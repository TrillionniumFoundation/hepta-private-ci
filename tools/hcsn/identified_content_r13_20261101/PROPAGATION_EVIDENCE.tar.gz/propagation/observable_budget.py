"""Choose a finite grid for declared first-hit observables, with honest scope.

This is a limited a posteriori certificate using the explicit unbounded
first-hit law. It does not turn these observables into a transition-TV bound.
CDF evaluation and expm arithmetic are not directed-rounding certified.
"""

import json
from pathlib import Path
import sys

import numpy as np
from scipy.linalg import expm

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))
sys.path.insert(0, str(ROOT))
from propagation.api import generator_numpy, make_grid
from propagation.bounds import action_certificate
from propagation.finite_volume import reset_numpy
from propagation.renewal_bounds import mixture_cdf_bounds
from validate_nested import subdivide


def first_hit_error_interval(finite_hit, continuous_lower, continuous_upper):
    """Upper bound on |finite_hit - true_hit| when true_hit is in [lo,hi]."""
    return max(abs(finite_hit-continuous_lower), abs(finite_hit-continuous_upper))


def main():
    protocol = json.loads((ROOT/'VALIDATION_PROTOCOL.json').read_text())
    nested = json.loads((ROOT/'NESTED_REFINEMENT.json').read_text())
    rows = []
    for row in nested['first_hit_rows']:
        low, high = mixture_cdf_bounds(np.array([row['dt']]), row['mu'], row['sigma'],
                                       row['mean'], row['width'], bins=8192)
        error = first_hit_error_interval(row['finite'], float(low[0]), float(high[0]))
        rows.append(dict(**row, continuous_lower=float(low[0]), continuous_upper=float(high[0]),
                         conditional_absolute_error_bound=error))
    budget = .002
    summary = [dict(n_active=n, worst_conditional_absolute_error_bound=max(
        r['conditional_absolute_error_bound'] for r in rows if r['n_active'] == n)) for n in (56, 112, 224)]
    chosen = next((s['n_active'] for s in summary if s['worst_conditional_absolute_error_bound'] <= budget), None)
    # Deliberately constructed after the diagnostic scan. It illustrates why a
    # large numerical action margin can disappear under an explicit error budget.
    # Safe gives 0; advance gives .26 - 1{first hit before .05}.
    witness = [r for r in rows if r['sigma'] == .15 and r['mean'] == .04
               and r['width'] == .03 and r['dt'] == .05]
    decisions = []
    for row in witness:
        q = np.array([0., .26-row['finite']])
        check = action_certificate(q, {'first_hit_probability_error': row['conditional_absolute_error_bound']})
        lower = min(0., .26-row['continuous_upper'])
        upper = max(0., .26-row['continuous_lower'])
        action = int(np.argmax(q))
        regret_interval = ([0., 0.] if action == 0 else
                           [max(0., row['continuous_lower']-.26), max(0., row['continuous_upper']-.26)])
        decisions.append(dict(n_active=row['n_active'], qvalues=q.tolist(),
            action=action, conditional_gap_check=check,
            continuous_advance_Q_interval=[.26-row['continuous_upper'], .26-row['continuous_lower']],
            continuous_one_action_regret_interval=regret_interval,
            continuous_value_interval=[lower, upper]))
    payload = dict(error_budget=budget, observable_contexts=54,
        first_hit_error_bounds=summary, selected_n_active_conditional_on_arithmetic=chosen,
        rows=rows, constructed_first_hit_decision=decisions,
        reference_bins=8192, cdf_padding=2e-13,
        arithmetic_verified_by_directed_rounding=False,
        scope='A posteriori bounds for 54 explicitly specified continuous first-hit averages, conditional on analytic CDF arithmetic. The small decision is a constructed post-scan illustration, not a new preregistered gain test. This is not a uniform kernel-TV bound, financial-payoff bound or general policy certificate.')
    path = ROOT/'OBSERVABLE_BUDGET.json'
    if path.exists():
        raise ValueError('Evidence is append-only')
    path.write_text(json.dumps(payload, indent=2, allow_nan=False)+'\n')
    print(json.dumps({k:payload[k] for k in ['error_budget', 'first_hit_error_bounds',
        'selected_n_active_conditional_on_arithmetic', 'constructed_first_hit_decision', 'scope']}, indent=2))


if __name__ == '__main__':
    main()
