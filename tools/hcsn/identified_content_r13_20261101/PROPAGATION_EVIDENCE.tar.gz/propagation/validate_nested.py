"""Global nested grid and complete-clock checks, separate from frozen training."""

import json
from pathlib import Path
import sys
import time

import numpy as np
from scipy.linalg import expm

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))
sys.path.insert(0, str(ROOT))
from action_validation import compute, model_at_step
import contract
from propagation.api import generator_numpy, make_grid
from propagation.bounds import action_certificate
from propagation.finite_volume import reset_numpy
from propagation.renewal_bounds import _clock_statistics, _duration_pmf, _phase_intervals, first_hit_cdf
from validate_propagation import physical_average


def subdivide(edges, factor):
    left = np.asarray(edges[:-1])[:, None]
    widths = np.diff(edges)[:, None]
    return np.r_[(left+widths*np.arange(factor)[None, :]/factor).ravel(), edges[-1]]


def zero_excursion_sanity():
    recovery, retention, total_time = .35, .75, 2.1
    kappa = 2/recovery
    q = np.zeros((4, 4))
    for bit in range(2):
        q[2*bit, 2*bit+1] = kappa
        for other in range(2):
            q[2*bit+1, 2*other] = kappa*(retention*(bit == other)+(1-retention)/2)
    q -= np.diag(q.sum(1))
    actual = np.array([1., 0., 0., 0.]) @ expm(q*total_time)
    actual_joint = np.c_[np.zeros(2), actual.reshape(2, 2)]
    rows = []
    for steps in (128, 256, 512):
        times = np.arange(steps+2)*total_time/steps
        exp_cdf = -np.expm1(-kappa*times)
        zero_hit = np.zeros(steps+1)
        zero_hit[0] = 1
        fast = _clock_statistics(zero_hit, zero_hit, _duration_pmf(exp_cdf, True, steps), retention)
        slow = _clock_statistics(zero_hit, zero_hit, _duration_pmf(exp_cdf, False, steps), retention)
        phase_lo, phase_hi = _phase_intervals(fast['counts'], slow['counts'], 1)
        weight_lo, weight_hi = _phase_intervals(fast['weighted_counts'], slow['weighted_counts'], retention)
        weight_hi = np.minimum(weight_hi, phase_hi)
        low = np.maximum(np.stack((.5*(phase_lo+weight_lo), .5*(phase_lo-weight_hi)))[:, :, -1], 0)
        high = np.minimum(np.stack((.5*(phase_hi+weight_hi), .5*(phase_hi-weight_lo)))[:, :, -1], phase_hi[:, -1])
        violation = max(float(np.max(low-actual_joint)), float(np.max(actual_joint-high)), 0)
        rows.append(dict(steps=steps, joint_lower=low.tolist(), joint_upper=high.tolist(),
                         actual_joint=actual_joint.tolist(), max_violation=violation,
                         max_interval_width=float((high-low).max()), fast_zero_cycle_mass=fast['zero_duration_cycle_mass']))
    return rows


def main():
    start = time.perf_counter()
    protocol = json.loads((ROOT/'VALIDATION_PROTOCOL.json').read_text())
    base = make_grid()
    grids = {factor: subdivide(base, factor) for factor in (1, 2, 4)}
    first = []
    cfg = protocol['first_hit']
    for case in protocol['physical_parameter_cases']:
        for factor, edges in grids.items():
            q = generator_numpy(case['sigma'], case['mu'], case['reset_x'], edges)['Q']
            n = len(edges)-1
            for dt in cfg['times']:
                survive = expm(dt*q[:n, :n]) @ np.ones(n)
                for mean in cfg['initial_gaussian_means']:
                    for width in cfg['initial_gaussian_widths']:
                        finite = 1-float(reset_numpy(mean, width, edges) @ survive)
                        exact = physical_average(lambda x: first_hit_cdf(x, dt, case['mu'], case['sigma']), mean, width, 320)
                        first.append(dict(**case, factor=factor, n_active=n, mean=mean, width=width, dt=dt,
                                          finite=finite, continuous_unbounded=exact, error=finite-exact))
    first_summary = [dict(factor=f, n_active=len(grids[f])-1,
        max_error=max(abs(r['error']) for r in first if r['factor'] == f),
        mean_error=float(np.mean([abs(r['error']) for r in first if r['factor'] == f]))) for f in grids]
    acfg = protocol['action_validation']
    models = {f: model_at_step(None, edges) for f, edges in grids.items()}
    contexts = [dict(mean=m, width=w, p0=p) for m in acfg['independent_initial_means']
                for w in acfg['independent_initial_widths'] for p in acfg['independent_bit0_probabilities']]
    witness = acfg['inherited_witness']
    actions = []
    for dt in acfg['independent_dt']+[witness['dt']]:
        cc = contexts if dt != witness['dt'] else [dict(mean=witness['mean'], width=witness['width'], p0=witness['p_bit0'])]
        results = {f: compute(model, cc, dt, acfg) for f, model in models.items()}
        for index, context in enumerate(cc):
            reference = results[4].qvalues[index]
            for factor in (1, 2):
                q = results[factor].qvalues[index]
                error = float(abs(q-reference).max())
                check = action_certificate(q, {'computed_finite_reference_difference': error},
                                            tolerance=acfg['horizon']*contract.PROTOCOL['tie_tolerance'])
                action = int(results[factor].action[index])
                actions.append(dict(**context, dt=dt, inherited_witness=dt == witness['dt'], factor=factor,
                    n_active=len(grids[factor])-1, action=action, reference_action=int(results[4].action[index]),
                    qvalues=q.tolist(), reference_qvalues=reference.tolist(),
                    computed_reference_action_regret=float(reference.max()-reference[action]), gap_check=check))
    action_summary = []
    for factor in (1, 2):
        part = [r for r in actions if r['factor'] == factor and not r['inherited_witness']]
        action_summary.append(dict(factor=factor, n_active=len(grids[factor])-1, contexts=len(part),
            disagreements=sum(r['action'] != r['reference_action'] for r in part),
            max_computed_reference_action_regret=max(r['computed_reference_action_regret'] for r in part),
            max_q_difference=max(r['gap_check']['value_error'] for r in part),
            finite_computed_reference_gap_accepts=sum(r['gap_check']['action_certified'] for r in part)))
    previous = json.loads((ROOT/'ACTIONS.json').read_text())
    tie_audit = []
    for record in previous['rows']:
        for g in record['per_grid']:
            q, error = g['qvalues'], g['finite_reference_gap_check']['value_error']
            updated = action_certificate(q, {'computed_finite_reference_difference': error},
                tolerance=acfg['horizon']*contract.PROTOCOL['tie_tolerance'])
            tie_audit.append(dict(mean=record['mean'], width=record['width'], p0=record['p0'], dt=record['dt'],
                                  near_step=g['near_step'], corrected_finite_vector_gap_check=updated))
    payload = dict(first_hit_rows=first, first_hit_summary=first_summary,
        action_rows=actions, action_summary=action_summary, inherited_near_step_tie_audit=tie_audit,
        zero_excursion_renewal_sanity=zero_excursion_sanity(), wall_seconds=time.perf_counter()-start,
        scope='True nested refinement at fixed expanded upper boundary. Finite numerical Q differences only. H*tau covers accumulated tie tolerance in exact finite-model value computation; a full cross-model policy regret certificate still requires uniform model error over reachable states. No continuous FV spatial bound asserted.')
    path = ROOT/'NESTED_REFINEMENT.json'
    if path.exists():
        raise ValueError('Evidence is append-only')
    path.write_text(json.dumps(payload, indent=2, allow_nan=False)+'\n')
    print(json.dumps({k: payload[k] for k in ['first_hit_summary', 'action_summary', 'zero_excursion_renewal_sanity', 'wall_seconds']}, indent=2))


if __name__ == '__main__':
    main()
