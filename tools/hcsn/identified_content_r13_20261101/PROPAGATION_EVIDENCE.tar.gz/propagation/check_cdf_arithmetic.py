"""High-precision spot checks of reference formulas; not interval certification."""

import json
from pathlib import Path
import sys

import mpmath as mp
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))
from propagation.renewal_bounds import first_hit_cdf


def main():
    mp.mp.dps = 80
    rows = []
    for sigma, mu in ((.3, .015), (.4, -.02), (.15, .04875)):
        for x in (0., .0001, .01, .04, .2, .6, .8, 13.064376419678013):
            for t in (.00001, .05, .45, 2.1, 6., 29.4):
                ss, mm, xx, tt = map(mp.mpf, (sigma, mu, x, t))
                phi = lambda z: mp.erfc(-z/mp.sqrt(2))/2
                ref = phi((-xx-mm*tt)/(ss*mp.sqrt(tt)))
                ref += mp.exp(-2*mm*xx/ss**2)*phi((-xx+mm*tt)/(ss*mp.sqrt(tt)))
                value = float(first_hit_cdf(x, t, mu, sigma))
                error = float(abs(mp.mpf(value)-ref))
                rows.append(dict(sigma=sigma, mu=mu, x=x, t=t, float64=value,
                                 mpmath_80_digit=str(ref), absolute_error=error))
    payload = dict(rows=rows, max_absolute_error=max(r['absolute_error'] for r in rows),
                   cases=len(rows), scope='Deterministic high-precision spot checks only; no proof of a uniform floating-point error bound and no directed-rounding interval claim.')
    path = ROOT/'CDF_ARITHMETIC.json'
    if path.exists():
        raise ValueError('Evidence is append-only')
    path.write_text(json.dumps(payload, indent=2, allow_nan=False)+'\n')
    print(json.dumps({k:v for k,v in payload.items() if k != 'rows'}, indent=2))


if __name__ == '__main__':
    main()
