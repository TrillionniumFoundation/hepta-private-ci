import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tarfile
import tempfile

REPO = Path('/workspace/scratch/3a732c35be06/hepta-r12')
REL = Path('tools/hcsn/identified_content_r13_20261101')
SOURCE = REPO/REL
BASE = '90d1c11c5e654b1bf595c2564f1160df7d8e07a9'
REPORT = SOURCE/'delivery_ci/CLEAN_RESTORE_REVIEW.json'
BASELINE_READ_SOURCES = {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git_bytes(path, expected_sha256=None):
    env = dict(os.environ)
    env['GIT_NO_LAZY_FETCH'] = '1'
    process = subprocess.run(['git', 'show', f'{BASE}:{path}'], cwd=REPO,
                             env=env, capture_output=True)
    if process.returncode == 0:
        data = process.stdout
        origin = 'fixed_commit_git_object'
    elif expected_sha256 is not None and (REPO/path).is_file():
        # Partial clones can lack a blob. A preserved old archive/source file
        # is accepted only after matching its immutable prior SHA256 entry.
        data = (REPO/path).read_bytes()
        assert digest(data) == expected_sha256, str(path)
        origin = 'preserved_worktree_bytes_verified_against_immutable_prior_sha256'
    else:
        raise RuntimeError(f'Cannot read baseline object {path}: {process.stderr.decode()}')
    if expected_sha256 is not None:
        assert digest(data) == expected_sha256
    BASELINE_READ_SOURCES[str(path)] = {'origin':origin, 'sha256':digest(data)}
    return data


def tar_members(payload):
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
        members = archive.getmembers()
        assert len({m.name for m in members}) == len(members), 'Duplicate member name'
        assert all(m.isfile() for m in members), 'Nonregular member'
        return {m.name: digest(archive.extractfile(m).read()) for m in members}


def run_restore(root, verify=False):
    command = [sys.executable, str(root/'restore_artifacts.py')]
    if verify:
        command.append('--verify-only')
    process = subprocess.run(command, cwd=root, capture_output=True, text=True)
    assert process.returncode == 0, process.stderr
    result = json.loads(process.stdout)
    assert result['verified_files'] == 645, result
    return {'returncode': process.returncode, 'stdout': result, 'stderr': process.stderr}


def main():
    assert not REPORT.exists(), 'Review is append-only'
    work = Path(tempfile.mkdtemp(prefix='hepta_r13_clean_restore_'))
    target = work/REL
    target.mkdir(parents=True)
    inputs = {'TRAINING_ARCHIVES.json', 'EVIDENCE_ARCHIVES.json',
              'restore_artifacts.py', 'native/BINARY_ARTIFACTS.json'}
    archives, all_members, part_sizes = [], {}, []
    changed_archives = 0
    for name in ('TRAINING_ARCHIVES.json', 'EVIDENCE_ARCHIVES.json'):
        before = json.loads(git_bytes(REL/name))
        after = json.loads((SOURCE/name).read_bytes())
        assert {k:v for k,v in before.items() if k != 'archives'} == {k:v for k,v in after.items() if k != 'archives'}
        old = {record['file']:record for record in before['archives']}
        assert set(old) == {record['file'] for record in after['archives']}
        for record in after['archives']:
            previous = old[record['file']]
            assert {k:v for k,v in previous.items() if k != 'parts'} == {k:v for k,v in record.items() if k != 'parts'}
            old_parts = previous.get('parts', [{'file': previous['file'], 'bytes': previous['bytes'], 'sha256': previous['sha256']}])
            old_blocks = []
            for part in old_parts:
                block = git_bytes(REL/part['file'], part['sha256'])
                assert len(block) == part['bytes'] and digest(block) == part['sha256']
                old_blocks.append(block)
            old_payload = b''.join(old_blocks)
            parts = record.get('parts', [{'file': record['file'], 'bytes': record['bytes'], 'sha256': record['sha256']}])
            blocks = []
            for part in parts:
                block = (SOURCE/part['file']).read_bytes()
                assert len(block) == part['bytes'] and digest(block) == part['sha256']
                blocks.append(block)
                inputs.add(part['file'])
            payload = b''.join(blocks)
            assert payload == old_payload
            assert len(payload) == record['bytes'] and digest(payload) == record['sha256']
            old_names, new_names = tar_members(old_payload), tar_members(payload)
            assert old_names == new_names == record['members'] == previous['members']
            for member, expected in new_names.items():
                assert member not in all_members or all_members[member] == expected
                all_members[member] = expected
            changed = previous.get('parts') != record.get('parts')
            if changed:
                changed_archives += 1
                assert all(len(b) <= 480000 for b in blocks)
                assert blocks == [payload[i:i+480000] for i in range(0, len(payload), 480000)]
                part_sizes.extend(map(len, blocks))
            archives.append({'archive':record['file'], 'payload_sha256':record['sha256'],
                'payload_bytes':len(payload), 'repartitioned':changed,
                'old_paths':[p['file'] for p in old_parts], 'new_paths':[p['file'] for p in parts],
                'member_count':len(new_names),
                'member_map_sha256':digest(json.dumps(new_names, sort_keys=True, separators=(',', ':')).encode()),
                'payload_byte_identical':True, 'member_set_and_hashes_identical':True})
    assert changed_archives == 9 and len(part_sizes) == 24
    native = json.loads((SOURCE/'native/BINARY_ARTIFACTS.json').read_text())
    for record in native['artifacts']:
        inputs.update(part['file'] for part in record['parts'])
    input_inventory = {}
    for name in sorted(inputs):
        source = SOURCE/name
        data = source.read_bytes()
        destination = target/name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        input_inventory[name] = {'sha256':digest(data), 'bytes':len(data)}
    assert len(inputs) == 43
    assert max(x['bytes'] for x in input_inventory.values()) <= 512000
    assert not (target/'evidence/fits').exists()
    assert not any((target/r['target']).exists() for r in native['artifacts'])
    before_listing = sorted(str(p.relative_to(target)) for p in target.rglob('*') if p.is_file())
    assert before_listing == sorted(inputs)
    verify_before = run_restore(target, verify=True)
    assert before_listing == sorted(str(p.relative_to(target)) for p in target.rglob('*') if p.is_file())
    restored = run_restore(target)
    restored_members = {}
    for name, expected in sorted(all_members.items()):
        path = target/name
        actual = digest(path.read_bytes())
        assert actual == expected
        restored_members[name] = actual
    binary_rows = []
    for record in native['artifacts']:
        path = target/record['target']
        data = path.read_bytes()
        mode = stat.S_IMODE(path.stat().st_mode)
        assert digest(data) == record['sha256'] and len(data) == record['bytes']
        assert mode == record['mode'] and data[:4] == b'\x7fELF'
        binary_rows.append({'target':record['target'], 'sha256':digest(data), 'bytes':len(data),
                            'mode_octal':oct(mode), 'exact_manifest_match':True})
    for record in archives:
        data = (target/record['archive']).read_bytes()
        assert digest(data) == record['payload_sha256'] and len(data) == record['payload_bytes']
    freeze_path = target/'evidence/FREEZE.json'
    frozen = json.loads(freeze_path.read_text())
    assert len(frozen['source_sha256']) == 40 and len(frozen['fit_sha256']) == 50
    assert digest(freeze_path.read_bytes()) == digest((SOURCE/'evidence/FREEZE.json').read_bytes())
    fits = {}
    for name, expected in frozen['fit_sha256'].items():
        actual = digest((target/'evidence'/name).read_bytes())
        assert actual == expected
        fits[name] = actual
    sources_from_archive, sources_from_checkout = {}, {}
    for name, expected in frozen['source_sha256'].items():
        path = target.parent/name
        # Git object bytes, not current working-tree files or preexisting evidence.
        tracked = git_bytes(Path('tools/hcsn')/name, expected)
        assert digest(tracked) == expected
        if path.exists():
            assert digest(path.read_bytes()) == expected
            sources_from_archive[name] = expected
        else:
            sources_from_checkout[name] = expected
    archive_only_source_count = len(sources_from_archive)
    archive_only_missing_sources = sorted(sources_from_checkout)
    # Real users run restoration in a git checkout. Complete only the forty
    # recorded frozen source files, after recording the archive-only result.
    for name in sources_from_checkout:
        path = target.parent/name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(git_bytes(Path('tools/hcsn')/name, sources_from_checkout[name]))
    assert all(digest((target.parent/name).read_bytes()) == expected
               for name, expected in frozen['source_sha256'].items())
    second_restore = run_restore(target)
    verify_after = run_restore(target, verify=True)
    assert all(digest((target/name).read_bytes()) == expected for name, expected in all_members.items())
    assert all(digest((target/name).read_bytes()) == item['sha256'] for name, item in input_inventory.items())
    spec = importlib.util.spec_from_file_location('clean_restore_readonly_review', target/'restore_artifacts.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    guard = target/'review_existing_bytes.bin'
    guard.write_bytes(b'preserved original bytes')
    try:
        module.save(guard.name, b'different requested bytes', False)
    except FileExistsError:
        overwrite_refused = True
    else:
        overwrite_refused = False
    assert overwrite_refused and guard.read_bytes() == b'preserved original bytes'
    guard.chmod(0o600)
    module.save(guard.name, guard.read_bytes(), True)
    verify_keeps_mode = stat.S_IMODE(guard.stat().st_mode) == 0o600
    module.save(guard.name, guard.read_bytes(), False)
    matching_bytes_mode_changed = stat.S_IMODE(guard.stat().st_mode) == 0o644
    assert verify_keeps_mode and matching_bytes_mode_changed
    guard.unlink()
    outside = work/'outside'
    outside.mkdir()
    link = target/'review_external_symlink'
    link.symlink_to(outside, target_is_directory=True)
    path_checks = {}
    for name in ('../escape', str(outside/'absolute'), 'review_external_symlink/escape'):
        try:
            module.destination(name)
        except ValueError:
            path_checks[name] = 'rejected'
        else:
            path_checks[name] = 'accepted'
    assert set(path_checks.values()) == {'rejected'}
    link.unlink()
    limitations = [
        'The artifact-only kit restores artifacts, not every frozen source file. Forty frozen sources require normal tracked checkout files plus restored members; the two phases are recorded separately.',
        'verify-only validates archived bytes and checks conflicting existing targets; success does not mean missing targets have been materialized.',
        'Serial save refuses an existing target with different bytes, but matching files can have their permission mode changed during restore.',
        'Destination resolve rejects observed parent traversal, outside absolute paths and existing outside symlinks; this is not protection against concurrent filesystem/symlink replacement between checks and writes.',
        'The restoration is not atomic and has no rollback. Earlier files or a reconstructed archive can remain after a later verification failure. Split archive save occurs before the full reconstructed archive digest check.',
        'Manifest input paths for archive/native parts are read directly, without the destination containment check. Treat manifests and their part paths as trusted repository data; no general untrusted-manifest sandbox is claimed.',
        'There is no archive decompression size/quota policy, and missing TRAINING_ARCHIVES or EVIDENCE_ARCHIVES manifests are silently skipped by the script. This review explicitly supplied both and checked the expected 645 count.',
        'Tar members must be regular files and match the manifest member set/hashes, but the restore implementation itself compares sets and does not separately forbid duplicate names. The audited real archives contain no duplicate member names.',
        'This verifies file bytes and the two Linux ELF modes, not a portable runnable environment, external Python/OS dependencies, signatures of an untrusted index, or execution on another architecture.'
    ]
    report = {
        'schema':'hcsn-r13-clean-restore-independent-review-v1',
        'baseline_commit':BASE,
        'scope':'Delivery packaging only. No training, task confirmation, model changes, or dependency changes.',
        'review_script_sha256':digest(Path(__file__).read_bytes()),
        'restore_script_sha256':input_inventory['restore_artifacts.py']['sha256'],
        'temp_root':str(work),
        'minimal_input_count':len(inputs), 'minimal_input_inventory':input_inventory,
        'repartitioned_archives':changed_archives, 'replacement_volume_count':len(part_sizes),
        'max_new_volume_bytes':max(part_sizes),
        'max_minimal_input_file_bytes':max(x['bytes'] for x in input_inventory.values()),
        'archive_count':len(archives), 'archive_comparisons':archives,
        'archived_member_occurrences':sum(x['member_count'] for x in archives),
        'unique_archived_member_count':len(all_members),
        'restored_member_hashes':restored_members,
        'verify_only_before_materialization':verify_before,
        'actual_restore':restored, 'second_restore_same_bytes':second_restore,
        'verify_only_after_materialization':verify_after,
        'native_binaries':binary_rows,
        'freeze_sha256':digest(freeze_path.read_bytes()),
        'freeze_fit_receipt_frontend_count':len(fits), 'freeze_fit_receipt_frontend_hashes':fits,
        'freeze_source_count':len(frozen['source_sha256']),
        'freeze_sources_restored_from_archive_count':archive_only_source_count,
        'freeze_sources_added_from_tracked_checkout_count':len(sources_from_checkout),
        'archive_only_missing_frozen_sources':archive_only_missing_sources,
        'freeze_source_hashes':frozen['source_sha256'],
        'baseline_read_sources':BASELINE_READ_SOURCES,
        'prior_attempt_note':'First review attempt stopped before restoration because the partial clone lacked a promised DATA_AND_FRONTEND blob and its proxy was unavailable. Retried with explicit per-file fallback to preserved bytes only after immutable prior SHA256 verification; no prior mismatch was accepted.',
        'existing_different_bytes_refused_and_preserved':overwrite_refused,
        'verify_only_preserves_existing_mode':verify_keeps_mode,
        'matching_existing_bytes_may_have_mode_changed':matching_bytes_mode_changed,
        'path_checks':path_checks, 'limitations':limitations,
        'passed':True
    }
    REPORT.write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps({k:report[k] for k in ['passed','minimal_input_count','repartitioned_archives',
        'replacement_volume_count','max_new_volume_bytes','archive_count','archived_member_occurrences',
        'unique_archived_member_count','freeze_fit_receipt_frontend_count','freeze_source_count',
        'freeze_sources_restored_from_archive_count','freeze_sources_added_from_tracked_checkout_count',
        'native_binaries','temp_root']}, indent=2))


if __name__ == '__main__':
    main()
