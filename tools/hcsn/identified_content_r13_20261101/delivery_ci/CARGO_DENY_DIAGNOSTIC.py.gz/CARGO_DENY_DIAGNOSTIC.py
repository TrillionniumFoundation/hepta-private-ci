import argparse
import collections
import gzip
import hashlib
import json
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    source = args.inputs
    output = args.output
    output.mkdir(parents=True, exist_ok=True)
    names = [
        "run_summary", "tool_install", "connector_provenance",
        "dependency_tree_comparison", "local_manifest_comparison",
        "advisory_errors", "advisory_parent_chains", "advisory_db",
        "metadata_checks", "resolved_metadata_summary", "workspace_direct_bans",
        "lock_sources", "lock_ban_parents",
    ]
    evidence = {name: json.loads((source / (name + ".json")).read_text()) for name in names}
    errors = evidence["advisory_errors"]
    raw = (source / "cargo-deny.stderr.txt").read_bytes()
    compressed = gzip.compress(raw, mtime=0)
    parts = []
    for i, offset in enumerate(range(0, len(compressed), 480000)):
        data = compressed[offset:offset + 480000]
        name = f"CARGO_DENY_BASELINE.stderr.txt.gz.vol{i:03d}"
        (output / name).write_bytes(data)
        parts.append({"path": name, "bytes": len(data), "sha256": digest(data)})
    report = {
        "schema": "hepta-r13-cargo-deny-readonly-diagnostic-v1",
        "status": "locally_reproduced_inherited_advisory_blockers",
        "observed_at_utc": evidence["connector_provenance"]["observed_at_utc"],
        "interpretation": {
            "error_count": len(errors),
            "error_categories": dict(collections.Counter(e["kind"] for e in errors)),
            "affected_package_versions": len({(e["crate"], e["version"]) for e in errors}),
            "remote_original_logs_obtained": False,
            "local_same_configuration_reproduction": True,
            "dependency_inputs_identical_r12_r13": evidence["dependency_tree_comparison"]["differences"] == [],
            "no_repository_dependency_or_policy_mutation_during_baseline_run": evidence["run_summary"]["before_hashes"] == evidence["run_summary"]["after_hashes"],
            "no_tests_or_training_run_by_baseline_diagnostic": True,
            "no_runtime_exploitability_claim": True,
            "static_matrix_sdk_indexeddb_wrapper_candidate_was_not_an_actual_ban_error": True,
        },
        "limitations": [
            "Remote job step summaries show failure, but raw remote logs remain unavailable (Transport closed).",
            "Local reproduction uses the pinned action's cargo-deny 0.19.0, Rust 1.95.0 and --all-features, adding --locked and changing only color output.",
            "The advisory database is time-varying; its exact local commit and the 22 matched source-file hashes are recorded.",
            "Advisory matching is a dependency-policy finding; exposure depends on enabled runtime features, paths and deployment.",
            "The six unmaintained findings have no patched version of the same crate in this database; the tool's text does not prove migration impossible.",
            "Workspace-only metadata was a limited initial check; the subsequent full resolved graph contains 1517 packages and nodes.",
            "Two-stage repair plans are prospective, and are not counts of already closed blockers.",
        ],
        "raw_stderr": {"bytes": len(raw), "sha256": digest(raw), "gzip_bytes": len(compressed), "gzip_sha256": digest(compressed), "parts": parts},
        "raw_stdout": (source / "cargo-deny.stdout.txt").read_text(),
        "evidence": evidence,
    }
    (output / "CARGO_DENY_DIAGNOSTIC.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"error_count": len(errors), "parts": parts, "report_bytes": (output / "CARGO_DENY_DIAGNOSTIC.json").stat().st_size}, indent=2))


if __name__ == "__main__":
    main()
