use std::fs;
use std::path::Path;
use std::path::PathBuf;

use codex_hepta_contracts::AgentId;
use codex_hepta_contracts::Sha256Digest;
use codex_hepta_paths::HeptaAgentLayout;
use codex_state::SqliteConfig;
use codex_utils_absolute_path::AbsolutePathBuf;
use sqlx::Row;
use sqlx::SqlitePool;

use crate::AUTOMATION_SCHEMA_VERSION;
use crate::AutomationDispatchUncertainty;
use crate::AutomationError;
use crate::AutomationLease;
use crate::AutomationQueueReceipt;
use crate::AutomationSchedule;
use crate::AutomationTask;
use crate::AutomationTaskDraft;
use crate::AutomationTaskId;
use crate::AutomationTaskState;
use crate::model::client_message_id;
use crate::taskflow::TaskFlowError;
use crate::taskflow::verify_taskflow_store;

const AUTOMATION_DB_FILENAME: &str = "automation_1.sqlite3";
const MAX_TASK_PAGE: usize = 1_024;
static MIGRATOR: sqlx::migrate::Migrator = sqlx::migrate!("./migrations");

#[derive(Clone)]
pub struct AutomationStore {
    pool: SqlitePool,
    owner_agent_id: AgentId,
    path: PathBuf,
    timer_epoch: i64,
}

impl AutomationStore {
    pub async fn open(layout: &HeptaAgentLayout) -> Result<Self, AutomationError> {
        Self::open_root(
            layout.automation_root().to_path_buf(),
            layout.agent_id().clone(),
        )
        .await
    }

    pub(crate) async fn open_root(
        root: PathBuf,
        owner_agent_id: AgentId,
    ) -> Result<Self, AutomationError> {
        create_private_directory(&root)?;
        let path = root.join(AUTOMATION_DB_FILENAME);
        let sqlite_home = AbsolutePathBuf::try_from(root).map_err(|_| AutomationError::Invalid)?;
        let pool = SqliteConfig::from_sqlite_home(sqlite_home)
            .open_durable_evidence_pool(&path)
            .await
            .map_err(unavailable)?;
        if let Err(error) = reconcile_legacy_migration_ids(&pool).await {
            pool.close().await;
            return Err(error);
        }
        if MIGRATOR.run(&pool).await.is_err() {
            pool.close().await;
            return Err(AutomationError::Unavailable);
        }
        protect_database_file(&path)?;
        sqlx::query(
            "INSERT INTO automation_meta (singleton, schema_version, owner_agent_id)
             VALUES (1, ?, ?) ON CONFLICT(singleton) DO NOTHING",
        )
        .bind(i64::from(AUTOMATION_SCHEMA_VERSION))
        .bind(owner_agent_id.as_str())
        .execute(&pool)
        .await
        .map_err(unavailable)?;
        verify_store(&pool, &owner_agent_id).await?;
        let timer_epoch: i64 = sqlx::query_scalar(
            "SELECT writer_epoch FROM automation_timer_lifecycle WHERE singleton = 1",
        )
        .fetch_one(&pool)
        .await
        .map_err(unavailable)?;
        if timer_epoch <= 0 {
            pool.close().await;
            return Err(AutomationError::Corrupt);
        }
        Ok(Self {
            pool,
            owner_agent_id,
            path,
            timer_epoch,
        })
    }

    pub fn owner_agent_id(&self) -> &AgentId {
        &self.owner_agent_id
    }

    pub(crate) fn taskflow_pool(&self) -> &SqlitePool {
        &self.pool
    }

    pub(crate) fn taskflow_owner_agent_id(&self) -> &AgentId {
        &self.owner_agent_id
    }

    pub(crate) fn timer_epoch(&self) -> i64 {
        self.timer_epoch
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub async fn close(&self) {
        self.pool.close().await;
    }

    pub async fn create_task(
        &self,
        draft: &AutomationTaskDraft,
    ) -> Result<AutomationTask, AutomationError> {
        draft.validate()?;
        let (schedule_kind, interval_ms) = schedule_columns(draft.schedule)?;
        let (mut transaction, phase) = self.begin_timer_write().await?;
        if phase != crate::TimerPhase::Active {
            return Err(AutomationError::Conflict);
        }
        let result = sqlx::query(
            "INSERT INTO automation_tasks (
                task_id, owner_agent_id, thread_id, prompt, schedule_kind, interval_ms,
                state, next_run_at_ms, next_occurrence, created_at_ms, updated_at_ms
             ) VALUES (?, ?, ?, ?, ?, ?, 'enabled', ?, 1, ?, ?)",
        )
        .bind(draft.task_id.to_string())
        .bind(self.owner_agent_id.as_str())
        .bind(&draft.thread_id)
        .bind(&draft.prompt)
        .bind(schedule_kind)
        .bind(interval_ms.map(to_i64).transpose()?)
        .bind(to_i64(draft.first_run_at_ms)?)
        .bind(to_i64(draft.created_at_ms)?)
        .bind(to_i64(draft.created_at_ms)?)
        .execute(&mut *transaction)
        .await;
        match result {
            Ok(_) => {
                transaction.commit().await.map_err(unavailable)?;
                self.task(draft.task_id)
                    .await?
                    .ok_or(AutomationError::Corrupt)
            }
            Err(error) if is_constraint(&error) => Err(AutomationError::Conflict),
            Err(error) => Err(unavailable(error)),
        }
    }

    pub async fn task(
        &self,
        task_id: AutomationTaskId,
    ) -> Result<Option<AutomationTask>, AutomationError> {
        sqlx::query(TASK_SELECT_BY_ID)
            .bind(task_id.to_string())
            .fetch_optional(&self.pool)
            .await
            .map_err(unavailable)?
            .map(|row| task_from_row(&row, &self.owner_agent_id))
            .transpose()
    }

    pub async fn list_tasks(&self, limit: usize) -> Result<Vec<AutomationTask>, AutomationError> {
        if !(1..=MAX_TASK_PAGE).contains(&limit) {
            return Err(AutomationError::Invalid);
        }
        let rows = sqlx::query(
            "SELECT task_id, owner_agent_id, thread_id, prompt, schedule_kind, interval_ms,
                    state, next_run_at_ms, next_occurrence, created_at_ms, updated_at_ms
             FROM automation_tasks ORDER BY created_at_ms, task_id LIMIT ?",
        )
        .bind(i64::try_from(limit).map_err(|_| AutomationError::Invalid)?)
        .fetch_all(&self.pool)
        .await
        .map_err(unavailable)?;
        rows.iter()
            .map(|row| task_from_row(row, &self.owner_agent_id))
            .collect()
    }

    /// Counts durable automation work that has not yet reached a drain-safe
    /// classification. Durable dispatch uncertainty is already classified as
    /// indeterminate and is intentionally excluded; it is reconciled after
    /// restart with the same stable identity rather than relabelled as success
    /// or failure. Leased work without an uncertainty witness and occurrence
    /// lifecycle states that can still advance (claimed, admitted, running)
    /// block a graceful Agentd drain.
    pub async fn drain_blockers(&self) -> Result<u32, AutomationError> {
        let count: i64 = sqlx::query_scalar(
            "SELECT COUNT(*) FROM (
                 SELECT r.task_id AS task_id, r.occurrence AS occurrence
                 FROM automation_runs r
                 JOIN automation_tasks t ON t.task_id = r.task_id
                 WHERE t.owner_agent_id = ? AND r.state = 'leased'
                   AND NOT EXISTS (
                       SELECT 1 FROM automation_dispatch_outcomes d
                       WHERE d.task_id = r.task_id
                         AND d.occurrence = r.occurrence
                         AND d.outcome = 'uncertain'
                   )
                 UNION
                 SELECT l.task_id AS task_id, l.occurrence AS occurrence
                 FROM automation_occurrence_lifecycle l
                 WHERE l.owner_agent_id = ?
                   AND l.state IN ('claimed', 'admitted', 'running')
                   AND NOT EXISTS (
                       SELECT 1 FROM automation_dispatch_outcomes d
                       WHERE d.task_id = l.task_id
                         AND d.occurrence = l.occurrence
                         AND d.outcome = 'uncertain'
                   )
             )",
        )
        .bind(self.owner_agent_id.as_str())
        .bind(self.owner_agent_id.as_str())
        .fetch_one(&self.pool)
        .await
        .map_err(unavailable)?;
        u32::try_from(count).map_err(|_| AutomationError::Corrupt)
    }

    /// Returns provider admissions whose terminal outcome is not known.
    ///
    /// An uncertain occurrence is deliberately not eligible for automatic
    /// retry. A provider-specific reconciler must use
    /// [`Self::reconcile_uncertain_occurrence_admitted`] with the exact queue
    /// receipt, or [`Self::reconcile_uncertain_occurrence_absent`] with durable
    /// proof that the stable dispatch identity was not accepted.
    pub async fn uncertain_dispatches(
        &self,
        limit: usize,
    ) -> Result<Vec<AutomationDispatchUncertainty>, AutomationError> {
        if !(1..=MAX_TASK_PAGE).contains(&limit) {
            return Err(AutomationError::Invalid);
        }
        let rows = sqlx::query(
            "SELECT o.task_id, o.occurrence, r.scheduled_for_ms,
                    o.client_user_message_id, o.observed_at_ms
             FROM automation_dispatch_outcomes o
             JOIN automation_runs r
               ON r.task_id = o.task_id AND r.occurrence = o.occurrence
             JOIN automation_tasks t ON t.task_id = o.task_id
             WHERE t.owner_agent_id = ? AND o.outcome = 'uncertain'
             ORDER BY o.observed_at_ms, o.task_id, o.occurrence LIMIT ?",
        )
        .bind(self.owner_agent_id.as_str())
        .bind(i64::try_from(limit).map_err(|_| AutomationError::Invalid)?)
        .fetch_all(&self.pool)
        .await
        .map_err(unavailable)?;
        rows.iter()
            .map(|row| {
                Ok(AutomationDispatchUncertainty {
                    task_id: parse_task_id(row, "task_id")?,
                    occurrence: to_u64(row.try_get("occurrence").map_err(unavailable)?)?,
                    scheduled_for_ms: to_u64(
                        row.try_get("scheduled_for_ms").map_err(unavailable)?,
                    )?,
                    client_user_message_id: row
                        .try_get("client_user_message_id")
                        .map_err(unavailable)?,
                    observed_at_ms: to_u64(row.try_get("observed_at_ms").map_err(unavailable)?)?,
                })
            })
            .collect()
    }

    pub async fn cancel_task(
        &self,
        task_id: AutomationTaskId,
        now_ms: u64,
    ) -> Result<AutomationTask, AutomationError> {
        let (mut transaction, _) = self.begin_timer_write().await?;
        let changed = sqlx::query(
            "UPDATE automation_tasks
             SET state = 'cancelled', next_run_at_ms = NULL, updated_at_ms = ?
             WHERE task_id = ? AND owner_agent_id = ? AND state IN ('enabled', 'disabled')",
        )
        .bind(to_i64(now_ms)?)
        .bind(task_id.to_string())
        .bind(self.owner_agent_id.as_str())
        .execute(&mut *transaction)
        .await
        .map_err(unavailable)?;
        if changed.rows_affected() != 1 {
            return Err(AutomationError::Conflict);
        }
        sqlx::query(
            "UPDATE automation_runs
             SET state = 'cancelled', lease_generation = NULL, lease_token = NULL,
                 lease_expires_at_ms = NULL
             WHERE task_id = ? AND state = 'pending'",
        )
        .bind(task_id.to_string())
        .execute(&mut *transaction)
        .await
        .map_err(unavailable)?;
        transaction.commit().await.map_err(unavailable)?;
        self.task(task_id).await?.ok_or(AutomationError::Corrupt)
    }

    pub async fn set_enabled(
        &self,
        task_id: AutomationTaskId,
        enabled: bool,
        resume_at_ms: Option<u64>,
        now_ms: u64,
    ) -> Result<AutomationTask, AutomationError> {
        let (mut transaction, phase) = self.begin_timer_write().await?;
        if enabled && phase != crate::TimerPhase::Active {
            return Err(AutomationError::Conflict);
        }
        let changed = if enabled {
            let resume_at_ms = resume_at_ms.ok_or(AutomationError::Invalid)?;
            sqlx::query(
                "UPDATE automation_tasks
                 SET state = 'enabled', next_run_at_ms = ?, updated_at_ms = ?
                 WHERE task_id = ? AND owner_agent_id = ? AND state = 'disabled'
                   AND NOT EXISTS (
                       SELECT 1 FROM automation_runs r
                       WHERE r.task_id = automation_tasks.task_id AND r.state = 'leased'
                   )",
            )
            .bind(to_i64(resume_at_ms)?)
            .bind(to_i64(now_ms)?)
            .bind(task_id.to_string())
            .bind(self.owner_agent_id.as_str())
            .execute(&mut *transaction)
            .await
            .map_err(unavailable)?
        } else {
            if resume_at_ms.is_some() {
                return Err(AutomationError::Invalid);
            }
            let changed = sqlx::query(
                "UPDATE automation_tasks
                 SET state = 'disabled', next_run_at_ms = NULL, updated_at_ms = ?
                 WHERE task_id = ? AND owner_agent_id = ? AND state = 'enabled'",
            )
            .bind(to_i64(now_ms)?)
            .bind(task_id.to_string())
            .bind(self.owner_agent_id.as_str())
            .execute(&mut *transaction)
            .await
            .map_err(unavailable)?;
            if changed.rows_affected() == 1 {
                sqlx::query(
                    "UPDATE automation_runs
                     SET state = 'cancelled', lease_generation = NULL, lease_token = NULL,
                         lease_expires_at_ms = NULL
                     WHERE task_id = ? AND state = 'pending'",
                )
                .bind(task_id.to_string())
                .execute(&mut *transaction)
                .await
                .map_err(unavailable)?;
            }
            changed
        };
        if changed.rows_affected() != 1 {
            return Err(AutomationError::Conflict);
        }
        transaction.commit().await.map_err(unavailable)?;
        self.task(task_id).await?.ok_or(AutomationError::Corrupt)
    }

    /// Recover work held by an older Agent generation before admitting new
    /// work. A stale lease with a materialized TaskFlow boundary is first
    /// reconciled as provider-proven-absent; only then is the compatibility
    /// scheduler lease released. The caller must own the per-Agent writer lock.
    pub async fn recover_stale_generation(
        &self,
        current_generation: u64,
        now_ms: u64,
    ) -> Result<u64, AutomationError> {
        if current_generation == 0 {
            return Err(AutomationError::Invalid);
        }
        let rows = sqlx::query(
            "SELECT r.task_id, r.occurrence, r.schedule_revision, r.scheduled_for_ms,
                    r.client_user_message_id, r.lease_generation,
                    r.lease_token, r.lease_expires_at_ms
             FROM automation_runs r
             JOIN automation_tasks t ON t.task_id = r.task_id
             WHERE r.state = 'leased' AND r.lease_generation != ?
               AND t.owner_agent_id = ?
               AND NOT EXISTS (
                   SELECT 1 FROM automation_dispatch_outcomes o
                   WHERE o.task_id = r.task_id
                     AND o.occurrence = r.occurrence
                     AND o.outcome = 'uncertain'
               )
             ORDER BY r.task_id, r.occurrence",
        )
        .bind(to_i64(current_generation)?)
        .bind(self.owner_agent_id.as_str())
        .fetch_all(&self.pool)
        .await
        .map_err(unavailable)?;

        let mut recovered = 0_u64;
        for row in rows {
            let task_id = parse_task_id(&row, "task_id")?;
            let occurrence_number = to_u64(row.try_get("occurrence").map_err(unavailable)?)?;
            let task = self.task(task_id).await?.ok_or(AutomationError::Corrupt)?;
            let lease = AutomationLease {
                task: task.clone(),
                occurrence: occurrence_number,
                schedule_revision: to_u64(
                    row.try_get::<Option<i64>, _>("schedule_revision")
                        .map_err(unavailable)?
                        .ok_or(AutomationError::Corrupt)?,
                )?,
                scheduled_for_ms: to_u64(row.try_get("scheduled_for_ms").map_err(unavailable)?)?,
                client_user_message_id: row
                    .try_get("client_user_message_id")
                    .map_err(unavailable)?,
                lease_generation: to_u64(row.try_get("lease_generation").map_err(unavailable)?)?,
                lease_token: row.try_get("lease_token").map_err(unavailable)?,
                lease_expires_at_ms: to_u64(
                    row.try_get("lease_expires_at_ms").map_err(unavailable)?,
                )?,
            };

            if let Some(occurrence) = self
                .automation_occurrence(task_id, occurrence_number)
                .await?
            {
                if occurrence.state == crate::AutomationOccurrenceState::Claimed {
                    if occurrence.claim_generation != lease.lease_generation
                        || occurrence.claim_token != lease.lease_token
                        || occurrence.client_user_message_id != lease.client_user_message_id
                    {
                        return Err(AutomationError::Conflict);
                    }
                    let mut proof_bytes = b"hepta.automation.stale-before-provider.v1\0".to_vec();
                    proof_bytes.extend_from_slice(occurrence.occurrence_id.as_bytes());
                    proof_bytes.push(0);
                    proof_bytes.extend_from_slice(&lease.lease_generation.to_be_bytes());
                    proof_bytes.extend_from_slice(lease.lease_token.as_bytes());
                    let proof_digest = Sha256Digest::for_bytes(&proof_bytes);

                    let mut run = self
                        .taskflow_run(&occurrence.taskflow_run_id)
                        .await
                        .map_err(map_taskflow_mutation_error)?;
                    // A crash may happen after occurrence materialization but
                    // before a TaskFlow run exists, or after run creation but
                    // before it receives an owner tuple. In either case create/
                    // finish only the local durable intent under the exact old
                    // scheduler lease; this still performs no provider call.
                    if run.as_ref().is_none_or(|value| {
                        value.state == crate::TaskFlowRunState::Queued
                            && value.owner_id.is_none()
                            && value.owner_epoch.is_none()
                            && value.generation.is_none()
                            && value.fencing_token.is_none()
                    }) {
                        self.prepare_occurrence_taskflow(&occurrence, &lease, now_ms, 1)
                            .await
                            .map_err(map_taskflow_mutation_error)?;
                        run = self
                            .taskflow_run(&occurrence.taskflow_run_id)
                            .await
                            .map_err(map_taskflow_mutation_error)?;
                    }
                    if run.is_none() {
                        return Err(AutomationError::Corrupt);
                    }
                    if task.state == crate::AutomationTaskState::Enabled {
                        self.requeue_occurrence_taskflow_after_proven_absence(
                            &occurrence,
                            &proof_digest,
                            now_ms,
                        )
                        .await
                        .map_err(map_taskflow_mutation_error)?;
                    } else {
                        self.cancel_claimed_taskflow_after_proven_absence(
                            &occurrence,
                            &proof_digest,
                            now_ms,
                        )
                        .await
                        .map_err(map_taskflow_mutation_error)?;
                        self.complete_occurrence(
                            task_id,
                            occurrence_number,
                            crate::AutomationOccurrenceTerminalState::Cancelled,
                            &proof_digest,
                            now_ms,
                        )
                        .await?;
                    }
                } else if occurrence.state != crate::AutomationOccurrenceState::Cancelled {
                    return Err(AutomationError::Conflict);
                }
            }
            self.release_for_retry(&lease).await?;
            recovered = recovered.checked_add(1).ok_or(AutomationError::Corrupt)?;
        }
        Ok(recovered)
    }

    pub async fn claim_due(
        &self,
        now_ms: u64,
        generation: u64,
        lease_duration_ms: u64,
    ) -> Result<Option<AutomationLease>, AutomationError> {
        if generation == 0 || lease_duration_ms == 0 {
            return Err(AutomationError::Invalid);
        }
        let lease_expires_at_ms = now_ms
            .checked_add(lease_duration_ms)
            .ok_or(AutomationError::Invalid)?;
        let (mut transaction, phase) = self.begin_timer_write().await?;
        if phase != crate::TimerPhase::Active {
            return Ok(None);
        }

        let reclaim = sqlx::query(
            "SELECT r.task_id, r.occurrence, r.schedule_revision,
                    r.scheduled_for_ms, r.client_user_message_id
             FROM automation_runs r
             JOIN automation_tasks t ON t.task_id = r.task_id
             WHERE t.owner_agent_id = ? AND t.state = 'enabled'
               AND (r.state = 'pending'
                    OR (r.state = 'leased' AND r.lease_expires_at_ms <= ?))
               AND NOT EXISTS (
                   SELECT 1 FROM automation_dispatch_outcomes o
                   WHERE o.task_id = r.task_id AND o.occurrence = r.occurrence
                     AND o.outcome = 'uncertain'
               )
             ORDER BY r.scheduled_for_ms, r.task_id, r.occurrence LIMIT 1",
        )
        .bind(self.owner_agent_id.as_str())
        .bind(to_i64(now_ms)?)
        .fetch_optional(&mut *transaction)
        .await
        .map_err(unavailable)?;

        let (task_id, occurrence, schedule_revision, scheduled_for_ms, client_id) =
            if let Some(row) = reclaim {
                let task_id = AutomationTaskId::parse(
                    &row.try_get::<String, _>("task_id").map_err(unavailable)?,
                )
                .map_err(|_| AutomationError::Corrupt)?;
                (
                    task_id,
                    to_u64(row.try_get("occurrence").map_err(unavailable)?)?,
                    to_u64(
                        row.try_get::<Option<i64>, _>("schedule_revision")
                            .map_err(unavailable)?
                            .ok_or(AutomationError::Corrupt)?,
                    )?,
                    to_u64(row.try_get("scheduled_for_ms").map_err(unavailable)?)?,
                    row.try_get("client_user_message_id").map_err(unavailable)?,
                )
            } else {
                let row = sqlx::query(
                    "SELECT t.task_id, t.next_occurrence, t.next_run_at_ms,
                        m.revision AS schedule_revision
                 FROM automation_tasks t
                 JOIN automation_schedule_metadata m
                   ON m.task_id = t.task_id AND m.owner_agent_id = t.owner_agent_id
                 WHERE t.owner_agent_id = ? AND t.state = 'enabled'
                   AND t.next_run_at_ms IS NOT NULL AND t.next_run_at_ms <= ?
                   AND NOT EXISTS (
                       SELECT 1 FROM automation_runs r
                       WHERE r.task_id = t.task_id AND r.state IN ('pending', 'leased')
                   )
                 ORDER BY t.next_run_at_ms, t.task_id LIMIT 1",
                )
                .bind(self.owner_agent_id.as_str())
                .bind(to_i64(now_ms)?)
                .fetch_optional(&mut *transaction)
                .await
                .map_err(unavailable)?;
                let Some(row) = row else {
                    transaction.commit().await.map_err(unavailable)?;
                    return Ok(None);
                };
                let task_id = AutomationTaskId::parse(
                    &row.try_get::<String, _>("task_id").map_err(unavailable)?,
                )
                .map_err(|_| AutomationError::Corrupt)?;
                let occurrence = to_u64(row.try_get("next_occurrence").map_err(unavailable)?)?;
                let schedule_revision =
                    to_u64(row.try_get("schedule_revision").map_err(unavailable)?)?;
                let scheduled_for_ms = to_u64(row.try_get("next_run_at_ms").map_err(unavailable)?)?;
                let client_id = client_message_id(&self.owner_agent_id, task_id, occurrence);
                sqlx::query(
                    "INSERT INTO automation_runs (
                    task_id, occurrence, schedule_revision, scheduled_for_ms,
                    client_user_message_id, state
                 ) VALUES (?, ?, ?, ?, ?, 'pending')",
                )
                .bind(task_id.to_string())
                .bind(to_i64(occurrence)?)
                .bind(to_i64(schedule_revision)?)
                .bind(to_i64(scheduled_for_ms)?)
                .bind(&client_id)
                .execute(&mut *transaction)
                .await
                .map_err(unavailable)?;
                let advanced = sqlx::query(
                    "UPDATE automation_tasks SET next_occurrence = next_occurrence + 1
                 WHERE task_id = ? AND next_occurrence = ?",
                )
                .bind(task_id.to_string())
                .bind(to_i64(occurrence)?)
                .execute(&mut *transaction)
                .await
                .map_err(unavailable)?;
                if advanced.rows_affected() != 1 {
                    return Err(AutomationError::Conflict);
                }
                (
                    task_id,
                    occurrence,
                    schedule_revision,
                    scheduled_for_ms,
                    client_id,
                )
            };

        let lease_token = uuid::Uuid::now_v7().to_string();
        let leased = sqlx::query(
            "UPDATE automation_runs
             SET state = 'leased', lease_generation = ?, lease_token = ?, lease_expires_at_ms = ?
             WHERE task_id = ? AND occurrence = ?
               AND (state = 'pending' OR (state = 'leased' AND lease_expires_at_ms <= ?))",
        )
        .bind(to_i64(generation)?)
        .bind(&lease_token)
        .bind(to_i64(lease_expires_at_ms)?)
        .bind(task_id.to_string())
        .bind(to_i64(occurrence)?)
        .bind(to_i64(now_ms)?)
        .execute(&mut *transaction)
        .await
        .map_err(unavailable)?;
        if leased.rows_affected() != 1 {
            return Err(AutomationError::Conflict);
        }
        let task_row = sqlx::query(TASK_SELECT_BY_ID)
            .bind(task_id.to_string())
            .fetch_one(&mut *transaction)
            .await
            .map_err(unavailable)?;
        let task = task_from_row(&task_row, &self.owner_agent_id)?;
        transaction.commit().await.map_err(unavailable)?;
        Ok(Some(AutomationLease {
            task,
            occurrence,
            schedule_revision,
            scheduled_for_ms,
            client_user_message_id: client_id,
            lease_generation: generation,
            lease_token,
            lease_expires_at_ms,
        }))
    }

    /// Records a dispatch intent before (or immediately after) crossing the
    /// provider seam when the terminal outcome cannot be determined.
    ///
    /// The occurrence remains leased and is excluded from both stale-generation
    /// recovery and automatic retry.  This is the durable boundary that keeps
    /// a lost provider response from becoming an unbounded duplicate stream.
    pub async fn record_dispatch_uncertain(
        &self,
        lease: &AutomationLease,
        observed_at_ms: u64,
    ) -> Result<(), AutomationError> {
        if lease.task.owner_agent_id != self.owner_agent_id {
            return Err(AutomationError::AccessDenied);
        }
        let (mut transaction, _) = self.begin_timer_write().await?;
        let updated = sqlx::query(
            "UPDATE automation_runs
             SET state = 'leased'
             WHERE task_id = ? AND occurrence = ? AND state = 'leased'
               AND lease_generation = ? AND lease_token = ?
               AND client_user_message_id = ?",
        )
        .bind(lease.task.task_id.to_string())
        .bind(to_i64(lease.occurrence)?)
        .bind(to_i64(lease.lease_generation)?)
        .bind(&lease.lease_token)
        .bind(&lease.client_user_message_id)
        .execute(&mut *transaction)
        .await
        .map_err(unavailable)?;
        if updated.rows_affected() != 1 {
            return Err(AutomationError::Conflict);
        }
        verify_claimed_dispatch_boundary_tx(&mut transaction, self, lease).await?;

        let existing = sqlx::query(
            "SELECT outcome FROM automation_dispatch_outcomes
             WHERE task_id = ? AND occurrence = ?",
        )
        .bind(lease.task.task_id.to_string())
        .bind(to_i64(lease.occurrence)?)
        .fetch_optional(&mut *transaction)
        .await
        .map_err(unavailable)?;
        match existing {
            Some(row) => {
                let outcome: String = row.try_get("outcome").map_err(unavailable)?;
                if outcome != "uncertain" {
                    return Err(AutomationError::Conflict);
                }
                sqlx::query(
                    "UPDATE automation_dispatch_outcomes SET observed_at_ms = ?
                     WHERE task_id = ? AND occurrence = ? AND outcome = 'uncertain'",
                )
                .bind(to_i64(observed_at_ms)?)
                .bind(lease.task.task_id.to_string())
                .bind(to_i64(lease.occurrence)?)
                .execute(&mut *transaction)
                .await
                .map_err(unavailable)?;
            }
            None => {
                sqlx::query(
                    "INSERT INTO automation_dispatch_outcomes (
                         task_id, occurrence, client_user_message_id, outcome, observed_at_ms
                     ) VALUES (?, ?, ?, 'uncertain', ?)",
                )
                .bind(lease.task.task_id.to_string())
                .bind(to_i64(lease.occurrence)?)
                .bind(&lease.client_user_message_id)
                .bind(to_i64(observed_at_ms)?)
                .execute(&mut *transaction)
                .await
                .map_err(|error| {
                    if is_constraint(&error) {
                        AutomationError::Conflict
                    } else {
                        unavailable(error)
                    }
                })?;
            }
        }
        transaction.commit().await.map_err(unavailable)
    }

    /// Aborts an intent only when the queue implementation has proved that the
    /// request failed before the external admission seam.  The uncertainty
    /// row and lease are removed in one transaction so a retry cannot race a
    /// crash between the two local updates.
    pub(crate) async fn abort_dispatch_before_admission(
        &self,
        lease: &AutomationLease,
        observed_at_ms: u64,
    ) -> Result<(), AutomationError> {
        if lease.task.owner_agent_id != self.owner_agent_id {
            return Err(AutomationError::AccessDenied);
        }
        let occurrence = self
            .automation_occurrence(lease.task.task_id, lease.occurrence)
            .await?
            .ok_or(AutomationError::Conflict)?;
        if occurrence.state != crate::AutomationOccurrenceState::Claimed
            || occurrence.claim_generation != lease.lease_generation
            || occurrence.claim_token != lease.lease_token
            || occurrence.client_user_message_id != lease.client_user_message_id
        {
            return Err(AutomationError::Conflict);
        }

        // The queue implementation has explicitly proved that provider contact
        // did not occur. Feed that proof through the same durable absence
        // reconciler used after process loss so both enabled retries and
        // concurrently retired schedules converge through one causal path.
        let mut proof_bytes = b"hepta.automation.before-admission.v1\0".to_vec();
        proof_bytes.extend_from_slice(occurrence.occurrence_id.as_bytes());
        proof_bytes.push(0);
        proof_bytes.extend_from_slice(&lease.lease_generation.to_be_bytes());
        proof_bytes.extend_from_slice(lease.lease_token.as_bytes());
        let proof_digest = Sha256Digest::for_bytes(&proof_bytes);
        self.reconcile_uncertain_occurrence_absent(
            lease.task.task_id,
            lease.occurrence,
            &lease.client_user_message_id,
            &proof_digest,
            observed_at_ms,
        )
        .await
    }

    /// Reconciles an uncertain occurrence after an external/provider-specific
    /// lookup returns a durable queue receipt.  This method only proves local
    /// terminalization and client-id fencing; it makes no physical provider
    /// exactly-once claim.
    #[deprecated(
        note = "use reconcile_uncertain_occurrence_admitted; legacy reconciliation cannot bypass the durable occurrence/TaskFlow chain"
    )]
    pub async fn reconcile_dispatch(
        &self,
        task_id: AutomationTaskId,
        occurrence: u64,
        receipt: &AutomationQueueReceipt,
        submitted_at_ms: u64,
    ) -> Result<AutomationTask, AutomationError> {
        match self
            .reconcile_uncertain_occurrence_admitted(task_id, occurrence, receipt, submitted_at_ms)
            .await
        {
            Ok(_) => self.task(task_id).await?.ok_or(AutomationError::Corrupt),
            Err(AutomationError::Conflict) => {
                // Preserve the old idempotent receipt-replay contract without
                // reintroducing its schedule-advancement bypass. A replay is
                // read-only and succeeds only for the exact already-committed
                // client/submission identity.
                let exact: i64 = sqlx::query_scalar(
                    "SELECT EXISTS(
                        SELECT 1
                        FROM automation_runs r
                        JOIN automation_dispatch_outcomes d
                          ON d.task_id = r.task_id AND d.occurrence = r.occurrence
                        JOIN automation_tasks t ON t.task_id = r.task_id
                        WHERE r.task_id = ? AND r.occurrence = ?
                          AND t.owner_agent_id = ?
                          AND r.state = 'submitted' AND d.outcome = 'submitted'
                          AND r.client_user_message_id = ?
                          AND d.client_user_message_id = r.client_user_message_id
                          AND r.queued_submission_id = ?
                          AND d.queued_submission_id = r.queued_submission_id
                    )",
                )
                .bind(task_id.to_string())
                .bind(to_i64(occurrence)?)
                .bind(self.owner_agent_id.as_str())
                .bind(&receipt.client_user_message_id)
                .bind(&receipt.queued_submission_id)
                .fetch_one(&self.pool)
                .await
                .map_err(unavailable)?;
                if exact != 1 {
                    return Err(AutomationError::Conflict);
                }
                self.task(task_id).await?.ok_or(AutomationError::Corrupt)
            }
            Err(error) => Err(error),
        }
    }

    /// Releases an uncertain occurrence only after an external check proves
    /// that the provider did not accept it.  The same client id is retained
    /// when the occurrence is claimed again.
    pub(crate) async fn release_uncertain_for_retry(
        &self,
        task_id: AutomationTaskId,
        occurrence: u64,
        client_user_message_id: &str,
    ) -> Result<(), AutomationError> {
        let (mut transaction, _) = self.begin_timer_write().await?;
        let row = sqlx::query(
            "SELECT r.state, r.client_user_message_id, t.state AS task_state,
                    d.outcome AS dispatch_outcome
             FROM automation_runs r
             JOIN automation_tasks t ON t.task_id = r.task_id
             LEFT JOIN automation_dispatch_outcomes d
               ON d.task_id = r.task_id AND d.occurrence = r.occurrence
             WHERE r.task_id = ? AND r.occurrence = ?
               AND t.owner_agent_id = ?",
        )
        .bind(task_id.to_string())
        .bind(to_i64(occurrence)?)
        .bind(self.owner_agent_id.as_str())
        .fetch_optional(&mut *transaction)
        .await
        .map_err(unavailable)?
        .ok_or(AutomationError::Conflict)?;
        let run_state: String = row.try_get("state").map_err(unavailable)?;
        let run_client_id: String = row.try_get("client_user_message_id").map_err(unavailable)?;
        let task_state: String = row.try_get("task_state").map_err(unavailable)?;
        let dispatch_outcome: Option<String> =
            row.try_get("dispatch_outcome").map_err(unavailable)?;
        if run_client_id != client_user_message_id {
            return Err(AutomationError::Conflict);
        }
        let released_state = if task_state == "enabled" {
            "pending"
        } else {
            "cancelled"
        };

        // Phase-2 cleanup is exact-idempotent. A crash after clearing the
        // uncertainty row but before the reconciler acknowledgement may replay
        // only the same stable client identity and resulting run state.
        if run_state == released_state && dispatch_outcome.is_none() {
            transaction.commit().await.map_err(unavailable)?;
            return Ok(());
        }
        if run_state != "leased" || dispatch_outcome.as_deref() != Some("uncertain") {
            return Err(AutomationError::Conflict);
        }

        let updated = sqlx::query(
            "UPDATE automation_runs
             SET state = ?, lease_generation = NULL, lease_token = NULL,
                 lease_expires_at_ms = NULL
             WHERE task_id = ? AND occurrence = ? AND state = 'leased'
               AND client_user_message_id = ?",
        )
        .bind(released_state)
        .bind(task_id.to_string())
        .bind(to_i64(occurrence)?)
        .bind(client_user_message_id)
        .execute(&mut *transaction)
        .await
        .map_err(unavailable)?;
        if updated.rows_affected() != 1 {
            return Err(AutomationError::Conflict);
        }
        let deleted = sqlx::query(
            "DELETE FROM automation_dispatch_outcomes
             WHERE task_id = ? AND occurrence = ? AND outcome = 'uncertain'
               AND client_user_message_id = ?",
        )
        .bind(task_id.to_string())
        .bind(to_i64(occurrence)?)
        .bind(client_user_message_id)
        .execute(&mut *transaction)
        .await
        .map_err(unavailable)?;
        if deleted.rows_affected() != 1 {
            return Err(AutomationError::Conflict);
        }
        transaction.commit().await.map_err(unavailable)
    }

    #[deprecated(
        note = "use AutomationScheduler/record_occurrence_admitted; direct queue admission is rejected unless the durable occurrence and claimed TaskFlow intent already exist"
    )]
    pub async fn mark_submitted(
        &self,
        lease: &AutomationLease,
        receipt: &AutomationQueueReceipt,
        submitted_at_ms: u64,
    ) -> Result<AutomationTask, AutomationError> {
        self.record_occurrence_admitted(lease, receipt, submitted_at_ms)
            .await?;
        self.task(lease.task.task_id)
            .await?
            .ok_or(AutomationError::Corrupt)
    }

    pub async fn release_for_retry(&self, lease: &AutomationLease) -> Result<(), AutomationError> {
        if lease.task.owner_agent_id != self.owner_agent_id {
            return Err(AutomationError::AccessDenied);
        }
        let (mut transaction, _) = self.begin_timer_write().await?;
        let updated = sqlx::query(
            "UPDATE automation_runs
             SET state = CASE WHEN EXISTS (
                     SELECT 1 FROM automation_tasks t
                     WHERE t.task_id = automation_runs.task_id AND t.state = 'enabled'
                 ) THEN 'pending' ELSE 'cancelled' END,
                 lease_generation = NULL, lease_token = NULL, lease_expires_at_ms = NULL
             WHERE task_id = ? AND occurrence = ? AND state = 'leased'
               AND lease_generation = ? AND lease_token = ?
               AND client_user_message_id = ?
               AND NOT EXISTS (
                   SELECT 1 FROM automation_dispatch_outcomes o
                   WHERE o.task_id = automation_runs.task_id
                     AND o.occurrence = automation_runs.occurrence
               )
               AND (
                   NOT EXISTS (
                       SELECT 1 FROM automation_occurrence_lifecycle l
                       WHERE l.task_id = automation_runs.task_id
                         AND l.occurrence = automation_runs.occurrence
                   )
                   OR EXISTS (
                       SELECT 1
                       FROM automation_occurrence_lifecycle l
                       JOIN taskflow_runs tf
                         ON tf.owner_agent_id = l.owner_agent_id
                        AND tf.run_id = l.taskflow_run_id
                       WHERE l.task_id = automation_runs.task_id
                         AND l.occurrence = automation_runs.occurrence
                         AND (
                             (l.state = 'claimed' AND tf.state = 'queued')
                             OR l.state = 'cancelled'
                         )
                   )
               )",
        )
        .bind(lease.task.task_id.to_string())
        .bind(to_i64(lease.occurrence)?)
        .bind(to_i64(lease.lease_generation)?)
        .bind(&lease.lease_token)
        .bind(&lease.client_user_message_id)
        .execute(&mut *transaction)
        .await
        .map_err(unavailable)?;
        if updated.rows_affected() != 1 {
            return Err(AutomationError::Conflict);
        }
        transaction.commit().await.map_err(unavailable)
    }
}

pub(crate) async fn verify_claimed_dispatch_boundary_tx(
    transaction: &mut sqlx::Transaction<'_, sqlx::Sqlite>,
    store: &AutomationStore,
    lease: &AutomationLease,
) -> Result<(), AutomationError> {
    let row = sqlx::query(
        "SELECT o.taskflow_run_id, o.step_attempt, o.claim_generation, o.claim_token,
                s.event_kind, s.owner_id, s.owner_epoch, s.fencing_token
         FROM automation_occurrence_lifecycle o
         JOIN taskflow_step_outbox s
           ON s.owner_agent_id = o.owner_agent_id
          AND s.run_id = o.taskflow_run_id
          AND s.step_id = 'codex_turn'
          AND s.attempt = o.step_attempt
         WHERE o.task_id = ? AND o.occurrence = ?
           AND o.owner_agent_id = ? AND o.state = 'claimed'
           AND o.client_user_message_id = ?
           AND o.claim_generation = ? AND o.claim_token = ?
           AND s.event_seq = (
               SELECT MAX(s2.event_seq)
               FROM taskflow_step_outbox s2
               WHERE s2.owner_agent_id = s.owner_agent_id
                 AND s2.run_id = s.run_id
                 AND s2.step_id = s.step_id
                 AND s2.attempt = s.attempt
           )",
    )
    .bind(lease.task.task_id.to_string())
    .bind(to_i64(lease.occurrence)?)
    .bind(store.owner_agent_id.as_str())
    .bind(&lease.client_user_message_id)
    .bind(to_i64(lease.lease_generation)?)
    .bind(&lease.lease_token)
    .fetch_optional(&mut **transaction)
    .await
    .map_err(unavailable)?
    .ok_or(AutomationError::Conflict)?;
    let event_kind: String = row.try_get("event_kind").map_err(unavailable)?;
    let owner_id: String = row.try_get("owner_id").map_err(unavailable)?;
    let owner_epoch = to_u64(row.try_get("owner_epoch").map_err(unavailable)?)?;
    let fencing_token: String = row.try_get("fencing_token").map_err(unavailable)?;
    if event_kind != "claimed"
        || owner_id != format!("automation.scheduler:{}", lease.task.task_id)
        || owner_epoch != lease.lease_generation
        || fencing_token != lease.lease_token
    {
        return Err(AutomationError::Conflict);
    }
    Ok(())
}

const TASK_SELECT_BY_ID: &str =
    "SELECT task_id, owner_agent_id, thread_id, prompt, schedule_kind, interval_ms,
            state, next_run_at_ms, next_occurrence, created_at_ms, updated_at_ms
     FROM automation_tasks WHERE task_id = ?";

fn task_from_row(
    row: &sqlx::sqlite::SqliteRow,
    expected_owner: &AgentId,
) -> Result<AutomationTask, AutomationError> {
    let owner = AgentId::parse(
        row.try_get::<String, _>("owner_agent_id")
            .map_err(unavailable)?,
    )
    .map_err(|_| AutomationError::Corrupt)?;
    if &owner != expected_owner {
        return Err(AutomationError::AccessDenied);
    }
    let task_id =
        AutomationTaskId::parse(&row.try_get::<String, _>("task_id").map_err(unavailable)?)
            .map_err(|_| AutomationError::Corrupt)?;
    let kind: String = row.try_get("schedule_kind").map_err(unavailable)?;
    let interval: Option<i64> = row.try_get("interval_ms").map_err(unavailable)?;
    let schedule = match (kind.as_str(), interval) {
        ("once", None) => AutomationSchedule::Once,
        ("fixed_interval", Some(interval)) => AutomationSchedule::FixedInterval {
            interval_ms: to_u64(interval)?,
        },
        _ => return Err(AutomationError::Corrupt),
    };
    schedule.validate().map_err(|_| AutomationError::Corrupt)?;
    Ok(AutomationTask {
        task_id,
        owner_agent_id: owner,
        thread_id: row.try_get("thread_id").map_err(unavailable)?,
        prompt: row.try_get("prompt").map_err(unavailable)?,
        schedule,
        state: AutomationTaskState::parse(
            &row.try_get::<String, _>("state").map_err(unavailable)?,
        )?,
        next_run_at_ms: row
            .try_get::<Option<i64>, _>("next_run_at_ms")
            .map_err(unavailable)?
            .map(to_u64)
            .transpose()?,
        next_occurrence: to_u64(row.try_get("next_occurrence").map_err(unavailable)?)?,
        created_at_ms: to_u64(row.try_get("created_at_ms").map_err(unavailable)?)?,
        updated_at_ms: to_u64(row.try_get("updated_at_ms").map_err(unavailable)?)?,
    })
}

fn schedule_columns(
    schedule: AutomationSchedule,
) -> Result<(&'static str, Option<u64>), AutomationError> {
    schedule.validate()?;
    Ok(match schedule {
        AutomationSchedule::Once => ("once", None),
        AutomationSchedule::FixedInterval { interval_ms } => ("fixed_interval", Some(interval_ms)),
    })
}

async fn verify_store(pool: &SqlitePool, owner_agent_id: &AgentId) -> Result<(), AutomationError> {
    let quick_check = sqlx::query_scalar::<_, String>("PRAGMA quick_check(1)")
        .fetch_all(pool)
        .await
        .map_err(unavailable)?;
    if quick_check != ["ok"] {
        return Err(AutomationError::Corrupt);
    }
    if !sqlx::query("PRAGMA foreign_key_check")
        .fetch_all(pool)
        .await
        .map_err(unavailable)?
        .is_empty()
    {
        return Err(AutomationError::Corrupt);
    }
    let row = sqlx::query(
        "SELECT schema_version, owner_agent_id FROM automation_meta WHERE singleton = 1",
    )
    .fetch_one(pool)
    .await
    .map_err(unavailable)?;
    let schema: i64 = row.try_get("schema_version").map_err(unavailable)?;
    let owner: String = row.try_get("owner_agent_id").map_err(unavailable)?;
    if schema != i64::from(AUTOMATION_SCHEMA_VERSION) {
        return Err(AutomationError::Corrupt);
    }
    if owner != owner_agent_id.as_str() {
        return Err(AutomationError::AccessDenied);
    }
    let foreign: i64 =
        sqlx::query_scalar("SELECT COUNT(*) FROM automation_tasks WHERE owner_agent_id != ?")
            .bind(owner_agent_id.as_str())
            .fetch_one(pool)
            .await
            .map_err(unavailable)?;
    if foreign != 0 {
        return Err(AutomationError::AccessDenied);
    }
    let invalid_outcomes: i64 = sqlx::query_scalar(
        "SELECT COUNT(*)
         FROM automation_dispatch_outcomes o
         LEFT JOIN automation_runs r
           ON r.task_id = o.task_id AND r.occurrence = o.occurrence
         JOIN automation_tasks t ON t.task_id = o.task_id
         WHERE t.owner_agent_id = ?
           AND (r.task_id IS NULL
                OR (o.outcome = 'uncertain' AND r.state != 'leased')
                OR (o.outcome = 'submitted' AND r.state != 'submitted')
                OR o.client_user_message_id != r.client_user_message_id
                OR (o.outcome = 'submitted' AND (
                    o.queued_submission_id IS NULL
                    OR o.queued_submission_id IS NOT r.queued_submission_id
                    OR o.submitted_at_ms IS NOT r.submitted_at_ms
                )))",
    )
    .bind(owner_agent_id.as_str())
    .fetch_one(pool)
    .await
    .map_err(unavailable)?;
    if invalid_outcomes != 0 {
        return Err(AutomationError::Corrupt);
    }
    let invalid_legacy_reconciliations: i64 = sqlx::query_scalar(
        "SELECT COUNT(*)
         FROM automation_legacy_dispatch_reconciliations l
         LEFT JOIN automation_runs r
           ON r.task_id = l.task_id AND r.occurrence = l.occurrence
         LEFT JOIN automation_tasks t ON t.task_id = l.task_id
         WHERE t.owner_agent_id IS NULL
            OR t.owner_agent_id != ?
            OR r.task_id IS NULL
            OR r.schedule_revision IS NOT NULL
            OR r.state != 'cancelled'
            OR r.client_user_message_id != l.client_user_message_id
            OR EXISTS (
                SELECT 1 FROM automation_dispatch_outcomes d
                WHERE d.task_id = l.task_id AND d.occurrence = l.occurrence
            )
            OR EXISTS (
                SELECT 1 FROM automation_occurrence_lifecycle o
                WHERE o.task_id = l.task_id AND o.occurrence = l.occurrence
            )",
    )
    .bind(owner_agent_id.as_str())
    .fetch_one(pool)
    .await
    .map_err(unavailable)?;
    if invalid_legacy_reconciliations != 0 {
        return Err(AutomationError::Corrupt);
    }
    crate::lifecycle::verify_occurrence_store(pool, owner_agent_id.as_str()).await?;
    verify_taskflow_store(pool, owner_agent_id)
        .await
        .map_err(map_taskflow_verify_error)?;
    Ok(())
}

fn map_taskflow_mutation_error(error: TaskFlowError) -> AutomationError {
    match error {
        TaskFlowError::Invalid(_) => AutomationError::Invalid,
        TaskFlowError::StaleFence
        | TaskFlowError::Conflict(_)
        | TaskFlowError::InvalidTransition(_) => AutomationError::Conflict,
        TaskFlowError::Corrupt(_) => AutomationError::Corrupt,
        TaskFlowError::Unavailable => AutomationError::Unavailable,
    }
}

fn map_taskflow_verify_error(error: TaskFlowError) -> AutomationError {
    match error {
        TaskFlowError::Unavailable => AutomationError::Unavailable,
        TaskFlowError::StaleFence => AutomationError::AccessDenied,
        TaskFlowError::Invalid(_)
        | TaskFlowError::Conflict(_)
        | TaskFlowError::Corrupt(_)
        | TaskFlowError::InvalidTransition(_) => AutomationError::Corrupt,
    }
}

fn is_constraint(error: &sqlx::Error) -> bool {
    matches!(error, sqlx::Error::Database(database) if database.is_unique_violation())
}

fn to_i64(value: u64) -> Result<i64, AutomationError> {
    i64::try_from(value).map_err(|_| AutomationError::Invalid)
}

fn to_u64(value: i64) -> Result<u64, AutomationError> {
    u64::try_from(value).map_err(|_| AutomationError::Corrupt)
}

fn parse_task_id(
    row: &sqlx::sqlite::SqliteRow,
    column: &str,
) -> Result<AutomationTaskId, AutomationError> {
    AutomationTaskId::parse(&row.try_get::<String, _>(column).map_err(unavailable)?)
        .map_err(|_| AutomationError::Corrupt)
}

fn unavailable(_error: impl std::fmt::Display) -> AutomationError {
    AutomationError::Unavailable
}

fn create_private_directory(path: &Path) -> Result<(), AutomationError> {
    fs::create_dir_all(path).map_err(unavailable)?;
    if path.canonicalize().map_err(unavailable)? != path {
        return Err(AutomationError::Invalid);
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(path, fs::Permissions::from_mode(0o700)).map_err(unavailable)?;
    }
    Ok(())
}

fn protect_database_file(_path: &Path) -> Result<(), AutomationError> {
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(_path, fs::Permissions::from_mode(0o600)).map_err(unavailable)?;
    }
    Ok(())
}

/// Preserve the two independently applied v4/v5 histories after their source
/// imports collided. Only exact original checksums can move to versions 17/18.
/// This transaction changes migration identities, never their SQL, checksums,
/// timestamps or product data. Unknown/dirty/duplicate histories fail closed.
async fn reconcile_legacy_migration_ids(pool: &SqlitePool) -> Result<(), AutomationError> {
    let mut transaction = pool
        .begin_with("BEGIN IMMEDIATE")
        .await
        .map_err(unavailable)?;
    let exists: i64 = sqlx::query_scalar(
        "SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = '_sqlx_migrations'",
    )
    .fetch_one(&mut *transaction)
    .await
    .map_err(unavailable)?;
    if exists == 0 {
        transaction.commit().await.map_err(unavailable)?;
        return Ok(());
    }
    let maximum = MIGRATOR.iter().count() + 2;
    let rows = sqlx::query(
        "SELECT version, checksum, success FROM _sqlx_migrations ORDER BY version LIMIT ?",
    )
    .bind(i64::try_from(maximum + 1).map_err(|_| AutomationError::Corrupt)?)
    .fetch_all(&mut *transaction)
    .await
    .map_err(unavailable)?;
    if rows.len() > maximum {
        return Err(AutomationError::Corrupt);
    }
    let mut remaps = Vec::new();
    for row in &rows {
        let version: i64 = row.try_get("version").map_err(unavailable)?;
        let checksum: Vec<u8> = row.try_get("checksum").map_err(unavailable)?;
        let success: bool = row.try_get("success").map_err(unavailable)?;
        if !success {
            return Err(AutomationError::Corrupt);
        }
        if MIGRATOR.iter().any(|migration| {
            migration.version == version && migration.checksum.as_ref() == checksum.as_slice()
        }) {
            continue;
        }
        let relocated = match version {
            4 => 17,
            5 => 18,
            _ => return Err(AutomationError::Corrupt),
        };
        if !MIGRATOR.iter().any(|migration| {
            migration.version == relocated && migration.checksum.as_ref() == checksum.as_slice()
        }) || rows
            .iter()
            .any(|row| row.get::<i64, _>("version") == relocated)
        {
            return Err(AutomationError::Corrupt);
        }
        remaps.push((version, relocated, checksum));
    }
    for (version, relocated, checksum) in remaps {
        let updated = sqlx::query(
            "UPDATE _sqlx_migrations SET version = ? WHERE version = ? AND checksum = ? AND success = 1",
        )
        .bind(relocated)
        .bind(version)
        .bind(checksum)
        .execute(&mut *transaction)
        .await
        .map_err(unavailable)?;
        if updated.rows_affected() != 1 {
            return Err(AutomationError::Corrupt);
        }
    }
    transaction.commit().await.map_err(unavailable)
}

#[cfg(test)]
#[path = "migration_convergence_tests.rs"]
mod migration_convergence_tests;
