"""Check a floating expectation assertion without changing model calculations."""
import contextlib
import hashlib
import importlib
import io
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np
import scipy

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'replay'))
name = 'tools.hcsn.continuation_r15_20261101.test_attainability'
path = root / 'replay/tools/hcsn/continuation_r15_20261101/test_attainability.py'
original = (root / 'original/test_attainability.py').read_bytes()
old = '        self.assertEqual((result["first_action"], result["reads"], result["resets"]), ("RESET", 1., 1.))'
new = '''        self.assertEqual(result["first_action"], "RESET")
        # These are floating expectations after matrix products, not integer counts.
        np.testing.assert_allclose([result["reads"], result["resets"]], [1., 1.],
                                   rtol=0, atol=16 * np.finfo(np.float64).eps)'''
assert original.decode().count(old) == 1
patched = original.decode().replace(old, new).encode()
rows = []


def run_case(version, perturb=False, corrupt=None):
    path.write_bytes(original if version == 'original' else patched)
    sys.modules.pop(name, None)
    module = importlib.import_module(name)
    transition = module.ToyWorld.transition
    evaluator = module.exact_episode
    def altered_transition(world, dt):
        matrix = transition(world, dt)
        # Exercise one-ULP differences permitted by the existing matrix contract.
        return np.nextafter(matrix, np.inf) if np.any(world.Q) else matrix
    def altered_result(*args, **kwargs):
        result = evaluator(*args, **kwargs)
        result[corrupt] = 'READ' if corrupt == 'first_action' else result[corrupt] + 1e-12
        return result
    suite = unittest.defaultTestLoader.loadTestsFromModule(module)
    if corrupt:
        suite = unittest.TestSuite([module.AttainabilityTests(
            'test_forward_mass_matches_direct_latent_paths_and_backward_alpha')])
    stream = io.StringIO()
    with contextlib.ExitStack() as stack:
        if perturb:
            stack.enter_context(patch.object(module.ToyWorld, 'transition', altered_transition))
        if corrupt:
            stack.enter_context(patch.object(module, 'exact_episode', altered_result))
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    row = dict(version=version, one_ulp_matrix_perturbation=perturb,
               corrupt_result_field=corrupt, tests=result.testsRun,
               failures=len(result.failures), errors=len(result.errors),
               success=result.wasSuccessful(), log=stream.getvalue())
    rows.append(row)
    return row


assert run_case('original')['success']
old_ulp = run_case('original', perturb=True)
assert old_ulp['tests'] == 6 and old_ulp['failures'] == 1 and old_ulp['errors'] == 0
assert run_case('patched')['success']
assert run_case('patched', perturb=True)['success']
for field in ['reads', 'resets', 'first_action']:
    negative = run_case('patched', corrupt=field)
    assert negative['tests'] == 1 and negative['failures'] == 1 and negative['errors'] == 0
path.write_bytes(patched)
report = dict(schema='hcsn.expectation-roundoff-regression.v1',
              source_head='e2252649e6bfc390c60e041a76e50dd94332bbdb',
              original_test_sha256=hashlib.sha256(original).hexdigest(),
              patched_test_sha256=hashlib.sha256(patched).hexdigest(),
              numpy=np.__version__, scipy=scipy.__version__, python=sys.version,
              source_files={str(p.relative_to(root / 'replay')):hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in sorted((root / 'replay').rglob('*.py'))},
              float64_count_atol=16*np.finfo(np.float64).eps,
              algorithm_changed=False, scientific_acceptance_changed=False,
              original_remote_job=124930433301,
              original_remote_reads=1.0000000000000002,
              original_local_failure_reproduced_without_perturbation=False,
              scope='A one-ULP allowed matrix perturbation is a portability control, not a reconstruction of runner internals.',
              limitation='Complete finite enumeration uses floating matrices and is not interval certification.',
              cases=rows, all_expected_outcomes_observed=True)
with (root / 'ROUND_OFF_REGRESSION.json').open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write('\n')
print(json.dumps({'cases':len(rows),'tests_executed':sum(row['tests'] for row in rows),
                  'expected_red_cases':4,'all_expected_outcomes_observed':True,
                  'original_test_sha256':report['original_test_sha256'],
                  'patched_test_sha256':report['patched_test_sha256']}))
