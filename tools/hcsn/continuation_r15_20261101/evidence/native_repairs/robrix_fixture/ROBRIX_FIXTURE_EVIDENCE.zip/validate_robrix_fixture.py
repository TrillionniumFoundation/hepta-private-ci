"""Focused runfiles probe; not full crate tests or Bazel analysis."""
import hashlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
PROBE = ROOT / "robrix-validation"
PROBE.mkdir(exist_ok=True)
ORIGINAL, CANDIDATE = ROOT / "original", ROOT / "robrix-candidate"
NAMES = ["cross-parser-corpus-v2.json", "manifest.json", "matrixd-control-v2.schema.json",
         "robrix_control_projection.rs", "supervisord-readonly-v2.schema.json"]
REL = "codex-rs/hepta-supervisor/tests/robrix_control_projection.rs"
ENV = os.environ | {"PATH": "/tmp/hcsn-r15-runtime-tools/cargo/bin:/usr/local/bin:/usr/bin:/bin",
                    "CARGO_HOME": "/tmp/hcsn-r15-runtime-tools/cargo",
                    "RUSTUP_HOME": "/tmp/hcsn-r15-runtime-tools/rustup",
                    "RUSTUP_TOOLCHAIN": "1.95.0"}
records = []
def run(name, args, env=None, success=True):
    r = subprocess.run(args, cwd=PROBE, env=env or ENV, capture_output=True, text=True)
    (PROBE/(name+".stdout.txt")).write_text(r.stdout)
    (PROBE/(name+".stderr.txt")).write_text(r.stderr)
    records.append({"name":name,"args":args,"returncode":r.returncode,
                    "stdout":r.stdout,"stderr":r.stderr,"expected_success":success})
    assert (r.returncode == 0) == success, records[-1]

shim = r'''
use std::collections::BTreeMap;
use std::fs;
type Result<T> = std::io::Result<T>;
trait Context<T> {
    fn context(self, msg: &str) -> Result<T>;
    fn with_context<F: FnOnce() -> String>(self, msg: F) -> Result<T>;
}
impl<T> Context<T> for Option<T> {
    fn context(self, msg: &str) -> Result<T> { self.ok_or_else(|| std::io::Error::other(msg.to_string())) }
    fn with_context<F: FnOnce() -> String>(self, msg: F) -> Result<T> { self.ok_or_else(|| std::io::Error::other(msg())) }
}
impl<T,E: std::fmt::Display> Context<T> for std::result::Result<T,E> {
    fn context(self, msg: &str) -> Result<T> { self.map_err(|e| std::io::Error::other(format!("{msg}: {e}"))) }
    fn with_context<F: FnOnce() -> String>(self, msg: F) -> Result<T> { self.map_err(|e| std::io::Error::other(format!("{}: {e}", msg()))) }
}
#[macro_export]
macro_rules! anyhow { ($($arg:tt)*) => { std::io::Error::other(format!($($arg)*)) }; }
#[macro_export]
macro_rules! bail { ($($arg:tt)*) => { return Err(crate::anyhow!($($arg)*)) }; }
mod anyhow { pub use crate::{anyhow, bail}; }
'''
main = '''
fn main() -> Result<()> {
    let expected: BTreeMap<String, Vec<u8>> = NAMES.iter()
        .map(|name| (name.to_string(), name.as_bytes().to_vec())).collect();
    assert_eq!(read_tracked_artifacts()?, expected);
    println!("all five synthetic fixture identities read");
    Ok(())
}
'''
roots = [PROBE/"runtime workspace/codex-rs", PROBE/"cargo workspace/codex-rs"]
for root in roots:
    d = root/"hepta-supervisor/fixtures/robrix-control-v2"; d.mkdir(parents=True,exist_ok=True)
    for name in NAMES: (d/name).write_bytes(name.encode())
for variant, source, bazel in [("before_bazel", ORIGINAL/REL, True),
                               ("after_bazel", CANDIDATE/REL, True),
                               ("after_cargo", CANDIDATE/REL, False)]:
    text = source.read_text()
    extracted = text[text.index("fn read_tracked_artifacts()"):]
    program = PROBE/(variant+".rs")
    program.write_text(shim+"\n"+extracted+"\nconst NAMES: [&str; 5] = "+json.dumps(NAMES)+";\n"+main)
    env = ENV | {"CARGO_MANIFEST_DIR":str(PROBE/"unavailable compile workspace") if bazel else str(roots[1]/"hepta-supervisor")}
    if bazel: env["BAZEL_PACKAGE"]="codex-rs/hepta-supervisor"
    else: env.pop("BAZEL_PACKAGE",None)
    run("compile_"+variant,["rustc","--edition","2024",str(program),"-o",str(PROBE/variant)],env)

marker = roots[0]/"utils/cargo-bin/repo_root.marker"
marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text("synthetic marker")
template = (ORIGINAL/"workspace_root_test_launcher.sh.tpl").read_text()
launcher = template.replace("__WORKSPACE_ROOT_MARKER__","codex-rs/utils/cargo-bin/repo_root.marker")
launcher = launcher.replace("__TEST_BIN__","probe/reader").replace("__RUNFILE_ENV_EXPORTS__","")
setup = 'export INSTA_WORKSPACE_ROOT="'+chr(36)+'{workspace_root}"\ncd "'+chr(36)+'{workspace_root}"'
launcher = launcher.replace("__WORKSPACE_ROOT_SETUP__",setup)
launcher_path=PROBE/"actual_launcher.sh"; launcher_path.write_text(launcher)
manifest=PROBE/"MANIFEST"
env=ENV|{"RUNFILES_MANIFEST_FILE":str(manifest),"RUNFILES_MANIFEST_ONLY":"1","TEST_WORKSPACE":"_main"}
for name in ["INSTA_WORKSPACE_ROOT","RUNFILES_DIR","TEST_SRCDIR","TEST_SHARD_INDEX","TEST_TOTAL_SHARDS",
             "RULES_RUST_TEST_TOTAL_SHARDS","RULES_RUST_TEST_SHARD_INDEX","CODEX_BAZEL_TEST_SKIP_FILTERS","TESTBRIDGE_TEST_ONLY"]:
    env.pop(name,None)
def launch(name,binary,success):
    manifest.write_text("_main/codex-rs/utils/cargo-bin/repo_root.marker "+str(marker)+
                        "\n_main/probe/reader "+str(PROBE/binary)+"\n")
    run(name,["bash",str(launcher_path)],env,success)
launch("old_reader_actual_manifest_launcher_rejects","before_bazel",False)
launch("new_reader_actual_manifest_launcher_passes","after_bazel",True)
run("cargo_reader_passes_without_bazel_env",[str(PROBE/"after_cargo")])
missing=ENV.copy(); missing.pop("INSTA_WORKSPACE_ROOT",None)
run("missing_runtime_root_rejects",[str(PROBE/"after_bazel")],missing,False)
d=roots[0]/"hepta-supervisor/fixtures/robrix-control-v2"
(d/"unexpected.json").write_text("{}")
launch("extra_artifact_is_still_observed_and_rejected","after_bazel",False)
(d/"unexpected.json").unlink(); (d/"non-file").mkdir()
launch("nonfile_artifact_is_still_rejected","after_bazel",False)

# Real macro source, with explicit synthetic glob and dependency records.
support_path=Path("/tmp/hcsn-r15-yaml-alias/audit_cargo_aliases.py")
spec=importlib.util.spec_from_file_location("macro_support",support_path)
support=importlib.util.module_from_spec(spec); spec.loader.exec_module(support)
source=inspect.getsource(support.emit)
needle="all_files = ['build.rs', 'src/lib.rs', 'src/main.rs', 'tests/selected.rs', 'tests/neighbor.rs']"
fixtures=["fixtures/robrix-control-v2/"+name for name in NAMES]
assert source.count(needle)==1
exec(compile(source.replace(needle,"all_files = "+repr(["src/lib.rs","tests/robrix_control_projection.rs"]+fixtures)),
             "<synthetic inventory>","exec"),support.__dict__)
base=Path("/tmp/hcsn-r15-yaml-alias/original")
definitions=(base/"defs.bzl").read_text()
helper=Path("/tmp/hcsn-r15-yaml-alias/candidate/bazel/rules/rust_crate_aliases.bzl").read_text()
test_helper=(base/"bazel/rules/testing/rust_test_dependencies.bzl").read_text()
def emit(directory):
    return support.emit(definitions,helper,test_helper,"codex-rs/hepta-supervisor","//conditions:default",
                        build=(directory/"codex-rs/hepta-supervisor/BUILD.bazel").read_text())[0]
before,after=emit(ORIGINAL),emit(CANDIDATE)
assert before.keys()==after.keys()
changed=[]
for name,row in after.items():
    assert {k:v for k,v in row.items() if k!="data"}=={k:v for k,v in before[name].items() if k!="data"}
    if row.get("data")!=before[name].get("data"):
        assert set(row["data"])-set(before[name]["data"])==set(fixtures)
        changed.append(name)
targets=[r for r in after.values() if r.get("crate_root")=="tests/robrix_control_projection.rs"]
assert targets and all(set(fixtures)<=set(r["data"]) for r in targets)
receipt={"scope":"Unchanged actual Bash runfiles launcher plus verbatim extracted Rust fixture readers with std-only error shims and five synthetic named fixtures; real macro source emission with explicit inventory. Not full Bazel analysis or original crate tests.",
         "observed_ci_failure_head":"1e91c5cf18272505508b9ce880fd34879bb6a546","job":124814581056,
         "records":records,"macro_emitted_records":len(after),"macro_targets_with_added_fixture_data":changed,
         "fixture_names":NAMES,"other_macro_attributes_unchanged":True,
         "original_assertions_unchanged":True,"runtime_permission_code_changed":False,"cargo_or_locks_changed":False,
         "still_required":"Original hepta-supervisor Robrix tests and native next-head Bazel GNU/macOS/Windows CI"}
(PROBE/"VALIDATION.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"success":True,"compile_runs":3,"runtime_cases":6,"macro_records":len(after),"data_targets":changed},indent=2))

