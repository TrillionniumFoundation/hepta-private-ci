
use std::collections::BTreeMap;
use std::fs;
type Result<T> = std::io::Result<T>;
trait Context<T> {
    fn context(self, msg: &str) -> Result<T>;
    fn with_context<F: FnOnce() -> String>(self, msg: F) -> Result<T>;
}
impl<T> Context<T> for Option<T> {
    fn context(self, msg: &str) -> Result<T> { self.ok_or_else(|| std::io::Error::other(msg.to_string())) }
    fn with_context<F: FnOnce() -> String>(self, msg: F) -> Result<T> { self.ok_or_else(|| std::io::Error::other(msg())) }
}
impl<T,E: std::fmt::Display> Context<T> for std::result::Result<T,E> {
    fn context(self, msg: &str) -> Result<T> { self.map_err(|e| std::io::Error::other(format!("{msg}: {e}"))) }
    fn with_context<F: FnOnce() -> String>(self, msg: F) -> Result<T> { self.map_err(|e| std::io::Error::other(format!("{}: {e}", msg()))) }
}
#[macro_export]
macro_rules! anyhow { ($($arg:tt)*) => { std::io::Error::other(format!($($arg)*)) }; }
#[macro_export]
macro_rules! bail { ($($arg:tt)*) => { return Err(crate::anyhow!($($arg)*)) }; }
mod anyhow { pub use crate::{anyhow, bail}; }

fn read_tracked_artifacts() -> Result<BTreeMap<String, Vec<u8>>> {
    read_artifacts(
        &std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("fixtures/robrix-control-v2"),
    )
}

fn read_artifacts(root: &std::path::Path) -> Result<BTreeMap<String, Vec<u8>>> {
    let mut artifacts = BTreeMap::new();
    for entry in fs::read_dir(root).with_context(|| format!("read {}", root.display()))? {
        let entry = entry?;
        let file_type = entry.file_type()?;
        if !file_type.is_file() {
            anyhow::bail!(
                "artifact set contains a non-file: {}",
                entry.path().display()
            );
        }
        let name = entry
            .file_name()
            .into_string()
            .map_err(|_| anyhow::anyhow!("artifact name is not UTF-8"))?;
        artifacts.insert(name, fs::read(entry.path())?);
    }
    Ok(artifacts)
}

const NAMES: [&str; 5] = ["cross-parser-corpus-v2.json", "manifest.json", "matrixd-control-v2.schema.json", "robrix_control_projection.rs", "supervisord-readonly-v2.schema.json"];

fn main() -> Result<()> {
    let expected: BTreeMap<String, Vec<u8>> = NAMES.iter()
        .map(|name| (name.to_string(), name.as_bytes().to_vec())).collect();
    assert_eq!(read_tracked_artifacts()?, expected);
    println!("all five synthetic fixture identities read");
    Ok(())
}
