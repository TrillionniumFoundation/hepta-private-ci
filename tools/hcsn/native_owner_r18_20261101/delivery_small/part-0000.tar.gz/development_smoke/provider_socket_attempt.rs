//! Stateful local provider: durable lease, billing counter and operation dedup.

use std::collections::BTreeMap;
use std::fs::OpenOptions;
use std::io::{BufRead, BufReader, Read, Write};
use std::os::unix::net::{UnixListener, UnixStream};
use std::path::Path;

use crate::common::{Job, MAX_FILE, Result, atomic, ensure, fault, read, seal, unseal};

pub struct Provider {
    run: String,
    job_checksum: u64,
    generation: u64,
    effects: BTreeMap<String, String>,
    count: u64,
    charged_micros: u64,
}

impl Provider {
    fn open(path: &Path, job: &Job) -> Result<Self> {
        if !path.exists() {
            return Ok(Self {
                run: job.run.clone(),
                job_checksum: job.checksum,
                generation: 0,
                effects: BTreeMap::new(),
                count: 0,
                charged_micros: 0,
            });
        }
        let text = read(path)?;
        let mut lines = unseal(&text)?.lines();
        let header: Vec<_> = lines
            .next()
            .ok_or("missing provider header")?
            .split('\t')
            .collect();
        ensure(
            header.len() == 6 && header[0] == "PROVIDER" && header[1] == job.run,
            "wrong provider run",
        )?;
        ensure(
            u64::from_str_radix(header[2], 16)? == job.checksum,
            "wrong provider job",
        )?;
        let mut result = Self {
            run: job.run.clone(),
            job_checksum: job.checksum,
            generation: header[3].parse()?,
            count: header[4].parse()?,
            charged_micros: header[5].parse()?,
            effects: BTreeMap::new(),
        };
        let mut total = 0;
        let mut indexes = Vec::new();
        for line in lines {
            let p: Vec<_> = line.split('\t').collect();
            ensure(
                p.len() == 7 && p[0] == "EFFECT" && p[1] == job.run,
                "bad effect",
            )?;
            ensure(
                result.effects.insert(p[2].into(), line.into()).is_none(),
                "duplicate effect",
            )?;
            total += p[5].parse::<u64>()?;
            indexes.push(p[6].parse::<u64>()?);
        }
        indexes.sort();
        ensure(
            indexes == (1..=result.count).collect::<Vec<_>>() && total == result.charged_micros,
            "inconsistent billing state",
        )?;
        Ok(result)
    }

    fn persist(&self, path: &Path) -> Result<()> {
        let mut text = format!(
            "PROVIDER\t{}\t{:016x}\t{}\t{}\t{}\n",
            self.run, self.job_checksum, self.generation, self.count, self.charged_micros
        );
        for effect in self.effects.values() {
            text.push_str(effect);
            text.push('\n');
        }
        atomic(path, &seal(&text))
    }

    fn request(
        &mut self,
        fields: &[&str],
        job: &Job,
        path: &Path,
        stop: &str,
        marker: &Path,
    ) -> Result<String> {
        ensure(fields.len() >= 2 && fields[1] == self.run, "wrong run")?;
        if fields[0] == "LEASE" {
            ensure(fields.len() == 2, "bad lease")?;
            self.generation = self
                .generation
                .checked_add(1)
                .ok_or("generation overflow")?;
            self.persist(path)?;
            return Ok(format!("LEASE\t{}", self.generation));
        }
        ensure(
            fields.len() >= 3 && fields[2].parse::<u64>()? == self.generation,
            "stale owner generation",
        )?;
        if fields[0] == "CHECK" {
            ensure(fields.len() == 3, "bad check")?;
            return Ok("OK".into());
        }
        ensure(fields.len() == 6 && fields[0] == "CALL", "bad call")?;
        let opid = fields[3];
        let expected = job
            .frames
            .iter()
            .find(|f| {
                f.opid == opid && (f.event == "received:READ" || f.event == "received:REFRESH")
            })
            .ok_or("unknown operation")?;
        let action = expected.event.split(':').nth(1).ok_or("no action")?;
        ensure(
            fields[4] == action && fields[5].parse::<u64>()? == expected.provider_micros,
            "operation content mismatch",
        )?;
        if let Some(receipt) = self.effects.get(opid) {
            return Ok(receipt.clone());
        }
        self.count = self.count.checked_add(1).ok_or("counter overflow")?;
        self.charged_micros = self
            .charged_micros
            .checked_add(expected.provider_micros)
            .ok_or("balance overflow")?;
        let receipt = format!(
            "EFFECT\t{}\t{}\t{}\t{}\t{}\t{}",
            self.run, opid, action, expected.token, expected.provider_micros, self.count
        );
        self.effects.insert(opid.into(), receipt.clone());
        self.persist(path)?;
        fault("provider_committed", stop, marker)?;
        Ok(receipt)
    }
}

pub fn serve(job: &Job, path: &Path, socket: &Path, stop: &str, marker: &Path) -> Result<()> {
    let lock = OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .open(path.with_extension("lock"))?;
    lock.try_lock()?;
    let mut provider = Provider::open(path, job)?;
    provider.persist(path)?;
    if socket.exists() {
        std::fs::remove_file(socket)?;
    }
    let listener = UnixListener::bind(socket)?;
    println!("READY\t{}", std::process::id());
    std::io::stdout().flush()?;
    for stream in listener.incoming() {
        let mut stream = stream?;
        let mut request = String::new();
        let bytes = BufReader::new(stream.try_clone()?)
            .take((MAX_FILE + 1) as u64)
            .read_line(&mut request)?;
        let response = if bytes > MAX_FILE {
            "ERR\trequest capacity".into()
        } else {
            let fields: Vec<_> = request.trim_end().split('\t').collect();
            match provider.request(&fields, job, path, stop, marker) {
                Ok(text) => text,
                Err(error) => format!("ERR\t{error}"),
            }
        };
        if writeln!(stream, "{response}").is_err() {
            continue;
        }
    }
    drop(lock);
    Ok(())
}

pub fn rpc(socket: &Path, request: &str) -> Result<String> {
    let mut stream = UnixStream::connect(socket)?;
    stream.set_read_timeout(Some(std::time::Duration::from_secs(10)))?;
    writeln!(stream, "{request}")?;
    let mut response = String::new();
    BufReader::new(stream)
        .take((MAX_FILE + 1) as u64)
        .read_line(&mut response)?;
    ensure(response.len() <= MAX_FILE, "response capacity")?;
    let response = response.trim_end().to_string();
    ensure(
        !response.starts_with("ERR") && !response.is_empty(),
        &format!("provider rejected: {response}"),
    )?;
    Ok(response)
}
