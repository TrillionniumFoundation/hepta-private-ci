"""Direct expected task-value fitting, with exact full-trajectory gradients."""
import hashlib
import time

import numpy as np

from .model import Model, softmax_policy


def fit_region(contract, seed, updates=600, learning_rate=.08):
    """Fit tabular randomized stopping decisions, then report hard deployment.

    The complete objective includes actual query/wait/recovery costs and next-job
    continuation. No observation-likelihood loss or teacher labels are used.
    This fits one public contract; cross-contract amortization is not claimed.
    """
    wall, cpu = time.perf_counter(), time.process_time()
    model = Model(contract)
    rng = np.random.default_rng(seed)
    logits = rng.normal(0., .01, model.valid.shape)
    initial = logits.copy()
    first, second = np.zeros_like(logits), np.zeros_like(logits)
    trace = []
    for update in range(1, updates+1):
        evaluated = model.solve(softmax_policy(model, logits))
        gradient = evaluated["logit_gradient"]
        if not np.all(np.isfinite(gradient)) or not np.isfinite(evaluated["initial_value"]):
            raise FloatingPointError("Direct task gradient failed")
        first = .9*first+.1*gradient
        second = .999*second+.001*gradient*gradient
        logits += learning_rate*(first/(1-.9**update))/(np.sqrt(second/(1-.999**update))+1e-8)
        if update == 1 or update % 20 == 0 or update == updates:
            trace.append(dict(update=update, value=evaluated["initial_value"],
                              maximum_gradient=float(np.max(np.abs(gradient)))))
    probabilities = softmax_policy(model, logits)
    soft = model.solve(probabilities)
    hard_actions = np.argmax(probabilities, axis=1)
    hard = model.solve(model.deterministic(hard_actions))
    optimal = model.solve()
    return dict(schema="hcsn.regenerative-evidence.direct-task-fit.v1",
        contract=contract.serializable(), states=[list(s) for s in model.states],
        seed=seed, updates=updates, learning_rate=learning_rate,
        objective="exact expected task return including post-FIRE continuation",
        gradient="full discounted occupation times policy advantage; no teacher labels",
        initial_sha256=hashlib.sha256(initial.astype("<f8").tobytes()).hexdigest(),
        logits=logits.tolist(), probabilities=probabilities.tolist(),
        hard_actions=hard_actions.tolist(), trace=trace,
        soft_value=soft["initial_value"], hard_value=hard["initial_value"],
        hard_minus_soft=hard["initial_value"]-soft["initial_value"],
        optimal_reference_value=optimal["initial_value"],
        hard_optimality_gap=optimal["initial_value"]-hard["initial_value"],
        soft_maximum_gradient=float(np.max(np.abs(soft["logit_gradient"]))),
        converged_gradient=bool(np.max(np.abs(soft["logit_gradient"])) < 1e-7),
        cpu_seconds=time.process_time()-cpu, wall_seconds=time.perf_counter()-wall,
        scope="One finite public contract; deterministic deployment is separately evaluated")
