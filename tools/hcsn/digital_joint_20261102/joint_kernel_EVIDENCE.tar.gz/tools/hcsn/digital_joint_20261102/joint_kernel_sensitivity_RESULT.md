# Local continuum-sensitivity and full trajectory recording

The registered stress comparison and its independently published FD-step
supplement passed. They qualify the reported local finite-grid approximation;
they do not prove whole-domain continuum gradients or a moving/free boundary.
The kernel remained unchanged at SHA256
`0439cf12f4519c29b1b079adb2ebc66eb86a252c59a2754770acc58ed5cff0e9`.

The single registered physical point is
`(b,sigma,mu,reset_plus,reset_minus,gamma,reset_SD)`
`=(.84,.78,.2,.15,-.12,1.9,.08)`, duration 2, center initial atom.
Its expected event count on grid31 is **1.2586411**, so the comparison exercises
a process with more than one expected event during an external interval.
All seven physical derivatives hold other physical coordinates fixed, the
normalized initial coordinate fixed and relative thresholds `-.5,0,.5` fixed.

The independent reference reconstructs the archived NumPy central-difference
FV generator and integrates its full active/refractory mass plus event count
with SciPy. It is independent implementation within the same spatial-discretization
family, not a separate exact continuum solution. Thirty PDE integrations cover
240/480 intervals with central FD step `1e-4`; fourteen additional PDE480
integrations use `5e-5`. Every call's full terminal mass/count, observable vector,
physical input and CPU/wall cost is retained.

| Sensitivity comparison, maximum absolute derivative error | Grid31 | Grid63 | Grid127 |
| --- | --- | --- | --- |
| Projected CDF, refractory mass and repeated-event count versus PDE480 half-step FD | `.0009253320` | `.0002281959` | `.0000539491` |
| Strict finite-node CDF versus projected continuum-density reference | `.0169763994` | `.0084107878` | `.0041866506` |

The first row projects each active representative's mass uniformly into its
Voronoi bin to compare continuum CDFs. The second row preserves the kernel's
actual strict-threshold bank complement, including its finite-grid atoms.
These are different observables; the smaller projected error must not be
reported as strict-bank gradient accuracy. Both errors decrease on refinement.

PDE240 versus PDE480 central-FD Jacobians differ by `1.23898e-5`. Halving the
PDE480 FD step changes its full Jacobian by **`7.11431e-8`**. The observed spatial
and strict-atom errors therefore remain much larger than the measured FD-step
change in this registered case. That is a local numerical diagnostic, not a
proof of a continuum derivative or a uniform accuracy certificate.

The earlier registered killed-Brownian stress result remains unchanged:
**grid31 maximum probability error `.0097422242`**, refining to `.0005807781` at
grid127. No continuum-exact claim follows from the finite CTMC's accurate
matrix-exponential derivatives.

The recorded source commits were
`29b2246c4bfb53d2bb5c3ca3ce83dcf142af0f2a` for the first comparison and
`97edbc1b5f20eae2a3e064d4ab93557c9eacba9b` for the independently registered
half-step supplement. Their source hashes remained unchanged at execution end.
The 30-solve comparison took 154.429720827 wall / 146.620862276 process CPU
seconds. The 14-solve supplement took 146.014655692 wall / 107.707490642 CPU
seconds. Their CPU total is 254.328352918 seconds; this makes no task-speed or
energy-advantage claim.

An initial sensitivity invocation failed with `ENOSPC` while creating its source
snapshot, before any numerical checks. Its failure JSON, zero-byte partial
snapshot and separately recovered source snapshot remain preserved as attempt001.
Attempt002 ran the unchanged published numerical source. The earlier 47-check
validator's independent import-path failure is also retained. These engineering
failures are not removed from the evidence history.

The 2,000-path continuous reference was already preserved in the published
`continuous_renewal_samples.csv`: terminal state columns, event count, multiple-event
indicator and first hit. The new same-seed recorder uses the exact archived
source, law and seed `0xBE23` and matches **all 2,000 recorded vectors and first
hit times exactly**. It now additionally retains complete state, refractory
residual, all **2,854 events** and PCG64 states before/after every path.
This is deterministic recording replay, not 2,000 additional independent samples,
new fits or a fresh confirmation cohort. Its runtime was 2.694413539 wall /
2.666225536 CPU seconds.

Full records are in:

- `joint_kernel_sensitivity_attempt_002.json` — all 30 PDE terminal mass/count records.
- `joint_kernel_sensitivity_halfstep_attempt_001.json` — all 14 additional records.
- `joint_kernel_trajectory_record_attempt_001_RAW.json.gz` — all 2,000 complete replay traces.
- Each attempt's `*_sources.json.gz` — exact source snapshots, with explicit failed/partial attempt history retained.

No task fitting, confirmation-world generation, Rust execution, parameter
identifiability or production qualification is established by these numerical
supplements. The scale gauge and constant-context bank limitations remain.
