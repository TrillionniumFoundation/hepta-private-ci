"""Independent CPU-clock diagnostic; not a formal fit or admission test."""
import argparse
import json
import os
from pathlib import Path
import resource
import signal
import time

import torch


def main():
    p = argparse.ArgumentParser(); p.add_argument("--out", type=Path, required=True)
    p.add_argument("--soft", type=int, default=6); args = p.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    def clocks():
        usage = resource.getrusage(resource.RUSAGE_SELF)
        stat = Path("/proc/self/stat").read_text(); fields = stat.rsplit(")", 1)[1].split()
        return dict(raw_prof_clock_seconds=time.clock_gettime(-8),
                    sched_clock_seconds=time.clock_gettime(-6), process_time_seconds=time.process_time(),
                    getrusage_cpu_seconds=usage.ru_utime+usage.ru_stime,
                    proc_cpu_seconds=(int(fields[11])+int(fields[12]))/os.sysconf("SC_CLK_TCK"),
                    actual_rlimit_cpu=list(resource.getrlimit(resource.RLIMIT_CPU)),
                    process_threads=int(fields[17]), host_pid=int(stat.split()[0]), namespace_pid=os.getpid())
    before = clocks(); torch.set_num_threads(1); torch.manual_seed(612)
    resource.setrlimit(resource.RLIMIT_CPU, (args.soft, args.soft+2))
    start = time.perf_counter(); iterations = 0
    def on_limit(signum, frame):
        report = dict(schema="joint-budget-raw-prof-clock-diagnostic-v1", signum=signum,
                      before_limit=before, at_signal=clocks(), iterations=iterations,
                      wall_seconds=time.perf_counter()-start, torch=torch.__version__,
                      scope="single independent Torch expm/backward workload; no HCSN fit/world or admission result")
        (args.out/"SIGNAL.json").write_text(json.dumps(report, indent=2, sort_keys=True)+"\n")
        os._exit(0)
    signal.signal(signal.SIGXCPU, on_limit)
    matrix = torch.randn(33, 33, dtype=torch.float64, requires_grad=True)
    while True:
        matrix.grad = None
        torch.matrix_exp(.02*matrix).square().sum().backward()
        iterations += 1


if __name__ == "__main__":
    main()
