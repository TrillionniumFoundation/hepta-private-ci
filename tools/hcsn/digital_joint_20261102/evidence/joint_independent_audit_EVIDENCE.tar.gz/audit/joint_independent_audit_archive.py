"""Archive raw confirmation and independent audits separately, with readback."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import tarfile
import time

HERE = Path(__file__).resolve().parent
REPOSITORY = HERE.parents[2]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(); p.add_argument("stage",choices=("confirmation","audit"))
    p.add_argument("--root",type=Path,required=True); p.add_argument("--confirmation",type=Path,required=True)
    p.add_argument("--out",type=Path,required=True); a = p.parse_args()
    wall,cpu = time.perf_counter(),time.process_time()
    frozen_path = a.root/"MODEL_FREEZE.json"; frozen = json.loads(frozen_path.read_bytes())
    def guard():
        assert sha(frozen_path) == "982ccd42b472072aa860e6c0d203fab72a740bd8bef120bc6e01197b1befa29c"
        assert all(sha(REPOSITORY/s)==h for s,h in frozen["sources"].items())
        assert all(sha(a.root/s)==h for s,h in frozen["models"].items())
        assert all(sha(a.root/r["path"])==r["sha256"] for r in frozen["data"].values())
    guard(); members = {}
    def add(path,name):
        path = Path(path)
        assert path.is_file() and not path.is_symlink() and name not in members
        members[name] = path
    if a.stage == "confirmation":
        for path in sorted(a.confirmation.rglob("*")):
            if path.is_file():
                add(path,"confirmation/"+str(path.relative_to(a.confirmation)))
        for suffix,name in ((".process.json","confirmation.process.json"),("_ADAPTER_STARTED.json","confirmation_ADAPTER_STARTED.json")):
            add(a.confirmation.with_name(a.confirmation.name+suffix),name)
        add(frozen_path,"model_freeze/MODEL_FREEZE.json")
        for relative in frozen["sources"]:
            add(REPOSITORY/relative,"source_snapshot/"+relative)
        for name in ("joint_confirmation_runner.py","joint_confirmation_runner_protocol.json",
                     "joint_independent_audit_serialization.py","joint_independent_audit_serialization.json"):
            relative = str((HERE/name).relative_to(REPOSITORY))
            add(HERE/name,"source_snapshot/"+relative)
        name = "joint_independent_audit_confirmation_input_manifest.json"
        add(HERE/name,"independent_input_manifest/"+name)
    else:
        for path in sorted(HERE.glob("joint_independent_audit*")):
            if path.is_file() and not path.name.endswith(".tar.gz") and path != a.out.with_name(a.out.name+".index.json"):
                add(path,"audit/"+path.name)
        for path in sorted((HERE/"evidence").rglob("joint_independent_audit*")):
            if path.is_file():
                add(path,"audit/"+str(path.relative_to(HERE)))
    records = {name:dict(sha256=sha(path),bytes=path.stat().st_size) for name,path in sorted(members.items())}
    a.out.parent.mkdir(parents=True,exist_ok=True)
    with a.out.open("xb") as raw, gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode="w") as archive:
            for name,path in sorted(members.items()):
                info = tarfile.TarInfo(name); info.size = records[name]["bytes"]; info.mode = 0o644
                with path.open("rb") as stream:
                    archive.addfile(info,stream)
    with tarfile.open(a.out,"r:gz") as archive:
        assert archive.getnames() == sorted(members)
        for member in archive:
            data = archive.extractfile(member).read()
            assert len(data) == records[member.name]["bytes"]
            assert hashlib.sha256(data).hexdigest() == records[member.name]["sha256"]
    assert all(sha(path)==records[name]["sha256"] for name,path in members.items())
    guard()
    result = dict(schema="joint-independent-evidence-archive-v1",stage=a.stage,
        archive=dict(name=a.out.name,bytes=a.out.stat().st_size,sha256=sha(a.out)),members=records,
        member_count=len(records),uncompressed_bytes=sum(v["bytes"] for v in records.values()),
        all_members_read_back=True,archive_source_sha256=sha(__file__),model_freeze_sha256=sha(frozen_path),
        model_training_reference_commit="8977e83d89fc0b2e7e74c2ed6f025adb096f5dfc",
        archive_cpu_window_seconds=time.process_time()-cpu,archive_wall_window_seconds=time.perf_counter()-wall,
        scope="Raw confirmation and audit bundles are separate; final model/training tree is in the separately published8977 artifact. Internal packing cost excludes imports/final index write/exit.")
    index = a.out.with_name(a.out.name+".index.json")
    with index.open("x") as stream:
        json.dump(result,stream,sort_keys=True,indent=2,allow_nan=False); stream.write("\n")
    print(json.dumps({k:v for k,v in result.items() if k != "members"},sort_keys=True))


if __name__ == "__main__": main()
