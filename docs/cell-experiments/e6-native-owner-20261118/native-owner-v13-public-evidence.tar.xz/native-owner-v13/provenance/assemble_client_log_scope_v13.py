"""Apply only the reviewed v12 diagnostic trait-scope repair and freeze no test results."""
import datetime,hashlib,json,os,pathlib,re,subprocess,time,traceback
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");S=W/"source"
BASE="30b4e260accbc0d81f6a17e106854c41c61c3346";PARENT="5a5d9c5256cd3ce390b2442474224ab98ea2efcc"
D=W/"client-log-scope-v13-review";PATCH=D/"client-log-scope-fix-two-modules.patch"
SHA="8103911c162bcf79fadc6116a4b4bd22dacab8d9359b2ecaef046e2139c03edd"
FILES=["codex-rs/hepta-agentd/src/learning_iteration_historical_source.rs","codex-rs/hepta-agentd/src/root_historical_task_read_client.rs"]
COUNTS=[4,26]
INPUT="codex-rs/hepta-agentd/src/root_historical_task_read_inputs.rs"
INPUT_SHA="7559a42a6d96bb99da19c237ce55e45474fe44ce4260b744c07b38f3d219d470"
def git(*a):return subprocess.check_output(["git","-C",str(S),*a],text=True).strip()
assert git("rev-parse","HEAD")==BASE and not git("status","--porcelain")
assert git("rev-parse",PARENT+"^")==BASE
assert all(x.startswith("docs/cell-experiments/e6-native-owner-20261118/") for x in git("diff","--name-only",BASE,PARENT).splitlines())
assert hashlib.sha256(PATCH.read_bytes()).hexdigest()==SHA
assert hashlib.sha256((S/INPUT).read_bytes()).hexdigest()==INPUT_SHA
original={rel:subprocess.check_output(["git","-C",str(S),"show",BASE+":"+rel],text=True) for rel in FILES}
out=dict(base=BASE,parent=PARENT,started=datetime.datetime.now(datetime.timezone.utc).isoformat(),stages=[],proposal_patch_sha256=SHA,original_inputs_sha256=INPUT_SHA)
def run(name,argv,env=None):
 start=time.monotonic()
 with (W/(name+".stdout.log")).open("xb") as stdout,(W/(name+".stderr.log")).open("xb") as stderr:
  p=subprocess.run(argv,cwd=S,env=env,stdout=stdout,stderr=stderr)
 out["stages"].append(dict(name=name,command=argv,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start))
 assert p.returncode==0,name
def strip(source):
 bodies=[]
 while ".inspect_err(" in source:
  start=source.index(".inspect_err(");opening=start+len(".inspect_err")
  depth=0;quoted=False;escaped=False
  for end in range(opening,len(source)):
   c=source[end]
   if quoted:
    if escaped:escaped=False
    elif c=="\\":escaped=True
    elif c=='"':quoted=False
   elif c=='"':quoted=True
   elif c=="(":depth+=1
   elif c==")":
    depth-=1
    if depth==0:break
  else:raise AssertionError("unbalanced diagnostic")
  body=source[start:end+1];assert "daemon_stage=" in body
  bodies.append(body);source=source[:start]+source[end+1:]
 return source.replace("use std::io::Write;\n",""),bodies
def strings(s):return re.findall(r'b?"(?:\\.|[^"\\])*"',s)
def tokens(s):return "".join(s.split())
try:
 run("client-v13-evidence-fast-forward",["git","merge","--ff-only",PARENT])
 run("client-v13-apply-check",["git","apply","--check",str(PATCH)])
 run("client-v13-apply",["git","apply",str(PATCH)])
 assert git("diff","--name-only").splitlines()==FILES
 for rel in FILES:
  assert (S/rel).read_bytes()==(D/(pathlib.Path(rel).name+".proposal")).read_bytes()
 env=os.environ.copy();env.update(json.loads(pathlib.Path("/home/qq/hepta-learn-ff41-tools/env.json").read_text()))
 env.update(RUSTUP_TOOLCHAIN="1.96.0",CARGO_BUILD_JOBS="2",CARGO_TARGET_DIR=str(W/"target"),CARGO_NET_OFFLINE="true",PYTHONDONTWRITEBYTECODE="1")
 run("client-v13-fmt",["just","fmt"],env=env)
 assert git("diff","--name-only").splitlines()==FILES
 rows=[]
 for rel,count in zip(FILES,COUNTS):
  current=(S/rel).read_text();base=original[rel];restored,new_bodies=strip(current);prior,old_bodies=strip(base)
  assert len(new_bodies)==len(old_bodies)==count
  assert tokens(restored)==tokens(prior),(rel,"non-diagnostic tokens changed")
  assert strings(restored)==strings(prior),(rel,"original non-diagnostic strings changed")
  assert "use std::io::Write;" not in current
  for a,b in zip(old_bodies,new_bodies):
   old_strings=strings(a);new_strings=strings(b)
   if "historical_client.read_limit" in a:
    assert len(old_strings)==len(new_strings)==1
    assert new_strings[0]==old_strings[0][:-1]+r'\n"'
    pattern=r'\.inspect_err\(\|_\|\{let_=std::io::Write::write_fmt\(&mutio::stderr\(\),format_args!\("daemon_stage=historical_client\.read_limitrequest_id=\{request_id\}maximum=\{MAX_READS\}\\n",?\),?\);\},?\)'
   else:
    assert old_strings==new_strings
    pattern=r'\.inspect_err\(\|_\|\{let_=std::io::Write::write_all\(&mut(?:std::)?io::stderr\(\),b"daemon_stage=[a-z_.]+\\n",?\);\},?\)'
   assert re.fullmatch(pattern,tokens(b)),(rel,"unexpected diagnostic body")
  rows.append(dict(path=rel,original_sha256=hashlib.sha256(base.encode()).hexdigest(),formatted_sha256=hashlib.sha256(current.encode()).hexdigest(),diagnostic_calls=count,original_non_diagnostic_tokens_restored=True,original_non_diagnostic_strings_identical=True,write_import_absent=True,log_bytes_preserved=True))
 assert hashlib.sha256((S/INPUT).read_bytes()).hexdigest()==INPUT_SHA
 patch=subprocess.check_output(["git","-C",str(S),"diff","--binary","--no-ext-diff"])
 with (W/"owner-client-log-scope-v13.patch").open("xb") as f:f.write(patch)
 out.update(status="reviewed-formatted",files=rows,patch_sha256=hashlib.sha256(patch).hexdigest(),patch_bytes=len(patch),source_head=git("rev-parse","HEAD"),built=False,tested=False,original_inputs_unchanged=True)
except BaseException as e:
 out.update(status="failed",error=repr(e))
 (W/"client-v13-assembly-error.log").write_text(traceback.format_exc())
 raise
finally:
 out["finished"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (W/"client-v13-formatted-review.json").open("x") as f:f.write(json.dumps(out,indent=2)+"\n")
 print(json.dumps(out,indent=2),flush=True)
