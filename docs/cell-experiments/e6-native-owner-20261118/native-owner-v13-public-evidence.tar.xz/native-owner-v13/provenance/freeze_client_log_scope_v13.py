"""Freeze only the reviewed diagnostic trait-scope repair before the single original owner case."""
import ast,datetime,hashlib,json,pathlib,subprocess,time,traceback
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");S=W/"source"
BASE="5a5d9c5256cd3ce390b2442474224ab98ea2efcc"
EXPECTED=["codex-rs/hepta-agentd/src/learning_iteration_historical_source.rs","codex-rs/hepta-agentd/src/root_historical_task_read_client.rs"]
INPUT="codex-rs/hepta-agentd/src/root_historical_task_read_inputs.rs";INPUT_SHA="7559a42a6d96bb99da19c237ce55e45474fe44ce4260b744c07b38f3d219d470"
def git(*a):return subprocess.check_output(["git","-C",str(S),*a],text=True).strip()
def patch():return subprocess.check_output(["git","-C",str(S),"diff","--binary","--no-ext-diff",BASE])
assert git("rev-parse","HEAD")==BASE
assert git("diff","--name-only").splitlines()==EXPECTED and not git("diff","--cached","--name-only")
review=json.loads((W/"client-v13-formatted-review.json").read_text())
assert review["status"]=="reviewed-formatted" and review["original_inputs_unchanged"]
assert any(x["name"]=="client-v13-fmt" and x["exit_code"]==0 for x in review["stages"])
SHA=review["patch_sha256"]
assert hashlib.sha256(patch()).hexdigest()==SHA
assert hashlib.sha256((W/"owner-client-log-scope-v13.patch").read_bytes()).hexdigest()==SHA
assert hashlib.sha256((S/INPUT).read_bytes()).hexdigest()==INPUT_SHA
independent=W/"client-log-scope-v13-review/ROOT_REVIEW.json"
assert independent.is_file()
independent_data=json.loads(independent.read_text())
assert independent_data["status"]=="reviewed-no-blocker"
assert independent_data["patch_sha256"]=="8103911c162bcf79fadc6116a4b4bd22dacab8d9359b2ecaef046e2139c03edd"
templates={}
for name in ("run_native_v13","archive_native_v13","prepare_v13_publication"):
 t=(W/(name+".template.py")).read_text();ast.parse(t);templates[name]=t
out=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=BASE,patch_sha256=SHA,stages=[],files=EXPECTED,original_inputs_sha256=INPUT_SHA,independent_review_sha256=hashlib.sha256(independent.read_bytes()).hexdigest(),template_sha256={k:hashlib.sha256(v.encode()).hexdigest() for k,v in templates.items()},scope="Repair only v12 diagnostic Write scope leaking through two original child super globs. Original inputs/by_ref unchanged, same log bytes, no error/predicate/order/deadline/budget change. All v12 compilation failure evidence remains with 30b4e260. No new case has yet run; previous tests are not inherited or repeated.")
def run(name,argv):
 start=time.monotonic()
 with (W/(name+".stdout.log")).open("xb") as stdout,(W/(name+".stderr.log")).open("xb") as stderr:
  p=subprocess.run(argv,cwd=S,stdout=stdout,stderr=stderr)
 out["stages"].append(dict(name=name,command=argv,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start));assert p.returncode==0,name
try:
 run("client-v13-diff-check",["git","diff","--check"])
 run("client-v13-add",["git","add","--",*EXPECTED])
 run("client-v13-commit",["git","-c","user.name=Codex","-c","user.email=codex@openai.com","commit","-m","Keep diagnostic Write calls out of original reader trait scopes"])
 head=git("rev-parse","HEAD");tree=git("rev-parse","HEAD^{tree}")
 assert git("rev-parse","HEAD^")==BASE and not git("status","--porcelain")
 assert hashlib.sha256(patch()).hexdigest()==SHA
 assert hashlib.sha256((S/INPUT).read_bytes()).hexdigest()==INPUT_SHA
 out.update(status="frozen",head=head,tree=tree,source_status="")
 for name,t in templates.items():
  text=t.replace("__STAGE_HEAD__",head).replace("__STAGE_TREE__",tree).replace("__STAGE_SHORT__",head[:8]).replace("__SOURCE_HEAD__",head)
  assert "__STAGE_" not in text and "__SOURCE_HEAD__" not in text;ast.parse(text)
  with (W/(name+".py")).open("x") as f:f.write(text)
  if name=="run_native_v13":out["run_adapter_sha256"]=hashlib.sha256(text.encode()).hexdigest()
except BaseException as e:
 out.update(status="failed",error=repr(e));(W/"client-v13-freeze-error.log").write_text(traceback.format_exc());raise
finally:
 out["finished"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (W/"owner-client-log-scope-v13-candidate.json").open("x") as f:f.write(json.dumps(out,indent=2)+"\n")
 print(json.dumps(out,indent=2),flush=True)
