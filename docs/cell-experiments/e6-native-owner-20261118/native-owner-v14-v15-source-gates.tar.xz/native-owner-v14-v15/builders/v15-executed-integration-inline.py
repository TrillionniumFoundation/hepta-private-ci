import pathlib, subprocess, hashlib, json, os, time
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b")
Q=W/"source-closure-v14"
R=W/"source-closure-v15-evidence"
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=Q,text=True).strip()=="570b46e1cd0d9093f37dbb31bd157825971e899d"
assert not subprocess.check_output(["git","status","--porcelain"],cwd=Q,text=True).strip()
R.mkdir(exist_ok=False)
items=[
(W/"historical-task-closed-diagnostics-v15-e1/historical-task-closed-diagnostics.patch","cceb837e9032ebf035512bfb019b504f71d120854f7d1d849c24736a36deff4c"),
(W/"chain-wrapper-typed-source-v15-corrected/wrapper-typed-source-v15-corrected.patch","90830b2e4b79a228647c0b6e8a1549ec089b5619bfdea47b49da796eca194465")]
result={"base":"570b46e1cd0d9093f37dbb31bd157825971e899d","patches":[]}
for path,expected in items:
 data=path.read_bytes()
 assert hashlib.sha256(data).hexdigest()==expected
 subprocess.run(["git","apply","--check",str(path)],cwd=Q,check=True)
 subprocess.run(["git","apply",str(path)],cwd=Q,check=True)
 result["patches"].append({"path":str(path),"bytes":len(data),"sha256":expected})
env=dict(os.environ)
env["PATH"]="/home/qq/.cargo/bin:"+env.get("PATH","")
env["RUSTUP_TOOLCHAIN"]="1.96.0"
start=time.monotonic()
with (R/"initial-rustfmt.stdout.log").open("wb") as out,(R/"initial-rustfmt.stderr.log").open("wb") as err:
 p=subprocess.run(["just","fmt"],cwd=Q,env=env,stdout=out,stderr=err)
result["rustfmt"]={"returncode":p.returncode,"wall_seconds":time.monotonic()-start}
(R/"integration-initial.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result))
assert p.returncode==0
