"""Run only the two original gates whose literal markers were observed to differ."""
import ast,datetime,hashlib,json,os,pathlib,subprocess,time
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");S=W/"source";Q=W/"source-closure-v14";R=W/"source-closure-v14-evidence"
BASE="3299c1d3318ff157f4948dee89b7939ef67b515c"
def git(cwd,*args):return subprocess.check_output(["git","-C",str(cwd),*args],text=True).strip()
assert git(S,"rev-parse","HEAD")=="978719e6137cc1fe9a64bcde7795cd478b2f293e" and not git(S,"status","--porcelain")
assert git(S,"rev-parse",BASE+"^")=="978719e6137cc1fe9a64bcde7795cd478b2f293e"
R.mkdir();assert not Q.exists()
subprocess.run(["git","-C",str(S),"worktree","add","--detach",str(Q),BASE],check=True)
modules=["test_historical_current_trust_client_source_closure","test_historical_task_read_source_closure"]
selected=[]
for m in modules:
 path=Q/"qa/b4-no-bypass"/(m+".py");tree=ast.parse(path.read_text())
 for item in tree.body:
  if isinstance(item,ast.ClassDef):
   selected.extend(m+"."+item.name+"."+node.name for node in item.body if isinstance(node,ast.FunctionDef) and node.name.startswith("test_"))
env=os.environ.copy();env["PYTHONDONTWRITEBYTECODE"]="1"
started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
argv=["python3","-m","unittest","-v",*modules]
with (R/"baseline.stdout.log").open("xb") as out,(R/"baseline.stderr.log").open("xb") as err:
 p=subprocess.run(argv,cwd=Q/"qa/b4-no-bypass",env=env,stdout=out,stderr=err)
result=dict(status="completed",baseline_head=BASE,baseline_tree=git(Q,"rev-parse","HEAD^{tree}"),argv=argv,cwd=str(Q/"qa/b4-no-bypass"),started=started,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-t,exit_code=p.returncode,selected_test_count=len(selected),selected_tests=selected,source_unchanged=git(Q,"rev-parse","HEAD")==BASE and not git(Q,"status","--porcelain"),rust_executed=False,business_executed=False,scope="Original unmodified source-closure gates on the exact v13 evidence descendant. Failures are preserved; no assertions or protected predicates have been changed.")
for name in ("baseline.stdout.log","baseline.stderr.log"):
 d=(R/name).read_bytes();result[name]=dict(bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
(R/"baseline.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2),flush=True)
