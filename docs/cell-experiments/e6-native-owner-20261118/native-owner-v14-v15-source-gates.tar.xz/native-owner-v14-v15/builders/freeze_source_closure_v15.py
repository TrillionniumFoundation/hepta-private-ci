"""Freeze the reviewed v15 gate/diagnostic successor, retaining failed v14 ancestry."""
import ast,datetime,hashlib,json,pathlib,subprocess,time,tomllib
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");Q=W/"source-closure-v14";R=W/"source-closure-v15-evidence"
BASE="570b46e1cd0d9093f37dbb31bd157825971e899d"
REMOTE_BASE="3299c1d3318ff157f4948dee89b7939ef67b515c"
FILES=[
"CALLERS.toml",
"codex-rs/hepta-agentd/src/authority_host_historical_task.rs",
"codex-rs/hepta-agentd/src/authority_host_historical_task_diagnostics.rs",
"codex-rs/hepta-agentd/src/root_historical_task_read_client.rs",
"qa/b4-no-bypass/test_complete_historical_task_source_closure.py",
"qa/b4-no-bypass/test_historical_task_capacity_source_closure.py",
"qa/b4-no-bypass/test_historical_task_diagnostic_source_closure.py",
]
def git(*args):return subprocess.check_output(["git","-C",str(Q),*args],text=True).strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
start=time.monotonic()
assert git("rev-parse","HEAD")==BASE and git("rev-parse","HEAD^")==REMOTE_BASE
assert not (R/"freeze.json").exists()
status=subprocess.check_output(["git","status","--porcelain","--untracked-files=all"],cwd=Q,text=True)
changed={line[3:] for line in status.splitlines()}
assert changed==set(FILES),(changed,FILES)
for rel in FILES:
 data=(Q/rel).read_bytes();assert data.endswith(b"\n"),rel
 if rel=="CALLERS.toml":assert not data.endswith(b"\n\n"),rel
 if rel.endswith(".py"):ast.parse(data.decode())
manifest=tomllib.loads((Q/"CALLERS.toml").read_text())
assert len(manifest["protected_file"])==892
assert len(manifest["boundary"])==1124
before=json.loads((W/"source-closure-v14-evidence/freeze.json").read_text())
assert git("rev-parse",BASE+":scripts/verify_hepta_callers.py")==git("rev-parse",REMOTE_BASE+":scripts/verify_hepta_callers.py")
assert (Q/"scripts/verify_hepta_callers.py").read_bytes()==subprocess.check_output(["git","show",BASE+":scripts/verify_hepta_callers.py"],cwd=Q)
for rel in [
"codex-rs/hepta-agentd/src/root_generation_current_client.rs",
"codex-rs/hepta-agentd/src/root_historical_task_read_protocol.rs",
"codex-rs/hepta-agentd/src/root_generation_publication_stream.rs",
]:
 assert (Q/rel).read_bytes()==subprocess.check_output(["git","show",BASE+":"+rel],cwd=Q),rel
record={"base":BASE,"base_tree":git("rev-parse","HEAD^{tree}"),"remote_base":REMOTE_BASE,"files":{rel:{"bytes":(Q/rel).stat().st_size,"sha256":sha(Q/rel)} for rel in FILES},"checks":[]}
with (R/"freeze-diff-check.stdout.log").open("xb") as out,(R/"freeze-diff-check.stderr.log").open("xb") as err:
 p=subprocess.run(["git","diff","--check"],cwd=Q,stdout=out,stderr=err)
record["checks"].append({"command":["git","diff","--check"],"exit_code":p.returncode})
assert p.returncode==0
subprocess.run(["git","add","--",*FILES],cwd=Q,check=True)
assert set(git("diff","--cached","--name-only").splitlines())==set(FILES)
assert git("diff","--name-only")==""
patch=subprocess.check_output(["git","diff","--cached","--binary","--no-ext-diff"],cwd=Q)
(R/"frozen-source.patch").write_bytes(patch)
with (R/"freeze-commit.stdout.log").open("xb") as out,(R/"freeze-commit.stderr.log").open("xb") as err:
 p=subprocess.run(["git","-c","user.name=Codex","-c","user.email=codex@openai.com","commit","-m","Close historical diagnostic source gates with private fixed stages"],cwd=Q,stdout=out,stderr=err)
assert p.returncode==0
head=git("rev-parse","HEAD");tree=git("rev-parse","HEAD^{tree}")
assert git("rev-parse","HEAD^")==BASE and git("status","--porcelain")==""
qa_modules=before["qa_modules"]+["test_historical_task_diagnostic_source_closure"]
assert len(qa_modules)==len(set(qa_modules))
record.update(status="frozen-not-yet-tested",source_head=head,source_tree=tree,codex_rs_tree=git("rev-parse","HEAD:codex-rs"),verifier_blob=git("rev-parse","HEAD:scripts/verify_hepta_callers.py"),verifier_sha256=sha(Q/"scripts/verify_hepta_callers.py"),patch_bytes=len(patch),patch_sha256=hashlib.sha256(patch).hexdigest(),qa_modules=qa_modules,whole_freeze_seconds=time.monotonic()-start,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_clean=True,native_business_not_rerun=True,prior_native_source="978719e6137cc1fe9a64bcde7795cd478b2f293e",prior_native_failure="request_id=65 maximum=64",prior_qa_source=BASE,prior_qa_failure_preserved=True)
(R/"freeze.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2))
