import pathlib,subprocess,json,os,hashlib,time,shutil,tomllib
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b"); Q=W/"source-closure-v14"; R=W/"source-closure-v15-evidence"
env=dict(os.environ); env.update(json.loads(pathlib.Path("/home/qq/hepta-learn-ff41-tools/env.json").read_text())); env["RUSTUP_TOOLCHAIN"]="1.96.0"
just=shutil.which("just",path=env.get("PATH",""))
assert just
start=time.monotonic()
with (R/"rustfmt-env-resolved.stdout.log").open("wb") as out,(R/"rustfmt-env-resolved.stderr.log").open("wb") as err:
 p=subprocess.run([just,"fmt"],cwd=Q,env=env,stdout=out,stderr=err)
result={"status":"formatted" if p.returncode==0 else "failed","command":[just,"fmt"],"returncode":p.returncode,"wall_seconds":time.monotonic()-start,"previous_failure":{"kind":"FileNotFoundError: just","stage":"preparation before formatter launch","pty":"dpty-6f3f44c9159cd575df040a61a6f9587384cbcff3f44fabce0566704e632f10d4","patches_already_applied":True},"head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=Q,text=True).strip()}
(R/"integration-rustfmt.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result))
assert p.returncode==0
m=tomllib.loads((Q/"CALLERS.toml").read_text())
keys=list(m)
rows=m["boundary"]
examples=[r for r in rows if "log_" in str(r) or (r.get("symbol","").find("::")<0 and r.get("symbol","").find("original")>=0)][:3]
print(json.dumps({"keys":keys,"examples":examples,"inventory_keys":list(m["privileged_inventory"]),"rows":len(m["protected_file"])}))
