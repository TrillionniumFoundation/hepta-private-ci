"""Offline marker inventory only: the verifier and all gates remain unchanged."""
import ast,hashlib,importlib.util,json,pathlib,re,subprocess,sys,tomllib
sys.dont_write_bytecode=True
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");Q=W/"source-closure-v14";R=W/"source-closure-v14-evidence"
scope=json.loads(pathlib.Path("/home/qq/.local/state/hepta-runtime-mac-worker/terminals/dpty-f2bb9b4f110a7b3371e29ec81576286f1ae77ba646a5811d85630f9dbf0fe85b/output.log").read_text())
spec=importlib.util.spec_from_file_location("v14_marker_proof",Q/"scripts/verify_hepta_callers.py")
proof=importlib.util.module_from_spec(spec);sys.modules[spec.name]=proof;spec.loader.exec_module(proof)
manifest=tomllib.loads((Q/"CALLERS.toml").read_text())
def stripped_observers(source):
 spans=[];cursor=0
 while True:
  start=source.find(".inspect_err(",cursor)
  if start<0:break
  depth=0;quoted=False;escaped=False;opening=start+len(".inspect_err")
  for end in range(opening,len(source)):
   c=source[end]
   if quoted:
    if escaped:escaped=False
    elif c=="\\":escaped=True
    elif c=='"':quoted=False
   elif c=='"':quoted=True
   elif c=="(":depth+=1
   elif c==")":
    depth-=1
    if depth==0:break
  else:raise AssertionError("unclosed observer")
  body=source[start:end+1]
  if "root_stage=" in body or "daemon_stage=" in body:
   assert "write_all" in body or "write_fmt" in body or "writeln!" in body
   spans.append((start,end+1))
  cursor=end+1
 # Two already-reviewed, fixed fence-branch observations.
 pattern=r'(?m)^[ \t]*let _ = std::io::stderr\(\)\s*\.write_all\(\s*b"daemon_stage=historical\.(?:operation|read_for)\.fence\\n",?\s*\);\n'
 spans.extend((m.start(),m.end()) for m in re.finditer(pattern,source))
 spans.sort();cursor=0;chars=[];positions=[]
 for start,end in spans:
  assert start>=cursor
  chars.extend(source[cursor:start]);positions.extend(range(cursor,start));cursor=end
 chars.extend(source[cursor:]);positions.extend(range(cursor,len(source)))
 return "".join(chars),positions,len(spans)
sources={}
for rel in scope["production"]:
 raw=(Q/rel).read_text();view,positions,count=stripped_observers(raw)
 code=proof._strip_cfg_test_items(proof._strip_rust_non_code(raw))
 mask=proof._strip_cfg_test_items(proof._strip_rust_non_code(view))
 assert len(mask)==len(view)
 old=subprocess.check_output(["git","-C",str(Q),"show","843351d3e21cd2365259ea7dd2f687c618e7e553:"+rel],text=True)
 sources[rel]=dict(raw=raw,code=code,view=view,mask=mask,positions=positions,observer_count=count,old=old)
def compact(value,positions):
 chosen=[i for i,c in enumerate(value) if not c.isspace()]
 return "".join(value[i] for i in chosen),[positions[i] for i in chosen]
def locate(rel,marker,kind,start=0,end=None):
 s=sources[rel];text=s["view" if kind=="raw" else "mask"]
 compacted,mapping=compact(text,s["positions"]);needle="".join(marker.split());found=[];cursor=0
 if not needle:return []
 while True:
  at=compacted.find(needle,cursor)
  if at<0:break
  lo,hi=mapping[at],mapping[at+len(needle)-1]+1;cursor=at+1
  if lo<start or (end is not None and hi>end):continue
  actual=s["raw"][lo:hi];actual_mask=proof._strip_rust_non_code(actual)
  found.append(dict(start=lo,end=hi,raw=actual,masked=actual_mask,raw_sha256=hashlib.sha256(actual.encode()).hexdigest()))
 return found
changes=[];unresolved=[];protected_status=[]
for row_index,row in enumerate(manifest["protected_file"]):
 rel=row["path"]
 if rel not in sources:continue
 s=sources[rel]
 try:proof._verify_protected_files(Q,{"protected_file":[row]});failure=None
 except proof.VerificationFailure as e:failure=str(e)
 protected_status.append(dict(row_index=row_index,path=rel,baseline_verified=failure is None,first_failure=failure))
 for i,marker in enumerate(row.get("required",[])):
  if marker in s["raw"]:continue
  matches=locate(rel,marker,"raw")
  record=dict(row_index=row_index,path=rel,kind="required",index=i,old=marker,matches=matches)
  (changes if matches else unresolved).append(record)
 for j,item in enumerate(row.get("required_function_order",[])):
  fn=item["function"];assert s["code"].count(fn)==1,(rel,fn)
  begin=s["code"].index(fn);end=proof._rust_item_end(s["code"],begin)+1;cursor=begin
  literals=item.get("literal_calls",[])
  for i,marker in enumerate(item["sequence"]):
   if marker in literals:
    at=s["raw"].find(marker,cursor,end);assert at>=0;(None)
    cursor=at+len(marker);continue
   at=s["code"].find(marker,cursor,end)
   matches=locate(rel,marker,"code",cursor,end)
   if at>=0 and (not matches or at<=matches[0]["start"]):
    cursor=at+len(marker);continue
   record=dict(row_index=row_index,path=rel,kind="sequence",function=fn,function_index=j,index=i,old=marker,matches=matches)
   (changes if matches else unresolved).append(record)
   if matches:cursor=matches[0]["end"]
 for j,seq in enumerate(row.get("required_order",[])):
  cursor=0
  for i,marker in enumerate(seq):
   at=s["code"].find(marker,cursor)
   if at>=0:cursor=at+len(marker);continue
   matches=locate(rel,marker,"code",cursor)
   record=dict(row_index=row_index,path=rel,kind="required_order",sequence_index=j,index=i,old=marker,matches=matches)
   (changes if matches else unresolved).append(record)
   if matches:cursor=matches[0]["end"]
qa=[]
for mapping in scope["matched_tests"]:
 path=mapping["test"];text=(Q/path).read_text();tree=ast.parse(text)
 for node in ast.walk(tree):
  if not isinstance(node,ast.Constant) or not isinstance(node.value,str):continue
  value=node.value
  if len(value)<6 or not any(c in value for c in ("(","?",".","]","}")):continue
  matches=[]
  for rel in mapping["production"]:
   s=sources[rel]
   if value in s["raw"] or "".join(value.split()) not in "".join(s["old"].split()):continue
   matches.extend(dict(source=rel,**m) for m in locate(rel,value,"raw"))
  if matches:qa.append(dict(path=path,line=node.lineno,end_line=node.end_lineno,column=node.col_offset,end_column=node.end_col_offset,old=value,matches=matches))
result=dict(schema=1,head=subprocess.check_output(["git","-C",str(Q),"rev-parse","HEAD"],text=True).strip(),old_marker_source="843351d3e21cd2365259ea7dd2f687c618e7e553",production=list(sources),protected_status=protected_status,proposed_marker_changes=changes,unresolved_markers=unresolved,qa_candidates=qa,authority="Offline proposal inventory only; no normalizer is installed into any verifier or runtime.")
(R/"marker-inventory-v2.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(dict(status="inventoried",protected_rows=len(protected_status),baseline_failed_rows=sum(not x["baseline_verified"] for x in protected_status),automatic_marker_candidates=len(changes),unresolved_count=len(unresolved),unresolved=[{k:v for k,v in row.items() if k!="matches"} for row in unresolved],qa_candidates=len(qa),affected_qa_files=sorted({x["path"] for x in qa}),source_unchanged=not subprocess.check_output(["git","-C",str(Q),"status","--porcelain"],text=True).strip()),indent=2))
