import pathlib,subprocess,json,hashlib,tomllib,copy,re,ast,importlib.util,sys
sys.dont_write_bytecode=True
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");Q=W/"source-closure-v14";R=W/"source-closure-v15-evidence"
A="codex-rs/hepta-agentd/src/";TASK=A+"authority_host_historical_task.rs";HELPER=A+"authority_host_historical_task_diagnostics.rs"
spec=importlib.util.spec_from_file_location("v15_marker_projection_only",Q/"scripts/verify_hepta_callers.py");proof=importlib.util.module_from_spec(spec);sys.modules[spec.name]=proof;spec.loader.exec_module(proof)
review=json.loads((W/"historical-task-closed-diagnostics-v15-e1/STATIC_REVIEW.json").read_text())
source=(Q/TASK).read_text();code=proof._strip_rust_non_code(source)
old_source=subprocess.check_output(["git","show","570b46e1cd0d9093f37dbb31bd157825971e899d:"+TASK],cwd=Q,text=True)
mapping=[]
for item in review["mapping"]:
 needle="log_historical_task_diagnostic(HistoricalTaskDiagnosticStage::"+item["variant"]+")"
 pat=r"\s*".join(re.escape(x) for x in re.sub(r"\s+","",needle))
 hits=list(re.finditer(pat,code));assert len(hits)==1,(item["variant"],len(hits))
 pos=hits[0].start();lo=code.rfind(".inspect_err(",0,pos);assert lo>=0
 start=code.find("(",lo);depth=1;hi=start+1
 while depth:
  if code[hi]=="(":depth+=1
  elif code[hi]==")":depth-=1
  hi+=1
 new=source[lo:hi];assert needle.replace(" ","") in re.sub(r"\s+","",new)
 assert item["old_observer"] in old_source
 mapping.append(dict(item,new_actual=new,new_actual_start=lo,new_actual_end=hi,new_actual_sha256=hashlib.sha256(new.encode()).hexdigest()))
manifest_text=(Q/"CALLERS.toml").read_text();before=tomllib.loads(manifest_text);after=copy.deepcopy(before);edits=[]
def change(value,where,mode):
 text=value
 for item in mapping:
  old=item["old_observer"] if mode=="raw" else proof._strip_rust_non_code(item["old_observer"])
  new=item["new_actual"] if mode=="raw" else proof._strip_rust_non_code(item["new_actual"])
  if old in text:text=text.replace(old,new)
 if text==value:return value
 hay=source if mode=="raw" else code
 if text not in hay:
  pat=r"\s*".join(re.escape(x) for x in re.sub(r"\s+","",text))
  hits=list(re.finditer(pat,hay));assert len(hits)==1,("new marker not exact unique",where,len(hits))
  text=hay[hits[0].start():hits[0].end()]
 assert text in hay
 edits.append({"field":where,"old":value,"new":text,"mode":mode,"source_sha256":hashlib.sha256(source.encode()).hexdigest()})
 return text
for i,row in enumerate(after["protected_file"]):
 if row["path"]!=TASK:continue
 for j,x in enumerate(row.get("required",[])):row["required"][j]=change(x,["protected_file",i,"required",j],"raw")
 for j,fo in enumerate(row.get("required_function_order",[])):
  for kind in ("sequence","top_level"):
   for k,x in enumerate(fo.get(kind,[])):fo[kind][k]=change(x,["protected_file",i,"required_function_order",j,kind,k],"masked")
for i,row in enumerate(after["boundary"]):
 for kind,targets in (("definition_markers",[row["definition_path"]]),("caller_markers",row.get("product_callers",[]))):
  if TASK not in targets:continue
  for j,x in enumerate(row.get(kind,[])):row[kind][j]=change(x,["boundary",i,kind,j],"raw")
def flat(o,path=()):
 if isinstance(o,str):return [(path,o)]
 if isinstance(o,list):return [v for i,x in enumerate(o) for v in flat(x,path+(i,))]
 if isinstance(o,dict):return [v for k,x in o.items() for v in flat(x,path+(k,))]
 return []
def tokens(block):
 result=[];i=0
 while i<len(block):
  if block[i]=="#":
   i=block.find("\n",i)
   if i<0:break
  elif block[i] in "\"'":
   quote=block[i];start=i;assert block[i:i+3]!=quote*3;i+=1
   while i<len(block):
    if block[i]=="\\" and quote=='"':i+=2;continue
    if block[i]==quote:break
    i+=1
   i+=1;result.append((start,i,tomllib.loads("x="+block[start:i])["x"]))
  else:i+=1
 return result
headers=list(re.finditer(r"(?m)^\[\[([A-Za-z_][A-Za-z_0-9]*)\]\]\s*$",manifest_text))
replacements=[]
for kind in ("protected_file","boundary"):
 blocks=[(h.start(),headers[k+1].start() if k+1<len(headers) else len(manifest_text)) for k,h in enumerate(headers) if h.group(1)==kind]
 for i,(b,a) in enumerate(zip(before[kind],after[kind])):
  if b==a:continue
  lo,hi=blocks[i];fields=flat(b);newfields=dict(flat(a));ts=tokens(manifest_text[lo:hi])
  assert [v for _,_,v in ts]==[v for _,v in fields]
  assert [p for p,_ in fields]==list(newfields)
  for (start,end,value),(path,old) in zip(ts,fields):
   if newfields[path]!=old:replacements.append((lo+start,lo+end,json.dumps(newfields[path],ensure_ascii=False)))
text=manifest_text
for lo,hi,value in sorted(replacements,reverse=True):text=text[:lo]+value+text[hi:]
assert tomllib.loads(text)==after
# One unique free function; its file and private parent are in the existing codex-rs source root.
BID="root_historical_fixed_stage_diagnostic"
boundary={"id":BID,"symbol":"log_historical_task_diagnostic","definition_path":HELPER,
 "definition_markers":["pub(super) fn log_historical_task_diagnostic(stage: HistoricalTaskDiagnosticStage) {","let _ = std::io::Write::write_all(&mut std::io::stderr(), bytes);"],
 "call_pattern":r"\blog_historical_task_diagnostic\b","product_callers":[TASK],
 "caller_markers":["use diagnostics::log_historical_task_diagnostic;"]}
assert BID not in after["privileged_inventory"]["required_boundary_ids"]
ids=after["privileged_inventory"]["required_boundary_ids"]
old_ids="required_boundary_ids = "+json.dumps(ids,ensure_ascii=False)
assert text.count(old_ids)==1
text=text.replace(old_ids,"required_boundary_ids = "+json.dumps(ids+[BID],ensure_ascii=False),1)
after["privileged_inventory"]["required_boundary_ids"].append(BID)
after["boundary"].append(boundary)
helper=(Q/HELPER).read_text()
private_module='#[path = "authority_host_historical_task_diagnostics.rs"]\nmod diagnostics;'
assert private_module in source
helper_row={"path":HELPER,"required":[helper],
 "forbidden":["pub(crate)","pub fn","std::fs::","OpenOptions","format!(","eprintln!(","panic!(","unwrap(","expect(","?"],
 "required_function_order":[{"function":"fn log_historical_task_diagnostic(","sequence":["let bytes: &[u8] = match stage","let _ = std::io::Write::write_all(&mut std::io::stderr(), bytes);"],"top_level":["let bytes: &[u8] = match stage","let _ = std::io::Write::write_all(&mut std::io::stderr(), bytes);"]}]}
reader_row={"path":TASK,"required":[private_module,"use diagnostics::HistoricalTaskDiagnosticStage;","use diagnostics::log_historical_task_diagnostic;"],"forbidden":["pub mod diagnostics","pub use diagnostics","diagnostics::*"]}
def val(v):
 if isinstance(v,str):return json.dumps(v,ensure_ascii=False)
 if isinstance(v,list):return "["+", ".join(val(x) for x in v)+"]"
 if isinstance(v,dict):return "{ "+", ".join(k+" = "+val(x) for k,x in v.items())+" }"
 if isinstance(v,bool):return str(v).lower()
 if isinstance(v,int):return str(v)
 raise AssertionError(type(v))
text=text.rstrip()+"\n\n[[boundary]]\n"+"\n".join(k+" = "+val(v) for k,v in boundary.items())+"\n"
for row in (helper_row,reader_row):
 text+="\n[[protected_file]]\n"+"\n".join(k+" = "+val(v) for k,v in row.items())+"\n"
 after["protected_file"].append(row)
assert tomllib.loads(text)==after
assert before["protected_file"][270]==after["protected_file"][270]
assert before["protected_file"][482]["forbidden"]==after["protected_file"][482]["forbidden"]
(Q/"CALLERS.toml").write_text(text)
# Adapt only existing complete-task QA literals; retain every original test/mutation function and loop.
rel="qa/b4-no-bypass/test_complete_historical_task_source_closure.py"
qa=(Q/rel).read_text();tree=ast.parse(qa);qa_edits=[]
lines=qa.splitlines(True);starts=[0]
for line in lines:starts.append(starts[-1]+len(line))
for node in ast.walk(tree):
 if not isinstance(node,ast.Constant) or not isinstance(node.value,str):continue
 new=change(node.value,["qa",rel,node.lineno,node.col_offset],"masked")
 if new!=node.value:
  lo=starts[node.lineno-1]+node.col_offset;hi=starts[node.end_lineno-1]+node.end_col_offset
  qa_edits.append((lo,hi,repr(new)))
for lo,hi,value in sorted(qa_edits,reverse=True):qa=qa[:lo]+value+qa[hi:]
ast.parse(qa);(Q/rel).write_text(qa)
report={"schema":1,"base":"570b46e1cd0d9093f37dbb31bd157825971e899d","status":"unfrozen exact gate proposal only","source":TASK,"source_sha256":hashlib.sha256(source.encode()).hexdigest(),"helper_sha256":hashlib.sha256(helper.encode()).hexdigest(),"mapping":mapping,"marker_edits":edits,"qa_literal_edits":len(qa_edits),"old_reader_forbidden_unchanged":True,"current_row270_unchanged":True,"old_boundaries_unchanged_except_no_changes_from_this_adapter":after["boundary"][:-1]==before["boundary"],"added_boundary":boundary,"new_protected_rows":[helper_row,reader_row],"source_roots":after["source_roots"],"ignored_path_fragments":after["ignored_path_fragments"],"protected_rows":len(after["protected_file"]),"verifier_unchanged":subprocess.check_output(["git","diff","--","scripts/verify_hepta_callers.py"],cwd=Q,text=True)=="","tests_executed":False}
(R/"helper-gate-adaptation.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({k:v for k,v in report.items() if k not in ("mapping","marker_edits","new_protected_rows")},indent=2))
