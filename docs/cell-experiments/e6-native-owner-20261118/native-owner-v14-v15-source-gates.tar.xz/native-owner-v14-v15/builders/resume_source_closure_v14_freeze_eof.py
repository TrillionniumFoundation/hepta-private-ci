"""Resolve the observed single EOF blank-line rejection and resume the exact freeze."""
import ast,datetime,difflib,hashlib,json,pathlib,subprocess,time,tomllib
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");Q=W/"source-closure-v14";R=W/"source-closure-v14-evidence";P=R/"merged-proposal";S=W/"source"
BASE="3299c1d3318ff157f4948dee89b7939ef67b515c";RUST="978719e6137cc1fe9a64bcde7795cd478b2f293e"
def git(root,*a):return subprocess.check_output(["git","-C",str(root),*a],text=True).strip()
def sha(x):return hashlib.sha256(x).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert git(Q,"rev-parse","HEAD")==BASE and not git(Q,"diff","--cached","--name-only")
assert git(S,"rev-parse","HEAD")==RUST and not git(S,"status","--porcelain")
ready_path=R/"FINAL_PROPOSAL.json";old_ready=ready_path.read_bytes();ready=json.loads(old_ready)
assert ready["patch_sha256"]=="e14e750094faaf446442cd41984da6f260ac0db9153ba1cf77e66f862b082240"
assert ready["reviewed_for_freeze"] is True
allowed=ready["files"]
assert set(git(Q,"diff","--name-only").splitlines())|set(git(Q,"ls-files","--others","--exclude-standard").splitlines())==set(allowed)
for rel in allowed:
 assert sha((P/rel).read_bytes())==sha((Q/rel).read_bytes())==ready["file_sha256"][rel]
assert (R/"freeze-diff-check.stdout.log").read_text()=="CALLERS.toml:16161: new blank line at EOF.\n"
manifest=(P/"CALLERS.toml").read_bytes();assert manifest.endswith(b"\n\n") and not manifest.endswith(b"\n\n\n")
fixed=manifest[:-1];assert tomllib.loads(manifest.decode())==tomllib.loads(fixed.decode())
for path in [R/"FINAL_PROPOSAL.before-eof-fix.json",R/"final-source-closure-proposal.before-eof-fix.patch"]:assert not path.exists()
(R/"FINAL_PROPOSAL.before-eof-fix.json").write_bytes(old_ready)
(R/"final-source-closure-proposal.before-eof-fix.patch").write_bytes((R/"final-source-closure-proposal.patch").read_bytes())
(P/"CALLERS.toml").write_bytes(fixed);(Q/"CALLERS.toml").write_bytes(fixed)
patch="".join("".join(difflib.unified_diff(subprocess.check_output(["git","-C",str(Q),"show",BASE+":"+rel],text=True).splitlines(True) if subprocess.run(["git","-C",str(Q),"cat-file","-e",BASE+":"+rel],capture_output=True).returncode==0 else [],(P/rel).read_text().splitlines(True),fromfile="a/"+rel if subprocess.run(["git","-C",str(Q),"cat-file","-e",BASE+":"+rel],capture_output=True).returncode==0 else "/dev/null",tofile="b/"+rel)) for rel in allowed)
(R/"final-source-closure-proposal.patch").write_text(patch)
ready["file_sha256"]["CALLERS.toml"]=sha(fixed);ready["patch_bytes"]=len(patch.encode());ready["patch_sha256"]=sha(patch.encode())
ready["format_only_review_delta"]={"parent_reviewed_patch_sha256":"e14e750094faaf446442cd41984da6f260ac0db9153ba1cf77e66f862b082240","changed_path":"CALLERS.toml","change":"remove exactly the last LF, resolving actual diff-check extra blank line at EOF","prior_bytes":len(manifest),"new_bytes":len(fixed),"tomllib_structure_equal":True,"all_other_candidate_bytes_unchanged":True,"failed_diff_check_exit_code":2,"failed_diff_check_seconds":0.01311174500733614}
ready_path.write_text(json.dumps(ready,indent=2)+"\n")
start=time.monotonic();started=now();commands=[]
def run(label,args):
 t=time.monotonic();c=subprocess.run(args,cwd=Q,text=True,capture_output=True)
 out=R/(label+".stdout.log");err=R/(label+".stderr.log")
 with out.open("x") as f:f.write(c.stdout)
 with err.open("x") as f:f.write(c.stderr)
 rec={"label":label,"argv":args,"duration_seconds":time.monotonic()-t,"exit_code":c.returncode,"stdout_sha256":sha(out.read_bytes()),"stderr_sha256":sha(err.read_bytes())};commands.append(rec)
 if c.returncode:raise RuntimeError(json.dumps(rec))
run("freeze-v2-diff-check",["git","diff","--check"])
run("freeze-v2-stage",["git","add","--",*allowed])
assert git(Q,"diff","--cached","--name-only").splitlines()==allowed
run("freeze-v2-commit",["git","-c","user.name=Codex","-c","user.email=codex@openai.com","commit","-m","Keep native owner source closure gates on the exact guarded paths"])
head=git(Q,"rev-parse","HEAD");tree=git(Q,"rev-parse","HEAD^{tree}")
assert git(Q,"rev-parse","HEAD^")==BASE and not git(Q,"status","--porcelain")
rust_tree=git(Q,"rev-parse","HEAD:codex-rs");assert rust_tree==git(Q,"rev-parse",RUST+":codex-rs")
verifier_blob=git(Q,"rev-parse","HEAD:scripts/verify_hepta_callers.py");assert verifier_blob==git(Q,"rev-parse",BASE+":scripts/verify_hepta_callers.py")
assert git(S,"rev-parse","HEAD")==RUST and not git(S,"status","--porcelain")
actual_patch=subprocess.check_output(["git","-C",str(Q),"diff","--binary","--no-ext-diff",BASE,head]);(R/"frozen-source-closure.patch").write_bytes(actual_patch)
result={"schema":1,"base":BASE,"source_head":head,"source_tree":tree,"started":started,"finished":now(),"freeze_resume_wall_seconds":time.monotonic()-start,"commands":commands,"files":allowed,"file_sha256":ready["file_sha256"],"qa_modules":[pathlib.Path(rel).stem for rel in allowed if rel.endswith(".py")],"proposal_patch_sha256":ready["patch_sha256"],"actual_git_patch_sha256":sha(actual_patch),"actual_git_patch_bytes":len(actual_patch),"format_only_delta":ready["format_only_review_delta"],"source_clean":True,"original_rust_head":RUST,"rust_tree":rust_tree,"rust_tree_identical":True,"verifier_blob":verifier_blob,"verifier_unchanged":True,"active_S_unchanged":True,"native_tests_inherited":False,"qa_has_not_run_yet":True}
with (R/"freeze.json").open("x") as f:f.write(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
