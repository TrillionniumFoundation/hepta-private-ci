"""Run only the frozen source-closure candidate and record original negative controls."""
import contextlib,datetime,hashlib,importlib.util,json,os,pathlib,subprocess,sys,time,traceback,unittest,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");Q=W/"source-closure-v14";R=W/"source-closure-v15-evidence"
freeze=json.loads((R/"freeze.json").read_text())
BASE="570b46e1cd0d9093f37dbb31bd157825971e899d"
def git(*args):return subprocess.check_output(["git","-C",str(Q),*args],text=True).strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert git("rev-parse","HEAD")==freeze["source_head"]
assert git("rev-parse","HEAD^")==BASE
assert git("status","--porcelain")==""
assert git("rev-parse","HEAD:codex-rs")!=git("rev-parse",BASE+":codex-rs")
assert sorted(git("diff","--name-only",BASE,"HEAD","--","codex-rs").splitlines())==sorted(["codex-rs/hepta-agentd/src/authority_host_historical_task.rs","codex-rs/hepta-agentd/src/authority_host_historical_task_diagnostics.rs","codex-rs/hepta-agentd/src/root_historical_task_read_client.rs"])
assert git("rev-parse","HEAD:scripts/verify_hepta_callers.py")==git("rev-parse",BASE+":scripts/verify_hepta_callers.py")
start=time.monotonic();started=now()
before=dict(head=git("rev-parse","HEAD"),tree=git("rev-parse","HEAD^{tree}"),clean=True)
os.chdir(Q/"qa/b4-no-bypass");sys.path.insert(0,str(Q/"qa/b4-no-bypass"))
modules=freeze["qa_modules"]
assert modules and len(modules)==len(set(modules))
class RecordingResult(unittest.TextTestResult):
 def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.records=[];self.current=None
 def startTest(self,test):
  super().startTest(test);self.current={"id":test.id(),"started":now(),"events":[]};self.test_started=time.monotonic()
 def addSuccess(self,test):super().addSuccess(test);self.current["events"].append({"status":"passed"})
 def addFailure(self,test,err):
  super().addFailure(test,err);self.current["events"].append({"status":"failed","traceback":self._exc_info_to_string(err,test)})
 def addError(self,test,err):
  super().addError(test,err)
  record={"status":"error","traceback":self._exc_info_to_string(err,test)}
  if self.current is None:self.records.append({"id":test.id(),"started":now(),"events":[record],"duration_seconds":0.0,"scope":"unittest class/module error holder"})
  else:self.current["events"].append(record)
 def addSkip(self,test,reason):super().addSkip(test,reason);self.current["events"].append({"status":"skipped","reason":reason})
 def addExpectedFailure(self,test,err):super().addExpectedFailure(test,err);self.current["events"].append({"status":"expected_failure","traceback":self._exc_info_to_string(err,test)})
 def addUnexpectedSuccess(self,test):super().addUnexpectedSuccess(test);self.current["events"].append({"status":"unexpected_success"})
 def addSubTest(self,test,subtest,err):
  super().addSubTest(test,subtest,err)
  if err:self.current["events"].append({"status":"subtest_failure" if issubclass(err[0],test.failureException) else "subtest_error","subtest":str(subtest),"traceback":self._exc_info_to_string(err,test)})
 def stopTest(self,test):
  self.current["duration_seconds"]=time.monotonic()-self.test_started;self.records.append(self.current);self.current=None;super().stopTest(test)
stdout=R/"candidate-qa.stdout.log";stderr=R/"candidate-qa.stderr.log"
with stdout.open("x") as out,stderr.open("x") as err,contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
 phase=time.monotonic()
 suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
 result=unittest.TextTestRunner(stream=err,verbosity=2,resultclass=RecordingResult).run(suite)
 unit_duration=time.monotonic()-phase
 phase=time.monotonic()
 spec=importlib.util.spec_from_file_location("v15_full_original_protected_file_gate",Q/"scripts/verify_hepta_callers.py")
 proof=importlib.util.module_from_spec(spec);sys.modules[spec.name]=proof;spec.loader.exec_module(proof)
 import tomllib
 manifest=tomllib.loads((Q/"CALLERS.toml").read_text())
 try:
  proof._verify_protected_files(Q,manifest)
  sweep={"status":"passed","original_verifier":"_verify_protected_files","protected_rows":len(manifest["protected_file"]),"all_rows_checked":True}
 except Exception:
  sweep={"status":"failed","original_verifier":"_verify_protected_files","protected_rows_requested":len(manifest["protected_file"]),"all_rows_checked":False,"traceback":traceback.format_exc()}
 sweep["duration_seconds"]=time.monotonic()-phase
 print(json.dumps({"protected_file_sweep":sweep},indent=2))
after=dict(head=git("rev-parse","HEAD"),tree=git("rev-parse","HEAD^{tree}"),clean=not git("status","--porcelain"))
records=result.records
failure_status={"failed","error","subtest_failure","subtest_error","unexpected_success"}
case_failures=sum(any(e["status"] in failure_status for e in rec["events"]) for rec in records)
report={"schema":1,"source_before":before,"source_after":after,"source_unchanged":before==after,"parent":BASE,"prior_native_source_not_inherited":"978719e6137cc1fe9a64bcde7795cd478b2f293e","started":started,"finished":now(),"whole_qa_execution_seconds":time.monotonic()-start,"modules":modules,"unittest":{"tests_run":result.testsRun,"successful":result.wasSuccessful(),"failures_including_subtests":len(result.failures),"errors_including_subtests":len(result.errors),"skips":len(result.skipped),"case_records":len(records),"cases_with_failure_events":case_failures,"duration_seconds":unit_duration},"protected_file_sweep":sweep,"cases":records,"native_attempt_executed":False,"rust_build_executed":False,"business_or_model_executed":False,"complete_owner_adoption_proven":False,"cost_scope":"Actual Python QA execution wall only; prior preparation/tool costs not fully measured, not a complete cost total.","unmeasured_costs":{"cpu_core_seconds":None,"energy_joules":None,"api_or_money":None}}
report["successful"]=result.wasSuccessful() and sweep["status"]=="passed" and before==after
(R/"candidate-qa-results.json").write_text(json.dumps(report,indent=2)+"\n")
root=ET.Element("testsuites")
suite_xml=ET.SubElement(root,"testsuite",name="native-owner-source-closure-v15",tests=str(len(records)),failures=str(case_failures),errors="0",skipped=str(len(result.skipped)),time=str(unit_duration))
for rec in records:
 case=ET.SubElement(suite_xml,"testcase",name=rec["id"],time=str(rec["duration_seconds"]))
 errors=[e for e in rec["events"] if e["status"] in failure_status]
 if errors:ET.SubElement(case,"failure",message="Original source-closure assertion failed").text="\n\n".join(e.get("subtest","")+"\n"+e.get("traceback",e["status"]) for e in errors)
 for event in rec["events"]:
  if event["status"]=="skipped":ET.SubElement(case,"skipped",message=event["reason"])
ET.ElementTree(root).write(R/"candidate-qa.xml",encoding="utf-8",xml_declaration=True)
print(json.dumps({k:v for k,v in report.items() if k!="cases"}|{"artifacts":{p.name:{"bytes":p.stat().st_size,"sha256":sha(p)} for p in [stdout,stderr,R/"candidate-qa-results.json",R/"candidate-qa.xml"]}},indent=2))
sys.exit(0 if report["successful"] else 1)
