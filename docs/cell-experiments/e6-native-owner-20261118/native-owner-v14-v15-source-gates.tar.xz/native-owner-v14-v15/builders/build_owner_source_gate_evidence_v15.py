"""Archive explicitly listed source-gate evidence only; never scan runtime private inputs."""
import datetime,hashlib,io,json,pathlib,stat,subprocess,tarfile
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b")
S=W/"source";Q=W/"source-closure-v14";R14=W/"source-closure-v14-evidence";R15=W/"source-closure-v15-evidence"
OUT=W/"public-evidence-v14-v15"
BASE="3299c1d3318ff157f4948dee89b7939ef67b515c";FAILED="570b46e1cd0d9093f37dbb31bd157825971e899d"
D="a6f9e8064f83680134af168e0500048b6942ddfd";TREE="894a8e5ff061980adec9825f0e519b3aba8c454e"
def git(*args):return subprocess.check_output(["git","-C",str(S),*args],text=True).strip()
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):
 st=path.lstat();assert stat.S_ISREG(st.st_mode) and st.st_nlink==1,str(path)
 with path.open("rb") as stream:
  before=stream.read();after=path.stat()
 assert (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
 return before
def json_read(path):return json.loads(read(path))
assert git("rev-parse","HEAD")==D and git("rev-parse","HEAD^{tree}")==TREE and not git("status","--porcelain")
assert subprocess.check_output(["git","-C",str(Q),"rev-parse","HEAD"],text=True).strip()==D
f14=json_read(R14/"freeze.json");f15=json_read(R15/"freeze.json")
assert f14["source_head"]==FAILED and f15["source_head"]==D and f15["source_tree"]==TREE
q14=json_read(R14/"candidate-qa-results.json");q15=json_read(R15/"candidate-qa-results.json")
products=json_read(R15/"products/result.json");pm=json_read(R15/"products/product-manifest.json");tags=json_read(R15/"products/root-elf-fixed-diagnostic-tags.json")
assert q14["source_before"]["head"]==FAILED and not q14["successful"]
assert q15["source_before"]["head"]==D and q15["source_unchanged"] and q15["successful"]
assert q15["protected_file_sweep"]["all_rows_checked"] and q15["protected_file_sweep"]["protected_rows"]==892
assert products["passed"] and products["head"]==D and products["tree"]==TREE and products["before"]==products["after"]
assert pm["head"]==D and pm["tree"]==TREE and tags["head"]==D and tags["all_14_present"]
assert len(tags["fixed_tags"])==14 and all(x["found"] for x in tags["fixed_tags"])
assert tags["elf_sha256"]==pm["artifacts"]["hepta-authority-host"]["sha256"]
OUT.mkdir(exist_ok=False)
files={};origins={};missing_optional=[]
def add(name,path,required=True):
 if not path.exists():
  assert not required,str(path)
  missing_optional.append(str(path));return
 assert name not in files and not name.startswith("/") and ".." not in pathlib.Path(name).parts
 files[name]=read(path);origins[name]={"kind":"exact-file","path":str(path)}
r14names=[
"FINAL_PROPOSAL.before-eof-fix.json","FINAL_PROPOSAL.json","FINAL_PROPOSAL.unfrozen.json",
"baseline.json","baseline.stderr.log","baseline.stdout.log","candidate-qa-results.json","candidate-qa.stderr.log","candidate-qa.stdout.log","candidate-qa.xml",
"diagnostic-manifest-map.json","diagnostic-manifest-proposal.toml",
"final-source-closure-proposal.before-eof-fix.patch","final-source-closure-proposal.patch",
"freeze-diff-check.stderr.log","freeze-diff-check.stdout.log",
"freeze-v2-commit.stderr.log","freeze-v2-commit.stdout.log","freeze-v2-diff-check.stderr.log","freeze-v2-diff-check.stdout.log","freeze-v2-stage.stderr.log","freeze-v2-stage.stdout.log",
"freeze.json","frozen-source-closure.patch","manifest-capacity-namespace-proposal.patch","manual-semantic-marker-map.json","marker-inventory-v2.json","marker-inventory.json","qa-exact-marker-map.json"]
for name in r14names:add("v14/"+name,R14/name)
r15names=[
"MANIFEST_V15_REVIEW_PROJECTION.json","helper-gate-adaptation.json","service-call-format-marker.json",
"initial-rustfmt.stderr.log","initial-rustfmt.stdout.log","integration-rustfmt.json",
"production-and-existing-qa-v15.patch","rustfmt-env-resolved.stderr.log","rustfmt-env-resolved.stdout.log",
"new-helper-qa-applied.json","freeze-diff-check.stdout.log","freeze-diff-check.stderr.log","freeze-commit.stdout.log","freeze-commit.stderr.log","freeze.json","frozen-source.patch",
"candidate-qa.stdout.log","candidate-qa.stderr.log","candidate-qa-results.json","candidate-qa.xml"]
for name in r15names:add("v15/"+name,R15/name)
for name in ["result.json","product-build.stdout.log","product-build.stderr.log","product-manifest.json","product-env.json","source-ff.stdout.log","source-ff.stderr.log","source-fast-forward.json","root-elf-fixed-diagnostic-tags.json"]:
 add("v15/products/"+name,R15/"products"/name)
review_groups={
"source-closure-v14-e1-qa-proposal-v3":["diagnostic-qa-marker-adaptation.patch","STATIC_REVIEW.json","STATIC_MAPPING.json"],
"chain-source-capacity-guards-v14":["capacity-source-guards-v14.patch","PROPOSAL_REVIEW.json","STRUCTURAL_REVIEW.json","MERGED_NAMESPACE_REVIEW.json"],
"historical-task-closed-diagnostics-v15-e1":["historical-task-closed-diagnostics.patch","STATIC_REVIEW.json"],
"chain-wrapper-typed-source-v15":["wrapper-typed-source-v15.patch","PROPOSAL_REVIEW.json"],
"chain-wrapper-typed-source-v15-corrected":["wrapper-typed-source-v15-corrected.patch","PROPOSAL_REVIEW.json","INTEGRATED_V15_STATIC_REVIEW.json"],
"historical-task-diagnostic-qa-v15-e1":["historical-task-diagnostic-qa.patch","STATIC_REVIEW.json"],
"historical-task-diagnostic-qa-v15-e1-v2":["historical-task-diagnostic-qa.patch","STATIC_REVIEW.json","FINAL_STATIC_REVIEW.json","FROZEN_REVIEW.json"]}
for group,names in review_groups.items():
 for name in names:add("reviews/"+group+"/"+name,W/group/name)
for name in ["ROOT_V15_PROPOSAL_REVIEW.json"]:
 add("reviews/"+name,W/name)
audit=W/"historical-read-budget-v13-e1-20261118-556e/SUCCESSFUL_FRESH_PATH_READ_ACCOUNTING.json"
assert sha(read(audit))=="69085ade2eddebe287efc5d5804848c6be329fd3b098849019758144ee5f9ec8"
add("v13-static-audit/SUCCESSFUL_FRESH_PATH_READ_ACCOUNTING.json",audit)
scripts=[
"prepare_gate_marker_inventory_v14.py","prepare_gate_marker_inventory_v14_v2.py","prepare_exact_gate_proposal_v14.py",
"merge_manifest_capacity_namespace_v14.py","merge_manifest_capacity_namespace_v14_v2.py","merge_manifest_capacity_namespace_v14_v3.py",
"assemble_final_source_closure_proposal_v14.py","freeze_source_closure_v14.py","resume_source_closure_v14_freeze_eof.py","run_source_closure_v14_baseline.py","run_frozen_source_closure_v14.py",
"v15-executed-integration-inline.py","v15-executed-fmt-resume-inline.py","prepare_helper_gate_v15.py","prepare_helper_gate_v15_v2.py","prepare_helper_gate_v15_v3.py",
"freeze_source_closure_v15.py","run_frozen_source_closure_v15.py","run_owner_products_v15.py","build_owner_source_gate_evidence_v15.py","publish_owner_source_gate_evidence_v15.py"]
for name in scripts:add("builders/"+name,W/name)
# These are exact operator output files from known source-only actions, never runtime child trees.
ptys=[
"dpty-a04b5f4146fbdd01deea6e8bca3d0695b05691339ecc8c5a14ac14d3f46ab33d",
"dpty-a686ea99f801dc2175059bf2f74f772bb0346ed6a35ef85b8ca8cd1ebe5e932a",
"dpty-e9b793db1f796fe11573a037963e1f73dade132fb8bfde199ff09dd8c3162389",
"dpty-cd06de8b89a5447f65162ec0a2bbff4b63af4cf72281309531d302f864f7072f",
"dpty-168662fbfd4144b9ebc6fc1a1fa8103b29e0d89692248ee3c43a06579bb11618",
"dpty-beb993f824fbd950105109c87c5d22fafb0dc2a702c8f2eaddea149f1412f7bf",
"dpty-7ca4aed75ebe6d535d311739e609718bf26aa1c34a33c2f5543b00f2b762087e",
"dpty-a580e11dc8947fb18b3105095d80c03926af9a46794c0f8649f7480165424463",
"dpty-6f3f44c9159cd575df040a61a6f9587384cbcff3f44fabce0566704e632f10d4",
"dpty-f77da075e170a8c615ffab73dd6e3ecbfaedcb031e3ca090affc91894fcb02e2",
"dpty-3d7f0a1d9d5b37324dc2e2e03e2fb3056da3a5c4bdf96bc891f48b56c615a37e",
"dpty-7df704414563ced876994d642fccdcfc74421eec2802253a4c8859c9ded03f6e",
"dpty-b4060006548ed3bc5eb2eb24f52ff127706207a5a66174381ff8aa55e3d522e5",
"dpty-c8f6a8fb7adca3da16c3719b5a2099c4626cac4ce1ed44aa5e9d5bcacb9ab92b",
"dpty-898e830af7f9f93bd3391d87557fa23f25f7a8a055c33467195457cbda007bdc",
"dpty-012ff7672b1359b05c7946d62fb6db59c2756da21acec0854195f8aff835948c",
"dpty-f659383fe8d95bed91f596b28ac14b13f5d24d325e9891a423ce5ca7fa158602",
"dpty-bffc3889c88593445aa05ef33d28f218ed7bbcae246c0300fc20619930518173",
"dpty-50168851f4e983135533b560722aba99f4ced8fbe20615eea3775587f1b5d82e",
"dpty-2f005ab3dc11437f19d421ebb5069a4aa3a3ac78477d86c1bdc094f69a56a5ce",
"dpty-8daf088b9a02b97babd6b0b85cc086373ef3e68ca7bb1b8bdd279bad2d5c1c64",
"dpty-77766d8e7b7b7b6571b6c0b3d205e9f8e9649874ab058f731658e10e7ac55481",
"dpty-10c1158f83c3f3a85abd54aabaccc5cae8e89d58991c9f4956c2c2abcccfafe1"]
for identifier in ptys:
 add("operator-output/"+identifier+".log",pathlib.Path("/home/qq/.local/state/hepta-runtime-mac-worker/terminals")/identifier/"output.log")
for name,head,freeze in [("v14",FAILED,f14),("v15",D,f15)]:
 for rel in freeze["files"]:
  # Approved commit file list: source, caller contract, and related QA only.
  assert rel=="CALLERS.toml" or rel.startswith("qa/b4-no-bypass/") or rel.startswith("codex-rs/hepta-agentd/src/")
  entry=name+"/frozen-source/"+rel
  files[entry]=subprocess.check_output(["git","-C",str(S),"show",head+":"+rel])
  origins[entry]={"kind":"exact-git-blob","commit":head,"path":rel}
baseline=json_read(R14/"baseline.json")
summary14={k:v for k,v in q14.items() if k!="cases"}
summary14.update(source_head=FAILED,source_tree=f14["source_tree"],baseline=baseline,source_gate_only=True,original_failed_eof_check={"exit_code":2,"elapsed_seconds":0.01311174500733614,"cause":"one extra final LF in CALLERS.toml; corrected with TOML structure unchanged"},source_failed_qa_never_relabelled=True)
summary15={k:v for k,v in q15.items() if k!="cases"}
summary15.update(source_head=D,source_tree=TREE,source_parent=FAILED,remote_base=BASE,
 product_preparation=products,compiler_products=pm,root_fixed_diagnostics=tags,
 native_business_executed=False,prior_native_source="978719e6137cc1fe9a64bcde7795cd478b2f293e",prior_native_result="BLOCKED: historical read request_id=65 maximum=64",
 prior_native_recorded_attempt_wall_v1_v13_seconds=3283.672103214776,
 prior_native_attempt_cost_scope="Previously recorded 13 native attempt wall scopes; excludes source QA, publication, research and unmeasured costs. Nested stages are not added again.",
 read_budget_audit={"path":"v13-static-audit/SUCCESSFUL_FRESH_PATH_READ_ACCOUNTING.json","sha256":"69085ade2eddebe287efc5d5804848c6be329fd3b098849019758144ee5f9ec8","source":"978719e6137cc1fe9a64bcde7795cd478b2f293e","qualification":"Static startup accounting only: 64 completed reads (62 Task + 1 Trust + 1 PostA), attach_sources attempts 65 and needs 66 to finish. Not a measured stack; no proven whole-session NoUpdate/Adopt/cold upper bound, no budget increase."},
 limitations=["150 source QA cases and 892 protected rows are attributed only to a6f9e806.","No full caller sweep, old 949-case result, v11 codec result or native adoption result is inherited.","No libtest, model, NoUpdate, Adopt or fresh D executed on this candidate.","Original MAX_READS=64, deadlines, authentication, refusal, freshness and postchecks remain unchanged.","CPU, energy, API/monetary and total research/publication costs are unknown, not zero."],
 retained_preparation_defects=["v14 initial EOF diff check failure","rejected Chain row270 wrong-file proposal, superseded before freeze","rejected E1 observer regex without fmt trailing comma, superseded before freeze","formatter executable absent from ordinary PATH; original environment resolved it","two pre-freeze marker-locator assumptions rejected before source writes","exact service method raw marker formatting fixed after verifier inspection"],
 source_clean_after=not git("status","--porcelain"))
for filename,value in [("v14-SUMMARY.json",summary14),("v15-SUMMARY.json",summary15)]:
 data=(json.dumps(value,indent=2)+"\n").encode();files[filename]=data;origins[filename]={"kind":"explicit-safe-summary"};(OUT/filename).write_bytes(data)
manifest={"schema":1,"source_head":D,"source_tree":TREE,"failed_source":FAILED,"base":BASE,"archive_prefix":"native-owner-v14-v15/","files":[{"path":name,"bytes":len(data),"sha256":sha(data),"origin":origins[name]} for name,data in sorted(files.items())],"optional_not_present":missing_optional,"scope":"Explicit source, logs, JUnit, metadata, costs, patches, and static reviews only. No recursive runtime directory capture, keys, SourceInputs, authority inputs or binaries."}
mb=(json.dumps(manifest,indent=2)+"\n").encode();(OUT/"manifest.json").write_bytes(mb)
arc=OUT/"native-owner-v14-v15-source-gates.tar.xz"
with tarfile.open(arc,"w:xz",preset=6) as tar:
 for name,data in sorted(list(files.items())+[("manifest.json",mb)]):
  info=tarfile.TarInfo("native-owner-v14-v15/"+name);info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=0;info.gid=0
  tar.addfile(info,io.BytesIO(data))
with tarfile.open(arc,"r:xz") as tar:
 members=tar.getmembers();assert len(members)==len(files)+1 and all(x.isfile() for x in members)
 for name,data in files.items():assert tar.extractfile("native-owner-v14-v15/"+name).read()==data
 assert tar.extractfile("native-owner-v14-v15/manifest.json").read()==mb
assert git("rev-parse","HEAD")==D and not git("status","--porcelain")
result={"status":"complete","source_head":D,"source_tree":TREE,"failed_source":FAILED,"base":BASE,"archive":str(arc),"archive_bytes":arc.stat().st_size,"archive_sha256":sha(read(arc)),"manifest":str(OUT/"manifest.json"),"manifest_sha256":sha(mb),"regular_files":len(files)+1,"source_unchanged":True,"qa_passed":q15["successful"],"product_preparation_passed":products["passed"],"finished":datetime.datetime.now(datetime.timezone.utc).isoformat()}
(W/"public-evidence-v15-build-result.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result,indent=2))
