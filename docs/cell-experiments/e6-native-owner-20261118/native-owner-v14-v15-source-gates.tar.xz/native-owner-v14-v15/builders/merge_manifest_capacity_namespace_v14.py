"""Merge approved precise QA proposals into an isolated proposal only."""
import ast,copy,difflib,hashlib,json,pathlib,re,subprocess,sys,tomllib
sys.dont_write_bytecode=True
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");Q=W/"source-closure-v14";R=W/"source-closure-v14-evidence";P=R/"merged-proposal";P.mkdir(exist_ok=True)
C=W/"chain-source-capacity-guards-v14"
ns={};src=(W/"prepare_gate_marker_inventory_v14_v2.py").read_text();exec(compile(src[:src.index("changes=[];")],"<readonly-marker-map>","exec"),ns)
proof=ns["proof"];locate=ns["locate"]
base_text=(Q/"CALLERS.toml").read_text();base=tomllib.loads(base_text)
assert (C/"base/CALLERS.toml").read_text()==base_text
cap_text=(C/"proposal/CALLERS.toml").read_text();cap=tomllib.loads(cap_text)
diag_text=(R/"diagnostic-manifest-proposal.toml").read_text();diag=tomllib.loads(diag_text)
def merge(b,d,c,path=()):
 if d==b:return copy.deepcopy(c)
 if c==b:return copy.deepcopy(d)
 if d==c:return copy.deepcopy(d)
 if isinstance(b,dict) and isinstance(d,dict) and isinstance(c,dict):
  assert b.keys()==d.keys()==c.keys(),path
  return {k:merge(b[k],d[k],c[k],path+(k,)) for k in b}
 if isinstance(b,list) and isinstance(d,list) and isinstance(c,list):
  n=len(b);assert len(d)>=n and len(c)>=n,path
  extra_d=d[n:];extra_c=c[n:];assert not extra_d or not extra_c or extra_d==extra_c,path
  return [merge(b[i],d[i],c[i],path+(i,)) for i in range(n)]+copy.deepcopy(extra_d or extra_c)
 raise AssertionError(("overlapping semantic change",path))
expected=merge(base,diag,cap)
manual=[]
def replace_exact_old(rel,old,new,kind=None):
 count=0
 for i,row in enumerate(expected["protected_file"]):
  if row["path"]!=rel:continue
  if kind in (None,"required"):
   for j,value in enumerate(row.get("required",[])):
    if value==old:row["required"][j]=new;count+=1;manual.append({"row":i,"path":rel,"field":["required",j],"old":old,"new":new})
  if kind in (None,"sequence"):
   for j,fo in enumerate(row.get("required_function_order",[])):
    for k,value in enumerate(fo["sequence"]):
     if value==old:fo["sequence"][k]=new;count+=1;manual.append({"row":i,"path":rel,"field":["required_function_order",j,"sequence",k],"old":old,"new":new})
 return count
A="codex-rs/hepta-agentd/src/"
assert replace_exact_old(A+"root_historical_ledger_data.rs","serde_json::to_vec(self).map_err(io::Error::other)?.len() > 12 * 1024","serde_json::to_vec(self).map_err(io::Error::other)?.len() > Self::JSON_BOUND")==1
assert replace_exact_old(A+"circuit_task_source_data.rs","DATA_BOUND: usize = 16_384","pub(crate) const JSON_BOUND: usize = 16_384;","required")==1
assert replace_exact_old(A+"circuit_task_source_data.rs","self.schema != 1 || self.purpose != PURPOSE || json(self)?.len() > DATA_BOUND","self.schema != 1 || self.purpose != PURPOSE || json(self)?.len() > Self::JSON_BOUND")==1
client=A+"root_historical_task_read_client.rs"
transport=locate(client,"lane.stream.exchange_with_response_bound(&request, operation.response_bound())?","raw")
decoder=locate(client,"require_complete_reply(&bytes, request_id, &self.profile)?","raw")
assert len(transport)==len(decoder)==1
assert replace_exact_old(client,"lane.stream.exchange(&request)?",transport[0]["masked"])==3
old_decoder="require_complete_reply(\n                    &bytes,\n                    request_id,\n                    &self.profile,\n                )?"
assert replace_exact_old(client,old_decoder,decoder[0]["masked"])==2
# Keep the existing refusal slot rule; only the already-tested CompletedLearning
# branch derives its bounded slot from the original scope and initial digests.
refusal=A+"authority_host_data_refusal.rs"
assert replace_exact_old(refusal,'let owner = format!("initial-data-refusal/{name}/{scope}");','let owner = format!("initial-data-refusal/{name}/{slot}");',"required")==1
rows=[row for row in expected["protected_file"] if row["path"]==refusal]
assert len(rows)==1;row=rows[0]
arms=[
 'RootDataKind::SourcePin => ("source-pin", scope),',
 'RootDataKind::SourceHandoff => ("source-handoff", scope),',
 'RootDataKind::CellSnapshot => ("cell-snapshot", scope),',
 'RootDataKind::HistoricalLedger => ("historical-ledger", scope),',
 'RootDataKind::RunStart => ("run-start", scope),',
]
slot='''let slot = codex_hepta_types::Digest32::of_parts(&[
                b"hepta.root.initial-data-refusal.completed-learning.v1\\0",
                scope.as_array(),
                initial.as_array(),
            ]);'''
for marker in arms+[slot]:
 assert marker in (Q/refusal).read_text();row["required"].append(marker)
fo=next(x for x in row["required_function_order"] if x["function"]=="fn binding(")
old_seq=copy.deepcopy(fo["sequence"])
assert old_seq[:3]==["target.digest().map_err(io::Error::other)?","scope_digest(target.scope())","let name = match kind"]
tail=old_seq[old_seq.index("RefusalRecord {"):]
fo["sequence"]=old_seq[:2]+["let (name, slot) = match kind"]+[proof._strip_rust_non_code(x) for x in arms]+[
 "RootDataKind::CompletedLearning { initial }",
 "codex_hepta_types::Digest32::from_array(initial)",
 "if initial.is_zero()",
 "return Err(io::Error::other(",
 proof._strip_rust_non_code(slot),
 "let owner = format!(",
]+tail
manual.append({"path":refusal,"kind":"scope_initial_namespace","original_five_arms_exact":arms,"complete_slot_raw_sha256":hashlib.sha256(slot.encode()).hexdigest(),"full_target_record_and_load_matching_preserved":True})
# Render only changed strings/arrays within the existing capacity proposal.
# All inserted capacity rows and inventory remain byte-identical to C.
def flat(obj,path=()):
 if isinstance(obj,str):return [(path,obj)]
 if isinstance(obj,list):return [v for i,x in enumerate(obj) for v in flat(x,path+(i,))]
 if isinstance(obj,dict):return [v for k,x in obj.items() for v in flat(x,path+(k,))]
 return []
def tokens(block):
 result=[];i=0
 while i<len(block):
  if block[i]=="#":
   i=block.find("\n",i)
   if i<0:break
  elif block[i] in "\"'":
   quote=block[i];start=i;assert block[i:i+3]!=quote*3;i+=1
   while i<len(block):
    if block[i]=="\\" and quote=='"':i+=2;continue
    if block[i]==quote:break
    i+=1
   i+=1;result.append((start,i,tomllib.loads("x="+block[start:i])["x"]))
  else:i+=1
 return result
headers=list(re.finditer(r"(?m)^\[\[([A-Za-z_][A-Za-z_0-9]*)\]\]\s*$",cap_text));blocks=[]
for k,h in enumerate(headers):
 if h.group(1)=="protected_file":blocks.append((h.start(),headers[k+1].start() if k+1<len(headers) else len(cap_text)))
replacements=[]
for i,(before,after) in enumerate(zip(cap["protected_file"],expected["protected_file"])):
 if before==after:continue
 lo,hi=blocks[i];block=cap_text[lo:hi]
 if before["path"]==refusal:
  # Keep this one existing row reviewable; all keys and original constraints
  # other than the two stale namespace markers retain their values.
  def val(v):
   if isinstance(v,str):return json.dumps(v,ensure_ascii=False)
   if isinstance(v,list):return "["+", ".join(val(x) for x in v)+"]"
   if isinstance(v,dict):return "{ "+", ".join(k+" = "+val(x) for k,x in v.items())+" }"
   if isinstance(v,bool):return str(v).lower()
   if isinstance(v,int):return str(v)
   raise AssertionError(type(v))
  new="[[protected_file]]\n"+"\n".join(k+" = "+val(v) for k,v in after.items())+"\n\n"
  replacements.append((lo,hi,new));continue
 fields=flat(before);newfields=dict(flat(after));ts=tokens(block)
 assert [v for _,_,v in ts]==[v for _,v in fields],i
 assert [p for p,_ in fields]==list(newfields),i
 for (start,end,value),(path,old) in zip(ts,fields):
  if newfields[path]!=old:replacements.append((lo+start,lo+end,json.dumps(newfields[path],ensure_ascii=False)))
text=cap_text
for lo,hi,value in sorted(replacements,reverse=True):text=text[:lo]+value+text[hi:]
assert tomllib.loads(text)==expected
(P/"CALLERS.toml").write_text(text)
# Capacity-exclusive tests can be copied without overlapping diagnostic edits.
copied=[]
for name in ["test_initial_absolute_deadline_source_closure.py","test_initial_lane_admission_source_closure.py","test_historical_task_capacity_source_closure.py"]:
 rel="qa/b4-no-bypass/"+name;target=P/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((C/"proposal"/rel).read_bytes());copied.append(rel)
# Adapt the actual namespace negative tests, retaining comment-spoof rejection.
qa="qa/b4-no-bypass/test_root_data_refusal_source_closure.py"
test=(Q/qa).read_text();assert test.count("initial-data-refusal/{name}/{scope}")==3
test=test.replace("initial-data-refusal/{name}/{scope}","initial-data-refusal/{name}/{slot}").replace("another-marker/{name}/{scope}","another-marker/{name}/{slot}")
old='''        literal = 'let owner = format!("initial-data-refusal/{name}/{slot}");'
        if raw.count(literal) != 1:
            raise PROOF.VerificationFailure("same primary scope refusal namespace required")
        position = raw.index(literal)
        if code[position:position + len(literal)] != PROOF._strip_rust_non_code(literal):
            raise PROOF.VerificationFailure("a comment cannot supply the refusal namespace")'''
literals=['let owner = format!("initial-data-refusal/{name}/{slot}");']+arms+[slot]
new="        # Each exact executable arm retains the original scope slot; completed\n        # learning alone uses its domain-separated scope/initial pair.\n        for literal in "+repr(tuple(literals))+":\n            if raw.count(literal) != 1:\n                raise PROOF.VerificationFailure(\"same scope and original initial refusal namespace required\")\n            position = raw.index(literal)\n            if code[position:position + len(literal)] != PROOF._strip_rust_non_code(literal):\n                raise PROOF.VerificationFailure(\"a comment cannot supply the refusal namespace\")"
assert old in test;test=test.replace(old,new,1)
newtest='''    def test_completed_slot_keeps_scope_initial_domain_and_full_refusal_identity(self):
        self.rejects_removal(REFUSAL, "binding", (
            "RootDataKind::CompletedLearning { initial }",
            "codex_hepta_types::Digest32::from_array(initial)",
            "if initial.is_zero()", "scope.as_array()", "initial.as_array()",
            "target: target.clone()",
        ))
        for old, new in (
            ('b"hepta.root.initial-data-refusal.completed-learning.v1\\\\0"',
             'b"another.completed-learning.domain\\\\0"'),
            ("scope.as_array()", "target.digest()?.as_array()"),
            ("initial.as_array()", "scope.as_array()"),
        ):
            with self.subTest(marker=old):
                self.check_mutation(REFUSAL, lambda source, old=old, new=new:
                                    source.replace(old, new, 1) + "\\n// " + old + "\\n")

'''
needle="    def test_refusal_does_not_need_to_decode_the_primary(self):";assert test.count(needle)==1;test=test.replace(needle,newtest+needle)
ast.parse(test);(P/qa).write_text(test);copied.append(qa)
# QA literal adaptations for the two clients and original DTO validator are
# applied after E1's exact diagnostic proposal to avoid overlapping old hunks.
qa_semantics={
 "lane.stream.exchange(&request)?":{"raw":transport[0]["raw"],"masked":transport[0]["masked"]},
 old_decoder:{"raw":decoder[0]["raw"],"masked":decoder[0]["masked"]},
 "serde_json::to_vec(self).map_err(io::Error::other)?.len() > 12 * 1024":{"raw":"serde_json::to_vec(self).map_err(io::Error::other)?.len() > Self::JSON_BOUND","masked":"serde_json::to_vec(self).map_err(io::Error::other)?.len() > Self::JSON_BOUND"},
}
(R/"manual-semantic-marker-map.json").write_text(json.dumps({"schema":1,"manifest_changes":manual,"qa_semantics":qa_semantics,"capacity_proposal_sha256":"b19ba695aaf122061bdd1916ba9468eb7fd8a5755f7a80a43c838e3657628788","same_production_source":"978719e6137cc1fe9a64bcde7795cd478b2f293e","verifier_unchanged":True},indent=2)+"\n")
patch="".join(difflib.unified_diff((Q/rel).read_text().splitlines(True) if (Q/rel).exists() else [],(P/rel).read_text().splitlines(True),fromfile="a/"+rel,tofile="b/"+rel) for rel in ["CALLERS.toml"]+copied)
(R/"manifest-capacity-namespace-proposal.patch").write_text(patch)
print(json.dumps({"status":"isolated-proposal-only","files":["CALLERS.toml"]+copied,"patch_bytes":len(patch.encode()),"patch_sha256":hashlib.sha256(patch.encode()).hexdigest(),"manifest_parse_matches_expected":True,"all_original_boundary_rows_unchanged":expected["boundary"][:-1]==base["boundary"],"new_boundaries":expected["boundary"][len(base["boundary"]):],"manual_semantic_changes":len(manual),"Q_and_S_unchanged":True,"tests_executed":False},indent=2))
