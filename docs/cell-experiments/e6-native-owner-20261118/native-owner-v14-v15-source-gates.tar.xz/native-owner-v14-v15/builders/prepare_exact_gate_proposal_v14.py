"""Create exact marker proposal; do not modify verifier, Q, production, or tests."""
import ast,contextlib,copy,hashlib,importlib,json,pathlib,re,sys,tomllib
sys.dont_write_bytecode=True
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");Q=W/"source-closure-v14";R=W/"source-closure-v14-evidence"
namespace={}
source=(W/"prepare_gate_marker_inventory_v14_v2.py").read_text()
exec(compile(source[:source.index("changes=[];")],"<existing-read-only-inventory>","exec"),namespace)
proof=namespace["proof"];locate=namespace["locate"];sources=namespace["sources"]
data=json.loads((R/"marker-inventory-v2.json").read_text())
manifest=tomllib.loads((Q/"CALLERS.toml").read_text());expected=copy.deepcopy(manifest);edits={}
def set_at(obj,path,value):
 for key in path[:-1]:obj=obj[key]
 assert isinstance(obj[path[-1]],str)
 obj[path[-1]]=value
def flat(obj,path=()):
 if isinstance(obj,str):return [(path,obj)]
 if isinstance(obj,list):return [v for i,x in enumerate(obj) for v in flat(x,path+(i,))]
 if isinstance(obj,dict):return [v for k,x in obj.items() for v in flat(x,path+(k,))]
 return []
records=[]
for item in data["proposed_marker_changes"]:
 i=item["row_index"];kind=item["kind"];match=item["matches"][0]
 if kind=="required":path=("required",item["index"]);value=match["raw"]
 elif kind=="sequence":path=("required_function_order",item["function_index"],"sequence",item["index"]);value=match["masked"]
 elif kind=="required_order":path=("required_order",item["sequence_index"],item["index"]);value=match["masked"]
 else:raise AssertionError(kind)
 assert dict(flat(manifest["protected_file"][i]))[path]==item["old"]
 set_at(expected["protected_file"][i],path,value)
 edits.setdefault(i,{})[path]=value
 records.append({k:v for k,v in item.items() if k!="matches"}|{"new":value,"actual_start":match["start"],"actual_end":match["end"],"actual_raw_sha256":match["raw_sha256"],"new_is_exact_original_verifier_mask":value==proof._strip_rust_non_code(match["raw"]) if kind!="required" else None})
# Every existing top-level constraint must retain its original depth predicate.
top_unresolved=[]
for i,row in enumerate(manifest["protected_file"]):
 rel=row["path"]
 if rel not in sources:continue
 s=sources[rel]
 for j,fo in enumerate(row.get("required_function_order",[])):
  begin=s["code"].index(fo["function"]);end=proof._rust_item_end(s["code"],begin)+1
  for k,old in enumerate(fo.get("top_level",[])):
   if old in s["code"][begin:end]:continue
   matches=locate(rel,old,"code",begin,end)
   if len(matches)!=1:top_unresolved.append({"row_index":i,"function":fo["function"],"old":old,"matches":len(matches)});continue
   path=("required_function_order",j,"top_level",k);value=matches[0]["masked"]
   set_at(expected["protected_file"][i],path,value);edits.setdefault(i,{})[path]=value
   records.append({"row_index":i,"path":rel,"kind":"top_level","function":fo["function"],"old":old,"new":value,"actual_raw_sha256":matches[0]["raw_sha256"]})
text=(Q/"CALLERS.toml").read_text()
headers=list(re.finditer(r"(?m)^\[\[([A-Za-z_][A-Za-z_0-9]*)\]\]\s*$",text));protected=[]
for hidx,h in enumerate(headers):
 if h.group(1)=="protected_file":protected.append((h.start(),headers[hidx+1].start() if hidx+1<len(headers) else len(text)))
assert len(protected)==len(manifest["protected_file"])
def string_tokens(block):
 result=[];i=0
 while i<len(block):
  if block[i]=="#":
   i=block.find("\n",i)
   if i<0:break
  elif block[i] in "\"'":
   quote=block[i];start=i;assert block[i:i+3]!=quote*3
   i+=1
   while i<len(block):
    if block[i]=="\\" and quote=='"':i+=2;continue
    if block[i]==quote:break
    i+=1
   i+=1;literal=block[start:i]
   result.append((start,i,tomllib.loads("value = "+literal)["value"]))
  else:i+=1
 return result
replacements=[]
for row_index,values in edits.items():
 lo,hi=protected[row_index];block=text[lo:hi];tokens=string_tokens(block);fields=flat(manifest["protected_file"][row_index])
 assert [v for _,_,v in tokens]==[v for _,v in fields],("unparsed TOML key/value",row_index)
 for (start,end,old),(path,value) in zip(tokens,fields):
  if path in values:replacements.append((lo+start,lo+end,json.dumps(values[path],ensure_ascii=False)))
for lo,hi,new in sorted(replacements,reverse=True):text=text[:lo]+new+text[hi:]
assert tomllib.loads(text)==expected
(R/"diagnostic-manifest-proposal.toml").write_text(text)
(R/"diagnostic-manifest-map.json").write_text(json.dumps({"schema":1,"base":"3299c1d3318ff157f4948dee89b7939ef67b515c","changes":records,"top_level_unresolved":top_unresolved,"verifier_unchanged":True},indent=2)+"\n")
# Bind each QA marker to the source/function explicitly passed to its original helper.
sys.path.insert(0,str(Q/"qa/b4-no-bypass"))
qa_records=[];manual=[];processed=[]
def evaluate(node,env):
 return eval(compile(ast.Expression(node),"<static-test-argument>","eval"),{"__builtins__":{"range":range,"tuple":tuple,"len":len}},env)
for rel in sorted({x["path"] for x in data["qa_candidates"]}):
 raw=(Q/rel).read_text();tree=ast.parse(raw)
 module=importlib.import_module(pathlib.Path(rel).stem);base_env=dict(vars(module))
 calls={}
 def handle(node,env):
  if not (isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and node.func.value.id=="self" and node.func.attr in {"reject_removal","check_markers","reject","check"}):return
  method=node.func.attr
  try:
   target=evaluate(node.args[0],env);fn=evaluate(node.args[1],env)
   if target not in sources:return
   if method in {"reject","check"}:fn="fn main() -> Result" if fn=="main" else "fn "+fn+"("
   s=sources[target];begin=s["code"].index(fn);end=proof._rust_item_end(s["code"],begin)+1
  except Exception as e:
   manual.append({"path":rel,"line":node.lineno,"method":method,"reason":"unresolved target/function "+type(e).__name__});return
  marker_nodes=list(node.args[2].elts) if method in {"check_markers","check"} and isinstance(node.args[2],(ast.Tuple,ast.List)) else [node.args[2]]
  for mn in marker_nodes:
   if not (isinstance(mn,ast.Constant) and isinstance(mn.value,str)):
    manual.append({"path":rel,"line":mn.lineno,"method":method,"target":target,"function":fn,"reason":"nonliteral marker"});continue
   old=mn.value;masked=method in {"reject","check"}
   if masked:
    pattern=r"\s*".join(map(re.escape,re.findall(r"[A-Za-z_]\w*|\d+|::|->|=>|!=|==|&&|\|\||\.\.|[^\s]",old)))
    if re.search(pattern,s["code"][begin:end]):continue
   elif old in s["raw"][begin:end]:continue
   matches=locate(target,old,"raw",begin,end)
   if not matches:
    manual.append({"path":rel,"line":mn.lineno,"method":method,"target":target,"function":fn,"old":old,"reason":"semantic or unmapped"});continue
   occurrence=0
   if method in {"reject_removal","reject"} and len(node.args)>3:
    try:occurrence=evaluate(node.args[3],env)
    except Exception:manual.append({"path":rel,"line":mn.lineno,"old":old,"reason":"occurrence unresolved"});continue
   if occurrence>=len(matches):manual.append({"path":rel,"line":mn.lineno,"old":old,"reason":"occurrence out of mapped range"});continue
   match=matches[occurrence];new=match["masked"] if masked else match["raw"]
   key=(mn.lineno,mn.col_offset,mn.end_lineno,mn.end_col_offset)
   entry=calls.setdefault(key,{"path":rel,"line":mn.lineno,"column":mn.col_offset,"end_line":mn.end_lineno,"end_column":mn.end_col_offset,"old":old,"method":method,"target":target,"function":fn,"replacements":[]})
   entry["replacements"].append({"new":new,"occurrence":occurrence,"original_occurrence_arg":ast.unparse(node.args[3]) if len(node.args)>3 else None,"occurrence_span":[node.args[3].lineno,node.args[3].col_offset,node.args[3].end_lineno,node.args[3].end_col_offset] if len(node.args)>3 else None,"actual_raw_sha256":match["raw_sha256"]})
 def walk(node,env):
  if isinstance(node,ast.For):
   try:values=list(evaluate(node.iter,env))
   except Exception:
    for child in node.body:walk(child,env)
    return
   if len(values)>128:raise AssertionError("unbounded static loop")
   for value in values:
    childenv=dict(env)
    if isinstance(node.target,ast.Name):childenv[node.target.id]=value
    elif isinstance(node.target,(ast.Tuple,ast.List)):
     for target,part in zip(node.target.elts,value):
      if isinstance(target,ast.Name):childenv[target.id]=part
    for child in node.body:walk(child,childenv)
   return
  handle(node,env)
  for child in ast.iter_child_nodes(node):walk(child,env)
 walk(tree,base_env)
 qa_records.extend(calls.values());processed.append(rel)
(R/"qa-exact-marker-map.json").write_text(json.dumps({"schema":1,"markers":qa_records,"manual":manual,"authority":"Static helper argument analysis, no QA/test/runtime execution."},indent=2)+"\n")
print(json.dumps({"status":"proposal-only","manifest_marker_changes":len(records),"manifest_edited_rows":len(edits),"manifest_parse_and_expected_semantics_equal":True,"top_level_unresolved":top_unresolved,"qa_exact_markers":len(qa_records),"qa_exact_files":sorted({x["path"] for x in qa_records}),"qa_ambiguous":[{"path":x["path"],"line":x["line"],"old":x["old"],"variants":len({y["new"] for y in x["replacements"]})} for x in qa_records if len({y["new"] for y in x["replacements"]})>1],"manual":manual,"no_source_or_test_change":True},indent=2))
