"""Freeze reviewed QA-only changes; the retained Rust source and verifier stay exact."""
import ast,datetime,hashlib,json,pathlib,subprocess,time,tomllib
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");Q=W/"source-closure-v14";R=W/"source-closure-v14-evidence";P=R/"merged-proposal";S=W/"source"
BASE="3299c1d3318ff157f4948dee89b7939ef67b515c";RUST="978719e6137cc1fe9a64bcde7795cd478b2f293e"
def git(root,*args):return subprocess.check_output(["git","-C",str(root),*args],text=True).strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data):return hashlib.sha256(data).hexdigest()
ready=json.loads((R/"FINAL_PROPOSAL.json").read_text())
assert ready["base"]==BASE and ready["reviewed_for_freeze"] is True
assert git(Q,"rev-parse","HEAD")==BASE and git(Q,"status","--porcelain")==""
assert git(S,"rev-parse","HEAD")==RUST and git(S,"status","--porcelain")==""
assert not (R/"freeze.json").exists()
allowed=ready["files"]
assert allowed and allowed==sorted(set(allowed))
assert all(rel=="CALLERS.toml" or (rel.startswith("qa/b4-no-bypass/test_") and rel.endswith(".py")) for rel in allowed)
for rel in allowed:
 data=(P/rel).read_bytes();assert sha(data)==ready["file_sha256"][rel]
 if rel.endswith(".py"):ast.parse(data.decode())
 if rel.endswith(".toml"):tomllib.loads(data.decode())
assert sha((R/"final-source-closure-proposal.patch").read_bytes())==ready["patch_sha256"]
start=time.monotonic();started=now();commands=[]
def run(label,args):
 t=time.monotonic();r=subprocess.run(args,cwd=Q,text=True,capture_output=True)
 stdout=R/(label+".stdout.log");stderr=R/(label+".stderr.log")
 stdout.write_text(r.stdout);stderr.write_text(r.stderr)
 rec={"label":label,"argv":args,"duration_seconds":time.monotonic()-t,"exit_code":r.returncode,"stdout_sha256":sha(stdout.read_bytes()),"stderr_sha256":sha(stderr.read_bytes())};commands.append(rec)
 if r.returncode:raise RuntimeError(json.dumps(rec))
for rel in allowed:
 target=Q/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((P/rel).read_bytes())
assert set(git(Q,"diff","--name-only").splitlines()) | set(git(Q,"ls-files","--others","--exclude-standard").splitlines())==set(allowed)
run("freeze-diff-check",["git","diff","--check"])
run("freeze-stage",["git","add","--",*allowed])
assert git(Q,"diff","--cached","--name-only").splitlines()==allowed
run("freeze-commit",["git","-c","user.name=Codex","-c","user.email=codex@openai.com","commit","-m","Keep native owner source closure gates on the exact guarded paths"])
head=git(Q,"rev-parse","HEAD");tree=git(Q,"rev-parse","HEAD^{tree}")
assert git(Q,"rev-parse","HEAD^")==BASE and git(Q,"status","--porcelain")==""
assert git(Q,"rev-parse","HEAD:codex-rs")==git(Q,"rev-parse",RUST+":codex-rs")
assert git(Q,"rev-parse","HEAD:scripts/verify_hepta_callers.py")==git(Q,"rev-parse",BASE+":scripts/verify_hepta_callers.py")
assert git(S,"rev-parse","HEAD")==RUST and git(S,"status","--porcelain")==""
qa_modules=[pathlib.Path(rel).stem for rel in allowed if rel.endswith(".py")]
result={"schema":1,"base":BASE,"source_head":head,"source_tree":tree,"started":started,"finished":now(),"freeze_wall_seconds":time.monotonic()-start,"commands":commands,"files":allowed,"file_sha256":ready["file_sha256"],"qa_modules":qa_modules,"proposal_patch_sha256":ready["patch_sha256"],"source_clean":True,"original_rust_head":RUST,"rust_tree_identical":True,"verifier_unchanged":True,"active_S_unchanged":True,"native_tests_inherited":False,"qa_has_not_run_yet":True}
(R/"freeze.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
