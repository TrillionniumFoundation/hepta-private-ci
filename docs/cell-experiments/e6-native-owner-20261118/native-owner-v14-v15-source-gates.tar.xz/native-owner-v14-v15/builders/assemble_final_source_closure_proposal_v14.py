"""Compose the reviewed QA-only proposals without changing either worktree."""
import ast,difflib,hashlib,json,pathlib,subprocess
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");Q=W/"source-closure-v14";S=W/"source";R=W/"source-closure-v14-evidence";P=R/"merged-proposal";E=W/"source-closure-v14-e1-qa-proposal-v3"
def sha(data):return hashlib.sha256(data).hexdigest()
review=json.loads((E/"STATIC_REVIEW.json").read_text())
assert review["base"]=="3299c1d3318ff157f4948dee89b7939ef67b515c"
assert sha((E/"diagnostic-qa-marker-adaptation.patch").read_bytes())=="307431f296e99abcf25270eb3beea2e000ae7f71ed362ba4ecad89f9df0882ef"
for row in review["files"]:
 rel=row["path"];assert sha((Q/rel).read_bytes())==row["base_sha256"]
 proposal=E/"proposal"/rel
 assert sha(proposal.read_bytes())==row["new_sha256"]
 target=P/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(proposal.read_bytes())
maps=json.loads((R/"manual-semantic-marker-map.json").read_text())["qa_semantics"]
simple={
 "bytes.len() > WIRE_BOUND":"bytes.len() > TASK_RESPONSE_BOUND",
 "reply.is_empty() || reply.len() > WIRE_BOUND":"reply.is_empty() || reply.len() > operation.response_bound()",
 "response_bound: WIRE_BOUND":"response_bound: TASK_RESPONSE_BOUND",
}
edits=[]
for rel in sorted({row["path"] for row in review["explicit_remaining_non_diagnostic_items"]}):
 source=(P/rel).read_text();tree=ast.parse(source);lines=source.splitlines(True);offset=[0]
 for line in lines:offset.append(offset[-1]+len(line))
 expected=[row for row in review["explicit_remaining_non_diagnostic_items"] if row["path"]==rel]
 replacements=[];seen=[]
 for node in ast.walk(tree):
  if not (isinstance(node,ast.Constant) and isinstance(node.value,str)):continue
  relevant=[row for row in expected if row["old"]==node.value]
  if not relevant:continue
  assert len(relevant)==1
  old=node.value
  new=maps[old]["masked" if rel.endswith("test_historical_task_read_source_closure.py") else "raw"] if old in maps else simple[old]
  lo=offset[node.lineno-1]+node.col_offset;hi=offset[node.end_lineno-1]+node.end_col_offset
  replacements.append((lo,hi,repr(new)));seen.append(old)
  edits.append(relevant[0]|{"new":new,"comparison":"raw" if not rel.endswith("test_historical_task_read_source_closure.py") else "existing masked tokenizer"})
 assert sorted(seen)==sorted(row["old"] for row in expected),(rel,seen,expected)
 after=source
 for lo,hi,value in sorted(replacements,reverse=True):after=after[:lo]+value+after[hi:]
 after_tree=ast.parse(after)
 reverse={row["new"]:row["old"] for row in edits if row["path"]==rel}
 class Restore(ast.NodeTransformer):
  def visit_Constant(self,node):
   if isinstance(node.value,str) and node.value in reverse:return ast.copy_location(ast.Constant(value=reverse[node.value]),node)
   return node
 assert ast.dump(Restore().visit(after_tree),include_attributes=False)==ast.dump(tree,include_attributes=False)
 (P/rel).write_text(after)
files=sorted(str(p.relative_to(P)) for p in P.rglob("*") if p.is_file())
assert len(files)==15,files
assert all(path=="CALLERS.toml" or path.startswith("qa/b4-no-bypass/test_") for path in files)
patch="".join("".join(difflib.unified_diff((Q/rel).read_text().splitlines(True) if (Q/rel).exists() else [],(P/rel).read_text().splitlines(True),fromfile="a/"+rel if (Q/rel).exists() else "/dev/null",tofile="b/"+rel)) for rel in files)
(R/"final-source-closure-proposal.patch").write_text(patch)
result={"schema":1,"base":"3299c1d3318ff157f4948dee89b7939ef67b515c","reviewed_for_freeze":False,"files":files,"file_sha256":{rel:sha((P/rel).read_bytes()) for rel in files},"patch_bytes":len(patch.encode()),"patch_sha256":sha(patch.encode()),"semantic_qa_edits":edits,"semantic_qa_AST_other_fields_unchanged":True,"diagnostic_review_sha256":sha((E/"STATIC_REVIEW.json").read_bytes()),"independent_semantic_review_pending":True,"no_tests_executed":True,"source_worktrees_unchanged":{str(root):not subprocess.check_output(["git","-C",str(root),"status","--porcelain"],text=True).strip() for root in (Q,S)}}
assert all(result["source_worktrees_unchanged"].values())
(R/"FINAL_PROPOSAL.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items() if k!="semantic_qa_edits"},indent=2))
