"""Build and pin the two products for the frozen gate/diagnostic successor only."""
import datetime,fcntl,hashlib,importlib.util,json,os,pathlib,subprocess,sys,time,traceback
sys.dont_write_bytecode=True
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b")
R=W/"source-closure-v15-evidence"
S=W/"source"
Q=W/"source-closure-v14"
ORIGINAL=pathlib.Path("/home/qq/hepta-learn-ff41-tools/root_5eeb5d33_completed_chain_v1.py")
ORIGINAL_SHA="ee20bff704f8495fabb6133bbb478d82dd14466303e82c4a93ff2ea276c2b3d1"
def git(repo,*args):
 return subprocess.check_output(["git","-C",str(repo),*args],text=True).strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
 frozen=json.loads((R/"freeze.json").read_text())
 head=frozen["source_head"];tree=frozen["source_tree"]
 assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()==ORIGINAL_SHA
 assert git(Q,"rev-parse","HEAD")==head and git(Q,"status","--porcelain")==""
 assert git(Q,"rev-parse","HEAD^")=="570b46e1cd0d9093f37dbb31bd157825971e899d"
 spec=importlib.util.spec_from_file_location("original_owner_product_harness_v15",ORIGINAL)
 harness=importlib.util.module_from_spec(spec);spec.loader.exec_module(harness)
 harness.REPO=S;harness.TARGET=W/"target";harness.OUT=R/"products"
 harness.PUBLIC=pathlib.Path("/var/tmp")/("hepta-native-e6-owner-gates-"+head[:8]+"-20261118-v15")
 harness.HEAD,harness.TREE=head,tree
 harness.OUT.mkdir(exist_ok=False)
 harness.result={"status":"preflight","head":head,"tree":tree,"stages":[],"checks":{},
  "original_harness":str(ORIGINAL),"original_harness_sha256":ORIGINAL_SHA,"adapter_sha256":sha(pathlib.Path(__file__)),
  "scope":"Compilation and exact pinned binary provenance for the closed diagnostics helper and explicit historical Lane type. No libtest, native owner business, model, adoption, or cold recovery executes. v13 native 65/64 remains attributed to 978719e; no prior test pass is inherited.",
  "native_owner_business_executed":False,"libtest_executed":False,"model_executed":False,
  "budget_read_limit_unchanged":64,"independent_controller_qualification":False,
  "unmeasured_costs":{"cpu_core_seconds":None,"energy_joules":None,"api_or_money":None}}
 harness.persist();start=time.monotonic();lock=None;passed=False
 try:
  assert os.getuid()==os.geteuid()==1000
  lock=(harness.TARGET/".hepta-root-native-owner.lock").open("a+b")
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  before_ff={"head":git(S,"rev-parse","HEAD"),"tree":git(S,"rev-parse","HEAD^{tree}"),"status":git(S,"status","--porcelain")}
  assert before_ff["head"]=="978719e6137cc1fe9a64bcde7795cd478b2f293e" and not before_ff["status"]
  subprocess.run(["git","merge-base","--is-ancestor",before_ff["head"],head],cwd=S,check=True)
  with (harness.OUT/"source-ff.stdout.log").open("xb") as out,(harness.OUT/"source-ff.stderr.log").open("xb") as err:
   completed=subprocess.run(["git","merge","--ff-only",head],cwd=S,stdout=out,stderr=err)
  assert completed.returncode==0
  after_ff={"head":git(S,"rev-parse","HEAD"),"tree":git(S,"rev-parse","HEAD^{tree}"),"status":git(S,"status","--porcelain")}
  assert after_ff=={"head":head,"tree":tree,"status":""}
  harness.save(harness.OUT/"source-fast-forward.json",{"before":before_ff,"after":after_ff,"operation":"git merge --ff-only","exit_code":completed.returncode,"old_pins_not_modified":True})
  env=json.loads((harness.BASE/"env.json").read_text());os.environ.update(env)
  for key in list(os.environ):
   if key.startswith("CARGO_PROFILE_") or key.startswith("CARGO_BIN_EXE_"):del os.environ[key]
  os.environ.update(RUSTUP_TOOLCHAIN="1.96.0",CARGO_BUILD_JOBS="2",CARGO_INCREMENTAL="0",CARGO_TARGET_DIR=str(harness.TARGET),CARGO_NET_OFFLINE="true",SOURCE_SHA=head,TESTED_SHA=head,HEPTA_CI_LANE="source-head",PYTHONDONTWRITEBYTECODE="1",GIT_TERMINAL_PROMPT="0")
  harness.result["before"]=harness.snapshot()
  assert harness.result["before"]["head"]==head and harness.result["before"]["tree"]==tree and not harness.result["before"]["status"]
  harness.PUBLIC.mkdir(mode=0o755)
  harness.result["status"]="building-products";harness.persist()
  if not harness.attempt("product-build-and-pin",harness.prepare_products):
   raise RuntimeError("original product preparation failed")
  manifest=json.loads((harness.OUT/"product-manifest.json").read_text())
  assert manifest["head"]==head and manifest["tree"]==tree
  tags=[
   "recipient_action","ledger","run_start","source_cell","handoff","source_observation",
   "run_start_publisher","run_start_deployment","run_start_observation","ledger_observation",
   "run_start_digest","ledger_digest","publication_projection","publication_validation"]
  exact=[("root_stage=historical_task."+name+"\n").encode() for name in tags]
  artifact=manifest["artifacts"]["hepta-authority-host"];elf=pathlib.Path(artifact["pinned"])
  found=[False]*len(exact);tail=b"";digest=hashlib.sha256()
  with elf.open("rb") as stream:
   before=os.fstat(stream.fileno())
   for block in iter(lambda:stream.read(1024*1024),b""):
    digest.update(block);window=tail+block
    for i,tag in enumerate(exact):found[i]=found[i] or tag in window
    tail=window[-256:]
   after=os.fstat(stream.fileno())
  fields=("st_dev","st_ino","st_size","st_mtime_ns","st_ctime_ns")
  assert all(getattr(before,x)==getattr(after,x) for x in fields)
  assert digest.hexdigest()==artifact["sha256"] and all(found)
  harness.save(harness.OUT/"root-elf-fixed-diagnostic-tags.json",{"head":head,"tree":tree,"elf":str(elf),"elf_sha256":digest.hexdigest(),"bytes":before.st_size,"stable_read":True,"fixed_tags":[{"tag":tag.decode().rstrip("\n"),"found":value} for tag,value in zip(exact,found)],"all_14_present":True,"runtime_execution":False})
  harness.result["after"]=harness.snapshot()
  assert harness.result["before"]==harness.result["after"]
  harness.result["status"]="compiled-and-pinned";passed=True
 except Exception as error:
  harness.result["status"]="failed";harness.result["error"]=repr(error)
  (harness.OUT/"driver-error.log").write_text(traceback.format_exc())
 finally:
  harness.result["whole_product_preparation_seconds"]=time.monotonic()-start
  harness.result["finished"]=now();harness.result["passed"]=passed
  harness.result["cost_scope"]="Measured whole product preparation wall, including owned source fast-forward, actual cargo build, pin/readback, and 14-tag ELF verification; excludes QA/research/publication. No complete cost claim."
  harness.persist()
  if lock is not None:lock.close()
 print(json.dumps(harness.result,indent=2))
 return 0 if passed else 1
if __name__=="__main__":sys.exit(main())
