"""Run existing ordinary owner tests against the isolated frozen candidate."""
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

WORK = Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b")
ORIGINAL = Path("/home/qq/hepta-learn-ff41-tools/root_5eeb5d33_completed_chain_v1.py")
ORIGINAL_SHA256 = "ee20bff704f8495fabb6133bbb478d82dd14466303e82c4a93ff2ea276c2b3d1"
HEAD = "ad21d6401fa307831b629b3e71ea1b9c3a350f83"
TREE = "b7409917a4f2c0c411a6ff8dfb93196cebf1e8b0"
RUN_ID = "e6-owner-current-ad21d640-20261118-v9"


def main():
    sys.dont_write_bytecode = True
    assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() == ORIGINAL_SHA256
    spec = importlib.util.spec_from_file_location("original_owner_harness", ORIGINAL)
    harness = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(harness)
    harness.REPO = WORK / "source"
    harness.TARGET = WORK / "target"
    harness.OUT = WORK / "native-v9"
    harness.PUBLIC = Path("/var/tmp") / ("hepta-native-" + RUN_ID)
    harness.ROOT = Path("/run") / ("hepta-daemon-learning-" + RUN_ID)
    harness.HEAD, harness.TREE = HEAD, TREE
    harness.PACKAGES = ["codex-hepta-agentd", "codex-hepta-contracts"]
    harness.OUT.mkdir(exist_ok=False)
    harness.result = dict(
        status="preflight",
        head=HEAD,
        tree=TREE,
        stages=[],
        checks={},
        original_harness=str(ORIGINAL),
        original_harness_sha256=ORIGINAL_SHA256,
        adapter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scope="One original evaluated-NoUpdate whole-cold owner case on the frozen static worker-stage diagnostic candidate; an original Adopt cold case runs once only if NoUpdate passed. Actual production authority/daemon binaries are rebuilt and pinned, with an independently changed authority ELF and static labels required before execution. "
        "Original fixture authorities, original deadlines, no retries. "
        "Cold tests authenticate retained C; they do not execute new D. "
        "No independent-controller qualification, learning-gain or full-cost claim.",
    )
    harness.persist()
    started = time.monotonic()
    lock = None
    mounts_attempted = False
    try:
        assert os.getuid() == os.geteuid() == 1000
        lock = (harness.TARGET / ".hepta-root-native-owner.lock").open("a+b")
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        harness.result["before"] = harness.snapshot()
        before = harness.result["before"]
        assert before["head"] == HEAD and before["tree"] == TREE and not before["status"]
        env = json.loads((harness.BASE / "env.json").read_text())
        os.environ.update(env)
        for key in list(os.environ):
            if key.startswith("CARGO_PROFILE_") or key.startswith("CARGO_BIN_EXE_"):
                del os.environ[key]
        os.environ.update(
            RUSTUP_TOOLCHAIN="1.96.0", CARGO_BUILD_JOBS="2", CARGO_INCREMENTAL="0",
            CARGO_TARGET_DIR=str(harness.TARGET), CARGO_NET_OFFLINE="true",
            SOURCE_SHA=HEAD, TESTED_SHA=HEAD, HEPTA_CI_LANE="source-head",
            PYTHONDONTWRITEBYTECODE="1", GIT_TERMINAL_PROMPT="0",
        )
        sys.path.insert(0, str(harness.REPO / "scripts"))
        from hepta_ci_junit import collect
        harness.collect = collect
        harness.require_roster()
        harness.PUBLIC.mkdir(mode=0o755)
        for name in ("codex-hepta-agentd", "hepta-authority-host", "hepta-joint-propose"):
            for variant in (name, name.replace("-", "_")):
                os.environ["CARGO_BIN_EXE_" + variant] = str(harness.PUBLIC / "unprepared" / name)
        helper = [
            "python3", "scripts/hepta_cell_test_helpers.py", "--package",
            "codex-hepta-infer-worker-host", "--output-dir", str(harness.PUBLIC / "helpers"),
        ]
        harness.result["status"] = "preparing"
        harness.persist()
        for name, action in [
            ("helper-build", lambda: harness.build_helpers(helper)),
            ("helper-verify-and-load", lambda: harness.verify_and_load_helpers(helper)),
            ("product-build-and-pin", harness.prepare_products),
            ("library-binaries-build-uid1000", harness.prepare_library_binaries),
        ]:
            if not harness.attempt(name, action):
                raise RuntimeError("original preparation failed: " + name)
        listing = json.loads((harness.OUT / "library-binaries-build-uid1000.stdout.log").read_text())
        selected = listing["rust-binaries"]["codex-hepta-agentd"]
        assert selected["kind"] == "lib" and selected["binary-id"] == "codex-hepta-agentd"
        executable = Path(selected["binary-path"])
        assert executable.parent == harness.TARGET / "debug/deps"
        rows = []
        for executable in [executable]:
            assert not executable.is_symlink()
            before_elf = executable.stat()
            assert before_elf.st_uid == 1000 and before_elf.st_nlink == 1
            assert before_elf.st_mode & 0o777 in (0o700, 0o701)
            with executable.open("rb") as stream:
                elf_hash = hashlib.file_digest(stream, "sha256").hexdigest()
            executable.chmod(0o701)
            after_elf = executable.stat()
            for field in ("st_dev", "st_ino", "st_size", "st_mtime_ns"):
                assert getattr(before_elf, field) == getattr(after_elf, field)
            with executable.open("rb") as stream:
                assert hashlib.file_digest(stream, "sha256").hexdigest() == elf_hash
            rows.append(dict(executable=str(executable), bytes=before_elf.st_size,
                             sha256=elf_hash, uid=before_elf.st_uid, gid=before_elf.st_gid,
                             mode_before=oct(before_elf.st_mode & 0o777), mode_after="0o701"))
        assert len(rows) == 1
        harness.save(harness.OUT / "source-executable-precondition.json", dict(
            test_executables=rows,
            previous_actual_eacces_record=str(WORK / "native-source-exec-precondition.json"),
            previous_record_sha256=hashlib.sha256(
                (WORK / "native-source-exec-precondition.json").read_bytes()).hexdigest(),
            authority_scope="Only isolated test ELF other-execute, after exact just test preparation. No read/write, private ancestor, owner data, credentials, trust, deadline or receipt change.",
        ))
        product = json.loads((harness.OUT / "product-manifest.json").read_text())
        previous_product = json.loads((WORK / "native-v8/product-manifest.json").read_text())
        authority = product["artifacts"]["hepta-authority-host"]
        assert product["head"] == HEAD and product["tree"] == TREE
        assert authority["sha256"] != previous_product["artifacts"]["hepta-authority-host"]["sha256"], "new production worker-stage diagnostics require a new actual authority ELF"
        labels = [b'root_stage=publication.inspect', b'root_stage=publication.enroll', b'root_stage=publication.deadline', b'root_stage=lane.checkpoint', b'root_stage=historical.worker', b'root_stage=post_a.worker']
        found = set()
        with Path(authority["pinned"]).open("rb") as stream:
            overlap = b""
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                block = overlap + block
                found.update(label for label in labels if label in block)
                overlap = block[-128:]
        assert found == set(labels), "new static error stages absent from actual pinned authority ELF"
        roles = [
            dict(role="A Root and post-A recovery Root", artifact=authority,
                 launch_source="ordinary_q24_process_launch_tests.rs + ordinary_q24_post_a_launch_tests.rs",
                 selector="explicit CARGO_BIN_EXE_hepta-authority-host; same per-run pinned product"),
            dict(role="A daemon and post-A daemon", artifact=product["artifacts"]["codex-hepta-agentd"],
                 launch_source="ordinary_q24_process_launch_tests.rs + ordinary_q24_post_a_launch_tests.rs",
                 selector="explicit CARGO_BIN_EXE_codex-hepta-agentd; same per-run pinned product"),
            dict(role="A independent Observer and post-A Source", artifact=rows[0],
                 launch_source="ordinary_q24_process_tests.rs + ordinary_q24_source_keeper_tests.rs",
                 selector="actual current_exe libtest; Source opens then fd-execs after original UID drop"),
        ]
        harness.save(harness.OUT / "component-executable-bindings.json", dict(
            head=HEAD, tree=TREE, roles=roles,
            authority_labels_observed=[label.decode() for label in labels],
            previous_authority_sha256=previous_product["artifacts"]["hepta-authority-host"]["sha256"],
            scope="Actual compiler output plus unchanged launch route + pinned bytes. Lifecycle PID evidence remains in original JUnit/stdout. No inferred B/C/D or independent certification.",
        ))
        mounts_attempted = True
        if not harness.attempt("root-mount-setup", harness.setup_mounts):
            raise RuntimeError("original mount preparation failed")
        harness.result["status"] = "testing"
        harness.persist()
        args = ["-p", "codex-hepta-agentd", "-p", "codex-hepta-contracts", "--lib",
                "--run-ignored", "only", "--test-threads", "1", "-E"]
        parent = harness.NO_UPDATE_COLD_PARENT
        no_update = harness.attempt("ordinary-whole-cold-no-update", lambda: harness.test(
            "ordinary-whole-cold-no-update", [*args, "test(=" + parent + ")"], [parent]
        ))
        if no_update:
            parent = harness.COLD_PARENT
            harness.attempt("ordinary-whole-cold-adopt", lambda: harness.test(
                "ordinary-whole-cold-adopt", [*args, "test(=" + parent + ")"], [parent]
            ))
        harness.result["status"] = "completed"
    except BaseException as error:
        harness.result.update(status="failed", error=repr(error))
        (harness.OUT / "adapter-error.log").write_text(traceback.format_exc())
    finally:
        if mounts_attempted:
            cleanup = []
            for name in ("witness-bind", "bind"):
                path = str(harness.ROOT / name)
                active = [line.split()[4] for line in Path("/proc/self/mountinfo").read_text().splitlines()]
                if path in active:
                    result = subprocess.run(["sudo", "-n", "umount", path], capture_output=True, text=True)
                    cleanup.append(dict(path=path, code=result.returncode,
                                        stdout=result.stdout, stderr=result.stderr))
            harness.save(harness.OUT / "mount-cleanup.json", cleanup)
            harness.result["cleanup_passed"] = all(item["code"] == 0 for item in cleanup)
        harness.result["after"] = harness.snapshot()
        harness.result["source_unchanged"] = harness.result.get("before") == harness.result["after"]
        harness.result["elapsed_seconds_including_wait"] = time.monotonic() - started
        harness.result["finished"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        harness.result["all_attempted_stages_passed"] = (
            harness.result["status"] == "completed"
            and harness.result["source_unchanged"]
            and harness.result.get("cleanup_passed", True)
            and all(stage.get("passed") is True for stage in harness.result["checks"].values())
        )
        harness.persist()
        if lock is not None:
            lock.close()
        print(json.dumps(harness.result), flush=True)
    return 0 if harness.result["all_attempted_stages_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

