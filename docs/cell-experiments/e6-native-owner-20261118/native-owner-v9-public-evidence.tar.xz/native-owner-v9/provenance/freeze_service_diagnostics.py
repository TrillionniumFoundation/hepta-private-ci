"""Freeze an exact descendant diagnostic source after the separately archived evidence commit."""
import datetime,hashlib,json,os,subprocess,sys,time,traceback
from pathlib import Path
W=Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");S=W/"source"
C9="f7e58512021c7481fa51809bb349f63d93bb1d6c"
EVIDENCE=sys.argv[1];EPATH=sys.argv[2]
assert len(EVIDENCE)==40 and all(x in "0123456789abcdef" for x in EVIDENCE)
assert Path(EPATH).is_absolute() and Path(EPATH).is_dir()
PATCH=W/"owner-service-static-stages-proposal.patch"
assert hashlib.sha256(PATCH.read_bytes()).hexdigest()=="194392cc8be36e3649e2814f7e666cbe8cd13f1768f897402c58d88cec61d77e"
def git(*a):return subprocess.check_output(["git","-C",str(S),*a],text=True).strip()
assert git("rev-parse","HEAD")==C9 and not git("status","--porcelain")
out=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),base=C9,evidence_parent=EVIDENCE,patch_proposal_sha256=hashlib.sha256(PATCH.read_bytes()).hexdigest(),stages=[])
def run(name,argv,cwd=S,env=None):
    start=time.monotonic()
    with (W/(name+".stdout.log")).open("xb") as stdout,(W/(name+".stderr.log")).open("xb") as stderr:
        p=subprocess.run(argv,cwd=cwd,env=env,stdout=stdout,stderr=stderr)
    out["stages"].append(dict(name=name,command=argv,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start))
    assert p.returncode==0,name
try:
    run("service-stage-evidence-fetch",["git","fetch","--no-tags",EPATH,EVIDENCE])
    assert git("rev-parse","FETCH_HEAD")==EVIDENCE
    changed=git("diff","--name-only",C9,EVIDENCE).splitlines()
    assert changed and all(x.startswith("docs/cell-experiments/e6-native-owner-20261118/") for x in changed),changed
    run("service-stage-evidence-fast-forward",["git","merge","--ff-only",EVIDENCE])
    run("service-stage-diagnostic-apply-check",["git","apply","--check",str(PATCH)])
    run("service-stage-diagnostic-apply",["git","apply",str(PATCH)])
    env=os.environ.copy();env.update(json.loads(Path("/home/qq/hepta-learn-ff41-tools/env.json").read_text()))
    env.update(RUSTUP_TOOLCHAIN="1.96.0",CARGO_BUILD_JOBS="2",CARGO_TARGET_DIR=str(W/"target"),CARGO_NET_OFFLINE="true",PYTHONDONTWRITEBYTECODE="1")
    run("service-stage-diagnostic-fmt",["just","fmt"],env=env)
    expected=['codex-rs/hepta-agentd/src/authority_host_generation_publication_runtime.rs', 'codex-rs/hepta-agentd/src/authority_host_generation_publication_transport.rs', 'codex-rs/hepta-agentd/src/authority_host_historical_read_runtime.rs', 'codex-rs/hepta-agentd/src/authority_host_listeners.rs', 'codex-rs/hepta-agentd/src/authority_host_post_a_worker.rs']
    assert git("diff","--name-only").splitlines()==expected
    run("service-stage-diagnostic-diff-check",["git","diff","--check"])
    run("service-stage-diagnostic-add",["git","add","--",*expected])
    run("service-stage-diagnostic-commit",["git","-c","user.name=Codex","-c","user.email=codex@openai.com","commit","-m","Locate native owner service failures before error reduction"])
    head=git("rev-parse","HEAD");tree=git("rev-parse","HEAD^{tree}")
    assert git("rev-parse","HEAD^")==EVIDENCE and not git("status","--porcelain")
    patch=subprocess.check_output(["git","-C",str(S),"diff","--binary",EVIDENCE,head])
    (W/"owner-service-static-stages.patch").write_bytes(patch)
    out.update(status="frozen",head=head,tree=tree,parent=EVIDENCE,files=expected,patch_sha256=hashlib.sha256(patch).hexdigest(),source_status=git("status","--porcelain"),
       scope="Static error-only labels at worker and original reduction boundaries; no original error, predicate, control flow, cleanup, or deadline change. No tests yet.")
    template=(W/"run_native_v9.template.py").read_text()
    assert hashlib.sha256(template.encode()).hexdigest()=="51bd90cbb4f14923cccf3e9e9335b77946d3ba2f2608d65a0ea2a1af5e20f361"
    script=template.replace("__STAGE_HEAD__",head).replace("__STAGE_TREE__",tree).replace("__STAGE_SHORT__",head[:8])
    assert "__STAGE_" not in script
    with (W/"run_native_v9.py").open("x") as stream:stream.write(script)
    out["run_adapter_sha256"]=hashlib.sha256(script.encode()).hexdigest()
except BaseException as e:
    out.update(status="failed",error=repr(e))
    (W/"service-stage-preparation-error.log").write_text(traceback.format_exc())
    raise
finally:
    out["finished"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (W/"owner-service-static-stages-candidate.json").write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps(out),flush=True)

