"""Merge the separately reviewed codec regression and format exactly once."""
import datetime,hashlib,json,os,pathlib,re,subprocess,time
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");S=W/"source"
BASE="1f4bdb211f0fb80fef89f25aef0f969053998b84"
P=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b/historical-task-response-tests-v11-e1-20261118-556e/task-response-codec-regressions.patch")
E1=json.loads(pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b/historical-task-response-tests-v11-e1-20261118-556e/STATIC_REVIEW.json").read_text())
original=json.loads("[\"codex-rs/hepta-agentd/src/authority_host_historical_read.rs\",\"codex-rs/hepta-agentd/src/authority_host_historical_read_runtime.rs\",\"codex-rs/hepta-agentd/src/circuit_task_source_data.rs\",\"codex-rs/hepta-agentd/src/root_generation_initial_frame_tests.rs\",\"codex-rs/hepta-agentd/src/root_generation_publication_stream.rs\",\"codex-rs/hepta-agentd/src/root_historical_ledger_data.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_client.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_protocol.rs\"]")
expected=json.loads("[\"codex-rs/hepta-agentd/src/authority_host_historical_read.rs\",\"codex-rs/hepta-agentd/src/authority_host_historical_read_runtime.rs\",\"codex-rs/hepta-agentd/src/circuit_task.rs\",\"codex-rs/hepta-agentd/src/circuit_task_source_data.rs\",\"codex-rs/hepta-agentd/src/circuit_task_source_data_tests.rs\",\"codex-rs/hepta-agentd/src/root_generation_initial_frame_tests.rs\",\"codex-rs/hepta-agentd/src/root_generation_publication_stream.rs\",\"codex-rs/hepta-agentd/src/root_historical_ledger_data.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_client.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_protocol.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_protocol_tests.rs\"]")
def git(*a):return subprocess.check_output(["git","-C",str(S),*a],text=True).strip()
assert git("rev-parse","HEAD")==BASE
assert git("diff","--name-only").splitlines()==original
actual=subprocess.check_output(["git","-C",str(S),"diff","--binary","--no-ext-diff"])
assert hashlib.sha256(actual).hexdigest()=="3a254241f91ba45a6664d50ab4009125879d3b046be56f471101155e5b0eda92"
assert hashlib.sha256(P.read_bytes()).hexdigest()=="365f44be3829ea23417d5b7402fcdea2e33ffb8c63bd9ef962237b5359f0381f"
for row in E1["files"]:
 assert hashlib.sha256((S/row["path"]).read_bytes()).hexdigest()==row["before_sha256"]
subprocess.run(["git","apply","--check",str(P)],cwd=S,check=True)
subprocess.run(["git","apply",str(P)],cwd=S,check=True)
assert git("diff","--name-only").splitlines()==expected
before={rel:(S/rel).read_text() for rel in expected}
with (W/"task-capacity-v11-combined-before-fmt.patch").open("xb") as f:f.write(subprocess.check_output(["git","-C",str(S),"diff","--binary","--no-ext-diff"]))
env=os.environ.copy();env.update(json.loads(pathlib.Path("/home/qq/hepta-learn-ff41-tools/env.json").read_text()))
env.update(RUSTUP_TOOLCHAIN="1.96.0",CARGO_BUILD_JOBS="2",CARGO_TARGET_DIR=str(W/"target"),CARGO_NET_OFFLINE="true",PYTHONDONTWRITEBYTECODE="1")
start=time.monotonic()
with (W/"task-capacity-v11-fmt.stdout.log").open("xb") as out,(W/"task-capacity-v11-fmt.stderr.log").open("xb") as err:
 result=subprocess.run(["just","fmt"],cwd=S,env=env,stdout=out,stderr=err)
assert result.returncode==0,"just fmt failed"
duration=time.monotonic()-start
assert git("diff","--name-only").splitlines()==expected
rows=[]
for rel in expected:
 after=(S/rel).read_text()
 assert "".join(before[rel].split())=="".join(after.split()),rel
 assert re.findall(r'b?"(?:\\.|[^"\\])*"',before[rel])==re.findall(r'b?"(?:\\.|[^"\\])*"',after),rel
 rows.append(dict(path=rel,before_format_sha256=hashlib.sha256(before[rel].encode()).hexdigest(),after_format_sha256=hashlib.sha256(after.encode()).hexdigest(),format_only_tokens=True,string_literals_identical=True))
patch=subprocess.check_output(["git","-C",str(S),"diff","--binary","--no-ext-diff"])
with (W/"owner-task-response-capacity.patch").open("xb") as f:f.write(patch)
meta=dict(base=BASE,files=rows,patch_path=str(W/"owner-task-response-capacity.patch"),patch_sha256=hashlib.sha256(patch).hexdigest(),patch_bytes=len(patch),fmt_elapsed_seconds=duration,fmt_exit=0,scope="Semantic Task capacity revision plus related tests; this audit proves only formatter preservation from the reviewed combined proposal.",finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
(W/"task-capacity-v11-formatted-review.json").write_text(json.dumps(meta,indent=2)+"\n")
print(json.dumps(meta,indent=2))
