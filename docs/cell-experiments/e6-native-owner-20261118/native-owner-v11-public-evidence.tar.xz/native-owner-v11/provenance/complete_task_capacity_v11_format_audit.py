"""Complete the formatter audit with only three observed trailing-comma normalizations."""
import datetime,hashlib,json,pathlib,re,subprocess
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");S=W/"source";D=W/"task-capacity-v11-review"
E1=W/"historical-task-response-tests-v11-e1-20261118-556e"
BASE="1f4bdb211f0fb80fef89f25aef0f969053998b84"
expected=json.loads("[\"codex-rs/hepta-agentd/src/authority_host_historical_read.rs\",\"codex-rs/hepta-agentd/src/authority_host_historical_read_runtime.rs\",\"codex-rs/hepta-agentd/src/circuit_task.rs\",\"codex-rs/hepta-agentd/src/circuit_task_source_data.rs\",\"codex-rs/hepta-agentd/src/circuit_task_source_data_tests.rs\",\"codex-rs/hepta-agentd/src/root_generation_initial_frame_tests.rs\",\"codex-rs/hepta-agentd/src/root_generation_publication_stream.rs\",\"codex-rs/hepta-agentd/src/root_historical_ledger_data.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_client.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_protocol.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_protocol_tests.rs\"]")
git=lambda *a:subprocess.check_output(["git","-C",str(S),*a],text=True).strip()
assert git("rev-parse","HEAD")==BASE and git("diff","--name-only").splitlines()==expected
rows=[]
for rel in expected:
 source=E1/"proposal"/rel
 if not source.exists():source=D/(pathlib.Path(rel).name+".proposal")
 before=source.read_text();after=(S/rel).read_text()
 b="".join(before.split());a="".join(after.split());normalizations=[]
 if rel.endswith("/root_historical_task_read_protocol_tests.rs"):
  for ty in ("RootHistoricalLedgerReadDataV1","RootHistoricalTaskPublicationDataV1"):
   old=ty+"::JSON_BOUND,),";new=ty+"::JSON_BOUND),"
   assert a.count(old)==1,(rel,old)
   a=a.replace(old,new,1);normalizations.append(dict(side="after",old=old,new=new))
  old="publication_data_fixture_with_observation(&vec![b'x';16*1024],)";new="publication_data_fixture_with_observation(&vec![b'x';16*1024])"
  assert b.count(old)==1
  b=b.replace(old,new,1);normalizations.append(dict(side="before",old=old,new=new))
 assert a==b,rel
 assert re.findall(r'b?"(?:\\.|[^"\\])*"',before)==re.findall(r'b?"(?:\\.|[^"\\])*"',after),rel
 rows.append(dict(path=rel,before_format_sha256=hashlib.sha256(before.encode()).hexdigest(),after_format_sha256=hashlib.sha256(after.encode()).hexdigest(),format_only_tokens=True,string_literals_identical=True,exact_trailing_comma_normalizations=normalizations))
patch=subprocess.check_output(["git","-C",str(S),"diff","--binary","--no-ext-diff"])
with (W/"owner-task-response-capacity.patch").open("xb") as f:f.write(patch)
copies=[
 ("dpty-fe4b6a345e0ef36d0c52ac486df39767e4120ea2c3452e2c169991fa9123816d","task-capacity-v11-format-audit-first.raw.log"),
 ("dpty-bac053bc7dee582c7fe835cbaab541aeaeeeb5956206d372e528d2f3e091e12d","task-capacity-v11-format-delta.raw.log"),
]
for session,name in copies:
 p=pathlib.Path("/home/qq/.local/state/hepta-runtime-mac-worker/terminals")/session/"output.log"
 with (W/name).open("xb") as f:f.write(p.read_bytes())
meta=dict(base=BASE,files=rows,patch_path=str(W/"owner-task-response-capacity.patch"),patch_sha256=hashlib.sha256(patch).hexdigest(),patch_bytes=len(patch),fmt_exit=0,fmt_elapsed_seconds=None,fmt_elapsed_limitation="Initial audit failed after successful formatter return before persisting elapsed; original PTY failure and exact style delta retained. Formatter was not rerun.",scope="Semantic Task capacity revision plus related tests. Exact three observed trailing-comma style changes normalized only for audit; every other non-whitespace token and every string literal remain identical to combined proposal.",finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (W/"task-capacity-v11-formatted-review.json").open("x") as f:f.write(json.dumps(meta,indent=2)+"\n")
print(json.dumps(meta,indent=2))
