"""Freeze the reviewed paired Task-only capacity repair before all new tests."""
import ast,datetime,hashlib,json,os,pathlib,subprocess,time,traceback
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");S=W/"source"
BASE="1f4bdb211f0fb80fef89f25aef0f969053998b84"
SHA="06d886cfe26999ed5ba27c5c38a0800622245becfa96a981c16308b70e4ae7ca"
EXPECTED=json.loads("[\"codex-rs/hepta-agentd/src/authority_host_historical_read.rs\",\"codex-rs/hepta-agentd/src/authority_host_historical_read_runtime.rs\",\"codex-rs/hepta-agentd/src/circuit_task.rs\",\"codex-rs/hepta-agentd/src/circuit_task_source_data.rs\",\"codex-rs/hepta-agentd/src/circuit_task_source_data_tests.rs\",\"codex-rs/hepta-agentd/src/root_generation_initial_frame_tests.rs\",\"codex-rs/hepta-agentd/src/root_generation_publication_stream.rs\",\"codex-rs/hepta-agentd/src/root_historical_ledger_data.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_client.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_protocol.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_protocol_tests.rs\"]")
def git(*a):return subprocess.check_output(["git","-C",str(S),*a],text=True).strip()
def patch():return subprocess.check_output(["git","-C",str(S),"diff","--binary","--no-ext-diff",BASE])
assert git("rev-parse","HEAD")==BASE
assert git("diff","--name-only").splitlines()==EXPECTED
assert not git("diff","--cached","--name-only")
assert hashlib.sha256(patch()).hexdigest()==SHA
assert hashlib.sha256((W/"owner-task-response-capacity.patch").read_bytes()).hexdigest()==SHA
review=json.loads((W/"task-capacity-v11-formatted-review.json").read_text())
assert review["fmt_exit"]==0 and review["patch_sha256"]==SHA
templates={}
for name in ("run_native_v11","archive_native_v11","prepare_v11_publication"):
 t=(W/(name+".template.py")).read_text();ast.parse(t);templates[name]=t
out=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=BASE,patch_sha256=SHA,stages=[],files=EXPECTED,template_sha256={k:hashlib.sha256(v.encode()).hexdigest() for k,v in templates.items()},
 scope="Paired v1 Task capacity revision. Task limit28933 derives from original12288/16384 DTO caps+canonical261 envelope. Default CURRENT/other operations, request/bootstrap limits, original authentication, refusal and deadlines unchanged. Related tests and original cases have not yet run.")
def run(name,argv):
 start=time.monotonic()
 with (W/(name+".stdout.log")).open("xb") as stdout,(W/(name+".stderr.log")).open("xb") as stderr:
  p=subprocess.run(argv,cwd=S,stdout=stdout,stderr=stderr)
 out["stages"].append(dict(name=name,command=argv,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start))
 assert p.returncode==0,name
try:
 run("task-capacity-v11-diff-check",["git","diff","--check"])
 run("task-capacity-v11-add",["git","add","--",*EXPECTED])
 run("task-capacity-v11-commit",["git","-c","user.name=Codex","-c","user.email=codex@openai.com","commit","-m","Compose bounded complete historical Task responses"])
 head=git("rev-parse","HEAD");tree=git("rev-parse","HEAD^{tree}")
 assert git("rev-parse","HEAD^")==BASE and not git("status","--porcelain")
 assert hashlib.sha256(patch()).hexdigest()==SHA
 out.update(status="frozen",head=head,tree=tree,source_status="")
 for name,t in templates.items():
  text=t.replace("__STAGE_HEAD__",head).replace("__STAGE_TREE__",tree).replace("__STAGE_SHORT__",head[:8]).replace("__SOURCE_HEAD__",head)
  assert "__STAGE_" not in text and "__SOURCE_HEAD__" not in text
  ast.parse(text)
  with (W/(name+".py")).open("x") as f:f.write(text)
  if name=="run_native_v11":out["run_adapter_sha256"]=hashlib.sha256(text.encode()).hexdigest()
except BaseException as e:
 out.update(status="failed",error=repr(e))
 (W/"task-capacity-v11-freeze-error.log").write_text(traceback.format_exc())
 raise
finally:
 out["finished"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (W/"owner-task-response-capacity-candidate.json").open("x") as f:f.write(json.dumps(out,indent=2)+"\n")
 print(json.dumps(out,indent=2),flush=True)
