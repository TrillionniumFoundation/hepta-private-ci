"""Freeze an exact descendant diagnostic source after the separately archived evidence commit."""
import datetime,hashlib,json,os,subprocess,sys,time,traceback
from pathlib import Path
W=Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");S=W/"source"
C9="ad21d6401fa307831b629b3e71ea1b9c3a350f83"
EVIDENCE=sys.argv[1];EPATH=sys.argv[2]
assert len(EVIDENCE)==40 and all(x in "0123456789abcdef" for x in EVIDENCE)
assert Path(EPATH).is_absolute() and Path(EPATH).is_dir()
PATCH=W/"owner-historical-static-stages-proposal.patch"
assert hashlib.sha256(PATCH.read_bytes()).hexdigest()=="1fc44b9d0b7e9eabf2ccc69853002db5fb5dbdd47deca79fb5c409a934d177c3"
def git(*a):return subprocess.check_output(["git","-C",str(S),*a],text=True).strip()
assert git("rev-parse","HEAD")==C9 and not git("status","--porcelain")
out=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),base=C9,evidence_parent=EVIDENCE,patch_proposal_sha256=hashlib.sha256(PATCH.read_bytes()).hexdigest(),stages=[])
def run(name,argv,cwd=S,env=None):
    start=time.monotonic()
    with (W/(name+".stdout.log")).open("xb") as stdout,(W/(name+".stderr.log")).open("xb") as stderr:
        p=subprocess.run(argv,cwd=cwd,env=env,stdout=stdout,stderr=stderr)
    out["stages"].append(dict(name=name,command=argv,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start))
    assert p.returncode==0,name
try:
    run("historical-stage-evidence-fetch",["git","fetch","--no-tags",EPATH,EVIDENCE])
    assert git("rev-parse","FETCH_HEAD")==EVIDENCE
    changed=git("diff","--name-only",C9,EVIDENCE).splitlines()
    assert changed and all(x.startswith("docs/cell-experiments/e6-native-owner-20261118/") for x in changed),changed
    run("historical-stage-evidence-fast-forward",["git","merge","--ff-only",EVIDENCE])
    run("historical-stage-diagnostic-apply-check",["git","apply","--check",str(PATCH)])
    run("historical-stage-diagnostic-apply",["git","apply",str(PATCH)])
    env=os.environ.copy();env.update(json.loads(Path("/home/qq/hepta-learn-ff41-tools/env.json").read_text()))
    env.update(RUSTUP_TOOLCHAIN="1.96.0",CARGO_BUILD_JOBS="2",CARGO_TARGET_DIR=str(W/"target"),CARGO_NET_OFFLINE="true",PYTHONDONTWRITEBYTECODE="1")
    run("historical-stage-diagnostic-fmt",["just","fmt"],env=env)
    expected=["codex-rs/hepta-agentd/src/authority_host_historical_ledger_history.rs","codex-rs/hepta-agentd/src/authority_host_historical_read.rs","codex-rs/hepta-agentd/src/authority_host_historical_task.rs"]
    assert git("diff","--name-only").splitlines()==expected
    run("historical-stage-diagnostic-diff-check",["git","diff","--check"])

    import re
    def strip_diagnostics(source):
        count=0
        while ".inspect_err(" in source:
            start=source.index(".inspect_err("); opening=start+len(".inspect_err")
            depth=0; quoted=False; escaped=False
            for end in range(opening,len(source)):
                c=source[end]
                if quoted:
                    if escaped: escaped=False
                    elif c=="\\": escaped=True
                    elif c=='"': quoted=False
                elif c=='"': quoted=True
                elif c=="(": depth+=1
                elif c==")":
                    depth-=1
                    if depth==0: break
            else: raise AssertionError("unbalanced diagnostic")
            added=source[start:end+1]
            assert "root_stage=" in added and "write_all" in added
            source=source[:start]+source[end+1:];count+=1
        return source.replace("use std::io::Write;\n",""),count
    audit_rows=[]
    for rel in expected:
        before=subprocess.check_output(["git","-C",str(S),"show",EVIDENCE+":"+rel],text=True)
        after=(S/rel).read_text()
        assert ".inspect_err(" not in before
        restored,count=strip_diagnostics(after)
        assert count>0
        assert "".join(restored.split())=="".join(before.split()),rel
        assert re.findall(r'b?"(?:\\.|[^"\\])*"',before)==re.findall(r'b?"(?:\\.|[^"\\])*"',restored),rel
        audit_rows.append(dict(path=rel,before_sha256=hashlib.sha256(before.encode()).hexdigest(),after_sha256=hashlib.sha256(after.encode()).hexdigest(),static_inspections=count,diagnostics_removed_equivalent_ignoring_whitespace=True,original_string_literal_sequence_identical=True))
    (W/"historical-stage-formatted-review.json").write_text(json.dumps(dict(parent=EVIDENCE,files=audit_rows,scope="Static structural audit; no runtime qualification"),indent=2)+"\n")
    run("historical-stage-diagnostic-add",["git","add","--",*expected])
    run("historical-stage-diagnostic-commit",["git","-c","user.name=Codex","-c","user.email=codex@openai.com","commit","-m","Locate original historical task failures without changing readers"])
    head=git("rev-parse","HEAD");tree=git("rev-parse","HEAD^{tree}")
    assert git("rev-parse","HEAD^")==EVIDENCE and not git("status","--porcelain")
    patch=subprocess.check_output(["git","-C",str(S),"diff","--binary",EVIDENCE,head])
    (W/"owner-historical-static-stages.patch").write_bytes(patch)
    out.update(status="frozen",head=head,tree=tree,parent=EVIDENCE,files=expected,patch_sha256=hashlib.sha256(patch).hexdigest(),source_status=git("status","--porcelain"),
       scope="Static error-only labels at worker and original reduction boundaries; no original error, predicate, control flow, cleanup, or deadline change. No tests yet.")
    template=(W/"run_native_v10.template.py").read_text()
    assert hashlib.sha256(template.encode()).hexdigest()=="30c2cad0b4ccdf93a4c75e7ec0b029a3bc38e99c92998be3de0b38a49525118d"
    script=template.replace("__STAGE_HEAD__",head).replace("__STAGE_TREE__",tree).replace("__STAGE_SHORT__",head[:8])
    assert "__STAGE_" not in script
    with (W/"run_native_v10.py").open("x") as stream:stream.write(script)
    out["run_adapter_sha256"]=hashlib.sha256(script.encode()).hexdigest()
    for stem in ("archive_native_v10","prepare_v10_publication"):
        body=(W/(stem+".template.py")).read_text().replace("__SOURCE_HEAD__",head)
        assert "__SOURCE_HEAD__" not in body
        with (W/(stem+".py")).open("x") as stream:stream.write(body)

except BaseException as e:
    out.update(status="failed",error=repr(e))
    (W/"historical-stage-preparation-error.log").write_text(traceback.format_exc())
    raise
finally:
    out["finished"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (W/"owner-historical-static-stages-candidate.json").write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps(out),flush=True)

