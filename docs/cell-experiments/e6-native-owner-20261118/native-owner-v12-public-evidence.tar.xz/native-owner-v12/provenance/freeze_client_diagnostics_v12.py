"""Freeze the reviewed error-only historical client and Dataset diagnostic before its original case."""
import ast,datetime,hashlib,json,os,pathlib,subprocess,time,traceback
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");S=W/"source"
BASE="b01b277b7c887a65a2159b37074eb7e0564e09e0"
SHA="533d7c0739a317b4e19784f992fac4b03f90e71c59cbc8ec4edd05bf884c353e"
EXPECTED=json.loads("[\"codex-rs/hepta-agentd/src/cell_q24_dataset_historical_ledger.rs\",\"codex-rs/hepta-agentd/src/learning_iteration_historical_source.rs\",\"codex-rs/hepta-agentd/src/root_historical_learning_operation.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_client.rs\"]")
def git(*a):return subprocess.check_output(["git","-C",str(S),*a],text=True).strip()
def patch():return subprocess.check_output(["git","-C",str(S),"diff","--binary","--no-ext-diff",BASE])
assert git("rev-parse","HEAD")==BASE
assert git("diff","--name-only").splitlines()==EXPECTED
assert not git("diff","--cached","--name-only")
assert hashlib.sha256(patch()).hexdigest()==SHA
assert hashlib.sha256((W/"owner-client-refusal-stages.patch").read_bytes()).hexdigest()==SHA
review=json.loads((W/"client-v12-formatted-review-final.json").read_text())
assert review["fmt_exit"]==0 and review["patch_sha256"]==SHA
templates={}
for name in ("run_native_v12","archive_native_v12","prepare_v12_publication"):
 t=(W/(name+".template.py")).read_text();ast.parse(t);templates[name]=t
out=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=BASE,patch_sha256=SHA,stages=[],files=EXPECTED,template_sha256={k:hashlib.sha256(v.encode()).hexdigest() for k,v in templates.items()},
 scope="Error-only client/operation/Dataset observations at original failures. Original Results/postcheck priority/fence/drop/identity/deadline/64-read and frame/component budgets unchanged. No new case has yet run. Earlier v11 codec tests are not inherited or repeated.")
def run(name,argv):
 start=time.monotonic()
 with (W/(name+".stdout.log")).open("xb") as stdout,(W/(name+".stderr.log")).open("xb") as stderr:
  p=subprocess.run(argv,cwd=S,stdout=stdout,stderr=stderr)
 out["stages"].append(dict(name=name,command=argv,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start))
 assert p.returncode==0,name
try:
 run("client-v12-diff-check",["git","diff","--check"])
 run("client-v12-add",["git","add","--",*EXPECTED])
 run("client-v12-commit",["git","-c","user.name=Codex","-c","user.email=codex@openai.com","commit","-m","Trace original historical client and Dataset refusals"])
 head=git("rev-parse","HEAD");tree=git("rev-parse","HEAD^{tree}")
 assert git("rev-parse","HEAD^")==BASE and not git("status","--porcelain")
 assert hashlib.sha256(patch()).hexdigest()==SHA
 out.update(status="frozen",head=head,tree=tree,source_status="")
 for name,t in templates.items():
  text=t.replace("__STAGE_HEAD__",head).replace("__STAGE_TREE__",tree).replace("__STAGE_SHORT__",head[:8]).replace("__SOURCE_HEAD__",head)
  assert "__STAGE_" not in text and "__SOURCE_HEAD__" not in text
  ast.parse(text)
  with (W/(name+".py")).open("x") as f:f.write(text)
  if name=="run_native_v12":out["run_adapter_sha256"]=hashlib.sha256(text.encode()).hexdigest()
except BaseException as e:
 out.update(status="failed",error=repr(e))
 (W/"client-v12-freeze-error.log").write_text(traceback.format_exc())
 raise
finally:
 out["finished"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (W/"owner-client-refusal-stages-candidate.json").open("x") as f:f.write(json.dumps(out,indent=2)+"\n")
 print(json.dumps(out,indent=2),flush=True)
