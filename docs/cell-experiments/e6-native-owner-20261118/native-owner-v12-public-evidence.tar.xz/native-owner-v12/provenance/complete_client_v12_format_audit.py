"""Finish v12 formatter audit with two exact pure-expression match-arm normalizations."""
import datetime,hashlib,json,pathlib,re,subprocess
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");S=W/"source"
BASE="e21ca2d9718c9c3506f6301449b29e6471a5cc22";PARENT="b01b277b7c887a65a2159b37074eb7e0564e09e0"
FILES=json.loads("[\"codex-rs/hepta-agentd/src/cell_q24_dataset_historical_ledger.rs\",\"codex-rs/hepta-agentd/src/learning_iteration_historical_source.rs\",\"codex-rs/hepta-agentd/src/root_historical_learning_operation.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_client.rs\"]")
git=lambda *a:subprocess.check_output(["git","-C",str(S),*a],text=True).strip()
assert git("rev-parse","HEAD")==PARENT and git("diff","--name-only").splitlines()==FILES
initial=json.loads((W/"client-v12-formatted-review.json").read_text())
assert initial["status"]=="failed" and initial["stages"][-1]["name"]=="client-v12-fmt" and initial["stages"][-1]["exit_code"]==0
def strip(source):
 count=0
 while ".inspect_err(" in source:
  start=source.index(".inspect_err(");opening=start+len(".inspect_err")
  depth=0;quoted=False;escaped=False
  for end in range(opening,len(source)):
   c=source[end]
   if quoted:
    if escaped:escaped=False
    elif c=="\\":escaped=True
    elif c=='"':quoted=False
   elif c=='"':quoted=True
   elif c=="(":depth+=1
   elif c==")":
    depth-=1
    if depth==0:break
  else:raise AssertionError("unbalanced diagnostic")
  removed=source[start:end+1]
  assert "daemon_stage=" in removed and ("write_all" in removed or "writeln!" in removed)
  source=source[:start]+source[end+1:];count+=1
 plain=0
 for label in ("historical.operation.fence","historical.read_for.fence"):
  pattern=r'(?m)^[ \t]*let _ = std::io::stderr\(\)\s*\.write_all\(\s*b"daemon_stage='+re.escape(label)+r'\\n",?\s*\);\n'
  source,n=re.subn(pattern,"",source);plain+=n
 source=source.replace("use std::io::Write;\n","")
 return source,count,plain
rows=[]
for rel in FILES:
 original=subprocess.check_output(["git","-C",str(S),"show",BASE+":"+rel],text=True)
 after=(S/rel).read_text();restored,count,plain=strip(after)
 before_tokens="".join(original.split());tokens="".join(restored.split());norm=[]
 if rel.endswith("/root_historical_task_read_client.rs"):
  pairs=[
   ("HistoricalReadOperationV1::Task=>Reply::Task(Box::new(require_complete_reply(&bytes,request_id,&self.profile)?,)),",
    "HistoricalReadOperationV1::Task=>Reply::Task(Box::new(require_complete_reply(&bytes,request_id,&self.profile,)?)),"),
   ("HistoricalReadOperationV1::LearningTrust=>Reply::LearningTrust(Box::new(require_original_trust_reply(&bytes,request_id,&self.profile,&self.learning_trust,&self.initial,)?,)),",
    "HistoricalReadOperationV1::LearningTrust=>{Reply::LearningTrust(Box::new(require_original_trust_reply(&bytes,request_id,&self.profile,&self.learning_trust,&self.initial,)?))}")
  ]
  for observed,original_arm in pairs:
   assert tokens.count(observed)==1 and before_tokens.count(original_arm)==1
   tokens=tokens.replace(observed,original_arm,1)
   norm.append(dict(observed=observed,original=original_arm))
 assert tokens==before_tokens,rel
 assert re.findall(r'b?"(?:\\.|[^"\\])*"',original)==re.findall(r'b?"(?:\\.|[^"\\])*"',restored),rel
 rows.append(dict(path=rel,original_sha256=hashlib.sha256(original.encode()).hexdigest(),formatted_sha256=hashlib.sha256(after.encode()).hexdigest(),inspect_err=count,plain_fence_logs=plain,original_tokens_identical_after_exact_rustfmt_arm_normalizations=True,original_string_literals_identical=True,exact_format_normalizations=norm))
patch=subprocess.check_output(["git","-C",str(S),"diff","--binary","--no-ext-diff"])
with (W/"owner-client-refusal-stages.patch").open("xb") as f:f.write(patch)
raw=pathlib.Path("/home/qq/.local/state/hepta-runtime-mac-worker/terminals/dpty-f684243eac31b92e591b2a594dbd574f30d32471628c77a44c5ba21307afa91e/output.log").read_bytes()
with (W/"client-v12-initial-format-audit.raw.log").open("xb") as f:f.write(raw)
meta=dict(base=BASE,parent=PARENT,files=rows,patch_bytes=len(patch),patch_sha256=hashlib.sha256(patch).hexdigest(),fmt_exit=0,fmt_elapsed_seconds=initial["stages"][-1]["elapsed_seconds"],original_audit_failure_preserved=True,formatter_repeated=False,scope="Error-only diagnostics. Two exact rustfmt match-arm changes only: trailing commas, and an expression-only LearningTrust block folded into the same match result. Remaining original non-whitespace tokens and complete string literal sequence identical. No tests/build yet.",finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (W/"client-v12-formatted-review-final.json").open("x") as f:f.write(json.dumps(meta,indent=2)+"\n")
print(json.dumps(meta,indent=2))
