"""Apply reviewed diagnostic-only proposals and retain a mechanical source audit."""
import datetime,hashlib,json,os,pathlib,re,subprocess,time,traceback
W=pathlib.Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");S=W/"source"
BASE="e21ca2d9718c9c3506f6301449b29e6471a5cc22";PARENT="b01b277b7c887a65a2159b37074eb7e0564e09e0"
PATCHES=json.loads("[[\"historical-client-v12-review/historical-client-static-stages-inline.patch\",\"55d360ae891f7bd402057f336c8005b83f775c77f78b4a0a4a408bdb5ce0d633\"],[\"chain-client-diag-v12-20261118-556e5fc/operation-refusal-stages.patch\",\"0abdfdcc857409050610082b10c7c2dafc76b7917b797aade2e789d41088f26c\"],[\"historical-dataset-client-v12-e1-20261118-556e/dataset-callback-static-stages.patch\",\"575189ed80032b9bced24af3ee7e90bf1dca4fdfbbb3c4aa52e91842e43587a3\"]]");FILES=json.loads("[\"codex-rs/hepta-agentd/src/cell_q24_dataset_historical_ledger.rs\",\"codex-rs/hepta-agentd/src/learning_iteration_historical_source.rs\",\"codex-rs/hepta-agentd/src/root_historical_learning_operation.rs\",\"codex-rs/hepta-agentd/src/root_historical_task_read_client.rs\"]")
def git(*a):return subprocess.check_output(["git","-C",str(S),*a],text=True).strip()
assert git("rev-parse","HEAD")==BASE and not git("status","--porcelain")
assert git("rev-parse",PARENT+"^")==BASE
assert all(x.startswith("docs/cell-experiments/e6-native-owner-20261118/") for x in git("diff","--name-only",BASE,PARENT).splitlines())
original={rel:subprocess.check_output(["git","-C",str(S),"show",BASE+":"+rel],text=True) for rel in FILES}
out=dict(base=BASE,parent=PARENT,started=datetime.datetime.now(datetime.timezone.utc).isoformat(),stages=[])
def run(name,argv,env=None):
 start=time.monotonic()
 with (W/(name+".stdout.log")).open("xb") as stdout,(W/(name+".stderr.log")).open("xb") as stderr:
  p=subprocess.run(argv,cwd=S,env=env,stdout=stdout,stderr=stderr)
 out["stages"].append(dict(name=name,command=argv,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start))
 assert p.returncode==0,name
def strip(source):
 count=0
 while ".inspect_err(" in source:
  start=source.index(".inspect_err(");opening=start+len(".inspect_err")
  depth=0;quoted=False;escaped=False
  for end in range(opening,len(source)):
   c=source[end]
   if quoted:
    if escaped:escaped=False
    elif c=="\\":escaped=True
    elif c=='"':quoted=False
   elif c=='"':quoted=True
   elif c=="(":depth+=1
   elif c==")":
    depth-=1
    if depth==0:break
  else:raise AssertionError("unbalanced diagnostic")
  removed=source[start:end+1]
  assert "daemon_stage=" in removed and ("write_all" in removed or "writeln!" in removed)
  source=source[:start]+source[end+1:];count+=1
 plain=0
 for label in ("historical.operation.fence","historical.read_for.fence"):
  pattern=r'(?m)^[ \t]*let _ = std::io::stderr\(\)\s*\.write_all\(\s*b"daemon_stage='+re.escape(label)+r'\\n",?\s*\);\n'
  source,n=re.subn(pattern,"",source);plain+=n
 source=source.replace("use std::io::Write;\n","")
 return source,count,plain
try:
 run("client-v12-evidence-fast-forward",["git","merge","--ff-only",PARENT])
 for i,(path,sha) in enumerate(PATCHES):
  p=W/path;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha
  run("client-v12-apply-check-"+str(i),["git","apply","--check",str(p)])
  run("client-v12-apply-"+str(i),["git","apply",str(p)])
 assert git("diff","--name-only").splitlines()==FILES
 pre=[]
 for rel in FILES:
  text=(S/rel).read_text();restored,count,plain=strip(text)
  assert restored==original[rel],(rel,"preformat byte restore")
  pre.append(dict(path=rel,inspect_err=count,plain_fence_logs=plain,exact_bytes_restored=True,proposal_sha256=hashlib.sha256(text.encode()).hexdigest()))
 proposal=subprocess.check_output(["git","-C",str(S),"diff","--binary","--no-ext-diff"])
 (W/"owner-client-refusal-stages-proposal.patch").write_bytes(proposal)
 env=os.environ.copy();env.update(json.loads(pathlib.Path("/home/qq/hepta-learn-ff41-tools/env.json").read_text()))
 env.update(RUSTUP_TOOLCHAIN="1.96.0",CARGO_BUILD_JOBS="2",CARGO_TARGET_DIR=str(W/"target"),CARGO_NET_OFFLINE="true",PYTHONDONTWRITEBYTECODE="1")
 run("client-v12-fmt",["just","fmt"],env=env)
 assert git("diff","--name-only").splitlines()==FILES
 rows=[]
 for rel in FILES:
  after=(S/rel).read_text();restored,count,plain=strip(after)
  if "".join(restored.split())!="".join(original[rel].split()):
   import difflib
   (W/("client-v12-format-delta-"+pathlib.Path(rel).name+".txt")).write_text("".join(difflib.unified_diff(original[rel].splitlines(True),restored.splitlines(True))))
   raise AssertionError((rel,"post-format token difference; exact delta retained"))
  assert re.findall(r'b?"(?:\\.|[^"\\])*"',original[rel])==re.findall(r'b?"(?:\\.|[^"\\])*"',restored),rel
  rows.append(dict(path=rel,original_sha256=hashlib.sha256(original[rel].encode()).hexdigest(),formatted_sha256=hashlib.sha256(after.encode()).hexdigest(),inspect_err=count,plain_fence_logs=plain,original_nonwhitespace_tokens_restored=True,original_string_literals_identical=True))
 patch=subprocess.check_output(["git","-C",str(S),"diff","--binary","--no-ext-diff"])
 (W/"owner-client-refusal-stages.patch").write_bytes(patch)
 out.update(status="reviewed-formatted",preformat=pre,files=rows,patch_sha256=hashlib.sha256(patch).hexdigest(),patch_bytes=len(patch),source_head=git("rev-parse","HEAD"),built=False,tested=False)
except BaseException as e:
 out.update(status="failed",error=repr(e))
 (W/"client-v12-assembly-error.log").write_text(traceback.format_exc())
 raise
finally:
 out["finished"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (W/"client-v12-formatted-review.json").write_text(json.dumps(out,indent=2)+"\n")
 print(json.dumps(out,indent=2))
