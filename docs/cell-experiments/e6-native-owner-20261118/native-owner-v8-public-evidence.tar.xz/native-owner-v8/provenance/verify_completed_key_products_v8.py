import datetime,hashlib,json,stat,subprocess,time
from pathlib import Path
w=Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b");r=w/"native-v8"
head="f7e58512021c7481fa51809bb349f63d93bb1d6c";tree="ef1ef15d5f2ef5dadefb5bdd0d73c255a7d0678f"
manifest=json.loads((r/"product-manifest.json").read_text());old=json.loads((w/"native-v7/product-manifest.json").read_text())
assert manifest["head"]==head and manifest["tree"]==tree
def git(*a):return subprocess.check_output(["git","-C",str(w/"source"),*a],text=True).strip()
assert git("rev-parse","HEAD")==head and git("rev-parse","HEAD^{tree}")==tree and not git("status","--porcelain")
started=time.monotonic();cpu=time.process_time();rows=[];domain=b"hepta.root.initial-data-refusal.completed-learning.v1\0"
for name,a in manifest["artifacts"].items():
 p=Path(a["pinned"]);before=p.stat();assert not p.is_symlink() and stat.S_ISREG(before.st_mode)
 sha=hashlib.sha256();seen=False;overlap=b""
 with p.open("rb") as stream:
  for block in iter(lambda:stream.read(1024*1024),b""):
   sha.update(block)
   if name=="hepta-authority-host":seen=seen or domain in overlap+block;overlap=block[-128:]
 after=p.stat()
 assert all(getattr(before,k)==getattr(after,k) for k in ("st_dev","st_ino","st_size","st_mtime_ns","st_ctime_ns"))
 digest=sha.hexdigest();assert digest==a["sha256"] and before.st_size==a["bytes"]
 if name=="hepta-authority-host":
  assert digest!=old["artifacts"][name]["sha256"] and seen
 rows.append(dict(name=name,path=str(p),sha256=digest,bytes=before.st_size,uid=before.st_uid,gid=before.st_gid,
  mode=oct(before.st_mode&0o7777),nlink=before.st_nlink,dev=before.st_dev,ino=before.st_ino,mtime_ns=before.st_mtime_ns,ctime_ns=before.st_ctime_ns,
  unchanged_during_read=True,previous_v7_sha256=old["artifacts"][name]["sha256"],completed_key_domain_present=seen if name=="hepta-authority-host" else None))
assert git("rev-parse","HEAD")==head and not git("status","--porcelain")
out=dict(status="verified",head=head,tree=tree,source_unchanged=True,products=rows,domain="hepta.root.initial-data-refusal.completed-learning.v1\\0",
 scope="Independent read-only actual pinned product hash/domain verification; no owner/test execution or business qualification.",
 elapsed_seconds=time.monotonic()-started,checker_cpu_seconds=time.process_time()-cpu,finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
(r/"completed-owner-domain-elf-check.json").write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out),flush=True)
