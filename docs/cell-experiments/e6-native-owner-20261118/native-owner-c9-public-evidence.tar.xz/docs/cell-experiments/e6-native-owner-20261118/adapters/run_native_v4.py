"""Run existing ordinary owner tests against the isolated frozen candidate."""
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

WORK = Path("/home/qq/e6-owner-current-20261118-556e5fc18a5b")
ORIGINAL = Path("/home/qq/hepta-learn-ff41-tools/root_5eeb5d33_completed_chain_v1.py")
ORIGINAL_SHA256 = "ee20bff704f8495fabb6133bbb478d82dd14466303e82c4a93ff2ea276c2b3d1"
HEAD = "74a611ae9d5197ddbe193603b6e7237210fb5a5a"
TREE = "f2f3c957bc361ebc14cab53e59a4a1db0bdd032c"
RUN_ID = "e6-owner-current-74a611ae-20261118-v4"


def main():
    sys.dont_write_bytecode = True
    assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() == ORIGINAL_SHA256
    spec = importlib.util.spec_from_file_location("original_owner_harness", ORIGINAL)
    harness = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(harness)
    harness.REPO = WORK / "source"
    harness.TARGET = WORK / "target"
    harness.OUT = WORK / "native-v4"
    harness.PUBLIC = Path("/var/tmp") / ("hepta-native-" + RUN_ID)
    harness.ROOT = Path("/run") / ("hepta-daemon-learning-" + RUN_ID)
    harness.HEAD, harness.TREE = HEAD, TREE
    harness.PACKAGES = ["codex-hepta-agentd", "codex-hepta-contracts"]
    harness.OUT.mkdir(exist_ok=False)
    harness.result = dict(
        status="preflight",
        head=HEAD,
        tree=TREE,
        stages=[],
        checks={},
        original_harness=str(ORIGINAL),
        original_harness_sha256=ORIGINAL_SHA256,
        adapter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scope="Existing original-pair error regression and evaluated-NoUpdate ordinary owner cold test on a new frozen diagnostic candidate. "
        "Original fixture authorities, original deadlines, no retries. "
        "Cold tests authenticate retained C; they do not execute new D. "
        "No independent-controller qualification, learning-gain or full-cost claim.",
    )
    harness.persist()
    started = time.monotonic()
    lock = None
    mounts_attempted = False
    try:
        assert os.getuid() == os.geteuid() == 1000
        lock = (harness.TARGET / ".hepta-root-native-owner.lock").open("a+b")
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        harness.result["before"] = harness.snapshot()
        before = harness.result["before"]
        assert before["head"] == HEAD and before["tree"] == TREE and not before["status"]
        env = json.loads((harness.BASE / "env.json").read_text())
        os.environ.update(env)
        for key in list(os.environ):
            if key.startswith("CARGO_PROFILE_") or key.startswith("CARGO_BIN_EXE_"):
                del os.environ[key]
        os.environ.update(
            RUSTUP_TOOLCHAIN="1.96.0", CARGO_BUILD_JOBS="2", CARGO_INCREMENTAL="0",
            CARGO_TARGET_DIR=str(harness.TARGET), CARGO_NET_OFFLINE="true",
            SOURCE_SHA=HEAD, TESTED_SHA=HEAD, HEPTA_CI_LANE="source-head",
            PYTHONDONTWRITEBYTECODE="1", GIT_TERMINAL_PROMPT="0",
        )
        sys.path.insert(0, str(harness.REPO / "scripts"))
        from hepta_ci_junit import collect
        harness.collect = collect
        harness.require_roster()
        harness.PUBLIC.mkdir(mode=0o755)
        for name in ("codex-hepta-agentd", "hepta-authority-host", "hepta-joint-propose"):
            for variant in (name, name.replace("-", "_")):
                os.environ["CARGO_BIN_EXE_" + variant] = str(harness.PUBLIC / "unprepared" / name)
        helper = [
            "python3", "scripts/hepta_cell_test_helpers.py", "--package",
            "codex-hepta-infer-worker-host", "--output-dir", str(harness.PUBLIC / "helpers"),
        ]
        harness.result["status"] = "preparing"
        harness.persist()
        for name, action in [
            ("helper-build", lambda: harness.build_helpers(helper)),
            ("helper-verify-and-load", lambda: harness.verify_and_load_helpers(helper)),
            ("product-build-and-pin", harness.prepare_products),
            ("library-binaries-build-uid1000", harness.prepare_library_binaries),
        ]:
            if not harness.attempt(name, action):
                raise RuntimeError("original preparation failed: " + name)
        prior = json.loads((WORK / "native-v3/result.json").read_text())
        assert prior["head"] == HEAD and prior["tree"] == TREE
        assert prior["checks"]["original-root-pair-errors"]["passed"] is True
        assert prior["source_unchanged"] is True
        harness.save(harness.OUT / "prior-original-pair-regression.json", dict(
            result=str(WORK / "native-v3/result.json"),
            sha256=hashlib.sha256((WORK / "native-v3/result.json").read_bytes()).hexdigest(),
            scope="The two actual original-pair regression tests passed on this exact source in v3; v3 then correctly refused a non-test hardlinked executable during setup. No owner test ran in v3.",
        ))
        listing = json.loads((harness.OUT / "library-binaries-build-uid1000.stdout.log").read_text())
        selected = listing["rust-binaries"]["codex-hepta-agentd"]
        assert selected["kind"] == "lib" and selected["binary-id"] == "codex-hepta-agentd"
        executable = Path(selected["binary-path"])
        assert executable.parent == harness.TARGET / "debug/deps"
        rows = []
        for executable in [executable]:
            assert not executable.is_symlink()
            before_elf = executable.stat()
            assert before_elf.st_uid == 1000 and before_elf.st_nlink == 1
            assert before_elf.st_mode & 0o777 in (0o700, 0o701)
            with executable.open("rb") as stream:
                elf_hash = hashlib.file_digest(stream, "sha256").hexdigest()
            executable.chmod(0o701)
            after_elf = executable.stat()
            for field in ("st_dev", "st_ino", "st_size", "st_mtime_ns"):
                assert getattr(before_elf, field) == getattr(after_elf, field)
            with executable.open("rb") as stream:
                assert hashlib.file_digest(stream, "sha256").hexdigest() == elf_hash
            rows.append(dict(executable=str(executable), bytes=before_elf.st_size,
                             sha256=elf_hash, uid=before_elf.st_uid, gid=before_elf.st_gid,
                             mode_before=oct(before_elf.st_mode & 0o777), mode_after="0o701"))
        assert len(rows) == 1
        harness.save(harness.OUT / "source-executable-precondition.json", dict(
            test_executables=rows,
            previous_actual_eacces_record=str(WORK / "native-source-exec-precondition.json"),
            previous_record_sha256=hashlib.sha256(
                (WORK / "native-source-exec-precondition.json").read_bytes()).hexdigest(),
            authority_scope="Only isolated test ELF other-execute, after exact just test preparation. No read/write, private ancestor, owner data, credentials, trust, deadline or receipt change.",
        ))
        mounts_attempted = True
        if not harness.attempt("root-mount-setup", harness.setup_mounts):
            raise RuntimeError("original mount preparation failed")
        harness.result["status"] = "testing"
        harness.persist()
        args = ["-p", "codex-hepta-agentd", "-p", "codex-hepta-contracts", "--lib",
                "--run-ignored", "only", "--test-threads", "1", "-E"]
        for name, parent in [
            ("ordinary-whole-cold-no-update", harness.NO_UPDATE_COLD_PARENT),
        ]:
            harness.attempt(name, lambda name=name, parent=parent: harness.test(
                name, [*args, "test(=" + parent + ")"], [parent]))
        harness.result["status"] = "completed"
    except BaseException as error:
        harness.result.update(status="failed", error=repr(error))
        (harness.OUT / "adapter-error.log").write_text(traceback.format_exc())
    finally:
        if mounts_attempted:
            cleanup = []
            for name in ("witness-bind", "bind"):
                path = str(harness.ROOT / name)
                active = [line.split()[4] for line in Path("/proc/self/mountinfo").read_text().splitlines()]
                if path in active:
                    result = subprocess.run(["sudo", "-n", "umount", path], capture_output=True, text=True)
                    cleanup.append(dict(path=path, code=result.returncode,
                                        stdout=result.stdout, stderr=result.stderr))
            harness.save(harness.OUT / "mount-cleanup.json", cleanup)
            harness.result["cleanup_passed"] = all(item["code"] == 0 for item in cleanup)
        harness.result["after"] = harness.snapshot()
        harness.result["source_unchanged"] = harness.result.get("before") == harness.result["after"]
        harness.result["elapsed_seconds_including_wait"] = time.monotonic() - started
        harness.result["finished"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        harness.result["all_attempted_stages_passed"] = (
            harness.result["status"] == "completed"
            and harness.result["source_unchanged"]
            and harness.result.get("cleanup_passed", True)
            and all(stage.get("passed") is True for stage in harness.result["checks"].values())
        )
        harness.persist()
        if lock is not None:
            lock.close()
        print(json.dumps(harness.result), flush=True)
    return 0 if harness.result["all_attempted_stages_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
