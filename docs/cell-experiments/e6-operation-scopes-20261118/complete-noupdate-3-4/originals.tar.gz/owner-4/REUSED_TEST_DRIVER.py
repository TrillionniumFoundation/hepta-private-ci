def test(name, arguments, expected=None):
    source_before = snapshot()
    save(OUT / (name + '-source-before.json'), source_before)
    require(source_before == result['before'], 'source changed before this exact test stage')
    restore_ownership()
    reports = [TARGET / 'nextest/local/junit.xml', REPO / 'codex-rs/target/nextest/local/junit.xml']
    for index, report in enumerate(reports):
        if report.exists():
            report.rename(OUT / f'{name}-prior-junit-{index}-excluded.xml')
    argv = ['python3', 'scripts/hepta_ci_exec.py', '--timeout-seconds', '7200',
            '--minimum-tests', '1', '--output', str(OUT / (name + '.json')), '--',
            'just', 'test', *arguments, '--retries', '0',
            '--success-output', 'final', '--failure-output', 'final', '--no-tests', 'fail']
    root = expected is not None
    if root:
        keys = ['PATH', 'SOURCE_SHA', 'TESTED_SHA', 'HEPTA_CI_LANE', 'PYTHONDONTWRITEBYTECODE',
                'CARGO_INCREMENTAL', 'CARGO_BUILD_JOBS', 'CARGO_TARGET_DIR', 'CARGO_NET_OFFLINE',
                'RUSTY_V8_ARCHIVE', 'RUSTY_V8_SRC_BINDING_PATH', 'LIBCLANG_PATH',
                'RUSTUP_TOOLCHAIN', 'BINDGEN_EXTRA_CLANG_ARGS', 'RUSTFLAGS', 'LD_LIBRARY_PATH']
        environment = {key: os.environ[key] for key in keys if key in os.environ}
        environment.update(CARGO_HOME=os.environ.get('CARGO_HOME', '/home/qq/.cargo'),
                           RUSTUP_HOME=os.environ.get('RUSTUP_HOME', '/home/qq/.rustup'),
                           GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='safe.directory',
                           GIT_CONFIG_VALUE_0=str(REPO),
                           HEPTA_HOST_AUTHORITY_QUALIFICATION_STATE_PARENT=str(ROOT / 'bind'),
                           HEPTA_HOST_AUTHORITY_QUALIFICATION_SOURCE=str(ROOT / 'source'),
                           HEPTA_Q24_FACTORY_WITNESS_BIND=str(ROOT / 'witness-bind'),
                           HEPTA_Q24_FACTORY_WITNESS_SOURCE=str(ROOT / 'witness-source'),
                           HEPTA_CHECKPOINT_TEST_ROOT=str(ROOT / 'checkpoints'),
                           HEPTA_ORDINARY_SOURCE_COMMIT=HEAD, HEPTA_ORDINARY_SOURCE_TREE=TREE)
        # Only this attempt's verified helper/pinned product environment is
        # exported. Failed preparation leaves explicit unavailable paths.
        for binary_name in ('codex-hepta-agentd', 'hepta-authority-host', 'hepta-joint-propose'):
            for variant in (binary_name, binary_name.replace('-', '_')):
                key = 'CARGO_BIN_EXE_' + variant
                environment[key] = os.environ[key]
        wrapper = "import os,runpy,sys; assert os.geteuid()==0; print('Root test uid=0',flush=True); runpy.run_path(sys.argv.pop(1),run_name='__main__')"
        argv = ['sudo', '-n', 'env', '-i', *(k + '=' + v for k, v in sorted(environment.items())),
                'python3', '-c', wrapper, *argv[1:]]
    save(OUT / (name + '-launch.json'), dict(command=argv, required_euid=0 if root else 1000))
    try:
        code = command(name + '-execution', argv)
    finally:
        if root:
            restore_ownership()
    observed = [p for p in reports if p.exists()]
    collection = dict(status='multiple-fresh-native-reports' if len(observed) > 1
                      else 'missing-fresh-native-report', paths=[str(p) for p in observed])
    for index, report in enumerate(observed):
        shutil.copyfile(report, OUT / f'{name}-fresh-native-observed-{index}.xml')
    if len(observed) == 1:
        collected = collect(OUT / (name + '.json'), observed[0], OUT / (name + '.xml'))
        collection = json.loads((OUT / (name + '.summary.json')).read_text())
        collection['collector_exit_code'] = collected
        if expected is not None and (OUT / (name + '.xml')).exists():
            cases = list(ET.parse(OUT / (name + '.xml')).iter('testcase'))
            actual = [c.attrib['name'] for c in cases if c.find('skipped') is None]
            coverage = dict(expected=expected, observed=actual, skipped=sum(c.find('skipped') is not None for c in cases), exact=len(cases) == len(expected) and sorted(actual) == sorted(expected))
            save(OUT / (name + '-parent-coverage.json'), coverage)
            collection['exact_parent_coverage'] = coverage['exact']
    save(OUT / (name + '-collection.json'), collection)
    result[name] = dict(command_exit_code=code, collection=collection)
    persist()
    after = snapshot()
    result[name]['source_after'] = after
    result[name]['source_unchanged'] = after == result['before']
    persist()
    return (code == 0 and collection.get('collector_exit_code') == 0
            and collection.get('status') == 'passed'
            and (expected is None or collection.get('exact_parent_coverage') is True)
            and after == result['before'])
