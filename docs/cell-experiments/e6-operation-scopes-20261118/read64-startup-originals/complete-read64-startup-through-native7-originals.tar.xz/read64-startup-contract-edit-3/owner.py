import fcntl,hashlib,json,os,re,subprocess,sys,time,tomllib,traceback
from pathlib import Path
BASE=Path("/home/qq/work/hepta-e6-operation-scope-20261118-2e9b");SRC=BASE/"source";OUT=BASE/"read64-startup-contract-edit-3"
OPS=json.loads("[{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/codex-rs/hepta-agentd/src/cell_q24_freeze_operation.rs\",\"before_sha256\":\"4e6c3fc05f09feaee843c48b1a73a9ca719a3f809bd7a8839598e27914fca138\",\"replacements\":[[\"read.revalidate_source()\",\"OriginalFreezePreparationReadV1::revalidate_source(&read)\",2],[\"let authorization = owner.authorize_in_operation(&self, &read)?;\",\"let authorization = OriginalCellQ24DatasetFreezeOwnerV1::authorize_in_operation(\\n                            &mut owner, &self, &read,\\n                        )?;\"]],\"after_sha256\":\"8d5de2c59c74ca77c9a42f3152947f95ebd71659d4b1321f6b8f6bf0c961b8ae\"},{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/codex-rs/hepta-agentd/src/learning_iteration_historical_source.rs\",\"before_sha256\":\"4b298a4f959ecb31086fe30cea0637cced39e3abc36f534768b8aac21898ac2f\",\"replacements\":[[\"        let original = Arc::clone(\",\"        let original: Arc<crate::OriginalCellQ24LearningStageOwnersV1> = Arc::clone(\"],[\"        original\\n            .prepared()\\n            .with_original_prepared_operation(|read| {\",\"        let prepared: &CellQ24PreparedLearningV1 = original.prepared();\\n        prepared.with_original_prepared_operation(|read| {\"],[\"        let original = self\\n            .original_q24\",\"        let original: &Arc<crate::OriginalCellQ24LearningStageOwnersV1> = self\\n            .original_q24\"]],\"after_sha256\":\"987a55f86550a0f0619aa51fb19764b4a0267dd2ed55cecb2bd19bc0c531d1fd\"},{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/qa/b4-no-bypass/test_historical_current_trust_client_source_closure.py\",\"before_sha256\":\"762ce18c8db5af3da48c2fd2a1db15f54f2bcb7230c2465a39734b01683d74a7\",\"replacements\":[[\"[AGENT + \\\"cell_q24_dataset_historical_ledger.rs\\\", AGENT + \\\"cell_q24_dataset_operation.rs\\\", AGENT + \\\"production_post_a_continuation.rs\\\"]\",\"[AGENT + \\\"cell_q24_dataset_historical_ledger.rs\\\", AGENT + \\\"cell_q24_dataset_operation.rs\\\", AGENT + \\\"production_post_a_continuation.rs\\\", AGENT + \\\"cell_q24_dataset_historical_preparation.rs\\\"]\"]],\"after_sha256\":\"b2a11fc913aee39ef6ceb45efba2d2e66d7968a143c32bf2dcdf8fe3f468d1ce\"},{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/qa/b4-no-bypass/test_historical_dataset_capability_source_closure.py\",\"before_sha256\":\"12e3b4022a01568cfdb3350ae693ec5c218b475d003142fc819663d62acc6d34\",\"replacements\":[[\"[HISTORY, OPERATION, AGENT + \\\"production_post_a_continuation.rs\\\"]\",\"[HISTORY, OPERATION, AGENT + \\\"production_post_a_continuation.rs\\\", AGENT + \\\"cell_q24_dataset_historical_preparation.rs\\\"]\"],[\"                              AGENT + \\\"production_post_a_q24_owners.rs\\\",\\n                          ])\",\"                              AGENT + \\\"production_post_a_q24_owners.rs\\\",\\n                              AGENT + \\\"learning_iteration_historical_source.rs\\\",\\n                          ])\"]],\"after_sha256\":\"149a5cd7ca6820ed72c199a123a1a5318291e7f5aadcbf8140100a011d5c25db\"},{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/qa/b4-no-bypass/test_historical_task_read_source_closure.py\",\"before_sha256\":\"50e163e16aacb2a063a45595865acd67f158e092a0e5717758625abb8d7397f7\",\"replacements\":[[\"\\\"receipt_client\\\": (A + \\\"cell_q24_dataset_historical_task.rs\\\", A + \\\"root_historical_learning_trust_client.rs\\\", A + \\\"learning_iteration_historical_source.rs\\\", A + \\\"root_post_a_learning_client.rs\\\"),\",\"\\\"receipt_client\\\": (A + \\\"cell_q24_dataset_historical_task.rs\\\", A + \\\"root_historical_learning_trust_client.rs\\\", A + \\\"learning_iteration_historical_source.rs\\\", A + \\\"root_post_a_learning_client.rs\\\", A + \\\"root_historical_learning_operation.rs\\\"),\"]],\"after_sha256\":\"758d087468b0761e989e4368ddeaed3253a26ea5b070015a4569a98e629617d7\"},{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/qa/b4-no-bypass/test_historical_freezer_source_closure.py\",\"before_sha256\":\"8596976979b2a97580f963cad92311ce95a230acdcb3a6c18ac8ea96e1232dbc\",\"replacements\":[[\"\\\"read.revalidate_source()\\\"\",\"\\\"OriginalFreezePreparationReadV1::revalidate_source(&read)\\\"\"]],\"after_sha256\":\"f718862a2fceef20ad8fd0b2e09977e55f2f316ff9f2e4f637dec2039712efd0\"},{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/qa/b4-no-bypass/test_historical_startup_operation_source_closure.py\",\"before_sha256\":\"50bfb9e75f8815e7290729e871fe8dad3be386fa3b63e995c09e1d616696b710\",\"replacements\":[[\"\\\"owner.authorize_in_operation(&self, &read)?\\\"\",\"\\\"OriginalCellQ24DatasetFreezeOwnerV1::authorize_in_operation(\\\"\"]],\"after_sha256\":\"ddc3fd1f728fb354ab73bea03d5bb3a2bfe6b95688368c2e57e7a379925b8346\"},{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/qa/b4-no-bypass/test_post_a_owner_files_source_closure.py\",\"before_sha256\":\"4d514d8a6fad1cf33735b4cd127de3c6153815aae5ff4ed0b855237cd4db3ca6\",\"replacements\":[[\"\\\"owner.authorize_in_operation(&self, &read)?\\\"\",\"\\\"OriginalCellQ24DatasetFreezeOwnerV1::authorize_in_operation(\\\"\"]],\"after_sha256\":\"fdf2562447341656f7d06274cfd2a191dfbf3716c24ea54e47294449b961a0bd\"}]")
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def row_text(row):
 out=["[[protected_file]]"]
 for k,v in row.items():
  if k!="required_function_order":out.append(k+" = "+json.dumps(v))
 for item in row["required_function_order"]:
  out.append("[[protected_file.required_function_order]]")
  for k,v in item.items():out.append(k+" = "+json.dumps(v))
 return "\n".join(out)+"\n\n"
OUT.mkdir(exist_ok=False);locks=[];started=time.monotonic();r={"native_cases":0,"verifier_changed":False,"original_223_test_failure_retained":True}
try:
 for p in (BASE/"native-component-owner.lock",BASE/"native-target-restored-1/.hepta-root-native-owner.lock"):
  h=p.open("a+b");fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(h)
 assert sha(BASE/"read64-startup-source-probe-2/RESULT.json")=="47a5d4070aee35d11108ba9db96b6bf52ba60abf0c015166eec399d946032db1"
 p=SRC/"CALLERS.toml";s=p.read_text();assert sha(p)=="0edec6bb7aee517ebc751b59b9fb5cadbe9032969ff7509ad380bfdab2263814"
 chunks=re.split(r"(?m)(?=^\[\[(?:boundary|protected_file)\]\]$|^\[authority\]$)",s)
 changed=[]
 for index,chunk in enumerate(chunks):
  if not chunk.startswith("[[protected_file]]"):continue
  row=tomllib.loads(chunk)["protected_file"][0];before=json.dumps(row)
  for f in row.get("required_function_order",[]):
   seq=f["sequence"]
   if row["path"].endswith("/cell_q24_freeze_operation.rs"):
    f["sequence"]=[x.replace("read.revalidate_source()","OriginalFreezePreparationReadV1::revalidate_source(&read)") for x in seq]
    seq=f["sequence"]
    if "owner.authorize_in_operation(&self, &read)?" in seq:
     i=seq.index("owner.authorize_in_operation(&self, &read)?")
     seq[i:i+1]=["OriginalCellQ24DatasetFreezeOwnerV1::authorize_in_operation(","&mut owner,","&self,","&read,"]
   if row["path"].endswith("/learning_iteration_historical_source.rs") and f["function"]=="fn with_original_historical_source(":
    i=seq.index(".prepared()");seq[i]="let prepared: &CellQ24PreparedLearningV1 = original.prepared()"
   if row["path"].endswith("/root_historical_learning_operation.rs") and f["function"]=="fn read_original_task(":
    i=seq.index("let result = self.read_for(self.trust, receipt,");seq[i]="let result = self.read_for(self.trust, receipt, |ledger, _, _, _|"
  if json.dumps(row)!=before:chunks[index]=row_text(row);changed.append(row["path"])
 assert len(changed)==3
 updated="".join(chunks);m=tomllib.loads(updated);assert len(m["boundary"])==1137 and len(m["protected_file"])==892
 candidates=[]
 for op in OPS:
  path=Path(op["path"]);assert sha(path)==op["before_sha256"]
  text=path.read_text()
  for replacement in op["replacements"]:
   old,new,*count=replacement;count=count[0] if count else 1
   assert text.count(old)==count,(path,old,text.count(old));text=text.replace(old,new)
  assert hashlib.sha256(text.encode()).hexdigest()==op["after_sha256"]
  candidates.append((path,text))
 (OUT/"CALLERS.toml.before").write_text(s);p.write_text(updated)
 for path,text in candidates:
  (OUT/(path.name+".before")).write_bytes(path.read_bytes());path.write_text(text)
 (OUT/"owner.py").write_bytes(Path(__file__).read_bytes())
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",RUSTUP_TOOLCHAIN="1.96.0");env["PATH"]=str(BASE/"tooling/bin")+":/home/qq/.cargo/bin:"+env["PATH"]
 fmt=subprocess.run(["just","fmt"],cwd=SRC/"codex-rs",env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300)
 (OUT/"format.stdout").write_bytes(fmt.stdout);(OUT/"format.stderr").write_bytes(fmt.stderr)
 sys.path.insert(0,str(SRC/"qa/b4-no-bypass"));import test_historical_ledger_readonly_source_closure as component
 failures=[]
 for i,row in enumerate(m["protected_file"]):
  try:component.PROOF._verify_protected_files(SRC,{"protected_file":[row]})
  except Exception as error:failures.append({"index":i,"path":row["path"],"error":repr(error)})
 r.update(successful=fmt.returncode==0 and not failures,format_exit=fmt.returncode,protected_failures=failures,protected_rows=len(m["protected_file"]),manifest_sha256=sha(p),source_sha256={str(path):sha(path) for path,text in candidates})
except BaseException as error:
 r.update(successful=False,error=repr(error));(OUT/"ERROR.txt").write_text(traceback.format_exc())
finally:
 r["wall_seconds"]=time.monotonic()-started;(OUT/"RESULT.json").write_text(json.dumps(r,indent=2)+"\n")
 for h in locks:h.close()
print(json.dumps(r),flush=True)
raise SystemExit(0 if r.get("successful") else 1)
