import fcntl,hashlib,json,os,re,subprocess,sys,time,tomllib,traceback
from pathlib import Path
BASE=Path("/home/qq/work/hepta-e6-operation-scope-20261118-2e9b");SRC=BASE/"source";OUT=BASE/"read64-startup-contract-edit-5"
OPS=json.loads("[{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/codex-rs/hepta-agentd/src/cell_q24_freeze_operation.rs\",\"before_sha256\":\"07ee995251608ff83f96092c666aba5f5e6776b0db5152c59763fbe62f3f95bc\",\"replacements\":[[\"        self.revalidate_source()\",\"        OriginalFreezePreparationReadV1::revalidate_source(self)\"],[\"OriginalDatasetLedgerV1::Live(_) => self.preparation.revalidate_source(),\",\"OriginalDatasetLedgerV1::Live(_) => {\\n                CellQ24DatasetFreezePreparationV1::revalidate_source(self.preparation)\\n            }\"]],\"after_sha256\":\"bef110589a7dfcc5343bccdd8d34e9bd582cd428c6790fc31ddb419b129535b2\"},{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/codex-rs/hepta-agentd/src/production_post_a_q24.rs\",\"before_sha256\":\"5ab8c1bcd080f5a9b21982b01ae4b2081a916309c4bbd14a3e77f1439578fb8c\",\"replacements\":[[\"        let (bootstrap, source) = prepared.with_original_prepared_operation(|read| {\",\"        let original_prepared: &CellQ24PreparedLearningV1 = prepared.as_ref();\\n        let (bootstrap, source) = original_prepared.with_original_prepared_operation(|read| {\"]],\"after_sha256\":\"d050e7379e82533a18c035f4371beac6378ea864e4bf8bf6c85f0a9ff1fe68da\"},{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/qa/b4-no-bypass/test_historical_freezer_source_closure.py\",\"before_sha256\":\"f718862a2fceef20ad8fd0b2e09977e55f2f316ff9f2e4f637dec2039712efd0\",\"replacements\":[[\"\\\"return Err(\\\", \\\"self.revalidate_source()\\\"\",\"\\\"return Err(\\\", \\\"OriginalFreezePreparationReadV1::revalidate_source(self)\\\"\"]],\"after_sha256\":\"3027186cad6952eddb1365e5a44141edd3d5427721218d769c5a7d43acadbbe5\"},{\"path\":\"/home/qq/work/hepta-e6-operation-scope-20261118-2e9b/source/qa/b4-no-bypass/test_historical_learning_delivery_source_closure.py\",\"before_sha256\":\"be680247e457f5e94dd4ce48b6281700b618004d77e0f0769b1c0dbc39b49c13\",\"replacements\":[[\"\\\"prepared.with_original_prepared_operation(|read|\\\"\",\"\\\"let original_prepared: &CellQ24PreparedLearningV1 = prepared.as_ref()\\\",\\n            \\\"original_prepared.with_original_prepared_operation(|read|\\\"\"]],\"after_sha256\":\"e1a8839977f5dd82545fd0347a1e29e0b8e40688890a5d0e47e1c8ea84981bdc\"}]")
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def row_text(row):
 out=["[[protected_file]]"]
 for k,v in row.items():
  if k!="required_function_order":out.append(k+" = "+json.dumps(v))
 for item in row["required_function_order"]:
  out.append("[[protected_file.required_function_order]]")
  for k,v in item.items():out.append(k+" = "+json.dumps(v))
 return "\n".join(out)+"\n\n"
OUT.mkdir(exist_ok=False);locks=[];started=time.monotonic();r={"native_cases":0,"verifier_changed":False,"original_223_pass_and_two_remaining_caller_refusals_retained":True}
try:
 for p in (BASE/"native-component-owner.lock",BASE/"native-target-restored-1/.hepta-root-native-owner.lock"):
  h=p.open("a+b");fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(h)
 assert sha(BASE/"read64-startup-source-probe-3/RESULT.json")=="f8f11d823dc378c5c7cddda880b0feaaff1ae744cf5a561a952f727a35d7c41b"
 p=SRC/"CALLERS.toml";s=p.read_text();assert sha(p)=="809cb64f0fe353b211a93896992fd1e492b8b26de9a275e2446f03705bc9a6aa"
 chunks=re.split(r"(?m)(?=^\[\[(?:boundary|protected_file)\]\]$|^\[authority\]$)",s)
 changed=[]
 for index,chunk in enumerate(chunks):
  if chunk.startswith("[[boundary]]"):
   row=tomllib.loads(chunk)["boundary"][0]
   if row["id"]=="q24_original_freeze_operation_owner":
    old=json.dumps("self.revalidate_source()");assert chunk.count(old)==1
    chunks[index]=chunk.replace(old,json.dumps("OriginalFreezePreparationReadV1::revalidate_source(self)"))
   continue
  if not chunk.startswith("[[protected_file]]"):continue
  row=tomllib.loads(chunk)["protected_file"][0];before=json.dumps(row)
  for f in row.get("required_function_order",[]):
   seq=f["sequence"]
   if row["path"].endswith("/cell_q24_freeze_operation.rs"):
    if f["function"]=="fn require_original_preparation(":
     i=seq.index("self.revalidate_source()");seq[i]="OriginalFreezePreparationReadV1::revalidate_source(self)"
    if f["function"]=="fn revalidate_source(":
     i=seq.index("OriginalDatasetLedgerV1::Live(_) => self.preparation.revalidate_source()")
     seq[i:i+1]=["OriginalDatasetLedgerV1::Live(_)","CellQ24DatasetFreezePreparationV1::revalidate_source(self.preparation)"]
   if row["path"].endswith("/production_post_a_q24.rs") and f["function"]=="fn assemble_original_post_a_q24(" and "prepared.with_original_prepared_operation(|read|" in seq:
    i=seq.index("prepared.with_original_prepared_operation(|read|")
    seq[i:i+1]=["let original_prepared: &CellQ24PreparedLearningV1 = prepared.as_ref()","original_prepared.with_original_prepared_operation(|read|"]
  if json.dumps(row)!=before:chunks[index]=row_text(row);changed.append(row["path"])
 assert len(changed)==2
 updated="".join(chunks);m=tomllib.loads(updated);assert len(m["boundary"])==1137 and len(m["protected_file"])==892
 candidates=[]
 for op in OPS:
  path=Path(op["path"]);assert sha(path)==op["before_sha256"]
  text=path.read_text()
  for replacement in op["replacements"]:
   old,new,*count=replacement;count=count[0] if count else 1
   assert text.count(old)==count,(path,old,text.count(old));text=text.replace(old,new)
  assert hashlib.sha256(text.encode()).hexdigest()==op["after_sha256"]
  candidates.append((path,text))
 (OUT/"CALLERS.toml.before").write_text(s);p.write_text(updated)
 for path,text in candidates:
  (OUT/(path.name+".before")).write_bytes(path.read_bytes());path.write_text(text)
 (OUT/"owner.py").write_bytes(Path(__file__).read_bytes())
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",RUSTUP_TOOLCHAIN="1.96.0");env["PATH"]=str(BASE/"tooling/bin")+":/home/qq/.cargo/bin:"+env["PATH"]
 fmt=subprocess.run(["just","fmt"],cwd=SRC/"codex-rs",env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300)
 (OUT/"format.stdout").write_bytes(fmt.stdout);(OUT/"format.stderr").write_bytes(fmt.stderr)
 sys.path.insert(0,str(SRC/"qa/b4-no-bypass"));import test_historical_ledger_readonly_source_closure as component
 failures=[]
 for i,row in enumerate(m["protected_file"]):
  try:component.PROOF._verify_protected_files(SRC,{"protected_file":[row]})
  except Exception as error:failures.append({"index":i,"path":row["path"],"error":repr(error)})
 r.update(successful=fmt.returncode==0 and not failures,format_exit=fmt.returncode,protected_failures=failures,protected_rows=len(m["protected_file"]),manifest_sha256=sha(p),source_sha256={str(path):sha(path) for path,text in candidates})
except BaseException as error:
 r.update(successful=False,error=repr(error));(OUT/"ERROR.txt").write_text(traceback.format_exc())
finally:
 r["wall_seconds"]=time.monotonic()-started;(OUT/"RESULT.json").write_text(json.dumps(r,indent=2)+"\n")
 for h in locks:h.close()
print(json.dumps(r),flush=True)
raise SystemExit(0 if r.get("successful") else 1)
