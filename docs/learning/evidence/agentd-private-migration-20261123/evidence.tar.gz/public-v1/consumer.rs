use codex_hepta_agentd::OriginalCellQ24EvaluationTimingV1;
use codex_hepta_intelligence_eval::LongitudinalTimeEvidenceV1;
pub fn make_original(timing: LongitudinalTimeEvidenceV1) -> OriginalCellQ24EvaluationTimingV1 {
    OriginalCellQ24EvaluationTimingV1::SystemLongitudinal {
        timing, minimum_window_micros: 1,
    }
}
