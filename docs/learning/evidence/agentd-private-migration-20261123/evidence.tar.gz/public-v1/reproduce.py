"""Recompile the same external consumer, using independent worktrees and fresh target directories."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

HERE=Path(__file__).resolve().parent
CURRENT="dafb12e11e7d95ffb9c5eb6d256223d6fd45ac34"
DONOR="24abd04c825cb0d5d0ce27b52ac5008eda13dde4"
TOOLCHAIN="+1.96.0"
TARGET="x86_64-unknown-linux-gnu"

def git(root,*args):
    return subprocess.check_output(["git","-C",root,*args],text=True).strip()

def arm(root,expected,build,name):
    if git(root,"rev-parse","HEAD")!=expected or git(root,"status","--porcelain","--untracked-files=no"):
        raise SystemExit(f"expected an unmodified checkout of {expected}")
    target=build/name; target.mkdir()
    env=dict(os.environ,CARGO_TARGET_DIR=str(target))
    cargo=["cargo",TOOLCHAIN,"check","--target",TARGET,"--manifest-path",str(root/"codex-rs/Cargo.toml"),"--locked","-p","codex-hepta-agentd","--lib","--message-format=json"]
    result=subprocess.run(cargo,cwd=root,env=env,stdout=subprocess.PIPE,text=True,check=True)
    crates={}
    for line in result.stdout.splitlines():
        v=json.loads(line)
        if v.get("reason")=="compiler-artifact" and v["target"]["name"] in {"codex_hepta_agentd","codex_hepta_intelligence_eval"}:
            crates[v["target"]["name"]]=next(Path(f) for f in v["filenames"] if f.endswith(".rmeta"))
    if set(crates)!={"codex_hepta_agentd","codex_hepta_intelligence_eval"}:
        raise SystemExit("missing the two real crate metadata files")
    for f in crates.values():
        if not f.is_relative_to(target): raise SystemExit("unexpected artifact location")
    driver=["rustc",TOOLCHAIN,"--target",TARGET,"--edition=2024","-D","warnings","--crate-type=lib","--emit=metadata","-L","dependency="+str(target/TARGET/"debug/deps")]
    for k,f in sorted(crates.items()):driver+=["--extern",k+"="+str(f)]
    result={}
    for witness in ("consumer","layout"):
        task=subprocess.run([*driver,str(HERE/(witness+".rs")),"-o",str(build/(name+"-"+witness+".rmeta"))],cwd=root,env=env,capture_output=True,text=True)
        result[witness]={"exit":task.returncode,"stderr":task.stderr}
    size=312 if name=="current" else 16
    assert result["layout"]["exit"] and f"size of {size}" in result["layout"]["stderr"]
    if name=="current":assert result["consumer"]["exit"]==0
    else:assert result["consumer"]["exit"] and "Box<LongitudinalTimeEvidenceV1>" in result["consumer"]["stderr"]
    return {"consumer_exit":result["consumer"]["exit"],"observed_size":size,"source":expected}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("current",type=Path);parser.add_argument("donor",type=Path);args=parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="agentd-v1-fresh-") as d:
        root=Path(d)
        print(json.dumps({"current":arm(args.current.resolve(),CURRENT,root,"current"),"donor":arm(args.donor.resolve(),DONOR,root,"donor")},indent=2))

if __name__=="__main__":
    main()
