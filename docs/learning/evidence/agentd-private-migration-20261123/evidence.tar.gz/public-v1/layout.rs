use codex_hepta_agentd::OriginalCellQ24EvaluationTimingV1;
const _: [(); 0] = [(); std::mem::size_of::<OriginalCellQ24EvaluationTimingV1>()];
