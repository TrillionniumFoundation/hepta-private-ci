# Candidate tests and prospective original gates

All Rust tests listed here are written, not executed. Rustfmt is a source
syntax/format check and is not type checking, package testing or guest evidence.

| Candidate test | Required real path / refusal |
|---|---|
| `spawn_one_retains_run_two_and_dispatch_cannot_be_reused` | Private production tracker accepts the original generation relationship, rejects a substituted spawn at dispatch and an idempotent/replayed dispatch. |
| `every_retained_identity_field_and_revision_is_checked_without_advancing` | Mutates run ID, context, envelope, authority, run generation, fence, deadline, revision rollback and terminal flag individually; every rejection preserves the retained state. |
| `missing_indeterminate_and_terminal_projection_never_become_a_terminal_witness` | Missing/other phases, including claimed terminal projections, cannot create a physical terminal or advance the tracker. |
| `external_cancelling_is_one_checked_revision_transition` | Same-revision mixed Cancelling refuses; exact next revision consumes once; duplicate consumption refuses. |
| `rejected_cancel_receipts_cannot_guess_or_roll_back_the_run_revision` | Indeterminate, unchanged/skipped revision, wrong disposition all refuse without changing the retained revision. |
| `original_intelligence_branch_keeps_spawn_one_and_run_two` | Actual original Agentd control, original App Server, real `run_intelligence`, original test FinalUse signer and provider fixture; requires one provider request, actual correlated completion and original Succeeded readback. |
| `original_external_cancel_interrupts_once_and_commits_correlated_terminal` | After the real provider request is recorded, original RunCancel must be consumed by the worker; requires one exact interrupt call, real Interrupted terminal, original Cancelled readback with unchanged reason/exact next revision, and the same complete record after reopening the original native journal. |
| `original_indeterminate_run_stops_exact_turn_without_rewriting_run_terminal` | The real original control projection becomes Indeterminate during the pending provider request. Requires exact-turn containment, real Interrupted event, Quarantined boundary, and the original run receipt left unchanged. |

The existing original tests for wrong thread/turn correlation, late completion
after cancellation/deadline, owner loss, original journal no-replay and the
non-intelligence `.run()` path must also remain in the full owning-package gate.

The real tests use the original response fixture's matcher-recorded request as
the synchronization point. Its 30-second delayed response is only a controlled
pending provider; observing a fixed elapsed delay never stands in for a real
physical request. Fixture admission/authority is explicit and not production
qualification.

## Suggested red then green execution

`red-control/` is the exact original db91 product code with only the same
cfg(test) task-local interrupt observer/module hook and the new real-host test
file. It preserves the original generation defect. The first real-host test
above must fail on that baseline at the original handoff/dispatch check. No red
execution has occurred yet. Do not use the baseline-only overlay as a product
patch, and do not mix a red result with the final candidate's source identity.

After the parent allocates the original build window, apply the separately
hashed candidate to the unchanged original workspace and original locks, with
the actual pinned Rust 1.95 toolchain, existing verified V8/native OpenSSL setup
and one build job. Use the original recipes, including:

```text
just test --locked --cargo-profile dev-small --build-jobs 1 --test-threads 1 -p codex-hepta-infer-worker-host --lib
just fmt --check
just fix -p codex-hepta-infer-worker-host
```

Retain raw stdout, stderr, JUnit, command/exit metadata, retry/filter counts,
source/preimage hashes and unmodified lock identities. Broader Agentd gates
from the ongoing checkpoint/owner integration remain separate; a previous
memory or Desktop result cannot be used as this package's result. If any
formatter/linter changes the candidate, freeze and qualify the actual final
bytes rather than assigning earlier execution to them.
