#!/usr/bin/env python3
"""Offline exact-source packaging and rustfmt only; never invokes Cargo."""

from __future__ import annotations

import datetime
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import tomllib


ROOT = Path(__file__).resolve().parents[1]
BASE = "db91f9ec316ba1472e7adf97f8415949de012469"
TREE = "81c03af04be56659d3eb4da71bf61aeac34c949f"
ORIGINAL = Path("/dev/shm/organ-3d6a75235bcb-hepta3398/cargo-home/git/checkouts/hepta-private-ci-4e02da04eb01edbd/db91f9e")
FORMATTER = Path("/dev/shm/organ-3d6a75235bcb-objective-tests/rustup-home/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustfmt")
PREFIX = "codex-rs/hepta-infer-worker-host/src/"
NAMES = ["native_app_server.rs", "native_run_monitor.rs", "native_run_monitor_tests.rs", "native_run_cancellation_tests.rs"]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def blob(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def save(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(ORIGINAL), *args])


def main() -> None:
    if git("rev-parse", BASE + "^{tree}").decode().strip() != TREE:
        raise ValueError("fixed original tree mismatch")
    if sha256(FORMATTER.read_bytes()) != "56b31ad3ec8fe0277a2884a189e243b8f04e9b48e5fd22e547c1516c5f8fd34c":
        raise ValueError("formatter differs from the independently restored official binary")
    build_inputs = []
    for relative in ["codex-rs/Cargo.toml", "codex-rs/Cargo.lock", "MODULE.bazel.lock", "codex-rs/hepta-infer-worker-host/Cargo.toml", "codex-rs/hepta-infer-worker-host/BUILD.bazel"]:
        original = git("show", BASE + ":" + relative)
        if original != (ORIGINAL / relative).read_bytes():
            raise ValueError("original build input drift: " + relative)
        build_inputs.append({"path": relative, "git_blob": blob(original), "sha256": sha256(original), "bytes": len(original)})
    member_count = len(tomllib.loads((ORIGINAL / "codex-rs/Cargo.toml").read_text())["workspace"]["members"])
    save(ROOT / "validation/original-build-inputs.json", {"base": BASE, "declared_workspace_member_entries": member_count, "resolved_workspace_member_count": None, "resolved_count_note": "Not recomputed in this source-only slice; no Cargo metadata invoked.", "unchanged_exact_inputs": build_inputs})
    preimages = json.loads((ROOT / "validation/base-identity.json").read_text())["files"]
    for entry in preimages:
        original = git("show", BASE + ":" + entry["path"])
        local = (ROOT / "base" / entry["path"]).read_bytes()
        if original != local or blob(local) != entry["git_blob"] or sha256(local) != entry["sha256"]:
            raise ValueError("exact preimage mismatch: " + entry["path"])
    for name in NAMES[1:]:
        if git("ls-tree", BASE, "--", PREFIX + name):
            raise ValueError("candidate new source already exists in fixed original: " + name)
    for path in (ROOT / "base").rglob("*"):
        if path.is_file() and path.name != "native_app_server.rs":
            if path.read_bytes() != (ROOT / "change" / path.relative_to(ROOT / "base")).read_bytes():
                raise ValueError("out-of-scope copied source changed: " + str(path))

    files = [ROOT / "change" / PREFIX / name for name in NAMES]
    args = [str(FORMATTER), "--config-path", str(ORIGINAL / "codex-rs/rustfmt.toml"), "--config", "skip_children=true"]
    before = {str(path.relative_to(ROOT)): sha256(path.read_bytes()) for path in files}
    receipts = []
    for label, extra in [("rustfmt-final", []), ("rustfmt-final-check", ["--check"])]:
        argv = args + extra + [str(path) for path in files]
        run = subprocess.run(argv, capture_output=True)
        (ROOT / "validation" / (label + ".stdout")).write_bytes(run.stdout)
        (ROOT / "validation" / (label + ".stderr")).write_bytes(run.stderr)
        receipt = {"argv": argv, "exit_code": run.returncode, "stdout_sha256": sha256(run.stdout), "stderr_sha256": sha256(run.stderr)}
        save(ROOT / "validation" / (label + ".json"), receipt)
        receipts.append(receipt)
        if run.returncode != 0:
            raise ValueError("candidate formatting failed")

    entries = []
    patches = []
    counts = {"added": 0, "removed": 0}
    for path in files:
        relative = path.relative_to(ROOT / "change").as_posix()
        data = path.read_bytes()
        text = data.decode("utf-8")
        preimage = ROOT / "base" / relative
        old = preimage.read_bytes() if preimage.exists() else None
        entry = {"path": relative, "mode": "100644", "type": "blob", "encoding": "utf-8", "content": text,
                 "candidate_git_blob": blob(data), "candidate_sha256": sha256(data), "bytes": len(data),
                 "unicode_characters": len(text), "whitespace_delimited_words": len(text.split()), "lines": len(text.splitlines()),
                 "preimage_git_blob": blob(old) if old is not None else None, "preimage_sha256": sha256(old) if old is not None else None,
                 "source_path": str(path)}
        entries.append(entry)
        lines = list(difflib.unified_diff((old.decode("utf-8") if old is not None else "").splitlines(keepends=True),
                                        text.splitlines(keepends=True), fromfile="a/" + relative if old is not None else "/dev/null", tofile="b/" + relative))
        patches.extend(lines)
        counts["added"] += sum(line.startswith("+") and not line.startswith("+++") for line in lines)
        counts["removed"] += sum(line.startswith("-") and not line.startswith("---") for line in lines)
    save(ROOT / "publication/root-source-entries.json", entries)
    (ROOT / "publication/original-run-cancel.patch").write_text("".join(patches))
    manifest = {"source_commit": BASE, "source_tree": TREE, "entries": [{k: v for k, v in entry.items() if k != "content"} for entry in entries],
                "diff_lines": counts, "files": len(entries), "source_bytes": sum(entry["bytes"] for entry in entries),
                "tests_authored_not_executed": {"binding_unit": 5, "actual_original_host_branch": 3},
                "actual_scope": "Official Rust1.95 rustfmt only; no original just fmt/Cargo/Agentd/AppServer/test/guest execution",
                "publication_requires": "Compare exact preimage and absence of the three new files at the then-current stacked head before CAS publication."}
    save(ROOT / "publication/source-manifest.json", manifest)

    # Exact original production baseline; only instrumentation and module hooks
    # are added under cfg(test). The real-host regression file is identical.
    baseline = (ROOT / "base" / PREFIX / NAMES[0]).read_text()
    marker = "async fn interrupt(client: &mut RemoteAppServerClient, output: &NativeRunOutput) {\n"
    if baseline.count(marker) != 1:
        raise ValueError("original interrupt marker is ambiguous")
    baseline = baseline.replace(marker, marker + "    #[cfg(all(test, unix))]\n    cancellation_tests::record_interrupt(output);\n")
    baseline += '\n#[cfg(all(test, unix))]\n#[path = "native_run_cancellation_tests.rs"]\nmod cancellation_tests;\n'
    red = ROOT / "red-control" / PREFIX
    red.mkdir(parents=True, exist_ok=True)
    (red / NAMES[0]).write_text(baseline)
    (red / NAMES[3]).write_bytes(files[3].read_bytes())
    save(ROOT / "validation/red-control-identity.json", {"base": BASE, "executed": False,
        "scope": "Exact original product behavior plus cfg(test) observation/module hooks, and the candidate real-host tests; no monitor implementation.",
        "files": [{"path": str(path.relative_to(ROOT / "red-control")), "sha256": sha256(path.read_bytes()), "git_blob": blob(path.read_bytes()), "bytes": path.stat().st_size} for path in [red / NAMES[0], red / NAMES[3]]]})
    save(ROOT / "validation/final-source-check.json", {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "base_commit": BASE, "base_tree": TREE, "exact_preimages_verified": len(preimages), "new_file_absence_verified": len(NAMES) - 1,
        "unchanged_copied_files_verified": len(preimages) - 1, "before_format": before,
        "final_source": {entry["path"]: entry["candidate_sha256"] for entry in entries},
        "formatter": {"path": str(FORMATTER), "sha256": sha256(FORMATTER.read_bytes()), "version": subprocess.check_output([str(FORMATTER), "--version"]).decode().strip()},
        "format_receipts": receipts, "cargo_or_tests_executed": False})
    print(json.dumps({"files": len(entries), "bytes": manifest["source_bytes"], "diff": counts,
        "manifest_sha256": sha256((ROOT / "publication/source-manifest.json").read_bytes()), "actual_scope": manifest["actual_scope"]}))


if __name__ == "__main__":
    main()
