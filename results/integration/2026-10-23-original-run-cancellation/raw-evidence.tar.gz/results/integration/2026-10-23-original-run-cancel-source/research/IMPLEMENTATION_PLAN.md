# Original execution-host cancellation slice

状态：根代理已授权源码候选；此文件是实施计划，不是已实现或执行回执。固定原 db91，最后发布前必须对 45f / 后续 checkpoint head 检查精确 preimage。产品候选独占 `work/original-run-cancel/`，不改共享原 source、依赖、Cargo.lock、workspace、协议或原 durable journal。

## 窄片接口与作用域

| 接点 | 最小改动 | 保持的边界 |
|---|---|---|
| `NativeWorkerConfig.generation` | 源兼容，文档明确 process spawn。 | 原 CLI、AgentdClient、App Server authority binding 继续使用 spawn；不让用户传两个互相猜测的 generation。 |
| `require_intelligence_handoff` | 由只返回 u64 改为私有已校验 run binding，字段来自原 handoff receipt。 | 无新 public grant/issuer；caller 原四字段仍匹配 RunStatus；新增 run ID、gen/fence/authority/deadline/context/envelope逐项检查与保存。 |
| `run_once` final handoff + dispatch ACK | 保存原 immutable binding，确认第二次 handoff 未变、revision符合；dispatch ACK 与 admitted run generation 比较。 | 不删除 generation/fence 条件，不把外层 Draining current 写回 admitted snapshot；相同逻辑 dispatch 的 idempotent ACK仍不授权第二次物理发送。 |
| `observe` | 复用现有 500ms owner tick，在 intelligence 模式检查同 bound run 的状态。 | 无额外 scheduler/ledger/轮询任务；非 intelligence 路径保持原语义。 |
| 外部 Cancelling | 以私有 typed exit 明确来自原 owner；更新经核验的 revision，再复用原 cancel_native→TurnInterrupt。 | 不第二次 RunCancel，不把外部 reason 改成另一条取消请求。 |
| missing/mismatch/regression/Indeterminate | 原精确 turn 的 containment stop + unknown。 | 不把这些观察写成 Cancelled/Completed；不能自动重新派发。 |
| 真实 terminal | 原 `observe_event` + `adapt_observed_event` correlation、原 owner-health边界继续负责。 | 不从 RunStatus 或 interrupt ACK 构造新的终态。既有 `commit_intelligence_terminal` 只能使用真实 observed terminal；无法绑定则保持 reconciliation required。 |

建议私有结构同时保留不可变字段与最新 revision。Run generation 来自初次原 receipt，与 spawn 分开；非零、合法 digest、原 run ID/context/envelope必须匹配。后续观察要求同一不可变 binding、revision 不回退。已经消耗的 dispatch/取消许可不能由于错误、lost response、readback failure重置。

## 执行顺序

1. 原 trusted host 提供既有四字段 handoff、原 process endpoint 与 final-use authorizer。
2. 真实原 Agentd RunStatus 返回 ContextAttached：构造私有 retained binding；不授予超出已有 handoff 的权限。
3. 原 path完成 durable native dispatch、原 RunMarkDispatched，再检查返回 full receipt 是同 run/binding、合法最新 revision、非 idempotent。
4. 物理发送前保留原 final-use/live/context revalidation。之后 only original App Server observed events 可以确认 thread/turn。
5. observe tick在原 ownerhealth之后查询 bound run。原 Cancelling使执行宿主退出observe，写同一原 native journal的cancel intent，并通过当前连接中精确 thread/turn发已有interrupt。
6. grace observation使用原pipeline。无 terminal correlation则unknown；ownerlost/mismatch/stalebinding不允许终态升级。原 RunObserveTerminal代码路径不得由显示状态直接驱动。
7. lost ACK或取消deadline超时不重发原Objective/turn。后续只能复用原读取/恢复流程。

注意：poll并非原子撤销许可。取消可能在最后检查与 TurnStart 之间发生；逻辑 dispatch 后的 disposition 本来就是 CancellingAfterDispatch，不能宣称这个窄片保证“取消按钮后零网络字节/零模型调用”。必须记录实际边界与真实 terminal结果。

## 必要回归候选

| 场景 | 必须实际进入的原路径 | 验收 |
|---|---|---|
| spawn=1 / admitted run=2 | 原 Fleet/Agentd控制端 + 原 run_intelligence | 原版在dispatch ACK拒绝；候选不因二者本来不同而拒绝，并保留同 fence/context/envelope。 |
| 错run ID / fence / authority / context / envelope / run generation / deadline | 原 retained-binding验证与observe分支 | 每个错误拒绝，不能只测字段形状；不将错误改为terminal。 |
| revision回退 | 原observe的真实receipt检查 | 拒绝且保留unknown；当前revision不回退。 |
| 外部 Cancelling | 原control RunCancel→既有observe tick→原 native journal→原 TurnInterrupt | 恰好一次当前turn interrupt，不额外RunCancel，不再TurnStart；独立cancel intent可从原 journal读取。 |
| interrupt ACK但无terminal | 原AppServer transport + grace | 仍unknown/held，不宣称Cancelled，不释放为成功。 |
| 错thread/turn terminal | 原adapt_observed_event / observe_event | 不能完成当前run；保持unknown。 |
| 精确Interrupted terminal | 原AppServer observed event + correlation | 真实Interrupted事实可保留；只在原 ownerauthority仍满足时走既有terminalpublication。 |
| complete与cancel竞态 | 原actualevent选择与原loop | 保留真实provider状态/取消boundary，不以晚到completed洗掉cancelled边界。 |
| missing run / Indeterminate / owner lost | 同一原executionconnection | 精确turn containment stop，unknown；无新RunObserveTerminal伪终态。 |
| Draining | 原generation/current语义 | 不修改admittedgen；原health失去ready的既有containment行为保持，不能产生effectauthority。 |
| 旧非intelligence `.run` | 原现有unit/真实hostfixture | 原行为、锁及authority要求不变。 |

测试应沿原 `CognitiveTestHost`/原 Fleet、真实 UDS control、原 AppServer、原 `DurableInferenceControl` 与原 test-only 独立 authorizer。可以控制 provider SSE 来确定事件顺序；必须明确 provider/issuer是fixture，不等于生产部署、真实模型或完整七-owner Objective资格。

原 `CognitiveTestHost` 的公有控制 API可以为该分支fixture接纳和附加一个原 snapshot。若fixture从该入口开始，报告只能称“原run_intelligence分支与原执行owner接合”；不能称已经跑完整 signed ObjectiveStart/七-ownercompiler。不能新增假 RunCancel/RunStatus server来替代原owner正控。

新增纯binding负例需与真正branch正控并行保留；不只写source字符串tests。所有候选tests在实际 owning package执行前均标记未运行。

## 原 owning-package 最终门禁（尚未运行）

在原193成员 workspace、原Rust1.95、原锁、原recipes中：

```text
just test --locked --cargo-profile dev-small --build-jobs 1 --test-threads 1 -p codex-hepta-infer-worker-host --lib
just test --locked --cargo-profile dev-small --build-jobs 1 --test-threads 1 -p codex-hepta-agentd --lib
```

原integration E2E若被选入还需独立保留实际命令、JUnit与完整logs。测试authority/模型fixture与生产输入分列；内存、host或旧generation的绿不能借用为本候选成功。format/Clippy按原recipe执行后核源码/锁精确身份。

## 后续完整取消链，不在本窄片

1. 原Agentd同一mutation中比较完整expected run snapshot，提供取消请求identity与原acceptancereceipt；不能只靠UI的read→write间预检。
2. 在原ProductionDurableWriter/Objective sender原域扩展typed cancellation（新migration/schema oracle/state_digest/语义校验同步）；单独prepared/claimed/observed/unknown，原raw/fullidentity、跨进程fence、独立current-cut ACK。同一个取消不因outerrequestid/endpoint/generation变化而重新发票。
3. 原RunStart/原native journal之间的受信恢复接合：取消与派发事实不能在新进程重新投影中遗失。只复用已有owner，不另建ledger。
4. Session只管理不持久的typedview/单次许可；host只注入原能力。post-send取消永远不走LocalCancelled；terminalreadback只读原owner实际证据。

对任一commit后ACK失败、超时、peer不匹配、request_rejected或未知结果，不能用默认permission/现场自算currentcut把链补成成功。
