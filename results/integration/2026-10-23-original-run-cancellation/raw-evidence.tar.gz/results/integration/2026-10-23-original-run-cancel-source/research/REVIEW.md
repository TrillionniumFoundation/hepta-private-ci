# P0 original RunCancel: fixed-source independent review

本报告仅依据 Hepta `db91f9ec316ba1472e7adf97f8415949de012469`、Desktop #256 source commit `bf0a0a0a582d7c93c191488e762c12bd6d75561a`。没有切换到 #257 / #3452，没有运行 Cargo、Agentd、App Server、QEMU 或 GitHub 操作。`original-inputs.json` 对 31 个原文件逐 Git 对象核对；`desktop-inputs.json` 对 21 个 Desktop 文件核对原发布 manifest。随后额外核对的实际 production E2E 文件单列于补充证据。

## 结论

目前不能把 Desktop 的按钮直接接 `AgentdClient::run_cancel` 后称为完整任务取消。该原接口确实属于 Agentd 的 run 协调器，但协调状态存于进程内 `BTreeMap`，不包含 Codex turn 的停止执行，也没有跨崩溃取消记录。真实执行宿主已经有原 `DurableInferenceControl.cancel_native`、`TurnInterrupt` 和精确 terminal correlation 路径；缺的是外部 RunCancel 到这条现有路径的接合，以及另一个原 generation 接线错误。

根代理已授权下一窄片：在原执行宿主内拆开 spawn / admitted run generation，并在原 observe loop 消费同一 run 的取消状态。源码候选将独立放置于 `work/original-run-cancel/`。此报告和方案不是已实现、已测试或已部署的声明。原取消持久域及原 RunStart 重放规则的大改不属于该窄片。

## 已存在的原 API 与 owner

| 层 | 固定源码位置 | 已有行为与限制 |
|---|---|---|
| 原控制 client | `hepta-agentd/src/client.rs:404–423` | `run_cancel(run_id, expected_revision, reason) -> AgentRunCancellation`，经原控制连接发一次请求；没有真实执行停止调用。 |
| 原 wire | `hepta-agent-protocol/src/lib.rs:178–208,511–528,634–638` | 三 disposition：CancelledBeforeDispatch、CancellingAfterDispatch、AlreadyTerminal。请求只有 run ID、revision、reason，外层带 spawn generation；没有独立取消签名、完整 expected snapshot 或操作 ID。 |
| Agentd route | `hepta-agentd/src/state_control.rs:503–518,1253–1268` | 当前 process spawn 精确匹配，Fleet refresh 后仅允许非 fenced Running/Draining；锁住原 run coordinator 调 `cancel_run`。 |
| 原 run 协调器 | `hepta-agentd/src/lane_b_runtime.rs:144–175,334–390` | 唯一 Agentd run 协调器，但为进程内 `BTreeMap`；不写 CognitiveStore、RunStart journal 或 native dispatch journal。 |
| 原 Objective durable owner | `hepta-agentd/src/objective_runtime.rs:209–285`；`hepta-learning-ledger/src/run_start.rs:319–417` | 原签名/完整 Objective publication 先在原 RunStart journal 追加并 sync，再投影到协调器。该 journal 目前只存 immutable run start 或 conflict，没有 run cancel lifecycle。 |
| 原 Codex 执行 owner | `hepta-infer-worker-host/src/native_app_server.rs:887–1004,1007–1058,1405–1417` | 当前仅在自身取消/失败路径调用 RunCancel，再经原 native journal 写取消意图并向精确 thread/turn 发 TurnInterrupt。observe 只读本地 CancellationToken、owner.health 和 App Server events，不消费外部 Cancelling。 |
| 原 native durable owner | `hepta-infer-core/src/durable_control.rs:171–200`；`native_control.rs:402–418,485–496` | 原文件独占 writer、原 journal；cancel_native 记录 intent，不释放运行名额，也不证明 turn 已停止。必须复用已有实例，不能从 UI 重开另一个 writer。 |
| Desktop #256 host | `services/hepta-session-host/src/lib.rs:162–175`；`owner.rs:173–179` | 只有未发送本地许可的取消。没有 RunCancel 接口。 |
| 原 Objective sender | `hepta-memory/src/objective_sender.rs:302–317`；`objective_sender_store.rs:19–53` | LocalCancelled 必须是 UNUSED → CANCELLED；不能用于已发送 Objective 或已派发 run。原域只有 permit/submission/history/local_cancelled。 |

所有 Hepta 路径以 `codex-rs/` 为前缀。永久源链接模板：

- [Hepta 原固定树](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/db91f9ec316ba1472e7adf97f8415949de012469)
- [Desktop #256 固定产品树](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/tree/bf0a0a0a582d7c93c191488e762c12bd6d75561a)

## 1. generation 接线矛盾：具体生产路径

1. 原 CLI `hepta-infer-worker-host/src/bin/hepta-infer-worker.rs:46` 从唯一 `--generation` 赋值，`:69–76` 直接构造 `NativeWorkerConfig.generation`。CLI 同时要求真实 `UnixFinalUseAuthorizer` 配置，没有默认签名者。`:98–128` 仅当四个 `--intelligence-*` 字段全部存在才调用 `run_intelligence`。
2. 原 driver `native_app_server.rs:432–435` 把该值传入 `AgentdClient::new`。原 `state_control.rs:51–55` 要求外层 spawn 等于 `AgentdIdentity.spawn_generation`。
3. `state.rs:336–345` 明确只接受 Starting = spawn、Running = spawn + 1、Draining = spawn + 2。因此对已通过原 route 的 Running generation，这个 +1 是实际检查的不变量，不是猜测。
4. `objective_runtime.rs:230–232` 以 current generation 创建原 run snapshot，并以 agent ID、spawn、current 共同派生 fence。`state_control.rs:453–458` 对原直接 RunStart 也检查 current run generation/fence。
5. 但 `native_app_server.rs:680–682` 要求 `run_mark_dispatched` 回执的 **run generation** 等于 **config spawn generation**。在 Running 时二者分别为 `s+1` 和 `s`，故真实 intelligence 分支会在物理 TurnStart 前拒绝，不能靠把 CLI generation 改为 `s+1` 修复；那样原控制端先拒绝 spawn。

这是静态源码推出的失败关闭错误，**本审查没有执行复现**。修复必须保留原 full binding 检查，并从真实 handoff receipt 保留 run generation；不得简单删除 generation/fence 验证。Draining 外层 current 进一步前进时，不应重写已有 run 的 admitted generation。

### 原测试为什么没有覆盖该分支

- `native_run_control_tests.rs:274–313` 的 intelligence 测试只验证原请求 payload digest 随四个 handoff 字段变化，没有执行 `run_intelligence`。
- `native_app_server_tests.rs:421–649` 启动真实 Agentd/App Server 的测试使用 `.run(...)`，即 intelligence = None。
- `hepta-agentd/tests/runtime_codex_product_e2e.rs:107–132` 虽然是原生产 caller E2E，但 `generation: 1` 后也调用 `.run(...)`。
- 固定完整 `codex-rs` 搜索中，`.run_intelligence(...)` 的产品调用只有原 CLI；没有已有测试实际进入该调用。搜索原文与 exit code 保留在本目录。

## 2. 什么才是取消所需的原 run 身份

该固定树没有名为 `RunIdentity` 的 Rust type。完整事实分别在 `RunStartRecordV1.snapshot`、`AgentRunSnapshot`、`AgentRunReceipt` 及原 handoff binding 中；报告中的“run 身份”是这些原字段的组合，不是声称已有另一个 API。

| 身份/证据 | 原来源 | 用途 |
|---|---|---|
| agent ID、当前 socket、UID/PID、process spawn | 可信宿主已有 origin 与 kernel peer；原 Agentd response | 只路由到当前原 owner；不可取自模型字符串或 UI label。 |
| exact signed Objective、run ID、body digest、issuer/message/sequence | 原 sender 已保留 raw + identity | 建立原请求身份，不授予新的取消或 effect 权限。 |
| Objective publication、RunStart anchor | 原 ObjectiveHistory journal ACK | 证明历史 publication；不提供 current run revision 或执行终态。Conflict / ExplicitAbstain 不能改称 runnable admission。 |
| request/objective/body/artifact digests、authority epoch、admitted generation、fence、deadline | 原 RunStart snapshot / AgentRunSnapshot | 完整、不可随替换进程/新 endpoint 重写的原 run binding。 |
| context、compilation envelope、当前 revision/phase | 原 Agentd handoff / run receipt | 精确匹配该运行实例，防混合及回退；revision 是当前协调器 revision，不是 Objective revision、journal sequence 或 Session observation sequence。 |
| native request/dispatch、thread、turn、correlation | 原 DurableInferenceControl + 原 App Server observed events | 真正停止/终态证据，只能由原执行 owner 产生或读取。 |

Desktop `services/hepta-os/src/wire.rs:282–345` 校验完整 receipt 后仅投影七个显示字段，主动丢弃 fence/context/compilation/deadline。`ui/core/src/hepta.rs:113–151` 明确其只是 observation。**不得拿这个显示对象构造取消 authority。**

仅先 RunStatus 再 `run_cancel(run_id, revision)` 也不是全身份原子校验：两次调用间存在状态变化；原 `remove_closed_run` 还允许移除闭合 run，之后同 run ID 可重建。未来面向 Desktop 的严格取消 owner 路径须在原 owner 的同一 serialized mutation 内检查完整原 binding，而非新增 UI ledger 或乐观预检。

## 3. 原 disposition 与 unknown 的真实边界

| 原结果 | 可以报告 | 不可以报告 |
|---|---|---|
| CancelledBeforeDispatch | 原协调器在 logical dispatch 前将 run 标为 Cancelled | 不能据此抹去历史副作用或声称独立 durability；该协调状态尚未跨崩溃保留。 |
| CancellingAfterDispatch | 原协调器已接受取消，等待执行 owner 的 terminal observation | 不能报告模型/设备已停止；目前外部取消尚未接入原 native observe。 |
| AlreadyTerminal | 原 coordinator 已是 Cancelled/Succeeded/Failed；应保留返回的具体 phase | 不能把 Succeeded/Failed 都显示成取消成功，也不能据此推导取消原因。 |
| request_rejected | 当前调用返回 owner rejection observation | 不能总称“修改前拒绝”：`cancel_run:347–355` 会先 expire_record；超 cancel ACK deadline 可先改 Indeterminate/revision，再返回 InvalidTransition。 |
| 部分写入、丢 ACK、进程退出、缺 run、generation/fence 错、超时 | unknown / reconciliation required，保留本次发送许可已消耗 | 不能重授许可、重新提交 Objective、把缺行当作未执行。 |
| RunStatus terminal_observed | 原 coordinator 声明终态 | 不等于独立的物理终态证明；原 RunObserveTerminal 写端接收 phase+bool/revision，真正 correlation 校验位于原 worker。Desktop 不得调用该写端口制造终态。 |

`lane_b_runtime.rs:675–709` 的取消 ACK deadline 过期会变为 Indeterminate，保留容量；`recover_indeterminate` 本身禁止 redispatch，但全原树只有 tests 调用它，没有当前 Agentd 启动接线。原 `ObjectiveRuntimeHost::reconcile` 在匹配原 generation/fence/auth 时将 immutable RunStart 投影为 admitted；它没有取消 tombstone。正常 supervisor generation 变化可使旧记录被跳过，这并不能替代跨崩溃取消事实。

## 4. wire / peer / authorization

原 `control.rs:96–139` 读一个有界 newline JSON frame，socket `:213–225` 为 0600、私有父目录；该 serve path 没有 `SO_PEERCRED` 方法权限分派或逐 run 取消签名。原 `client.rs:739–781` 校验 schema/request/agent/spawn，但不校验 peer UID/PID，也不校验 current_generation 与内部 receipt 身份。这是现有 owner-only local control trust profile，不能把它当成模型可调用的通用遥控端口。

Desktop 原 Objective transport `objective/mod.rs:414–475` 已有可复用的严格 UDS边界：私有 canonical path、UID/PID、单帧+EOF、有界 deadline、逐次成功写入 byte count。新 canceller若以后实现应沿同机制独立 typed method；不能因原 AgentdClient 名称相同就丢弃现有宿主 peer 防护。

历史 Objective signature 的作用是身份/原 admission，不能冒充新的 RunCancel grant。取消所需的当前 trusted-host access/owner policy 必须沿原宿主权威；原 `require_run_reconciliation_ready` 允许 Draining，不能错误复用要求 Running、ready、未过期 Objective 的 admission gate。owner fenced/lost 时，执行宿主已有独立精确 turn 的 containment interrupt 路径应保留，不能默默生成新权限。

## 5. 没有闭合的生产输入/实现

1. 已 installed 原 CognitiveStore/ProductionDurableWriter、active lease/live verifier 与独立 current-cut checkpoint 生产 provider。本审查固定 db91 的原 checkpoint trait 不能被 echo、现场自算 cut 或测试实现替代。
2. 当前可信 Agentd endpoint/UID/PID/spawn 与原 admitted run 全身份；display observation 不足。
3. 原 native execution 宿主、原 DurableInferenceControl 实例、现有 final-use authorizer、真实 App Server connection 与 thread/turn binding。无需也不得由 UI 新建 scheduler、journal 或签名者。
4. 原 sender 的独立 post-send cancellation 生命周期、完整 request/receipt 保留、跨进程唯一 claim、unknown 无重授、每次 mutation 的独立 full-cut ACK。原 LocalCancelled / Submission / History 均不能冒用。
5. 原 RunStart owner 的取消/派发恢复约束或原执行 journal 的受信接合，防取消事实在旧 publication 重投影时遗失；不建立另一份 run owner。
6. 原执行 owner 的 terminal readback 到 Session 的 typed 只读接线，保留“owner 声明”“已独立保留”“物理观察”等实际区别，不把 ACK 当停止证明。

## 当前决策

先实现 `IMPLEMENTATION_PLAN.md` 的原执行宿主窄片，保持 #256 Send/Cancel 产品资格边界。随后由根代理安排原 workspace owning-package tests；此时不能引用先前 memory 322、host 14 或任意旧 CI 成功作为这个新分支的验证。
