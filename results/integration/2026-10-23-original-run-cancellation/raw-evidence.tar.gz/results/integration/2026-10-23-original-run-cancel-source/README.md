# Original run cancellation: isolated source candidate

Status: product source and regression candidates only. Official Rust 1.95
`rustfmt` has parsed/formatted the candidate. No Cargo, original test recipe,
Agentd, App Server, QEMU or GitHub operation has been run for this slice.
The actual execution result is not yet known.

Base: Hepta `db91f9ec316ba1472e7adf97f8415949de012469`, tree
`81c03af04be56659d3eb4da71bf61aeac34c949f`. Publication must compare the exact
preimage against the then-current stacked head (45f / later checkpoint work).
Only the `change/` directory is the candidate; the original shared checkout
and its manifests, locks and protocol are untouched.

The fixed Cargo manifest contains 187 explicit workspace member entries. This
source-only check did not run Cargo metadata or recompute the fully resolved
workspace package count; earlier package-graph counts must retain their own
original receipts and source pins.

## Problem and behavior

The original CLI passes its sole `--generation` to `NativeWorkerConfig` and
then to `AgentdClient` as the process spawn. Original Agentd requires its live
Running generation to be spawn + 1, and admits Objective runs at that Running
generation. The original worker nevertheless compared the dispatched run
receipt's generation to the process spawn. Its intelligence path therefore
refused a legitimate spawn 1 / run 2 before a physical turn could start.

The candidate keeps the public config/CLI field source compatible and spawn
only. It retains the original handoff's immutable run ID, context, compiled
envelope, authority epoch, admitted generation, fence and deadline. Subsequent
handoff/dispatch/readback receipts must match those fields and the applicable
revision transition. An idempotent dispatch ACK remains unable to authorize a
second physical turn. The spawn + 1 rule is this original Agentd lifecycle
profile's verified invariant, not a general equivalence of generation fields.

The existing observation loop now also reads that original run on its existing
owner tick. A valid `Cancelling` causes the existing native journal cancellation
and exact thread/turn `TurnInterrupt`; it does not issue another RunCancel.
Missing, mixed, regressed or Indeterminate observations quarantine the local
boundary and contain the exact turn, without writing a guessed run terminal.
A rejected/mixed local cancellation ACK also keeps the retained revision and
quarantines the boundary; rejection can have followed an original expiry
mutation and never proves that no mutation occurred.

Only the existing original App Server event/correlation path can establish a
physical terminal. Its physical Interrupted/Completed facts can still be
retained alongside a Quarantined boundary. They cannot make an unresolved run
projection terminal or make `NativeRunOutput::succeeded()` true. The original
terminal publication path remains guarded by observed correlation and owner
authority; no new RunObserveTerminal protocol or display-derived authority was
introduced. The outer daemon can advance to Draining without rewriting the
retained admitted generation; its existing health/authority refusal remains.

## Files and review size

The product delta is in `native_app_server.rs` and the new private
`native_run_monitor.rs`. Two sibling test files cover the real host branch and
the retained binding. The only observation hook is cfg(test, unix), task-local,
and records actual calls to the unchanged interrupt transport. A count alone
cannot satisfy the branch tests.

The full diff slightly exceeds the repository's usual 800-line review target
because it includes the real-owner fixture and refusal matrix. Product logic
itself is below 500 changed lines. If split for landing, the coherent stages
are (1) retained handoff/dispatch binding with spawn/run separation and its
unit matrix; (2) observation-loop cancellation consumption and actual original
host tests. The final assembled candidate must still run the whole owning
package; staged snippets or a syntax result do not qualify it.

## Scope and remaining production gaps

- This is current-process execution-host cancellation. It is not a new durable
  cancellation domain, scheduler, ledger, writer, signer or default permission.
- Original Agentd run projections remain in-memory. Cross-crash cancellation,
  original RunStart replay coordination and durable cancellation publication
  are not implemented by this change.
- The 500 ms tick is a polling cadence, not a hard wall-clock cancellation
  guarantee. A cancellation can race the last read, TurnStart and completion.
  The original actual-event/revision boundaries decide the result.
- The original owner-only UDS trust profile is unchanged. A UI display receipt
  is not cancellation authority; Desktop's unused local-send cancellation must
  not be reused after send. The Desktop post-send RunCancel adapter and full
  expected-snapshot cancellation API remain separate work.
- Real-host tests use original Fleet/Agentd/App Server/native journal paths,
  but their provider and FinalUse issuer are explicit fixtures. They enter at
  the trusted original RunStart/RunAttachContext APIs, not at a production
  signed Objective/seven-owner compiler or restored production checkpoint.
- No manifest, lock, schema, protocol, original journal format or production
  credential has been changed.

The earlier fixed-source investigation and source identities are in
`../run-cancel-gap-review/`. New execution evidence must remain separate from
the already completed memory/host tests for other source pins.
