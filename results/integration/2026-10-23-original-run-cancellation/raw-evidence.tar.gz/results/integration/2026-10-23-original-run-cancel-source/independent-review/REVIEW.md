# Independent review of the original RunCancel consumer slice

## Identity and result

The four reviewed candidate files match `work/original-run-cancel/publication/source-manifest.json`, SHA-256 `f2aff212bce918e175f9e938606fe61b38abf5efed211cc2ea79e968aca4bddf`. Their SHA-256, Git blob identities, lengths and file modes were checked independently. The existing file's preimage and the three new files' absence were checked directly against local Git objects at Hepta commit `db91f9ec316ba1472e7adf97f8415949de012469`, tree `81c03af04be56659d3eb4da71bf61aeac34c949f`.

No concrete blocking source error was found in this four-file scope. This is a read-only review, not a Rust compilation or execution result. The five binding tests and three original-host branch tests remain authored and unexecuted. The exact checked inputs and the six original API source identities are retained in `review-inputs.json`.

## Checked behavior

### Spawn identity and the admitted run remain distinct

The original `AgentdClient` puts the immutable process spawn generation into control requests, including RunCancel, RunObserveTerminal and RunStatus (`codex-rs/hepta-agentd/src/client.rs`, lines 404–463). The original process refresh accepts Starting at spawn, Running at spawn + 1, and Draining at spawn + 2; other combinations are fenced (`state.rs`, lines 336–353). This explicitly supports the candidate's Running-generation check on the fixed source, rather than merely inferring it from a test using 1 and 2.

`RetainedIntelligenceRun::from_handoff` retains the actual original receipt's immutable run identity, context and compilation digests, authority epoch, generation, fence and deadline. It checks the expected ContextAttached revision and the fixed original fence material. Subsequent observations must retain all of those values and cannot move the revision backwards. This does not create an authority token or a second run owner.

### One fresh dispatch acknowledgement is required for physical send

The original coordinator can return an idempotent Dispatched receipt before checking the supplied expected revision (`lane_b_runtime.rs`, lines 307–331). The candidate explicitly rejects such a reply as a new physical-send permission. `accept_dispatch` requires the retained revision plus exactly one, the Dispatched phase, unchanged binding, and a non-idempotent acknowledgement. The worker still has its original durable native-dispatch journal and original FinalUse authorization boundary.

This client-side check is materially useful: reading an existing Dispatched projection cannot authorize a competing worker to repeat `turn/start`.

### Observed cancellation does not cause a second cancellation request

The observation loop reads the original RunStatus through the existing client. An exact next-revision Cancelling receipt is consumed once. `ObservationFailure::OwnerCancelling` proceeds to containment of the already-bound App Server thread and turn without sending RunCancel again, preserving the original cancellation reason and revision.

Missing, mixed, stale, Indeterminate or terminal coordinator projections are treated as unresolved at this boundary. They do not substitute for an App Server terminal witness. The original exact thread/turn can be interrupted for containment, while `intelligence_reconciled = false` prevents an inferred run-terminal mutation.

For a locally initiated cancellation, a failed or mixed RunCancel acknowledgement cannot advance the retained revision. The candidate quarantines the native result, records that reconciliation remains required, and still performs exact-turn containment. It does not guess a new revision or rearm dispatch. The original coordinator can mutate expiry state before rejecting a request (`lane_b_runtime.rs`, lines 334–389); this conservative treatment correctly preserves that ambiguity.

### Terminal publication still requires the original observation and authority

`commit_intelligence_terminal` requires an actually observed terminal, the original correlation digest, and current owner health. It writes through the original RunObserveTerminal API and checks the returned retained identity and terminal phase. The original coordinator's compare/revision and transition rules remain in effect (`lane_b_runtime.rs`, lines 392–432).

The grace observation after interruption does not use the original run projection as a terminal substitute. A terminal projection alone, an interrupt acknowledgement alone, or an unresolved cancellation acknowledgement cannot cause an invented successful run outcome.

## Test and fixture review

The five pure binding tests exercise spawn 1 versus run 2, rejection of idempotent dispatch, every retained identity field, backwards and mixed revisions, missing/Indeterminate/terminal projections, single consumption of Cancelling, and rejection of unexpected cancellation dispositions and revision advances. Failed validations assert that the retained binding is unchanged.

The three branch tests use the original `CognitiveTestHost`, Agentd control APIs, native durable journal and App Server transport. They check completion, an independently issued RunCancel, and an unresolved original run. They assert one physical provider request, the exact interrupted thread/turn, the real correlated terminal where applicable, the original coordinator readback, and native journal readback after reopening.

The original `ResponseMock` records a request in its matcher before the delayed response is delivered (`codex-rs/core/tests/common/responses.rs`, `ResponseMock::requests`, `base_mock`, and `mount_response_once`). Waiting for that recorded request therefore provides a real provider-request synchronization point; it does not wait for the 30-second delayed completion.

The expected final coordinator receipts do not copy the observed `idempotent` field. The fixed original `AgentRunCoordinator::run` explicitly returns a non-idempotent observation (`lane_b_runtime.rs`, lines 542–546), so the expected receipt can remain independent of the result.

The fixture deliberately enters through the trusted original RunStart/RunAttachContext APIs with test digests, a test provider and an independent test FinalUse issuer. This does not qualify production signing inputs or the signed Objective compiler. No production trust root, production authority deployment, or crash-recovery qualification follows from these tests.

## Limits that must remain explicit

- The coordinator is still the original in-memory run owner; this slice does not make RunCancel crash-durable or implement a durable client cancellation outbox.
- The retained monitor is current-process state. Native journal reopening in the tests does not prove recovery of the original coordinator or of the cancellation monitor after process loss.
- A 500 ms observation interval is a polling schedule, not a hard termination deadline. RPC waits, scheduling, the App Server and actual correlated terminal delivery remain relevant. A cancellation racing immediately after a successful status read is consumed by a subsequent observation, subject to the existing bounded waits.
- A failed or unknown original acknowledgement is not evidence that the original owner made no transition. The candidate preserves the unknown state rather than choosing a revision for retry.
- These eight new tests still require the original owning-package gate. Formatter success alone does not establish type correctness or runtime behavior, and no local Cargo command was run as part of this review.

## Review provenance

`review-inputs.json` records the candidate identities, original Git commit/tree and six original source files checked against their Git blobs. No candidate file, shared workspace file, dependency manifest, lock, executable or remote repository was changed by this review.
