# Original Run worker library CI candidate

This change adds `.github/workflows/hepta-original-run-worker.yml` as an explicit
source-head gate for the frozen original RunCancel consumer candidate. It runs
the original **entire `codex-hepta-infer-worker-host` library test selection** on
the PR head, then requires eight precise new Rust test names in fresh JUnit.

**Current evidence is source and static validation only. No worker Rust test,
Cargo build, GitHub workflow, Agentd process or AppServer was executed by this CI
preparation task. The eight new Rust tests remain pending actual execution.**

## Inputs and publication identity

The starting workflow is the exact published
`.github/workflows/hepta-objective-owner.yml`, Git blob
`f661e8d7acaa3c1ea25a14baad1f10c9d5a479a4`. Its published readback is recorded in
`work/owner-ci/publication/root-3444-ci-readback.json` at `5a3ffeb70a…`; the parent
publisher's complete-tree readback at `45f1e7d471c9e0720ce2c149da92629f785a01a4`
records the subsequent stack. The latter commit is the reference base, with tree
`62e0c4a173763426a0a6d4e5c3d1fb8df7ce653d`.

The original task inputs were compared to the locally available exact
`db91f9ec316ba1472e7adf97f8415949de012469` Git objects. This task did **not** fetch
or directly resolve a local `45f1e7d` object. `validation/input-identity.json`
distinguishes that limitation from the publisher's available readback chain.
Before publication, the parent must verify the new workflow path is absent at
the actual current stack head. No existing workflow or its branch guard changes.

The separate four-source Rust candidate remains frozen under
`work/original-run-cancel/publication/source-manifest.json`, SHA-256
`f2aff212bce918e175f9e938606fe61b38abf5efed211cc2ea79e968aca4bddf`.
The static verifier rechecks all four complete source identities and the actual
module aliases/test functions. This CI task does not change those sources,
Cargo manifests, the Cargo lock, Bazel manifests or locks, or nextest config.

## Actual command and execution scope

The workflow is a normal `pull_request` workflow on opened, synchronize,
reopened and ready-for-review events. It has no head-branch, base-branch, draft
or proposal selector. Its broad path filters cover `codex-rs/**`, this workflow,
the original CI actions/scripts, the root justfile and Bazel lock inputs. A
documentation-only PR outside those paths does not trigger it.

The runner checks out `github.event.pull_request.head.sha`, reads back its
commit/tree, and recomputes the Git blob, SHA-256 and mode of every tracked
checkout leaf. Both tracked-byte drift and untracked source-tree changes
refuse qualification. Every original command verifies the same source before
and after execution, with full terminal verification as well.

It retains the original setup actions and their pinned action SHAs, the
`prepare-bazel-ci`/`setup-bazel-ci`/`setup-ci` chain, native system OpenSSL and
other original prerequisites, Rust **1.95.0**, and the original checksum-verified
V8 archive/binding resolver. No new workspace, resolver, binary downloader,
manifest rewrite or lock update is introduced. The effective metadata must
still identify the original **193-member profile** and the original workspace
root. This static task did not execute metadata or requalify that count; the
literal original manifest's member entries and Cargo's effective graph are
different quantities.

The complete worker test command is:

```text
just test --locked --cargo-profile dev-small --build-jobs 1 --test-threads 1 -p codex-hepta-infer-worker-host --lib --no-tests fail
```

There is no `-E`, test-name filter, alternate manifest, synthetic workspace or
ignored-test override. Original default selection remains in force. One Cargo
build job, one nextest test thread, incremental compilation disabled, the
original `dev-small` profile and a 240-minute CI job limit make the resource
profile explicit. Actual runner capacity, dependency resolution and test
behavior remain to be measured by CI.

The workflow also runs the original `just fmt --check --base <PR base>` and
scoped `just fix -p codex-hepta-infer-worker-host --locked --profile dev-small
--lib`, followed by final formatting. Any source or lock change made by a fix
refuses the gate. The original fix command permits warnings; a zero exit is
not a claim of warning-free or `-D warnings` validation.

## Exact eight test identities

The `native_app_server` root module is read from the original crate's `lib.rs`.
The candidate declares `run_monitor` and `cancellation_tests` with explicit
paths, and `run_monitor` declares its own `tests` alias. These aliases yield:

| Full nextest test name | Intended branch |
| --- | --- |
| `native_app_server::run_monitor::tests::spawn_one_retains_run_two_and_dispatch_cannot_be_reused` | Spawn/run distinction and no repeated dispatch |
| `native_app_server::run_monitor::tests::every_retained_identity_field_and_revision_is_checked_without_advancing` | Full retained identity and revision checks |
| `native_app_server::run_monitor::tests::missing_indeterminate_and_terminal_projection_never_become_a_terminal_witness` | Refuse invented terminal evidence |
| `native_app_server::run_monitor::tests::external_cancelling_is_one_checked_revision_transition` | Consume original Cancelling transition |
| `native_app_server::run_monitor::tests::rejected_cancel_receipts_cannot_guess_or_roll_back_the_run_revision` | Refuse stale/mixed cancel receipt advancement |
| `native_app_server::cancellation_tests::original_intelligence_branch_keeps_spawn_one_and_run_two` | Original host execution branch |
| `native_app_server::cancellation_tests::original_external_cancel_interrupts_once_and_commits_correlated_terminal` | Original external cancel, single interrupt and correlated terminal |
| `native_app_server::cancellation_tests::original_indeterminate_run_stops_exact_turn_without_rewriting_run_terminal` | Exact-turn containment without invented run terminal |

The gate compares complete strings. A test with the same function name in a
different module, or a test whose name merely starts with the expected string,
does not satisfy the requirement. Duplicate full names, a different package or
binary, inconsistent counters, a required skipped test or any final library
failure/error refuse qualification. The full library can contain additional
original tests; their results remain in the same raw report and index.

## JUnit identity and version evidence

The gate installs and checks the effective **nextest 0.9.103**. The primary
source is nextest-rs/nextest commit
[`d2e7b879fb79975e8b47a8e3ce569b651e6381c0`](https://github.com/nextest-rs/nextest/tree/d2e7b879fb79975e8b47a8e3ce569b651e6381c0),
resolved by the parent from annotated tag `cargo-nextest-0.9.103`. The supplied
source files and original fixture were independently checked against their
Git blob, SHA-256 and byte identities in `base/nextest-0.9.103/proof.json`.

`nextest-metadata/src/test_list.rs:285–346` defines lib binary IDs as the Cargo
package name, preserving hyphens. `nextest-runner/src/reporter/aggregator/junit.rs`
uses that ID as the test suite name and case classname (`171–173`, `257–302`).
Consequently this lib expects `codex-hepta-infer-worker-host`, while its Rust
crate target is `codex_hepta_infer_worker_host`. The latter is deliberately
rejected as the JUnit classname. This conclusion comes from pinned primary
source, not from an executed worker binary.

The pinned original fixture omits a root skip counter and uses
`testsuite.disabled="0"`. The checker accepts omitted zero-only skip metadata
and validates any present `disabled` or `skipped` counter against the actual
cases. Missing nonzero metadata or contradictory values refuse. The original
reporter does not publish `TestSkipped` as JUnit cases (`193–203`), so a required
skipped test is also caught by its missing exact name. Raw nextest stderr is
retained to preserve the original selection/skipped summary.

The real local memory XML in
`work/checkpoint-current/validation/checkpoint-memory-all-02.junit.xml` was also
inspected: it contains 327 successful cases; the associated stderr reports
eight additional skips. That run used **nextest 0.9.149**, which writes different
skip-counter attributes. It is only a format comparison here, not evidence of
the pinned CI tool's behavior, and never worker test evidence.

The original `local` profile inherits `default`, including `retries = 1`, with
its unchanged test-specific overrides. The workflow preserves and publishes
the exact config, does not override retries, and retains `flakyFailure`/
`rerunFailure` evidence. A final pass after an allowed retry can pass the
original gate; neither the receipt nor this report calls it a zero-retry pass.

## Static verification actually performed

`run_static_validation.py` records all four exact commands, timestamps, exit
codes, complete stdout/stderr and their SHA-256 values. All four exited zero:

| Local command | Actual scope |
| --- | --- |
| `python3 validate_candidate.py` | Duplicate-key-rejecting YAML load and explicit schema checks; ten `bash -n` blocks; four inline Python programs parsed/compiled; command, source pin and eight exact Rust names checked |
| `python3 -O validate_candidate.py` | Same source guards remain effective with Python assertions disabled |
| `python3 test_junit_gate.py` | 38 synthetic parser and mocked command-boundary cases, all pass |
| `python3 -O test_junit_gate.py` | The same 38 synthetic cases, all pass |

The synthetic cases include each of the eight missing names independently,
prefix/module substitution, skip/failure/error, duplicate names, wrong
package/classname, counter mismatches, malformed/missing/multiple/symlink
reports, the original 0.9.103 fixture as an expected failing foreign-binary
input, original retry behavior, and both original skip-counter forms. The real
embedded runner's command boundary is also exercised with **only the external
command mocked**: a stale passing report is removed; no fresh report fails;
a fresh report cannot override command failure; source drift before or after
the command refuses qualification. These are Python checker tests, not any of
the eight Rust tests.

Each `junit-gate-*.json` retains the exact synthetic XML input, resulting index
or error and mocked-boundary receipt for every case. Syntax receipts retain
full Bash-parser stdout/stderr and hashes for all extracted scripts; their
complete source is also contained in the workflow. No actionlint or GitHub
execution is claimed.

## CI evidence and remaining limits

After actual publication, the workflow keeps complete raw command stdout and
stderr, fresh unmodified JUnit, exact test names/counters/retry evidence,
source/lock snapshots, original nextest configuration, tool versions, verified
V8 input hashes, per-command results and final qualification. Every outcome
uses an `always()` finalizer and upload-artifact step. A killed or unavailable
runner is not assumed to complete an upload.

`worker_library_qualified` requires all setup, full worker, format, fix and
source checks to succeed on that head. `full_workspace_qualified`,
`bazel_qualified`, `native_guest_qualified`, `cross_crash_run_cancel_qualified`
and `production_authority_qualified` remain false. Unit qualification does not
implement crash-durable RunCancel, the Desktop post-send cancellation adapter,
a production signing/permission source or a new scheduler/ledger. The original
host fixtures use clearly identified test authority. The 500 ms observation
tick in the Rust candidate is not a hard physical cancellation deadline.
