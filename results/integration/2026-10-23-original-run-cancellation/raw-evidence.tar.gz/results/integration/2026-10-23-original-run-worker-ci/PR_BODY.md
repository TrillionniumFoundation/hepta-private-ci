## Why

The original RunCancel consumer candidate adds five retained-binding tests and
three original-host cancellation tests in the worker library. Existing
proposal/aggregate selectors and worker binary tests do not provide an explicit
PR gate for this entire library or these exact eight branches.

## Change

Add `hepta-original-run-worker.yml` on normal PR source heads, with no branch or
draft skip. Reuse the original workspace, lock, Rust 1.95.0, preparation actions,
native OpenSSL and verified V8 resolver. Run the full original
`just test --locked --cargo-profile dev-small --build-jobs 1 --test-threads 1 -p codex-hepta-infer-worker-host --lib --no-tests fail`,
plus original format and scoped fix recipes, rejecting source or lock changes.

Require fresh JUnit and all eight complete Rust test names. Reject wrong
package/binary/classname, prefix substitutes, duplicates, inconsistent counters,
required skips, failures, stale reports and source drift. Preserve the original
nextest local profile and retry policy; retain raw reports and retry evidence.
The pinned nextest 0.9.103 primary implementation and fixture establish its lib
binary ID and original `disabled`/omitted-zero-skip format.

## Validation performed

- YAML and explicit workflow checks passed in normal and optimized Python.
- All ten Bash blocks passed `bash -n`; all four inline Python programs parsed
  and compiled without executing their original commands.
- The exact embedded checker passed 38 synthetic cases under normal Python and
  the same 38 under `python -O`, including each missing required Rust case and
  mocked command-boundary freshness, exit-code and source-drift failures.
- The separate four Rust source files remain byte-identical to their frozen
  manifest. No Cargo, GitHub workflow or new Rust test was executed by this
  static preparation task.

This is an explicit future CI gate, not a report of its success. Worker
qualification, build capacity and all eight Rust tests remain pending actual
CI execution. It does not qualify the full workspace, Bazel/native guests,
crash-durable RunCancel, Desktop post-send cancellation or production authority.
