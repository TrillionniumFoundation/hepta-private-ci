#!/usr/bin/env python3
"""Retain complete local static/synthetic stdout and stderr; never invoke Cargo."""

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "validation"


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main():
    rows = []
    for label, args in (
        ("syntax-normal", ["validate_candidate.py"]),
        ("syntax-optimized", ["-O", "validate_candidate.py"]),
        ("junit-normal", ["test_junit_gate.py"]),
        ("junit-optimized", ["-O", "test_junit_gate.py"]),
    ):
        command = [sys.executable, *args]
        started = datetime.now(timezone.utc).isoformat()
        stdout = OUT / (label + ".stdout")
        stderr = OUT / (label + ".stderr")
        with stdout.open("wb") as out, stderr.open("wb") as err:
            result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err, check=False)
        row = {"name": label, "argv": command, "cwd": str(ROOT), "exit_code": result.returncode,
               "started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(),
               "stdout": identity(stdout), "stderr": identity(stderr)}
        rows.append(row)
        print(json.dumps(row), flush=True)
    receipt = {"scope": "Static workflow validation and synthetic checker tests only",
               "commands": rows, "all_passed": all(row["exit_code"] == 0 for row in rows),
               "Cargo_executed": False, "GitHub_operations": False, "workflow_executed": False,
               "actual_worker_tests_executed": False}
    (OUT / "local-execution.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return 0 if receipt["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
