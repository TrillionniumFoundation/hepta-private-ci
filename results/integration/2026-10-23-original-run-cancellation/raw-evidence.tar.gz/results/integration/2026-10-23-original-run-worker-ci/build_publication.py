#!/usr/bin/env python3
"""Prepare complete source/evidence entries for parent publication; no remote calls."""

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "publication"
PREFIX = "results/integration/2026-10-23-original-run-worker-ci"
WORKFLOW = ".github/workflows/hepta-original-run-worker.yml"
WORKFLOW_SHA = "652edd3c54408eb9613653538f1e58c6ba6f73a5c123ae6fe7bd0e75c895f702"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def fingerprint(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def entry(local, path):
    data = local.read_bytes()
    text = data.decode("utf-8", errors="strict")
    require(text.encode("utf-8") == data, f"Non-lossless UTF-8: {local}")
    value = fingerprint(local)
    return {"path": path, "mode": "100644", "type": "blob", "encoding": "utf-8", "content": text,
            "candidate_git_blob": value["git_blob"], "candidate_sha256": value["sha256"],
            "bytes": value["bytes"], "unicode_characters": len(text), "whitespace_delimited_words": len(text.split()),
            "lines": len(text.splitlines()), "preimage_git_blob": None, "preimage_sha256": None,
            "source_path": str(local.resolve())}


def main():
    workflow = ROOT / "change" / WORKFLOW
    require(fingerprint(workflow)["sha256"] == WORKFLOW_SHA, "Frozen workflow changed")
    execution = json.loads((ROOT / "validation/local-execution.json").read_text())
    require(execution["all_passed"] and not execution["Cargo_executed"]
            and not execution["workflow_executed"], "Unexpected execution scope/status")
    for row in execution["commands"]:
        require(row["exit_code"] == 0, f"Local validation failed: {row['name']}")
        for kind in ("stdout", "stderr"):
            raw = Path(row[kind]["path"])
            require(fingerprint(raw)["sha256"] == row[kind]["sha256"], f"Raw stream changed: {raw}")
    for name in ("candidate-syntax.json", "candidate-syntax-optimized.json", "junit-gate-normal.json", "junit-gate-optimized.json"):
        value = json.loads((ROOT / "validation" / name).read_text())
        require(value["workflow"]["sha256"] == WORKFLOW_SHA, f"Stale workflow validation: {name}")
        require(not value["Cargo_executed"] and not value["workflow_executed"], f"Wrong scope: {name}")
        if name.startswith("junit"):
            require(value["tests_run"] == 38 and value["successful"] and len(value["cases"]) == 38,
                    f"Synthetic gate result incomplete: {name}")
    source = [entry(workflow, WORKFLOW)]
    selections = [
        "README.md", "PR_BODY.md", "build_candidate.py", "validate_candidate.py", "test_junit_gate.py",
        "run_static_validation.py", "build_publication.py", "publication/source-manifest.json",
        "validation/input-identity.json", "validation/reference-provenance.json", "validation/local-execution.json",
        "validation/candidate-syntax.json", "validation/candidate-syntax-optimized.json",
        "validation/junit-gate-normal.json", "validation/junit-gate-optimized.json",
        "validation/syntax-normal.stdout", "validation/syntax-normal.stderr",
        "validation/syntax-optimized.stdout", "validation/syntax-optimized.stderr",
        "validation/junit-normal.stdout", "validation/junit-normal.stderr",
        "validation/junit-optimized.stdout", "validation/junit-optimized.stderr",
        "validation/evidence-rounds.json", "validation/root-independent/candidate-syntax.json",
        "validation/root-independent/junit-gate-optimized.json",
        "base/.github/workflows/hepta-objective-owner.yml", "base/nextest-0.9.103/proof.json",
        "base/nextest-0.9.103/fixtures/nextest-tests-junit.xml",
        "base/nextest-0.9.103/nextest-runner/src/reporter/aggregator/junit.rs",
        "base/nextest-0.9.103/nextest-metadata/src/test_list.rs",
    ]
    review = ROOT / "validation/independent-review.json"
    if review.exists():
        selections.append("validation/independent-review.json")
    evidence = [entry(ROOT / relative, PREFIX + "/" + relative) for relative in selections]
    frozen = ROOT.parent / "original-run-cancel/publication/source-manifest.json"
    require(fingerprint(frozen)["sha256"] == "f2aff212bce918e175f9e938606fe61b38abf5efed211cc2ea79e968aca4bddf",
            "Rust source input manifest changed")
    for row in json.loads(frozen.read_text())["entries"]:
        require(fingerprint(Path(row["source_path"])) == {"bytes": row["bytes"], "sha256": row["candidate_sha256"],
                                                        "git_blob": row["candidate_git_blob"]}, "Frozen Rust source changed")
    evidence.append(entry(frozen, PREFIX + "/reference/frozen-rust-source-manifest.json"))
    descriptors = [{key: value for key, value in row.items() if key != "content"} for row in source + evidence]
    index = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "source_reference_head": "45f1e7d471c9e0720ce2c149da92629f785a01a4",
        "source_reference_tree": "62e0c4a173763426a0a6d4e5c3d1fb8df7ce653d",
        "scope": "One new source-head worker CI workflow; complete static/synthetic local evidence, no Rust/CI execution",
        "no_remote_operations": True, "Cargo_executed": False,
        "new_workflow_path_requires_parent_absence_check_at_actual_publication_head": True,
        "frozen_Rust_4_source_files_unchanged": True, "source_entries": len(source),
        "evidence_entries_excluding_this_index": len(evidence), "entries": descriptors,
        "lossless_synthetic_evidence": "junit-gate-normal/optimized.json contain every exact XML input and parser result/command-boundary receipt; no test output was truncated",
        "lossless_shell_evidence": "candidate-syntax normal/optimized receipts retain all actual Bash stdout/stderr and extracted script identities; complete Bash/Python source is in the workflow",
        "actual_static_results": {"bash_blocks": 10, "embedded_python_blocks": 4,
                                  "synthetic_normal": 38, "synthetic_optimized": 38},
    }
    save(OUT / "evidence-index.json", index)
    evidence.append(entry(OUT / "evidence-index.json", PREFIX + "/evidence-index.json"))
    for kind, rows in (("source", source), ("evidence", evidence), ("all", source + evidence)):
        save(OUT / ("root-" + kind + "-entries.json"), rows)
    summary = {"source_files": len(source), "source_bytes": sum(row["bytes"] for row in source),
               "evidence_files": len(evidence), "evidence_bytes": sum(row["bytes"] for row in evidence),
               "workflow": fingerprint(workflow), "publication_entries": {}}
    for kind in ("source", "evidence", "all"):
        path = OUT / ("root-" + kind + "-entries.json")
        summary["publication_entries"][kind] = {"path": str(path), **fingerprint(path)}
    save(OUT / "summary.json", summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
