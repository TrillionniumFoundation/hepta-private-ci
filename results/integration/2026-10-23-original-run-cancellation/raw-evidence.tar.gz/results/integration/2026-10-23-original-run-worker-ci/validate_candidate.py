#!/usr/bin/env python3
"""Static validation only: parse the workflow and its Bash/Python, never run Cargo."""

from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import types
from unittest.mock import patch

import yaml


ROOT = Path(__file__).resolve().parent
WORKFLOW = ROOT / "change/.github/workflows/hepta-original-run-worker.yml"
OUT = ROOT / "validation"
EXPECTED_TESTS = {
    "native_app_server::run_monitor::tests::spawn_one_retains_run_two_and_dispatch_cannot_be_reused",
    "native_app_server::run_monitor::tests::every_retained_identity_field_and_revision_is_checked_without_advancing",
    "native_app_server::run_monitor::tests::missing_indeterminate_and_terminal_projection_never_become_a_terminal_witness",
    "native_app_server::run_monitor::tests::external_cancelling_is_one_checked_revision_transition",
    "native_app_server::run_monitor::tests::rejected_cancel_receipts_cannot_guess_or_roll_back_the_run_revision",
    "native_app_server::cancellation_tests::original_intelligence_branch_keeps_spawn_one_and_run_two",
    "native_app_server::cancellation_tests::original_external_cancel_interrupts_once_and_commits_correlated_terminal",
    "native_app_server::cancellation_tests::original_indeterminate_run_stops_exact_turn_without_rewriting_run_terminal",
}


class UniqueLoader(yaml.BaseLoader):
    def construct_mapping(self, node, deep=False):
        result = {}
        for key_node, value_node in node.value:
            key = self.construct_object(key_node, deep=deep)
            if key in result:
                raise ValueError(f"Duplicate YAML key: {key}")
            result[key] = self.construct_object(value_node, deep=deep)
        return result


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def embedded_python(shell):
    programs = []
    lines = shell.splitlines()
    index = 0
    while index < len(lines):
        match = re.search(r"<<'([A-Za-z_][A-Za-z_0-9]*)'", lines[index])
        if not match:
            index += 1
            continue
        marker = match.group(1)
        end = index + 1
        while end < len(lines) and lines[end] != marker:
            end += 1
        require(end < len(lines), f"Unclosed heredoc {marker}")
        programs.append("\n".join(lines[index + 1:end]) + "\n")
        index = end + 1
    return programs


def load_runner(output):
    """Load definitions for synthetic checker tests; __main__/execute never run."""
    document = yaml.load(WORKFLOW.read_text(), Loader=UniqueLoader)
    source = next(step for step in document["jobs"]["worker-library"]["steps"] if step.get("id") == "source")
    programs = embedded_python(source["run"])
    require(len(programs) == 1, "Expected one source runner")
    module = types.ModuleType("source_only_worker_runner")
    environment = {"GITHUB_WORKSPACE": str(ROOT), "WORKER_CI_EVIDENCE": str(output),
                   "SOURCE_SHA": "1" * 40, "BASE_SHA": "2" * 40}
    with patch.dict(os.environ, environment):
        exec(compile(programs[0], str(WORKFLOW) + "::source", "exec"), module.__dict__)
    return module


def verify_frozen_rust_names():
    manifest_path = ROOT.parent / "original-run-cancel/publication/source-manifest.json"
    manifest = json.loads(manifest_path.read_text())
    require(identity(manifest_path)["sha256"] == "f2aff212bce918e175f9e938606fe61b38abf5efed211cc2ea79e968aca4bddf",
            "Frozen RunCancel source manifest changed")
    paths = {}
    for row in manifest["entries"]:
        path = Path(row["source_path"])
        actual = identity(path)
        require(actual == {"bytes": row["bytes"], "sha256": row["candidate_sha256"],
                           "git_blob": row["candidate_git_blob"]}, f"Frozen Rust file changed: {path}")
        paths[path.name] = path
    app = paths["native_app_server.rs"].read_text()
    monitor = paths["native_run_monitor.rs"].read_text()
    require('#[path = "native_run_monitor.rs"]\nmod run_monitor;' in app, "Original monitor module alias changed")
    require('#[path = "native_run_cancellation_tests.rs"]\nmod cancellation_tests;' in app,
            "Original cancellation test module alias changed")
    require('#[path = "native_run_monitor_tests.rs"]\nmod tests;' in monitor, "Monitor test alias changed")
    lib = (ROOT / "base/codex-rs/hepta-infer-worker-host/src/lib.rs").read_text()
    require("pub mod native_app_server;" in lib, "Original root module alias changed")
    modules = {"native_run_monitor_tests.rs": "native_app_server::run_monitor::tests::",
               "native_run_cancellation_tests.rs": "native_app_server::cancellation_tests::"}
    observed = set()
    for filename, prefix in modules.items():
        source = paths[filename].read_text()
        for match in re.finditer(r"#\[(?:tokio::)?test(?:\([^\]]*\))?\]\s*(?:async\s+)?fn\s+(\w+)\(", source):
            observed.add(prefix + match.group(1))
    require(observed == EXPECTED_TESTS, "Eight exact workflow names do not match frozen Rust modules/functions")
    return {"manifest": str(manifest_path), **identity(manifest_path),
            "exact_names": sorted(observed), "Rust_executed": False}


def verify_original_nextest():
    root = ROOT / "base/nextest-0.9.103"
    proof = json.loads((root / "proof.json").read_text())
    require(proof["tag"] == "cargo-nextest-0.9.103"
            and proof["commit"] == "d2e7b879fb79975e8b47a8e3ce569b651e6381c0", "Wrong nextest source pin")
    for row in proof["files"]:
        require(identity(root / row["path"]) == {"bytes": row["bytes"], "sha256": row["sha256"], "git_blob": row["sha"]},
                f"Original nextest blob mismatch: {row['path']}")
    reporter = (root / "nextest-runner/src/reporter/aggregator/junit.rs").read_text()
    metadata = (root / "nextest-metadata/src/test_list.rs").read_text()
    require(".set_classname(test_instance.suite_info.binary_id.as_str())" in reporter,
            "Pinned reporter no longer uses binary ID as classname")
    require("let mut id = package_name.to_owned();" in metadata
            and "if kind == &RustTestBinaryKind::LIB || kind == &RustTestBinaryKind::PROC_MACRO" in metadata,
            "Pinned lib binary ID convention changed")
    return {"primary_repository": "nextest-rs/nextest", **proof,
            "lib_binary_id": "Cargo package name; not Rust underscore crate/target name",
            "expected_worker_classname_and_suite": "codex-hepta-infer-worker-host",
            "reporter_line_ranges": [[130, 191], [193, 203], [257, 268], [296, 303]],
            "binary_id_line_range": [285, 346],
            "pinned_fixture_counter_shape": "testsuites has no skip counter; testsuite has disabled=0",
            "fixture_is_worker_run": False,
            "actual_local_memory_nextest_version": "0.9.149 (different; not CI-pin execution evidence)"}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    text = WORKFLOW.read_text()
    document = yaml.load(text, Loader=UniqueLoader)
    require(list(document["on"]) == ["pull_request"], "Expected a normal PR trigger")
    trigger = document["on"]["pull_request"]
    require("branches" not in trigger and "branches-ignore" not in trigger, "No base branch selector permitted")
    require(set(trigger["types"]) == {"opened", "synchronize", "reopened", "ready_for_review"}, "PR event coverage changed")
    require("codex-rs/**" in trigger["paths"] and ".github/workflows/hepta-original-run-worker.yml" in trigger["paths"],
            "The candidate source and this workflow must trigger the gate")
    require("head.ref" not in text and ".draft" not in text, "No head branch or draft skip permitted")
    require(document["permissions"] == {"contents": "read"}, "Unexpected write permission")
    require(set(document["jobs"]) == {"worker-library"}, "Expected one explicit owning-package job")
    job = document["jobs"]["worker-library"]
    require("if" not in job and "strategy" not in job, "Job must not be conditionally skipped/sharded")
    require(job["runs-on"] == "ubuntu-24.04" and job["timeout-minutes"] == "240", "Runner profile changed")
    expected_env = {"RUSTUP_TOOLCHAIN": "1.95.0", "RUSTUP_AUTO_INSTALL": "0", "CARGO_INCREMENTAL": "0",
                    "CARGO_BUILD_JOBS": "1", "OPENSSL_INCLUDE_DIR": "/usr/include",
                    "OPENSSL_LIB_DIR": "/usr/lib/x86_64-linux-gnu",
                    "SOURCE_SHA": "${{ github.event.pull_request.head.sha }}",
                    "BASE_SHA": "${{ github.event.pull_request.base.sha }}"}
    require(all(job["env"].get(key) == value for key, value in expected_env.items()), "Original environment or source-head identity changed")
    steps = job["steps"]
    ids = [step["id"] for step in steps if "id" in step]
    require(len(ids) == len(set(ids)), "Duplicate step ID")
    by_id = {step["id"]: step for step in steps if "id" in step}
    require(by_id["checkout"]["with"] == {"ref": "${{ env.SOURCE_SHA }}", "fetch-depth": "0", "persist-credentials": "false"},
            "Checkout must read the exact source head")
    require(by_id["tools"]["uses"] == "./.github/actions/prepare-bazel-ci", "Original preparation required")
    require(by_id["rust"]["with"] == {"toolchain": "1.95.0", "components": "clippy,rustfmt,rust-src"}, "Original toolchain/components required")
    require(by_id["nextest"]["with"]["tool"] == "nextest@0.9.103", "Existing nextest version required")
    require(by_id["v8"]["env"]["V8_FROM_SOURCE"] == "0"
            and by_id["v8"]["env"]["RUSTY_V8_ARCHIVE"] == ""
            and by_id["v8"]["env"]["RUSTY_V8_SRC_BINDING_PATH"] == "", "Original verified V8 resolver required")
    require(by_id["worker"]["run"] == 'python3 "$WORKER_CI_EVIDENCE/run_worker.py" worker', "Original worker command not invoked")
    require(by_id["fix_worker"]["run"] == 'python3 "$WORKER_CI_EVIDENCE/run_worker.py" fix-worker', "Scoped original fix not invoked")
    for label in ("worker", "fix_worker", "format_final"):
        require(by_id[label]["if"] == "always() && steps.metadata.outcome == 'success' && steps.v8.outcome == 'success'",
                "Only prerequisite outcomes may guard original package commands")
    require(steps[-2]["if"] == steps[-1]["if"] == "always()", "Terminal receipts and artifact must run on all outcomes")
    require(steps[-1]["with"]["if-no-files-found"] == "error", "Missing evidence must fail")
    known_actions = set()
    for path in (ROOT / "base/.github").rglob("*.yml"):
        known_actions.update(re.findall(r"\buses:\s*([^\s#]+)", path.read_text()))
    actions = []
    for step in steps:
        if "uses" in step:
            uses = step["uses"]
            require(uses in known_actions and (uses.startswith("./") or re.fullmatch(r"[^@]+@[0-9a-f]{40}", uses)),
                    f"Action is not an original pinned input: {uses}")
            actions.append(uses)
    shell_checks = []
    python_checks = []
    for index, step in enumerate(steps, 1):
        if "run" not in step:
            continue
        name = step.get("id", f"step-{index:02d}")
        require(step["shell"] == "bash", f"Unvalidated shell in {name}")
        path = OUT / "shell" / (name + ".bash")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(step["run"])
        command = ["bash", "-n", str(path)]
        result = subprocess.run(command, capture_output=True, check=False)
        streams = {}
        for kind, raw in (("stdout", result.stdout), ("stderr", result.stderr)):
            raw_path = path.with_suffix("." + kind)
            raw_path.write_bytes(raw)
            streams[kind] = {"path": str(raw_path), **identity(raw_path), "content": raw.decode("utf-8")}
        shell_checks.append({"step": name, "argv": command, "exit_code": result.returncode,
                             "script": str(path), **identity(path), **streams})
        require(result.returncode == 0, f"Bash syntax failed in {name}")
        for source in embedded_python(step["run"]):
            program = OUT / "embedded-python" / f"{name}-{len(python_checks) + 1:02d}.py"
            program.parent.mkdir(parents=True, exist_ok=True)
            program.write_text(source)
            compile(ast.parse(source, str(program)), str(program), "exec")
            python_checks.append({"step": name, "script": str(program), **identity(program), "parse_compile": "passed"})
    require(len(shell_checks) == 10 and len(python_checks) == 4, "Unexpected unvalidated inline program count")
    runner = load_runner(OUT)
    require(runner.PACKAGES == {"worker": "codex-hepta-infer-worker-host"}, "Wrong owning package")
    require(runner.REQUIRED_WORKER == EXPECTED_TESTS and len(EXPECTED_TESTS) == 8, "Wrong exact required tests")
    require(runner.COMMANDS["worker"] == ["just", "test", "--locked", "--cargo-profile", "dev-small",
            "--build-jobs", "1", "--test-threads", "1", "-p", "codex-hepta-infer-worker-host", "--lib", "--no-tests", "fail"],
            "Worker command must be the full original library recipe without filters")
    require(runner.COMMANDS["fix-worker"] == ["just", "fix", "-p", "codex-hepta-infer-worker-host", "--locked", "--profile", "dev-small", "--lib"],
            "Wrong scoped Clippy recipe")
    require(runner.COMMANDS["format"] == ["just", "fmt", "--check", "--base", "2" * 40], "Wrong original format recipe")
    source = next(Path(row["script"]).read_text() for row in python_checks if row["step"] == "source")
    for token in ('len(members) != 193', 'value["files_sha256"] == original["files_sha256"]',
                  'profiles["default"].get("retries") != 1', 'path.unlink()',
                  'receipt["source_before"] = verify_source()', 'receipt["source_after"] = verify_source()'):
        require(token in source, f"Missing original source/profile gate: {token}")
    require(not any(isinstance(node, ast.Assert) for node in ast.walk(ast.parse(source))), "Gate assertions must survive Python -O")
    for command in runner.COMMANDS.values():
        require(not set(command) & {"-E", "--filterset", "--offline", "--all-features", "--workspace", "cargo-test"},
                "Unreviewed command filter or graph override")
    receipt = {"created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "scope": "Static YAML/schema/Bash parsing/Python compile; runner definitions loaded only for command inspection.",
               "workflow": {"path": str(WORKFLOW), **identity(WORKFLOW), "lines": len(text.splitlines())},
               "python_version": sys.version, "python_optimization": sys.flags.optimize,
               "yaml_parser": "PyYAML " + yaml.__version__ + " BaseLoader with duplicate-key rejection",
               "yaml_and_schema": "passed", "original_pinned_actions": actions,
               "bash_syntax": shell_checks, "embedded_python_syntax": python_checks,
               "prospective_command_plan": runner.COMMANDS, "frozen_rust_test_names": verify_frozen_rust_names(),
               "original_nextest_format": verify_original_nextest(),
               "workflow_executed": False, "Cargo_executed": False, "GitHub_operations": False,
               "GitHub_actionlint_executed": False,
               "qualification": "Only source and syntax; no original Rust test or CI qualification."}
    path = OUT / ("candidate-syntax-optimized.json" if sys.flags.optimize else "candidate-syntax.json")
    path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"receipt": str(path), "workflow": receipt["workflow"], "bash_blocks": len(shell_checks),
                      "python_blocks": len(python_checks), "exact_new_Rust_names": 8, "syntax_passed": True,
                      "Cargo_executed": False}, indent=2))


if __name__ == "__main__":
    main()
