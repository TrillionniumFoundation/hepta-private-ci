#!/usr/bin/env python3
"""Synthetic regression tests of the exact embedded CI checker, never Rust tests."""

from pathlib import Path
import copy
import hashlib
import io
import json
import subprocess
import sys
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

from validate_candidate import EXPECTED_TESTS, OUT, WORKFLOW, identity, load_runner


PACKAGE = "codex-hepta-infer-worker-host"
MODE = "optimized" if sys.flags.optimize else "normal"
FIXTURES = OUT / "junit-fixtures" / MODE
ROWS = []
NAMES = sorted(EXPECTED_TESTS)


def report():
    root = ET.Element("testsuites", {"name": "nextest-run"})
    suite = ET.SubElement(root, "testsuite", {"name": PACKAGE})
    for name in NAMES:
        ET.SubElement(suite, "testcase", {"name": name, "classname": PACKAGE})
    return recount(root)


def recount(root):
    for node in [root, *root.findall("./testsuite")]:
        cases = node.findall(".//testcase")
        node.attrib.update(tests=str(len(cases)), failures=str(sum(c.find("failure") is not None for c in cases)),
                           errors=str(sum(c.find("error") is not None for c in cases)),
                           skipped=str(sum(c.find("skipped") is not None for c in cases)))
    return root


def bytes_of(root):
    return ET.tostring(root, encoding="utf-8", xml_declaration=True) + b"\n"


def remove_case(root, name):
    suite = root.find("./testsuite")
    suite.remove(next(case for case in suite if case.attrib["name"] == name))
    return recount(root)


def replace_name(root, suffix):
    root.find(".//testcase").attrib["name"] += suffix
    return root


def status(root, tag):
    ET.SubElement(root.find(".//testcase"), tag, {"message": "synthetic final status"})
    return recount(root)


def duplicate(root, failing=False):
    suite = root.find("./testsuite")
    new = copy.deepcopy(suite[0])
    if failing:
        ET.SubElement(new, "failure")
    suite.append(new)
    return recount(root)


def wrong_attribute(root, location, key, value):
    (root if location == "." else root.find(location)).attrib[key] = value
    return root


def positive_retry(root):
    ET.SubElement(root.find(".//testcase"), "flakyFailure", {"message": "synthetic first attempt"})
    return root


def extra_skipped(root):
    suite = root.find("./testsuite")
    case = ET.SubElement(suite, "testcase", {"name": "existing_module::unrelated_ignored_test", "classname": PACKAGE})
    ET.SubElement(case, "skipped")
    return recount(root)


def complete_plus_extra(root):
    ET.SubElement(root.find("./testsuite"), "testcase", {"name": "existing_module::original_worker_test", "classname": PACKAGE})
    return recount(root)


def pinned_skip_counters(root):
    root.attrib.pop("skipped")
    suite = root.find("./testsuite")
    suite.attrib["disabled"] = suite.attrib.pop("skipped")
    return root


def run_parser_case(name, expected, mutate=None, special=None):
    output = FIXTURES / name
    output.mkdir(parents=True, exist_ok=True)
    stderr = "Starting 8 tests across 1 binary (SYNTHETIC CHECKER FIXTURE)\nSummary SYNTHETIC ONLY\n"
    (output / "worker.stderr").write_text(stderr)
    fixture = output / "fresh-input.xml"
    root = report()
    if mutate:
        root = mutate(root)
    data = b"invalid synthetic XML\n" if special == "malformed" else bytes_of(root)
    if special == "original_nextest_fixture":
        data = (OUT.parent / "base/nextest-0.9.103/fixtures/nextest-tests-junit.xml").read_bytes()
    if special != "missing_report":
        fixture.write_bytes(data)
    paths = [fixture]
    if special == "two_reports":
        second = output / "other-input.xml"
        second.write_bytes(data)
        paths.append(second)
    if special == "symlink":
        link = output / "linked-input.xml"
        if link.is_symlink():
            link.unlink()
        link.symlink_to(fixture.name)
        paths = [link]
    runner = load_runner(output)
    runner.junit_paths = lambda: paths
    result = None
    error = None
    try:
        result = runner.retain_tests("worker")
        observed = True
    except (ValueError, ET.ParseError) as failure:
        observed = False
        error = str(failure)
    index_path = output / "worker-test-index.json"
    index = json.loads(index_path.read_text()) if index_path.exists() else None
    row = {"name": name, "kind": "synthetic_parser", "expected_accept": expected,
           "observed_accept": observed, "error": error, "input_xml": data.decode("utf-8"),
           "input_sha256": hashlib.sha256(data).hexdigest(), "input_present": special != "missing_report",
           "synthetic_stderr": stderr, "index": index, "Cargo_executed": False}
    ROWS.append(row)
    unittest.TestCase().assertEqual(observed, expected, msg=name)
    if name == "original_retry_policy_retained":
        unittest.TestCase().assertEqual(len(result["retry_evidence"]), 1)
    if special not in {"missing_report", "two_reports", "symlink"}:
        unittest.TestCase().assertEqual((output / "worker.junit.xml").read_bytes(), data)


def run_execute_case(name, create_fresh, command_exit=0, drift_before=False, drift_after=False):
    """Exercise real freshness/exit/source checks, replacing only external command execution."""
    output = FIXTURES / name
    output.mkdir(parents=True, exist_ok=True)
    fixture = output / "generated.xml"
    fixture.write_bytes(bytes_of(report()))  # A prior fully passing report must not qualify a new run.
    runner = load_runner(output)
    runner.junit_paths = lambda: [fixture]
    runner.resource_state = lambda: {"synthetic_resources": True}
    calls = []
    checks = []

    def verify_source():
        unchanged = not (drift_before if not checks else drift_after)
        checks.append(unchanged)
        return {"unchanged": unchanged, "synthetic_source_check": True}

    def external(command, **kwargs):
        calls.append(command)
        unittest.TestCase().assertFalse(fixture.exists(), "Old JUnit was not removed before command")
        if create_fresh:
            fixture.write_bytes(bytes_of(report()))
        kwargs["stderr"].write(b"Synthetic external command: no Cargo or Rust executed\n")
        return subprocess.CompletedProcess(command, command_exit)

    runner.verify_source = verify_source
    with patch.object(runner.subprocess, "run", side_effect=external), patch("sys.stdout", new=io.StringIO()):
        actual_exit = runner.execute("worker")
    receipt = json.loads((output / "worker.json").read_text())
    expected_success = create_fresh and command_exit == 0 and not drift_before and not drift_after
    unittest.TestCase().assertEqual(actual_exit == 0, expected_success)
    unittest.TestCase().assertEqual(len(calls), 0 if drift_before else 1)
    ROWS.append({"name": name, "kind": "synthetic_command_boundary", "expected_accept": expected_success,
                 "observed_accept": actual_exit == 0, "receipt": receipt, "external_command_was_mocked": True,
                 "Cargo_executed": False, "source_check_results": checks})


def main():
    suite = unittest.TestSuite()

    def add(name, expected, mutate=None, special=None):
        suite.addTest(unittest.FunctionTestCase(lambda: run_parser_case(name, expected, mutate, special), description=name))

    add("complete_eight_exact", True)
    add("pinned_0103_skip_counter_shape", True, pinned_skip_counters)
    add("full_library_may_contain_other_tests", True, complete_plus_extra)
    add("original_retry_policy_retained", True, positive_retry)
    add("unrelated_reported_skip_preserved", True, extra_skipped)
    for index, name in enumerate(NAMES):
        add(f"missing_required_{index:02d}", False, lambda root, name=name: remove_case(root, name))
    add("same_prefix_suffix_is_not_exact", False, lambda root: replace_name(root, "_replacement"))
    add("wrong_module_with_same_function", False,
        lambda root: wrong_attribute(root, ".//testcase", "name", "some_other_module::" + NAMES[0].rsplit("::", 1)[-1]))
    for tag in ("skipped", "failure", "error"):
        add("required_" + tag, False, lambda root, tag=tag: status(root, tag))
    add("duplicate_passing_name", False, duplicate)
    add("duplicate_pass_and_failure", False, lambda root: duplicate(root, True))
    add("wrong_package_suite", False, lambda root: wrong_attribute(root, "./testsuite", "name", "codex-hepta-memory"))
    add("wrong_case_classname", False, lambda root: wrong_attribute(root, ".//testcase", "classname", "codex_hepta_infer_worker_host"))
    add("missing_case_classname", False, lambda root: wrong_attribute(root, ".//testcase", "classname", ""))
    add("root_test_counter_mismatch", False, lambda root: wrong_attribute(root, ".", "tests", "9"))
    add("suite_failure_counter_mismatch", False, lambda root: wrong_attribute(root, "./testsuite", "failures", "1"))
    add("pinned_disabled_counter_mismatch", False,
        lambda root: wrong_attribute(pinned_skip_counters(root), "./testsuite", "disabled", "1"))
    add("contradictory_disabled_skipped_counters", False,
        lambda root: wrong_attribute(root, "./testsuite", "disabled", "1"))
    add("hidden_failure_with_zero_counters", False,
        lambda root: wrong_attribute(wrong_attribute(status(root, "failure"), ".", "failures", "0"), "./testsuite", "failures", "0"))
    add("malformed_report", False, special="malformed")
    add("missing_report", False, special="missing_report")
    add("multiple_report_locations", False, special="two_reports")
    add("symlink_report", False, special="symlink")
    add("original_0103_failing_other_binary_fixture", False, special="original_nextest_fixture")
    for args in (
        ("stale_pass_is_deleted_then_no_fresh_report", False, 0, False, False),
        ("fresh_complete_report_after_mock_command", True, 0, False, False),
        ("fresh_report_cannot_override_command_failure", True, 9, False, False),
        ("source_drift_before_command_refuses_execution", True, 0, True, False),
        ("source_drift_after_command_refuses_qualification", True, 0, False, True),
    ):
        suite.addTest(unittest.FunctionTestCase(lambda args=args: run_execute_case(*args), description=args[0]))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    receipt = {"scope": "Synthetic tests of the exact embedded CI checker and command boundary only",
               "workflow": {"path": str(WORKFLOW), **identity(WORKFLOW)},
               "test_program": {"path": str(Path(__file__)), **identity(Path(__file__))},
               "python_optimization": sys.flags.optimize, "tests_run": result.testsRun,
               "failures": len(result.failures), "errors": len(result.errors), "successful": result.wasSuccessful(),
               "cases": ROWS, "Cargo_executed": False, "workflow_executed": False,
               "actual_worker_test_execution": False}
    (OUT / f"junit-gate-{MODE}.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in ("tests_run", "failures", "errors", "successful", "python_optimization",
                                                  "Cargo_executed", "actual_worker_test_execution")}, indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
