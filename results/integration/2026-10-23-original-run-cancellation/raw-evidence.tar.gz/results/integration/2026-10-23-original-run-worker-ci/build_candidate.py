#!/usr/bin/env python3
"""Prepare one source-only worker workflow from the reviewed original owner gate."""

from pathlib import Path
import textwrap


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "base/.github/workflows/hepta-objective-owner.yml"
DESTINATION = ROOT / "change/.github/workflows/hepta-original-run-worker.yml"


def replace_once(text, before, after):
    if text.count(before) != 1:
        raise ValueError(f"Expected exactly one original fragment: {before[:100]!r}")
    return text.replace(before, after, 1)


def main():
    text = BASE.read_text()
    text = replace_once(text, "name: Original Objective owner package gates", "name: Original Run worker library gate")
    text = replace_once(text, "# Source-head owning-package qualification. This is not a production checkpoint,\n# full-workspace/Bazel/native-guest gate, or a proposal that rewrites its input.", "# Full original worker lib on the exact PR source head, including eight exact\n# RunCancel regression names. This does not qualify crash-durable RunCancel,\n# production signing/authority, the full workspace, Bazel or a native guest.")
    text = text.replace("hepta-objective-owner.yml", "hepta-original-run-worker.yml")
    text = text.replace("original-objective-owner", "original-run-worker")
    text = text.replace("OWNER_CI_EVIDENCE", "WORKER_CI_EVIDENCE")
    text = text.replace("run_owner.py", "run_worker.py")
    text = text.replace("original_owner_ci", "original_run_worker_ci")
    text = text.replace("owning_packages_qualified", "worker_library_qualified")
    text = text.replace("production_checkpoint_implemented", "cross_crash_run_cancel_qualified")
    text = replace_once(text, "  owning-packages:\n    name: Original memory and Agentd libraries (source head)", "  worker-library:\n    name: Original infer worker library (source head)")
    text = replace_once(text, 'PACKAGES = {"memory": "codex-hepta-memory", "agentd": "codex-hepta-agentd"}', 'PACKAGES = {"worker": "codex-hepta-infer-worker-host"}')
    text = replace_once(text, '          PACKAGES = {"worker": "codex-hepta-infer-worker-host"}', '''          # nextest 0.9.103 RustBinaryId::from_parts keeps the Cargo package
          # name for lib targets; JUnit suite.name/classname use that ID.
          # Primary source: nextest-rs/nextest d2e7b879fb79975e8b47a8e3ce569b651e6381c0.
          PACKAGES = {"worker": "codex-hepta-infer-worker-host"}''')
    first = text.index("          REQUIRED_MEMORY = {")
    last = text.index("          def now():", first)
    required = '''REQUIRED_WORKER = {
    "native_app_server::run_monitor::tests::spawn_one_retains_run_two_and_dispatch_cannot_be_reused",
    "native_app_server::run_monitor::tests::every_retained_identity_field_and_revision_is_checked_without_advancing",
    "native_app_server::run_monitor::tests::missing_indeterminate_and_terminal_projection_never_become_a_terminal_witness",
    "native_app_server::run_monitor::tests::external_cancelling_is_one_checked_revision_transition",
    "native_app_server::run_monitor::tests::rejected_cancel_receipts_cannot_guess_or_roll_back_the_run_revision",
    "native_app_server::cancellation_tests::original_intelligence_branch_keeps_spawn_one_and_run_two",
    "native_app_server::cancellation_tests::original_external_cancel_interrupts_once_and_commits_correlated_terminal",
    "native_app_server::cancellation_tests::original_indeterminate_run_stops_exact_turn_without_rewriting_run_terminal",
}

'''
    text = text[:first] + textwrap.indent(required, "          ") + text[last:]
    first = text.index("          def junit_paths():")
    last = text.index("          def execute(label):", first)
    checker = '''def junit_paths():
    paths = {ROOT / "codex-rs/target/nextest/local/junit.xml"}
    if os.environ.get("CARGO_TARGET_DIR"):
        target = Path(os.environ["CARGO_TARGET_DIR"])
        if not target.is_absolute():
            target = ROOT / "codex-rs" / target
        paths.add(target / "nextest/local/junit.xml")
    metadata = OUT / "metadata.json"
    if metadata.is_file():
        target = json.loads(metadata.read_text()).get("cargo_target_directory")
        if target:
            paths.add(Path(target) / "nextest/local/junit.xml")
    return sorted(paths)

def retain_tests(label):
    if label != "worker":
        raise ValueError("Only the original worker library report is accepted")
    candidates = junit_paths()
    if any(path.is_symlink() for path in candidates):
        raise ValueError("Generated JUnit must not be a symlink")
    reports = [path for path in candidates if path.is_file()]
    if len(reports) != 1:
        raise ValueError(f"Expected one fresh original JUnit report, got {reports}")
    data = reports[0].read_bytes()
    (OUT / (label + ".junit.xml")).write_bytes(data)
    root = ET.fromstring(data)
    suites = root.findall("./testsuite")
    cases = root.findall(".//testcase")
    errors = []
    if root.tag != "testsuites" or len(suites) != 1:
        errors.append("Expected the original single-library nextest testsuites shape")
    if len(suites) == 1 and (
            suites[0].attrib.get("name") != PACKAGES[label]
            or suites[0].findall("./testcase") != cases):
        errors.append("JUnit suite identity or case placement differs from the original worker library")
    names = [case.attrib.get("name", "") for case in cases]
    if not cases or len(names) != len(set(names)) or any(not name for name in names):
        errors.append("JUnit is empty or has empty/duplicate full test names")
    if any(case.attrib.get("classname") != PACKAGES[label] for case in cases):
        errors.append("JUnit case belongs to a different package")
    final_tags = ("failure", "error", "skipped")
    counts = {"tests": len(cases)} | {
        {"failure": "failures", "error": "errors", "skipped": "skipped"}[tag]:
        sum(case.find(tag) is not None for case in cases) for tag in final_tags}
    if any(sum(len(case.findall(tag)) for tag in final_tags) > 1 for case in cases):
        errors.append("A case has ambiguous final statuses")
    for element in [root, *suites]:
        for key, expected in counts.items():
            # The pinned nextest 0.9.103 fixture uses suite.disabled=0 and
            # omits a root skip counter. Newer nextest uses skipped=0.
            # Missing zero-only skip metadata is allowed; present counters
            # must still agree, and required skipped cases always refuse.
            keys = (key,) if key != "skipped" else tuple(
                name for name in ("skipped", "disabled") if name in element.attrib)
            if key == "skipped" and not keys:
                if expected:
                    errors.append("A nonzero skipped-case count has no JUnit counter")
                continue
            for counter in keys:
                value = element.attrib.get(counter, "")
                if not re.fullmatch(r"[0-9]+", value) or int(value) != expected:
                    errors.append(f"JUnit {element.tag} {counter} counter disagrees with actual cases")
    passed = {case.attrib["name"] for case in cases
              if case.attrib.get("name") and not any(case.find(tag) is not None for tag in final_tags)}
    missing = sorted(REQUIRED_WORKER - passed)
    if missing:
        errors.append("An exact required worker case is absent, skipped or failing")
    if counts["failures"] or counts["errors"]:
        errors.append("The original worker library contains a final failure/error")
    retry_tags = {"rerunFailure", "rerunError", "flakyFailure", "flakyError"}
    retries = [{"name": case.attrib.get("name"), "elements": [
        {"tag": child.tag, "attributes": child.attrib}
        for child in case if child.tag in retry_tags]}
        for case in cases if any(child.tag in retry_tags for child in case)]
    result = {
        "source_path": str(reports[0]), "sha256": digest(data), "bytes": len(data),
        "junit_attributes": root.attrib, "suite_attributes": [suite.attrib for suite in suites],
        "reported_counts": counts, "reported_test_names": names,
        "executed_test_names": sorted(passed), "required_exact_test_names": sorted(REQUIRED_WORKER),
        "required_test_names_missing": missing, "validation_errors": errors,
        "retry_evidence": retries, "retry_policy": "Original local profile inherits default retries=1; no override",
        "nextest_summary_lines": [line for line in (OUT / (label + ".stderr")).read_text(errors="replace").splitlines()
                                  if "Summary" in line or "Starting" in line],
        "required_owning_tests_present_and_passed": not errors,
        "selection": "Complete original package --lib, no test-name or filterset restriction",
        "ignored_or_skipped_policy": "Original default selection preserved; every required case must execute and pass",
    }
    save(label + "-test-index.json", result)
    if errors:
        raise ValueError("Original worker JUnit failed validation: " + "; ".join(errors))
    return result

'''
    text = text[:first] + textwrap.indent(checker, "          ") + text[last:]
    text = replace_once(text, "                          if path.exists():", "                          if path.exists() or path.is_symlink():")
    text = replace_once(text, "                              # Previous package evidence was copied before clearing its generated report.", "                              # A previous report cannot qualify this command; the fresh bytes are retained below.")
    text = replace_once(text, '                      receipt["effective_workspace_members"] = len(members)', '                      if Path(metadata["workspace_root"]).resolve() != ROOT / "codex-rs":\n                          raise ValueError("Cargo metadata did not resolve the original workspace root")\n                      receipt["cargo_target_directory"] = metadata["target_directory"]\n                      receipt["effective_workspace_members"] = len(members)')
    text = replace_once(text, '              save("command-plan.json", {name: {"argv": argv, "status": "not_started"} for name, argv in COMMANDS.items()})', '''              nextest_path = ROOT / "codex-rs/.config/nextest.toml"
              nextest = tomllib.loads(nextest_path.read_text())
              profiles = nextest["profile"]
              if (profiles["local"].get("inherits") != "default"
                      or profiles["default"].get("retries") != 1
                      or profiles["default"]["junit"]["path"] != "junit.xml"):
                  raise ValueError("Original nextest profile/retries/JUnit path changed; review this gate")
              (OUT / "original-nextest.toml").write_bytes(nextest_path.read_bytes())
              save("nextest-profile.json", {"path": "codex-rs/.config/nextest.toml",
                  "sha256": digest(nextest_path.read_bytes()), "profile": "local",
                  "configuration": nextest, "overrides_added": False})
              save("command-plan.json", {name: {"argv": argv, "status": "not_started"} for name, argv in COMMANDS.items()})''')
    first = text.index("      - name: Run the entire original memory library test suite")
    last = text.index("      - name: Recheck original formatting", first)
    text = text[:first] + '''      - name: Run the full original worker library including all eight exact RunCancel regression cases
        id: worker
        if: always() && steps.metadata.outcome == 'success' && steps.v8.outcome == 'success'
        shell: bash
        run: python3 "$WORKER_CI_EVIDENCE/run_worker.py" worker

      - name: Run original scoped worker Clippy and reject any source or lock rewrite
        id: fix_worker
        if: always() && steps.metadata.outcome == 'success' && steps.v8.outcome == 'success'
        shell: bash
        run: python3 "$WORKER_CI_EVIDENCE/run_worker.py" fix-worker

''' + text[last:]
    text = replace_once(text, '                                "format", "memory", "agentd", "fix_memory", "fix_agentd", "format_final")', '                                "format", "worker", "fix_worker", "format_final")')
    text = replace_once(text, '                    "cross_crash_run_cancel_qualified": False}', '                    "cross_crash_run_cancel_qualified": False, "production_authority_qualified": False}')
    text = replace_once(text, '          if not records[0]["stdout"].startswith("rustc 1.95.0 "):\n              raise SystemExit("Wrong effective compiler")', '          if not records[0]["stdout"].startswith("rustc 1.95.0 "):\n              raise SystemExit("Wrong effective compiler")\n          if records[3]["stdout"].split()[:2] != ["cargo-nextest", "0.9.103"]:\n              raise SystemExit("Wrong effective nextest version for the reviewed JUnit profile")')
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    DESTINATION.write_text(text)
    print(DESTINATION)


if __name__ == "__main__":
    main()
