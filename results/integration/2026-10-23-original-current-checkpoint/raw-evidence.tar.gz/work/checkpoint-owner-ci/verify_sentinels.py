#!/usr/bin/env python3
"""Exercise the actual embedded JUnit validator with explicitly synthetic inputs."""
from pathlib import Path
import ast
import copy
import datetime
import hashlib
import json
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "validation"
OLD = ROOT.parent / "owner-ci/validation/embedded-python/source-02.py"
NEW = OUT / "embedded-python/source-02.py"


def load_validator(path):
    tree = ast.parse(path.read_text())
    selected = []
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id.startswith("REQUIRED_")
            for target in node.targets
        ):
            selected.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name == "retain_tests":
            selected.append(node)
    assert len([node for node in selected if isinstance(node, ast.FunctionDef)]) == 1
    namespace = {"ET": ET}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), "exec"), namespace)
    return namespace


def all_names(namespace, label):
    if label == "memory":
        return sorted(namespace["REQUIRED_MEMORY"])
    names = set(namespace["REQUIRED_BRIDGE"]) | namespace["REQUIRED_BOOTSTRAP"]
    for prefix, minimum in namespace["REQUIRED_AGENTD_GROUPS"].items():
        index = 0
        while sum(name.startswith(prefix) for name in names) < minimum:
            names.add(prefix + f"synthetic_count_fixture_{index}")
            index += 1
    return sorted(names)


def run(namespace, folder, label, names):
    folder.mkdir(parents=True)
    xml = ET.Element("testsuites", tests=str(len(names)), failures="0", errors="0")
    suite = ET.SubElement(xml, "testsuite", name="synthetic-validator-input")
    for name in names:
        ET.SubElement(suite, "testcase", name=name)
    path = folder / "synthetic.junit.xml"
    path.write_bytes(ET.tostring(xml, encoding="utf-8", xml_declaration=True))
    (folder / (label + ".stderr")).write_text(
        "Synthetic JUnit validation fixture only; no Rust tests were executed.\n"
    )
    namespace.update(
        OUT=folder,
        junit_paths=lambda: [path],
        digest=lambda data: hashlib.sha256(data).hexdigest(),
        save=lambda name, value: (folder / name).write_text(json.dumps(value, indent=2) + "\n"),
    )
    try:
        result = namespace["retain_tests"](label)
        return {"accepted": True, "required_missing": result["required_test_names_missing"]}
    except ValueError as error:
        result = json.loads((folder / (label + "-test-index.json")).read_text())
        return {"accepted": False, "error": str(error),
                "required_missing": result["required_test_names_missing"]}


def main():
    old = load_validator(OLD)
    new = load_validator(NEW)
    added = json.loads((ROOT.parent / "checkpoint-current/validation/ci-sentinels.json").read_text())["required_added_tests"]
    assert len(added) == 8
    cases = []
    for label in ("memory", "agentd"):
        names = all_names(new, label)
        for version, namespace in (("old", old), ("new", new)):
            result = run(namespace, OUT / "junit-fixtures" / (label + "-complete-" + version), label, names)
            assert result["accepted"] is True
            cases.append({"case": label + "-complete", "validator": version, **result})
    for index, missing in enumerate(added):
        label = "memory" if missing.startswith("production_writer::") else "agentd"
        names = all_names(new, label)
        assert names.count(missing) == 1
        # Keep both total count and the original test-group count unchanged.
        replacement = missing.rsplit("::", 1)[0] + "::synthetic_replacement_same_group"
        assert replacement not in names
        names[names.index(missing)] = replacement
        baseline = run(old, OUT / "junit-fixtures" / f"missing-{index}-old", label, names)
        candidate = run(new, OUT / "junit-fixtures" / f"missing-{index}-new", label, names)
        assert baseline["accepted"] is True
        assert candidate["accepted"] is False
        assert candidate["required_missing"] == [missing]
        cases.append({"case": "missing-exact-new-test-with-counts-preserved", "missing": missing,
                      "old_validator": baseline, "new_validator": candidate})
    receipt = {
        "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "scope": "Actual old/new embedded retain_tests functions executed only on synthetic JUnit inputs; no Rust package, Actions workflow or product test execution.",
        "old_embedded_sha256": hashlib.sha256(OLD.read_bytes()).hexdigest(),
        "new_embedded_sha256": hashlib.sha256(NEW.read_bytes()).hexdigest(),
        "original_required_memory_names_preserved": old["REQUIRED_MEMORY"] <= new["REQUIRED_MEMORY"],
        "original_required_bridge_names_preserved": old["REQUIRED_BRIDGE"] == new["REQUIRED_BRIDGE"],
        "new_required_test_count": 8,
        "complete_positive_invocations": 4,
        "omission_counterexamples": 8,
        "each_omission_old_accepts_new_rejects": True,
        "cases": cases,
        "passed": True,
    }
    assert receipt["original_required_memory_names_preserved"]
    assert receipt["original_required_bridge_names_preserved"]
    (OUT / "sentinel-validation.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in
                      ("scope", "new_required_test_count", "complete_positive_invocations", "omission_counterexamples", "passed")}, indent=2))


if __name__ == "__main__":
    main()
