import json
import os
from pathlib import Path
import subprocess
evidence = Path(os.environ["OWNER_CI_EVIDENCE"])
records = []
for command in (["rustc", "-Vv"], ["cargo", "-Vv"], ["just", "--version"],
                ["cargo", "nextest", "--version"], ["pkg-config", "--modversion", "openssl"],
                ["pkg-config", "--variable=libdir", "openssl"]):
    result = subprocess.run(command, text=True, capture_output=True, check=False)
    records.append({"argv": command, "exit_code": result.returncode,
                    "stdout": result.stdout, "stderr": result.stderr})
(evidence / "tool-versions.json").write_text(json.dumps(records, indent=2) + "\n")
if any(record["exit_code"] for record in records):
    raise SystemExit(1)
if not records[0]["stdout"].startswith("rustc 1.95.0 "):
    raise SystemExit("Wrong effective compiler")
if records[-1]["stdout"].strip() != os.environ["OPENSSL_LIB_DIR"]:
    raise SystemExit("Unexpected original system OpenSSL library directory")
