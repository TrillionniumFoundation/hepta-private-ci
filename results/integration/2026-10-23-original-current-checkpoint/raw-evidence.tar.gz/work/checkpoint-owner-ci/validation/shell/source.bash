set -euo pipefail
cat > "$OWNER_CI_EVIDENCE/run_owner.py" <<'PY'
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tomllib
import xml.etree.ElementTree as ET

ROOT = Path(os.environ["GITHUB_WORKSPACE"]).resolve()
OUT = Path(os.environ["OWNER_CI_EVIDENCE"])
SOURCE = os.environ["SOURCE_SHA"]
BASE = os.environ["BASE_SHA"]
PACKAGES = {"memory": "codex-hepta-memory", "agentd": "codex-hepta-agentd"}
COMMANDS = {
    "native-update": ["sudo", "apt-get", "update"],
    "native-install": ["sudo", "apt-get", "install", "-y", "--no-install-recommends",
        "build-essential", "bubblewrap", "libcap-dev", "pkg-config", "libssl-dev", "cmake", "clang"],
    "v8": ["python3", "scripts/hepta_ci_v8.py"],
    "metadata": ["cargo", "metadata", "--locked", "--no-deps", "--format-version", "1"],
    "format": ["just", "fmt", "--check", "--base", BASE],
}
for label, package in PACKAGES.items():
    COMMANDS[label] = ["just", "test", "--locked", "--cargo-profile", "dev-small",
        "--build-jobs", "1", "--test-threads", "1", "-p", package, "--lib", "--no-tests", "fail"]
    COMMANDS["fix-" + label] = ["just", "fix", "-p", package, "--locked", "--profile", "dev-small", "--lib"]
COMMANDS["format-final"] = COMMANDS["format"]
REQUIRED_MEMORY = {
    "checked_concurrent_history_keeps_one_publication_and_idempotent_acknowledgement",
    "checked_negative_control_separate_prechecks_allow_conflicting_generic_appends",
    "snapshot_acknowledged_does_not_promote_a_committed_observation_without_checkpoint_ack",
    "snapshot_acknowledged_holds_the_original_write_lock_through_the_current_cut_ack",
    "snapshot_acknowledged_recovers_local_cancellation_without_a_new_cancellation_right",
    "checkpoint_current_cancelled_future_releases_lock_without_creating_sender_state",
    "checkpoint_current_holds_the_original_write_lock_through_acknowledgement",
    "checkpoint_current_invalid_deadline_and_terminal_leases_never_call_the_publisher",
    "checkpoint_current_refusal_timeout_mismatch_and_live_revocation_preserve_the_cut",
    "checkpoint_current_without_a_request_uses_the_original_fence_and_changes_no_rows",
}
REQUIRED_BRIDGE = {
    "uninstalled_original_objective_sender_refuses_without_a_new_owner",
    "installed_original_objective_sender_reuses_same_writer_and_live_verifier",
    "retained_signed_body_hash_matches_original_agentd_wire_projection",
}
REQUIRED_BOOTSTRAP = {
    "production_composition::tests::checkpoint_failures_and_post_ack_live_refusals_never_install_recovered_hosts",
    "production_composition::tests::invalid_checkpoint_deadline_refuses_before_consulting_external_inputs",
    "production_composition::notes_tests::attached_notes_ack_then_checkpoint_refusal_publishes_no_host_and_closes_target",
}
REQUIRED_AGENTD_GROUPS = {
    "production_composition::tests::": 9,
    "production_composition::notes_tests::": 6,
    "production_composition::objective_sender_tests::": 3,
    "production_authority::tests::": 5,
    "final_use_issuer::tests::": 7,
}
REQUIRED_MEMORY = {"production_writer::objective_sender::tests::" + name for name in REQUIRED_MEMORY}
REQUIRED_BRIDGE = {"production_composition::objective_sender_tests::" + name for name in REQUIRED_BRIDGE}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")

def git(*args):
    return subprocess.check_output(["git", "--no-replace-objects", *args], cwd=ROOT)

def resource_state():
    available = next(int(line.split()[1]) * 1024 for line in Path("/proc/meminfo").read_text().splitlines()
                     if line.startswith("MemAvailable:"))
    return {"at": now(), "memory_available_bytes": available,
            "disk_available_bytes": shutil.disk_usage(ROOT).free,
            "build_jobs": 1, "test_threads": 1, "cargo_profile": "dev-small"}

def snapshot():
    head = git("rev-parse", "HEAD").decode().strip()
    tree = git("rev-parse", "HEAD^{tree}").decode().strip()
    rows = []
    errors = []
    for item in git("ls-tree", "-rz", "--full-tree", "HEAD").split(b"\0"):
        if not item:
            continue
        meta, raw_path = item.split(b"\t", 1)
        mode, kind, expected = meta.decode().split()
        name = os.fsdecode(raw_path)
        path = ROOT / name
        try:
            if kind != "blob":
                raise ValueError("unsupported non-blob checkout input")
            actual_mode = path.lstat().st_mode
            if mode == "120000":
                if not stat.S_ISLNK(actual_mode):
                    raise ValueError("symlink mode changed")
                data = os.fsencode(os.readlink(path))
            else:
                if not stat.S_ISREG(actual_mode) or bool(actual_mode & 0o111) != (mode == "100755"):
                    raise ValueError("regular file mode changed")
                data = path.read_bytes()
            actual = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
            if actual != expected:
                errors.append({"path": name, "error": "actual bytes differ from HEAD", "actual_git_blob": actual})
            rows.append({"path": name, "mode": mode, "git_blob": actual,
                         "sha256": digest(data), "bytes": len(data)})
        except (OSError, ValueError) as error:
            errors.append({"path": name, "error": str(error)})
    status = git("status", "--porcelain=v1", "--untracked-files=all").decode()
    locks = [row for row in rows if Path(row["path"]).name in
             {"Cargo.lock", "MODULE.bazel.lock", "uv.lock", "pnpm-lock.yaml", "package-lock.json"}]
    return {"head": head, "tree": tree, "tracked_blobs": len(rows), "files": rows,
            "files_sha256": digest(json.dumps(rows, sort_keys=True).encode()),
            "locks": locks, "errors": errors, "git_status": status}

def verify_source():
    value = snapshot()
    original = json.loads((OUT / "source.json").read_text())
    ok = (value["head"] == SOURCE and value["tree"] == original["tree"]
          and value["files_sha256"] == original["files_sha256"]
          and not value["errors"] and not value["git_status"])
    return {key: value[key] for key in ("head", "tree", "tracked_blobs", "files_sha256", "locks", "errors", "git_status")} | {"unchanged": ok}

def junit_paths():
    paths = {ROOT / "codex-rs/target/nextest/local/junit.xml"}
    if os.environ.get("CARGO_TARGET_DIR"):
        paths.add(Path(os.environ["CARGO_TARGET_DIR"]) / "nextest/local/junit.xml")
    return sorted(paths)

def retain_tests(label):
    reports = [path for path in junit_paths() if path.is_file()]
    if len(reports) != 1:
        raise ValueError(f"Expected one fresh original JUnit report, got {reports}")
    data = reports[0].read_bytes()
    (OUT / (label + ".junit.xml")).write_bytes(data)
    root = ET.fromstring(data)
    cases = root.findall(".//testcase")
    passed = {case.attrib["name"] for case in cases
              if not any(case.findall(tag) for tag in ("failure", "error", "skipped"))}
    required = REQUIRED_MEMORY if label == "memory" else REQUIRED_BRIDGE | REQUIRED_BOOTSTRAP
    groups = {prefix: sum(name.startswith(prefix) for name in passed)
              for prefix in REQUIRED_AGENTD_GROUPS} if label == "agentd" else {}
    valid = (bool(cases) and int(root.attrib["tests"]) == len(cases)
             and int(root.attrib["failures"]) == 0 and int(root.attrib["errors"]) == 0
             and required <= passed and all(groups[prefix] >= count for prefix, count in
                                          (REQUIRED_AGENTD_GROUPS.items() if label == "agentd" else [])))
    result = {"source_path": str(reports[0]), "sha256": digest(data), "bytes": len(data),
              "junit_attributes": root.attrib, "executed_test_names": sorted(passed),
              "required_test_names_missing": sorted(required - passed), "required_groups": groups,
              "nextest_summary_lines": [line for line in (OUT / (label + ".stderr")).read_text(errors="replace").splitlines()
                                        if "Summary" in line or "Starting" in line],
              "required_owning_tests_present_and_passed": valid,
              "selection": "Complete original package --lib, no test-name or filterset restriction"}
    save(label + "-test-index.json", result)
    if not valid:
        raise ValueError("Original owning-package JUnit is empty, failing or missing required owner tests")
    return result

def execute(label):
    receipt = {"name": label, "argv": COMMANDS[label], "source_sha": SOURCE,
               "started_at": now(), "status": "running", "exit_code": None,
               "resources_before": resource_state()}
    save(label + ".json", receipt)
    stdout = OUT / (label + ".stdout")
    stderr = OUT / (label + ".stderr")
    stdout.touch()
    stderr.touch()
    try:
        receipt["source_before"] = verify_source()
        if not receipt["source_before"]["unchanged"]:
            raise ValueError("Source or lock drift before original command")
        if label in PACKAGES:
            for path in junit_paths():
                if path.exists():
                    if path.is_symlink() or not path.is_file():
                        raise ValueError("Invalid prior generated JUnit path")
                    # Previous package evidence was copied before clearing its generated report.
                    path.unlink()
        cwd = ROOT / "codex-rs" if label == "metadata" else ROOT
        receipt["cwd"] = str(cwd)
        print("Running original gate: " + label, flush=True)
        with stdout.open("wb") as out, stderr.open("wb") as err:
            completed = subprocess.run(COMMANDS[label], cwd=cwd, stdout=out, stderr=err, check=False)
        receipt["exit_code"] = completed.returncode
        if label in PACKAGES and any(path.is_file() for path in junit_paths()):
            receipt["tests"] = retain_tests(label)
        if completed.returncode != 0:
            raise ValueError("Original command failed")
        if label in PACKAGES and "tests" not in receipt:
            raise ValueError("Successful test command did not produce fresh JUnit")
        if label == "v8":
            names = {"RUSTY_V8_ARCHIVE", "RUSTY_V8_SRC_BINDING_PATH"}
            exported = {key: value for line in Path(os.environ["GITHUB_ENV"]).read_text().splitlines()
                        if "=" in line for key, value in [line.split("=", 1)] if key in names}
            if set(exported) != names or not all(exported.values()):
                raise ValueError("Original verified V8 resolver did not export its archive and binding")
            receipt["verified_v8_artifacts"] = []
            for name, value in sorted(exported.items()):
                path = Path(value)
                with path.open("rb") as artifact:
                    artifact_sha256 = hashlib.file_digest(artifact, "sha256").hexdigest()
                receipt["verified_v8_artifacts"].append({"environment": name, "path": str(path),
                    "bytes": path.stat().st_size, "sha256": artifact_sha256})
        if label == "metadata":
            metadata = json.loads(stdout.read_text())
            members = set(metadata["workspace_members"])
            packages = {row["name"] for row in metadata["packages"] if row["id"] in members}
            if len(members) != 193 or not set(PACKAGES.values()) <= packages:
                raise ValueError("Original 193-member workspace or owning packages changed; review this profile")
            receipt["effective_workspace_members"] = len(members)
            receipt["packages"] = sorted(packages)
        receipt["status"] = "passed"
    except (OSError, ValueError, KeyError, TypeError, ET.ParseError, subprocess.SubprocessError) as error:
        receipt["status"] = "failed"
        receipt["error"] = str(error)
    finally:
        try:
            receipt["source_after"] = verify_source()
            if not receipt["source_after"]["unchanged"]:
                receipt["status"] = "failed"
        except (OSError, ValueError, subprocess.SubprocessError) as error:
            receipt["status"] = "failed"
            receipt["source_verification_error"] = str(error)
        receipt.update(finished_at=now(), resources_after=resource_state())
        for kind, path in (("stdout", stdout), ("stderr", stderr)):
            receipt[kind] = {"file": path.name, "bytes": path.stat().st_size, "sha256": digest(path.read_bytes())}
        save(label + ".json", receipt)
    print(json.dumps({key: receipt[key] for key in ("name", "status", "exit_code")}), flush=True)
    return 0 if receipt["status"] == "passed" else 1

def initialize():
    if not re.fullmatch("[0-9a-f]{40}", SOURCE) or not re.fullmatch("[0-9a-f]{40}", BASE):
        raise ValueError("Expected immutable PR head and base IDs")
    git("cat-file", "-e", BASE + "^{commit}")
    value = snapshot()
    save("source.json", value)
    if value["head"] != SOURCE or value["errors"] or value["git_status"]:
        raise ValueError("PR head checkout/readback is not exact and clean")
    toolchain = tomllib.loads((ROOT / "codex-rs/rust-toolchain.toml").read_text())["toolchain"]
    if toolchain["channel"] != "1.95.0" or not {"clippy", "rustfmt", "rust-src"} <= set(toolchain["components"]):
        raise ValueError("Repository compiler profile changed; review the owner gate")
    for name, package in PACKAGES.items():
        manifest = tomllib.loads((ROOT / "codex-rs" / package.removeprefix("codex-") / "Cargo.toml").read_text())
        if manifest["package"]["name"] != package:
            raise ValueError("Original owning-package identity changed")
    save("command-plan.json", {name: {"argv": argv, "status": "not_started"} for name, argv in COMMANDS.items()})
    save("compiler-profile.json", toolchain)
    save("initial-resources.json", resource_state())
    return 0

if __name__ == "__main__":
    try:
        code = initialize() if sys.argv[1] == "initialize" else execute(sys.argv[1])
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        save("runner-error.json", {"at": now(), "phase": sys.argv[1:], "error": str(error), "qualified": False})
        code = 1
    raise SystemExit(code)
PY
python3 "$OWNER_CI_EVIDENCE/run_owner.py" initialize
