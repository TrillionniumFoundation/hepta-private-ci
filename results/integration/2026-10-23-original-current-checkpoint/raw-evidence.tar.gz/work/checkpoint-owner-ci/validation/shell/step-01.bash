set -euo pipefail
export OWNER_CI_EVIDENCE="$RUNNER_TEMP/hepta-original-objective-owner"
mkdir -p "$OWNER_CI_EVIDENCE"
printf 'OWNER_CI_EVIDENCE=%s\n' "$OWNER_CI_EVIDENCE" >> "$GITHUB_ENV"
python3 - <<'PY'
import json
import os
from pathlib import Path
receipt = {key: os.environ.get(key) for key in (
    "SOURCE_SHA", "BASE_SHA", "GITHUB_RUN_ID", "GITHUB_RUN_ATTEMPT",
    "GITHUB_REPOSITORY", "RUNNER_OS", "RUNNER_ARCH")}
receipt.update(owning_packages_qualified=False, full_workspace_qualified=False,
               production_checkpoint_implemented=False)
Path(os.environ["OWNER_CI_EVIDENCE"], "attempt.json").write_text(
    json.dumps(receipt, indent=2) + "\n")
PY
