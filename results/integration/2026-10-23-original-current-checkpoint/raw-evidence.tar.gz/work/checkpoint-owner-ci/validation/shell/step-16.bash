python3 - <<'PY'
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
evidence = Path(os.environ["RUNNER_TEMP"], "hepta-original-objective-owner")
evidence.mkdir(parents=True, exist_ok=True)
result = {"source_sha": os.environ["SOURCE_SHA"], "steps": json.loads(os.environ["SETUP_OUTCOMES"]),
          "owning_packages_qualified": False, "full_workspace_qualified": False,
          "bazel_qualified": False, "native_guest_qualified": False,
          "production_checkpoint_implemented": False}
try:
    spec = importlib.util.spec_from_file_location("original_owner_ci", evidence / "run_owner.py")
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    result["source_final"] = runner.verify_source()
    result["commands"] = {}
    for label, argv in runner.COMMANDS.items():
        path = evidence / (label + ".json")
        result["commands"][label] = json.loads(path.read_text()) if path.exists() else {
            "argv": argv, "status": "not_started", "exit_code": None}
    required_steps = ("checkout", "source", "tools", "rust", "nextest", "native", "v8", "metadata",
                      "format", "memory", "agentd", "fix_memory", "fix_agentd", "format_final")
    result["owning_packages_qualified"] = (result["source_final"]["unchanged"]
        and all(result["steps"].get(name, {}).get("outcome") == "success" for name in required_steps)
        and all(row["status"] == "passed" and row["exit_code"] == 0 for row in result["commands"].values()))
    with (evidence / "source-drift.patch").open("wb") as output:
        subprocess.run(["git", "diff", "--binary", "--no-renames", "HEAD"], stdout=output, check=True)
except (OSError, ValueError, KeyError, TypeError, ImportError, subprocess.SubprocessError) as error:
    result["finalization_error"] = str(error)
    result["owning_packages_qualified"] = False
(evidence / "result.json").write_text(json.dumps(result, indent=2) + "\n")
inventory = []
for path in sorted(evidence.rglob("*")):
    if path.is_file():
        data = path.read_bytes()
        inventory.append({"path": str(path.relative_to(evidence)), "bytes": len(data),
                          "sha256": hashlib.sha256(data).hexdigest()})
(evidence / "artifact-inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
raise SystemExit(0 if result["owning_packages_qualified"] else 1)
PY
