from pathlib import Path
import base64
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path('/workspace/scratch/3d6a75235bcb')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def regular_files(directory, excluded=()):
    result = {}
    for path in sorted((ROOT / directory).rglob('*')):
        rel = path.relative_to(ROOT / directory)
        if '__pycache__' in rel.parts or any(x in rel.parts for x in excluded):
            continue
        if path.is_symlink():
            raise ValueError('Unexpected evidence symlink: ' + str(path))
        if path.is_file():
            result[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    return result


def make_bundle(directory, prefix, members, source_commit, source_tree, readme, extra_files):
    destination = ROOT / directory
    destination.mkdir(parents=True, exist_ok=True)
    inventory = []
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(members.items()):
            path = Path(name)
            if path.is_absolute() or '..' in path.parts:
                raise ValueError('Unsafe archive name: ' + name)
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o644
            member.uid = member.gid = member.mtime = 0
            member.uname = member.gname = ''
            archive.addfile(member, io.BytesIO(data))
            inventory.append({'path': name, 'bytes': len(data), 'sha256': sha(data), 'git_blob': blob(data)})
    data = gzip.compress(stream.getvalue(), mtime=0)
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        recovered = {member.name: archive.extractfile(member).read() for member in archive.getmembers()}
    if recovered != members:
        raise ValueError('Full archive readback mismatch')
    manifest = {
        'source_commit': source_commit,
        'source_tree': source_tree,
        'archive': {'file': 'raw-evidence.tar.gz', 'bytes': len(data), 'sha256': sha(data),
                    'members': len(inventory), 'uncompressed_member_bytes': sum(row['bytes'] for row in inventory),
                    'full_readback_matches': True},
        'members': inventory,
        'scope': 'Complete named frozen inputs and raw evidence; not new execution. No dependency cache or binaries included.',
    }
    outputs = {
        'README.md': readme.encode(),
        'manifest.json': (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode(),
        'raw-evidence.tar.gz': data,
        **extra_files,
    }
    entries = []
    for name, value in outputs.items():
        path = destination / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value)
        is_archive = name.endswith('.tar.gz')
        entries.append({'path': prefix + '/' + name, 'mode': '100644', 'type': 'blob',
                        'encoding': 'base64' if is_archive else 'utf-8',
                        'content': base64.b64encode(value).decode() if is_archive else value.decode(),
                        'candidate_git_blob': blob(value), 'candidate_sha256': sha(value),
                        'bytes': len(value), 'preimage_git_blob': None})
    entries_path = destination.parent / 'evidence-entries.json'
    entries_path.write_text(json.dumps(entries, ensure_ascii=False))
    summary = {'directory': directory, 'source_commit': source_commit,
               'archive': manifest['archive'], 'outer_files': len(entries),
               'entries_file': str(entries_path), 'entries_characters': len(entries_path.read_text()),
               'entries_sha256': sha(entries_path.read_bytes())}
    (destination.parent / 'bundle-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    return summary


if __name__ == '__main__':
    members = {}
    frozen_sources = [
        'work/original-run-cancel/publication/root-evidence-entries.json',
        'work/original-run-cancel-ci/publication/root-evidence-entries.json',
    ]
    for name in frozen_sources:
        entries = json.loads((ROOT / name).read_text())
        for entry in entries:
            data = base64.b64decode(entry['content']) if entry.get('encoding') == 'base64' else entry['content'].encode()
            if sha(data) != entry['candidate_sha256'] or blob(data) != entry['candidate_git_blob'] or len(data) != entry['bytes']:
                raise ValueError('Frozen evidence identity changed: ' + entry['path'])
            if entry['path'] in members:
                raise ValueError('Duplicate evidence member: ' + entry['path'])
            members[entry['path']] = data
        members[name] = (ROOT / name).read_bytes()
    members.update(regular_files('work/original-run-cancel-ci-review'))
    for name in ['work/original-run-cancel-publish/source-entries.json',
                 'work/original-run-cancel-publish/root-source-readback.json',
                 'work/build_closure_evidence.py']:
        members[name] = (ROOT / name).read_bytes()
    source = 'df9f564dc086e722ee1f6125a2f7a5b6d1801c6b'
    tree = '9363a0af547df790c3883e615c7a90c62cebdad3'
    readme = '''# Original Run cancellation candidate: source and static evidence

Source commit: `df9f564dc086e722ee1f6125a2f7a5b6d1801c6b`.
Source tree: `9363a0af547df790c3883e615c7a90c62cebdad3`.
Parent: checkpoint source `9e1521d2ac6d171a0c307e2ae5a3b7a1ee6cacd0`.

The original worker incorrectly compared a Running generation with its daemon
spawn generation. This candidate retains the original Run identity, validates
exact revisions, consumes the original Cancelling transition once, and uses the
existing AppServer interrupt and correlated terminal event. Missing, mixed or
indeterminate state remains quarantined; it does not create a new RunCancel
authority, scheduler, ledger or guessed terminal observation.

## Actual validation boundary

- Four Rust source files: official Rust 1.95 rustfmt and independent source review.
- Eight Rust regression tests are authored and **not yet executed**.
- The new normal-PR workflow runs the complete original worker library through
  `just test --locked --cargo-profile dev-small --build-jobs 1 --test-threads 1
  -p codex-hepta-infer-worker-host --lib --no-tests fail` and requires all eight
  exact test names in fresh JUnit. It preserves the original workspace and locks.
- Its 38 synthetic parser/command-boundary checks pass in ordinary and optimized
  Python; ten Bash blocks and four embedded Python programs pass syntax checks.
  These are checker tests, not worker execution. The gate's actual nextest pin is
  0.9.103; the local memory run's 0.9.149 is only a separately labeled format input.
- Full source publication readback covers all 9,255 leaves, including unchanged
  file modes/blobs. No GitHub CI or native guest success is claimed here.

## Complete retained records

`raw-evidence.tar.gz` contains all 24 frozen Rust-candidate evidence entries and
all 34 final CI evidence entries, their full frozen entry records, the independent
CI review, the exact five-source publication entries, and root readback. Both
earlier and later independent Python result records are retained with their round
identities. `manifest.json` lists every member byte count, SHA-256 and Git blob.
The archive was fully decoded and compared to every original member before
publication. No dependency cache or compilation binary is bundled.

Extract into an empty review directory to inspect the original report paths:

```sh
python3 -m tarfile -e raw-evidence.tar.gz extracted
```

Production signing/permission inputs, Desktop post-send cancellation,
cross-crash durable RunCancel, complete Agentd/worker execution and native guest
lifecycle remain separate gates. The 500 ms observation tick is not a hard
physical-cancellation deadline.
'''
    print(json.dumps(make_bundle(
        'work/original-run-cancel-publish/evidence',
        'results/integration/2026-10-23-original-run-cancellation', members, source, tree, readme,
        {'publication/root-source-readback.json': (ROOT / 'work/original-run-cancel-publish/root-source-readback.json').read_bytes(),
         'reviews/worker-ci.md': (ROOT / 'work/original-run-cancel-ci-review/REVIEW.md').read_bytes()}), indent=2))
