# 后续原 owner mutation / terminal-cut 作用域映射

状态：基于 Hepta `db91f9ec316ba1472e7adf97f8415949de012469` 的只读技术分析。
本文件没有实现下面的候选方案，也没有执行 Rust、guest 或生产 backend。
当前获批实施片是 `work/checkpoint-current/change/` 的 active writer checkpoint 与 strict bootstrap；本文件不扩大该片范围。

## 范围定义

这里枚举原 `ProductionDurableWriter` 的生产入口、它的 Notes/HOS2/reauthorization 扩展、sealed production cognitive capability，以及 Agentd 对这些入口的运行期调用。它不是整个 193-crate workspace 所有可写 API 的审计，也不证明每种 CognitiveStore 兼容写路径都必须经过这个 writer。原 full-cut 扫描包含所有登记表；其他路径只要提交这些表，也会使已发布 cut 过期。

当前新入口为 active writer 复用原 `BEGIN IMMEDIATE` 下的全状态 capture 与外部 ACK。它只负责显式调用的那个确认点，并不会给下面的方法自动添加持续 checkpoint。

## 原 writer 入口清单

除另行注明外，文件为 `codex-rs/hepta-memory/src/production_writer.rs`；行号是 db91 固定版本。

| 入口 / 路径 | 原持久化或外部动作 | 新 bootstrap ACK 的覆盖 |
| --- | --- | --- |
| `open` / `open_with_live_verifier`，528–676 | 获取原文件 owner lock；获取 lease、过期关闭及 successor 获取可能写 lease chain | factory 的显式后置 ACK 可以包含已完成的 lease 写入；并未让构造器本身拥有默认 publisher |
| `admit`，738–762 | 原 event/outbox admission，重放可不新增 | 运行期无自动 ACK |
| `prepare_operation`，767–790 | operation identity + event/outbox 在原事务原子写入 | 运行期无自动 ACK |
| `claim_dispatch_lease` / `renew_dispatch_claim`，841–872 | 原 operation claim / renew 事务 | 运行期无自动 ACK |
| `recover`，875–890 | 调用 `finalize_replayed_occurrence`；不是通用 read-only 方法 | 可能终止 lease，见下文 |
| `recover_inherited_queued`，895–908 | 从已终止 predecessor 读取原 queued receipt | 本身不制造新 send 身份；后续 dispatch 另有实际写入 |
| `status`，910–915；`final_use_binding`，795–839 | 原状态 / 不可变 binding 读取与校验 | 不应为它们虚构新的 mutation 或 ledger |
| `reconcile`，923–929；target batch，935–1088 | 观察原 target 结果，按原 domain 写终态 / 不确定状态 | 无自动 full-cut ACK；observer 不重发并不等于不写库 |
| `mark_indeterminate` / `apply` / `reject` / `rollback_occurrence`，1151–1192 | 原结果状态事务 | 无自动 full-cut ACK |
| `release` / `rollback_lease`，1195–1211 | 原 Active→Released / RolledBack commit | 新 active-only API 在这之后正确拒绝，不能用于终态发布 |
| ordinary compatibility `dispatch_target`，1254–1323 | 原一次 dispatch claim、真实 target 调用、结果 settlement | 与 FinalUse 严格入口是不同公开组合边界；不能把新strict factory等同于所有兼容调用迁移 |
| strict `dispatch_final_use_target_with_owner`，1355–1662 | 内部多次原事务，随后真实 FinalUse target entry；详见下一表 | 单次 bootstrap ACK 不覆盖其执行期改变 |
| sealed `remember_with_kg` / `correct_with_kg` / `forget_with_kg`，1864–2005 | 同一原事务内 admission + semantic/KG 修改 + terminal event | 返回原 mutation receipt 前没有独立完整 cut ACK |
| 原 Objective retain / observation / local cancellation | 新 domain 仍在同一 CognitiveStore，原 commit→ACK | 原 owner sender 已有显式 ACK，当前片只提取共享 helper |
| 原 Objective `snapshot_acknowledged` | 同一原事务读取真实 snapshot + full cut ACK | 继续必须同事务；不是普通本地 snapshot |
| 原 Objective recovery/page/普通 snapshot | 读取保留身份、exact raw 与既有历史；不授发送权 | 本地读取本身不证明独立 ACK |

### strict dispatch 不能只在末尾泛泛加一次 ACK

原流程在同一个高层方法内有多个真正持久化边界：

| 原代码位置 | 状态变化 / 外部边界 | 后续严格接线必须保留的条件 |
| --- | --- | --- |
| 1401–1448 | HOS2 原 reauthorization claim 或原 operation claim | 只能消费原内部 pre-boundary proof，不把一般 unknown 改成可重发 |
| 1457–1497 | 原 current / inherited dispatch claim event | 真实 target 入口前已持久声明 indeterminate；不能从调用结果猜测没进入 |
| 1498–1509 | 原 claim mark-entered / enter-reauthorization | 另一原事务；不能只在更早的 claimed cut 上进入外部边界 |
| 1522–1607 | FinalUse claim / entry 拒绝后的原 proof 或原拒绝 settlement | 如是 HOS2 proof，必须沿原规则保留；失败不能凭空发放新授权 |
| 1565–1610 | 原 verified-use 闭包与 target future | 真正外部 effect 入口；checkpoint 不能替代一次性 FinalUse |
| 1618–1652 | 原 target结果 settlement；原 claim-settled marker 可在其后写入 | 若要求该阶段 current-cut，不能在后续 mark-settled 写前发布后仍说最终状态已覆盖 |
| 1654–1660 | 对已提交 Notes 结果自动调用 receipt retirement | 此时必须另考虑原应用 receipt 删除边界，不能只在高层 return 后追加 ACK |

完整 cut 和原 effect journal 的角色不同。即使 immutable request / terminal event 没被改动，后续 registered table 写入也改变 full state digest。若外部 backend 只保留旧 cut，严格恢复会拒绝与新 DB 状态不匹配的组合；若允许旧 DB 一起回滚，又必须由独立 CURRENT 规则拒绝旧 cut。不能以“事件仍在原库”替代独立 freshness 证明。

## Notes 与 HOS2 的外部 receipt 退役

| 原文件 | 原行为 | 本片未解决的问题 |
| --- | --- | --- |
| `production_notes_owner.rs:25–48` | `settle_notes_terminal` 验证原 receipt，调用原 lease reconcile 写 terminal event | 结果有本地 durability，但没有自动新 full-cut ACK |
| `production_notes_owner.rs:54–108` | 读取原 durable terminal row、核原 binding/live authority，构造 sealed `NotesRetirementPermit` 后调用 target | 允许应用丢弃其 receipt 的原入口没有 independent current-cut 步骤 |
| `production_notes_owner.rs:111–134` | 重试原最新 committed receipt 的 retirement，明确不做应用 dispatch | 幂等 metadata ACK 不等于完整 cut 已被独立确认 |
| `production_hos2_owner.rs:44–96` | 原 HOS2 conflict / terminal receipt 写入 | 原本地 journal 变更同样使 full cut 过期 |
| `production_hos2_owner.rs:103–138` | 读原 durable terminal prefix，构造 sealed `Hos2RetirementPermit`，执行原 native frontier retirement | 独立 full-cut ACK 尚未接到这个 kernel history 丢弃边界 |

Notes bootstrap 的 `attached` 是另一个边界：`hepta-agentd/src/notes_bootstrap.rs:204–241` 构造 target 并通过原 inherited descriptors 交换 ACK，原 `with_additional_target` 只更新内存目标表。这不是上表中原 operation terminal event，也不是应用 receipt retirement。

## lease 终态的完整遗漏集

`LocalLeaseOutbox::require_current_transaction` 走原 active 校验，所以当前新 `checkpoint_current` 拒绝终态是正确约束，不能为“补 checkpoint”而改成允许 stale writer。

明确会进入终态的原路径至少包括：

- `release` / `rollback_lease` → `local_lease_outbox.rs:1301–1354 transition_lease`。该原事务同时核 lease/event/outbox、禁止 unresolved outcomes、核 compact journals，然后追加 terminal lease 并 commit。
- `expire_lease`（1189 起）在显式原绑定过期后 terminalize，再由原 writer open 决定合法 successor。不能从 expiration 推断外部 effects 没发生。
- `ProductionDurableWriter::recover` → `finalize_replayed_occurrence`（3065–3159）。NotAdmitted / Queued 可以不终止；已 terminal occurrence 且其他 occurrence 不再 unresolved 时会追加 Released。这条恢复方法必须按分支分类。
- predecessor terminalization / successor acquisition 位于原 writer open（569–645）；bootstrap 仅能 checkpoint 成功打开的当前 active successor 的完整状态，不能证明任意先前失败窗口都有独立可恢复 cut。

终态后调用 active API 会拒绝；终态前调用又不能包含随后 terminal commit。单纯调整调用位置不能消除这个窗口。

## 最小后续设计建议（未实现、不是现成 API）

### A. 先保留当前 bootstrap 片的真实范围

不把 provider optional，不新增 echo 默认值；不把初始 `current_cut` 从待恢复 DB 重新算出来。新入口只用于当前 active original writer 的显式确认，既有 whole-owner runtime 缺口继续列在账上。

### B. 对 active 原结果与 receipt retirement 做窄接线

优先从一个原 domain 的退役入口开始（Notes 或 HOS2，分片选择），复用同一个原 publisher 能力和同一原 writer：在持有原 SQLite 写入序列化事务期间核原 exact terminal binding，捕获完整 cut、等待独立 ACK、重新 live verify，然后才形成原 sealed retirement permission。不能先发退役许可再补 ACK，也不能建立新的 UI receipt ledger。

这只是后续方向，不是本片新增方法。真实原 target metadata 调用的阻塞、不可重入及最终权限校验仍须审查；不能在 ACK 后又追加原 claim-settled 行却继续引用之前的 cut。若调用方可继续调用未接 checkpoint 的旧退役入口，canonical strict runtime 必须显式迁移，不能把新增方法当作全局强制。

### C. lease 终态采用独立的原 owner 事务方案

不要改 `ensure_current_active`，不要仅凭一个可序列化的 terminal receipt 赋予旧 writer 写权。可研究的最小方案是由**原终态转换本身**保留一个受限、不可伪造的 post-commit 确认上下文：绑定确切 terminal lease head、原 owner/authority/lease/token/epoch 与当前源实例；只允许在同原全写者锁下核对“该 terminal head 仍是当前 head，尚无 successor”，发布该 exact terminal cut，不允许任何 domain write 或复活 sender。

这个建议尚没有 API、实现或授权证明。特别是 commit 后进程死亡、external ACK 未知、authority 已过期、或已有 successor 的情况，需要原外部 current-cut / authority 服务提供明确恢复决定。当前 strict recovery 不接受 DB 与旧 cut 不一致，不能为自动恢复而回退 legacy fresh open，也不能在新进程现场重算并 self-sign 新 cut。

因此 `release_and_checkpoint` 之类名称本身不会解决跨 SQLite 与外部服务的崩溃原子性。若未来采用此封装，必须把 commit→ACK 的 unknown 保留为事实，并分别证明 success、迟到 CAS、取消和 restart；不能宣传为不存在未知窗口。

### D. backend 的最低真实前置

复用现有 `ObjectiveSenderCheckpoint` 契约并不等于实现了 backend。生产实现仍需明确独立持久域、认证的 latest read、原 owner / authority fence 验证、同 lease 的发布顺序、取消与远端迟到请求处理，以及恢复时提供 CURRENT cut 的受信 adapter。上述能力不能由当前 DB、本地同 rollback 域文件、fixture echo、普通时间戳或其他 domain 的 journal prefix 代替。

## 后续验收分离

每个后续片都应保留其原 owning-package 的正反和 crash 点证据，独立于已通过的 322 项历史 memory 测试。至少区分：mutation commit 前；commit 后 ACK 前；ACK 不确定；ACK 成功但最后 live 拒绝；receipt retirement 前后；lease terminal commit 前后；successor 已获取；外部迟到发布。拒绝重发和缺失恢复资格是不同结果，报告不能互相替代。

本分析只记录已有源码事实与明确标注的建议，没有实现 backend，没有选择新的 trust root，也没有关闭全 owner runtime / terminal-cut blocker。
