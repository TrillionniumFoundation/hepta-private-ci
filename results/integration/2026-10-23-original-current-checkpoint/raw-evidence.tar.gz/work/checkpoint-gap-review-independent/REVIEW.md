# 原 writer checkpoint_current 与 strict bootstrap 独立只读审查

## 结论

建议按方案推进**当前 active original writer 的显式完整 cut 发布入口**，并让 strict factory 必须接收 checkpoint、在原恢复和 lease 获取完成后执行 ACK、最后才安装 config。返回同一个 writer 与同一个 checkpoint `Arc` 绑定的 typed attachment，是当前最小且可复核的接线范围。

这仍是 API 方案审查。审查时没有对应的新实现，不能记录为编译通过、生产 checkpoint 已具备、全 owner 每次写入均受独立 current-cut 保护，或生产 bootstrap 已经实际运行。本文没有修改产品源码，没有运行 Cargo、QEMU、任何 guest、GitHub 或网络操作。

独审指出过两个确定的作用域问题；保存的方案快照已经纳入修正，后续实现仍必须保留这些边界：

1. 复用当前 active-lease fence 的 `checkpoint_current` **无法在 lease 已 Released/RolledBack/expired 后发布终态 cut**。不得把“终止后再调用一次”列为可用方案。
2. strict factory 的 Notes handoff 构造目标并发送真实 `attached` ACK，但**没有把 handoff ACK 写入 CognitiveStore**。bootstrap cut 可以包含已提交的 lease 状态，不能声称它持久记录了 Notes socket 握手。

另需持续保留缺失的生产能力：独立 current-cut backend、其受信 latest-read 恢复适配器、同 lease 内的迟到发布 fencing、取消后的外部副作用约束、运行期每个所选持久化边界的接线，以及终态 lease 的专门授权发布协议。这些是实际代码或信任设施缺口，不是仅缺本机编译环境。

## 审查身份与证据范围

- 固定原源码：`TrillionniumFoundation/hepta-private-ci` commit `db91f9ec316ba1472e7adf97f8415949de012469`，tree `81c03af04be56659d3eb4da71bf61aeac34c949f`。
- 直接读取已经下载的完整 Git checkout，核对 12 个引用文件的工作副本、原 Git object、mode、Git blob、SHA-256 和字节数；结果见 `review-inputs.json`。这不是重新从远端读取。
- 方案来自 `work/checkpoint-gap-review/API_DESIGN.md`；独立快照为 `reviewed-api-design.md`，SHA-256 `813b0348677f4f3e1a52bf355f00ad9f2559a623c6251a56f53a5d367ea088b2`。此快照已包含本轮 terminal / Notes 修正（105–108、188–195）；不是修正前的初次阅读版本。后续方案修改须与此版本区分。
- 方案计划位于另一个 active-Agentd-helper 修复之后发布；该修复不被此报告当作 checkpoint 实现或执行证据。
- 下文行号均指上述 db91 原源码；方案行号指保存的方案快照。既有 memory 317/319/322 和 Agentd 桥接测试状态不被本次只读审查更新。

## 原机制与新入口的可接受边界

| 审查项 | 原机制与方案 | 判断 |
| --- | --- | --- |
| 初始恢复信任 | `cognitive_store_recovery.rs:55–75` 要求宿主独立持久保留并认证 CURRENT cut；digest 本身只是完整性比较。factory `production_composition.rs:124–138,187–196` 消费此原输入 | 新入口不能先打开可疑 DB、现场计算 cut，再把它作为初始受信恢复输入 |
| 同一 owner | 方案在原 `ProductionDurableWriter` 上新增方法，继续用其 `store.pool`、lease 和 retained live verifier | 没有必要新增库、writer、签名器、schema 或另一个协议 |
| 全写者串行 | `objective_sender.rs:408–441` 已在原 `BEGIN IMMEDIATE` 中 capture → 外部 ACK → exact equality → live check | 必须复用这个原 SQLite 写入锁；不能把 `recovery_anchor()` 返回后的异步 ACK 或 capability 自有 Mutex 当作等价替代 |
| 完整状态 | `cognitive_store_recovery.rs:376–633` 校验原 schema、所有登记表和 exact 数据；有行数、总字节、单行与 schema 上限（49–53） | 完整 cut 包含该事务之前所有已提交的登记状态；不是 Objective-only 摘要 |
| 读取确认 | `snapshot_acknowledged` 在同一事务读 request/snapshot，再做完整 ACK（`objective_sender.rs:281–299`） | refactor 必须保留 snapshot 与 cut 的同事务身份，不能退回普通 snapshot + 单独 ACK |
| 单次发送 | 现有 mutation 先原事务 commit，再 ACK；失败保持 unknown 和已占用的 send fence（`objective_sender.rs:375–381`） | 公共 checkpoint 只读状态，不得创建 request、event、ticket 或新的发送机会 |
| bootstrap 输入 | 方案使 checkpoint `Arc<C>` 与期限成为必需字段，旧成功 signature 被显式迁移 | 不得提供 `None`、always-ACK 或本地 DB echo 默认值 |
| 返回接线 | typed attachment 返回 Notes identity 和已经绑定的原 sender | factory 与此 sender 可证明使用同 writer、同 checkpoint `Arc`；不代表所有受信调用方都无法另选 publisher |
| 最后安装 | 原 `config.rs:337–359` 在全部 metadata callback 后重新 live verify，再连续设置两个 handle | 新代码须先完成 checkpoint 和 sender 构造；安装后不能再做会失败的构造或产生半注册 |

### 初始 current-cut 与新 ACK 是两个不同的信任步骤

初始 cut 用于批准恢复旧 owner；新 cut 用于让外部能力确认恢复和 lease 获取之后的状态。新方法不能替代前一个输入。`CognitiveStore::recovery_anchor()`（`cognitive_store_recovery.rs:96–107`）返回前已经结束其事务，而且注释明确它不发布独立 ACK witness。把它返回的值直接交还给恢复入口，或仅存入同一回滚域中的普通文件，都没有建立初始 CURRENT 信任。

新方法返回的 `CognitiveRecoveryAnchor` 也只是已成功调用注入能力所确认的精确值。这个类型本身可序列化，不是签名、写授权、外部服务实现或长期永远 current 的证明。之后任一原 writer mutation 都会改变 full state digest。

### 取消、超时与同步回调

原 trait 已明确要求：future 每次 poll bounded/nonblocking、不重入同一个 CognitiveStore、取消后不能由后台继续发布旧 cut（`objective_sender.rs:45–58`）；sender 文档也要求同步 verifier/clock bounded/nonblocking（109–113）。方案保留这些契约是正确的。

但这不是通用 Rust API 能自动强制的性质：

- Tokio timeout 只能协作式取消 await；阻塞的 future 构造、poll、verifier 或 clock 回调无法被它抢占。
- 参数只包住外部 ACK future 的等待，不给 `BEGIN IMMEDIATE` 获取、完整 cut 扫描、同步校验和 rollback 的整段过程提供硬 wall-clock 上限。
- future 被丢弃并不证明远端请求已撤销；`spawn_blocking`、后台线程或已发给服务端的请求可能继续执行。只有真正 backend 的完成、取消和 fencing 协议能保证释放 SQLite fence 后不发生迟到覆盖。
- 当前 writer fence 标识 owner、lease 和 authority，不是每个 cut 的独立顺序号；同一 active lease 上多次发布仍需 backend 的独立 latest-read/CAS 和迟到请求拒绝机制。不能仅比较 lease generation 就宣称同 lease 的先后发布已排好序。

因此此片可以保留一个显式注入且无默认值的生产能力要求，但不能把 fixture 对原 cut 的 echo 变成生产实现，也不能用 timeout 测试替代真实 provider 的取消语义资格。真实 provider 未提供时，canonical production composition 仍不能被宣称可部署。

## 两项确定的范围修正

### 1. 终态 lease 不能通过 active checkpoint 入口发布

证据链：

- `production_writer.rs:1195–1211` 的 `release` / `rollback_lease` 调用原 lease 终态转换并返回。
- `local_lease_outbox.rs:1162–1167` 分别转换为 Released / RolledBack。
- 当前 sender fence 走 `require_current_transaction`（`objective_sender.rs:384–405`）。
- 该原方法在同一事务调用 `ensure_current_active`（`local_lease_outbox.rs:3188–3199`）。
- 非 Active 状态在 `local_lease_outbox.rs:5208–5215` 明确拒绝；deadline 也在 5191–5205 检查。

所以“release commit → checkpoint_current”按设计必然拒绝；“checkpoint_current → release commit”又会让刚发布的 cut 过期。方案末节已按此审查把通过该入口接线的范围限定为仍 active 的有效调用；**终态 lease、过期及 takeover 的最终发布仍需后续原授权事务协议**。

本片不应放松 active fence。应至少保留一个原 owning-package 负例：终态后调用新方法被拒绝、publisher 未调用、lease 终态没有恢复为 Active，也没有新 ticket/event。

### 2. Notes handoff 不等于原库中的持久记录

strict factory 调用的是 `AgentdProductionOperationRuntimeConfig::with_notes_from_session`（`production_composition.rs:199–206`）。它进入 `notes_bootstrap.rs:204–241`：验证原 recovered host、接收真实 inherited descriptors、构造 `ProductionNotesTarget`、把 target 放入 runtime config、发送 `RegistrationStatus::Attached`。原 `with_additional_target`（`production_writer_host.rs:113–131`）只更新内存中的目标列表。

这条路径没有 CognitiveStore commit。post-handoff checkpoint 的正确作用是：在手中已有真实 Notes handoff 的情况下，要求 bootstrap 的原持久 owner 状态获得独立确认，失败则不注册配置并关闭未安装 descriptors。它不能证明 Notes handoff ACK 已经由本 full cut 持久保留，也不能把这个 ACK 作为最终安装成功身份。

真正 Notes 终态写入在 `production_notes_owner.rs:25–48` 的原 `reconcile_notes_terminal`。后续 `retire_notes_receipt:54–108` 当前验证本地 terminal row 和 live authority 后直接给应用发 receipt retirement permission，没有独立 full-cut ACK。bootstrap 的一次 checkpoint 不覆盖这个后续边界。

## 持续 mutation 作用域

下表是实际调用范围区分，不是“所有 mutation”完成清单；是否会改变数据仍按具体结果而定。

| 原路径 | 对 cut 的影响 | 本提议的覆盖 |
| --- | --- | --- |
| `ProductionDurableWriter::open` lease acquisition / expired close / successor（`production_writer.rs:569–645`） | 可能追加原 lease 行 | canonical factory 在恢复后 ACK，可包含这些已提交变化 |
| 原 Objective retain / observation / cancellation | 追加独立 sender domain 行，仍用同原库 | 保留现有 commit→ACK 和 unknown 行为；只做 helper 复用 |
| `prepare_operation`（767–790） | 原 admission/operation/outbox 事务 | 无自动新 checkpoint |
| dispatch claim/renew（841–872） | 原 dispatch claim 持久状态 | 无自动新 checkpoint |
| recover/finalize、reconcile、mark/apply/reject/rollback occurrence | 可追加结果或终态 | 无自动新 checkpoint |
| 原 production cognitive mutation（remember/correct/forget，约1844–2005） | 语义表、KG、原 admission/event 等事务 | 无自动新 checkpoint |
| Notes terminal reconcile / receipt retirement（`production_notes_owner.rs:25–108`） | 原结果先持久化，再可能删除应用侧 receipt | 无新 ACK 保护；需要独立后续接线 |
| release / rollback / expiry / takeover | 终态或 successor 改变 lease chain | active-only 新入口不等于终态协议 |
| Agentd 原运行期 reconciler（`runtime.rs:406–423`） | 周期调用 reauthorize_pending 和 reconcile | 启动后的持续写入不能引用 bootstrap ACK 当作最新 cut |

strict factory 的配置安装是内存注册，之后原 runtime 还要 attach（`runtime.rs:205–216`）并启动原 reconciliation。因此报告应使用“bootstrap 当前 cut 发布入口”，不能使用“所有原 owner 写入都已 checkpoint”“原生产恢复已完整闭合”等结论。

## 建议实现与验收约束

以下是尚待实现/执行的检查，不是本次通过的测试：

| 类别 | 必须观察的真实行为 |
| --- | --- |
| 无请求正向 | 原 active writer 的新方法能确认 exact post-lease cut，不添加任何 Objective request/event，也不返回 ticket |
| 原身份 | provider 实际看到 owner/schema/state 和当前原 lease/authority fence；返回错 owner/schema/state 时拒绝 |
| 写入串行 | 在 ACK 挂起时，另一个真实原 SQLite mutation 无法越过同一写锁；取消/失败结束后可继续，并明确没有迟到 provider publication |
| 已有 sender 回归 | retain、checked observation、snapshot_acknowledged、local cancellation 的 old exact semantics 不变，尤其 commit 后 unknown 不重授 send permission |
| bootstrap 顺序 | 回调 cut 包含新 lease；初始 supplied cut 仍先通过原恢复；没有提供 provider 的成功 API 路径 |
| early rejection | 重复注册、非法期限、错误 current-cut owner 等拒绝时不触发 checkpoint，不做新的 target/issuer/clock 工作（按照既定 guard 顺序） |
| Notes 后失败 | 真实 Attached ACK 之后，checkpoint拒绝/超时或最终 live check 拒绝：config 两 handle 都为空，应用 stream 关闭，零 effect/issuer bytes；不能把早期 Attached 当最终成功 |
| 同 provider | 成功 attachment 的 sender 后续 ACK 使用与 bootstrap 同一 `Arc<C>`，同 recovered writer；显式兼容 getter 的不同信任范围单独说明 |
| 终态反向 | Released/RolledBack/expired 原 lease 拒绝 checkpoint，不调用 provider，不创建状态或重新激活 lease |
| 后续变更 | 普通原 mutation 后 full cut 实际改变；旧 bootstrap cut 不能被继续当作 CURRENT；明确原恢复按 exact cut 拒绝 |
| 真实 backend | 独立认证与latest-read、同 lease 的并发/迟到 CAS、drop/超时/进程崩溃后的发布行为需原 backend 专门资格；Test/Crash/Probe 不能替代 |

原 memory 与 Agentd owning-package 都须按最终源码和原锁实际执行。只测 memory 不覆盖 factory；只把新源码放进 workflow 也不是执行成功。本次没有为任何新 test 记录 pass。

## 发布范围建议

选择 typed attachment 后，保留现有显式 `AgentdConfig::original_objective_sender(checkpoint, deadline)` 作为受信 embedding 的兼容接口可以接受，但必须准确写出保证范围：**canonical strict factory 返回的 sender**与 bootstrap 使用同 publisher。现有 public 原 writer 和显式 config builders 仍是受信调用面；此方案没有强制所有外部使用者统一走同一个 publisher。

若目标是整个 `AgentdConfig` 内永久禁止更换 provider，需要另外的 API 迁移和同原 trait 的类型擦除存储方案，不能在此片同时悄悄承诺该更强性质。也不能通过新数据库、UI ledger、自签 key 或第三种 checkpoint 协议绕过该决定。

固定源码链接基址：`https://github.com/TrillionniumFoundation/hepta-private-ci/blob/db91f9ec316ba1472e7adf97f8415949de012469/`。本地读取的各文件身份和设计快照 hash 已单独保留，便于 root 将本报告用于候选实现的下一轮逐字节复核。
