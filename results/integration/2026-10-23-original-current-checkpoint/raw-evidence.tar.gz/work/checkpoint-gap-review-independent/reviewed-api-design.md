# Proposed original-writer current-cut ACK and strict bootstrap

Status: design for parent and independent review; no implementation of this
proposal has been written. Fixed original source is Hepta
`db91f9ec316ba1472e7adf97f8415949de012469`. Publication should follow the separately
prepared two-file Agentd active-helper fix on the current `#3444` branch; that
fix does not change any checkpoint logic. No Cargo or GitHub operation was run.

## 1. Minimal original-owner entry point

```rust
impl ProductionDurableWriter {
    pub async fn checkpoint_current<C: ObjectiveSenderCheckpoint>(
        &self,
        checkpoint: &C,
        deadline: Duration,
    ) -> Result<CognitiveRecoveryAnchor, ObjectiveSenderError>;
}
```

The existing trait and error types remain the same. Their historical Objective
names do not make the payload an Objective-only cut: the current implementation
already captures all registered CognitiveStore tables. Avoid a second trait,
error conversion layer, database, key, issuer or serialized schema in this slice.
This entry point is restricted to the original **current active writer lease**.
Its original `require_current_transaction` check must not be weakened for an
already released, rolled-back, expired or superseded writer.

Keep the implementation beside the current sender ACK code, with a common
private method on the same writer:

```rust
async fn checkpoint_current_transaction<C: ObjectiveSenderCheckpoint>(
    &self,
    transaction: &mut Transaction<'_, Sqlite>,
    checkpoint: &C,
    deadline: Duration,
) -> Result<CognitiveRecoveryAnchor, ObjectiveSenderError>;
```

Move the current sender's `current_fence` implementation to the original writer
without changing its checked lease or fence fields. The public method validates
`0 < deadline <= 5 seconds`, checks the retained live verifier and original
durability/lease, opens the original `BEGIN IMMEDIATE`, and delegates. The shared
transaction helper requires the current original lease in that same transaction,
captures the full cut, performs the existing pre-ACK live check, awaits the same
checkpoint under the cooperative timeout, requires exact returned-cut equality,
and performs the existing post-ACK live check. The public method rolls back the
read-only transaction and performs the last live check before returning the cut.

Existing sender `acknowledge_committed` delegates to the public method and drops
only the returned cut. `snapshot_acknowledged` keeps its request/snapshot read in
the same transaction and delegates to the shared transaction helper before its
existing rollback/final-live check. `retain_before_send`, observation retention
and cancellation retain their one original mutation and single-use permission
semantics. There is no synthetic Objective request or extra sender event.

The timeout remains cooperative. Synchronous verifier/clock work and every
checkpoint future poll must be bounded and nonblocking. This refactor cannot
make a detached worker or remote server stop publishing after cancellation;
that remains a required property of the actual checkpoint implementation. Do
not add `spawn_blocking`, a read/rename publisher, or an always-ACK default.

## 2. Mandatory factory input

```rust
pub struct AgentdProductionHostInputs<'a, C: ObjectiveSenderCheckpoint> {
    // All existing required authority, current_cut, descriptor and target fields.
    pub checkpoint: Arc<C>,
    pub checkpoint_deadline: Duration,
    // Existing notes remains optional; current-cut ACK does not.
}

pub async fn attach_production_operation_host<C: ObjectiveSenderCheckpoint>(
    config: &mut AgentdConfig,
    inputs: AgentdProductionHostInputs<'_, C>,
) -> Result<AgentdProductionHostAttachment<C>, AgentdError>;
```

Upgrade the existing strict factory, rather than adding an optional field or
leaving the old successful signature available with no ACK. Missing checkpoint
is a compile-time input omission. Invalid deadline fails before consulting
target, clock, issuer or checkpoint; already-configured rejection remains the
first guard. The initial `current_cut` must still be independently supplied and
authenticated **before** recovery. The new method may only capture the live
original recovered owner after that admission; it must never derive the initial
recovery input from the suspect database.

Order after the existing preflight is:

1. Original FinalUse authority and issuer-peer validation.
2. Original exact-cut recovery and one original writer/lease acquisition.
3. Original recovered-host checks and optional original Notes offer/ACK handoff.
4. `recovered_host.writer().checkpoint_current(checkpoint.as_ref(), deadline)`.
5. Create a restricted sender capability using that **same `Arc<C>`** and the
   **same recovered writer**; this does not open a writer or write an event.
6. Existing final synchronous protected verifier and atomic two-handle install.
7. Return the successful attachment only after installation.

No fallible constructor occurs after install. ACK refusal, timeout, cut mismatch
or live-authority failure leaves both config handles absent. Existing durable
recovery/lease records are preserved, with the same requirement for fresh
independent recovery authorization on retry. An earlier real Notes `attached`
ACK still must not be presented as successful final factory installation.
The present `with_notes_from_session` path builds a target and exchanges the
real descriptor/ACK; it does not write a CognitiveStore row. Therefore the new
cut includes the original lease mutation, but must not be described as a durable
SQLite record of the Notes handoff ACK.

## 3. Binding bootstrap and later sender to the same publisher

Recommended minimal result shape:

```rust
pub struct AgentdProductionHostAttachment<C: ObjectiveSenderCheckpoint> {
    pub notes_identity: Option<NotesTargetIdentity>,
    pub original_sender: ProductionObjectiveSender<C>,
}
```

Returning the already-bound restricted sender avoids making `AgentdConfig`
generic or adding a second object-safe/boxed checkpoint protocol. The canonical
strict path consumes this capability; factory and sender necessarily received
the same writer and checkpoint Arc during construction.

Compatibility boundary: the existing explicit
`AgentdConfig::original_objective_sender(checkpoint, deadline)` can remain for
trusted embeddings of other explicitly installed owners. Its caller can still
choose another provider, as can the existing public original writer constructor.
Do not claim a global prohibition on all trusted callers changing providers.
If the product instead requires the config API itself to guarantee one publisher
for every later sender construction, that is a larger API change: retain a type-
erased adapter of the **same** original trait in config and remove the caller's
checkpoint argument. Do not add both approaches in this slice. Parent must select
the intended boundary before implementation.

The existing return `Option<NotesTargetIdentity>` changes to a typed attachment.
This is an explicit source migration, not a silent fallback: existing callers
use `.notes_identity`. The original sender and checkpoint traits, callback
implementations, database schema, original Cargo.lock and Desktop dependency
pin remain compatible. A host newly opting into strict factory construction
must provide a genuine checkpoint implementation; a fixture cannot do that.

## 4. Exact source/caller impact

| File | Proposed change |
| --- | --- |
| `codex-rs/hepta-memory/src/objective_sender.rs` | Add no-ticket writer method; move/reuse the current fence and ACK helper; preserve sender lifecycle |
| `codex-rs/hepta-memory/src/objective_sender_tests.rs` | Real original-owner no-ticket ACK, failure, write-lock and no-event tests |
| `codex-rs/hepta-agentd/src/production_composition.rs` | Required generic checkpoint input, typed attachment, final bootstrap ACK |
| `codex-rs/hepta-agentd/src/lib.rs` | Export attachment type |
| `codex-rs/hepta-agentd/src/production_composition_fixture.rs` | Explicit test-only publisher/probes; required input type |
| `codex-rs/hepta-agentd/src/production_composition_tests.rs` | Adapt generic inputs/result; verify bootstrap cut includes new lease and failed ACK never installs |
| `codex-rs/hepta-agentd/src/production_composition_notes_tests.rs` | Adapt result; ACK refusal/timeout after actual Notes handoff leaves both config handles absent |
| `codex-rs/hepta-agentd/src/objective_sender_host_tests.rs` | Consume returned canonical sender and prove same provider/writer; retain explicit getter compatibility tests |
| Existing adjacent `OBJECTIVE_SENDER.md`, `PRODUCTION_COMPOSITION.md` | Record exact scope and still-missing production publisher |

The complete source search found factory callsites only in the three Agentd test
files and the fixture return type. This is a fixed-tree observation, not proof
that unseen downstream applications have no consumers.

## 5. Required focused verification

Original memory tests should cover successful no-ticket ACK with no sender rows
or events; exact current writer fence; refused/held/mismatched ACK; final live
revocation; write lock held through the callback; later explicit ACK without new
events. A terminal-lease test must release or roll back the original lease, then
require this entry point to reject **without calling the publisher**. Existing
322 results remain historical until the new memory source is
tested under the original lock/toolchain.

Original Agentd tests should prove callback sees the **post-acquisition** cut,
has not been invoked on early refusal or already-configured input, and success
returns the same provider-bound sender. Refusal/timeout after actual Notes ACK
must leave config empty, close uninstalled application streams and send no
effect/issuer bytes. Existing late protected-clock callback tests remain gates.
Agentd compilation/execution remains the original owning-package CI's job; source
review or memory tests do not qualify the factory.

## 6. Scope that remains open

This closes one local code gap: original bootstrap can publish its new live cut
without manufacturing an Objective request. It does not implement the protected
checkpoint backend, its latest-read recovery adapter, or its service deployment.
It also does not publish after every later `prepare_operation`, dispatch claim,
reconciliation, lease release/takeover or semantic cognitive mutation. Each such
mutation can invalidate a previously published exact cut. A production lifecycle
must route its selected **active-writer** success boundaries through this entry
point, or otherwise enforce an equivalent original-owner publication contract.
In particular, `release` and `rollback_lease` commit a terminal lease, after which
the original active-lease check correctly prevents this method from publishing
that terminal cut. Terminal retirement and takeover need a separate original-
authority transaction/terminal-cut design; allowing a stale writer to ACK is not
an admissible workaround. The broader owner is not continuously checkpointed
merely by this bootstrap call.
