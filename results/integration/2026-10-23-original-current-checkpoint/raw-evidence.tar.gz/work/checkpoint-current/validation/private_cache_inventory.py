#!/usr/bin/env python3
"""Verify this task's crate archives against the original lock and unpacked bytes.

Inventory is read-only. Cleanup accepts only an unchanged, verified inventory and
removes regular single-link archive files, never extracted sources or targets.
"""
from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import os
import stat
import sys
import tarfile
import tomllib

ROOT = Path(__file__).resolve().parent
TASK = Path('/dev/shm/organ-3d6a75235bcb-hepta3398')
CARGO = TASK / 'cargo-home'
REGISTRY = CARGO / 'registry'
CACHE = REGISTRY / 'cache'
LOCK = TASK / 'source/codex-rs/Cargo.lock'
EXPECTED_LOCK = '83651f11dea7f58dc96f3d119c120ab2bd8019e418979ab091ef49de7cceb9e8'
CLOSURE = ROOT.parents[1] / 'hepta-integration/production-composition/validation/memory-target-dependency-graph.json'


def digest_stream(stream):
    value = hashlib.sha256()
    while block := stream.read(1024 * 1024):
        value.update(block)
    return value.hexdigest()


def digest(path):
    with path.open('rb') as stream:
        return digest_stream(stream)


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def resources():
    return {
        'at': now(),
        'shm_free_bytes': os.statvfs(TASK).f_bavail * os.statvfs(TASK).f_frsize,
        'scratch_free_bytes': os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize,
        'memory_available_bytes': next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')),
    }


def assert_owned_directory(path):
    assert path.is_absolute() and path.is_relative_to(TASK), path
    for component in [path, *path.parents]:
        if component == TASK.parent:
            break
        entry = component.lstat()
        assert stat.S_ISDIR(entry.st_mode), component
        assert entry.st_dev == TASK.stat().st_dev, component
        assert not component.is_symlink(), component
    assert path.resolve() == path, path


def cargo_processes():
    result = []
    for entry in Path('/proc').glob('[0-9]*/comm'):
        try:
            command = entry.read_text().strip()
            if command not in {'cargo', 'rustc', 'cargo-nextest', 'just', 'clippy-driver'}:
                continue
            environment = (entry.parent / 'environ').read_bytes().split(b'\0')
            cwd = (entry.parent / 'cwd').resolve()
            if cwd.is_relative_to(TASK) or f'CARGO_HOME={CARGO}'.encode() in environment:
                result.append({'pid': int(entry.parent.name), 'comm': command, 'cwd': str(cwd)})
        except (OSError, ValueError):
            pass
    return result


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def inventory(destination):
    assert not destination.exists(), destination
    assert_owned_directory(CACHE)
    assert_owned_directory(REGISTRY / 'src')
    assert digest(LOCK) == EXPECTED_LOCK
    active = cargo_processes()
    assert not active, active
    lock = tomllib.loads(LOCK.read_text())
    packages = {f"{package['name']}-{package['version']}": package for package in lock['package'] if package.get('source', '').startswith('registry+')}
    closure = json.loads(CLOSURE.read_text())
    assert closure['Cargo_lock_sha256_before'] == EXPECTED_LOCK == closure['Cargo_lock_sha256_after']
    names = set(closure['package_names'])
    before = resources()
    records = []
    for index in sorted(CACHE.iterdir()):
        assert_owned_directory(index)
        for archive in sorted(index.iterdir()):
            st = archive.lstat()
            record = {
                'path': str(archive), 'bytes': st.st_size,
                'allocated_bytes': st.st_blocks * 512,
                'mode': oct(stat.S_IMODE(st.st_mode)), 'device': st.st_dev,
                'inode': st.st_ino, 'nlink': st.st_nlink,
                'uid': st.st_uid, 'mtime_ns': st.st_mtime_ns,
                'errors': [], 'eligible': False,
            }
            records.append(record)
            if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1 or archive.suffix != '.crate':
                record['errors'].append('not an owned regular single-link crate archive')
                continue
            record['sha256'] = digest(archive)
            package = packages.get(archive.stem)
            if package is None:
                record['errors'].append('archive package absent from original Cargo.lock; kept')
                continue
            record['package'] = {key: package[key] for key in ('name', 'version', 'source', 'checksum')}
            record['name_in_original_memory_closure'] = package['name'] in names
            if record['sha256'] != package['checksum']:
                record['errors'].append('archive checksum differs from original Cargo.lock')
                continue
            source = REGISTRY / 'src' / index.name / archive.stem
            record['source_path'] = str(source)
            if not source.is_dir() or source.is_symlink():
                record['errors'].append('corresponding unpacked source missing or symlink')
                continue
            assert_owned_directory(source)
            cargo_ok = source / '.cargo-ok'
            record['cargo_ok'] = {'present': cargo_ok.is_file(), 'sha256': digest(cargo_ok) if cargo_ok.is_file() else None}
            if not cargo_ok.is_file():
                record['errors'].append('Cargo unpack completion marker missing')
            members = []
            seen = set()
            with tarfile.open(archive, 'r|gz') as stream:
                for member in stream:
                    name = PurePosixPath(member.name)
                    if name.is_absolute() or '..' in name.parts or not name.parts or name.parts[0] != archive.stem:
                        record['errors'].append(f'unsafe archive member {member.name}')
                        continue
                    relative = PurePosixPath(*name.parts[1:])
                    if str(relative) in seen:
                        record['errors'].append(f'duplicate archive member {relative}')
                        continue
                    seen.add(str(relative))
                    target = source.joinpath(*relative.parts)
                    if target.resolve() != target:
                        record['errors'].append(f'archive member resolves through symlink: {relative}')
                        continue
                    row = {'path': str(relative), 'archive_mode': oct(member.mode), 'bytes': member.size}
                    members.append(row)
                    if member.isdir():
                        row['type'] = 'directory'
                        if not target.is_dir():
                            record['errors'].append(f'extracted directory missing: {relative}')
                        continue
                    if not member.isfile() or not target.is_file() or target.is_symlink():
                        record['errors'].append(f'not matching extracted regular file: {relative}')
                        continue
                    row['type'] = 'file'
                    extracted = stream.extractfile(member)
                    assert extracted is not None
                    row['archive_sha256'] = digest_stream(extracted)
                    actual = target.stat()
                    row['source_sha256'] = digest(target)
                    row['source_bytes'] = actual.st_size
                    row['source_mode'] = oct(stat.S_IMODE(actual.st_mode))
                    if row['archive_sha256'] != row['source_sha256'] or member.size != actual.st_size:
                        record['errors'].append(f'extracted bytes differ: {relative}')
                    if bool(member.mode & 0o111) != bool(actual.st_mode & 0o111):
                        record['errors'].append(f'extracted executable mode differs: {relative}')
            record['member_count'] = len(members)
            record['verified_source_files'] = sum(row.get('type') == 'file' for row in members)
            record['archive_source_comparison_manifest_sha256'] = canonical(sorted(members, key=lambda row: row['path']))
            record['eligible'] = not record['errors']
    result = {
        'purpose': 'Remove only reproducible compressed archives; not a source or compile repair',
        'script_sha256': digest(Path(__file__)), 'recorded_at': now(),
        'cache_root': str(CACHE), 'cache_resolved_root': str(CACHE.resolve()),
        'lock_path': str(LOCK), 'lock_sha256': EXPECTED_LOCK,
        'closure_receipt': str(CLOSURE), 'closure_receipt_sha256': digest(CLOSURE),
        'closure_package_names_count': len(names),
        'before': before, 'after_read_only_inventory': resources(),
        'active_cargo_processes': active, 'archives': records,
        'total_archive_count': len(records),
        'total_archive_bytes': sum(row['bytes'] for row in records),
        'eligible_archive_count': sum(row['eligible'] for row in records),
        'eligible_archive_bytes': sum(row['bytes'] for row in records if row['eligible']),
        'eligible_allocated_bytes': sum(row['allocated_bytes'] for row in records if row['eligible']),
        'kept_archive_count': sum(not row['eligible'] for row in records),
        'source_and_index_and_target_removed': False,
    }
    write_new(destination, result)
    print(json.dumps({key: result[key] for key in ('total_archive_count', 'total_archive_bytes', 'eligible_archive_count', 'eligible_archive_bytes', 'kept_archive_count')}))


def cleanup(inventory_path, destination):
    assert not destination.exists(), destination
    record = json.loads(inventory_path.read_text())
    assert record['cache_root'] == str(CACHE)
    assert record['script_sha256'] == digest(Path(__file__))
    assert digest(LOCK) == record['lock_sha256'] == EXPECTED_LOCK
    assert_owned_directory(CACHE)
    active = cargo_processes()
    assert not active, active
    before = resources()
    eligible = [row for row in record['archives'] if row['eligible']]
    # Validate every deletion first; stop without deleting anything if stale.
    for row in eligible:
        archive = Path(row['path'])
        assert archive.is_relative_to(CACHE) and archive.resolve() == archive
        st = archive.lstat()
        assert stat.S_ISREG(st.st_mode) and st.st_nlink == 1
        assert (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns) == (row['device'], row['inode'], row['bytes'], row['mtime_ns'])
        assert digest(archive) == row['sha256'] == row['package']['checksum']
        assert Path(row['source_path']).is_dir()
        assert digest(Path(row['source_path']) / '.cargo-ok') == row['cargo_ok']['sha256']
    removed = []
    try:
        for row in eligible:
            Path(row['path']).unlink()
            removed.append({'path': row['path'], 'bytes': row['bytes'], 'sha256': row['sha256']})
    finally:
        result = {
            'recorded_at': now(), 'script_sha256': digest(Path(__file__)),
            'inventory_path': str(inventory_path), 'inventory_sha256': digest(inventory_path),
            'before': before, 'after': resources(), 'active_cargo_processes': active,
            'removed': removed, 'removed_count': len(removed),
            'removed_archive_bytes': sum(row['bytes'] for row in removed),
            'all_expected_archives_removed': len(removed) == len(eligible),
            'Cargo_lock_sha256_after': digest(LOCK),
            'source_index_git_target_and_toolchain_removed': False,
            'scope': 'Compressed archives only; extracted byte verification and exact Cargo checksum identities are in the preserved inventory. Cargo may redownload reproducible archives. No compile behavior, profile, source or lock change.',
        }
        write_new(destination, result)
    print(json.dumps({key: result[key] for key in ('removed_count', 'removed_archive_bytes', 'all_expected_archives_removed', 'before', 'after')}))


if __name__ == '__main__':
    if sys.argv[1] == 'inventory' and len(sys.argv) == 3:
        inventory(Path(sys.argv[2]))
    elif sys.argv[1] == 'cleanup' and len(sys.argv) == 4:
        cleanup(Path(sys.argv[2]), Path(sys.argv[3]))
    else:
        raise SystemExit('inventory OUTPUT | cleanup INVENTORY OUTPUT')
