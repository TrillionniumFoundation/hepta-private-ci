#!/usr/bin/env python3
"""Freeze successful original-memory gates without broadening their scope."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import stat
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('checkpoint_original_runner', HERE / 'run_original.py')
RUNNER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUNNER)
LOCK_SHA = '83651f11dea7f58dc96f3d119c120ab2bd8019e418979ab091ef49de7cceb9e8'
MANIFEST_SHA = 'cbe60bc2e7133b4a0011bef45d76007f1c507843e6e1f5ec58d4c7a5df6fbca0'


def digest_file(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while data := stream.read(1024 * 1024):
            value.update(data)
    return value.hexdigest()


def ref(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest_file(path)}


def main():
    destination = HERE / 'final-validation-identity.json'
    assert not destination.exists()
    manifest_path = RUNNER.ROOT / 'publication/manifest.json'
    assert digest_file(manifest_path) == MANIFEST_SHA
    manifest = RUNNER.frozen()
    overlay_path = HERE / 'overlay-identity.json'
    overlay = json.loads(overlay_path.read_text())
    verification = RUNNER.VERIFIER.verify(overlay['changes'])
    assert digest_file(RUNNER.SOURCE / 'codex-rs/Cargo.lock') == LOCK_SHA
    gates = []
    for name, expected_stage in [('checkpoint-memory-all-02', 'test'),
                                 ('checkpoint-fix-01', 'fix'),
                                 ('checkpoint-format-final-01', 'format-check')]:
        path = HERE / f'{name}.json'
        receipt = json.loads(path.read_text())
        assert receipt['stage'] == expected_stage
        assert receipt['exit_code'] == 0 and receipt['controlled_stop_reason'] is None
        assert receipt['source_verification_error'] is None
        assert receipt['source_and_test_gate_valid'] is True
        assert receipt['Cargo_lock_sha256_before'] == receipt['Cargo_lock_sha256_after'] == LOCK_SHA
        assert receipt['candidate_manifest_sha256'] == MANIFEST_SHA
        assert receipt['overlay_identity_sha256'] == digest_file(overlay_path)
        gates.append({'receipt': ref(path), 'command': receipt['command'],
                      'exit_code': 0, 'stdout': ref(HERE / f'{name}.stdout'),
                      'stderr': ref(HERE / f'{name}.stderr'),
                      'warning_summaries': receipt['warning_summaries'],
                      'nextest_summary_lines': receipt['nextest_summary_lines']})
    junit_path = HERE / 'checkpoint-memory-all-02.junit.xml'
    cases = list(ET.parse(junit_path).iter('testcase'))
    assert len(cases) == 327
    assert all(case.find('failure') is None and case.find('error') is None and case.find('skipped') is None for case in cases)
    new_tests = sorted(case.attrib['name'] for case in cases if '::checkpoint_current_' in case.attrib['name'])
    assert len(new_tests) == 5
    final_files = []
    for entry in manifest['files']:
        path = RUNNER.SOURCE / entry['path']
        data = path.read_bytes()
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o644
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
        assert RUNNER.VERIFIER.blob(data) == entry['git_blob']
        final_files.append({'path': entry['path'], 'mode': '100644',
                            'sha256': entry['sha256'], 'git_blob': entry['git_blob'], 'bytes': len(data)})
    expected = {path: entry['mode'] for path, entry in RUNNER.VERIFIER.BASE_BLOBS.items()}
    expected.update({entry['path']: entry['mode'] for entry in overlay['changes']})
    modes = []
    for name, mode in sorted(expected.items()):
        path = RUNNER.SOURCE / name
        info = path.lstat()
        actual = ('120000' if stat.S_ISLNK(info.st_mode) else
                  ('100755' if info.st_mode & 0o111 else '100644') if stat.S_ISREG(info.st_mode) else 'unsupported')
        assert mode == actual, (name, mode, actual)
        modes.append({'path': name, 'mode': actual})
    test_receipt = json.loads((HERE / 'checkpoint-memory-all-02.json').read_text())
    binaries = []
    for binary in test_receipt['original_memory_test_binaries']:
        path = Path(binary['path'])
        assert digest_file(path) == binary['sha256'] and path.stat().st_size == binary['bytes']
        binaries.append({**binary, 'mode': oct(stat.S_IMODE(path.stat().st_mode)), 'still_present_and_equal': True})
    result = {
        'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'script': ref(Path(__file__)), 'candidate_manifest': ref(manifest_path),
        'candidate_base_commit': manifest['base_commit'], 'candidate_base_tree': manifest['base_tree'],
        'source_identity_scope': overlay['source_identity_scope'],
        'original_9111_blob_manifest_sha256': overlay['base_blob_manifest_sha256'],
        'source_overlay_identity': ref(overlay_path), 'source_overlay_path_count': len(overlay['changes']),
        'final_full_source_verification': verification, 'mode_checked_file_count': len(modes),
        'full_mode_manifest_canonical_sha256': hashlib.sha256(json.dumps(modes, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        'final_candidate_files': final_files, 'Cargo_lock_sha256': LOCK_SHA,
        'gates': gates, 'junit': ref(junit_path),
        'memory_tests_run': 327, 'memory_tests_passed': 327,
        'memory_tests_failed': 0, 'original_tests_skipped_reported_by_nextest': 8,
        'new_checkpoint_tests_passed': new_tests,
        'original_memory_test_binaries': binaries,
        'original_full_lib_tests_ran_without_filter': True,
        'clippy_was_original_scoped_just_fix': True,
        'clippy_warnings_denied': False,
        'quality_gates_rewrote_source_or_lock': False,
        'Agentd_factory_Notes_bridge_tests_executed_here': False,
        'production_checkpoint_backend_implemented_or_qualified_here': False,
        'qualification_limits': [
            'Full original memory package on the recorded source overlay and original lock; not a complete Git 45f checkout of all historical evidence files.',
            'No Agentd/Notes/native UI/device end-to-end qualification follows from the memory package gate.',
            'Checkpoint test providers remain test-only; independently trusted latest-cut reads and a production durable publisher are still required.',
            'The public checkpoint covers one active-writer cut under the original lock, not all later mutations or terminal-lease retirement.',
            'Deadlines retain their documented cooperative bounded/nonblocking embedding assumptions.',
        ],
    }
    RUNNER.save(destination, result)
    print(json.dumps({'path': str(destination), 'bytes': destination.stat().st_size,
                      'sha256': digest_file(destination), 'memory_passed': 327,
                      'new_checkpoint_tests_passed': len(new_tests),
                      'candidate_files': len(final_files), 'source_overlay_paths': len(overlay['changes']),
                      'mode_checked_files': len(modes)}))


if __name__ == '__main__':
    main()
