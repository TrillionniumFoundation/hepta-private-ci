#!/usr/bin/env python3
"""Keep the verified private Windows crate available while moving its storage."""
from pathlib import Path
import importlib.util
import json
import os
import shutil
import stat

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('private_cache_inventory', ROOT / 'private_cache_inventory.py')
HELPER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(HELPER)
INVENTORY = ROOT / 'private-registry-outside-memory-inventory-01.json'
RECEIPT = ROOT / 'private-windows-source-relocation-01.json'
NAME = 'windows-0.58.0'
SOURCE = HELPER.REGISTRY / 'src/index.crates.io-1949cf8c6b5b557f' / NAME
DESTINATION = ROOT.parent / 'cache/registry-src/index.crates.io-1949cf8c6b5b557f' / NAME
BACKUP = SOURCE.with_name(NAME + '.task-relocation-preimage')
MIN_FREE = 256 * 1024**2


def files(root):
    result = []
    directories = []
    for directory, children, names in os.walk(root, followlinks=False):
        directory = Path(directory)
        for child in children:
            path = directory / child
            entry = path.lstat()
            assert stat.S_ISDIR(entry.st_mode) and not path.is_symlink(), path
            directories.append({'path': str(path.relative_to(root)), 'mode': oct(stat.S_IMODE(entry.st_mode))})
        for name in names:
            path = directory / name
            entry = path.lstat()
            assert stat.S_ISREG(entry.st_mode) and entry.st_nlink == 1, path
            result.append({
                'path': str(path.relative_to(root)), 'bytes': entry.st_size,
                'sha256': HELPER.digest(path), 'mode': oct(stat.S_IMODE(entry.st_mode)),
                'mtime_ns': entry.st_mtime_ns,
            })
    return {'files': sorted(result, key=lambda row: row['path']),
            'directories': sorted(directories, key=lambda row: row['path']),
            'root_mode': oct(stat.S_IMODE(root.stat().st_mode))}


def main():
    assert not RECEIPT.exists() and not DESTINATION.exists() and not BACKUP.exists()
    assert not HELPER.cargo_processes(), 'No task compilation during cache layout change'
    HELPER.assert_owned_directory(SOURCE)
    inventory = json.loads(INVENTORY.read_text())
    expected = next(row for row in inventory['directories'] if row['path'] == str(SOURCE))
    assert not expected['symlink_or_hardlink_paths']
    archive = Path(expected['archive_path'])
    assert HELPER.digest(archive) == expected['archive_sha256'] == expected['package']['checksum']
    assert HELPER.digest(HELPER.LOCK) == HELPER.EXPECTED_LOCK
    assert shutil.disk_usage(ROOT).free - expected['allocated_bytes'] >= MIN_FREE
    before = HELPER.resources()
    original = files(SOURCE)
    assert len(original['files']) == expected['file_count']
    assert sum(row['bytes'] for row in original['files']) == expected['bytes']
    # The complete per-file preimage is durable before the old storage is changed.
    preimage = ROOT / 'private-windows-source-preimage-01.json'
    HELPER.write_new(preimage, {'source': str(SOURCE), 'recorded_at': HELPER.now(), 'manifest': original})
    failure = None
    copied = False
    linked = False
    backup_removed = False
    try:
        DESTINATION.parent.mkdir(parents=True, exist_ok=True)
        assert DESTINATION.parent.resolve() == DESTINATION.parent
        shutil.copytree(SOURCE, DESTINATION, copy_function=shutil.copy2, symlinks=False)
        for entry in original['files']:
            with (DESTINATION / entry['path']).open('rb') as stream:
                os.fsync(stream.fileno())
        assert files(DESTINATION) == original, 'Copied cache must match every file byte, mode and mtime'
        assert files(SOURCE) == original, 'Original cache changed during copy'
        assert shutil.disk_usage(ROOT).free >= MIN_FREE
        assert not HELPER.cargo_processes()
        copied = True
        SOURCE.rename(BACKUP)
        try:
            SOURCE.symlink_to(DESTINATION, target_is_directory=True)
            assert SOURCE.is_symlink() and SOURCE.resolve() == DESTINATION
            assert files(SOURCE) == original
            linked = True
        except BaseException:
            if SOURCE.is_symlink():
                SOURCE.unlink()
            BACKUP.rename(SOURCE)
            raise
        # Destination and the original cache path are already verified complete.
        shutil.rmtree(BACKUP)
        backup_removed = True
    except BaseException as error:
        failure = repr(error)
        raise
    finally:
        result = {
            'recorded_at': HELPER.now(), 'script_sha256': HELPER.digest(Path(__file__)),
            'source_path': str(SOURCE), 'destination_path': str(DESTINATION),
            'inventory_path': str(INVENTORY), 'inventory_sha256': HELPER.digest(INVENTORY),
            'per_file_preimage_path': str(preimage), 'per_file_preimage_sha256': HELPER.digest(preimage),
            'archive_checksum': expected['archive_sha256'],
            'files': expected['file_count'], 'bytes': expected['bytes'],
            'manifest_canonical_sha256': HELPER.canonical(original),
            'copied_exact_bytes_modes_mtimes': copied, 'original_path_link_verified': linked,
            'verified_old_storage_removed': backup_removed,
            'remaining_backup_exists': BACKUP.exists(), 'failure': failure,
            'before': before, 'after': HELPER.resources(),
            'minimum_destination_free_bytes': MIN_FREE,
            'Cargo_lock_sha256_after': HELPER.digest(HELPER.LOCK),
            'scope': 'Private registry storage layout only. Original complete crate source stays accessible at the same cache path. No workspace source, index, Git, target, toolchain, lock, version, profile or test changed.',
        }
        HELPER.write_new(RECEIPT, result)
    print(json.dumps({key: result[key] for key in ('files', 'bytes', 'copied_exact_bytes_modes_mtimes', 'original_path_link_verified', 'verified_old_storage_removed', 'before', 'after')}))


if __name__ == '__main__':
    main()
