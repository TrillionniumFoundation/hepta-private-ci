#!/usr/bin/env python3
"""Relocate only inventoried original-lock archive bytes; retain cache paths."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import stat
import sys

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('private_cache_inventory', ROOT / 'private_cache_inventory.py')
HELPER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(HELPER)
DEST = ROOT.parent / 'cache/registry-archives'
MIN_DEST_FREE = 256 * 1024**2


def main(inventory_path, receipt_path):
    assert not receipt_path.exists()
    assert not DEST.exists(), 'Use a fresh private relocation destination'
    inventory = json.loads(inventory_path.read_text())
    assert inventory['script_sha256'] == HELPER.digest(ROOT / 'private_cache_inventory.py')
    assert inventory['lock_sha256'] == HELPER.digest(HELPER.LOCK) == HELPER.EXPECTED_LOCK
    assert not HELPER.cargo_processes(), 'No task Cargo processes may run during relocation'
    HELPER.assert_owned_directory(HELPER.CACHE)
    entries = [entry for entry in inventory['archives'] if entry['eligible']]
    available = shutil.disk_usage(ROOT).free
    needed = sum(entry['bytes'] for entry in entries)
    assert available - needed >= MIN_DEST_FREE, (available, needed)
    for entry in entries:
        source = Path(entry['path'])
        st = source.lstat()
        assert source.resolve() == source and source.is_relative_to(HELPER.CACHE)
        assert stat.S_ISREG(st.st_mode) and st.st_nlink == 1
        assert (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns) == (entry['device'], entry['inode'], entry['bytes'], entry['mtime_ns'])
        assert HELPER.digest(source) == entry['sha256'] == entry['package']['checksum']
    before = HELPER.resources()
    moved = []
    failure = None
    DEST.mkdir(parents=True)
    assert DEST.resolve() == DEST
    try:
        for entry in entries:
            source = Path(entry['path'])
            destination = DEST / source.relative_to(HELPER.CACHE)
            destination.parent.mkdir(parents=True, exist_ok=True)
            assert not destination.exists()
            assert shutil.disk_usage(ROOT).free - entry['bytes'] >= MIN_DEST_FREE
            with source.open('rb') as origin, destination.open('xb') as target:
                shutil.copyfileobj(origin, target, length=1024 * 1024)
                target.flush()
                os.fsync(target.fileno())
            os.chmod(destination, int(entry['mode'], 8))
            os.utime(destination, ns=(source.stat().st_atime_ns, entry['mtime_ns']))
            assert destination.stat().st_nlink == 1
            assert HELPER.digest(destination) == entry['sha256']
            assert destination.stat().st_size == entry['bytes']
            assert HELPER.digest(source) == entry['sha256']
            temporary = source.with_name(source.name + '.task-relocation-link')
            assert not temporary.exists() and not temporary.is_symlink()
            temporary.symlink_to(destination)
            # Replacing the original is the final action, after a verified durable copy.
            os.replace(temporary, source)
            assert source.is_symlink() and source.resolve() == destination
            assert HELPER.digest(source) == entry['sha256']
            moved.append({
                'original_path': str(source), 'destination': str(destination),
                'bytes': entry['bytes'], 'sha256': entry['sha256'],
                'Cargo_lock_checksum': entry['package']['checksum'],
                'source_archive_member_manifest_sha256': entry['archive_source_comparison_manifest_sha256'],
                'destination_device': destination.stat().st_dev,
                'destination_mode': oct(stat.S_IMODE(destination.stat().st_mode)),
                'original_path_retained_as_symlink': True,
            })
    except BaseException as error:
        failure = repr(error)
        raise
    finally:
        receipt = {
            'recorded_at': HELPER.now(), 'script_sha256': HELPER.digest(Path(__file__)),
            'inventory_path': str(inventory_path), 'inventory_sha256': HELPER.digest(inventory_path),
            'destination_root': str(DEST), 'minimum_destination_free_bytes': MIN_DEST_FREE,
            'before': before, 'after': HELPER.resources(),
            'failure': failure, 'moved': moved,
            'moved_count': len(moved), 'moved_bytes': sum(row['bytes'] for row in moved),
            'all_expected_moved': len(moved) == len(entries) and failure is None,
            'Cargo_lock_sha256_after': HELPER.digest(HELPER.LOCK),
            'source_index_git_target_and_toolchain_changed': False,
            'scope': 'Private compressed archive storage relocation only. All archive bytes retained and verified; original paths remain usable symlinks. No product source, dependency version, Cargo lock, profile or test change.',
        }
        HELPER.write_new(receipt_path, receipt)
    print(json.dumps({key: receipt[key] for key in ('moved_count', 'moved_bytes', 'all_expected_moved', 'before', 'after')}))


if __name__ == '__main__':
    assert len(sys.argv) == 3
    main(Path(sys.argv[1]), Path(sys.argv[2]))
