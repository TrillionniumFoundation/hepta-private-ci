#!/usr/bin/env python3
"""Run the original workspace gates on an explicitly recorded checkpoint delta."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "validation"
WORK = ROOT.parent
TASK = Path("/dev/shm/organ-3d6a75235bcb-hepta3398")
SOURCE = TASK / "source"
TARGET = TASK / "target"
TOOLCHAIN = Path("/dev/shm/organ-3d6a75235bcb-objective-tests/rustup-home/toolchains/1.95.0-x86_64-unknown-linux-gnu")
RESTORE = WORK / "checkpoint-current-validation/validation/official-rust195-restore-v1.json"
SPEC = importlib.util.spec_from_file_location("original_owner_overlay", WORK / "objective-owner/validation/owner_overlay.py")
VERIFIER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFIER)
MIN_MEMORY = 1536 * 1024**2
MIN_SHM = 256 * 1024**2


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    with path.open("x") as handle:
        json.dump(value, handle, indent=2)
        handle.write("\n")


def frozen():
    path = ROOT / "publication/manifest-v2.json"
    manifest = json.loads(path.read_text())
    for entry in manifest["files"]:
        data = (ROOT / "change" / entry["path"]).read_bytes()
        assert sha(data) == entry["sha256"]
        assert VERIFIER.blob(data) == entry["git_blob"]
        assert len(data) == entry["bytes"]
    return manifest


def row_for(name, data):
    base = VERIFIER.BASE_BLOBS.get(name)
    return {
        "path": name,
        "preimage_git_blob": base["sha"] if base else None,
        "preimage_sha256": None,
        "candidate_git_blob": VERIFIER.blob(data),
        "candidate_sha256": sha(data),
        "mode": base["mode"] if base else "100644",
        "bytes": len(data),
    }


def apply():
    destination = OUT / "overlay-identity-v2.json"
    assert not destination.exists(), "Never overwrite an overlay identity"
    manifest = frozen()
    old_path = WORK / "owner-recovery-ack/validation/overlay-identity.json"
    old = json.loads(old_path.read_text())
    rows = {row["path"]: row.copy() for row in old["changes"]}
    before = VERIFIER.verify(list(rows.values()))
    lock = SOURCE / "codex-rs/Cargo.lock"
    lock_before = sha(lock.read_bytes())
    sync = {
        "codex-rs/hepta-memory/OBJECTIVE_SENDER.md": ROOT / "base/codex-rs/hepta-memory/OBJECTIVE_SENDER.md",
        "codex-rs/hepta-agentd/src/objective_sender_host_tests.rs": ROOT / "base/codex-rs/hepta-agentd/src/objective_sender_host_tests.rs",
        "codex-rs/hepta-agentd/src/objective_runtime.rs": WORK / "agentd-bridge-fix/change/codex-rs/hepta-agentd/src/objective_runtime.rs",
    }
    transitions = []
    # Preserve all three actual prior overlay bytes before bringing them to 45f.
    for name, origin in sync.items():
        current = (SOURCE / name).read_bytes()
        backup = OUT / "initial-overlay-preimages" / name
        backup.parent.mkdir(parents=True, exist_ok=True)
        backup.write_bytes(current)
        data = origin.read_bytes()
        transitions.append({"path": name, "before_git_blob": VERIFIER.blob(current),
                            "before_sha256": sha(current), "after_git_blob": VERIFIER.blob(data),
                            "after_sha256": sha(data), "origin": str(origin)})
        (SOURCE / name).write_bytes(data)
        (SOURCE / name).chmod(0o644)
        replacement = row_for(name, data)
        if name in rows:
            replacement["preimage_sha256"] = rows[name]["preimage_sha256"]
        elif name in VERIFIER.BASE_BLOBS:
            assert VERIFIER.blob(current) == VERIFIER.BASE_BLOBS[name]["sha"]
            replacement["preimage_sha256"] = sha(current)
        rows[name] = replacement
    at_45f_sources = VERIFIER.verify(list(rows.values()))
    for entry in manifest["files"]:
        data = (SOURCE / entry["path"]).read_bytes()
        assert sha(data) == entry["preimage_sha256"], entry["path"]
        assert VERIFIER.blob(data) == entry["preimage_git_blob"], entry["path"]
    exact_preimages = [dict(path=row["path"], git_blob=row["preimage_git_blob"],
                           sha256=row["preimage_sha256"]) for row in manifest["files"]]
    for entry in manifest["files"]:
        name = entry["path"]
        data = (ROOT / "change" / name).read_bytes()
        replacement = row_for(name, data)
        replacement["preimage_sha256"] = (rows[name]["preimage_sha256"] if name in rows
                                             else entry["preimage_sha256"])
        rows[name] = replacement
        (SOURCE / name).write_bytes(data)
        (SOURCE / name).chmod(0o644)
    changes = [rows[name] for name in sorted(rows)]
    after = VERIFIER.verify(changes)
    assert sha(lock.read_bytes()) == lock_before
    record = {
        "at": now(), "original_base_head": VERIFIER.BASELINE["head"],
        "original_base_tree": VERIFIER.BASELINE["tree"],
        "base_blob_manifest_sha256": sha((WORK / "objective-owner/validation/base-blob-manifest.json").read_bytes()),
        "prior_overlay_identity_sha256": sha(old_path.read_bytes()),
        "candidate_base_commit": manifest["base_commit"], "candidate_base_tree": manifest["base_tree"],
        "candidate_manifest_sha256": sha((ROOT / "publication/manifest-v2.json").read_bytes()),
        "source_identity_scope": "Original full 9111-blob workspace plus recorded source overlays; not a complete Git checkout of 45f and its historical evidence files",
        "initial_19_overlay_verification": before,
        "three_path_45f_source_sync": transitions,
        "source_verification_after_sync": at_45f_sources,
        "ten_exact_45f_preimages": exact_preimages,
        "changes": changes, "source_verification_after_candidate": after,
        "Cargo_lock_sha256": lock_before,
        "rust195_restore_receipt": str(RESTORE), "rust195_restore_receipt_sha256": sha(RESTORE.read_bytes()),
    }
    save(destination, record)
    print(json.dumps({"operation": "apply", "changes": len(changes), "verification": after}), flush=True)


def resources():
    memory = next(int(line.split()[1]) * 1024 for line in Path("/proc/meminfo").read_text().splitlines()
                  if line.startswith("MemAvailable:"))
    size = int(subprocess.check_output(["du", "-sb", str(TARGET)], text=True).split()[0])
    return {"at": now(), "memory_available_bytes": memory,
            "shm_available_bytes": shutil.disk_usage(TASK).free,
            "target_apparent_bytes": size}


def group_members(group):
    result = []
    for path in Path("/proc").glob("[0-9]*/stat"):
        try:
            value = path.read_text()
            fields = value[value.rfind(")") + 2:].split()
            if int(fields[2]) == group and fields[0] != "Z":
                result.append(int(path.parent.name))
        except (OSError, ValueError, IndexError):
            continue
    return result


def quiesce(process):
    """Only the process group created for this runner's direct child is owned."""
    previous = {sig: signal.signal(sig, signal.SIG_IGN) for sig in (signal.SIGINT, signal.SIGTERM)}
    record = {"group": process.pid, "members_before": group_members(process.pid)}
    try:
        if process.poll() is None or record["members_before"]:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            until = time.monotonic() + 10
            while group_members(process.pid) and time.monotonic() < until:
                time.sleep(0.1)
            if group_members(process.pid):
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        process.wait(timeout=10)
        record["members_after"] = group_members(process.pid)
        assert not record["members_after"], "Owned command group did not quiesce"
        return record
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)


def run(stage, name):
    assert re.fullmatch(r"[a-z0-9-]+", name)
    prefix = OUT / name
    for ext in ("json", "stdout", "stderr", "junit.xml"):
        assert not prefix.with_suffix("." + ext).exists(), "Never overwrite a gate receipt"
    manifest = frozen()
    identity_path = OUT / "overlay-identity-v2.json"
    identity = json.loads(identity_path.read_text())
    assert sha((ROOT / "publication/manifest-v2.json").read_bytes()) == identity["candidate_manifest_sha256"]
    rows = identity["changes"]
    before = VERIFIER.verify(rows)
    commands = {
        "test": ["just", "test", "--locked", "--cargo-profile", "dev-small", "--build-jobs", "1",
                 "--test-threads", "1", "-p", "codex-hepta-memory", "--lib"],
        "format-check": ["just", "fmt", "--check"],
        "fix": ["just", "fix", "-p", "codex-hepta-memory", "--locked", "--profile", "dev-small", "--lib"],
    }
    command = commands[stage]
    env = os.environ.copy()
    overrides = {
        "PATH": f"{TOOLCHAIN / 'bin'}:/tmp/hepta-native-cargo/bin:/tmp/hepta-output-portfolio-env/bin:/usr/local/bin:/usr/bin:/bin",
        "RUSTUP_HOME": str(TOOLCHAIN.parents[1]), "RUSTUP_TOOLCHAIN": "1.95.0", "RUSTUP_AUTO_INSTALL": "0",
        "CARGO_HOME": str(TASK / "cargo-home"), "CARGO_TARGET_DIR": str(TARGET), "TMPDIR": str(TASK / "tmp"),
        "CARGO_INCREMENTAL": "0", "CARGO_BUILD_JOBS": "1", "CARGO_HTTP_TIMEOUT": "30", "CARGO_NET_RETRY": "1",
        "OPENSSL_LIB_DIR": "/usr/lib/x86_64-linux-gnu", "OPENSSL_INCLUDE_DIR": "/usr/include",
    }
    if stage == "fix":
        overrides.update(GIT_DIR=str(WORK / "objective-owner/validation/format-baseline.git"),
                         GIT_WORK_TREE=str(SOURCE))
        for row in rows:
            backup = OUT / "quality-preimages" / name / row["path"]
            backup.parent.mkdir(parents=True, exist_ok=True)
            backup.write_bytes((SOURCE / row["path"]).read_bytes())
    env.update(overrides)
    restored = json.loads(RESTORE.read_text())
    tool_hashes = {binary: sha((TOOLCHAIN / "bin" / binary).read_bytes())
                   for binary in restored["expected_binary_sha256"]}
    assert tool_hashes == restored["expected_binary_sha256"], "Wrong original 1.95 binaries"
    tools = {}
    for argv in (["rustc", "-Vv"], ["cargo", "-Vv"], ["cargo", "nextest", "--version"], ["just", "--version"]):
        result = subprocess.run(argv, env=env, capture_output=True, text=True)
        tools[" ".join(argv)] = {"exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
        assert result.returncode == 0, argv
    lock = SOURCE / "codex-rs/Cargo.lock"
    lock_before = sha(lock.read_bytes())
    assert lock_before == identity["Cargo_lock_sha256"]
    measurements = [resources()]
    assert measurements[0]["memory_available_bytes"] >= MIN_MEMORY
    assert measurements[0]["shm_available_bytes"] >= MIN_SHM
    junit = SOURCE / "codex-rs/target/nextest/local/junit.xml"
    junit_before = sha(junit.read_bytes()) if junit.exists() else None
    started = now()
    controlled = None
    exception = None
    process = None
    cleanup = None
    code = None
    with prefix.with_suffix(".stdout").open("x") as stdout, prefix.with_suffix(".stderr").open("x") as stderr:
        try:
            process = subprocess.Popen(command, cwd=SOURCE, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            print(json.dumps({"stage": stage, "command": command, "pid": process.pid,
                              "initial_resources": measurements[0]}), flush=True)
            last = time.monotonic()
            while process.poll() is None:
                time.sleep(1)
                if time.monotonic() - last < 10:
                    continue
                last = time.monotonic()
                sample = resources()
                measurements.append(sample)
                print(json.dumps(sample), flush=True)
                if sample["memory_available_bytes"] < MIN_MEMORY:
                    controlled = "MemAvailable fell below the unchanged 1.5 GiB guard."
                elif sample["shm_available_bytes"] < MIN_SHM:
                    controlled = "Shared /dev/shm free space fell below the unchanged 256 MiB guard."
                if controlled:
                    break
        except BaseException as error:
            exception = repr(error)
        finally:
            if process is not None:
                cleanup = quiesce(process)
                code = process.returncode
    verification_error = None
    try:
        after = VERIFIER.verify(rows)
    except Exception as error:
        after = None
        verification_error = repr(error)
    receipt = {
        "stage": stage, "started_at": started, "finished_at": now(), "command": command, "cwd": str(SOURCE),
        "environment_overrides": overrides, "tool_versions": tools, "tool_binary_sha256": tool_hashes,
        "rust195_restore_receipt_sha256": sha(RESTORE.read_bytes()),
        "candidate_manifest_sha256": sha((ROOT / "publication/manifest-v2.json").read_bytes()),
        "overlay_identity_sha256": sha(identity_path.read_bytes()),
        "source_identity_scope": identity["source_identity_scope"], "source_changes": rows,
        "source_verification_before": before, "source_verification_after": after,
        "source_verification_error": verification_error,
        "Cargo_lock_sha256_before": lock_before, "Cargo_lock_sha256_after": sha(lock.read_bytes()),
        "exit_code": code, "controlled_stop_reason": controlled, "runner_exception": exception,
        "owned_group_cleanup": cleanup, "resources": measurements + [resources()],
    }
    if stage == "test" and junit.exists():
        data = junit.read_bytes()
        receipt["junit_updated"] = sha(data) != junit_before
        if receipt["junit_updated"]:
            prefix.with_suffix(".junit.xml").write_bytes(data)
            tree = ET.fromstring(data)
            cases = tree.findall(".//testcase")
            present = {c.attrib["name"] for c in cases if c.find("failure") is None
                       and c.find("error") is None and c.find("skipped") is None}
            required = json.loads((OUT / "ci-sentinels.json").read_text())["required_added_tests"]
            required = [name for name in required if name.startswith("production_writer::")]
            receipt["junit"] = {"sha256": sha(data), "attributes": tree.attrib, "testcase_count": len(cases),
                                "missing_new_memory_tests": sorted(set(required) - present)}
        binaries = []
        for binary in sorted((TARGET / "dev-small/deps").glob("codex_hepta_memory-*")):
            if binary.is_file() and os.access(binary, os.X_OK):
                data = binary.read_bytes()
                binaries.append({"path": str(binary), "bytes": len(data), "sha256": sha(data)})
        receipt["original_memory_test_binaries"] = binaries
    for ext in ("stdout", "stderr"):
        path = prefix.with_suffix("." + ext)
        receipt[ext + "_file"] = path.name
        receipt[ext + "_sha256"] = sha(path.read_bytes())
    text = prefix.with_suffix(".stderr").read_text()
    receipt["warning_summaries"] = re.findall(r"^warning: `[^\n]+generated[^\n]+", text, re.MULTILINE)
    receipt["nextest_summary_lines"] = [line for line in text.splitlines() if "Summary [" in line]
    test_valid = True
    if stage == "test" and code == 0 and not controlled:
        result = receipt.get("junit", {})
        test_valid = (receipt.get("junit_updated", False) and result.get("testcase_count") == 327
                      and not result.get("missing_new_memory_tests")
                      and result.get("attributes", {}).get("failures") == "0"
                      and result.get("attributes", {}).get("errors") == "0")
    receipt["source_and_test_gate_valid"] = (code == 0 and not controlled and not exception
        and not verification_error and lock_before == receipt["Cargo_lock_sha256_after"] and test_valid)
    save(prefix.with_suffix(".json"), receipt)
    print(json.dumps({"receipt": str(prefix.with_suffix('.json')), "exit_code": code,
                      "controlled_stop_reason": controlled, "source_verification_error": verification_error,
                      "source_and_test_gate_valid": receipt["source_and_test_gate_valid"],
                      "stderr_tail": text[-2500:]}), flush=True)
    if controlled:
        return 130
    if exception or verification_error or lock_before != receipt["Cargo_lock_sha256_after"] or not test_valid:
        return 3
    return code if code is not None and code >= 0 else 1


if __name__ == "__main__":
    def interrupted(signum, _frame):
        raise InterruptedError(f"runner received signal {signum}")

    signal.signal(signal.SIGTERM, interrupted)
    if sys.argv[1] == "apply":
        apply()
    else:
        raise SystemExit(run(sys.argv[1], sys.argv[2]))
