#!/usr/bin/env python3
"""Freeze and overlay the authorized test-only centralized SQLite correction."""
from pathlib import Path
import copy
import datetime
import difflib
import hashlib
import importlib.util
import json
import re
import subprocess

ROOT = Path('/workspace/scratch/3d6a75235bcb/work/checkpoint-current')
HERE = Path(__file__).resolve().parent
NAME = 'codex-rs/hepta-memory/src/objective_sender_tests.rs'
OLD_MANIFEST_SHA = 'cbe60bc2e7133b4a0011bef45d76007f1c507843e6e1f5ec58d4c7a5df6fbca0'
FORMAT_SHA = '56b31ad3ec8fe0277a2884a189e243b8f04e9b48e5fd22e547c1516c5f8fd34c'
SPEC = importlib.util.spec_from_file_location('old_checkpoint_runner', ROOT / 'validation/run_original.py')
RUNNER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUNNER)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    old_manifest_path = ROOT / 'publication/manifest.json'
    assert sha(old_manifest_path.read_bytes()) == OLD_MANIFEST_SHA
    old = json.loads(old_manifest_path.read_text())
    old_identity_path = ROOT / 'validation/overlay-identity.json'
    identity = json.loads(old_identity_path.read_text())
    source_before = RUNNER.VERIFIER.verify(identity['changes'])
    old_entry = next(row for row in old['files'] if row['path'] == NAME)
    previous = (HERE / 'preimage' / NAME).read_bytes()
    assert sha(previous) == old_entry['sha256']
    assert (RUNNER.SOURCE / NAME).read_bytes() == previous
    for row in old['files']:
        if row['path'] != NAME:
            assert sha((ROOT / 'change' / row['path']).read_bytes()) == row['sha256']
    candidate = ROOT / 'change' / NAME
    unformatted = candidate.read_bytes()
    (HERE / 'before-rustfmt.rs').write_bytes(unformatted)
    formatter = RUNNER.TOOLCHAIN / 'bin/rustfmt'
    config = Path('/dev/shm/organ-3d6a75235bcb-hepta3398/cargo-home/git/checkouts/hepta-private-ci-4e02da04eb01edbd/db91f9e/codex-rs/rustfmt.toml')
    assert sha(formatter.read_bytes()) == FORMAT_SHA
    command = [str(formatter), '--emit', 'stdout', '--config-path', str(config), '--config', 'skip_children=true']
    result = subprocess.run(command, input=unformatted, capture_output=True, check=False)
    (HERE / 'rustfmt.stdout').write_bytes(result.stdout)
    (HERE / 'rustfmt.stderr').write_bytes(result.stderr)
    save(HERE / 'rustfmt.json', {'command': command, 'exit_code': result.returncode,
        'tool_sha256': FORMAT_SHA, 'config_sha256': sha(config.read_bytes()),
        'before_sha256': sha(unformatted), 'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})
    assert result.returncode == 0
    candidate.write_bytes(result.stdout)
    current = candidate.read_bytes()
    test_names = lambda data: re.findall(r'#\[tokio::test\]\s*async fn (\w+)\(', data.decode())
    assert test_names(current) == test_names(previous)
    assert previous.count(b'SqliteConnection::connect_with(&options)') == 3
    assert b'SqliteConnection::connect_with' not in current and b'clippy::' not in current
    assert current.count(b'independent_writer_connection(&fixture.store).await') == 3
    # All three original BUSY=5 and transaction probes remain byte-identical.
    for token in [b'sqlx::query("BEGIN IMMEDIATE")', b'sqlx::query("ROLLBACK")',
                  b'Some("5")', b'fixture.checkpoint.release.notify_one()']:
        assert current.count(token) == previous.count(token), token
    manifest = copy.deepcopy(old)
    manifest['captured_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    manifest['previous_candidate_manifest_sha256'] = OLD_MANIFEST_SHA
    manifest['revision'] = 'Use the original codex-state SQLite shim for three independent test-only writer probes; no runtime or assertion changes.'
    manifest['rustfmt_receipt'] = 'revisions/sqlite-shim/rustfmt.json'
    manifest['original_package_execution'] = 'Pending on these revised bytes; previous 327-pass and quality receipts are retained for the preceding candidate only.'
    entry = next(row for row in manifest['files'] if row['path'] == NAME)
    entry.update(bytes=len(current), sha256=sha(current), git_blob=RUNNER.VERIFIER.blob(current))
    new_manifest_path = ROOT / 'publication/manifest-v2.json'
    save(new_manifest_path, manifest)
    patch = ''
    for row in manifest['files']:
        name = row['path']
        base = (ROOT / 'base' / name).read_bytes()
        final = (ROOT / 'change' / name).read_bytes()
        assert sha(base) == row['preimage_sha256'] and RUNNER.VERIFIER.blob(base) == row['preimage_git_blob']
        assert sha(final) == row['sha256'] and RUNNER.VERIFIER.blob(final) == row['git_blob']
        patch += ''.join(difflib.unified_diff(base.decode().splitlines(True), final.decode().splitlines(True),
                                            fromfile='a/' + name, tofile='b/' + name))
    with (ROOT / 'publication/checkpoint-current-v2.patch').open('x') as stream:
        stream.write(patch)
    with (HERE / 'sqlite-shim-only.patch').open('x') as stream:
        stream.write(''.join(difflib.unified_diff(previous.decode().splitlines(True), current.decode().splitlines(True),
                                                fromfile='a/' + NAME, tofile='b/' + NAME)))
    (RUNNER.SOURCE / NAME).write_bytes(current)
    (RUNNER.SOURCE / NAME).chmod(0o644)
    revised_identity = copy.deepcopy(identity)
    revised_identity['at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    revised_identity['prior_candidate_overlay_sha256'] = sha(old_identity_path.read_bytes())
    revised_identity['candidate_manifest_sha256'] = sha(new_manifest_path.read_bytes())
    revised_identity['candidate_manifest_path'] = str(new_manifest_path)
    revised_identity['revision_changed_paths'] = [NAME]
    row = next(row for row in revised_identity['changes'] if row['path'] == NAME)
    row.update(bytes=len(current), candidate_sha256=sha(current), candidate_git_blob=RUNNER.VERIFIER.blob(current))
    after = RUNNER.VERIFIER.verify(revised_identity['changes'])
    revised_identity['source_verification_before_sqlite_revision'] = source_before
    revised_identity['source_verification_after_candidate'] = after
    new_identity = ROOT / 'validation/overlay-identity-v2.json'
    save(new_identity, revised_identity)
    original_runner = (ROOT / 'validation/run_original.py').read_text()
    revised_runner = original_runner.replace('publication/manifest.json', 'publication/manifest-v2.json').replace('"overlay-identity.json"', '"overlay-identity-v2.json"')
    assert revised_runner != original_runner
    with (ROOT / 'validation/run_original_v2.py').open('x') as stream:
        stream.write(revised_runner)
    finalizer = (ROOT / 'validation/freeze_validation.py').read_text()
    finalizer = (finalizer.replace('run_original.py', 'run_original_v2.py')
        .replace('publication/manifest.json', 'publication/manifest-v2.json')
        .replace(OLD_MANIFEST_SHA, sha(new_manifest_path.read_bytes()))
        .replace('overlay-identity.json', 'overlay-identity-v2.json')
        .replace('final-validation-identity.json', 'final-validation-identity-v2.json')
        .replace('checkpoint-memory-all-02', 'checkpoint-memory-all-03')
        .replace('checkpoint-fix-01', 'checkpoint-fix-02')
        .replace('checkpoint-format-final-01', 'checkpoint-format-final-02'))
    with (ROOT / 'validation/freeze_validation_v2.py').open('x') as stream:
        stream.write(finalizer)
    save(HERE / 'revision-identity.json', {
        'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'previous_candidate_manifest_sha256': OLD_MANIFEST_SHA,
        'candidate_manifest_path': str(new_manifest_path), 'candidate_manifest_sha256': sha(new_manifest_path.read_bytes()),
        'source_path': NAME, 'previous_sha256': sha(previous), 'final_sha256': sha(current),
        'final_git_blob': RUNNER.VERIFIER.blob(current), 'test_names_unchanged': test_names(current),
        'direct_SQLite_connection_calls_removed': 3, 'lint_allowances_added': False,
        'production_files_changed_by_this_revision': [],
        'overlay_identity_path': str(new_identity), 'overlay_identity_sha256': sha(new_identity.read_bytes()),
        'original_full_source_verification_before': source_before, 'original_full_source_verification_after': after,
        'source_and_lock_qualification': 'Not yet run for this revision; previous receipts are historical and preserved.',
        'original_runner_sha256': sha(original_runner.encode()), 'revised_runner_sha256': sha(revised_runner.encode()),
        'runner_changes': 'Only frozen manifest and overlay receipt paths changed; commands, guard, toolchain, source verification and tests gate unchanged.',
    })
    print(json.dumps({'manifest': str(new_manifest_path), 'manifest_sha256': sha(new_manifest_path.read_bytes()),
                      'revised_source_sha256': sha(current), 'overlay_changes': len(revised_identity['changes']),
                      'test_names_unchanged': len(test_names(current)), 'production_revision_changes': 0}))


if __name__ == '__main__':
    main()
