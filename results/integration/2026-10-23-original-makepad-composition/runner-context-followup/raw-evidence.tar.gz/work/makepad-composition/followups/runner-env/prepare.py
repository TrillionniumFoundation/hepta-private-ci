#!/usr/bin/env python3
"""Freeze a one-line workflow-context repair; never changes the published v3 input."""
from __future__ import annotations

import copy
import datetime as dt
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

import yaml

ROOT = Path(__file__).resolve().parent
COMPOSITION = ROOT.parents[1]
RELATIVE = ".github/workflows/ui-product-foundation.yml"
SOURCE_COMMIT = "bb3a82cc6c4c24fae5fe62d83ff723afb6326224"
EVIDENCE_HEAD = "a807c7bcc91158f3cc94de2c7ae0788680bdf104"
ALLOWED_JOB_ENV = {"github", "needs", "strategy", "matrix", "vars", "secrets", "inputs"}
ADDED = "          printf 'CARGO_TARGET_DIR=%s/native-presentation-target\\n' \"${RUNNER_TEMP:?}\" >> \"${GITHUB_ENV:?}\"\n"


def identity(raw: bytes) -> dict:
    return {
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "git_blob": hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest(),
    }


def save(name: str, value: object) -> None:
    (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def job_env_context_violations(doc: dict) -> list[str]:
    result = []
    for job_name, job in doc["jobs"].items():
        for key, value in job.get("env", {}).items():
            for expression in re.findall(r"\$\{\{(.*?)\}\}", value):
                for context in re.findall(r"(?<![\w.])([A-Za-z_][\w-]*)\s*\.", expression):
                    if context not in ALLOWED_JOB_ENV:
                        result.append(f"jobs.{job_name}.env.{key}: {context}")
    return result


def main() -> None:
    entries = json.loads((COMPOSITION / "publication/upstream-source-v3/source-entries.json").read_text())
    entry = next(item for item in entries if item["path"] == RELATIVE)
    old = entry["content"].encode()
    if identity(old)["git_blob"] != entry["candidate_git_blob"]:
        raise ValueError("frozen v3 preimage does not match its recorded Git blob")
    if old != (COMPOSITION / "change/hepta" / RELATIVE).read_bytes():
        raise ValueError("local frozen v3 source drift")
    old_text = old.decode()
    removed = "      CARGO_TARGET_DIR: ${{ runner.temp }}/native-presentation-target\n"
    needle = "      - name: Bind source before installing native inputs\n        run: |\n          set -euo pipefail\n"
    if old_text.count(removed) != 1 or old_text.count(needle) != 1:
        raise ValueError("repair must match exactly one original job and step")
    new_text = old_text.replace(removed, "").replace(needle, needle + ADDED)
    new = new_text.encode()
    before = yaml.load(old_text, Loader=yaml.BaseLoader)
    after = yaml.load(new_text, Loader=yaml.BaseLoader)
    old_violations = job_env_context_violations(before)
    new_violations = job_env_context_violations(after)
    if old_violations != ["jobs.native-presentation.env.CARGO_TARGET_DIR: runner"] or new_violations:
        raise ValueError("unexpected job-env context result")
    expected = copy.deepcopy(before)
    del expected["jobs"]["native-presentation"]["env"]["CARGO_TARGET_DIR"]
    first_run = next(step for step in expected["jobs"]["native-presentation"]["steps"] if "run" in step)
    insertion = ADDED.removeprefix("          ")
    first_run["run"] = first_run["run"].replace("set -euo pipefail\n", "set -euo pipefail\n" + insertion, 1)
    if expected != after:
        raise ValueError("workflow changed outside the two intended scalar values")
    for folder, raw in [("base", old), ("change", new)]:
        dest = ROOT / folder / RELATIVE
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(raw)
    patch = "".join(difflib.unified_diff(old_text.splitlines(keepends=True), new_text.splitlines(keepends=True), fromfile="a/" + RELATIVE, tofile="b/" + RELATIVE))
    (ROOT / "runner-env.patch").write_text(patch)
    commands = []

    def run(argv: list[str], cwd: Path, *, env: dict | None = None, input_text: str | None = None) -> subprocess.CompletedProcess:
        completed = subprocess.run(argv, cwd=cwd, env=env, input=input_text, text=True, capture_output=True)
        commands.append({"argv": argv, "cwd": str(cwd), "exit_code": completed.returncode, "stdout": completed.stdout, "stderr": completed.stderr})
        if completed.returncode:
            raise ValueError(f"validation command failed: {argv}")
        return completed

    with tempfile.TemporaryDirectory(prefix="workflow-context-", dir=ROOT) as temporary:
        fixture = Path(temporary)
        target = fixture / RELATIVE
        target.parent.mkdir(parents=True)
        target.write_bytes(old)
        run(["git", "init", "-q"], fixture)
        run(["git", "apply", "--check", str(ROOT / "runner-env.patch")], fixture)
        run(["git", "apply", str(ROOT / "runner-env.patch")], fixture)
        if target.read_bytes() != new:
            raise ValueError("applied patch differs from frozen candidate")
        steps = after["jobs"]["native-presentation"]["steps"]
        script = next(step["run"] for step in steps if "run" in step)
        run(["bash", "-n"], fixture, input_text=script)
        lock = fixture / "apps/hepta-control-ui/rust/Cargo.lock"
        lock.parent.mkdir(parents=True)
        shutil.copyfile(COMPOSITION / "base/hepta/apps/hepta-control-ui/rust/Cargo.lock", lock)
        run(["git", "add", "--all"], fixture)
        run(["git", "-c", "user.name=Workflow fixture", "-c", "user.email=fixture@invalid", "commit", "-qm", "Local source-binding fixture"], fixture)
        runner_temp = fixture / "runner temp with spaces"
        runner_temp.mkdir()
        env_file = fixture / "github environment"
        env = dict(os.environ, RUNNER_TEMP=str(runner_temp), GITHUB_ENV=str(env_file))
        run(["bash", "-euo", "pipefail", "-c", script], fixture, env=env)
        expected_env = f"CARGO_TARGET_DIR={runner_temp}/native-presentation-target\n"
        if env_file.read_text() != expected_env:
            raise ValueError("runner target environment value was not preserved")
        first_run_result = {"fixture_only": True, "full_first_run_exit": 0, "absolute_target_preserved_with_spaces": True, "environment_file": env_file.read_text(), "source_binding_outputs": sorted(p.name for p in (runner_temp / "native-presentation-evidence").iterdir())}
    old_id, new_id = identity(old), identity(new)
    save("commands.json", commands)
    save("preimages.json", [{"path": RELATIVE, "source_commit": SOURCE_COMMIT, "preimage": old_id}])
    save("source-entries.json", [{"path": RELATIVE, "mode": "100644", "type": "blob", "encoding": "utf-8", "content": new_text, "candidate_git_blob": new_id["git_blob"], "candidate_sha256": new_id["sha256"], "bytes": len(new), "preimage_git_blob": old_id["git_blob"], "preimage_sha256": old_id["sha256"]}])
    save("source-manifest.json", {"utc": dt.datetime.now(dt.timezone.utc).isoformat(), "repository": "TrillionniumFoundation/hepta-private-ci", "source_base": SOURCE_COMMIT, "publication_parent": EVIDENCE_HEAD, "scope": "Only move native-presentation CARGO_TARGET_DIR initialization from invalid job env context to the first runner shell step.", "files": [{"path": RELATIVE, "preimage": old_id, "candidate": new_id}], "original_lock_unchanged": identity((COMPOSITION / "base/hepta/apps/hepta-control-ui/rust/Cargo.lock").read_bytes()), "static_rule_source": "https://docs.github.com/en/actions/reference/workflows-and-actions/contexts#context-availability", "job_env_allowed_contexts": sorted(ALLOWED_JOB_ENV), "focused_original_violations": old_violations, "focused_candidate_violations": new_violations, "yaml_version": yaml.__version__, "all_other_yaml_fields_identical": True, "branch_filters": {k: v for k, v in after["on"]["pull_request"].items() if "branch" in k}, "workflow_path_matches": RELATIVE in after["on"]["pull_request"]["paths"], "first_run_fixture": first_run_result, "patch_check_and_apply": "passed; applied bytes match candidate", "actionlint": "not installed; not executed", "github_runner_execution": "not executed or observed by this local validation", "not_executed": ["Cargo metadata/lock generation", "Rust compilation", "Makepad rendering", "physical IME/AT/mobile qualification"], "patch": identity((ROOT / "runner-env.patch").read_bytes())})
    print(json.dumps({"status": "passed", "files": 1, "preimage": old_id, "candidate": new_id, "focused_original_violations": old_violations, "focused_candidate_violations": new_violations, "commands": len(commands)}, indent=2))


if __name__ == "__main__":
    main()
