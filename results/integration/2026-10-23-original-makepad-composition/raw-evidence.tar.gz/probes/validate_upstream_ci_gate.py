#!/usr/bin/env python3
"""Execute only the small Python gate tests and parse CI source, never Cargo."""

import ast
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import shlex
import subprocess
import sys
import tomllib

import yaml

ROOT = Path(__file__).resolve().parents[1]
CANDIDATE = ROOT / "change/hepta"
OUTPUT = ROOT / "validation/exact-junit-gate-v1"


def identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()}


def main():
    if OUTPUT.exists():
        raise SystemExit("refusing to overwrite an existing gate receipt")
    OUTPUT.mkdir(parents=True)
    paths = [
        ".github/workflows/ui-product-foundation.yml",
        "apps/hepta-control-ui/rust/.config/nextest.toml",
        "apps/hepta-control-ui/tools/check-native-composition-junit.py",
        "apps/hepta-control-ui/test/test_native_composition_junit.py",
        "apps/hepta-control-ui/rust/robrix-ui/NATIVE_COMPOSITION.md",
    ]
    before = {name: identity(CANDIDATE / name) for name in paths}
    rust_unchanged = []
    previous = json.loads((ROOT / "publication/upstream-source-v2/source-entries.json").read_text())
    for entry in previous:
        if entry["path"].endswith(".rs"):
            if identity(CANDIDATE / entry["path"])["sha256"] != entry["candidate_sha256"]:
                raise SystemExit("Rust source changed while adding only the CI gate")
            rust_unchanged.append(entry["path"])
    lock = CANDIDATE / "apps/hepta-control-ui/rust/Cargo.lock"
    if lock.read_bytes() != (ROOT / "base/hepta/apps/hepta-control-ui/rust/Cargo.lock").read_bytes():
        raise SystemExit("original lock changed")
    results = []
    for variant in ([], ["-O"]):
        command = [sys.executable, "-B", *variant,
                   str(CANDIDATE / "apps/hepta-control-ui/test/test_native_composition_junit.py")]
        completed = subprocess.run(command, capture_output=True, timeout=60)
        label = "optimized" if variant else "normal"
        (OUTPUT / (label + ".stdout")).write_bytes(completed.stdout)
        (OUTPUT / (label + ".stderr")).write_bytes(completed.stderr)
        results.append({"command": command, "exit": completed.returncode,
                        "stdout": identity(OUTPUT / (label + ".stdout")),
                        "stderr": identity(OUTPUT / (label + ".stderr"))})
        if completed.returncode or b"Ran 12 tests" not in completed.stderr or not completed.stderr.endswith(b"\nOK\n"):
            raise SystemExit("the synthetic gate regression suite did not pass")

    # Parsing only: the run blocks, installer, nextest and Rust commands are
    # never executed by this controller.
    document = yaml.load((CANDIDATE / paths[0]).read_text(), Loader=yaml.BaseLoader)
    job = document["jobs"]["native-presentation"]
    shell_results = []
    for i, step in enumerate(job["steps"]):
        if "run" not in step:
            continue
        path = OUTPUT / f"step-{i:02d}.bash"
        path.write_text(step["run"])
        done = subprocess.run(["bash", "-n", str(path)], capture_output=True, timeout=10)
        shell_results.append({"script": path.name, "exit": done.returncode, **identity(path)})
        if done.returncode:
            raise SystemExit("native CI shell block did not parse")
    module_path = CANDIDATE / paths[2]
    spec = importlib.util.spec_from_file_location("native_gate", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    run = next(step["run"] for step in job["steps"] if step.get("name", "").startswith("Execute the explicitly"))
    commands = [shlex.split(line.split(" -- just ", 1)[1]) for line in run.splitlines() if " -- just " in line]
    if [["just", *c] for c in commands] != [module.command("headless"), module.command("native")]:
        raise SystemExit("workflow differs from the exact full-library commands")
    config = tomllib.loads((CANDIDATE / paths[1]).read_text())
    for mode in module.MODES:
        profile = config["profile"]["native-composition-" + mode]
        if profile != {"retries": 0, "fail-fast": False,
                       "junit": {"path": "junit.xml", "report-name": "hepta-native-composition-" + mode,
                                 "report-skipped": "all"}}:
            raise SystemExit("unexpected native test profile")
        prepare = run.index(f"{mode}-junit-start.json\" --junit")
        execute = run.index(f"--output \"$RUNNER_TEMP/native-presentation-evidence/{mode}.json\"")
        verify = run.index(f"--execution \"$RUNNER_TEMP/native-presentation-evidence/{mode}.json\"")
        if not prepare < execute < verify:
            raise SystemExit("fresh report preparation/verification order changed")
    for path in paths[2:4]:
        ast.parse((CANDIDATE / path).read_text(), filename=path)
    after = {name: identity(CANDIDATE / name) for name in paths}
    if before != after:
        raise SystemExit("candidate changed during the gate-only verification")
    result = {
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "scope": "Python synthetic XML/receipt tests plus YAML/TOML/Bash/Python source parsing only; no Rust, Cargo, nextest or renderer execution.",
        "python": sys.version,
        "source_before": before, "source_after": after,
        "rust_source_unchanged_since_v2": rust_unchanged,
        "original_ui_lock_unchanged": identity(lock),
        "python_test_runs": results,
        "python_tests_each": 12,
        "shell_parse": shell_results,
        "exact_workflow_commands_and_profiles": "matched",
        "coverage_gate": {mode: sorted(names) for mode, names in module.MODES.items()},
        "original_nextest_version": "0.9.146",
        "original_nextest_source_proof": "research/nextest-0146-junit/proof.json",
        "rust_test_execution": "not run; exact test coverage is a mandatory future CI gate",
        "status": "passed_for_the_stated_python_and_static_scope",
    }
    (OUTPUT / "receipt.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"python_tests_each": 12, "python_runs": len(results),
                      "shell_blocks_parsed": len(shell_results), "rust_sources_unchanged": len(rust_unchanged),
                      "receipt": str(OUTPUT / "receipt.json"), "Rust_executed": False}))


if __name__ == "__main__":
    main()
