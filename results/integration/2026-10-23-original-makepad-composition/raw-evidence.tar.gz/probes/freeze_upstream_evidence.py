#!/usr/bin/env python3
"""Freeze an explicit upstream-only archive allow-list; never traverse caches."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import stat

ROOT = Path('/workspace/scratch/3d6a75235bcb/work/makepad-composition')
OUTPUT = ROOT / 'publication/upstream-evidence-v1'
rows = []


def digest(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def add(path, archive_path, classification):
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f'expected regular evidence file: {path}')
    parts = Path(archive_path).parts
    if any(part in ('cache', 'target', 'patch-check', '__pycache__') for part in parts):
        raise RuntimeError('cache/build/temporary path is outside archive scope')
    if 'desktop' in parts:
        raise RuntimeError('unfinished Desktop source is outside upstream archive scope')
    rows.append({'local_path': str(path), 'archive_path': archive_path,
                 'classification': classification, 'mode': stat.S_IMODE(path.stat().st_mode),
                 **digest(path.read_bytes())})


def add_tree(path, archive_prefix, classification):
    for file in sorted(path.rglob('*')):
        if file.is_file() and '__pycache__' not in file.parts:
            add(file, str(Path(archive_prefix) / file.relative_to(path)), classification)


def write(name, value):
    with (OUTPUT / name).open('x', encoding='utf-8') as out:
        json.dump(value, out, indent=2, ensure_ascii=False)
        out.write('\n')


manifest = json.loads((ROOT / 'publication/upstream-source-v3/source-manifest.json').read_text())
for file in manifest['files']:
    actual = digest((ROOT / 'change/hepta' / file['path']).read_bytes())
    if (actual['sha256'], actual['git_blob'], actual['bytes']) != (
        file['candidate_sha256'], file['candidate_git_blob'], file['bytes']
    ):
        raise RuntimeError(f'frozen upstream source drift: {file["path"]}')
if len(manifest['files']) != 35:
    raise RuntimeError('unexpected final source count')

bases = json.loads((ROOT / 'BASES.json').read_text())
upstream_base = [file for file in bases['source_files'] if file['repository'] == 'hepta']
for file in upstream_base:
    actual = digest((ROOT / 'base/hepta' / file['path']).read_bytes())
    if any(actual[key] != file[key] for key in ('bytes', 'sha256', 'git_blob')):
        raise RuntimeError(f'original upstream source drift: {file["path"]}')
if len(upstream_base) != 212:
    raise RuntimeError('unexpected original input inventory')

readback = json.loads((ROOT.parent / 'makepad-composition-root-review/source-readback.json').read_text())
if (readback['source_commit'], readback['tree'], readback['complete_leaf_count'],
    readback['all_leaf_modes_and_blobs_match']) != (
    'bb3a82cc6c4c24fae5fe62d83ff723afb6326224',
    '9f45307ad3502328aee501e5c142388c541351b0', 9159, True
):
    raise RuntimeError('unexpected root publication proof')

summary = {
    'schema': 'hepta-original-app-composition-evidence.v1',
    'utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'repository': 'TrillionniumFoundation/hepta-private-ci',
    'base_commit': manifest['base_commit'], 'base_root_tree': manifest['base_root_tree'],
    'source_commit': readback['source_commit'], 'source_tree': readback['tree'],
    'source_files': 35, 'modified_preimages': 10, 'new_paths': 25,
    'original_input_files': len(upstream_base),
    'execution': {
        'python_gate': {'normal_passed': 12, 'optimized_passed': 12,
                        'independent_root_repeat_each': 12},
        'rustfmt': {'upstream_files': 13, 'toolchain': '1.95.0',
                    'scope': 'stdin syntax/format only; no compiler'},
        'workflow_parsing': {'bash_blocks_passed': 4, 'yaml': 'parsed', 'toml': 'parsed',
                             'python': 'parsed', 'command_profiles': 'exactly matched'},
        'final_patch': 'actual apply --check, apply and all 35 final bytes passed',
        'historical_patch_v1': 'real apply --check exit 128 preserved, corrected LF splitting in v2/v3',
        'remote_readback': 'root checked all 9159 leaf modes/blobs',
        'cargo': 'not run', 'rust_compilation': 'not run', 'rust_tests': 'not run',
        'nextest': 'not run', 'clippy': 'not run', 'renderer': 'not run',
    },
    'unchanged_source_boundaries': [
        'original Hepta UI Cargo.lock', 'Makepad SDK pin and source',
        'original core/presenter/ImeRouter/pointer gate/room/composer',
        'original NativeHost render before_event through EOF (14590 bytes)',
    ],
    'known_open_gates': [
        'real locked headless/native Rust package compilation and exact JUnit gates',
        'Desktop adapter and normal Cargo lock generation using the real source commit',
        'full original 29-asset/15-notice/Liberation-source resource bundle',
        'real window and actual font consumption/readable CJK pixels',
        'physical IME, selection/undo preservation, assistive technology',
        'Web/mobile/bare-metal and full three-slot workspace integration',
        'independent production Chat authority; RequestSend remains SendUnavailable',
    ],
    'archive_exclusions': [
        'unfinished Desktop source and Desktop rustfmt inputs/outputs',
        'all Cargo/Git cache files and cache-migration records',
        'temporary patch-check repositories and targets',
        'Agentd V8 side-review', 'font payloads and binaries',
    ],
    'mixed_receipts': 'Original combined rustfmt receipts remain unedited; only upstream raw records are included.',
}
write('final-summary.json', summary)

for name in ('README.md', 'PR_BODY.md', 'final-summary.json'):
    add(OUTPUT / name, name, 'summary')
add(ROOT / 'BASES.json', 'source-provenance/BASES.json', 'source-provenance')
add_tree(ROOT / 'base/hepta', 'original-hepta', 'original-source')
for version in ('v1', 'v2', 'v3'):
    directory = ROOT / f'publication/upstream-source-{version}'
    for path in sorted(directory.iterdir()):
        if path.is_file():
            add(path, f'source-stages/upstream-source-{version}/{path.name}', 'source-stage')
for name in ('freeze_upstream_source.py', 'validate_upstream_ci_gate.py', 'format_changed_sources.py',
             'format_changed_sources_v2.py', 'compose_original_app.py', 'freeze_upstream_evidence.py'):
    add(ROOT / 'probes' / name, 'probes/' + name, 'controller-source')
for name in ('hepta-base-tree.z', 'hepta_ci_exec.py', 'original-justfile', 'run-nextest.py'):
    add(ROOT / 'research' / name, 'research/' + name, 'original-tool-input')
for name in ('nextest-0146-junit', 'original-native-assets'):
    add_tree(ROOT / 'research' / name, 'research/' + name, 'original-tool-input')
add_tree(ROOT.parent / 'makepad-original-source', 'research/makepad-original-source', 'original-sdk-input')
for name in ('upstream-source-review-v1.json', 'makepad-build-input-review-v1.json'):
    add(ROOT / 'validation' / name, 'validation/' + name, 'source-review')
add_tree(ROOT / 'validation/exact-junit-gate-v1', 'validation/exact-junit-gate-v1', 'python-static-execution')
for version in ('v1', 'v2'):
    directory = ROOT / f'validation/rustfmt-{version}'
    add(directory / 'receipt.json', f'validation/rustfmt-{version}/receipt.json', 'rustfmt-execution')
    for path in sorted(directory.rglob('*')):
        if path.is_file() and 'hepta' in path.relative_to(directory).parts:
            add(path, f'validation/rustfmt-{version}/' + str(path.relative_to(directory)), 'upstream-rustfmt-raw')
add_tree(ROOT.parent / 'makepad-composition-root-review', 'root-review', 'independent-root-review')

names = [row['archive_path'] for row in rows]
if len(set(names)) != len(names):
    raise RuntimeError('duplicate archive member')
rows.sort(key=lambda row: row['archive_path'])
counts = {}
for row in rows:
    item = counts.setdefault(row['classification'], {'files': 0, 'bytes': 0})
    item['files'] += 1
    item['bytes'] += row['bytes']
write('archive-entries.json', rows)
write('inventory-summary.json', {
    'members': len(rows), 'raw_bytes': sum(row['bytes'] for row in rows),
    'archive_entries_sha256': digest((OUTPUT / 'archive-entries.json').read_bytes())['sha256'],
    'classifications': counts, 'source_verified_against_v3': 35,
    'original_inputs_verified_against_BASES': len(upstream_base),
    'contains_cache': False, 'contains_unfinished_desktop_source': False,
})
print(json.dumps({'members': len(rows), 'raw_bytes': sum(row['bytes'] for row in rows),
                  'inventory': str(OUTPUT / 'archive-entries.json')}, indent=2))
