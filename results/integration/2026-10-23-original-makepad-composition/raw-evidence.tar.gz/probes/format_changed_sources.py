#!/usr/bin/env python3
"""Format only this isolated, not-yet-frozen candidate through rustfmt stdin.

This is syntax/format evidence, not Cargo type checking or a renderer run.
"""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
PREVIOUS = ROOT.parent / 'checkpoint-current-validation/validation/official-rust195-restore-v1.json'
OUTPUT = ROOT / 'validation/rustfmt-v1'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if OUTPUT.exists():
        raise SystemExit('refusing to overwrite an existing format receipt')
    prior = json.loads(PREVIOUS.read_text())
    rustfmt = Path(prior['toolchain_directory']) / 'bin/rustfmt'
    version = subprocess.run([str(rustfmt), '--version'], capture_output=True, check=True)
    if version.stdout.strip() != b'rustfmt 1.9.0-stable (59807616e1 2026-04-14)':
        raise SystemExit('unexpected original compiler companion')
    OUTPUT.mkdir(parents=True)
    report = {
        'scope': 'stdin-only syntax/format check; no Cargo, rustc compilation, test or UI execution',
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'tool': str(rustfmt),
        'tool_sha256': sha(rustfmt.read_bytes()),
        'version': version.stdout.decode().strip(),
        'files': [],
        'status': 'started',
    }
    changed = []
    for repository, edition in (('hepta', '2024'), ('desktop', '2021')):
        for path in sorted((ROOT / 'change' / repository).rglob('*.rs')):
            relative = path.relative_to(ROOT / 'change')
            before = path.read_bytes()
            base = ROOT / 'base' / relative
            if base.exists() and base.read_bytes() == before:
                continue
            backup = OUTPUT / 'pre-format' / relative
            backup.parent.mkdir(parents=True, exist_ok=True)
            backup.write_bytes(before)
            command = [str(rustfmt), '--emit', 'stdout', '--edition', edition]
            result = subprocess.run(command, input=before, capture_output=True, timeout=30)
            stderr = OUTPUT / 'stderr' / relative.with_suffix('.txt')
            stderr.parent.mkdir(parents=True, exist_ok=True)
            stderr.write_bytes(result.stderr)
            report['files'].append({
                'path': str(relative), 'command': command, 'exit': result.returncode,
                'input_sha256': sha(before), 'input_bytes': len(before),
                'output_sha256': sha(result.stdout), 'output_bytes': len(result.stdout),
                'stderr_sha256': sha(result.stderr),
            })
            if result.returncode or result.stderr or not result.stdout:
                report['status'] = 'failed_without_applying_any_output'
                (OUTPUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
                return 1
            changed.append((path, before, result.stdout))
    for path, before, formatted in changed:
        if path.read_bytes() != before:
            raise SystemExit(f'candidate changed during stdin processing: {path}')
    for path, _, formatted in changed:
        path.write_bytes(formatted)
    report['status'] = 'formatted_syntax_only'
    report['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUTPUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'files': len(changed), 'receipt': str(OUTPUT / 'receipt.json')}))
    return 0


if __name__ == '__main__':
    sys.exit(main())
