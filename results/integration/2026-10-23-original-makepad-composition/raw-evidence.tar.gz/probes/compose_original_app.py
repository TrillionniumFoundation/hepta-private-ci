from pathlib import Path
root=Path('work/makepad-composition/change/hepta/apps/hepta-control-ui/rust/robrix-ui')
base=Path('work/makepad-composition/base/hepta/apps/hepta-control-ui/rust/robrix-ui')
p=root/'src/app.rs';s=base.joinpath('src/app.rs').read_text()
s=s.replace('use crate::ime_router::ImeRouter;','use crate::ime_router::ImeRouter;\nuse crate::chat_source::{ChatSource, ChatSourceSlot};\n#[cfg(feature = "native-presentation")]\nuse crate::native_presentation::render::RendererPresentation;')
s=s.replace('#[cfg(feature = "native-host")]\n    crate::native_host::render::configure(cx);\n    #[cfg(not(feature = "native-host"))]', '#[cfg(any(feature = "native-host", feature = "native-presentation"))]\n    crate::native_launch::configure(cx);\n    #[cfg(not(any(feature = "native-host", feature = "native-presentation")))]')
s=s.replace('    workspace: ChatWorkspace,','    chat_source: ChatSourceSlot,')
s=s.replace('    native_host: NativeRenderer,','    native_host: NativeRenderer,\n    #[cfg(feature = "native-presentation")]\n    #[rust]\n    native_presentation: RendererPresentation,')
a=s.index('impl ScriptHook for App {');b=s.index('    fn script_mod(vm:',a)
s=s[:a]+'''impl ScriptHook for App {}

fn standalone_workspace() -> ChatWorkspace {
    #[cfg(feature = "ui-fixtures")]
    {
        let mut workspace = hepta_control_core::chat::fixtures::owner_conversation_fixture();
        hepta_control_core::chat::fixtures::extend_scroll_fixture(&mut workspace);
        workspace
    }
    #[cfg(not(feature = "ui-fixtures"))]
    ChatWorkspace::default()
}

impl AppMain for App {
    fn after_new_from_script(vm: &mut ScriptVm, app: &mut Self) {
        #[cfg(not(any(feature = "native-host", feature = "native-presentation")))]
        let _ = &vm;
        assert!(app.chat_source.adopt_once(|| {
            #[cfg(any(feature = "native-host", feature = "native-presentation"))]
            if let Some(setup) = vm.with_cx_mut(crate::native_launch::take) {
                match setup.mode {
                    #[cfg(feature = "native-host")]
                    crate::native_launch::LaunchMode::OwnerHost(host) => {
                        vm.with_cx_mut(|cx| app.native_host.adopt(cx, host, setup.outcome));
                    }
                    #[cfg(feature = "native-presentation")]
                    crate::native_launch::LaunchMode::Presentation(composition) => {
                        vm.with_cx_mut(|cx| app.native_presentation.adopt(cx, setup.outcome));
                        return ChatSource::Embedded(composition);
                    }
                }
            }
            // Evaluated only for standalone/old owner-host mode, never as an
            // empty draft that would shadow a caller's existing composition.
            ChatSource::Standalone(standalone_workspace())
        }), "the original App adopts exactly one ChatSource");
    }
'''+s[b:]
a='''        crate::visual_theme::apply_tree(cx, &self.ui);
        self.ime_router
            .dispatch(cx, &self.ui, event, &mut self.workspace);'''
b='''        #[cfg(feature = "native-presentation")]
        if let Some(composition) = self.chat_source.composition_mut()
            && self.native_presentation.before_event(cx, &self.ui, event, composition)
        {
            return;
        }
        crate::visual_theme::apply_tree(cx, &self.ui);
        self.ime_router
            .dispatch(cx, &self.ui, event, self.chat_source.workspace_mut());
        #[cfg(feature = "native-presentation")]
        if let Some(composition) = self.chat_source.composition_mut() {
            self.native_presentation.after_event(cx, &self.ui, event, composition);
        }'''
assert a in s;s=s.replace(a,b)
s=s.replace('self.workspace.tab','self.chat_source.workspace().tab').replace('self.workspace.navigation_open','self.chat_source.workspace().navigation_open').replace('self.workspace.presentation_epoch()','self.chat_source.workspace().presentation_epoch()').replace('&self.workspace, &self.ui','self.chat_source.workspace(), &self.ui')
assert 'self.workspace' not in s
p.write_text(s)

p=root/'src/native_host/render.rs';s=base.joinpath('src/native_host/render.rs').read_text()
a=s.index('#[derive(Default)]\nstruct RunOutcome');b=s.index('#[derive(Default)]\npub(crate) struct RendererHost',a)
s=s[:a]+'''use crate::native_launch::{ConfigureResources, LaunchMode, RunOutcome};

/// A Linux development runner. The original owner/witness and close protocol
/// remains here; only event-loop admission is shared with presentation mode.
#[cfg(target_os = "linux")]
pub fn run_native(host: Box<dyn NativeHost>, resources: ConfigureResources) -> Result<(), String> {
    crate::native_launch::run(LaunchMode::OwnerHost(host), resources)
}

'''+s[b:]
a=s.index('    pub(crate) fn adopt(');b=s.index('    pub(crate) fn before_event(',a)
s=s[:a]+'''    pub(crate) fn adopt(
        &mut self,
        cx: &mut Cx,
        host: Box<dyn NativeHost>,
        outcome: Rc<RefCell<RunOutcome>>,
    ) {
        outcome.borrow_mut().adopted = true;
        self.host = Some(host);
        self.outcome = Some(outcome);
        // A completion signal can arrive just before JoinHandle becomes
        // finished. Keep the legacy 250 ms bounded nonblocking poll fallback.
        self.poll_timer = cx.start_interval(0.25);
    }

'''+s[b:]
p.write_text(s)
p=root/'build.rs';s=base.joinpath('build.rs').read_text().replace('|| std::env::var_os("CARGO_FEATURE_NATIVE_HOST").is_some()', '|| std::env::var_os("CARGO_FEATURE_NATIVE_HOST").is_some()\n        || std::env::var_os("CARGO_FEATURE_NATIVE_PRESENTATION").is_some()');p.write_text(s)
