#!/usr/bin/env python3
"""Freeze the first original-App source slice, without building or running it."""

import datetime
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "publication/upstream-source-v1"
BASE_SHA = "56630b12b8a4c69fff2c47b95b36d88a7389c39f"
BASE_TREE = "15ff893b92898185ea709e847b244e4d66ae2bf4"


def identity(data):
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob": hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest(),
    }


def main():
    if OUTPUT.exists():
        raise SystemExit("refusing to overwrite an existing upstream source freeze")
    provenance = json.loads((ROOT / "BASES.json").read_text())
    if provenance["hepta"] != {
        "commit": BASE_SHA,
        "tree": BASE_TREE,
        "reviewed_pr": 3067,
    }:
        raise SystemExit("unexpected original Hepta base")
    tree_bytes = (ROOT / "research/hepta-base-tree.z").read_bytes()
    tree = {}
    for record in tree_bytes.split(b"\0"):
        if not record:
            continue
        meta, name = record.split(b"\t", 1)
        mode, kind, blob = meta.decode().split()
        tree[name.decode()] = {"mode": mode, "type": kind, "git_blob": blob}
    if len(tree) != 9134:
        raise SystemExit("original full-tree inventory changed")

    preimages = []
    source_entries = []
    patch = []
    for path in sorted((ROOT / "change/hepta").rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT / "change/hepta").as_posix()
        base = ROOT / "base/hepta" / relative
        before = base.read_bytes() if base.exists() else None
        after = path.read_bytes()
        if before == after:
            continue
        if before is None:
            if relative in tree:
                raise SystemExit(f"new file already exists in original tree: {relative}")
            preimage = None
        else:
            preimage = identity(before)
            if tree.get(relative) != {
                "mode": "100644",
                "type": "blob",
                "git_blob": preimage["git_blob"],
            }:
                raise SystemExit(f"preimage is not the original Git blob: {relative}")
        candidate = identity(after)
        source_entries.append({
            "path": relative,
            "mode": "100644",
            "type": "blob",
            "encoding": "utf-8",
            "content": after.decode("utf-8"),
            "candidate_git_blob": candidate["git_blob"],
            "candidate_sha256": candidate["sha256"],
            "bytes": len(after),
            "preimage_git_blob": preimage["git_blob"] if preimage else None,
            "preimage_sha256": preimage["sha256"] if preimage else None,
        })
        preimages.append({"path": relative, "preimage": preimage})
        patch.append(f"diff --git a/{relative} b/{relative}\n")
        if before is None:
            patch.append("new file mode 100644\n")
            patch.append(f"index {'0' * 40}..{candidate['git_blob']}\n")
        else:
            patch.append(f"index {preimage['git_blob']}..{candidate['git_blob']} 100644\n")
        patch.extend(difflib.unified_diff(
            (before or b"").decode("utf-8").splitlines(True),
            after.decode("utf-8").splitlines(True),
            fromfile=f"a/{relative}" if before is not None else "/dev/null",
            tofile=f"b/{relative}",
        ))

    if len(source_entries) != 32:
        raise SystemExit(f"unexpected upstream source count: {len(source_entries)}")
    # Deleted original files must not silently disappear from the patch.
    for base in (ROOT / "base/hepta").rglob("*"):
        if base.is_file() and not (ROOT / "change/hepta" / base.relative_to(ROOT / "base/hepta")).is_file():
            raise SystemExit(f"unrepresented deletion: {base}")
    lock = "apps/hepta-control-ui/rust/Cargo.lock"
    if (ROOT / "base/hepta" / lock).read_bytes() != (ROOT / "change/hepta" / lock).read_bytes():
        raise SystemExit("original UI Cargo.lock must remain unchanged in the API slice")

    OUTPUT.mkdir(parents=True)
    patch_path = OUTPUT / "original-app-composition.patch"
    patch_path.write_text("".join(patch))
    (OUTPUT / "source-entries.json").write_text(json.dumps(source_entries, indent=2) + "\n")
    (OUTPUT / "preimages.json").write_text(json.dumps(preimages, indent=2) + "\n")

    checkout = OUTPUT / "patch-check"
    checkout.mkdir()
    commands = []

    def run(arguments):
        result = subprocess.run(arguments, cwd=checkout, capture_output=True, text=True)
        commands.append({"argv": arguments, "cwd": str(checkout), "exit": result.returncode,
                         "stdout": result.stdout, "stderr": result.stderr})
        (OUTPUT / "patch-apply-commands.json").write_text(json.dumps(commands, indent=2) + "\n")
        if result.returncode:
            raise SystemExit("patch check failed; preserving its actual command result")

    run(["git", "init", "--quiet"])
    for entry in preimages:
        if entry["preimage"] is not None:
            dest = checkout / entry["path"]
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes((ROOT / "base/hepta" / entry["path"]).read_bytes())
    run(["git", "apply", "--check", str(patch_path)])
    run(["git", "apply", str(patch_path)])
    for entry in source_entries:
        after = (checkout / entry["path"]).read_bytes()
        if after != (ROOT / "change/hepta" / entry["path"]).read_bytes():
            raise SystemExit(f"applied patch mismatch: {entry['path']}")

    manifest = {
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "repository": "TrillionniumFoundation/hepta-private-ci",
        "base_commit": BASE_SHA,
        "base_root_tree": BASE_TREE,
        "base_tree_inventory": {"entries": len(tree), "raw_sha256": identity(tree_bytes)["sha256"]},
        "scope": "Source-only original App composition API and exact missing notice restoration; not a Rust build, executed test, resource bundle or renderer qualification.",
        "files": [{k: v for k, v in e.items() if k != "content"} for e in source_entries],
        "source_files": len(source_entries),
        "modified_preimages": sum(e["preimage"] is not None for e in preimages),
        "new_files": sum(e["preimage"] is None for e in preimages),
        "original_lock": identity((ROOT / "change/hepta" / lock).read_bytes()),
        "patch": identity(patch_path.read_bytes()),
        "patch_check": "git apply --check, actual apply and all 32 final-file byte comparisons passed against exact original preimages",
        "executed": [
            "Original Git-blob and notice/catalog SHA-256 comparisons",
            "Official Rust 1.95 companion rustfmt through stdin, syntax/format only",
            "YAML parsing, source comparison and git patch application only",
        ],
        "not_executed": [
            "Cargo resolution, build, tests or Clippy for this slice",
            "The newly authored native-presentation GitHub Actions lane",
            "A native window, actual fonts, physical IME, assistive technology or device control",
        ],
        "next_phase": "Publish this source as a reviewable upstream candidate; only after a real commit exists pin all Desktop Hepta packages to it and normally generate/validate the dependency lock.",
    }
    (OUTPUT / "source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({k: manifest[k] for k in ("source_files", "modified_preimages", "new_files", "patch_check")}))
    print(str(OUTPUT))


if __name__ == "__main__":
    main()
