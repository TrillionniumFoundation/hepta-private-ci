## Why this change is needed

Desktop can already use the original Hepta ChatWorkspace presenter, but the
original Makepad App constructs and owns its own workspace. Launching that App
beside Desktop would create a second draft owner and bypass Desktop's existing
Session reducer and bounded Bridge. The original App needs an explicit adoption
and lifecycle path before a real Desktop Makepad adapter can reuse it.

This is a draft stacked on #3067. Source commit:
`bb3a82cc6c4c24fae5fe62d83ff723afb6326224`.

## Resulting behavior

- `native-presentation` lets the existing App borrow a caller's one original
  ChatWorkspace. `ChatSourceSlot` adopts once, and the existing single ImeRouter
  and original Chat widgets continue to handle input.
- Existing NativeHost and the presentation mode share original App startup and
  event-loop admission. The existing owner-host event/witness/close suffix stays
  byte-identical. No empty NativeHost or replacement authority is introduced.
- Presentation polls an existing client without blocking Draw, wakes through
  the original SignalToUI path, and uses the existing Console labels and Refresh
  button. Cleanup drops the client's channels once; it is not run cancellation.
- Original Send remains `SendUnavailable`. Observation or refresh success does
  not become Chat history, owner admission, readiness or external-effect success.
- The original missing fourteen notice files are restored exactly, with source
  provenance. The current catalog remains 29 assets, 15 notices and the pinned
  Liberation source archive; no earlier native backend or builder is imported.
- A separate source-head/base-merge CI lane tests both headless and native
  composition features with the unchanged original UI lock. It requires fresh
  JUnit evidence for five/eight exact new test names and runs native Clippy with
  warnings denied, while preserving the full `--lib` selection.

## Validation actually completed

- Python exact-JUnit gate tests: **12/12** normally and **12/12** under `python -O`.
  An independent reviewer repeated both sets.
- Workflow YAML/TOML/Python parsing and four Bash syntax checks passed.
- Official Rust 1.95 rustfmt stdin checks passed for all thirteen changed/new
  upstream Rust files. This is syntax/format verification only.
- Final patch applied to its exact original preimages and reproduced all
  **35** source files; remote readback matched the complete **9,159-leaf** tree.
- Original UI Cargo.lock, SDK pin, core/presenter/IME/room sources and the
  existing native-host event suffix were checked for the stated byte retention.

Rust compilation, Rust tests, actual nextest, native Clippy and renderer
execution for this source have **not run yet**. This draft adds their mandatory
CI entry points and preserves raw evidence; it does not claim those gates passed.

## Remaining integration and acceptance gates

Desktop's separate adapter must move its existing DraftBook, reducer and Bridge
into this interface, pin its original UI packages to this real commit and
generate its lock with Cargo. Its first candidate selects one fixed workspace;
full workspace switching needs RoomKey scoping and stale-input protection.

The current original native editor can reset selection/undo after rejected
edits. Resource checks do not attest the exact font bytes that produce pixels.
A real window, physical IME, readable CJK, accessibility, Web/mobile/bare-metal
acceptance and the production Chat authority connection remain open. The
presentation interface alone does not close those gates.

