// Reproducible generated build overlay; never edits the Cargo Git cache.
import {execOwned as execFileSync} from './owned-artifact-lease.mjs';
import {createHash} from 'node:crypto';
import {cp,mkdir,readFile,rm,writeFile,lstat} from 'node:fs/promises';
import {join} from 'node:path';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
export async function preparePlatform(workspace,makepadRoot,revision){
 const generated=join(workspace,'target/robrix-build');
 const platform=join(generated,'makepad-platform');
 const app=join(generated,'workspace');
 await mkdir(generated,{recursive:true});
 // These directories contain only our generated source copies, never user state.
 await rm(platform,{recursive:true,force:true});
 await cp(join(makepadRoot,'platform'),platform,{recursive:true});
 const patchRoot=join(workspace,'robrix-ui/patches');
 const identity=JSON.parse(await readFile(join(patchRoot,'makepad-wasm-clock.json'),'utf8'));
 const patch=join(patchRoot,'makepad-wasm-clock.patch');
 if(identity.upstream!==revision||sha(await readFile(patch))!==identity.patchSha256||sha(await readFile(join(platform,identity.path)))!==identity.beforeSha256) throw new Error('Unexpected platform patch inputs');
 execFileSync('patch',['--batch','--forward','--fuzz=0','-p1','-d',platform,'-i',patch],{stdio:'inherit'});
 if(sha(await readFile(join(platform,identity.path)))!==identity.afterSha256) throw new Error('Platform patch output mismatch');
 const layoutIdentity=JSON.parse(await readFile(join(patchRoot,'makepad-wasm-instance-layout.json'),'utf8'));
 const layoutPatch=join(patchRoot,'makepad-wasm-instance-layout.patch');
 if(layoutIdentity.upstream!==revision||sha(await readFile(layoutPatch))!==layoutIdentity.patchSha256) throw new Error('Unexpected instance layout patch identity');
 for(const file of layoutIdentity.files) if(sha(await readFile(join(platform,file.path)))!==file.beforeSha256) throw new Error('Unexpected instance layout input: '+file.path);
 execFileSync('patch',['--batch','--forward','--fuzz=0','-p1','-d',platform,'-i',layoutPatch],{stdio:'inherit'});
 for(const file of layoutIdentity.files) if(sha(await readFile(join(platform,file.path)))!==file.afterSha256) throw new Error('Unexpected instance layout output: '+file.path);
 const imeIdentity=JSON.parse(await readFile(join(patchRoot,'makepad-wasm-ime.json'),'utf8'));
 const imePatch=join(patchRoot,'makepad-wasm-ime.patch');
 if(imeIdentity.upstream!==revision||sha(await readFile(imePatch))!==imeIdentity.patchSha256) throw new Error('Unexpected Web IME patch identity');
 for(const file of imeIdentity.files) if(sha(await readFile(join(platform,file.path)))!==file.beforeSha256) throw new Error('Unexpected Web IME input: '+file.path);
 execFileSync('patch',['--batch','--forward','--fuzz=0','-p1','-d',platform,'-i',imePatch],{stdio:'inherit'});
 for(const file of imeIdentity.files) if(sha(await readFile(join(platform,file.path)))!==file.afterSha256) throw new Error('Unexpected Web IME output: '+file.path);
 // The root platform crate's sibling path dependencies remain at the exact Git
 // revision, avoiding duplicate local copies of script/network/math types.
 let manifest=await readFile(join(platform,'Cargo.toml'),'utf8');
 let section='';
 manifest=manifest.split('\n').map(line=>{
  if(line.trim().startsWith('[')) section=line.trim();
  if(!section.includes('dependencies')) return line;
  return line.replace(/path\s*=\s*"[^"]+"/,line.includes('{')
    ? `git = "https://github.com/kevinaboos/makepad", rev = "${revision}"`
    : `git = "https://github.com/kevinaboos/makepad"\nrev = "${revision}"`);
 }).join('\n');
 manifest+='\n[workspace]\n';
 await writeFile(join(platform,'Cargo.toml'),manifest);
 // The no-thread font patch is isolated in the draw crate. Its native and
 // atomics-enabled worker path remains the upstream implementation.
 const draw=join(generated,'makepad-draw');
 await rm(draw,{recursive:true,force:true});
 await cp(join(makepadRoot,'draw'),draw,{recursive:true});
 const drawIdentity=JSON.parse(await readFile(join(patchRoot,'makepad-wasm-fonts.json'),'utf8'));
 const drawPatch=join(patchRoot,'makepad-wasm-fonts.patch');
 if(drawIdentity.upstream!==revision||sha(await readFile(drawPatch))!==drawIdentity.patchSha256) throw new Error('Unexpected draw patch identity');
 for(const file of drawIdentity.files) if(sha(await readFile(join(draw,file.path)))!==file.beforeSha256) throw new Error('Unexpected draw patch input: '+file.path);
 execFileSync('patch',['--batch','--forward','--fuzz=0','-p1','-d',draw,'-i',drawPatch],{stdio:'inherit'});
 for(const file of drawIdentity.files) if(sha(await readFile(join(draw,file.path)))!==file.afterSha256) throw new Error('Unexpected draw patch output: '+file.path);
 // Optional WASM-only consumer observations in the generated pinned overlay.
 // No Cargo revision changes and no browser acceptance assertion changes.
 const consumerIdentity=JSON.parse(await readFile(join(patchRoot,'makepad-font-consumer.json'),'utf8'));
 const consumerPatch=join(patchRoot,'makepad-font-consumer.patch');
 if(consumerIdentity.upstream!==revision||sha(await readFile(consumerPatch))!==consumerIdentity.patchSha256)throw new Error('Unexpected font consumer patch identity');
 for(const file of consumerIdentity.files){
  if(!/^(makepad-platform|makepad-draw)\/src\/[a-z_./]+\.rs$/.test(file.path)||file.path.split('/').includes('..'))throw new Error('Invalid consumer source path');
  const target=join(generated,file.path);
  if(file.beforeSha256===null){
   try{await lstat(target);throw new Error('Consumer source unexpectedly exists');}catch(error){if(error.code!=='ENOENT')throw error;}
  }else if(sha(await readFile(target))!==file.beforeSha256)throw new Error('Unexpected consumer input: '+file.path);
 }
 execFileSync('patch',['--batch','--forward','--fuzz=0','-p1','-d',generated,'-i',consumerPatch],{stdio:'inherit'});
 for(const file of consumerIdentity.files)if(sha(await readFile(join(generated,file.path)))!==file.afterSha256)throw new Error('Unexpected consumer output: '+file.path);
 let drawManifest=await readFile(join(draw,'Cargo.toml'),'utf8');
 let drawSection='';
 drawManifest=drawManifest.split('\n').map(line=>{
  if(line.trim().startsWith('[')) drawSection=line.trim();
  if(!drawSection.includes('dependencies')) return line;
  return line.replace(/path\s*=\s*"[^"]+"/,`git = "https://github.com/kevinaboos/makepad", rev = "${revision}"`);
 }).join('\n')+'\n[workspace]\n';
 await writeFile(join(draw,'Cargo.toml'),drawManifest);
 await mkdir(app,{recursive:true});
 for(const name of ['core','web','robrix-ui']) {await rm(join(app,name),{recursive:true,force:true});await cp(join(workspace,name),join(app,name),{recursive:true});}
 await cp(join(workspace,'Cargo.lock'),join(app,'Cargo.lock'));
 const sourceManifest=await readFile(join(workspace,'Cargo.toml'),'utf8');
 await writeFile(join(app,'Cargo.toml'),sourceManifest+'\n[patch."https://github.com/kevinaboos/makepad"]\nmakepad-platform = { path = "../makepad-platform" }\nmakepad-draw = { path = "../makepad-draw" }\n');
 return {workspace:app,identity,layoutIdentity,imeIdentity,drawIdentity,consumerIdentity,platformManifestSha256:sha(manifest),drawManifestSha256:sha(drawManifest)};
}
