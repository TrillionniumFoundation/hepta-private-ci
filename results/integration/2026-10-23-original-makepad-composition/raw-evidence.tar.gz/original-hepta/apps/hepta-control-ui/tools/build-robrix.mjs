// Build/packaging tooling only. Product UI and event handling live in Rust/Makepad.
import {execOwned as execFileSync} from './owned-artifact-lease.mjs';
import { createHash } from 'node:crypto';
import { cp, mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import {preparePlatform} from './prepare-makepad-platform.mjs';
import {robrixSourceIdentity} from './robrix-source-identity.mjs';
import {emitStaticBridge} from './emit-static-makepad-bridge.mjs';
import {verifyImageFitApi} from './check-makepad-dsl.mjs';
import {withArtifactLease,withStagedArtifact} from './owned-artifact-lease.mjs';
const root = fileURLToPath(new URL('..', import.meta.url));
const workspace = join(root, 'rust');
let source;
const fixtures=process.argv.includes('--fixtures');
await withArtifactLease(root,'build',async lease=>withStagedArtifact(lease,fixtures?'dist-robrix-fixtures':'dist',async output=>{
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const provenance = JSON.parse(await readFile(join(workspace, 'robrix-ui/UPSTREAM.json'), 'utf8'));
const sourceIdentity=await robrixSourceIdentity(root);
const cjkFonts=JSON.parse(execFileSync('python3',[join(root,'tools/prepare-fonts.py'),...(process.env.HEPTA_FONTS_OFFLINE==='1'?['--offline']:[])],{encoding:'utf8'}));
const metadata=JSON.parse(execFileSync('cargo',['+1.95.0','metadata','--locked','--format-version','1','--manifest-path',join(workspace,'Cargo.toml')],{encoding:'utf8',maxBuffer:16*1024*1024}));
const widgets=metadata.packages.find(p=>p.name==='makepad-widgets');
if(!widgets?.source?.endsWith('#'+provenance.makepad.revision)) throw new Error('Makepad lock does not match provenance');
const makepadRoot=dirname(dirname(widgets.manifest_path));
if(execFileSync('git',['-C',makepadRoot,'rev-parse','HEAD'],{encoding:'utf8'}).trim()!==provenance.makepad.revision) throw new Error('Wrong Makepad checkout');
execFileSync('git',['-C',makepadRoot,'diff','--quiet','HEAD','--']);
await verifyImageFitApi(join(workspace,'robrix-ui/src'),join(makepadRoot,'widgets/src/image_cache.rs'));
const toolchainPatch=JSON.parse(await readFile(join(workspace,'robrix-ui/patches/cargo-makepad-toolchain.json'),'utf8'));
const nightly=execFileSync('rustup',['run',toolchainPatch.toolchain,'rustc','--version'],{encoding:'utf8'}).trim();
if(nightly!==toolchainPatch.rustcVersion) throw new Error('Unqualified nightly: '+nightly);
const toolTarget=join(workspace,'target/robrix-tools');
// Upstream intentionally has no tracked lockfile. Build its tool in an isolated
// exact Git archive with our reviewed lock; never depend on or modify cache state.
const toolSource=join(workspace,'target/robrix-tool-source');
const toolArchive=join(workspace,'target/robrix-tool-source.tar');
await mkdir(dirname(toolSource),{recursive:true});
await rm(toolSource,{recursive:true,force:true});
await mkdir(toolSource,{recursive:true});
execFileSync('git',['-C',makepadRoot,'archive','--format=tar','--output='+toolArchive,provenance.makepad.revision]);
try {execFileSync('tar',['-xf',toolArchive,'-C',toolSource]);}
finally {await rm(toolArchive,{force:true});}
const toolCompile=join(toolSource,toolchainPatch.path);
const pristineCompile=await readFile(toolCompile,'utf8');
if(sha(pristineCompile)!==toolchainPatch.beforeSha256||pristineCompile.split('"nightly"').length-1!==toolchainPatch.literalCount)throw new Error('Pinned packager toolchain source changed');
const datedCompile=pristineCompile.replaceAll('"nightly"',JSON.stringify(toolchainPatch.toolchain));
if(sha(datedCompile)!==toolchainPatch.afterSha256)throw new Error('Packager date pin differs from reviewed transformation');
await writeFile(toolCompile,datedCompile);

const packagerLock=await readFile(join(workspace,'robrix-ui/patches/cargo-makepad.Cargo.lock'));
await writeFile(join(toolSource,'Cargo.lock'),packagerLock);
const toolEnv={...process.env,CARGO_BUILD_JOBS:'1',CARGO_INCREMENTAL:'0',CARGO_PROFILE_DEV_DEBUG:'0'};
for(const name of ['CARGO_BUILD_TARGET','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS']) delete toolEnv[name];
execFileSync('cargo',['+1.95.0','build','--locked','--manifest-path',join(toolSource,'tools/cargo_makepad/Cargo.toml'),'--bin','cargo-makepad','--target-dir',toolTarget],{stdio:'inherit',env:toolEnv});
if(sha(await readFile(join(toolSource,'Cargo.lock')))!==sha(packagerLock)) throw new Error('Packager lock changed');
const packager=join(toolTarget,'debug',process.platform==='win32'?'cargo-makepad.exe':'cargo-makepad');
const overlay=await preparePlatform(workspace,makepadRoot,provenance.makepad.revision);
source=join(overlay.workspace,'target/makepad-wasm-app/release/hepta-robrix-ui');
// The upstream packager overlays files; remove only its prior generated package
// so resources deleted from current source cannot survive through Cargo cache reuse.
await rm(source,{recursive:true,force:true});
const packageEnv={...process.env,CARGO_TARGET_DIR:join(overlay.workspace,'target'),CARGO_BUILD_JOBS:'1',CARGO_INCREMENTAL:'0',CARGO_PROFILE_RELEASE_DEBUG:'0'};
delete packageEnv.CARGO_ENCODED_RUSTFLAGS;
delete packageEnv.RUSTFLAGS;
delete packageEnv.CARGO_BUILD_TARGET;
execFileSync(packager,['wasm','--no-threads','build','-p','hepta-robrix-ui','--bin','hepta-robrix','--release',...(fixtures?['--features','hepta-robrix-ui/ui-fixtures']:[])],{cwd:overlay.workspace,stdio:'inherit',env:packageEnv});
const canonicalLock=await readFile(join(workspace,'Cargo.lock'),'utf8');
const generatedLock=await readFile(join(overlay.workspace,'Cargo.lock'),'utf8');
let expectedLock=canonicalLock;
const expectedSource=`source = "git+https://github.com/kevinaboos/makepad?rev=${provenance.makepad.revision}#${provenance.makepad.revision}"\n`;
for(const name of ['makepad-platform','makepad-draw']){
 const header=`[[package]]\nname = "${name}"\nversion = "2.0.0"\n`;
 const start=expectedLock.indexOf(header)+header.length;
 const end=expectedLock.indexOf('\n',start)+1;
 if(start<header.length||expectedLock.slice(start,end)!==expectedSource) throw new Error('Unexpected locked overlay source: '+name);
 expectedLock=expectedLock.slice(0,start)+expectedLock.slice(end);
}
if(expectedLock!==generatedLock) throw new Error('Generated lock changed beyond the exact platform/draw overlays');
if((await robrixSourceIdentity(root)).sha256!==sourceIdentity.sha256) throw new Error('UI source changed during build; rebuild before qualification');
const rawHtml = await readFile(join(source, 'index.html'), 'utf8');
const wasmName = rawHtml.match(/['"]\.\/(hepta-robrix\.[a-f0-9]+\.wasm)['"]/)?.[1];
if (!wasmName) throw new Error('Unexpected pinned Makepad bootstrap; refusing to package');
await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
await cp(source, output, { recursive: true });
// Keep archived art provenance in the build receipt without packaging unused bytes.
const art=JSON.parse(await readFile(join(workspace,'robrix-ui/resources/ASSETS.json'),'utf8'));
if(art.assets.length!==0)throw new Error('Current Rust renderer declares no art resources; review any new asset binding');

// Bind the same verified cache bytes used by native compile-time assets.
for(const asset of cjkFonts.assets){
 const bytes=await readFile(asset.inputPath);
 if(bytes.length!==asset.bytes||sha(bytes)!==asset.sha256)throw new Error('CJK resource identity drift');
 const destination=join(output,asset.logical);
 await mkdir(dirname(destination),{recursive:true});await writeFile(destination,bytes);
}
for(const name of ['OFL.txt','NOTICE.txt'])await cp(join(workspace,'robrix-ui/resources/fonts',name),join(output,'hepta_robrix_ui/resources/fonts',name));
const frameworkPath = join(output, 'makepad_platform/web.js');
let framework = await readFile(frameworkPath, 'utf8');
const originalFrameworkSha256 = sha(framework);
// Remove upstream network crash upload at its transport boundary. No report is
// sent, including pagehide sendBeacon/fallback GET; runtime error state remains.
const start = framework.indexOf('const fallback_get=async payload=>{');
const end = framework.indexOf('const take_pending_panic=()=>{', start);
if (start < 0 || end <= start || !framework.slice(start, end).includes("fetch('/api/crash'")) throw new Error('Pinned crash transport changed');
framework = framework.slice(0, start) + 'const send=async()=>false;\n' + framework.slice(end);
// Move the pinned framework textarea stylesheet to a same-origin CSS asset.
// Property-level runtime positioning remains platform glue, not inline rules.
const styleStart = framework.indexOf("var style=document.createElement('style')");
const styleEndToken = 'document.body.appendChild(style)';
const styleEnd = framework.indexOf(styleEndToken, styleStart);
if (styleStart < 0 || styleEnd < 0) throw new Error('Pinned input stylesheet changed');
const expression = framework.slice(styleStart, styleEnd).split('style.innerHTML=')[1];
if (!expression) throw new Error('Missing pinned input stylesheet');
const literals = [...expression.matchAll(/"(?:[^"\\]|\\.)*"/g)].map(match => JSON.parse(match[0]));
if (!literals.length) throw new Error('Empty input stylesheet');
await writeFile(join(output, 'input-platform.css'), literals.join('')+'\n/* Full-window canvas must not reserve an inline text baseline. */\ncanvas.full_canvas { display: block; }\n');
framework = framework.slice(0, styleStart) + framework.slice(styleEnd + styleEndToken.length);
if (framework.includes("fetch('/api/crash'") || framework.includes("fetch('/$report_error") || framework.includes("sendBeacon('/api/crash'")) throw new Error('Crash transport survived packaging');
await writeFile(frameworkPath, framework);
// Generated loader glue contains no application state/actions or transcript.
await writeFile(join(output, 'bootstrap.js'), `import {WasmWebGL} from './makepad_platform/web_gl.js';\ndocument.documentElement.dataset.heptaBootPhase='fetch-and-instantiate-wasm';\ntry {\n const wasm=await WasmWebGL.fetch_and_instantiate_wasm('./${wasmName}');\n document.documentElement.dataset.heptaBootPhase='construct-webgl-host';\n const host=new WasmWebGL(wasm, {}, document.querySelector('canvas'));\n if(!host.gl){\n  document.documentElement.dataset.heptaBootPhase='webgl2-unavailable';\n  const loader=document.querySelector('.canvas_loader');\n  loader.textContent='WebGL2 is unavailable in this browser or graphics environment. Conversations cannot be rendered here.';\n  loader.setAttribute('role','alert');\n }else document.documentElement.dataset.heptaBootPhase='webgl-host-constructed';\n} catch(error) {\n document.documentElement.dataset.heptaBootPhase='bootstrap-failed';\n throw error;\n}\n`);
const csp = "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self'; connect-src 'self'; img-src 'self' data:; font-src 'self'; worker-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'none'";
await writeFile(join(output, 'index.html'), `<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="Content-Security-Policy" content="${csp}"><title>Hepta Conversations</title><link rel="stylesheet" href="./makepad_platform/full_canvas.css"><link rel="stylesheet" href="./input-platform.css"><script type="module" src="./bootstrap.js"></script></head><body><canvas class="full_canvas" preserveDrawingBuffer aria-label="Hepta conversations"></canvas><div class="canvas_loader">Loading conversations…</div></body></html>\n`);
await cp(join(workspace, 'robrix-ui/licenses'), join(output, 'licenses'), { recursive: true });
await cp(join(makepadRoot,'LICENSE'),join(output,'licenses/MAKEPAD-MIT.txt'));
await cp(join(workspace,'robrix-ui/UPSTREAM.json'),join(output,'UPSTREAM.json'));
const staticBridge=await emitStaticBridge(output);
const files = {};
async function inventory(dir) {
 for (const entry of (await readdir(dir, {withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))) {
  const path=join(dir,entry.name);
  if (entry.isDirectory()) await inventory(path);
  else {if(!entry.isFile())throw new Error('Only regular packaged resources are allowed');const bytes=await readFile(path);files[relative(output,path).replaceAll('\\','/')]={bytes:bytes.length,sha256:sha(bytes)};}
 }
}
await inventory(output);
const expectedResources=JSON.parse(await readFile(join(workspace,'robrix-ui/patches/web-asset-paths.json'),'utf8'));
const expectedPaths=[...expectedResources.files,wasmName].sort();
if(JSON.stringify(Object.keys(files).sort())!==JSON.stringify(expectedPaths))throw new Error('Generated package resource set differs from the reviewed SDK/resource catalog');
// Independent URL -> compiler resource-path mapping, never copied from runtime observations.
const fontConsumerResources={};
for(const [logical,pin]of Object.entries(files).filter(([name])=>/\.(ttf|otf)$/.test(name))){
 const widget=/^makepad_widgets\/resources\/[^/]+\.(ttf|otf)$/.test(logical);
 const cjk=cjkFonts.assets.find(asset=>asset.logical===logical);
 if(!widget&&!cjk)throw new Error('Unreviewed font consumer resource owner: '+logical);
 const relativePath=logical.slice(logical.indexOf('/')+1);
 const absolutePath=join(widget?dirname(widgets.manifest_path):join(overlay.workspace,'robrix-ui'),relativePath).replaceAll('\\','/');
 // CJK served bytes deliberately come from the independently verified cache;
 // its compiler resource path is the generated app root, not that cache path.
 const bytes=await readFile(widget?absolutePath:cjk.inputPath);
 if(bytes.length!==pin.bytes||sha(bytes)!==pin.sha256)throw new Error('Consumer resource/source digest mismatch');
 fontConsumerResources['/'+logical]={absolutePath,dependencyPath:logical,bytes:pin.bytes,sha256:pin.sha256};
}
await writeFile(join(output,'build-manifest.json'),JSON.stringify({schema:'hepta.robrix-ui.build.v1',browserRuntime:'rust-makepad-wasm',fixtures,sourceIdentity,staticBridge,upstream:provenance,artAssets:art,cjkFonts:{manifestSha256:cjkFonts.manifestSha256,bytes:cjkFonts.bytes,assets:cjkFonts.assets.map(({inputPath,...asset})=>asset)},nightly,platformPatch:overlay.identity,instanceLayoutPatch:overlay.layoutIdentity,webImePatch:overlay.imeIdentity,drawPatch:overlay.drawIdentity,fontConsumerPatch:overlay.consumerIdentity,fontConsumerResources,drawManifestSha256:overlay.drawManifestSha256,platformManifestSha256:overlay.platformManifestSha256,canonicalLockSha256:sha(canonicalLock),generatedLockSha256:sha(await readFile(join(overlay.workspace,'Cargo.lock'))),packagerSource:provenance.makepad.revision,packagerToolchainPatch:toolchainPatch,packagerLockSha256:sha(packagerLock),packagerSha256:sha(await readFile(packager)),threads:false,webglContext:{preserveDrawingBuffer:true,reason:'verified-visible-resize-loss-with-discarded-buffer'},automaticCrashUpload:false,viewportZoomRestrictionRemoved:true,originalFrameworkSha256,packagedFrameworkSha256:sha(framework),files},null,2)+'\n');
console.log(`Packaged Robrix-derived Rust UI (${Object.keys(files).length} assets); rendering still requires host acceptance`);

}));
