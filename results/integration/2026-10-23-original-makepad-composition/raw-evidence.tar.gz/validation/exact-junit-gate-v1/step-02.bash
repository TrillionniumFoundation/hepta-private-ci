set -euo pipefail
mkdir -p "$RUNNER_TEMP/native-presentation-evidence"
git rev-parse HEAD > "$RUNNER_TEMP/native-presentation-evidence/tested-head.txt"
git rev-parse 'HEAD^{tree}' > "$RUNNER_TEMP/native-presentation-evidence/tested-tree.txt"
sha256sum apps/hepta-control-ui/rust/Cargo.lock > "$RUNNER_TEMP/native-presentation-evidence/original-lock.sha256"
