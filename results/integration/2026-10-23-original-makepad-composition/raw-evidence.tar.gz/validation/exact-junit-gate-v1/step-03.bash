set -euo pipefail
rustup toolchain install 1.95.0 --profile minimal --component rustfmt,clippy
test "$(rustc --version)" = "rustc 1.95.0 (59807616e 2026-04-14)"
cargo install just --locked --version 1.58.0 --root "$TOOL_ROOT"
python3 apps/hepta-control-ui/tools/install-official-nextest.py "$TOOL_ROOT"
export PATH="$TOOL_ROOT/bin:$PATH"
test "$(just --version)" = "just 1.58.0"
python3 apps/hepta-control-ui/tools/install-official-nextest.py --verify "$TOOL_ROOT"
echo "$TOOL_ROOT/bin" >> "$GITHUB_PATH"
rustc -Vv > "$RUNNER_TEMP/native-presentation-evidence/rustc.txt"
cargo -Vv > "$RUNNER_TEMP/native-presentation-evidence/cargo.txt"
