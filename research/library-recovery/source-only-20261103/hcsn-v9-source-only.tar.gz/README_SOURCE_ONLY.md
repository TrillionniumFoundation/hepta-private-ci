# hcsn-v9: source-only recovery

Original Library artifact: `HCSN_V9_20261101_source_evidence.zip`

Original ZIP SHA-256: `b9bc77d41716de8e2babec5899f3e2c80f2ebacc9ced6553ce6d7ccd2a764518`

Source-only bundle includes 33 candidate code, docs and selected configuration files. It does NOT contain raw evidence datasets/checkpoints/logs and cannot, by itself, prove the full experiments can be independently replayed.

## Verify

Run `sha256sum hcsn-v9-source-only.tar.gz` and compare with `bundle_sha256` in the sidecar JSON. Then extract into a new empty directory: `tar -xzf hcsn-v9-source-only.tar.gz -C <empty-dir>` and verify each file against `SOURCE_MANIFEST.json`.

## Scope

Historical results must not be claimed reproducible solely because source is recovered. Dependencies, asset acquisition, random seeds and environment requirements are described in the preserved scripts/READMEs where available. Files flagged as possible secrets were excluded pending manual inspection.
