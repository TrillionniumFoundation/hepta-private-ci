"""Verify this extracted bundle and restore the pinned predecessor into repo/."""
import hashlib, json, stat, zipfile
from pathlib import Path, PurePosixPath
base = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = json.loads((base / 'BUNDLE_MANIFEST.json').read_text())
def safe_target(name, root=base):
    relative = PurePosixPath(name)
    if relative.is_absolute() or '..' in relative.parts or '\\' in str(relative): raise ValueError('Unsafe path')
    target = root / str(relative)
    if any(p.is_symlink() for p in [target, *target.parents] if p == base or base in p.parents): raise ValueError('Symlink ancestor')
    return target
for entry in manifest['files']:
    path = safe_target(entry['path'])
    if path.is_symlink() or path.stat().st_size != entry['bytes']:
        raise ValueError('Bundle size/type mismatch: ' + entry['path'])
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''): h.update(block)
    if h.hexdigest() != entry['sha256']: raise ValueError('Bundle hash mismatch: ' + entry['path'])
archive_path = safe_target(manifest['predecessor']['path'])
with zipfile.ZipFile(archive_path) as archive:
    old = json.loads(archive.read('PACKAGE_MANIFEST.json'))
    expected = {e['path'] for e in old['files']}
    if set(archive.namelist()) != expected | {'PACKAGE_MANIFEST.json'}: raise ValueError('Old inventory')
    for entry in old['files']:
        name = PurePosixPath(entry['path']); info = archive.getinfo(str(name))
        target = safe_target(str(name), base / 'repo')
        if stat.S_ISLNK(info.external_attr >> 16): raise ValueError('Old symlink')
        content = archive.read(str(name))
        if len(content) != entry['bytes'] or sha(content) != entry['sha256']: raise ValueError('Old hash')
        if target.exists():
            if target.is_symlink() or sha(target.read_bytes()) != entry['sha256']: raise FileExistsError(target)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write(content)
print('All bundle payload hashes verified; predecessor restored under repo/. No downloads or model runs performed.')
