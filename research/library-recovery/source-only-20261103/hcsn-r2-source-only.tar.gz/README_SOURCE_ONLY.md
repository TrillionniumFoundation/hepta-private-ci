# hcsn-r2: source-only recovery

Original Library artifact: `HCSN_Next_Blockers_R2_20261101_source_evidence.zip`

Original ZIP SHA-256: `566d6a2f01dc67ca19bcc95f66c2fb830a4390e38b9667ae4cb6eec9b611163a`

Source-only bundle includes 185 candidate code, docs and selected configuration files. It does NOT contain raw evidence datasets/checkpoints/logs and cannot, by itself, prove the full experiments can be independently replayed.

## Verify

Run `sha256sum hcsn-r2-source-only.tar.gz` and compare with `bundle_sha256` in the sidecar JSON. Then extract into a new empty directory: `tar -xzf hcsn-r2-source-only.tar.gz -C <empty-dir>` and verify each file against `SOURCE_MANIFEST.json`.

## Scope

Historical results must not be claimed reproducible solely because source is recovered. Dependencies, asset acquisition, random seeds and environment requirements are described in the preserved scripts/READMEs where available. Files flagged as possible secrets were excluded pending manual inspection.
