# hcsn-addressed: source-only recovery

Original Library artifact: `HCSN_Addressed_Followup_20261101_source_evidence.zip`

Original ZIP SHA-256: `9c7fb471af01515f1617f8973de438c56d3deed91479ec0e8cf948915fe7b4ea`

Source-only bundle includes 121 candidate code, docs and selected configuration files. It does NOT contain raw evidence datasets/checkpoints/logs and cannot, by itself, prove the full experiments can be independently replayed.

## Verify

Run `sha256sum hcsn-addressed-source-only.tar.gz` and compare with `bundle_sha256` in the sidecar JSON. Then extract into a new empty directory: `tar -xzf hcsn-addressed-source-only.tar.gz -C <empty-dir>` and verify each file against `SOURCE_MANIFEST.json`.

## Scope

Historical results must not be claimed reproducible solely because source is recovered. Dependencies, asset acquisition, random seeds and environment requirements are described in the preserved scripts/READMEs where available. Files flagged as possible secrets were excluded pending manual inspection.
