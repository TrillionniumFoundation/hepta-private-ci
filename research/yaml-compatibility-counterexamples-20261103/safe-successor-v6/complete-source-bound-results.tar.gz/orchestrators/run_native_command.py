#!/usr/bin/env python3
"""Capture actual scoped workspace commands without changing their gates."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, time
ap=argparse.ArgumentParser()
ap.add_argument('--name',required=True);ap.add_argument('--repo',type=Path,required=True)
ap.add_argument('--out',type=Path,required=True);ap.add_argument('--cwd',default='codex-rs')
ap.add_argument('command',nargs=argparse.REMAINDER);a=ap.parse_args()
argv=a.command[1:] if a.command[:1]==['--'] else a.command
assert argv
a.out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def snapshot():
    paths=subprocess.check_output(['git','-C',str(a.repo),'diff','--name-only','HEAD'],text=True).splitlines()
    paths+=subprocess.check_output(['git','-C',str(a.repo),'ls-files','--others','--exclude-standard'],text=True).splitlines()
    return {p:sha(a.repo/p) if (a.repo/p).is_file() else None for p in sorted(set(paths))}
before=snapshot();start=time.monotonic()
prefix='/workspace/scratch/1f1d02319616/recovered-toolchain-20261103/bin'
environment={'PATH':prefix+':/workspace/scratch/1f1d02319616/recovered-tools-20261103/bin:/workspace/scratch/1f1d02319616/recovery-20261103/dotslash:'+os.environ['PATH'],
 'RUSTC':prefix+'/rustc','RUSTDOC':prefix+'/rustdoc','CARGO_HOME':'/tmp/chain-yaml-native-cargo-home-20261103',
 'CARGO_TARGET_DIR':'/tmp/chain-yaml-native-target-20261103','CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'1',
 'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0'}
env=dict(os.environ,**environment)
with (a.out/(a.name+'.stdout')).open('wb') as stdout,(a.out/(a.name+'.stderr')).open('wb') as stderr:
    p=subprocess.run(argv,cwd=a.repo/a.cwd,env=env,stdout=stdout,stderr=stderr)
after=snapshot()
receipt={'schema':'yaml-scoped-workspace-command-v1','name':a.name,'argv':argv,'cwd':str(a.repo/a.cwd),
 'base_commit':subprocess.check_output(['git','-C',str(a.repo),'rev-parse','HEAD'],text=True).strip(),
 'environment_overrides':environment,'exit_code':p.returncode,'seconds':time.monotonic()-start,
 'orchestrator_sha256':sha(__file__),'compiler_sha256':sha(prefix+'/rustc'),
 'before_source_sha256':before,'after_source_sha256':after,'inputs_unchanged':before==after,
 'stdout_sha256':sha(a.out/(a.name+'.stdout')),'stderr_sha256':sha(a.out/(a.name+'.stderr'))}
(a.out/(a.name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['name','exit_code','seconds','inputs_unchanged','stdout_sha256','stderr_sha256']}),flush=True)
if p.returncode:print((a.out/(a.name+'.stderr')).read_text()[-10000:])
raise SystemExit(p.returncode)
