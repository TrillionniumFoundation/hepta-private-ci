#!/usr/bin/env python3
"""Replace per-node Tagged wrappers with Serde's native tagged-value dispatch."""
from pathlib import Path
import argparse, hashlib, json, shutil
ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(a.source/'src/de/deserializer.rs')=='83689c15720ab7a34d0baad1448788d9c82c59173d27669c0a7739117966a585'
shutil.copytree(a.source,a.out)
p=a.out/'src/de/deserializer.rs';s=p.read_text()
old='    pub(super) cfg: Cfg,\n';assert s.count(old)==1
s=s.replace(old,old+'    /// The current local tag has already been delivered to a legacy Value visitor.\n    pub(super) legacy_value_tag_consumed: bool,\n')
old='            key_empty_map_node: false,\n';assert s.count(old)==2
s=s.replace(old,old+'            legacy_value_tag_consumed: false,\n')
old="    fn deserialize_any<V: Visitor<'de>>(mut self, visitor: V) -> Result<V::Value, Self::Error> {\n";assert s.count(old)==1
s=s.replace(old,old+'''        if self.cfg.legacy_serde_yaml_scalars && !self.legacy_value_tag_consumed {
            let local_tag = match self.ev.peek()? {
                Some(Ev::Scalar { raw_tag, .. } | Ev::SeqStart { raw_tag, .. } | Ev::MapStart { raw_tag, .. }) =>
                    raw_tag.as_deref().filter(|tag| tag.starts_with('!')).map(str::to_owned),
                _ => None,
            };
            if let Some(tag) = local_tag {
                return super::legacy_value_tags::visit(self, tag, visitor);
            }
        }
''')
old='                    key_empty_map_node: kemn,\n';assert s.count(old)==1
s=s.replace(old,old+'                    legacy_value_tag_consumed: false,\n')
p.write_text(s)
p=a.out/'src/de/mod.rs';s=p.read_text();assert s.count('mod legacy_scalars;')==1;p.write_text(s.replace('mod legacy_scalars;','mod legacy_scalars;\nmod legacy_value_tags;'))
(a.out/'src/de/legacy_value_tags.rs').write_text('''//! Present only actual local tags through Serde's EnumAccess protocol.
// No node is copied, stripped, replayed or charged again here. Untagged nodes
// take the ordinary deserialize_any path, avoiding a virtual Tagged sequence
// and its recursive frames at every container depth.
use serde_core::de::{self, IntoDeserializer, Visitor};
use super::Error;
use super::deserializer::YamlDeserializer;

pub(super) fn visit<'de, V: Visitor<'de>>(
    mut de: YamlDeserializer<'de, '_>,
    tag: String,
    visitor: V,
) -> Result<V::Value, Error> {
    // This marker belongs to this one node. Child deserializers start false.
    // The raw event, including its tag, stays intact for alias retention and
    // budget accounting; scalar resolution still sees the original tag.
    de.legacy_value_tag_consumed = true;
    visitor.visit_enum(LocalTag { de, tag })
}

struct LocalTag<'de, 'e> {
    de: YamlDeserializer<'de, 'e>,
    tag: String,
}
impl<'de, 'e> de::EnumAccess<'de> for LocalTag<'de, 'e> {
    type Error = Error;
    type Variant = LocalValue<'de, 'e>;
    fn variant_seed<V: de::DeserializeSeed<'de>>(
        self, seed: V,
    ) -> Result<(V::Value, Self::Variant), Error> {
        Ok((seed.deserialize(self.tag.into_deserializer())?, LocalValue(self.de)))
    }
}
struct LocalValue<'de, 'e>(YamlDeserializer<'de, 'e>);
impl<'de> de::VariantAccess<'de> for LocalValue<'de, '_> {
    type Error = Error;
    fn newtype_variant_seed<T: de::DeserializeSeed<'de>>(self, seed: T) -> Result<T::Value, Error> {
        seed.deserialize(self.0)
    }
    fn unit_variant(self) -> Result<(), Error> {
        Err(Error::msg("a legacy YAML local tag carries a value"))
    }
    fn tuple_variant<V: Visitor<'de>>(self, _len: usize, _visitor: V) -> Result<V::Value, Error> {
        Err(Error::msg("a legacy YAML local tag carries a newtype value"))
    }
    fn struct_variant<V: Visitor<'de>>(self, _fields: &'static [&'static str], _visitor: V) -> Result<V::Value, Error> {
        Err(Error::msg("a legacy YAML local tag carries a newtype value"))
    }
}
''')
print(json.dumps({'deserializer_sha256':sha(a.out/'src/de/deserializer.rs'),'tag_module_sha256':sha(a.out/'src/de/legacy_value_tags.rs')}))
