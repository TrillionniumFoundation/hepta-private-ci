#!/usr/bin/env python3
"""Keep the large scalar dispatch frame out of the local-tag recursion path."""
from pathlib import Path
import argparse,hashlib,shutil
ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
p=a.source/'src/de/deserializer.rs'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='297a17d4a5ad8d1e3c63dbcfa8edce1d8d850e97c6fc7efb2df8bffa9031c2c8'
shutil.copytree(a.source,a.out);p=a.out/'src/de/deserializer.rs';s=p.read_text()
start=s.index("    fn deserialize_any<V: Visitor<'de>>(mut self, visitor: V) -> Result<V::Value, Self::Error> {")
end=s.index('    /// Parse a boolean literal according to `strict_booleans`.',start)
method=s[start:end];split=method.index('        if self.cfg.legacy_serde_yaml_scalars && matches!')
body=method[split:];assert body.endswith('    }\n\n')
dispatch=method[:split]+'        self.deserialize_any_value(visitor)\n    }\n\n'
s=s[:start]+dispatch+s[end:]
needle="    fn legacy_scalar<V: Visitor<'de>>(";assert s.count(needle)==1
helper='''    // This separate frame is intentional: a local tag's EnumAccess recurses
    // into its payload before this large scalar-dispatch frame is allocated.
    // Keeping it in deserialize_any doubles that frame at every tagged depth
    // in unoptimized builds and can overflow before the unchanged depth cap.
    fn deserialize_any_value<V: Visitor<'de>>(mut self, visitor: V) -> Result<V::Value, Error> {
'''+body
s=s.replace(needle,helper+needle);p.write_text(s)
print(hashlib.sha256(p.read_bytes()).hexdigest())
