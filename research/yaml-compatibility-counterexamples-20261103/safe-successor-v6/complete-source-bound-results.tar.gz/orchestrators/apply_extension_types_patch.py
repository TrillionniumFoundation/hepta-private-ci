#!/usr/bin/env python3
"""Cover the actual skills-extension u16 and unit Product enum inputs."""
from pathlib import Path
import argparse,hashlib,shutil
ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
assert hashlib.sha256((a.source/'src/de/deserializer.rs').read_bytes()).hexdigest()=='8edc1007e3048c41a58738633ead8bf7181a7fa6634c1919a5c0d919637150bd'
shutil.copytree(a.source,a.out)
p=a.out/'src/de/legacy_scalars.rs';s=p.read_text().replace('U32','Unsigned').replace('error("u32")','error("unsigned integer")');p.write_text(s)
p=a.out/'src/de/deserializer.rs';s=p.read_text().replace('Target::U32','Target::Unsigned')
needle="    fn deserialize_u16<V: Visitor<'de>>(mut self, visitor: V) -> Result<V::Value, Self::Error> {\n";assert s.count(needle)==1
s=s.replace(needle,needle+'''        if self.cfg.legacy_serde_yaml_scalars {
            return self.legacy_scalar(super::legacy_scalars::Target::Unsigned, visitor);
        }
''')
needle='''    ) -> Result<V::Value, Self::Error> {
        enum Mode<'de, 'a> {
''';assert s.count(needle)==1
s=s.replace(needle,'''    ) -> Result<V::Value, Self::Error> {
        if self.cfg.legacy_serde_yaml_scalars {
            let local_tag = match self.ev.peek()? {
                Some(Ev::Scalar { raw_tag, .. } | Ev::SeqStart { raw_tag, .. } | Ev::MapStart { raw_tag, .. }) =>
                    raw_tag.as_deref().filter(|tag| tag.starts_with('!')).map(str::to_owned),
                _ => None,
            };
            if let Some(tag) = local_tag {
                let variant = match tag.strip_prefix('!') {
                    Some("") | None => tag.as_str(),
                    Some(rest) => rest,
                }.to_owned();
                return super::legacy_value_tags::visit(self, variant, visitor);
            }
            if matches!(self.ev.peek()?, Some(Ev::Scalar { .. })) {
                let value = self.take_scalar_view()?.effective.into_owned();
                return visitor.visit_enum(value.into_deserializer());
            }
            return Err(Error::unexpected("a legacy enum scalar or local YAML tag")
                .with_location(self.ev.last_location()));
        }
        enum Mode<'de, 'a> {
''');p.write_text(s)
p=a.out/'src/de/legacy_value_tags.rs';s=p.read_text();s=s.replace('use super::Error;','use super::Error;\nuse super::events::Ev;\nuse granit_parser::ScalarStyle;')
old='''    fn unit_variant(self) -> Result<(), Error> {
        Err(Error::msg("a legacy YAML local tag carries a value"))
    }
''';assert s.count(old)==1
s=s.replace(old,'''    fn unit_variant(self) -> Result<(), Error> {
        // A unit enum tag accepts only a plain null payload, as the legacy
        // deserializer did after consuming the tag. Quoted null stays text.
        let is_null = match self.0.ev.peek()? {
            Some(Ev::Scalar { value, style: ScalarStyle::Plain, .. }) =>
                value.is_empty() || matches!(value.as_ref(), "null" | "Null" | "NULL" | "~"),
            None => true,
            _ => false,
        };
        if is_null {
            let _ = self.0.ev.next()?;
            Ok(())
        } else {
            Err(Error::unexpected("null payload for a legacy unit enum")
                .with_location(self.0.ev.last_location()))
        }
    }
''');p.write_text(s)
print(hashlib.sha256((a.out/'src/de/deserializer.rs').read_bytes()).hexdigest())
