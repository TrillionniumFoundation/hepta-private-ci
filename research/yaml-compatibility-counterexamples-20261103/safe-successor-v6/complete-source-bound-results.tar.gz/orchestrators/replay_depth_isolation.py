#!/usr/bin/env python3
"""Compare unchanged official/fork and legacy on the same explicit conditions."""
from pathlib import Path
import argparse, hashlib, json, os, resource, shutil, subprocess, sys, time
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--library',type=Path,required=True);ap.add_argument('--dependencies',type=Path,required=True);ap.add_argument('--rustc',type=Path,required=True);ap.add_argument('--shape',action='append',default=[]);a=ap.parse_args()
root=Path(__file__).resolve().parent;a.out.mkdir(exist_ok=False)
for source,target in [('probe/depth_isolation.rs','main.rs'),('probe/compatible_value.rs','safe_yaml.rs')]:shutil.copy2(root/source,a.out/target)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={str(p):sha(p) for p in [a.out/'main.rs',a.out/'safe_yaml.rs',a.library]}
args=[str(a.rustc),'--edition=2024','-C','debuginfo=0','-C','opt-level=0','-L','dependency='+str(a.dependencies),'--extern','serde_saphyr='+str(a.library)]
for name in ['serde','serde_yaml','serde_json','serde_saphyr','ryu','indexmap']:
    ps=list(a.dependencies.glob('lib'+name+'-*.rlib'));assert len(ps)==1
    inputs[str(ps[0])]=sha(ps[0]);args+=['--extern',('serde_saphyr_official' if name=='serde_saphyr' else name)+'='+str(ps[0])]
args+=[str(a.out/'main.rs'),'-o',str(a.out/'probe')]
records=[]
def run(name,argv,env=None):
    start=time.monotonic();p=subprocess.run(argv,capture_output=True,timeout=30,env=env,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_CORE,(0,0)))
    (a.out/(name+'.stdout')).write_bytes(p.stdout);(a.out/(name+'.stderr')).write_bytes(p.stderr)
    rec={'name':name,'argv':argv,'exit_code':p.returncode,'seconds':time.monotonic()-start,'RUST_MIN_STACK':env.get('RUST_MIN_STACK') if env is not None else os.environ.get('RUST_MIN_STACK'),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()};records.append(rec)
    if p.returncode != 0 or name == 'compile': print(json.dumps({'name':name,'exit_code':p.returncode,'outcome':p.stdout.decode()[:160],'error':p.stderr.decode()[:160]}),flush=True)
    return p
p=run('compile',args)
if p.returncode==0:
    inputs[str(a.out/'probe')]=sha(a.out/'probe')
    for stack in [None,'8388608']:
        env=dict(os.environ);env.pop('RUST_MIN_STACK',None)
        if stack is not None:env['RUST_MIN_STACK']=stack
        for variant in ['legacy','official-json','fork-default-json','fork-default-value','fork-active-value']:
            for shape in a.shape or ['sequence']:
                for depth in [32,48,64,65]:
                    run(('default' if stack is None else 'repo-8m')+'-'+variant+'-'+shape+'-'+str(depth),[str(a.out/'probe'),variant,str(depth),shape],env)
(a.out/'RECEIPT.json').write_text(json.dumps({'schema':'yaml-depth-isolation-v1','orchestrator_sha256':sha(__file__),'orchestrator_argv':sys.argv,'inputs_sha256':inputs,'records':records,'inputs_unchanged':all(sha(p)==h for p,h in inputs.items()),'compiler':subprocess.check_output([str(a.rustc),'--version'],text=True).strip(),'compiler_sha256':sha(a.rustc),'notes':['No parser budget was changed.','8 MiB condition is the existing repository justfile setting; default-thread failures remain failures.','All linked libraries and executable are unoptimized.'], 'production_accepted':False},indent=2)+'\n')

print(json.dumps({'run_observations':len(records)-1,'process_failures':sum(r['exit_code']!=0 for r in records),'production_accepted':False}))
