import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import tomllib

root = Path(__file__).resolve().parents[2]
out = root / 'tooling/validation/completed-client-callers-07a0cf7c'
out.mkdir(exist_ok=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == '07a0cf7cb2340a767cc613869feb0f3d667e7c16'
spec = importlib.util.spec_from_file_location('completed_client_proof', root / 'scripts/verify_hepta_callers.py')
proof = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = proof
spec.loader.exec_module(proof)
manifest = proof._load_manifest(root / 'CALLERS.toml')
files = proof._source_files(root, proof._string_tuple(manifest, 'source_roots'))
inputs = set(files) | set((root / 'qa/b4-no-bypass').glob('*.py')) | set((root / 'scripts').glob('*.py'))
inputs |= {root / 'CALLERS.toml', root / '.github/blob-size-allowlist.txt'}

def snapshot():
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(inputs)}

def save(name, data):
    with (out / name).open('w') as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

before = snapshot()
save('before.json', before)
command = [sys.executable, '-m', 'unittest', 'test_completed_learning_client_source_closure', 'test_q24_completed_history_control_source_closure', '-v']
start = time.monotonic()
with (out / 'source-qa.log').open('w') as stream:
    qa = subprocess.run(command, cwd=root / 'qa/b4-no-bypass', stdout=stream, stderr=subprocess.STDOUT)
print(json.dumps({'source_qa_exit': qa.returncode}), flush=True)
index = {p.relative_to(root).as_posix(): proof._strip_cfg_test_items(proof._strip_rust_non_code(p.read_text())) for p in files}
identifiers = {'root_completed_retain_acceptance', 'root_completed_accept_capsule', 'root_completed_read_original', 'q24_completed_history_config_install'}
old = tomllib.loads(subprocess.check_output(['git', 'show', '27bbd027bf02e134755cadb98ccd20d320364ce0:CALLERS.toml'], cwd=root, text=True))
old_failures = []
current = []
ignored = proof._string_tuple(manifest, 'ignored_path_fragments')
cache = {}
for boundary in proof._boundary_rows(old):
    if boundary.identifier not in identifiers:
        continue
    try:
        proof._verify_boundary(root, boundary, index, ignored, fields_by_receiver_type=cache)
    except proof.VerificationFailure as error:
        old_failures.append({'id': boundary.identifier, 'error': str(error)})
    else:
        old_failures.append({'id': boundary.identifier, 'unexpected_pass': True})
for boundary in proof._boundary_rows(manifest):
    if boundary.identifier not in identifiers:
        continue
    try:
        current.append({'id': boundary.identifier, 'pass': True, 'receipt': proof._verify_boundary(root, boundary, index, ignored, fields_by_receiver_type=cache)})
    except proof.VerificationFailure as error:
        current.append({'id': boundary.identifier, 'pass': False, 'error': str(error)})
after = snapshot()
save('after.json', after)
head_after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
clean = not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=root, text=True)
record = {'source_commit': head, 'source_tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip(), 'command': command, 'source_qa_exit': qa.returncode, 'rust_files': len(files), 'input_files': len(inputs), 'old_manifest_baseline': old_failures, 'selected_boundaries': current, 'all_inputs_unchanged': before == after, 'head_unchanged': head == head_after, 'tracked_clean': clean, 'elapsed_seconds': time.monotonic() - start, 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'native_executed': False, 'full_caller_scan': False}
save('result.json', record)
print(json.dumps(record, indent=2), flush=True)
assert len(old_failures) == 4 and all('caller set mismatch' in r.get('error', '') for r in old_failures)
assert len(current) == 4 and all(r['pass'] for r in current)
assert qa.returncode == 0 and before == after and head == head_after and clean
