import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import tomllib

root = Path(__file__).resolve().parents[2]
out = root / 'tooling/validation/terminal-ack-4cde2ffd'
out.mkdir(exist_ok=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == '4cde2ffd2b842ee7848df773a55471ee7513d462'
spec = importlib.util.spec_from_file_location('terminal_ack_proof', root / 'scripts/verify_hepta_callers.py')
proof = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = proof
spec.loader.exec_module(proof)
manifest = proof._load_manifest(root / 'CALLERS.toml')
files = proof._source_files(root, proof._string_tuple(manifest, 'source_roots'))
inputs = set(files) | set((root / 'qa/b4-no-bypass').glob('*.py')) | set((root / 'scripts').glob('*.py'))
inputs |= {root / 'CALLERS.toml', root / '.github/blob-size-allowlist.txt'}


def snapshot():
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(inputs)}


def save(name, data):
    with (out / name).open('w') as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


before = snapshot()
save('before.json', before)
command = [sys.executable, '-m', 'unittest', 'test_q24_terminal_acceptance_source_closure',
           'test_completed_learning_client_source_closure', 'test_q24_completed_history_control_source_closure',
           'test_completed_learning_route_source_closure', '-v']
start = time.monotonic()
with (out / 'source-qa.log').open('w') as stream:
    qa = subprocess.run(command, cwd=root / 'qa/b4-no-bypass', stdout=stream, stderr=subprocess.STDOUT)
print(json.dumps({'source_qa_exit': qa.returncode}), flush=True)
index = {p.relative_to(root).as_posix(): proof._strip_cfg_test_items(proof._strip_rust_non_code(p.read_text())) for p in files}
identifiers = {
    'root_completed_acknowledgement_construct', 'root_completed_acknowledgement_data',
    'root_completed_acknowledgement_current', 'q24_terminal_acceptance_state_attach',
    'q24_terminal_acceptance_state_read', 'q24_terminal_acceptance_client',
    'root_completed_retain_acceptance', 'root_completed_accept_capsule',
    'root_completed_read_original', 'q24_completed_history_config_install',
}
ignored = proof._string_tuple(manifest, 'ignored_path_fragments')
cache = {}
results = []
for boundary in proof._boundary_rows(manifest):
    if boundary.identifier not in identifiers:
        continue
    try:
        entry = {'id': boundary.identifier, 'pass': True,
                 'receipt': proof._verify_boundary(root, boundary, index, ignored, fields_by_receiver_type=cache)}
    except proof.VerificationFailure as error:
        entry = {'id': boundary.identifier, 'pass': False, 'error': str(error)}
    results.append(entry)
    save('selected-progress.json', results)
    print(json.dumps(entry), flush=True)
after = snapshot()
save('after.json', after)
head_after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
clean = not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=root, text=True)
record = {
    'source_commit': head, 'source_tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip(),
    'command': command, 'source_qa_exit': qa.returncode, 'rust_files': len(files), 'input_files': len(inputs),
    'selected_boundaries': results, 'all_inputs_unchanged': before == after, 'head_unchanged': head == head_after,
    'tracked_clean': clean, 'elapsed_seconds': time.monotonic() - start,
    'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'native_executed': False, 'full_caller_scan': False,
}
save('result.json', record)
print(json.dumps(record, indent=2), flush=True)
assert len(results) == 10 and all(r['pass'] for r in results)
assert qa.returncode == 0 and before == after and head == head_after and clean
