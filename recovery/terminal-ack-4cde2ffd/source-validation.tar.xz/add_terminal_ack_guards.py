from pathlib import Path
import hashlib
import json
import re
import tomllib

root = Path(__file__).resolve().parents[2]
A = 'codex-rs/hepta-agentd/src/'
cap = A + 'root_completed_learning_history.rs'
ack = A + 'root_completed_learning_acknowledgement.rs'
state = A + 'state_q24_completed_history.rs'
terminal = A + 'learning_iteration_terminal_acceptance.rs'
client = A + 'client_q24_completed_history.rs'
data = 'codex-rs/hepta-agent-protocol/src/q24_terminal_acceptance.rs'
helper = A + 'ordinary_q24_cold_acceptance_data_tests.rs'

boundaries = [
    dict(id='root_completed_acknowledgement_construct', symbol='OriginalCompletedLearningAcknowledgementV1', definition_path=cap,
         definition_markers=['pub(crate) struct OriginalCompletedLearningAcknowledgementV1 {', 'identity: AgentdIdentity,', 'data: OriginalQ24TerminalAcceptanceDataV1,'],
         call_pattern=r'\bOriginalCompletedLearningAcknowledgementV1\s*\{', product_callers=[], caller_markers=[]),
    dict(id='root_completed_acknowledgement_data', symbol='OriginalCompletedLearningAcknowledgementV1::data', receiver_type='OriginalCompletedLearningAcknowledgementV1', definition_path=ack,
         definition_markers=['fn data(&self) -> &OriginalQ24TerminalAcceptanceDataV1'], product_callers=[terminal, state], caller_markers=[]),
    dict(id='root_completed_acknowledgement_current', symbol='OriginalCompletedLearningAcknowledgementV1::require_original_current', receiver_type='OriginalCompletedLearningAcknowledgementV1', definition_path=ack,
         definition_markers=['fn require_original_current(', 'identity != &self.identity'], product_callers=[state], caller_markers=[]),
    dict(id='q24_terminal_acceptance_state_attach', symbol='AgentdState::attach_original_q24_terminal_acceptance', receiver_type='AgentdState', definition_path=state,
         definition_markers=['fn attach_original_q24_terminal_acceptance(', 'acknowledged: OriginalCompletedLearningAcknowledgementV1'], product_callers=[terminal], caller_markers=[]),
    dict(id='q24_terminal_acceptance_state_read', symbol='AgentdState::read_original_q24_terminal_acceptance', receiver_type='AgentdState', definition_path=state,
         definition_markers=['fn read_original_q24_terminal_acceptance('], product_callers=[A + 'state_control.rs'], caller_markers=[]),
    dict(id='q24_terminal_acceptance_client', symbol='AgentdClient::original_q24_terminal_acceptance', receiver_type='AgentdClient', definition_path=client,
         definition_markers=['fn original_q24_terminal_acceptance('], product_callers=[], caller_markers=[]),
]

rows = [
    dict(path=cap, required=['pub(crate) struct OriginalCompletedLearningAcknowledgementV1 {', 'identity: AgentdIdentity,', 'data: OriginalQ24TerminalAcceptanceDataV1,'],
         forbidden=['impl Clone for OriginalCompletedLearningAcknowledgementV1', 'impl Deref for OriginalCompletedLearningAcknowledgementV1', 'Deserialize', 'Serialize', 'pub client:', 'pub(crate) client:', 'pub identity:', 'pub(crate) identity:', 'pub data:', 'pub(crate) data:'],
         required_function_order=[dict(function='fn accept(', sequence=[
             'Result<OriginalCompletedLearningAcknowledgementV1, AgentdError>', 'let mut fence = FenceReadOnDrop', 'armed: true',
             'RootHistoricalTaskReadClientV1::accept_completed_once(&self.client, &self.identity)?',
             'let data = OriginalQ24TerminalAcceptanceDataV1 {', 'crate::neuron_generation_process_identity_digest_v1(&self.identity)?',
             'root_profile: response.profile', 'initial: response.initial', 'frozen_scope: response.frozen_scope', 'terminal_head: response.terminal_head',
             'acceptance: response.acceptance', 'data_cut: response.data_cut', 'data.validate_data().map_err(AgentdError::Protocol)?',
             'self.client.require_completed_identity(&self.identity)?', 'let acknowledged = OriginalCompletedLearningAcknowledgementV1 {',
             'client: Arc::clone(&self.client)', 'identity: self.identity.clone()', 'fence.armed = false', 'Ok(acknowledged)'],
             top_level=['let data = OriginalQ24TerminalAcceptanceDataV1 {', 'data.validate_data().map_err(AgentdError::Protocol)?',
                        'self.client.require_completed_identity(&self.identity)?', 'let acknowledged = OriginalCompletedLearningAcknowledgementV1 {', 'fence.armed = false'])]),
    dict(path=ack, required=['impl OriginalCompletedLearningAcknowledgementV1'],
         forbidden=['HistoricalReadOperationV1', 'accept_completed_once(', 'read_completed_response(', 'exchange(', 'File::open', 'unsafe impl', 'Deserialize', 'Serialize', 'impl Clone', 'impl Deref', 'OriginalCompletedLearningContextV1'],
         required_function_order=[
             dict(function='fn data(', sequence=['&OriginalQ24TerminalAcceptanceDataV1', '&self.data']),
             dict(function='fn require_original_current(', sequence=['let mut fence = FenceReadOnDrop', 'armed: true', 'self.client.require_completed_identity(identity)?',
                  'if identity != &self.identity', 'return Err(AgentdError::Io(refused()))', 'let result = self.data.validate_data()',
                  'let after = self.client.require_completed_identity(identity);', 'after?;', 'result?;', 'fence.armed = false;', 'Ok(())'],
                  top_level=['let result = self.data.validate_data()', 'let after = self.client.require_completed_identity(identity);', 'after?;', 'result?;', 'fence.armed = false;'])]),
    dict(path=state, required=['fn attach_original_q24_terminal_acceptance(', 'fn read_original_q24_terminal_acceptance('], forbidden=[],
         required_function_order=[
             dict(function='fn attach_original_q24_terminal_acceptance(', sequence=[
                 'acknowledged: OriginalCompletedLearningAcknowledgementV1', 'self.require_original_completed_history_current()?;',
                 'OriginalCompletedLearningAcknowledgementV1::require_original_current(', 'let result = OriginalCompletedLearningAcknowledgementV1::data(&acknowledged)', '.validate_data()',
                 'let root_after = OriginalCompletedLearningAcknowledgementV1::require_original_current(', 'let generation_after = self.require_original_completed_history_current();',
                 'root_after?;', 'generation_after?;', 'result?;', 'self.original_q24_terminal_acceptance', '.set(acknowledged)', '.map_err('],
                 top_level=['let result = OriginalCompletedLearningAcknowledgementV1::data(&acknowledged)', 'let root_after = OriginalCompletedLearningAcknowledgementV1::require_original_current(',
                            'let generation_after = self.require_original_completed_history_current();', 'root_after?;', 'generation_after?;', 'result?;', 'self.original_q24_terminal_acceptance']),
             dict(function='fn read_original_q24_terminal_acceptance(', sequence=[
                 'self.require_original_completed_history_current()?;', 'let Some(acknowledged) = self.original_q24_terminal_acceptance.get() else {',
                 'self.require_original_completed_history_current()?;', 'return Ok(None);',
                 'OriginalCompletedLearningAcknowledgementV1::require_original_current(',
                 'let data = OriginalCompletedLearningAcknowledgementV1::data(acknowledged).clone();', 'let result = data.validate_data()',
                 'let root_after = OriginalCompletedLearningAcknowledgementV1::require_original_current(', 'let generation_after = self.require_original_completed_history_current();',
                 'root_after?;', 'generation_after?;', 'result?;', 'Ok(Some(data))'],
                 top_level=['let data = OriginalCompletedLearningAcknowledgementV1::data(acknowledged).clone();', 'let result = data.validate_data()',
                            'let root_after = OriginalCompletedLearningAcknowledgementV1::require_original_current(', 'let generation_after = self.require_original_completed_history_current();',
                            'root_after?;', 'generation_after?;', 'result?;'])]),
    dict(path=A + 'state.rs', required=['original_q24_terminal_acceptance: std::sync::OnceLock<', 'crate::root_completed_learning_history::OriginalCompletedLearningAcknowledgementV1,', 'original_q24_terminal_acceptance: std::sync::OnceLock::new(),'], forbidden=['OnceLock<OriginalQ24TerminalAcceptanceDataV1>']),
    dict(path=A + 'state_control.rs', required=['crate::AgentdMethod::OriginalQ24TerminalAcceptance {} => {', 'data: AgentdState::read_original_q24_terminal_acceptance(self)?'], forbidden=[]),
    dict(path=client, required=['fn original_q24_terminal_acceptance('], forbidden=[],
         required_function_order=[dict(function='fn original_q24_terminal_acceptance(', sequence=['&self,', 'self', '.send(AgentdRequest {', 'request_id: self.request_id()',
             'spawn_generation: self.spawn_generation', 'method: crate::AgentdMethod::OriginalQ24TerminalAcceptance {}', '.await?',
             'AgentdPayload::OriginalQ24TerminalAcceptance { data }', 'if let Some(data) = &data', 'data.validate_data().map_err(AgentdError::Protocol)?', 'Ok(data)', 'payload => unexpected(payload)'])]),
    dict(path=data, required=['#[serde(deny_unknown_fields)]', 'pub struct OriginalQ24TerminalAcceptanceDataV1 {'] + ['pub ' + name + ': String,' for name in ['identity_digest', 'root_profile', 'initial', 'frozen_scope', 'terminal_head', 'acceptance', 'data_cut']],
         forbidden=['File::open', 'std::fs', 'unsafe', 'OriginalCompletedLearningAcknowledgementV1', 'OriginalCompletedLearningHistoryV1'],
         required_function_order=[dict(function='fn validate_data(', sequence=['if self.schema != 1', '"identity_digest", &self.identity_digest', '"root_profile", &self.root_profile',
             '"initial", &self.initial', '"frozen_scope", &self.frozen_scope', '"terminal_head", &self.terminal_head', '"acceptance", &self.acceptance', '"data_cut", &self.data_cut',
             'value.len() != 64', 'byte.is_ascii_digit()', "(b'a'..=b'f').contains(&byte)", "value.bytes().all(|byte| byte == b'0')", 'return Err(format!(', 'Ok(())'])]),
    dict(path='codex-rs/hepta-agent-protocol/src/lib.rs', required=['pub use q24_terminal_acceptance::OriginalQ24TerminalAcceptanceDataV1;', 'OriginalQ24TerminalAcceptance {},', 'OriginalQ24TerminalAcceptance {', 'data: Option<OriginalQ24TerminalAcceptanceDataV1>'], forbidden=[]),
    dict(path=helper, required=['fn wait_for_original_terminal_acceptance('], forbidden=['HostAuthorityFrontierStore::initialize', 'FileAnchorWitnessStore::open'],
         required_function_order=[dict(function='fn wait_for_original_terminal_acceptance(', sequence=[
             'let client = running.client()?;', 'observe_original_record::<Refusal>', 'before.attempt >= previous_attempt', 'require_actual_acceptance(&accepted, &checkpoint, plan, terminal)?',
             'let digest = accepted.data_digest()?;', 'before == after && after.phase == Phase::Ready && after.attempt >= 2', 'if let Some(acknowledged)',
             'client.original_q24_terminal_acceptance().await?', 'acknowledged.validate_data()', 'crate::neuron_generation_process_identity_digest_v1(',
             'acknowledged.initial == initial.head_digest.to_string()', 'acknowledged.frozen_scope.as_str()', 'acknowledged.terminal_head',
             'acknowledged.acceptance == digest.to_string()', 'acknowledged.data_cut.as_str()', 'let actual = observe_original_record::<',
             'let final_attempt = observe_original_record::<Refusal>(', 'actual == accepted && final_attempt == after', 'super::root::write_json(',
             '&acknowledged,', 'running.require_live()?;', 'return Ok(digest);'], top_level=['let client = running.client()?;'])]),
]

def scalar(value):
    return json.dumps(value)

def table(kind, row):
    text = '\n[[' + kind + ']]\n'
    for key, value in row.items():
        if key != 'required_function_order':
            text += key + ' = ' + scalar(value) + '\n'
    for function in row.get('required_function_order', []):
        text += '[[' + kind + '.required_function_order]]\n'
        text += ''.join(key + ' = ' + scalar(value) + '\n' for key, value in function.items())
    return text

path = root / 'CALLERS.toml'
original = path.read_text()
before = tomllib.loads(original)
ids = [row['id'] for row in boundaries]
assert not set(ids) & {row['id'] for row in before['boundary']}
required = before['privileged_inventory']['required_boundary_ids']
old_line = 'required_boundary_ids = ' + json.dumps(required)
assert original.count(old_line) == 1
changed = original.replace(old_line, 'required_boundary_ids = ' + json.dumps(required + ids))
changed = changed.rstrip() + '\n' + ''.join(table('boundary', row) for row in boundaries) + ''.join(table('protected_file', row) for row in rows)
after = tomllib.loads(changed)
assert after['boundary'][:-len(boundaries)] == before['boundary']
assert after['protected_file'][:-len(rows)] == before['protected_file']
old_hash = hashlib.sha256(original.encode()).hexdigest()
new_hash = hashlib.sha256(changed.encode()).hexdigest()
allow_path = root / '.github/blob-size-allowlist.txt'
allow = allow_path.read_text()
needle = 'sha256:' + old_hash + ' CALLERS.toml'
assert allow.splitlines().count(needle) == 1
path.write_text(changed)
allow_path.write_text(allow.replace(needle, 'sha256:' + new_hash + ' CALLERS.toml'))
print(json.dumps({'old_boundaries_preserved':len(before['boundary']), 'old_protected_preserved':len(before['protected_file']), 'new_boundaries':ids, 'added_protected':len(rows), 'new_digest':new_hash}))
