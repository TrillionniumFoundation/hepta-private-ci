import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time

ROOT = Path('/home/qian-qi/work/hia-codex-deps-20261127-589c')
REPO = ROOT / 'src'
OUT = ROOT / 'stdin-native-gates-20261127'
OUT.mkdir()
RESULT = OUT / 'result.json'
BASE = '73a86e4c0f7b6d4772dc259796f7492323acb539'
TREE = '55663ab8e80b5caf32da71eb557a2140b2a8597c'
BRANCH = 'codex/hia-stdin-utf8-20261127-589c'
receipt = {'schema': 'codex.hia.stdin-native-gates.v1', 'passed': False,
           'source_head': BASE, 'expected_tree': TREE, 'commands': [],
           'installed_cli_qualified': False, 'whole_codex_rewritten': False}
env = os.environ.copy()
env.update({'PATH': str(ROOT / 'bin') + ':' + str(Path.home() / '.cargo/bin') + ':' + env['PATH'],
            'CARGO_TARGET_DIR': str(ROOT / 'chrono-target'), 'CARGO_BUILD_JOBS': '2',
            'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
            'CARGO_TERM_COLOR': 'never', 'RUSTUP_TOOLCHAIN': '1.96.1',
            'PYTHONDONTWRITEBYTECODE': '1'})


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save():
    temporary = RESULT.with_suffix('.tmp')
    temporary.write_text(json.dumps(receipt, indent=2) + '\n')
    temporary.replace(RESULT)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, env=env, text=True).strip()


def run(name, command, cwd):
    log = OUT / (name + '.log')
    started = time.monotonic()
    with log.open('wb') as handle:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=handle, stderr=subprocess.STDOUT)
    entry = {'name': name, 'command': command, 'cwd': str(cwd),
             'returncode': result.returncode, 'elapsed_seconds': time.monotonic() - started,
             'log': str(log), 'log_sha256': digest(log)}
    receipt['commands'].append(entry)
    save()
    print(json.dumps(entry), flush=True)
    return result.returncode


try:
    assert git('status', '--porcelain') == ''
    receipt['previous_head'] = git('rev-parse', 'HEAD')
    assert receipt['previous_head'] == 'a59ab22f8455ec62ebbd04167f2b8cc067a511f4'
    assert run('fetch-candidate', ['git', 'fetch', '--no-tags',
               'https://github.com/TrillionniumFoundation/hepta-private-ci.git',
               'codex/hia-union29-20261116-a90d'], REPO) == 0
    assert git('rev-parse', 'FETCH_HEAD') == BASE
    git('switch', '-c', BRANCH, BASE)
    patch = ROOT / 'stdin-utf8-source.patch'
    assert digest(patch) == 'bdeeb2c15f9f0d22267a99d90a7f6089853fa2ab66f93b6f854c44591ce52340'
    git('apply', '--check', '--index', str(patch))
    git('apply', '--index', str(patch))
    assert git('write-tree') == TREE
    receipt['source_tree'] = TREE
    receipt['source_inputs'] = {name: digest(REPO / name)
                              for name in git('diff', '--cached', '--name-only').splitlines()}
    archive = ROOT / 'stdin-native37.tar.gz'
    assert digest(archive) == '63cab79fb6ee8a754c039ead9d255518a638afc0131621e78bde28c4ae916627'
    native = ROOT / 'codex-hia-stdin-native37-final'
    assert not native.exists()
    with tarfile.open(archive) as package:
        for member in package.getmembers():
            parts = Path(member.name).parts
            assert parts[0] == native.name and '..' not in parts
            assert member.isfile() or member.isdir()
        package.extractall(ROOT)
    assert digest(native / 'build.json') == 'ac697058379eff7962783c94e06c607a62b05c7a0cf43bf76eb3837d10ef4a32'
    env['CODEX_HIA_NATIVE_LIB_DIR'] = str(native)
    rustc = subprocess.check_output(['rustup', 'which', '--toolchain', '1.96.1', 'rustc'],
                                    env=env, text=True).strip()
    caller_report = OUT / 'native-prompt-caller.json'
    caller_rc = run('native-prompt-caller', [sys.executable, '-B',
                    str(REPO / 'hia/tests/test_native_prompt_decode_caller.py'),
                    '--library-dir', str(native), '--rustc', rustc,
                    '--report', str(caller_report)], REPO)
    receipt['caller_report'] = {'path': str(caller_report), 'sha256': digest(caller_report)}
    caller = json.loads(caller_report.read_text())
    receipt['caller'] = {key: caller.get(key) for key in
                         ['passed', 'production_unit_tests', 'error', 'native_build']}
    receipt['caller']['stdin_cases'] = len(caller.get('stdin_cases', []))
    stream_rc = run('native-stream-parser', ['just', 'test', '-p', 'codex-utils-stream-parser',
                    '--features', 'codex-utils-stream-parser/hia-native', '--locked'], REPO / 'codex-rs')
    log = (OUT / 'native-stream-parser.log').read_text()
    receipt['stream_summary'] = [line for line in log.splitlines() if 'Summary [' in line]
    receipt['source_inputs_unchanged'] = all(digest(REPO / path) == value
                                            for path, value in receipt['source_inputs'].items())
    receipt['source_tree_after'] = git('write-tree')
    receipt['unstaged_diff'] = git('diff', '--stat')
    receipt['passed'] = (caller_rc == 0 and caller.get('passed') is True and stream_rc == 0
                         and receipt['source_inputs_unchanged']
                         and receipt['source_tree_after'] == TREE and not receipt['unstaged_diff'])
except Exception as error:
    receipt['error'] = f'{type(error).__name__}: {error}'
finally:
    save()
    print(json.dumps({'receipt': str(RESULT), 'sha256': digest(RESULT),
                      'passed': receipt['passed'], 'error': receipt.get('error'),
                      'caller': receipt.get('caller'), 'stream_summary': receipt.get('stream_summary')}), flush=True)
