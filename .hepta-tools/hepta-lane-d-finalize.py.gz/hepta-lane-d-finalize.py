#!/usr/bin/env python3
"""One-shot Lane D source/document finalizer run on the exact repair branch."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def write(rel: str, text: str) -> None:
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{label}: expected one match, found {count}")
    return text.replace(old, new, 1)


def regex_once(text: str, pattern: str, repl: str, label: str, flags: int = 0) -> str:
    updated, count = re.subn(pattern, repl, text, count=1, flags=flags)
    if count != 1:
        raise SystemExit(f"{label}: expected one regex match, found {count}")
    return updated


def privatize_struct(text: str, name: str) -> str:
    pattern = rf"(pub struct {re.escape(name)} \{{\n)(.*?)(\n\}})"
    match = re.search(pattern, text, flags=re.S)
    if not match:
        raise SystemExit(f"missing struct {name}")
    body = re.sub(r"(?m)^    pub ", "    ", match.group(2))
    return text[: match.start()] + match.group(1) + body + match.group(3) + text[match.end() :]


def insert_after_struct(text: str, name: str, addition: str) -> str:
    pattern = rf"(pub struct {re.escape(name)} \{{\n.*?\n\}}\n)"
    return regex_once(text, pattern, rf"\1\n{addition.strip()}\n", f"impl {name}", re.S)


def patch_planner() -> None:
    path = "codex-rs/hepta-control-plane/src/planner.rs"
    text = read(path)
    if "LANE_D_FINAL_HARDENING_V1" in text:
        return
    text = replace_once(
        text,
        "const MAX_RESOURCE_RESERVATIONS: usize = 32;",
        "const MAX_RESOURCE_RESERVATIONS: usize = 32;\n// LANE_D_FINAL_HARDENING_V1: output envelopes are sealed and revalidated.",
        "planner marker",
    )
    text = replace_once(
        text,
        "    pub revocation_frontier_digest: Digest32,\n    pub collected_at_micros: u64,\n    pub maximum_owner_age_micros: u64,",
        "    pub revocation_frontier_digest: Digest32,\n    pub snapshot_policy_digest: Digest32,\n    pub collected_at_micros: u64,\n    pub maximum_owner_age_micros: u64,",
        "snapshot request policy",
    )
    text = replace_once(
        text,
        "    pub revocation_frontier_digest: Digest32,\n    pub collected_at_micros: u64,\n    pub expires_at_micros: u64,\n    pub owner_summaries: Vec<OwnerSummaryV1>,",
        "    pub revocation_frontier_digest: Digest32,\n    pub snapshot_policy_digest: Digest32,\n    pub maximum_owner_age_micros: u64,\n    pub required_owner_set_digest: Digest32,\n    pub collected_at_micros: u64,\n    pub expires_at_micros: u64,\n    pub owner_summaries: Vec<OwnerSummaryV1>,",
        "snapshot output policy",
    )
    text = replace_once(
        text,
        "    pub deadline_micros: u64,\n    pub candidates: Vec<PlanCandidateV1>,\n    pub resource_reservations: Vec<ResourceReservationV1>,",
        "    pub deadline_micros: u64,\n    pub evaluation_policy_digest: Digest32,\n    pub resource_profile_digest: Digest32,\n    pub candidates: Vec<PlanCandidateV1>,\n    pub resource_reservations: Vec<ResourceReservationV1>,",
        "planning request policies",
    )
    text = replace_once(
        text,
        "    pub snapshot_digest: Digest32,\n    pub source_candidate_set_digest: Digest32,",
        "    pub snapshot_digest: Digest32,\n    pub evaluation_policy_digest: Digest32,\n    pub resource_profile_digest: Digest32,\n    pub source_candidate_set_digest: Digest32,",
        "prepared policies",
    )
    text = replace_once(
        text,
        "    pub source_candidate_set_digest: Digest32,\n    pub candidate_set_digest: Digest32,\n    pub resource_rejected_candidate_ids: Vec<StableId>,\n    pub evaluation_policy_digest: Digest32,",
        "    pub source_candidate_set_digest: Digest32,\n    pub candidate_set_digest: Digest32,\n    pub prepared_digest: Digest32,\n    pub resource_profile_digest: Digest32,\n    pub resource_rejected_candidate_ids: Vec<StableId>,\n    pub evaluation_policy_digest: Digest32,",
        "receipt prepared binding",
    )

    for name in [
        "GlobalStateSnapshotV1",
        "PreparedPlanInputV1",
        "NduPlanEvaluationV1",
        "FeasiblePlanReceiptV1",
        "GrantRequestSetV1",
    ]:
        text = privatize_struct(text, name)

    text = insert_after_struct(
        text,
        "GlobalStateSnapshotV1",
        """
impl GlobalStateSnapshotV1 {
    #[must_use]
    pub const fn objective_digest(&self) -> Digest32 { self.objective_digest }
    #[must_use]
    pub const fn body_generation(&self) -> Generation { self.body_generation }
    #[must_use]
    pub const fn configuration_digest(&self) -> Digest32 { self.configuration_digest }
    #[must_use]
    pub const fn revocation_frontier_digest(&self) -> Digest32 { self.revocation_frontier_digest }
    #[must_use]
    pub const fn snapshot_policy_digest(&self) -> Digest32 { self.snapshot_policy_digest }
    #[must_use]
    pub const fn maximum_owner_age_micros(&self) -> u64 { self.maximum_owner_age_micros }
    #[must_use]
    pub const fn required_owner_set_digest(&self) -> Digest32 { self.required_owner_set_digest }
    #[must_use]
    pub const fn collected_at_micros(&self) -> u64 { self.collected_at_micros }
    #[must_use]
    pub const fn expires_at_micros(&self) -> u64 { self.expires_at_micros }
    #[must_use]
    pub fn owner_summaries(&self) -> &[OwnerSummaryV1] { &self.owner_summaries }
    #[must_use]
    pub fn missing_owner_ids(&self) -> &[StableId] { &self.missing_owner_ids }
    #[must_use]
    pub fn stale_owner_ids(&self) -> &[StableId] { &self.stale_owner_ids }
    #[must_use]
    pub fn unavailable_owner_ids(&self) -> &[StableId] { &self.unavailable_owner_ids }
    #[must_use]
    pub const fn snapshot_digest(&self) -> Digest32 { self.snapshot_digest }
}
""",
    )
    text = insert_after_struct(
        text,
        "PreparedPlanInputV1",
        """
impl PreparedPlanInputV1 {
    #[must_use]
    pub fn plan_id(&self) -> &StableId { &self.plan_id }
    #[must_use]
    pub const fn objective_digest(&self) -> Digest32 { self.objective_digest }
    #[must_use]
    pub const fn body_generation(&self) -> Generation { self.body_generation }
    #[must_use]
    pub const fn configuration_digest(&self) -> Digest32 { self.configuration_digest }
    #[must_use]
    pub const fn revocation_frontier_digest(&self) -> Digest32 { self.revocation_frontier_digest }
    #[must_use]
    pub const fn snapshot_digest(&self) -> Digest32 { self.snapshot_digest }
    #[must_use]
    pub const fn evaluation_policy_digest(&self) -> Digest32 { self.evaluation_policy_digest }
    #[must_use]
    pub const fn resource_profile_digest(&self) -> Digest32 { self.resource_profile_digest }
    #[must_use]
    pub const fn source_candidate_set_digest(&self) -> Digest32 { self.source_candidate_set_digest }
    #[must_use]
    pub const fn candidate_set_digest(&self) -> Digest32 { self.candidate_set_digest }
    #[must_use]
    pub fn feasible_candidates(&self) -> &[PlanCandidateV1] { &self.feasible_candidates }
    #[must_use]
    pub fn resource_rejected_candidate_ids(&self) -> &[StableId] { &self.resource_rejected_candidate_ids }
    #[must_use]
    pub const fn expires_at_micros(&self) -> u64 { self.expires_at_micros }
    #[must_use]
    pub const fn prepared_digest(&self) -> Digest32 { self.prepared_digest }
    #[must_use]
    pub const fn authority(&self) -> &AuthorityPosture { &self.authority }
}
""",
    )
    text = insert_after_struct(
        text,
        "NduPlanEvaluationV1",
        """
impl NduPlanEvaluationV1 {
    #[must_use]
    pub const fn objective_digest(&self) -> Digest32 { self.objective_digest }
    #[must_use]
    pub const fn body_generation(&self) -> Generation { self.body_generation }
    #[must_use]
    pub const fn evaluation_policy_digest(&self) -> Digest32 { self.evaluation_policy_digest }
    #[must_use]
    pub const fn evaluation_digest(&self) -> Digest32 { self.evaluation_digest }
    #[must_use]
    pub fn evaluated_candidate_ids(&self) -> &[StableId] { &self.evaluated_candidate_ids }
    #[must_use]
    pub fn rejected_candidate_ids(&self) -> &[StableId] { &self.rejected_candidate_ids }
    #[must_use]
    pub fn pareto_candidate_ids(&self) -> &[StableId] { &self.pareto_candidate_ids }
    #[must_use]
    pub fn advisory_candidate_id(&self) -> Option<&StableId> { self.advisory_candidate_id.as_ref() }
    #[must_use]
    pub const fn uncertainty_digest(&self) -> Digest32 { self.uncertainty_digest }
    #[must_use]
    pub const fn disposition(&self) -> PlanningEvaluationDispositionV1 { self.disposition }
    #[must_use]
    pub const fn binding_digest(&self) -> Digest32 { self.binding_digest }
    #[must_use]
    pub const fn authority(&self) -> &AuthorityPosture { &self.authority }
}
""",
    )
    text = insert_after_struct(
        text,
        "FeasiblePlanReceiptV1",
        """
impl FeasiblePlanReceiptV1 {
    #[must_use]
    pub fn plan_id(&self) -> &StableId { &self.plan_id }
    #[must_use]
    pub const fn objective_digest(&self) -> Digest32 { self.objective_digest }
    #[must_use]
    pub const fn body_generation(&self) -> Generation { self.body_generation }
    #[must_use]
    pub const fn configuration_digest(&self) -> Digest32 { self.configuration_digest }
    #[must_use]
    pub const fn revocation_frontier_digest(&self) -> Digest32 { self.revocation_frontier_digest }
    #[must_use]
    pub const fn snapshot_digest(&self) -> Digest32 { self.snapshot_digest }
    #[must_use]
    pub const fn source_candidate_set_digest(&self) -> Digest32 { self.source_candidate_set_digest }
    #[must_use]
    pub const fn candidate_set_digest(&self) -> Digest32 { self.candidate_set_digest }
    #[must_use]
    pub const fn prepared_digest(&self) -> Digest32 { self.prepared_digest }
    #[must_use]
    pub const fn resource_profile_digest(&self) -> Digest32 { self.resource_profile_digest }
    #[must_use]
    pub fn resource_rejected_candidate_ids(&self) -> &[StableId] { &self.resource_rejected_candidate_ids }
    #[must_use]
    pub const fn evaluation_policy_digest(&self) -> Digest32 { self.evaluation_policy_digest }
    #[must_use]
    pub const fn ndu_evaluation_digest(&self) -> Digest32 { self.ndu_evaluation_digest }
    #[must_use]
    pub const fn ndu_binding_digest(&self) -> Digest32 { self.ndu_binding_digest }
    #[must_use]
    pub const fn evaluation_disposition(&self) -> PlanningEvaluationDispositionV1 { self.evaluation_disposition }
    #[must_use]
    pub fn chosen_candidate_id(&self) -> Option<&StableId> { self.chosen_candidate_id.as_ref() }
    #[must_use]
    pub const fn chosen_plan_digest(&self) -> Option<Digest32> { self.chosen_plan_digest }
    #[must_use]
    pub const fn uncertainty_digest(&self) -> Digest32 { self.uncertainty_digest }
    #[must_use]
    pub const fn expires_at_micros(&self) -> u64 { self.expires_at_micros }
    #[must_use]
    pub const fn search_disclosure(&self) -> SearchDisclosureV1 { self.search_disclosure }
    #[must_use]
    pub const fn receipt_digest(&self) -> Digest32 { self.receipt_digest }
    #[must_use]
    pub const fn authority(&self) -> &AuthorityPosture { &self.authority }
}
""",
    )
    text = insert_after_struct(
        text,
        "GrantRequestSetV1",
        """
impl GrantRequestSetV1 {
    #[must_use]
    pub const fn plan_receipt_digest(&self) -> Digest32 { self.plan_receipt_digest }
    #[must_use]
    pub fn requests(&self) -> &[GrantRequestV1] { &self.requests }
    #[must_use]
    pub const fn request_set_digest(&self) -> Digest32 { self.request_set_digest }
    #[must_use]
    pub const fn authority(&self) -> &AuthorityPosture { &self.authority }
}
""",
    )

    text = replace_once(
        text,
        '    require_digest(request.revocation_frontier_digest, "revocation frontier")?;\n    if request.maximum_owner_age_micros == 0 {',
        '    require_digest(request.revocation_frontier_digest, "revocation frontier")?;\n    require_digest(request.snapshot_policy_digest, "snapshot policy")?;\n    if request.maximum_owner_age_micros == 0 {',
        "snapshot policy validation",
    )
    text = replace_once(
        text,
        "    request.required_owner_ids.sort();\n    reject_duplicate_ids(&request.required_owner_ids, PlannerError::DuplicateOwner)?;",
        "    request.required_owner_ids.sort();\n    reject_duplicate_ids(&request.required_owner_ids, PlannerError::DuplicateOwner)?;\n    let required_owner_set_digest = digest_owner_set(&request.required_owner_ids);",
        "required owner digest",
    )
    text = replace_once(
        text,
        "        revocation_frontier_digest: request.revocation_frontier_digest,\n        collected_at_micros: request.collected_at_micros,",
        "        revocation_frontier_digest: request.revocation_frontier_digest,\n        snapshot_policy_digest: request.snapshot_policy_digest,\n        maximum_owner_age_micros: request.maximum_owner_age_micros,\n        required_owner_set_digest,\n        collected_at_micros: request.collected_at_micros,",
        "snapshot policy output",
    )
    text = replace_once(
        text,
        "    if request.deadline_micros <= request.now_micros {",
        '    require_digest(request.evaluation_policy_digest, "evaluation policy")?;\n    require_digest(request.resource_profile_digest, "resource profile")?;\n    if request.deadline_micros <= request.now_micros {',
        "planning policy validation",
    )
    text = replace_once(
        text,
        "    if request.resource_reservations.len() > MAX_RESOURCE_RESERVATIONS {",
        "    if request.resource_reservations.is_empty()\n        || request.resource_reservations.len() > MAX_RESOURCE_RESERVATIONS\n    {",
        "resource reservation nonempty",
    )
    text = replace_once(
        text,
        "        snapshot_digest: snapshot.snapshot_digest,\n        source_candidate_set_digest,",
        "        snapshot_digest: snapshot.snapshot_digest,\n        evaluation_policy_digest: request.evaluation_policy_digest,\n        resource_profile_digest: request.resource_profile_digest,\n        source_candidate_set_digest,",
        "prepared policy output",
    )
    text = replace_once(
        text,
        "    if prepared.prepared_digest != digest_prepared_plan(prepared)\n        || prepared.authority.grants_any()",
        "    if prepared.prepared_digest != digest_prepared_plan(prepared)\n        || prepared.candidate_set_digest != digest_candidates(&prepared.feasible_candidates)\n        || prepared.authority.grants_any()",
        "finalize candidate rehash",
    )
    text = replace_once(
        text,
        "    if evaluation.binding_digest != digest_ndu_evaluation(evaluation)\n        || evaluation.authority.grants_any()",
        "    if evaluation.binding_digest != digest_ndu_evaluation(evaluation)\n        || evaluation.evaluation_policy_digest != prepared.evaluation_policy_digest\n        || evaluation.authority.grants_any()",
        "finalize policy binding",
    )
    text = replace_once(
        text,
        "        candidate_set_digest: prepared.candidate_set_digest,\n        resource_rejected_candidate_ids: prepared.resource_rejected_candidate_ids.clone(),",
        "        candidate_set_digest: prepared.candidate_set_digest,\n        prepared_digest: prepared.prepared_digest,\n        resource_profile_digest: prepared.resource_profile_digest,\n        resource_rejected_candidate_ids: prepared.resource_rejected_candidate_ids.clone(),",
        "receipt policy fields",
    )
    text = replace_once(
        text,
        ") -> Result<GrantRequestSetV1, PlannerError> {\n    if receipt.receipt_digest != digest_plan_receipt(receipt)",
        ") -> Result<GrantRequestSetV1, PlannerError> {\n    validate_snapshot_for_planning(snapshot, now_micros)?;\n    if receipt.receipt_digest != digest_plan_receipt(receipt)",
        "grant snapshot revalidation",
    )
    text = replace_once(
        text,
        "        || prepared.prepared_digest != digest_prepared_plan(prepared)\n        || prepared.authority.grants_any()",
        "        || prepared.prepared_digest != digest_prepared_plan(prepared)\n        || prepared.candidate_set_digest != digest_candidates(&prepared.feasible_candidates)\n        || prepared.authority.grants_any()",
        "grant candidate rehash",
    )
    text = replace_once(
        text,
        "        || receipt.candidate_set_digest != prepared.candidate_set_digest\n        || receipt.objective_digest != snapshot.objective_digest",
        "        || receipt.candidate_set_digest != prepared.candidate_set_digest\n        || receipt.prepared_digest != prepared.prepared_digest\n        || receipt.resource_profile_digest != prepared.resource_profile_digest\n        || receipt.evaluation_policy_digest != prepared.evaluation_policy_digest\n        || receipt.objective_digest != snapshot.objective_digest",
        "grant policy binding",
    )
    text = replace_once(
        text,
        "fn digest_snapshot(snapshot: &GlobalStateSnapshotV1) -> Digest32 {",
        "fn digest_owner_set(owners: &[StableId]) -> Digest32 {\n    let mut bytes = b\"hepta.control.required-owner-set.v1\".to_vec();\n    push_ids(&mut bytes, owners);\n    Digest32::of_bytes(&bytes)\n}\n\nfn digest_snapshot(snapshot: &GlobalStateSnapshotV1) -> Digest32 {",
        "owner set digest helper",
    )
    text = replace_once(
        text,
        "    push_digest(&mut bytes, snapshot.revocation_frontier_digest);\n    push_u64(&mut bytes, snapshot.collected_at_micros);",
        "    push_digest(&mut bytes, snapshot.revocation_frontier_digest);\n    push_digest(&mut bytes, snapshot.snapshot_policy_digest);\n    push_u64(&mut bytes, snapshot.maximum_owner_age_micros);\n    push_digest(&mut bytes, snapshot.required_owner_set_digest);\n    push_u64(&mut bytes, snapshot.collected_at_micros);",
        "snapshot digest policies",
    )
    text = replace_once(
        text,
        "    push_digest(&mut bytes, prepared.snapshot_digest);\n    push_digest(&mut bytes, prepared.source_candidate_set_digest);",
        "    push_digest(&mut bytes, prepared.snapshot_digest);\n    push_digest(&mut bytes, prepared.evaluation_policy_digest);\n    push_digest(&mut bytes, prepared.resource_profile_digest);\n    push_digest(&mut bytes, prepared.source_candidate_set_digest);",
        "prepared digest policies",
    )
    text = replace_once(
        text,
        "    push_digest(&mut bytes, receipt.candidate_set_digest);\n    push_ids(&mut bytes, &receipt.resource_rejected_candidate_ids);",
        "    push_digest(&mut bytes, receipt.candidate_set_digest);\n    push_digest(&mut bytes, receipt.prepared_digest);\n    push_digest(&mut bytes, receipt.resource_profile_digest);\n    push_ids(&mut bytes, &receipt.resource_rejected_candidate_ids);",
        "receipt digest policies",
    )
    write(path, text)


def patch_planner_tests() -> None:
    path = "codex-rs/hepta-control-plane/src/planner_tests.rs"
    text = read(path)
    if "tampered_candidate_payload_is_rejected_before_grant_request" in text:
        return
    text = replace_once(
        text,
        "        revocation_frontier_digest: digest(\"revocations\"),\n        collected_at_micros: 1_000,",
        "        revocation_frontier_digest: digest(\"revocations\"),\n        snapshot_policy_digest: digest(\"snapshot-policy\"),\n        collected_at_micros: 1_000,",
        "test snapshot policy",
    )
    text = replace_once(
        text,
        "        deadline_micros: 1_900,\n        candidates: vec![candidate(\"abstain\", 0), candidate(\"work\", work_resource)],",
        "        deadline_micros: 1_900,\n        evaluation_policy_digest: digest(\"policy\"),\n        resource_profile_digest: digest(\"resource-profile\"),\n        candidates: vec![candidate(\"abstain\", 0), candidate(\"work\", work_resource)],",
        "test planning policies",
    )
    text += r'''

#[test]
fn tampered_candidate_payload_is_rejected_before_grant_request() {
    let snapshot = must(collect_snapshot(
        snapshot_request(),
        vec![summary(OwnerReadinessV1::Ready, 950, 1_800)],
    ));
    let prepared = must(prepare_plan(&snapshot, planning_request(1)));
    let ndu = evaluation(
        &prepared,
        PlanningEvaluationDispositionV1::UniqueParetoRecommendation,
        vec![id("work")],
        Some(id("work")),
    );
    let receipt = must(finalize_plan(&snapshot, &prepared, &ndu, 1_100));
    let mut tampered = prepared.clone();
    let candidate = tampered
        .feasible_candidates
        .iter_mut()
        .find(|candidate| candidate.candidate_id == id("work"))
        .expect("work candidate");
    candidate.final_payload_digests[0] = digest("tampered-payload");

    assert_eq!(
        must_err(request_execution_grants(
            &snapshot,
            &tampered,
            &receipt,
            1_200,
        )),
        PlannerError::PreparedPlanMismatch
    );
}

#[test]
fn tampered_candidate_operation_resource_or_owner_is_rejected() {
    let snapshot = must(collect_snapshot(
        snapshot_request(),
        vec![summary(OwnerReadinessV1::Ready, 950, 1_800)],
    ));
    let prepared = must(prepare_plan(&snapshot, planning_request(1)));
    let ndu = evaluation(
        &prepared,
        PlanningEvaluationDispositionV1::UniqueParetoRecommendation,
        vec![id("work")],
        Some(id("work")),
    );
    let receipt = must(finalize_plan(&snapshot, &prepared, &ndu, 1_100));

    let mut operation = prepared.clone();
    operation.feasible_candidates[1].operation_id = id("tampered-operation");
    assert_eq!(
        must_err(request_execution_grants(&snapshot, &operation, &receipt, 1_200)),
        PlannerError::PreparedPlanMismatch
    );

    let mut resource = prepared.clone();
    resource.feasible_candidates[1].resource_costs[0].value = q32(2);
    assert_eq!(
        must_err(request_execution_grants(&snapshot, &resource, &receipt, 1_200)),
        PlannerError::PreparedPlanMismatch
    );

    let mut owner = prepared.clone();
    owner.feasible_candidates[1].required_owner_ids.clear();
    assert_eq!(
        must_err(request_execution_grants(&snapshot, &owner, &receipt, 1_200)),
        PlannerError::PreparedPlanMismatch
    );
}

#[test]
fn grant_request_revalidates_snapshot_masks_and_digest() {
    let snapshot = must(collect_snapshot(
        snapshot_request(),
        vec![summary(OwnerReadinessV1::Ready, 950, 1_800)],
    ));
    let prepared = must(prepare_plan(&snapshot, planning_request(1)));
    let ndu = evaluation(
        &prepared,
        PlanningEvaluationDispositionV1::UniqueParetoRecommendation,
        vec![id("work")],
        Some(id("work")),
    );
    let receipt = must(finalize_plan(&snapshot, &prepared, &ndu, 1_100));
    let mut tampered = snapshot.clone();
    tampered.stale_owner_ids.push(id("planner"));

    assert_eq!(
        must_err(request_execution_grants(
            &tampered,
            &prepared,
            &receipt,
            1_200,
        )),
        PlannerError::PreparedPlanMismatch
    );
}

#[test]
fn evaluation_policy_is_frozen_before_ndu_evaluation() {
    let snapshot = must(collect_snapshot(
        snapshot_request(),
        vec![summary(OwnerReadinessV1::Ready, 950, 1_800)],
    ));
    let prepared = must(prepare_plan(&snapshot, planning_request(1)));
    let ndu = must(bind_ndu_plan_evaluation_v1(NduPlanEvaluationInputV1 {
        objective_digest: prepared.objective_digest,
        body_generation: prepared.body_generation,
        evaluation_policy_digest: digest("different-policy"),
        evaluation_digest: digest("ndu-evaluation"),
        evaluated_candidate_ids: prepared
            .feasible_candidates
            .iter()
            .map(|candidate| candidate.candidate_id.clone())
            .collect(),
        rejected_candidate_ids: Vec::new(),
        pareto_candidate_ids: vec![id("work")],
        advisory_candidate_id: Some(id("work")),
        uncertainty_digest: digest("uncertainty"),
        disposition: PlanningEvaluationDispositionV1::UniqueParetoRecommendation,
    }));

    assert_eq!(
        must_err(finalize_plan(&snapshot, &prepared, &ndu, 1_100)),
        PlannerError::EvaluationBindingMismatch
    );
}

#[test]
fn resource_profile_and_snapshot_policy_are_mandatory_and_digest_bound() {
    let snapshot = must(collect_snapshot(
        snapshot_request(),
        vec![summary(OwnerReadinessV1::Ready, 950, 1_800)],
    ));
    let mut request = planning_request(1);
    request.resource_profile_digest = Digest32::ZERO;
    assert_eq!(
        must_err(prepare_plan(&snapshot, request)),
        PlannerError::EmptyDigest("resource profile")
    );

    let mut changed = snapshot.clone();
    changed.snapshot_policy_digest = digest("changed-snapshot-policy");
    assert_eq!(
        must_err(prepare_plan(&changed, planning_request(1))),
        PlannerError::PreparedPlanMismatch
    );
}
'''
    write(path, text)


def patch_ndu() -> None:
    path = "codex-rs/hepta-ndu/src/evaluator.rs"
    text = read(path)
    if "hepta.ndu.contribution.v1" not in text:
        text = replace_once(
            text,
            'const EVALUATION_V2_DIGEST_DOMAIN: &[u8] = b"hepta.ndu.evaluation.v2";',
            'const EVALUATION_V2_DIGEST_DOMAIN: &[u8] = b"hepta.ndu.evaluation.v2";\nconst CONTRIBUTION_DIGEST_DOMAIN: &[u8] = b"hepta.ndu.contribution.v1";',
            "NDU contribution domain",
        )
        text = replace_once(
            text,
            "    validate_known_axes(&contribution, profile)?;\n    let candidate_id = contribution.candidate_id.clone();",
            "    validate_known_axes(&contribution, profile)?;\n    let contribution_digest = digest_contribution(&contribution);\n    let candidate_id = contribution.candidate_id.clone();",
            "NDU contribution digest",
        )
        text = replace_once(
            text,
            "    accumulator\n        .support_digests\n        .push(contribution.support_digest);",
            "    accumulator.support_digests.push(contribution_digest);",
            "NDU support provenance",
        )
        text = replace_once(
            text,
            "    for (axis, _) in &profile.dimensions {\n        if !accumulator.utility.contains_key(axis) {\n            return Err(NduError::MissingAxis {\n                candidate: candidate_id.to_string(),\n                axis: axis.to_string(),\n            });\n        }\n    }",
            "    for (axis, _) in &profile.dimensions {\n        if !accumulator.utility.contains_key(axis) {\n            return Err(NduError::MissingAxis {\n                candidate: candidate_id.to_string(),\n                axis: axis.to_string(),\n            });\n        }\n        if !accumulator.uncertainty.contains_key(axis) {\n            return Err(NduError::MissingAxis {\n                candidate: candidate_id.to_string(),\n                axis: format!(\"uncertainty:{axis}\"),\n            });\n        }\n    }",
            "NDU uncertainty completeness",
        )
        text = replace_once(
            text,
            "fn digest_evaluation_policy(policy: &EvaluationPolicyV1) -> Digest32 {",
            "fn digest_contribution(contribution: &UtilityContribution) -> Digest32 {\n    let mut bytes = Vec::new();\n    bytes.extend_from_slice(CONTRIBUTION_DIGEST_DOMAIN);\n    push_id(&mut bytes, &contribution.candidate_id);\n    push_id(&mut bytes, &contribution.organ_id);\n    bytes.extend_from_slice(contribution.objective_digest.as_array());\n    bytes.extend_from_slice(&contribution.generation.get().to_be_bytes());\n    bytes.push(match contribution.feasibility {\n        FeasibilityPosture::Feasible => 0,\n        FeasibilityPosture::HardConstraintViolation => 1,\n    });\n    push_axis_values(&mut bytes, &contribution.utility);\n    push_axis_values(&mut bytes, &contribution.risk);\n    push_axis_values(&mut bytes, &contribution.resource);\n    push_axis_values(&mut bytes, &contribution.uncertainty);\n    bytes.extend_from_slice(contribution.support_digest.as_array());\n    Digest32::of_bytes(&bytes)\n}\n\nfn digest_evaluation_policy(policy: &EvaluationPolicyV1) -> Digest32 {",
            "NDU digest helper",
        )
        write(path, text)

    tests_path = "codex-rs/hepta-ndu/src/evaluator_tests.rs"
    tests = read(tests_path)
    if "missing_uncertainty_axis_is_unavailable" not in tests:
        tests = replace_once(
            tests,
            "        uncertainty: vec![AxisValue {\n            axis: id(\"success\"),\n            value: FixedQ32::ZERO,\n        }],",
            "        uncertainty: vec![\n            AxisValue {\n                axis: id(\"success\"),\n                value: FixedQ32::ZERO,\n            },\n            AxisValue {\n                axis: id(\"latency\"),\n                value: FixedQ32::ZERO,\n            },\n        ],",
            "NDU test uncertainty completeness",
        )
        tests += r'''

#[test]
fn missing_uncertainty_axis_is_unavailable() {
    let abstain = contribution("abstain", 0, 0);
    let mut work = contribution("work", 1, 1);
    work.uncertainty.retain(|value| value.axis == id("success"));

    let error = must_err(evaluate_candidates(
        set(vec![abstain, work]),
        profile(),
        None,
    ));
    assert_eq!(error.code(), "NDU-E003");
}

#[test]
fn candidate_support_digest_binds_organ_and_contribution_semantics() {
    let mut open_profile = profile();
    open_profile.required_organs.organ_ids.clear();
    let first = must(evaluate_candidates(
        set(vec![contribution("abstain", 0, 0), contribution("work", 1, 1)]),
        open_profile.clone(),
        None,
    ));
    let first_support = first
        .evaluated_candidates
        .iter()
        .find(|candidate| candidate.candidate_id == id("work"))
        .expect("work candidate")
        .support_digest;

    let mut changed = contribution("work", 1, 1);
    changed.organ_id = id("other-organ");
    let second = must(evaluate_candidates(
        set(vec![contribution("abstain", 0, 0), changed]),
        open_profile,
        None,
    ));
    let second_support = second
        .evaluated_candidates
        .iter()
        .find(|candidate| candidate.candidate_id == id("work"))
        .expect("work candidate")
        .support_digest;

    assert_ne!(first_support, second_support);
}
'''
        write(tests_path, tests)


def patch_objective() -> None:
    path = "codex-rs/hepta-objective/src/objective_admission.rs"
    text = read(path)
    if "MAX_PROFILE_CONSTRAINTS" not in text:
        text = replace_once(
            text,
            "const Q32_ONE_RAW: i128 = 1_i128 << 32;",
            "const Q32_ONE_RAW: i128 = 1_i128 << 32;\nconst MAX_PROFILE_CONSTRAINTS: usize = 256;\nconst MAX_PROFILE_PREDICATES: usize = 128;\nconst MAX_PROFILE_ACTIONS: usize = 128;\nconst MAX_PROFILE_SOFT_DIMENSIONS: usize = 64;\nconst MAX_PROFILE_EVIDENCE_REQUIREMENTS: usize = 128;\nconst MAX_PROFILE_ABSTENTION_RULES: usize = 64;\nconst MAX_PROFILE_ENCODED_BYTES: usize = 256 * 1024;",
            "objective profile constants",
        )
        text = replace_once(
            text,
            "    if profile.allowed_locales.is_empty()\n        || profile.allowed_locales.len() > MAX_PROFILE_LOCALES\n        || profile.allowed_trusted_source_identities.len() > MAX_PROFILE_SOURCES\n    {\n        return Err(ObjectiveAdmissionError::InvalidProfile(\"collection bound\"));\n    }",
            "    if profile.allowed_locales.is_empty()\n        || profile.allowed_locales.len() > MAX_PROFILE_LOCALES\n        || profile.allowed_trusted_source_identities.len() > MAX_PROFILE_SOURCES\n    {\n        return Err(ObjectiveAdmissionError::InvalidProfile(\"collection bound\"));\n    }\n    if profile.constraints.len() > MAX_PROFILE_CONSTRAINTS\n        || profile.predicates.len() > MAX_PROFILE_PREDICATES\n        || profile.actions.len() > MAX_PROFILE_ACTIONS\n        || profile.soft_dimensions.len() > MAX_PROFILE_SOFT_DIMENSIONS\n        || profile.evidence_requirements.len() > MAX_PROFILE_EVIDENCE_REQUIREMENTS\n        || profile.risk.abstention_rules.len() > MAX_PROFILE_ABSTENTION_RULES\n    {\n        return Err(ObjectiveAdmissionError::InvalidProfile(\"mapping count bound\"));\n    }\n    if profile_encoded_size(profile) > MAX_PROFILE_ENCODED_BYTES {\n        return Err(ObjectiveAdmissionError::InvalidProfile(\"profile byte bound\"));\n    }\n    if !(profile.risk.low_value <= profile.risk.medium_value\n        && profile.risk.medium_value <= profile.risk.high_value\n        && profile.risk.high_value <= profile.risk.critical_value\n        && profile.risk.rollback_none_value <= profile.risk.rollback_reversible_value\n        && profile.risk.rollback_reversible_value\n            <= profile.risk.rollback_compensatable_value\n        && profile.risk.rollback_compensatable_value\n            <= profile.risk.rollback_irreversible_value)\n    {\n        return Err(ObjectiveAdmissionError::InvalidProfile(\"risk ordering\"));\n    }",
            "objective profile validation",
        )
        text = replace_once(
            text,
            "fn validate_source_mappings(\n    profile: &ObjectiveAdmissionProfileV1,\n) -> Result<(), ObjectiveAdmissionError> {",
            "fn profile_encoded_size(profile: &ObjectiveAdmissionProfileV1) -> usize {\n    let mut size = 1024usize;\n    let mut add = |value: &str| { size = size.saturating_add(value.len() + 4); };\n    add(profile.profile_id.as_str());\n    add(profile.principal_scope.as_str());\n    for value in &profile.allowed_locales { add(value); }\n    for value in &profile.allowed_trusted_source_identities { add(value.as_str()); }\n    for value in &profile.constraints {\n        add(&value.source_constraint_id); add(&value.expected_unit); add(value.axis.as_str());\n    }\n    for value in &profile.predicates {\n        add(&value.source_predicate_id); add(&value.expected_unit); add(value.axis.as_str());\n    }\n    for value in &profile.actions {\n        add(&value.source_action_class); add(value.action_id.as_str());\n    }\n    for value in &profile.soft_dimensions {\n        add(&value.source_dimension_id); add(&value.expected_unit); add(value.dimension.as_str());\n    }\n    for value in &profile.evidence_requirements {\n        add(&value.source_requirement_id); add(value.axis.as_str());\n    }\n    for value in resource_mappings(&profile.resources) {\n        add(value.constraint_id.as_str()); add(value.axis.as_str()); add(value.evidence_source.as_str());\n    }\n    add(profile.risk.evidence_source.as_str());\n    for value in [\n        &profile.risk.risk_constraint_id, &profile.risk.risk_axis,\n        &profile.risk.rollback_constraint_id, &profile.risk.rollback_axis,\n        &profile.risk.compensation_constraint_id, &profile.risk.compensation_axis,\n        &profile.risk.abstention_constraint_id, &profile.risk.abstention_axis,\n    ] { add(value.as_str()); }\n    for value in &profile.risk.abstention_rules { add(&value.source_rule); }\n    size\n}\n\nfn validate_source_mappings(\n    profile: &ObjectiveAdmissionProfileV1,\n) -> Result<(), ObjectiveAdmissionError> {",
            "objective profile size helper",
        )
        write(path, text)

    tests_path = "codex-rs/hepta-objective/src/objective_admission_tests.rs"
    tests = read(tests_path)
    if "oversized_profile_mapping_set_is_rejected" not in tests:
        tests += r'''

#[test]
fn oversized_profile_mapping_set_is_rejected() {
    let mut profile = profile();
    profile.constraints = (0..257)
        .map(|index| ObjectiveConstraintProfileV1 {
            source_constraint_id: format!("constraint.{index}"),
            expected_unit: "unit".to_string(),
            class: ConstraintClass::Task,
            axis: id(&format!("axis.{index}")),
        })
        .collect();
    assert_eq!(
        ObjectiveAdmissionError::InvalidProfile("mapping count bound"),
        profile.digest().expect_err("oversized profile must reject")
    );
}

#[test]
fn risk_profile_ordering_is_monotone() {
    let mut profile = profile();
    profile.risk.high_value = FixedQ32::from_raw(0);
    assert_eq!(
        ObjectiveAdmissionError::InvalidProfile("risk ordering"),
        profile.digest().expect_err("non-monotone risk profile must reject")
    );
}
'''
        write(tests_path, tests)


def patch_execution_docs() -> None:
    path = "docs/readiness/OBJECTIVE_COMPILER_EXECUTION.md"
    text = read(path)
    replacements = [
        ("## 4. Legal-action grammar and intrinsic abstain", "## 4. Deterministic compilation algorithm\n\n### 4.1 Legal-action grammar and intrinsic abstain"),
        ("## 5. Deterministic compilation algorithm", "### 4.2 Deterministic compilation steps"),
        ("## 6. State, publication and idempotency", "## 5. State machine and persistence"),
        ("## 7. Stable error taxonomy and fallback", "## 6. Error taxonomy and fallback"),
        ("## 8. Security and adversarial inputs", "## 7. Security and adversarial inputs"),
        ("## 9. Complexity, performance and resource envelope", "## 8. Performance envelope"),
        ("## 10. Golden fixtures and tests", "## 9. Golden fixtures and tests"),
        ("## 11. Implementation and completion sequence", "## 10. Implementation sequence"),
    ]
    for old, new in replacements:
        if old in text:
            text = replace_once(text, old, new, f"objective heading {old}")
    if "## 11. Coding-entry checklist" not in text:
        marker = "## Appendix A. Closed gap and protocol mapping"
        checklist = """## 11. Coding-entry checklist

- exact canonical source receipt and immutable profile digest are current;
- every profile collection and encoded profile is within its enforced bound;
- all represented source semantics map without truncation or guessing;
- intrinsic `abstain`, hard-feasibility and conflict fixtures pass;
- outputs remain deny-all and the durable caller boundary is named;
- exact-head and synthetic-merge checks pass before source completion is claimed.

"""
        text = replace_once(text, marker, checklist + marker, "objective checklist")
    anchor = "The canonical IR contains no raw credentials, unrestricted external text, hidden model state or executable code. Every payload and collection has both count and encoded-byte bounds."
    if "Admission profiles are bounded to" not in text:
        text = replace_once(
            text,
            anchor,
            anchor + " Admission profiles are bounded to 256 constraint mappings, 128 predicate mappings, 128 action mappings, 64 soft dimensions, 128 evidence mappings, 64 abstention rules and 256 KiB of encoded profile semantics; risk and rollback levels must be monotone.",
            "objective profile docs",
        )
    write(path, text)

    path = "docs/readiness/NDU_SYSTEM_EXECUTION.md"
    text = read(path)
    replacements = [
        ("## 2. Cross-organ contribution contract", "## 2. Cross-organ utility contract"),
        ("## 3. Versioned aggregation policy", "## 3. Multi-objective feasibility and Pareto policy"),
        ("## 4. Feasibility, Pareto and scalarization", "### 3.1 Feasibility, Pareto and scalarization"),
        ("## 5. Deterministic hierarchical preference solver", "## 4. Deterministic hierarchical solver"),
        ("## 6. Local solver receipts versus independent certificate", "## 5. Convergence, infeasibility and multiple solutions"),
        ("## 7. Conditional covariance and stochastic shadow boundary", "## 6. State, persistence and scheduling\n\n### 6.1 Conditional covariance and stochastic shadow boundary"),
        ("## 8. Projection state and owner-local durability reference", "### 6.2 Projection state and owner-local durability reference"),
        ("## 9. Goodhart, wireheading and outcome ownership", "## 7. Goodhart and wireheading controls"),
        ("## 10. Scheduling, fallback and rollback", "### 7.1 Scheduling, fallback and rollback"),
        ("## 11. Numerical and resource envelope", "## 8. Numerical and resource envelope"),
        ("## 12. Golden fixtures and tests", "## 9. Golden fixtures and tests"),
        ("## 13. Implementation sequence and completion rule", "## 10. Implementation sequence"),
        ("## Appendix A. Canonical protocol mapping", "## Appendix A. Closed gap and protocol mapping"),
    ]
    for old, new in replacements:
        if old in text:
            text = replace_once(text, old, new, f"NDU heading {old}")
    if "## 11. Coding-entry checklist" not in text:
        marker = "## Appendix A. Closed gap and protocol mapping"
        checklist = """## 11. Coding-entry checklist

- contribution sets bind one objective and generation and contain every required organ;
- every utility axis has an explicit uncertainty value, never an omitted implicit zero;
- candidate support digests bind organ identity and complete normalized contribution semantics;
- aggregation, Pareto tolerance and optional scalarization profiles are digest-bound;
- local termination receipts remain distinct from independent convergence certificates;
- projection reopen, tamper and revocation non-resurrection fixtures pass;
- exact-head and synthetic-merge checks pass before source completion is claimed.

"""
        text = replace_once(text, marker, checklist + marker, "NDU checklist")
    anchor = "A contribution with an empty support digest, mixed objective, mixed generation, duplicate organ identity, unknown axis or missing required organ is unavailable rather than zero."
    if "Every evaluated candidate must also contain a value for every registered uncertainty axis" not in text:
        text = replace_once(
            text,
            anchor,
            anchor + " Every evaluated candidate must also contain a value for every registered uncertainty axis. The candidate support digest is derived from the organ identity, objective, generation, feasibility posture, complete normalized vectors and the upstream support digest, so provenance cannot be detached from contribution semantics.",
            "NDU provenance docs",
        )
    write(path, text)

    path = "docs/readiness/CONTROL_RUNTIME_EXECUTION.md"
    text = read(path)
    if "snapshot-policy digest" not in text:
        text = replace_once(
            text,
            "`SnapshotRequestV1` binds the required owner set, objective, body generation, configuration, current revocation frontier, collection time, maximum owner age and snapshot expiry.",
            "`SnapshotRequestV1` binds the required owner set, objective, body generation, configuration, current revocation frontier, a snapshot-policy digest, collection time, maximum owner age and snapshot expiry. The resulting snapshot additionally binds the required-owner-set digest and the exact maximum-age policy.",
            "control snapshot policy docs",
        )
    if "evaluation-policy digest and resource-profile digest are frozen" not in text:
        text = replace_once(
            text,
            "`prepare_plan` filters resource-infeasible candidates before NDU evaluation and records their IDs in `resource_rejected_candidate_ids`.",
            "The evaluation-policy digest and resource-profile digest are frozen in the planning request before candidate filtering. At least one explicit resource reservation is required in the pilot; an empty collection cannot silently mean an unbounded or zero-resource profile.\n\n`prepare_plan` filters resource-infeasible candidates before NDU evaluation and records their IDs in `resource_rejected_candidate_ids`.",
            "control policy docs",
        )
    if "recomputes the complete feasible-candidate-set digest" not in text:
        text = replace_once(
            text,
            "`finalize_plan` revalidates:",
            "`finalize_plan` recomputes the complete feasible-candidate-set digest from candidate identity, operation, plan, owner, final-payload and resource fields, verifies it against the sealed prepared envelope, and revalidates:",
            "control finalize docs",
        )
    if "Before reading any selected operation or payload" not in text:
        text = replace_once(
            text,
            "`request_execution_grants` accepts only a current snapshot, the exact prepared input and the exact final plan receipt.",
            "`request_execution_grants` accepts only a current snapshot, the exact sealed prepared input and the exact final plan receipt. Before reading any selected operation or payload, it recomputes the snapshot, candidate-set, prepared-plan and receipt digests, checks all readiness masks, policy bindings and expiry, and rejects any mutation.",
            "control grant docs",
        )
    if "RCP-13" not in text:
        text = replace_once(
            text,
            "- `RCP-12`: no receipt claims an optimum outside the bounded candidate set.",
            "- `RCP-12`: no receipt claims an optimum outside the bounded candidate set.\n- `RCP-13`: operation, payload, resource or required-owner mutation after finalization rejects before grant-request construction.\n- `RCP-14`: grant-request construction revalidates snapshot masks and digest.\n- `RCP-15`: the NDU evaluation policy and resource profile are frozen before evaluation and bound through the final receipt.",
            "control verification docs",
        )
    write(path, text)


def patch_maps_and_ledgers() -> None:
    path = "docs/modules/objective.compiler/IMPLEMENTATION_MAP.json"
    data = json.loads(read(path))
    for operation in data["operations"]:
        if operation["operation"] == "check_feasibility_v1":
            operation["outputs"] = ["FeasibilityReceiptV1"]
        if operation["operation"] == "admit_and_compile_objective_v1":
            names = {test["symbol"] for test in operation["tests"]}
            for symbol in ["oversized_profile_mapping_set_is_rejected", "risk_profile_ordering_is_monotone"]:
                if symbol not in names:
                    operation["tests"].append({"path": "codex-rs/hepta-objective/src/objective_admission_tests.rs", "symbol": symbol})
    write(path, json.dumps(data, indent=2) + "\n")

    path = "docs/modules/utility.ndu/IMPLEMENTATION_MAP.json"
    data = json.loads(read(path))
    for operation in data["operations"]:
        if operation["operation"] == "evaluate_candidates_with_policy":
            names = {test["symbol"] for test in operation["tests"]}
            for symbol in ["missing_uncertainty_axis_is_unavailable", "candidate_support_digest_binds_organ_and_contribution_semantics"]:
                if symbol not in names:
                    operation["tests"].append({"path": "codex-rs/hepta-ndu/src/evaluator_tests.rs", "symbol": symbol})
    write(path, json.dumps(data, indent=2) + "\n")

    path = "docs/modules/control.runtime/IMPLEMENTATION_MAP.json"
    data = json.loads(read(path))
    for operation in data["operations"]:
        if operation["operation"] == "finalize_plan":
            names = {test["symbol"] for test in operation["tests"]}
            if "evaluation_policy_is_frozen_before_ndu_evaluation" not in names:
                operation["tests"].append({"path": "codex-rs/hepta-control-plane/src/planner_tests.rs", "symbol": "evaluation_policy_is_frozen_before_ndu_evaluation"})
        if operation["operation"] == "request_execution_grants":
            names = {test["symbol"] for test in operation["tests"]}
            for symbol in [
                "tampered_candidate_payload_is_rejected_before_grant_request",
                "tampered_candidate_operation_resource_or_owner_is_rejected",
                "grant_request_revalidates_snapshot_masks_and_digest",
            ]:
                if symbol not in names:
                    operation["tests"].append({"path": "codex-rs/hepta-control-plane/src/planner_tests.rs", "symbol": symbol})
    write(path, json.dumps(data, indent=2) + "\n")

    path = "docs/readiness/LANE_D_PROTOCOLS.json"
    data = json.loads(read(path))
    protocols = {row["id"]: row for row in data["protocols"]}
    def add_field(protocol: str, name: str, kind: str) -> None:
        fields = protocols[protocol]["fields"]
        if not any(field["name"] == name for field in fields):
            fields.append({"name": name, "type": kind})
    add_field("GlobalStateSnapshotV1", "snapshotPolicyDigest", "sha256")
    add_field("GlobalStateSnapshotV1", "maximumOwnerAgeMicros", "u64")
    add_field("GlobalStateSnapshotV1", "requiredOwnerSetDigest", "sha256")
    add_field("PreparedPlanInputV1", "evaluationPolicyDigest", "sha256")
    add_field("PreparedPlanInputV1", "resourceProfileDigest", "sha256")
    add_field("FeasiblePlanReceiptV1", "preparedDigest", "sha256")
    add_field("FeasiblePlanReceiptV1", "resourceProfileDigest", "sha256")
    protocols["GlobalStateSnapshotV1"]["digestScope"] = ["all fields except snapshotDigest, including freshness and required-owner policy"]
    protocols["PreparedPlanInputV1"]["digestScope"] = ["snapshot/objective/body/configuration/frontier", "evaluation and resource policy", "source and feasible candidate sets", "resource rejection set", "expiry"]
    protocols["FeasiblePlanReceiptV1"]["digestScope"] = ["all semantic fields except receiptDigest and authority, including prepared and resource-profile digests"]
    write(path, json.dumps(data, indent=2) + "\n")

    path = "docs/readiness/LANE_D_GAP_CLOSURE.json"
    data = json.loads(read(path))
    existing = {row["id"] for row in data["gaps"]}
    additions = [
        ("LANE-D-OBJ-PROFILE-023", "P1", "Objective admission profile collections and total encoded semantics were not comprehensively bounded", ["codex-rs/hepta-objective/src/objective_admission.rs", "codex-rs/hepta-objective/src/objective_admission_tests.rs"]),
        ("LANE-D-NDU-UNCERTAINTY-024", "P1", "NDU candidate finalization did not require every registered uncertainty axis", ["codex-rs/hepta-ndu/src/evaluator.rs", "codex-rs/hepta-ndu/src/evaluator_tests.rs"]),
        ("LANE-D-NDU-PROVENANCE-025", "P1", "Candidate support digests did not bind organ identity and full normalized contribution semantics", ["codex-rs/hepta-ndu/src/evaluator.rs", "codex-rs/hepta-ndu/src/evaluator_tests.rs"]),
        ("LANE-D-RCP-INTEGRITY-026", "P0", "Prepared candidates and snapshots could be mutated after finalization without complete revalidation before grant requests", ["codex-rs/hepta-control-plane/src/planner.rs", "codex-rs/hepta-control-plane/src/planner_tests.rs"]),
        ("LANE-D-RCP-POLICY-027", "P0", "NDU evaluation, resource and snapshot freshness policies were not frozen through the complete planning receipt chain", ["codex-rs/hepta-control-plane/src/planner.rs", "docs/readiness/LANE_D_PROTOCOLS.json"]),
        ("LANE-D-READINESS-028", "P0", "Readiness section identities and implementation map types drifted from the latest execution specifications and Rust API", ["docs/readiness/OBJECTIVE_COMPILER_EXECUTION.md", "docs/readiness/NDU_SYSTEM_EXECUTION.md", "docs/modules/objective.compiler/IMPLEMENTATION_MAP.json"]),
    ]
    for gap_id, severity, title, closure in additions:
        if gap_id not in existing:
            data["gaps"].append({"id": gap_id, "severity": severity, "title": title, "state": "closed", "closure": closure})
    write(path, json.dumps(data, indent=2) + "\n")

    path = "docs/readiness/LANE_D_MATURITY.json"
    data = json.loads(read(path))
    for module in data["modules"]:
        dimensions = module["dimensions"]
        if module["module"] == "objective.compiler":
            dimensions["boundedAdmissionProfile"] = {"state": "candidate_implemented", "evidence": ["MAX_PROFILE_ENCODED_BYTES", "oversized_profile_mapping_set_is_rejected"]}
        elif module["module"] == "utility.ndu":
            dimensions["completeUncertaintyAndProvenance"] = {"state": "candidate_implemented", "evidence": ["missing_uncertainty_axis_is_unavailable", "candidate_support_digest_binds_organ_and_contribution_semantics"]}
        elif module["module"] == "control.runtime":
            dimensions["sealedPlanningIntegrity"] = {"state": "candidate_implemented", "evidence": ["tampered_candidate_payload_is_rejected_before_grant_request", "grant_request_revalidates_snapshot_masks_and_digest"]}
            dimensions["policyPrebinding"] = {"state": "candidate_implemented", "evidence": ["snapshotPolicyDigest", "evaluationPolicyDigest", "resourceProfileDigest"]}
    write(path, json.dumps(data, indent=2) + "\n")


def write_lane_checker() -> None:
    checker = r'''#!/usr/bin/env python3
"""Closed-world semantic verifier for Lane D owner-local candidate source."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
MODULES = ("objective.compiler", "utility.ndu", "control.runtime")
MAPS = {module: f"docs/modules/{module}/IMPLEMENTATION_MAP.json" for module in MODULES}
REQUIRED_DOCS = (
    "docs/contracts/OBJECTIVE_ERRORS.json",
    "docs/readiness/OBJECTIVE_COMPILER_EXECUTION.md",
    "docs/readiness/NDU_SYSTEM_EXECUTION.md",
    "docs/readiness/CONTROL_RUNTIME_EXECUTION.md",
    "docs/readiness/LANE_D_MATURITY.json",
    "docs/readiness/LANE_D_PROTOCOLS.json",
    "docs/readiness/LANE_D_GAP_CLOSURE.json",
    "docs/delivery/LANE_D_WORK_PACKAGE_OVERLAY.json",
    "docs/governance/MODULE_IMPLEMENTATION_BASELINE.md",
    "qualification/module-execution-dossiers/detail/objective.compiler.md",
    "qualification/module-execution-dossiers/detail/utility.ndu.md",
    "qualification/module-execution-dossiers/detail/control.runtime.md",
)
ALLOWED_PREFIXES = (
    "codex-rs/hepta-objective/",
    "codex-rs/hepta-ndu/",
    "codex-rs/hepta-control-plane/",
    "docs/contracts/OBJECTIVE_ERRORS.json",
    "docs/readiness/OBJECTIVE_COMPILER_EXECUTION.md",
    "docs/readiness/NDU_SYSTEM_EXECUTION.md",
    "docs/readiness/CONTROL_RUNTIME_EXECUTION.md",
    "docs/readiness/LANE_D_",
    "docs/delivery/LANE_D_WORK_PACKAGE_OVERLAY.json",
    "docs/governance/MODULE_IMPLEMENTATION_BASELINE.md",
    "docs/modules/objective.compiler/IMPLEMENTATION_MAP.json",
    "docs/modules/utility.ndu/IMPLEMENTATION_MAP.json",
    "docs/modules/control.runtime/IMPLEMENTATION_MAP.json",
    "qualification/module-execution-dossiers/",
    "scripts/hepta-lane-d-semantic-conformance.py",
    ".github/workflows/hepta-lane-d-semantic-conformance.yml",
)


def fail(message: str) -> None:
    raise SystemExit("FAIL_HEPTA_LANE_D_SEMANTIC_CONFORMANCE: " + message)


def need(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def load(path: str) -> dict[str, Any]:
    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in items:
            if key in result:
                fail(f"duplicate JSON key {path}:{key}")
            result[key] = value
        return result
    return json.loads((ROOT / path).read_text(encoding="utf-8"), object_pairs_hook=pairs)


def verify_map(module: str) -> None:
    mapping = load(MAPS[module])
    need(mapping.get("module") == module, f"{module} map identity")
    need(mapping.get("authorityDelta") == "none", f"{module} authority delta")
    need(mapping.get("operations"), f"{module} operations")
    for operation in mapping["operations"]:
        source_path = operation["sourcePath"]
        need((ROOT / source_path).is_file(), f"missing source {source_path}")
        source = (ROOT / source_path).read_text(encoding="utf-8")
        symbol = operation["nativeSymbol"].split("::")[-1]
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", symbol):
            need(re.search(rf"\b(?:fn|struct)\s+{re.escape(symbol)}\b", source) is not None, f"missing native symbol {operation['nativeSymbol']}")
        for test in operation.get("tests", []):
            test_path = test["path"]
            need((ROOT / test_path).is_file(), f"missing test {test_path}")
            test_source = (ROOT / test_path).read_text(encoding="utf-8")
            test_symbol = test["symbol"]
            if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", test_symbol):
                need(f"fn {test_symbol}" in test_source, f"missing test symbol {test_symbol}")


def verify() -> int:
    for path in REQUIRED_DOCS:
        need((ROOT / path).is_file(), f"missing document {path}")
    for module in MODULES:
        verify_map(module)

    objective = (ROOT / "codex-rs/hepta-objective/src/objective_admission.rs").read_text(encoding="utf-8")
    for token in ["MAX_PROFILE_CONSTRAINTS", "MAX_PROFILE_ENCODED_BYTES", "profile_encoded_size", 'InvalidProfile("risk ordering")']:
        need(token in objective, "objective hardening " + token)

    ndu = (ROOT / "codex-rs/hepta-ndu/src/evaluator.rs").read_text(encoding="utf-8")
    for token in ["CONTRIBUTION_DIGEST_DOMAIN", "digest_contribution", "uncertainty:{axis}", "support_digests.push(contribution_digest)"]:
        need(token in ndu, "NDU hardening " + token)

    planner = (ROOT / "codex-rs/hepta-control-plane/src/planner.rs").read_text(encoding="utf-8")
    for token in [
        "LANE_D_FINAL_HARDENING_V1",
        "snapshot_policy_digest",
        "required_owner_set_digest",
        "evaluation_policy_digest",
        "resource_profile_digest",
        "prepared_digest != digest_prepared_plan(prepared)",
        "candidate_set_digest != digest_candidates(&prepared.feasible_candidates)",
        "validate_snapshot_for_planning(snapshot, now_micros)?;",
        "receipt.prepared_digest != prepared.prepared_digest",
    ]:
        need(token in planner, "control hardening " + token)
    for struct_name in ["GlobalStateSnapshotV1", "PreparedPlanInputV1", "NduPlanEvaluationV1", "FeasiblePlanReceiptV1", "GrantRequestSetV1"]:
        body = re.search(rf"pub struct {struct_name} \{{(.*?)\n\}}", planner, flags=re.S)
        need(body is not None and "    pub " not in body.group(1), f"{struct_name} output not sealed")

    headings = {
        "docs/readiness/OBJECTIVE_COMPILER_EXECUTION.md": [
            "## 4. Deterministic compilation algorithm", "## 5. State machine and persistence", "## 11. Coding-entry checklist", "## Appendix A. Closed gap and protocol mapping"
        ],
        "docs/readiness/NDU_SYSTEM_EXECUTION.md": [
            "## 2. Cross-organ utility contract", "## 3. Multi-objective feasibility and Pareto policy", "## 11. Coding-entry checklist", "## Appendix A. Closed gap and protocol mapping"
        ],
        "docs/readiness/CONTROL_RUNTIME_EXECUTION.md": ["RCP-13", "RCP-14", "RCP-15"],
    }
    for path, tokens in headings.items():
        text = (ROOT / path).read_text(encoding="utf-8")
        for token in tokens:
            need(token in text, f"{path} missing {token}")

    gaps = load("docs/readiness/LANE_D_GAP_CLOSURE.json")
    gap_ids = {row["id"] for row in gaps.get("gaps", [])}
    for gap_id in [
        "LANE-D-OBJ-PROFILE-023", "LANE-D-NDU-UNCERTAINTY-024", "LANE-D-NDU-PROVENANCE-025",
        "LANE-D-RCP-INTEGRITY-026", "LANE-D-RCP-POLICY-027", "LANE-D-READINESS-028",
    ]:
        need(gap_id in gap_ids, "missing gap record " + gap_id)
    need(all(row.get("state") == "closed" for row in gaps["gaps"]), "repository gap not closed")
    need(all(str(row.get("state", "")).endswith("required") for row in gaps["externalGates"]), "external gate truth posture")

    protocols = load("docs/readiness/LANE_D_PROTOCOLS.json")
    need(protocols.get("authorityDelta") == "none", "protocol authority delta")
    need(all(row.get("authority") in {"none", "deny_all"} for row in protocols["protocols"]), "positive protocol authority")

    maturity = load("docs/readiness/LANE_D_MATURITY.json")
    need(maturity.get("authorityDelta") == "none", "maturity authority delta")
    need({row["module"] for row in maturity["modules"]} == set(MODULES), "maturity module closure")
    for row in maturity["modules"]:
        for key in ["productCaller", "independentAcceptance", "activation", "release"]:
            need(row["dimensions"][key]["state"] == "not_established", f"truth boundary {row['module']} {key}")

    print(json.dumps({"status": "PASS_HEPTA_LANE_D_SEMANTIC_CONFORMANCE", "modules": 3, "repositoryGaps": len(gaps["gaps"]), "externalGatesRemainExternal": True, "authorityGranted": False}, sort_keys=True))
    return 0


def verify_changes(base: str) -> int:
    result = subprocess.run(["git", "diff", "--name-only", f"{base}...HEAD"], cwd=ROOT, check=True, text=True, capture_output=True)
    changed = [line for line in result.stdout.splitlines() if line]
    denied = [path for path in changed if not any(path == prefix or path.startswith(prefix) for prefix in ALLOWED_PREFIXES)]
    need(not denied, "out-of-envelope paths: " + ", ".join(denied))
    need(changed, "empty Lane D change set")
    print(json.dumps({"status": "PASS_HEPTA_LANE_D_CHANGE_POLICY", "changedPaths": len(changed), "authorityGranted": False}, sort_keys=True))
    return 0


def self_test() -> int:
    need(any("x/y".startswith(prefix) for prefix in ("x/",)), "prefix fixture")
    try:
        json.loads('{"a":1,"a":2}', object_pairs_hook=lambda items: (_ for _ in ()).throw(ValueError("duplicate")) if len(items) != len(dict(items)) else dict(items))
        fail("duplicate-key fixture accepted")
    except ValueError:
        pass
    print(json.dumps({"status": "PASS_HEPTA_LANE_D_SELF_TEST", "authorityGranted": False}, sort_keys=True))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("verify")
    sub.add_parser("self-test")
    changes = sub.add_parser("verify-changes")
    changes.add_argument("--base", required=True)
    args = parser.parse_args()
    if args.command == "verify":
        return verify()
    if args.command == "self-test":
        return self_test()
    return verify_changes(args.base)


if __name__ == "__main__":
    raise SystemExit(main())
'''
    write("scripts/hepta-lane-d-semantic-conformance.py", checker)


def update_dossier_index_hashes() -> None:
    path = "qualification/module-execution-dossiers/DETAILS.json"
    data = json.loads(read(path))
    for row in data.get("rows", []):
        dossier = ROOT / row["path"]
        if dossier.is_file():
            row["sha256"] = hashlib.sha256(dossier.read_bytes()).hexdigest()
    write(path, json.dumps(data, separators=(",", ":")) + "\n")


def main() -> None:
    patch_planner()
    patch_planner_tests()
    patch_ndu()
    patch_objective()
    patch_execution_docs()
    patch_maps_and_ledgers()
    write_lane_checker()
    update_dossier_index_hashes()


if __name__ == "__main__":
    main()
