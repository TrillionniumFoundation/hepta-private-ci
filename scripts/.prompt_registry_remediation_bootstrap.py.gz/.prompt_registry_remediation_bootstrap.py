#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def write(path: str, content: str) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")


def replace_once(path: str, old: str, new: str) -> None:
    content = read(path)
    count = content.count(old)
    if count != 1:
        raise RuntimeError(f"{path}: expected exactly one match, found {count}: {old[:120]!r}")
    write(path, content.replace(old, new, 1))


def insert_before_once(path: str, marker: str, insertion: str) -> None:
    replace_once(path, marker, insertion + marker)


def run(*args: str) -> str:
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()


# ---------------------------------------------------------------------------
# Durable schema V4: relations become part of the authoritative metadata image.
# ---------------------------------------------------------------------------
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "//! immutable payload extents are durable. Existing payload bytes are not rewritten\n"
    "//! on metadata changes. V1/V2 storage migrates at open; validated V3 reopen does\n"
    "//! not rewrite metadata. Hot state and metadata remain size-dependent.\n",
    "//! immutable payload extents are durable. Existing payload bytes are not rewritten\n"
    "//! on metadata changes. V1/V2/V3 storage migrates at open; validated V4 reopen\n"
    "//! does not rewrite metadata. V4 persists factor relations in the same atomic\n"
    "//! metadata image that selects payload extents. Hot state and metadata remain\n"
    "//! size-dependent.\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "use crate::PromptFactor;\n",
    "use crate::PromptFactor;\n"
    "use crate::PromptFactorRelation;\n"
    "use crate::PromptFactorRelationKind;\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "const STORE_SCHEMA: u32 = 2;\n",
    "const LEGACY_STORE_SCHEMA: u32 = 2;\n"
    "const STORE_SCHEMA: u32 = 4;\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "    pub fn register_factor(\n"
    "        &mut self,\n"
    "        factor: PromptFactor,\n"
    "    ) -> Result<RegistryReceipt, DurableRegistryError> {\n"
    "        self.commit(|registry| registry.register_factor(factor))\n"
    "    }\n",
    "    pub fn register_factor(\n"
    "        &mut self,\n"
    "        factor: PromptFactor,\n"
    "    ) -> Result<RegistryReceipt, DurableRegistryError> {\n"
    "        self.commit(|registry| registry.register_factor(factor))\n"
    "    }\n\n"
    "    /// Persist one governed factor relation in the same atomic V4 metadata\n"
    "    /// image as factors, realizations, lifecycle events, and payload references.\n"
    "    pub fn register_factor_relation(\n"
    "        &mut self,\n"
    "        relation: PromptFactorRelation,\n"
    "    ) -> Result<RegistryReceipt, DurableRegistryError> {\n"
    "        self.commit(|registry| registry.register_factor_relation(relation))\n"
    "    }\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "    factors: Vec<StoredFactor>,\n"
    "    realizations: Vec<StoredRealization>,\n",
    "    factors: Vec<StoredFactor>,\n"
    "    #[serde(default, skip_serializing_if = \"Vec::is_empty\")]\n"
    "    relations: Vec<StoredRelation>,\n"
    "    realizations: Vec<StoredRealization>,\n",
)
insert_before_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "#[derive(Deserialize, Serialize)]\n"
    "#[serde(deny_unknown_fields)]\n"
    "struct StoredRealization {\n",
    "#[derive(Deserialize, Serialize)]\n"
    "#[serde(deny_unknown_fields)]\n"
    "struct StoredRelation {\n"
    "    relation_id: String,\n"
    "    left_factor_id: String,\n"
    "    right_factor_id: String,\n"
    "    kind: u8,\n"
    "    evidence_digest: [u8; 32],\n"
    "}\n\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "                lifecycle: lifecycle_code(factor.lifecycle),\n"
    "            })\n"
    "            .collect(),\n"
    "        realizations: registry\n",
    "                lifecycle: lifecycle_code(factor.lifecycle),\n"
    "            })\n"
    "            .collect(),\n"
    "        relations: registry\n"
    "            .relations\n"
    "            .values()\n"
    "            .map(|relation| StoredRelation {\n"
    "                relation_id: relation.relation_id.to_string(),\n"
    "                left_factor_id: relation.left_factor_id.to_string(),\n"
    "                right_factor_id: relation.right_factor_id.to_string(),\n"
    "                kind: relation_kind_code(relation.kind),\n"
    "                evidence_digest: relation.evidence_digest.into_array(),\n"
    "            })\n"
    "            .collect(),\n"
    "        realizations: registry\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "    if stored.schema != STORE_SCHEMA || stored.maximum_records == 0 || maximum_records == 0 {\n",
    "    if !matches!(stored.schema, LEGACY_STORE_SCHEMA | STORE_SCHEMA)\n"
    "        || stored.maximum_records == 0\n"
    "        || maximum_records == 0\n"
    "    {\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "    if factors.len().saturating_add(realizations.len()) > configured_maximum {\n"
    "        return Err(DurableRegistryError::CapacityExceeded);\n"
    "    }\n\n"
    "    let mut realization_bindings = BTreeMap::new();\n",
    "    let mut relations = BTreeMap::new();\n"
    "    for stored_relation in stored.relations {\n"
    "        let relation = PromptFactorRelation {\n"
    "            relation_id: parse_id(stored_relation.relation_id)?,\n"
    "            left_factor_id: parse_id(stored_relation.left_factor_id)?,\n"
    "            right_factor_id: parse_id(stored_relation.right_factor_id)?,\n"
    "            kind: decode_relation_kind(stored_relation.kind)?,\n"
    "            evidence_digest: Digest32::from_array(stored_relation.evidence_digest),\n"
    "        };\n"
    "        if relation.evidence_digest.is_zero()\n"
    "            || relation.left_factor_id >= relation.right_factor_id\n"
    "            || relations\n"
    "                .insert(relation.relation_id.clone(), relation)\n"
    "                .is_some()\n"
    "        {\n"
    "            return Err(DurableRegistryError::Corrupt);\n"
    "        }\n"
    "    }\n"
    "    if factors\n"
    "        .len()\n"
    "        .saturating_add(realizations.len())\n"
    "        .saturating_add(relations.len())\n"
    "        > configured_maximum\n"
    "    {\n"
    "        return Err(DurableRegistryError::CapacityExceeded);\n"
    "    }\n\n"
    "    let mut realization_bindings = BTreeMap::new();\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "        relations: BTreeMap::new(),\n",
    "        relations,\n",
)
insert_before_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "const fn role_code(value: PromptRoleV2) -> u8 {\n",
    "const fn relation_kind_code(value: PromptFactorRelationKind) -> u8 {\n"
    "    match value {\n"
    "        PromptFactorRelationKind::Complements => 0,\n"
    "        PromptFactorRelationKind::Substitutes => 1,\n"
    "        PromptFactorRelationKind::Conflicts => 2,\n"
    "    }\n"
    "}\n\n"
    "fn decode_relation_kind(value: u8) -> Result<PromptFactorRelationKind, DurableRegistryError> {\n"
    "    match value {\n"
    "        0 => Ok(PromptFactorRelationKind::Complements),\n"
    "        1 => Ok(PromptFactorRelationKind::Substitutes),\n"
    "        2 => Ok(PromptFactorRelationKind::Conflicts),\n"
    "        _ => Err(DurableRegistryError::Corrupt),\n"
    "    }\n"
    "}\n\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "            3 => {\n"
    "                let manifest =\n"
    "                    serde_json::from_value(value).map_err(|_| DurableRegistryError::Corrupt)?;\n"
    "                let (payloads, state) = payloads::PayloadState::hydrate(&store.root, manifest)?;\n"
    "                store.payloads = payloads;\n"
    "                StoredAny::V2(state)\n"
    "            }\n",
    "            3 | 4 => {\n"
    "                let manifest =\n"
    "                    serde_json::from_value(value).map_err(|_| DurableRegistryError::Corrupt)?;\n"
    "                let (payloads, state) = payloads::PayloadState::hydrate(&store.root, manifest)?;\n"
    "                store.payloads = payloads;\n"
    "                StoredAny::V2(state)\n"
    "            }\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "        let bytes = serde_json::to_vec(&payloads::StoredV3 {\n"
    "            schema: 3,\n",
    "        let bytes = serde_json::to_vec(&payloads::StoredV3 {\n"
    "            schema: 4,\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "#[cfg(all(test, unix))]\n"
    "mod tests {\n",
    "#[cfg(all(test, unix))]\n"
    "#[path = \"durable_v4_tests.rs\"]\n"
    "mod durable_v4_tests;\n\n"
    "#[cfg(all(test, unix))]\n"
    "mod tests {\n",
)

replace_once(
    "codex-rs/hepta-prompt-registry/src/durable_payloads.rs",
    "//! Storage-v3 payload extent file under the existing exclusive registry owner.\n",
    "//! Storage-v4 payload extent file under the existing exclusive registry owner.\n",
)
replace_once(
    "codex-rs/hepta-prompt-registry/src/durable_payloads.rs",
    "        if stored.schema != 3\n"
    "            || stored.state.schema != super::STORE_SCHEMA\n",
    "        if !matches!(stored.schema, 3 | 4)\n"
    "            || !matches!(\n"
    "                stored.state.schema,\n"
    "                super::LEGACY_STORE_SCHEMA | super::STORE_SCHEMA\n"
    "            )\n",
)

# ---------------------------------------------------------------------------
# Add an explicit schema-V4 reopen test.
# ---------------------------------------------------------------------------
write(
    "codex-rs/hepta-prompt-registry/src/durable_v4_tests.rs",
    r'''use super::*;
use std::collections::BTreeSet;
use std::os::unix::fs::DirBuilderExt;
use std::time::SystemTime;
use std::time::UNIX_EPOCH;

use codex_hepta_contracts::FinalUseGrant;
use codex_hepta_contracts::FinalUseRevocations;
use codex_hepta_contracts::SignedFinalUseGrant;
use ed25519_dalek::Signer;
use ed25519_dalek::SigningKey;

use crate::final_use_admission_binding;

fn id(value: &str) -> StableId {
    StableId::new(value).unwrap_or_else(|error| panic!("valid id: {error}"))
}

fn digest(value: &str) -> Digest32 {
    Digest32::of_bytes(value.as_bytes())
}

fn factor(label: &str) -> PromptFactor {
    PromptFactor {
        factor_id: id(&format!("factor:{label}")),
        proposer_id: id(&format!("proposer:{label}")),
        semantic_version: id("semantic:v1"),
        semantic_purpose: format!("purpose:{label}"),
        authority_class: "registered_prompt_factor".to_owned(),
        eligible_objective_dimensions: vec![id("dimension:truth")],
        content_digest: digest(&format!("content:{label}")),
        source: FactorSource::GovernedInternal,
        lifecycle: Lifecycle::Draft,
    }
}

fn admit(
    registry: &mut DurablePromptRegistry,
    authority: &FinalUseAuthority,
    signing_key: &SigningKey,
    factor: &PromptFactor,
    ordinal: u8,
    now: u64,
) {
    let reviewer = id("reviewer:v4");
    let scope = digest(&format!("scope:{}", factor.factor_id));
    let evidence = digest(&format!("evidence:{}", factor.factor_id));
    let binding =
        final_use_admission_binding(factor, &reviewer, scope, evidence).expect("binding");
    let grant = FinalUseGrant {
        schema_version: 1,
        signer_id: "review-authority:v4".to_owned(),
        authority_epoch: 1,
        grant_id: format!("grant:admit:{ordinal}"),
        nonce: [ordinal; 32],
        binding,
        not_before_unix_ms: now.saturating_sub(1_000),
        expires_at_unix_ms: now + 30_000,
    };
    let signed = SignedFinalUseGrant {
        signature: signing_key
            .sign(&grant.signing_bytes().expect("signing bytes"))
            .to_bytes()
            .to_vec(),
        grant,
    };
    registry
        .admit_factor_final_use(
            authority,
            &signed,
            &factor.factor_id,
            scope,
            evidence,
        )
        .expect("admit factor");
}

#[test]
fn schema_v4_persists_relations_in_the_atomic_metadata_image() {
    let temporary = tempfile::tempdir().expect("tempdir");
    let root = temporary.path().join("registry");
    std::fs::DirBuilder::new()
        .mode(0o700)
        .create(&root)
        .expect("state dir");
    let authority_root = temporary.path().join("authority");
    let signing_key = SigningKey::from_bytes(&[84; 32]);
    let authority = FinalUseAuthority::open_state_dir(
        &authority_root,
        "review-authority:v4".to_owned(),
        signing_key.verifying_key().to_bytes(),
        FinalUseRevocations {
            authority_epoch: 1,
            revision: 1,
            revoked_grant_ids: BTreeSet::new(),
        },
    )
    .expect("authority");
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("clock")
        .as_millis() as u64;

    let mut durable = DurablePromptRegistry::open_state_dir(&root, 64).expect("registry");
    let left = factor("a");
    let right = factor("b");
    durable.register_factor(left.clone()).expect("left");
    durable.register_factor(right.clone()).expect("right");
    admit(&mut durable, &authority, &signing_key, &left, 1, now);
    admit(&mut durable, &authority, &signing_key, &right, 2, now);
    let relation = PromptFactorRelation {
        relation_id: id("relation:a:b:conflict"),
        left_factor_id: left.factor_id.clone(),
        right_factor_id: right.factor_id.clone(),
        kind: PromptFactorRelationKind::Conflicts,
        evidence_digest: digest("relation-evidence"),
    };
    durable
        .register_factor_relation(relation.clone())
        .expect("relation");
    let before = durable
        .registry()
        .expect("registry")
        .factor_graph_source_v1()
        .source_digest();
    drop(durable);
    drop(authority);

    let reopened = DurablePromptRegistry::open_state_dir(&root, 64).expect("reopen");
    let source = reopened
        .registry()
        .expect("registry")
        .factor_graph_source_v1();
    assert_eq!(source.source_digest(), before);
    assert_eq!(source.relations(), &[relation]);

    let metadata: serde_json::Value = serde_json::from_slice(
        &std::fs::read(root.join("registry.json")).expect("metadata"),
    )
    .expect("metadata json");
    assert_eq!(metadata["schema"].as_u64(), Some(4));
    assert_eq!(metadata["state"]["schema"].as_u64(), Some(4));
    assert_eq!(
        metadata["state"]["relations"]
            .as_array()
            .map(Vec::len),
        Some(1)
    );
}
''',
)

# ---------------------------------------------------------------------------
# Link and modernize the graph tests instead of widening crate-private APIs.
# ---------------------------------------------------------------------------
canonical_tests = read("codex-rs/hepta-prompt-optimizer/src/canonical_tests.rs")
if '#[path = "graph_tests.rs"]\nmod graph_tests;' not in canonical_tests:
    canonical_tests = canonical_tests.rstrip() + '\n\n#[path = "graph_tests.rs"]\nmod graph_tests;\n'
    write("codex-rs/hepta-prompt-optimizer/src/canonical_tests.rs", canonical_tests)

write(
    "codex-rs/hepta-prompt-optimizer/src/graph_tests.rs",
    r'''use super::*;

use codex_hepta_kg::PromptFactorProjectionV1;
use codex_hepta_kg::build_prompt_factor_projection_v1;
use codex_hepta_prompt_registry::PromptFactorRelation;
use codex_hepta_prompt_registry::PromptFactorRelationKind;
use codex_hepta_types::Generation;

use crate::CandidateDisposition;
use crate::OptimizationRequest;
use crate::PromptCandidate;

fn register_admitted_factor(
    registry: &mut DurablePromptRegistry,
    authority: &FinalUseAuthority,
    signing_key: &SigningKey,
    factor_id: &str,
    ordinal: u8,
    now: u64,
) {
    let factor = PromptFactor {
        factor_id: id(factor_id),
        proposer_id: id(&format!("proposer:{factor_id}")),
        semantic_version: id("semantic:v1"),
        semantic_purpose: format!("graph constraint for {factor_id}"),
        authority_class: "registered_prompt_factor".to_owned(),
        eligible_objective_dimensions: vec![id("dimension:truth")],
        content_digest: digest(&format!("factor-content:{factor_id}")),
        source: FactorSource::GovernedInternal,
        lifecycle: Lifecycle::Draft,
    };
    registry
        .register_factor(factor.clone())
        .expect("register factor");
    let reviewer = id("reviewer:graph-tests");
    let scope = digest(&format!("scope:{factor_id}"));
    let evidence = digest(&format!("factor-admission:{factor_id}"));
    let binding =
        final_use_admission_binding(&factor, &reviewer, scope, evidence).expect("binding");
    let grant = FinalUseGrant {
        schema_version: 1,
        signer_id: "review-authority:prompt".to_owned(),
        authority_epoch: 1,
        grant_id: format!("admission:{factor_id}"),
        nonce: [ordinal; 32],
        binding,
        not_before_unix_ms: now.saturating_sub(1_000),
        expires_at_unix_ms: now + 30_000,
    };
    let signed = SignedFinalUseGrant {
        signature: signing_key
            .sign(&grant.signing_bytes().expect("signing bytes"))
            .to_bytes()
            .to_vec(),
        grant,
    };
    registry
        .admit_factor_final_use(authority, &signed, &factor.factor_id, scope, evidence)
        .expect("admit factor");
}

fn graph() -> PromptFactorProjectionV1 {
    let temporary = tempfile::tempdir().expect("tempdir");
    let root = temporary.path().join("registry");
    let (mut registry, _, authority, signing_key, now) = registry_fixture(&root, &[1]);
    register_admitted_factor(
        &mut registry,
        &authority,
        &signing_key,
        "factor:b",
        41,
        now,
    );
    register_admitted_factor(
        &mut registry,
        &authority,
        &signing_key,
        "factor:c",
        42,
        now,
    );
    registry
        .register_factor_relation(PromptFactorRelation {
            relation_id: id("relation:a-b-conflict"),
            left_factor_id: id("factor:a"),
            right_factor_id: id("factor:b"),
            kind: PromptFactorRelationKind::Conflicts,
            evidence_digest: digest("evidence:a-b-conflict"),
        })
        .expect("register conflict");
    registry
        .register_factor_relation(PromptFactorRelation {
            relation_id: id("relation:a-c-complement"),
            left_factor_id: id("factor:a"),
            right_factor_id: id("factor:c"),
            kind: PromptFactorRelationKind::Complements,
            evidence_digest: digest("evidence:a-c-complement"),
        })
        .expect("register complement");
    registry
        .register_factor_relation(PromptFactorRelation {
            relation_id: id("relation:b-c-substitute"),
            left_factor_id: id("factor:b"),
            right_factor_id: id("factor:c"),
            kind: PromptFactorRelationKind::Substitutes,
            evidence_digest: digest("evidence:b-c-substitute"),
        })
        .expect("register substitute");
    let source = registry
        .registry()
        .expect("registry")
        .factor_graph_source_v1();
    build_prompt_factor_projection_v1(
        Generation::new(1).expect("generation"),
        digest("prompt-generation-vector"),
        &source,
    )
    .expect("factor graph")
}

fn candidate(name: &str, factor_id: &str, gain: i64, registry_digest: Digest32) -> PromptCandidate {
    PromptCandidate {
        candidate_id: id(name),
        factor_id: id(factor_id),
        realization_id: id(&format!("realization:{name}")),
        admitted: true,
        legal: true,
        expected_gain: FixedQ32::from_raw(gain),
        cost: 1,
        registry_digest,
        support_digest: digest(&format!("candidate-support:{name}")),
    }
}

#[test]
fn graph_conflicts_are_hard_constraints_and_receipt_binds_relation_view() {
    let factor_graph = graph();
    let registry_digest = factor_graph.registry_snapshot_digest();
    let request = OptimizationRequest {
        decision_id: id("decision:graph"),
        objective_digest: digest("objective"),
        registry_snapshot_digest: registry_digest,
        budget: 3,
        maximum_selected: 3,
        candidates: vec![
            candidate("candidate:a", "factor:a", 30, registry_digest),
            candidate("candidate:b", "factor:b", 20, registry_digest),
            candidate("candidate:c", "factor:c", 10, registry_digest),
        ],
    };
    let receipt = optimize_with_factor_graph(request, &factor_graph).expect("graph optimize");
    assert_eq!(
        receipt.portfolio.selected,
        vec![id("candidate:a"), id("candidate:c")]
    );
    assert_eq!(receipt.observed_relation_count, 3);
    assert_eq!(receipt.observed_complement_count, 1);
    assert_eq!(receipt.observed_substitute_count, 1);
    assert_eq!(receipt.observed_conflict_count, 1);
    assert!(!receipt.relation_request_digest.is_zero());
    assert_eq!(
        receipt.factor_graph_generation_digest,
        factor_graph.generation().generation_digest
    );
    assert_eq!(
        receipt.portfolio.total_expected_gain,
        FixedQ32::from_raw(40)
    );
    assert!(receipt.portfolio.decisions.iter().any(|decision| {
        decision.candidate_id == id("candidate:b")
            && decision.disposition == CandidateDisposition::GraphConflict
    }));
    receipt.validate().expect("bound receipt");
    assert!(!receipt.authority.grants_any());
}

#[test]
fn candidate_factor_missing_from_complete_graph_fails_closed() {
    let factor_graph = graph();
    let registry_digest = factor_graph.registry_snapshot_digest();
    let request = OptimizationRequest {
        decision_id: id("decision:missing"),
        objective_digest: digest("objective"),
        registry_snapshot_digest: registry_digest,
        budget: 1,
        maximum_selected: 1,
        candidates: vec![candidate("candidate:x", "factor:x", 10, registry_digest)],
    };
    let error = optimize_with_factor_graph(request, &factor_graph).expect_err("missing factor");
    assert!(
        matches!(&error, crate::Error::FactorGraph(message) if message.contains("factor:x")),
        "unexpected error: {error:?}"
    );
}

#[test]
fn registry_snapshot_drift_fails_closed_before_selection() {
    let factor_graph = graph();
    let request = OptimizationRequest {
        decision_id: id("decision:stale-registry"),
        objective_digest: digest("objective"),
        registry_snapshot_digest: digest("different-registry"),
        budget: 1,
        maximum_selected: 1,
        candidates: vec![candidate(
            "candidate:a",
            "factor:a",
            10,
            factor_graph.registry_snapshot_digest(),
        )],
    };
    let error = optimize_with_factor_graph(request, &factor_graph).expect_err("stale registry");
    assert!(
        matches!(&error, crate::Error::FactorGraph(message) if message.contains("registry snapshot")),
        "unexpected error: {error:?}"
    );
}

#[test]
fn graph_substitutes_are_hard_redundancy_constraints() {
    let factor_graph = graph();
    let registry_digest = factor_graph.registry_snapshot_digest();
    let request = OptimizationRequest {
        decision_id: id("decision:substitute"),
        objective_digest: digest("objective"),
        registry_snapshot_digest: registry_digest,
        budget: 2,
        maximum_selected: 2,
        candidates: vec![
            candidate("candidate:b", "factor:b", 20, registry_digest),
            candidate("candidate:c", "factor:c", 10, registry_digest),
        ],
    };
    let receipt = optimize_with_factor_graph(request, &factor_graph).expect("graph optimize");
    assert_eq!(receipt.portfolio.selected, vec![id("candidate:b")]);
    assert_eq!(receipt.observed_substitute_count, 1);
    assert!(receipt.portfolio.decisions.iter().any(|decision| {
        decision.candidate_id == id("candidate:c")
            && decision.disposition == CandidateDisposition::GraphSubstitute
    }));
}
''',
)

# policy.rs is an exact, unlinked duplicate of graph.rs on the source base.
policy = ROOT / "codex-rs/hepta-prompt-optimizer/src/policy.rs"
graph = ROOT / "codex-rs/hepta-prompt-optimizer/src/graph.rs"
if policy.exists():
    if policy.read_bytes() != graph.read_bytes():
        raise RuntimeError("refusing to delete policy.rs because it diverges from graph.rs")
    policy.unlink()

# ---------------------------------------------------------------------------
# Exact-source implementation map generator and validator.
# ---------------------------------------------------------------------------
write(
    "scripts/hepta-prompt-registry-implementation-map.py",
    r'''#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "docs/modules/prompt.registry/IMPLEMENTATION_MAP.json"
SOURCE_BASE = "a126987b84737dbc2ee2592442a314117bddb4a2"

SOURCE_PATHS = [
    "codex-rs/hepta-prompt-registry/src/lib.rs",
    "codex-rs/hepta-prompt-registry/src/admission.rs",
    "codex-rs/hepta-prompt-registry/src/delivery.rs",
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "codex-rs/hepta-prompt-registry/src/durable_payloads.rs",
    "codex-rs/hepta-prompt-registry/src/v2.rs",
    "codex-rs/hepta-prompt-optimizer/src/canonical.rs",
    "codex-rs/hepta-prompt-optimizer/src/graph.rs",
    "codex-rs/hepta-agentd/src/prompt_runtime.rs",
    "codex-rs/hepta-agentd/src/state.rs",
    "codex-rs/hepta-agentd/src/app_runtime.rs",
]
TEST_PATHS = [
    "codex-rs/hepta-prompt-registry/src/durable_v4_tests.rs",
    "codex-rs/hepta-prompt-registry/src/durable_payloads_tests.rs",
    "codex-rs/hepta-prompt-registry/src/lib_tests.rs",
    "codex-rs/hepta-prompt-registry/src/v2_tests.rs",
    "codex-rs/hepta-prompt-optimizer/src/graph_tests.rs",
    "codex-rs/hepta-prompt-optimizer/src/canonical_tests.rs",
    "codex-rs/hepta-agentd/src/prompt_runtime_tests.rs",
]


def git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def blob(path: str) -> str:
    return git("hash-object", path)


def sha256(path: str) -> str:
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()


def require_symbols(path: str, symbols: list[str]) -> None:
    content = (ROOT / path).read_text(encoding="utf-8")
    missing = [symbol for symbol in symbols if symbol not in content]
    if missing:
        raise SystemExit(f"{path}: missing required symbols: {missing}")


def document() -> dict:
    for path in SOURCE_PATHS + TEST_PATHS:
        if not (ROOT / path).is_file():
            raise SystemExit(f"missing mapped path: {path}")
    require_symbols(
        "codex-rs/hepta-prompt-registry/src/durable.rs",
        [
            "pub struct DurablePromptRegistry",
            "pub fn register_factor_relation",
            "schema: 4",
            "relations: Vec<StoredRelation>",
        ],
    )
    require_symbols(
        "codex-rs/hepta-agentd/src/prompt_runtime.rs",
        ["pub struct AgentdPromptPipelineOwner", "pub fn compile_and_stage"],
    )
    source_objects = [
        {
            "path": path,
            "gitBlob": blob(path),
            "sha256": sha256(path),
        }
        for path in SOURCE_PATHS
    ]
    tests = [
        {
            "path": path,
            "gitBlob": blob(path),
            "sha256": sha256(path),
        }
        for path in TEST_PATHS
    ]
    return {
        "schema": "hepta.module-implementation-map.v4",
        "moduleId": "prompt.registry",
        "generatedBy": "scripts/hepta-prompt-registry-implementation-map.py",
        "sourceBase": {
            "branch": "main",
            "commit": SOURCE_BASE,
            "purpose": "exact main SHA from which this remediation branch was cut",
        },
        "status": {
            "sourceImplemented": True,
            "sourceComposed": True,
            "productActivated": False,
            "accepted": False,
            "released": False,
            "productionReady": False,
            "qualificationRule": (
                "productActivated, accepted, released, and productionReady remain false "
                "until exact-head and synthetic-merge qualification receipts are green "
                "and the external acceptance/release authorities act"
            ),
        },
        "storage": {
            "semanticSchema": 4,
            "physicalSchema": 4,
            "relationsPersistedAtomically": True,
            "payloadExtentsSelectedByMetadata": True,
        },
        "operations": [
            {
                "operation": "register_factor",
                "nativeSymbol": "DurablePromptRegistry::register_factor",
                "sourcePath": "codex-rs/hepta-prompt-registry/src/durable.rs",
                "authority": "bootstrap/internal; authenticated product publisher required for activation",
            },
            {
                "operation": "admit_factor_final_use",
                "nativeSymbol": "DurablePromptRegistry::admit_factor_final_use",
                "sourcePath": "codex-rs/hepta-prompt-registry/src/durable.rs",
                "authority": "FinalUseAuthority",
            },
            {
                "operation": "register_realization_payload_final_use_v2",
                "nativeSymbol": "DurablePromptRegistry::register_realization_payload_final_use_v2",
                "sourcePath": "codex-rs/hepta-prompt-registry/src/durable.rs",
                "authority": "FinalUseAuthority",
            },
            {
                "operation": "register_factor_relation",
                "nativeSymbol": "DurablePromptRegistry::register_factor_relation",
                "sourcePath": "codex-rs/hepta-prompt-registry/src/durable.rs",
                "authority": "source implemented; authenticated product publisher added before activation",
            },
            {
                "operation": "enumerate_candidates",
                "nativeSymbol": "AgentdPromptPipelineOwner::enumerate_candidates",
                "sourcePath": "codex-rs/hepta-agentd/src/prompt_runtime.rs",
                "authority": "deny-all candidate source",
            },
            {
                "operation": "compile_and_stage",
                "nativeSymbol": "AgentdPromptPipelineOwner::compile_and_stage",
                "sourcePath": "codex-rs/hepta-agentd/src/prompt_runtime.rs",
                "authority": "source composed; no provider authority",
            },
        ],
        "sourceObjects": source_objects,
        "tests": tests,
        "qualification": {
            "workflow": ".github/workflows/prompt-registry-qualification.yml",
            "receiptGenerator": "scripts/hepta-prompt-registry-qualification-receipt.py",
            "requiredCandidates": ["exact-head", "synthetic-merge"],
            "requiredChecks": [
                "fmt",
                "unit-integration",
                "strict-clippy",
                "cargo-shear",
                "protocol-schema-validation",
            ],
        },
    }


def render() -> str:
    return json.dumps(document(), indent=2, sort_keys=True) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    rendered = render()
    if args.check:
        if not OUTPUT.exists() or OUTPUT.read_text(encoding="utf-8") != rendered:
            raise SystemExit(
                "prompt.registry IMPLEMENTATION_MAP.json is stale; run "
                "scripts/hepta-prompt-registry-implementation-map.py"
            )
        return 0
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(rendered, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
''',
)
os.chmod(ROOT / "scripts/hepta-prompt-registry-implementation-map.py", 0o755)

write(
    "scripts/hepta-prompt-registry-validate.py",
    r'''#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAP = ROOT / "docs/modules/prompt.registry/IMPLEMENTATION_MAP.json"


def main() -> int:
    document = json.loads(MAP.read_text(encoding="utf-8"))
    if document.get("schema") != "hepta.module-implementation-map.v4":
        raise SystemExit("unexpected implementation-map schema")
    if document.get("moduleId") != "prompt.registry":
        raise SystemExit("wrong module id")
    status = document.get("status", {})
    for key in ("sourceImplemented", "sourceComposed"):
        if status.get(key) is not True:
            raise SystemExit(f"{key} must be true")
    for key in ("productActivated", "accepted", "released", "productionReady"):
        if status.get(key) is not False:
            raise SystemExit(f"{key} must remain false before external qualification")
    storage = document.get("storage", {})
    if storage.get("semanticSchema") != 4 or storage.get("physicalSchema") != 4:
        raise SystemExit("prompt registry must publish schema V4")
    seen = set()
    for item in document.get("sourceObjects", []) + document.get("tests", []):
        path = item.get("path")
        if not path or path in seen or not (ROOT / path).is_file():
            raise SystemExit(f"invalid mapped path: {path!r}")
        seen.add(path)
        if len(item.get("gitBlob", "")) != 40 or len(item.get("sha256", "")) != 64:
            raise SystemExit(f"invalid source identity for {path}")
    technical = (ROOT / "docs/modules/prompt.registry/TECHNICAL.md").read_text(
        encoding="utf-8"
    )
    if "bounded in-memory" in technical.lower() and "not durable" in technical.lower():
        raise SystemExit("stale in-memory-only claim remains in technical documentation")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
''',
)
os.chmod(ROOT / "scripts/hepta-prompt-registry-validate.py", 0o755)

write(
    "scripts/hepta-prompt-registry-qualification-receipt.py",
    r'''#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE_PATHS = [
    "codex-rs/hepta-prompt-registry/src/lib.rs",
    "codex-rs/hepta-prompt-registry/src/admission.rs",
    "codex-rs/hepta-prompt-registry/src/delivery.rs",
    "codex-rs/hepta-prompt-registry/src/durable.rs",
    "codex-rs/hepta-prompt-registry/src/durable_payloads.rs",
    "codex-rs/hepta-prompt-registry/src/v2.rs",
    "codex-rs/hepta-prompt-optimizer/src/canonical.rs",
    "codex-rs/hepta-prompt-optimizer/src/graph.rs",
    "codex-rs/hepta-agentd/src/prompt_runtime.rs",
]


def git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", required=True, choices=("exact-head", "synthetic-merge"))
    parser.add_argument("--base-sha", required=True)
    parser.add_argument("--head-sha", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    source_rows = []
    aggregate = hashlib.sha256()
    for path in SOURCE_PATHS:
        blob = git("hash-object", path)
        digest = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
        aggregate.update(path.encode())
        aggregate.update(bytes.fromhex(blob))
        aggregate.update(bytes.fromhex(digest))
        source_rows.append({"path": path, "gitBlob": blob, "sha256": digest})
    receipt = {
        "schema": "hepta.prompt-registry.qualification-receipt.v1",
        "candidate": args.candidate,
        "runId": os.environ.get("GITHUB_RUN_ID", "local"),
        "runAttempt": os.environ.get("GITHUB_RUN_ATTEMPT", "1"),
        "repository": os.environ.get("GITHUB_REPOSITORY", "local"),
        "headSha": args.head_sha,
        "baseSha": args.base_sha,
        "candidateCommit": git("rev-parse", "HEAD"),
        "candidateTree": git("rev-parse", "HEAD^{tree}"),
        "sourceBlobDigest": aggregate.hexdigest(),
        "sourceObjects": source_rows,
        "checks": {
            "fmt": "passed",
            "unitIntegration": "passed",
            "strictClippy": "passed",
            "cargoShear": "passed",
            "protocolSchemaValidation": "passed",
        },
        "authority": {
            "sourceQualified": True,
            "productActivated": False,
            "accepted": False,
            "released": False,
            "productionReady": False,
        },
    }
    output = ROOT / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
''',
)
os.chmod(ROOT / "scripts/hepta-prompt-registry-qualification-receipt.py", 0o755)

# Accurate dossier: source facts and authority ceilings are explicit.
write(
    "qualification/module-execution-dossiers/detail/prompt.registry.md",
    r'''# `prompt.registry` execution dossier

## Exact source baseline

This dossier is generated and reviewed against the remediation source base
`main@a126987b84737dbc2ee2592442a314117bddb4a2`. Exact branch-head, base,
candidate-tree, run-id, and source-blob identities are emitted by the dedicated
qualification workflow rather than asserted by this prose document.

## Implemented source state

`codex-hepta-prompt-registry` is not an in-memory-only registry. The
`DurablePromptRegistry` owner uses an exclusive state-directory lock,
clone-mutate-persist-swap publication, immutable payload extents, metadata
temporary-file fsync, atomic rename, directory fsync, and a poisoned/reopen
state after indeterminate post-rename durability.

Storage schema V4 persists factors, factor relations, realizations, exact model
bindings, payload references, supersession links, and lifecycle events in one
metadata snapshot. The snapshot digest and graph source include the persisted
relations. V1/V2/V3 state remains readable and is republished as V4 only on a
subsequent mutation.

The Agentd source tree composes one durable registry owner with the canonical
prompt optimizer, intelligence compiler, durable prompt runtime, and embedded
App Server prompt-runtime host. This is **source composition**, not proof of
product activation or release.

## Five independent states

| State | Current value | Meaning |
|---|---:|---|
| source implemented | true | Durable registry, V2 protocol, final-use admission, optimizer bridge, and runtime source exist. |
| source composed | true | Agentd opens the registry/runtime owners and installs the runtime host. |
| product activated | false | No deployment assertion is made by source code or this dossier. |
| accepted | false | Independent acceptance authority has not issued acceptance. |
| released | false | Independent release authority has not issued release. |

`productionReady` is false until both exact-head and deterministic
synthetic-merge qualification receipts are green and the independent
acceptance/release authorities act.

## Required qualification

The dedicated workflow runs, for both candidate identities:

1. formatting without mutation;
2. registry, optimizer, and Agentd prompt-runtime unit/integration tests;
3. strict Clippy;
4. Cargo shear orphan/dependency validation;
5. implementation-map and protocol/schema validation.

Each retained receipt binds the GitHub run id, run attempt, head SHA, base SHA,
candidate commit/tree, and a digest over exact source blobs. A skipped,
cancelled, missing, stale, or failed lane is not qualification.

## Authority ceiling

The registry and all receipts are deny-all with respect to model/provider
authority, deployment, acceptance, merge, and release. A green source
qualification receipt is evidence about one exact candidate only. It cannot
activate a product, approve external effects, or grant release authority.
''',
)

# Update TECHNICAL's stale storage-version wording and add explicit state matrix.
technical_path = "docs/modules/prompt.registry/TECHNICAL.md"
technical = read(technical_path)
technical = technical.replace("V3", "V4")
state_section = r'''
## Capability state matrix

The module tracks five independent states and never infers one from another:

- **source implemented** — source and tests exist for the capability;
- **source composed** — a named product owner wires the source into its runtime;
- **product activated** — a deployment authority has enabled the capability;
- **accepted** — an independent acceptance authority has accepted the exact candidate;
- **released** — an independent release authority has released the exact candidate.

At this revision, source implementation and source composition are true.
Product activation, acceptance, release, and production readiness remain false.
The dedicated exact-head and synthetic-merge qualification receipts are
necessary source evidence but do not grant any of those external authorities.

'''
if "## Capability state matrix" not in technical:
    marker = "\n## "
    first = technical.find(marker, technical.find("\n") + 1)
    if first == -1:
        technical += "\n" + state_section
    else:
        technical = technical[:first] + "\n" + state_section + technical[first:]
write(technical_path, technical)

# ---------------------------------------------------------------------------
# Dedicated exact-head/synthetic-merge qualification workflow.
# ---------------------------------------------------------------------------
write(
    ".github/workflows/prompt-registry-qualification.yml",
    r'''name: prompt.registry qualification

on:
  pull_request:
    paths:
      - "codex-rs/hepta-prompt-registry/**"
      - "codex-rs/hepta-prompt-optimizer/**"
      - "codex-rs/hepta-agentd/src/prompt_runtime*"
      - "codex-rs/hepta-agentd/src/state.rs"
      - "codex-rs/hepta-agentd/src/app_runtime.rs"
      - "docs/modules/prompt.registry/**"
      - "qualification/module-execution-dossiers/detail/prompt.registry.md"
      - "scripts/hepta-prompt-registry-*"
      - ".github/workflows/prompt-registry-qualification.yml"
  push:
    branches:
      - main
      - "codex/prompt-registry-*"
    paths:
      - "codex-rs/hepta-prompt-registry/**"
      - "codex-rs/hepta-prompt-optimizer/**"
      - "codex-rs/hepta-agentd/src/prompt_runtime*"
      - "codex-rs/hepta-agentd/src/state.rs"
      - "codex-rs/hepta-agentd/src/app_runtime.rs"
      - "docs/modules/prompt.registry/**"
      - "qualification/module-execution-dossiers/detail/prompt.registry.md"
      - "scripts/hepta-prompt-registry-*"
      - ".github/workflows/prompt-registry-qualification.yml"
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: prompt-registry-qualification-${{ github.ref }}
  cancel-in-progress: true

jobs:
  exact-head:
    name: exact-head
    runs-on: ubuntu-24.04
    steps:
      - uses: actions/checkout@de0fac2e4500dabe0009e67214ff5f5447ce83dd
        with:
          fetch-depth: 0
          persist-credentials: false
      - uses: ./.github/actions/setup-ci
      - uses: dtolnay/rust-toolchain@e081816240890017053eacbb1bdf337761dc5582
        with:
          toolchain: 1.95.0
          components: rustfmt,clippy
      - name: Install cargo-shear
        uses: taiki-e/install-action@44c6d64aa62cd779e873306675c7a58e86d6d532
        with:
          tool: cargo-shear@1.11.2
          checksum: true
      - name: Validate generated implementation map
        run: |
          python3 scripts/hepta-prompt-registry-implementation-map.py --check
          python3 scripts/hepta-prompt-registry-validate.py
      - name: Formatting without mutation
        working-directory: codex-rs
        run: cargo fmt --all --check
      - name: Unit and integration tests
        working-directory: codex-rs
        run: |
          cargo test -p codex-hepta-prompt-registry
          cargo test -p codex-hepta-prompt-optimizer
          cargo test -p codex-hepta-agentd prompt_runtime
      - name: Strict Clippy
        working-directory: codex-rs
        run: |
          cargo clippy -p codex-hepta-prompt-registry -p codex-hepta-prompt-optimizer -p codex-hepta-agentd --all-targets -- -D warnings
      - name: Cargo shear
        working-directory: codex-rs
        run: cargo shear --deny-warnings
      - name: Retain exact-head qualification receipt
        env:
          BASE_SHA: ${{ github.event.pull_request.base.sha || github.event.before || github.sha }}
          HEAD_SHA: ${{ github.event.pull_request.head.sha || github.sha }}
        run: |
          python3 scripts/hepta-prompt-registry-qualification-receipt.py \
            --candidate exact-head \
            --base-sha "$BASE_SHA" \
            --head-sha "$HEAD_SHA" \
            --output qualification-receipts/prompt-registry-exact-head.json
      - uses: actions/upload-artifact@65c4c4a1ddee5b72f698fdd19549f0f0fb45cf08
        with:
          name: prompt-registry-exact-head
          path: qualification-receipts/prompt-registry-exact-head.json
          if-no-files-found: error

  synthetic-merge:
    name: synthetic-merge
    runs-on: ubuntu-24.04
    steps:
      - uses: actions/checkout@de0fac2e4500dabe0009e67214ff5f5447ce83dd
        with:
          fetch-depth: 0
          persist-credentials: false
      - name: Construct deterministic base-first merge candidate
        id: candidate
        env:
          PR_BASE: ${{ github.event.pull_request.base.sha }}
          PR_HEAD: ${{ github.event.pull_request.head.sha }}
        run: |
          set -euo pipefail
          base="${PR_BASE:-$(git rev-parse origin/main)}"
          head="${PR_HEAD:-$(git rev-parse HEAD)}"
          git config user.name "prompt.registry qualification"
          git config user.email "prompt-registry-qualification@users.noreply.github.com"
          git checkout --detach "$base"
          git merge --no-ff --no-commit "$head"
          tree="$(git write-tree)"
          candidate="$(printf '%s\n' 'prompt.registry deterministic synthetic merge' | git commit-tree "$tree" -p "$base" -p "$head")"
          git reset --hard "$candidate"
          echo "base=$base" >> "$GITHUB_OUTPUT"
          echo "head=$head" >> "$GITHUB_OUTPUT"
          echo "candidate=$candidate" >> "$GITHUB_OUTPUT"
      - uses: ./.github/actions/setup-ci
      - uses: dtolnay/rust-toolchain@e081816240890017053eacbb1bdf337761dc5582
        with:
          toolchain: 1.95.0
          components: rustfmt,clippy
      - name: Install cargo-shear
        uses: taiki-e/install-action@44c6d64aa62cd779e873306675c7a58e86d6d532
        with:
          tool: cargo-shear@1.11.2
          checksum: true
      - name: Validate generated implementation map
        run: |
          python3 scripts/hepta-prompt-registry-implementation-map.py --check
          python3 scripts/hepta-prompt-registry-validate.py
      - name: Formatting without mutation
        working-directory: codex-rs
        run: cargo fmt --all --check
      - name: Unit and integration tests
        working-directory: codex-rs
        run: |
          cargo test -p codex-hepta-prompt-registry
          cargo test -p codex-hepta-prompt-optimizer
          cargo test -p codex-hepta-agentd prompt_runtime
      - name: Strict Clippy
        working-directory: codex-rs
        run: |
          cargo clippy -p codex-hepta-prompt-registry -p codex-hepta-prompt-optimizer -p codex-hepta-agentd --all-targets -- -D warnings
      - name: Cargo shear
        working-directory: codex-rs
        run: cargo shear --deny-warnings
      - name: Retain synthetic-merge qualification receipt
        run: |
          python3 scripts/hepta-prompt-registry-qualification-receipt.py \
            --candidate synthetic-merge \
            --base-sha "${{ steps.candidate.outputs.base }}" \
            --head-sha "${{ steps.candidate.outputs.head }}" \
            --output qualification-receipts/prompt-registry-synthetic-merge.json
      - uses: actions/upload-artifact@65c4c4a1ddee5b72f698fdd19549f0f0fb45cf08
        with:
          name: prompt-registry-synthetic-merge
          path: qualification-receipts/prompt-registry-synthetic-merge.json
          if-no-files-found: error

  required:
    name: prompt.registry required
    if: always()
    needs: [exact-head, synthetic-merge]
    runs-on: ubuntu-24.04
    steps:
      - name: Require both exact candidates
        env:
          EXACT: ${{ needs.exact-head.result }}
          MERGE: ${{ needs.synthetic-merge.result }}
        run: |
          test "$EXACT" = success
          test "$MERGE" = success
''',
)

# Generate the map after all mapped source/test files are in place.
run("python3", "scripts/hepta-prompt-registry-implementation-map.py")
run("python3", "scripts/hepta-prompt-registry-validate.py")

# Remove the one-shot bootstrap mechanism from the resulting source commit.
for relative in [
    "scripts/.prompt_registry_remediation_bootstrap.py",
    ".github/workflows/prompt-registry-remediation-bootstrap.yml",
]:
    path = ROOT / relative
    if path.exists():
        path.unlink()