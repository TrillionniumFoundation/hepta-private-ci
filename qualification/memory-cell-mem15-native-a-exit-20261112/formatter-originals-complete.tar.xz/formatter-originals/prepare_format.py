import hashlib,json,os,shutil,subprocess,time,traceback
from pathlib import Path
ROOT=Path("/home/qq/work/mem15-native-qualification-20261112-ef0c")
CACHE=Path("/home/qq/work/mem13-native-qualification-20261112-ef0c/source")
SOURCE=ROOT/"source-draft"
COMMIT="b0e4ba507aa3e1d7dee8158b54a61453035d75e6"
TREE="7bfc61aa8a8b1d408b679dee279ddcf8f9425368"
BASE="7f6b5b80cf4528aabd44ad2df1a93d7f70e7590d"
ROOT.mkdir(exist_ok=False)
ENV=dict(os.environ)
ENV.update(PATH="/home/qq/.cargo/bin:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/just-1.58.0:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/uv-0.13.5:"+ENV.get("PATH","/usr/bin:/bin"),RUSTUP_TOOLCHAIN="1.96.0",GIT_TERMINAL_PROMPT="0",PYTHONDONTWRITEBYTECODE="1")
R={"schema":"hepta.mem15.pretest-native-format.v1","source_commit":COMMIT,"source_tree":TREE,"base":BASE,"started_unix_ns":time.time_ns(),"status":"running","commands":[],"tests_executed":0,"model_calls":0,"pretest_format_only":True}
def digest(p):
 b=p.read_bytes();return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
def save():
 t=ROOT/"FORMAT.pending.json";t.write_text(json.dumps(R,indent=2)+"\n");t.replace(ROOT/"FORMAT.json")
def run(label,args,cwd):
 log=ROOT/(label+".log");started=time.time_ns()
 with log.open("wb") as f:c=subprocess.run(args,cwd=cwd,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 R["commands"].append({"name":label,"command":args,"started_unix_ns":started,"finished_unix_ns":time.time_ns(),"exit_code":c.returncode,"log":str(log),**digest(log)})
 save()
 if c.returncode:raise RuntimeError(label+" failed")
def git(*args,env=None):
 return subprocess.check_output(["git","-C",str(SOURCE),*args],env=env or ENV).decode().strip()
def identity():
 return {"commit":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"status":git("status","--porcelain")}
try:
 save()
 run("fetch-draft",["git","-C",str(CACHE),"fetch","--no-tags","--depth=5","https://github.com/TrillionniumFoundation/hepta-private-ci.git",COMMIT],ROOT)
 run("isolated-worktree",["git","-C",str(CACHE),"worktree","add","--detach",str(SOURCE),COMMIT],ROOT)
 if identity()!={"commit":COMMIT,"tree":TREE,"status":""}:raise RuntimeError("draft source identity mismatch")
 R["before"]=identity()
 paths=git("diff","--name-only","--diff-filter=ACMRT",BASE,COMMIT).splitlines()
 R["draft_postimages"]={p:digest(SOURCE/p) for p in paths}
 run("tool-versions",["/bin/sh","-c","rustfmt --version && just --version && uv --version"],SOURCE)
 run("just-format",["just","fmt","--base",BASE],SOURCE)
 R["after"]=identity()
 patch=subprocess.check_output(["git","-C",str(SOURCE),"diff","--binary","HEAD"],env=ENV)
 (ROOT/"FORMAT.patch").write_bytes(patch)
 changed=git("diff","--name-only","HEAD").splitlines()
 R["format_changed_paths"]=changed
 R["format_patch"]=digest(ROOT/"FORMAT.patch")
 for path in sorted(set(paths+changed)):
  dest=ROOT/"formatted-postimages"/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE/path,dest)
 R["formatted_postimages"]={p:digest(SOURCE/p) for p in sorted(set(paths+changed))}
 index_env=dict(ENV,GIT_INDEX_FILE=str(ROOT/"formatted.index"))
 git("read-tree","HEAD",env=index_env)
 git("add","--update",env=index_env)
 R["formatted_tree"]=git("write-tree",env=index_env)
 R["source_bytes_changed"]=bool(changed)
 R["status"]="formatted_pending_publication"
except BaseException as error:
 R["status"]="failed";R["error"]=type(error).__name__+": "+str(error);(ROOT/"exception.txt").write_text(traceback.format_exc())
finally:
 R["finished_unix_ns"]=time.time_ns();save();print(json.dumps(R,indent=2))
if R["status"]!="formatted_pending_publication":raise SystemExit(1)
