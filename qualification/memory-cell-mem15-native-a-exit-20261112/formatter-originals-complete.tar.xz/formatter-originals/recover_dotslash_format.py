import hashlib,io,json,os,shutil,subprocess,tarfile,time,traceback,urllib.request
from pathlib import Path
ROOT=Path("/home/qq/work/mem15-native-qualification-20261112-ef0c")
OUT=ROOT/"format-recovery01"
SOURCE=ROOT/"source-draft"
COMMIT="b0e4ba507aa3e1d7dee8158b54a61453035d75e6"
TREE="7bfc61aa8a8b1d408b679dee279ddcf8f9425368"
BASE="7f6b5b80cf4528aabd44ad2df1a93d7f70e7590d"
OUT.mkdir(exist_ok=False)
ENV=dict(os.environ)
ENV.update(PATH=str(OUT/"bin")+":/home/qq/.cargo/bin:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/just-1.58.0:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/uv-0.13.5:"+ENV.get("PATH","/usr/bin:/bin"),RUSTUP_TOOLCHAIN="1.96.0",PYTHONDONTWRITEBYTECODE="1",XDG_CACHE_HOME=str(OUT/"tool-cache"))
R={"schema":"hepta.mem15.pretest-format-recovery.v1","source_commit":COMMIT,"source_tree":TREE,"base":BASE,"started_unix_ns":time.time_ns(),"status":"running","commands":[],"tests_executed":0,"model_calls":0,"system_packages_modified":False,"pretest_format_only":True}
def digest(p):
 b=p.read_bytes();return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
def save():
 p=OUT/"RESULT.pending.json";p.write_text(json.dumps(R,indent=2)+"\n");p.replace(OUT/"RESULT.json")
def git(*args,env=None):
 return subprocess.check_output(["git","-C",str(SOURCE),*args],env=env or ENV).decode().strip()
def run(label,args):
 p=OUT/(label+".log");start=time.time_ns()
 with p.open("wb") as f:c=subprocess.run(args,cwd=SOURCE,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 R["commands"].append({"name":label,"command":args,"started_unix_ns":start,"finished_unix_ns":time.time_ns(),"exit_code":c.returncode,"log":str(p),**digest(p)})
 save()
 if c.returncode:raise RuntimeError(label+" failed")
def get(url,limit):
 req=urllib.request.Request(url,headers={"User-Agent":"hepta-native-task-local-tool-preparation","Accept":"application/vnd.github+json"} if "api.github.com" in url else {"User-Agent":"hepta-native-task-local-tool-preparation"})
 with urllib.request.urlopen(req,timeout=60) as r:b=r.read(limit+1);final=r.url
 if len(b)>limit:raise RuntimeError("public tool download byte cap exceeded")
 return b,final
try:
 save()
 old=json.loads((ROOT/"FORMAT.json").read_text())
 if old.get("status")!="failed" or old.get("source_commit")!=COMMIT or old.get("error")!="RuntimeError: just-format failed":
  raise RuntimeError("original formatter failure not established")
 if digest(ROOT/"just-format.log")["sha256"]!="fb3df0a6a7e4231768579db6a245908c1de6aec2210f92f95f62b5ab2a9ebaf4":
  raise RuntimeError("original missing-dotslash log changed")
 if git("rev-parse","HEAD")!=COMMIT or git("rev-parse","HEAD^{tree}")!=TREE:
  raise RuntimeError("draft source identity changed")
 R["original_format_result"]=digest(ROOT/"FORMAT.json")
 (OUT/"first-format-partial.patch").write_bytes(subprocess.check_output(["git","-C",str(SOURCE),"diff","--binary","HEAD"],env=ENV))
 R["first_format_partial_patch"]=digest(OUT/"first-format-partial.patch")
 R["first_format_changed_paths"]=git("diff","--name-only","HEAD").splitlines()
 raw,url=get("https://api.github.com/repos/meta/dotslash/releases/tags/v0.5.9",1048576)
 (OUT/"dotslash-release.json").write_bytes(raw)
 release=json.loads(raw)
 if release.get("tag_name")!="v0.5.9" or release.get("draft") or release.get("prerelease"):
  raise RuntimeError("unexpected official DotSlash release identity")
 assets=[a for a in release["assets"] if a["name"]=="dotslash-ubuntu-22.04.x86_64.tar.gz"]
 if len(assets)!=1:raise RuntimeError("exact Linux DotSlash release asset absent")
 asset=assets[0];expected=asset.get("digest","")
 if not expected.startswith("sha256:") or len(expected)!=71:
  raise RuntimeError("official release asset has no SHA256 digest")
 if not asset["browser_download_url"].startswith("https://github.com/meta/dotslash/releases/download/v0.5.9/"):
  raise RuntimeError("unexpected official asset source")
 tar_raw,resolved=get(asset["browser_download_url"],33554432)
 if len(tar_raw)!=asset["size"] or hashlib.sha256(tar_raw).hexdigest()!=expected[7:]:
  raise RuntimeError("official DotSlash asset size/SHA256 mismatch")
 tar_path=OUT/asset["name"];tar_path.write_bytes(tar_raw)
 with tarfile.open(fileobj=io.BytesIO(tar_raw),mode="r:gz") as t:
  members=[m for m in t.getmembers() if m.name=="dotslash"]
  if len(members)!=1 or not members[0].isfile() or members[0].size>33554432:
   raise RuntimeError("DotSlash artifact does not contain exactly one regular binary")
  binary=t.extractfile(members[0]).read()
 bin_dir=OUT/"bin";bin_dir.mkdir()
 exe=bin_dir/"dotslash";exe.write_bytes(binary);exe.chmod(0o755)
 R["dotslash"]={"tag":release["tag_name"],"release_api":url,"release_metadata":digest(OUT/"dotslash-release.json"),"asset_name":asset["name"],"asset_id":asset["id"],"official_asset_digest":expected,"asset_url":asset["browser_download_url"],"archive":digest(tar_path),"binary":digest(exe)}
 run("dotslash-help",[str(exe),"--help"])
 manifest=SOURCE/"tools/buildifier"
 entry=json.loads(manifest.read_text().split("\n",1)[1])["platforms"]["linux-x86_64"]
 if entry["digest"]!="887377fc64d23a850f4d18a077b5db05b19913f4b99b270d193f3c7334b5a9a7":
  raise RuntimeError("repository pinned Buildifier changed")
 R["buildifier_manifest"]={"path":str(manifest),**digest(manifest),"platform":entry}
 run("pinned-buildifier-version",[str(exe),str(manifest),"--version"])
 resolved_artifacts=[]
 for p in (OUT/"tool-cache").rglob("*"):
  if p.is_file() and not p.is_symlink() and p.stat().st_size==entry["size"] and digest(p)["sha256"]==entry["digest"]:
   resolved_artifacts.append({"path":str(p),**digest(p)})
 if not resolved_artifacts:raise RuntimeError("pinned Buildifier bytes unavailable in task-local cache")
 R["buildifier_resolved"]=resolved_artifacts
 run("just-format",["just","fmt","--base",BASE])
 R["status"]="formatted_pending_publication"
except BaseException as error:
 R["status"]="failed";R["error"]=type(error).__name__+": "+str(error);(OUT/"exception.txt").write_text(traceback.format_exc())
finally:
 try:
  patch=OUT/"FORMAT.patch";patch.write_bytes(subprocess.check_output(["git","-C",str(SOURCE),"diff","--binary","HEAD"],env=ENV))
  R["format_patch"]=digest(patch)
  paths=git("diff","--name-only","--diff-filter=ACMRT",BASE,COMMIT).splitlines()
  changed=git("diff","--name-only","HEAD").splitlines();R["format_changed_paths"]=changed
  R["formatted_postimages"]={p:digest(SOURCE/p) for p in sorted(set(paths+changed))}
  for path in sorted(set(paths+changed)):
   dest=OUT/"postimages"/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE/path,dest)
  index_env=dict(ENV,GIT_INDEX_FILE=str(OUT/"formatted.index"))
  git("read-tree","HEAD",env=index_env);git("add","--update",env=index_env)
  R["formatted_tree"]=git("write-tree",env=index_env)
  R["formatted_codex_rs_tree"]=git("rev-parse",R["formatted_tree"]+":codex-rs")
  R["source_after"]={"commit":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"status":git("status","--porcelain")}
 except BaseException as e:R["collection_error"]=type(e).__name__+": "+str(e)
 R["finished_unix_ns"]=time.time_ns();save();print(json.dumps(R,indent=2))
if R["status"]!="formatted_pending_publication":raise SystemExit(1)
