import base64
import datetime as dt
import hashlib
import json
import tarfile
from pathlib import Path, PurePosixPath

D = Path('/workspace/scratch/ef0c911c24f4/mem15-native-capture/initial-recovered')
EXPECTED_ARCHIVE = '7ccd0c04afabd3faa37a21f8431b3791235e3a1f963bb658cc4e29e729276b8d'
SOURCE = 'bbbcc63003a88d0396a9694222dc98dc8c0d59d6'
TREE = 'fe00b2618f39e942ec6b1a8af2d63ec585e5f892'
CODEX_TREE = 'ed240f298fa2cbb104c65054596e64e7d1e9bca8'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def meta(b):
    return {'bytes': len(b), 'sha256': sha(b)}

def body(value):
    return value.get('structuredContent') or json.loads(next(c['text'] for c in value['content'] if c['type'] == 'text'))

def write_exact(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.is_file() and not path.is_symlink() and path.read_bytes() == data, path
    else:
        path.write_bytes(data)

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

archive = (D / 'capture-bbbcc630-01.tar.xz').read_bytes()
assert len(archive) == 68348 and sha(archive) == EXPECTED_ARCHIVE
chunks = []
combined = b''
for offset, folder in [(0, 'archive-000000'), (65536, 'archive-065536')]:
    p = D / 'transport' / folder
    envelope = json.loads((p / 'READBACK.json').read_bytes())
    request = envelope['request']
    assert request['operation']['tool'] == 'binary_read'
    assert request['operation']['arguments']['offset'] == offset
    pages = [body(page) for page in envelope['pages']]
    sdk = b''
    for page in pages:
        data = base64.b64decode(page['data_base64'], validate=True)
        assert page['offset'] == len(sdk) and page['next_offset'] == len(sdk) + len(data)
        assert page['result_sha256'] == pages[0]['result_sha256']
        assert page['operation_id'] == pages[0]['operation_id']
        sdk += data
    assert pages[-1]['eof'] and len(sdk) == pages[-1]['total_bytes'] and sha(sdk) == pages[-1]['result_sha256']
    assert sdk == (p / 'original-sdk-payload.json').read_bytes()
    content = body(json.loads(sdk))
    chunk = base64.b64decode(content['data_base64'], validate=True)
    assert chunk == (p / 'original-chunk.bin').read_bytes()
    assert sha(chunk) == content['chunk_sha256']
    assert content['offset'] == offset == len(combined)
    assert content['next_offset'] == offset + len(chunk) and content['size'] == 68348
    if chunks:
        assert request['operation']['arguments']['expected_version'] == chunks[0]['version'] == content['version']
    else:
        assert 'expected_version' not in request['operation']['arguments']
    combined += chunk
    chunks.append({'offset': offset, 'bytes': len(chunk), 'sha256': sha(chunk),
                   'version': content['version'], 'operation_id': pages[0]['operation_id'],
                   'original_sdk': meta(sdk), 'sdk_pages': len(pages), 'eof': content['eof']})
assert combined == archive and chunks[-1]['eof'] and not chunks[0]['eof']

source_sdk = (D / 'PUBLICATION_AND_BLOCKER.original-sdk-payload.json').read_bytes()
source_body = body(json.loads(source_sdk))
assert source_body['truncated'] is False
source_files = {}
for item in source_body['files']:
    data = item['text'].encode()
    assert len(data) == item['size'] and sha(data) == item['sha256']
    name = PurePosixPath(item['path']).name
    assert (D / name).read_bytes() == data
    source_files[name] = data
publication = json.loads(source_files['CAPTURE_BBBCC630_01_PUBLICATION.json'])
assert publication['bytes'] == len(archive) and publication['sha256'] == sha(archive)
assert publication['status'] == 'incomplete'

with tarfile.open(D / 'capture-bbbcc630-01.tar.xz', 'r:xz') as tf:
    members = tf.getmembers()
    seen = set()
    contents = {}
    total_bytes = 0
    for item in members:
        path = PurePosixPath(item.name)
        assert item.name and not path.is_absolute() and '..' not in path.parts and '\\' not in item.name
        assert item.name not in seen and (item.isfile() or item.isdir()), item.name
        seen.add(item.name)
        assert item.size <= 8 * 1024 * 1024
        total_bytes += item.size
        assert total_bytes <= 64 * 1024 * 1024
        if item.isfile():
            contents[item.name] = tf.extractfile(item).read()
    manifest = json.loads(contents['MEMBER_MANIFEST.json'])
    assert set(manifest) == set(contents) - {'MEMBER_MANIFEST.json'}
    for name, expected in manifest.items():
        assert meta(contents[name]) == expected, name
    for name, data in contents.items():
        write_exact(D / 'extracted' / name, data)

result_bytes = contents['RESULT.json']
write_exact(D / 'RESULT.json', result_bytes)
result = json.loads(result_bytes)
plan = json.loads(contents['PLAN.json'])
assert result['status'] == 'incomplete'
assert result['source_commit'] == plan['source_commit'] == SOURCE
assert result['source_tree'] == plan['source_tree'] == TREE
assert result['codex_rs_tree'] == plan['codex_rs_tree'] == CODEX_TREE
assert result['source_before'] == result['source_after']
assert result['source_before'] == {'commit': SOURCE, 'tree': TREE, 'codex_rs_tree': CODEX_TREE, 'status': ''}
assert result['source_unchanged'] is True and contents['source-rewrites.patch'] == b''

postimages = {}
for path, pin in result['formatted_postimages'].items():
    data = contents['source-postimages/' + path]
    assert meta(data) == {k: pin[k] for k in ['bytes', 'sha256']}
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == pin['git_blob']
    postimages[path] = meta(data)
for path, pin in result['adapter_source_pins'].items():
    fullpath = 'scripts/' + path
    data = contents['source-postimages/' + fullpath]
    assert meta(data) == pin
    postimages[fullpath] = pin
assert set('source-postimages/' + p for p in postimages) == {p for p in contents if p.startswith('source-postimages/')}

phases = {phase['name']: phase for phase in result['phases']}
assert list(phases) == ['fetch-final', 'new-worktree', 'verified-v8', 'native-binaries', 'capture-precompile', 'final-format']
receipt_verifications = []
for name in ['verified-v8', 'native-binaries', 'capture-precompile', 'final-format']:
    phase = phases[name]
    receipt_name = name + '.receipt.json'
    receipt = json.loads(contents[receipt_name])
    assert receipt == phase['receipt']
    expected_exit = 2 if name == 'capture-precompile' else 0
    assert phase['exit_code'] == receipt['command_exit_code'] == receipt['exit_code'] == receipt['returncode'] == expected_exit
    assert phase['status'] == receipt['status'] == ('failed' if expected_exit else 'passed')
    assert receipt['timed_out'] is False and receipt['output_limit_exceeded'] is False
    assert receipt['before'] == receipt['after']
    assert receipt['before']['commit'] == SOURCE and receipt['before']['tree'] == TREE and receipt['before']['dirty'] is False
    assert receipt['source_sha'] == receipt['tested_sha'] == SOURCE
    assert receipt['command'] == phase['command']
    log = contents[receipt['log_file']]
    assert meta(log) == {'bytes': receipt['log_bytes'], 'sha256': receipt['log_sha256']}
    assert receipt['observed_passed_tests'] == receipt['observed_failed_tests'] == 0
    started = dt.datetime.fromisoformat(receipt['started_at']).timestamp()
    finished = dt.datetime.fromisoformat(receipt['finished_at']).timestamp()
    assert phase['started_unix_ns'] / 1e9 <= started <= finished <= phase['finished_unix_ns'] / 1e9
    receipt_verifications.append({'phase': name, 'exit_code': expected_exit, 'status': phase['status'],
                                  'receipt': meta(contents[receipt_name]), 'log': meta(log),
                                  'source_before_after_clean': True, 'observed_tests': 0})

precompile = phases['capture-precompile']
log_name = precompile['receipt']['log_file']
log = contents[log_name]
assert log == source_files[log_name]
text = log.decode()
assert "the argument '--no-fail-fast' cannot be used with '--no-run'" in text
assert 'cargo nextest run --no-fail-fast' in text and '--no-run' in precompile['command']
assert result['arms'] == [] and result['new_controls_passed'] is False
assert result['model_generation_count'] is None and result['physical_native_http_count'] is None
assert result['observer_authenticated'] is False and result['scored_memory_benefit_episodes'] == 0
assert result['scientific_acceptance'] == 'HOLD' and result['fixture_only'] is True
assert result['format_passed'] is True
assert result['binaries_before'] == result['binaries_after'] and result['binary_bytes_unchanged'] is True
assert set(result['binaries_before']) == {'codex', 'hepta-infer-worker'}

terminal_sdk = (D / 'TERMINAL.original-sdk-payload.json').read_bytes()
terminal_envelope = json.loads((D / 'transport/terminal/READBACK.json').read_bytes())
page = body(terminal_envelope['pages'][0])
assert page['eof'] and page['offset'] == 0 and page['total_bytes'] == page['next_offset'] == len(terminal_sdk)
assert base64.b64decode(page['data_base64'], validate=True) == terminal_sdk and sha(terminal_sdk) == page['result_sha256']
terminal = body(json.loads(terminal_sdk))
assert terminal == json.loads((D / 'TERMINAL.json').read_bytes())
assert terminal['job_id'] == '1a1cf155b58-2564-197e' and terminal['state'] == 'failed' and terminal['exit_code'] == 1
assert terminal['timed_out'] is terminal['cancelled'] is False
assert terminal['output_complete'] is terminal['output_durable'] is terminal['terminal_publication_confirmed'] is True
assert terminal['log_truncated'] == {'stderr': False, 'stdout': False}
assert terminal['at_unix_ms'] * 1000000 >= result['finished_unix_ns']

verification = {
    'schema': 'hepta.mem15.initial-native-capture-readonly-recovery.v1',
    'original_archive': {'file': 'capture-bbbcc630-01.tar.xz', **meta(archive), 'complete': True},
    'original_archive_sdk_transport': {'chunks': chunks, 'all_original_sdk_and_chunk_hashes_verified': True, 'version_pinned_after_first_chunk': True},
    'publication': {'file': 'CAPTURE_BBBCC630_01_PUBLICATION.json', **meta(source_files['CAPTURE_BBBCC630_01_PUBLICATION.json']), 'matches_whole_archive': True},
    'publication_and_blocker_original_sdk': meta(source_sdk),
    'tar_safety': {'members': len(members), 'regular_files': len(contents), 'directories': len(members) - len(contents), 'unsafe_paths': 0, 'links': 0, 'special_files': 0, 'duplicate_paths': 0},
    'original_member_manifest': {'file': 'extracted/MEMBER_MANIFEST.json', **meta(contents['MEMBER_MANIFEST.json']), 'entries': len(manifest), 'all_member_hashes_verified': True, 'covers_all_other_regular_files': True},
    'original_result': {'file': 'RESULT.json', **meta(result_bytes), 'status': result['status'], 'original_bytes_preserved': True},
    'terminal': {k: terminal[k] for k in ['job_id', 'state', 'exit_code', 'timed_out', 'cancelled', 'output_complete', 'output_durable', 'terminal_publication_confirmed']},
    'terminal_original_sdk': {'file': 'TERMINAL.original-sdk-payload.json', **meta(terminal_sdk)},
    'source': {'commit': SOURCE, 'tree': TREE, 'codex_rs_tree': CODEX_TREE, 'clean_before_and_after': True, 'source_unchanged': True,
               'archived_postimages_verified': len(postimages), 'formatted_postimages_verified': len(result['formatted_postimages']),
               'adapter_postimages_verified': len(result['adapter_source_pins']), 'source_rewrite_patch_bytes': 0},
    'phase_receipts': receipt_verifications,
    'capture_precompile_failure': {'exit_code': 2, 'cause': 'just test expands to cargo nextest run --no-fail-fast; --no-fail-fast cannot be combined with --no-run',
                                    'original_log': {'file': 'extracted/' + log_name, **meta(log)}, 'argument_parse_failure_before_test_execution': True},
    'execution_boundary': {'new_control_tests_executed': 0, 'capture_arms_started': 0,
                           'basis': 'Only setup, verified-v8, native-binaries, failed capture-precompile, and final-format phases occurred; all receipts observe zero tests; original arms array is empty.',
                           'original_model_generation_count': None, 'original_physical_native_http_count': None,
                           'original_null_measurements_preserved': True, 'observer_authenticated': False,
                           'scored_memory_benefit_episodes': 0, 'scientific_acceptance': 'HOLD'},
    'native_binaries_build_passed': True,
    'format_passed': True,
    'recorded_binaries_before': result['binaries_before'],
    'recorded_binaries_after': result['binaries_after'],
    'recorded_binary_bytes_unchanged': True,
    'binary_verification_basis': 'Identical recorded before/after pins in the original RESULT. Native binary bytes were not downloaded.',
    'recovery_actions': {'native_jobs_started': 0, 'tests_run': 0, 'model_calls_started': 0, 'code_changes': 0, 'publication_or_pr': False},
}
write_json(D / 'VERIFICATION.json', verification)
files = []
for path in sorted(D.rglob('*')):
    if path.is_file() and path.name != 'RECOVERY_MANIFEST.json':
        files.append({'path': path.relative_to(D).as_posix(), **meta(path.read_bytes())})
write_json(D / 'RECOVERY_MANIFEST.json', {'schema': 'hepta.mem15.initial-recovery-local-manifest.v1', 'files': files})
print(json.dumps({'archive': verification['original_archive'], 'manifest': verification['original_member_manifest'],
                  'result': verification['original_result'], 'terminal': verification['terminal'],
                  'source': verification['source'], 'execution_boundary': verification['execution_boundary'],
                  'recorded_binaries_before': result['binaries_before'], 'recovery_files': len(files)}, indent=2))
