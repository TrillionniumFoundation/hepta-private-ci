import base64
import datetime as dt
import hashlib
import json
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath

D = Path('/workspace/scratch/ef0c911c24f4/mem15-native-capture/continuation02-recovered')
P = D.parent / 'initial-recovered'
S = 'bbbcc63003a88d0396a9694222dc98dc8c0d59d6'
T = 'fe00b2618f39e942ec6b1a8af2d63ec585e5f892'
CT = 'ed240f298fa2cbb104c65054596e64e7d1e9bca8'
ARMS = ['attach', 'reader-off', 'withhold', 'tombstone']
CASE = 'production_composition::tests::episodic_control::provider::process::episodic_native_a_exit_capture'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def meta(b):
    return {'bytes': len(b), 'sha256': sha(b)}

def body(obj):
    return obj.get('structuredContent') or json.loads(next(c['text'] for c in obj['content'] if c['type'] == 'text'))

def write_exact(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.is_file() and not path.is_symlink() and path.read_bytes() == data, path
    else:
        path.write_bytes(data)

def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

def decode_sdk_pages(envelope):
    pages = [body(page) for page in envelope['pages']]
    output = b''
    proof = []
    for page in pages:
        b = base64.b64decode(page['data_base64'], validate=True)
        assert page['offset'] == len(output) and page['next_offset'] == len(output) + len(b)
        assert page['operation_id'] == pages[0]['operation_id'] and page['result_sha256'] == pages[0]['result_sha256']
        proof.append({'offset': page['offset'], **meta(b)})
        output += b
    assert pages[-1]['eof'] and len(output) == pages[-1]['total_bytes'] and sha(output) == pages[-1]['result_sha256']
    return output, {'operation_id': pages[0]['operation_id'], **meta(output), 'pages': proof}

archive = (D / 'capture-bbbcc630-02.tar.xz').read_bytes()
assert meta(archive) == {'bytes': 48456, 'sha256': 'f01514d24b24efc457ddda28dec880c5f292293b71ac4b534f4d5403d7b80fe4'}
archive_readback = json.loads((D / 'transport/archive-000000/READBACK.json').read_bytes())
sdk, archive_sdk_proof = decode_sdk_pages(archive_readback)
assert sdk == (D / 'transport/archive-000000/original-sdk-payload.json').read_bytes()
chunk = body(json.loads(sdk))
assert base64.b64decode(chunk['data_base64'], validate=True) == archive == (D / 'transport/archive-000000/original-chunk.bin').read_bytes()
assert chunk['offset'] == 0 and chunk['next_offset'] == chunk['size'] == len(archive) and chunk['eof'] is True
assert chunk['chunk_sha256'] == sha(archive)
assert archive_readback['request']['operation']['tool'] == 'binary_read'

pub_envelope = json.loads((D / 'transport/publication/READBACK.json').read_bytes())
pub_sdk, publication_sdk_proof = decode_sdk_pages(pub_envelope)
assert pub_sdk == (D / 'PUBLICATION.original-sdk-payload.json').read_bytes()
pub_body = body(json.loads(pub_sdk))
assert pub_body['truncated'] is False and len(pub_body['files']) == 1
pub_entry = pub_body['files'][0]
pub_bytes = pub_entry['text'].encode()
assert meta(pub_bytes) == {'bytes': pub_entry['size'], 'sha256': pub_entry['sha256']}
assert pub_bytes == (D / 'CAPTURE_BBBCC630_02_PUBLICATION.json').read_bytes()
publication = json.loads(pub_bytes)
assert publication['sha256'] == sha(archive) and publication['bytes'] == len(archive) and publication['status'] == 'incomplete'

with tarfile.open(D / 'capture-bbbcc630-02.tar.xz', 'r:xz') as tf:
    members = tf.getmembers()
    files = {}
    seen = set()
    total = 0
    for member in members:
        p = PurePosixPath(member.name)
        assert member.name and not p.is_absolute() and '..' not in p.parts and '\\' not in member.name
        assert member.name not in seen and (member.isfile() or member.isdir())
        assert member.size <= 8 * 1024 * 1024
        total += member.size
        assert total <= 64 * 1024 * 1024
        seen.add(member.name)
        if member.isfile():
            files[member.name] = tf.extractfile(member).read()
    manifest = json.loads(files['MEMBER_MANIFEST.json'])
    assert set(manifest) == set(files) - {'MEMBER_MANIFEST.json'}
    for name, expected in manifest.items():
        assert meta(files[name]) == expected, name
    for name, data in files.items():
        assert data == (D / 'extracted' / name).read_bytes()

result_bytes = files['RESULT.json']
assert meta(result_bytes) == {'bytes': 34720, 'sha256': '8f50331059d7890928b93f500d7d48ae16911b495fa87b89dc6cc589b241b9d6'}
assert result_bytes == (D / 'RESULT.json').read_bytes()
final_sdk = (D / 'FINAL.original-sdk-payload.json').read_bytes()
final = body(json.loads(final_sdk))
assert final['truncated'] is False and len(final['files']) == 1
final_entry = final['files'][0]
assert final_entry['text'].encode() == result_bytes and final_entry['sha256'] == sha(result_bytes) and final_entry['size'] == len(result_bytes)
result = json.loads(result_bytes)
initial = json.loads((P / 'RESULT.json').read_bytes())
assert result['source_commit'] == S and result['source_tree'] == T and result['codex_rs_tree'] == CT
assert result['source_before'] == result['source_after'] == {'commit': S, 'tree': T, 'codex_rs_tree': CT, 'status': ''}
assert result['source_unchanged'] is True and files['source-rewrites.patch'] == b''
assert result['formatted_postimages'] == initial['formatted_postimages'] and result['adapter_source_pins'] == initial['adapter_source_pins']
for name, pin in result['formatted_postimages'].items():
    data = (P / 'extracted/source-postimages' / name).read_bytes()
    assert meta(data) == {key: pin[key] for key in ['bytes', 'sha256']}
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == pin['git_blob']
for name, pin in result['adapter_source_pins'].items():
    assert meta((P / 'extracted/source-postimages/scripts' / name).read_bytes()) == pin
assert not any(name.startswith('source-postimages/') for name in files)

source_proof = []
for name in ['production_episodic_process.rs', 'production_episodic_process_child.rs']:
    original = P / 'extracted/source-postimages/codex-rs/hepta-agentd/src' / name
    data = original.read_bytes()
    write_exact(D / 'source-proof' / name, data)
    source_proof.append({'file': 'source-proof/' + name, **meta(data), 'source_commit': S,
                         'basis': 'Byte-identical source postimage from verified first-attempt archive; its pin repeats in continuation02 original RESULT.'})
process = (D / 'source-proof/production_episodic_process.rs').read_text()
child = (D / 'source-proof/production_episodic_process_child.rs').read_text()
resolve_at = process.index('let worker = codex_utils_cargo_bin::cargo_bin("hepta-infer-worker")?;')
a_at = process.index('let a = child::observe(')
c_at = process.index('let c = child::observe(')
dispatch_at = process.index('"DISPATCH_INPUT.json"')
assert resolve_at < a_at < dispatch_at < c_at
assert 'std::fs::create_dir(root)?;' in child[child.index('pub(super) async fn observe('):]

phases = {phase['name']: phase for phase in result['phases']}
expected_phases = ['ack-controls', 'cli-control'] + [name for arm in ARMS for name in [arm + '-prepare', arm + '-capture']] + ['scoped-fix', 'final-format']
assert list(phases) == expected_phases
phase_checks = []
for name, phase in phases.items():
    receipt = json.loads(files[name + '.receipt.json'])
    assert receipt == phase['receipt']
    expected_exit = 100 if name.endswith('-capture') else 0
    assert phase['exit_code'] == receipt['exit_code'] == receipt['command_exit_code'] == receipt['returncode'] == expected_exit
    assert phase['status'] == receipt['status'] == ('failed' if expected_exit else 'passed')
    assert receipt['timed_out'] is False and receipt['output_limit_exceeded'] is False
    assert receipt['before'] == receipt['after'] and receipt['before']['dirty'] is False
    assert receipt['before']['commit'] == receipt['source_sha'] == receipt['tested_sha'] == S and receipt['before']['tree'] == T
    assert receipt['command'] == phase['command']
    log = files[receipt['log_file']]
    assert meta(log) == {'bytes': receipt['log_bytes'], 'sha256': receipt['log_sha256']}
    start = dt.datetime.fromisoformat(receipt['started_at']).timestamp()
    end = dt.datetime.fromisoformat(receipt['finished_at']).timestamp()
    assert phase['started_unix_ns'] / 1e9 <= start <= end <= phase['finished_unix_ns'] / 1e9
    phase_checks.append({'phase': name, 'exit_code': expected_exit, 'status': phase['status'],
                         'receipt': meta(files[name + '.receipt.json']), 'log': meta(log), 'source_before_after_clean': True})

controls = {
    'ack-controls': [
        'production_composition::tests::episodic_control::provider::process::child::tests::imported_ack_requires_successful_original_process_exit_and_exact_input',
        'production_composition::tests::episodic_control::provider::process::child::tests::missing_or_repeated_ack_cannot_start_c',
    ],
    'cli-control': ['context_delivery_tests::delivery_rejects_ambiguous_modes_before_authority_or_journal_open'],
}
reports = []
previous_uuid = None
for name in ['ack-controls', 'cli-control'] + [arm + '-capture' for arm in ARMS]:
    phase = phases[name]
    receipt = phase['receipt']
    is_capture = name.endswith('-capture')
    expected_names = [CASE] if is_capture else controls[name]
    data = files[name + '.junit.xml']
    root = ET.fromstring(data)
    cases = list(root.iter('testcase'))
    assert len(cases) == int(root.attrib['tests']) == len(expected_names)
    assert int(root.attrib['skipped']) == int(root.attrib['errors']) == 0
    assert int(root.attrib['failures']) == (1 if is_capture else 0)
    assert sorted(c.attrib['name'] for c in cases) == sorted(expected_names)
    uuid = root.attrib['uuid']
    log = files[receipt['log_file']].decode()
    assert uuid in log and uuid != previous_uuid
    prior_name = name + '.previous.junit.xml'
    if prior_name in files:
        assert ET.fromstring(files[prior_name]).attrib['uuid'] == previous_uuid
    start = dt.datetime.fromisoformat(receipt['started_at']).timestamp()
    end = dt.datetime.fromisoformat(receipt['finished_at']).timestamp()
    for case in cases:
        stamp = dt.datetime.fromisoformat(case.attrib['timestamp']).timestamp()
        assert start <= stamp <= end and stamp + float(case.attrib['time']) <= end
        assert not list(case.iter('error')) and not list(case.iter('skipped'))
        assert len(list(case.iter('failure'))) == (1 if is_capture else 0)
    if is_capture:
        assert receipt['observed_failed_tests'] == 1 and receipt['observed_passed_tests'] == 0
        assert 'Error: NotFound { name: "hepta-infer-worker"' in log
        assert 'Cargo/Bazel binary metadata is unavailable' in log
        assert 'JUnit does not bind exact required cases, source and execution time' == phase['collection_error']
    else:
        assert receipt['observed_passed_tests'] == len(cases) and receipt['observed_failed_tests'] == 0
        assert phase['junit']['sha256'] == sha(data) and phase['junit']['bytes'] == len(data) and phase['junit']['uuid'] == uuid
        assert phase['junit']['case_names'] == expected_names and phase['junit']['fresh_source_time_binding'] is True
    reports.append({'phase': name, 'selected_tests': len(cases), 'passed': 0 if is_capture else len(cases),
                    'failed': 1 if is_capture else 0, 'skipped': 0, 'uuid': uuid, 'junit': meta(data),
                    'case_names': expected_names, 'uuid_in_original_log': True, 'fresh_from_previous_junit': True,
                    'all_case_timestamps_and_durations_within_original_receipt': True, 'source_bound_by_original_receipt': True})
    previous_uuid = uuid

arm_checks = []
assert [arm['arm'] for arm in result['arms']] == ARMS
for arm, observation in zip(ARMS, result['arms']):
    request_id = 'mem15-bbbcc630-' + arm + '-ef0c-v1'
    native_names = sorted(name for name in files if name.startswith(arm + '/native/'))
    adapter_names = sorted(name for name in files if name.startswith(arm + '/adapter/'))
    assert native_names == [arm + '/native/INTENT.json']
    assert adapter_names == sorted([arm + '/adapter/' + name for name in ['PLAN.json', 'SERVER.json', 'STOPPED.json']])
    intent = json.loads(files[native_names[0]])
    assert intent['outer_source_sha'] == S and intent['request_id'] == request_id
    assert intent['process_mode'] == arm.replace('-', '_')
    assert intent['physical_provider_request_count'] is None
    assert intent['A_import_harness_process_exits_before_C'] is False and intent['A_exit_before_C_required'] is True
    environment = json.loads(files[arm + '/BOUND_NATIVE_ENVIRONMENT.json'])
    assert environment['HEPTA_MEM_CONTEXT_REQUEST_ID'] == request_id and environment['HEPTA_MEM_NATIVE_SOURCE_SHA'] == S
    assert environment['HEPTA_MEM_NATIVE_INTERVENTION'] == arm and environment['HEPTA_MEM_NATIVE_PHASE'] == 'capture'
    plan = json.loads(files[arm + '/adapter/PLAN.json'])
    server = json.loads(files[arm + '/adapter/SERVER.json'])
    stopped = json.loads(files[arm + '/adapter/STOPPED.json'])
    assert plan['source_pins'] == result['adapter_source_pins'] and plan['native_source_sha'] == S and plan['request_id'] == request_id
    assert plan['mode'] == 'capture' and plan['observer_authenticated'] is False
    assert server['plan'] == meta(files[arm + '/adapter/PLAN.json'])
    assert stopped['http_connections_observed'] == 0 and stopped['observer_authenticated'] is False
    listener_intent = json.loads(files[arm + '/LISTENER_INTENT.json'])
    listener_start = json.loads(files[arm + '/LISTENER_STARTED.json'])
    listener_exit = json.loads(files[arm + '/LISTENER_EXIT.json'])
    assert listener_intent['source'] == result['source_before']
    assert listener_intent['precompile_completed_at_unix_ns'] == result['precompile_completed_at_unix_ns']
    assert listener_start['pid'] == listener_exit['pid'] and listener_exit['exit_code'] == 0 and listener_exit['timed_out'] is False
    assert result['precompile_completed_at_unix_ns'] < listener_start['started_unix_ns'] <= server['started_at_unix_ns']
    assert server['started_at_unix_ns'] <= phases[arm + '-capture']['started_unix_ns'] < phases[arm + '-capture']['finished_unix_ns'] <= stopped['ended_at_unix_ns'] <= listener_exit['finished_unix_ns']
    assert observation['request_id'] == request_id and observation['status'] == 'incomplete'
    assert observation['model_generation_count'] is None and observation['physical_native_http_count'] is None
    assert '/native/RESULT.json' in observation['error']
    arm_checks.append({'arm': arm, 'request_id': request_id, 'capture_test_exit_code': 100, 'capture_test_failed': True,
                       'error': 'hepta-infer-worker binary lookup NotFound before first child::observe(A)',
                       'native_files': native_names, 'adapter_files': adapter_names,
                       'A_or_C_artifacts_present': False, 'native_started_exit_ack_artifacts_present': False,
                       'dispatch_input_or_native_result_present': False,
                       'http_attempt_or_provider_artifacts_present': False,
                       'listener_stopped_reports_connections': 0, 'listener_observer_authenticated': False,
                       'listener_exit_code': 0, 'listener_timed_out': False,
                       'listener_window_contains_capture_test': True,
                       'original_model_generation_count': None, 'original_physical_native_http_count': None,
                       'original_physical_provider_request_count': None})

assert result['status'] == 'incomplete' and result['new_controls_passed'] is True
assert result['scoped_fix_passed'] is result['format_passed'] is result['source_unchanged'] is True
assert result['binaries_before'] == result['binaries_after'] == initial['binaries_after'] and result['binary_bytes_unchanged'] is True
assert result['model_generation_count'] is None and result['physical_native_http_count'] is None
assert result['observer_authenticated'] is False and result['scored_memory_benefit_episodes'] == 0 and result['scientific_acceptance'] == 'HOLD'
token = json.loads(files['TOKEN_PREFLIGHT.json'])
assert token == result['token_preflight']
assert [entry['arm'] for entry in token['entries']] == ARMS and all(entry['status'] == 'NOT_EXECUTED_NO_MAPPED_REQUEST' for entry in token['entries'])
assert token['assets_before'] == token['assets_after'] and token['runtime_before'] == token['runtime_after'] and token['same_frozen_assets'] is True
assert files['prior-originals/RESULT.json'] == (P / 'RESULT.json').read_bytes()
assert files['prior-originals/TERMINAL.original-sdk-payload.json'] == (P / 'TERMINAL.original-sdk-payload.json').read_bytes()

terminal_sdk = (D / 'TERMINAL.original-sdk-payload.json').read_bytes()
assert meta(terminal_sdk) == {'bytes': 907, 'sha256': '82e81218baf2c954f0c1babfd7d5e5bc4805a756c87e39af524187e7d769c0e0'}
terminal = body(json.loads(terminal_sdk))
assert terminal == json.loads((D / 'TERMINAL.json').read_bytes())
assert terminal['job_id'] == '1a1cf2a93ea-2564-19b5' and terminal['state'] == 'failed' and terminal['exit_code'] == 1
assert terminal['timed_out'] is terminal['cancelled'] is False
assert terminal['output_complete'] is terminal['output_durable'] is terminal['terminal_publication_confirmed'] is True
assert terminal['log_truncated'] == {'stderr': False, 'stdout': False}
assert terminal['at_unix_ms'] * 1000000 >= result['finished_unix_ns']

verification = {
    'schema': 'hepta.mem15.continuation02-readonly-recovery.v1',
    'archive': {'file': 'capture-bbbcc630-02.tar.xz', **meta(archive), 'complete': True, 'version': chunk['version'],
                'binary_chunks': 1, 'whole_file_in_single_bounded_versioned_read': True, 'original_sdk_transport': archive_sdk_proof},
    'publication': {'file': 'CAPTURE_BBBCC630_02_PUBLICATION.json', **meta(pub_bytes), 'matches_archive': True, 'original_sdk_transport': publication_sdk_proof},
    'tar_safety': {'members': len(members), 'regular_files': len(files), 'unsafe_paths': 0, 'links': 0, 'special_files': 0, 'duplicate_paths': 0},
    'original_member_manifest': {'file': 'extracted/MEMBER_MANIFEST.json', **meta(files['MEMBER_MANIFEST.json']), 'entries': len(manifest), 'covers_all_other_files': True, 'all_hashes_verified': True},
    'original_result': {'file': 'RESULT.json', **meta(result_bytes), 'status': 'incomplete', 'original_bytes_preserved': True, 'matches_original_sdk': True},
    'original_terminal_sdk': {'file': 'TERMINAL.original-sdk-payload.json', **meta(terminal_sdk), 'basis': 'Byte-identical copy of root original authoritative-terminal SDK readback; no duplicate terminal query.'},
    'terminal': {key: terminal[key] for key in ['job_id', 'state', 'exit_code', 'timed_out', 'cancelled', 'output_complete', 'output_durable', 'terminal_publication_confirmed']},
    'source': {'commit': S, 'tree': T, 'codex_rs_tree': CT, 'before_after_clean': True, 'source_unchanged_recorded': True,
               'rewrite_patch_bytes': 0, 'recorded_postimage_pins_match_verified_first_attempt_files': 14,
               'continuation02_archive_contains_source_postimages': False,
               'basis': 'Original before/after RESULT and all phase receipts; repeated 14 postimage pins equal the first-attempt archived source files.'},
    'new_controls': {'passed': 3, 'failed': 0, 'skipped': 0, 'reports': reports[:2]},
    'capture_tests': {'executed': 4, 'passed': 0, 'failed': 4, 'reports': reports[2:],
                      'original_collection_errors_preserved': True,
                      'interpretation': 'Four genuine test failures with exit 100 and worker NotFound; not merely an absent successful JUnit.'},
    'phase_receipts': phase_checks,
    'arms': arm_checks,
    'A_C_boundary': {'source_proof': source_proof, 'worker_lookup_before_first_A_observe': True,
                     'worker_lookup_uses_error_propagating_question_mark': True,
                     'A_role_directory_creation_occurs_inside_unreached_observe': True,
                     'A_or_C_native_start_not_reached': True,
                     'basis': 'Identical worker NotFound in each original failed-test log, frozen source call order, native subtrees containing only INTENT, and listener STOPPED records with zero observed connections.',
                     'absence_scope': 'No A/C files, native STARTED/EXIT/ACK, DISPATCH_INPUT/native RESULT, HTTP/ATTEMPT/provider files in the complete archive. Tar contains only regular files, so empty-directory absence is inferred from unreached observe rather than claimed from tar directory inventory alone.',
                     'listener_processes_did_start_and_exit': True},
    'scoped_fix_passed': True, 'final_format_passed': True,
    'recorded_binaries_before': result['binaries_before'], 'recorded_binaries_after': result['binaries_after'], 'recorded_binaries_unchanged': True,
    'binary_basis': 'Original runner before/after pins; binary bytes were not downloaded.',
    'original_measurements': {'model_generation_count': None, 'physical_native_http_count': None, 'observer_authenticated': False,
                              'all_arm_model_and_http_counts_remain_null': True, 'all_native_intent_provider_counts_remain_null': True,
                              'scored_memory_benefit_episodes': 0, 'scientific_acceptance': 'HOLD',
                              'null_counts_were_not_replaced_with_zero': True},
    'token_preflight': {'all_four_entries': 'NOT_EXECUTED_NO_MAPPED_REQUEST', 'original_assets_and_runtime_pins_unchanged': True},
    'prior_failed_result_and_terminal_bytes_preserved': True,
    'recovery_actions': {'native_jobs_started': 0, 'tests_or_controls_run': 0, 'model_calls_started': 0, 'code_changes': 0, 'publication_or_pr': False},
}
write_json(D / 'VERIFICATION.json', verification)
local_files = [{'path': p.relative_to(D).as_posix(), **meta(p.read_bytes())} for p in sorted(D.rglob('*')) if p.is_file() and p.name != 'RECOVERY_MANIFEST.json']
write_json(D / 'RECOVERY_MANIFEST.json', {'schema': 'hepta.mem15.continuation02-recovery-local-manifest.v1', 'files': local_files})
print(json.dumps({'archive': {'file': 'capture-bbbcc630-02.tar.xz', **meta(archive)},
                  'members': len(members), 'manifest_entries': len(manifest), 'controls_passed': 3, 'capture_tests_failed': 4,
                  'A_or_C_native_start_not_reached': True, 'null_counts_preserved': True,
                  'report_uuids': [{'phase': r['phase'], 'uuid': r['uuid']} for r in reports],
                  'verification': meta((D / 'VERIFICATION.json').read_bytes()),
                  'recovery_manifest': meta((D / 'RECOVERY_MANIFEST.json').read_bytes()), 'local_files': len(local_files)}, indent=2))
