import base64
import datetime as dt
import hashlib
import json
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath

D = Path('/workspace/scratch/ef0c911c24f4/mem15-native-capture/continuation03-recovered')
X = D / 'extracted'
P = D.parent / 'continuation02-recovered'
I = D.parent / 'initial-recovered'
S = 'bbbcc63003a88d0396a9694222dc98dc8c0d59d6'
T = 'fe00b2618f39e942ec6b1a8af2d63ec585e5f892'
CT = 'ed240f298fa2cbb104c65054596e64e7d1e9bca8'
ARMS = ['attach', 'reader-off', 'withhold', 'tombstone']
READS = [4, 0, 4, 3]
CASE = 'production_composition::tests::episodic_control::provider::process::episodic_native_a_exit_capture'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def meta(b):
    return {'bytes': len(b), 'sha256': sha(b)}

def b(name):
    return (X / name).read_bytes()

def j(name):
    return json.loads(b(name))

def sdk_body(obj):
    return obj.get('structuredContent') or json.loads(next(c['text'] for c in obj['content'] if c['type'] == 'text'))

archive = (D / 'capture-bbbcc630-03.tar.xz').read_bytes()
assert meta(archive) == {'bytes': 83100, 'sha256': '147bd82bd791c0df8376fc14678a892313de3403884b54be2c176f112917beac'}
chunk_checks = []
joined = b''
version = None
for offset in [0, 65536]:
    folder = D / 'transport' / ('archive-' + str(offset).zfill(6))
    readback = json.loads((folder / 'READBACK.json').read_bytes())
    response = readback['response']
    assert not response.get('isError', False)
    payload = sdk_body(response)
    chunk = base64.b64decode(payload['data_base64'], validate=True)
    assert chunk == (folder / 'original-chunk.bin').read_bytes()
    assert sha(chunk) == payload['chunk_sha256'] and payload['offset'] == offset == len(joined)
    assert payload['next_offset'] == offset + len(chunk) and payload['size'] == len(archive)
    if version is None:
        version = payload['version']
    else:
        assert readback['request']['expected_version'] == version == payload['version']
    assert json.loads((folder / 'original-sdk-response.json').read_bytes()) == response
    chunk_checks.append({'offset': offset, **meta(chunk), 'version': payload['version'], 'eof': payload['eof'],
                         'original_sdk_response': meta((folder / 'original-sdk-response.json').read_bytes())})
    joined += chunk
assert joined == archive and payload['eof'] is True

with tarfile.open(D / 'capture-bbbcc630-03.tar.xz', 'r:xz') as tf:
    members = tf.getmembers()
    names = set()
    files = {}
    total = 0
    for member in members:
        path = PurePosixPath(member.name)
        assert member.name and not path.is_absolute() and '..' not in path.parts and '\\' not in member.name
        assert member.name not in names and (member.isfile() or member.isdir()) and member.size <= 16 * 1024 * 1024
        total += member.size
        assert total <= 128 * 1024 * 1024
        names.add(member.name)
        if member.isfile():
            files[member.name] = tf.extractfile(member).read()
    manifest = json.loads(files['MEMBER_MANIFEST.json'])
    assert set(manifest) == set(files) - {'MEMBER_MANIFEST.json'}
    for name, pin in manifest.items():
        assert meta(files[name]) == pin and files[name] == b(name), name

result = j('RESULT.json')
assert b('RESULT.json') == (D / 'RESULT.json').read_bytes()
assert meta(b('RESULT.json')) == {'bytes': 47948, 'sha256': 'e67f4e4220995704db06f27d86743021e4fa4308b6daf4cb6b150312fcffa6ca'}
pub = json.loads((D / 'CAPTURE_BBBCC630_03_PUBLICATION.json').read_bytes())
assert pub['bytes'] == len(archive) and pub['sha256'] == sha(archive) and pub['status'] == result['status'] == 'capture_controls_passed'
for kind, local in [('RESULT', 'RESULT.json'), ('PUBLICATION', 'CAPTURE_BBBCC630_03_PUBLICATION.json')]:
    response = json.loads((D / (kind + '.original-sdk-response.json')).read_bytes())
    body = sdk_body(response)
    assert body['truncated'] is False and len(body['files']) == 1
    item = body['files'][0]
    raw = item['text'].encode()
    assert item['eof'] is True and meta(raw) == {'bytes': item['size'], 'sha256': item['sha256']} and raw == (D / local).read_bytes()

expected_source = {'commit': S, 'tree': T, 'codex_rs_tree': CT, 'status': ''}
assert result['source_before'] == result['source_after'] == expected_source
assert result['source_commit'] == S and result['source_tree'] == T and result['codex_rs_tree'] == CT
assert result['source_unchanged'] is True and b('source-rewrites.patch') == b''
previous = json.loads((P / 'RESULT.json').read_bytes())
assert result['formatted_postimages'] == previous['formatted_postimages'] and result['adapter_source_pins'] == previous['adapter_source_pins']
assert result['binaries_before'] == result['binaries_after'] == previous['binaries_after'] and result['binary_bytes_unchanged'] is True
for path, pin in result['formatted_postimages'].items():
    data = (I / 'extracted/source-postimages' / path).read_bytes()
    assert meta(data) == {k: pin[k] for k in ['bytes', 'sha256']}
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == pin['git_blob']
for path, pin in result['adapter_source_pins'].items():
    assert meta((I / 'extracted/source-postimages/scripts' / path).read_bytes()) == pin
assert b('prior-originals/RESULT.json') == (P / 'RESULT.json').read_bytes()
assert b('prior-originals/TERMINAL.original-sdk-payload.json') == (P / 'TERMINAL.original-sdk-payload.json').read_bytes()
assert result['controls_executed_here'] == 0 and result['precompile_and_controls_reused_from_unchanged_source'] is True
assert result['new_controls_passed'] is True
for control in ['ack-controls', 'cli-control']:
    for suffix in ['.junit.xml', '.receipt.json']:
        assert b('prior-originals/' + control + suffix) == (P / 'extracted' / (control + suffix)).read_bytes()
    rec = j('prior-originals/' + control + '.receipt.json')
    assert b('prior-originals/' + rec['log_file']) == (P / 'extracted' / rec['log_file']).read_bytes()

phases = {phase['name']: phase for phase in result['phases']}
assert len(phases) == 14 and 'ack-controls' not in phases and 'cli-control' not in phases and 'native-binaries' not in phases
phase_checks = []
for name, phase in phases.items():
    receipt = j(name + '.receipt.json')
    assert receipt == phase['receipt'] and receipt['command'] == phase['command']
    assert phase['status'] == receipt['status'] == 'passed'
    assert phase['exit_code'] == receipt['command_exit_code'] == receipt['exit_code'] == receipt['returncode'] == 0
    assert receipt['timed_out'] is False and receipt['output_limit_exceeded'] is False
    assert receipt['before'] == receipt['after'] and receipt['before']['dirty'] is False
    assert receipt['before']['commit'] == receipt['source_sha'] == receipt['tested_sha'] == S and receipt['before']['tree'] == T
    assert meta(b(receipt['log_file'])) == {'bytes': receipt['log_bytes'], 'sha256': receipt['log_sha256']}
    start = dt.datetime.fromisoformat(receipt['started_at']).timestamp()
    end = dt.datetime.fromisoformat(receipt['finished_at']).timestamp()
    assert phase['started_unix_ns'] / 1e9 <= start <= end <= phase['finished_unix_ns'] / 1e9
    phase_checks.append({'phase': name, 'exit_code': 0, 'receipt': meta(b(name + '.receipt.json')), 'log': meta(b(receipt['log_file'])), 'clean_source_binding': True})

junit_checks = []
previous_uuid = None
for arm in ARMS:
    name = arm + '-capture'
    phase = phases[name]
    receipt = phase['receipt']
    data = b(name + '.junit.xml')
    report = ET.fromstring(data)
    cases = list(report.iter('testcase'))
    assert int(report.attrib['tests']) == 1 and len(cases) == 1 and cases[0].attrib['name'] == CASE
    assert all(int(report.attrib[key]) == 0 for key in ['failures', 'errors', 'skipped'])
    assert not any(list(cases[0].iter(tag)) for tag in ['failure', 'error', 'skipped'])
    uuid = report.attrib['uuid']
    assert uuid in b(receipt['log_file']).decode() and phase['junit']['uuid'] == uuid
    assert phase['junit']['bytes'] == len(data) and phase['junit']['sha256'] == sha(data)
    assert phase['junit']['case_names'] == [CASE] and phase['junit']['fresh_source_time_binding'] is True
    old_uuid = ET.fromstring(b(name + '.previous.junit.xml')).attrib['uuid']
    assert old_uuid != uuid
    if previous_uuid is not None:
        assert old_uuid == previous_uuid
    else:
        assert old_uuid == ET.fromstring((P / 'extracted/tombstone-capture.junit.xml').read_bytes()).attrib['uuid']
    start = dt.datetime.fromisoformat(receipt['started_at']).timestamp()
    end = dt.datetime.fromisoformat(receipt['finished_at']).timestamp()
    stamp = dt.datetime.fromisoformat(cases[0].attrib['timestamp']).timestamp()
    assert start <= stamp <= end and stamp + float(cases[0].attrib['time']) <= end
    assert receipt['observed_passed_tests'] == 1 and receipt['observed_failed_tests'] == 0
    junit_checks.append({'arm': arm, 'uuid': uuid, 'previous_uuid': old_uuid, 'junit': meta(data), 'passed': 1, 'failed': 0, 'skipped': 0,
                         'uuid_in_original_log': True, 'case_time_and_duration_within_original_receipt': True, 'source_bound_by_receipt': True})
    previous_uuid = uuid

arm_checks = []
parsed_bodies = {}
for index, arm in enumerate(ARMS):
    joined = j(arm + '/JOINED.json')
    assert joined == result['arms'][index] and joined['arm'] == arm and joined['status'] == 'joined'
    request_id = 'mem15-bbbcc630-' + arm + '-ef0c-v1'
    assert joined['request_id'] == request_id
    native = j(arm + '/native/RESULT.json')
    assert meta(b(arm + '/native/RESULT.json')) == joined['native_result']
    assert meta(b(arm + '/native/C.journal')) == joined['native_journal']
    delta = native['source_reads_after'] - native['source_reads_before']
    assert delta == READS[index] == joined['source_read_delta']
    assert native['physical_provider_request_count'] is None and native['model_generation_count'] is None
    assert native['production_authenticated'] is False and native['scientific_acceptance'] == 'HOLD'
    assert joined['C_namespace_isolated'] is False and joined['full_memory_off_demonstrated'] is False
    assert joined['model_generation_count'] == 0
    plan = j(arm + '/adapter/PLAN.json')
    server = j(arm + '/adapter/SERVER.json')
    stopped = j(arm + '/adapter/STOPPED.json')
    assert plan['mode'] == 'capture' and plan['native_source_sha'] == S and plan['request_id'] == request_id
    assert plan['source_pins'] == result['adapter_source_pins'] and plan['observer_authenticated'] is False
    for key, name in [('adapter_plan', 'PLAN.json'), ('adapter_server', 'SERVER.json'), ('adapter_stopped', 'STOPPED.json')]:
        assert meta(b(arm + '/adapter/' + name)) == joined[key]
    assert server['plan'] == meta(b(arm + '/adapter/PLAN.json'))
    assert stopped['observer_authenticated'] is False
    li, ls, le = [j(arm + '/' + name) for name in ['LISTENER_INTENT.json', 'LISTENER_STARTED.json', 'LISTENER_EXIT.json']]
    assert li['source'] == expected_source and li['listener_seconds'] == 120
    assert ls['pid'] == le['pid'] and le['exit_code'] == 0 and le['timed_out'] is False
    assert ls['started_unix_ns'] <= server['started_at_unix_ns'] <= phases[arm + '-capture']['started_unix_ns']
    assert stopped['ended_at_unix_ns'] <= le['finished_unix_ns']
    c_exit = j(arm + '/native/C/EXIT.json')
    assert c_exit['exited_at_unix_ns'] <= le['finished_unix_ns']
    common = {'arm': arm, 'request_id': request_id, 'source_reads_before': native['source_reads_before'], 'source_reads_after': native['source_reads_after'],
              'source_read_delta': delta, 'nonce': joined['fixture_nonce'], 'native_result': joined['native_result'],
              'original_native_model_and_provider_counts_remain_null': True, 'listener_started': ls, 'listener_exit': le,
              'listener_window_seconds': (stopped['ended_at_unix_ns'] - server['started_at_unix_ns']) / 1e9,
              'observer_authenticated': False, 'C_namespace_isolated': False}
    if arm == 'tombstone':
        assert native['native_revocation_rejected'] is True and stopped['http_connections_observed'] == joined['physical_native_http_count'] == 0
        assert sorted(name for name in files if name.startswith(arm + '/adapter/')) == [arm + '/adapter/PLAN.json', arm + '/adapter/SERVER.json', arm + '/adapter/STOPPED.json']
        assert common['listener_window_seconds'] >= 120
        assert phases[arm + '-capture']['finished_unix_ns'] <= stopped['ended_at_unix_ns']
        assert joined['nonce_in_http_body'] is None and 'provider_request' not in joined
        common.update({'physical_native_http_count': 0, 'capture_side_model_generation_count': 0,
                       'zero_http_basis': 'Full >=120-second listener window, native revocation rejection, no ATTEMPT/http/provider-request artifacts; process review checks AbortBeforeEffect journal.',
                       'native_revocation_rejected': True, 'nonce_in_http_body': None})
    else:
        prefix = arm + '/adapter/http-0001/'
        assert sorted({name.split('/')[2] for name in files if name.startswith(arm + '/adapter/http-')}) == ['http-0001']
        request, raw_body, mapped, response = [b(prefix + name) for name in ['request.http.bin', 'body.bin', 'provider-request.bin', 'response.http.bin']]
        observed, mapping, attempt = j(prefix + 'OBSERVED.json'), j(prefix + 'MAPPING.json'), j(arm + '/adapter/ATTEMPT.json')
        for record in [observed, mapping, attempt]:
            assert record['native_body'] == meta(raw_body)
        assert observed['native_http'] == attempt['native_http'] == meta(request)
        assert observed['response_http'] == meta(response)
        assert mapping['provider_request'] == attempt['provider_request'] == meta(mapped) == joined['provider_request']
        assert joined['native_body'] == meta(raw_body)
        head, body_raw = request.split(b'\r\n\r\n', 1)
        assert body_raw == raw_body and head.split(b'\r\n')[0] == b'POST /v1/responses HTTP/1.1'
        headers = [line.split(b':', 1) for line in head.split(b'\r\n')[1:]]
        lengths = [int(value.strip()) for key, value in headers if key.lower() == b'content-length']
        assert lengths == [len(raw_body)]
        assert not any(key.lower() == b'transfer-encoding' for key, _ in headers)
        assert observed['advertised_body_bytes'] == observed['observed_body_bytes'] == len(raw_body)
        parsed = json.loads(raw_body)
        provider = json.loads(mapped)
        assert provider['input'].encode() == raw_body
        assert sorted(parsed) == mapping['included_fields'] == joined['body_fields'] and mapping['discarded_fields'] == []
        assert mapping['source_utf8_equals_destination_utf8'] is True and mapping['native_role_semantics_preserved'] is False
        assert mapping['mapping'] == plan['mapping'] == 'exact-utf8-responses-json-in-single-user-message.v1'
        assert mapping['input_bytes'] == len(raw_body) and mapping['provider_request_bytes'] == len(mapped)
        assert provider['max_output_tokens'] == plan['max_output_tokens'] == 32 and provider['temperature'] == 0 and provider['store'] is False
        assert provider['model'] == parsed['model'] == plan['profile']['model_name']
        assert attempt['mode'] == 'capture' and attempt['request_id'] == request_id and attempt['http_directory'] == 'http-0001'
        assert observed['status'] == 'CAPTURED_WITHOUT_GENERATION' and observed['physical_model_calls'] == 0
        assert observed['capture_complete'] is True and observed['socket_write_succeeded'] is True and observed['observer_authenticated'] is False
        assert observed['scientific_acceptance'] == 'HOLD'
        reply_head, reply_body = response.split(b'\r\n\r\n', 1)
        assert reply_head.split(b'\r\n')[0].startswith(b'HTTP/1.1 409 ')
        assert json.loads(reply_body) == {'error': 'capture-only; no model request issued'}
        assert server['started_at_unix_ns'] <= observed['started_at_unix_ns'] <= observed['ended_at_unix_ns'] <= stopped['ended_at_unix_ns']
        assert c_exit['started_at_unix_ns'] <= observed['started_at_unix_ns'] < observed['ended_at_unix_ns'] <= c_exit['exited_at_unix_ns']
        assert stopped['http_connections_observed'] == joined['physical_native_http_count'] == 1
        nonce_present = joined['fixture_nonce'].encode() in raw_body
        assert nonce_present == joined['nonce_in_http_body'] == (arm == 'attach')
        assert native['native_revocation_rejected'] is False
        common.update({'physical_native_http_count': 1, 'capture_side_model_generation_count': observed['physical_model_calls'],
                       'model_zero_basis': 'Original OBSERVED.json CAPTURED_WITHOUT_GENERATION with physical_model_calls=0, capture ATTEMPT/PLAN, and retained 409 response.',
                       'nonce_in_http_body': nonce_present, 'native_http': meta(request), 'native_body': meta(raw_body), 'mapped_request': meta(mapped),
                       'capture_response': meta(response), 'mapping_exact_utf8': True, 'discarded_fields': [],
                       'native_role_semantics_preserved': False, 'body_fields': sorted(parsed), 'observed': meta(b(prefix + 'OBSERVED.json'))})
        parsed_bodies[arm] = parsed
    arm_checks.append(common)

left = b('reader-off/adapter/http-0001/body.bin')
right = b('withhold/adapter/http-0001/body.bin')
differing = sorted(k for k in set(parsed_bodies['reader-off']) | set(parsed_bodies['withhold']) if parsed_bodies['reader-off'].get(k) != parsed_bodies['withhold'].get(k))
assert left != right and parsed_bodies['reader-off'] != parsed_bodies['withhold']
assert differing == ['client_metadata', 'input', 'prompt_cache_key'] == result['reader_off_vs_withhold']['differing_top_level_fields']
assert result['reader_off_vs_withhold']['left'] == meta(left) and result['reader_off_vs_withhold']['right'] == meta(right)
assert result['reader_off_vs_withhold']['no_normalization_or_dynamic_field_removal'] is True

preflight = j('TOKEN_PREFLIGHT.json')
assert preflight == result['token_preflight'] and preflight['same_frozen_assets'] is True
assert preflight['assets_before'] == preflight['assets_after'] and preflight['runtime_before'] == preflight['runtime_after']
token_script = b('token_only.py')
assert b'AutoTokenizer.from_pretrained' in token_script and b'trust_remote_code=False' in token_script
assert b'.generate(' not in token_script and b'AutoModel' not in token_script
token_checks = []
for entry, arm, expected_count in zip(preflight['entries'][:3], ARMS[:3], [7565, 7007, 7029]):
    token_bytes = b(arm + '/TOKEN_ONLY.json')
    token = json.loads(token_bytes)
    mapped_bytes = b(arm + '/adapter/http-0001/provider-request.bin')
    mapped = json.loads(mapped_bytes)
    assert entry['arm'] == arm and entry['original_output'] == meta(token_bytes) and entry['request'] == meta(mapped_bytes)
    assert entry['worker'] == meta(token_script) and entry['execution_passed'] is True
    assert token['request_sha256'] == sha(mapped_bytes)
    assert token['prompt_tokens'] == entry['prompt_tokens'] == expected_count and token['input_limit'] == entry['input_limit'] == 1024
    assert token['budget_admitted'] is entry['budget_admitted'] is False
    assert token['status'] == entry['status'] == 'REJECTED_INPUT_TOKEN_BUDGET'
    assert token['model_generation_count'] == entry['model_generation_count'] == 0
    assert token['model_weights_loaded'] is token['namespace_isolated'] is token['truncation'] is False
    for tensor_name, tensor in token['tensors'].items():
        assert tensor['dtype'] == 'torch.int64' and tensor['shape'] == [1, expected_count]
        assert len(tensor['values']) == 1 and len(tensor['values'][0]) == expected_count
        if tensor_name == 'attention_mask':
            assert set(tensor['values'][0]) == {1}
    prompt = token['rendered_prompt']
    user_marker = '<|im_start|>user\n'
    ending = '<|im_end|>\n<|im_start|>assistant\n'
    assert prompt[prompt.index(user_marker) + len(user_marker):prompt.rindex(ending)] == mapped['input']
    token_checks.append({'arm': arm, 'original_output': meta(token_bytes), 'request': meta(mapped_bytes), 'worker_script': meta(token_script),
                         'prompt_tokens': expected_count, 'input_limit': 1024, 'status': token['status'], 'budget_admitted': False,
                         'retained_tensor_lengths_match_count': True, 'rendered_user_content_matches_original_mapped_input': True,
                         'truncation': False, 'model_weights_loaded': False, 'model_generation_count': 0,
                         'interpretation': 'Post-capture tokenizer-only preflight; not generation-entry evidence and not a budget pass.'})
assert preflight['entries'][3] == {'arm': 'tombstone', 'status': 'NOT_EXECUTED_NO_MAPPED_REQUEST'}
assert 'tombstone/TOKEN_ONLY.json' not in files
assert result['model_generation_count'] == 0 and result['physical_native_http_count'] == sum(a['physical_native_http_count'] for a in arm_checks) == 3
assert result['observer_authenticated'] is False and result['scored_memory_benefit_episodes'] == 0 and result['scientific_acceptance'] == 'HOLD'
assert result['format_passed'] is result['scoped_fix_passed'] is True

proof = {
    'schema': 'hepta.mem15.continuation03-artifact-verification.v1',
    'archive': {'file': 'capture-bbbcc630-03.tar.xz', **meta(archive), 'version': version, 'complete': True, 'chunks': chunk_checks},
    'sdk_basis': 'Complete direct h responses retained as returned and serialized locally; all decoded remote file and chunk bytes verified against returned and published hashes.',
    'tar_safety': {'members': len(members), 'regular_files': len(files), 'unsafe_paths': 0, 'links': 0, 'special_files': 0, 'duplicates': 0},
    'original_member_manifest': {'file': 'extracted/MEMBER_MANIFEST.json', **meta(b('MEMBER_MANIFEST.json')), 'entries': len(manifest), 'covers_all_other_regular_files': True, 'all_hashes_verified': True},
    'result': {'file': 'RESULT.json', **meta(b('RESULT.json')), 'status': result['status'], 'original_bytes_unchanged': True},
    'authoritative_job_id': None, 'authoritative_terminal': 'UNKNOWN_PENDING_SEPARATE_IDENTITY_AND_TERMINAL_READBACK',
    'source': {'commit': S, 'tree': T, 'codex_rs_tree': CT, 'before_after_clean': True, 'source_unchanged_recorded': True, 'rewrite_patch_bytes': 0,
               'recorded_postimage_pins_match_prior_verified_source_files': 14, 'postimage_bytes_not_repeated_in_this_archive': True},
    'recorded_binaries_unchanged': True, 'binary_basis': 'Original before/after pins, unchanged from prior attempt; binary files themselves were not downloaded.',
    'controls': {'reused_prior_passed': 3, 'executed_here': 0, 'prior_result_terminal_junit_receipt_log_bytes_verified': True},
    'capture_junit': junit_checks, 'capture_tests_passed': 4, 'phase_receipts': phase_checks,
    'arms': arm_checks,
    'reader_off_vs_withhold': {'left': meta(left), 'right': meta(right), 'raw_body_equal': False, 'parsed_json_equal': False,
                               'differing_top_level_fields': differing, 'normalization_or_dynamic_field_removal': False},
    'token_only_preflight': {'entries': token_checks, 'tombstone': 'NOT_EXECUTED_NO_MAPPED_REQUEST', 'all_three_budget_rejected': True,
                            'original_complete_outputs_and_tensors_preserved': True, 'assets_and_runtime_recorded_pins_unchanged': True,
                            'tokenizer_was_not_rerun_by_recovery': True},
    'model_zero_basis': 'Capture OBSERVED records and diagnostic 409 responses for three HTTP arms; full tombstone listener window plus native rejection for zero-HTTP arm. Token-only outputs are not used as generation-entry proof.',
    'original_native_null_counts_preserved': True,
    'physical_native_http_count': 3, 'capture_side_model_generation_count': 0, 'scored_memory_benefit_episodes': 0,
    'observer_authenticated': False, 'C_namespace_isolated': False, 'full_memory_off_demonstrated': False, 'scientific_acceptance': 'HOLD',
    'scoped_fix_passed': True, 'final_format_passed': True,
    'recovery_actions': {'native_jobs_started': 0, 'reconcile_sent': 0, 'tests_or_controls_run': 0, 'tokenizer_runs': 0, 'model_calls_started': 0, 'code_changes': 0, 'git_publication': False},
}
(D / 'ARTIFACT_VERIFICATION.json').write_text(json.dumps(proof, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'archive': meta(archive), 'members': len(members), 'manifest_entries': len(manifest),
                  'capture_tests_passed': 4, 'http_counts': [a['physical_native_http_count'] for a in arm_checks], 'source_read_deltas': READS,
                  'nonce_in_http_body': [a['nonce_in_http_body'] for a in arm_checks],
                  'tombstone_window_seconds': arm_checks[-1]['listener_window_seconds'],
                  'tokens': [e['prompt_tokens'] for e in token_checks], 'all_budgets_rejected': True,
                  'reader_vs_withhold_differing_fields': differing, 'artifact_verification': meta((D / 'ARTIFACT_VERIFICATION.json').read_bytes())}, indent=2))
