import hashlib
import io
import json
import tarfile
from pathlib import Path

D = Path('/workspace/scratch/ef0c911c24f4/mem15-native-capture/continuation03-recovered')
B = D.parent

def meta(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

artifact = json.loads((D / 'ARTIFACT_VERIFICATION.json').read_bytes())
process = json.loads((D / 'INDEPENDENT_PROCESS_REVIEW.json').read_bytes())
assert process['status'] == 'VERIFIED_CONSISTENT' and process['failures'] == [] and len(process['checks']) == 447
assert process['original_result'] == {k: artifact['result'][k] for k in ['bytes', 'sha256']}
assert process['source_commit'] == artifact['source']['commit'] and process['source_tree'] == artifact['source']['tree']
assert process['remote_calls'] == process['new_model_calls'] == 0 and process['originals_modified'] is False

arms = []
for a, p in zip(artifact['arms'], process['arms']):
    assert a['arm'] == p['arm'] and a['request_id'] == p['request_id'] and a['source_read_delta'] == p['source_read_delta']
    assert p['A_exit_code'] == 0 and p['C_exit_code'] == 1 and p['A_exit_ns'] < p['C_start_ns']
    arms.append({
        'arm': a['arm'], 'request_id': a['request_id'], 'A_pid': p['A_pid'], 'C_pid': p['C_pid'],
        'A_exit_code': 0, 'C_exit_code': 1, 'A_exit_precedes_C_start': True, 'gap_seconds': p['gap_seconds'],
        'source_read_delta': a['source_read_delta'], 'physical_native_http_count': a['physical_native_http_count'],
        'nonce_in_http_body': a['nonce_in_http_body'], 'capture_side_model_generation_count': 0,
        'process_outcome': p['outcome'], 'native_revocation_rejected': a['arm'] == 'tombstone',
        'listener_window_seconds': a['listener_window_seconds'], 'C_namespace_isolated': False,
        'original_native_model_and_provider_counts_remain_null': True,
    })

pins = {}
for name in ['capture-bbbcc630-03.tar.xz', 'RESULT.json', 'CAPTURE_BBBCC630_03_PUBLICATION.json',
             'RESULT.original-sdk-response.json', 'PUBLICATION.original-sdk-response.json',
             'ARTIFACT_VERIFICATION.json', 'INDEPENDENT_PROCESS_REVIEW.json', 'extracted/MEMBER_MANIFEST.json']:
    pins[name] = meta((D / name).read_bytes())

verification = {
    'schema': 'hepta.mem15.continuation03-combined-readonly-verification.v1',
    'artifact_verification': 'VERIFIED_CONSISTENT',
    'independent_process_review': {'status': 'VERIFIED_CONSISTENT', 'checks': 447, 'failures': 0,
                                  'file': 'INDEPENDENT_PROCESS_REVIEW.json', **pins['INDEPENDENT_PROCESS_REVIEW.json']},
    'artifact_review': {'file': 'ARTIFACT_VERIFICATION.json', **pins['ARTIFACT_VERIFICATION.json']},
    'original_file_pins': pins,
    'archive': {'complete': True, 'version': artifact['archive']['version'], 'binary_chunks': 2,
                'safe_regular_files': 244, 'original_manifest_entries': 243, 'all_hashes_verified': True},
    'authoritative_job_id': None,
    'authoritative_terminal': 'UNKNOWN_PENDING_SEPARATE_IDENTITY_AND_TERMINAL_READBACK',
    'file_and_archive_success_does_not_establish_outer_terminal': True,
    'source': artifact['source'],
    'controls': artifact['controls'], 'new_capture_tests_passed': 4, 'new_capture_tests_failed': 0,
    'junit': artifact['capture_junit'],
    'arms': arms,
    'C_exit_interpretation': 'All four C processes exited 1. Three received the intentional capture-only 409 response; tombstone retained native AbortBeforeEffect/canonical-head-changed. The capture Rust cases passed because those are the expected capture and revocation outcomes. No successful inference is claimed.',
    'http_and_model': {'native_http_requests': 3, 'capture_side_model_generation_count': 0,
                       'zero_model_basis': artifact['model_zero_basis'], 'original_native_null_counts_preserved': True,
                       'exact_body_to_mapped_input_utf8': True, 'discarded_fields': [], 'native_role_semantics_preserved': False},
    'reader_off_vs_withhold': artifact['reader_off_vs_withhold'],
    'token_only_preflight': artifact['token_only_preflight'],
    'scoped_fix_passed': True, 'final_format_passed': True, 'recorded_binaries_unchanged': True,
    'observer_authenticated': False, 'C_namespace_isolated': False, 'full_memory_off_demonstrated': False,
    'scored_memory_benefit_episodes': 0, 'scientific_acceptance': 'HOLD',
    'limitations': process['limitations'],
    'recovery_actions': artifact['recovery_actions'],
}
write_json(D / 'VERIFY.json', verification)

evidence = {
    'schema': 'hepta.mem15.native-capture-recovered-evidence.v1',
    'status': 'capture_fixture_artifacts_verified; outer_job_terminal_unknown',
    'original_result_status': 'capture_controls_passed',
    'authoritative_outer_job_id': None, 'authoritative_outer_terminal': 'UNKNOWN_PENDING_SEPARATE_READBACK',
    'source': artifact['source'],
    'archive': {'file': 'capture-bbbcc630-03.tar.xz', **pins['capture-bbbcc630-03.tar.xz'],
                'complete': True, 'original_member_manifest': pins['extracted/MEMBER_MANIFEST.json'],
                'regular_files': 244, 'original_manifest_entries': 243, 'all_manifest_hashes_verified': True},
    'original_result': {'file': 'RESULT.json', **pins['RESULT.json']},
    'publication': {'file': 'CAPTURE_BBBCC630_03_PUBLICATION.json', **pins['CAPTURE_BBBCC630_03_PUBLICATION.json']},
    'controls': artifact['controls'], 'capture_junit': {'passed': 4, 'failed': 0, 'skipped': 0, 'each_uuid_source_and_receipt_window_verified': True},
    'arms': arms,
    'C_exit_interpretation': verification['C_exit_interpretation'],
    'source_read_deltas': [4, 0, 4, 3], 'native_http_counts': [1, 1, 1, 0],
    'capture_side_model_generation_count': 0, 'model_zero_basis': artifact['model_zero_basis'],
    'original_native_model_and_provider_counts_remain_null': True,
    'mapping': {'exact_native_body_utf8_preserved_in_mapped_request_input': True,
                'discarded_fields': [], 'native_role_semantics_preserved': False,
                'constructed_mapped_request_is_not_a_model_generation_request_that_was_sent': True},
    'reader_off_vs_withhold': artifact['reader_off_vs_withhold'],
    'token_only_preflight': {'scope': 'Post-capture tokenizer-only preflight, not generation-entry validation.',
                            'arms': [entry['arm'] for entry in artifact['token_only_preflight']['entries']],
                            'prompt_tokens': [7565, 7007, 7029], 'input_limit': 1024,
                            'statuses': ['REJECTED_INPUT_TOKEN_BUDGET'] * 3, 'budget_admitted': [False] * 3,
                            'truncation': False, 'model_weights_loaded': False, 'model_generation_count': 0,
                            'tombstone': 'NOT_EXECUTED_NO_MAPPED_REQUEST', 'complete_original_outputs_and_tensors_preserved': True},
    'scoped_fix_passed': True, 'final_format_passed': True, 'recorded_binaries_unchanged': True,
    'observer_authenticated': False, 'C_namespace_isolated': False, 'full_memory_off_demonstrated': False,
    'retention_off_implemented': False, 'unseen_source_benefit_evaluated': False,
    'scored_memory_benefit_episodes': 0, 'scientific_acceptance': 'HOLD',
    'verification_files': ['VERIFY.json', 'ARTIFACT_VERIFICATION.json', 'INDEPENDENT_PROCESS_REVIEW.json'],
    'prior_history': {'first_attempt': 'native build passed; capture precompile argument conflict; zero new controls/captures executed; failed outer terminal preserved.',
                     'continuation02': 'Three controls passed; four capture tests failed at worker metadata lookup before A/C; raw null counts and failed terminal preserved.',
                     'continuation03': 'Continued only the A/C paths proven unstarted; prior three controls/build/V8 were not repeated.'},
    'publication_task_executions': {'native_jobs': 0, 'reconcile': 0, 'tests': 0, 'models': 0, 'tokenizer': 0},
}
write_json(D / 'EVIDENCE.json', evidence)

report = '''# MEM15 native A-exit capture: recovered continuation 03

**The four capture fixtures passed their expected control outcomes. Scientific acceptance remains HOLD.** Original receipts and two independent readback checks establish separate importer A and worker C processes, exact ACK/input bindings, source-read deltas **4 / 0 / 4 / 3**, and native HTTP counts **1 / 1 / 1 / 0**. The capture observers report **0 model generations**; no memory-benefit episode was scored.

**The authoritative outer job identity and terminal are still pending a separate readback.** This package preserves the original file status `capture_controls_passed`; file or archive existence is not used to manufacture a successful outer terminal. A later terminal record can be appended without rewriting this checkpoint.

## Exact source and execution scope

The tested source is commit `bbbcc63003a88d0396a9694222dc98dc8c0d59d6`, tree `fe00b2618f39e942ec6b1a8af2d63ec585e5f892`, with `codex-rs` tree `ed240f298fa2cbb104c65054596e64e7d1e9bca8`. All original phase receipts and RESULT show clean, identical before/after source identities; the rewrite patch is empty. The repeated 14 source pins match the source files retained with the initial attempt. This archive does not repeat all those source postimages.

The three controls that passed in continuation 02 were reused with byte-identical JUnit, receipts, logs, RESULT, and terminal evidence. **Zero new control tests** ran in continuation 03. Its four capture Rust executions passed with no selected failures or skips; all four JUnit UUIDs, exact case names, original logs, and receipt time windows were checked. Scoped fix and final format passed. Recorded binary before/after pins stayed identical; executable bytes themselves were not downloaded.

## Per-arm result and the four C exit codes

| Arm | A PID / exit | C PID / exit | A-exit to C-start gap | Source reads | Native HTTP | Nonce in HTTP body |
| --- | --- | --- | ---: | ---: | ---: | --- |
| Attach | 296752 / 0 | 297201 / 1 | 8.199 s | 4 | 1 | Yes |
| Reader-off | 297684 / 0 | 297743 / 1 | 8.114 s | 0 | 1 | No |
| Withhold | 298228 / 0 | 298245 / 1 | 8.157 s | 4 | 1 | No |
| Tombstone | 298753 / 0 | 298785 / 1 | 8.133 s | 3 | 0 | No HTTP body |

**All four C processes exited 1, as expected for these capture diagnostics.** Attach, reader-off, and withhold received the retained HTTP 409 response `capture-only; no model request issued`. Their journals contain a failed observed terminal, with `observation.terminal_observed=true`. The native RESULT's top-level `terminal_observed=false` records absence of successful completion; it does not mean no failed terminal was observed. Tombstone records `Reserve → Dispatch → AbortBeforeEffect`, `canonical-head-changed`, and no `Started` or `Observe` event. Prepared Dispatch metadata is not an observed HTTP request.

For every arm, A's raw stdin, sole ACK in stdout, snapshot digest, owner fields, PID, successful OS exit, and C's later distinct PID were cross-checked against INTENT/STARTED/EXIT and journal records. C receives the same fixed 105-byte public prompt; A's snapshot is not injected into C's stdin. A is a deterministic import process, while the parent harness and owner remain alive. This is process-path fixture evidence, not evidence of model learning.

Tombstone's original SERVER-to-STOPPED interval is **120.093767174 seconds**. The complete observation window covers C and records zero connections. Its archive has no HTTP directory, ATTEMPT, or provider-request file; native revocation and journal evidence support the recorded pre-effect rejection.

## HTTP bytes, mapping, and the reader-off/withhold distinction

For the three HTTP arms, the raw request's Content-Length and exact body bytes match the observer, ATTEMPT, mapping, and manifest pins. Each constructed mapped request's `/input` is the complete original native body UTF-8, with no discarded fields. The original response is the diagnostic 409 and the original OBSERVED record says `CAPTURED_WITHOUT_GENERATION`, `physical_model_calls=0`. These capture records establish the zero-generation observation; token-only output is not used to claim a generation event.

The mapping treats the native JSON as a single user-message string; **native role semantics are not preserved**. The constructed `provider-request.bin` is retained mapping evidence, not evidence that a model generation request was sent.

Reader-off and withhold both omit the fixture nonce but are **not equal** as raw bytes or parsed JSON. Their full bodies are each 26,576 bytes and differ in exactly three top-level fields: `client_metadata`, `input`, and `prompt_cache_key`. No dynamic field was removed or normalized. Reader-off's source-read delta is 0; withhold's is 4. These observations do not establish a fully memory-free baseline.

## Token-only admission was rejected

| Arm | Retained prompt tokens | Limit | Admission |
| --- | ---: | ---: | --- |
| Attach | 7,565 | 1,024 | REJECTED_INPUT_TOKEN_BUDGET |
| Reader-off | 7,007 | 1,024 | REJECTED_INPUT_TOKEN_BUDGET |
| Withhold | 7,029 | 1,024 | REJECTED_INPUT_TOKEN_BUDGET |
| Tombstone | No mapped request | 1,024 | Not executed |

Complete TOKEN_ONLY outputs, rendered prompts, integer tensors, and the 1,376-byte tokenizer-only script are retained. Tensor lengths equal the recorded counts, and each output is hash-bound to its original mapped request. The recorded preflight used no truncation and loaded no model weights. **This was post-capture tokenizer-only preflight, not generation-entry validation; all three available inputs failed the budget.** Recovery did not rerun the tokenizer.

## Qualification boundaries and preserved history

`observer_authenticated=false`, `production_authenticated=false`, `C_namespace_isolated=false`, `full_memory_off_demonstrated=false`, and `retention_off_implemented=false` remain explicit. Separate task roots and cleared child environments do not prove complete old file/tool/chat/cache closure. The native per-arm `model_generation_count` and `physical_provider_request_count` remain **null** in their unchanged original files; joined counts are separately bound to capture observer records. Private owner receipt/database bytes are not included: the review checks their retained public digests and exact ACK bindings and makes no production authentication claim.

The initial precompile failure and continuation 02's four worker-lookup failures remain original failures. Continuation 03 resumed only paths proven not to have started A/C; it did not replay prior build/V8 or the three passed controls. Four independently generated fixture nonces are not a paired memory-benefit cohort. Real scored benefit remains **0** and acceptance remains **HOLD**.

## Original archive and verification

`capture-bbbcc630-03.tar.xz`: **83,100 bytes**, SHA256 `147bd82bd791c0df8376fc14678a892313de3403884b54be2c176f112917beac`. Both binary chunks share a fixed file version and passed individual hashes. All **244 regular files** and **243 original member-manifest entries** were checked; unsafe paths, links, special files, and duplicate names were rejected. Original RESULT is **47,948 bytes**, SHA256 `e67f4e4220995704db06f27d86743021e4fa4308b6daf4cb6b150312fcffa6ca`.

[EVIDENCE.json](EVIDENCE.json) is the compact result index. [VERIFY.json](VERIFY.json) combines the artifact check and independent **447-check / 0-failure** process review, with exact pins for the full [ARTIFACT_VERIFICATION.json](ARTIFACT_VERIFICATION.json) and [INDEPENDENT_PROCESS_REVIEW.json](INDEPENDENT_PROCESS_REVIEW.json). Complete direct SDK responses, original chunk bytes, the original archive, all extracted originals, and the source-independent validation scripts are preserved in this recovery package. No original execution file was edited and no test, native job, model, tokenizer, start, or reconcile was executed by recovery.
'''
(D / 'RESULTS.md').write_text(report)

inventory = []
for path in sorted(D.rglob('*')):
    if path.is_file() and path.name != 'RECOVERY_MANIFEST.json':
        assert not path.is_symlink()
        inventory.append({'path': path.relative_to(D).as_posix(), **meta(path.read_bytes())})
write_json(D / 'RECOVERY_MANIFEST.json', {'schema': 'hepta.mem15.continuation03-recovery-inventory.v1',
                                        'original_files_not_rewritten': True, 'files': inventory})

bundle = B / 'continuation03-recovery-complete.tar.xz'
snapshot = {path.relative_to(D).as_posix(): path.read_bytes() for path in sorted(D.rglob('*')) if path.is_file()}
with tarfile.open(bundle, 'w:xz', format=tarfile.PAX_FORMAT, preset=6) as tf:
    for name, data in snapshot.items():
        info = tarfile.TarInfo('continuation03-recovered/' + name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        tf.addfile(info, io.BytesIO(data))
with tarfile.open(bundle, 'r:xz') as tf:
    assert len(tf.getmembers()) == len(snapshot)
    for member in tf.getmembers():
        assert member.isfile()
        name = member.name.removeprefix('continuation03-recovered/')
        assert tf.extractfile(member).read() == snapshot[name]

package_manifest = {'schema': 'hepta.mem15.continuation03-recovery-package.v1', 'file': bundle.name,
                    **meta(bundle.read_bytes()), 'members': len(snapshot), 'all_packaged_bytes_verified': True,
                    'inventory': {'path': 'continuation03-recovered/RECOVERY_MANIFEST.json', **meta((D / 'RECOVERY_MANIFEST.json').read_bytes())},
                    'outer_terminal': 'UNKNOWN_PENDING_SEPARATE_READBACK; any later terminal must be appended as separate evidence',
                    'small_deliverables': {name: meta((D / name).read_bytes()) for name in ['RESULTS.md', 'EVIDENCE.json', 'VERIFY.json']}}
write_json(B / 'CONTINUATION03_RECOVERY_PACKAGE_MANIFEST.json', package_manifest)
print(json.dumps(package_manifest, indent=2))
