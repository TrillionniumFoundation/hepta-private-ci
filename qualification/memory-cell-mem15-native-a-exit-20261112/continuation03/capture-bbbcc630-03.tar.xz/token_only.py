
import hashlib,json,os,sys
from pathlib import Path
profile=json.loads(Path(sys.argv[1]).read_bytes())
sys.path.insert(0,profile["site_packages"])
import torch
from transformers import AutoTokenizer
torch.set_num_threads(2)
raw=Path(sys.argv[2]).read_bytes(); request=json.loads(raw)
tokenizer=AutoTokenizer.from_pretrained(profile["model_dir"],local_files_only=True,trust_remote_code=False)
prompt=tokenizer.apply_chat_template([{"role":"user","content":request["input"]}],tokenize=False,add_generation_prompt=True)
inputs=tokenizer(prompt,return_tensors="pt",truncation=False)
count=int(inputs["input_ids"].shape[1])
result={"schema":"hepta.mem15.token-only.v1","request_sha256":hashlib.sha256(raw).hexdigest(),
 "rendered_prompt":prompt,"tensors":{name:{"dtype":str(value.dtype),"shape":list(value.shape),"values":value.tolist()} for name,value in inputs.items()},
 "prompt_tokens":count,"input_limit":1024,"truncation":False,"budget_admitted":count<=1024,
 "status":"ADMITTED_WITHOUT_GENERATION" if count<=1024 else "REJECTED_INPUT_TOKEN_BUDGET",
 "model_weights_loaded":False,"model_generation_count":0,"namespace_isolated":False}
Path(sys.argv[3]).write_bytes(json.dumps(result,sort_keys=True,separators=(",",":"),allow_nan=False).encode()+b"\n")
print(json.dumps({key:value for key,value in result.items() if key not in ("rendered_prompt","tensors")},sort_keys=True))
