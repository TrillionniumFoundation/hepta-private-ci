"""Resume only A/C operations proved unstarted after worker metadata rejection.

Keep both failed attempts, all three passing controls, source and binaries.
Add existing underscore binary-metadata aliases through the recipe shell.
No Rust/source/timeout/policy changes and no repetition of the passing controls.
"""
import base64
import hashlib
import json
from pathlib import Path

PRIOR_TERMINAL_B64 = "eyJjb250ZW50IjpbeyJ0eXBlIjoidGV4dCIsInRleHQiOiJ7XG4gIFwiYXRfdW5peF9tc1wiOiAxNzk0NDc4MDA4MzYyLFxuICBcImF1ZGl0X3JlY29yZGVkXCI6IHRydWUsXG4gIFwiYXV0b21hdGljX3JldHJ5XCI6IGZhbHNlLFxuICBcImNhbmNlbGxlZFwiOiBmYWxzZSxcbiAgXCJleGl0X2NvZGVcIjogMSxcbiAgXCJqb2JfaWRcIjogXCIxYTFjZjJhOTNlYS0yNTY0LTE5YjVcIixcbiAgXCJsYXVuY2hfbm9uY2VcIjogXCJmN2NjOTUyMTUyYjk2MzljYzcwM2RkYjk3NTY5ZDc4ZVwiLFxuICBcImxvZ19ieXRlc1wiOiB7XG4gICAgXCJzdGRlcnJcIjoge1xuICAgICAgXCJzZWVuXCI6IDAsXG4gICAgICBcInN0b3JlZFwiOiAwXG4gICAgfSxcbiAgICBcInN0ZG91dFwiOiB7XG4gICAgICBcInNlZW5cIjogMzI3LFxuICAgICAgXCJzdG9yZWRcIjogMzI3XG4gICAgfVxuICB9LFxuICBcImxvZ19lcnJvcnNcIjoge1xuICAgIFwic3RkZXJyXCI6IG51bGwsXG4gICAgXCJzdGRvdXRcIjogbnVsbFxuICB9LFxuICBcImxvZ19zeW5jZWRcIjoge1xuICAgIFwic3RkZXJyXCI6IHRydWUsXG4gICAgXCJzdGRvdXRcIjogdHJ1ZVxuICB9LFxuICBcImxvZ190cnVuY2F0ZWRcIjoge1xuICAgIFwic3RkZXJyXCI6IGZhbHNlLFxuICAgIFwic3Rkb3V0XCI6IGZhbHNlXG4gIH0sXG4gIFwib3V0cHV0X2NvbXBsZXRlXCI6IHRydWUsXG4gIFwib3V0cHV0X2R1cmFibGVcIjogdHJ1ZSxcbiAgXCJzdGF0ZVwiOiBcImZhaWxlZFwiLFxuICBcInRlcm1pbmFsX3B1YmxpY2F0aW9uX2NvbmZpcm1lZFwiOiB0cnVlLFxuICBcInRlcm1pbmFsX3B1YmxpY2F0aW9uX3Byb3RvY29sXCI6IDEsXG4gIFwidGltZWRfb3V0XCI6IGZhbHNlXG59In1dLCJzdHJ1Y3R1cmVkQ29udGVudCI6bnVsbCwiaXNFcnJvciI6ZmFsc2V9Cg=="
PRIOR_TERMINAL_SHA = "82e81218baf2c954f0c1babfd7d5e5bc4805a756c87e39af524187e7d769c0e0"
FIRST = Path("/home/qq/work/mem15-native-qualification-20261112-ef0c/capture-bbbcc630-01")
PRIOR = FIRST.parent / "capture-bbbcc630-02"
runner = (FIRST / "submitted.py").read_bytes()
if hashlib.sha256(runner).hexdigest() != "ec700c2c9f5ad2cabb8b845e357661976e4dd370b0badb2cf5ceeb7153de1e38":
    raise RuntimeError("original reviewed definitions changed")
marker = b"\nOUT.mkdir(mode=0o700, exist_ok=False)\n"
if runner.count(marker) != 1:
    raise RuntimeError("original definition/main boundary changed")
exec(compile(runner.split(marker)[0], "<mem15-reviewed-definitions>", "exec"), globals())
OUT = ROOT / "capture-bbbcc630-03"
OUT.mkdir(mode=0o700, exist_ok=False)
RESULT["schema"] = "hepta.mem15.native-capture-metadata-continuation.v1"
RESULT["scope"] = "resume only A/C proved never started in completed metadata-failure attempt; three passed controls/build/V8 not repeated; capture-only, no model generation"

try:
    save()
    terminal_raw = base64.b64decode(PRIOR_TERMINAL_B64, validate=True)
    if pin(terminal_raw)["sha256"] != PRIOR_TERMINAL_SHA:
        raise ValueError("original terminal SDK pin differs")
    sdk = json.loads(terminal_raw)
    terminal = json.loads(next(item["text"] for item in sdk["content"] if item["type"] == "text"))
    if (sdk.get("isError") or terminal["job_id"] != "1a1cf2a93ea-2564-19b5" or terminal["state"] != "failed"
            or terminal["exit_code"] != 1 or terminal["timed_out"] or terminal["cancelled"]
            or not terminal["output_complete"] or not terminal["output_durable"]
            or not terminal["terminal_publication_confirmed"] or any(terminal["log_truncated"].values())):
        raise ValueError("original metadata-failure job lacks a complete failed terminal")
    raw = (PRIOR / "RESULT.json").read_bytes()
    if pin(raw) != {"bytes": 34720, "sha256": "8f50331059d7890928b93f500d7d48ae16911b495fa87b89dc6cc589b241b9d6"}:
        raise ValueError("original completed RESULT changed")
    prior = json.loads(raw)
    phases = {entry["name"]: entry for entry in prior["phases"]}
    expected_phases = {"ack-controls", "cli-control", "scoped-fix", "final-format"} | {
        arm["arm"] + ending for arm in ARMS for ending in ("-prepare", "-capture")}
    if (set(phases) != expected_phases or prior["status"] != "incomplete" or not prior["new_controls_passed"]
            or not prior["source_unchanged"] or not prior["binary_bytes_unchanged"]
            or prior["source_before"] != prior["source_after"] or prior["source_after"] != require_source()
            or not prior.get("finished_unix_ns") or terminal["at_unix_ms"] * 10**6 < prior["finished_unix_ns"]
            or prior["model_generation_count"] is not None or prior["physical_native_http_count"] is not None
            or [(entry["arm"], entry["request_id"], entry["status"]) for entry in prior["arms"]]
            != [(arm["arm"], arm["request_id"], "incomplete") for arm in ARMS]):
        raise ValueError("original completion does not bind the exact frozen four-arm failure")
    archive_path = ROOT / "capture-bbbcc630-02.tar.xz"
    if digest(archive_path) != {"bytes": 48456, "sha256": "f01514d24b24efc457ddda28dec880c5f292293b71ac4b534f4d5403d7b80fe4"}:
        raise ValueError("original metadata-failure archive changed")
    with tarfile.open(archive_path, "r:xz") as archive:
        if archive.extractfile("RESULT.json").read() != raw:
            raise ValueError("archived RESULT differs")
        manifest = json.load(archive.extractfile("MEMBER_MANIFEST.json"))
        v8_raw = archive.extractfile("prior-originals/v8.env").read()
    if digest(PROFILE)["sha256"] != PROFILE_SHA:
        raise ValueError("frozen provider profile changed")
    PROFILE_VALUE = document(PROFILE)
    ADAPTER_PINS = prior["adapter_source_pins"]
    if ADAPTER_PINS != {name: digest(SOURCE / "scripts" / name) for name in ADAPTER_PINS}:
        raise ValueError("adapter source changed")
    originals = OUT / "prior-originals"
    originals.mkdir()
    (originals / "TERMINAL.original-sdk-payload.json").write_bytes(terminal_raw)
    (originals / "RESULT.json").write_bytes(raw)
    (originals / "reviewed-helper-source.py").write_bytes(runner)
    (originals / "v8.env").write_bytes(v8_raw)

    def retained(relative):
        path = PRIOR / relative
        if path.is_symlink() or not path.is_file() or digest(path) != manifest[relative]:
            raise ValueError("retained original differs from complete frozen archive: " + relative)
        destination = originals / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
        return path

    # Read back the three already passed controls; never execute them again here.
    for name, names in (("ack-controls", ACK_CASES), ("cli-control", {CLI_CASE})):
        phase = phases[name]
        receipt = document(retained(name + ".receipt.json"))
        log = retained(receipt["log_file"]).read_text()
        report = ET.parse(retained(name + ".junit.xml")).getroot()
        cases = report.findall(".//testcase")
        if (phase["status"] != "passed" or phase["exit_code"] != 0 or receipt != phase["receipt"]
                or receipt["command_exit_code"] != 0 or receipt["timed_out"]
                or receipt["observed_passed_tests"] != len(names) or receipt["observed_failed_tests"] != 0
                or report.attrib["uuid"] != phase["junit"]["uuid"] or report.attrib["uuid"] not in log
                or len(cases) != len(names) or {case.attrib["name"] for case in cases} != names
                or any(case.find(tag) is not None for case in cases for tag in ("failure", "error", "skipped"))
                or not all(datetime.fromisoformat(receipt["started_at"]) <= datetime.fromisoformat(case.attrib["timestamp"]) <= datetime.fromisoformat(receipt["finished_at"]) for case in cases)
                or any(receipt[side]["commit"] != COMMIT or receipt[side]["tree"] != TREE or receipt[side]["dirty"] for side in ("before", "after"))):
            raise ValueError("original passing control no longer binds exact source/time/selection: " + name)
    boundaries = []
    for arm in ARMS:
        name = arm["arm"]
        base = PRIOR / name
        native = base / "native"
        adapter = base / "adapter"
        # Stronger than missing RESULT alone: require the exact initial directory contents,
        # complete failed test, matching source-position error and original zero-request stop.
        native_entries = sorted(path.name for path in native.iterdir())
        adapter_entries = sorted(path.name for path in adapter.iterdir())
        if native_entries != ["INTENT.json"] or adapter_entries != ["PLAN.json", "SERVER.json", "STOPPED.json"]:
            raise ValueError("an A/C or HTTP effect/unknown state exists; no reissue for " + name)
        if any((native / entry).exists() for entry in ("A", "C", "A_ACK.json", "DISPATCH_INPUT.json", "RESULT.json", "C.journal")):
            raise ValueError("an original A/C step exists; stop and recover " + name)
        intent = document(retained(name + "/native/INTENT.json"))
        plan, server, stopped, listener = (document(retained(name + suffix)) for suffix in (
            "/adapter/PLAN.json", "/adapter/SERVER.json", "/adapter/STOPPED.json", "/LISTENER_EXIT.json"))
        bound = document(retained(name + "/BOUND_NATIVE_ENVIRONMENT.json"))
        phase = phases[name + "-capture"]
        receipt = document(retained(name + "-capture.receipt.json"))
        log_raw = retained(receipt["log_file"]).read_bytes()
        report = ET.parse(retained(name + "-capture.junit.xml")).getroot()
        cases = report.findall(".//testcase")
        if (phases[name + "-prepare"]["status"] != "passed" or phase["status"] != "failed" or phase["exit_code"] != 100
                or receipt != phase["receipt"] or receipt["command_exit_code"] != 100 or receipt["timed_out"]
                or receipt["observed_passed_tests"] != 0 or receipt["observed_failed_tests"] != 1
                or pin(log_raw)["sha256"] != receipt["log_sha256"]
                or b'Error: NotFound { name: "hepta-infer-worker"' not in log_raw
                or b'fallback: "Cargo/Bazel binary metadata is unavailable"' not in log_raw
                or len(cases) != 1 or cases[0].attrib["name"] != CAPTURE_CASE or cases[0].find("failure") is None
                or any(receipt[side]["commit"] != COMMIT or receipt[side]["tree"] != TREE or receipt[side]["dirty"] for side in ("before", "after"))
                or stopped["http_connections_observed"] != 0 or listener["exit_code"] != 0 or listener["timed_out"]
                or (base / "LISTENER_INTERRUPTED.json").exists()
                or stopped["ended_at_unix_ns"] - server["started_at_unix_ns"] < 119 * 10**9
                or not server["started_at_unix_ns"] <= phase["started_unix_ns"] <= phase["finished_unix_ns"] <= stopped["ended_at_unix_ns"]
                or plan["native_source_sha"] != COMMIT or plan["request_id"] != arm["request_id"]
                or plan["mode"] != "capture" or plan["profile"] != PROFILE_VALUE or plan["source_pins"] != ADAPTER_PINS
                or server["plan"] != pin(canonical(plan))
                or intent["outer_source_sha"] != COMMIT or intent["request_id"] != arm["request_id"]
                or intent["requested_model"] != PROFILE_VALUE["model_name"]
                or intent["provider_base_url"] != f"http://127.0.0.1:{server['address'][1]}/v1"
                or "CARGO_BIN_EXE_hepta_infer_worker" in bound or "NEXTEST_BIN_EXE_hepta_infer_worker" in bound):
            raise ValueError("original metadata rejection/zero-request boundary not established for " + name)
        boundaries.append({"arm": name, "request_id": arm["request_id"], "native_entries": native_entries,
            "adapter_entries": adapter_entries, "A_C_directories_absent": True, "original_http_connections_observed": 0,
            "original_failed_harness_attempt_retained": True, "A_import_or_C_resend_authorized_if_unknown": False,
            "log": pin(log_raw), "listener_stop": digest(adapter / "STOPPED.json")})
    for name in ("scoped-fix", "final-format"):
        if phases[name]["status"] != "passed" or phases[name]["exit_code"] != 0:
            raise ValueError("original final checks did not preserve frozen source")
    RESULT["prior"] = {"job_id": terminal["job_id"], "result": pin(raw), "terminal_sdk": pin(terminal_raw),
        "archive": digest(archive_path), "failed_harness_attempts": 4, "passed_controls_repeated": False,
        "native_binaries_rebuilt": False, "original_counts_preserved_as_null": True, "arm_boundaries": boundaries}
    RESULT["source_before"] = require_source()
    BINARIES = prior["binaries_before"]
    if BINARIES != prior["binaries_after"] or set(BINARIES) != {"codex", "hepta-infer-worker"}:
        raise ValueError("original binary measurements differ")
    for name, value in BINARIES.items():
        if digest(Path(value["path"])) != value["pin"]:
            raise ValueError("original qualified binary changed: " + name)
        ENV["CARGO_BIN_EXE_" + name] = value["path"]
    worker_path = BINARIES["hepta-infer-worker"]["path"]
    ENV["CARGO_BIN_EXE_hepta_infer_worker"] = worker_path
    ENV["NEXTEST_BIN_EXE_hepta_infer_worker"] = worker_path
    RESULT["binaries_before"] = BINARIES
    RESULT["formatted_postimages"] = prior["formatted_postimages"]
    for path, expected in RESULT["formatted_postimages"].items():
        if digest(SOURCE / path) != {key: expected[key] for key in ("bytes", "sha256")}:
            raise ValueError("formatted source postimage changed")
    repair = document(OLD / "clang-resources-v1/REPAIR.json")
    deps = document(OLD / "build-dependencies/DEPENDENCIES.json")
    if repair["status"] != "prepared" or repair["system_packages_modified"] or not deps["protoc_usable"]:
        raise ValueError("original build prerequisites unavailable")
    ENV.update(repair["build_environment"], PROTOC=deps["protoc_path"], LD_LIBRARY_PATH=deps["protoc_libraries"])
    for line in v8_raw.decode().splitlines():
        key, value = line.split("=", 1)
        if key not in {"RUSTY_V8_ARCHIVE", "RUSTY_V8_SRC_BINDING_PATH"}:
            raise ValueError("unexpected original V8 export")
        ENV[key] = value
    RESULT["adapter_source_pins"] = ADAPTER_PINS
    RESULT["build_environment"] = prior["build_environment"]
    RESULT["binary_metadata_aliases"] = {key: ENV[key] for key in (
        "CARGO_BIN_EXE_hepta-infer-worker", "CARGO_BIN_EXE_hepta_infer_worker", "NEXTEST_BIN_EXE_hepta_infer_worker")}
    shutil.copyfile(PROFILE, OUT / "frozen-profile.json")
    write(OUT / "PLAN.json", {"source_commit": COMMIT, "source_tree": TREE, "codex_rs_tree": CODEX_TREE,
        "arms": ARMS, "continuation_arm_root": str(OUT), "prior_failed_arm_root": str(PRIOR),
        "original_request_ids_unchanged": True, "prior_A_C_never_started_required": True,
        "old_failed_harness_attempts_retained": 4, "only_existing_underscore_binary_metadata_added": True,
        "binary_metadata_aliases": RESULT["binary_metadata_aliases"], "binary_pin": BINARIES["hepta-infer-worker"]["pin"],
        "model_generation_authorized": False, "capture_case": CAPTURE_CASE, "maximum_A_C_attempts_per_arm": 1,
        "passed_controls_reused": sorted(ACK_CASES | {CLI_CASE}), "no_retry_if_any_original_A_C_unknown": True,
        "nextest_retries": 0, "nextest_timeout_policy_changed": False, "listener_timeout_seconds": 120,
        "max_input_tokens": 1024, "max_output_tokens": 32, "post_capture_token_only_predeclared": True})
    import __main__
    (OUT / "submitted.py").write_text(__main__.SUBMITTED_PAYLOAD)
    probe = "import os,json,pathlib,hashlib; p=" + repr(worker_path) + "; k=['CARGO_BIN_EXE_hepta-infer-worker','CARGO_BIN_EXE_hepta_infer_worker','NEXTEST_BIN_EXE_hepta_infer_worker']; v={x:os.environ.get(x) for x in k}; assert v[k[1]]==p and v[k[2]]==p; assert hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()=='3659f3d490105ae60778821602a92c138c169b323bc2864512a3d5e87ed304b5'; print(json.dumps({'scope':'actual frozen just shell metadata probe; no tests/model/A/C launched','environment':v},sort_keys=True))"
    if not command("worker-metadata-through-shell", [PYTHON, str(SOURCE / "scripts/just-shell.py"), "exec \"$@\"", "metadata-probe", PYTHON, "-c", probe], timeout=60):
        raise ValueError("worker metadata did not survive the original recipe shell")
    RESULT["new_controls_passed"] = True
    RESULT["controls_executed_here"] = 0
    RESULT["precompile_completed_at_unix_ns"] = prior["precompile_completed_at_unix_ns"]
    RESULT["precompile_and_controls_reused_from_unchanged_source"] = True
    save()
    for arm in ARMS:
        run_arm(arm)
    if all(entry["status"] == "joined" for entry in RESULT["arms"]):
        RESULT["model_generation_count"] = sum(entry["model_generation_count"] for entry in RESULT["arms"])
        RESULT["physical_native_http_count"] = sum(entry["physical_native_http_count"] for entry in RESULT["arms"])
    left, right = (OUT / arm / "adapter/http-0001/body.bin" for arm in ("reader-off", "withhold"))
    if left.is_file() and right.is_file():
        a, b = left.read_bytes(), right.read_bytes()
        ja, jb = json.loads(a), json.loads(b)
        RESULT["reader_off_vs_withhold"] = {"raw_body_equal": a == b, "parsed_json_equal": ja == jb,
            "left": pin(a), "right": pin(b), "differing_top_level_fields": sorted(key for key in set(ja) | set(jb) if ja.get(key) != jb.get(key)),
            "no_normalization_or_dynamic_field_removal": True}
    try:
        token_only()
    except BaseException as error:
        RESULT["token_preflight_error"] = type(error).__name__ + ": " + str(error)
        (OUT / "token-preflight-exception.txt").write_text(traceback.format_exc())
    RESULT["scoped_fix_passed"] = command("scoped-fix", ["just", "fix", "--locked", "-p", "codex-hepta-agentd", "-p", "codex-hepta-infer-worker-host"], final=True)
    RESULT["format_passed"] = command("final-format", ["just", "fmt", "--base", BASE], timeout=900, final=True)
    RESULT["source_after"] = identity()
    (OUT / "source-rewrites.patch").write_bytes(subprocess.check_output(["git", "-C", str(SOURCE), "diff", "--binary", "HEAD"], env=ENV))
    RESULT["source_unchanged"] = RESULT["source_before"] == RESULT["source_after"]
    RESULT["binaries_after"] = {name: {"path": value["path"], "pin": digest(Path(value["path"]))} for name, value in BINARIES.items()}
    RESULT["binary_bytes_unchanged"] = RESULT["binaries_after"] == BINARIES
    RESULT["status"] = "capture_controls_passed" if (len(RESULT["arms"]) == 4
        and all(entry["status"] == "joined" for entry in RESULT["arms"])
        and RESULT["scoped_fix_passed"] and RESULT["format_passed"] and RESULT["source_unchanged"]
        and RESULT["binary_bytes_unchanged"]) else "incomplete"
except BaseException as error:
    RESULT.update(status="incomplete", error=type(error).__name__ + ": " + str(error))
    (OUT / "exception.txt").write_text(traceback.format_exc())
finally:
    RESULT["finished_unix_ns"] = time.time_ns()
    save()
    selected = [path for path in OUT.rglob("*") if path.is_file() and not path.is_symlink()
        and not any(part in {"home", "cache", "work", "token-home", "__pycache__"} for part in path.relative_to(OUT).parts)]
    write(OUT / "MEMBER_MANIFEST.json", {str(path.relative_to(OUT)): digest(path) for path in selected})
    archive_path = ROOT / "capture-bbbcc630-03.tar.xz"
    with tarfile.open(archive_path, "x:xz") as stream:
        for path in selected + [OUT / "MEMBER_MANIFEST.json"]:
            stream.add(path, arcname=str(path.relative_to(OUT)), recursive=False)
    publication = {"archive": str(archive_path), **digest(archive_path), "result": str(OUT / "RESULT.json"), "status": RESULT["status"]}
    write(ROOT / "CAPTURE_BBBCC630_03_PUBLICATION.json", publication)
    print(json.dumps(publication, indent=2))
if RESULT["status"] != "capture_controls_passed":
    raise SystemExit(1)
