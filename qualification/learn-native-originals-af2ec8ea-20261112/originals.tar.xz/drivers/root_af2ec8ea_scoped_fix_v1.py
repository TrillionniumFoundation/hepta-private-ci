import os,sys,json,hashlib,subprocess,time,datetime,fcntl,traceback,shutil
from pathlib import Path
BASE=Path('/home/qq/hepta-learn-ff41-tools')
SOURCE=Path('/home/qq/hepta-learn-ff41-root-source-integration-v1')
REPO=Path('/home/qq/hepta-learn-ff41-native-root-279deb99-v1')
TARGET=Path('/home/qq/hepta-learn-ff41-target-f73704ac-v1')
OUT=BASE/'validation/root-af2ec8ea-scoped-fix-v1'
HEAD='af2ec8ea6d66864cef1222138f4d5e193f9bcfe3'
TREE='05e43c6b12cc5db5b93835dce4901f6e6eb4ed5b'
CMD=[str(BASE/'bin/just'),'fix','--locked','--offline','-p','codex-hepta-agentd','-p','codex-hepta-agent-protocol','-p','codex-hepta-learning-ledger','-p','codex-hepta-contracts','-p','codex-hepta-neuron','-p','codex-hepta-intelligence-eval','-p','codex-hepta-learning-artifacts']
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(repo,*args):return subprocess.check_output(['/usr/bin/git',*args],cwd=repo)
def snapshot(repo):
 h=hashlib.sha256();count=0
 for entry in git(repo,'ls-files','-s','-z').split(b'\0'):
  if not entry:continue
  meta,path=entry.split(b'\t',1);mode=meta.split()[0];p=repo/os.fsdecode(path)
  raw=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
  h.update(mode+b'\0'+path+b'\0'+hashlib.sha256(raw).digest());count+=1
 return {'head':git(repo,'rev-parse','HEAD').decode().strip(),'tree':git(repo,'rev-parse','HEAD^{tree}').decode().strip(),'status':git(repo,'status','--porcelain').decode(),'tracked_files':count,'tracked_sha256':h.hexdigest(),'hash_format':'mode NUL path NUL SHA256(content), git index order'}
OUT.mkdir(parents=True,exist_ok=False)
result={'status':'preflight','expected_head':HEAD,'expected_tree':TREE,'command':CMD,'cwd':str(REPO/'codex-rs'),'target':str(TARGET),'started':utc(),'uid':os.getuid(),'scope':'Actual seven-package scoped just fix, including test compilation; no test execution, JUnit, UID0 custody or whole-chain qualification.'}
def persist():
 temp=OUT/'result.json.tmp';temp.write_text(json.dumps(result,indent=2)+'\n');os.replace(temp,OUT/'result.json')
persist();started=time.monotonic();lock=None;child=None
try:
 assert os.getuid()==1000,'original ordinary compiler UID differs'
 assert TARGET.is_dir(),'known f737 target missing'
 lock=(TARGET/'.hepta-root-native-owner.lock').open('a+b')
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 result['target_owner_lock']='held exclusive .hepta-root-native-owner.lock'
 cargo_lock=TARGET/'debug/.cargo-lock'
 if cargo_lock.exists():
  with cargo_lock.open('rb') as probe:
   fcntl.flock(probe,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(probe,fcntl.LOCK_UN)
 result['cargo_lock_probe']='nonblocking probe released before Cargo launch'
 occupied=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   comm=(p/'comm').read_text().strip()
   if comm not in ['cargo','rustc','clippy-driver','cargo-clippy']:continue
   penv=(p/'environ').read_bytes().split(b'\0')
   current=next((x.split(b'=',1)[1].decode(errors='replace') for x in penv if x.startswith(b'CARGO_TARGET_DIR=')),'')
   cwd=os.readlink(p/'cwd')
   if current==str(TARGET) or cwd.startswith(str(REPO)):
    occupied.append({'pid':int(p.name),'name':comm,'target':current,'cwd':cwd})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 result['occupied_target_processes']=occupied;assert not occupied,'same target has live compiler'
 result['disk_free']=shutil.disk_usage(TARGET).free;assert result['disk_free']>=4*1024**3,'insufficient compiler storage'
 bundle=BASE/'root-af2ec8ea-source.bundle'
 data=bundle.read_bytes();assert len(data)==15358 and hashlib.sha256(data).hexdigest()=='78fa62c4a12fdbf6336c3aee14028c9977e48ade6f98ccae3ad9fb97428e5338','candidate bundle differs'
 assert not git(SOURCE,'status','--porcelain').strip(),'source-library has changes'
 with (OUT/'bundle-verify-import.log').open('xb') as log:
  subprocess.run(['/usr/bin/git','bundle','verify',str(bundle)],cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['/usr/bin/git','fetch',str(bundle),'HEAD:refs/remotes/original-source/candidate-af2ec8ea'],cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT,check=True)
 assert git(SOURCE,'rev-parse','refs/remotes/original-source/candidate-af2ec8ea').decode().strip()==HEAD
 result['source_library']={'path':str(SOURCE),'head':git(SOURCE,'rev-parse','HEAD').decode().strip(),'tree':git(SOURCE,'rev-parse',HEAD+'^{tree}').decode().strip(),'status':git(SOURCE,'status','--porcelain').decode()}
 assert result['source_library']['tree']==TREE,'source-library exact tree differs'
 assert REPO.is_dir(),'stable native worktree missing'
 assert git(REPO,'rev-parse','HEAD').decode().strip()=='6c56821259a9dcb29431e9c18710424b3a3bf1ed','stable worktree predecessor differs'
 assert not git(REPO,'status','--porcelain').strip(),'stable worktree has changes'
 archive=Path('/home/qq/hepta-learn-ff41-archived-source-6c568212-before-af2ec8ea-v1');assert not archive.exists()
 with (OUT/'source-import.log').open('wb') as log:
  subprocess.run(['/usr/bin/git','worktree','add','--detach',str(archive),'6c56821259a9dcb29431e9c18710424b3a3bf1ed'],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
  assert git(archive,'rev-parse','HEAD^{tree}').decode().strip()=='d2a11955f033252ecc6f5f3a08a8a2c0d3440975'
  assert not git(archive,'status','--porcelain').strip()
  subprocess.run(['/usr/bin/git','fetch',str(BASE/'root-af2ec8ea-source.bundle'),'HEAD:refs/remotes/original-source/candidate-af2ec8ea'],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
  assert git(REPO,'rev-parse','refs/remotes/original-source/candidate-af2ec8ea').decode().strip()==HEAD
  subprocess.run(['/usr/bin/git','checkout','--detach',HEAD],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
 result['stable_worktree_reuse']={'original_head':'6c56821259a9dcb29431e9c18710424b3a3bf1ed','original_archive':str(archive),'reason':'Preserve compiler source paths; original clean source and all original run evidence remain retained.'}
 before=snapshot(REPO);assert before['head']==HEAD and before['tree']==TREE and not before['status'],'candidate source identity differs'
 result['before']=before
 original=json.loads((BASE/'env.json').read_text());assert isinstance(original,dict) and all(isinstance(k,str) and isinstance(v,str) for k,v in original.items()),'unexpected original environment shape'
 env=os.environ.copy();env.update(original)
 for key in list(env):
  if key.startswith('CARGO_PROFILE_'):del env[key]
 env.update({'RUSTUP_TOOLCHAIN':'1.96.0','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(TARGET),'GIT_TERMINAL_PROMPT':'0'})
 env['PATH']=str(BASE/'bin')+':/home/qq/.cargo/bin:'+env.get('PATH','/usr/local/bin:/usr/bin:/bin')
 result['environment']={k:env.get(k) for k in ['PATH','CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_TARGET_DIR','BINDGEN_EXTRA_CLANG_ARGS','LIBCLANG_PATH','RUSTFLAGS']}
 result['profile_overrides']=[k for k in env if k.startswith('CARGO_PROFILE_')]
 result['rustc']=subprocess.check_output(['/home/qq/.cargo/bin/rustc','--version'],env=env,text=True).strip()
 assert result['rustc'].startswith('rustc 1.96.0 '),'wrong original Rust toolchain'
 result['just']=subprocess.check_output([str(BASE/'bin/just'),'--version'],env=env,text=True).strip()
 result['driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 result['status']='running';result['compile_started']=utc();persist()
 print('ROOT_AF2EC8EA_SCOPED_FIX_STARTED '+json.dumps({'head':HEAD,'tree':TREE,'target':str(TARGET),'result':str(OUT/'result.json')}),flush=True)
 with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
  child=subprocess.Popen(CMD,cwd=REPO/'codex-rs',env=env,stdout=stdout,stderr=stderr)
  result['cargo_recipe_pid']=child.pid;persist();code=child.wait()
 result['exit_code']=code;result['after']=snapshot(REPO);result['source_unchanged']=result['before']==result['after']
 (OUT/'fix.patch').write_bytes(git(REPO,'diff','--binary','--no-ext-diff','HEAD'))
 for raw in git(REPO,'diff','--name-only','-z','HEAD').split(b'\0'):
  if raw:
   rel=Path(os.fsdecode(raw));target=OUT/'postimage'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((REPO/rel).read_bytes())
 result['status']='completed'
except BaseException as error:
 result['status']='driver_failed' if child is not None else 'preflight_failed'
 result['exception_type']=type(error).__name__;result['exception']=str(error)
 (OUT/'driver-error.log').write_text(traceback.format_exc())
finally:
 result['finished']=utc();result['elapsed']=time.monotonic()-started
 result['logs']={}
 for p in sorted(OUT.rglob('*')):
  if p.is_file() and p.name not in ['result.json','result.json.tmp']:
   raw=p.read_bytes();result['logs'][p.relative_to(OUT).as_posix()]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 persist()
 if lock is not None:lock.close()
 print('ROOT_AF2EC8EA_SCOPED_FIX_TERMINAL '+json.dumps(result),flush=True)

# This integration probe stops after compilation; native tests require a separate exact-source launch.
