"""Retain closed ordinary-A evidence; no compilation or test is executed."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import tarfile

BASE = Path('/home/qq/hepta-learn-ff41-tools')
OUT = BASE / 'validation/root-native-originals-af2ec8ea-v1'
RUNS = ['root-af2ec8ea-native-tests-v1', 'root-af2ec8ea-scoped-fix-v1']
assert os.geteuid() == 0
OUT.mkdir(mode=0o700)
os.chown(OUT, 1000, 1000)
sources = {}

def add_tree(directory, prefix):
    assert directory.is_dir() and not directory.is_symlink()
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            rel = path.relative_to(directory)
            if rel.parts[0] == 'bin' or rel.parts[:2] == ('helpers', 'bin'):
                continue
            assert stat.S_ISREG(path.stat().st_mode)
            sources[prefix + '/' + rel.as_posix()] = path

children = set()
for name in RUNS:
    directory = BASE / 'validation' / name
    result = json.loads((directory / 'result.json').read_text())
    assert result['status'] == 'completed' and result['source_unchanged'] is True
    if name.endswith('native-tests-v1'):
        assert result['ordinary-a']['collection']['total_testcases'] == 1
    add_tree(directory, 'validation/' + name)
    junit = directory / 'ordinary-a.xml'
    if junit.exists():
        children.update(re.findall(
            r'ORDINARY_Q24_ORIGINAL_CHILD_LOGS=(/tmp/ordinary-q24-original-process-[A-Za-z0-9]+)',
            junit.read_text()))
for short in ['af2ec8ea']:
    public = Path('/tmp') / ('hepta-native-' + short + '-ff41-v1')
    for env in [public / 'product-env.json', public / 'helpers/env.json']:
        assert all(key.startswith('CARGO_BIN_EXE_') for key in json.loads(env.read_text()))
    add_tree(public, 'public/' + public.name)
for child in sorted(children):
    path = Path(child)
    add_tree(path, 'original-child-logs/' + path.name)
for name in ['root_af2ec8ea_native_tests_v1.py', 'root_af2ec8ea_scoped_fix_v1.py']:
    sources['drivers/' + name] = BASE / name

rows = []
for name, path in sorted(sources.items()):
    raw = path.read_bytes()
    metadata = path.stat()
    rows.append(dict(path=name, original_path=str(path), bytes=len(raw),
                     sha256=hashlib.sha256(raw).hexdigest(),
                     git_blob=hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
                     uid=metadata.st_uid, gid=metadata.st_gid, mode=stat.S_IMODE(metadata.st_mode)))
manifest = dict(scope='Closed original af2ec8ea ordinary-A result, matching scoped compile, '
                'actual helper/product manifests and build logs, child stdout/stderr and exact drivers. '
                'Pinned executable files are excluded; no test success is inferred from compilation. '
                'Prior JUnit files marked excluded retain their original status.',
                collector_uid=os.geteuid(), files=rows, file_count=len(rows),
                input_bytes=sum(row['bytes'] for row in rows))
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
(OUT / 'manifest.json').write_bytes(manifest_raw)
archive = OUT / 'originals.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for row in rows:
        path = sources[row['path']]
        raw = path.read_bytes()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        tar.addfile(tar.gettarinfo(str(path), arcname=row['path']), io.BytesIO(raw))
    info = tarfile.TarInfo('manifest.json')
    info.size = len(manifest_raw)
    info.mode = 0o600
    tar.addfile(info, io.BytesIO(manifest_raw))
for row in rows:
    raw = sources[row['path']].read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
raw = archive.read_bytes()
result = dict(archive=str(archive), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
              git_blob=hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
              manifest_sha256=hashlib.sha256(manifest_raw).hexdigest(),
              file_count=len(rows), input_bytes=manifest['input_bytes'],
              original_bytes_unchanged=True, native_tests_run=False)
(OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
for path in OUT.iterdir():
    os.chown(path, 1000, 1000)
print(json.dumps(result), flush=True)
