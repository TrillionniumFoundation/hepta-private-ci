"""Recover the official original files from the published frozen manifest without running a model."""
import argparse,json,sys
from pathlib import Path
default=Path(__file__).resolve().parent
sys.path.insert(0,str(Path('trial').resolve()))
from qualification.hcsn_intervention_value.media.acquire import acquire,digests
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--manifest',type=Path,default=default/'sources.json')
p.add_argument('--output',type=Path,required=True)
arg=p.parse_args();root=arg.output.resolve();(root/'media-cache').mkdir(parents=True,exist_ok=True)
for entry in json.loads(arg.manifest.read_text()):
    acquire(entry,root,root/'verified_acquisition.jsonl')
    actual=root/'media-cache'/(str(entry['pageid'])+Path(entry['title']).suffix)
    if digests(actual)!=[entry['sha1'],entry['original_sha256']]:
        raise ValueError(f'original does not match receipt: {entry["pageid"]}')
