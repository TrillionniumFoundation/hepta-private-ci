"""Run the archived visual frontend in bounded source batches; preserve per-query probabilities."""
from pathlib import Path
import os,sys,json,subprocess,time,argparse
from collections import defaultdict
base=Path(__file__).resolve().parent;project=base.parents[1]
mod='qualification.hcsn_intervention_value.media.'
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MALLOC_ARENA_MAX='1')
sem=base/'semantic';parts=sem/'parts';parts.mkdir(exist_ok=True,parents=True)
weight=project/'lab2/weights/resnet18.pth'
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('split',nargs='+',choices=('train','dev','test'));o=parser.parse_args()

def child(s,stem,rows):
 receipt=parts/(stem+'.receipt.json');out=parts/(stem+'.npz');roster=parts/(stem+'.roster.json')
 if receipt.exists() and json.loads(receipt.read_text())['status']=='ok':return True
 if receipt.exists(): receipt.rename(receipt.with_suffix('.previous'))
 roster.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
 t=time.monotonic()
 with (parts/(stem+'.log')).open('a') as f:
  p=subprocess.run([sys.executable,'-m',mod+'vision',str(roster),s,str(out),'--weights',str(weight),'--threads','1'],env=env,stdout=f,stderr=subprocess.STDOUT)
 print(stem,len(rows),'exit',p.returncode,'wall',time.monotonic()-t,flush=True)
 return p.returncode==0

for s in o.split:
 if (sem/(s+'.receipt.json')).exists() and json.loads((sem/(s+'.receipt.json')).read_text())['status']=='ok':continue
 groups=defaultdict(list)
 for r in json.loads((base/'roster'/(s+'.json')).read_text()):groups[r['recording']].append(r)
 for rid,rows in groups.items():
  stem=f'{s}_{rid}'
  if child(s,stem,rows):continue
  failed=parts/(stem+'.receipt.json')
  if failed.exists():failed.rename(parts/(stem+'.failed.json'))
  for j,row in enumerate(rows):
   if not child(s,f'{stem}_{j+1}',[row]):raise RuntimeError(f'failed even for one query: {row["query_id"]}')
 subprocess.run([sys.executable,'-m',mod+'assemble_vision',str(base/'roster'/(s+'.json')),s,str(parts),str(sem/(s+'.npz'))],env=env,check=True)
 print(s,'assembled',flush=True)
