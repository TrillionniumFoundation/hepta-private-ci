from pathlib import Path
import json,numpy as np,hashlib,zipfile
p=Path(__file__).resolve().parent
def sha(name):
 with name.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(name):return json.loads(name.read_text())
seal=read(p/'data_freeze.json');source=read(p/'source_report.json');by={}
for s in ('train','dev','test'):
 raw=p/'features'/(s+'.npz');sem=p/'semantic'/(s+'.npz');rfile=p/'roster'/(s+'.json');rows=read(rfile);rr=read(p/'receipts'/(s+'.json'));sr=read(p/'semantic'/(s+'.receipt.json'))
 with np.load(raw) as a,np.load(sem) as b:
  ids=[r['query_id'] for r in rows];assert ids==a['query_id'].tolist()==b['query_id'].tolist()
  assert len(ids)==seal['query_counts'][s]==len(set(ids));n=len(ids)
  assert len(set(a['recording']))*4==len(ids) and 2*sum(a['label'])==n
  assert a['audio'].shape==(n,6,52) and a['visual'].shape==(n,6,76) and b['probability'].shape==(n,6,2)
  assert np.isfinite(b['probability']).all() and np.allclose(b['probability'].sum(-1),1)
 assert sha(raw)==rr['sha256'] and sha(sem)==sr['output_sha256'] and sha(rfile)==sr['roster_sha256']==rr['roster_sha256']==seal['rosters_sha256'][s]
 by[s]=dict(windows=n,recordings=len(ids)//4,raw_sha256=sha(raw),semantic_sha256=sha(sem),roster_sha256=sha(rfile),raw_receipt_sha256=sha(p/'receipts'/(s+'.json')),semantic_receipt_sha256=sha(p/'semantic'/(s+'.receipt.json')))
names=['README.md','plan.json','sources.json','data_freeze.json','excluded_or_reserve.json','visual_provenance_qc.json','source_report.json','vision_disk_equivalence.json','test_release.json','acquisition.jsonl','portable_replay.py','reacquire.py','relocate.py','technical.py','roster.py','materialize.py','rgb_disk.py','vision_disk.py','check_vision_disk.py','assemble_verified.py','sealed_test_jobs.py','semantic_parts.py','plan_pending_vision.py','make_report.py','final_packet.py']
files={f'pinned/{n}':p/n for n in names}
for d in ('roster','technical','receipts'):
 for f in sorted((p/d).glob('*.json')):files['pinned/'+d+'/'+f.name]=f
for f in sorted((p/'semantic/parts').glob('*.json')):files['pinned/semantic/parts/'+f.name]=f
for f in sorted((p/'semantic').glob('*.receipt.json')):files['pinned/semantic/'+f.name]=f
for n in ('semantic_parts.log','semantic_dev_progress.log','test_jobs.log','non_test.log','test_raw.log','test_inference.log','acquire.log','technical.log','portable_check.log'):
 if (p/n).is_file():files['pinned/log/'+n]=p/n
archive=p/'source_replay.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,path in sorted(files.items()):
  item=zipfile.ZipInfo(n,(1980,1,1,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;z.writestr(item,path.read_bytes())
 manifest={k:sha(v) for k,v in files.items()}
 item=zipfile.ZipInfo('hashes.json',(1980,1,1,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;z.writestr(item,json.dumps(manifest,sort_keys=True,indent=2))
with zipfile.ZipFile(archive) as z:
 for name,expected in json.loads(z.read('hashes.json')).items():assert hashlib.sha256(z.read(name)).hexdigest()==expected
report=dict(qualified_media=True,partitions=by,data_seal_sha256=sha(p/'data_freeze.json'),source_report_sha256=sha(p/'source_report.json'),source_kit_sha256=sha(archive),source_kit_bytes=archive.stat().st_size,kit_entries=len(files)+1,portable_entry='pinned/portable_replay.py',originals_in_kit=False,model_weights_in_kit=False,test_authorization=source['test_authorization'],test_completion=source['test_completion'],pretrained_reference='Existing repo checkout qualification/hcsn_intervention_value/media and official ResNet-18 ImageNet V1 checkpoint f37072fd47e89c5e827621c5baffa7500819f7896bbacec160b1a16c560e07ec.',semantic_comparison_sha256=sha(p/'vision_disk_equivalence.json'))
out=p/'evidence_packet.json';out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print('packet',sha(out),'kit',sha(archive),archive.stat().st_size,'items',len(files)+1,flush=True)
