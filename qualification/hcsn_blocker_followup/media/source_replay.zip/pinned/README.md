# 新独立钢琴／吉他录制队列

本轮的 22 个作品、22 个已知制作组、22 个上传账号均与上一轮入选作品的对应字段分离。两轮沿用原已训练声学头、原图库、同一 ImageNet 视觉头和价格。新数据检验的是这些固定条件下购买相机信息的策略。两个工作流的数据分布和价格保持同一任务定义，新录制的人员、场景及时间来自不同生产过程。

| 分区 | 钢琴作品 | 吉他作品 | 总片段 |
|---|---:|---:|---:|
| TRAIN | 4 | 4 | 32 |
| DEV | 3 | 3 | 24 |
| TEST | 4 | 4 | 32 |

## 来源与冻结

数据源为 Wikimedia Commons 对应作品页面发布的原始视频。完整署名、许可、公开永久页面、版本、SHA-1、原始字节数和本地 SHA-256 见 `sources.json`。历史公开影片的许可可能限定司法辖区。作品覆盖音乐会、庆祝活动、音乐录影、钢琴或吉他实验演示、民间录音等。主乐器标签取自作品页面。它无法确保每个前缀都有可闻旋律或画面内出现乐器。部分演示使用信息卡；部分表演带歌声、舞蹈或伴奏。

`plan.json` 固定每类 13 个候选、顺序、分区槽位、时间窗口和技术准入。四个 2.88 秒窗口分别落于原始时长中心 90% 的四个等分区间。优先使用原始均匀锚点，遇时间戳不连续时按距离试 0.10 秒预设网格。四个区间必须均有足量原始 PCM、合法前缀视频帧、原始声学包时间覆盖；窗口内快速解码不能把 PCM 时钟向未来移动超过一个源样本。未使用能量、类别输出、人工可识别性或策略收益挑选时间点。`technical/*.json` 保留 26 件候选的完整性检查和命中的时间。两件吉他演示因时钟技术条件被排除，按原顺序启用两件吉他备用。两件钢琴备用未启用。没有对音视频作合成补全。

`visual_provenance_qc.json` 标记人工来源检查。2026-11-23 02:36:35 UTC 以作品 24% 和 66% 两个时点的画面核对拍摄类型，共查看 24 件候选，其中最终 TRAIN 7/8、DEV 6/6、TEST 7/8。检查时尚未计算新来源的模型输出；本次查看未改变规则、作品排序或切片。`data_freeze.json` 于 02:37:24 UTC 绑定三个名册、所有原件、所有精确时间点和实现。TEST 的原始视频是可公开访问的数据。该设计依赖建模者遵守先封存后评估的操作约定，无法提供密码学保密性。

## 文件与复算

从包含 `trial/` 与 `lab2/` 的实验检出根目录执行。重新获取发布字节时，应使用固定 `sources.json` 的原始 URL 和 SHA-1，连同原始长度核验后保存为 `media-cache/<pageid>.<ext>`。重建已有身份与时间的特征不需要重新搜索 Commons。运行需 FFmpeg、FFprobe 和 NumPy。语义分支另需 PyTorch、torchvision 及 Pillow，使用原轮已校验固定 ResNet-18 权重。

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python lab3/recordings/reacquire.py --output lab3/recordings
python lab3/recordings/materialize.py train
python lab3/recordings/materialize.py dev
python -m qualification.hcsn_intervention_value.media.vision \
  lab3/recordings/roster/train.json train lab3/recordings/semantic/train.npz \
  --weights lab2/weights/resnet18.pth --threads 1
```

上例的 Python 路径应包含资格模块 `trial` 和已安装依赖。名册的 `local_media` 是采集机绝对路径，跨机器复现应将同一原件定位至本机缓存，并另存映射；验证原名册的哈希时应保留发布的原始文件。原件及人工来源检查用的截屏均不上传。各原始特征分片含 `audio[E,6,52]`、`visual[E,6,76]`、对应分块特征、`dt`、`group`、`recording`、`label`、`query_id`、`start_seconds` 和 `split`。语义分片存 `probability[E,6,2]` 与 `query_id`，顺序为钢琴、吉他。`source_report.json` 给出下载及特征阶段的计时边界。

跨机器独立复算可以先运行 `reacquire.py --manifest <发布目录>/sources.json --output <新目录>`，再运行 `relocate.py <发布目录> <新目录>`。后一步核验每个原件、每个发布名册及原封存摘要，并生成另存的本地路径映射。调用 `materialize.work(Path(<新目录>), "train")` 可从本地原件重建非语义特征。

内存受限时，`rgb_disk.py` 将同一冻结 PTS 选取的 RGB 字节暂存，`vision_disk.py` 逐帧执行原 torchvision 变换，仍将相同六帧 float32 batch 送入同一模型。`check_vision_disk.py` 在两件真实 TRAIN 作品（720p、1080p）上重算原代码，与分期结果逐字节比较输入、1,000 类 logits 和两个类别的后验概率。`assemble_verified.py` 按原查询顺序检查并合并原流程与适配流程，保留不同脚本及逐件收据的真实身份。临时 RGB 与原视频均为本地复现资源。
