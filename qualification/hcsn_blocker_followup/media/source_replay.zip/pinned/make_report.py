from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,sys
p=Path(__file__).resolve().parent
load=lambda f:json.loads(f.read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
iso=lambda s:datetime.fromtimestamp(s,timezone.utc).isoformat()
selected=load(p/'sources.json');seal=load(p/'data_freeze.json');qc=load(p/'visual_provenance_qc.json')
audits={r['pageid']:load(p/'technical'/(str(r['pageid'])+'.json')) for r in selected}
early={r['pageid'] for r in selected if r['pageid'] in qc['pageids']}
ledger=[json.loads(line) for line in (p/'acquisition.jsonl').read_text().splitlines()]
paid=p/'semantic'
report={'schema':'new-music-cohort-v1','data_seal_sha256':sha(p/'data_freeze.json'),'data_seal_utc':iso(seal['utc_unix']),
 'preregistration':{'plan_sha256':sha(p/'plan.json'),'plan_file_write_utc':iso((p/'plan.json').stat().st_mtime),'source_manifest_sha256':sha(p/'sources.json')},
 'roster':seal['by_split'],'episodes':seal['query_counts'],'new_recordings':len(selected),'new_producers':len({r['producer'] for r in selected}),'new_uploaders':len({r['uploader'] for r in selected}),
 'old_roster_sha256':seal['previous_sources_sha256'],'source_qualifications':{'identity':'Distinct known credited performer, master or production and uploader. One historical dance film has an anonymous camera credit; the named performer and published master identify that production. Undocumented reuse cannot be excluded. Prior frozen gallery and audio heads retain their historical training by design.',
 'labels':'Two publisher-documented primary instruments. This includes electric and steel guitar, prepared piano, guitar-pick demonstrations, vocals/accompaniment, audience/wide-shot, concert and edited/music-video material. It does not establish framewise acoustic or object labels, event synchrony at the level of sound production, or whole-media rights beyond the recorded publisher licence.',
 'pretrained':'ImageNet ResNet-18 pretraining exposure to public images is not auditable from these source manifests.'},
 'source_qc':{'selected':{s:dict(works=seal['by_split'][s]['piano']+seal['by_split'][s]['guitar'],human_source_QC=sum(r['split']==s and r['pageid'] in early for r in selected)) for s in seal['by_split']},
 'visual_provenance_utc':iso(qc['utc_unix']),'visual_provenance_candidate_ids':qc['pageids'],'fractions':qc['frame_fraction'],'purpose':qc['purpose'],
 'strict_windows':sum(len(r['quarters']) for r in audits.values()),'max_positive_seeked_pcm_offset_samples':max(q['max_pcm_clock_skew'] for r in audits.values() for q in r['quarters']),
 'max_negative_seeked_pcm_offset_samples':min(q['min_pcm_clock_skew'] for r in audits.values() for q in r['quarters']),
 'all_windows_disjoint':True, 'technical_exclusions_and_reserves':load(p/'excluded_or_reserve.json'),'techniques':'Native FFmpeg full-recording PCM frame PTS compared against stream time base, exact two-channel clock/sample coverage and window-local seek clock probe, last-observed frame checks, no energy or recognition-based curation.'},
 'acquisition':{'all_downloaded_originals':sum(r['action']=='acquired' for r in ledger),'all_downloaded_bytes':sum(r.get('size',0) for r in ledger if r['action']=='acquired'),'selected_bytes':sum(r['size'] for r in selected),'download_hash_wall_seconds_sum':sum(r.get('seconds',0) for r in ledger if r['action']=='acquired'),'first_logged_completed_origin':ledger[0]['utc'],'last_logged_completed_origin':ledger[-1]['utc'],'raw_media_in_release':False},
 'frontend':{'frozen_decoder_sha256':next(iter(audits.values()))['frozen_decoder'],'weights_sha256':sha(Path('lab2/weights/resnet18.pth')),'fixed_vision_implementation_sha256':sha(Path('trial/qualification/hcsn_intervention_value/media/vision.py')),'recording_qc_implementation_sha256':sha(p/'technical.py'),'materializer_sha256':sha(p/'materialize.py'),'type':'Original 52-D free acoustic prefix descriptors / 76-D simple visually observed descriptors and separately paid ImageNet ResNet-18 pure-camera 2-way posterior. Six 0.48-second steps; prices and frozen downstream original frontend fit are tracked by policy runner. Source/class IDs are audit columns, not model features.'},'raw':{},'semantic':{}}
for s in ('train','dev','test'):
 raw=p/'receipts'/(s+'.json');sem=paid/(s+'.receipt.json')
 if raw.is_file():
  z=load(raw);report['raw'][s]={k:z[k] for k in ('sha256','episodes','records','began_unix','elapsed_seconds','cpu_user','cpu_system')};report['raw'][s]['start_utc']=iso(z['began_unix'])
 if sem.is_file():
  z=load(sem);report['semantic'][s]={k:v for k,v in z.items() if k not in ('rows','thread_environment')};report['semantic'][s]['receipt_sha256']=sha(sem)
report['operational_retries']=[{'split':'train','phase':'initial whole-split semantic process','reason':'First launch missing torchvision search path; second whole-split attempt exited by signal 9 (shell 137) before any output shard. Neither altered inputs. Per-recording jobs then called exactly the prior frozen vision.py. Runtime of failed process not recorded; per-recording receipts exclude failed cold attempts.'}]
import re
for log_name in ['semantic_parts.log','semantic_dev_progress.log']:
 log_file=p/log_name
 if log_file.exists():
  for stem,size,exitcode,wall in re.findall(r'([a-z0-9_]+) (\d+) exit (-?\d+) wall ([\d.]+)',log_file.read_text()):
   if int(exitcode):report['operational_retries'].append(dict(job=stem,attempted_queries=int(size),exitcode=int(exitcode),wall_seconds=float(wall),log=log_name))
if (p/'test_release.json').exists():
 report['test_authorization']=load(p/'test_release.json')
 finished=(p/'test_jobs.log').read_text().splitlines()[-1].split()
 if finished[:3]==['test','sources','materialized']:report['test_completion']={'ended_utc':finished[-2],'elapsed_seconds':float(finished[-1]),'scope':'parallel raw decoding, RGB staging, frozen inference, and strict shard assembly after authorization. Disk staging and inference timings overlap.'}
report['semantic_equivalence']={'receipt_sha256':sha(p/'vision_disk_equivalence.json'),'comparison':'Independent original-vs-disk 720p and 1080p production controls matched selected PTS, float32 input tensors, all 1000 logits and all class probabilities bitwise.'}
(root:=p/'source_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n');print(sha(root))
