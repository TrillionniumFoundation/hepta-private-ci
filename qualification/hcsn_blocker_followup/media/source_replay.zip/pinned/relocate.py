"""Verify and rebind only absolute local media paths for an independent source replay."""
import argparse,hashlib,json,shutil
from pathlib import Path
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('original',type=Path);p.add_argument('output',type=Path);ns=p.parse_args()
 source=ns.original.resolve();out=ns.output.resolve()
 if source==out:raise ValueError('replay destination must differ from archived original')
 if (out/'data_freeze.json').exists():raise FileExistsError(out/'data_freeze.json')
 (out/'roster').mkdir(parents=True,exist_ok=True);original=json.loads((source/'data_freeze.json').read_text())
 new=dict(original);new['original_seal_sha256']=sha(source/'data_freeze.json')
 assert sha(source/'sources.json')==new['sources_sha256']
 records=json.loads((source/'sources.json').read_text());ids={str(r['pageid']):r for r in records}
 targets={i:out/'media-cache'/(i+Path(r['title']).suffix) for i,r in ids.items()}
 for i,target in targets.items():
  if target.stat().st_size!=ids[i]['size'] or sha(target)!=ids[i]['original_sha256']:raise ValueError(f'original input mismatch {i}')
 shutil.copyfile(source/'sources.json',out/'sources.json');new['rosters_sha256']={}
 for s,expected in original['rosters_sha256'].items():
  f=source/'roster'/(s+'.json');assert sha(f)==expected
  rows=json.loads(f.read_text())
  for row in rows:row['local_media']=str(targets[row['recording']])
  dest=out/'roster'/(s+'.json');dump(dest,rows);new['rosters_sha256'][s]=sha(dest)
 dump(out/'data_freeze.json',new)
if __name__=='__main__':main()
