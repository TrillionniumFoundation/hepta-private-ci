from pathlib import Path
import json,sys
p=Path(__file__).resolve().parent
for s in sys.argv[1:]:
 rows=json.loads((p/'roster'/(s+'.json')).read_text())
 done={q['query_id'] for f in (p/'semantic/parts').glob(s+'_*.receipt.json') for d in [json.loads(f.read_text())] if d['status']=='ok' for q in d['rows']}
 remaining=[r for r in rows if r['query_id'] not in done]
 (p/'semantic/parts'/(s+'_disk.roster.json')).write_text(json.dumps(remaining,indent=2,ensure_ascii=False)+'\n')
 (p/('remaining_'+s+'.txt')).write_text('\n'.join(r['query_id'] for r in remaining)+'\n')
 print(s,len(remaining))
