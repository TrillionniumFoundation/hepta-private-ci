"""Materialize held-out media after the caller's model-selection seal."""
import concurrent.futures,datetime,json,os,subprocess,sys,time
from pathlib import Path
from rgb_disk import one
base=Path(__file__).resolve().parent
pkg=base.parents[1]
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MALLOC_ARENA_MAX='1')
def cmd(args,log):
 with (base/log).open('a') as fh:subprocess.run([sys.executable,*map(str,args)],env=env,check=True,stdout=fh,stderr=subprocess.STDOUT)
def stage(rows):
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(one,rows))
if __name__=='__main__':
 rows=json.loads((base/'roster/test.json').read_text());began=time.time()
 cmd([base/'plan_pending_vision.py','test'],'test_stages.log')
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  st=pool.submit(stage,rows)
  raw=pool.submit(cmd,[base/'materialize.py','test'],'test_raw.log')
  infer=pool.submit(cmd,[base/'vision_disk.py','test',base/'semantic/parts/test_disk.roster.json',base/'semantic/parts/test_disk.npz'],'test_inference.log')
  st.result();raw.result();infer.result()
 cmd([base/'assemble_verified.py','test'],'test_stages.log')
 print('test sources materialized',datetime.datetime.now(datetime.timezone.utc).isoformat(),time.time()-began,flush=True)
