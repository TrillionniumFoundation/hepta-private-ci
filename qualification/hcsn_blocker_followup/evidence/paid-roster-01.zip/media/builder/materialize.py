"""Construct new-shard raw observations with the original decoder, then the frozen visual head."""
from pathlib import Path
import argparse,concurrent.futures,datetime,hashlib,json,os,resource,subprocess,sys,time,tempfile
import numpy as np
from technical import HERE,build,fixed

def work(root,split):
 freeze=json.loads((root/'data_freeze.json').read_text())
 roster_file=root/'roster'/(split+'.json');rows=json.loads(roster_file.read_text())
 if build.digest(roster_file)!=freeze['rosters_sha256'][split]:raise ValueError('altered split roster')
 src={r['pageid']:r for r in json.loads((root/'sources.json').read_text())}
 if build.digest(root/'sources.json')!=freeze['sources_sha256']:raise ValueError('altered source registry')
 begin=time.monotonic();start=time.time();window=root/'window-cache'/split;window.mkdir(exist_ok=True,parents=True)
 args=[]
 for r in rows:
  s=src[int(r['recording'])]; original=Path(r['local_media'])
  if build.digest(original)!=s['original_sha256']:raise ValueError('original archive digest mismatch')
  bind={'input_sha256':s['original_sha256'],'frontend_sha256':build.digest(Path(fixed.__file__)),'start_seconds':r['start_seconds']}
  args.append((str(original),r,window,bind))
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:details=list(pool.map(build.job,args))
 col={}
 for r in rows:
  with np.load(window/(r['query_id']+'.npz'),allow_pickle=False) as f:
   for k in f.files:col.setdefault(k,[]).append(f[k])
  for k in ('label','group','recording','query_id','dt','start_seconds','split'):col.setdefault(k,[]).append(r[k])
 cols={k:np.asarray(v) for k,v in col.items()};n=len(rows)
 for k,dim in [('audio',52),('visual',76)]:
  assert cols[k].shape==(n,6,dim) and np.array_equal(cols[k],cols[k+'_block'].cumsum(1)/np.arange(1,7)[None,:,None])
 out=root/'features'/(split+'.npz');out.parent.mkdir(exist_ok=True)
 with tempfile.NamedTemporaryFile(dir=out.parent,suffix='.npz',delete=False) as fh:
  np.savez_compressed(fh,**cols);temp=Path(fh.name)
 os.replace(temp,out)
 cpu=resource.getrusage(resource.RUSAGE_SELF);children=resource.getrusage(resource.RUSAGE_CHILDREN)
 info=dict(split=split,episodes=n,records=len({row['recording'] for row in rows}),frozen_source_sha256=freeze['sources_sha256'],frontend_sha256=details[0]['binding']['frontend_sha256'],sha256=build.digest(out),roster_sha256=build.digest(roster_file),began_unix=start,elapsed_seconds=time.monotonic()-begin,cpu_user=cpu.ru_utime+children.ru_utime,cpu_system=cpu.ru_stime+children.ru_stime,individual_records=details)
 build.save_json(root/'receipts'/(split+'.json'),info);print(split,info['sha256'],info['elapsed_seconds'],flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('split',choices=('train','dev','test'));a=p.parse_args()
 work(HERE,a.split)
