"""Bind distinct new Commons works, quarter times and immutable originals before scoring."""
from pathlib import Path
import hashlib,json,re,time
import numpy as np
from technical import HERE,build
PRODUCERS={
43697361:'Trumpetrep',40222673:'Biswarup Ganguly and Johnny Purty',198374754:'CanadaPiano1998',46205579:'JHistory',
157539108:'Paramount / Chico Marx / The Cocoanuts',90400953:'Doug Haslam',184704912:'Alan Atanton / Stewart Yeff',
28102065:'Golf Bravo / Yaroslavsky station',68801795:'Santi Music School',67284494:'Tobias Frei / Prophecy',
163037840:'Concert Films Corporation / Paul Gordon / Jakob Gimpel',121725321:'Leezy',9917138:'Rerumirf / Harold Bauer Duo-Art',
22010132:'Tomschryer',112877831:'Isaacvp',142796455:'U.S. Department of State / Antony Blinken',63566948:'La Argentinita / Manolo de Huelva film',
91863130:'DrTrumpet',99719538:'Sir Amugi',34218111:'David Robert Grimes / String Theory',
41489852:'Szervac Attila / Tritonus Guitar Trio',115344562:'Isak Zvegelj / Ljubljana Street Country',
147121838:'BEAG music',46917193:'Blues Breaking Records / Gerry Joe Weise',114759433:'Cultuur in Actie / The Five Great Guitars',85721948:'Viktor O. Ledenyov / Summer Guitar Festival'}
def read(p):return json.loads(p.read_text())
def freeze():
 plan=read(HERE/'plan.json');oldpath=Path('trial/qualification/hcsn_intervention_value/media/sources.json')
 old=read(oldpath);used={k:{str(r[k]).casefold() for r in old} for k in ['pageid','uploader','sha1','producer']}
 taken=[];references=[];excluded=[]
 for label,ids in plan['priority'].items():
  selected=[]
  for rid in ids:
   base=read(HERE/'metadata'/(str(rid)+'.json')); det=HERE/'technical'/(str(rid)+'.json')
   base['producer']=PRODUCERS[rid]
   if any(str(base[k]).casefold() in vals for k,vals in used.items()):
    excluded.append({'pageid':rid,'reason':'identity overlaps source, performer/producer, prior cohort or uploader'});continue
   if len(selected)>=len(plan['partition_slots_per_label']):
    excluded.append({'pageid':rid,'reason':'ordered backup not required'});continue
   if not det.is_file():return False
   checked=read(det);assert checked['protocol_sha256']==build.digest(HERE/'plan.json')
   if not checked['eligible']:
    excluded.append({'pageid':rid,'reason':checked['reason'],'audit_sha256':build.digest(det)});continue
   split=plan['partition_slots_per_label'][len(selected)];names=re.sub(r'[^a-zA-Z0-9]+','-',base['producer'].lower()).strip('-')
   base.update(label=int(label=='guitar'),split=split,group='new-prod-'+names,original_sha256=checked['source_sha256'],
               technical_sha256=build.digest(det),page_permanent='https://commons.wikimedia.org/w/index.php?oldid='+str(base['page_revision']))
   for k,vals in used.items():vals.add(str(base[k]).casefold())
   selected.append(base);taken.append(base)
   for n,quarter in enumerate(checked['quarters'],1):
    references.append(dict(query_id=f'newcommons-{rid}-w{n:02d}',local_media=str((HERE/'media-cache'/(str(rid)+Path(base['title']).suffix)).resolve()),
        start_seconds=quarter['start_seconds'],group=base['group'],recording=str(rid),split=split,label=base['label'],dt=[.48]*6))
 for split in ('train','dev','test'):
  build.save_json(HERE/'roster'/(split+'.json'),[r for r in references if r['split']==split])
 build.save_json(HERE/'sources.json',taken);build.save_json(HERE/'excluded_or_reserve.json',excluded)
 shard_hashes={s:build.digest(HERE/'roster'/(s+'.json')) for s in ('train','dev','test')}
 build.save_json(HERE/'data_freeze.json',dict(utc_unix=time.time(),sources_sha256=build.digest(HERE/'sources.json'),
     excluded_sha256=build.digest(HERE/'excluded_or_reserve.json'),previous_sources_sha256=build.digest(oldpath),
     plan_sha256=build.digest(HERE/'plan.json'),technical_implementation=build.digest(HERE/'technical.py'),
     roster_implementation=build.digest(Path(__file__)),rosters_sha256=shard_hashes,
     n_recordings=len(taken),n_unique_producers=len({r['producer'] for r in taken}),
     n_unique_uploaders=len({r['uploader'] for r in taken}),by_split={s:{label:sum(r['split']==s and r['instrument']==label for r in taken) for label in plan['priority']} for s in shard_hashes},
     query_counts={s:sum(r['split']==s for r in references) for s in shard_hashes},
     model_scores_opened=False))
 return True
if __name__=='__main__':
 if (HERE/'data_freeze.json').exists():raise ValueError('already sealed')
 while not freeze():time.sleep(.6)
 print('frozen',build.digest(HERE/'data_freeze.json'),flush=True)
