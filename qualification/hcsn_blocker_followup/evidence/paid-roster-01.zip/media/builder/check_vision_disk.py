"""Compare true source RGB tensor, logits and posterior bit-for-bit with the archived code."""
import hashlib,json,sys,os,time
from pathlib import Path
import torch,numpy as np
from qualification.hcsn_intervention_value.media import vision
from vision_disk import tensors,th,ROOT,CHECKPOINT
torch.set_num_threads(1);torch.set_num_interop_threads(1)
m,x,idx=vision.load_model(CHECKPOINT);proof=[]
rows=json.loads((ROOT/'roster/train.json').read_text())
with torch.inference_mode():
 for q in ['newcommons-43697361-w01','newcommons-184704912-w02']:
  r=next(k for k in rows if k['query_id']==q);path=Path(r['local_media'])
  # Independently run original, unmodified decoder and transform.
  imgs,clock=vision.decode_prefixes(path,r['start_seconds'],vision.source_meta(path))
  z=torch.stack([x(im) for im in imgs]);del imgs
  baseline=m(z);p=vision.cumulative_class_probability(baseline,idx)
  cand,raw=tensors(r,x);now=m(cand);cp=vision.cumulative_class_probability(now,idx)
  assert clock==raw['details'] and torch.equal(z,cand) and torch.equal(baseline,now) and torch.equal(p,cp)
  old=ROOT/'semantic/parts'/('train_'+r['recording']+'.npz')
  with np.load(old) as a:
   np.testing.assert_array_equal(a['probability'][list(a['query_id']).index(q)],p.numpy())
  proof.append(dict(id=q,source_sha256=raw['source_sha256'],pts=clock['chosen_pts_ticks'],tensor_dtype=str(z.dtype),shape=list(z.shape),tensor_sha256=th(z),logits_sha256=th(now),probability_sha256=th(p),archived_existing_part_sha256=vision.digest(old),source_equivalent=True))
report=dict(verified=True,examples=proof,original_vision_sha256=vision.digest(vision.__file__),rgb_adapter_sha256=vision.digest(ROOT/'rgb_disk.py'),inference_adapter_sha256=vision.digest(ROOT/'vision_disk.py'),checkpoint_sha256=vision.digest(CHECKPOINT),torch_version=torch.__version__,torchvision_version=vision.torchvision.__version__)
(ROOT/'vision_disk_equivalence.json').write_text(json.dumps(report,indent=2)+'\n');print('bitwise equal for',len(proof),'controls')
