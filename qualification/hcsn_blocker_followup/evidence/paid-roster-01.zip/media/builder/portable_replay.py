"""Recreate released new-cohort features under a new output directory, without legacy absolute paths."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE=Path(__file__).resolve().parent
CLI=argparse.ArgumentParser(description=__doc__)
CLI.add_argument('destination',type=Path)
CLI.add_argument('--previous-code',required=True,type=Path,help='checkout root that contains qualification/hcsn_intervention_value')
CLI.add_argument('--weights',required=True,type=Path,help='original ImageNet ResNet-18 checkpoint')
CLI.add_argument('--media-cache',type=Path,help='optional directory containing the checksum-pinned original Commons files')
CLI.add_argument('--split',choices=('train','dev','test'),action='append')
a=CLI.parse_args()
project=a.destination.resolve();code=a.previous_code.resolve();weight=a.weights.resolve()
if not (code/'qualification/hcsn_intervention_value/media/vision.py').is_file():raise ValueError('missing original qualification package')
if hashlib.sha256(weight.read_bytes()).hexdigest()!='f37072fd47e89c5e827621c5baffa7500819f7896bbacec160b1a16c560e07ec':raise ValueError('checkpoint identity differs')
project.mkdir(parents=True,exist_ok=False);(project/'trial').symlink_to(code,target_is_directory=True)
(project/'lab2/weights').mkdir(parents=True);(project/'lab2/weights/resnet18.pth').symlink_to(weight)
target=project/'lab3/recordings';target.mkdir(parents=True)
for name in ('technical.py','materialize.py','reacquire.py','relocate.py','rgb_disk.py','vision_disk.py'):
 shutil.copyfile(HERE/name,target/name)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONPATH=str(code)+os.pathsep+os.environ.get('PYTHONPATH',''))
def run(*args):
 subprocess.run([sys.executable,*map(str,args)],cwd=project,env=env,check=True)
if a.media_cache:(target/'media-cache').symlink_to(a.media_cache.resolve(),target_is_directory=True)
else:run(target/'reacquire.py','--manifest',HERE/'sources.json','--output',target)
run(target/'relocate.py',HERE,target)
for s in a.split or []:
 run(target/'materialize.py',s)
 run(target/'rgb_disk.py',s)
 (target/'semantic').mkdir(exist_ok=True)
 run(target/'vision_disk.py',s,target/'roster'/(s+'.json'),target/'semantic'/(s+'.npz'))
print(json.dumps({'workspace':str(project),'portable_sources':str(target/'sources.json'),'splits':a.split or []}))
