"""Verify original and bitwise-confirmed disk-staged part identities, then assemble in roster order."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,time
import numpy as np
ROOT=Path(__file__).resolve().parent
def sha(p):
 with Path(p).open('rb') as fh:return hashlib.file_digest(fh,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text())
def assemble(s):
 start=time.monotonic();sem=ROOT/'semantic';folder=sem/'parts'
 target=sem/(s+'.npz');f=ROOT/'roster'/(s+'.json');rows=read(f)
 seal=read(ROOT/'data_freeze.json');assert sha(f)==seal['rosters_sha256'][s]
 wanted={r['query_id']:r for r in rows};sources={str(r['pageid']):r for r in read(ROOT/'sources.json')}
 witness=ROOT/'vision_disk_equivalence.json';proof=read(witness)
 original=sha(Path('trial/qualification/hcsn_intervention_value/media/vision.py'))
 rgb_adapter=sha(ROOT/'rgb_disk.py');inference_adapter=sha(ROOT/'vision_disk.py');expected_weight=sha(Path('lab2/weights/resnet18.pth'))
 assert proof['verified'] and proof['original_vision_sha256']==original and proof['inference_adapter_sha256']==inference_adapter
 assert proof['rgb_adapter_sha256']==rgb_adapter and proof['checkpoint_sha256']==expected_weight
 assert len(proof['examples'])>=2 and all(x['source_equivalent'] for x in proof['examples'])
 mapped={};used=[];disk_elapsed=0.
 for receipt in sorted(folder.glob(s+'_*.receipt.json')):
  d=read(receipt)
  if d['status']!='ok':continue
  stem=receipt.name.removesuffix('.receipt.json');source_list=folder/(stem+'.roster.json');arr=folder/(stem+'.npz')
  assert sha(source_list)==d['roster_sha256'] and sha(arr)==d['output_sha256']
  sr=read(source_list);assert d['split']==s and d['weight_sha256']==expected_weight and d['torchvision']==proof['torchvision_version']
  adapter=d['script_sha256']==inference_adapter
  if not adapter and d['script_sha256']!=original:raise ValueError('unexpected inference code')
  if adapter and (d['original_vision_sha256']!=original or d['rgb_adapter_sha256']!=rgb_adapter):raise ValueError('unbound adapter')
  with np.load(arr,allow_pickle=False) as z:
   ids=z['query_id'].tolist();values=z['probability']
   assert ids==[x['query_id'] for x in sr]==[x['query_id'] for x in d['rows']]
   assert values.shape==(len(ids),6,2) and values.dtype==np.float64 and np.isfinite(values).all()
   assert values.min()>=0 and values.max()<=1 and np.allclose(values.sum(-1),1,atol=1e-12,rtol=0)
   for i,q in enumerate(ids):
    w=wanted[q];m=d['rows'][i];assert w==sr[i] and w['start_seconds']==m['start_seconds'] and m['source_sha256']==sources[w['recording']]['original_sha256']
    assert all(t<end for t,end in zip(m['chosen_pts_seconds'],m['absolute_endpoint_seconds']))
    if q in mapped:raise ValueError('duplicate query '+q)
    if adapter:
     raw=read(ROOT/'rgb-cache'/s/(q+'.json'));assert m['rgb_sha256']==raw['rgb_sha256'] and raw['details']['chosen_pts_ticks']==m['chosen_pts_ticks']
     disk_elapsed+=raw['elapsed_seconds']
    mapped[q]=values[i].copy()
  part={'file':receipt.name,'sha256':sha(receipt),'process_wall_seconds':d['wall_seconds'],'process_cpu_seconds':d['cpu_seconds'],'child_cpu_seconds':d['child_cpu_seconds'],'queries':len(ids),'weight_sha256':d['weight_sha256'],'torchvision':d['torchvision'],'script_sha256':d['script_sha256'],'rgb_staging_sha256':rgb_adapter if adapter else None}
  used.append(part)
 if set(mapped)!=set(wanted):raise ValueError('incomplete query set')
 with target.open('xb') as fh:np.savez_compressed(fh,query_id=np.array(list(wanted)),probability=np.stack([mapped[q] for q in wanted]))
 rec=dict(status='ok',split=s,queries=len(rows),roster_sha256=sha(f),output_sha256=sha(target),parts=used,assembly_wall_seconds=time.monotonic()-start,process_sum_wall_seconds=sum(x['process_wall_seconds'] for x in used),rgb_staging_sum_wall_seconds=disk_elapsed,energy_joules=None,assembly_implementation_sha256=sha(__file__),original_vision_sha256=original,equivalence_sha256=sha(witness),clock_note='CPU/elapsed from individual successful parts exclude failed jobs. Disk staging sum and inference process wall may overlap and must not be summed as elapsed clock.')
 target.with_suffix('.receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(s,len(rows),rec['output_sha256'],flush=True)
if __name__=='__main__':
 cli=argparse.ArgumentParser();cli.add_argument('split',choices=('train','dev','test'));a=cli.parse_args();assemble(a.split)
