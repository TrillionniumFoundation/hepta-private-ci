"""Rate-aware official Wikimedia metadata request, single queue."""
import datetime,json,time,urllib.request,urllib.error
from email.utils import parsedate_to_datetime
HEAD={'User-Agent':'HeptaResearch/1.0 (https://github.com/TrillionniumFoundation/hepta-private-ci; nonprofit research reproducibility)'}
def get(url):
 for i in range(8):
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers=HEAD),timeout=40) as resp:return json.load(resp)
  except urllib.error.HTTPError as e:
   if e.code not in (429,500,502,503,504) or i==7:raise
   val=e.headers.get('retry-after','60')
   try:secs=int(val)
   except ValueError:secs=max(1,int(parsedate_to_datetime(val).timestamp()-time.time()))
   print('official metadata retry',e.code,secs,flush=True);time.sleep(secs+1)
