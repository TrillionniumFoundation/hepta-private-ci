"""Write the original frozen selector's exact RGB output to disk instead of process stdout memory."""
import argparse,ast,bisect,hashlib,json,subprocess,time,re,os
from fractions import Fraction
from pathlib import Path
root=Path(__file__).resolve().parent
frozen=Path('trial/qualification/hcsn_intervention_value/media/vision.py').resolve()
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
# Reuse the frozen original timestamp parser, relative seek discipline and strict endpoint rule.
body=ast.parse(frozen.read_text()).body
use=[n for n in body if (isinstance(n,ast.Assign) and any(isinstance(a,ast.Name) and a.id in ('_FRAME','_BASE') for a in n.targets)) or (isinstance(n,ast.FunctionDef) and n.name in ('_info','select_indices','source_meta'))]
exec(compile(ast.Module(body=use,type_ignores=[]),str(frozen),'exec'),globals())

def one(row):
 st=time.monotonic()
 path=Path(row['local_media']); cache=root/'rgb-cache'/row['split'];cache.mkdir(exist_ok=True,parents=True)
 info=cache/(row['query_id']+'.json');rgb=cache/(row['query_id']+'.rgb')
 if info.is_file() and rgb.is_file():
  old=json.loads(info.read_text())
  if old['rgb_sha256']==sha(rgb) and old['adapter_sha256']==sha(__file__):return
 origin,duration=source_meta(path);start=Fraction(str(row['start_seconds']));ends=[origin+start+Fraction(12,25)*t for t in range(1,7)]
 if start<0 or ends[-1]>origin+duration+Fraction(1,1000):raise ValueError('invalid source duration')
 seek=max(Fraction(0),start-2)
 while True:
  length=start+Fraction(29,10)-seek
  cmd=['ffmpeg','-hide_banner','-nostdin','-v','info','-threads','1','-copyts','-ss',f'{float(seek):.6f}','-t',f'{float(length):.6f}','-i',str(path),'-map','0:v:0','-an','-filter_threads','1']
  probe=subprocess.run(cmd+['-vf','showinfo=checksum=0','-fps_mode','passthrough','-f','null','-'],capture_output=True,check=True)
  clock,rows=_info(probe.stderr);pts=[clock*r[1] for r in rows]
  if pts[0]<ends[0] or seek==0:break
  seek=max(Fraction(0),start-2*(start-seek))
 selected=select_indices(pts,ends);unique=sorted(set(selected))
 expr='+'.join(f'eq(n\\,{n})' for n in unique);filtered=f'select={expr},format=rgb24,showinfo=checksum=0'
 temp=rgb.with_suffix('.tmp')
 with temp.open('wb') as sink:
  proc=subprocess.run(cmd+['-vf',filtered,'-fps_mode','passthrough','-c:v','rawvideo','-threads:v','1','-f','rawvideo','-'],stdout=sink,stderr=subprocess.PIPE,check=True)
 check,kept=_info(proc.stderr)
 if len(kept)!=len(unique) or [check*r[1] for r in kept]!=[pts[k] for k in unique]:raise ValueError('raw RGB PTS mismatch')
 frames={};offset=0
 for ix,(_,_,w,h) in zip(unique,kept):
  frames[ix]=dict(offset=offset,width=w,height=h);offset+=w*h*3
 if temp.stat().st_size!=offset:raise ValueError('raw RGB length mismatch')
 os.replace(temp,rgb)
 details=dict(start_seconds=float(start),absolute_endpoint_seconds=[float(t) for t in ends],chosen_pts_seconds=[float(pts[i]) for i in selected],chosen_pts_ticks=[rows[i][1] for i in selected],time_base=str(clock),decoded_dimensions=[[frames[i]['width'],frames[i]['height']] for i in selected])
 obj=dict(query_id=row['query_id'],recording=row['recording'],source_sha256=sha(path),rgb_sha256=sha(rgb),original_selector_sha256=sha(frozen),adapter_sha256=sha(__file__),frames=[frames[i] for i in selected],details=details,elapsed_seconds=time.monotonic()-st)
 info.write_text(json.dumps(obj,indent=2)+'\n')
 print(row['query_id'],round(obj['elapsed_seconds'],3),flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('split',choices=('train','dev','test'));p.add_argument('--ids',nargs='*');a=p.parse_args()
 rows=json.loads((root/'roster'/(a.split+'.json')).read_text())
 if a.ids:rows=[r for r in rows if r['query_id'] in a.ids]
 for r in rows:one(r)
