from pathlib import Path
import sys,json,time,datetime
sys.path.insert(0,str(Path('trial').resolve()))
from qualification.hcsn_intervention_value.media.acquire import acquire,log
b=Path('lab3/recordings').resolve()
(b/'media-cache').mkdir(exist_ok=True);ledger=b/'acquisition.jsonl';seen=set()
while True:
 lines=(b/'queue.txt').read_text().splitlines()
 for rid in lines:
  if not rid.isdigit() or rid in seen:continue
  while not (b/'metadata'/(rid+'.json')).is_file():time.sleep(1)
  r=json.loads((b/'metadata'/(rid+'.json')).read_text());r['split']='metadata shortlisted candidate'
  try:acquire(r,b,ledger)
  except Exception as e:log(ledger,pageid=r['pageid'],action='unavailable',detail=str(e))
  seen.add(rid)
 if (b/'queue.complete').exists() and all(r in seen for r in lines if r.isdigit()):break
 time.sleep(1)
