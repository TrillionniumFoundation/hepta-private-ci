"""Apply the unchanged official transform and ResNet-18 to disk-staged original RGB frames."""
from pathlib import Path
import argparse,hashlib,json,os,resource,time,sys
import torch,numpy as np
from PIL import Image
from qualification.hcsn_intervention_value.media import vision

ROOT=Path(__file__).resolve().parent
CHECKPOINT=ROOT.parents[1]/'lab2/weights/resnet18.pth'
def sha(p):return vision.digest(p)
def tensors(row,transform):
 folder=ROOT/'rgb-cache'/row['split'];m=json.loads((folder/(row['query_id']+'.json')).read_text());path=folder/(row['query_id']+'.rgb')
 if m['rgb_sha256']!=sha(path) or m['source_sha256']!=sha(Path(row['local_media'])) or m['original_selector_sha256']!=sha(vision.__file__) or m['adapter_sha256']!=sha(ROOT/'rgb_disk.py'):raise ValueError('unbound original, selector or RGB bytes')
 xs=[]
 with path.open('rb') as fh:
  for fr in m['frames']:
   w,h=fr['width'],fr['height'];fh.seek(fr['offset']);raw=fh.read(w*h*3)
   if len(raw)!=w*h*3:raise ValueError('truncated RGB')
   with Image.frombytes('RGB',(w,h),raw) as image:xs.append(transform(image))
   del raw
 return torch.stack(xs),m
def th(x):return hashlib.sha256(x.detach().contiguous().cpu().numpy().tobytes()).hexdigest()

def execute(split,roster,out):
 begin=time.monotonic();cpu=time.process_time()
 rows=json.loads(roster.read_text());torch.set_num_threads(1);torch.set_num_interop_threads(1)
 model,transform,idx=vision.load_model(CHECKPOINT);rec=[];values=[]
 with torch.inference_mode():
  for r in rows:
   while not (ROOT/'rgb-cache'/split/(r['query_id']+'.json')).exists():time.sleep(.5)
   z,m=tensors(r,transform);logits=model(z);prob=vision.cumulative_class_probability(logits,idx)
   rec.append(dict(query_id=r['query_id'],source_sha256=m['source_sha256'],rgb_sha256=m['rgb_sha256'],preprocessed_sha256=th(z),preprocessed_dtype=str(z.dtype),logits_sha256=th(logits),probability_sha256=th(prob),**m['details']))
   values.append(prob.numpy());print('inference',r['query_id'],flush=True)
 tmp=out.with_suffix('.tmp')
 with tmp.open('wb') as f:np.savez_compressed(f,query_id=np.array([r['query_id'] for r in rows]),probability=np.stack(values))
 os.replace(tmp,out)
 stamp=dict(status='ok',split=split,queries=len(rows),output_sha256=sha(out),roster_sha256=sha(roster),weight_sha256=sha(CHECKPOINT),torchvision=vision.torchvision.__version__,script_sha256=sha(__file__),original_vision_sha256=sha(vision.__file__),rgb_adapter_sha256=sha(ROOT/'rgb_disk.py'),wall_seconds=time.monotonic()-begin,cpu_seconds=time.process_time()-cpu,child_cpu_seconds=0.,rows=rec,batch_shape=[6,3,224,224],torch=torch.__version__,self_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
 out.with_suffix('.receipt.json').write_text(json.dumps(stamp,indent=2)+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('split');p.add_argument('roster',type=Path);p.add_argument('out',type=Path);a=p.parse_args();execute(a.split,a.roster,a.out)
