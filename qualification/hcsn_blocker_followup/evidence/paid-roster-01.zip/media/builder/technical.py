"""Select preregistered time windows using publisher clocks without labels or scores."""
from pathlib import Path
import concurrent.futures,hashlib,json,sys,time,subprocess
import numpy as np
sys.path.insert(0,str(Path('trial').resolve()))
from qualification.hcsn_intervention_value.media import build,recording_features as fixed,coverage
from qualification.hcsn_intervention_value.media.clock_sensitivity import timings
HERE=Path(__file__).resolve().parent


def proof(path,duration,timeline,start):
 rate,tolerance,left,right,prev,following,delta,_=timeline
 lo=round(start*rate);hi=round((start+2.88)*rate)
 if lo<left[0] or hi>right[-1]:return None,'audio_endpoint'
 rem=(np.maximum(np.minimum(prev,following),lo)<np.minimum(np.maximum(prev,following),hi))&(np.abs(delta)>tolerance)
 if rem.any():return None,'source_clock_transition'
 seek=max(0,start-.2);off=start-seek
 args=['ffmpeg','-v','info','-nostdin','-threads','1','-ss',f'{seek:.6f}','-i',str(path),'-t',f'{off+2.98:.6f}',
       '-map','0:a:0','-af','asettb=expr=1/sr,ashowinfo','-f','null','-']
 r=subprocess.run(args,capture_output=True,check=True)
 frames=np.array([(int(i),int(t),int(sr),int(n)) for i,t,sr,n in coverage.re.findall(coverage.PATTERN,r.stderr)],dtype='int64')
 if not len(frames):return None,'no_seeked_pcm'
 sampled=np.r_[0,np.cumsum(frames[:-1,3])]; active=(sampled<round((off+2.88)*rate))&(sampled+frames[:,3]>round(off*rate))
 if not active.any():return None,'no_pcm_window'
 skew=frames[active,1]-sampled[active]
 if skew.max()>1:return None,'future_pcm_skew'
 try:pcm,rr,images,pts,original_off=fixed.make_frames(path,start)
 except (ValueError,subprocess.CalledProcessError) as e:return None,'raw_decode_'+type(e).__name__
 if rr!=rate or len(pcm)<round((off+2.88)*rate):return None,'insufficient_seeked_pcm'
 if original_off!=off or len(images)<1 or pts[0]>=off+.04-1e-9:return None,'no_initial_causal_video'
 return dict(start_seconds=start,first_sample=lo,end_sample=hi,rate_hz=rate,min_pcm_clock_skew=int(skew.min()),max_pcm_clock_skew=int(skew.max()),decoded_audio_samples=len(pcm),video_frames=len(images),earliest_video_pts=float(pts[0]),latest_video_pts=float(pts[-1]),original_clock_tolerance=int(tolerance)),None


def qualify(path):
 length=fixed.duration_of(path);timeline=timings(str(path));lo=.05*length;hi=.95*length
 begin=lo;span=(hi-lo)/4
 canonical=np.linspace(lo,hi-2.88,4);winning=[];counts={}
 for i,center in enumerate(canonical):
  low=lo+i*span+(.1 if i else 0.); high=lo+(i+1)*span-2.88-(.1 if i<3 else 0.)
  if high<low: return dict(eligible=False,reason='quarter_too_short',duration=length,quarters=winning,rejections=counts)
  target=float(np.clip(center,low,high))
  options={round(float(v),5) for v in np.arange(low,high+1e-8,.1)}
  options.update((round(target,5),round(high,5)))
  values=sorted(options,key=lambda x:(round(abs(x-center),7),x))
  for s in values:
   found,reason=proof(path,length,timeline,s)
   if found is not None:winning.append(found);break
   counts[reason]=counts.get(reason,0)+1
  else:return dict(eligible=False,reason='quarter_without_valid_window',first_failed_quarter=i+1,duration=length,quarters=winning,rejections=counts)
 return dict(eligible=True,duration=length,quarters=winning,rejections=counts)


def process(row):
 rid=row['pageid'];path=HERE/'media-cache'/(str(rid)+Path(row['title']).suffix);started=time.time()
 if path.stat().st_size!=row['size'] or hashlib.sha1(path.read_bytes()).hexdigest()!=row['sha1']:raise ValueError(f'bad original {rid}')
 try:result=qualify(path)
 except (ValueError,subprocess.CalledProcessError,IndexError) as e:result=dict(eligible=False,reason='technical_exception',error=str(e))
 result.update(pageid=rid,source_sha256=build.digest(path),source_sha1=row['sha1'],size=path.stat().st_size,
               began_utc=started,elapsed_seconds=time.time()-started,protocol_sha256=build.digest(HERE/'plan.json'),
               implementation=build.digest(Path(__file__)),frozen_decoder=build.digest(Path(fixed.__file__)))
 build.save_json(HERE/'technical'/(str(rid)+'.json'),result)
 print(rid,'OK' if result['eligible'] else result.get('reason'),result['elapsed_seconds'],flush=True)
 return rid


def main():
 plan=json.loads((HERE/'plan.json').read_text())
 ids=[str(i) for rows in plan['priority'].values() for i in rows]; pending=set(ids)
 (HERE/'technical').mkdir(exist_ok=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  active={}
  while pending or active:
   for key in list(active):
    if active[key].done():active.pop(key).result()
   for key in ids:
    if key not in pending or len(active)>=2:continue
    if (HERE/'technical'/(key+'.json')).is_file():pending.remove(key);continue
    m=HERE/'metadata'/(key+'.json')
    if not m.is_file():continue
    r=json.loads(m.read_text());path=HERE/'media-cache'/(key+Path(r['title']).suffix)
    if not path.is_file():continue
    active[key]=pool.submit(process,r);pending.remove(key)
   if pending or active:time.sleep(.5)
if __name__=='__main__':main()
