import hashlib,json,os,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
root=Path("/home/qian-qi/hcsn-flow-integration-20261122-0639")
source=root/"sources/fixtures-v4"; evidence=root/"evidence"; frozen=evidence/"fixtures-v4"
assert hashlib.sha256((frozen/"SOURCE_MANIFEST.json").read_bytes()).hexdigest()=="1953148571aa943cc20ad531c2268626acd523cf57cb6adb87e700399b7e3be1"
(root/"studies").mkdir(exist_ok=True)
output=root/"studies/integration-v1"
command=[sys.executable,"-m","qualification.hcsn_scale.study_launcher",str(root/"data/Occupancy_Estimation.csv"),str(output),"--source-manifest",str(frozen/"SOURCE_MANIFEST.json"),"--stream-plan",str(frozen/"STREAM_PLAN.json"),"--adaptation-plan",str(frozen/"ADAPTATION_PLAN.json"),"--child-timeout","1200"]
receipt=evidence/"studies-v1-driver.json"
assert not receipt.exists() and not output.exists()
record={"schema":"hcsn-flow-outer-process-v1","state":"running","utc_start":datetime.now(timezone.utc).isoformat(),"command":command,"source_manifest_sha256":hashlib.sha256((frozen/"SOURCE_MANIFEST.json").read_bytes()).hexdigest(),"declared_trials":45,"runtime_source":str(source),"concurrent_children":1,"cpu_quota_percent":100,"memory_max_bytes":6442450944}
receipt.write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record),flush=True)
started=time.perf_counter()
try:
 with (evidence/"studies-v1.stdout").open("wb") as out,(evidence/"studies-v1.stderr").open("wb") as err:
  child=subprocess.run(command,cwd=source,env=os.environ.copy(),stdout=out,stderr=err,timeout=5400)
 record.update(state="completed" if child.returncode==0 else "failed",exit_code=child.returncode)
except subprocess.TimeoutExpired:
 record.update(state="timed_out",exit_code=None)
finally:
 record.update(cold_launcher_wall_seconds=time.perf_counter()-started,utc_end=datetime.now(timezone.utc).isoformat())
 receipt.write_text(json.dumps(record,indent=2)+"\n")
 print(json.dumps(record),flush=True)
raise SystemExit(0 if record["state"]=="completed" else 1)
