"""Render the completed, verified research evidence without fitting a model."""

import argparse
import json
from pathlib import Path
import statistics

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


NAMES = {
    "hcsn_feedback": "HCSN：完整反馈",
    "hcsn_no_feedback": "HCSN：关闭反馈",
    "hcsn_drop_value_risk": "HCSN：移除 value/risk",
    "hcsn_ordinary_tanh": "HCSN：普通特征替代",
    "tanh": "tanh RNN",
    "gru": "GRU",
    "lif_surrogate": "LIF surrogate 参考",
    "official_cfc": "官方 CfC",
    "gated_delta_reference": "Gated-delta recurrence 参考",
    "causal_transformer": "小型 causal Transformer",
    "keep": "KEEP",
    "direct": "条件直接解",
    "profile_bp": "Profile BP",
    "joint_bp": "Joint BP",
    "bounded_edit": "有界编辑",
}
ORDER = list(NAMES)[:10]
P4_ORDER = list(NAMES)[10:]
PLOT_NAMES = ["HCSN feedback", "HCSN no feedback", "HCSN drop value/risk",
              "HCSN ordinary features", "tanh RNN", "GRU", "LIF reference",
              "Official CfC", "Gated-delta recurrence", "Causal Transformer"]


def number(value, digits=5):
    return f"{value:.{digits}g}"


def render(extracted, output):
    study = extracted / "study"
    summary = json.loads((study / "POSTHOC/summary.json").read_text())
    verified = json.loads((study / "POSTHOC/verification.json").read_text())
    replay = json.loads((study / "POSTHOC/selected_replay.json").read_text())
    if not summary["verification_passed"] or not verified["passed"] or not replay["passed"]:
        raise RuntimeError("only completely verified evidence may be rendered")
    rows = summary["per_seed"]
    aggregates = {(r["study"], r["arm"]): r for r in summary["aggregates"]}
    output.mkdir(parents=True, exist_ok=True)
    for name in ("summary.json", "verification.json", "selected_replay.json"):
        (output / name).write_bytes((study / "POSTHOC" / name).read_bytes())
    stream_table = []
    p4_table = []
    for arm in ORDER:
        item = aggregates[("stream", arm)]
        m = item["metrics"]
        stream_table.append(
            f"| {NAMES[arm]} | {number(m['test_mse']['mean'])} ± {number(m['test_mse']['sample_sd'], 3)} "
            f"| {m['test_accuracy']['mean']:.1%} | {m['cold_wall_seconds']['median']:.2f} "
            f"| {int(m['parameters']['mean'])} / {int(m['total_parameters']['mean'])} "
            f"| {int(m['state_bytes']['mean'])} | {item['adoption_counts'].get('NoUpdate', 0)}/3 |"
        )
    for arm in P4_ORDER:
        item = aggregates[("adaptation", arm)]
        m = item["metrics"]
        p4_table.append(
            f"| {NAMES[arm]} | {number(m['selected_dev_mse']['mean'])} "
            f"| {number(m['preservation_delta']['mean'])} | {m['cold_wall_seconds']['median']:.2f} "
            f"| {int(m['factorizations']['mean'])} | {int(m['backward_evaluations']['mean'])} "
            f"| {item['adoption_counts'].get('KEEP', 0)}/3 "
            f"| {int(sum(r['preservation_rejections'] for r in rows if r['study']=='adaptation' and r['arm']==arm))} |"
        )
    paired = []
    by_key = {(r["study"], r["arm"], r["seed"]): r for r in rows}
    seeds = [181391, 284729, 395201]
    for arm in ORDER[1:4]:
        delta = [by_key[("stream", "hcsn_feedback", s)]["test_mse"]
                 - by_key[("stream", arm, s)]["test_mse"] for s in seeds]
        paired.append(f"| 完整反馈 − {NAMES[arm]} | " + " | ".join(number(v) for v in delta)
                      + f" | {number(statistics.mean(delta))} |")
    portfolio = []
    for row in summary["portfolio_choice"]:
        portfolio.append(f"| {row['seed']} | {NAMES[row['method']]} | {row['candidate_kind']} "
                         f"| {number(row['dev_mse'])} | {number(row['preservation_mse'])} "
                         f"| {row['all_method_cold_seconds']:.2f} | `{row['state_digest'][:16]}` |")
    raw = []
    for row in sorted(rows, key=lambda r: (r["study"], r["arm"], r["seed"])):
        primary = row["test_mse"] if row["study"] == "stream" else row["selected_dev_mse"]
        raw.append(f"| {row['study']} | {row['arm']} | {row['seed']} | {number(primary, 9)} "
                   f"| {row['cold_wall_seconds']:.4f} | {row['adoption']} |")
    colors = ["#176685"] * 4 + ["#9dabb7"] * 6
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
    fig, axes = plt.subplots(1, 2, figsize=(15, 6.5), constrained_layout=True)
    positions = np.arange(10)
    mse = [aggregates[("stream", a)]["metrics"]["test_mse"]["mean"] for a in ORDER]
    costs = [aggregates[("stream", a)]["metrics"]["cold_wall_seconds"]["median"] for a in ORDER]
    axes[0].barh(positions, mse, color=colors, alpha=.7)
    for i, arm in enumerate(ORDER):
        points = [by_key[("stream", arm, s)]["test_mse"] for s in seeds]
        axes[0].scatter(points, i + np.linspace(-.14, .14, 3), color="#173143", s=25, zorder=3)
    axes[0].set_yticks(positions, PLOT_NAMES)
    axes[0].invert_yaxis()
    axes[0].set_xlabel("Held-out one-hot MSE (unconstrained ridge scores; lower is better)")
    if min(mse) > 0 and max(mse) / min(mse) > 20:
        axes[0].set_xscale("log")
        axes[0].set_xlabel("Held-out one-hot MSE (log scale; unconstrained ridge scores)")
    axes[0].set_title("Quality: mean bar and all three fixed seeds", loc="left", weight="bold")
    axes[1].barh(positions, costs, color=colors, alpha=.85)
    axes[1].set_yticks(positions, PLOT_NAMES)
    axes[1].invert_yaxis()
    axes[1].set_xscale("log")
    axes[1].set_xlabel("Median complete cold-process seconds (log scale; lower is better)")
    axes[1].set_title("Cost: imports, preparation, training, selection and saving", loc="left", weight="bold")
    for i, value in enumerate(costs):
        axes[1].text(value * 1.05, i, f"{value:.1f}s", va="center", fontsize=9)
    axes[1].set_xlim(right=max(costs) * 1.8)
    for axis in axes:
        axis.grid(axis="x", alpha=.18)
        axis.set_axisbelow(True)
    fig.suptitle("HCSN physical-flow integration · UCI864 sensor encoder study", fontsize=15, weight="bold")
    fig.savefig(output / "stream_quality_cost.png", dpi=180)
    fig.savefig(output / "stream_quality_cost.svg")
    plt.close(fig)
    total = summary["cold_cost"]["launcher_accounted_total_seconds"]
    report = f"""# HCSN 连续流集成：实现与真实流式实验记录

日期：2026-11-22。源代码见 [Draft PR #6958](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6958)。本记录覆盖审计后的五项接通工作，以及固定计划的 45 个正式运行。

## 交付与来源

- 运行源码 commit：`abb3e5012c5f48e3cb42759785429cb1d496acb3`；基准为 `b0b4b9a1dc424233621fff394d866b654963f8da`。
- 119 个运行源码文件的 manifest：`1953148571aa943cc20ad531c2268626acd523cf57cb6adb87e700399b7e3be1`。独立 GitHub Git-tree 回读全部匹配。
- 修改按 13 个逻辑提交组织，每个少于 500 变更行；默认 legacy 行为和历史实验保持可复现。
- 精确源码 [CI run 45007458768](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45007458768)：124 tests，0 failure/error/skip；canonical formatter、显式 Ruff 和 clean-tree 检查全部成功。这是指定源码检查的结果，不代表全部仓库工作流均通过。
- 原始预测、候选状态、未入选结果、所有成本与运行日志在 `evidence.zip`；机器汇总为 [summary.json](summary.json)，逐项核验为 [verification.json](verification.json)，保存模型的独立重放为 [selected_replay.json](selected_replay.json)。

## 五项实现

1. **统一时间与事件量。** `step_physical` 分开 event-mask 与每秒连续写入率，明确首次事件概率、贴现首次事件、重复事件数、occupation 积分与 continuation value。初始不应期群体参与总体风险。重复事件数可跨区间相加；区间首次事件概率不能直接相加为全窗口风险。
2. **内容进入动力学。** 上一状态的 active/refractory 标记内容经有界投影进入漂移、边界、奖励。四个 HCSN 消融采用同参数配置、同初始权重、同状态容量与输入/批次计划，各自独立训练；关闭 route 后相应参数不活跃。反馈在声明区间起点更新，区间内保持。
3. **接通解析再生参考。** 固定漂移/扩散、reset、确定不应期的独立 Brownian 参考包含重复首达、计数矩、贴现事件及再生价值。测试直接比较实际有限生成元，并显式检查有限 Erlang 不应期的提前释放误差。
4. **直接解、编辑与 BP 共存。** 多目标读出共用一次中心化 SVD；profile/joint 路径保留真实 BP。候选受开发集改进和传入保持集约束；不满足时返回 KEEP。固定程序的编辑 delta 与独立读出求解成本分别记录。
5. **真实传感器 encoder。** 用真实时间差与因果窗口运行四个 HCSN arm、六个参考模型，并保存从开发集选择的模型及一次最终测试预测。外层记录冷进程全部时间。

## 流式 encoder 协议

使用 [UCI Room Occupancy Estimation](https://archive.ics.uci.edu/dataset/864/room+occupancy+estimation)，DOI `10.24432/C5P605`，CC BY 4.0。源 CSV SHA256 为 `c090ee5c94b61762bfec9d22767864490b51030f98cca030f02822468db25d9c`。

输入为 15 个温度、光照、声音幅度、CO₂、PIR 传感器通道；这不是原始音频、视频或全模态语料。使用 16 次观测的因果窗口，窗口之间 reset；实际相邻时间差保留，不对不同 clocks 取平均。训练/开发/测试按时间分离并净空，使用 128/64/118 个窗口。该数据集在项目此前研究中已使用，不称作前瞻性未见数据。

三个固定 seed，每个 arm 完成 64 次 batch=8 的 next-sensor 更新。占用人数标签只用于训练评估 probe 与开发选择；在 step 0/32/64 中按开发 MSE 选模型，最后对测试集评分。基础参数目标为 600 ±15%，持久状态上限为 8192 bytes；实际容量并不相同。表中同时报告基础参数/含 probe 总参数。CPU FP64、单线程；900 秒是下一更新开始前检查的软预算。运行在共享的 Intel Xeon E5-2673 v3 2.40GHz 主机，48 个逻辑 CPU 中对本进程树限制 100% CPU quota，没有专属核心隔离。

测试 MSE 是四个 one-hot 目标坐标上的均方误差；共同 ridge probe 输出未经概率单纯形投影，不能当作已校准概率。sample SD 反映三个完整训练随机种子（初始化与批次顺序），固定时间切分未变化，不构成人群优势置信区间。

| 方法 | 测试 MSE：均值 ± sample SD | 平均 accuracy | 完整冷进程秒：中位数 | 基础/含 probe 参数 | 持久状态 bytes | NoUpdate |
|---|---:|---:|---:|---:|---:|---:|
{chr(10).join(stream_table)}

![真实传感器质量和完整成本](stream_quality_cost.png)

四个 HCSN arm 的基础参数均为 598，持久状态均为 848 bytes，含相同 probe 后总参数为 754。普通特征 arm 仅用普通 tanh 特征替换 risk/value 两列，仍保留其他流动力学、内容和完整流计算成本。以下配对差值使用同一个 seed；负值表示完整反馈的测试 MSE 更低。它检验指定读出与预算下这些通道的增量可用性；通道是内部状态的确定函数，不增加外部信息，也不证明所有 flow 特征或所有任务均有增益。NoUpdate 仅表示选中的 encoder checkpoint 是 step 0；其 ridge probe 仍使用训练标签拟合，全部已发生训练成本照计。

| 配对 MSE 差 | seed 181391 | seed 284729 | seed 395201 | 三 seed 均值 |
|---|---:|---:|---:|---:|
{chr(10).join(paired)}

## 条件解与编辑协议及结果

同 seed 共用未训练 incumbent 和随机预测头。最早 16 个训练窗口作为保持集，额外 purge 一个窗口；其后最多 64 个拟合窗口，开发最多 32 个。归一化和 clock scale 仅由所选拟合输入决定。没有 test 模型评分，也不使用 occupancy 标签。

可编辑 encoder 块限定为 `feedback.projection.weight`。Profile/joint 各运行 8 次 BP；direct 固定 encoder；bounded edit 从同一 incumbent 独立尝试八个预声明 drift/reward 方向，每个 L2=0.02。每个候选需要开发 MSE 改善，并满足保持 MSE ≤ 原始 KEEP +0.01。表中 SVD 指条件读出的分解，不包含流内部线性求解；全部真实耗时仍计入完整费用。P4 MSE 以标准化并截断至 [-8,8] 的 15 个传感器为目标，与上表四维 one-hot MSE 不可直接比较。其开发集参与候选及五方法选择，选中开发分数用于检验本次受约束搜索过程，不是独立测试集泛化结果。

| 方法 | 选中开发 MSE：均值 | 保持 MSE 变化：均值 | 完整冷进程秒：中位数 | 条件 SVD/seed | backward/seed | KEEP | 保持门拒绝：总数 |
|---|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(p4_table)}

每个 seed 在五个已经执行完的方法中按共同开发 MSE 选择。并列按固定方法顺序处理；全搜索费用包括五种方法，不能把选中 direct 或 KEEP 解释成这次搜索只花了该方法的时间。

| seed | 选中方法 | 候选种类 | 开发 MSE | 保持 MSE | 五方法完整总秒 | 状态摘要 |
|---|---|---|---:|---:|---:|---|
{chr(10).join(portfolio)}

## 完整核验与成本范围

45 个冷子进程的计费及 launcher setup/执行共 **{total:.2f} 秒**。所有运行、失败信息与未入选候选都保留；NoUpdate/KEEP 也承担已发生的搜索成本。核验阶段完成 **{verified['check_count']} 项检查**，从保存预测独立重算流式测试指标，并核对所有声明 trial、源码、计划、batch IDs、候选状态与选择门。

另对保存的 KEEP/selected 状态执行独立无梯度重放，核查 15 个 adaptation trial 的开发和保持分数。该重放花费 **{replay['cost']['total_verification_seconds']:.2f} 秒**，执行 **{replay['cost']['forward_calls']}** 次前向、**{replay['cost']['cache_hits']}** 次验证缓存命中；没有 backward、条件读出重拟合或 test 评估。核验成本单列，未减少原训练/搜索账本。

## 可支持的结论范围

解析参考和真实 AD/选择机制已接通，程序能够记录并选择直接解、编辑、BP 或 KEEP。是否更快需要比较完整成本；本实现的动态传播仍使用 dense matrix exponential，多 RHS SVD 的复用不能代表整个神经网络已有速度优势。

暴露池化传给 probe 的 risk 汇总为各区间首次事件概率之和除以总时长；它是每秒暴露统计，不是概率、瞬时 hazard 或全窗口首次风险。occupation feature 是区间内 active population 概率的时间平均，与房间 occupancy 标签是不同对象。

当前 value 是冻结当前有限生成元和奖励后的贴现 policy continuation，按区间末状态加权且允许负值；risk 是首次事件概率。它们不能直接等同 He–Xiong 论文的 equity call/default put。Brownian 闭式参考覆盖固定系数、固定边界及明确 reset/delay；网络采用有限空间、Erlang 不应期及区间边界投影。matrix exponential 对声明的有限过程精确，本轮没有通过原文 smooth-pasting 方程求出内生金融自由边界。

保持门仅约束指定窗口上的标准化下一传感器预测 MSE，相对未训练 KEEP 不恶化超过 0.01；它不要求逐点输出不变，也不能证明预训练知识保持。手写语义编辑方向的生成成本未测量，也不能将它称为自动权重程序已经替代全网 BP。跨架构使用资源预算区间与上限，实际状态/读出容量不同；相同参数/状态的严格配对结论只适用于四个 HCSN 消融。

LIF 使用每源区间最多一次事件的 endpoint surrogate；gated-delta 使用明确递推参考；CfC 使用官方 `ncps==1.0.1`。这里没有神经形态能耗测量、优化 GPU kernel、长期跨窗口在线适应或全模态联合训练结果。

## 所有 seed 原始摘要

stream 列为测试 MSE；adaptation 列为选中开发 next-sensor MSE。

| study | arm | seed | 对应 MSE | 完整冷进程秒 | 决策 |
|---|---|---:|---:|---:|---|
{chr(10).join(raw)}
"""
    (output / "RESULTS.md").write_text(report)
    return {"output": str(output), "rows": len(rows), "checks": verified["check_count"], "total_seconds": total}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("extracted", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(render(args.extracted, args.output)))


if __name__ == "__main__":
    main()
