import ast,hashlib,inspect,json,os,subprocess,sys,time,zipfile
from pathlib import Path
root=Path("/home/qian-qi/hcsn-flow-integration-20261122-0639")
archive=root/"incoming/validation-v1.zip"
assert hashlib.sha256(archive.read_bytes()).hexdigest()=="8fbc8b605600e9d4322db318d5d41fdc609cdba2ed18f92a0be8fa879eb1b318"
validation=root/"validation-v1"; validation.mkdir(exist_ok=False)
with zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read("MANIFEST.json"))
 for item in manifest["files"]:
  data=z.read(item["path"]); assert hashlib.sha256(data).hexdigest()==item["sha256"]
  assert "/" not in item["path"] and "\\" not in item["path"]
  (validation/item["path"]).write_bytes(data)
scripts=["validate_flow_study.py","validate_flow_details.py","replay_selected_flow.py"]
def normalized(data):
 tree=ast.parse(data)
 for node in ast.walk(tree):
  if isinstance(node,(ast.Module,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and node.body:
   first=node.body[0]
   if isinstance(first,ast.Expr) and isinstance(first.value,ast.Constant) and isinstance(first.value.value,str):
    first.value.value=inspect.cleandoc(first.value.value)
 return ast.dump(tree,include_attributes=False)
before={name:normalized((validation/name).read_bytes()) for name in scripts}
fmt=subprocess.run(["/home/qian-qi/hcsn-sixwork-tools-20261121-e29f/formatter-venv/bin/ruff","format",*scripts],cwd=validation,capture_output=True,text=True)
(validation/"formatter.stdout").write_text(fmt.stdout);(validation/"formatter.stderr").write_text(fmt.stderr)
assert fmt.returncode==0 and all(before[n]==normalized((validation/n).read_bytes()) for n in scripts)
record={"schema":"hcsn-posthoc-driver-v1","state":"waiting_for_complete_study","validator_files":{n:hashlib.sha256((validation/n).read_bytes()).hexdigest() for n in scripts},"formatter_ast_unchanged_except_docstrings":True,"jobs":[]}
receipt=validation/"DRIVER.json";receipt.write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record),flush=True)
wait_started=time.perf_counter();study=root/"studies/integration-v1";source=root/"sources/fixtures-v4"
while True:
 launch=json.loads((study/"LAUNCH.json").read_text())
 outer=json.loads((root/"evidence/studies-v1-driver.json").read_text())
 if launch["state"]!="running" and outer["state"]!="running":break
 if time.perf_counter()-wait_started>5400:raise TimeoutError("bounded wait for complete study exceeded")
 time.sleep(30)
record["waiting_seconds"]=time.perf_counter()-wait_started
record["state"]="validating";receipt.write_text(json.dumps(record,indent=2)+"\n")
execution=time.perf_counter()
for name in ["validate_flow_study.py","replay_selected_flow.py"]:
 began=time.perf_counter()
 completed=subprocess.run([sys.executable,str(validation/name),str(study),"--source-root",str(source)],cwd=source,capture_output=True,text=True,timeout=600)
 (validation/(name+".stdout")).write_text(completed.stdout);(validation/(name+".stderr")).write_text(completed.stderr)
 item={"script":name,"exit_code":completed.returncode,"cold_wall_seconds":time.perf_counter()-began,"stdout":completed.stdout,"stderr_tail":completed.stderr[-3000:]}
 record["jobs"].append(item);receipt.write_text(json.dumps(record,indent=2)+"\n");print(json.dumps(item),flush=True)
 if completed.returncode!=0:break
record.update(state="verified" if len(record["jobs"])==2 and all(p["exit_code"]==0 for p in record["jobs"]) else "verification_failed",posthoc_cold_seconds=time.perf_counter()-execution)
receipt.write_text(json.dumps(record,indent=2)+"\n")
entries=[]
def add_files(directory,prefix):
 for p in sorted(directory.rglob("*")):
  if p.is_file() and "__pycache__" not in p.parts:
   if p.is_symlink():raise ValueError("unexpected symlink")
   entries.append((p,prefix+"/"+p.relative_to(directory).as_posix()))
add_files(study,"study")
add_files(validation,"validation")
add_files(source,"source")
for name in ["fixtures-v2","fixtures-v3","fixtures-v4"]:
 path=root/"evidence"/name
 if path.is_dir():add_files(path,"fixtures/"+name)
for name in ["environment_setup.json","studies-v1-driver.json","studies-v1.stdout","studies-v1.stderr"]:
 p=root/"evidence"/name
 if p.is_file():entries.append((p,"provenance/"+name))
manifest={"schema":"hcsn-flow-complete-evidence-v1","source_commit":"abb3e5012c5f48e3cb42759785429cb1d496acb3","source_manifest_sha256":"1953148571aa943cc20ad531c2268626acd523cf57cb6adb87e700399b7e3be1","validation_state":record["state"],"files":[]}
for p,name in entries:
 data=p.read_bytes();manifest["files"].append({"path":name,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()})
target=root/"evidence/hcsn-flow-integration-v1.zip"
with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,name in entries:
  info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,p.read_bytes())
 z.writestr("MANIFEST.json",json.dumps(manifest,indent=2,allow_nan=False)+"\n")
archive_info={"path":str(target),"bytes":target.stat().st_size,"sha256":hashlib.sha256(target.read_bytes()).hexdigest(),"entries":len(entries),"validation_state":record["state"]}
(root/"evidence/integration-v1-archive.json").write_text(json.dumps(archive_info,indent=2)+"\n")
print(json.dumps(archive_info),flush=True)
raise SystemExit(0 if record["state"]=="verified" else 1)
