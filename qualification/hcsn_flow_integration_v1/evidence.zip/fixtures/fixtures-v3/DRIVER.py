Durable process stdin; exact transfer and formatter receipts are included.
