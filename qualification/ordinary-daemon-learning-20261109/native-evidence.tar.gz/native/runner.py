import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path("/home/qq/hepta-daemon-learning-a6f94-20261109")
SOURCE = ROOT / "source"
EVIDENCE = ROOT / "evidence"

def git(*args):
    return subprocess.check_output(["git", *args], cwd=SOURCE).decode()

def snapshot(label):
    names = sorted(set(git("ls-files", "--cached", "--others", "--exclude-standard", "-z").split("\0")) - {""})
    files = []
    for name in names:
        path = SOURCE / name
        if path.is_symlink():
            data = os.readlink(path).encode()
            kind = "symlink"
        elif path.is_file():
            data = path.read_bytes()
            kind = "file"
        else:
            files.append({"path": name, "kind": "absent_or_directory"})
            continue
        files.append({"path": name, "kind": kind, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    data = (json.dumps(files, sort_keys=True, separators=(",", ":")) + "\n").encode()
    file = EVIDENCE / (label + ".files.json.gz")
    file.write_bytes(gzip.compress(data, mtime=0))
    diff = git("diff", "--binary", "HEAD").encode()
    (EVIDENCE / (label + ".diff.gz")).write_bytes(gzip.compress(diff, mtime=0))
    return {
        "head": git("rev-parse", "HEAD").strip(),
        "base_tree": git("rev-parse", "HEAD^{tree}").strip(),
        "status": git("status", "--short"),
        "manifest_path": str(file),
        "manifest_sha256": hashlib.sha256(data).hexdigest(),
        "manifest_file_count": len(files),
        "tracked_diff_sha256": hashlib.sha256(diff).hexdigest(),
    }

name, *command = sys.argv[1:]
if not name or "/" in name or not command:
    raise RuntimeError("exact run name and argv required")
record_path = EVIDENCE / (name + ".json")
log_path = EVIDENCE / (name + ".log")
if record_path.exists() or log_path.exists():
    raise RuntimeError("refuse to overwrite an earlier validation attempt")
env = os.environ.copy()
env.update(json.loads((ROOT / "transfer/native-env.json").read_text()))
helper = json.loads((EVIDENCE / "helper-source-binding.json").read_text())
binary = Path(helper["pinned_executable"])
if hashlib.sha256(binary.read_bytes()).hexdigest() != helper["sha256"]:
    raise RuntimeError("helper executable changed")
original = Path("/home/qq/hepta-framework-21f10a247d16-20261109/source")
for entry in helper["source_files"]:
    relative = Path(entry["path"]).relative_to(original)
    if hashlib.sha256((SOURCE / relative).read_bytes()).hexdigest() != entry["sha256"]:
        raise RuntimeError("helper source changed: " + str(relative))
before = snapshot(name + ".before")
record = {
    "name": name, "command": command, "cwd": str(SOURCE),
    "source_before": before, "started_unix_seconds": time.time(),
    "environment": {key: env[key] for key in json.loads((ROOT / "transfer/native-env.json").read_text())},
    "helper_sha256": helper["sha256"], "helper_source_files_verified": len(helper["source_files"]),
}
record_path.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"started": name, "command": command, "source_manifest_sha256": before["manifest_sha256"], "log": str(log_path)}), flush=True)
with log_path.open("wb") as log:
    result = subprocess.run(command, cwd=SOURCE, env=env, stdout=log, stderr=subprocess.STDOUT)
after = snapshot(name + ".after")
data = log_path.read_bytes()
record.update({
    "source_after": after, "source_unchanged": before["manifest_sha256"] == after["manifest_sha256"],
    "exit_code": result.returncode, "elapsed_seconds": time.time() - record["started_unix_seconds"],
    "raw_log_sha256": hashlib.sha256(data).hexdigest(), "raw_log_bytes": len(data),
})
log_path.with_suffix(".log.gz").write_bytes(gzip.compress(data, mtime=0))
junit = Path(env["CARGO_TARGET_DIR"]) / "nextest/local/junit.xml"
if junit.is_file() and junit.stat().st_mtime >= record["started_unix_seconds"]:
    saved = EVIDENCE / (name + ".junit.xml")
    shutil.copyfile(junit, saved)
    record["junit"] = {"path": str(saved), "sha256": hashlib.sha256(saved.read_bytes()).hexdigest()}
record_path.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"finished": name, "exit_code": result.returncode, "elapsed_seconds": record["elapsed_seconds"], "source_unchanged": record["source_unchanged"], "log_sha256": record["raw_log_sha256"]}), flush=True)
print(data.decode(errors="replace")[-12000:], flush=True)
sys.exit(result.returncode)
