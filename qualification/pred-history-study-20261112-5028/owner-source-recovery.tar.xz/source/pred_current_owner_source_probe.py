"""One current, bounded, read-only TaskFlow source observation on Linux."""

import json
import os
from pathlib import Path
import signal
import sqlite3
import time

signal.alarm(25)
started = time.monotonic()
keys = ("HEPTA_FLEET_ROOT", "HEPTA_AGENT_ID", "HEPTA_AGENT_GENERATION",
        "HEPTA_AGENT_HOME", "HEPTA_AGENT_RUN_ROOT")


def read_bytes(path, limit):
    with Path(path).open("rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError("bounded read exceeded")
    return data


def start_identity(proc):
    return read_bytes(proc / "stat", 4096).decode().rsplit(")", 1)[1].split()[19]


boot = read_bytes("/proc/sys/kernel/random/boot_id", 128).decode().strip()
entries = []
for entry in Path("/proc").iterdir():
    if entry.name.isdigit():
        entries.append(entry)
    if len(entries) > 8192:
        break
names, owners, failures = [], [], []
same_uid = 0
for proc in entries[:8192]:
    if time.monotonic() - started > 15:
        failures.append({"stage": "process_names", "reason": "time_budget"})
        break
    try:
        if proc.stat().st_uid != os.getuid():
            continue
        same_uid += 1
        name = read_bytes(proc / "comm", 128).decode().strip()
        if not (name.startswith("hepta") or name == "agentd"):
            continue
        identity = start_identity(proc)
        names.append({"pid": int(proc.name), "name": name, "start_ticks": identity})
        if name not in ("hepta-agentd", "agentd") or len(owners) >= 16:
            continue
        raw = read_bytes(proc / "environ", 1048576)
        selected = {}
        for part in raw.split(b"\0"):
            name_bytes, sep, value = part.partition(b"=")
            if sep and name_bytes.decode(errors="replace") in keys:
                selected[name_bytes.decode()] = value.decode()
        row = {"pid": int(proc.name), "start_ticks": identity,
               "required_keys_present": {key: key in selected for key in keys},
               "source_contract": "current_process_exact_environment_keys",
               "owner_source_fields": selected}
        if proc.stat().st_uid != os.getuid() or start_identity(proc) != identity:
            failures.append({"pid": int(proc.name), "reason": "process_identity_changed"})
            continue
        root, agent_id = selected.get("HEPTA_FLEET_ROOT"), selected.get("HEPTA_AGENT_ID")
        if root and Path(root).is_absolute() and agent_id and len(agent_id) <= 256 and "/" not in agent_id and agent_id not in (".", ".."):
            fleet = Path(root)
            home = fleet / "agents" / agent_id
            row["layout_presence"] = {name: path.is_file() for name, path in (
                ("fleet_registry", fleet / "fleet.toml"), ("agent_manifest", home / "agent.toml"),
                ("generation", home / "run/generation.json"),
                ("automation_database", home / "automation/automation_1.sqlite3"))}
            path = home / "automation/automation_1.sqlite3"
            if path.is_file() and time.monotonic() - started < 19:
                row["database"] = {"path": str(path), "wal_present": Path(str(path) + "-wal").is_file()}
                try:
                    with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True, timeout=1) as db:
                        db.execute("PRAGMA query_only=ON")
                        db.set_progress_handler(lambda: int(time.monotonic() - started > 22), 1000)
                        db.execute("BEGIN")
                        row["database"]["journal_mode"] = db.execute("PRAGMA journal_mode").fetchone()[0]
                        tables = {}
                        for suffix in ("attempts", "observations", "reconciliations"):
                            table = "taskflow_effect_dispatch_" + suffix
                            present = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None
                            item = {"present": present}
                            if present:
                                item["columns"] = [r[1] for r in db.execute("PRAGMA table_info(" + table + ")")]
                                count = db.execute("SELECT count(*) FROM (SELECT 1 FROM " + table + " LIMIT 1025)").fetchone()[0]
                                item.update(row_count_bounded=count, count_is_lower_bound=count == 1025)
                            tables[table] = item
                        db.rollback()
                        row["database"]["tables"] = tables
                        row["database"]["readonly_transaction_completed"] = True
                except (sqlite3.Error, OSError, ValueError) as exc:
                    row["database"]["read_error_type"] = type(exc).__name__
        row["same_start_identity_after_read"] = start_identity(proc) == identity
        owners.append(row)
    except (OSError, ValueError, UnicodeError) as exc:
        failures.append({"pid": int(proc.name), "error_type": type(exc).__name__})
result = {
    "schema": "pred-current-owner-source-probe-v1", "boot_id": boot,
    "observed_monotonic_start": started, "observed_monotonic_end": time.monotonic(),
    "process_entries_seen": len(entries), "process_entries_truncated": len(entries) > 8192,
    "same_uid_entries_examined": same_uid, "hepta_name_matches": names,
    "agentd_candidates": owners, "errors": failures,
    "scope": "current same-UID process names, then exact required agentd environment keys and derived owner paths only; no argv, secret environment values, broad home scan or owner creation",
    "snapshot_atomic": False, "native_provenance_authenticated": False,
    "arrival_sequencer_established": False, "independent_effect_observer_established": False,
    "business_actions_executed": 0, "owner_database_writes": 0,
    "historical_unknown_replayed": False,
}
print(json.dumps(result, sort_keys=True), flush=True)
