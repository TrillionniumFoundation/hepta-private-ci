"""Isolated PFT research namespace; never import a live checkout by accident."""
