"""Create-exclusive v2 admission from the unused v1 and verified publication."""
import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).parent
OLD = ROOT.parent / 'analytic_ssh_run'
REPOSITORY = ROOT.parent / 'analytic_network'
SOURCE = REPOSITORY / 'qualification/pft_six_experiments_20261125'
COMMIT = '6e4af27a18b9dd2252713623bff07bdce1ef2cba'
TREE = '835727e6aebde67c52fe8a54e2c273747b214c4f'
ROUND = 'pft-direct-ssh-20261125-7c9e-v2'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def write(name, value):
    raw = (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()
    with (ROOT / name).open('xb') as stream:
        stream.write(raw)
    return digest(raw)


old_raw = (OLD / 'REGISTRATION.json').read_bytes()
assert digest(old_raw) == '9f3aa9909041273f3986a24267fddd6b2c8e19d34a73cdb8c6d26c5bdae73808'
withdrawal_raw = (OLD / 'WITHDRAWN_BEFORE_EXECUTION.json').read_bytes()
assert digest(withdrawal_raw) == '8ceb986c230cb0d148ef5ac1b05e17d5b3d85e9d1b02828b7176813d16840cbd'
old = json.loads(old_raw)
readback_raw = (ROOT / 'PUBLICATION_READBACK.json').read_bytes()
readback = json.loads(readback_raw)
assert (readback['commit'], readback['tree'], readback['parents']) == (COMMIT, TREE, ['6798955fd7e4553cd57057b018344af07a83b579'])
manifest_raw = (ROOT / 'PUBLICATION_MANIFEST.json').read_bytes()
assert digest(manifest_raw) == 'da102a21b9e162e542c426909e41bcfb470d7880b7b171916bebbcb9c9742741'
manifest = json.loads(manifest_raw)
blobs = {item['path']: item['blob'] for item in readback['files']}
for item in manifest['files']:
    raw = (REPOSITORY / item['path']).read_bytes()
    blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    assert digest(raw) == item['sha256'] and blob == item['git_blob_sha1'] == blobs[item['path']]

sys.path.insert(0, str(SOURCE))
import ssh_snapshot

assert ssh_snapshot.SCHEMA == 'pft-direct-ssh-frozen-snapshot-v2'
sources = {name: digest((SOURCE / name).read_bytes()) for name in ssh_snapshot.SOURCES}
for name in ('direct_snapshot.py', 'distributed.py', 'transport.py'):
    assert sources[name] == old['source_sha256'][name]
roster = copy.deepcopy(old['roster'])
for peer in roster:
    peer['stage'] = str(Path(peer['stage']).parent / ROUND)
configs = {}
for node, host in enumerate(('pocket4', 'ai395')):
    raw = (OLD / (host + '-config.json')).read_bytes()
    assert digest(raw) == old['config_sha256'][host]
    config = json.loads(raw)
    config.update(schema=ssh_snapshot.SCHEMA, source_sha256=sources, roster=roster)
    config['frozen'].update(round_id=ROUND, archive=roster[node]['stage'] + '/original-statistics.json.zlib',
                            output=roster[node]['stage'] + '/run')
    config['reference'] = roster[node]['stage'] + '/central-reference.json'
    config.pop('remote_config_sha256', None)
    config['context_id'] = ssh_snapshot.context(config)
    configs[host] = config
assert configs['pocket4']['context_id'] == configs['ai395']['context_id']
config_sha = {'ai395': write('ai395-config.json', configs['ai395'])}
configs['pocket4']['remote_config_sha256'] = config_sha['ai395']
config_sha['pocket4'] = write('pocket4-config.json', configs['pocket4'])
helpers = {name: digest((ROOT / name).read_bytes()) for name in ('deploy_template.py', 'preflight_template.py', 'execute_template.py', 'collect_template.py')}
control_reports = {name: digest((ROOT / name).read_bytes()) for name in ('LOCAL_CONTROLS.json', 'ORCHESTRATION_TARGETED_CONTROLS.json', 'ORCHESTRATION_FINAL_GROUP_CONTROLS.json')}
registration = copy.deepcopy(old)
registration.update(schema='pft-direct-ssh-engineering-admission-v2', round_id=ROUND,
                    source_commit=COMMIT, source_tree=TREE, source_sha256=sources,
                    publication_manifest_sha256=digest(manifest_raw),
                    publication_readback_sha256=digest(readback_raw),
                    context_id=configs['pocket4']['context_id'], config_sha256=config_sha,
                    roster=roster, orchestration_helper_sha256=helpers,
                    local_control_report_sha256=control_reports)
registration['prior_unused_ssh_admission'] = {
    'registration_sha256': digest(old_raw), 'source_commit': '6798955fd7e4553cd57057b018344af07a83b579',
    'withdrawal_sha256': digest(withdrawal_raw), 'deployments': 0, 'application_rounds': 0,
    'state': 'WITHDRAWN_BEFORE_EXECUTION',
    'reason': 'Inner owner could reap the SSH leader before its final group signal; v2 holds WNOWAIT ownership until the final signal and unique reap',
    'permission_to_execute_v1': False}
registration['budgets']['maximum_ssh_application_rounds_across_v1_and_v2'] = 1
registration['budgets']['outer_cleanup_reserve_seconds_within_55'] = 9
registration['budgets']['prior_unused_ssh_round_transferred_not_added'] = True
registration['execution']['inner_process_ownership'] = 'Linux WNOWAIT until last group signal, then unique reap'
registration['execution']['outer_nested_group_ownership'] = 'Original application stopped and unreaped; captured SSH remains its direct child until final nested-group signal'
registration['execution']['terminal_collection'] = 'Authoritative durable native terminal state plus original process termination and completed owned-group cleanup; UNKNOWN never consumes final bundle'
registration_sha = write('REGISTRATION.json', registration)
publication = {
    'schema': 'pft-ssh-source-publication-v2', 'repository': readback['repository'], 'pr': 7085,
    'commit': COMMIT, 'tree': TREE, 'parents': readback['parents'],
    'registration_sha256': registration_sha, 'publication_manifest_sha256': digest(manifest_raw),
    'publication_readback_sha256': digest(readback_raw), 'source_sha256': sources,
    'method': readback['method'], 'publication_retry_authorized': False}
publication_sha = write('SOURCE_PUBLICATION.json', publication)
orchestration = {
    'schema': 'pft-ssh-orchestration-v2', 'registration_sha256': registration_sha,
    'source_publication_sha256': publication_sha, 'source_commit': COMMIT, 'source_tree': TREE,
    'helper_sha256': helpers, 'test_source_sha256': digest((ROOT / 'test_orchestration.py').read_bytes()),
    'local_control_report_sha256': control_reports,
    'prior_v1_orchestration_sha256': digest((OLD / 'ORCHESTRATION.json').read_bytes()),
    'application_rounds': 1, 'maximum_ssh_rounds_including_withdrawn_v1': 1,
    'outer_execution_deadline_seconds': 55, 'outer_cleanup_reserve_seconds': 9,
    'inner_delivery_deadline_seconds': 45, 'inner_reap_seconds': 4, 'inner_diagnostic_join_seconds': .1,
    'deploy_source': 'exact published file bytes with SHA256 validation',
    'statistics_source': 'each host copies only its own previous original archive',
    'preflight_network_connections': 0, 'controller_data_relay': False,
    'responder_start': 'fixed remote entry via the peer native SSH channel only',
    'collection': 'after authoritative native terminal and original process/cleanup proof, before any ledger read; create-exclusive bundle',
    'new_firewall_routes_or_credentials': False, 'scientific_panel_runs': 0,
    'lost_ownership_action': 'UNKNOWN with original artifacts retained; no stale numeric PID/PGID signal'}
orchestration_sha = write('ORCHESTRATION.json', orchestration)
print(json.dumps({'registration_sha256': registration_sha, 'source_publication_sha256': publication_sha,
                  'orchestration_sha256': orchestration_sha, 'config_sha256': config_sha,
                  'context_id': configs['pocket4']['context_id'], 'helper_sha256': helpers}, sort_keys=True))
