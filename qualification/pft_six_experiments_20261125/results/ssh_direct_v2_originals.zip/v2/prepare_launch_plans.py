"""Freeze exact stable-key control-plane requests; no host operation is issued."""
import base64
import hashlib
import json
from pathlib import Path
import shlex
import zlib

ROOT = Path(__file__).parent
SOURCE = ROOT.parent / 'analytic_network/qualification/pft_six_experiments_20261125'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def write(name, value):
    raw = (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()
    with (ROOT / name).open('xb') as output:
        output.write(raw)
    return digest(raw)


def command(executable, code):
    assert '\nHEPTA_FIXED_OPERATOR\n' not in code
    return shlex.quote(executable) + " -u - <<'HEPTA_FIXED_OPERATOR'\n" + code + '\nHEPTA_FIXED_OPERATOR\n'


registration_raw = (ROOT / 'REGISTRATION.json').read_bytes()
registration_sha = digest(registration_raw)
registration = json.loads(registration_raw)
publication_raw = (ROOT / 'SOURCE_PUBLICATION.json').read_bytes()
publication = json.loads(publication_raw)
assert publication['registration_sha256'] == registration_sha
orchestration_raw = (ROOT / 'ORCHESTRATION.json').read_bytes()
orchestration_sha = digest(orchestration_raw)
orchestration = json.loads(orchestration_raw)
assert orchestration['registration_sha256'] == registration_sha
assert orchestration['source_publication_sha256'] == digest(publication_raw)
templates = {}
for name, expected in orchestration['helper_sha256'].items():
    raw = (ROOT / name).read_bytes()
    assert digest(raw) == expected == registration['orchestration_helper_sha256'][name]
    templates[name] = raw.decode()
sources = {}
for name, expected in registration['source_sha256'].items():
    raw = (SOURCE / name).read_bytes()
    assert digest(raw) == expected
    sources[name] = raw.decode()
reference_raw = (SOURCE / 'results/pft2_multihost.json').read_bytes()
assert digest(reference_raw) == registration['candidate']['reference_artifact_sha256']
plans = {}
for peer in registration['roster']:
    host = peer['alias']
    config_raw = (ROOT / (host + '-config.json')).read_bytes()
    config_sha = digest(config_raw)
    assert config_sha == registration['config_sha256'][host]
    old_stage = str(Path(peer['stage']).parent / 'pft-direct-usb4-20261125-7c9e-v1')
    payload = {'sources': sources, 'config': config_raw.decode(), 'config_sha256': config_sha,
               'reference': reference_raw.decode(), 'own_existing_archive': old_stage + '/original-statistics.json.zlib',
               'REGISTRATION.json': registration_raw.decode(), 'SOURCE_PUBLICATION.json': publication_raw.decode(),
               'source_commit': registration['source_commit'], 'registration_sha256': registration_sha}
    encoded = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()
    prefix = 'PAYLOAD_BASE64 = ' + repr(base64.b64encode(zlib.compress(encoded, 9)).decode()) + '\nPAYLOAD_SHA256 = ' + repr(digest(encoded)) + '\n'
    deploy = command('/usr/bin/python3', prefix + templates['deploy_template.py'])
    values = {'STAGE': peer['stage'], 'EXPECTED_CONFIG': config_sha, 'SOURCE_COMMIT': registration['source_commit'],
              'REGISTRATION_SHA256': registration_sha, 'OLD_STAGE': old_stage}
    prefix = ''.join(name + ' = ' + repr(value) + '\n' for name, value in values.items())
    preflight = command(peer['python'], prefix + templates['preflight_template.py'])
    requests = [('deploy', deploy, 120), ('preflight', preflight, 15)]
    if host == 'pocket4':
        values.update(EXECUTABLE=peer['python'], ORCHESTRATION_SHA256=orchestration_sha)
        prefix = ''.join(name + ' = ' + repr(value) + '\n' for name, value in values.items())
        requests.append(('execute', command(peer['python'], prefix + templates['execute_template.py']), 65))
    for kind, shell, timeout in requests:
        params = {'host': host, 'command': shell, 'shell': '/bin/sh', 'timeout_seconds': timeout,
                  'idempotency_key': 'pft-ssh-v2-' + kind + '-' + host + '-7c9e-' + registration_sha[:12]}
        plan = {'schema': 'pft-ssh-control-plane-plan-v2', 'kind': kind, 'registration_sha256': registration_sha,
                'source_commit': registration['source_commit'], 'orchestration_sha256': orchestration_sha,
                'command_sha256': digest(shell.encode()), 'params': params,
                'application_rounds_started': 1 if kind == 'execute' else 0,
                'unknown_launch_action': 'recover only the same idempotency key; never resubmit under a new key'}
        name = host + '-' + kind + '-plan.json'
        plans[name] = {'sha256': write(name, plan), 'command_sha256': plan['command_sha256'], 'key': params['idempotency_key']}
print(json.dumps({'plans': plans, 'host_operations_issued': 0}, sort_keys=True))
