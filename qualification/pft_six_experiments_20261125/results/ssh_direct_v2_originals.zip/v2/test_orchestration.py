"""Local process fixtures only; these controls never connect to an SSH host."""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock
import zlib

ROOT = Path(__file__).parent


def module(name):
    spec = importlib.util.spec_from_file_location('local_' + name, ROOT / (name + '_template.py'))
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


class OrchestrationControls(unittest.TestCase):
    def test_outer_freezes_original_parent_before_signalling_nested_session(self):
        self.exercise_stopped_owner(False)

    def test_failed_continue_still_kills_and_reaps_our_reserved_app(self):
        self.exercise_stopped_owner(True)

    def exercise_stopped_owner(self, fail_continue):
        owner = module('execute')
        with tempfile.TemporaryDirectory() as temporary:
            stage = Path(temporary)
            (stage / 'run').mkdir()
            nested_argv = [sys.executable, '-c', 'import signal,time;signal.signal(signal.SIGINT,signal.SIG_IGN);signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(8)']
            code = ('import json,pathlib,signal,subprocess,time;'
                    'signal.signal(signal.SIGINT,signal.SIG_IGN);'
                    'child=subprocess.Popen(' + repr(nested_argv) + ',start_new_session=True);'
                    'pathlib.Path(' + repr(str(stage / 'run/SSH_CHILD.json')) + ').write_text(json.dumps({"pid":child.pid,"owned_process_group":child.pid}));'
                    'print("ready",flush=True);time.sleep(8)')
            process = subprocess.Popen([sys.executable, '-c', code], stdout=subprocess.PIPE, start_new_session=True)
            original = owner.process_stamp(process.pid)
            captured = {}
            real_signal, real_kill = os.killpg, os.kill
            checked_nested = []
            try:
                with selectors.DefaultSelector() as selector:
                    selector.register(process.stdout, selectors.EVENT_READ)
                    self.assertTrue(selector.select(timeout=2))
                self.assertEqual(process.stdout.readline(), b'ready\n')
                owner.observe_ssh(process, original, stage, nested_argv, captured)
                self.assertEqual(len(captured), 1)
                nested_pid = next(iter(captured))
                def checked_signal(group, signum):
                    self.assertIsNone(process.returncode)
                    owner.exit_without_reaping(process)
                    if group == nested_pid:
                        app_now = owner.process_stamp(process.pid)
                        child_now = owner.process_stamp(nested_pid)
                        self.assertIn(app_now['state'], ('T', 't'))
                        self.assertEqual(child_now['ppid'], process.pid)
                        self.assertTrue(owner.same_process(captured[nested_pid], child_now))
                        stopped = os.waitid(os.P_PID, process.pid, os.WSTOPPED | os.WNOHANG | os.WNOWAIT)
                        self.assertEqual(stopped.si_code, os.CLD_STOPPED)
                        checked_nested.append(signum)
                    return real_signal(group, signum)
                def controlled_kill(pid, signum):
                    if fail_continue and signum == signal.SIGCONT:
                        raise OSError('controlled SIGCONT failure')
                    return real_kill(pid, signum)
                began = time.monotonic()
                with mock.patch.object(os, 'killpg', checked_signal), mock.patch.object(os, 'kill', controlled_kill), mock.patch.object(process, 'wait', wraps=process.wait) as reap:
                    result = owner.cleanup_owned(process, original, stage, nested_argv, captured, began + 8)
                    self.assertEqual(reap.call_count, 1)
                self.assertEqual(result['state'], 'UNKNOWN' if fail_continue else 'TERMINAL', result)
                self.assertEqual(checked_nested, [signal.SIGKILL])
                self.assertEqual(process.returncode, -signal.SIGKILL)
                self.assertLess(time.monotonic() - began, 8)
                with self.assertRaises(ChildProcessError):
                    os.waitid(os.P_PID, process.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
            finally:
                if process.returncode is None:
                    owner.cleanup_owned(process, original, stage, nested_argv, captured, time.monotonic() + 9)
                process.stdout.close()

    def test_uncaptured_exited_ssh_leader_requires_inner_reap_proof(self):
        self.exercise_exited_leader(False)

    def test_captured_exited_ssh_leader_requires_inner_or_outer_group_proof(self):
        self.exercise_exited_leader(True)

    def exercise_exited_leader(self, capture):
        owner = module('execute')
        with tempfile.TemporaryDirectory() as temporary:
            stage = Path(temporary)
            (stage / 'run').mkdir()
            nested_code = 'import os,time;child=os.fork();print(child,flush=True) if child else time.sleep(.6);time.sleep(.2) if child else None;os._exit(0)'
            nested_argv = [sys.executable, '-c', nested_code]
            code = ('import json,pathlib,subprocess;'
                    'child=subprocess.Popen(' + repr(nested_argv) + ',stdout=subprocess.PIPE,start_new_session=True);'
                    'descendant=int(child.stdout.readline());'
                    'pathlib.Path(' + repr(str(stage / 'run/SSH_CHILD.json')) + ').write_text(json.dumps({"pid":child.pid,"owned_process_group":child.pid}));'
                    'print(descendant,flush=True);child.wait()')
            process = subprocess.Popen([sys.executable, '-c', code], stdout=subprocess.PIPE, start_new_session=True)
            original = owner.process_stamp(process.pid)
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ)
                self.assertTrue(selector.select(timeout=2))
            descendant = int(process.stdout.readline())
            captured = {}
            if capture:
                owner.observe_ssh(process, original, stage, nested_argv, captured)
                self.assertEqual(len(captured), 1)
            while owner.exit_without_reaping(process) is None:
                time.sleep(.005)
            stale_ssh_pid = json.loads((stage / 'run/SSH_CHILD.json').read_bytes())['pid']
            real_signal, groups = os.killpg, []
            def checked_signal(group, signum):
                groups.append(group)
                self.assertNotEqual(group, stale_ssh_pid)
                return real_signal(group, signum)
            with mock.patch.object(os, 'killpg', checked_signal):
                result = owner.cleanup_owned(process, original, stage, nested_argv, captured, time.monotonic() + 4, 'c' * 64)
            self.assertEqual(result['state'], 'UNKNOWN')
            self.assertEqual(groups, [process.pid])
            self.assertTrue(any('inner owner' in error['message'] for error in result['errors']))
            until = time.monotonic() + .6
            while time.monotonic() < until:
                child = owner.process_stamp(descendant)
                if child is None or child['state'] in ('Z', 'X'):
                    break
                time.sleep(.01)
            child = owner.process_stamp(descendant)
            self.assertTrue(child is None or child['state'] in ('Z', 'X'))
            process.stdout.close()

    def test_successful_outer_leader_remains_reserved_until_final_group_signal(self):
        owner = module('execute')
        with tempfile.TemporaryDirectory() as temporary:
            process = subprocess.Popen([sys.executable, '-c', 'pass'], start_new_session=True)
            original = owner.process_stamp(process.pid)
            while owner.exit_without_reaping(process) is None:
                time.sleep(.005)
            real_signal, observed = os.killpg, []
            def checked_signal(group, signum):
                self.assertIsNone(process.returncode)
                self.assertEqual(owner.exit_without_reaping(process), 0)
                observed.append((group, signum))
                return real_signal(group, signum)
            with mock.patch.object(os, 'killpg', checked_signal), mock.patch.object(process, 'wait', wraps=process.wait) as reap:
                result = owner.cleanup_owned(process, original, Path(temporary), [], {}, time.monotonic() + 4)
                self.assertEqual(reap.call_count, 1)
            self.assertEqual(result['state'], 'TERMINAL')
            self.assertEqual(observed, [(process.pid, signal.SIGKILL)])
            self.assertEqual(process.returncode, 0)

    def collector_fixture(self, stage, pid):
        collector = module('collect')
        (stage / 'run').mkdir()
        boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        config = {'frozen': {'node': 1}, 'context_id': 'e' * 64,
                  'roster': [{}, {'boot': boot, 'python': sys.executable, 'hostname': os.uname().nodename, 'uid': os.getuid()}]}
        raw = json.dumps(config).encode()
        (stage / 'SSH_CONFIG.json').write_bytes(raw)
        digest = hashlib.sha256(raw).hexdigest()
        start = {'pid': pid, 'boot': boot, 'config_sha256': digest, 'node': 1,
                 'hostname': os.uname().nodename, 'uid': os.getuid(), 'executable': sys.executable,
                 'context_id': config['context_id']}
        (stage / 'run/STARTED.json').write_text(json.dumps(start))
        collector.STAGE, collector.EXPECTED_CONFIG, collector.HOST = str(stage), digest, 'local-fixture-only'
        collector.SOURCE_COMMIT, collector.REGISTRATION_SHA256 = 'a' * 40, 'b' * 64
        collector.INITIATOR_GATE = {'native_status': {'output_complete': True, 'output_durable': True,
                                                     'terminal_publication_confirmed': True, 'state': 'failed', 'exit_code': 1},
                                    'source_commit': collector.SOURCE_COMMIT, 'registration_sha256': collector.REGISTRATION_SHA256,
                                    'execution': {'cleanup': {'state': 'TERMINAL'}, 'exit_code': 1}}
        return collector, start

    def test_collector_refuses_live_or_unknown_original_before_consuming_bundle(self):
        with tempfile.TemporaryDirectory() as temporary:
            stage = Path(temporary)
            collector, start = self.collector_fixture(stage, os.getpid())
            (stage / 'run/END.json').write_text(json.dumps({**start, 'status': 'COMPLETE'}))
            (stage / 'run/ledger.json').write_text('must not be read before the terminal gate')
            original_read = Path.read_bytes
            def guarded_read(path):
                if path == stage / 'run/ledger.json':
                    raise AssertionError('Live collector read the ledger before terminal proof')
                return original_read(path)
            with mock.patch.object(Path, 'read_bytes', guarded_read), self.assertRaises(RuntimeError):
                collector.collect()
            self.assertFalse((stage / 'EVIDENCE.json.zlib').exists())
            collector.INITIATOR_GATE['execution']['cleanup']['state'] = 'UNKNOWN'
            with self.assertRaises(RuntimeError):
                collector.collect()
            self.assertFalse((stage / 'EVIDENCE.json.zlib').exists())

    def test_confirmed_dead_partial_failure_is_retained_without_a_success_claim(self):
        process = subprocess.Popen([sys.executable, '-c', 'raise SystemExit(1)'])
        process.wait(timeout=2)
        with tempfile.TemporaryDirectory() as temporary:
            stage = Path(temporary)
            collector, _ = self.collector_fixture(stage, process.pid)
            with contextlib.redirect_stdout(io.StringIO()):
                collector.collect()
            raw = (stage / 'EVIDENCE.json.zlib').read_bytes()
            evidence = json.loads(zlib.decompress(raw))
            self.assertEqual(evidence['local_terminal_status'], 'MISSING_END_CONFIRMED_PROCESS_DEAD')
            self.assertEqual(evidence['process_observation']['reason'], 'original_pid_absent')
            self.assertIn('run/STARTED.json', evidence['files'])
            with self.assertRaises(FileExistsError), contextlib.redirect_stdout(io.StringIO()):
                collector.collect()
            self.assertEqual((stage / 'EVIDENCE.json.zlib').read_bytes(), raw)


if __name__ == '__main__':
    unittest.main()
