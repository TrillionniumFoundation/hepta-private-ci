import base64
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import zlib

started = time.monotonic()
raw = zlib.decompress(base64.b64decode(PAYLOAD_BASE64))
assert hashlib.sha256(raw).hexdigest() == PAYLOAD_SHA256
payload = json.loads(raw)
config_raw = payload['config'].encode()
assert hashlib.sha256(config_raw).hexdigest() == payload['config_sha256']
config = json.loads(config_raw)
node = config['frozen']['node']
stage = Path(config['roster'][node]['stage'])
stage.mkdir(mode=0o700)
failure = None
try:
    assert set(payload['sources']) == set(config['source_sha256'])
    for name, content in payload['sources'].items():
        encoded = content.encode()
        assert hashlib.sha256(encoded).hexdigest() == config['source_sha256'][name]
        with (stage / name).open('xb') as output:
            output.write(encoded)
    with (stage / 'SSH_CONFIG.json').open('xb') as output:
        output.write(config_raw)
    reference = payload['reference'].encode()
    assert hashlib.sha256(reference).hexdigest() == config['reference_sha256']
    with (stage / 'central-reference.json').open('xb') as output:
        output.write(reference)
    original = Path(payload['own_existing_archive']).read_bytes()
    assert len(original) <= 1_000_000
    assert hashlib.sha256(original).hexdigest() == config['frozen']['archive_sha256']
    assert config['frozen']['archive'] == str(stage / 'original-statistics.json.zlib')
    with (stage / 'original-statistics.json.zlib').open('xb') as output:
        output.write(original)
    for name in ('REGISTRATION.json', 'SOURCE_PUBLICATION.json'):
        with (stage / name).open('x') as output:
            output.write(payload[name])
except BaseException as error:
    failure = {'type': type(error).__name__, 'message': str(error)[:500]}
    raise
finally:
    result = {'schema': 'pft-ssh-deployment-v1', 'status': 'FAILED' if failure else 'COMPLETE',
              'error': failure, 'pid': os.getpid(), 'python': sys.version, 'executable': sys.executable,
              'wall_seconds': time.monotonic() - started, 'source_commit': payload['source_commit'],
              'registration_sha256': payload['registration_sha256'],
              'config_sha256': payload['config_sha256'], 'source_sha256': config['source_sha256'],
              'archive_sha256': config['frozen']['archive_sha256'],
              'archive_source': payload['own_existing_archive'], 'peer_archive_received_from_controller': False,
              'application_started': False}
    with (stage / 'DEPLOYMENT.json').open('x') as output:
        json.dump(result, output, sort_keys=True)
    print(json.dumps(result), flush=True)
