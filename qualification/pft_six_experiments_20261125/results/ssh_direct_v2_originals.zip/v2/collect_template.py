"""Collect immutable originals only after the admitted processes are terminal."""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import time
import zlib


def original_application_terminal(stage, config, started):
    current_boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    expected = config['roster'][config['frozen']['node']]
    if (type(started.get('pid')) is not int or started['pid'] <= 0 or started['boot'] != expected['boot']
            or started['config_sha256'] != EXPECTED_CONFIG or started['node'] != config['frozen']['node']
            or started['hostname'] != expected['hostname'] or started['uid'] != expected['uid']
            or started['executable'] != expected['python'] or started['context_id'] != config['context_id']):
        raise ValueError('The retained application identity differs from admission')
    if current_boot != started['boot']:
        return {'pid': started['pid'], 'terminal': True, 'reason': 'original_boot_ended', 'current_boot': current_boot}
    folder = Path('/proc') / str(started['pid'])
    try:
        fields = (folder / 'stat').read_text().rsplit(') ', 1)[1].split()
        raw_command = (folder / 'cmdline').read_bytes()
    except FileNotFoundError:
        return {'pid': started['pid'], 'terminal': True, 'reason': 'original_pid_absent', 'current_boot': current_boot}
    if fields[0] in ('Z', 'X'):
        return {'pid': started['pid'], 'terminal': True, 'reason': 'original_process_not_executing', 'state': fields[0]}
    command = [expected['python'], str(stage / 'ssh_snapshot.py'), str(stage / 'SSH_CONFIG.json'), '--expected', EXPECTED_CONFIG]
    encoded = b'\0'.join(os.fsencode(value) for value in command) + b'\0'
    if raw_command != encoded:
        raise RuntimeError('A live PID has a different command; original identity is uncertain and no final bundle is permitted')
    raise RuntimeError('Original application is still active; no final evidence bundle may be created')


def collect():
    started_time = time.monotonic()
    stage = Path(STAGE)
    gate = INITIATOR_GATE
    native = gate['native_status']
    if not (native['output_complete'] and native['output_durable'] and native['terminal_publication_confirmed']
            and native['state'] in ('succeeded', 'failed') and native['exit_code'] is not None):
        raise RuntimeError('Initiator launch has no authoritative durable terminal status')
    if gate['source_commit'] != SOURCE_COMMIT or gate['registration_sha256'] != REGISTRATION_SHA256:
        raise ValueError('Initiator terminal receipt belongs to another admission')
    execution = gate['execution']
    if execution['cleanup']['state'] != 'TERMINAL' or execution['exit_code'] is None:
        raise RuntimeError('Initiator retains unknown owned processes; final collection is forbidden')
    config_raw = (stage / 'SSH_CONFIG.json').read_bytes()
    if hashlib.sha256(config_raw).hexdigest() != EXPECTED_CONFIG:
        raise ValueError('Collector configuration differs from admission')
    config = json.loads(config_raw)
    start_path, end_path = stage / 'run/STARTED.json', stage / 'run/END.json'
    if not start_path.exists():
        raise RuntimeError('No original application PID identity; retain partial files without consuming the final bundle')
    start_raw = start_path.read_bytes()
    original_start = json.loads(start_raw)
    end_raw = end_path.read_bytes() if end_path.exists() else None
    original_end = json.loads(end_raw) if end_raw is not None else None
    if original_end is not None and any(original_end[key] != original_start[key] for key in ('pid', 'boot', 'config_sha256')):
        raise ValueError('Application END differs from its original STARTED identity')
    observation = original_application_terminal(stage, config, original_start)
    if config['frozen']['node'] == 0:
        execution_raw = (stage / 'EXECUTION_RESULT.json').read_bytes()
        if hashlib.sha256(execution_raw).hexdigest() != gate['execution_result_sha256']:
            raise ValueError('Local initiator execution differs from the terminal gate')
        # The outer owner captured these identities while the original parent
        # was alive. No new identity is created from a stale numeric PID here.
        for original in execution['owned_ssh_processes']:
            folder = Path('/proc') / str(original['pid'])
            try:
                fields = (folder / 'stat').read_text().rsplit(') ', 1)[1].split()
                raw_command = (folder / 'cmdline').read_bytes()
            except FileNotFoundError:
                continue
            same = (int(fields[19]) == original['start_ticks'] and int(fields[2]) == original['pgid']
                    and int(fields[3]) == original['sid'])
            if same and fields[0] not in ('Z', 'X'):
                raise RuntimeError('Originally owned SSH process still active; do not consume final evidence')
    # Only after all process gates pass do we read and package the retained
    # application frames, ledgers and candidate. Running/unknown attempts never
    # create the exclusive EVIDENCE file.
    names = ['SSH_CONFIG.json', 'REGISTRATION.json', 'SOURCE_PUBLICATION.json', 'DEPLOYMENT.json',
             'PREFLIGHT.json', 'EXECUTION_STARTED.json', 'EXECUTION_RESULT.json',
             'APPLICATION.stdout', 'APPLICATION.stderr']
    names += ['run/' + name for name in ['STARTED.json', 'END.json', 'CANDIDATE.json', 'ledger.json',
                                       'frames.json', 'result.json', 'SSH_ARGV.json', 'SSH_CHILD.json', 'SSH.stderr']]
    frame_dir = stage / 'run/frames'
    if frame_dir.exists():
        paths = sorted(frame_dir.iterdir())
        if len(paths) > 16 or any(re.fullmatch('[0-9a-f]{64}', path.name) is None or path.is_symlink() for path in paths):
            raise ValueError('Unexpected retained frame inventory')
        names += ['run/frames/' + path.name for path in paths]
    files = {}
    for name in names:
        path = stage / name
        if path.exists():
            if path.is_symlink() or not path.is_file():
                raise ValueError('Evidence must be an original regular file')
            raw = path.read_bytes()
            if len(raw) > 2_000_000:
                raise ValueError('Evidence file exceeds the fixed collection bound')
            digest = hashlib.sha256(raw).hexdigest()
            if name.startswith('run/frames/') and (digest != path.name or len(raw) > 65540):
                raise ValueError('Original frame bytes differ from their retained identity')
            files[name] = {'sha256': digest, 'bytes': len(raw), 'base64': base64.b64encode(raw).decode()}
    if start_path.read_bytes() != start_raw or (end_path.read_bytes() if end_path.exists() else None) != end_raw:
        raise RuntimeError('Terminal metadata changed during evidence collection')
    bundle = zlib.compress(json.dumps({'schema': 'pft-ssh-original-evidence-v2', 'host': HOST,
                                       'source_commit': SOURCE_COMMIT, 'registration_sha256': REGISTRATION_SHA256,
                                       'initiator_terminal_gate': gate, 'process_observation': observation,
                                       'local_terminal_status': original_end['status'] if original_end else 'MISSING_END_CONFIRMED_PROCESS_DEAD',
                                       'files': files}, sort_keys=True).encode(), 9)
    with (stage / 'EVIDENCE.json.zlib').open('xb') as output:
        output.write(bundle)
    print(json.dumps({'host': HOST, 'path': str(stage / 'EVIDENCE.json.zlib'), 'bytes': len(bundle),
                      'sha256': hashlib.sha256(bundle).hexdigest(), 'application_end': original_end,
                      'process_observation': observation, 'collection_wall_seconds': time.monotonic() - started_time}), flush=True)


if __name__ == '__main__':
    collect()
