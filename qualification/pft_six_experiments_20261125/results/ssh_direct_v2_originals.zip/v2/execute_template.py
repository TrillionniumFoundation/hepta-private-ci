"""Fixed Linux outer owner: retain app leader until all owned-group signals."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

BOOT = Path('/proc/sys/kernel/random/boot_id').read_text().strip()


def command_sha(argv):
    return hashlib.sha256(b'\0'.join(os.fsencode(item) for item in argv) + b'\0').hexdigest()


def process_stamp(pid):
    try:
        folder = Path('/proc') / str(pid)
        fields = (folder / 'stat').read_text().rsplit(') ', 1)[1].split()
        status = (folder / 'status').read_text()
        uid = int(next(line for line in status.splitlines() if line.startswith('Uid:')).split()[1])
        command = (folder / 'cmdline').read_bytes()
    except FileNotFoundError:
        return None
    return {'pid': pid, 'boot': BOOT, 'state': fields[0], 'ppid': int(fields[1]),
            'pgid': int(fields[2]), 'sid': int(fields[3]), 'start_ticks': int(fields[19]),
            'uid': uid, 'command_sha256': hashlib.sha256(command).hexdigest()}


def same_process(original, current):
    keys = ('pid', 'boot', 'pgid', 'sid', 'start_ticks', 'uid')
    return current is not None and all(current[key] == original[key] for key in keys) and (
        current['state'] in ('Z', 'X') or current['command_sha256'] == original['command_sha256'])


def exit_without_reaping(process):
    if process.returncode is not None:
        raise RuntimeError('Outer owner lost its unreaped leader')
    status = os.waitid(os.P_PID, process.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
    if status is None:
        return None
    if status.si_code == os.CLD_EXITED:
        return status.si_status
    if status.si_code in (os.CLD_KILLED, os.CLD_DUMPED):
        return -status.si_status
    raise RuntimeError('Unexpected outer wait status')


def observe_ssh(process, app_stamp, stage, expected_argv, owned):
    current_app = process_stamp(process.pid)
    if not same_process(app_stamp, current_app) or current_app['state'] in ('Z', 'X'):
        return
    candidates = set()
    file = stage / 'run/SSH_CHILD.json'
    if file.exists():
        raw = file.read_bytes()
        if len(raw) > 4096:
            raise ValueError('Oversized own SSH child identity')
        record = json.loads(raw)
        if type(record.get('pid')) is not int or record.get('owned_process_group') != record['pid']:
            raise ValueError('Malformed own SSH child identity')
        candidates.add(record['pid'])
    children = Path('/proc') / str(process.pid) / 'task' / str(process.pid) / 'children'
    try:
        raw_children = children.read_text()
    except FileNotFoundError:
        raw_children = ''
    if len(raw_children) > 4096:
        raise ValueError('Unexpected child inventory bound')
    candidates.update(int(value) for value in raw_children.split())
    if len(candidates) > 8:
        raise ValueError('Unexpected number of application children')
    for pid in candidates:
        observed = process_stamp(pid)
        if observed is None or observed['state'] in ('Z', 'X'):
            continue
        if (observed['ppid'] == process.pid and observed['pgid'] == pid and observed['sid'] == pid
                and observed['uid'] == app_stamp['uid'] and observed['start_ticks'] >= app_stamp['start_ticks']
                and observed['command_sha256'] == command_sha(expected_argv)):
            if pid in owned and not same_process(owned[pid], observed):
                raise RuntimeError('Observed SSH PID identity changed')
            owned[pid] = observed


def cleanup_owned(process, app_stamp, stage, expected_argv, owned, deadline, expected_config=None):
    """Never signal a nested SSH group while its parent can concurrently reap it."""
    events, errors, stop_requested = [], [], False
    try:
        if exit_without_reaping(process) is None:
            os.kill(process.pid, signal.SIGINT)
            events.append({'signal': 'SIGINT', 'target': 'unreaped_application'})
            grace = min(deadline - 2.5, time.monotonic() + 4.2)
            while time.monotonic() < grace and exit_without_reaping(process) is None:
                observe_ssh(process, app_stamp, stage, expected_argv, owned)
                time.sleep(min(.02, max(0., grace - time.monotonic())))
        if exit_without_reaping(process) is None:
            # The app is our unreaped child. Stopping it temporarily prevents
            # its independent SSH reaper from racing the nested-group signal.
            stop_requested = True
            os.kill(process.pid, signal.SIGSTOP)
            stop_deadline = min(deadline - 2, time.monotonic() + .3)
            current = process_stamp(process.pid)
            stopped = os.waitid(os.P_PID, process.pid, os.WSTOPPED | os.WNOHANG | os.WNOWAIT)
            while current is not None and (current['state'] not in ('T', 't', 'Z', 'X') or stopped is None) and time.monotonic() < stop_deadline:
                time.sleep(.005)
                current = process_stamp(process.pid)
                stopped = os.waitid(os.P_PID, process.pid, os.WSTOPPED | os.WNOHANG | os.WNOWAIT)
            if not same_process(app_stamp, current) or current['state'] not in ('T', 't') or stopped is None or stopped.si_code != os.CLD_STOPPED or stopped.si_status != signal.SIGSTOP:
                raise RuntimeError('Cannot establish a stopped original SSH owner')
            events.append({'signal': 'SIGSTOP', 'target': 'unreaped_application', 'confirmed_stop_status': stopped.si_status})
            exit_without_reaping(process)
            observe_ssh(process, app_stamp, stage, expected_argv, owned)
            for original in list(owned.values()):
                child = process_stamp(original['pid'])
                if child is None:
                    continue
                if not same_process(original, child) or child['ppid'] != process.pid:
                    raise RuntimeError('Nested SSH ownership no longer belongs to the stopped app')
                # Even an exited SSH leader remains reserved by the stopped
                # parent until after this signal; no stale numeric PID is used.
                os.killpg(original['pgid'], signal.SIGKILL)
                events.append({'signal': 'SIGKILL', 'target': 'ssh_with_stopped_parent', 'identity': original})
            os.kill(process.pid, signal.SIGCONT)
            stop_requested = False
            resume_deadline = min(deadline - 1.5, time.monotonic() + .5)
            while time.monotonic() < resume_deadline and exit_without_reaping(process) is None:
                time.sleep(.005)
    except BaseException as error:
        errors.append({'type': type(error).__name__, 'message': str(error)[:500]})
    finally:
        leader_reserved = False
        try:
            # WNOWAIT must still confirm sole ownership before either final
            # app signal. A SIGSTOP introduced here must not be left behind.
            exit_without_reaping(process)
            leader_reserved = True
        except BaseException as error:
            errors.append({'type': type(error).__name__, 'message': str(error)[:500]})
        if leader_reserved:
            try:
                if stop_requested:
                    os.kill(process.pid, signal.SIGCONT)
                    events.append({'signal': 'SIGCONT', 'target': 'unreaped_application'})
            except BaseException as error:
                errors.append({'type': type(error).__name__, 'message': str(error)[:500]})
            finally:
                final_signal_complete = False
                try:
                    exit_without_reaping(process)
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    events.append({'signal': 'SIGKILL', 'target': 'unreaped_application_group'})
                    final_signal_complete = True
                except BaseException as error:
                    errors.append({'type': type(error).__name__, 'message': str(error)[:500]})
                finally:
                    if final_signal_complete:
                        try:
                            # No process/group signal follows the unique reap.
                            process.wait(timeout=max(.001, deadline - time.monotonic()))
                        except BaseException as error:
                            errors.append({'type': type(error).__name__, 'message': str(error)[:500]})
    inner_end = stage / 'run/END.json'
    proof = json.loads(inner_end.read_bytes()) if inner_end.exists() else {}
    matching_end = (proof.get('pid') == app_stamp['pid'] and proof.get('boot') == app_stamp['boot']
                    and expected_config is not None and proof.get('config_sha256') == expected_config
                    and 'teardown_error' in proof and proof['teardown_error'] is None)
    inner_reaped = matching_end and type(proof.get('ssh_child_exit_code')) is int
    outer_final_groups = {event['identity']['pid'] for event in events if event.get('target') == 'ssh_with_stopped_parent'}
    observations = []
    for original in owned.values():
        current = process_stamp(original['pid'])
        original_live = same_process(original, current) and current['state'] not in ('Z', 'X')
        observations.append({'original': original, 'current': current, 'original_still_running': original_live})
        if original_live:
            errors.append({'type': 'UnknownOwnership', 'message': 'Original SSH session remains active; no unsafe numeric signal sent'})
        elif original['pid'] not in outer_final_groups and not inner_reaped:
            errors.append({'type': 'UnknownOwnership', 'message': 'Captured SSH leader ended without outer final-group signal or matching inner owner final-group/reap proof'})
    # A child receipt missed during monitoring must never become a kill target
    # after its parent died. A currently active unobserved identity stays UNKNOWN.
    identity_file = stage / 'run/SSH_CHILD.json'
    if identity_file.exists():
        identity = json.loads(identity_file.read_bytes())
        pid = identity.get('pid')
        if type(pid) is not int:
            errors.append({'type': 'MalformedIdentity', 'message': 'Missing exact SSH PID'})
        elif pid not in owned:
            if not inner_reaped:
                errors.append({'type': 'UnknownOwnership', 'message': 'Uncaptured SSH receipt lacks the matching inner owner final-group/reap proof'})
    elif expected_config is not None and not owned:
        no_child_proof = matching_end and 'ssh_child_exit_code' in proof and proof['ssh_child_exit_code'] is None
        if not no_child_proof:
            errors.append({'type': 'UnknownOwnership', 'message': 'No captured SSH identity or matching completed pre-child failure receipt'})
    return {'state': 'TERMINAL' if not errors and process.returncode is not None else 'UNKNOWN',
            'events': events, 'errors': errors, 'ssh_observations': observations,
            'application_exit_code': process.returncode}


def execute():
    started = time.monotonic()
    deadline = started + 55
    stage = Path(STAGE)
    raw = (stage / 'SSH_CONFIG.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != EXPECTED_CONFIG:
        raise ValueError('Execution configuration pin differs')
    config = json.loads(raw)
    preflight = json.loads((stage / 'PREFLIGHT.json').read_bytes())
    if preflight['status'] != 'COMPLETE' or preflight['config_sha256'] != EXPECTED_CONFIG or preflight['source_commit'] != SOURCE_COMMIT:
        raise ValueError('A matching completed preflight is required')
    if preflight['executable'] != EXECUTABLE or (stage / 'run').exists():
        raise ValueError('Interpreter differs or this application output was already attempted')
    for name, digest in config['source_sha256'].items():
        if hashlib.sha256((stage / name).read_bytes()).hexdigest() != digest:
            raise ValueError('Execution source differs from the admitted source')
    sys.path.insert(0, str(stage))
    import ssh_snapshot
    expected_ssh = ssh_snapshot.ssh_argv(config)
    identity = {'schema': 'pft-ssh-outer-execution-v2', 'host': 'pocket4', 'pid': os.getpid(), 'boot': BOOT,
                'source_commit': SOURCE_COMMIT, 'registration_sha256': REGISTRATION_SHA256,
                'config_sha256': EXPECTED_CONFIG, 'started_unix_ns': time.time_ns(),
                'preflight_sha256': hashlib.sha256((stage / 'PREFLIGHT.json').read_bytes()).hexdigest(),
                'round_id': config['frozen']['round_id'], 'orchestration_sha256': ORCHESTRATION_SHA256}
    with (stage / 'EXECUTION_STARTED.json').open('x') as output:
        json.dump(identity, output, sort_keys=True)
    cpu0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    process, app_stamp, owned, cleanup = None, None, {}, None
    result = {**identity, 'status': 'FAILED', 'exit_code': None}
    command = [EXECUTABLE, str(stage / 'ssh_snapshot.py'), str(stage / 'SSH_CONFIG.json'), '--expected', EXPECTED_CONFIG]
    try:
        with (stage / 'APPLICATION.stdout').open('xb') as stdout, (stage / 'APPLICATION.stderr').open('xb') as stderr:
            process = subprocess.Popen(command, cwd=stage, stdout=stdout, stderr=stderr, start_new_session=True)
            app_stamp = process_stamp(process.pid)
            if app_stamp is None or app_stamp['ppid'] != os.getpid() or app_stamp['uid'] != os.getuid() or app_stamp['pgid'] != process.pid or app_stamp['sid'] != process.pid or app_stamp['command_sha256'] != command_sha(command):
                raise RuntimeError('The original application child identity was not captured')
            result['application_identity'] = app_stamp
            active_deadline = deadline - 9
            while exit_without_reaping(process) is None:
                observe_ssh(process, app_stamp, stage, expected_ssh, owned)
                if time.monotonic() >= active_deadline:
                    raise TimeoutError('Outer observation deadline reached; cleanup is within the same 55-second bound')
                time.sleep(.02)
            result['observed_exit_without_reaping'] = exit_without_reaping(process)
            result['status'] = 'COMPLETE' if result['observed_exit_without_reaping'] == 0 else 'FAILED'
    except BaseException as error:
        result['error'] = {'type': type(error).__name__, 'message': str(error)[:500]}
    finally:
        if process is not None and app_stamp is not None:
            try:
                cleanup = cleanup_owned(process, app_stamp, stage, expected_ssh, owned, deadline, EXPECTED_CONFIG)
            except BaseException as error:
                cleanup = {'state': 'UNKNOWN', 'error': {'type': type(error).__name__, 'message': str(error)[:500]}}
        elif process is not None:
            # The direct Popen leader is still ours even if metadata capture
            # failed; only that reserved group may be signalled, never an SSH PID.
            try:
                exit_without_reaping(process)
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=max(.001, deadline - time.monotonic()))
            except BaseException as error:
                result['fallback_cleanup_error'] = {'type': type(error).__name__, 'message': str(error)[:500]}
            cleanup = {'state': 'UNKNOWN', 'reason': 'Application metadata was not captured; nested ownership unconfirmed'}
        result['cleanup'] = cleanup
        result['exit_code'] = None if process is None else process.returncode
        result['owned_ssh_processes'] = list(owned.values())
        if cleanup is None or cleanup['state'] != 'TERMINAL':
            result['status'] = 'UNKNOWN'
        end_path = stage / 'run/END.json'
        try:
            result['application_end'] = json.loads(end_path.read_bytes()) if end_path.exists() else None
        except BaseException as error:
            result['application_end'] = None
            result['end_read_error'] = {'type': type(error).__name__, 'message': str(error)[:500]}
        if result['status'] == 'COMPLETE' and (result['application_end'] is None or result['application_end']['status'] != 'COMPLETE'):
            result['status'] = 'FAILED'
        cpu1 = resource.getrusage(resource.RUSAGE_CHILDREN)
        result['wall_seconds'] = time.monotonic() - started
        result['child_cpu_seconds'] = (cpu1.ru_utime + cpu1.ru_stime) - (cpu0.ru_utime + cpu0.ru_stime)
        with (stage / 'EXECUTION_RESULT.json').open('x') as output:
            json.dump(result, output, sort_keys=True)
        print(json.dumps(result), flush=True)
    raise SystemExit(0 if result['status'] == 'COMPLETE' else 1)


if __name__ == '__main__':
    execute()
