import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

stage = Path(STAGE)
started = time.monotonic()
result = {'schema': 'pft-ssh-preflight-v1', 'status': 'FAILED', 'application_started': False,
          'pid': os.getpid(), 'executable': sys.executable, 'config_sha256': EXPECTED_CONFIG,
          'source_commit': SOURCE_COMMIT, 'registration_sha256': REGISTRATION_SHA256}
try:
    raw = (stage / 'SSH_CONFIG.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED_CONFIG
    config = json.loads(raw)
    assert not Path(config['frozen']['output']).exists()
    deployment = json.loads((stage / 'DEPLOYMENT.json').read_bytes())
    assert deployment['status'] == 'COMPLETE' and deployment['source_commit'] == SOURCE_COMMIT
    assert deployment['registration_sha256'] == REGISTRATION_SHA256
    sys.path.insert(0, str(stage))
    import ssh_snapshot
    projected, reference = ssh_snapshot.prepare(config)
    result['identity'] = ssh_snapshot.identity(config, EXPECTED_CONFIG)
    result['local_contribution_id'] = projected['message']['contribution_id']
    result['local_payload_sha256'] = projected['message']['payload_sha256']
    result['context_id'] = config['context_id']
    result['central_reference_grid_sha256'] = reference['audit_candidate_sha256']
    old_stage = Path(OLD_STAGE)
    old_end = json.loads((old_stage / 'run/END.json').read_bytes())
    result['old_tcp_end_sha256'] = hashlib.sha256((old_stage / 'run/END.json').read_bytes()).hexdigest()
    result['old_tcp_status'] = old_end['status']
    old_process = Path('/proc') / str(old_end['pid']) / 'cmdline'
    old_cmd = old_process.read_bytes() if old_process.exists() else b''
    result['old_tcp_pid'] = old_end['pid']
    result['old_tcp_pid_absent'] = not bool(old_cmd)
    result['old_tcp_command_still_present'] = str(old_stage).encode() in old_cmd and b'direct_snapshot.py' in old_cmd
    assert old_end['status'] == 'FAILED' and not result['old_tcp_command_still_present']
    if projected['node'] == 0:
        command = ssh_snapshot.ssh_argv(config)
        inspection = subprocess.run(command[:-2] + ['-G', command[-2]], capture_output=True, text=True, timeout=4)
        assert inspection.returncode == 0
        values = {}
        for line in inspection.stdout.splitlines():
            key, _, value = line.partition(' ')
            values.setdefault(key, []).append(value)
        assert values['hostname'] == [config['roster'][1]['address']]
        assert values['user'] == [config['roster'][1]['user']]
        assert values['port'] == ['22'] and values['proxyusefdpass'] == ['yes']
        assert values['identityagent'] == ['none'] and values['forwardagent'] == ['no']
        assert values['stricthostkeychecking'] in (['true'], ['yes'])
        assert values['userknownhostsfile'] == [config['ssh']['known_hosts']]
        assert values['hostkeyalias'] == [config['ssh']['host_key_alias']]
        result['ssh_effective_configuration'] = values
        result['ssh_configuration_stderr'] = inspection.stderr
        result['ssh_connections_opened'] = 0
    result['status'] = 'COMPLETE'
except BaseException as error:
    result['error'] = {'type': type(error).__name__, 'message': str(error)[:500]}
    raise
finally:
    result['wall_seconds'] = time.monotonic() - started
    with (stage / 'PREFLIGHT.json').open('x') as output:
        json.dump(result, output, sort_keys=True)
    print(json.dumps(result), flush=True)
