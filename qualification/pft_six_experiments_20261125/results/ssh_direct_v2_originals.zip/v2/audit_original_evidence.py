"""Offline receipt/hash/frame audit of the completed single engineering round."""
import base64
import hashlib
import json
from pathlib import Path
import struct
import zlib

ROOT = Path(__file__).parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def tool_receipt(name):
    value = json.loads((ROOT / name).read_bytes())
    return value.get('structuredContent') or json.loads(next(item['text'] for item in value['content'] if item['type'] == 'text'))


registration_raw = (ROOT / 'REGISTRATION.json').read_bytes()
registration = json.loads(registration_raw)
assert sha(registration_raw) == '98478f2b2c3ce2429d5b8e0e25f77cdd84a12e3fc4036071009115bd8fac79ca'
publication_raw = (ROOT / 'SOURCE_PUBLICATION.json').read_bytes()
hosts, originals, bundles, results, transfers = ('pocket4', 'ai395'), {}, {}, {}, {}
for node, host in enumerate(hosts):
    raw = (ROOT / (host + '-EVIDENCE.json.zlib')).read_bytes()
    bundle = json.loads(zlib.decompress(raw))
    assert bundle['registration_sha256'] == sha(registration_raw)
    assert bundle['source_commit'] == registration['source_commit']
    assert bundle['local_terminal_status'] == 'COMPLETE' and bundle['process_observation']['terminal']
    decoded = {}
    for name, item in bundle['files'].items():
        content = base64.b64decode(item['base64'], validate=True)
        assert len(content) == item['bytes'] and sha(content) == item['sha256'], (host, name)
        decoded[name] = content
    assert decoded['REGISTRATION.json'] == registration_raw
    assert decoded['SOURCE_PUBLICATION.json'] == publication_raw
    assert decoded['SSH_CONFIG.json'] == (ROOT / (host + '-config.json')).read_bytes()
    config = json.loads(decoded['SSH_CONFIG.json'])
    assert sha(decoded['SSH_CONFIG.json']) == registration['config_sha256'][host]
    start, end = (json.loads(decoded['run/' + name + '.json']) for name in ('STARTED', 'END'))
    assert end['status'] == 'COMPLETE' and end['teardown_error'] is None
    for key in ('node', 'hostname', 'uid', 'pid', 'boot', 'executable', 'config_sha256', 'context_id'):
        assert start[key] == end[key], (host, key)
    assert end['training_runs'] == end['real_user_adoptions'] == 0 and end['data_generated'] is False
    assert end['wall_seconds'] <= registration['budgets']['delivery_deadline_seconds'] + 4.1
    result = json.loads(decoded['run/result.json'])
    assert result['identity']['pid'] == end['pid']
    assert result['accepted_ids'] == sorted(config['frozen']['expected_contribution_ids'])
    assert result['candidate_integer_grid'] == [-2513573058, -1645586540, 3737977534, 5200016296, 1473707131, 316503714, 2713977994, 1198731121]
    assert result['ledger_sha256'] == sha(decoded['run/ledger.json'])
    ledger = json.loads(decoded['run/ledger.json'])
    assert sha(canonical(ledger['body'])) == ledger['body_sha256']
    messages = {item['contribution_id']: item for item in ledger['body']['messages']}
    events = json.loads(decoded['run/frames.json'])
    assert len(events) == 8 and result['transfers'] == events
    frames = []
    for event in events:
        wire = decoded['run/frames/' + event['wire_sha256']]
        assert event['status'] == 'complete'
        assert len(wire) == event['frame_bytes'] == event['transferred_bytes']
        assert sha(wire) == event['wire_sha256'] and struct.unpack('!I', wire[:4])[0] == len(wire) - 4
        frame = json.loads(wire[4:])
        assert frame['schema'] == 'pft-direct-ssh-statistics-v2'
        assert frame['round_id'] == registration['round_id'] and frame['context_id'] == registration['context_id']
        sender = node if event['direction'] == 'send' else 1 - node
        assert frame['sender'] == sender and frame['recipient'] == 1 - sender
        if frame['kind'] == 'contribution':
            message = frame['body']
            assert message == messages[config['frozen']['expected_contribution_ids'][sender]]
            assert message['payload_sha256'] == config['frozen']['expected_contributions'][sender]
        frames.append({'direction': event['direction'], 'sender': sender, 'sequence': frame['sequence'],
                       'kind': frame['kind'], 'bytes': len(wire), 'sha256': sha(wire)})
    for direction in ('send', 'receive'):
        assert [frame['sequence'] for frame in frames if frame['direction'] == direction] == [0, 1, 2, 3]
    originals[host], bundles[host], results[host], transfers[host] = decoded, bundle, result, frames

assert originals['pocket4']['run/ledger.json'] == originals['ai395']['run/ledger.json']
for host, peer in zip(hosts, reversed(hosts)):
    for frame in transfers[host]:
        match = [other for other in transfers[peer] if other['sha256'] == frame['sha256']]
        assert len(match) == 1 and match[0]['direction'] != frame['direction']
        path = 'run/frames/' + frame['sha256']
        assert originals[host][path] == originals[peer][path]
for key in ('accepted_ids', 'statistics_snapshot_id', 'candidate', 'candidate_sha256', 'candidate_integer_grid',
            'quantization_step', 'central_reference_grid_sha256', 'central_reference_artifact_sha256', 'ssh_connection'):
    assert results['pocket4'][key] == results['ai395'][key], key
guard = results['pocket4']['ssh_guard']
assert len(guard['attempts']) == 1 and guard['attempts'][0] == guard['selected']
selected = guard['selected']
connection = results['pocket4']['ssh_connection']
assert selected['transport'] == 'usb4' and selected['status'] == 'connected'
assert selected['interface_bound'] and selected['interface_policy'] == 'required' and selected['interface'] == 'thunderbolt0'
assert selected['local_address'] == connection['client'] == ['10.77.0.4', 51217]
assert selected['remote_address'] == connection['server'] == ['10.77.0.2', 22]
ssh_stderr = originals['pocket4']['run/SSH.stderr'].decode()
config = json.loads(originals['pocket4']['SSH_CONFIG.json'])
assert 'Server host key: ssh-ed25519 ' + config['ssh']['server_host_key'] in ssh_stderr
assert any(config['ssh']['client_public_key'] in line and 'Server accepts key:' in line for line in ssh_stderr.splitlines())
assert 'using "publickey"' in ssh_stderr

execution_raw = originals['pocket4']['EXECUTION_RESULT.json']
execution = json.loads(execution_raw)
assert execution['status'] == 'COMPLETE' and execution['cleanup']['state'] == 'TERMINAL'
assert not execution['cleanup']['errors'] and execution['exit_code'] == 0
assert not any(item['original_still_running'] for item in execution['cleanup']['ssh_observations'])
native = tool_receipt('pocket4-execute-status-receipt.json')
assert native['state'] == 'succeeded' and native['exit_code'] == 0
assert native['output_complete'] and native['output_durable'] and native['terminal_publication_confirmed']
assert native['job_id'] == '1a2129b6b21-ffbe-3fce' and not native['automatic_retry']
projection = []
for host in hosts:
    gate = bundles[host]['initiator_terminal_gate']
    assert gate['execution_result_sha256'] == sha(execution_raw)
    for key in ('pid', 'boot', 'source_commit', 'registration_sha256', 'config_sha256', 'round_id', 'status', 'exit_code'):
        assert gate['execution'][key] == execution[key]
    projection.append({'host': host, 'path': 'initiator_terminal_gate.execution.started_unix_ns',
                       'gate_projection': gate['execution']['started_unix_ns'],
                       'original_file_value': execution['started_unix_ns'],
                       'difference_ns': gate['execution']['started_unix_ns'] - execution['started_unix_ns']})
erratum = {'schema': 'pft-metadata-integer-projection-erratum-v1', 'registration_sha256': sha(registration_raw),
           'cause': 'The control-plane gate copied a JSON nanosecond integer through JavaScript Number, which has insufficient precision beyond 2^53',
           'original_execution_result_sha256': sha(execution_raw), 'observations': projection,
           'time_source_of_record': 'Original EXECUTION_RESULT.json bytes embedded in the pocket4 bundle; raw byte SHA verified',
           'affected_process_identity_fields': [], 'bundles_changed': False, 'new_collection_or_application_rounds': 0}
with (ROOT / 'EVIDENCE_PROJECTION_ERRATUM.json').open('x') as output:
    json.dump(erratum, output, indent=2, sort_keys=True)

summary = {'schema': 'pft-direct-ssh-engineering-result-v2', 'status': 'PASS_ENGINEERING_FROZEN_STATISTICS',
           'registration_sha256': sha(registration_raw), 'source_commit': registration['source_commit'],
           'source_tree': registration['source_tree'], 'round_id': registration['round_id'],
           'application_rounds': 1, 'original_scientific_panels_repeated': 0,
           'initiator_job_id': native['job_id'], 'native_terminal_status': native,
           'exact_execution_started_unix_ns': execution['started_unix_ns'],
           'route': {'ssh_connection': connection, 'guard': guard, 'server_host_key': config['ssh']['server_host_key'],
                     'client_public_key': config['ssh']['client_public_key'], 'controller_statistic_relay': False},
           'transport': {'unique_frames': 8, 'unique_framed_application_bytes': 9752,
                         'pocket4_to_ai395_bytes': 4881, 'ai395_to_pocket4_bytes': 4871,
                         'all_sender_receiver_original_bytes_identical': True, 'failed_frames': 0,
                         'bytes_exclude_ssh_handshake_encryption_and_transport_overhead': True,
                         'frames': transfers['pocket4']},
           'shared': {key: results['pocket4'][key] for key in ('accepted_ids', 'statistics_snapshot_id', 'ledger_sha256',
                      'candidate', 'candidate_sha256', 'candidate_integer_grid', 'quantization_step',
                      'central_reference_grid_sha256', 'central_reference_artifact_sha256')},
           'per_host': {}, 'costs': {'initiator_outer_wall_seconds': execution['wall_seconds'],
                                   'initiator_child_cpu_seconds': execution['child_cpu_seconds']},
           'metadata_projection_erratum_sha256': sha((ROOT / 'EVIDENCE_PROJECTION_ERRATUM.json').read_bytes()),
           'historical_tcp_erratum_sha256': sha((ROOT / 'HISTORICAL_TCP_ERRATUM.json').read_bytes()),
           'unqualified_claims': registration['cannot_qualify'],
           'limitations': ['One archived 8-dimensional seed731 case; no new data generation or parameter training',
                           'Rank 8 of 8; this case demonstrates no dimensional reduction advantage',
                           'Raw peer float weights have different byte hashes; explicitly registered 1e-10 canonical weights match exactly',
                           'Original direct TCP failure remains failed; SSH succeeds over an already configured trusted port22 path',
                           'No end-to-end adopted-update time or foundation-model qualification follows from this engineering exchange']}
for host in hosts:
    result = results[host]
    end = json.loads(originals[host]['run/END.json'])
    summary['per_host'][host] = {key: result[key] for key in ('effective_rank', 'feature_dimension',
        'effective_direction_relative_error', 'normal_residual_relative', 'discarded_target_relative_norm',
        'peer_full_precision_relative_error', 'central_reference_relative_error_including_quantization', 'raw_candidate_sha256')}
    summary['per_host'][host].update(pid=end['pid'], boot=end['boot'], status=end['status'],
        application_wall_seconds=end['wall_seconds'], teardown_seconds=end['teardown_seconds'],
        original_pid_absent=bundles[host]['process_observation']['reason'] == 'original_pid_absent',
        evidence_sha256=sha((ROOT / (host + '-EVIDENCE.json.zlib')).read_bytes()),
        original_files=len(originals[host]))
    for phase, file in [('deployment', 'DEPLOYMENT.json'), ('preflight', 'PREFLIGHT.json')]:
        summary['costs'][host + '_' + phase + '_wall_seconds'] = json.loads(originals[host][file])['wall_seconds']
    summary['costs'][host + '_collection_wall_seconds'] = json.loads(tool_receipt(host + '-collect-read-receipt.json')['stdout']['text'])['collection_wall_seconds']
with (ROOT / 'ENGINEERING_RESULT.json').open('x') as output:
    json.dump(summary, output, indent=2, sort_keys=True)
print(json.dumps({'status': summary['status'], 'result_sha256': sha((ROOT / 'ENGINEERING_RESULT.json').read_bytes()),
                  'unique_frames': 8, 'unique_framed_application_bytes': 9752,
                  'canonical_candidate_sha256': summary['shared']['candidate_sha256'],
                  'statistics_snapshot_id': summary['shared']['statistics_snapshot_id'],
                  'projection_erratum': projection}, sort_keys=True))
