"""Independent, read-only validation of the one completed frozen-statistic exchange.

Imports no protocol code, creates no examples, opens no sockets, and never runs
the peer entry. This is a verifier of retained engineering evidence, not a new
research panel or a speed benchmark.
"""
import base64
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import shlex
import struct
import sys
import time
import zlib

STARTED = time.monotonic()
CPU_STARTED = time.process_time()
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np

ROOT = Path("/tmp/hepta_acceptance_7c9e/analytic_ssh_v2_run")
COMMIT = "6e4af27a18b9dd2252713623bff07bdce1ef2cba"
REG_SHA = "98478f2b2c3ce2429d5b8e0e25f77cdd84a12e3fc4036071009115bd8fac79ca"
JOB = "1a2129b6b21-ffbe-3fce"
EXPECTED_BUNDLES = {
    "pocket4": (25747, "9be8920d0215545e12851a9a9b83304b09a8b812df45a1c804dc1a6905376427"),
    "ai395": (18479, "da35df030ecdbd27b59b11d80f3d43693931215a0e3026f310f9d7a95395d505"),
}
CHECKS = []


def check(label, condition):
    if not condition:
        raise ValueError(label)
    CHECKS.append(label)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique_object(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("Duplicate evidence JSON key: " + key)
        result[key] = value
    return result


def decode(raw):
    def nonfinite(value):
        raise ValueError("Nonfinite evidence JSON constant: " + value)
    return json.loads(raw, object_pairs_hook=unique_object, parse_constant=nonfinite)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return sha(canonical(value))


def array_digest(value):
    array = np.ascontiguousarray(value, dtype="<f8")
    return sha(str(array.shape).encode() + array.tobytes())


def relative(actual, expected):
    return float(np.linalg.norm(np.asarray(actual) - np.asarray(expected)) / max(np.linalg.norm(expected), 1e-15))


reg_raw = (ROOT / "REGISTRATION.json").read_bytes()
registration = decode(reg_raw)
check("frozen_registration", sha(reg_raw) == REG_SHA)
original_reference = ROOT.parent / "analytic_network/qualification/pft_six_experiments_20261125/results/pft2_multihost.json"
reference_raw = original_reference.read_bytes()
reference = decode(reference_raw)
case, = [item for item in reference["records"] if item["size"] == 8 and item["seed"] == 731]
bundles, files, configs, values, frame_packets = {}, {}, {}, {}, {}
for node, host in enumerate(("pocket4", "ai395")):
    raw = (ROOT / (host + "-EVIDENCE.json.zlib")).read_bytes()
    check(host + ":bundle_bytes_and_sha", (len(raw), sha(raw)) == EXPECTED_BUNDLES[host])
    bundle = decode(zlib.decompress(raw))
    bundles[host] = bundle
    check(host + ":bundle_admission", bundle["host"] == host and bundle["schema"] == "pft-ssh-original-evidence-v2"
          and bundle["source_commit"] == COMMIT and bundle["registration_sha256"] == REG_SHA
          and bundle["local_terminal_status"] == "COMPLETE" and bundle["process_observation"]["terminal"] is True)
    retained = {}
    for name, item in bundle["files"].items():
        data = base64.b64decode(item["base64"], validate=True)
        check(host + ":retained_file:" + name, len(data) == item["bytes"] and sha(data) == item["sha256"] and len(data) <= 2_000_000)
        retained[name] = data
    files[host] = retained
    values[host] = {name: decode(data) for name, data in retained.items() if name.endswith(".json")}
    check(host + ":exact_config_bytes", retained["SSH_CONFIG.json"] == (ROOT / (host + "-config.json")).read_bytes())
    check(host + ":exact_registration_bytes", retained["REGISTRATION.json"] == reg_raw)
    check(host + ":exact_source_publication_bytes", retained["SOURCE_PUBLICATION.json"] == (ROOT / "SOURCE_PUBLICATION.json").read_bytes())
    config = values[host]["SSH_CONFIG.json"]
    configs[host] = config
    expected = config["roster"][node]
    started, ended = values[host]["run/STARTED.json"], values[host]["run/END.json"]
    check(host + ":original_process_identity", all(started[key] == ended[key] for key in
          ("pid", "boot", "uid", "node", "hostname", "executable", "config_sha256", "context_id"))
          and started["node"] == node and started["boot"] == expected["boot"] and started["uid"] == expected["uid"]
          and started["hostname"] == expected["hostname"] and started["executable"] == expected["python"]
          and started["config_sha256"] == sha(retained["SSH_CONFIG.json"]) and started["context_id"] == registration["context_id"])
    check(host + ":definite_inner_terminal", ended["status"] == "COMPLETE" and ended["error"] is None and ended["teardown_error"] is None
          and ended["training_runs"] == ended["real_user_adoptions"] == 0 and ended["data_generated"] is False
          and 0 <= ended["wall_seconds"] <= 49.1 and 0 <= ended["teardown_seconds"] <= 4.1)
    deployment, preflight = values[host]["DEPLOYMENT.json"], values[host]["PREFLIGHT.json"]
    check(host + ":own_original_archive", deployment["status"] == "COMPLETE" and deployment["source_commit"] == COMMIT
          and deployment["registration_sha256"] == REG_SHA and deployment["source_sha256"] == registration["source_sha256"]
          and deployment["archive_sha256"] == config["frozen"]["archive_sha256"]
          and deployment["archive_source"] == str(Path(expected["stage"]).parent / "pft-direct-usb4-20261125-7c9e-v1/original-statistics.json.zlib")
          and deployment["peer_archive_received_from_controller"] is False and deployment["application_started"] is False)
    check(host + ":preflight_own_contribution", preflight["status"] == "COMPLETE" and preflight["application_started"] is False
          and preflight["local_payload_sha256"] == config["frozen"]["expected_contributions"][node]
          and preflight["local_contribution_id"] == config["frozen"]["expected_contribution_ids"][node]
          and preflight["old_tcp_status"] == "FAILED" and preflight["old_tcp_command_still_present"] is False)
    gate = bundle["initiator_terminal_gate"]
    native = gate["native_status"]
    check(host + ":authoritative_unique_execution", gate["job_id"] == native["job_id"] == JOB
          and native["state"] == "succeeded" and native["exit_code"] == 0 and native["automatic_retry"] is False
          and native["output_complete"] is True and native["output_durable"] is True and native["terminal_publication_confirmed"] is True
          and gate["source_commit"] == COMMIT and gate["registration_sha256"] == REG_SHA)
    check(host + ":reference_pin", sha(reference_raw) == config["reference_sha256"]
          and digest(case["audit_candidate_integer_grid"]) == case["audit_candidate_sha256"])
    events = values[host]["run/frames.json"]
    check(host + ":eight_complete_events", len(events) == 8 and sum(event["direction"] == "send" for event in events) == 4
          and all(event["status"] == "complete" and event["frame_bytes"] == event["transferred_bytes"] for event in events))
    counters = {"send": 0, "receive": 0}
    packets = {}
    for event in events:
        wire = retained["run/frames/" + event["wire_sha256"]]
        check(host + ":wire:" + event["wire_sha256"], len(wire) == event["frame_bytes"] and sha(wire) == event["wire_sha256"]
              and len(wire) >= 5 and struct.unpack("!I", wire[:4])[0] == len(wire) - 4 <= 65536)
        packet = decode(wire[4:])
        direction = event["direction"]
        sender = node if direction == "send" else 1 - node
        sequence = counters[direction]
        kinds = ("hello", "contribution", "summary", "commit" if sender == 0 else "complete")
        check(host + ":envelope:" + event["wire_sha256"], canonical(packet) == wire[4:]
              and set(packet) == {"schema", "round_id", "context_id", "sender", "recipient", "sequence", "kind", "body"}
              and packet["schema"] == "pft-direct-ssh-statistics-v2" and packet["round_id"] == registration["round_id"]
              and packet["context_id"] == registration["context_id"] and packet["sender"] == sender
              and packet["recipient"] == 1 - sender and packet["sequence"] == sequence and packet["kind"] == kinds[sequence]
              and all(type(packet[key]) is int for key in ("sender", "recipient", "sequence")))
        packets[(sender, sequence)] = packet
        counters[direction] += 1
    frame_packets[host] = packets
    check(host + ":result_transfers_match_retained_events", values[host]["run/result.json"]["transfers"] == events)

left, right = (files[host] for host in ("pocket4", "ai395"))
check("both_sides_exact_wire_bytes", {k: v for k, v in left.items() if k.startswith("run/frames/")} ==
      {k: v for k, v in right.items() if k.startswith("run/frames/")})
check("both_sides_inverse_event_sequence", all(a["wire_sha256"] == b["wire_sha256"] and a["direction"] != b["direction"]
      for a, b in zip(values["pocket4"]["run/frames.json"], values["ai395"]["run/frames.json"])))
check("both_sides_exact_ledger", left["run/ledger.json"] == right["run/ledger.json"])
check("both_sides_same_terminal_gate", bundles["pocket4"]["initiator_terminal_gate"] == bundles["ai395"]["initiator_terminal_gate"])
execution = values["pocket4"]["EXECUTION_RESULT.json"]
gate = bundles["pocket4"]["initiator_terminal_gate"]
check("execution_raw_hash_is_gate_anchor", sha(left["EXECUTION_RESULT.json"]) == gate["execution_result_sha256"])
check("execution_gate_identity_fields_exact", {k: v for k, v in execution.items() if k != "started_unix_ns"} ==
      {k: v for k, v in gate["execution"].items() if k != "started_unix_ns"})
projection_difference = gate["execution"]["started_unix_ns"] - execution["started_unix_ns"]
check("known_non_authoritative_timestamp_projection", projection_difference == 49)
check("outer_definite_cleanup", execution["status"] == "COMPLETE" and execution["exit_code"] == 0
      and execution["cleanup"]["state"] == "TERMINAL" and execution["cleanup"]["errors"] == []
      and execution["observed_exit_without_reaping"] == 0 and execution["wall_seconds"] < 55
      and execution["application_end"] == values["pocket4"]["run/END.json"]
      and execution["application_end"]["ssh_child_exit_code"] == 0
      and execution["application_end"]["ssh_stderr_eof"] is True
      and all(not observation["original_still_running"] for observation in execution["cleanup"]["ssh_observations"]))

config = configs["pocket4"]
argv = values["pocket4"]["run/SSH_ARGV.json"]
check("fixed_native_ssh_program", argv[:5] == ["/usr/bin/ssh", "-F", "/dev/null", "-T", "-v"]
      and all(argv[index] == "-o" for index in range(5, len(argv) - 2, 2)))
options = dict(item.split("=", 1) for item in argv[6:-2:2])
peer = config["roster"][1]
remote = shlex.join([peer["python"], peer["stage"] + "/ssh_snapshot.py", peer["stage"] + "/SSH_CONFIG.json",
                     "--expected", config["remote_config_sha256"]])
check("fixed_native_ssh_trust_and_target", argv[-2:] == [peer["alias"], remote]
      and options["Hostname"] == peer["address"] and options["User"] == peer["user"] and options["Port"] == "22"
      and options["StrictHostKeyChecking"] == "yes" and options["UpdateHostKeys"] == "no"
      and options["IdentityFile"] == config["ssh"]["identity_file"] and options["UserKnownHostsFile"] == config["ssh"]["known_hosts"]
      and options["HostKeyAlias"] == config["ssh"]["host_key_alias"] and options["KnownHostsCommand"] == "none"
      and options["ProxyJump"] == "none" and options["ProxyUseFdpass"] == "yes" and options["IdentityAgent"] == "none"
      and options["ProxyCommand"] == shlex.join(["/usr/bin/python3", config["ssh"]["guard"], "--inventory", config["ssh"]["inventory"], "--peer", peer["alias"], "--verbose"]))
stderr = left["run/SSH.stderr"].decode()
check("bounded_actual_ssh_diagnostics", len(left["run/SSH.stderr"]) <= 65536
      and "Server host key: ssh-ed25519 " + config["ssh"]["server_host_key"] in stderr
      and any("Server accepts key:" in line and config["ssh"]["client_public_key"] in line for line in stderr.splitlines())
      and 'using "publickey"' in stderr)
reports = [decode(line) for line in stderr.splitlines() if line.startswith("{")]
check("one_bound_usb4_attempt", len(reports) == 1 and len(reports[0]["attempts"]) == 1)
selected = reports[0]["selected"]
connection = values["pocket4"]["run/result.json"]["ssh_connection"]
check("observed_direct_endpoints", selected["status"] == "connected" and selected["transport"] == "usb4"
      and selected["interface_bound"] is True and selected["interface_policy"] == "required"
      and selected["interface"] == config["roster"][0]["interface"]
      and selected["local_address"] == connection["client"] and selected["remote_address"] == connection["server"]
      and connection["client"][0] == config["roster"][0]["address"] and connection["server"] == [peer["address"], 22]
      and values["ai395"]["run/result.json"]["ssh_connection"] == connection)

packets = frame_packets["pocket4"]
for node, host in enumerate(("pocket4", "ai395")):
    identity = packets[(node, 0)]["body"]["identity"]
    own_start = values[host]["run/STARTED.json"]
    check(host + ":hello_is_original_runtime", all(identity[key] == own_start[key] for key in identity))
    check(host + ":summary_is_original_candidate", packets[(node, 2)]["body"] == values[host]["run/CANDIDATE.json"])
commit = packets[(0, 3)]["body"]
check("mutually_confirmed_summaries", commit == {"initiator_summary_sha256": digest(packets[(0, 2)]["body"]),
      "responder_summary_sha256": digest(packets[(1, 2)]["body"])}
      and packets[(1, 3)]["body"] == {"commit_sha256": digest(commit)})

ledger = values["pocket4"]["run/ledger.json"]
body = ledger["body"]
check("ledger_body_integrity", digest(body) == ledger["body_sha256"])
messages = sorted(body["messages"], key=lambda item: item["contribution_id"])
check("two_original_contributions_only", len(messages) == 2 and len({item["data_sha256"] for item in messages}) == 2
      and [item["contribution_id"] for item in messages] == sorted(config["frozen"]["expected_contribution_ids"]))
for message in messages:
    node = int(message["client_id"])
    check("contribution_origin_" + str(node), message == packets[(node, 1)]["body"]
          and message["payload_sha256"] == config["frozen"]["expected_contributions"][node]
          and message["contribution_id"] == config["frozen"]["expected_contribution_ids"][node]
          and message["payload_sha256"] == digest({k: v for k, v in message.items() if k != "payload_sha256"})
          and message["contribution_id"] == digest([message[k] for k in ("parent_id", "coordinate_id", "objective_id", "client_id", "data_sha256")]))
    check("shared_objective_" + str(node), all(message[k] == body["header"][k] for k in body["header"])
          and type(message["count"]) is int and message["count"] > 0)
parent = np.asarray(config["frozen"]["parent"], dtype=float)
check("fixed_parent_coordinate_and_objective", body["header"] == {
    "size": 8, "parent_id": array_digest(parent), "coordinate_id": array_digest(np.eye(8)),
    "objective_id": digest({"ridge": .01, "loss": "sum squared residual", "version": 1})})
gram = np.zeros((8, 8))
moment = np.zeros(8)
for message in messages:
    g, m = np.asarray(message["gram"]), np.asarray(message["moment"])
    check("finite_shapes_" + message["client_id"], g.shape == (8, 8) and m.shape == (8,) and np.isfinite(g).all() and np.isfinite(m).all())
    gram += g
    moment += m
snapshot = body["snapshot"]
check("snapshot_and_statistics_integrity", snapshot["cutoff_id"] == registration["round_id"] and snapshot["header"] == body["header"]
      and snapshot["statistics_sha256"] == digest([gram.tolist(), moment.tolist()])
      and snapshot["contributions"] == [[item["contribution_id"], item["payload_sha256"]] for item in messages]
      and snapshot["snapshot_id"] == digest({k: v for k, v in snapshot.items() if k != "snapshot_id"}))
action = np.linalg.solve(gram + .01 * np.eye(8), moment)
raw_candidate = parent + action
grid = [round(float(value) * 10 ** 10) for value in raw_candidate]
canonical_candidate = np.asarray(grid, dtype=float) / 10 ** 10
eigenvalues, eigenvectors = np.linalg.eigh((gram + gram.T) / 2)
tolerance = 64 * np.finfo(float).eps * 8 * max(1., float(max(abs(eigenvalues))))
active = eigenvalues > tolerance
directional = eigenvectors[:, active] @ ((eigenvectors[:, active].T @ moment) / (eigenvalues[active] + .01))
normal_residual = float(np.linalg.norm((gram + .01 * np.eye(8)) @ action - moment) / max(np.linalg.norm(moment), 1e-15))
directional_error = relative(directional, action)
check("independent_fixed_ridge_numerics", np.isfinite(raw_candidate).all() and grid == case["audit_candidate_integer_grid"]
      and normal_residual <= 1e-10 and directional_error <= 1e-10)
peer_errors = {}
for host in ("pocket4", "ai395"):
    candidate = values[host]["run/CANDIDATE.json"]
    error = relative(candidate["raw_candidate"], raw_candidate)
    peer_errors[host] = error
    check(host + ":independent_candidate_match", candidate["candidate_integer_grid"] == grid
          and candidate["candidate"] == canonical_candidate.tolist() and candidate["candidate_sha256"] == array_digest(canonical_candidate)
          and candidate["raw_candidate_sha256"] == array_digest(candidate["raw_candidate"])
          and candidate["ledger_sha256"] == sha(left["run/ledger.json"])
          and candidate["statistics_snapshot_id"] == snapshot["snapshot_id"]
          and candidate["effective_rank"] == int(np.count_nonzero(active)) and candidate["feature_dimension"] == 8
          and candidate["central_reference_artifact_sha256"] == sha(reference_raw)
          and candidate["central_reference_grid_sha256"] == case["audit_candidate_sha256"] and error <= 1e-12)

traffic = {host: sum(item["frame_bytes"] for item in values[host]["run/frames.json"] if item["direction"] == "send")
           for host in ("pocket4", "ai395")}
report = {
    "schema": "pft-independent-ssh-v2-originals-verification-v1", "status": "PASS_ENGINEERING_FROZEN_STATISTICS_ONLY",
    "reviewer": "authorization_delivery", "source_commit": COMMIT, "registration_sha256": REG_SHA, "unique_initiator_job_id": JOB,
    "verification_script_sha256": sha(Path(__file__).read_bytes()), "bundle_sha256": {host: value[1] for host, value in EXPECTED_BUNDLES.items()},
    "checks_passed": len(CHECKS), "checks": CHECKS, "real_network_rounds_observed": 1, "new_network_rounds_from_verifier": 0,
    "wire_frames": 8, "frame_events_per_host": 8, "raw_application_frame_bytes_sent": traffic,
    "total_unique_application_wire_bytes": sum(traffic.values()), "wire_bytes_exclude_ssh_transport_overhead": True,
    "ledger_sha256": sha(left["run/ledger.json"]), "statistics_snapshot_id": snapshot["snapshot_id"],
    "candidate_sha256": array_digest(canonical_candidate), "canonical_candidate": canonical_candidate.tolist(),
    "quantization_step": 1e-10, "effective_rank": int(np.count_nonzero(active)), "feature_dimension": 8,
    "independent_normal_residual_relative": normal_residual, "independent_directional_relative_error": directional_error,
    "independent_raw_candidate_relative_errors": peer_errors,
    "peer_raw_candidate_relative_error": relative(values["pocket4"]["run/CANDIDATE.json"]["raw_candidate"], values["ai395"]["run/CANDIDATE.json"]["raw_candidate"]),
    "quantization_relative_error": relative(raw_candidate, canonical_candidate), "observed_connection": connection,
    "original_application_pids": {host: values[host]["run/STARTED.json"]["pid"] for host in ("pocket4", "ai395")},
    "observed_wall_seconds": {"outer": execution["wall_seconds"], **{host: values[host]["run/END.json"]["wall_seconds"] for host in ("pocket4", "ai395")}},
    "cross_host_clock_synchronization_assumed": False,
    "gate_timestamp_projection": {"raw_started_unix_ns": execution["started_unix_ns"], "projected_started_unix_ns": gate["execution"]["started_unix_ns"],
                                  "difference_ns": projection_difference, "authoritative_source": "Original EXECUTION_RESULT bytes pinned by gate.execution_result_sha256; projection is not exact nanosecond evidence"},
    "method": "Independent parser/hash/envelope/ledger reconstruction and one 8-dimensional fixed-statistic solve; imports no protocol implementation",
    "limits": ["No new training/evaluation examples or research panel", "No actual A/B permission or user adoption", "No model quality or training-time advantage established", "Full effective rank 8/8 demonstrates no dimension reduction", "No Byzantine consensus or permissionless trust demonstrated", "Original TCP failures and withdrawn SSH v1 remain unchanged"],
    "old_e6_budget_spent_seconds": 0, "scientific_training_or_evaluation_runs": 0,
    "verification_wall_seconds": time.monotonic() - STARTED, "verification_process_cpu_seconds": time.process_time() - CPU_STARTED,
    "verification_python": sys.version, "verification_numpy": np.__version__,
}
output = ROOT.parent / "authorization_delivery_ssh_v2_actual_verification.json"
with output.open("x") as stream:
    json.dump(report, stream, sort_keys=True, indent=2)
    stream.write("\n")
print(json.dumps({key: value for key, value in report.items() if key != "checks"}, sort_keys=True))
print(json.dumps({"report_path": str(output), "report_sha256": sha(output.read_bytes())}))
