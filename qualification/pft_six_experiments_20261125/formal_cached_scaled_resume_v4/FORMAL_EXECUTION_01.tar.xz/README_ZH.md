# Formal cached_scaled 冷恢复单项静态候选

## 当前状态

本目录仅完成源码编写和静态核对，未运行 Python parser、formatter、import、模型、测试或工作流。尚无数值结果，不声称正式冷恢复门已通过。root 将先对唯一新增 runner 作官方格式化、收束新注册文件，再在原 runtime 中执行唯一一次注册路径。

源提交：`f9b4cdb63261c5531ac255a4f7b270893c828323`。本地保存的 13 个原文件已用 Git blob 逐个验证 13/13 一致。根 AGENTS 与已读版本相同；qualification、实验根、native_profile_v4、actual_hcsn_v2 目录均无更近 AGENTS。静态阶段“不执行”约束优先于一般格式化/测试建议。

## 修复的验证缺口

旧 `test_native_profile.py` 固定 P2P N8/S271901 parent、`actual_p2p_v2_full`、`plain_linear`，明确排除 `readout.mean`。它不能证明带训练期标准化统计量的正式 `ScaledReadout` 冷恢复。

本候选使用独立 `FORMAL_PROFILE.json`，仅接受：

- case：`n8-s2101-value_risk-full-learned-m64-lr1e-05`；
- format：`actual_hcsn_v2_selected`；
- protocol SHA256：`aad9b709d3ee6a32597487f5ae1eb2c1fc490f74d05320c4d32349fe7f09e7b8`；
- coordinate_candidate_sha256：null；
- candidate.pt：33078 bytes，SHA256 `2eeda94ea29a02119b8d7b73b2f1c355e9a052a802a5867ca5092782adc44513`；
- constructor：原 `CachedSmallHCSN` + 原 `ScaledReadout`，不替换物理实现。

旧 `PARENT_PROFILE.bytes.json` 和 raw 测试只保留在 reference 供核对，未修改、不调用。准备阶段没有解码 candidate.pt；候选 config 的具体值将在唯一实际运行中读回并完整保留。

## 数学范围与比较

沿用原无标签 12×2×6 数值刺激和 margins [0.55,0.72]，不读取训练标签或评分数据。

| 进程 | 模型构造 | forward | 时间步 |
|---|---:|---:|---:|
| 主进程完整路径 | 1 | 1 | 12 |
| 新进程第一段 | 1 | 1 | 5 |
| 另一个新进程续段 | 1 | 1 | 7 |
| **合计** | **3** | **3** | **24 个批次步** |

batch=2，因此是 **48 个轨迹步**。原提议中的 36 不是此刺激的实际计数。保存和加载动态状态不算 forward；本方案还会读回四次小型 PopulationState 对象，其中主进程三次、续段进程一次，不增加物理模型构造。初态、完整终态、cold5、cold7 均有独立状态工件。

正式 model checkpoint 本身没有五个 PopulationState 张量。其来源为原 initial_state 或 cold5 状态文件，包含 density、boundary、drift、cost、message、step、完整 config，以及原 profile/candidate/model/source/runtime 身份守卫。不能只存 density 再重建控制量。

完整 12 步 logits/features 与 5+7 拼接输出逐项比较，终点五张量以原 `rtol=1e-11, atol=1e-12` 比较；step/config 精确相等。初态/完整终态读回不重归一化。每个子结果须绑定相同 profile、checkpoint、全模型 tensor digest 和 source binding，且 diagnostics_scope 保持 this_call_only。

显式要求四个 readout 项：

```text
readout.mean
readout.scale
readout.linear.weight
readout.linear.bias
```

mean/scale 必须是真实 buffers、scale 全正；主进程逐项检查前后精确不变。两个子进程使用原加载器完整 strict=True 重载，原构造器检查四项的 float64/形状/有限性/正 scale，随后返回的全模型 tensor digest 与主进程相同，覆盖跨进程 readout 参数与 buffer 身份。

静态物理源审查确认 N8 接收侧仅读 N/2 个神经元、每个五特征，feature_dim=20；slow_every=2。runner 将它们作为运行时方案门，step5 位于控制周期中间，cold7 从 action_step=5 重建缓存并覆盖随后 step6 的刷新。这是静态推导，尚不是 checkpoint 解码观察。

## 时间与 CPU 上限

原 runtime 固定为 pocket4：

```text
/home/alex/pft-six-actual-hcsn-20261125/venv/bin/python
Python 3.14.4 / NumPy 2.5.5 / Torch 2.15.0+cpu
CPU, threads=1, interop_threads=1
```

总门为 **180 秒 wall、150 秒 CPU**，重试次数 0。脚本内部使用主进程 175 秒 active alarm 留出清理时间；两个 child 各 50 秒 alarm，并复用原 bounded_process 的 55 秒进程组守卫/最多 5 秒清理。CPU soft/hard 为主进程 50/55、两 child 各45/46；三进程 hard CPU 上限合计147秒，完成回执仍检查总 CPU 不超过150。root 外层原宿主的180秒 hard wall约束继续保留，内部 Python signal 是补充控制。

不拟合、不 backward、不优化参数、不搜索种子，不调用 E1–E6、Laya、R20 或其他 checkpoint。模型类初始化会按原实现分配参数，随后 strict 加载原完整 selected_weights；没有选择新的初始化方案或搜索。

## 输入与输出

`INPUTS.json` 列出必须提供的原材料及新命令格式。已提供 common.py、optimized.py、source_provenance.json 和原 FORMAL_PROTOCOL_v2.json；两个二进制 archive、candidate.pt 和 capsule 的25个物理源在本静态阶段没有恢复。root 可从 pocket4 已存在的原材料只读复制进新的隔离 material-root，逐项验证固定 SHA；不要使用符号链接，也不要把相近的 upstream model.py 代替冻结 capsule 版本。

运行输出目录必须不存在；脚本 exclusive create，不覆盖历史结果。保留 START、两个 task/process 回执、initial/complete/first/second PopulationState、complete.json 及 RESULT 或 FAILURE。若原宿主硬超时导致只有 START，则仍是未完成，不重试。

命令范式见 `INPUTS.json`。本目录没有执行其中的命令。

## root 的格式化后收束

1. 官方 formatter 只处理新增 `run_formal_cached_scaled_resume.py`；不要格式化 source/native_profile_v4、materials/scientific 或 reference 中的原文件。
2. 格式化后的 runner bytes/SHA 更新到本次新 `REGISTRATION.json` 的对应 source_pin，并同步 INPUTS。旧 frozen sources、protocol、candidate 及 PARENT_PROFILE 身份不变。
3. 对完整新 REGISTRATION.json 求 SHA，将它作为唯一执行命令的 `--registration-sha256`，固定后不再修改任何注册源。
4. 独立静态审查通过并且材料全齐后，由 root 在原 runtime 唯一执行。

这项通过只会证明该固定正式 checkpoint、固定刺激和 step5 截点的续算等价；不扩大为其他 checkpoint/时钟、连续时间重采样、模型收益、上线或生产资格。
