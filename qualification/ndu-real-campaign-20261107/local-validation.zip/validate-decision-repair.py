import hashlib,json,os,pathlib,platform,subprocess,time,unittest
root=pathlib.Path.cwd()
out=root.parent/'campaign-validation-20261107'/'attempt-002';out.mkdir(exist_ok=False)
source=[*root.glob('scripts/ndu_portfolio/*.py'),*root.glob('scripts/ndu_semantic_state/*.py'),*root.glob('experiments/multimodal_output_portfolio/joint_hepta_20261029/v3/decision_audit/*.py'),root/'experiments/multimodal_output_portfolio/joint_hepta_20261029/hepta_core.py',root/'.github/workflows/blocking-ci.yml',root/'experiments/multimodal_output_portfolio/joint_hepta_20261029/oracle.py',root/'experiments/multimodal_output_portfolio/unified_20261028/profile.py']
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source)}
receipt={'schema':'hepta.integrated-engineering-validation.v1','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'source_sha256':hashes,'python':platform.python_version(),'groups':[],'scope':'local engineering fixtures and real subprocess cleanup; not hosted CI, real GPU, real-source benefit, or native owner qualification','scientific_acceptance':False}
start=time.process_time(),time.perf_counter()
groups=[('decision_audit','experiments/multimodal_output_portfolio/joint_hepta_20261029/v3/decision_audit','experiments.multimodal_output_portfolio.joint_hepta_20261029.v3.decision_audit')]
for name,directory,prefix in groups:
 modules=[prefix+'.'+p.stem for p in sorted((root/directory).glob('test_*.py'))]
 suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
 began=time.process_time(),time.perf_counter()
 with (out/(name+'.log')).open('w') as stream:r=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 row={'group':name,'modules':modules,'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skips':len(r.skipped),'cpu_seconds':time.process_time()-began[0],'wall_seconds':time.perf_counter()-began[1],'log_sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()}
 receipt['groups'].append(row);print(json.dumps(row),flush=True)
 (out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
receipt['tests']=sum(x['tests'] for x in receipt['groups']);receipt['passed']=all(not(x['errors'] or x['failures'] or x['skips']) for x in receipt['groups'])
receipt.update(cpu_seconds=time.process_time()-start[0],wall_seconds=time.perf_counter()-start[1],source_unchanged=hashes=={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source)})
(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_sha256','groups')}),flush=True)
raise SystemExit(0 if receipt['passed'] and receipt['source_unchanged'] else 1)
