from pathlib import Path
import os, subprocess, json, time
root=Path(__file__).resolve().parent.parent
q=Path(__file__).resolve().parent
repo=root/'private-ci-dylint-work-20261103'
env=os.environ.copy()
env['PATH']=os.pathsep.join([str(q/'local-bazel-bin'),str(root/'matrix-toolchain-1.96.0-20261103/bin'),str(root/'recovered-tools-20261103/bin'),env['PATH']])
env['CARGO_HOME']=str(root/'private-ci-dependency-union-cargo-home-20261103')
cmd=['python3','qualification/dylint-20261103/run_lock.py','--output',str(q/'local-generated-lock-system-trust')]
started=time.monotonic()
with (q/'local-system-trust-lock-driver.log').open('wb') as out:
    completed=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
receipt={'command':cmd,'exit':completed.returncode,'elapsed_seconds':time.monotonic()-started,'startup_options':['--batch','--host_jvm_args=-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts','--output_user_root='+str(q/'bazel-state')]}
(q/'local-system-trust-lock-driver.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
raise SystemExit(completed.returncode)
