# Signed-only supplemental control

This is a descriptive supplement registered after the main 72 results were available. It reuses the main train/development/test families, including the now-public test family; it is not a fresh holdout or part of the original preregistered 72-case qualification. The main artifacts and selection remain unchanged.

Only the persistent recurrent topology changes: original `message_mode='flow'` removes boundary messages, and `synaptic_mask[:, N:2*N] = 0` removes unsigned event-rate messages. Thus the only signal transmitted between populations is signed event flow. Local probability, value, risk, and readout state remain present. Sender populations receive the same raw input; receiver populations have no direct raw-input route.

The original 14 source files, data, seed initialization, per-width backend, 180 training-CPU-second / 512-update cap, optimizer, and development-only checkpoint selection are retained. A separately bound factory substitution is applied only inside each fresh training worker. Saved masks permit the original core model to reload the control without any factory patch at test time. All nine terminal records and checkpoint masks are checked and sealed before any supplemental test data are constructed.

`run.py` is a Linux operator-specific experiment driver: its `resource` accounting and `ru_maxrss * 1024` conversion target the existing Linux CPU host. The neural model core is unchanged. Each worker uses one Torch thread; nine workers may execute concurrently. Report worker/parent/stage costs separately, retain errors, and do not convert CPU time to energy.

`summarize.py` is read-only postprocessing. Numerical learning thresholds are reused descriptively; three seeds and the same synthetic source family do not establish out-of-distribution or foundation-model superiority. Comparisons to main `qvi_flow` distinguish signed-only transmission from the main unsigned-plus-signed flow condition.
