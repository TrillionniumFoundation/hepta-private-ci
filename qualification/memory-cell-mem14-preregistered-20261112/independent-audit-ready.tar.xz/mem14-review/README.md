# Independent MEM14 readback audit

This is independent standard-library Python code. It does not import the
experiment, invoke child processes, load models, call providers, retokenize
outputs or execute commands remotely. SQLite is opened with `mode=ro&immutable=1`
and `PRAGMA query_only=ON`. Output directories are created exclusively outside
the supplied original evidence directory.

The three audit modules are frozen together before the complete MEM14 results
are read. `FROZEN_AUDIT.json` pins all required files. `preparation-frozen` records
the successful plan/source/launch/grammar/statistics validation. The only prior
outcome-bearing material used during implementation was one already published
MEM12 source's ten arms, solely to validate original-byte/custody checks; no
scoring function was called on those old rows. See `EVIDENCE_VALIDATION.json`.

## Run

From a directory containing this `mem14-review` folder:

```sh
python -B mem14-review/audit.py --prepare --out mem14-review/audit-preparation-new
python -B mem14-review/audit.py --original /absolute/path/to/unpacked/original \
  --archive /absolute/path/to/evidence.tar.xz \
  --archive-sha256 SHA256_OBSERVED_FROM_ORIGINAL_JOB \
  --archive-bytes ORIGINAL_ARCHIVE_BYTE_COUNT \
  --out /absolute/path/to/new-independent-review
```

The original directory must contain `cohort`, `source/scripts`, `EVIDENCE_INDEX.json`,
`PREPARE_RESULT.json`, `EXECUTION_SPEC.json`, `run_campaign_remote.py`, and
`RUN_SUMMARY.json`, as stored by the frozen run helper. No extraction or write to
the supplied original directory is performed by the audit.

The supplied archive hash and length must come from independently recovered run
metadata. Archive verification checks the exact member set, every retained
member and the exact index bytes against the unpacked originals. Without an
archive, retained-file validation can run but archive provenance is explicitly
`NOT_SUPPLIED`.

## Frozen scope

- Plan: `1aa291205146cffec039a583640be9c9c33a4afedff8dc31d2cdf32874d4c8e0`.
- Execution source: `7f6b5b80cf4528aabd44ad2df1a93d7f70e7590d`.
- Source tree: `491484a45e05d05d2b72fec472f96405c37decac`.
- Run helper: `3329cecaabcaed30d733e40af322942f5486cc53db387e804416e1d9c10524f2`.
- Original durable job: `1a1ced26052-2564-186f`.
- Operation key: `mem14-causal-execute-20261112-ef0c-v1`.
- 32 fresh sources, ten arms each; one common generated task template and one
  retrieved-record cap. Every planned source remains in each denominator.
- Primary public endpoint is frozen v2. Strict v1 is a descriptive endpoint.
  Bare UNKNOWN is a valid v2 format but is never the correct color.
- Primary contrast is BM25 minus full memory-off. Paired differences lie in
  `[-1, 1]`. Missing labels first receive worst-case per-source difference
  bounds. Primary one-sided Hoeffding uses `sqrt(2*log(20)/32)`; all nine
  simultaneous contrasts use `sqrt(2*log(180)/32)`.

The audit independently reconstructs memory retrieval, actor requests, chat
wrapping, scores, paired bounds, replacement follow-through and costs. The
four empty-delivery arms are compared on exact requests, model-input records,
rendered prompts and tensors. BM25 and exact-KV inputs are compared separately.
Unknown execution is never converted to a known zero model count.

## Provenance and interpretation

Frozen plan/preexecution references came from published evidence commit
`fe11230642106872a71c7cc1f1d131a0abfbbb14`; exact launch references came from
`760796e95c7db4e5c6906a9a59374fe477ecde09`. Required source files were restored
from execution commit `7f6b5b80cf4528aabd44ad2df1a93d7f70e7590d` or byte-identical
files in the previously published MEM12 original archive; all twelve match the
actual frozen plan's SHA256 pins. The legacy plan came from archive SHA256
`29ab6cde66622dd76ebee5cf65ae51c6c17dbbbbe0a66b7b7626d77358782e05`, published at
`2bcb8e5f16c0b544294f11a1eafa1bfc281cc714`.

This audit verifies retained-byte consistency. It does not authenticate the
physical host or promote research Python SQLite, deterministic A ingestion or
this text selector to the production native owner, a learned association system
or the original MEM5 OCR selector. Scientific acceptance remains HOLD and broad
production/natural-task/parameter-consolidation claims remain false.

If an audit implementation defect is found during readback, preserve this
checkpoint and record an explicit code revision and reason before running the
new version. The experiment plan, parser, original scores and raw evidence stay
fixed.
