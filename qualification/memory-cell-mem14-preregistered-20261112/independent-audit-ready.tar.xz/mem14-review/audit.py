#!/usr/bin/env python3
"""Independent MEM14 audit. Standard library only; no campaign/model imports.

Use --prepare to check frozen materials and all missing-pair states without
reading outcomes. Use --original only after a frozen run is complete/read back.
The output directory is created exclusively and must be outside the originals.
"""
import argparse
import ast
import base64
from collections import Counter
import json
import math
from pathlib import Path, PurePosixPath
import re
import sqlite3
import sys
import tarfile

from analysis import ARMS, EMPTY, COLORS, N, V1, V2_WORD, V2_SENTENCE, contrast, selected_v1, selected_v2, self_check
from evidence import Checks, EvidenceError, canon, digest, literal, pin, raw, read, valid_number, verify_writer, verify_returned

HERE = Path(__file__).resolve().parent
REFERENCE = HERE / "reference"
PLAN_PIN = {"bytes": 30299, "sha256": "1aa291205146cffec039a583640be9c9c33a4afedff8dc31d2cdf32874d4c8e0"}
SOURCE_COMMIT = "7f6b5b80cf4528aabd44ad2df1a93d7f70e7590d"
SOURCE_TREE = "491484a45e05d05d2b72fec472f96405c37decac"
HELPER_SHA = "3329cecaabcaed30d733e40af322942f5486cc53db387e804416e1d9c10524f2"
JOB_ID = "1a1ced26052-2564-186f"
RUN_KEY = "mem14-causal-execute-20261112-ef0c-v1"
COST_KEYS = ("prompt_tokens", "output_tokens", "wall_seconds", "provider_wall_seconds_with_setup",
             "user_cpu_seconds", "system_cpu_seconds", "read_wall_seconds", "read_cpu_seconds")
BOUNDARIES = [
    "32 generated sources share one task template; 320 rows are not 320 independent sources.",
    "The v2 endpoint was designed after MEM12 but frozen before these new sources generated responses. MEM12 is never rescored.",
    "A is deterministic ingestion with no model call; retained state uses research Python SQLite, not the production native owner.",
    "All returned model requests, rendered prompts and tokenizer tensors are checked against original logs and hash bindings; this audit does not retokenize or generate.",
    "This establishes retained-byte consistency, not authentication of the physical host, observer, original native owner or provider internals.",
    "Isolation records new network/mount/PID/IPC/UTS/user namespaces and empty task-state roots; system roots and frozen model/runtime assets remain mounted read-only.",
    "One local model.generate invocation per returned row is evidenced by frozen worker code and one log record; internal forward steps and KV-cache accesses are not observed.",
    "Equal limits do not imply equal actual costs. Common A cost is charged once; missing costs remain missing.",
    "Hoeffding bounds assume independent generated sources under this one template. They do not establish natural-task generalization.",
    "No trained association, parameter consolidation, authenticated production recovery or broad deployment benefit was evaluated.",
]


def audit_pins():
    return {name: pin(raw(HERE / name)) for name in ("analysis.py", "evidence.py", "audit.py")}


def preflight(checks):
    check = checks.require
    plan_raw = raw(REFERENCE / "MEM14_PLAN.json")
    check(pin(plan_raw) == PLAN_PIN, "frozen_reference_plan")
    plan = json.loads(plan_raw)
    old_raw = raw(REFERENCE / "MEM12_PLAN.json")
    check(pin(old_raw) == {"bytes": 10624, "sha256": "f623a23197fe94b3d5434ffac1f02cb3d99398ca4c69aad18716dbeeef1b2d82"}, "legacy_reference_plan_pin")
    old = json.loads(old_raw)
    prep = read(REFERENCE / "PREEXECUTION.json")
    check(pin(raw(REFERENCE / "PREEXECUTION.json"))["sha256"] == "a9a047e0ac5ea6829b8bc67fcc67b0a9b79c7edb826eb9f0f99490f981bee783",
          "frozen_preexecution_publication")
    check(plan["schema"] == "hepta.mem14.controlled-diagnostic.v1" and plan["selector_version"] == "v2"
          and plan["source_count"] == len(plan["cases"]) == N and set(plan["arms"]) == set(ARMS), "frozen_version_denominator")
    check(plan["limits"] == {"context_bytes": 2048, "input_tokens": 1024, "output_tokens": 32,
                              "provider_seconds": 60, "retrieval_records": 1}, "frozen_equal_limits")
    check(plan["analysis"] == prep["remote_preparation"]["analysis"]
          and plan["analysis"]["primary_contrast"] == "on_bm25 minus off"
          and plan["analysis"]["alpha"] == 0.05 and plan["analysis"]["simultaneous_contrasts"] == 9
          and plan["analysis"]["difference_range"] == [-1, 1], "frozen_statistical_contract")
    check(old["schema"] == "hepta.mem12.controlled-diagnostic.v1" and "selector_version" not in old
          and len(old["cases"]) == 8 and old["limits"]["retrieval_records"] == 2, "legacy_reference_unchanged")
    check(all(plan[k] == old[k] for k in ("actor", "provider_worker", "profile", "arms")), "old_actor_worker_profile_identical")
    old_keys = {f["key"] for c in old["cases"] for f in c["facts"]}
    new_keys = {f["key"] for c in plan["cases"] for f in c["facts"]}
    old_ids = {":".join((old["cohort_id"], c["case_id"], a)) for c in old["cases"] for a in ARMS}
    new_ids = {":".join((plan["cohort_id"], c["case_id"], a)) for c in plan["cases"] for a in ARMS}
    check(len(new_keys) == 96 and not new_keys & old_keys and not new_ids & old_ids and len(new_ids) == 320,
          "fresh_source_keys_and_request_ids")
    for i, case in enumerate(plan["cases"], 1):
        cid = f"source-{i:02d}"
        check(case["case_id"] == case["source_id"] == cid and len(case["facts"]) == 3
              and len(case["arm_order"]) == 10 and set(case["arm_order"]) == set(ARMS), "planned_source_and_arm_roster", cid)
        task = case["public_task"]
        check(set(task) == {"key", "model", "query", "question"}
              and task["model"] == plan["profile"]["model_name"]
              and task["query"] == task["key"] + " badge color"
              and task["question"] == f"What color badge must the courier use for {task['key']}?", "public_task_no_truth", cid)
        check(case["truth"] in COLORS and case["replacement"] == COLORS[(COLORS.index(case["truth"])+1) % 8]
              and next(f["color"] for f in case["facts"] if f["key"] == task["key"]) == case["truth"], "frozen_truth_replacement", cid)
        check(len({f["color"] for f in case["facts"]}) == 3 and all(
            f["text"] == f"{f['key']} requires a {f['color']} badge." and f["color"] in COLORS
            for f in case["facts"]), "three_frozen_source_facts", cid)
    for name, expected in plan["sources"].items():
        check(pin(raw(REFERENCE / "source/scripts" / name)) == expected, "reference_source_pin", name)
    source = REFERENCE / "source/scripts/ndu_real_runtime"
    actor, worker, bootstrap = (literal(source / name, variable) for name, variable in (
        ("run_episodic_diagnostic.py", "ACTOR"), ("episodic_local_worker.py", "WORKER"), ("episodic_isolation.py", "_BOOTSTRAP")))
    check(pin(actor) == plan["actor"] and pin(worker.encode()) == plan["provider_worker"], "reference_actor_worker_pins")
    parser = next(n for n in ast.parse(raw(source / "episodic_diagnostic_report.py")).body
                  if isinstance(n, ast.FunctionDef) and n.name == "selected_text")
    check(V1 in [n.value for n in ast.walk(parser) if isinstance(n, ast.Constant)], "strict_v1_parser_identity")
    parser2 = next(n for n in ast.parse(raw(source / "episodic_diagnostic_protocol.py")).body
                   if isinstance(n, ast.FunctionDef) and n.name == "selected_v2")
    constants = [n.value for n in ast.walk(parser2) if isinstance(n, ast.Constant)]
    check([a.arg for a in parser2.args.args] == ["value"] and "|".join(COLORS) in constants
          and "the courier must use a (" in constants and r") badge\." in constants, "v2_label_free_parser_identity")
    args_raw, launch_raw = raw(REFERENCE / "FROZEN_ARGS.json"), raw(REFERENCE / "CONFIRMED_LAUNCH.json")
    check(pin(args_raw)["sha256"] == "c5fba46e3b25714a85915640afe6996a53b89ed03951651a04a38cde7f64fe7e"
          and pin(launch_raw)["sha256"] == "e9a68493ccc377f13da3f50c020498252e15052bb00c8970b78201df144a7ed4", "launch_reference_pins")
    args, launch_envelope = json.loads(args_raw), json.loads(launch_raw)
    launch = json.loads(launch_envelope["content"][0]["text"])
    job = launch["job"]
    check(job["id"] == JOB_ID and job["idempotency_key"] == args["idempotency_key"] == RUN_KEY
          and job["args"] == ["-c", args["command"]] and job["cwd"] == args["cwd"] == prep["spec"]["root"]
          and job["host"] == args["host"] == "ai395" and args["timeout_seconds"] == 21600
          and args["env"] == {"PYTHONDONTWRITEBYTECODE": "1"} and job["env_keys"] == ["PYTHONDONTWRITEBYTECODE"]
          and job["launch_state"] == "launched" and launch["launch"]["ok"] is True and launch["reused"] is False,
          "one_frozen_outer_job_binding")
    encoded = re.findall(r"base64\.b64decode\('([A-Za-z0-9+/=]+)'\)", args["command"])
    check(len(encoded) == 1, "one_embedded_run_helper")
    helper = base64.b64decode(encoded[0], validate=True)
    check(pin(helper)["sha256"] == prep["spec"]["run_helper_sha256"] == HELPER_SHA, "frozen_helper_payload_pin")
    check(prep["spec"]["source_commit"] == SOURCE_COMMIT and prep["spec"]["source_tree"] == SOURCE_TREE
          and prep["spec"]["outer_run_deadline_seconds"] == 21600
          and plan["registered_at_unix_ns"] < job["created_unix_ms"]*1_000_000, "frozen_launch_chronology")
    return plan, actor, bootstrap, helper, prep, job


def verify_index(root, checks, *, category):
    index = read(root / "EVIDENCE_INDEX.json")
    for name, expected in index.items():
        parts = PurePosixPath(name)
        checks.require(not parts.is_absolute() and ".." not in parts.parts, "safe_index_path", name)
        path = root / name
        checks.require(not any(p.is_symlink() for p in [path, *path.parents] if p != root.parent), "no_original_symlink", name)
        checks.require(pin(raw(path)) == expected, category, name)
    return index


def verify_archive(path, sha256, expected_bytes, root, index, checks):
    if path is None:
        return {"status": "NOT_SUPPLIED", "sha256": None, "bytes": None}
    got = pin(raw(path))
    checks.require(got == {"bytes": expected_bytes, "sha256": sha256}, "external_archive_pin")
    with tarfile.open(path, "r:xz") as archive:
        names = archive.getnames()
        checks.require(len(names) == len(set(names)) == len(index)+1
                       and set(names) == set(index) | {"EVIDENCE_INDEX.json"}, "archive_exact_members")
        for name, expected in index.items():
            checks.require(archive.getmember(name).isfile() and pin(archive.extractfile(name).read()) == expected,
                           "archive_member_hash", name)
        checks.require(archive.extractfile("EVIDENCE_INDEX.json").read() == raw(root / "EVIDENCE_INDEX.json"), "archive_index_bytes")
    return {"status": "VERIFIED", **got, "indexed_members": len(index)}


def observed(values, maximum=False):
    known = [v for v in values if valid_number(v)]
    return {"observed_max" if maximum else "observed_sum": (max(known) if known else None) if maximum else sum(known),
            "observed_rows": len(known), "missing_rows": len(values)-len(known)}


def same_value(a, b):
    if type(a) in (int, float) and type(b) in (int, float):
        return math.isclose(a, b, rel_tol=0, abs_tol=1e-8)
    return a == b


def compare_subset(expected, reported, checks, category, identity=""):
    for key, value in expected.items():
        check_id = identity + "/" + key
        if key not in reported:
            checks.check(False, category, check_id)
        elif isinstance(value, dict):
            compare_subset(value, reported[key], checks, category, check_id)
        else:
            checks.check(same_value(value, reported[key]), category, check_id)


def audit_original(root, archive, archive_sha, archive_bytes, checks):
    plan, actor, bootstrap, helper, prepared, job = preflight(checks)
    cohort = root / "cohort"
    checks.require(raw(cohort / "PLAN.json") == raw(REFERENCE / "MEM14_PLAN.json")
                   and read(cohort / "PLAN_PIN.json") == PLAN_PIN and raw(cohort / "ACTOR.py") == actor,
                   "actual_plan_and_actor_frozen")
    index = verify_index(root, checks, category="indexed_original_hash")
    archive_info = verify_archive(archive, archive_sha, archive_bytes, root, index, checks)
    for name, expected in plan["sources"].items():
        checks.require(pin(raw(root / "source/scripts" / name)) == expected, "actual_source_pin", name)
    prep, spec, summary = (read(root / name) for name in ("PREPARE_RESULT.json", "EXECUTION_SPEC.json", "RUN_SUMMARY.json"))
    saved_report = read(cohort / "REPORT.json") if (cohort / "REPORT.json").exists() else None
    checks.require(prep == prepared["remote_preparation"] and spec == prepared["spec"], "actual_frozen_preparation_and_spec")
    checks.require(summary["source_commit"] == SOURCE_COMMIT and summary["source_tree"] == SOURCE_TREE
                   and summary["protocol_sha256"] == PLAN_PIN["sha256"]
                   and raw(root / "run_campaign_remote.py") == helper
                   and summary["outer_supervisor_deadline_seconds"] == 21600, "actual_run_source_helper_and_deadline")
    checks.require(job["created_unix_ms"]*1_000_000 <= summary["started_at_unix_ns"] < summary["ended_at_unix_ns"], "run_after_original_launch")
    rows, writers, actual, equality, replacements, exact_equality = [], [], {}, [], [], []
    errors = (OSError, ValueError, KeyError, TypeError, StopIteration, sqlite3.Error)
    for case in plan["cases"]:
        cid = case["case_id"]
        try:
            writer = verify_writer(cohort, plan, case, checks)
            writers.append({"case_id": cid, "status": "VERIFIED_CONSISTENT", "wall_seconds": writer["wall_seconds"]})
        except errors as error:
            writer = None
            writers.append({"case_id": cid, "status": "UNAVAILABLE_OR_INVALID", "wall_seconds": None, "reason": str(error)})
        for arm in ARMS:
            d = cohort / cid / arm
            row = {"case_id": cid, "arm": arm, "truth": case["truth"], "replacement": case["replacement"],
                   "status": "UNKNOWN" if d.exists() else "UNATTEMPTED",
                   "physical_generations": None if d.exists() else 0, "primary_correct": None,
                   "primary_selected": None, "v1_correct": None, "v1_selected": None}
            try:
                if (d / "ROW.json").exists():
                    retained = read(d / "ROW.json")
                    checks.require(retained["case_id"] == cid and retained["arm"] == arm
                                   and retained["protocol_sha256"] == PLAN_PIN["sha256"], "retained_row_identity", cid+"/"+arm)
                    row["reported_status"] = retained["status"]
                    for key in ("wall_seconds", "provider_wall_seconds_with_setup"):
                        if valid_number(retained.get(key)):
                            row[key] = retained[key]
                    if retained["status"] == "RETURNED":
                        if writer is None:
                            raise EvidenceError("A writer unavailable or invalid")
                        facts, actual[(cid, arm)] = verify_returned(cohort, plan, case, arm, writer, actor, bootstrap, checks)
                        row.update(facts, status="RETURNED", physical_generations=1)
                        selected, old_selected = selected_v2(facts["text"]), selected_v1(facts["text"])
                        row.update(primary_selected=selected, primary_correct=selected == case["truth"],
                                   v1_selected=old_selected, v1_correct=old_selected == case["truth"])
                        checks.check(type(retained["correct"]) is bool and retained["correct"] is row["primary_correct"],
                                     "independent_ROW_primary_score", cid+"/"+arm)
                    else:
                        row["status"] = retained["status"]
                        if (retained["status"] in ("SETUP_FAILED", "WRITER_UNAVAILABLE", "ACTOR_UNAVAILABLE")
                                and type(retained.get("physical_generations")) is int
                                and retained["physical_generations"] == 0 and not (d / "provider").exists()):
                            row["physical_generations"] = 0
                        else:
                            row["physical_generations"] = None
                elif not d.exists():
                    row["status"] = "UNATTEMPTED"
            except errors as error:
                row.update(status="EVIDENCE_INVALID", physical_generations=None, primary_correct=None,
                           primary_selected=None, v1_correct=None, v1_selected=None, reason=str(error))
                actual.pop((cid, arm), None)
            rows.append(row)
        if all((cid, a) in actual for a in EMPTY):
            reference = actual[(cid, "off")]
            eq = {k: all(actual[(cid, a)][k] == reference[k] for a in EMPTY) for k in reference}
            checks.check(all(eq[k] for k in ("request_bytes", "model_input_bytes", "tensors", "rendered_prompt")), "four_empty_arm_inputs_identical", cid)
            equality.append({"case_id": cid, "status": "COMPARED", **eq})
        else:
            equality.append({"case_id": cid, "status": "UNAVAILABLE", "missing_arms": [a for a in EMPTY if (cid, a) not in actual]})
        if all((cid, arm) in actual for arm in ("on_bm25", "exact_kv")):
            eq = {key: actual[(cid, "on_bm25")][key] == actual[(cid, "exact_kv")][key]
                  for key in actual[(cid, "on_bm25")]}
            exact_equality.append({"case_id": cid, "status": "COMPARED", **eq})
        else:
            exact_equality.append({"case_id": cid, "status": "UNAVAILABLE"})
    valid_rows = [r for r in rows if r["status"] == "RETURNED"]
    checks.check(len({r["actor_session_id"] for r in valid_rows}) == len(valid_rows)
                 and len({r["actor_launcher_pid"] for r in valid_rows}) == len(valid_rows), "fresh_C_sessions_processes")
    panels, costs, contrasts = {}, {}, {}
    by_id = {(r["case_id"], r["arm"]): r for r in rows}
    for arm in ARMS:
        group = [by_id[(c["case_id"], arm)] for c in plan["cases"]]
        known = sum(r["primary_correct"] is not None for r in group)
        success = sum(r["primary_correct"] is True for r in group)
        panels[arm] = {
            "planned": N, "scored": known, "successes": success, "missing": N-known,
            "statuses": dict(Counter(r["status"] for r in group)),
            "missing_label_rate_bounds": [success/N, (success+N-known)/N],
            "v1_descriptive": {"scored": known, "missing": N-known, "successes": sum(r["v1_correct"] is True for r in group),
                               "format_accepted": sum(r["v1_selected"] is not None for r in group)},
            "v2_format_accepted": sum(r["primary_selected"] is not None for r in group),
            "v2_unknown_outputs": sum(r["primary_selected"] == "unknown" for r in group),
            "relevant_key_delivered": sum(r.get("relevant_key_delivered") is True for r in group),
            "retrieved_records": observed([r.get("retrieved_records") for r in group]),
            "delivered_records": observed([r.get("delivered_records") for r in group]),
        }
        costs[arm] = {key: observed([r.get(key) for r in group]) for key in COST_KEYS}
        costs[arm]["peak_rss_kib"] = observed([r.get("max_rss_kib") for r in group], maximum=True)
        compare_subset({k: costs[arm][k] for k in ("prompt_tokens", "output_tokens", "wall_seconds", "provider_wall_seconds_with_setup")},
                       summary["measured_costs_by_arm"][arm], checks, "independent_cost_sum", arm)
        compare_subset({k: panels[arm][k] for k in ("planned", "scored", "successes", "missing", "missing_label_rate_bounds", "v1_descriptive")},
                       summary["panels"][arm], checks, "independent_panel_sum", arm)
        if arm == "on_bm25":
            continue
        a = [by_id[(c["case_id"], "on_bm25")]["primary_correct"] for c in plan["cases"]]
        b = [by_id[(c["case_id"], arm)]["primary_correct"] for c in plan["cases"]]
        result = contrast(a, b)
        if arm != "off":
            del result["primary_hoeffding_lower_95"]
        contrasts[arm] = {"contrast": "on_bm25 minus " + arm, **result}
        compare_subset({k: contrasts[arm][k] for k in ("contrast", "planned_pairs", "missing_label_difference_bounds",
                       "paired_mean_difference", "bonferroni_hoeffding_lower_95")}, summary["contrasts"][arm], checks, "independent_paired_bound", arm)
        if arm == "off":
            checks.check(same_value(result["primary_hoeffding_lower_95"], summary["contrasts"][arm]["primary_hoeffding_lower_95"]), "independent_primary_bound")
    for case in plan["cases"]:
        before, after = (by_id[(case["case_id"], arm)] for arm in ("on_bm25", "replace"))
        observed_pair = before["primary_correct"] is not None and after["primary_correct"] is not None
        replacements.append({"case_id": case["case_id"], "truth": case["truth"], "replacement": case["replacement"],
            "pair_status": "OBSERVED" if observed_pair else "MISSING", "on_text": before.get("text"), "replace_text": after.get("text"),
            "on_selected_v2": before["primary_selected"], "replace_selected_v2": after["primary_selected"],
            "replacement_selected": after["primary_selected"] == case["replacement"] if after["primary_correct"] is not None else None,
            "output_changed": before["text"] != after["text"] if observed_pair else None,
            "newly_selected_replacement": before["primary_selected"] != case["replacement"] and after["primary_selected"] == case["replacement"] if observed_pair else None,
            "truth_to_replacement_change": before["primary_selected"] == case["truth"] and after["primary_selected"] == case["replacement"] if observed_pair else None})
    if saved_report is not None:
        checks.check(saved_report["protocol_sha256"] == PLAN_PIN["sha256"] and len(saved_report["rows"]) == 320
                     and len({(r["case_id"], r["arm"]) for r in saved_report["rows"]}) == 320, "saved_report_complete_roster")
        for retained in saved_report["rows"]:
            row = by_id.get((retained["case_id"], retained["arm"]))
            checks.check(row is not None and retained["correct"] is row["primary_correct"]
                         and retained.get("v1_correct") is row["v1_correct"], "independent_saved_report_score", retained["case_id"]+"/"+retained["arm"])
    else:
        checks.check(False, "saved_report_present")
    totals = {key: observed([r.get(key) for r in rows]) for key in COST_KEYS}
    totals.update(peak_rss_kib=observed([r.get("max_rss_kib") for r in rows], maximum=True),
                  common_A_wall_seconds=observed([w["wall_seconds"] for w in writers]),
                  common_A_charged_once=True,
                  run_wall_seconds=(summary["ended_at_unix_ns"]-summary["started_at_unix_ns"])/1e9,
                  prepare_wall_seconds=(prep["ended_at_unix_ns"]-prep["started_at_unix_ns"])/1e9,
                  archive_and_readback_wall_seconds=None)
    compare_subset(totals["common_A_wall_seconds"], summary["common_A_writer_cost"]["wall_seconds"], checks, "independent_common_A_cost")
    checks.check(summary["common_A_writer_cost"]["charged_once"] is True, "common_A_charged_once")
    totals["cost_per_correct_returned_tokens"] = {
        arm: ((costs[arm]["prompt_tokens"]["observed_sum"] + costs[arm]["output_tokens"]["observed_sum"])/panels[arm]["successes"]
              if panels[arm]["successes"] and not panels[arm]["missing"] else None) for arm in ARMS}
    checks.check(summary["known_returned_generations"] == len(valid_rows)
                 and summary["unsettled_generation_rows"] == sum(r["physical_generations"] is None for r in rows)
                 and summary["planned_rows"] == 320 and summary["generated_sources"] == N, "independent_run_totals")
    for key in ("production_adoption", "observer_authenticated", "native_owner_used", "natural_task_benefit_established", "parameter_consolidation_executed"):
        checks.check(summary[key] is False, "conclusion_scope", key)
    checks.check(summary["scientific_acceptance"] == "HOLD", "conclusion_scope", "scientific_acceptance")
    verify_index(root, checks, category="originals_unchanged_after_review")
    result = {
        "schema": "hepta.mem14.independent-readback-review.v1", "status": "VERIFIED_CONSISTENT" if not checks.failures else "CHECK_FAILED",
        "archive": archive_info, "indexed_members": len(index), "plan_pin": PLAN_PIN,
        "source_commit": SOURCE_COMMIT, "source_tree": SOURCE_TREE, "run_helper_sha256": HELPER_SHA,
        "outer_job_id": JOB_ID, "run_key": RUN_KEY, "audit_code": audit_pins(),
        "new_model_calls": 0, "remote_execution_calls": 0, "originals_modified": False,
        "method": "Independent stdlib-only readback; no campaign imports, model loading, tokenization or child process; SQLite mode=ro&immutable=1.",
        "planned_rows": 320, "paired_sources": N, "shared_templates": 1, "scored_rows": len(valid_rows),
        "known_returned_generation_rows": len(valid_rows), "known_zero_generation_rows": sum(r["physical_generations"] == 0 for r in rows),
        "unsettled_generation_rows": sum(r["physical_generations"] is None for r in rows),
        "checks_by_category": dict(checks.counts), "failures": checks.failures,
        "selector_version": "v2", "primary_full_output_grammar": [V2_WORD, V2_SENTENCE], "strict_v1_descriptive_regex": V1,
        "all_missing_states_validation": self_check(), "panels": panels, "paired_contrasts": contrasts,
        "four_empty_arm_equality": equality, "bm25_exact_kv_equality": exact_equality, "replacement_diagnostic": {
            "changes_primary_endpoint": False, "inference": "descriptive intervention follow-through; no extra unadjusted confirmatory test",
            "pairs": replacements, "wrong_value_selected": sum(r["replacement_selected"] is True for r in replacements),
            "new_wrong_value_selected": sum(r["newly_selected_replacement"] is True for r in replacements),
            "truth_to_wrong_value_changes": sum(r["truth_to_replacement_change"] is True for r in replacements)},
        "costs_by_arm": costs, "cost_totals": totals, "writer_custody": writers, "rows": rows,
        "controlled_diagnostic_primary_lower_bound_positive": contrasts["off"]["primary_hoeffding_lower_95"] > 0 and not checks.failures,
        "scientific_acceptance": "HOLD", "production_adoption": False, "natural_task_benefit_established": False,
        "parameter_consolidation_executed": False, "limitations": BOUNDARIES,
    }
    return result


def markdown(result):
    lines = ["# MEM14 independent audit", "", "**Status: " + result["status"] + ".**", "",
             "This audit makes zero model calls and executes no remote commands. Original evidence is read only.", ""]
    if "panels" not in result:
        lines += ["Frozen 32-source / 10-arm plan, source pins, actual launch binding, both public grammars and all nine missing-pair states verified.",
                  "No outcome evidence was read or scored in this preparation stage.", ""]
    else:
        lines += [f"The fixed denominator is 32 source pairs; {result['scored_rows']} of 320 planned rows have verified returned evidence.", "",
                  "## Frozen endpoints", "", "| Arm | v2 correct / 32 | Missing | v2 format valid | Strict v1 correct | Relevant memo delivered |", "|---|---:|---:|---:|---:|---:|"]
        for arm in ARMS:
            p = result["panels"][arm]
            lines.append(f"| {arm} | {p['successes']} / 32 | {p['missing']} | {p['v2_format_accepted']} | {p['v1_descriptive']['successes']} | {p['relevant_key_delivered']} |")
        primary = result["paired_contrasts"]["off"]
        lines += ["", "## Paired causal contrasts", "",
                  "Primary: BM25 minus full memory-off. Missing source outcomes first receive worst-case difference bounds; all 32 pairs remain in the Hoeffding denominator.", "",
                  f"Primary one-sided 95% lower bound: **{primary['primary_hoeffding_lower_95']:.9f}**.", "",
                  "| BM25 minus | Wins / losses / ties (complete pairs) | Missing pairs | Mean difference bounds | Nine-contrast simultaneous lower 95% |",
                  "|---|---:|---:|---|---:|"]
        for arm, c in result["paired_contrasts"].items():
            interval = c["missing_label_difference_bounds"]
            lines.append(f"| {arm} | {c['observed_wins']} / {c['observed_losses']} / {c['observed_ties']} | {c['missing_pairs']} | [{interval[0]:.6f}, {interval[1]:.6f}] | {c['bonferroni_hoeffding_lower_95']:.9f} |")
        inputs = sum(r["status"] == "COMPARED" and all(r[k] for k in ("request_bytes", "model_input_bytes", "tensors", "rendered_prompt")) for r in result["four_empty_arm_equality"])
        exact_inputs = sum(r["status"] == "COMPARED" and all(r[k] for k in ("request_bytes", "model_input_bytes", "tensors", "rendered_prompt")) for r in result["bm25_exact_kv_equality"])
        rep = result["replacement_diagnostic"]
        lines += ["", "## Original bytes and interventions", "",
                  f"The four empty-delivery arms have identical request bytes, model-input bytes, tensors and rendered prompts in **{inputs} / 32** sources.", "",
                  f"BM25 and exact-KV have identical model inputs in {exact_inputs} / 32 sources. This comparison exposes whether the baselines deliver the same fact under the single-record budget.", "",
                  f"Replacement selects the wrong intervened value in {rep['wrong_value_selected']} sources; {rep['new_wrong_value_selected']} newly follow that value relative to BM25, including {rep['truth_to_wrong_value_changes']} changes from the original correct value. These are descriptive intervention checks; original truth and primary scoring stay fixed.", "",
                  "## Measured costs", "", "| Arm | Prompt tokens | Output tokens | Arm wall seconds | Provider wall with setup | Peak RSS KiB |", "|---|---:|---:|---:|---:|---:|"]
        for arm, c in result["costs_by_arm"].items():
            lines.append(f"| {arm} | {c['prompt_tokens']['observed_sum']} | {c['output_tokens']['observed_sum']} | {c['wall_seconds']['observed_sum']:.6f} | {c['provider_wall_seconds_with_setup']['observed_sum']:.6f} | {c['peak_rss_kib']['observed_max']} |")
        totals = result["cost_totals"]
        lines += ["", f"Common A writer wall time, charged once: {totals['common_A_wall_seconds']['observed_sum']:.6f} seconds. Run wall: {totals['run_wall_seconds']:.6f} seconds; preparation: {totals['prepare_wall_seconds']:.6f} seconds.",
                  "Per-field observed and missing counts, CPU totals and all per-row evidence pins are retained in REVIEW.json. A missing cost is never treated as an observed zero.", ""]
    lines += ["## Scientific scope", "", "Scientific acceptance remains **HOLD**. Production adoption, natural-task benefit and parameter consolidation are not established.", ""]
    lines += ["- " + s for s in BOUNDARIES]
    lines += ["", "## Audit identity", "", "Plan SHA256: `" + PLAN_PIN["sha256"] + "`.",
              "Source commit: `" + SOURCE_COMMIT + "`; source tree: `" + SOURCE_TREE + "`.",
              "Original durable job: `" + JOB_ID + "`; frozen operation key: `" + RUN_KEY + "`.", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--original", type=Path)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--archive-sha256")
    parser.add_argument("--archive-bytes", type=int)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if args.archive and (not args.archive_sha256 or args.archive_bytes is None):
        parser.error("archive requires independently supplied SHA256 and byte length")
    out = args.out.resolve()
    if args.original and (out == args.original.resolve() or args.original.resolve() in out.parents):
        parser.error("output must be outside original evidence")
    out.mkdir(parents=True, exist_ok=False)
    checks = Checks()
    try:
        if args.prepare:
            preflight(checks)
            result = {"schema": "hepta.mem14.independent-audit-preparation.v1", "status": "READY",
                      "plan_pin": PLAN_PIN, "source_commit": SOURCE_COMMIT, "source_tree": SOURCE_TREE,
                      "run_helper_sha256": HELPER_SHA, "original_job_id": JOB_ID, "run_key": RUN_KEY,
                      "new_model_calls": 0, "remote_execution_calls": 0, "originals_modified": False,
                      "outcomes_read": 0, "planned_rows": 320, "paired_sources": N,
                      "audit_code": audit_pins(), "checks_by_category": dict(checks.counts),
                      "failures": checks.failures, "statistical_self_check": self_check()}
        else:
            result = audit_original(args.original.resolve(), args.archive, args.archive_sha256, args.archive_bytes, checks)
        (out / "REVIEW.json").write_text(json.dumps(result, sort_keys=True, indent=2, allow_nan=False)+"\n")
        (out / "REVIEW.md").write_text(markdown(result))
        print(json.dumps({"status": result["status"], "output": str(out), "new_model_calls": 0,
                          "failures": len(checks.failures), "plan_pin": PLAN_PIN}, sort_keys=True))
        return 1 if checks.failures else 0
    except Exception as error:
        failure = {"status": "AUDIT_INCOMPLETE", "error": type(error).__name__+": "+str(error),
                   "new_model_calls": 0, "remote_execution_calls": 0, "originals_modified": False,
                   "plan_pin": PLAN_PIN, "checks_by_category": dict(checks.counts), "failures": checks.failures}
        (out / "REVIEW_ERROR.json").write_text(json.dumps(failure, sort_keys=True, indent=2)+"\n")
        print(json.dumps(failure, sort_keys=True))
        return 2


if __name__ == "__main__":
    sys.exit(main())
