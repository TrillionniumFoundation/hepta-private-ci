"""Independent read-only evidence checks; imports no campaign implementation.

Checks retained bytes, SQLite rows, chronology, provenance, runtime bindings and
actual model input. It never launches a child process or loads model libraries.
"""
import ast
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import random
import re
import sqlite3

from analysis import ARMS, EMPTY

NAMES = {"mnt", "pid", "net", "ipc", "uts", "user"}
PREFIX = "<|im_start|>system\nYou are a helpful AI assistant named SmolLM, trained by Hugging Face<|im_end|>\n<|im_start|>user\n"
SUFFIX = "<|im_end|>\n<|im_start|>assistant\n"
RECORD_FIELDS = ("record_id", "namespace", "source_id", "key", "version", "text", "provenance")


class EvidenceError(ValueError):
    pass


class Checks:
    def __init__(self):
        self.counts = Counter()
        self.failures = []

    def check(self, ok, category, identity=""):
        self.counts[category] += 1
        if not ok:
            self.failures.append({"category": category, "identity": identity})
        return bool(ok)

    def require(self, ok, category, identity=""):
        if not self.check(ok, category, identity):
            raise EvidenceError(category + ": " + identity)


def raw(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise EvidenceError("not a regular original: " + str(path))
    return path.read_bytes()


def read(path):
    return json.loads(raw(path))


def canon(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode()


def pin(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def digest(value):
    return pin(canon(value))["sha256"]


def literal(path, name):
    for node in ast.parse(raw(path)).body:
        if isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id == name for t in node.targets
        ):
            return ast.literal_eval(node.value)
    raise EvidenceError("missing source literal: " + name)


def db_read(path):
    raw(path)  # Refuse symlinks and missing/nonregular databases.
    with sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro&immutable=1", uri=True) as db:
        db.execute("PRAGMA query_only=ON")
        db.row_factory = sqlite3.Row
        rows = [dict(r) for r in db.execute("SELECT * FROM records ORDER BY namespace,source_id,key")]
        meta = json.loads(db.execute("SELECT value FROM meta WHERE id=1").fetchone()[0])
    return meta, rows, [json.loads(r["payload"]) for r in rows if r["status"] == "active"]


def namespaces(child, host):
    return set(child) == set(host) == NAMES and all(
        isinstance(child[k], str) and isinstance(host[k], str) and child[k] != host[k]
        for k in NAMES
    )


def log_records(log, prefix):
    return [line[len(prefix):] for line in log.splitlines() if line.startswith(prefix)]


def valid_number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def validate_records(records, check, identity):
    check(len(records) == len({r["record_id"] for r in records}), "unique_record_ids", identity)
    for record in records:
        check(record["record_id"] == digest({k: v for k, v in record.items() if k != "record_id"}),
              "record_identity_hash", identity)
        check(record["namespace"] == "mem12" and record["dependencies"] == [],
              "record_scope_no_dependencies", identity)


def validate_database(meta, frontier, active, check, identity):
    check(meta["schema"] == "hepta.mem6.authority.v1" and meta["max_records"] == 16
          and meta["max_serialized_bytes"] == 32768 and len(frontier) <= 16
          and len(canon({"meta": meta, "rows": frontier})) <= 32768, "database_bounds", identity)
    by_id = {r["record_id"]: r for r in active}
    for row in frontier:
        check(row["status"] in ("active", "revoked") and row["namespace"] == "mem12", "database_frontier_state", identity)
        if row["status"] == "active":
            record = by_id[row["record_id"]]
            check(all(row[k] == record[k] for k in ("namespace", "source_id", "key", "version", "record_id")),
                  "database_frontier_record_binding", identity)
        else:
            check(row["payload"] is None, "database_revoked_payload_absent", identity)


def verify_writer(cohort, plan, case, checks):
    check, cid = checks.require, case["case_id"]
    root = cohort / cid / "writer"
    receipt, process, snapshot = read(root / "RECEIPT.json"), read(root / "stdout.bin"), read(root / "snapshot.json")
    expected = {"case": {k: case[k] for k in ("case_id", "source_id", "facts")}, "cohort_id": plan["cohort_id"]}
    check(raw(root / "REQUEST.json") == canon(expected), "A_source_only_request", cid)
    check(receipt["status"] == "EXITED" and type(receipt["returncode"]) is int
          and receipt["returncode"] == 0 and receipt["process"] == process,
          "A_process_exit", cid)
    check(type(process["pid"]) is int and process["pid"] > 0
          and isinstance(process["session_id"], str) and bool(process["session_id"]),
          "A_process_identity", cid)
    check(receipt["database"] == pin(raw(root / "authority.sqlite"))
          and process["snapshot"] == pin(raw(root / "snapshot.json")), "A_pins", cid)
    body = snapshot["body"]
    check(snapshot["sha256"] == digest(body), "A_snapshot_digest", cid)
    meta, frontier, active = db_read(root / "authority.sqlite")
    validate_database(meta, frontier, active, check, cid)
    check(sorted(active, key=lambda r: r["write_sequence"]) == body["records"]
          and len(frontier) == len(active) == 3 and meta["generation"] == body["generation"] == 3
          and meta["authority_id"] == body["authority_id"]
          and body["schema"] == "hepta.mem6.snapshot.v1" and body["namespace"] == "mem12",
          "A_database_snapshot", cid)
    validate_records(active, check, cid)
    for sequence, (record, fact) in enumerate(zip(body["records"], case["facts"]), 1):
        expected_record = {
            "namespace": "mem12", "source_id": case["source_id"], "key": fact["key"],
            "text": fact["text"], "version": 1, "write_sequence": sequence,
            "dependencies": [], "provenance": {
                "source_uri": "generated://mem12/" + plan["cohort_id"] + "/" + cid,
                "source_sha256": pin(fact["text"].encode())["sha256"],
                "source_version": "A-v1", "episode_id": cid + "-A",
            },
        }
        expected_record["record_id"] = digest(expected_record)
        check(record == expected_record, "A_facts_and_provenance", cid)
    check(plan["registered_at_unix_ns"] < receipt["started_at_unix_ns"] < receipt["exited_at_unix_ns"],
          "A_chronology", cid)
    check(valid_number(receipt["wall_seconds"]), "A_cost", cid)
    return {"receipt": receipt, "process": process, "meta": meta, "frontier": frontier,
            "active": active, "case_id": cid, "wall_seconds": receipt["wall_seconds"]}


def independently_rank(records, strategy, key, query, seed, limit):
    """Fixed baselines reimplemented here; no experiment function is imported."""
    if strategy == "exact_kv":
        return sorted((r for r in records if r["key"] == key),
                      key=lambda r: (r["source_id"], r["key"], r["record_id"]))[:limit]
    if strategy == "icl":
        return sorted(records, key=lambda r: (r["write_sequence"], r["record_id"]))[:limit]
    if strategy == "uniform_replay":
        return random.Random(seed).sample(sorted(records, key=lambda r: r["record_id"]),
                                         min(limit, len(records)))
    if strategy != "bm25":
        raise EvidenceError("unexpected retrieval strategy")
    terms = sorted(set(re.findall(r"\w+", query.casefold())))
    if not terms or not records:
        return []
    docs = [Counter(re.findall(r"\w+", (r["key"] + " " + r["text"]).casefold())) for r in records]
    lengths = [sum(d.values()) for d in docs]
    average = sum(lengths) / len(docs)
    if not average:
        return []
    scores = []
    for record, doc, length in zip(records, docs, lengths):
        score = 0.0
        for term in terms:
            tf = doc[term]
            if tf:
                df = sum(term in d for d in docs)
                idf = math.log1p((len(docs) - df + 0.5) / (df + 0.5))
                score += idf * tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * length / average))
        if score > 0:
            scores.append((score, record))
    return [r for _, r in sorted(scores, key=lambda pair: (-pair[0], pair[1]["record_id"]))[:limit]]


def verify_memory(root, plan, case, arm, writer, checks):
    check, cid = checks.require, case["case_id"]
    ident = cid + "/" + arm
    key = case["public_task"]["key"]
    mode, strategy, mutation = plan["arms"][arm]
    memory = read(root / "MEMORY.json")
    receipt = memory["receipt"]
    expected = {
        "session_id": ":".join((plan["cohort_id"], cid, arm)), "mode": mode,
        "strategy": strategy, "source_ids": [case["source_id"]], "replay_seed": case["replay_seed"],
        "query_sha256": digest({k: case["public_task"][k] for k in ("query", "key")}),
        "limit": plan["limits"]["retrieval_records"], "max_context_bytes": plan["limits"]["context_bytes"],
        "store_read": arm != "off", "retrieval_executed": arm not in ("off", "retrieval_off"),
        "association_called": False, "association_id": None, "association_status": "unavailable",
        "association_authentication_established": False, "source_dependency_rejections": 0,
    }
    check(all(type(receipt[k]) is type(v) and receipt[k] == v for k, v in expected.items()),
          "memory_arm_binding_and_stages", ident)
    check(receipt["receipt_sha256"] == digest({k: v for k, v in receipt.items() if k != "receipt_sha256"})
          and pin(memory["context"].encode()) == {"bytes": receipt["context_bytes"], "sha256": receipt["context_sha256"]},
          "memory_receipt_hash", ident)
    delivered = [{k: r[k] for k in RECORD_FIELDS} for r in memory["records"]]
    check(memory["context"] == "\n".join(canon(r).decode() for r in delivered)
          and receipt["delivered_ids"] == [r["record_id"] for r in memory["records"]]
          and receipt["provenance"] == [{"record_id": r["record_id"], **r["provenance"]} for r in memory["records"]],
          "memory_delivered_bytes_and_provenance", ident)
    check(receipt["context_bytes"] <= plan["limits"]["context_bytes"]
          and len(delivered) <= plan["limits"]["retrieval_records"], "memory_budget", ident)
    active = []
    if arm == "off":
        check(not (root / "authority.sqlite").exists() and not (root / "actor/inputs/memory.txt").exists()
              and receipt["view_receipt"] is None, "full_off_no_store_or_memory_file", ident)
    else:
        meta, frontier, active = db_read(root / "authority.sqlite")
        validate_database(meta, frontier, active, check, ident)
        validate_records(active, check, ident)
        check(raw(root / "actor/inputs/memory.txt") == memory["context"].encode(), "actor_memory_bytes", ident)
        view = receipt["view_receipt"]
        check(view["authority_generation"] == meta["generation"] and view["authority_id"] == meta["authority_id"]
              and view["frontier_sha256"] == digest([{k: v for k, v in r.items() if k != "payload"} for r in frontier])
              and view["logical_serialized_bytes"] == len(canon({"meta": meta, "rows": frontier}))
              and view["resident_record_count"] == len(active) and view["snapshot_sha256"] is None
              and view["snapshot_rejections"] == 0, "reader_database_receipt", ident)
        if arm == "retention_off":
            check(not active and not frontier and meta["generation"] == 0
                  and meta["authority_id"] != writer["meta"]["authority_id"], "retention_discard", ident)
        else:
            check(meta["authority_id"] == writer["meta"]["authority_id"] and len(frontier) == 3
                  and {r["key"] for r in frontier} == {r["key"] for r in writer["frontier"]}, "fork_original_A_authority", ident)
            source_other = sorted((r for r in writer["active"] if r["key"] != key), key=lambda r: r["key"])
            other = sorted((r for r in active if r["key"] != key), key=lambda r: r["key"])
            check(other == source_other, "nontarget_records_unchanged", ident)
            if arm == "delete":
                target = next(r for r in frontier if r["key"] == key)
                check(target["status"] == "revoked" and target["payload"] is None and target["version"] == 2
                      and not any(r["key"] == key for r in active) and meta["generation"] == 4,
                      "relevant_delete", ident)
            elif arm == "replace":
                target = next(r for r in active if r["key"] == key)
                text = f"{key} requires a {case['replacement']} badge."
                check(target["text"] == text and target["version"] == 2 and target["write_sequence"] == 4
                      and meta["generation"] == 4 and target["provenance"] == {
                          "source_uri": "generated://mem12/wrong-fact-intervention",
                          "source_sha256": pin(text.encode())["sha256"], "source_version": "counterfactual-v2",
                          "episode_id": cid + "-replace"}, "relevant_replace", ident)
            else:
                check(sorted(active, key=lambda r: r["key"]) == sorted(writer["active"], key=lambda r: r["key"])
                      and meta["generation"] == 3, "unchanged_reader_copy", ident)
        check(all(r in active for r in memory["records"]), "delivered_current_records", ident)
    selected = [] if arm in ("off", "retrieval_off") else independently_rank(
        active, strategy, key, case["public_task"]["query"], case["replay_seed"], plan["limits"]["retrieval_records"])
    check(receipt["eligible_count"] == len(active)
          and receipt["retrieved_ids"] == receipt["selected_ids"] == [r["record_id"] for r in selected],
          "independent_retrieval_and_selection", ident)
    if arm in EMPTY:
        check(not memory["context"] and not delivered, "empty_delivery", ident)
    else:
        check(memory["records"] == selected and receipt["byte_dropped_ids"] == [],
              "selected_records_delivered", ident)
    return memory


def verify_returned(cohort, plan, case, arm, writer, actor, bootstrap, checks):
    """Return independent facts only; public outcome scoring happens separately."""
    check, cid = checks.require, case["case_id"]
    ident, root = cid + "/" + arm, cohort / cid / arm
    row, ar = read(root / "ROW.json"), read(root / "actor/RECEIPT.json")
    request, provider_raw = raw(root / "actor/actor-output.bin"), raw(root / "PROVIDER.json")
    provider = json.loads(provider_raw)
    rid = ":".join((plan["cohort_id"], cid, arm))
    directory = root / "provider" / hashlib.sha256(rid.encode()).hexdigest()
    check(list((root / "provider").iterdir()) == [directory], "one_provider_operation", ident)
    check(row["case_id"] == cid and row["arm"] == arm and row["request_id"] == rid
          and row["protocol_sha256"] == pin(canon(plan))["sha256"], "row_identity", ident)
    check(row["status"] == provider["status"] == "RETURNED" and type(row["physical_generations"]) is int
          and row["physical_generations"] == 1, "returned_generation", ident)
    check(row["provider_pin"] == pin(provider_raw) and row["request_pin"] == pin(request)
          and row["memory_pin"] == pin(raw(root / "MEMORY.json")), "row_evidence_pins", ident)
    check(raw(directory / "RECEIPT.json") == provider_raw and raw(directory / "request.bin") == request,
          "provider_original_bytes", ident)
    expected = {"schema": "hepta.mem11.local-provider.v1", "request_id": rid, "request": pin(request),
                "launch_sha256": pin(raw(root / "actor/RECEIPT.json"))["sha256"], "profile": plan["profile"],
                "worker": plan["provider_worker"], "timeout_seconds": plan["limits"]["provider_seconds"],
                "provider_source": plan["sources"]["ndu_real_runtime/episodic_local_provider.py"],
                "dependency_sources": {Path(n).name: plan["sources"][n] for n in (
                    "hepta_ci_exec.py", "ndu_real_runtime/episodic_local_worker.py", "ndu_real_runtime/episodic_provider_handoff.py")}}
    check(raw(directory / "ADMISSION.json") == canon(expected)
          and all(provider.get(k) == v for k, v in expected.items()), "provider_admission", ident)
    check(provider["runtime_before"] == provider["runtime_after"]
          and provider["runtime_before"]["sha256"] == plan["profile"]["runtime_sha256"]
          and provider["source_unchanged"] is True, "stable_runtime_source", ident)
    check(provider["python"]["sha256"] == plan["profile"]["python_sha256"], "provider_python", ident)
    execution = provider["execution"]
    check(provider["local_generation_returned"] is True and type(execution["returncode"]) is int
          and execution["returncode"] == 0 and execution["timed_out"] is False
          and execution["output_limit_exceeded"] is False, "execution_terminal", ident)
    log = raw(directory / "combined.log")
    check(pin(log) == provider["combined_log"] == {"bytes": execution["log_bytes"], "sha256": execution["log_sha256"]},
          "log_pin", ident)
    boots, results, inputs = (log_records(log, p) for p in (b"MEM11_BOOTSTRAP ", b"MEM11_RESULT ", b"MEM12_MODEL_INPUT "))
    check(len(boots) == len(results) == len(inputs) == 1, "one_logged_generation", ident)
    result, model_raw = json.loads(results[0]), raw(directory / "model-input.json")
    model = json.loads(model_raw)
    check(json.loads(boots[0]) == provider["bootstrap"] and result == provider["result"], "log_receipt_consistency", ident)
    check(provider["bootstrap"]["empty"] is True
          and namespaces(provider["bootstrap"]["namespaces"], provider["host_namespaces"]), "provider_isolation", ident)
    check(model_raw == inputs[0] == canon(model) and pin(model_raw) == result["model_input"] == provider["model_input"],
          "actual_model_input_bytes", ident)
    check(set(model) == {"schema", "request_sha256", "rendered_prompt", "tensors"}
          and model["schema"] == "hepta.mem12.model-input.v1"
          and model["request_sha256"] == result["request_sha256"] == pin(request)["sha256"], "model_request_binding", ident)
    tensors = model["tensors"]
    check(set(tensors) == {"input_ids", "attention_mask"}, "tensor_keys", ident)
    check(type(result["prompt_tokens"]) is int and 1 <= result["prompt_tokens"] <= plan["limits"]["input_tokens"],
          "input_token_budget", ident)
    for name, tensor in tensors.items():
        check(set(tensor) == {"dtype", "shape", "values"} and tensor["dtype"] == "torch.int64"
              and tensor["shape"] == [1, result["prompt_tokens"]] and len(tensor["values"]) == 1
              and len(tensor["values"][0]) == result["prompt_tokens"]
              and all(type(v) is int and 0 <= v < 2**31 for v in tensor["values"][0]),
              "tensor_shape_values", ident + "/" + name)
    check(all(v == 1 for v in tensors["attention_mask"]["values"][0])
          and len(result["tokens"]) <= plan["limits"]["output_tokens"]
          and all(type(v) is int and 0 <= v < 2**31 for v in result["tokens"])
          and isinstance(result["text"], str), "token_budget_mask", ident)
    stdout, stderr = raw(root / "actor/stdout.bin"), raw(root / "actor/stderr.bin")
    first, separator, emitted = stdout.partition(b"\n")
    check(separator == b"\n" and emitted == request and json.loads(first) == ar["bootstrap"], "actor_raw_request", ident)
    check(pin(stdout) == ar["stdout"] and pin(stderr) == ar["stderr"] and pin(request) == ar["actor_output"],
          "actor_output_pins", ident)
    check(ar["status"] == "EXECUTED" and type(ar["returncode"]) is int and ar["returncode"] == 0
          and ar["capture_truncated"] is False and ar["source_unchanged"] is True
          and ar["input_transport"] == "sealed-memfd-ro-bind-data", "actor_execution", ident)
    check(ar["bootstrap"]["bootstrap"] == "hepta.mem9.namespace.v1"
          and namespaces(ar["bootstrap"]["namespaces"], ar["host_namespaces"])
          and all(ar["bootstrap"][k] is True for k in ("home_empty", "cache_empty", "workspace_empty")), "actor_isolation", ident)
    check(ar["bootstrap_sha256"] == pin(bootstrap.encode())["sha256"]
          and ar["launcher_sha256"] == plan["sources"]["ndu_real_runtime/episodic_isolation.py"]["sha256"]
          and ar["actor_sha256"] == plan["actor"]["sha256"], "actor_source", ident)
    task_raw = canon(case["public_task"])
    check(raw(root / "actor/inputs/actor.py") == actor and raw(root / "actor/inputs/task.json") == task_raw
          and ar["task"] == pin(task_raw), "actor_frozen_inputs", ident)
    wr, wp = writer["receipt"], writer["process"]
    check(ar["session_id"] != wp["session_id"] and ar["process_identity"]["launcher_pid"] != wp["pid"]
          and wr["exited_at_unix_ns"] <= ar["started_at_unix_ns"] < ar["ended_at_unix_ns"]
          <= provider["started_at_unix_ns"] < provider["ended_at_unix_ns"], "A_C_chronology", ident)
    memory = verify_memory(root, plan, case, arm, writer, checks)
    mr, delivered = memory["receipt"], memory["records"]
    check(ar["mode"] == ("off" if arm == "off" else "on")
          and ar["context_sha256"] == mr["context_sha256"] and ar["context_bytes"] == mr["context_bytes"],
          "actor_memory_receipt_binding", ident)
    prompt = ("Use only the saved dispatch memo to answer the question. If the memo does not contain the answer, reply UNKNOWN. Reply with one color word only.\nSaved memo:\n"
              + "\n".join(r["text"] for r in delivered) + "\nQuestion: " + case["public_task"]["question"] + "\nAnswer:")
    expected_request = {"model": plan["profile"]["model_name"], "input": prompt, "store": False,
                        "max_output_tokens": plan["limits"]["output_tokens"], "temperature": 0}
    check(request == canon(expected_request) + b"\n", "independent_request_reconstruction", ident)
    check(model["rendered_prompt"] == PREFIX + prompt + SUFFIX, "fixed_chat_wrapper", ident)
    check(math.isclose(row["wall_seconds"], (row["ended_at_unix_ns"] - row["started_at_unix_ns"]) / 1e9,
                       rel_tol=0, abs_tol=1e-9), "wall_timestamp", ident)
    facts = {
        "text": result["text"], "relevant_key_delivered": any(r["key"] == case["public_task"]["key"] for r in delivered),
        "delivered_records": len(delivered), "retrieved_records": len(mr["retrieved_ids"]),
        "prompt_tokens": result["prompt_tokens"], "output_tokens": len(result["tokens"]),
        "user_cpu_seconds": result["user_cpu_seconds"], "system_cpu_seconds": result["system_cpu_seconds"],
        "max_rss_kib": result["max_rss_kib"], "wall_seconds": row["wall_seconds"],
        "provider_wall_seconds_with_setup": row["provider_wall_seconds_with_setup"],
        "read_wall_seconds": mr["decision_wall_seconds"], "read_cpu_seconds": mr["decision_cpu_seconds"],
        "request_pin": pin(request), "model_input_pin": pin(model_raw), "tensor_pin": pin(canon(tensors)),
        "actor_session_id": ar["session_id"], "actor_launcher_pid": ar["process_identity"]["launcher_pid"],
        "provider_start_ns": provider["started_at_unix_ns"], "provider_end_ns": provider["ended_at_unix_ns"],
        "evidence_directory": str(root.relative_to(cohort.parent)),
    }
    for key in ("prompt_tokens", "output_tokens", "user_cpu_seconds", "system_cpu_seconds", "max_rss_kib",
                "wall_seconds", "provider_wall_seconds_with_setup", "read_wall_seconds", "read_cpu_seconds"):
        check(valid_number(facts[key]), "finite_nonnegative_cost", ident + "/" + key)
    actual = {"request_bytes": request, "model_input_bytes": model_raw, "tensors": canon(tensors),
              "rendered_prompt": model["rendered_prompt"], "output_text": result["text"], "output_tokens": result["tokens"]}
    return facts, actual
