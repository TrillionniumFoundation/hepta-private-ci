"""Independent frozen MEM14 endpoints and fixed-denominator statistics.

This module has no dependency on the experiment implementation or its outputs.
"""
import itertools
import math
import re

N = 32
ALPHA = 0.05
FAMILY = 9
ARMS = ("on_bm25", "off", "delete", "replace", "retrieval_off", "delivery_off",
        "exact_kv", "finite_icl", "uniform_replay", "retention_off")
EMPTY = ("off", "retention_off", "retrieval_off", "delivery_off")
COLORS = ("red", "orange", "yellow", "green", "blue", "purple", "pink", "white")
V1 = r"(?:answer:\s*)?(red|orange|yellow|green|blue|purple|pink|white|unknown)[.!]?"
V2_WORD = r"red|orange|yellow|green|blue|purple|pink|white|unknown"
V2_SENTENCE = r"the courier must use a (red|orange|yellow|green|blue|purple|pink|white) badge\."


def selected_v1(text):
    if not isinstance(text, str):
        return None
    m = re.fullmatch(V1, text.strip().casefold())
    return m[1] if m else None


def selected_v2(text):
    if not isinstance(text, str):
        return None
    normalized = text.strip().casefold()
    if re.fullmatch(V2_WORD, normalized):
        return normalized
    m = re.fullmatch(V2_SENTENCE, normalized)
    return m[1] if m else None


def pair_interval(a, b):
    if any(v is not None and type(v) is not bool for v in (a, b)):
        raise ValueError("paired scores must be bool or missing")
    return ((int(a) if a is not None else 0) - (int(b) if b is not None else 1),
            (int(a) if a is not None else 1) - (int(b) if b is not None else 0))


def lower_hoeffding(lower_mean, family_size=1):
    if family_size not in (1, FAMILY) or not -1 <= lower_mean <= 1:
        raise ValueError("fixed MEM14 analysis arguments required")
    radius = math.sqrt((1 - (-1)) ** 2 * math.log(family_size / ALPHA) / (2 * N))
    return max(-1.0, lower_mean - radius)


def contrast(a, b):
    if len(a) != N or len(b) != N:
        raise ValueError("all 32 planned source pairs are required")
    intervals = [pair_interval(x, y) for x, y in zip(a, b)]
    lower = sum(x for x, _ in intervals) / N
    upper = sum(y for _, y in intervals) / N
    observed = [(x, y) for x, y in zip(a, b) if x is not None and y is not None]
    return {"planned_pairs": N, "observed_complete_pairs": len(observed),
            "missing_pairs": N-len(observed),
            "observed_wins": sum(x and not y for x, y in observed),
            "observed_losses": sum(y and not x for x, y in observed),
            "observed_ties": sum(x == y for x, y in observed),
            "missing_label_difference_bounds": [lower, upper],
            "paired_mean_difference": lower if lower == upper else None,
            "primary_hoeffding_lower_95": lower_hoeffding(lower),
            "bonferroni_hoeffding_lower_95": lower_hoeffding(lower, FAMILY)}


def self_check():
    states = []
    for a, b in itertools.product((False, True, None), repeat=2):
        possibilities = [int(x)-int(y)
                         for x in ((False, True) if a is None else (a,))
                         for y in ((False, True) if b is None else (b,))]
        interval = pair_interval(a, b)
        if interval != (min(possibilities), max(possibilities)):
            raise AssertionError("missing-pair bounds are wrong")
        repeated = contrast([a]*N, [b]*N)
        if repeated["missing_label_difference_bounds"] != list(interval):
            raise AssertionError("planned denominator changed")
        states.append({"a": a, "b": b, "interval": list(interval),
                       "n": N, "lower_95": repeated["primary_hoeffding_lower_95"]})
    for color in COLORS:
        assert selected_v2(color) == color
        assert selected_v2("The courier must use a " + color + " badge.") == color
        assert selected_v1("The courier must use a " + color + " badge.") is None
    assert selected_v2(" UNKNOWN ") == "unknown"
    assert all(selected_v2(s) is None for s in (
        "blue.", "Answer: blue", "blue or red", "The courier must use the blue badge.",
        "The courier must use a blue badge", "The courier must use a unknown badge.",
        "The courier must use a blue badge. Then red.", None, {"answer": "blue"}))
    mixed = contrast([True]*31 + [None], [False]*32)
    assert mixed["missing_label_difference_bounds"] == [31/32, 1.0]
    assert mixed["paired_mean_difference"] is None and mixed["planned_pairs"] == 32
    assert contrast([None]*32, [None]*32)["primary_hoeffding_lower_95"] == -1.0
    return {"status": "PASS", "model_calls": 0, "missing_states": states,
            "primary_radius": math.sqrt(2*math.log(20)/N),
            "simultaneous_radius": math.sqrt(2*math.log(180)/N),
            "fixed_source_denominator": N, "family_size": FAMILY,
            "primary_minimum_complete_net_wins": 14,
            "simultaneous_minimum_complete_net_wins": 19}
