import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

repo = Path('/workspace/scratch/4b389620cc87/cell127-repo')
output = Path('/workspace/scratch/4b389620cc87/validation-differentiation')
head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip()
tree = subprocess.check_output(['git','rev-parse','HEAD^{tree}'], cwd=repo, text=True).strip()
assert head == '6b249933d2d5f2503ad78f10e73ce261817a07f7'
assert tree == '1ce761595c7f7e3a8b9671d42d78172917364417'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
paths=sorted(repo.glob('scripts/hepta_cells/*.py'))
def manifest():
    return {p.relative_to(repo).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before = manifest()
with zipfile.ZipFile(output / 'source-final.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for path in paths:
        archive.write(path,path.relative_to(repo).as_posix())
    for rel in ['scripts/hepta_cells/requirements.txt','scripts/test_hepta_cells_differentiation_reference.py']:
        archive.write(repo/rel,rel)
environment=dict(os.environ, PYTHONPATH='scripts',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
argv=[sys.executable,'-m','hepta_cells.differentiation_reference','--output',str(output/'reference-final')]
started=time.perf_counter()
run=subprocess.run(argv,cwd=repo,env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
elapsed=time.perf_counter()-started
for name,data in [('reference-final.stdout.log',run.stdout),('reference-final.stderr.log',run.stderr)]:
    with (output/name).open('xb') as stream:stream.write(data)
after=manifest()
report={'schema':'cell127-layout-execution-v1','source_commit':head,'source_tree':tree,
        'git_clean_before':True,'source_before':before,'source_unchanged':before==after,
        'returncode':run.returncode,'argv':argv,'wall_seconds':elapsed,
        'stdout_sha256':hashlib.sha256(run.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(run.stderr).hexdigest(),
        'scope':'default synthetic layout experiment, not another unit-test run or an independent real confirmation cohort',
        'scientific_acceptance':'HOLD','decision':'NoUpdate'}
with (output/'FINAL_EXECUTION.json').open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
print(run.stdout.decode(),end='')
print(json.dumps({key:report[key] for key in ['source_commit','source_unchanged','returncode','wall_seconds']}))
sys.exit(run.returncode if before==after else 2)
