import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time
import zipfile

root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
output.mkdir(parents=True, exist_ok=False)
paths = sorted({
    *root.glob("scripts/hepta_cells/*.py"),
    *root.glob("scripts/test_hepta_cells_*.py"),
    root / "scripts/hepta_pred1/models.py",
    root / "scripts/hepta_pred1/__init__.py",
    root / "scripts/hepta_cells/requirements.txt",
})
def manifest():
    result = {}
    for path in paths:
        data = path.read_bytes()
        result[path.relative_to(root).as_posix()] = {
            "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
            "bytes": len(data),
        }
    return result

before = manifest()
with zipfile.ZipFile(output / "tested-source.zip", "x", zipfile.ZIP_DEFLATED) as archive:
    for path in paths:
        archive.write(path, path.relative_to(root).as_posix())
argv = [sys.executable, "-m", "unittest", "discover", "-s", "scripts", "-p", "test_hepta_cells_*.py", "-v"]
environment = dict(os.environ, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", PYTHONDONTWRITEBYTECODE="1")
started = time.perf_counter()
run = subprocess.run(argv, cwd=root, env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
elapsed = time.perf_counter() - started
(output / "unittest.log").write_bytes(run.stdout)
text = run.stdout.decode("utf-8")
counts = re.findall(r"Ran (\d+) tests? in", text)
after = manifest()
report = {
    "schema": "cell127-source-validation-v1",
    "git_parent": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
    "source_state": "declared modified file bytes before canonical formatting; see complete manifest and retained source archive",
    "python": platform.python_version(),
    "numpy": __import__("numpy").__version__,
    "command": argv,
    "thread_environment": {key: environment[key] for key in ["OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "PYTHONDONTWRITEBYTECODE"]},
    "returncode": run.returncode,
    "tests": int(counts[-1]) if counts else None,
    "skips": len(re.findall(r"\.\.\. skipped", text)),
    "wall_seconds": elapsed,
    "source_unchanged": before == after,
    "source_files": before,
    "log_sha256": hashlib.sha256(run.stdout).hexdigest(),
    "source_archive_sha256": hashlib.sha256((output / "tested-source.zip").read_bytes()).hexdigest(),
    "qualification": "engineering regression only; no authenticated evaluator, real-task benefit or production adoption",
}
(output / "VALIDATION.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k:report[k] for k in ["returncode", "tests", "skips", "source_unchanged", "wall_seconds"]}))
sys.exit(run.returncode if before == after else 2)
