# Source bytes for reference-01

These source bytes were recovered **after** reference-01 and its independent checkpoint-write-failure review. They were not archived at the time of those executions.

The newly added `hepta_cells/differentiation_reference.py` was reconstructed by applying the exact inverse of the subsequently retained edits. Its SHA-256 is `cb509ddb52d73985165dbedcf3f624cb22ffa0998fdc5528afdf1c59cfde1eff`, which exactly matches both reference-01's pre-execution `PROTOCOL.json` and the separately recorded execution manifest. The test file was reconstructed in the same way and matches its original execution hash. No generated result, prediction, checkpoint, journal, timing or execution log was reconstructed or edited.

All other package files were copied from the then-current workspace and individually checked against every entry in reference-01's original `source_sha256` mapping. All 14 package files match those recorded pins. The complete verified package and original test file were first staged into a 50,120-byte recovery ZIP with SHA-256 `74a87628a034c8fa08343ba4a0b3206c2a1b36971b94e3ad3790069468ff69fd`; this directory is an extraction of those checked bytes. `FILES.json` records each member. The source package does not claim a frozen transitive Python/NumPy dependency closure or independent provenance of the synthetic data.

The recovered source intentionally retains the checkpoint-write receipt-ordering defect. The repair and additional regression are in the later source. Use the original `PROTOCOL.json` for runtime versions and experiment settings, and preserve the separate negative review attempt. This recovery does not re-run tests, model training or inference and does not change the original HOLD / NoUpdate result.
