"""Read retained layout-reference evidence without invoking its producers.

This independent auditor imports no Hepta module. It recomputes dataset hashes,
predictions, loss values and declared arithmetic from retained NumPy arrays and
receipts, and opens original SQLite files in immutable read-only mode. Old and
final executions must be passed separately and produce distinct output reports.
"""

import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import zipfile

import numpy as np


def digest(*parts):
    result = hashlib.sha256()
    for part in parts:
        raw = part if isinstance(part, bytes) else str(part).encode()
        result.update(len(raw).to_bytes(8, "big"))
        result.update(raw)
    return result.hexdigest()


def review(root, *, source_repo=None, source_commit=None, source_archive=None):
    result = json.loads((root / "RESULT.json").read_text())
    protocol = json.loads((root / "PROTOCOL.json").read_text())
    checks = []

    def check(label, condition):
        checks.append({"check": label, "passed": bool(condition)})

    check("fixed_reference_scope", (
        protocol["tasks"], protocol["features"], protocol["train_rows"],
        protocol["evaluation_rows"], protocol["task_order"]
    ) == (2, 4, 24, 16, [0, 1]))
    archive = zipfile.ZipFile(source_archive) if source_archive else None
    try:
        for name, expected in protocol["source_sha256"].items():
            if Path(name).name != name or not name.endswith(".py"):
                raise ValueError("source manifest requires Python basenames")
            relative = f"scripts/hepta_cells/{name}"
            if source_repo:
                current = (source_repo / relative).read_bytes()
                check("source_current:" + name,
                      hashlib.sha256(current).hexdigest() == expected)
            if source_commit:
                recorded = subprocess.run(
                    ["git", "-C", str(source_repo), "show",
                     f"{source_commit}:{relative}"],
                    check=True, capture_output=True,
                ).stdout
                check("source_git_commit:" + name,
                      hashlib.sha256(recorded).hexdigest() == expected)
            if archive:
                check("source_archive:" + name,
                      hashlib.sha256(archive.read(relative)).hexdigest() == expected)
        if archive:
            source_names = {
                "scripts/hepta_cells/" + name
                for name in protocol["source_sha256"]
            }
            check("archive_python_source_inventory", source_names == {
                name for name in archive.namelist()
                if name.startswith("scripts/hepta_cells/") and name.endswith(".py")
            })
    finally:
        if archive:
            archive.close()

    for name, pin in result["artifacts"].items():
        if Path(name).name != name:
            raise ValueError("artifact manifest requires basenames")
        raw = (root / name).read_bytes()
        check("artifact:" + name, len(raw) == pin["bytes"]
              and hashlib.sha256(raw).hexdigest() == pin["sha256"])

    fits, updates, prediction_scalars, maximum_difference = 0, 0, 0, 0.0
    for run in result["runs"]:
        seed = run["seed"]
        with np.load(root / f"{seed}-inputs.npz", allow_pickle=False) as data:
            arrays = {
                arm: np.load(root / f"{seed}-{arm}.npz", allow_pickle=False)
                for arm in ("frozen", "shared_bank", "routed_heads")
            }
            try:
                for arm, row in run["arms"].items():
                    stored = arrays[arm]
                    prefix = f"{seed}:{arm}"
                    check(prefix + ":parameter_count", row["parameters"] == sum(
                        data[f"task{task}_initial_weights"].size
                        + data[f"task{task}_initial_bias"].size
                        for task in range(2)
                    ) == 10)
                    mse_key = "training_mse_values" if "training_mse_values" in row["counters"] else "mse_values"
                    count = dict.fromkeys((
                        "provider_calls", "provider_rows", "feature_copy_scalars",
                        "input_bytes", "route_decisions", "head_calls", "forward_mac",
                        "gradient_mac", "optimizer_steps", "parameter_update_scalars",
                        "owner_work_units", "forward_bias_adds", "gradient_bias_adds", mse_key,
                    ), 0)
                    for phase, receipt in enumerate(row["training"]):
                        x = data[f"task{phase}_train_inputs"]
                        target = data[f"task{phase}_train_targets"]
                        n, steps = len(x), receipt["completed_steps"]
                        label = f"{prefix}:fit{phase}"
                        check(label + ":roster", receipt["status"] == "completed"
                              and receipt["items"] == n == 24
                              and steps == receipt["requested_steps"] == protocol["steps"])
                        dataset = digest(
                            "semantic-dataset-v1",
                            *(digest("array", v.dtype.str, v.shape, v.tobytes()) for v in x),
                            target.shape, target.dtype.str, target.tobytes(),
                        )
                        check(label + ":dataset_digest", dataset == receipt["dataset_digest"])
                        with np.load(root / f"{seed}-{arm}-fit{phase}.npz", allow_pickle=False) as checkpoint:
                            check(label + ":checkpoint", np.array_equal(
                                checkpoint["weights"], stored[f"phase{phase}_task{phase}_weights"]
                            ) and np.array_equal(checkpoint["bias"], stored[f"phase{phase}_task{phase}_bias"]))
                            before = x[:, 1:] @ data[f"task{phase}_initial_weights"] + data[f"task{phase}_initial_bias"]
                            after = x[:, 1:] @ checkpoint["weights"] + checkpoint["bias"]
                            check(label + ":training_losses",
                                  float(np.mean((before - target) ** 2)) == receipt["loss_before"]
                                  and float(np.mean((after - target) ** 2)) == receipt["loss_after"])
                        count["provider_calls"] += 1
                        count["provider_rows"] += n
                        count["feature_copy_scalars"] += n * 4
                        count["input_bytes"] += x.nbytes
                        count["route_decisions"] += n
                        count["head_calls"] += steps + 2
                        count["forward_mac"] += n * 4 * (steps + 2)
                        count["gradient_mac"] += n * 4 * steps
                        count["optimizer_steps"] += steps
                        count["parameter_update_scalars"] += 5 * steps
                        count["forward_bias_adds"] += n * (steps + 2)
                        count["gradient_bias_adds"] += (n - 1) * steps
                        count[mse_key] += n * (steps + 2)
                        fits += 1
                        updates += steps

                    for panel in row["panels"]:
                        phase, task = panel["phase"], panel["task"]
                        x = data[f"task{task}_evaluation_inputs"]
                        target = data[f"task{task}_evaluation_targets"]
                        panel_id = f"phase{phase}_task{task}"
                        predicted = x[:, 1:] @ stored[panel_id + "_weights"] + stored[panel_id + "_bias"]
                        observed = np.asarray(panel["predictions"])
                        maximum_difference = max(maximum_difference, float(np.max(np.abs(predicted - observed))))
                        prediction_scalars += predicted.size
                        check(prefix + ":" + panel_id + ":prediction_and_metric",
                              np.array_equal(predicted, observed)
                              and np.array_equal(observed, stored[panel_id + "_predictions"])
                              and float(np.mean((observed - target) ** 2)) == panel["mse"])
                        n, work = len(x), x.nbytes + len(x) * (4 + 5)
                        count["provider_calls"] += 1
                        count["provider_rows"] += n
                        count["feature_copy_scalars"] += n * 4
                        count["input_bytes"] += x.nbytes
                        count["route_decisions"] += n
                        count["head_calls"] += 1
                        count["forward_mac"] += n * 4
                        count["forward_bias_adds"] += n
                        count["owner_work_units"] += work
                        check(prefix + ":" + panel_id + ":owner_work", panel["receipts"][0]["work_units"] == work)
                        if arm == "routed_heads":
                            check(prefix + ":" + panel_id + ":dense_same_selection",
                                  np.array_equal(np.asarray(panel["dense_receipts"][task]["output"]["logits"]), observed))
                    check(prefix + ":complete_selected_counters", count == row["counters"])
                    check(prefix + ":retention", np.array_equal(
                        stored["phase0_task0_predictions"], stored["phase1_task0_predictions"]
                    ) and row["old_task_predictions_retained"])
                    database = root / f"{seed}-{arm}.sqlite"
                    connection = sqlite3.connect(database.resolve().as_uri() + "?mode=ro&immutable=1", uri=True)
                    try:
                        history = connection.execute("SELECT count(*), max(generation) FROM history").fetchone()
                        planned = connection.execute("SELECT count(*) FROM population_plan").fetchone()[0]
                        check(prefix + ":no_adoption_epochs", history == (
                            12 if arm == "routed_heads" else 4, 0
                        ) and planned == 0)
                    finally:
                        connection.close()
                check(f"{seed}:shared_routed_arrays_identical", all(
                    np.array_equal(arrays["shared_bank"][name], arrays["routed_heads"][name])
                    for name in arrays["shared_bank"].files
                ))
            finally:
                for stored in arrays.values():
                    stored.close()

    check("total_fit_and_update_count", fits == result["fits"] == len(protocol["seeds"]) * 4
          and updates == result["optimizer_steps"] == fits * protocol["steps"])
    check("qualification_boundaries", result["independent_real_tasks"] == 0
          and result["negative_transfer_tested"] is False
          and result["full_physical_cost_known"] is False
          and result["total_physical_compute_matched"] is False
          and result["adoption_authorized"] is False
          and result["scientific_acceptance"] == "HOLD" and result["decision"] == "NoUpdate")
    return {
        "reference_directory": str(root), "source_commit": source_commit,
        "reference_source_sha256": protocol["source_sha256"]["differentiation_reference.py"],
        "auditor_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "audit_scope": "read-only arrays, receipts, declared cost formulas, archive hashes and immutable SQLite; no producer or model execution",
        "execution_separation": "this report covers only the specified reference directory, never aggregates earlier runs",
        "source_files_verified": len(protocol["source_sha256"]) if source_repo or source_archive else 0,
        "artifact_files_verified": len(result["artifacts"]),
        "source_archive_sha256": hashlib.sha256(source_archive.read_bytes()).hexdigest() if source_archive else None,
        "checks": checks, "checks_passed": sum(c["passed"] for c in checks),
        "checks_failed": sum(not c["passed"] for c in checks),
        "fit_receipts": fits, "optimizer_steps_from_original_receipts": updates,
        "prediction_scalars_recomputed": prediction_scalars,
        "maximum_prediction_difference": maximum_difference,
        "original_result_sha256": hashlib.sha256((root / "RESULT.json").read_bytes()).hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-repo", type=Path)
    parser.add_argument("--source-commit")
    parser.add_argument("--source-archive", type=Path)
    args = parser.parse_args()
    if args.source_commit and not args.source_repo:
        parser.error("--source-commit requires --source-repo")
    report = review(args.reference, source_repo=args.source_repo,
                    source_commit=args.source_commit, source_archive=args.source_archive)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps({k: v for k, v in report.items() if k != "checks"}, indent=2))
    raise SystemExit(report["checks_failed"] > 0)


if __name__ == "__main__":
    main()
