# Native qualification v3 — independent readback

**Result: PASS, with the two-archive provenance requirements below.** This was a read-only local evidence review. No tests or remote commands were executed; original evidence was not changed.

## Verified execution

- Native archive: **383,072 bytes, 68 regular payloads**, SHA-256 `5b0be7d15d3a7cdc5182fc625cee8220c9cfeeafc30a3302d9d54a27b087b693`. Every extracted payload matches its archived bytes.
- Ordinary run and the single collection rerun each contain the same **881** successful cases: **772 agentd + 109 learning-artifacts**. The retained ordinary JUnit belongs to rerun UUID `577a4f5e-abcd-4dbb-ae57-b0ee06ec741c`; it has no failed, erroneous or skipped testcase elements. The replay is not an additional set of distinct tests.
- Root raw log and JUnit agree on **six exact parent tests**, UUID `17b138c5-3514-4ff2-951a-b8f55c3546bb`. All case timestamps and the original report mtime lie inside the original command window. The framework duration is **0.307 s**; the command wall time is **1.058378 s**. Final success output repeats the six PASS lines; nested child tests are not counted separately.
- The actual service marker records **UID 60001, schema 2, Cell scope, retained writer, dedicated listener, one synthetic Experience receipt and exact retry**. Binding: `d79deb69c33b54260257315204b4563852c067100ccfccfd74c534e922c2e7bc`.
- The source-regression raw stderr contains **17 distinct successes**, `Ran 17 tests` and `OK`; recorded exit code is 0.

## Keep the source phases distinct

| Phase | Canonical inventory SHA-256 | Evidence |
| --- | --- | --- |
| Tested, before maintenance | `34f2b72cfc17988d70935393ffdd22b31b5334e00000bbb107ef3645fdba6bfd` | Ordinary, Root and source-regression records |
| Maintained/compiled, after fix/fmt | `1901b15d75b0d0b7eec8c2b1a3d0abeea6e0f279661203d38b22b10c82d16f20` | fix 0, fmt 0, bins check 0 |
| Final marker-aligned/config source | `aad7b3e68c34257731c841cb9f0140c60657df0fb72552fefe743eb5eaaa1768` | Final caller proof 0; Rust inventory identical to compiled snapshot |

The 10,622-row manifests were checked and both transitions reconstructed from actual payload bytes: 17 maintained Rust files, then exactly `CALLERS.toml` and the scope QA file. Final TOML data and QA AST change only string whitespace after normalization; all seven marker replacements preserve their non-whitespace character sequences. **No behavior tests after maintenance are claimed.**

Final caller proof: **188 boundaries, 170 protected-file entries (133 distinct paths), 6,157 Rust files scanned, `authorityGranted=false`**. The stage assembly and evidence constructor/readback product caller sets remain empty.

## Preserved failures and collection provenance

The initial v1 compiler failure, original Root collector failure, and post-maintenance literal-marker proof failure remain present. The Root command itself exited 0; reconciliation recovered its original report without re-running Root. Ordinary collection required exactly one replay, completed before fix/fmt. Original ordinary/status/audit snapshots match their preserved copies; the time-of-gate status hash can also be reconstructed exactly by removing only three later completion fields.

The native archive intentionally excludes two entries named by its reconciliation artifact index. `original-inputs-v2.json.gz` resolves to **byte-identical** `native/inputs-v2.json.gz`. The excluded source manifest resolves through canonical decompressed JSON identity `34f2b72cfc17988d70935393ffdd22b31b5334e00000bbb107ef3645fdba6bfd` in the accompanying source/review archive: its reconstructed gzip bytes differ from the recorded original gzip, and **gzip byte identity is not asserted**. The two archives must be read together; tested, maintained/compiled and final canonical manifests belong to that provenance package.

These records qualify mechanisms and source provenance. They do not establish real training, scientific independent evaluation, product assembly, Circuit providers, model-generation publication/recovery, continual operation or downstream task benefit. Production acceptance remains **HOLD**.

Machine-readable counts, six parent names, UUID/timing checks, critical artifact hashes and exclusions are in `independent-native-readback-v3.json`. Complete case inventories remain in the unchanged native archive.
