# Root learning V2 candidate — code review

Review date: 2026-11-09.
Scope: frozen V2 candidate, 33 changed files, based on Root code commit
`b443fe0cd7642316d016d78d6d3fbaa3e9dfc341`.
Qualification source inventory SHA-256:
`34f2b72cfc17988d70935393ffdd22b31b5334e00000bbb107ef3645fdba6bfd`.
The 33-file payload is recorded in `candidate-v2.json`.

This note records source review of the scope/checkpoint/evidence composition,
Root service qualification code, and caller boundaries. It does not certify
native compilation, test execution, scientific independence, or deployment.

## Review disposition

No remaining blocking source/API error was identified in the reviewed paths.
Native qualification remains a separate required result for this exact source
inventory. No build, Rust test, privileged test, or complete caller-scan pass is
claimed by this note before those results are available.

## Fixed source-caller findings

1. The evidence fixture was reachable only through a test module, but the caller
   scanner handles each source file separately. Its `Fixture::client` call to
   `RootObservationStream::from_stream_for_uid` was therefore counted as product
   code. Explicit `#[cfg(test)]` on `impl Fixture` records the existing test-only
   restriction without granting a production same-UID exception.
2. The original `(RootObservationStream|Self)::from_stream_for_uid` matcher
   incorrectly included two existing, different transport types:
   `AgentdUnixCognitiveCheckpointTransport` in `cognitive_checkpoint_unix.rs` and
   `RootFinalUseFrontierClient` in `hepta-contracts/src/authority_root_frontier.rs`.
   The boundary now uses the existing typed matcher with
   `receiver_type = "RootObservationStream"`; the broad pattern was removed.
   The scanner implementation and allowed product-caller set were not widened.
   The only allowed product caller remains `learning_iteration_evidence_client.rs`.
3. The added source regression includes those actual homonymous transports and
   the test fixture, and requires rejection of unauthorized direct, import-alias,
   and type-alias calls to the RootObservationStream constructor.

## Preserved authority and transport constraints

- Root registration/reopen remain separate, retain the original live writer and
  process pin, and refuse absent, foreign, or incompatible protected state.
- Scoped profile, sealed handoff, runtime, and protected checkpoint share the
  frozen request/owners/update-rule binding. V1/V2 mismatch is refused; opening
  existing state does not migrate, reset, or downgrade its profile.
- Evidence readback consumes the supplied connection and original pidfd. It
  checks actual peer UID/PID and process incarnation, refuses its own UID/process,
  and retains the existing 16 KiB frame, 500 ms exchange, and 300 s session bounds.
- Evidence responses require exact lookup binding/head/digest, pinned signature
  verification, current validity, and a final process-liveness check. Cancellation
  or an invalid response consumes the lane. No signing key or reconnect is added.
- `require_root_learning_assembled` remains intact. Root registration continues
  to report `production_ready: false`.

## Root qualification code in this candidate

The new retained-service test now selects schema 2 and Cell scope. Its actual
Root parent launches UID/GID 60001 with cleared groups/capabilities and
NoNewPrivileges, retains the child pidfd, registers the original writer, and
transfers the sealed scope at the listener-ready barrier. The child reconstructs
`bundle.frozen_scope`, uses `from_root_stream_scoped_v2`, and exercises initial CAS,
one synthetic Experience receipt, exact retry, and readback. Root then reopens
with `from_registered_scoped_v2` and compares the protected files before/after
read-only recovery. Missing/duplicate registration and owner custody are checked.

These are assertions present in the test source, not a claim that it has passed.
The configuration serves observation, issuer, checkpoint, and the dedicated
learning listener; Device/Notes consumer lanes are absent from this test.

## Exact remaining boundaries

- Frozen scope validates candidate component digests and update-rule identity
  after Training and on recovery/checkpoint. It does not prove actual tensor
  masks, gradient/update locality, state migration, or scientific compatibility.
- Evidence V1 binds the original initial head and exact receipt payload. It
  does not include `FrozenLearningScopeV2::binding()` in the signed evidence.
  The V2 worker/checkpoint enforce that additional scope; no V2-scope attestation
  by an independent evaluator is claimed.
- Product callers of `with_root_learning_stage_owners`, evidence
  `from_owner_stream`, and evidence `readback` remain empty. Actual training,
  evaluator/signing stage owners, current withdrawal/revocation reconciliation,
  and Circuit providers still require product assembly.
- Model generation publication, adoption, and recovery remain outside this
  increment; ordinary generation remains `Unpublished`. Learning checkpoint
  recovery must not be reported as model-generation release or recovery.
- A separate UID and authenticated signature establish custody/authenticity,
  not independent operators, held-out evaluation, causal task benefit, or
  scientific independence. Synthetic receipts and pre-signed fixture records
  cannot establish those claims.

Attach native results with this exact inventory before making qualification
claims. This review grants no merge, deployment, production-ready, or end-to-end
learning acceptance status.
