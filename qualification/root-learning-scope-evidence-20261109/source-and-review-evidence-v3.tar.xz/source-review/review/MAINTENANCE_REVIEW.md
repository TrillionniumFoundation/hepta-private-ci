# Maintenance and publication-cut review

Review date: 2026-11-09. Method: local source/diff/hash inspection only.
Reviewed `maintenance-source-delta-v2.json.gz` against `inputs-v2.json.gz`,
the maintained `integration` files, and `publication-final-stack-v3`.
Maintained source inventory:
`1901b15d75b0d0b7eec8c2b1a3d0abeea6e0f279661203d38b22b10c82d16f20`.

## Maintenance disposition: no material behavior change found

All 17 delta entries were inspected. Their recorded before/after SHA-256 values
match the archived input and delta text. Applying those entries to the 33-file
input produces exactly the current 33 maintained integration files.

The changes consist of line wrapping, indentation, trailing commas, import/export
ordering, and equivalent expression/block formatting. In particular, the
BaseRelease error arm still returns the same error; the registration closure
still returns the same `learning_store` result. No condition or call was removed.

The only non-formatting cleanup is in
`authority_host_learning_service_root_tests.rs`: the registration field changes
from `identity.agent_id.clone()` to `identity.agent_id` for the Copy AgentId.
It preserves the same value and is confined to qualification code.

No maintenance change alters schema selection, frozen bindings, component/update
checks, UID/PID/pidfd checks, writer/lease checks, signature verification, frame or
time bounds, cancellation behavior, recovery/CAS order, or product caller sets.
The schema-2 Cell/UID-60001 test and its read-only scoped recovery remain intact.

## Publication stack: final bytes correct; cut 4 has a compatibility omission

Independent recomputation found 33 final files exactly equal to the maintained
candidate. All stage patch/payload hashes match their manifest. The ten changed
line counts are 280, 301, 439, 284, 275, 306, 408, 287, 493, 452: each is below 500.

However, cut 4 changes `learning_store` from three parameters to four and adds
`update_scope` to `HostAuthorityLearningBootstrapV1`, while leaving the existing
`authority_host_learning_registration_tests.rs` unchanged until cut 5.
At that intermediate cut, the baseline test file still has seven three-argument
`learning_store` calls and a bootstrap literal missing `update_scope`.
Those are definite test-compilation incompatibilities (missing argument/field),
even though the affected tests are ignored at runtime. Cut 4's separate
`root_production_learning_inputs_tests.rs` V1 fixture correction does not fix them.

Minimal packaging correction: move the existing V1 registration-test adaptations
(`/*scope*/ None` at all seven calls and `update_scope: None` in the literal)
from cut 5 into cut 4. Keep the newly added scoped qualification test in cut 5.
The existing V1 portion is about 60 changed lines, giving an estimated cut-4
count of 344; regenerate patch counts/hashes after repartitioning. Final source
bytes need not change. No source or publication files were edited in this review.

## Qualification limits retained

This review ran no tests or compilers after `just fix`/`just fmt`; it adds no
post-maintenance test-pass claim and no per-cut compilation claim. The cumulative
native qualification and maintained-binary result must retain their own logs.
The final candidate still does not prove tensor-mask locality, add V2 scope to
the evidence signature, assemble product stage/Circuit providers, publish/recover
ordinary model generations, or establish scientific independence.

Disposition: maintenance delta is behavior-preserving on source review;
repair the cut-4 V1 registration-fixture omission before publishing that split.

## Integration follow-up

The final v4 review partition moves the complete registration test file into cut 4, including all seven legacy call adaptations and the missing bootstrap field. Cut 4 is 444 changed lines; cut 5 is 115. All ten cuts remain below 500 and their final 33 files match integration exactly.

After the review, two non-Rust files received exact whitespace-only source-marker alignment for rustfmt method chains. Receiver, argument, operator and token character sequences are unchanged. Seven affected protected rows and fifteen definition rows passed local static inspection; the full final native closure receipt is recorded separately. No behavior tests were run after maintenance.
