# Final product-boundary fact check

Date: 2026-11-09. Read-only review of integration, publication stack v4, source
inventories, CALLERS, and the recorded native qualification summary.
No tests, compilation, source edits, or remote operations were performed here.

## Evidence identity

- Final source inventory:
  `aad7b3e68c34257731c841cb9f0140c60657df0fb72552fefe743eb5eaaa1768`.
- Maintained compiled Rust inventory:
  `1901b15d75b0d0b7eec8c2b1a3d0abeea6e0f279661203d38b22b10c82d16f20`.
- Tested pre-maintenance inventory:
  `34f2b72cfc17988d70935393ffdd22b31b5334e00000bbb107ef3645fdba6bfd`.
- `native-qualification-final-v3.json` records a successful final static caller
  proof over 6,157 Rust files, 188 boundaries and 170 protected-file entries
  (133 distinct protected paths), with
  `authority_granted: false`. These are recorded results, not reruns by this review.

## Confirmed product boundaries

1. **Unassembled Root learning still refuses startup.**
   `codex-rs/hepta-agentd/src/config_root_learning.rs`:
   `AgentdConfig::require_root_learning_assembled` rejects retained pending
   `root_learning_inputs`. CALLERS retains this condition/error sequence.
   The same manifest requires a top-level call in
   `production_launcher.rs::run` before MCP/runtime setup and in
   `runtime.rs::run_with_shutdown` before consuming Circuit/operation inputs.
   All three source hashes equal the original baseline; the recorded full caller
   proof covers these protected guards.

2. **Stage owners and evidence readback are not product-assembled.**
   `CALLERS.toml` still has empty product-caller sets for:
   `root_learning_original_stage_assembly`
   (`AgentdConfig::with_root_learning_stage_owners` in `config_root_learning.rs`),
   `learning_evidence_original_owner_constructor`, and
   `learning_evidence_original_owner_readback`
   (`LearningIterationEvidenceClientV1::{from_owner_stream,readback}` in
   `learning_iteration_evidence_client.rs`). A callable client and a registered
   checkpoint do not supply actual training/evaluation/signing stage owners or
   Circuit providers. Root learning registration still returns
   `production_ready: false` in `authority_host_learning_registration.rs`.

3. **Frozen scope constrains declared candidate components.**
   `codex-rs/hepta-learning-artifacts/src/learning_iteration_scope.rs`:
   `FrozenLearningScopeV2::{freeze,validate_request,validate_observation,validate_snapshot}`
   binds request/owners, Cell or Organ scope, and update rule; it compares Training
   candidate component digests and lineage. The worker/checkpoint recheck these
   constraints. This does not establish tensor masks, gradient/update locality,
   actual byte compatibility, or independent downstream task benefit.

4. **Evidence V1 does not independently attest the V2 frozen scope.**
   `codex-rs/hepta-agentd/src/learning_iteration_evidence_client.rs::readback`
   checks the original request/owners and sends
   `binding: self.initial.head_digest.to_string()` plus the exact receipt digest.
   It verifies `learning_iteration_receipt_signing_bytes_v1(receipt)` with the
   pinned verifier. `learning_iteration_evidence_wire.rs` adds no field carrying
   `FrozenLearningScopeV2::binding()`. Its existing evidence `scope_digest` must
   not be described as a newly signed Cell/Organ binding. V2 scope enforcement
   remains with the worker and protected checkpoint.

5. **Ordinary model generation has not been promoted from Unpublished.**
   The prior baseline's ordinary `Unpublished` status is unchanged by this stack.
   Generation publication/recovery modules, including `neuron_generation.rs`
   (`AgentdNeuronGenerationOwnerV2`), `neuron_generation_initial.rs`,
   `neuron_generation_current.rs`, and `neuron_generation_update.rs`, have no
   changes in the 33-file payload. Manifest comparison confirms all 55
   `neuron_generation*.rs` files retain baseline hashes. This is preservation
   evidence, not a new runtime generation observation. Learning checkpoint
   recovery must not be reported as formal model publication or recovery closure.

6. **Cross-UID custody does not establish scientific independence.**
   The external evidence client authenticates its selected peer and signatures.
   `learning_iteration_evidence_root_tests.rs` uses pre-signed synthetic evidence;
   `authority_host_learning_service_root_tests.rs` uses synthetic checkpoint
   receipts. Separate UID/PID ownership does not prove independent operators,
   evaluation design, signing-key governance, or successor-task gains.

## V4 cut-4 finding resolved

`publication-final-stack-v4` cut 4 now includes the complete maintained
`authority_host_learning_registration_tests.rs`: all seven legacy store calls
carry `/*scope*/ None`, and its bootstrap literal carries `update_scope: None`.
The file equals integration exactly. The missing-argument/missing-field finding
in `MAINTENANCE_REVIEW.md` is therefore resolved in v4.
Cut 4 is 444 changed lines; cut 5 is 115. All ten cuts remain below 500 lines,
and their final 33-file composition equals integration byte for byte.
This confirms source partitioning; it grants no per-cut native-test acceptance.

Disposition: the documented refusal and product-readiness limits remain accurate.
The completed static proof and custody qualification do not close the outstanding
stage-owner, Circuit, scientific-evaluation, or model-publication product work.
