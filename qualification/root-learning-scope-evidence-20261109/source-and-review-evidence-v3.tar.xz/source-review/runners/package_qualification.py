#!/usr/bin/env python3
"""Package existing qualification evidence; never execute source tests or native jobs."""
from __future__ import annotations

import datetime as dt
import gzip
import hashlib
import io
import json
import pathlib
import shutil
import tarfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
CONTROL = ROOT / 'native-control'
WORK = ROOT / 'qualification-work'
NATIVE = WORK / 'extracted' / 'native'
OUT = WORK / 'deliverable'
REPO = 'TrillionniumFoundation/hepta-private-ci'
BASE = 'e2e20033daa67d9d9826d4942e4d6bdd15ba4ab5'
CODE = 'b8e8c6e82abc1479c573f61a5e17d28d581e6cad'
TREE = 'deca4dc9e355ba313c68528d9c88bd5104a71f36'
TESTED = '34f2b72cfc17988d70935393ffdd22b31b5334e00000bbb107ef3645fdba6bfd'
COMPILED = '1901b15d75b0d0b7eec8c2b1a3d0abeea6e0f279661203d38b22b10c82d16f20'
FINAL = 'aad7b3e68c34257731c841cb9f0140c60657df0fb72552fefe743eb5eaaa1768'
FOLDER = 'qualification/root-learning-scope-evidence-20261109'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: pathlib.Path):
    return json.loads(path.read_bytes())


def json_bytes(value) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def main():
    source_readback = read_json(CONTROL / 'published-source-readback.json')
    pr_readback = read_json(CONTROL / 'published-pr-readback.json')
    assert source_readback['overall_pass'] and pr_readback['overall_pass']
    assert source_readback['observed_commit_sha'] == CODE
    assert source_readback['observed_root_tree_sha'] == TREE
    native_readback_path = CONTROL / 'independent-native-readback-v3.json'
    native_readback = read_json(native_readback_path)
    # The complete independent result remains a named archive payload.
    assert native_readback.get('overall_pass') is True, 'Independent native review must pass'

    header = read_json(CONTROL / 'native-qualification-final-v3.json')
    archive_in = WORK / 'native-qualification-final-v3.tar.xz'
    native_bytes = archive_in.read_bytes()
    assert len(native_bytes) == header['bytes'] and sha(native_bytes) == header['sha256']
    final_gate = read_json(NATIVE / 'final-closure-v3.json')
    assert final_gate['phase'] == 'passed' and final_gate['command_exit_code'] == 0
    assert final_gate['source_before'] == COMPILED and final_gate['source_after'] == FINAL
    assert final_gate['rust_source_unchanged_from_compiled_snapshot'] is True
    assert final_gate['tests_after_maintenance'] is False
    caller_proof = read_json(NATIVE / 'final-caller-proof-v3.log')
    assert caller_proof['status'] == 'PASS_HEPTA_CALLER_CLOSED_SET'
    assert caller_proof['rustFilesScanned'] == 6157 and caller_proof['authorityGranted'] is False
    assert len(caller_proof['protectedFiles']) == 170
    assert len(set(caller_proof['protectedFiles'])) == 133

    native_payloads = []
    for p in sorted(NATIVE.rglob('*')):
        if p.is_file():
            b = p.read_bytes()
            native_payloads.append({'path': str(p.relative_to(NATIVE.parent)), 'bytes': len(b), 'sha256': sha(b)})
    assert len(native_payloads) == 68
    original_input_reference = read_json(NATIVE / 'reconcile-v2' / 'reconciliation.json')['original_artifacts']
    input_ref = next(x for x in original_input_reference if x['path'].endswith('/inputs-v2.json.gz'))
    assert sha((NATIVE / 'inputs-v2.json.gz').read_bytes()) == input_ref['sha256']

    payloads: dict[str, bytes] = {}

    def add(name: str, data: bytes):
        assert name not in payloads and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
        payloads[name] = data

    def add_file(name: str, p: pathlib.Path):
        add(name, p.read_bytes())

    manifest_specs = [
        ('initial-failed-v1.files.json', 'reconstructed-v1.files.json.gz', '2bff80b8428678eea8e1af330760da164e31f6a1978f49865e61ad38436aa2cb'),
        ('tested-v2.files.json', 'reconstructed-v2.files.json.gz', TESTED),
        ('compiled-v2.files.json', 'reconstructed-maintained-v2.files.json.gz', COMPILED),
        ('final-v3.files.json', 'reconstructed-final-v3.files.json.gz', FINAL),
    ]
    inventories = []
    manifests = {}
    for name, original, expected in manifest_specs:
        b = gzip.decompress((CONTROL / original).read_bytes())
        rows = json.loads(b)
        assert sha(b) == expected and len(rows) == 10622
        assert b == json.dumps(rows, sort_keys=True, separators=(',', ':')).encode()
        add('manifests/' + name, b)
        inventories.append({'path': 'manifests/' + name, 'sha256': expected, 'entries': len(rows), 'bytes': len(b)})
        manifests[name] = {x['path']: x for x in rows}
    assert all(v == manifests['final-v3.files.json'][k] for k, v in manifests['compiled-v2.files.json'].items() if k.endswith('.rs'))

    expected_files = read_json(CONTROL / 'final-published-files.json')
    assert len(expected_files) == 33
    for row in expected_files:
        b = (ROOT / 'integration' / row['path']).read_bytes()
        assert sha(b) == row['sha256'] and len(b) == row['bytes']
        assert hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest() == row['blob_sha']
        assert manifests['final-v3.files.json'][row['path']]['sha256'] == row['sha256']
        add('final-source/' + row['path'], b)

    stack_dir = ROOT / 'publication-final-stack-v4'
    for p in sorted((stack_dir / 'stages').iterdir()):
        if p.is_file():
            add_file('review-cuts/' + p.name, p)
    add_file('review-cuts/stack.json', stack_dir / 'stack.json')
    add_file('review-cuts/final-source-match.json', stack_dir / 'final-source-match.json')
    for name in ['REVIEW.md', 'MAINTENANCE_REVIEW.md', 'FINAL_PRODUCT_BOUNDARY_REVIEW.md']:
        add_file('review/' + name, CONTROL / name)
    for name in ['published-source-readback.json', 'published-pr-readback.json', 'published-source-stack.json', 'final-published-files.json', 'native-qualification-final-v3.json', 'independent-native-readback-v3.json', 'static-marker-repair-v3-summary.json']:
        add_file('provenance/' + name, CONTROL / name)
    for p in sorted(CONTROL.glob('independent-native-readback-v3*.md')):
        add_file('review/' + p.name, p)
    add('provenance/native-payload-index.json', json_bytes(native_payloads))
    add('provenance/source-inventories.json', json_bytes(inventories))
    add('provenance/maintenance-source-delta-v2.json', gzip.decompress((CONTROL / 'maintenance-source-delta-v2.json.gz').read_bytes()))
    add('provenance/static-marker-repair-v3.json', gzip.decompress((CONTROL / 'static-marker-repair-v3.json.gz').read_bytes()))
    add_file('prior-evidence/independent-readback.json', ROOT / 'evidence-recheck' / 'independent-readback.json')
    add_file('prior-evidence/compute-status-before-native-run.json', ROOT / 'evidence-recheck' / 'COMPUTE_STATUS.json')
    for name in ['runner-v1.py', 'runner-v2.py', 'audit-v1.py', 'audit-v2.py', 'root-qualification-v2.py', 'reconcile-v2.py', 'maintenance-v2.py', 'final-closure-v3.py', 'build_final_stack.py', 'split_root_cut.py', 'package_qualification.py']:
        add_file('runners/' + name, CONTROL / name)
    provenance_note = {
        'native_archive_payloads': 68,
        'native_reconcile_index_external_references': [
            {'reference': 'native/reconcile-v2/original-inputs-v2.json.gz', 'resolved_by': 'native/inputs-v2.json.gz', 'equality': 'identical gzip bytes and SHA256', 'sha256': input_ref['sha256']},
            {'reference': 'native/reconcile-v2/qualified-source.files.json.gz', 'resolved_by': 'source-review/manifests/tested-v2.files.json', 'equality': 'identical canonical uncompressed JSON SHA256 only; reconstructed gzip bytes are not asserted identical', 'canonical_sha256': TESTED},
        ],
        'inventory_algorithm': 'Sorted rows {path,sha256,kind}; JSON sort_keys=True,separators=(comma,colon), UTF-8, no terminal newline. Files hash exact bytes; symlinks hash readlink text. Includes codex-rs tracked file/symlink inventory plus CALLERS.toml and two source QA files; not a Git commit hash.',
        'rust_unchanged_after_compilation': True,
        'tests_after_maintenance': False,
        'source_archive_is_not_a_new_native_execution': True,
    }
    add('provenance/archive-relationships.json', json_bytes(provenance_note))
    index = [{'path': 'source-review/' + name, 'bytes': len(b), 'sha256': sha(b)} for name, b in sorted(payloads.items())]
    add('artifact-index.json', json_bytes({'schema_version': 1, 'files': index, 'self_entry_excluded': True}))

    OUT.mkdir(exist_ok=True)
    native_name = 'native-qualification-final-v3.tar.xz'
    source_name = 'source-and-review-evidence-v3.tar.xz'
    shutil.copyfile(archive_in, OUT / native_name)
    with tarfile.open(OUT / source_name, 'w:xz', preset=6) as archive:
        for name, b in sorted(payloads.items()):
            info = tarfile.TarInfo('source-review/' + name)
            info.size, info.mode, info.mtime = len(b), 0o644, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            archive.addfile(info, io.BytesIO(b))
    source_archive_bytes = (OUT / source_name).read_bytes()
    archives = [
        {'file': native_name, 'bytes': len(native_bytes), 'sha256': sha(native_bytes), 'payloads': 68},
        {'file': source_name, 'bytes': len(source_archive_bytes), 'sha256': sha(source_archive_bytes), 'payloads': len(payloads)},
    ]
    published = read_json(CONTROL / 'published-source-stack.json')
    stages = published['stages']
    stage_lines = [json.dumps(x, ensure_ascii=False, separators=(',', ':')) for x in stages]
    (OUT / 'source-stack.jsonl').write_text('\n'.join(stage_lines) + '\n')

    validation = {
        'schema': 'hepta.root-learning-scope-evidence-qualification.v1',
        'created_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'repository': REPO,
        'base_evidence_commit': BASE,
        'cumulative_code_commit': CODE,
        'cumulative_code_tree': TREE,
        'code_files': 33,
        'code_bytes': sum(x['bytes'] for x in expected_files),
        'source_identity': {'behavior_tested': TESTED, 'maintained_and_compiled': COMPILED, 'final_static_proof': FINAL},
        'ordinary_tests': {'agentd': 772, 'learning_artifacts': 109, 'total_passed': 881, 'scope': 'pre-maintenance cumulative candidate'},
        'root_tests': {'passed_parents': 6, 'count_nested_children_again': False, 'actual_consumer_uid': 60001},
        'source_regressions': {'passed': 17, 'scope': 'pre-maintenance; not rerun after fix/fmt'},
        'maintenance': {'just_fix': 0, 'just_fmt': 0, 'bins_check': 0, 'rust_files_changed': 17, 'material_behavior_change_found_in_static_review': False},
        'final_caller_proof': {'status': 'PASS_HEPTA_CALLER_CLOSED_SET', 'rust_files': 6157, 'boundaries': 188, 'protected_entries': 170, 'distinct_protected_paths': 133, 'authority_granted': False},
        'report_reconciliation': {'root_rerun': False, 'ordinary_rerun_count': 1, 'original_failed_receipts_preserved': True},
        'tests_after_maintenance': False,
        'per_cut_native_acceptance_claimed': False,
        'per_cut_github_ci_pass_claimed': False,
        'published_source_readback': {'exact_ref': CODE, 'files': 33, 'sha256_blob_sha_size_and_tree_path': 'all matched'},
        'product': {'disposition': 'HOLD_UNASSEMBLED', 'stage_owner_product_callers': 0, 'evidence_client_product_callers': 0, 'generation': 'Unpublished boundary preserved; no new generation runtime observation', 'merged_or_deployed_by_this_task': False},
        'archives': archives,
        'read_archives_together': True,
    }
    (OUT / 'validation.json').write_bytes(json_bytes(validation))

    root_tests = [
        'root_learning_registration_reopens_without_replacing_original_history',
        'root_learning_sealed_pin_and_dedicated_uds_recover_original_checkpoint',
        'root_learning_handoff_reaches_dedicated_uid_with_original_root_pin',
        'root_scoped_learning_reopens_exact_scope_and_refuses_legacy_client',
        'original_external_uid_returns_a_verified_receipt_through_held_pidfd',
        'root_learning_public_registration_serves_retained_writer_and_recovers_history',
    ]
    readme = f'''# Scoped Root learning and external evidence qualification

Date: 2026-11-09. Status: **mechanism qualification passed; product assembly remains HOLD**.
This is evidence cut 11/11 for code PRs #5541 through #5550.
The cumulative code head is [`{CODE}`](https://github.com/{REPO}/commit/{CODE}),
based on prior evidence head [`{BASE}`](https://github.com/{REPO}/commit/{BASE}).
All code cuts are drafts, each below 500 changed lines. No per-cut native acceptance is claimed.

## Implemented behavior

- Freeze the exact request, owners, update rule and Cell/Organ component boundary.
- Carry that scope through original Root registration, sealed handoff, scoped worker,
  protected schema-2 checkpoint and history recovery; refuse V1/V2 reinterpretation.
- Check authenticated Training candidates before record/CAS/evaluation and recheck
  every recovered Training receipt, including histories ending in NoUpdate.
- Read existing signed evidence through the original stream and pre-held pidfd,
  with exact peer identity, bounded I/O, signature checks and cancellation consumption.
- Qualify actual Root registration, retained writer/listener, schema-2 Cell handoff
  to UID 60001, checkpoint CAS/readback/exact retry and recovery of the same store.

## Observed qualification

| Check | Observed result | Source boundary |
| --- | --- | --- |
| Ordinary libraries | 772 agentd + 109 learning-artifacts = 881 passed | Tested inventory |
| Explicit Root parents | 6 passed; nested children not counted again | Tested inventory |
| Source regressions | 17 passed; caller scanner self-test passed | Before maintenance |
| Required maintenance | just fix and just fmt exited 0 | Maintained inventory |
| Binary compilation | selected-package cargo check --bins exited 0 | Maintained inventory |
| Final caller proof | 6157 Rust files, 188 boundaries, 170 protected entries / 133 paths | Final inventory |
| Authority | authorityGranted=false | Final caller proof |
| GitHub source readback | all 33 files / 636280 bytes matched SHA256, blob SHA, size and tree path | Exact code head |

## Three distinct source identities

These are canonical source-inventory SHA256 values, not Git commit IDs.

| Inventory | SHA256 | Evidence |
| --- | --- | --- |
| Behavior-tested | `{TESTED}` | 881 ordinary + 6 Root; 17 source QA |
| Maintained/compiled | `{COMPILED}` | fix/fmt and binary compile |
| Final | `{FINAL}` | exact marker alignment and final whole-tree caller proof |

Seventeen Rust files changed during maintenance: formatting/import order and one Copy cleanup.
Static review found no material behavior change. No behavior or source-QA tests ran after maintenance.
The final change touched only exact whitespace markers in CALLERS and one source-QA file;
all Rust bytes are identical to the compiled inventory. Guard character sequences and scanner code remain unchanged.

## Evidence files

Read the two archives together. [VALIDATION.md](VALIDATION.md) describes commands, corrections and limits.
[validation.json](validation.json), [source-stack.jsonl](source-stack.jsonl) and [SHA256SUMS](SHA256SUMS)
provide machine-readable results, the published dependency chain and archive/file integrity.

- `{native_name}`: 68 native receipts, logs, JUnit reports and input payloads, including original failures.
- `{source_name}`: {len(payloads)} source/review payloads, four complete canonical inventories,
  all 33 final source files, ten review cuts, runner sources and independent archive/GitHub readbacks.
- The reconcile index's original-inputs gzip is represented by the identical top-level inputs gzip.
  Its qualified-source gzip is represented by the identical canonical JSON in the source archive;
  reconstructed compressed bytes are not asserted identical to the original gzip.

## Product state and limits

`require_root_learning_assembled` still refuses unfinished assembly; registration retains
`production_ready: false`. Stage-owner assembly and evidence-client product caller sets remain empty.
Real trainer, independent evaluator, result signer and Circuit providers are not product-assembled.
This scope admission checks declared component digests, not actual gradient or tensor update masks.
Evidence V1 still binds the initial request/owners; it does not independently sign the V2 frozen scope.
Synthetic signed receipts and different UIDs do not establish scientific or operator independence.
The Root service test has no Device/Notes consumer qualification and uses synthetic Experience.
Learning checkpoint recovery does not publish a model generation: ordinary `Unpublished` is preserved.
No successor-task benefit, persistent continual learning, cloud training, merge or deployment is claimed.

The previous #5468 evidence was separately read back: its 760 ordinary / 3 Root reports and
65 archived payloads are corroborated. That earlier tested/maintained split remains distinct from this run.
'''
    (OUT / 'README.md').write_text(readme)
    test_bullets = '\n'.join('- `' + name + '`' for name in root_tests)
    validation_md = f'''# Validation details and interpretation

## Native execution

Host: ai395, isolated source `/home/qq/hepta-root-product-0744-20261109/source`.
Toolchain: Rust 1.96.0. The unchanged native helper is separately pinned in the runner/receipt.
The starting 10608 codex-rs objects were checked against the prior maintained baseline.
Each new inventory contains 10622 file/symlink entries, including CALLERS and two source-QA files.

The pre-maintenance cumulative candidate ran the repository-prescribed test entrypoint:

```sh
just test --locked --offline -p codex-hepta-agentd -p codex-hepta-learning-artifacts --lib --test-threads 2
```

Ordinary raw logs show 772 agentd and 109 learning-artifacts passing cases.
The six explicit Root parents were selected exactly by the native Root qualification runner:

{test_bullets}

Root JUnit has six cases, run UUID `17b138c5-3514-4ff2-951a-b8f55c3546bb`.
Its SHA256 is `5a73fad9e6e9d0ddaf0bbc98a7a526353c79dd30ad684b0bce057a558d198355`.
Raw logs, names, UUID, report timestamp and original command window were checked together.
The public-service case records actual consumer UID 60001, schema 2 / Cell scope,
original retained writer and dedicated listener, one restored receipt and exact retry.
Nested process helpers are not additional parent tests.

Source audit ran scanner self-test, whole-tree verify, and 17 bootstrap/scope/collision regressions.
Both scanner implementation files retain their baseline hashes.

## Required maintenance and final source proof

After behavior qualification, the repository-required maintenance ran:

```sh
just fix --locked --offline -p codex-hepta-agentd -p codex-hepta-learning-artifacts
just fmt
cargo check --locked --offline -p codex-hepta-agentd -p codex-hepta-learning-artifacts --bins
```

All three exited 0. Seventeen Rust files changed mechanically, including one redundant clone cleanup.
The maintained inventory is `{COMPILED}`.
No tests were rerun after maintenance, in accordance with the repository's instructions.
The final full source verifier ran `python3 scripts/verify_hepta_callers.py verify` and exited 0.
It covered 6157 Rust files, 188 boundaries and 170 protected-file entries (133 distinct paths).
It reports `PASS_HEPTA_CALLER_CLOSED_SET` and `authorityGranted=false`.

## Preserved failures and collection correction

1. Initial v1 compilation exited 101 on ambiguous assertion imports and missing optional
   scope fields in existing test fixtures. Those errors were fixed before v2 behavior tests.
2. Initial source audit found a test helper missing an explicit test-only impl annotation,
   plus a broad same-name constructor matcher. Existing typed receiver resolution fixed
   the matcher; the scanner implementation was not changed. The collision regression passed.
3. The original Root command exited 0, but its wrapper looked under CARGO_TARGET_DIR for JUnit.
   The actual report was under source/codex-rs/target/nextest/local/junit.xml, so collection failed.
   The original failed receipt/status/log remain unchanged and are included in the native archive.
   Reconciliation verified the existing six-case report and did not rerun Root tests.
4. That Root report had overwritten the ordinary JUnit. The identical ordinary command ran
   once more before maintenance; full raw case inventories matched the original run and new JUnit.
   This does not add 881 more distinct cases. Reconciliation explicitly records one rerun.
5. The first post-fmt source verifier rejected a single-line literal marker after rustfmt
   wrapped a method chain. Its failed receipt remains. Only exact marker whitespace was aligned
   in CALLERS and one source-QA file; non-whitespace guard sequences and every Rust byte remained fixed.
   The final whole-tree verifier then passed. Source-QA tests were not rerun on those final marker bytes.

The archives retain distinct failed, corrected and successful receipts. No original failure was relabeled.
The independent readback records the two reconcile-index references resolved by the companion archive.

## Published source and review cuts

All ten source cuts are based on the previous cut, starting from `{BASE}`.
Their changed-line counts are 280, 301, 439, 444, 115, 306, 408, 287, 493 and 452.
The final cumulative tree is `{TREE}` and code head is `{CODE}`.
Exact-ref connector readback checked all 33 files against the final local/native source inventory,
including content SHA256, Git blob SHA1, size and tree membership. The reports are in the source archive.
The v3 review-cut issue was fixed in v4: cut 4 includes all legacy registration-test adaptations.
These are cumulative review cuts; individual cuts have no separately claimed native/CI qualification.

## Product acceptance remains HOLD

The unchanged startup guard, empty product caller sets and `production_ready: false` are intentional.
Actual training/evaluation/signing owners and Circuit providers are absent from this product assembly.
Frozen Cell/Organ scope checks declared components after authenticated Training and on recovery;
it does not prove execution-time tensor masking, data isolation or downstream benefit.
Evidence receipts use initial-request binding, not an independent signature over FrozenLearningScopeV2.
The actual UID test uses pre-signed fixtures; the Root service test uses synthetic Experience receipts.
Different UIDs are process-custody evidence, not independent scientific evaluation.
No Device/Notes consumer lane, formal generation publication/recovery, sustained operation or deployment
is qualified by this stack. `Unpublished` remains the ordinary generation boundary.
'''
    (OUT / 'VALIDATION.md').write_text(validation_md)
    sums = []
    for p in sorted(OUT.iterdir()):
        if p.is_file() and p.name != 'SHA256SUMS':
            sums.append(sha(p.read_bytes()) + '  ' + p.name)
    (OUT / 'SHA256SUMS').write_text('\n'.join(sums) + '\n')
    textual_lines = sum(len(p.read_text().splitlines()) for p in OUT.iterdir() if p.is_file() and p.suffix != '.xz')
    assert textual_lines < 500, textual_lines
    output_manifest = []
    for p in sorted(OUT.iterdir()):
        b = p.read_bytes()
        output_manifest.append({'path': FOLDER + '/' + p.name, 'local_path': str(p), 'bytes': len(b), 'sha256': sha(b), 'blob_sha': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest(), 'binary': p.suffix == '.xz'})
    (CONTROL / 'qualification-publication-manifest.json').write_bytes(json_bytes(output_manifest))
    print(json.dumps({'files': len(output_manifest), 'textual_added_lines': textual_lines, 'archives': archives, 'source_inventory': FINAL, 'output': str(OUT)}, indent=2))


if __name__ == '__main__':
    main()
