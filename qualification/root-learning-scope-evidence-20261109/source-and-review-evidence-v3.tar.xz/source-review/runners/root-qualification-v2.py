#!/usr/bin/env python3
"""Six exact Root parent tests, after ordinary tests and before fix/fmt.

No source is edited. Setup creates only this attempt's private Root directories
and one bind mount in a newly unshared mount namespace. It never mounts over an
existing owner, resets authority state, broadens an ignored-test selector, or
retries a test. Existing nextest per-case timeouts bound execution; compilation
and Cargo lock waits are not killed by this script. The outer native job owns
its overall deadline. Use --print-plan for a read-only command preview.
"""

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

ROOT = Path('/home/qq/hepta-root-product-0744-20261109')
SOURCE = ROOT / 'source'
EVIDENCE = ROOT / 'evidence'
TARGET = ROOT / 'target'
TESTS = [
    'authority_host_service::writer::learning_registration::tests::'
    'root_learning_registration_reopens_without_replacing_original_history',
    'authority_host_service::writer::learning_registration::tests::'
    'root_learning_sealed_pin_and_dedicated_uds_recover_original_checkpoint',
    'root_production_handoff::learning::tests::'
    'root_learning_handoff_reaches_dedicated_uid_with_original_root_pin',
    'authority_host_service::writer::learning_registration::tests::'
    'root_scoped_learning_reopens_exact_scope_and_refuses_legacy_client',
    'learning_iteration_evidence_client::tests::root::'
    'original_external_uid_returns_a_verified_receipt_through_held_pidfd',
    'authority_host_learning_service_root_tests::'
    'root_learning_public_registration_serves_retained_writer_and_recovers_history',
]
FILTER = ' | '.join(f'test(={name})' for name in TESTS)
COMMAND = [
    'just', 'test', '--locked', '--offline', '-p', 'codex-hepta-agentd',
    '--lib', '--run-ignored', 'only', '-E', FILTER, '--test-threads', '1',
    '--retries', '0', '--success-output', 'final', '--failure-output', 'final',
]
ENV_KEYS = [
    'PATH', 'RUSTUP_HOME', 'RUSTUP_TOOLCHAIN', 'CARGO_HOME', 'LIBCLANG_PATH',
    'BINDGEN_EXTRA_CLANG_ARGS', 'CARGO_TARGET_DIR', 'CARGO_INCREMENTAL',
    'CARGO_BUILD_JOBS', 'CARGO_PROFILE_TEST_DEBUG', 'CARGO_PROFILE_DEV_DEBUG',
    'CODEX_REPO_ROOT', 'PYTHONDONTWRITEBYTECODE',
    'CARGO_BIN_EXE_hepta-joint-propose', 'CARGO_BIN_EXE_hepta_joint_propose',
]


def digest(path):
    if path.is_symlink():
        return hashlib.sha256(os.readlink(path).encode()).hexdigest()
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def publish(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def inventory(attempt, inputs_path):
    inputs = json.loads(gzip.decompress(inputs_path.read_bytes()))
    pin = inputs['baseline_manifest']
    manifest_path = Path(pin['path'])
    if not manifest_path.is_absolute():
        raise RuntimeError('absolute original baseline manifest path required')
    raw = gzip.decompress(manifest_path.read_bytes())
    if hashlib.sha256(raw).hexdigest() != pin['sha256']:
        raise RuntimeError('original decompressed baseline manifest hash mismatch')
    baseline = [row for row in json.loads(raw)
                if row['path'].startswith('codex-rs/') and row['kind'] in ('file', 'symlink')]
    if len(baseline) != pin['codex_objects']:
        raise RuntimeError('original baseline object count mismatch')
    names = {row['path'] for row in baseline} | {row['path'] for row in inputs['files']}
    rows = []
    for name in sorted(names):
        path = SOURCE / name
        if Path(name).is_absolute() or '..' in Path(name).parts:
            raise RuntimeError('invalid source inventory path')
        rows.append({'path': name, 'sha256': digest(path),
                     'kind': 'symlink' if path.is_symlink() else 'file'})
    data = json.dumps(rows, sort_keys=True, separators=(',', ':')).encode()
    value = hashlib.sha256(data).hexdigest()
    output = attempt / (value + '.files.json.gz')
    if not output.exists():
        output.write_bytes(gzip.compress(data, mtime=0))
    return value


def private_directory(path):
    path.mkdir(mode=0o700)
    metadata = path.lstat()
    if not stat.S_ISDIR(metadata.st_mode) or metadata.st_uid != 0 or stat.S_IMODE(metadata.st_mode) != 0o700:
        raise RuntimeError(f'Root0700 custody absent: {path}')
    return {'path': str(path), 'device': metadata.st_dev, 'inode': metadata.st_ino,
            'uid': metadata.st_uid, 'mode': oct(stat.S_IMODE(metadata.st_mode))}


def report_identity(path):
    if not path.exists():
        return None
    metadata = path.stat()
    return (metadata.st_dev, metadata.st_ino, metadata.st_size, metadata.st_mtime_ns, digest(path))


def run_setup(command, receipt):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            timeout=15, check=False)
    receipt['setup_commands'].append({'command': command, 'exit_code': result.returncode,
                                     'stdout': result.stdout.decode(errors='replace'),
                                     'stderr': result.stderr.decode(errors='replace')})
    if result.returncode:
        raise RuntimeError(f'owned mount setup failed: {command[0]} (exit {result.returncode})')


def refuse_maintenance(status_path):
    # The exact inventory gate below is mandatory even when no marker exists.
    # Also refuse a recorded maintenance operation whose formatting was a no-op.
    for path in EVIDENCE.glob('*.json'):
        try:
            record = json.loads(path.read_text())
        except (OSError, ValueError):
            continue
        command = record.get('command', []) if isinstance(record, dict) else []
        if isinstance(command, list) and any(str(value) in {'fix', 'fmt'} for value in command):
            raise RuntimeError(f'refusing behavior tests after recorded fix/fmt: {path.name}')
    state = json.loads(status_path.read_text())
    if state.get('phase') != 'tests-finished' or state.get('exit_code') != 0:
        raise RuntimeError('successful ordinary pre-maintenance phase required')
    return state


def run_namespace(args, attempt):
    receipt = {'schema_version': 1, 'attempt': args.attempt, 'phase': 'preflight',
               'root_uid': os.getuid(), 'root_euid': os.geteuid(),
               'tests_requested': TESTS, 'command': COMMAND, 'cwd': str(SOURCE),
               'expected_source_inventory': args.expected_inventory,
               'ordinary_receipt': str(args.ordinary_receipt),
               'ordinary_status': str(args.ordinary_status),
               'inputs': str(args.inputs),
               'setup_commands': [], 'tests_executed': False, 'test_retries': 0,
               'started_unix_seconds': time.time(), 'production_acceptance': 'HOLD'}
    report = attempt / 'qualification.json'
    protected = None
    public_tmp = None
    mountpoint = None
    mounted = False
    code = 1
    try:
        if os.getuid() != 0 or os.geteuid() != 0:
            raise RuntimeError('actual Root is required')
        namespace = os.readlink('/proc/self/ns/mnt')
        if namespace == args.parent_mount_namespace:
            raise RuntimeError('the qualification must use its newly unshared mount namespace')
        receipt['mount_namespace'] = namespace
        receipt['parent_mount_namespace'] = args.parent_mount_namespace
        state = refuse_maintenance(args.ordinary_status)
        ordinary = json.loads(args.ordinary_receipt.read_text())
        if (ordinary.get('exit_code') != 0
                or ordinary.get('source_before') != args.expected_inventory
                or ordinary.get('source_after') != args.expected_inventory):
            raise RuntimeError('ordinary gate must pass on this exact unchanged source')
        receipt['ordinary_receipt_sha256'] = digest(args.ordinary_receipt)
        receipt['ordinary_status_sha256'] = digest(args.ordinary_status)
        receipt['inputs_sha256'] = digest(args.inputs)
        payload = gzip.decompress(args.inputs.read_bytes())
        payload_digest = hashlib.sha256(payload).hexdigest()
        if state.get('payload_sha256') is not None and state['payload_sha256'] != payload_digest:
            raise RuntimeError('inputs payload differs from the selected ordinary status')
        receipt['inputs_payload_sha256'] = payload_digest
        receipt['baseline_manifest'] = json.loads(payload)['baseline_manifest']
        receipt['source_before'] = inventory(attempt, args.inputs)
        if receipt['source_before'] != args.expected_inventory:
            raise RuntimeError('source changed after ordinary tests; do not mix or rerun maintenance')
        env = os.environ.copy()
        selected = {key: ordinary['environment'][key] for key in ENV_KEYS}
        if selected['CARGO_TARGET_DIR'] != str(TARGET) or selected['CODEX_REPO_ROOT'] != str(SOURCE):
            raise RuntimeError('ordinary environment uses another source/target')
        helper = Path(selected['CARGO_BIN_EXE_hepta-joint-propose'])
        if (selected['CARGO_BIN_EXE_hepta_joint_propose'] != str(helper)
                or digest(helper) != state['helper_sha256']):
            raise RuntimeError('original helper identity differs from the ordinary run')
        receipt['helper_sha256'] = digest(helper)
        env.update(selected)
        protected = Path(tempfile.mkdtemp(prefix='hepta-root-product-0744-', dir='/root'))
        os.chmod(protected, 0o700)
        original_source = protected / 'source'
        mountpoint = protected / 'state-bind'
        checkpoint = protected / 'checkpoint-tests'
        receipt['protected_directories'] = [private_directory(path)
                                            for path in (original_source, mountpoint, checkpoint)]
        run_setup(['/usr/bin/mount', '--bind', str(original_source), str(mountpoint)], receipt)
        mounted = True
        source_stat = original_source.stat()
        mounted_stat = mountpoint.stat()
        if (source_stat.st_dev, source_stat.st_ino) != (mounted_stat.st_dev, mounted_stat.st_ino):
            raise RuntimeError('bind source/mountpoint identity mismatch')
        entries = [line for line in Path('/proc/self/mountinfo').read_text().splitlines()
                   if line.split()[4] == str(mountpoint)]
        if len(entries) != 1 or any(token.startswith('shared:') for token in entries[0].split(' - ')[0].split()[6:]):
            raise RuntimeError('one private exact bind mount is required')
        receipt['bind'] = {'source': str(original_source), 'mountpoint': str(mountpoint),
                           'device': mounted_stat.st_dev, 'inode': mounted_stat.st_ino,
                           'mountinfo': entries[0]}
        public_tmp = Path(tempfile.mkdtemp(prefix='hq0744-', dir='/run'))
        os.chmod(public_tmp, 0o755)
        # The external-UID socket fixture needs traversable ancestors. Never use
        # /root or a private task checkout as TMPDIR for its UID60001 endpoint.
        qualification_env = {
            'HEPTA_CHECKPOINT_TEST_ROOT': str(checkpoint),
            'HEPTA_HOST_AUTHORITY_QUALIFICATION_STATE_PARENT': str(mountpoint),
            'HEPTA_HOST_AUTHORITY_QUALIFICATION_SOURCE': str(original_source),
            'TMPDIR': str(public_tmp),
        }
        env.update(qualification_env)
        receipt['environment'] = {**selected, **qualification_env}
        reports = [TARGET / 'nextest/local/junit.xml', TARGET / 'nextest/default/junit.xml']
        before = {str(path): report_identity(path) for path in reports}
        receipt['phase'] = 'root-tests'
        receipt['test_started_unix_seconds'] = time.time()
        publish(report, receipt)
        log = attempt / 'root-six.log'
        with log.open('xb') as stream:
            result = subprocess.run(COMMAND, cwd=SOURCE, env=env, stdout=stream,
                                    stderr=subprocess.STDOUT, check=False)
        receipt['command_exit_code'] = result.returncode
        receipt['elapsed_seconds'] = time.time() - receipt['test_started_unix_seconds']
        receipt['log_sha256'] = digest(log)
        receipt['log_bytes'] = log.stat().st_size
        receipt['source_after'] = inventory(attempt, args.inputs)
        if receipt['source_after'] != receipt['source_before']:
            raise RuntimeError('source changed during Root qualification')
        matches = []
        for path in reports:
            identity = report_identity(path)
            if identity is None or identity == before[str(path)]:
                continue
            parsed = ET.fromstring(path.read_bytes())
            cases = parsed.findall('.//testcase')
            names = [case.attrib['name'] for case in cases]
            if len(names) != len(TESTS) or set(names) != set(TESTS):
                continue
            output = attempt / f'root-six-{path.parent.name}.junit.xml'
            output.write_bytes(path.read_bytes())
            matches.append({'path': str(output), 'sha256': digest(output), 'cases': names,
                            'failures': len(parsed.findall('.//failure')),
                            'errors': len(parsed.findall('.//error')),
                            'skipped': len(parsed.findall('.//skipped'))})
        receipt['junit'] = matches
        receipt['tests_executed'] = bool(matches)
        if result.returncode != 0:
            raise RuntimeError(f'Root command failed (exit {result.returncode}); preserve original log')
        if len(matches) != 1 or any(matches[0][key] for key in ('failures', 'errors', 'skipped')):
            raise RuntimeError('one fresh JUnit report containing exactly six successful parent cases is required')
        receipt['phase'] = 'passed'
        receipt['passed_parent_cases'] = len(TESTS)
        receipt['nested_children_counted_separately'] = False
        code = 0
    except Exception as error:
        receipt['phase'] = 'failed'
        receipt['error'] = repr(error)
    finally:
        cleanup = []
        if mounted:
            try:
                run_setup(['/usr/bin/umount', str(mountpoint)], receipt)
                mounted = False
                cleanup.append('owned bind unmounted')
            except Exception as error:
                cleanup.append(f'owned unmount failed; namespace teardown remains: {error!r}')
                code = 1
        for path, label in ((protected if not mounted and code == 0 else None, 'private Root'),
                            (public_tmp, 'traversable temporary')):
            if path is not None:
                try:
                    shutil.rmtree(path)
                    cleanup.append(f'owned {label} fixture removed')
                except Exception as error:
                    cleanup.append(f'owned {label} cleanup failed: {error!r}')
                    code = 1
        if protected is not None and protected.exists():
            receipt['retained_private_fixture_for_failure_review'] = str(protected)
        receipt['cleanup'] = cleanup
        receipt['exit_code'] = code
        if code and receipt['phase'] == 'passed':
            receipt['phase'] = 'cleanup-failed'
        receipt['finished_unix_seconds'] = time.time()
        receipt['boundary'] = ('Six explicit mechanism qualifications; synthetic scope and signed fixture '
                               'records do not establish independent evaluation, deployed stage owners, '
                               'Circuit providers, training, model publication, or continual operation.')
        publish(report, receipt)
        print(json.dumps(receipt), flush=True)
    return code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', default='root-six')
    parser.add_argument('--expected-inventory')
    parser.add_argument('--ordinary-receipt', type=Path)
    parser.add_argument('--ordinary-status', type=Path)
    parser.add_argument('--inputs', type=Path)
    parser.add_argument('--print-plan', action='store_true')
    parser.add_argument('--parent-mount-namespace')
    args = parser.parse_args()
    if args.print_plan:
        print(json.dumps({'command': COMMAND, 'cwd': str(SOURCE), 'tests': TESTS,
                          'setup_command_timeout_seconds': 15,
                          'existing_nextest_default_per_test_seconds': 60,
                          'retries': 0, 'source_edits': False,
                          'requires': ['ordinary gate passed at exact expected inventory',
                                       'explicit same-attempt ordinary receipt/status/input paths',
                                       'original gzip baseline manifest pinned by decompressed SHA256 and object count',
                                       'actual Root', 'new private mount namespace',
                                       'Root0700 original source and bind',
                                       'traversable root-owned TMPDIR',
                                       'before fix/fmt']}, indent=2))
        return 0
    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}', args.attempt):
        parser.error('bounded attempt identity required')
    if not re.fullmatch(r'[a-f0-9]{64}', args.expected_inventory or ''):
        parser.error('--expected-inventory must pin the successful ordinary inventory')
    for name in ('ordinary_receipt', 'ordinary_status', 'inputs'):
        path = getattr(args, name)
        if path is None or not path.is_absolute() or not path.is_relative_to(EVIDENCE):
            parser.error(f'--{name.replace("_", "-")} must explicitly select a file in {EVIDENCE}')
        if path.is_symlink() or not path.is_file() or path.resolve() != path:
            parser.error(f'--{name.replace("_", "-")} must be an existing non-symlink file')
    if os.getuid() != 0 or os.geteuid() != 0:
        parser.error('invoke through the already authorized actual Root qualification path')
    attempt = EVIDENCE / args.attempt
    if args.parent_mount_namespace is None:
        attempt.mkdir(mode=0o755, exist_ok=False)
        command = ['/usr/bin/unshare', '--mount', '--propagation', 'private', '--',
                   sys.executable, str(Path(__file__).resolve()), '--attempt', args.attempt,
                   '--expected-inventory', args.expected_inventory,
                   '--ordinary-receipt', str(args.ordinary_receipt),
                   '--ordinary-status', str(args.ordinary_status),
                   '--inputs', str(args.inputs),
                   '--parent-mount-namespace', os.readlink('/proc/self/ns/mnt')]
        publish(attempt / 'launch.json', {'command': command, 'source_edited': False,
                                          'created_unix_seconds': time.time()})
        result = subprocess.run(command, check=False)
        if not (attempt / 'qualification.json').exists():
            publish(attempt / 'setup-refusal.json', {'exit_code': result.returncode,
                    'tests_executed': False, 'reason': 'private mount namespace entry did not complete'})
        return result.returncode
    if not attempt.is_dir():
        parser.error('owned attempt directory must be created by the outer invocation')
    return run_namespace(args, attempt)


if __name__ == '__main__':
    raise SystemExit(main())
