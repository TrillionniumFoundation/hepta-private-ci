from pathlib import Path
import hashlib,json,subprocess
r=Path('/workspace/scratch/0744c4dfe130');old=r/'publication-final-stack';out=r/'publication-final-stack-v4';out.mkdir();(out/'stages').mkdir()
plan=json.loads((old/'stack.json').read_text());source=old/'projection';repo=out/'projection'
def cmd(args,cwd=None):return subprocess.check_output(args,cwd=cwd,stderr=subprocess.PIPE)
base=cmd(['git','rev-parse','HEAD~9'],source).decode().strip()
cmd(['git','clone','--no-hardlinks','--quiet',str(source),str(repo)]);cmd(['git','checkout','--quiet','--detach',base],repo)
cmd(['git','config','user.name','Hepta review packaging'],repo);cmd(['git','config','user.email','hepta-review@localhost'],repo)
entries=[]
for stage in plan['stages']:
 changes=json.loads(Path(stage['changes']).read_text())
 if stage['number']==9:
  for row in changes:row['content']=(r/'integration'/row['path']).read_text()
 if stage['number']!=4:entries.append((stage['slug'],changes));continue
 path='codex-rs/hepta-agentd/src/root_production_learning_inputs_tests.rs'
 original=cmd(['git','show',base+':'+path],source).decode();needle='        initial_snapshot: profile.encoded_initial().to_owned(),\n'
 assert original.count(needle)==1
 compatibility=original.replace(needle,needle+'        update_scope: None,\n')
 final=next(row['content'] for row in changes if row['path']==path);assert final.startswith(compatibility)
 product=[row for row in changes if not row['path'].endswith('_tests.rs') or row['path'].endswith('/authority_host_learning_registration_tests.rs')]+[{'path':path,'content':compatibility}]
 tests=[row for row in changes if row['path'].endswith('_tests.rs') and not row['path'].endswith('/authority_host_learning_registration_tests.rs')]
 entries.extend([('root-scoped-handoff',product),('root-scope-qualification',tests)])
result={'schema_version':1,'status':'BUILT','code_baseline':plan['code_baseline'],'suggested_first_parent':plan['suggested_first_parent'],'qualification_scope':plan['qualification_scope'],'never_publish_synthetic_projection_history':True,'stages':[]}
for number,(slug,rows) in enumerate(entries,1):
 for row in rows:
  p=repo/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_text(row['content'])
 cmd(['git','add','--',*[row['path'] for row in rows]],repo)
 stats=cmd(['git','diff','--cached','--numstat'],repo).decode().splitlines();count=sum(int(a)+int(d) for a,d,_ in [line.split('\t',2) for line in stats]);assert count<500,(number,count)
 stem=f'{number:02d}-{slug}';change=out/'stages'/f'{stem}.changes.json';change.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
 patch=cmd(['git','diff','--cached','--binary'],repo);patch_path=out/'stages'/f'{stem}.patch';patch_path.write_bytes(patch)
 cmd(['git','-c','core.hooksPath=/dev/null','-c','commit.gpgsign=false','commit','--quiet','-m',stem],repo)
 result['stages'].append({'number':number,'slug':slug,'changes':str(change),'changes_sha256':hashlib.sha256(change.read_bytes()).hexdigest(),'patch':str(patch_path),'patch_sha256':hashlib.sha256(patch).hexdigest(),'changed_lines':count,'files':[{'path':row['path'],'sha256':hashlib.sha256(row['content'].encode()).hexdigest()} for row in rows]})
paths=sorted({row['path'] for _,rows in entries for row in rows});matches=[]
for path in paths:
 a=(repo/path).read_bytes();b=(r/'integration'/path).read_bytes();assert a==b,path;matches.append({'path':path,'sha256':hashlib.sha256(a).hexdigest()})
result['source_file_count']=len(paths);result['maintained_source_inventory']=json.loads((r/'native-control/static-marker-repair-v3-summary.json').read_text())['source_after'];result['per_cut_tests_claimed']=False
(out/'stack.json').write_text(json.dumps(result,indent=2)+'\n');(out/'final-source-match.json').write_text(json.dumps({'exact_final_match':True,'files':matches,'source_file_count':len(matches)},indent=2)+'\n')
print(json.dumps({'status':'BUILT','code_cuts':len(entries),'source_files':len(paths),'counts':[s['changed_lines'] for s in result['stages']]}))
