#!/usr/bin/env python3
"""Rebuild nine local review cuts from the frozen v2 plan and maintained source.

No input checkout is modified, and no remote command is used. Shared files keep
their planned intermediate versions; their final modifying cut receives the full
maintained file. Each stage emits a JSON array of {path, content}, a patch, and
counts. A BUILT result requires exact final bytes, stable inputs, complete file
coverage, present newly registered modules, and fewer than 500 lines per cut.
This is source packaging, not native qualification or publication authority.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
from typing import Any


WORKSPACE = Path(__file__).resolve().parents[1]
DEFAULT_PLAN = WORKSPACE / "review-stack-plan-v2/stack-plan.json"
LINE_LIMIT = 500


class BuildError(Exception):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise BuildError(message)


def safe_path(value: str) -> str:
    path = PurePosixPath(value)
    require(
        bool(value) and not path.is_absolute() and ".." not in path.parts
        and ".git" not in path.parts and str(path) == value
        and not any(ord(char) < 32 for char in value),
        f"Unsafe or noncanonical source path: {value!r}",
    )
    return value


def git(root: Path, *args: str, optional: bool = False) -> bytes | None:
    environment = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    result = subprocess.run(
        ["git", "-c", "core.hooksPath=/dev/null", "-c", "commit.gpgsign=false",
         "-C", str(root), *args],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=environment,
    )
    if result.returncode:
        if optional:
            return None
        raise BuildError(f"Local git {' '.join(args)} failed: {result.stderr.decode(errors='replace')}")
    return result.stdout


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def text_content(data: bytes, path: str) -> str:
    require(b"\0" not in data, f"Binary content is unsupported: {path}")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError as error:
        raise BuildError(f"Non-UTF-8 source: {path}") from error


def source_bytes(root: Path, relative: str) -> bytes:
    path = root / safe_path(relative)
    require(path.resolve().is_relative_to(root), f"Source escapes integration: {relative}")
    require(path.exists() and not path.is_symlink(), f"Missing or symlink source: {relative}")
    require(stat.S_ISREG(path.stat().st_mode), f"Non-regular source: {relative}")
    data = path.read_bytes()
    text_content(data, relative)
    return data


def write_json(path: Path, value: Any) -> None:
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode())


def dirty_paths(root: Path, base: str) -> set[str]:
    tracked = git(root, "diff", "--no-ext-diff", "--no-renames", "--name-only", "-z", base)
    others = git(root, "ls-files", "--others", "--exclude-standard", "-z")
    assert tracked is not None and others is not None
    result = {safe_path(part.decode()) for part in (tracked + others).split(b"\0") if part}
    # Python's local bytecode is an execution by-product, never a source input.
    return {path for path in result if "__pycache__" not in PurePosixPath(path).parts}


def check_new_modules(state: dict[str, bytes], added_rust: set[str]) -> list[str]:
    """Check registration of newly introduced modules, not Rust type correctness."""
    checked = []
    declaration = re.compile(
        r"(?P<attrs>(?:\s*#\[[^\]]*\]\s*)*)"
        r"(?:pub(?:\([^)]*\))?\s+)?mod\s+(?P<name>[A-Za-z_]\w*)\s*;"
    )
    for path, data in state.items():
        if not path.endswith(".rs"):
            continue
        code = re.sub(r"(?m)^\s*//[^\n]*", "", text_content(data, path))
        for match in declaration.finditer(code):
            explicit = re.search(r'#\[\s*path\s*=\s*"([^"]+)"\s*\]', match["attrs"])
            parent = PurePosixPath(path).parent
            candidates = [str(parent / explicit[1])] if explicit else [
                str(parent / (match["name"] + ".rs")),
                str(parent / match["name"] / "mod.rs"),
            ]
            for target in set(candidates) & added_rust:
                require(target in state, f"Module registered before its source: {path} -> {target}")
                checked.append(f"{path} -> {target}")
    return sorted(set(checked))


def build(args: argparse.Namespace) -> dict[str, Any]:
    integration = args.integration.resolve()
    plan_path = args.plan.resolve()
    plan_bytes = plan_path.read_bytes()
    plan = json.loads(plan_bytes)
    template = (args.projection or plan_path.parent / "projection").resolve()
    output = args.output.resolve()
    require(not output.exists(), f"Output already exists; choose a fresh directory: {output}")
    require(not output.is_relative_to(integration), "Output must be outside integration")
    require(not output.is_relative_to(template), "Output must be outside the template projection")
    cuts = plan["cuts"]
    require([cut["number"] for cut in cuts] == list(range(1, 10)), "Expected exactly cuts 01–09")
    planned = {safe_path(row["path"]): row for row in plan["source_files"]}
    require(len(planned) == len(plan["source_files"]), "Duplicate planned source paths")
    baseline_commit = plan["local_projection_baseline"]
    require(bool(re.fullmatch(r"[0-9a-f]{40}", baseline_commit)), "Invalid template baseline SHA")
    base_ref = git(integration, "rev-parse", "--verify", args.integration_base + "^{commit}")
    assert base_ref is not None
    integration_base = base_ref.decode().strip()
    baseline: dict[str, bytes | None] = {}
    versions: dict[tuple[int, str], bytes] = {}
    modifying: dict[str, list[int]] = {}
    previous = baseline_commit
    for cut in cuts:
        number = cut["number"]
        commit = cut["local_projection_commit"]
        require(bool(re.fullmatch(r"[0-9a-f]{40}", commit)), "Invalid template stage SHA")
        parents = git(template, "rev-list", "--parents", "-n", "1", commit)
        assert parents is not None
        require(parents.decode().split() == [commit, previous], f"Template chain differs at cut {number}")
        paths = {safe_path(row["path"]) for row in cut["files"]}
        observed = git(template, "diff", "--no-ext-diff", "--no-renames", "--name-only", "-z", previous, commit)
        assert observed is not None
        require(paths == {x.decode() for x in observed.split(b"\0") if x}, f"Template file list differs at cut {number}")
        for path in paths:
            data = git(template, "show", f"{commit}:{path}")
            assert data is not None
            text_content(data, path)
            versions[number, path] = data
            modifying.setdefault(path, []).append(number)
        previous = commit
    require(set(modifying) == set(planned), "Plan omits or adds a source relative to its stage files")
    for path, row in planned.items():
        data = git(template, "show", f"{baseline_commit}:{path}", optional=True)
        require((blob_sha(data) if data is not None else None) == row["baseline_git_blob"], f"Baseline blob differs: {path}")
        require(sha256(versions[modifying[path][-1], path]) == row["sha256"], f"Template final source differs: {path}")
        baseline[path] = data
    assignments = {}
    for value in args.assign:
        path, separator, stage = value.rpartition("=")
        require(bool(separator) and stage.isdigit() and 1 <= int(stage) <= 9, f"Expected --assign path=1..9: {value}")
        path = safe_path(path)
        require(path not in modifying and path not in assignments, f"Assignment already planned: {path}")
        assignments[path] = int(stage)
        modifying[path] = [int(stage)]
        baseline[path] = git(integration, "show", f"{integration_base}:{path}", optional=True)
    initial_dirty = dirty_paths(integration, integration_base)
    unknown = sorted(initial_dirty - set(modifying))
    require(not unknown, "Unassigned integration changes/additions: " + ", ".join(unknown) + "; use an explicit --assign path=cut after review")
    final = {path: source_bytes(integration, path) for path in sorted(modifying)}
    output.mkdir(parents=True)
    projection = output / "projection"
    projection.mkdir()
    stages_dir = output / "stages"
    stages_dir.mkdir()
    state = {path: data for path, data in baseline.items() if data is not None}
    for path, data in state.items():
        target = projection / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    git(projection, "init", "-q")
    git(projection, "config", "core.autocrlf", "false")
    git(projection, "config", "user.name", "Local Review Stack Builder")
    git(projection, "config", "user.email", "review-stack-builder@local.invalid")
    git(projection, "add", ".")
    git(projection, "commit", "-qm", "LOCAL ONLY baseline projection; never publish synthetic history")
    added_rust = {path for path, data in baseline.items() if data is None and path.endswith(".rs")}
    rows = []
    for cut in cuts:
        number = cut["number"]
        stage_paths = sorted(path for path, numbers in modifying.items() if number in numbers)
        for path in stage_paths:
            data = final[path] if number == modifying[path][-1] else versions[number, path]
            state[path] = data
            target = projection / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        modules = check_new_modules(state, added_rust)
        git(projection, "add", "-N", ".")
        patch = git(projection, "diff", "--no-ext-diff", "--no-renames", "--binary")
        raw_counts = git(projection, "diff", "--no-ext-diff", "--no-renames", "--numstat", "-z")
        assert patch is not None and raw_counts is not None
        files = []
        for part in raw_counts.split(b"\0"):
            if not part:
                continue
            plus, minus, raw_path = part.split(b"\t", 2)
            require(plus.isdigit() and minus.isdigit(), "Unexpected binary source diff")
            path = raw_path.decode()
            files.append({"path": path, "additions": int(plus), "deletions": int(minus), "sha256": sha256(state[path])})
        require({row["path"] for row in files} <= set(stage_paths), f"Unexpected stage mutation at cut {number}")
        name = f"{number:02}-{cut['slug']}"
        require(bool(re.fullmatch(r"[0-9a-z_-]+", name)), "Unsafe stage slug")
        patch_path = stages_dir / (name + ".patch")
        changes_path = stages_dir / (name + ".changes.json")
        patch_path.write_bytes(patch)
        changes = [{"path": row["path"], "content": text_content(state[row["path"]], row["path"])} for row in files]
        write_json(changes_path, changes)
        count = sum(row["additions"] + row["deletions"] for row in files)
        rows.append({"number": number, "slug": cut["slug"], "files": files,
                     "changed_lines": count, "complex_limit_exclusive": LINE_LIMIT,
                     "limit_satisfied": count < LINE_LIMIT, "patch": str(patch_path),
                     "patch_sha256": sha256(patch), "changes": str(changes_path),
                     "changes_sha256": sha256(changes_path.read_bytes()),
                     "new_module_registration_checks": modules,
                     "native_validation_performed": False})
        git(projection, "add", ".")
        git(projection, "commit", "--allow-empty", "-qm", f"LOCAL ONLY cut {number:02}: {cut['slug']}")
    proof_files = []
    for path, expected in final.items():
        actual = (projection / path).read_bytes()
        require(actual == expected and state[path] == expected, f"Final source mismatch: {path}")
        proof_files.append({"path": path, "sha256": sha256(expected), "bytes": len(expected), "exact_match": True})
    tracked = git(projection, "ls-files", "-z")
    assert tracked is not None
    require({x.decode() for x in tracked.split(b"\0") if x} == set(final), "Final projection file set differs")
    require(dirty_paths(integration, integration_base) == initial_dirty, "Integration change inventory moved during build")
    for path, expected in final.items():
        require(source_bytes(integration, path) == expected, f"Integration changed during build: {path}")
    require(plan_path.read_bytes() == plan_bytes, "Plan changed during build")
    proof = {"exact_match": True, "file_set_match": True, "inputs_stable": True,
             "files": proof_files, "integration_mutated": False,
             "integration_base": integration_base, "plan_sha256": sha256(plan_bytes),
             "unassigned_changes": [], "explicit_new_assignments": assignments}
    write_json(output / "final-source-match.json", proof)
    rejected = [row["number"] for row in rows if not row["limit_satisfied"]]
    result = {"schema_version": 1, "status": "REJECTED" if rejected else "BUILT",
              "code_baseline": plan["code_baseline"], "suggested_first_parent": plan["suggested_first_parent"],
              "template_plan": str(plan_path), "integration": str(integration),
              "final_source_file_count": len(final), "final_source_match": str(output / "final-source-match.json"),
              "stages": rows, "oversized_cuts": rejected,
              "shared_file_policy": "Planned intermediates; maintained complete file at its last modifying cut",
              "native_validation_performed": False, "remote_calls_made": False,
              "never_publish_synthetic_projection_history": True,
              "qualification_scope": "One cumulative candidate; no per-cut compiler/test acceptance claim"}
    write_json(output / "stack.json", result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--integration", type=Path, default=WORKSPACE / "integration")
    parser.add_argument("--plan", type=Path, default=DEFAULT_PLAN)
    parser.add_argument("--projection", type=Path, help="Template git projection; default: plan sibling projection/")
    parser.add_argument("--integration-base", default="HEAD", help="Read-only local reference for discovering unplanned changes")
    parser.add_argument("--output", type=Path, required=True, help="Fresh output directory outside both input repositories")
    parser.add_argument("--assign", action="append", default=[], metavar="PATH=CUT", help="Explicitly assign an additional reviewed source file to cut 1..9")
    args = parser.parse_args()
    try:
        result = build(args)
    except (BuildError, OSError, ValueError, KeyError) as error:
        print(json.dumps({"status": "REJECTED", "error": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 2
    print(json.dumps({"status": result["status"], "output": str(args.output.resolve()),
                      "counts": [row["changed_lines"] for row in result["stages"]],
                      "oversized_cuts": result["oversized_cuts"]}, ensure_ascii=False))
    return 2 if result["oversized_cuts"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
