#!/usr/bin/env python3
"""Recover the original six-case Root evidence, then repair ordinary collection.

Run once as qq from the task's ordinary native executor, before fix/fmt. The only
privileged subprocess exports already existing evidence and, after preserving it,
returns the task's exact nextest report directories/files to qq if Root owns them.
It never starts a Root test, changes source, modifies an original receipt/status,
or removes a fixture. If original ordinary JUnit was overwritten, run the exact
original two-package ordinary command once; an existing output directory refuses
replay. A failed reconciliation remains a separate record, never an amendment to
the original failed collector. --print-plan performs no filesystem changes.
"""

import argparse
from datetime import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import stat
import subprocess
import sys
import time
import tomllib
import xml.etree.ElementTree as ET

ROOT = Path('/home/qq/hepta-root-product-0744-20261109')
SOURCE = ROOT / 'source'
EVIDENCE = ROOT / 'evidence'
OUT = EVIDENCE / 'reconcile-v2'
EXPECTED = '34f2b72cfc17988d70935393ffdd22b31b5334e00000bbb107ef3645fdba6bfd'
MANIFEST = EVIDENCE / (EXPECTED + '.files.json.gz')
ROOT_RECEIPT = EVIDENCE / 'root-six-v2/qualification.json'
ROOT_LOG = EVIDENCE / 'root-six-v2/root-six.log'
ORDINARY_RECEIPT = EVIDENCE / 'agentd-artifacts-lib-v2.json'
ORDINARY_LOG = EVIDENCE / 'agentd-artifacts-lib-v2.log'
STATUS = EVIDENCE / 'status-v2.json'
INPUTS = EVIDENCE / 'inputs-v2.json.gz'
AUDIT = EVIDENCE / 'audit-v2.json'
SHIM = Path('/home/qq/hepta-learning-native-4f559bf-d9fb-20261108/transfer/just')
ROOT_STARTED = 1794226380.8315532
ROOT_FINISHED = 1794226382.0906003
ROOT_JUNIT_SHA256 = '5a73fad9e6e9d0ddaf0bbc98a7a526353c79dd30ad684b0bce057a558d198355'
COMMAND = ['just', 'test', '--locked', '--offline', '-p', 'codex-hepta-agentd',
           '-p', 'codex-hepta-learning-artifacts', '--lib', '--test-threads', '2']
PACKAGES = {'codex-hepta-agentd', 'codex-hepta-learning-artifacts'}
TESTS = [
    'authority_host_service::writer::learning_registration::tests::'
    'root_learning_registration_reopens_without_replacing_original_history',
    'authority_host_service::writer::learning_registration::tests::'
    'root_learning_sealed_pin_and_dedicated_uds_recover_original_checkpoint',
    'root_production_handoff::learning::tests::'
    'root_learning_handoff_reaches_dedicated_uid_with_original_root_pin',
    'authority_host_service::writer::learning_registration::tests::'
    'root_scoped_learning_reopens_exact_scope_and_refuses_legacy_client',
    'learning_iteration_evidence_client::tests::root::'
    'original_external_uid_returns_a_verified_receipt_through_held_pidfd',
    'authority_host_learning_service_root_tests::'
    'root_learning_public_registration_serves_retained_writer_and_recovers_history',
]
REPORTS = [ROOT / 'target/nextest/local/junit.xml',
           ROOT / 'target/nextest/default/junit.xml',
           SOURCE / 'codex-rs/target/nextest/local/junit.xml',
           SOURCE / 'codex-rs/target/nextest/default/junit.xml']
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def capture(path, limit=64 * 1024 * 1024):
    """Read a bounded regular artifact and retain its actual file identity."""
    require(path.is_absolute() and path.resolve() == path, f'noncanonical artifact: {path}')
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= limit,
            f'bounded regular artifact required: {path}')
    with path.open('rb') as stream:
        data = stream.read(limit + 1)
    after = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_uid', 'st_gid', 'st_mode')
    require(all(getattr(before, name) == getattr(after, name) for name in fields),
            f'artifact changed while reading: {path}')
    require(len(data) == after.st_size, f'artifact length changed: {path}')
    return data, {'path': str(path), 'sha256': sha(data), 'bytes': len(data),
                  'device': after.st_dev, 'inode': after.st_ino,
                  'mtime_ns': after.st_mtime_ns, 'ctime_ns': after.st_ctime_ns,
                  'uid': after.st_uid, 'gid': after.st_gid,
                  'mode': oct(stat.S_IMODE(after.st_mode))}


def write_bytes(path, data):
    require(path.parent == OUT, 'writes are confined to this new artifact directory')
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
    with os.fdopen(descriptor, 'wb') as stream:
        os.fchmod(stream.fileno(), 0o644)
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    return {'path': str(path), 'sha256': sha(data), 'bytes': len(data), 'mode': '0o644'}


def write_json(name, value):
    return write_bytes(OUT / name, (json.dumps(value, indent=2) + '\n').encode())


def snapshot(path, name):
    data, identity = capture(path)
    identity['copy'] = write_bytes(OUT / name, data)
    return data, identity


def unchanged(identity):
    _, current = capture(Path(identity['path']))
    require(current == {key: value for key, value in identity.items() if key != 'copy'},
            f'original artifact was changed: {identity["path"]}')


def source_inventory():
    raw = gzip.decompress(capture(MANIFEST)[0])
    require(sha(raw) == EXPECTED, 'pinned decompressed source manifest mismatch')
    rows = json.loads(raw)
    require(len(rows) == 10622, 'unexpected exact candidate inventory size')
    names = [row['path'] for row in rows]
    require(names == sorted(set(names)), 'candidate manifest must be sorted and unique')
    current = []
    for row in rows:
        relative = Path(row['path'])
        require(not relative.is_absolute() and '..' not in relative.parts,
                'invalid candidate source path')
        path = SOURCE / relative
        if path.is_symlink():
            digest = sha(os.readlink(path).encode())
            kind = 'symlink'
        else:
            require(path.is_file(), f'missing candidate source file: {relative}')
            value = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    value.update(block)
            digest, kind = value.hexdigest(), 'file'
        current.append({'path': str(relative), 'sha256': digest, 'kind': kind})
    value = sha(json.dumps(current, sort_keys=True, separators=(',', ':')).encode())
    require(value == EXPECTED, f'source inventory changed: {value}')
    return value


def parsed_log(data):
    text = ANSI.sub('', data.decode(errors='replace'))
    ids = re.findall(r'Nextest run ID ([a-f0-9-]{36}) with nextest profile: (\S+)', text)
    starts = re.findall(r'^\s*Starting (\d+) tests across (\d+) binar(?:y|ies)\b', text, re.M)
    summaries = list(re.finditer(r'^\s*Summary \[[^\]]+\] (\d+) tests run: (\d+) passed([^\n]*)', text, re.M))
    require(len(ids) == len(starts) == len(summaries) == 1,
            'one actual nextest run/start/success summary required in raw log')
    count, binaries = map(int, starts[0])
    summary = summaries[0]
    require(count > 0 and int(summary[1]) == int(summary[2]) == count,
            'raw nextest totals are not entirely successful')
    require(not re.search(r'\b(?:failed|flaky|timed out|cancelled|leaked)\b', summary[3]),
            'raw nextest summary has a non-success outcome')
    prefix = text[:summary.start()]
    pairs = re.findall(r'^\s*PASS \[[^\]]+\]\s+(?:\(\d+/\d+\)\s+)?(\S+)\s+(\S+)\s*$', prefix, re.M)
    require(len(pairs) == len(set(pairs)) == count, 'raw PASS lines do not match exact run count')
    return {'uuid': ids[0][0], 'profile': ids[0][1], 'count': count,
            'binaries': binaries, 'cases': [list(pair) for pair in sorted(pairs)]}


def epoch(value):
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(parsed.tzinfo is not None, 'JUnit timestamp must include its timezone')
    return parsed.timestamp()


def validate_junit(data, identity, run, started, finished):
    tree = ET.fromstring(data)
    require(tree.tag == 'testsuites' and tree.attrib.get('uuid') == run['uuid'],
            'JUnit does not name the actual raw-log run UUID')
    cases = tree.findall('.//testcase')
    pairs = sorted([[case.attrib.get('classname', ''), case.attrib.get('name', '')] for case in cases])
    require(pairs == run['cases'] and len(cases) == run['count'], 'JUnit exact case set mismatch')
    require(int(tree.attrib.get('tests', '-1')) == len(cases), 'JUnit header count mismatch')
    for node in tree.iter():
        require(node.tag not in {'failure', 'error', 'skipped', 'rerunFailure', 'rerunError',
                                 'flakyFailure', 'flakyError'}, 'JUnit contains an unsuccessful case')
        for key in ('failures', 'errors', 'disabled', 'skipped'):
            require(int(node.attrib.get(key, '0')) == 0, f'JUnit declares {key}')
    # Run UUID plus original run window prevents accepting another invocation's
    # report. Ten milliseconds only covers JUnit's millisecond timestamp rounding.
    mtime = identity['mtime_ns'] / 1_000_000_000
    require(started - 0.01 <= mtime <= finished + 0.01, 'JUnit file mtime is outside this run')
    for node in [tree, *cases]:
        require('timestamp' in node.attrib, 'JUnit run/case timestamp is absent')
        require(started - 0.01 <= epoch(node.attrib['timestamp']) <= finished + 0.01,
                'JUnit timestamp is outside this run')
    return {'uuid': run['uuid'], 'profile': run['profile'], 'case_count': len(cases),
            'cases': pairs, 'failures': 0, 'errors': 0, 'skipped': 0,
            'original_file': identity, 'freshness_window': [started, finished]}


def capture_reports(paths, prefix):
    results = []
    for index, path in enumerate(paths):
        entry = {'path': str(path), 'exists': path.exists()}
        if entry['exists']:
            try:
                _, identity = snapshot(path, f'{prefix}-{index:02d}.junit.xml')
                entry['identity'] = identity
            except Exception as error:
                entry['read_error'] = repr(error)
        results.append(entry)
    return results


def find_report(captured, run, started, finished):
    valid, rejected = [], []
    for entry in captured:
        if 'identity' not in entry:
            rejected.append(entry)
            continue
        identity = entry['identity']
        data = capture(Path(identity['copy']['path']))[0]
        try:
            valid.append(validate_junit(data, identity, run, started, finished))
        except Exception as error:
            rejected.append({'path': entry['path'], 'reason': repr(error)})
    require(len({item['original_file']['sha256'] for item in valid}) <= 1,
            'different reports claim the same run; refuse ambiguous reconciliation')
    return valid, rejected


def diagnose_report_locations(log):
    """Read the exact configuration/shim and only consider literal owned paths."""
    diagnostics, candidates = {'raw_report_location_lines': []}, []
    text = ANSI.sub('', log.decode(errors='replace'))
    diagnostics['raw_report_location_lines'] = [line for line in text.splitlines()
        if re.search(r'junit|report (?:written|saved|path|location)', line, re.I)]
    config_path = SOURCE / 'codex-rs/.config/nextest.toml'
    config_raw, diagnostics['nextest_config'] = snapshot(config_path, 'nextest-config.toml')
    _, diagnostics['just_shim'] = snapshot(SHIM, 'just-shim.txt')
    config = tomllib.loads(config_raw.decode())
    diagnostics['declared_store'] = config.get('store', {})
    profiles = config.get('profile', {})
    diagnostics['declared_junit'] = {name: profiles.get(name, {}).get('junit', {})
                                    for name in ('local', 'default')}
    store = config.get('store', {}).get('dir')
    if isinstance(store, str):
        for base in (SOURCE / 'codex-rs', SOURCE):
            for profile in ('local', 'default'):
                junit = profiles.get(profile, {}).get('junit', {}).get('path')
                if junit is None:
                    junit = profiles.get('default', {}).get('junit', {}).get('path')
                if isinstance(junit, str):
                    candidates.append(base / store / profile / junit)
    for line in diagnostics['raw_report_location_lines']:
        candidates.extend(Path(value) for value in re.findall(r'(/[^\s\x1b<>"\']+\.xml)', line))
    allowed = []
    for path in candidates:
        if (path.is_absolute() and path.is_relative_to(ROOT) and '..' not in path.parts
                and path not in REPORTS and path not in allowed):
            allowed.append(path)
    diagnostics['additional_literal_owned_candidates'] = [str(path) for path in allowed]
    return diagnostics, allowed


def root_export():
    require(os.getuid() == os.geteuid() == 0, 'actual Root is required only to export original evidence')
    account = pwd.getpwnam('qq')
    require(OUT.resolve() == OUT and OUT.stat().st_uid == account.pw_uid
            and stat.S_IMODE(OUT.stat().st_mode) == 0o755, 'qq-owned0755 output directory required')
    report = {'phase': 'collecting', 'expected_source_inventory': EXPECTED,
              'root_tests_executed_by_reconciliation': False, 'production_acceptance': 'HOLD'}
    try:
        raw, receipt_identity = snapshot(ROOT_RECEIPT, 'original-root-qualification.json')
        receipt = json.loads(raw)
        log, log_identity = snapshot(ROOT_LOG, 'original-root-six.log')
        report['original_receipt'] = receipt_identity
        report['original_log'] = log_identity
        report['original_collector_phase'] = receipt.get('phase')
        report['original_collector_exit_code'] = receipt.get('exit_code')
        report['original_collector_error'] = receipt.get('error')
        require(receipt.get('attempt') == 'root-six-v2', 'different original Root attempt')
        require(receipt.get('source_before') == receipt.get('source_after') == EXPECTED,
                'original Root receipt source does not match candidate')
        require(receipt.get('root_uid') == receipt.get('root_euid') == 0,
                'original Root receipt does not attest actual Root')
        require(receipt.get('command_exit_code') == 0, 'actual Root command failed; no automatic rerun')
        require(receipt.get('phase') == 'failed' and receipt.get('exit_code') == 1
                and receipt.get('junit') == []
                and 'one fresh JUnit report containing exactly six successful parent cases is required'
                    in receipt.get('error', ''), 'original failure differs from the missing-JUnit collector defect')
        require(abs(receipt['test_started_unix_seconds'] - ROOT_STARTED) < 0.001
                and abs(receipt['finished_unix_seconds'] - ROOT_FINISHED) < 0.001,
                'original Root execution window differs from the reviewed attempt')
        require(receipt.get('log_sha256') == log_identity['sha256']
                and receipt.get('log_bytes') == log_identity['bytes'] == 21310,
                'original Root raw-log hash/length differs from its receipt')
        require(receipt.get('tests_requested') == TESTS, 'original Root selector differs')
        report['command'] = receipt['command']
        report['command_exit_code'] = 0
        report['source_before'] = report['source_after'] = EXPECTED
        report['test_started_unix_seconds'] = receipt['test_started_unix_seconds']
        report['test_finished_unix_seconds'] = receipt['finished_unix_seconds']
        run = parsed_log(log)
        require(run['cases'] == sorted([['codex-hepta-agentd', name] for name in TESTS])
                and run['binaries'] == 1, 'raw Root log does not contain exactly the six parent passes')
        require(re.search(r'ROOT_LEARNING_REGISTERED_SERVICE actual_consumer_uid=60001[^\n]*'
                          r'schema=2 scope=cell frozen_scope_binding=[0-9a-f]{64}', log.decode(errors='replace')),
                'actual dedicated-UID V2 service evidence is missing')
        report['raw_run'] = run
        report['expected_four_locations'] = capture_reports(REPORTS, 'existing-report')
        report['additional_locations'] = []
        matches, rejected = find_report(report['expected_four_locations'], run, ROOT_STARTED, ROOT_FINISHED)
        if not matches:
            diagnostics, additional = diagnose_report_locations(log)
            report['location_diagnostics'] = diagnostics
            report['additional_locations'] = capture_reports(additional, 'declared-report')
            matches, more_rejected = find_report(report['additional_locations'], run, ROOT_STARTED, ROOT_FINISHED)
            rejected.extend(more_rejected)
        report['rejected_reports'] = rejected
        require(matches, 'original Root JUnit unavailable: inspect saved raw log, nextest config and just shim; no test rerun')
        require(all(item['original_file']['sha256'] == ROOT_JUNIT_SHA256
                    and item['original_file']['bytes'] == 1858 for item in matches),
                'Root JUnit differs from the independently observed original report')
        report['independently_observed_junit'] = {
            'path': str(SOURCE / 'codex-rs/target/nextest/local/junit.xml'),
            'sha256': ROOT_JUNIT_SHA256, 'bytes': 1858, 'mtime_unix_seconds': 1794226381.8818543}
        report['junit'] = matches
        data = capture(Path(matches[0]['original_file']['copy']['path']))[0]
        report['junit_copy'] = write_bytes(OUT / 'root-six-v2.junit.xml', data)
        unchanged(receipt_identity)
        unchanged(log_identity)
        report.update(phase='passed', exit_code=0, tests_executed=True, passed_parent_cases=6,
                      nested_children_counted_separately=False, reconciled_unix_seconds=time.time(),
                      boundary='Mechanism qualification only; no training, independent evaluation, model release or product acceptance.')
    except Exception as error:
        report.update(phase='blocked', exit_code=1, error=repr(error))
    write_json('reconciled-qualification.json', report)
    if report['exit_code']:
        print(json.dumps({'phase': report['phase'], 'error': report['error']}), flush=True)
        return 1
    # These exact task-owned report paths may have been atomically replaced by
    # Root with umask077. Copy and verify first; never chmod original receipts,
    # raw logs, source files, private fixtures or unrelated Cargo cache entries.
    repairs = []
    for base in (ROOT / 'target', SOURCE / 'codex-rs/target'):
        for path in (base / 'nextest', base / 'nextest/local', base / 'nextest/default',
                     base / 'nextest/local/junit.xml', base / 'nextest/default/junit.xml'):
            if not path.exists():
                continue
            require(path.resolve() == path, f'report custody path is a symlink: {path}')
            before = path.lstat()
            require(before.st_uid in (0, account.pw_uid), 'foreign nextest report owner')
            if before.st_uid == 0:
                mode = 0o755 if stat.S_ISDIR(before.st_mode) else 0o644
                require(stat.S_ISDIR(before.st_mode) or stat.S_ISREG(before.st_mode), 'unexpected report object')
                os.chown(path, account.pw_uid, account.pw_gid)
                os.chmod(path, mode)
                repairs.append({'path': str(path), 'previous_uid': 0,
                                'previous_mode': oct(stat.S_IMODE(before.st_mode)),
                                'uid': account.pw_uid, 'gid': account.pw_gid, 'mode': oct(mode)})
    write_json('report-permission-repairs.json', repairs)
    print(json.dumps({'phase': 'root-evidence-recovered', 'passed_parent_cases': 6,
                      'root_tests_rerun': False}), flush=True)
    return 0


def no_maintenance():
    for name in ('maintenance-v2.json', 'scoped-fix-v2.log', 'fmt-v2.log'):
        require(not (EVIDENCE / name).exists(), f'behavior tests forbidden after maintenance marker: {name}')
    for path in EVIDENCE.glob('*.json'):
        record = json.loads(capture(path)[0])
        command = record.get('command', []) if isinstance(record, dict) else []
        require(not any(value in ('fix', 'fmt') for value in command),
                f'behavior tests forbidden after recorded fix/fmt: {path}')


def ordinary_environment(receipt, status):
    env = receipt['environment']
    require(env['CARGO_TARGET_DIR'] == str(ROOT / 'target') and env['CODEX_REPO_ROOT'] == str(SOURCE),
            'ordinary environment source/target mismatch')
    require(Path(env['PATH'].split(':')[0]) / 'just' == SHIM, 'ordinary just shim changed')
    helper = Path(env['CARGO_BIN_EXE_hepta-joint-propose'])
    require(env['CARGO_BIN_EXE_hepta_joint_propose'] == str(helper)
            and file_sha(helper) == status['helper_sha256'], 'original helper digest mismatch')
    # Keep the same task's selected environment; do not carry an accidental
    # profile/filter/Root-qualification variable from the corrective launcher.
    selected = {key: os.environ[key] for key in ('HOME', 'USER', 'LOGNAME', 'LANG', 'LC_ALL')
                if key in os.environ}
    selected.update(env)
    return selected


def driver():
    account = pwd.getpwnam('qq')
    require(os.getuid() == os.geteuid() == account.pw_uid, 'run corrective driver as qq, not Root')
    require(OUT.parent.resolve() == OUT.parent, 'noncanonical evidence directory')
    OUT.mkdir(mode=0o755, exist_ok=False)  # Refuse replay even after an interrupted ordinary attempt.
    os.chmod(OUT, 0o755)
    outcome = {'phase': 'preflight', 'started': time.time(), 'source_before': EXPECTED,
               'source_edited': False, 'root_tests_rerun': False, 'ordinary_rerun_count': 0,
               'behavior_tests_after_maintenance': False, 'production_acceptance': 'HOLD',
               'original_artifacts': []}
    code = 1
    try:
        no_maintenance()
        outcome['source_before'] = source_inventory()
        originals = [(ORDINARY_RECEIPT, 'original-ordinary.json'), (ORDINARY_LOG, 'original-ordinary.log'),
                     (STATUS, 'original-status-v2.json'), (INPUTS, 'original-inputs-v2.json.gz'),
                     (AUDIT, 'original-audit-v2.json'), (MANIFEST, 'qualified-source.files.json.gz')]
        for path, name in originals:
            _, identity = snapshot(path, name)
            outcome['original_artifacts'].append(identity)
        ordinary = json.loads((OUT / 'original-ordinary.json').read_text())
        status = json.loads((OUT / 'original-status-v2.json').read_text())
        audit = json.loads((OUT / 'original-audit-v2.json').read_text())
        require(ordinary.get('exit_code') == 0 and ordinary.get('command') == COMMAND
                and ordinary.get('cwd') == str(SOURCE)
                and ordinary.get('source_before') == ordinary.get('source_after') == EXPECTED,
                'original ordinary command did not pass on this exact source')
        require(status.get('phase') == 'tests-finished' and status.get('exit_code') == 0
                and status.get('source_before') == status.get('source_after') == EXPECTED,
                'ordinary status is not the unchanged pre-maintenance candidate')
        require(status['payload_sha256'] == sha(gzip.decompress((OUT / 'original-inputs-v2.json.gz').read_bytes())),
                'original v2 input payload mismatch')
        raw = (OUT / 'original-ordinary.log').read_bytes()
        require(sha(raw) == ordinary['log_sha256'] and len(raw) == ordinary['log_bytes'],
                'original ordinary log differs from its receipt')
        original_run = parsed_log(raw)
        require({pair[0] for pair in original_run['cases']} == PACKAGES and original_run['binaries'] == 2,
                'ordinary raw log is not exactly the two selected package libraries')
        require(audit.get('status') == 'passed' and all(row['exit_code'] == 0 for row in audit['commands']),
                'current independent audit-v2 did not pass')
        outcome['separate_audit'] = {'path': str(AUDIT), 'sha256': sha((OUT / 'original-audit-v2.json').read_bytes()),
                                   'status': 'passed', 'commands': audit['commands']}
        for row in audit['commands']:
            require(re.fullmatch(r'[a-z0-9-]+', row['name']), 'unexpected audit artifact name')
            for suffix in ('stdout', 'stderr'):
                path = EVIDENCE / (row['name'] + '.' + suffix)
                data, identity = snapshot(path, 'original-' + path.name)
                require(sha(data) == row[suffix + '_sha256'], 'audit raw output hash mismatch')
                outcome['original_artifacts'].append(identity)
        env = ordinary_environment(ordinary, status)
        command = ['/usr/bin/sudo', '-n', '/usr/bin/python3', '-B', str(ROOT / 'reconcile-v2.py'), '--export-root']
        with (OUT / 'root-export.log').open('xb') as stream:
            os.fchmod(stream.fileno(), 0o644)
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=False, timeout=60)
        require(result.returncode == 0, 'Root evidence export blocked; read root-export.log and reconciled-qualification.json')
        root = json.loads((OUT / 'reconciled-qualification.json').read_text())
        require(root.get('phase') == 'passed', 'reconciled Root evidence is not complete')
        outcome['root_qualification'] = {'path': str(OUT / 'reconciled-qualification.json'),
                                         'sha256': sha((OUT / 'reconciled-qualification.json').read_bytes())}
        captured = root['expected_four_locations'] + root['additional_locations']
        original_finish = ordinary['started'] + ordinary['elapsed_seconds']
        matches, rejected = find_report(captured, original_run, ordinary['started'], original_finish)
        record = {'command': COMMAND, 'cwd': str(SOURCE), 'environment': ordinary['environment'],
                  'source_before': EXPECTED, 'original_receipt': str(ORDINARY_RECEIPT),
                  'original_receipt_sha256': sha((OUT / 'original-ordinary.json').read_bytes()),
                  'original_run': original_run, 'original_report_rejections': rejected}
        if matches:
            record.update(mode='original-report-recovered', started=ordinary['started'],
                          elapsed_seconds=ordinary['elapsed_seconds'], exit_code=0,
                          log_sha256=ordinary['log_sha256'], log_path=str(OUT / 'original-ordinary.log'),
                          junit=matches, actual_run=original_run)
            junit = capture(Path(matches[0]['original_file']['copy']['path']))[0]
        else:
            no_maintenance()
            require(source_inventory() == EXPECTED, 'source changed before the single ordinary rerun')
            locations = list(dict.fromkeys([*REPORTS, *[Path(row['path']) for row in root['additional_locations']]]))
            before = {str(path): capture(path)[1] if path.exists() else None for path in locations}
            started = time.time()
            write_json('ordinary-rerun-started.json', {'started': started, 'command': COMMAND,
                'cwd': str(SOURCE), 'uid': os.getuid(), 'source_before': EXPECTED,
                'report_identities_before': before, 'automatic_retry_allowed': False})
            outcome['ordinary_rerun_count'] = 1
            log = OUT / 'ordinary-rerun.log'
            with log.open('xb') as stream:
                os.fchmod(stream.fileno(), 0o644)
                result = subprocess.run(COMMAND, cwd=SOURCE, env=env, stdout=stream,
                                        stderr=subprocess.STDOUT, check=False)
            finished = time.time()
            data, log_identity = capture(log)
            record.update(mode='one-ordinary-rerun-after-overwritten-report', started=started,
                          finished=finished, elapsed_seconds=finished - started, exit_code=result.returncode,
                          actual_uid=os.getuid(), log_path=str(log), log_sha256=log_identity['sha256'],
                          log_bytes=len(data))
            # This receipt survives parser/collector failure; do not hide an executed command.
            write_json('ordinary-rerun-command.json', record)
            record['source_after'] = source_inventory()
            require(result.returncode == 0, 'single ordinary rerun failed; preserve its raw log, no automatic retry')
            run = parsed_log(data)
            require(run['cases'] == original_run['cases'] and run['binaries'] == 2,
                    'ordinary rerun selected a different exact case inventory')
            reports = capture_reports(locations, 'ordinary-report')
            matches, rejected = find_report(reports, run, started, finished)
            record['report_candidates'] = reports
            record['report_rejections'] = rejected
            require(matches, 'ordinary command passed but no actual fresh matching JUnit was collected')
            require(all(item['original_file']['sha256'] != (before[item['original_file']['path']] or {}).get('sha256')
                        for item in matches), 'ordinary JUnit did not change from its pre-run identity')
            record['junit'], record['actual_run'] = matches, run
            junit = capture(Path(matches[0]['original_file']['copy']['path']))[0]
        record['junit_copy'] = write_bytes(OUT / 'ordinary-v2.junit.xml', junit)
        record.update(phase='passed', source_after=source_inventory(),
                      passed_cases=record['actual_run']['count'], tests_executed=True,
                      root_tests_executed=False, finished_collection=time.time())
        outcome['ordinary_qualification'] = write_json('reconciled-ordinary.json', record)
        for identity in outcome['original_artifacts']:
            unchanged(identity)
        # A second bounded privileged read checks original Root receipt/log custody;
        # it starts no tests and makes no edits, even after the ordinary run.
        verify = ['/usr/bin/sudo', '-n', '/usr/bin/python3', '-B', str(ROOT / 'reconcile-v2.py'), '--verify-original-root']
        result = subprocess.run(verify, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False, timeout=30)
        write_bytes(OUT / 'original-root-preservation.stdout', result.stdout)
        write_bytes(OUT / 'original-root-preservation.stderr', result.stderr)
        require(result.returncode == 0, 'original Root failure evidence changed')
        outcome.update(phase='passed', exit_code=0, source_after=source_inventory(),
                       original_receipts_and_status_preserved=True)
        code = 0
    except Exception as error:
        outcome.update(phase='blocked', exit_code=1, error=repr(error))
    finally:
        outcome['finished'] = time.time()
        write_json('reconciliation.json', outcome)
        artifacts = []
        for path in sorted(OUT.iterdir()):
            if path.is_file():
                _, identity = capture(path)
                require(identity['mode'] == '0o644', f'unreadable published artifact mode: {path.name}')
                artifacts.append(identity)
        write_json('artifact-index.json', {'directory': str(OUT), 'directory_mode': '0o755',
                                          'artifacts': artifacts, 'originals_rewritten': False})
        print(json.dumps({'phase': outcome['phase'], 'exit_code': code, 'artifacts': str(OUT),
                          'root_tests_rerun': False, 'ordinary_rerun_count': outcome['ordinary_rerun_count'],
                          'error': outcome.get('error')}), flush=True)
    return code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--print-plan', action='store_true')
    group.add_argument('--export-root', action='store_true')
    group.add_argument('--verify-original-root', action='store_true')
    args = parser.parse_args()
    if args.print_plan:
        print(json.dumps({'run_as': 'qq', 'source_inventory': EXPECTED, 'artifacts': str(OUT),
            'root_execution': 'none; sudo only reads/exports existing Root evidence and repairs exact task report custody',
            'four_report_locations': [str(path) for path in REPORTS],
            'ordinary_command_if_original_junit_was_overwritten': COMMAND, 'cwd': str(SOURCE),
            'ordinary_maximum_runs': 1, 'before_fix_fmt_only': True,
            'artifact_modes': {'directories': '0755', 'files': '0644'},
            'original_receipts_status_logs': 'preserved; referenced by original hash and file identity'}, indent=2))
        return 0
    if args.export_root:
        return root_export()
    if args.verify_original_root:
        require(os.getuid() == os.geteuid() == 0, 'actual Root readback required')
        report = json.loads(capture(OUT / 'reconciled-qualification.json')[0])
        unchanged(report['original_receipt'])
        unchanged(report['original_log'])
        print(json.dumps({'original_root_receipt_preserved': True, 'original_root_log_preserved': True}))
        return 0
    return driver()


if __name__ == '__main__':
    raise SystemExit(main())
