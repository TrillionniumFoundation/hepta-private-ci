import base64,gzip,hashlib,json,os,subprocess,sys,tarfile,time
from pathlib import Path
root=Path('/home/qq/hepta-root-product-0744-20261109'); source=root/'source'; evidence=root/'evidence'
def sha(path):
 if path.is_symlink():return hashlib.sha256(os.readlink(path).encode()).hexdigest()
 h=hashlib.sha256()
 with path.open('rb') as f:
  for part in iter(lambda:f.read(1048576),b''):h.update(part)
 return h.hexdigest()
inputs_raw=gzip.decompress((evidence/'inputs-v2.json.gz').read_bytes()); inputs=json.loads(inputs_raw)
baseline_raw=gzip.decompress(Path(inputs['baseline_manifest']['path']).read_bytes())
assert hashlib.sha256(baseline_raw).hexdigest()==inputs['baseline_manifest']['sha256']
base=[r for r in json.loads(baseline_raw) if r['path'].startswith('codex-rs/') and r['kind'] in ('file','symlink')]
assert len(base)==10608
names=sorted({r['path'] for r in base}|{r['path'] for r in inputs['files']})
def inventory():
 rows=[{'path':p,'sha256':sha(source/p),'kind':'symlink' if (source/p).is_symlink() else 'file'} for p in names]
 raw=json.dumps(rows,sort_keys=True,separators=(',',':')).encode(); h=hashlib.sha256(raw).hexdigest()
 (evidence/(h+'.files.json.gz')).write_bytes(gzip.compress(raw,mtime=0));return h,rows
ordinary=json.loads((evidence/'reconcile-v2/reconciled-ordinary.json').read_text())
reconciliation=json.loads((evidence/'reconcile-v2/reconciliation.json').read_text())
assert reconciliation['phase']=='passed' and reconciliation['original_receipts_and_status_preserved']
status=json.loads((evidence/'status-v2.json').read_text())
root_receipt=json.loads((evidence/'reconcile-v2/reconciled-qualification.json').read_text())
audit=json.loads((evidence/'audit-v2.json').read_text())
assert ordinary['exit_code']==0 and ordinary['phase']=='passed'
assert root_receipt['phase']=='passed' and root_receipt['passed_parent_cases']==6
assert audit['status']=='passed' and all(c['exit_code']==0 for c in audit['commands'])
before,before_rows=inventory();assert before==ordinary['source_before']==ordinary['source_after']==root_receipt['source_before']==root_receipt['source_after']
env=os.environ.copy();env.update(ordinary['environment'])
report={'phase':'maintenance','started':time.time(),'source_before':before,'commands':[],'behavior_tests_after_maintenance':False,'ordinary_passed_cases':ordinary['passed_cases'],'ordinary_packages':{k:sum(c[0]==k for c in ordinary['actual_run']['cases']) for k in sorted({c[0] for c in ordinary['actual_run']['cases']})},'root_passed_parent_cases':6,'runtime_cgroup':Path('/proc/self/cgroup').read_text()}
def save(): (evidence/'maintenance-v2.json').write_text(json.dumps(report,indent=2))
def run(name,cmd,cwd):
 log=evidence/(name+'.log');started=time.time()
 with log.open('wb') as f:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'cwd':str(cwd),'environment':ordinary['environment'],'started':started,'elapsed_seconds':time.time()-started,'exit_code':p.returncode,'log_sha256':sha(log),'log_bytes':log.stat().st_size}
 (evidence/(name+'.json')).write_text(json.dumps(row,indent=2));report['commands'].append(row);save();return p.returncode
save()
code=run('scoped-fix-v2',['just','fix','--locked','--offline','-p','codex-hepta-agentd','-p','codex-hepta-learning-artifacts'],source/'codex-rs')
if code:report['phase']='fix-failed';save();sys.exit(code)
code=run('fmt-v2',['just','fmt'],source/'codex-rs')
if code:report['phase']='fmt-failed';save();sys.exit(code)
after,after_rows=inventory();report['source_after']=after
old={r['path']:r for r in before_rows};delta=[]
for row in after_rows:
 if row!=old[row['path']]:delta.append({**row,'before_sha256':old[row['path']]['sha256'],'text':(source/row['path']).read_text()})
data=json.dumps(delta,ensure_ascii=False,separators=(',',':')).encode();compressed=gzip.compress(data,mtime=0)
(evidence/'maintenance-source-delta-v2.json.gz').write_bytes(compressed)
encoded=base64.b64encode(compressed).decode()
parts=[]
for i in range(0,len(encoded),32000):
 p=evidence/f'maintenance-source-delta-v2.part-{i//32000:03d}.txt';p.write_text(encoded[i:i+32000]);parts.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
report['delta']={'files':len(delta),'paths':[r['path'] for r in delta],'uncompressed_sha256':hashlib.sha256(data).hexdigest(),'compressed_sha256':sha(evidence/'maintenance-source-delta-v2.json.gz'),'parts':parts};save()
proof_name='post-maintenance-caller-proof-v2';proof_cmd=['python3','scripts/verify_hepta_callers.py','verify'];proof_started=time.time();proof_log=evidence/(proof_name+'.log')
proof_stream=proof_log.open('wb');proof_process=subprocess.Popen(proof_cmd,cwd=source,env=env,stdout=proof_stream,stderr=subprocess.STDOUT)
code=run('post-maintenance-bins-check-v2',['cargo','check','--locked','--offline','-p','codex-hepta-agentd','-p','codex-hepta-learning-artifacts','--bins'],source/'codex-rs')
proof_code=proof_process.wait();proof_stream.close()
proof_row={'name':proof_name,'command':proof_cmd,'cwd':str(source),'started':proof_started,'elapsed_seconds':time.time()-proof_started,'exit_code':proof_code,'log_sha256':sha(proof_log),'log_bytes':proof_log.stat().st_size}
(evidence/(proof_name+'.json')).write_text(json.dumps(proof_row,indent=2));report['commands'].append(proof_row);save()
if code or proof_code:report['phase']='post-maintenance-check-failed';save();sys.exit(code or proof_code)
final,_=inventory();assert final==after
report['phase']='passed';report['finished']=time.time();save()
selected=[]
for p in sorted(evidence.rglob('*')):
 if not p.is_file() or p.name.endswith('.files.json.gz') or p.name.startswith('maintenance-source-delta-v2.part-'):continue
 if p.suffix in ('.log','.json','.xml','.stdout','.stderr') or p.name.startswith('inputs-') or p.name=='maintenance-source-delta-v2.json.gz':selected.append(p)
archive=root/'native-qualification-v2.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for p in selected:tar.add(p,arcname='native/'+str(p.relative_to(evidence)),recursive=False)
info={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'files':len(selected),'source_before':before,'source_after':after}
(root/'native-qualification-v2.json').write_text(json.dumps(info,indent=2));print(json.dumps(info),flush=True)
