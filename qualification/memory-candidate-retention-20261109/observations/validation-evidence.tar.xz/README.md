# Candidate validation provenance archive

This package preserves existing task-owned validation/build bytes. It does not
run tests, actors, native workers, formatters, or experiments and makes no new
scientific or runtime-qualification claim.

Included: final evaluator-v3 seven-test stdout/stderr/receipt; initial runner
seven-test log/receipt and tested sources; the one-test quarantine preflight
correction log/receipt and sources; original formatting/AST receipts and saved
candidate preformat source snapshots; current candidate sources; both original
and corrected launch payloads, manifests, build-validation observations and
helper source; runtime-readiness and CI-invocation-correction observations.
All original members remain byte-for-byte unchanged. Nested launch source
archives contain only Python source and one repository-owned golden JSON file.

Known preservation limits:
- The early candidate_runtime five-test Torch/OCR/host-callback output and the
  early candidate_memory/action_effects nine-test output were present only in
  conversation tool output. No separate original log was saved; none is
  reconstructed here. Their saved source/format evidence is included without
  manufacturing a missing test log.
- Original and correction launcher gate checks were run as inline local tool
  scripts. No separate original gate-test script was saved. Their existing
  BUILD_VALIDATION observations and the actual helpers/payloads are preserved;
  this package does not invent command transcripts or rerun those checks.
- The shared initial format receipt includes three MEM2 file entries. It is
  preserved intact, while this package's format-source snapshots are limited
  to the ten candidate-related Python files.
- formatting/current-source is a packaging-time snapshot, not another tested
  source version or a new AST-validation claim. Initial and corrected source
  identity chains remain distinguished by their original receipts/payloads.
- The archived CI observation records 17 candidate contracts passing at the
  old head followed by a replay import failure. It explicitly leaves the new
  workflow correction's outcome pending; no future CI success is claimed.

No model weights, images, external references/annotations, credentials, runtime
packages or real episode output trees are included. Paths/digests referring to
external models/data inside existing request receipts are retained as metadata
and were not followed. Actual campaign evidence is a separate publication.

The adjacent validation-manifest.json indexes every member, original location,
byte length and SHA-256, and binds this archive. Archive verification consists
only of rereading every archived member and comparing it with its source bytes.
