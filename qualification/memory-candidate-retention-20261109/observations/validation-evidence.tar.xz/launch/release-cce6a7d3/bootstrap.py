"""Create one fixed campaign root from a verified payload, then execute once."""

import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import tarfile
import time
import traceback

SPEC = json.loads('{"archive":{"bytes":192832,"path":"/home/qq/mem-candidate-20261109-a6b21bc7-source.tar.gz","sha256":"05522d1f79ffb5e4c2857b4d01e89fe4d237a9350d205f17c6079831246699ef"},"frozen_checkpoint_count":1,"independent_training_repeats":0,"remote_root":"/home/qq/mem-candidate-retention-20261109-a6b21bc7","request":{"catalog":{"bytes":1410133,"path":"pilot-catalog.json","sha256":"8433d0c026b0818f8e60ee2f0ae7e7b57c57ae35cbb72cf212b89895b97d0904"},"config":{"episode_wall_seconds":60,"evaluator_sha256":"7988cb2eaaf8e3aad6f943fd762a1fd8847b5d44dbdc6eb5330ca2e45fc6ff45","latency_weight":0.01,"material_root":"/home/qq/ndu-real-materials-20261107-audit-bffe40c2","ocr_library_dir":"/home/qq/ndu-real-runtime-20261107-bc2efaf10cd0/portable-ocr-v1/root/usr/lib/x86_64-linux-gnu","pillow_path":"/home/qq/ndu-real-runtime-20261107-bc2efaf10cd0/python-deps","python":"/home/qq/hepta-smollm2-weight-research-20261103/ci-env/bin/python","reference_index_sha256":"d8086b7cd34b1d8c30463d8fc4cc8ada59d9973e2d8b5248090d4ab1be2b3cb2","repository_root":"/home/qq/mem-candidate-retention-20261109-a6b21bc7/source","rubric_sha256":"fee667c32ec08286bbaf4e9f70b6489aff55bc7d790dca37fc657e5350084300","runtime_roots":["/usr","/lib","/lib64","/etc/ld.so.cache","/proc/cpuinfo","/dev/urandom","/dev/null","/home/qq/hepta-smollm2-weight-research-20261103/ci-env","/home/qq/hepta-smollm2-weight-research-20261103/python/cpython-3.12.16-linux-x86_64-gnu","/home/qq/ndu-real-runtime-20261107-bc2efaf10cd0/python-deps","/home/qq/mem-candidate-retention-20261109-a6b21bc7/source","/home/qq/ndu-real-runtime-20261107-bc2efaf10cd0/portable-ocr-v1/root"],"scripts_root":"/home/qq/mem-candidate-retention-20261109-a6b21bc7/source/scripts","source_exposure_ledger_path":"/home/qq/ndu-real-materials-20261107-audit-bffe40c2/public-source-exposure-20261107-v3.json","source_exposure_ledger_sha256":"6722edfc88e1089bcaf0fba9727c233416830fdc6682b461422d26bdfd4cb6af","tessdata_dir":"/home/qq/ndu-real-runtime-20261107-bc2efaf10cd0/portable-ocr-v1/root/usr/share/tesseract-ocr/5/tessdata","tesseract":"/home/qq/ndu-real-runtime-20261107-bc2efaf10cd0/portable-ocr-v1/root/usr/bin/tesseract"},"excluded_source_groups":["merchant-5d4b99c3062c5faa80efd221","merchant-bd1804bb290a96349b65a9ab","merchant-50f46908878b39ed0bd3853f"],"exclusion_manifest":{"bytes":18908,"path":"/home/qq/cell-causal-abcde-20261108-cf0/collection/selected-sources.json","sha256":"0a8054ceb0a5874caa89d6b871083752e61688be5da0f47fc513bed2dd965f2b"},"experiment_id":"mem-candidate-retention-20261109-a6b21bc7","exposure_ledgers":[{"bytes":3231,"path":"/home/qq/ndu-real-materials-20261107-audit-bffe40c2/public-source-exposure-20261107-v3.json","sha256":"6722edfc88e1089bcaf0fba9727c233416830fdc6682b461422d26bdfd4cb6af"}],"groups_per_role":{"development":10,"retention_validation":4},"max_workers":2,"model":{"control_profile_sha256":"5f21ccc84d70f69b1ee3894a156a8e0181fdc0c358c3b1520d038dfc47a62df7","core":"hepta","deployment_profile":{"bytes":498,"path":"/home/qq/cell-causal-abcde-20261108-cf0/evaluation-b-v1/cloud-return/results/b/models/independent/s104729/hepta/reset/content/deployment-profile.json","sha256":"d14a0c398c8ff617105dd53472468e5e06cd78381d797776bef1121694a2c6bc"},"parameters_sha256":"a8907476aae7fb8bf50f033da73953d2e80f54a43ada3fd2a6e312c3e4dfe772","receipt":{"bytes":38343,"path":"/home/qq/cell-causal-abcde-20261108-cf0/evaluation-b-v1/cloud-return/results/b/models/independent/s104729/hepta/reset/content/receipt.json","sha256":"7bbaa55447701830291e5d0652009fcf6b8f315c46a9c13de40e112eeed76f84"},"weights":{"bytes":72247,"path":"/home/qq/cell-causal-abcde-20261108-cf0/evaluation-b-v1/cloud-return/results/b/models/independent/s104729/hepta/reset/content/weights.pt","sha256":"313743619c25f7449c30982d5f2dcc96e574a9bc41730eb5c9551fb568fb57ac"}},"registry_sha256":"09d5f57c5c4c5f421f16c51febd048b7746d5d52723d825240f8655bf7fbdd07","schema":"ndu.real.candidate-retention-request.v1","selection_salt":"mem-candidate-retention-20261109-a6b21bc7-v1","source_commit":"cce6a7d3222a7eaffe2ec3890e624820a2ec8023","source_pins":[{"bytes":14705,"path":"experiments/multimodal_output_portfolio/joint_hepta_20261029/hepta_core.py","sha256":"54c2e9724f6cb924582451bea907d671fe510963879117dd5f00cf4e95f1e978"},{"bytes":74,"path":"scripts/ndu_real_materials/__init__.py","sha256":"1f0a2d2286ae48aa399b8759c8326e878b4de73bbec0fcc9c2617b58463187a9"},{"bytes":4685,"path":"scripts/ndu_real_materials/acquire.py","sha256":"0dac9af6017cef053b117d5c9f72c264fd01412c4bff1816694c502eb35c7d6d"},{"bytes":3205,"path":"scripts/ndu_real_materials/common.py","sha256":"85a70ee45bfdea796f5ddf632aa7c6a93e60ccf3ca75e8925fd76e8b07cf2ce0"},{"bytes":30312,"path":"scripts/ndu_real_materials/coverage.py","sha256":"f164e862dc5c9c48bcc5eab732e8e0dbbd0f375610b1c64ed201434394259796"},{"bytes":9284,"path":"scripts/ndu_real_materials/evaluator.py","sha256":"7988cb2eaaf8e3aad6f943fd762a1fd8847b5d44dbdc6eb5330ca2e45fc6ff45"},{"bytes":5043,"path":"scripts/ndu_real_materials/groups.py","sha256":"60ed62f2df57cfbfc7441f5504ad39cfcebe4bb3114e2cedd55ca80dc213b3fa"},{"bytes":17264,"path":"scripts/ndu_real_materials/isolate.py","sha256":"03e23e125465984d794b011eab2ecf82a84a8b0f6b91ec6ef670fcd421652354"},{"bytes":11446,"path":"scripts/ndu_real_materials/isolation_probe.py","sha256":"f2c7cc52ccffb8bba27082c0ffbb9b80d1b4d3488ce835b8c4c2c0c903b1acac"},{"bytes":20627,"path":"scripts/ndu_real_materials/register.py","sha256":"85383349aec4388756f9a96755611c94e78cf756fa2ae3ea5a061ca78c9228e0"},{"bytes":77,"path":"scripts/ndu_real_runtime/__init__.py","sha256":"cb8063131308ce06b535be86ae276281fa6c0cc0f21a1752f29d0c59018ef8a4"},{"bytes":1644,"path":"scripts/ndu_real_runtime/_causal_checks.py","sha256":"c17c073a94cf29ba442926b2def9e52008b226c13658480f9110e29bc9aa410d"},{"bytes":2817,"path":"scripts/ndu_real_runtime/action_effects.py","sha256":"d19ac57ce7f95589facefd8c021c864aa418134a8a1f6c19a85456524d43262e"},{"bytes":24716,"path":"scripts/ndu_real_runtime/actor.py","sha256":"f91dc57bc808f1986db8cc86673feb10dad0a538b5c05ab96c631b60a1468444"},{"bytes":9439,"path":"scripts/ndu_real_runtime/candidate_memory.py","sha256":"32bf7ca6157ac611b1b0616e291ec6c9c8d1424392f41bdf994e69547535d27e"},{"bytes":31538,"path":"scripts/ndu_real_runtime/candidate_retention_report.py","sha256":"fc05736495909ffde054e3a320aae4f5b7b8219050ba4d2de1121fd210f26e57"},{"bytes":8263,"path":"scripts/ndu_real_runtime/candidate_runtime.py","sha256":"863b4467b7fdae21a170ab13ce3bade9e4319570a5dada811f793af3fbc871f4"},{"bytes":8400,"path":"scripts/ndu_real_runtime/causal_ace.py","sha256":"09150a7722e76d116a5761927f9687ba53e7ec1fe7718bb364fd5a39dbad2c65"},{"bytes":10067,"path":"scripts/ndu_real_runtime/causal_analysis.py","sha256":"e2e3d075530f8262ceec1f4faf7005c40bdd860bc3f1093cf66ae513a9a39297"},{"bytes":14618,"path":"scripts/ndu_real_runtime/causal_b.py","sha256":"6f270394edd7f474810fbbefcf3638cca43d03ddc2476ec81a17879e26dd8f6a"},{"bytes":8128,"path":"scripts/ndu_real_runtime/causal_b_contract.py","sha256":"953e946c9d0c020c5aa1ceb9e1d41e7030f91729260f01e81895b76cdc6d290c"},{"bytes":15465,"path":"scripts/ndu_real_runtime/causal_composition.py","sha256":"7735155426f12ff31fe31b453a7a29da9ca8e18b1e8593884dd0a0379895d90a"},{"bytes":23492,"path":"scripts/ndu_real_runtime/causal_improver.py","sha256":"d07e75fcfec61393427e138ed39ecfd0ec284ec6600364b889abd404d6b29ea0"},{"bytes":10162,"path":"scripts/ndu_real_runtime/causal_protocol.py","sha256":"a450ca58bdb923cc7dd11ecf5ef08fbca55a975ad41e9475df8b0ce8327df8a2"},{"bytes":16843,"path":"scripts/ndu_real_runtime/causal_topology.py","sha256":"65e41055e2d1d5e0681b4c2477c3771af1c7a9737ca081f4b6cf139c4be1a068"},{"bytes":15234,"path":"scripts/ndu_real_runtime/controllers.py","sha256":"0cd9c8da5122d6b7940e322382e9118607d54b14246ee3449feb05904728824b"},{"bytes":32634,"path":"scripts/ndu_real_runtime/episode.py","sha256":"2845bbbb9ff4e25d1b7fcf1d766d0d17268af06085fc62b3c4384e7097412243"},{"bytes":18985,"path":"scripts/ndu_real_runtime/evolve1.py","sha256":"29b00f3f913787f12a7915f5a4d7728ccb2a149c7d17b4a39c25cd02daeed0f6"},{"bytes":20332,"path":"scripts/ndu_real_runtime/evolve1_pilot.py","sha256":"a66a436e82f702e3e0318e968056797077a0038817e1f18bd0ae787685f1087f"},{"bytes":4549,"path":"scripts/ndu_real_runtime/evolve1_reference.py","sha256":"dcbb79d0b40d87bb3f977a15dd00019b987487a6b558e337fe230b509aec2cee"},{"bytes":15099,"path":"scripts/ndu_real_runtime/factorial_report.py","sha256":"ceb0628852adbac6882cd04d70ad27ee496a208c4dd4ba3e0d5f6defd08cd542"},{"bytes":2076,"path":"scripts/ndu_real_runtime/finite_entropic_golden.json","sha256":"361f37baddd9bbcccbfa16f9b438e14707b22ae7c997863a13b19fe01def02cc"},{"bytes":12969,"path":"scripts/ndu_real_runtime/fit_loop.py","sha256":"ffed1b606594e637812a01d004c394518d88e497b7ba9720c13466027f1bf8e5"},{"bytes":17363,"path":"scripts/ndu_real_runtime/gradient_check.py","sha256":"0311796a3f37654fe53e8c1d8d6141b95381787d0f84b0699477889d60a6732e"},{"bytes":12219,"path":"scripts/ndu_real_runtime/interval_costs.py","sha256":"47e5aeba99a3d7763d607f2a796937ceda4e429ab72b0e41909ce78a8ee3828c"},{"bytes":25671,"path":"scripts/ndu_real_runtime/matrix.py","sha256":"c3f1792e73a0c92f953568a924f686e1865f97f728210982eee51b5dbfbe4d10"},{"bytes":15246,"path":"scripts/ndu_real_runtime/meter_diagnostic.py","sha256":"0d2c0a6a1e1df89b28351f22a759470078a30bc9df559f6c4b26859671a57670"},{"bytes":8563,"path":"scripts/ndu_real_runtime/metering.py","sha256":"268966957ddf16d9824e08041c63f09cb14f6f3e6e14a11aceaf104857089226"},{"bytes":3133,"path":"scripts/ndu_real_runtime/native_worker.py","sha256":"566e4cd00294998923a08675f90640bfae1ea63c5d540390bdd22e712dbada76"},{"bytes":11181,"path":"scripts/ndu_real_runtime/neural.py","sha256":"2c079d201e7be37bec2c97720d9fec83da93c9ff93813c3aaf60bc154a3df987"},{"bytes":3377,"path":"scripts/ndu_real_runtime/objective.py","sha256":"cb3194011908ac46c20bedb8833e18a606709debbb051291360648ec2b869edd"},{"bytes":10940,"path":"scripts/ndu_real_runtime/ocr.py","sha256":"5cbcaca04a4843b51379bbcc3911ae4453c25b3f0585970ae4d9d414624a47f1"},{"bytes":3249,"path":"scripts/ndu_real_runtime/organization_artifacts.py","sha256":"b47db312199308c884691097468ca92f02e66f234144e07220981a8d0aec3981"},{"bytes":19700,"path":"scripts/ndu_real_runtime/organization_policy.py","sha256":"ef1b631fe4c01c4acd5b7c2116540fb32c04c4eeb1e79ba754fe20c6040c408d"},{"bytes":17322,"path":"scripts/ndu_real_runtime/organization_reference.py","sha256":"e27bdecab60a8792490f2522071be6000f3cbebda315c54c33ba78807c3e3bf6"},{"bytes":13376,"path":"scripts/ndu_real_runtime/organization_reference_artifacts.py","sha256":"e643f62f8f2a2e3b6529ea4d63aef4f1eba3ee8550e1d3d34f29377809dc0921"},{"bytes":1415,"path":"scripts/ndu_real_runtime/organization_review.py","sha256":"188786ebecdc5b4bd174cd73fff0711df9a8737f87b4fa8c7957ccef18359a51"},{"bytes":15066,"path":"scripts/ndu_real_runtime/pipeline.py","sha256":"55e64da2995bd685bf5b24b7ce74e6ce821dacb0d65cf94e68e8ab53a9eb9d6c"},{"bytes":7204,"path":"scripts/ndu_real_runtime/recursive_objective.py","sha256":"c811ddff6f4bb31aeae28a47b23265fb7b0255a8a1cc7250a5ff591e96f946f9"},{"bytes":29818,"path":"scripts/ndu_real_runtime/run_candidate_retention.py","sha256":"88ecc33260e9f43a5e9e95575da5bdfe286336329d7753f262c11567b2b0f0f0"},{"bytes":1106,"path":"scripts/ndu_real_runtime/score_worker.py","sha256":"e40818170025960efd7a45fbc3dd8beba45cdaa872de0bd37038dcaeb626f887"},{"bytes":22961,"path":"scripts/ndu_real_runtime/span_meter.py","sha256":"3ef63104c27aeb2ee64478ad7461f579dd5f06be05aa4f4c9bcc709e8826a70b"},{"bytes":11574,"path":"scripts/ndu_real_runtime/state_codec.py","sha256":"fd50ea3a5cba1498e2cafd61d7fbfca73c8c9ad5a1dfdd9c74ac8155becc8fc7"},{"bytes":17785,"path":"scripts/ndu_real_runtime/study.py","sha256":"372f5120c6a9463986b9499c2072043279d963aa4110895e57911f2b7f93b2d7"},{"bytes":9847,"path":"scripts/ndu_real_runtime/subprocess_supervisor.py","sha256":"2679c877f630148edddd17183e6d3766b9c690d57ce8465308eb8d84a5aafb81"},{"bytes":36744,"path":"scripts/ndu_real_runtime/training.py","sha256":"593518b351073dc213f0bc9c139ca7d7fa61c0bc7783ccd9646a79b84155570f"},{"bytes":13318,"path":"scripts/ndu_real_runtime/training_grid.py","sha256":"af8bbf410207c86363ca05203d99f68f73c4ebeedf49f5858945e869df54d331"},{"bytes":22876,"path":"scripts/ndu_real_runtime/training_job_result.py","sha256":"68b2971750b38992622b8b853c7b58727f3a549dfe9802e323d5085e8d4a7284"},{"bytes":6000,"path":"scripts/ndu_real_runtime/trajectory.py","sha256":"700a66b30d24dbe39d75c2cd1293cd0ae2719526695a3fa71e725eb56670320e"}],"training_records":{"bytes":2116544,"path":"/home/qq/cell-causal-abcde-20261108-cf0/collection/training-common.jsonl","sha256":"6d33792df24a44865b95e0b867f18b9faa5753ab9a86f5cd88a861fdfbf03b14"}},"request_sha256":"052e8b30473bb1517376f6e8c0a27e67ed27644e9e0ba9fa69ae84462a0d062c","schema":"ndu.real.candidate-bootstrap-spec.v1","source_commit_supplied_by_caller":"cce6a7d3222a7eaffe2ec3890e624820a2ec8023"}')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def write_once(path, raw):
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def allowed_path(name):
    path = PurePosixPath(name)
    if path.is_absolute() or str(path) != name or "\\" in name or any(p in {".", ".."} for p in path.parts):
        return False
    extras = {"experiments/multimodal_output_portfolio/joint_hepta_20261029/hepta_core.py", "scripts/ndu_real_runtime/finite_entropic_golden.json"}
    return name in extras or (
        len(path.parts) == 3 and path.parts[0] == "scripts"
        and path.parts[1] in {"ndu_real_runtime", "ndu_real_materials"}
        and path.suffix == ".py" and not path.name.startswith("test_")
    )


def validate_archive(raw):
    pin = SPEC["archive"]
    require(len(raw) == pin["bytes"] and digest(raw) == pin["sha256"], "Source archive digest or byte length differs")
    expected = {}
    for entry in SPEC["request"]["source_pins"]:
        name = entry["path"]
        require(set(entry) == {"path", "bytes", "sha256"} and allowed_path(name) and name not in expected, "Invalid or duplicate source manifest path")
        require(type(entry["bytes"]) is int and 0 <= entry["bytes"] <= 4 * 1024**2, "Invalid source file size")
        expected[name] = entry
    require(1 <= len(expected) <= 256 and sum(p["bytes"] for p in expected.values()) <= 32 * 1024**2, "Source inventory exceeds its bound")
    with gzip.GzipFile(fileobj=io.BytesIO(raw), mode="rb") as compressed:
        expanded = compressed.read(40 * 1024**2 + 1)
    require(len(expanded) <= 40 * 1024**2, "Expanded archive exceeds its bound")
    files = {}
    with tarfile.open(fileobj=io.BytesIO(expanded), mode="r:") as archive:
        for member in archive:
            require(member.type == tarfile.REGTYPE and not member.pax_headers and not member.linkname, "Archive contains a nonregular file, link, or extended header")
            require(allowed_path(member.name) and member.name in expected and member.name not in files, "Archive contains an escaping, unplanned, or duplicate path")
            pin = expected[member.name]
            require(member.size == pin["bytes"], "Archive member size differs from source pin")
            stream = archive.extractfile(member)
            require(stream is not None, "Regular archive member has no data")
            data = stream.read(member.size + 1)
            require(len(data) == pin["bytes"] and digest(data) == pin["sha256"], "Source file digest differs from request")
            files[member.name] = data
    require(set(files) == set(expected), "Archive omits a pinned source file")
    return files


def main():
    require(SPEC["schema"] == "ndu.real.candidate-bootstrap-spec.v1", "Unexpected bootstrap schema")
    root = Path(SPEC["remote_root"])
    require(str(root) == "/home/qq/mem-candidate-retention-20261109-a6b21bc7", "Frozen campaign destination differs")
    archive_path = Path(SPEC["archive"]["path"])
    require(str(archive_path) == "/home/qq/mem-candidate-20261109-a6b21bc7-source.tar.gz", "Frozen archive location differs")
    require(0 < SPEC["archive"]["bytes"] <= 16 * 1024**2, "Archive exceeds its bound")
    with os.fdopen(os.open(archive_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb") as stream:
        info = os.fstat(stream.fileno())
        require(stat.S_ISREG(info.st_mode) and info.st_size == SPEC["archive"]["bytes"], "Archive is not the pinned regular file")
        raw = stream.read(SPEC["archive"]["bytes"] + 1)
    files = validate_archive(raw)
    request = SPEC["request"]
    request_raw = json_bytes(request)
    require(digest(request_raw) == SPEC["request_sha256"], "Embedded request digest differs")
    source = root / "source"
    require(request["config"]["repository_root"] == str(source) and request["config"]["scripts_root"] == str(source / "scripts"), "Request execution roots differ")
    require(request["source_commit"] == SPEC["source_commit_supplied_by_caller"], "Request commit identity differs")
    # A prior attempt, including a failed extraction, is never silently renewed.
    root.mkdir(mode=0o700, exist_ok=False)
    started = time.perf_counter()
    receipt = {"schema": "ndu.real.candidate-bootstrap.v1", "status": "Failed", "source_commit": request["source_commit"], "archive": SPEC["archive"], "request_sha256": SPEC["request_sha256"], "source_file_count": len(files), "source_projection_verified": True, "retry_of": None, "scientific_acceptance": "HOLD"}
    try:
        source.mkdir(mode=0o700)
        for name, data in sorted(files.items()):
            path = source / name
            path.parent.mkdir(parents=True, exist_ok=True)
            write_once(path, data)
            path.chmod(0o644)
        write_once(root / "request.json", request_raw)
        overrides = {"PYTHONPATH": os.pathsep.join((str(source / "scripts"), str(source), request["config"]["pillow_path"])), "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1"}
        command = [request["config"]["python"], "-m", "ndu_real_runtime.run_candidate_retention", "--request", str(root / "request.json"), "--output", str(root / "run-001")]
        receipt.update(command=command, environment_overrides=overrides)
        print(json.dumps({"event": "candidate_campaign_start", "source_commit": request["source_commit"], "run": str(root / "run-001"), "request_sha256": SPEC["request_sha256"]}), flush=True)
        with (root / "runner-console.log").open("xb") as log:
            result = subprocess.run(command, cwd=source, env={**os.environ, **overrides}, stdout=log, stderr=subprocess.STDOUT, check=False)
        receipt.update(returncode=result.returncode, status="Completed" if result.returncode == 0 else "Failed")
    except Exception as error:
        receipt["error"] = {"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()}
    receipt["wall_seconds"] = time.perf_counter() - started
    write_once(root / "BOOTSTRAP_RECEIPT.json", json_bytes(receipt))
    print(json.dumps({"event": "candidate_campaign_exit", "status": receipt["status"], "returncode": receipt.get("returncode"), "receipt": str(root / "BOOTSTRAP_RECEIPT.json")}), flush=True)
    return 0 if receipt["status"] == "Completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
