"""Export terminal candidate-campaign metadata once, without rescoring or actors."""

from collections import Counter, defaultdict
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile
import time

ROOT = Path("/home/qq/mem-candidate-retention-20261109-a6b21bc7")
EXPORT_NAME = "evidence-export-v1"
RUNS = {"run-001", "run-002"}
ROOT_METADATA = {
    "request.json", "request-v2.json", "BOOTSTRAP_RECEIPT.json",
    "BOOTSTRAP_RECEIPT-v2.json", "runner-console.log", "runner-console-v2.log",
}
SUFFIXES = {".json", ".jsonl", ".log"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def fingerprint(path):
    digest = hashlib.sha256()
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), "Evidence must be a regular file: " + str(path))
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(data)
        after = os.fstat(stream.fileno())
    require((before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_size, after.st_mtime_ns, after.st_ctime_ns), "File changed during collection: " + str(path))
    return {"sha256": digest.hexdigest(), "bytes": after.st_size}


def read_json(relative, *, optional=False):
    path = ROOT / relative
    if optional and not path.exists():
        return None
    pin = fingerprint(path)
    require(pin["bytes"] <= 32 * 1024**2, "JSON exceeds the metadata read bound")
    raw = path.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == pin["sha256"], "JSON changed during collection")
    return json.loads(raw)


def metadata_path(relative):
    return relative.as_posix() in ROOT_METADATA or (relative.parts[0] in RUNS and relative.suffix in SUFFIXES)


def summary(run, bootstrap):
    old_run = read_json("run-001/RUN_RECEIPT.json")
    old_bootstrap = read_json("BOOTSTRAP_RECEIPT.json")
    plan = read_json("run-002/PLAN.json", optional=True)
    report = read_json("run-002/REPORT.json", optional=True)
    if report is not None:
        require(report.get("schema") == "ndu.real.candidate-retention-report.v1", "Unexpected report schema")
        require(fingerprint(ROOT / "run-002/REPORT.json")["sha256"] == run.get("report_sha256"), "Terminal receipt does not bind REPORT bytes")
        require(plan is not None and len(plan["episodes"]) == report["planned_episodes"] == len(report["episodes"]), "Plan/report full denominators differ")
        require({r["original_operation_id"] for r in plan["episodes"]} == {r["original_operation_id"] for r in report["episodes"]}, "Plan/report episode identities differ")
    else:
        require(run["status"] != "Completed", "Completed run lacks its report")
    design = None
    if plan is not None:
        require(fingerprint(ROOT / "run-002/PLAN.json")["sha256"] == run.get("plan_sha256"), "Terminal receipt does not bind PLAN bytes")
        roles = defaultdict(list)
        for row in plan["episodes"]:
            roles[row["split"]].append(row)
        design = {
            "planned_episodes": len(plan["episodes"]),
            "planned_pairs": len({r["pair_id"] for r in plan["episodes"]}),
            "source_group_count": len({r["source_group_id"] for r in plan["episodes"]}),
            "by_role": {role: {"episodes": len(rows), "case_pairs": len({r["pair_id"] for r in rows}), "source_groups": len({r["source_group_id"] for r in rows}), "episode_groups": len({r["episode_group"] for r in rows}), "family_episode_counts": dict(Counter(r["task_family"] for r in rows))} for role, rows in sorted(roles.items())},
            "groups_per_role": plan["groups_per_role"],
            "selection_salt": plan["selection_salt"],
            "excluded_source_groups": plan["excluded_source_groups"],
            "quarantined_source_groups_not_in_released_catalog": plan.get("quarantined_source_groups_not_in_released_catalog", []),
            "control_plan": plan["control_plan"],
        }
    fields = ("status", "source_commit", "planned_episodes", "source_group_count", "terminal_status_counts", "wall_seconds", "cpu_seconds", "weights_sha256_before", "weights_sha256_after", "source_pins_unchanged", "energy_joules", "provider_charges", "error")
    return {
        "schema": "ndu.real.candidate-retention-export-summary.v1",
        "campaign_root": str(ROOT),
        "attempt_kind": bootstrap.get("attempt_kind"),
        "retry_of": bootstrap.get("retry_of"),
        "run_001": {key: old_run[key] for key in fields if key in old_run},
        "run_002": {key: run[key] for key in fields if key in run},
        "bootstrap_wall_seconds": {"original": old_bootstrap.get("wall_seconds"), "preflight_correction": bootstrap.get("wall_seconds")},
        "cost_accounting": "Run/episode/Bootstrap envelopes overlap; retain all original levels and do not add them. Export cost is separate.",
        "design": design,
        # Copy panels intact: numerator, denominator, unknowns, bounds and nulls.
        "report": None if report is None else {key: value for key, value in report.items() if key not in {"episodes", "verified_source_sha256"}},
        "report_missing": report is None,
        "new_fits": 0,
        "independent_training_repeats": 0,
        "frozen_checkpoint_count": 1,
        "scientific_acceptance": "HOLD",
        "collection_performs_no_rescore_or_actor_execution": True,
    }


def add_bytes(archive, name, raw):
    info = tarfile.TarInfo(name)
    info.size, info.mode, info.uid, info.gid, info.mtime = len(raw), 0o644, 0, 0, 0
    info.uname = info.gname = ""
    archive.addfile(info, io.BytesIO(raw))


def main():
    started, cpu = time.perf_counter(), time.process_time()
    require(ROOT.is_dir() and not ROOT.is_symlink(), "Campaign root is missing or linked")
    run = read_json("run-002/RUN_RECEIPT.json")
    bootstrap = read_json("BOOTSTRAP_RECEIPT-v2.json")
    require(run.get("status") in {"Completed", "Failed", "Unresolved"}, "Wait for the run's terminal receipt before collecting")
    require(bootstrap.get("status") in {"Completed", "Failed"} and bootstrap.get("attempt_kind") == "preflight-correction", "Wait for the correction bootstrap's terminal receipt before collecting")
    require(bootstrap.get("source_commit") == run.get("source_commit"), "Bootstrap and run source identities differ")
    result = summary(run, bootstrap)
    export = ROOT / EXPORT_NAME
    require(not os.path.lexists(export), "Export already exists; refusing replacement")
    # Inventory the whole campaign, never following a route to external material.
    assets, metadata = [], []
    for directory, subdirs, filenames in os.walk(ROOT, followlinks=False):
        current = Path(directory)
        subdirs.sort()
        filenames.sort()
        for name in subdirs:
            require(not (current / name).is_symlink(), "Linked directory cannot be included in a complete asset inventory")
        for name in filenames:
            path = current / name
            relative = path.relative_to(ROOT)
            pin = fingerprint(path)
            included = metadata_path(relative)
            entry = {"path": relative.as_posix(), **pin, "outside_archive": not included, "retained_on_remote": True}
            if included:
                entry["archive_path"] = "campaign/" + relative.as_posix()
                metadata.append(dict(entry))
            assets.append(entry)
    export.mkdir(mode=0o700, exist_ok=False)
    generated = {
        "SUMMARY.json": result,
        "ASSET_INDEX.json": {"schema": "ndu.real.candidate-assets.v1", "root": str(ROOT), "scope": "Every original regular file in the entire campaign tree before export; no symlink traversal. The new export directory is indexed separately by EXPORT_RECEIPT.", "file_count": len(assets), "total_bytes": sum(row["bytes"] for row in assets), "files": assets},
        "METADATA_INDEX.json": {"schema": "ndu.real.candidate-metadata-archive.v1", "source_root": str(ROOT), "file_count": len(metadata), "original_bytes": sum(row["bytes"] for row in metadata), "exclusions": "Images, binaries, source files and source-package assets remain on remote and appear in ASSET_INDEX. No material-root references, annotations or external weights are accessed.", "files": metadata},
    }
    generated_raw = {name: json_bytes(value) for name, value in generated.items()}
    for name, raw in generated_raw.items():
        with (export / name).open("xb") as stream:
            stream.write(raw)
    archive_path = export / "metadata-evidence.tar.xz"
    with archive_path.open("xb") as stream:
        with tarfile.open(fileobj=stream, mode="w:xz", format=tarfile.PAX_FORMAT, preset=6) as archive:
            for row in metadata:
                raw = (ROOT / row["path"]).read_bytes()
                require(len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"], "Metadata changed after inventory: " + row["path"])
                add_bytes(archive, row["archive_path"], raw)
            for name, raw in generated_raw.items():
                add_bytes(archive, name, raw)
    # Terminal receipts are checked again after packaging, without importing code.
    for row in assets:
        if row["path"] in {"run-002/RUN_RECEIPT.json", "BOOTSTRAP_RECEIPT-v2.json"}:
            require(fingerprint(ROOT / row["path"]) == {key: row[key] for key in ("sha256", "bytes")}, "Terminal receipt changed during export")
    receipt = {
        "schema": "ndu.real.candidate-evidence-export.v1",
        "status": "Completed",
        "source_commit": run.get("source_commit"),
        "run_status": run["status"],
        "bootstrap_status": bootstrap["status"],
        "source_root": str(ROOT),
        "output": str(export),
        "artifact_pins": {name: {"path": str(export / name), **fingerprint(export / name)} for name in (*generated_raw, archive_path.name)},
        "original_files": len(assets),
        "archived_original_metadata_files": len(metadata),
        "outside_archive_files": len(assets) - len(metadata),
        "wall_seconds": time.perf_counter() - started,
        "cpu_seconds": time.process_time() - cpu,
        "energy_joules": None,
        "provider_charges": None,
        "scientific_acceptance": "HOLD",
    }
    with (export / "EXPORT_RECEIPT.json").open("xb") as stream:
        stream.write(json_bytes(receipt))
    print(json.dumps(receipt, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
