"""Build the frozen candidate campaign payload; never launch or change a repo."""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shlex
import stat
import tarfile

ROOT = Path(__file__).resolve().parent
REMOTE_ROOT = "/home/qq/mem-candidate-retention-20261109-a6b21bc7"
REMOTE_ARCHIVE = "/home/qq/mem-candidate-20261109-a6b21bc7-source.tar.gz"
EXTRAS = {
    "experiments/multimodal_output_portfolio/joint_hepta_20261029/hepta_core.py",
    "scripts/ndu_real_runtime/finite_entropic_golden.json",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key")
            result[key] = value
        return result
    def constant(value):
        raise ValueError("Nonfinite JSON value: " + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)


def source_projection(repository):
    repository = Path(repository).resolve(strict=True)
    names = set(EXTRAS)
    for package in ("ndu_real_runtime", "ndu_real_materials"):
        folder = repository / "scripts" / package
        require(folder.is_dir() and not folder.is_symlink(), "Source package missing or linked")
        names.update(p.relative_to(repository).as_posix() for p in folder.glob("*.py") if not p.name.startswith("test_"))
    files = {}
    for name in sorted(names):
        path = repository / name
        require(path.resolve(strict=True) == path, "Source symlinks are not admitted: " + name)
        require(stat.S_ISREG(path.lstat().st_mode) and path.stat().st_size <= 4 * 1024**2, "Source must be a bounded regular file: " + name)
        files[name] = path.read_bytes()
    require(1 <= len(files) <= 256 and sum(map(len, files.values())) <= 32 * 1024**2, "Source projection exceeds its bounds")
    return files


def archive_bytes(files):
    # USTAR + zero metadata + gzip mtime 0 makes the same bytes reproducible.
    tar_stream = io.BytesIO()
    with tarfile.open(fileobj=tar_stream, mode="w", format=tarfile.USTAR_FORMAT) as archive:
        for name, raw in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.uid, info.gid, info.mtime = len(raw), 0o644, 0, 0, 0
            info.uname = info.gname = ""
            archive.addfile(info, io.BytesIO(raw))
    output = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", compresslevel=9, mtime=0, fileobj=output) as compressed:
        compressed.write(tar_stream.getvalue())
    return output.getvalue()


def build(repository, template, commit, output):
    require(re.fullmatch(r"[0-9a-f]{40}", commit), "Full final code commit is required")
    template_raw = Path(template).read_bytes()
    request = strict_json(template_raw)
    config = request["config"]
    require(request["schema"] == "ndu.real.candidate-retention-request.v1", "Unexpected request schema")
    require(request["experiment_id"] == Path(REMOTE_ROOT).name, "Unexpected campaign identity")
    require(config["repository_root"] == REMOTE_ROOT + "/source" and config["scripts_root"] == REMOTE_ROOT + "/source/scripts", "Frozen execution roots differ")
    require(config["episode_wall_seconds"] == 60 and request["groups_per_role"] == {"development": 10, "retention_validation": 4} and request["max_workers"] == 2, "Frozen campaign size or budget differs")
    require(all(Path(config[key]).is_absolute() for key in ("python", "pillow_path", "material_root")), "Absolute frozen runtime paths required")
    require(config["repository_root"] in config["runtime_roots"] and config["pillow_path"] in config["runtime_roots"], "Host isolation roots omit frozen code or Pillow")
    files = source_projection(repository)
    request["source_commit"] = commit
    request["source_pins"] = [{"path": name, "sha256": digest(raw), "bytes": len(raw)} for name, raw in files.items()]
    require(digest(files["scripts/ndu_real_materials/evaluator.py"]) == config["evaluator_sha256"], "Template evaluator pin differs from published source")
    require(any(pin["path"] == config["source_exposure_ledger_path"] and pin["sha256"] == config["source_exposure_ledger_sha256"] for pin in request["exposure_ledgers"]), "Host exposure pin differs from request ledgers")
    source_archive, request_raw = archive_bytes(files), json_bytes(request)
    spec = {
        "schema": "ndu.real.candidate-bootstrap-spec.v1",
        "remote_root": REMOTE_ROOT,
        "archive": {"path": REMOTE_ARCHIVE, "sha256": digest(source_archive), "bytes": len(source_archive)},
        "request": request,
        "request_sha256": digest(request_raw),
        "source_commit_supplied_by_caller": commit,
        "independent_training_repeats": 0,
        "frozen_checkpoint_count": 1,
    }
    bootstrap_template = (ROOT / "bootstrap_template.py").read_text()
    require(bootstrap_template.count("__FROZEN_SPEC_JSON__") == 1, "Bootstrap template substitution differs")
    bootstrap = bootstrap_template.replace("__FROZEN_SPEC_JSON__", repr(json.dumps(spec, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False))).encode()
    compile(bootstrap, "bootstrap.py", "exec")
    command = (shlex.quote(config["python"]) + " -c " + shlex.quote(bootstrap.decode()) + "\n").encode()
    artifacts = {"source.tar.gz": source_archive, "request.json": request_raw, "bootstrap.py": bootstrap, "submission_command.txt": command}
    manifest = {
        "schema": "ndu.real.candidate-launch-build.v1",
        "source_commit": commit,
        "commit_binding": "caller-supplied published commit; this builder verifies exact local source projection bytes without querying Git",
        "remote_root": REMOTE_ROOT,
        "remote_archive_path": REMOTE_ARCHIVE,
        "remote_run_path": REMOTE_ROOT + "/run-001",
        "request_template_sha256": digest(template_raw),
        "builder_sha256": digest(Path(__file__).read_bytes()),
        "bootstrap_template_sha256": digest(bootstrap_template.encode()),
        "source_file_count": len(files),
        "source_total_bytes": sum(map(len, files.values())),
        "source_pins": request["source_pins"],
        "artifacts": {name: {"sha256": digest(raw), "bytes": len(raw)} for name, raw in artifacts.items()},
        "scientific_acceptance": "HOLD",
        "remote_execution_performed": False,
    }
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    for name, raw in {**artifacts, "BUILD_MANIFEST.json": json_bytes(manifest)}.items():
        with (output / name).open("xb") as stream:
            stream.write(raw)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", required=True, type=Path)
    parser.add_argument("--template", required=True, type=Path)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    manifest = build(args.repository, args.template, args.source_commit, args.output)
    print(json.dumps({key: manifest[key] for key in ("source_commit", "source_file_count", "source_total_bytes", "artifacts", "remote_execution_performed")}))


if __name__ == "__main__":
    main()
