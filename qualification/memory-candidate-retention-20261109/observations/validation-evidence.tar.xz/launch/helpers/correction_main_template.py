# Appended to the verified common bootstrap section by build_correction.py.


def read_regular(path, *, expected_sha=None, expected_bytes=None, limit=1024 * 1024):
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_size <= limit, "Evidence is not a bounded regular file")
        raw = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
    require((before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_size, after.st_mtime_ns, after.st_ctime_ns) and len(raw) <= limit, "Original evidence changed while read")
    require(expected_bytes is None or len(raw) == expected_bytes, "Original evidence byte length differs")
    require(expected_sha is None or digest(raw) == expected_sha, "Original evidence digest differs")
    return raw


def verify_correction_request(old, new, root):
    old_source, new_source = str(root / "source"), str(root / "source-v2")
    require(old["config"]["repository_root"] == old_source and old["config"]["scripts_root"] == old_source + "/scripts", "Original execution roots differ")
    require(old["config"]["runtime_roots"].count(old_source) == 1, "Original runtime source root differs")
    expected = json.loads(json.dumps(old))
    expected["source_commit"] = new["source_commit"]
    expected["source_pins"] = new["source_pins"]
    expected["config"]["repository_root"] = new_source
    expected["config"]["scripts_root"] = new_source + "/scripts"
    expected["config"]["runtime_roots"] = [new_source if value == old_source else value for value in old["config"]["runtime_roots"]]
    require(new == expected, "Correction changed frozen experiment fields beyond code and execution paths")
    require(new["source_commit"] == SPEC["source_commit_supplied_by_caller"] and new["source_commit"] != old["source_commit"], "Correction commit differs")


def verify_original_preflight(root):
    old_raw = read_regular(root / "request.json", expected_sha=SPEC["original_request_sha256"])
    receipt_raw = read_regular(root / "run-001/RUN_RECEIPT.json", expected_sha=SPEC["original_run_receipt_sha256"], expected_bytes=SPEC["original_run_receipt_bytes"])
    receipt = json.loads(receipt_raw)
    require(receipt.get("status") == "Failed", "Original attempt did not end as Failed")
    require(not os.path.lexists(root / "run-001/PLAN.json"), "Original PLAN exists; cannot treat the attempt as an unstarted preflight")
    journal = read_regular(root / "run-001/runner.jsonl", expected_bytes=0, limit=1)
    require(not journal and not receipt.get("attempts") and receipt.get("planned_episodes") is None, "Original episode execution evidence exists")
    old = json.loads(old_raw)
    require(receipt.get("source_commit") == old["source_commit"], "Original receipt and request code identity differ")
    return old, {
        "request_sha256": digest(old_raw),
        "run_receipt_sha256": digest(receipt_raw),
        "status": receipt["status"],
        "plan_absent": True,
        "runner_journal_bytes": len(journal),
        "runner_journal_sha256": digest(journal),
    }


def main():
    require(SPEC["schema"] == "ndu.real.candidate-bootstrap-correction-spec.v1" and SPEC["attempt_kind"] == "preflight-correction", "Unexpected correction schema")
    root = Path(SPEC["remote_root"])
    require(str(root) == "/home/qq/mem-candidate-retention-20261109-a6b21bc7" and root.is_dir() and not root.is_symlink(), "Original campaign root missing or linked")
    require(SPEC["archive"]["path"] == "/home/qq/mem-candidate-20261109-a6b21bc7-source-v2.tar.gz", "Correction archive location differs")
    old, original_evidence = verify_original_preflight(root)
    request = SPEC["request"]
    verify_correction_request(old, request, root)
    request_raw = json_bytes(request)
    require(digest(request_raw) == SPEC["request_sha256"], "Correction request digest differs")
    archive = SPEC["archive"]
    require(0 < archive["bytes"] <= 16 * 1024**2, "Correction archive exceeds its bound")
    raw = read_regular(Path(archive["path"]), expected_sha=archive["sha256"], expected_bytes=archive["bytes"], limit=16 * 1024**2)
    files = validate_archive(raw)
    source = root / "source-v2"
    destinations = [source, root / "request-v2.json", root / "run-002", root / "runner-console-v2.log", root / "BOOTSTRAP_RECEIPT-v2.json"]
    require(all(not os.path.lexists(path) for path in destinations), "Correction destination already exists; refusing replacement or retry")
    # Atomic reservation is create-only. The old campaign tree is never rewritten.
    source.mkdir(mode=0o700, exist_ok=False)
    started = time.perf_counter()
    receipt = {
        "schema": "ndu.real.candidate-bootstrap.v1",
        "status": "Failed",
        "attempt_kind": "preflight-correction",
        "retry_of": {"run": str(root / "run-001"), "job_id": SPEC["original_job_id"]},
        "original_preflight_evidence": original_evidence,
        "source_commit": request["source_commit"],
        "archive": archive,
        "request_sha256": SPEC["request_sha256"],
        "source_file_count": len(files),
        "source_projection_verified": True,
        "new_fits": 0,
        "training_executed": False,
        "independent_training_repeats": 0,
        "frozen_checkpoint_count": 1,
        "scientific_acceptance": "HOLD",
    }
    try:
        for name, data in sorted(files.items()):
            path = source / name
            path.parent.mkdir(parents=True, exist_ok=True)
            write_once(path, data)
            path.chmod(0o644)
        write_once(root / "request-v2.json", request_raw)
        overrides = {"PYTHONPATH": os.pathsep.join((str(source / "scripts"), str(source), request["config"]["pillow_path"])), "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1"}
        command = [request["config"]["python"], "-m", "ndu_real_runtime.run_candidate_retention", "--request", str(root / "request-v2.json"), "--output", str(root / "run-002")]
        receipt.update(command=command, environment_overrides=overrides)
        print(json.dumps({"event": "candidate_campaign_start", "attempt_kind": "preflight-correction", "source_commit": request["source_commit"], "run": str(root / "run-002"), "request_sha256": SPEC["request_sha256"]}), flush=True)
        with (root / "runner-console-v2.log").open("xb") as log:
            result = subprocess.run(command, cwd=source, env={**os.environ, **overrides}, stdout=log, stderr=subprocess.STDOUT, check=False)
        receipt.update(returncode=result.returncode, status="Completed" if result.returncode == 0 else "Failed")
    except Exception as error:
        receipt["error"] = {"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()}
    receipt["wall_seconds"] = time.perf_counter() - started
    write_once(root / "BOOTSTRAP_RECEIPT-v2.json", json_bytes(receipt))
    print(json.dumps({"event": "candidate_campaign_exit", "attempt_kind": "preflight-correction", "status": receipt["status"], "returncode": receipt.get("returncode"), "receipt": str(root / "BOOTSTRAP_RECEIPT-v2.json")}), flush=True)
    return 0 if receipt["status"] == "Completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
