"""Prepare the explicitly authorized preflight correction; never execute it."""

import argparse
import copy
import json
from pathlib import Path
import re
import shlex

import build as payload

OLD_REQUEST_SHA = "052e8b30473bb1517376f6e8c0a27e67ed27644e9e0ba9fa69ae84462a0d062c"
OLD_RECEIPT_SHA = "bda871d1df0fb78398b445265c68f047790396629f208d32ba08e117d201255c"
OLD_JOB = "1a1c0432b6c-5e21-992"
REMOTE_ARCHIVE = "/home/qq/mem-candidate-20261109-a6b21bc7-source-v2.tar.gz"


def build(repository, original_request, commit, output):
    payload.require(re.fullmatch(r"[0-9a-f]{40}", commit), "Full correction code commit required")
    old_raw = Path(original_request).read_bytes()
    payload.require(payload.digest(old_raw) == OLD_REQUEST_SHA, "Original frozen request differs")
    old = payload.strict_json(old_raw)
    old_source, new_source = payload.REMOTE_ROOT + "/source", payload.REMOTE_ROOT + "/source-v2"
    payload.require(old["config"]["repository_root"] == old_source and old["config"]["scripts_root"] == old_source + "/scripts", "Unexpected original source paths")
    payload.require(old["config"]["runtime_roots"].count(old_source) == 1 and commit != old["source_commit"], "Original runtime root or correction commit differs")
    files = payload.source_projection(repository)
    payload.require(set(files) == {pin["path"] for pin in old["source_pins"]}, "Correction changes the published source inventory")
    request = copy.deepcopy(old)
    request["source_commit"] = commit
    request["source_pins"] = [{"path": name, "sha256": payload.digest(raw), "bytes": len(raw)} for name, raw in files.items()]
    request["config"]["repository_root"] = new_source
    request["config"]["scripts_root"] = new_source + "/scripts"
    request["config"]["runtime_roots"] = [new_source if value == old_source else value for value in old["config"]["runtime_roots"]]
    payload.require(payload.digest(files["scripts/ndu_real_materials/evaluator.py"]) == request["config"]["evaluator_sha256"], "Original evaluator pin changed")
    archive, request_raw = payload.archive_bytes(files), payload.json_bytes(request)
    spec = {
        "schema": "ndu.real.candidate-bootstrap-correction-spec.v1",
        "remote_root": payload.REMOTE_ROOT,
        "archive": {"path": REMOTE_ARCHIVE, "sha256": payload.digest(archive), "bytes": len(archive)},
        "request": request,
        "request_sha256": payload.digest(request_raw),
        "source_commit_supplied_by_caller": commit,
        "original_request_sha256": OLD_REQUEST_SHA,
        "original_run_receipt_sha256": OLD_RECEIPT_SHA,
        "original_run_receipt_bytes": 1478,
        "original_job_id": OLD_JOB,
        "attempt_kind": "preflight-correction",
        "new_fits": 0,
        "independent_training_repeats": 0,
        "frozen_checkpoint_count": 1,
    }
    base = (payload.ROOT / "bootstrap_template.py").read_text()
    marker = "\ndef main():\n"
    payload.require(base.count(marker) == 1, "Original bootstrap common section changed")
    correction = (payload.ROOT / "correction_main_template.py").read_text()
    template = base.split(marker)[0] + "\n" + correction
    payload.require(template.count("__FROZEN_SPEC_JSON__") == 1, "Correction substitution differs")
    bootstrap = template.replace("__FROZEN_SPEC_JSON__", repr(json.dumps(spec, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False))).encode()
    compile(bootstrap, "bootstrap-v2.py", "exec")
    command = (shlex.quote(request["config"]["python"]) + " -c " + shlex.quote(bootstrap.decode()) + "\n").encode()
    artifacts = {"source-v2.tar.gz": archive, "request-v2.json": request_raw, "bootstrap-v2.py": bootstrap, "submission-command-v2.txt": command}
    manifest = {
        "schema": "ndu.real.candidate-launch-correction-build.v1",
        "attempt_kind": "preflight-correction",
        "retry_of": {"run": payload.REMOTE_ROOT + "/run-001", "job_id": OLD_JOB},
        "source_commit": commit,
        "commit_binding": "caller-supplied published commit; exact local source bytes independently pinned",
        "original_request_sha256": OLD_REQUEST_SHA,
        "original_run_receipt_sha256": OLD_RECEIPT_SHA,
        "remote_archive_path": REMOTE_ARCHIVE,
        "remote_source_path": new_source,
        "remote_run_path": payload.REMOTE_ROOT + "/run-002",
        "allowed_request_changes": ["source_commit", "source_pins", "config.repository_root", "config.scripts_root", "config.runtime_roots (only source to source-v2)"],
        "source_file_count": len(files),
        "source_total_bytes": sum(map(len, files.values())),
        "source_pins": request["source_pins"],
        "artifacts": {name: {"sha256": payload.digest(raw), "bytes": len(raw)} for name, raw in artifacts.items()},
        "builder_sha256": payload.digest(Path(__file__).read_bytes()),
        "common_builder_sha256": payload.digest((payload.ROOT / "build.py").read_bytes()),
        "bootstrap_common_template_sha256": payload.digest(base.encode()),
        "correction_template_sha256": payload.digest(correction.encode()),
        "new_fits": 0,
        "independent_training_repeats": 0,
        "frozen_checkpoint_count": 1,
        "scientific_acceptance": "HOLD",
        "remote_execution_performed": False,
    }
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    for name, raw in {**artifacts, "BUILD_MANIFEST-v2.json": payload.json_bytes(manifest)}.items():
        with (output / name).open("xb") as stream:
            stream.write(raw)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", required=True, type=Path)
    parser.add_argument("--original-request", required=True, type=Path)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    manifest = build(args.repository, args.original_request, args.source_commit, args.output)
    print(json.dumps({key: manifest[key] for key in ("source_commit", "source_file_count", "source_total_bytes", "artifacts", "attempt_kind", "remote_execution_performed")}))


if __name__ == "__main__":
    main()
