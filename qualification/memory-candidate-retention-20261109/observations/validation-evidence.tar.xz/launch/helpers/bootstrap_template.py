"""Create one fixed campaign root from a verified payload, then execute once."""

import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import tarfile
import time
import traceback

SPEC = json.loads(__FROZEN_SPEC_JSON__)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def write_once(path, raw):
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def allowed_path(name):
    path = PurePosixPath(name)
    if path.is_absolute() or str(path) != name or "\\" in name or any(p in {".", ".."} for p in path.parts):
        return False
    extras = {"experiments/multimodal_output_portfolio/joint_hepta_20261029/hepta_core.py", "scripts/ndu_real_runtime/finite_entropic_golden.json"}
    return name in extras or (
        len(path.parts) == 3 and path.parts[0] == "scripts"
        and path.parts[1] in {"ndu_real_runtime", "ndu_real_materials"}
        and path.suffix == ".py" and not path.name.startswith("test_")
    )


def validate_archive(raw):
    pin = SPEC["archive"]
    require(len(raw) == pin["bytes"] and digest(raw) == pin["sha256"], "Source archive digest or byte length differs")
    expected = {}
    for entry in SPEC["request"]["source_pins"]:
        name = entry["path"]
        require(set(entry) == {"path", "bytes", "sha256"} and allowed_path(name) and name not in expected, "Invalid or duplicate source manifest path")
        require(type(entry["bytes"]) is int and 0 <= entry["bytes"] <= 4 * 1024**2, "Invalid source file size")
        expected[name] = entry
    require(1 <= len(expected) <= 256 and sum(p["bytes"] for p in expected.values()) <= 32 * 1024**2, "Source inventory exceeds its bound")
    with gzip.GzipFile(fileobj=io.BytesIO(raw), mode="rb") as compressed:
        expanded = compressed.read(40 * 1024**2 + 1)
    require(len(expanded) <= 40 * 1024**2, "Expanded archive exceeds its bound")
    files = {}
    with tarfile.open(fileobj=io.BytesIO(expanded), mode="r:") as archive:
        for member in archive:
            require(member.type == tarfile.REGTYPE and not member.pax_headers and not member.linkname, "Archive contains a nonregular file, link, or extended header")
            require(allowed_path(member.name) and member.name in expected and member.name not in files, "Archive contains an escaping, unplanned, or duplicate path")
            pin = expected[member.name]
            require(member.size == pin["bytes"], "Archive member size differs from source pin")
            stream = archive.extractfile(member)
            require(stream is not None, "Regular archive member has no data")
            data = stream.read(member.size + 1)
            require(len(data) == pin["bytes"] and digest(data) == pin["sha256"], "Source file digest differs from request")
            files[member.name] = data
    require(set(files) == set(expected), "Archive omits a pinned source file")
    return files


def main():
    require(SPEC["schema"] == "ndu.real.candidate-bootstrap-spec.v1", "Unexpected bootstrap schema")
    root = Path(SPEC["remote_root"])
    require(str(root) == "/home/qq/mem-candidate-retention-20261109-a6b21bc7", "Frozen campaign destination differs")
    archive_path = Path(SPEC["archive"]["path"])
    require(str(archive_path) == "/home/qq/mem-candidate-20261109-a6b21bc7-source.tar.gz", "Frozen archive location differs")
    require(0 < SPEC["archive"]["bytes"] <= 16 * 1024**2, "Archive exceeds its bound")
    with os.fdopen(os.open(archive_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb") as stream:
        info = os.fstat(stream.fileno())
        require(stat.S_ISREG(info.st_mode) and info.st_size == SPEC["archive"]["bytes"], "Archive is not the pinned regular file")
        raw = stream.read(SPEC["archive"]["bytes"] + 1)
    files = validate_archive(raw)
    request = SPEC["request"]
    request_raw = json_bytes(request)
    require(digest(request_raw) == SPEC["request_sha256"], "Embedded request digest differs")
    source = root / "source"
    require(request["config"]["repository_root"] == str(source) and request["config"]["scripts_root"] == str(source / "scripts"), "Request execution roots differ")
    require(request["source_commit"] == SPEC["source_commit_supplied_by_caller"], "Request commit identity differs")
    # A prior attempt, including a failed extraction, is never silently renewed.
    root.mkdir(mode=0o700, exist_ok=False)
    started = time.perf_counter()
    receipt = {"schema": "ndu.real.candidate-bootstrap.v1", "status": "Failed", "source_commit": request["source_commit"], "archive": SPEC["archive"], "request_sha256": SPEC["request_sha256"], "source_file_count": len(files), "source_projection_verified": True, "retry_of": None, "scientific_acceptance": "HOLD"}
    try:
        source.mkdir(mode=0o700)
        for name, data in sorted(files.items()):
            path = source / name
            path.parent.mkdir(parents=True, exist_ok=True)
            write_once(path, data)
            path.chmod(0o644)
        write_once(root / "request.json", request_raw)
        overrides = {"PYTHONPATH": os.pathsep.join((str(source / "scripts"), str(source), request["config"]["pillow_path"])), "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1"}
        command = [request["config"]["python"], "-m", "ndu_real_runtime.run_candidate_retention", "--request", str(root / "request.json"), "--output", str(root / "run-001")]
        receipt.update(command=command, environment_overrides=overrides)
        print(json.dumps({"event": "candidate_campaign_start", "source_commit": request["source_commit"], "run": str(root / "run-001"), "request_sha256": SPEC["request_sha256"]}), flush=True)
        with (root / "runner-console.log").open("xb") as log:
            result = subprocess.run(command, cwd=source, env={**os.environ, **overrides}, stdout=log, stderr=subprocess.STDOUT, check=False)
        receipt.update(returncode=result.returncode, status="Completed" if result.returncode == 0 else "Failed")
    except Exception as error:
        receipt["error"] = {"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()}
    receipt["wall_seconds"] = time.perf_counter() - started
    write_once(root / "BOOTSTRAP_RECEIPT.json", json_bytes(receipt))
    print(json.dumps({"event": "candidate_campaign_exit", "status": receipt["status"], "returncode": receipt.get("returncode"), "receipt": str(root / "BOOTSTRAP_RECEIPT.json")}), flush=True)
    return 0 if receipt["status"] == "Completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
