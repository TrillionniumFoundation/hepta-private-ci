Candidate campaign payload builder
==================================

These local preparation scripts do not modify the repository, fetch code,
submit remote jobs, train weights, or execute an actor.

Build once into a NEW directory after root has verified the published source
projection. The final published commit is an explicit caller-supplied identity;
the builder does not query Git. Every actual source byte is independently pinned.

python /workspace/scratch/a6b21bc72124/candidate-launch/build.py \
  --repository /workspace/scratch/a6b21bc72124/hepta-private-ci \
  --template /workspace/scratch/a6b21bc72124/candidate-request-template.json \
  --source-commit cce6a7d3222a7eaffe2ec3890e624820a2ec8023 \
  --output /workspace/scratch/a6b21bc72124/candidate-launch/release-cce6a7d3

Generated artifacts:

- source.tar.gz: only top-level non-test Python files from the two runtime and
  material packages, hepta_core.py, and finite_entropic_golden.json. No private
  material, references, qualification files, labels, weights, or dependencies.
- request.json: reviewed template with only source_commit and source_pins set.
- bootstrap.py: standalone frozen launcher, with archive and request digests.
- submission_command.txt: complete shell-quoted command for the same launcher.
- BUILD_MANIFEST.json: exact source and artifact digests and byte counts.

Root's remote steps (not performed by this builder):

1. Transfer source.tar.gz using h_binary_write to the exact path
   /home/qq/mem-candidate-20261109-a6b21bc7-source.tar.gz.
2. Verify its digest and byte count against BUILD_MANIFEST.json.
3. Submit the exact contents of submission_command.txt under the original
   stable job idempotency_key. Preserve that original job for all subsequent
   status checks. Do not change seed/path or create replacement attempts.

Bootstrap validates compressed bytes, bounded expansion, exact inventory,
canonical safe relative names, regular-only USTAR members, and every source
file's original digest before creating the fixed destination. It refuses an
existing campaign root. It never uses tarfile.extract/extractall.

Fixed destinations:
  /home/qq/mem-candidate-retention-20261109-a6b21bc7/source
  /home/qq/mem-candidate-retention-20261109-a6b21bc7/request.json
  /home/qq/mem-candidate-retention-20261109-a6b21bc7/run-001
  /home/qq/mem-candidate-retention-20261109-a6b21bc7/runner-console.log
  /home/qq/mem-candidate-retention-20261109-a6b21bc7/BOOTSTRAP_RECEIPT.json

Launch environment overrides:
  PYTHONPATH=source/scripts:source:<the pinned config pillow_path>
  OMP_NUM_THREADS=1
  MKL_NUM_THREADS=1
  OPENBLAS_NUM_THREADS=1

No fallback environment, package installation, source rewriting, retry,
resampling, or new training is implemented. An interrupted or failed original
job keeps its original evidence and directory. The experiment remains one
existing checkpoint, zero new independent training repeats, and HOLD.
