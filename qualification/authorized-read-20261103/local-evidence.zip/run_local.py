#!/usr/bin/env python3
"""Retain original local commands, input identities and prerequisite failures."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
REPO = ROOT / "private-ci-authorized-read-work-20261103"
name, *command = sys.argv[1:]
if not command or "/" in name:
    raise ValueError("expected a simple evidence label and an original command")
env = os.environ.copy()
native = ROOT / "private-ci-v8-allocator-qualification-20261103/native-tools"
env["PATH"] = ":".join(str(ROOT / p) for p in ["matrix-toolchain-1.96.0-20261103/bin", "recovered-tools-20261103/bin"]) + ":" + str(native) + ":" + env["PATH"]
env["LD_LIBRARY_PATH"] = str(native) + (":" + env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else "")
env["CARGO_HOME"] = str(ROOT / "private-ci-dependency-union-cargo-home-20261103")
env["CARGO_TARGET_DIR"] = str(OUT / "target")
env.update(CARGO_BUILD_JOBS="2", CARGO_INCREMENTAL="0", CARGO_PROFILE_DEV_DEBUG="0", CARGO_PROFILE_TEST_DEBUG="0")
paths = ["codex-rs/exec-server/src/local_file_system.rs", "codex-rs/exec-server/tests/authorized_read_rpc.rs", "codex-rs/Cargo.lock", "codex-rs/Cargo.toml", "MODULE.bazel.lock"]
def snapshot():
    return {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
started = time.monotonic()
log = OUT / (name + ".log")
if log.exists():
    raise RuntimeError("refusing to overwrite an original command record")
with log.open("wb") as stream:
    result = subprocess.run(command, cwd=REPO / "codex-rs", env=env, stdout=stream, stderr=subprocess.STDOUT)
after = snapshot()
receipt = {"command": command, "exit": result.returncode, "elapsed_seconds": time.monotonic() - started,
           "source_before": before, "source_after": after, "unchanged": before == after,
           "log_bytes": log.stat().st_size, "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest()}
(OUT / (name + ".json")).write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({k: v for k, v in receipt.items() if k not in {"source_before", "source_after"}}, indent=2))
print(log.read_text(errors="replace")[-2500:])
sys.exit(result.returncode)
