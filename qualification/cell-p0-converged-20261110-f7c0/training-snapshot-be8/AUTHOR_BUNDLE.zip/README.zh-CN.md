# Original Training snapshot readback

固定组件 `8ad9f24e238b0680f975fea8c9d26db146066a8c`，tree `eaa8b27f16a5f9fed87e9d6882cd23dfaecfd125`，直接基于 published `30a697c50e10abd56e61b6b84f28ac9ae9f32f5d`。

新增 74 行生产模块只做完整 snapshot 的 Training 读回：先用原 Coordinator 校验完整结构及 head，再按原 observed time 得到 exact Dataset prefix，最后通过原 typed stage 的同一 lane 验证 native CURRENT、原 Generator journal/signature，并将 retained、expected、actual receipt 全等比较。Candidate 与 TrainingNoUpdateV2 均适用；Dataset-only 仅可读已有完成结果。

验证：just fmt、git diff HEAD --check、9 项 source closure 测试及 224 boundaries / 224 inventory / 219 protected files 检查全部通过。原 6 项 stage testcase 源、stage 主体、native/receipt owners 与 caller verifier 逐 blob 不变。新增 5 项 Rust 行为测试仅编写，未执行/编译；本地 native 与 just fix 因明确资源约束未启动，等待同源 CI。完整新树 caller 扫描未运行，不转用 base30a 的 PASS。

首轮 source-wrapper index.lock preflight 失败（0 个测试）及 protected exact-function-marker 失败均保留。后者通过将新函数签名改为 argument-position impl Trait 适配既有检查器，未放宽检查器；之后顺序检查通过。

这里不提供 Root CURRENT custody、其他阶段认证、生产 StageOwner 装配、Dataset feature/target 语义、Model proposal 协议或真实 B/C。新增 API 自身 product caller 仍为空。实际普通 Adopt 0、NoUpdate 0，所有 authority 为 false。新测试的后续完整历史是明确结构 fixture，不能作为独立任务或全进程冷恢复证据。

COMPONENT.json 给接口、门禁状态、5 项新测试和 6 项既有测试及 CI filter；SOURCE_BLOBS.json、SOURCE_COMPATIBILITY.json 与 component.patch 给精确源和原实现不变依据。所有先前原始日志保留；MANIFEST.json 逐项绑定证据文件。
