import hashlib
import json
from pathlib import Path
import resource
import subprocess
import sys
import time
from datetime import datetime, timezone

root = Path('/tmp/hepta-p0-training-snapshot-f7c0')
evidence = Path(__file__).parent
name = sys.argv[1]
argv = sys.argv[2:]
before = subprocess.check_output(['git', 'write-tree'], cwd=root, text=True).strip()
start = datetime.now(timezone.utc).isoformat()
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
clock = time.monotonic()
with (evidence / (name + '.log')).open('wb') as output:
    result = subprocess.run(argv, cwd=root, stdout=output, stderr=subprocess.STDOUT)
elapsed = time.monotonic() - clock
finish = datetime.now(timezone.utc).isoformat()
end_usage = resource.getrusage(resource.RUSAGE_CHILDREN)
after = subprocess.check_output(['git', 'write-tree'], cwd=root, text=True).strip()
dirty = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True)
log = (evidence / (name + '.log')).read_bytes()
record = {'argv': argv, 'cwd': str(root), 'base': '30a697c50e10abd56e61b6b84f28ac9ae9f32f5d', 'source_tree_before': before, 'source_tree_after': after, 'source_unchanged': before == after and not dirty, 'started_at_utc': start, 'ended_at_utc': finish, 'exit_code': result.returncode, 'costs': {'wall_seconds': elapsed, 'child_user_cpu_seconds': end_usage.ru_utime - usage.ru_utime, 'child_system_cpu_seconds': end_usage.ru_stime - usage.ru_stime}, 'log': {'path': str(evidence / (name + '.log')), 'bytes': len(log), 'sha256': hashlib.sha256(log).hexdigest()}, 'native_build_or_test': False, 'full_caller_scan': False}
(evidence / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
print(log.decode())
sys.exit(result.returncode)
