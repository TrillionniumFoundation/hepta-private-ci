import importlib.util
import json
from pathlib import Path
import sys
import tomllib

root = Path('/tmp/hepta-p0-training-snapshot-f7c0')
spec = importlib.util.spec_from_file_location('training_snapshot_inventory', root / 'scripts/verify_hepta_callers.py')
proof = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = proof
spec.loader.exec_module(proof)
data = tomllib.loads((root / 'CALLERS.toml').read_text())
boundaries = proof._boundary_rows(data)
inventory = proof._verify_privileged_inventory(data, boundaries)
protected = proof._verify_protected_files(root, data)
assert all(value is False for value in data['authority'].values())
print(json.dumps({'status': 'PASS', 'boundaries': len(boundaries), 'protected_files': len(protected), 'inventory': inventory, 'authority': data['authority'], 'full_caller_scan': False}))
