# Terminal local evidence, version 1

This bundle freezes completed local build attempts and a reproduction using the unchanged production output-combining helper.

- RMCP runtime test cases observed: **0**. Attempts ended before test execution: missing CMake, missing `stddef.h`, and `codex-protocol` compiler SIGKILL respectively.
- The SIGKILL cause remains **unknown**. There is no kernel evidence attributing it to memory pressure.
- Attempts 2 and 3 have complete raw logs. Attempt 1 has only a clearly labeled truncated tool excerpt; its missing full raw log is an evidence gap.
- The legacy production helper reproduced loss of 256 of 513 chunks. Its source, probe source, lockfile and complete raw log are bound in `metadata.json`.
- Core output-owner tests and the two original git-attribution / Matrix failures remain pending. The diagnostic-only commit is not counted as a repair pass.
- The local checkout is based on `0c99a30`; it is component verification, with no full-candidate source-head admission for the published candidate.

The `null` cost fields are unknown measurements. Cargo's 58.38-second probe build duration is the one retained tool-reported duration, and excludes an unmeasured probe runtime.

`SHA256SUMS` binds every payload file. Recreate the probe against the specified source checkout; its Cargo path dependency is recorded exactly in the included manifest.
