# Terminal local core compiler evidence

The core unit selection ended with exit 101 before test execution. The vendored `starlark` library compiler was terminated by signal 9 (SIGKILL). The reason remains unknown; this is not evidence of an out-of-memory event or of a source/type error.

Execution source: local `5d7f18b06a1830b68ae1adf8155587e7cfd69aa0`, tree `57e744aac7572e7b962c53afc0da11c0389969ea`. The published common candidate is recorded only as a parent-reported reference and was not the source compiled here. Runtime cases observed: **0**.

The raw stdout/stderr log is complete. Whole-invocation costs were not measured and remain null. No new native jobs or retries were started after this terminal result. The two original git-attribution / Matrix failures and scoped core Clippy remain unverified.
