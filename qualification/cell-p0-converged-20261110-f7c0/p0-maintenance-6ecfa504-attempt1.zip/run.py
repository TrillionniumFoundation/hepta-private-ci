"""One measured, source-pinned scoped Clippy attempt; never starts tests or retries."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import tempfile
import time


ROOT = Path('/workspace/scratch/f7c0ded86bcc')
REPO = ROOT / 'hepta-p0-maintenance-6ecfa504'
TARGET = ROOT / 'maintenance-6ecfa504-target'
ATTEMPT = Path(__file__).resolve().parent
SOURCE = '6ecfa504d2132f3682ffb01f8c9d65346b26cf5b'
TREE = '9184583f3842d90a560436f279c753f15792e3ab'
COMMAND = ['just', 'fix', '-p', 'codex-core', '-p', 'codex-hepta-agentd', '-p', 'codex-rmcp-client', '--locked']
PATH_PREFIX = ':'.join([
    str(ROOT / 'rmcp-tools/cmake/data/bin'),
    str(ROOT / 'toolchain/installed/bin'),
    '/workspace/scratch/1f3ba4601505/tools/just-1.51.0',
])
ENV_OVERRIDES = {
    'CARGO_TARGET_DIR': str(TARGET),
    'CARGO_BUILD_JOBS': '1',
    'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_INCREMENTAL': '0',
    'BINDGEN_EXTRA_CLANG_ARGS': '-isystem /usr/lib/gcc/x86_64-linux-gnu/14/include',
}
ENV = dict(os.environ)
ENV.update(ENV_OVERRIDES)
ENV['PATH'] = PATH_PREFIX + ':' + ENV.get('PATH', '')


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc_now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args, env=None):
    return subprocess.check_output(
        ['git', '-C', str(REPO), *args], env=env, text=True
    ).strip()


def source_snapshot(include_working_tree=False):
    result = {
        'head': git('rev-parse', 'HEAD'),
        'head_tree': git('rev-parse', 'HEAD^{tree}'),
        'status_porcelain': subprocess.check_output(
            ['git', '-C', str(REPO), 'status', '--porcelain=v1', '--untracked-files=all'],
            text=True,
        ).rstrip('\n'),
    }
    result['clean'] = not result['status_porcelain']
    if not include_working_tree:
        return result
    changed = subprocess.check_output(
        ['git', '-C', str(REPO), 'diff', '--name-only', '-z', 'HEAD']
    ).decode().split('\0')
    untracked = subprocess.check_output(
        ['git', '-C', str(REPO), 'ls-files', '--others', '--exclude-standard', '-z']
    ).decode().split('\0')
    changed = sorted(set(path for path in changed + untracked if path))
    result['changed_files'] = {
        name: {'sha256': sha256(REPO / name), 'bytes': (REPO / name).stat().st_size}
        if (REPO / name).is_file() else {'sha256': None, 'bytes': None}
        for name in changed
    }
    if not changed:
        result['working_tree_tree'] = result['head_tree']
    else:
        # Compute a content tree using a private index; leave the real index alone.
        with tempfile.TemporaryDirectory(prefix='end-index-', dir=ATTEMPT) as directory:
            index = Path(git('rev-parse', '--git-path', 'index'))
            if not index.is_absolute():
                index = REPO / index
            private_index = Path(directory) / 'index'
            shutil.copyfile(index, private_index)
            index_env = dict(ENV, GIT_INDEX_FILE=str(private_index))
            subprocess.run(
                ['git', '-C', str(REPO), 'add', '-A', '--', *changed],
                env=index_env, check=True, stdout=subprocess.DEVNULL,
            )
            result['working_tree_tree'] = git('write-tree', env=index_env)
    return result


def resource_snapshot():
    roots = [Path('/sys/fs/cgroup')]
    memberships = []
    mounts = []
    try:
        for line in Path('/proc/self/cgroup').read_text().splitlines():
            _, controllers, location = line.split(':', 2)
            if not controllers:
                memberships.append(location)
        for line in Path('/proc/self/mountinfo').read_text().splitlines():
            before, after = line.split(' - ', 1)
            parts, suffix = before.split(), after.split()
            if suffix[0] == 'cgroup2':
                mounts.append((parts[3], parts[4]))
    except (OSError, ValueError, IndexError):
        pass
    for mount_root, mountpoint in mounts:
        roots.append(Path(mountpoint))
        for location in memberships:
            relative = os.path.relpath(location, mount_root)
            if not relative.startswith('..'):
                roots.append(Path(mountpoint) / relative)

    def read(name):
        for root in dict.fromkeys(roots):
            try:
                return (root / name).read_text().strip()
            except OSError:
                pass
        return None

    def number(value):
        if value is None:
            return None
        if value == 'max':
            return -1
        try:
            return int(value)
        except ValueError:
            return None

    result = {'observed_at_utc': utc_now(), 'cgroup_v2_mount_count': len(mounts)}
    for name in ['memory.max', 'memory.current', 'memory.peak', 'memory.swap.max', 'memory.swap.current', 'pids.max', 'pids.current', 'pids.peak']:
        result[name] = number(read(name))
    for name in ['memory.events', 'memory.events.local', 'cpu.stat', 'pids.events']:
        raw = read(name)
        result[name] = None if raw is None else {
            line.split()[0]: int(line.split()[1]) for line in raw.splitlines()
        }
    cpu_max = read('cpu.max')
    result['cpu.max_quota_us'] = number(cpu_max.split()[0]) if cpu_max else None
    result['cpu.max_period_us'] = number(cpu_max.split()[1]) if cpu_max else None
    result['proc_meminfo'] = {}
    try:
        for line in Path('/proc/meminfo').read_text().splitlines():
            key, value = line.split(':', 1)
            if key in {'MemTotal', 'MemAvailable', 'MemFree', 'SwapTotal', 'SwapFree'}:
                result['proc_meminfo'][key + '_bytes'] = int(value.split()[0]) * 1024
    except (OSError, ValueError):
        pass
    result['cpu_affinity_count'] = len(os.sched_getaffinity(0))
    result['load_average'] = list(os.getloadavg())
    result['rlimit_nproc'] = list(resource.getrlimit(resource.RLIMIT_NPROC))
    result['rlimit_as'] = list(resource.getrlimit(resource.RLIMIT_AS))
    result['rlimit_cpu_seconds'] = list(resource.getrlimit(resource.RLIMIT_CPU))
    result['rlimit_nofile'] = list(resource.getrlimit(resource.RLIMIT_NOFILE))
    disk = shutil.disk_usage(ROOT)
    result['disk'] = {'total_bytes': disk.total, 'used_bytes': disk.used, 'free_bytes': disk.free}
    result['visibility_note'] = 'Absent cgroup values are unknown; /proc values are not proof of a container hard limit.'
    return result


metadata_path = ATTEMPT / 'metadata.json'
log = ATTEMPT / 'just-fix.log'
assert not metadata_path.exists() and not log.exists(), 'Never overwrite or replay an attempt'
assert not TARGET.exists(), 'The controlled attempt requires a new independent target'
source_before = source_snapshot()
assert source_before['head'] == SOURCE and source_before['head_tree'] == TREE
assert source_before['clean']
tools = {}
for name, args in {
    'rustc': ['--version', '--verbose'],
    'cargo': ['--version'],
    'cargo-clippy': ['--version'],
    'clippy-driver': ['--version'],
    'rustfmt': ['--version'],
    'just': ['--version'],
    'cmake': ['--version'],
    'python3': ['--version'],
}.items():
    binary = shutil.which(name, path=ENV['PATH'])
    assert binary is not None, name
    completed = subprocess.run([binary, *args], env=ENV, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
    tools[name] = {'executable': binary, 'version_output': completed.stdout.strip()}
manifest = ROOT / 'toolchain/manifest.json'
shutil.copyfile(manifest, ATTEMPT / 'toolchain-manifest.json')
metadata = {
    'schema_version': 1,
    'attempt': 'maintenance-6ecfa504-attempt1',
    'scope': 'One scoped just fix invocation; type/Clippy maintenance only, no runtime tests',
    'command': COMMAND,
    'cwd': str(REPO / 'codex-rs'),
    'environment_overrides': ENV_OVERRIDES,
    'PATH_prefix': PATH_PREFIX,
    'tools': tools,
    'toolchain_manifest_sha256': sha256(manifest),
    'runner_sha256': sha256(Path(__file__)),
    'source_before': source_before,
    'resources_before': resource_snapshot(),
    'status': 'RUNNING',
    'started_at_utc': utc_now(),
    'observed_runtime_test_cases': 0,
    'retry_count': 0,
}
metadata_path.write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps({'status': 'RUNNING', 'metadata': str(metadata_path), 'log': str(log), 'source': SOURCE}), flush=True)
usage_before = resource.getrusage(resource.RUSAGE_CHILDREN)
started = time.monotonic()
with log.open('xb') as output:
    completed = subprocess.run(COMMAND, cwd=REPO / 'codex-rs', env=ENV, stdout=output, stderr=subprocess.STDOUT, check=False)
elapsed = time.monotonic() - started
usage_after = resource.getrusage(resource.RUSAGE_CHILDREN)
resources_after = resource_snapshot()
source_after = source_snapshot(include_working_tree=True)
patch = ATTEMPT / 'clippy-changes.patch'
patch.write_bytes(subprocess.check_output(['git', '-C', str(REPO), 'diff', '--binary', 'HEAD']))
metadata.update({
    'status': 'EXITED',
    'finished_at_utc': utc_now(),
    'exit_code': completed.returncode,
    'resources_after': resources_after,
    'source_after': source_after,
    'raw_log': log.name,
    'raw_log_bytes': log.stat().st_size,
    'raw_log_sha256': sha256(log),
    'patch': patch.name,
    'patch_bytes': patch.stat().st_size,
    'patch_sha256': sha256(patch),
    'costs': {
        'wall_clock_seconds': elapsed,
        'cpu_user_seconds': usage_after.ru_utime - usage_before.ru_utime,
        'cpu_system_seconds': usage_after.ru_stime - usage_before.ru_stime,
        'rusage_children_maxrss_bytes': usage_after.ru_maxrss * 1024,
        'rss_scope_note': 'Linux RUSAGE_CHILDREN maximum resident set, not summed concurrent process-tree peak. Tool-version preflight children are also included in this maximum.',
        'ru_inblock': usage_after.ru_inblock - usage_before.ru_inblock,
        'ru_oublock': usage_after.ru_oublock - usage_before.ru_oublock,
        'network_bytes': None,
        'energy_joules': None,
        'monetary_cost': None,
    },
    'source_head_admission_note': 'If Clippy changed any source, this is maintenance evidence for the recorded transition, not proof that the original unchanged source passed.',
    'termination_reason': None,
})
metadata_path.write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps({'status': 'EXITED', 'exit_code': completed.returncode, 'metadata': str(metadata_path), 'wall_clock_seconds': elapsed, 'source_clean_after': source_after['clean'], 'working_tree_tree_after': source_after['working_tree_tree'], 'patch_bytes': patch.stat().st_size}), flush=True)
raise SystemExit(completed.returncode)
