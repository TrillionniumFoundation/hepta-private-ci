import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time

repo = Path('/tmp/hepta-p0-lock-03f4-f7c0')
root = Path('/tmp/hepta-p0-bazel-lock-f7c0')
evidence = Path('/tmp/hepta-p0-lock-03f4-evidence-f7c0/attempt-2-explicit-jvm-ca')
manifest_path = evidence / 'ATTEMPT.json'
manifest = json.loads(manifest_path.read_text())
env = os.environ.copy()
env['PATH'] = ':'.join([
    str(root / 'bin'),
    '/workspace/scratch/f7c0ded86bcc/toolchain/installed/bin',
    '/workspace/scratch/1f3ba4601505/tools/just-1.51.0',
    env['PATH'],
])
env.update({
    'BAZEL_OUTPUT_USER_ROOT': str(root / 'output-user-root'),
    'BAZEL_REPOSITORY_CACHE': str(root / 'repository-cache'),
    'BAZEL_REPO_CONTENTS_CACHE': str(root / 'repo-contents-cache'),
    'TMPDIR': str(root / 'tmp'),
    'CODEX_BAZEL_BIN': str(evidence / 'bazel-with-system-ca'),
})
for name in ['BAZEL_OUTPUT_USER_ROOT', 'BAZEL_REPOSITORY_CACHE', 'BAZEL_REPO_CONTENTS_CACHE', 'TMPDIR']:
    Path(env[name]).mkdir(exist_ok=True)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo).decode().strip()


def free(path):
    stat = os.statvfs(path)
    return stat.f_bavail * stat.f_frsize


def write_manifest():
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')


assert git('rev-parse', 'HEAD') == manifest['source']
assert not git('status', '--porcelain')
spec = importlib.util.spec_from_file_location('repo_bazel_wrapper', repo / '.github/scripts/run_bazel_with_buildbuddy.py')
wrapper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wrapper)
actual_command = wrapper.bazel_command('mod', 'deps', '--lockfile_mode=error', env=env)
actual_command = [value if not value.startswith('--remote_header=') else '--remote_header=<redacted>' for value in actual_command]
command = ['just', 'bazel-lock-check']
log_path = evidence / 'bazel-lock-check.log'
started = time.monotonic()
attempt = {
    'command': command,
    'wrapper_generated_argv': actual_command,
    'cwd': str(repo),
    'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'environment_overrides': {key: env[key] for key in ['PATH', 'BAZEL_OUTPUT_USER_ROOT', 'BAZEL_REPOSITORY_CACHE', 'BAZEL_REPO_CONTENTS_CACHE', 'TMPDIR', 'CODEX_BAZEL_BIN']},
    'log': str(log_path),
    'maximum_wall_seconds': 600,
    'minimum_tmp_free_bytes': 536870912,
    'space_policy': 'Only the writable tmp filesystem is a gate; source Git alternates are read-only on workspace.',
    'state': 'running',
}
manifest['lock_check'] = attempt
write_manifest()
print(json.dumps({'started': attempt['started_at'], 'command': command, 'raw_log': str(log_path)}), flush=True)
last_progress = 0
stop_reason = None
with log_path.open('wb') as output:
    process = subprocess.Popen(command, cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    while process.poll() is None:
        elapsed = time.monotonic() - started
        tmp_free = free(root)
        if elapsed - last_progress >= 30:
            print(json.dumps({'elapsed_seconds': round(elapsed, 2), 'tmp_free_bytes': tmp_free, 'raw_log_bytes': log_path.stat().st_size}), flush=True)
            last_progress = elapsed
        if elapsed >= 600 or tmp_free < 536870912:
            stop_reason = 'wall_time_budget' if elapsed >= 600 else 'low_free_space'
            os.killpg(process.pid, signal.SIGINT)
            break
        time.sleep(1)
    exit_code = process.wait()
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
attempt.update({
    'state': 'completed',
    'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exit_code': exit_code,
    'wall_seconds': time.monotonic() - started,
    'controlled_stop_reason': stop_reason,
    'direct_children_user_seconds': usage.ru_utime,
    'direct_children_system_seconds': usage.ru_stime,
    'direct_children_max_rss_kib': usage.ru_maxrss,
    'cost_boundary': 'Child resource usage includes git prechecks and command client subprocesses; detached Bazel server cost is not included and remains unmeasured.',
    'log_bytes': log_path.stat().st_size,
    'log_sha256': hashlib.sha256(log_path.read_bytes()).hexdigest(),
})
manifest['lock_after_check'] = {
    'sha256': hashlib.sha256((repo / 'MODULE.bazel.lock').read_bytes()).hexdigest(),
    'bytes': (repo / 'MODULE.bazel.lock').stat().st_size,
}
manifest['source_after_check'] = git('rev-parse', 'HEAD')
manifest['status_after_check'] = git('status', '--porcelain')
manifest['space_after_check'] = {'tmp_free_bytes': free(root)}
write_manifest()
print(json.dumps(attempt, indent=2), flush=True)
print(log_path.read_text(errors='replace')[-12000:], flush=True)
raise SystemExit(exit_code)
