use tokio::sync::{broadcast, mpsc};

#[tokio::main(flavor = "current_thread")]
async fn main() {
    let (stdout_tx, stdout_rx) = mpsc::channel(1);
    let (stderr_tx, stderr_rx) = mpsc::channel(1);
    // Use the actual unchanged production helper used by the common candidate.
    let mut combined = codex_utils_pty::combine_output_receivers(stdout_rx, stderr_rx);
    drop(stderr_tx);
    let sent_chunks = 513;
    let bytes_per_chunk = 4096;
    for _ in 0..sent_chunks {
        stdout_tx.send(vec![b'x'; bytes_per_chunk]).await.unwrap();
    }
    drop(stdout_tx);
    let mut received_chunks = 0;
    let mut received_bytes = 0;
    let mut lost_chunks = 0;
    loop {
        match combined.recv().await {
            Ok(chunk) => {
                received_chunks += 1;
                received_bytes += chunk.len();
            }
            Err(broadcast::error::RecvError::Lagged(count)) => lost_chunks += count,
            Err(broadcast::error::RecvError::Closed) => break,
        }
    }
    assert!(lost_chunks > 0, "the delayed receiver must actually saturate");
    assert_eq!(received_chunks + lost_chunks, sent_chunks);
    assert!(received_bytes < sent_chunks as usize * bytes_per_chunk);
    println!(
        "source_sha=0c99a30dbe9307d48aa50ffc63404235ade8ae9c helper=codex_utils_pty::combine_output_receivers sent_chunks={sent_chunks} received_chunks={received_chunks} lost_chunks={lost_chunks} received_bytes={received_bytes}"
    );
}
