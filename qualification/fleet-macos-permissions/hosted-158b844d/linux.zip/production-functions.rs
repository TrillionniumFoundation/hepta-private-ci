fn copy_immutable_program(source: &Path, destination: &Path) -> Result<(), FleetRegistryError> {
    let mut input = File::open(source)?;
    let mut output = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(destination)?;
    std::io::copy(&mut input, &mut output)?;
    set_mode(destination, /*mode*/ 0o555)?;
    // Flush through the writing handle retained across the mode change.
    // Windows cannot FlushFileBuffers on a separately opened read-only handle.
    output.sync_all()?;
    Ok(())
}

fn set_mode(path: &Path, mode: u32) -> Result<(), FleetRegistryError> {
    use std::os::unix::fs::PermissionsExt;
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(mode))?;
    Ok(())
}

fn sync_directory(path: &Path) -> Result<(), FleetRegistryError> {
    File::open(path)?.sync_all()?;
    Ok(())
}

fn publish_release_directory(staging: &Path, final_root: &Path) -> Result<(), FleetRegistryError> {
    #[cfg(target_os = "macos")]
    {
        use std::os::unix::fs::PermissionsExt;

        // Darwin requires write permission on the moved directory, even for a
        // same-parent rename. Keep the 0700 directory private until it is moved,
        // then seal and flush that exact inode through the retained handle.
        // Catalog admission rejects a writable root if publication is interrupted.
        let directory = File::open(staging)?;
        std::fs::rename(staging, final_root)?;
        directory.set_permissions(std::fs::Permissions::from_mode(0o555))?;
        directory.sync_all()?;
    }
    #[cfg(not(target_os = "macos"))]
    {
        set_mode(staging, /*mode*/ 0o555)?;
        std::fs::rename(staging, final_root)?;
    }
    Ok(())
}
