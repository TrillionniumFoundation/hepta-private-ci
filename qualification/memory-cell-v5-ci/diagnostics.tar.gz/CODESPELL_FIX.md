# Codespell 最小修复交付

基线仓库为 `TrillionniumFoundation/hepta-private-ci`，PR head 为 `332d8156d081e22405450dd607023689f68f03e1`。实际失败来自 run `40470653139` 的 job `122077013125`，其工作流运行于 PR merge revision `bbe36d7c618860cd06da120469c15547aaca4a94`。两个身份分别记录，未将 merge revision 当作 head。

## 只应用两个配置文件

1. `.codespellignore`：保留原有内容，追加 `nd`、`regraded`、`trough` 三个有效词。
2. `.github/workflows/codespell.yml`：保留 `./.git`，在 Action 的 `with.skip` 中明确列出五个实际报错的 gzip 分片及一个 gzip+base64 JSON 容器。所有路径为精确匹配，没有新增通配符。

原 Git blob、拟应用内容的 Git blob / SHA-256 / bytes、完整路径及证据清单见 [CODESPELL_FIX.json](CODESPELL_FIX.json)；可审查的两文件差异见 [codespell.patch](codespell.patch)。本目录其余文件为诊断证据，不是这次应应用的仓库文件。原始日志保留了错误词，不应作为可读仓库正文一并提交。

## 实际 219 项失败的构成

| 原因 | 数量 | 处理 |
| --- | ---: | --- |
| gzip 分片被当作文本扫描 | 209 | 精确跳过 5 个分片 |
| 同一个 gzip+base64 JSON 容器的随机字符命中 | 4 | 精确跳过该容器 |
| 有效用词 | 6 | 忽略 3 个合法词 |

五个分片分别产生 46、47、38、43、35 条诊断，详见 [findings.json](evidence/codespell/findings.json)。`trough` 是 peak-minus-trough 的下极值；`regraded` 描述历史结果重新评分，共 4 处；`nd` 是 `np.einsum("nr,nrd->nd", ...)` 的输出维度标记。没有改写任何冻结源码、训练语料、结果或历史报告。

## 为何改 workflow，而非 `.codespellrc`

实际安装版本是 Codespell 2.4.3，Action 固定于 `8f01853be192eb0f849a5c7d721450e7a467c579`。该 Action 的默认 `skip` 为 `./.git`，入口脚本明确拼成 `--skip ./.git`，因此覆盖 `.codespellrc` 的 skip 设置。只修改 `.codespellrc` 无法修复本次实际命令。新增 skip 是没有空格的单个逗号分隔值，避免入口脚本未引用的参数展开把它拆成多个参数。

未改 Codespell、Checkout 或 matcher 的固定 Action 版本；未开 only-warn；未改 `blocking-ci.yml` 或 required fan-in；保留其余可读源码和报告的扫描范围。

## 验证边界

已逐字节验证两份基线配置及五份参考文件的 Git blob，核对单一 skip 参数的 shell 分词，并对完整日志的全部 219 条错误进行独立分类：213 条由精确载荷路径排除，6 条由合法词条处理，未覆盖项为 0。完整日志保留在 [job-122077013125.log](evidence/codespell/job-122077013125.log)。

这些是静态检查，尚未宣称 Codespell 或整个 blocking CI 已通过。本地没有 codespell_lib；由 root 应用两文件后在托管环境运行相同固定 Action 的实际检查。未推送远端，也未修改原研究工作区。
