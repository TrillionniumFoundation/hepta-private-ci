# Complete workflow path validation

## Observed failure

Blocking CI run `40470653139`, contract job `122077331672`, failed against PR head `332d8156d081e22405450dd607023689f68f03e1`. Its document verifier interpreted the suffix `.github/workflows/ci.yml` of `codex-rs/third_party/imbl-6.1.0/.github/workflows/ci.yml` as a workflow at the repository root. The complete nested path exists at that head; its Git blob is `90a8a881853795bad1c6db2533d7d04d9964590d`.

The reference occurs in frozen `qualification/memory-cell-v2/sources/github-history.json:389`. That historical file remains unchanged.

## Change

The proposed change resolves a canonical repository-relative prefix before a matched workflow path. It checks the resulting complete file identity. Existing checks for root workflow paths, URLs, and dot-relative links remain active. The scan roots and mandatory production scripts remain unchanged. No historical evidence allowlist or directory exclusion is added.

This also closes the converse error: a missing nested workflow can no longer pass because an unrelated workflow of the same basename exists at the root.

Only `scripts/hepta-docs.py` and the new `scripts/test_hepta_workflow_references.py` are intended changes. Other script copies in this staging directory are unchanged import/test dependencies. `original/hepta-docs.py` is the original source; its Git blob was independently recomputed as `0d65aa4dee439e58ef124d99f4d422affdfae82f`.

## Validation and boundaries

- Seven new filesystem-based behavior tests passed, including missing nested identities, mixed references, all existing scan scopes, and retained URL/dot-relative checks.
- Two existing root-workflow tests passed.
- The two new nested-identity cases both failed against the original verifier, as expected: one false rejection and one false acceptance.
- The first invocation of the existing tests omitted the `scripts` import path and failed at import time. Its raw log remains in `evidence/workflow-reference/existing-root-tests.log`; the correctly scoped invocation is recorded separately.

Commands, exits, and log hashes are in `evidence/workflow-reference/test-results.json` and `test-results-followup.json`. Source hashes and the patch identity are in `WORKFLOW_REFERENCE_FIX.json`. The two-file patch is `workflow-reference.patch`.

The staging directory is not a full repository checkout. The complete `verify --profile development` and final formatting remain for the root agent's exact-commit hosted validation. No research source, protocol, frozen data, remote reference, or CI rerun was modified by this work.
