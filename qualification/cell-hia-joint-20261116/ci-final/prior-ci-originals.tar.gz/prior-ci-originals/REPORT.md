# Final c277 CI and generated runtime ledger repair

Snapshot: **2026-11-16 04:06:26 UTC**. This directory contains original GitHub run/job JSON and complete runtime failure logs, plus the separately authorized generated-ledger repair and its original command records. The cloud workspace disappeared during the task; these files were restored from retained tool results and exact private Mac originals. They were not reconstructed from test summaries.

## CI results

| Gate | Observed result |
| --- | --- |
| [Joint candidate run 43800566412](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43800566412), head `c2774c6d1118dfd2745ac52b4069c8f254624c29` | **FAILURE**, job 133079561941, “Actual runtime entry and cold original-job observation” |
| [Runtime PR 132 run 43795217971](https://github.com/TrillionniumFoundation/hepta-runtime/actions/runs/43795217971), head `5f7f03a1f22905789371ce0e181a1a0f013beca9` | **FAILURE**, both prospective-merge and exact-head jobs fail “Frozen REA local mapping checks” |
| [HIA PR 902 run 43794923319](https://github.com/TrillionniumFoundation/Hepta/actions/runs/43794923319) | **SUCCESS**, source and native jobs both complete successfully |
| c277 v8-canary | **SUCCESS** |
| c277 Hepta stem Cell routes | **SUCCESS** |
| c277 blocking-ci | Still running |
| c277 Hepta architecture convergence | Still running |

The joint workflow's SSH fixture diagnosis belongs to the separate HIA agent. It is not attributed to the runtime ledger failure. These CI failures do not erase the separately retained actual Mac/ai395 candidate observations; neither do those observations make these CI runs pass.

## Concrete runtime failure

Both complete runtime logs end with:

```
{"inventory_check": "FAIL", "error": "stored ledger differs from current repository mapping/source projection"}
```

The exact-head job proves checkout of `5f7f03a`. It completed 2,633 Rust tests successfully (44 skipped), nine file-capability tests and 29 ledger tests before the separate `check-mapping` command exited 2. The prospective-merge job additionally completed 2,592 tests without remote filesystem support (32 skipped), then failed at the same inventory check. Its merge SHA was `43010635573091122197092b0b26f00c026e6dfb`; the source head remained `5f7f03a`.

The one-line macOS source repair removed a 28-byte Linux cfg annotation from `src/mcp/rea_evidence_file.rs`. The committed derived ledger still describes the old file:

| Field | Stored | Actual fixed source |
| --- | --- | --- |
| Bytes | 37,311 | 37,283 |
| SHA256 | `4a65fc7a8c8527b250d733374c9de21b05941ba270a93dcac390d186764dc6fc` | `3d9b563b88f3e215cb7c8ee5d762f6e76df097860d074f09a35e9ca7985f2a80` |

The original and fixed sources were compared at exact GitHub commits and independently hashed in the retained Mac checkouts. Their sole difference is the cfg deletion. This is a concrete source-derived inventory regression caused by the repair, not a runner issue or an unrelated failure.

## Authenticated generated repair

A new private directory was populated from the exact 5f Git archive: 5,306 tracked files. The frozen source checkout was left unchanged. Original GitHub artifact `13194916757.zip` was acquired and verified as 938,631 bytes with SHA256 `a76fa4ef0c88c6e02e5d199d442bca9912ffe38c65fb0e2206bb899876751488`. All 59 original upstream files at commit `93b8b82db70279e40f484114cff9dc1958dc14ee` were fetched and verified against the pinned sizes, SHA256 values and Git blob IDs.

The unchanged original CLI passed every requested step on Mac Python 3.14.3:

1. `restore` from the original pinned cache.
2. `generate` into the new source copy.
3. `check-mapping`.
4. All 29 existing ledger tests.
5. Full authenticated `check` against the same raw cache.

The authenticated commands report `VERIFIED_AGAINST_PINS`; the local-only `check-mapping` command correctly retains its narrower `NOT_REVERIFIED` semantics. The generated delta is exactly three scalars:

- `/runtime/source_files/189/bytes`: 37,311 to 37,283.
- `/runtime/source_files/189/sha256`: the old hash to the actual hash above.
- `/runtime/source_manifest_sha256`: `9e98a472a0af64178e3d5e5a9652c705d4ccfcb0e6d289498cbb7c4bbf10134d` to `0d049ab7b3df8332ac05f1f8aea68487e7166f1cb13eaaa0263350568982d00a`.

The whole copied tree changed only the derived ledger. Every tool qualification row, summary and behavior gate remains identical. All 229 operations remain OPEN. No handwritten qualification was added, and no gate was weakened.

## Exact objects delivered for root review

The generated ledger is 792,075 bytes, SHA256 `804bda258d2fc8acfb806f7751599fae25db8dae5431d61faed61ae8071a9cb5`, Git blob `6e37f9bf789c1ec95f07deca37d392d21af57333`. Its local copy is `ledger-review/REA_6_8_0_LEDGER.generated.json`.

`ledger-review/BLOB_HANDOFF.json` contains the exact 12 Git tree entries and all original record hashes. The same handoff is available as hepta-runtime Git blob `182854f9beb9733289e8dcbb1844839e776a7310`. The original `GENERATED_REVIEW.json` is blob `de694ee649d50f1f17ef5309ebb69ab14922f63c`, SHA256 `936b4c796188fd1ec6a57f2d5d052617a022b2428004d156e42542ccd9880cc6`.

The generated ledger and the 11 original review/stdout/stderr records were uploaded as blobs only. The agent did not create commits, update refs, rerun CI, rerun models or change the frozen candidate. Root owns the subsequent review and branch update.

The original Mac material remains under `/Users/qianqi/hepta-cell-joint-runtime-724fb6-v1/runtime-ledger-review-v1/`, including the authenticated cache. Empty stderr/stdout records are retained explicitly.
