import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time


root = pathlib.Path('/workspace/scratch/337c309bc660')
work = root / 'hepta-base-merge-recovered'
phase, recipe = sys.argv[1:]
assert recipe in {'bazel-lock-update', 'bazel-lock-check'}
assert phase.replace('-', '').isalnum()
out = root / 'dependency-recovery' / ('bazel-' + phase)
out.mkdir(exist_ok=False)
environment = dict(os.environ)
environment['PATH'] = str(root / 'shared-tools/bin') + ':/root/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:' + environment['PATH']
environment['CARGO_HOME'] = str(root / 'dependency-cache/cargo-home')
environment['XDG_CACHE_HOME'] = str(root / 'dependency-cache')
environment['CARGO_TERM_COLOR'] = 'never'
command = ['just', recipe]
inputs = [
    'MODULE.bazel',
    'MODULE.bazel.lock',
    '.bazelversion',
    '.bazelrc',
    'codex-rs/Cargo.toml',
    'codex-rs/Cargo.lock',
    'tools/argument-comment-lint/Cargo.toml',
    'tools/argument-comment-lint/Cargo.lock',
    'scripts/check-module-bazel-lock.sh',
    '.github/scripts/run_bazel_with_buildbuddy.py',
]


def source_hashes():
    return {path: hashlib.sha256((work / path).read_bytes()).hexdigest() for path in inputs}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=work, text=True).strip()


def expanded_crate_count():
    source = root / 'dependency-cache/cargo-home/registry/src'
    return sum(1 for registry in source.iterdir() if registry.is_dir() for package in registry.iterdir() if package.is_dir())


head = git('rev-parse', 'HEAD')
assert head == 'd58e440a336af4a74861e96e06a219b5f973a5cc', head
before = source_hashes()
assert before['codex-rs/Cargo.lock'] == '35d297d090267ae4ee4e536847ba6ed23cb764d613bb739651c5a7442b77e221'
module_before = (work / 'MODULE.bazel.lock').read_bytes()
(out / 'MODULE.bazel.lock.before').write_bytes(module_before)
receipt = {
    'phase': phase,
    'command': command,
    'cwd': str(work),
    'source_head': head,
    'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'status_before': git('status', '--porcelain=v1'),
    'source_hashes_before': before,
    'cargo_home': environment['CARGO_HOME'],
    'local_cache_config_sha256': hashlib.sha256((work / 'user.bazelrc').read_bytes()).hexdigest(),
    'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'running',
    'disk_free_before': shutil.disk_usage(root).free,
    'expanded_cargo_crates_before': expanded_crate_count(),
    'native_build_or_test_requested': False,
}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
start = time.monotonic()
minimum_free = receipt['disk_free_before']
log = out / 'bazel.log'
samples = out / 'disk-samples.jsonl'
with log.open('wb') as stream, samples.open('w') as observations:
    process = subprocess.Popen(command, cwd=work, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    while True:
        free = shutil.disk_usage(root).free
        minimum_free = min(minimum_free, free)
        observations.write(json.dumps({'elapsed_seconds': time.monotonic() - start, 'disk_free_bytes': free}) + '\n')
        observations.flush()
        code = process.poll()
        if code is not None:
            break
        time.sleep(1)
after = source_hashes()
module_after = (work / 'MODULE.bazel.lock').read_bytes()
(out / 'MODULE.bazel.lock.after').write_bytes(module_after)
unchanged_other_inputs = all(before[path] == after[path] for path in inputs if path != 'MODULE.bazel.lock')
receipt.update({
    'status': 'completed',
    'completed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'elapsed_seconds': time.monotonic() - start,
    'exit_code': code,
    'source_head_after': git('rev-parse', 'HEAD'),
    'status_after': git('status', '--porcelain=v1'),
    'source_hashes_after': after,
    'other_inputs_unchanged': unchanged_other_inputs,
    'module_lock_changed': module_before != module_after,
    'disk_free_after': shutil.disk_usage(root).free,
    'minimum_disk_free_observed': minimum_free,
    'expanded_cargo_crates_after': expanded_crate_count(),
    'log': str(log),
    'log_bytes': log.stat().st_size,
    'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
    'disk_samples_sha256': hashlib.sha256(samples.read_bytes()).hexdigest(),
})
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
print(log.read_text(errors='replace')[-9000:])
raise SystemExit(code if unchanged_other_inputs else 2)
