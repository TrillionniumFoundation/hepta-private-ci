print("namespace-setup-diagnostic-only")
