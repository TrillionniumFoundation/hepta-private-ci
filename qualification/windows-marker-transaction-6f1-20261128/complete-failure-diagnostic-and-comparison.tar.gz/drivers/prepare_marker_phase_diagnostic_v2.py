from pathlib import Path
import subprocess,os,json,hashlib,time
R=Path(__file__).resolve().parent;S=R/'source';Q=R/'qualification/marker-phase-diagnostic-v2';Q.mkdir(mode=0o700)
head=subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=S,text=True).strip()
assert head=='6f1e6717bd5f19b6c7a4c0b630251fbd013d8b70'
assert not subprocess.check_output(['/usr/bin/git','status','--porcelain'],cwd=S)
helper=S/'codex-rs/windows-sandbox-rs/src/bin/setup_main/win.rs'
caller=S/'codex-rs/windows-sandbox-rs/src/setup.rs'
for p in (helper,caller):(Q/(p.parent.name+'-'+p.name+'.original')).write_bytes(p.read_bytes())
text=helper.read_text()
needle='fn run_setup(payload: &Payload, log: &mut dyn Write, sbx_dir: &Path) -> Result<()> {'
insert='''fn trace_setup_marker(payload: &Payload, phase: &'static str) {
    if std::env::var("SBX_DEBUG").ok().as_deref() != Some("1") {
        return;
    }
    let directory = sandbox_dir(&payload.codex_home);
    let marker_len = std::fs::metadata(directory.join("setup_marker.json"))
        .ok()
        .map(|metadata| metadata.len());
    log_note(
        &format!(
            "HIA_SETUP_TRANSACTION pid={} phase={phase} mode={:?} refresh_only={} marker_len={marker_len:?}",
            std::process::id(),
            payload.mode,
            payload.refresh_only
        ),
        Some(&directory),
    );
}

'''
assert text.count(needle)==1;text=text.replace(needle,insert+needle)
old='    let result = run_setup(&payload, &mut log, &sbx_dir);'
new='''    trace_setup_marker(&payload, "begin");
    let result = run_setup(&payload, &mut log, &sbx_dir);
    trace_setup_marker(
        &payload,
        if result.is_ok() { "return-ok" } else { "return-error" },
    );'''
assert text.count(old)==1;text=text.replace(old,new)
old='''    if writes_setup_marker {
        prepare_setup_marker(&payload.codex_home, &payload.real_user)?;
    }'''
new='''    trace_setup_marker(payload, "locked");
    if writes_setup_marker {
        prepare_setup_marker(&payload.codex_home, &payload.real_user)?;
        trace_setup_marker(payload, "prepared");
    }'''
assert text.count(old)==1;text=text.replace(old,new)
old='''    }?;
    if writes_setup_marker {
        commit_setup_marker('''
new='''    }?;
    trace_setup_marker(payload, "provisioned");
    if writes_setup_marker {
        commit_setup_marker('''
assert text.count(old)==1;text=text.replace(old,new)
old='''            payload.allow_local_binding,
        )?;
    }
    Ok(())
}

fn run_read_acl_only'''
new='''            payload.allow_local_binding,
        )?;
        trace_setup_marker(payload, "committed");
    }
    Ok(())
}

fn run_read_acl_only'''
assert text.count(old)==1;text=text.replace(old,new);helper.write_text(text)
text=caller.read_text()
needle='fn verify_setup_completed(codex_home: &Path) -> Result<()> {'
insert='''fn trace_incomplete_setup(codex_home: &Path) {
    if std::env::var("SBX_DEBUG").ok().as_deref() != Some("1") {
        return;
    }
    use std::io::Read;
    use std::io::Seek;
    use std::io::SeekFrom;
    let marker_len = std::fs::metadata(setup_marker_path(codex_home))
        .ok()
        .map(|metadata| metadata.len());
    eprintln!(
        "HIA_SETUP_OBSERVATION pid={} marker_len={marker_len:?}",
        std::process::id()
    );
    let path = current_log_file_path(&sandbox_dir(codex_home));
    let Ok(mut log) = std::fs::File::open(path) else {
        return;
    };
    let Ok(metadata) = log.metadata() else {
        return;
    };
    let offset = metadata.len().saturating_sub(32 * 1024);
    if log.seek(SeekFrom::Start(offset)).is_err() {
        return;
    }
    let mut raw = Vec::new();
    if log.take(32 * 1024).read_to_end(&mut raw).is_err() {
        return;
    }
    for line in String::from_utf8_lossy(&raw)
        .lines()
        .filter(|line| line.contains("HIA_SETUP_TRANSACTION "))
        .take(64)
    {
        eprintln!("{line}");
    }
}

'''
assert text.count(needle)==1;text=text.replace(needle,insert+needle)
old='''    } else {
        Err(failure(
            SetupErrorCode::OrchestratorHelperIncomplete,'''
new='''    } else {
        trace_incomplete_setup(codex_home);
        Err(failure(
            SetupErrorCode::OrchestratorHelperIncomplete,'''
assert text.count(old)==1;text=text.replace(old,new);caller.write_text(text)
env=dict(os.environ);env['PATH']='/Users/qianqi/.rustup/toolchains/1.96.1-aarch64-apple-darwin/bin:/opt/homebrew/bin:/Users/qianqi/.cargo/bin:/usr/bin:/bin:/usr/sbin:/sbin'
for label,cmd in [('just-fmt',['/opt/homebrew/bin/just','fmt']),('diff-check',['/usr/bin/git','diff','--check'])]:
 start=time.monotonic()
 with (Q/(label+'.stdout')).open('xb') as out,(Q/(label+'.stderr')).open('xb') as err:
  child=subprocess.Popen(cmd,cwd=S/'codex-rs',env=env,stdout=out,stderr=err);rc=child.wait()
 result={'argv':cmd,'returncode':rc,'seconds':time.monotonic()-start};(Q/(label+'.json')).write_text(json.dumps(result)+'\n');assert rc==0,result
(Q/'source.diff').write_bytes(subprocess.check_output(['/usr/bin/git','diff'],cwd=S))
(Q/'source-pins.json').write_text(json.dumps({p.relative_to(S).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (helper,caller)},indent=2)+'\n')
print('Diagnostic-only candidate prepared; no success claim or test change',flush=True)
