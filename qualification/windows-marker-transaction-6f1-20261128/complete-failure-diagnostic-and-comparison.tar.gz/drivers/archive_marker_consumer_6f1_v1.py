from pathlib import Path
import hashlib,json,subprocess,time,zipfile,gzip
R=Path(__file__).resolve().parent
Q=R/'qualification/marker-consumer-6f1-v1';Q.mkdir(mode=0o700)
repo='TrillionniumFoundation/hepta-private-ci'
items=[
 ('consumer6f1-job140797955764.log',f'repos/{repo}/actions/jobs/140797955764/logs',None,None),
 ('consumer6f1-artifact15239836691.zip',f'repos/{repo}/actions/artifacts/15239836691/zip',4942070,'21e821530a2871705148b79ec0ca4c6296cf7879196b549d4fd7ecfae6111240'),
]
results=[]
for name,url,size,sha in items:
 p=Q/name
 command=['/opt/homebrew/bin/gh','api',url]
 (Q/(name+'.intent.json')).write_text(json.dumps({'command':command})+'\n')
 started=time.monotonic()
 with p.open('xb') as out,(Q/(name+'.stderr')).open('xb') as err:
  child=subprocess.Popen(command,stdout=out,stderr=err)
  (Q/(name+'.started.json')).write_text(json.dumps({'pid':child.pid})+'\n')
  rc=child.wait()
 result={'name':name,'returncode':rc,'seconds':time.monotonic()-started,'bytes':p.stat().st_size}
 (Q/(name+'.terminal.json')).write_text(json.dumps(result)+'\n')
 assert rc==0,result
 raw=p.read_bytes();result['sha256']=hashlib.sha256(raw).hexdigest()
 if size is not None: assert len(raw)==size,(name,len(raw),size)
 if sha is not None: assert result['sha256']==sha,result
 if name.endswith('.zip'):
  members=[]
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   for info in z.infolist():
    b=z.read(info);members.append({'name':info.filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'crc32':info.CRC})
    if info.filename.endswith(('.log','.xml','.json','.txt')):
     assert not info.filename.startswith('/') and '..' not in Path(info.filename).parts
     dest=Q/(name+'.members')/info.filename;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  result['members']=members
 else:
  (Q/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
  assert gzip.decompress((Q/(name+'.gz')).read_bytes())==raw
 results.append(result);print(json.dumps(result),flush=True)
(Q/'terminal.json').write_text(json.dumps({'returncode':0,'results':results},indent=2)+'\n')
print('ARCHIVE COMPLETE',flush=True)
