from pathlib import Path
import difflib,hashlib,json,os,subprocess,time
R=Path(__file__).resolve().parent;S=R/'source';Q=R/'qualification/subagent-event-diagnostic-v1';Q.mkdir(mode=0o700)
p=S/'codex-rs/core/tests/suite/subagent_notifications.rs';old=p.read_bytes()
before='''    wait_for_event_match(child_thread.as_ref(), |event| match event {
        EventMsg::TurnComplete(event) if event.turn_id == child_turn_id => Some(()),
        _ => None,
    })
'''
after='''    wait_for_event_match(child_thread.as_ref(), |event| {
        eprintln!("subagent completion observation: wanted thread={child_thread_id} turn={child_turn_id}; actual={event:?}");
        match event {
            EventMsg::TurnComplete(event) if event.turn_id == child_turn_id => Some(()),
            _ => None,
        }
    })
'''
assert old.count(before.encode())==1
new=old.replace(before.encode(),after.encode())
(Q/'original-subagent_notifications.rs').write_bytes(old);(Q/'diagnostic-subagent_notifications.rs').write_bytes(new)
(Q/'diagnostic.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='original',tofile='diagnostic')))
head=subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=S,text=True).strip()
assert head=='c903c5ea74e3241da2cb23d47ab35f633455041a'
names=['codex-rs/core/tests/common/lib.rs','codex-rs/core/src/agent/control/residency.rs','codex-rs/Cargo.toml','codex-rs/Cargo.lock']
pins={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in names}
env=dict(os.environ);env['PATH']='/Users/qianqi/.rustup/toolchains/1.96.1-aarch64-apple-darwin/bin:/opt/homebrew/bin:/Users/qianqi/.cargo/bin:/usr/bin:/bin:/usr/sbin:/sbin';env['CARGO_TARGET_DIR']=str(R/'cargo-target');env['CARGO_BUILD_JOBS']='4'
cmd=['/opt/homebrew/bin/just','test','--locked','-p','codex-core','--test','all','-E','test(suite::subagent_notifications::subagent_stop_replaces_stop_and_skips_internal_subagents)']
(Q/'intent.json').write_text(json.dumps({'head':head,'argv':cmd,'source_old':hashlib.sha256(old).hexdigest(),'source_diagnostic':hashlib.sha256(new).hexdigest(),'original_matcher_and_timeouts_unchanged':True,'production_qualification':False,'other_sources':pins},indent=2)+'\n')
p.write_bytes(new);start=time.monotonic()
try:
 with (Q/'tests.stdout').open('xb') as out,(Q/'tests.stderr').open('xb') as err:
  child=subprocess.Popen(cmd,cwd=S/'codex-rs',env=env,stdout=out,stderr=err);(Q/'started.json').write_text(json.dumps({'pid':child.pid})+'\n');rc=child.wait()
 assert p.read_bytes()==new
finally:
 assert p.read_bytes()==new
 p.write_bytes(old)
restored=p.read_bytes()==old and all(hashlib.sha256((S/n).read_bytes()).hexdigest()==v for n,v in pins.items())
report={'returncode':rc,'seconds':time.monotonic()-start,'original_source_restored':restored,'production_qualification':False}
(Q/'terminal.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
raw=(Q/'tests.stderr').read_text()
rows=[line for line in raw.splitlines() if 'subagent completion observation:' in line]
(Q/'observed-events.txt').write_text('\n'.join(rows)+'\n')
print(json.dumps({'event_lines':len(rows),'observations_path':str(Q/'observed-events.txt')}),flush=True)
for line in rows:print(line[:600],flush=True)
assert restored
raise SystemExit(rc)
