from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path(__file__).resolve().parent;S=R/'source';Q=R/'qualification/subagent-request-selection-v2';Q.mkdir(mode=0o700)
relative='codex-rs/core/tests/suite/subagent_notifications.rs';p=S/relative;old=p.read_bytes()
head=subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=S,text=True).strip()
assert head=='c903c5ea74e3241da2cb23d47ab35f633455041a'
assert old==subprocess.check_output(['/usr/bin/git','show','HEAD:'+relative],cwd=S)
patch=Path('/Users/qianqi/work/codex-subagent-completion-20261128-2ac5/qualification/request-selection-v2/source.patch').read_bytes()
(Q/'source.patch').write_bytes(patch);(Q/'original-subagent_notifications.rs').write_bytes(old)
subprocess.run(['/usr/bin/git','apply','--check','-'],cwd=S,input=patch,check=True)
subprocess.run(['/usr/bin/git','apply','-'],cwd=S,input=patch,check=True)
candidate=p.read_bytes()
try:
 assert hashlib.sha256(candidate).hexdigest()=='1f017d35bd5b4c267989ab2237e8427169a19bb92b89c4744745945ea392408b'
 (Q/'candidate-subagent_notifications.rs').write_bytes(candidate)
 names=['codex-rs/core/tests/common/lib.rs','codex-rs/core/src/agent/control/residency.rs','codex-rs/Cargo.toml','codex-rs/Cargo.lock']
 pins={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in names}
 env=dict(os.environ);env['PATH']='/Users/qianqi/.rustup/toolchains/1.96.1-aarch64-apple-darwin/bin:/opt/homebrew/bin:/Users/qianqi/.cargo/bin:/usr/bin:/bin:/usr/sbin:/sbin';env['CARGO_TARGET_DIR']=str(R/'cargo-target');env['CARGO_BUILD_JOBS']='4'
 cmd=['/opt/homebrew/bin/just','test','--locked','-p','codex-core','--test','all','-E','test(suite::subagent_notifications::subagent_stop_replaces_stop_and_skips_internal_subagents)']
 (Q/'intent.json').write_text(json.dumps({'head':head,'argv':cmd,'source_old':hashlib.sha256(old).hexdigest(),'source_candidate':hashlib.sha256(candidate).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest(),'other_sources':pins,'original_budgets_seconds':{'matching_request':2,'event':10,'hook':2}},indent=2)+'\n')
 start=time.monotonic()
 with (Q/'tests.stdout').open('xb') as out,(Q/'tests.stderr').open('xb') as err:
  child=subprocess.Popen(cmd,cwd=S/'codex-rs',env=env,stdout=out,stderr=err);(Q/'started.json').write_text(json.dumps({'pid':child.pid})+'\n');rc=child.wait()
 assert p.read_bytes()==candidate
 assert all(hashlib.sha256((S/n).read_bytes()).hexdigest()==v for n,v in pins.items())
finally:
 assert p.read_bytes()==candidate
 p.write_bytes(old)
report={'returncode':rc,'seconds':time.monotonic()-start,'original_source_restored':p.read_bytes()==old,'candidate_unchanged_during_test':True}
(Q/'terminal.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
print((Q/'tests.stderr').read_text()[-8000:],flush=True)
raise SystemExit(rc)
