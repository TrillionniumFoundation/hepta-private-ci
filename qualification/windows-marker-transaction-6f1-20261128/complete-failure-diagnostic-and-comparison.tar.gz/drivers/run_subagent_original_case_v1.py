from pathlib import Path
import os,subprocess,time,json,hashlib
R=Path(__file__).resolve().parent;S=R/'source';Q=R/'qualification/subagent-original-case-v1';Q.mkdir(mode=0o700)
env=dict(os.environ);env['PATH']='/Users/qianqi/.rustup/toolchains/1.96.1-aarch64-apple-darwin/bin:/opt/homebrew/bin:/Users/qianqi/.cargo/bin:/usr/bin:/bin:/usr/sbin:/sbin';env['CARGO_TARGET_DIR']=str(R/'cargo-target');env['CARGO_BUILD_JOBS']='4'
names=['codex-rs/core/tests/suite/subagent_notifications.rs','codex-rs/core/tests/common/lib.rs','codex-rs/core/src/agent/control/residency.rs','codex-rs/core/src/session/tasks.rs','codex-rs/Cargo.toml','codex-rs/Cargo.lock']
names=[n for n in names if (S/n).is_file()];before={n:(S/n).read_bytes() for n in names}
head=subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=S,text=True).strip()
(Q/'source-before.json').write_text(json.dumps({'head':head,'files':{n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in before.items()}},indent=2)+'\n')
cmd=['/opt/homebrew/bin/just','test','--locked','-p','codex-core','--test','all','-E','test(suite::subagent_notifications::subagent_stop_replaces_stop_and_skips_internal_subagents)']
(Q/'intent.json').write_text(json.dumps({'argv':cmd,'cwd':str(S/'codex-rs')},indent=2)+'\n');started=time.monotonic()
with (Q/'tests.stdout').open('xb') as out,(Q/'tests.stderr').open('xb') as err:
 child=subprocess.Popen(cmd,cwd=S/'codex-rs',env=env,stdout=out,stderr=err);(Q/'started.json').write_text(json.dumps({'pid':child.pid})+'\n');rc=child.wait()
result={'returncode':rc,'seconds':time.monotonic()-started,'source_unchanged':all((S/n).read_bytes()==v for n,v in before.items())}
(Q/'terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raw=(Q/'tests.stderr').read_text();print(raw[-5500:],flush=True);raise SystemExit(rc)
