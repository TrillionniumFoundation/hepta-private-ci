#!/usr/bin/env python3
"""Preserve the completed exact afdf standard discovery and same-child samples."""
from pathlib import Path
import importlib.util
import json
import io
import stat
import tarfile

BASE=Path('/workspace/scratch/ff41dfc0f7bf/tooling')
HELPER=BASE/'archive_bfee_native_originals_ci_v3.py'
spec=importlib.util.spec_from_file_location('exact_evidence_io',HELPER)
helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
SOURCE=BASE/'validation/root-afdf13ff-full-source-ci-evidence-monitored-v1'
OUT=BASE/'publication/evidence-afdf13ff-source-qa-20261113-v1'
HEAD='afdf13ffc1757c0dfa5d3f6922bde2d746251df7'
TREE='7eb8f9f742ce2a28327b6d7aae0b2f0f8cd7ebf4'

def main():
 OUT.mkdir(exist_ok=True)
 files=[p for p in SOURCE.iterdir() if p.is_file()]
 files += [HELPER,Path(__file__),BASE/'run_root_afdf13ff_full_source_ci_evidence_monitored_v1.py',
           BASE/'publication/evidence-5e2426ad-full-caller-20261113-v1/publication-receipt.json']
 saved={str(p.relative_to(BASE)):helpers.original(p) for p in sorted(set(files))}
 prefix=str(SOURCE.relative_to(BASE))+'/'
 result=json.loads(saved[prefix+'result.json'][0])
 gate=json.loads(saved[prefix+'fullsource.json'][0])
 assert result['status']=='completed' and result['source_unchanged'] and result['all_gates_passed']
 assert result['full_caller_executed'] is False and len(result['stages'])==1
 assert result['source']==result['after']==gate['before']==gate['after']
 assert result['source']['head']==HEAD and result['source']['tree']==TREE
 assert result['source']['tracked_files']==15500 and result['source']['tracked_sha256']=='10d16cdd1f455bb0ea756b72156658f33e6a34f1e6f15ccc88c74e4aade5191d'
 assert gate['status']=='completed' and gate['exit_code']==0 and gate['source_unchanged']
 assert gate['command']==['python3','-m','unittest','discover','-s','qa/b4-no-bypass','-p','test_*.py','-v']
 assert saved[prefix+'fullsource.stdout.log'][0]==b''
 stderr=saved[prefix+'fullsource.stderr.log'][0]
 assert stderr.endswith(b'Ran 926 tests in 218.235s\n\nOK\n')
 assert helpers.digest(stderr)=='3f1df1eefa2332e5d562fe63988a73b4adc466756661eedf216031472cf2c704'
 samples=[json.loads(line) for line in saved[prefix+'fullsource.resources.jsonl'][0].splitlines()]
 assert len(samples)==221 and all(x['same_child_start'] for x in samples)
 assert len({(x['pid'],x['start_ticks']) for x in samples})==1
 assert all('observation_error' not in x for x in samples)
 assert json.loads(saved[prefix+'terminal-tool.original.json'][0])['exit_code']==0
 archive=OUT/'originals.tar.xz';assert not archive.exists()
 with tarfile.open(archive,'x:xz',preset=6) as tar:
  for name,(data,metadata) in saved.items():
   e=tarfile.TarInfo(name);e.size=len(data);e.mode=stat.S_IMODE(metadata['st_mode']);e.mtime=metadata['st_mtime_ns']/1e9
   tar.addfile(e,io.BytesIO(data))
 with tarfile.open(archive,'r:xz') as tar:
  members=tar.getmembers();assert len(members)==len(saved) and {m.name for m in members}==set(saved)
  for m in members:assert m.isfile() and tar.extractfile(m).read()==saved[m.name][0]
 for name,pair in saved.items():assert helpers.original(BASE/name)==pair
 body,_=helpers.original(archive)
 manifest={'schema':1,'head':HEAD,'tree':TREE,'archive':archive.name,'archive_bytes':len(body),'archive_sha256':helpers.digest(body),
 'member_count':len(saved),'input_bytes':sum(len(x[0]) for x in saved.values()),
 'members':[{'path':name,'bytes':len(b),'sha256':helpers.digest(b),'source_stat':s} for name,(b,s) in saved.items()],
 'all_originals_unchanged':True,'all_members_verified':True}
 verification={'schema':1,'head':HEAD,'tree':TREE,'source_qa':{k:gate[k] for k in ['status','exit_code','started','finished','elapsed_seconds','source_unchanged','command','files','read_only_child_usage']},
 'unittest_summary':{'tests':926,'elapsed_seconds':218.235,'status':'OK'},'source_snapshot':result['source'],
 'samples':{'count':221,'same_pid_and_start':True,'observation_errors':0,'bytes':len(saved[prefix+'fullsource.resources.jsonl'][0]),
 'sha256':helpers.digest(saved[prefix+'fullsource.resources.jsonl'][0]),'summary':json.loads(saved[prefix+'resource-summary.json'][0])},
 'full_caller_executed_on_this_candidate':False,'actual_cli_receipt_source':'5e2426ad737fc5f8bef5c69e4a49f4b9a0275be4',
 'same_cli_inputs_proof':json.loads(saved[prefix+'checkout-and-driver-receipt.json'][0])['cli_input_comparison'],
 'previous_signal_cause_inferred':False,'native_tests_executed':0,'whole_qualification_counts':[0,0,0],
 'previous_evidence_head':'f5a8672016ca4fa5e4b6eca01afd4e42f6763311'}
 helpers.write_new(OUT/'manifest.json',helpers.json_bytes(manifest))
 helpers.write_new(OUT/'verification.json',helpers.json_bytes(verification))
 readme="""# Exact afdf standard source QA: 926 tests completed

The unchanged standard command `python3 -m unittest discover -s qa/b4-no-bypass -p 'test_*.py' -v` completed exit 0 with **926 tests in 218.235 seconds, OK** on afdf13ffc1757c0dfa5d3f6922bde2d746251df7 / tree 7eb8f9f742ce2a28327b6d7aae0b2f0f8cd7ebf4.

The gate ran 02:02:19.350943–02:06:00.621714 UTC (221.270096366 seconds including launcher bookkeeping). Complete physical snapshots before and after were identical: 15,500 files / 234,446,647 bytes / SHA-256 10d16cdd1f455bb0ea756b72156658f33e6a34f1e6f15ccc88c74e4aade5191d. The only repository difference from 5e is the actual caller expectation in one QA file. Source, scanner, tests, command, environment, budgets and test grouping were not altered during execution.

The separately reviewed launcher added only a read-only sampler in the same process namespace and cumulative child rusage. All 221 original JSONL samples are included, with one PID/start and no observation errors. Maximum sampled RSS was 674,780 KiB; final rusage reports maxrss 674,016 KiB. Both original values are preserved separately. They do not establish why older bfee and 5e processes exited -9.

The complete authoritative caller CLI was actually executed on 5e2426ad, where it passed 6,892 Rust files / 1,113 boundaries / 1,113 inventory / 878 protected entries. It was not rerun on afdf. The sole changed QA file is neither a scanner/Rust/CALLERS file nor a declared protected or definition input; the comparison receipt is included. This appendix explicitly records full_caller_executed=false for afdf and does not manufacture a later CLI receipt.

Earlier signal exits, the already-emitted identity subtest failure, and the successful focused correction remain in prior/separate evidence. This successful complete discovery is not a native or whole-chain result. Whole qualification remains 0/0/0. H preparation/connection failures and original native results have separate scopes.

All raw stdout/stderr, complete result/snapshots, launcher before and after the docstring correction, diff, launch/terminal receipts and full resources.jsonl are retained. Every archived member was compared byte-for-byte and original inputs were rechecked unchanged.
"""
 helpers.write_new(OUT/'README.md',readme.encode())
 infos=[]
 for p in sorted(OUT.iterdir()):
  b,_=helpers.original(p)
  infos.append({'name':p.name,'bytes':len(b),'sha256':helpers.digest(b),'git_blob':helpers.hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
 print(json.dumps({'output':str(OUT),'files':infos,'members':len(saved),'input_bytes':manifest['input_bytes']}))
if __name__=='__main__':main()
