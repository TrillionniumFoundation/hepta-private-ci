"""Run only the complete standard source QA suite on the frozen integrated source.

No Rust/native/H command is part of this driver. Each original command keeps
independent stdout, stderr, terminal status and complete source snapshots.
"""
import datetime
import hashlib
import json
import os
import resource
import threading
from pathlib import Path
import subprocess
import time
import traceback


REPO = Path('/workspace/scratch/ff41dfc0f7bf/hepta-current-history-guards-cloud')
OUT = Path('/workspace/scratch/ff41dfc0f7bf/tooling/validation/root-afdf13ff-full-source-ci-evidence-monitored-v1')
HEAD = 'afdf13ffc1757c0dfa5d3f6922bde2d746251df7'
TREE = '7eb8f9f742ce2a28327b6d7aae0b2f0f8cd7ebf4'
CALLERS = '86cc52079c610b02d50fd5b3c2e56846ef9dc238e9afbfc4d577b9924dedd216'


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=REPO)


def snapshot():
    digest = hashlib.sha256()
    count = 0
    total_bytes = 0
    for entry in git('ls-files', '-s', '-z').split(b'\0'):
        if not entry:
            continue
        meta, name = entry.split(b'\t', 1)
        path = REPO / os.fsdecode(name)
        if path.is_symlink():
            contents = os.fsencode(os.readlink(path))
            content_digest = hashlib.sha256(contents).digest()
            total_bytes += len(contents)
        else:
            with path.open('rb') as stream:
                content_digest = hashlib.file_digest(stream, 'sha256').digest()
                total_bytes += os.fstat(stream.fileno()).st_size
        digest.update(meta.split()[0] + b'\0' + name + b'\0' + content_digest)
        count += 1
    return dict(head=git('rev-parse', 'HEAD').decode().strip(),
                tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
                status=git('status', '--porcelain=v1', '--untracked-files=all').decode(),
                tracked_files=count, tracked_bytes=total_bytes,
                tracked_sha256=digest.hexdigest(),
                callers_sha256=hashlib.sha256((REPO / 'CALLERS.toml').read_bytes()).hexdigest())


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def child_resource_samples(pid, stopped, target):
    """Read the original child's proc view; never signal or change that process."""
    first_start = None
    with target.open('x') as stream:
        while not stopped.is_set():
            row = dict(observed_at=utc(), monotonic=time.monotonic(), pid=pid)
            try:
                proc = Path('/proc') / str(pid)
                start = (proc / 'stat').read_text().rsplit(')', 1)[1].split()[19]
                if first_start is None:
                    first_start = start
                row['start_ticks'] = start
                row['same_child_start'] = start == first_start
                if start != first_start:
                    row['status'] = 'pid_reused_refuse_sample'
                else:
                    allowed = ('Name:', 'State:', 'Pid:', 'PPid:', 'VmPeak:',
                               'VmHWM:', 'VmRSS:', 'VmSize:', 'Threads:')
                    row['status_fields'] = [
                        line for line in (proc / 'status').read_text().splitlines()
                        if line.startswith(allowed)
                    ]
                row['memory_available'] = [
                    line for line in Path('/proc/meminfo').read_text().splitlines()
                    if line.startswith(('MemTotal:', 'MemAvailable:', 'SwapTotal:', 'SwapFree:'))
                ]
            except OSError as error:
                row['observation_error'] = dict(type=type(error).__name__, errno=error.errno)
            stream.write(json.dumps(row) + '\n')
            stream.flush()
            stopped.wait(1.0)


def child_rusage():
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    return dict(utime=usage.ru_utime, stime=usage.ru_stime,
                maxrss_kib=usage.ru_maxrss, minor_faults=usage.ru_minflt,
                major_faults=usage.ru_majflt, voluntary_switches=usage.ru_nvcsw,
                involuntary_switches=usage.ru_nivcsw,
                scope='launcher cumulative reaped children; maxrss is a peak, not subtractable')


assert OUT.is_dir() and not (OUT / 'result.json').exists()
before = snapshot()
assert before['head'] == HEAD and before['tree'] == TREE
assert not before['status'] and before['callers_sha256'] == CALLERS
save(OUT / 'source-before.json', before)
result = dict(status='running', started=utc(), repo=str(REPO), source=before,
              driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              execution='all qa/b4-no-bypass/test_*.py at exactafdf13ff; standard discover; read-only child RSS/rusage observation; no timeout, retry, grouping, environment change or source edits',
              native_tests_executed=0, full_caller_executed=False, stages=[])
save(OUT / 'result.json', result)
environment = dict(os.environ)
environment['PYTHONDONTWRITEBYTECODE'] = '1'
environment['PYTHONUNBUFFERED'] = '1'
commands = [('fullsource', ['python3', '-m', 'unittest', 'discover', '-s', 'qa/b4-no-bypass', '-p', 'test_*.py', '-v'])]
for name, argv in commands:
    record = dict(name=name, command=argv, cwd=str(REPO), started=utc(), status='starting')
    result['stages'].append(record)
    save(OUT / 'result.json', result)
    start = time.monotonic()
    try:
        record['before'] = snapshot()
        assert record['before'] == before, 'source differs before original gate'
        with (OUT / (name + '.stdout.log')).open('xb') as stdout, (OUT / (name + '.stderr.log')).open('xb') as stderr:
            child = subprocess.Popen(argv, cwd=REPO, env=environment, stdout=stdout, stderr=stderr)
            record.update(status='running', pid=child.pid)
            save(OUT / (name + '.json'), record)
            save(OUT / 'result.json', result)
            print(json.dumps({'stage': name, 'pid': child.pid, 'started': record['started']}), flush=True)
            before_usage = child_rusage()
            stopped = threading.Event()
            sampler = threading.Thread(target=child_resource_samples,
                                       args=(child.pid, stopped, OUT / (name + '.resources.jsonl')))
            sampler.start()
            try:
                record.update(exit_code=child.wait(), status='completed')
            finally:
                stopped.set()
                sampler.join()
                record['read_only_child_usage'] = dict(before=before_usage, after=child_rusage())

    except BaseException as error:
        record.update(status='driver_failed', error=repr(error))
        (OUT / (name + '.driver-error.log')).write_text(traceback.format_exc())
    finally:
        record.update(finished=utc(), elapsed_seconds=time.monotonic() - start)
        try:
            record['after'] = snapshot()
            record['source_unchanged'] = record['before'] == record['after'] == before
        except BaseException as error:
            record['snapshot_error'] = repr(error)
            record['source_unchanged'] = False
        record['files'] = {}
        for path in sorted(OUT.glob(name + '.*.log')):
            with path.open('rb') as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            record['files'][path.name] = dict(bytes=path.stat().st_size, sha256=digest)
        record['passed'] = record['status'] == 'completed' and record.get('exit_code') == 0 and record.get('source_unchanged') is True
        save(OUT / (name + '.json'), record)
        save(OUT / 'result.json', result)
        print(json.dumps({'stage': name, 'status': record['status'], 'exit_code': record.get('exit_code'),
                          'source_unchanged': record.get('source_unchanged'),
                          'elapsed_seconds': record['elapsed_seconds']}), flush=True)
result.update(status='completed', finished=utc(), after=snapshot())
result['source_unchanged'] = result['source'] == result['after']
result['all_gates_passed'] = result['source_unchanged'] and all(record['passed'] for record in result['stages'])
save(OUT / 'result.json', result)
print('ROOT_AFDF13FF_FULL_SOURCE_MONITORED_GATE_TERMINAL ' + json.dumps(result), flush=True)
raise SystemExit(0 if result['all_gates_passed'] else 1)
