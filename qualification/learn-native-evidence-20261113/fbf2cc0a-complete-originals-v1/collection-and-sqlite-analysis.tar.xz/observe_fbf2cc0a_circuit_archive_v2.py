"""Read a verified closed archive and query a private WAL-aware SQLite copy read-only."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import tarfile
import traceback


ARCHIVE = Path('/home/qq/hepta-learn-ff41-tools/validation/root-originals-fbf2cc0a-v1/originals.tar.xz')
ARCHIVE_SHA = '154f69338407158e558f3a583bda1ed3057c164d7f2eb75c6df5ac7cd2174605'
MANIFEST_SHA = '569d0760ee44275cd7cd712e12d0e528c7ce1d88befd52385ce45895e976ee48'
HEAD = 'fbf2cc0a3eaf4ca1e720300c306ff6ad38517449'
TREE = '7b5104c68e65c4fec111f21d3aa8f5ba04984e9d'
RUNTIME = Path('/run/oq-Ovma1L')
OUT = Path('/home/qq/hepta-learn-ff41-tools/validation/root-fbf2cc0a-circuit-data-observation-v2')
RUN_ID = 'ordinary-original-a'
QUERIES = {
    'run': 'SELECT owner_agent_id, run_id, definition_digest, revision, state_json, state_digest, last_event_digest FROM circuit_v2_runs WHERE run_id = ?',
    'definition': 'SELECT circuit_id, version, definition_digest, definition_json FROM circuit_v2_definitions WHERE owner_agent_id = ? AND definition_digest = ?',
    'events': 'SELECT seq, command_id, event_json, previous_digest, state_digest, event_digest FROM circuit_v2_events WHERE owner_agent_id = ? AND run_id = ? ORDER BY seq LIMIT 257',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def physical(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_uid, value.st_gid,
            value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def snapshot(directory):
    return {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes()),
                     'physical': physical(p.stat())} for p in sorted(directory.iterdir())}


def data_fields(value, path='$', output=None):
    """Emit only known timing/count/reason fields; omit arbitrary payloads and keys."""
    if output is None:
        output = []
    if isinstance(value, dict):
        for name, item in value.items():
            if not isinstance(name, str) or len(name) > 96:
                continue
            where = path + '.' + name
            if name in {'created_at_ms', 'last_observed_ms', 'now_ms', 'observed_at_ms',
                        'at_ms', 'max_elapsed_ms', 'revision', 'activation_id',
                        'max_activations', 'seq', 'steps', 'transition_count'}:
                if type(item) is int:
                    output.append({'field': where, 'value': item})
            elif name in {'stop_reason', 'kind', 'event_type', 'status'}:
                if item is None or (isinstance(item, str) and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_-]{0,63}', item)):
                    output.append({'field': where, 'value': item})
                elif isinstance(item, dict):
                    output.append({'field': where, 'variant_keys': sorted(item)})
            elif name in {'activations', 'computations', 'pending', 'in_flight'} and isinstance(item, (list, dict)):
                output.append({'field': where, 'count': len(item)})
            data_fields(item, where, output)
    elif isinstance(value, list):
        for index, item in enumerate(value[:256]):
            data_fields(item, path + '[' + str(index) + ']', output)
    assert len(output) <= 4096
    return output


def observe():
    assert os.getuid() == os.geteuid() == 1000
    fd = os.open(ARCHIVE, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        archive_before = physical(os.fstat(stream.fileno()))
        assert stat.S_ISREG(archive_before[2]) and archive_before[5] == 311400
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == ARCHIVE_SHA
        stream.seek(0)
        with tarfile.open(fileobj=stream, mode='r:xz') as archive:
            members = archive.getmembers()
            names = [member.name for member in members]
            assert len(names) == len(set(names)) and len(names) < 50000
            assert all(member.isfile() and not Path(member.name).is_absolute()
                       and '..' not in Path(member.name).parts for member in members)
            manifest_bytes = archive.extractfile('manifest.json').read()
            assert sha(manifest_bytes) == MANIFEST_SHA
            manifest = json.loads(manifest_bytes)
            assert manifest['source_head'] == HEAD and manifest['source_tree'] == TREE
            rows = {row['path']: row for row in manifest['records']
                    if row['kind'] == 'regular' and 'sha256' in row}
            assert set(names) == set(rows) | {'manifest.json'}
            case = [case for case in manifest['cases'] if case['stage'] == 'ordinary-a']
            assert len(case) == 1 and case[0]['native_parent_reported_pass'] is False
            runtime = [marker for marker in case[0]['markers'] if marker.get('role') == 'a_runtime']
            assert len(runtime) == 1 and Path(runtime[0]['actual_path']) == RUNTIME
            databases = [row for row in rows.values()
                         if Path(row['actual_path']).name == 'automation_1.sqlite3'
                         and Path(row['actual_path']).is_relative_to(RUNTIME)]
            assert len(databases) == 1
            database = databases[0]
            side_paths = {database['actual_path'] + suffix for suffix in ('', '-wal', '-shm', '-journal')}
            selected, total = [], 0
            copy = OUT / 'sqlite-copy'
            copy.mkdir(mode=0o700)
            for member in members:
                if member.name == 'manifest.json':
                    continue
                row = rows[member.name]
                data = archive.extractfile(member).read()
                assert len(data) == member.size == row['physical']['size'] and sha(data) == row['sha256']
                total += len(data)
                if row['actual_path'] in side_paths:
                    name = Path(row['actual_path']).name
                    with (copy / name).open('xb') as output:
                        output.write(data)
                        output.flush()
                        os.fsync(output.fileno())
                    os.chmod(copy / name, 0o600)
                    selected.append({'member': member.name, 'original_path': row['original_path'],
                                     'actual_path': row['actual_path'], 'bytes': len(data), 'sha256': sha(data)})
            assert total == manifest['totals']['bytes'] == 8838274
        assert physical(os.fstat(stream.fileno())) == archive_before
        assert physical(ARCHIVE.stat()) == archive_before
    before = snapshot(copy)
    database_copy = copy / 'automation_1.sqlite3'
    assert database_copy.read_bytes()[:16] == b'SQLite format 3\0'
    connection = sqlite3.connect(database_copy.as_uri() + '?mode=ro', uri=True)
    connection.row_factory = sqlite3.Row
    try:
        connection.execute('PRAGMA query_only = ON')
        schema = {table: [dict(row) for row in connection.execute('PRAGMA table_info(' + table + ')')]
                  for table in ('circuit_v2_runs', 'circuit_v2_definitions', 'circuit_v2_events')}
        runs = list(connection.execute(QUERIES['run'], (RUN_ID,)))
        assert len(runs) == 1
        run = dict(runs[0])
        definitions = list(connection.execute(QUERIES['definition'], (run['owner_agent_id'], run['definition_digest'])))
        assert len(definitions) == 1
        definition = dict(definitions[0])
        events = list(connection.execute(QUERIES['events'], (run['owner_agent_id'], RUN_ID)))
        assert len(events) < 257
        state = json.loads(run.pop('state_json'))
        definition_data = json.loads(definition.pop('definition_json'))
        event_data = []
        for row in events:
            item = dict(row)
            raw = item.pop('event_json')
            body = json.loads(raw)
            item.update(event_json_sha256=sha(raw.encode()), top_level_keys=sorted(body), fields=data_fields(body))
            event_data.append(item)
        observed = dict(sqlite_version=sqlite3.sqlite_version,
                        journal_mode=connection.execute('PRAGMA journal_mode').fetchone()[0],
                        schema=schema, run_metadata=run, state_fields=data_fields(state),
                        state_top_level_keys=sorted(state), definition_metadata=definition,
                        definition_fields=data_fields(definition_data), events=event_data)
    finally:
        connection.close()
    after = snapshot(copy)
    durable_names = {name for name in before if not name.endswith('-shm')}
    assert all(before[name] == after.get(name) for name in durable_names)
    assert physical(ARCHIVE.stat()) == archive_before
    return dict(status='completed', source_head=HEAD, source_tree=TREE,
                archive=str(ARCHIVE), archive_sha256=ARCHIVE_SHA, manifest_sha256=MANIFEST_SHA,
                all_archived_members_verified=len(rows), all_archived_bytes_verified=total,
                selected_sqlite_originals=selected, copy_before=before, copy_after=after,
                copy_unchanged=(before == after), copied_db_and_wal_unchanged=True,
                copy_cache_changes=[name for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)],
                archive_unchanged=True, queries=QUERIES,
                observation=observed, native_tests_run=False, qualification_inferred=False,
                scope='Pure DATA query (mode=ro and query_only) of a separate copied DB plus archived WAL/SHM; only private SQLite cache changes may occur. All original archive members and copied durable DB/WAL remain unchanged. No original store opened and no native qualification inferred.')


assert os.getuid() == os.geteuid() == 1000
OUT.mkdir(mode=0o700, exist_ok=False)
(OUT / 'query-spec.json').write_text(json.dumps(QUERIES, indent=2) + '\n')
try:
    result = observe()
    code = 0
except BaseException as error:
    result = {'status': 'failed', 'error': repr(error), 'native_tests_run': False,
              'qualification_inferred': False}
    (OUT / 'observer-error.log').write_text(traceback.format_exc())
    code = 1
result['finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
for path in OUT.iterdir():
    if path.is_file():
        os.chmod(path, 0o600)
        with path.open('rb') as stream:
            os.fsync(stream.fileno())
print(json.dumps(result), flush=True)
raise SystemExit(code)
