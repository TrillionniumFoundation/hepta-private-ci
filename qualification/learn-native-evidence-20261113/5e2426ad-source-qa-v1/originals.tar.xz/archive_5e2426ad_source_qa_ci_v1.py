#!/usr/bin/env python3
"""Archive a completed source-QA gate while its separate caller gate continues."""
from pathlib import Path
import importlib.util
import json
import io
import stat
import tarfile

BASE = Path('/workspace/scratch/ff41dfc0f7bf/tooling')
HELPER = BASE / 'archive_bfee_native_originals_ci_v3.py'
spec = importlib.util.spec_from_file_location('exact_evidence_io', HELPER)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
OUT = BASE / 'publication/evidence-5e2426ad-source-qa-20261113-v1'
HEAD = '5e2426ad737fc5f8bef5c69e4a49f4b9a0275be4'
TREE = 'd9e8346daaa98162d583b7b5c8aad5b49cf960ed'
PREFIX = 'validation/root-5e2426ad-full-source-caller-ci-evidence-v1/'
NAMES = [
 'fullsource.json', 'fullsource.stdout.log', 'fullsource.stderr.log',
 'source-before.json', 'launch-tool.original.json', 'checkout-intent.json',
 'checkout-and-driver-receipt.json', 'resource-observation-start-v1.json',
 'qa-signal-and-emitted-failures-v1.json', 'resource-observation-after-qa-sigkill-v1.json',
]
def main():
 OUT.mkdir(exist_ok=True)
 paths = [BASE / (PREFIX + name) for name in NAMES]
 paths += [HELPER, Path(__file__),
  BASE / 'run_root_5e2426ad_full_source_caller_ci_evidence_v1.py',
  BASE / 'validation/root-bfee5aa3-full-source-caller-ci-evidence-v1/fullsource.json',
  BASE / 'validation/root-bfee5aa3-full-source-caller-ci-evidence-v1/fullsource.stderr.log',
  BASE / 'publication/evidence-bfee5aa3-native-originals-20261113-v2/publication-receipt.json']
 saved = {str(p.relative_to(BASE)): helpers.original(p) for p in sorted(set(paths))}
 gate = json.loads(saved[PREFIX + 'fullsource.json'][0])
 compare = json.loads(saved[PREFIX + 'qa-signal-and-emitted-failures-v1.json'][0])
 assert gate['status'] == 'completed' and gate['exit_code'] == -9 and gate['source_unchanged']
 assert gate['before'] == gate['after']
 assert gate['before']['head'] == HEAD and gate['before']['tree'] == TREE
 assert gate['before']['tracked_files'] == 15500
 assert gate['before']['tracked_sha256'] == '60df345e7700fc84d422370878e5af9aaf5902a12491be830b946e324992bb6b'
 assert len(compare['current']['all_observed_fail_or_error_lines']) == 1
 assert not compare['current']['has_terminal_suite_summary'] and not compare['same_last_method_line']
 target = OUT / 'originals.tar.xz'
 assert not target.exists(), 'Reconcile an existing immutable archive'
 with tarfile.open(target, 'x:xz', preset=6) as tar:
  for name,(data,stamp) in saved.items():
   entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=stat.S_IMODE(stamp['st_mode'])
   entry.mtime=stamp['st_mtime_ns']/1e9
   tar.addfile(entry,io.BytesIO(data))
 with tarfile.open(target,'r:xz') as tar:
  members=tar.getmembers()
  assert len(members)==len(saved) and {m.name for m in members}==set(saved)
  for m in members:assert m.isfile() and tar.extractfile(m).read()==saved[m.name][0]
 for name, pair in saved.items():assert helpers.original(BASE/name)==pair
 data,_=helpers.original(target)
 manifest={'schema':1,'head':HEAD,'tree':TREE,'archive':target.name,'archive_bytes':len(data),
  'archive_sha256':helpers.digest(data),'member_count':len(saved),
  'input_bytes':sum(len(v[0]) for v in saved.values()),
  'members':[{'path':name,'bytes':len(b),'sha256':helpers.digest(b),'source_stat':s} for name,(b,s) in saved.items()],
  'all_members_rechecked_exact':True,'all_originals_unchanged':True}
 verification={'schema':1,'head':HEAD,'tree':TREE,
  'qa':{k:gate[k] for k in ['status','exit_code','started','finished','elapsed_seconds','source_unchanged','command']},
  'snapshot':gate['before'],'observed_failures':compare['current']['all_observed_fail_or_error_lines'],
  'full_test_count_known':False,'final_traceback_available':False,'termination_cause_attributed':False,
  'old_bfee_has_same_last_test':False,'native_or_business_executed':False,
  'caller_gate':'separate command still running; its log/result excluded from this immutable appendix',
  'previous_evidence_head':'0786f9ae916bb245bef1d43a847bd4e81917e497'}
 helpers.write_new(OUT/'manifest.json',helpers.json_bytes(manifest))
 helpers.write_new(OUT/'verification.json',helpers.json_bytes(verification))
 readme="""# Exact 5e2426ad source QA: signal exit and an emitted subtest failure

This appendix records the completed source-QA command on 5e2426ad737fc5f8bef5c69e4a49f4b9a0275be4 / tree d9e8346daaa98162d583b7b5c8aad5b49cf960ed. It does not describe native execution.

The complete unittest discovery of all qa/b4-no-bypass/test_*.py ran from 01:45:48.037733 to 01:48:37.949933 UTC (169.911982797 seconds) and returned -9. The complete before/after physical source snapshots were equal: 15,500 tracked files, SHA-256 60df345e7700fc84d422370878e5af9aaf5902a12491be830b946e324992bb6b. No final suite count or final traceback was emitted.

Before termination, stderr did emit one explicit subtest FAIL: OriginalQ24OutcomeControlCallerTests.test_exact_product_callers_and_inventory, identifier q24_outcome_control_original_identity. This failure is retained separately from the signal exit. It must not be summarized as a run without test failures. The frozen CALLERS row includes the actual cell_q24_task_observation_control.rs caller while the old local QA tuple contains only config/state.

The last reported test differs from the earlier bfee -9 run. The complete original tail comparison and both original stderr files are retained. Available read-only resource observations are not evidence of the cause: cgroup memory files and pressure data were unavailable; the recorded child PIDs were not visible in the observer exec's proc view. Neither timeout nor OOM is inferred.

The independent authoritative caller CLI continued sequentially on this exact same frozen source. Its still-growing logs and unfinished result are deliberately excluded here. They will have a separate terminal appendix. No source, checks, budgets, test selection or compiler profile were changed and no native tests were run by this driver.

Every archived member was read back and compared byte-for-byte and original file metadata/bytes were rechecked. Prior evidence history is retained. Whole qualification remains 0/0/0.
"""
 helpers.write_new(OUT/'README.md',readme.encode())
 files=[]
 for path in sorted(OUT.iterdir()):
  b,_=helpers.original(path)
  files.append({'name':path.name,'bytes':len(b),'sha256':helpers.digest(b),
   'git_blob':helpers.hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
 print(json.dumps({'output':str(OUT),'files':files,'members':len(saved),'input_bytes':manifest['input_bytes']}))
if __name__=='__main__':main()
