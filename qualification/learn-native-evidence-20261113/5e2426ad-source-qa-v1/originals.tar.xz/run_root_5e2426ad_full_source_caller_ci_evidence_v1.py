"""Run the complete source QA suite and authoritative caller CLI on the frozen integrated source.

No Rust/native/H command is part of this driver. Each original command keeps
independent stdout, stderr, terminal status and complete source snapshots.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import traceback


REPO = Path('/workspace/scratch/ff41dfc0f7bf/hepta-current-history-guards-cloud')
OUT = Path('/workspace/scratch/ff41dfc0f7bf/tooling/validation/root-5e2426ad-full-source-caller-ci-evidence-v1')
HEAD = '5e2426ad737fc5f8bef5c69e4a49f4b9a0275be4'
TREE = 'd9e8346daaa98162d583b7b5c8aad5b49cf960ed'
CALLERS = '86cc52079c610b02d50fd5b3c2e56846ef9dc238e9afbfc4d577b9924dedd216'


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=REPO)


def snapshot():
    digest = hashlib.sha256()
    count = 0
    total_bytes = 0
    for entry in git('ls-files', '-s', '-z').split(b'\0'):
        if not entry:
            continue
        meta, name = entry.split(b'\t', 1)
        path = REPO / os.fsdecode(name)
        if path.is_symlink():
            contents = os.fsencode(os.readlink(path))
            content_digest = hashlib.sha256(contents).digest()
            total_bytes += len(contents)
        else:
            with path.open('rb') as stream:
                content_digest = hashlib.file_digest(stream, 'sha256').digest()
                total_bytes += os.fstat(stream.fileno()).st_size
        digest.update(meta.split()[0] + b'\0' + name + b'\0' + content_digest)
        count += 1
    return dict(head=git('rev-parse', 'HEAD').decode().strip(),
                tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
                status=git('status', '--porcelain=v1', '--untracked-files=all').decode(),
                tracked_files=count, tracked_bytes=total_bytes,
                tracked_sha256=digest.hexdigest(),
                callers_sha256=hashlib.sha256((REPO / 'CALLERS.toml').read_bytes()).hexdigest())


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


assert OUT.is_dir() and not (OUT / 'result.json').exists()
before = snapshot()
assert before['head'] == HEAD and before['tree'] == TREE
assert not before['status'] and before['callers_sha256'] == CALLERS
save(OUT / 'source-before.json', before)
result = dict(status='running', started=utc(), repo=str(REPO), source=before,
              driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              execution='all qa/b4-no-bypass/test_*.py then complete authoritative CLI at exact5e2426ad; sequential; continue after gate failure; no timeout, retry or source edits',
              native_tests_executed=0, stages=[])
save(OUT / 'result.json', result)
environment = dict(os.environ)
environment['PYTHONDONTWRITEBYTECODE'] = '1'
environment['PYTHONUNBUFFERED'] = '1'
commands = [('fullsource', ['python3', '-m', 'unittest', 'discover', '-s', 'qa/b4-no-bypass', '-p', 'test_*.py', '-v']), ('fullcallers', ['python3', 'scripts/verify_hepta_callers.py', 'verify', '--root', str(REPO)])]
for name, argv in commands:
    record = dict(name=name, command=argv, cwd=str(REPO), started=utc(), status='starting')
    result['stages'].append(record)
    save(OUT / 'result.json', result)
    start = time.monotonic()
    try:
        record['before'] = snapshot()
        assert record['before'] == before, 'source differs before original gate'
        with (OUT / (name + '.stdout.log')).open('xb') as stdout, (OUT / (name + '.stderr.log')).open('xb') as stderr:
            child = subprocess.Popen(argv, cwd=REPO, env=environment, stdout=stdout, stderr=stderr)
            record.update(status='running', pid=child.pid)
            save(OUT / (name + '.json'), record)
            save(OUT / 'result.json', result)
            print(json.dumps({'stage': name, 'pid': child.pid, 'started': record['started']}), flush=True)
            record.update(exit_code=child.wait(), status='completed')
    except BaseException as error:
        record.update(status='driver_failed', error=repr(error))
        (OUT / (name + '.driver-error.log')).write_text(traceback.format_exc())
    finally:
        record.update(finished=utc(), elapsed_seconds=time.monotonic() - start)
        try:
            record['after'] = snapshot()
            record['source_unchanged'] = record['before'] == record['after'] == before
        except BaseException as error:
            record['snapshot_error'] = repr(error)
            record['source_unchanged'] = False
        record['files'] = {}
        for path in sorted(OUT.glob(name + '.*.log')):
            with path.open('rb') as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            record['files'][path.name] = dict(bytes=path.stat().st_size, sha256=digest)
        record['passed'] = record['status'] == 'completed' and record.get('exit_code') == 0 and record.get('source_unchanged') is True
        save(OUT / (name + '.json'), record)
        save(OUT / 'result.json', result)
        print(json.dumps({'stage': name, 'status': record['status'], 'exit_code': record.get('exit_code'),
                          'source_unchanged': record.get('source_unchanged'),
                          'elapsed_seconds': record['elapsed_seconds']}), flush=True)
result.update(status='completed', finished=utc(), after=snapshot())
result['source_unchanged'] = result['source'] == result['after']
result['all_gates_passed'] = result['source_unchanged'] and all(record['passed'] for record in result['stages'])
save(OUT / 'result.json', result)
print('ROOT_5E2426AD_FULL_SOURCE_CALLER_GATES_TERMINAL ' + json.dumps(result), flush=True)
raise SystemExit(0 if result['all_gates_passed'] else 1)
