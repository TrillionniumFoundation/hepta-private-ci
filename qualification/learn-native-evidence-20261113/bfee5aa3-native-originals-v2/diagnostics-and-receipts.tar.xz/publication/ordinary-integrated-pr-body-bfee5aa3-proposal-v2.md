## Why this change

The concrete Q24 aggregate already owns real learning stages and bounded work
lanes. The missing link is ordinary daemon assembly and retention of original
evidence across A, learning, CURRENT/C and process restart.

This PR connects the explicit `q24-initial` and `q24-post-a` product entries:

**A → original Decision and independently signed Outcome → frozen Dataset →
actual Training → independent B → Adopt or evaluated NoUpdate → CURRENT and
subsequent task C → completed-history recovery in new daemon and Root processes.**

> **Draft / unqualified: Adopt / evaluated post-B NoUpdate / whole daemon+Root
> cold recovery remain 0 / 0 / 0.** Snapshot: **2026-11-13 01:15:03 UTC**.
> bfee caller CLI and seven-package fix passed; full source QA ended `-9`,
> cause unestablished. Native binding6, reducer2 and FS2 passed; A failed in
> **4.881 s** with a conflict-or-uncertain-ACK message. Whole-chain v3 remains
> prepared only. Predecessor results do not qualify this amendment.

#6006 already contains real aggregate owners. #6018 fixes the strict generic
caller-proof locator. The #5981 counterexample assertion-order correction
remains test sequencing, separate from Root-backed persistent refusal.

## Production changes

### 1. Produce and retain A's original evidence

Ordinary `main` now invokes the explicit Initial and post-A assemblers before
running the selected production launch. Initial assembly consumes the actual
Root session, sealed deployment, existing original files, model, Artifact and
FinalUse inputs. Ledger installation consumes Root-activated trust and its fixed
Generator/Observer bindings; deployment JSON does not bootstrap its own trust
root or select a replacement signer.

The task's actual producer writes the original Decision. An opt-in control query
exposes only the original task observation DATA needed by the independent
Observer. The Observer submits its own signed terminal Outcome through the
bounded control lane. Task success, a new run, or a new machine is not converted
into a reward, an Outcome signature, or evidence of evaluator independence.

The original Objective append/sync publication is retained by Root before task
execution, with readiness, generation and AuthBus checks around the handoff.
Accepted control connections are owned and joined during the original shutdown
grace. Source capture requires actual runtime drain, connection completion and
owner release; a configuration flag or an aborted task cannot supply that fact.
Post-A learning is assembled from retained evidence after A's temporary runtime
has exited. The explicit material-session fresh/recovery CLI paths preserve the
original physical checkpoint and require actual old-writer retirement before
a new incarnation can adopt it.

The original RunStart generation is now checked against the original
publisher's actual Running incarnation: a nonzero `spawn_generation` must have
an overflow-checked successor, and the snapshot must carry that generation and
its `objective_fence`. This is independent of the Cell/model target generation.
Client and Root physical readback share that narrow binding check; all existing
scope, signature, trust, physical-file, session and refusal checks remain.
Cold readback uses the retained original publisher identity, never the new
recipient's generation. Six binding tests use real Fleet Starting→Running
transitions and explicit wrong-generation, foreign-fence and overflow cases;
they do not claim authentication or physical Root authority.

Initial startup separates PREPARED descriptor custody from an initialized or
captured Cell history. The actual daemon writer initializes its original
witness; Root then checks that same descriptor and the complete baseline.
Reserve-stage Cell and Ledger registration require the original unwritten
Generation target. Publish and later capture still require actual genesis.
No fixture header or empty-file observation substitutes for either phase.

Fresh filesystem handoff also provisions the fixed `run_root/prompt-runtime`
child before releasing the original control directory. A preexisting child is
refused before ownership changes; the new physical directory is pinned and
assigned only to the exact daemon UID/GID with mode 0700. The Root control
parent remains mode 2750. Recovery reuses that same original child without
creating or migrating one, and does not gain permission to create arbitrary
children under the Root parent.

### 2. Assemble learning from the retained original task

The historical task route joins the original RunStart publication, Source,
Automation delivery, Cell, Ledger and witness cuts. Read-only readers use
existing original descriptors and canonical physical replay; recovery does not
reopen an old writer or repair a partial tail to manufacture a complete record.
Current Root context and current trust remain separate checks from the retained
historical facts.

The post-A daemon reads that actual task receipt, freezes the Dataset with the
original signer, releases the freeze writer, and obtains Root's typed late-install
acknowledgement. Only then does it consume the four original Learning, Model,
publication and independent-B handoffs. `assemble_q24_learning` now has a real
product caller, and the actual remote B client is installed before the learning
iteration starts.

Initial owner assembly and each historical stage execute under the same bounded
Prepared operation and original Trainer borrow. Before/after physical, trust,
checkpoint and cancellation checks remain in place, including error paths.
This removes repeated nested reads without cross-operation caching or increases
to the original 64 historical reads, 32 B frames, 500ms frame limits, or absolute
session deadlines.

### 3. Give B independent data and decision authority

B runs inside the actual Root custodian with fixed existing files, a signed
preregistered protocol, and Root-admitted role/controller bindings. Independent
held-out data ownership, Generator policy provenance, Observer evidence and
Evaluator decision authority are checked explicitly. A different PID, UID,
run or machine supplies process isolation only; it does not establish those
independence properties. Evaluator keys and held-out labels are not handed to
the learner.

The candidate is supplied after actual Training. The original Trainer exports
candidate DATA and measured Training work; Root binds it to the authenticated
Training cut, job, Dataset rows, model/head shape, steps and elapsed work.
Candidate resource claims cannot be copied from the fixed control arm or
inferred from a manifest declaration.

`PrepareCandidate` uses the label-free benchmark and produces a challenge for
the actual Generator's durable plan claim. The independent Source receives the
actual candidate through its original bounded handoff, produces its policy and
Observer-signed business evidence in the required order, and submits the fixed
source files. The first held-out/OPE release and evaluation occur in `Complete`
after that admission. Raw outcome units and policy probabilities are preserved;
Q24 scores are not normalized into probabilities or invented labels.

The product runner re-reads the actual physical holdout consumption owner before
and after release. The Model service borrows native evaluation evidence from
that same Root custodian; serialized receipts, public receipt fields and generic
CAS implementations do not become native evaluation authority. The learner
receives an opaque current observation and signed evidence.

### 4. Carry the actual decision into CURRENT and C

The supervised continuation retains the original stage owners, material, trust,
history receipt and successor handoff. Adopt uses the actual trained material,
independent decision, Artifact/Selection inputs and FinalUse checks to publish
through Root's original CURRENT CAS and configure the subsequent task C.
Evaluated NoUpdate retains the original model and publishes the actual new task
CURRENT for C through `OwnerDrainedSameModel`. It still requires B's completed
decision, the independent Selection, a real publication CAS and the resulting
C/NextUse relationship. Retaining model weights does not retain A's task/run,
writer or Generation CURRENT.

**TrainingNoUpdate is a distinct branch.** It may legitimately skip B, but it
does not satisfy the evaluated-NoUpdate qualification and is not substituted for
that parent fixture. Missing B, missing source evidence, and an uncertain write
remain explicit failures; they are not translated into NoUpdate.

The real process fixtures drive the ordinary binaries, independent Source and
Observer, Root handoffs, actual Artifact signatures, C execution and process
retirement. They retain the original files for the later cold phase rather than
keeping A or the old Source process alive to conceal a handoff gap.

The test-only custody path also retains those original directories on early
return or scope exit, before a successful fixture holder can be returned.
`OriginalEvidenceDirectory` covers A's protected/runtime directories, the post-A
model witness and B's private business directory. It keeps the same directory
and inodes and emits a custody-only path marker; it does not copy evidence,
replace the original error, change a result or deadline, or manufacture a
successful task. The new helpers are explicitly restricted to test builds.

## Persistent refusal, first acceptance, and acknowledgement ordering

Root refusal records are armed before the original authority/primary-file
observation. The complete Root callback, physical postchecks and original end
check must finish before the exact-attempt CAS can reach Ready. An uncertain
read, a crash in the armed interval, or observed corruption cannot be converted
into successful recovery by restoring only old primary bytes.

First publication acceptance is created only by the actual first
Prepared→Published transition under that same refusal arm. A repeated Publish
preserves an existing acceptance verbatim. An older Published record with no
first acceptance cannot be backfilled. The original verification time and
reserved/Selection/Published/Generation/consumer binding are immutable.

Fresh terminal acceptance joins the actual completed learning and publication
facts while the original post-A daemon and Root session are still live. It does not require C to
be retired first. The later private completed-history route admits the new
recipient, checks actual old-process retirement, captures the existing completed
C, and then reads the Finalized cut. That route opens no old Delivery, Trainer,
Model or C writer and grants no execution, new Selection or signing authority.
The evaluated-NoUpdate history branch checks the genuine same-model C
publication and its first acceptance, as well as the full retained-model
NextUse projection. An Initial-only CURRENT cannot satisfy that history.

Completed-history recovery uses the first facts actually committed while the
original signatures and work window were valid. Old records without those
facts are refused. After the original writer lease expires, the new recipient
can obtain only completed-history evidence under its current Root session,
trust/revocation checks and original physical cuts; it cannot extend the old
work window, re-sign receipts or turn an expired receipt into new execution
authority. The daemon takes this branch before opening the old Freeze,
Delivery, Trainer or Model owners and publishes completion DATA only after
actual C Finalized and Root Ready checks. Missing DATA remains missing.

The terminal acknowledgement is also ordered explicitly. Only the consumed
one-shot Root request, a validated reply and the delivery postchecks produce the
typed acknowledgement stored in State. The zero-payload control query returns
that existing DATA; it does not send another Accept/History request. The parent
fixture waits for both the immutable physical first fact/Ready record and the
matching acknowledgement, then physically rechecks them before stopping the
daemon. Disk Ready alone cannot authorize an early stop before ACK receipt.
The independent B Source likewise waits for its terminal finalized notice before
returning and exiting.

Component corruption tests keep the successful baseline, first bad-byte read,
and restored-byte read as separate assertions. Same-handle poisoning and
Root-backed cross-process refusal have separate scopes; the former is not
presented as a durable cold fence. These mechanisms do not claim protection
against jointly rolling back the independent authority/refusal state itself.

## Review map

| Area | Primary production files |
| --- | --- |
| Ordinary entry and deferred owner installation | `main.rs`, `production_initial_q24.rs`, `production_post_a_q24.rs`, `production_post_a_q24_handoff.rs` |
| A evidence and runtime release | `objective_run_start_retention.rs`, `cell_q24_task_ledger.rs`, `control_source_capture.rs`, `runtime.rs` |
| Initial phase and descriptor custody | `authority_host_historical_cell_files.rs`, `authority_host_historical_cell_registration.rs`, `authority_host_historical_ledger_registration.rs`, `authority_host_initial_peer_runtime.rs` |
| Fresh filesystem custody and durable prompt state | `root_agentd_filesystem.rs`, `state.rs`, `prompt_runtime.rs` |
| Original publisher Running binding | `objective_runtime.rs`, `root_generation_initial_run_start.rs`, `authority_host_run_start_inputs.rs` |
| Frozen historical learning | `authority_host_historical_task.rs`, `cell_q24_learning_owner_inputs.rs`, `cell_q24_learning_historical_operation.rs` |
| Independent B and actual Training binding | `authority_host_q24_evaluation_registration.rs`, `authority_host_q24_evaluation_prepare.rs`, `authority_host_q24_evaluation_execute.rs`, `cell_q24_training_b_plan.rs` |
| B Source ordering and final handoff | `authority_host_q24_evaluation_source_flow.rs`, `authority_host_q24_evaluation_source_serve.rs`, `root_independent_b_notice.rs` |
| CURRENT/C and immutable acceptance | `production_post_a_continuation.rs`, `authority_host_generation_publication_transport.rs`, `authority_host_publication_refusal.rs`, `authority_host_publication_completed.rs` |
| Completed-history read and typed ACK | `authority_host_completed_observation.rs`, `root_completed_learning_history.rs`, `state_q24_completed_history.rs`, `ordinary_q24_cold_acceptance_data_tests.rs` |

Paths in the table are under `codex-rs/hepta-agentd/src/`. Parser, physical-store,
protocol and evaluator changes are in their corresponding library crates.
`CALLERS.toml` and source-closure tests record the real new production callers
and preserve unknown-receiver refusal and the existing ordered checks.

## Current source and validation status

**Evidence snapshot: 2026-11-13 01:15:03 UTC.** Keep this PR Draft. Each result
belongs to its named source; later evidence requires an explicit update.

| Proposed source | Exact identity |
| --- | --- |
| Local HEAD | `bfee5aa363cb63897c28c8f74fd6b167de5e859b` |
| Tree | `d24d13a0d716036319a6b814dd89b8e913689b00` |
| Immutable remote object | [`3a26e6e9baba163c31d395e69e114af6a5c97efb`](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/3a26e6e9baba163c31d395e69e114af6a5c97efb), same tree |
| Complete snapshot | 15,497 files; SHA256 `dfed7872d8cb0158e556de66d1499fbc10d03bad19c6038874eaefe0d2ffd847` |

Two test-only stages remain separate:

- **557:** local `14aaf469` → remote `dd979d4a`, tree `93367ebe`. Before owners
  open, Circuit uses the declared Source lease. Real reducer tests cover 2 s
  delay and 60 s/120 s boundaries; observation time/deadlines stay fixed.
- **558:** local `bfee5aa3` → remote `3a26e6e9`, tree `d24d13a0`. Keeps Adopt cold
  and adds evaluated-NoUpdate cold through the same actual-process helper.
  Both require actual B evaluation and keep eight-minute watchdogs.

Source audit: `tooling/publication/ordinary-integrated-after-556/`; both
parents/messages/trees GET-verified, `next_index=559`, `inflight=null`.

| Gate / source | Observed result |
| --- | --- |
| **bfee complete caller CLI** | **PASS**, exit 0, **700.3409369 s**; full index, unchanged source. |
| **bfee full source QA** | **Exit -9**, 186.2999167 s; unchanged source, cause unestablished. No complete QA PASS. |
| **bfee H scoped fix v1** | **Preflight failed before Rust**: nine tracked archives missing despite clean status; skip-worktree metadata observed. No compile/tests. |
| **bfee H recovery / fix v2** | **PASS**, exit 0 / **114.6773889 s**, 01:01:30.829–01:03:25.507 UTC; complete 15,497/dfed source unchanged, empty `fix.patch`. Test compilation is not test execution. |
| **bfee native A driver v2** | Binding **6 PASS**, reducer **2 PASS**, filesystem **2 PASS**; A **0 PASS / 1 FAIL, 4.881 s**. Driver 01:06:41.403–01:09:48.228 UTC / **186.824275 s**, unchanged source; both cleanup stages exit 0. |
| **bfee whole chain** | v3 prepared only, not uploaded/launched. No Adopt, evaluated-NoUpdate, cold, Root48, seven-library or hosted-check PASS. |
| **fbf predecessor**, tree `7b5104c6` | Seven-package fix exit 0 / 113.191 s; **926/926 source QA PASS**; full caller **PASS** / **803.9089727 s**; binding **6 PASS**, filesystem **2 PASS**, A **0 PASS / 1 FAIL, 2.905 s**. These results do not transfer to bfee. |

Current bfee A reports `ordinary original Objective returned conflict or
uncertain ACK; no inferred execution`. This test message combines Conflict and
AcknowledgementLost; it does not establish a timeout or successful execution.
Initial readiness completed in **56.525 ms**. Both child status-9 exits were
failure cleanup. Raw records are
`tooling/validation/root-bfee5aa3-observed-progress-v2/native-result-original.json`
and `original-ordinary-a.xml` in that directory. The next cause requires original
business DATA and the preserved reply branch, not inference from the message.

### Observed predecessor failure

fbf A reported `original Circuit source: Circuit task needs original owner
reconciliation`; both child status-9 exits were cleanup. Archived DB/WAL DATA
records `max_elapsed_ms=1000`, creation at `1794528912455`, first Advance at
`1794528915335` (**2,880 ms later**), revision 1, `stop_reason=deadline`, one
cancelled activation and only Created / applied-Advance events. Original archive
and copied durable DB/WAL stayed unchanged; only private SHM cache changed.

**Source analysis**, separate from the DB observations, connects that stop and
lack of dispatch to missing input and `Missing → reconciliation`. Stage 557
fixes the declaration; its reducer tests now pass, while A remains failing.
No 500 ms frame, 64-read/32-frame budget, signature window or writer lease grows.

### Original evidence and remaining gates

The [fbf originals at immutable `5b21d40e`](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/5b21d40eed1178b8861724e88908e5f619f38bc5/qualification/learn-native-evidence-20261113/fbf2cc0a-complete-originals-v1)
include native/JUnit and full source/caller records, plus the
[Circuit DATA observation](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/5b21d40eed1178b8861724e88908e5f619f38bc5/qualification/learn-native-evidence-20261113/fbf2cc0a-complete-originals-v1/circuit-data-observation.json).
`tooling/publication/evidence-5d-fbf-originals-20261113-v1/publication-receipt.json`
records remote-byte verification; 5d evidence stays separately identified.
The [bfee manifest at immutable `226a4bbd`](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/226a4bbd27728bb87b32de878ce87683970cb985/qualification/learn-native-evidence-20261113/bfee5aa3-source-gates-v1/manifest.json)
retains the unsuccessful QA process and successful caller CLI; its receipt is
`tooling/publication/evidence-bfee5aa3-source-gates-20261113-v1/publication-receipt.json`.

H v1 originals remain intact. Actual v2 hydration created only nine verified
archives before compilation; source-unchanged applies to that complete candidate,
not incomplete v1. The original
`tooling/validation/root-bfee5aa3-observed-progress-v2/compile-result-final.original.json`
is 5,009 B, SHA256 `a778a419714d86407d766a799636687fc017073e2b6194e72f0d0093f5ba679d`.

The full schedule is **A → Adopt → actual post-B NoUpdate → Adopt cold →
evaluated-NoUpdate cold → Root48 → seven libraries → full source QA → caller
CLI**. Root48 preserves the original 45 names, PREPARED Cell case and two
acceptance negatives; FS2 is separate. UID1000 builds precede actual UID0 tests.
Exact rosters, fresh JUnit and zero retries remain mandatory. Both cold watchdogs
are 480 s; product 60 s/120 s/300 s bounds stay fixed. Failures retain originals
and do not suppress later gates.

Complete source QA, successful A, both decisions/cold paths, Root48, seven
libraries and hosted checks remain outstanding. Source/component passes cannot
substitute. Qualification remains **0 / 0 / 0**.
