"""Prepare an unlaunched exact-source compiler driver from reviewed originals."""

import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
old = (ROOT / "root_bfee5aa3_scoped_fix_v1.py").read_text()
reviewed = (ROOT / "root_bfee5aa3_scoped_fix_v2.py").read_text()
assert hashlib.sha256(reviewed.encode()).hexdigest() == "6855c20cdc77efa47dbba273da6ca1893666cb11c66b21b5090caa9e4daecad3"
parsed = ast.parse(reviewed)
functions = {
    node.name: ast.get_source_segment(reviewed, node)
    for node in parsed.body
    if isinstance(node, ast.FunctionDef)
}


def replace_once(source, before, after):
    assert source.count(before) == 1, before[:100]
    return source.replace(before, after, 1)


expected = json.loads(
    (ROOT / "validation/root-bfee5aa3-native-inputs-v1/source-hydration-expected.json").read_text()
)
archives = expected["observed_missing_archive_files"]
assert len(archives) == 9
archive_snapshot = {
    "head": expected["head"],
    "tree": expected["tree"],
    "status": "",
    "tracked_files": expected["tracked_files"],
    "tracked_sha256": expected["tracked_sha256"],
    "hash_format": expected["hash_format"],
}
prefix = old[: old.index("def utc():")]
prefix = prefix.replace("traceback,shutil", "traceback,shutil,stat")
prefix = prefix.replace("root-bfee5aa3-scoped-fix-v1", "root-__NEXT_TAG__-scoped-fix-v1")
prefix = prefix.replace(expected["head"], "__NEXT_HEAD__")
prefix = prefix.replace(expected["tree"], "__NEXT_TREE__")
prefix += (
    "PRIOR_HEAD=" + repr(expected["head"]) + "\n"
    "ARCHIVE=Path('/home/qq/hepta-learn-ff41-archived-source-bfee5aa3-before-__NEXT_TAG__-v1')\n"
    "ARCHIVE_EXPECTED=" + repr(archive_snapshot) + "\n"
    "HYDRATION_EXPECTED={'head':HEAD,'tree':TREE,'tracked_files':__NEXT_COUNT__,'tracked_sha256':'__NEXT_SNAPSHOT__','observed_missing_archive_files':"
    + repr(archives)
    + "}\n"
)
hydrate = functions["hydrate_confirmed_archives"]
start = hydrate.index("        prior_bytes=")
end = hydrate.index("        assert HYDRATION_EXPECTED['head']==HEAD", start)
hydrate = hydrate[:start] + hydrate[end:]
hydrate = hydrate.replace(
    "Create only nine confirmed missing immutable archives; no index/config/ref edits or prior evidence changes. This is source hydration, not unchanged source relative to v1.",
    "Inspect the complete checked-out source; create only an observed omitted subset of the nine previously verified unchanged archives. No overwrite, index/config edit or prior-evidence mutation. Compilation starts only after the complete exact candidate exists.",
)
hydrate = replace_once(hydrate, "        assert HYDRATION_EXPECTED['tracked_files']==15497\n", "")
hydrate = replace_once(
    hydrate,
    "        assert len(entries)==15497\n        assert missing==[row['path'] for row in expected],'missing tracked set or order differs from the nine observed archives'\n",
    "        assert len(entries)==HYDRATION_EXPECTED['tracked_files']\n"
    "        allowed={row['path'] for row in expected}\n"
    "        assert set(missing)<=allowed,'checkout omitted an unapproved tracked path'\n"
    "        expected=[row for row in expected if row['path'] in missing]\n"
    "        assert missing==[row['path'] for row in expected],'missing archive order differs'\n",
)
hydrate = hydrate.replace(
    ",prior_v1_result_sha256=PRIOR_RESULT_SHA256", ""
).replace(
    "existing fbf archive is not the complete original frozen source",
    "bfee archive is not the complete frozen predecessor",
).replace("all_nine_prechecked=True", "all_missing_prechecked=True")
start = hydrate.index("        assert (PRIOR_OUT/'result.json').read_bytes()==prior_bytes")
end = hydrate.index("        for item in prepared:\n", start)
hydrate = hydrate[:start] + hydrate[end:]
hydrate = hydrate.replace(
    ",prior_v1_evidence_unchanged=True", ""
).replace(
    "Only the subsequent complete candidate compile before/after; v1 lacked nine archives.",
    "Only the complete candidate compile before/after; any checkout omissions and create-only hydration are recorded separately.",
)
assert "PRIOR_OUT" not in hydrate and "prior_bytes" not in hydrate
helpers = "\n\n".join(
    functions[name]
    for name in (
        "utc", "git", "snapshot", "recovery_log", "open_directory", "relative_parent",
        "stamp", "checked_original_file", "require_same_directory", "require_same_parent",
    )
) + "\n\n" + hydrate + "\n\n"
main = old[old.index("OUT.mkdir(parents=True,exist_ok=False)"):]
main = main.replace("root-bfee5aa3-source.bundle", "root-__NEXT_TAG__-source.bundle")
main = main.replace("candidate-bfee5aa3", "candidate-__NEXT_TAG__")
main = main.replace("len(data)==3348", "len(data)==__NEXT_BUNDLE_BYTES__")
main = main.replace("df4c76b4b462936fe791619d983b7535e2595d60e4a3b22f2e92c737aea978ba", "__NEXT_BUNDLE_SHA256__")
main = main.replace("fbf2cc0a3eaf4ca1e720300c306ff6ad38517449", expected["head"])
main = main.replace("7b5104c68e65c4fec111f21d3aa8f5ba04984e9d", expected["tree"])
main = main.replace("/home/qq/hepta-learn-ff41-archived-source-fbf2cc0a-before-bfee5aa3-v1", "/home/qq/hepta-learn-ff41-archived-source-bfee5aa3-before-__NEXT_TAG__-v1")
main = main.replace("ROOT_BFEE5AA3_SCOPED_FIX", "ROOT___NEXT_TAG_UPPER___SCOPED_FIX")
main = replace_once(
    main,
    " assert not git(REPO,'status','--porcelain').strip(),'stable worktree has changes'\n",
    " assert not git(REPO,'status','--porcelain').strip(),'stable worktree has changes'\n"
    " result['predecessor_complete']=snapshot(REPO)\n"
    " assert result['predecessor_complete']==ARCHIVE_EXPECTED,'predecessor physical source differs'\n",
)
main = replace_once(
    main,
    "  assert not git(archive,'status','--porcelain').strip()\n",
    "  assert not git(archive,'status','--porcelain').strip()\n"
    "  assert snapshot(archive)==ARCHIVE_EXPECTED,'new archive is not the complete predecessor'\n",
)
main = replace_once(
    main,
    " before=snapshot(REPO);assert before['head']==HEAD and before['tree']==TREE and not before['status'],'candidate source identity differs'\n",
    " result['source_hydration']=hydrate_confirmed_archives()\n"
    " before=snapshot(REPO);assert before['head']==HEAD and before['tree']==TREE and not before['status'],'candidate source identity differs'\n"
    " assert before['tracked_files']==HYDRATION_EXPECTED['tracked_files'] and before['tracked_sha256']==HYDRATION_EXPECTED['tracked_sha256'],'complete candidate digest differs'\n",
)
main = replace_once(
    main,
    " result['disk_free']=shutil.disk_usage(TARGET).free;assert result['disk_free']>=4*1024**3,'insufficient compiler storage'\n",
    " result['disk_free']=shutil.disk_usage(TARGET).free;assert result['disk_free']>=4*1024**3,'insufficient compiler storage'\n"
    " for name,expected_size,expected_sha in [\n"
    "  ('root-bfee5aa3-scoped-fix-v2',5009,'a778a419714d86407d766a799636687fc017073e2b6194e72f0d0093f5ba679d'),\n"
    "  ('root-bfee5aa3-native-tests-v2',36858,'b6257a1bf209e3e24497a1efe18ef4084a4db9cb3fb2cd87cad5c468ea7f5f1e')]:\n"
    "  previous=(BASE/'validation'/name/'result.json').read_bytes()\n"
    "  assert len(previous)==expected_size and hashlib.sha256(previous).hexdigest()==expected_sha,'predecessor terminal original differs'\n"
    "  terminal=json.loads(previous);assert terminal['status']=='completed' and terminal['source_unchanged'] is True\n"
    "  (OUT/(name+'.original.json')).write_bytes(previous)\n",
)
template = prefix + helpers + main
target = ROOT / "root_original_initial_progress_scoped_fix_template_v1.py"
with target.open("x") as out:
    out.write(template)
# Placeholder identifiers intentionally prevent accidental execution.
ast.parse(template)
print(json.dumps({
    "path": str(target), "bytes": len(template.encode()),
    "sha256": hashlib.sha256(template.encode()).hexdigest(),
    "status": "prepared_only_not_uploaded_or_launched",
    "scope": "Template structural preparation; no candidate source identity is frozen yet.",
}))
