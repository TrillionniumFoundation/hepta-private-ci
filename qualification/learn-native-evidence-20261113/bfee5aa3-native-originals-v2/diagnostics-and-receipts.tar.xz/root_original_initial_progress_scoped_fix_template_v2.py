import os,sys,json,hashlib,subprocess,time,datetime,fcntl,traceback,shutil,stat
from pathlib import Path
BASE=Path('/home/qq/hepta-learn-ff41-tools')
SOURCE=Path('/home/qq/hepta-learn-ff41-root-source-integration-v1')
REPO=Path('/home/qq/hepta-learn-ff41-native-root-279deb99-v1')
TARGET=Path('/home/qq/hepta-learn-ff41-target-f73704ac-v1')
OUT=BASE/'validation/root-__NEXT_TAG__-scoped-fix-v1'
HEAD='__NEXT_HEAD__'
TREE='__NEXT_TREE__'
CMD=[str(BASE/'bin/just'),'fix','--locked','--offline','-p','codex-hepta-agentd','-p','codex-hepta-agent-protocol','-p','codex-hepta-learning-ledger','-p','codex-hepta-contracts','-p','codex-hepta-neuron','-p','codex-hepta-intelligence-eval','-p','codex-hepta-learning-artifacts']
PRIOR_HEAD='bfee5aa363cb63897c28c8f74fd6b167de5e859b'
ARCHIVE=Path('/home/qq/hepta-learn-ff41-archived-source-bfee5aa3-before-__NEXT_TAG__-v1')
ARCHIVE_EXPECTED={'head': 'bfee5aa363cb63897c28c8f74fd6b167de5e859b', 'tree': 'd24d13a0d716036319a6b814dd89b8e913689b00', 'status': '', 'tracked_files': 15497, 'tracked_sha256': 'dfed7872d8cb0158e556de66d1499fbc10d03bad19c6038874eaefe0d2ffd847', 'hash_format': 'mode NUL path NUL SHA256(content), git index order'}
HYDRATION_EXPECTED={'head':HEAD,'tree':TREE,'tracked_files':__NEXT_COUNT__,'tracked_sha256':'__NEXT_SNAPSHOT__','observed_missing_archive_files':[{'path': 'qualification/cell-platform-fixtures-20261108/native-and-ci-evidence.tar.gz', 'git_mode': '100644', 'blob': '3a40fd7c802df1a9cc4e7dd284ebd96bcd5e3c62', 'bytes': 2896268, 'sha256': '11ba543a46a6150bbd89c2ac5513bea56660c69358ddb348122b4bae57533fe7'}, {'path': 'qualification/cell-research-stages-20261108/followthrough-20261108/verify1-independent-audit.tar.gz', 'git_mode': '100644', 'blob': '807c2dc3c1088f916f11a235378bfdc051eda955', 'bytes': 1177531, 'sha256': 'ac8863c2893869db846801d825e89863cf168e87782571dd009733b921643de0'}, {'path': 'qualification/cell-research-stages-20261108/native-ci-routing-20261108/raw-ci-logs.tar.gz', 'git_mode': '100644', 'blob': 'cea174270290297bd72c4e2cc126ebddbb2cf741', 'bytes': 1766809, 'sha256': '3d4c805e3008b36d147fa750c36b301f20b82ca9f876f943c63ae24fa01fa02c'}, {'path': 'qualification/hcsn-localization-trainer-20261108/hcsn-trainer-native-evidence.zip', 'git_mode': '100644', 'blob': '3c427d48aa759a4a4bad8258c951fbb94c0c616d', 'bytes': 1843158, 'sha256': '27d4f684ba9df1b9dec5c518377c50f80239d2a3f4998045f88939593fa01bcc'}, {'path': 'qualification/memory-cell-mem1/raw-evidence-v1.tar.xz', 'git_mode': '100644', 'blob': '6f312b46ecae7f0d314b55504b0d7a5c75e3524b', 'bytes': 1765660, 'sha256': 'df21f41c562a695cf76419521a6c73a99539571ee40b1b7b4315323ce38c6d15'}, {'path': 'qualification/ordinary-owner-assembly-20261111/native-evidence/v5/original-records.tar.xz', 'git_mode': '100644', 'blob': '891109a74a5484451195bdaed03629de505dc131', 'bytes': 1894408, 'sha256': 'b887df69055e182cae12aa6c588c91313c50c1761fb9c4323ed8621a5472e0e9'}, {'path': 'qualification/ordinary-owner-assembly-20261111/native-evidence/v6/original-records.tar.xz', 'git_mode': '100644', 'blob': '6535c15dcc3d795a22a26ced34861394ff98ec2e', 'bytes': 1297388, 'sha256': 'aaff3176e000652f54ac97308714aec0e94079ce6b731be5ec45f4622441394a'}, {'path': 'qualification/pin-utils-parent-backports-20261108/native-evidence.tar.gz', 'git_mode': '100644', 'blob': '506b81500b5f81d5eb8bee8ad610f3620696bca3', 'bytes': 2767574, 'sha256': '4c5cfe6d68e48fdc6f065ac7bbd2d0ee852a5b896f8d15b997f5fa8189e63c11'}, {'path': 'qualification/pred1/evidence/pred1_evidence.tar.xz', 'git_mode': '100644', 'blob': '3f72098ddf57a704aef4d5f325dd7770b6f89694', 'bytes': 5959884, 'sha256': '08322f8fe581f84e7e6ea31f705c5c8554610930a5f531e15294de14e331219e'}]}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def git(repo,*args):return subprocess.check_output(['/usr/bin/git',*args],cwd=repo,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})

def snapshot(repo):
 h=hashlib.sha256();count=0
 for entry in git(repo,'ls-files','-s','-z').split(b'\0'):
  if not entry:continue
  meta,path=entry.split(b'\t',1);mode=meta.split()[0];p=repo/os.fsdecode(path)
  raw=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
  h.update(mode+b'\0'+path+b'\0'+hashlib.sha256(raw).digest());count+=1
 return {'head':git(repo,'rev-parse','HEAD').decode().strip(),'tree':git(repo,'rev-parse','HEAD^{tree}').decode().strip(),'status':git(repo,'status','--porcelain').decode(),'tracked_files':count,'tracked_sha256':h.hexdigest(),'hash_format':'mode NUL path NUL SHA256(content), git index order'}

def recovery_log(value):
    pending=OUT/'source-hydration.json.tmp'
    with pending.open('w') as stream:
        json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    os.replace(pending,OUT/'source-hydration.json')
    directory=os.open(OUT,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:os.fsync(directory)
    finally:os.close(directory)

def open_directory(path):
    assert path.is_absolute() and '..' not in path.parts
    flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
    current=os.open('/',flags)
    try:
        for part in path.parts[1:]:
            following=os.open(part,flags,dir_fd=current)
            os.close(current);current=following
        return current
    except BaseException:
        os.close(current);raise

def relative_parent(root,relative):
    path=Path(relative)
    assert not path.is_absolute() and path.parts and all(part not in ('.','..') for part in path.parts)
    assert path.as_posix()==relative
    current=os.dup(root)
    try:
        for part in path.parts[:-1]:
            following=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=current)
            os.close(current);current=following
        return current,path.name
    except BaseException:
        os.close(current);raise

def stamp(metadata):
    return {key:getattr(metadata,key) for key in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')}

def checked_original_file(parent,name,expected):
    descriptor=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
    try:
        before=os.fstat(descriptor)
        assert stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_uid==1000
        assert before.st_size==expected['bytes']
        pieces=[];remaining=expected['bytes']+1
        while remaining:
            part=os.read(descriptor,min(remaining,1024*1024))
            if not part:break
            pieces.append(part);remaining-=len(part)
        raw=b''.join(pieces)
        after=os.fstat(descriptor)
        assert stamp(before)==stamp(after)
        assert stamp(after)==stamp(os.stat(name,dir_fd=parent,follow_symlinks=False))
        assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256']
        assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==expected['blob']
        return raw,stamp(after)
    finally:os.close(descriptor)

def require_same_directory(path,held):
    observed=open_directory(path)
    try:
        a,b=os.fstat(observed),os.fstat(held)
        assert (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino),'directory path identity changed'
    finally:os.close(observed)

def require_same_parent(root,path,held):
    observed,_=relative_parent(root,path)
    try:
        a,b=os.fstat(observed),os.fstat(held)
        assert (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino),'parent directory identity changed'
    finally:os.close(observed)

def hydrate_confirmed_archives():
    record={'status':'preflight','scope':'Inspect the complete checked-out source; create only an observed omitted subset of the nine previously verified unchanged archives. No overwrite, index/config edit or prior-evidence mutation. Compilation starts only after the complete exact candidate exists.','expected_head':HEAD,'expected_tree':TREE,'created':[]}
    recovery_log(record)
    roots=[];parents=[];prepared=[]
    try:
        assert HYDRATION_EXPECTED['head']==HEAD and HYDRATION_EXPECTED['tree']==TREE
        expected=HYDRATION_EXPECTED['observed_missing_archive_files']
        assert len(expected)==9 and len({row['path'] for row in expected})==9
        assert git(REPO,'rev-parse','HEAD').decode().strip()==HEAD
        assert git(REPO,'rev-parse','HEAD^{tree}').decode().strip()==TREE
        assert not git(REPO,'status','--porcelain').strip(),'stable worktree has changes'
        destination=open_directory(REPO);roots.append(destination)
        original=open_directory(ARCHIVE);roots.append(original)
        index_before=git(REPO,'ls-files','-s','-z')
        flags_before=git(REPO,'ls-files','-v','-z')
        config_before=git(REPO,'config','--local','--null','--list')
        entries=[];index={};missing=[]
        for entry in index_before.split(b'\0'):
            if not entry:continue
            meta,name=entry.split(b'\t',1);mode,blob,stage=meta.split()
            assert stage==b'0' and name not in index
            index[name]=(mode,blob,stage);entries.append((mode,name))
            try:(REPO/os.fsdecode(name)).lstat()
            except FileNotFoundError:missing.append(os.fsdecode(name))
        assert len(entries)==HYDRATION_EXPECTED['tracked_files']
        allowed={row['path'] for row in expected}
        assert set(missing)<=allowed,'checkout omitted an unapproved tracked path'
        expected=[row for row in expected if row['path'] in missing]
        assert missing==[row['path'] for row in expected],'missing archive order differs'
        flag_entries=flags_before.split(b'\0')
        record.update(initial_missing=missing,index_before_sha256=hashlib.sha256(index_before).hexdigest(),index_flags_before_sha256=hashlib.sha256(flags_before).hexdigest(),local_config_before_sha256=hashlib.sha256(config_before).hexdigest())
        archive_before=snapshot(ARCHIVE)
        assert archive_before==ARCHIVE_EXPECTED,'bfee archive is not the complete frozen predecessor'
        record['archive_before']=archive_before
        recovery_log(record)
        for row in expected:
            path=row['path'];encoded=os.fsencode(path)
            assert row['git_mode']=='100644'
            assert index[encoded]==(b'100644',row['blob'].encode(),b'0')
            assert flag_entries.count(b'S '+encoded)==1,'confirmed missing archive lacks exact skip-worktree flag S'
            required=b'100644 blob '+row['blob'].encode()+b'\t'+encoded+b'\0'
            assert git(REPO,'ls-tree','-z',PRIOR_HEAD,'--',path)==required
            assert git(REPO,'ls-tree','-z',HEAD,'--',path)==required
            parent,name=relative_parent(destination,path);parents.append(parent)
            original_parent,original_name=relative_parent(original,path);parents.append(original_parent)
            try:os.stat(name,dir_fd=parent,follow_symlinks=False)
            except FileNotFoundError:pass
            else:raise AssertionError('destination already exists, including partial file or symlink')
            raw=git(REPO,'cat-file','blob',row['blob'])
            assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
            assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['blob']
            archived,original_stamp=checked_original_file(original_parent,original_name,row)
            assert archived==raw,'archive bytes differ from immutable Git blob'
            prepared.append({'expected':row,'raw':raw,'parent':parent,'name':name,'original_parent':original_parent,'original_name':original_name,'original_stamp':original_stamp})
        replacements={os.fsencode(item['expected']['path']):item['raw'] for item in prepared}
        virtual=hashlib.sha256()
        for mode,name in entries:
            path=REPO/os.fsdecode(name)
            raw=replacements[name] if name in replacements else (os.readlink(path).encode() if path.is_symlink() else path.read_bytes())
            virtual.update(mode+b'\0'+name+b'\0'+hashlib.sha256(raw).digest())
        assert virtual.hexdigest()==HYDRATION_EXPECTED['tracked_sha256'],'existing source plus exact missing blobs differs from Cloud candidate'
        record.update(status='preflight_complete',all_missing_prechecked=True,virtual_candidate_sha256=virtual.hexdigest(),inputs=[{'expected':item['expected'],'archive_original':item['original_stamp'],'index_flag':'S','parent_and_new_head_blob_equal':True} for item in prepared])
        recovery_log(record)
        require_same_directory(REPO,destination);require_same_directory(ARCHIVE,original)
        assert git(REPO,'ls-files','-s','-z')==index_before and git(REPO,'ls-files','-v','-z')==flags_before
        assert git(REPO,'config','--local','--null','--list')==config_before
        for item in prepared:
            row=item['expected'];parent=item['parent'];name=item['name']
            require_same_parent(destination,row['path'],parent)
            raw,observed=checked_original_file(item['original_parent'],item['original_name'],row)
            assert raw==item['raw'] and observed==item['original_stamp'],'original archive changed after preflight'
            descriptor=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=parent)
            try:
                opened=os.fstat(descriptor)
                assert stat.S_ISREG(opened.st_mode) and opened.st_nlink==1 and opened.st_size==0 and opened.st_uid==1000
                created={'path':row['path'],'status':'created_empty','original_blob':row['blob'],'expected_sha256':row['sha256'],'expected_bytes':row['bytes'],'opened':stamp(opened)}
                record['created'].append(created);record['status']='hydrating';recovery_log(record)
                view=memoryview(item['raw'])
                while view:
                    count=os.write(descriptor,view)
                    assert count>0,'archive write made no progress'
                    view=view[count:]
                os.fsync(descriptor)
                written=os.fstat(descriptor)
                assert written.st_size==row['bytes']
            finally:os.close(descriptor)
            os.fsync(parent)
            require_same_parent(destination,row['path'],parent)
            restored,after=checked_original_file(parent,name,row)
            assert restored==item['raw'] and after==stamp(written)
            created.update(status='restored_and_fsynced',after=after,actual_sha256=hashlib.sha256(restored).hexdigest())
            recovery_log(record)
        require_same_directory(REPO,destination);require_same_directory(ARCHIVE,original)
        assert git(REPO,'ls-files','-s','-z')==index_before,'index entries changed'
        assert git(REPO,'ls-files','-v','-z')==flags_before,'index flags changed'
        assert git(REPO,'config','--local','--null','--list')==config_before,'local Git config changed'
        for item in prepared:
            raw,after=checked_original_file(item['original_parent'],item['original_name'],item['expected'])
            assert raw==item['raw'] and after==item['original_stamp'],'archive original changed'
        archive_after=snapshot(ARCHIVE);assert archive_after==archive_before
        actual=snapshot(REPO)
        assert git(REPO,'ls-files','-s','-z')==index_before,'index entries changed after complete snapshot'
        assert git(REPO,'ls-files','-v','-z')==flags_before,'index flags changed after complete snapshot'
        assert git(REPO,'config','--local','--null','--list')==config_before,'local Git config changed after complete snapshot'
        assert actual['head']==HEAD and actual['tree']==TREE and not actual['status']
        assert actual['tracked_files']==HYDRATION_EXPECTED['tracked_files'] and actual['tracked_sha256']==HYDRATION_EXPECTED['tracked_sha256']
        record.update(status='completed',candidate_after_hydration=actual,archive_after=archive_after,archive_unchanged=True,index_entries_unchanged=True,index_flags_unchanged=True,local_git_config_unchanged=True)
        recovery_log(record)
        return {'record':str(OUT/'source-hydration.json'),'initial_missing':missing,'created_files':len(record['created']),'candidate_after_hydration':actual,'archive_unchanged':True,'source_unchanged_scope':'Only the complete candidate compile before/after; any checkout omissions and create-only hydration are recorded separately.'}
    except BaseException as error:
        record.update(status='failed',exception_type=type(error).__name__,exception=str(error),partial_created_files_preserved=True,automatic_replay=False)
        recovery_log(record);raise
    finally:
        for descriptor in reversed(parents+roots):os.close(descriptor)

OUT.mkdir(parents=True,exist_ok=False)
result={'status':'preflight','expected_head':HEAD,'expected_tree':TREE,'command':CMD,'cwd':str(REPO/'codex-rs'),'target':str(TARGET),'started':utc(),'uid':os.getuid(),'scope':'Actual seven-package scoped just fix, including test compilation; no test execution, JUnit, UID0 custody or whole-chain qualification.'}
def persist():
 temp=OUT/'result.json.tmp';temp.write_text(json.dumps(result,indent=2)+'\n');os.replace(temp,OUT/'result.json')
persist();started=time.monotonic();lock=None;child=None
try:
 assert os.getuid()==1000,'original ordinary compiler UID differs'
 assert TARGET.is_dir(),'known f737 target missing'
 lock=(TARGET/'.hepta-root-native-owner.lock').open('a+b')
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 result['target_owner_lock']='held exclusive .hepta-root-native-owner.lock'
 cargo_lock=TARGET/'debug/.cargo-lock'
 if cargo_lock.exists():
  with cargo_lock.open('rb') as probe:
   fcntl.flock(probe,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(probe,fcntl.LOCK_UN)
 result['cargo_lock_probe']='nonblocking probe released before Cargo launch'
 occupied=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   comm=(p/'comm').read_text().strip()
   if comm not in ['cargo','rustc','clippy-driver','cargo-clippy']:continue
   penv=(p/'environ').read_bytes().split(b'\0')
   current=next((x.split(b'=',1)[1].decode(errors='replace') for x in penv if x.startswith(b'CARGO_TARGET_DIR=')),'')
   cwd=os.readlink(p/'cwd')
   if current==str(TARGET) or cwd.startswith(str(REPO)):
    occupied.append({'pid':int(p.name),'name':comm,'target':current,'cwd':cwd})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 result['occupied_target_processes']=occupied;assert not occupied,'same target has live compiler'
 result['disk_free']=shutil.disk_usage(TARGET).free;assert result['disk_free']>=4*1024**3,'insufficient compiler storage'
 for name,expected_size,expected_sha in [
  ('root-bfee5aa3-scoped-fix-v2',5009,'a778a419714d86407d766a799636687fc017073e2b6194e72f0d0093f5ba679d'),
  ('root-bfee5aa3-native-tests-v2',36858,'b6257a1bf209e3e24497a1efe18ef4084a4db9cb3fb2cd87cad5c468ea7f5f1e')]:
  previous=(BASE/'validation'/name/'result.json').read_bytes()
  assert len(previous)==expected_size and hashlib.sha256(previous).hexdigest()==expected_sha,'predecessor terminal original differs'
  terminal=json.loads(previous);assert terminal['status']=='completed' and terminal['source_unchanged'] is True
  (OUT/(name+'.original.json')).write_bytes(previous)
 bundle=BASE/'root-__NEXT_TAG__-source.bundle'
 data=bundle.read_bytes();assert len(data)==__NEXT_BUNDLE_BYTES__ and hashlib.sha256(data).hexdigest()=='__NEXT_BUNDLE_SHA256__','candidate bundle differs'
 assert not git(SOURCE,'status','--porcelain').strip(),'source-library has changes'
 with (OUT/'bundle-verify-import.log').open('xb') as log:
  subprocess.run(['/usr/bin/git','bundle','verify',str(bundle)],cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['/usr/bin/git','fetch',str(bundle),'HEAD:refs/remotes/original-source/candidate-__NEXT_TAG__'],cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT,check=True)
 assert git(SOURCE,'rev-parse','refs/remotes/original-source/candidate-__NEXT_TAG__').decode().strip()==HEAD
 result['source_library']={'path':str(SOURCE),'source_head':git(SOURCE,'rev-parse','HEAD').decode().strip(),'candidate_head':HEAD,'candidate_tree':git(SOURCE,'rev-parse',HEAD+'^{tree}').decode().strip(),'status':git(SOURCE,'status','--porcelain').decode()}
 assert result['source_library']['candidate_tree']==TREE,'source-library exact tree differs'
 assert REPO.is_dir(),'stable native worktree missing'
 assert git(REPO,'rev-parse','HEAD').decode().strip()=='bfee5aa363cb63897c28c8f74fd6b167de5e859b','stable worktree predecessor differs'
 assert not git(REPO,'status','--porcelain').strip(),'stable worktree has changes'
 result['predecessor_complete']=snapshot(REPO)
 assert result['predecessor_complete']==ARCHIVE_EXPECTED,'predecessor physical source differs'
 archive=Path('/home/qq/hepta-learn-ff41-archived-source-bfee5aa3-before-__NEXT_TAG__-v1');assert not archive.exists()
 with (OUT/'source-import.log').open('wb') as log:
  subprocess.run(['/usr/bin/git','worktree','add','--detach',str(archive),'bfee5aa363cb63897c28c8f74fd6b167de5e859b'],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
  assert git(archive,'rev-parse','HEAD^{tree}').decode().strip()=='d24d13a0d716036319a6b814dd89b8e913689b00'
  assert not git(archive,'status','--porcelain').strip()
  assert snapshot(archive)==ARCHIVE_EXPECTED,'new archive is not the complete predecessor'
  subprocess.run(['/usr/bin/git','fetch',str(BASE/'root-__NEXT_TAG__-source.bundle'),'HEAD:refs/remotes/original-source/candidate-__NEXT_TAG__'],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
  assert git(REPO,'rev-parse','refs/remotes/original-source/candidate-__NEXT_TAG__').decode().strip()==HEAD
  subprocess.run(['/usr/bin/git','checkout','--detach',HEAD],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
 result['stable_worktree_reuse']={'original_head':'bfee5aa363cb63897c28c8f74fd6b167de5e859b','original_archive':str(archive),'reason':'Preserve compiler source paths; original clean source and all original run evidence remain retained.'}
 result['source_hydration']=hydrate_confirmed_archives()
 before=snapshot(REPO);assert before['head']==HEAD and before['tree']==TREE and not before['status'],'candidate source identity differs'
 assert before['tracked_files']==HYDRATION_EXPECTED['tracked_files'] and before['tracked_sha256']==HYDRATION_EXPECTED['tracked_sha256'],'complete candidate digest differs'
 result['before']=before
 original=json.loads((BASE/'env.json').read_text());assert isinstance(original,dict) and all(isinstance(k,str) and isinstance(v,str) for k,v in original.items()),'unexpected original environment shape'
 env=os.environ.copy();env.update(original)
 for key in list(env):
  if key.startswith('CARGO_PROFILE_'):del env[key]
 env.update({'RUSTUP_TOOLCHAIN':'1.96.0','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(TARGET),'GIT_TERMINAL_PROMPT':'0'})
 env['PATH']=str(BASE/'bin')+':/home/qq/.cargo/bin:'+env.get('PATH','/usr/local/bin:/usr/bin:/bin')
 result['environment']={k:env.get(k) for k in ['PATH','CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_TARGET_DIR','BINDGEN_EXTRA_CLANG_ARGS','LIBCLANG_PATH','RUSTFLAGS']}
 result['profile_overrides']=[k for k in env if k.startswith('CARGO_PROFILE_')]
 result['rustc']=subprocess.check_output(['/home/qq/.cargo/bin/rustc','--version'],env=env,text=True).strip()
 assert result['rustc'].startswith('rustc 1.96.0 '),'wrong original Rust toolchain'
 result['just']=subprocess.check_output([str(BASE/'bin/just'),'--version'],env=env,text=True).strip()
 result['driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 result['status']='running';result['compile_started']=utc();persist()
 print('ROOT___NEXT_TAG_UPPER___SCOPED_FIX_STARTED '+json.dumps({'head':HEAD,'tree':TREE,'target':str(TARGET),'result':str(OUT/'result.json')}),flush=True)
 with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
  child=subprocess.Popen(CMD,cwd=REPO/'codex-rs',env=env,stdout=stdout,stderr=stderr)
  result['cargo_recipe_pid']=child.pid;persist();code=child.wait()
 result['exit_code']=code;result['after']=snapshot(REPO);result['source_unchanged']=result['before']==result['after']
 (OUT/'fix.patch').write_bytes(git(REPO,'diff','--binary','--no-ext-diff','HEAD'))
 for raw in git(REPO,'diff','--name-only','-z','HEAD').split(b'\0'):
  if raw:
   rel=Path(os.fsdecode(raw));target=OUT/'postimage'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((REPO/rel).read_bytes())
 result['status']='completed'
except BaseException as error:
 result['status']='driver_failed' if child is not None else 'preflight_failed'
 result['exception_type']=type(error).__name__;result['exception']=str(error)
 (OUT/'driver-error.log').write_text(traceback.format_exc())
finally:
 result['finished']=utc();result['elapsed']=time.monotonic()-started
 result['logs']={}
 for p in sorted(OUT.rglob('*')):
  if p.is_file() and p.name not in ['result.json','result.json.tmp']:
   raw=p.read_bytes();result['logs'][p.relative_to(OUT).as_posix()]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 persist()
 if lock is not None:lock.close()
 print('ROOT___NEXT_TAG_UPPER___SCOPED_FIX_TERMINAL '+json.dumps(result),flush=True)

# This integration probe stops after compilation; native tests require a separate exact-source launch.
