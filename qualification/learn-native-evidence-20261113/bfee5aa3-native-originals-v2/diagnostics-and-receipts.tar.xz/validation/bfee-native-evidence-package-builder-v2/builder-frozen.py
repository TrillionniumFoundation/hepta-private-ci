#!/usr/bin/env python3
"""Preserve completed read-only collection and DATA observations; no H or Rust."""
from pathlib import Path
import hashlib
import io
import json
import os
import stat
import tarfile

BASE = Path('/workspace/scratch/ff41dfc0f7bf/tooling')
ORIGINAL = BASE / 'validation/root-native-originals-bfee5aa3-v2'
OUT = BASE / 'publication/evidence-bfee5aa3-native-originals-20261113-v2'
HEAD = 'bfee5aa363cb63897c28c8f74fd6b167de5e859b'
TREE = 'd24d13a0d716036319a6b814dd89b8e913689b00'
ARCHIVE_SHA = 'd42b5e0c33f38c1b3b372a82857434e137b4a3356f8f0c35d75bc4250b273209'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def stamp(value):
    return {key: getattr(value, key) for key in (
        'st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink',
        'st_size', 'st_mtime_ns', 'st_ctime_ns')}

def original(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode), str(path)
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        opened = os.fstat(stream.fileno())
        data = stream.read()
        after_fd = os.fstat(stream.fileno())
    after = path.lstat()
    assert stamp(before) == stamp(opened) == stamp(after_fd) == stamp(after)
    assert len(data) == before.st_size
    return data, stamp(before)

def write_new(path, data):
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())

def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / 'diagnostics-and-receipts.tar.xz').exists(), 'Reconcile an existing archive; do not replay'
    paths = []
    for path in ORIGINAL.rglob('*'):
        if path.is_file() and 'sqlite-copy' not in path.parts and path.suffix != '.bin' and path.name != 'originals.tar.xz':
            paths.append(path)
    for relative in [
        'validation/root-bfee5aa3-observed-progress-v2',
        'validation/completed-chain-collector-bfee5aa3-v2-prepared',
        'validation/ci-initial-progress-fix-template-review-v1',
        'publication/draft-bfee5aa3-v1',
    ]:
        directory = BASE / relative
        assert directory.is_dir(), relative
        paths.extend(path for path in directory.rglob('*') if path.is_file())
    paths.extend(BASE / relative for relative in [
        'collect_completed_chain_originals_v3.py',
        'observe_bfee5aa3_circuit_archive_v1.py',
        'observe_bfee5aa3_original_journal_data_v1.py',
        'root_original_initial_progress_scoped_fix_template_v1.py',
        'prepare_initial_progress_fix_template_v1.py',
        'root_original_initial_progress_scoped_fix_template_v2.py',
        'validation/root-initial-progress-template-v2/refinement.json',
        'publication/ordinary-integrated-pr-body-bfee5aa3-proposal-v2.md',
        'publication/evidence-bfee5aa3-source-preflight-20261113-v1/publication-receipt.json',
        'archive_bfee_native_originals_ci_v2.py',
    ])
    saved = {}
    for path in sorted(set(paths)):
        data, metadata = original(path)
        saved[str(path.relative_to(BASE))] = (data, metadata)
    def value(name):
        return json.loads(saved[name][0])

    native_prefix = 'validation/root-bfee5aa3-observed-progress-v2/'
    native_bytes = saved[native_prefix + 'native-result-original.json'][0]
    assert digest(native_bytes) == 'b6257a1bf209e3e24497a1efe18ef4084a4db9cb3fb2cd87cad5c468ea7f5f1e'
    native = json.loads(native_bytes)
    assert native['status'] == 'completed' and native['source_unchanged'] is True
    assert native['before'] == native['after']
    assert native['before']['head'] == HEAD and native['before']['tree'] == TREE
    assert native['before']['tracked_files'] == 15497
    assert native['before']['tracked_sha256'] == 'dfed7872d8cb0158e556de66d1499fbc10d03bad19c6038874eaefe0d2ffd847'
    counts = {}
    for key, total, failures in [
        ('root-run-start-publisher', 6, 0), ('circuit-source-lease-budget', 2, 0),
        ('root-filesystem', 2, 0), ('ordinary-a', 1, 1),
    ]:
        entry = native[key]
        report = entry['collection']
        assert report['source_sha'] == HEAD and report['source_tree'] == TREE
        assert report['total_testcases'] == total and report['failures'] == failures
        assert report['errors'] == report['skipped_in_xml'] == 0 and report['exact_parent_coverage'] is True
        assert entry['command_exit_code'] == (100 if failures else 0)
        counts[key] = {name: report[name] for name in [
            'status', 'total_testcases', 'failures', 'errors', 'skipped_in_xml',
            'junit_bytes', 'junit_sha256', 'exact_parent_coverage', 'command']}
    assert digest(saved[native_prefix + 'original-ordinary-a.xml'][0]) == counts['ordinary-a']['junit_sha256']
    fixed = value(native_prefix + 'compile-result-final.original.json')
    assert fixed['status'] == 'completed' and fixed['exit_code'] == 0 and fixed['source_unchanged'] is True
    assert all(fixed['before'][key] == val for key, val in native['before'].items())
    origin_prefix = 'validation/root-native-originals-bfee5aa3-v2/'
    collector = json.loads(value(origin_prefix + 'collector-status-1.mcp.json')['content'][0]['text'])
    assert collector['state'] == 'succeeded' and collector['exit_code'] == 0
    assert collector['output_complete'] and collector['output_durable'] and collector['terminal_publication_confirmed']
    assert not collector['automatic_retry'] and not collector['cancelled'] and not collector['timed_out']

    archive_bytes, archive_stat = original(ORIGINAL / 'originals.tar.xz')
    assert len(archive_bytes) == 317900 and digest(archive_bytes) == ARCHIVE_SHA
    manifest_bytes = saved[origin_prefix + 'manifest.json'][0]
    assert digest(manifest_bytes) == '0dd07fb40a628373b59788155dfb1553b5243acd0423601931d61063bf71adeb'
    manifest = json.loads(manifest_bytes)
    regular = {entry['path']: entry for entry in manifest['records'] if entry['kind'] == 'regular'}
    assert len(regular) == 261
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:xz') as archive:
        entries = archive.getmembers()
        assert len(entries) == 262 and len({entry.name for entry in entries}) == len(entries)
        seen = set()
        total_bytes = 0
        for entry in entries:
            assert entry.isfile()
            data = archive.extractfile(entry).read()
            if entry.name == 'manifest.json':
                assert data == manifest_bytes
            else:
                expected = regular[entry.name]
                assert len(data) == expected['physical']['size'] and digest(data) == expected['sha256']
                total_bytes += len(data)
                seen.add(entry.name)
        assert seen == set(regular) and total_bytes == 8972543

    sql = value(origin_prefix + 'sqlite-observer-v1-result.json')
    journal = value(origin_prefix + 'journal-and-outbox-data-v1/result.json')
    for data in [sql, journal]:
        assert data['status'] == 'completed' and data['source_head'] == HEAD
        assert data['archive_sha256'] == ARCHIVE_SHA
        assert data['archive_unchanged'] is True and data['copied_db_and_wal_unchanged'] is True
    assert len(journal['run_start']['records']) == 1 and journal['run_start']['records'][0]['disposition'] == 'Compiled'
    assert set(journal['source']['stage_states']) == {'request', 'input'}
    assert all(entry['state'] == 'Completed' for entry in journal['source']['stage_states'].values())
    assert len(journal['cell']['frames']) == 1 and journal['cell']['frames'][0]['tag'] == 3
    assert journal['outbox']['row_count'] == 0
    pr = value('publication/draft-bfee5aa3-v1/publication-receipt.json')
    assert pr['draft'] is True and pr['merged'] is False and pr['qualification_counts'] == [0, 0, 0]
    assert pr['local_head'] == HEAD and pr['tree'] == TREE

    archive_path = OUT / 'diagnostics-and-receipts.tar.xz'
    with tarfile.open(archive_path, 'x:xz', preset=6) as archive:
        for name, (data, metadata) in saved.items():
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = stat.S_IMODE(metadata['st_mode'])
            entry.mtime = metadata['st_mtime_ns'] / 1_000_000_000
            archive.addfile(entry, io.BytesIO(data))
    with tarfile.open(archive_path, 'r:xz') as archive:
        entries = archive.getmembers()
        assert len(entries) == len(saved) and {entry.name for entry in entries} == set(saved)
        for entry in entries:
            assert entry.isfile() and archive.extractfile(entry).read() == saved[entry.name][0]
    for name, (data, metadata) in saved.items():
        current, current_metadata = original(BASE / name)
        assert current == data and current_metadata == metadata
    assert original(ORIGINAL / 'originals.tar.xz') == (archive_bytes, archive_stat)
    support_bytes, _ = original(archive_path)
    support_manifest = {
        'schema': 1, 'source_head': HEAD, 'source_tree': TREE,
        'archive': archive_path.name, 'archive_bytes': len(support_bytes), 'archive_sha256': digest(support_bytes),
        'member_count': len(saved), 'input_bytes': sum(len(value[0]) for value in saved.values()),
        'all_member_bytes_verified': True, 'all_originals_rechecked_unchanged': True,
        'members': [{'path': name, 'bytes': len(data), 'sha256': digest(data), 'source_stat': metadata}
                    for name, (data, metadata) in saved.items()],
        'excluded_redundant_copies': ['binary archive download chunks', 'private SQLite DB/WAL/SHM copies'],
        'note': 'The immutable original SQLite bytes remain in originals.tar.xz; only private SHM cache changed during mode=ro/query_only observations.',
    }
    verification = {
        'schema': 1, 'source_head': HEAD, 'source_tree': TREE,
        'native_original_archive': {'bytes': len(archive_bytes), 'sha256': ARCHIVE_SHA,
            'git_blob': hashlib.sha1(b'blob ' + str(len(archive_bytes)).encode() + b'\0' + archive_bytes).hexdigest(),
            'regular_members': 261, 'original_input_bytes': total_bytes, 'all_member_bytes_verified': True},
        'native': {'status': native['status'], 'started': native['started'], 'finished': native['finished'],
            'elapsed': native['elapsed'], 'source_unchanged': True, 'gates': counts,
            'native_result_sha256': digest(native_bytes), 'whole_chain_pass_counts': [0, 0, 0]},
        'compile': {'exit_code': fixed['exit_code'], 'source_unchanged': True, 'tests_executed': 0,
            'result_sha256': digest(saved[native_prefix + 'compile-result-final.original.json'][0])},
        'collection': collector,
        'data_observations': {
            'sqlite_result_sha256': digest(saved[origin_prefix + 'sqlite-observer-v1-result.json'][0]),
            'journal_outbox_result_sha256': digest(saved[origin_prefix + 'journal-and-outbox-data-v1/result.json'][0]),
            'original_archive_and_copied_db_wal_unchanged': True,
            'qualification_inferred': False, 'exact_ack_variant_inferred': False,
            'first_local_launcher_error_preserved': 'FileNotFoundError for guessed /usr/local/bin/python3 before diagnostic child start; actual sys.executable successor exited 0'},
        'draft_pr': {'number': pr['pr'], 'head': pr['head'], 'draft': True, 'merged': False,
            'receipt_sha256': digest(saved['publication/draft-bfee5aa3-v1/publication-receipt.json'][0])},
        'next_template_review': 'Prepared-only; no H upload or execution by this evidence task.',
        'previous_evidence_head': 'd427f3356067c28705c544c1bc2d66492f549115',
    }
    write_new(OUT / 'originals.tar.xz', archive_bytes)
    write_new(OUT / 'native-manifest.json', manifest_bytes)
    write_new(OUT / 'native-verification.json', saved[origin_prefix + 'verification.json'][0])
    write_new(OUT / 'support-manifest.json', json_bytes(support_manifest))
    write_new(OUT / 'verification.json', json_bytes(verification))
    readme = '''# Bfee A-v2 originals and read-only DATA observations

Exact native source: bfee5aa363cb63897c28c8f74fd6b167de5e859b, tree d24d13a0d716036319a6b814dd89b8e913689b00. The complete 15,497-file physical source hash was unchanged before and after execution. Earlier failed source-preflight and successful hydration/compile attempts remain in the parent evidence history.

## Actual outcomes

| Gate | Actual outcome |
| --- | --- |
| Seven-package scoped fix v2 | Exit 0, unchanged source, 114.677388904 seconds; no tests executed |
| Publisher binding | 6 passed, 0 failed, 0 skipped; exact roster |
| Circuit source-lease budget reducer | 2 passed, 0 failed, 0 skipped; exact roster |
| Root filesystem | 2 passed, 0 failed, 0 skipped; exact roster |
| Ordinary A | 0 passed, 1 failed, 0 skipped; test duration 4.881 seconds |
| Whole Adopt / evaluated post-B NoUpdate / cold | 0 / 0 / 0 |

A failed with `ordinary original Objective returned conflict or uncertain ACK; no inferred execution`. This error groups two outcomes and does not identify the precise returned variant. The driver preserved both child exits and cleanup. No successful ACK, timeout cause, A completion, independent Outcome, B evaluation or whole-chain completion is inferred from a durable prefix.

## Actual archived DATA

The read-only collector exited 0 and retained 261 regular originals (8,972,543 input bytes) in `originals.tar.xz`. All 20 version-pinned download chunks, the 317,900-byte archive SHA-256, the embedded manifest and every member were checked. Collection did not rerun the tests or open business owners.

Two diagnostics examined this same archive. SQLite was read using private copies of DB, WAL and SHM, with `mode=ro` and `query_only`. Original archive and copied durable DB/WAL bytes remained unchanged; private SHM cache changes are explicitly recorded. No original database was checkpointed or modified.

* Circuit `ordinary-original-a` had its original 120,000 ms limit. First Advance occurred 2,908 ms after created_at; computation_claimed followed 6 ms later. Revision was 2, its sole activation was in_flight, stop_reason was null, and no Complete/terminal event existed in this archived prefix.
* RunStart framing contained one complete v2 `Compiled` record and no Conflict record. This is structural DATA, without new native authentication or a delivered-ACK claim.
* Source framing showed request and input claim/complete pairs, with no result or withdrawal stage.
* Cell framing contained one HPTACJ04 tag-3 admission, snapshot revision 0, model generation 1. No tag-4 queue-age or tag-0 commit frame existed in these bytes. Only named prefix fields and chain checks were decoded; no native Cell receipt or authority was reconstructed.
* The actual `circuit_learning_outbox_v1` query for this run returned zero rows. Absence of an outbox row alone does not establish that execution never began.

The full scripts, exact SQL, source-codec hashes, raw collection/observer receipts, output reports, initial local launcher failure before any diagnostic child start, and successful successor execution are preserved in `diagnostics-and-receipts.tar.xz`. Private SQLite copies are not duplicated because the original DB/WAL/SHM are already archived. None of these observations replays business activity or upgrades a pending stage to Completed.

The same appendix preserves Root's byte-verified draft PR #6284 receipt, pointing to remote 3a26e6e9baba163c31d395e69e114af6a5c97efb, and the static review of prepared-only next compile templates. This evidence task did not create/update the PR, change source refs, upload the prepared template or execute Rust. The original v1 template and the separately named metadata-only v2 refinement are retained.

`native-manifest.json` is the exact collector manifest. `support-manifest.json` lists every supporting member and complete SHA-256. `verification.json` ties the independent outcomes to their exact original result hashes. Parent evidence is retained unchanged.
'''
    write_new(OUT / 'README.md', readme.encode())
    output = []
    for path in sorted(OUT.iterdir()):
        data, _ = original(path)
        output.append({'name': path.name, 'bytes': len(data), 'sha256': digest(data),
                       'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()})
    print(json.dumps({'output': str(OUT), 'support_members': len(saved), 'support_input_bytes': support_manifest['input_bytes'], 'files': output}))

if __name__ == '__main__':
    main()
