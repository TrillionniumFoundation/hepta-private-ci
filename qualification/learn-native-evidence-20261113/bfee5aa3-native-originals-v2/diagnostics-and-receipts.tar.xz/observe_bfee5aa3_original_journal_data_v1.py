"""Pure DATA observation of verified archived bytes, with no product store calls."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import sqlite3
import subprocess
import tarfile

BASE = Path('/workspace/scratch/ff41dfc0f7bf/tooling')
ROOT = BASE / 'validation/root-native-originals-bfee5aa3-v2'
ARCHIVE = ROOT / 'originals.tar.xz'
OUT = ROOT / 'journal-and-outbox-data-v1'
SOURCE = BASE.parent / 'hepta-current-history-guards-cloud'
HEAD = 'bfee5aa363cb63897c28c8f74fd6b167de5e859b'
ARCHIVE_SHA = 'd42b5e0c33f38c1b3b372a82857434e137b4a3356f8f0c35d75bc4250b273209'
MANIFEST_SHA = '0dd07fb40a628373b59788155dfb1553b5243acd0423601931d61063bf71adeb'
RUN = 'ordinary-original-a'
RUNTIME = 'cases/ordinary-a/retained/a_runtime/'
AGENT_HOME = RUNTIME + 'fleet/agents/018f4f72-5f8f-7cc1-8f55-df9fb3aa2c12/home/'

def sha(value):
    return hashlib.sha256(value).digest()

def physical(path):
    s = path.stat()
    return (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)

class Reader:
    def __init__(self, data):
        self.data, self.pos = data, 0
    def take(self, size):
        assert 0 <= size <= len(self.data) - self.pos
        value = self.data[self.pos:self.pos + size]
        self.pos += size
        return value
    def number(self, width=8):
        return int.from_bytes(self.take(width), 'big')
    def identity(self, width=4):
        size = self.number(width)
        assert 1 <= size <= 128
        text = self.take(size).decode('utf-8')
        assert re.fullmatch(r'[A-Za-z0-9_.:/-]+', text), 'Unexpected diagnostic ID syntax'
        return text
    def finish(self):
        assert self.pos == len(self.data)

def run_start(data):
    assert 72 <= len(data) <= 64 * 1024 * 1024
    assert data[:8] == b'HEPTRS01' and sha(data[:40]) == data[40:72]
    offset, predecessor, records, run_ids = 72, bytes(32), [], set()
    while offset < len(data):
        assert len(data) - offset >= 8 and len(records) < 4096
        size, complement = int.from_bytes(data[offset:offset+4], 'big'), int.from_bytes(data[offset+4:offset+8], 'big')
        assert 0 < size <= 528384 and size == (~complement & 0xffffffff)
        end = offset + size + 112
        assert end <= len(data)
        frame = data[offset:end]
        assert sha(frame[:-32]) == frame[-32:]
        sequence = int.from_bytes(frame[8:16], 'big')
        assert sequence == len(records) + 1 and frame[16:48] == predecessor
        payload = frame[48:48+size]
        chain = frame[48+size:80+size]
        assert chain == sha(b'hepta.run-start-chain.v1' + predecessor + sequence.to_bytes(8, 'big') + sha(payload))
        domains = [d for d in (b'hepta.run-start-record.v1', b'hepta.run-start-record.v2', b'hepta.run-start-conflict.v1') if payload.startswith(d)]
        assert len(domains) == 1
        domain = domains[0]
        r = Reader(payload[len(domain):])
        r.identity(); key_epoch = r.number(); r.identity(); auth_sequence = r.number(); expires = r.number()
        r.take(32 + 32 + 64)  # public digests and signature; never print signature bytes
        r.identity(); profile_revision = r.number(); profile_digest = r.take(32)
        r.take(32 * 3)
        observed, deadline = r.number(), r.number()
        posture = r.take(8); assert all(value in (0, 1) for value in posture)
        record = {'sequence': sequence, 'frame_start': offset, 'frame_end': end,
                  'payload_domain': domain.decode(), 'payload_sha256': sha(payload).hex(),
                  'chain_digest': chain.hex(), 'authentication_sequence': auth_sequence,
                  'key_epoch': key_epoch, 'expires_at_ms': expires,
                  'profile_revision': profile_revision, 'profile_digest': profile_digest.hex(),
                  'observed_at_unix_micros': observed, 'deadline_unix_micros': deadline}
        if domain.startswith(b'hepta.run-start-record.'):
            disposition = r.number(); assert disposition in (0, 1)
            run = r.identity(); objective_digest = r.take(32); r.take(32 * 5)
            record.update(disposition=('Compiled' if disposition == 0 else 'ExplicitAbstain'),
                          authority_epoch=r.number(), generation=r.number())
            r.take(32 + 32)
            semantic_length = r.number(4); assert 1 <= semantic_length <= 262144
            semantic = r.take(semantic_length); assert sha(semantic) == objective_digest
            if domain.endswith(b'.v2'):
                protocol_digest = r.take(32); protocol_length = r.number(4)
                assert 1 <= protocol_length <= 262144 and sha(r.take(protocol_length)) == protocol_digest
        else:
            run = r.identity(); r.take(32); conflict_digest = r.take(32)
            length = r.number(4); assert 1 <= length <= 262144 and sha(r.take(length)) == conflict_digest
            record.update(disposition='Conflict', conflict_digest=conflict_digest.hex())
        r.finish(); assert run not in run_ids
        run_ids.add(run); record['run_id'] = run
        records.append(record); offset = end; predecessor = chain
    return {'records': records, 'complete_framing': True, 'binding_digest_data': data[8:40].hex(),
            'native_authentication_or_authority_revalidated': False}

def source_journal(data):
    assert 72 <= len(data) <= 32 * 1024 * 1024
    assert data[:8] == b'HEPTEX01' and sha(data[:40]) == data[40:72]
    offset, previous, frames, states = 72, sha(data[:72]), [], {}
    while offset < len(data):
        size = int.from_bytes(data[offset:offset+4], 'big'); assert 36 <= size <= 65536 + 163
        end = offset + 4 + size + 32; assert end <= len(data)
        payload = data[offset+4:end-32]; sequence = len(frames) + 1
        current = sha(b'hepta.product-evaluation.execution-journal.v1' + previous + sequence.to_bytes(8, 'big') + payload)
        assert current == data[end-32:end]
        r = Reader(payload); tag = r.number(1); name = r.identity(2); binding = r.take(32)
        assert binding != bytes(32)
        match = re.fullmatch(r'circuit-source:(request|input|result|withdraw):([0-9a-f]{64})', name)
        assert match and match.group(2) == sha(RUN.encode()).hex()
        stage = match.group(1)
        if tag == 0:
            r.finish(); assert stage not in states
            states[stage] = {'binding_digest': binding.hex(), 'state': 'Pending'}
        else:
            assert tag == 1 and 1 <= len(payload) - r.pos <= 65536
            assert states[stage] == {'binding_digest': binding.hex(), 'state': 'Pending'}
            remaining = payload[r.pos:]
            states[stage].update(state='Completed', payload_bytes=len(remaining), payload_sha256=sha(remaining).hex())
        frames.append({'sequence': sequence, 'stage': stage, 'record_kind': 'claim' if tag == 0 else 'complete',
                       'frame_start': offset, 'frame_end': end, 'history_digest': current.hex()})
        previous, offset = current, end
    return {'frames': frames, 'stage_states': states, 'complete_framing': True,
            'native_owner_or_witness_revalidated': False}

def cell_journal(data):
    assert 40 <= len(data) and data[:8] in (b'HPTACJ03', b'HPTACJ04')
    offset, previous, frames = 40, sha(data[:40]), []
    names = {0: 'commit', 1: 'reset', 2: 'legacy_admission', 3: 'admission', 4: 'host_queue_age'}
    while offset < len(data):
        assert len(data)-offset >= 4
        size = int.from_bytes(data[offset:offset+4], 'big'); assert 0 < size <= 131072
        end = offset + 4 + size + 32; assert end <= len(data)
        payload = data[offset+4:end-32]; sequence = len(frames)+1
        current = sha(b'hepta.cell.journal.frame.v1' + previous + sequence.to_bytes(8,'big') + size.to_bytes(8,'big') + payload)
        assert current == data[end-32:end]
        r = Reader(payload); tag = r.number(1); assert tag in names
        record = {'sequence': sequence, 'tag': tag, 'record_kind': names[tag], 'partition_index': r.number(),
                  'frame_start': offset, 'frame_end': end, 'checkpoint_digest': current.hex()}
        if tag in (0, 2, 3):
            record.update(snapshot_revision=r.number(), writer_epoch=r.number())
        if tag == 0:
            record.update(deadline_micros=r.number(), decided_at_micros=r.number(), committed_at_micros=r.number())
        elif tag in (2, 3):
            r.take(128); record['operation_id'] = r.identity(8); r.take(32)
            record.update(deadline_micros=r.number(), admitted_at_micros=r.number())
            r.identity(8); r.identity(8); r.identity(8); record['model_generation'] = r.number()
        elif tag == 4:
            record['operation_id'] = r.identity(8); r.take(32); record['host_queue_age_micros'] = r.number(); r.finish()
        record['prefix_only_decoding'] = tag != 4
        frames.append(record); previous, offset = current, end
    return {'magic': data[:8].decode(), 'frames': frames, 'complete_framing': True,
            'scope_model_witness_authority_revalidated': False,
            'scope': 'Original frame checksum/chain and named tag prefixes only; no reconstructed native Cell owner or receipt.'}

def main():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE).decode().strip() == HEAD
    OUT.mkdir(mode=0o700, exist_ok=False)
    before = physical(ARCHIVE); data = ARCHIVE.read_bytes(); assert len(data)==317900 and sha(data).hex()==ARCHIVE_SHA
    selected, evidence = {}, {}
    paths = [AGENT_HOME+'objective-run-start-v1/journal.bin', RUNTIME+'data/a-source.journal', RUNTIME+'data/a-cell.journal']
    with tarfile.open(ARCHIVE, 'r:xz') as archive:
        manifest_bytes = archive.extractfile('manifest.json').read(); assert sha(manifest_bytes).hex()==MANIFEST_SHA
        manifest=json.loads(manifest_bytes); rows={r['path']:r for r in manifest['records'] if r['kind']=='regular' and 'sha256' in r}
        total=0
        for member in archive.getmembers():
            if member.name=='manifest.json':continue
            assert member.isfile(); raw=archive.extractfile(member).read(); row=rows[member.name]
            assert len(raw)==row['physical']['size'] and sha(raw).hex()==row['sha256'];total+=len(raw)
            if member.name in paths or '/automation/automation_1.sqlite3' in member.name:
                selected[member.name]=raw
                evidence[member.name]={'sha256':row['sha256'],'bytes':len(raw),'actual_path':row['actual_path']}
        assert total==8972543
    result={'run_start':run_start(selected[paths[0]]),'source':source_journal(selected[paths[1]]),'cell':cell_journal(selected[paths[2]])}
    copy=OUT/'sqlite-copy';copy.mkdir(mode=0o700)
    for name,raw in selected.items():
        if '/automation/automation_1.sqlite3' not in name:continue
        assert Path(name).name in ('automation_1.sqlite3','automation_1.sqlite3-wal','automation_1.sqlite3-shm')
        p=copy/Path(name).name
        with p.open('xb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
    def copy_snapshot():
        return {p.name:{'sha256':sha(p.read_bytes()).hex(),'physical':physical(p)} for p in sorted(copy.iterdir())}
    copy_before=copy_snapshot()
    query='SELECT owner_agent_id, run_id, intent_json, request_digest, acknowledged_head, retired FROM circuit_learning_outbox_v1 WHERE run_id = ?'
    connection=sqlite3.connect((copy/'automation_1.sqlite3').as_uri()+'?mode=ro',uri=True);connection.row_factory=sqlite3.Row
    try:
        connection.execute('PRAGMA query_only=ON')
        columns=[dict(row) for row in connection.execute('PRAGMA table_info(circuit_learning_outbox_v1)')]
        rows=[]
        if columns:
            for row in connection.execute(query,(RUN,)):
                row=dict(row);raw=row.pop('intent_json');body=json.loads(raw)
                assert set(body)=={'operation_id','source_run_id','completed_task_receipt','objective_digest'}
                row.update(intent_json_sha256=sha(raw.encode()).hex(),intent_data=body);rows.append(row)
        result['outbox']={'query':query,'parameters':[RUN],'schema':columns,'rows':rows,'row_count':len(rows)}
    finally:
        connection.close()
    copy_after=copy_snapshot()
    assert all(copy_after[name]==value for name,value in copy_before.items() if not name.endswith('-shm'))
    assert physical(ARCHIVE)==before and sha(ARCHIVE.read_bytes()).hex()==ARCHIVE_SHA
    sources=['hepta-learning-ledger/src/run_start.rs','hepta-learning-ledger/src/run_start_frames.rs',
             'hepta-intelligence-eval/src/product_execution_file.rs','hepta-intelligence-eval/src/product_execution_physical.rs',
             'hepta-agentd/src/circuit_task_source_journal.rs','hepta-neuron/src/cell_journal.rs',
             'hepta-neuron/src/cell_journal_image.rs','hepta-neuron/src/cell_journal_codec.rs','hepta-types/src/digest.rs']
    result.update(status='completed',source_head=HEAD,archive_sha256=ARCHIVE_SHA,manifest_sha256=MANIFEST_SHA,
                  original_members=evidence,all_archive_members_verified=261,all_archive_bytes_verified=total,
                  archive_before=before,archive_after=physical(ARCHIVE),archive_unchanged=True,
                  copy_before=copy_before,copy_after=copy_after,copied_db_and_wal_unchanged=True,
                  codec_sources=[{'path':'codex-rs/'+p,'sha256':sha((SOURCE/'codex-rs'/p).read_bytes()).hex()} for p in sources],
                  scope='Data-only framing/chain and bounded field-prefix observation of immutable collected originals. No signature/authority revalidation, writer recovery, inferred ACK, product API or native test.',
                  finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:result[key] for key in ['status','run_start','source','cell','outbox']},indent=2))

if __name__=='__main__':
    main()
