#!/usr/bin/env python3
"""Archive the completed draft publication and last connection observation only."""
from pathlib import Path
import importlib.util
import json
import io
import stat
import tarfile

BASE=Path('/workspace/scratch/ff41dfc0f7bf/tooling')
HELPER=BASE/'archive_bfee_native_originals_ci_v3.py'
spec=importlib.util.spec_from_file_location('exact_evidence_io',HELPER)
helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
SOURCE=BASE/'publication/draft-afdf13ff-v1'
OUT=BASE/'publication/evidence-afdf13ff-publication-20261113-v1'
EVIDENCE='c65ef4add55e5ee99ce33cdb81fcc6ce6731638c'
REMOTE_SOURCE='69e711feff3bd67951d33d01f28b68172b35b20d'
LOCAL_SOURCE='afdf13ffc1757c0dfa5d3f6922bde2d746251df7'
TREE='7eb8f9f742ce2a28327b6d7aae0b2f0f8cd7ebf4'

def main():
 OUT.mkdir(exist_ok=True)
 files=[p for p in SOURCE.rglob('*') if p.is_file()]
 files += [HELPER,Path(__file__),
 BASE/'publication/ordinary-integrated-pr-body-afdf13ff-proposal-v4.md',
 BASE/'publication/ordinary-integrated-pr-body-afdf13ff-proposal-v5.md',
 BASE/'prepare_afdf13ff_pr_body_v4.py',
 BASE/'validation/root-5e2426ad-native-inputs-v1/bundle-upload-reconciliation-info-v3.mcp.json',
 BASE/'publication/evidence-afdf13ff-final-source-20261113-v1/publication-receipt.json']
 saved={str(p.relative_to(BASE)):helpers.original(p) for p in sorted(set(files))}
 prefix=str(SOURCE.relative_to(BASE))+'/'
 def value(name):return json.loads(saved[name][0])
 def fetched(name):
  raw=value(prefix+name);assert raw['isError'] is False
  return json.loads(raw['structuredContent']['content'])
 receipt_bytes=saved[prefix+'publication-receipt.json'][0]
 assert len(receipt_bytes)==3870 and helpers.digest(receipt_bytes)=='d171c98fbadc7735679c2565e5885ea9ca7bfd746e09a2061ffe17579257cba2'
 r=json.loads(receipt_bytes)
 assert r['source_head']==REMOTE_SOURCE and r['local_source_head']==LOCAL_SOURCE and r['source_tree']==TREE
 assert r['evidence_head']==EVIDENCE and r['expected_sha_lease'] and not r['force']
 assert r['draft'] and not r['merged'] and not r['native_new_candidate_executed'] and r['qualification']==[0,0,0]
 body=saved['publication/ordinary-integrated-pr-body-afdf13ff-proposal-v5.md'][0]
 assert len(body)==r['body_bytes']==21760 and helpers.digest(body)==r['body_sha256']
 pr=fetched('pr-body-readback.mcp.json')
 assert pr['number']==6284 and pr['state']=='open' and pr['draft'] and not pr['merged']
 assert pr['head']['sha']==REMOTE_SOURCE and pr['body'].encode()==body
 assert fetched('source-ref-readback.mcp.json')['object']['sha']==REMOTE_SOURCE
 assert fetched('final-preflight-ref.mcp.json')['object']['sha']==r['prior_source_ref']=='3a26e6e9baba163c31d395e69e114af6a5c97efb'
 candidate=fetched('preflight-candidate-commit.mcp.json')
 assert candidate['sha']==REMOTE_SOURCE and candidate['tree']['sha']==TREE
 evidence=fetched('final-preflight-evidence.mcp.json')
 assert evidence['sha']==EVIDENCE and evidence['tree']['sha']=='83c94042b929cafd2c3d9023054726c56b89797f'
 prepared=value(prefix+'prepared-body-v4.json')
 assert prepared['snapshot']=='2026-11-13 02:10:35 UTC' and prepared['evidence_head']==EVIDENCE
 oldbody=saved['publication/ordinary-integrated-pr-body-afdf13ff-proposal-v4.md'][0]
 assert helpers.digest(oldbody)==prepared['sha256']
 assert b'2026-11-13 02:10:35 UTC' in body and EVIDENCE.encode() in body
 hname='validation/root-5e2426ad-native-inputs-v1/bundle-upload-reconciliation-info-v3.mcp.json'
 h=value(hname);assert h['result']['isError'] is True
 assert h['result']['structuredContent']['error_data']['payload']['error']['code']=='tunnel_client_not_seen'
 for item in r['files']:
  path=Path(item['path']);data,_=helpers.original(path)
  assert len(data)==item['bytes'] and helpers.digest(data)==item['sha256']
 archive=OUT/'originals.tar.xz';assert not archive.exists()
 with tarfile.open(archive,'x:xz',preset=6) as tar:
  for name,(data,metadata) in saved.items():
   entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=stat.S_IMODE(metadata['st_mode']);entry.mtime=metadata['st_mtime_ns']/1e9
   tar.addfile(entry,io.BytesIO(data))
 with tarfile.open(archive,'r:xz') as tar:
  members=tar.getmembers();assert len(members)==len(saved) and {m.name for m in members}==set(saved)
  for m in members:assert m.isfile() and tar.extractfile(m).read()==saved[m.name][0]
 for name,pair in saved.items():assert helpers.original(BASE/name)==pair
 # The requested publication directory itself is complete, not a selective subset.
 assert {str(p.relative_to(BASE)) for p in SOURCE.rglob('*') if p.is_file()}=={name for name in saved if name.startswith(prefix)}
 data,_=helpers.original(archive)
 manifest={'schema':1,'archive':archive.name,'archive_bytes':len(data),'archive_sha256':helpers.digest(data),
 'member_count':len(saved),'input_bytes':sum(len(x[0]) for x in saved.values()),'complete_publication_directory':str(SOURCE),
 'members':[{'path':name,'bytes':len(b),'sha256':helpers.digest(b),'source_stat':s} for name,(b,s) in saved.items()],
 'all_members_verified':True,'all_originals_rechecked_unchanged':True}
 verification={'schema':1,'status':'completed','original_publication_receipt_sha256':helpers.digest(receipt_bytes),
 'pr':{'number':6284,'draft':True,'merged':False,'source_head':REMOTE_SOURCE,'local_source_head':LOCAL_SOURCE,'source_tree':TREE,
 'prior_source_head':r['prior_source_ref'],'root_used_expected_sha_lease':True,'root_force':False,'body_exact_original_readback':True,'body_bytes':len(body),'body_sha256':helpers.digest(body)},
 'body_evidence_snapshot':{'head':EVIDENCE,'time':'2026-11-13 02:10:35 UTC','valid_at_original_snapshot':True,'not_rewritten_to_follow_new_evidence_head':True},
 'last_H_observation':{'started':h['started'],'finished':h['finished'],'original_sha256':helpers.digest(saved[hname][0]),
 'error_code':'tunnel_client_not_seen','old_bundle_landing':'unknown','new_fix_or_native_launch_claimed':False,'scope':'same external connection blocker; not a product or compile failure'},
 'actions_in_this_append':{'source_or_pr_mutation':False,'QA':False,'H':False,'native':False,'qualification_changed':False},
 'whole_qualification_counts':[0,0,0],'parent_evidence_head':EVIDENCE}
 helpers.write_new(OUT/'manifest.json',helpers.json_bytes(manifest))
 helpers.write_new(OUT/'verification.json',helpers.json_bytes(verification))
 readme="""# Final draft publication receipt and unchanged external blocker

This appendix preserves the complete original draft-afdf13ff-v1 directory, actual PR body v5 and its predecessor v4, the body generator, and the final H read-only connection observation. The exact original receipt is 3,870 bytes, SHA-256 d171c98fbadc7735679c2565e5885ea9ca7bfd746e09a2061ffe17579257cba2.

Root fast-forwarded the source branch with an expected-SHA lease from 3a26e6e9baba163c31d395e69e114af6a5c97efb to 69e711feff3bd67951d33d01f28b68172b35b20d and updated draft PR #6284. The independently read-back original responses show the exact source head, draft=true, merged=false and body bytes equal to v5 (21,760 bytes, SHA-256 8b808a75dcc275fce8b7218e9d0eb8e2b85192f722db0ebb63eaf0232f7bf662). The remote source tree matches local afdf13ffc1757c0dfa5d3f6922bde2d746251df7, tree 7eb8f9f742ce2a28327b6d7aae0b2f0f8cd7ebf4.

The body's evidence snapshot correctly identifies c65ef4add55e5ee99ce33cdb81fcc6ce6731638c at **2026-11-13 02:10:35 UTC**. This later appendix adds only publication receipts and the same external blocker; it does not invalidate that timestamped snapshot or require editing the PR to follow the evidence branch.

The final H observation at 02:09:13.520–02:09:13.915 UTC reports tunnel_client_not_seen after 300 seconds. The earlier bundle landing remains unknown. No new H fix or native run was started; this is an external connection blocker, not a newly observed product or compilation failure.

No existing archive, source ref or PR was changed by this append. No QA, H command or native test was executed. Qualification remains 0 / 0 / 0. Earlier failed native attempts, exact source QA and caller results remain in the parent evidence history.

Every archived member was read back and compared byte-for-byte. All requested original input bytes and metadata, including the complete publication directory, were rechecked unchanged. The published body is preserved as an original, not regenerated or edited here.
"""
 helpers.write_new(OUT/'README.md',readme.encode())
 infos=[]
 for p in sorted(OUT.iterdir()):
  b,_=helpers.original(p)
  infos.append({'name':p.name,'bytes':len(b),'sha256':helpers.digest(b),'git_blob':helpers.hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
 print(json.dumps({'output':str(OUT),'files':infos,'members':len(saved),'input_bytes':manifest['input_bytes']}))
if __name__=='__main__':main()
