## Purpose and current qualification

This PR connects the ordinary `q24-initial` and `q24-post-a` entries to the
existing concrete learning aggregate and preserves the original evidence across
the full process chain:

**A → original Decision and independent Outcome → frozen Dataset → actual
Training → independent B → Adopt or evaluated NoUpdate → CURRENT and task C →
completed-history recovery in new daemon and Root processes.**

> **Draft / unqualified. Adopt / evaluated post-B NoUpdate / whole daemon+Root
> cold recovery remain 0 / 0 / 0. Evidence snapshot: 2026-11-13 02:10:35 UTC.**
> The latest native A result belongs to **bfee** and is **0 PASS / 1 FAIL,
> 4.881 s**. The new Initial progress reader and its six tests have not been
> compiled or executed on H. Candidate **afdf13ff** passed the complete standard
> source QA: **926 / 926**, exit 0, unchanged source. The complete caller CLI
> passed on **5e**, whose Rust, CALLERS and scanner bytes are unchanged by the
> final QA-only correction. No afdf CLI execution or native success is inferred.

#6006 already contains real aggregate owners. #6018 repairs the strict generic
caller-proof locator. For #5981, the counterexample fails at the assertion that
the corrupt read must be rejected, **before the restore operation runs**. That
failure does not show that restored bytes were accepted after a rejected read.
The assertion-order correction and persistent Root refusal are reviewed
separately below.

## Production changes

### Original A assembly, publication and retirement

After the generic `startup.receive()`, Linux ordinary `main` invokes
`assemble_original_initial_q24` and `assemble_original_post_a_q24` before the
selected production launch runs. These assemblers use the actual Root session,
sealed deployment, original files and fixed Artifact/FinalUse inputs. Root activates Ledger trust and its Generator/Observer bindings. The
producer writes the original Decision; the independent Observer supplies the
signed terminal Outcome.

Root retains the original Objective append/sync publication before execution.
RunStart checks the original publisher's Running generation with checked
`spawn_generation + 1` and the matching objective fence, separately from the
Cell/model target. Full request, signature, session and physical checks remain.

PREPARED descriptor custody grants no captured history. The daemon initializes
its original Cell witness before Root validates the same descriptor. Reserve
requires the unwritten Generation target; Publish/capture require real genesis.
Fresh filesystem handoff pins only `run_root/prompt-runtime` for the exact
daemon UID/GID, mode 0700, keeping its Root parent 2750. Existing-child refusal
precedes ownership changes; recovery reuses the original directory.

Accepted control futures retain their owners through shutdown. Historical
capture requires actual drain, connection completion and owner release. The
material-session CLI requires actual old-writer retirement before a new
incarnation adopts the original physical checkpoint.

### New: read A's actual completion after a lost acknowledgement

The ordinary fixture submits the Objective **once**. The new opt-in Initial
progress query accepts that exact `AuthBusObjectiveIngress` and returns DATA
from the installed current producer and original RunStart owner. It does not
resubmit work or expose the C Update capability.

| Result | Required evidence and handling |
| --- | --- |
| `InFlight {}` | The exact original request and current producer pass validation, and the actual owned admission/worker pending count is nonzero. Only this typed result permits another read. |
| `Completed { data }` | Original admission publication, two strict Source/Decision observations, and two equal committed Automation traces agree on the run and history. The trace must be `Succeeded`, have zero unresolved work, and remain unchanged with the pending count still zero. |
| Error | Missing, withdrawn or corrupt Source, changed request/history, unavailable owner, fencing and transport errors fail closed. They do not become `InFlight` or completion. |

The current RunStart, producer identity and runtime checks execute again after
the observation, including its error path. A durable `Compiled` admission or a
zero pending count alone cannot supply `circuit_succeeded`. Completion DATA
contains the original admission, original task observation, Circuit revision
and history digest; it supplies no new execution or signing authority.

The fixture now preserves the actual reply distinction. A Conflict fails with
its run ID and conflict digest. A lost acknowledgement records and immediately
prints the original error, then uses only the read-only progress route. If that
read fails, the returned diagnostic retains both the original ACK error and the
observation error. It never manufactures an `ObjectiveRunAdmission` for the lost
ACK case. A received success ACK is cross-checked against the independently
read completion.

The original absolute deadline is retained throughout. Each control query keeps
its existing two-second frame bound; only typed `InFlight` schedules another
read, at 50 ms intervals capped by the same absolute end. No generic error is
retried, no new Objective is submitted, and no operation window is extended.
Successful Circuit completion still requires the independent Observer's signed
Outcome afterward. The progress query neither supplies that Outcome nor turns
task success into a reward.

### Historical learning and independent B

The historical route joins original RunStart, Source, Automation, Cell, Ledger
and witness cuts through existing read-only descriptors and canonical replay.
It neither reopens an old writer nor repairs a partial tail. Current Root and
trust checks remain separate from historical facts.

The post-A daemon freezes the Dataset with the original signer, releases that
writer, receives Root's late-install ACK and consumes the original Learning,
Model, publication and B handoffs. Owner assembly and each stage share the
bounded Prepared operation and original Trainer borrow, with physical, trust,
checkpoint and cancellation checks before/after, including errors. No authority
is cached across operations; 64 historical reads, 32 B frames, 500 ms frame
limits and absolute session ends remain fixed.

B's actual Root custodian holds fixed files, a signed preregistration and fixed
roles/controllers. It checks held-out data ownership, Generator policy
provenance, Observer evidence and Evaluator decision authority. PID/UID/machine
separation alone is insufficient; the learner receives no Evaluator key or
held-out labels.

Root binds actual Training candidate/work DATA to the authenticated cut, job,
Dataset, model/head shape and measured steps/work. A copied fixed-arm budget
cannot substitute. Label-free `PrepareCandidate` yields the original Generator's
durable plan challenge. The independent Source receives the actual candidate,
signs policy before observing held-out outcomes and submits original signed
business evidence. Held-out release/evaluation occur in `Complete` afterward.
Original outcome units and policy probabilities are preserved.

The runner re-reads the physical holdout consumption owner before/after release.
Model publication borrows native evidence from that same custodian; receipt
fields, generic CAS and manifest DATA cannot reconstruct qualification. The
independent Source waits for its final terminal notice before exit.

### Decision, CURRENT and the subsequent task C

The supervised continuation retains the actual owners, material, trust, history
receipt and successor handoff. Adopt uses the trained material, independent
decision, Artifact/Selection inputs and FinalUse checks to publish through the
original Root CURRENT CAS and execute C.

Evaluated NoUpdate retains the model but publishes a **new task CURRENT** through
`OwnerDrainedSameModel`. It still requires B's actual completed decision,
independent Selection, publication CAS and full C/retained-model NextUse
relationship. Model generation and C task/run/writer generation are distinct.
`TrainingNoUpdate`, which may legitimately skip B, does not qualify as this
evaluated-NoUpdate branch. Missing owners or evidence and uncertain writes are
not converted to NoUpdate.

Process fixtures invoke real binaries, independent Source/Observer processes,
original handoffs, Artifact signatures, C and retirement. Test-only custody
preserves original paths/inodes on early failure without changing the error,
result, deadline or evidence bytes.

### First acceptance, persistent refusal and completed-history recovery

Root arms refusal before authority/primary observation. The complete callback,
physical postchecks and original end must finish before exact-attempt Ready.
Restoring primary bytes alone cannot clear an armed crash or observed corruption.

Actual first Prepared→Published creates immutable publication acceptance inside
that arm; repeated Publish preserves it. Old records lacking the fact cannot
be backfilled. Fresh terminal acceptance joins completed learning/publication
while the original signatures, work window and session are valid. It does not
wait for C retirement or first appear after the old lease expires.

A new recipient then uses explicit CaptureRetired followed by ReadFinalized,
under current Root/trust/revocation checks and actual old-process retirement.
This early daemon branch opens no old Freeze, Delivery, Trainer, Model or C
writer, and grants no execution, renewed signature or new Selection. Completion
DATA appears only after actual C Finalized and Root Ready. NoUpdate must have
its real same-model C publication and full NextUse; Initial-only CURRENT fails.

Only a consumed one-shot Root request, validated reply and delivery postchecks
produce the private terminal ACK in State. Its zero-payload query sends no new
Root request. Before shutdown the fixture requires both the physical first
fact/Ready and matching daemon ACK, then rechecks the physical bytes. Disk Ready
alone cannot justify an early stop.

Tests separate baseline, corrupt read and restored read. Same-handle poisoning
is not a cold fence; persistent refusal does not cover joint rollback of its
independent authority/refusal state.

## Review map

Agentd filenames below are under `codex-rs/hepta-agentd/src/`.

| Area | Main review points |
| --- | --- |
| Ordinary assembly/custody | `main.rs`, `production_initial_q24.rs`, `production_post_a_q24.rs`, `root_agentd_filesystem.rs` |
| New Initial readback | `state_q24_outcome.rs`, `objective_history.rs`, `cell_q24_task_observation_control.rs`, `client_q24_outcome.rs`; protocol: `hepta-agent-protocol/src/q24_initial_task_progress.rs` |
| Single-submit fixture/tests | `ordinary_q24_process_completion_tests.rs`, `ordinary_q24_process_tests.rs`, `cell_q24_initial_task_progress_control_tests.rs` |
| Historical learning/B | `cell_q24_learning_historical_operation.rs`, `authority_host_q24_evaluation_prepare.rs`, `authority_host_q24_evaluation_execute.rs` |
| CURRENT and cold | `production_post_a_continuation.rs`, `authority_host_publication_refusal.rs`, `authority_host_completed_observation.rs`, `root_completed_learning_history.rs` |

`CALLERS.toml` and source tests retain exact callers, unknown-receiver refusal
and ordered checks. Stage562 adds the actual Observation module to the source
test's expected identity-caller tuple, already declared by the product change.
It changes neither the checker nor Rust.

## Current source and validation

**Snapshot: 2026-11-13 02:10:35 UTC.** Source branch and this draft PR identify the
candidate below; exact-candidate native inputs remain prepared only. Results
remain attached to their exact source. The original bfee native failure and
5e incomplete QA are preserved alongside the later successful source checks.

| Identity | Value |
| --- | --- |
| Local source HEAD | `afdf13ffc1757c0dfa5d3f6922bde2d746251df7` |
| Source tree | `7eb8f9f742ce2a28327b6d7aae0b2f0f8cd7ebf4` |
| Published remote source HEAD | [`69e711feff3bd67951d33d01f28b68172b35b20d`](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/69e711feff3bd67951d33d01f28b68172b35b20d), exact same tree |
| Candidate physical snapshot | 15,500 files, 234,446,647 B; SHA256 `10d16cdd1f455bb0ea756b72156658f33e6a34f1e6f15ccc88c74e4aade5191d` |
| Source branch | `codex/learn-eval-ordinary-integrated-20261112-ff41` → `69e711feff3bd67951d33d01f28b68172b35b20d`; draft, not merged |
| Latest immutable evidence HEAD | `c65ef4add55e5ee99ce33cdb81fcc6ce6731638c` |

Stages559–561 contain the product reader, fixture and actual-owner tests; 562
corrects the source-test tuple. All four objects have independent parent,
message and tree GET checks. Publication is not execution.

### New candidate: observed limits

| Gate / exact source | Actual status at this snapshot |
| --- | --- |
| **5e full source QA** | **Exit -9**, 169.911983 s, unchanged source. Before termination, stderr explicitly emitted **FAIL** for `test_exact_product_callers_and_inventory`, subtest `q24_outcome_control_original_identity`. There is no terminal suite count or PASS. |
| **5e complete caller CLI** | **PASS**, exit 0, 693.037307 s, unchanged source: 6,892 Rust files, 1,113 boundaries, 1,113 inventory entries, 878 protected entries; `authorityGranted=false`. afdf changes only the three-line Python test expectation; no afdf CLI run is claimed. |
| **afdf complete standard source QA** | **926 / 926 PASS**, exit 0. Standard unittest discovery reported 218.235 s; the original gate took 221.270096 s and preserved all 15,500 tracked files. The launcher added only read-only same-process resource sampling; no grouping, timeout, signal, retry or test/environment change. |
| **562 focused caller-expectation module** | **16 PASS**, exit 0, 1.978769 s on the exact corrected file; formatting passed. This addresses the observed stale tuple, not the unexplained signal termination or full-suite qualification. |
| **H source transfer / compile** | Tunnel disconnected; the earlier 5e bundle-write disposition remains unknown. Exact afdf bundle, scoped-fix, A and full-v3 inputs are prepared locally only. Drivers have not been uploaded or launched, and 559–562 have no H compile result. The uncertain transfer has not been replayed. |
| **Six new Initial tests** | Source exists; **not H-compiled or executed**. No native PASS is assigned. |
| **Whole chains and cold** | Both decision paths and both cold parents have test coverage, but no qualifying native completion. Adopt / evaluated post-B NoUpdate / whole cold remain **0 / 0 / 0**. |

The old emitted assertion failure and the `-9` termination remain separate
facts. Neither OOM nor timeout is established as the old termination cause.
The later afdf 926-test PASS is a distinct, complete standard run. Its 221
same-PID/start resource samples and original rusage are retained; they do not
retroactively diagnose the earlier signals. The focused repair and full PASS
do not erase either original failure or qualify native behavior.

Six source tests cover ACK-loss diagnostics, Conflict, real-owner successful
completion, changed-request/withdrawn-source refusal with unchanged journals,
missing/fenced producer and strict `type`/`status` wire DATA. They do not
resubmit work, supply Outcome or manually alter pending counters. Their native
results remain unverified.

### Prior native results: bfee and fbf only

| Source / gate | Observed result |
| --- | --- |
| **bfee caller CLI** | PASS, exit 0, 700.340937 s; full index and unchanged source. |
| **bfee full source QA** | Exit -9, 186.299917 s; cause unestablished, no complete QA PASS. |
| **bfee H fix v1 / v2** | v1 failed preflight before Rust because nine tracked archives were absent. v2 created only the verified missing archives, then seven-package fix passed in 114.677389 s with complete 15,497-file/dfed source unchanged and empty `fix.patch`. The v1 originals remain preserved. |
| **bfee A driver v2** | Binding **6 PASS**, reducer **2 PASS**, filesystem **2 PASS**; A **0 PASS / 1 FAIL, 4.881 s**. Initial readiness completed in 56.525 ms. Both child status-9 exits were failure cleanup. |
| **fbf predecessor** | Seven-package fix passed; **926/926 source QA PASS**; caller CLI PASS in 803.908973 s; binding **6 PASS**, filesystem **2 PASS**, A **0 PASS / 1 FAIL, 2.905 s**. |

These predecessor results do not transfer to afdf.

### What the retained bfee originals actually show

The bfee parent reported `ordinary original Objective returned conflict or
uncertain ACK; no inferred execution`. That message merged two reply variants;
it does not establish the actual ACK error, a timeout, or completed execution.
The new fixture preserves the original variant and error for the next run.

Read-only diagnostics of the retained archive observed:

- Circuit kept its original **120,000 ms** limit. First Advance was **2,908 ms**
  after creation, and computation was claimed 6 ms later. The archived state
  was revision 2, one activation `in_flight`, `stop_reason=null`, with only
  Created, Advance and computation-claimed events and no terminal event.
- RunStart framing contained one v2 `Compiled` record, generation 2, and no
  Conflict record. Source had request/input claim-and-complete pairs, with no
  result or withdrawal stage.
- Cell framing contained a single HPTACJ04 tag-3 admission, snapshot revision 0,
  writer epoch 1 and model generation 1. These bytes contained no queue-age or
  commit frame. The actual learning-outbox query returned zero rows.

These are DATA observations, not authenticated receipts or inferred ACKs.
The 261-original archive and durable DB/WAL copies remained unchanged during
`mode=ro`/`query_only` analysis; only private SHM cache changed. No business
owner was reopened and no task replayed.

The earlier fbf archive has a different failure: the fixture declared a
1,000 ms Circuit limit and first Advance occurred 2,880 ms after creation;
revision 1 stopped with `deadline` and a cancelled activation. **Source
analysis**, distinct from those observed bytes, connects absent dispatch/input
to `Missing → reconciliation`. Stage557 binds the pre-owner Circuit declaration
to the original Source lease, without changing observed time or extending an
active deadline. Its two reducer tests passed at bfee; bfee's in-flight prefix
does not repeat that old Deadline result.

### Immutable evidence and remaining gates

Latest evidence HEAD:
[`c65ef4add55e5ee99ce33cdb81fcc6ce6731638c`](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/c65ef4add55e5ee99ce33cdb81fcc6ce6731638c).
Its history preserves:

- [afdf complete 926-test QA and original resource observations](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/c65ef4add55e5ee99ce33cdb81fcc6ce6731638c/qualification/learn-native-evidence-20261113/afdf13ff-source-qa-v1).
- [5e complete caller CLI and retained prior QA](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/c65ef4add55e5ee99ce33cdb81fcc6ce6731638c/qualification/learn-native-evidence-20261113/5e2426ad-full-caller-v1).
- [Exact-caller repair, prepared native inputs and unresolved H transfer](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/c65ef4add55e5ee99ce33cdb81fcc6ce6731638c/qualification/learn-native-evidence-20261113/afdf13ff-prepared-support-v1).
- [5e QA originals and emitted failure](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/c65ef4add55e5ee99ce33cdb81fcc6ce6731638c/qualification/learn-native-evidence-20261113/5e2426ad-source-qa-v1).
- [bfee native originals and DATA diagnostics](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/0786f9ae916bb245bef1d43a847bd4e81917e497/qualification/learn-native-evidence-20261113/bfee5aa3-native-originals-v2).
- [bfee source/caller gates](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/226a4bbd27728bb87b32de878ce87683970cb985/qualification/learn-native-evidence-20261113/bfee5aa3-source-gates-v1)
  and [fbf originals/Deadline DATA](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/5b21d40eed1178b8861724e88908e5f619f38bc5/qualification/learn-native-evidence-20261113/fbf2cc0a-complete-originals-v1).

Local `tooling/publication/evidence-5e2426ad-source-qa-20261113-v1/` and
`evidence-bfee5aa3-native-originals-20261113-v2/` retain their respective
`publication-receipt.json` byte checks. Candidate input manifest:
`tooling/validation/root-afdf13ff-native-inputs-v1/manifest.json`, prepared only.

The intended complete schedule remains **A → Adopt → actual post-B NoUpdate →
Adopt cold → evaluated-NoUpdate cold → Root48 → seven libraries → full source
QA → full caller CLI**. Root48 preserves all original 45 names, the PREPARED
Cell case and two acceptance negatives; filesystem2 remains separately
identified. UID1000 builds precede actual UID0 tests, with exact rosters, fresh
JUnit, zero retries and retained failure originals. Both cold parents use their
existing 480 s harness watchdogs; product 60 s/120 s/300 s bounds, signature
windows, 500 ms frames and 64/32 limits remain fixed.

The next gates are H tunnel restoration and reconciliation of the exact old
5e bundle path, followed by exact-candidate H compile, the six new tests/A,
both decision/C chains and both cold parents. The current source checks are
complete within the exact-source scopes stated above; they do not replace the
final source/caller gates in the unexecuted full native schedule. Component or
source passes cannot substitute for actual process outcomes. **Qualification
remains 0 / 0 / 0.**
