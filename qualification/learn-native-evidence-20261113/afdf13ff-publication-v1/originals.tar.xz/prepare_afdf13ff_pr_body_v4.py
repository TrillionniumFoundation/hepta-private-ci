"""Prepare a reviewable PR update from the exact terminal source receipts."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path('/workspace/scratch/ff41dfc0f7bf/tooling')
EVIDENCE_HEAD = sys.argv[1]
QA_EVIDENCE_PATH = sys.argv[2]
PREPARED_EVIDENCE_PATH = sys.argv[3]
CALLER_EVIDENCE_PATH = sys.argv[4]
assert re.fullmatch('[0-9a-f]{40}', EVIDENCE_HEAD)
for value in (QA_EVIDENCE_PATH, PREPARED_EVIDENCE_PATH, CALLER_EVIDENCE_PATH):
    assert value.startswith('qualification/learn-native-evidence-20261113/')
    assert '..' not in value and re.fullmatch('[A-Za-z0-9/_-]+', value)
qa = json.loads((ROOT / 'validation/root-afdf13ff-full-source-ci-evidence-monitored-v1/result.json').read_text())
cli = json.loads((ROOT / 'validation/root-5e2426ad-full-source-caller-ci-evidence-v1/fullcallers.json').read_text())
assert qa['all_gates_passed'] and qa['source_unchanged']
assert qa['source']['head'] == 'afdf13ffc1757c0dfa5d3f6922bde2d746251df7'
assert qa['full_caller_executed'] is False
assert len(qa['stages']) == 1 and qa['stages'][0]['exit_code'] == 0
assert cli['exit_code'] == 0 and cli['source_unchanged']
assert 'Ran 926 tests in 218.235s\n\nOK\n' in (ROOT / 'validation/root-afdf13ff-full-source-ci-evidence-monitored-v1/fullsource.stderr.log').read_text()
original = ROOT / 'publication/ordinary-integrated-pr-body-afdf13ff-proposal-v3.md'
body = original.read_text()
assert hashlib.sha256(original.read_bytes()).hexdigest() == '4ec0aa4530e178b7be254a2795e2fcff8ecb7c2fdb336059e17473917b4ccf28'
now = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')
body = body.replace('2026-11-13 02:01:21 UTC', now)
old = '''> compiled or executed on H. Candidate **afdf13ff** includes the exact-caller
> expectation correction; its focused 16-test source module passed, but full
> source, full caller and native qualification are still outstanding.'''
new = '''> compiled or executed on H. Candidate **afdf13ff** passed the complete standard
> source QA: **926 / 926**, exit 0, unchanged source. The complete caller CLI
> passed on **5e**, whose Rust, CALLERS and scanner bytes are unchanged by the
> final QA-only correction. No afdf CLI execution or native success is inferred.'''
assert old in body
body = body.replace(old, new)
old = '''Ordinary `main` invokes the explicit Initial/post-A assemblers using the actual
Root session, sealed deployment, original files and fixed Artifact/FinalUse
inputs.'''
new = '''After the generic `startup.receive()`, Linux ordinary `main` invokes
`assemble_original_initial_q24` and `assemble_original_post_a_q24` before the
selected production launch runs. These assemblers use the actual Root session,
sealed deployment, original files and fixed Artifact/FinalUse inputs.'''
assert old in body
body = body.replace(old, new)
old = '''**Snapshot: ''' + now + '''.** Local proposal only: source objects and
exact-candidate native inputs are prepared; this proposal has not moved the
branch or updated PR #6284. Results remain attached to their exact source.'''
new = '''**Snapshot: ''' + now + '''.** Source branch and this draft PR identify the
candidate below; exact-candidate native inputs remain prepared only. Results
remain attached to their exact source. The original bfee native failure and
5e incomplete QA are preserved alongside the later successful source checks.'''
assert old in body
body = body.replace(old, new)
body = body.replace('| Proposed local HEAD |', '| Local source HEAD |').replace('| Proposed tree |', '| Source tree |').replace('| Immutable proposed remote object |', '| Published remote source HEAD |')
old = '| Source branch last published by Root | `3a26e6e9baba163c31d395e69e114af6a5c97efb`, corresponding to bfee |'
new = '| Source branch | `codex/learn-eval-ordinary-integrated-20261112-ff41` → `69e711feff3bd67951d33d01f28b68172b35b20d`; draft, not merged |'
assert old in body
body = body.replace(old, new)
old = '| **5e complete caller CLI** | Started 01:48:41 UTC and still recorded as **running**. No terminal result is claimed. |'
new = '| **5e complete caller CLI** | **PASS**, exit 0, 693.037307 s, unchanged source: 6,892 Rust files, 1,113 boundaries, 1,113 inventory entries, 878 protected entries; `authorityGranted=false`. afdf changes only the three-line Python test expectation; no afdf CLI run is claimed. |\n| **afdf complete standard source QA** | **926 / 926 PASS**, exit 0. Standard unittest discovery reported 218.235 s; the original gate took 221.270096 s and preserved all 15,500 tracked files. The launcher added only read-only same-process resource sampling; no grouping, timeout, signal, retry or test/environment change. |'
assert old in body
body = body.replace(old, new)
old = '''The emitted assertion failure and the `-9` termination are separate facts.
Neither OOM nor timeout is established as the termination cause. The exact
562 focused pass does not erase the earlier failure or turn the partial full
run into a completed suite.'''
new = '''The old emitted assertion failure and the `-9` termination remain separate
facts. Neither OOM nor timeout is established as the old termination cause.
The later afdf 926-test PASS is a distinct, complete standard run. Its 221
same-PID/start resource samples and original rusage are retained; they do not
retroactively diagnose the earlier signals. The focused repair and full PASS
do not erase either original failure or qualify native behavior.'''
assert old in body
body = body.replace(old, new)
body = body.replace('a2fc53ba8037c0577e61b8a5c1d78d5a5df0b1b5', EVIDENCE_HEAD)
prefix = 'https://github.com/TrillionniumFoundation/hepta-private-ci/tree/' + EVIDENCE_HEAD + '/'
marker = 'Its history preserves:\n\n'
assert marker in body
body = body.replace(marker, marker + '\n'.join([
    '- [afdf complete 926-test QA and original resource observations](' + prefix + QA_EVIDENCE_PATH + ').',
    '- [5e complete caller CLI and retained prior QA](' + prefix + CALLER_EVIDENCE_PATH + ').',
    '- [Exact-caller repair, prepared native inputs and unresolved H transfer](' + prefix + PREPARED_EVIDENCE_PATH + ').',
]) + '\n')
old = '''The next gates are reconciled transfer, exact-candidate H compile and the six
new tests/A, followed by both decision/C chains and both cold parents. Final
source/caller and native results are still required. Component/source passes
cannot substitute for those process outcomes. **Qualification remains 0 / 0 / 0.**'''
new = '''The next gates are H tunnel restoration and reconciliation of the exact old
5e bundle path, followed by exact-candidate H compile, the six new tests/A,
both decision/C chains and both cold parents. The current source checks are
complete within the exact-source scopes stated above; they do not replace the
final source/caller gates in the unexecuted full native schedule. Component or
source passes cannot substitute for actual process outcomes. **Qualification
remains 0 / 0 / 0.**'''
assert old in body
body = body.replace(old, new)
assert 'still recorded as **running**' not in body
assert 'full source, full caller and native qualification are still outstanding' not in body
out = ROOT / 'publication/ordinary-integrated-pr-body-afdf13ff-proposal-v4.md'
with out.open('x') as stream:
    stream.write(body)
record = dict(path=str(out), bytes=out.stat().st_size,
              sha256=hashlib.sha256(out.read_bytes()).hexdigest(), snapshot=now,
              evidence_head=EVIDENCE_HEAD, native_tests_executed=0,
              source_head='69e711feff3bd67951d33d01f28b68172b35b20d',
              scope='Prepared reviewable body. External publication is a separate lease-protected action with readback.')
with (ROOT / 'publication/draft-afdf13ff-v1/prepared-body-v4.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
