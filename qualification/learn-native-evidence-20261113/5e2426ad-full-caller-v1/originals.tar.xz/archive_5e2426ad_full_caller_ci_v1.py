#!/usr/bin/env python3
"""Freeze complete exact 5e caller evidence; never run the verifier or tests."""
from pathlib import Path
import importlib.util
import json
import io
import stat
import tarfile

BASE=Path('/workspace/scratch/ff41dfc0f7bf/tooling')
HELPER=BASE/'archive_bfee_native_originals_ci_v3.py'
spec=importlib.util.spec_from_file_location('exact_evidence_io',HELPER)
helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
SOURCE=BASE/'validation/root-5e2426ad-full-source-caller-ci-evidence-v1'
OUT=BASE/'publication/evidence-5e2426ad-full-caller-20261113-v1'
HEAD='5e2426ad737fc5f8bef5c69e4a49f4b9a0275be4'
TREE='d9e8346daaa98162d583b7b5c8aad5b49cf960ed'

def main():
 OUT.mkdir(exist_ok=True)
 files=[p for p in SOURCE.iterdir() if p.is_file()]
 files += [HELPER,Path(__file__),BASE/'run_root_5e2426ad_full_source_caller_ci_evidence_v1.py',
 BASE/'publication/evidence-5e2426ad-source-qa-20261113-v1/publication-receipt.json']
 saved={str(p.relative_to(BASE)):helpers.original(p) for p in sorted(set(files))}
 prefix=str(SOURCE.relative_to(BASE))+'/'
 result=json.loads(saved[prefix+'result.json'][0])
 gate=json.loads(saved[prefix+'fullcallers.json'][0])
 receipt=json.loads(saved[prefix+'fullcallers.stdout.log'][0])
 assert result['status']=='completed' and result['source_unchanged'] and not result['all_gates_passed']
 assert result['source']==result['after']==gate['before']==gate['after']
 assert result['source']['head']==HEAD and result['source']['tree']==TREE
 assert gate['status']=='completed' and gate['exit_code']==0 and gate['source_unchanged']
 assert receipt['status']=='PASS_HEPTA_CALLER_CLOSED_SET' and receipt['authorityGranted'] is False
 assert receipt['rustFilesScanned']==6892 and len(receipt['boundaries'])==1113
 assert len(receipt['privilegedInventory'])==1113 and len(receipt['protectedFiles'])==878
 assert saved[prefix+'fullcallers.stderr.log'][0]==b''
 assert helpers.digest(saved[prefix+'fullcallers.stdout.log'][0])=='090d7b2761fc331aca3bfb069e80a2a3a1934551b5985160ad8109fb1574ce47'
 assert result['stages'][0]['exit_code']==-9
 terminal=json.loads(saved[prefix+'terminal-tool.original.json'][0])
 assert terminal['exit_code']==1
 archive=OUT/'originals.tar.xz';assert not archive.exists()
 with tarfile.open(archive,'x:xz',preset=6) as tar:
  for name,(data,metadata) in saved.items():
   e=tarfile.TarInfo(name);e.size=len(data);e.mode=stat.S_IMODE(metadata['st_mode']);e.mtime=metadata['st_mtime_ns']/1e9
   tar.addfile(e,io.BytesIO(data))
 with tarfile.open(archive,'r:xz') as tar:
  members=tar.getmembers();assert len(members)==len(saved) and {m.name for m in members}==set(saved)
  for m in members:assert m.isfile() and tar.extractfile(m).read()==saved[m.name][0]
 for name,pair in saved.items():assert helpers.original(BASE/name)==pair
 body,_=helpers.original(archive)
 manifest={'schema':1,'head':HEAD,'tree':TREE,'archive':archive.name,'archive_bytes':len(body),'archive_sha256':helpers.digest(body),
 'member_count':len(saved),'input_bytes':sum(len(x[0]) for x in saved.values()),
 'members':[{'path':name,'bytes':len(b),'sha256':helpers.digest(b),'source_stat':s} for name,(b,s) in saved.items()],
 'all_originals_unchanged':True,'all_members_verified':True}
 verification={'schema':1,'head':HEAD,'tree':TREE,'full_caller':{k:gate[k] for k in ['status','exit_code','started','finished','elapsed_seconds','source_unchanged','command','files']},
 'rust_files':6892,'boundaries':1113,'inventory':1113,'protected':878,'authority_granted':False,
 'source_snapshot':result['source'],'whole_driver_exit':1,'source_qa_exit':-9,'whole_driver_all_gates_passed':False,
 'different_candidate_cli_claimed':False,'native_tests_executed':0,'whole_qualification_counts':[0,0,0],
 'previous_evidence_head':'a2fc53ba8037c0577e61b8a5c1d78d5a5df0b1b5'}
 helpers.write_new(OUT/'manifest.json',helpers.json_bytes(manifest))
 helpers.write_new(OUT/'verification.json',helpers.json_bytes(verification))
 readme="""# Actual complete caller CLI on 5e2426ad

The unchanged full command `python3 scripts/verify_hepta_callers.py verify --root <isolated-checkout>` completed exit 0 on exact 5e2426ad737fc5f8bef5c69e4a49f4b9a0275be4 / tree d9e8346daaa98162d583b7b5c8aad5b49cf960ed. It ran 01:48:41.243888–02:00:14.281319 UTC (693.037306803 seconds).

The actual receipt reports 6,892 Rust files, 1,113 boundaries, 1,113 privileged inventory entries and 878 protected files, with authorityGranted=false. Stdout is the complete 534,529-byte receipt, SHA-256 090d7b2761fc331aca3bfb069e80a2a3a1934551b5985160ad8109fb1574ce47; stderr is empty. Complete physical source snapshots before and after are equal (15,500 files, SHA-256 60df345e7700fc84d422370878e5af9aaf5902a12491be830b946e324992bb6b).

The preceding standard unittest discovery on this same version returned -9 and had already emitted one identity-caller subtest FAIL. Its immutable separate appendix remains in the parent history; the complete outer driver still exited 1 and all_gates_passed=false. This caller success is not a source-suite pass, native result, authority receipt or whole-chain qualification. No timeout/OOM cause is assigned to the earlier QA termination.

All closed original driver files, raw stdout/stderr, full source snapshots, prior signal/failure/resource observations, static driver-retention review and publication receipt are retained. The static memory-retention review is not live whole-suite profiling. This appendix does not claim that the later QA-only revision executed this CLI.

Every tar member was compared with its exact original bytes and each original metadata/byte state was checked again. Source, gates and scanner were not altered. Native tests were not run; whole counts remain 0/0/0.
"""
 helpers.write_new(OUT/'README.md',readme.encode())
 infos=[]
 for p in sorted(OUT.iterdir()):
  b,_=helpers.original(p)
  infos.append({'name':p.name,'bytes':len(b),'sha256':helpers.digest(b),'git_blob':helpers.hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
 print(json.dumps({'output':str(OUT),'files':infos,'members':len(saved),'input_bytes':manifest['input_bytes']}))
if __name__=='__main__':main()
