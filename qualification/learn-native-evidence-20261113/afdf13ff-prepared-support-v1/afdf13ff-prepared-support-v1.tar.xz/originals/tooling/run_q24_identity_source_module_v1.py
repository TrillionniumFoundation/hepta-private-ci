"""Retain an exact, focused source-QA run; no native execution or retries."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

REPO = Path('/workspace/scratch/ff41dfc0f7bf/hepta-integration-recovered-cloud')
OUT = Path(sys.argv[1])
OUT.mkdir(parents=True, exist_ok=False)
COMMAND = [sys.executable, '-m', 'unittest', 'discover', '-s', 'qa/b4-no-bypass',
           '-p', 'test_q24_original_outcome_control_source_closure.py', '-v']


def snapshot():
    def git(*args):
        return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=REPO)
    digest = hashlib.sha256()
    count = size = 0
    for entry in git('ls-files', '-s', '-z').split(b'\0'):
        if not entry:
            continue
        meta, name = entry.split(b'\t', 1)
        path = REPO / os.fsdecode(name)
        data = os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes()
        digest.update(meta.split()[0] + b'\0' + name + b'\0' + hashlib.sha256(data).digest())
        count += 1
        size += len(data)
    return dict(head=git('rev-parse', 'HEAD').decode().strip(),
                tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
                status=git('status', '--porcelain=v1', '--untracked-files=all').decode(),
                tracked_files=count, tracked_bytes=size, tracked_sha256=digest.hexdigest())


def save(result):
    temp = OUT / 'result.json.tmp'
    temp.write_text(json.dumps(result, indent=2) + '\n')
    temp.replace(OUT / 'result.json')


result = dict(command=COMMAND, cwd=str(REPO), before=snapshot(), status='running',
              started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              native_tests_executed=0)
save(result)
start = time.monotonic()
with (OUT / 'stdout.log').open('xb') as stdout, (OUT / 'stderr.log').open('xb') as stderr:
    child = subprocess.run(COMMAND, cwd=REPO,
                           env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'},
                           stdout=stdout, stderr=stderr)
result.update(status='completed', exit_code=child.returncode,
              finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              elapsed_seconds=time.monotonic() - start, after=snapshot())
result['source_unchanged'] = result['before'] == result['after']
result['files'] = {p.name: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                   for p in sorted(OUT.glob('*.log'))}
save(result)
print(json.dumps(result))
print((OUT / 'stderr.log').read_text())
sys.exit(child.returncode if result['source_unchanged'] else 98)
