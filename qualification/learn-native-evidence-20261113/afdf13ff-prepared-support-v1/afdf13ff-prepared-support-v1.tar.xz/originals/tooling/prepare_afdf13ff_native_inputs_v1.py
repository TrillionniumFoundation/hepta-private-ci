"""Prepare create-only inputs for the corrected candidate; never execute H or Rust."""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/scratch/ff41dfc0f7bf')
REPO = ROOT / 'hepta-integration-recovered-cloud'
OUT = ROOT / 'tooling/validation/root-afdf13ff-native-inputs-v1'
HEAD = 'afdf13ffc1757c0dfa5d3f6922bde2d746251df7'
TREE = '7eb8f9f742ce2a28327b6d7aae0b2f0f8cd7ebf4'
BASE = 'bfee5aa363cb63897c28c8f74fd6b167de5e859b'
TAG = HEAD[:8]
REMOTE = '/home/qq/hepta-learn-ff41-tools/'


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=REPO)


def metadata(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                remote_path=REMOTE + path.name)


assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
assert not git('status', '--porcelain=v1', '--untracked-files=all')
digest = hashlib.sha256()
count = size = 0
for entry in git('ls-files', '-s', '-z').split(b'\0'):
    if not entry:
        continue
    meta, name = entry.split(b'\t', 1)
    path = REPO / os.fsdecode(name)
    data = os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes()
    digest.update(meta.split()[0] + b'\0' + name + b'\0' + hashlib.sha256(data).digest())
    count += 1
    size += len(data)
assert count == 15500 and size == 234446647
assert digest.hexdigest() == '10d16cdd1f455bb0ea756b72156658f33e6a34f1e6f15ccc88c74e4aade5191d'
OUT.mkdir(parents=True, exist_ok=False)
bundle = OUT / f'root-{TAG}-source.bundle'
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^' + BASE], cwd=REPO, check=True)
with (OUT / 'bundle-verify.stdout.log').open('xb') as stdout, (OUT / 'bundle-verify.stderr.log').open('xb') as stderr:
    subprocess.run(['git', 'bundle', 'verify', str(bundle)], cwd=REPO, stdout=stdout, stderr=stderr, check=True)
assert git('bundle', 'list-heads', str(bundle)).decode() == HEAD + ' HEAD\n'
bundle_meta = metadata(bundle)
fix_template = ROOT / 'tooling/root_original_initial_progress_scoped_fix_template_v2.py'
fix = fix_template.read_text()
for marker, value in {
    '__NEXT_TAG__': TAG, '__NEXT_TAG_UPPER__': TAG.upper(), '__NEXT_HEAD__': HEAD,
    '__NEXT_TREE__': TREE, '__NEXT_COUNT__': str(count), '__NEXT_SNAPSHOT__': digest.hexdigest(),
    '__NEXT_BUNDLE_BYTES__': str(bundle_meta['bytes']), '__NEXT_BUNDLE_SHA256__': bundle_meta['sha256'],
}.items():
    assert marker in fix
    fix = fix.replace(marker, value)
assert not re.search(r'__NEXT_[A-Z_]+__', fix)
native_old_path = ROOT / 'tooling/root_5e2426ad_native_tests_v1.py'
native_old = native_old_path.read_text()
native = native_old.replace('5e2426ad737fc5f8bef5c69e4a49f4b9a0275be4', HEAD).replace(
    'd9e8346daaa98162d583b7b5c8aad5b49cf960ed', TREE).replace('5e2426ad', TAG)
assert native.replace(HEAD, '5e2426ad737fc5f8bef5c69e4a49f4b9a0275be4').replace(
    TREE, 'd9e8346daaa98162d583b7b5c8aad5b49cf960ed').replace(TAG, '5e2426ad') == native_old
full_template = ROOT / 'tooling/root_completed_chain_native_template_v3.py'
full = full_template.read_text()
for marker, value in {
    '__FROZEN_REPO_ABSOLUTE__': '/home/qq/hepta-learn-ff41-native-root-279deb99-v1',
    '__NEW_UNIQUE_RUN_ID__': f'root-{TAG}-full-v1',
    '__MATCHING_SCOPED_FIX_RESULT_JSON__': REMOTE + f'validation/root-{TAG}-scoped-fix-v1/result.json',
    '__SOURCE_HEAD_40_HEX__': HEAD, '__SOURCE_TREE_40_HEX__': TREE,
}.items():
    assert marker in full
    full = full.replace(marker, value)
assert not re.search(r'__(?:FROZEN|NEW_UNIQUE|MATCHING|SOURCE)_[A-Z0-9_]+__', full)
scripts = [
    (ROOT / f'tooling/root_{TAG}_scoped_fix_v1.py', fix),
    (ROOT / f'tooling/root_{TAG}_native_tests_v1.py', native),
    (ROOT / f'tooling/root_{TAG}_completed_chain_v1.py', full),
]
for path, source in scripts:
    ast.parse(source, filename=str(path))
    with path.open('x') as stream:
        stream.write(source)
manifest = dict(
    schema=1, created=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source=dict(head=HEAD, tree=TREE, status='', tracked_files=count, tracked_bytes=size,
                tracked_sha256=digest.hexdigest(), hash_format='mode NUL path NUL SHA256(content), git index order'),
    predecessor=BASE, items=[bundle_meta, *[metadata(path) for path, _ in scripts]],
    templates=[metadata(fix_template), metadata(native_old_path), metadata(full_template)],
    native_driver_change='Only exact source head/tree, namespace and matching fix-record path; normalized bytes equal the reviewed 5e driver.',
    execution_status='prepared only; no upload or H/Rust/native execution',
    predecessor_upload_status='5e bundle create-only upload timed out; landing unknown; two read-only reconciliations report tunnel disconnected. Never launched its fix or native drivers.',
    original_5e_files_preserved=True,
    required_before_H_mutation='Restore H tunnel, reconcile the exact original 5e bundle path, and revalidate stable bfee source and no active compiler before candidate import.',
    whole_chain_qualified=dict(positive=0, evaluated_no_update=0, daemon_and_root_cold=0),
)
with (OUT / 'manifest.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
    stream.write('\n')
print(json.dumps(manifest))
