#!/usr/bin/env python3
"""Collect one closed ordinary-chain attempt; never compile or execute tests.

All inputs are read-only. Output archives contain regular-file bytes, while
links, sockets, FIFOs and excluded environment/executable files are described
in the manifest only. No native success is inferred from successful collection.
"""

import argparse
import ast
from dataclasses import dataclass
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import tarfile
import traceback
import xml.etree.ElementTree as ET

BASE = Path('/home/qq/hepta-learn-ff41-tools')
RUN_PARENT = Path('/run')
TEMP_PARENT = Path('/tmp')
MAX_FILE = 256 * 1024 * 1024
MAX_TOTAL = 2 * 1024 * 1024 * 1024
MAX_ENTRIES = 50_000
NEVER_READ_IDS = set()
VERIFIED_PUBLIC_ENV = {}
ORIGINAL_DRIVERS = set()
PIN_DIRECTORIES = ()
DECODED_ORIGINALS = {}
PREFIX = 'neuron_generation_current::initial_root_tests::ordinary::'
PARENTS = {
    'ordinary-a': PREFIX + 'ordinary_main_a_records_independent_outcome_and_retires_original_processes',
    'ordinary-post-a-adopt': PREFIX + 'post_a_process::ordinary_main_adopts_after_independent_b_and_executes_original_c',
    'ordinary-post-a-no-update': PREFIX + 'post_a_process::ordinary_main_retains_after_completed_independent_b_and_executes_original_c',
    'ordinary-whole-cold': PREFIX + 'cold_process::ordinary_main_cold_recovers_completed_c_after_actual_daemon_and_root_retirement',
}
MARKERS = {
    'ORDINARY_Q24_ACTUAL_A_EVIDENCE': 'a',
    'ORDINARY_Q24_ACTUAL_WHOLE_EVIDENCE': 'whole',
    'ORDINARY_Q24_COLD_PHASE_EVIDENCE': 'cold',
    'ORDINARY_Q24_WHOLE_COLD_RESULT': 'cold_result',
}


def require(value, message):
    if not value:
        raise RuntimeError(message)


def absolute(value):
    path = Path(value)
    require(path.is_absolute() and str(path) == value and '..' not in path.parts,
            'noncanonical original path: ' + repr(value))
    return path


def metadata(value):
    return dict(device=value.st_dev, inode=value.st_ino, uid=value.st_uid,
                gid=value.st_gid, mode=value.st_mode, nlink=value.st_nlink,
                size=value.st_size, mtime_ns=value.st_mtime_ns, ctime_ns=value.st_ctime_ns)


def open_directory(path):
    """Anchor every ancestor with openat; a replaced symlink cannot redirect IO."""
    absolute(str(path))
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        for part in path.parts[1:]:
            following = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                dir_fd=fd)
            os.close(fd)
            fd = following
        return fd
    except BaseException:
        os.close(fd)
        raise


def hash_fd(fd, bound):
    digest = hashlib.sha256()
    length = 0
    while True:
        block = os.read(fd, 1024 * 1024)
        if not block:
            break
        length += len(block)
        require(length <= bound, 'original regular file exceeds bound or changed length')
        digest.update(block)
    return length, digest.hexdigest()


def regular(parent, name, expected, archive=None, arcname=None):
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=parent)
    try:
        before = metadata(os.fstat(fd))
        require(before == expected and stat.S_ISREG(before['mode']), 'original regular inode changed')
        require((before['device'], before['inode']) not in NEVER_READ_IDS, 'excluded original inode')
        require(before['size'] <= MAX_FILE, 'original regular file exceeds explicit bound')
        first = hash_fd(fd, before['size'])
        require(first[0] == before['size'], 'original length differs')
        if archive is not None:
            os.lseek(fd, 0, os.SEEK_SET)
            info = tarfile.TarInfo(arcname)
            info.size, info.mode, info.uid, info.gid = before['size'], 0o600, before['uid'], before['gid']
            with os.fdopen(os.dup(fd), 'rb') as source:
                archive.addfile(info, source)
        os.lseek(fd, 0, os.SEEK_SET)
        second = hash_fd(fd, before['size'])
        require(first == second and metadata(os.fstat(fd)) == before
                and metadata(os.stat(name, dir_fd=parent, follow_symlinks=False)) == before,
                'original bytes or physical metadata changed during collection')
        return first[1]
    finally:
        os.close(fd)


def read_original(path, bound=16 * 1024 * 1024):
    require(path != BASE / 'env.json', 'secret environment content must never be read')
    parent = open_directory(path.parent)
    try:
        before = metadata(os.stat(path.name, dir_fd=parent, follow_symlinks=False))
        require(stat.S_ISREG(before['mode']) and before['size'] <= bound, 'bounded original data required')
        expected_hash = regular(parent, path.name, before)
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=parent)
        with os.fdopen(fd, 'rb') as source:
            require(metadata(os.fstat(source.fileno())) == before, 'original data replaced before decoding')
            data = source.read(bound + 1)
            require(metadata(os.fstat(source.fileno())) == before, 'original data changed while decoding')
        require(len(data) == before['size'] and hashlib.sha256(data).hexdigest() == expected_hash
                and metadata(os.stat(path.name, dir_fd=parent, follow_symlinks=False)) == before,
                'original decoded bytes differ')
        observation = dict(physical=before, sha256=expected_hash)
        require(path not in DECODED_ORIGINALS or DECODED_ORIGINALS[path] == observation,
                'original discovery data changed between reads')
        DECODED_ORIGINALS[path] = observation
        return data
    finally:
        os.close(parent)


def excluded(path, physical):
    name = path.name
    if (physical['device'], physical['inode']) in NEVER_READ_IDS:
        return 'secret environment inode or hard link: metadata only; no content read'
    if any(path.is_relative_to(directory) for directory in PIN_DIRECTORIES):
        return 'pinned executable directory: metadata only; no content read'
    if path in VERIFIED_PUBLIC_ENV:
        return None
    if name == 'env.json' or name.endswith('-env.json') or name == '.env' or name.startswith('.env.'):
        return 'environment file: metadata only; no content read'
    if stat.S_IMODE(physical['mode']) & 0o111 and path not in ORIGINAL_DRIVERS:
        return 'executable file: metadata only; no content read'
    return None


@dataclass(frozen=True)
class OriginalTree:
    label: str
    original: Path
    actual: Path
    only: tuple | None = None


def snapshot_tree(tree, archive, budget):
    rows = []

    def walk(fd, relative, names=None):
        before = metadata(os.fstat(fd))
        listing = sorted(os.listdir(fd)) if names is None else list(names)
        rows.append(dict(path=tree.label + '/' + relative.as_posix(), kind='directory',
                         original_path=str(tree.original / relative), actual_path=str(tree.actual / relative),
                         physical=before))
        for name in listing:
            require(name not in ('', '.', '..') and '/' not in name, 'invalid directory entry')
            physical = metadata(os.stat(name, dir_fd=fd, follow_symlinks=False))
            rel = relative / name
            row = dict(path=tree.label + '/' + rel.as_posix(), original_path=str(tree.original / rel),
                       actual_path=str(tree.actual / rel), physical=physical)
            mode = physical['mode']
            budget['entries'] += 1
            require(budget['entries'] <= MAX_ENTRIES and len(rel.parts) <= 32, 'evidence tree bound')
            if stat.S_ISDIR(mode):
                child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
                try:
                    require(metadata(os.fstat(child)) == physical, 'directory replaced during open')
                    walk(child, rel)
                finally:
                    os.close(child)
                continue
            if stat.S_ISREG(mode):
                row['kind'] = 'regular'
                actual_path = tree.actual / rel
                reason = excluded(actual_path, physical)
                if reason:
                    row['excluded'] = reason
                else:
                    budget['bytes'] += physical['size']
                    require(budget['bytes'] <= MAX_TOTAL, 'aggregate original evidence bound')
                    row['sha256'] = regular(fd, name, physical, archive, row['path'])
                    if actual_path in VERIFIED_PUBLIC_ENV:
                        require(row['sha256'] == VERIFIED_PUBLIC_ENV[actual_path]['sha256'],
                                'validated public pin environment changed')
                        row['public_pin_paths_only'] = True
            elif stat.S_ISLNK(mode):
                row.update(kind='symlink', target=os.readlink(name, dir_fd=fd), content_read=False)
            elif stat.S_ISSOCK(mode):
                row.update(kind='socket', content_read=False)
            elif stat.S_ISFIFO(mode):
                row.update(kind='fifo', content_read=False)
            else:
                row.update(kind='special', content_read=False)
            require(metadata(os.stat(name, dir_fd=fd, follow_symlinks=False)) == physical,
                    'original entry changed during observation')
            rows.append(row)
        require(metadata(os.fstat(fd)) == before, 'original directory metadata changed')
        if names is None:
            require(sorted(os.listdir(fd)) == listing, 'original directory membership changed')

    fd = open_directory(tree.actual)
    try:
        original_root = metadata(os.fstat(fd))
        walk(fd, Path('.'), tree.only)
        reopened = open_directory(tree.actual)
        try:
            require(metadata(os.fstat(reopened)) == original_root, 'original tree pathname replaced')
        finally:
            os.close(reopened)
    finally:
        os.close(fd)
    return rows


def setup_command(root, filesystem_root=None):
    # Exact v2 setup body: its successful original execution checks both inode
    # equalities before emitting the retained mountinfo. Do not execute it here.
    original = """import os,pathlib,subprocess,json
assert os.geteuid()==0
root=pathlib.Path(%r);root.mkdir(mode=0o700)
for name in ['source','bind','witness-source','witness-bind','checkpoints']:(root/name).mkdir(mode=0o700)
for source,target in [('source','bind'),('witness-source','witness-bind')]:
 subprocess.run(['mount','--bind',str(root/source),str(root/target)],check=True)
 assert (root/source).stat().st_dev==(root/target).stat().st_dev
 assert (root/source).stat().st_ino==(root/target).stat().st_ino
rows=[line for line in pathlib.Path('/proc/self/mountinfo').read_text().splitlines() if str(root) in line]
assert len(rows)==2
print(json.dumps({'uid':os.geteuid(),'root':str(root),'actual_mountinfo':rows}))
""" % str(root)
    if filesystem_root is not None:
        original = original.replace(
            "root=pathlib.Path(%r);root.mkdir(mode=0o700)\n" % str(root),
            "root=pathlib.Path(%r);root.mkdir(mode=0o700)\n" % str(root)
            + "filesystem=pathlib.Path(%r);filesystem.mkdir(mode=0o755);filesystem.chmod(0o755)\n" % str(filesystem_root)
            + "metadata=filesystem.stat()\n"
            + "assert metadata.st_uid==0 and metadata.st_gid==0 and metadata.st_mode & 0o7777==0o755\n")
        original = original.replace(
            "print(json.dumps({'uid':os.geteuid(),'root':str(root),'actual_mountinfo':rows}))",
            "print(json.dumps({'uid':os.geteuid(),'root':str(root),'actual_mountinfo':rows,\n"
            + "                  'filesystem_root':str(filesystem),'filesystem_custody':{'uid':metadata.st_uid,'gid':metadata.st_gid,'mode':metadata.st_mode & 0o7777,'device':metadata.st_dev,'inode':metadata.st_ino}}))")
    return original


def original_mapping(run, root, result, filesystem_root=None):
    stages = [row for row in result['stages'] if row['name'] == 'root-mount-setup']
    require(len(stages) == 1, 'one actual mount setup record required')
    stage = stages[0]
    require(stage['status'] == 'completed' and stage['exit_code'] == 0
            and stage['command'] == ['sudo', '-n', 'python3', '-c', setup_command(root, filesystem_root)],
            'actual original mount equality proof differs')
    observed = json.loads(read_original(run / 'root-mount-setup.stdout.log'))
    require(observed['uid'] == 0 and observed['root'] == str(root), 'original Root mount output differs')
    rows = observed['actual_mountinfo']
    require(len(rows) == 2 and {row.split()[4] for row in rows}
            == {str(root / 'bind'), str(root / 'witness-bind')}, 'actual mountinfo targets differ')
    cleanup = json.loads(read_original(run / 'mount-cleanup.json'))
    require(len(cleanup) == 2 and {row['path'] for row in cleanup}
            == {str(root / 'bind'), str(root / 'witness-bind')}
            and all(row['code'] == 0 for row in cleanup), 'original successful unmount records required')
    # These are kernel mount descriptions only, never an environment read.
    with open('/proc/self/mountinfo', encoding='utf-8') as source:
        current_mounts = source.read(4 * 1024 * 1024 + 1)
    require(len(current_mounts) <= 4 * 1024 * 1024, 'mount description bound')
    active = {row.split()[4] for row in current_mounts.splitlines()}
    require(str(root / 'bind') not in active and str(root / 'witness-bind') not in active,
            'original bind mount is still active; collector does not unmount')
    check_directory(root, 0, 0o700)
    if filesystem_root is not None:
        custody = observed['filesystem_custody']
        require(observed['filesystem_root'] == str(filesystem_root)
                and (custody['uid'], custody['gid'], custody['mode']) == (0, 0, 0o755),
                'original filesystem test parent custody differs')
        descriptor = open_directory(filesystem_root)
        try:
            actual = os.fstat(descriptor)
            require((actual.st_dev, actual.st_ino, actual.st_uid, actual.st_gid, stat.S_IMODE(actual.st_mode))
                    == (custody['device'], custody['inode'], 0, 0, 0o755), 'filesystem parent replaced')
        finally:
            os.close(descriptor)
    return dict(setup=stage, output=observed, cleanup=cleanup,
                current_bind_mounts_absent=True,
                aliases={str(root / 'bind'): str(root / 'source'),
                         str(root / 'witness-bind'): str(root / 'witness-source')})


def map_original(path, mapping):
    for original, actual in mapping['aliases'].items():
        if path.is_relative_to(original):
            return Path(actual) / path.relative_to(original)
    return path


def check_directory(path, uid, mode):
    fd = open_directory(path)
    try:
        actual = os.fstat(fd)
        require(actual.st_uid == uid and stat.S_IMODE(actual.st_mode) == mode,
                'original evidence directory owner/mode differs: ' + str(path))
    finally:
        os.close(fd)


def case_evidence(stage, report, root, mapping, window):
    document = ET.fromstring(read_original(report))
    cases = list(document.iter('testcase'))
    require(len(cases) == 1 and cases[0].get('name') == PARENTS[stage], 'wrong original ordinary parent')
    case = cases[0]
    passed = not any(case.find(tag) is not None for tag in ('failure', 'error', 'skipped'))
    texts = '\n'.join(node.text or '' for tag in ('system-out', 'system-err') for node in case.iter(tag))
    retained, children, markers = {}, set(), []
    for line in texts.splitlines():
        match = re.fullmatch(r'\s*ORDINARY_Q24_RETAINED_DIRECTORY role=([a-z_]+) reason=(explicit_keep|scope_exit) path=(/[^\r\n]+)', line)
        if match:
            role, reason, raw = match.groups()
            path = absolute(raw)
            allowed = {
                'a_protected': (root / 'bind', r'ordinary-q24-[A-Za-z0-9]+', 0, 0o700),
                'a_runtime': (RUN_PARENT, r'oq-[A-Za-z0-9]+', 0, 0o2710),
                'post_a_model_witness': (root / 'witness-bind', r'ordinary-post-a-model-[A-Za-z0-9]+', 0, 0o700),
                'independent_b_business': (TEMP_PARENT, r'ordinary-original-independent-b-[A-Za-z0-9]+', 60002, 0o700),
            }
            require(role in allowed and role not in retained, 'unknown or duplicate retained directory role')
            parent, pattern, uid, mode = allowed[role]
            require(path.parent == parent and re.fullmatch(pattern, path.name), 'out-of-scope retained marker')
            actual = map_original(path, mapping)
            require_directory_window(actual, window)
            # Failed setup can stop before the original chmod/chown. Keep its
            # actual metadata too; never claim that it reached the normal mode.
            if passed:
                check_directory(actual, uid, mode)
            retained[role] = OriginalTree('cases/' + stage + '/retained/' + role, path, actual)
            markers.append(dict(marker='retained', role=role, reason=reason, original_path=raw, actual_path=str(actual)))
            continue
        match = re.fullmatch(r'\s*ORDINARY_Q24_ORIGINAL_CHILD_LOGS=(' + re.escape(str(TEMP_PARENT))
                             + r'/ordinary-q24-original-process-[A-Za-z0-9]+)', line)
        if match:
            children.add(absolute(match[1]))
            continue
        match = re.fullmatch(r'\s*(ORDINARY_Q24_[A-Z_]+)=(/[^\r\n]+)', line)
        if match and match[1] in MARKERS:
            markers.append(dict(marker=MARKERS[match[1]], original_path=str(absolute(match[2]))))
    protected = retained.get('a_protected')
    suffixes = {'a': '', 'whole': 'ordinary-whole-phase', 'cold': 'ordinary-cold-phase',
                'cold_result': 'ordinary-whole-cold-result.json'}
    for marker in markers:
        if marker['marker'] in suffixes:
            require(protected is not None and Path(marker['original_path'])
                    == protected.original / suffixes[marker['marker']], 'archive marker escaped its original protected directory')
            marker['actual_path'] = str(map_original(Path(marker['original_path']), mapping))
    trees = list(retained.values())
    for child in sorted(children):
        require_directory_window(child, window)
        check_directory(child, 0, 0o700)
        trees.append(OriginalTree('cases/' + stage + '/child-logs/' + child.name, child, child))
    if passed:
        roles = {'a_protected', 'a_runtime'}
        required = {'a'}
        if stage != 'ordinary-a':
            roles.update(('post_a_model_witness', 'independent_b_business'))
            required = {'whole'}
        if stage == 'ordinary-whole-cold':
            required.update(('cold', 'cold_result'))
        require(set(retained) == roles and required.issubset({m['marker'] for m in markers}),
                'successful ordinary parent lacks required original evidence markers')
        require(len(children) >= (3 if stage == 'ordinary-a' else 8 if stage == 'ordinary-whole-cold' else 6),
                'successful parent lacks original child output files')
    return trees, dict(stage=stage, report=str(report), native_parent_reported_pass=passed,
                       original_execution_window_ns=window,
                       markers=markers, original_child_log_directories=[str(p) for p in sorted(children)])


def require_directory_window(path, window):
    fd = open_directory(path)
    try:
        observed = os.fstat(fd)
        require(window[0] <= observed.st_ctime_ns <= window[1],
                'retained directory metadata falls outside its original execution window')
    finally:
        os.close(fd)


def execution_window(result, stage):
    rows = [row for row in result['stages'] if row['name'] == stage + '-execution']
    require(len(rows) == 1 and rows[0]['status'] == 'completed', 'actual ordinary execution is not closed')
    def nanos(value):
        parsed = datetime.datetime.fromisoformat(value)
        require(parsed.tzinfo is not None, 'original execution timestamp has no timezone')
        epoch = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc)
        elapsed = parsed - epoch
        return ((elapsed.days * 86400 + elapsed.seconds) * 1_000_000 + elapsed.microseconds) * 1000
    window = (nanos(rows[0]['started']), nanos(rows[0]['finished']))
    require(window[0] <= window[1], 'original execution clock regressed')
    return window


def require_business_references(cases, trees, mapping):
    for case in cases:
        for marker in case['markers']:
            if marker['marker'] not in ('a', 'whole', 'cold'):
                continue
            filename = {'a': 'actual-a-phase.json', 'whole': 'actual-case.json',
                        'cold': 'original-completed-phase.json'}[marker['marker']]
            path = Path(marker['actual_path']) / filename
            data = json.loads(read_original(path))
            for raw in data['business_files']:
                reference = absolute(raw)
                candidates = [tree for tree in trees if tree.label.startswith('cases/' + case['stage'] + '/retained/')
                              and reference.is_relative_to(tree.original)]
                require(len(candidates) == 1, 'business reference outside this original case custody: ' + raw)
                actual = map_original(reference, mapping)
                parent = open_directory(actual.parent)
                try:
                    require(stat.S_ISREG(os.stat(actual.name, dir_fd=parent, follow_symlinks=False).st_mode),
                            'original declared business file missing or not regular')
                finally:
                    os.close(parent)


def driver_bindings(raw, args, run):
    """Decode only simple path/string constants; never import or execute a driver."""
    selected = {'BASE', 'HEAD', 'TREE', 'OUT', 'ROOT', 'PUBLIC', 'RUN_ID', 'FILESYSTEM_ROOT'}
    values = {}

    def value(node):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        if isinstance(node, ast.Name) and node.id in values:
            return values[node.id]
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Path':
            require(len(node.args) == 1 and not node.keywords, 'unsupported original path constant')
            return Path(value(node.args[0]))
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            left, right = value(node.left), value(node.right)
            require(isinstance(left, str) and isinstance(right, str), 'unsupported string constant')
            return left + right
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
            left, right = value(node.left), value(node.right)
            require(isinstance(left, Path) and isinstance(right, str), 'unsupported path constant')
            return left / right
        raise RuntimeError('unsupported original driver constant')

    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name in selected:
                require(name not in values, 'duplicate original driver binding')
                values[name] = value(node.value)
    require({name: values.get(name) for name in ('BASE', 'HEAD', 'TREE', 'OUT', 'ROOT', 'PUBLIC')}
            == dict(BASE=BASE, HEAD=args.head, TREE=args.tree, OUT=run, ROOT=args.root, PUBLIC=args.public),
            'explicit source/run/directory arguments differ from original driver constants')
    require(values.get('FILESYSTEM_ROOT') == args.filesystem_root, 'original filesystem parent differs')
    return {name: str(observed) for name, observed in values.items()}


def prepare_exclusions(public):
    global PIN_DIRECTORIES
    NEVER_READ_IDS.clear()
    VERIFIED_PUBLIC_ENV.clear()
    ORIGINAL_DRIVERS.clear()
    DECODED_ORIGINALS.clear()
    PIN_DIRECTORIES = (public / 'bin', public / 'helpers/bin')
    descriptor = open_directory(BASE)
    try:
        # Metadata only, including the identity used to refuse hard-link aliases.
        try:
            observed = os.stat('env.json', dir_fd=descriptor, follow_symlinks=False)
        except FileNotFoundError:
            return
        if stat.S_ISREG(observed.st_mode):
            NEVER_READ_IDS.add((observed.st_dev, observed.st_ino))
    finally:
        os.close(descriptor)


def validate_public_env(public):
    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, 'duplicate public environment key; contents not archived')
            result[key] = value
        return result

    records = []
    for path in (public / 'product-env.json', public / 'helpers/env.json'):
        raw = read_original(path, 1024 * 1024)
        try:
            value = json.loads(raw, object_pairs_hook=unique_object)
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise RuntimeError('public pin environment is not strict JSON; contents not archived') from None
        require(isinstance(value, dict) and 0 < len(value) <= 128, 'bounded public pin dictionary required')
        for key, entry in value.items():
            require(isinstance(key, str) and re.fullmatch(r'CARGO_BIN_EXE_[A-Za-z0-9_-]+', key),
                    'public environment contains a non-pin key; contents not archived')
            require(isinstance(entry, str) and '\x00' not in entry and '\n' not in entry,
                    'public pin is not a pathname')
            pin = Path(entry)
            require(pin.is_absolute() and str(pin) == entry and '..' not in pin.parts,
                    'public pin is not a canonical absolute path; contents not archived')
            require(any(pin.is_relative_to(directory) and pin != directory for directory in PIN_DIRECTORIES),
                    'public pin escaped this original attempt')
        observation = dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), pin_paths=value)
        VERIFIED_PUBLIC_ENV[path] = observation
        records.append(observation)
    return records


def native_report_inventory(run, result):
    reports = []
    seen = set()
    for item in result['stages']:
        if not item['name'].endswith('-execution'):
            continue
        name = item['name'][:-len('-execution')]
        require(re.fullmatch(r'[a-z][a-z0-9-]{1,80}', name) and name not in seen, 'ambiguous native stage')
        seen.add(name)
        report = run / (name + '.xml')
        record = dict(stage=name, report=str(report), execution=item)
        if not report.exists():
            record.update(present=False, qualification_inferred=False)
            reports.append(record)
            continue
        cases = list(ET.fromstring(read_original(report, 64 * 1024 * 1024)).iter('testcase'))
        require(len(cases) <= 50_000, 'JUnit testcase bound')
        names = [case.get('name') for case in cases]
        require(all(isinstance(name, str) and 0 < len(name) <= 1024 for name in names), 'invalid JUnit names')
        active = [case.get('name') for case in cases if case.find('skipped') is None]
        record.update(present=True, observed=names, executed=active,
                      failures=sum(case.find('failure') is not None for case in cases),
                      errors=sum(case.find('error') is not None for case in cases),
                      skipped=len(names) - len(active), qualification_inferred=False)
        coverage = run / (name + '-parent-coverage.json')
        if coverage.exists():
            declared = json.loads(read_original(coverage))
            expected = declared['expected']
            require(isinstance(expected, list) and all(isinstance(name, str) for name in expected)
                    and len(expected) == len(set(expected)) <= 10_000, 'invalid original exact roster')
            exact = len(cases) == len(expected) and sorted(active) == sorted(expected)
            record.update(original_parent_coverage=declared, calculated_exact_roster=exact,
                          coverage_report_consistent=(declared['observed'] == active
                              and declared['skipped'] == len(names) - len(active) and declared['exact'] == exact))
        reports.append(record)
    return reports


def collect(args):
    run = BASE / 'validation' / args.run_id
    root = args.root
    prepare_exclusions(args.public)
    result = json.loads(read_original(run / 'result.json'))
    require(result['head'] == args.head and result['tree'] == args.tree
            and result['before']['head'] == args.head and result['before']['tree'] == args.tree,
            'frozen original source differs')
    require(result['status'] in ('completed', 'driver_failed') and result['finished']
            and all(stage['status'] != 'running' for stage in result['stages']), 'original driver is not closed')
    driver_bytes = read_original(args.driver)
    require(hashlib.sha256(driver_bytes).hexdigest() == result['driver_sha256'], 'actual driver hash differs')
    constants = driver_bindings(driver_bytes, args, run)
    ORIGINAL_DRIVERS.add(args.driver)
    fix_records = []
    for path in args.fix_record:
        raw = read_original(path)
        original = json.loads(raw)
        require(original['status'] == 'completed' and original['exit_code'] == 0
                and original['source_unchanged'] is True and original['before'] == result['before'],
                'scoped fix is not an unchanged successful check of this exact source')
        fix_records.append(dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest()))
    if 'prior_fix_record' in result:
        require(result['prior_fix_record'] in fix_records, 'driver-bound scoped fix record must be explicitly included')
    mapping = original_mapping(run, root, result, args.filesystem_root)
    public_env = validate_public_env(args.public)
    product_manifest = json.loads(read_original(args.public / 'product-manifest.json'))
    require(product_manifest['head'] == args.head and product_manifest['tree'] == args.tree,
            'public product manifest belongs to another source')
    trees = [OriginalTree('validation/run', run, run),
             OriginalTree('drivers', args.driver.parent, args.driver.parent, (args.driver.name,)),
             OriginalTree('public', args.public, args.public),
             OriginalTree('root-original/source', root / 'bind', root / 'source'),
             OriginalTree('root-original/witness', root / 'witness-bind', root / 'witness-source'),
             OriginalTree('root-original/checkpoints', root / 'checkpoints', root / 'checkpoints')]
    trees.extend(OriginalTree('validation/fix-' + str(index), path.parent, path.parent)
                 for index, path in enumerate(args.fix_record))
    if args.filesystem_root is not None:
        trees.append(OriginalTree('root-original/filesystem-tests', args.filesystem_root, args.filesystem_root))
    reports = native_report_inventory(run, result)
    cases, case_trees = [], []
    for report in reports:
        stage = report['stage']
        if stage not in PARENTS or not report['present']:
            continue
        discovered, case = case_evidence(stage, run / (stage + '.xml'), root, mapping,
                                         execution_window(result, stage))
        case_trees.extend(discovered)
        cases.append(case)
    require(len({tree.actual for tree in case_trees}) == len(case_trees), 'original cases reused an evidence directory')
    require_business_references(cases, case_trees, mapping)
    # Original protected/model directories are already in the fixed Root trees.
    # Record their per-case provenance above without copying their bytes twice.
    for tree in case_trees:
        if not any(tree.actual.is_relative_to(existing.actual) for existing in trees if existing.only is None):
            trees.append(tree)
    require(len({tree.actual for tree in trees}) == len(trees), 'overlapping original evidence selections')
    before, budget = [], dict(entries=0, bytes=0)
    archive_path = args.output / 'originals.tar.xz'
    with tarfile.open(archive_path, 'x:xz', preset=3) as archive:
        for tree in trees:
            before.extend(snapshot_tree(tree, archive, budget))
        after, after_budget = [], dict(entries=0, bytes=0)
        for tree in trees:
            after.extend(snapshot_tree(tree, None, after_budget))
        require(before == after and budget == after_budget, 'original evidence changed after copying')
        for path, decoded in DECODED_ORIGINALS.items():
            matches = [row for row in before if row['actual_path'] == str(path) and row['kind'] == 'regular']
            require(len(matches) == 1 and matches[0].get('sha256') == decoded['sha256']
                    and matches[0]['physical'] == decoded['physical'], 'discovery input differs from archived original')
        manifest = dict(schema=1, source_head=args.head, source_tree=args.tree, original_run=args.run_id,
                        collector_uid=os.geteuid(), source_unchanged=result.get('source_unchanged'),
                        original_driver_status=result['status'], original_driver_bindings=constants,
                        original_all_stages_passed=result.get('all_stages_passed'),
                        native_tests_run=False, qualification_inferred=False,
                        mapping_proof=mapping, scoped_fix_records=fix_records, public_pin_environments=public_env,
                        native_reports=reports, cases=cases, records=before, totals=budget,
                        missing_fresh_reports=[report['stage'] for report in reports if not report['present']],
                        scope='Closed original fixture and driver records only. Collection is not a native test result. Excluded files and nonregular entries have no content claim.')
        encoded = (json.dumps(manifest, indent=2) + '\n').encode()
        info = tarfile.TarInfo('manifest.json')
        info.size, info.mode = len(encoded), 0o600
        archive.addfile(info, io.BytesIO(encoded))
    (args.output / 'manifest.json').write_bytes(encoded)
    with archive_path.open('rb') as stream:
        archive_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(status='completed', input_bytes=budget['bytes'], entry_count=len(before),
                archive=str(archive_path), bytes=archive_path.stat().st_size, sha256=archive_hash,
                manifest_sha256=hashlib.sha256(encoded).hexdigest(), original_bytes_unchanged=True,
                native_tests_run=False, qualification_inferred=False,
                original_driver_status=result['status'], original_all_stages_passed=result.get('all_stages_passed'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('run-id', 'head', 'tree', 'driver', 'root', 'public', 'output'):
        parser.add_argument('--' + key, required=True)
    parser.add_argument('--fix-record', action='append', default=[])
    parser.add_argument('--filesystem-root')
    args = parser.parse_args()
    require(re.fullmatch(r'root-[a-z0-9-]{4,70}', args.run_id), 'explicit unique original run ID required')
    require(all(re.fullmatch(r'[0-9a-f]{40}', value) for value in (args.head, args.tree)), 'exact source IDs required')
    args.driver, args.root, args.public, args.output = map(absolute, (args.driver, args.root, args.public, args.output))
    args.fix_record = [absolute(path) for path in args.fix_record]
    args.filesystem_root = absolute(args.filesystem_root) if args.filesystem_root else None
    require(args.driver.parent == BASE and args.driver.suffix == '.py', 'explicit original driver path required')
    require(all(path.parent.parent == BASE / 'validation' and path.name == 'result.json'
                and path.parent != BASE / 'validation' / args.run_id for path in args.fix_record)
            and len(args.fix_record) == len(set(args.fix_record)), 'explicit distinct task scoped-fix records required')
    require(args.root.parent == RUN_PARENT and re.fullmatch(r'hepta-daemon-learning-[a-z0-9-]{4,80}', args.root.name),
            'explicit original Root fixture directory required')
    require(args.public.parent == TEMP_PARENT and re.fullmatch(r'hepta-native-[a-z0-9-]{4,80}', args.public.name),
            'explicit original public pin directory required')
    require(args.filesystem_root is None or (args.filesystem_root.parent == RUN_PARENT
            and re.fullmatch(r'hepta-filesystem-[a-z0-9-]{4,80}', args.filesystem_root.name)),
            'explicit separate filesystem test parent required')
    require(args.output.parent == BASE / 'validation' and args.output.name.startswith('root-originals-')
            and args.output != BASE / 'validation' / args.run_id
            and all(args.output != path.parent for path in args.fix_record),
            'separate new task output directory required')
    require(os.getuid() == os.geteuid() == 0, 'collector requires actual UID0; it changes no input permissions')
    args.output.mkdir(mode=0o700, exist_ok=False)
    try:
        result = collect(args)
        code = 0
    except BaseException as error:
        result = dict(status='failed', error=repr(error), native_tests_run=False,
                      qualification_inferred=False, original_bytes_unchanged=None)
        (args.output / 'collector-error.log').write_text(traceback.format_exc())
        partial = args.output / 'originals.tar.xz'
        if partial.exists():
            with partial.open('rb') as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            result['incomplete_archive'] = dict(path=str(partial), bytes=partial.stat().st_size, sha256=digest,
                                                validated=False)
        code = 1
    (args.output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    for path in args.output.iterdir():
        os.chmod(path, 0o600)
        with path.open('rb') as stream:
            os.fsync(stream.fileno())
        os.chown(path, 1000, 1000)
    os.chown(args.output, 1000, 1000)
    descriptor = open_directory(args.output)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    print(json.dumps(result), flush=True)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
