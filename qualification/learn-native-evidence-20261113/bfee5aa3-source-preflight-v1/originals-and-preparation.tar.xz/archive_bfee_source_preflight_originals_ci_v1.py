#!/usr/bin/env python3
"""Freeze already-read source-preflight evidence; never execute H or Rust."""
from pathlib import Path
import hashlib
import io
import json
import os
import stat
import tarfile

BASE = Path('/workspace/scratch/ff41dfc0f7bf/tooling')
OUT = BASE / 'publication/evidence-bfee5aa3-source-preflight-20261113-v1'
HEAD = 'bfee5aa363cb63897c28c8f74fd6b167de5e859b'
TREE = 'd24d13a0d716036319a6b814dd89b8e913689b00'
CUT = 'dfed7872d8cb0158e556de66d1499fbc10d03bad19c6038874eaefe0d2ffd847'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def stamp(value):
    return {key: getattr(value, key) for key in (
        'st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink',
        'st_size', 'st_mtime_ns', 'st_ctime_ns')}

def original(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode), str(path)
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        opened = os.fstat(stream.fileno())
        data = stream.read()
        after_fd = os.fstat(stream.fileno())
    after = path.lstat()
    assert stamp(before) == stamp(opened) == stamp(after_fd) == stamp(after)
    assert len(data) == before.st_size
    return data, stamp(before)

def write_new(path, data):
    if path.exists():
        assert path.read_bytes() == data, 'Refuse a different prior postimage'
        return
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())

def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    paths = []
    directories = [
        'validation/root-bfee5aa3-source-preflight-originals-ci-v1',
        'validation/ordinary-bfee5aa3-hydration-v2-review',
        'validation/sticky-bfee-driver-readonly-review-v1',
        'validation/ordinary-bfee5aa3-budget-driver-review-v1',
        'validation/completed-chain-collector-bfee5aa3-v2-prepared',
    ]
    for relative in directories:
        directory = BASE / relative
        assert directory.is_dir(), relative
        paths.extend(path for path in directory.rglob('*') if path.is_file())
    parent_inputs = BASE / 'validation/root-bfee5aa3-native-inputs-v1'
    for name in [
        'assemble-launch.py', 'compile-result-preflight-failed.original.json',
        'manifest.json', 'root-bfee5aa3-source.bundle',
        'scoped-fix-failure-logs.mcp.json', 'scoped-fix-launch-intent.json',
        'scoped-fix-launch.mcp.json', 'scoped-fix-read-1.mcp.json',
        'scoped-fix-v2-launch-intent.json', 'scoped-fix-v2-launch.mcp.json',
        'scoped-fix-v2-pty-read-1.mcp.json', 'scoped-fix-v2-read-1.mcp.json',
        'scoped-fix-v2-upload.mcp.json', 'source-hydration-expected.json',
        'source-observer-launch-intent.json', 'source-observer-launch.mcp.json',
        'source-observer-observation.derived.json',
        'source-observer-output-original.jsonl', 'source-observer-read-1.mcp.json',
        'transfer-parts-1.py', 'upload-1.mcp.json', 'upload-2.mcp.json',
    ]:
        paths.append(parent_inputs / name)
    paths.extend(BASE / relative for relative in [
        'validation/root-bfee5aa3-observed-progress-v2/compile-result-final.original.json',
        'root_bfee5aa3_scoped_fix_v1.py', 'root_bfee5aa3_scoped_fix_v2.py',
        'observe_bfee5aa3_source_preflight_v1.py',
        'archive_bfee_source_preflight_originals_ci_v1.py',
    ])
    saved = {}
    for path in sorted(set(paths)):
        data, metadata = original(path)
        name = str(path.relative_to(BASE))
        saved[name] = (data, metadata)

    hbase = 'validation/root-bfee5aa3-source-preflight-originals-ci-v1/h-files/validation/'
    first = json.loads(saved[hbase + 'root-bfee5aa3-scoped-fix-v1/result.json'][0])
    hydration_data = saved[hbase + 'root-bfee5aa3-scoped-fix-v2/source-hydration.json'][0]
    hydration = json.loads(hydration_data)
    observed = json.loads(saved[hbase + 'root-bfee5aa3-source-preflight-observation-v1/result.json'][0])
    fixed_data = saved['validation/root-bfee5aa3-observed-progress-v2/compile-result-final.original.json'][0]
    fixed = json.loads(fixed_data)
    assert first['status'] == 'preflight_failed'
    assert digest(hydration_data) == 'ebc7c55b3ab2043183c00cad97528008ede0d45c6aba67c2c9973b3126525335'
    assert digest(fixed_data) == 'a778a419714d86407d766a799636687fc017073e2b6194e72f0d0093f5ba679d'
    assert hydration['status'] == 'completed'
    assert len(hydration['created']) == len(hydration['inputs']) == len(hydration['initial_missing']) == 9
    assert {item['path'] for item in hydration['created']} == set(hydration['initial_missing'])
    for created, source in zip(hydration['created'], hydration['inputs'], strict=True):
        expected = source['expected']
        assert created['path'] == expected['path']
        assert created['status'] == 'restored_and_fsynced'
        assert created['actual_sha256'] == created['expected_sha256'] == expected['sha256']
        assert created['expected_bytes'] == created['after']['st_size'] == expected['bytes']
        assert created['opened']['st_size'] == 0
        assert created['original_blob'] == expected['blob']
        assert source['index_flag'] == 'S' and source['parent_and_new_head_blob_equal']
    for key in ['all_nine_prechecked', 'archive_unchanged', 'index_entries_unchanged',
                'index_flags_unchanged', 'local_git_config_unchanged', 'prior_v1_evidence_unchanged']:
        assert hydration[key] is True
    candidate = hydration['candidate_after_hydration']
    assert candidate['head'] == HEAD and candidate['tree'] == TREE and candidate['status'] == ''
    assert candidate['tracked_files'] == 15497
    assert hydration['virtual_candidate_sha256'] == candidate['tracked_sha256'] == CUT
    assert fixed['status'] == 'completed' and fixed['exit_code'] == 0 and fixed['source_unchanged'] is True
    assert fixed['before'] == fixed['after'] == candidate
    assert fixed['driver_sha256'] == digest(saved['root_bfee5aa3_scoped_fix_v2.py'][0])
    for name in ['result.json', 'driver-error.log', 'source-import.log', 'bundle-verify-import.log']:
        assert saved[hbase + 'root-bfee5aa3-scoped-fix-v1/' + name][0] == saved[
            hbase + 'root-bfee5aa3-source-preflight-observation-v1/original-' + name][0]
    failure = json.loads(saved['validation/root-bfee5aa3-native-inputs-v1/scoped-fix-failure-logs.mcp.json'][0])
    assert failure['isError'] is True and 'MCP request timed out' in failure['content'][0]['text']

    archive_path = OUT / 'originals-and-preparation.tar.xz'
    assert not archive_path.exists(), 'Archive already exists: reconcile, do not replay'
    with tarfile.open(archive_path, 'x:xz', preset=6) as archive:
        for name, (data, metadata) in saved.items():
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = stat.S_IMODE(metadata['st_mode'])
            entry.mtime = metadata['st_mtime_ns'] / 1_000_000_000
            archive.addfile(entry, io.BytesIO(data))
    with tarfile.open(archive_path, 'r:xz') as archive:
        entries = archive.getmembers()
        assert len(entries) == len(saved) and {entry.name for entry in entries} == set(saved)
        for entry in entries:
            assert entry.isfile() and archive.extractfile(entry).read() == saved[entry.name][0]
    for name, (data, metadata) in saved.items():
        current, current_metadata = original(BASE / name)
        assert current == data and current_metadata == metadata
    archive_data, _ = original(archive_path)
    manifest = {
        'schema': 1, 'scope': 'Source-preflight failure, read-only observer, exact original-byte hydration, compile-only successor, and not-launched collector preparation.',
        'head': HEAD, 'tree': TREE, 'archive': archive_path.name,
        'archive_bytes': len(archive_data), 'archive_sha256': digest(archive_data),
        'member_count': len(saved), 'input_bytes': sum(len(value[0]) for value in saved.values()),
        'members': [{'path': name, 'bytes': len(data), 'sha256': digest(data), 'source_stat': metadata}
                    for name, (data, metadata) in saved.items()],
        'all_member_bytes_verified': True, 'all_originals_rechecked_unchanged': True,
        'large_existing_git_archives_included': False,
    }
    write_new(OUT / 'manifest.json', json_bytes(manifest))
    verification = {
        'schema': 1, 'source_head': HEAD, 'source_tree': TREE,
        'v1': {'status': first['status'], 'rust_started': False, 'test_execution_count': 0,
               'original_result_sha256': digest(saved[hbase + 'root-bfee5aa3-scoped-fix-v1/result.json'][0]),
               'original_mcp_read_timeout_preserved': True},
        'observer': {'status': observed.get('status'), 'original_copies_exact': True,
                     'result_sha256': digest(saved[hbase + 'root-bfee5aa3-source-preflight-observation-v1/result.json'][0])},
        'hydration': {'created_files': 9, 'all_original_git_blobs_match': True,
                      'index_flags_and_local_config_unchanged': True, 'prior_evidence_unchanged': True,
                      'tracked_files': 15497, 'virtual_and_actual_sha256': CUT,
                      'sha256': digest(hydration_data)},
        'compile_v2': {'status': fixed['status'], 'exit_code': fixed['exit_code'],
                       'started': fixed['started'], 'compile_started': fixed['compile_started'],
                       'finished': fixed['finished'], 'elapsed': fixed['elapsed'],
                       'source_unchanged': fixed['source_unchanged'], 'result_sha256': digest(fixed_data),
                       'scope': fixed['scope'], 'tests_executed': 0},
        'collector': {'status': 'prepared_not_uploaded_or_launched',
                      'prepared_spec': 'validation/completed-chain-collector-bfee5aa3-v2-prepared/prepared-bfee5aa3-v2.json'},
        'business_recovery_claimed': False, 'whole_chain_pass_claimed': False,
    }
    write_new(OUT / 'verification.json', json_bytes(verification))
    readme = '''# Bfee source preflight and hydration originals

This appendix preserves separate observations for exact source bfee5aa363cb63897c28c8f74fd6b167de5e859b / tree d24d13a0d716036319a6b814dd89b8e913689b00.

* The first scoped-fix attempt failed during its source snapshot, before Rust or tests. Its original result, FileNotFoundError traceback, import/bundle logs, and the separately failed MCP log-read request remain unchanged.
* The read-only source observer found nine absent tracked archive files marked skip-worktree in the reused candidate. The prior fbf source retained the original files. The original observer and all four copied v1 files are preserved byte-for-byte.
* The successor created only those nine missing files from their existing, matching Git blobs. The receipt records the opened empty inode, exact bytes/hash, fsync, unchanged index/flags/config, unchanged earlier evidence, and equal virtual/actual 15,497-file source hash. This is source hydration; it does not establish business recovery. The approximately 21 MB of already tracked archive bytes are not duplicated here.
* The subsequent seven-package `just fix --locked --offline` finished exit 0 in 114.677388904 seconds with identical complete before/after snapshots. It compiled tests but executed none. The preserved result states that scope explicitly.
* The future A-v2 collection command and frozen collector/driver were parsed and checked locally. This appendix does not claim that the collector was uploaded or launched, or that A-v2 tests completed.

The source snapshot failure and successful successor are distinct attempts. Source hydration is not unchanged source relative to the failed v1 materialization. There is no native-test or whole-chain pass in this appendix. The older evidence branch history remains intact.

`manifest.json` identifies every original member and its complete SHA-256. Every tar member was read back and compared with the original bytes, and source files were then rechecked without modification. `verification.json` records the narrow cross-checks.
'''
    write_new(OUT / 'README.md', readme.encode())
    print(json.dumps({key: manifest[key] for key in ['archive', 'archive_bytes', 'archive_sha256', 'member_count', 'input_bytes']}))
    print(json.dumps({'output': str(OUT), 'verification_sha256': digest((OUT / 'verification.json').read_bytes())}))

if __name__ == '__main__':
    main()
