import os,json,hashlib,pathlib,subprocess,datetime
manifest={'head': 'bfee5aa363cb63897c28c8f74fd6b167de5e859b', 'tree': 'd24d13a0d716036319a6b814dd89b8e913689b00', 'prior_native_head': 'fbf2cc0a3eaf4ca1e720300c306ff6ad38517449', 'bundle_base': 'fbf2cc0a3eaf4ca1e720300c306ff6ad38517449', 'scope': 'actual seven-package compile probe only; no tests launched', 'files': [{'local': '/workspace/scratch/ff41dfc0f7bf/tooling/validation/root-bfee5aa3-native-inputs-v1/root-bfee5aa3-source.bundle', 'remote': '/home/qq/hepta-learn-ff41-tools/root-bfee5aa3-source.bundle', 'bytes': 3348, 'sha256': 'df4c76b4b462936fe791619d983b7535e2595d60e4a3b22f2e92c737aea978ba', 'parts': ['/home/qq/hepta-learn-ff41-tools/root-bfee5aa3-source.bundle.part-0']}, {'local': '/workspace/scratch/ff41dfc0f7bf/tooling/root_bfee5aa3_scoped_fix_v1.py', 'remote': '/home/qq/hepta-learn-ff41-tools/root_bfee5aa3_scoped_fix_v1.py', 'bytes': 9111, 'sha256': '1ef836ff1c12f5f2b074853713bcea4d9437227be673f4b1a9eae3718d572f45', 'parts': ['/home/qq/hepta-learn-ff41-tools/root_bfee5aa3_scoped_fix_v1.py.part-0']}], 'transfer_programs': [{'path': '/workspace/scratch/ff41dfc0f7bf/tooling/validation/root-bfee5aa3-native-inputs-v1/transfer-parts-1.py', 'bytes': 17635, 'sha256': '7956a3952a4790cd471f86348cd4abc249346190b79319d92f775521bf63dfbc'}]}
observed=[]
for item in manifest['files']:
 p=pathlib.Path(item['remote']);b=b''.join(pathlib.Path(part).read_bytes() for part in item['parts'])
 assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
 if p.exists():assert p.read_bytes()==b
 else:
  tmp=p.with_name(p.name+'.assemble-'+str(os.getpid()))
  with tmp.open('xb') as output:output.write(b);output.flush();os.fsync(output.fileno())
  tmp.chmod(0o600)
  try:os.link(tmp,p)
  finally:tmp.unlink()
 assert p.read_bytes()==b
 observed.append({k:item[k] for k in ['remote','bytes','sha256']})
base=pathlib.Path('/home/qq/hepta-learn-ff41-tools')
previous=json.loads((base/'validation/root-fbf2cc0a-native-tests-v1/result.json').read_text())
assert previous['status']=='completed' and previous['source_unchanged'] and previous.get('head',previous.get('expected_head'))==manifest['prior_native_head']
assert not (base/('validation/root-bfee5aa3-scoped-fix-v1')).exists()
launch=base/'validation/root-bfee5aa3-scoped-fix-launch-v1';launch.mkdir(exist_ok=False)
child=subprocess.Popen(['/usr/bin/python3',str(base/'root_bfee5aa3_scoped_fix_v1.py')],stdin=subprocess.DEVNULL,stdout=(launch/'stdout.log').open('xb'),stderr=(launch/'stderr.log').open('xb'),start_new_session=True)
record={'status':'compile_probe_launched','pid':child.pid,'head':manifest['head'],'tree':manifest['tree'],'at':str(datetime.datetime.now(datetime.timezone.utc)),'files':observed,'native_tests_launched':False}
(launch/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
