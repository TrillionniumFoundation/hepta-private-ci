 bundle=BASE/'root-bfee5aa3-source.bundle'
 data=bundle.read_bytes();assert len(data)==3348 and hashlib.sha256(data).hexdigest()=='df4c76b4b462936fe791619d983b7535e2595d60e4a3b22f2e92c737aea978ba','candidate bundle differs'
 assert not git(SOURCE,'status','--porcelain').strip(),'source-library has changes'
 with (OUT/'bundle-verify-import.log').open('xb') as log:
  subprocess.run(['/usr/bin/git','bundle','verify',str(bundle)],cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['/usr/bin/git','fetch',str(bundle),'HEAD:refs/remotes/original-source/candidate-bfee5aa3'],cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT,check=True)
 assert git(SOURCE,'rev-parse','refs/remotes/original-source/candidate-bfee5aa3').decode().strip()==HEAD
 result['source_library']={'path':str(SOURCE),'head':git(SOURCE,'rev-parse','HEAD').decode().strip(),'tree':git(SOURCE,'rev-parse',HEAD+'^{tree}').decode().strip(),'status':git(SOURCE,'status','--porcelain').decode()}
 assert result['source_library']['tree']==TREE,'source-library exact tree differs'
 assert REPO.is_dir(),'stable native worktree missing'
 assert git(REPO,'rev-parse','HEAD').decode().strip()=='fbf2cc0a3eaf4ca1e720300c306ff6ad38517449','stable worktree predecessor differs'
 assert not git(REPO,'status','--porcelain').strip(),'stable worktree has changes'
 archive=Path('/home/qq/hepta-learn-ff41-archived-source-fbf2cc0a-before-bfee5aa3-v1');assert not archive.exists()
 with (OUT/'source-import.log').open('wb') as log:
  subprocess.run(['/usr/bin/git','worktree','add','--detach',str(archive),'fbf2cc0a3eaf4ca1e720300c306ff6ad38517449'],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
  assert git(archive,'rev-parse','HEAD^{tree}').decode().strip()=='7b5104c68e65c4fec111f21d3aa8f5ba04984e9d'
  assert not git(archive,'status','--porcelain').strip()
  subprocess.run(['/usr/bin/git','fetch',str(BASE/'root-bfee5aa3-source.bundle'),'HEAD:refs/remotes/original-source/candidate-bfee5aa3'],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
  assert git(REPO,'rev-parse','refs/remotes/original-source/candidate-bfee5aa3').decode().strip()==HEAD
  subprocess.run(['/usr/bin/git','checkout','--detach',HEAD],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
 result['stable_worktree_reuse']={'original_head':'fbf2cc0a3eaf4ca1e720300c306ff6ad38517449','original_archive':str(archive),'reason':'Preserve compiler source paths; original clean source and all original run evidence remain retained.'}
