
def recovery_log(value):
    pending=OUT/'source-hydration.json.tmp'
    with pending.open('w') as stream:
        json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    os.replace(pending,OUT/'source-hydration.json')
    directory=os.open(OUT,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:os.fsync(directory)
    finally:os.close(directory)


def open_directory(path):
    assert path.is_absolute() and '..' not in path.parts
    flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
    current=os.open('/',flags)
    try:
        for part in path.parts[1:]:
            following=os.open(part,flags,dir_fd=current)
            os.close(current);current=following
        return current
    except BaseException:
        os.close(current);raise


def relative_parent(root,relative):
    path=Path(relative)
    assert not path.is_absolute() and path.parts and all(part not in ('.','..') for part in path.parts)
    assert path.as_posix()==relative
    current=os.dup(root)
    try:
        for part in path.parts[:-1]:
            following=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=current)
            os.close(current);current=following
        return current,path.name
    except BaseException:
        os.close(current);raise


def stamp(metadata):
    return {key:getattr(metadata,key) for key in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')}


def checked_original_file(parent,name,expected):
    descriptor=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
    try:
        before=os.fstat(descriptor)
        assert stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_uid==1000
        assert before.st_size==expected['bytes']
        pieces=[];remaining=expected['bytes']+1
        while remaining:
            part=os.read(descriptor,min(remaining,1024*1024))
            if not part:break
            pieces.append(part);remaining-=len(part)
        raw=b''.join(pieces)
        after=os.fstat(descriptor)
        assert stamp(before)==stamp(after)
        assert stamp(after)==stamp(os.stat(name,dir_fd=parent,follow_symlinks=False))
        assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256']
        assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==expected['blob']
        return raw,stamp(after)
    finally:os.close(descriptor)


def require_same_directory(path,held):
    observed=open_directory(path)
    try:
        a,b=os.fstat(observed),os.fstat(held)
        assert (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino),'directory path identity changed'
    finally:os.close(observed)


def require_same_parent(root,path,held):
    observed,_=relative_parent(root,path)
    try:
        a,b=os.fstat(observed),os.fstat(held)
        assert (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino),'parent directory identity changed'
    finally:os.close(observed)


def hydrate_confirmed_archives():
    record={'status':'preflight','scope':'Create only nine confirmed missing immutable archives; no index/config/ref edits or prior evidence changes. This is source hydration, not unchanged source relative to v1.','expected_head':HEAD,'expected_tree':TREE,'created':[]}
    recovery_log(record)
    roots=[];parents=[];prepared=[]
    try:
        prior_bytes=(PRIOR_OUT/'result.json').read_bytes()
        assert len(prior_bytes)==2396 and hashlib.sha256(prior_bytes).hexdigest()==PRIOR_RESULT_SHA256,'original v1 terminal record differs'
        prior=json.loads(prior_bytes)
        assert prior['status']=='preflight_failed' and prior['exception_type']=='FileNotFoundError'
        assert prior['expected_head']==HEAD and prior['expected_tree']==TREE
        assert 'compile_started' not in prior and 'cargo_recipe_pid' not in prior and 'exit_code' not in prior
        assert prior['stable_worktree_reuse']['original_head']==PRIOR_HEAD
        assert prior['stable_worktree_reuse']['original_archive']==str(ARCHIVE)
        for name,expected in prior['logs'].items():
            path=Path(name);assert not path.is_absolute() and '..' not in path.parts
            raw=(PRIOR_OUT/path).read_bytes()
            assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],'original v1 log differs'
        (OUT/'prior-scoped-fix-v1-result.original.json').write_bytes(prior_bytes)
        assert HYDRATION_EXPECTED['head']==HEAD and HYDRATION_EXPECTED['tree']==TREE
        expected=HYDRATION_EXPECTED['observed_missing_archive_files']
        assert len(expected)==9 and len({row['path'] for row in expected})==9
        assert HYDRATION_EXPECTED['tracked_files']==15497
        assert git(REPO,'rev-parse','HEAD').decode().strip()==HEAD
        assert git(REPO,'rev-parse','HEAD^{tree}').decode().strip()==TREE
        assert not git(REPO,'status','--porcelain').strip(),'stable worktree has changes'
        destination=open_directory(REPO);roots.append(destination)
        original=open_directory(ARCHIVE);roots.append(original)
        index_before=git(REPO,'ls-files','-s','-z')
        flags_before=git(REPO,'ls-files','-v','-z')
        config_before=git(REPO,'config','--local','--null','--list')
        entries=[];index={};missing=[]
        for entry in index_before.split(b'\0'):
            if not entry:continue
            meta,name=entry.split(b'\t',1);mode,blob,stage=meta.split()
            assert stage==b'0' and name not in index
            index[name]=(mode,blob,stage);entries.append((mode,name))
            try:(REPO/os.fsdecode(name)).lstat()
            except FileNotFoundError:missing.append(os.fsdecode(name))
        assert len(entries)==15497
        assert missing==[row['path'] for row in expected],'missing tracked set or order differs from the nine observed archives'
        flag_entries=flags_before.split(b'\0')
        record.update(initial_missing=missing,index_before_sha256=hashlib.sha256(index_before).hexdigest(),index_flags_before_sha256=hashlib.sha256(flags_before).hexdigest(),local_config_before_sha256=hashlib.sha256(config_before).hexdigest(),prior_v1_result_sha256=PRIOR_RESULT_SHA256)
        archive_before=snapshot(ARCHIVE)
        assert archive_before==ARCHIVE_EXPECTED,'existing fbf archive is not the complete original frozen source'
        record['archive_before']=archive_before
        recovery_log(record)
        for row in expected:
            path=row['path'];encoded=os.fsencode(path)
            assert row['git_mode']=='100644'
            assert index[encoded]==(b'100644',row['blob'].encode(),b'0')
            assert flag_entries.count(b'S '+encoded)==1,'confirmed missing archive lacks exact skip-worktree flag S'
            required=b'100644 blob '+row['blob'].encode()+b'\t'+encoded+b'\0'
            assert git(REPO,'ls-tree','-z',PRIOR_HEAD,'--',path)==required
            assert git(REPO,'ls-tree','-z',HEAD,'--',path)==required
            parent,name=relative_parent(destination,path);parents.append(parent)
            original_parent,original_name=relative_parent(original,path);parents.append(original_parent)
            try:os.stat(name,dir_fd=parent,follow_symlinks=False)
            except FileNotFoundError:pass
            else:raise AssertionError('destination already exists, including partial file or symlink')
            raw=git(REPO,'cat-file','blob',row['blob'])
            assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
            assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['blob']
            archived,original_stamp=checked_original_file(original_parent,original_name,row)
            assert archived==raw,'archive bytes differ from immutable Git blob'
            prepared.append({'expected':row,'raw':raw,'parent':parent,'name':name,'original_parent':original_parent,'original_name':original_name,'original_stamp':original_stamp})
        replacements={os.fsencode(item['expected']['path']):item['raw'] for item in prepared}
        virtual=hashlib.sha256()
        for mode,name in entries:
            path=REPO/os.fsdecode(name)
            raw=replacements[name] if name in replacements else (os.readlink(path).encode() if path.is_symlink() else path.read_bytes())
            virtual.update(mode+b'\0'+name+b'\0'+hashlib.sha256(raw).digest())
        assert virtual.hexdigest()==HYDRATION_EXPECTED['tracked_sha256'],'existing source plus exact missing blobs differs from Cloud candidate'
        record.update(status='preflight_complete',all_nine_prechecked=True,virtual_candidate_sha256=virtual.hexdigest(),inputs=[{'expected':item['expected'],'archive_original':item['original_stamp'],'index_flag':'S','parent_and_new_head_blob_equal':True} for item in prepared])
        recovery_log(record)
        require_same_directory(REPO,destination);require_same_directory(ARCHIVE,original)
        assert git(REPO,'ls-files','-s','-z')==index_before and git(REPO,'ls-files','-v','-z')==flags_before
        assert git(REPO,'config','--local','--null','--list')==config_before
        for item in prepared:
            row=item['expected'];parent=item['parent'];name=item['name']
            require_same_parent(destination,row['path'],parent)
            raw,observed=checked_original_file(item['original_parent'],item['original_name'],row)
            assert raw==item['raw'] and observed==item['original_stamp'],'original archive changed after preflight'
            descriptor=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=parent)
            try:
                opened=os.fstat(descriptor)
                assert stat.S_ISREG(opened.st_mode) and opened.st_nlink==1 and opened.st_size==0 and opened.st_uid==1000
                created={'path':row['path'],'status':'created_empty','original_blob':row['blob'],'expected_sha256':row['sha256'],'expected_bytes':row['bytes'],'opened':stamp(opened)}
                record['created'].append(created);record['status']='hydrating';recovery_log(record)
                view=memoryview(item['raw'])
                while view:
                    count=os.write(descriptor,view)
                    assert count>0,'archive write made no progress'
                    view=view[count:]
                os.fsync(descriptor)
                written=os.fstat(descriptor)
                assert written.st_size==row['bytes']
            finally:os.close(descriptor)
            os.fsync(parent)
            require_same_parent(destination,row['path'],parent)
            restored,after=checked_original_file(parent,name,row)
            assert restored==item['raw'] and after==stamp(written)
            created.update(status='restored_and_fsynced',after=after,actual_sha256=hashlib.sha256(restored).hexdigest())
            recovery_log(record)
        require_same_directory(REPO,destination);require_same_directory(ARCHIVE,original)
        assert git(REPO,'ls-files','-s','-z')==index_before,'index entries changed'
        assert git(REPO,'ls-files','-v','-z')==flags_before,'index flags changed'
        assert git(REPO,'config','--local','--null','--list')==config_before,'local Git config changed'
        assert (PRIOR_OUT/'result.json').read_bytes()==prior_bytes,'v1 original result changed'
        for name,expected in prior['logs'].items():
            raw=(PRIOR_OUT/name).read_bytes()
            assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],'v1 original log changed'
        for item in prepared:
            raw,after=checked_original_file(item['original_parent'],item['original_name'],item['expected'])
            assert raw==item['raw'] and after==item['original_stamp'],'archive original changed'
        archive_after=snapshot(ARCHIVE);assert archive_after==archive_before
        actual=snapshot(REPO)
        assert actual['head']==HEAD and actual['tree']==TREE and not actual['status']
        assert actual['tracked_files']==HYDRATION_EXPECTED['tracked_files'] and actual['tracked_sha256']==HYDRATION_EXPECTED['tracked_sha256']
        record.update(status='completed',candidate_after_hydration=actual,archive_after=archive_after,archive_unchanged=True,index_entries_unchanged=True,index_flags_unchanged=True,local_git_config_unchanged=True,prior_v1_evidence_unchanged=True)
        recovery_log(record)
        return {'record':str(OUT/'source-hydration.json'),'initial_missing':missing,'created_files':len(record['created']),'candidate_after_hydration':actual,'archive_unchanged':True,'source_unchanged_scope':'Only the subsequent complete candidate compile before/after; v1 lacked nine archives.'}
    except BaseException as error:
        record.update(status='failed',exception_type=type(error).__name__,exception=str(error),partial_created_files_preserved=True,automatic_replay=False)
        recovery_log(record);raise
    finally:
        for descriptor in reversed(parents+roots):os.close(descriptor)
