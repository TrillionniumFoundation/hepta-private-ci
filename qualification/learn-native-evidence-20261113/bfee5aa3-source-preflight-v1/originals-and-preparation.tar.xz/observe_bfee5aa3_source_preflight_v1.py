"""Read source metadata and preserved preflight logs; do not change a checkout."""
from pathlib import Path
import subprocess, os, json, hashlib, datetime, traceback

BASE = Path('/home/qq/hepta-learn-ff41-tools')
REPO = Path('/home/qq/hepta-learn-ff41-native-root-279deb99-v1')
ARCHIVE = Path('/home/qq/hepta-learn-ff41-archived-source-fbf2cc0a-before-bfee5aa3-v1')
OUT = BASE / 'validation/root-bfee5aa3-source-preflight-observation-v1'
PREVIOUS = BASE / 'validation/root-bfee5aa3-scoped-fix-v1'
REL = 'qualification/cell-platform-fixtures-20261108/native-and-ci-evidence.tar.gz'
HEAD = 'bfee5aa363cb63897c28c8f74fd6b167de5e859b'
OLD = 'fbf2cc0a3eaf4ca1e720300c306ff6ad38517449'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')

def git(repo, *args):
    return subprocess.check_output(['/usr/bin/git', *args], cwd=repo, env=GIT_ENV)

def physical(path):
    if not path.exists() and not path.is_symlink():
        return {'exists': False}
    s = path.lstat()
    value = {'exists': True, 'device': s.st_dev, 'inode': s.st_ino, 'mode': s.st_mode,
             'uid': s.st_uid, 'gid': s.st_gid, 'bytes': s.st_size, 'mtime_ns': s.st_mtime_ns,
             'ctime_ns': s.st_ctime_ns, 'symlink': path.is_symlink()}
    if path.is_file() and not path.is_symlink():
        value['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    return value

OUT.mkdir(exist_ok=False)
record = {'status': 'started', 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'uid': os.getuid(), 'scope': 'Read-only Git source/index/object metadata and original preflight logs; no Rust, business stores or checkout mutation.'}
try:
    assert os.getuid() == 1000
    record['preserved_logs'] = {}
    for name in ['result.json', 'driver-error.log', 'source-import.log', 'bundle-verify-import.log']:
        raw = (PREVIOUS / name).read_bytes()
        (OUT / ('original-' + name)).write_bytes(raw)
        record['preserved_logs'][name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    record['checkouts'] = {}
    for label, repo in [('stable', REPO), ('prior_archive', ARCHIVE)]:
        before = git(repo, 'rev-parse', 'HEAD').decode().strip()
        tree = git(repo, 'rev-parse', 'HEAD^{tree}').decode().strip()
        status = git(repo, 'status', '--porcelain', '--untracked-files=no').decode()
        flags = git(repo, 'ls-files', '-v', '--', REL).decode()
        entries = git(repo, 'ls-files', '-s', '-z').split(b'\0')
        missing = []
        for entry in entries:
            if not entry:
                continue
            meta, rel = entry.split(b'\t', 1)
            path = repo / os.fsdecode(rel)
            if not path.exists() and not path.is_symlink():
                missing.append({'path': os.fsdecode(rel), 'index': meta.decode()})
        config = subprocess.run(['/usr/bin/git', 'config', '--get-regexp', '^(core.sparseCheckout|core.hooksPath|core.worktree)$'], cwd=repo, env=GIT_ENV, capture_output=True)
        record['checkouts'][label] = {'path': str(repo), 'head': before, 'tree': tree,
            'status': status, 'selected_index_flags': flags, 'selected_file': physical(repo / REL),
            'missing_tracked_files': missing, 'configuration_exit': config.returncode,
            'configuration': config.stdout.decode(), 'head_unchanged': before == git(repo, 'rev-parse', 'HEAD').decode().strip()}
    record['objects'] = {}
    for revision in [OLD, HEAD]:
        entry = git(REPO, 'ls-tree', revision, '--', REL).decode().strip()
        raw = git(REPO, 'cat-file', 'blob', revision + ':' + REL)
        record['objects'][revision] = {'entry': entry, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    record['status'] = 'completed'
except BaseException as error:
    record['status'] = 'failed'
    record['error'] = str(error)
    (OUT / 'error.log').write_text(traceback.format_exc())
finally:
    record['finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
