#!/usr/bin/env python3
"""Publish only missing bytes of the pinned MEM6 archive through existing gh auth.

Run once on desktop after a verified preflight. This uses immutable Git objects,
performs complete remote-byte readback, and creates one new branch at the end.
It does not execute archived code, rerun actors, replace historical indexes,
change credentials or create a pull request. An uncertain run must be reconciled
from its original PTY identity and receipts, never restarted under a new key.
"""
import base64
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import threading

ROOT = Path("/home/qian-qi/mem6-archive-publication-20261111-ed353-v2")
SOURCE = Path("/home/qian-qi/mem6-cold-custody-20261110-ed353-v1/mem6-cas-001.tar.xz")
REPOSITORY = "TrillionniumFoundation/hepta-private-ci"
RUN = "qualification/memory-cell-mem6/run-001/"
BRANCH = "research/mem6-full-archive-20261111-ed353"
NEW_PART_DIRECTORY = "raw-transfer/complete-20261111-ed353/"
PLAN_PATH = RUN + "ARCHIVE_COMPLETION_PLAN_20261111_ED353.json"
INDEX_PATH = RUN + "ARCHIVE_COMPLETE_INDEX_20261111_ED353.json"
EXPECTED_BYTES = 61412948
EXPECTED_SHA = "f77acd9feb27fda3f8000b0d089dbdbe258a4adfb7acedcb2e0cd590cc4f361e"
EXPECTED_VERSION = "2050:50102880:61412948:1794317318863616657:1794329732213425735"
KEY = "mem6-original-publication-desktop-20261111-ed353-v1"
LOCK = threading.Lock()
TREE_CACHE = {}
PHASE = "preconditions"
START_OWNED = False


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git_blob_id(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()


def save(name, value):
    with (ROOT / name).open("xb") as output:
        output.write(encoded(value))


def event(value):
    value = {"at": datetime.now(timezone.utc).isoformat(), **value}
    with LOCK:
        with (ROOT / "PUBLICATION_EVENTS.jsonl").open("a") as output:
            output.write(json.dumps(value, sort_keys=True) + "\n")
            output.flush()
            os.fsync(output.fileno())


def gh(endpoint, body=None, *, allow404=False, global_path=False):
    endpoint = endpoint if global_path else ("repos/" + REPOSITORY + "/" + endpoint).rstrip("/")
    args = ["/usr/bin/gh", "api", endpoint]
    payload = None
    if body is not None:
        payload = encoded(body)
        args += ["--method", "POST", "--input", "-"]
        event({"kind": "write_request", "endpoint": endpoint,
               "payload_sha256": digest(payload), "payload_bytes": len(payload)})
    completed = subprocess.run(args, input=payload, capture_output=True, timeout=90)
    if completed.returncode:
        status = re.findall(rb"HTTP [0-9]{3}", completed.stderr)
        event({"kind": "request_failed", "endpoint": endpoint,
               "returncode": completed.returncode,
               "http_status": [s.decode() for s in status],
               "stderr_bytes": len(completed.stderr),
               "stderr_sha256": digest(completed.stderr),
               "write_effect_unknown": body is not None})
        if allow404 and b"HTTP 404" in completed.stderr:
            return None
        raise RuntimeError("GitHub request failed at " + endpoint +
                           "; returncode=" + str(completed.returncode))
    value = json.loads(completed.stdout)
    if body is not None:
        event({"kind": "write_response", "endpoint": endpoint,
               "sha": value.get("sha") or value.get("object", {}).get("sha")})
    return value


def source_pin():
    before = SOURCE.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size != EXPECTED_BYTES:
        raise ValueError("source must be the pinned regular archive")
    identity = lambda s: ":".join(str(v) for v in (
        s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns))
    version = identity(before)
    if version != EXPECTED_VERSION:
        raise ValueError("source version changed")
    raw = SOURCE.read_bytes()
    if digest(raw) != EXPECTED_SHA or identity(SOURCE.lstat()) != version:
        raise ValueError("source bytes or identity changed")
    return raw, {"path": str(SOURCE), "bytes": len(raw),
                 "sha256": digest(raw), "version": version}


def tree(sha):
    if sha not in TREE_CACHE:
        value = gh("git/trees/" + sha)
        if value.get("truncated"):
            raise ValueError("Git tree response truncated")
        TREE_CACHE[sha] = {row["path"]: row for row in value["tree"]}
    return TREE_CACHE[sha]


def resolve(root_tree, path):
    current = root_tree
    components = PurePosixPath(path).parts
    for number, component in enumerate(components):
        row = tree(current).get(component)
        if row is None:
            return None
        if number + 1 < len(components):
            if row["type"] != "tree":
                raise ValueError("non-tree path prefix")
            current = row["sha"]
    return row


def upload_blob(raw):
    if len(raw) > 512000:
        raise ValueError("repository blob budget exceeded")
    expected = git_blob_id(raw)
    value = gh("git/blobs", {
        "encoding": "base64", "content": base64.b64encode(raw).decode("ascii")})
    if value["sha"] != expected:
        raise ValueError("GitHub blob identity differs")
    return expected


def download_part(row):
    value = gh("git/blobs/" + row["git_blob"])
    if value["encoding"] != "base64" or value["sha"] != row["git_blob"]:
        raise ValueError("unexpected GitHub blob response")
    content = base64.b64decode("".join(value["content"].split()), validate=True)
    if (len(content) != row["bytes"] or digest(content) != row["sha256"] or
            git_blob_id(content) != row["git_blob"]):
        raise ValueError("GitHub part byte readback differs")
    with (ROOT / "readback-parts" / ("%012d.part" % row["archive_offset"])).open("xb") as output:
        output.write(content)
    event({"kind": "part_readback_verified", "path": row["path"],
           "offset": row["archive_offset"], "bytes": row["bytes"],
           "sha256": row["sha256"], "git_blob": row["git_blob"]})
    return row


def commit(tree_sha, parent, message, identity):
    value = gh("git/commits", {
        "tree": tree_sha, "parents": [parent], "message": message,
        "author": identity, "committer": identity})
    if value["tree"]["sha"] != tree_sha or [p["sha"] for p in value["parents"]] != [parent]:
        raise ValueError("created commit does not match requested tree and parent")
    return value["sha"]


def parallel_checked(function, values):
    pool = ThreadPoolExecutor(max_workers=4)
    futures = {pool.submit(function, value): index for index, value in enumerate(values)}
    results = [None] * len(futures)
    try:
        for future in as_completed(futures):
            results[futures[future]] = future.result()
    except Exception:
        for future in futures:
            future.cancel()
        raise
    finally:
        pool.shutdown(wait=True, cancel_futures=True)
    return results


def main():
    global PHASE, START_OWNED
    os.umask(0o077)
    if os.getuid() != 1000:
        raise ValueError("unexpected desktop operator uid")
    preflight = json.loads((ROOT / "PREFLIGHT_RECEIPT.json").read_bytes())
    prior_raw = (ROOT / "BASE_ARCHIVE_INDEX.json").read_bytes()
    prior = json.loads(prior_raw)
    if (preflight["status"] != "verified" or preflight["repository"] != REPOSITORY or
            preflight["proposed_branch"] != BRANCH or
            digest(prior_raw) != preflight["base_index_sha256"]):
        raise ValueError("preflight binding differs")
    archive, before = source_pin()
    if before != preflight["source"]:
        raise ValueError("source differs from preflight")
    fs = os.statvfs(ROOT)
    if fs.f_bavail * fs.f_frsize < 2 * 1024**3:
        raise ValueError("insufficient publication/readback disk budget")
    stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    save("PUBLICATION_START.json", {
        "schema": "hepta.mem6.complete-publication-start.v1",
        "created_at": stamp, "idempotency_key": KEY, "pid": os.getpid(),
        "source": before, "branch": BRANCH})
    START_OWNED = True
    (ROOT / "readback-parts").mkdir(mode=0o700, exist_ok=False)
    profile = gh("user", global_path=True)
    if profile["login"] != "ProfHepta":
        raise ValueError("unexpected current GitHub actor")
    if not gh("")["permissions"]["push"]:
        raise ValueError("current GitHub actor lacks push")
    if gh("git/ref/heads/" + BRANCH, allow404=True) is not None:
        raise ValueError("branch already exists; reconcile rather than overwrite")
    remaining = gh("rate_limit", global_path=True)["resources"]["core"]["remaining"]
    if remaining < 400:
        raise ValueError("insufficient GitHub readback/write request budget")
    identity = {}
    for field, key in (("name", "user.name"), ("email", "user.email")):
        result = subprocess.run(["/usr/bin/git", "config", "--get", key],
                                capture_output=True, text=True, check=True)
        identity[field] = result.stdout.strip()
        if not identity[field]:
            raise ValueError("existing Git identity is incomplete")
    identity["date"] = stamp
    base = preflight["base_commit"]
    base_commit = gh("git/commits/" + base)
    base_tree = base_commit["tree"]["sha"]
    for path in (PLAN_PATH, INDEX_PATH, RUN + NEW_PART_DIRECTORY.rstrip("/")):
        if resolve(base_tree, path) is not None:
            raise ValueError("new publication path already exists in base")
    PHASE = "verify_existing_published_parts"
    parts = []
    cursor = 0
    missing = []
    for original in sorted(prior["published_parts"], key=lambda p: p["archive_offset"]):
        row = dict(original)
        path = PurePosixPath(row["path"])
        if (path.is_absolute() or ".." in path.parts or
                not row["path"].startswith("raw-transfer/")):
            raise ValueError("invalid prior part path")
        start, size = row["archive_offset"], row["bytes"]
        if start < cursor or size <= 0 or size > 512000:
            raise ValueError("invalid prior part range")
        if start > cursor:
            missing.append((cursor, start))
        data = archive[start:start + size]
        existing = resolve(base_tree, RUN + row["path"])
        if (existing is None or existing["type"] != "blob" or
                digest(data) != row["sha256"] or len(data) != size):
            raise ValueError("prior part or source mismatch")
        row["git_blob"] = existing["sha"]
        if row["git_blob"] != git_blob_id(data):
            raise ValueError("prior Git blob differs from archive")
        parts.append(row)
        cursor = start + size
    if cursor < len(archive):
        missing.append((cursor, len(archive)))
    if sum(r["bytes"] for r in parts) != prior["published_bytes"]:
        raise ValueError("prior published byte total differs")
    parallel_checked(download_part, parts)
    new_parts = []
    for start, end in missing:
        for offset in range(start, end, 500000):
            content = archive[offset:min(offset + 500000, end)]
            new_parts.append({
                "path": NEW_PART_DIRECTORY + ("missing-%012d.part" % offset),
                "archive_offset": offset, "bytes": len(content),
                "sha256": digest(content), "kind": "missing_range_completion"})
    PHASE = "upload_missing_immutable_blobs"
    def upload_part(row):
        content = archive[row["archive_offset"]:row["archive_offset"] + row["bytes"]]
        return {**row, "git_blob": upload_blob(content)}
    new_parts = parallel_checked(upload_part, new_parts)
    parts = sorted(parts + new_parts, key=lambda p: p["archive_offset"])
    cursor = 0
    for row in parts:
        if row["archive_offset"] != cursor:
            raise ValueError("full archive has a gap or overlap")
        cursor += row["bytes"]
    if cursor != EXPECTED_BYTES:
        raise ValueError("full archive byte total differs")
    plan = {
        "schema": "hepta.mem6.complete-archive-publication-plan.v1",
        "created_at": stamp, "status": "STAGED_PENDING_GITHUB_READBACK",
        "archive_descriptor": prior["archive_descriptor"],
        "base_commit": base, "historical_partial_index_sha256": digest(prior_raw),
        "parts": parts, "new_parts": len(new_parts),
        "new_bytes": sum(p["bytes"] for p in new_parts),
        "expected_total_bytes": EXPECTED_BYTES,
        "complete_archive_published": False,
        "cloud_complete_archive_downloaded": False,
        "full_owner_cold_recovery": False, "independent_trust_domain": False}
    save("ARCHIVE_COMPLETION_PLAN.json", plan)
    plan_blob = upload_blob(encoded(plan))
    entries = [{"path": RUN + row["path"], "mode": "100644",
                "type": "blob", "sha": row["git_blob"]} for row in new_parts]
    entries.append({"path": PLAN_PATH, "mode": "100644", "type": "blob", "sha": plan_blob})
    content_tree = gh("git/trees", {"base_tree": base_tree, "tree": entries})["sha"]
    content_commit = commit(
        content_tree, base, "qualification(mem6): complete pinned original archive bytes", identity)
    event({"kind": "immutable_content_commit", "sha": content_commit, "tree": content_tree})
    PHASE = "verify_complete_github_byte_readback"
    for row in parts:
        observed = resolve(content_tree, RUN + row["path"])
        if observed is None or observed["type"] != "blob" or observed["sha"] != row["git_blob"]:
            raise ValueError("content tree does not reference expected part")
    parallel_checked(download_part, new_parts)
    full = hashlib.sha256()
    total = 0
    for row in parts:
        content = (ROOT / "readback-parts" / ("%012d.part" % row["archive_offset"])).read_bytes()
        if len(content) != row["bytes"] or digest(content) != row["sha256"]:
            raise ValueError("cached GitHub readback changed")
        full.update(content)
        total += len(content)
    if total != EXPECTED_BYTES or full.hexdigest() != EXPECTED_SHA:
        raise ValueError("GitHub complete archive readback mismatch")
    after = source_pin()[1]
    if before != after:
        raise ValueError("source changed during publication")
    index = {
        "schema": "hepta.mem6.complete-raw-archive-publication.v1",
        "created_at": stamp, "status": "COMPLETE_BYTES_VERIFIED_FROM_GITHUB",
        "complete_archive_published": True,
        "publication_branch": BRANCH,
        "content_commit": content_commit, "content_tree": content_tree,
        "base_commit": base, "archive_descriptor": prior["archive_descriptor"],
        "historical_partial_index_path": "ARCHIVE_INDEX.json",
        "historical_partial_index_sha256": digest(prior_raw),
        "historical_partial_index_unchanged": True,
        "parts": parts, "published_bytes": total, "part_count": len(parts),
        "new_part_count": len(new_parts), "new_bytes": sum(p["bytes"] for p in new_parts),
        "whole_archive_sha256": full.hexdigest(),
        "github_readback": {
            "every_part_downloaded_and_sha256_verified": True,
            "complete_offset_order_sha256_verified": True,
            "existing_parts_source": "immutable base Git blobs, checked before missing-byte upload",
            "new_parts_source": "new immutable Git blobs, checked after content commit creation",
            "every_content_tree_path_resolves_expected_blob": True},
        "source_before": before, "source_after": after,
        "cloud_complete_archive_downloaded": False,
        "actor_reexecuted": False, "archived_code_executed": False,
        "full_owner_cold_recovery": False, "independent_trust_domain": False,
        "external_runtime_inputs_included": False, "scientific_acceptance": "HOLD",
        "limitations": [
            "Complete original byte publication does not establish owner or capability recovery.",
            "The historical partial cloud download is unchanged.",
            "Recorded scientific outcomes and thresholds are unchanged."]}
    save("ARCHIVE_COMPLETE_INDEX.json", index)
    index_blob = upload_blob(encoded(index))
    final_tree = gh("git/trees", {"base_tree": content_tree, "tree": [
        {"path": INDEX_PATH, "mode": "100644", "type": "blob", "sha": index_blob}]})["sha"]
    old_raw_tree = resolve(content_tree, RUN + "raw-transfer")["sha"]
    new_raw_tree = resolve(final_tree, RUN + "raw-transfer")["sha"]
    if old_raw_tree != new_raw_tree:
        raise ValueError("receipt tree changed already verified raw bytes")
    head = commit(final_tree, content_commit,
                  "qualification(mem6): bind complete GitHub archive readback", identity)
    save("READY_TO_PUBLISH.json", {"commit": head, "tree": final_tree,
                                 "content_commit": content_commit, "branch": BRANCH})
    PHASE = "create_new_branch"
    if gh("git/ref/heads/" + BRANCH, allow404=True) is not None:
        raise ValueError("publication branch appeared; no overwrite attempted")
    try:
        gh("git/refs", {"ref": "refs/heads/" + BRANCH, "sha": head})
    except Exception:
        observed = gh("git/ref/heads/" + BRANCH, allow404=True)
        if observed is None or observed["object"]["sha"] != head:
            raise
    observed = gh("git/ref/heads/" + BRANCH)
    if observed["object"]["sha"] != head:
        raise ValueError("published branch does not match verified commit")
    result = {
        "schema": "hepta.mem6.complete-archive-publication-receipt.v1",
        "status": "VERIFIED_PUBLISHED", "created_at": datetime.now(timezone.utc).isoformat(),
        "idempotency_key": KEY, "repository": REPOSITORY, "branch": BRANCH,
        "head": head, "content_commit": content_commit, "content_tree": content_tree,
        "raw_tree": new_raw_tree, "index_path": INDEX_PATH, "index_blob": index_blob,
        "archive_bytes": total, "archive_sha256": full.hexdigest(),
        "part_count": len(parts), "new_part_count": len(new_parts),
        "new_bytes": sum(p["bytes"] for p in new_parts),
        "github_actor": profile["login"], "source_unchanged": before == after,
        "cloud_complete_archive_downloaded": False, "pull_request_created": False,
        "full_owner_cold_recovery": False, "independent_trust_domain": False,
        "actor_reexecuted": False, "scientific_acceptance": "HOLD"}
    save("PUBLICATION_RECEIPT.json", result)
    event({"kind": "verified_published", "head": head})
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        if START_OWNED:
            save("PUBLICATION_FAILURE.json", {
                "phase": PHASE, "error_type": type(error).__name__,
                "message": str(error), "automatic_retry": False,
                "instruction": "Inspect original event journal/PTY and known Git objects before retrying."})
        raise
