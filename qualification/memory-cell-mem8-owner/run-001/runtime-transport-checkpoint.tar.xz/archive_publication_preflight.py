
import base64,hashlib,json,os,pathlib,subprocess,stat
from datetime import datetime,timezone
ROOT=pathlib.Path('/home/qian-qi/mem6-archive-publication-20261111-ed353-v1')
SOURCE=pathlib.Path('/home/qian-qi/mem6-cold-custody-20261110-ed353-v1/mem6-cas-001.tar.xz')
REPO='TrillionniumFoundation/hepta-private-ci'
BASE_FALLBACK='39d895547fa7a50c45d580d3e30236c87f99d322'
PATH='qualification/memory-cell-mem6/run-001/ARCHIVE_INDEX.json'
BRANCH='research/mem6-full-archive-20261111-ed353'
EXPECTED_SHA='f77acd9feb27fda3f8000b0d089dbdbe258a4adfb7acedcb2e0cd590cc4f361e'
os.umask(0o077);ROOT.mkdir(mode=0o700,exist_ok=False)
def save(name,value):
 with (ROOT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def api(endpoint,allow404=False):
 p=subprocess.run(['gh','api','repos/'+REPO+'/'+endpoint],capture_output=True,timeout=45)
 if p.returncode:
  if allow404 and b'HTTP 404' in p.stderr:return None
  raise RuntimeError('GitHub read failed: '+endpoint+'; code='+str(p.returncode))
 return json.loads(p.stdout)
def pin():
 st=SOURCE.lstat()
 if not stat.S_ISREG(st.st_mode) or st.st_size!=61412948:raise ValueError('archive file invalid')
 version=':'.join(str(v) for v in [st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns])
 expected='2050:50102880:61412948:1794317318863616657:1794329732213425735'
 if version!=expected:raise ValueError('desktop archive version changed')
 raw=SOURCE.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=EXPECTED_SHA:raise ValueError('archive SHA mismatch')
 return raw,{'path':str(SOURCE),'bytes':len(raw),'sha256':EXPECTED_SHA,'version':version}
save('START_RECEIPT.json',{'schema':'hepta.mem6.archive-publication-preflight.v1','status':'started','created_at':datetime.now(timezone.utc).isoformat(),'idempotency_key':'mem6-original-publication-preflight-pty-20261111-ed353-v1','pid':os.getpid(),'github_write_attempted':False})
try:
 fs=os.statvfs(ROOT)
 if fs.f_bavail*fs.f_frsize<2*1024**3:raise ValueError('less than 2 GiB free')
 raw,pinned=pin()
 repo=api('')
 if not repo.get('permissions',{}).get('push'):raise ValueError('current GitHub actor lacks push')
 main=api('git/ref/heads/main')['object']['sha']
 content=api('contents/'+PATH+'?ref='+main,True)
 base=main
 if content is None:base=BASE_FALLBACK;content=api('contents/'+PATH+'?ref='+base)
 idxraw=base64.b64decode(content['content'],validate=False)
 index=json.loads(idxraw)
 if index['archive_descriptor']['expected_sha256']!=EXPECTED_SHA or index['archive_descriptor']['expected_bytes']!=len(raw):raise ValueError('GitHub archive descriptor mismatch')
 parts=sorted(index['published_parts'],key=lambda p:p['archive_offset'])
 cursor=0;missing=[];published=0
 for row in parts:
  start=row['archive_offset'];size=row['bytes']
  if start<cursor or size<=0 or size>512000:raise ValueError('bad published range')
  if start>cursor:missing.append({'start':cursor,'end_exclusive':start})
  piece=raw[start:start+size]
  if len(piece)!=size or hashlib.sha256(piece).hexdigest()!=row['sha256']:raise ValueError('prior part descriptor differs from pinned original')
  cursor=start+size;published+=size
 if cursor<len(raw):missing.append({'start':cursor,'end_exclusive':len(raw)})
 if published!=index['published_bytes']:raise ValueError('prior byte total differs')
 if api('git/ref/heads/'+BRANCH,True) is not None:raise ValueError('publication branch already exists; inspect before any write')
 with (ROOT/'BASE_ARCHIVE_INDEX.json').open('xb') as f:f.write(idxraw)
 result={'schema':'hepta.mem6.archive-publication-preflight.v1','status':'verified','created_at':datetime.now(timezone.utc).isoformat(),'source':pinned,'repository':REPO,'base_commit':base,'observed_main':main,'proposed_branch':BRANCH,'base_index_path':PATH,'base_index_sha256':hashlib.sha256(idxraw).hexdigest(),'base_index_git_blob':content['sha'],'existing_parts':len(parts),'existing_bytes':published,'missing_bytes':len(raw)-published,'missing_ranges':missing,'new_part_max_bytes':500000,'github_push_permission':True,'github_write_attempted':False,'source_unchanged':pin()[1]==pinned,'actor_rerun':False,'full_owner_cold_recovery':False}
 save('PREFLIGHT_RECEIPT.json',result);print(json.dumps(result,sort_keys=True))
except Exception as e:
 save('PREFLIGHT_FAILURE.json',{'status':'failed','error_type':type(e).__name__,'message':str(e),'github_write_attempted':False});raise
