"""Read-only audit of an exact-source native CI artifact; never execute its files."""

import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def safe_name(name):
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or "\\" in name or not path.parts:
        raise ValueError(f"unsafe archive path: {name!r}")
    return Path(*path.parts)


def describe(name, data):
    return {"path": name, "bytes": len(data), "sha256": digest(data), "git_blob": blob(data)}


def main():
    archive, target, head, tree, base = sys.argv[1:]
    target = Path(target)
    target.mkdir(exist_ok=False)
    source = Path(archive).read_bytes()
    report = {"zip": describe(Path(archive).name, source), "source_sha": head,
              "source_tree": tree, "base_sha": base, "files": [], "receipts": [], "sources": {}}
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        infos = zipped.infolist()
        assert len({i.filename for i in infos}) == len(infos)
        assert sum(i.file_size for i in infos) <= 128 * 1024 * 1024
        for info in infos:
            path = target / safe_name(info.filename)
            assert not stat.S_ISLNK(info.external_attr >> 16)
            if info.is_dir():
                path.mkdir(parents=True, exist_ok=True)
                continue
            path.parent.mkdir(parents=True, exist_ok=True)
            data = zipped.read(info)
            with path.open("xb") as stream:
                stream.write(data)
            report["files"].append(describe(info.filename, data))
    expected = [head, tree]
    assert (target / "source-before.txt").read_text().splitlines() == expected
    assert (target / "source-after.txt").read_text().splitlines() == expected
    assert (target / "worktree-before.txt").read_bytes() == b""
    event = (target / "event-identity.txt").read_text().splitlines()
    assert event[-2:] == [head, base]
    report["source_ref"] = event[0]
    report["worktree_after"] = (target / "worktree-after.txt").read_text().splitlines()
    report["stage_presence"] = (target / "stages.txt").read_text()
    for path in sorted(target.glob("*.json")):
        receipt = json.loads(path.read_bytes())
        if "command" not in receipt:
            continue
        assert receipt["source_sha"] == head and receipt["tested_sha"] == head
        assert receipt["base_sha"] == base and receipt["lane"] == "source-head"
        before = receipt["before"]
        assert before["commit"] == head and before["tree"] == tree and not before["dirty"]
        if "log_file" in receipt:
            logfile = target / safe_name(receipt["log_file"])
            log = logfile.read_bytes()
            assert len(log) == receipt["log_bytes"]
            assert digest(log) == receipt["log_sha256"]
            text = re.sub(r"\x1b\[[0-9;]*m", "", log.decode("utf-8", errors="replace"))
            receipt["observed_case_lines"] = [line for line in text.splitlines()
                                              if re.search(r"\b(PASS|FAIL|SKIP|TIMEOUT)\b", line)]
        report["receipts"].append({"file": path.name, **receipt})
    for phase, path_list in [("before", "source-paths.zlist"), ("after", "rewrite-paths.zlist")]:
        relative = f"changed-source-{phase}.tar.gz"
        directory = target / f"source-{phase}"
        directory.mkdir()
        entries = []
        with tarfile.open(target / relative, "r:gz") as packed:
            members = packed.getmembers()
            assert len({member.name for member in members}) == len(members)
            assert sum(member.size for member in members) <= 64 * 1024 * 1024
            for member in members:
                assert member.isfile(), f"unexpected tar entry type: {member.name}"
                path = directory / safe_name(member.name)
                path.parent.mkdir(parents=True, exist_ok=True)
                data = packed.extractfile(member).read()
                with path.open("xb") as stream:
                    stream.write(data)
                entries.append(describe(member.name, data))
        expected_paths = {name.decode() for name in (target / path_list).read_bytes().split(b"\0") if name}
        assert {entry["path"] for entry in entries} == expected_paths
        report["sources"][phase] = entries
    output = target / "ARTIFACT_AUDIT.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"report": str(output), "zip": report["zip"],
                      "stage_presence": report["stage_presence"],
                      "worktree_after": report["worktree_after"],
                      "sources_after": report["sources"]["after"],
                      "receipts": [{key: item.get(key) for key in
                                    ["file", "command", "status", "exit_code", "command_exit_code", "error",
                                     "observed_passed_tests", "observed_failed_tests"]}
                                   for item in report["receipts"]]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
