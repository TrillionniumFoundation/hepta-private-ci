#!/usr/bin/env python3
"""Three independent current-availability GETs, never an inference request."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import urllib.error
import urllib.request

RUN_ID = "mem8-provider-get-desktop-20261111-ed353-v1"
ROOT = Path("/home/qian-qi/mem8-provider-get-readonly-20261111-ed353-v1")
BASE = "http://127.0.0.1:18083"
PATHS = ["/health", "/routing", "/v1/models"]
CAP = 262144


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(b):
    return hashlib.sha256(b).hexdigest()


def save(name, obj):
    b = (json.dumps(obj, indent=2, sort_keys=True) + "\n").encode()
    fd = os.open(ROOT / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(b)
    return {"path": str(ROOT / name), "bytes": len(b), "sha256": sha(b)}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def alarm_handler(signum, frame):
    raise TimeoutError("bounded GET wall deadline")


def safe_projection(obj):
    if not isinstance(obj, dict):
        return {"json_kind": type(obj).__name__}
    out = {"json_kind": "object"}
    for key in ["ok", "healthy", "ready", "available"]:
        if isinstance(obj.get(key), bool):
            out[key] = obj[key]
    for key in ["status", "backend", "active_backend", "default_backend", "selected_backend", "model"]:
        value = obj.get(key)
        if isinstance(value, str) and len(value) <= 160 and re.fullmatch(r"[A-Za-z0-9_.:/+ -]+", value):
            if key != "status" or value.lower() in ["ok", "healthy", "ready", "available", "unavailable", "degraded", "error", "failed", "draining", "busy"]:
                out[key] = value
    if isinstance(obj.get("data"), list):
        ids = []
        for entry in obj["data"]:
            value = entry.get("id") if isinstance(entry, dict) else None
            if isinstance(value, str) and len(value) <= 200 and re.fullmatch(r"[A-Za-z0-9_.:/+ -]+", value):
                ids.append(value)
        out["current_get_model_ids"] = ids
        out["model_id_scope"] = "Current GET metadata only; not an ID or identity observed for the original inference request."
    return out


def main():
    ROOT.mkdir(mode=0o700, exist_ok=False)
    started = utc()
    save("INTENT.json", {"run_id": RUN_ID, "started_at": started, "base_url": BASE,
                         "methods": ["GET"], "paths": PATHS, "attempts_each": 1,
                         "model_requests": 0, "authorization_header_added": False,
                         "proxy_use": False, "redirect_following": False})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    old_handler = signal.signal(signal.SIGALRM, alarm_handler)
    observations = []
    for index, path in enumerate(PATHS):
        observation_id = RUN_ID + "-get-" + str(index + 1)
        item = {"observation_id": observation_id, "id_scope": "Current diagnostic GET only; not the original thread, turn, client key, or model request ID.",
                "method": "GET", "url": BASE + path, "attempts": 1, "started_at": utc(),
                "socket_timeout_seconds": 6, "wall_deadline_seconds": 7}
        signal.setitimer(signal.ITIMER_REAL, 7)
        response = None
        try:
            request = urllib.request.Request(BASE + path, method="GET", headers={"Accept": "application/json", "X-Request-ID": observation_id, "User-Agent": "hepta-readonly-diagnostic"})
            try:
                response = opener.open(request, timeout=6)
            except urllib.error.HTTPError as exc:
                response = exc
            item["http_status"] = response.code
            body = response.read(CAP + 1)
            item["body_limit_exceeded"] = len(body) > CAP
            body = body[:CAP]
            item["captured_body_bytes"] = len(body)
            item["captured_body_sha256"] = sha(body)
            item["raw_body_persisted"] = False
            ids = {}
            for name in ["x-request-id", "request-id", "x-correlation-id"]:
                value = response.headers.get(name)
                if value is not None:
                    ids[name] = {"present": True, "sha256": sha(value.encode()), "bytes": len(value.encode())}
            item["current_get_response_id_metadata"] = ids
            if not item["body_limit_exceeded"]:
                try:
                    obj = json.loads(body)
                except (ValueError, UnicodeDecodeError):
                    item["json_parse_status"] = "NOT_JSON"
                else:
                    item["json_parse_status"] = "PARSED"
                    item["safe_current_availability"] = safe_projection(obj)
        except Exception as exc:
            item["exception_type"] = type(exc).__name__
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            if response is not None:
                response.close()
            item["finished_at"] = utc()
            observations.append(item)
    signal.signal(signal.SIGALRM, old_handler)
    result = {"schema": "hepta.mem8.provider-current-get-readonly.v1", "run_id": RUN_ID,
              "started_at": started, "finished_at": utc(), "observations": observations,
              "model_requests": 0, "service_changes": False, "retry_count": 0,
              "original_provider_final_status": "UNKNOWN",
              "boundary": "These GETs observe current availability only. They do not settle or identify the original inference request; all diagnostic/model-list/response IDs are separate."}
    receipt = save("RESULT.json", result)
    print(json.dumps({"run_id": RUN_ID, "result": receipt, "get_attempts": len(observations),
                      "http_statuses": [x.get("http_status") for x in observations],
                      "original_provider_final_status": "UNKNOWN"}), flush=True)


if __name__ == "__main__":
    main()
