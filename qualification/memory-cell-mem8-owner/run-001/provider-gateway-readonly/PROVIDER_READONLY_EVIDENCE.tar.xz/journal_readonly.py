#!/usr/bin/env python3
"""One bounded metadata-only read of the original provider time window."""
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import signal
import subprocess
import time
from datetime import datetime, timezone

RUN_ID = "mem8-provider-journal-ai395-20261111-ed353-v1"
ROOT = Path("/home/qq/mem8-provider-journal-readonly-20261111-ed353-v1")
UNIT = "dual-llm-gateway.service"
SINCE = "2026-11-11 04:47:00 UTC"
UNTIL = "2026-11-11 04:49:00 UTC"
IDS = {
    "thread": "01a1c8ef-125f-75ae-aaf1-0fe5a4c079f6",
    "turn": "01a1c8ef-1fbd-75b0-bc6e-2b22a1f1f596",
    "client_key": "qualification-e2e-message:Integer(2)",
}
PROPS = ["Id", "FragmentPath", "DropInPaths", "StandardOutput", "StandardError",
         "SyslogIdentifier", "LogNamespace", "LogsDirectory", "ActiveState", "SubState"]


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(b):
    return hashlib.sha256(b).hexdigest()


def write(name, value):
    b = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    fd = os.open(ROOT / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(b)
    return {"path": str(ROOT / name), "bytes": len(b), "sha256": digest(b)}


def bounded(argv, timeout, stdout_cap):
    started = utc()
    child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             stdin=subprocess.DEVNULL, start_new_session=True)
    selector = selectors.DefaultSelector()
    streams = {"stdout": bytearray(), "stderr": bytearray()}
    for name, pipe in [("stdout", child.stdout), ("stderr", child.stderr)]:
        os.set_blocking(pipe.fileno(), False)
        selector.register(pipe, selectors.EVENT_READ, name)
    deadline = time.monotonic() + timeout
    stop_reason = None
    try:
        while selector.get_map():
            if time.monotonic() >= deadline:
                stop_reason = "bounded_timeout"
                break
            for key, _ in selector.select(min(0.2, max(0, deadline - time.monotonic()))):
                data = os.read(key.fileobj.fileno(), 65536)
                if not data:
                    selector.unregister(key.fileobj)
                    continue
                name = key.data
                cap = stdout_cap if name == "stdout" else 16384
                room = cap - len(streams[name])
                streams[name].extend(data[:room])
                if len(data) > room:
                    stop_reason = name + "_byte_cap"
                    break
            if stop_reason:
                break
    finally:
        selector.close()
        if stop_reason or child.poll() is None:
            # Only this script's journalctl/systemctl child, never the service.
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
        try:
            code = child.wait(timeout=1)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait(timeout=1)
        child.stdout.close()
        child.stderr.close()
    out = bytes(streams["stdout"])
    err = bytes(streams["stderr"])
    meta = {"argv": argv, "started_at": started, "finished_at": utc(),
            "exit_code": code, "stop_reason": stop_reason,
            "stdout_bytes": len(out), "stdout_sha256": digest(out),
            "stderr_bytes": len(err), "stderr_sha256": digest(err),
            "raw_stdout_persisted": False, "raw_stderr_persisted": False}
    return out, meta


def safe_record(record):
    message = record.get("MESSAGE")
    if not isinstance(message, str):
        return None
    matched = {}
    for key, value in IDS.items():
        if re.search(r"(?<![A-Za-z0-9_-])" + re.escape(value) + r"(?![A-Za-z0-9_-])", message):
            matched[key] = value
    if not matched:
        return None
    result = {"matched_original_identifiers": matched,
              "exact_thread_or_turn_match": bool(set(matched) & {"thread", "turn"}),
              "client_key_alone_proves_unique_request_identity": False,
              "message_bytes": len(message.encode()), "message_sha256": digest(message.encode()),
              "raw_message_persisted": False}
    timestamp = record.get("__REALTIME_TIMESTAMP")
    if isinstance(timestamp, str) and timestamp.isdigit():
        result["journal_realtime_utc"] = datetime.fromtimestamp(int(timestamp) / 1e6, timezone.utc).isoformat()
    for key in ["_PID", "PRIORITY"]:
        value = record.get(key)
        if isinstance(value, str) and value.isdigit():
            result[key] = value
    try:
        data = json.loads(message)
    except (ValueError, TypeError):
        data = None
    if isinstance(data, dict):
        safe = {}
        for key in ["status", "status_code", "http_status"]:
            value = data.get(key)
            if isinstance(value, int) and not isinstance(value, bool) and 100 <= value <= 599:
                safe[key] = value
        for key in ["type", "event"]:
            value = data.get(key)
            if value in ["response.created", "response.completed", "response.failed", "response.cancelled",
                         "request.started", "request.completed", "request.failed", "timeout"]:
                safe[key] = value
        if data.get("method") in ["GET", "POST"]:
            safe["method"] = data["method"]
        if data.get("path") in ["/v1/responses", "/v1/chat/completions", "/v1/completions"]:
            safe["path"] = data["path"]
        result["allowlisted_structured_fields"] = safe
    return result


def main():
    ROOT.mkdir(mode=0o700, exist_ok=False)
    started = utc()
    write("INTENT.json", {"run_id": RUN_ID, "started_at": started, "unit": UNIT,
                         "since": SINCE, "until": UNTIL, "original_identifiers": IDS,
                         "service_changes": False, "model_requests": 0, "raw_log_publication": False})
    result = {"schema": "hepta.mem8.provider-original-journal-readonly.v1", "run_id": RUN_ID,
              "started_at": started, "unit": UNIT, "window_utc": {"since": SINCE, "until": UNTIL},
              "original_identifiers": IDS, "original_provider_final_status": "UNKNOWN",
              "time_proximity_is_request_identity": False, "service_changes": False,
              "model_requests": 0, "journal_queries": 0}
    try:
        command = ["systemctl", "--user", "show", UNIT, "--no-pager"]
        command.extend("--property=" + p for p in PROPS)
        raw, meta = bounded(command, 8, 65536)
        props = {}
        for line in raw.decode("utf-8", "replace").splitlines():
            key, sep, value = line.partition("=")
            if sep and key in PROPS:
                props[key] = value
        result["current_unit_log_destination"] = {"properties": props, "command_receipt": meta,
                                                   "historical_configuration_proven": False}
        write("LOG_DESTINATION.json", result["current_unit_log_destination"])
        if meta["exit_code"] != 0 or meta["stop_reason"]:
            result["journal_read_status"] = "NOT_READ_LOG_DESTINATION_UNCONFIRMED"
        elif any(props.get(key, "").startswith("journal") for key in ["StandardOutput", "StandardError"]):
            command = ["journalctl", "--user", "--unit=" + UNIT, "--since=" + SINCE,
                       "--until=" + UNTIL, "--output=json", "--no-pager", "--all", "--quiet", "--lines=2000"]
            raw, meta = bounded(command, 12, 4 * 1024 * 1024)
            result["journal_queries"] = 1
            result["journal_command_receipt"] = meta
            matches = []
            parsed = invalid = 0
            for line in raw.splitlines():
                try:
                    record = json.loads(line)
                except ValueError:
                    invalid += 1
                    continue
                if not isinstance(record, dict):
                    invalid += 1
                    continue
                parsed += 1
                projection = safe_record(record)
                if projection is not None:
                    matches.append(projection)
            result.update({"journal_entries_parsed": parsed, "invalid_record_count": invalid,
                           "entry_limit_may_have_truncated_window": parsed >= 2000,
                           "exact_identifier_match_count": len(matches), "matched_records": matches,
                           "nonmatching_records_and_credentials_disclosed": False,
                           "journal_read_status": "BOUNDED_READ_COMPLETE" if meta["exit_code"] == 0 and not meta["stop_reason"] and not invalid and parsed < 2000 else "BOUNDED_READ_INCOMPLETE"})
        else:
            result["journal_read_status"] = "NOT_READ_NON_JOURNAL_DESTINATION"
    except Exception as exc:
        result["diagnostic_exception_type"] = type(exc).__name__
        result["journal_read_status"] = "DIAGNOSTIC_INCOMPLETE"
    result["finished_at"] = utc()
    result["boundary"] = "Only exact original identifiers were projected. Missing matches do not establish provider completion, failure, or nonexecution. Current unit metadata is not proof of the historical configuration."
    receipt = write("RESULT.json", result)
    print(json.dumps({"run_id": RUN_ID, "result": receipt, "journal_queries": result["journal_queries"],
                      "journal_read_status": result.get("journal_read_status"),
                      "exact_identifier_match_count": result.get("exact_identifier_match_count"),
                      "original_provider_final_status": "UNKNOWN"}), flush=True)


if __name__ == "__main__":
    main()
