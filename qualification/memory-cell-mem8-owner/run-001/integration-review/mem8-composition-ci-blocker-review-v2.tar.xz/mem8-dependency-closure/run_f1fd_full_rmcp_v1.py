from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import traceback
import xml.etree.ElementTree as ET

TASK = Path(__file__).resolve().parent
RECORDS = TASK / 'records'
SOURCE = Path('/home/qian-qi/mem8-matrix-diagnostic-ed353817-v1/source')
TARGET = Path('/home/qian-qi/mem8-dependency-validation-ed353817-v2/target')
HEAD = 'f1fd544b3e12ed6aca83872cdeda8114a1e058c0'
TREE = 'fff40d06312d4f6a185772cd8a62a618d55f31cf'
BASE = '96038ccf0660154fac143ba6cbe4be81e00813e8'
EXPECTED = [tuple(row) for row in json.loads((TASK / 'EXPECTED_CASE_IDS.json').read_text())]
ENV = {**os.environ, 'PATH': '/home/qian-qi/.cargo/bin:/home/qian-qi/.local/bin:' + os.environ.get('PATH', ''), 'RUSTUP_TOOLCHAIN': '1.96.0', 'CARGO_TARGET_DIR': str(TARGET), 'CARGO_BUILD_JOBS': '4', 'PYTHONDONTWRITEBYTECODE': '1', 'RUST_BACKTRACE': '1', 'TMPDIR': '/tmp', 'SOURCE_SHA': HEAD, 'TESTED_SHA': HEAD, 'BASE_SHA': BASE, 'HEPTA_CI_LANE': 'source-head'}


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as handle:
        while chunk := handle.read(1024 * 1024):
            value.update(chunk)
    return value.hexdigest()


def save(name, value):
    with (RECORDS / name).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')


def git(*arguments):
    return subprocess.check_output(['git', '-C', str(SOURCE), *arguments], env=ENV)


def identity():
    return {'commit': git('rev-parse', 'HEAD').decode().strip(), 'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(), 'dirty': bool(git('status', '--porcelain=v1').strip()), 'cargo_lock_sha256': sha(SOURCE / 'codex-rs/Cargo.lock'), 'bazel_lock_sha256': sha(SOURCE / 'MODULE.bazel.lock')}


def phase(name, command, test=False, extra=None):
    before = identity()
    assert before['commit'] == HEAD and before['tree'] == TREE and not before['dirty']
    junit_path = SOURCE / 'codex-rs/target/nextest/local/junit.xml'
    previous = (junit_path.stat().st_mtime_ns, sha(junit_path)) if junit_path.exists() else None
    receipt_path = RECORDS / (name + '.json')
    wrapper = [sys.executable, '-B', str(SOURCE / 'scripts/hepta_ci_exec.py'), '--output', str(receipt_path), '--minimum-tests', '268' if test else '0', '--timeout-seconds', '1800', '--', *command]
    print('MEM8_F1FD_FULL_RMCP_PHASE_START ' + json.dumps({'name': name, 'source': before, 'command': command, 'started_at': now(), 'command_budget_seconds': 1800}), flush=True)
    with (RECORDS / (name + '.wrapper.stdout.log')).open('xb') as stdout, (RECORDS / (name + '.wrapper.stderr.log')).open('xb') as stderr:
        completed = subprocess.run(wrapper, cwd=SOURCE / 'codex-rs', env={**ENV, **(extra or {})}, stdout=stdout, stderr=stderr)
    receipt = json.loads(receipt_path.read_text())
    raw = (RECORDS / receipt['log_file']).read_bytes()
    assert len(raw) == receipt['log_bytes'] and hashlib.sha256(raw).hexdigest() == receipt['log_sha256']
    text = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode())
    after = identity()
    audit = {'before': before, 'after': after, 'command': command, 'wrapper_exit_code': completed.returncode, 'receipt_status': receipt['status'], 'command_exit_code': receipt.get('command_exit_code'), 'log_bytes': len(raw), 'log_sha256': receipt['log_sha256'], 'observed_passed': receipt.get('observed_passed_tests', 0), 'observed_failed': receipt.get('observed_failed_tests', 0), 'summary_lines': re.findall(r'Summary[^\n]+', text), 'command_budget_seconds': 1800}
    current = (junit_path.stat().st_mtime_ns, sha(junit_path)) if junit_path.exists() else None
    if test and current is not None and current != previous:
        data = junit_path.read_bytes()
        (RECORDS / (name + '.junit.xml')).write_bytes(data)
        doc = ET.fromstring(data)
        cases = list(doc.iter('testcase'))
        ids = [(case.get('classname'), case.get('name')) for case in cases]
        failures = [(case.get('classname'), case.get('name')) for case in cases if case.find('failure') is not None or case.find('error') is not None]
        skipped = [(case.get('classname'), case.get('name')) for case in cases if case.find('skipped') is not None]
        audit['junit'] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'run_id': doc.get('uuid'), 'ids': ids, 'failures': failures, 'skipped': skipped, 'duplicate_ids': len(ids) - len(set(ids)), 'raw_run_id_matches': 'Nextest run ID ' + doc.get('uuid') in text, 'matches_original_268_unique_case_ids': sorted(ids) == EXPECTED}
    passed = completed.returncode == 0 and receipt['status'] == 'passed' and before == after and not receipt.get('timed_out') and not receipt.get('output_limit_exceeded')
    if test:
        junit = audit.get('junit', {})
        passed = passed and junit.get('matches_original_268_unique_case_ids') and junit.get('raw_run_id_matches') and not junit.get('duplicate_ids') and not junit.get('failures') and not junit.get('skipped') and audit['observed_passed'] == 268 and audit['observed_failed'] == 0
        summary = re.findall(r'Summary\s+\[[^]]+\]\s+268 tests run:\s+268 passed,\s+7 skipped', text)
        passed = passed and len(summary) == 1
    audit['gate_passed'] = bool(passed)
    save(name + '.audit.json', audit)
    if after != before:
        (RECORDS / (name + '.source.diff')).write_bytes(git('diff', '--binary', HEAD))
        (RECORDS / (name + '.source.status')).write_bytes(git('status', '--porcelain=v1'))
    print('MEM8_F1FD_FULL_RMCP_PHASE_RESULT ' + json.dumps({key: value for key, value in audit.items() if key != 'junit'}, sort_keys=True), flush=True)
    return audit


def main():
    os.umask(0o077)
    RECORDS.mkdir(mode=0o700)
    source = identity()
    assert source['commit'] == HEAD and source['tree'] == TREE and not source['dirty']
    assert len(EXPECTED) == len(set(EXPECTED)) == 268 and EXPECTED == sorted(EXPECTED)
    materialized = []
    for relative in ('docs/modules/MODULES.json', 'qualification/neuron-v13-generation/proposal_worker.py'):
        entry = git('ls-tree', HEAD, '--', relative).decode().strip()
        metadata, observed = entry.split('\t', 1)
        mode, kind, blob = metadata.split()
        assert observed == relative and kind == 'blob'
        raw = git('show', HEAD + ':' + relative)
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == blob
        path = SOURCE / relative
        existed = path.is_file()
        if not existed:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
            path.chmod(int(mode, 8) & 0o777)
        assert path.read_bytes() == raw
        materialized.append({'path': relative, 'blob': blob, 'mode': mode, 'already_present': existed})
    assert identity() == source
    save('INPUT.json', {'source': source, 'base': BASE, 'publication_branch': 'codex/mem8-dependency-f1fd544b-20261111-ed353817', 'expected_unique_selected_cases': 268, 'expected_filtered_or_ignored_cases': 7, 'expected_case_ids_sha256': sha(TASK / 'EXPECTED_CASE_IDS.json'), 'original_case_id_source_run': 'c6520272-0490-4d9f-bee4-5d08be7198bd', 'materialized_exact_head_files': materialized, 'format_evidence_reused': 'exact f1fd Matrix production v4 format/clean receipt; no source change since', 'command_budget_seconds_per_phase': 1800, 'retries': 0, 'model_requests_requested': False, 'started_at': now(), 'free_bytes_before': os.statvfs(TASK).f_bavail * os.statvfs(TASK).f_frsize})
    built = phase('same-source-codex-cli-build', ['cargo', 'build', '--locked', '-p', 'codex-cli', '--bin', 'codex'])
    assert built['gate_passed'], 'f1fd CLI build did not qualify; tests not launched'
    binary = TARGET / 'debug/codex'
    assert binary.is_file() and os.access(binary, os.X_OK)
    before_binary = {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': sha(binary), 'source': identity(), 'build_receipt': 'same-source-codex-cli-build.json'}
    save('CLI_BEFORE_TESTS.json', before_binary)
    command = ['just', 'test', '--locked', '-p', 'codex-rmcp-client', '--test-threads', '2', '--no-tests', 'fail', '--retries', '0']
    tested = phase('full-rmcp-268', command, test=True, extra={'CARGO_BIN_EXE_codex': str(binary), 'NEXTEST_BIN_EXE_codex': str(binary)})
    after_binary = {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': sha(binary), 'source': identity()}
    save('CLI_AFTER_TESTS.json', after_binary)
    assert after_binary['sha256'] == before_binary['sha256'] and after_binary['bytes'] == before_binary['bytes'], 'CLI changed during full consumer tests'
    assert tested['gate_passed'], 'original full RMCP suite did not qualify; preserve output and stop before fix'
    fixed = phase('scoped-rmcp-fix', ['just', 'fix', '--locked', '-p', 'codex-rmcp-client'])
    result = {'source': identity(), 'built': built['gate_passed'], 'full_rmcp_268_passed': tested['gate_passed'], 'scoped_fix_passed_clean': fixed['gate_passed'], 'cli_hash_unchanged_during_tests': True, 'qualification_passed': bool(built['gate_passed'] and tested['gate_passed'] and fixed['gate_passed']), 'whole_ci_pass_claimed': False, 'memory_benefit_claimed': False, 'finished_at': now()}
    save('RESULT.json', result)
    print('MEM8_F1FD_FULL_RMCP_RESULT ' + json.dumps(result, sort_keys=True), flush=True)
    assert result['qualification_passed'], 'scoped fix changed source or failed; preserve original output, do not test a dirty tree'


if __name__ == '__main__':
    try:
        main()
    except Exception:
        failure = traceback.format_exc()
        if RECORDS.exists():
            with (RECORDS / 'DRIVER_FAILURE.txt').open('x') as handle:
                handle.write(failure)
        print(failure, flush=True)
        raise
