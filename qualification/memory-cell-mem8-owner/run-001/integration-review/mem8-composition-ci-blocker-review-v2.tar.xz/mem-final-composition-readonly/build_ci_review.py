from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import re

import yaml

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'ci-source'
HEAD = '2ae5215beaf8d7b7df111a090b82134beae2683d'
BASE = '96038ccf0660154fac143ba6cbe4be81e00813e8'
TREE = '12159640adcf073b51f3837e75575e11f5c20233'
BRANCH = 'codex/mem8-integrated-source-20261111-ed353817'
BASE_BRANCH = 'codex/mem8-common-source-20261111-ed353817'


def read_json(name):
    return json.loads((ROOT / name).read_text())


def write_json(name, value):
    path = ROOT / name
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def glob_match(value, pattern):
    # Patterns in the inspected event lists use only *, **, ?, and literals.
    if any(token in pattern for token in '[]{}+'):
        raise ValueError(f'Unreviewed trigger pattern: {pattern}')
    expr = ''
    index = 0
    while index < len(pattern):
        if pattern[index:index + 3] == '**/':
            expr += '(?:.*/)?'
            index += 3
        elif pattern[index:index + 2] == '**':
            expr += '.*'
            index += 2
        elif pattern[index] == '*':
            expr += '[^/]*'
            index += 1
        elif pattern[index] == '?':
            expr += '[^/]'
            index += 1
        else:
            expr += re.escape(pattern[index])
            index += 1
    return re.fullmatch(expr, value) is not None


def selected(value, patterns):
    result = False
    for pattern in patterns:
        exclude = pattern.startswith('!')
        if glob_match(value, pattern[1:] if exclude else pattern):
            result = not exclude
    return result


def event_match(event_name, config, paths):
    config = config or {}
    if not isinstance(config, dict):
        raise ValueError(config)
    branch = BASE_BRANCH if event_name.startswith('pull_request') else BRANCH
    if event_name == 'push' and 'tags' in config and 'branches' not in config:
        return False, [], 'tag-only push'
    if 'branches' in config and not selected(branch, config['branches']):
        return False, [], 'branch filter'
    if 'branches-ignore' in config and selected(branch, config['branches-ignore']):
        return False, [], 'branch-ignore filter'
    matches = [p for p in paths if selected(p, config.get('paths', ['**']))]
    if 'paths-ignore' in config:
        matches = [p for p in matches if not selected(p, config['paths-ignore'])]
    if not matches:
        return False, [], 'path filter'
    return True, matches, 'static event/path match; job conditions remain explicit'


def summary_job(job_id, job):
    return {
        'id': job_id,
        'name': job.get('name', job_id),
        'if': job.get('if'),
        'needs': job.get('needs'),
        'runs_on': job.get('runs-on'),
        'timeout_minutes': job.get('timeout-minutes'),
        'permissions': job.get('permissions'),
        'uses': job.get('uses'),
        'matrix': job.get('strategy', {}).get('matrix'),
        'with': job.get('with'),
        'test_and_feature_command_lines': [
            {'step': step.get('name'), 'if': step.get('if'), 'line': line.strip()}
            for step in job.get('steps', [])
            for line in step.get('run', '').splitlines()
            if any(token in line for token in (
                'just test', 'cargo test', 'cargo clippy', '--features',
                '--all-features', '--run-ignored', '--ignored', '--no-default-features',
                'windows_current_ci.py', 'bazel_targets', 'bazel-lock-update',
                '--test_tag_filters', 'check_ci_results.py',
            ))
        ],
    }


plan = read_json('GIT_TREE_PLAN.json')
paths = [item['path'] for item in plan['tree_elements']]
assert len(paths) == len(set(paths)) == 112
capsule = read_json('WORKFLOW_SOURCE_CAPSULE.json')
workflow_files = capsule['files']
documents = {}
auto = []
event_inventory = {}
for entry in workflow_files:
    path = entry['path']
    raw = entry['content'].encode()
    assert hashlib.sha256(raw).hexdigest() == entry['sha256']
    assert hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest() == entry['git_blob_sha']
    assert (SOURCE / path).read_bytes() == raw
    if not path.endswith(('.yaml', '.yml')):
        continue
    data = yaml.load(entry['content'], Loader=yaml.BaseLoader)
    events = data.get('on', {})
    if isinstance(events, str):
        events = {events: {}}
    elif isinstance(events, list):
        events = {event: {} for event in events}
    event_inventory[path] = list(events)
    documents[path] = (entry, data, events)
    for event in ('push', 'pull_request', 'pull_request_target'):
        if event not in events:
            continue
        match, matched_paths, reason = event_match(event, events[event], paths)
        auto.append({
            'path': path, 'git_blob_sha': entry['git_blob_sha'],
            'name': data.get('name'), 'event': event,
            'event_configuration': events[event], 'matches': match,
            'matched_paths': matched_paths, 'reason': reason,
            'permissions': data.get('permissions'),
            'jobs': [summary_job(k, v) for k, v in data.get('jobs', {}).items()] if match else [],
        })

matched = [row for row in auto if row['matches']]
assert not [row for row in matched if row['event'] == 'push']
assert len([row for row in matched if row['event'] == 'pull_request']) == 11
assert len([row for row in matched if row['event'] == 'pull_request_target']) == 1
assert not [path for path, events in event_inventory.items() if set(events) & {'workflow_run', 'create'}]

scope_spec = importlib.util.spec_from_file_location('ci_scope_review', SOURCE / 'scripts/hepta_ci_scope.py')
scope_module = importlib.util.module_from_spec(scope_spec)
scope_spec.loader.exec_module(scope_module)
scope = scope_module.select(paths)
assert all(scope.values())

reusable_paths = set()
pending = [row['path'] for row in matched]
while pending:
    path = pending.pop()
    for job in documents[path][1].get('jobs', {}).values():
        child = job.get('uses', '')
        if child.startswith('./.github/workflows/'):
            child = child[2:]
            if child not in reusable_paths:
                reusable_paths.add(child)
                pending.append(child)
reusables = []
for path in sorted(reusable_paths):
    entry, data, events = documents[path]
    reusables.append({
        'path': path, 'git_blob_sha': entry['git_blob_sha'], 'name': data.get('name'),
        'events': events, 'permissions': data.get('permissions'),
        'jobs': [summary_job(k, v) for k, v in data.get('jobs', {}).items()],
    })

main_files = {x['path']: x for x in read_json('CI_MAIN_WORKFLOW_INVENTORY.json')['files']}
dispatch = []
for path, (entry, data, events) in documents.items():
    if 'workflow_dispatch' in events and (path in reusable_paths or any(row['path'] == path for row in matched)):
        dispatch.append({
            'path': path, 'candidate_declares_dispatch': True,
            'present_on_default_main': path in main_files,
            'default_main_blob': main_files.get(path, {}).get('sha'),
            'candidate_blob': entry['git_blob_sha'],
            'inputs': events['workflow_dispatch'],
            'executed': False,
            'boundary': 'Default-branch registration is a separate prerequisite; no dispatch sent.'
        })

body = {
    'schema': 'mem8-existing-ci-matrix-v1',
    'prepared_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': {'commit': HEAD, 'tree': TREE, 'branch': BRANCH, 'base_commit': BASE,
               'base_branch': BASE_BRANCH, 'pull_request': 5935, 'changed_paths': 112},
    'audit_execution': {'local_metadata_analysis_only': True, 'host_jobs': 0,
                        'native_tests': 0, 'model_requests': 0, 'ref_mutations': 0,
                        'workflow_dispatches': 0, 'reruns': 0, 'cancellations': 0},
    'workflow_source_count': len(documents), 'additional_readme_files': len(workflow_files) - len(documents),
    'branch_protection': {
        'common': {'protected': False, 'required_contexts': [], 'source': 'CI_BRANCH_RULES_READONLY.json'},
        'main': {'protected': True, 'required_contexts': ['CI required', 'Architecture required'],
                 'app_id': 15368, 'enforcement_level': 'non_admins'},
        'rulesets_response': [], 'classic_full_protection_endpoint': '403 integration access denied',
        'limit': 'Branch metadata exposes required contexts; absence of rulesets is not a claim that every administrative protection is absent.'
    },
    'scope_select': {'script_blob': '553bb1f2473f58fce7587c254f817a2c5a45ea09',
                     'method': 'exact pure select(112 paths); no script main/subprocess', 'result': scope},
    'matched_events': matched, 'nonmatching_events': [row for row in auto if not row['matches']],
    'all_event_inventory': event_inventory, 'reusable_call_chain': reusables,
    'required_fan_in': {
        'CI required': {
            'applicable_on_this_diff': ['scope', 'hepta-contract-gate', 'bazel', 'blob-size-policy', 'cargo-deny', 'codespell', 'repo-checks', 'rust-ci', 'sdk'],
            'allowed_skipped_by_existing_policy': ['hepta-scoped', 'lightweight'],
            'required_by_common_branch_protection': False,
            'required_by_main_branch_protection': True,
            'source': '.github/workflows/blocking-ci.yml',
        },
        'Architecture required': {
            'needs': 'qualification', 'lanes': ['source-head', 'base-merge'],
            'scope_groups': ['inference', 'effects', 'lifecycle', 'objective', 'learning'],
            'identical_tree_reuse': 'Existing candidate-tree gate may reuse source-head native result for identical tree; lane/source receipts still required.',
            'required_by_common_branch_protection': False,
            'required_by_main_branch_protection': True,
            'source': '.github/workflows/hepta-architecture-convergence.yml',
        },
    },
    'ignored_provider_boundary': {
        'ordinary_source_blob': '2d86359ec9e488369c47d182ac9d8fc273b9f675',
        'ordinary_case': 'real_agentd_loopback_provider_read_only_smoke',
        'g_source_blob': 'aa0e8fd90b112fe0a4f5eab18bf5dacb76d3a8a7',
        'g_case': 'production_composition::tests::episodic_control::provider::episodic_real_provider_fresh_context_smoke',
        'both_explicitly_ignored': True,
        'matching_ci_enables_these_ignored_cases': False,
        'nextest_wrapper': 'run-nextest.py passes flags through without injecting --run-ignored; just test uses profile local.',
        'bazel': 'Agentd macro supplies no unit/integration extra args; defs defaults to empty args; .bazelrc has no ignored-test opt-in.',
        'existing_other_ignored_command': 'Architecture runs only the named infer-core bounded history/scale test with cargo --ignored; it cannot select Agentd cases.',
        'original_provider_physical_requests': None,
        'original_unknown_turn_may_be_replayed': False,
        'no_global_claim': 'This is a source-selection audit of the real-provider cases and workflow entrypoints, not a measured packet count for unexecuted CI.',
    },
    'side_effect_boundary': {
        'release_or_deployment_auto_event_match': False,
        'workflow_run_or_create_trigger_present': False,
        'existing_ci_effects': ['ephemeral checkout/build/test fixtures', 'Actions logs and artifacts', 'dependency/build caches', 'Bazel/Keyring/UI lock proposal postimages retained as artifacts'],
        'conditional_cla': {
            'event': 'pull_request_target', 'guard': "vars.ENABLE_UPSTREAM_AUTOMATION == 'true'",
            'can_write': ['statuses', 'pull requests', 'cla-signatures branch'],
            'guard_value': 'UNOBSERVED: connector rejected variable endpoint',
            'not_a_model_or_release_job': True,
        },
    },
    'dispatch_definitions': dispatch,
    'dispatch_docs': 'https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#workflow_dispatch',
    'first_observation': 'CI5935_INITIAL_OBSERVATION.json',
    'coverage_boundaries': [
        'The new composition has not inherited native PASS from G, F2, provider or dependency heads.',
        'MEM native-owner minimum-tests=1 is a nonempty gate; final audit must verify the actual 11 memory and 6 nonignored Agentd case identities plus three child markers and complete protocol results.',
        'F2 app-server config cases, qualification-cognitive-write profile, disabled-memory extension and empty native tool-router controls are existing focused checks. Their old-head PASS does not transfer. Inspect actual combined-head Bazel test logs for coverage before adding only the missing focused checks.',
        'Skipped branch-specific schema/HOS2 proposal jobs are expected conditions, not new blockers.',
        'rust-ci-full is dispatch/full-ci-branch/postmerge infrastructure, not an extra automatically required PR matrix for this branch.',
        'Do not change Fence/security/permissions or mark failed/skipped/queued native checks as passing.',
    ],
}
write_json('CI_REQUIRED_MATRIX.json', body)
print(json.dumps({'workflow_yamls': len(documents), 'matched_push': 0,
                  'matched_pr': 11, 'conditional_pr_target': 1,
                  'reusable_workflows': len(reusables), 'scope': scope}, ensure_ascii=False))
