#!/usr/bin/env python3
"""Independently reconstruct the proposed Git tree from original tree objects."""
import copy
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent

def tree_sha(entries):
    rows = sorted(entries, key=lambda x: (x['path'] + ('/' if x['type'] == 'tree' else '')).encode())
    assert len({x['path'] for x in rows}) == len(rows)
    payload = b''
    for row in rows:
        mode = row['mode'].lstrip('0')
        assert mode in ['40000', '100644', '100755', '120000', '160000']
        payload += mode.encode() + b' ' + row['path'].encode() + b'\0' + bytes.fromhex(row['sha'])
    return hashlib.sha1(b'tree ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()

def replay(common, changes):
    dirs = copy.deepcopy(common)
    touched = {''}
    for item in changes:
        parts = item['path'].split('/')
        for n in range(1, len(parts)):
            parent = '/'.join(parts[:n-1])
            child = '/'.join(parts[:n])
            name = parts[n-1]
            entries = dirs[parent]['entries']
            old = next((r for r in entries if r['path'] == name), None)
            if old is None:
                entries.append({'path': name, 'type':'tree', 'mode':'040000', 'sha':'0' * 40})
                dirs[child] = {'entries': []}
            else:
                assert old['type'] == 'tree' and child in dirs, 'missing complete original subtree: ' + child
            touched.add(child)
        directory = '/'.join(parts[:-1])
        entries = dirs[directory]['entries']
        dirs[directory]['entries'] = [x for x in entries if x['path'] != parts[-1]]
        if item['sha'] is not None:
            dirs[directory]['entries'].append({'path':parts[-1], 'type':item['type'], 'mode':item['mode'], 'sha':item['sha']})
    for path in sorted(touched, key=lambda x: len(x.split('/')) if x else 0, reverse=True):
        identity = tree_sha(dirs[path]['entries'])
        if path:
            parent, _, name = path.rpartition('/')
            entry = next(x for x in dirs[parent]['entries'] if x['path'] == name)
            entry['sha'] = identity
        else:
            return identity

def main():
    proof = json.loads((BASE / 'GIT_OBJECT_PROOF.json').read_text())
    plan = json.loads((BASE / 'GIT_TREE_PLAN.json').read_text())
    originals = proof['complete_tree_records']
    count = 0
    for branch, directories in originals.items():
        for path, row in directories.items():
            assert tree_sha(row['entries']) == row['sha'], (branch, path)
            count += 1
    assert count == 73
    comparisons = proof['comparison']
    branch_results = []
    for branch, data in comparisons.items():
        assert data['merge_base'] == plan['base_commit'] and data['behind_by'] == 0
        entries = []
        for change in data['files']:
            assert change['status'] in ['added', 'modified'], change
            parent, _, name = change['path'].rpartition('/')
            actual = next(x for x in originals[branch][parent]['entries'] if x['path'] == name)
            assert actual['sha'] == change['sha']
            entries.append({'path':change['path'], 'sha':actual['sha'], 'type':actual['type'], 'mode':actual['mode']})
        rebuilt = replay(originals['common'], entries)
        assert rebuilt == data['head_tree'] == originals[branch]['']['sha']
        branch_results.append({'branch':branch, 'head':data['head'], 'tree':rebuilt, 'paths':len(entries)})
    combined = plan['tree_elements']
    assert len(combined) == len({x['path'] for x in combined}) == 112
    selected = [comparisons[x]['files'] for x in ['G', 'provider', 'dependency']]
    known = {x['path']:x['sha'] for group in selected for x in group}
    assert len(known) == sum(len(x) for x in selected) == 112
    assert known == {x['path']:x['sha'] for x in combined}
    assert all(x['sha'] for x in combined)
    rebuilt = replay(originals['common'], combined)
    assert rebuilt == plan['expected_tree'] == '12159640adcf073b51f3837e75575e11f5c20233'
    original_windows = {x['path']:x['sha'] for x in comparisons['windows']['files']}
    provider = {x['path']:x['sha'] for x in comparisons['provider']['files']}
    assert len(original_windows) == 7 and all(provider[k] == v for k,v in original_windows.items())
    result = {'schema':'hepta.mem8.final-source-composition.root-tree-audit.v1', 'complete_original_tree_objects_checked':count, 'branch_reconstructions':branch_results, 'changed_files':112, 'pairwise_path_conflicts':0, 'base_commit':plan['base_commit'], 'base_tree':plan['base_tree'], 'reconstructed_final_tree':rebuilt, 'proposed_parents':plan['proposed_parents'], 'windows_seven_postimages_preserved_in_provider':True, 'new_source_logic':False, 'native_execution':False, 'model_execution':False, 'source_composition_only':True, 'passed':True}
    (BASE / 'ROOT_TREE_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__ == '__main__':
    main()
