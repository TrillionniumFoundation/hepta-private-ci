"""Validate one published native source head and preserve exact-source evidence."""

import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time
from datetime import datetime, timezone, timedelta


CONFIG_PATH = Path(sys.argv[1])
CONFIG = json.loads(CONFIG_PATH.read_text())
PARENT = Path('/home/qq/mem8-owner-20261111-ed353817')
ORIGINAL = Path(CONFIG['donor'])
TOOLS = PARENT / 'native-6be-20261111' / 'tools'
assert re.fullmatch(r'native-fresh-[a-z0-9-]+', CONFIG['run_name'])
for name in ['source_sha', 'source_tree', 'base_sha', 'base_tree']:
    assert re.fullmatch(r'[0-9a-f]{40}', CONFIG[name])
HEAD, TREE, BASE = (CONFIG[k] for k in ['source_sha', 'source_tree', 'base_sha'])
RUN = PARENT / CONFIG['run_name']
SOURCE = RUN / 'source'
RECORDS = RUN / 'records'
TARGET = Path(CONFIG.get('target_dir', str(RUN / 'target')))
assert TARGET.is_absolute() and not TARGET.is_symlink() and TARGET.resolve().is_relative_to(PARENT.resolve())
BUDGET_SECONDS = int(CONFIG['phase_budget_seconds'])
assert BUDGET_SECONDS == 2700
STARTED_AT = datetime.now(timezone.utc)
DEADLINE_UTC = STARTED_AT + timedelta(seconds=BUDGET_SECONDS)
DEADLINE = time.monotonic() + BUDGET_SECONDS
PROVIDER_CASE = 'production_composition::tests::episodic_control::provider::episodic_real_provider_fresh_context_smoke'
assert len(CONFIG['tests']) == 1
assert CONFIG['tests'][0]['package'] == 'codex-hepta-agentd'
assert len(CONFIG['tests'][0]['expected_cases']) == len(set(CONFIG['tests'][0]['expected_cases'])) == 6
assert PROVIDER_CASE not in CONFIG['tests'][0]['expected_cases']
assert CONFIG['tests'][0]['filter_expression'] == ' | '.join('test(=' + name + ')' for name in CONFIG['tests'][0]['expected_cases'])
assert CONFIG['provider_test_selected'] is False and CONFIG['provider_requests_authorized'] is False



def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def git(cwd, *args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=cwd).decode().strip()


def identity(cwd):
    return {'head': git(cwd, 'rev-parse', 'HEAD'), 'tree': git(cwd, 'rev-parse', 'HEAD^{tree}'),
            'status': git(cwd, 'status', '--porcelain', '--untracked-files=normal')}


def command(label, args, cwd, environment):
    started = time.monotonic()
    log = RECORDS / (label + '.invocation.log')
    with log.open('xb') as stream:
        remaining = int(DEADLINE - time.monotonic())
        if remaining <= 0:
            raise RuntimeError('G phase deadline exhausted before ' + label)
        timed_out = False
        try:
            result = subprocess.run(args, cwd=cwd, env=environment, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=remaining + 15)
            returncode = result.returncode
        except subprocess.TimeoutExpired:
            returncode = 124
            timed_out = True
        stream.flush()
        os.fsync(stream.fileno())
    data = log.read_bytes()
    write_json(RECORDS / (label + '.invocation.json'), {'command': args, 'cwd': str(cwd),
               'returncode': returncode, 'outer_wrapper_timeout': timed_out, 'elapsed_seconds': time.monotonic() - started,
               'log_file': log.name, 'log_bytes': len(data), 'log_sha256': sha(data)})
    print(json.dumps({'phase': label, 'returncode': returncode, 'outer_wrapper_timeout': timed_out, 'log': str(log)}), flush=True)
    return returncode


def require(label, args, cwd, environment):
    code = command(label, args, cwd, environment)
    if code:
        raise RuntimeError(f'{label} failed with exit {code}; inspect retained command log')


def paths(*args):
    raw = subprocess.check_output(['git', '--no-replace-objects', *args], cwd=SOURCE)
    return [name.decode() for name in raw.split(b'\0') if name]


def snapshot_files(label, names):
    entries = []
    with (RECORDS / (label + '.tar.xz')).open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:xz') as archive:
            for name in sorted(set(names)):
                path = SOURCE / name
                if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(SOURCE.resolve()):
                    raise ValueError('unexpected source entry ' + repr(name))
                data = path.read_bytes()
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
                entries.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                                'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()})
    write_json(RECORDS / (label + '.json'), entries)
    return entries


def exact_command(label, args, environment, expected_cases=None, minimum_tests=0, working_directory=None):
    remaining = int(DEADLINE - time.monotonic())
    if remaining <= 0:
        raise RuntimeError('native run deadline exhausted before ' + label)
    receipt_path = RECORDS / (label + '.json')
    code = command(label, ['python3', str(SOURCE / 'scripts/hepta_ci_exec.py'), '--timeout-seconds', str(remaining),
                           '--minimum-tests', str(minimum_tests), '--output', str(receipt_path),
                           '--', *args], working_directory or SOURCE, environment)
    receipt = json.loads(receipt_path.read_text())
    assert receipt['source_sha'] == receipt['tested_sha'] == HEAD
    assert receipt['base_sha'] == BASE and receipt['lane'] == 'source-head'
    assert receipt['before']['commit'] == HEAD and receipt['before']['tree'] == TREE
    assert not receipt['before']['dirty']
    raw = (RECORDS / receipt['log_file']).read_bytes()
    assert sha(raw) == receipt['log_sha256'] and len(raw) == receipt['log_bytes']
    text = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode('utf-8', errors='replace'))
    case_lines = [line for line in text.splitlines() if re.search(r'\b(PASS|FAIL|SKIP|TIMEOUT)\b', line)]
    passed_rows = re.findall(r'^\s*PASS\s+\[[^\]]+\]\s+(?:\(\s*\d+/\d+\)\s+)?(\S+)\s+(\S+)\s*$', text, flags=re.MULTILINE)
    observed = [name for package, name in passed_rows]
    write_json(RECORDS / (label + '.case-audit.json'), {'expected_cases': expected_cases,
               'observed_pass_cases': observed, 'all_case_lines': case_lines,
               'raw_log_sha256': sha(raw), 'counts_from_receipt': {
                   'passed': receipt['observed_passed_tests'], 'failed': receipt['observed_failed_tests']}})
    if code or receipt['status'] != 'passed' or receipt['exit_code'] or receipt['command_exit_code']:
        raise RuntimeError(f'{label} failed exact-source command gate with exit {code}')
    assert receipt['after'] == receipt['before']
    if expected_cases is not None:
        assert all(package == 'codex-hepta-agentd' for package, name in passed_rows)
        assert receipt['observed_failed_tests'] == 0
        assert PROVIDER_CASE not in observed
    if expected_cases is not None and (sorted(observed) != sorted(expected_cases)
                                      or receipt['observed_passed_tests'] != len(expected_cases)):
        raise RuntimeError(label + ' did not execute exactly the expected named cases')


def main():
    original_before = identity(ORIGINAL)
    assert original_before == {'head': BASE, 'tree': CONFIG['base_tree'], 'status': ''}
    assert shutil.disk_usage(PARENT).free >= 50 * 1024**3
    RUN.mkdir(mode=0o700)
    RECORDS.mkdir()
    write_json(RUN / 'INPUT.json', CONFIG)
    write_json(RUN / 'START.json', {'run_id': CONFIG['run_id'], 'pid': os.getpid(), 'host': 'ai395',
               'source_sha': HEAD, 'source_tree': TREE, 'base_sha': BASE,
               'started_at': STARTED_AT.isoformat(), 'deadline_utc': DEADLINE_UTC.isoformat(), 'original_before': original_before,
               'driver_sha256': sha(Path(__file__).read_bytes()), 'deadline_seconds': BUDGET_SECONDS,
               'not_production_owner_recovery': True, 'memory_package_tests_this_run': False,
               'existing_agentd_controls_expected': 6,
               'purpose': 'G zero-model compile and six existing episodic regressions',
               'provider_requests_authorized': False, 'ignored_provider_case_selected': False})
    environment = os.environ.copy()
    removed = []
    for key in list(environment):
        if (key.startswith(('GIT_TRACE', 'HEPTA_LOCAL_PROVIDER_', 'HEPTA_MEM_CONTEXT_', 'HEPTA_MEM_NATIVE_')) or key in {'GIT_CURL_VERBOSE', 'GITHUB_RUN_ID',
                'GITHUB_RUN_ATTEMPT', 'GITHUB_JOB', 'RUSTY_V8_ARCHIVE', 'RUSTY_V8_SRC_BINDING_PATH',
                'V8_FROM_SOURCE', 'HEPTA_EPISODIC_DRAIN_REGRESSION_CASE', 'CARGO_BIN_EXE_codex'}):
            environment.pop(key)
            removed.append(key)
    dotslash = Path(CONFIG['dotslash']['binary_path'])
    assert dotslash.is_file() and not dotslash.is_symlink()
    assert hashlib.sha256(dotslash.read_bytes()).hexdigest() == CONFIG['dotslash']['binary_sha256']
    assert dotslash.stat().st_size == CONFIG['dotslash']['binary_bytes']
    write_json(RECORDS / 'dotslash-input.json', CONFIG['dotslash'])
    environment.update(PATH=str(dotslash.parent) + ':' + str(TOOLS / 'bin') + ':/home/qq/.cargo/bin:' + environment.get('PATH', ''),
                       CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0',
                       CARGO_PROFILE_TEST_DEBUG='0', CARGO_TARGET_DIR=str(TARGET),
                       CARGO_NET_GIT_FETCH_WITH_CLI='true', PYTHONDONTWRITEBYTECODE='1',
                       CODEX_REPO_ROOT=str(SOURCE), SOURCE_SHA=HEAD, TESTED_SHA=HEAD,
                       BASE_SHA=BASE, HEPTA_CI_LANE='source-head')
    include = Path(CONFIG['bindgen_system_include'])
    assert include.is_absolute() and (include / 'stddef.h').is_file() and (include / 'stdarg.h').is_file()
    compiler_include = subprocess.check_output(['gcc', '-print-file-name=include'], text=True).strip()
    assert Path(compiler_include).resolve() == include.resolve()
    environment['BINDGEN_EXTRA_CLANG_ARGS'] = '-isystem ' + str(include)
    write_json(RECORDS / 'bindgen-include.json', {'path': str(include),
               'configuration_scope': 'this run child environment only',
               'headers': [{'path': str(include / name), 'sha256': sha((include / name).read_bytes())}
                           for name in ['stddef.h', 'stdarg.h']]})
    write_json(RECORDS / 'environment-controls.json', {'removed_names_only': removed,
               'build_jobs': 2, 'provider_enabled_variables': [], 'ignored_provider_case_selected': False, 'debug': 0, 'target_dir': str(TARGET),
               'source_root': str(SOURCE), 'source_sha': HEAD, 'base_sha': BASE,
               'v8': 'repo resolver with inherited override pair/source-build flags removed for this child only',
               'drain': 'outer test launches and verifies commit/revoke/panic children; branch selector unset'})
    status = 'failed'
    failure = None
    completed = []
    cli_evidence = None
    try:
        require('clone-private-source', ['git', 'clone', '--shared', '--no-checkout', str(ORIGINAL), str(SOURCE)], RUN, environment)
        require('fetch-exact-source', ['git', '-c', 'credential.helper=!gh auth git-credential', 'fetch', '--no-tags', 'https://github.com/TrillionniumFoundation/hepta-private-ci.git', HEAD, BASE], SOURCE, environment)
        assert git(SOURCE, 'rev-parse', HEAD + '^{tree}') == TREE
        assert git(SOURCE, 'rev-parse', BASE + '^{tree}') == CONFIG['base_tree']
        require('verify-base-ancestry', ['git', 'merge-base', '--is-ancestor', BASE, HEAD], SOURCE, environment)
        require('checkout-exact-source', ['git', 'checkout', '--detach', HEAD], SOURCE, environment)
        assert identity(ORIGINAL) == original_before
        before = identity(SOURCE)
        assert before == {'head': HEAD, 'tree': TREE, 'status': ''}
        write_json(RECORDS / 'source-before.json', before)
        changed = snapshot_files('changed-source-before', paths('diff', '--name-only', '--diff-filter=ACMRT', '-z', BASE, HEAD))
        expected_sources = {item['path']: item for item in CONFIG['expected_source_files']}
        assert {item['path'] for item in changed} == set(expected_sources)
        for item in changed:
            expected = expected_sources[item['path']]
            assert item['git_blob'] == expected['postimage_git_blob']
            assert item['sha256'] == expected['postimage_sha256'] and item['bytes'] == expected['postimage_bytes']
        require('repo-rules', ['git', 'show', 'HEAD:AGENTS.md'], SOURCE, environment)
        assert git(SOURCE, 'rev-parse', 'HEAD:AGENTS.md') == 'faa57cc0db48123e1011f1eb47692cd3bbbcfc3a'

        (RECORDS / 'proposed.patch').open('xb').write(subprocess.check_output(['git', 'diff', '--binary', BASE, HEAD], cwd=SOURCE))
        for name, args in [('rustc', ['rustc', '--version', '--verbose']), ('rustfmt', ['rustfmt', '--version']),
                           ('nextest', ['cargo', 'nextest', '--version']), ('just', ['just', '--version']),
                           ('dotslash', [str(dotslash), '--version'])]:
            require(name + '-version', args, SOURCE / 'codex-rs', environment)
        assert (RECORDS / 'just-version.invocation.log').read_text().strip() == 'just 1.51.0'
        assert 'rustc 1.96.0 ' in (RECORDS / 'rustc-version.invocation.log').read_text()
        assert (RECORDS / 'dotslash-version.invocation.log').read_text() == CONFIG['dotslash']['version_output']
        exact_command('format', ['just', 'fmt', '--base', BASE], environment)
        completed.append('format')
        v8_file = RECORDS / 'v8-environment.txt'
        v8_file.open('x').close()
        exact_command('v8-inputs', ['python3', 'scripts/hepta_ci_v8.py'], {**environment, 'GITHUB_ENV': str(v8_file)})
        v8 = dict(line.split('=', 1) for line in v8_file.read_text().splitlines())
        assert set(v8) == {'RUSTY_V8_ARCHIVE', 'RUSTY_V8_SRC_BINDING_PATH'}
        v8_evidence = []
        for name, value in v8.items():
            path = Path(value)
            assert path.is_file() and not path.is_symlink()
            data = path.read_bytes()
            v8_evidence.append({'name': name, 'path': value, 'bytes': len(data), 'sha256': sha(data)})
        write_json(RECORDS / 'v8-artifacts.json', v8_evidence)
        environment.update(v8)
        completed.append('v8-inputs')
        exact_command('codex-cli-build', ['cargo', 'build', '--locked', '-p', 'codex-cli', '--bin', 'codex'], environment, working_directory=SOURCE / 'codex-rs')
        completed.append('codex-cli-build')
        cli = TARGET / 'debug' / 'codex'
        assert cli.is_file() and not cli.is_symlink() and cli.resolve().is_relative_to(TARGET.resolve())
        cli_bytes = cli.read_bytes()
        cli_stat = cli.stat()
        cli_evidence = {'path': str(cli), 'bytes': len(cli_bytes), 'sha256': sha(cli_bytes),
                        'device': cli_stat.st_dev, 'inode': cli_stat.st_ino, 'mode': cli_stat.st_mode,
                        'mtime_ns': cli_stat.st_mtime_ns, 'ctime_ns': cli_stat.st_ctime_ns,
                        'source_sha': HEAD, 'source_tree': TREE,
                        'build_receipt': 'codex-cli-build.json', 'source_after_build': identity(SOURCE),
                        'binding': 'CARGO_BIN_EXE_codex; current run child environment only'}
        assert os.access(cli, os.X_OK) and len(cli_bytes) > 0
        write_json(RECORDS / 'codex-binary.json', cli_evidence)
        environment['CARGO_BIN_EXE_codex'] = str(cli)
        for test in CONFIG['tests']:
            label, package, filter_expression = (test[key] for key in ['label', 'package', 'filter_expression'])
            expected = test['expected_cases']
            args = ['just', 'test', '--locked', '-p', package]
            if test.get('features'):
                args += ['--features', ','.join(test['features'])]
            args += ['--lib', '-E', filter_expression, '--no-capture', '--retries', '0', '--test-threads', '1']
            assert '--run-ignored' not in args and PROVIDER_CASE not in filter_expression
            exact_command(label, args, environment, expected_cases=expected, minimum_tests=len(expected))
            if label == 'agentd-tests':
                receipt = json.loads((RECORDS / (label + '.json')).read_text())
                raw = (RECORDS / receipt['log_file']).read_text()
                text = re.sub(r'\x1b\[[0-9;]*m', '', raw)
                markers = re.findall(r'^episodic-drain-case-complete:(commit|revoke|panic)\s*$', text, flags=re.MULTILINE)
                write_json(RECORDS / 'drain-markers.json', {'source_sha': HEAD, 'raw_log_sha256': receipt['log_sha256'],
                           'observed': markers, 'expected': ['commit', 'revoke', 'panic'],
                           'kind': 'actual child marker lines forwarded only after parent exact-marker verification'})
                assert sorted(markers) == ['commit', 'panic', 'revoke'], markers
            assert sha(cli.read_bytes()) == cli_evidence['sha256']
            completed.append(label)
        for package in ['codex-hepta-agentd']:
            exact_command('fix-' + package, ['just', 'fix', '--locked', '-p', package], environment)
            completed.append('fix-' + package)
        assert sha(cli.read_bytes()) == cli_evidence['sha256']
        assert time.monotonic() < DEADLINE, 'G independent deadline exhausted'
        status = 'passed'
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)}
    finally:
        after = identity(SOURCE) if SOURCE.is_dir() else None
        if SOURCE.is_dir():
            write_json(RECORDS / 'source-after.json', after)
            (RECORDS / 'source-rewrites.patch').open('xb').write(subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=SOURCE))
            (RECORDS / 'index-rewrites.patch').open('xb').write(subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=SOURCE))
            snapshot_files('changed-source-after', paths('diff', '--name-only', '--diff-filter=ACMRT', '-z', 'HEAD')
                           + paths('ls-files', '--others', '--exclude-standard', '-z'))
        binary_after = None
        if cli_evidence is not None:
            try:
                binary_after = {'source_sha': HEAD, 'path': str(cli), 'sha256': sha(cli.read_bytes()),
                                'bytes': cli.stat().st_size, 'source': after,
                                'matches_initial': sha(cli.read_bytes()) == cli_evidence['sha256']}
                if not binary_after['matches_initial']:
                    status = 'failed'
            except OSError as binary_error:
                binary_after = {'source_sha': HEAD, 'path': str(cli), 'matches_initial': False,
                                'error': str(binary_error)}
                status = 'failed'
            write_json(RECORDS / 'codex-binary-after.json', binary_after)
        old_after = identity(ORIGINAL)
        if after != {'head': HEAD, 'tree': TREE, 'status': ''} or old_after != original_before:
            status = 'failed'
        write_json(RUN / 'NATIVE_RESULT.json', {'status': status, 'run_id': CONFIG['run_id'],
                   'source_sha': HEAD, 'source_tree': TREE, 'base_sha': BASE, 'completed': completed,
                   'failure': failure, 'source_after': after, 'original_after': old_after, 'binary_after': binary_after,
                   'finished_at': datetime.now(timezone.utc).isoformat(),
                   'scope': 'G zero-model qualification: actual compile plus six exact existing episodic cases and scoped fix; new ignored real-provider case unselected',
                   'started_at': STARTED_AT.isoformat(), 'deadline_utc': DEADLINE_UTC.isoformat(),
                   'provider_requests_authorized': False, 'ignored_provider_case_selected': False})
        shutil.copyfile(Path(__file__), RUN / 'DRIVER.py')
        manifest = []
        for path in sorted([*RUN.iterdir(), *RECORDS.rglob('*')]):
            if path.is_file():
                data = path.read_bytes()
                manifest.append({'path': str(path.relative_to(RUN)), 'bytes': len(data), 'sha256': sha(data)})
        write_json(RUN / 'FILE_MANIFEST.json', manifest)
        archive_path = RUN / 'NATIVE_EVIDENCE.tar.xz'
        with tarfile.open(archive_path, 'x:xz') as archive:
            for item in manifest:
                archive.add(RUN / item['path'], arcname=item['path'], recursive=False)
            archive.add(RUN / 'FILE_MANIFEST.json', arcname='FILE_MANIFEST.json', recursive=False)
        archive_bytes = archive_path.read_bytes()
        print('MEM8_G_NATIVE_TERMINAL ' + json.dumps({'result': str(RUN / 'NATIVE_RESULT.json'),
              'status': status, 'archive': str(archive_path), 'bytes': len(archive_bytes),
              'sha256': sha(archive_bytes), 'source_sha': HEAD, 'deadline_utc': DEADLINE_UTC.isoformat()}), flush=True)
    return 0 if status == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
