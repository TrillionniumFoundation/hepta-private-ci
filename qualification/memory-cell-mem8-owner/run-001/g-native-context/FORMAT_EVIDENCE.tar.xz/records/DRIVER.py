#!/usr/bin/env python3
"""One isolated, source-bound formatter run; no builds or tests."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
import time
import traceback

INPUT = Path(sys.argv[1])
INPUT_BYTES = INPUT.read_bytes()
CONFIG = json.loads(INPUT_BYTES)
ROOT = Path(CONFIG["work_root"])
ROOT.mkdir(mode=0o700, parents=False, exist_ok=False)
RECORDS = ROOT / "records"
RECORDS.mkdir()
SOURCE = ROOT / "source"
ENV = os.environ.copy()
ENV["PATH"] = ":".join(CONFIG["path_prefixes"] + [ENV.get("PATH", "")])
START = time.time()
STEPS = []
result = {
    "schema": "hepta.mem8.actual-formatter.v1",
    "run_id": CONFIG["run_id"],
    "model_calls_run": 0,
    "base_commit": CONFIG["base_commit"],
    "base_tree": CONFIG["base_tree"],
    "format_scope": "four G candidate Rust files after exact F2 HEAD; no inherited-campaign native claim",
    "input_sha256": hashlib.sha256(INPUT_BYTES).hexdigest(),
    "work_root": str(ROOT),
    "started_at_unix": START,
    "builds_run": 0,
    "tests_run": 0,
    "status": "running",
}
def digest(data):
    return hashlib.sha256(data).hexdigest()
def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
def run(label, args, cwd=ROOT, allow=(0,), timeout=1200):
    started = time.time()
    process = subprocess.run(args, cwd=cwd, env=ENV, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, timeout=timeout, check=False)
    log = RECORDS / (label + ".log")
    log.write_bytes(process.stdout)
    record = {"label": label, "command": args, "cwd": str(cwd),
              "exit_code": process.returncode, "started_at_unix": started,
              "elapsed_seconds": time.time() - started, "log": log.name,
              "log_bytes": len(process.stdout), "log_sha256": digest(process.stdout)}
    STEPS.append(record)
    write_json(RECORDS / "STEPS.json", STEPS)
    if allow is not None and process.returncode not in allow:
        raise RuntimeError(f"{label} exited {process.returncode}")
    return process.stdout
def git(label, args, allow=(0,)):
    return run(label, ["git", *args], SOURCE, allow)
try:
    donor_head = run("donor-before-head", ["git", "rev-parse", "HEAD"], CONFIG["donor"]).decode().strip()
    donor_tree = run("donor-before-tree", ["git", "rev-parse", "HEAD^{tree}"], CONFIG["donor"]).decode().strip()
    donor_status = run("donor-before-status", ["git", "status", "--porcelain"], CONFIG["donor"]).decode()
    assert (donor_head, donor_tree, donor_status) == (CONFIG["base_commit"], CONFIG["base_tree"], ""), "exact clean F2 donor required"
    (RECORDS / "INPUT.json").write_bytes(INPUT_BYTES)
    (RECORDS / "DRIVER.py").write_bytes(Path(__file__).read_bytes())
    run("clone", ["git", "clone", "--shared", "--no-checkout", CONFIG["donor"], str(SOURCE)])
    git("checkout", ["checkout", "--detach", CONFIG["base_commit"]])
    head = git("base-head", ["rev-parse", "HEAD"]).decode().strip()
    tree = git("base-tree", ["rev-parse", "HEAD^{tree}"]).decode().strip()
    assert (head, tree) == (CONFIG["base_commit"], CONFIG["base_tree"]), (head, tree)
    assert not git("base-status", ["status", "--porcelain"]).strip(), "base must be clean"

    expected = {}
    for item in CONFIG["files"]:
        relative = PurePosixPath(item["path"])
        assert not relative.is_absolute() and ".." not in relative.parts
        assert relative.parts[0] == "codex-rs"
        target = SOURCE / relative
        before = target.read_bytes() if target.exists() else None
        assert (None if before is None else git_blob(before)) == item["preimage_git_blob"], item["path"]
        content = item["content"].encode()
        assert git_blob(content) == item["postimage_git_blob"], item["path"]
        assert digest(content) == item["postimage_sha256"], item["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        expected[item["path"]] = content
    git("stage-exact-candidate", ["add", "--", *expected])
    staged = set(git("candidate-paths", ["diff", "--cached", "--name-only", "-z"]).decode().rstrip("\0").split("\0"))
    assert staged == set(expected), (staged, set(expected))
    assert not git("candidate-unstaged", ["diff", "--name-only"]).strip()
    result["candidate_index_tree"] = git("candidate-tree", ["write-tree"]).decode().strip()
    git("formatter-source-blobs", ["rev-parse", "HEAD:justfile", "HEAD:scripts/format.py"])
    proposed = git("proposed-patch", ["diff", "--cached", "--binary", "HEAD"])
    (RECORDS / "proposed.patch").write_bytes(proposed)
    version = run("rustc-version", ["rustc", "--version", "--verbose"], SOURCE / "codex-rs")
    assert version.startswith(b"rustc 1.96.0 "), version
    run("rustfmt-version", ["rustfmt", "--version"], SOURCE / "codex-rs")
    version = run("just-version", ["just", "--version"], SOURCE / "codex-rs")
    assert version.strip() == b"just 1.51.0", version
    run("format", ["just", "fmt"], SOURCE / "codex-rs", allow=None)
    format_exit_code = STEPS[-1]["exit_code"]
    rewrites = git("formatter-rewrites", ["diff", "--binary", result["candidate_index_tree"]])
    (RECORDS / "source-rewrites.patch").write_bytes(rewrites)
    changed_output = git("formatter-changed-paths", ["diff", "--name-only", "-z", result["candidate_index_tree"]])
    changed = sorted(set(changed_output.decode().rstrip("\0").split("\0")) - {""})
    result["formatter_changed_paths"] = changed
    result["formatter_paths_outside_candidate"] = sorted(set(changed) - set(expected))
    git("format-whitespace", ["diff", "--check"], allow=None)
    whitespace_exit_code = STEPS[-1]["exit_code"]
    git("final-status", ["status", "--porcelain"])
    final_patch = git("final-candidate-patch", ["diff", "--binary", "HEAD"])
    (RECORDS / "candidate-after-format.patch").write_bytes(final_patch)
    inventory = []
    for path in sorted(set(expected) | set(changed)):
        target = SOURCE / path
        assert target.is_file() and not target.is_symlink(), path
        before = subprocess.run(["git", "show", result["candidate_index_tree"] + ":" + path], cwd=SOURCE, env=ENV,
                                check=True, stdout=subprocess.PIPE).stdout
        after = target.read_bytes()
        for kind, content in [("preimages", before), ("postimages", after)]:
            output = RECORDS / kind / path
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(content)
        inventory.append({
            "path": path, "input_git_blob": git_blob(before), "input_sha256": digest(before),
            "output_git_blob": git_blob(after), "output_sha256": digest(after),
            "output_bytes": len(after), "formatter_changed": before != after,
            "candidate_owned": path in expected,
        })
    write_json(RECORDS / "FILE_MANIFEST.json", inventory)
    with tarfile.open(RECORDS / "format-sources.tar.xz", "x:xz") as archive:
        for kind in ["preimages", "postimages"]:
            for path in sorted((RECORDS / kind).rglob("*")):
                if path.is_file():
                    archive.add(path, arcname=path.relative_to(RECORDS), recursive=False)
    result["formatter_exit_code"] = format_exit_code
    if format_exit_code or whitespace_exit_code:
        raise RuntimeError(f"formatter exit {format_exit_code}; whitespace exit {whitespace_exit_code}")
    assert not result["formatter_paths_outside_candidate"], "formatter changed unowned source"
    assert run("donor-after-head", ["git", "rev-parse", "HEAD"], CONFIG["donor"]).decode().strip() == donor_head
    assert run("donor-after-tree", ["git", "rev-parse", "HEAD^{tree}"], CONFIG["donor"]).decode().strip() == donor_tree
    assert run("donor-after-status", ["git", "status", "--porcelain"], CONFIG["donor"]).decode() == donor_status
    result["status"] = "formatted_source_captured_no_tests"
except BaseException as error:
    result["status"] = "failed"
    result["error"] = f"{type(error).__name__}: {error}"
    (RECORDS / "error.log").write_text(traceback.format_exc())
finally:
    result["finished_at_unix"] = time.time()
    result["elapsed_seconds"] = result["finished_at_unix"] - START
    result["steps"] = STEPS
    result["artifacts"] = []
    for path in sorted(RECORDS.iterdir()):
        if path.is_file() and path.name != "FORMAT_RESULT.json":
            data = path.read_bytes()
            result["artifacts"].append({"path": path.name, "bytes": len(data), "sha256": digest(data)})
    write_json(RECORDS / "FORMAT_RESULT.json", result)
    archive_path = ROOT / "format_evidence.tar.xz"
    with tarfile.open(archive_path, "x:xz") as archive:
        for path in sorted(RECORDS.rglob("*")):
            if path.is_file():
                archive.add(path, arcname=path.relative_to(ROOT), recursive=False)
    archive_bytes = archive_path.read_bytes()
    print(json.dumps({"archive": str(archive_path), "archive_bytes": len(archive_bytes), "archive_sha256": digest(archive_bytes), "status": result["status"], "base": result["base_commit"],
                      "records": str(RECORDS), "changed_paths": result.get("formatter_changed_paths"),
                      "outside_candidate": result.get("formatter_paths_outside_candidate"),
                      "builds": 0, "tests": 0, "error": result.get("error")}), flush=True)
if result["status"] == "failed":
    raise SystemExit(1)

