"""Recheck retained G bytes and local patch replay; never build or call a model."""

import ast
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile


ROOT = Path('/workspace/scratch/ed3538174819')
OUT = ROOT / 'mem-stage-g-static-review'
G = ROOT / 'mem-stage-g-native-context-candidate'
FORMATTED = G / 'formatted'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': digest(data), 'git_blob': blob(data)}


capsule = json.loads((FORMATTED / 'SOURCE_CAPSULE.json').read_text())
assert digest((FORMATTED / 'SOURCE_CAPSULE.json').read_bytes()) == '5cb33e3183ba2e5175751f57f6b115021ced43a6f9c3b545f8f3b795c9c6f964'
assert digest((FORMATTED / 'SOURCE.patch').read_bytes()) == capsule['source_patch_sha256']
assert len((FORMATTED / 'SOURCE.patch').read_bytes()) == capsule['source_patch_bytes']
files = []
with tempfile.TemporaryDirectory(prefix='g-static-replay-', dir=OUT) as temporary:
    replay = Path(temporary)
    for entry in capsule['files']:
        data = (FORMATTED / 'source' / entry['path']).read_bytes()
        assert data == entry['content'].encode()
        assert blob(data) == entry['postimage_git_blob']
        assert digest(data) == entry['postimage_sha256']
        assert len(data) == entry['postimage_bytes']
        archived = G / 'formatter-v1/readback/records/postimages' / entry['path']
        assert archived.read_bytes() == data
        if entry['preimage_git_blob'] is not None:
            before = FORMATTED / 'before' / entry['path']
            assert blob(before.read_bytes()) == entry['preimage_git_blob']
            destination = replay / entry['path']
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(before, destination)
        files.append({key: value for key, value in entry.items() if key != 'content'})
    subprocess.run(['git', 'apply', '--check', str(FORMATTED / 'SOURCE.patch')], cwd=replay, check=True)
    subprocess.run(['git', 'apply', str(FORMATTED / 'SOURCE.patch')], cwd=replay, check=True)
    for entry in capsule['files']:
        assert (replay / entry['path']).read_bytes() == (FORMATTED / 'source' / entry['path']).read_bytes()

archive = G / 'formatter-v1/format_evidence.tar.xz'
assert archive.stat().st_size == 41624
assert digest(archive.read_bytes()) == 'd2fee84f30985c162ef778c9956c033c74f252bef8be5a7c03ae84c290056c14'
records = G / 'formatter-v1/readback/records'
with tarfile.open(archive, 'r:xz') as handle:
    members = handle.getmembers()
    assert len({m.name for m in members}) == len(members) == 43
    for member in members:
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        retained = G / 'formatter-v1/readback' / member.name
        assert retained.read_bytes() == handle.extractfile(member).read()

steps = json.loads((records / 'STEPS.json').read_text())
for step in steps:
    data = (records / step['log']).read_bytes()
    assert len(data) == step['log_bytes'] and digest(data) == step['log_sha256']
result = json.loads((records / 'FORMAT_RESULT.json').read_text())
assert result['builds_run'] == result['tests_run'] == result['model_calls_run'] == 0
assert result['formatter_exit_code'] == 0 and not result['formatter_paths_outside_candidate']
assert result['base_commit'] == capsule['base_commit']
assert (records / 'donor-before-status.log').read_bytes() == (records / 'donor-after-status.log').read_bytes() == b''
assert (records / 'donor-before-head.log').read_bytes() == (records / 'donor-after-head.log').read_bytes()
assert (records / 'donor-before-tree.log').read_bytes() == (records / 'donor-after-tree.log').read_bytes()

driver = ROOT / 'mem-native-g-9d9bdfb-ai395/run_g_native.py'
driver_input = ROOT / 'mem-native-g-9d9bdfb-ai395/INPUT.json'
assert digest(driver.read_bytes()) == 'b7f8d1c69320779f2011a129b2f22517fd72384e294f65994f14ebe9e7686e28'
assert digest(driver_input.read_bytes()) == '55d97444c9a126253d4194a1321f8461ec0c22742991b8254aaebe00c7067de7'
ast.parse(driver.read_text())
config = json.loads(driver_input.read_text())
assert config['source_sha'] == '9d9bdfbaeeec3c618f3fc80e2f663a29c13f4b27'
assert config['base_sha'] == capsule['base_commit']
assert config['expected_source_files'] == files
assert config['provider_test_selected'] is config['provider_requests_authorized'] is False
cases = config['tests'][0]['expected_cases']
assert len(cases) == len(set(cases)) == 6
assert capsule['test_case'] not in cases
assert config['tests'][0]['filter_expression'] == ' | '.join('test(=' + name + ')' for name in cases)

audit = {
    'schema': 'hepta.mem8.g-independent-static-input-audit.v1',
    'verdict': 'NO_MUST_FIX_IDENTIFIED_STATIC_ONLY',
    'head': config['source_sha'], 'tree': config['source_tree'],
    'base': capsule['base_commit'], 'base_tree': capsule['base_tree'],
    'capsule': identity(FORMATTED / 'SOURCE_CAPSULE.json'),
    'source_patch': identity(FORMATTED / 'SOURCE.patch'),
    'exact_four_file_capsule_and_archive_postimages_match': True,
    'source_patch_replayed_from_exact_preimages': True,
    'files': files,
    'formatter_archive': identity(archive),
    'formatter_archive_members_rechecked': len(members),
    'formatter_step_logs_rechecked': len(steps),
    'formatter_only_builds_tests_models': [0, 0, 0],
    'native_driver': identity(driver), 'native_input': identity(driver_input),
    'driver_python_ast': 'parsed',
    'native_expected_cases': cases,
    'new_ignored_provider_case_selected': False,
    'review_executed_native_tests': 0, 'review_model_requests': 0,
    'review_host_probes': 0,
    'limits': ['No Rust compilation result from this static audit.',
               'No original deployed source/owner/independent issuer custody is established.',
               'The ignored provider case remains unexecuted by this review.'],
}
(OUT / 'STATIC_INPUT_AUDIT.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({'status': 'verified', 'files': len(files), 'formatter_members': len(members),
                  'formatter_logs': len(steps), 'native_tests_run': 0, 'model_calls_run': 0}))
