# G native context: independent static review

**Verdict: no must-fix identified in the frozen formatted candidate or its zero-model native driver.** This permits the separately authorized compile and six existing-case validation phase. It is not a Rust compilation result, a provider result, or permission to execute the new ignored provider case.

Reviewed candidate: [PR #5926](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5926), commit `9d9bdfbaeeec3c618f3fc80e2f663a29c13f4b27`, tree `07192603a5164f4b5d4da24e37595be2a0a04777`, on qualified F2 `0c32926cfec58d986477fc72ba3a4787ab75fde9`. This review made no host probe, service action, native execution, or model request and changed no candidate source.

## Exact reviewed bytes

The 56,702-byte formatted capsule has SHA-256 `5cb33e3183ba2e5175751f57f6b115021ced43a6f9c3b545f8f3b795c9c6f964`. Its 27,457-byte patch has SHA-256 `6476fb569f74dfbcaa222cbf2b012ad267779c2306e47e023ee507db7f394dbe`. Local replay from the two exact existing-file preimages produced all four formatted postimages. Each also matches the original formatter archive. The new audit rechecked all 43 archive members and all 26 step-log byte counts and hashes; the formatter itself ran zero builds, tests, and models. Reproduction and full identities are in `verify_static_inputs.py` and `STATIC_INPUT_AUDIT.json`.

All paths below are relative to `codex-rs/hepta-agentd/src/`.

| File | Reviewed postimage Git blob |
| --- | --- |
| `production_composition_fixture.rs` | `af775eb84932c102cb00eb301e4edacd2e3cc6bc` |
| `production_episodic_control_tests.rs` | `1a2f49b93b9c562b9817874652184f06297615a7` |
| `production_episodic_provider_authority.rs` | `a9444c7ed750ff4d8d47260470d445cfd49ab118` |
| `production_episodic_provider_tests.rs` | `aa0e8fd90b112fe0a4f5eab18bf5dacb76d3a8a7` |

## Ownership and compilation-sensitive points

`AgentdConfig::production_writer_host()` returns a cloned `Option<Arc<AgentdProductionWriterHost>>`. The test therefore owns its host reference before consuming `config` with `into_parts()`. That method returns owned identity, registry, and `Arc<File>` values; `_writer_lock` remains a binding through the test scope. This is not a borrowed-host-after-move pattern. The signatures were read from the exact F2 [config source](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-agentd/src/config.rs).

`Fixture` has no custom `Drop` implementation. Its `inputs()` borrows the cut for `ProductionCompositionInputs<'_>`; `attach_production_operation_host(...).await` consumes those inputs and returns no borrowed value. Only after that await does the test move `fixture.directory` into `TempDir::keep()`, and it does not use the partially moved fixture again. Other fields have their normal scope-end destruction. This removes the suspected partial-move and borrow-lifetime issue, but it remains a static conclusion pending the native compiler. See the reviewed [fixture](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/9d9bdfbaeeec3c618f3fc80e2f663a29c13f4b27/codex-rs/hepta-agentd/src/production_composition_fixture.rs) and unchanged [composition entry](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-agentd/src/production_composition.rs).

The new module is nested under the existing production-composition test module, whose parent is Linux-gated. The required dependency imports and public/crate-visible APIs exist in the pinned [Agentd manifest](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-agentd/Cargo.toml) and source modules listed in `SOURCE_REFERENCES.json`. No missing dependency or obvious visibility mismatch was found.

## What the proposed real path would exercise

The ignored [provider test](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/9d9bdfbaeeec3c618f3fc80e2f663a29c13f4b27/codex-rs/hepta-agentd/src/production_episodic_provider_tests.rs) installs a real retained writer fixture, configures the ordinary episodic ingress, imports through ordinary UDS, and runs `AppServerModelDriver` with a fresh durable native request identity. It checks the F2 `ExplicitContextOnly` options and the identity of the retained canonical store. The native client name remains `hepta-infer-worker`; its existing empty tool router is distinct from the ordinary product-smoke client.

The native [App Server driver](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-infer-worker-host/src/native_app_server.rs) reads `CognitiveContext`, encodes it as untrusted additional context, obtains the exact final-use claim, records dispatch, and revalidates the source-bound context immediately before the physical turn-start boundary. G checks two source reads before its fixture grant and another two for final revalidation. Its random nonce is absent from the user prompt and query; the proposed success check requires that nonce in the final output and unchanged canonical cut. These are mechanism checks, not measured unseen-task benefit or captured physical provider payload proof.

The configured `CountedSource` and signing issuer are explicitly synthetic fixtures. The verifier returns a typed, fixture-authorized `SourceDraft` and `MemoryVerification::Verified`; the digest itself does not create that status. The new [issuer](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/9d9bdfbaeeec3c618f3fc80e2f663a29c13f4b27/codex-rs/hepta-agentd/src/production_episodic_provider_authority.rs) binds the exact operation, subject and request, checks the fixture source-read count, and uses its isolated public test identity. It supplies no original deployed source custody or independent production authority.

## Uncertain dispatch and retention

The existing [native run control](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-infer-worker-host/src/native_run_control.rs) reserves the original request before dispatch. A non-reserved request enters cached-result or existing-request reconciliation; it is not dispatched under a new identity. The [recovery path](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-infer-worker-host/src/native_recovery.rs) uses full thread/read and exact original thread, turn, owner generation and request correlations. Its recovery read is not another turn/start.

G creates its intent output directory once and rejects reuse. It keeps the private fixture root and writes `OBSERVED.json` plus the original durable journal observation before propagating the model outcome or assertion error. `RESULT.json` and the completion marker are produced only after all success assertions. A scope guard cancels or aborts its own fixture tasks on failure. That task cleanup does not prove remote-provider cancellation; an unknown physical outcome must stay unknown.

The retained directory and journal are useful evidence, but G does not implement a cold reconstruction of its in-memory fixture source authority or the original deployment. Read linearization and native context revalidation are not an external-effect lease. Host prompt contributors and skills remain outside F2's stated automatic-memory isolation. Those limitations must survive any future success report.

## Zero-model native driver review

Reviewed `run_g_native.py`, SHA-256 `b7f8d1c69320779f2011a129b2f22517fd72384e294f65994f14ebe9e7686e28`, with `INPUT.json`, SHA-256 `55d97444c9a126253d4194a1321f8461ec0c22742991b8254aaebe00c7067de7`. The request identity is `mem8-native-g-9d9bdfb-ai395-20261111-ed353-v1`.

The driver uses a separate clone of the qualified F2 donor, binds all four source postimages, builds a fresh exact-source Codex CLI, and compares the binary hash afterward. It removes provider/context/native run inputs from the child environment, uses exact equality filters for the six existing cases, does not select the new ignored case, sets zero retries and one test thread, and verifies all three actual drain markers. Dirty formatter or scoped-fix output fails qualification. The new 45-minute G budget does not alter the completed owner/F campaign deadline.

The driver was parsed and reviewed, not run by this reviewer. Its ongoing execution and any later raw evidence belong to a separate native result. No result from F2 or the earlier ordinary provider smoke transfers to G.
