import argparse,base64,hashlib,json,os
from pathlib import Path
ROOT=Path(__file__).parent
INDEX=json.loads((ROOT/"ARCHIVE_COMPLETE_INDEX.json").read_bytes())
PARTS=sorted(INDEX["parts"],key=lambda r:r["archive_offset"])
def dig(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def validate(row,raw):
    assert len(raw)==row["bytes"],row["path"]
    assert dig(raw)==row["sha256"],row["path"]
    assert blob(raw)==row["git_blob"],row["path"]
ap=argparse.ArgumentParser()
ap.add_argument("offsets",nargs="*",type=int)
ap.add_argument("--complete",action="store_true")
args=ap.parse_args()
for offset in args.offsets:
    row=next(r for r in PARTS if r["archive_offset"]==offset)
    raw=base64.b64decode("".join((ROOT/"encoded"/f"{offset:012d}.b64").read_text().split()),validate=True)
    validate(row,raw)
    target=ROOT/"parts"/f"{offset:012d}.part"
    target.parent.mkdir(exist_ok=True)
    if target.exists():assert target.read_bytes()==raw
    else:
        with target.open("xb") as f:f.write(raw)
records=[]
for row in PARTS:
    path=ROOT/"parts"/f'{row["archive_offset"]:012d}.part'
    if path.is_file():
        raw=path.read_bytes();validate(row,raw);records.append(row)
result={"schema":"hepta.mem6.github-cloud-byte-copy.v1","source_commit":"e8fd9416a2fd012633c8e29b5090e6cc710145f5","verified_parts":len(records),"verified_bytes":sum(r["bytes"] for r in records),"complete":False}
if args.complete:
    assert len(records)==128
    target=ROOT/"mem6-cas-001.tar.xz"
    if target.exists():
        with target.open("rb") as f:actual=hashlib.file_digest(f,"sha256").hexdigest()
        assert target.stat().st_size==61412948 and actual==INDEX["whole_archive_sha256"]
    else:
        cursor=0;whole=hashlib.sha256()
        with target.open("xb") as out:
            for row in records:
                assert row["archive_offset"]==cursor
                raw=(ROOT/"parts"/f'{cursor:012d}.part').read_bytes()
                validate(row,raw);out.write(raw);whole.update(raw);cursor+=len(raw)
            out.flush();os.fsync(out.fileno())
        actual=whole.hexdigest()
        assert cursor==61412948 and actual==INDEX["whole_archive_sha256"]
    result.update(complete=True,archive=str(target),sha256=actual,actor_reexecuted=False,archived_runtime_executed=False,full_owner_cold_recovery=False,independent_trust_domain=False)
tmp=ROOT/"COPY_STATUS.json.tmp"
tmp.write_text(json.dumps(result,indent=2)+"\n");os.replace(tmp,ROOT/"COPY_STATUS.json")
print(json.dumps(result,sort_keys=True))
