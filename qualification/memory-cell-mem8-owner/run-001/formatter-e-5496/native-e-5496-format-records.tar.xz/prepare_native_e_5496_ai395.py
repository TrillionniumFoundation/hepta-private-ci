"""Create an isolated exact-source worktree and retain native formatter output."""

import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time
from datetime import datetime, timezone


PARENT = Path('/home/qq/mem8-owner-20261111-ed353817')
ORIGINAL = PARENT / 'source'
RUN = PARENT / 'native-e-5496-20261111'
TOOLS = PARENT / 'native-6be-20261111' / 'tools'
SOURCE = RUN / 'source'
HEAD = '5496ff0cf33c116f8b8d458e821b42c71c9ffa67'
TREE = '5a531bbd732f1d9cb75df32b63b67261295e0cb7'
BASE = 'ad5a4ed6d40a2eceac189afaced5d93137724a52'
BASE_TREE = 'e601d41a97fadbee17947805f4ec507453522800'
OLD_HEAD = '96038ccf0660154fac143ba6cbe4be81e00813e8'
OLD_TREE = '1277666f3285cdf006d36478e6f74ddec38e1fe0'
RUN_ID = 'mem8-native-e-5496-format-ai395-20261111-ed353-v1'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def git(cwd, *args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=cwd).decode().strip()


def identity(cwd):
    return {'head': git(cwd, 'rev-parse', 'HEAD'), 'tree': git(cwd, 'rev-parse', 'HEAD^{tree}'),
            'status': git(cwd, 'status', '--porcelain', '--untracked-files=normal')}


def command(label, args, cwd, environment):
    started = time.monotonic()
    log = RUN / 'records' / (label + '.log')
    with log.open('xb') as stream:
        result = subprocess.run(args, cwd=cwd, env=environment, stdout=stream, stderr=subprocess.STDOUT)
        stream.flush()
        os.fsync(stream.fileno())
    data = log.read_bytes()
    record = {'command': args, 'cwd': str(cwd), 'returncode': result.returncode,
              'elapsed_seconds': time.monotonic() - started, 'log_file': log.name,
              'log_bytes': len(data), 'log_sha256': sha(data)}
    write_json(RUN / 'records' / (label + '.command.json'), record)
    print(json.dumps({'phase': label, 'returncode': result.returncode, 'log': str(log)}), flush=True)
    return result.returncode


def require(label, args, cwd, environment):
    code = command(label, args, cwd, environment)
    if code:
        raise RuntimeError(f'{label} failed with exit {code}; inspect retained command log')


def snapshot_files(label, names):
    entries = []
    with tarfile.open(RUN / 'records' / (label + '.tar.xz'), 'w:xz') as archive:
        for name in sorted(set(names)):
            path = SOURCE / name
            if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(SOURCE.resolve()):
                raise ValueError('unexpected source entry ' + repr(name))
            data = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
            entries.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()})
    write_json(RUN / 'records' / (label + '.json'), entries)
    return entries


def paths(*args):
    data = subprocess.check_output(['git', '--no-replace-objects', *args], cwd=SOURCE)
    return [name.decode() for name in data.split(b'\0') if name]


def main():
    original_before = identity(ORIGINAL)
    assert original_before == {'head': OLD_HEAD, 'tree': OLD_TREE, 'status': ''}, original_before
    assert shutil.disk_usage(PARENT).free >= 50 * 1024**3
    RUN.mkdir(mode=0o700)
    (RUN / 'records').mkdir()
    write_json(RUN / 'START.json', {'run_id': RUN_ID, 'pid': os.getpid(), 'host': 'ai395',
               'source_sha': HEAD, 'source_tree': TREE, 'base_sha': BASE,
               'started_at': datetime.now(timezone.utc).isoformat(), 'original_before': original_before,
               'driver_sha256': sha(Path(__file__).read_bytes()), 'new_task_not_native_v4_retry': True})
    environment = os.environ.copy()
    for key in list(environment):
        if key.startswith('GIT_TRACE') or key == 'GIT_CURL_VERBOSE':
            environment.pop(key)
    environment.update(PATH=str(TOOLS / 'bin') + ':/home/qq/.cargo/bin:' + environment.get('PATH', ''),
                       CARGO_BUILD_JOBS='4', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0',
                       CARGO_PROFILE_TEST_DEBUG='0', CARGO_TARGET_DIR=str(RUN / 'target'),
                       CARGO_NET_GIT_FETCH_WITH_CLI='true', PYTHONDONTWRITEBYTECODE='1',
                       SOURCE_SHA=HEAD, TESTED_SHA=HEAD, BASE_SHA=BASE, HEPTA_CI_LANE='source-head')
    try:
        require('fetch-exact-source', ['git', 'fetch', '--no-tags', 'origin', HEAD, BASE], ORIGINAL, environment)
        assert git(ORIGINAL, 'rev-parse', HEAD + '^{tree}') == TREE
        assert git(ORIGINAL, 'rev-parse', BASE + '^{tree}') == BASE_TREE
        require('verify-base-ancestry', ['git', 'merge-base', '--is-ancestor', BASE, HEAD], ORIGINAL, environment)
        require('create-worktree', ['git', 'worktree', 'add', '--detach', str(SOURCE), HEAD], ORIGINAL, environment)
        assert identity(ORIGINAL) == original_before
        before = identity(SOURCE)
        assert before == {'head': HEAD, 'tree': TREE, 'status': ''}, before
        write_json(RUN / 'records' / 'source-before.json', before)
        changed = paths('diff', '--name-only', '--diff-filter=ACMRT', '-z', BASE, HEAD)
        snapshot_files('changed-source-before', changed)
        (RUN / 'records' / 'proposed.patch').write_bytes(subprocess.check_output(
            ['git', 'diff', '--binary', BASE, HEAD], cwd=SOURCE))
        require('rustc-version', ['rustc', '--version', '--verbose'], SOURCE / 'codex-rs', environment)
        require('rustfmt-version', ['rustfmt', '--version'], SOURCE / 'codex-rs', environment)
        require('nextest-version', ['cargo', 'nextest', '--version'], SOURCE / 'codex-rs', environment)
        require('just-version', [str(TOOLS / 'bin' / 'just'), '--version'], RUN, environment)
        assert (RUN / 'records' / 'just-version.log').read_text().strip() == 'just 1.51.0'
        code = command('format-invocation', ['python3', 'scripts/hepta_ci_exec.py', '--timeout-seconds', '1800',
                       '--output', str(RUN / 'records' / 'format.json'), '--', 'just', 'fmt', '--base', BASE],
                       SOURCE, environment)
        after = identity(SOURCE)
        write_json(RUN / 'records' / 'source-after-format.json', after)
        (RUN / 'records' / 'source-rewrites.patch').write_bytes(subprocess.check_output(
            ['git', 'diff', '--binary', 'HEAD'], cwd=SOURCE))
        rewrites = paths('diff', '--name-only', '--diff-filter=ACMRT', '-z', 'HEAD')
        rewrites += paths('ls-files', '--others', '--exclude-standard', '-z')
        entries = snapshot_files('changed-source-after-format', rewrites)
        assert identity(ORIGINAL) == original_before
        write_json(RUN / 'FORMAT_RESULT.json', {'run_id': RUN_ID, 'source_sha': HEAD, 'source_tree': TREE,
                   'base_sha': BASE, 'format_gate_exit_code': code, 'before': before, 'after': after,
                   'changed_files': entries, 'original_after': identity(ORIGINAL), 'tests_run': False,
                   'finished_at': datetime.now(timezone.utc).isoformat()})
        print('MEM8_E_5496_FORMAT_TERMINAL ' + str(RUN / 'FORMAT_RESULT.json'), flush=True)
    except BaseException as error:
        write_json(RUN / 'PREPARE_FAILURE.json', {'run_id': RUN_ID, 'type': type(error).__name__,
                   'error': str(error), 'source_sha': HEAD, 'tests_run': False,
                   'finished_at': datetime.now(timezone.utc).isoformat()})
        raise


if __name__ == '__main__':
    main()
