"""Read public compiler/header metadata after the observed bindgen failure."""
import ctypes.util
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
ROOT=Path('/home/qq/mem8-owner-20261111-ed353817')
output=ROOT/'native-gcc-header-probe-v2-20261111.json'
rows=[]
def probe(args,input=None):
    try:
        r=subprocess.run(args,input=input,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
        v={'command':args,'exit_code':r.returncode,'output':r.stdout.decode(errors='replace')}
    except OSError as e:
        v={'command':args,'error':str(e)}
    rows.append(v)
    return v
r=probe(['gcc','-print-file-name=include'])
assert r['exit_code']==0
inc=Path(r['output'].strip());assert inc.is_absolute()
probe(['gcc','--version'])
clang=[]
for name in ['clang','clang-21','/usr/lib/llvm-21/bin/clang']:
    binary=shutil.which(name)
    if binary and binary not in clang:
        clang.append(binary);probe([binary,'-print-resource-dir']);probe([binary,'--version'])
headers=[]
for name in ['stddef.h','stdarg.h']:
    p=inc/name;b=p.read_bytes()
    headers.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
r=probe(['gcc','-E','-x','c','-','-isystem',str(inc)],b'#include <stddef.h>\n#include <stdarg.h>\n')
assert r['exit_code']==0
directories=[]
for name in ['/usr/lib/llvm-21/lib/clang/21','/usr/lib/clang/21']:
    p=Path(name);h=p/'include/stddef.h'
    directories.append({'path':name,'exists':p.is_dir(),'stddef_header_exists':h.is_file()})
value={'compiler_metadata':rows,'header_files':headers,'clang_executables':clang,
       'clang_resource_dir':'reported above by actual clang driver' if clang else 'unavailable: no clang or clang-21 executable',
       'libclang_21':ctypes.util.find_library('clang-21'),
       'resource_candidates':directories,
       'scope':'Read-only diagnostic. No source, owner or global environment modified.'}
with output.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps({'result':str(output),'include':str(inc),'clang_executables':clang,'libclang_21':value['libclang_21']}))
