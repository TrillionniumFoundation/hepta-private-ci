from __future__ import annotations

import copy
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
OLD = WORK / "mem-stage-formatted-81889"
F = WORK / "mem-stage-f-66f570a/formatted"
NATIVE = WORK / "mem-native-66f570-tools-ai395"
F_NATIVE = WORK / "mem-native-f2-0c32926-ai395"
BASE_HEAD = "ad5a4ed6d40a2eceac189afaced5d93137724a52"
BASE_TREE = "e601d41a97fadbee17947805f4ec507453522800"
CORE_HEAD = "66f570a77c60aac8d33e6cbeac8dfd120ef1d867"
CORE_TREE = "8eaee893e1e6e43423f288fc654e05c3c95f6179"
FINAL_HEAD = "0c32926cfec58d986477fc72ba3a4787ab75fde9"
FINAL_TREE = "0d5aa1544aad103f9099c7c8347d8075d6ecc76e"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def blob(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def info(data: bytes) -> dict:
    return {"bytes": len(data), "sha256": sha(data), "git_blob": blob(data)}


def read_json(path: Path):
    return json.loads(path.read_bytes())


def save(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, ("refuse different existing artifact", path)
    else:
        with path.open("xb") as handle:
            handle.write(data)


def save_json(path: Path, data) -> None:
    save(path, (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode())


def run(args, **kwargs):
    result = subprocess.run(args, capture_output=True, **kwargs)
    assert result.returncode == 0, (args, result.returncode, result.stderr.decode(errors="replace"))
    return result.stdout


def patch_file(path: str, before: bytes | None, after: bytes) -> bytes:
    assert before != after, ("no-op", path)
    with tempfile.TemporaryDirectory(prefix="mem-final-diff-") as directory:
        left, right = Path(directory) / "before", Path(directory) / "after"
        if before is not None:
            left.write_bytes(before)
        right.write_bytes(after)
        result = subprocess.run(
            ["git", "diff", "--no-index", "--no-renames", "--no-ext-diff", "--no-color", "--full-index",
             "--", str(left) if before is not None else "/dev/null", str(right)],
            capture_output=True,
        )
        assert result.returncode == 1, result.stderr
        lines = result.stdout.decode().splitlines(keepends=True)
        lines[0] = f"diff --git a/{path} b/{path}\n"
        for index, line in enumerate(lines):
            if line.startswith("--- "):
                lines[index] = "--- " + (f"a/{path}" if before is not None else "/dev/null") + "\n"
            elif line.startswith("+++ "):
                lines[index] = f"+++ b/{path}\n"
            elif line.startswith("@@"):
                break
        return "".join(lines).encode()


remote = read_json(ROOT / "REMOTE_INPUTS.json")
old = read_json(OLD / "STAGE_MANIFEST.json")
capsule = read_json(OLD / "INPUT_CAPSULE.json")
f_manifest = read_json(F / "PUBLISHED_STAGE_MANIFEST.json")
f_qualified = read_json(F_NATIVE / "NATIVE_QUALIFIED_STAGE_MANIFEST.json")
assert old["base_head"] == BASE_HEAD
assert old["target_head"] == "81889f5e09c247473aa7f20d927bb0eca16c7c48"
assert f_manifest["base_commit"] == CORE_HEAD
assert f_qualified["source_sha"] == FINAL_HEAD and f_qualified["source_tree"] == FINAL_TREE

base = {item["path"]: item["content"].encode() for item in capsule["base_files"]}
historical_final = {item["path"]: item["content"].encode() for item in capsule["target_files"]}
assert len(base) == 17 and len(historical_final) == 30
for item in capsule["base_files"] + capsule["target_files"]:
    assert blob(item["content"].encode()) == item["sha"], item["path"]

archive_bytes = (NATIVE / "published-archive.tar.xz").read_bytes()
assert len(archive_bytes) == 156176
assert sha(archive_bytes) == "7a2f8bc2a4b3ebd8530f1cee179d6b815b5329a5f1c3076f244439042873eab6"
with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:xz") as archive:
    result = json.load(archive.extractfile("NATIVE_RESULT.json"))
    source = json.load(archive.extractfile("records/source-before.json"))
    source_tar = archive.extractfile("records/changed-source-before.tar.xz").read()
    assert archive.extractfile("records/source-rewrites.patch").read() == b""
with tarfile.open(fileobj=io.BytesIO(source_tar), mode="r:xz") as archive:
    core_changed = {}
    for member in archive.getmembers():
        assert member.isfile() and not member.name.startswith("/") and ".." not in Path(member.name).parts
        core_changed[member.name.removeprefix("./")] = archive.extractfile(member).read()
assert len(core_changed) == 28
assert source == {"head": CORE_HEAD, "tree": CORE_TREE, "status": ""}, source
assert set(core_changed) == {item["filename"] for item in remote["comparison_ad5_66f"]["files"]}

for key, path in [
    ("workflow_base", ".github/workflows/hepta-mem-python.yml"),
    ("build_base", "codex-rs/hepta-agentd/BUILD.bazel"),
]:
    item = remote[key]
    assert item["encoding"] == "utf-8"
    data = item["content"].encode()
    assert blob(data) == item["sha"]
    assert path not in base
    base[path] = data
for path in ["codex-rs/hepta-agentd/src/app_runtime.rs", "codex-rs/app-server/src/config_manager.rs"]:
    assert path not in base and path not in core_changed
    base[path] = (F / "base" / path).read_bytes()

fixed_path = "codex-rs/hepta-memory/src/production_episodic_tests.rs"
assert core_changed[fixed_path] == remote["fixed_owner_test"]["content"].encode()
assert blob(core_changed[fixed_path]) == "245dc875742fb5e645859bd1cfe8c370e4189f12"
expected_corrections = {
    fixed_path,
    "codex-rs/hepta-agentd/src/production_episodic_drain_tests.rs",
    "codex-rs/hepta-agentd/BUILD.bazel",
    ".github/workflows/hepta-mem-python.yml",
}
assert expected_corrections == {item["filename"] for item in remote["comparison_81889_66f"]["files"]}
for path, data in historical_final.items():
    if path in core_changed and path not in expected_corrections:
        assert data == core_changed[path], path

stages = []
for original in old["stages"]:
    metadata = {key: copy.deepcopy(original[key]) for key in [
        "id", "behavior", "case_ids", "commands", "expected_cumulative_memory_episodic_tests",
        "expected_cumulative_agentd_episodic_tests",
    ]}
    images = {}
    old_patch = (OLD / "stages" / original["id"] / "SOURCE.patch").read_bytes()
    assert sha(old_patch) == original["patch_sha256"]
    for item in original["files"]:
        data = (OLD / "stages" / original["id"] / "postimages" / item["path"]).read_bytes()
        assert blob(data) == item["postimage_git_blob"] and sha(data) == item["sha256"]
        images[item["path"]] = data
    metadata["images"] = images
    stages.append(metadata)
lookup = {stage["id"]: stage for stage in stages}
lookup["B"]["images"][fixed_path] = core_changed[fixed_path]
lookup["B"]["corrections_from_historical_81889_stack"] = [
    "Use exact c6aa/66f postimage: remove drop(store) after consuming close().await; +0/-1 compared with historical test."
]
for path in sorted(expected_corrections - {fixed_path}):
    lookup["D3"]["images"][path] = core_changed[path]
lookup["D3"]["corrections_from_historical_81889_stack"] = [
    "Use actual 66f formatted drain postimage, including original readiness diagnostic, real cargo-bin Codex CLI, and verified child stdout marker forwarding.",
    "Include unchanged-security-scope Bazel real CLI prerequisite and exact-source CI build/binary binding; no longer use current_exe as Codex CLI."
]
for stage in stages:
    if stage["id"] in ["D3", "E"]:
        stage["commands"] = [
            "cargo build --locked -p codex-cli --bin codex",
            "Bind CARGO_BIN_EXE_codex to this exact-head binary after recording its bytes/SHA256 and executable mode; recheck unchanged binary at completion.",
            "just test --locked -p codex-hepta-agentd --lib episodic --no-capture --retries 0",
        ]
        stage["required_drain_markers"] = ["commit", "revoke", "panic"]

f_case = f_qualified["tests"][0]["case_ids"]
for item in f_manifest["stages"]:
    name = item["name"]
    stages.append({
        "id": name,
        "behavior": (
            "Persist required feature constraints after client request overrides and configuration reload."
            if name == "F1" else
            "Configure retained episodic ingress with explicit-context-only memory paths while preserving the store; enforce source namespace and profile requirements."
        ),
        "images": {file["path"]: (F / name / file["path"]).read_bytes() for file in item["files"]},
        "case_ids": [f_case[0]] if name == "F1" else [
            f_case[1], "app_runtime::tests::episodic_embedding_keeps_the_store_but_removes_implicit_memory_paths",
            "production_composition::tests::episodic_control::episodic_control_replays_original_commit_then_rejects_revoked_context",
        ],
        "commands": [
            "just test --locked -p codex-app-server --lib config_manager::feature_constraints_tests",
        ] + ([] if name == "F1" else [
            "cargo build --locked -p codex-cli --bin codex",
            "Bind fresh exact-head CARGO_BIN_EXE_codex and verify unchanged binary at completion.",
            "just test --locked -p codex-hepta-agentd --lib episodic --no-capture --retries 0",
            "Run the exact qualified profile, memory-extension disabled-state, and empty native-router controls listed in native-evidence/F2_QUALIFIED.json.",
        ]),
        "expected_cumulative_memory_episodic_tests": 11,
        "expected_cumulative_agentd_episodic_tests": 5 if name == "F1" else 6,
        "expected_cumulative_config_manager_feature_tests": 1 if name == "F1" else 2,
        "published_commit": f_manifest["publication"][name]["commit"],
        "published_tree": f_manifest["publication"][name]["tree"],
        "published_parent": f_manifest["publication"][name]["parent"],
        "published_pr": f_manifest["publication"][name]["pr"],
    })

save(ROOT / "historical-inputs/81889_STAGE_MANIFEST.json", (OLD / "STAGE_MANIFEST.json").read_bytes())
save(ROOT / "historical-inputs/F_PUBLISHED_PENDING_STAGE_MANIFEST.json", (F / "PUBLISHED_STAGE_MANIFEST.json").read_bytes())
save(ROOT / "native-evidence/CORE_CLOUD_ARCHIVE_AUDIT.json", (NATIVE / "CLOUD_ARCHIVE_AUDIT.json").read_bytes())
save(ROOT / "native-evidence/F2_QUALIFIED.json", (F_NATIVE / "NATIVE_QUALIFIED_STAGE_MANIFEST.json").read_bytes())
save(ROOT / "native-evidence/F2_AUDIT.json", (F_NATIVE / "NATIVE_AUDIT.json").read_bytes())
for path, data in base.items():
    save(ROOT / "base" / path, data)

manifest = {
    "schema": "hepta.mem8.final-formatted-review-stack.v1",
    "status": "reviewable_reconstruction_no_remote_ref_mutation",
    "base": {"commit": BASE_HEAD, "tree": BASE_TREE, "source_A_pr": 5888},
    "core_target": {"commit": CORE_HEAD, "tree": CORE_TREE, "pr": 5892},
    "final_target": {"commit": FINAL_HEAD, "tree": FINAL_TREE, "pr": 5917},
    "historical_target_not_rewritten": old["target_head"],
    "method": "Preserve previous coherent stage boundaries; replace only four final-source corrections with exact native-run input bytes; append exact published F1/F2 bytes; verify every preimage and replay every full patch sequentially.",
    "validation_boundary": [
        "The reconstructed B/C/D1/D2/D3/E boundaries are not independently compiled or formatted; their existing intermediate-source boundaries remain subject to exact-head normal CI.",
        "Native qualification belongs to published 66f570 and 0c32926 only. Rewriting commit history does not transfer a PASS to a new commit.",
        "F1 behavior ran on F2 combined head; no independent F1 native result is inferred.",
        "This artifact makes no claim of actual original-owner recovery, provider task success, or causal memory benefit.",
    ],
    "base_evidence_files": [{"path": path, **info(data)} for path, data in sorted(base.items())],
    "stages": [],
}
current = dict(base)
with tempfile.TemporaryDirectory(prefix="mem-final-replay-") as directory:
    replay = Path(directory)
    run(["git", "init", "-q"], cwd=replay)
    for path, data in current.items():
        save(replay / path, data)
    run(["git", "add", "--all"], cwd=replay)
    for ordinal, stage in enumerate(stages, start=1):
        before_map = dict(current)
        files, patches = [], []
        for path, after in stage["images"].items():
            before = current.get(path)
            patch = patch_file(path, before, after)
            fields = run(["git", "apply", "--numstat"], input=patch).decode().strip().split("\t", 2)
            assert len(fields) == 3 and fields[2] == path
            added, deleted = int(fields[0]), int(fields[1])
            files.append({
                "path": path, "preimage_git_blob": blob(before) if before is not None else None,
                "postimage_git_blob": blob(after), "preimage_sha256": sha(before) if before is not None else None,
                "postimage_sha256": sha(after), "postimage_bytes": len(after),
                "additions": added, "deletions": deleted,
            })
            if stage["id"] in ["F1", "F2"]:
                frozen = next(item for item in next(s for s in f_manifest["stages"] if s["name"] == stage["id"])["files"] if item["path"] == path)
                assert blob(after) == frozen["postimage_git_blob"]
                assert (blob(before) if before is not None else None) == frozen["preimage_git_blob"]
            save(ROOT / "stages" / stage["id"] / "postimages" / path, after)
            patches.append(patch)
        patch = b"".join(patches)
        patch_path = ROOT / "stages" / stage["id"] / "SOURCE.patch"
        save(patch_path, patch)
        run(["git", "apply", "--index", "--check", str(patch_path)], cwd=replay)
        run(["git", "apply", "--index", str(patch_path)], cwd=replay)
        current.update(stage["images"])
        actual_paths = set(run(["git", "ls-files", "-z"], cwd=replay).decode().rstrip("\0").split("\0"))
        assert actual_paths == set(current)
        for path, data in current.items():
            assert (replay / path).read_bytes() == data, (stage["id"], path)
        metadata = {key: value for key, value in stage.items() if key != "images"}
        metadata.update(
            order=ordinal, requires_stage=stages[ordinal - 2]["id"] if ordinal > 1 else "published_A",
            files=files, additions=sum(f["additions"] for f in files), deletions=sum(f["deletions"] for f in files),
            patch=patch_path.relative_to(ROOT).as_posix(), patch_bytes=len(patch), patch_sha256=sha(patch),
            verified_preimages=len(files), sequential_git_apply="PASS",
            sparse_fixture_tree=run(["git", "write-tree"], cwd=replay).decode().strip(),
            sparse_fixture_tree_is_full_repository_tree=False,
        )
        if stage["id"] == "E":
            expected = dict(base)
            expected.update(historical_final)
            expected.update(core_changed)
            assert current == expected
            observed_changes = {path: data for path, data in current.items() if base.get(path) != data}
            assert observed_changes == core_changed
            metadata["exact_core_checkpoint"] = {"published_commit": CORE_HEAD, "changed_paths": 28, "all_changed_file_bytes_match_native_input": True}
            core_checkpoint = dict(current)
        if stage["id"] == "F2":
            for path in {f["path"] for s in f_manifest["stages"] for f in s["files"]}:
                assert current[path] == (F / "F2" / path).read_bytes(), path
        save_json(ROOT / "stages" / stage["id"] / "MANIFEST.json", metadata)
        manifest["stages"].append(metadata)

assert len(stages) == 8 and len(current) == 35
changed = {path for path, data in current.items() if base.get(path) != data}
expected_changed = set(core_changed) | {item["filename"] for item in remote["comparison_66f_f2"]["files"]}
assert changed == expected_changed and len(changed) == 31
source_a_paths = ["episodic_source.rs", "production_episodic_snapshot.rs", "episodic_source_tests.rs", "lib.rs"]
for name in source_a_paths:
    path = "codex-rs/hepta-memory/src/" + name
    assert current[path] == base[path]
manifest["all_final_changed_paths"] = [{"path": path, **info(current[path])} for path in sorted(changed)]
manifest["final_evidence_paths"] = [{"path": path, **info(data)} for path, data in sorted(current.items())]
manifest["source_A_four_paths_unchanged"] = True
manifest["core_checkpoint_matches_native_input_28_paths"] = True
manifest["final_31_changed_paths_match_published_66f_plus_F1_F2"] = True
manifest["full_repository_tree_reconstruction_executed"] = False
manifest["native_evidence"] = {
    "core_run_id": "mem8-native-66f570-tools-ai395-20261111-ed353-v7",
    "core_archive_blob": "c08c54c653f9602e1f40953a16689e3a6e7994e2",
    "core_archive_sha256": sha(archive_bytes),
    "core_counts": {"memory": 11, "agentd": 5, "protocol": 16, "drain_child_markers": ["commit", "revoke", "panic"]},
    "core_audit": info((NATIVE / "CLOUD_ARCHIVE_AUDIT.json").read_bytes()),
    "f2_run_id": f_qualified["native_run_id"],
    "f2_archive_blob": f_qualified["native_archive_blob"],
    "f2_archive_sha256": f_qualified["native_archive"]["sha256"],
    "f2_audit_blob": f_qualified["native_audit_blob"],
    "f2_native_qualified_manifest_blob": "5dcd1784d6664428ac485862c5afb9bcf54979f1",
    "f2_executions": 11, "f2_distinct_cases": 10,
}
for path, data in current.items():
    save(ROOT / "final-postimages" / path, data)
save_json(ROOT / "STAGE_MANIFEST.json", manifest)
save_json(ROOT / "STAGE_REPLAY_AUDIT.json", {
    "status": "PASS", "stage_count": len(stages), "base_evidence_files": len(base),
    "final_evidence_files": len(current), "final_changed_paths": len(changed),
    "patches_replayed": [s["id"] for s in stages],
    "all_preimages_verified": True, "all_written_bytes_verified_after_every_stage": True,
    "core_all28_equal_native_exact_source": True, "F_all6_equal_published_exact_postimages": True,
    "source_A_unchanged": True, "full_repository_tree_reconstruction_executed": False,
    "remote_refs_modified": False, "native_commands_executed": False,
})
print(json.dumps({"stage_count": len(stages), "final_changed_paths": len(changed), "stages": [
    {key: s[key] for key in ["id", "additions", "deletions", "patch_sha256"]} for s in manifest["stages"]
]}))
