"""Verify packaged exact bytes and all stage patches; never execute archived source."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile


def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.package.resolve()
    manifest = json.loads((root / "STAGE_MANIFEST.json").read_bytes())
    assert len(manifest["stages"]) == 8
    current = {}
    for item in manifest["base_evidence_files"]:
        data = (root / "base" / item["path"]).read_bytes()
        assert len(data) == item["bytes"] and git_blob(data) == item["git_blob"]
        assert hashlib.sha256(data).hexdigest() == item["sha256"]
        current[item["path"]] = data
    with tempfile.TemporaryDirectory(prefix="mem-review-verify-") as folder:
        replay = Path(folder)
        for path, data in current.items():
            out = replay / path
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(data)
        for stage in manifest["stages"]:
            patch = root / stage["patch"]
            data = patch.read_bytes()
            assert len(data) == stage["patch_bytes"]
            assert hashlib.sha256(data).hexdigest() == stage["patch_sha256"]
            assert len(stage["files"]) > 0
            for item in stage["files"]:
                before = current.get(item["path"])
                assert (git_blob(before) if before is not None else None) == item["preimage_git_blob"]
                after = (root / "stages" / stage["id"] / "postimages" / item["path"]).read_bytes()
                assert len(after) == item["postimage_bytes"]
                assert git_blob(after) == item["postimage_git_blob"]
                assert hashlib.sha256(after).hexdigest() == item["postimage_sha256"]
                current[item["path"]] = after
            for command in [["git", "apply", "--check", str(patch)], ["git", "apply", str(patch)]]:
                result = subprocess.run(command, cwd=replay, capture_output=True)
                assert result.returncode == 0, (stage["id"], result.stderr.decode(errors="replace"))
            files = {p.relative_to(replay).as_posix(): p.read_bytes() for p in replay.rglob("*") if p.is_file()}
            assert files == current
        assert len(current) == 35
        final = {item["path"]: item for item in manifest["final_evidence_paths"]}
        assert set(current) == set(final)
        for path, data in current.items():
            assert data == (root / "final-postimages" / path).read_bytes()
            assert git_blob(data) == final[path]["git_blob"]
    print(json.dumps({"status": "PASS", "stages": 8, "verified_final_paths": 35,
                      "native_commands_executed": False, "full_repository_tree_reconstruction_executed": False}))


if __name__ == "__main__":
    main()
