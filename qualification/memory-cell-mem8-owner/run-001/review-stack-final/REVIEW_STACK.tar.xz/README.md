# MEM8 final formatted review stack

This package reconstructs the final source as eight reviewable stages after published source A. It does not update a branch, create a PR, merge source, execute a model request, or repeat native tests.

## Fixed endpoints

| Role | Exact commit | Tree |
|---|---|---|
| Published A / reconstruction base | ad5a4ed6d40a2eceac189afaced5d93137724a52 | e601d41a97fadbee17947805f4ec507453522800 |
| Qualified owner/control core | 66f570a77c60aac8d33e6cbeac8dfd120ef1d867 | 8eaee893e1e6e43423f288fc654e05c3c95f6179 |
| Published F1 | 911d62a9d4574abd6d175ea080ba7c239d02f935 | 613069bac3f5c66d14b9eca452eaec517569a32a |
| Qualified combined F2 | 0c32926cfec58d986477fc72ba3a4787ab75fde9 | 0d5aa1544aad103f9099c7c8347d8075d6ecc76e |

## Stage boundaries

| Stage | Files | Actual patch lines | Expected cumulative memory cases | Expected cumulative Agentd cases |
|---|---:|---:|---:|---:|
| B | 6 | +554/-1 | 5 | None |
| C | 4 | +462/-0 | 11 | None |
| D1 | 8 | +152/-0 | 11 | 1 |
| D2 | 10 | +539/-4 | 11 | 3 |
| D3 | 4 | +389/-4 | 11 | 4 |
| E | 6 | +364/-21 | 11 | 5 |
| F1 | 2 | +113/-0 | 11 | 5 |
| F2 | 5 | +202/-9 | 11 | 6 |

B contains atomic original-owner import and lost-ack recovery. Its exact final test removes the duplicate drop after consuming close, fixing the observed E0382 compile failure. C adds the six focused owner regressions. D1 supplies protocol and retained-host ingress with unconfigured-source refusal. D2 configures ordinary bounded imports. D3 supplies cancellation/drain coverage, the actual Codex executable prerequisite, validated child-marker forwarding, Bazel declaration, and exact-source CI binary binding. E retains the current source observation for ordinary context-read freshness. F1 persists host-required feature constraints. F2 uses them for the explicit-context memory profile.

The D3 workflow still uses a minimum of one case for broad stage admission. That is a nonempty-test guard; the named-case counts and the three drain markers in this package are the stronger acceptance requirements. A green minimum alone does not prove every intended stage case is linked.

## What was actually checked

Every original stage input blob and original patch hash was checked. The four corrections after historical 81889 are taken from the complete original 66f native source archive. All eight generated patches were applied in order with Git, checking every predecessor blob and every resulting byte. The checkpoint after E matches all 28 changed paths from ad5 to 66f. F1/F2 retain their published exact preimages and postimages, including the shared configuration test file's F1 prefix. The final 31 changed paths match the published 66f plus F1/F2 source; four A source paths remain unchanged. The package has 35 evidence paths because it also retains unchanged A inputs.

This is a sparse source replay, not an independently rebuilt full repository tree. TREE_RECONSTRUCTION.json gives exact base-tree/overlay requests and expected whole-tree IDs for a reviewer with the full Git object database. No remote ref was changed.

The original 66f native run passed 11 memory, 5 Agentd and 16 protocol cases, with actual commit/revoke/panic child markers, clean formatter/scoped-fix gates, and an unchanged exact-head Codex binary. The separate F2 native run passed five groups containing 11 executions of 10 distinct cases, with its own newly built binary and clean source. F2 did not rerun unchanged memory/protocol packages. Evidence indexes retain these exact source identities.

The reconstructed B through E intermediate commits have not been independently compiled or formatted. A newly published stage still needs its own exact-head normal gates. F1's behavior was tested on combined F2; this package does not infer a standalone F1 native result. These native fixtures establish implementation behavior, not original production-owner recovery, real provider task success, or causal memory benefit.

## Reproduce the review checks

Run `python3 verify_replay.py` from this package. It verifies packaged source bytes and all eight patches in a temporary directory. It never executes archived source or invokes a provider.

STAGE_MANIFEST.json contains complete per-file before/after Git blob hashes, SHA256 values, byte counts, patch hashes, stage requirements and expected case IDs. Each stages/<stage>/ directory contains its complete SOURCE.patch, MANIFEST.json and postimages. The full base and final-postimages directories make replay independent of the original scratch directories. build_review_stack.py is retained as historical construction provenance and refers to the original evidence locations; verify_replay.py is the portable verifier.

Historical pending manifests are preserved verbatim under historical-inputs. Current immutable native evidence is referenced under native-evidence, including archive blobs and the separate current F2 qualification index.
