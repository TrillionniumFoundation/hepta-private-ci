use std::ffi::OsString;
use std::fs::File;
use std::fs::OpenOptions;
use std::path::Path;
use std::path::PathBuf;

use codex_hepta_contracts::AgentId;
use codex_hepta_fleet::AgentLifecycle;
use codex_hepta_fleet::FleetRegistry;
use codex_hepta_fleet::ResourceBudget;
use codex_hepta_paths::HeptaAgentLayout;
use codex_hepta_paths::HeptaFleetRoot;

use crate::AgentdError;

#[path = "config_desktop.rs"]
mod desktop;

#[path = "config_circuit_task.rs"]
mod circuit_task;

#[path = "config_sockets.rs"]
mod sockets;
pub(crate) use sockets::AgentdSocketInputs;

#[cfg(target_os = "linux")]
#[path = "config_root_handoff.rs"]
mod root_handoff;
#[cfg(target_os = "linux")]
pub use root_handoff::PreparedRootAgentdConfig;
#[cfg(target_os = "linux")]
pub use root_handoff::drop_root_native_owner_credentials;

pub const HEPTA_AGENT_ID_ENV: &str = "HEPTA_AGENT_ID";
pub const HEPTA_AGENT_GENERATION_ENV: &str = "HEPTA_AGENT_GENERATION";
pub const HEPTA_AGENT_HOME_ENV: &str = "HEPTA_AGENT_HOME";
pub const HEPTA_AGENT_RUN_ROOT_ENV: &str = "HEPTA_AGENT_RUN_ROOT";
pub const HEPTA_COGNITIVE_RETRIEVAL_MODE_ENV: &str = "HEPTA_COGNITIVE_RETRIEVAL_MODE";

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AgentdIdentity {
    pub agent_id: AgentId,
    pub layout: HeptaAgentLayout,
    pub spawn_generation: u64,
    pub fleet_root: PathBuf,
    pub workspace: PathBuf,
    pub resources: ResourceBudget,
    pub home_root: PathBuf,
    pub run_root: PathBuf,
    pub control_socket: PathBuf,
    pub app_server_socket: PathBuf,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CognitiveRetrievalMode {
    Compatibility,
    HnmfRequired,
}

impl CognitiveRetrievalMode {
    #[must_use]
    pub const fn requires_current_context(self) -> bool {
        matches!(self, Self::HnmfRequired)
    }
}

fn parse_cognitive_retrieval_mode(
    value: Option<OsString>,
) -> Result<CognitiveRetrievalMode, AgentdError> {
    let Some(value) = value.filter(|value| !value.is_empty()) else {
        return Ok(CognitiveRetrievalMode::Compatibility);
    };
    let value = value.into_string().map_err(|_| {
        AgentdError::Invalid(format!(
            "{HEPTA_COGNITIVE_RETRIEVAL_MODE_ENV} must be UTF-8"
        ))
    })?;
    match value.as_str() {
        "compatibility" => Ok(CognitiveRetrievalMode::Compatibility),
        "hnmf-required" => Ok(CognitiveRetrievalMode::HnmfRequired),
        _ => Err(AgentdError::Invalid(format!(
            "{HEPTA_COGNITIVE_RETRIEVAL_MODE_ENV} must be compatibility or hnmf-required"
        ))),
    }
}

fn cognitive_retrieval_mode_from_process_environment() -> Result<CognitiveRetrievalMode, AgentdError>
{
    parse_cognitive_retrieval_mode(std::env::var_os(HEPTA_COGNITIVE_RETRIEVAL_MODE_ENV))
}

enum WriterSource {
    OrdinaryPath,
    #[cfg(target_os = "linux")]
    RootDescriptor(File),
}

pub struct AgentdConfig {
    identity: AgentdIdentity,
    sockets: AgentdSocketInputs,
    registry: FleetRegistry,
    authbus_trust_file: Option<PathBuf>,
    evidence_trust_file: Option<PathBuf>,
    automation_effect_host_file: Option<PathBuf>,
    evidence_recovery_frontier_file: Option<PathBuf>,
    evidence_recovery_frontier_trust_file: Option<PathBuf>,
    objective_profile_file: Option<PathBuf>,
    authbus_checkpoint_file: Option<PathBuf>,
    cognitive_ranker: Option<std::sync::Arc<crate::PinnedCognitiveRanker>>,
    production_operations: Option<crate::AgentdProductionOperationRuntimeConfig>,
    production_writer_host: Option<std::sync::Arc<crate::AgentdProductionWriterHost>>,
    notes_objective: Option<crate::AgentdNotesObjectiveConfig>,
    desktop_objective: Option<crate::AgentdDesktopObjectiveConfig>,
    #[cfg(target_os = "linux")]
    notes_ui: Option<crate::AgentdNotesUiRuntime>,
    #[cfg(target_os = "linux")]
    notes_thread_tools: Option<crate::AgentdNotesThreadToolRuntime>,
    #[cfg(target_os = "linux")]
    desktop_thread_tools: Option<crate::AgentdDesktopThreadToolRuntime>,
    cognitive_retrieval_mode: CognitiveRetrievalMode,
    cognitive_retrieval_context: Option<std::sync::Arc<dyn crate::CurrentMemoryRetrievalContext>>,
    cognitive_retrieval_learning: Option<std::sync::Arc<crate::CognitiveRetrievalLearningSink>>,
    plasticity_bootstrap: Option<crate::PlasticityRuntimeBootstrapV1>,
    learning_iteration_bootstrap: Option<crate::LearningIterationRuntimeBootstrapV1>,
    terminal_learning_bootstrap: Option<crate::TerminalLearningRuntimeBootstrapV1>,
    neuron_generation_bootstrap: Option<crate::NeuronGenerationRuntimeBootstrapV2>,
    circuit_task_bootstrap: Option<crate::CircuitTaskRuntimeBootstrapV1>,
    circuit_task_invocation:
        Option<std::sync::Arc<dyn crate::AgentdCircuitTaskInvocationProviderV1>>,
    intuition_policy_host: Option<std::sync::Arc<crate::AgentdIntuitionPolicyHostV1>>,
    intelligence_product_runner: Option<std::sync::Arc<crate::AgentdIntelligenceProductRunnerV1>>,
    intelligence_invocation_provider:
        Option<std::sync::Arc<dyn crate::AgentdIntelligenceInvocationProviderV1>>,
    // Retire original facade state before the one retained process-owner file.
    _writer_lock: std::sync::Arc<File>,
}

impl AgentdConfig {
    pub fn from_process_environment() -> Result<Self, AgentdError> {
        let cognitive_retrieval_mode = cognitive_retrieval_mode_from_process_environment()?;
        let fleet_root = required_path(codex_hepta_paths::HEPTA_FLEET_ROOT_ENV)?;
        let agent_id = required_utf8(HEPTA_AGENT_ID_ENV)?;
        let spawn_generation = required_utf8(HEPTA_AGENT_GENERATION_ENV)?
            .parse::<u64>()
            .map_err(|_| {
                AgentdError::Invalid(format!(
                    "{HEPTA_AGENT_GENERATION_ENV} must be an unsigned integer"
                ))
            })?;
        let home_root = required_path(HEPTA_AGENT_HOME_ENV)?;
        let run_root = required_path(HEPTA_AGENT_RUN_ROOT_ENV)?;
        let codex_home = required_path("CODEX_HOME")?;
        let current_dir = std::env::current_dir()?;
        Self::load(
            fleet_root,
            AgentId::parse(agent_id).map_err(|error| AgentdError::Invalid(error.to_string()))?,
            spawn_generation,
            home_root,
            run_root,
            codex_home,
            current_dir,
        )
        .map(|config| config.with_cognitive_retrieval_mode(cognitive_retrieval_mode))
    }

    #[allow(clippy::too_many_arguments)]
    pub fn load(
        fleet_root: PathBuf,
        agent_id: AgentId,
        spawn_generation: u64,
        home_root: PathBuf,
        run_root: PathBuf,
        codex_home: PathBuf,
        current_dir: PathBuf,
    ) -> Result<Self, AgentdError> {
        Self::load_with_writer_source(
            fleet_root,
            agent_id,
            spawn_generation,
            home_root,
            run_root,
            codex_home,
            current_dir,
            WriterSource::OrdinaryPath,
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn load_with_writer_source(
        fleet_root: PathBuf,
        agent_id: AgentId,
        spawn_generation: u64,
        home_root: PathBuf,
        run_root: PathBuf,
        codex_home: PathBuf,
        current_dir: PathBuf,
        writer_source: WriterSource,
    ) -> Result<Self, AgentdError> {
        if spawn_generation == 0 {
            return Err(AgentdError::Invalid(
                "spawn generation must be non-zero".to_string(),
            ));
        }
        let typed_fleet_root = HeptaFleetRoot::parse(fleet_root.clone())
            .map_err(|error| AgentdError::Invalid(error.to_string()))?;
        require_canonical(&fleet_root, "fleet root")?;
        let registry = FleetRegistry::open_existing(typed_fleet_root)?;
        let record = registry
            .load()?
            .agent(&agent_id)
            .cloned()
            .ok_or_else(|| AgentdError::Invalid(format!("unknown fleet agent {agent_id}")))?;

        if record.lifecycle.lifecycle != AgentLifecycle::Starting
            || record.lifecycle.generation != spawn_generation
        {
            return Err(AgentdError::GenerationFenced(format!(
                "agent {agent_id} expected Starting generation {spawn_generation}, found {:?} generation {}",
                record.lifecycle.lifecycle, record.lifecycle.generation
            )));
        }
        require_exact_path(&home_root, record.layout.home_root(), "agent home")?;
        require_exact_path(&run_root, record.layout.run_root(), "agent run root")?;
        require_exact_path(&codex_home, record.layout.home_root(), "Codex home")?;
        let workspace = current_dir.canonicalize()?;
        if workspace != record.manifest.workspace.as_path() {
            return Err(AgentdError::Invalid(format!(
                "process workspace {} does not match manifest {}",
                workspace.display(),
                record.manifest.workspace.as_path().display()
            )));
        }

        let writer_lock = match writer_source {
            WriterSource::OrdinaryPath => OpenOptions::new()
                .create(true)
                .truncate(false)
                .read(true)
                .write(true)
                .open(record.layout.writer_lock())?,
            #[cfg(target_os = "linux")]
            WriterSource::RootDescriptor(file) => file,
        };
        writer_lock.try_lock().map_err(|error| {
            AgentdError::Invalid(format!(
                "agent {agent_id} already has a live writer lock: {error}"
            ))
        })?;
        let layout = record.layout;
        let control_socket = layout.agentd_control_socket().to_path_buf();
        let app_server_socket = layout.app_server_socket().to_path_buf();

        Ok(Self {
            identity: AgentdIdentity {
                agent_id,
                layout,
                spawn_generation,
                fleet_root,
                workspace,
                resources: record.manifest.resources,
                home_root,
                run_root,
                control_socket,
                app_server_socket,
            },
            registry,
            _writer_lock: std::sync::Arc::new(writer_lock),
            sockets: AgentdSocketInputs::Bind,
            authbus_trust_file: None,
            evidence_trust_file: None,
            automation_effect_host_file: None,
            evidence_recovery_frontier_file: None,
            evidence_recovery_frontier_trust_file: None,
            objective_profile_file: None,
            authbus_checkpoint_file: None,
            cognitive_ranker: None,
            production_operations: None,
            production_writer_host: None,
            notes_objective: None,
            desktop_objective: None,
            #[cfg(target_os = "linux")]
            notes_ui: None,
            #[cfg(target_os = "linux")]
            notes_thread_tools: None,
            #[cfg(target_os = "linux")]
            desktop_thread_tools: None,
            cognitive_retrieval_mode: CognitiveRetrievalMode::Compatibility,
            cognitive_retrieval_context: None,
            cognitive_retrieval_learning: None,
            plasticity_bootstrap: None,
            learning_iteration_bootstrap: None,
            terminal_learning_bootstrap: None,
            neuron_generation_bootstrap: None,
            circuit_task_bootstrap: None,
            circuit_task_invocation: None,
            intuition_policy_host: None,
            intelligence_product_runner: None,
            intelligence_invocation_provider: None,
        })
    }

    /// Explicit owner-managed public-key/route registry. No file is generated
    /// or trusted implicitly; the runtime validates and reloads it before use.
    pub fn with_authbus_trust_file(mut self, path: PathBuf) -> Self {
        self.authbus_trust_file = Some(path);
        self
    }

    pub(crate) fn authbus_trust_file(&self) -> Option<&Path> {
        self.authbus_trust_file.as_deref()
    }

    /// Explicit multi-issuer role registry for kernel.evidence product ingress.
    /// The file is owner-controlled and revalidated at each append boundary.
    pub fn with_evidence_trust_file(mut self, path: PathBuf) -> Self {
        self.evidence_trust_file = Some(path);
        self
    }

    pub(crate) fn evidence_trust_file(&self) -> Option<&Path> {
        self.evidence_trust_file.as_deref()
    }

    /// Optional restore/startup gate backed by a signed frontier and a signer
    /// trust file from outside the Agent home rollback domain. Both files are
    /// required together.
    pub fn with_evidence_recovery_frontier_files(
        mut self,
        frontier_file: PathBuf,
        signer_trust_file: PathBuf,
    ) -> Self {
        self.evidence_recovery_frontier_file = Some(frontier_file);
        self.evidence_recovery_frontier_trust_file = Some(signer_trust_file);
        self
    }

    pub(crate) fn evidence_recovery_frontier_files(&self) -> Option<(&Path, &Path)> {
        match (
            self.evidence_recovery_frontier_file.as_deref(),
            self.evidence_recovery_frontier_trust_file.as_deref(),
        ) {
            (Some(frontier), Some(trust)) => Some((frontier, trust)),
            _ => None,
        }
    }

    /// Attach one protected provider/final-use configuration, fixed at startup.
    pub fn with_automation_effect_host_file(mut self, path: PathBuf) -> Self {
        self.automation_effect_host_file = Some(path);
        self
    }

    pub(crate) fn automation_effect_host_file(&self) -> Option<&Path> {
        self.automation_effect_host_file.as_deref()
    }

    /// Explicit owner-managed objective admission profile. A request cannot
    /// select or replace this file; changing it requires a new process generation.
    pub fn with_objective_profile_file(mut self, path: PathBuf) -> Self {
        self.objective_profile_file = Some(path);
        self
    }

    pub(crate) fn objective_profile_file(&self) -> Option<&Path> {
        self.objective_profile_file.as_deref()
    }

    /// Independently retained replay witness. Production signed ingress requires
    /// this alongside the trust file; it must live outside the Agent home.
    pub fn with_authbus_checkpoint_file(mut self, path: PathBuf) -> Self {
        self.authbus_checkpoint_file = Some(path);
        self
    }

    pub(crate) fn authbus_checkpoint_file(&self) -> Option<&Path> {
        self.authbus_checkpoint_file.as_deref()
    }

    /// Attach an explicitly selected, read-only learned consumer. The host must
    /// authenticate the selection and current revocation witness independently.
    /// No CLI/environment default manufactures an evaluator or selection.
    pub fn with_cognitive_ranker(
        mut self,
        ranker: std::sync::Arc<crate::PinnedCognitiveRanker>,
    ) -> Result<Self, AgentdError> {
        ranker
            .require_identity(&self.identity.agent_id, self.identity.spawn_generation)
            .map_err(AgentdError::Invalid)?;
        if self.cognitive_ranker.is_some() {
            return Err(AgentdError::Invalid(
                "cognitive ranker already configured".to_string(),
            ));
        }
        self.cognitive_ranker = Some(ranker);
        Ok(self)
    }

    pub(crate) fn cognitive_ranker(&self) -> Option<std::sync::Arc<crate::PinnedCognitiveRanker>> {
        self.cognitive_ranker.clone()
    }

    #[cfg(target_os = "linux")]
    pub(crate) fn require_unconfigured_production_hosts(&self) -> Result<(), AgentdError> {
        if self.production_writer_host.is_some() || self.production_operations.is_some() {
            return Err(AgentdError::Invalid(
                "production host is already configured".to_string(),
            ));
        }
        Ok(())
    }

    #[cfg(target_os = "linux")]
    pub(crate) fn install_production_hosts(
        &mut self,
        host: std::sync::Arc<crate::AgentdProductionWriterHost>,
        mut operations: crate::AgentdProductionOperationRuntimeConfig,
    ) -> Result<(), AgentdError> {
        self.require_unconfigured_production_hosts()?;
        operations.validate_for(self)?;
        let writer = host.writer();
        if writer.owner_agent_id() != &self.identity.agent_id
            || host.spawn_generation() != self.identity.spawn_generation
            || writer.authority() != &operations.authority
            || writer.lease_id() != operations.lease_id
            || writer.generation() != operations.lease_generation
        {
            return Err(AgentdError::GenerationFenced(
                "production recovered writer identity differs from Agentd".to_string(),
            ));
        }
        // After every metadata callback and recovery await, recheck the same
        // live verifier immediately before publishing either handle.
        operations
            .verifier
            .verify(&operations.authority, &self.identity.agent_id)
            .map_err(AgentdError::GenerationFenced)?;
        // No fallible operation follows either assignment. The caller has
        // revalidated this same original owner before this exclusive commit.
        operations.verifier = self.retain_production_verifier(operations.verifier);
        self.production_writer_host = Some(host);
        self.production_operations = Some(operations);
        Ok(())
    }

    /// Attach an externally-authorized long-lived production operation host.
    /// Default process-environment startup never manufactures or loads this
    /// authority; an embedding must provide the complete verified runtime
    /// configuration explicitly.
    pub fn with_production_operations(
        mut self,
        mut operations: crate::AgentdProductionOperationRuntimeConfig,
    ) -> Result<Self, AgentdError> {
        operations.validate_for(&self)?;
        if self.production_operations.is_some() {
            return Err(AgentdError::Invalid(
                "production operation runtime already configured".to_string(),
            ));
        }
        operations.verifier = self.retain_production_verifier(operations.verifier);
        self.production_operations = Some(operations);
        Ok(self)
    }

    pub(crate) fn take_production_operations(
        &mut self,
    ) -> Option<crate::AgentdProductionOperationRuntimeConfig> {
        self.production_operations.take()
    }

    /// Install the actual Session UI beside the same original protected writer.
    /// `run` supervises it as a required task; a Session exit drains this host.
    #[cfg(target_os = "linux")]
    pub fn with_original_notes_ui(
        mut self,
        runtime: crate::AgentdNotesUiRuntime,
    ) -> Result<Self, AgentdError> {
        if self.notes_ui.is_some()
            || self.notes_thread_tools.is_some()
            || self.desktop_thread_tools.is_some()
        {
            return Err(AgentdError::Invalid(
                "original Notes UI already configured".into(),
            ));
        }
        runtime.validate_for(&self)?;
        self.notes_ui = Some(runtime);
        Ok(self)
    }

    #[cfg(target_os = "linux")]
    pub(crate) fn take_original_notes_ui(&mut self) -> Option<crate::AgentdNotesUiRuntime> {
        self.notes_ui.take()
    }

    #[cfg(target_os = "linux")]
    pub(crate) fn install_original_notes_thread_tools(
        mut self,
        runtime: crate::AgentdNotesThreadToolRuntime,
    ) -> Result<Self, AgentdError> {
        if self.notes_ui.is_some()
            || self.notes_thread_tools.is_some()
            || self.desktop_thread_tools.is_some()
        {
            return Err(AgentdError::Invalid(
                "original Notes operation mode already selected".into(),
            ));
        }
        runtime.validate_for(&self)?;
        self.notes_thread_tools = Some(runtime);
        Ok(self)
    }

    /// Hold the actual Session for the required original-thread worker. The
    /// original inherited pidfd and birth validation must precede installation.
    #[cfg(target_os = "linux")]
    pub fn with_original_notes_thread_session(
        mut self,
        session: crate::AgentdNotesSessionLifetime,
    ) -> Result<Self, AgentdError> {
        let runtime = self.notes_thread_tools.as_mut().ok_or_else(|| {
            AgentdError::Invalid("original Notes thread mode is not installed".into())
        })?;
        runtime.install_session(session)?;
        Ok(self)
    }

    /// Retain only the mandatory original Start receipt bound to the installed
    /// model tool profile. It is reverified on the final actual connection.
    #[cfg(target_os = "linux")]
    pub fn with_original_notes_thread_seed(
        mut self,
        seed: crate::NotesThreadSeedReceipt,
    ) -> Result<Self, AgentdError> {
        self.notes_thread_tools
            .as_mut()
            .ok_or_else(|| {
                AgentdError::Invalid("original Notes tool runtime is not installed".into())
            })?
            .install_seed(seed)?;
        Ok(self)
    }

    #[cfg(target_os = "linux")]
    pub(crate) fn take_original_notes_thread_tools(
        &mut self,
    ) -> Option<crate::AgentdNotesThreadToolRuntime> {
        self.notes_thread_tools.take()
    }

    /// Explicit old-incarnation recovery from the trusted sealed deployment.
    /// The actual current target is taken from the already installed Session
    /// observer; no UI command supplies either target or a helper path.
    #[cfg(target_os = "linux")]
    pub fn with_original_notes_previous_recovery(
        mut self,
        launch: crate::AgentdNotesPreviousRecoveryLaunch,
    ) -> Result<Self, AgentdError> {
        self.production_operations
            .as_mut()
            .ok_or(AgentdError::CognitiveWriteRuntimeUnavailable)?
            .select_previous_notes_process(launch)?;
        Ok(self)
    }

    /// Resolve only on the already recovered original writer. Latest requires
    /// the installed original-thread seed/session and complete protected cut;
    /// the existing helper still receives one exact old operation only.
    #[cfg(target_os = "linux")]
    pub async fn with_original_notes_previous_recovery_request(
        self,
        request: crate::AgentdNotesPreviousRecoveryRequest,
    ) -> Result<Self, AgentdError> {
        let operation_id = match &request.selector {
            crate::AgentdNotesRecoverySelector::ExactOperation { operation_id } => {
                operation_id.clone()
            }
            crate::AgentdNotesRecoverySelector::LatestRecordedOriginalNotes => {
                self.notes_thread_tools
                    .as_ref()
                    .ok_or_else(|| {
                        AgentdError::Invalid(
                            "latest recorded recovery requires original thread mode".into(),
                        )
                    })?
                    .latest_recovery_operation(&request.previous_target)
                    .await?
            }
        };
        self.with_original_notes_previous_recovery(request.resolved(operation_id))
    }

    /// Attach a sealed old Calculator operation to the same recovered runtime.
    /// The supplied current identity must already be an actual attached target.
    #[cfg(target_os = "linux")]
    pub fn with_original_calculator_previous_recovery(
        mut self,
        current: &codex_hepta_memory::CalculatorTargetIdentity,
        launch: crate::AgentdCalculatorPreviousRecoveryLaunch,
    ) -> Result<Self, AgentdError> {
        self.production_operations
            .as_mut()
            .ok_or(AgentdError::CognitiveWriteRuntimeUnavailable)?
            .select_previous_calculator_process(current, launch)?;
        Ok(self)
    }

    /// Attach an externally verified production cognitive writer to normal
    /// Agentd composition. Agentd never manufactures this authority.
    pub fn with_production_writer_host(
        mut self,
        host: std::sync::Arc<crate::AgentdProductionWriterHost>,
    ) -> Result<Self, AgentdError> {
        if self.production_writer_host.is_some() {
            return Err(AgentdError::Invalid(
                "production cognitive writer host already configured".to_string(),
            ));
        }
        let writer = host.writer();
        if writer.owner_agent_id() != &self.identity.agent_id {
            return Err(AgentdError::GenerationFenced(
                "production cognitive writer owner does not match Agentd identity".to_string(),
            ));
        }
        if host.spawn_generation() != self.identity.spawn_generation {
            return Err(AgentdError::GenerationFenced(format!(
                "production host spawn generation {} does not match Agentd spawn generation {}",
                host.spawn_generation(),
                self.identity.spawn_generation
            )));
        }
        self.production_writer_host = Some(host);
        Ok(self)
    }

    pub(crate) fn production_writer_host(
        &self,
    ) -> Option<std::sync::Arc<crate::AgentdProductionWriterHost>> {
        self.production_writer_host.clone()
    }

    /// Select the retrieval product profile explicitly. Compatibility preserves
    /// the legacy owner-ranked path. HnmfRequired forbids startup without a
    /// current authenticated retrieval context and never silently falls back.
    pub fn with_cognitive_retrieval_mode(mut self, mode: CognitiveRetrievalMode) -> Self {
        self.cognitive_retrieval_mode = mode;
        self
    }

    pub(crate) fn cognitive_retrieval_mode(&self) -> CognitiveRetrievalMode {
        self.cognitive_retrieval_mode
    }

    /// Attach an authenticated external-generation/engram currentness source.
    /// The ordinary CLI never manufactures one. Once attached, any currentness
    /// failure closes HNMF retrieval instead of falling back to an older view.
    pub fn with_cognitive_retrieval_context(
        mut self,
        current: std::sync::Arc<dyn crate::CurrentMemoryRetrievalContext>,
    ) -> Result<Self, AgentdError> {
        if self.cognitive_retrieval_context.is_some() {
            return Err(AgentdError::Invalid(
                "cognitive retrieval context already configured".to_string(),
            ));
        }
        let context = current
            .current(&self.identity.agent_id, self.identity.spawn_generation)
            .map_err(AgentdError::Invalid)?;
        context
            .validate()
            .map_err(|error| AgentdError::Invalid(error.to_string()))?;
        self.cognitive_retrieval_context = Some(current);
        Ok(self)
    }

    pub(crate) fn cognitive_retrieval_context(
        &self,
    ) -> Option<std::sync::Arc<dyn crate::CurrentMemoryRetrievalContext>> {
        self.cognitive_retrieval_context.clone()
    }

    /// Attach the actual durable learning-ledger sink for HNMF assignment
    /// evidence. The retrieval currentness provider must already be configured;
    /// Agentd never records generator-relative assignments on the compatibility
    /// path that lacks a frozen HNMF generation.
    pub fn with_cognitive_retrieval_learning(
        mut self,
        sink: std::sync::Arc<crate::CognitiveRetrievalLearningSink>,
    ) -> Result<Self, AgentdError> {
        if self.cognitive_retrieval_context.is_none() {
            return Err(AgentdError::Invalid(
                "retrieval learning requires a configured current retrieval context".to_string(),
            ));
        }
        if self.cognitive_retrieval_learning.is_some() {
            return Err(AgentdError::Invalid(
                "cognitive retrieval learning sink already configured".to_string(),
            ));
        }
        self.cognitive_retrieval_learning = Some(sink);
        Ok(self)
    }

    pub(crate) fn cognitive_retrieval_learning(
        &self,
    ) -> Option<std::sync::Arc<crate::CognitiveRetrievalLearningSink>> {
        self.cognitive_retrieval_learning.clone()
    }

    /// Attach one explicitly constructed governed plasticity bootstrap envelope.
    /// Agentd itself consumes the envelope, creates the bounded channel, retains
    /// the sole mutable owner and stores the producer handle in daemon state.
    /// There is no ambient/default plasticity writer.
    pub fn with_plasticity_runtime_bootstrap(
        mut self,
        bootstrap: crate::PlasticityRuntimeBootstrapV1,
    ) -> Result<Self, AgentdError> {
        if self.plasticity_bootstrap.is_some() {
            return Err(AgentdError::Invalid(
                "plasticity runtime bootstrap already configured".to_string(),
            ));
        }
        self.plasticity_bootstrap = Some(bootstrap);
        Ok(self)
    }

    pub(crate) fn take_plasticity_runtime_bootstrap(
        &mut self,
    ) -> Option<crate::PlasticityRuntimeBootstrapV1> {
        self.plasticity_bootstrap.take()
    }

    /// Explicit control-owner opt-in. Work runs separately from foreground turns.
    /// The governed plasticity owner must also be attached before runtime start.
    pub fn with_learning_iteration_bootstrap(
        mut self,
        bootstrap: crate::LearningIterationRuntimeBootstrapV1,
    ) -> Result<Self, AgentdError> {
        bootstrap.require_identity(&self.identity)?;
        if self.learning_iteration_bootstrap.is_some() {
            return Err(AgentdError::Invalid(
                "learning iteration owner already configured".into(),
            ));
        }
        self.learning_iteration_bootstrap = Some(bootstrap);
        Ok(self)
    }

    pub(crate) fn take_learning_iteration_bootstrap(
        &mut self,
    ) -> Option<crate::LearningIterationRuntimeBootstrapV1> {
        self.learning_iteration_bootstrap.take()
    }

    /// Attach the narrow native terminal-value learner explicitly. It shares
    /// the existing ledger/Memory owners and runs outside foreground turns.
    pub fn with_terminal_learning_bootstrap(
        mut self,
        bootstrap: crate::TerminalLearningRuntimeBootstrapV1,
    ) -> Result<Self, AgentdError> {
        bootstrap.require_identity(&self.identity)?;
        if self.terminal_learning_bootstrap.is_some() {
            return Err(AgentdError::Invalid(
                "terminal learning owner already configured".into(),
            ));
        }
        self.terminal_learning_bootstrap = Some(bootstrap);
        Ok(self)
    }

    pub(crate) fn take_terminal_learning_bootstrap(
        &mut self,
    ) -> Option<crate::TerminalLearningRuntimeBootstrapV1> {
        self.terminal_learning_bootstrap.take()
    }

    /// Attach an already admitted stateful control adapter and its exclusive
    /// journal. Ordinary process configuration leaves this service absent.
    pub fn with_neuron_generation_bootstrap(
        mut self,
        bootstrap: crate::NeuronGenerationRuntimeBootstrapV2,
    ) -> Result<Self, AgentdError> {
        bootstrap.require_identity(&self.identity)?;
        self.require_neuron_generation_profile()?;
        self.neuron_generation_bootstrap = Some(bootstrap);
        Ok(self)
    }

    /// Check the explicit generation profile before opening its durable owners.
    pub fn require_neuron_generation_profile(&self) -> Result<(), AgentdError> {
        if self.neuron_generation_bootstrap.is_some()
            || self.notes_objective.is_some()
            || self.desktop_objective.is_some()
        {
            return Err(AgentdError::Invalid(
                "generation service requires its own explicit non-finite profile".into(),
            ));
        }
        Ok(())
    }

    pub(crate) fn take_neuron_generation_bootstrap(
        &mut self,
    ) -> Option<crate::NeuronGenerationRuntimeBootstrapV2> {
        self.neuron_generation_bootstrap.take()
    }

    /// Attach the authenticated current intuition-policy product caller.
    /// The caller is pinned to this exact Agentd identity/generation and owns
    /// no model, scorer, RNG or learning facts itself.
    pub fn with_intuition_policy_host(
        mut self,
        host: std::sync::Arc<crate::AgentdIntuitionPolicyHostV1>,
    ) -> Result<Self, AgentdError> {
        host.require_identity(&self.identity.agent_id, self.identity.spawn_generation)
            .map_err(|error| AgentdError::Invalid(error.to_string()))?;
        if self.intuition_policy_host.is_some() {
            return Err(AgentdError::Invalid(
                "intuition policy host already configured".to_string(),
            ));
        }
        self.intuition_policy_host = Some(host);
        Ok(self)
    }

    pub(crate) fn intuition_policy_host(
        &self,
    ) -> Option<std::sync::Arc<crate::AgentdIntuitionPolicyHostV1>> {
        self.intuition_policy_host.clone()
    }

    /// Compose the canonical intelligence product caller into this daemon.
    /// No authority file, signer identity, or verifying key is inferred.
    pub fn with_intelligence_product_runner(
        mut self,
        runner: std::sync::Arc<crate::AgentdIntelligenceProductRunnerV1>,
    ) -> Result<Self, AgentdError> {
        self.require_no_circuit_task_profile()?;
        if self.intelligence_product_runner.is_some() {
            return Err(AgentdError::Invalid(
                "intelligence product runner already configured".to_string(),
            ));
        }
        self.intelligence_product_runner = Some(runner);
        Ok(self)
    }

    pub(crate) fn intelligence_product_runner(
        &self,
    ) -> Option<std::sync::Arc<crate::AgentdIntelligenceProductRunnerV1>> {
        self.intelligence_product_runner.clone()
    }

    /// Attach the host-owned provider that derives seven-owner inputs for the
    /// existing ObjectiveStart product ingress.  The provider is never
    /// constructed from request bytes.
    pub fn with_intelligence_invocation_provider(
        mut self,
        provider: std::sync::Arc<dyn crate::AgentdIntelligenceInvocationProviderV1>,
    ) -> Result<Self, AgentdError> {
        self.require_no_circuit_task_profile()?;
        if self.intelligence_invocation_provider.is_some() {
            return Err(AgentdError::Invalid(
                "intelligence invocation provider already configured".to_string(),
            ));
        }
        self.intelligence_invocation_provider = Some(provider);
        Ok(self)
    }

    pub(crate) fn intelligence_invocation_provider(
        &self,
    ) -> Option<std::sync::Arc<dyn crate::AgentdIntelligenceInvocationProviderV1>> {
        self.intelligence_invocation_provider.clone()
    }

    /// Opt in to one frozen literal Notes profile; no general AI executor.
    pub fn with_notes_objective(
        mut self,
        config: crate::AgentdNotesObjectiveConfig,
    ) -> Result<Self, AgentdError> {
        self.require_no_circuit_task_profile()?;
        config.validate()?;
        if self.notes_objective.is_some()
            || self.desktop_objective.is_some()
            || self.neuron_generation_bootstrap.is_some()
        {
            return Err(AgentdError::Invalid(
                "Notes Objective adapter already configured".into(),
            ));
        }
        self.notes_objective = Some(config);
        Ok(self)
    }

    #[cfg(target_os = "linux")]
    pub(crate) fn require_finite_notes_profile(&self) -> Result<(), AgentdError> {
        self.require_no_circuit_task_profile()?;
        if self.production_writer_host.is_none()
            || self.notes_objective.is_none()
            || self.authbus_trust_file.is_none()
            || self.authbus_checkpoint_file.is_none()
            || self.objective_profile_file.is_none()
            || self.production_operations.is_some()
            || self.evidence_trust_file.is_some()
            || self.evidence_recovery_frontier_file.is_some()
            || self.evidence_recovery_frontier_trust_file.is_some()
            || self.automation_effect_host_file.is_some()
            || self.cognitive_ranker.is_some()
            || self.cognitive_retrieval_mode != CognitiveRetrievalMode::Compatibility
            || self.cognitive_retrieval_context.is_some()
            || self.cognitive_retrieval_learning.is_some()
            || self.plasticity_bootstrap.is_some()
            || self.learning_iteration_bootstrap.is_some()
            || self.terminal_learning_bootstrap.is_some()
            || self.neuron_generation_bootstrap.is_some()
            || self.intuition_policy_host.is_some()
            || self.intelligence_product_runner.is_some()
            || self.intelligence_invocation_provider.is_some()
        {
            return Err(AgentdError::Invalid(
                "finite Notes profile requires its original writer, Notes, AuthBus and admission owners without another execution plane".into(),
            ));
        }
        Ok(())
    }

    pub(crate) fn notes_objective(&self) -> Option<crate::AgentdNotesObjectiveConfig> {
        self.notes_objective.clone()
    }

    pub fn identity(&self) -> &AgentdIdentity {
        &self.identity
    }

    pub(crate) fn into_parts(self) -> (AgentdIdentity, FleetRegistry, std::sync::Arc<File>) {
        (self.identity, self.registry, self._writer_lock)
    }
}

fn required_utf8(name: &str) -> Result<String, AgentdError> {
    let value = std::env::var_os(name)
        .filter(|value| !value.is_empty())
        .ok_or_else(|| AgentdError::Invalid(format!("{name} is required")))?;
    value
        .into_string()
        .map_err(|_| AgentdError::Invalid(format!("{name} must be UTF-8")))
}

fn required_path(name: &str) -> Result<PathBuf, AgentdError> {
    let value: OsString = std::env::var_os(name)
        .filter(|value| !value.is_empty())
        .ok_or_else(|| AgentdError::Invalid(format!("{name} is required")))?;
    Ok(PathBuf::from(value))
}

fn require_canonical(path: &Path, label: &str) -> Result<(), AgentdError> {
    let canonical = path.canonicalize()?;
    if canonical != path {
        return Err(AgentdError::Invalid(format!(
            "{label} must be canonical and symlink-free: {}",
            path.display()
        )));
    }
    Ok(())
}

fn require_exact_path(actual: &Path, expected: &Path, label: &str) -> Result<(), AgentdError> {
    require_canonical(actual, label)?;
    if actual != expected {
        return Err(AgentdError::Invalid(format!(
            "{label} {} does not match registered path {}",
            actual.display(),
            expected.display()
        )));
    }
    Ok(())
}

#[cfg(test)]
#[path = "config_tests.rs"]
mod tests;

#[path = "owner_writer_custody.rs"]
mod writer_custody;
