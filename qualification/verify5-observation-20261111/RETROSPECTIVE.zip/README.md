# VERIFY retrospective GitHub readback

## What was actually collected

This is a read-only adapter observation of existing GitHub Actions. Six existing
run attempts, six different API-declared source SHAs and all sixteen constituent
jobs were retrieved. All runs had already finished before collection. No job was
dispatched, retried, or altered. No model was trained or invoked.

Collection occurred from **2026-11-12 00:18:10.729 UTC** through
**2026-11-12 00:19:39.147 UTC** (November 11 in America/New_York).
There are **zero pre-terminal snapshots**. The initial ACK view is
**NOT_OBSERVED**, with null payload and time; it is not a manufactured constant
baseline.

[ORIGINALS.json](ORIGINALS.json) retains the complete connector-decoded responses,
their original inner text, request identity and actual collection clocks.
These are **not raw HTTP wire bytes**. Inner SHA-256 digests cover exact UTF-8
`structuredContent.content`; canonical outer JSON serialization does not
normalize the embedded payload strings. Six fetched workflow bodies rehash to
their GitHub-reported Git blob identities.

[SUMMARY.json](SUMMARY.json) contains derived accounting, the complete job roster,
identity checks, and explicit outcome/observation boundaries.

## Fixed observed sources

| Run | API-declared source | Job conclusions |
| --- | --- | --- |
| [42771553807](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42771553807) | `0893ac7a2e8e8126d67f77bad7086df1d739fbc6` | 3 success |
| [42773881110](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42773881110) | `a2cd828aad47c56ac8c01dc2e423454eca7eafae` | 3 success |
| [42825965141](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42825965141) | `0006e834178ff3cbc78bb6059e97ca7be52dc282` | 1 success, 1 failure, 1 cancelled |
| [42827989197](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42827989197) | `88deb8a490565fd9b55851ba4581c9516fd1029f` | 2 success, 1 cancelled |
| [42903566372](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42903566372) | `4010cc2631a993d76ce9ebbeca3bddbd1e8c83a0` | 2 success, 1 cancelled |
| [42872910595](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42872910595) | `95b9153068222b63ccc90b7e002b15b43a61406e` | 1 failure |

All six returned attempt numbers are 1. Each attempt-specific jobs endpoint
returned its complete `total_count` on page 1 (three or one jobs).
Run/attempt/head identity joins match all sixteen jobs. Counts are **11 success,
2 failure and 3 cancelled**. The four failed run conclusions are not sixteen
failed job conclusions.

These are six operational run/source clusters, not six independently sampled
business tasks. Five runs use the same workflow family; four share exactly the
same workflow blob. There are two workflow IDs and three distinct workflow blobs
overall. Repository, source ancestry and workflow dependencies remain shared.

## Outcome contract

Keep three different facts separate:

1. `ci_conclusion` is GitHub's reported job conclusion, retained verbatim.
2. The narrow claim "this particular CI job passed" can be supported/refuted by
   the corresponding success/failure metadata. Cancellation remains unknown for
   this qualification view rather than a test failure.
3. `business_terminal_outcome` remains **UNKNOWN for every row**: a CI job
   conclusion is not an independent semantic outcome for a user's business task.
   In particular, cancellation must never be imputed as business failure or
   success.

A completed run with a failed conclusion can contain successful jobs, cancelled
jobs, and skipped test stages. A timestamp labelled `started_at` with an empty
step roster does not prove that any workload step actually ran.

The API head is an intended source identity. It is not automatically the
executed checkout identity: PR workflows can execute a prospective merge.
The summary binds an executed checkout only where an already read complete
decoded job log establishes it (three existing captures). Other rows remain
unverified at that boundary. No new large log downloads were performed.

## Collector contract for the next observation stage

- Freeze repository, run ID, attempt, expected head and the job roster. Use the
  attempt-specific endpoint; require exact row count, unique job IDs and matching
  run/attempt/head identities. Retain missing or inconsistent responses.
- Record `request_started_utc`, `response_observed_utc`, the clock domain,
  request endpoint, decoded payload byte length and SHA-256 for every call.
  Provider event timestamps and collector availability timestamps are distinct.
  Do not backdate observation to a provider `created_at` or `completed_at`.
- Preserve separate states for NOT_REQUESTED, REQUESTED, AVAILABLE, ERROR,
  PARTIAL and UNKNOWN. A failed read does not establish a failed target job.
- A prospective initial view must come from a real retained pre-terminal
  response. A synthetic projection of current terminal records is only an
  explicitly simulated ablation and cannot supply that missing observation.
- Mandatory source/owner/permission checks remain deterministic. Metadata and
  logs are separately obtained observations from the same GitHub trust domain;
  this is not independent custody or an independent business adjudicator.
- For policy comparison, freeze the action decision before the optional GET.
  Never let returned facts retroactively enter the earlier risk model input.
  A readback reporting a terminal fact is a deterministic observation, not a
  learned prediction that has discovered the label.

## Preventing terminal-label leakage

Before-readback risk features must exclude `conclusion`, completed step status,
`completed_at`, terminal test summaries, artifact outcome names, final duration,
raw log text, log/payload hashes and terminal payload byte lengths.
Those fields depend on the later observation or its target label.

Run/job IDs, commit SHAs, branch names and PR text are join/provenance fields,
not arbitrary categorical risk features: they can reveal known outcome or
repair history. The collector can use them to retrieve and bind evidence without
showing them to the risk model.

A genuine earlier status such as queued/in_progress is usable only with its
retained actual availability time. This capture has no such earlier response.
All current metadata are terminal observations. No feature projection of these
records demonstrates pre-terminal predictive information.

## Cost and evidence limits

Eighteen measured calls returned **162,854 decoded UTF-8 payload bytes**.
The sum of their client elapsed durations is **11,389 ms**: 3,271 ms for run
metadata, 5,598 ms for job rosters, and 2,520 ms for pinned workflow contents.
Calls within each group ran concurrently, so that sum is **not total wall time**.
The clocks are the execution orchestrator's Date.now/ISO wall clock; monotonic
timing is not asserted.

Workflow retrieval and roster discovery are preparation costs, separate from
a future per-decision readback cost. The prior three log captures are referenced
with measured byte hashes; their unrecorded per-call timing remains null.
Wire bytes, connector caching, CPU, energy and provider charges remain unknown.
Historical CI job duration is not the cost of the present readback.

This establishes a real external-service source adapter and its observation
boundaries. It does not estimate risk calibration, drift, an ACK/readback
information gain, or a no-check/fixed/risk-triggered/oracle policy difference.
It adds **zero independently adjudicated business tasks**, zero model
computations, and zero scientific confirmations. **HOLD / NONE**.

## Artifact identity

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| ORIGINALS.json | 346380 | `007b2069a9ea7f02040e923f7851d68a4ccaa979c3c014d6e6a30c2693710bce` |
| SUMMARY.json | 21423 | `25f7e5c3491f4f6b4234594c62c85ed712be8a9729845679f8269085cfde9503` |
