"""Observe each callback mutation using a separate real SQLite journal."""

from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys

from experiments.verification_cell_verify1.contracts import digest
from experiments.verification_cell_verify1.test_checker_dispatch import CheckerDispatchTests


def observe(kind):
    fixture = CheckerDispatchTests()
    fixture.setUp()
    callbacks = []
    reply = fixture.reply("op", fixture.source.snapshot, "fail", 1.0)
    original = asdict(reply)

    def lost(operation, snapshot):
        fixture.calls.append(operation)
        raise KeyboardInterrupt()

    def invoke(operation, snapshot):
        fixture.calls.append(operation)
        return reply

    def read_snapshot(snapshot):
        callbacks.append("read_snapshot")
        if kind == "readback_outcome" and len(callbacks) == 2:
            object.__setattr__(reply, "outcome", "pass")
        return digest(asdict(snapshot))

    try:
        if kind.startswith("auth_"):
            try:
                fixture.dispatch(run=lost)
            except KeyboardInterrupt:
                pass
            field, replacement = {
                "auth_outcome": ("outcome", "pass"),
                "auth_evidence": ("evidence_sha256", digest("substituted-evidence")),
                "auth_cost": ("actual_cost_units", 0.0),
                "auth_bool_alias": ("actual_cost_units", True),
            }[kind]

            def authenticate(operation, received, request_sha, config_sha):
                callbacks.append("authenticate")
                object.__setattr__(received, field, replacement)
                return True

            action = lambda: fixture.journal.reconcile(
                "op", reply, read_snapshot=read_snapshot, authenticate=authenticate
            )
        else:
            if kind == "ingress_bool_alias":
                object.__setattr__(reply, "actual_cost_units", True)
            action = lambda: fixture.dispatch(run=invoke, read_snapshot=read_snapshot)
        try:
            result, error = action(), None
        except Exception as exception:
            result, error = None, {
                "type": type(exception).__name__,
                "message": str(exception),
            }
        return {
            "scenario": kind,
            "original_reply": original,
            "mutated_reply": asdict(reply),
            "callbacks": callbacks,
            "actual_checker_invocations": len(fixture.calls),
            "result": result,
            "error": error,
            "retained_status": fixture.journal.status("op")["result"]["status"],
        }
    finally:
        fixture.doCleanups()


if __name__ == "__main__":
    source = Path("experiments/verification_cell_verify1/checker_dispatch.py").read_bytes()
    observations = [
        observe(kind)
        for kind in (
            "auth_outcome", "auth_evidence", "auth_cost", "auth_bool_alias",
            "readback_outcome", "ingress_bool_alias",
        )
    ]
    result = {
        "schema": "hepta.verify5.dispatch-mutation-observations.v1",
        "source_sha256": hashlib.sha256(source).hexdigest(),
        "source_git_blob_sha": hashlib.sha1(
            b"blob " + str(len(source)).encode() + b"\0" + source
        ).hexdigest(),
        "observations": observations,
        "scope": "controlled callbacks and independent local SQLite journals; no real-task admission",
    }
    Path(sys.argv[1]).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps([
        {"scenario": row["scenario"], "retained_status": row["retained_status"],
         "error": row["error"], "actual_checker_invocations": row["actual_checker_invocations"]}
        for row in observations
    ], indent=2))
