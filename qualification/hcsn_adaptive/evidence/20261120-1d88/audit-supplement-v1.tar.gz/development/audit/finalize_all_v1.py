"""Seal every predeclared campaign before the first real final holdout claim."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path('/home/qian-qi/hcsn-adaptive-20261120-1d88')
REPO = ROOT / 'repo'
PYTHON = '/home/qian-qi/heptatorch-wide-neg-20261121-19d2fc/venv/bin/python'
ENV = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
           OPENBLAS_NUM_THREADS='1', PYTHONUNBUFFERED='1')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def execute(command, name):
    start = time.perf_counter()
    result = subprocess.run(command, cwd=REPO, env=ENV, capture_output=True, text=True)
    log = ROOT / 'results' / (name + '.log')
    with log.open('x') as stream:
        stream.write(result.stdout + '\nSTDERR\n' + result.stderr)
    return {'name': name, 'command': command, 'returncode': result.returncode,
            'wall_seconds': time.perf_counter()-start, 'log': str(log), 'log_sha256': sha(log)}


def write_exclusive(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def main():
    campaigns = []
    for name, count in [('smoke', 6), ('p1_future_return', 36), ('p2_future_return', 18),
                        ('p1_delayed_recall', 36), ('p2_delayed_recall', 18), ('p3_uci864', 12),
                        ('p4_uci864', 19), ('taskadv', 12)]:
        module = ('hcsn_scale' if name.startswith('p4_') else
                  'hcsn_task_advantage' if name == 'taskadv' else 'hcsn_adaptive')
        output = ROOT / 'runs' / name
        manifest = ROOT / 'manifests' / (name+'.json')
        seal_code = (f'from qualification.{module}.campaign import read_manifest,seal_selection_set; '
                     f'm=read_manifest({str(manifest)!r}); seal_selection_set(m,{str(output)!r})')
        campaigns.append({'name': name, 'expected_final_rows': count,
                          'manifest': str(manifest), 'output': str(output),
                          'seal': str(output/'finalization-seal.json'),
                          'seal_command': [PYTHON, '-c', seal_code],
                          'final_command': [PYTHON, '-m', f'qualification.{module}.campaign', 'finalize',
                                            '--manifest', str(manifest), '--output', str(output)]})
    output = ROOT / 'runs' / 'equity-v1'
    command = [PYTHON, '-m', 'qualification.hcsn_equity_ablation.campaign']
    campaigns.append({'name': 'equity-v1', 'expected_final_rows': 18,
                      'manifest': str(output/'manifest.json'), 'output': str(output),
                      'seal': str(output/'selection-seal.json'),
                      'seal_command': command+['seal', '--output', str(output)],
                      'final_command': command+['finalize', '--output', str(output)]})
    claims = [str(p) for entry in campaigns for p in Path(entry['output']).rglob('final.started')]
    if claims:
        raise RuntimeError('No final holdout may precede this global seal: '+repr(claims))
    seals = []
    for entry in campaigns:
        receipt = execute(entry['seal_command'], 'global-seal-'+entry['name'])
        seals.append(receipt)
        if receipt['returncode'] != 0:
            raise RuntimeError('Seal failed: '+str(receipt))
        entry['manifest_file_sha256'] = sha(Path(entry['manifest']))
        entry['selection_seal_sha256'] = sha(Path(entry['seal']))
    global_seal = {'schema': 'hcsn.global-finalization-seal.v1',
                   'sealed_at_utc': datetime.now(timezone.utc).isoformat(),
                   'prior_final_claims': claims, 'formal_final_rows': 169, 'smoke_final_rows': 6,
                   'campaigns': campaigns, 'seal_execution': seals,
                   'script_sha256': sha(Path(__file__)),
                   'rule': 'All source/data/runtime/model selections frozen; no training or reselection after this seal.'}
    seal_path = ROOT / 'results' / 'global-finalization-seal-v1.json'
    write_exclusive(seal_path, global_seal)
    final_receipts = []
    for entry in campaigns:
        for item in campaigns:
            if (sha(Path(item['seal'])) != item['selection_seal_sha256'] or
                    sha(Path(item['manifest'])) != item['manifest_file_sha256']):
                raise RuntimeError('A globally sealed choice changed')
        final_receipts.append(execute(entry['final_command'], 'global-final-'+entry['name']))
    receipt = {'global_seal_sha256': sha(seal_path), 'executions': final_receipts,
               'warning': 'Process exit is not an individual-trial success claim; inspect every final receipt.'}
    write_exclusive(ROOT/'results'/'global-final-execution-v1.json', receipt)
    print(json.dumps({'global_seal_sha256': receipt['global_seal_sha256'],
                      'executions': [{k: v for k, v in row.items() if k in ('name', 'returncode', 'wall_seconds')}
                                     for row in final_receipts]}, indent=2))


if __name__ == '__main__':
    main()
