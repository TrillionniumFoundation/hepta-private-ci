"""Identify the first native-FP32 invariant violation; no tolerances are changed."""
import hashlib
import json
from pathlib import Path

import torch
import qualification.hcsn_adaptive.batched_flow as backend

torch.set_num_threads(1)
torch.manual_seed(178)
precision = {"transport_precision": "native"} if "transport_precision" in backend.FlowConfig.__dataclass_fields__ else {}
model = backend.BatchedFlow(backend.FlowConfig(input_size=2, content_size=2, bins=4, stages=2, **precision)).float()
inputs = torch.tensor([[.2, -.4], [-.2, .4]], dtype=torch.float32)
config = model.config
drift = config.base_drift+config.drift_scale*model.drive(inputs).squeeze(-1).tanh()
generator, event, _ = model._generator(drift)
batch, size = event.shape
active = torch.cat((inputs.new_ones(config.bins), inputs.new_zeros(config.stages+1)))
weights = torch.stack((event, active.expand_as(event)), -1)
augmented = torch.cat((torch.cat((generator, weights), -1), inputs.new_zeros(batch, 2, size+2)), -2)
transition = torch.matrix_exp(augmented*config.dt)[:, :size, :size]
print(json.dumps({"version": "p1-native-fp32-failure-diagnostic-v1", "torch": torch.__version__,
    "backend_sha256": hashlib.sha256(Path(backend.__file__).read_bytes()).hexdigest(),
    "generator_row_sum_real": generator.double().sum(-1).detach().tolist(),
    "transition_row_sum_real_minus_one": (transition.double().sum(-1)-1).detach().tolist()}))
validate = model.validate_state
step_number = 0

def observed(state, batch, dtype, device):
    try:
        validate(state, batch, dtype, device)
    except ValueError:
        p = state.density[:, :1].double()
        print(json.dumps({"first_bad_step": step_number, "time_micros": state.time_micros,
            "mass_error_real": (p.sum(-1)-1).tolist(), "min_probability": p.min().item(),
            "max_content_excess": (state.density[:, 1:].double().abs()-p).max().item(),
            "max_boundary": state.boundary.abs().max().item()}))
        raise

model.validate_state = observed
state = None
try:
    with torch.no_grad():
        for step_number in range(1, 513):
            _, state, _ = model.step(inputs, state)
except ValueError:
    pass
else:
    print(json.dumps({"completed_steps": 512, "mass_error": (state.density[:, 0].double().sum(-1)-1).tolist()}))
