"""Read immutable final receipts; create auditable aggregate tables and archive."""
import hashlib
import json
from pathlib import Path
import statistics
import tarfile

ROOT = Path('/home/qian-qi/hcsn-adaptive-20261120-1d88')
OUT = ROOT / 'analysis' / 'final-evidence-v1'
OUT.mkdir(exist_ok=False)


def read(path):
    return json.loads(path.read_text())


def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n')


def stats(values):
    return {'mean': statistics.mean(values),
            'sample_sd': statistics.stdev(values) if len(values)>1 else None,
            'n': len(values), 'values': values}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


counts = {}
adaptive_names = ['smoke', 'p1_future_return', 'p2_future_return', 'p1_delayed_recall',
                  'p2_delayed_recall', 'p3_uci864']
for name in adaptive_names:
    run = ROOT/'runs'/name
    final = read(run/'final-summary.json')
    summary = read(run/'campaign-summary.json')
    assert len(final) == summary['planned_trials'] and all(row['status']=='completed' for row in final)
    assert not summary['uncertain_or_unavailable_cost_records']
    rows, groups, features = [], {}, {}
    for result in final:
        trial = result['trial']
        training = read(run/'trials'/trial['id']/'training.json')
        cost, feature = training['cost'], training['feature_cost']
        features[feature['key']] = feature['shared_cost']
        row = {'trial': trial, 'test_mse': result['test_mse'], 'dev_mse': training['best_dev'],
               'training_mean_constant_mse': result['training_mean_constant_mse'],
               'selected_step': training['best_step'], 'outcome': training['outcome'],
               'eligible_parameters': training['eligible_parameters'],
               'learning_cost': cost, 'feature_cost_key': feature['key'],
               'final_wall_seconds': result['wall_seconds'],
               'test_selection_count': result['test_selection_count']}
        row.update({k: result[k] for k in ['accuracy', 'macro_f1', 'confusion'] if k in result})
        rows.append(row)
        groups.setdefault(trial['variant']['id']+':'+trial['method'], []).append(row)
    table = {}
    for key, values in groups.items():
        table[key] = {'test_mse': stats([v['test_mse'] for v in values]),
                      'dev_mse': stats([v['dev_mse'] for v in values]),
                      'learner_wall_seconds': stats([v['learning_cost']['wall_seconds'] for v in values]),
                      'final_wall_seconds': stats([v['final_wall_seconds'] for v in values]),
                      'no_update': sum(v['outcome']=='NoUpdate' for v in values),
                      'selected_steps': [v['selected_step'] for v in values]}
        for metric in ['accuracy', 'macro_f1']:
            if metric in values[0]:
                table[key][metric] = stats([v[metric] for v in values])
    write(name+'.json', {'manifest': summary['manifest'], 'table': table, 'rows': rows,
                         'shared_features': features,
                         'training_totals_deduplicated': summary['total_reserved_work_deduplicated'],
                         'journal_wall_lower_bound_seconds': summary['journal_wall_lower_bound_seconds'],
                         'cost_scope': summary['cost_scope']})
    counts[name] = len(rows)

p4 = read(ROOT/'runs/p4_uci864/final-summary.json')
assert len(p4['finals']) == 19 and all(row['status']=='completed' for row in p4['finals'])
assert not p4['summary']['cost_uncertain_tracks']
groups = {}
for row in p4['summary']['tracks']:
    directory = ROOT/'runs/p4_uci864/tracks'/row['track']['id']
    training = read(directory/'training.json')
    row['training_cost'] = training.get('cost')
    row['worker_processes'] = [{k:v for k,v in read(p).items() if k not in ['stdout','stderr']}
                               for p in sorted(directory.glob('process-*.json'))]
    groups.setdefault(row['track']['kind']+':'+str(row['track']['width']), []).append(row)
table = {}
for key, rows in groups.items():
    table[key] = {metric: stats([row['final'][metric] for row in rows])
                  for metric in ['test_probe_mse','accuracy','macro_f1']}
    table[key].update(no_update=sum(row['outcome']=='NoUpdate' for row in rows),
                      selected_steps=[row['selected_step'] for row in rows],
                      parameters=[row['model'] for row in rows],
                      worker_wall_seconds=stats([sum(p['wall_seconds'] for p in row['worker_processes']) for row in rows]))
write('p4_uci864.json', {'seal':p4['seal'], 'table':table, 'tracks':p4['summary']['tracks'],
                        'training_totals':p4['summary']['total_reserved_counts'],
                        'cost_journals':p4['summary']['cost_journals']})
counts['p4_uci864'] = len(p4['finals'])

task = read(ROOT/'runs/taskadv/campaign-summary.json')
assert len(task['rows']) == 12 and all(row['final']['status']=='completed' for row in task['rows'])
assert not task['unavailable_or_uncertain_costs']
groups = {}
for row in task['rows']:
    groups.setdefault(row['trial']['arm'], []).append(row)
task['table'] = {key: {**{metric:stats([row['final']['test'][metric] for row in rows])
                         for metric in ['task_mse','objective','expected_events']},
                       'no_update':sum(row['outcome']=='NoUpdate' for row in rows)}
                 for key,rows in groups.items()}
write('taskadv.json', task)
counts['taskadv'] = len(task['rows'])

equity = read(ROOT/'runs/equity-v1/final.json')
assert len(equity['results']) == 18 and equity['test_selection_count'] == 0
equity['groups'] = []
groups = {}
for row in equity['results']:
    groups.setdefault(row['task']+':'+row['arm'], []).append(row['test_mse'])
equity['table'] = {key:stats(values) for key,values in groups.items()}
for path in sorted((ROOT/'runs/equity-v1').glob('*/training.json')):
    train = read(path)
    assert train['status']=='completed' and train['cost_journal']['status']=='settled'
    equity['groups'].append({'group':path.parent.name, 'training':train, 'final':read(path.parent/'final.json')})
write('equity.json', equity)
counts['equity-v1'] = 18

write('COUNTS.json', {'counts':counts, 'formal_completed':sum(v for k,v in counts.items() if k!='smoke'),
                      'smoke_completed':counts['smoke'], 'formal_training_failures':0,
                      'formal_final_unavailable':0, 'training_cost_uncertain':0,
                      'global_seal':read(ROOT/'results/global-finalization-seal-v1.json'),
                      'final_execution':read(ROOT/'results/global-final-execution-v1.json')})

files = set()
for directory in [ROOT/'runs', ROOT/'manifests', ROOT/'results', OUT]:
    files.update(p for p in directory.rglob('*') if p.is_file())
for directory in ['future_return-formal-v1','delayed_recall-formal-v1','uci864-query-v1']:
    files.update(p for p in (ROOT/'data'/directory).rglob('*') if p.is_file())
for path in [ROOT/'analysis/finalize_all_v1.py', Path(__file__),
             ROOT/'standalone-helper-v1/BUILD.json', ROOT/'native-helper/manifest.json']:
    if path.is_file():
        files.add(path)
for path in (ROOT/'manifests').glob('*.json'):
    value=read(path)
    for name in value.get('source', {}):
        source=ROOT/'repo'/name
        if source.is_file():
            files.add(source)
for name in read(ROOT/'runs/equity-v1/manifest.json')['source']:
    source=ROOT/'repo'/name
    if source.is_file():
        files.add(source)
members=[{'path':str(p.relative_to(ROOT)), 'bytes':p.stat().st_size, 'sha256':sha(p)} for p in sorted(files)]
member_path=ROOT/'analysis/runtime-evidence-members-v1.json'
member_path.write_text(json.dumps(members,indent=2)+'\n')
archive=ROOT/'analysis/runtime-evidence-v1.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
    for path in sorted(files):
        tar.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
    tar.add(member_path,arcname='runtime-evidence-members-v1.json',recursive=False)
receipt={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),
         'members':len(members),'uncompressed_bytes':sum(row['bytes'] for row in members),
         'member_manifest_sha256':sha(member_path),'counts':counts}
(ROOT/'analysis/runtime-evidence-receipt-v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
