# P1 / P2 / TaskADV 最终结果独立只读分析

已读取正式 final-summary、training-summary 和成本 jsonl；没有重跑训练/测试，没有改冻结源或结果回执。下面为三个初始化种子的均值；± 为样本标准差，不是置信区间。各 seed 使用同一数据划分。

## 结论

本轮支持“小规模固定特征的可微机制与闭式/坐标读出训练可运行”，不支持“程序式编辑普遍替代 BP”或“连续任务边界已经带来稳定收益”。TaskADV 的 81 个候选全部正常评估，三个 seed 的三个非平凡搜索 arm 均保留 NoUpdate，不能把实现成功当作性能成功。

## P1：机制与特征消融

| Variant | future_return 测试 MSE | delayed_recall 测试 MSE |
|---|---:|---:|
| fixed_dynamics | 0.26697058 ± 0.01967061 | 0.00252313 ± 0.00222979 |
| input_drift | 0.33651999 ± 0.11769242 | 0.00925963 ± 0.00676473 |
| free_scalar | 0.37316651 ± 0.15536422 | 0.00355058 ± 0.00228468 |
| input_boundary | 0.35416840 ± 0.06780938 | 0.00355058 ± 0.00228468 |
| task_continuation | 0.25982362 ± 0.02363281 | 0.00384453 ± 0.00234819 |
| no_call | 0.30678377 ± 0.07133873 | 0.00905354 ± 0.00637813 |
| no_risk | 0.33570002 ± 0.11654073 | 0.00928219 ± 0.00680229 |
| no_risk_call | 0.30634152 ± 0.07074133 | 0.00908707 ± 0.00640680 |
| no_margin | 0.33184302 ± 0.11616905 | 0.00946723 ± 0.00664068 |
| no_occupation | 0.34246417 ± 0.12388586 | 0.00924694 ± 0.00645775 |
| phase1 | 0.33461327 ± 0.11453586 | 0.00911100 ± 0.00668865 |
| phase4 | 0.33833306 ± 0.11852889 | 0.00936143 ± 0.00678501 |

训练均值常数预测的 MSE 分别为 0.68376898、0.36203253。未来收益任务的 auxiliary task_continuation 均值比 fixed_dynamics 小约 2.7%，但三 seed 中两个更差，不能称稳定优势。delayed_recall 上 fixed_dynamics 最好；input_boundary 三 seed 都选 gain=0、b=.25，逐 seed 与 free_scalar 完全相同。task_continuation 实际 b=.1875 恒定，不能把该任务结果解释为输入自适应边界收益。future_return 的 auxiliary task 边界实际在 ±.1875 变化；其目标仍是辅助观察 MDP，不是真实任务损失 critic。

Call/risk/margin/occupation 和 phase 数的结果没有一致的正向优势；去 Call 在这两个固定-feature对照中并未变差。这里的 Call 是 finite-policy Call；不能拿它代替后来 full-HX 消融的结论。delayed_recall 的 readout 使用 last+mean，mean 聚合本身保留早期 cue 的贡献，低误差不能单独证明 population 状态具有长时记忆。

P1 共享特征/搜索账本总墙钟：future_return 5.485172 秒，delayed_recall 6.242863 秒；每项36个不同(seed,variant)缓存。读出账本总墙钟分别2.013034、1.812425秒。全部相关链通过重新计算 SHA 校验，没有未结算操作。

## P2：学习器误差与实际费用

| Learner | future_return MSE | delayed_recall MSE | future learner 秒 | recall learner 秒 |
|---|---:|---:|---:|---:|
| frozen | 1.87875808 ± 0.72635462 | 0.78029032 ± 0.50249205 | 0.036931 | 0.034861 |
| ridge | 0.33651999 ± 0.11769242 | 0.00925963 ± 0.00676473 | 0.054739 | 0.035609 |
| bp | 0.27502402 ± 0.02806262 | 0.06202456 ± 0.06773758 | 1.350879 | 1.389327 |
| zeroth_order | 0.41004167 ± 0.04090781 | 0.16595417 ± 0.12370408 | 1.050963 | 1.223302 |
| programmatic_edit | 0.29273355 ± 0.04479995 | 0.05623131 ± 0.06452191 | 0.984479 | 0.993258 |
| edit_then_bp | 0.27215155 ± 0.04142684 | 0.06154737 ± 0.06855386 | 1.276900 | 0.949525 |

这些是每 seed 的 learner 账本均值，包括开发选择和完整checkpoint持久化；不包括共同特征生成。共有3个独立feature缓存：future_return合计0.274450秒、每seed0.091483秒；recall合计0.322579秒、每seed0.107526秒。不能给六种方法分别重复计算同一个共享缓存，也不能把缓存视为零成本。

BP 的 checkpoint 时间均值为1.081160/1.076599秒；ProgrammaticEdit为0.781872/0.779558秒，占所列墙钟的大部分。分配至算法操作区间的时间分别为 BP 0.221388/0.235031秒，edit 0.162850/0.168895秒；区间仍包含日志及相邻调度开销，不是纯内核 benchmark。因此不能从这些秒数推导大模型通用加速倍率。

所有方法仅优化相同19个 affine readout参数，encoder/features冻结，统一训练目标 MSE + (0.001/96)||W||²，bias不惩罚。共同上限并不代表同样本/FLOP预算：

| 方法 | 训练样本处理次数 | backward examples | dev queries | proposals |
|---|---:|---:|---:|---:|
| Frozen | 0 | 0 | 1 | 0 |
| Ridge | 96 | 0 | 2 | 1 |
| BP | 2048 | 2048 | 9 | 64 |
| Zeroth order | 4096 | 0 | 9 | 64 |
| ProgrammaticEdit | 6144 | 0 | 9 | 64 |
| Edit then BP | 4096 | 1024 | 9 | 64 |

ProgrammaticEdit是残差相关性选择坐标并执行带trust radius的坐标更新，没有MIT agent发现程序的训练/推理/搜索过程。本轮编辑在future_return逊于BP，recall均值稍好于BP但明显逊于闭式ridge；edit+BP在future_return略好，但差异相对seed波动很小。结果支持闭式/局部更新在特定固定表示问题上的价值，不支持替代非线性表征学习或基础模型预训练。

## TaskADV：真实任务损失教师的负结果

四个arm最终全部输出同一零边界策略。三个seed均值：task MSE=0.6263373525 ± 0.3389987188；MSE+0.01*expected_events=0.6306140723；expected_events=0.4276719794。

| Seed | 最终 task MSE | 最终带事件成本 objective | zero dev objective | 最佳 task候选 dev objective |
|---|---:|---:|---:|---:|
| 11 | 0.40566774 | 0.40786110 | 0.45272233 | 0.52864062 |
| 29 | 1.01667006 | 1.02387337 | 0.49531836 | 5.67631214 |
| 47 | 0.45667427 | 0.46010774 | 0.52557852 | 0.85812138 |

81个搜索候选没有数值失败；加3次共享zero reference共84次dev queries，成本全部保留。这是开发选择明确拒绝边界改变，不是预算不足或缺失结果。训练得到的 critic 确实有连续输入/状态依赖：三 seed 的 FD/AD 均通过，最大绝对差2.81e-9；可微性成立与预测收益成立是不同命题。

每seed的共享readout/teacher/diagnostic账本平均0.092599秒，共0.277798秒；arm搜索账本均值always_zero0.008747秒、fixed0.217994秒、input0.202657秒、task0.197746秒。整个12trial加共享计算合计2.159232秒，未计进程外部开销和最终推理。教师/critic费用仅是task方法必需成本，放入共同artifact不意味着控制组必须支付它。

TaskADV只有32个readout训练样本、不同flow宽度和单决策协议，不能把其绝对MSE与P1/P2直接排名。端点教师只估计low/high风险差，不保证任一端点或中间sigmoid动作优于b=0；本次NoUpdate正是这一限制的实际体现。后续若改变教师/策略/normalizer，需要独立新方案及新留出，不能对已公开test反调参。

## 证据

远程根：`/home/qian-qi/hcsn-adaptive-20261120-1d88/runs/`。

- `p1_future_return/final-summary.json` SHA256 `dfe0a224e5893a927bcf3bd616a7b66ce8477abcc480f2794506a7c5f332a71c`
- `p1_delayed_recall/final-summary.json` SHA256 `245a553442442d0fcab386fdd3441527e15c04079d08e31e5328428cdf67475c`
- `p2_future_return/final-summary.json` SHA256 `cc2e3a9ae4931b5ae6c2be38ea050db450abe7ace18b777ad8645207bc6c007b`
- `p2_delayed_recall/final-summary.json` SHA256 `2ec0108603ae6f780214202c8fdac684485dfa63a22983e5e355f40a32acf84d`
- `taskadv/final-summary.json` SHA256 `fc0da68406101d6f67e58833af29f98c893f039866adcf5b076a43fd47917cb9`

训练选择依据位于各campaign的`training-summary.json`、`trials/<id>/training.json`；实际成本位于adaptive的`trials/<id>/learner/cost.jsonl`和`features/<key-prefix>/cost.jsonl`，TaskADV的`trials/<id>/cost.jsonl`和`shared/<seed>/cost.jsonl`。本地派生汇总与证据身份另见`p1_p2_taskadv_final_summary.json`及`result_evidence.json`。原始回执由Root统一归档。

