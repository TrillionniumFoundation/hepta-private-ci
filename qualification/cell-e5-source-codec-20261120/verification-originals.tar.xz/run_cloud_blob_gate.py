"""Run the unchanged repository blob gate on exact imported Git objects."""
import hashlib
import json
import os
import pathlib
import platform
import shutil
import subprocess
import tarfile
import time
import traceback

ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / "cloud-blob-gate-1"
OUT.mkdir(exist_ok=False)
REPO = OUT / "objects.git"
BASE = "63f494553a735bd55a3fef7cfe2e76604cd6db7d"
HEAD = "0a57d319ee479c820c36618d6c713881829c04cc"
ENV = dict(os.environ, GIT_NO_LAZY_FETCH="1", GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0")
START = time.monotonic()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def gitsha(kind, raw):
    return hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def git(*args, data=None):
    return subprocess.check_output(["git", *args], cwd=REPO, env=ENV, input=data, stderr=subprocess.PIPE, timeout=15)


def state():
    answer = {}
    for name in ["HEAD", "config", "index", "packed-refs"]:
        p = REPO / name
        answer[name] = sha(p.read_bytes()) if p.is_file() else None
    answer["loose_refs"] = {str(p.relative_to(REPO)): sha(p.read_bytes()) for p in (REPO / "refs").rglob("*") if p.is_file()}
    return answer


objects = []
error = None
result = {"schema": "hepta.exact-git-object-original-blob-gate.v1", "host": "managed-cloud-workspace", "base": BASE, "head": HEAD, "max_bytes": 512000, "model_loads": 0, "forward_calls": 0, "generation_calls": 0, "training_updates": 0, "native_replays": 0}
try:
    init = subprocess.run(["git", "init", "--bare", str(REPO)], env=ENV, capture_output=True, timeout=15)
    (OUT / "init.stdout").write_bytes(init.stdout)
    (OUT / "init.stderr").write_bytes(init.stderr)
    assert init.returncode == 0
    metadata = json.loads((ROOT / "git-metadata-export-1/RESULT.json").read_bytes())
    archive = ROOT / "git-metadata-export-1/metadata.tar.gz"
    assert archive.stat().st_size == metadata["archive_bytes"] and sha(archive.read_bytes()) == metadata["archive_sha256"]
    with tarfile.open(archive, "r:gz") as tar:
        actual = tar.getmembers()
        assert len(actual) == len(metadata["objects"])
        for entry in metadata["objects"]:
            member = tar.getmember(entry["path"])
            assert member.isfile()
            raw = tar.extractfile(member).read()
            assert len(raw) == entry["bytes"] and sha(raw) == entry["sha256"]
            assert gitsha(entry["type"], raw) == entry["oid"]
            oid = git("hash-object", "-t", entry["type"], "-w", "--stdin", data=raw).decode().strip()
            assert oid == entry["oid"]
            assert git("cat-file", entry["type"], oid) == raw
            objects.append({**entry, "exact_readback": True})
    files = []
    for source, manifest, key in [("publication-freeze", "FREEZE_PUBLICATION_MANIFEST.json", "publication_files"), ("publication-measurement", "MEASUREMENT_PUBLICATION_MANIFEST.json", "files")]:
        for entry in json.loads((ROOT / manifest).read_bytes())[key]:
            raw = (ROOT / source / entry["path"]).read_bytes()
            assert len(raw) == entry["bytes"] and sha(raw) == entry["sha256"]
            assert gitsha("blob", raw) == entry["git_blob_sha1"]
            oid = git("hash-object", "-t", "blob", "-w", "--stdin", data=raw).decode().strip()
            assert oid == entry["git_blob_sha1"] and git("cat-file", "blob", oid) == raw
            files.append(entry)
            objects.append({"path": entry["path"], "oid": oid, "type": "blob", "bytes": len(raw), "sha256": sha(raw), "exact_readback": True})
    assert len(files) == 53
    (OUT / "EXACT_OBJECTS.json").write_text(json.dumps(objects, sort_keys=True) + "\n")
    changed_raw = git("diff", "--name-only", "--diff-filter=AM", "--no-renames", "-z", BASE, HEAD)
    (OUT / "changed-paths.stdout").write_bytes(changed_raw)
    changed = [x for x in changed_raw.decode().split("\0") if x]
    assert sorted(changed) == sorted(entry["path"] for entry in files)
    (OUT / "CHANGED_PATHS.json").write_text(json.dumps(changed, sort_keys=True) + "\n")
    for name, expected in [("check_blob_size.py", "eb7a9eab936b7c7948ed13fbd6d6aca09aa38997c20685a8ee12d72e388d52c3"), ("blob-size-allowlist.txt", "56a9a1cd05a0d81bba73a43c19e1451b213443f631dabacfa5b4e8d145e43d1c")]:
        raw = (ROOT / "blob-execution-1" / name).read_bytes()
        assert sha(raw) == expected
        (OUT / name).write_bytes(raw)
    argv = ["python", str(OUT / "check_blob_size.py"), "--base", BASE, "--head", HEAD, "--max-bytes", "512000", "--allowlist", str(OUT / "blob-size-allowlist.txt")]
    before = state()
    (OUT / "BEFORE.json").write_text(json.dumps(before, sort_keys=True) + "\n")
    (OUT / "INTENT.json").write_text(json.dumps({"argv": argv, "cwd": str(REPO), "timeout_seconds": 120, "base": BASE, "head": HEAD, "original_script_sha256": sha((OUT / "check_blob_size.py").read_bytes()), "original_allowlist_sha256": sha((OUT / "blob-size-allowlist.txt").read_bytes())}, sort_keys=True) + "\n")
    began = time.monotonic()
    try:
        child = subprocess.run(argv, cwd=REPO, env=ENV, capture_output=True, timeout=120)
        stdout, stderr, code, timed_out = child.stdout, child.stderr, child.returncode, False
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code, timed_out = exc.stdout or b"", exc.stderr or b"", None, True
    wall = time.monotonic() - began
    (OUT / "stdout").write_bytes(stdout)
    (OUT / "stderr").write_bytes(stderr)
    after = state()
    (OUT / "AFTER.json").write_text(json.dumps(after, sort_keys=True) + "\n")
    result.update({"status": "PASS" if code == 0 and before == after else "FAIL", "argv": argv, "cwd": str(REPO), "exit_code": code, "timed_out": timed_out, "gate_wall_seconds": wall, "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr), "verified_git_objects": len(objects), "verified_blobs": len(files), "changed_file_count": len(changed), "head_ref_index_config_unchanged": before == after, "original_script_sha256": sha((OUT / "check_blob_size.py").read_bytes()), "original_allowlist_sha256": sha((OUT / "blob-size-allowlist.txt").read_bytes()), "git_version": git("--version").decode().strip(), "python_version": platform.python_version()})
except Exception as exc:
    error = type(exc).__name__ + ": " + str(exc)
    (OUT / "exception.txt").write_text(traceback.format_exc())
    result.update({"status": "ERROR", "error": error})
result["owner_wall_seconds"] = time.monotonic() - START
(OUT / "RESULT.json").write_text(json.dumps(result, sort_keys=True) + "\n")
print(json.dumps(result, indent=2))
raise SystemExit(0 if result["status"] == "PASS" else 1)
