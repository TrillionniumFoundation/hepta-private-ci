"""Package only this isolated audit's evidence, without reading any producer task."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
paths = [
 "data.json", "source/verify.py", "prepare_recount.py", "run_original_verify.py",
 "evidence/MOSI_ORIGINAL_DATA_RECOVERY.json", "evidence/TRANSFER_VERIFY_RESULT.json",
 "evidence/ORIGINAL_VERIFY_RESULT.json", "evidence/ORIGINAL_VERIFY_STARTED.json",
 "evidence/original-verify.stdout.log", "evidence/original-verify.stderr.log",
 "transfer/INDEX.json", "transfer/CHUNKS.json", "raw/verified_objects.json",
 "raw/FRESH_SEAL.json", "raw/terminal_manifest.json", "raw/fresh_study.py",
 "raw/PROSPECTIVE_REPLICATION.md", "derived/SUMMARY.json",
 "derived/all_intact_models.json", "package_replay_evidence.py"
]
out = root / "evidence" / "original-replay.tar.gz"
inventory = []
with out.open("xb") as dest:
    with gzip.GzipFile(filename="", mode="wb", fileobj=dest, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as archive:
            for name in sorted(paths):
                path = root / name
                if path.is_symlink() or not path.is_file():
                    raise ValueError("unexpected evidence path: " + name)
                data = path.read_bytes()
                record = {"path": name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                inventory.append(record)
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                archive.addfile(info, io.BytesIO(data))
payload = out.read_bytes()
result = {"archive": str(out), "size": len(payload),
          "sha256": hashlib.sha256(payload).hexdigest(),
          "git_blob": hashlib.sha1(b"blob " + str(len(payload)).encode() + b"\0" + payload).hexdigest(),
          "members": inventory, "only_isolated_audit_files_read": True,
          "no_forward_or_training": True}
if len(payload) > 500 * 1024:
    raise ValueError("evidence archive exceeds existing blob policy")
(root / "evidence" / "ORIGINAL_REPLAY_PACKAGE.json").write_text(
    json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in result.items() if k != "members"}, sort_keys=True))
