"""Assemble fixed GitHub copies in this new audit directory; never read producer paths."""
import datetime
import hashlib
import json
import pathlib
import tarfile
import time
import traceback

ROOT = pathlib.Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
RAW_COMMIT = "4b84b0431b089ccac84c75ac3ac19f96ad804fe4"
MANIFEST_SHA = "1033cd2e6a0002eee1c4e9c4a1beecc43d27e096ebd22bc8bda99770a2898930"
DATA_SHA = "968dfb23d19f7ba50c9907b2146810e09922283b4b4342618e8d2eac151c4f70"
VERIFY_SHA = "bdbb45e0ad4227ef2750bb7d35ca4d2035b1c9fd8257d2c4e2c7ed7fa76b17af"

def digest(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

def write_new(path, value):
    with path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")

def require(condition, message):
    if not condition:
        raise ValueError(message)

def main():
    started = time.monotonic()
    result = {"schema": "hepta.mosi.fixed-raw-transfer.v1",
              "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "source_commit": RAW_COMMIT, "new_forward": False, "new_training": False,
              "producer_directories_read": False, "objects": []}
    try:
        transfer = ROOT / "transfer"
        index = json.loads((transfer / "INDEX.json").read_bytes())
        require(index["commit"] == RAW_COMMIT, "wrong fixed source commit")
        entries = index["objects"]
        require(len(entries) == 166, "wrong number of exact archived objects")
        expected = {entry["name"]: entry for entry in entries}
        require(len(expected) == len(entries), "duplicate index names")
        chunks = json.loads((transfer / "CHUNKS.json").read_bytes())
        require([x["part"] for x in chunks] == list(range(15)), "missing or unordered chunks")
        tar_path = ROOT / "published-4b84.tar"
        tar_hash = hashlib.sha256()
        tar_bytes = 0
        with tar_path.open("xb") as target:
            for item in chunks:
                path = transfer / ("raw_4b84_part_%03d.bin" % item["part"])
                payload = path.read_bytes()
                require(len(payload) == item["written"], "chunk size mismatch")
                require(hashlib.sha256(payload).hexdigest() == item["sha256"], "chunk hash mismatch")
                target.write(payload)
                tar_hash.update(payload)
                tar_bytes += len(payload)
        require(tar_bytes == 15455744, "unexpected complete tar size")
        raw = ROOT / "raw"
        require(raw.is_dir() and not list(raw.iterdir()), "raw destination must be empty")
        with tarfile.open(tar_path, mode="r:") as archive:
            members = archive.getmembers()
            require(len(members) == len(expected), "archive member count differs")
            require(len({m.name for m in members}) == len(members), "duplicate archive member")
            require({m.name for m in members} == set(expected), "archive member names differ")
            for member in members:
                name = member.name
                parts = pathlib.PurePosixPath(name).parts
                require(member.isfile() and not member.issym() and not member.islnk(), "non-regular archive entry")
                require(name and not name.startswith("/") and "\\" not in name, "unsafe archive name")
                require(all(p not in ("", ".", "..") for p in parts), "unsafe archive path")
                require("/".join(parts) == name, "noncanonical archive path")
                entry = expected[name]
                require(member.size == entry["size"], "member size mismatch: " + name)
                handle = archive.extractfile(member)
                require(handle is not None, "unreadable archive member")
                with handle:
                    payload = handle.read()
                sha = hashlib.sha256(payload).hexdigest()
                oid = hashlib.sha1(b"blob " + str(len(payload)).encode("ascii") + b"\0" + payload).hexdigest()
                require(len(payload) == entry["size"] and sha == entry["sha256"] and oid == entry["git_blob"], "fixed Git object mismatch: " + name)
                path = raw / name
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("xb") as output:
                    output.write(payload)
                result["objects"].append({"name": name, "bytes": len(payload), "sha256": sha, "git_blob": oid})
        manifest_path = raw / "verified_objects.json"
        require(digest(manifest_path) == MANIFEST_SHA, "original canonical manifest mismatch")
        manifest = json.loads(manifest_path.read_bytes())
        require(len(manifest) == 165 and set(manifest) == set(expected) - {"verified_objects.json"}, "canonical manifest set mismatch")
        for name, record in manifest.items():
            require(record["size"] == expected[name]["size"] and record["sha256"] == expected[name]["sha256"], "canonical object identity mismatch")
        seal_path = raw / "FRESH_SEAL.json"
        seal = json.loads(seal_path.read_bytes())
        terminal = json.loads((raw / "terminal_manifest.json").read_bytes())
        require(digest(ROOT / "data.json") == DATA_SHA == seal["data_manifest_sha256"], "true original data manifest mismatch")
        require(digest(ROOT / "source" / "verify.py") == VERIFY_SHA == seal["code"]["verify.py"], "original verifier mismatch")
        require(digest(raw / "fresh_study.py") == seal["fresh_driver_sha256"], "fresh driver mismatch")
        require(digest(raw / "PROSPECTIVE_REPLICATION.md") == seal["fresh_protocol_sha256"], "fresh protocol mismatch")
        require(digest(raw / "AV_input_provenance.json") == seal["AV_input_provenance_sha256"], "AV provenance mismatch")
        require(digest(seal_path) == terminal["seal_sha256"], "terminal seal mismatch")
        require(digest(raw / "result" / "SUMMARY.json") == terminal["summary_sha256"], "terminal summary mismatch")
        require(len(terminal["files"]) == 159, "unexpected terminal file count")
        for name, sha in terminal["files"].items():
            require(name in manifest and manifest[name]["sha256"] == sha and digest(raw / name) == sha, "terminal object mismatch: " + name)
        for name, sha in seal["fits"].items():
            require(digest(raw / "models" / name) == sha, "sealed fit mismatch")
        for name, sha in seal["weights"].items():
            require(digest(raw / "models" / name) == sha, "sealed actual weight bytes mismatch")
        result.update(status="PASS", tar_bytes=tar_bytes, tar_sha256=tar_hash.hexdigest(),
                      archive_objects=len(expected), original_objects=len(manifest),
                      original_object_bytes=sum(x["size"] for x in manifest.values()),
                      archive_payload_bytes=sum(x["size"] for x in expected.values()),
                      terminal_objects=len(terminal["files"]), fit_receipts=len(seal["fits"]),
                      actual_weight_objects=len(seal["weights"]), data_sha256=DATA_SHA,
                      original_verifier_sha256=VERIFY_SHA,
                      receipt_scope="Object identity and saved-prediction replay inputs only; no model inference or physical retiming.")
    except BaseException:
        result["status"] = "FAIL"
        result["exception"] = traceback.format_exc()
        raise
    finally:
        result["wall_s"] = time.monotonic() - started
        result["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write_new(EVIDENCE / "TRANSFER_VERIFY_RESULT.json", result)
        print(json.dumps({k: result[k] for k in result if k != "objects"}, sort_keys=True))

if __name__ == "__main__":
    main()
