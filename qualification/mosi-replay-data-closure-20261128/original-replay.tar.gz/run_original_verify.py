"""Run the sealed verifier once on fixed copies; no training or model code is imported."""
import contextlib
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import resource
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
RAW = ROOT / "raw"
VERIFY_SHA = "bdbb45e0ad4227ef2750bb7d35ca4d2035b1c9fd8257d2c4e2c7ed7fa76b17af"
DATA_SHA = "968dfb23d19f7ba50c9907b2146810e09922283b4b4342618e8d2eac151c4f70"
DESIGNS = [(0, a) for a in ("raw_all", "raw_text", "raw_av")] + [
    (64, a) for a in ("fp_h", "fp_h_text", "fp_h_av", "fp_h_shuffle", "fp_r",
                      "random_h", "bp_h", "transformer", "transformer_text")]
SHARED = ("fp_h", "fp_r", "random_h", "bp_h", "transformer", "fp_h_av")

def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

def write_new(path, value):
    with path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")

def require(condition, message):
    if not condition:
        raise ValueError(message)

def compare_values(before, after, path="$", differences=None):
    if differences is None:
        differences = []
    if type(before) is not type(after):
        differences.append({"path": path, "published": before, "recomputed": after})
    elif isinstance(before, dict):
        if set(before) != set(after):
            differences.append({"path": path, "published_keys": sorted(before), "recomputed_keys": sorted(after)})
        for key in sorted(set(before) & set(after)):
            compare_values(before[key], after[key], path + "." + str(key), differences)
    elif isinstance(before, list):
        if len(before) != len(after):
            differences.append({"path": path, "published_length": len(before), "recomputed_length": len(after)})
        for i, (left, right) in enumerate(zip(before, after)):
            compare_values(left, right, path + "[" + str(i) + "]", differences)
    elif before != after:
        entry = {"path": path, "published": before, "recomputed": after}
        if type(before) in (float, int) and type(after) in (float, int):
            entry["absolute_difference"] = abs(before - after)
        differences.append(entry)
    return differences

def main():
    if not __debug__ or sys.flags.optimize:
        raise ValueError("Original sealed verifier requires active assertions")
    marker = EVIDENCE / "ORIGINAL_VERIFY_STARTED.json"
    write_new(marker, {"started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                       "pid": os.getpid(), "single_execution": True})
    started = time.monotonic()
    cpu_started = time.process_time()
    result = {"schema": "hepta.mosi.original-saved-prediction-replay.v1",
              "source_commit": "4f80d069218e5416be0f51323a9db46b461d07dd",
              "raw_commit": "4b84b0431b089ccac84c75ac3ac19f96ad804fe4",
              "python": sys.version, "python_executable": sys.executable,
              "platform": platform.platform(), "assertions_enabled": __debug__,
              "environment": {k: os.environ.get(k) for k in
                              ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                               "PYTHONOPTIMIZE", "PYTHONDONTWRITEBYTECODE")},
              "priority_nice": os.getpriority(os.PRIO_PROCESS, 0),
              "new_forward": False, "new_training": False, "producer_timing_remeasured": False,
              "original_scientific_directory_read": False,
              "designs": DESIGNS, "shared": SHARED,
              "scope_override_matches_fresh_driver": True}
    exit_code = 1
    try:
        require(json.loads((EVIDENCE / "TRANSFER_VERIFY_RESULT.json").read_bytes())["status"] == "PASS", "transfer failed")
        require(sha(ROOT / "source" / "verify.py") == VERIFY_SHA, "verifier source changed")
        require(sha(ROOT / "data.json") == DATA_SHA, "original data changed")
        index = json.loads((ROOT / "transfer" / "INDEX.json").read_bytes())["objects"]
        before_hashes = {entry["name"]: sha(RAW / entry["name"]) for entry in index}
        require(all(before_hashes[e["name"]] == e["sha256"] for e in index), "fixed raw changed before replay")
        require(not (ROOT / "derived").exists(), "derived output already exists")
        spec = importlib.util.spec_from_file_location("original_mosi_saved_prediction_verify", ROOT / "source" / "verify.py")
        module = importlib.util.module_from_spec(spec)
        with (EVIDENCE / "original-verify.stdout.log").open("x", encoding="utf-8") as stdout, (
              EVIDENCE / "original-verify.stderr.log").open("x", encoding="utf-8") as stderr:
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                spec.loader.exec_module(module)
                module.DESIGNS = DESIGNS
                module.SHARED = SHARED
                original_argv = sys.argv
                sys.argv = [str(ROOT / "source" / "verify.py"), str(RAW / "models"),
                            str(RAW / "cold"), str(ROOT / "data.json"),
                            str(RAW / "FRESH_SEAL.json"), str(ROOT / "derived")]
                result["original_verifier_argv"] = sys.argv.copy()
                try:
                    module.main()
                finally:
                    sys.argv = original_argv
        result["original_verifier_exit"] = 0
        result["numpy"] = module.np.__version__
        require("torch" not in sys.modules, "unexpected model runtime import")
        output = {}
        for name in ("SUMMARY.json", "all_intact_models.json"):
            published = RAW / "result" / name
            recomputed = ROOT / "derived" / name
            differences = compare_values(json.loads(published.read_bytes()), json.loads(recomputed.read_bytes()))
            output[name] = {"published_sha256": sha(published), "recomputed_sha256": sha(recomputed),
                            "bytes_identical": published.read_bytes() == recomputed.read_bytes(),
                            "json_differences": len(differences)}
            if differences:
                write_new(EVIDENCE / (name + ".differences.json"), differences)
                output[name]["max_absolute_numeric_difference"] = max(
                    (item.get("absolute_difference", 0) for item in differences), default=0)
        result["outputs"] = output
        after_hashes = {entry["name"]: sha(RAW / entry["name"]) for entry in index}
        require(before_hashes == after_hashes, "replay modified original copied inputs")
        require(sha(ROOT / "data.json") == DATA_SHA, "replay changed original data")
        result["copied_inputs_unchanged"] = True
        result["scope"] = json.loads((ROOT / "derived" / "SUMMARY.json").read_bytes())["scope"]
        result["status"] = "PASS" if all(x["bytes_identical"] for x in output.values()) else "REPLAY_COMPLETED_WITH_DIFFERENCES"
        result["interpretation"] = "Actual sealed saved-prediction arithmetic replay with the recovered producer data manifest. It is not new forward inference, model training, or independent physical remeasurement of the reported costs."
        exit_code = 0 if result["status"] == "PASS" else 2
    except BaseException:
        result["status"] = "FAIL"
        result["exception"] = traceback.format_exc()
    finally:
        result["wall_s"] = time.monotonic() - started
        result["cpu_s"] = time.process_time() - cpu_started
        result["self_peak_rss_KiB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        result["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result["exit_code"] = exit_code
        write_new(EVIDENCE / "ORIGINAL_VERIFY_RESULT.json", result)
        print(json.dumps(result, sort_keys=True))
    return exit_code

if __name__ == "__main__":
    raise SystemExit(main())
