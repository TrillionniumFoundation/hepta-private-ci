"""Freeze the narrow data-closure patch and actual evidence; do not run tests or science."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
PACKAGE_REL = "qualification/mosi-replay-data-closure-20261128"
PACKAGE = ROOT / "candidate" / PACKAGE_REL
PARENT = "54c8fe3c8f04b1871d64e360463fcb576a3906d4"
PRODUCTION = "qualification/hcsn_sustained_20261128/mosi_recovery/publish_mosi.py"
TEST = "qualification/hcsn_sustained_20261128/mosi_recovery/test_publish_mosi.py"
HELPERS = ["qualification/hcsn_sustained_20261128/crema/publish_results.py",
           "qualification/hcsn_sustained_20261128/crema/archive.py"]
DATA_SHA = "968dfb23d19f7ba50c9907b2146810e09922283b4b4342618e8d2eac151c4f70"
REPLAY_SHA = "3dae2445f9c8ba10956514b6414bf2672f62bb0b6f4d2f8cef2fc5324f9d1656"
FORMAT_SHA = "08f03b0f01b8126fadbef2a0082a4accf73510afdaefa3ed97c331d6310d8914"

def require(condition, message):
    if not condition:
        raise ValueError(message)

def identities(payload):
    return {"size": len(payload), "sha256": hashlib.sha256(payload).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(payload)).encode() + b"\0" + payload).hexdigest()}

def write_new(path, payload):
    if not isinstance(payload, bytes):
        payload = payload.encode("utf-8")
    with path.open("xb") as handle:
        handle.write(payload)

def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode("utf-8")

def read_json(path):
    return json.loads(path.read_bytes())

def archived_json(archive, path):
    member = archive.getmember(path)
    require(member.isfile() and member.size <= 65536, "unexpected archived evidence JSON")
    with archive.extractfile(member) as handle:
        return json.load(handle)

def functions(source):
    return {node.name: node for node in ast.walk(ast.parse(source))
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}

def outside_function(source, name):
    node = functions(source)[name]
    lines = source.splitlines(keepends=True)
    return "".join(lines[:node.lineno - 1]), "".join(lines[node.end_lineno:])

def main():
    evidence = ROOT / "evidence"
    originals = {path: (ROOT / "baseline" / path).read_bytes()
                 for path in [PRODUCTION, TEST] + HELPERS}
    candidates = {path: (ROOT / "candidate" / path).read_bytes()
                  for path in [PRODUCTION, TEST] + HELPERS}
    require(identities(candidates[PRODUCTION])["sha256"] ==
            "ba76f99405fab27c1c21ee579602202c096cac9fea2abcaf0c7e0bf025e17f8e", "tested production changed")
    require(identities(candidates[TEST])["sha256"] ==
            "041a353c9bb78438f7430e4bff54240d6ebef346004db147e631272a96b57ac4", "tested tests changed")
    require(all(originals[path] == candidates[path] for path in HELPERS), "immutable helper changed")
    require(outside_function(originals[PRODUCTION].decode(), "fresh_map") ==
            outside_function(candidates[PRODUCTION].decode(), "fresh_map"),
            "production diff escapes fresh_map")
    original_tests = functions(originals[TEST].decode())
    candidate_tests = functions(candidates[TEST].decode())
    existing = sorted(name for name in original_tests if name.startswith("test_"))
    require(len(existing) == 15, "unexpected existing control count")
    preserved = [name for name in existing
                 if ast.dump(original_tests[name], include_attributes=False) ==
                    ast.dump(candidate_tests[name], include_attributes=False)]
    require(preserved == existing, "existing control function changed")
    added = sorted(name for name in candidate_tests
                   if name.startswith("test_") and name not in original_tests)
    require(len(added) == 6, "unexpected new control count")
    scope = {
        "parent_remote_commit": PARENT,
        "parent_tree": "408843f80d6cbdc807cb47ea5b5d977f0fab9b59",
        "extracted_fixed_sources_not_full_checkout": True,
        "production_diff_only_function": "fresh_map",
        "production_prefix_and_suffix_bytes_unchanged": True,
        "existing_15_test_function_ASTs_unchanged": preserved,
        "new_control_methods": added,
        "fixture_changes": [
            "Replace relay's time module binding with SimpleNamespace; leave shared stdlib time.sleep used by Python3.14 subprocess.wait intact while retaining no-wait Mock.",
            "After fresh_fixture constructs its actual Git tree, set the mocked publication return to that new exact commit."
        ],
        "sources": {path: {"baseline": identities(originals[path]),
                           "tested_final": identities(candidates[path])} for path in candidates},
        "scientific_training_and_original_verifier_source_changed": False,
        "full_publisher_concurrent_input_snapshot_qualification": "Not claimed; separate audit scope."
    }
    write_new(evidence / "SOURCE_SCOPE_FINAL.json", json_bytes(scope))
    patch = ""
    for path in (PRODUCTION, TEST):
        patch += "".join(difflib.unified_diff(originals[path].decode().splitlines(keepends=True),
                                            candidates[path].decode().splitlines(keepends=True),
                                            fromfile="a/" + path, tofile="b/" + path))
    write_new(evidence / "final.patch", patch)
    recovery_path = ROOT.parent / "evidence" / "MOSI_ORIGINAL_DATA_RECOVERY.json"
    recovery = read_json(recovery_path)
    require(recovery["sha256"] == DATA_SHA and recovery["size"] == 3083, "recovery identity differs")
    write_new(evidence / "MOSI_ORIGINAL_DATA_RECOVERY.json", recovery_path.read_bytes())
    data = (evidence / "real_original_data_968dfb23.json").read_bytes()
    require(identities(data)["sha256"] == DATA_SHA, "recovered original data differs")
    write_new(PACKAGE / "original-data-968dfb23.json", data)
    format_path = ROOT.parent / "root" / "SCIENCE_QUALIFICATION_FORMAT_RESULT.json"
    format_payload = format_path.read_bytes()
    require(identities(format_payload)["sha256"] == FORMAT_SHA, "format receipt changed")
    formatter = json.loads(format_payload)
    require(formatter["exit_code"] == 0, "format driver failed")
    for row in formatter["candidate_files"]:
        if row["path"] in (PRODUCTION, TEST):
            require(row["before_sha256"] == row["after_sha256"] ==
                    identities(candidates[row["path"]])["sha256"], "format receipt identity mismatch")
    write_new(evidence / "SCIENCE_QUALIFICATION_FORMAT_RESULT.json", format_payload)
    replay_payload = (PACKAGE / "original-replay.tar.gz").read_bytes()
    require(identities(replay_payload)["sha256"] == REPLAY_SHA, "replay archive differs")
    with tarfile.open(PACKAGE / "original-replay.tar.gz", "r:gz") as archive:
        replay = archived_json(archive, "evidence/ORIGINAL_VERIFY_RESULT.json")
        transfer = archived_json(archive, "evidence/TRANSFER_VERIFY_RESULT.json")
    require(replay["status"] == "PASS" and replay["exit_code"] == 0, "original replay failed")
    require(transfer["status"] == "PASS" and transfer["original_objects"] == 165, "raw identity failed")
    require(all(row["bytes_identical"] and row["json_differences"] == 0
                for row in replay["outputs"].values()), "replay differs from producer summary")
    addendum = {
        "historical_observations_preserved": [
            "At inspected older22f source raw publication was absent.",
            "Fixed4b84 primary manifest contains165 original payload objects and omits required fresh data.json.",
            "Initial original-verifier invocation with old4f80 SHAed0aff8abbc79b2b250bb7b6977e542741a1fbc6999013b720b41a6aafd60302 failed sealed data identity."
        ],
        "new_recovery": recovery, "recovered_data_artifact": PACKAGE_REL + "/original-data-968dfb23.json",
        "same_raw_commit": replay["raw_commit"], "original_verifier_commit": replay["source_commit"],
        "new_complete_saved_prediction_replay": replay,
        "producer_original_raw_commit_modified": False,
        "source_recovery_attributed_to_uninstalled_publisher_patch": False,
        "new_forward_or_training": False, "producer_timing_remeasured": False
    }
    write_new(evidence / "RECOVERY_ADDENDUM.json", json_bytes(addendum))
    review = {
        "reviewer": "/root/research_training",
        "actual_read_sha256": {path: identities(candidates[path])["sha256"] for path in (PRODUCTION, TEST)},
        "source_review": [
            "Same data path is explicitly seal-hashed, passed to original verifier and inserted into published mapping.",
            "All seven reserved root names are rejected unconditionally before terminal entries replace required inputs.",
            "Original165-object manifest and159 terminal keys do not conflict with seven reserved names.",
            "Original verifier reads36 fit JSON,36 prediction NPZ and adjacent receipts, fresh seal and exact data manifest; it does not itself open actual weight bytes.",
            "Fixture preserves no-wait Mock without replacing global time.sleep used by stdlib subprocess.wait.",
            "Fresh fixture updates mocked push result to its new actual Git commit, preserving remote-object validation."
        ],
        "dynamic_reserved_key_control": "Seven conflicting entries with deliberately different hash values executed.",
        "same_bytes_collision": "Rejected by unconditional membership gate in source review; no separate same-bytes subtest claimed.",
        "scientific_fixture_scope": "Synthetic publisher inputs and stubbed model arithmetic; not a scientific experiment."
    }
    write_new(evidence / "INDEPENDENT_SOURCE_REVIEW.json", json_bytes(review))
    transport = {
        "scope": "Only newly created isolated audit files; no producer directory access.",
        "first_small_chunks_write": "SSH transport failed before helper execution afterINDEX.json succeeded.",
        "reconciliation": "ExactCHUNKS.json read returnedFileNotFoundError; create-only write then succeeded.",
        "later_read_failures": "Some parallel bounded reads had transport errors; archive packaging used existing own PTY and exact-version-pinned sequential binary reads.",
        "original_verifier_executions_after_recovery": 1,
        "automatic_retry_or_unknown_job_restart": False,
        "bytes_transferred_chunks": 15455744, "chunk_count": 15,
        "copied_original_objects": 165, "canonical_manifest_additional_bytes": 22888,
        "no_network_or_host_configuration_changes": True
    }
    write_new(evidence / "TRANSFER_TRANSPORT_NOTES.json", json_bytes(transport))
    trials = {}
    for directory in ("baseline-15", "baseline-harnessfix-15", "candidate-21-attempt-02", "candidate-21-attempt-03"):
        trial = read_json(evidence / directory / "RESULT.json")
        trials[directory] = {key: trial[key] for key in ("tests", "failures", "errors", "skips", "successful", "wall_s")}
        trials[directory]["result_sha256"] = identities((evidence / directory / "RESULT.json").read_bytes())["sha256"]
    require(trials["candidate-21-attempt-03"]["tests"] == 21 and trials["candidate-21-attempt-03"]["successful"],
            "actual final controls unavailable")
    probe = read_json(evidence / "original-missing-data-probe" / "RESULT.json")
    members = []
    for path in sorted(evidence.rglob("*")):
        if path.is_file() and not any(part.startswith(".") for part in path.relative_to(evidence).parts):
            members.append(("evidence/" + str(path.relative_to(evidence)), path))
    for side in ("baseline", "baseline-harnessfix", "candidate"):
        for path in [PRODUCTION, TEST] + HELPERS:
            members.append(("source/" + side + "/" + path, ROOT / side / path))
    for name in ("native_control_runner.py", "native_control_runner_v2.py", "package_data_closure.py"):
        members.append(("drivers/" + name, ROOT / name))
    inventory = []
    control_path = PACKAGE / "controls.tar.gz"
    with control_path.open("xb") as dest:
        with gzip.GzipFile(filename="", mode="wb", fileobj=dest, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as archive:
                for name, path in sorted(members):
                    require(not path.is_symlink(), "symlink in owned evidence")
                    payload = path.read_bytes()
                    inventory.append({"path": name, **identities(payload)})
                    info = tarfile.TarInfo(name)
                    info.size = len(payload); info.mode = 0o644; info.mtime = 0
                    info.uid = info.gid = 0; info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(payload))
    controls_id = identities(control_path.read_bytes())
    require(controls_id["size"] < 500 * 1024 and len(replay_payload) < 500 * 1024, "evidence exceeds blob limit")
    result = {
        "schema": "hepta.mosi.publication-data-closure.v1",
        "parent_remote_commit": PARENT, "parent_tree": scope["parent_tree"],
        "status": "ENGINEERING_CONTROLS_AND_ORIGINAL_ARITHMETIC_REPLAY_PASS",
        "production_scope": "Only fresh_map data dependency inclusion and reserved original input keys",
        "sources": {path: identities(candidates[path]) for path in (PRODUCTION, TEST)},
        "timeline_of_actual_controls": trials,
        "first_failure_explanations": {
            "baseline-15": "Untouched15 had3 failures on Python3.14 because fixture patch of relay.time.sleep replaced stdlib time.sleep used by subprocess.wait.",
            "baseline-harnessfix-15": "Only fixture module binding corrected; all15 existing test function bodies unchanged;15/15pass.",
            "candidate-21-attempt-02": "20pass/1error: fixture push returned previous tree; receiver correctly refused absent provenance. Fixture now returns new fixed commit.",
            "candidate-21-attempt-03": "21/21 actual controls pass; no production validation bypass."
        },
        "original_mapping_counterexample": probe,
        "controls_scope": "Synthetic publisher fixtures plus real local Git commit/blob/tree objects. Model arithmetic and unused NumPy import explicitly stubbed; no live publish.",
        "reserved_key_coverage": "All7 conflicting-key cases executed; same-bytes rejection is unconditional source review, not another executed subcase.",
        "fresh_payload_count_before": 165, "fresh_payload_count_after": 166,
        "fresh_receipt_file_count_after_including_index": 167,
        "receipt_gate": "Old incomplete receipt stays unchanged and cannot skip or trigger republish on new manifest mismatch.",
        "actual_raw_transfer": {k: v for k, v in transfer.items() if k != "objects"},
        "recovered_original_data": recovery, "original_replay": replay,
        "format_command": {
            "receipt_sha256": FORMAT_SHA, "exit_code": formatter["exit_code"],
            "wall_seconds": formatter["wall_seconds"], "stdout": formatter["stdout"],
            "scope": formatter["scope"], "qualification": formatter["qualification"],
            "tests_reexecuted_after_format": False
        },
        "archives": {"controls.tar.gz": controls_id, "original-replay.tar.gz": identities(replay_payload)},
        "control_archive_members": len(inventory),
        "unchanged_boundaries": [
            "No new forward inference, training, scientific algorithm edit or producer timing remeasurement.",
            "Frozen missing-artifact and wrong-manifest failures remain historical evidence.",
            "Saved-prediction replay verifies saved results; it does not regenerate predictions from weights.",
            "Concurrent mutation safety between arithmetic verification, publication snapshot and hardlink staging is outside this narrow patch.",
            "Scientific quality and matched-quality speed conclusions are unchanged."
        ]
    }
    write_new(PACKAGE / "RESULT.json", json_bytes(result))
    readme = "# MOSI publication: include the exact replay data dependency\n\nThe original fresh_map ran the saved-prediction verifier with\nreconstructed/data.json, but omitted that file from its publication mapping.\nA receipt could therefore bind exactly to an incomplete mapping. The omitted\nfile determines the sealed data identity, feature-preparation cost and split\nvideo counts used by the verifier.\n\n## Change\n\nBased on commit 54c8fe3c8f04b1871d64e360463fcb576a3906d4, the production change is\nconfined to fresh_map. It explicitly verifies the existing data manifest\nagainst FRESH_SEAL.json, passes that same path to the original verifier and\nincludes it as data.json in the publication mapping. Terminal entries cannot\nreplace any of the seven required root objects. Source, quality, receipt,\nmanifest and fixed-commit object gates remain in force.\n\nA complete future fresh publication has 166 payload entries, or 167 objects\nincluding verified_objects.json. An older receipt binding the incomplete\nmapping is preserved and rejected; the patch does not silently upgrade it or\nrepublish after a failed resume.\n\n## Actual controls and retained failures\n\n| Attempt | Actual outcome | Interpretation |\n| --- | --- | --- |\n| Untouched existing suite | 12 pass, 3 fail of 15 | On Python 3.14 the fixture's global time.sleep patch also intercepted subprocess.wait. |\n| Existing suite with fixture isolated | 15/15 pass | Only the relay module's time binding is replaced; the no-wait assertion remains. |\n| Old mapper counterexample | Reproduced | The verifier receives the data path, but the old mapping, manifest and object expectations omit it. |\n| First new suite | 20 pass, 1 error of 21 | The fixture returned an earlier Git commit; the receiver correctly rejected missing provenance. |\n| Final candidate | 21/21 pass | The fixture now returns its new actual tree. All original fifteen test bodies remain unchanged. |\n\nThe six added methods cover the data path from the explicit hash gate through\nverifier arguments and published objects, correct new publication, missing or\nwrong local data, missing or wrong remote data over both API and real native Git\nreadback, old incomplete receipt retention, and all seven reserved-key\ncollisions. The collision tests use deliberately conflicting hash values;\nrejection of even a same-bytes collision follows from the unconditional\nmembership check and is not claimed as a separately executed subtest.\n\nThese controls use recognizable synthetic publisher fixtures and real local Git\nobjects. Model arithmetic and the unused NumPy import are explicitly stubbed.\nThey are publishing integrity controls, not scientific experiments. Complete\nfirst-failure logs, source preimages, local Git controls, final sources and\ninvocation records are in controls.tar.gz.\n\n## Actual original-data recovery and original verifier replay\n\nThe original data file was recovered without modification from its producer\npath. Its 3,083 bytes have the exact sealed SHA256\n968dfb23d19f7ba50c9907b2146810e09922283b4b4342618e8d2eac151c4f70.\nThe bytes are provided as original-data-968dfb23.json; the original host,\npath and file version are retained in the recovery receipt. The old missing\nobservation and the earlier rejection of a different ed0aff... manifest are\nnot rewritten.\n\nThe replay used only copies from fixed raw commit\n[4b84b0431b089ccac84c75ac3ac19f96ad804fe4](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/4b84b0431b089ccac84c75ac3ac19f96ad804fe4/qualification/hcsn_sustained_20261128/mosi_fresh_raw)\nand the recovered data, in a new isolated directory. All 165 original payload\nobjects and their original canonical index were checked by size, SHA256 and Git\nblob identity. All 159 terminal entries, 36 fit receipts and 49 actual weight\nobjects match their sealed identities. The original raw commit remains intact;\nthis package supplies the missing dependency separately.\n\nExactly one invocation of the original\n[verify.py at 4f80d069218e5416be0f51323a9db46b461d07dd](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/4f80d069218e5416be0f51323a9db46b461d07dd/qualification/hcsn_mosi_three_stream_20261127/verify.py)\nthen ran with the same enrolled DESIGNS and SHARED constants as the sealed\nfresh driver. Its source SHA256 is\nbdbb45e0ad4227ef2750bb7d35ca4d2035b1c9fd8257d2c4e2c7ed7fa76b17af.\nPython 3.12.3, NumPy 2.5.4, one BLAS/OpenMP thread and nice 10 were used.\n\nThe original arithmetic replay passed: 36 fit jobs, 108 eligible prefixes,\n684 prediction vectors and 469,224 scalar entries across three seeds,\n686 clips and 31 test videos. SUMMARY.json and all_intact_models.json are\nboth byte-identical to the published originals. Their SHA256 values are\nb4de92a5706d9b2d89373fa1cb7e965262bd0d3c38db54d25d4189689bdc65b7\nand 631692a3df88adc6c4b8490c6c6fdbafeb8024b0cfba9d3807b0b2f835f2ef11.\nThe invocation took 1.243905663 seconds with peak RSS 43,488 KiB. This is\narithmetic replay duration, not training duration.\n\noriginal-replay.tar.gz includes the original verifier, invocation wrapper,\nfixed-object inventory, actual stdout and result, copied seal/terminal/source\nmetadata, exact recovered data and derived outputs. No producer scientific\ndirectory was read during this replay, and all copied inputs retained their\nhashes. There was no forward inference, training or independent physical\nretiming. Weight-to-prediction computation is still the producer's execution;\nthe original verifier reads saved predictions and compares sealed weight\nidentities, while the separate transfer check hashes actual weight bytes.\n\n## Formatting and scope\n\nThe parent audit executed the exact original just fmt driver with seven\nrequired fixed-byte fixtures and a partial synthetic Git inventory containing\nfour actual qualification Python candidates, including these two files.\nIt exited zero in 0.127479410 seconds and reported that no changed files needed\nformatting. The formatter's language scope does not include qualification\nPython: this is not a Python-format qualification or full-repository formatting\nclaim. Both candidate SHA256 values remained unchanged and parsed successfully.\nThe exact receipt is archived. No controls or scientific replay were rerun\nafter formatting.\n\nThe original executor outage is also retained. The alternate host used fixed\nsource bundles rather than a full repository checkout; the publication parent\nand both tested source identities are explicit in RESULT.json.\n\nThis patch closes the data-dependency omission. It does not claim a coherent\nimmutable snapshot across every concurrent source mutation between arithmetic\nverification, publication snapshot and hardlink staging. It also changes none\nof the scientific quality or matched-quality speed gates. Restored arithmetic\nreproducibility does not establish a new foundation model or universal\nbackpropagation replacement.\n"
    write_new(PACKAGE / "README.md", readme)
    publish_paths = [PRODUCTION, TEST] + [PACKAGE_REL + "/" + name for name in
                    ("README.md", "RESULT.json", "controls.tar.gz", "original-replay.tar.gz", "original-data-968dfb23.json")]
    manifest = {
        "parent_remote_commit": PARENT, "parent_tree": scope["parent_tree"],
        "publication_status": "prepared; parent agent publishes",
        "tested_source_tree_constructed_from_exact_file_bytes": True,
        "full_local_git_commit_claimed": False,
        "files": [{"path": path, "native_path": str(ROOT / "candidate" / path), "mode": "100644",
                   **identities((ROOT / "candidate" / path).read_bytes())} for path in publish_paths],
        "control_archive_inventory": inventory,
        "all_new_blobs_under_500_KiB": all((ROOT / "candidate" / path).stat().st_size < 500 * 1024 for path in publish_paths),
        "new_source_or_tests_executed_during_packaging": False
    }
    write_new(ROOT / "PUBLICATION_MANIFEST.json", json_bytes(manifest))
    print(json.dumps({"manifest": str(ROOT / "PUBLICATION_MANIFEST.json"),
                      "manifest_identity": identities((ROOT / "PUBLICATION_MANIFEST.json").read_bytes()),
                      "files": manifest["files"], "control_archive_members": len(inventory)}, sort_keys=True))

if __name__ == "__main__":
    main()
