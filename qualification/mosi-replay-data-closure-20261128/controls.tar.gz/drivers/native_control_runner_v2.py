"""Fixed-source stdlib publisher controls; no scientific forward/training."""
from pathlib import Path
import ast
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import platform
import resource
import shutil
import subprocess
import sys
import time
import unittest

ROOT=Path('/home/qq/hepta-audit-20261128-5bdf/mosi-data')
REL=Path('qualification/hcsn_sustained_20261128/mosi_recovery')
EVIDENCE=ROOT/'evidence'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,record):path.write_text(json.dumps(record,indent=2,sort_keys=True,allow_nan=False)+'\n')
def record_source(root):
    result={}
    for path in sorted(root.rglob('*.py')):
        if '__pycache__' in path.parts:continue
        payload=path.read_bytes()
        result[str(path.relative_to(root))]={'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),
            'git_blob':hashlib.sha1(f'blob {len(payload)}\0'.encode()+payload).hexdigest()}
    return result

class Details(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.events=[]
    def addSuccess(self,test):
        self.events.append({'test':test.id(),'status':'PASS'});super().addSuccess(test)
    def addFailure(self,test,error):
        self.events.append({'test':test.id(),'status':'FAIL','detail':self._exc_info_to_string(error,test)});super().addFailure(test,error)
    def addError(self,test,error):
        self.events.append({'test':test.id(),'status':'ERROR','detail':self._exc_info_to_string(error,test)});super().addError(test,error)
    def addSkip(self,test,reason):
        self.events.append({'test':test.id(),'status':'SKIP','reason':reason});super().addSkip(test,reason)
    def addSubTest(self,test,subtest,error):
        self.events.append({'test':test.id(),'subtest':str(subtest),'status':'PASS' if error is None else 'FAIL'})
        super().addSubTest(test,subtest,error)

def suite(side,destination):
    source=ROOT/side
    sys.path.insert(0,str(source/REL))
    started=time.perf_counter()
    loaded=unittest.defaultTestLoader.discover(str(source/REL),pattern='test_publish_mosi.py')
    with (destination/'unittest.log').open('w') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=Details).run(loaded)
    receipt={'side':side,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skips':len(result.skipped),'successful':result.wasSuccessful(),'wall_s':time.perf_counter()-started,
        'python':sys.version,'platform':platform.platform(),'self_peak_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'children_peak_rss_KiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
        'source':record_source(source),'events':result.events,
        'scope':'Synthetic publisher controls with real local Git objects; model arithmetic and unused NumPy import are explicitly stubbed. No network publication, forward or training.'}
    write(destination/'RESULT.json',receipt)
    print(json.dumps({k:receipt[k] for k in ('side','tests','failures','errors','skips','successful','wall_s')}))
    return 0 if result.wasSuccessful() else 1

def original_probe(destination):
    baseline=ROOT/'baseline'/REL
    sys.path.insert(0,str(baseline))
    spec=importlib.util.spec_from_file_location('closure_fixture_tests',ROOT/'candidate'/REL/'test_publish_mosi.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    assert Path(module.relay.__file__).resolve()==(baseline/'publish_mosi.py').resolve()
    case=module.PublicationResumeTests('test_valid_receipts_read_current_sources_and_exact_git_objects')
    try:
        case.setUp();old=case.fresh_map_fixture()
        files=old(case.task);manifest,objects=module.relay.publication_snapshot(files)
        result={'source_parent_commit':'54c8fe3c8f04b1871d64e360463fcb576a3906d4',
            'original_mapper_sha256':sha(baseline/'publish_mosi.py'),
            'synthetic_only':True,'model_arithmetic_stub_calls':case.arithmetic_stub.call_count,
            'data_file_present':case.fresh_data.is_file(),'data_fixture_sha256':sha(case.fresh_data),
            'data_fixture_bytes':case.fresh_data.stat().st_size,'data_used_by_stub_path':str(case.fresh_data),
            'data_in_returned_mapping':'data.json' in files,'data_in_manifest':'data.json' in json.loads(manifest),
            'data_in_git_object_expectation':'data.json' in objects,
            'mapped_paths':sorted(files),'new_remote_publications':0,'forward_passes':0,'training_steps':0}
        result['omission_reproduced']=(case.arithmetic_stub.call_count==1 and all(not result[k] for k in
            ('data_in_returned_mapping','data_in_manifest','data_in_git_object_expectation')))
        write(destination/'RESULT.json',result)
        assert result['omission_reproduced']
        print(json.dumps({'original_omission_reproduced':True,'scientific_validation':False}))
        return 0
    finally:case.doCleanups()

def run():
    expected={
        'baseline-harnessfix':('2a7017e51c9149cd1de2efe7ac6f8ff7852188a422e959e91ab2105eccdacc4d','2ebed25af36ef5d169d99b831c901a7aa5895016a17418f4d4d27dc698c2b3a1'),
        'candidate':('ba76f99405fab27c1c21ee579602202c096cac9fea2abcaf0c7e0bf025e17f8e','6b019e2702605db3aeaa29e66ccd69ab72d06e1f3ed763eb29e7afb44736074f')}
    for side,hashes in expected.items():
        for filename,digest in zip(('publish_mosi.py','test_publish_mosi.py'),hashes):
            if sha(ROOT/side/REL/filename)!=digest:raise ValueError('source byte identity '+side+'/'+filename)
    steps=[('baseline-harnessfix-15','suite','baseline-harnessfix'),('original-missing-data-probe','probe',''),('candidate-21-attempt-02','suite','candidate')]
    receipts=[]
    for name,mode,side in steps:
        destination=EVIDENCE/name;destination.mkdir(exist_ok=False)
        command=[sys.executable,'-B',str(Path(__file__).resolve()),mode,side,str(destination)]
        start=time.perf_counter()
        run=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=45,
            env={**os.environ,'PYTHONOPTIMIZE':'','PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
        (destination/'stdout.log').write_text(run.stdout);(destination/'stderr.log').write_text(run.stderr)
        receipt={'name':name,'command':command,'exit_code':run.returncode,'wall_s':time.perf_counter()-start,
            'driver_sha256':sha(Path(__file__)),'source_bundle':'Exact pinned/source candidate files, not a complete repository checkout.'}
        write(destination/'EXECUTION.json',receipt);receipts.append(receipt)
        print(run.stdout,end='');print(run.stderr,end='')
        if run.returncode:break
    before=(ROOT/'baseline'/REL/'publish_mosi.py').read_text();after=(ROOT/'candidate'/REL/'publish_mosi.py').read_text()
    originals={node.name:ast.get_source_segment(before,node) for node in ast.parse(before).body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
    changes={node.name for node in ast.parse(after).body if isinstance(node,(ast.FunctionDef,ast.ClassDef))
        and originals.get(node.name)!=ast.get_source_segment(after,node)}
    write(EVIDENCE/'SOURCE_SCOPE_V2.json',{'changed_top_level_definitions':sorted(changes),'only_fresh_map':changes=={'fresh_map'},
        'parent_remote_commit':'54c8fe3c8f04b1871d64e360463fcb576a3906d4','parent_tree':'408843f80d6cbdc807cb47ea5b5d977f0fab9b59',
        'baseline':record_source(ROOT/'baseline'),'candidate':record_source(ROOT/'candidate')})
    assert changes=={'fresh_map'}
    real_data=ROOT.parent/'evidence/mosi-original-data-968dfb23.json'
    if real_data.exists():
        expected_sha='968dfb23d19f7ba50c9907b2146810e09922283b4b4342618e8d2eac151c4f70'
        assert real_data.stat().st_size==3083 and sha(real_data)==expected_sha
        retained=EVIDENCE/'real_original_data_968dfb23.json'
        if retained.exists():assert sha(retained)==expected_sha
        else:retained.write_bytes(real_data.read_bytes())
        write(EVIDENCE/'REAL_ORIGINAL_DATA_BINDING_V2.json',{'native_source':str(real_data),'bytes':3083,'sha256':expected_sha,
            'FRESH_SEAL_sha256':'fc024bfe4a11bcf1f95390efe0a32d2200cb532f11aa7c7c57fa15c601194858',
            'feature_prep_total_wall_s':json.loads(real_data.read_bytes())['feature_prep_total_wall_s'],
            'status':'Exact producer original recovered after the prior fixed Git inventory omission; retained separately from synthetic fixtures.',
            'new_independent_timing_or_forward':False,'historical_missing_reports_unchanged':True})
    write(EVIDENCE/'EXECUTIONS_V2.json',receipts)
    print(json.dumps({'finished':True,'all_commands_exit_zero':all(x['exit_code']==0 for x in receipts),
        'steps':len(receipts),'native_root':str(ROOT),'standard_just_paths':{p:Path(p).is_file() for p in
            ('/home/qq/.cargo/bin/just','/home/qq/.local/bin/just','/usr/local/bin/just','/usr/bin/just')}}))
    return 0 if len(receipts)==3 and all(x['exit_code']==0 for x in receipts) else 1

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'run'
    if mode=='suite':raise SystemExit(suite(sys.argv[2],Path(sys.argv[3])))
    if mode=='probe':raise SystemExit(original_probe(Path(sys.argv[3])))
    raise SystemExit(run())
