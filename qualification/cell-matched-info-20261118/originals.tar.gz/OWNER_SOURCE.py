import fcntl,hashlib,json,os,resource,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/qian-qi/work/hepta-e1-matched-info-20261118-2e9b')
SOURCE=ROOT/'source'
ARTIFACT=Path('/dev/shm/hepta-cell-experiments-v3-20261116-0c078a')
RUNTIME=Path('/home/qian-qi/hepta-cell-experiments-v3-20261116-0c078a')
OUTPUT=ARTIFACT/'research-matched-info-20261118-2e9b'
OWNED=ROOT/'owned-run-1'
RETAINED=ROOT/'retained'
STAGES=('freeze','train-final_only','train-all_actions','audit-training','frozen','retrieval','final_only','all_actions')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(json.dumps(v,sort_keys=True,allow_nan=False).encode()+b'\n');f.flush();os.fsync(f.fileno())
def checkpoint(stage):
 files={}
 if OUTPUT.exists():
  for p in sorted(OUTPUT.rglob('*')):
   if not p.is_file() or '__pycache__' in p.parts:continue
   name=str(p.relative_to(OUTPUT));expected=sha(p);q=RETAINED/name
   q.parent.mkdir(parents=True,exist_ok=True)
   if q.exists():assert sha(q)==expected,name
   else:
    with p.open('rb') as f,q.open('xb') as t:
     for b in iter(lambda:f.read(1048576),b''):t.write(b)
     t.flush();os.fsync(t.fileno())
    assert sha(q)==expected
   files[name]={'sha256':expected,'bytes':p.stat().st_size}
 write(OWNED/('CHECKPOINT-'+stage+'.json'),{'stage':stage,'retained':str(RETAINED),'files':files})
def main():
 OWNED.mkdir(exist_ok=False)
 deployment=json.loads((ROOT/'DEPLOYMENT.json').read_text())
 assert deployment['source_commit']=='992f2b3de51902448abf5743f94179bf40e11b6d'
 prior=Path('/home/qian-qi/work/hepta-e4-native-repair-20261118-2e9b/owned-run-1/EXIT.json')
 previous=json.loads(prior.read_text());assert previous['wait_returncode']==0 and previous['timed_out'] is False
 lock=ARTIFACT/'research-round03-20261118-392934-b/WORKER.lock'
 assert lock.is_file() and not lock.is_symlink()
 with lock.open('a+b') as held:
  fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB)
  gpu=subprocess.run(['/usr/bin/nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True)
  assert int(gpu.stdout.splitlines()[0])>=4096
  write(OWNED/'INTENT.json',{'source_commit':deployment['source_commit'],'source_tree':deployment['source_tree'],'deployment_sha256':sha(ROOT/'DEPLOYMENT.json'),'owner_source_sha256':sha(ROOT/'OWNER_SOURCE.py'),'previous_owner_exit_sha256':sha(prior),'lock':str(lock),'stages':STAGES,'planned_training_updates':128,'planned_evaluation_calls':96,'automatic_retry':False,'started_at_ns':time.time_ns()})
  env=dict(os.environ,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1')
  for stage in STAGES:
   for name,expected in deployment['files'].items():assert sha(SOURCE/name)==expected,name
   command=[str(RUNTIME/'venv/bin/python'),'-I','-B',str(SOURCE/'scripts/cell_experiments/run_matched_info_v4.py'),stage,'--artifact-root',str(ARTIFACT),'--output',str(OUTPUT)]
   if stage=='freeze':command+=['--code-commit',deployment['source_commit']]
   directory=OWNED/stage;directory.mkdir(exist_ok=False)
   started=time.perf_counter();usage=resource.getrusage(resource.RUSAGE_CHILDREN)
   write(directory/'INTENT.json',{'stage':stage,'argv':command,'started_at_ns':time.time_ns(),'automatic_retry':False})
   timed_out=False
   with (directory/'STDOUT.txt').open('xb') as out,(directory/'STDERR.txt').open('xb') as err:
    child=subprocess.Popen(command,cwd=SOURCE,env=env,stdout=out,stderr=err,start_new_session=True)
    write(directory/'STARTED.json',{'pid':child.pid,'process_group_id':child.pid,'started_at_ns':time.time_ns()})
    try:code=child.wait(timeout=1800 if stage.startswith('train-') else 900)
    except subprocess.TimeoutExpired:
     timed_out=True;os.killpg(child.pid,signal.SIGTERM)
     try:code=child.wait(timeout=30)
     except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=30)
   after=resource.getrusage(resource.RUSAGE_CHILDREN)
   receipt={'stage':stage,'wait_returncode':code,'exit_source':'subprocess.Popen.wait','timed_out':timed_out,'wall_seconds':time.perf_counter()-started,'completed_child_user_cpu_seconds':after.ru_utime-usage.ru_utime,'completed_child_system_cpu_seconds':after.ru_stime-usage.ru_stime,'stdout_sha256':sha(directory/'STDOUT.txt'),'stderr_sha256':sha(directory/'STDERR.txt'),'full_system_cost_known':False,'nested_costs_are_not_additive':True,'automatic_retry':False}
   write(directory/'EXIT.json',receipt);checkpoint(stage);print(json.dumps(receipt),flush=True)
   if code:write(OWNED/'FAILED.json',receipt);return 1
  write(OWNED/'COMPLETE.json',{'status':'COMPLETE','stages':STAGES,'retained':str(RETAINED),'GPU_released_after_owner_exit':True})
 return 0
try:
 code=main()
except BaseException as error:
 if OWNED.exists() and not (OWNED/'WRAPPER_FAILED.json').exists():write(OWNED/'WRAPPER_FAILED.json',{'error_type':type(error).__name__,'error':str(error),'automatic_retry':False})
 raise
raise SystemExit(code)
