# Laya terminal evidence, observed 2026-10-18 16:46 UTC

The exact-source CI job 117713314446 in run 39140341757 completed success at f191cd081ba16fed8827a18093b5a5b39e9a36cd. Its new, hash-verified artifact contains 64 fresh real typed-Reader invocations: 16 registered tasks times four evidence arms. It is not a historical report replay. See LAYA_TERMINAL_CHECKPOINT.json for the source/log/receipt chain and the independent receipt-arithmetic checks.

Evidence-condition accuracy and top1 gold fraction are separate metrics. The report contains 12,422 SDK-reported input tokens and 63.7905 seconds of evaluation wall time. It does not provide the 40 independent calibration samples plus 72 nine-arm inference target, independent factual gold qualification, complete hardware/FLOPs/energy/cost receipts or production permission. The runtime warning refers specifically to the choice:11+ temperature clamp; applicability to the heads used here is not established by that warning alone. Independent calibration receipts remain absent.

The original artifact ZIP SHA-256 was checked against both the GitHub API and job log before parsing its three non-weight JSON members. No checkpoint weights are present in this bundle. The workflow and evaluator source files are copies fetched at exact head f191cd. The job log is the full decoded job log returned by the GitHub connector. The terminal-log-excerpts.json file gives the exact supporting line references.

No workflow rerun, dispatch, full CI refresh, repository mutation or GitHub blob upload was performed for this terminal check. Source-level and sample arithmetic review do not constitute independent verification of every gold fact, nor do these jobs close required checks.

At this agent's handoff there are no unfinished recoverable tool cells and no local background processes launched by this agent. Earlier stalled upload calls were interrupted and yielded no success response; archive publishing belongs to root. Other agents' shared-host processes were not rescanned in this narrowly scoped read.

Research remains SHADOW_ONLY / DENY_ALL / NO_GO.
