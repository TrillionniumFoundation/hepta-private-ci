# PR #2599 fixture context correction

Remote source-head job 117713683668 at 19c5cd41 found two E0599 errors introduced by the earlier e214 fixture patch. The correction is e69455587d2709c34b6b1832ed1aa4fca9025aeb plus strict source-map child a4728553d2f09242640400719d82257bc9c63c73. Old failure evidence is in final-ci-pre-repair-evidence.tar.gz.

Only two Rust lines were added before existing context propagation; production code, Wiremock expectations, and all non-identity map claims remain unchanged. The independent reviewer traced all 43 new context calls and identified only these two analogous gaps; that was static review, not a workspace compilation.

The initial reduced rustc probe used an existing read-only anyhow 1.0.104 rlib. LOCKED_RUST_TYPE_PROBE.json supersedes its dependency identity: exact locked anyhow 1.0.103, crate SHA256 matched Cargo.lock, and all 54 cached package source files matched that archive. The isolated offline/locked Cargo compiler reproducer fails before with both E0599 errors and compiles after. It is not the complete Hepta workspace or a platform/native integration gate. The probe Cargo.toml records the actual cache path used in this environment.

Original strict migration ran on the real clean source commit. The final clean maps-child retains the same 26 global qualification failures as 19c5; runtime.agentd migration and derived-check pass. Existing non-ancestor anchors and the original validator are unchanged.

The original pre-repair CI observation and the new-head queued jobs have separate timestamps. No old-source success transfers to a472. Required CI and production promotion remain unqualified. No workspace native tests or local model inference ran in this correction. The reduced compiler commands completed; no background processes were launched.
