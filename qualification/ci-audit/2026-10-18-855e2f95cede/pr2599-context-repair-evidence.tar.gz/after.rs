#![allow(dead_code)]
use anyhow::Context;
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProviderEffectBindingError {
    EmptyField(&'static str),
    InvalidKey(String),
    InvalidDigest(String),
    SchemaVersion,
    KeyMismatch,
    PayloadMismatch,
    UnsupportedCapability,
    NotFound,
    Unknown,
    Conflict,
    AckConflict,
    InvalidAckSource,
    StatusObservationSourceRequired,
    InvalidReasonCode,
}
fn provider(value: Result<(), ProviderEffectBindingError>) -> anyhow::Result<()> { value.map_err(|error| anyhow::anyhow!("{error:?}")).context("provider key") }
fn contract(value: Result<(), String>) -> anyhow::Result<()> { value.map_err(anyhow::Error::msg).context("contract digest") }
