from pathlib import Path
import json, hashlib, shutil, datetime
root = Path("/workspace/scratch/855e2f95cede/audit")
out = Path("/dev/shm/hepta-root-delivery-855e2f95cede")
out.mkdir(exist_ok=True)
def read(p): return json.loads((root/p).read_text())
def write(p, s): (out/p).write_text(s.rstrip()+"\n")
env=read("environment/host_snapshot.json")
inventory=read("github_inventory/inventory_summary.json")
p2599=read("PR2599_PUBLISHED_CHECKPOINT.json")
p2714=read("PR2714_PUBLISHED_CHECKPOINT.json")
blockers=read("ci_audit/blockers.json")
for b in blockers:
    if b["id"] in ("CI-001","CI-003"):
        b["status"]="FIX_PUSHED_NATIVE_AND_REQUIRED_CI_PENDING"
        b["repair_head"]=p2599["head"]
        b["repair_source_commit"]="e21417abcedda77d73a08b1417522966dc2d1c0a"
        b["repair_owner"]="PR #2599 / root"
        b["next"]="Run canonical just test plus required Clippy/platform checks at 19c5cd41 with enough disk; no merge until genuine required success."
blockers.extend([
 {"id":"MAP-QUALIFICATION","status":"FAILED_26_MODULES","owner":"Per-module source-map owners","root":"Strict global qualification still fails on 26 modules. Three affected maps retain a non-ancestor baseline anchor.","next":"Review original provenance and actual source with each owner. Do not bypass checked_identity, invent parents or transfer execution claims."},
 {"id":"NATIVE-DISK","status":"BLOCKED_EXTERNAL","owner":"Accessible executor resource owner","root":"Overlay available disk is zero; the native resource preflight stopped before Cargo began.","next":"Use an accessible independent build workspace with enough disk. Preserve concurrent owners and the canonical test/Clippy/platform gates."},
 {"id":"RESEARCH-DECLARATIONS","status":"FIX_PUSHED_REQUIRED_CI_PENDING","owner":"PR #2714","root":"Five stages close reproduced declaration, evidence-class overwrite and malformed boolean issues in the reviewed nine-file set.","next":"Verify exact f191cd08 required checks; contract tests and boolean statements are not independent scientific qualification."},
 {"id":"MEMORY-FRESH-112","status":"BLOCKED_EXTERNAL_RESOURCE_AND_NO_GO","owner":"PR #1452 / independent evidence reviewer","root":"Historical 40+72 rows are distinct from the failed fresh attempt (6 calibration / 0 evaluation). No completed new-model receipts were created by this audit.","next":"Use a worker fitting the pinned model and locked protocol, start a new batch, finish 40 calibration then 72 nine-arm calls, independently review answers/citations/holdout/cost."},
 {"id":"SHARED-STEM-EMPIRICAL","status":"SHADOW_ONLY_NO_GO","owner":"PR #2695 and Shared Stem owners","root":"Contracts and shared representation code do not establish measured capability, negative transfer, resource cost or multimodal performance.","next":"Run pinned shared-versus-replicated ablations with budget receipts, isolation, negative-transfer and forgetting measurements."},
 {"id":"OS-FINAL-USE","status":"UNQUALIFIED","owner":"Hepta #2815 -> Desktop #193 -> #194; A04/A05/A06/A07","root":"Observed native effect dispatcher supports QueryAbi; remaining operations, durable delivery, G1/G2 and Final-use qualification are incomplete.","next":"Verify the same-head stack and complete authenticated broker/Final-use positive and negative cases on real native platforms. Missing authority continues to deny effects."},
 {"id":"FULL-SEMANTIC-COVERAGE","status":"NOT_COMPLETE","owner":"Feature and integration owners","root":"All Hepta branch/PR metadata and branch git graph relations were enumerated; not every diff/review/historical job/scientific artifact was audited.","next":"Continue by owner DAG. Verify semantic superiority and exact current gates before closing, deleting or merging."}
])
cp={
 "schema":"hepta.recovery-checkpoint.v1",
 "created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
 "repository":"TrillionniumFoundation/hepta-private-ci",
 "repository_path":"qualification/ci-audit/2026-10-18-855e2f95cede",
 "host":env["host"],
 "source_main":"f8c9419df6ddeb36ff8b522a50219981fb8d9345",
 "evidence_labels":["VERIFIED_NOW","HISTORICAL_CLAIM","HISTORICAL_EXECUTION_RECOUNTED_NOW","NOT_ACCESSIBLE","INFERRED"],
 "environment":{"utc":env["completed_utc"],"scope":env["scope"],"worktrees_observed":len(env["repositories"]),"processes_observed":len(env["processes"]),"overlay_free_bytes":env["disk"]["free_bytes"],"external_hosts":env["external_hosts"]},
 "inventory":inventory,
 "branch_graph":read("github_inventory/branch_graph_complete_summary.json"),
 "published_repairs":[p2599,{k:v for k,v in p2714.items() if k!="ci_snapshot"}],
 "latest_postpush_ci":{"observed_interval_utc":["2026-10-18T15:37:00Z","2026-10-18T15:38:59Z"],"pr2599":{"runs":4,"checks":11,"jobs":11},"pr2714":{"runs":5,"checks":6,"jobs":6},"jobs_queued":17,"run_statuses":{"queued":8,"pending":1},"required_aggregators":"ABSENT; no success inferred","source":"ci-evidence.tar.gz"},
 "queue_snapshot":read("QUEUE_METRICS.json"),
 "organization_utilization":"NOT_ACCESSIBLE; observed job counts do not establish capacity",
 "completed_new_model_receipts_this_audit":0,
 "model_cost_this_audit":{"local_inference_calls":0,"local_tokens":0,"local_inference_seconds":0,"scope":"No local model run. The pushed existing remote Reader workflow remains queued at the recorded snapshot; future receipts require separate verification."},
 "research_posture":"SHADOW_ONLY / DENY_ALL / NO_GO",
 "merge_count":0,"forced_ref_updates":0,"workflow_cancellations":0,
 "protection_or_validator_weakened":False,"all_blockers_closed":False,
 "blockers":blockers,"next_commands":"REPRODUCE.md"
}
write("CHECKPOINT.json",json.dumps(cp,ensure_ascii=False,indent=2))
write("BLOCKERS.json",json.dumps(blockers,ensure_ascii=False,indent=2))
for a,b in [
("environment/RUNNING_TASKS.md","RUNNING_TASKS.md"),
("environment/host_snapshot.json","host_snapshot.json"),
("environment/capture_environment.py","capture_environment.py"),
("github_inventory/BRANCH_PR_DAG.md","BRANCH_PR_DAG.md"),
("github_inventory/FINAL_PR2599_MAP_RECEIPT.json","FINAL_PR2599_MAP_RECEIPT.json"),
("github_inventory/PR2599_MAP_FINAL.md","PR2599_MAP_FINAL.md"),
("RUNNER_QUEUE.md","RUNNER_QUEUE.md"),
("QUEUE_METRICS.json","QUEUE_METRICS.json"),
("SCHEDULER_SOURCE_AUDIT.json","SCHEDULER_SOURCE_AUDIT.json"),
("analyze_scheduler_snapshot.py","analyze_scheduler_snapshot.py"),
("PR2599_PUBLISHED_CHECKPOINT.json","PR2599_PUBLISHED_CHECKPOINT.json"),
("PR2714_PUBLISHED_CHECKPOINT.json","PR2714_PUBLISHED_CHECKPOINT.json")]:
 shutil.copyfile(root/a,out/b)
queue_extra="""

## Exact workflow source and zero-job runs

The exact main blobs of 51 workflow concurrency definitions were verified. Among the 441 observed nonterminal runs, 296 had no jobs in the fully paginated latest-attempt response: 255 had no branch in the branch snapshot, 32 had a different branch source SHA, and 9 matched. Those records do not establish occupied or available runners. The 96 repeated workflow/branch groups are review candidates; no automated cancellation was performed. See SCHEDULER_SOURCE_AUDIT.json.

No scheduling policy was changed. Administration access is needed to establish runner groups, online/busy totals, actual organization ceilings and the safety of a capacity change. No utilization improvement or queue reduction is claimed.
"""
write("RUNNER_QUEUE.md",(out/"RUNNER_QUEUE.md").read_text()+queue_extra)
lines=["# Current blocker disposition","",f"Compiled {cp['created_utc']}. This is an open-blocker checkpoint.","","| ID | Status | Owner | Next action |","|---|---|---|---|"]
for b in blockers:
 lines.append("| "+" | ".join(str(b.get(k,"")).replace("|","/") for k in ("id","status","owner","next"))+" |")
lines += ["","BLOCKERS.json retains original run/job IDs, source SHAs and failure locations. Full logs and commands are in ci-evidence.tar.gz. A repair commit is not a merge or a terminal required-check success.","","Strict source-map qualification is a separate remaining gate. The observed blocking contract gate uses the development profile; do not assert that the 26 qualification failures caused a queued job to fail."]
write("BLOCKERS.md","\n".join(lines))
ci_intro="""# CI matrix: latest repair heads and earlier failure evidence

## Pushed source heads, second observation

Observed 2026-10-18 15:37-15:38 UTC. Source identity, pagination totals and latest attempt 1 were checked.

| PR | Source head | Base observed | Runs / checks / jobs | Current observed state |
|---|---|---|---:|---|
| #2599 | 19c5cd41c17dd42da7afac96203a4bc7901e23a6 | f8c9419df6ddeb36ff8b522a50219981fb8d9345 | 4 / 11 / 11 | All jobs queued |
| #2714 | f191cd081ba16fed8827a18093b5a5b39e9a36cd | e08323af4805ed9a8d14afabf2212923195f2156 | 5 / 6 / 6 | All jobs queued |

The 9 runs consist of 8 queued and 1 pending. CI required and Architecture required have not been generated; absence is not success. No execution event occurred between the first and second observations.

Current prospective merge objects have the expected source/base parents and trees equal to the source trees. Their merge commit SHAs differ from source SHAs by design; full identities are in ci-evidence.tar.gz.

## Actual local validation

| Scope | Result | Qualification limit |
|---|---|---|
| #2714 final package | 109 tests pass, 0 fail/error/skip | Synthetic Python contracts, no model inference |
| Independent frozen stages | 98 and 102 tests pass | Separate overlapping stages, not added to 109 |
| Independent final repairs | 5 calibration + 10 harness focused tests pass | Verified original negative cases are rejected |
| #2599 formatting / diff / derived check | PASS | Rust 1.95.0 and canonical just fmt; no native compiler qualification |
| Four repaired source maps | PASS | Strict source identity/object checks |
| All module-map qualification | FAIL, 26 modules | main 29 -> source-only 30 -> final 26 |
| Native Cargo/Clippy/three platforms | BLOCKED_EXTERNAL, not started | No available native build disk |

Required main contexts observed through the branch summary are CI required and Architecture required (app 15368). The full protection endpoint returned 403, so no unseen rule is assumed satisfied. The local strict qualification profile is separate from current workflow development gates.

## Earlier selected-subject evidence

The following source report retains its original timestamps and HEADs. It is not an all-PR or full-history CI inventory.

"""
write("CI_MATRIX.md",ci_intro+(root/"ci_audit/CI_MATRIX.md").read_text())
report="""# HEPTA 开发接力执行 checkpoint — 2026-10-18

## 本轮已经写入远端的结果

本轮共向两个既有 PR 快进推送 7 个提交，未强推、未合并、未修改保护规则或校验器。两条修复都保持原分支和实际依赖关系。所有尚未完成的门禁继续计为未闭合。

| 修复线 | 当前 HEAD | 已实施变更 | 本地验证 |
|---|---|---|---|
| [#2599](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/2599) | 19c5cd41c17dd42da7afac96203a4bc7901e23a6 | 四份 Rust 测试文件/测试区块改用 typed Result 传递错误；原严格 CLI 更新四份源码映射 | Rustfmt、diff、derived check 通过；4 maps 通过；原生测试未启动 |
| [#2714](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/2714) | f191cd081ba16fed8827a18093b5a5b39e9a36cd | Reader/Harness/Stem 显式证据声明、校准等级不可覆盖、拒绝非布尔 authority marker；5 个可审查阶段、9 文件 | 最终 109 项 Python 契约测试通过；独立分阶段复核通过 |

#2599 保留全部断言和平台限制，未引入 #1350 所依赖的 218 个 Intuition 功能提交。四份映射仅更新 sourceBase/sourceObjects，执行、激活与验收声明完全不变。三个旧映射的锚点不在 main 祖先链上，原迁移器正确拒绝；本轮保留其原文和失败证据。全库严格资格结果是 main 29 个失败模块、源码候选 30 个、最终候选 26 个，不能称为全库通过。详细对象与原始日志见 PR2599_MAP_FINAL.md、FINAL_PR2599_MAP_RECEIPT.json 和归档。

#2714 修复了可实际复现的证据完整性问题：缺失声明曾被有利默认值填充；caller 曾能把明确 LOCAL 的 calibration 改为 REAL_SHADOW；Stem 曾接受字符串或未知值；可选 authority marker 曾接受 null、整数 0、浮点 0.0。新行为明确拒绝这些情况。布尔声明本身不证明科学独立性，全部输出仍 DENY_ALL，研究继续 SHADOW_ONLY / NO_GO。

## 真实环境与权限

可访问主机是 2313cba36518。15:30:22 UTC 快照观察到 16 个 worktree 和 11 个可见进程；进程、cwd、dirty 文件、输出位置及遮蔽后的 argv 在 RUNNING_TASKS.md 和 host_snapshot.json。该主机未被独立识别为用户指定的 Dot/Hepta 专用工作机；没有已验证的项目 SSH 路径，因此其他主机状态为 NOT_ACCESSIBLE。

本会话已实际验证 GitHub 读、创建 Git 对象和按 expected SHA 快进更新既有分支的能力。完整 branch protection 读取返回 403，runner 管理端点不在插件允许范围内；无法据此统计 org 的 online/busy、runner groups、并发配额或利用率。

主机可见 9 CPU、cgroup 配额 8 核、内存上限 8 GiB。overlay 可用空间为 0。原生构建预检在 Cargo 启动前拒绝，因此没有把“未执行”计为通过。独占 tmpfs 完整 checkout 用于真实提交与源码映射验证；未删除并行 owner 的工作区、模型权重或缓存。该临时目录易失，唯一证据已归档入仓。

## 全量基础清点及其边界

Hepta 在 14:20:04-14:23:41 UTC 的完整分页快照为：

- 2,519 个唯一分支；26 个数据页，随后空页。
- 2,846 个 PR；29 个数据页，随后空页。
- Open 1,553，其中 Draft 1,526、非 Draft 27。
- Closed 1,293，其中 merged 315、closed-unmerged 978。
- 2,519 条分支相对 main 的 git 图关系全部核验：same 2、包含 main 且 ahead 289、only-behind 28、divergent 2,200。
- Open PR base-ref DAG 共 1,250 条边，未发现环；684 个分支未关联 PR，仅记录事实，不判定应删除。

完整 raw 页、页哈希、normalized inventory、git graph 与 DAG 在 inventory-evidence.tar.gz。BRANCH_PR_DAG.md 说明了实际依赖。该结果不等于完成 2,846 个 PR 的逐 diff/review/历史 CI/科学材料语义审查；名称分类只作候选，不能授权淘汰或合并。

PON 对比实际确认 #1504 的 wrapper 通过 4/4 故障注入单元测试，#1501 同组为 2 pass / 2 fail；这证明了该 wrapper 在日志管道错误传播上的改进，未证明完整 Bazel/PoN/平台资格。#1508 对当前 #1468 缺少大量基线提交，#1509 的两份自有提交只改两文件格式。旧 PR 顺序不能替代当前语义与依赖核验。

## CI 与队列

15:37-15:38 UTC 第二次新 HEAD 快照：#2599 的 11 个 jobs 与 #2714 的 6 个 jobs 全部 queued；两项 required 汇总检查均未生成。没有任何一条达到可合并条件。详细新旧 SHA、run/job IDs、错误日志和根因见 CI_MATRIX.md、BLOCKERS.json 和 ci-evidence.tar.gz。

14:31:49-14:32:35 UTC 对 441 个非终态 run 的完整 latest-attempt job 分页读取，共 1,587 个 jobs：494 queued、168 in_progress、393 success、137 failure、220 cancelled、175 skipped。队列年龄中位数 24.56 分钟、p95 61.62 分钟、最大 76.99 分钟。成功数包含各 job 的局部结果，绝不是完整 required-CI 通过数。

其中 296 个非终态 run 没有 job 记录；它们不是 runner 占用证明。所有队列数都是有明确时间窗口的观测，不能推出 org 空闲容量。对 exact main 的 51 份 workflow concurrency 源码已校验，当前证据不足以安全改变 org 资源策略；未执行取消、重跑、改 labels 或减平台覆盖率。

## 模型实验和 OS 联动

本轮没有启动本地真实模型推理，新增完成的模型 receipts 为 0。历史档案确有 40 calibration + 72 nine-arm 行，但属于 10 月 13-14 日运行；不能替代新 HEAD 的新实验。另一 owner 的 10 月 18 日 fresh attempt 完成 6 个 calibration 答案、0 evaluation，第七次没有返回后 watchdog 终止。两个批次不得拼接。本轮推送触发的既有远端 Reader workflow 仍处于排队观测，后续须按其实际 receipts 单独核验。

64 次 Laya Reader / 四臂指标保留为历史局部证据。缺独立 heldout calibration、完整设备/概率/FLOPs/内存/能源 join，继续 HOLD_NO_GO。共享 Encoder、NDU/System2 和多模态方向仍需真实受控消融与预算测量，不能用这 109 项契约测试证明能力提升。

OS 仓库在 15:22:56-15:23:29 UTC 完整清点 167 branches、185 PR；open 20（Draft 16、非 Draft 4）、merged 109、closed-unmerged 56。main 为 f9e306f76154590e096a42f70ce9de0a7c859e60。#193 在所观察 HEAD 有 7 checks / 4 runs success；#194 是 0 checks / 0 runs，不能计绿。仍是 Hepta #2815 -> Desktop #193 -> #194 的未合并依赖栈。

该桌面项目具备可继续整合的接口与权限契约基础。当前被审查 native effect dispatcher 只支持 QueryAbi，其他控制操作返回不支持；G1/G2、生产 issuer、持久递交/撤销和 Final-use 资格未完整闭合。因此目前不能将其当作已具生产资格的桌面/移动端控制器。详见 research-os-evidence.tar.gz 中的完整审计与 20 个 open PR 的检查表。

## 下一阶段

BLOCKERS.md/BLOCKERS.json 为未闭合清单，REPRODUCE.md 为固定 SHA 的可执行验证入口。优先在可访问且有独立磁盘的原生 worker 上完成 #2599 的 Cargo/Clippy/三平台验证，同时处理当前精确 HEAD 的真实 CI 失败；继续保持源码映射原身份、科学资格和外部 effect 权限的拒绝边界。

本 checkpoint 的结论是“修复已推送、证据已归档、门禁未闭合”。没有后台本地训练或编译被宣称仍在运行。远端 queued run 仅按实际 run ID 和观测状态记录。
"""
write("README.md",report)
repro="""# Reproduce and continue

Use an independently writable clone with enough build disk. Read the repository AGENTS.md first; Rust tests must use the canonical just test entry. Do not write into another active owner's worktree.

## Exact source retrieval

~~~bash
git clone --no-checkout https://github.com/TrillionniumFoundation/hepta-private-ci.git hepta-recovery
cd hepta-recovery
git fetch origin fix/ci-clippy-expect-unwrap-20261017 research/real-reader-intake-p4-20261017
git worktree add ../hepta-2599-19c5cd41 19c5cd41c17dd42da7afac96203a4bc7901e23a6
git worktree add ../hepta-2714-f191cd08 f191cd081ba16fed8827a18093b5a5b39e9a36cd
~~~

Each command must be checked for success. Before any later mutation, GET the PR again and compare its current head/base/state. An advanced branch requires semantic reconciliation; never force it over another owner.

## Research contract suite

Run in the #2714 worktree:

~~~bash
python3 -B -m unittest discover -v -s qualification/neuron-shared-encoder/tests -p 'test_*.py'
~~~

The recorded final result is 109 tests / 109 pass / 0 error / 0 skip. These are synthetic contract tests. Exact touched paths, old/new Git blobs, Ruff commands, negative baseline regressions and stage-specific logs are in research-os-evidence.tar.gz and ci-evidence.tar.gz.

## Clippy and native fixtures

Run in the #2599 worktree with the repository-pinned Rust toolchain and dependencies. These native commands are NEXT ACTIONS, not tests completed by this audit:

~~~bash
just test --locked -p codex-hepta-fleet --lib -E 'test(authority_port)'
just test --locked -p codex-hepta-agentd --test kernel_evidence_product --test plasticity_process_e2e
~~~

Then execute the exact workflow's Clippy commands with its deny flags and all required Windows/macOS/Linux targets. Preserve platform-specific test fences, canonical SQLite adapters, signing/authority tests and coverage.

Recorded static checks:

~~~bash
just fmt --base f8c9419df6ddeb36ff8b522a50219981fb8d9345
git diff --check 1ebb9b8a9313e6504d2ebf9597412f3fe9c49d9e 19c5cd41c17dd42da7afac96203a4bc7901e23a6
python scripts/hepta-implementation-maps.py verify --profile qualification
python scripts/hepta-module-docs.py verify --profile qualification
python scripts/hepta-module-docs.py refresh-derived --check
~~~

The two qualification commands are expected to retain the recorded 26-module failure set on this head. Do not bypass a failed ancestor check through internal helper functions. The source-map archive includes the exact original commands and complete failure output.

## Required GitHub evidence

Use authenticated GitHub plugin GET requests for the PR, commit check-runs, combined statuses and actions/runs filtered by the exact head. Follow every page. For each run follow every latest-attempt job page and verify run ID, source SHA, attempt and any synthetic merge's parents/tree. Required contexts observed are CI required and Architecture required; full administrative protection visibility was not available.

The first two post-push snapshots contain 17 queued jobs and absent aggregators. Queued, pending, missing, cancelled, skipped, metadata-only and old-SHA success are not complete required-check success. No merge was performed.

## Memory experiment

Inspect PR #1452 at 2a0e8d016f5e00359561934909e801ae26f2bfd7 and its locked strong_rag_shards.py protocol before invoking a model. Admit an adequate worker and create a fresh output batch. Complete 40 calibration calls, then 72 nine-arm inference calls, retaining per-sample answers, citation/source provenance, model/prompt/dataset hashes, device/seed/temperature and measured tokens/latency/resources. Do not append the six failed-attempt responses to a different historical batch. Independent calibration and scientific acceptance remain necessary even if counts are met.

## Archive verification

FILES.json and ARCHIVES.json list file and archive SHA-256/Git blob identities. Each evidence archive includes a member manifest. Verify hashes before using its receipts; retain their original timestamps and observation scope. Source code remains recoverable from the exact pushed commits. Never upload model weights or invent missing physical measurements.
"""
write("REPRODUCE.md",repro)
write("build_delivery_provenance.json",json.dumps({"created_utc":cp["created_utc"],"input_root":str(root),"output_root":str(out),"purpose":"Repository-backed checkpoint; no network or Git mutation by this builder"},indent=2))
files=[]
for p in sorted(out.iterdir()):
 if p.is_file() and p.name!="FILES.json":
  b=p.read_bytes()
  files.append({"path":p.name,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob_sha":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest(),"lines":len(b.splitlines())})
write("FILES.json",json.dumps({"created_utc":cp["created_utc"],"files":files},ensure_ascii=False,indent=2))
print(json.dumps({"out":str(out),"files":len(files),"bytes":sum(f["bytes"] for f in files),"lines":sum(f["lines"] for f in files)}))
