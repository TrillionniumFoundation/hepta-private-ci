"""Bounded remote replay of exposed historical MDV S, never confirmation."""
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import tarfile
import time

sys.dont_write_bytecode = True
started = time.monotonic()
raw = sys.stdin.buffer.read(1024 * 1024 + 1)
assert len(raw) <= 1024 * 1024
payload = json.loads(raw)
root = Path('/home/qian-qi/work/cell-common-dev-e1c98-001')
root.mkdir(exist_ok=False)
(root / 'INPUT.json').write_bytes(raw)
sources = {}
for name, entry in payload['files'].items():
    relative = Path(name)
    assert not relative.is_absolute() and '..' not in relative.parts
    data = entry['content'].encode()
    assert hashlib.sha256(data).hexdigest() == entry['sha256']
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)
    sources[name] = {'bytes': len(data), 'sha256': entry['sha256']}
sys.path.insert(0, str(root / 'driver' / 'scripts'))
from cell_repo_mdv.compare import compare
from cell_repo_mdv.contracts import digest
from cell_repo_mdv.memory import initial_state

task = json.loads((root / 'original' / 'task2.json').read_text())
corpus = json.loads((root / 'original' / 'corpus.json').read_text())
candidate = json.loads((root / 'original' / 'state.json').read_text())
receipt = json.loads((root / 'original' / 'result.json').read_text())
parent = initial_state(corpus)
original_task = json.loads(json.dumps(task))
old_workspace = task['workspace']
task['task_id'] = 'repo-dev/e1c98-exposed-S-terminal-comparison-001'
task['environment']['CARGO_TARGET_DIR'] = str(root / 'target')
task['environment']['PYTHONPATH'] = str(root / 'driver' / 'scripts')
task['source']['before_status'] = ''
for key in list(task['source']['before_pins']):
    if key.endswith('.otf'):
        del task['source']['before_pins'][key]
font_step = {
    'kind': 'observe',
    'argv': ['python3', 'apps/hepta-control-ui/tools/prepare-fonts.py',
             '--cache', '/home/qian-qi/work/cell-ui-ime-20261108-08b6-evidence/runtime-assets',
             '--offline', '--install', 'apps/hepta-control-ui/rust/robrix-ui/resources/fonts'],
    'timeout_seconds': 30,
}
for steps in task['recipes'].values():
    for step in steps:
        step['argv'] = [v.replace(old_workspace + '/apps/', '../apps/') for v in step['argv']]
    steps.insert(0, json.loads(json.dumps(font_step)))
frozen = {
    'schema': 'hepta.repo-mdv.exposed-S-replay-profile.v1',
    'driver_commit': payload['driver_commit'],
    'driver_tree': payload['driver_tree'],
    'driver_materialization': 'exact Git-bound Python source subset; not full native checkout',
    'sources': sources,
    'task_source': task['source'],
    'historical_input_sha256': digest(original_task),
    'task': task,
    'corpus_sha256': digest(corpus),
    'parent_state_sha256': digest(parent),
    'candidate_state_sha256': digest(candidate),
    'candidate_receipt_sha256': digest(receipt),
    'arm_order': ['no_update', 'bm25', 'fixed_expert', 'candidate'],
    'fixed_expert': 'native-clippy-borrow',
    'cache_profile': 'new target directory at campaign start; shared sequentially across arms; existing Cargo and pinned font caches',
    'not_a_latency_comparison': True,
    'requested_resource_envelope': {'cpu_quota_percent': 200, 'memory_max_bytes': 8589934592, 'timeout_seconds': 4200},
    'configuration_changes': [
        'fresh successor task ID and output',
        'font materialization is now an explicit charged step in every arm',
        'before-pins describe clean source; original font hashes remain in after-pins',
        'manifest path is relative to just codex-rs working directory to address each clone',
        'driver PYTHONPATH and initially absent target directory are rebound',
    ],
    'independent_tasks': 0,
    'new_training_updates': 0,
    'scientific_status': 'HOLD',
    'production_status': 'not_adopted',
    'frozen_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(root / 'FROZEN.json').write_text(json.dumps(frozen, indent=2) + '\n')
(root / 'parent-state.json').write_text(json.dumps(parent) + '\n')
result = {'status': 'started', 'scientific_status': 'HOLD', 'independent_tasks': 0}
try:
    env = dict(os.environ, **task['environment'])
    check = subprocess.run(['cargo', 'nextest', '--version'], env=env, capture_output=True, timeout=20)
    (root / 'nextest.stdout').write_bytes(check.stdout)
    (root / 'nextest.stderr').write_bytes(check.stderr)
    assert check.returncode == 0
    print(json.dumps({'stage': 'comparison-start', 'root': str(root), 'driver_commit': payload['driver_commit']}), flush=True)
    report = compare(task, corpus, root / 'comparison', parent=parent, candidate=candidate,
                     candidate_receipt=receipt, fixed_document=frozen['fixed_expert'],
                     arm_order=tuple(frozen['arm_order']))
    result.update(status='completed', terminal_comparison_complete=report['terminal_comparison_complete'],
                  arms=report['arms'], errors=report['errors'], costs=report['costs'],
                  source_unchanged_verified=report['source_unchanged_verified'])
except Exception as error:
    result.update(status='failed', error={'type': type(error).__name__, 'message': str(error)})
finally:
    result['driver_sources_unchanged'] = all(
        hashlib.sha256((root / name).read_bytes()).hexdigest() == pin['sha256']
        for name, pin in sources.items())
    result['outer_wall_seconds'] = time.monotonic() - started
    result['outer_scope'] = 'controller from stdin read through final result, excludes final serialization/archive and remote dispatch/transfer'
    result['completed_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (root / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    members = [p for p in root.iterdir() if p.is_file()]
    members += list((root / 'original').rglob('*')) + list((root / 'driver').rglob('*.py'))
    comparison = root / 'comparison'
    if comparison.is_dir():
        members += [p for p in comparison.iterdir() if p.is_file()]
        members += list((comparison / 'preparation').rglob('*'))
        for arm in frozen['arm_order']:
            arm_root = comparison / arm
            if arm_root.is_dir():
                members += [p for p in arm_root.iterdir() if p.is_file()]
                members += list((arm_root / 'execution').rglob('*'))
    members = sorted({p for p in members if p.is_file()})
    manifest = [{'path': str(p.relative_to(root)), 'bytes': p.stat().st_size,
                 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in members]
    (root / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
    with tarfile.open(root / 'evidence.tar.gz', 'w:gz') as tar:
        for path in [*members, root / 'MANIFEST.json']:
            tar.add(path, arcname=str(path.relative_to(root)), recursive=False)
    archive = (root / 'evidence.tar.gz').read_bytes()
    print(json.dumps({'result': result, 'archive_bytes': len(archive), 'archive_sha256': hashlib.sha256(archive).hexdigest()}), flush=True)
assert result['status'] == 'completed' and result['terminal_comparison_complete']
