"""Pinned SmolLM2 Cell inference, joint LoRA measurement and research export.

The original Chain source owns loading, encoding, decoding and material checks.
This bridge edits only fixed Q/V factors; it never trains, qualifies or installs.
"""
from contextlib import contextmanager
import hashlib
import importlib.metadata
import importlib.util
import math
import os
from pathlib import Path
import sys
import tempfile

from .artifacts import file_sha256
from .errors import checksum, digest, integer, loads, need, WeightError
from .patches import squared_norm, tensor_sha256
from .providers import TorchProvider

MODEL = "HuggingFaceTB/SmolLM2-135M-Instruct"
REVISION = "12fd25f77366fa6b3b4b768ec3050bf629380bac"
SOURCE_COMMIT = "c96022b897c1235fdbdbfcfa32764403511c6aab"
# Complete executed source/config closure, plus the original Q32 scorer profile.
SOURCE_PINS = {
    "scripts/llm_runtime_pilot.py": "65ccc6454befd96fa5ce1f5bdde2c56cb6cbb741cf495b8d24a758039f99f755",
    "scripts/llm_parent_material.py": "5396d72c4730aea2d271b55a8404f6eaba64dc57f91343537710c28f7686b43c",
    "scripts/llm_neural_read_worker.py": "791fbe67ae7d2b2e0551e5f9f6fd77797ed9f8c210e7ca47f9acb6ac02895769",
    "formal/pon-nakamoto-v1/llm_adapter_contract.py": "e46311a08584ad7becfc56cd0b699d9bc6921adcfe39319e50aa14faa984ced5",
    "formal/pon-nakamoto-v1/contract_wire.py": "cbe45d72ad20ed5683d50dceaa97b93bc74cdafced7d0896386edf9cbe9f98f6",
    "config/pon/model-family-smollm2-135m-v1.json": "0837bbfb31f3f2b9a8731545c9f742aee1ebd32daed392a936a3ec9719537e52",
    "config/pon/ledger-v1.json": "6755e36aab0ab9f4743da331a8dcd3374d657ff80f027ecf28db922e6d5ea39a",
    "config/pon/work-profile-v1.json": "03f7537b2fc3fa0c2f7036dd73d7088ba1ce50eafe6f2c907087d30385320880",
    "config/pon/model-family-v1.json": "30b250db074e7fbb5776c1474371258a6110cc1742e0e9970232a799ab790ca1",
    "config/pon/devnet-v1.json": "4491b96ead11a020e8d71f27713368b65e663eef5cfc6fd0800a166b0c2a20d4",
}
TARGETS = sorted([
    {"module": f"model.layers.{layer}.self_attn.{projection}", "in_features": 576,
     "out_features": 576 if projection == "q_proj" else 192, "rank": 4, "alpha": [8, 1]}
    for layer in range(30) for projection in ("q_proj", "v_proj")
], key=lambda target: target["module"])
FACTOR_SHAPES = {
    target["module"] + suffix: shape for target in TARGETS
    for suffix, shape in ((".A", (4, 576)), (".B", (target["out_features"], 4)))
}
ACTION_TOKENS = (10407, 4607)
ACTION_IDS = (
    "memory-82aaf7382d0b835b69cb7508f53ff8c4d18d25f25ae9e9437f928ab5c70860a8",
    "memory-9b91d44953ed21ffd72efd3798d8b396aaaf285be044c44ee8f40cb6919f678c",
)
MODES = ("conditional_binary", "next_token", "greedy_8")
NO_AUTHORITY = {name: False for name in (
    "installation_authorized", "selection_authorized", "independent_accepted",
    "prospective_accepted", "public_reward_eligible", "hepta_final_use",
    "production_activation", "production_eligible",
)}


def validate_factors(factors, complete=True):
    """Require all actual F32 values, including finiteness absent from wire checks."""
    import torch
    need(isinstance(factors, dict) and (set(factors) == set(FACTOR_SHAPES) if complete
         else set(factors) <= set(FACTOR_SHAPES)), "PATCH_SCOPE", "Expected canonical Q/V factor names only")
    for name, tensor in factors.items():
        need(isinstance(tensor, torch.Tensor) and tensor.device.type == "cpu"
             and tensor.dtype == torch.float32 and tuple(tensor.shape) == FACTOR_SHAPES[name]
             and not tensor.is_sparse and not tensor.is_quantized,
             "SHAPE_MISMATCH", "Cell factors must have the fixed CPU F32 shape", tensor=name)
        need(bool(torch.isfinite(tensor).all()), "NONFINITE", "Nonfinite Cell factor", tensor=name)
    return factors


def factor_delta_metrics(parent, replacements):
    """Joint products in FP64 characterize the stored FP32 factors, not execution."""
    import torch
    validate_factors(parent)
    validate_factors(replacements, complete=False)
    physical, modules = [], []
    for name, value in sorted(replacements.items()):
        before = parent[name]
        delta = value.double() - before.double()
        physical.append({"parameter": name, "parent_sha256": tensor_sha256(before),
                         "candidate_sha256": tensor_sha256(value),
                         "changed_coordinates": int(torch.count_nonzero(before != value)),
                         "delta_squared_norm": squared_norm(delta)})
    for module in sorted({name.rsplit(".", 1)[0] for name in replacements}):
        a, b = parent[module + ".A"], parent[module + ".B"]
        new_a, new_b = replacements.get(module + ".A", a), replacements.get(module + ".B", b)
        before = 2.0 * (b.double() @ a.double())
        after = 2.0 * (new_b.double() @ new_a.double())
        delta = after - before
        need(bool(torch.isfinite(delta).all()), "NONFINITE", "Nonfinite effective LoRA delta")
        parent_squared, delta_squared = squared_norm(before), squared_norm(delta)
        modules.append({"module": module, "changed_coordinates": int(torch.count_nonzero(before != after)),
                        "delta_l2": math.sqrt(delta_squared), "delta_max_abs": float(delta.abs().max()),
                        "parent_adapter_l2": math.sqrt(parent_squared),
                        "adapter_relative_norm": math.sqrt(delta_squared / parent_squared) if parent_squared else None,
                        "parent_a_all_zero": not bool(torch.count_nonzero(a)),
                        "parent_b_all_zero": not bool(torch.count_nonzero(b)),
                        "candidate_a_all_zero": not bool(torch.count_nonzero(new_a)),
                        "candidate_b_all_zero": not bool(torch.count_nonzero(new_b)),
                        "parent_effective_sha256": tensor_sha256(before),
                        "candidate_effective_sha256": tensor_sha256(after)})
    physical_count = sum(item["changed_coordinates"] for item in physical)
    effective_count = sum(item["changed_coordinates"] for item in modules)
    physical_tensors = sum(item["parent_sha256"] != item["candidate_sha256"] for item in physical)
    return {"schema": "hepta.weight.smollm2-lora-measurement.v1",
            "expression": "2*(B_candidate@A_candidate-B_parent@A_parent)",
            "measurement_dtype": "float64_from_stored_float32_factors",
            "physical_changed_coordinates": physical_count, "physical_changed_tensors": physical_tensors,
            "physical_delta_l2": math.sqrt(sum(item["delta_squared_norm"] for item in physical)),
            "effective_changed_coordinates": effective_count,
            "effective_delta_l2": math.sqrt(sum(item["delta_l2"] ** 2 for item in modules)),
            "physical_change_without_effective_change": physical_tensors > 0 and effective_count == 0,
            "execution_no_op_proven": physical_tensors == 0,
            "physical": physical, "modules": modules, "execution_equivalence_claimed": False,
            "limitation": "A zero algebraic delta is not proof of identical nested FP32 execution; probe actual outputs"}


@contextmanager
def _import_paths(paths):
    original = list(sys.path)
    try:
        sys.path[:0] = [str(path) for path in paths]
        yield
    finally:
        sys.path[:] = original


def verify_source_pins(root, pins, policy):
    need(pins == SOURCE_PINS, "IDENTITY_MISMATCH", "Unsupported Chain source closure")
    need(os.environ.get("TRNM_PON_EVALUATION_POLICY", "legacy-first-two-v3") == "legacy-first-two-v3",
         "INVALID_MODEL", "The pinned Cell contract requires the original wire parameters")
    root = policy.read(root, directory=True)
    for relative, expected in SOURCE_PINS.items():
        policy.bound(root / relative, expected, 2 * 1024 * 1024)
    return root


def _source_modules(root):
    """Import the audited closure; refuse a previously imported different tree."""
    paths = (root / "scripts", root / "formal/pon-nakamoto-v1")
    sources = {"contract_wire": paths[1] / "contract_wire.py",
               "llm_adapter_contract": paths[1] / "llm_adapter_contract.py",
               "llm_runtime_pilot": paths[0] / "llm_runtime_pilot.py",
               "llm_parent_material": paths[0] / "llm_parent_material.py"}
    loaded = {}
    with _import_paths(paths):
        for name, path in sources.items():
            existing = sys.modules.get(name)
            if existing is not None:
                need(Path(existing.__file__).resolve() == path.resolve(), "IDENTITY_MISMATCH",
                     "Chain source imported from another tree", module=name)
                loaded[name] = existing
                continue
            raw = path.read_bytes()
            need(hashlib.sha256(raw).hexdigest() == SOURCE_PINS[path.relative_to(root).as_posix()],
                 "IDENTITY_MISMATCH", "Chain source changed before import", module=name)
            spec = importlib.util.spec_from_file_location(name, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            try:
                # Compile checked bytes, bypassing an unrelated/stale .pyc cache.
                exec(compile(raw, str(path), "exec"), module.__dict__)
            except BaseException:
                sys.modules.pop(name, None)
                raise
            loaded[name] = module
    return loaded["llm_runtime_pilot"], loaded["llm_parent_material"], loaded["llm_adapter_contract"]


def _original(call, *args, **kwargs):
    try:
        return call(*args, **kwargs)
    except (ValueError, KeyError, TypeError, OSError, OverflowError, RecursionError) as exc:
        raise WeightError("CELL_CONTRACT", "Original Chain contract rejected material or input",
                          {"check": getattr(call, "__name__", "source"), "reason": str(exc)[:512]}) from exc


def _put_bytes(store, data, extension, kind):
    need(len(data) <= store.max_artifact_bytes, "ARTIFACT_LIMIT", "Cell material exceeds artifact limit")
    fd, name = tempfile.mkstemp(prefix=".pending-", dir=store.root)
    temporary = Path(name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        return store._commit(temporary, extension, kind, {})
    finally:
        temporary.unlink(missing_ok=True)


def _dependency_versions():
    result = {}
    for name in ("transformers", "peft", "safetensors", "tokenizers", "numpy"):
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            result[name] = None
    return result


class SmolLM2Provider(TorchProvider):
    name = "smollm2_cell"
    task_kind = "causal_language_model"

    def __init__(self, module, tokenizer, runtime, parent_material, contract_api,
                 contract, contract_raw, parent, parent_raw, plan, identity, store,
                 source_root, policy, allowed_targets=None):
        import torch
        need(contract["targets"] == TARGETS, "INVALID_MODEL", "Unsupported Cell target geometry")
        self.tokenizer, self.runtime, self.parent_material, self.contract_api = tokenizer, runtime, parent_material, contract_api
        self.contract, self.contract_raw, self.parent, self.parent_raw = contract, contract_raw, parent, parent_raw
        self.plan, self.source_root, self.policy = plan, source_root, policy
        self.factor_tensors = dict(runtime.adapter_tensors(module, TARGETS))
        validate_factors(self.factor_tensors)
        self.parent_factors = {name: value.detach().cpu().clone() for name, value in self.factor_tensors.items()}
        self.parent_factor_hashes = {name: tensor_sha256(value) for name, value in self.parent_factors.items()}
        self.base_weights = {target["module"]: module.get_base_model().get_submodule(target["module"]).get_base_layer().weight
                             for target in TARGETS}
        allowed = sorted(FACTOR_SHAPES) if allowed_targets is None else allowed_targets
        need(isinstance(allowed, list) and len(set(allowed)) == len(allowed)
             and set(allowed) <= set(FACTOR_SHAPES), "PATCH_SCOPE", "Only canonical Cell factors are editable")
        super().__init__(module, identity, store, allowed)
        factor_ids = {id(value) for value in self.factor_tensors.values()}
        self.parameters = {name: value for name, value in self.parameters.items() if id(value) not in factor_ids}
        self.parameters.update(self.factor_tensors)
        self.aliases.update({name: name for name in self.factor_tensors})
        need([tokenizer.encode(word, add_special_tokens=False) for word in ("yes", "no")]
             == [[value] for value in ACTION_TOKENS], "IDENTITY_MISMATCH", "Answer token identities differ")
        self.backend.update(numeric_dtype="float32", attention="eager", use_cache=False,
                            deterministic_algorithms=torch.are_deterministic_algorithms_enabled(),
                            source_commit=SOURCE_COMMIT, source_pins=SOURCE_PINS, dependencies=_dependency_versions())
        self.backend_id = digest(self.backend)
        self.last_probe_metrics = {"feature_cache_enabled": False}

    def _global_squared_norm(self):
        import torch
        omitted = {id(value) for value in (*self.factor_tensors.values(), *self.base_weights.values())}
        total = 0.0
        for value in self.module.parameters():
            if id(value) not in omitted:
                need(bool(torch.isfinite(value).all()), "NONFINITE", "Nonfinite backbone")
                total += squared_norm(value)
        for name, base in self.base_weights.items():
            effective = base.detach() + 2.0 * (self.factor_tensors[name + ".B"] @ self.factor_tensors[name + ".A"])
            need(bool(torch.isfinite(effective).all()), "NONFINITE", "Nonfinite effective projection")
            total += squared_norm(effective)
        return total

    def _check_parent(self):
        need(all(tensor_sha256(self.factor_tensors[name]) == expected
                 for name, expected in self.parent_factor_hashes.items()),
             "IDENTITY_MISMATCH", "Loaded parent factors changed outside a temporary probe")

    def compile_tensor(self, name, value):
        validate_factors({name: value}, complete=False)
        return super().compile_tensor(name, value)

    @contextmanager
    def temporary_patch(self, replacements):
        validate_factors(replacements, complete=False)
        need(set(replacements) <= self.allowed_targets, "PATCH_SCOPE", "Patch is outside the factor allowlist")
        self._check_parent()
        with super().temporary_patch(replacements):
            yield
        self._check_parent()

    def measure_patch(self, replacements):
        self._check_parent()
        need(set(replacements) <= self.allowed_targets, "PATCH_SCOPE", "Patch is outside the factor allowlist")
        result = factor_delta_metrics(self.parent_factors, replacements)
        result["global_effective_parent_l2"] = math.sqrt(self.global_squared_norm)
        result["global_norm_basis"] = "Unique parent weights with FP32 base+2*BA projections; factor parameters excluded"
        result["global_effective_weight_relative_norm"] = (
            result["effective_delta_l2"] / math.sqrt(self.global_squared_norm) if self.global_squared_norm else None)
        return result

    def prepare_inputs(self, inputs):
        import torch
        need(isinstance(inputs, dict) and set(inputs) <= {"prompt", "input_ids", "request_id", "mode"}
             and ("prompt" in inputs) != ("input_ids" in inputs),
             "INVALID_INPUT", "Supply one prompt or one already encoded sequence; labels are not inputs")
        mode = inputs.get("mode", "conditional_binary")
        need(mode in MODES, "INVALID_INPUT", "Unknown SmolLM2 output mode")
        prompt_hash = None
        if "prompt" in inputs:
            prompt = inputs["prompt"]
            need(isinstance(prompt, str) and 1 <= len(prompt.encode("utf-8")) <= 2048,
                 "INPUT_LIMIT", "Prompt must contain 1..2048 UTF-8 bytes")
            prompt_hash = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
            tokens = _original(self.runtime.prompt_tokens, self.tokenizer, {"prompt": prompt}, 128)
        else:
            tokens = inputs["input_ids"]
        need(isinstance(tokens, list) and 1 <= len(tokens) <= 128
             and all(type(value) is int and 0 <= value < 49152 for value in tokens),
             "INPUT_LIMIT", "Expected 1..128 vocabulary token IDs; truncation is rejected")
        request_id = inputs.get("request_id", digest(inputs))
        need(isinstance(request_id, str) and 1 <= len(request_id.encode("utf-8")) <= 128,
             "INVALID_INPUT", "Invalid request identity")
        ids = torch.tensor([tokens], dtype=torch.int64)
        mask = torch.ones_like(ids, dtype=torch.bool)
        positions = mask.to(torch.int64).cumsum(-1) - 1
        encoded = {"input_ids": ids, "attention_mask": mask, "position_ids": positions}
        encoded_identity = {name: value.tolist() for name, value in encoded.items()}
        output_contract = {"mode": mode, "vocabulary": 49152,
                           "generation_tokens": 8 if mode == "greedy_8" else 0,
                           "action_ids": list(ACTION_IDS) if mode == "conditional_binary" else None,
                           "action_tokens": list(ACTION_TOKENS) if mode == "conditional_binary" else None,
                           "scoring": "raw-float32-logits-times-2^32-round-even" if mode == "conditional_binary" else None}
        meta = {"examples": 1, "tokens": len(tokens), "input_id": digest(inputs),
                "model_input_id": digest({"encoded": encoded_identity, "output_contract": output_contract}),
                "encoded_input_id": digest(encoded_identity), "output_contract": output_contract,
                "prompt_sha256": prompt_hash, "request_id": request_id, "mode": mode,
                "input_encoding": "chat-template-once-no-extra-special-tokens" if prompt_hash else "already-encoded-token-ids",
                "output_scope": "fixed-eight-token-greedy" if mode == "greedy_8" else "last-position-vocabulary-logits",
                "conditional_class_order": ["yes", "no"] if mode == "conditional_binary" else None}
        return (mode, request_id), encoded, meta

    @contextmanager
    def probe_context(self, replacements, captures, interventions, force_uncached=False):
        self.last_probe_metrics = {"feature_cache_enabled": False, "use_cache": False,
                                   "instrumented": bool(captures or interventions)}
        yield

    def forward(self, args, kwargs):
        import torch
        mode, request_id = args
        if mode == "greedy_8":
            with _import_paths([]):
                receipt = _original(self.runtime.decode_tokens, self.module, self.tokenizer,
                    kwargs["input_ids"][0].tolist(), request_id, self.contract, self.parent["contract"],
                    self.plan, torch, torch.device("cpu"), artifact=self._current_adapter_id(),
                    role="weight-workbench-research-candidate")
            self.last_probe_metrics.update(profile="pon-greedy-lowest-token-id-fixed-eight-v1",
                model_forward_calls=8, generated_tokens=8,
                model_forward_token_positions=sum(kwargs["input_ids"].numel() + step for step in range(8)),
                decoder_receipt=receipt)
            return {"generated_token_ids": torch.tensor(receipt["response"]["generated_token_ids"], dtype=torch.int64),
                    "input_ids": kwargs["input_ids"]}
        output = self.module(**kwargs, use_cache=False)
        need(output.logits.dtype == torch.float32 and output.logits.device.type == "cpu"
             and tuple(output.logits.shape) == (1, kwargs["input_ids"].shape[1], 49152)
             and bool(torch.isfinite(output.logits).all()), "INVALID_OUTPUT", "Unexpected Cell logits")
        logits = output.logits[:, -1, :].contiguous()
        self.last_probe_metrics.update(profile="hepta-smollm-single-token-action-score-v1" if mode == "conditional_binary"
                                       else "hepta-smollm-last-position-logits-v1",
            model_forward_calls=1, model_forward_token_positions=kwargs["input_ids"].numel(),
            logits_sha256=hashlib.sha256(self.runtime.tensor_bytes(logits)).hexdigest())
        result = {"next_token_logits": logits, "input_ids": kwargs["input_ids"],
                  "attention_mask": kwargs["attention_mask"]}
        if mode == "conditional_binary":
            raw = logits[:, list(ACTION_TOKENS)]
            scores = [round(float(raw[0, index].item()) * (1 << 32)) for index in range(2)]
            need(all(-(1 << 63) <= value < (1 << 63) for value in scores),
                 "INVALID_OUTPUT", "Q32 action score exceeds int64")
            result.update(raw_action_logits=raw, scores_q32=torch.tensor([scores], dtype=torch.int64),
                          conditional_binary_probabilities=raw.softmax(-1))
            self.last_probe_metrics.update(action_ids=list(ACTION_IDS), action_token_ids=list(ACTION_TOKENS),
                original_score_output="scores_q32", probabilities_scope="derived softmax over yes/no only; not original score or generation",
                output_modes_equivalent=False)
        return result

    def _current_adapter_id(self):
        with _import_paths([]):
            _, adapter_id, _ = _original(self.runtime.wrap_adapter, self.module, self.contract, self.parent["contract"])
        return adapter_id

    def _verify_backbone(self):
        shapes = self.contract_api.architecture_shapes(self.contract["architecture"])
        actual = {name: self.runtime.tensor_descriptor(value)
                  for name, value in self.runtime.backbone_tensors(self.module, shapes).items()}
        need(actual == self.contract["backbone"]["index"], "IDENTITY_MISMATCH", "Frozen backbone no longer matches target contract")

    def export_cell(self, replacements, sealed_candidate):
        """Publish complete, validated material beneath the existing owner store."""
        validate_factors(replacements, complete=False)
        self._check_parent()
        need(set(replacements) <= self.allowed_targets, "PATCH_SCOPE", "Export is outside the factor allowlist")
        need(isinstance(sealed_candidate, dict), "INVALID_ARGUMENT", "Expected a sealed candidate")
        candidate_id = checksum(sealed_candidate.get("candidate_id"), "candidate_id")
        need(digest({key: value for key, value in sealed_candidate.items() if key != "candidate_id"}) == candidate_id
             and sealed_candidate.get("schema") == "hepta.weight.sealed-candidate.v1"
             and sealed_candidate.get("model_id") == self.model_id and sealed_candidate.get("backend_id") == self.backend_id
             and sealed_candidate.get("construction_kind") == "DirectWeightEdit"
             and sealed_candidate.get("gradient_steps") == 0 and sealed_candidate.get("optimizer_calls") == 0
             and sealed_candidate.get("production_eligible") is False
             and sealed_candidate.get("requires_independent_evaluation") is True,
             "IDENTITY_MISMATCH", "Seal does not bind this research session")
        patch_ref = self.store.ref(sealed_candidate["patch"]["artifact_id"])
        need(patch_ref == sealed_candidate["patch"] and patch_ref["kind"] == "weight-patch",
             "IDENTITY_MISMATCH", "Sealed patch reference differs")
        patch = self.store.load_json(patch_ref["artifact_id"])
        stored = self.store.load_tensors(patch["parameters"]["artifact_id"])
        need(patch.get("model_id") == self.model_id and patch.get("backend_id") == self.backend_id
             and patch.get("construction_kind") == "DirectWeightEdit"
             and set(stored) == set(replacements) == set(patch["parent_parameter_hashes"])
             and all(tensor_sha256(stored[name]) == tensor_sha256(value)
                     and patch["parent_parameter_hashes"][name] == self.parent_factor_hashes[name]
                     for name, value in replacements.items()),
             "IDENTITY_MISMATCH", "Export factors differ from frozen patch or parent")
        verify_source_pins(self.source_root, SOURCE_PINS, self.policy)
        self._verify_backbone()
        measurement = self.measure_patch(replacements)
        factors = {name: replacements.get(name, value).detach().cpu().clone()
                   for name, value in self.parent_factors.items()}
        validate_factors(factors)
        if measurement["execution_no_op_proven"]:
            artifact = _put_bytes(self.store, self.parent_raw, ".safetensors", "smollm2-complete-adapter")
        else:
            artifact = self.store.put_tensors(factors, "smollm2-complete-adapter")
        # Freeze the reloaded values, including every untouched parent factor.
        reloaded = self.store.load_tensors(artifact["artifact_id"])
        validate_factors(reloaded)
        need(all(tensor_sha256(reloaded[name]) == tensor_sha256(value) for name, value in factors.items()),
             "IDENTITY_MISMATCH", "Complete export changed factor bytes")
        modules = {target["module"]: {
            "A": self.runtime.tensor_descriptor(reloaded[target["module"] + ".A"]),
            "B": self.runtime.tensor_descriptor(reloaded[target["module"] + ".B"]),
            "rank": 4, "alpha": [8, 1], "dropout": False} for target in TARGETS}
        wrapper = {"schema": "pon-wrapped-decoder-lora-material-v1", "contract": self.parent["contract"],
                   "modules": modules, "material_scope": "factor-bytes-and-insertion-interface-not-functional-equivalence"}
        wrapped_raw, adapter_id = _original(self.contract_api.freeze_wrapped_adapter, wrapper, self.contract, self.parent["contract"])
        contract_ref = _put_bytes(self.store, self.contract_raw, ".contract.json", "smollm2-target-contract")
        wrapper_ref = _put_bytes(self.store, wrapped_raw, ".adapter.json", "smollm2-wrapped-adapter")
        export_root = self.store.root / ("cell-" + candidate_id)
        need(not export_root.is_symlink(), "INVALID_PATH", "Cell export directory is a symlink")
        export_root.mkdir(mode=0o700, exist_ok=True)
        refs = {"artifact.safetensors": artifact, "target-contract.json": contract_ref,
                "wrapped-adapter.json": wrapper_ref}
        for name, ref in refs.items():
            self._link_material(export_root / name, ref)
        with _import_paths([]):
            _, preflight = _original(self.parent_material.verify_parent,
                export_root / "target-contract.json", export_root / "wrapped-adapter.json",
                export_root / "artifact.safetensors", expected_contract=self.parent["contract"],
                expected_adapter=adapter_id, expected_file_sha256=artifact["sha256"])
        child = {"schema": "hepta-smollm-parent-material-v1", "generation": self.parent["generation"] + 1,
                 "operation_id": "direct-weight-edit-" + candidate_id, "directory": str(export_root),
                 "contract": self.parent["contract"], "adapter": adapter_id, "file_sha256": artifact["sha256"]}
        envelope = {"schema": "hepta.weight.smollm2-cell-export.v1", "construction_kind": "DirectWeightEdit",
                    "candidate_id": candidate_id, "sealed_at_ms": sealed_candidate["sealed_at_ms"],
                    "information_cutoff_ms": sealed_candidate["information_cutoff_ms"],
                    "evaluation_protocol_sha256": sealed_candidate["evaluation_protocol_sha256"],
                    "model_id": self.model_id, "backend_id": self.backend_id, "source_pins": SOURCE_PINS,
                    "parent": self.parent, "candidate_material": child, "patch": patch_ref,
                    "materials": refs, "material_preflight": preflight, "lora_measurement": measurement,
                    "gradient_steps": 0, "optimizer_calls": 0, "training_executed": False,
                    "optimizer_continuation": "unsupported-no-optimizer-state",
                    "authority": NO_AUTHORITY, "status": "RESEARCH_MATERIAL_REQUIRES_INDEPENDENT_EVALUATION",
                    "qualification_bridge": "DirectWeightEdit requires an explicit owner branch; never fabricate operation=train receipts"}
        parent_ref = self.store.put_json(child, "smollm2-parent-material")
        envelope_ref = self.store.put_json(envelope, "smollm2-direct-weight-edit")
        self._link_material(export_root / "parent-material.json", parent_ref)
        self._link_material(export_root / "direct-weight-edit.json", envelope_ref)
        fd = os.open(export_root, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        self._check_parent()
        return {"directory": str(export_root), "materials": refs, "parent_material": parent_ref,
                "direct_weight_edit": envelope_ref, "material_preflight": preflight,
                "adapter": adapter_id, "file_sha256": artifact["sha256"],
                "construction_kind": "DirectWeightEdit", "production_eligible": False}

    @staticmethod
    def _link_material(destination, ref):
        try:
            os.link(ref["path"], destination)
        except FileExistsError:
            need(not destination.is_symlink() and file_sha256(destination) == ref["sha256"],
                 "IDENTITY_MISMATCH", "Immutable Cell export already differs")

    def describe(self):
        result = super().describe()
        result.update(task_kind=self.task_kind, source_commit=SOURCE_COMMIT,
            target_contract=self.parent["contract"], parent_adapter=self.parent["adapter"],
            factor_tensors=120, factor_parameters=230400, factor_dtype="float32",
            output_modes=list(MODES), default_output_mode="conditional_binary",
            action_class_order=["yes", "no"], action_token_ids=list(ACTION_TOKENS),
            action_ids=list(ACTION_IDS), original_action_output="scores_q32",
            effective_patch_measurement="Joint 2*(B_candidate@A_candidate-B_parent@A_parent)",
            export_method="export_cell(replacements, sealed_candidate)")
        result["limitations"] += [
            "Only complete fixed rank-4 Q/V LoRA factor material can be exported; backbone edits are refused",
            "Conditional yes/no probabilities are derived diagnostics; the original scorer returns raw-logit Q32 scores",
            "Eight-token greedy decoding is separate and can disagree with conditional scoring",
            "A-only or B-only edits of the all-zero parent have zero effective LoRA update",
            "Material validation confers no Cell installation or quality qualification authority",
        ]
        return result

    def close(self):
        self.factor_tensors.clear()
        self.parent_factors.clear()
        self.base_weights.clear()
        self.tokenizer = None
        super().close()


def load_smollm2(config, policy, store):
    """Load original local source and all seven pinned upstream model files."""
    import torch
    required = {"source_dir", "source_pins", "materials_dir", "material_manifest_sha256",
                "plan_path", "plan_sha256", "parent_dir", "parent_contract", "parent_adapter",
                "parent_file_sha256", "generation"}
    need(isinstance(config, dict) and required <= set(config)
         and set(config) <= required | {"allowed_patch_targets", "device"},
         "INVALID_MODEL", "Incomplete or unsupported SmolLM2 provider configuration")
    need(config.get("device", "cpu") == "cpu" and sys.byteorder == "little",
         "UNSUPPORTED_DEVICE", "SmolLM2 Cell provider requires little-endian CPU")
    source = verify_source_pins(config["source_dir"], config["source_pins"], policy)
    runtime, parent_material, contract_api = _original(_source_modules, source)
    materials = policy.read(config["materials_dir"], directory=True)
    manifest_path = policy.bound(materials / "material-manifest.json", config["material_manifest_sha256"], 2 * 1024 * 1024)
    for name, (size, expected) in runtime.PUBLIC_FILES.items():
        path = policy.bound(materials / name, expected, size)
        need(path.stat().st_size == size and not (materials / name).is_symlink(),
             "IDENTITY_MISMATCH", "Upstream model material length or file type differs", file=name)
    manifest, _ = _original(runtime.verify_materials, materials)
    plan_path = policy.bound(config["plan_path"], config["plan_sha256"], 512 * 1024)
    plan = loads(plan_path.read_bytes())
    # Later observer profiles import additional modules and need their own audit.
    need(plan.get("schema") == "llm-runtime-public-pilot-plan-v1", "INVALID_MODEL", "Only the pinned strict-v1 execution plan is supported")
    _original(runtime.validate_plan, plan)
    need(plan["runtime_source"] == SOURCE_PINS["scripts/llm_runtime_pilot.py"]
         and plan["model_family_configuration_sha256"] == SOURCE_PINS["config/pon/model-family-smollm2-135m-v1.json"]
         and plan["backend"] == "cpu" and plan["generation_tokens"] == 8
         and 1 <= plan["threads"] <= min(4, torch.get_num_threads())
         and runtime.identity(manifest) == plan["snapshot"],
         "IDENTITY_MISMATCH", "Execution plan, material snapshot or owner thread budget differs")
    parent_root = policy.read(config["parent_dir"], directory=True)
    for name in ("target-contract.json", "wrapped-adapter.json", "artifact.safetensors"):
        policy.read(parent_root / name)
    generation = integer(config["generation"], "generation", 1, (1 << 63) - 2)
    parent = {"schema": "hepta-smollm-parent-material-v1", "generation": generation,
              "operation_id": "weight-workbench-explicit-parent", "directory": str(parent_root),
              "contract": checksum(config["parent_contract"]), "adapter": checksum(config["parent_adapter"]),
              "file_sha256": checksum(config["parent_file_sha256"])}
    with _import_paths([]):
        factors_raw, preflight = _original(parent_material.verify_parent,
            parent_root / "target-contract.json", parent_root / "wrapped-adapter.json", parent_root / "artifact.safetensors",
            expected_contract=parent["contract"], expected_adapter=parent["adapter"], expected_file_sha256=parent["file_sha256"])
        contract_raw = _original(parent_material.read_regular, parent_root / "target-contract.json", contract_api.MAX_MANIFEST_BYTES)
        contract = _original(contract_api.verify_target_contract, contract_raw, parent["contract"],
            expected_backbone_root=preflight["backbone"], expected_tokenizer_root=preflight["tokenizer"])
        parent_raw = _original(parent_material.read_regular, parent_root / "artifact.safetensors", 2 * 1024 * 1024)
    need(hashlib.sha256(parent_raw).hexdigest() == parent["file_sha256"], "IDENTITY_MISMATCH", "Parent artifact changed while loading")
    factors = {name: torch.frombuffer(bytearray(value), dtype=torch.float32).reshape(FACTOR_SHAPES[name]).clone()
               for name, value in factors_raw.items()}
    validate_factors(factors)
    # Session.open owns the pool. Match original numeric settings without a
    # second interop initializer or any monkeypatch to the original source.
    torch.set_num_threads(plan["threads"])
    need(torch.get_num_interop_threads() == 1, "THREAD_POLICY", "Owner must initialize one interop thread")
    torch.use_deterministic_algorithms(True)
    torch.set_float32_matmul_precision("highest")
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from safetensors import safe_open
        from safetensors.torch import load_file, save_file
        import peft  # noqa: F401 -- fail before allocating the large backbone
    except ImportError as exc:
        raise WeightError("DEPENDENCY_MISSING", "SmolLM2 requires the original Transformers/PEFT CPU environment") from exc
    imports = (torch, torch.device("cpu"), AutoModelForCausalLM, AutoTokenizer, safe_open, save_file, load_file)
    with _import_paths([]), torch.random.fork_rng(devices=[]):
        module, tokenizer, shapes, _ = _original(runtime.load_model, materials, plan, imports)
        actual, _, _ = _original(runtime.make_contract, module, tokenizer, shapes, materials, manifest, plan)
        need({key: value for key, value in actual.items() if key != "registration"}
             == {key: value for key, value in contract.items() if key != "registration"},
             "IDENTITY_MISMATCH", "Loaded backbone/tokenizer differ from the immutable parent target")
        module = _original(runtime.insert_lora, module, plan, "candidate", torch)
        destination = runtime.adapter_tensors(module, TARGETS)
        validate_factors(destination)
        with torch.no_grad():
            for name, value in factors.items():
                destination[name].copy_(value)
        _, adapter_id, _ = _original(runtime.wrap_adapter, module, contract, parent["contract"])
        need(adapter_id == parent["adapter"], "IDENTITY_MISMATCH", "Actual loaded factor identity differs")
    identity = {"provider": "smollm2_cell", "model": MODEL, "revision": REVISION,
                "source_commit": SOURCE_COMMIT, "source_pins": SOURCE_PINS,
                "material_manifest_sha256": file_sha256(manifest_path), "snapshot": plan["snapshot"],
                "public_files": {name: {"byte_length": size, "sha256": value} for name, (size, value) in runtime.PUBLIC_FILES.items()},
                "plan_sha256": config["plan_sha256"], "parent": {key: value for key, value in parent.items() if key != "directory"},
                "material_preflight": preflight}
    return SmolLM2Provider(module, tokenizer, runtime, parent_material, contract_api, contract, contract_raw,
                          parent, parent_raw, plan, identity, store, source, policy, config.get("allowed_patch_targets"))
