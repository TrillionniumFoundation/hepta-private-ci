import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path('/home/qq/hepta-cell-common-e1c98-20261109')
SOURCE = ROOT / 'source-fresh'
EVIDENCE = ROOT / 'evidence'
EVIDENCE.mkdir(exist_ok=True)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE, text=True).strip()

def snapshot():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain=v1', '--untracked-files=all')}

name, expected_source, *command = sys.argv[1:]
assert name and '/' not in name and command
record_path = EVIDENCE / (name + '.json')
log_path = EVIDENCE / (name + '.log')
assert not record_path.exists() and not log_path.exists(), 'create-only attempt'
before = snapshot()
assert before['head'] == expected_source and not before['status'], before
env = os.environ.copy()
settings = {
    'PATH': '/home/qq/hepta-learning-native-4f559bf-d9fb-20261108/transfer:/home/qq/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
    'RUSTUP_HOME': '/home/qq/.rustup', 'RUSTUP_TOOLCHAIN': '1.96.0',
    'CARGO_HOME': '/home/qq/.cargo', 'LIBCLANG_PATH': '/usr/lib/llvm-21/lib',
    'BINDGEN_EXTRA_CLANG_ARGS': '-isystem/usr/lib/gcc/x86_64-linux-gnu/15/include',
    'CARGO_TARGET_DIR': str(ROOT / 'target'), 'CARGO_INCREMENTAL': '0',
    'CARGO_BUILD_JOBS': '8', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
    'CODEX_REPO_ROOT': str(SOURCE), 'PYTHONDONTWRITEBYTECODE': '1',
    'PYTHONPATH': str(SOURCE / 'scripts') + ':' + str(SOURCE),
    'TMPDIR': str(ROOT / 'tmp'), 'OMP_NUM_THREADS': '1',
    'MKL_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
}
(ROOT / 'tmp').mkdir(exist_ok=True)
helper = ROOT / 'target/debug/hepta-joint-propose'
if helper.is_file():
    settings['CARGO_BIN_EXE_hepta-joint-propose'] = str(helper)
    settings['CARGO_BIN_EXE_hepta_joint_propose'] = str(helper)
env.update(settings)
record = {'schema': 'hepta.cell-common.command.v1', 'name': name, 'command': command,
          'cwd': str(SOURCE), 'source_before': before, 'environment': settings,
          'started_unix': time.time(), 'energy_joules': None, 'provider_cost': None,
          'cost_scope': 'whole subprocess including compile/test and child processes',
          'exit_code': None}
if helper.is_file():
    record['existing_helper_sha256'] = hashlib.sha256(helper.read_bytes()).hexdigest()
record_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'started': name, 'source': before, 'command': command}), flush=True)
start = time.monotonic()
cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
with log_path.open('xb') as log:
    result = subprocess.run(command, cwd=SOURCE, env=env, stdout=log, stderr=subprocess.STDOUT)
end_cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
raw = log_path.read_bytes()
after = snapshot()
record.update({'exit_code': result.returncode, 'wall_seconds': time.monotonic() - start,
               'child_cpu_seconds': (end_cpu.ru_utime + end_cpu.ru_stime) - (cpu.ru_utime + cpu.ru_stime),
               'child_peak_rss_kib': end_cpu.ru_maxrss,
               'source_after': after, 'source_unchanged': before == after,
               'raw_log_bytes': len(raw), 'raw_log_sha256': hashlib.sha256(raw).hexdigest(),
               'completed_unix': time.time()})
log_path.with_suffix('.log.gz').write_bytes(gzip.compress(raw, mtime=0))
for p in [ROOT / 'target/nextest/local/junit.xml', SOURCE / 'codex-rs/target/nextest/local/junit.xml']:
    if p.is_file() and p.stat().st_mtime >= record['started_unix']:
        b = p.read_bytes()
        dest = EVIDENCE / (name + '.junit.xml')
        dest.write_bytes(b)
        record['junit'] = {'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b), 'path': str(dest)}
        break
record_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
print(raw.decode(errors='replace')[-18000:], flush=True)
sys.exit(result.returncode if before == after else 90)
