"""Record one explicitly authorized, non-test maintenance command."""

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def create_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def git(source, *args):
    return subprocess.check_output(["git", *args], cwd=source)


def snapshot(source, destination, label):
    patch = git(source, "diff", "--binary", "--full-index", "HEAD", "--")
    patch_path = destination / f"{label}.patch"
    with patch_path.open("xb") as stream:
        stream.write(patch)
    paths = git(source, "diff", "--name-only", "-z", "HEAD", "--").split(b"\0")
    files = []
    for raw in paths:
        if not raw:
            continue
        path = source / os.fsdecode(raw)
        row = {"path": os.fsdecode(raw)}
        if path.is_symlink():
            contents = os.fsencode(os.readlink(path))
            row.update(kind="symlink", bytes=len(contents), sha256=digest(contents))
        elif path.is_file():
            contents = path.read_bytes()
            row.update(kind="file", bytes=len(contents), sha256=digest(contents))
        else:
            row["kind"] = "absent"
        files.append(row)
    return {
        "head": git(source, "rev-parse", "HEAD").decode().strip(),
        "tree": git(source, "rev-parse", "HEAD^{tree}").decode().strip(),
        "status": git(source, "status", "--porcelain=v1", "--untracked-files=all").decode(),
        "untracked": [os.fsdecode(p) for p in git(
            source, "ls-files", "--others", "--exclude-standard", "-z"
        ).split(b"\0") if p],
        "index_diff_sha256": digest(git(source, "diff", "--cached", "--binary", "HEAD", "--")),
        "working_diff": {"path": str(patch_path), "sha256": digest(patch), "bytes": len(patch)},
        "changed_files": files,
        "tree_is_committed_tree_not_dirty_worktree_digest": True,
    }


def cgroup_state():
    try:
        membership = Path("/proc/self/cgroup").read_text()
        relative = next(line[3:] for line in membership.splitlines() if line.startswith("0::"))
        root = Path("/sys/fs/cgroup") / relative.lstrip("/")
        values = {"membership": membership, "path": str(root)}
        for name in ("cpu.max", "cpu.stat", "memory.max", "memory.peak", "memory.events", "cgroup.events"):
            path = root / name
            values[name] = path.read_text() if path.is_file() else None
        return values
    except (OSError, StopIteration) as error:
        return {"unavailable": str(error)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("plan", type=Path)
    parser.add_argument("plan_sha256")
    parser.add_argument("attempt")
    parser.add_argument("phase", choices=("fix", "fmt", "clippy"))
    parser.add_argument("expected_input_diff_sha256")
    args = parser.parse_args()
    raw_plan = args.plan.read_bytes()
    if digest(raw_plan) != args.plan_sha256:
        raise RuntimeError("maintenance plan hash changed")
    if not args.attempt or Path(args.attempt).name != args.attempt:
        raise RuntimeError("one create-only attempt name required")
    plan = json.loads(raw_plan)
    source = Path(plan["source"])
    destination = Path(plan["evidence_root"]) / args.attempt
    destination.mkdir(parents=True, exist_ok=False)
    before = snapshot(source, destination, "before")
    empty = digest(b"")
    if (before["head"] != plan["tested_runtime_commit"]
            or before["tree"] != plan["tested_runtime_tree"]
            or before["untracked"]
            or before["index_diff_sha256"] != empty
            or before["working_diff"]["sha256"] != args.expected_input_diff_sha256):
        create_json(destination / "ADMISSION_FAILED.json", before)
        raise RuntimeError("source differs from explicitly reviewed maintenance input")
    environment = os.environ.copy()
    environment.update(plan["environment"])
    command = plan["commands"][args.phase]
    record = {
        "schema": "hepta.common.maintenance-command.v1",
        "attempt": args.attempt, "phase": args.phase, "command": command,
        "cwd": str(source / "codex-rs"), "environment": plan["environment"],
        "controller_sha256": digest(Path(__file__).read_bytes()),
        "plan_sha256": args.plan_sha256, "source_before": before,
        "tested_runtime_commit": plan["tested_runtime_commit"],
        "tested_runtime_tree": plan["tested_runtime_tree"],
        "tests_executed_by_this_command": False,
        "maintenance_worktree_inherits_no_test_pass_claim": True,
        "started_unix": time.time(), "cgroup_before": cgroup_state(),
        "cost_scope": "whole subprocess including compilation, lint, and child processes",
        "energy_joules": None, "provider_cost": None,
    }
    create_json(destination / "STARTED.json", record)
    print(json.dumps({"started": args.attempt, "phase": args.phase, "command": command}), flush=True)
    started = time.monotonic()
    cpu_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    log_path = destination / "command.log"
    launch_error = None
    with log_path.open("xb") as output:
        try:
            result = subprocess.run(command, cwd=source / "codex-rs", env=environment,
                                    stdout=output, stderr=subprocess.STDOUT)
            exit_code = result.returncode
        except OSError as error:
            launch_error = repr(error)
            output.write((launch_error + "\n").encode())
            exit_code = 127
    cpu_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    raw_log = log_path.read_bytes()
    with (destination / "command.log.gz").open("xb") as output:
        output.write(gzip.compress(raw_log, mtime=0))
    after = snapshot(source, destination, "after")
    allowed = set(plan["originally_changed_code_paths"])
    unexpected = sorted(row["path"] for row in after["changed_files"] if row["path"] not in allowed)
    record.update({
        "exit_code": exit_code, "launch_error": launch_error,
        "wall_seconds": time.monotonic() - started,
        "child_cpu_seconds": (cpu_after.ru_utime + cpu_after.ru_stime) - (cpu_before.ru_utime + cpu_before.ru_stime),
        "child_peak_rss_kib": cpu_after.ru_maxrss,
        "completed_unix": time.time(), "cgroup_after": cgroup_state(),
        "raw_log_sha256": digest(raw_log), "raw_log_bytes": len(raw_log),
        "source_after": after, "changed_paths_outside_initial_scope": unexpected,
        "source_commit_unchanged": before["head"] == after["head"] and before["tree"] == after["tree"],
        "review_required_before_local_application": True,
    })
    create_json(destination / "RESULT.json", record)
    print(json.dumps(record), flush=True)
    print(raw_log.decode(errors="replace")[-14000:], flush=True)
    if not record["source_commit_unchanged"] or after["untracked"] or after["index_diff_sha256"] != empty:
        return 90
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
