#!/usr/bin/env python3
"""Create an isolated, source-bound Matrix startup timing probe.

This does not change the candidate checkout or any deadline. The generated
worktree preserves the exact migration test and adds stderr timing/error probes
only. Its results diagnose failure; they are not qualification evidence for the
unmodified source. Run the printed just command only after the main native build
has finished using the shared target directory.
"""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def git(source: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(source), *args], text=True).strip()


def replace_exact(text: str, old: str, new: str, expected: int = 1) -> str:
    count = text.count(old)
    if count != expected:
        raise RuntimeError(f"expected {expected} matches, found {count}: {old!r}")
    return text.replace(old, new)


def instrument_sdk(text: str) -> str:
    text = replace_exact(
        text,
        "pub struct MatrixSdkClient {",
        '''// Diagnostic overlay only: these probes retain production deadlines.
struct MatrixStartupProbe {
    phase: &'static str,
    started: std::time::Instant,
}

impl MatrixStartupProbe {
    fn new(phase: &'static str) -> Self {
        eprintln!("MATRIX_STARTUP_PROBE phase={phase} state=begin");
        Self { phase, started: std::time::Instant::now() }
    }
}

impl Drop for MatrixStartupProbe {
    fn drop(&mut self) {
        eprintln!(
            "MATRIX_STARTUP_PROBE phase={} state=end_or_cancel elapsed_ms={}",
            self.phase,
            self.started.elapsed().as_millis(),
        );
    }
}

pub struct MatrixSdkClient {''',
    )
    text = replace_exact(
        text,
        ".map_err(|_| MatrixSdkError::Initialization)??;",
        '''.map_err(|error| {
            eprintln!("MATRIX_STARTUP_PROBE phase=build.outer_timeout error={error:?}");
            MatrixSdkError::Initialization
        })??;''',
        expected=3,
    )
    text = replace_exact(
        text,
        "        let paths = MatrixSdkPaths::prepare(layout, &config)?;\n        let client = Client::builder()",
        '''        let _total_probe = MatrixStartupProbe::new("build.total");
        let paths_probe = MatrixStartupProbe::new("build.paths");
        let paths = MatrixSdkPaths::prepare(layout, &config)?;
        drop(paths_probe);
        let builder_probe = MatrixStartupProbe::new("build.sdk_builder");
        let client = Client::builder()''',
    )
    text = replace_exact(
        text,
        '''            .build()
            .await
            .map_err(|_| MatrixSdkError::Initialization)?;''',
        '''            .build()
            .await
            .map_err(|error| {
                eprintln!("MATRIX_STARTUP_PROBE phase=build.sdk_builder error={error:?}");
                MatrixSdkError::Initialization
            })?;
        drop(builder_probe);
        let token_probe = MatrixStartupProbe::new("build.clear_sync_token");''',
    )
    text = replace_exact(
        text,
        '''            .remove_kv_data(StateStoreDataKey::SyncToken)
            .await
            .map_err(|_| MatrixSdkError::Initialization)?;''',
        '''            .remove_kv_data(StateStoreDataKey::SyncToken)
            .await
            .map_err(|error| {
                eprintln!("MATRIX_STARTUP_PROBE phase=build.clear_sync_token error={error:?}");
                MatrixSdkError::Initialization
            })?;
        drop(token_probe);''',
    )
    text = replace_exact(
        text,
        "            if matches!(restore, Ok(Ok(()))) {",
        '''            eprintln!("MATRIX_STARTUP_PROBE phase=restore_session result={restore:?}");
            if matches!(restore, Ok(Ok(()))) {''',
    )
    return text


def instrument_test(text: str) -> str:
    text = replace_exact(
        text,
        "    let client = tokio::time::timeout(\n        Duration::from_secs(120),",
        '''    let diagnostic_started = std::time::Instant::now();
    eprintln!("MATRIX_STARTUP_PROBE phase=fixture.builder state=begin");
    let client = tokio::time::timeout(
        Duration::from_secs(120),''',
    )
    text = replace_exact(
        text,
        "    .await??;\n    let session = fixture_session()?;",
        '''    .await??;
    eprintln!("MATRIX_STARTUP_PROBE phase=fixture.builder state=end elapsed_ms={}", diagnostic_started.elapsed().as_millis());
    let diagnostic_started = std::time::Instant::now();
    let session = fixture_session()?;''',
    )
    text = replace_exact(
        text,
        '''    .await??;
    assert_eq!(
        serde_json::to_value(client.matrix_auth().session())?,''',
        '''    .await??;
    eprintln!("MATRIX_STARTUP_PROBE phase=fixture.restore_session state=end elapsed_ms={}", diagnostic_started.elapsed().as_millis());
    assert_eq!(
        serde_json::to_value(client.matrix_auth().session())?,''',
    )
    text = replace_exact(
        text,
        '''    prepare_fixture(temp.path()).await?;
    reopen_fixture(temp.path()).await''',
        '''    let diagnostic_started = std::time::Instant::now();
    eprintln!("MATRIX_STARTUP_PROBE phase=fixture.prepare state=begin");
    prepare_fixture(temp.path()).await?;
    eprintln!("MATRIX_STARTUP_PROBE phase=fixture.prepare state=end elapsed_ms={}", diagnostic_started.elapsed().as_millis());
    let diagnostic_started = std::time::Instant::now();
    let result = reopen_fixture(temp.path()).await;
    eprintln!("MATRIX_STARTUP_PROBE phase=fixture.reopen state=end elapsed_ms={} result={result:?}", diagnostic_started.elapsed().as_millis());
    result''',
    )
    return text


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--ref", default="HEAD")
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    output = args.output.absolute()
    if output.exists():
        raise RuntimeError(f"refuse to overwrite existing diagnostic directory: {output}")
    head = git(source, "rev-parse", f"{args.ref}^{{commit}}")
    tree = git(source, "rev-parse", f"{args.ref}^{{tree}}")
    output.mkdir(parents=True)
    worktree = output / "source"
    subprocess.run(
        ["git", "-C", str(source), "worktree", "add", "--detach", str(worktree), head],
        check=True,
    )
    files = {
        "codex-rs/hepta-matrix-sdk/src/sdk.rs": instrument_sdk,
        "codex-rs/hepta-matrix-sdk/tests/store_version_migration.rs": instrument_test,
    }
    digests = {}
    for relative, instrument in files.items():
        path = worktree / relative
        original = path.read_bytes()
        instrumented = instrument(original.decode()).encode()
        path.write_bytes(instrumented)
        digests[relative] = {
            "original_sha256": hashlib.sha256(original).hexdigest(),
            "instrumented_sha256": hashlib.sha256(instrumented).hexdigest(),
        }
    patch = subprocess.check_output(["git", "-C", str(worktree), "diff", "--binary"])
    (output / "diagnostic.patch").write_bytes(patch)
    manifest = {
        "purpose": "diagnostic timing only; not source-exact qualification",
        "base_head": head,
        "base_tree": tree,
        "deadline_changed": False,
        "patch_sha256": hashlib.sha256(patch).hexdigest(),
        "files": digests,
        "command": [
            "just", "test", "--locked", "-p", "codex-hepta-matrix-sdk",
            "--test", "store_version_migration", "--no-capture", "--retries", "0",
            "-E", "test(encrypted_state_identity_session_and_queues_survive_restart)",
        ],
        "cwd": str(worktree / "codex-rs"),
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
