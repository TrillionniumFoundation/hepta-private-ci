#!/usr/bin/env python3
"""Record one unchanged-deadline Matrix diagnostic run in an isolated worktree."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path("/home/qq/hepta-cell-common-e1c98-20261109")
DIAGNOSTIC = ROOT / "matrix-diagnostic-original"
SOURCE = DIAGNOSTIC / "source"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=SOURCE, text=True).strip()


def snapshot():
    diff = subprocess.check_output(["git", "diff", "--binary"], cwd=SOURCE)
    return {
        "head": git("rev-parse", "HEAD"),
        "tree": git("rev-parse", "HEAD^{tree}"),
        "status": git("status", "--porcelain=v1", "--untracked-files=all"),
        "overlay_sha256": hashlib.sha256(diff).hexdigest(),
    }


def main():
    name = sys.argv[1]
    assert name in {
        "original-debug",
        "original-debug-half-cpu",
        "encryption-opt3",
        "encryption-opt3-half-cpu",
    }
    log_path = DIAGNOSTIC / (name + ".log")
    record_path = DIAGNOSTIC / (name + ".json")
    assert not log_path.exists() and not record_path.exists(), "create-only attempt"
    before = snapshot()
    manifest = json.loads((DIAGNOSTIC / "manifest.json").read_text())
    assert before["head"] == manifest["base_head"]
    if name.startswith("original-debug"):
        assert before["overlay_sha256"] == manifest["patch_sha256"]
    else:
        overlay = json.loads((DIAGNOSTIC / "encryption-opt3-overlay.json").read_text())
        assert before["overlay_sha256"] == overlay["overlay_sha256"]
    command = list(manifest["command"])
    env = os.environ.copy()
    settings = {
        "PATH": "/home/qq/hepta-learning-native-4f559bf-d9fb-20261108/transfer:/home/qq/.cargo/bin:/usr/local/bin:/usr/bin:/bin",
        "RUSTUP_HOME": "/home/qq/.rustup",
        "RUSTUP_TOOLCHAIN": "1.96.0",
        "CARGO_HOME": "/home/qq/.cargo",
        "LIBCLANG_PATH": "/usr/lib/llvm-21/lib",
        "BINDGEN_EXTRA_CLANG_ARGS": "-isystem/usr/lib/gcc/x86_64-linux-gnu/15/include",
        "CARGO_TARGET_DIR": str(ROOT / "target"),
        "CARGO_INCREMENTAL": "0",
        "CARGO_BUILD_JOBS": "8",
        "CARGO_PROFILE_TEST_DEBUG": "0",
        "CARGO_PROFILE_DEV_DEBUG": "0",
        "CODEX_REPO_ROOT": str(SOURCE),
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(SOURCE / "scripts") + ":" + str(SOURCE),
        "TMPDIR": str(ROOT / "tmp"),
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
    }
    env.update(settings)
    record = {
        "schema": "hepta.matrix-startup.diagnostic.v1",
        "name": name,
        "claim": "diagnostic overlay; not unmodified-source qualification",
        "deadline_changed": False,
        "command": command,
        "cwd": str(SOURCE / "codex-rs"),
        "source_before": before,
        "environment": settings,
        "started_unix": time.time(),
        "exit_code": None,
    }
    for line in Path("/proc/self/cgroup").read_text().splitlines():
        hierarchy, controllers, cgroup = line.split(":", 2)
        if hierarchy == "0" and not controllers:
            limit = Path("/sys/fs/cgroup") / cgroup.lstrip("/") / "cpu.max"
            if limit.is_file():
                record["cpu_max"] = limit.read_text().strip()
    record_path.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record), flush=True)
    start = time.monotonic()
    cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
    with log_path.open("xb") as log:
        result = subprocess.run(
            command, cwd=SOURCE / "codex-rs", env=env, stdout=log, stderr=subprocess.STDOUT
        )
    end_cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
    raw = log_path.read_bytes()
    after = snapshot()
    record.update(
        {
            "exit_code": result.returncode,
            "wall_seconds": time.monotonic() - start,
            "child_cpu_seconds": (end_cpu.ru_utime + end_cpu.ru_stime)
            - (cpu.ru_utime + cpu.ru_stime),
            "child_peak_rss_kib": end_cpu.ru_maxrss,
            "source_after": after,
            "source_unchanged": before == after,
            "raw_log_bytes": len(raw),
            "raw_log_sha256": hashlib.sha256(raw).hexdigest(),
            "completed_unix": time.time(),
        }
    )
    log_path.with_suffix(".log.gz").write_bytes(gzip.compress(raw, mtime=0))
    for junit in [
        ROOT / "target/nextest/local/junit.xml",
        SOURCE / "codex-rs/target/nextest/local/junit.xml",
    ]:
        if junit.is_file() and junit.stat().st_mtime >= record["started_unix"]:
            content = junit.read_bytes()
            copied = DIAGNOSTIC / (name + ".junit.xml")
            copied.write_bytes(content)
            record["junit"] = {
                "sha256": hashlib.sha256(content).hexdigest(),
                "bytes": len(content),
                "path": str(copied),
            }
            break
    record_path.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record), flush=True)
    print(raw.decode(errors="replace")[-20000:], flush=True)
    sys.exit(result.returncode if before == after else 90)


if __name__ == "__main__":
    main()
