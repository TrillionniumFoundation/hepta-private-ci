"""Run two existing actual-Root component tests from a pinned nextest archive.

This controller is an execution artifact, not a production authority provider.
Every Root-owned write remains inside one new private qualification directory.
"""

import base64
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import stat
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET


TESTS = {
    "root_learning_scoped_sealed_pin_preserves_scope_on_cold_reopen",
    "root_learning_sealed_pin_and_dedicated_uds_recover_original_checkpoint",
}


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def verified_file(item):
    path = Path(item["path"])
    metadata = path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or digest(path) != item["sha256"]:
        raise RuntimeError(f"pinned regular file changed: {path}")
    if item.get("bytes", metadata.st_size) != metadata.st_size:
        raise RuntimeError(f"pinned file size changed: {path}")
    return path


def write_json(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def verify_gates(plan):
    expected = {
        "head": plan["source_commit"], "tree": plan["source_tree"], "status": ""
    }
    # Git is read as the existing repository owner before sudo. Root does not
    # alter global safe.directory or otherwise bypass Git ownership checks.
    if plan["source_before"] != expected:
        raise RuntimeError("pre-sudo source snapshot differs from frozen source")
    if len(plan["native_gate_records"]) != 4:
        raise RuntimeError("the four original native gate records are required")
    required = {"helper-build-", "native-libraries-", "matrix-sdk-", "agentd-binaries-"}
    seen = set()
    for item in plan["native_gate_records"]:
        record = json.loads(verified_file(item).read_text())
        categories = [prefix for prefix in required if record.get("name", "").startswith(prefix)]
        if len(categories) != 1 or categories[0] in seen:
            raise RuntimeError("native gate category is missing or duplicated")
        seen.add(categories[0])
        if (
            record.get("exit_code") != 0
            or record.get("completed_unix") is None
            or record.get("source_before") != expected
            or record.get("source_after") != expected
            or record.get("source_unchanged") is not True
        ):
            raise RuntimeError(f"native gate is incomplete or failed: {item['path']}")
    if seen != required:
        raise RuntimeError("the complete four native gate categories are required")
    model = json.loads(verified_file(plan["model_terminal_record"]).read_text())
    if model.get("exit_code") is None or model.get("completed_unix") is None:
        raise RuntimeError("model command is still running")
    if model.get("source_before") != expected or model.get("source_after") != expected:
        raise RuntimeError("model command was not bound to this exact source")


def copy_pinned(item, destination, executable=False):
    original = verified_file(item)
    with original.open("rb") as source, Path(destination).open("xb") as target:
        shutil.copyfileobj(source, target, length=1024 * 1024)
    os.chmod(destination, 0o700 if executable else 0o600)
    if digest(destination) != item["sha256"]:
        raise RuntimeError(f"copy differs from frozen file: {destination}")
    return Path(destination)


def source_manifest(source):
    rows = []
    for path in sorted(source.rglob("*")):
        name = path.relative_to(source).as_posix()
        if path.is_symlink():
            rows.append({"path": name, "symlink": os.readlink(path)})
        elif path.is_file():
            rows.append({"path": name, "sha256": digest(path)})
    return rows


def run(plan_path, expected_plan):
    if os.geteuid() != 0 or digest(plan_path) != expected_plan:
        raise RuntimeError("actual Root and exact reviewed plan are required")
    os.umask(0o077)
    plan = json.loads(Path(plan_path).read_text())
    if digest(__file__) != plan["controller_sha256"]:
        raise RuntimeError("Root controller changed after plan freeze")
    verify_gates(plan)
    prepared = json.loads(verified_file(plan["preparation_result"]).read_text())
    if prepared["source_commit"] != plan["source_commit"] or prepared["source_tree"] != plan["source_tree"]:
        raise RuntimeError("archive preparation source differs")
    for key in ("source_archive", "nextest_archive"):
        if prepared[key] != plan[key]:
            raise RuntimeError(f"archive pin differs from preparation: {key}")
    tool_record = json.loads(verified_file(plan["tools_record"]).read_text())
    original_tools = dict(tool_record["actual_toolchain_files"])
    original_tools.update({item["name"]: item for item in tool_record["files"]
                           if item["name"] in {"just", "cargo-nextest"}})
    if original_tools != plan["tools"]:
        raise RuntimeError("execution tool pins differ from the archive preparation")

    parent = Path("/var/lib/hepta-common-e1c98-root-test-" + plan["source_commit"][:8])
    if str(parent) != plan["root_parent"]:
        raise RuntimeError("unexpected Root qualification directory")
    ancestors = []
    for path in [Path("/"), Path("/var"), Path("/var/lib")]:
        metadata = path.lstat()
        if not stat.S_ISDIR(metadata.st_mode) or metadata.st_uid != 0 or metadata.st_mode & 0o022:
            raise RuntimeError(f"original ancestor is not protected: {path}")
        ancestors.append({"path": str(path), "uid": metadata.st_uid, "gid": metadata.st_gid,
                          "mode": oct(stat.S_IMODE(metadata.st_mode)), "device": metadata.st_dev,
                          "inode": metadata.st_ino})
    parent.mkdir(mode=0o700)  # Create-only: retain any previous attempt as evidence.
    for name in ("inputs", "bin", "source", "tmp", "cargo-home", "target", "cache", "config", "data", "evidence", "run-extracted"):
        (parent / name).mkdir(mode=0o700)
    write_json(parent / "evidence/PLAN.json", plan)
    write_json(parent / "evidence/ANCESTORS.json", ancestors)
    source_archive = copy_pinned(plan["source_archive"], parent / "inputs/source.tar.gz")
    archive = copy_pinned(plan["nextest_archive"], parent / "inputs/native-nextest.tar.zst")
    source = parent / "source"
    with tarfile.open(source_archive, "r:gz") as bundled:
        bundled.extractall(source, filter="data")
    before = source_manifest(source)
    write_json(parent / "evidence/SOURCE_BEFORE.json", before)
    for name in ("just", "cargo", "cargo-nextest"):
        copy_pinned(plan["tools"][name], parent / "bin" / name, executable=True)
    rustc = verified_file(plan["tools"]["rustc"])
    environment = {
        "PATH": str(parent / "bin") + ":" + str(rustc.parent) + ":/usr/bin:/bin",
        "RUSTC": str(rustc), "CARGO_HOME": str(parent / "cargo-home"),
        "CARGO_TARGET_DIR": str(parent / "target"), "CARGO_NET_OFFLINE": "true",
        "TMPDIR": str(parent / "tmp"), "XDG_CACHE_HOME": str(parent / "cache"),
        "XDG_CONFIG_HOME": str(parent / "config"), "XDG_DATA_HOME": str(parent / "data"),
        "PYTHONDONTWRITEBYTECODE": "1", "HEPTA_CHECKPOINT_TEST_ROOT": str(parent),
        "PYTHONNOUSERSITE": "1",
        "CODEX_REPO_ROOT": str(source), "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
        "LD_LIBRARY_PATH": str(rustc.parent.parent / "lib") + ":/usr/lib/llvm-21/lib",
    }
    expression = "package(=codex-hepta-agentd) & (" + " | ".join(
        "test(/::" + name + "$/)" for name in sorted(TESTS)
    ) + ")"
    command = [str(parent / "bin/just"), "test", "--archive-file", str(archive),
               "--workspace-remap", str(source / "codex-rs"), "--extract-to", str(parent / "run-extracted"),
               "--run-ignored", "only", "--retries", "0", "--no-tests", "fail", "--test-threads", "1", "-E", expression]
    record = {"schema": "hepta.common.actual-root-handoff.v1", "source_commit": plan["source_commit"],
              "source_tree": plan["source_tree"], "argv": command, "cwd": str(source), "environment": environment,
              "root_parent": str(parent), "actual_euid": os.geteuid(), "started_unix": time.time(),
              "source_archive": plan["source_archive"], "nextest_archive": plan["nextest_archive"],
              "exit_code": None, "research_fixture_metadata": True, "independent_actor_custody": False,
              "same_root_process_storage_and_transport": True, "root_process_restarted": False,
              "deployed_non_root_consumer": False, "ordinary_P0_chain": False,
              "independent_confirmation_tasks": 0, "production_adopted": False,
              "scientific_gain_claimed": False}
    write_json(parent / "evidence/STARTED.json", record)
    log_path = parent / "evidence/root-handoff.log"
    start = time.monotonic()
    cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
    with log_path.open("xb") as log:
        result = subprocess.run(command, cwd=source, env=environment, stdout=log, stderr=subprocess.STDOUT)
    command_wall = time.monotonic() - start
    end_cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
    after = source_manifest(source)
    bound_after = {row["path"]: row for row in after}
    unchanged = all(bound_after.get(row["path"]) == row for row in before)
    additions = [row["path"] for row in after if row["path"] not in {item["path"] for item in before}]
    allowed_additions = all(path.startswith("codex-rs/target/nextest/") for path in additions)
    write_json(parent / "evidence/SOURCE_AFTER.json", after)
    raw = log_path.read_bytes()
    (parent / "evidence/root-handoff.log.gz").write_bytes(gzip.compress(raw, mtime=0))
    record.update({"exit_code": result.returncode, "completed_unix": time.time(),
                   "wall_seconds": command_wall,
                   "cost_scope": "just test subprocess and descendants; preparation and evidence work remain in the outer command record",
                   "child_cpu_seconds": end_cpu.ru_utime + end_cpu.ru_stime - cpu.ru_utime - cpu.ru_stime,
                   "child_peak_rss_kib": end_cpu.ru_maxrss, "source_files_unchanged": unchanged,
                   "new_source_paths": additions, "only_nextest_output_added": allowed_additions,
                   "raw_log_bytes": len(raw), "raw_log_sha256": hashlib.sha256(raw).hexdigest()})
    reports = [path for path in parent.rglob("junit.xml") if path.stat().st_mtime >= record["started_unix"]]
    cases = []
    if len(reports) == 1:
        report = reports[0].read_bytes()
        (parent / "evidence/root-handoff.junit.xml").write_bytes(report)
        for case in ET.fromstring(report).iter("testcase"):
            cases.append({"name": case.attrib["name"], "time": case.attrib.get("time"),
                          "failure": case.find("failure") is not None, "error": case.find("error") is not None,
                          "skipped": case.find("skipped") is not None})
    record["testcases"] = cases
    record["two_original_tests_passed"] = (
        result.returncode == 0 and len(cases) == 2
        and {case["name"].rsplit("::", 1)[-1] for case in cases} == TESTS
        and all(not (case["failure"] or case["error"] or case["skipped"]) for case in cases)
    )
    record["qualified_component_only"] = record["two_original_tests_passed"] and unchanged and allowed_additions
    write_json(parent / "evidence/RESULT.json", record)
    exports = []
    for name in ("RESULT.json", "ANCESTORS.json", "root-handoff.log.gz", "root-handoff.junit.xml"):
        path = parent / "evidence" / name
        if path.exists():
            data = path.read_bytes(); metadata = path.stat()
            exports.append({"name": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                            "path": str(path), "uid": metadata.st_uid, "mode": oct(stat.S_IMODE(metadata.st_mode)),
                            "inode": metadata.st_ino, "mtime_ns": metadata.st_mtime_ns,
                            "base64": base64.b64encode(data).decode()})
    print(json.dumps({"root_component_export": exports, "qualified_component_only": record["qualified_component_only"]}), flush=True)
    return 0 if record["qualified_component_only"] else (result.returncode or 92)


if __name__ == "__main__":
    sys.exit(run(*sys.argv[1:]))
