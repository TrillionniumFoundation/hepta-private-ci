from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = root / 'repo'
tool = repo / 'tools/argument-comment-lint'
stage = sys.argv[1]
assert stage in ('bootstrap', 'test', 'test-isolated-config')
drivers = root / 'lint-drivers'
drivers.mkdir(exist_ok=True)
env = dict(os.environ)
prefixes = [
    root / 'lint-nightly/cargo/bin',
    root / 'lint-tools/cargo-dylint-x86_64-unknown-linux-gnu-v6.3.2',
    root / 'lint-tools/dylint-link-x86_64-unknown-linux-gnu-v6.3.2',
    root.parent / 'runtime_audit_resume_20261125/toolchain/installed/bin',
]
env.update(
    PATH=os.pathsep.join(map(str, prefixes)) + os.pathsep + env['PATH'],
    CARGO_HOME=str(root / 'lint-nightly/cargo'),
    RUSTUP_HOME=str(root / 'lint-nightly/rustup'),
    RUSTUP_TOOLCHAIN='nightly-2025-09-18',
    DYLINT_DRIVER_PATH=str(drivers),
    CARGO_TARGET_DIR=str(root / 'lint-target'),
    CARGO_BUILD_JOBS='2',
    CARGO_INCREMENTAL='0',
    RUST_MIN_STACK='8388608',
)
tracked = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain', 'src/lib.rs', 'src/comment_parser.rs']
before = {name: hashlib.sha256((tool / name).read_bytes()).hexdigest() for name in tracked}
if stage == 'bootstrap':
    command = ['cargo', 'dylint', 'list', '--path', str(tool), '--all']
    cwd = tool
else:
    nextest_config = root / 'lint-nextest.toml' if stage == 'test-isolated-config' else repo / 'codex-rs/.config/nextest.toml'
    command = ['just', 'test', '--manifest-path', str(tool / 'Cargo.toml'), '--locked', '--config', str(tool / '.cargo/config.toml'), '--config-file', str(nextest_config)]
    cwd = repo / 'codex-rs'
log = root / f'lint-{stage}.log'
started = time.time()
with log.open('wb') as output:
    result = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT, check=False)
after = {name: hashlib.sha256((tool / name).read_bytes()).hexdigest() for name in tracked}
receipt = dict(stage=stage, command=command, cwd=str(cwd), started_at_unix=started, elapsed_seconds=time.time()-started, exit_code=result.returncode, before=before, after=after, inputs_unchanged=before == after, log_bytes=log.stat().st_size, log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(), driver_source='upstream default Clippy main clone; no DYLINT_CLIPPY_REPO override')
(root / f'lint-{stage}-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
print(log.read_text(errors='replace')[-12000:], flush=True)
raise SystemExit(result.returncode)
