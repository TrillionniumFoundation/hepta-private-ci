# Windows SSH fixture process boundary candidate

## Result

Source commit `93850ac9fb1c066f18ae12e7d0a7044ab513f22c` is a child of `29f845b6a214472906416cc0626551c19a4ab54e`. It changes only three test fixture files. Canonical trust paths, production trust code, all original test function bodies, live OpenSSH signing, native verification assertions, workflow filters and budgets remain intact.

The original Windows shard produced an actual operator target result of 30 passed and 13 failed in 0.26 seconds before the overall job was later cancelled. Every one of these 13 failures occurred after `ssh-keygen` was spawned and its nonzero exit reached the fixture assertion. These failures are independent of V8 timeouts. The old fixture discarded the numeric status and did not preserve child stderr in its failure diagnostics. Exact Windows causality therefore remains unresolved.

## Candidate behavior

The child process now runs in the same canonical fixture directory. Each file argument is relative to that directory, and the helper rejects empty, parent-traversal and outside-root arguments before spawning. Actual process success remains mandatory. Failures now report command, cwd, full ExitStatus, numeric exit code, stdout and stderr. No fake key generation, signature replacement, Windows skip or weakened trust assertion was introduced.

Rust's [canonicalize documentation](https://doc.rust-lang.org/std/fs/fn.canonicalize.html) describes the Windows extended-length path interoperability boundary. The source inspection receipt also identifies the exact upstream Win32-OpenSSH blob examined. This is a source-supported portability correction, not a claim that the original Windows failure was reproduced. The runner's selected OpenSSH executable version and exact exit code were not recorded. Captured output also supplies pipes/null stdin instead of inherited standard streams, so a future pass would not by itself isolate path handling from stdio behavior.

## Actual validation

`just fmt` and `git diff --check` passed. A small Rust probe directly included the modified `test_support.rs`, used the existing Rust 1.95.0 compiler and cached tempfile library, and executed six real OpenSSH processes on Linux. It checked empty-passphrase Ed25519 key generation, fingerprinting, a root directory and filenames containing spaces, signing a nested file, successful verification in the original namespace, and rejection of an incorrect namespace. A real missing-file command returned code 255 and proved that command/cwd/status/code/stdout/stderr reach the failure message. Three invalid relative-file cases were rejected before process creation.

`live-probe.stderr.txt` contains expected, caught panic diagnostics from those negative controls; the final probe process exited 0. No private key bytes were read into the report or printed. The probe compiled in approximately 0.23 seconds and ran in approximately 0.03 seconds. The 140028 KiB child RSS value is a cumulative maximum across compile and run, not a measurement of the SSH process alone.

The full original 43-test crate and Windows CI were not executed in this packet. The parent requested no heavy native builds while the existing cold Bazel lane was running and disk space was constrained. This packet establishes only Linux fixture-boundary behavior. **Windows qualification remains pending the original Windows CI.**

## Files and reproduction

`source.bundle` contains the three-file source commit and requires the recorded base commit. `source.patch` is the same exact delta. `source/` preserves the candidate bytes. `SOURCE_IDENTITY.json` and `MANIFEST.json` bind the commit, tree and all published bytes. `original/` preserves the original compressed log, first-panics extraction and job receipt without modification. `ANALYSIS.json` separates observations, source inference, candidate behavior and remaining qualification.

`LINUX_BOUNDARY_VALIDATION.json` records the exact compiler command, dependency hash, include-path environment setting, executable digest, output hashes and timestamps. `live_ssh_probe.rs` takes the actual helper path through `HEPTA_SSH_FIXTURE_SUPPORT` at compile time. The 4.7 MB executable is reproducible and intentionally excluded from publication; its digest remains in the receipt.

The separate scout trigger receipt records that both existing resource scout workflows accept only owner-branch `push` events and expose no `workflow_dispatch`. This packet makes no remote writes and changes no resource workflows.
