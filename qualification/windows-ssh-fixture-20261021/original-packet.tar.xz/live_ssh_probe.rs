mod test_support {
    include!(env!("HEPTA_SSH_FIXTURE_SUPPORT"));
}

use std::fs::File;
use std::os::unix::fs::PermissionsExt;
use std::panic::AssertUnwindSafe;
use std::panic::catch_unwind;
use std::process::Stdio;

use test_support::private_tempdir;
use test_support::run_ssh_keygen;
use test_support::ssh_keygen;
use test_support::ssh_keygen_path;

fn main() {
    let temporary = private_tempdir("live SSH fixture boundary probe");
    let root = temporary.path().join("fixture root with spaces");
    std::fs::create_dir(&root).unwrap();
    std::fs::set_permissions(&root, std::fs::Permissions::from_mode(0o700)).unwrap();
    let root = root.canonicalize().unwrap();
    let parent_cwd = std::env::current_dir().unwrap();
    assert_ne!(parent_cwd, root);
    let key = root.join("operator key");

    run_ssh_keygen(
        ssh_keygen(&root)
            .args(["-q", "-t", "ed25519", "-N", "", "-f"])
            .arg(ssh_keygen_path(&root, &key)),
    );
    let fingerprint = run_ssh_keygen(
        ssh_keygen(&root)
            .args(["-E", "sha256", "-lf"])
            .arg(ssh_keygen_path(&root, &key.with_extension("pub"))),
    );
    assert!(String::from_utf8_lossy(&fingerprint.stdout).contains("SHA256:"));
    let public = std::fs::read_to_string(key.with_extension("pub")).unwrap();
    assert!(public.starts_with("ssh-ed25519 "));
    let allowed_signers = root.join("allowed signers");
    std::fs::write(&allowed_signers, format!("operator@example {public}")).unwrap();
    let nested = root.join("nested inputs");
    std::fs::create_dir(&nested).unwrap();
    let statement = nested.join("signed statement");
    std::fs::write(&statement, b"canonical operator acceptance statement\n").unwrap();
    let namespace = "hepta-vnext-operator-acceptance-v1";
    run_ssh_keygen(
        ssh_keygen(&root)
            .args(["-Y", "sign", "-f"])
            .arg(ssh_keygen_path(&root, &key))
            .args(["-n", namespace])
            .arg(ssh_keygen_path(&root, &statement)),
    );
    let signature = statement.with_extension("sig");
    assert!(signature.is_file());
    run_ssh_keygen(
        ssh_keygen(&root)
            .args(["-Y", "verify", "-f"])
            .arg(ssh_keygen_path(&root, &allowed_signers))
            .args(["-I", "operator@example", "-n", namespace, "-s"])
            .arg(ssh_keygen_path(&root, &signature))
            .stdin(Stdio::from(File::open(&statement).unwrap())),
    );
    let wrong_namespace = ssh_keygen(&root)
        .args(["-Y", "verify", "-f"])
        .arg(ssh_keygen_path(&root, &allowed_signers))
        .args(["-I", "operator@example", "-n", "wrong-namespace", "-s"])
        .arg(ssh_keygen_path(&root, &signature))
        .stdin(Stdio::from(File::open(&statement).unwrap()))
        .output()
        .unwrap();
    assert!(!wrong_namespace.status.success());
    println!(
        "wrong_namespace: status={:?}; code={:?}; stdout={:?}; stderr={:?}",
        wrong_namespace.status,
        wrong_namespace.status.code(),
        String::from_utf8_lossy(&wrong_namespace.stdout),
        String::from_utf8_lossy(&wrong_namespace.stderr),
    );
    assert_eq!(std::env::current_dir().unwrap(), parent_cwd);
    println!(
        "PASS: live Ed25519 key generation, fingerprint, nested-file signing, exact-namespace verification, wrong-namespace rejection; directory and filenames contain spaces"
    );

    let failure = catch_unwind(AssertUnwindSafe(|| {
        run_ssh_keygen(
            ssh_keygen(&root)
                .args(["-E", "sha256", "-lf"])
                .arg(ssh_keygen_path(&root, &root.join("missing public key"))),
        );
    }))
    .expect_err("missing key must remain an actual process failure");
    let message = failure
        .downcast_ref::<String>()
        .expect("diagnostic assertion is a String");
    for field in [
        "command=",
        "cwd=",
        "status=",
        "code=Some(",
        "stdout=",
        "stderr=",
        "missing public key",
    ] {
        assert!(message.contains(field), "missing diagnostic field: {field}");
    }
    println!("PASS: real nonzero OpenSSH exit retains command/cwd/status/code/stdout/stderr");

    let other = private_tempdir("separate SSH fixture root");
    for path in [
        root.clone(),
        root.join("../outside key"),
        other.path().join("outside key"),
    ] {
        assert!(
            catch_unwind(|| ssh_keygen_path(&root, &path)).is_err(),
            "empty and out-of-root file arguments must fail before process creation"
        );
    }
    println!("PASS: empty, parent-traversal and separate-root arguments rejected before spawning");
    println!(
        "SUMMARY: 6 real OpenSSH processes, 3 pre-spawn path guards; Linux boundary probe only; original 43-test crate and Windows CI not run"
    );
}
