"""Native gates for an explicitly marked three-crate exact-source projection."""
import argparse, hashlib, json, os
from pathlib import Path
import re, shutil, subprocess, time, tomllib, xml.etree.ElementTree as ET
ROOT = Path('/home/qian-qi/work/memory-cell-mem1-20261108-r1')
SOURCE = ROOT / 'projection'
MAIN = '732e934ba496d90fbe042b8d41d479ef901643e5'
TARGET = ROOT / 'target'


def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def git(*args): return subprocess.check_output(['git','-C',str(SOURCE),*args],timeout=90)

def identity():
    overlay=json.loads((ROOT/'overlay.json').read_text())
    return {'projection_baseline_commit':git('rev-parse','HEAD').decode().strip(),
            'candidate_tree':git('write-tree').decode().strip(),
            'rust_patch_sha256':hashlib.sha256(git('diff','--binary','HEAD')).hexdigest(),
            'files':{x['path']:digest(SOURCE/x['path']) for x in overlay['files']}}

def environment():
    env=os.environ.copy()
    env.update({'CARGO_TARGET_DIR':str(TARGET),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0',
                'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','LIBCLANG_PATH':'/usr/lib/llvm-21/lib',
                'NEXTEST_PROFILE':'local','NEXTEST_TEST_THREADS':'2','RUSTUP_TOOLCHAIN':'1.96.0','RUST_MIN_STACK':'8388608',
                'PATH':'/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin'})
    return env

def apply_overlay():
    manifest=json.loads((SOURCE/'projection-manifest.json').read_text())
    if manifest['source_commit']!=MAIN: raise RuntimeError('source base mismatch')
    overlay=json.loads((ROOT/'overlay.json').read_text())
    if digest(SOURCE/'codex-rs/hepta-memory-retrieval/src/lib.rs')!=overlay['base_lib_sha256']:
        raise RuntimeError('baseline lib bytes differ')
    checked=[]
    for item in overlay['files']:
        relative=Path(item['path'])
        if relative.is_absolute() or '..' in relative.parts: raise RuntimeError('unsafe overlay path')
        p=SOURCE/relative; before=digest(p) if p.exists() else None
        if before!=item['before_sha256']: raise RuntimeError('stale overlay path '+str(relative))
        raw=item['content'].encode()
        if hashlib.sha256(raw).hexdigest()!=item['sha256']: raise RuntimeError('overlay payload digest mismatch')
        checked.append((p,raw))
    for p,raw in checked:
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    git('add','--',*(x['path'] for x in overlay['files'] if x['path'].endswith('.rs')))


def prepare():
    env=environment()
    before=tomllib.loads((SOURCE/'codex-rs/Cargo.lock').read_text())
    original={(x['name'],x['version'],x.get('source'),x.get('checksum')) for x in before['package']}
    prep=ROOT/'evidence/preparation';prep.mkdir(parents=True,exist_ok=False)
    log=prep/'cargo-metadata.log'
    with log.open('wb') as stream:
        p=subprocess.run(['cargo','metadata','--offline','--format-version=1'],cwd=SOURCE/'codex-rs',env=env,stdout=stream,stderr=subprocess.STDOUT)
    if p.returncode:
        print(log.read_text()[-12000:],flush=True);raise RuntimeError('offline projected lock resolution failed')
    after=tomllib.loads((SOURCE/'codex-rs/Cargo.lock').read_text())
    resolved={(x['name'],x['version'],x.get('source'),x.get('checksum')) for x in after['package']}
    if not resolved<=original: raise RuntimeError('resolved dependency differs from original main lock')
    (prep/'resolved-lock.json').write_text(json.dumps({'source_commit':MAIN,'projected_cargo_lock_sha256':digest(SOURCE/'codex-rs/Cargo.lock'),'registry_identities_match_original':True,'packages':[dict(zip(['name','version','source','checksum'],x)) for x in sorted(resolved,key=lambda x:(x[0],x[1]))]},indent=2)+'\n')
    git('init')
    # These are retained harness inputs, not part of the Rust formatting scope.
    (SOURCE/'.git/info/exclude').write_text('codex-rs/target/\nscripts/memory_cell_mem1/\nqualification/memory-cell-mem1/\n**/__pycache__/\n')
    git('add','--all')
    git('-c','user.name=Hepta Native Projection','-c','user.email=projection@localhost','commit','-m','Local exact-source build projection; not a published upstream commit')
    apply_overlay()
    print(json.dumps({'prepared':str(SOURCE),'scope':'three-crate exact-source projection','source_commit':MAIN,'resolved_packages':len(resolved),'identity':identity()}),flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['prepare','build','maintenance','smoke']);parser.add_argument('--attempt',default='v1');args=parser.parse_args()
    if args.phase=='prepare':prepare();return
    output=ROOT/'evidence'/f'{args.phase}-{args.attempt}';output.mkdir(parents=True,exist_ok=False)
    result={'source_commit':MAIN,'qualification':'three-crate exact-source projection; not full-workspace validation','phase':args.phase,'steps':[]}
    try:
        before=identity();result['source_before']=before;env=environment();result['versions']={}
        for name,argv in [('rustc',['rustc','--version']),('just',['just','--version']),('nextest',['cargo','nextest','--version'])]:
            result['versions'][name]=subprocess.check_output(argv,env=env,text=True,timeout=20).strip()
        if args.phase=='build':
            commands=[('core-tests',['just','test','--locked','--offline','-p','codex-hepta-memory-retrieval','--lib','--test-threads','2']),('example-build',['cargo','build','--locked','--offline','--message-format=json-render-diagnostics','-p','codex-hepta-memory-retrieval','--example','mem1_fast_memory'])]
        elif args.phase=='maintenance':
            commands=[('clippy',['just','fix','--locked','--offline','-p','codex-hepta-memory-retrieval','--lib','--examples','--','-D','warnings']),('fmt',['just','fmt','--base',before['projection_baseline_commit']])]
        else:
            smoke=ROOT/'evidence'/f'smoke-campaign-{args.attempt}'
            commands=[('smoke',['python3',str(SOURCE/'scripts/memory_cell_mem1/run.py'),'--native',str(ROOT/'bin/mem1_fast_memory'),'--output',str(smoke),'--seeds','0','--arms','fast']),('verify',['python3',str(SOURCE/'scripts/memory_cell_mem1/verify_results.py'),str(smoke)])]
        for name,argv in commands:
            started=time.time_ns();log=output/f'{name}.log'
            with log.open('xb') as stream:
                process=subprocess.run(argv,cwd=SOURCE/'codex-rs',env=env,stdout=stream,stderr=subprocess.STDOUT)
            row={'name':name,'argv':argv,'exit_code':process.returncode,'wall_seconds':(time.time_ns()-started)/1e9,'log':str(log),'log_sha256':digest(log)}
            if name=='core-tests' and process.returncode==0:
                junit=SOURCE/'codex-rs/target/nextest/local/junit.xml'
                if not junit.is_file() or junit.stat().st_mtime_ns<started:raise RuntimeError('no fresh JUnit')
                raw=junit.read_bytes();xml=ET.fromstring(raw);match=re.search(r'Nextest run ID ([0-9a-f-]{36})',log.read_text())
                if match is None or xml.attrib.get('uuid')!=match.group(1):raise RuntimeError('JUnit run UUID mismatch')
                (output/'core-tests.xml').write_bytes(raw);cases=xml.findall('.//testcase')
                row['junit']={'sha256':hashlib.sha256(raw).hexdigest(),'attributes':xml.attrib,'testcases':len(cases),'names':[x.attrib for x in cases],'failures':[x.attrib for x in cases if x.find('failure') is not None or x.find('error') is not None]}
            if name=='example-build' and process.returncode==0:
                artifacts=[]
                for line in log.read_text().splitlines():
                    try:message=json.loads(line)
                    except json.JSONDecodeError:continue
                    if message.get('reason')=='compiler-artifact' and message.get('target',{}).get('name')=='mem1_fast_memory' and message.get('executable'):artifacts.append(message)
                if len(artifacts)!=1:raise RuntimeError('missing or ambiguous binary artifact')
                original=Path(artifacts[0]['executable']);pin=ROOT/'bin/mem1_fast_memory';pin.parent.mkdir(exist_ok=True)
                if pin.exists(): pin.chmod(0o755)
                shutil.copyfile(original,pin);pin.chmod(0o555)
                if digest(original)!=digest(pin):raise RuntimeError('binary changed during pinning')
                row['binary']={'path':str(pin),'sha256':digest(pin),'size':pin.stat().st_size,'compiler_artifact':artifacts[0]}
            result['steps'].append(row)
            print(json.dumps({'name':name,'exit_code':process.returncode,'wall_seconds':row['wall_seconds'],'log':str(log),'tests':row.get('junit',{}).get('testcases'),'binary':row.get('binary',{}).get('path')}),flush=True)
            if process.returncode: print(log.read_text()[-16000:],flush=True);break
        result['source_after']=identity()
        if args.phase!='maintenance' and result['source_after']!=before:raise RuntimeError('source changed during native gate')
        if args.phase=='maintenance':(output/'changes.patch').write_bytes(git('diff','--binary','HEAD'))
    except Exception as error:result['error']={'type':type(error).__name__,'message':str(error)}
    (output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'result':str(output/'result.json'),'error':result.get('error'),'exit_codes':[x['exit_code'] for x in result['steps']]}),flush=True)
    if result.get('error') or not result['steps'] or any(x['exit_code'] for x in result['steps']):raise SystemExit(1)
if __name__=='__main__':main()
