from pathlib import Path
import hashlib,json,re,tarfile,io,tomllib
root=Path('/workspace/scratch/eb987333a9b4/memory-cell'); base=root/'baseline'; code=root/'code'; native=root/'native'
workspace=(base/'codex-rs/Cargo.toml').read_text(); parsed=tomllib.loads(workspace)
sections={m.group(1):m.group(0) for m in re.finditer(r'^\[([^\n]+)\]\n.*?(?=^\[|\Z)',workspace,re.M|re.S)}
projection='[workspace]\nmembers = ["hepta-types", "hepta-cognitive-types", "hepta-memory-retrieval"]\nresolver = '+json.dumps(parsed['workspace'].get('resolver','2'))+'\n\n'
for name in ['workspace.package','workspace.lints','workspace.lints.clippy']:
 projection+=sections[name]+'\n'
projection+='[workspace.dependencies]\nsha2 = "0.10"\nserde = { version = "1", features = ["rc"] }\nserde_json = "1"\n'
config=(base/'codex-rs/.config/nextest.toml').read_text(); nextest=''
for m in re.finditer(r'^\[([^\n]+)\]\n.*?(?=^\[|\Z)',config,re.M|re.S):
 if m.group(1) in ['profile.default','profile.default.junit','profile.local']:nextest+=m.group(0)+'\n'
files={}
for name in ['hepta-types','hepta-cognitive-types','hepta-memory-retrieval']:
 for p in (base/'codex-rs'/name).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:
   files[str(p.relative_to(base))]=p.read_bytes()
for rel in ['justfile','scripts/just-shell.py','scripts/run-nextest.py','scripts/format.py','codex-rs/Cargo.lock']:
 files[rel]=(base/rel).read_bytes()
files['codex-rs/Cargo.toml']=projection.encode();files['codex-rs/.config/nextest.toml']=nextest.encode()
manifest={'source_commit':'732e934ba496d90fbe042b8d41d479ef901643e5','qualification':'three-crate exact-source projection; not full workspace','workspace_manifest_original_sha256':hashlib.sha256(workspace.encode()).hexdigest(),'nextest_config_original_sha256':hashlib.sha256(config.encode()).hexdigest(),'transformations':['workspace membership and external dependencies reduced to transitive three-crate closure','nextest profiles and junit retained; unrelated package overrides omitted','lockfile may be pruned offline; all resolved registry identities must match original lockfile'],'baseline_files':{rel:hashlib.sha256(raw).hexdigest() for rel,raw in files.items()}}
files['projection-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with tarfile.open(native/'projection-base.tar.xz','w:xz') as tf:
 for rel,raw in files.items():
  info=tarfile.TarInfo(rel);info.size=len(raw);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(raw))
paths=['codex-rs/hepta-memory-retrieval/src/lib.rs','codex-rs/hepta-memory-retrieval/src/fast_memory.rs','codex-rs/hepta-memory-retrieval/src/fast_memory_tests.rs','codex-rs/hepta-memory-retrieval/examples/mem1_fast_memory.rs']
paths+=sorted(str(p.relative_to(code)) for p in (code/'scripts/memory_cell_mem1').glob('*.py'))
paths+=['qualification/memory-cell-mem1/PROTOCOL.md']
overlay=[]
for rel in paths:
 raw=(code/rel).read_bytes(); before=(base/rel)
 overlay.append({'path':rel,'content':raw.decode(),'sha256':hashlib.sha256(raw).hexdigest(),'before_sha256':hashlib.sha256(before.read_bytes()).hexdigest() if before.exists() else None})
payload={'base_lib_sha256':'29208957d293bfd076977093a01ee36451dcd9cb370b9c26e22dfe20774c21d1','files_sha256':hashlib.sha256(json.dumps([(x['path'],x['sha256']) for x in overlay],sort_keys=True).encode()).hexdigest(),'files':overlay}
(native/'overlay-v2.json').write_text(json.dumps(payload))
print(json.dumps({'base_files':len(files),'archive_bytes':(native/'projection-base.tar.xz').stat().st_size,'archive_sha256':hashlib.sha256((native/'projection-base.tar.xz').read_bytes()).hexdigest(),'overlay_files':len(overlay),'files_sha256':payload['files_sha256'],'resolver':parsed['workspace'].get('resolver')}))
