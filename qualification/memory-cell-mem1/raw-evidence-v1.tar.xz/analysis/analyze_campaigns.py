"""Create descriptive pilot aggregates; raw-event validation remains separate."""
import argparse
import hashlib
import json
import statistics
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    report = {"schema": "mem1-descriptive-pilot-aggregate-v1", "conditions": {},
              "statistical_unit": "five independent synthetic stream seeds",
              "inference": "descriptive only; no real-task or production qualification"}
    metrics = {
        "a1_stable_accuracy": lambda r: r["panels"]["A1"]["stable"]["accuracy"],
        "after_b_stable_accuracy": lambda r: r["panels"]["B"]["stable"]["accuracy"],
        "final_stable_accuracy": lambda r: r["panels"]["A2"]["stable"]["accuracy"],
        "retention_delta": lambda r: r["retention_delta"],
        "b_prequential_accuracy": lambda r: r["b_prequential_accuracy"],
        "final_superseded_accuracy": lambda r: r["panels"]["A2"]["superseded"]["accuracy"],
        "final_composition_accuracy": lambda r: r["panels"]["A2"]["composition"]["accuracy"],
        "final_stable_coverage": lambda r: r["panels"]["A2"]["stable"]["coverage"],
        "kernel_multiplications": lambda r: r["capacity_and_compute"]["kernel_multiplications"],
        "owner_checks": lambda r: r["capacity_and_compute"]["owner_checks"],
        "peak_pool_payload_bytes": lambda r: r["capacity_and_compute"]["pool_payload_bytes"],
        "reserved_state_payload_bytes": lambda r: r["capacity_and_compute"]["state_payload_bytes"],
        "wall_ms": lambda r: r["wall_ns"] / 1e6,
        "python_cpu_ms": lambda r: r["python_cpu_ns"] / 1e6,
        "native_child_cpu_ms": lambda r: r["native_child_cpu_ns"] / 1e6,
        "native_calls": lambda r: r["native_calls"],
        "sleep_updates": lambda r: r["counts"]["sleep_updates"],
        "rebuild_updates": lambda r: r["counts"]["rebuild_updates"],
        "online_updates": lambda r: r["counts"]["online_updates"],
    }
    for manifest_path in sorted(args.root.rglob("manifest.json")):
        manifest = json.loads(manifest_path.read_text())
        if manifest.get("schema") != "hepta-mem1-reference-v1" or manifest.get("planned_runs") != 35:
            continue
        condition = "dynamic" if manifest["owner_change"] else "stationary"
        if condition in report["conditions"]:
            raise ValueError(f"duplicate condition: {condition}")
        path = manifest_path.parent / "results.json"
        rows = json.loads(path.read_text())
        if len(rows) != 35 or any(r["status"] != "completed" for r in rows):
            raise ValueError("incomplete campaign")
        by_arm = {}
        for arm in manifest["arms"]:
            selected = sorted((r for r in rows if r["arm"] == arm), key=lambda r: r["seed"])
            result = {"seeds": [r["seed"] for r in selected], "metrics": {}, "threshold_samples": [], "probe_counts": {}}
            for name, value in metrics.items():
                values = [value(r) for r in selected]
                result["metrics"][name] = {"mean": statistics.mean(values), "min": min(values), "max": max(values), "by_seed": values}
            result["threshold_samples"] = [r["b_samples_to_80pct_window16"] for r in selected]
            result["threshold_censored"] = sum(r["b_threshold_censored"] for r in selected)
            for name in ("wrong_assertions", "stale_assertions", "invalid_assertions"):
                result["probe_counts"][name] = sum(panel[name] for r in selected for panels in r["panels"].values() for panel in panels.values())
            result["probe_counts"]["total_probes"] = sum(panel["n"] for r in selected for panels in r["panels"].values() for panel in panels.values())
            result["native_recoveries"] = sum(sum(r["native_recoveries"]) for r in selected)
            by_arm[arm] = result
        paired = {}
        for left, right in [("fast_uniform", "fast"), ("fast_structured", "fast_uniform"), ("fast_stabilized", "fast_structured")]:
            comparison = {}
            for name in ("a1_stable_accuracy", "after_b_stable_accuracy", "final_stable_accuracy", "retention_delta", "b_prequential_accuracy", "kernel_multiplications", "wall_ms"):
                values = [a - b for a, b in zip(by_arm[left]["metrics"][name]["by_seed"], by_arm[right]["metrics"][name]["by_seed"])]
                comparison[name] = {"mean": statistics.mean(values), "min": min(values), "max": max(values), "by_seed": values}
            paired[f"{left}_minus_{right}"] = comparison
        report["conditions"][condition] = {"relative_directory": str(manifest_path.parent.relative_to(args.root)),
            "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
            "results_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "arms": by_arm, "paired_differences": paired}
    if set(report["conditions"]) != {"dynamic", "stationary"}:
        raise ValueError("both 35-run conditions required")
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    for name, condition in report["conditions"].items():
        print(name)
        print("arm A1 afterB delta final Bpreq compos stale wrong invalid mult wall_ms threshold")
        for arm, row in condition["arms"].items():
            m = row["metrics"]
            vals = [m[k]["mean"] for k in ("a1_stable_accuracy", "after_b_stable_accuracy", "retention_delta", "final_stable_accuracy", "b_prequential_accuracy", "final_composition_accuracy")]
            print(arm, *[round(v, 5) for v in vals], row["probe_counts"]["stale_assertions"], row["probe_counts"]["wrong_assertions"], row["probe_counts"]["invalid_assertions"], m["kernel_multiplications"]["mean"], round(m["wall_ms"]["mean"], 3), row["threshold_samples"])


if __name__ == "__main__":
    main()
