import pathlib,subprocess,json,hashlib,datetime,gzip,zipfile,io
base=pathlib.Path("/home/qian-qi/hcsn-smallnet-20261124/dependency-residual-patch-v1/hosted-sdk-pass-v1");base.mkdir(exist_ok=False)
head="e4f2cfa6f4f6bbc356ae20200eda3cd78ab92dd1";run_id=45540235075;job_id=138957422954;rows=[]
def fetch(name,endpoint):
 p=base/name
 with p.open("xb") as out:proc=subprocess.run(["gh","api","--method","GET",endpoint],stdout=out,stderr=subprocess.PIPE,timeout=120)
 data=p.read_bytes()
 row={"name":name,"endpoint":endpoint,"exit_code":proc.returncode,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"stderr":proc.stderr.decode(errors="replace")}
 rows.append(row)
 if proc.returncode:raise RuntimeError(row["stderr"])
 return data
meta=json.loads(fetch("SDK_JOB.json",f"repos/TrillionniumFoundation/hepta-private-ci/actions/jobs/{job_id}"))
assert meta["head_sha"]==head and meta["run_id"]==run_id and meta["status"]=="completed" and meta["conclusion"]=="success"
raw=fetch("SDK_ORIGINAL.log",f"repos/TrillionniumFoundation/hepta-private-ci/actions/jobs/{job_id}/logs")
text=raw.decode("utf-8")
(base/"SDK_ORIGINAL.log.gz").write_bytes(gzip.compress(raw,mtime=0))
listing=json.loads(fetch("ARTIFACT_LIST.json",f"repos/TrillionniumFoundation/hepta-private-ci/actions/runs/{run_id}/artifacts?per_page=100"))
assert listing["total_count"]<=100
selected=[a for a in listing["artifacts"] if a["name"]=="sdk-mcp-conformance-reports"]
artifacts=[]
for a in selected:
 assert not a["expired"]
 data=fetch(f"artifact-{a['id']}.zip",f"repos/TrillionniumFoundation/hepta-private-ci/actions/artifacts/{a['id']}/zip")
 if a.get("digest"):assert a["digest"]=="sha256:"+hashlib.sha256(data).hexdigest()
 members=[]
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  assert z.testzip() is None
  for m in z.infolist():
   p=pathlib.PurePosixPath(m.filename);assert not p.is_absolute() and ".." not in p.parts
   if m.is_dir():continue
   b=z.read(m.filename);members.append({"path":m.filename,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"json":json.loads(b)})
 artifacts.append({"id":a["id"],"name":a["name"],"api_digest":a.get("digest"),"zip_bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"members":members})
receipt={"schema":1,"observed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head_sha":head,"run_id":run_id,"job_id":job_id,"job_conclusion":meta["conclusion"],"requests":rows,"artifacts":artifacts}
(base/"FETCH_RECEIPT.json").write_text(json.dumps(receipt,indent=2)+"\n")
lines=text.splitlines()
proof=[line for line in lines if any(s in line for s in ["HEAD is now at","git rev-parse HEAD","SOURCE_SHA:","COMMIT_SHA","//codex-rs/cli:codex","//codex-rs/code-mode-host:codex-code-mode-host","Build completed successfully","Test Suites:","Tests:","Snapshots:","PASS ","FAIL ","Test SDK packages","pnpm -r --filter ./sdk/typescript run test"])]
print(json.dumps({"head":head,"job":job_id,"raw_bytes":len(raw),"raw_sha256":hashlib.sha256(raw).hexdigest(),"artifact_count":len(artifacts),"artifact_members":[{"id":a["id"],"member_names":[m["path"] for m in a["members"]]} for a in artifacts],"proof_lines":proof},indent=2))
