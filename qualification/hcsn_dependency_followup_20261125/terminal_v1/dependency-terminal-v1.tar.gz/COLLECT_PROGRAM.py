"""Capture completed hosted proof and honestly classify the cancelled local build."""

import datetime
import gzip
import hashlib
import io
import json
import pathlib
import re
import subprocess
import tarfile

BASE = pathlib.Path("/home/qian-qi/hcsn-smallnet-20261124/dependency-residual-patch-v1")
SOURCE = "e4f2cfa6f4f6bbc356ae20200eda3cd78ab92dd1"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    output = BASE / "terminal-evidence-v1"
    output.mkdir(exist_ok=False)
    hosted = BASE / "hosted-sdk-pass-v1"
    native = BASE / "native-sdk-v1"
    metadata = json.loads((hosted / "SDK_JOB.json").read_text())
    fetch = json.loads((hosted / "FETCH_RECEIPT.json").read_text())
    raw = (hosted / "SDK_ORIGINAL.log").read_bytes()
    text = re.sub(r"\x1b\[[0-9;]*m", "", raw.decode()).replace("\r\n", "\n")
    assert metadata["head_sha"] == SOURCE and metadata["conclusion"] == "success"
    assert metadata["id"] == 138957422954 and metadata["run_id"] == 45540235075
    assert set(re.findall(r"SOURCE_SHA: ([0-9a-f]{40})", text)) == {SOURCE}
    assert "HEAD is now at e4f2cfa6" in text
    assert 'Run test "$(git rev-parse HEAD)" = "$SOURCE_SHA"' in text
    assert "--build_metadata=COMMIT_SHA=${SOURCE_SHA}" in text
    assert "//codex-rs/cli:codex" in text
    assert "//codex-rs/code-mode-host:codex-code-mode-host" in text
    assert "Build completed successfully, 25041 total actions" in text
    assert "Run pnpm -r --filter ./sdk/typescript run test\n" in text
    assert "Test Suites: 5 passed, 5 total" in text
    assert "Tests:       47 passed, 47 total" in text
    assert re.search(r"Artifact ID(?: is|:)?\s*14989107963\b", text)
    steps = {s["name"]: s for s in metadata["steps"]}
    required_steps = [
        "Verify exact SDK source", "Build codex and code-mode host with Bazel",
        "Warm up Bazel-built SDK executables", "Install dependencies",
        "Build SDK packages", "Lint SDK packages", "Test SDK packages",
        "Preserve MCP conformance reports", "Check for a clean worktree",
    ]
    for name in required_steps:
        assert steps[name]["conclusion"] == "success", name
    artifact = fetch["artifacts"][0]
    assert artifact["id"] == 14989107963 and len(artifact["members"]) == 2
    assert artifact["sha256"] == sha((hosted / "artifact-14989107963.zip").read_bytes())
    assert artifact["api_digest"] == "sha256:" + artifact["sha256"]
    start = datetime.datetime.fromisoformat(metadata["started_at"].replace("Z", "+00:00"))
    end = datetime.datetime.fromisoformat(metadata["completed_at"].replace("Z", "+00:00"))
    proof_lines = [line for line in text.splitlines() if any(s in line for s in (
        "HEAD is now at e4f2cfa6", 'Run test "$(git rev-parse HEAD)"',
        "--build_metadata=COMMIT_SHA=${SOURCE_SHA}", "Build completed successfully",
        "Run pnpm -r --filter ./sdk/typescript run test", "PASS tests/",
        "Test Suites:", "Tests:", "Snapshots:", "14989107963",
    ))]
    acceptance = {
        "schema": 1, "decision": "PASS_EXACT_CANDIDATE_HOSTED_NATIVE_AND_FULL_SDK",
        "source_commit": SOURCE, "workflow_run": metadata["run_id"], "job": metadata["id"],
        "job_url": metadata["html_url"], "job_started_at": metadata["started_at"],
        "job_completed_at": metadata["completed_at"], "complete_job_wall_seconds": (end-start).total_seconds(),
        "hosted_cpu_seconds": None, "hosted_rss_bytes": None,
        "log_bytes": len(raw), "log_sha256": sha(raw),
        "checked_out_source_verified_in_original_log": True,
        "required_steps": [steps[name] for name in required_steps],
        "native_targets": ["//codex-rs/cli:codex", "//codex-rs/code-mode-host:codex-code-mode-host"],
        "bazel_total_actions": 25041, "native_warmup_and_original_full_test_command_passed": True,
        "jest": {"suites_passed": 5, "suites_total": 5, "tests_passed": 47, "tests_total": 47, "failed": 0, "skipped": 0, "snapshots_total": 0},
        "proof_lines": proof_lines,
        "published_artifact": {k: artifact[k] for k in ("id", "name", "api_digest", "zip_bytes", "sha256")},
        "published_artifact_members": [{k: m[k] for k in ("path", "bytes", "sha256")} for m in artifact["members"]],
        "binary_sha256": None,
        "binary_identity_scope": "The workflow staged and exercised Bazel-produced executables from the exact source. It published the two MCP reports, not executable binaries or binary checksums; no checksum is invented.",
        "scope": "This SDK job checked out the exact PR source. It does not grant all other jobs or the default branch a pass, and does not close GitHub advisory alerts.",
    }
    (output / "HOSTED_ACCEPTANCE.json").write_text(json.dumps(acceptance, indent=2)+"\n")
    native_receipt = json.loads((native / "RECEIPT.json").read_text())
    preparation = json.loads((native / "CANCEL_PREPARATION.json").read_text())
    observation = json.loads((native / "PTY_TERMINAL_OBSERVATION.json").read_text())
    assert observation["status"]["state"] == "exited" and observation["status"]["exit_code"] == 1
    assert observation["output_complete"] and observation["status"]["capture_error"] is None
    assert observation["offset"] == 0 and observation["next_offset"] == observation["available_end"]
    assert sha((native / "NATIVE_PTY.log").read_bytes()) == observation["chunk_sha256"]
    assert native_receipt["final_tracked_changes"] == ["package.json", "pnpm-lock.yaml"]
    assert native_receipt["operations"][-1]["name"] == "bazel-shutdown"
    assert native_receipt["operations"][-1]["exit_code"] == 0
    scope = subprocess.run([
        "systemctl", "--user", "show", "hcsn-dependency-native-sdk-v1.scope",
        "--property=ActiveState", "--property=LoadState", "--property=CPUUsageNSec", "--property=MemoryPeak",
    ], capture_output=True, text=True, timeout=15)
    assert "ActiveState=inactive" in scope.stdout
    native_log = (native / "bazel-sdk-build.log").read_text(errors="replace")
    error_lines = [line for line in native_log.splitlines()
                   if re.match(r"^(ERROR:|FATAL:|error:|error\[)", line) or "OutOfMemoryError" in line]
    non_cancel_errors = [line for line in error_lines if not any(w in line.lower() for w in ("interrupt", "cancel"))]
    classification = {
        "schema": 1, "classification": "CANCELLED_AS_REDUNDANT_AFTER_EXACT_HOSTED_PASS",
        "local_native_pass": False, "local_full_jest_replayed": False,
        "cancellation_transport": "One control-C via the runtime-owned dedicated PTY; no PID kill.",
        "native_pty_exit_code": 1, "dedicated_bazel_shutdown_exit_code": 0,
        "driver_interrupt_reporting_issue": "The original driver entered finally after KeyboardInterrupt, shut down its own Bazel server successfully, persisted final source/cost fields, then raised KeyError for its unset status display. Original raw receipt/log are retained unchanged.",
        "measured_driver_wall_seconds": native_receipt["wall_seconds"],
        "pre_cancel_scope_snapshot": preparation["pre_cancel_scope_snapshot"],
        "post_cancel_scope_snapshot": scope.stdout, "post_cancel_scope_query_exit_code": scope.returncode,
        "complete_scope_cpu_seconds": None,
        "cost_scope": "Driver wall is measured through shutdown. Pre-cancel scope CPU/peak-memory are retained observations; full cleanup CPU was not separately captured. No local completion, speedup, or full-CPU estimate is asserted.",
        "partial_build_error_lines": error_lines, "non_interruption_error_lines": non_cancel_errors,
        "final_tracked_changes": native_receipt["final_tracked_changes"],
        "final_package_sha256": native_receipt["final_package_sha256"],
        "final_lock_sha256": native_receipt["final_lock_sha256"],
        "hosted_acceptance_source": SOURCE, "hosted_acceptance_job": 138957422954,
    }
    (output / "LOCAL_TERMINAL_CLASSIFICATION.json").write_text(json.dumps(classification, indent=2)+"\n")
    for job_id, name in ((138957422867, "PYTHON_JOB.json"), (138957422971, "CARGO_DENY_JOB.json")):
        proc = subprocess.run(["gh", "api", "--method", "GET", f"repos/TrillionniumFoundation/hepta-private-ci/actions/jobs/{job_id}"], capture_output=True, timeout=60)
        assert proc.returncode == 0
        obj = json.loads(proc.stdout)
        assert obj["head_sha"] == SOURCE and obj["conclusion"] == "success"
        (hosted / name).write_bytes(proc.stdout)
    for source, label in ((hosted, "hosted"), (native, "local_native")):
        dest = output / label
        dest.mkdir()
        for p in sorted(source.iterdir()):
            if not p.is_file() or p.is_symlink():
                continue
            before = p.stat()
            data = p.read_bytes()
            after = p.stat()
            assert (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns)
            (dest / p.name).write_bytes(data)
    (output / "COLLECT_PROGRAM.py").write_bytes(pathlib.Path(__file__).read_bytes())
    status = {
        "schema": 1, "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "source": SOURCE, "hosted_sdk": "PASS_5_SUITES_47_TESTS_EXACT_SOURCE",
        "local_native": classification["classification"],
        "parent_archive": {"name": "dependency-evidence-v1.tar.gz", "sha256": "ce8dba04e69968376d2fb8ac71881caa60cfa6b0b5f0aca0c8b681816dbc3cef", "published_commit": "2178f51af0b0af96b59a8b647672185bae46d51e"},
        "initial_failures_preserved_in_parent_archive": "Original47 tests:18pass29 environment failures; original fixture hydration timeout. No denominator is combined with the later successful replay.",
        "default_branch_or_advisory_clearance_claim": False,
    }
    (output / "STATUS.json").write_text(json.dumps(status, indent=2)+"\n")
    entries = []
    for p in sorted(output.rglob("*")):
        if p.is_file():
            data = p.read_bytes()
            entries.append({"path": p.relative_to(output).as_posix(), "bytes": len(data), "sha256": sha(data)})
    manifest = {"schema": 1, "member_count_excluding_manifest": len(entries), "members": entries}
    manifest_bytes = (json.dumps(manifest, indent=2)+"\n").encode()
    (output / "MANIFEST.json").write_bytes(manifest_bytes)
    archive = BASE / "dependency-terminal-v1.tar.gz"
    with archive.open("xb") as raw_file:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw_file, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as tar:
                for p in sorted(output.rglob("*")):
                    if not p.is_file():
                        continue
                    data = p.read_bytes()
                    info = tarfile.TarInfo(p.relative_to(output).as_posix())
                    info.size = len(data); info.mode = 0o644; info.mtime = 0
                    tar.addfile(info, io.BytesIO(data))
    compressed_bytes = archive.read_bytes()
    expected = {row["path"]: (row["bytes"], row["sha256"]) for row in entries}
    expected["MANIFEST.json"] = (len(manifest_bytes), sha(manifest_bytes))
    seen = set()
    with tarfile.open(fileobj=io.BytesIO(gzip.decompress(compressed_bytes)), mode="r:") as tar:
        for member in tar:
            assert member.isfile() and member.name in expected and member.name not in seen
            data = tar.extractfile(member).read()
            assert (len(data), sha(data)) == expected[member.name]
            seen.add(member.name)
    assert seen == set(expected)
    index = {"schema": 1, "archive_path": str(archive), "bytes": len(compressed_bytes), "sha256": sha(compressed_bytes),
             "git_blob_sha1": hashlib.sha1(b"blob "+str(len(compressed_bytes)).encode()+b"\0"+compressed_bytes).hexdigest(),
             "member_count": len(seen), "manifest_sha256": sha(manifest_bytes), "full_gzip_and_members_verified": True,
             "hosted_source": SOURCE, "hosted_sdk_job": 138957422954, "hosted_jest": acceptance["jest"],
             "local_classification": classification["classification"], "local_wall_seconds": native_receipt["wall_seconds"],
             "observed_non_interruption_build_error_lines": non_cancel_errors}
    (BASE / "DEPENDENCY_TERMINAL_ARCHIVE_V1.json").write_text(json.dumps(index, indent=2)+"\n")
    print(json.dumps(index, indent=2), flush=True)


if __name__ == "__main__":
    main()
