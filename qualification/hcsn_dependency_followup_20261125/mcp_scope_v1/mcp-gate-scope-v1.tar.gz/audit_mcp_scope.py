#!/usr/bin/env python3
"""Read-only recomputation of existing SDK MCP report scopes; no tests run."""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import zipfile


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "e4f2"
ARTIFACT = ROOT / "artifact-14989107963.zip"
ZIP_SHA = "91638585bdbaad62ad8cc903d5828cad372b926914eddc8e55a2707f3bb3af71"
MODES = ["2025-06-18", "2025-11-25", "2026-07-28"]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ckey(row):
    return tuple(row[k] for k in ("mode", "transport", "source", "scenario", "check_id"))


def rkey(row):
    return tuple(row[k] for k in ("mode", "transport", "check_id"))


def observed(report, review=False):
    statuses = collections.defaultdict(set)
    rows = []
    for case in report["cases"]:
        assert case["success"] == all(c["success"] for c in case["checks"])
        for check in case["checks"]:
            assert check["status"] in {"PASS", "FAIL", "SKIP"}
            assert check["success"] is (check["status"] != "FAIL")
            identity = {"mode": case["mode"], "transport": case["transport"]}
            if review:
                identity["check_id"] = check["name"]
                key = rkey(identity)
                assert key not in statuses
            else:
                identity.update(
                    source=check["source"],
                    scenario=check["scenario"] or "",
                    check_id=check["check_id"] or re.sub(r"#\d+$", "", check["name"]),
                )
                key = ckey(identity)
            statuses[key].add(check["status"])
            rows.append({**identity, "status": check["status"], "detail": check["detail"]})
    return statuses, rows


def compare(report, baseline, review=False):
    keyfn = rkey if review else ckey
    cand, rows = observed(report, review)
    old = collections.defaultdict(set)
    for bucket, status in (("passing", "PASS"), ("failing", "FAIL")):
        vals = [keyfn(x) for x in baseline["checks"][bucket]]
        assert len(vals) == len(set(vals))
        for k in vals:
            old[k].add(status)
    known = {k for k, s in cand.items() if "FAIL" in s and "FAIL" in old[k]}
    new = {k for k, s in cand.items() if "FAIL" in s and "FAIL" not in old[k]}
    missing = set()
    fixed = set()
    for k, s in old.items():
        cur = cand.get(k, set())
        if "PASS" in s and "PASS" not in cur:
            missing.add(k)
        elif "FAIL" in s and "FAIL" not in cur:
            if "PASS" in cur:
                fixed.add(k)
            else:
                missing.add(k)
    gate = report["regressionGate"]
    for field, got in (("knownFailures", known), ("newFailures", new),
                       ("missingChecks", missing), ("fixedChecks", fixed)):
        assert got == {keyfn(x) for x in gate[field]}, field
    assert gate["configurationErrors"] == []
    assert gate["requiredModes"] == MODES
    assert gate["success"] is True and not new and not missing
    actual_modes = {x["mode"] for x in report["cases"]}
    assert actual_modes == set(MODES)
    if review:
        assert baseline["requiredModes"] == report["modes"] == MODES
        assert baseline["reviewer"] == report["reviewer"]
        assert {(x["mode"], x["transport"]) for x in baseline["requiredCases"]} == {
            (x["mode"], x["transport"]) for x in report["cases"]}
    else:
        for field in ("automaticAuthRequired", "modernFeatureEnablement"):
            assert baseline[field] == report[field]
        for field in ("repository", "gitRef", "authenticationIncluded", "scenarios"):
            assert baseline["officialConformance"][field] == report["officialConformance"][field]
        assert {(x["mode"], x["transport"]) for x in report["cases"]} == {
            (m, t) for m in MODES for t in ("stdio", "official-http")}
    counts = collections.Counter(x["status"] for x in rows)
    cases_passed = sum(x["success"] for x in report["cases"])
    mode_counts = []
    for mode in MODES:
        counts_mode = collections.Counter(x["status"] for x in rows if x["mode"] == mode)
        mode_counts.append({"mode": mode, **dict(counts_mode)})
        if not review:
            original = next(x["checks"] for x in report["modeSummaries"] if x["mode"] == mode)
            assert original["passed"] == counts_mode["PASS"]
            assert original["total"] == counts_mode["PASS"] + counts_mode["FAIL"]
    if review:
        assert report["summary"] == {
            "passed": counts["PASS"], "failed": counts["FAIL"], "total": len(rows),
            "casesPassed": cases_passed, "casesTotal": len(report["cases"])}
    else:
        assert report["summary"] == {
            "passed": cases_passed, "failed": len(report["cases"]) - cases_passed,
            "total": len(report["cases"])}
    assert report["success"] is False
    return {
        "original_overall_success": report["success"],
        "original_regression_gate_success": gate["success"],
        "cases_passed": cases_passed, "cases_total": len(report["cases"]),
        "row_status_counts": dict(counts), "raw_rows": len(rows),
        "applicable_rows_excluding_skip": counts["PASS"] + counts["FAIL"],
        "mode_row_status_counts": mode_counts,
        "baseline_identity_counts": {k: len(v) for k, v in baseline["checks"].items()},
        "candidate_distinct_identities": len(cand),
        "recomputed_known_failures": len(known), "recomputed_new_failures": len(new),
        "recomputed_missing_checks": len(missing), "recomputed_fixed_checks": len(fixed),
        "all_gate_identity_sets_match_original": True,
        "known_failure_identities": gate["knownFailures"],
        "fixed_identity_set": gate["fixedChecks"],
        "failed_rows": [x for x in rows if x["status"] == "FAIL"],
        "skipped_rows": [x for x in rows if x["status"] == "SKIP"],
        "count_scope": "Rows include repeated protocol observations; stable identities collapse retries. Neither count is an independent Jest-test denominator.",
    }


def main():
    source_rows = json.loads((ROOT / "GITHUB_READ_RECEIPTS.json").read_text())
    for row in source_rows:
        data = (SOURCE / row["path"]).read_bytes()
        assert len(data) == row["bytes"] and digest(data) == row["sha256"]
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert blob == row["candidate_git_blob"] == row["parent_git_blob"]
    archive = ARTIFACT.read_bytes()
    assert digest(archive) == ZIP_SHA
    reports = {}
    with zipfile.ZipFile(ARTIFACT) as z:
        assert z.testzip() is None
        for member, baseline_file, review in (
            ("codex-mcp-conformance-11786.json", "regression-baseline-v1.json", False),
            ("codex-mcp-review-11786.json", "review-regression-baseline-v1.json", True),
        ):
            data = z.read(member)
            report = json.loads(data)
            baseline = json.loads((SOURCE / "scripts/mcp_conformance" / baseline_file).read_text())
            reports[member] = {
                "bytes": len(data), "sha256": digest(data),
                **compare(report, baseline, review),
            }
    out = {
        "schema": 1, "audited_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "source_commit": "e4f2cfa6f4f6bbc356ae20200eda3cd78ab92dd1",
        "original_parent": "356877c2d1d5225e97e0417683a5e5a7f8e2c1fc",
        "hosted_run": 45540235075, "sdk_job": 138957422954,
        "artifact_id": 14989107963, "artifact_sha256": ZIP_SHA,
        "decision": "PASS_EXISTING_REGRESSION_CONTRACT_WITH_RETAINED_KNOWN_FAILURES",
        "sdk_jest": {"suites_passed": 5, "suites_total": 5, "tests_passed": 47, "tests_total": 47},
        "original_contract": "Two original Jest MCP tests run the committed Python harness with --baseline-report and fail on a nonzero exit. The harness exit follows regressionGate.success when a baseline is supplied; overall success remains false when acknowledged checks fail.",
        "contract_and_baselines_unchanged_from_parent": True,
        "new_exceptions_or_waivers_added": False,
        "runtime_or_model_tests_executed_by_this_audit": 0,
        "sources": source_rows, "reports": reports,
        "interpretation": [
            "47/47 Jest means the existing exact-source SDK contract passed, not zero failing MCP scenarios.",
            "Conformance has1119 PASS,28 FAIL,7 SKIP rows;1147 applicable rows,4/6 transport cases. All28 failures match the committed baseline; no new/missing checks.",
            "Reviewer has162 PASS,24 FAIL rows and15/21 cases. The baseline had30 failing identities;6 now pass,24 remain acknowledged failures.",
            "Conformance failures cover intermediate default elicitation values and intermediate/modern OAuth metadata-var3, scope challenges/step-up, preregistration; modern also scope union.",
            "Reviewer failures are4 catalog-over-limit assertions in each of3 modes by2 transports: startup wrongly ready, missing expected limit error, server-info mismatch, and1025 discovered tools where0 were required.",
            "The6 fixed reviewer identities are large-integer elicitation schema/round-trip and MRTR64-input bounds on modern HTTP and stdio; this comparison is not causal attribution to the npm-only patch.",
            "Shipping conformance checks pass; shipping catalog reviewer failures remain. No complete MCP conformance, default-branch or whole-repository pass is asserted.",
        ],
    }
    path = ROOT / "MCP_REGRESSION_SCOPE_REVIEW.json"
    if path.exists():
        old = json.loads(path.read_text())
        old.pop("audited_utc")
        check = dict(out); check.pop("audited_utc")
        assert old == check
    else:
        path.write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"path": str(path), "bytes": path.stat().st_size,
                      "sha256": digest(path.read_bytes()),
                      "summaries": {k: {j: v[j] for j in ("row_status_counts", "cases_passed", "cases_total", "recomputed_known_failures", "recomputed_fixed_checks")} for k, v in reports.items()}}, ensure_ascii=False))


if __name__ == "__main__":
    main()
