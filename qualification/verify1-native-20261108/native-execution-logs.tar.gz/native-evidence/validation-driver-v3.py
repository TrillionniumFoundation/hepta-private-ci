"""Bounded native VERIFY-1 validation; preserve every command and failed log."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/verification-cell-verify1-20261108-771b')
SOURCE = ROOT / 'native-integration'
EVIDENCE = ROOT / 'native-evidence'
ENV = os.environ.copy()
ENV.update(PATH=str(ROOT / 'native-tools/bin') + ':/home/qian-qi/.cargo/bin:' + ENV.get('PATH', ''),
           CARGO_TARGET_DIR=str(ROOT / 'native-target'), CARGO_BUILD_JOBS='2',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           CARGO_INCREMENTAL='0', PYTHONDONTWRITEBYTECODE='1')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def run(label, argv, cwd=SOURCE / 'codex-rs'):
    record_path = EVIDENCE / (label + '.json')
    if record_path.exists():
        raise RuntimeError('command label already exists: ' + label)
    record = {'label': label, 'argv': argv, 'cwd': str(cwd), 'status': 'RUNNING'}
    record_path.write_text(json.dumps(record, sort_keys=True) + '\n')
    started = time.perf_counter_ns()
    with (EVIDENCE / (label + '.stdout.log')).open('xb') as out, (EVIDENCE / (label + '.stderr.log')).open('xb') as err:
        result = subprocess.run(argv, cwd=cwd, env=ENV, stdout=out, stderr=err)
    record.update(status='PASSED' if result.returncode == 0 else 'FAILED', exit_code=result.returncode,
                  wall_ns=time.perf_counter_ns() - started)
    for stream in ('stdout', 'stderr'):
        raw = (EVIDENCE / (label + '.' + stream + '.log')).read_bytes()
        record[stream + '_sha256'] = digest(raw)
        record[stream + '_bytes'] = len(raw)
    record_path.write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
    print(json.dumps(record, sort_keys=True), flush=True)
    if result.returncode:
        raise RuntimeError(label + ' failed; original logs retained')


def main():
    EVIDENCE.mkdir(exist_ok=True)
    cgroup = next(line.split(':', 2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
    control = Path('/sys/fs/cgroup') / cgroup.lstrip('/')
    cpu = (control / 'cpu.max').read_text().strip().split()
    memory = (control / 'memory.max').read_text().strip()
    limits = {'cgroup': cgroup, 'cpu_max': cpu, 'memory_max': memory, 'nice': os.getpriority(os.PRIO_PROCESS, 0)}
    (EVIDENCE / 'build-resource-limits-v3.json').write_text(json.dumps(limits, sort_keys=True, indent=2) + '\n')
    print(json.dumps(limits), flush=True)
    if cpu[0] == 'max' or int(cpu[0]) > 2 * int(cpu[1]) or memory == 'max' or int(memory) > 4294967296 or limits['nice'] < 10:
        raise RuntimeError('requested aggregate native resource bounds are not observed')
    paths = json.loads((EVIDENCE / 'source-before-validation-v3.json').read_text())
    before = {path: digest((SOURCE / path).read_bytes()) for path in paths}
    if before != paths:
        raise RuntimeError('source differs from transferred manifest')
    (EVIDENCE / 'tested-source-sha256-v3.json').write_text(json.dumps(before, sort_keys=True, indent=2) + '\n')
    run('evidence-tests-v3', ['/home/qian-qi/.cargo/bin/just', 'test', '--locked', '-p', 'codex-hepta-evidence', '--test-threads', '2'])
    run('fixture-cli-build-v1', ['/home/qian-qi/.cargo/bin/cargo', 'build', '--locked', '-p', 'codex-hepta-evidence', '--example', 'verify1_fixture_check'])
    run('cross-language-v1', ['/usr/bin/python3', '-B', str(EVIDENCE / 'cross-language-driver.py')])
    run('agentd-tests-v1', ['/home/qian-qi/.cargo/bin/just', 'test', '--locked', '-p', 'codex-hepta-agentd', '--test', 'kernel_evidence_product', '--test', 'verify1_kernel_evidence_product', '--test-threads', '2'])
    after = {path: digest((SOURCE / path).read_bytes()) for path in paths}
    if after != before:
        raise RuntimeError('source changed during native validation')
    print(json.dumps({'native_stage_tests': 'PASSED', 'source_unchanged': True, 'formatting': 'NOT_YET_RUN'}), flush=True)


if __name__ == '__main__':
    main()
