"""Check actual frozen Python effects and native receipt compatibility, no model inference."""
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys

ROOT = Path('/home/qian-qi/work/verification-cell-verify1-20261108-771b')
FROZEN = ROOT / 'source'
OUT = ROOT / 'native-evidence/cross-language-v1'
CLI = ROOT / 'native-target/debug/examples/verify1_fixture_check'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    sys.dont_write_bytecode = True
    pinned = json.loads((ROOT / 'evidence/native-validation.json').read_text())['formatted_source_sha256']
    assert all(digest((FROZEN / path).read_bytes()) == expected for path, expected in pinned.items())
    sys.path.insert(0, str(FROZEN))
    from experiments.verification_cell_verify1 import contracts as c
    from experiments.verification_cell_verify1 import kernel_payload
    from experiments.verification_cell_verify1 import runtime
    OUT.mkdir(exist_ok=False)
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(FROZEN))
    expected = {'clean': 'proved', 'stale_read': 'refuted', 'missing_receipt': 'unknown',
                'semantic_error': 'refuted', 'partial_success': 'refuted', 'common_misjudgment': 'refuted'}
    rows = []
    for fault, verdict in expected.items():
        path = OUT / (fault + '.sqlite')
        goal = {'task_id': 'task:crosslang:猴🧪\x7f', 'left': -7, 'right': 9}
        runtime.initialize(path, goal)
        worker_rows = []
        for tick in (1, 2, 3):
            worker = subprocess.run([sys.executable, '-B', '-m', 'experiments.verification_cell_verify1.runtime',
                '--database', str(path), '--goal', runtime.canonical(goal), '--fault', fault, '--tick', str(tick)],
                cwd=FROZEN, env=env, text=True, capture_output=True)
            worker_rows.append({'tick': tick, 'exit_code': worker.returncode, 'stdout': worker.stdout, 'stderr': worker.stderr})
            assert worker.returncode == 0, worker.stderr
        scope = c.Scope(goal['task_id'], 'attempt:native-crosslang', runtime.sha(goal), 3,
                        'sqlite_two_field_engineering_fixture_v1', 'terminal_goal_value_error', 4, 4)
        before = runtime.outcome(path, goal)
        result = subprocess.run([str(CLI), str(path), runtime.canonical(goal), c.canonical_json(scope)],
                                env=env, text=True, capture_output=True)
        record = {'fault': fault, 'worker_operations': worker_rows, 'exit_code': result.returncode,
                  'stdout': result.stdout, 'stderr': result.stderr, 'precheck_value_error': before}
        (OUT / (fault + '.json')).write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
        assert result.returncode == 0, result.stderr
        payload = json.loads(result.stdout)
        claimed = c.parse_record(payload['record_json'])
        parsed = kernel_payload.validate_payload_identity(payload, expected_record_sha256=c.digest(claimed),
                                                          expected_type=c.VerificationReceipt)
        assert parsed.verdict == verdict
        assert parsed.scope == scope
        assert runtime.outcome(path, goal) == before
        with sqlite3.connect(path) as db:
            assert db.execute('SELECT count(*) FROM accepted').fetchone() == (0,)
            assert db.execute('SELECT count(*) FROM intents').fetchone() == (3,)
        row = {'fault': fault, 'native_verdict': parsed.verdict, 'value_error': before,
               'record_sha256': payload['record_sha256'], 'accepted_rows': 0, 'physical_effect_operations': 3}
        if fault == 'missing_receipt':
            reconciled = runtime.reconcile(path, goal, 4)
            assert reconciled['effects_replayed'] == 0
            recovered = subprocess.run([str(CLI), str(path), runtime.canonical(goal), c.canonical_json(scope)],
                                       env=env, text=True, capture_output=True)
            (OUT / 'missing_receipt_reconciled.json').write_text(json.dumps({'exit_code': recovered.returncode,
                'stdout': recovered.stdout, 'stderr': recovered.stderr, 'controller_reconciliation': reconciled}, sort_keys=True, indent=2) + '\n')
            assert recovered.returncode == 0
            recovered_payload = json.loads(recovered.stdout)
            recovered_record = c.parse_record(recovered_payload['record_json'])
            assert kernel_payload.validate_payload_identity(recovered_payload, expected_record_sha256=c.digest(recovered_record),
                expected_type=c.VerificationReceipt).verdict == 'proved'
            row['after_owner_readback'] = 'proved'
        rows.append(row)
    assert all(digest((FROZEN / path).read_bytes()) == expected for path, expected in pinned.items())
    report = {'status': 'PASSED', 'scope': 'frozen Python worker effects to native read-only fixture checker',
              'frozen_source_unchanged': True, 'model_inference': False, 'signature_authentication': False,
              'production_acceptance': False, 'cases': rows}
    (OUT / 'result.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    print(json.dumps(report, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
