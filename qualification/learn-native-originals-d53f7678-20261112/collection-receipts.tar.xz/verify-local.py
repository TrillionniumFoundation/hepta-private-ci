from pathlib import Path
import base64
import datetime
import hashlib
import io
import json
import os
import tarfile
import xml.etree.ElementTree as ET

OUT = Path("/workspace/scratch/ff41dfc0f7bf/tooling/validation/root-native-originals-d53f7678-v1")
OBS = Path("/workspace/scratch/ff41dfc0f7bf/tooling/validation/root-d53f7678-observed-progress-v1")
HEAD = "d53f7678860d6f2ab6b3a6143ea1ceb37bdb2c9f"
TREE = "abc89d1ce05ba27f3a56a7601ccfd22de3051b47"
JUNIT_SHA = "c80e7176f94b043d2b2592042828feb7d22eabd4c0460603d5993824619db37d"

def sha(b):
    return hashlib.sha256(b).hexdigest()

def blob(b):
    return hashlib.sha1(b"blob " + str(len(b)).encode() + b"\0" + b).hexdigest()

def save_once(path, data):
    if path.exists():
        assert path.read_bytes() == data, str(path)
        return
    with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())

expected = json.loads((OUT / "collector-result.original.json").read_bytes())
chunks = []
versions = set()
chunk_proofs = []
for i in range((expected["bytes"] + 16383) // 16384):
    response = json.loads((OUT / f"chunk{i:03d}.response.json").read_bytes())
    raw = (OUT / f"chunk{i:03d}.bin").read_bytes()
    assert raw == base64.b64decode(response["data_base64"], validate=True)
    assert response["path"] == expected["archive"]
    assert response["offset"] == i * 16384
    assert response["next_offset"] == min((i + 1) * 16384, expected["bytes"])
    assert response["size"] == expected["bytes"]
    assert response["eof"] == (response["next_offset"] == expected["bytes"])
    assert len(raw) == response["next_offset"] - response["offset"]
    assert sha(raw) == response["chunk_sha256"]
    versions.add(response["version"])
    chunks.append(raw)
    chunk_proofs.append({k: response[k] for k in ["offset", "next_offset", "chunk_sha256", "version", "eof"]})
assert len(versions) == 1
archive = b"".join(chunks)
assert len(archive) == expected["bytes"]
assert sha(archive) == expected["sha256"] and blob(archive) == expected["git_blob"]
save_once(OUT / "originals.tar.xz", archive)

with tarfile.open(fileobj=io.BytesIO(archive), mode="r:xz") as tar:
    members = tar.getmembers()
    names = [m.name for m in members]
    assert len(names) == len(set(names))
    assert all(m.isfile() and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in members)
    manifest_raw = tar.extractfile("manifest.json").read()
    assert sha(manifest_raw) == expected["manifest_sha256"]
    manifest = json.loads(manifest_raw)
    assert manifest["file_count"] == expected["file_count"] == 41
    assert manifest["input_bytes"] == expected["input_bytes"]
    assert manifest["collector_uid"] == 0
    assert set(names) == {"manifest.json"} | {r["path"] for r in manifest["files"]}
    verified = []
    data = {}
    for row in manifest["files"]:
        raw = tar.extractfile(row["path"]).read()
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"] and blob(raw) == row["git_blob"], row["path"]
        verified.append({"path": row["path"], "bytes": len(raw), "sha256": sha(raw), "git_blob": blob(raw)})
        data[row["path"]] = raw
    assert sum(x["bytes"] for x in verified) == expected["input_bytes"]

save_once(OUT / "manifest.json", manifest_raw)
native_prefix = "validation/root-d53f7678-native-tests-v1/"
fix_prefix = "validation/root-d53f7678-scoped-fix-v1/"
native_raw = data[native_prefix + "result.json"]
fix_raw = data[fix_prefix + "result.json"]
native = json.loads(native_raw)
fix = json.loads(fix_raw)
assert native["head"] == HEAD and native["tree"] == TREE
assert fix["expected_head"] == HEAD and fix["expected_tree"] == TREE
for result in [native, fix]:
    assert result["status"] == "completed" and result["source_unchanged"] is True
    assert result["before"]["head"] == result["after"]["head"] == HEAD
    assert result["before"]["tree"] == result["after"]["tree"] == TREE
    assert result["before"]["status"] == result["after"]["status"] == ""
    assert result["before"]["tracked_sha256"] == result["after"]["tracked_sha256"]
assert fix["exit_code"] == 0
assert data[fix_prefix + "fix.patch"] == b""
junit = data[native_prefix + "ordinary-a.xml"]
assert len(junit) == 3435 and sha(junit) == JUNIT_SHA
xml = ET.fromstring(junit)
cases = list(xml.iter("testcase"))
counts = {"total": len(cases), "passed": 0, "failed": 0, "errors": 0, "skipped": 0}
for c in cases:
    if c.find("failure") is not None:
        counts["failed"] += 1
    elif c.find("error") is not None:
        counts["errors"] += 1
    elif c.find("skipped") is not None:
        counts["skipped"] += 1
    else:
        counts["passed"] += 1
assert counts == {"total": 1, "passed": 0, "failed": 1, "errors": 0, "skipped": 0}
assert native["ordinary-a"]["collection"]["total_testcases"] == 1
children = {k: v for k, v in data.items() if k.startswith("original-child-logs/")}
assert any("/ordinary-q24-original-process-yi14k1/" in k for k in children)
assert any("/ordinary-q24-original-process-AnQaza/" in k for k in children)
OBS.mkdir(exist_ok=True)
save_once(OBS / "ordinary-a-original.xml", junit)
save_once(OBS / "native-result-original.json", native_raw)
save_once(OBS / "scoped-fix-result-original.json", fix_raw)
save_once(OUT / "ordinary-a-original.xml", junit)
for name, raw in children.items():
    save_once(OUT / name.replace("/", "__"), raw)
proof = {
    "schema": 1,
    "verified_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_head": HEAD, "source_tree": TREE,
    "archive": {k: expected[k] for k in ["bytes", "sha256", "git_blob", "manifest_sha256", "file_count", "input_bytes"]},
    "all_member_bytes_verified": True, "archive_roundtrip_verified": True,
    "chunk_version": next(iter(versions)), "chunks": chunk_proofs,
    "original_source_unchanged": True,
    "scoped_fix": {k: fix.get(k) for k in ["status", "exit_code", "source_unchanged", "started", "finished", "elapsed"]},
    "native": {k: native.get(k) for k in ["status", "source_unchanged", "started", "finished"]},
    "ordinary_a": {"counts": counts, "junit_bytes": len(junit), "junit_sha256": sha(junit), "cases": [dict(c.attrib) for c in cases]},
    "child_logs": [{"path": k, "bytes": len(v), "sha256": sha(v)} for k, v in children.items()],
    "verified_members": verified,
    "scope": "Original d53 scoped fix and one ordinary A failure only; collection does not execute Rust/tests or change source.",
    "cause_limit": "Phase logs establish progress through cell-before; no Cell return is recorded. The daemon response-length poll reports its deadline. Root cleanup signal 9 does not establish the underlying Root or Cell cause."
}
save_once(OUT / "verification.json", (json.dumps(proof, indent=2) + "\n").encode())
print(json.dumps({k: v for k, v in proof.items() if k not in ["verified_members", "chunks"]}))
print(json.dumps({"original_child_text": {k: v.decode("utf-8") for k, v in children.items()}}))
