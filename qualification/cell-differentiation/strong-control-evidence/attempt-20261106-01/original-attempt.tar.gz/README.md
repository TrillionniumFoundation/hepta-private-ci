# P3 matched-control implementation and first execution

Base files were read without changing the existing checkout at commit
`9bbf4bb4d1b5466f62d75d6b70dad4d26ec75d55` (the Cell RSI followthrough branch).
Only three new Python files should be copied into `qualification/cell-differentiation/`:
`strong_control.py`, `strong_control_audit.py`, `test_strong_control.py`.
The six existing research source files remain byte-identical to the base commit.

## What is now executable

The new entrypoint freezes the source hashes and protocol before execution. It compares
three independent numerical fits: demand-triggered split, fixed experts with the same
selective update/frozen-parent policy, and one fixed 12-coordinate linear tensor with
task-gated feature blocks and no topology change. All arms retain 12 FP64 coefficients,
update the same six new-task coordinates, receive the same parent bytes, diagnostic
information and budget. Both helpful and redundant scenarios and five new seeds are
predeclared. The old `0.0005` gain and `0.01` retention thresholds remain unchanged.

This is a synthetic reference experiment with supplied task identity. It does not test
an arbitrary neural network, deployed Cell worker, descendant improver or service.
The unsplit control is a single masked linear tensor; its dense feature materialization
and inference arithmetic are charged explicitly. Parameter bytes are measured; FLOPs
are algorithmic estimates; energy, GPU, network and billing costs are unmeasured.
Shared pretraining and diagnosis are physically executed once per trial and included
once in every arm comparison. Summing comparison ledgers would double-count them.

Commands for a separately authorized new candidate execution are:

```bash
python3 -m unittest -v test_strong_control.py
python3 strong_control.py prepare --protocol /new/path/PROTOCOL.json
python3 strong_control.py run --protocol /new/path/PROTOCOL.json --output /new/path/attempt
```

The output directory must not exist. There is no automatic resume or replay. Failed
trials remain in the complete planned denominator with unknown costs represented by
null. The repaired implementation saves the original numerical payload before invoking
the readback checker, including when that checker fails.

## Actual first attempt, preserved

`actual-01/` was executed with the source snapshot in its `EXECUTED_SOURCE/` directory,
not the later repaired source. Its protocol digest is
`ee74cf2ec61b97636b0eabadf1066161562b88de38293fd0d3bdb0e1153f41c3`.
The command returned exit 0 because scientific HOLD is a valid report, not a process
execution failure. The result contains 10 planned trials, six completed/readback-valid
trials, four failures, and 3,456 completed test predictions out of 5,760 planned.
All ten trial positions remain present and the scientific decision is **HOLD**.

Across the six retained valid trials the three models have identical parameter bytes.
Fixed-selective MSE gain is exactly zero. Unsplit-selective paired gains have magnitude
at most `2.6020852139652106e-18`; these are far below the frozen `0.0005` threshold.
These observations do not establish a benefit from structural differentiation.

The original checker used scalar `**2` while the declared numerical kernel computes a
vector square. An independent arithmetic reproduction found a one-ULP discrepancy:
`a=0.11208460483823379`, `b=-0.05149136280119249` yielded scalar squared residual
`0.026757097189174635` versus vector `0.02675709718917463`. The repaired checker uses
the declared vector kernel. The first driver also discarded the full completed result
when audit raised; this was repaired by retaining RAW records before audit. Both are
engineering fixes, not changes to learning, gain thresholds or sample selection.

The four failed original payloads are unavailable because of the first driver's bug;
their exact failure cause cannot be independently attributed from the retained traceback
alone. They remain failed. They were not retrained or silently restored. The read-only
`READBACK.json` verifies the six retained original payloads using the repaired checker;
it performs zero new model training or trial executions. The final implementation's
six behavioral tests pass (`tests-final.log`). No model experiment ran on that final
source, so the original attempt must not be cited as its successful qualification.

## P4 and P5

The latest existing followthrough records still do not supply a descendant improver
comparison with common initial system, hidden tasks and complete budget. The synthetic
P3 fits do not fill that P4 gap. Likewise existing resident/HCSN native tests establish
engineering behavior, not a same-candidate long-running quality/p99/effective-throughput/
RAM/VRAM/recovery/state-growth/cost service curve. This task did not start a production
service or modify the existing desktop HCSN CUDA campaign.

`HANDOFF.json` binds final source/test hashes and first-attempt/readback identities.
Prior archives, initial failed attempts and no-authority statements remain unchanged.
