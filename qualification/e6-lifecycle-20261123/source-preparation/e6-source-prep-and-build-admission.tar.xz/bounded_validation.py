"""Validate the exact cold-publication source in its existing isolated Cargo caches."""
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

BASE = Path('/home/qq/work/hepta-e16-ac5459-20261121')
PREP = BASE / 'e6-cold01-first-publication-fix-bf6d-v2-offline'
SRC = PREP / 'source'
TARGET = PREP / 'target'
CACHE = PREP / 'cargo-home'
OWNER = BASE / 'e6-cold01-bf6d-build-boundaries-20261123'
DONOR = BASE / 'e6-lifecycle-qualification-v1'
COMMIT = 'bf6d51904c8bcda5d50f3782c85ece84cb73a78f'
PARENT = '61503a7d3bc87a5584cd2f20b8b17ea3838fdcfd'
TREE = '03f7135e2c060422f9dbd51bb38c5701cfaefe24'
REMAIN = 647.3566216025501
USED = 1152.6433783974499
CASES = ['cell_generation_current::tests::original_observer::feature::' + name for name in (
    'original_feature_boundary_keeps_genesis_digest_across_actual_drain',
    'original_feature_boundary_refuses_revision_zero_with_resume_or_admission')]
PINS = {'justfile':'74f869224eba12fc4212b043428e7f5b35b551d26f5b06161c25d8aca525f124',
        'scripts/hepta_ci_exec.py':'9b2bfaa563fff018df4e4f10944f6fbc63d307fa4c4a7e167c392288edb5a5c1',
        'scripts/hepta_ci_junit.py':'cdb325f4a9266bc554fa266ee6a42dc1e1390b6b45d4bac47fa50aa9255cdeec',
        'scripts/run-nextest.py':'45c4e35d1ff24840d9e1e05331af0b89475bfe1aec3231afc56fecb8cea66127',
        'scripts/hepta_cell_test_helpers.py':'43802e867f91225efcef9ea4763567c0aeabd5a07b6c03000eb033501b4eb9ae',
        'codex-rs/hepta-agentd/src/ordinary_q24_cold_publication_data_tests.rs':'0985f7296bd6027f6e213a0582cfe77c5263a969a11cf8a4eacb0006473ae403',
        'codex-rs/hepta-agentd/src/ordinary_q24_post_a_completed_data_tests.rs':'b711d8864ce05ce580431f410c91ee05648f1c3b7c4b95e112c4d1ccfebb35fa'}
TOOLS = {'cargo':'f30f9fd1b1d0b8fd10dc33219eb4cd4bec3543f40e434ac71f5a03fd0359063f',
         'just':'50cd9b4a47c26a2570a0cca1bf86a106290b1cd35b131630696f63b9fbd1400d',
         'cargo-nextest':'234184741162d97741c89eca1df6368a45cc4bbade54e8ff2ef64fc7104ecaac',
         'rustc':'ba4b837efb6612dfa8d941c5a72b8a50d1d03a0f36216743b173949aa8d9eb75'}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    assert path.resolve() == path
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode)
    return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]


def protected():
    rows = []
    for expected in prepared['protected_before']:
        name = expected['path']; pre = identity(name); digest = sha(name)
        assert pre == identity(name) == expected['identity'] and digest == expected['sha256']
        rows.append({'path':name,'identity':pre,'sha256':digest})
    return rows


def tool_ids():
    ids = {}
    for name, expected in TOOLS.items():
        path = Path(shutil.which(name)).resolve(); digest = sha(path)
        assert digest == expected, (name,str(path),digest)
        ids[name] = {'path':str(path),'sha256':digest}
    return ids


def source_state():
    def git(*args):
        return subprocess.check_output(['git','--no-optional-locks',*args],cwd=SRC,timeout=60).decode().strip()
    view = {'commit':git('rev-parse','HEAD'),'parent':git('rev-parse','HEAD^'),'tree':git('rev-parse','HEAD^{tree}'),
            'status':git('status','--porcelain=v1','--untracked-files=all')}
    assert view == {'commit':COMMIT,'parent':PARENT,'tree':TREE,'status':''},view
    for file, digest in PINS.items(): assert sha(SRC / file) == digest,file
    return view


def save(name, data):
    with (OWNER/name).open('x') as out:
        json.dump(data,out,indent=2,sort_keys=True);out.write('\n');out.flush();os.fsync(out.fileno())


def run(label, argv, *, charged=False, cwd=None, limit=60):
    global charged_seconds
    available = min(limit, REMAIN-charged_seconds) if charged else limit
    assert available > 0, 'original compile budget exhausted'
    paths = [OWNER/(label+suffix) for suffix in ('.stdout','.stderr')]
    with paths[0].open('xb') as out, paths[1].open('xb') as err:
        child = None; code = None; error = None; started=time.monotonic()
        try:
            child=subprocess.Popen(argv,cwd=cwd or SRC/'codex-rs',stdout=out,stderr=err,stdin=subprocess.DEVNULL,start_new_session=True)
            code=child.wait(timeout=available)
        except BaseException as exc:
            error=repr(exc)
            if child and child.poll() is None:
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                code=child.wait(timeout=10)
        finally:
            elapsed=time.monotonic()-started
            if charged:charged_seconds+=elapsed
            for stream in [out,err]: stream.flush();os.fsync(stream.fileno())
            row={'label':label,'argv':argv,'limit_seconds':available,'wall_seconds':elapsed,'charged':charged,'exit_code':code,'error':error}
            result['commands'].append(row);save(label+'.json',row)
    if code!=0 or error:raise RuntimeError(f'{label}: {error or code}; see original stdout/stderr')
    return paths[0]


os.umask(0o077)
assert os.geteuid()==os.getuid()==1000
OWNER.mkdir(mode=0o700,exist_ok=False)
started=time.monotonic();charged_seconds=0.0;fds=[]
result={'source':COMMIT,'parent':PARENT,'tree':TREE,'commands':[],'automatic_retry':False,'successful':False,
        'compile_remaining_before':REMAIN,'compile_used_before':USED,'lint_seconds_new':0,'cold_calls':0,'boundary_calls':0}
try:
    for path in [DONOR/'build-v1/owner.lock',BASE/'e6-native-successor-v2/native-component-owner.lock',DONOR/'target/.hepta-root-native-owner.lock']:
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);fds.append(fd);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    fd=os.open(PREP/'BUILD_TEST_OWNER.lock',os.O_CREAT|os.O_EXCL|os.O_RDWR|os.O_NOFOLLOW,0o600);fds.append(fd);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not (BASE/'e6-cold01-bf6d-build-boundaries-v1').exists(),'previous build owner exists'
    receipt=PREP/'RESULT.json';assert sha(receipt)=='6d611cacc4f8c09702ccebf828530d1611c53b39d465ba90adac0219f15dcb92'
    prepared=json.loads(receipt.read_bytes());assert prepared['successful'] and prepared['new_source_clean_exact_commit'] and prepared['protected_before']==prepared['protected_after']
    assert prepared['source_commit']==COMMIT and prepared['compile_budget_before_and_after']['remaining_seconds']==REMAIN
    for path in [SRC,CACHE,TARGET]:assert path.is_dir() and path.resolve()==path and path.parent==PREP
    temp=OWNER/'tmp';temp.mkdir(mode=0o700);os.chdir(SRC)
    inherited={k:os.environ[k] for k in ('HOME','USER','LOGNAME') if k in os.environ}
    os.environ.clear();os.environ.update(inherited)
    os.environ.update({'TMPDIR':str(temp),'CARGO_HOME':str(CACHE),'CARGO_TARGET_DIR':str(TARGET),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_NET_OFFLINE':'true',
        'SOURCE_SHA':COMMIT,'TESTED_SHA':COMMIT,'HEPTA_CI_LANE':'source-head','PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0','GIT_TERMINAL_PROMPT':'0',
        'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','RUSTUP_HOME':'/home/qq/.rustup','RUSTUP_TOOLCHAIN':'1.96.0','LIBCLANG_PATH':'/home/qq/hepta-learn-ff41-tools/lib',
        'BINDGEN_EXTRA_CLANG_ARGS':'-isystem /usr/lib/gcc/x86_64-linux-gnu/15/include','PATH':str(DONOR/'tooling/bin')+':/home/qq/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qq/.cargo/bin:/home/qq/hepta-learn-ff41-tools/bin:/home/qq/hepta-learn-ff41-tools/python/bin:/usr/local/bin:/usr/bin:/bin'})
    result['protected_before']=protected();result['tools_before']=tool_ids();result['source_before']=source_state()
    run('format',['just','fmt','--base',PARENT]);assert source_state()==result['source_before']
    meta=json.loads(run('metadata',['cargo','metadata','--locked','--offline','--format-version=1']).read_bytes())
    assert Path(meta['workspace_root'])==SRC/'codex-rs' and Path(meta['target_directory'])==TARGET
    for package in meta['packages']:
        manifest=Path(package['manifest_path']).resolve()
        assert manifest.is_relative_to(SRC) or manifest.is_relative_to(CACHE),str(manifest)
    lib=run('library',['cargo','nextest','list','--locked','--offline','-p','codex-hepta-agentd','-p','codex-hepta-contracts','-p','codex-hepta-neuron','--lib','--list-type','binaries-only','--message-format','json'],charged=True,limit=REMAIN)
    bins=json.loads(lib.read_bytes());assert Path(bins['rust-build-meta']['target-directory'])==TARGET
    assert set(bins['rust-binaries'])=={'codex-hepta-agentd','codex-hepta-contracts','codex-hepta-neuron'}
    result['test_binaries']={}
    for key,item in bins['rust-binaries'].items():
        path=Path(item['binary-path']);assert path.resolve().is_relative_to(TARGET);result['test_binaries'][key]={'path':str(path),'sha256':sha(path)}
    prod=run('products',['cargo','build','--locked','--offline','-p','codex-hepta-agentd','--bin','codex-hepta-agentd','--bin','hepta-authority-host','--message-format=json-render-diagnostics'],charged=True,limit=REMAIN)
    products={}
    for line in prod.read_bytes().splitlines():
        item=json.loads(line);name=item.get('target',{}).get('name')
        if item.get('reason')=='compiler-artifact' and name in ('codex-hepta-agentd','hepta-authority-host') and item.get('executable'):
            path=Path(item['executable']);assert path.resolve().is_relative_to(TARGET) and not item['profile']['test'];products[name]={'path':str(path),'sha256':sha(path)}
    assert len(products)==2;result['products']=products
    helper=['python3','scripts/hepta_cell_test_helpers.py','--package','codex-hepta-infer-worker-host','--output-dir',str(OWNER/'helpers')]
    run('helper',helper,cwd=SRC,charged=True,limit=REMAIN);run('helper-verify',helper+['--verify-only'],cwd=SRC,charged=True,limit=REMAIN)
    sys.path.insert(0,str(SRC/'scripts'))
    import hepta_ci_exec,hepta_ci_junit
    report_paths=[TARGET/'nextest/local/junit.xml',SRC/'codex-rs/target/nextest/local/junit.xml']
    for idx,path in enumerate(report_paths):
        if path.exists():assert path.resolve()==path and path.is_file();path.rename(OWNER/f'prior-{idx}-junit.xml')
    expression=' or '.join('test(='+name+')' for name in CASES)
    args=['just','test','--locked','--offline','-p','codex-hepta-neuron','--lib','--test-threads','1','-E',expression,'--retries','0','--success-output','final','--failure-output','final','--no-tests','fail']
    available=REMAIN-charged_seconds;assert available>0;begin=time.monotonic();result['boundary_calls']=1
    try:
        with (OWNER/'boundary-recorder.stdout').open('x') as f,contextlib.redirect_stdout(f):
            code=hepta_ci_exec.run(OWNER/'boundaries.json',args,minimum_tests=2,timeout_seconds=available)
    finally:
        elapsed=time.monotonic()-begin;charged_seconds+=elapsed;result['boundary_elapsed_seconds']=elapsed
    result['boundary_command_exit']=code
    reports=[path for path in report_paths if path.exists()];assert len(reports)==1,(code,len(reports))
    with (OWNER/'junit-collector.stdout').open('x') as f,contextlib.redirect_stdout(f):
        collected=hepta_ci_junit.collect(OWNER/'boundaries.json',reports[0],OWNER/'boundaries.xml')
    cases=list(ET.parse(OWNER/'boundaries.xml').iter('testcase'));actual=[x.attrib['name'] for x in cases];assert sorted(actual)==sorted(CASES)
    result['cases']=actual;assert code==collected==0 and all(x.find(t) is None for x in cases for t in ('skipped','error','failure'))
    assert charged_seconds<=REMAIN;result['successful']=True
except BaseException as exc:
    result['error']=repr(exc);(OWNER/'ERROR.txt').write_text(traceback.format_exc())
finally:
    for key,check in [('source',source_state),('tools',tool_ids),('protected',protected)]:
        if key+'_before' not in result:continue
        try:
            result[key+'_after']=check();assert result[key+'_after']==result[key+'_before']
        except BaseException as exc:
            result[key+'_after_error']=repr(exc);result['successful']=False
    result['compile_charged_seconds']=charged_seconds;result['compile_cumulative']=USED+charged_seconds
    result['compile_remaining_after']=REMAIN-charged_seconds;result['owner_seconds']=time.monotonic()-started
    save('RESULT.json',result)
    for fd in fds:os.close(fd)
    print(json.dumps({'successful':result['successful'],'sha256':sha(OWNER/'RESULT.json'),'result':str(OWNER/'RESULT.json'),'error':result.get('error'),'charged':charged_seconds}),flush=True)
sys.exit(0 if result['successful'] else 1)
