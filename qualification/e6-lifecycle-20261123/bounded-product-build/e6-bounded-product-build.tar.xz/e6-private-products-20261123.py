"""Validate the exact cold-publication source in its existing isolated Cargo caches."""
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

BASE = Path('/home/qq/work/hepta-e16-ac5459-20261121')
PREP = BASE / 'e6-cold01-first-publication-fix-bf6d-v2-offline'
SRC = PREP / 'source'
UNIT = BASE / 'e6-bf6d-private-neuron-validation-20261123'
TARGET = UNIT / 'target'
CACHE = UNIT / 'cargo-home'
OWNER = BASE / 'e6-bf6d-private-products-20261123'
DONOR = BASE / 'e6-lifecycle-qualification-v1'
COMMIT = 'bf6d51904c8bcda5d50f3782c85ece84cb73a78f'
PARENT = '61503a7d3bc87a5584cd2f20b8b17ea3838fdcfd'
TREE = '03f7135e2c060422f9dbd51bb38c5701cfaefe24'
REMAIN = 625.7520949426107
USED = 1174.2479050573893
CASES = ['cell_generation_current::tests::original_observer::feature::' + name for name in (
    'original_feature_boundary_keeps_genesis_digest_across_actual_drain',
    'original_feature_boundary_refuses_revision_zero_with_resume_or_admission')]
PINS = {'justfile':'74f869224eba12fc4212b043428e7f5b35b551d26f5b06161c25d8aca525f124',
        'scripts/hepta_ci_exec.py':'9b2bfaa563fff018df4e4f10944f6fbc63d307fa4c4a7e167c392288edb5a5c1',
        'scripts/hepta_ci_junit.py':'cdb325f4a9266bc554fa266ee6a42dc1e1390b6b45d4bac47fa50aa9255cdeec',
        'scripts/run-nextest.py':'45c4e35d1ff24840d9e1e05331af0b89475bfe1aec3231afc56fecb8cea66127',
        'scripts/hepta_cell_test_helpers.py':'43802e867f91225efcef9ea4763567c0aeabd5a07b6c03000eb033501b4eb9ae',
        'codex-rs/hepta-agentd/src/ordinary_q24_cold_publication_data_tests.rs':'0985f7296bd6027f6e213a0582cfe77c5263a969a11cf8a4eacb0006473ae403',
        'codex-rs/hepta-agentd/src/ordinary_q24_post_a_completed_data_tests.rs':'b711d8864ce05ce580431f410c91ee05648f1c3b7c4b95e112c4d1ccfebb35fa'}
TOOLS = {'cargo':'f30f9fd1b1d0b8fd10dc33219eb4cd4bec3543f40e434ac71f5a03fd0359063f',
         'just':'50cd9b4a47c26a2570a0cca1bf86a106290b1cd35b131630696f63b9fbd1400d',
         'cargo-nextest':'234184741162d97741c89eca1df6368a45cc4bbade54e8ff2ef64fc7104ecaac',
         'rustc':'ba4b837efb6612dfa8d941c5a72b8a50d1d03a0f36216743b173949aa8d9eb75'}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    assert path.resolve() == path
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode)
    return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]


def tool_ids():
    ids = {}
    for name, expected in TOOLS.items():
        path = Path(shutil.which(name)).resolve(); digest = sha(path)
        assert digest == expected, (name,str(path),digest)
        ids[name] = {'path':str(path),'sha256':digest}
    return ids


def source_state():
    def git(*args):
        return subprocess.check_output(['git','--no-optional-locks',*args],cwd=SRC,timeout=60).decode().strip()
    view = {'commit':git('rev-parse','HEAD'),'parent':git('rev-parse','HEAD^'),'tree':git('rev-parse','HEAD^{tree}'),
            'status':git('status','--porcelain=v1','--untracked-files=all')}
    assert view == {'commit':COMMIT,'parent':PARENT,'tree':TREE,'status':''},view
    for file, digest in PINS.items(): assert sha(SRC / file) == digest,file
    return view


def save(name, data):
    with (OWNER/name).open('x') as out:
        json.dump(data,out,indent=2,sort_keys=True);out.write('\n');out.flush();os.fsync(out.fileno())


def run(label, argv, *, charged=False, cwd=None, limit=60):
    global charged_seconds
    available = min(limit, REMAIN-charged_seconds-2) if charged else limit
    assert available > 0, 'original compile budget exhausted'
    paths = [OWNER/(label+suffix) for suffix in ('.stdout','.stderr')]
    with paths[0].open('xb') as out, paths[1].open('xb') as err:
        child = None; code = None; error = None; started=time.monotonic()
        try:
            child=subprocess.Popen(argv,cwd=cwd or SRC/'codex-rs',stdout=out,stderr=err,stdin=subprocess.DEVNULL,start_new_session=True)
            code=child.wait(timeout=available)
        except BaseException as exc:
            error=repr(exc)
            if child and child.poll() is None:
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                code=child.wait(timeout=10)
        finally:
            elapsed=time.monotonic()-started
            if charged:charged_seconds+=elapsed
            for stream in [out,err]: stream.flush();os.fsync(stream.fileno())
            row={'label':label,'argv':argv,'limit_seconds':available,'wall_seconds':elapsed,'charged':charged,'exit_code':code,'error':error}
            result['commands'].append(row);save(label+'.json',row)
    if code!=0 or error:raise RuntimeError(f'{label}: {error or code}; see original stdout/stderr')
    return paths[0]


os.umask(0o077)
assert os.getuid()==os.geteuid()==1000
OWNER.mkdir(mode=0o700)
started=time.monotonic();charged_seconds=0.0;fds=[]
result={'source':COMMIT,'parent':PARENT,'tree':TREE,'commands':[],'automatic_retry':False,'successful':False,'compile_remaining_before':REMAIN,'compile_used_before':USED,'cold_calls':0,'boundary_calls':0,'classification':'Exact three selected package build groups on independent target; Cargo scoped metadata from repository graph-free strategy. Earlier two boundary units already complete.'}
try:
    for path in [DONOR/'build-v1/owner.lock',BASE/'e6-native-successor-v2/native-component-owner.lock',UNIT/'owner.lock']:
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);fds.append(fd);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert sha(UNIT/'RESULT.json')=='e761a094de7874e7d0aba714e4b25399b3d6586696ef9e334ef004684f876baa'
    assert not (DONOR/'target').exists() and not (PREP/'target').exists()
    previous=json.loads((UNIT/'RESULT.json').read_bytes());assert previous['successful'] and previous['compile_cumulative']==USED and previous['compile_remaining_after']==REMAIN
    for path in [SRC,TARGET,CACHE]:assert path.is_dir() and path.resolve()==path
    temp=OWNER/'tmp';temp.mkdir(mode=0o700);os.chdir(SRC)
    inherited={k:os.environ[k] for k in ('HOME','USER','LOGNAME') if k in os.environ}
    os.environ.clear();os.environ.update(inherited)
    os.environ.update({'TMPDIR':str(temp),'CARGO_HOME':str(CACHE),'CARGO_TARGET_DIR':str(TARGET),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_NET_OFFLINE':'true',
        'SOURCE_SHA':COMMIT,'TESTED_SHA':COMMIT,'HEPTA_CI_LANE':'source-head','PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0','GIT_TERMINAL_PROMPT':'0',
        'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','RUSTUP_HOME':'/home/qq/.rustup','RUSTUP_TOOLCHAIN':'1.96.0','LIBCLANG_PATH':'/home/qq/hepta-learn-ff41-tools/lib',
        'BINDGEN_EXTRA_CLANG_ARGS':'-isystem /usr/lib/gcc/x86_64-linux-gnu/15/include','PATH':str(DONOR/'tooling/bin')+':/home/qq/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qq/.cargo/bin:/home/qq/hepta-learn-ff41-tools/bin:/home/qq/hepta-learn-ff41-tools/python/bin:/usr/local/bin:/usr/bin:/bin'})

    assert sha(BASE/'e6-bf6d-source-gates-20261123/format.exit.json')==previous['format_receipt_sha256']
    result['source_before']=source_state();result['tools_before']=tool_ids()
    import tomllib
    packages=tomllib.loads((SRC/'codex-rs/Cargo.lock').read_text())['package'];lock={(i['name'],i['version']):i['checksum'] for i in packages if i.get('source','').startswith('registry+')}
    plan=[{'n': 'aws-smithy-async', 'v': '1.3.1', 'sha256': 'de681a9df7ff79823b759ee17061076ec049cd61a8fa28ece4293d89c9f6964e', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/aws-smithy-async-1.3.1.crate', 'bytes': 22076, 'host': 'desktop'}, {'n': 'aws-smithy-http', 'v': '0.64.2', 'sha256': 'ba8960956e0ee0ca3f3161e62913a61bc65a7ef638ca3ef1d4c7159f8443e398', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/aws-smithy-http-0.64.2.crate', 'bytes': 29617, 'host': 'desktop'}, {'n': 'aws-smithy-http-client', 'v': '1.5.1', 'sha256': 'aeca69f65362f7375891008ea525fd440ad6db1836458ac188c87b126804114e', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/aws-smithy-http-client-1.5.1.crate', 'bytes': 409938, 'host': 'desktop'}, {'n': 'aws-smithy-runtime', 'v': '1.16.1', 'sha256': '79cef0c41e8ca40f74f68ed8ee4d1ddbde12bb847b95ef9b3c025681ddfae58a', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/aws-smithy-runtime-1.16.1.crate', 'bytes': 147227, 'host': 'desktop'}, {'n': 'aws-smithy-runtime-api', 'v': '1.19.1', 'sha256': '06788004dea79018413f381891da6dcca23196acd79c4d51b767fbdacc76eae4', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/aws-smithy-runtime-api-1.19.1.crate', 'bytes': 102573, 'host': 'desktop'}, {'n': 'aws-smithy-schema', 'v': '1.0.0', 'sha256': '1d7a3b01a2a1b453176457b260b0ed55d33de61d35d21b74022c51ec62a42895', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/aws-smithy-schema-1.0.0.crate', 'bytes': 186303, 'host': 'desktop'}, {'n': 'aws-smithy-types', 'v': '1.9.0', 'sha256': '55752025c39c0e094962fd73f1c57014b191f678612e517f219468e575af9822', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/aws-smithy-types-1.9.0.crate', 'bytes': 122296, 'host': 'desktop'}, {'n': 'blake3', 'v': '1.8.7', 'sha256': '6d9e454fc11f76977dc803893aff6304ed33d6a26efae8696573bea74baa27ae', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/blake3-1.8.7.crate', 'bytes': 209726, 'host': 'desktop'}, {'n': 'constant_time_eq', 'v': '0.4.2', 'sha256': '3d52eff69cd5e647efe296129160853a42795992097e8af39800e1060caeea9b', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/constant_time_eq-0.4.2.crate', 'bytes': 25831, 'host': 'desktop'}, {'n': 'libsqlite3-sys', 'v': '0.39.1', 'sha256': '14a5f01b87b92705d07b433c06f96cbc764637d81a0bffb5734ce17cf0f9a2b3', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.39.1.crate', 'bytes': 2759388, 'host': 'desktop'}, {'n': 'loom', 'v': '0.7.3', 'host': None}, {'n': 'process-wrap', 'v': '10.0.1', 'sha256': '1f21b97672d2dc848e7b25701ab4535618b92f4861c13cc3f7f7bed52ad3c8da', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/process-wrap-10.0.1.crate', 'bytes': 201062, 'host': 'desktop'}, {'n': 'rmcp', 'v': '3.9.0', 'sha256': 'd24a7e92f4bcaa36b97fa93c4fa7ca8f3e669eced949345b3462dba333c7f909', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/rmcp-3.9.0.crate', 'bytes': 677294, 'host': 'desktop'}, {'n': 'rmcp-macros', 'v': '3.9.0', 'sha256': 'b3140f24a766f80f9ec1607bde85680959a69b83d46fa9ce87dadab7e67ab029', 'path': '/home/qian-qi/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/rmcp-macros-3.9.0.crate', 'bytes': 24500, 'host': 'desktop'}, {'n': 'time', 'v': '0.3.55', 'sha256': 'cdb87b95ec50ddfa440816d227a17b2ccbdda963a316a727fda0fc4334f7d134', 'path': '/home/qq/work/hepta-audit-pty-diagnostic-20261105/cargo-home/registry/cache/index.crates.io-1949cf8c6b5b557f/time-0.3.55.crate', 'bytes': 279955, 'host': 'ai395'}, {'n': 'time-core', 'v': '0.1.9', 'sha256': '9e1c906769ad99c88eaa54e728060edef082f8e358ff32030cb7c7d315e81109', 'path': '/home/qq/work/hepta-audit-pty-diagnostic-20261105/cargo-home/registry/cache/index.crates.io-1949cf8c6b5b557f/time-core-0.1.9.crate', 'bytes': 10320, 'host': 'ai395'}, {'n': 'time-macros', 'v': '0.2.32', 'sha256': '7e689342a48d2ea927c87ea50cabf8594854bf940e9310208848d680d668ed85', 'path': '/home/qq/work/hepta-audit-pty-diagnostic-20261105/cargo-home/registry/cache/index.crates.io-1949cf8c6b5b557f/time-macros-0.2.32.crate', 'bytes': 33664, 'host': 'ai395'}]
    cache=CACHE/'registry/cache/index.crates.io-1949cf8c6b5b557f';result['added_archives']=[]
    for item in plan:
        if not item['host']:continue
        name=item['n'];vers=item['v'];digest=lock[(name,vers)];assert item['sha256']==digest
        dest=cache/f'{name}-{vers}.crate';parts=[Path(item['path'])] if item['host']=='ai395' else [UNIT/'tmp'/f'input-{name}-{vers}-{i}.bin' for i in range((item['bytes']+851954)//851955)]
        stage=temp/dest.name
        with stage.open('xb') as out:
            for path in parts:
                assert path.resolve()==path and path.is_file() and path.stat().st_nlink==1
                with path.open('rb') as inp:shutil.copyfileobj(inp,out)
        assert stage.stat().st_size==item['bytes'] and sha(stage)==digest
        if dest.exists():assert sha(dest)==digest
        else:stage.rename(dest)
        result['added_archives'].append([name,vers,digest])
    save('PREPARED.json',result);result['preparation_seconds']=time.monotonic()-started
    print(json.dumps({'state':'starting-scoped-build','verified_archives':len(result['added_archives']),'budget':REMAIN}),flush=True)
    meta_path=run('metadata',['cargo','metadata','--no-deps','--locked','--offline','--format-version=1'],charged=True,limit=REMAIN)
    meta=json.loads(meta_path.read_bytes());assert Path(meta['workspace_root'])==SRC/'codex-rs' and Path(meta['target_directory'])==TARGET
    for package in meta['packages']:assert Path(package['manifest_path']).resolve().is_relative_to(SRC)
    lib=run('library',['cargo','nextest','list','--locked','--offline','-p','codex-hepta-agentd','-p','codex-hepta-contracts','-p','codex-hepta-neuron','--lib','--list-type','binaries-only','--message-format','json','--cargo-metadata',str(meta_path)],charged=True,limit=REMAIN)
    bins=json.loads(lib.read_bytes());assert Path(bins['rust-build-meta']['target-directory'])==TARGET
    assert set(bins['rust-binaries'])=={'codex-hepta-agentd','codex-hepta-contracts','codex-hepta-neuron'}
    result['test_binaries']={}
    for key,item in bins['rust-binaries'].items():
        path=Path(item['binary-path']);assert path.resolve().is_relative_to(TARGET);result['test_binaries'][key]={'path':str(path),'sha256':sha(path)}
    prod=run('products',['cargo','build','--locked','--offline','-p','codex-hepta-agentd','--bin','codex-hepta-agentd','--bin','hepta-authority-host','--message-format=json-render-diagnostics'],charged=True,limit=REMAIN)
    products={}
    for line in prod.read_bytes().splitlines():
        item=json.loads(line);name=item.get('target',{}).get('name')
        if item.get('reason')=='compiler-artifact' and name in ('codex-hepta-agentd','hepta-authority-host') and item.get('executable'):
            path=Path(item['executable']);assert path.resolve().is_relative_to(TARGET) and not item['profile']['test'];products[name]={'path':str(path),'sha256':sha(path)}
    assert len(products)==2;result['products']=products
    helper=['python3','scripts/hepta_cell_test_helpers.py','--package','codex-hepta-infer-worker-host','--output-dir',str(OWNER/'helpers')]
    run('helper',helper,cwd=SRC,charged=True,limit=REMAIN);run('helper-verify',helper+['--verify-only'],cwd=SRC,charged=True,limit=REMAIN)

    result['successful']=True
except BaseException as exc:
    result['error']=repr(exc);(OWNER/'ERROR.txt').write_text(traceback.format_exc())
finally:
    for key,check in [('source',source_state),('tools',tool_ids)]:
        if key+'_before' not in result:continue
        try:
            result[key+'_after']=check();assert result[key+'_after']==result[key+'_before']
        except BaseException as exc:
            result[key+'_after_error']=repr(exc);result['successful']=False
    result['compile_charged_seconds']=charged_seconds;result['compile_cumulative']=USED+charged_seconds;result['compile_remaining_after']=REMAIN-charged_seconds;result['owner_seconds']=time.monotonic()-started
    save('RESULT.json',result)
    for fd in fds:os.close(fd)
    print(json.dumps({'successful':result['successful'],'sha256':sha(OWNER/'RESULT.json'),'error':result.get('error'),'charged_seconds':charged_seconds}),flush=True)
sys.exit(0 if result['successful'] else 1)
