"""Validate the exact cold-publication source in its existing isolated Cargo caches."""
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

BASE = Path('/home/qq/work/hepta-e16-ac5459-20261121')
PREP = BASE / 'e6-cold01-first-publication-fix-bf6d-v2-offline'
SRC = PREP / 'source'
OWNER = BASE / 'e6-bf6d-private-neuron-validation-20261123'
TARGET = OWNER / 'target'
CACHE = OWNER / 'cargo-home'
DONOR = BASE / 'e6-lifecycle-qualification-v1'
COMMIT = 'bf6d51904c8bcda5d50f3782c85ece84cb73a78f'
PARENT = '61503a7d3bc87a5584cd2f20b8b17ea3838fdcfd'
TREE = '03f7135e2c060422f9dbd51bb38c5701cfaefe24'
REMAIN = 647.3566216025501
USED = 1152.6433783974499
CASES = ['cell_generation_current::tests::original_observer::feature::' + name for name in (
    'original_feature_boundary_keeps_genesis_digest_across_actual_drain',
    'original_feature_boundary_refuses_revision_zero_with_resume_or_admission')]
PINS = {'justfile':'74f869224eba12fc4212b043428e7f5b35b551d26f5b06161c25d8aca525f124',
        'scripts/hepta_ci_exec.py':'9b2bfaa563fff018df4e4f10944f6fbc63d307fa4c4a7e167c392288edb5a5c1',
        'scripts/hepta_ci_junit.py':'cdb325f4a9266bc554fa266ee6a42dc1e1390b6b45d4bac47fa50aa9255cdeec',
        'scripts/run-nextest.py':'45c4e35d1ff24840d9e1e05331af0b89475bfe1aec3231afc56fecb8cea66127',
        'scripts/hepta_cell_test_helpers.py':'43802e867f91225efcef9ea4763567c0aeabd5a07b6c03000eb033501b4eb9ae',
        'codex-rs/hepta-agentd/src/ordinary_q24_cold_publication_data_tests.rs':'0985f7296bd6027f6e213a0582cfe77c5263a969a11cf8a4eacb0006473ae403',
        'codex-rs/hepta-agentd/src/ordinary_q24_post_a_completed_data_tests.rs':'b711d8864ce05ce580431f410c91ee05648f1c3b7c4b95e112c4d1ccfebb35fa'}
TOOLS = {'cargo':'f30f9fd1b1d0b8fd10dc33219eb4cd4bec3543f40e434ac71f5a03fd0359063f',
         'just':'50cd9b4a47c26a2570a0cca1bf86a106290b1cd35b131630696f63b9fbd1400d',
         'cargo-nextest':'234184741162d97741c89eca1df6368a45cc4bbade54e8ff2ef64fc7104ecaac',
         'rustc':'ba4b837efb6612dfa8d941c5a72b8a50d1d03a0f36216743b173949aa8d9eb75'}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    assert path.resolve() == path
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode)
    return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]


def protected():
    rows = []
    for expected in prepared['protected_before']:
        name = expected['path']; pre = identity(name); digest = sha(name)
        assert pre == identity(name) == expected['identity'] and digest == expected['sha256']
        rows.append({'path':name,'identity':pre,'sha256':digest})
    return rows


def tool_ids():
    ids = {}
    for name, expected in TOOLS.items():
        path = Path(shutil.which(name)).resolve(); digest = sha(path)
        assert digest == expected, (name,str(path),digest)
        ids[name] = {'path':str(path),'sha256':digest}
    return ids


def source_state():
    def git(*args):
        return subprocess.check_output(['git','--no-optional-locks',*args],cwd=SRC,timeout=60).decode().strip()
    view = {'commit':git('rev-parse','HEAD'),'parent':git('rev-parse','HEAD^'),'tree':git('rev-parse','HEAD^{tree}'),
            'status':git('status','--porcelain=v1','--untracked-files=all')}
    assert view == {'commit':COMMIT,'parent':PARENT,'tree':TREE,'status':''},view
    for file, digest in PINS.items(): assert sha(SRC / file) == digest,file
    return view


def save(name, data):
    with (OWNER/name).open('x') as out:
        json.dump(data,out,indent=2,sort_keys=True);out.write('\n');out.flush();os.fsync(out.fileno())


def run(label, argv, *, charged=False, cwd=None, limit=60):
    global charged_seconds
    available = min(limit, REMAIN-charged_seconds) if charged else limit
    assert available > 0, 'original compile budget exhausted'
    paths = [OWNER/(label+suffix) for suffix in ('.stdout','.stderr')]
    with paths[0].open('xb') as out, paths[1].open('xb') as err:
        child = None; code = None; error = None; started=time.monotonic()
        try:
            child=subprocess.Popen(argv,cwd=cwd or SRC/'codex-rs',stdout=out,stderr=err,stdin=subprocess.DEVNULL,start_new_session=True)
            code=child.wait(timeout=available)
        except BaseException as exc:
            error=repr(exc)
            if child and child.poll() is None:
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                code=child.wait(timeout=10)
        finally:
            elapsed=time.monotonic()-started
            if charged:charged_seconds+=elapsed
            for stream in [out,err]: stream.flush();os.fsync(stream.fileno())
            row={'label':label,'argv':argv,'limit_seconds':available,'wall_seconds':elapsed,'charged':charged,'exit_code':code,'error':error}
            result['commands'].append(row);save(label+'.json',row)
    if code!=0 or error:raise RuntimeError(f'{label}: {error or code}; see original stdout/stderr')
    return paths[0]


import tomllib

def sparse_key(name):
    name=name.lower()
    if len(name)<3:return str(len(name))+'/'+name
    if len(name)==3:return '3/'+name[0]+'/'+name
    return name[:2]+'/'+name[2:4]+'/'+name

def copy_registry():
    key='index.crates.io-1949cf8c6b5b557f'
    pool=[Path('/home/qq/work/hepta-worker-unified-20261105-4d868a11/cargo-home/registry'),Path('/home/qq/.cargo/registry')]
    index=CACHE/'registry/index'/key;downloads=CACHE/'registry/cache'/key
    index.mkdir(parents=True);downloads.mkdir(parents=True)
    config=next(root/'index'/key/'config.json' for root in pool if (root/'index'/key/'config.json').is_file())
    shutil.copyfile(config,index/'config.json')
    lock=tomllib.loads((SRC/'codex-rs/Cargo.lock').read_text());rows=[];missing=[];index_missing=[]
    required={}
    for item in lock['package']:
        if item.get('source','').startswith('registry+'):
            required.setdefault(item['name'],set()).add((item['version'],item['checksum']))
    for r in lock['package']:
        if not r.get('source','').startswith('registry+'):continue
        name=r['name'];version=r['version'];sha256=r['checksum'];filename=f'{name}-{version}.crate';leaf=Path('.cache')/sparse_key(name)
        if not (index/leaf).exists():
            src=None
            for root in pool:
                candidate=root/'index'/key/leaf
                if not candidate.is_file():continue
                records=[json.loads(line) for line in candidate.read_bytes().split(b'\0') if line.startswith(b'{')]
                if required[name]<={(e['vers'],e['cksum']) for e in records}:src=candidate;break
            if src:
                (index/leaf).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,index/leaf)
            else:index_missing.append(name)
        src=next((root/'cache'/key/filename for root in pool if (root/'cache'/key/filename).is_file()),None)
        if src is None:missing.append([name,version]);continue
        assert src.resolve()==src and src.is_file() and not src.is_symlink()
        shutil.copyfile(src,downloads/filename);assert sha(downloads/filename)==sha256,(name,version)
        rows.append({'name':name,'version':version,'sha256':sha256,'bytes':(downloads/filename).stat().st_size,'source':str(src)})
    save('locked-crates.json',{'verified':rows,'missing':missing,'missing_index':index_missing})
    result['locked_registry']={'verified':len(rows),'missing':len(missing),'missing_index':len(index_missing),'bytes':sum(r['bytes'] for r in rows)}
    git_source=PREP/'cargo-home/git';assert git_source.resolve()==git_source
    for path in git_source.rglob('*'):
        assert not path.is_symlink() and (path.is_dir() or path.is_file()),str(path)
        if path.name=='alternates' and path.parent.name=='info':assert not path.read_bytes().strip(),str(path)
    shutil.copytree(git_source,CACHE/'git',copy_function=shutil.copy2)
    for path in (CACHE/'git').rglob('*'):
        if path.is_file():
            donor=git_source/path.relative_to(CACHE/'git');a=donor.stat();b=path.stat();assert b.st_nlink==1 and (a.st_dev,a.st_ino)!=(b.st_dev,b.st_ino) and sha(donor)==sha(path)
    result['verified_private_git_copy']=True

os.umask(0o077);assert os.getuid()==os.geteuid()==1000
OWNER.mkdir(mode=0o700);TARGET.mkdir(mode=0o700);CACHE.mkdir(mode=0o700);temp=OWNER/'tmp';temp.mkdir(mode=0o700)
started=time.monotonic();charged_seconds=0.0;fds=[]
result={'source':COMMIT,'tree':TREE,'parent':PARENT,'commands':[],'compile_used_before':USED,'compile_remaining_before':REMAIN,'cold_calls':0,'boundary_calls':0,'successful':False,'target_initially_empty':not any(TARGET.iterdir()),'automatic_retry':False,'classification':'Independent exact-source neuron boundary execution. Historical donor and prepared target unavailable.'}
try:
    for path in [DONOR/'build-v1/owner.lock',BASE/'e6-native-successor-v2/native-component-owner.lock']:
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);fds.append(fd);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    fd=os.open(OWNER/'owner.lock',os.O_RDWR|os.O_NOFOLLOW|os.O_EXCL|os.O_CREAT,0o600);fds.append(fd);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not (DONOR/'target').exists() and not (PREP/'target').exists()
    assert sha(PREP/'RESULT.json')=='6d611cacc4f8c09702ccebf828530d1611c53b39d465ba90adac0219f15dcb92'
    prior=BASE/'e6-cold01-bf6d-build-boundaries-20261123/RESULT.json';assert sha(prior)=='a9bb64180d90794dc2c9ea1f46e86bcfeb8bb0eb87e642fa1971f77485e69b1f' and json.loads(prior.read_bytes())['compile_charged_seconds']==0
    for row in json.loads((PREP/'RESULT.json').read_bytes())['protected_before']:
        p=Path(row['path']);assert not p.exists();result.setdefault('absent_original_ELF_paths_before',[]).append(str(p))
    os.chdir(SRC);env={k:os.environ[k] for k in ('HOME','USER','LOGNAME') if k in os.environ};os.environ.clear();os.environ.update(env)
    os.environ.update({'TMPDIR':str(temp),'CARGO_HOME':str(CACHE),'CARGO_TARGET_DIR':str(TARGET),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_NET_OFFLINE':'true',
        'SOURCE_SHA':COMMIT,'TESTED_SHA':COMMIT,'HEPTA_CI_LANE':'source-head','PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0','GIT_TERMINAL_PROMPT':'0',
        'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','RUSTUP_HOME':'/home/qq/.rustup','RUSTUP_TOOLCHAIN':'1.96.0','LIBCLANG_PATH':'/home/qq/hepta-learn-ff41-tools/lib',
        'BINDGEN_EXTRA_CLANG_ARGS':'-isystem /usr/lib/gcc/x86_64-linux-gnu/15/include','PATH':str(DONOR/'tooling/bin')+':/home/qq/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qq/.cargo/bin:/home/qq/hepta-learn-ff41-tools/bin:/home/qq/hepta-learn-ff41-tools/python/bin:/usr/local/bin:/usr/bin:/bin'})
    result['tools_before']=tool_ids();result['source_before']=source_state();copy_registry()
    sg=BASE/'e6-bf6d-source-gates-20261123/format.exit.json';fmt=json.loads(sg.read_bytes());assert fmt['argv']==['just','fmt','--base',PARENT] and fmt['exit_code']==0 and fmt['cwd']==str(SRC/'codex-rs')
    result['format_receipt_sha256']=sha(sg);result['preparation_wall_seconds']=time.monotonic()-started;save('PREPARED.json',result)
    sys.path.insert(0,str(SRC/'scripts'))
    import hepta_ci_exec,hepta_ci_junit
    paths=[TARGET/'nextest/local/junit.xml',SRC/'codex-rs/target/nextest/local/junit.xml'];assert not any(p.exists() for p in paths)
    expression=' or '.join('test(='+name+')' for name in CASES)
    args=['just','test','--locked','--offline','-p','codex-hepta-neuron','--lib','--test-threads','1','-E',expression,'--retries','0','--success-output','final','--failure-output','final','--no-tests','fail']
    result['boundary_calls']=1;begin=time.monotonic()
    try:
        with (OWNER/'recorder.stdout').open('x') as f,contextlib.redirect_stdout(f):code=hepta_ci_exec.run(OWNER/'boundaries.json',args,minimum_tests=2,timeout_seconds=REMAIN-2)
    finally:charged_seconds=time.monotonic()-begin
    result['boundary_exit_code']=code
    reports=[p for p in paths if p.exists()];assert len(reports)==1,('fresh JUnit count',len(reports),'command exit',code)
    with (OWNER/'collector.stdout').open('x') as f,contextlib.redirect_stdout(f):collected=hepta_ci_junit.collect(OWNER/'boundaries.json',reports[0],OWNER/'boundaries.xml')
    cases=list(ET.parse(OWNER/'boundaries.xml').iter('testcase'));result['observed_cases']=[c.attrib['name'] for c in cases]
    assert code==collected==0 and sorted(result['observed_cases'])==sorted(CASES) and all(x.find(t) is None for x in cases for t in ['error','failure','skipped'])
    assert charged_seconds<=REMAIN;result['successful']=True
except BaseException as exc:
    result['error']=repr(exc);(OWNER/'ERROR.txt').write_text(traceback.format_exc())
finally:
    for k,fn in [('source',source_state),('tools',tool_ids)]:
        if k+'_before' in result:
            try:result[k+'_after']=fn();assert result[k+'_after']==result[k+'_before']
            except BaseException as exc:result[k+'_after_error']=repr(exc);result['successful']=False
    result['absent_original_ELF_paths_after']=[k for k in result.get('absent_original_ELF_paths_before',[]) if not Path(k).exists()]
    result['compile_charged_seconds']=charged_seconds;result['compile_cumulative']=USED+charged_seconds;result['compile_remaining_after']=REMAIN-charged_seconds
    result['owner_seconds']=time.monotonic()-started;save('RESULT.json',result)
    for fd in fds:os.close(fd)
    print(json.dumps({'successful':result['successful'],'sha256':sha(OWNER/'RESULT.json'),'charged_seconds':charged_seconds,'error':result.get('error')}),flush=True)
sys.exit(0 if result['successful'] else 1)
