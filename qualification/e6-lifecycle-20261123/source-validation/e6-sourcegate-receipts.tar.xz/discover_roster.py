import json,pathlib,sys,unittest
root=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);loader=unittest.TestLoader()
suite=loader.discover(str(root/'qa/b4-no-bypass'),pattern='test_*.py')
def ids(value):
 if isinstance(value,unittest.TestSuite):return [name for child in value for name in ids(child)]
 return [value.id()]
cases=ids(suite)
with (out/'B4_DISCOVERED_ROSTER.json').open('x') as stream:json.dump({'cases':cases,'loader_errors':loader.errors,'count':len(cases)},stream,indent=2);stream.write('\n')
assert not loader.errors and len(cases)==len(set(cases))==1014
