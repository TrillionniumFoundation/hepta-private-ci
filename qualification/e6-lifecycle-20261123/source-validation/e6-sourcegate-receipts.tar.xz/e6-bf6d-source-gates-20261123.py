"""Exercise the three original source checks on the existing bf6d checkout."""
from pathlib import Path
import hashlib, json, os, re, signal, subprocess, sys, time, traceback

BASE=Path('/home/qq/work/hepta-e16-ac5459-20261121')
SRC=BASE/'e6-cold01-first-publication-fix-bf6d-v2-offline/source'
OUT=BASE/'e6-bf6d-source-gates-20261123'
SHA='bf6d51904c8bcda5d50f3782c85ece84cb73a78f'
PARENT='61503a7d3bc87a5584cd2f20b8b17ea3838fdcfd'
TREE='03f7135e2c060422f9dbd51bb38c5701cfaefe24'

def datahash(data):return hashlib.sha256(data).hexdigest()

def git(*args):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=SRC,timeout=60)

def inventory():
    assert git('rev-parse','HEAD').decode().strip()==SHA
    assert git('rev-parse','HEAD^{tree}').decode().strip()==TREE
    assert git('rev-parse','HEAD^').decode().strip()==PARENT
    assert not git('status','--porcelain=v1','--untracked-files=all').strip()
    rows=[]
    for entry in git('ls-files','-s','-z').split(b'\0'):
        if not entry:continue
        info,name=entry.split(b'\t',1);mode,oid,stage=info.split();fn=SRC/os.fsdecode(name)
        assert stage==b'0' and mode in (b'100644',b'100755',b'120000')
        data=os.fsencode(os.readlink(fn)) if mode==b'120000' else fn.read_bytes()
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode()==oid
        rows.append([os.fsdecode(name),mode.decode(),len(data),datahash(data)])
    return rows

def save(name,data):
    with (OUT/name).open('x') as f:json.dump(data,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())

def command(label,argv,limit,cwd=SRC):
    row={'label':label,'argv':argv,'cwd':str(cwd),'limit_seconds':limit,'started_unix_ns':time.time_ns()};save(label+'.intent.json',row)
    with (OUT/(label+'.stdout')).open('xb') as out,(OUT/(label+'.stderr')).open('xb') as err:
        start=time.monotonic();child=subprocess.Popen(argv,cwd=cwd,stdout=out,stderr=err,stdin=subprocess.DEVNULL,start_new_session=True)
        try:code=child.wait(timeout=limit);row['timed_out']=False
        except subprocess.TimeoutExpired:
            row['timed_out']=True;os.killpg(child.pid,signal.SIGTERM)
            try:code=child.wait(timeout=3)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=3)
        elapsed=time.monotonic()-start
        for f in [out,err]:f.flush();os.fsync(f.fileno())
    row.update(exit_code=code,wall_seconds=elapsed,finished_unix_ns=time.time_ns());result['commands'].append(row);save(label+'.exit.json',row)
    print(json.dumps(row),flush=True)
    if code!=0:raise RuntimeError(f'{label} exit {code}; see original streams')
    return elapsed

assert os.getuid()==os.geteuid()==1000
os.umask(0o077);OUT.mkdir(mode=0o700);tmp=OUT/'tmp';tmp.mkdir(mode=0o700)
path=str(BASE/'e6-lifecycle-qualification-v1/tooling/bin')+':/home/qq/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qq/.cargo/bin:/usr/local/bin:/usr/bin:/bin'
os.environ.update(PATH=path,TMPDIR=str(tmp),GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0',PYTHONDONTWRITEBYTECODE='1',RUSTUP_TOOLCHAIN='1.96.0',CARGO_NET_OFFLINE='true')
start=time.monotonic();result={'source':SHA,'tree':TREE,'parent':PARENT,'successful':False,'commands':[],'original_roster_count':1014,'native_or_model_calls':0,'compile_charged_seconds':0}
try:
    before=inventory();save('source-before.json',before);result['tracked_files']=len(before)
    command('format',['just','fmt','--base',PARENT],60,SRC/'codex-rs');assert inventory()==before
    elapsed=command('callers-self-test',['/usr/bin/python3','scripts/verify_hepta_callers.py','self-test'],1800)
    assert inventory()==before
    command('callers-verify',['/usr/bin/python3','scripts/verify_hepta_callers.py','verify'],1800-elapsed)
    assert inventory()==before
    roster="""import json,pathlib,sys,unittest
root=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);loader=unittest.TestLoader()
suite=loader.discover(str(root/'qa/b4-no-bypass'),pattern='test_*.py')
def ids(value):
 if isinstance(value,unittest.TestSuite):return [name for child in value for name in ids(child)]
 return [value.id()]
cases=ids(suite)
with (out/'B4_DISCOVERED_ROSTER.json').open('x') as stream:json.dump({'cases':cases,'loader_errors':loader.errors,'count':len(cases)},stream,indent=2);stream.write('\\n')
assert not loader.errors and len(cases)==len(set(cases))==1014
"""
    (OUT/'discover_roster.py').write_text(roster)
    elapsed=command('b4-roster-only',['/usr/bin/python3',str(OUT/'discover_roster.py'),str(SRC),str(OUT)],60)
    assert inventory()==before
    command('b4-full',['/usr/bin/python3','-m','unittest','discover','-s','qa/b4-no-bypass','-p','test_*.py'],1800-elapsed)
    log=(OUT/'b4-full.stderr').read_text();assert re.findall(r'^Ran (\d+) tests? in [0-9.]+s$',log,re.M)==['1014'] and re.search(r'^OK$',log,re.M) and not re.search(r'^OK \(skipped=',log,re.M)
    result['original_cli_checks_passed']=True;result['successful']=True
except BaseException as exc:
    result['error']=repr(exc);(OUT/'ERROR.txt').write_text(traceback.format_exc())
finally:
    if 'before' in locals():
        try:
            after=inventory();save('source-after.json',after);result['source_unchanged']=before==after;assert result['source_unchanged']
        except BaseException as exc:result.update(successful=False,source_after_error=repr(exc))
    result['wall_seconds']=time.monotonic()-start;save('RESULT.json',result);print(json.dumps(result),flush=True)
sys.exit(0 if result['successful'] else 1)
