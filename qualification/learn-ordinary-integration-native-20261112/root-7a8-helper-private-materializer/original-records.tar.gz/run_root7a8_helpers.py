import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

source = Path('/workspace/scratch/ff41dfc0f7bf/hepta-native-b26ea05c-cloud')
records = Path('/workspace/scratch/ff41dfc0f7bf/tooling/validation/integration-7a8cc3c8-cloud-helpers')
target = Path('/workspace/scratch/ff41dfc0f7bf/target-cloud-native')
records.mkdir()
environment = {**os.environ, 'CARGO_TARGET_DIR': str(target), 'CARGO_BUILD_JOBS': '1',
               'SOURCE_SHA': '7a8cc3c8c473b623a12667f49750c2ee5a46ea14',
               'TESTED_SHA': '7a8cc3c8c473b623a12667f49750c2ee5a46ea14',
               'HEPTA_CI_LANE': 'independent-root7a8-helper-build'}

def snapshot():
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=source, text=True).strip()
    return {'sha': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain=v1', '--untracked-files=all')}

record = {'before': snapshot(), 'source_path': str(source), 'uid': os.geteuid(),
          'executor': platform.node(), 'scope': 'required same-source native helper build only; zero executed tests',
          'state': 'running', 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'previous_attempts': '6318 source/raw preserved before switching this terminated source checkout; no result inherited',
          'environment': {k: environment[k] for k in ('CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
          'CARGO_HOME', 'RUSTUP_HOME', 'RUSTUP_TOOLCHAIN', 'BINDGEN_EXTRA_CLANG_ARGS',
          'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'RUSTFLAGS') if k in environment}}
assert record['before'] == {'sha': environment['SOURCE_SHA'], 'tree': 'c39ccb2167f7f8c1f3b2899ebaa073fd61a3bac1', 'status': ''}
command = [sys.executable, 'scripts/hepta_cell_test_helpers.py', '--package',
           'codex-hepta-infer-worker-host', '--output-dir', str(records / 'helpers')]
record['command'] = command
(records / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
with (records / 'build.log').open('xb') as log:
    result = subprocess.run(command, cwd=source, env=environment, stdout=log, stderr=subprocess.STDOUT)
record.update(state='completed', exit_code=result.returncode, elapsed_seconds=time.monotonic() - start)
if result.returncode == 0:
    with (records / 'verify.log').open('xb') as log:
        check = subprocess.run([*command, '--verify-only'], cwd=source, env=environment,
                               stdout=log, stderr=subprocess.STDOUT)
    record['verify_exit_code'] = check.returncode
record.update(after=snapshot(), finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
record['source_unchanged'] = record['before'] == record['after']
record['tests'] = 0
record['junit'] = []
record['files'] = [{'path': str(p.relative_to(records)), 'bytes': p.stat().st_size,
                    'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                   for p in sorted(records.rglob('*')) if p.is_file() and p.name != 'run.json']
(records / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if result.returncode == 0 and record.get('verify_exit_code') == 0 and record['source_unchanged'] else 1)
