#!/usr/bin/env python3
"""Record the original three-library scope on a fresh cloud executor."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

source = Path("/workspace/scratch/ff41dfc0f7bf/hepta-native-fix-recovered-cloud")
records = Path("/workspace/scratch/ff41dfc0f7bf/tooling/validation/integration-2420fb01-cloud")
target = Path("/workspace/scratch/ff41dfc0f7bf/target-cloud-native")
records.mkdir(parents=True, exist_ok=True)
manifest_path = records / "driver.json"
assert not manifest_path.exists(), "Refuse to overwrite a previous attempt"
env = {**os.environ, "CARGO_TARGET_DIR": str(target), "CARGO_BUILD_JOBS": "2",
       "SOURCE_SHA": "2420fb01d7d26d7c851f48dd24ad2f9385272259",
       "TESTED_SHA": "2420fb01d7d26d7c851f48dd24ad2f9385272259",
       "HEPTA_CI_LANE": "independent-cloud-frozen-native-2420fb01",
       "PYTHONDONTWRITEBYTECODE": "1"}
def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snapshot():
    def git(*args):
        return subprocess.check_output(["git", *args], cwd=source, text=True).strip()
    return {"sha": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "status": git("status", "--porcelain=v1", "--untracked-files=all")}
manifest = {"scope": "ordinary component libraries only; not UID0 or complete learning acceptance",
            "state": "starting", "started_utc": utc(), "source": str(source),
            "before": snapshot(), "uid": os.geteuid(), "executor": platform.node(),
            "target": str(target), "harness_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "selected_environment": {key: env[key] for key in ("CARGO_HOME", "RUSTUP_HOME", "RUSTUP_TOOLCHAIN", "CARGO_TARGET_DIR", "CARGO_BUILD_JOBS", "SOURCE_SHA", "TESTED_SHA", "HEPTA_CI_LANE") if key in env},
            "stages": {}}
def save():
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
def stage(name, command, collect_junit=False):
    folder = records / name
    folder.mkdir()
    start_wall = time.time()
    previous_reports = {}
    candidates = [source / "codex-rs/target/nextest/local/junit.xml", target / "nextest/local/junit.xml"]
    for path in candidates:
        if path.exists():
            previous_reports[str(path)] = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "mtime_ns": path.stat().st_mtime_ns}
    record = {"state": "running", "command": command, "uid": os.geteuid(), "before": snapshot(),
              "started_utc": utc(), "previous_reports": previous_reports}
    path = folder / "run.json"
    path.write_text(json.dumps(record, indent=2) + "\n")
    manifest["state"] = name
    manifest["stages"][name] = {"state": "running", "record": str(path)}
    save()
    start = time.monotonic()
    log = folder / "command.log"
    with log.open("xb") as stream:
        result = subprocess.run(command, cwd=source, env=env, stdout=stream, stderr=subprocess.STDOUT)
    record.update(state="completed", exit_code=result.returncode, elapsed_seconds=time.monotonic() - start, finished_utc=utc(), after=snapshot())
    record["source_unchanged"] = record["before"] == record["after"]
    raw = log.read_bytes()
    record["log"] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    record["junit"] = []
    if collect_junit:
        for candidate in candidates:
            if candidate.exists() and candidate.stat().st_mtime >= start_wall:
                raw_report = candidate.read_bytes()
                digest = hashlib.sha256(raw_report).hexdigest()
                report_name = "junit-" + str(len(record["junit"])) + ".xml"
                shutil.copyfile(candidate, folder / report_name)
                cases = [{"name": case.attrib["name"], "class": case.attrib.get("classname"),
                          "failed": case.find("failure") is not None or case.find("error") is not None,
                          "skipped": case.find("skipped") is not None}
                         for case in ET.fromstring(raw_report).iter("testcase")]
                record["junit"].append({"original_path": str(candidate), "path": report_name,
                                        "bytes": len(raw_report), "sha256": digest, "cases": cases})
    path.write_text(json.dumps(record, indent=2) + "\n")
    manifest["stages"][name] = {"state": "completed", "exit_code": result.returncode,
                                "elapsed_seconds": record["elapsed_seconds"], "record": str(path)}
    save()
    return record

save()
exit_code = 1
try:
    assert os.geteuid() != 0, "ordinary tests require actual unprivileged execution"
    assert manifest["before"] == {"sha": env["SOURCE_SHA"], "tree": "24c507b1536b4dd7d92a87525f1adf13fa455b54", "status": ""}
    helper_command = [sys.executable, "scripts/hepta_cell_test_helpers.py", "--package",
                      "codex-hepta-infer-worker-host", "--output-dir", str(records / "helpers")]
    helper = stage("helpers-build", helper_command)
    if helper["exit_code"] != 0 or not helper["source_unchanged"]:
        raise RuntimeError("actual same-source helper build failed")
    helper_manifest = json.loads((records / "helpers/manifest.json").read_text())
    assert helper_manifest["complete"] and helper_manifest["source_sha"] == env["SOURCE_SHA"]
    env.update(json.loads((records / "helpers/env.json").read_text()))
    verify = stage("helpers-verify-before", [*helper_command, "--verify-only"])
    assert verify["exit_code"] == 0 and verify["source_unchanged"]
    ordinary = stage("ordinary", ["just", "test", "--locked", "-p", "codex-hepta-agentd",
                     "-p", "codex-hepta-agent-protocol", "-p", "codex-hepta-learning-ledger",
                     "--lib", "--retries", "0", "--no-tests", "fail", "--test-threads", "2",
                     "--success-output", "final", "--failure-output", "final"], collect_junit=True)
    verify = stage("helpers-verify-after", [*helper_command, "--verify-only"])
    assert verify["exit_code"] == 0 and verify["source_unchanged"]
    if not ordinary["junit"]:
        raise RuntimeError("ordinary stage produced no fresh JUnit; no test acceptance is recorded")
    assert len(ordinary["junit"]) == 1 and ordinary["source_unchanged"]
    cases = ordinary["junit"][0]["cases"]
    manifest["ordinary_counts"] = {"cases": len(cases), "failed": sum(c["failed"] for c in cases),
                                    "skipped": sum(c["skipped"] for c in cases), "exit_code": ordinary["exit_code"]}
    exit_code = ordinary["exit_code"]
    manifest["state"] = "passed" if exit_code == 0 else "failed"
except Exception as error:
    manifest["state"] = "failed"
    manifest["error"] = type(error).__name__ + ": " + str(error)
    (records / "exception.log").write_text(traceback.format_exc())
finally:
    manifest["final"] = snapshot()
    manifest["source_unchanged"] = manifest["before"] == manifest["final"]
    manifest["finished_utc"] = utc()
    save()
    print(json.dumps(manifest, indent=2))
sys.exit(exit_code)
