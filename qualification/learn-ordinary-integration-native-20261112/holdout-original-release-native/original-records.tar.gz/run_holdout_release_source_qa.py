import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

source = Path('/workspace/scratch/ff41dfc0f7bf/hepta-independent-b-provider-cloud')
records = Path('/workspace/scratch/ff41dfc0f7bf/tooling/validation/holdout-release-a803b7b1-source-qa')
records.mkdir()

def snapshot():
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=source, text=True).strip()
    return {'sha': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain=v1', '--untracked-files=all')}

command = ['python3', '-m', 'unittest', 'discover', '-s', 'qa/b4-no-bypass',
           '-p', 'test_*holdout*source_closure.py', '-v']
record = {'before': snapshot(), 'command': command, 'state': 'running',
          'scope': '18 physical CAS and release source tests, including exactly two caller boundaries scanning all Rust files; no full caller or full source QA claim',
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
assert record['before'] == {'sha': 'a803b7b16fa59abccb6f6a2774456c5c46521344',
                            'tree': 'ca031a13fae4bbd67a6d1dba7b115c92a50cf0ba', 'status': ''}
(records / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
log = records / 'source-qa.log'
with log.open('xb') as output:
    result = subprocess.run(command, cwd=source, stdout=output, stderr=subprocess.STDOUT)
record.update(state='completed', exit_code=result.returncode, elapsed_seconds=time.monotonic() - start,
              after=snapshot(), finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
record['source_unchanged'] = record['before'] == record['after']
record['log'] = {'bytes': log.stat().st_size, 'sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
(records / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if result.returncode == 0 and record['source_unchanged'] else 1)
