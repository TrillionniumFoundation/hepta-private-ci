import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET


plan = json.loads(sys.stdin.read())
repo = Path(plan["repository"])
records = Path(plan["records"])
records.mkdir(parents=True, exist_ok=True)
manifest_path = records / "driver.json"
if manifest_path.exists():
    raise SystemExit("refuse to overwrite a previous attempt")
environment = dict(os.environ)
environment.update(json.loads(Path("/home/qq/hepta-learn-ff41-tools/env.json").read_text()))
environment["SOURCE_SHA"] = plan["source"]
environment["TESTED_SHA"] = plan["source"]
environment["HEPTA_CI_LANE"] = "independent-frozen-native-399ff258"
recorder = "/home/qq/hepta-learn-ff41-tools/run_native_recorded.py"
root_directory = Path(plan["root_directory"])
target = Path(environment["CARGO_TARGET_DIR"])
original_uid, original_gid = os.getuid(), os.getgid()
manifest = {
    "plan": plan,
    "uid": original_uid,
    "status": "starting",
    "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "stages": {},
    "native_acceptance_scope": "component suites, not complete ordinary A-to-C cold recovery",
}


def save():
    temporary = manifest_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(manifest, indent=2) + "\n")
    temporary.replace(manifest_path)


def git(*arguments):
    return subprocess.check_output(["git", *arguments], cwd=repo, env=environment, text=True).strip()


def snapshot():
    return {"sha": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "status": git("status", "--porcelain=v1", "--untracked-files=all")}


def bootstrap(command):
    with (records / "bootstrap.log").open("ab") as log:
        subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT, check=True)


def run_stage(name, command, stage_environment=None):
    manifest["status"] = name
    manifest["stages"][name] = {"status": "running", "command": command,
                                "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
    save()
    start = time.monotonic()
    with (records / (name + "-launch.log")).open("xb") as log:
        result = subprocess.run(command, cwd=repo, env=stage_environment or environment,
                                stdout=log, stderr=subprocess.STDOUT)
    manifest["stages"][name].update(status="completed", exit_code=result.returncode,
                                   elapsed_seconds=time.monotonic() - start)
    save()
    return result.returncode


def recorded(name, command):
    return ["/usr/bin/python3", recorder, str(repo), str(records / name), *command]


def read_test_report(name):
    result = json.loads((records / name / "run.json").read_text())
    reports = result.get("junit", [])
    if not reports:
        return result, None
    report = ET.parse(reports[0]["path"])
    cases = list(report.iter("testcase"))
    observed = [{"name": case.attrib["name"], "class": case.attrib.get("classname"),
                 "failed": case.find("failure") is not None or case.find("error") is not None,
                 "skipped": case.find("skipped") is not None} for case in cases]
    (records / (name + "-cases.json")).write_text(json.dumps(observed, indent=2) + "\n")
    return result, observed


def restore_ownership():
    paths = [path for path in (target, records, repo / "codex-rs/target/nextest") if path.exists()]
    if paths:
        subprocess.run(["sudo", "-n", "chown", "-R", f"{original_uid}:{original_gid}",
                        *map(str, paths)], env=environment, check=True)


save()
try:
    assert original_uid != 0, "ordinary suite requires the actual unprivileged account"
    bundle = Path(plan["bundle"])
    assert hashlib.sha256(bundle.read_bytes()).hexdigest() == plan["bundle_sha256"]
    assert not repo.exists(), "a new isolated checkout is required"
    bootstrap(["git", "clone", "--shared", "--no-checkout", plan["object_source"], str(repo)])
    bootstrap(["git", "-C", str(repo), "bundle", "verify", str(bundle)])
    bootstrap(["git", "-C", str(repo), "fetch", str(bundle), "HEAD"])
    bootstrap(["git", "-C", str(repo), "checkout", "--detach", plan["source"]])
    manifest["before"] = snapshot()
    assert manifest["before"] == {"sha": plan["source"], "tree": plan["tree"], "status": ""}
    save()
    helper = ["python3", "scripts/hepta_cell_test_helpers.py", "--package",
              "codex-hepta-infer-worker-host", "--output-dir", str(records / "helpers")]
    if run_stage("helpers-build", recorded("helpers-build", helper)):
        raise RuntimeError("actual same-source helper build failed")
    helper_manifest = json.loads((records / "helpers/manifest.json").read_text())
    assert helper_manifest["complete"] and helper_manifest["source_sha"] == plan["source"]
    environment.update(json.loads((records / "helpers/env.json").read_text()))
    arguments = ["just", "test", "--locked", "--offline"]
    for package in plan["ordinary_packages"]:
        arguments.extend(["-p", package])
    arguments.extend(["--lib", "--retries", "0", "--no-tests", "fail", "--test-threads", "2",
                      "--success-output", "final", "--failure-output", "final"])
    ordinary_exit = run_stage("ordinary", recorded("ordinary", arguments))
    ordinary_record, ordinary_cases = read_test_report("ordinary")
    assert ordinary_record["uid"] == original_uid and ordinary_record["source_unchanged"]
    if ordinary_cases is None:
        raise RuntimeError("ordinary compilation or execution produced no fresh JUnit; Root suite not run")
    manifest["ordinary_counts"] = {
        "cases": len(ordinary_cases), "failed": sum(case["failed"] for case in ordinary_cases),
        "skipped": sum(case["skipped"] for case in ordinary_cases), "exit_code": ordinary_exit,
    }
    setup = (
        "import os,subprocess,sys; from pathlib import Path; assert os.geteuid()==0; "
        "p=Path(sys.argv[1]); p.mkdir(mode=0o700); "
        "[(p/n).mkdir(mode=0o700) for n in ('source','bind','checkpoints','witness-source','witness-bind')]; "
        "subprocess.run(['mount','--bind',str(p/'source'),str(p/'bind')],check=True); "
        "subprocess.run(['mount','--bind',str(p/'witness-source'),str(p/'witness-bind')],check=True); "
        "print('Root fixture uid='+str(os.geteuid())+' path='+str(p),flush=True)"
    )
    if run_stage("root-setup", ["sudo", "-n", "/usr/bin/python3", "-c", setup, str(root_directory)]):
        raise RuntimeError("actual UID0 protected bind fixture setup failed")
    names = ("PATH", "SOURCE_SHA", "TESTED_SHA", "HEPTA_CI_LANE", "PYTHONDONTWRITEBYTECODE",
             "CARGO_INCREMENTAL", "CARGO_BUILD_JOBS", "CARGO_PROFILE_TEST_DEBUG", "CARGO_PROFILE_DEV_DEBUG",
             "CARGO_TARGET_DIR", "RUSTY_V8_ARCHIVE", "RUSTY_V8_SRC_BINDING_PATH", "LIBCLANG_PATH",
             "RUSTUP_TOOLCHAIN", "BINDGEN_EXTRA_CLANG_ARGS")
    root_environment = {key: environment[key] for key in names if key in environment}
    root_environment.update(
        CARGO_HOME=environment.get("CARGO_HOME", "/home/qq/.cargo"),
        RUSTUP_HOME=environment.get("RUSTUP_HOME", "/home/qq/.rustup"),
        GIT_CONFIG_COUNT="1", GIT_CONFIG_KEY_0="safe.directory", GIT_CONFIG_VALUE_0=str(repo),
        HEPTA_HOST_AUTHORITY_QUALIFICATION_STATE_PARENT=str(root_directory / "bind"),
        HEPTA_HOST_AUTHORITY_QUALIFICATION_SOURCE=str(root_directory / "source"),
        HEPTA_CHECKPOINT_TEST_ROOT=str(root_directory / "checkpoints"),
        HEPTA_Q24_FACTORY_WITNESS_BIND=str(root_directory / "witness-bind"),
        HEPTA_Q24_FACTORY_WITNESS_SOURCE=str(root_directory / "witness-source"),
    )
    root_environment.update(json.loads((records / "helpers/env.json").read_text()))
    root_arguments = ["just", "test", "--locked", "--offline", "-p", "codex-hepta-agentd", "-p",
                      "codex-hepta-contracts", "--lib", "--run-ignored", "only", "-E",
                      " | ".join("test(=" + name + ")" for name in plan["parents"]),
                      "--retries", "0", "--no-tests", "fail", "--test-threads", "1",
                      "--success-output", "final", "--failure-output", "final"]
    check_uid = "import os,runpy,sys; assert os.geteuid()==0; print('Root test uid=0',flush=True); runpy.run_path(sys.argv.pop(1),run_name='__main__')"
    root_command = ["sudo", "-n", "env", "-i", *[key + "=" + value for key, value in sorted(root_environment.items())],
                    "/usr/bin/python3", "-c", check_uid, recorder, str(repo), str(records / "root"), *root_arguments]
    root_exit = run_stage("root", root_command)
    restore_ownership()
    root_record, root_cases = read_test_report("root")
    assert root_record["uid"] == 0 and root_record["source_unchanged"]
    assert root_cases is not None, "Root suite produced no fresh JUnit"
    coverage = {"expected": plan["parents"], "observed": [case["name"] for case in root_cases],
                "unskipped": [case["name"] for case in root_cases if not case["skipped"]]}
    coverage["exact"] = sorted(coverage["expected"]) == sorted(coverage["observed"]) == sorted(coverage["unskipped"])
    (records / "root-parent-coverage.json").write_text(json.dumps(coverage, indent=2) + "\n")
    manifest["root_counts"] = {"cases": len(root_cases), "failed": sum(case["failed"] for case in root_cases),
                               "skipped": sum(case["skipped"] for case in root_cases), "exit_code": root_exit,
                               "exact_parent_coverage": coverage["exact"]}
    if run_stage("helpers-verify", recorded("helpers-verify", [*helper, "--verify-only"])):
        raise RuntimeError("same-source pinned helper verification failed")
    manifest["after"] = snapshot()
    assert manifest["after"] == manifest["before"]
    manifest["status"] = "passed" if not ordinary_exit and not root_exit and coverage["exact"] else "failed"
except BaseException as error:
    manifest["status"] = "failed"
    manifest["error"] = f"{type(error).__name__}: {error}"
    (records / "driver-error.log").write_text(traceback.format_exc())
finally:
    try:
        restore_ownership()
        for name in ("witness-bind", "bind"):
            path = root_directory / name
            result = subprocess.run(["sudo", "-n", "mountpoint", "-q", str(path)], env=environment)
            if result.returncode == 0:
                subprocess.run(["sudo", "-n", "umount", str(path)], env=environment, check=True)
        if repo.exists():
            manifest["final"] = snapshot()
    except BaseException as error:
        manifest["cleanup_error"] = f"{type(error).__name__}: {error}"
        manifest["status"] = "failed"
    manifest["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
print(json.dumps(manifest), flush=True)
raise SystemExit(0 if manifest["status"] == "passed" else 1)
