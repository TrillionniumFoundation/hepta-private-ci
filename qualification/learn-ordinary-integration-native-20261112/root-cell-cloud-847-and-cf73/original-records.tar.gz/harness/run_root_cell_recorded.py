#!/usr/bin/env python3
"""Record one frozen, ordinary-UID Neuron test invocation without editing source."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

root = Path(sys.argv[1]).resolve()
expected_commit = sys.argv[2]
out = Path(sys.argv[3]).resolve()
out.mkdir(parents=True, exist_ok=True)
target = Path("/workspace/scratch/ff41dfc0f7bf/target-cloud-native")
def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()
def snapshot():
    return {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"), "status": git("status", "--porcelain=v1")}
command = ["just", "test", "-p", "codex-hepta-neuron", "--lib", "--locked", "-E", "test(original_cell_data_) | test(published_feature_readonly_)", "--retries", "0", "--no-tests", "fail", "--test-threads", "2", "--success-output", "final", "--failure-output", "final"]
env = {**os.environ, "CARGO_TARGET_DIR": str(target), "CARGO_BUILD_JOBS": "2", "PYTHONDONTWRITEBYTECODE": "1"}
expected = []
for path in (root / "codex-rs/hepta-neuron/src").glob("*.rs"):
    expected.extend(re.findall(r"^fn ((?:original_cell_data_|published_feature_readonly_)\w*)\(", path.read_text(), re.M))
assert len(expected) == 9
record = {"state": "running", "source": str(root), "before": snapshot(), "executor": {"hostname": platform.node(), "uid": os.geteuid(), "platform": platform.platform(), "python": sys.executable}, "command": command, "target": str(target), "expected_case_suffixes": sorted(expected), "started_at": stamp(), "harness_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "tools": {name: subprocess.check_output(args, text=True).strip() for name, args in {"rustc": ["rustc", "--version"], "cargo": ["cargo", "--version"], "nextest": ["cargo", "nextest", "--version"], "just": ["just", "--version"]}.items()}}
assert record["before"]["commit"] == expected_commit and record["before"]["status"] == ""
junit = target / "nextest/local/junit.xml"
assert not junit.exists(), "Caller must preserve and relocate any prior report before this invocation"
runpath = out / "run.json"
runpath.write_text(json.dumps(record, indent=2) + "\n")
log = out / "command.log"
started = time.monotonic()
with log.open("wb") as stream:
    process = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
record.update({"state": "completed", "exit_code": process.returncode, "elapsed_seconds": time.monotonic() - started, "finished_at": stamp(), "after": snapshot()})
record["source_unchanged"] = record["before"] == record["after"]
raw = log.read_bytes()
record["log"] = {"path": log.name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
record["junit"] = None
if junit.exists():
    raw_junit = junit.read_bytes()
    shutil.copyfile(junit, out / "junit.xml")
    tree = ET.fromstring(raw_junit)
    cases = [{"name": case.attrib.get("name"), "classname": case.attrib.get("classname"), "failure": case.find("failure") is not None, "error": case.find("error") is not None, "skipped": case.find("skipped") is not None} for case in tree.iter("testcase")]
    record["junit"] = {"path": "junit.xml", "bytes": len(raw_junit), "sha256": hashlib.sha256(raw_junit).hexdigest(), "cases": cases, "expected_set_matches": sorted(case["name"].rsplit("::", 1)[-1] for case in cases) == sorted(expected)}
runpath.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
print(raw.decode(errors="replace")[-16000:])
sys.exit(process.returncode if process.returncode else (0 if record["source_unchanged"] and record["junit"] and record["junit"]["expected_set_matches"] and not any(case["skipped"] or case["failure"] or case["error"] for case in record["junit"]["cases"]) else 1))
