import datetime, hashlib, json, pathlib, subprocess, sys, time
root=pathlib.Path("/workspace/scratch/ff41dfc0f7bf/hepta-task-readback-typed-cloud")
records=pathlib.Path("/workspace/scratch/ff41dfc0f7bf/tooling/validation/task-readback-typed")
sys.path.insert(0,str(root/"scripts"))
import verify_hepta_callers as v
def git(*a): return subprocess.check_output(["git",*a],cwd=root,text=True).strip()
start=time.monotonic()
meta={"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"sha":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"before_status":git("status","--porcelain=v1"),"scope":"one existing boundary, all repository Rust files; original and positive/negative source controls; unchanged checker"}
manifest=v._load_manifest(root/"CALLERS.toml")
boundary=next(b for b in v._boundary_rows(manifest) if b.identifier=="q24_task_original_ledger_readback")
ignored=v._string_tuple(manifest,"ignored_path_fragments")
files=v._source_files(root,v._string_tuple(manifest,"source_roots"))
index={p.relative_to(root).as_posix():v._strip_cfg_test_items(v._strip_rust_non_code(p.read_text())) for p in files}
rel="codex-rs/hepta-agentd/src/state_circuit_task.rs"
positive=index[rel]
original=subprocess.check_output(["git","show","2420fb01d7d26d7c851f48dd24ad2f9385272259:"+rel],cwd=root,text=True)
original=v._strip_cfg_test_items(v._strip_rust_non_code(original))
results=[]
for label,code,expected in [("original",original,"unresolved possible OriginalCellQ24TaskLedgerProducerV1::readback receiver"),("explicit_circuit",positive,None),("injected_ledger_call",positive.replace("crate::CircuitTaskHandleV1::readback(handle, request, record.clone())","crate::OriginalCellQ24TaskLedgerProducerV1::readback(handle, request, record.clone())"),"caller set mismatch")]:
    candidate=dict(index);candidate[rel]=code
    try:
        receipt=v._verify_boundary(root,boundary,candidate,ignored)
    except v.VerificationFailure as error:
        if expected is None or expected not in str(error): raise
        results.append({"case":label,"expected_rejected":True,"error":str(error)})
    else:
        if expected is not None: raise AssertionError(label+" unexpectedly accepted")
        results.append({"case":label,"receipt":receipt})
meta.update(state="completed",elapsed_seconds=time.monotonic()-start,rust_files_scanned=len(files),results=results,after_status=git("status","--porcelain=v1"),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
assert not meta["before_status"] and not meta["after_status"]
(records/"final-run.json").write_text(json.dumps(meta,indent=2)+"\n")
print(json.dumps(meta,indent=2))
