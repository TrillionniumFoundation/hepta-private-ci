import datetime, hashlib, json, pathlib, subprocess, sys, time
root=pathlib.Path("/workspace/scratch/ff41dfc0f7bf/hepta-task-readback-typed-cloud")
records=pathlib.Path("/workspace/scratch/ff41dfc0f7bf/tooling/validation/task-readback-typed")
sys.path.insert(0,str(root/"scripts"))
import verify_hepta_callers as v
def git(*a): return subprocess.check_output(["git",*a],cwd=root,text=True).strip()
start=time.monotonic()
meta={"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"sha":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"before_status":git("status","--porcelain=v1"),"scope":"one existing boundary, all repository Rust files; original and positive/negative source controls; unchanged checker"}
manifest=v._load_manifest(root/"CALLERS.toml")
boundary=next(b for b in v._boundary_rows(manifest) if b.identifier=="q24_task_original_ledger_readback")
ignored=v._string_tuple(manifest,"ignored_path_fragments")
files=v._source_files(root,v._string_tuple(manifest,"source_roots"))
index={p.relative_to(root).as_posix():v._strip_cfg_test_items(v._strip_rust_non_code(p.read_text())) for p in files}
rel="codex-rs/hepta-agentd/src/state_circuit_task.rs"
positive=index[rel]
original=subprocess.check_output(["git","show","HEAD^:"+rel],cwd=root,text=True)
original=v._strip_cfg_test_items(v._strip_rust_non_code(original))
errors=[]
fields=v.authority_fields(index,boundary.receiver_type)
for relative,code in index.items():
 if relative==boundary.definition_path or v._is_ignored(relative,ignored): continue
 try: v.has_authority_call(code,boundary.receiver_type,"readback",fields)
 except v.UnresolvedTypedReceiver as error: errors.append({"path":relative,"error":str(error)})
meta.update(state="completed",elapsed_seconds=time.monotonic()-start,rust_files_scanned=len(files),unresolved=errors,after_status=git("status","--porcelain=v1"),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(records/"enumeration.json").write_text(json.dumps(meta,indent=2)+"\n")
print(json.dumps(meta,indent=2))
