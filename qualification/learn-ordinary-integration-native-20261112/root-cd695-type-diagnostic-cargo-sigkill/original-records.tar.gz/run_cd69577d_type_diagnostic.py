import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time

base = Path('/workspace/scratch/ff41dfc0f7bf')
source = base / 'hepta-check-cd69577d-cloud'
records = base / 'tooling/validation/integration-cd69577d-cloud-type-diagnostic'
records.mkdir()
environment = {**os.environ, 'CARGO_TARGET_DIR': str(base / 'target-cloud-native'),
               'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0',
               'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0'}

def snapshot():
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=source, text=True).strip()
    return {'sha': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain=v1', '--untracked-files=all')}

command = ['cargo', 'check', '--locked', '--offline', '--lib', '--bins',
           '--message-format=json-render-diagnostics', '-p', 'codex-hepta-agentd',
           '-p', 'codex-hepta-agent-protocol', '-p', 'codex-hepta-learning-ledger']
record = {'before': snapshot(), 'source_path': str(source), 'uid': os.geteuid(),
          'executor': platform.node(), 'scope': 'static type diagnostic only; not a native test or qualification gate',
          'state': 'running', 'command': command,
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'environment': {k: environment[k] for k in ('CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
          'CARGO_INCREMENTAL', 'CARGO_HOME', 'RUSTUP_HOME', 'RUSTUP_TOOLCHAIN',
          'BINDGEN_EXTRA_CLANG_ARGS', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG',
          'RUSTFLAGS') if k in environment}}
assert record['before'] == {'sha': 'cd69577d08cd90937f70ebd8719b44a24b1ee91f',
                           'tree': '5e60c42aa19d7150bcc8d117ca5479a65a083085', 'status': ''}
(records / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
with (records / 'compiler.jsonl').open('xb') as stdout, (records / 'stderr.log').open('xb') as stderr:
    result = subprocess.run(command, cwd=source / 'codex-rs', env=environment,
                            stdout=stdout, stderr=stderr)
record.update(state='completed', exit_code=result.returncode,
              elapsed_seconds=time.monotonic() - started, after=snapshot(),
              finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              tests=0, junit=[])
record['source_unchanged'] = record['before'] == record['after']
record['files'] = [{'path': p.name, 'bytes': p.stat().st_size,
                    'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                   for p in sorted(records.iterdir()) if p.is_file() and p.name != 'run.json']
(records / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
raise SystemExit(result.returncode if record['source_unchanged'] else 1)
