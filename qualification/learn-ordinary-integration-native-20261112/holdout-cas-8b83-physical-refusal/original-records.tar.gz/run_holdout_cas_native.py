import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET

source = Path('/workspace/scratch/ff41dfc0f7bf/hepta-independent-b-provider-cloud')
out = Path('/workspace/scratch/ff41dfc0f7bf/tooling/validation/holdout-cas-8b83dbc8-native')
target = Path('/workspace/scratch/ff41dfc0f7bf/target-cloud-native')
out.mkdir()

def snapshot():
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=source, text=True).strip()
    return {'sha': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain=v1', '--untracked-files=all')}

command = ['just', 'test', '--locked', '--offline', '-p', 'codex-hepta-intelligence-eval',
           '--lib', '-E', 'test(fenced_holdout_file::tests::)', '--retries', '0',
           '--no-tests', 'fail', '--test-threads', '2', '--success-output', 'final',
           '--failure-output', 'final']
env = {**os.environ, 'CARGO_TARGET_DIR': str(target), 'CARGO_BUILD_JOBS': '1',
       'SOURCE_SHA': '8b83dbc88d2623c026c62509897c716e151517ae',
       'TESTED_SHA': '8b83dbc88d2623c026c62509897c716e151517ae',
       'HEPTA_CI_LANE': 'physical-holdout-cas-native'}
record = {'before': snapshot(), 'scope': 'actual locked-file CAS tests; not independent B efficacy, Root cold refusal or fullchain',
          'command': command, 'uid': os.geteuid(), 'executor': platform.node(),
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'state': 'running', 'target': str(target),
          'environment': {key: env[key] for key in ('CARGO_HOME', 'RUSTUP_HOME', 'RUSTUP_TOOLCHAIN',
          'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'BINDGEN_EXTRA_CLANG_ARGS', 'CARGO_PROFILE_DEV_DEBUG',
          'CARGO_PROFILE_TEST_DEBUG', 'RUSTFLAGS') if key in env}}
assert record['before'] == {'sha': env['SOURCE_SHA'], 'tree': '2966b8bc42884f2f8b5ca701cc53364b1435c9f1', 'status': ''}
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
began = time.time()
monotonic = time.monotonic()
log = out / 'native.log'
with log.open('xb') as output:
    result = subprocess.run(command, cwd=source, env=env, stdout=output, stderr=subprocess.STDOUT)
record.update(state='completed', exit_code=result.returncode, elapsed_seconds=time.monotonic() - monotonic,
              finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), after=snapshot())
record['source_unchanged'] = record['before'] == record['after']
record['log'] = {'bytes': log.stat().st_size, 'sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
record['junit'] = []
for path in (source / 'codex-rs/target/nextest/local/junit.xml', target / 'nextest/local/junit.xml'):
    if path.exists() and path.stat().st_mtime >= began:
        saved = out / f'junit-{len(record["junit"])}.xml'
        shutil.copyfile(path, saved)
        cases = [{'name': case.attrib['name'], 'class': case.attrib.get('classname'),
                  'failed': case.find('failure') is not None or case.find('error') is not None,
                  'skipped': case.find('skipped') is not None} for case in ET.parse(saved).iter('testcase')]
        record['junit'].append({'path': str(saved), 'sha256': hashlib.sha256(saved.read_bytes()).hexdigest(),
                                'bytes': saved.stat().st_size, 'cases': cases})
record['qualified'] = result.returncode == 0 and record['source_unchanged'] and len(record['junit']) == 1
if record['qualified']:
    cases = record['junit'][0]['cases']
    record['qualified'] = len(cases) == 9 and not any(case['failed'] or case['skipped'] for case in cases)
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if record['qualified'] else 1)
