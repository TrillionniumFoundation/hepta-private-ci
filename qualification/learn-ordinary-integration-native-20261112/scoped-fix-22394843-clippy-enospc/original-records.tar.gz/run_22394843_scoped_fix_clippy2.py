import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time

base = Path('/workspace/scratch/ff41dfc0f7bf')
source = base / 'hepta-fix-22394843-cloud'
records = base / 'tooling/validation/integration-22394843-cloud-scoped-fix-clippy2'
records.mkdir()
environment = {**os.environ, 'CARGO_TARGET_DIR': str(base / 'target-cloud-native'),
               'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0'}
assert not any(k.startswith('CARGO_PROFILE_') for k in environment), 'Use original repository profiles'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=source)

def snapshot(label):
    tracked = git('ls-files', '-z').split(b'\0')
    manifest = []
    for relative in tracked:
        if not relative:
            continue
        p = source / os.fsdecode(relative)
        if p.is_symlink():
            data = os.fsencode(os.readlink(p))
        else:
            data = p.read_bytes()
        manifest.append({'path': os.fsdecode(relative), 'bytes': len(data),
                         'sha256': hashlib.sha256(data).hexdigest()})
    raw = (json.dumps(manifest, separators=(',', ':')) + '\n').encode()
    (records / (label + '-source.json')).write_bytes(raw)
    return {'sha': git('rev-parse', 'HEAD').decode().strip(),
            'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'status': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
            'tracked_files': len(manifest), 'source_sha256': hashlib.sha256(raw).hexdigest()}

command = ['just', 'fix', '--locked', '--offline', '-p', 'codex-hepta-agentd',
           '-p', 'codex-hepta-agent-protocol', '-p', 'codex-hepta-learning-ledger']
before = snapshot('before')
assert before['sha'] == '22394843214c0480d56a8470bd819bb0d7b43140'
assert before['tree'] == 'c0ab9277feff37e3282a2b9a2959b82cb3b640ae' and before['status'] == ''
record = {'before': before, 'source_path': str(source), 'uid': os.geteuid(),
          'executor': platform.node(), 'scope': 'Repository scoped clippy --fix --tests; static diagnostic, no native tests',
          'state': 'running', 'command': command,
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'environment': {k: environment[k] for k in ('CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
          'CARGO_INCREMENTAL', 'CARGO_HOME', 'RUSTUP_HOME', 'RUSTUP_TOOLCHAIN',
          'BINDGEN_EXTRA_CLANG_ARGS', 'RUSTFLAGS') if k in environment},
          'profile': 'Original workspace dev/test configuration; no CARGO_PROFILE override',
          'harness_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(records / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
with (records / 'stdout.log').open('xb') as stdout, (records / 'stderr.log').open('xb') as stderr:
    result = subprocess.run(command, cwd=source / 'codex-rs', env=environment,
                            stdout=stdout, stderr=stderr)
record.update(state='completed', exit_code=result.returncode,
              elapsed_seconds=time.monotonic() - started, after=snapshot('after'),
              finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              tests=0, junit=[])
(records / 'automatic-fixes.patch').write_bytes(git('diff', '--binary', 'HEAD'))
record['source_unchanged'] = record['before'] == record['after']
record['files'] = [{'path': p.name, 'bytes': p.stat().st_size,
                    'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                   for p in sorted(records.iterdir()) if p.is_file() and p.name != 'run.json']
(records / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
raise SystemExit(result.returncode)
