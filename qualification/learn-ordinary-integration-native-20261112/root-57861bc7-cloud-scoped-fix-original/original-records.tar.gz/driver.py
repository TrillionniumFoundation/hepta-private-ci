import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import time

repo = pathlib.Path('/dev/shm/hepta-root-compile-57861-ff41')
out = pathlib.Path(__file__).parent
env = dict(os.environ)
for key in list(env):
    if key.startswith('CARGO_PROFILE_'):
        del env[key]
env.update(RUSTUP_TOOLCHAIN='1.96.0', CARGO_TARGET_DIR='/workspace/scratch/ff41dfc0f7bf/target-cloud-native', CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0')
command = ['just', 'fix', '--locked', '--offline', '-p', 'codex-hepta-agentd', '-p', 'codex-hepta-agent-protocol', '-p', 'codex-hepta-learning-ledger']

def capture():
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=repo).decode().strip()
    digest = hashlib.sha256()
    count = 0
    for name in subprocess.check_output(['git', 'ls-files', '-z'], cwd=repo).split(b'\0'):
        if not name:
            continue
        path = repo / name.decode()
        if path.is_file():
            digest.update(name + b'\0' + hashlib.sha256(path.read_bytes()).digest())
            count += 1
    return dict(head=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'), status=git('status', '--porcelain=v1'), tracked_files=count, tracked_sha256=digest.hexdigest())

before = capture()
assert before['head'] == '57861bc757a217686d5974d46529aa5ac91ee812'
assert before['tree'] == '3666bc38a5641c0ea4a2aa4b4252e11d79b23b9c'
assert not before['status']
result = dict(status='running', before=before, uid=os.getuid(), command=command, cwd=str(repo/'codex-rs'), started=datetime.datetime.now(datetime.timezone.utc).isoformat(), profile_overrides=[], build_jobs=1, scope='Actual scoped just fix, including test compilation. No test execution, JUnit, Root custody or whole-chain qualification.')
record = out/'result.json'
record.write_text(json.dumps(result, indent=2)+'\n')
start = time.monotonic()
try:
    with (out/'stdout.log').open('wb') as stdout, (out/'stderr.log').open('wb') as stderr:
        process = subprocess.run(command, cwd=repo/'codex-rs', env=env, stdout=stdout, stderr=stderr)
    result.update(status='completed', exit_code=process.returncode, after=capture(), elapsed=time.monotonic()-start)
    result['source_unchanged'] = result['before'] == result['after']
    (out/'fix.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=repo))
except BaseException as error:
    result.update(status='failed', error=repr(error), elapsed=time.monotonic()-start, after=capture())
finally:
    result['finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['logs'] = {name: dict(bytes=(out/name).stat().st_size, sha256=hashlib.sha256((out/name).read_bytes()).hexdigest()) for name in ['stdout.log', 'stderr.log'] if (out/name).exists()}
    record.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
