import datetime
import fcntl
import json
import os
from pathlib import Path
import shutil
import time

base = Path('/workspace/scratch/ff41dfc0f7bf')
root = base / 'target-cloud-native/debug/incremental'
output = base / 'tooling/validation/completed-a512-incremental-retirement.json'
assert not output.exists()
names = {'cargo', 'rustc', 'rust-lld', 'ld.lld', 'cc', 'clang'}
active = []
for proc in Path('/proc').iterdir():
    if proc.name.isdigit():
        try:
            if (proc / 'comm').read_text().strip() in names:
                active.append(int(proc.name))
        except OSError:
            pass
assert not active, active
record = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'root': str(root), 'active_native_processes_observed': active,
          'pre_free': shutil.disk_usage(base).free,
          'scope': 'completed original incremental sessions only; preserve working sessions, dependencies, source and records',
          'removed': [], 'skipped': []}
cutoff = time.time() - 60
for package in sorted(root.iterdir()):
    if package.is_symlink() or not package.is_dir():
        continue
    for session in sorted(package.iterdir()):
        if session.is_symlink() or not session.is_dir() or session.name.endswith('-working'):
            continue
        prefix = session.name.rsplit('-', 1)[0]
        lock = package / (prefix + '.lock')
        if not lock.is_file() or lock.is_symlink():
            record['skipped'].append({'path': str(session), 'reason': 'no original lock'})
            continue
        try:
            with lock.open('rb') as held:
                fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
                entries = list(session.rglob('*'))
                if any(path.is_symlink() for path in entries):
                    raise RuntimeError('symlink in session')
                files = [path for path in entries if path.is_file()]
                latest = max((path.stat().st_mtime for path in files), default=session.stat().st_mtime)
                if latest > cutoff or (package / (prefix + '-working')).exists():
                    record['skipped'].append({'path': str(session), 'reason': 'recent or working session'})
                    continue
                row = {'path': str(session), 'files': len(files),
                       'bytes': sum(path.stat().st_size for path in files),
                       'latest_mtime': latest, 'original_lock_acquired': True}
                shutil.rmtree(session)
                record['removed'].append(row)
        except BlockingIOError:
            record['skipped'].append({'path': str(session), 'reason': 'original session lock busy'})
record.update(finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              removed_bytes=sum(row['bytes'] for row in record['removed']),
              post_free=shutil.disk_usage(base).free)
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key not in ('removed', 'skipped')}, indent=2))
print('removed_sessions', len(record['removed']), 'skipped_sessions', len(record['skipped']))
