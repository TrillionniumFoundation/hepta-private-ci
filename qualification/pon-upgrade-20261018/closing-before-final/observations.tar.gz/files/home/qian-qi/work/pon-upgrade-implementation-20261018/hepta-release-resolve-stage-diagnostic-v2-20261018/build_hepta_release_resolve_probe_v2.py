#!/usr/bin/env python3
"""Link the timing helper to exact native Cargo compiler-artifact rlibs.

Input is the complete original successful cached Cargo JSON build inventory.
The actual hepta-supervisord executable anchors the runtime profile and target
dependency directory. Build-profile library variants stay in the receipt but
cannot masquerade as that runtime. Any remaining ambiguity is a hard failure.
No Cargo manifest, dependency resolution, product API or runtime timeout changes.
This builds the diagnostic only; it does not execute it.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def select_runtime_artifacts(events):
    needed = {"codex_hepta_contracts", "codex_hepta_paths", "codex_hepta_fleet",
              "codex_hepta_supervisor", "serde_json"}
    finished = [event for event in events if event.get("reason") == "build-finished"]
    if len(finished) != 1 or finished[0].get("success") is not True:
        raise RuntimeError("require one successful original Cargo build")
    runtimes = [event for event in events
                if event.get("reason") == "compiler-artifact"
                and event.get("target", {}).get("name") == "hepta-supervisord"
                and event.get("target", {}).get("kind") == ["bin"]]
    if len(runtimes) != 1:
        raise RuntimeError("require exactly one original hepta-supervisord binary target")
    event = runtimes[0]
    profile = event.get("profile")
    if not isinstance(profile, dict) or profile.get("test") is not False or profile.get("opt_level") != "3":
        raise RuntimeError("require the original non-test optimized Supervisor runtime profile")
    executable = event.get("executable")
    if not isinstance(executable, str):
        raise RuntimeError("runtime target has no actual executable")
    binary = Path(executable)
    if not binary.is_absolute() or executable not in event.get("filenames", []):
        raise RuntimeError("runtime executable must be an absolute original artifact filename")
    dependency_directory = binary.parent / "deps"
    runtime = {"path": executable, "package_id": event["package_id"],
               "features": event.get("features"), "profile": profile,
               "target": event["target"], "dependency_directory": str(dependency_directory)}
    candidates = {name: {} for name in needed}
    for event in events:
        target = event.get("target", {})
        name = target.get("name")
        if event.get("reason") != "compiler-artifact" or name not in needed:
            continue
        for filename in event.get("filenames", []):
            path = Path(filename)
            if path.suffix != ".rlib":
                continue
            reasons = []
            if target.get("kind") != ["lib"]:
                reasons.append("not-original-library-target")
            if event.get("profile") != profile:
                reasons.append("profile-differs-from-runtime")
            if not path.is_absolute() or path.parent != dependency_directory:
                reasons.append("target-dependency-directory-differs")
            if name == "codex_hepta_supervisor" and (
                event["package_id"] != runtime["package_id"]
                or event.get("features") != runtime["features"]
            ):
                reasons.append("supervisor-package-or-features-differ-from-runtime")
            item = {"path": str(path), "package_id": event["package_id"],
                    "features": event.get("features"), "profile": event.get("profile"),
                    "target": target, "excluded_reasons": reasons}
            previous = candidates[name].get(str(path))
            if previous is not None and previous != item:
                raise RuntimeError("one native artifact path has conflicting Cargo metadata")
            candidates[name][str(path)] = item
    eligible = {name: [item for item in options.values() if not item["excluded_reasons"]]
                for name, options in candidates.items()}
    counts = {name: len(items) for name, items in eligible.items()}
    if any(count != 1 for count in counts.values()):
        raise RuntimeError("require exactly one original rlib per runtime target/profile: "
                           + json.dumps(counts, sort_keys=True))
    selected = {name: items[0] for name, items in eligible.items()}
    return runtime, selected, {name: list(items.values()) for name, items in candidates.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rustc", type=Path, required=True)
    parser.add_argument("--toolchain", default="1.96.0")
    args = parser.parse_args()
    events = []
    for line in args.inventory.read_text().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    runtime, selected, candidates = select_runtime_artifacts(events)
    runtime_path = Path(runtime["path"])
    if not runtime_path.is_file():
        raise RuntimeError("original runtime executable is missing")
    runtime["sha256"] = sha(runtime_path)
    for artifact in selected.values():
        path = Path(artifact["path"])
        if not path.is_absolute() or not path.is_file():
            raise RuntimeError("actual referenced native rlib is missing")
        artifact["sha256"] = sha(path)
    if not args.source.is_absolute() or not args.rustc.is_absolute() or not args.output.is_absolute():
        raise RuntimeError("all executable/source/output paths must be absolute")
    receipt = Path(str(args.output) + ".build.json")
    stdout = Path(str(args.output) + ".build.stdout")
    stderr = Path(str(args.output) + ".build.stderr")
    if any(path.exists() for path in [args.output, receipt, stdout, stderr]):
        raise RuntimeError("diagnostic outputs must be new")
    command = [str(args.rustc), "+" + args.toolchain, "--edition=2024", "--crate-name",
               "hepta_release_resolve_probe", "-C", "opt-level=3", str(args.source), "-o", str(args.output)]
    for name, artifact in sorted(selected.items()):
        command += ["--extern", name + "=" + artifact["path"]]
    for directory in sorted({str(Path(item["path"]).parent) for item in selected.values()}):
        command += ["-L", "dependency=" + directory]
    with stdout.open("xb") as out, stderr.open("xb") as err:
        result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
    record = {"schema":"hepta-original-release-resolve-probe-build-v2", "command":command,
              "inventory_sha256":sha(args.inventory),"diagnostic_source_sha256":sha(args.source),
              "runtime_compiler_artifact":runtime,
              "all_relevant_compiler_artifacts":candidates,
              "linked_original_artifacts":selected,"exit_code":result.returncode,
              "stdout_sha256":sha(stdout),"stderr_sha256":sha(stderr),
              "diagnostic_binary_sha256":sha(args.output) if result.returncode == 0 else None,
              "product_source_modified":False,"native_diagnostic_executed":False}
    receipt.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if result.returncode:
        raise SystemExit(result.returncode)
    print(json.dumps({"binary":str(args.output),"build_receipt":str(receipt),
                      "sha256":record["diagnostic_binary_sha256"]}))


if __name__ == "__main__":
    main()
