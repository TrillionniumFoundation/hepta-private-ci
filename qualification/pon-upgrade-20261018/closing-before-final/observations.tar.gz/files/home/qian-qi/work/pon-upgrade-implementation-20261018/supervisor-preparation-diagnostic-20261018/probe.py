#!/usr/bin/env python3
"""Compare exact Supervisor builds at the original pre-CAS Start boundary.

This is a native diagnostic, not a startup/installation qualification.  Each
case copies a stopped Fleet byte-for-byte.  It sends a deliberately stale
state_digest through the real v2 Start RPC, which resolves/hashes the catalog
release before the original CAS rejects it.  No valid Start fence is sent.
Catalog arguments and every descriptor/signature remain unchanged.  Their
absolute paths are recorded but no Agentd process is authorized to use them.
Key inputs are limited to the two explicitly named, 32-byte public verifiers.
"""

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import stat
import struct
import subprocess
import sys
import time
import tomllib
import uuid

SCHEMA = 2
FRAME_LIMIT = 65_536
IO_SECONDS = 2.0


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(path, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def canonical(path):
    path = Path(path)
    require(path.is_absolute() and path == path.resolve(strict=True),
            f"not an existing absolute physical path: {path}")
    return path


def inventory(root):
    result = []
    for current, directories, files in os.walk(root, followlinks=False):
        for name in sorted(directories + files):
            path = Path(current) / name
            info = path.lstat()
            relative = path.relative_to(root).as_posix()
            require(not stat.S_ISLNK(info.st_mode), f"symlink not allowed: {relative}")
            if stat.S_ISSOCK(info.st_mode) and relative == "run/supervisor.sock":
                continue  # Only this obsolete daemon endpoint is not copied.
            if stat.S_ISDIR(info.st_mode):
                continue
            require(stat.S_ISREG(info.st_mode), f"special file not allowed: {relative}")
            result.append({"path": relative, "size": info.st_size,
                           "mode": stat.S_IMODE(info.st_mode), "sha256": digest(path)})
    return sorted(result, key=lambda item: item["path"])


def paths_in(value, pointer=""):
    if isinstance(value, dict):
        for key, item in value.items():
            yield from paths_in(item, pointer + "/" + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from paths_in(item, pointer + "/" + str(index))
    elif isinstance(value, str) and value.startswith("/"):
        yield {"field": pointer, "path": value}


def preflight(source, agent_id, release_id, expected_agentd_sha):
    fleet = canonical(source / "fleet")
    agents = fleet / "agents"
    require(sorted(path.name for path in agents.iterdir()) == [agent_id],
            "diagnostic requires the original single-Agent Fleet")
    agent = agents / agent_id
    manifest = tomllib.loads((agent / "agent.toml").read_text())
    require(manifest["agent_id"] == agent_id, "Agent manifest identity differs")
    workspace = canonical(manifest["workspace"]["root"])
    require(workspace.is_relative_to(source), "workspace escapes the retained study")
    run = agent / "run"
    require(not any(path.name.startswith("supervisor") for path in run.iterdir()),
            "an existing process, restart, signed-intent or transaction owner must not be copied")
    lifecycle_files = sorted(run.glob("lifecycle-*.json"))
    require(bool(lifecycle_files), "no original lifecycle history")
    lifecycle = json.loads(lifecycle_files[-1].read_bytes())
    require(lifecycle.get("generation") == 4 and lifecycle.get("lifecycle") == "stopped",
            "expected original stopped generation 4 before any actual Supervisor start")
    release_states = sorted((agent / "releases").glob("release-state-*.json"))
    require(bool(release_states), "no original release history")
    release_state = json.loads(release_states[-1].read_bytes())
    require(release_state.get("generation") == 0 and release_state.get("current") is None
            and release_state.get("previous") is None, "release state is already active")
    require(not any((agent / "matrix" / "secrets").iterdir()),
            "diagnostic does not copy a Matrix credential store")
    require(not (agent / "matrix" / "binding.json").exists(), "Matrix companion is configured")
    catalog = fleet / "releases" / release_id / "release.json"
    metadata = json.loads(catalog.read_bytes())
    require(metadata.get("schema_version") == 2 and metadata.get("release_id") == release_id
            and metadata.get("matrixd") is None, "unexpected catalog profile")
    program = metadata["agentd"]
    require(program["program_relative_path"] == "bin/hepta-agentd", "unexpected program path")
    executable = canonical(catalog.parent / program["program_relative_path"])
    require(program["program_sha256"] == expected_agentd_sha == digest(executable),
            "catalog executable differs from the original exact Agentd pin")
    require(program["program_size_bytes"] == executable.stat().st_size,
            "catalog executable size differs")
    args = program["args"]
    require(len(args) == 6 and args[0] == "--cognitive-bootstrap-descriptor"
            and args[2] == "--cognitive-bootstrap-descriptor-digest"
            and args[4] == "--automation-effect-host-file", "unexpected original catalog arguments")
    descriptor = canonical(args[1])
    host = canonical(args[5])
    require(descriptor.is_relative_to(source) and host.is_relative_to(source),
            "bootstrap/host path escapes the retained study")
    require(digest(descriptor) == args[3], "original descriptor host pin differs")
    descriptor_paths = list(paths_in(json.loads(descriptor.read_bytes())))
    require(all(Path(item["path"]).is_relative_to(source) for item in descriptor_paths),
            "descriptor contains an unexpected absolute path outside the study")
    return fleet, {"workspace": str(workspace), "catalog_sha256": digest(catalog),
                   "agentd_sha256": expected_agentd_sha, "agentd_size_bytes": executable.stat().st_size,
                   "unchanged_catalog_args": args, "descriptor_sha256": args[3],
                   "descriptor_absolute_paths": descriptor_paths,
                   "effect_host_absolute_paths": list(paths_in(json.loads(host.read_bytes()))),
                   "descriptor_and_host_execution": False}


class Rpc:
    def __init__(self, directory, endpoint, child):
        self.directory, self.endpoint, self.child = directory, endpoint, child
        self.sequence = 0

    def call(self, label, method):
        self.sequence += 1
        label = f"{self.sequence:03}-{label}"
        request = {"schema_version": SCHEMA, "request_id": self.sequence, "method": method}
        frame = json.dumps(request, separators=(",", ":")).encode() + b"\n"
        require(len(frame) <= FRAME_LIMIT, "request exceeds original frame bound")
        (self.directory / f"{label}-request.json").write_bytes(frame)
        started = time.monotonic_ns()
        observation = {"started_at_unix_ns": time.time_ns(), "io_timeout_seconds": IO_SECONDS,
                       "request_sha256": hashlib.sha256(frame).hexdigest(), "stages": {}}
        raw, response = bytearray(), None
        phase = "connect"
        phase_start = started
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as stream:
                stream.settimeout(IO_SECONDS)
                stream.connect(str(self.endpoint))
                peer_pid, peer_uid, peer_gid = struct.unpack("3i", stream.getsockopt(
                    socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("3i")))
                require(peer_pid == self.child.pid and peer_uid == os.getuid(), "unexpected Supervisor peer")
                observation["peer"] = {"pid": peer_pid, "uid": peer_uid, "gid": peer_gid}
                observation["stages"][phase] = time.monotonic_ns() - phase_start
                phase, phase_start = "write", time.monotonic_ns()
                stream.settimeout(IO_SECONDS)
                stream.sendall(frame)
                stream.shutdown(socket.SHUT_WR)
                observation["stages"][phase] = time.monotonic_ns() - phase_start
                phase, phase_start = "read", time.monotonic_ns()
                deadline = phase_start + int(IO_SECONDS * 1_000_000_000)
                while not raw.endswith(b"\n"):
                    remaining = (deadline - time.monotonic_ns()) / 1_000_000_000
                    if remaining <= 0:
                        raise TimeoutError("read budget expired")
                    stream.settimeout(remaining)
                    chunk = stream.recv(FRAME_LIMIT + 1 - len(raw))
                    if not chunk:
                        raise EOFError("server closed before one complete bounded response")
                    raw.extend(chunk)
                    require(len(raw) <= FRAME_LIMIT, "response exceeds original frame bound")
                response = json.loads(raw)
                require(response["schema_version"] == SCHEMA and response["request_id"] == self.sequence,
                        "response identity differs")
                observation["state"] = "response"
        except (OSError, EOFError) as error:
            observation.update(state="transport_failure", phase=phase, error_type=type(error).__name__,
                               error=str(error))
        finally:
            observation["stages"][phase] = time.monotonic_ns() - phase_start
            observation.update(finished_at_unix_ns=time.time_ns(),
                               monotonic_elapsed_ns=time.monotonic_ns() - started,
                               response_sha256=hashlib.sha256(raw).hexdigest())
            (self.directory / f"{label}-response.bin").write_bytes(raw)
            save(self.directory / f"{label}-execution.json", observation)
        return response, observation


def stopped(response):
    require(response is not None and response["payload"]["type"] == "agent", "missing actual Agent snapshot")
    status = {key: value for key, value in response["payload"].items() if key != "type"}
    require(status["lifecycle"] == "stopped" and status["lifecycle_generation"] == 4
            and status.get("control_revision") == 0 and not status["active"]
            and not status["release_change_pending"]
            and all(status[field] is None for field in ["process_id", "spawn_generation", "runtime_generation",
                                                        "current_release", "previous_release"])
            and not status["matrix"]["active"] and not status["matrix"]["configured"],
            "unexpected original owner state; no Start probe is allowed")
    return status


def run_case(label, binary, expected_sha, source_fleet, source_inventory, output, agent_id, release_id, keys):
    binary = canonical(binary)
    require(digest(binary) == expected_sha, f"{label} Supervisor differs from supplied source/build pin")
    directory = output / label
    directory.mkdir(mode=0o700)
    fleet = directory / "fleet"
    shutil.copytree(source_fleet, fleet, symlinks=False,
                    ignore=lambda base, names: ["supervisor.sock"] if Path(base) == source_fleet / "run"
                    and "supervisor.sock" in names else [])
    require(inventory(fleet) == source_inventory, "Fleet copy differs from original file bytes/modes")
    endpoint = fleet / "run" / "supervisor.sock"
    require(len(os.fsencode(endpoint)) < 108, "diagnostic Supervisor socket exceeds Linux sun_path")
    argv = [str(binary), "--fleet-root", str(fleet), "--grant-verifier-key", str(keys[0]),
            "--grant-signer-id", "operator", "--grant-signer-epoch", "4", "--h7-verifier-key", str(keys[1]),
            "--h7-signer-id", "h7-signer", "--h7-signer-epoch", "1"]
    result, child = None, None
    try:
        with (directory / "supervisord.log").open("xb") as log:
            child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log, stderr=log)
        rpc = Rpc(directory, endpoint, child)
        deadline = time.monotonic() + 15
        while True:
            require(child.poll() is None, "owned Supervisor exited during readiness")
            health, _ = rpc.call("health", {"type": "health"})
            if health and health["payload"].get("ready") is True:
                break
            require(time.monotonic() < deadline, "original 15-second daemon readiness budget expired")
            time.sleep(0.05)
        before = stopped(rpc.call("snapshot-before", {"type": "snapshot", "agent_id": agent_id})[0])
        fence = copy.deepcopy(before["control_fence"])
        original_digest = fence["state_digest"]
        require(len(original_digest) == 64 and all(c in "0123456789abcdef" for c in original_digest),
                "original fence digest is not canonical")
        fence["state_digest"] = ("0" if original_digest != "0" * 64 else "f") * 64
        require(fence["state_digest"] != original_digest, "probe must never send a matching fence")
        response, execution = rpc.call("start-stale-preparation", {"type": "start", "fence": fence,
                                                                  "release_id": release_id})
        after = stopped(rpc.call("snapshot-after", {"type": "snapshot", "agent_id": agent_id})[0])
        require(after == before, "stale Start changed original Supervisor state")
        if response is not None:
            require(response["payload"].get("type") == "error"
                    and response["payload"].get("code") == "stale_control_fence",
                    "unexpected Start result: did not reach the intended original CAS rejection")
            require(response["payload"].get("actual") == before, "CAS rejected a different state")
        result = {"schema": "hepta-supervisor-start-preparation-diagnostic-v1", "label": label,
                  "supervisor_binary": str(binary), "supervisor_sha256": expected_sha,
                  "owned_supervisor_pid": child.pid, "argv": argv, "before": before, "after": after,
                  "start_execution": execution, "start_response": response,
                  "original_fence_digest": original_digest, "deliberately_stale_fence_digest": fence["state_digest"],
                  "actual_start_admission": False, "installed_service_generations": 0,
                  "probe_scope": "original catalog verification followed by mandatory stale-fence rejection"}
    finally:
        if child is not None:
            if child.poll() is None:
                child.send_signal(signal.SIGINT)
                try:
                    child.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    child.kill()  # Only the exact Popen-owned diagnostic daemon.
                    child.wait(timeout=5)
            save(directory / "owned-daemon-cleanup.json", {"pid": child.pid, "returncode": child.returncode})
        require(digest(binary) == expected_sha, "Supervisor binary changed during diagnostic")
    require(result is not None, "diagnostic did not complete")
    save(directory / "result.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="reviewed JSON configuration")
    args = parser.parse_args()
    require(sys.platform == "linux", "diagnostic uses Linux SO_PEERCRED and the original Linux native case")
    config = json.loads(args.input.read_bytes())
    require(config["schema"] == "hepta-supervisor-start-preparation-config-v1", "unknown diagnostic schema")
    source = canonical(config["source_study_root"])
    agent_id, release_id = config["agent_id"], config["source_release"]
    require(str(uuid.UUID(agent_id)) == agent_id and agent_id != str(uuid.UUID(int=0)), "invalid Agent ID")
    require(1 <= len(release_id) <= 128 and all(c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
                                             for c in release_id), "invalid release ID")
    fleet, audit = preflight(source, agent_id, release_id, config["agentd_sha256"])
    original_inventory = inventory(fleet)
    output = Path(config["output_root"])
    require(output.is_absolute() and not output.exists() and output.parent == output.parent.resolve(strict=True),
            "output must be a fresh physical path beneath an existing canonical parent")
    require(not output.is_relative_to(source) and not source.is_relative_to(output), "output overlaps retained study")
    output.mkdir(mode=0o700)
    save(output / "config.json", config)
    save(output / "path-audit.json", audit)
    save(output / "original-fleet-file-manifest.json", original_inventory)
    keys = []
    for name in ["supervisor-grant-verifier.key", "h7-verifier.key"]:
        original = canonical(source / name)
        require(original.is_file() and original.stat().st_size == 32, "expected only a 32-byte public verifier")
        target = output / name
        shutil.copyfile(original, target)
        target.chmod(0o600)
        keys.append(target)
    results = []
    try:
        for label in ["debug", "release"]:
            case = config[label]
            results.append(run_case(label, case["path"], case["sha256"], fleet, original_inventory,
                                    output, agent_id, release_id, keys))
    except Exception as error:
        save(output / "diagnostic-failure.json", {"type": type(error).__name__, "reason": str(error)})
        raise
    finally:
        unchanged = inventory(fleet) == original_inventory
        save(output / "source-preservation.json", {"original_fleet_file_bytes_and_modes_unchanged": unchanged,
                                                   "atime_is_not_claimed_unchanged": True})
        require(unchanged, "original Fleet changed during diagnostic")
    save(output / "comparison.json", {"schema": "hepta-supervisor-start-preparation-comparison-v1",
                                     "actual_start_admission": False, "results": results})
    print(json.dumps({"output_root": str(output), "cases": len(results), "actual_start_admission": False}))


if __name__ == "__main__":
    main()
