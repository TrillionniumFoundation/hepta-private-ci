#!/usr/bin/env python3
"""Link the timing helper to exact native Cargo compiler-artifact rlibs.

Input must come from the real cached `cargo build --locked ...
--message-format=json` for the desired original Supervisor build profile.
This neither modifies a Cargo manifest nor performs fresh dependency resolution.
It does not run the diagnostic. The root retains the original build receipt.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rustc", type=Path, required=True)
    parser.add_argument("--toolchain", default="1.96.0")
    args = parser.parse_args()
    needed = {"codex_hepta_contracts", "codex_hepta_paths", "codex_hepta_fleet",
              "codex_hepta_supervisor", "serde_json"}
    artifacts = {name: {} for name in needed}
    finished = False
    for line in args.inventory.read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("reason") == "build-finished":
            finished = event.get("success") is True
        target = event.get("target", {}).get("name")
        if event.get("reason") == "compiler-artifact" and target in needed:
            for name in event.get("filenames", []):
                path = Path(name)
                if path.suffix == ".rlib":
                    artifacts[target][str(path)] = {"path":str(path),"package_id":event["package_id"],
                                                   "features":event.get("features"),"profile":event.get("profile")}
    if not finished or any(len(value) != 1 for value in artifacts.values()):
        raise RuntimeError("require a successful original build and exactly one rlib per actual crate")
    selected = {name: next(iter(options.values())) for name, options in artifacts.items()}
    for artifact in selected.values():
        path = Path(artifact["path"])
        if not path.is_absolute() or not path.is_file():
            raise RuntimeError("actual referenced native rlib is missing")
        artifact["sha256"] = sha(path)
    if not args.source.is_absolute() or not args.rustc.is_absolute() or not args.output.is_absolute():
        raise RuntimeError("all executable/source/output paths must be absolute")
    receipt = Path(str(args.output) + ".build.json")
    stdout = Path(str(args.output) + ".build.stdout")
    stderr = Path(str(args.output) + ".build.stderr")
    if any(path.exists() for path in [args.output, receipt, stdout, stderr]):
        raise RuntimeError("diagnostic outputs must be new")
    command = [str(args.rustc), "+" + args.toolchain, "--edition=2024", "--crate-name",
               "hepta_release_resolve_probe", "-C", "opt-level=3", str(args.source), "-o", str(args.output)]
    for name, artifact in sorted(selected.items()):
        command += ["--extern", name + "=" + artifact["path"]]
    for directory in sorted({str(Path(item["path"]).parent) for item in selected.values()}):
        command += ["-L", "dependency=" + directory]
    with stdout.open("xb") as out, stderr.open("xb") as err:
        result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
    record = {"schema":"hepta-original-release-resolve-probe-build-v1", "command":command,
              "inventory_sha256":sha(args.inventory),"diagnostic_source_sha256":sha(args.source),
              "linked_original_artifacts":selected,"exit_code":result.returncode,
              "stdout_sha256":sha(stdout),"stderr_sha256":sha(stderr),
              "diagnostic_binary_sha256":sha(args.output) if result.returncode == 0 else None,
              "product_source_modified":False,"native_diagnostic_executed":False}
    receipt.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if result.returncode:
        raise SystemExit(result.returncode)
    print(json.dumps({"binary":str(args.output),"build_receipt":str(receipt),
                      "sha256":record["diagnostic_binary_sha256"]}))


if __name__ == "__main__":
    main()
