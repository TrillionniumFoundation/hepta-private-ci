use std::io;
use std::io::{Read, Write};
use std::os::unix::net::UnixStream;
use std::time::{Duration, Instant};
type TestResult = Result<(), Box<dyn std::error::Error>>;
fn remaining(deadline: Instant) -> io::Result<Duration> {
    deadline
        .checked_duration_since(Instant::now())
        .filter(|left| !left.is_zero())
        .ok_or_else(|| io::Error::new(io::ErrorKind::TimedOut, "Notes total deadline"))
}

fn read_before(stream: &mut UnixStream, mut bytes: &mut [u8], deadline: Instant) -> io::Result<()> {
    while !bytes.is_empty() {
        stream.set_read_timeout(Some(remaining(deadline)?))?;
        match stream.read(bytes) {
            Ok(0) => return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "Notes read")),
            Ok(count) => bytes = &mut bytes[count..],
            Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
            Err(error) => return Err(error),
        }
    }
    Ok(())
}

#[test]
fn closed_peer_buffered_frame_remains_readable() -> TestResult {
    let (mut owner, mut application) = UnixStream::pair()?;
    application.write_all(&3_u32.to_be_bytes())?;
    application.write_all(b"ack")?;
    drop(application);

    let deadline = Instant::now() + Duration::from_secs(2);
    let mut prefix = [0; 4];
    read_before(&mut owner, &mut prefix, deadline)?;
    assert_eq!(u32::from_be_bytes(prefix), 3);
    let mut response = [0; 3];
    read_before(&mut owner, &mut response, deadline)?;
    assert_eq!(&response, b"ack");
    Ok(())
}

#[test]
fn closed_peer_partial_frame_still_returns_unexpected_eof() -> TestResult {
    let (mut owner, mut application) = UnixStream::pair()?;
    application.write_all(&3_u32.to_be_bytes())?;
    application.write_all(b"ac")?;
    drop(application);

    let deadline = Instant::now() + Duration::from_secs(2);
    let mut prefix = [0; 4];
    read_before(&mut owner, &mut prefix, deadline)?;
    assert_eq!(u32::from_be_bytes(prefix), 3);
    let mut response = [0; 3];
    assert_eq!(
        read_before(&mut owner, &mut response, deadline)
            .expect_err("a partial response cannot be accepted")
            .kind(),
        io::ErrorKind::UnexpectedEof
    );
    Ok(())
}

