from src.calc import total
assert total([1, 2, 4]) == 7
assert total([]) == 0
