import json
import shutil
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "source"))
from async_recurrent_lifecycle import AsyncRecurrentLifecycle
from models import Model
from skill_lifecycle import SkillContract, goals_digest


def main():
    taskroot = ROOT / "originals-checkpoints"
    taskroot.mkdir()
    task = {"id": "original-independent", "version": 1,
            "goals": ["original payload"], "fault": "normal"}
    contract = SkillContract(task["id"], 1, goals_digest(task["goals"]),
                             time.monotonic_ns() + 60_000_000_000, 1)
    model = Model("gru", 41)
    model.p["V"][:] = 0
    model.p["c"][:] = (0, 0, 10)
    np.savez(taskroot / "model.npz", **model.p)
    driver = AsyncRecurrentLifecycle.start(task, contract, taskroot / "model.npz", taskroot / "session")
    try:
        assert driver.step()
        assert not driver.step()
        first_pid = driver._process.pid
        driver.release()
        driver._process.join(timeout=5)
        assert not driver._process.is_alive()
        first = driver.wait(time.monotonic_ns())
        assert first["knowledge"] == "CONFIRMED_COMPLETE"
        (taskroot / "control-first-settled.db").write_bytes((taskroot / "session/control.db").read_bytes())
        folder = next((taskroot / "session/destination/effects").iterdir())
        shutil.copytree(folder, taskroot / "first-effect-original")
        shutil.rmtree(folder)
        calls_before = driver.calls
        stale = driver.wait(time.monotonic_ns())
        after_stale = driver.calls
        (taskroot / "control-after-stale-wait.db").write_bytes((taskroot / "session/control.db").read_bytes())
        current = driver.inspect()
        assert current["index"] == 0 and not current["complete"]
        (taskroot / "control-current-incomplete.db").write_bytes((taskroot / "session/control.db").read_bytes())
        driver.step()
        second_pid = driver._process.pid
        second_invocation = driver.async_attempt["invocation"]
        driver.release()
        driver._process.join(timeout=5)
        assert not driver._process.is_alive()
        second = driver.wait(time.monotonic_ns())
        (taskroot / "control-second-settled.db").write_bytes((taskroot / "session/control.db").read_bytes())
        result = {"first_worker_pid": first_pid, "second_worker_pid": second_pid,
                  "first": first, "stale_wait_after_actual_payload_removal": stale,
                  "stale_wait_reserved_read": after_stale - calls_before,
                  "explicit_current_read": current, "second": second,
                  "same_original_invocation_redispatched": first["invocation"] == second_invocation,
                  "source_scope": "cooperating fixture; actual worker apply twice after one original effect disappears; no common checkpoint rollback"}
        (ROOT / "REPRODUCTION_CHECKPOINTS.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result, indent=2), flush=True)
        assert stale["knowledge"] != "CONFIRMED_COMPLETE", "stale settled bit falsely certifies missing effect"
        assert first["invocation"] != second_invocation, "settled original invocation was dispatched again"
    finally:
        driver.close()


if __name__ == "__main__":
    main()
