
import json,os,sys,time
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from async_recurrent_lifecycle import AsyncRecurrentLifecycle
from durable_lifecycle import canonical
from skill_lifecycle import SkillContract
root=Path(sys.argv[2]); inputs=json.loads((root/'inputs.json').read_text())
d=AsyncRecurrentLifecycle.start(inputs['task'],SkillContract(**inputs['contract']),root/'model.npz',root/'session')
while d.async_attempt is None: d.step()
ready=d.wait(time.monotonic_ns()+8_000_000_000)
assert ready['notice_phase']=='WAITING',ready
(root/'original-worker-spec.json').write_bytes(canonical(d._spec))
(root/'original-checkpoint.json').write_bytes(d.db.execute('SELECT body FROM state').fetchone()[0])
print(json.dumps({'worker_pid':d._process.pid,'controller_pid':os.getpid(),'ready':ready,'policy':d.policy,'owner':d.policy['owner']}),flush=True)
if sys.stdin.readline()=='release\n':
    d.release()
    with (root/'release-returned.json').open('wb') as f:
        f.write(canonical({'release_attempted':d.async_attempt['release_attempted'],'time_ns':time.monotonic_ns()}));f.flush();os.fsync(f.fileno())
    print(json.dumps({'release_returned':True}),flush=True)
sys.stdin.readline()
d.close()
