"""Read-only reconstruction of the complete MEM-2 native-window campaign."""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import statistics
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--native", required=True, type=Path)
    parser.add_argument("--source-root", required=True, type=Path)
    args = parser.parse_args()
    sys.path.insert(0, str(args.source_root))
    from coverage_control import PROFILES, audit_pair, audit_window
    from environment import Owner, Experience, schedule

    root = args.campaign
    manifest = json.loads((root / "manifest.json").read_text())
    results = json.loads((root / "results.json").read_text())
    if hashlib.sha256(args.native.read_bytes()).hexdigest() != manifest["native_binary_sha256"]:
        raise ValueError("native binary identity mismatch")
    for name, expected in manifest["source_sha256"].items():
        if Path(name).name != name or hashlib.sha256((args.source_root / name).read_bytes()).hexdigest() != expected:
            raise ValueError("executed source identity mismatch")
    expected = {(c, s) for c in ("dynamic", "stationary") for s in manifest["seeds"]}
    actual = [(r["condition"], r["seed"]) for r in results["completed"]]
    if len(actual) != len(expected) or set(actual) != expected or results["failures"]:
        raise ValueError("trajectory attempt roster mismatch")
    expected_roster = {(c, s, p, a) for c, s in expected for p in ("A1", "B") for a in PROFILES}
    roster = [(r["condition"], r["seed"], r["phase"], r["profile"]) for r in results["attempt_roster"]]
    if len(roster) != len(expected_roster) or set(roster) != expected_roster or any(
        r["status"] != "completed" for r in results["attempt_roster"]
    ) or manifest["planned_windows"] != len(expected_roster):
        raise ValueError("native window attempt roster mismatch")
    aggregate, details = defaultdict(list), []
    totals = Counter()
    for condition, seed in sorted(expected):
        for phase in ("A1", "B"):
            folder = root / f"{condition}-seed-{seed}" / f"replay-window-{phase}"
            frozen = json.loads((folder / "frozen.json").read_text())
            attempts = json.loads((folder / "attempts.json").read_text())
            owner = Owner(seed)
            if condition == "dynamic" and phase == "B":
                owner.change_rules_and_revoke()
            state = hashlib.sha256((folder / "pre-state.bin").read_bytes()).hexdigest()
            selector_seed = seed * 100 + {"A1": 11, "B": 29}[phase]
            if (frozen["generation"], frozen["owner_change"], frozen["pre_state"],
                frozen["phase"], frozen["seed"], frozen["selector_seed"]) != (
                owner.generation, condition == "dynamic", state, phase, seed, selector_seed
            ):
                raise ValueError("frozen state/owner/selector identity mismatch")
            rows = [Experience(**{**r, "key": tuple(r["key"])}) for r in frozen["pool"]]
            last, offset = {}, 0
            for stage, sources in schedule(seed):
                last.update({source: offset + i + 1 for i, source in enumerate(sources)})
                offset += len(sources)
                if stage == phase:
                    break
            eligible = {s for s in last if owner.resolve(s, "Replay") is not None}
            if {r.source for r in rows} != eligible or any(r.step != last[r.source] for r in rows):
                raise ValueError("frozen pool exposure differs from original stream")
            if set(attempts) != set(PROFILES):
                raise ValueError("profile attempt roster mismatch")
            checks = {}
            for profile in PROFILES:
                result = attempts[profile]
                if result != json.loads((folder / f"{profile}.json").read_text()) or (
                    result["profile"] != profile or result["post_state"] != hashlib.sha256(
                        (folder / f"{profile}.bin").read_bytes()).hexdigest()
                ):
                    raise ValueError("profile result or final state bytes mismatch")
                checks[profile] = audit_window(result, rows, owner, seed=selector_seed, checkpoint_sha256=state)
                if result["evaluation_multiplications"] != 3584:
                    raise ValueError("evaluation operation count mismatch")
                trace = [json.loads(line) for line in (folder / f"{profile}.trace.jsonl").read_text().splitlines()]
                expected_events = ["started"] + [event for _ in range(64) for event in
                                                ("update_attempt", "update_receipt")] + ["query"] * 20
                if [r["event"] for r in trace] != expected_events:
                    raise ValueError("native operation trace roster mismatch")
                for logged, receipt in zip(trace[2:129:2], result["lineage"]):
                    if {k: v for k, v in logged.items() if k != "event"} != receipt:
                        raise ValueError("native receipt differs from raw operation trace")
                aggregate[condition, phase, profile].append({
                    "seed": seed, "stable": checks[profile]["scores"]["stable"]["correct"] / 8,
                    "coverage": len(checks[profile]["source_multiset"]), "wall_ns": result["wall_ns"]})
                totals.update(windows=1, updates=result["updates"], queries=len(result["queries"]))
            match = audit_pair(attempts["coverage_uniform"], attempts["coverage_structured"],
                               checks["coverage_uniform"], checks["coverage_structured"])
            details.append({"condition": condition, "seed": seed, "phase": phase, "matched": match})
    summary = [{"condition": c, "phase": p, "profile": a,
                "stable_accuracy_mean": statistics.mean(r["stable"] for r in rows),
                "per_seed_stable_accuracy": [r["stable"] for r in rows],
                "source_coverage_mean": statistics.mean(r["coverage"] for r in rows),
                "observed_wall_ms_mean": statistics.mean(r["wall_ns"] for r in rows) / 1e6}
               for (c, p, a), rows in aggregate.items()]
    print(json.dumps({"schema": "mem2-independent-reconstruction-v2", "verified": dict(totals),
                      "matching_pairs": len(details), "aggregate": summary, "pair_details": details,
                      "scientific_qualification": "HOLD", "production_adoption": "NoUpdate"}, indent=2))


if __name__ == "__main__":
    main()
