import hashlib,json,sys,shutil,time
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,'/workspace/scratch/d70a317df5f3/act-work/scripts/act2_learning')
from gru_async_continuation import GRUAsyncContinuation
from test_gru_async_continuation import GRUAsyncTests

def main():
 case=GRUAsyncTests();case.setUp()
 try:
  c=GRUAsyncContinuation.start(directory=case.root/'session',**case.args)
  try:
   c.observe(time.monotonic_ns()+5_000_000_000)
   assert c.plan()=='ensure'
   c.release()
   assert c.observe(time.monotonic_ns()+5_000_000_000)['knowledge']=='CONFIRMED_COMPLETE'
   before=json.loads(json.dumps(c.state))
   original=c.owner.observe
   calls=0
   def disappearing(deadline_ns):
    nonlocal calls
    calls+=1
    result=original(deadline_ns)
    if calls==1:
     folder=next((c.owner.directory/'destination/effects').iterdir())
     shutil.rmtree(folder)
    return result
   with patch.object(c.owner,'observe',disappearing):
    try: result=c.finish()
    except ValueError as error: result={'knowledge':'REJECTED','error':str(error)}
    else: raise RuntimeError('UNKNOWN transition still accepted')
   print(json.dumps({'source_sha256':hashlib.sha256(Path('/workspace/scratch/d70a317df5f3/act-work/scripts/act2_learning/gru_async_continuation.py').read_bytes()).hexdigest(),'knowledge':result['knowledge'],'phase':c.state['phase'],'pending':c.state['pending'],'hidden_changed':c.state['hidden']!=before['hidden'],'sequence_before':before['sequence'],'sequence_after':c.state['sequence'],'fresh_reads':calls},indent=2))
  finally:c.close()
 finally:case.doCleanups()
if __name__=='__main__':main()
