from pathlib import Path
import tarfile
import json
import hashlib
import datetime

OUT = Path("/workspace/scratch/ff41dfc0f7bf/tooling/validation/root-native-originals-561d95bd-v1")
wanted = {"ed25519-dalek": "2.2.0", "curve25519-dalek": "4.1.3"}
records = []
raw_records = []
with tarfile.open(OUT / "originals.tar.xz", "r:xz") as tar:
    manifest = json.loads(tar.extractfile("manifest.json").read())
    for file in manifest["files"]:
        if not file["path"].endswith((".log", ".jsonl")):
            continue
        raw = tar.extractfile(file["path"]).read()
        assert len(raw) == file["bytes"] and hashlib.sha256(raw).hexdigest() == file["sha256"]
        for line_number, line in enumerate(raw.splitlines(keepends=True), 1):
            if not line.lstrip().startswith(b"{"):
                continue
            try:
                event = json.loads(line)
            except (ValueError, UnicodeDecodeError):
                continue
            if event.get("reason") != "compiler-artifact":
                continue
            package_id = event.get("package_id", "")
            for name, version in wanted.items():
                if not (f"#{name}@{version}" in package_id or package_id.startswith(f"{name} {version} ")):
                    continue
                if event.get("target", {}).get("name") != name.replace("-", "_"):
                    continue
                records.append({
                    "archive_member": file["path"],
                    "member_sha256": file["sha256"],
                    "original_line": line_number,
                    "original_line_sha256": hashlib.sha256(line).hexdigest(),
                    "package": name,
                    "version": version,
                    "package_id": package_id,
                    "target_name": event["target"]["name"],
                    "target_kind": event["target"].get("kind"),
                    "profile": event["profile"],
                    "fresh": event.get("fresh"),
                    "filenames": event.get("filenames", []),
                })
                raw_records.append(line)
by_package = {name: [r for r in records if r["package"] == name] for name in wanted}
helper_records = [r for r in records if "helper" in r["archive_member"]]
proof = {
    "schema": 1,
    "source_head": "561d95bdf192b2631f6a762d2915d27a120d87bb",
    "source_tree": "387feebbb3bc51f6d0a187137128e100ba63dea1",
    "extracted_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source": "Original Cargo compiler-artifact JSON lines from the verified native archive",
    "records": records,
    "matching_record_count": len(records),
    "helper_matching_record_count": len(helper_records),
    "both_packages_observed_in_helper_output": all(any(r["package"] == n for r in helper_records) for n in wanted),
    "all_observed_profiles_report_opt_level_3": bool(records) and all(str(r["profile"]["opt_level"]) == "3" for r in records),
    "both_packages_observed": all(by_package.values()),
    "qualification_limit": "Cargo profile observations establish the reported build profile; they do not establish an end-to-end pass or isolate runtime causality."
}
(OUT / "crypto-profile-observations.json").write_text(json.dumps(proof, indent=2) + "\n")
(OUT / "crypto-compiler-artifacts.original.jsonl").write_bytes(b"".join(raw_records))
print(json.dumps({**{k: v for k, v in proof.items() if k != "records"}, "records": [{k: r[k] for k in ["archive_member", "original_line", "package", "version", "target_name", "profile", "fresh"]} for r in records]}))
