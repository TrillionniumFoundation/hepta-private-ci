import gzip,hashlib,io,json,os,pathlib,stat,sys,tarfile,time
root=pathlib.Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
evidence=root/"evidence"
npm=root/"tools/npm-cache-02/_logs"
out=root/"closed-native-v2"
limit=479000
excluded_roots={"source-stage1","source-ff-r3"}
rows=[]
skipped=[]
observed={}
result={"schema":1,"output_directory":str(out),"status":"running"}
def sha(data):return hashlib.sha256(data).hexdigest()
def encode(value):return (json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+"\n").encode()
def identity(st):return (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns,st.st_mode,st.st_nlink)
def read_exact(path,expected=None):
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  before=os.fstat(fd)
  if not stat.S_ISREG(before.st_mode) or before.st_nlink!=1:raise RuntimeError("not a regular single-link file: "+str(path))
  if expected is not None and identity(before)!=expected:raise RuntimeError("file identity changed: "+str(path))
  with os.fdopen(fd,"rb",closefd=False) as handle:data=handle.read()
  after=os.fstat(fd)
  if identity(before)!=identity(after) or len(data)!=after.st_size:raise RuntimeError("file changed while reading: "+str(path))
  return data,identity(after),stat.S_IMODE(after.st_mode)
 finally:os.close(fd)
def add(path,member):
 st=path.lstat()
 if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1:
  skipped.append({"source":str(path),"reason":"not regular single-link","mode":stat.S_IMODE(st.st_mode),"nlink":st.st_nlink})
  return
 data,ident,mode=read_exact(path)
 rows.append({"source":str(path),"member":member,"bytes":len(data),"sha256":sha(data),"mode":format(mode,"04o")})
 observed[str(path)]=ident
def visit(directory):
 for item in sorted(directory.iterdir(),key=lambda x:x.name):
  rel=item.relative_to(evidence)
  if rel.parts[0] in excluded_roots:continue
  st=item.lstat()
  if stat.S_ISDIR(st.st_mode):
   visit(item)
  elif stat.S_ISREG(st.st_mode):
   if rel.parts[0]=="v8-resolution-02" and (item.name=="cargo-nextest" or item.name.endswith((".a",".a.gz",".tar.gz",".zip",".bin",".dll",".so",".exe",".rs"))):
    skipped.append({"source":str(item),"reason":"excluded non-metadata V8 artifact"})
   else:add(item,"native/evidence/"+rel.as_posix())
  else:skipped.append({"source":str(item),"reason":"not a regular file; not followed","mode":stat.S_IMODE(st.st_mode)})
def compress(subset):
 buf=io.BytesIO()
 with gzip.GzipFile(filename="",mode="wb",fileobj=buf,compresslevel=9,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode="w|",format=tarfile.PAX_FORMAT) as archive:
   for row in subset:
    data,ident,mode=read_exact(pathlib.Path(row["source"]),observed[row["source"]])
    if len(data)!=row["bytes"] or sha(data)!=row["sha256"]:raise RuntimeError("member contents changed: "+row["source"])
    info=tarfile.TarInfo(row["member"]);info.size=len(data);info.mode=mode;info.uid=0;info.gid=0;info.uname="";info.gname="";info.mtime=0;info.pax_headers={}
    archive.addfile(info,io.BytesIO(data))
 return buf.getvalue()
def split(subset):
 data=compress(subset)
 if len(data)<=limit:return [(subset,data)]
 if len(subset)==1:raise RuntimeError("single member compressed above limit: "+subset[0]["source"]+" size="+str(len(data)))
 mid=len(subset)//2
 return split(subset[:mid])+split(subset[mid:])
if out.exists():raise SystemExit("Refusing existing closed-native-v2 output directory")
if not evidence.is_dir():raise SystemExit("Missing native evidence root")
out.mkdir()
(out/"pack.py").write_text(PACK_SCRIPT,encoding="utf-8")
try:
 visit(evidence)
 npm_present=npm.is_dir()
 if npm_present:
  for path in sorted(npm.glob("*.log"),key=lambda x:x.name):add(path,"native/npm-cache-02/_logs/"+path.name)
 rows.sort(key=lambda r:r["member"])
 if not rows:raise RuntimeError("no source evidence files")
 if len({r["member"] for r in rows})!=len(rows):raise RuntimeError("duplicate archive member")
 packs=split(rows)
 parts=[]
 for number,(subset,data) in enumerate(packs,1):
  name="p"+str(number).zfill(3)+".tar.gz"
  if len(data)>=480000:raise RuntimeError("part exceeds hard limit")
  (out/name).write_bytes(data)
  for row in subset:row["part"]=name
  parts.append({"name":name,"bytes":len(data),"sha256":sha(data),"member_count":len(subset),"uncompressed_bytes":sum(r["bytes"] for r in subset)})
 members={"schema":1,"files":rows,"excluded_evidence_prefixes":[x+"/" for x in sorted(excluded_roots)],"skipped_nonregular_or_nonmetadata":skipped,"npm_log_directory":str(npm),"npm_log_directory_present":npm_present}
 member_bytes=encode(members);(out/"members.json").write_bytes(member_bytes)
 index={"schema":1,"format":"independent-deterministic-tar-gzip-v2","root":str(root),"archive_member_prefixes":["native/evidence/","native/npm-cache-02/"],"max_part_bytes":limit,"members_file":"members.json","members_bytes":len(member_bytes),"members_sha256":sha(member_bytes),"parts":parts,"total_members":len(rows),"total_uncompressed_bytes":sum(r["bytes"] for r in rows),"pack_script_sha256":sha(PACK_SCRIPT.encode())}
 index_bytes=encode(index);(out/"index.json").write_bytes(index_bytes)
 # Re-open every independently decompressible part and verify each member.
 expected={r["member"]:r for r in rows}
 verified=[]
 for part in parts:
  archive_path=out/part["name"];data=archive_path.read_bytes()
  if sha(data)!=part["sha256"] or len(data)!=part["bytes"]:raise RuntimeError("part checksum changed")
  with tarfile.open(fileobj=io.BytesIO(data),mode="r:gz") as archive:
   actual=archive.getmembers()
   if len(actual)!=part["member_count"]:raise RuntimeError("part member count mismatch")
   for member in actual:
    if not member.isfile() or member.name not in expected:raise RuntimeError("unexpected archive member")
    row=expected[member.name]
    if row["part"]!=part["name"] or member.mode!=int(row["mode"],8):raise RuntimeError("wrong member part/mode")
    data=archive.extractfile(member).read()
    if len(data)!=row["bytes"] or sha(data)!=row["sha256"]:raise RuntimeError("member verification failed")
    verified.append(member.name)
 if len(verified)!=len(rows) or len(set(verified))!=len(rows):raise RuntimeError("member coverage mismatch")
 # Assert source content still agrees with the closed snapshot.
 for row in rows:
  data,_,_=read_exact(pathlib.Path(row["source"]),observed[row["source"]])
  if sha(data)!=row["sha256"]:raise RuntimeError("source changed after archive: "+row["source"])
 result.update({"status":"packed_and_verified","members":len(rows),"uncompressed_bytes":sum(r["bytes"] for r in rows),"npm_logs":sum(r["member"].startswith("native/npm-cache-02/") for r in rows),"skipped_count":len(skipped),"parts":parts,"index_bytes":len(index_bytes),"index_sha256":sha(index_bytes),"members_bytes":len(member_bytes),"members_sha256":sha(member_bytes)})
except Exception as exc:
 result["status"]="failed";result["error"]=repr(exc)
(out/"result.json").write_bytes(encode(result))
print(json.dumps(result,ensure_ascii=False),flush=True)
sys.exit(0 if result["status"]=="packed_and_verified" else 1)
