# Closed native evidence v2

This is the original native-evidence component prepared for later composition with separately preserved controller evidence. It is not the final combined qualification archive.

## Stable files for composition

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `p001.tar.gz` | 233,056 | `184fc22b52dfcff299a8e1015953d117fb2d26ee5a86a2b7a4e3029d9c0f175c` |
| `index.json` | 791 | `1b5b24d38c4f9bdbbf4ef0ab7398d9459f89a23765d06a38436cbf28fe5189c3` |
| `members.json` | 187,563 | `da95f8781005bac8495eb8c3dc19907fa3db4ecad3f61e1ff577664d36908e82` |

The single independently readable tar.gz contains 484 regular files totaling 1,318,324 uncompressed bytes. It is below the 479,000-byte target and 480,000-byte hard ceiling. Exactly one original npm failure log is included.

## Source scope

Files were collected from:

- `/home/qian-qi/work/cell-architecture-closure-20261106-9387/evidence`, excluding the already published `source-stage1/` and `source-ff-r3/` prefixes.
- `/home/qian-qi/work/cell-architecture-closure-20261106-9387/tools/npm-cache-02/_logs/*.log`.

Only regular files with one hard link were read. Symlinks would not be followed. The skipped-nonregular/nonmetadata list is empty. V8 metadata remains included; tools' V8/nextest binaries, npmrc files, and token files are outside the collected scope.

Archive member names are `native/evidence/...` and `native/npm-cache-02/_logs/...`. Each manifest entry records the original absolute source path, member path, original mode, byte count, SHA256, and part name.

## Verification

The native pack job `1a1b3f9bc19-fc05-85b1` completed successfully with exit 0. Before finishing it reopened the archive, checked all 484 members against the manifest, and re-read each source file to verify unchanged content and file identity.

The archive uses sorted member names, fixed gzip mtime and empty gzip filename, and fixed tar uid/gid/uname/gname/mtime. Original file modes are retained. On local readback, version-pinned chunks and each chunk SHA256 were checked, followed by full index/manifest/part SHA256 validation.

All 484 members were safely extracted under this directory and checked again for size, SHA256, mode, path, uniqueness, and normalized archive metadata. The unpacked original files are available under `native/`. `extraction-verification.json` records the successful local result.

## Audit separation

The pack's launch, authoritative terminal status, complete controller logs, and readback metadata are stored in `audit/` and `download-receipts/`. They are separate from `p001.tar.gz`, so the package does not contain a reference to its own creation receipt.

No source worktree, Git reference, original evidence file, or build target was modified. No remote branch was pushed by this packaging task. The top-level local `manifest.json` seals all files in this delivery directory except itself.
