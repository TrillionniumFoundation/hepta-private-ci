from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
root = Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source = root / "source"
evidence = root / "evidence" / "native-fix-01"
expected = "37e6ffe9dda66289580f9e3bdf6b161b2ee7d02e"
packages = ["-p", "codex-hepta-neuron", "-p", "codex-hepta-automation", "-p", "codex-hepta-runtime", "-p", "codex-hepta-agentd"]
evidence.mkdir()
def write(name, data):
    with (evidence / name).open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
def git(*args):
    return subprocess.check_output(["git", *args], cwd=source, text=True).strip()
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()
stage = json.loads((root / "evidence/source-stage1/complete.json").read_text())
if stage["outcome"] != "source_ready_no_native_build_started" or stage["final_identity"][0] != expected:
    raise RuntimeError("source stage did not finish at the expected formatted head")
before = {"head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"), "codex_rs_tree": git("rev-parse", "HEAD:codex-rs"), "status": git("status", "--porcelain")}
if before["head"] != expected or before["status"]:
    raise RuntimeError("native fix does not start from the clean expected candidate")
v8 = json.loads((root / "evidence/v8-resolution/result.json").read_text())
for item in v8["resolved_material"]:
    if sha(Path(item["path"])) != item["sha256"]:
        raise RuntimeError("V8 material changed after resolution")
overrides = {
    "PATH": "/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/.cargo/bin:" + os.environ["PATH"],
    "RUSTUP_TOOLCHAIN": "1.96.0",
    "PYTHONDONTWRITEBYTECODE": "1",
    "CARGO_TARGET_DIR": str(root / "target"),
    "CARGO_BUILD_JOBS": "2",
    "NEXTEST_TEST_THREADS": "2",
    "CARGO_PROFILE_TEST_DEBUG": "0",
    "CARGO_PROFILE_DEV_DEBUG": "0",
    "CARGO_INCREMENTAL": "0",
    "CARGO_NET_GIT_FETCH_WITH_CLI": "true",
    "PROTOC": "/usr/bin/protoc",
    "PROTOC_INCLUDE": "/usr/include",
    "CODEX_REPO_ROOT": str(source),
    "HEPTA_CI_LANE": "source-head",
    "SOURCE_SHA": expected,
    "TESTED_SHA": expected,
    "BASE_SHA": "a6f3aa12ba187448c35449c7da0a9798ae4ca987",
    **v8["environment"],
}
os.environ.update(overrides)
helper_path = source / "scripts/hepta_ci_exec.py"
spec = importlib.util.spec_from_file_location("hepta_ci_exec", helper_path)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
command = ["just", "fix", "--locked", *packages]
state = {
    "label": "native-fix-01", "started_unix_ns": time.time_ns(),
    "command": command, "source_before": before,
    "environment_overrides": overrides, "helper_sha256": sha(helper_path),
    "v8_official_release_checksum_verified": v8["official_release_checksum_verified"],
    "v8_material": v8["resolved_material"],
    "scope": "Original just fix transformation and real four-package compilation; not a passing test qualification.",
}
write("started.json", state)
print(json.dumps({"event": "native_fix_started", **state}), flush=True)
os.chdir(source)
result = helper.execute_logged(command, evidence / "command.log", timeout_seconds=4200)
state["execution"] = result
state["source_after"] = {
    "head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
    "codex_rs_tree": git("rev-parse", "HEAD:codex-rs"),
    "status": git("status", "--porcelain"),
    "changed_paths": git("diff", "--name-only").splitlines(),
}
patch = subprocess.check_output(["git", "diff", "--binary"], cwd=source)
with (evidence / "fix.patch").open("xb") as stream:
    stream.write(patch)
state["patch"] = {"path": "fix.patch", "bytes": len(patch), "sha256": hashlib.sha256(patch).hexdigest()}
state["finished_unix_ns"] = time.time_ns()
state["outcome"] = "completed" if result["returncode"] == 0 and not result["timed_out"] and not result["output_limit_exceeded"] else "failed"
write("result.json", state)
print(json.dumps({"event": "native_fix_complete", **state}), flush=True)
sys.exit(0 if state["outcome"] == "completed" else 1)
