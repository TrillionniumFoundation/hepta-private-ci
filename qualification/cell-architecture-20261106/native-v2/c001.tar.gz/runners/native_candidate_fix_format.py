"""Prepare one exact successor and retain original formatter/fix execution.

This runner never publishes or runs qualification tests. Any source mutation is
retained as a patch for the coordinating owner to review before freezing tests.
"""

from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-sha", required=True)
    parser.add_argument("--source-tree", required=True)
    parser.add_argument("--rust-tree", required=True)
    parser.add_argument("--previous-sha", required=True)
    parser.add_argument("--label", required=True)
    args = parser.parse_args()
    for value in (args.source_sha, args.source_tree, args.rust_tree, args.previous_sha):
        if re.fullmatch(r"[0-9a-f]{40}", value) is None:
            raise ValueError("full Git identity required")
    if re.fullmatch(r"[a-z0-9-]+", args.label) is None:
        raise ValueError("bounded evidence label required")

    sys.dont_write_bytecode = True
    root = Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
    source = root / "source"
    evidence = root / "evidence" / args.label
    evidence.mkdir()

    def sha(path):
        with path.open("rb") as stream:
            return hashlib.file_digest(stream, "sha256").hexdigest()

    def write(name, value):
        with (evidence / name).open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")

    def git(*values):
        return subprocess.check_output(["git", *values], cwd=source, text=True).strip()

    def identity():
        return {
            "head": git("rev-parse", "HEAD"),
            "tree": git("rev-parse", "HEAD^{tree}"),
            "codex_rs_tree": git("rev-parse", "HEAD:codex-rs"),
            "status": git("status", "--porcelain"),
        }

    def checked(label, command, *, cwd=source):
        result = subprocess.run(
            command, cwd=cwd, capture_output=True, timeout=300, check=False
        )
        for channel in ("stdout", "stderr"):
            (evidence / (label + "." + channel + ".log")).write_bytes(
                getattr(result, channel)
            )
        write(label + ".json", {"command": command, "returncode": result.returncode})
        if result.returncode:
            raise RuntimeError(label + " failed")
        return result.stdout.decode("utf-8")

    before = identity()
    write("before-fast-forward.json", before)
    if before["head"] != args.previous_sha or before["status"]:
        raise RuntimeError("previous checkout differs from the coordinated identity")
    checked("fetch-successor", ["git", "fetch", "--depth=64", "origin", args.source_sha])
    checked("ff-successor", ["git", "merge", "--ff-only", args.source_sha])
    bound = identity()
    if bound["head"] != args.source_sha or bound["tree"] != args.source_tree or bound["codex_rs_tree"] != args.rust_tree or bound["status"]:
        raise RuntimeError("fetched source differs from the coordinated candidate")
    write("bound-source.json", bound)

    uv = Path("/home/qian-qi/work/hepta-pq-effect-v4-20261105-93bfcf/tools/uv-0.11.3/bin/uv")
    v8 = json.loads((root / "evidence/v8-resolution-02/result.json").read_text())
    if not v8["official_release_checksum_verified"]:
        raise RuntimeError("official V8 checksum verification is absent")
    for item in v8["resolved_material"]:
        if sha(Path(item["path"])) != item["sha256"]:
            raise RuntimeError("V8 material changed")
    overrides = {
        "PATH": "/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:"
        + str(uv.parent) + ":/home/qian-qi/.cargo/bin:" + os.environ["PATH"],
        "RUSTUP_TOOLCHAIN": "1.96.0",
        "PYTHONDONTWRITEBYTECODE": "1",
        "CARGO_TARGET_DIR": str(root / "target"),
        "CARGO_BUILD_JOBS": "2",
        "NEXTEST_TEST_THREADS": "2",
        "CARGO_PROFILE_TEST_DEBUG": "0",
        "CARGO_PROFILE_DEV_DEBUG": "0",
        "CARGO_INCREMENTAL": "0",
        "CARGO_NET_GIT_FETCH_WITH_CLI": "true",
        "PROTOC": "/usr/bin/protoc",
        "PROTOC_INCLUDE": "/usr/include",
        "CODEX_REPO_ROOT": str(source),
        "UV_PROJECT_ENVIRONMENT": str(root / "python-scripts-env"),
        "HEPTA_CI_LANE": "source-head",
        "SOURCE_SHA": args.source_sha,
        "TESTED_SHA": args.source_sha,
        "BASE_SHA": "a6f3aa12ba187448c35449c7da0a9798ae4ca987",
        **v8["environment"],
    }
    os.environ.update(overrides)
    helper_path = source / "scripts/hepta_ci_exec.py"
    spec = importlib.util.spec_from_file_location("hepta_ci_exec", helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    state = {
        "label": args.label,
        "started_unix_ns": time.time_ns(),
        "source_before": bound,
        "helper_sha256": sha(helper_path),
        "uv_observed_sha256": sha(uv),
        "environment_overrides": overrides,
        "scope": "Original four-owner fix and actual PR-scoped formatter; not a passing test qualification",
        "commands": [],
    }
    checked("uv-version", [str(uv), "--version"])
    checked("rustc-version", ["rustc", "--version", "--verbose"])
    write("started.json", state)
    print(json.dumps({"event": "candidate_fix_format_started", **state}), flush=True)
    packages = [
        "-p", "codex-hepta-neuron", "-p", "codex-hepta-automation",
        "-p", "codex-hepta-runtime", "-p", "codex-hepta-agentd",
    ]
    stages = [
        ("fix", ["just", "fix", "--locked", *packages], source, 4200),
        ("fmt-pr", ["just", "fmt", "--base", overrides["BASE_SHA"]], source, 600),
        ("fmt-rust-check", ["cargo", "fmt", "--", "--config", "imports_granularity=Item", "--check"], source / "codex-rs", 600),
    ]
    for label, command, cwd, timeout in stages:
        os.chdir(cwd)
        result = helper.execute_logged(command, evidence / (label + ".log"), timeout_seconds=timeout)
        record = {"label": label, "command": command, "cwd": str(cwd), **result, "identity_after": identity()}
        write(label + ".json", record)
        state["commands"].append(record)
        print(json.dumps({"event": "candidate_stage_complete", **record}), flush=True)
        if label == "fix" and result["returncode"] != 0:
            break
    state["source_after"] = identity()
    patch = subprocess.check_output(["git", "diff", "--binary"], cwd=source)
    (evidence / "changes.patch").write_bytes(patch)
    state["patch"] = {"bytes": len(patch), "sha256": hashlib.sha256(patch).hexdigest(), "paths": git("diff", "--name-only").splitlines()}
    state["finished_unix_ns"] = time.time_ns()
    failed = any(c["returncode"] or c["timed_out"] or c["output_limit_exceeded"] for c in state["commands"])
    state["outcome"] = "failed" if failed else "needs_source_review" if patch else "source_ready"
    write("result.json", state)
    print(json.dumps({"event": "candidate_fix_format_complete", **state}), flush=True)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
