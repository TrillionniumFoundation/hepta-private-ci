from pathlib import Path
import ast,hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
root=Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source";publish=root/"evidence/final-source-05";publish.mkdir()
gates=root/"evidence/native-final-gates-05";gates.mkdir()
previous="8d86de32cb0d22367eaab7994f49515187cf71d3"
rust="3deb8503bc873331518c0c536a269c00d754a8bf"
branch="codex/cell-architecture-closure-20261106-9387"
paths=["scripts/hepta_typed_callers.py","scripts/test_hepta_typed_callers.py"]
format_record=json.loads((root/"evidence/native-r4-format-04/result.json").read_text())
expected_patch="c9b42328416c546cbe567328f7ef17fd9d4b683edbb9af3944384b32f9fca4a3"
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(directory,name,data):
    with (directory/name).open("x") as f:json.dump(data,f,indent=2);f.write("\n")
def git(*args):return subprocess.check_output(["git",*args],cwd=source,text=True).strip()
def identity():return {"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"rust_tree":git("rev-parse","HEAD:codex-rs"),"status":git("status","--porcelain")}
def checked(label,args,timeout=300):
    p=subprocess.run(args,cwd=source,capture_output=True,timeout=timeout,check=False)
    for channel in ("stdout","stderr"):(publish/(label+"."+channel+".log")).write_bytes(getattr(p,channel))
    write(publish,label+".json",{"command":args,"returncode":p.returncode})
    if p.returncode:raise RuntimeError(label+" failed")
    return p.stdout.decode()
before=identity();write(publish,"before.json",before)
patch=subprocess.check_output(["git","diff","--binary"],cwd=source)
if before["head"]!=previous or before["rust_tree"]!=rust or hashlib.sha256(patch).hexdigest()!=expected_patch:
    raise RuntimeError("formatter candidate changed before approved publication")
if git("diff","--name-only").splitlines()!=paths or git("diff","--cached","--name-only") or git("ls-files","--others","--exclude-standard"):
    raise RuntimeError("unreviewed source changes present")
for relative in paths:
    original=git("show",previous+":"+relative)
    current=(source/relative).read_text()
    if ast.dump(ast.parse(original),include_attributes=False)!=ast.dump(ast.parse(current),include_attributes=False):
        raise RuntimeError("published formatting changes Python AST")
    if sha(source/relative)!=format_record["python_after"][relative]["sha256"]:
        raise RuntimeError("formatted source hash changed")
remote=checked("remote-before",["git","ls-remote","--exit-code","origin","refs/heads/"+branch]).split()
if remote!=[previous,"refs/heads/"+branch]:raise RuntimeError("remote advanced before coordinated publication")
checked("stage-python-format",["git","add","--",*paths])
if git("diff","--cached","--name-only").splitlines()!=paths:raise RuntimeError("staged source differs from approved two-file patch")
checked("staged-diff-check",["git","diff","--cached","--check"])
checked("commit-python-format",["git","commit","-m","style(python): format typed caller scope regressions"])
committed=identity()
if committed["status"] or committed["rust_tree"]!=rust or git("rev-parse","HEAD^")!=previous:
    raise RuntimeError("committed source differs from approved formatting")
checked("push-python-format",["git","push","origin","HEAD:refs/heads/"+branch])
remote_after=checked("remote-after",["git","ls-remote","--exit-code","origin","refs/heads/"+branch]).split()
if remote_after!=[committed["head"],"refs/heads/"+branch]:raise RuntimeError("published source readback differs")
record={"outcome":"published_clean_source","previous":previous,"identity":committed,"branch":branch,"approved_patch_sha256":expected_patch,"python_after":format_record["python_after"],"published_unix_ns":time.time_ns()}
write(publish,"result.json",record)
print(json.dumps({"event":"final_source_published",**record}),flush=True)
v8=json.loads((root/"evidence/v8-resolution-02/result.json").read_text())
if not v8["official_release_checksum_verified"]:raise RuntimeError("V8 official verification missing")
for item in v8["resolved_material"]:
    if sha(item["path"])!=item["sha256"]:raise RuntimeError("V8 material changed")
overrides={"PATH":"/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/.cargo/bin:"+os.environ["PATH"],"RUSTUP_TOOLCHAIN":"1.96.0","PYTHONDONTWRITEBYTECODE":"1","CARGO_TARGET_DIR":str(root/"target"),"CARGO_BUILD_JOBS":"2","NEXTEST_TEST_THREADS":"2","CARGO_PROFILE_TEST_DEBUG":"0","CARGO_PROFILE_DEV_DEBUG":"0","CARGO_INCREMENTAL":"0","CARGO_NET_GIT_FETCH_WITH_CLI":"true","PROTOC":"/usr/bin/protoc","PROTOC_INCLUDE":"/usr/include","CODEX_REPO_ROOT":str(source),"HEPTA_CI_LANE":"source-head","SOURCE_SHA":committed["head"],"TESTED_SHA":committed["head"],"BASE_SHA":"a6f3aa12ba187448c35449c7da0a9798ae4ca987",**v8["environment"]}
os.environ.update(overrides)
tool=subprocess.run(["cargo","nextest","--version"],cwd=source,capture_output=True,text=True,timeout=30,check=False)
write(gates,"nextest-version.json",{"command":["cargo","nextest","--version"],"returncode":tool.returncode,"stdout":tool.stdout,"stderr":tool.stderr})
if tool.returncode or not tool.stdout.startswith("cargo-nextest 0.9.103"):
    raise RuntimeError("original nextest 0.9.103 tool is not available")
packages=["-p","codex-hepta-neuron","-p","codex-hepta-automation","-p","codex-hepta-runtime","-p","codex-hepta-agentd"]
commands=[("tests",4200,1,["just","test","--locked",*packages,"--retries","0"]),("clippy",900,0,["just","clippy","--locked",*packages,"--","-D","warnings"])]
sequence={"source":committed,"environment_overrides":overrides,"started_unix_ns":time.time_ns(),"helper_sha256":sha(source/"scripts/hepta_ci_exec.py"),"run_nextest_sha256":sha(source/"scripts/run-nextest.py"),"justfile_sha256":sha(source/"justfile"),"cargo_lock_sha256":sha(source/"codex-rs/Cargo.lock"),"gates":[]}
write(gates,"started.json",sequence)
for name,timeout,minimum,command in commands:
    output=gates/(name+".json")
    args=["python3","scripts/hepta_ci_exec.py","--timeout-seconds",str(timeout),"--minimum-tests",str(minimum),"--output",str(output),"--",*command]
    print(json.dumps({"event":"native_gate_started","label":name,"identity":committed,"command":args}),flush=True)
    p=subprocess.run(args,cwd=source,check=False)
    result=json.loads(output.read_text()) if output.is_file() else {"status":"missing"}
    sequence["gates"].append({"label":name,"wrapper_returncode":p.returncode,"record":result})
    print(json.dumps({"event":"native_gate_terminal","label":name,"wrapper_returncode":p.returncode,"status":result.get("status"),"observed_passed_tests":result.get("observed_passed_tests"),"observed_failed_tests":result.get("observed_failed_tests")}),flush=True)
    if p.returncode:break
sequence["finished_unix_ns"]=time.time_ns();sequence["source_after"]=identity()
sequence["outcome"]="passed" if len(sequence["gates"])==2 and all(g["wrapper_returncode"]==0 and g["record"].get("status")=="passed" for g in sequence["gates"]) else "failed"
write(gates,"result.json",sequence)
print(json.dumps({"event":"native_gate_sequence_complete","outcome":sequence["outcome"],"source_after":sequence["source_after"]}),flush=True)
raise SystemExit(0 if sequence["outcome"]=="passed" else 1)
