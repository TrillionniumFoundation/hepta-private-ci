from pathlib import Path
import hashlib,json,os,shlex,shutil,subprocess,sys,time
sys.dont_write_bytecode=True
root=Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source";evidence=root/"evidence/native-python-text-07";evidence.mkdir()
expected="87cce8066b5f41e2d462b9469a301245f43d8c23";tree="60604de0d6ea4805fd248574ba83fe49f16b261a";rust="3deb8503bc873331518c0c536a269c00d754a8bf"
def sha(path):
    with Path(path).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def git(*args):return subprocess.check_output(["git",*args],cwd=source,text=True).strip()
def identity():return {"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"rust_tree":git("rev-parse","HEAD:codex-rs"),"status":git("status","--porcelain")}
def write(name,value):
    with (evidence/name).open("x") as f:json.dump(value,f,indent=2);f.write("\n")
before=identity()
if (before["head"],before["tree"],before["rust_tree"],before["status"])!=(expected,tree,rust,""):raise RuntimeError("Python/text gates require exact frozen source")
cache=Path("/home/qian-qi/.local/share/pnpm/store/v11/links/@/prettier/3.5.3/7e56e21580f0c9558edb81ef024a24bd45a6455c20eafad33f5a663e6bf6c934/node_modules/prettier")
if json.loads((cache/"package.json").read_text()).get("version")!="3.5.3":raise RuntimeError("cached Prettier version differs")
destination=root/"tools/prettier-3.5.3-observed";destination.mkdir()
members=[]
for path in sorted(cache.rglob("*")):
    if path.is_symlink():raise RuntimeError("unexpected symlink in cached Prettier")
    if path.is_file():
        relative=path.relative_to(cache);target=destination/relative;target.parent.mkdir(parents=True,exist_ok=True)
        digest=sha(path);shutil.copyfile(path,target)
        if sha(target)!=digest or sha(path)!=digest:raise RuntimeError("cached Prettier changed during copy")
        members.append({"path":str(relative),"bytes":target.stat().st_size,"sha256":digest})
entry=destination/"bin/prettier.cjs"
observed=subprocess.run(["/usr/bin/node",str(entry),"--version"],capture_output=True,text=True,timeout=20,check=False)
if observed.returncode or observed.stdout.strip()!="3.5.3":raise RuntimeError("copied Prettier version mismatch")
write("prettier-cache.json",{"origin":str(cache),"destination":str(destination),"version":observed.stdout.strip(),"entry_sha256":sha(entry),"members":members,"scope":"Existing cache version and every copied file hash verified; underlying Prettier execution, not successful pnpm provisioning"})
package=json.loads((source/"package.json").read_text())
format_script="prettier --check *.json *.md docs/*.md .github/workflows/*.yml **/*.js"
if package["scripts"]["format"]!=format_script:raise RuntimeError("original Prettier script changed")
underlying=shlex.join(["/usr/bin/node",str(entry)])+format_script[len("prettier"):]
uv=Path("/home/qian-qi/work/hepta-pq-effect-v4-20261105-93bfcf/tools/uv-0.11.3/bin/uv")
env={"PATH":"/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:"+str(uv.parent)+":/home/qian-qi/.cargo/bin:"+os.environ["PATH"],"RUSTUP_TOOLCHAIN":"1.96.0","PYTHONDONTWRITEBYTECODE":"1","CODEX_REPO_ROOT":str(source),"UV_PROJECT_ENVIRONMENT":str(root/"python-scripts-env"),"RUFF_CACHE_DIR":str(root/"tools/ruff-cache-final"),"HEPTA_CI_LANE":"source-head","SOURCE_SHA":expected,"TESTED_SHA":expected,"BASE_SHA":"a6f3aa12ba187448c35449c7da0a9798ae4ca987"}
os.environ.update(env)
codespell="/home/qian-qi/work/hepta-architecture-20261025/codespell-2.4.3-venv-v1/bin/codespell"
tool=subprocess.run([codespell,"--version"],capture_output=True,text=True,timeout=20,check=False)
if tool.returncode or tool.stdout.strip()!="2.4.3":raise RuntimeError("original codespell version differs")
write("codespell-version.json",{"command":[codespell,"--version"],"returncode":tool.returncode,"stdout":tool.stdout,"stderr":tool.stderr})
commands=[
("pr-format",600,0,["just","fmt","--base",env["BASE_SHA"],"--check"],True),
("typed-tests",600,1,["python3","-B","-m","unittest","discover","-s","scripts","-p","test_hepta_typed_callers.py","-v"],True),
("b4-tests",600,1,["python3","-B","-m","unittest","discover","-s","qa/b4-no-bypass","-p","test_*.py","-v"],True),
("caller-proof",900,0,["python3","-B","scripts/verify_hepta_callers.py","verify"],True),
("archive-tests",600,1,["python3","-B","-m","unittest","discover","-s","scripts/tests","-p","test_hepta_evidence_archive.py","-v"],True),
("archive-verify",600,0,["python3","-B","scripts/hepta_evidence_archive.py","verify","qualification/cell-unification-20261106/archive","--expected-source",env["BASE_SHA"],"--expected-listing","c1e6d2104a3b33f7a37b600efd8468e2a169e7a5e624682ac6fe78a674ea6669"],True),
("archive-check-tree",600,0,["python3","-B","scripts/hepta_evidence_archive.py","check-tree","--revision",expected,"--prefix","qualification/cell-unification-20261106"],True),
("codespell",600,0,[codespell,"--ignore-words",".codespellignore","--skip","./.git"],True),
("prettier-underlying",600,0,["/bin/sh","-c",underlying],True),
("ruff-full-diagnostic",600,0,[str(uv),"run","--frozen","--project","scripts","ruff","format","--check","scripts",".github"],False),
]
state={"label":"native-python-text-07","source_before":before,"started_unix_ns":time.time_ns(),"environment_overrides":env,"original_prettier_script":format_script,"underlying_prettier_script":underlying,"gates":[],"scope":"Frozen published candidate read-only Python, source-audit, archive, spelling, and underlying Prettier checks; full Ruff tree check is separately diagnostic"}
write("started.json",state)
print(json.dumps({"event":"python_text_gates_started",**state}),flush=True)
for label,timeout,minimum,command,required in commands:
    if identity()!=before:raise RuntimeError("frozen source changed between read-only gates")
    output=evidence/(label+".json")
    args=["python3","scripts/hepta_ci_exec.py","--timeout-seconds",str(timeout),"--minimum-tests",str(minimum),"--output",str(output),"--",*command]
    print(json.dumps({"event":"python_text_gate_started","label":label,"required":required,"command":args}),flush=True)
    p=subprocess.run(args,cwd=source,check=False)
    result=json.loads(output.read_text()) if output.exists() else {"status":"missing"}
    state["gates"].append({"label":label,"required":required,"wrapper_returncode":p.returncode,"record":result})
    print(json.dumps({"event":"python_text_gate_terminal","label":label,"required":required,"wrapper_returncode":p.returncode,"status":result.get("status"),"observed_passed_tests":result.get("observed_passed_tests"),"observed_failed_tests":result.get("observed_failed_tests")}),flush=True)
state["source_after"]=identity();state["finished_unix_ns"]=time.time_ns()
state["outcome"]="passed" if all(not g["required"] or (g["wrapper_returncode"]==0 and g["record"].get("status")=="passed") for g in state["gates"]) and state["source_after"]==before else "failed"
write("result.json",state)
print(json.dumps({"event":"python_text_gates_complete","outcome":state["outcome"],"source_after":state["source_after"],"diagnostic_status":[{"label":g["label"],"status":g["record"].get("status")} for g in state["gates"] if not g["required"]]}),flush=True)
raise SystemExit(0 if state["outcome"]=="passed" else 1)
