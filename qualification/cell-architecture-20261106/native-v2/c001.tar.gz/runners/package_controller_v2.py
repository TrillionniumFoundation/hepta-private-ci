from pathlib import Path
import gzip,hashlib,io,json,os,stat,tarfile
root=Path("/workspace/scratch/93874da9c102")
src=root/"native-discovery"
out=src/"controller-pack-v2"
out.mkdir()
directories=[
"preparation-failures","formatter-tool-prepare-01","formatter-tool-prepare-02",
"pnpm-cache-cross-host","nextest-tool-06","codespell-cli-merge-01","controller-receipts",
"native-fix-format-03","native-r4-format-04","native-final-05","runner-failure-06",
"github-read-05","github-merge-observation-06","github-merge-review-07",
"gates-07-08-complete","prettier-format-09","controller-final"]
sources={}
for name in directories:
    directory=src/name
    if not directory.is_dir():raise RuntimeError("missing closed directory: "+name)
    for p in sorted(directory.rglob("*")):
        if p.is_file():sources["controller/"+str(p.relative_to(src))]=p
for pattern in ["native-fix-02*","python-tool-cache-01.json","python-tool-paths-02.json","preparation-complete.json"]:
    for p in sorted(src.glob(pattern)):
        if p.is_file():sources["controller/"+p.name]=p
for p in sorted(src.glob("*.py")):
    sources["runners/"+p.name]=p
review=root/"validation/prettier-root-review.json"
if review.is_file():sources["review/prettier-root-review.json"]=review
records=[]
contents={}
for original,p in sorted(sources.items()):
    st=p.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1:raise RuntimeError("non-regular or shared file: "+str(p))
    data=p.read_bytes()
    if p.stat().st_size!=st.st_size or p.stat().st_mtime_ns!=st.st_mtime_ns:raise RuntimeError("source record changed: "+str(p))
    member=original if len(original)<180 else "long/"+str(len(records)).zfill(6)
    if member in contents:raise RuntimeError("duplicate packed path")
    digest=hashlib.sha256(data).hexdigest()
    records.append({"path":member,"original_path":original,"bytes":len(data),"sha256":digest,"source_mode":oct(stat.S_IMODE(st.st_mode))})
    contents[member]=data
def encode(group):
    tarbytes=io.BytesIO()
    with tarfile.open(fileobj=tarbytes,mode="w",format=tarfile.PAX_FORMAT) as tar:
        for item in group:
            data=contents[item["path"]]
            info=tarfile.TarInfo(item["path"]);info.size=len(data);info.mode=0o644
            info.uid=0;info.gid=0;info.uname="";info.gname="";info.mtime=0
            tar.addfile(info,io.BytesIO(data))
    compressed=io.BytesIO()
    with gzip.GzipFile(fileobj=compressed,filename="",mode="wb",compresslevel=9,mtime=0) as f:f.write(tarbytes.getvalue())
    return compressed.getvalue()
groups=[]
def split(group):
    data=encode(group)
    if len(data)>=480000:
        if len(group)==1:raise RuntimeError("single record exceeds compressed part budget")
        middle=len(group)//2;split(group[:middle]);split(group[middle:]);return
    groups.append((group,data))
split(records)
parts=[]
for i,(group,data) in enumerate(groups):
    name=f"c{i:03}.tar.gz";(out/name).write_bytes(data)
    parts.append({"path":name,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"members":len(group)})
    for item in group:item["part"]=name
    with tarfile.open(fileobj=io.BytesIO(data),mode="r:gz") as tar:
        found=tar.getmembers()
        if [m.name for m in found]!=[r["path"] for r in group]:raise RuntimeError("archive member roster mismatch")
        for member,item in zip(found,group):
            if not member.isfile():raise RuntimeError("non-file member")
            restored=tar.extractfile(member).read()
            if len(restored)!=item["bytes"] or hashlib.sha256(restored).hexdigest()!=item["sha256"]:raise RuntimeError("archive member hash mismatch")
manifest={"schema":"hepta.closed-native-members.v2","scope":"Closed original controller receipts, failures, command scripts, and independently verified readbacks; original logs remain unchanged.","members":records}
manifest_bytes=(json.dumps(manifest,sort_keys=True,separators=(",",":"))+"\n").encode()
if len(manifest_bytes)>=480000:raise RuntimeError("manifest too large")
(out/"members.json").write_bytes(manifest_bytes)
index={"schema":"hepta.closed-native-controller-pack.v2","parts":parts,"members_manifest":{"path":"members.json","bytes":len(manifest_bytes),"sha256":hashlib.sha256(manifest_bytes).hexdigest()},"member_count":len(records),"total_member_bytes":sum(r["bytes"] for r in records),"max_member_path":max(len(r["path"]) for r in records),"tested_revision":"87cce8066b5f41e2d462b9469a301245f43d8c23","published_source_revision":"4ce8808d8b48624a17d247fdf47c7fbdaaab80a4","rust_tree":"3deb8503bc873331518c0c536a269c00d754a8bf"}
(out/"index.json").write_text(json.dumps(index,indent=2)+"\n")
print(json.dumps(index,indent=2))
