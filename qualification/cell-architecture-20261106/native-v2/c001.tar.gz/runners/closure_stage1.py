from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import stat
import subprocess
import sys
import time

ROOT = Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
SOURCE = ROOT / "source"
EVIDENCE = ROOT / "evidence" / "source-stage1"
EXPECTED = "73414467c27bf238757c733e9b5035746c77e14c"
EXPECTED_TREE = "8cbb206f47db9c841dd5a2e03c35aa9fb12e59ab"
ORIGINAL = "a6f3aa12ba187448c35449c7da0a9798ae4ca987"
BRANCH = "codex/cell-architecture-closure-20261106-9387"
PREFIX = "qualification/cell-unification-20261106"
LISTING = "c1e6d2104a3b33f7a37b600efd8468e2a169e7a5e624682ac6fe78a674ea6669"
TOOLBIN = Path("/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin")
ENV = os.environ.copy()
ENV.update({
    "PATH": str(TOOLBIN) + ":/home/qian-qi/.cargo/bin:" + ENV["PATH"],
    "RUSTUP_TOOLCHAIN": "1.96.0",
    "GIT_TERMINAL_PROMPT": "0",
    "PYTHONDONTWRITEBYTECODE": "1",
    "CARGO_TARGET_DIR": str(ROOT / "target"),
    "CARGO_BUILD_JOBS": "2",
    "NEXTEST_TEST_THREADS": "2",
    "CARGO_PROFILE_TEST_DEBUG": "0",
    "CARGO_PROFILE_DEV_DEBUG": "0",
    "CARGO_INCREMENTAL": "0",
    "CARGO_NET_GIT_FETCH_WITH_CLI": "true",
})
EVIDENCE.mkdir()
records = []

def save(name, obj):
    path = EVIDENCE / name
    with path.open("x") as stream:
        json.dump(obj, stream, indent=2)
        stream.write("\n")

def run(label, args, cwd=SOURCE, required=True, seconds=600):
    record = {"label": label, "command": args, "cwd": str(cwd), "started_unix_ns": time.time_ns()}
    print(json.dumps({"event": "start", **record}), flush=True)
    try:
        result = subprocess.run(args, cwd=cwd, env=ENV, capture_output=True, timeout=seconds)
        record.update(returncode=result.returncode, finished_unix_ns=time.time_ns())
        for name, data in (("stdout", result.stdout), ("stderr", result.stderr)):
            path = EVIDENCE / (label + "." + name + ".log")
            with path.open("xb") as stream:
                stream.write(data)
            record[name] = {"path": path.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        save(label + ".json", record)
        records.append(record)
        print(json.dumps({"event": "complete", **record}), flush=True)
        if required and result.returncode:
            raise RuntimeError(label + " failed: " + str(result.returncode))
        return result
    except subprocess.TimeoutExpired:
        record.update(timeout_seconds=seconds, finished_unix_ns=time.time_ns())
        save(label + ".timeout.json", record)
        records.append(record)
        raise

def git(label, *args, required=True):
    return run(label, ["git", *args], required=required).stdout.decode().strip()

def head(label):
    return git(label, "rev-parse", "HEAD", "HEAD^{tree}", "HEAD:codex-rs").splitlines()

def push(label, previous):
    observed = git(label + "-remote-before", "ls-remote", "--exit-code", "origin", "refs/heads/" + BRANCH)
    if observed.split()[0] != previous:
        raise RuntimeError("remote branch moved before " + label + ": " + observed)
    git(label, "push", "origin", "HEAD:refs/heads/" + BRANCH)
    result = git(label + "-remote-after", "ls-remote", "--exit-code", "origin", "refs/heads/" + BRANCH).split()[0]
    if result != head(label + "-local-after")[0]:
        raise RuntimeError("push readback mismatch")
    return result

state = {"expected": EXPECTED, "original": ORIGINAL, "branch": BRANCH, "scope": "source archive and formatter stages only; no native build"}
save("started.json", state)
try:
    if git("initial-clean", "status", "--porcelain"):
        raise RuntimeError("source not clean at start")
    if head("initial-head")[0] != ORIGINAL:
        raise RuntimeError("prepared source is no longer the expected original")
    git("fetch-source", "fetch", "--depth=1", "origin", EXPECTED)
    git("checkout-source", "switch", "-c", BRANCH, EXPECTED)
    identity = head("source-before")
    if identity[:2] != [EXPECTED, EXPECTED_TREE]:
        raise RuntimeError("candidate identity mismatch")
    if git("candidate-clean", "status", "--porcelain"):
        raise RuntimeError("candidate is dirty")
    original_root = ROOT / "archive-original"
    packed_root = ROOT / "archive-packed-v1"
    restored_root = ROOT / "archive-restored-v1"
    if any(path.exists() or path.is_symlink() for path in (original_root, packed_root, restored_root)):
        raise RuntimeError("an archive preparation destination already exists")
    git("original-worktree", "-c", "core.autocrlf=false", "worktree", "add", "--detach", str(original_root), ORIGINAL)
    script = SOURCE / "scripts/hepta_evidence_archive.py"
    spec = importlib.util.spec_from_file_location("hepta_archive", script)
    archive = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(archive)
    migration = json.loads((SOURCE / PREFIX / "MIGRATION.json").read_text())
    old_members = archive.git_members(original_root, ORIGINAL, PREFIX)
    save("original-roster.json", old_members)
    index = archive.pack(original_root, ORIGINAL, PREFIX, packed_root)
    index_sha = hashlib.sha256((packed_root / "index.json").read_bytes()).hexdigest()
    save("packed-index-observation.json", {"index_sha256": index_sha, "index": index})
    if index_sha != migration["archive_index_sha256"] or index["payload_sha256"] != migration["payload_sha256"]:
        raise RuntimeError("deterministic archive differs from frozen migration identity")
    verification = archive.verify(packed_root, original_root, ORIGINAL, expected_listing=LISTING)
    save("archive-verified.json", verification)
    restore = archive.verify(packed_root, original_root, ORIGINAL, destination=restored_root, expected_listing=LISTING)
    verified_count, verified_bytes = 0, 0
    for member in old_members:
        restored = restored_root / member["path"]
        data = restored.read_bytes()
        digest = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        mode = "100755" if restored.stat().st_mode & stat.S_IXUSR else "100644"
        if digest != member["git_blob"] or mode != member["mode"]:
            raise RuntimeError("restored original mismatch: " + member["path"])
        if data != (original_root / member["path"]).read_bytes():
            raise RuntimeError("restored original bytes differ: " + member["path"])
        verified_count += 1
        verified_bytes += len(data)
    actual_files = {p.relative_to(restored_root).as_posix() for p in restored_root.rglob("*") if p.is_file()}
    if actual_files != {member["path"] for member in old_members}:
        raise RuntimeError("restored roster differs")
    save("restore-byte-mode-comparison.json", {
        "original": ORIGINAL, "listing_sha256": LISTING,
        "member_count": verified_count, "bytes": verified_bytes,
        "all_blob_ids_equal": True, "all_file_bytes_equal": True, "all_git_modes_equal": True,
        "restore": restore,
    })
    current = {item["path"]: item for item in archive.git_members(SOURCE, EXPECTED, PREFIX)}
    removals = []
    for member in old_members:
        name = member["path"]
        if name in {PREFIX + "/README.md", PREFIX + "/MIGRATION.json"} or name.startswith(PREFIX + "/failures/"):
            continue
        if name not in current:
            continue
        if current[name] != member:
            raise RuntimeError("candidate changed an original selected for archival: " + name)
        path = SOURCE / name
        data = path.read_bytes()
        if hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() != member["git_blob"]:
            raise RuntimeError("selected source file changed before removal")
        removals.append(name)
    save("mechanical-removal-roster.json", removals)
    for name in removals:
        (SOURCE / name).unlink()
    destination = SOURCE / PREFIX / "archive"
    shutil.copytree(packed_root, destination)
    git("stage-archive", "add", "--all", "--", PREFIX)
    git("stage-archive-parts", "add", "-f", "--", str(destination.relative_to(SOURCE)))
    staged_tree = git("archive-staged-tree", "write-tree")
    staged_archive = archive.git_members(SOURCE, staged_tree, PREFIX + "/archive")
    if {p["path"].removeprefix(PREFIX + "/archive/") for p in staged_archive} != {p.name for p in packed_root.iterdir()}:
        raise RuntimeError("staged archive roster incomplete")
    checkout = archive.check_tree(SOURCE, staged_tree, 190, 512000, PREFIX)
    save("archive-checkout-budget.json", checkout)
    git("archive-whitespace", "diff", "--cached", "--check")
    git("archive-commit", "commit", "-m", "chore(evidence): preserve Cell originals in bounded verified archive")
    archive_sha = push("archive-push", EXPECTED)
    state["archive_identity"] = head("archive-identity")
    state["archive_push_sha"] = archive_sha
    save("archive-published.json", state)
    print(json.dumps({"event": "archive_published", "sha": archive_sha, "tree": state["archive_identity"][1]}), flush=True)
    rust_before = head("format-before")
    run("rust-fmt-original-check-before", ["cargo", "fmt", "--", "--config", "imports_granularity=Item", "--check"], cwd=SOURCE/"codex-rs", required=False)
    run("rust-fmt-repair", ["cargo", "fmt", "--", "--config", "imports_granularity=Item"], cwd=SOURCE/"codex-rs")
    run("just-fmt", ["just", "fmt"], cwd=SOURCE/"codex-rs")
    run("rust-fmt-original-check-after", ["cargo", "fmt", "--", "--config", "imports_granularity=Item", "--check"], cwd=SOURCE/"codex-rs")
    paths = git("format-changed-paths", "diff", "--name-only").splitlines()
    if any(not (path.startswith("codex-rs/") and path.endswith(".rs")) for path in paths):
        raise RuntimeError("formatter changed files outside the permitted Rust-only stage")
    save("format-stage.json", {"before": rust_before, "changed_paths": paths, "changed_count": len(paths)})
    if paths:
        git("stage-format", "add", "--", *paths)
        git("format-whitespace", "diff", "--cached", "--check")
        git("format-commit", "commit", "-m", "style(rust): apply the pinned full-workspace formatter")
        format_sha = push("format-push", archive_sha)
    else:
        format_sha = archive_sha
    if git("final-clean", "status", "--porcelain"):
        raise RuntimeError("source is dirty after formatting")
    state.update(outcome="source_ready_no_native_build_started", final_identity=head("final-identity"), format_push_sha=format_sha, formatted_paths=paths, records=records)
    save("complete.json", state)
    print(json.dumps({"event": "source_ready", "identity": state["final_identity"], "formatted_paths": paths}), flush=True)
except Exception as error:
    state.update(outcome="failed", error={"type": type(error).__name__, "message": str(error)}, records=records)
    save("failure.json", state)
    print(json.dumps({"event": "failed", "error": state["error"]}), flush=True)
    raise
