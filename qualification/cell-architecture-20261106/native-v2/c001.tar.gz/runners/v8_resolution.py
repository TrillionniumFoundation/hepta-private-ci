from pathlib import Path
import hashlib
import importlib
import json
import os
import shutil
import sys
import time

sys.dont_write_bytecode = True
root = Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source = root / "source"
evidence = root / "evidence" / "v8-resolution"
evidence.mkdir()
cache = root / "v8-resolver"
cache.mkdir()
names = (
    "librusty_v8_ptrcomp_sandbox_release_x86_64-unknown-linux-gnu.a.gz",
    "src_binding_ptrcomp_sandbox_release_x86_64-unknown-linux-gnu.rs",
)
observed = Path("/data/rusty-v8-v150.4.0-independent")
expected = (
    "a35c75d1f26e6a983885a45b33490a4ebe54f05050568b32b89cfb421b30b583",
    "7727826ae479bdb645e807239fb12d1f8e2e23de7a6cf16f5ee592690d1d8506",
)
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()
state = {
    "started_unix_ns": time.time_ns(),
    "source_files": {str(path.relative_to(source)): sha(path) for path in (
        source / "scripts/codex_package/v8.py",
        source / "scripts/codex_package/targets.py",
        source / "codex-rs/Cargo.lock",
    )},
    "original_observed_material": [],
}
destination = cache / "rusty-v8-150.4.0-x86_64-unknown-linux-gnu"
destination.mkdir()
for name, digest in zip(names, expected):
    path = observed / name
    if sha(path) != digest:
        raise RuntimeError("observed original V8 material changed")
    state["original_observed_material"].append({"path": str(path), "bytes": path.stat().st_size, "sha256": digest})
    shutil.copyfile(path, destination / name)
sys.path.insert(0, str(source / "scripts"))
v8 = importlib.import_module("codex_package.v8")
targets = importlib.import_module("codex_package.targets")
try:
    pair = v8.fetch_codex_v8_artifacts(targets.TARGET_SPECS["x86_64-unknown-linux-gnu"], cache_root=cache)
    state["official_release_checksum_verified"] = True
    checksums = destination / "rusty_v8_ptrcomp_sandbox_release_x86_64-unknown-linux-gnu.sha256"
    shutil.copyfile(checksums, evidence / checksums.name)
    state["official_checksum_file"] = {
        "url": "https://github.com/openai/codex/releases/download/rusty-v8-v150.4.0/" + checksums.name,
        "sha256": sha(checksums),
        "bytes": checksums.stat().st_size,
        "contents": checksums.read_text(),
    }
    paths = (pair.archive, pair.binding)
except Exception as error:
    state["official_release_checksum_verified"] = False
    state["official_check_error"] = {"type": type(error).__name__, "message": str(error)}
    paths = tuple(observed / name for name in names)
    state["scope"] = "Observed pinned pair only; official release verification did not succeed."
state["environment"] = dict(zip(("RUSTY_V8_ARCHIVE", "RUSTY_V8_SRC_BINDING_PATH"), map(str, paths)))
state["resolved_material"] = [{"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)} for path in paths]
state["finished_unix_ns"] = time.time_ns()
with (evidence / "result.json").open("x") as stream:
    json.dump(state, stream, indent=2)
    stream.write("\n")
print(json.dumps(state, indent=2))
