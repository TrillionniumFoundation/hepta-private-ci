from pathlib import Path
import base64,hashlib,importlib.util,json,os,re,subprocess,sys,tarfile,time
sys.dont_write_bytecode=True
root=Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source"
evidence=root/"evidence"/"formatter-tool-prepare-01"
evidence.mkdir()
tool_root=root/"tools"
tool_root.mkdir(exist_ok=True)
bin_dir=tool_root/"bin";bin_dir.mkdir(exist_ok=True)
env=os.environ.copy()
env.update({"COREPACK_HOME":str(tool_root/"corepack-cache"),"npm_config_cache":str(tool_root/"npm-cache"),"UV_PROJECT_ENVIRONMENT":str(root/"python-scripts-env"),"PYTHONDONTWRITEBYTECODE":"1"})
env["PATH"]=str(bin_dir)+":/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/.cargo/bin:"+env["PATH"]
uv=Path("/home/qian-qi/work/hepta-pq-effect-v4-20261105-93bfcf/tools/uv-0.11.3/bin/uv")
records=[]
def sha(path,algorithm="sha256"):
    with Path(path).open("rb") as stream:return hashlib.file_digest(stream,algorithm).hexdigest()
def run(label,command,cwd=source,timeout=300):
    print(json.dumps({"event":"tool_preparation_command_started","label":label,"command":command}),flush=True)
    p=subprocess.run(command,cwd=cwd,env=env,capture_output=True,timeout=timeout,check=False)
    for stream in ("stdout","stderr"):
        (evidence/(label+"."+stream+".log")).write_bytes(getattr(p,stream))
    row={"label":label,"command":command,"returncode":p.returncode,"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest()}
    records.append(row)
    (evidence/(label+".json")).write_text(json.dumps(row,indent=2)+"\n")
    print(json.dumps({"event":"tool_preparation_command_complete",**row}),flush=True)
    if p.returncode: raise RuntimeError(label+" failed")
    return p.stdout.decode()
def git(*args):return subprocess.check_output(["git",*args],cwd=source,text=True).strip()
before={"head":git("rev-parse","HEAD"),"status":git("status","--porcelain")}
if before["head"]!="b4afdbadc247c6fadfad4e416c00a9a853affa1c" or before["status"]:
    raise RuntimeError("source moved before tool-only preparation")
package=json.loads((source/"package.json").read_text())
pnpm=package["packageManager"]
if not pnpm.startswith("pnpm@10.34.5+sha512."):raise RuntimeError("unexpected package-manager pin")
run("corepack-install-pnpm",["/usr/bin/corepack","install","--global",pnpm],cwd=tool_root)
run("corepack-enable-pnpm",["/usr/bin/corepack","enable","--install-directory",str(bin_dir),"pnpm"],cwd=tool_root)
version=run("pnpm-version",[str(bin_dir/"pnpm"),"--version"]).strip()
if version!="10.34.5":raise RuntimeError("resolved pnpm differs from repository pin")
lock=(source/"pnpm-lock.yaml").read_text()
match=re.search(r"(?m)^  prettier@3\\.5\\.3:\\n    resolution: \\{integrity: ([^}]+)\\}",lock)
if match is None:
    match=re.search(r"(?m)^  prettier@3\.5\.3:\n    resolution: \{integrity: ([^}]+)\}",lock)
if match is None:raise RuntimeError("root lock Prettier integrity not found")
integrity=match.group(1).strip().strip("'\"")
downloads=tool_root/"prettier-download";downloads.mkdir()
packed=json.loads(run("pack-prettier",["/usr/bin/npm","pack","prettier@3.5.3","--ignore-scripts","--json","--pack-destination",str(downloads)],cwd=downloads))
if len(packed)!=1:raise RuntimeError("expected one Prettier archive")
archive=downloads/packed[0]["filename"]
algorithm,wanted=integrity.split("-",1)
with archive.open("rb") as stream:
    observed=base64.b64encode(hashlib.file_digest(stream,algorithm).digest()).decode()
if observed!=wanted or packed[0]["integrity"]!=integrity:
    raise RuntimeError("Prettier archive differs from original lock integrity")
destination=tool_root/"prettier-3.5.3";destination.mkdir()
with tarfile.open(archive,"r:gz") as tar:
    for member in tar.getmembers():
        if not member.name.startswith("package/") or member.issym() or member.islnk():
            raise RuntimeError("unexpected package member")
    tar.extractall(destination,filter="data")
prettier=destination/"package/bin/prettier.cjs"
os.symlink(prettier,bin_dir/"prettier")
pversion=run("prettier-version",["/usr/bin/node",str(prettier),"--version"]).strip()
if pversion!="3.5.3":raise RuntimeError("Prettier version mismatch")
run("uv-sync", [str(uv),"sync","--frozen","--project","scripts"])
rversion=run("ruff-version",[str(uv),"run","--frozen","--project","scripts","ruff","--version"]).strip()
if rversion!="ruff 0.15.13":raise RuntimeError("Ruff differs from original lock")
spec=importlib.util.spec_from_file_location("observed_repo_format",source/"scripts/format.py")
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
base="a6f3aa12ba187448c35449c7da0a9798ae4ca987"
groups=module.scoped_formatter_groups(module.changed_paths(base),check=True,base=base)
group_records=[{"name":g.name,"commands":[{"arguments":list(c.args),"cwd":str(c.cwd)} for c in g.commands]} for g in groups]
(evidence/"original-formatter-plan.json").write_text(json.dumps(group_records,indent=2)+"\n")
buildifier=source/"tools/buildifier"
after={"head":git("rev-parse","HEAD"),"status":git("status","--porcelain")}
if after!=before:raise RuntimeError("tool preparation changed source identity")
result={"outcome":"prepared","source_before":before,"source_after":after,"commands":records,"tool_environment":{key:env[key] for key in ("COREPACK_HOME","npm_config_cache","UV_PROJECT_ENVIRONMENT","PATH")},"pnpm":{"version":version,"pin":pnpm,"command":str(bin_dir/"pnpm")},"prettier":{"version":pversion,"archive":str(archive),"archive_sha256":sha(archive),"lock_integrity":integrity,"entry":str(prettier),"entry_sha256":sha(prettier)},"ruff":{"version":rversion,"uv":str(uv),"uv_sha256":sha(uv)},"buildifier_descriptor":{"path":str(buildifier),"exists":buildifier.is_file(),"sha256":sha(buildifier) if buildifier.is_file() else None},"formatter_groups":[{"name":g["name"],"command_count":len(g["commands"])} for g in group_records],"finished_unix_ns":time.time_ns(),"scope":"Install original pinned tools into task-owned environment; no product source or format/test gate modified"}
(evidence/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"event":"formatter_tools_prepared",**result}),flush=True)
