from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
root=Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source";gates=root/"evidence/native-final-gates-08";gates.mkdir()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(directory,name,data):
    with (directory/name).open("x") as f:json.dump(data,f,indent=2);f.write("\n")
def git(*args):return subprocess.check_output(["git",*args],cwd=source,text=True).strip()
def identity():return {"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"rust_tree":git("rev-parse","HEAD:codex-rs"),"status":git("status","--porcelain")}
committed=identity()
if (committed["head"],committed["tree"],committed["rust_tree"],committed["status"])!=("87cce8066b5f41e2d462b9469a301245f43d8c23","60604de0d6ea4805fd248574ba83fe49f16b261a","3deb8503bc873331518c0c536a269c00d754a8bf",""):raise RuntimeError("native tests require exact frozen published source")
nextest_binary=root/"tools/nextest-0.9.103/bin/cargo-nextest"
verification=root/"evidence/nextest-tool-06/version-check-01/result.json"
if sha(nextest_binary)!="e999c122a02c3fe74a1b66d254b6419a8a665e8bf540b1d31de7933a6d3753f1" or sha(verification)!="a3e64bad22fe31cc8edb7fa992176e60ba9b59d93e56de2cdfcbdfd02ed57a96":raise RuntimeError("official nextest verification identity changed")
write(gates,"nextest-binding.json",{"binary":str(nextest_binary),"binary_sha256":sha(nextest_binary),"official_verification_record":str(verification),"official_verification_record_sha256":sha(verification)})
v8=json.loads((root/"evidence/v8-resolution-02/result.json").read_text())
if not v8["official_release_checksum_verified"]:raise RuntimeError("V8 official verification missing")
for item in v8["resolved_material"]:
    if sha(item["path"])!=item["sha256"]:raise RuntimeError("V8 material changed")
overrides={"PATH":str(nextest_binary.parent)+":/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/.cargo/bin:"+os.environ["PATH"],"RUSTUP_TOOLCHAIN":"1.96.0","PYTHONDONTWRITEBYTECODE":"1","CARGO_TARGET_DIR":str(root/"target"),"CARGO_BUILD_JOBS":"2","NEXTEST_TEST_THREADS":"2","CARGO_PROFILE_TEST_DEBUG":"0","CARGO_PROFILE_DEV_DEBUG":"0","CARGO_INCREMENTAL":"0","CARGO_NET_GIT_FETCH_WITH_CLI":"true","PROTOC":"/usr/bin/protoc","PROTOC_INCLUDE":"/usr/include","CODEX_REPO_ROOT":str(source),"HEPTA_CI_LANE":"source-head","SOURCE_SHA":committed["head"],"TESTED_SHA":committed["head"],"BASE_SHA":"a6f3aa12ba187448c35449c7da0a9798ae4ca987",**v8["environment"]}
os.environ.update(overrides)
tool=subprocess.run(["cargo","nextest","--version"],cwd=source,capture_output=True,text=True,timeout=30,check=False)
write(gates,"nextest-version.json",{"command":["cargo","nextest","--version"],"returncode":tool.returncode,"stdout":tool.stdout,"stderr":tool.stderr})
if tool.returncode or not tool.stdout.startswith("cargo-nextest 0.9.103"):
    raise RuntimeError("original nextest 0.9.103 tool is not available")
packages=["-p","codex-hepta-neuron","-p","codex-hepta-automation","-p","codex-hepta-runtime","-p","codex-hepta-agentd"]
commands=[("tests",4200,1,["just","test","--locked",*packages,"--retries","0"]),("clippy",900,0,["just","clippy","--locked",*packages,"--","-D","warnings"])]
sequence={"source":committed,"environment_overrides":overrides,"started_unix_ns":time.time_ns(),"helper_sha256":sha(source/"scripts/hepta_ci_exec.py"),"run_nextest_sha256":sha(source/"scripts/run-nextest.py"),"justfile_sha256":sha(source/"justfile"),"cargo_lock_sha256":sha(source/"codex-rs/Cargo.lock"),"gates":[]}
write(gates,"started.json",sequence)
for name,timeout,minimum,command in commands:
    output=gates/(name+".json")
    args=["python3","scripts/hepta_ci_exec.py","--timeout-seconds",str(timeout),"--minimum-tests",str(minimum),"--output",str(output),"--",*command]
    print(json.dumps({"event":"native_gate_started","label":name,"identity":committed,"command":args}),flush=True)
    p=subprocess.run(args,cwd=source,check=False)
    result=json.loads(output.read_text()) if output.is_file() else {"status":"missing"}
    sequence["gates"].append({"label":name,"wrapper_returncode":p.returncode,"record":result})
    print(json.dumps({"event":"native_gate_terminal","label":name,"wrapper_returncode":p.returncode,"status":result.get("status"),"observed_passed_tests":result.get("observed_passed_tests"),"observed_failed_tests":result.get("observed_failed_tests")}),flush=True)
    if p.returncode:break
sequence["finished_unix_ns"]=time.time_ns();sequence["source_after"]=identity()
sequence["outcome"]="passed" if len(sequence["gates"])==2 and all(g["wrapper_returncode"]==0 and g["record"].get("status")=="passed" for g in sequence["gates"]) else "failed"
write(gates,"result.json",sequence)
print(json.dumps({"event":"native_gate_sequence_complete","outcome":sequence["outcome"],"source_after":sequence["source_after"]}),flush=True)
raise SystemExit(0 if sequence["outcome"]=="passed" else 1)
