from pathlib import Path
import ast,hashlib,importlib.util,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
root=Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source";evidence=root/"evidence/native-r4-format-04";evidence.mkdir()
old="6475f08304274cf32768f65011f1e1ca2fcc9452"
new="8d86de32cb0d22367eaab7994f49515187cf71d3"
tree="d0290a0cb7812b1f093b99e4148b6087fb37283b"
rust="3deb8503bc873331518c0c536a269c00d754a8bf"
base="a6f3aa12ba187448c35449c7da0a9798ae4ca987"
patch=root/"evidence/native-fix-format-03/changes.patch"
patch_sha="7fcfb5d6b536892833427d4e5b73476370cc1f186b94ce595980e526738b514f"
expected_python={"scripts/hepta_typed_callers.py":"8216714b487796958ab117ff5a3ede765eb2b70308208d5adc0f544b4b9c880e","scripts/test_hepta_typed_callers.py":"a2780171c547993e5f36f3bdd0631254cf3a8634499659d68e1438e07ff1a3aa"}
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(name,data):
    with (evidence/name).open("x") as f:json.dump(data,f,indent=2);f.write("\n")
def git(*args):return subprocess.check_output(["git",*args],cwd=source,text=True).strip()
def ident():return {"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"rust_tree":git("rev-parse","HEAD:codex-rs"),"status":git("status","--porcelain")}
def command(label,args,timeout=300):
    p=subprocess.run(args,cwd=source,capture_output=True,timeout=timeout,check=False)
    for channel in ("stdout","stderr"):(evidence/(label+"."+channel+".log")).write_bytes(getattr(p,channel))
    write(label+".json",{"command":args,"returncode":p.returncode})
    if p.returncode:raise RuntimeError(label+" failed")
    return p.stdout
before=ident();write("before-reversal.json",before)
current=subprocess.check_output(["git","diff","--binary"],cwd=source)
if before["head"]!=old or sha(patch)!=patch_sha or hashlib.sha256(current).hexdigest()!=patch_sha:
    raise RuntimeError("original 03 patch or working source changed")
known=json.loads((root/"evidence/native-fix-format-03/result.json").read_text())["patch"]["paths"]
if git("diff","--name-only").splitlines()!=known or git("ls-files","--others","--exclude-standard"):
    raise RuntimeError("unexpected worktree material before exact patch reversal")
command("reverse-check",["git","apply","--reverse","--check",str(patch)])
command("reverse-original-03",["git","apply","--reverse",str(patch)])
restored=ident();write("restored-6475.json",restored)
if restored["head"]!=old or restored["status"]:raise RuntimeError("original source not clean after exact reversal")
command("fetch-8d86",["git","fetch","--depth=64","origin",new])
command("ff-8d86",["git","merge","--ff-only",new])
bound=ident();write("bound-source.json",bound)
if (bound["head"],bound["tree"],bound["rust_tree"],bound["status"])!=(new,tree,rust,""):
    raise RuntimeError("new source does not match root's exact published identities")
ast_before={}
for relative,digest in expected_python.items():
    path=source/relative
    if sha(path)!=digest:raise RuntimeError("r4 Python input differs from reviewed source")
    ast_before[relative]=ast.dump(ast.parse(path.read_text()),include_attributes=False)
uv=Path("/home/qian-qi/work/hepta-pq-effect-v4-20261105-93bfcf/tools/uv-0.11.3/bin/uv")
os.environ.update({"PATH":"/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:"+str(uv.parent)+":/home/qian-qi/.cargo/bin:"+os.environ["PATH"],"RUSTUP_TOOLCHAIN":"1.96.0","PYTHONDONTWRITEBYTECODE":"1","UV_PROJECT_ENVIRONMENT":str(root/"python-scripts-env"),"CODEX_REPO_ROOT":str(source),"CARGO_TARGET_DIR":str(root/"target")})
helper_path=source/"scripts/hepta_ci_exec.py"
spec=importlib.util.spec_from_file_location("hepta_ci_exec",helper_path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
state={"label":"native-r4-format-04","started_unix_ns":time.time_ns(),"source_before":bound,"original_03_patch_sha256":patch_sha,"python_before":expected_python,"helper_sha256":sha(helper_path),"commands":[],"scope":"Reviewed source handoff and repository-pinned r4 formatting only; no tests or publishing"}
write("started.json",state);print(json.dumps({"event":"r4_format_started",**state}),flush=True)
os.chdir(source)
for label,args in (("fmt-pr",["just","fmt","--base",base]),("fmt-pr-check",["just","fmt","--base",base,"--check"])):
    run=helper.execute_logged(args,evidence/(label+".log"),timeout_seconds=600)
    row={"label":label,"command":args,**run};write(label+".json",row);state["commands"].append(row)
    print(json.dumps({"event":"r4_format_command_complete",**row}),flush=True)
    if run["returncode"] or run["timed_out"] or run["output_limit_exceeded"]:raise RuntimeError(label+" failed")
changed=git("diff","--name-only").splitlines()
if not set(changed)<=set(expected_python):raise RuntimeError("formatter changed an unreviewed owner")
after=ident()
if after["head"]!=new or after["rust_tree"]!=rust or git("diff","--name-only","--","codex-rs"):raise RuntimeError("Rust bytes changed in Python-only formatting stage")
python_after={}
for relative,original_ast in ast_before.items():
    path=source/relative
    current_ast=ast.dump(ast.parse(path.read_text()),include_attributes=False)
    if current_ast!=original_ast:raise RuntimeError("Python AST changed during formatting")
    python_after[relative]={"sha256":sha(path),"ast_sha256":hashlib.sha256(current_ast.encode()).hexdigest(),"ast_identical":True}
diff=subprocess.check_output(["git","diff","--binary"],cwd=source);(evidence/"r4-format.patch").write_bytes(diff)
state.update({"source_after":after,"python_after":python_after,"changed_paths":changed,"patch":{"bytes":len(diff),"sha256":hashlib.sha256(diff).hexdigest()},"finished_unix_ns":time.time_ns(),"outcome":"needs_source_review" if diff else "source_ready"})
write("result.json",state);print(json.dumps({"event":"r4_format_complete",**state}),flush=True)
