from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
root=Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source";stage=root/"format-review-09";stage.mkdir()
before_dir=stage/"before";before_dir.mkdir();after_dir=stage/"after";after_dir.mkdir()
out=root/"evidence/prettier-format-09";out.mkdir()
expected="87cce8066b5f41e2d462b9469a301245f43d8c23"
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(["git",*args],cwd=source,text=True).strip()
def identity():return {"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"rust_tree":git("rev-parse","HEAD:codex-rs"),"status":git("status","--porcelain")}
original=identity()
if original["head"]!=expected or original["status"]:raise RuntimeError("frozen active source differs")
attribution=json.loads((root/"evidence/text-failure-attribution-09/result.json").read_text())
if not attribution["all_failed_paths_identical_to_original_base"]:raise RuntimeError("failure attribution differs")
paths=sorted(item["path"] for item in attribution["failed_paths"]["prettier"])
if len(paths)!=31:raise RuntimeError("formatting roster differs")
tracked=set(git("ls-files").splitlines())
ancestors={Path(".")}
for name in paths:ancestors.update(Path(name).parents)
config_names={"package.json","pnpm-lock.yaml",".editorconfig",".prettierignore","AGENTS.md"}
configs=sorted(name for name in tracked if Path(name).parent in ancestors and (Path(name).name in config_names or Path(name).name.startswith(".prettierrc") or Path(name).name.startswith("prettier.config.")))
copied=[]
for name in sorted(set(paths+configs)):
    data=subprocess.check_output(["git","show",expected+":"+name],cwd=source)
    if data!=(source/name).read_bytes():raise RuntimeError("active source file differs from commit")
    for destination in [before_dir,after_dir]:
        p=destination/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    copied.append({"path":name,"blob":git("rev-parse",expected+":"+name),"bytes":len(data),"sha256":sha(data),"kind":"target" if name in paths else "configuration"})
(out/"inputs.json").write_text(json.dumps({"source":original,"files":copied},indent=2)+"\n")
(out/"roster.json").write_text(json.dumps(paths,indent=2)+"\n")
plugin=root/"tools/prettier-3.5.3-observed/plugins/babel.mjs"
entry=root/"tools/prettier-3.5.3-observed/bin/prettier.cjs"
cache=json.loads((root/"evidence/native-python-text-07/prettier-cache.json").read_text())
for member in cache["members"]:
    if sha((root/"tools/prettier-3.5.3-observed"/member["path"]).read_bytes())!=member["sha256"]:raise RuntimeError("observed formatter cache changed")
commands=[]
def run(label,args,cwd=after_dir,check=True):
    started=time.time_ns()
    p=subprocess.run(args,cwd=cwd,capture_output=True,check=False,timeout=120)
    (out/(label+".stdout.log")).write_bytes(p.stdout);(out/(label+".stderr.log")).write_bytes(p.stderr)
    rec={"label":label,"command":args,"cwd":str(cwd),"returncode":p.returncode,"started_unix_ns":started,"finished_unix_ns":time.time_ns(),"stdout_sha256":sha(p.stdout),"stderr_sha256":sha(p.stderr)}
    (out/(label+".json")).write_text(json.dumps(rec,indent=2)+"\n")
    commands.append(rec)
    print(json.dumps({"event":"format_review_command","label":label,"returncode":p.returncode}),flush=True)
    if check and p.returncode:raise RuntimeError(label+" failed")
    return p.stdout
run("git-init",["git","init","--quiet"])
run("git-stage-originals",["git","add","--",*sorted(set(paths+configs))])
run("format-targets",["/usr/bin/node",str(entry),"--write",*paths])
run("check-targets",["/usr/bin/node",str(entry),"--check",*paths])
helper=out/"ast-compare.mjs";helper.write_text("import fs from \"node:fs\";\nimport path from \"node:path\";\nimport crypto from \"node:crypto\";\nimport {pathToFileURL} from \"node:url\";\nconst [plugin, before, after, rosterFile, output] = process.argv.slice(2);\nconst {parsers} = await import(pathToFileURL(plugin).href);\nconst excluded = new Set([\"start\", \"end\", \"loc\", \"range\", \"comments\", \"leadingComments\", \"trailingComments\", \"innerComments\", \"tokens\", \"extra\", \"raw\"]);\nfunction normalize(value) {\n  if (Array.isArray(value)) return value.map(normalize);\n  if (value !== null && typeof value === \"object\") {\n    return Object.fromEntries(Object.keys(value).sort().filter(key => !excluded.has(key)).map(key => [key, normalize(value[key])]));\n  }\n  return value;\n}\nconst digest = value => crypto.createHash(\"sha256\").update(value).digest(\"hex\");\nconst paths = JSON.parse(fs.readFileSync(rosterFile, \"utf8\"));\nconst records = [];\nfor (const name of paths) {\n  const original = fs.readFileSync(path.join(before, name), \"utf8\");\n  const formatted = fs.readFileSync(path.join(after, name), \"utf8\");\n  const left = await parsers.babel.parse(original, {filepath:name});\n  const right = await parsers.babel.parse(formatted, {filepath:name});\n  if ((left.errors?.length ?? 0) || (right.errors?.length ?? 0)) throw new Error(\"Parser errors in \" + name);\n  const a = JSON.stringify(normalize(left));\n  const b = JSON.stringify(normalize(right));\n  records.push({path:name,before_sha256:digest(original),after_sha256:digest(formatted),before_ast_sha256:digest(a),after_ast_sha256:digest(b),ast_equal:a===b,before_comments:left.comments?.length??null,after_comments:right.comments?.length??null});\n}\nconst result={parser:\"Prettier 3.5.3 bundled babel\",excluded_layout_fields:[...excluded].sort(),scope:\"Recursive sorted-key AST comparison, excluding layout/raw/comment metadata; literal values and all other semantic nodes retained.\",all_ast_equal:records.every(r=>r.ast_equal),files:records};\nfs.writeFileSync(output,JSON.stringify(result,null,2)+\"\\n\",{flag:\"wx\"});\nconsole.log(JSON.stringify({files:records.length,all_ast_equal:result.all_ast_equal}));\nif (!result.all_ast_equal) process.exitCode=1;\n")
run("compare-ast",["/usr/bin/node",str(helper),str(plugin),str(before_dir),str(after_dir),str(out/"roster.json"),str(out/"ast-result.json")])
changed=run("changed-paths",["git","diff","--name-only"]).decode().splitlines()
if sorted(changed)!=paths:raise RuntimeError("formatter changed unexpected paths")
patch=run("patch",["git","diff","--binary"])
(out/"changes.patch").write_bytes(patch)
run("whitespace",["git","diff","--check"])
ast=json.loads((out/"ast-result.json").read_text())
if not ast["all_ast_equal"]:raise RuntimeError("formatter AST changed")
files=[]
for rec in ast["files"]:
    name=rec["path"]
    data=(after_dir/name).read_bytes()
    blob=subprocess.check_output(["git","hash-object","--stdin"],cwd=after_dir,input=data).decode().strip()
    files.append({**rec,"before_blob":git("rev-parse",expected+":"+name),"after_blob":blob,"before_bytes":(before_dir/name).stat().st_size,"after_bytes":len(data)})
final=identity()
if final!=original:raise RuntimeError("active source changed during isolated formatting")
result={"scope":"Independent copy only; no active source/ref mutation; 31 pre-existing JavaScript formatting failures repaired by exact observed Prettier 3.5.3, original failed gate preserved.","source_before":original,"source_after":final,"prettier_entry_sha256":sha(entry.read_bytes()),"babel_plugin_sha256":sha(plugin.read_bytes()),"files":files,"all_ast_equal":ast["all_ast_equal"],"patch_bytes":len(patch),"patch_sha256":sha(patch),"commands":commands,"finished_unix_ns":time.time_ns()}
(out/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"event":"prettier_review_complete","files":len(files),"all_ast_equal":True,"patch_bytes":len(patch),"patch_sha256":sha(patch),"source":final}),flush=True)
