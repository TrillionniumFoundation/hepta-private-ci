from pathlib import Path
import hashlib,json,os,re,shlex,subprocess,time,urllib.parse
root=Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source";repo=root/"merge-review/repository.git";out=root/"evidence/final-source-integration-10";out.mkdir()
expected="87cce8066b5f41e2d462b9469a301245f43d8c23";base="e01c860f9b43a88555dfe9120a86f7f451e760fd";merge="151dfe3d97fbe186269a2d6333ec04dbf665bde9";rust="3deb8503bc873331518c0c536a269c00d754a8bf"
branch="codex/cell-architecture-closure-20261106-9387";base_branch="work/cell-unification-20261106"
inputs={"scripts/hepta_typed_callers.py":"0774d796759876fab1873a2a1dcbb4c91210533d34edbe32707fb8f52b9d569c","scripts/test_hepta_typed_callers.py":"059d636fe604217c7c01975e50c5d8a3074445fd5bc31ef8652b09220c4dd0d5","scripts/verify_hepta_callers.py":"ff62f959e78225aa198ec73d0cfe3747bab3a85f80e58fccec7857e407486f71","CALLERS.toml":"715df436da33503674ca02453360d1f03e2d919c2fd8d9e059eca9efd90be0ee","qa/b4-no-bypass/KERNEL_AUTHORITY_BOUNDARIES.json":"aa38dd3e67013b55fba4080f92d31c6932cf78d477a9df3d40abb64858bf7fbc","qa/b4-no-bypass/test_verify_hepta_callers.py":"dba4c5421ed30f7ea83d2b9c160b38a3570fc05cae7de5f68310d47062783c1d","qa/b4-no-bypass/test_kernel_authority_closed_world.py":"5ea3ab6a21f48e90f414d7e7865d1ec77008c1006b4262a4ea489cca096f035a","qa/b4-no-bypass/test_root_admin_source_closure.py":"aa5036a5498383d8c4968f7fc546d1e93c15e10b7bb76cd288804100273a8b7e"}
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0",GIT_TERMINAL_PROMPT="0")
records=[];result={"status":"preparing","tested_revision":expected,"base_revision":base,"merge_commit":merge,"started_unix_ns":time.time_ns()}
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,value):
    with (out/name).open("x") as f:json.dump(value,f,indent=2);f.write("\n")
def run(label,args,cwd=repo,custom_env=None,input_bytes=None,timeout=120,require=True):
    started=time.time_ns()
    try:
        p=subprocess.run(args,cwd=cwd,env=custom_env or env,input=input_bytes,capture_output=True,timeout=timeout,check=False)
        stdout,stderr,code,timed_out=p.stdout,p.stderr,p.returncode,False
    except subprocess.TimeoutExpired as exc:
        stdout,stderr,code,timed_out=exc.stdout or b"",exc.stderr or b"",124,True
    (out/(label+".stdout.log")).write_bytes(stdout);(out/(label+".stderr.log")).write_bytes(stderr)
    item={"label":label,"command":args,"cwd":str(cwd),"returncode":code,"timed_out":timed_out,"started_unix_ns":started,"finished_unix_ns":time.time_ns(),"stdout_sha256":sha(stdout),"stderr_sha256":sha(stderr)}
    save(label+".json",item);records.append(item)
    print(json.dumps({"event":"source_integration_command","label":label,"returncode":code,"timed_out":timed_out}),flush=True)
    if require and code:raise RuntimeError(label+" failed with "+str(code))
    return stdout
def snapshot(label):
    value={}
    for field,args in [("head",["rev-parse","HEAD"]),("tree",["rev-parse","HEAD^{tree}"]),("rust_tree",["rev-parse","HEAD:codex-rs"]),("status",["status","--porcelain"]),("refs",["for-each-ref","--format=%(refname) %(objectname)"])]:
        value[field]=run(label+"-"+field,["git",*args],cwd=source).decode().strip()
    save(label+".json",value);return value
def audit(tree):
    observed={}
    for name,digest in inputs.items():
        data=subprocess.check_output(["git","show",tree+":"+name],cwd=repo,env=env)
        observed[name]=sha(data)
        if observed[name]!=digest:raise RuntimeError("audit source identity changed: "+name)
    return observed
try:
    before=snapshot("source-before");result["source_before"]=before
    if (before["head"],before["tree"],before["rust_tree"],before["status"])!=(expected,"60604de0d6ea4805fd248574ba83fe49f16b261a",rust,""):raise RuntimeError("active source differs from completed tests")
    original_gate=json.loads((root/"evidence/native-final-gates-08/result.json").read_text())
    if original_gate["outcome"]!="passed" or original_gate["source_after"]["head"]!=expected:raise RuntimeError("original native gates did not finish on expected source")
    fmt=json.loads((root/"evidence/prettier-format-09/result.json").read_text())
    strict_file=root/"evidence/prettier-format-09/ast-result-strict-02.json"
    strict=json.loads(strict_file.read_text())
    if sha(strict_file.read_bytes())!="06d94fc81690d02a0dd2e803fcca211ad02061995355d8bbf6f6ffdf33b64638" or not strict["all_ast_equal"] or len(strict["files"])!=31:raise RuntimeError("strict AST proof identity differs")
    patch=root/"evidence/prettier-format-09/changes.patch"
    if sha(patch.read_bytes())!="cf6ccb3cd512878b4e5f91fa93f546fa77aef0374cfa574ece941941454f98cd":raise RuntimeError("reviewed format patch changed")
    merge_ids=run("merge-identity",["git","show","-s","--format=%T %P",merge]).decode().strip().split()
    if merge_ids!=["60604de0d6ea4805fd248574ba83fe49f16b261a",expected,base]:raise RuntimeError("reviewed merge identity differs")
    result["audit_inputs_before"]=audit(merge)
    paths=sorted(item["path"] for item in fmt["files"])
    strict_by_path={i["path"]:i for i in strict["files"]}
    for item in fmt["files"]:
        proof=strict_by_path[item["path"]]
        for key in ["before_sha256","after_sha256"]:
            if item[key]!=proof[key]:raise RuntimeError("format AST binding differs")
        if not proof["ast_equal"]:raise RuntimeError("non-equivalent formatter result")
    index=root/"format-review-09/integration-index-10"
    if index.exists():raise RuntimeError("isolated index already exists")
    isolated=dict(env,GIT_INDEX_FILE=str(index))
    run("read-merge-tree",["git","read-tree",merge],custom_env=isolated)
    run("format-patch-check",["git","apply","--cached","--check",str(patch)],custom_env=isolated)
    run("format-patch-apply",["git","apply","--cached",str(patch)],custom_env=isolated)
    tree=run("write-format-tree",["git","write-tree"],custom_env=isolated).decode().strip()
    changed=run("format-tree-paths",["git","diff","--name-only",merge,tree]).decode().splitlines()
    if sorted(changed)!=paths:raise RuntimeError("staged format pathset differs")
    for item in fmt["files"]:
        name=item["path"]
        after=subprocess.check_output(["git","rev-parse",tree+":"+name],cwd=repo,env=env).decode().strip()
        before_blob=subprocess.check_output(["git","rev-parse",merge+":"+name],cwd=repo,env=env).decode().strip()
        if after!=item["after_blob"] or before_blob!=item["before_blob"]:raise RuntimeError("staged format blob differs")
    rust_after=run("format-rust-tree",["git","rev-parse",tree+":codex-rs"]).decode().strip()
    if rust_after!=rust:raise RuntimeError("Rust tree changed")
    result["audit_inputs_after"]=audit(tree)
    message="style(apps): satisfy existing Prettier format gate\n\nFormat 31 existing browser, control UI, and native JavaScript files with\nPrettier 3.5.3. Verify each result with the bundled Babel parser while\npreserving semantic template raw text, literal values, and regex fields.\n"
    (out/"message.txt").write_text(message)
    commit=run("commit-format",["git","commit-tree",tree,"-p",merge,"-F",str(out/"message.txt")]).decode().strip()
    if not re.fullmatch("[0-9a-f]{40}",commit):raise RuntimeError("unexpected commit identity")
    result.update({"commit":commit,"tree":tree,"rust_tree":rust_after,"changed_paths":paths,"strict_ast_record_sha256":sha(strict_file.read_bytes()),"reviewed_patch_sha256":sha(patch.read_bytes())})
    run("commit-object",["git","cat-file","-p",commit])
    run("old-head-ancestor",["git","merge-base","--is-ancestor",expected,commit])
    run("current-base-ancestor",["git","merge-base","--is-ancestor",base,commit])
    remote=run("remote-refs-before",["git","ls-remote","--heads","origin","refs/heads/"+branch,"refs/heads/"+base_branch],cwd=source).decode().splitlines()
    mapping={line.split()[1]:line.split()[0] for line in remote}
    if mapping!={"refs/heads/"+branch:expected,"refs/heads/"+base_branch:base}:raise RuntimeError("remote refs advanced; publication stopped")
    remote_url=subprocess.check_output(["git","remote","get-url","--push","origin"],cwd=source,env=env,text=True).strip()
    if remote_url not in ["https://github.com/TrillionniumFoundation/hepta-private-ci.git","git@github.com:TrillionniumFoundation/hepta-private-ci.git"]:raise RuntimeError("configured publication URL requires review; value withheld")
    result["status"]="source_verified_before_push";save("before-push.json",result)
    run("normal-push",["git","push","--porcelain",remote_url,commit+":refs/heads/"+branch],timeout=180)
    remote_after=run("remote-ref-after",["git","ls-remote","--heads","origin","refs/heads/"+branch],cwd=source).decode().strip().split()
    if remote_after!=[commit,"refs/heads/"+branch]:raise RuntimeError("published ref readback differs")
    result["published_commit"]=commit;save("published.json",result)
    run("fetch-published",["git","fetch","origin",branch],cwd=source,timeout=180)
    run("fast-forward-published",["git","merge","--ff-only",commit],cwd=source)
    after=snapshot("source-after-ff");result["source_after_ff"]=after
    if (after["head"],after["tree"],after["rust_tree"],after["status"])!=(commit,tree,rust,""):raise RuntimeError("published source checkout differs")
    for name,digest in inputs.items():
        if sha((source/name).read_bytes())!=digest:raise RuntimeError("working audit input differs")
    package=json.loads((source/"package.json").read_text())
    original="prettier --check *.json *.md docs/*.md .github/workflows/*.yml **/*.js"
    if package["scripts"]["format"]!=original:raise RuntimeError("original format glob changed")
    entry=root/"tools/prettier-3.5.3-observed/bin/prettier.cjs"
    cache=json.loads((root/"evidence/native-python-text-07/prettier-cache.json").read_text())
    for item in cache["members"]:
        if sha((root/"tools/prettier-3.5.3-observed"/item["path"]).read_bytes())!=item["sha256"]:raise RuntimeError("verified observed Prettier cache changed")
    command=shlex.join(["/usr/bin/node",str(entry)])+original[len("prettier"):]
    gate_env=dict(env,PYTHONDONTWRITEBYTECODE="1",CODEX_REPO_ROOT=str(source),HEPTA_CI_LANE="source-head",SOURCE_SHA=commit,TESTED_SHA=commit,BASE_SHA=base)
    gate=out/"prettier-underlying.json"
    run("full-prettier",["python3","scripts/hepta_ci_exec.py","--timeout-seconds","600","--minimum-tests","0","--output",str(gate),"--","/bin/sh","-c",command],cwd=source,custom_env=gate_env,timeout=630)
    result["prettier_gate"]=json.loads(gate.read_text())
    result["source_final"]=snapshot("source-final")
    if result["source_final"]!=after:raise RuntimeError("read-only text gate changed source")
    result["status"]="published_and_verified"
except Exception as exc:
    result["status"]="failed";result["error"]=repr(exc)
finally:
    result["commands"]=records;result["finished_unix_ns"]=time.time_ns()
    save("result.json",result)
    print(json.dumps({"event":"source_integration_terminal","status":result["status"],"commit":result.get("commit"),"tree":result.get("tree"),"rust_tree":result.get("rust_tree"),"error":result.get("error")}),flush=True)
raise SystemExit(0 if result["status"]=="published_and_verified" else 1)
