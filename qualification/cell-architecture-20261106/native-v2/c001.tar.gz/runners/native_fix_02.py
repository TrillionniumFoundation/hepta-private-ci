from pathlib import Path
import json
import os
import subprocess
import time
root = Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source = root / "source"
record_dir = root / "evidence" / "source-ff-r3"
record_dir.mkdir()
old = "37e6ffe9dda66289580f9e3bdf6b161b2ee7d02e"
new = "b4afdbadc247c6fadfad4e416c00a9a853affa1c"
expected_tree = "b63abc5963ee86cfe056894096d9128c8e42e0e6"
def checked(label, command):
    result = subprocess.run(command, cwd=source, capture_output=True, text=True, check=False, timeout=300)
    (record_dir / (label + ".stdout.log")).write_text(result.stdout)
    (record_dir / (label + ".stderr.log")).write_text(result.stderr)
    with (record_dir / (label + ".json")).open("x") as stream:
        json.dump({"command": command, "returncode": result.returncode, "unix_ns": time.time_ns()}, stream, indent=2)
    if result.returncode:
        raise RuntimeError(label + " failed")
    return result.stdout.strip()
if checked("before-head", ["git", "rev-parse", "HEAD"]) != old:
    raise RuntimeError("source moved before root r3 fast-forward")
if checked("before-clean", ["git", "status", "--porcelain"]):
    raise RuntimeError("source dirty before root r3 fast-forward")
for name in ("started.json", "command.log"):
    if (root / "evidence/native-fix-01" / name).exists():
        raise RuntimeError("first fix dispatched unexpectedly; original budget requires reconciliation")
checked("fetch-r3", ["git", "fetch", "--depth=2", "origin", new])
checked("ff-r3", ["git", "merge", "--ff-only", new])
after = checked("after-head", ["git", "rev-parse", "HEAD", "HEAD^{tree}", "HEAD:codex-rs"]).splitlines()
stage = json.loads((root / "evidence/source-stage1/complete.json").read_text())
if after[:2] != [new, expected_tree] or after[2] != stage["final_identity"][2]:
    raise RuntimeError("r3 changed the expected source or Rust tree")
if checked("after-clean", ["git", "status", "--porcelain"]):
    raise RuntimeError("source dirty after r3 fast-forward")
with (record_dir / "result.json").open("x") as stream:
    json.dump({"before": old, "after": after, "rust_tree_unchanged": True, "first_fix_not_dispatched": True}, stream, indent=2)
os.environ["CODEX_REPO_ROOT"] = str(source)
print(json.dumps({"event": "r3_source_bound", "identity": after}), flush=True)

from pathlib import Path
import hashlib
import importlib
import json
import os
import shutil
import sys
import time

sys.dont_write_bytecode = True
root = Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source = root / "source"
evidence = root / "evidence" / "v8-resolution-02"
evidence.mkdir()
cache = root / "v8-resolver-02"
cache.mkdir()
names = (
    "librusty_v8_ptrcomp_sandbox_release_x86_64-unknown-linux-gnu.a.gz",
    "src_binding_ptrcomp_sandbox_release_x86_64-unknown-linux-gnu.rs",
)
observed = Path("/data/rusty-v8-v150.4.0-independent")
expected = (
    "a35c75d1f26e6a983885a45b33490a4ebe54f05050568b32b89cfb421b30b583",
    "7727826ae479bdb645e807239fb12d1f8e2e23de7a6cf16f5ee592690d1d8506",
)
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()
state = {
    "started_unix_ns": time.time_ns(),
    "source_files": {str(path.relative_to(source)): sha(path) for path in (
        source / "scripts/codex_package/v8.py",
        source / "scripts/codex_package/targets.py",
        source / "codex-rs/Cargo.lock",
    )},
    "original_observed_material": [],
}
destination = cache / "rusty-v8-150.4.0-x86_64-unknown-linux-gnu"
destination.mkdir()
for name, digest in zip(names, expected):
    path = observed / name
    if sha(path) != digest:
        raise RuntimeError("observed original V8 material changed")
    state["original_observed_material"].append({"path": str(path), "bytes": path.stat().st_size, "sha256": digest})
    shutil.copyfile(path, destination / name)
sys.path.insert(0, str(source / "scripts"))
v8 = importlib.import_module("codex_package.v8")
targets = importlib.import_module("codex_package.targets")
try:
    pair = v8.fetch_codex_v8_artifacts(targets.TARGET_SPECS["x86_64-unknown-linux-gnu"], cache_root=cache)
    state["official_release_checksum_verified"] = True
    checksums = destination / "rusty_v8_ptrcomp_sandbox_release_x86_64-unknown-linux-gnu.sha256"
    shutil.copyfile(checksums, evidence / checksums.name)
    state["official_checksum_file"] = {
        "url": "https://github.com/openai/codex/releases/download/rusty-v8-v150.4.0/" + checksums.name,
        "sha256": sha(checksums),
        "bytes": checksums.stat().st_size,
        "contents": checksums.read_text(),
    }
    paths = (pair.archive, pair.binding)
except Exception as error:
    state["official_release_checksum_verified"] = False
    state["official_check_error"] = {"type": type(error).__name__, "message": str(error)}
    paths = tuple(observed / name for name in names)
    state["scope"] = "Observed pinned pair only; official release verification did not succeed."
state["environment"] = dict(zip(("RUSTY_V8_ARCHIVE", "RUSTY_V8_SRC_BINDING_PATH"), map(str, paths)))
state["resolved_material"] = [{"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)} for path in paths]
state["finished_unix_ns"] = time.time_ns()
with (evidence / "result.json").open("x") as stream:
    json.dump(state, stream, indent=2)
    stream.write("\n")
print(json.dumps(state, indent=2))

from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
root = Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source = root / "source"
evidence = root / "evidence" / "native-fix-02"
expected = "b4afdbadc247c6fadfad4e416c00a9a853affa1c"
packages = ["-p", "codex-hepta-neuron", "-p", "codex-hepta-automation", "-p", "codex-hepta-runtime", "-p", "codex-hepta-agentd"]
evidence.mkdir()
def write(name, data):
    with (evidence / name).open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
def git(*args):
    return subprocess.check_output(["git", *args], cwd=source, text=True).strip()
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()
stage = json.loads((root / "evidence/source-stage1/complete.json").read_text())
if stage["outcome"] != "source_ready_no_native_build_started" or stage["final_identity"][0] != "37e6ffe9dda66289580f9e3bdf6b161b2ee7d02e":
    raise RuntimeError("source stage did not finish at the expected formatted head")
before = {"head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"), "codex_rs_tree": git("rev-parse", "HEAD:codex-rs"), "status": git("status", "--porcelain")}
if before["head"] != expected or before["status"]:
    raise RuntimeError("native fix does not start from the clean expected candidate")
v8 = json.loads((root / "evidence/v8-resolution-02/result.json").read_text())
for item in v8["resolved_material"]:
    if sha(Path(item["path"])) != item["sha256"]:
        raise RuntimeError("V8 material changed after resolution")
overrides = {
    "PATH": "/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/.cargo/bin:" + os.environ["PATH"],
    "RUSTUP_TOOLCHAIN": "1.96.0",
    "PYTHONDONTWRITEBYTECODE": "1",
    "CARGO_TARGET_DIR": str(root / "target"),
    "CARGO_BUILD_JOBS": "2",
    "NEXTEST_TEST_THREADS": "2",
    "CARGO_PROFILE_TEST_DEBUG": "0",
    "CARGO_PROFILE_DEV_DEBUG": "0",
    "CARGO_INCREMENTAL": "0",
    "CARGO_NET_GIT_FETCH_WITH_CLI": "true",
    "PROTOC": "/usr/bin/protoc",
    "PROTOC_INCLUDE": "/usr/include",
    "CODEX_REPO_ROOT": str(source),
    "HEPTA_CI_LANE": "source-head",
    "SOURCE_SHA": expected,
    "TESTED_SHA": expected,
    "BASE_SHA": "a6f3aa12ba187448c35449c7da0a9798ae4ca987",
    **v8["environment"],
}
os.environ.update(overrides)
helper_path = source / "scripts/hepta_ci_exec.py"
spec = importlib.util.spec_from_file_location("hepta_ci_exec", helper_path)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
command = ["just", "fix", "--locked", *packages]
state = {
    "label": "native-fix-02", "started_unix_ns": time.time_ns(),
    "command": command, "source_before": before,
    "environment_overrides": overrides, "helper_sha256": sha(helper_path),
    "v8_official_release_checksum_verified": v8["official_release_checksum_verified"],
    "v8_material": v8["resolved_material"],
    "scope": "Original just fix transformation and real four-package compilation; not a passing test qualification.",
}
write("started.json", state)
print(json.dumps({"event": "native_fix_started", **state}), flush=True)
os.chdir(source)
result = helper.execute_logged(command, evidence / "command.log", timeout_seconds=4200)
state["execution"] = result
state["source_after"] = {
    "head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
    "codex_rs_tree": git("rev-parse", "HEAD:codex-rs"),
    "status": git("status", "--porcelain"),
    "changed_paths": git("diff", "--name-only").splitlines(),
}
patch = subprocess.check_output(["git", "diff", "--binary"], cwd=source)
with (evidence / "fix.patch").open("xb") as stream:
    stream.write(patch)
state["patch"] = {"path": "fix.patch", "bytes": len(patch), "sha256": hashlib.sha256(patch).hexdigest()}
state["finished_unix_ns"] = time.time_ns()
state["outcome"] = "completed" if result["returncode"] == 0 and not result["timed_out"] and not result["output_limit_exceeded"] else "failed"
write("result.json", state)
print(json.dumps({"event": "native_fix_complete", **state}), flush=True)
sys.exit(0 if state["outcome"] == "completed" else 1)
