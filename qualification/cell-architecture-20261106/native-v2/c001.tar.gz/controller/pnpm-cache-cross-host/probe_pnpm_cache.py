from pathlib import Path
import base64
import getpass
import hashlib
import json
import os
import shutil
import subprocess
import time

WANTED = "10.34.5"
EXPECTED = "a4ee05f2f73658255bd6a89859c065a45c28a57daefae2c893a168ee2b73168c37b91e83e57ea67654ad03f03031746430e8bce38e362e042605fb8abc80192e"
URL = "https://registry.npmjs.org/pnpm/-/pnpm-10.34.5.tgz"
task_user_dir = Path.home()
env = os.environ.copy()
env.update({"COREPACK_ENABLE_NETWORK": "0", "COREPACK_ENABLE_AUTO_PIN": "0", "COREPACK_ENABLE_PROJECT_SPEC": "0", "npm_config_manage_package_manager_versions": "false", "PYTHONDONTWRITEBYTECODE": "1"})
result = {"user": getpass.getuser(), "home": str(task_user_dir), "started_unix_ns": time.time_ns(), "executables": [], "matching_tarballs": [], "searches": [], "errors": [], "scope": "Read-only path, version and exact public package-cache inspection. No registry requests, installations, source/target writes or CUDA actions."}
def emit(event, **values):
    print(json.dumps({"event": event, **values}), flush=True)
def hashes(path):
    p = Path(path)
    h256 = hashlib.sha256()
    h512 = hashlib.sha512()
    with p.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            h256.update(chunk)
            h512.update(chunk)
    st = p.stat()
    return {"path": str(p), "resolved_path": str(p.resolve()), "bytes": st.st_size, "mode": oct(st.st_mode & 0o777), "sha256": h256.hexdigest(), "sha512": h512.hexdigest()}
node = shutil.which("node")
emit("identity", user=result["user"], home=result["home"], node=node)
seen = set()
def probe(path):
    try:
        p = Path(path)
        if not p.is_file():
            return
        resolved = p.resolve()
        if str(resolved) in seen:
            return
        seen.add(str(resolved))
        if p.suffix in (".js", ".cjs") and node:
            command = [node, str(p), "--version"]
        elif os.access(p, os.X_OK):
            command = [str(p), "--version"]
        else:
            return
        process = subprocess.run(command, cwd="/", env=env, capture_output=True, text=True, check=False, timeout=12)
        row = {**hashes(resolved), "command": command, "returncode": process.returncode, "stdout": process.stdout[:2000], "stderr": process.stderr[:2000]}
        result["executables"].append(row)
        emit("executable", **row)
    except Exception as error:
        result["errors"].append({"path": str(path), "type": type(error).__name__, "message": str(error)})
def tarball(path, origin):
    try:
        p = Path(path)
        if not p.is_file():
            return
        row = hashes(p)
        if row["sha512"] == EXPECTED:
            row["origin"] = origin
            result["matching_tarballs"].append(row)
            emit("exact_tarball", **row)
    except Exception as error:
        result["errors"].append({"path": str(path), "type": type(error).__name__, "message": str(error)})
for value in (
    shutil.which("pnpm"),
    task_user_dir / ".local/share/pnpm/pnpm",
    task_user_dir / ".local/bin/pnpm",
    task_user_dir / ".npm-global/bin/pnpm",
    Path("/usr/local/bin/pnpm"),
    Path("/usr/bin/pnpm"),
    Path("/usr/lib/node_modules/pnpm/bin/pnpm.cjs"),
    Path("/usr/local/lib/node_modules/pnpm/bin/pnpm.cjs"),
    task_user_dir / ".npm-global/lib/node_modules/pnpm/bin/pnpm.cjs",
):
    if value:
        probe(value)
cache_roots = [
    task_user_dir / ".npm/_cacache",
    task_user_dir / ".cache/npm/_cacache",
    task_user_dir / ".local/share/npm/_cacache",
]
for cache in cache_roots:
    index = cache / "index-v5"
    if not index.is_dir():
        continue
    command = ["rg", "-l", "--fixed-strings", URL, str(index)]
    p = subprocess.run(command, cwd="/", capture_output=True, text=True, timeout=35, check=False)
    rows = p.stdout.splitlines()
    result["searches"].append({"kind": "exact_tarball_cache_key", "root": str(index), "returncode": p.returncode, "matched_files": len(rows), "stderr": p.stderr[:2000]})
    for filename in rows[:40]:
        try:
            for line in Path(filename).read_text(errors="strict").splitlines():
                if URL not in line or "\t" not in line:
                    continue
                entry = json.loads(line.split("\t", 1)[1])
                integrity = entry.get("integrity", "")
                if URL not in entry.get("key", "") or not integrity.startswith("sha512-"):
                    continue
                digest = base64.b64decode(integrity.split("-", 1)[1].split("?", 1)[0]).hex()
                if digest == EXPECTED:
                    tarball(cache / "content-v2/sha512" / digest[:2] / digest[2:4] / digest[4:], "npm cache exact URL and integrity")
        except Exception as error:
            result["errors"].append({"path": filename, "type": type(error).__name__, "message": str(error)})
search_roots = [
    task_user_dir / ".cache/node/corepack",
    task_user_dir / ".cache/corepack",
    task_user_dir / ".cache/pnpm",
    task_user_dir / ".local/share/pnpm",
    task_user_dir / ".npm",
    task_user_dir / ".nvm/versions/node",
]
for name in ("COREPACK_HOME", "XDG_CACHE_HOME", "PNPM_HOME"):
    value = os.environ.get(name)
    if value:
        p = Path(value)
        if p.is_absolute():
            search_roots.append(p)
work = task_user_dir / "work"
if work.is_dir():
    search_roots.extend(p for p in work.glob("*/tools") if p.is_dir())
    search_roots.extend(p for p in work.glob("*/*pnpm*") if p.is_dir())
unique_roots = []
for p in search_roots:
    if p.is_dir() and str(p) not in unique_roots:
        unique_roots.append(str(p))
if unique_roots:
    command = ["rg", "--files", "--hidden", "--no-ignore", "--glob", "!**/target/**", "--glob", "!**/.git/**", "--glob", "pnpm", "--glob", "pnpm.cjs", "--glob", "pnpm-10.34.5*.tgz", "--glob", "pnpm-10.34.5*.tar.gz", *unique_roots]
    p = subprocess.run(command, cwd="/", capture_output=True, text=True, timeout=50, check=False)
    paths = p.stdout.splitlines()
    result["searches"].append({"kind": "known_tool_filenames", "roots": unique_roots, "returncode": p.returncode, "paths": paths, "stderr": p.stderr[:2000]})
    for path in paths[:40]:
        if path.endswith((".tgz", ".tar.gz")):
            tarball(path, "matching package archive filename")
        elif Path(path).name in ("pnpm", "pnpm.cjs"):
            probe(path)
result["finished_unix_ns"] = time.time_ns()
result["exact_tool_found"] = any(x["returncode"] == 0 and x["stdout"].strip() == WANTED for x in result["executables"])
emit("summary", **result)
