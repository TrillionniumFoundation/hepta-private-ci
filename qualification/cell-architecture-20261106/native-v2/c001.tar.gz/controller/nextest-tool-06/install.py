from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import time

sys.dont_write_bytecode = True
root = Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source = root / "source"
install = root / "tools/nextest-0.9.103"
evidence = root / "evidence/nextest-tool-06"
expected_source = "87cce8066b5f41e2d462b9469a301245f43d8c23"
expected_rust = "3deb8503bc873331518c0c536a269c00d754a8bf"
metadata_path = root / "evidence/github-read-05/nextest-release.stdout.json"
metadata_sha256 = "541f7c139f9519b89160fcdd0e164a3b051f3bb29d33fbfba7fa5304b4824798"
archive_name = "cargo-nextest-0.9.103-x86_64-unknown-linux-gnu.tar.gz"
checksum_name = "cargo-nextest-0.9.103-x86_64-unknown-linux-gnu.sha256"
if install.exists() or evidence.exists():
    print(json.dumps({"event": "refused_existing_path", "install_exists": install.exists(), "evidence_exists": evidence.exists()}), flush=True)
    raise SystemExit(2)
evidence.mkdir()
install.mkdir()
downloads = install / "downloads"
downloads.mkdir()
bin_dir = install / "bin"
bin_dir.mkdir()
state = {"label": "nextest-tool-06", "started_unix_ns": time.time_ns(), "commands": [], "scope": "Official exact nextest tool installation in task-owned paths; no product tests, global tool changes or target changes"}
def emit(event, **data):
    print(json.dumps({"event": event, **data}), flush=True)
def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()
def write_json(name, data):
    with (evidence / name).open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
def source_identity():
    def git(*args):
        return subprocess.check_output(["git", *args], cwd=source, text=True).strip()
    return {"head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"), "rust_tree": git("rev-parse", "HEAD:codex-rs"), "status": git("status", "--porcelain")}
def run(label, command, *, cwd=install, env=None, timeout=300):
    emit("command_started", label=label, command=command)
    timed_out = False
    try:
        result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, timeout=timeout, check=False)
        stdout, stderr, returncode = result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired as error:
        stdout = error.stdout or b""
        stderr = error.stderr or b""
        returncode = None
        timed_out = True
    for channel, data in (("stdout", stdout), ("stderr", stderr)):
        with (evidence / (label + "." + channel + ".log")).open("xb") as stream:
            stream.write(data)
    row = {"label": label, "command": command, "cwd": str(cwd), "returncode": returncode, "timed_out": timed_out, "stdout_bytes": len(stdout), "stderr_bytes": len(stderr), "stdout_sha256": hashlib.sha256(stdout).hexdigest(), "stderr_sha256": hashlib.sha256(stderr).hexdigest()}
    state["commands"].append(row)
    write_json(label + ".json", row)
    emit("command_complete", **row)
    if timed_out or returncode:
        raise RuntimeError(label + " failed or timed out")
    return stdout.decode("utf-8", errors="strict")
try:
    before = source_identity()
    state["source_before"] = before
    if before["head"] != expected_source or before["rust_tree"] != expected_rust or before["status"]:
        raise RuntimeError("source does not match the frozen clean identity")
    global_binary = shutil.which("cargo-nextest")
    if global_binary and Path(global_binary).is_file():
        state["existing_global_tool"] = {"path": global_binary, "sha256_before": digest(global_binary)}
    raw_metadata = metadata_path.read_bytes()
    if hashlib.sha256(raw_metadata).hexdigest() != metadata_sha256:
        raise RuntimeError("official metadata changed before installation")
    with (evidence / "official-release.json").open("xb") as stream:
        stream.write(raw_metadata)
    metadata = json.loads(raw_metadata)
    if metadata["tag_name"] != "cargo-nextest-0.9.103":
        raise RuntimeError("wrong official release")
    selected = {}
    for name in (archive_name, checksum_name):
        rows = [asset for asset in metadata["assets"] if asset["name"] == name]
        if len(rows) != 1 or not re.fullmatch(r"sha256:[0-9a-f]{64}", rows[0]["digest"] or ""):
            raise RuntimeError("missing unique official asset identity")
        selected[name] = rows[0]
    state["official_release"] = {"html_url": metadata["html_url"], "tag_name": metadata["tag_name"], "published_at": metadata["published_at"], "metadata_sha256": metadata_sha256, "assets": selected}
    write_json("started.json", state)
    emit("official_assets_bound", source=before, assets=selected)
    gh = shutil.which("gh")
    if not gh:
        raise RuntimeError("gh unavailable for the official release download")
    run("download", [gh, "release", "download", metadata["tag_name"], "--repo", "nextest-rs/nextest", "--pattern", archive_name, "--pattern", checksum_name, "--dir", str(downloads)], timeout=300)
    observed = {}
    for name, asset in selected.items():
        path = downloads / name
        sha = digest(path)
        if path.stat().st_size != asset["size"] or "sha256:" + sha != asset["digest"]:
            raise RuntimeError("download differs from the GitHub API asset digest: " + name)
        observed[name] = {"path": str(path), "bytes": path.stat().st_size, "sha256": sha, "official_api_digest_verified": True}
    lines = (downloads / checksum_name).read_text().splitlines()
    checksums = []
    for line in lines:
        match = re.fullmatch(r"([0-9a-fA-F]{64})\s+\*?(.+)", line)
        if match and match.group(2).removeprefix("./") == archive_name:
            checksums.append(match.group(1).lower())
    if checksums != [observed[archive_name]["sha256"]]:
        raise RuntimeError("official checksum file does not exactly identify the archive")
    state["downloaded_assets"] = observed
    state["official_checksum_file_contents"] = (downloads / checksum_name).read_text()
    state["official_release_checksum_verified"] = True
    archive = downloads / archive_name
    with tarfile.open(archive, "r:gz") as package:
        members = package.getmembers()
        for member in members:
            parts = PurePosixPath(member.name)
            if parts.is_absolute() or ".." in parts.parts or not (member.isfile() or member.isdir()):
                raise RuntimeError("unsafe or unexpected release archive member")
        binaries = [member for member in members if member.isfile() and PurePosixPath(member.name).name == "cargo-nextest"]
        if len(binaries) != 1:
            raise RuntimeError("release archive does not contain exactly one cargo-nextest")
        binary_member = binaries[0]
        if not 0 < binary_member.size <= 128 * 1024 * 1024:
            raise RuntimeError("unexpected nextest binary size")
        state["archive_members"] = [{"name": member.name, "bytes": member.size, "mode": oct(member.mode)} for member in members]
        binary = bin_dir / "cargo-nextest"
        with package.extractfile(binary_member) as src, binary.open("xb") as dst:
            shutil.copyfileobj(src, dst)
    binary.chmod(0o755)
    binary_sha = digest(binary)
    direct_version = run("binary-version", [str(binary), "--version"], timeout=30).strip()
    if re.fullmatch(r"cargo-nextest 0\.9\.103(?:\s[^\n]*)?", direct_version) is None:
        raise RuntimeError("installed binary is not exact nextest 0.9.103")
    env = os.environ.copy()
    rust_bin = "/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin"
    env["PATH"] = str(bin_dir) + ":" + rust_bin + ":/home/qian-qi/.cargo/bin:" + env["PATH"]
    env["RUSTUP_TOOLCHAIN"] = "1.96.0"
    resolved = shutil.which("cargo-nextest", path=env["PATH"])
    if resolved != str(binary):
        raise RuntimeError("candidate PATH does not select the pinned tool")
    cargo_version = run("cargo-nextest-version", [rust_bin + "/cargo", "nextest", "--version"], cwd=source / "codex-rs", env=env, timeout=30).strip()
    if cargo_version != direct_version:
        raise RuntimeError("cargo dispatch does not select the exact installed binary")
    if digest(binary) != binary_sha:
        raise RuntimeError("tool bytes changed during version verification")
    state["installed_binary"] = {"path": str(binary), "bytes": binary.stat().st_size, "sha256": binary_sha, "version": direct_version, "cargo_dispatch_version": cargo_version, "path_prepend": str(bin_dir), "resolved_command": resolved}
    if "existing_global_tool" in state:
        old = state["existing_global_tool"]
        old["sha256_after"] = digest(old["path"])
        old["unchanged"] = old["sha256_before"] == old["sha256_after"]
        if not old["unchanged"]:
            raise RuntimeError("existing global tool changed during preparation")
    after = source_identity()
    state["source_after"] = after
    state["source_unchanged"] = before == after
    if not state["source_unchanged"]:
        raise RuntimeError("source changed during the tool-only installation")
    state["outcome"] = "prepared"
except Exception as error:
    state["outcome"] = "failed"
    state["error"] = {"type": type(error).__name__, "message": str(error)}
    try:
        state["source_after"] = source_identity()
    except Exception as identity_error:
        state["source_after_error"] = str(identity_error)
finally:
    state["finished_unix_ns"] = time.time_ns()
    write_json("result.json", state)
    emit("nextest_tool_complete", **state)
raise SystemExit(0 if state["outcome"] == "prepared" else 1)
