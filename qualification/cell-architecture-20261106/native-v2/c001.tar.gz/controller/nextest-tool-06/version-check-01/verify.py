from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,tarfile,time
root=Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source"
base=root/"evidence/nextest-tool-06"
out=base/"version-check-01";out.mkdir()
binary=root/"tools/nextest-0.9.103/bin/cargo-nextest"
archive=root/"tools/nextest-0.9.103/downloads/cargo-nextest-0.9.103-x86_64-unknown-linux-gnu.tar.gz"
checksum=root/"tools/nextest-0.9.103/downloads/cargo-nextest-0.9.103-x86_64-unknown-linux-gnu.sha256"
def sha(path):
    with Path(path).open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def identity():
    def git(*args):return subprocess.check_output(["git",*args],cwd=source,text=True).strip()
    return {"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"rust_tree":git("rev-parse","HEAD:codex-rs"),"status":git("status","--porcelain")}
before=identity()
result={"label":"nextest-tool-06-version-check-01","started_unix_ns":time.time_ns(),"source_before":before,"prior_result_path":str(base/"result.json"),"prior_result_sha256":sha(base/"result.json"),"scope":"Read-only reconciliation of the installer's single-line validation mistake; exact expected nextest version remains 0.9.103; no repository gate edits or product tests"}
try:
    if before["head"]!="87cce8066b5f41e2d462b9469a301245f43d8c23" or before["rust_tree"]!="3deb8503bc873331518c0c536a269c00d754a8bf" or before["status"]:
        raise RuntimeError("source no longer matches frozen clean identity")
    prior=json.loads((base/"result.json").read_text())
    if prior["outcome"]!="failed" or prior.get("error",{}).get("message")!="installed binary is not exact nextest 0.9.103":
        raise RuntimeError("unexpected prior failure")
    if sha(archive)!="b6b5daad02ddef2d0e1f1114c4cd708f2960fd421a415693f995cef3bef90036" or sha(checksum)!="b4ffb1328e5e899cfc2581d09e45384698467c5fe561c64b94ce3fe404c7d18a":
        raise RuntimeError("official artifacts changed")
    with tarfile.open(archive,"r:gz") as package:
        member=package.getmember("cargo-nextest")
        with package.extractfile(member) as stream:
            archive_binary_sha256=hashlib.file_digest(stream,"sha256").hexdigest()
    binary_sha256=sha(binary)
    if binary_sha256!=archive_binary_sha256:
        raise RuntimeError("installed binary differs from official archive member")
    env=os.environ.copy()
    rust_bin="/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin"
    env["PATH"]=str(binary.parent)+":"+rust_bin+":/home/qian-qi/.cargo/bin:"+env["PATH"]
    env["RUSTUP_TOOLCHAIN"]="1.96.0"
    selected=shutil.which("cargo-nextest",path=env["PATH"])
    if selected!=str(binary):raise RuntimeError("PATH selected another nextest")
    command=[rust_bin+"/cargo","nextest","--version"]
    process=subprocess.run(command,cwd=source/"codex-rs",env=env,capture_output=True,check=False,timeout=30)
    (out/"cargo-nextest-version.stdout.log").write_bytes(process.stdout)
    (out/"cargo-nextest-version.stderr.log").write_bytes(process.stderr)
    result["version_command"]={"command":command,"returncode":process.returncode,"stdout_bytes":len(process.stdout),"stderr_bytes":len(process.stderr),"stdout_sha256":hashlib.sha256(process.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(process.stderr).hexdigest()}
    if process.returncode:raise RuntimeError("original Cargo version command failed")
    lines=process.stdout.decode().splitlines()
    first=re.fullmatch(r"cargo-nextest ([^ ]+) \(([0-9a-f]+) ([0-9-]+)\)",lines[0])
    fields=dict(line.split(": ",1) for line in lines[1:])
    if first is None or first.group(1)!="0.9.103" or fields.get("release")!="0.9.103" or fields.get("host")!="x86_64-unknown-linux-gnu":
        raise RuntimeError("actual Cargo-dispatched tool version or host differs")
    if re.fullmatch(r"[0-9a-f]{40}",fields.get("commit-hash","")) is None or not fields["commit-hash"].startswith(first.group(2)) or fields.get("commit-date")!=first.group(3):
        raise RuntimeError("inconsistent verbose version identity")
    if process.stdout!=(base/"binary-version.stdout.log").read_bytes():
        raise RuntimeError("Cargo version differs from installed binary's original version output")
    global_tool=prior["existing_global_tool"]
    global_after=sha(global_tool["path"])
    if global_after!=global_tool["sha256_before"]:
        raise RuntimeError("original global nextest changed")
    after=identity()
    if after!=before:raise RuntimeError("source changed during tool verification")
    result.update({"outcome":"prepared","official_api_digest_verified":True,"official_release_checksum_verified":True,"archive":{"path":str(archive),"bytes":archive.stat().st_size,"sha256":sha(archive)},"checksum_file":{"path":str(checksum),"bytes":checksum.stat().st_size,"sha256":sha(checksum),"contents":checksum.read_text()},"installed_binary":{"path":str(binary),"bytes":binary.stat().st_size,"sha256":binary_sha256,"archive_member_sha256":archive_binary_sha256,"version_line":lines[0],"version_fields":fields,"path_prepend":str(binary.parent),"resolved_command":selected},"global_tool":{"path":global_tool["path"],"sha256_before":global_tool["sha256_before"],"sha256_after":global_after,"unchanged":True},"source_after":after,"source_unchanged":True})
except Exception as error:
    result["outcome"]="failed"
    result["error"]={"type":type(error).__name__,"message":str(error)}
    try:result["source_after"]=identity()
    except Exception as nested:result["source_after_error"]=str(nested)
finally:
    result["finished_unix_ns"]=time.time_ns()
    with (out/"result.json").open("x") as stream:json.dump(result,stream,indent=2);stream.write("\n")
    print(json.dumps(result,indent=2),flush=True)
raise SystemExit(0 if result["outcome"]=="prepared" else 1)
