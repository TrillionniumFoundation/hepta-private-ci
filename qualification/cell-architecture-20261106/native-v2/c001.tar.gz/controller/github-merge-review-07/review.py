import hashlib, json, os, pathlib, re, subprocess, sys, time, urllib.parse

root = pathlib.Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source = root / "source"
review = root / "merge-review"
repo = review / "repository.git"
evidence = root / "evidence/github-merge-review-07"
old = "a6f3aa12ba187448c35449c7da0a9798ae4ca987"
base = "e01c860f9b43a88555dfe9120a86f7f451e760fd"
head = "87cce8066b5f41e2d462b9469a301245f43d8c23"
head_tree = "60604de0d6ea4805fd248574ba83fe49f16b261a"
env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_TERMINAL_PROMPT="0")
records = []
result = {"schema": 1, "source": str(source), "review": str(review), "old_base": old, "current_base": base, "head": head, "expected_head_tree": head_tree, "started_unix": time.time(), "status": "running"}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def run(label, argv, cwd, timeout=60, acceptable=(0,)):
    t = time.time()
    try:
        proc = subprocess.run(argv, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        rc, stdout, stderr = proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired as exc:
        rc, stdout, stderr = 124, exc.stdout or b"", exc.stderr or b""
    record = {"label": label, "argv": argv, "cwd": str(cwd), "exit_code": rc, "elapsed_seconds": time.time()-t, "stdout_bytes": len(stdout), "stdout_sha256": sha(stdout), "stderr_bytes": len(stderr), "stderr_sha256": sha(stderr)}
    (evidence / (label + ".stdout.log")).write_bytes(stdout)
    (evidence / (label + ".stderr.log")).write_bytes(stderr)
    save_json(evidence / (label + ".json"), record)
    records.append(record)
    print(json.dumps({"command": label, "exit_code": rc, "stdout_bytes": len(stdout), "stderr_bytes": len(stderr)}), flush=True)
    if rc not in acceptable:
        raise RuntimeError(label + " exited " + str(rc))
    return stdout, rc

def snapshot(label):
    values = {}
    for field, args in [
        ("head", ["rev-parse", "HEAD"]),
        ("tree", ["rev-parse", "HEAD^{tree}"]),
        ("rust_tree", ["rev-parse", "HEAD:codex-rs"]),
        ("status", ["status", "--porcelain=v1", "--untracked-files=all"]),
        ("refs", ["for-each-ref", "--format=%(refname) %(objectname)"]),
    ]:
        p = subprocess.run(["git", *args], cwd=source, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True, timeout=30)
        values[field] = p.stdout.decode("utf-8")
        if p.stderr:
            raise RuntimeError("unexpected snapshot stderr " + field)
    shallow = source / ".git/shallow"
    values["shallow"] = {"exists": shallow.is_file(), "size": shallow.stat().st_size if shallow.is_file() else None}
    save_json(evidence / (label + ".json"), values)
    return values

if review.exists() or evidence.exists():
    raise SystemExit("Refusing existing independent review or evidence directory")
evidence.mkdir(parents=True)
review.mkdir()
try:
    result["source_before"] = snapshot("source-before")
    if result["source_before"]["head"].strip() != head or result["source_before"]["tree"].strip() != head_tree or result["source_before"]["status"]:
        raise RuntimeError("source identity changed or dirty; no cloning performed")
    origin_proc = subprocess.run(["git", "remote", "get-url", "origin"], cwd=source, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, check=True)
    origin = origin_proc.stdout.decode("utf-8").strip()
    parsed = urllib.parse.urlsplit(origin)
    if parsed.scheme in ("https", "http") and (parsed.username or parsed.password or parsed.query or parsed.fragment):
        raise RuntimeError("Origin includes unexpected credential/URL fields; refused to log or reuse")
    result["source_origin"] = origin
    result["source_origin_command"] = {"argv": ["git", "remote", "get-url", "origin"], "cwd": str(source), "exit_code": 0}
    run("git-version", ["git", "--version"], review)
    run("clone-independent-bare", ["git", "clone", "--bare", "--no-local", "--no-hardlinks", "--single-branch", str(source), str(repo)], review, timeout=240)
    clone_head, _ = run("clone-head", ["git", "rev-parse", "HEAD"], repo)
    if clone_head.decode().strip() != head:
        raise RuntimeError("Independent clone did not retain frozen head")
    shallow = repo / "shallow"
    result["clone_shallow_before_fetch"] = {"exists": shallow.is_file(), "size": shallow.stat().st_size if shallow.is_file() else None}
    run("review-origin", ["git", "remote", "set-url", "origin", origin], repo)
    run("fetch-exact-current-base", ["git", "fetch", "--no-tags", "--depth=64", "origin", base], repo, timeout=300)
    fetched, _ = run("fetched-identity", ["git", "rev-parse", "FETCH_HEAD"], repo)
    if fetched.decode().strip() != base:
        raise RuntimeError("Fetched identity not expected current base")
    remote, _ = run("ls-remote", ["git", "ls-remote", "origin", "refs/heads/work/cell-unification-20261106", "refs/heads/codex/cell-architecture-closure-20261106-9387"], repo, timeout=120)
    result["remote_refs"] = dict((line.split()[1], line.split()[0]) for line in remote.decode().splitlines())
    if result["remote_refs"].get("refs/heads/work/cell-unification-20261106") != base or result["remote_refs"].get("refs/heads/codex/cell-architecture-closure-20261106-9387") != head:
        raise RuntimeError("remote moved again; preserving observations without further review")
    commits, _ = run("base-commits", ["git", "log", "--format=%H%x09%P%x09%s", old + ".." + base], repo)
    changes, _ = run("base-paths", ["git", "diff", "--name-status", old, base], repo)
    summary, _ = run("base-stat", ["git", "diff", "--stat", old, base], repo)
    result["base_commits"] = commits.decode().splitlines()
    result["base_paths"] = changes.decode().splitlines()
    result["base_stat"] = summary.decode()
    print(json.dumps({"base_commits": result["base_commits"], "base_paths": result["base_paths"], "base_stat": result["base_stat"]}), flush=True)
    bases, _ = run("merge-base", ["git", "merge-base", "--all", base, head], repo, acceptable=(0,1))
    result["merge_bases"] = bases.decode().splitlines()
    _, result["old_base_ancestor_current_base_exit"] = run("old-base-ancestor-current-base", ["git", "merge-base", "--is-ancestor", old, base], repo, acceptable=(0,1))
    _, result["current_base_ancestor_head_exit"] = run("current-base-ancestor-head", ["git", "merge-base", "--is-ancestor", base, head], repo, acceptable=(0,1))
    merged, result["merge_tree_exit"] = run("merge-tree", ["git", "merge-tree", "--write-tree", base, head], repo, timeout=120, acceptable=(0,1))
    lines = merged.decode("utf-8").splitlines()
    result["merge_tree"] = lines[0] if lines and re.fullmatch(r"[0-9a-f]{40}", lines[0]) else None
    result["merge_tree_matches_head_tree"] = result["merge_tree"] == head_tree
    stage_re = re.compile(r"^([0-7]{6}) ([0-9a-f]{40}) ([123])\t(.+)$")
    result["conflict_stages"] = [{"mode": m[1], "blob": m[2], "stage": int(m[3]), "path": m[4]} for line in lines if (m := stage_re.match(line))]
    result["conflict_paths"] = sorted({r["path"] for r in result["conflict_stages"]})
    result["conflict_path_count"] = len(result["conflict_paths"])
    result["clone_shallow_after_fetch"] = {"exists": shallow.is_file(), "size": shallow.stat().st_size if shallow.is_file() else None}
    result["status"] = "observed"
except Exception as exc:
    result["status"] = "failed"
    result["error"] = repr(exc)
finally:
    try:
        result["source_after"] = snapshot("source-after")
        result["source_unchanged"] = result.get("source_before") == result["source_after"]
    except Exception as exc:
        result["source_after_error"] = repr(exc)
        result["source_unchanged"] = False
    result["commands"] = records
    result["finished_unix"] = time.time()
    save_json(evidence / "result.json", result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
sys.exit(0 if result["status"] == "observed" and result["source_unchanged"] else 1)
