import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
repo=root/"merge-review/repository.git"
out=root/"evidence/github-merge-review-07/formatter-difference-01"
out.mkdir()
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0")
path="codex-rs/hepta-neuron/src/cell_test_support.rs"
commands=[
("e01-vs-formatted",["git","diff","--no-ext-diff","--unified=5","e01c860f9b43a88555dfe9120a86f7f451e760fd","87cce8066b5f41e2d462b9469a301245f43d8c23","--",path]),
("a6-vs-e01",["git","diff","--no-ext-diff","--unified=3","a6f3aa12ba187448c35449c7da0a9798ae4ca987","e01c860f9b43a88555dfe9120a86f7f451e760fd","--",path]),
("a6-vs-e01-whitespace-ignored",["git","diff","--no-ext-diff","--ignore-all-space","--unified=3","a6f3aa12ba187448c35449c7da0a9798ae4ca987","e01c860f9b43a88555dfe9120a86f7f451e760fd","--",path])]
records=[]
for label,args in commands:
 p=subprocess.run(args,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
 (out/(label+".stdout.log")).write_bytes(p.stdout)
 (out/(label+".stderr.log")).write_bytes(p.stderr)
 r={"label":label,"argv":args,"cwd":str(repo),"exit_code":p.returncode,"stdout_bytes":len(p.stdout),"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_bytes":len(p.stderr),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest()}
 (out/(label+".json")).write_text(json.dumps(r,indent=2)+"\n")
 records.append(r)
 print(json.dumps(r),flush=True)
 print(p.stdout.decode(),flush=True)
(out/"result.json").write_text(json.dumps({"commands":records},indent=2)+"\n")
