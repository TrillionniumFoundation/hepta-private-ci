import hashlib,json,os,pathlib,re,subprocess,sys,time
root=pathlib.Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source"
repo=root/"merge-review/repository.git"
out=root/"evidence/github-merge-review-07/merge-commit-01"
head="87cce8066b5f41e2d462b9469a301245f43d8c23"
base="e01c860f9b43a88555dfe9120a86f7f451e760fd"
tree="60604de0d6ea4805fd248574ba83fe49f16b261a"
rust_tree="3deb8503bc873331518c0c536a269c00d754a8bf"
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0",GIT_TERMINAL_PROMPT="0")
records=[]
result={"schema":1,"repo":str(repo),"expected_parents":[head,base],"expected_tree":tree,"expected_rust_tree":rust_tree,"status":"running","started_unix":time.time()}
def sha(d): return hashlib.sha256(d).hexdigest()
def save(path,v): path.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n")
def run(label,args,cwd=repo):
 p=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
 (out/(label+".stdout.log")).write_bytes(p.stdout)
 (out/(label+".stderr.log")).write_bytes(p.stderr)
 r={"label":label,"argv":args,"cwd":str(cwd),"exit_code":p.returncode,"stdout_bytes":len(p.stdout),"stdout_sha256":sha(p.stdout),"stderr_bytes":len(p.stderr),"stderr_sha256":sha(p.stderr)}
 records.append(r);save(out/(label+".json"),r)
 if p.returncode: raise RuntimeError(label+" exited "+str(p.returncode))
 return p.stdout
def snapshot(label):
 v={}
 for field,args in [("head",["rev-parse","HEAD"]),("tree",["rev-parse","HEAD^{tree}"]),("rust_tree",["rev-parse","HEAD:codex-rs"]),("status",["status","--porcelain=v1","--untracked-files=all"]),("refs",["for-each-ref","--format=%(refname) %(objectname)"])]:
  p=subprocess.run(["git",*args],cwd=source,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=True)
  if p.stderr: raise RuntimeError("unexpected active source stderr")
  v[field]=p.stdout.decode()
 save(out/(label+".json"),v);return v
if out.exists(): raise SystemExit("Refusing existing merge-commit evidence")
out.mkdir()
try:
 result["source_before"]=snapshot("source-before")
 if result["source_before"]["head"].strip()!=head or result["source_before"]["tree"].strip()!=tree or result["source_before"]["status"]: raise RuntimeError("active source identity changed")
 identity=run("candidate-tree",["git","rev-parse",head+"^{tree}",head+":codex-rs"]).decode().splitlines()
 if identity!=[tree,rust_tree]: raise RuntimeError("candidate tree mismatch")
 base_commit=run("base-identity",["git","rev-parse","--verify",base+"^{commit}"]).decode().strip()
 if base_commit!=base: raise RuntimeError("base mismatch")
 result["review_refs_before"]=run("review-refs-before",["git","for-each-ref","--format=%(refname) %(objectname)"]).decode()
 (out/"message.txt").write_text(MERGE_MESSAGE,encoding="utf-8")
 commit=run("commit-tree",["git","commit-tree",tree,"-p",head,"-p",base,"-F",str(out/"message.txt")]).decode().strip()
 if not re.fullmatch(r"[0-9a-f]{40}",commit): raise RuntimeError("unexpected commit output")
 result["commit"]=commit
 raw=run("commit-object",["git","cat-file","-p",commit]).decode()
 headers=raw.split("\n\n",1)[0].splitlines()
 result["actual_parents"]=[x[7:] for x in headers if x.startswith("parent ")]
 result["actual_tree"]=[x[5:] for x in headers if x.startswith("tree ")][0]
 if result["actual_parents"]!=[head,base] or result["actual_tree"]!=tree: raise RuntimeError("created commit identity mismatch")
 result["actual_rust_tree"]=run("commit-rust-tree",["git","rev-parse",commit+":codex-rs"]).decode().strip()
 if result["actual_rust_tree"]!=rust_tree: raise RuntimeError("created Rust tree mismatch")
 run("first-parent-ancestor",["git","merge-base","--is-ancestor",head,commit])
 run("second-parent-ancestor",["git","merge-base","--is-ancestor",base,commit])
 diff=run("unchanged-tree-diff",["git","diff","--exit-code","--stat",head,commit])
 if diff: raise RuntimeError("nonempty tree diff")
 result["review_refs_after"]=run("review-refs-after",["git","for-each-ref","--format=%(refname) %(objectname)"]).decode()
 result["review_refs_unchanged"]=result["review_refs_before"]==result["review_refs_after"]
 result["status"]="created_and_verified" if result["review_refs_unchanged"] else "unexpected_ref_change"
except Exception as exc:
 result["status"]="failed";result["error"]=repr(exc)
finally:
 try:
  result["source_after"]=snapshot("source-after");result["source_unchanged"]=result.get("source_before")==result["source_after"]
 except Exception as exc:
  result["source_unchanged"]=False;result["source_after_error"]=repr(exc)
 result["commands"]=records;result["finished_unix"]=time.time()
 save(out/"result.json",result);print(json.dumps(result,ensure_ascii=False),flush=True)
sys.exit(0 if result["status"]=="created_and_verified" and result["source_unchanged"] else 1)
