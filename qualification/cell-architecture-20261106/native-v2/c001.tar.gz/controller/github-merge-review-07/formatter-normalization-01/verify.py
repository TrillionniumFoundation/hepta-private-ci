import hashlib,importlib.util,json,os,pathlib,shutil,subprocess,sys,time
root=pathlib.Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source"
repo=root/"merge-review/repository.git"
old_materials=root/"merge-review/formatter-a6"
materials=root/"merge-review/formatter-e01"
out=root/"evidence/github-merge-review-07/formatter-normalization-01"
old="a6f3aa12ba187448c35449c7da0a9798ae4ca987"
base="e01c860f9b43a88555dfe9120a86f7f451e760fd"
head="87cce8066b5f41e2d462b9469a301245f43d8c23"
merged="ff7480ac57f3f91046a4b155559873a281465d4d"
path="codex-rs/hepta-neuron/src/cell_test_support.rs"
toolchain=pathlib.Path("/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin")
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0",RUSTUP_TOOLCHAIN="1.96.0",PATH=str(toolchain)+os.pathsep+os.environ.get("PATH",""))
records=[]
result={"schema":1,"base":base,"head":head,"preliminary_merge_tree":merged,"status":"running","started_unix":time.time()}
def sha(d): return hashlib.sha256(d).hexdigest()
def oid(d): return hashlib.sha1(b"blob "+str(len(d)).encode()+b"\0"+d).hexdigest()
def save(path,v): path.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n")
def run(label,args,cwd=repo):
 p=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
 (out/(label+".stdout.log")).write_bytes(p.stdout)
 (out/(label+".stderr.log")).write_bytes(p.stderr)
 rec={"label":label,"argv":args,"cwd":str(cwd),"exit_code":p.returncode,"stdout_bytes":len(p.stdout),"stdout_sha256":sha(p.stdout),"stderr_bytes":len(p.stderr),"stderr_sha256":sha(p.stderr)}
 save(out/(label+".json"),rec); records.append(rec)
 if p.returncode: raise RuntimeError(label+" exited "+str(p.returncode))
 return p.stdout
def snapshot(label):
 v={}
 for field,args in [("head",["rev-parse","HEAD"]),("tree",["rev-parse","HEAD^{tree}"]),("rust_tree",["rev-parse","HEAD:codex-rs"]),("status",["status","--porcelain=v1","--untracked-files=all"]),("refs",["for-each-ref","--format=%(refname) %(objectname)"])]:
  p=subprocess.run(["git",*args],cwd=source,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=True)
  if p.stderr: raise RuntimeError("unexpected source snapshot stderr")
  v[field]=p.stdout.decode()
 save(out/(label+".json"),v); return v
if out.exists() or materials.exists(): raise SystemExit("Refusing existing normalization paths")
out.mkdir()
materials.mkdir()
try:
 result["source_before"]=snapshot("source-before")
 if result["source_before"]["head"].strip()!=head or result["source_before"]["status"]: raise RuntimeError("source changed")
 previous=json.loads((root/"evidence/github-merge-review-07/formatter-01/result.json").read_text())
 result["previous_result_sha256"]=sha((root/"evidence/github-merge-review-07/formatter-01/result.json").read_bytes())
 result["rustfmt_binary_sha256"]=sha((toolchain/"rustfmt").read_bytes())
 if result["rustfmt_binary_sha256"]!=previous["rustfmt_binary"]["sha256"]: raise RuntimeError("formatter binary changed")
 for meta in previous["context_files"]:
  original=(old_materials/meta["path"]).read_bytes()
  if sha(original)!=meta["sha256"]: raise RuntimeError("context changed")
  target=materials/meta["path"]; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(original)
 upstream=run("e01-original",["git","show",base+":"+path])
 candidate=run("head-original",["git","show",head+":"+path])
 normalized_a6=(old_materials/path).read_bytes()
 result["e01_is_head_plus_one_lf"]=upstream==candidate+b"\n"
 result["a6_formatted_equals_head"]=normalized_a6==candidate
 target=materials/path; target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(upstream)
 sys.dont_write_bytecode=True
 spec=importlib.util.spec_from_file_location("original_a6_formatter_normalization",materials/"scripts/format.py")
 module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
 command=module.rust_file_command(path,check=False)
 if command.args[:5]!=("rustfmt","--edition","2024","--config","imports_granularity=Item,skip_children=true"): raise RuntimeError("original formatter options changed")
 run("format-e01",list(command.args),command.cwd)
 normalized_e01=target.read_bytes()
 result["e01_formatted_equals_a6_formatted"]=normalized_e01==normalized_a6
 result["e01_formatted_equals_head"]=normalized_e01==candidate
 result["original_e01"]={"blob":oid(upstream),"sha256":sha(upstream),"bytes":len(upstream)}
 result["normalized_e01"]={"blob":oid(normalized_e01),"sha256":sha(normalized_e01),"bytes":len(normalized_e01)}
 result["normalized_a6"]={"blob":oid(normalized_a6),"sha256":sha(normalized_a6),"bytes":len(normalized_a6)}
 result["head_blob"]={"blob":oid(candidate),"sha256":sha(candidate),"bytes":len(candidate)}
 paths=run("merge-tree-vs-head-paths",["git","diff","--name-only",head,merged]).decode().splitlines()
 raw=run("merge-tree-vs-head-raw",["git","diff","--raw","--no-abbrev",head,merged]).decode()
 result["preliminary_merge_diff_paths"]=paths
 result["preliminary_merge_diff_raw"]=raw
 result["preliminary_merge_diff_only_conflicted_batch"]=paths==["codex-rs/hepta-neuron/src/cell_batch.rs"]
 result["nonconflicting_paths_exact_head"]=result["preliminary_merge_diff_only_conflicted_batch"]
 result["status"]="verified" if all(result[k] for k in ["e01_is_head_plus_one_lf","a6_formatted_equals_head","e01_formatted_equals_a6_formatted","e01_formatted_equals_head","preliminary_merge_diff_only_conflicted_batch"]) else "difference_found"
except Exception as exc:
 result["status"]="failed";result["error"]=repr(exc)
finally:
 try:
  result["source_after"]=snapshot("source-after");result["source_unchanged"]=result.get("source_before")==result["source_after"]
 except Exception as exc:
  result["source_unchanged"]=False;result["source_after_error"]=repr(exc)
 result["commands"]=records;result["finished_unix"]=time.time()
 save(out/"result.json",result);print(json.dumps(result,ensure_ascii=False),flush=True)
sys.exit(0 if result["status"]=="verified" and result["source_unchanged"] else 1)
