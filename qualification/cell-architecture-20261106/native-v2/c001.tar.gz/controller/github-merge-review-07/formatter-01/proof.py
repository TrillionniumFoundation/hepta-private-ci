import hashlib, importlib.util, json, os, pathlib, re, shutil, subprocess, sys, time

root = pathlib.Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source = root / "source"
repo = root / "merge-review/repository.git"
materials = root / "merge-review/formatter-a6"
evidence = root / "evidence/github-merge-review-07/formatter-01"
old = "a6f3aa12ba187448c35449c7da0a9798ae4ca987"
base = "e01c860f9b43a88555dfe9120a86f7f451e760fd"
head = "87cce8066b5f41e2d462b9469a301245f43d8c23"
toolchain = pathlib.Path("/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin")
env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_TERMINAL_PROMPT="0", RUSTUP_TOOLCHAIN="1.96.0", PATH=str(toolchain) + os.pathsep + os.environ.get("PATH", ""))
commands, blobs = [], []
result = {"schema": 1, "old_base": old, "current_base": base, "head": head, "materials": str(materials), "status": "running", "started_unix": time.time()}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git_blob_id(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def save_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def run(label, argv, cwd=repo, timeout=60, acceptable=(0,)):
    t = time.time()
    p = subprocess.run(argv, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    record = {"label": label, "argv": argv, "cwd": str(cwd), "exit_code": p.returncode, "elapsed_seconds": time.time()-t, "stdout_bytes": len(p.stdout), "stdout_sha256": sha(p.stdout), "stderr_bytes": len(p.stderr), "stderr_sha256": sha(p.stderr)}
    (evidence / (label + ".stdout.log")).write_bytes(p.stdout)
    (evidence / (label + ".stderr.log")).write_bytes(p.stderr)
    save_json(evidence / (label + ".json"), record)
    commands.append(record)
    if p.returncode not in acceptable:
        raise RuntimeError(label + " exited " + str(p.returncode))
    return p.stdout, p.returncode

def snapshot(label):
    values = {}
    for field, args in [
        ("head", ["rev-parse", "HEAD"]),
        ("tree", ["rev-parse", "HEAD^{tree}"]),
        ("rust_tree", ["rev-parse", "HEAD:codex-rs"]),
        ("status", ["status", "--porcelain=v1", "--untracked-files=all"]),
        ("refs", ["for-each-ref", "--format=%(refname) %(objectname)"]),
    ]:
        p = subprocess.run(["git", *args], cwd=source, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True, timeout=30)
        if p.stderr:
            raise RuntimeError("unexpected source snapshot stderr")
        values[field] = p.stdout.decode("utf-8")
    save_json(evidence / (label + ".json"), values)
    return values

def blob(commit, path, optional=False):
    argv = ["git", "ls-tree", commit, "--", path]
    p = subprocess.run(argv, cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True, timeout=30)
    if not p.stdout and optional:
        return None
    match = re.fullmatch(rb"([0-7]{6}) blob ([0-9a-f]{40})\t(.+)\n", p.stdout)
    if not match or match[3].decode() != path:
        raise RuntimeError("unexpected object lookup: " + path)
    mode, oid = match[1].decode(), match[2].decode()
    q = subprocess.run(["git", "cat-file", "blob", oid], cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True, timeout=30)
    if git_blob_id(q.stdout) != oid or p.stderr or q.stderr:
        raise RuntimeError("blob integrity/command failure: " + path)
    meta = {"commit": commit, "path": path, "mode": mode, "blob": oid, "bytes": len(q.stdout), "sha256": sha(q.stdout), "commands": [argv, ["git", "cat-file", "blob", oid]], "exit_codes": [0, 0]}
    blobs.append(meta)
    return q.stdout, meta

if evidence.exists() or materials.exists():
    raise SystemExit("Refusing existing formatter evidence/materials")
evidence.mkdir(parents=True)
materials.mkdir()
try:
    result["source_before"] = snapshot("source-before")
    if result["source_before"]["head"].strip() != head or result["source_before"]["status"]:
        raise RuntimeError("active source changed; refusing proof")
    listing, _ = run("changed-paths", ["git", "diff", "--name-only", old, base])
    paths = listing.decode().splitlines()
    if len(paths) != 7 or any(not x.startswith("codex-rs/hepta-neuron/src/") or not x.endswith(".rs") for x in paths):
        raise RuntimeError("expected exactly seven Neuron sources")
    context_candidates = ["scripts/format.py", "rustfmt.toml", ".rustfmt.toml", "rust-toolchain.toml", "Cargo.toml", "codex-rs/Cargo.toml", "codex-rs/rustfmt.toml", "codex-rs/.rustfmt.toml", "codex-rs/rust-toolchain.toml", "codex-rs/hepta-neuron/Cargo.toml", "codex-rs/hepta-neuron/rustfmt.toml", "codex-rs/hepta-neuron/.rustfmt.toml", "codex-rs/hepta-neuron/rust-toolchain.toml", "codex-rs/hepta-neuron/src/rustfmt.toml", "codex-rs/hepta-neuron/src/.rustfmt.toml"]
    result["context_files"], result["context_absent"] = [], []
    for path in context_candidates:
        item = blob(old, path, optional=True)
        if item is None:
            result["context_absent"].append(path)
            continue
        data, meta = item
        output = materials / path
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(data)
        result["context_files"].append(meta)
    for required in ["scripts/format.py", "codex-rs/Cargo.toml", "codex-rs/hepta-neuron/Cargo.toml", "codex-rs/rustfmt.toml", "codex-rs/rust-toolchain.toml"]:
        if not (materials / required).is_file():
            raise RuntimeError("missing original context " + required)
    toolpath = pathlib.Path(shutil.which("rustfmt", path=env["PATH"]))
    if toolpath != toolchain / "rustfmt":
        raise RuntimeError("wrong rustfmt binary")
    result["rustfmt_binary"] = {"path": str(toolpath), "bytes": toolpath.stat().st_size, "sha256": sha(toolpath.read_bytes())}
    rustc, _ = run("rustc-version", [str(toolchain / "rustc"), "--version"], materials)
    rustfmt, _ = run("rustfmt-version", [str(toolpath), "--version"], materials)
    if rustc.decode().split()[1] != "1.96.0":
        raise RuntimeError("not Rust 1.96.0")
    result["rustc_version"] = rustc.decode().strip()
    result["rustfmt_version"] = rustfmt.decode().strip()
    prior, rc = run("prior-format-commit", ["git", "rev-parse", "--verify", "37e6ffe9^{commit}"], acceptable=(0,128))
    result["prior_format_commit"] = prior.decode().strip() if rc == 0 else None
    if result["prior_format_commit"]:
        _, result["prior_format_ancestor_head_exit"] = run("prior-format-ancestor-head", ["git", "merge-base", "--is-ancestor", result["prior_format_commit"], head], acceptable=(0,1))
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("original_a6_formatter", materials / "scripts/format.py")
    formatter = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = formatter
    spec.loader.exec_module(formatter)
    result["method"] = "Unmodified a6 scripts/format.py rust_file_command(check=False), original manifests/rustfmt/toolchain config, pinned installed Rust 1.96.0; only seven independent blob copies are formatted."
    result["whole_workspace_cargo_fmt_run"] = False
    result["comparisons"] = []
    for i, path in enumerate(paths):
        before, original_meta = blob(old, path)
        upstream, upstream_meta = blob(base, path)
        current, current_meta = blob(head, path)
        prior_item = blob(result["prior_format_commit"], path) if result["prior_format_commit"] else None
        destination = materials / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(before)
        command = formatter.rust_file_command(path, check=False)
        if command.args[:5] != ("rustfmt", "--edition", "2024", "--config", "imports_granularity=Item,skip_children=true"):
            raise RuntimeError("unexpected original scoped formatter options")
        run("format-" + str(i+1).zfill(2), list(command.args), command.cwd)
        formatted = destination.read_bytes()
        comparison = {"path": path, "a6": original_meta, "e01": upstream_meta, "head87cc": current_meta, "prior37e6": prior_item[1] if prior_item else None, "formatted_a6": {"bytes": len(formatted), "blob": git_blob_id(formatted), "sha256": sha(formatted)}, "e01_equals_formatted_a6": upstream == formatted, "e01_equals_head87cc": upstream == current, "e01_equals_prior37e6": upstream == prior_item[0] if prior_item else None, "mode_preserved": original_meta["mode"] == upstream_meta["mode"] == current_meta["mode"]}
        result["comparisons"].append(comparison)
        print(json.dumps({"path": path, "e01_equals_formatted_a6": comparison["e01_equals_formatted_a6"], "e01_equals_head87cc": comparison["e01_equals_head87cc"], "e01_equals_prior37e6": comparison["e01_equals_prior37e6"], "e01_blob": upstream_meta["blob"], "head_blob": current_meta["blob"]}), flush=True)
    result["all_seven_exact_formatter_output"] = all(x["e01_equals_formatted_a6"] and x["mode_preserved"] for x in result["comparisons"])
    result["e01_head_equal_count"] = sum(x["e01_equals_head87cc"] for x in result["comparisons"])
    result["e01_prior_format_equal_count"] = sum(x["e01_equals_prior37e6"] is True for x in result["comparisons"])
    result["status"] = "verified" if result["all_seven_exact_formatter_output"] else "difference_found"
except Exception as exc:
    result["status"] = "failed"
    result["error"] = repr(exc)
finally:
    try:
        result["source_after"] = snapshot("source-after")
        result["source_unchanged"] = result.get("source_before") == result["source_after"]
    except Exception as exc:
        result["source_after_error"] = repr(exc)
        result["source_unchanged"] = False
    save_json(evidence / "blob-inputs.json", blobs)
    result["commands"] = commands
    result["finished_unix"] = time.time()
    save_json(evidence / "result.json", result)
    print(json.dumps({"status": result["status"], "error": result.get("error"), "all_seven_exact_formatter_output": result.get("all_seven_exact_formatter_output"), "e01_head_equal_count": result.get("e01_head_equal_count"), "source_unchanged": result["source_unchanged"], "result": str(evidence / "result.json")}), flush=True)
sys.exit(0 if result["status"] == "verified" and result["source_unchanged"] else 1)
