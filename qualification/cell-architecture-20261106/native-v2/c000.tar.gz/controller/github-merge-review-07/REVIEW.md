# Independent upstream merge review

## Result

The current upstream base advanced from `a6f3aa12ba187448c35449c7da0a9798ae4ca987` to `e01c860f9b43a88555dfe9120a86f7f451e760fd` by one commit touching seven Neuron files. A real content conflict exists only in `cell_batch.rs`; this was not merely a GitHub mergeability-cache observation.

Six upstream files are byte-for-byte equal to the original a6 blobs formatted with the repository's unmodified scoped formatter under Rust 1.96.0. The seventh, `cell_test_support.rs`, contains exactly one additional trailing LF. Applying the same formatter to that upstream file yields the exact same blob as formatted a6, the earlier candidate formatting commit, and the frozen candidate. The original first-pass result was therefore **6/7 exact**, and its failed/difference_found receipt remains intact.

With explicit root authorization, an actual two-parent merge commit was then created only in the independent review repository. It preserves the frozen candidate's entire tree. No remote reference or active-source reference was updated by this work.

## Commit and tree identities

- Frozen candidate / first parent: `87cce8066b5f41e2d462b9469a301245f43d8c23`.
- Current upstream / second parent: `e01c860f9b43a88555dfe9120a86f7f451e760fd`.
- Created local merge commit: `151dfe3d97fbe186269a2d6333ec04dbf665bde9`.
- Full resolved tree: `60604de0d6ea4805fd248574ba83fe49f16b261a`.
- Rust subtree: `3deb8503bc873331518c0c536a269c00d754a8bf`.
- Independent repository: `/home/qian-qi/work/cell-architecture-closure-20261106-9387/merge-review/repository.git`.
- Active native source: `/home/qian-qi/work/cell-architecture-closure-20261106-9387/source`.

The parent order, both ancestry relationships, unchanged tree diff, Rust subtree, independent-repository references, and active-source HEAD/tree/refs/status were checked after creation. The active source stayed clean and unchanged throughout. The independent repository was cloned with `--bare --no-local --no-hardlinks --single-branch`; Git handled the shallow boundaries, and only that independent repository fetched the exact current upstream commit.

## Seven-file comparison

All modes are `100644`. “Exact” compares original e01 bytes with formatter(a6), without whitespace normalization.

| File | e01 blob | Formatter(a6) blob | Frozen 87cc blob | Exact |
| --- | --- | --- | --- | --- |
| cell_batch.rs | `646b6814b9eecb843b22a8cc061d05a395f7bbd7` | `646b6814b9eecb843b22a8cc061d05a395f7bbd7` | `097e2216200cc48e500570eee1143d5a3c244ded` | Yes |
| cell_binding.rs | `669e52b01affd89b954d8ed099f8b097cf8ea488` | `669e52b01affd89b954d8ed099f8b097cf8ea488` | `669e52b01affd89b954d8ed099f8b097cf8ea488` | Yes |
| cell_inference.rs | `23e9f5a76787935ef5c1e2c01690ca25612212be` | `23e9f5a76787935ef5c1e2c01690ca25612212be` | `45cf9c7f9c897037627551a2217b7e14d8b09607` | Yes |
| cell_journal.rs | `630e2067393851755c08ee3cf51def9f1489b97b` | `630e2067393851755c08ee3cf51def9f1489b97b` | `630e2067393851755c08ee3cf51def9f1489b97b` | Yes |
| cell_journal_codec.rs | `1bfab0bde498bc86e8d926a4bb0ce945d1d1d557` | `1bfab0bde498bc86e8d926a4bb0ce945d1d1d557` | `1bfab0bde498bc86e8d926a4bb0ce945d1d1d557` | Yes |
| cell_owner.rs | `b223014428f4c700ab5fd14f2128278939ce15fe` | `b223014428f4c700ab5fd14f2128278939ce15fe` | `b223014428f4c700ab5fd14f2128278939ce15fe` | Yes |
| cell_test_support.rs | `d04dfd8e201c12ab1ab60a9071d766c9227b84b5` | `230983b21f16b821717139a29d05cb9f836cc1ad` | `230983b21f16b821717139a29d05cb9f836cc1ad` | No: one extra EOF LF |

Four original e01 files exactly equal frozen 87cc: binding, journal, journal codec, and owner. The inference file matched the earlier formatting commit and later received candidate logic changes. The batch file already contained candidate changes. The test-support exception is exactly one extra trailing LF: e01 has 8,561 bytes, while both normalized inputs and frozen 87cc have 8,560 bytes and blob `230983b21f16b821717139a29d05cb9f836cc1ad`.

## Formatter method and scope

The proof imports the unmodified original `scripts/format.py` from a6 and calls its original `rust_file_command(path, check=False)` for only the seven copied inputs. Original workspace/crate manifests, `codex-rs/rustfmt.toml`, and `codex-rs/rust-toolchain.toml` were also copied from a6.

The resulting command retains edition 2024 and `--config imports_granularity=Item,skip_children=true`, with the owning crate as working directory. The `skip_children` setting comes from the repository's original scoped formatter. This proof did not rerun full-workspace Cargo formatting or product tests.

- Compiler: `rustc 1.96.0 (ac68faa20 2026-05-25)`.
- Formatter: `rustfmt 1.9.0-stable (ac68faa20c 2026-05-25)`.
- Formatter binary SHA256: `342c3d56e8958da0b108108a39e37ceac64ebdd42e6eefafa237d219e5b7eb0c`.
- The stable-toolchain warning about `imports_granularity` is preserved in each raw stderr log.
- Initial full proof: `formatter-01/result.json`, status `difference_found`.
- Exact exception diff: `formatter-difference-01/e01-vs-formatted.stdout.log`.
- Separate normalization proof: `formatter-normalization-01/result.json`, status `verified`.

## Actual merge result

`git merge-base --all e01 87cc` returns a6. `git merge-tree --write-tree e01 87cc` exits 1 and produces preliminary tree `ff7480ac57f3f91046a4b155559873a281465d4d` with one conflict path, `codex-rs/hepta-neuron/src/cell_batch.rs`.

| Stage | Meaning | Blob |
| --- | --- | --- |
| 1 | Common a6 base | `37b5b5c20d36141b037a845e942794e8dabc2952` |
| 2 | Current e01 upstream | `646b6814b9eecb843b22a8cc061d05a395f7bbd7` |
| 3 | Frozen 87cc candidate | `097e2216200cc48e500570eee1143d5a3c244ded` |

A complete tree diff between the preliminary merge and 87cc lists only this conflicted batch file. Every automatically merged path already equals the frozen candidate, including test support. Retaining the reviewed candidate queue implementation therefore gives exactly tree `60604de0d6ea4805fd248574ba83fe49f16b261a`. The created commit uses that verified tree and the two actual parent commits.

## Durable jobs and preserved outcomes

| Job | Operation | Terminal outcome |
| --- | --- | --- |
| `1a1b3dc2618-fc05-8524` | Independent clone/fetch and merge observation | Succeeded, exit 0; underlying merge-tree exit 1 retained |
| `1a1b3ded39c-fc05-853c` | First formatter comparison | Failed, exit 1; 6/7 exact, difference_found retained |
| `1a1b3e0ade0-fc05-854b` | Exact exception diffs | Succeeded, exit 0 |
| `1a1b3e2ac09-fc05-8553` | Exception normalization and full merge-tree comparison | Succeeded, exit 0 |
| `1a1b3e52eec-fc05-8562` | Authorized local two-parent commit creation | Succeeded, exit 0 |

Each job's launch receipt, authoritative terminal status, complete controller stdout/stderr, and command-level logs are included. All five controller logs were checked against their terminal stored-byte counts. Remote evidence files were read back completely and independently verified against the returned file byte sizes and SHA256 values.

`remote-readback-manifest.json` records native paths, read versions, and SHA256 values for the 160 downloaded evidence/context/formatted files. `manifest.json` seals all local proof material except itself. Original prior-base observation remains in the sibling `github-merge-observation-06` directory, including raw remote references and the old a6 clean merge-tree result; no observation has been rewritten to hide the base movement or failed exact comparison.
