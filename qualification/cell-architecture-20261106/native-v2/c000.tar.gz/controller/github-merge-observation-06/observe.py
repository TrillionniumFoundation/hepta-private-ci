from pathlib import Path
import hashlib,json,subprocess,time
root=Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source"
evidence=root/"evidence/github-merge-observation-06"
evidence.mkdir()
base="a6f3aa12ba187448c35449c7da0a9798ae4ca987"
head="87cce8066b5f41e2d462b9469a301245f43d8c23"
expected_tree="60604de0d6ea4805fd248574ba83fe49f16b261a"
def git(*args):
    return subprocess.check_output(["git",*args],cwd=source,text=True).strip()
def identity():
    return {"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"rust_tree":git("rev-parse","HEAD:codex-rs"),"status":git("status","--porcelain")}
records=[]
def run(label,command,timeout=60):
    print(json.dumps({"event":"merge_observation_started","label":label,"command":command}),flush=True)
    timed_out=False
    try:
        p=subprocess.run(command,cwd=source,capture_output=True,check=False,timeout=timeout)
        stdout,stderr,returncode=p.stdout,p.stderr,p.returncode
    except subprocess.TimeoutExpired as error:
        stdout,stderr,returncode=error.stdout or b"",error.stderr or b"",None
        timed_out=True
    for name,value in (("stdout",stdout),("stderr",stderr)):
        with (evidence/(label+"."+name+".log")).open("xb") as stream:stream.write(value)
    record={"label":label,"command":command,"returncode":returncode,"timed_out":timed_out,"stdout_bytes":len(stdout),"stderr_bytes":len(stderr),"stdout_sha256":hashlib.sha256(stdout).hexdigest(),"stderr_sha256":hashlib.sha256(stderr).hexdigest()}
    records.append(record)
    with (evidence/(label+".json")).open("x") as stream:json.dump(record,stream,indent=2);stream.write("\n")
    print(json.dumps({"event":"merge_observation_complete",**record,"stdout":stdout.decode(errors="replace"),"stderr":stderr.decode(errors="replace")}),flush=True)
    return record,stdout.decode(errors="strict"),stderr.decode(errors="strict")
state={"label":"github-merge-observation-06","started_unix_ns":time.time_ns(),"source_sha":head,"base_sha":base,"expected_tree":expected_tree,"commands":records,"scope":"Read remote branch identities, local ancestry and merge-tree only. No checkout, real merge, fast-forward, worktree, refs or configuration mutations."}
try:
    before=identity();state["source_before"]=before
    if before["head"]!=head or before["tree"]!=expected_tree or before["status"]:
        raise RuntimeError("source differs from frozen clean head")
    git_version=run("git-version",["git","--version"])
    state["git_version"]=git_version[1].strip()
    shallow_name=git("rev-parse","--git-path","shallow")
    shallow=Path(shallow_name)
    if not shallow.is_absolute():shallow=source/shallow
    state["shallow"]={"path":str(shallow),"exists":shallow.exists(),"bytes":shallow.stat().st_size if shallow.exists() else None}
    replace_record,replace_stdout,_=run("replace-presence",["git","for-each-ref","--count=1","--format=present","refs/replace"])
    state["replace_refs_present"]=bool(replace_stdout.strip()) if replace_record["returncode"]==0 else None
    remote_record,remote_stdout,_=run("ls-remote",["git","ls-remote","origin","refs/heads/work/cell-unification-20261106","refs/heads/codex/cell-architecture-closure-20261106-9387"],timeout=120)
    refs={}
    if remote_record["returncode"]==0:
        for line in remote_stdout.splitlines():
            oid,name=line.split(None,1);refs[name]=oid
    state["remote_refs"]=refs
    state["remote_base_matches"]=refs.get("refs/heads/work/cell-unification-20261106")==base
    state["remote_source_matches"]=refs.get("refs/heads/codex/cell-architecture-closure-20261106-9387")==head
    ancestor_record,_,_=run("is-ancestor",["git","merge-base","--is-ancestor",base,head])
    state["base_is_ancestor"]=ancestor_record["returncode"]==0 if ancestor_record["returncode"] in (0,1) else None
    merge_record,merge_stdout,_=run("merge-tree",["git","merge-tree","--write-tree",base,head],timeout=120)
    state["merge_tree_first_line"]=merge_stdout.splitlines()[0] if merge_stdout.splitlines() else None
    state["merge_tree_matches_head_tree"]=merge_record["returncode"]==0 and state["merge_tree_first_line"]==expected_tree
    after=identity();state["source_after"]=after;state["source_unchanged"]=before==after
    if not state["source_unchanged"]:raise RuntimeError("source identity changed during observation")
    state["outcome"]="observed"
except Exception as error:
    state["outcome"]="failed"
    state["error"]={"type":type(error).__name__,"message":str(error)}
    try:state["source_after"]=identity()
    except Exception as nested:state["source_after_error"]=str(nested)
finally:
    state["finished_unix_ns"]=time.time_ns()
    with (evidence/"result.json").open("x") as stream:json.dump(state,stream,indent=2);stream.write("\n")
    print(json.dumps({"event":"merge_observation_result",**state},indent=2),flush=True)
raise SystemExit(0 if state["outcome"]=="observed" else 1)
