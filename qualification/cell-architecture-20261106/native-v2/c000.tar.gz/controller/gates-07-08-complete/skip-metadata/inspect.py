import hashlib,json,os,pathlib,stat,subprocess,time
root=pathlib.Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
repo=root/"merge-review/repository.git"
commit="87cce8066b5f41e2d462b9469a301245f43d8c23"
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0",GIT_TERMINAL_PROMPT="0")
result={"schema":1,"commit":commit,"run_id":"aa0d04a1-d9a0-4d47-b71f-76a135023c16","observed_profile":"local","commands":[],"target_inventory":[],"checked_unix":time.time()}
for label,args in [
 ("nextest-config-paths",["git","ls-tree","-r","--name-only",commit,"--","codex-rs/.config",".config"]),
 ("nextest-config",["git","show",commit+":codex-rs/.config/nextest.toml"]),
 ("root-nextest-config",["git","show",commit+":.config/nextest.toml"]),
 ("runner",["git","show",commit+":scripts/run_nextest.py"])]:
 p=subprocess.run(args,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
 row={"label":label,"argv":args,"cwd":str(repo),"exit_code":p.returncode,"stdout_bytes":len(p.stdout),"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_bytes":len(p.stderr),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest(),"stdout":p.stdout.decode(),"stderr":p.stderr.decode()}
 result["commands"].append(row)
target=root/"target/nextest"
result["target_nextest_exists"]=target.exists()
result["target_nextest_path"]=str(target)
if target.is_dir():
 pending=[(target,0)]
 while pending:
  directory,depth=pending.pop()
  for child in sorted(directory.iterdir(),key=lambda x:x.name):
   st=child.lstat()
   row={"path":str(child),"relative":str(child.relative_to(target)),"bytes":st.st_size,"mtime_ns":st.st_mtime_ns,"mode":stat.S_IMODE(st.st_mode),"kind":"symlink" if stat.S_ISLNK(st.st_mode) else "directory" if stat.S_ISDIR(st.st_mode) else "file" if stat.S_ISREG(st.st_mode) else "other"}
   result["target_inventory"].append(row)
   if len(result["target_inventory"])>200:raise RuntimeError("bounded nextest metadata inventory exceeded")
   if stat.S_ISDIR(st.st_mode) and depth<3:pending.append((child,depth+1))
   elif stat.S_ISREG(st.st_mode) and child.suffix in (".xml",".json") and st.st_size<=4194304:
    data=child.read_bytes();row["sha256"]=hashlib.sha256(data).hexdigest();row["contains_exact_run_id"]=result["run_id"].encode() in data
print(json.dumps(result,ensure_ascii=False),flush=True)
