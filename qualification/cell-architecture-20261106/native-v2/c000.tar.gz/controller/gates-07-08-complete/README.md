# Complete native gate 07/08 evidence

## Scope and immutable test identity

This directory preserves complete controller output for the original native gate jobs and the original four-package test and strict Clippy helper logs. It does not replace any earlier receipt or retag the tested source.

- Tested commit: `87cce8066b5f41e2d462b9469a301245f43d8c23`.
- Full source tree: `60604de0d6ea4805fd248574ba83fe49f16b261a`.
- Rust subtree: `3deb8503bc873331518c0c536a269c00d754a8bf`.
- Both gate 08 helper records report identical clean before/after source identity.
- No source, Git reference, test profile, filter, budget, cache, or target content was changed by this collection.

## Actual nextest result

The original log reports run ID `aa0d04a1-d9a0-4d47-b71f-76a135023c16` with profile `local`:

```text
Starting 990 tests across 31 binaries (66 tests skipped)
Summary [228.914s] 990 tests run: 990 passed (1 slow), 66 skipped
```

There are exactly 990 PASS rows, with no FAIL/CANCEL/TIMEOUT/LEAK result rows. The original report says **31 binaries**; 29 distinct binary names have PASS rows. These are separate observations, not interchangeable counts.

| Package | PASS rows |
| --- | ---: |
| codex-hepta-agentd | 639 |
| codex-hepta-automation | 143 |
| codex-hepta-neuron | 177 |
| codex-hepta-runtime | 31 |
| Total | 990 |

The one slow test, `runtime::hos2_recovery_tests::actual_reconciler_asks_original_issuer_for_same_k_d_and_does_not_resend_unknown`, ultimately passed in 36.558 seconds.

The test helper ran the unchanged original command:

```text
just test --locked -p codex-hepta-neuron -p codex-hepta-automation -p codex-hepta-runtime -p codex-hepta-agentd --retries 0
```

It exited 0 after 1070.945293 seconds including compilation. Strict Clippy ran the same four packages with `just clippy --locked ... -- -D warnings` and exited 0 after 288.666849 seconds.

## Skipped-test evidence boundary

The original text log has no per-test SKIP rows. Consequently, the 66 skipped tests' individual names and reasons are **not verified** by this collection.

Read-only inspection of the exact tested commit found `codex-rs/.config/nextest.toml`, whose default profile configures `junit.xml` and whose local-profile comment describes implicit inheritance for nextest 0.9.103. The independent task's `target/nextest` directory was observed absent. Subsequent file-info probes for the two workspace JUnit candidate paths timed out in the MCP service; those timeouts are preserved and are not reported as proof of file absence. No `nextest list` or test execution was launched to reconstruct missing metadata.

The bounded metadata observation job `1a1b3f11f3b-fc05-8592` completed successfully with 8,437 bytes of controller stdout and no stderr. Its command-level records retain two unsuccessful exploratory Git path lookups. The local collector's initial Python syntax error is also retained; it did not run or modify product code.

## Gate 07 failures remain intact

Original gate 07, job `1a1b3cfd4cb-fc05-84df`, terminated failed with exit 1. Its result records include:

| Entry | Original outcome |
| --- | --- |
| PR formatting | Passed |
| Typed tests | Passed |
| B4 tests | Passed |
| Caller proof | Failed, exit 124 |
| Archive tests, verification, tree checks | Passed |
| Codespell | Passed |
| Underlying Prettier | Failed, exit 1 |
| Full Ruff diagnostic | Failed, exit 1 |

These original failures are preserved. Follow-up remediation and later verification belong to their own evidence records.

## Complete log integrity

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| Gate 07 controller stdout | 49,992 | `5e55c787617592e6a1fc14eb9fc764d144d468346695741e44c6529f2bd3cf7c` |
| Gate 08 controller stdout | 223,063 | `3eb51398ce461ad1560abba31c3a5ef62c963c6c278853df89483d1cb8181d2a` |
| Gate 08 original test helper log | 196,194 | `be7cb119b5ed389a430e2544e0ee7dad22c05d17b1563a046d2d9d66d39efdec` |
| Gate 08 original strict Clippy helper log | 22,176 | `337d289653bc16a27be1b48ad8e6dac2ec2bc3b51bdf4d12e499410812b9c301` |

Both original controller stderr streams are empty. Both authoritative terminal receipts confirm complete durable output without truncation.

Existing controller chunks were copied into this new directory without modifying their original directories. Missing gate 08 output from offset 32,797 through 223,063 was fetched using the original job identity and exact offsets. `controller-assembly.json` records every byte range, source receipt, hash, and complete coverage. Conflicting overlapping bytes would have failed assembly.

The helper test log was read in version-pinned chunks; its complete byte count and SHA256 match the original helper record. A separately read tail overlaps and matches the assembled log exactly. The Clippy log matches its original helper record as well. Both complete helper logs are also exact contiguous matches inside the assembled controller stdout, as recorded in `helper-controller-links.json`.

`manifest.json` seals this directory only. It does not claim that later gate 09 or source-integration evidence has been incorporated into a final combined archive.
