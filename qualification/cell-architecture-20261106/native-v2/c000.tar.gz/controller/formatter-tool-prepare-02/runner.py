from pathlib import Path
import base64,hashlib,json,os,re,subprocess,sys,tarfile,time
root=Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source"
evidence=root/"evidence/formatter-tool-prepare-02";evidence.mkdir()
tool_root=root/"tools";bin_dir=tool_root/"bin"
downloads=tool_root/"npm-locked-downloads-02";downloads.mkdir()
env=os.environ.copy();env["npm_config_cache"]=str(tool_root/"npm-cache-02")
env["PATH"]=str(bin_dir)+":"+env["PATH"]
records=[]
def run(label,command):
    print(json.dumps({"event":"tool_command_started","label":label,"command":command}),flush=True)
    p=subprocess.run(command,cwd=downloads,env=env,capture_output=True,timeout=240,check=False)
    for name in ("stdout","stderr"):(evidence/(label+"."+name+".log")).write_bytes(getattr(p,name))
    record={"label":label,"command":command,"returncode":p.returncode,"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest()}
    records.append(record);(evidence/(label+".json")).write_text(json.dumps(record,indent=2)+"\n")
    print(json.dumps({"event":"tool_command_complete",**record}),flush=True)
    if p.returncode:raise RuntimeError(label+" failed")
    return p.stdout.decode()
source_inputs={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/"package.json",source/"pnpm-lock.yaml")}
pm=json.loads((source/"package.json").read_text())["packageManager"]
if not pm.startswith("pnpm@10.34.5+sha512."):raise RuntimeError("unexpected pnpm pin")
pnpm_sha512=pm.split("+sha512.",1)[1]
lock=(source/"pnpm-lock.yaml").read_text()
match=re.search(r"(?m)^  prettier@3\.5\.3:\n    resolution: \{integrity: ([^}]+)\}",lock)
if match is None:raise RuntimeError("Prettier lock integrity missing")
prettier_integrity=match.group(1).strip().strip("'\"")
tools=[]
for name,version,expected in (("pnpm","10.34.5",pnpm_sha512),("prettier","3.5.3",prettier_integrity)):
    info=json.loads(run("pack-"+name,["/usr/bin/npm","pack",name+"@"+version,"--ignore-scripts","--json","--pack-destination",str(downloads)]))
    if len(info)!=1:raise RuntimeError("ambiguous package response")
    archive=downloads/info[0]["filename"]
    raw=archive.read_bytes();digest=hashlib.sha512(raw).digest()
    if name=="pnpm":
        if digest.hex()!=expected:raise RuntimeError("pnpm tarball differs from packageManager integrity")
    else:
        if "sha512-"+base64.b64encode(digest).decode()!=expected:raise RuntimeError("Prettier tarball differs from pnpm lock integrity")
    destination=tool_root/(name+"-"+version+"-verified");destination.mkdir()
    with tarfile.open(archive,"r:gz") as tar:
        for member in tar.getmembers():
            if not member.name.startswith("package/") or member.issym() or member.islnk():raise RuntimeError("unexpected package member")
        tar.extractall(destination,filter="data")
    entry=destination/"package/bin"/(name+".cjs")
    os.symlink(entry,bin_dir/name)
    observed=run(name+"-version",["/usr/bin/node",str(entry),"--version"]).strip()
    if observed!=version:raise RuntimeError(name+" version differs from repository")
    tools.append({"name":name,"version":observed,"entry":str(entry),"entry_sha256":hashlib.sha256(entry.read_bytes()).hexdigest(),"archive":str(archive),"archive_sha256":hashlib.sha256(raw).hexdigest(),"archive_sha512":digest.hex(),"verified_original_pin":expected})
for path,digest in source_inputs.items():
    if hashlib.sha256((source/path).read_bytes()).hexdigest()!=digest:raise RuntimeError("tool dependency inputs changed during preparation")
result={"outcome":"prepared","tools":tools,"source_dependency_hashes":source_inputs,"commands":records,"finished_unix_ns":time.time_ns(),"scope":"Official registry packages verified against original source integrity; task-local paths only; no product source or gate executed"}
(evidence/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"event":"tools_prepared",**result}),flush=True)
