import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import {pathToFileURL} from "node:url";
const [plugin, before, after, rosterFile, output] = process.argv.slice(2);
const {parsers} = await import(pathToFileURL(plugin).href);
const excluded = new Set(["start", "end", "loc", "range", "comments", "leadingComments", "trailingComments", "innerComments", "tokens"]);
const extraLayout = new Set(["raw", "rawValue", "parenthesized", "parenStart", "trailingComma"]);
function normalize(value, inExtra = false) {
  if (Array.isArray(value)) return value.map(item => normalize(item));
  if (value !== null && typeof value === "object") {
    const pairs = Object.keys(value).sort()
      .filter(key => !excluded.has(key) && !(inExtra && extraLayout.has(key)))
      .map(key => [key, normalize(value[key], key === "extra")])
      .filter(([key, child]) => key !== "extra" || child === null || Object.keys(child).length !== 0);
    return Object.fromEntries(pairs);
  }
  if (typeof value === "number" && !Number.isFinite(value)) return {nonFiniteNumber: String(value)};
  return value;
}
const digest = value => crypto.createHash("sha256").update(value).digest("hex");
const paths = JSON.parse(fs.readFileSync(rosterFile, "utf8"));
const records = [];
for (const name of paths) {
  const original = fs.readFileSync(path.join(before, name), "utf8");
  const formatted = fs.readFileSync(path.join(after, name), "utf8");
  const left = await parsers.babel.parse(original, {filepath:name});
  const right = await parsers.babel.parse(formatted, {filepath:name});
  if ((left.errors?.length ?? 0) || (right.errors?.length ?? 0)) throw new Error("Parser errors in " + name);
  const a = JSON.stringify(normalize(left));
  const b = JSON.stringify(normalize(right));
  records.push({path:name,before_sha256:digest(original),after_sha256:digest(formatted),before_ast_sha256:digest(a),after_ast_sha256:digest(b),ast_equal:a===b,before_comments:left.comments?.length??null,after_comments:right.comments?.length??null});
}
const result={parser:"Prettier 3.5.3 bundled babel",excluded_layout_fields:[...excluded].sort(),excluded_extra_layout_fields:[...extraLayout].sort(),scope:"Strict recursive sorted-key AST comparison. raw is preserved everywhere except explicit extra formatting metadata; all TemplateElement.value.raw, literal values, RegExp pattern/flags and other semantic node fields are retained. Non-finite numbers are represented explicitly.",all_ast_equal:records.every(r=>r.ast_equal),files:records};
fs.writeFileSync(output,JSON.stringify(result,null,2)+"\n",{flag:"wx"});
console.log(JSON.stringify({files:records.length,all_ast_equal:result.all_ast_equal}));
if (!result.all_ast_equal) process.exitCode=1;
