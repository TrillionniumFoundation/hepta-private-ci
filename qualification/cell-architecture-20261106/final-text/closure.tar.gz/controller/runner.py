from pathlib import Path
import gzip,hashlib,io,json,os,re,subprocess,tarfile,time
root=Path("/home/qian-qi/work/cell-architecture-closure-20261106-9387")
source=root/"source";out=root/"evidence/final-text-closure-12";out.mkdir()
expected="e585b90d09a2565e04394d47e1576092b0e9be70";expected_tree="81ff0f7e2ed7a06f677168c9cd4ccc6ec133073a"
previous="4ce8808d8b48624a17d247fdf47c7fbdaaab80a4";rust="3deb8503bc873331518c0c536a269c00d754a8bf"
branch="codex/cell-architecture-closure-20261106-9387";inputs={"scripts/hepta_typed_callers.py":"0774d796759876fab1873a2a1dcbb4c91210533d34edbe32707fb8f52b9d569c","scripts/test_hepta_typed_callers.py":"059d636fe604217c7c01975e50c5d8a3074445fd5bc31ef8652b09220c4dd0d5","scripts/verify_hepta_callers.py":"ff62f959e78225aa198ec73d0cfe3747bab3a85f80e58fccec7857e407486f71","CALLERS.toml":"715df436da33503674ca02453360d1f03e2d919c2fd8d9e059eca9efd90be0ee","qa/b4-no-bypass/KERNEL_AUTHORITY_BOUNDARIES.json":"aa38dd3e67013b55fba4080f92d31c6932cf78d477a9df3d40abb64858bf7fbc","qa/b4-no-bypass/test_verify_hepta_callers.py":"dba4c5421ed30f7ea83d2b9c160b38a3570fc05cae7de5f68310d47062783c1d","qa/b4-no-bypass/test_kernel_authority_closed_world.py":"5ea3ab6a21f48e90f414d7e7865d1ec77008c1006b4262a4ea489cca096f035a","qa/b4-no-bypass/test_root_admin_source_closure.py":"aa5036a5498383d8c4968f7fc546d1e93c15e10b7bb76cd288804100273a8b7e"}
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0",GIT_TERMINAL_PROMPT="0",PYTHONDONTWRITEBYTECODE="1",CODEX_REPO_ROOT=str(source))
records=[];result={"scope":"Final documentation and evidence text/path closure only; no Rust, Python test suites, full caller audit, or Prettier rerun.","requested_revision":expected,"requested_tree":expected_tree,"started_unix_ns":time.time_ns(),"gates":[]}
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,value):
    with (out/name).open("x") as f:json.dump(value,f,indent=2);f.write("\n")
def run(label,args,timeout=180,required=True):
    started=time.time_ns()
    try:
        p=subprocess.run(args,cwd=source,env=env,capture_output=True,timeout=timeout,check=False)
        stdout,stderr,code,timed_out=p.stdout,p.stderr,p.returncode,False
    except subprocess.TimeoutExpired as exc:
        stdout,stderr,code,timed_out=exc.stdout or b"",exc.stderr or b"",124,True
    (out/(label+".stdout.log")).write_bytes(stdout);(out/(label+".stderr.log")).write_bytes(stderr)
    record={"label":label,"command":args,"returncode":code,"timed_out":timed_out,"started_unix_ns":started,"finished_unix_ns":time.time_ns(),"stdout_bytes":len(stdout),"stdout_sha256":sha(stdout),"stderr_bytes":len(stderr),"stderr_sha256":sha(stderr)}
    save(label+".json",record);records.append(record)
    print(json.dumps({"event":"final_text_command","label":label,"returncode":code,"timed_out":timed_out}),flush=True)
    if stdout:print(stdout.decode(errors="replace"),end="",flush=True)
    if stderr:print(stderr.decode(errors="replace"),end="",flush=True)
    if required and code:raise RuntimeError(label+" exited "+str(code))
    return stdout
def git(*args):return subprocess.check_output(["git",*args],cwd=source,env=env,text=True).strip()
def identity():
    return {"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"rust_tree":git("rev-parse","HEAD:codex-rs"),"status":git("status","--porcelain=v1","--untracked-files=all"),"audit_input_sha256":{name:sha((source/name).read_bytes()) for name in inputs}}
try:
    result["checkout_before"]=identity();save("checkout-before.json",result["checkout_before"])
    if result["checkout_before"]["head"]!=previous or result["checkout_before"]["status"]:raise RuntimeError("previous published checkout differs")
    remote=run("remote-head-before",["git","ls-remote","--heads","origin","refs/heads/"+branch]).decode().strip().split()
    if remote!=[expected,"refs/heads/"+branch]:raise RuntimeError("remote head moved; stopping before fetch/FF")
    run("fetch-final",["git","fetch","origin",branch])
    if git("rev-parse","FETCH_HEAD")!=expected:raise RuntimeError("fetched revision differs")
    run("previous-ancestor",["git","merge-base","--is-ancestor",previous,expected])
    changed=run("changed-paths",["git","diff","--name-only",previous,expected]).decode().splitlines()
    if len(changed)!=28 or any(not name.startswith("qualification/") for name in changed):raise RuntimeError("expected documentation/evidence-only 28-file delta differs")
    result["changed_paths"]=changed
    run("fast-forward-final",["git","merge","--ff-only",expected])
    before=identity();result["source_before"]=before;save("source-before.json",before)
    if (before["head"],before["tree"],before["rust_tree"],before["status"])!=(expected,expected_tree,rust,"") or before["audit_input_sha256"]!=inputs:raise RuntimeError("final clean tree/Rust/audit identity differs")
    codespell="/home/qian-qi/work/hepta-architecture-20261025/codespell-2.4.3-venv-v1/bin/codespell"
    version=run("codespell-version",[codespell,"--version"],timeout=30).decode().strip()
    if version!="2.4.3":raise RuntimeError("original codespell version differs")
    env.update(HEPTA_CI_LANE="source-head",SOURCE_SHA=expected,TESTED_SHA=expected,BASE_SHA="e01c860f9b43a88555dfe9120a86f7f451e760fd")
    commands=[
    ("codespell",600,[codespell,"--ignore-words",".codespellignore","--skip","./.git"]),
    ("architecture-path-budget",600,["python3","-B","scripts/hepta_evidence_archive.py","check-tree","--revision",expected,"--prefix","qualification/cell-architecture-20261106"]),
    ("unification-path-budget",600,["python3","-B","scripts/hepta_evidence_archive.py","check-tree","--revision",expected,"--prefix","qualification/cell-unification-20261106"]),
    ("changed-text-whitespace",120,["git","diff","--check",previous,expected]),
    ]
    for label,timeout,command in commands:
        if identity()!=before:raise RuntimeError("source changed between text gates")
        target=out/(label+".json")
        args=["python3","scripts/hepta_ci_exec.py","--timeout-seconds",str(timeout),"--minimum-tests","0","--output",str(target),"--",*command]
        run("execute-"+label,args,timeout=timeout+30,required=False)
        gate=json.loads(target.read_text()) if target.is_file() else {"status":"missing"}
        result["gates"].append({"label":label,"record":gate})
        print(json.dumps({"event":"final_text_gate_terminal","label":label,"status":gate.get("status"),"exit_code":gate.get("exit_code"),"log_file":gate.get("log_file")}),flush=True)
    result["source_after"]=identity();save("source-after.json",result["source_after"])
    result["status"]="passed" if len(result["gates"])==4 and all(g["record"].get("status")=="passed" and g["record"].get("exit_code")==0 for g in result["gates"]) and result["source_after"]==before else "failed"
except Exception as exc:
    result["status"]="failed";result["error"]=repr(exc)
    try:result["source_after_error"]=identity()
    except Exception as follow:result["source_after_error"]={"error":repr(follow)}
finally:
    result["commands"]=records;result["finished_unix_ns"]=time.time_ns();save("result.json",result)
    print(json.dumps({"event":"final_text_closure_terminal","status":result["status"],"error":result.get("error"),"source":result.get("source_after",result.get("source_after_error"))}),flush=True)
pack=root/"final-text-closure-12-pack";pack.mkdir()
members=[];raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode="w",format=tarfile.PAX_FORMAT) as tar:
    for path in sorted(out.iterdir()):
        if not path.is_file() or path.is_symlink() or path.stat().st_nlink!=1:raise RuntimeError("unexpected closure record")
        data=path.read_bytes();name="records/"+path.name
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.uid=0;info.gid=0;info.uname="";info.gname="";info.mtime=0
        tar.addfile(info,io.BytesIO(data));members.append({"member":name,"bytes":len(data),"sha256":sha(data)})
compressed=io.BytesIO()
with gzip.GzipFile(fileobj=compressed,filename="",mode="wb",compresslevel=9,mtime=0) as stream:stream.write(raw.getvalue())
payload=compressed.getvalue()
if len(payload)>=480000:raise RuntimeError("light closure pack exceeds file budget")
(pack/"records.tar.gz").write_bytes(payload)
manifest={"schema":"hepta.final-text-closure.v1","source_revision":expected,"source_tree":expected_tree,"rust_tree":rust,"outcome":result["status"],"archive":{"path":"records.tar.gz","bytes":len(payload),"sha256":sha(payload)},"member_count":len(members),"total_member_bytes":sum(m["bytes"] for m in members),"members":members}
(pack/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps({"event":"final_text_closure_packed","archive":manifest["archive"],"member_count":len(members),"manifest_sha256":sha((pack/"manifest.json").read_bytes())}),flush=True)
raise SystemExit(0 if result["status"]=="passed" else 1)
