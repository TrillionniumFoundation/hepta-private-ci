import os,json,hashlib,subprocess,time,base64,lzma
from pathlib import Path
root=Path('/home/qian-qi/worktrees/hepta-eval-recovery-173a-20261109')
e=Path('/home/qian-qi/worktrees/hepta-eval-recovery-173a-20261109-native')
passed=json.loads((e/'attempt-02/result.json').read_text())
assert passed['exit_code']==0 and passed['source_unchanged']
out=e/'maintenance-01';out.mkdir(exist_ok=False)
before=json.loads((e/'attempt-02/source-after.json').read_text())
for n,v in before.items():
 p=root/n
 data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
 assert hashlib.sha256(data).hexdigest()==v['sha256'],n
env=os.environ.copy()
env.update(PATH='/home/qian-qi/.cargo/bin:'+env.get('PATH',''),RUSTUP_TOOLCHAIN='1.96.0',CARGO_TARGET_DIR=str(e/'target'),CARGO_BUILD_JOBS='4',CARGO_INCREMENTAL='0')
results=[]
for name,cmd in [('fix',['just','fix','--locked','--offline','-p','codex-hepta-intelligence-eval']),('fmt',['just','fmt'])]:
 start=time.time()
 with (out/(name+'.log')).open('wb') as log:
  p=subprocess.run(['/usr/bin/time','-v','-o',str(out/(name+'-time.txt'))]+cmd,cwd=root/'codex-rs',env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'exit_code':p.returncode,'elapsed_seconds':time.time()-start})
 print(json.dumps(results[-1]),flush=True)
 print((out/(name+'.log')).read_text(errors='replace')[-8000:],flush=True)
 if p.returncode:break
after={}
for n,v in before.items():
 p=root/n
 data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
 after[n]={'sha256':hashlib.sha256(data).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
changes=[n for n in before if before[n]['sha256']!=after[n]['sha256']]
(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,separators=(',',':')))
summary={'results':results,'changed_by_maintenance':changes,'tests_rerun_after_maintenance':False}
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
raise SystemExit(next((r['exit_code'] for r in results if r['exit_code']),0))
