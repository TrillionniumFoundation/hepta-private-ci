import os,json,hashlib,subprocess,time,tarfile,io
from pathlib import Path
root=Path('/home/qian-qi/worktrees/hepta-eval-recovery-173a-20261109')
e=Path('/home/qian-qi/worktrees/hepta-eval-recovery-173a-20261109-native')
m=e/'maintenance-01'
maintenance=json.loads((m/'result.json').read_text())
assert len(maintenance['results'])==2 and all(x['exit_code']==0 for x in maintenance['results'])
before=json.loads((m/'source-after.json').read_text())
env=os.environ.copy();env.update(PATH='/home/qian-qi/.cargo/bin:'+env.get('PATH',''),RUSTUP_TOOLCHAIN='1.96.0',CARGO_TARGET_DIR=str(e/'target'),CARGO_BUILD_JOBS='4',CARGO_INCREMENTAL='0')
cmd=['cargo','check','--locked','--offline','-p','codex-hepta-intelligence-eval','--lib']
start=time.time()
with (m/'check.log').open('wb') as log:
 p=subprocess.run(['/usr/bin/time','-v','-o',str(m/'check-time.txt')]+cmd,cwd=root/'codex-rs',env=env,stdout=log,stderr=subprocess.STDOUT)
summary={'command':cmd,'exit_code':p.returncode,'elapsed_seconds':time.time()-start,'behavior_tests_rerun':False}
for n,v in before.items():
 q=root/n;data=os.readlink(q).encode() if q.is_symlink() else q.read_bytes()
 assert hashlib.sha256(data).hexdigest()==v['sha256'],n
summary['source_unchanged']=True
(m/'check-result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
print((m/'check.log').read_text(),flush=True)
assert p.returncode==0
candidate=json.loads((e/'attempt-02/candidate-files.json').read_text())
manifest=[]
for r in candidate:
 data=(root/r['path']).read_bytes()
 manifest.append({'path':r['path'],'bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest(),'baseline_blob':r['baseline_blob']})
(m/'final-candidate-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
def archive(path,items):
 with tarfile.open(path,'w:xz',preset=6) as out:
  for name,data in sorted(items):
   info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;info.uid=info.gid=0
   out.addfile(info,io.BytesIO(data))
 return {'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
sources=archive(e/'final-sources.tar.xz',[(r['path'],(root/r['path']).read_bytes()) for r in candidate])
items=[]
for folder in ['attempt-01','attempt-02','maintenance-01']:
 for path in (e/folder).iterdir():
  if path.is_file():items.append((folder+'/'+path.name,path.read_bytes()))
items.append(('MANIFEST.json',(json.dumps([{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(items)],indent=2)+'\n').encode()))
evidence=archive(e/'native-evidence-v1.tar.xz',items)
print(json.dumps({'sources':sources,'evidence':evidence,'files':manifest}),flush=True)
