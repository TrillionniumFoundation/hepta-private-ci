import hashlib,json,subprocess,time,tomllib
from pathlib import Path
root=Path('/workspace/scratch/173a4f734dee/hepta-learning')
out=Path('/workspace/scratch/173a4f734dee/source-closure-final')
out.mkdir(exist_ok=False)
def inventory():
 data=tomllib.loads((root/'CALLERS.toml').read_text())
 paths={root/'CALLERS.toml'}
 for source in data['source_roots']:paths.update((root/source).rglob('*.rs'))
 paths.update((root/'scripts').glob('*.py'))
 paths.update(root/r['path'] for r in data.get('protected_file',[]))
 return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=inventory()
(out/'inputs-before.json').write_text(json.dumps(before,sort_keys=True,separators=(',',':')))
start=time.time()
with (out/'receipt.json').open('wb') as log,(out/'stderr.log').open('wb') as err:
 result=subprocess.run(['python3','scripts/verify_hepta_callers.py','verify'],cwd=root,stdout=log,stderr=err)
after=inventory()
(out/'inputs-after.json').write_text(json.dumps(after,sort_keys=True,separators=(',',':')))
summary={'command':['python3','scripts/verify_hepta_callers.py','verify'],'exit_code':result.returncode,'elapsed_seconds':time.time()-start,'inputs_unchanged':before==after,'input_files':len(before),'inputs_sha256':hashlib.sha256((out/'inputs-before.json').read_bytes()).hexdigest()}
if result.returncode==0:
 receipt=json.loads((out/'receipt.json').read_text())
 summary.update(status=receipt['status'],rust_files=receipt['rustFilesScanned'],boundaries=len(receipt['boundaries']),protected_rows=len(receipt['protectedFiles']),authority_granted=receipt['authorityGranted'])
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
print((out/'stderr.log').read_text()[-3000:],flush=True)
assert before==after
raise SystemExit(result.returncode)
