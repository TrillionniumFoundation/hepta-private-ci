#!/usr/bin/env python3
"""Package only frozen post-publication caller-proof evidence; run no checks."""
import argparse
import datetime
import hashlib
import json
import os
import pathlib
import re
import stat
import zipfile

ROOT = pathlib.Path("/home/qian-qi/work/cell-s0s5-20261108-1628")
OUT = ROOT / "joint-publication/caller-proof-delivery-prep"
SOURCE_ROOTS = [
    "joint-publication/caller-proof-followup",
    "joint-publication/build-test-ci-failures",
    "joint-publication/caller-proof-review-s3",
    "joint-publication/source-blob-ci-failure",
    "joint-caller-proof-validation-v1",
    "joint-caller-proof-finalization",
    "joint-publication/root-caller-proof-review",
]
BASE_HEAD = "710df84a6b10afa005976c24a1108fb2a57810d3"
CODE_HEAD = "81da60b349e32d89d0e4c4674a517a66af7e5eee"
CODE_TREE = "cc6ca8d7c05a2b5d6ccc9179a570c6efc71e4d83"
PATCH_SHA = "ecd500c22fa388c14d08793ac22ba11f4738597c1d1ce3c83ddb5210947b0fe6"
REQUIRED_PINS = {
    "joint-caller-proof-validation-v1/RESULT.json": [3941, "e9efe35968f58e1cc15b41bcce475727cbbef3e0957fc286e21fd7a199537eb5"],
    "joint-caller-proof-validation-v1/STATIC_RUNTIME_INPUT_REVIEW.json": [2710, "189ce55f2b04b755e5b72b4614e6a289e9b735be706192ce7f0ba2310e98e10d"],
    "joint-caller-proof-finalization/FORMAT_IDENTITY.json": [2420, "8438abd001576284e3e7558a58c35891652134fbd29fbd005919a9d55ee71946"],
    "joint-caller-proof-finalization/PATCH_AFTER_FMT.diff": [12003, PATCH_SHA],
    "joint-publication/caller-proof-followup/CODE_READY.json": [1292, "a82a05641e38bc309a593f7d7ca2fa4f53b3b987e6bc7ae2a53fa44e5d86696e"],
    "joint-publication/caller-proof-review-s3/FINAL_COMMIT_REVIEW.json": [4841, "b5e402c2aba6bf80e19f2eb5cd62541904d810a6df8d9e55578ea13e4ad66604"],
    "joint-publication/root-caller-proof-review/ROOT_REVIEW.json": [2634, "2d32d56f307dcd28559afbf2487989518a25ba483f2290522467145572b16637"],
    "joint-publication/root-caller-proof-review/GITHUB_BLOB_RERUN_RESPONSE.json": [500, "fa3c93f4191fb990992573ac81c8f10dd4c5c993ebdb159904589d8718714831"],
}
SCOPE = {
    "tested_static_source": "dirty " + BASE_HEAD + " plus exact patch " + PATCH_SHA,
    "committed_static_source": {"head": CODE_HEAD, "tree": CODE_TREE},
    "static_scope": "Caller proof self-test, full verify and 96 B4 tests; original stdout/stderr and source identities are retained.",
    "runtime_scope": "Prior 1097 native passes remain bound to 710df84, not relabeled to 81da60b. No Rust or scientific checks are run by this packager.",
    "failure_scope": "Original hosted caller-proof failures, pre-checkout Fence failure and one explicitly rejected 403 retry are retained.",
    "format_scope": "Official just fmt exited 0; these root TOML/qa Python files had no formatter owner and their bytes stayed identical.",
    "authority": "No runtime or scientific admission is granted.",
    "snapshot_boundary": "Only the seven named input roots and packaging metadata. Future GitHub publication receipts are excluded.",
    "prior_sealed_archive": {"sha256": "9abc9567e66334a8f16df97b0e7187a286ec04d140a126bb8dcb9300b64cf64a", "modified": False, "copied_into_this_package": False},
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def json_bytes(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode("utf-8")

def relative(value):
    p = pathlib.PurePosixPath(value)
    if p.is_absolute() or not p.parts or ".." in p.parts or str(p) != value:
        raise ValueError("Unsafe or noncanonical relative path: " + value)
    return p

def no_symlink_path(path):
    rel = path.relative_to(ROOT)
    current = ROOT
    if ROOT.is_symlink():
        raise RuntimeError("Root must not be a symlink")
    for part in rel.parts:
        current = current / part
        if stat.S_ISLNK(current.lstat().st_mode):
            raise RuntimeError("Symlink rejected: " + str(current))

def signature(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)

def read_stable(path):
    no_symlink_path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as f:
        before = os.fstat(f.fileno())
        if not stat.S_ISREG(before.st_mode):
            raise RuntimeError("Nonregular file rejected: " + str(path))
        data = f.read()
        after = os.fstat(f.fileno())
    if signature(before) != signature(after) or signature(after) != signature(path.lstat()):
        raise RuntimeError("File changed while reading: " + str(path))
    if len(data) != before.st_size:
        raise RuntimeError("Incomplete read: " + str(path))
    return data, {"bytes": len(data), "sha256": sha(data), "original_mode": stat.S_IMODE(before.st_mode)}

def collect(allow_missing=False):
    contents, rows, missing = {}, [], []
    for root_name in SOURCE_ROOTS:
        relative(root_name)
        source = ROOT / root_name
        if not source.exists() and not source.is_symlink():
            if allow_missing:
                missing.append(root_name)
                continue
            raise RuntimeError("Missing source root: " + root_name)
        no_symlink_path(source)
        if not source.is_dir():
            raise RuntimeError("Expected source directory: " + root_name)
        for directory, dirs, names in os.walk(source, followlinks=False):
            here = pathlib.Path(directory)
            dirs.sort()
            for name in dirs:
                candidate = here / name
                if not stat.S_ISDIR(candidate.lstat().st_mode):
                    raise RuntimeError("Nonregular directory rejected: " + str(candidate))
            for name in sorted(names):
                path = here / name
                rel = str(path.relative_to(ROOT))
                if rel in contents:
                    raise RuntimeError("Duplicate input member: " + rel)
                data, record = read_stable(path)
                contents[rel] = data
                rows.append({"path": rel, **record})
    return contents, sorted(rows, key=lambda row: row["path"]), missing

def write_new(path, data):
    with path.open("xb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    if path.read_bytes() != data:
        raise RuntimeError("Written bytes differ: " + str(path))

def plan():
    return {
        "schema": "hepta.post-publication-caller-proof-pack-plan.v1",
        "source_roots": SOURCE_ROOTS,
        "scope": SCOPE,
        "required_pins": {k: {"bytes": v[0], "sha256": v[1]} for k, v in REQUIRED_PINS.items()},
        "nonregular_policy": "Reject all symlinks and nonregular files; never follow links.",
        "verification": "Read/stat/hash every input; repeat full inventory after archive creation; read back every ZIP member.",
        "pending_authorization": "Root ready_for_sealing signal and all writers complete.",
        "no_repo_or_target_writes": True,
        "no_behavioral_checks_or_retry_requests": True,
        "blob_threshold_bytes": 512000,
    }

def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    contents, rows, missing = collect(allow_missing=True)
    missing_pins = [p for p in REQUIRED_PINS if p not in contents]
    for name, expected in REQUIRED_PINS.items():
        if name in contents and (len(contents[name]), sha(contents[name])) != tuple(expected):
            raise RuntimeError("Required identity mismatch: " + name)
    result = {
        "schema": "hepta.post-publication-caller-proof-preparation.v1",
        "prepared_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "source_roots": SOURCE_ROOTS, "files": rows,
        "regular_file_count": len(rows), "bytes": sum(r["bytes"] for r in rows),
        "missing_roots": missing, "missing_required_pins": missing_pins,
        "sealed": False, "scope": SCOPE,
    }
    for name, data in [("PACK_PLAN.json", json_bytes(plan())), ("PREPARATION_INVENTORY.json", json_bytes(result))]:
        write_new(OUT / name, data)
    print(json.dumps({"prepared": True, "sealed": False, "regular_file_count": len(rows), "bytes": result["bytes"], "missing_roots": missing, "missing_required_pins": missing_pins, "script_sha256": sha(pathlib.Path(__file__).read_bytes())}))

def seal(snapshot, signal_name):
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", snapshot):
        raise ValueError("Invalid snapshot name")
    if pathlib.PurePosixPath(signal_name).name != signal_name:
        raise ValueError("Signal must be a filename inside the prep directory")
    signal_data, _ = read_stable(OUT / signal_name)
    signal = json.loads(signal_data)
    if signal.get("ready_for_sealing") is not True or signal.get("owner") != "root":
        raise RuntimeError("Explicit root completion signal required")
    if signal.get("all_writers_complete") is not True:
        raise RuntimeError("Writer completion is required")
    if signal.get("source_head") != CODE_HEAD or signal.get("source_tree") != CODE_TREE:
        raise RuntimeError("Unexpected final code identity")
    if signal.get("source_roots") != SOURCE_ROOTS:
        raise RuntimeError("Root signal must freeze exactly the seven reviewed input roots")
    script_data, _ = read_stable(pathlib.Path(__file__))
    if signal.get("script_sha256") != sha(script_data):
        raise RuntimeError("Script identity does not match the root-reviewed signal")
    contents, rows, missing = collect()
    for name, expected in REQUIRED_PINS.items():
        if name not in contents or (len(contents[name]), sha(contents[name])) != tuple(expected):
            raise RuntimeError("Required identity mismatch: " + name)
    for name in signal.get("required_files", []):
        relative(name)
        if name not in contents:
            raise RuntimeError("Required signal file missing: " + name)
    for name, pin in signal.get("additional_pins", {}).items():
        if name not in contents or len(contents[name]) != pin["bytes"] or sha(contents[name]) != pin["sha256"]:
            raise RuntimeError("Additional identity mismatch: " + name)
    code = json.loads(contents["joint-publication/caller-proof-followup/CODE_READY.json"])
    if (code["code_head"], code["code_tree"], code["base_head"], code["tested_patch_sha256"]) != (CODE_HEAD, CODE_TREE, BASE_HEAD, PATCH_SHA):
        raise RuntimeError("Code-ready identity mismatch")
    package_plan, _ = read_stable(OUT / "PACK_PLAN.json")
    if json.loads(package_plan) != plan():
        raise RuntimeError("Packaging plan changed")
    members = {"evidence/" + name: data for name, data in contents.items()}
    metadata = {"metadata/COMPLETION_SIGNAL.json": signal_data, "metadata/PACK_PLAN.json": package_plan, "metadata/pack_caller_proof_followup.py": script_data}
    members.update(metadata)
    manifest = {
        "schema": "hepta.post-publication-caller-proof-manifest.v1",
        "sealed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "source_roots": SOURCE_ROOTS, "scope": SCOPE, "files": rows,
        "payload_file_count": len(rows), "payload_bytes": sum(r["bytes"] for r in rows),
        "metadata_files": [{"path": n, "bytes": len(d), "sha256": sha(d)} for n, d in sorted(metadata.items())],
        "excluded_files": [], "missing_roots": missing,
    }
    manifest_data = json_bytes(manifest)
    members["MANIFEST.json"] = manifest_data
    directory = OUT / "snapshots" / snapshot
    directory.mkdir(parents=True, exist_ok=False)
    write_new(directory / "MANIFEST.json", manifest_data)
    archive = directory / "post-publication-caller-proof-evidence.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 8, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with archive.open("rb") as f:
        os.fsync(f.fileno())
    after_contents, after_rows, after_missing = collect()
    if after_contents != contents or after_rows != rows or after_missing != missing:
        raise RuntimeError("Frozen source inventory changed while packaging")
    if read_stable(OUT / signal_name)[0] != signal_data or read_stable(pathlib.Path(__file__))[0] != script_data:
        raise RuntimeError("Signal or packager changed while packaging")
    with zipfile.ZipFile(archive) as z:
        if sorted(z.namelist()) != sorted(members) or len(z.infolist()) != len(members):
            raise RuntimeError("Archive member mismatch")
        for name, expected in members.items():
            if z.read(name) != expected:
                raise RuntimeError("Archive readback mismatch: " + name)
    archive_data, archive_record = read_stable(archive)
    result = {
        "schema": "hepta.post-publication-caller-proof-archive-result.v1",
        "archive": {"path": str(archive), **archive_record},
        "manifest": {"path": str(directory / "MANIFEST.json"), "bytes": len(manifest_data), "sha256": sha(manifest_data)},
        "payload_file_count": len(rows), "member_count": len(members),
        "all_members_readback_verified": True, "all_input_bytes_rechecked": True,
        "blob_size_limit": 512000, "requires_exact_allowlist_pin": len(archive_data) > 512000,
        "scope": SCOPE, "repo_writes": 0, "target_writes": 0, "checks_executed_by_packager": 0,
    }
    result_data = json_bytes(result)
    write_new(directory / "ARCHIVE_RESULT.json", result_data)
    print(json.dumps({"result": result, "result_file": {"path": str(directory / "ARCHIVE_RESULT.json"), "bytes": len(result_data), "sha256": sha(result_data)}}))

def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("prepare")
    sealed = sub.add_parser("seal")
    sealed.add_argument("--snapshot", required=True)
    sealed.add_argument("--signal", required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare()
    else:
        seal(args.snapshot, args.signal)

if __name__ == "__main__":
    main()
