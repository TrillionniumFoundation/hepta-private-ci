#!/usr/bin/env python3
"""Prepare source-bound raw evidence; seal only with an explicit root signal."""

import argparse
import collections
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile
import time

ROOT = Path("/home/qian-qi/work/cell-s0s5-20261108-1628")
PREP = ROOT / "joint-delivery-prep"
REPOSITORY = ROOT / "joint-source"
DENIED_COMPONENTS = {".git", "target", "cargo-target", "joint-cargo-target",
                     "matrix-target", "ci-target", "__pycache__"}
DENIED_ROOTS = {"joint-source", "source", "matrix-source", "ci-source", "s4-source",
                "remote-ci-f491"}
COMPILED_SUFFIXES = {".rmeta", ".rlib", ".o", ".obj", ".a", ".so", ".dylib",
                     ".dll", ".exe", ".pdb", ".pyc"}
EXECUTABLE_MAGIC = (b"\x7fELF", b"MZ", b"\xcf\xfa\xed\xfe",
                    b"\xce\xfa\xed\xfe", b"\xfe\xed\xfa\xcf",
                    b"\xfe\xed\xfa\xce", b"\xca\xfe\xba\xbe")

def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def signature(value):
    return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns)

def safe_source(relative):
    parts = PurePosixPath(relative).parts
    if not parts or PurePosixPath(relative).is_absolute() or any(
        part in {".", ".."} for part in parts
    ):
        raise ValueError("invalid relative source path: " + relative)
    if parts[0] in DENIED_ROOTS or any(p in DENIED_COMPONENTS for p in parts):
        raise ValueError("source tree or target traversal is outside scope: " + relative)
    if parts[0] == "joint-delivery-prep" and (
        len(parts) < 2 or parts[1] not in {"agent-receipts", "delivery-documents"}
    ):
        raise ValueError("recursive preparation input is forbidden: " + relative)
    current = ROOT
    for part in parts[:-1]:
        current = current / part
        if current.is_symlink():
            raise ValueError("symlink ancestor rejected: " + str(current))
    return ROOT.joinpath(*parts)

def enumerate_sources(names):
    entries = {}
    missing = []
    for name in sorted(set(names)):
        root = safe_source(name)
        if not root.exists() and not root.is_symlink():
            missing.append(name)
            continue
        def walk(path):
            relative = path.relative_to(ROOT).as_posix()
            item = path.lstat()
            if stat.S_ISLNK(item.st_mode):
                entries[relative] = {"kind": "symlink", "target": os.readlink(path)}
            elif stat.S_ISDIR(item.st_mode):
                if path.name in DENIED_COMPONENTS:
                    entries[relative] = {"kind": "excluded_directory",
                                         "reason": "target_or_generated_cache"}
                    return
                for child in sorted(path.iterdir()):
                    walk(child)
            elif stat.S_ISREG(item.st_mode):
                entries[relative] = {"kind": "regular", "signature": signature(item),
                                     "bytes": item.st_size, "mtime_ns": item.st_mtime_ns,
                                     "mode": stat.S_IMODE(item.st_mode)}
            else:
                entries[relative] = {"kind": "special", "mode": item.st_mode}
        walk(root)
    return entries, missing

def exclusion(relative, prefix, pins):
    if relative in pins:
        return None
    name = PurePosixPath(relative).name
    if name.endswith(".lock") and name not in {"Cargo.lock", "MODULE.bazel.lock"}:
        return "temporary_lock"
    if name in {"LOCK", "lock"} or name.endswith(".lck"):
        return "temporary_lock"
    if PurePosixPath(relative).suffix.lower() in COMPILED_SUFFIXES:
        return "rebuildable_compiler_output_or_executable"
    if any(prefix.startswith(magic) for magic in EXECUTABLE_MAGIC):
        return "rebuildable_executable_magic"
    return None

def capture(relative, before, snapshot, pins):
    source = safe_source(relative)
    fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        with os.fdopen(fd, "rb", closefd=False) as stream:
            opened = os.fstat(fd)
            if not stat.S_ISREG(opened.st_mode) or signature(opened) != tuple(before["signature"]):
                raise RuntimeError("source changed before read: " + relative)
            prefix = stream.read(16)
            stream.seek(0)
            reason = exclusion(relative, prefix, pins)
            output = None
            destination = snapshot / "payload" / relative
            if reason is None:
                destination.parent.mkdir(parents=True, exist_ok=True)
                output = destination.open("xb")
            hashed = hashlib.sha256()
            count = 0
            try:
                while True:
                    block = stream.read(1024 * 1024)
                    if not block:
                        break
                    hashed.update(block)
                    count += len(block)
                    if output is not None:
                        output.write(block)
            finally:
                if output is not None:
                    output.close()
            if signature(os.fstat(fd)) != signature(opened) or count != opened.st_size:
                raise RuntimeError("source changed during read: " + relative)
            if signature(source.lstat()) != signature(opened):
                raise RuntimeError("source path changed during read: " + relative)
    finally:
        os.close(fd)
    sha = hashed.hexdigest()
    if relative in pins:
        expected = pins[relative]
        if sha != expected["sha256"] or count != expected["bytes"]:
            raise RuntimeError("forensic original pin mismatch: " + relative)
    return {
        "source_relative_path": relative, "source_absolute_path": str(source),
        "bytes": count, "sha256": sha, "source_mtime_ns": before["mtime_ns"],
        "source_mode": before["mode"], "included": reason is None,
        "payload_path": ("payload/" + relative) if reason is None else None,
        "exclusion_reason": reason,
        "forensic_exact_exception": relative in pins,
    }

def git_identity(head, expected_tree):
    if not re.fullmatch(r"[0-9a-f]{40}", head):
        raise ValueError("final source head must be a full commit SHA")
    tree = subprocess.check_output(
        ["git", "rev-parse", head + "^{tree}"], cwd=REPOSITORY, text=True
    ).strip()
    if tree != expected_tree:
        raise RuntimeError("completion signal tree does not match the exact commit")
    return {"head": head, "tree": tree}

def create_archive(snapshot, manifest):
    archive = snapshot / "joint-final-native-evidence.tar.gz"
    files = sorted(p for p in snapshot.rglob("*") if p.is_file())
    expected = {}
    with archive.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw,
                           compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w",
                              format=tarfile.PAX_FORMAT) as tar:
                for path in files:
                    if path.is_symlink():
                        raise RuntimeError("unexpected staged symlink")
                    name = path.relative_to(snapshot).as_posix()
                    data = path.read_bytes()
                    expected[name] = {"bytes": len(data), "sha256": digest(data)}
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    import io
                    tar.addfile(info, io.BytesIO(data))
    seen = set()
    with tarfile.open(archive, "r:gz") as tar:
        for member in tar:
            if not member.isfile() or member.name not in expected:
                raise RuntimeError("unexpected archive member")
            data = tar.extractfile(member).read()
            if len(data) != expected[member.name]["bytes"] or digest(data) != expected[member.name]["sha256"]:
                raise RuntimeError("archive member readback mismatch")
            if member.name in seen:
                raise RuntimeError("duplicate archive member")
            seen.add(member.name)
    if seen != set(expected):
        raise RuntimeError("archive member set mismatch")
    result = {
        "schema": "hepta.joint-delivery-archive-result.v1",
        "status": "SEALED_ARTIFACT_NOT_A_SCIENTIFIC_QUALIFICATION",
        "path": str(archive), "bytes": archive.stat().st_size,
        "sha256": digest(archive.read_bytes()), "regular_members": len(expected),
        "all_member_bytes_verified": True,
        "manifest_sha256": digest((snapshot / "MANIFEST.json").read_bytes()),
        "source_identity": manifest["source_identity"],
    }
    (snapshot / "ARCHIVE_RESULT.json").write_bytes(encoded(result))
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["prepare", "seal"])
    parser.add_argument("--snapshot", required=True)
    parser.add_argument("--signal")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,63}", args.snapshot):
        raise ValueError("invalid snapshot name")
    scope = json.loads((PREP / "SCOPE.json").read_text())
    signal = None
    names = list(scope["source_roots"])
    identity = {"owner_reported_head": scope["owner_reported_active_head"],
                "owner_reported_tree": scope["owner_reported_active_tree"],
                "verified_final_identity": False}
    required = []
    if args.mode == "seal":
        if not args.signal or Path(args.signal).name != args.signal:
            raise ValueError("seal needs a completion signal filename within preparation root")
        signal = json.loads((PREP / args.signal).read_text())
        if signal.get("ready_for_sealing") is not True or signal.get("owner") != "root":
            raise ValueError("no explicit root completion signal")
        final_receipts = signal.get("final_fix_fmt_receipts", [])
        if not final_receipts or not signal.get("terminal_receipts"):
            raise ValueError("final fix/fmt and terminal job receipts are required")
        required = scope["required_at_seal"] + signal.get("required_files", []) + final_receipts
        names += scope["pending_roots"] + signal.get("source_roots", []) + required
        identity = git_identity(signal["source_head"], signal["source_tree"])
        identity["verified_final_identity"] = True
    before, missing = enumerate_sources(names)
    if args.mode == "seal" and missing:
        raise RuntimeError("missing sealed inputs: " + repr(missing))
    for relative in required:
        if before.get(relative, {}).get("kind") != "regular":
            raise RuntimeError("required receipt is not a regular file: " + relative)
    snapshot = PREP / "snapshots" / args.snapshot
    snapshot.mkdir(parents=True, exist_ok=False)
    pins = {x["path"]: x for x in scope["forensic_exact_assets"]}
    records = []
    excluded = []
    try:
        for relative, entry in sorted(before.items()):
            if entry["kind"] == "regular":
                records.append(capture(relative, entry, snapshot, pins))
            else:
                excluded.append({"source_relative_path": relative, **entry})
        after, after_missing = enumerate_sources(names)
        if before != after or missing != after_missing:
            raise RuntimeError("selected source set changed during preparation")
        if any(pin not in {x["source_relative_path"] for x in records if x["included"]}
               for pin in pins):
            raise RuntimeError("mandatory forensic originals missing from payload")
        duplicates = collections.defaultdict(list)
        for row in records:
            duplicates[row["sha256"]].append(row["source_relative_path"])
        packaging_inputs = {}
        for name in ["SCOPE.json", "PLAN.json", "pack_joint_delivery.py"]:
            data = (PREP / name).read_bytes()
            (snapshot / name).write_bytes(data)
            packaging_inputs[name] = {"bytes": len(data), "sha256": digest(data)}
        if signal is not None:
            data = (PREP / args.signal).read_bytes()
            (snapshot / "COMPLETION_SIGNAL.json").write_bytes(data)
            packaging_inputs["COMPLETION_SIGNAL.json"] = {"bytes": len(data), "sha256": digest(data)}
        manifest = {
            "schema": "hepta.joint-delivery-manifest.v1",
            "status": "PREPARED_NOT_SEALED" if args.mode == "prepare" else "READY_FOR_ARCHIVE",
            "created_unix_ns": time.time_ns(), "source_identity": identity,
            "source_roots": sorted(set(names)), "missing_roots": missing,
            "pending_roots_not_snapshotted_in_prepare": scope["pending_roots"] if args.mode == "prepare" else [],
            "required_receipts": sorted(set(required)), "files": records,
            "excluded_nonregular_entries": excluded,
            "external_references": scope["external_references"],
            "forensic_exact_assets": scope["forensic_exact_assets"],
            "packaging_inputs": packaging_inputs,
            "identical_content_groups": [
                {"sha256": key, "source_paths": value}
                for key, value in sorted(duplicates.items()) if len(value) > 1
            ],
            "cost_claim_boundary": scope["cost_claim_boundary"],
            "source_files_or_tests_modified": False, "tests_executed_by_packager": False,
            "original_failure_receipts_preserved_verbatim": True,
        }
        (snapshot / "MANIFEST.json").write_bytes(encoded(manifest))
        result = {
            "snapshot": str(snapshot), "status": manifest["status"],
            "regular_source_files": len(records),
            "included_files": sum(x["included"] for x in records),
            "included_bytes": sum(x["bytes"] for x in records if x["included"]),
            "excluded_regular_files": sum(not x["included"] for x in records),
            "nonregular_entries": len(excluded), "missing_roots": missing,
            "forensic_originals_included": len(pins),
            "manifest_sha256": digest((snapshot / "MANIFEST.json").read_bytes()),
            "archive_created": False,
        }
        if args.mode == "seal":
            result["archive"] = create_archive(snapshot, manifest)
            result["archive_created"] = True
        (snapshot / "PREPARATION_RESULT.json").write_bytes(encoded(result))
        print(json.dumps(result))
    except Exception as error:
        (snapshot / "PREPARATION_FAILURE.json").write_bytes(encoded({
            "status": "FAILED_NOT_SEALED", "error_type": type(error).__name__,
            "error": str(error), "captured_file_count": len(records),
            "source_files_modified": False, "archive_validity_claim": False,
        }))
        raise

if __name__ == "__main__":
    main()
