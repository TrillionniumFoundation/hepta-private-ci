# S3–S5 科学结论与 ORG1 工程回归范围校对

这是只读源码与既有原件校对，没有启动测试、训练、拟合、优化器、参考实验或 E 数据访问。共同源码审阅锚点为 `9fc756728081df6311b770834d76aa8eea8e1708`；ORG1 增量锚点为 `093b7a703eb4e31fcea3d8ab5d3f4749664504c5`；旧 S81 状态从 `60af6862c23d94a45e30c39e3de91ade8b058ae6` 精确 Git blob 读取。后续共同树的工程复验必须另绑其实际 head/tree，不能重标下面的历史执行。

## 可用于共同 README 的阶段结论

| 阶段 | 已实现与已真实执行 | 仍未达到阶段出口的具体原因 |
| --- | --- | --- |
| S3 学习内核 | 已有可微 HCSN 数值机制原件；本轮补齐可配置官方基线 adapter、真实标量容量/反向连通审核与 ABC 训练、D 开发验证入口。已封存的开发运行实际完成 5 个 fresh baseline fits，单 seed 101，每个 16 diagnostic + 12 main updates，共 140 updates；另有 28 项隔离的共同研究兼容检查。 | 新 formal fits=0，E 未解释。12 main updates 未完成首 epoch；只有 attention 通过短时记忆阈值，不能作架构排名或充分训练声明。PLIF 9770 trainable scalars 中 6236 有非零梯度矩，3534 零矩参数不能因发生 decay 就算梯度使用。formal protocol 仍欠完整六族 episode 集成、合格 HCSN 容量参照、全上下文数值域、消融与维护动态、收敛/资源原件；独立 formal 总预算尚未分配。没有相对强时序/梯度基线的合格收益或成本优势，HOLD。 |
| S4 组织可塑性 | D validator 已补齐真实 before-state 的配对绑定。ORG1 的 split/merge/rewire reference 与 finite-panel reviewer 可纳入共同源码；原封存运行实际完成 99 paired tasks / 198 arm-task executions，三操作每臂均 33/33 正确，保留真实迁移、后继使用与指定故障恢复原件。 | 这些是 Python key/value reference，不是 matched native D 组织收益实验。fixed/dynamic 使用相同字典索引调度，但尚未证明调度器强度；二者质量相同，rewire 消息 36→69，未观察质量增益。resident-byte integrals、能源、provider、完整运行成本未知，mean_net_gain=null；缺 native owner/独立 evaluator/完整后继消费与代表性任务及独立 fits，D/ORG1 继续 HOLD/NoUpdate。休眠/退役不受支持；key/value split 不能算训练出分化技能。 |
| S5 可继承改进器 | 已实现四臂 solver×improver component transfer、全部尝试分母、selection/heldout/retention 分离及历史发现成本分账。原 NumPy synthetic pilot 实际有 3 个发现 seed、12 runs、72 attempts，另有 24 个历史发现候选；较早 72-attempt development run 独立保留。 | 12 runs 的数值 pilot 门全部满足，但 qualified=0、unresolved=12，所有 cost_per_effective_improvement=null。后代 improver 在 S0 的平均 gain 为 8.8542 pp，对照 14.7135 pp；retention loss 也更小（2.6042 vs 9.6354 pp），是适应/保留权衡，未证明效率优越。仍无真实任务/独立原生 evaluator、完整历史 R&D 与外层成本、native adoption/下一任务消费恢复、独立确认，因此不能称真实可继承改进效率或 RSI 成立。 |

### S4 相关 B 证据必须另列

#5345 的 B matched-state training 真实完成 56/56 作业与 960 计划部署记录，但只有 2 个训练 seed。开发条件相对预先锁定最强 planning comparator 的 8 个部署效用点差均为负；保留验证只有 2 个 cases / 2 source groups，160/160 记录评分为零。零差异不证明保留、不退化或泛化。它不是 D 组织实验；不要把 B 的负效用或两个 retention cases 改写为 ORG1/D 的样本量与结论。共同起点是模式预训练之前的相同构造器，不是同一已训练 checkpoint 的状态消融。

### 新 formal=0 与旧 S81 UNKNOWN 不能合并

新 `proposals/localization-v2/formal_protocol.json` 的 `formal_fits_started:0` 仅约束这项新 formal study。旧 S81 CPU V1 formal owner 已从 160 登记 fits 中保留 20、提交一次；原提交是 `UNKNOWN / MAY_HAVE_BEEN_SENT`，没有获验证 remote identity 或 completion capsule。140 locally unstarted、0 verified completions、0 reservation releases/replays，并不等于实际远端 fits 或 optimizer updates=0；后者仍 Unknown。后来只读 GET 的 `remote_effect_unknown=false` 不能解消原 submit。旧冻结原件不在共同研究导入范围内，但历史状态与资源责任保留。

## 精确文件与发布锚点

- S3：[PR #5377](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5377) 至 [#5382](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5382)；`proposals/localization-v2/formal_protocol.json`、`qualification/hcsn-localization-trainer-20261108/{README.md,MANIFEST.json,NATIVE_AUDIT_SUMMARY.json}`；数值原件 `qualification/hcsn_differentiable/evidence/math-closure-20261108/STATUS.json`。训练 raw ZIP SHA256 `27d4f684ba9df1b9dec5c518377c50f80239d2a3f4998045f88939593fa01bcc`，1843158 bytes。独立 PLIF endpoint 诊断 [#5389](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5389) 不增加训练。
- 旧 S81：[60af 精确 FORMAL_HALT 文档](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/60af6862c23d94a45e30c39e3de91ade8b058ae6/qualification/hcsn_regenerative/studies/s81-cpu-v1-20261107/FORMAL_HALT_20261108.md)，同目录 `FORMAL_HALT_STATUS_20261108.json`；数值冻结研究原锚点 #5327。
- B/D：[PR #5345](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5345)，`qualification/cell-causal-abcde-20261108/{README.md,B_CONTRASTS.csv,B_LOCKED_COMPARATOR.csv,D_CAPABILITY_AUDIT.json}`；`scripts/ndu_real_runtime/causal_topology.py`。
- ORG1：[PR #5375](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5375) @093b7a7，`qualification/cell-organization-20261108/{README.md,RESULTS.json,ARTIFACTS.json,INTEGRATION.json}`。历史 99 pairs 的 archive/source identity 与后来 41-method integration run 分开保留。
- S5：[PR #5348](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5348) @c600204c6095b438746e7efd8a098bc38e1d8613，`qualification/evolve-1-20261108/{README.md,CURRENT.json,campaign-final.json,PROTOCOL.md}`；`scripts/ndu_real_runtime/{evolve1.py,evolve1_reference.py,evolve1_pilot.py,causal_improver.py}`。

## ORG1 41-method 共同工程回归的精确范围

在 repo root 执行以下命令才是单独的 41 项工程回归：

```text
python3 -B -m unittest scripts.ndu_real_runtime.test_organization_policy scripts.ndu_real_runtime.test_causal_topology scripts.ndu_real_runtime.test_causal_protocol -v
```

22 ORG methods 只生成/篡改临时 JSON fixtures 并调用 reviewer；7 topology methods 在 `tempfile.TemporaryDirectory()` 中生成图/状态/trace/cost/recovery/owner fixtures；12 protocol methods用内存 8 rows（2 fit labels×2 cases×2 arms），其中分析 draws=100。fit labels 不是实际拟合。测试入口没有模型训练、reference runner 或真实 ABCDE 文件路径。三个 `organization_reference --operation split|merge|rewire` 命令是 workflow 后续另一步；本轮不执行该步骤，也不增加 99-pair 运行次数。

精确 a55→093 diff 全部为新增：1 workflow、11 qualification 记录/archives、5 implementation Python、1 tests。无既有 Rust/Cargo/权限源码修改。新增 workflow 的 permissions 为 contents:read。reviewer 返回处 `organization_policy.py:469–478` 无条件保持 scientific_acceptance=HOLD、decision=NoUpdate、benefit/adoption/runtime_authority/full_physical_cost_known=false。共同合并/复验结果由 root 的实际新 head 与回执决定，本审查不预先报绿。

## native RESULT 的训练计数建议

建议字段为 `new_registered_scientific_experiment_runs: 0`，配：

```text
Scope: this joint integration/correctness verification launched no new registered scientific experiment or formal confirmation study. Internal unit-test learning/optimizer operations are outside this counter and were not globally instrumented.
```

中文：**本轮共同工程验证未新增登记的科学实验或正式确认训练；这不是对全部 Rust 单元测试内部 optimizer 操作次数的全局计量。** 保留旧 `new_training_runs:0` 字段时必须加同样的 scope。该字段也不能抹去此前已实际完成的 5 个开发 fits / 140 updates，或把旧 S81 的远端 Unknown 改为零。
