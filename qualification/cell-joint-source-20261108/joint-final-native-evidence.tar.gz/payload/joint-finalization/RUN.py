from pathlib import Path
import subprocess,json,hashlib,time,os,stat,tomllib
r=Path("/home/qian-qi/work/cell-s0s5-20261108-1628");s=r/"joint-source";o=r/"joint-finalization";o.mkdir(exist_ok=True)
def g(*a):return subprocess.check_output(["git",*a],cwd=s,text=True).strip()
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
 return h.hexdigest()
head="710df84a6b10afa005976c24a1108fb2a57810d3";base="c37ebf8de8efc660229e66e4030d589be46bc194"
assert g("rev-parse","HEAD")==head and not g("status","--porcelain")
v5=json.loads((r/"joint-circuit-validation-v5/RESULT.json").read_text())
assert v5["head"]==head and v5["complete"] and len(v5["commands"])==6
assert all(x["exit_code"]==0 and x["tests_run"]>0 and x["input_hashes_stable"] and not x["source_status"] for x in v5["commands"])
tracked=subprocess.check_output(["git","ls-files","-z"],cwd=s).decode().split("\0");tracked=[p for p in tracked if p]
packages=["codex-hepta-agentd","codex-hepta-automation","codex-hepta-evidence","codex-hepta-infer-worker-host","codex-hepta-learning-ledger","codex-hepta-memory-retrieval","codex-hepta-ndu","codex-hepta-neuron","codex-hepta-matrix-sdk","codex-hepta-operator-acceptance"]
manifests={}
for p in tracked:
 if p.startswith("codex-rs/") and p.endswith("/Cargo.toml") and len(p.split("/"))==3:
  data=tomllib.loads((s/p).read_text());name=data.get("package",{}).get("name")
  if name in packages:
   assert name not in manifests;manifests[name]=p
assert set(manifests)==set(packages)
fmt_candidates=subprocess.check_output(["git","diff","--name-only","-z",base,"HEAD"],cwd=s).decode().split("\0");fmt_candidates=[p for p in fmt_candidates if p]
prefixes=[str(Path(p).parent)+"/" for p in manifests.values()]
allowed={p for p in tracked if (p.endswith(".rs") and any(p.startswith(x) for x in prefixes)) or p in fmt_candidates}
def snapshot():
 result={}
 for p in tracked:
  q=s/p;st=q.lstat()
  if stat.S_ISREG(st.st_mode):result[p]={"kind":"regular","bytes":st.st_size,"mode":stat.S_IMODE(st.st_mode),"sha256":sha(q)}
  elif stat.S_ISLNK(st.st_mode):
   v=os.readlink(q);result[p]={"kind":"symlink","target":v,"mode":stat.S_IMODE(st.st_mode)}
  else:raise RuntimeError("unsupported tracked file "+p)
 return result
before=snapshot();(o/"TRACKED_BEFORE.json").write_text(json.dumps(before,indent=2)+"\n")
(o/"FORMAT_CANDIDATES.json").write_text(json.dumps(fmt_candidates,indent=2)+"\n")
old=json.loads((r/"joint-native-bound-v3/RESULT.json").read_text());env=dict(os.environ,**old["environment_explicit"]);assert env["CARGO_TARGET_DIR"]==str(r/"joint-cargo-target") and not (r/"cargo-target").exists()
fix=["just","fix","--locked"]
for p in packages:fix+=["-p",p]
commands=[("scoped-just-fix",fix),("scoped-just-fmt",["just","fmt","--base",base])]
record={"head_before":head,"tree_before":g("rev-parse","HEAD^{tree}"),"tests_completed_before_finalization":1097,"test_receipt_sha256":sha(r/"joint-circuit-validation-v5/RESULT.json"),"all_tests_precede_this_fix_fmt":True,"no_tests_will_be_run_after_final_fix_fmt":True,"package_manifests":manifests,"format_base":base,"format_scope":"Only the diff from c37 and subsequent working-tree lint edits; earlier staged formatting proofs retain their own source identities. No whole-tree or vendor formatter run.","tracked_files":len(tracked),"protected_files":len(set(tracked)-allowed),"environment_explicit":old["environment_explicit"],"commands":[],"complete":False}
(o/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n");print(json.dumps({"event":"frozen","head":head,"tracked":len(tracked),"protected":record["protected_files"],"package_count":len(packages),"format_candidate_count":len(fmt_candidates)}),flush=True)
for name,argv in commands:
 print(json.dumps({"event":"start","name":name,"argv":argv}),flush=True);t=time.time()
 with (o/(name+".stdout")).open("wb") as so,(o/(name+".stderr")).open("wb") as se:p=subprocess.run(argv,cwd=s/"codex-rs",env=env,stdout=so,stderr=se)
 row={"name":name,"argv":argv,"exit_code":p.returncode,"wall_seconds":time.time()-t}
 for side in ["stdout","stderr"]:
  q=o/(name+"."+side);row[side+"_bytes"]=q.stat().st_size;row[side+"_sha256"]=sha(q)
 row["source_status"]=g("status","--porcelain");record["commands"].append(row);(o/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n");print(json.dumps(row),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
after=snapshot();(o/"TRACKED_AFTER.json").write_text(json.dumps(after,indent=2)+"\n")
changed=[p for p in tracked if before[p]!=after[p]];protected_changes=[p for p in changed if p not in allowed]
for name,args in [("final.patch",["diff","--binary","HEAD"]),("final.numstat",["diff","--numstat","HEAD"]),("final.status",["status","--porcelain"])]:
 (o/name).write_bytes(subprocess.check_output(["git",*args],cwd=s))
check=subprocess.run(["git","diff","--check"],cwd=s,capture_output=True);(o/"diff-check.stdout").write_bytes(check.stdout);(o/"diff-check.stderr").write_bytes(check.stderr)
record.update({"complete":True,"head_after":g("rev-parse","HEAD"),"changed_paths":changed,"protected_changes":protected_changes,"protected_inputs_stable":not protected_changes,"diff_check_exit":check.returncode,"source_status":g("status","--porcelain"),"patch_sha256":sha(o/"final.patch"),"patch_bytes":(o/"final.patch").stat().st_size})
(o/"RESULT.json").write_text(json.dumps(record,indent=2)+"\n");print(json.dumps({k:record[k] for k in ["complete","head_after","changed_paths","protected_changes","protected_inputs_stable","diff_check_exit","patch_sha256","patch_bytes"]}),flush=True)
assert not protected_changes and check.returncode==0
