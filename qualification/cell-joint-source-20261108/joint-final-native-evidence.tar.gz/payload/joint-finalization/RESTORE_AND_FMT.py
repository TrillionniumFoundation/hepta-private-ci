from pathlib import Path
import subprocess,json,hashlib,time,os,stat
r=Path("/home/qian-qi/work/cell-s0s5-20261108-1628");s=r/"joint-source";o=r/"joint-finalization"
def g(*a):return subprocess.check_output(["git",*a],cwd=s,text=True).strip()
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
 return h.hexdigest()
head="710df84a6b10afa005976c24a1108fb2a57810d3";base="c37ebf8de8efc660229e66e4030d589be46bc194";p="codex-rs/hepta-operator-acceptance/src/durable.rs"
prior=json.loads((o/"RESULT.json").read_text());assert prior["complete"] and all(x["exit_code"]==0 for x in prior["commands"]);assert prior["changed_paths"]==[p] and prior["protected_inputs_stable"]
review=r/"joint-boundary-review/FINAL_FIX_PIN_REVIEW.json";assert review.is_file()
assert g("rev-parse","HEAD")==head
original=subprocess.check_output(["git","show",head+":"+p],cwd=s);current=(s/p).read_bytes()
old=b"    let _ = parent_pin;";new=b"    parent_pin;"
assert original.count(old)==2 and current==original.replace(old,new)
(s/p).write_bytes(original)
env=dict(os.environ,**prior["environment_explicit"]);argv=["just","fmt","--base",base];t=time.time()
with (o/"restored-just-fmt.stdout").open("wb") as so,(o/"restored-just-fmt.stderr").open("wb") as se:result=subprocess.run(argv,cwd=s/"codex-rs",env=env,stdout=so,stderr=se)
before=json.loads((o/"TRACKED_BEFORE.json").read_text());mismatches=[]
for name,olddata in before.items():
 q=s/name;st=q.lstat()
 if stat.S_ISREG(st.st_mode):now={"kind":"regular","bytes":st.st_size,"mode":stat.S_IMODE(st.st_mode),"sha256":sha(q)}
 elif stat.S_ISLNK(st.st_mode):now={"kind":"symlink","target":os.readlink(q),"mode":stat.S_IMODE(st.st_mode)}
 else:now={"kind":"unsupported"}
 if now!=olddata:mismatches.append(name)
status=g("status","--porcelain");record={"head":g("rev-parse","HEAD"),"tree":g("rev-parse","HEAD^{tree}"),"source_status":status,"restored_path":p,"restored_file_sha256":sha(s/p),"rejected_autofix_patch_sha256":sha(o/"final.patch"),"review_sha256":sha(review),"decision":"Discard two no-op non-Windows unit-value autofixes that introduce path_statements warnings; restore the exact tested source bytes. This is not a Windows handle-release or safety defect.","fmt_argv":argv,"fmt_exit_code":result.returncode,"fmt_wall_seconds":time.time()-t,"tracked_files_compared":len(before),"tracked_mismatches":mismatches,"all_tracked_files_equal_to_tested_source":not mismatches and not status,"prior_fix_and_fmt_exit_codes":[x["exit_code"] for x in prior["commands"]],"tests_after_final_fix_fmt":0}
for side in ["stdout","stderr"]:
 q=o/("restored-just-fmt."+side);record["fmt_"+side+"_bytes"]=q.stat().st_size;record["fmt_"+side+"_sha256"]=sha(q)
(o/"FINAL_SOURCE_IDENTITY.json").write_text(json.dumps(record,indent=2)+"\n");print(json.dumps(record),flush=True)
assert result.returncode==0 and not mismatches and not status and record["head"]==head
