"""Run selected imported research contracts without training or optimizer use."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
import time
import unittest
from unittest.mock import patch


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("pure", "torch"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "CAPSULE_MANIFEST.json").read_text())
    args.output.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    source = {row["path"]: row["sha256"] for row in manifest["source_files"]}

    def hashes():
        return {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in source}

    assert hashes() == source, "frozen source identity mismatch"
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(root / "proposals/localization-v2"))
    prefix = "qualification.hcsn_differentiable.tests."
    selected = [
        prefix + "test_benchmark_admission",
        "test_episodes.EpisodeTests.test_sealed_subject_is_excluded_before_label_coordinate_clock_parsing",
    ]
    runtime = {"python": sys.version, "executable": sys.executable, "platform": platform.platform()}
    optimizer_attempts = 0
    if args.mode == "torch":
        import torch

        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        runtime.update(torch=torch.__version__, cuda_build=torch.version.cuda)
        selected = [
            prefix + "test_encoder",
            prefix + "test_probability_intervals",
            prefix + "test_operator.OperatorNumericalTests.test_contract_and_episode_snapshot_reject_changes",
        ]
        selected += [prefix + "test_network.NetworkTests." + name for name in (
            "test_actual_dt_batched_mass_and_exactly_one_advance_per_layer_step",
            "test_chunk_continuation_preserves_full_layer_content_and_clocks",
            "test_missing_observation_advances_but_padding_preserves_state",
            "test_operator_grid_ownership_cannot_differ_at_equal_state_count",
        )]

    def reject_optimizer(*_args, **_kwargs):
        nonlocal optimizer_attempts
        optimizer_attempts += 1
        raise RuntimeError("optimizer construction is outside this compatibility check")

    class ReceiptResult(unittest.TextTestResult):
        def __init__(self, *values, **kwargs):
            super().__init__(*values, **kwargs)
            self.executed = []

        def startTest(self, test):
            self.executed.append(test.id())
            super().startTest(test)

    with (args.output / "tests.log").open("x") as stream:
        runner = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=ReceiptResult)
        suite = unittest.defaultTestLoader.loadTestsFromNames(selected)
        if args.mode == "torch":
            with patch.object(torch.optim.Optimizer, "__init__", reject_optimizer):
                result = runner.run(suite)
        else:
            result = runner.run(suite)
    after = hashes()
    record = {
        "schema": "cell-joint-research-compatibility-v1",
        "mode": args.mode,
        "source_head": manifest["source_head"],
        "source_tree": manifest["source_tree"],
        "evidence_scope": "selected frozen Python files only; not the full integrated tree",
        "selected_names": selected,
        "executed_tests": result.executed,
        "tests_run": result.testsRun,
        "failures": [[test.id(), error] for test, error in result.failures],
        "errors": [[test.id(), error] for test, error in result.errors],
        "skipped": [[test.id(), reason] for test, reason in result.skipped],
        "passed": result.wasSuccessful() and not result.skipped and after == source,
        "source_files_sha256": source,
        "source_unchanged": after == source,
        "runtime": runtime,
        "optimizer_construction_attempts": optimizer_attempts,
        "optimizer_steps": 0,
        "new_training_runs": 0,
        "real_dataset_access": False,
        "confirmation_access": False,
        "scientific_admission": "HOLD",
        "excluded": "Full qualification runner, capacity optimizer test, network Adam/checkpoint update tests, frontend preparation and training entry points were not run.",
        "wall_seconds": time.perf_counter() - started,
        "recorded_utc": datetime.now(timezone.utc).isoformat(),
    }
    (args.output / "RESULT.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({key: record[key] for key in (
        "mode", "source_head", "tests_run", "passed", "source_unchanged", "runtime",
        "optimizer_construction_attempts", "optimizer_steps", "new_training_runs", "wall_seconds",
    )}), flush=True)
    return 0 if record["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
