# Research identity review of the frozen joint candidate

Audited commit: `68d8c41eaf94c89604d34acc65f3bb04a2f3d7d3`.
Audited tree: `0ae35634197ea22d397d3b37202607a3d9f60ca2`.

This is a read-only comparison of exact Git objects. The changing joint working tree was not used as a frozen source. No test, trainer, optimizer, or confirmation-data operation was executed.

## Identity result

| Comparison | Result |
| --- | --- |
| Imported research files against the per-file import manifest from `60af6862c23d94a45e30c39e3de91ade8b058ae6` | 101 of 101 byte-identical |
| Python files within that import | 36 of 36 AST-identical |
| Files in the previously tested frozen capsule from `30385c7440e3137ca5951982fbb61fcdd7ab58b8` | 42 of 42 byte-identical |
| Python files in that frozen capsule | 30 of 30 AST-identical |

The 101 imported files include code, documentation, workflows, and retained evidence. They are not 101 Python modules. No source differences were found.

`AUDIT.json` records each expected source blob, current blob, both SHA-256 values, and Python AST comparison where applicable. AST comparison ignores source-location attributes and does not execute the modules.

## Prior 28-test evidence

The retained compatibility archive is bound by SHA-256 `ca5124ab6f82cc61962d0990223d642ba9ceeaf8f562963aa759fd60a29a50e7`. Its source capsule SHA-256 is `e6c5d32e97f98beae2e54a0163cb7420c71315cc0089f26154a5f5452cb72981`.

The prior execution comprised 13 pure Python tests on ROG and 15 selected Torch tests on desktop. The desktop used Torch `2.8.0+cu128` with CPU execution; this is not the pinned `+cpu` CI environment. The exact test identities and runtime receipts remain in the retained archive.

The matching files establish source identity for those selected prior tests. They do not establish that the entire joint tree, every imported module, or all research tests were executed at the joint commit.

## Research admission remains HOLD

The trainer manifest still declares `scientific_admission: HOLD`, `complete_equal_budget_scientific_comparison: false`, `formal_fits_started: 0`, and `confirmation_access: false`.

The formal protocol remains `specified_not_admitted_not_started`, with A/B/C for training, D for development, and E sealed. Its independent formal resource budget is still unallocated; the earlier interface allowance is not a formal-study budget.

The separate HCSN benchmark protocol remains `draft_blocked_missing_evidence_and_implementations`. Its numerical qualification is false and its per-arm wall, tuning, and parameter budgets are null.

Current exact source still skips E rows before interpreting labels, coordinates, and clocks, fits frontend statistics only from A/B/C, rejects confirmation-bearing prepared manifests, and emits a development receipt with `HOLD`. `GATE_EXCERPTS.json` preserves the relevant exact lines.

This review preserves the existing boundary: the selected compatibility tests and native development records do not establish complete equal-budget training, convergence, formal confirmation, scientific benefit, or production admission.
