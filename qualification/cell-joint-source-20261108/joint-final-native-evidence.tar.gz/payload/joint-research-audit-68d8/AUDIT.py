import pathlib,subprocess,json,hashlib,zipfile,ast,difflib
root=pathlib.Path("/home/qian-qi/work/cell-s0s5-20261108-1628");repo=root/"joint-source";out=root/"joint-research-audit-68d8"
head="68d8c41eaf94c89604d34acc65f3bb04a2f3d7d3"
def git(*a): return subprocess.check_output(["git","-C",str(repo),*a])
imports=json.loads(git("show",head+":qualification/joint-research-import-20261108/IMPORT.json"))
records=[];diffs={}
for f in imports["source_files"]:
 p=f["path"];current=git("show",head+":"+p);original=git("cat-file","blob",f["source_blob"])
 assert len(original)==f["bytes"] and hashlib.sha256(original).hexdigest()==f["sha256"]
 r={"path":p,"expected_source_blob":f["source_blob"],"current_blob":git("rev-parse",head+":"+p).decode().strip(),"source_sha256":f["sha256"],"joint_sha256":hashlib.sha256(current).hexdigest(),"bytes_equal":current==original}
 if p.endswith(".py"):
  old=ast.dump(ast.parse(original,filename=p),include_attributes=False)
  new=ast.dump(ast.parse(current,filename=p),include_attributes=False)
  r.update({"python_ast_equal":old==new,"python_ast_sha256":hashlib.sha256(new.encode()).hexdigest()})
 if current!=original:
  try: diffs[p]="".join(difflib.unified_diff(original.decode().splitlines(True),current.decode().splitlines(True),fromfile=imports["source_head"]+":"+p,tofile=head+":"+p))
  except UnicodeDecodeError: diffs[p]="Binary contents differ"
 records.append(r)
frozen=root/"joint-research-validation/frozen-source.zip"
snapshot=[]
with zipfile.ZipFile(frozen) as z:
 capsule=json.loads(z.read("CAPSULE_MANIFEST.json"))
 for f in capsule["source_files"]:
  p=f["path"];stored=z.read(p);assert len(stored)==f["bytes"] and hashlib.sha256(stored).hexdigest()==f["sha256"]
  current=git("show",head+":"+p)
  r={"path":p,"snapshot_sha256":f["sha256"],"joint_sha256":hashlib.sha256(current).hexdigest(),"bytes_equal":current==stored,"snapshot_blob":f["source_blob"],"joint_blob":git("rev-parse",head+":"+p).decode().strip()}
  if p.endswith(".py"):
   original=ast.dump(ast.parse(stored,filename=p),include_attributes=False);new=ast.dump(ast.parse(current,filename=p),include_attributes=False)
   r["python_ast_equal"]=original==new
  snapshot.append(r)
gate_paths=["qualification/hcsn-localization-trainer-20261108/MANIFEST.json","proposals/localization-v2/formal_protocol.json","qualification/hcsn_differentiable/research_protocol.json"]
gates={p:json.loads(git("show",head+":"+p)) for p in gate_paths}
source_excerpts={}
for p,patterns in [("proposals/localization-v2/episodes.py",["E","subject","validation","fit"]),("proposals/localization-v2/train_development.py",["HOLD","confirmation","admission","training_subject","fit("]),("proposals/localization-v2/PROTOCOL.md",["HOLD","confirmation","E","sealed"]),("proposals/localization-v2/TRAINER.md",["HOLD","confirmation","E","sealed"])]:
 lines=git("show",head+":"+p).decode().splitlines()
 selected=set()
 for i,line in enumerate(lines):
  if any(pattern in line for pattern in patterns):
   selected.update(range(max(0,i-1),min(len(lines),i+2)))
 source_excerpts[p]=[{"line":i+1,"text":lines[i]} for i in sorted(selected)]
validation=json.loads((root/"joint-research-validation/SUMMARY.json").read_text())
summary={"schema":"joint-research-identity-audit-v1","head":head,"tree":git("rev-parse",head+"^{tree}").decode().strip(),"import_source_head":imports["source_head"],"imported_files":len(records),"byte_identical_imported_files":sum(r["bytes_equal"] for r in records),"python_imported_files":sum("python_ast_equal" in r for r in records),"python_imported_ast_identical":sum(r.get("python_ast_equal",False) for r in records),"import_differences":diffs,"snapshot_head":capsule["source_head"],"snapshot_tree":capsule["source_tree"],"snapshot_files":len(snapshot),"byte_identical_snapshot_files":sum(r["bytes_equal"] for r in snapshot),"python_snapshot_files":sum("python_ast_equal" in r for r in snapshot),"python_snapshot_ast_identical":sum(r.get("python_ast_equal",False) for r in snapshot),"selected_prior_tests_run":validation["tests_run"],"prior_validation_archive_sha256":validation["archive_sha256"],"prior_scientific_admission":validation["scientific_admission"],"static_audit_only":True,"new_tests_or_training":0,"optimizer_steps":0,"confirmation_data_accessed":False}
record={"summary":summary,"imported_files":records,"snapshot_files":snapshot,"gate_documents":gates,"gate_source_excerpts":source_excerpts,"prior_validation":validation}
(out/"AUDIT.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({"summary":summary,"gate_documents":gates,"gate_source_excerpts":source_excerpts}))
