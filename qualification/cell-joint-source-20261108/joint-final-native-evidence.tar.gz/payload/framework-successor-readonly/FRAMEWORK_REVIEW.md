# PR #5388 successor: recovery, accounting, and drain review

## Reviewed identities and scope

- Base: `1eb72a1131285f5de98beeb7c95a27eab72d647e`.
- Successor: `f21e41039046b1247d64536bdec2bd308816f16d`, tree `2f646a4cd67c79f7673e913356460d0aac0dfdfd`.
- Joint source observed only through immutable Git blobs: `c37ebf8de8efc660229e66e4030d589be46bc194`.
- Read-only source review; no repository mutation, build, tests, training, optimizer, provider contact, or live data access. Frozen copies and this receipt are outside joint.
- Reviewed the automation recovery/event/store/state/drain/readback implementation, Cell clock-aware admission and Agentd Cell composition, and their added regression source. The separate S1/S2 reviewer owns signed ingress, supervised task lane, result-consumer lifetime, and ACT/CTRL composition.

**No merge-blocking defect was found in the reviewed recovery/cost/drain delta.** The event/state/store changes form one semantic unit and must enter the joint candidate together. This is a static review, not a new runtime pass.

## Findings

### 1. Settlement preserves the original computation and does not renew execution

`codex-rs/hepta-automation/src/circuit_history.rs:236–305` adds `RecoverySettled`. It requires the expected revision, no terminal outcome, monotonic observation, expired writer lease, and either a strictly higher generation with a nondecreasing owner epoch or the exact already-established settlement-only fence. The completion must identify an InFlight/Indeterminate activation whose retained execution-request digest matches.

The successor writer expires at the settlement timestamp. InFlight work becomes Indeterminate, then stop and Reconcile reduce as one journal event. This path grants no new execution lease and emits no new dispatch. Both normal lease claims and new computation claims reject a run with `settlement_fence_revision` set. A single recovery owner can settle several retained receipts without manufacturing a further generation.

`circuit_store.rs:143–159,203–228` routes this through the existing AutomationStore writer transaction. `circuit_journal.rs:317–440` verifies history, rejects changed bytes under an existing command ID, preserves exact-retry readback with no dispatch, applies revision/state-digest CAS, and appends the event before transaction commit. The recovery-budget allowance is not reset by process restart: the counter is derived from replay, with receipt slots reserved separately from lease-renewal capacity.

The tests explicitly retain actual work 7 against a smaller reservation, reject a changed actual-work retry, reopen the store, verify the original completion trace, reject stale/live/changed-request recovery, and prove that the first settlement cannot reopen an execution lease.

### 2. UNKNOWN and original queue cost are preserved

`codex-rs/hepta-neuron/src/cell_inference.rs:80–141` starts clock-aware durable admission with `host_queue_age_micros=None`, samples again after admission, and checks monotonicity, the queue-age bound, and the original Cell deadline before native contact. It records the original host wait even if the control call returns an error or an invalid receipt. Failure to durably retain that measurement leaves pending state.

`cell_inference.rs:150–206` reads only the originally admitted semantic/model request. It verifies unchanged snapshot, request, and deadline. Missing queue measurement returns `UnmeasuredQueueCost` before native readback; it is never replaced with zero or time spent waiting for recovery. Native queue time and retained host wait are added with checked arithmetic. Earlier caller/task-queue time is expressly outside this local measurement.

`codex-rs/hepta-agentd/src/circuit_cell.rs:182–241` uses the same live post-admission clock sample for the enclosing Circuit guard; regression of either clock or a passed Circuit lease/deadline prevents contact and retains pending state. Clock epochs are an explicit host responsibility across reopen/migration. The Cell and Circuit clocks have separate units/epochs; they are not silently converted into a common epoch.

`circuit_cell.rs:306–315` preserves actual model latency as Circuit work instead of clamping an overrun. This numeric work budget is not a complete physical/economic cost ledger: host wait remains in the Cell receipt, and this change does not establish energy, monetary cost, batching savings, or total serving benefit.

### 3. Drain is based on verified durable history

`codex-rs/hepta-automation/src/circuit_drain.rs:13–49` verifies the original AutomationStore owner and enumerates Circuit run projections in pages of 128 within one SQLite read transaction. Each enumerated run is replayed through the same canonical journal loader. An absent or corrupt history for a run is an error, not zero blockers. A run blocks while outcome is absent or unresolved work remains, including a stopped run whose original work is unsettled.

The regression source verifies:
- stopped pending work still blocks after store reopen;
- original settlement removes the blocker;
- projection tampering returns Corrupt;
- the scan reaches beyond its first page;
- a corrupt empty run ID is visited and rejected.

`circuit_task_readback.rs:22–55` binds the original definition/start/fence digest without registering a definition or creating genesis. Missing history returns None; differing original bytes or corrupt retained history are errors. Its regression drops history/projection only inside a fault fixture and checks that readback never repairs or recreates them.

The separate S1/S2 reviewer confirmed that the new task-lane ingress guard covers invocation construction through result publication, and that already-started native work retains its pending guard after caller cancellation. That review also checked all reopen gates: mark_draining sets drain_requested and closes readiness/admission under the runtime mutex; generation refresh, App Server readiness, and Notes readiness cannot reopen a draining process. Admission count is acquired under the same mutex before task construction. Drain reads active/pending before durable observation and includes pending again afterward. These are peer-reviewed source facts; runtime validation of their combined tree remains the root's pending native run.

### 4. Authority remains explicit

`circuit_cell.rs:115–137` accepts the sealed owner-issued computation admission, checks its owner/definition/original execution-request binding, and switches to readback/reconciliation when its lease/deadline is over. A raw dispatch DTO cannot use this API.

`circuit_cell.rs:253–280` requires the committed Cell decision to carry `AuthorityPosture::DENY_ALL`, the original operation/scope/input identity, valid digests, and abstention on an exceeded Cell deadline. The completion contains computational output and retained costs; it adds no tool-effect authority.

The successor README explicitly leaves cross-generation product recovery dependent on a current supervisor and original input/model receipt owners. It does not automatically reauthorize an old ObjectiveStart, qualify dynamic topology, or establish learning/adoption/next-task benefit.

## Compatibility and composition requirements

1. **New canonical event:** `RecoverySettled` serializes as `kind: recovery_settled` under the existing Circuit V2 journal. There is no Cargo or SQL-schema migration in this 40-file delta. Old readers do not understand the new variant; after such an event is written, old-binary downgrade compatibility is not available.
2. **Old digests:** `CircuitRunV2.settlement_fence_revision` uses `skip_serializing_if=Option::is_none`; untouched existing histories keep their prior canonical state bytes. The run is replayed, not deserialized as trusted projection state.
3. **Atomic import:** preserve history/state/runtime/store/journal and their public export together. Partial transplantation could omit settlement completion extraction, initialization of the optional state marker, or the guarded public API.
4. **Shared paths:** against c37, only `hepta-agentd/src/circuit_cell_tests.rs` and the three crates' `lib.rs` are changed on both sides. Keep all existing ACT/CTRL/common tests and exports while adding the successor modules. No runtime/cost source overlap was observed in the rest of this delta.
5. **Clock responsibility:** preserve/fence the Cell epoch on reboot or migration. The new task runtime takes the injected clock unchanged; this is an existing host-port contract, not a new automatic clock migration.
6. **Historical validation identity:** the acceptance JSON declares 1085/1085 native tests, 61 default-profile exclusions, and a compiler-metadata-pinned helper. Its head/tree observation is of the original base worktree, with per-file identities and post-maintenance equivalence recorded separately. All 38 Rust content hashes in that receipt equal the published f21 Git blobs. This supports the declared historical source binding, not a claim that the full new joint tree has already passed.

## Minimum meaningful combined verification

Root's planned four-package library verification covers the affected implementation and shared ledger contracts:

```text
just test --locked -p codex-hepta-automation -p codex-hepta-agentd -p codex-hepta-neuron -p codex-hepta-learning-ledger --lib --test-threads 2
```

Use the actual newly built `hepta-joint-propose` executable, selected from compiler metadata and bound by SHA, as already established. The important new regression names in this review are:

- `expired_recovery_settles_after_the_lease_allowance_is_exhausted`
- `expired_recovery_rejects_live_stale_and_changed_original_requests`
- `recovery_owner_settles_multiple_receipts_without_a_new_lease`
- `stopped_circuit_blocks_drain_after_reopen_until_original_work_settles`
- `drain_observation_includes_runs_beyond_the_first_page`
- `task_readback_never_initializes_missing_or_repairs_lost_history`
- `single_admission_sync_rechecks_deadline_clock_and_queue_before_contact`
- `single_queue_cost_and_policy_survive_errors_and_lost_measurement_ack`
- `single_uncertain_admission_never_contacts_native_or_invents_queue_cost`
- `single_entry_retains_measured_host_wait_for_original_request_readback`
- `either_clock_regression_after_admission_prevents_contact_and_retains_hold`

The signed ObjectiveStart/result-consumer E2E and current ACT/CTRL regressions are owned by S1/S2's composition review. Do not broaden this review into a scientific training run, and do not reuse the historical 1085 as the new combined candidate's count.
