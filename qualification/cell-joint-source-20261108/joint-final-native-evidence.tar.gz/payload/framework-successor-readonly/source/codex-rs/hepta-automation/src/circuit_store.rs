//! Circuit V2 uses the existing AutomationStore. No second DB or scheduler.
//! Every mutation holds SQLite's writer reservation across lease/CAS checks and
//! the event append. Public effect authority remains with its existing owner.

use codex_hepta_contracts::Sha256Digest;

use crate::AutomationStore;
use crate::BoundedCircuitDefinitionV2;
use crate::CircuitCommandReceiptV2;
use crate::CircuitCommandStatusV2;
use crate::CircuitCommandV2;
use crate::CircuitLeaseClaimV2;
use crate::CircuitRunV2;
use crate::CircuitStartV2;
use crate::TaskFlowError;
use crate::TaskFlowFence;
use crate::circuit_history::CircuitFenceIdentityV2;
use crate::circuit_history::CircuitLedgerEventV2;
use crate::circuit_history::CircuitRecoverySettlementV2;
use crate::circuit_journal;
use crate::circuit_journal::encode;
use crate::circuit_journal::unavailable;
use crate::circuit_profile::hash;
use crate::circuit_profile::text;
use crate::circuit_state::CircuitCommittedTraceV2;

impl AutomationStore {
    /// Register immutable bytes under the new explicit profile. Old versions
    /// remain readable; this does not replace any serving TaskFlow V1 graph.
    pub async fn register_bounded_circuit_definition(
        &self,
        definition: &BoundedCircuitDefinitionV2,
        fence: &TaskFlowFence,
    ) -> Result<Sha256Digest, TaskFlowError> {
        self.circuit_fence_identity(fence)?;
        let mut tx = self
            .taskflow_pool()
            .begin_with("BEGIN IMMEDIATE")
            .await
            .map_err(unavailable)?;
        circuit_journal::verify_owner(&mut tx, self.owner_agent_id()).await?;
        let digest =
            circuit_journal::register_definition(&mut tx, self.owner_agent_id(), definition)
                .await?;
        tx.commit().await.map_err(unavailable)?;
        Ok(digest)
    }

    /// Commit one bounded run and its frozen definition/inputs atomically.
    pub async fn create_bounded_circuit_run(
        &self,
        definition: &BoundedCircuitDefinitionV2,
        start: &CircuitStartV2,
        fence: &TaskFlowFence,
    ) -> Result<CircuitCommandReceiptV2, TaskFlowError> {
        let event = CircuitLedgerEventV2::Created {
            start: start.clone(),
            fence: self.circuit_fence_identity(fence)?,
        };
        let (run, _) = event.replay(/*previous*/ None, definition, self.owner_agent_id())?;
        let command_digest = hash("hepta.circuit.command.v2", &event)?;
        let mut tx = self
            .taskflow_pool()
            .begin_with("BEGIN IMMEDIATE")
            .await
            .map_err(unavailable)?;
        circuit_journal::verify_owner(&mut tx, self.owner_agent_id()).await?;
        circuit_journal::register_definition(&mut tx, self.owner_agent_id(), definition).await?;
        if let Some(history) =
            circuit_journal::load(&mut tx, self.owner_agent_id(), &start.run_id).await?
        {
            if history.run.definition_digest != run.definition_digest
                || history.commands.get("create") != Some(&command_digest)
            {
                return Err(TaskFlowError::Conflict(
                    "circuit run already has different initial bytes".to_string(),
                ));
            }
            tx.commit().await.map_err(unavailable)?;
            return Ok(CircuitCommandReceiptV2 {
                status: CircuitCommandStatusV2::AlreadyApplied,
                run: history.run,
                dispatches: Vec::new(),
            });
        }
        let previous = Sha256Digest::for_bytes(b"hepta.circuit.genesis.v2");
        let last_digest =
            circuit_journal::event_digest(&run, "create", &command_digest, &previous)?;
        sqlx::query("INSERT INTO circuit_v2_runs VALUES (?, ?, ?, ?, ?, ?, ?)")
            .bind(self.owner_agent_id().as_str())
            .bind(&run.run_id)
            .bind(run.definition_digest.as_str())
            .bind(0_i64)
            .bind(encode(&run)?)
            .bind(run.state_digest()?.as_str())
            .bind(last_digest.as_str())
            .execute(&mut *tx)
            .await
            .map_err(unavailable)?;
        circuit_journal::append(&mut tx, &run, "create", &event, &previous).await?;
        tx.commit().await.map_err(unavailable)?;
        Ok(CircuitCommandReceiptV2 {
            status: CircuitCommandStatusV2::Applied,
            run,
            dispatches: Vec::new(),
        })
    }

    /// Persist a scheduling quantum or a receipt. A duplicate command returns
    /// its verified current run and no new dispatch, even after acknowledgement
    /// loss. Changed bytes under the same command ID are rejected.
    pub async fn apply_bounded_circuit_command(
        &self,
        command: &CircuitCommandV2,
    ) -> Result<CircuitCommandReceiptV2, TaskFlowError> {
        let event = CircuitLedgerEventV2::Applied {
            fence: self.circuit_fence_identity(&command.fence)?,
            expected_revision: command.expected_revision,
            now_ms: command.now_ms,
            event: command.event.clone(),
        };
        self.apply_circuit_ledger(&command.run_id, &command.command_id, &event)
            .await
    }

    /// Lease renewal/takeover is journaled. Expired in-flight computations become
    /// indeterminate under the successor; original invocation identity and full
    /// reservations survive. They must reconcile, never dispatch again.
    pub async fn claim_bounded_circuit_run(
        &self,
        claim: &CircuitLeaseClaimV2,
    ) -> Result<CircuitCommandReceiptV2, TaskFlowError> {
        let event = CircuitLedgerEventV2::Claimed {
            fence: self.circuit_fence_identity(&claim.fence)?,
            expected_revision: claim.expected_revision,
            now_ms: claim.now_ms,
            lease_duration_ms: claim.lease_duration_ms,
        };
        self.apply_circuit_ledger(&claim.run_id, &claim.command_id, &event)
            .await
    }

    /// Stop an expired run and settle one original receipt in the same event.
    /// A higher fence enters settlement-only mode; subsequent receipts may use
    /// that exact fence. No lease or dispatch is issued, and the event consumes
    /// a reserved receipt slot even when recovery lease renewals are exhausted.
    pub async fn reconcile_expired_circuit_computation(
        &self,
        request: &CircuitRecoverySettlementV2,
    ) -> Result<CircuitCommandReceiptV2, TaskFlowError> {
        let event = CircuitLedgerEventV2::RecoverySettled {
            fence: self.circuit_fence_identity(&request.fence)?,
            expected_revision: request.expected_revision,
            now_ms: request.now_ms,
            execution_request_digest: request.execution_request_digest.clone(),
            completion: request.completion.clone(),
        };
        self.apply_circuit_ledger(&request.run_id, &request.command_id, &event)
            .await
    }

    /// Recover from canonical events in one consistent read transaction. A
    /// projection is compared against replay; it is never deserialized as trusted
    /// runtime state. This observation alone cannot reissue computation/effects.
    pub async fn bounded_circuit_run(
        &self,
        run_id: &str,
    ) -> Result<Option<CircuitRunV2>, TaskFlowError> {
        text(run_id)?;
        let mut tx = self.taskflow_pool().begin().await.map_err(unavailable)?;
        let history = circuit_journal::load(&mut tx, self.owner_agent_id(), run_id).await?;
        tx.commit().await.map_err(unavailable)?;
        Ok(history.map(|history| history.run))
    }

    /// Read the complete consumed computation receipts and their replayed run
    /// under the same SQLite snapshot. This never admits or repeats work.
    pub async fn bounded_circuit_committed_trace(
        &self,
        run_id: &str,
    ) -> Result<Option<CircuitCommittedTraceV2>, TaskFlowError> {
        text(run_id)?;
        let mut tx = self.taskflow_pool().begin().await.map_err(unavailable)?;
        let history = circuit_journal::load(&mut tx, self.owner_agent_id(), run_id).await?;
        tx.commit().await.map_err(unavailable)?;
        Ok(history.map(|history| CircuitCommittedTraceV2 {
            run: history.run,
            completions: history.completions,
            history_digest: history.last_digest,
        }))
    }

    fn circuit_fence_identity(
        &self,
        fence: &TaskFlowFence,
    ) -> Result<CircuitFenceIdentityV2, TaskFlowError> {
        if fence.owner_agent_id != *self.owner_agent_id() {
            return Err(TaskFlowError::StaleFence);
        }
        CircuitFenceIdentityV2::from_fence(fence)
    }

    async fn apply_circuit_ledger(
        &self,
        run_id: &str,
        command_id: &str,
        event: &CircuitLedgerEventV2,
    ) -> Result<CircuitCommandReceiptV2, TaskFlowError> {
        text(run_id)?;
        text(command_id)?;
        let mut tx = self
            .taskflow_pool()
            .begin_with("BEGIN IMMEDIATE")
            .await
            .map_err(unavailable)?;
        let history = circuit_journal::load(&mut tx, self.owner_agent_id(), run_id)
            .await?
            .ok_or_else(|| TaskFlowError::Conflict("unknown circuit run".to_string()))?;
        let receipt = circuit_journal::persist_transition(
            &mut tx,
            &history,
            self.owner_agent_id(),
            command_id,
            event,
        )
        .await?;
        tx.commit().await.map_err(unavailable)?;
        Ok(receipt)
    }
}
