import hashlib, json, os, re, sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd()))
from scripts.hepta_ci_exec import git, observed_test_counts
out = Path(os.environ["RUNNER_TEMP"]) / "windows-delete-boundary"
def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
def native_identity(runner, target, runner_os, runner_arch, rustc_lines):
    targets = {
        "windows-latest": ("x86_64-pc-windows-msvc", "X64"),
        "windows-11-arm": ("aarch64-pc-windows-msvc", "ARM64"),
    }
    assert runner in targets, "unknown Windows runner"
    expected, arch = targets[runner]
    assert target == expected, "runner and target disagree"
    assert runner_os == "Windows" and runner_arch == arch, "native runner identity disagrees"
    assert [line for line in rustc_lines if line.startswith("host: ")] == ["host: " + expected], "compiler host disagrees"
    assert [line for line in rustc_lines if line.startswith("release: ")] == ["release: 1.96.0"], "compiler release disagrees"
    return {"runner": runner, "target": expected, "runner_arch": arch}
probes = {
    "private-relative-rename": ("private_state_native_probe::relative_open_and_rename_remain_bound_to_held_root", "relative_rename_complete"),
    "private-held-sharing": ("private_state_native_probe::sharing_denies_directory_replacement_and_held_input_mutation", "sharing_complete"),
    "private-no-reparse": ("private_state_native_probe::rejects_reparse_paths_hardlinks_and_non_leaf_names", "reparse_complete"),
    "private-native-flush": ("private_state_native_probe::file_and_directory_flush_results_are_distinct", "flush_complete"),
}
operations = {
    "private-relative-rename": {'held_root_relative_rename': True, 'renamed_source_is_absent': False},
    "private-held-sharing": {'held_directory_rename_attack': False, 'held_input_write_attack': False, 'held_input_rename_attack': False},
    "private-no-reparse": {'root_leaf_reparse': False, 'root_ancestor_reparse': False, 'held_root_child_reparse': False, 'multiple_links_rejected': False, 'invalid_leaf_rejected': False},
    "private-native-flush": {'file_FlushFileBuffers_before_rename': True, 'held_root_relative_rename': True, 'file_FlushFileBuffers_after_rename': True, 'directory_FlushFileBuffers': True, 'directory_native_normal_flush': True, 'read_only_file_flush_negative_control': False},
}
acl_selectors = (
    "acl::tests::complete_denies_compare_mapped_masks_and_require_every_right",
    "acl::tests::complete_denies_require_effective_recursive_scope_and_precede_allows",
    "acl::tests::complete_denies_accept_native_effective_and_inherit_only_components",
    "acl::tests::complete_denies_do_not_borrow_missing_scope_from_another_sid",
    "acl::tests::complete_denies_require_all_rights_in_each_split_scope",
    "acl::tests::complete_file_denies_need_effective_rights_but_no_inheritance",
    "acl::tests::partial_read_deny_is_repaired_before_native_file_data_access",
    "acl::tests::deny_ace_update_failure_is_an_error",
)
owner_selectors = (
    "security::tests::native_owner_only_readback_is_valid_for_file_and_directory",
    "security::tests::native_rejects_existing_unsafe_dacls_without_repair",
    "security::tests::native_rejects_wrong_expected_sid_and_unsafe_object_shapes",
    "security::tests::native_readback_parser_rejects_altered_forms_and_every_truncation",
    "security::tests::native_unqueryable_thread_token_never_falls_back_to_process_user",
    "namespace_acl::tests::ancestor_parser_distinguishes_new_sibling_creation_from_existing_mutation",
    "namespace_acl::tests::inherited_effective_mutator_is_not_treated_as_inherit_only",
    "namespace_acl::tests::missing_truncated_and_unbounded_acl_are_refused",
    "namespace_acl::tests::unknown_owner_and_ace_forms_do_not_grant_namespace_admission",
    "namespace_acl::tests::exact_trustedinstaller_owner_and_maintenance_ace_are_namespace_only",
    "namespace_acl::tests::nearby_service_sids_never_gain_namespace_owner_or_mutator_trust",
    "namespace_acl::tests::trustedinstaller_owned_namespace_keeps_foreign_mutation_and_shape_refusals",
    "parent_anchor::fresh_private_directory::private_owner_lock::original_store_file::tests::actual_original_io_keeps_marker_and_payload_bytes_across_cold_open",
    "parent_anchor::fresh_private_directory::private_owner_lock::owner_file::tests::actual_private_file_extent_error_refuses_later_writes_without_growth",
    "parent_anchor::fresh_private_directory::private_owner_lock::owner_file::tests::actual_private_journal_reopens_original_bytes_and_appends_under_same_lock",
    "parent_anchor::fresh_private_directory::private_owner_lock::owner_file::tests::actual_read_only_private_file_cannot_write_truncate_or_create_missing",
    "parent_anchor::fresh_private_directory::private_owner_lock::owner_read::tests::actual_locked_read_descriptor_change_is_not_absence_or_repairable",
    "parent_anchor::fresh_private_directory::private_owner_lock::owner_read::tests::actual_locked_read_keeps_ancestry_alive_and_missing_is_only_observation",
    "parent_anchor::fresh_private_directory::private_owner_lock::owner_read::tests::actual_locked_read_rejects_real_hardlink_without_adopting_it",
    "parent_anchor::fresh_private_directory::private_owner_lock::owner_read::tests::actual_locked_read_size_error_fences_later_larger_read_without_reset",
    "parent_anchor::fresh_private_directory::private_owner_lock::owner_stage::tests::actual_locked_stage_replaces_synced_original_without_path_reopen",
    "parent_anchor::fresh_private_directory::private_owner_lock::owner_stage::tests::actual_locked_stage_share_conflict_never_replaces_or_repairs_state",
    "parent_anchor::fresh_private_directory::private_owner_lock::tests::actual_marker_sharing_error_is_rejection_not_state_locked_and_stays_refused",
    "parent_anchor::fresh_private_directory::private_owner_lock::tests::actual_owner_lock_refuses_shared_context_poison_without_recovery",
    "parent_anchor::fresh_private_directory::tests::actual_cold_candidate_never_creates_missing_or_adopts_changed_dacl",
    "parent_anchor::fresh_private_directory::tests::actual_cold_candidate_preserves_existing_bytes_and_shared_identity",
    "parent_anchor::fresh_private_directory::tests::actual_directory_context_poison_never_recovers_into_success",
    "parent_anchor::fresh_private_directory::tests::actual_new_directory_has_exact_protected_owner_dacl_on_original_handle",
    "parent_anchor::fresh_private_directory::tests::actual_parent_flush_uses_held_id_after_former_path_is_replaced",
    "parent_anchor::fresh_private_directory::tests::actual_parent_write_sharing_conflict_is_not_retried_or_repaired",
    "parent_anchor::fresh_private_directory::tests::actual_private_root_allows_compatible_second_owner_open_before_lock",
    "parent_anchor::fresh_private_directory::tests::actual_writable_directory_syncs_new_entry_without_noop_or_fallback",
    "parent_anchor::fresh_private_directory::tests::changed_child_descriptor_cannot_be_repaired_into_same_fresh_role",
    "parent_anchor::fresh_private_directory::tests::create_only_collision_never_adopts_or_overwrites_existing_state",
    "parent_anchor::tests::actual_ancestor_chain_revalidates_and_reopens_without_touching_state",
    "parent_anchor::tests::actual_parent_delete_child_rights_reject_live_and_cold_anchor",
    "primary_owner::tests::actual_elevated_primary_owner_remains_live",
    "primary_owner::tests::primary_owner_stays_refused_after_impersonation_is_restored",
    "primary_owner::tests::real_restricted_primary_token_is_refused",
    "primary_owner::tests::same_user_impersonation_cannot_mint_primary_owner",
)
store_selectors = {
    "original-final-use-windows": (
        "final_use::windows_owner::tests::native_explicit_owner_keeps_original_signed_claim_replay_and_os_lock",
        "final_use::windows_owner::tests::native_cold_frontier_mismatch_rejects_before_original_state_rewrites",
        "final_use::windows_owner::tests::native_legacy_zero_nonce_preserves_original_staged_and_committed_bytes",
        "windows_state_stage_tests::windows_stage_replaces_relative_to_held_directory_using_exact_source",
        "windows_state_stage_tests::windows_stage_without_delete_access_cannot_replace",
        "windows_state_stage_tests::windows_stage_respects_destination_delete_sharing",
        "windows_state_stage_tests::windows_stage_rejects_escaped_leaf_without_publication",
    ),
    "original-registry-windows": (
        "durable::platform::tests::native_registry_retains_os_lock_and_recovers_only_unselected_payload_tail",
        "durable::platform::tests::native_registry_corrupt_manifest_never_trims_or_rewrites_existing_state",
        "durable::platform::tests::native_registry_existing_marker_with_missing_manifest_never_reinitializes",
    ),
}
required = ("partial-delete-deny", "broad-identity-delete", "legacy-delete-boundary", *probes, "acl-unit-controls", "private-owner-descriptor", "full-restriction-candidate", "held-read-acl", "private-local-ntfs", "private-principal-continuity", "private-owner-lock", *store_selectors)
filtered_selectors = {
    "partial-delete-deny": ("token::tests::partial_delete_deny_is_repaired_before_native_workspace_writes",),
    "broad-identity-delete": ("token::tests::workspace_capabilities_deny_writes_and_deletes_under_broad_identity_aces",),
    "legacy-delete-boundary": ("unified_exec::tests::legacy_workspace_write_delete_is_limited_to_writable_roots",),
    "acl-unit-controls": acl_selectors,
    "full-restriction-candidate": ("token::tests::full_restriction::native_full_restriction_preserves_reads_and_refuses_parent_delete",),
    "held-read-acl": (
        "filesystem_read_acl::tests::actual_readv3_query_retains_same_plan_noninherited_handles_without_acl_repair",
        "filesystem_read_acl::tests::actual_read_role_extra_mutation_and_changed_descriptor_are_sticky_refusals",
        "filesystem_read_acl::tests::actual_read_role_different_plan_and_registry_change_never_rebind_an_old_proof",
    ),
    **{name: (selector,) for name, (selector, _) in probes.items()},
}
if sys.argv[1] == "tests":
    name, minimum = sys.argv[2], int(sys.argv[3])
    assert name in required, "unknown native test receipt"
    code, log_code = map(int, sys.argv[4].split())
    raw = (out / (name + ".log")).read_bytes()
    text = raw.decode("utf-8", errors="replace")
    text = re.sub(r"\x1b\[[0-9;]*m", "", text)
    passed, failed = observed_test_counts(text)
    ok = code == log_code == 0 and passed >= minimum and failed == 0 and re.search(r"Summary[^\n]*?\d+ tests? run:", text) is not None
    if name in {"private-owner-descriptor", "private-owner-lock", "private-principal-continuity", "private-local-ntfs"}:
        ok = ok and not re.search(r"\b[1-9][0-9]* skipped\b", text)
    def exact_names(selectors):
        names = re.findall(r"^test (.+?) \.\.\. ok\s*$", text, re.MULTILINE)
        return len(names) == len(selectors) and set(names) == set(selectors)
    if name in filtered_selectors:
        selectors = filtered_selectors[name]
        runs = re.findall(r"Summary[^\n]*?(\d+) tests? run:", text)
        ok = ok and minimum == passed == len(selectors) and runs == [str(len(selectors))] and exact_names(selectors)
    proof = {}
    if name in probes:
        selector, stage = probes[name]
        records, malformed = [], False
        for payload in re.findall(r"^HEPTA_PRIVATE_STATE_NATIVE_PROBE (.+)$", text, re.MULTILINE):
            try:
                records.append(json.loads(payload))
            except ValueError:
                malformed = True
        scopes = bool(records) and all(isinstance(row, dict) and row.get("owner_supported") is False and row.get("power_loss_qualified") is False for row in records)
        completed = scopes and any(row.get("stage") == stage for row in records)
        observed = {stage: bool(scopes and any(row.get("stage") == stage and isinstance(row.get("result"), dict) and row["result"].get("ok") is expected for row in records)) for stage, expected in operations[name].items()}
        named = re.search(r"^test " + re.escape(selector) + r" \.\.\. ok\s*$", text, re.MULTILINE) is not None
        runs = re.findall(r"Summary[^\n]*?(\d+) tests? run:", text)
        ok = ok and minimum == passed == 1 and runs[-1:] == ["1"] and named and completed and all(observed.values()) and not malformed
        proof = {"test_selector": selector, "completion_stage": stage, "exact_test_name_observed": named, "completion_observed": bool(completed), "required_operation_results_observed": observed, "probe_record_count": len(records), "malformed_probe_record": malformed, "owner_supported": False, "power_loss_qualified": False}
    elif name == "acl-unit-controls":
        observed = {selector: re.search(r"^test " + re.escape(selector) + r" \.\.\. ok\s*$", text, re.MULTILINE) is not None for selector in acl_selectors}
        ok = ok and minimum == len(acl_selectors) and all(observed.values())
        proof = {"test_filter": "test(/^acl::tests::/)", "required_test_names_observed": observed}
    elif name in store_selectors:
        selectors = store_selectors[name]
        runs = re.findall(r"Summary[^\n]*?(\d+) tests? run:", text)
        ok = ok and minimum == passed == len(selectors) and runs == [str(len(selectors))] and exact_names(selectors)
        proof = {"required_test_names_observed": list(selectors), "owner_supported": False, "power_loss_qualified": False, "whole_unit_qualified": False}
    elif name == "private-owner-descriptor":
        observed = {selector: re.search(r"^test " + re.escape(selector) + r" \.\.\. ok\s*$", text, re.MULTILINE) is not None for selector in owner_selectors}
        runs = re.findall(r"Summary[^\n]*?(\d+) tests? run:", text)
        ok = ok and minimum == passed == len(owner_selectors) and runs == [str(len(owner_selectors))] and all(observed.values()) and exact_names(owner_selectors)
        proof = {"test_package": "codex-utils-windows-private-state", "required_test_names_observed": observed, "owner_supported": False, "power_loss_qualified": False}
    elif name == "private-owner-lock":
        selectors = (
            "native_owner_lock_child",
            "actual_second_process_reports_state_locked_then_owner_drop_releases",
            "actual_natural_process_exit_releases_original_os_lock_without_destructor",
            "actual_cold_missing_marker_and_nonempty_marker_never_reset",
        )
        observed = {selector: re.search(r"^test " + re.escape(selector) + r" \.\.\. ok\s*$", text, re.MULTILINE) is not None for selector in selectors}
        runs = re.findall(r"Summary[^\n]*?(\d+) tests? run:", text)
        ok = ok and minimum == passed == 4 and runs == ["4"] and all(observed.values()) and exact_names(selectors)
        proof = {"test_target": "native_owner_lock", "required_test_names_observed": observed, "owner_supported": False, "power_loss_qualified": False, "whole_unit_qualified": False}
    elif name == "private-principal-continuity":
        selectors = (
            "native_same_effective_token_revalidates",
            "native_same_sid_replacement_is_refused_and_cannot_revive",
            "native_held_token_modification_is_refused",
            "native_degraded_and_unqueryable_thread_tokens_never_fall_back",
        )
        observed = {selector: re.search(r"^test " + re.escape(selector) + r" \.\.\. ok\s*$", text, re.MULTILINE) is not None for selector in selectors}
        runs = re.findall(r"Summary[^\n]*?(\d+) tests? run:", text)
        ok = ok and minimum == passed == 4 and runs == ["4"] and all(observed.values()) and exact_names(selectors)
        proof = {"test_target": "native_principal", "required_test_names_observed": observed, "owner_supported": False, "trusted_parent": False, "power_loss_qualified": False}
    elif name == "private-local-ntfs":
        selectors = (
            "native_local_ntfs_file_and_directory_report_same_volume",
            "native_nondisk_handle_is_rejected",
            "native_volume_observation_stays_bound_to_renamed_held_object",
            "native_directory_volume_observation_stays_bound_after_rename",
        )
        observed = {selector: re.search(r"^test " + re.escape(selector) + r" \.\.\. ok\s*$", text, re.MULTILINE) is not None for selector in selectors}
        runs = re.findall(r"Summary[^\n]*?(\d+) tests? run:", text)
        records, malformed = [], False
        for payload in re.findall(r"^HEPTA_LOCAL_NTFS_OBSERVATION (.+)$", text, re.MULTILINE):
            try:
                records.append(json.loads(payload))
            except ValueError:
                malformed = True
        expected_stages = {"local_ntfs_complete", "nondisk_complete", "held_binding_complete", "held_directory_binding_complete"}
        scopes = all(isinstance(row, dict) and set(row) == {"stage", "owner_supported", "trusted_parent", "power_loss_qualified"} and row.get("owner_supported") is False and row.get("trusted_parent") is False and row.get("power_loss_qualified") is False and isinstance(row.get("stage"), str) for row in records)
        completed = len(records) == 4 and scopes and {row["stage"] for row in records} == expected_stages
        ok = ok and minimum == passed == 4 and runs == ["4"] and all(observed.values()) and exact_names(selectors) and completed and not malformed
        proof = {"test_target": "native_volume", "required_test_names_observed": observed, "completion_observed": completed, "owner_supported": False, "trusted_parent": False, "power_loss_qualified": False, "remote_device_native_executed": False}
    elif name == "full-restriction-candidate":
        selector = "token::tests::full_restriction::native_full_restriction_preserves_reads_and_refuses_parent_delete"
        named = re.search(r"^test " + re.escape(selector) + r" \.\.\. ok\s*$", text, re.MULTILINE) is not None
        runs = re.findall(r"Summary[^\n]*?(\d+) tests? run:", text)
        records, malformed = [], False
        for payload in re.findall(r"^HEPTA_FULL_RESTRICTION_CANDIDATE (.+)$", text, re.MULTILINE):
            try:
                records.append(json.loads(payload))
            except ValueError:
                malformed = True
        record = records[0] if len(records) == 1 and isinstance(records[0], dict) else {}
        completed = len(records) == 1 and set(record) == {"stage", "readonly_controls", "explicit_read_execute", "production_admitted"} and record.get("stage") == "original_operations_complete" and record.get("readonly_controls") is True and record.get("explicit_read_execute") is True and record.get("production_admitted") is False
        ok = ok and minimum == passed == 1 and runs[-1:] == ["1"] and named and completed and not malformed
        proof = {"test_selector": selector, "exact_test_name_observed": named, "candidate_completion_observed": completed, "production_admitted": False}
    save(name + ".json", {"returncode": code, "logging_returncode": log_code, "minimum_tests": minimum, "observed_passed_tests": passed, "observed_failed_tests": failed, "log_sha256": hashlib.sha256(raw).hexdigest(), "status": "passed" if ok else "failed", **proof})
    sys.exit(0 if ok else 1)
phase = sys.argv[2]
result = {"scope": "three native Windows deletion regressions, four private-state mechanism probes, 40 private-state library controls including five original descriptor controls, four owner-lock process controls, eight current ACL controls, one test-only full-restriction candidate, four read-only local-NTFS controls, four live principal controls, seven original FinalUse/held-stage controls and three original Registry controls; real remote-device rejection is untested; no Windows owner support, production sandbox admission or power-loss qualification", "production_sandbox_admitted": False, "windows_private_state_owners_supported": False, "power_loss_qualified": False, "run_id": os.environ["GITHUB_RUN_ID"], "run_attempt": os.environ["GITHUB_RUN_ATTEMPT"], "status": "running"}
save("result.json", result)
assert sys.argv[1] == "source" and phase in {"before", "after"}
if phase == "before":
    for name in required:
        (out / (name + ".json")).unlink(missing_ok=True)
assert os.name == "nt", "this evidence requires native Windows execution"
native = native_identity(os.environ["HEPTA_CI_RUNNER"], os.environ["HEPTA_CI_TARGET"], os.environ["RUNNER_OS"], os.environ["RUNNER_ARCH"], (out / "rustc.txt").read_text().splitlines())
assert re.fullmatch(r"just 1\.51\.0\s*", (out / "just.txt").read_text())
assert re.match(r"cargo-nextest 0\.9\.103(?:\s|$)", (out / "nextest.txt").read_text())
source, tested, base, lane = (os.environ[key] for key in ("SOURCE_SHA", "TESTED_SHA", "BASE_SHA", "HEPTA_CI_LANE"))
assert all(re.fullmatch(r"[0-9a-f]{40}", value) for value in (source, tested, base))
head, tree, parents = git("rev-parse", "HEAD"), git("rev-parse", "HEAD^{tree}"), git("show", "-s", "--format=%P", "HEAD").split()
assert head == tested
assert git("cat-file", "-t", source) == "commit"
assert git("cat-file", "-t", base) == "commit"
if lane == "source-head":
    assert tested == source
else:
    assert lane == "base-merge" and parents == [base, source]
    assert tree == git("merge-tree", "--write-tree", base, source)
assert not git("diff", "--cached", "--raw", "--no-ext-diff", "--no-textconv", "HEAD", "--")
assert not git("ls-files", "--others", "--exclude-standard", "-z")
assert not any(row and (row[0] == "S" or row[0].islower()) for row in git("ls-files", "-v", "-z").split("\0"))
manifest, placeholders = [], 0
for row in git("ls-tree", "--full-tree", "-r", "-z", "HEAD").split("\0"):
    if not row:
        continue
    metadata, relative = row.split("\t", 1)
    mode, kind, expected = metadata.split()
    assert kind == "blob" and mode in {"100644", "100755", "120000"}
    path = Path(relative)
    if path.is_symlink():
        assert mode == "120000"
        data = os.fsencode(os.readlink(path))
    else:
        assert path.is_file()
        data = path.read_bytes()
        placeholders += int(mode == "120000")
    # NTFS does not represent Git executable bits; bind tree modes and
    # exact blob bytes, including Git's Windows symlink placeholders.
    assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data, usedforsecurity=False).hexdigest() == expected, relative
    manifest.append([relative, mode, hashlib.sha256(data).hexdigest()])
snapshot = {"source_sha": source, "base_sha": base, "tested_sha": head, "tree": tree, "parents": parents, "lane": lane, "tracked_files": len(manifest), "tracked_bytes_sha256": hashlib.sha256(json.dumps(manifest, separators=(",", ":")).encode()).hexdigest(), "symlink_placeholders": placeholders, "native": native}
save("source-" + phase + ".json", snapshot)
result["source"] = snapshot
if phase == "after":
    assert snapshot == json.loads((out / "source-before.json").read_text())
    result["tests"] = {name: json.loads((out / (name + ".json")).read_text()) for name in required}
    result["status"] = "passed" if all(value["status"] == "passed" for value in result["tests"].values()) else "failed"
save("result.json", result)
assert result["status"] != "failed"
