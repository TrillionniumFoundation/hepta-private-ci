use super::*;
use codex_utils_absolute_path::AbsolutePathBuf;
use codex_utils_absolute_path::AbsolutePathBufGuard;
use pretty_assertions::assert_eq;
use std::num::NonZeroU64;
use tempfile::tempdir;

#[test]
fn test_deserialize_ollama_model_provider_toml() {
    let azure_provider_toml = r#"
name = "Ollama"
base_url = "http://localhost:11434/v1"
        "#;
    let expected_provider = ModelProviderInfo {
        name: "Ollama".into(),
        base_url: Some("http://localhost:11434/v1".into()),
        env_key: None,
        env_key_instructions: None,
        experimental_bearer_token: None,
        auth: None,
        aws: None,
        wire_api: WireApi::Responses,
        query_params: None,
        http_headers: None,
        env_http_headers: None,
        request_max_retries: None,
        stream_max_retries: None,
        stream_idle_timeout_ms: None,
        websocket_connect_timeout_ms: None,
        requires_openai_auth: false,
        supports_websockets: false,
        supports_standalone_web_search: false,
        content_item_kinds_capability: None,
    };

    let provider: ModelProviderInfo = toml::from_str(azure_provider_toml).unwrap();
    assert_eq!(expected_provider, provider);
}

#[test]
fn test_deserialize_azure_model_provider_toml() {
    let azure_provider_toml = r#"
name = "Azure"
base_url = "https://xxxxx.openai.azure.com/openai"
env_key = "AZURE_OPENAI_API_KEY"
query_params = { api-version = "2025-04-01-preview" }
        "#;
    let expected_provider = ModelProviderInfo {
        name: "Azure".into(),
        base_url: Some("https://xxxxx.openai.azure.com/openai".into()),
        env_key: Some("AZURE_OPENAI_API_KEY".into()),
        env_key_instructions: None,
        experimental_bearer_token: None,
        auth: None,
        aws: None,
        wire_api: WireApi::Responses,
        query_params: Some(maplit::hashmap! {
            "api-version".to_string() => "2025-04-01-preview".into(),
        }),
        http_headers: None,
        env_http_headers: None,
        request_max_retries: None,
        stream_max_retries: None,
        stream_idle_timeout_ms: None,
        websocket_connect_timeout_ms: None,
        requires_openai_auth: false,
        supports_websockets: false,
        supports_standalone_web_search: false,
        content_item_kinds_capability: None,
    };

    let provider: ModelProviderInfo = toml::from_str(azure_provider_toml).unwrap();
    assert_eq!(expected_provider, provider);
}

#[test]
fn test_deserialize_example_model_provider_toml() {
    let azure_provider_toml = r#"
name = "Example"
base_url = "https://example.com"
env_key = "API_KEY"
http_headers = { "X-Example-Header" = "example-value" }
env_http_headers = { "X-Example-Env-Header" = "EXAMPLE_ENV_VAR" }
supports_standalone_web_search = true
        "#;
    let expected_provider = ModelProviderInfo {
        name: "Example".into(),
        base_url: Some("https://example.com".into()),
        env_key: Some("API_KEY".into()),
        env_key_instructions: None,
        experimental_bearer_token: None,
        auth: None,
        aws: None,
        wire_api: WireApi::Responses,
        query_params: None,
        http_headers: Some(maplit::hashmap! {
            "X-Example-Header".to_string() => "example-value".into(),
        }),
        env_http_headers: Some(maplit::hashmap! {
            "X-Example-Env-Header".to_string() => "EXAMPLE_ENV_VAR".to_string(),
        }),
        request_max_retries: None,
        stream_max_retries: None,
        stream_idle_timeout_ms: None,
        websocket_connect_timeout_ms: None,
        requires_openai_auth: false,
        supports_websockets: false,
        supports_standalone_web_search: true,
        content_item_kinds_capability: None,
    };

    let provider: ModelProviderInfo = toml::from_str(azure_provider_toml).unwrap();
    assert_eq!(expected_provider, provider);
}

#[test]
fn test_deserialize_chat_wire_api_shows_helpful_error() {
    let provider_toml = r#"
name = "OpenAI using Chat Completions"
base_url = "https://api.openai.com/v1"
env_key = "OPENAI_API_KEY"
wire_api = "chat"
        "#;

    let err = toml::from_str::<ModelProviderInfo>(provider_toml).unwrap_err();
    assert!(err.to_string().contains(CHAT_WIRE_API_REMOVED_ERROR));
}

#[test]
fn test_deserialize_websocket_connect_timeout() {
    let provider_toml = r#"
name = "OpenAI"
base_url = "https://api.openai.com/v1"
websocket_connect_timeout_ms = 15000
supports_websockets = true
        "#;

    let provider: ModelProviderInfo = toml::from_str(provider_toml).unwrap();
    assert_eq!(provider.websocket_connect_timeout_ms, Some(15_000));
}

#[test]
fn test_personal_access_token_uses_chatgpt_codex_base_url() {
    let api_provider = ModelProviderInfo::create_openai_provider(/*base_url*/ None)
        .to_api_provider(Some(AuthMode::PersonalAccessToken))
        .expect("OpenAI provider should build API provider");

    assert_eq!(api_provider.base_url, CHATGPT_CODEX_BASE_URL);
}

#[test]
fn test_header_auth_uses_chatgpt_codex_base_url() {
    let api_provider = ModelProviderInfo::create_openai_provider(/*base_url*/ None)
        .to_api_provider(Some(AuthMode::Headers))
        .expect("OpenAI provider should build API provider");

    assert_eq!(api_provider.base_url, CHATGPT_CODEX_BASE_URL);
}

#[test]
fn internal_metadata_wire_policy_uses_resolved_provider_url() {
    assert!(provider_accepts_internal_chat_message_metadata(
        OPENAI_API_BASE_URL
    ));
    assert!(provider_accepts_internal_chat_message_metadata(
        "https://API.OPENAI.COM/v1/"
    ));
    assert!(!provider_accepts_internal_chat_message_metadata(
        CHATGPT_CODEX_BASE_URL
    ));
    assert!(!provider_accepts_internal_chat_message_metadata(
        "https://api.openai.com/proxy/v1"
    ));
}

#[test]
fn test_uses_openai_actor_authorization() {
    let mut provider = ModelProviderInfo {
        http_headers: Some(maplit::hashmap! {
            "X-OpenAI-Actor-Authorization".to_string() => "actor-token".into(),
        }),
        ..ModelProviderInfo::default()
    };
    assert!(provider.uses_openai_actor_authorization());

    provider.http_headers = None;
    assert!(!provider.uses_openai_actor_authorization());

    provider.http_headers = Some(maplit::hashmap! {
        OPENAI_ACTOR_AUTHORIZATION_HEADER.to_string() => "  ".into(),
    });
    assert!(!provider.uses_openai_actor_authorization());

    provider.http_headers = Some(maplit::hashmap! {
        OPENAI_ACTOR_AUTHORIZATION_HEADER.to_string() => "actor-token".into(),
    });
    provider.requires_openai_auth = true;
    assert!(!provider.uses_openai_actor_authorization());
}

#[test]
fn test_deserialize_provider_auth_config_defaults() {
    let base_dir = tempdir().unwrap();
    let provider_toml = r#"
name = "Corp"

[auth]
command = "./scripts/print-token"
args = ["--format=text"]
        "#;

    let provider: ModelProviderInfo = {
        let _guard = AbsolutePathBufGuard::new(base_dir.path());
        toml::from_str(provider_toml).unwrap()
    };

    assert_eq!(
        provider.auth,
        Some(ModelProviderAuthInfo {
            command: "./scripts/print-token".to_string(),
            args: vec!["--format=text".into()],
            timeout_ms: NonZeroU64::new(5_000).unwrap(),
            refresh_interval_ms: 300_000,
            cwd: AbsolutePathBuf::resolve_path_against_base(".", base_dir.path()),
        })
    );
}

#[test]
fn test_deserialize_provider_aws_config() {
    let provider_toml = r#"
name = "Amazon Bedrock"
base_url = "https://bedrock.example.com/v1"

[aws]
profile = "codex-bedrock"
region = "us-west-2"

[aws.auth_refresh]
command = "aws"
args = ["login", "--profile", "codex-bedrock"]
        "#;

    let provider: ModelProviderInfo = toml::from_str(provider_toml).unwrap();

    assert_eq!(
        provider.aws,
        Some(ModelProviderAwsAuthInfo {
            profile: Some("codex-bedrock".to_string()),
            region: Some("us-west-2".to_string()),
            auth_refresh: Some(AwsAuthRefreshConfig {
                command: "aws".to_string(),
                args: vec!["login".into(), "--profile".into(), "codex-bedrock".into()],
                timeout_ms: NonZeroU64::new(300_000).expect("timeout should be non-zero"),
            }),
        })
    );
}

#[test]
fn test_create_amazon_bedrock_provider() {
    assert_eq!(
        ModelProviderInfo::create_amazon_bedrock_provider(/*aws*/ None),
        ModelProviderInfo {
            name: "Amazon Bedrock".to_string(),
            base_url: None,
            env_key: None,
            env_key_instructions: None,
            experimental_bearer_token: None,
            auth: None,
            aws: Some(ModelProviderAwsAuthInfo {
                profile: None,
                region: None,
                auth_refresh: None,
            }),
            wire_api: WireApi::Responses,
            query_params: None,
            http_headers: Some(maplit::hashmap! {
                AMAZON_BEDROCK_MANTLE_CLIENT_AGENT_HEADER.to_string() =>
                    AMAZON_BEDROCK_MANTLE_CLIENT_AGENT_VALUE.into(),
            }),
            env_http_headers: None,
            request_max_retries: None,
            stream_max_retries: None,
            stream_idle_timeout_ms: None,
            websocket_connect_timeout_ms: None,
            requires_openai_auth: false,
            supports_websockets: false,
            supports_standalone_web_search: false,
            content_item_kinds_capability: None,
        }
    );
}

#[test]
fn test_create_amazon_bedrock_runtime_provider() {
    let mut expected = ModelProviderInfo::create_amazon_bedrock_provider(/*aws*/ None);
    expected.name = "Amazon Bedrock Runtime".to_string();
    expected.http_headers = None;

    assert_eq!(
        ModelProviderInfo::create_amazon_bedrock_runtime_provider(/*aws*/ None),
        expected
    );
}

#[test]
fn test_create_amazon_bedrock_runtime_provider_with_aws_configuration() {
    let provider =
        ModelProviderInfo::create_amazon_bedrock_runtime_provider(Some(ModelProviderAwsAuthInfo {
            profile: Some("runtime-profile".to_string()),
            region: Some("us-west-2".to_string()),
            auth_refresh: None,
        }));

    assert_eq!(
        (
            provider.name.as_str(),
            provider.aws,
            provider.http_headers,
            provider.supports_standalone_web_search,
        ),
        (
            "Amazon Bedrock Runtime",
            Some(ModelProviderAwsAuthInfo {
                profile: Some("runtime-profile".to_string()),
                region: Some("us-west-2".to_string()),
                auth_refresh: None,
            }),
            None,
            false,
        )
    );
}

fn provider_auth_for_test() -> ModelProviderAuthInfo {
    ModelProviderAuthInfo {
        command: "token-fetcher".to_string(),
        args: vec!["fetch".into()],
        timeout_ms: NonZeroU64::new(5_000).expect("timeout should be non-zero"),
        refresh_interval_ms: 300_000,
        cwd: std::env::current_dir()
            .expect("current directory should be available")
            .try_into()
            .expect("current directory should be absolute"),
    }
}

#[test]
fn test_amazon_bedrock_provider_adds_mantle_client_agent_header() {
    let api_provider = ModelProviderInfo::create_amazon_bedrock_provider(/*aws*/ None)
        .to_api_provider(/*auth_mode*/ None)
        .expect("Amazon Bedrock provider should build API provider");

    assert_eq!(
        api_provider
            .headers
            .get(AMAZON_BEDROCK_MANTLE_CLIENT_AGENT_HEADER)
            .and_then(|value| value.to_str().ok()),
        Some(AMAZON_BEDROCK_MANTLE_CLIENT_AGENT_VALUE)
    );
}

#[test]
fn test_built_in_model_providers_include_amazon_bedrock_endpoints() {
    let providers = built_in_model_providers(/*openai_base_url*/ None);

    assert_eq!(
        [
            AMAZON_BEDROCK_PROVIDER_ID,
            AMAZON_BEDROCK_RUNTIME_PROVIDER_ID
        ]
        .into_iter()
        .map(|provider_id| {
            providers
                .get(provider_id)
                .map(ModelProviderInfo::is_amazon_bedrock)
        })
        .collect::<Vec<_>>(),
        vec![Some(true), Some(true)]
    );
}

#[test]
fn test_built_in_model_providers_include_amazon_bedrock_runtime() {
    let providers = built_in_model_providers(/*openai_base_url*/ None);
    let runtime = providers
        .get(AMAZON_BEDROCK_RUNTIME_PROVIDER_ID)
        .expect("Amazon Bedrock Runtime provider should be built in");

    assert!(runtime.is_amazon_bedrock());
    assert!(runtime.is_amazon_bedrock_runtime());
    assert!(
        !providers
            .get(AMAZON_BEDROCK_PROVIDER_ID)
            .expect("Amazon Bedrock provider should be built in")
            .is_amazon_bedrock_runtime()
    );
}

#[test]
fn test_merge_configured_model_providers_adds_custom_provider() {
    let custom_provider = ModelProviderInfo {
        name: "Custom".to_string(),
        base_url: Some("https://example.com/v1".to_string()),
        ..ModelProviderInfo::default()
    };
    let configured_model_providers =
        std::collections::HashMap::from([("custom".to_string(), custom_provider.clone())]);

    let mut expected = built_in_model_providers(/*openai_base_url*/ None);
    expected.insert("custom".to_string(), custom_provider);

    assert_eq!(
        merge_configured_model_providers(
            built_in_model_providers(/*openai_base_url*/ None),
            configured_model_providers,
        ),
        Ok(expected)
    );
}

#[test]
fn test_merge_configured_model_providers_applies_amazon_bedrock_aws_override() {
    let auth_refresh = AwsAuthRefreshConfig {
        command: "aws".to_string(),
        args: vec!["login".into(), "--profile".into(), "codex-bedrock".into()],
        timeout_ms: NonZeroU64::new(10_000).expect("timeout should be non-zero"),
    };
    let configured_model_providers = std::collections::HashMap::from([(
        AMAZON_BEDROCK_PROVIDER_ID.to_string(),
        ModelProviderInfo {
            aws: Some(ModelProviderAwsAuthInfo {
                profile: Some("codex-bedrock".to_string()),
                region: Some("us-west-2".to_string()),
                auth_refresh: Some(auth_refresh.clone()),
            }),
            ..ModelProviderInfo::default()
        },
    )]);

    let mut expected = built_in_model_providers(/*openai_base_url*/ None);
    expected
        .get_mut(AMAZON_BEDROCK_PROVIDER_ID)
        .expect("Amazon Bedrock provider should be built in")
        .aws = Some(ModelProviderAwsAuthInfo {
        profile: Some("codex-bedrock".to_string()),
        region: Some("us-west-2".to_string()),
        auth_refresh: Some(auth_refresh),
    });

    assert_eq!(
        merge_configured_model_providers(
            built_in_model_providers(/*openai_base_url*/ None),
            configured_model_providers,
        ),
        Ok(expected)
    );
}

#[test]
fn test_merge_configured_model_providers_applies_runtime_overrides_independently() {
    let runtime_aws = ModelProviderAwsAuthInfo {
        profile: Some("runtime-profile".to_string()),
        region: Some("eu-west-1".to_string()),
        auth_refresh: None,
    };
    let configured_model_providers = std::collections::HashMap::from([(
        AMAZON_BEDROCK_RUNTIME_PROVIDER_ID.to_string(),
        ModelProviderInfo {
            base_url: Some("https://runtime.example.com/openai/v1".to_string()),
            aws: Some(runtime_aws.clone()),
            ..ModelProviderInfo::default()
        },
    )]);
    let mut expected = built_in_model_providers(/*openai_base_url*/ None);
    let expected_runtime = expected
        .get_mut(AMAZON_BEDROCK_RUNTIME_PROVIDER_ID)
        .expect("Amazon Bedrock Runtime provider should be built in");
    expected_runtime.base_url = Some("https://runtime.example.com/openai/v1".to_string());
    expected_runtime.aws = Some(runtime_aws);

    assert_eq!(
        merge_configured_model_providers(
            built_in_model_providers(/*openai_base_url*/ None),
            configured_model_providers,
        ),
        Ok(expected)
    );
}

#[test]
fn test_merge_configured_model_providers_applies_amazon_bedrock_transport_overrides() {
    let auth = provider_auth_for_test();
    let configured_model_providers = std::collections::HashMap::from([(
        AMAZON_BEDROCK_PROVIDER_ID.to_string(),
        ModelProviderInfo {
            base_url: Some("https://proxy.example.com/v1".to_string()),
            auth: Some(auth.clone()),
            aws: Some(ModelProviderAwsAuthInfo {
                profile: Some("codex-bedrock".to_string()),
                region: Some("us-west-2".to_string()),
                auth_refresh: None,
            }),
            http_headers: Some(maplit::hashmap! {
                "x-example-header".to_string() => "value".into(),
            }),
            ..ModelProviderInfo::default()
        },
    )]);

    let mut expected = built_in_model_providers(/*openai_base_url*/ None);
    let expected_provider = expected
        .get_mut(AMAZON_BEDROCK_PROVIDER_ID)
        .expect("Amazon Bedrock provider should be built in");
    expected_provider.base_url = Some("https://proxy.example.com/v1".to_string());
    expected_provider.auth = Some(auth);
    expected_provider.aws = Some(ModelProviderAwsAuthInfo {
        profile: Some("codex-bedrock".to_string()),
        region: Some("us-west-2".to_string()),
        auth_refresh: None,
    });
    expected_provider
        .http_headers
        .get_or_insert_default()
        .insert("x-example-header".to_string(), "value".into());

    assert_eq!(
        merge_configured_model_providers(
            built_in_model_providers(/*openai_base_url*/ None),
            configured_model_providers,
        ),
        Ok(expected)
    );
}

#[test]
fn test_merge_configured_model_providers_rejects_amazon_bedrock_non_default_fields() {
    let configured_model_providers = std::collections::HashMap::from([(
        AMAZON_BEDROCK_PROVIDER_ID.to_string(),
        ModelProviderInfo {
            name: "Custom Bedrock".to_string(),
            aws: Some(ModelProviderAwsAuthInfo {
                profile: Some("codex-bedrock".to_string()),
                region: None,
                auth_refresh: None,
            }),
            ..ModelProviderInfo::default()
        },
    )]);

    assert_eq!(
        merge_configured_model_providers(
            built_in_model_providers(/*openai_base_url*/ None),
            configured_model_providers,
        ),
        Err(
            "model_providers.amazon-bedrock only supports changing `base_url`, `auth`, `http_headers`, `aws.profile`, `aws.region`, and `aws.auth_refresh`; other non-default provider fields are not supported"
                .to_string()
        )
    );
}

#[test]
fn test_merge_configured_model_providers_allows_amazon_bedrock_default_fields() {
    let configured_model_providers = std::collections::HashMap::from([(
        AMAZON_BEDROCK_PROVIDER_ID.to_string(),
        ModelProviderInfo {
            aws: Some(ModelProviderAwsAuthInfo {
                profile: None,
                region: None,
                auth_refresh: None,
            }),
            wire_api: WireApi::Responses,
            ..ModelProviderInfo::default()
        },
    )]);

    assert_eq!(
        merge_configured_model_providers(
            built_in_model_providers(/*openai_base_url*/ None),
            configured_model_providers,
        ),
        Ok(built_in_model_providers(/*openai_base_url*/ None))
    );
}

#[test]
fn test_validate_provider_aws_rejects_conflicting_auth() {
    let provider = ModelProviderInfo {
        aws: Some(ModelProviderAwsAuthInfo {
            profile: None,
            region: None,
            auth_refresh: None,
        }),
        env_key: Some("AWS_BEARER_TOKEN_BEDROCK".to_string()),
        supports_websockets: false,
        ..ModelProviderInfo::create_openai_provider(/*base_url*/ None)
    };

    assert_eq!(
        provider.validate(),
        Err("provider aws cannot be combined with env_key, requires_openai_auth".to_string())
    );
}

#[test]
fn test_validate_provider_aws_rejects_websockets() {
    let provider = ModelProviderInfo {
        aws: Some(ModelProviderAwsAuthInfo {
            profile: None,
            region: None,
            auth_refresh: None,
        }),
        requires_openai_auth: false,
        supports_websockets: true,
        ..ModelProviderInfo::create_openai_provider(/*base_url*/ None)
    };

    assert_eq!(
        provider.validate(),
        Err("provider aws cannot be combined with supports_websockets".to_string())
    );
}

#[test]
fn test_validate_provider_aws_auth_refresh_command() {
    for (command, expected) in [
        (
            "  ",
            Err("provider aws.auth_refresh.command must not be empty".to_string()),
        ),
        (
            "other-command",
            Err("provider aws.auth_refresh.command must be `aws`".to_string()),
        ),
        ("aws", Ok(())),
    ] {
        let provider =
            ModelProviderInfo::create_amazon_bedrock_provider(Some(ModelProviderAwsAuthInfo {
                profile: None,
                region: None,
                auth_refresh: Some(AwsAuthRefreshConfig {
                    command: command.to_string(),
                    args: Vec::new(),
                    timeout_ms: NonZeroU64::new(300_000).expect("timeout should be non-zero"),
                }),
            }));

        assert_eq!(provider.validate(), expected);
    }
}

#[test]
fn test_deserialize_provider_auth_config_allows_zero_refresh_interval() {
    let base_dir = tempdir().unwrap();
    let provider_toml = r#"
name = "Corp"

[auth]
command = "./scripts/print-token"
refresh_interval_ms = 0
        "#;

    let provider: ModelProviderInfo = {
        let _guard = AbsolutePathBufGuard::new(base_dir.path());
        toml::from_str(provider_toml).unwrap()
    };

    let auth = provider.auth.expect("auth config should deserialize");
    assert_eq!(auth.refresh_interval_ms, 0);
    assert_eq!(auth.refresh_interval(), None);
}

#[test]
fn content_item_kinds_capability_requires_the_exact_configured_and_resolved_endpoint() {
    let endpoint = "https://receiver.example/v1";
    let provider = ModelProviderInfo {
        base_url: Some(endpoint.to_string()),
        content_item_kinds_capability: Some(ContentItemKindsCapability {
            endpoint: endpoint.to_string(),
        }),
        ..ModelProviderInfo::default()
    };
    assert_eq!(provider.validate(), Ok(()));
    assert_eq!(
        provider.internal_chat_message_metadata_policy(endpoint),
        InternalChatMessageMetadataPolicy::ContentItemKindsOnly,
    );

    for resolved in [
        "http://receiver.example/v1",
        "https://other.example/v1",
        "https://receiver.example:8443/v1",
        "https://receiver.example/other",
        "https://receiver.example/v1/",
        "https://receiver.example/v1?key=value",
        CHATGPT_CODEX_BASE_URL,
    ] {
        assert_eq!(
            provider.internal_chat_message_metadata_policy(resolved),
            InternalChatMessageMetadataPolicy::None,
            "a capability must not migrate to {resolved}",
        );
    }

    let mut changed_configuration = provider.clone();
    changed_configuration.base_url = Some("https://other.example/v1".to_string());
    assert!(changed_configuration.validate().is_err());
    assert_eq!(
        changed_configuration.internal_chat_message_metadata_policy(endpoint),
        InternalChatMessageMetadataPolicy::None,
    );
    changed_configuration.base_url = None;
    assert!(changed_configuration.validate().is_err());
    assert_eq!(
        changed_configuration.internal_chat_message_metadata_policy(endpoint),
        InternalChatMessageMetadataPolicy::None,
    );
}

#[test]
fn content_item_kinds_capability_does_not_trust_provider_names_or_loopback() {
    for endpoint in [
        "http://127.0.0.1:39001/v1",
        "http://localhost:39001/v1",
        "https://proxy.example/v1",
        CHATGPT_CODEX_BASE_URL,
    ] {
        let mut provider = ModelProviderInfo {
            name: "OpenAI".to_string(),
            base_url: Some(endpoint.to_string()),
            ..ModelProviderInfo::default()
        };
        assert_eq!(
            provider.internal_chat_message_metadata_policy(endpoint),
            InternalChatMessageMetadataPolicy::None,
        );
        provider.content_item_kinds_capability = Some(ContentItemKindsCapability {
            endpoint: endpoint.to_string(),
        });
        let expected = if endpoint == CHATGPT_CODEX_BASE_URL {
            InternalChatMessageMetadataPolicy::None
        } else {
            InternalChatMessageMetadataPolicy::ContentItemKindsOnly
        };
        assert_eq!(provider.internal_chat_message_metadata_policy(endpoint), expected);
    }

    for endpoint in [
        "file:///tmp/provider",
        "receiver.example/v1",
        "https://user:password@receiver.example/v1",
        "https://receiver.example/v1?key=value",
        "https://receiver.example/v1#fragment",
        "https://CHATGPT.COM/backend-api/codex",
        "https://chatgpt.com:443/backend-api/codex",
        "https://chatgpt.com./backend-api/codex",
        "https://chatgpt%2ecom/backend-api/codex",
    ] {
        let provider = ModelProviderInfo {
            base_url: Some(endpoint.to_string()),
            content_item_kinds_capability: Some(ContentItemKindsCapability {
                endpoint: endpoint.to_string(),
            }),
            ..ModelProviderInfo::default()
        };
        assert!(provider.validate().is_err(), "must reject {endpoint}");
        assert_eq!(
            provider.internal_chat_message_metadata_policy(endpoint),
            InternalChatMessageMetadataPolicy::None,
        );
    }
}

#[test]
fn content_item_kinds_capability_forwards_no_other_internal_fields() {
    use codex_protocol::models::ContentItem;
    use codex_protocol::models::ContentItemKind;
    use codex_protocol::models::InternalChatMessageMetadataPassthrough;
    use codex_protocol::models::ResponseItem;

    let durable = ResponseItem::Message {
        id: None,
        role: "user".to_string(),
        content: vec![ContentItem::InputAudio {
            audio_url: "data:audio/wav;base64,AAAA".to_string(),
        }],
        phase: None,
        internal_chat_message_metadata_passthrough: Some(
            InternalChatMessageMetadataPassthrough {
                turn_id: Some("private-turn-id".to_string()),
                create_time: Some(12.into()),
                content_item_kinds: Some(vec![ContentItemKind("user.audio".to_string())]),
                executed_tool_calls: Some(vec![]),
            },
        ),
    };
    let mut wire = durable.clone();
    InternalChatMessageMetadataPolicy::ContentItemKindsOnly.apply(&mut wire);
    let expected = ResponseItem::Message {
        id: None,
        role: "user".to_string(),
        content: vec![ContentItem::InputAudio {
            audio_url: "data:audio/wav;base64,AAAA".to_string(),
        }],
        phase: None,
        internal_chat_message_metadata_passthrough: Some(
            InternalChatMessageMetadataPassthrough {
                content_item_kinds: Some(vec![ContentItemKind("user.audio".to_string())]),
                ..Default::default()
            },
        ),
    };
    assert_eq!(wire, expected);

    let mut first_party_wire = durable.clone();
    InternalChatMessageMetadataPolicy::All.apply(&mut first_party_wire);
    assert_eq!(first_party_wire, durable);

    let mut unknown_wire = durable;
    InternalChatMessageMetadataPolicy::None.apply(&mut unknown_wire);
    let mut no_metadata = expected;
    no_metadata.clear_internal_chat_message_metadata_passthrough();
    assert_eq!(unknown_wire, no_metadata);

    let mut no_kinds = ResponseItem::Message {
        id: None,
        role: "user".to_string(),
        content: vec![ContentItem::InputAudio {
            audio_url: "data:audio/wav;base64,AAAA".to_string(),
        }],
        phase: None,
        internal_chat_message_metadata_passthrough: Some(
            InternalChatMessageMetadataPassthrough {
                turn_id: Some("private-turn-id".to_string()),
                create_time: Some(12.into()),
                content_item_kinds: None,
                executed_tool_calls: Some(vec![]),
            },
        ),
    };
    InternalChatMessageMetadataPolicy::ContentItemKindsOnly.apply(&mut no_kinds);
    assert_eq!(no_kinds, no_metadata);
}

#[test]
fn content_item_kinds_capability_configuration_is_explicit_and_field_limited() {
    let provider: ModelProviderInfo = toml::from_str(
        r#"
base_url = "https://receiver.example/v1"
[content_item_kinds_capability]
endpoint = "https://receiver.example/v1"
"#,
    )
    .expect("the owner can explicitly declare this receiver's field capability");
    let expected = ModelProviderInfo {
        base_url: Some("https://receiver.example/v1".to_string()),
        content_item_kinds_capability: Some(ContentItemKindsCapability {
            endpoint: "https://receiver.example/v1".to_string(),
        }),
        ..ModelProviderInfo::default()
    };
    assert_eq!(provider, expected);
    assert_eq!(provider.validate(), Ok(()));
    assert!(
        !toml::to_string(&ModelProviderInfo::default())
            .expect("default provider serializes")
            .contains("content_item_kinds_capability")
    );
    assert!(
        toml::from_str::<ModelProviderInfo>(
            r#"
base_url = "https://receiver.example/v1"
[content_item_kinds_capability]
endpoint = "https://receiver.example/v1"
turn_id = true
"#,
        )
        .is_err()
    );
}

#[test]
fn content_item_kinds_capability_rejects_api_base_path_normalization() {
    for endpoint in [
        "https://receiver.example/allowed/./other",
        "https://receiver.example/allowed/../other",
        "https://receiver.example/allowed/.",
        "https://receiver.example/allowed/..",
        "https://receiver.example/allowed/%2e%2e/other",
        "https://receiver.example/allowed/%2E/other",
        "https://receiver.example/allowed/.%2e/other",
        "https://receiver.example/allowed/%2e./other",
        "https://receiver.example/allowed/%5cother",
        "https://receiver.example/allowed/%5Cother",
        "https://receiver.example/allowed\\other",
        "https://receiver.example/allowed/%2fother",
        "https://receiver.example/allowed/%252e%252e/other",
        "https://receiver.example/release%20name/v1",
    ] {
        let provider = ModelProviderInfo {
            base_url: Some(endpoint.to_string()),
            content_item_kinds_capability: Some(ContentItemKindsCapability {
                endpoint: endpoint.to_string(),
            }),
            ..ModelProviderInfo::default()
        };
        assert!(provider.validate().is_err(), "must reject {endpoint}");
        assert_eq!(
            provider.internal_chat_message_metadata_policy(endpoint),
            InternalChatMessageMetadataPolicy::None,
        );
    }

    for endpoint in [
        "https://receiver.example/v1",
        "https://receiver.example/allowed/provider-v2",
        "https://receiver.example/allowed/provider.v2",
        "https://receiver.example/allowed/.well-known/api",
        "https://receiver.example/allowed/v1/",
        "http://127.0.0.1:39001/v1",
    ] {
        let provider = ModelProviderInfo {
            base_url: Some(endpoint.to_string()),
            content_item_kinds_capability: Some(ContentItemKindsCapability {
                endpoint: endpoint.to_string(),
            }),
            query_params: Some(maplit::hashmap! {
                "api-version".to_string() => "2026-10-27".into(),
            }),
            ..ModelProviderInfo::default()
        };
        assert_eq!(provider.validate(), Ok(()));
        assert_eq!(
            provider.internal_chat_message_metadata_policy(endpoint),
            InternalChatMessageMetadataPolicy::ContentItemKindsOnly,
        );
    }
}
