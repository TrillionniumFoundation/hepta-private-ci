from pathlib import Path
import json,os,subprocess,hashlib,datetime,time,sys
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_text());R=Path(P['root']);W=D.parents[2]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,o):
 with (D/n).open('x') as f:json.dump(o,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==P['local_parent']
for n,x in P['source_pins'].items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==x['sha256'],n
env=os.environ.copy();env.update({'CARGO_TARGET_DIR':str(W/'work/ci-follow/Hepta-Mac-authorized-read-root-integration-20261027-001/linux-mapping-target'),'CARGO_BUILD_JOBS':'1','CARGO_NET_OFFLINE':'true','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0','RUSTUP_TOOLCHAIN':'1.96.0'})
t=time.monotonic_ns();argv=P['steps'][0]['argv']
with (D/'stdout.original').open('xb') as so,(D/'stderr.original').open('xb') as se:
 child=subprocess.Popen(argv,cwd=R/'codex-rs',env=env,stdout=so,stderr=se)
 save('actual-source-fix-start.json',{'recorded_utc':now(),'runner_pid':os.getpid(),'runner_birth':Path('/proc/self/stat').read_text(),'child_pid':child.pid,'child_birth':Path(f'/proc/{child.pid}/stat').read_text(),'invocation':os.environ.get('INVOCATION_ID'),'command':argv})
 rc=child.wait();so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
after={}
for n in P['source_pins']:
 b=(R/n).read_bytes();after[n]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'changed':hashlib.sha256(b).hexdigest()!=P['source_pins'][n]['sha256']}
save('actual-source-fix-terminal.json',{'recorded_utc':now(),'actual_child_wait':rc,'seconds':(time.monotonic_ns()-t)/1e9,'after_source_pins':after,'raw':{n:{'bytes':(D/n).stat().st_size,'sha256':hashlib.sha256((D/n).read_bytes()).hexdigest()} for n in ['stdout.original','stderr.original']},'remaining_core_dependent_lint_NOT_QUALIFIED':True,'original_CI_NOT_QUALIFIED':True,'merge_ready':False})
sys.exit(rc)
