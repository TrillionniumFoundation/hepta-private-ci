from pathlib import Path
import datetime,hashlib,json,os,subprocess,time,sys
D=Path(__file__).resolve().parent;P=json.loads((D/"plan.json").read_text());R=Path(P["root"]);W=D.parents[2]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,o):
 b=(json.dumps(o,indent=2)+"\n").encode()
 with path.open("xb") as f:f.write(b);f.flush();os.fsync(f.fileno())
def guard():
 for n,x in P["source_pins"].items():
  if hashlib.sha256((R/n).read_bytes()).hexdigest()!=x["sha256"]:raise RuntimeError("source changed: "+n)
env=os.environ.copy();env["CARGO_TARGET_DIR"]=str(W/"work/ci-follow/Hepta-Mac-authorized-read-root-integration-20261027-001/linux-mapping-target");env["CARGO_BUILD_JOBS"]="1";env["CARGO_NET_OFFLINE"]="true";env["CARGO_PROFILE_DEV_DEBUG"]="0";env["CARGO_PROFILE_TEST_DEBUG"]="0";env["CARGO_INCREMENTAL"]="0";env["RUSTUP_TOOLCHAIN"]="1.96.0"
save(D/"actual-durable-runner-start.json",{"started_utc":now(),"pid":os.getpid(),"birth":Path("/proc/self/stat").read_text(),"unit_invocation_id":os.environ.get("INVOCATION_ID"),"role":P["role"],"plan_sha256":hashlib.sha256((D/"plan.json").read_bytes()).hexdigest()})
results=[]
for step in P["steps"]:
 guard();O=D/step["name"];O.mkdir();t=time.monotonic_ns()
 with (O/"stdout.original").open("xb")as so,(O/"stderr.original").open("xb")as se:
  step_env=env.copy();step_env.update(step.get("environment",{}))
  child=subprocess.Popen(step["argv"],cwd=R/"codex-rs",env=step_env,stdout=so,stderr=se)
  try:birth=Path(f"/proc/{child.pid}/stat").read_text()
  except FileNotFoundError:birth=None
  start={"started_utc":now(),"pid":child.pid,"birth":birth,"command":step["argv"],"step":step,"same_resource_caps":True};save(O/"actual-start.json",start);rc=child.wait();so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
 r={**start,"finished_utc":now(),"actual_process_wait_exit":rc,"seconds":(time.monotonic_ns()-t)/1e9,"raw":{},"original_CI_closed":False,"merge_ready":False}
 for n in ["stdout.original","stderr.original"]:
  b=(O/n).read_bytes();r["raw"][n]={"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
 if rc == 0 and step.get("allowed_generated_file"):
  f=R/step["allowed_generated_file"];b=f.read_bytes();r["actual_generated_file"]={"path":step["allowed_generated_file"],"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
 save(O/"actual-terminal.json",r);results.append(r);guard()
 if rc!=0:break
save(D/"actual-durable-runner-terminal.json",{"finished_utc":now(),"steps":results,"actual_final_child_wait_exit":results[-1]["actual_process_wait_exit"],"original_full_CI_not_closed":True,"merge_ready":False});sys.exit(results[-1]["actual_process_wait_exit"])
