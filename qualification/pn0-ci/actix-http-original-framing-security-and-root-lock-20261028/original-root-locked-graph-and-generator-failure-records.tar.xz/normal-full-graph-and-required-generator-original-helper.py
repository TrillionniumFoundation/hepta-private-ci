from pathlib import Path
import datetime, hashlib, json, os, subprocess, time

D = Path(__file__).resolve().parent
H = D.parents[2] / 'work/root-hepta-integration-20261026'
P = D / 'existing-original-verified-inputs-and-required-Bazel-006'
prior = json.loads((P / 'actual-owner-terminal.json').read_text())
assert prior['actual_wait'] == 101 and prior['next_actual_missing'] == {'name': 'radix_trie', 'version': '0.2.1'}
assert not Path(f"/proc/{prior['pid']}").exists()
lock = H / 'codex-rs/Cargo.lock'
before = lock.read_bytes()
assert hashlib.sha256(before).hexdigest() == prior['root_lock_after_SHA256']
O = D / 'normal-full-locked-graph-after-input-repairs-and-required-Bazel-007'
O.mkdir(exist_ok=False)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(name, value):
    (O / name).write_text(json.dumps(value, indent=2) + '\n')

owner = {'started_utc': now(), 'pid': os.getpid(), 'proc_stat': Path('/proc/self/stat').read_text(), 'root_lock_SHA256': hashlib.sha256(before).hexdigest(), 'steps': [], 'scope': 'Actual original root online metadata failed on missing ruma input; that input and64exact normal-Cargo source inputs are now repaired and verified, plus retained quinn-udp restored with no redownload. The finite input batches stopped truthfully. Run the same original normal locked full all-features query once with normal Cargo transport, allowing it to fetch the remaining actual radix_trie and inputs. No test/ABI qualification, CI rerun, original resource/time cap change or expired SDK/PN1 allocation renewal. After actual query0 only, required original Bazel lock generation once.'}
save('actual-owner-start.json', owner)
env = os.environ.copy()
env['RUSTUP_TOOLCHAIN'] = '1.96.0'

def run(role, command):
    assert lock.read_bytes() == before
    step = {'role': role, 'started_utc': now(), 'command': command, 'cwd': str(H / 'codex-rs') if command[0] == 'cargo' else str(H)}
    owner['steps'].append(step)
    t = time.monotonic()
    with (O / (role + '.stdout.original')).open('xb') as out, (O / (role + '.stderr.original')).open('xb') as err:
        p = subprocess.Popen(command, cwd=step['cwd'], env=env, stdout=out, stderr=err)
        step.update(pid=p.pid, proc_stat=Path(f'/proc/{p.pid}/stat').read_text())
        save(role + '.start.json', step)
        save('actual-owner-current.json', owner)
        code = p.wait()
    step.update(actual_wait=code, seconds=time.monotonic() - t, finished_utc=now(), root_lock_byteexact=lock.read_bytes() == before)
    save(role + '.terminal.json', step)
    assert step['root_lock_byteexact']
    return code

started = time.monotonic()
code = 75
try:
    role = 'actual-same-normal-full-locked-metadata'
    code = run(role, ['cargo', 'metadata', '--manifest-path', str(H / 'codex-rs/Cargo.toml'), '--format-version', '1', '--locked', '--all-features'])
    if code == 0:
        data = json.loads((O / (role + '.stdout.original')).read_text())
        actix = [p for p in data['packages'] if p['name'] == 'actix-http']
        assert len(actix) == 1 and actix[0]['version'] == '3.12.1'
        owner.update(actual_full_locked_graph_query_succeeded=True, actual_metadata_packages=len(data['packages']), actual_actix_version='3.12.1')
        save('actual-full-locked-graph-query-admission.json', {'recorded_utc': now(), 'actual_wait': 0, 'metadata_raw': role + '.stdout.original', 'root_lock_SHA256': hashlib.sha256(before).hexdigest(), 'packages': len(data['packages']), 'actual_actix_version': '3.12.1', 'not_native_ABI_release_or_public_qualification': True})
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=H, text=True).strip() == 'ce3c769d5c8ed202c6fb0596d8d439d65d7167d1'
        assert subprocess.check_output(['git', 'status', '--short'], cwd=H, text=True) == ' M codex-rs/Cargo.lock\n'
        module = H / 'MODULE.bazel.lock'
        (O / 'MODULE.bazel.lock.before-required-generator.original').write_bytes(module.read_bytes())
        code = run('actual-required-just-bazel-lock-update', ['just', 'bazel-lock-update'])
        (O / 'MODULE.bazel.lock.after-required-generator.original').write_bytes(module.read_bytes())
        owner.update(required_Bazel_generator_actual_wait=code, module_lock_after_SHA256=hashlib.sha256(module.read_bytes()).hexdigest(), root_actual_status_after=subprocess.check_output(['git', 'status', '--short'], cwd=H, text=True))
except Exception as exc:
    code = 1
    owner['exception'] = repr(exc)
finally:
    owner.update(finished_utc=now(), actual_wait=code, seconds=time.monotonic() - started, root_lock_after_SHA256=hashlib.sha256(lock.read_bytes()).hexdigest(), task_complete=False, merge_ready=False)
    save('actual-owner-terminal.json', owner)
    print(json.dumps({'actual_wait': code, 'seconds': owner['seconds'], 'full_graph_query_admitted': owner.get('actual_full_locked_graph_query_succeeded', False), 'Bazel_generator_actual_wait': owner.get('required_Bazel_generator_actual_wait'), 'exception': owner.get('exception')}))
raise SystemExit(code)
