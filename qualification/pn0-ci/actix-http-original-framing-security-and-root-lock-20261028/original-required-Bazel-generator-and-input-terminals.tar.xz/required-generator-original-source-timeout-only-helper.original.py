from pathlib import Path
import base64, datetime, hashlib, json, os, re, subprocess, time

D = Path(__file__).resolve().parent
H = D.parents[2] / "work/root-hepta-integration-20261026"
P = D / "normal-full-locked-graph-after-input-repairs-and-required-Bazel-007"
prior = json.loads((P / "actual-owner-terminal.json").read_text())
assert prior["actual_wait"] == 37 and prior["required_Bazel_generator_actual_wait"] == 37
assert prior["actual_full_locked_graph_query_succeeded"] is True
assert not Path(f"/proc/{prior['pid']}").exists()
failure = (P / "actual-required-just-bazel-lock-update.stderr.original").read_bytes()
url = "https://github.com/v8/v8/archive/refs/tags/15.0.245.2.tar.gz"
assert url.encode() in failure and b"java.net.SocketTimeoutException: Read timed out" in failure
assert b"error: recipe `bazel-lock-update` failed on line 150 with exit code 37" in failure
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=H, text=True).strip() == "ce3c769d5c8ed202c6fb0596d8d439d65d7167d1"
assert subprocess.check_output(["git", "status", "--short"], cwd=H, text=True) == " M codex-rs/Cargo.lock\n"
lock = H / "codex-rs/Cargo.lock"
before = lock.read_bytes()
assert hashlib.sha256(before).hexdigest() == prior["root_lock_after_SHA256"]
module = H / "MODULE.bazel.lock"
module_before = module.read_bytes()
assert hashlib.sha256(module_before).hexdigest() == prior["module_lock_after_SHA256"]
source = (H / "MODULE.bazel").read_bytes()
block = source[source.index(b'bazel_dep(name = "v8", version = "15.0.245.2")'):]
integrity = re.search(rb'integrity = "sha256-([^"]+)"', block)[1]
assert base64.b64decode(integrity).hex() == "164f3d3e0a8b4c02a386d3a88d1b1133d37e5c20be0239fecdcdde414a4340d5"
O = D / "required-Bazel-original-only-after-actual-v8-source-socket-timeout-008"
O.mkdir(exist_ok=False)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(name, value):
    (O / name).write_text(json.dumps(value, indent=2) + "\n")

owner = {
    "started_utc": now(), "pid": os.getpid(), "proc_stat": Path("/proc/self/stat").read_text(),
    "prior_actual_generator_wait": 37,
    "prior_generator_seconds": prior["steps"][-1]["seconds"],
    "prior_owner_actual_total_seconds": prior["seconds"],
    "prior_full_graph_actual_wait": 0,
    "actual_transient_environment_error": "Original pinned V8 source HTTP download java.net.SocketTimeoutException: Read timed out before dependency lock generation; source unchanged.",
    "original_pinned_V8_source_URL": url,
    "original_pinned_V8_source_SHA256": base64.b64decode(integrity).hex(),
    "root_lock_SHA256": hashlib.sha256(before).hexdigest(),
    "module_source_SHA256": hashlib.sha256(source).hexdigest(),
    "steps": [],
    "scope": "One retry of only original required just bazel-lock-update after explicit original HTTP socket timeout. Same source, command, toolchain, normal transport defaults and original development resource caps. No metadata/native test rerun, CI dispatch/cancel, workflow/assertion/timeout change or expired SDK/supervisor/PN1/model allocation renewal. All previous actual failures and elapsed costs retained."
}
save("actual-owner-start.json", owner)
(P / "MODULE.bazel.lock.after-required-generator.original").read_bytes()
(O / "MODULE.bazel.lock.before-required-generator.original").write_bytes(module_before)
env = os.environ.copy()
env["RUSTUP_TOOLCHAIN"] = "1.96.0"
started = time.monotonic()
code = 75
try:
    role = "actual-original-required-just-bazel-lock-update-after-explicit-source-timeout"
    step = {"role": role, "command": ["just", "bazel-lock-update"], "cwd": str(H), "started_utc": now()}
    owner["steps"].append(step)
    t = time.monotonic()
    with (O / (role + ".stdout.original")).open("xb") as out, (O / (role + ".stderr.original")).open("xb") as err:
        p = subprocess.Popen(step["command"], cwd=H, env=env, stdout=out, stderr=err)
        step.update(pid=p.pid, proc_stat=Path(f"/proc/{p.pid}/stat").read_text())
        save(role + ".start.json", step)
        save("actual-owner-current.json", owner)
        code = p.wait()
    step.update(actual_wait=code, seconds=time.monotonic()-t, finished_utc=now(), root_lock_byteexact=lock.read_bytes()==before)
    save(role + ".terminal.json", step)
    assert step["root_lock_byteexact"]
    (O / "MODULE.bazel.lock.after-required-generator.original").write_bytes(module.read_bytes())
    owner.update(required_Bazel_generator_actual_wait=code, module_lock_after_SHA256=hashlib.sha256(module.read_bytes()).hexdigest(), root_actual_status_after=subprocess.check_output(["git", "status", "--short"], cwd=H, text=True))
except Exception as exc:
    code = 1
    owner["exception"] = repr(exc)
finally:
    owner.update(finished_utc=now(), actual_wait=code, seconds=time.monotonic()-started, root_lock_after_SHA256=hashlib.sha256(lock.read_bytes()).hexdigest(), task_complete=False, merge_ready=False)
    save("actual-owner-terminal.json", owner)
    print(json.dumps({"actual_wait":code, "seconds":owner["seconds"], "Bazel_generator_actual_wait":owner.get("required_Bazel_generator_actual_wait"), "exception":owner.get("exception")}))
raise SystemExit(code)
