#!/usr/bin/python3
"""One bounded, no-target-execution Bazel query/analysis ownership window."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1] / "root-hepta-integration-20261026"
FROZEN = HERE.parent / "Hepta-advisory-aws-p256-full-source-candidate-20261026-001"
BAZEL = Path("/home/qian-qi/.local/bin/bazel")
EXPECTED_HEAD = "9d8be55e3763bfaba78d6698c3f31bbd79069d3e"
EXPECTED_LOCK = "6a11a58d8e6cd3b08afceac5cc1f4d0e9b1e718597b6d6e7ba78f1af1d69d323"
EXPECTED_IGNORE = "27dedefd96f29ddba7b0c3a505b6af49ef4468ab2573f1a3343933027377a3e9"
CPU = 200
MEMORY = 8 * 1024**3
MAX_WHOLE = 600.0
COMMAND_DEADLINE = 565.0
MAX_LOG_BYTES = 64 * 1024**2
START = time.monotonic()
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
OBS = HERE / "observed"
OBS.mkdir(exist_ok=False)
OUTPUT = HERE / "output-base"
assert not OUTPUT.exists(), "unique analysis output-base already exists"
assert not (HERE / "result.json").exists(), "owner already used"
STEPS = []
OWNED = []
PINS = {}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def write(name, value):
    data = json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    path = HERE / name
    with path.open("x") as stream:
        stream.write(data)
    return digest(path)


def source_check():
    for name, expected in PINS.items():
        actual = digest(ROOT / name)
        assert (actual["bytes"], actual["sha256"]) == expected, ("source drift", name)


def birth(pid):
    raw = Path(f"/proc/{pid}/stat").read_text()
    tail = raw[raw.rindex(")") + 2:].split()
    return int(tail[19])


def stop_owned(child, initial_birth):
    if child.poll() is not None:
        return
    assert birth(child.pid) == initial_birth and os.getpgid(child.pid) == child.pid
    os.killpg(child.pid, signal.SIGTERM)
    try:
        child.wait(timeout=5)
    except subprocess.TimeoutExpired:
        assert birth(child.pid) == initial_birth and os.getpgid(child.pid) == child.pid
        os.killpg(child.pid, signal.SIGKILL)
        child.wait(timeout=5)


def execute(name, argv, cap=180):
    source_check()
    left = COMMAND_DEADLINE - (time.monotonic() - START)
    assert left > 5, "analysis command window exhausted; no reset"
    timeout = min(float(cap), left)
    stdout = OBS / f"{name}.stdout"
    stderr = OBS / f"{name}.stderr"
    started = time.monotonic()
    child = None
    b = None
    timed_out = False
    over_log = False
    try:
        with stdout.open("xb") as out, stderr.open("xb") as err:
            child = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdin=subprocess.DEVNULL,
                                     stdout=out, stderr=err, start_new_session=True)
            OWNED.append(child)
            b = birth(child.pid)
            while child.poll() is None:
                if time.monotonic() - started >= timeout:
                    timed_out = True
                    stop_owned(child, b)
                    break
                if stdout.stat().st_size > MAX_LOG_BYTES or stderr.stat().st_size > MAX_LOG_BYTES:
                    over_log = True
                    stop_owned(child, b)
                    break
                time.sleep(0.1)
            code = child.wait(timeout=5)
    finally:
        if child is not None and child.poll() is None and b is not None:
            stop_owned(child, b)
    item = {"name": name, "argv": argv, "cwd": str(ROOT), "timeout_seconds": timeout,
            "pid": child.pid if child else None, "birth": b,
            "returncode": code, "waited_reaped": child.poll() is not None,
            "elapsed_seconds": time.monotonic() - started,
            "timed_out": timed_out, "log_limit_exceeded": over_log,
            "stdout": digest(stdout), "stderr": digest(stderr)}
    STEPS.append(item)
    write(f"step-{len(STEPS):02d}-{name}.json", item)
    source_check()
    assert code == 0 and not timed_out and not over_log, ("command failed", name, code)
    return stdout.read_text()


BASE = [str(BAZEL), "--batch", "--host_jvm_args=-Xmx4g", f"--output_base={OUTPUT}"]


def query(name, expression, output="build", cap=180):
    return execute(name, BASE + ["query", "--lockfile_mode=error", f"--output={output}", expression], cap)


def label(value):
    assert re.fullmatch(r"(?:@@?[A-Za-z0-9_+~.\-]+)?//[A-Za-z0-9_+~./\-]*:[A-Za-z0-9_+~./\-]+", value), ("untrusted/unsupported label", value)
    return value


def relative_label(value, parent):
    if value.startswith(":"):
        value = parent.rsplit(":", 1)[0] + value
    return label(value)


def location_files(raw):
    found = []
    for line in raw.splitlines():
        match = re.match(r"(.+?):\d+:\d+: (?:.*?)(@@?[^ ]+//[^ ]+|//[^ ]+)$", line)
        if match:
            path = Path(match.group(1)).resolve()
            assert path.is_relative_to(OUTPUT.resolve()), ("location outside owned output base", str(path))
            assert path.name in {"BUILD", "BUILD.bazel"}
            found.append((path, match.group(2)))
    assert found, "no actual returned BUILD paths"
    return found


def snapshot(path, name):
    data = path.read_bytes()
    target = OBS / name
    target.write_bytes(data)
    return {"source": digest(path), "snapshot": digest(target)}


def main():
    inv = json.loads((FROZEN / "final-source-inventory.json").read_text())
    for member in inv["members"]:
        PINS[member["path"]] = (member["size"], member["sha256"])
    PINS["MODULE.bazel.lock"] = (1718438, EXPECTED_LOCK)
    PINS[".bazelignore"] = (652, EXPECTED_IGNORE)
    for name in ["AGENTS.md", "defs.bzl", "MODULE.bazel", "codex-rs/aws-auth/BUILD.bazel", "codex-rs/deny.toml"]:
        p = digest(ROOT / name)
        PINS[name] = (p["bytes"], p["sha256"])
    source_check()
    head = execute("git-head", ["git", "rev-parse", "HEAD"], 10).strip()
    assert head == EXPECTED_HEAD, head
    old_ignore = execute("base-bazelignore", ["git", "show", "HEAD:.bazelignore"], 10)
    added = "codex-rs/third_party/aws-config-1.8.12\n"
    assert (ROOT / ".bazelignore").read_text().replace(added, "", 1) == old_ignore
    metadata = json.loads((FROZEN / "cargo-metadata.original.json").read_text())
    members = {p["manifest_path"] for p in metadata["packages"] if p["id"] in metadata["workspace_members"]}
    assert not any("/third_party/aws-config-1.8.12/" in p for p in members)
    write("admission.json", {"utc": now(), "root": str(ROOT), "head": head,
        "source_pins": PINS, "whole_seconds": MAX_WHOLE, "command_deadline": COMMAND_DEADLINE,
        "cpu_percent": CPU, "memory_max_bytes": MEMORY, "no_Rust_target_execution": True,
        "batch_only": True, "independent_output_base": str(OUTPUT),
        "no_original_workspace_member_newly_ignored": True,
        "handwritten_vendor_BUILD_not_consumer_DEP_DATA": True})
    current = "@crates//:aws-config"
    chain = []
    for hop in range(5):
        raw = query(f"aws-alias-{hop}", current)
        chain.append({"label": current, "output": digest(OBS / f"aws-alias-{hop}.stdout")})
        actual = re.search(r'^\s*actual = "([^"]+)"', raw, re.MULTILINE)
        if actual:
            current = relative_label(actual.group(1), current)
            continue
        assert "rust_library(" in raw, "hub did not reach actual Rust library"
        break
    else:
        raise AssertionError("too many aliases")
    final_label = label(current)
    raw_locations = query("aws-library-location", final_label, "location", 60)
    locations = location_files(raw_locations)
    package = locations[0][0].parent
    generated = snapshot(locations[0][0], "generated-aws-BUILD.bazel")
    package_names = sorted(p.name for p in package.iterdir())
    write("actual-aws-package-names.json", {"path": str(package), "entries": package_names})
    assert "cargo_toml_env_vars.env" in package_names, "generated package env not present"
    env = snapshot(package / "cargo_toml_env_vars.env", "generated-aws-cargo-env.env")
    assert "CARGO_PKG_VERSION=1.8.12" in (package / "cargo_toml_env_vars.env").read_text()
    docs = query("aws-compile-data", f"labels(compile_data, {final_label})", "label", 60)
    doc_labels = [x for x in docs.splitlines() if x.endswith("//:src/profile/location_of_profile_files.md")]
    assert doc_labels, "actual generated compile_data omitted required profile markdown"
    doc = snapshot(package / "src/profile/location_of_profile_files.md", "generated-aws-profile.md")
    query("consumer-label", "//codex-rs/aws-auth:aws-auth", "label", 60)
    expression = 'mnemonic("Rustc", deps(//codex-rs/aws-auth:aws-auth))'
    raw_actions = execute("normal-consumer-aquery", BASE + ["aquery", "--lockfile_mode=error",
        "--output=jsonproto", "--include_commandline", "--include_param_files",
        "--include_artifacts=false", f"--symlink_prefix={HERE / 'analysis-links'}/", expression], 300)
    actions = json.loads(raw_actions)
    targets = {str(x["id"]): x["label"] for x in actions.get("targets", [])}
    names = {"aws_config", "codex_aws_auth", "p256", "elliptic_curve", "crypto_bigint", "ctutils"}
    selected = []
    for action in actions.get("actions", []):
        argv = action.get("arguments", [])
        if "--crate-name" not in argv:
            continue
        crate = argv[argv.index("--crate-name") + 1]
        if crate in names:
            selected.append({"crate": crate, "label": targets.get(str(action.get("targetId"))),
                             "arguments": argv, "environmentVariables": action.get("environmentVariables", [])})
    assert names <= {x["crate"] for x in selected}, "normal consumer analysis missing required real crate actions"
    aws_actions = [x for x in selected if x["crate"] == "aws_config"]
    expected_features = {"credentials-login", "credentials-process", "default", "default-https-client", "rt-tokio", "sso"}
    for action in aws_actions:
        argv = action["arguments"]
        cfgs = {argv[i + 1] for i, arg in enumerate(argv[:-1]) if arg == "--cfg"}
        assert {f'feature="{f}"' for f in expected_features} <= cfgs, "normal action lost AWS feature"
    write("actual-selected-actions.json", {"normal_consumer": "//codex-rs/aws-auth:aws-auth",
        "aws_alias_chain": chain, "actual_aws_library": final_label,
        "generated_BUILD": generated, "generated_env": env, "compile_data_doc": doc,
        "features_verified_in_real_analysis": sorted(expected_features), "actions": selected})
    actual_labels = sorted({label(x["label"]) for x in selected if x["crate"] != "codex_aws_auth"})
    chain_locations = query("selected-chain-locations", "set(" + " ".join(actual_labels) + ")", "location", 90)
    manifests = []
    for index, (build_path, returned_label) in enumerate(location_files(chain_locations)):
        root = build_path.parent
        assert (root / "Cargo.toml").is_file()
        manifests.append({"label": returned_label,
            "BUILD": snapshot(build_path, f"chain-{index:02d}-BUILD.bazel"),
            "Cargo.toml": snapshot(root / "Cargo.toml", f"chain-{index:02d}-Cargo.toml")})
    write("actual-selected-chain-manifests.json", manifests)
    source_check()
    return {"conclusion": "SOURCE_MATERIALIZATION_AND_NORMAL_CONSUMER_ANALYSIS_OBSERVED",
            "normal_consumer_analysis": True, "actual_generated_AWS_features": True,
            "actual_generated_version_env": True, "actual_profile_compile_data": True,
            "Rust_compile_or_test_execution": False, "platform_qualification": False,
            "seven_DPoP_tests": False, "merge_ready": False}


result = {"started_utc": now(), "qualified_compile_or_tests": False}
code = 0
try:
    result.update(main())
except BaseException as error:
    result.update(conclusion="FAIL_OR_INCOMPLETE", error_type=type(error).__name__, error=str(error))
    code = 1
finally:
    result.update(ended_utc=now(), owner_elapsed_seconds=time.monotonic() - START,
                  steps=STEPS, all_started_direct_children_reaped=all(x.poll() is not None for x in OWNED),
                  root_source_mutation_authorized=False, Rust_target_execution_authorized=False)
    if result["owner_elapsed_seconds"] > MAX_WHOLE:
        result["whole_deadline_exceeded"] = True
        code = 1
    write("result.json", result)
sys.exit(code)
