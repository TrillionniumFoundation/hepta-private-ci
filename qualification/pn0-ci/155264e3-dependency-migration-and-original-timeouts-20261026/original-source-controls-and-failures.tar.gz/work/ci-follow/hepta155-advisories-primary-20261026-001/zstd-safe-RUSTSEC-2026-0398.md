```toml
[advisory]
id = "RUSTSEC-2026-0398"
package = "zstd-safe"
date = "2026-10-16"
url = "https://github.com/gyscos/zstd-rs/commit/80506be743fae2ed0c2fe8b21c374c6a2eab0be7"
references = ["https://github.com/gyscos/zstd-rs/pull/384"]
categories = ["memory-exposure", "memory-corruption"]
keywords = ["seekable", "out-of-bounds"]

[affected]

[affected.functions]
"zstd_safe::seekable::Seekable::decompress" = [">= 7.2.2, < 8.2.0"]
"zstd_safe::seekable::AdvancedSeekable::decompress" = [">= 7.2.2, < 8.2.0"]

[versions]
patched = [">= 8.2.0"]
unaffected = ["< 7.2.2"]
```

# `Seekable::decompress` sets a `Vec` length beyond its capacity for offsets past the end

`ZSTD_seekable_decompress` shortens the requested length to the end of the
data without checking that the offset is before it. For an offset past the
end, it returns a wrapped-around length without writing anything, and
`Seekable::decompress` passed that length to `Vec::set_len`.

With the `seekable` feature, whoever supplies the archive, or chooses the
offset, can leave the caller's `Vec<u8>` with a length far beyond its
capacity. Reading it then discloses neighbouring heap memory, and appending
to it corrupts memory. Offsets near `u64::MAX` can also hang the call.

The flaw was corrected by clamping requests to the end of the data, and by
checking every count reported by the C library against the buffer capacity.
