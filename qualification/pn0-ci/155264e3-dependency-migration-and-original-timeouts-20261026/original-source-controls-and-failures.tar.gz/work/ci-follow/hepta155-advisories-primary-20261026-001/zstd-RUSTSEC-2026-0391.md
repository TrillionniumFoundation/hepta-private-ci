```toml
[advisory]
id = "RUSTSEC-2026-0391"
package = "zstd"
date = "2026-10-16"
url = "https://github.com/gyscos/zstd-rs/commit/74ace2dcdca62a2ce0f034895d6079458311e003"
references = ["https://github.com/gyscos/zstd-rs/pull/384"]
categories = ["memory-exposure"]
keywords = ["information-leak", "context-reuse"]

[affected]

[affected.functions]
"zstd::stream::raw::Encoder::with_context" = [">= 0.13.2, < 0.14.3"]
"zstd::stream::raw::Decoder::with_context" = [">= 0.13.2, < 0.14.3"]

[versions]
patched = [">= 0.14.3"]
unaffected = ["< 0.13.2"]
```

# Data from an abandoned stream leaks into the next stream on a reused context

The `with_context` constructors of the stream encoders and decoders used the
borrowed context as it was. When a stream was abandoned on a context, for
example an encoder dropped before `finish()` after an error, whatever it
left there was carried into the next stream: the input buffered by the
previous encoder (up to 128 KiB, or all of it with `zstdmt`) became the
start of the next frame, and a decoder returned undelivered output of the
previous stream.

An application reusing one context for data that must stay separate, such
as different users' requests, could disclose one user's plaintext to
another. Whoever supplies the data can cause the abandonment with invalid
input.

The flaw was corrected by resetting the context's session in
`with_context`.
