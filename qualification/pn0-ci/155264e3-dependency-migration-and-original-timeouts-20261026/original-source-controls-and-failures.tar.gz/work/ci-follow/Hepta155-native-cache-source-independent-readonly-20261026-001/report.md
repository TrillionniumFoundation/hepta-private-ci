# Hepta published155 native/cache source audit — read only

审计对象：`155264e3b5d3dcdafa244cd0c31c336ab25a207f`。所有下列源码行号均来自本目录 `source155/` 的 exact Git object 字节，未读 dirty worktree 作为结论依据。未运行仓库程序、build、test、fmt、aquery、dispatch、cancel、push、ROG 或 SSH；未修改源码、工作流、保护规则、CPU/limits。唯一写入是本审计收据目录（曾误在调用者目录生成一个空输入 SHA 收据，已删除，不涉及仓库源码）。

## Source binding

- 本地 exact155 tree：`0b9dede8b0d6812bd4c6a95d9572e886468c5c7f`，见 `evidence/local155-object.txt`。
- 原日志实际 checkout：`5c78e40b510c35cbeaa4849790516997c976f1b4`，五份原日志的 Uses/HEAD 行保存在 `evidence/cache-and-checkout-original-log-lines.txt`。
- 已保存官方 GitHub commit metadata 显示 actual merge 5c78 的 tree 与 head155 的 tree 均为上述 `0b9d…`，merge parents 为 `[c38e7727220f32c7410f59083c5ea7878bbae078,155264e3b5d3dcdafa244cd0c31c336ab25a207f]`。本次复用而非重新获取，见 `evidence/hepta-preview-commit.original.json`、`evidence/hepta-head-commit.original.json`；本地没有 5c78 commit object，未 fetch。
- Bazel 与 SDK workflow 的 exact155 Git 字节分别与前次独立官方 raw155 字节 SHA-256 一致：`d660f6c04dd5922567c717b8703aca60992f7f3bf037e8607c972b3cb89c2f31`、`2ac4937a15b5589d6c075df0f521a4ea46d0727f2cce06a9a3bd25a0358369a3`。
- 41 份完整源码的 Git blob IDs：`source155-git-blobs.tsv`；各文件完整 SHA-256：`source155.sha256`。该 source manifest SHA-256 为 `c067d30f4de3612d40606e3eed569839ef10fcae1ec12750917741520b2141e9`，Git blob manifest SHA-256 为 `b7025431e18e49b1cf66d876871a6ab2d80573316d2eea9d1e3be5df38417b72`。

## Confirmed source/interface findings

### F1 — SDK repository-cache restore is absent; save reads an undeclared output

`155:.github/workflows/sdk.yml:76-80` calls `setup-bazel-ci`, not `prepare-bazel-ci`. `155:.github/actions/setup-bazel-ci/action.yml:8-10` declares only `repository-cache-path`; its full steps contain no actions/cache restore. `155:.github/workflows/sdk.yml:184-190` nevertheless saves the repository cache and tests `steps.setup_bazel.outputs.cache-hit`, which that action never declares. The original SDK log has setup-bazel inputs `disk-cache:false`, `repository-cache:false` at lines 645/647 and no Bazel repository-restore step. This is a provable missing download-cache restore interface, not a proved native action-cache invalidation.

The current SDK save namespace is exactly:

`bazel-cache-x86_64-unknown-linux-gnu-${hashFiles('MODULE.bazel', 'codex-rs/Cargo.lock', 'codex-rs/Cargo.toml')}`.

It differs from `prepare-bazel-ci`'s `bazel-cache-${CACHE_SCOPE}-${TARGET}-${CACHE_HASH}` (`155:.github/actions/prepare-bazel-ci/action.yml:47-70`). Substituting prepare without an explicit namespace migration cannot be represented as restoring prior SDK keys.

### F2 — Four repository download restores miss; no persistent compiled-output cache is configured

All five original jobs report no BuildBuddy key (see extracted original line evidence). `155:.github/scripts/run_bazel_with_buildbuddy.py:117-124,140-174,245-247` therefore selects the local fallback and removes `ci-linux` from the invocation. `155:.bazelrc:8-12` distinguishes disk, repository-contents and repository-download caches. Since removing `ci-linux` removes its `ci-bazel`/`ci` expansion, the `ci` disk-cache-disable at line 105 must not be used to claim that these local jobs disabled Bazel disk caching. The observed local progress does say `disk-cache, linux-sandbox`. The setup action input `disk-cache:false` is a separate fact: setup-bazel did not persist that disk cache through its caching feature.

The repository restore path is `$CI_BUILD_ROOT/bazel-repository-cache` (`155:.github/actions/setup-ci/action.yml:45-69`); prepare restores exactly that path (`155:.github/actions/prepare-bazel-ci/action.yml:62-70`). It does not restore `.cache/bazel-disk-cache` or the build output base. `155:.github/actions/setup-bazel-ci/action.yml:18-27` supplies bazelisk/output-base only. Source and original setup action inputs establish no persistent compiled-output cache across these five jobs. This explains lack of configured cross-job output reuse; it does not establish a wrong action digest or that every printed compile progress line executed a fresh compile.

Actual original repository-cache keys (the shared hash suffix is `ace69f841c3b05c5f1450f4d2a9396f35135397c9f55ea24433d33b04a543608`):

| Original job | Exact restore namespace before the hash | Evidence |
|---|---|---|
| 121613023021 GNU clippy | `bazel-cache-bazel-clippy-x86_64-unknown-linux-gnu-` | original log line 656: miss |
| 121613023099 GNU test | `bazel-cache-bazel-test-x86_64-unknown-linux-gnu-` | original log line 656: miss |
| 121613023048 musl-named test | `bazel-cache-bazel-test-x86_64-unknown-linux-musl-` | original log line 656: miss |
| 121613022900 release verification | `bazel-cache-bazel-verify-release-build-x86_64-unknown-linux-gnu-` | original log line 685: miss |
| 121613022191 SDK | no restore step | source F1; original log |

These keys are archive keys for downloaded dependencies, not native action keys. Omitting `.bazelrc`, patches or features from this download-cache archive key is not itself a demonstrated cache correctness defect. Repository-rule hashes still select and verify requested downloaded bytes. No broad new output cache is proposed here.

### F3 — Linux matrix target names are not bound to target-platform flags

`155:.github/workflows/bazel.yml:40-43` declares GNU/musl rows, but the shared test command at lines 83-112 supplies neither `matrix.target` nor any `--platforms` flag. Prepare uses its target as a cache name (`155:.github/actions/prepare-bazel-ci/action.yml:28,52`); setup-bazel-ci only declares that input. No input-to-toolchain mapping exists there. The wrapper does not synthesize a Linux target from that matrix label. The keyed `ci-linux` configuration uses `//:rbe` (`155:.bazelrc:180-182`), and `155:rbe.bzl:14-21` fixes that platform to `gnu.2.28`; the keyless path removes `ci-linux`. `155:BUILD.bazel:5-15` likewise declares the local Linux platform as GNU-compatible. The musl-named original job prints `bazel-out/local_linux-fastbuild/...` paths, excerpted separately.

Thus the job name and cache suffix do not prove musl compilation coverage. This is a source binding concern, not permission to delete that job, reduce features/tests, or assert identical GNU/musl action keys. Exact effective native/Rust target action digests remain UNKNOWN in this read-only audit.

## Native source/feature contract retained

- `155:MODULE.bazel:156-187` pins `rules_rs 0.0.96`, applies explicit build-script-deps and Windows patches, and patches reexported rules_rust. The explicit build-script-deps patch carries its annotation through (`155:patches/rules_rs_build_script_deps_annotation.patch:7-58`). No dependency-removal candidate is justified by this source.
- `155:MODULE.bazel:492-523` wires the v8 build script to a Bazel archive and binding, with `v8_enable_sandbox` on all listed triples. `155:codex-rs/code-mode-runtime/Cargo.toml:24` also requests the sandbox. `155:.bazelrc:214-217` enables pointer compression and sandbox.
- `155:codex-rs/Cargo.lock:17288-17302` pins v8 crate `150.4.0` and checksum `42a978ff11f15b24e5c05a7123cf2b68f41e763546699781a924ef4e2cf43a49`; `155:MODULE.bazel:584-605` pins V8 source `15.0.245.2`, integrity, all three V8 patches, and the same v8 crate checksum. `155:MODULE.bazel:609-627` pins libcxx/libcxxabi/llvm-libc commits.
- `155:third_party/v8/BUILD.bazel:69-100,188-205,274-296` selects source-built Linux archive targets through `core_lib_icu` and target binding selectors. `155:patches/v8_bazel_rules.patch:108-155` distinguishes exec and target snapshot tools; Linux uses the exec tool and Windows uses the target tool. Observed `[for tool]`/unmarked source builds are not enough to diagnose erroneous duplicate native builds; actual action digest/inputs/configuration comparison is missing.
- Feature-specific fixture variants are explicit test-only targets, e.g. `155:codex-rs/hepta-agentd/BUILD.bazel:22-59,61-109`; the macro creates a separate test library only when dependency replacements or test-only features require it (`155:defs.bzl:348-365`). No source evidence shows an accidentally redundant fixture variant or justifies removing coverage. Original common printed source paths do not prove duplicate action keys.
- The release verification explicitly keeps fastbuild and disables Rust debug assertions (`155:.github/workflows/bazel.yml:471-485`). Cargo release LTO settings must not be treated as its active Bazel compilation mode. Conversely the keyless removal of ci-linux drops its ordinary CI expansion, so exact effective Rust flags need actual action evidence before estimating any saving.

## Only source-only candidate — NOT APPLIED; runtime effect UNKNOWN

For F1 only, add an explicit `actions/cache/restore` step immediately after the SDK setup step. Reuse the already pinned `actions/cache/restore@668228422ae6a00e4ad889ee87cd7109ec5666a7`, the exact existing SDK repository-cache path, the exact existing SDK save key expression, and restore prefix `bazel-cache-x86_64-unknown-linux-gnu-`. Give it a distinct ID and make the existing save condition read that restore step's `outputs.cache-hit`. Preserve non-fatal cache service handling and the current `always() && !cancelled()` save policy.

Do not switch to a different prepare namespace, claim an unobserved hit, or reuse source/cache artifacts from another trust boundary. Do not change V8/rules_rs/LLVM versions, source patches, sandbox/pointer compression, ABI selectors, bindings, dependency hashes/integrities, tests/fixtures, CPU concurrency or 60-minute limits. This candidate corrects a download-cache interface only; it cannot be presented as resolving the observed 57–58 minutes of post-analysis native work. No candidate was applied or run.

## Unknowns and excluded claims

| Question | Finding |
|---|---|
| Actual Bazel action digest invalidation, identical-key execution twice, cache corruption | UNKNOWN: no original action digest/command/input comparison obtained |
| Unnecessary V8 host/target compile duplication | UNKNOWN: printed paths/configuration markers alone are insufficient |
| CPU oversubscription from `--jobs=30` | UNKNOWN: queue size is not active CPU count; parent audit owns observed running counts |
| Fixture or test hang explains the native-heavy budget | Not established; no deletion or skip proposal |
| Existing prebuilt V8 is fully equivalent to source + features + patches | UNKNOWN; no substitution proposed |
| SDK cache interface fix meets 60 minutes | UNKNOWN; no runtime validation or speedup claim |

## Official Bazel primary documentation checked

The [repository-cache documentation](https://bazel.build/run/build#the-repository-cache) describes downloaded-file reuse and SHA-256 selection. The [remote/disk-cache documentation](https://bazel.build/remote/caching) describes cached action outputs and action/CAS metadata. These separate mechanisms support the boundary in F2. The [build configuration section](https://bazel.build/run/build#build-configurations-and-cross-compilation) explains why a library shared by a build tool and target may require both execution and target variants. Checked via web tool on 2026-10-26; summarized evidence is in `evidence/official-bazel-docs-verification.md`. The oversized command-line-reference request failed and is not used as evidence.
