# Official primary documentation verification

Accessed with web tool, 2026-10-26. This is a derived verification note, not a raw page capture.

- https://bazel.build/run/build — retrieved 415 lines. Repository-cache section lines 243-245: downloaded files are reused using known SHA-256 requests. Configuration section lines 315-321: execution tools and requested targets can require different builds of a shared library. These support separate download caching and expected host/target variants; they do not prove equivalence or redundancy for this Hepta run.
- https://bazel.build/remote/caching — retrieved 361 lines. Lines 95-109 distinguish cached action outputs, action metadata and CAS. Lines 289-295 describe a filesystem disk cache for built artifacts. This supports distinguishing action/output reuse from repository downloads.
- https://bazel.build/reference/command-line-reference#flag--repository_cache — retrieval failed because page exceeded tool size limit. Not used.

No documentation was used to claim a performance improvement, actual action-key equality, or prebuilt/source V8 equivalence.
