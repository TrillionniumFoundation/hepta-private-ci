import os,pathlib,subprocess,time,json,signal,hashlib
BASE=pathlib.Path('/home/qian-qi/Documents/Codex/2026-10-25/github-trillionnium-chain-https-github-com')
ROOT=BASE/'work/root-hepta-integration-20261026'
D=BASE/'work/ci-follow/Hepta-root-advisory-dependency-source-admission-20261026-001/lock-update'
start=time.monotonic();names=['codex-rs/Cargo.toml','codex-rs/Cargo.lock','MODULE.bazel.lock'];before={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names}
cmd=['/home/qian-qi/.cargo/bin/just','bazel-lock-update'];env={**os.environ,'PATH':str(D/'bin')+os.pathsep+os.environ['PATH']}
with (D/'stdout.log').open('xb',buffering=0) as out,(D/'stderr.log').open('xb',buffering=0) as err:
 p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
 (D/'started.json').write_text(json.dumps({'command':cmd,'pid':p.pid,'batch_mode_no_daemon':True,'before':before,'child_seconds':480,'operator_seconds':540,'not_compiler_or_crypto_qualification':True})+'\n')
 timed=False;violation=None
 while p.poll() is None:
  if time.monotonic()-start>=480:timed=True;violation='deadline'
  if (D/'stdout.log').stat().st_size+(D/'stderr.log').stat().st_size>8*1024*1024:violation='log cap'
  if violation:os.killpg(p.pid,signal.SIGKILL);break
  time.sleep(.2)
 code=p.wait()
after={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names}
assert before['codex-rs/Cargo.toml']==after['codex-rs/Cargo.toml'] and before['codex-rs/Cargo.lock']==after['codex-rs/Cargo.lock']
v={'command':cmd,'exit_code':code,'timed_out':timed,'violation':violation,'seconds':time.monotonic()-start,'child_reaped':True,'batch_mode_no_daemon':True,'before':before,'after':after,'files':{},'typecheck_or_crypto_tests':False,'full_cargo_deny':False,'merge_ready':False}
for name in ['stdout.log','stderr.log']:
 b=(D/name).read_bytes();v['files'][name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(D/'result.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True);raise SystemExit(code if not violation else 1)
