from pathlib import Path
import json,re,collections,datetime,hashlib
D=Path("work/ci-follow/Hepta155-five-original-timeout-phase-readonly-20261026-001");P=Path('work/ci-follow/Hepta-published155-cancellation-concurrency-readonly-20261026T1729Z-001')
jobs=json.loads((P/'retained-blocking-attempt1-jobs.original.json').read_text())['jobs']
ids=[121613023021,121613023099,121613023048,121613022900,121613022191]
def dt(v):return datetime.datetime.fromisoformat(v.replace('Z','+00:00'))
def sec(a,b):return round((dt(b)-dt(a)).total_seconds(),6)
def event(v):return {'line':v['line'],'utc':v['utc'],'text':v['text']}
allrows=[];nativepaths={}
for ident in ids:
 p=P/f'job{ident}.full-original.log';b=p.read_bytes();lines=b.decode().splitlines();parsed=[]
 for num,line in enumerate(lines,1):
  line=line.lstrip('\ufeff');m=re.match(r'^(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z) (.*)$',line)
  if m:parsed.append({'line':num,'utc':m[1],'text':re.sub(r'\x1b\[[0-9;]*m','',m[2])})
 job=next(x for x in jobs if x['id']==ident)
 steps=[]
 for s in job['steps']:
  v={k:s.get(k)for k in ['name','number','conclusion','started_at','completed_at']}
  v['metadata_wall_seconds']=sec(v['started_at'],v['completed_at'])if v['started_at']and v['completed_at']else None;steps.append(v)
 active=next(s for s in steps if s['conclusion']=='cancelled')
 groups={'analysis':[],'analysis_complete':[],'native_C_or_CXX_progress':[],'explicit_v8_source_progress':[],'Rust_compile_progress':[],'tests_counter':[],'test_target_progress':[],'cache_restore_miss':[],'Bazel_repository_loading':[],'BuildBuddy_unavailable':[],'cancel':[]}
 pathobs=collections.defaultdict(list)
 for v in parsed:
  t=v['text'];progress=bool(re.match(r'^\[[\d,]+ / [\d,]+\]',t))
  if t.startswith('Analyzing:'):groups['analysis'].append(v)
  if 'INFO: Analyzed 'in t:groups['analysis_complete'].append(v)
  if 'Computing main repo mapping:'in t or t.startswith('Loading:')or 'Downloading 'in t:groups['Bazel_repository_loading'].append(v)
  if 'Cache not found for input keys:'in t:groups['cache_restore_miss'].append(v)
  if ('BuildBuddy key unavailable;'in t or 'BuildBuddy API key is not available;'in t):groups['BuildBuddy_unavailable'].append(v)
  if '##[error]The operation was canceled.'in t:groups['cancel'].append(v)
  if progress:
   n=re.search(r'\bCompiling (?!Rust\b)([^;]+?\.(?:cc|cpp|cxx|c|S))(?:\s+\[for tool\])?;',t)
   if n:groups['native_C_or_CXX_progress'].append(v);pathobs[n[1]].append(v)
   if n and('external/v8'in n[1]or n[1].startswith(('src/compiler/','src/builtins/','src/snapshot/','src/torque/','src/heap/'))):groups['explicit_v8_source_progress'].append(v)
   if 'Compiling Rust 'in t:groups['Rust_compile_progress'].append(v)
   tm=re.search(r'\b([\d,]+) / ([\d,]+) tests\b',t)
   if tm:groups['tests_counter'].append(v|{'completed_counter':int(tm[1].replace(',','')),'total_counter':int(tm[2].replace(',',''))})
   if 'Testing //'in t:groups['test_target_progress'].append(v)
 report={}
 for label,vals in groups.items():
  report[label]={'log_observation_count':len(vals),'first':event(vals[0])if vals else None,'last':event(vals[-1])if vals else None,'first_to_last_observation_span_seconds':sec(vals[0]['utc'],vals[-1]['utc'])if vals else None,'interpretation':'Timestamp span of observed progress samples, not CPUtime or exclusive phase occupancy; phases overlap.'}
 if groups['tests_counter']:
  end=groups['tests_counter'][-1];report['tests_counter']['last_counter']={k:end[k]for k in ['completed_counter','total_counter']}
 analyzed=groups['analysis_complete'][0]if groups['analysis_complete']else None
 cancelled=groups['cancel'][-1]
 earliest_analysis=groups['analysis'][0]if groups['analysis']else None
 prebuild=sec(job['started_at'],active['started_at'])
 row={'job_id':ident,'job_name':job['name'],'source_original_log':{'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'source_head':job['head_sha'],'run':job['run_id'],'attempt':job['run_attempt'],'metadata_steps':steps,'pre_main_Bazel_step_wall_seconds':prebuild,'main_Bazel_step_wall_seconds':active['metadata_wall_seconds'],'main_step_start_to_first_analysis_seconds':sec(active['started_at'],earliest_analysis['utc'])if earliest_analysis else None,'first_analysis_to_analysis_complete_seconds':sec(earliest_analysis['utc'],analyzed['utc'])if earliest_analysis and analyzed else None,'main_step_start_to_analysis_complete_seconds':sec(active['started_at'],analyzed['utc'])if analyzed else None,'analysis_complete_to_cancel_seconds':sec(analyzed['utc'],cancelled['utc'])if analyzed else None,'phases':report,'native_source_labels_observed':len(pathobs),'actual_all_tests_complete':False,'sdk_tests_run':False if ident==121613022191 else None,'no_new_execution':True}
 paths={k:{'samples':len(v),'first_utc':v[0]['utc'],'last_utc':v[-1]['utc'],'first_line':v[0]['line'],'last_line':v[-1]['line']}for k,v in sorted(pathobs.items())};(D/f'job{ident}.native-source-path-observations.json').write_text(json.dumps(paths,indent=2)+'\n');nativepaths[ident]=set(paths)
 (D/f'job{ident}.phase-quantification.json').write_text(json.dumps(row,indent=2)+'\n');allrows.append(row)
common=sorted(set.intersection(*(nativepaths[x]for x in ids)))
intersections={'all5_shared_source_labels':common,'all5_shared_source_label_count':len(common),'interpretation':'Same printed source label across jobs is evidence of repeated source compilation observations. It does not prove identical Bazel action keys, ABI/feature equivalence, wastedwork or a safe binarysubstitution.','pairwise_shared_label_count':{str(a)+'-'+str(b):len(nativepaths[a]&nativepaths[b])for i,a in enumerate(ids)for b in ids[i+1:]}}
(D/'native-observed-source-label-overlap.json').write_text(json.dumps(intersections,indent=2)+'\n')
(D/'five-original-phase-quantification.json').write_text(json.dumps(allrows,indent=2)+'\n')
print(json.dumps([{'id':x['job_id'],'preBazel_seconds':x['pre_main_Bazel_step_wall_seconds'],'main_Bazel_seconds':x['main_Bazel_step_wall_seconds'],'main_to_analyzed_seconds':x['main_step_start_to_analysis_complete_seconds'],'analyzed_to_cancel_seconds':x['analysis_complete_to_cancel_seconds'],'native_first':x['phases']['native_C_or_CXX_progress']['first']['utc']if x['phases']['native_C_or_CXX_progress']['first']else None,'native_last':x['phases']['native_C_or_CXX_progress']['last']['utc']if x['phases']['native_C_or_CXX_progress']['last']else None,'Rustfirst':x['phases']['Rust_compile_progress']['first']['utc']if x['phases']['Rust_compile_progress']['first']else None,'Rustlast':x['phases']['Rust_compile_progress']['last']['utc']if x['phases']['Rust_compile_progress']['last']else None,'tests_last':x['phases']['tests_counter'].get('last_counter'),'repo_cache_miss':x['phases']['cache_restore_miss']['log_observation_count'],'native_labels':x['native_source_labels_observed']}for x in allrows],indent=2));print('all5_shared_source_labels',len(common))
