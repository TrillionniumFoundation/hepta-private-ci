import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

D = Path(__file__).resolve().parent
START = json.loads((D.parent / 'launch-intent.json').read_text())['start_monotonic']
REMAINING_UNIT = int(START + 590 - time.monotonic()) - 2
if REMAINING_UNIT < 30:
    raise RuntimeError('insufficient original absolute window')
UNIT = 'hepta-seven-dpop-20261026-002-39b543f8'
command = ['systemd-run', '--user', '--wait', '--pipe', '--collect', '--quiet', '--service-type=exec',
           '--unit=' + UNIT, '--property=Nice=10', '--property=CPUQuota=200%',
           '--property=MemoryMax=8589934592', '--property=RuntimeMaxSec=' + str(REMAINING_UNIT),
           '--property=TimeoutStopSec=5', '--property=KillMode=control-group',
           '/usr/bin/python3', str(D / 'owner.py'), str(START)]
intent = {'unit': UNIT, 'command': command, 'start_monotonic': START,
          'hierarchy_seconds': {'child': 550, 'collector': 580, 'unit': 590, 'outer': 600},
          'single_source_copy_resolve_compile_list_run_window': True,
          'no_old_model_supervisor_W1_budget_reused': True}
with (D / 'launch-intent.json').open('x') as f:
    json.dump(intent, f, indent=2)
    f.write('\n')
    f.flush()
    os.fsync(f.fileno())
with (D / 'unit.stdout').open('xb', buffering=0) as out, (D / 'unit.stderr').open('xb', buffering=0) as err:
    child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
    code = child.wait()
    out.flush()
    os.fsync(out.fileno())
    err.flush()
    os.fsync(err.fileno())
result = {'exit_code': code, 'launcher_child_reaped': True, 'seconds_before_final_publication': time.monotonic() - START,
          'unit': UNIT, 'outer_required_terminal_evidence': True}
with (D / 'launch-result.json').open('x') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
    f.flush()
    os.fsync(f.fileno())
print(json.dumps(result), flush=True)
sys.exit(code if time.monotonic() - START < 600 else 1)
