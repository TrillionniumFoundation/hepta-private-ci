import errno
import os
from pathlib import Path
import time

def scan_tree(root, limit, deadline, state, record):
    root = Path(root)
    identity = root.stat()
    expected = (identity.st_dev, identity.st_ino)
    while True:
        if time.monotonic() >= deadline:
            raise RuntimeError("scan absolute deadline")
        total = 0
        def walk_error(error):
            raise error
        try:
            current = root.stat()
            if (current.st_dev, current.st_ino) != expected:
                raise RuntimeError("target directory identity changed")
            for parent, dirs, names in os.walk(root, onerror=walk_error):
                if time.monotonic() >= deadline:
                    raise RuntimeError("scan absolute deadline")
                for name in names:
                    total += (Path(parent) / name).lstat().st_size
                    state["high_water"] = max(state["high_water"], total)
                    if state["high_water"] > limit:
                        raise RuntimeError("target logical capacity")
            current = root.stat()
            if (current.st_dev, current.st_ino) != expected:
                raise RuntimeError("target directory identity changed")
            state["complete_scans"] += 1
            return total
        except OSError as error:
            if error.errno != errno.ENOENT:
                raise
            state["incomplete_scans"] += 1
            record({"errno": error.errno, "filename": error.filename, "partial_bytes": total,
                    "high_water": state["high_water"], "incomplete_scan": True})
            # A missing/replaced root never authorizes an empty target or a refunded reservation.
            current = root.stat()
            if (current.st_dev, current.st_ino) != expected:
                raise RuntimeError("target directory identity changed")
            if state["incomplete_scans"] > 256:
                raise RuntimeError("bounded scan retry capacity")
            time.sleep(.002)
