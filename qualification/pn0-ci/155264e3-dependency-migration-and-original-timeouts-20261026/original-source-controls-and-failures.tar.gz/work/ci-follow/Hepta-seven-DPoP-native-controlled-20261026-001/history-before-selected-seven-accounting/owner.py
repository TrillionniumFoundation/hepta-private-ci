import collections
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import time
import tomllib

BASE = Path('/home/qian-qi/Documents/Codex/2026-10-25/github-trillionnium-chain-https-github-com')
ROOT = BASE / 'work/root-hepta-integration-20261026'
D = Path(__file__).resolve().parent
COPY = D / 'source'
TARGET = D / 'target'
RAW = D / 'raw'
FROZEN = BASE / 'work/ci-follow/Hepta-advisory-aws-p256-full-source-candidate-20261026-001'
START = float(sys.argv[1])
STEPS = []
FIRST_ERROR = None
EXPECTED_HEAD = '9d8be55e3763bfaba78d6698c3f31bbd79069d3e'
EXPECTED_NAMES = {
    'test_header_extracts_public_coordinates', 'test_build_message',
    'test_calculate_valid_key', 'test_calculate_invalid_key',
    'test_calculated_signature_is_jose_es256_and_rejects_changed_message',
    'test_rfc7515_appendix_a3_existing_es256_wire_signature_verifies',
    'test_entropy_failure_returns_login_error_without_a_proof_or_fallback',
}
FILTER = 'package(=aws-config) & test(/^login::dpop::tests::/)'
EXPECTED_NEW = {('aws-smithy-protocol-test', '0.63.14'), ('cbor-diag', '0.1.12'),
                ('ciborium', '0.2.2'), ('ciborium-io', '0.2.2'), ('ciborium-ll', '0.2.2'),
                ('h2', '0.3.27'), ('hyper', '0.14.32'), ('roxmltree', '0.14.1'),
                ('separator', '0.4.1')}
ENV = {k: os.environ[k] for k in ('HOME', 'USER', 'LOGNAME', 'PATH', 'RUSTUP_HOME',
       'CARGO_HOME', 'XDG_RUNTIME_DIR', 'DBUS_SESSION_BUS_ADDRESS', 'LANG') if k in os.environ}
ENV.update({'PATH': '/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
            'RUSTUP_TOOLCHAIN': '1.95.0', 'CARGO_BUILD_JOBS': '2',
            'CARGO_TARGET_DIR': str(TARGET), 'PYTHONDONTWRITEBYTECODE': '1',
            'CARGO_NET_RETRY': '0', 'CARGO_HTTP_TIMEOUT': '30'})

def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def save(name, value):
    p = D / name
    with p.open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())

def require(value, reason):
    if not value:
        raise RuntimeError(reason)

def elapsed():
    return time.monotonic() - START

def logical(p):
    return sum(f.lstat().st_size for root, dirs, files in os.walk(p)
               for f in (Path(root) / name for name in files)) if p.exists() else 0

PEAK_TARGET = 0
LAST_SCAN = 0.0
def guard():
    global PEAK_TARGET, LAST_SCAN
    require(elapsed() < 550, 'shared child/copy/resolve/build/list/run deadline550')
    if time.monotonic() - LAST_SCAN < .5:
        return
    LAST_SCAN = time.monotonic()
    size = logical(TARGET)
    PEAK_TARGET = max(PEAK_TARGET, size)
    require(size <= 6 * 1024**3, 'private target logical capacity6GiB')
    if RAW.exists():
        files = [x for x in RAW.iterdir() if x.is_file()]
        require(all(x.stat().st_size <= 16 * 1024**2 for x in files), 'single raw capture16MiB')
        require(sum(x.stat().st_size for x in files) <= 64 * 1024**2, 'aggregate raw capture64MiB')
    fs = os.statvfs(D)
    require(fs.f_bavail * fs.f_frsize >= 512 * 1024**2, 'filesystem reserve512MiB')

def birth(pid):
    raw = Path(f'/proc/{pid}/stat').read_text()
    return {'pid': pid, 'start_ticks': int(raw[raw.rfind(')') + 2:].split()[19]),
            'ppid': int(raw[raw.rfind(')') + 2:].split()[1])}

def run(name, argv, cwd=D):
    guard()
    started = time.monotonic()
    row = {'name': name, 'argv': argv, 'cwd': str(cwd), 'started_elapsed': elapsed()}
    violation = None
    with (RAW / (name + '.stdout')).open('xb', buffering=0) as out, (RAW / (name + '.stderr')).open('xb', buffering=0) as err:
        child = subprocess.Popen(argv, cwd=cwd, env=ENV, stdin=subprocess.DEVNULL,
                                 stdout=out, stderr=err, start_new_session=True)
        try:
            row['identity'] = birth(child.pid)
        except FileNotFoundError:
            row['identity'] = {'pid': child.pid, 'start_ticks': None, 'birth_unknown': True}
        save(name + '-started.json', row)
        try:
            while True:
                observed = os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
                if observed is not None:
                    break
                try:
                    guard()
                except Exception as e:
                    violation = repr(e)
                    break
                time.sleep(.25)
        finally:
            # Keep the unreaped leader until the final group signal; never signal an old reused PID/PGID.
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            got, status, usage = os.wait4(child.pid, 0)
            child.returncode = os.waitstatus_to_exitcode(status)
            row.update({'wait_pid': got, 'wait_status': status, 'exit_code': child.returncode,
                        'leader_reaped': True, 'cpu_user_seconds': usage.ru_utime,
                        'cpu_system_seconds': usage.ru_stime, 'maxrss_kib': usage.ru_maxrss,
                        'violation': violation, 'seconds': time.monotonic() - started,
                        'finished_elapsed': elapsed(), 'all_tree_terminal': 'UNKNOWN'})
            for stream in (out, err):
                stream.flush()
                os.fsync(stream.fileno())
    STEPS.append(row)
    save(name + '-result.json', row)
    require(violation is None and child.returncode == 0, f'{name} failed: {row}')
    guard()
    return row

def inventory(root, names):
    rows = []
    for name in names:
        guard()
        f = root / name
        st = f.lstat()
        if stat.S_ISLNK(st.st_mode):
            raw = os.fsencode(os.readlink(f))
            digest = hashlib.sha256(raw).hexdigest()
        else:
            require(stat.S_ISREG(st.st_mode), 'unexpected source file kind')
            digest = sha(f)
        rows.append({'path': name, 'size': st.st_size, 'mode': stat.S_IMODE(st.st_mode), 'sha256': digest})
    return rows

def graph_admission():
    old = tomllib.loads((D / 'integrated-before.Cargo.lock').read_text())['package']
    new = tomllib.loads((COPY / 'codex-rs/Cargo.lock').read_text())['package']
    key = lambda p: (p['name'], p['version'], p.get('source'))
    oldpk, newpk = {key(x): x for x in old}, {key(x): x for x in new}
    require(set(oldpk) <= set(newpk), 'test graph removed an integrated package')
    for k, v in oldpk.items():
        require(v.get('checksum') == newpk[k].get('checksum'), f'checksum changed: {k}')
    added = set(newpk) - set(oldpk)
    require({(k[0], k[1]) for k in added} == EXPECTED_NEW, 'unexpected dev packages; stop before native')
    metadata = json.loads((RAW / 'resolve.stdout').read_text())
    packs, nodes = {p['id']: p for p in metadata['packages']}, {p['id']: p for p in metadata['resolve']['nodes']}
    package = next(p for p in packs.values() if p['name'] == 'aws-config')
    require(package['id'] in metadata['workspace_members'], 'vendor not selected member')
    require(len(metadata['workspace_members']) == 196, 'expected full original195 plus vendor')
    pnode = nodes[package['id']]
    require(pnode['features'] == ['credentials-login', 'credentials-process', 'default', 'default-https-client', 'rt-tokio', 'sso'], 'vendor feature correspondence')
    starts = [d['pkg'] for d in pnode['deps'] if any(k['kind'] == 'dev' for k in d['dep_kinds'])]
    parents = {x: None for x in starts}
    todo = collections.deque(starts)
    while todo:
        current = todo.popleft()
        for d in nodes[current]['deps']:
            if any(k['kind'] is None for k in d['dep_kinds']) and d['pkg'] not in parents:
                parents[d['pkg']] = current
                todo.append(d['pkg'])
    reasons = []
    for k in sorted(added, key=str):
        pid = next(i for i, p in packs.items() if key(p) == k)
        require(pid in parents, 'new package not reachable from real vendor dev dependency')
        path = []
        current = pid
        while current is not None:
            path.append({'name': packs[current]['name'], 'version': packs[current]['version']})
            current = parents[current]
        reasons.append({'package': newpk[k], 'vendor_dev_dependency_path': list(reversed(path))})
    baseline = json.loads((FROZEN / 'cargo-metadata.original.json').read_text())
    oldnodes = {x['id']: x for x in baseline['resolve']['nodes']}
    fresh_by_key = {key(p): nodes[p['id']] for p in packs.values()}
    feature_delta = []
    for p in baseline['packages']:
        before = set(oldnodes[p['id']]['features'])
        after = set(fresh_by_key[key(p)]['features'])
        if before != after:
            feature_delta.append({'package': key(p), 'before': sorted(before), 'after': sorted(after)})
        if p['name'].startswith('aws-') or p['name'] in {'p256', 'elliptic-curve', 'crypto-bigint', 'ctutils'}:
            require(before <= after, 'lost normal AWS or crypto feature')
        if p['name'] in {'p256', 'elliptic-curve', 'crypto-bigint', 'ctutils'}:
            require(before == after, 'crypto feature mismatch')
    save('graph-admission.json', {'old_packages': len(oldpk), 'new_packages': len(newpk),
         'original22_AWS_versions_checksums_retained': True, 'added_dev_paths': reasons,
         'actual_feature_deltas': feature_delta, 'member_id': package['id'],
         'test_only_member_configuration_not_exact_production': True})

def main():
    RAW.mkdir()
    require(os.getpriority(os.PRIO_PROCESS, 0) == 10, 'absolute Nice10 required')
    cg = Path('/sys/fs/cgroup') / Path('/proc/self/cgroup').read_text().strip().split('::', 1)[1].lstrip('/')
    quota, period = (cg / 'cpu.max').read_text().split()
    memory = (cg / 'memory.max').read_text().strip()
    require(quota != 'max' and int(quota) <= 2 * int(period), 'CPU200 quota required')
    require(memory != 'max' and int(memory) <= 8 * 1024**3, 'MemoryMax8GiB required')
    save('actual-resources.json', {'nice': os.getpriority(os.PRIO_PROCESS, 0), 'cpu_max': [quota, period],
         'memory_max': memory, 'cgroup': str(cg), 'start_monotonic': START})
    run('root-head', ['git', 'rev-parse', 'HEAD'], ROOT)
    require((RAW / 'root-head.stdout').read_text().strip() == EXPECTED_HEAD, 'root HEAD drift')
    run('root-tracked', ['git', 'ls-files', '-z'], ROOT)
    tracked = sorted(os.fsdecode(x) for x in (RAW / 'root-tracked.stdout').read_bytes().split(b'\0') if x)
    source_inventory = inventory(ROOT, tracked)
    require(sum(r['size'] for r in source_inventory) <= 2 * 1024**3, 'source2GiB')
    save('root-tracked-before.json', source_inventory)
    frozen = json.loads((FROZEN / 'final-source-inventory.json').read_text())
    names = [x['path'] for x in frozen['members']] + ['MODULE.bazel.lock', '.bazelignore']
    initial_overlay = inventory(ROOT, names)
    for row in frozen['members']:
        require(sha(ROOT / row['path']) == row['sha256'], 'root76 source drift')
    save('root78-before.json', initial_overlay)
    shutil.copy2(ROOT / 'codex-rs/Cargo.lock', D / 'integrated-before.Cargo.lock')
    run('clone', ['git', 'clone', '--shared', '--no-checkout', str(ROOT), str(COPY)])
    run('checkout', ['git', 'checkout', '--detach', EXPECTED_HEAD], COPY)
    for name in names:
        guard()
        dest = COPY / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / name, dest)
        require(dest.stat().st_ino != (ROOT / name).stat().st_ino, 'source shared writable inode')
    for row in source_inventory:
        dest = COPY / row['path']
        if not dest.is_symlink():
            dest.chmod(row['mode'])
    require(inventory(COPY, tracked) == source_inventory, 'complete source copy correspondence')
    manifest = COPY / 'codex-rs/Cargo.toml'
    original_manifest = manifest.read_bytes()
    manifest.write_text(original_manifest.decode().replace('members = [\n', 'members = [\n    "third_party/aws-config-1.8.12",\n', 1))
    require(manifest.read_bytes() != original_manifest, 'test member overlay not applied')
    save('test-only-overlay.json', {'before_sha256': hashlib.sha256(original_manifest).hexdigest(), 'after_sha256': sha(manifest)})
    TARGET.mkdir()
    seed = ROOT / 'codex-rs/target'
    save('cache-seed.json', {'source': str(seed), 'source_identity': [seed.stat().st_dev, seed.stat().st_ino],
         'source_logical_bytes': logical(seed), 'destination': str(TARGET),
         'method': 'cp -a --reflink=auto; distinct inodes required; COW or copied bytes, never fresh build'})
    run('seed-cache', ['cp', '-a', '--reflink=auto', str(seed) + '/.', str(TARGET)])
    for root, dirs, files in os.walk(seed):
        for name in files:
            src = Path(root) / name
            dst = TARGET / src.relative_to(seed)
            if src.is_file() and not src.is_symlink():
                require((src.stat().st_dev, src.stat().st_ino) != (dst.stat().st_dev, dst.stat().st_ino), 'seed shared writable inode')
    cwd = COPY / 'codex-rs'
    run('resolve', ['cargo', 'metadata', '--format-version=1', '--features', 'aws-config/credentials-login'], cwd)
    graph_admission()
    common = ['--locked', '--offline', '-p', 'aws-config', '--lib', '--features', 'aws-config/credentials-login', '-E', FILTER]
    run('compile', ['just', 'test', '--no-run'] + common, cwd)
    run('enumerate', ['cargo', 'nextest', 'list', '--message-format=json'] + common, cwd)
    listing = json.loads((RAW / 'enumerate.stdout').read_text())
    selected = []
    binaries = []
    for suite in listing['rust-suites'].values():
        matched = [name for name, case in suite['testcases'].items() if case['filter-match']['status'] == 'matches']
        if matched:
            selected.extend(matched)
            binaries.append(Path(suite['binary-path']))
    require(set(selected) == {'login::dpop::tests::' + x for x in EXPECTED_NAMES} and len(selected) == 7, 'actual selected names must be exactly seven')
    binary_pins = []
    for binary in binaries:
        require(binary.resolve().is_relative_to(TARGET), 'test binary escaped private target')
        binary.chmod(0o500)
        binary_pins.append({'path': str(binary), 'size': binary.stat().st_size, 'sha256': sha(binary)})
    save('actual-seven-selection.json', {'names': selected, 'binary_pins': binary_pins, 'not_production_exact_graph': True})
    run('seven-tests', ['just', 'test'] + common, cwd)
    output = (RAW / 'seven-tests.stdout').read_text() + (RAW / 'seven-tests.stderr').read_text()
    require('7 tests run: 7 passed, 0 skipped' in output, 'actual7/7/0skip summary missing')
    for name in EXPECTED_NAMES:
        require('login::dpop::tests::' + name in output, 'actual PASS name missing')
    for pin in binary_pins:
        require(sha(Path(pin['path'])) == pin['sha256'], 'test binary drift')
    run('final-fmt', ['just', 'fmt'], cwd)
    require(inventory(ROOT, tracked) == source_inventory, 'root tracked source changed')
    require(inventory(ROOT, names) == initial_overlay, 'root78 changed')
    require(inventory(COPY, [x['path'] for x in frozen['members'] if x['path'] not in ['codex-rs/Cargo.toml', 'codex-rs/Cargo.lock']]) ==
            inventory(ROOT, [x['path'] for x in frozen['members'] if x['path'] not in ['codex-rs/Cargo.toml', 'codex-rs/Cargo.lock']]), 'vendor/source drift')
    save('root78-after.json', inventory(ROOT, names))
    save('private-vendor-after.json', inventory(COPY, [x['path'] for x in frozen['members']]))
    save('known-crypto-fingerprint-files.json', [
        {'path': str(q), 'bytes': q.stat().st_size, 'sha256': sha(q), 'text': q.read_text()}
        for prefix in ['aws-config', 'p256', 'elliptic-curve', 'crypto-bigint', 'ctutils']
        for folder in (TARGET / 'debug/.fingerprint').glob(prefix + '-*')
        for q in folder.glob('*.json') if q.stat().st_size <= 65536])
    return {'seven_selected': 7, 'passed': 7, 'failed': 0, 'skipped': 0,
            'mechanism_sample_only': True, 'exact_production_graph_qualification': False,
            'full_upstream_suite_qualification': False, 'merge_ready': False}

try:
    result = main()
except BaseException as error:
    FIRST_ERROR = repr(error)
    result = {'seven_selected': None, 'passed': None, 'failed': None, 'skipped': None,
              'mechanism_sample_only': True, 'exact_production_graph_qualification': False,
              'full_upstream_suite_qualification': False, 'merge_ready': False}
finally:
    result.update({'first_error': FIRST_ERROR, 'steps': STEPS, 'elapsed_before_final_publication': elapsed(),
                   'target_peak_observed_logical_bytes': PEAK_TARGET,
                   'monitor_not_filesystem_hard_quota': True, 'all_tree_terminal': 'UNKNOWN'})
    save('owner-result.json', result)
    print(json.dumps(result), flush=True)
    require(elapsed() < 580, 'collector deadline after final IO580')
    sys.exit(0 if FIRST_ERROR is None else 1)
