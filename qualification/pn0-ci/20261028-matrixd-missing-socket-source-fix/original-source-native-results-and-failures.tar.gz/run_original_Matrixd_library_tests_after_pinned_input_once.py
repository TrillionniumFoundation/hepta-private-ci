from pathlib import Path
import os,subprocess,datetime,json,time,hashlib
D=Path(__file__).resolve().parent
W=D.parents[2]
H=W/"work/root-hepta-integration-20261026"
start=time.monotonic()
env=os.environ.copy(); env.update({"CARGO_TARGET_DIR":str(W/"work/ci-follow/Hepta-Mac-authorized-read-root-integration-20261027-001/linux-mapping-target"),"CARGO_BUILD_JOBS":"1","CARGO_NET_OFFLINE":"true","CARGO_PROFILE_DEV_DEBUG":"0","CARGO_PROFILE_TEST_DEBUG":"0","CARGO_INCREMENTAL":"0","RUSTUP_TOOLCHAIN":"1.96.0"})
cmd=["just","test","-p","codex-hepta-matrixd","--locked","--offline","--lib"]
r={"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"command":cmd,"cwd":str(H/"codex-rs"),"env":{k:env[k] for k in ["CARGO_TARGET_DIR","CARGO_BUILD_JOBS","CARGO_PROFILE_DEV_DEBUG","CARGO_PROFILE_TEST_DEBUG","CARGO_INCREMENTAL","RUSTUP_TOOLCHAIN"]},"scope":"All original Matrixd library tests plus one real missing/live/retired socket regression; Linux development profile only, no Windows/native full qualification, no expired SDK/supervisor/model budget resumed"}
with (D/"original-Matrixd-library-after-pinned-input.stdout.original").open("wb") as out,(D/"original-Matrixd-library-after-pinned-input.stderr.original").open("wb") as err:
 p=subprocess.Popen(cmd,cwd=H/"codex-rs",env=env,stdout=out,stderr=err); r["pid"]=p.pid; r["proc_stat"]=Path(f"/proc/{p.pid}/stat").read_text(); (D/"actual-Matrixd-library-after-pinned-input-process-start.json").write_text(json.dumps(r,indent=2)+"\n"); code=p.wait()
r.update({"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"actual_wait":code,"seconds":time.monotonic()-start,"task_complete":False,"merge_ready":False})
(D/"actual-Matrixd-library-after-pinned-input-process-terminal.json").write_text(json.dumps(r,indent=2)+"\n"); print(json.dumps(r));

raise SystemExit(code)
