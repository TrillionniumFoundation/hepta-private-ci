from pathlib import Path
import subprocess, json, datetime, time, hashlib, os, tomllib

D = Path(__file__).resolve().parent
W = D.parents[2]
C = W / 'work/hepta-aws-json-isolated-validation-20261028/codex-rs'
V = C / 'third_party/aws-smithy-json-0.61.9'
terminal = D / 'actual-isolated-official-reference-lock-update-terminal.json'
original = json.loads((D / 'actual-isolated-official-reference-lock-update-start.json').read_text())
expected_pid = original['pid']
expected_birth = original['proc_stat'].rsplit(')', 1)[1].split()[19]

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source():
    return {str(p.relative_to(C)): digest(p) for p in [C/'Cargo.toml', C/'Cargo.lock', V/'Cargo.toml', V/'Cargo.lock', V/'src/deserialize/token.rs', V/'src/serialize.rs']}

waiting = {'started_utc':now(), 'stage':'WAITING_FOR_SAME_METADATA_ACTUAL_TERMINAL_NOT_NATIVE_TEST_RUNNING', 'pid':os.getpid(), 'proc_stat':Path('/proc/self/stat').read_text(), 'metadata_pid':expected_pid, 'metadata_birth':expected_birth, 'source_token_expected':'f16a4dc2f02b8bdcebb118badccd1ebe4d502360832ce3e9b0ef6d7743fefdf3', 'dev_reference_manifest_expected':'56ce3714b07d359467f68959214ab1ef7e0dc6cc1ca15fd7c39955255fc198b0'}
(D/'actual-original-reference-full-continuation-owner-start.json').write_text(json.dumps(waiting,indent=2)+'\n')
while not terminal.exists():
    stat = Path(f'/proc/{expected_pid}/stat')
    if not stat.exists() or stat.read_text().rsplit(')',1)[1].split()[19] != expected_birth:
        if terminal.exists():
            break
        waiting.update(finished_utc=now(), stage='METADATA_OWNER_GONE_WITHOUT_TERMINAL_RECEIPT_UNKNOWN_NO_TEST_STARTED', actual_wait=75)
        (D/'actual-original-reference-full-continuation-owner-terminal.json').write_text(json.dumps(waiting,indent=2)+'\n')
        raise SystemExit(75)
    time.sleep(5)
meta = json.loads(terminal.read_text())
assert meta['actual_wait'] == 0, meta
assert digest(V/'src/deserialize/token.rs') == waiting['source_token_expected']
assert digest(V/'Cargo.toml') == waiting['dev_reference_manifest_expected']
lock = tomllib.loads((V/'Cargo.lock').read_text())['package']
assert [(p['name'],p['version']) for p in lock if p['name']=='serde_json'] == [('serde_json','1.0.146')]
assert [(p['name'],p['version']) for p in lock if p['name']=='aws-smithy-types'] == [('aws-smithy-types','1.4.7')]
host = tomllib.loads((C/'Cargo.lock').read_text())['package']
assert [(p['name'],p['version']) for p in host if p['name']=='serde_json'] == [('serde_json','1.0.151')]
cmd = ['just','test','-p','aws-smithy-json','--manifest-path',str(V/'Cargo.toml'),'--locked','--lib']
env = os.environ.copy()
env.update(RUSTUP_TOOLCHAIN='1.96.0', CARGO_NET_OFFLINE='false', CARGO_TARGET_DIR=str(D/'isolated-upstream-native-target'), CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0')
r = {'started_utc':now(),'command':cmd,'cwd':str(C),'source_before':source(),'actual_metadata_terminal':meta,'scope':'All original nonignored upstream tests and all3 unchanged security regressions. Exact upstream dev reference1.0.146 isolated from host runtime1.0.151; same current aws-smithy-types1.4.7. Original prior 67P/1F/1ignored and stack-overflow RED retained. Original ignored all_codepoints is unchanged, not newly skipped. Not Windows/release/fullgraph/SDK/model/publicprepare qualification or expired budget reset.'}
t=time.monotonic()
with (D/'original-reference-fixed-upstream-full.stdout.original').open('xb') as out,(D/'original-reference-fixed-upstream-full.stderr.original').open('xb') as err:
    p=subprocess.Popen(cmd,cwd=C,env=env,stdout=out,stderr=err)
    r.update(pid=p.pid,proc_stat=Path(f'/proc/{p.pid}/stat').read_text())
    (D/'actual-original-reference-fixed-upstream-full-start.json').write_text(json.dumps(r,indent=2)+'\n')
    code=p.wait()
r.update(finished_utc=now(),actual_wait=code,seconds=time.monotonic()-t,source_after=source(),task_complete=False,merge_ready=False)
(D/'actual-original-reference-fixed-upstream-full-terminal.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
raise SystemExit(code)
