from pathlib import Path
import subprocess, json, datetime, time, hashlib, os

D = Path(__file__).resolve().parent
W = D.parents[2]
C = W / 'work/hepta-aws-json-isolated-validation-20261028/codex-rs'
paths = ['Cargo.toml', 'Cargo.lock', 'third_party/aws-smithy-json-0.61.9/src/deserialize/token.rs']
source = lambda: {p: hashlib.sha256((C / p).read_bytes()).hexdigest() for p in paths}
cmd = ['cargo', 'update', '--manifest-path', str(C / 'Cargo.toml'), '-p', 'aws-smithy-json']
env = os.environ.copy()
env.update(RUSTUP_TOOLCHAIN='1.96.0', CARGO_NET_OFFLINE='false')
r = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': cmd, 'cwd': str(C), 'source_before': source(), 'scope': 'Original upstream proptest default dev dependencies need the missing rusty-fork registry entry. Preserve both offline failures. No original test, feature, version constraint, cap or workflow changed; isolated Cargo inputs only.'}
t = time.monotonic()
with (D / 'isolated-verified-member-online-update.stdout.original').open('wb') as out, (D / 'isolated-verified-member-online-update.stderr.original').open('wb') as err:
    p = subprocess.Popen(cmd, cwd=C, env=env, stdout=out, stderr=err)
    r.update(pid=p.pid, proc_stat=Path(f'/proc/{p.pid}/stat').read_text())
    (D / 'actual-isolated-verified-member-online-update-start.json').write_text(json.dumps(r, indent=2) + '\n')
    code = p.wait()
r.update(finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), actual_wait=code, seconds=time.monotonic() - t, source_after=source())
(D / 'actual-isolated-verified-member-online-update-terminal.json').write_text(json.dumps(r, indent=2) + '\n')
print(json.dumps(r))
raise SystemExit(code)
