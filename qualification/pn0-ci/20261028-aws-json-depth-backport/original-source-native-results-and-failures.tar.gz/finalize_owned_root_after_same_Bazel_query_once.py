from pathlib import Path
import subprocess, json, time, datetime, hashlib, os

D = Path(__file__).resolve().parent
W = D.parents[2]
R = W / 'work/root-hepta-integration-20261026'
V = R / 'codex-rs/third_party/aws-smithy-json-0.61.9'
query_start = json.loads((D/'actual-root-fixed-path-package-Bazel-dependency-loading-start.json').read_text())
query_terminal = D/'actual-root-fixed-path-package-Bazel-dependency-loading-terminal.json'
query_pid = query_start['pid']
query_birth = query_start['proc_stat'].rsplit(')',1)[1].split()[19]

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def source():
    h = subprocess.run(['git','-C',str(R),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
    raw = subprocess.run(['git','-C',str(R),'status','--porcelain=v1','-z','--untracked-files=all'],capture_output=True,check=True).stdout
    paths = {}
    for row in raw.split(b'\0'):
        if not row:
            continue
        p = row[3:].decode()
        f = R/p
        paths[p] = hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
    return {'head':h,'dirty_status_SHA256':hashlib.sha256(raw).hexdigest(),'paths':paths}

def save(stage, **values):
    r.update(stage=stage,observed_utc=now(),**values)
    (D/'actual-root-after-query-fix-and-final-fmt-owner-current.json').write_text(json.dumps(r,indent=2)+'\n')

expected = source()
assert json.loads((D/'actual-root-original-reference-upstream-full-terminal.json').read_text())['actual_wait']==0
r = {'started_utc':now(),'pid':os.getpid(),'proc_stat':Path('/proc/self/stat').read_text(),'query_pid':query_pid,'query_birth':query_birth,'source_before_wait':expected,'scope':'Actual one-shot owner waits for the same query. Only on actual query0 and unchanged complete root WIP does it run scoped just fix, then final just fmt. No native tests after fix/fmt. No commit/push/CI change or original-budget reset.'}
save('WAITING_SAME_QUERY_NO_FORMAT_OR_LINT_STARTED')
while not query_terminal.exists():
    p=Path(f'/proc/{query_pid}/stat')
    if not p.exists() or p.read_text().rsplit(')',1)[1].split()[19]!=query_birth:
        if query_terminal.exists():
            break
        save('QUERY_OWNER_GONE_NO_WAIT_RECEIPT_UNKNOWN_NO_SOURCE_MUTATION',actual_wait=75)
        raise SystemExit(75)
    time.sleep(5)
q=json.loads(query_terminal.read_text())
if q['actual_wait']!=0:
    save('QUERY_FAILED_NO_LINT_OR_FORMAT_STARTED',query_terminal=q,actual_wait=q['actual_wait'])
    raise SystemExit(q['actual_wait'])
if source()!=expected:
    save('ROOT_SOURCE_CHANGED_CONCURRENTLY_NO_MUTATION',actual_wait=75)
    raise SystemExit(75)
env=os.environ.copy()
env.update(RUSTUP_TOOLCHAIN='1.96.0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(D/'isolated-upstream-native-target'))
commands=[('scoped-fix',['just','fix','-p','aws-smithy-json','--manifest-path',str(V/'Cargo.toml'),'--locked']),('final-fmt',['just','fmt'])]
steps=[]
for role,cmd in commands:
    before=source()
    save('RUNNING_'+role.upper(),command=cmd,source_before_step=before)
    start=time.monotonic()
    with (D/f'root-after-query-{role}.stdout.original').open('xb') as out,(D/f'root-after-query-{role}.stderr.original').open('xb') as err:
        p=subprocess.Popen(cmd,cwd=R/'codex-rs',env=env,stdout=out,stderr=err)
        save('RUNNING_'+role.upper(),command=cmd,child_pid=p.pid,child_proc_stat=Path(f'/proc/{p.pid}/stat').read_text())
        code=p.wait()
    after=source()
    step={'role':role,'command':cmd,'actual_wait':code,'seconds':time.monotonic()-start,'source_before':before,'source_after':after}
    steps.append(step)
    if code!=0:
        save('STEP_FAILED',steps=steps,actual_wait=code)
        raise SystemExit(code)
    if role=='scoped-fix' and any(p.endswith('.rs') and before['paths'].get(p)!=sha for p,sha in after['paths'].items()):
        save('LINTER_CHANGED_RUST_REVIEW_REQUIRED_NO_FINAL_FMT_OR_TEST_RETRY',steps=steps,actual_wait=75)
        raise SystemExit(75)
save('FINAL_FMT_ACTUAL_COMPLETE_NO_TESTS_AFTER',steps=steps,actual_wait=0,source_final=source(),task_complete=False,merge_ready=False,no_commit_push_or_publication=True)
(D/'actual-root-after-query-fix-and-final-fmt-terminal.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'stage':r['stage'],'actual_wait':0,'task_complete':False,'merge_ready':False}))
