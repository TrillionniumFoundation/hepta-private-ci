from pathlib import Path
import subprocess, json, datetime, time, hashlib, os

D = Path(__file__).resolve().parent
W = D.parents[2]
C = W / 'work/hepta-aws-json-isolated-validation-20261028/codex-rs'
paths = ['Cargo.toml', 'Cargo.lock', 'third_party/aws-smithy-json-0.61.9/src/deserialize/token.rs']
source = lambda: {p: hashlib.sha256((C / p).read_bytes()).hexdigest() for p in paths}
cmd = ['just', 'test', '-p', 'aws-smithy-json', '--locked', '--lib', '-E', 'test(skip_deeply_nested_does_not_overflow_stack)']
env = os.environ.copy()
env.update(RUSTUP_TOOLCHAIN='1.96.0', CARGO_NET_OFFLINE='false', CARGO_TARGET_DIR=str(D / 'isolated-upstream-native-target'), CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0')
r = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': cmd, 'cwd': str(C), 'source_before': source(), 'env': {k:env[k] for k in ['RUSTUP_TOOLCHAIN','CARGO_NET_OFFLINE','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_INCREMENTAL']}, 'scope': 'Actual upstream regression against byte-exact original vulnerable production prefix and exact upstream added tests; scoped ordinary Linux development only. Not original Windows/release/model/SDK/supervisor/publicprepare qualification or reset budget.'}
t = time.monotonic()
with (D / 'isolated-original-upstream-native-RED.stdout.original').open('xb') as out, (D / 'isolated-original-upstream-native-RED.stderr.original').open('xb') as err:
    p = subprocess.Popen(cmd, cwd=C, env=env, stdout=out, stderr=err)
    r.update(pid=p.pid, proc_stat=Path(f'/proc/{p.pid}/stat').read_text())
    (D / 'actual-isolated-original-upstream-native-RED-start.json').write_text(json.dumps(r, indent=2) + '\n')
    code = p.wait()
r.update(finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), actual_wait=code, seconds=time.monotonic() - t, source_after=source())
(D / 'actual-isolated-original-upstream-native-RED-terminal.json').write_text(json.dumps(r, indent=2) + '\n')
print(json.dumps(r))
raise SystemExit(code)
