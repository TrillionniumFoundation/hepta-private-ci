# PN0 GNU/musl matrix platform binding source candidate

This is an isolated source candidate on Hepta `8987059863d4c2c095d191ade658a00c05598a11`. It is **not applied**, compiled, analyzed by Bazel, or tested. No workflow run, retry, cancellation, source push, new native budget or test was created. Original published155 five 60-minute timeouts and all Windows failures remain OPEN.

## Confirmed source contract and minimal correction

The original Linux test rows name GNU and musl but their command does not use the target to select a platform. The original keyless logs' local_linux paths and exact155 source were frozen by the separate 41-file audit. Current898 retains this gap; the SDK cache correction is unrelated.

The candidate adds only two matrix platform values, one step environment binding and one conditional argument append. GNU uses the existing `//:local_linux` platform (LLVM GNU2.28 and the existing GNU host properties). Musl uses **`@rules_rs//rs/platforms:x86_64-unknown-linux-musl`**, whose actual pinned generator supplies CPU/OS, the separate rules_rs musl constraint, LLVM musl and LLVM PIE-off. Host/exec selection remains the existing GNU setup for rustc/proc-macros/build scripts and V8 generators. Linux source-built V8/custom libc++/libc++abi target paths already exist. No prebuilt substitution, feature or checksum change is proposed.

A bare platform flag before the CI wrapper's config is insufficient: `run-bazel-ci.sh` appends `--config=ci-linux`, and that config expands in place to GNU `//:rbe` on keyed builds. The candidate repeats **only Linux callers' explicit --platforms arguments** in their original order after the existing CI config. It supports equals and two-token forms, preserves the original arguments and all other config/argument ordering, and does not change macOS/Windows paths. Keyless Python removal of ci-linux still preserves this explicit target; keyed callers' target is no longer replaced by the GNU default. Existing diagnostic `bazel info` already copies platform arguments and post-config arguments.

## Why not use the existing LLVM musl platform directly

Pinned rules_rs0.0.96 owns a separate linux_libc setting defaulting to glibc. LLVM0.8.11's linux_amd64_musl platform supplies LLVM's musl constraint but **does not supply rules_rs musl**. It therefore does not establish a coherent Rust-musl/native-musl target. In addition, the V8 archive select can see its Rust-GNU branch and custom LLVM-musl branch both true with unrelated constraint sets and different labels; this is a source-level ambiguity risk, not a newly observed Bazel failure.

The existing `bazel/platforms/release_binaries.bzl` still maps release musl groups directly to LLVM platforms. This separate existing release-path gap is **not repaired by this CI-only candidate**. Do not use a future matrix result to qualify those release groups without checking their actual toolchain and correcting their mapping. No new release roadmap or acceptance exception is proposed.

## Existing source support and remaining blockers

Actual previously materialized pinned sources show rules_rs GNU exec triples and musl target stdlib definitions, LLVM Linux musl headers/runtime selection and static executable linking, and target/exec separation. These show a coherent existing source route; they do not prove actual resolution/linking/native compatibility. Musl target outputs must remain separate from GNU-host-loaded proc-macros. LLVM's musl dynamic-linking path has an explicit TODO and chooses static executables; do not move the host itself to musl or claim arbitrary dlopen compatibility.

V8 aliases choose existing source-built musl archives and existing GNU-generated API bindings, with sandbox/pointer compression/custom libc++ untouched. Actual Rustc/C++ actions, generated binding/native ABI, musl stdlib/sysroot materialization, linked target ELF and test execution all remain **UNVERIFIED** on this candidate. No action digest, binary ABI, remote execution or 60-minute improvement is claimed. Source materialization or static mapping is not such evidence.

Wine-backed target declarations already require GNU2.28. Genuine musl target selection therefore cannot count those GNU-only Wine tests as musl coverage; GNU retains them unchanged. The original test target pattern, features, filters, resources, all matrix jobs, every action/step and platform-native Windows qualification remain. Any actual skipped/incompatible inventory must be reported, not hidden in a green aggregate or called all original tests passed.

## Static evidence and exact scope

The Python YAML structural check compares the entire old/new workflow after removing only the two new matrix fields, one new env field and resetting the one changed run block; they are equal. All later jobs are byte-identical. The shell is byte-identical after removing the sole inserted Linux explicit-platform block. Bash -n syntax parsing exits0; it does not execute the script or establish its runtime behavior. No product tests were added or run. Two earlier helper-only errors (broad source needle, then JSON deepcopy conversion of a YAML key) are preserved; candidate bytes were not changed to relax any contract.

The 33 complete source files in source898/ and materialized-primary/ are byte/hash copies for review. External materialized files come from the earlier terminal/incomplete385s Bazel analysis, not a new run or success. Original crate/toolchain definitions may materialize additional dependencies on first real musl analysis; all existing integrity checks and budgets remain required.

## Primary sources checked

- [Bazel platform roles, constraints and incompatible-target behavior](https://bazel.build/concepts/platforms).
- [Bazel config expansion occurs in place](https://bazel.build/run/bazelrc#config).
- [Official registry rules_rs0.0.96](https://registry.bazel.build/modules/rules_rs/0.0.96/).
- [Official registry LLVM0.8.11](https://registry.bazel.build/modules/llvm/0.8.11/).

These references support general semantics; the frozen exact repository/module sources establish this candidate's specific constraints. Two raw BCR source.json requests and a guessed Rust target-specific page were unavailable through the web tool and are not evidence. The actual musl target/platform source is preserved locally.

## Required acceptance remains unchanged

Before qualification: independently review this source candidate, obtain actual precise target/exec toolchains and C++/Rustc flags, confirm musl target ELF/ABI and GNU host tools, preserve complete original test/incompatible inventory, execute original necessary CI within unchanged resources and deadlines, and pass all original Windows/security/pair requirements on the exact paired source/actual PR previews. No original timeout or spent validation budget is reset. Merge/task readiness remains false.
