from pathlib import Path
import subprocess,json,hashlib,difflib,datetime,yaml,copy
D=Path("work/ci-follow/Hepta-SDK-original-namespace-cache-restore-source-candidate-20261026-001");R=Path('work/root-hepta-integration-20261026');base='9d8be55e3763bfaba78d6698c3f31bbd79069d3e';rel='.github/workflows/sdk.yml'
def git(*args):return subprocess.run(['git','-C',str(R),*args],capture_output=True,check=True).stdout
before_status=git('status','--porcelain=v1','--',rel);before_work=(R/rel).read_bytes();original=git('show',base+':'+rel);assert original==before_work and not before_status
(D/'AGENTS.base9d8.md').write_bytes(git('show',base+':AGENTS.md'))
O=D/'original'/rel;N=D/'candidate'/rel;O.parent.mkdir(parents=True);N.parent.mkdir(parents=True);O.write_bytes(original)
j=yaml.load(original.decode(),Loader=yaml.BaseLoader);steps=j['jobs']['sdks']['steps'];save=next(x for x in steps if x.get('name')=='Save bazel repository cache')
assert save['if']=="always() && !cancelled() && steps.setup_bazel.outputs.cache-hit != 'true'"
key=save['with']['key'];path=save['with']['path']
new_step="""      - name: Restore bazel repository cache
        id: restore_bazel_repository
        continue-on-error: true
        uses: actions/cache/restore@668228422ae6a00e4ad889ee87cd7109ec5666a7 # v5.0.4
        with:
          path: """+path+"""
          key: """+key+"""
          restore-keys: |
            bazel-cache-x86_64-unknown-linux-gnu-

"""
anchor='      - name: Build codex and code-mode host with Bazel\n'
text=original.decode();assert text.count(anchor)==1
candidate=text.replace(anchor,new_step+anchor,1).replace("steps.setup_bazel.outputs.cache-hit != 'true'","steps.restore_bazel_repository.outputs.cache-hit != 'true'",1).encode()
N.write_bytes(candidate)
patch=''.join(difflib.unified_diff(text.splitlines(keepends=True),candidate.decode().splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel,n=4))
(D/'sdk-repository-download-cache-restore.patch').write_text(patch)
n=yaml.load(candidate.decode(),Loader=yaml.BaseLoader);newsteps=n['jobs']['sdks']['steps'];insert=next(x for x in newsteps if x.get('id')=='restore_bazel_repository');oldpin='668228422ae6a00e4ad889ee87cd7109ec5666a7'
assert insert['uses']=='actions/cache/restore@'+oldpin and insert['continue-on-error']=='true'
assert insert['with']['path']==path and insert['with']['key']==key and insert['with']['restore-keys']=='bazel-cache-x86_64-unknown-linux-gnu-\n'
ids=[x['id']for x in newsteps if 'id'in x];assert len(ids)==len(set(ids))
assert newsteps.index(insert)==next(i for i,s in enumerate(newsteps)if s.get('id')=='setup_bazel')+1
normalized=copy.deepcopy(n);ns=normalized['jobs']['sdks']['steps'];ns.remove(next(x for x in ns if x.get('id')=='restore_bazel_repository'));newsave=next(x for x in ns if x.get('name')=='Save bazel repository cache')
assert newsave['if']=="always() && !cancelled() && steps.restore_bazel_repository.outputs.cache-hit != 'true'"
newsave['if']=save['if'];assert normalized==j
assert n['jobs']['sdks']['timeout-minutes']=='60'and n['jobs']['python-sdk']['timeout-minutes']=='20'
without_step=candidate.decode().replace(new_step,'',1).replace("steps.restore_bazel_repository.outputs.cache-hit != 'true'","steps.setup_bazel.outputs.cache-hit != 'true'",1)
assert without_step.encode()==original
after_status=git('status','--porcelain=v1','--',rel);after_work=(R/rel).read_bytes();assert before_status==after_status and before_work==after_work
oldlines=text.splitlines();newlines=candidate.decode().splitlines()
changes={'old_original_save_if':{'line':next(i+1 for i,s in enumerate(oldlines)if 'steps.setup_bazel.outputs.cache-hit'in s),'text':next(s for s in oldlines if 'steps.setup_bazel.outputs.cache-hit'in s)},'new_restore_start':{'line':next(i+1 for i,s in enumerate(newlines)if 'name: Restore bazel repository cache'in s)},'new_save_if':{'line':next(i+1 for i,s in enumerate(newlines)if 'steps.restore_bazel_repository.outputs.cache-hit'in s),'text':next(s for s in newlines if 'steps.restore_bazel_repository.outputs.cache-hit'in s)}}
def meta(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
receipt={'schema':'minimal-SDK-original-namespace-download-cache-source-candidate-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'observed_root_HEAD':git('rev-parse','HEAD').decode().strip(),'path':rel,'root_worktree_file_equal_base_and_unchanged':True,'root_source_or_Git_mutated':False,'original':meta(O),'candidate':meta(N),'patch':meta(D/'sdk-repository-download-cache-restore.patch'),'exact_old_new_lines':changes,'YAML_parse_and_static_structural_invariants':{'BaseLoader_parsed_original_and_candidate':True,'all_workflow_contracts_job_keys_and_original_step_maps_identical_after_only_restore_insert_and_save_if_identifier_change':True,'reverse_two_allowed_edits_restores_entire_original_bytes':True,'SDK60_python20_preserved':True,'all_runners_environments_permissions_features_test_commands_actions_and_job_conditions_preserved':True,'all_original_save_fields_and_key_path_pin_preserved':True,'original_always_notcancelled_save_policy_preserved':True,'new_restore_id_unique_and_immediately_after_original_setup':True,'pinned_restore_action_matches_existing_repository_restore_pin':True,'new_restore_and_existing_save_nonfatal_cache_policy':True,'download_path_key_prefix_original_SDK_namespace':True,'no_prepare_namespace_substitution':True,'no_new_concurrency_or_platformflags_or_actioncache':True},'scope':'Only SDK repository download restore and save-output binding; no actioncache/Bazelplatform/toolchain/musl/sourcepatch/securitypolicychange.','benefit':'Previously SDK saveddownloadcache without restoringit; new sourcecandidate enables exactlythat namespace tobe restored. Hit/miss/speedup and60minutecompletion remainUNKNOWN; originalpostanalysisnative57min notclosed.','qualification':{'applied_to_root':False,'new_build_test_fmt_or_repo_program':False,'workflow_dispatch_push_cancel_merge':False,'native_or_hosted_CI_pass':False,'five_original_timeout_checks_closed':False,'musl_target_qualification_gap_closed':False,'merge_ready':False},'provenance':'work/ci-follow/Hepta155-native-cache-source-independent-readonly-20261026-001/receipt.json'}
(D/'static-source-candidate-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
manifest=[meta(p)for p in sorted(D.rglob('*'))if p.is_file()and p.name!='manifest.json'];(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'receipt':meta(D/'static-source-candidate-receipt.json'),'patch':meta(D/'sdk-repository-download-cache-restore.patch'),'original':meta(O),'candidate':meta(N),'changes':changes},indent=2));print(patch)
