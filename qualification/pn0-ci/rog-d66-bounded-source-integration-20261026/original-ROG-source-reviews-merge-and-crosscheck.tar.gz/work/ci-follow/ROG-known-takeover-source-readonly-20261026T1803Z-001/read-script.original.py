import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

project = Path('/home/qian-qi/Documents/Codex/2026-10-22/github-trillionnium-chain-https-github-com')
work = project / 'work'
out = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'worktrees': [], 'coordination': [], 'native_validation': []}
for name in ['chain-tcl4-integration-20261024', 'hepta-windows-portable-tools-20261024',
             'hepta-selected-initial-prepared-host-20261025', 'chain-model-release-closure-20261025',
             'hepta-cell-material-consumer-20261025']:
    directory = work / name
    entry = {'name': name}
    for label, arguments in [('head', ['rev-parse', 'HEAD']), ('status', ['status', '--short'])]:
        r = subprocess.run(['git', '-C', str(directory), *arguments], capture_output=True, text=True, timeout=10)
        entry[label] = {'exit_code': r.returncode, 'stdout': r.stdout[:16000], 'stderr': r.stderr[:2000]}
    out['worktrees'].append(entry)

coord = work / 'coordination'
for directory in [coord, coord / 'inbox']:
    if directory.is_dir():
        out['coordination'].append({'directory': str(directory), 'entries': sorted(p.name for p in directory.iterdir())[:300]})
inbox = coord / 'inbox'
if inbox.is_dir():
    for directory in sorted(inbox.iterdir()):
        if directory.is_dir() and directory.name.startswith('local-codex-'):
            candidates = []
            for p in sorted(directory.iterdir()):
                if p.is_file() and not p.is_symlink() and ('ack' in p.name.lower() or 'accepted' in p.name.lower()) and p.stat().st_size <= 65536:
                    data = p.read_bytes()
                    candidates.append({'name': p.name, 'sha256': hashlib.sha256(data).hexdigest(), 'content': data.decode('utf-8', errors='replace')})
            out['coordination'].append({'inbox': directory.name, 'explicit_ack_candidates': candidates})

directory = work / 'hepta-selected-initial-prepared-host-validation-20261025'
if directory.is_dir():
    rows = []
    for p in directory.iterdir():
        if p.is_file() and not p.is_symlink():
            s = p.stat()
            rows.append({'name': p.name, 'bytes': s.st_size, 'mtime_ns': s.st_mtime_ns})
    out['native_validation'] = sorted(rows, key=lambda row: row['mtime_ns'], reverse=True)[:80]
print(json.dumps(out, ensure_ascii=False, sort_keys=True))
