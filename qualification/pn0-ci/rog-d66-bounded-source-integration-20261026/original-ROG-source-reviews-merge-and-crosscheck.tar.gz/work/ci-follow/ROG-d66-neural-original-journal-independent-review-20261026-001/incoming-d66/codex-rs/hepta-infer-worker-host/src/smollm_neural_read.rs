//! Host composition for real SmolLM parameters in the ordinary cognitive read.
//! Uses the existing inference worker, durable control journal and kernel
//! FinalUse issuer. This module issues no authority and selects no artifact.

use std::sync::Arc;
use std::sync::Mutex;
use std::sync::atomic::AtomicBool;
use std::sync::atomic::AtomicU64;
use std::sync::atomic::Ordering;
use std::time::Duration;
use std::time::SystemTime;
use std::time::UNIX_EPOCH;

use codex_hepta_agentd::NeuralCognitiveInferencePortV1;
use codex_hepta_agentd::NeuralCognitiveObservationV1;
use codex_hepta_agentd::NeuralCognitivePinV1;
use codex_hepta_agentd::NeuralCognitiveRequestV1;
use codex_hepta_contracts::AgentId;
use codex_hepta_contracts::FinalUseBinding;
use codex_hepta_infer_core::durable_control::Assignment;
use codex_hepta_infer_core::durable_control::DurableInferenceControl;
use codex_hepta_infer_core::durable_control::InferenceRequest;
use codex_hepta_infer_core::durable_control::RequestState;
use codex_hepta_infer_core::durable_control::Reservation;
use codex_hepta_infer_core::durable_control::TerminalObservation;
use codex_hepta_types::AuthorityPosture;
use codex_hepta_types::Digest32;
use codex_hepta_types::StableId;
use tokio_util::sync::CancellationToken;

use crate::model_worker::ExecutionStatus;
use crate::model_worker::InferenceWorker;
use crate::model_worker::ModelManifest;
use crate::model_worker::ResourceGrant;
use crate::model_worker::WorkerRequest;
use crate::native_app_server::TurnStartAuthorizer;

#[path = "smollm_neural_driver.rs"]
mod driver;
use driver::Exchange;
use driver::Mailbox;

#[path = "smollm_neural_query.rs"]
mod query;
#[path = "smollm_neural_settled_read.rs"]
mod settled;
pub use driver::SmolLmCellStartOwnerV1;
use driver::SmolLmDriver;
pub use driver::SmolLmFirstExchangeFailureV1;
pub use driver::SmolLmFixedInitialBackboneProofV1;
pub use driver::SmolLmMeasuredForwardV1;
pub use driver::SmolLmMeasuredLoadV1;
pub use driver::SmolLmNeuralReadConfigV1;
pub use driver::VerifiedCellMaterialV1;
pub use driver::verify_controlled_cell_material_v1;

#[path = "smollm_runtime_identity.rs"]
pub(crate) mod runtime_identity;
use runtime_identity::SmolLmRuntimeIdentityV1;

static REQUEST_SEQUENCE: AtomicU64 = AtomicU64::new(1);

struct ControlContext {
    control: Arc<Mutex<DurableInferenceControl>>,
    authorizer: Arc<dyn TurnStartAuthorizer>,
    runtime: tokio::runtime::Handle,
    owner_id: AgentId,
    body_generation: u64,
    worker_id: String,
    grant: ResourceGrant,
    model_digest: String,
}

struct Admitted {
    request_id: String,
    reservation_id: String,
    payload_digest: String,
    deadline_ms: u64,
    revision: u64,
}

impl ControlContext {
    fn admit(&self, payload: Digest32, timeout_ms: u64) -> Result<Admitted, String> {
        let now = now_ms()?;
        let request_id = format!(
            "neural-{now}-{}",
            REQUEST_SEQUENCE.fetch_add(1, Ordering::Relaxed)
        );
        let reservation_id = format!("reservation-{request_id}");
        let deadline_ms = now
            .checked_add(timeout_ms)
            .ok_or("neural deadline overflow")?;
        if deadline_ms > self.grant.expires_at_ms {
            return Err("neural resource grant expires before the operation".to_owned());
        }
        let payload_digest = payload.to_string();
        let mut control = self
            .control
            .lock()
            .map_err(|_| "original inference control poisoned")?;
        let submitted = control
            .submit(
                now,
                InferenceRequest {
                    request_id: request_id.clone(),
                    principal_id: self.owner_id.as_str().to_owned(),
                    model_digest: self.model_digest.clone(),
                    payload_digest: payload_digest.clone(),
                    maximum_tokens: 1,
                    deadline_ms,
                    semantic_digest: self.grant.semantic_digest.clone(),
                },
            )
            .map_err(|error| error.to_string())?;
        // A reused or recovered dispatch is never replayed by this adapter.
        if submitted.idempotent {
            return Err("neural request already exists; owner reconciliation required".to_owned());
        }
        let reserved = control
            .reserve(
                now,
                &request_id,
                submitted.revision,
                Reservation {
                    reservation_id: reservation_id.clone(),
                    quota_units: 1,
                    maximum_tokens: 1,
                    authority_epoch: self.grant.authority_epoch,
                    valid_until_ms: deadline_ms,
                },
            )
            .map_err(|error| error.to_string())?;
        let assigned = control
            .assign(
                &request_id,
                reserved.revision,
                Assignment {
                    worker_id: self.worker_id.clone(),
                    worker_generation: self.grant.generation,
                    assignment_digest: Digest32::of_parts(&[
                        b"hepta.smollm-assignment.v1\0",
                        payload.as_array(),
                        request_id.as_bytes(),
                    ])
                    .to_string(),
                },
            )
            .map_err(|error| error.to_string())?;
        Ok(Admitted {
            request_id,
            reservation_id,
            payload_digest,
            deadline_ms,
            revision: assigned.revision,
        })
    }

    fn enter(
        &self,
        admitted: &Admitted,
        scope: Digest32,
        execution: &codex_hepta_agentd::NeuralCognitiveExecutionV1,
    ) -> Result<codex_hepta_contracts::EnteredUseToken, String> {
        execution.check()?;
        let resource_scope = serde_json::to_vec(&(
            "hepta.smollm-final-use-resource.v1",
            scope.to_string(),
            self.owner_id.as_str(),
            self.body_generation,
            &self.grant.grant_id,
            self.grant.authority_epoch,
            self.grant.generation,
            self.grant.expires_at_ms,
            self.grant.revoked,
            self.grant.maximum_models,
            self.grant.maximum_active_requests,
            self.grant.maximum_memory_bytes,
            &self.grant.semantic_digest,
        ))
        .map_err(|error| error.to_string())?;
        let binding = FinalUseBinding {
            subject_id: self.owner_id.as_str().to_owned(),
            destination_id: self.worker_id.clone(),
            request_sha256: Digest32::of_parts(&[
                b"hepta.smollm-final-use.v1\0",
                admitted.request_id.as_bytes(),
                self.model_digest.as_bytes(),
                admitted.payload_digest.as_bytes(),
            ])
            .into_array(),
            scope_sha256: Digest32::of_bytes(&resource_scope).into_array(),
            payload_sha256: admitted
                .payload_digest
                .parse::<Digest32>()
                .map_err(|error| error.to_string())?
                .into_array(),
        };
        execution.check()?;
        let claim_deadline = execution
            .deadline()
            .min(std::time::Instant::now() + Duration::from_millis(250));
        let token = self.runtime.block_on(async {
            tokio::select! {
                biased;
                _ = execution.cancelled() => Err("neural read execution cancelled before final-use entry".to_owned()),
                result = tokio::time::timeout_at(
                    tokio::time::Instant::from_std(claim_deadline), self.authorizer.claim(binding.clone()),
                ) => result.map_err(|_| "original final-use claim timed out".to_owned())?
                    .map_err(|error| error.to_string()),
            }
        })?;
        // A successful claim still consumes its original nonce when cancellation
        // wins here. Never refund it or enter the effect after caller expiry.
        execution.check()?;
        token.enter(&binding).map_err(|error| error.to_string())
    }

    fn settle_load(
        &self,
        admitted: &Admitted,
        observed: Digest32,
        execution: &codex_hepta_agentd::NeuralCognitiveExecutionV1,
    ) -> Result<(), String> {
        self.settle(admitted, Some(observed), true, 0)?;
        // Durable control may wait. Reject late delivery without rewriting the
        // real completion or refunding its already consumed FinalUse nonce.
        execution.check()
    }

    fn settle(
        &self,
        admitted: &Admitted,
        output: Option<Digest32>,
        terminal: bool,
        tokens: u32,
    ) -> Result<(), String> {
        let status = if terminal {
            Some(if output.is_some() {
                RequestState::Completed
            } else {
                RequestState::Failed
            })
        } else {
            None
        };
        let evidence = Digest32::of_parts(&[
            b"hepta.smollm-observation.v1\0",
            admitted.request_id.as_bytes(),
            output.unwrap_or(Digest32::ZERO).as_array(),
            &[u8::from(terminal)],
            &tokens.to_be_bytes(),
        ]);
        self.control
            .lock()
            .map_err(|_| "original inference control poisoned")?
            .settle(
                &admitted.request_id,
                admitted.revision,
                evidence.to_string(),
                TerminalObservation {
                    request_id: admitted.request_id.clone(),
                    reservation_id: admitted.reservation_id.clone(),
                    worker_id: self.worker_id.clone(),
                    worker_generation: self.grant.generation,
                    model_digest: self.model_digest.clone(),
                    payload_digest: admitted.payload_digest.clone(),
                    terminal_observed: terminal,
                    terminal_status: status,
                    output_digest: output.map(|value| value.to_string()),
                    consumed_tokens: tokens,
                    usage_units: u64::from(tokens),
                },
            )
            .map_err(|error| error.to_string())?;
        Ok(())
    }
}

/// One qualified parameter consumer's warm model in the original inference
/// owner. Start it before enabling the Agentd read route; cold loading is not
/// hidden inside the normal two-second cognitive request deadline.
pub struct SmolLmNeuralReadPortV1 {
    pin: Option<NeuralCognitivePinV1>,
    model_id: String,
    physical: SmolLmRuntimeIdentityV1,
    scope: Digest32,
    context: ControlContext,
    worker: Mutex<InferenceWorker<SmolLmDriver>>,
    mailbox: Mailbox,
    admission_closed: AtomicBool,
}

impl SmolLmNeuralReadPortV1 {
    /// The embedding owner supplies its existing journal, resource grant and
    /// original FinalUse authorizer. No key or authority is constructed here.
    /// Call on the host's blocking executor, as the ordinary ranker already does.
    #[allow(clippy::too_many_arguments)]
    pub fn start(
        config: SmolLmNeuralReadConfigV1,
        pin: NeuralCognitivePinV1,
        parameter_bytes: Vec<u8>,
        owner_id: AgentId,
        body_generation: u64,
        worker_id: String,
        grant: ResourceGrant,
        control: Arc<Mutex<DurableInferenceControl>>,
        authorizer: Arc<dyn TurnStartAuthorizer>,
        runtime: tokio::runtime::Handle,
    ) -> Result<Self, String> {
        Self::start_cancellable(
            config,
            pin,
            parameter_bytes,
            owner_id,
            body_generation,
            worker_id,
            grant,
            control,
            authorizer,
            runtime,
            CancellationToken::new(),
        )
    }

    /// Startup cancellation never claims terminal inference completion. The
    /// original driver session retains its observed child until cleanup.
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn start_cancellable(
        config: SmolLmNeuralReadConfigV1,
        pin: NeuralCognitivePinV1,
        parameter_bytes: Vec<u8>,
        owner_id: AgentId,
        body_generation: u64,
        worker_id: String,
        grant: ResourceGrant,
        control: Arc<Mutex<DurableInferenceControl>>,
        authorizer: Arc<dyn TurnStartAuthorizer>,
        runtime: tokio::runtime::Handle,
        cancellation: CancellationToken,
    ) -> Result<Self, String> {
        let identity = SmolLmRuntimeIdentityV1::from(&pin);
        let scope = pin.compatibility_digest();
        Self::start_physical(
            config,
            Some(pin),
            identity,
            scope,
            parameter_bytes,
            owner_id,
            body_generation,
            worker_id,
            grant,
            control,
            authorizer,
            runtime,
            cancellation,
        )
    }

    // Initial loading has no evaluated pin, even at this internal boundary.
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn start_initial_cancellable(
        config: SmolLmNeuralReadConfigV1,
        identity: SmolLmRuntimeIdentityV1,
        scope: Digest32,
        parameter_bytes: Vec<u8>,
        owner_id: AgentId,
        body_generation: u64,
        worker_id: String,
        grant: ResourceGrant,
        control: Arc<Mutex<DurableInferenceControl>>,
        authorizer: Arc<dyn TurnStartAuthorizer>,
        runtime: tokio::runtime::Handle,
        cancellation: CancellationToken,
    ) -> Result<Self, String> {
        Self::start_physical(
            config,
            /*pin*/ None,
            identity,
            scope,
            parameter_bytes,
            owner_id,
            body_generation,
            worker_id,
            grant,
            control,
            authorizer,
            runtime,
            cancellation,
        )
    }

    // Shared private lifecycle; only the old constructor can supply a full pin.
    #[allow(clippy::too_many_arguments)]
    fn start_physical(
        config: SmolLmNeuralReadConfigV1,
        pin: Option<NeuralCognitivePinV1>,
        identity: SmolLmRuntimeIdentityV1,
        scope: Digest32,
        parameter_bytes: Vec<u8>,
        owner_id: AgentId,
        body_generation: u64,
        worker_id: String,
        grant: ResourceGrant,
        control: Arc<Mutex<DurableInferenceControl>>,
        authorizer: Arc<dyn TurnStartAuthorizer>,
        runtime: tokio::runtime::Handle,
        cancellation: CancellationToken,
    ) -> Result<Self, String> {
        if cancellation.is_cancelled() {
            return Err("neural worker startup cancelled before admission".to_owned());
        }
        let now = now_ms()?;
        if body_generation == 0
            || grant.maximum_models != 1
            || grant.maximum_active_requests != 1
            || grant.maximum_memory_bytes != 8 * 1024 * 1024 * 1024
            || grant.expires_at_ms < now.saturating_add(720_000)
            || config.execution_profile_digest()? != identity.execution_profile_digest
            || Digest32::of_bytes(&parameter_bytes) != identity.payload_digest
        {
            return Err(
                "neural worker requires its exact bounded resource and parameter profile"
                    .to_owned(),
            );
        }
        let model_id = format!("smollm-read-{}", identity.payload_digest);
        let model_domain: &[u8] = if pin.is_some() {
            b"hepta.smollm-read-model.v1\0"
        } else {
            b"hepta.smollm.selected-initial-runtime-model.v1\0"
        };
        let load_domain: &[u8] = if pin.is_some() {
            b"hepta.smollm-load.v1\0"
        } else {
            b"hepta.smollm.selected-initial-runtime-load.v1\0"
        };
        let model_digest = Digest32::of_parts(&[
            model_domain,
            identity.payload_digest.as_array(),
            identity.family_digest.as_array(),
            identity.execution_profile_digest.as_array(),
        ])
        .to_string();
        let manifest = ModelManifest {
            model_id: model_id.clone(),
            model_digest: model_digest.clone(),
            weights_digest: identity.payload_digest.to_string(),
            tokenizer_digest: config.tokenizer_digest.to_string(),
            preprocessor_digest: identity.execution_profile_digest.to_string(),
            quantization_digest: Digest32::of_bytes(b"float32-unquantized").to_string(),
            runtime_digest: identity.execution_profile_digest.to_string(),
            device_digest: Digest32::of_bytes(b"cpu-eager-float32-threads-4").to_string(),
            maximum_tokens: 1,
        };
        let context = ControlContext {
            control,
            authorizer,
            runtime,
            owner_id,
            body_generation,
            worker_id: worker_id.clone(),
            grant: grant.clone(),
            model_digest,
        };
        let load_execution = codex_hepta_agentd::NeuralCognitiveExecutionV1::with_deadline(
            std::time::Instant::now() + Duration::from_secs(120),
            cancellation.clone(),
        );
        let mailbox = Arc::new(Mutex::new(Default::default()));
        let driver = SmolLmDriver::new(
            config,
            identity.clone(),
            parameter_bytes,
            mailbox.clone(),
            context.runtime.clone(),
            cancellation,
            load_execution.deadline(),
        );
        let mut worker = InferenceWorker::new(now, worker_id, grant.generation, grant, driver)
            .map_err(|error| error.to_string())?;
        let admitted = context.admit(
            Digest32::of_parts(&[
                load_domain,
                context.owner_id.as_str().as_bytes(),
                &context.body_generation.to_be_bytes(),
                identity.payload_digest.as_array(),
                identity.execution_profile_digest.as_array(),
            ]),
            120_000,
        )?;
        let entered = match context.enter(&admitted, scope, &load_execution) {
            Ok(token) => token,
            Err(error) => {
                context.settle(&admitted, None, true, 0)?;
                return Err(error);
            }
        };
        let loaded = worker.load_model(now_ms()?, manifest);
        drop(entered);
        let loaded = match loaded {
            Ok(value) => value,
            Err(error) => {
                context.settle(&admitted, None, false, 0)?;
                return Err(error.to_string());
            }
        };
        if let Err(error) = load_execution.check() {
            context.settle(&admitted, None, false, 0)?;
            return Err(error);
        }
        let observed = Digest32::of_parts(&[
            b"hepta.smollm-loaded.v1\0",
            loaded.handle_id.as_bytes(),
            &loaded.observed_memory_bytes.to_be_bytes(),
        ]);
        context.settle_load(&admitted, observed, &load_execution)?;
        mailbox
            .lock()
            .map_err(|_| "neural exchange poisoned")?
            .measurements
            .settle_load_output(&admitted, observed)?;
        Ok(Self {
            pin,
            model_id,
            physical: identity,
            scope,
            context,
            worker: Mutex::new(worker),
            mailbox,
            admission_closed: AtomicBool::new(false),
        })
    }

    /// Observe one original settled load and the last settled forward only.
    /// These borrowed historical receipts grant no current execution authority.
    /// The bounded read-only closure must not reenter this port or dispatch effects.
    pub fn with_measurements<T>(
        &self,
        consume: impl FnOnce(&SmolLmMeasuredLoadV1, Option<&SmolLmMeasuredForwardV1>) -> T,
    ) -> Result<T, String> {
        // Match execute/shutdown lock order; an observer never queues a read
        // behind an arbitrary callback after that read has been admitted.
        let _worker = self
            .worker
            .try_lock()
            .map_err(|_| "original neural worker is active or poisoned")?;
        if self.admission_closed.load(Ordering::SeqCst) {
            return Err("neural session has unresolved physical execution".to_owned());
        }
        self.mailbox
            .lock()
            .map_err(|_| "neural exchange poisoned")?
            .measurements
            .observe(consume)
    }

    /// Read the sticky original failure only, including after admission closes.
    /// This passive snapshot cannot restore Ready, model or effect authority.
    pub fn first_exchange_failure(&self) -> Result<Option<SmolLmFirstExchangeFailureV1>, String> {
        let _worker = self
            .worker
            .try_lock()
            .map_err(|_| "original neural worker is active or poisoned")?;
        Ok(self
            .mailbox
            .try_lock()
            .map_err(|_| "original neural mailbox is active or poisoned")?
            .first_failure)
    }

    /// Explicit original-owner unload. Success requires the Python supervisor's
    /// exact terminal wait4/RSS receipt; asynchronous Drop cleanup earns no such
    /// completion. Call from the same blocking host executor used by start.
    pub fn shutdown(&self) -> Result<(), String> {
        let mut worker = self
            .worker
            .try_lock()
            .map_err(|_| "original neural worker is active or poisoned")?;
        self.mailbox
            .lock()
            .map_err(|_| "neural exchange poisoned")?
            .measurements
            .suspend();
        let observed = worker
            .unload_model(now_ms()?, &self.model_id)
            .map_err(|error| error.to_string())?;
        if !observed.terminal_observed {
            return Err("neural unload terminal observation missing".to_owned());
        }
        Ok(())
    }
}

impl SmolLmNeuralReadPortV1 {
    fn execute_physical(
        &self,
        query: &str,
        action_ids: &[StableId],
        payload: Digest32,
        scope: Digest32,
        execution: &codex_hepta_agentd::NeuralCognitiveExecutionV1,
    ) -> Result<(Option<Vec<i64>>, Digest32), String> {
        execution.check()?;
        if self.admission_closed.load(Ordering::SeqCst) {
            return Err(
                "neural session has unresolved physical execution; unload required".to_owned(),
            );
        }
        if query.is_empty() || query.len() > 2048 || action_ids.is_empty() || action_ids.len() > 128
        {
            return Err("neural query exceeds its original registered bounds".to_owned());
        }
        // Queueing behind another call could outlive the ordinary read request
        // and then execute after its caller had already timed out.
        let mut worker = self
            .worker
            .try_lock()
            .map_err(|_| "original neural worker is active or poisoned")?;
        // Keep the original read admission cap even for a direct host caller
        // supplying a longer startup/evaluation window. This can only shorten
        // the original caller's remaining window, never renew it.
        let remaining_ms = u64::try_from(execution.remaining()?.as_millis())
            .map_err(|error| error.to_string())?
            .min(2_000);
        if remaining_ms == 0 {
            return Err("neural read execution deadline".to_owned());
        }
        let admitted = self.context.admit(payload, remaining_ms)?;
        let entered = match self.context.enter(&admitted, scope, execution) {
            Ok(token) => token,
            Err(error) => {
                self.context.settle(&admitted, None, true, 0)?;
                return Err(error);
            }
        };
        let mut mailbox = self
            .mailbox
            .lock()
            .map_err(|_| "neural exchange poisoned")?;
        mailbox.measurements.clear_forward();
        mailbox.exchange = Some(Exchange {
            query: query.to_owned(),
            execution: execution.clone(),
            request_id: admitted.request_id.clone(),
            payload_digest: admitted.payload_digest.clone(),
            response: None,
        });
        drop(mailbox);
        if let Err(error) = execution.check() {
            self.mailbox
                .lock()
                .map_err(|_| "neural exchange poisoned")?
                .exchange
                .take();
            self.context.settle(&admitted, None, true, 0)?;
            return Err(error);
        }
        let observed = worker.run(
            now_ms()?,
            &self.model_id,
            WorkerRequest {
                request_id: admitted.request_id.clone(),
                reservation_id: admitted.reservation_id.clone(),
                model_digest: self.context.model_digest.clone(),
                payload_digest: admitted.payload_digest.clone(),
                maximum_tokens: 1,
                deadline_ms: admitted.deadline_ms,
                lease_payload_digest: admitted.payload_digest.clone(),
                reservation_model_digest: self.context.model_digest.clone(),
                reservation_maximum_tokens: 1,
                cancelled: false,
            },
        );
        drop(entered);
        let observed = match observed {
            Ok(value) => value,
            Err(error) => {
                self.admission_closed.store(true, Ordering::SeqCst);
                self.mailbox
                    .lock()
                    .map_err(|_| "neural exchange poisoned")?
                    .exchange
                    .take();
                self.context.settle(&admitted, None, false, 0)?;
                return Err(error.to_string());
            }
        };
        let exchange = self
            .mailbox
            .lock()
            .map_err(|_| "neural exchange poisoned")?
            .exchange
            .take()
            .ok_or("neural observation missing")?;
        let (response, receipt, raw_response) = exchange
            .response
            .ok_or("neural terminal response missing")?;
        if execution.check().is_err()
            || observed.status != ExecutionStatus::Succeeded
            || !observed.terminal_observed
            || observed.output_digest != Some(receipt.to_string())
            || now_ms()? > admitted.deadline_ms
        {
            self.admission_closed.store(true, Ordering::SeqCst);
            self.context.settle(
                &admitted,
                None,
                observed.terminal_observed,
                observed.consumed_tokens,
            )?;
            return Err(
                "neural operation did not complete within its original admission".to_owned(),
            );
        }
        self.context
            .settle(&admitted, Some(receipt), true, observed.consumed_tokens)?;
        let mut mailbox = self
            .mailbox
            .lock()
            .map_err(|_| "neural exchange poisoned")?;
        mailbox
            .measurements
            .retain_forward(&admitted, &raw_response, receipt)?;
        if let Err(error) = execution.check() {
            mailbox.measurements.clear_forward();
            return Err(error);
        }
        drop(mailbox);
        let scores = action_ids
            .iter()
            .map(|action| {
                response
                    .action_ids
                    .iter()
                    .position(|value| value == action.as_str())
                    .map(|index| response.scores_q32[index])
            })
            .collect::<Option<Vec<_>>>();
        Ok((scores, receipt))
    }
}

fn now_ms() -> Result<u64, String> {
    u64::try_from(
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|error| error.to_string())?
            .as_millis(),
    )
    .map_err(|error| error.to_string())
}

#[cfg(test)]
#[path = "smollm_neural_read_tests.rs"]
mod tests;
