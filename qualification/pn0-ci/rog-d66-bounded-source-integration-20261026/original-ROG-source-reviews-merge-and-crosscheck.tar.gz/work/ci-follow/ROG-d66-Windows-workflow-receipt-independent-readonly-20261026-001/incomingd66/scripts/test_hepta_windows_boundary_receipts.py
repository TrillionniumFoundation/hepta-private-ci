"""Synthetic receipt-parser controls; no Windows test is executed here."""

import ast
import json
import os
import re
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
import unittest

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = ROOT / ".github/workflows/hepta-windows-delete-boundary.yml"


def reader():
    text = WORKFLOW.read_text()
    start = text.index("          import hashlib, json, os, re, sys\n")
    end = text.index("          PY\n", start)
    return textwrap.dedent(text[start:end])


def owner_cases(source):
    for node in ast.parse(source).body:
        if isinstance(node, ast.Assign) and any(
            isinstance(n, ast.Name) and n.id == "owner_selectors" for n in node.targets
        ):
            return ast.literal_eval(node.value)
    raise AssertionError("missing complete library case inventory")


VOLUME = (
    "native_local_ntfs_file_and_directory_report_same_volume",
    "native_nondisk_handle_is_rejected",
    "native_volume_observation_stays_bound_to_renamed_held_object",
    "native_directory_volume_observation_stays_bound_after_rename",
)
LOCK = (
    "native_owner_lock_child",
    "actual_second_process_reports_state_locked_then_owner_drop_releases",
    "actual_natural_process_exit_releases_original_os_lock_without_destructor",
    "actual_cold_missing_marker_and_nonempty_marker_never_reset",
)
PRINCIPAL = (
    "native_same_effective_token_revalidates",
    "native_same_sid_replacement_is_refused_and_cannot_revive",
    "native_held_token_modification_is_refused",
    "native_degraded_and_unqueryable_thread_tokens_never_fall_back",
)


def log(cases, *, passed=None, skipped=0, failed=0):
    return "".join(f"test {name} ... ok\n" for name in cases) + (
        f"Summary [0.123s] {len(cases)} tests run: {len(cases) if passed is None else passed} passed, {failed} failed, {skipped} skipped\n"
    )


def volume_markers():
    return "".join(
        "HEPTA_LOCAL_NTFS_OBSERVATION "
        + json.dumps(
            {
                "stage": stage,
                "owner_supported": False,
                "trusted_parent": False,
                "power_loss_qualified": False,
            }
        )
        + "\n"
        for stage in (
            "local_ntfs_complete",
            "nondisk_complete",
            "held_binding_complete",
            "held_directory_binding_complete",
        )
    )


class WindowsBoundaryReceiptTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = reader()
        cls.cases = owner_cases(cls.source)

    def test_native_host_must_match_the_fixed_runner_and_target(self):
        definition = next(
            node
            for node in ast.parse(self.source).body
            if isinstance(node, ast.FunctionDef) and node.name == "native_identity"
        )
        namespace = {}
        exec(
            compile(
                ast.Module(body=[definition], type_ignores=[]),
                "native-identity",
                "exec",
            ),
            namespace,
        )
        identity = namespace["native_identity"]
        for runner, target, arch in (
            ("windows-latest", "x86_64-pc-windows-msvc", "X64"),
            ("windows-11-arm", "aarch64-pc-windows-msvc", "ARM64"),
        ):
            lines = ["host: " + target, "release: 1.96.0"]
            self.assertEqual(
                identity(runner, target, "Windows", arch, lines)["target"], target
            )
            invalid = (
                ("unknown", target, "Windows", arch, lines),
                (runner, "wrong-target", "Windows", arch, lines),
                (runner, target, "Linux", arch, lines),
                (runner, target, "Windows", "wrong-arch", lines),
                (runner, target, "Windows", arch, ["host: wrong", "release: 1.96.0"]),
                (runner, target, "Windows", arch, lines + [lines[0]]),
                (runner, target, "Windows", arch, [lines[0], "release: 1.95.0"]),
            )
            for arguments in invalid:
                with (
                    self.subTest(arguments=arguments),
                    self.assertRaises(AssertionError),
                ):
                    identity(*arguments)

    def test_every_filtered_group_requires_one_exact_complete_named_result_set(self):
        assignments = {
            target.id: node
            for node in ast.parse(self.source).body
            if isinstance(node, ast.Assign)
            for target in node.targets
            if isinstance(target, ast.Name)
        }
        namespace = {}
        selected = [
            assignments[name]
            for name in ("probes", "acl_selectors", "filtered_selectors")
        ]
        exec(
            compile(
                ast.Module(body=selected, type_ignores=[]), "filtered-selectors", "exec"
            ),
            namespace,
        )
        operations = ast.literal_eval(assignments["operations"].value)
        groups = namespace["filtered_selectors"]
        self.assertEqual(len(groups), 14)
        for name, cases in groups.items():
            markers = ""
            if name in namespace["probes"]:
                complete = namespace["probes"][name][1]
                records = [
                    {
                        "stage": stage,
                        "result": {"ok": expected},
                        "owner_supported": False,
                        "power_loss_qualified": False,
                    }
                    for stage, expected in operations[name].items()
                ] + [
                    {
                        "stage": complete,
                        "owner_supported": False,
                        "power_loss_qualified": False,
                    }
                ]
                markers = "".join(
                    "HEPTA_PRIVATE_STATE_NATIVE_PROBE " + json.dumps(row) + "\n"
                    for row in records
                )
            elif name == "full-restriction-candidate":
                markers = (
                    "HEPTA_FULL_RESTRICTION_CANDIDATE "
                    + json.dumps(
                        {
                            "stage": "original_operations_complete",
                            "readonly_controls": True,
                            "explicit_read_execute": True,
                            "production_admitted": False,
                        }
                    )
                    + "\n"
                )
            complete = markers + log(cases, skipped=200)
            with self.subTest(name=name):
                self.assertEqual(self.evaluate(name, len(cases), complete), 0)
                invalid = (
                    markers + log(("unregistered::wrong_test",), passed=len(cases)),
                    complete + "test " + cases[0] + " ... ok\n",
                    complete + log(cases),
                    markers + log(cases[:-1], passed=len(cases)),
                    markers + log(cases, failed=1),
                )
                for text in invalid:
                    self.assertEqual(self.evaluate(name, len(cases), text), 1)

    def evaluate(self, tag, minimum, text, *, codes="0 0"):
        with tempfile.TemporaryDirectory(
            prefix="windows-receipt-parser-only-"
        ) as temporary:
            out = Path(temporary) / "windows-delete-boundary"
            out.mkdir()
            (out / (tag + ".log")).write_text(text)
            result = subprocess.run(
                [
                    sys.executable,
                    "-B",
                    "-c",
                    self.source,
                    "tests",
                    tag,
                    str(minimum),
                    codes,
                ],
                cwd=ROOT,
                env={**os.environ, "RUNNER_TEMP": temporary},
                capture_output=True,
                timeout=10,
            )
            self.assertEqual(result.stderr, b"")
            receipt = json.loads((out / (tag + ".json")).read_text())
            self.assertEqual(
                result.returncode, 0 if receipt["status"] == "passed" else 1
            )
            return result.returncode

    def test_complete_library_receipt_and_original_descriptors_are_required(self):
        self.assertEqual(len(self.cases), 40)
        self.assertEqual(len(set(self.cases)), 40)
        self.assertEqual(
            sum(name.startswith("security::tests::") for name in self.cases), 5
        )
        self.assertEqual(
            self.evaluate("private-owner-descriptor", 40, log(self.cases)), 0
        )
        self.assertEqual(
            self.evaluate("private-owner-descriptor", 5, log(self.cases)), 1
        )
        original = tuple(
            name for name in self.cases if name.startswith("security::tests::")
        )
        self.assertEqual(
            self.evaluate("private-owner-descriptor", 40, log(original)), 1
        )

    def test_every_missing_library_case_refuses_even_with_a_green_total(self):
        for name in self.cases:
            with self.subTest(name=name):
                missing = tuple(value for value in self.cases if value != name)
                self.assertEqual(
                    self.evaluate(
                        "private-owner-descriptor", 40, log(missing, passed=40)
                    ),
                    1,
                )

    def test_duplicate_and_unknown_named_results_refuse(self):
        for extra in (self.cases[0], "unregistered::case"):
            with self.subTest(extra=extra):
                text = "test " + extra + " ... ok\n" + log(self.cases)
                self.assertEqual(self.evaluate("private-owner-descriptor", 40, text), 1)

    def test_failures_skips_mismatched_totals_and_logging_failures_refuse(self):
        for kwargs in ({"passed": 39}, {"skipped": 1}, {"failed": 1}):
            with self.subTest(kwargs=kwargs):
                self.assertEqual(
                    self.evaluate(
                        "private-owner-descriptor", 40, log(self.cases, **kwargs)
                    ),
                    1,
                )
        self.assertEqual(
            self.evaluate("private-owner-descriptor", 40, log(self.cases), codes="0 1"),
            1,
        )

    def test_original_filtered_acl_selection_still_requires_every_selected_case(self):
        tree = ast.parse(self.source)
        cases = next(
            ast.literal_eval(node.value)
            for node in tree.body
            if isinstance(node, ast.Assign)
            and any(
                isinstance(n, ast.Name) and n.id == "acl_selectors"
                for n in node.targets
            )
        )
        self.assertEqual(
            self.evaluate("acl-unit-controls", 8, log(cases, skipped=13)), 0
        )
        self.assertEqual(
            self.evaluate(
                "acl-unit-controls", 8, log(cases[:-1], passed=8, skipped=13)
            ),
            1,
        )

    def test_original_volume_controls_and_new_held_directory_are_all_required(self):
        complete = volume_markers() + log(VOLUME)
        self.assertEqual(self.evaluate("private-local-ntfs", 4, complete), 0)
        for index in range(4):
            with self.subTest(index=index):
                markers = volume_markers().splitlines(keepends=True)
                self.assertEqual(
                    self.evaluate(
                        "private-local-ntfs",
                        4,
                        "".join(markers[:index] + markers[index + 1 :]) + log(VOLUME),
                    ),
                    1,
                )
                self.assertEqual(
                    self.evaluate(
                        "private-local-ntfs",
                        4,
                        volume_markers() + log(VOLUME[:index] + VOLUME[index + 1 :]),
                    ),
                    1,
                )

    def test_all_real_owner_lock_process_cases_are_required(self):
        self.assertEqual(self.evaluate("private-owner-lock", 4, log(LOCK)), 0)
        for index in range(4):
            with self.subTest(index=index):
                self.assertEqual(
                    self.evaluate(
                        "private-owner-lock",
                        4,
                        log(LOCK[:index] + LOCK[index + 1 :], passed=4),
                    ),
                    1,
                )

    def test_multiple_or_missing_terminal_summaries_refuse(self):
        text = log(self.cases)
        for value in (text + text, "\n".join(text.splitlines()[:-1]) + "\n"):
            with self.subTest(value=value[-80:]):
                self.assertEqual(
                    self.evaluate("private-owner-descriptor", 40, value), 1
                )

    def test_all_principal_cases_require_exact_names_and_no_skips(self):
        self.assertEqual(
            self.evaluate("private-principal-continuity", 4, log(PRINCIPAL)), 0
        )
        for index in range(4):
            with self.subTest(index=index):
                self.assertEqual(
                    self.evaluate(
                        "private-principal-continuity",
                        4,
                        log(PRINCIPAL[:index] + PRINCIPAL[index + 1 :], passed=4),
                    ),
                    1,
                )
        for extra in (PRINCIPAL[0], "unregistered::principal"):
            with self.subTest(extra=extra):
                self.assertEqual(
                    self.evaluate(
                        "private-principal-continuity",
                        4,
                        "test " + extra + " ... ok\n" + log(PRINCIPAL),
                    ),
                    1,
                )
        self.assertEqual(
            self.evaluate("private-principal-continuity", 4, log(PRINCIPAL, skipped=1)),
            1,
        )

    def test_original_store_receipts_require_every_selected_native_case(self):
        tree = ast.parse(self.source)
        targets = next(
            ast.literal_eval(node.value)
            for node in tree.body
            if isinstance(node, ast.Assign)
            and any(
                isinstance(target, ast.Name) and target.id == "store_selectors"
                for target in node.targets
            )
        )
        self.assertEqual(
            {name: len(cases) for name, cases in targets.items()},
            {"original-final-use-windows": 7, "original-registry-windows": 3},
        )
        for name, cases in targets.items():
            count = len(cases)
            with self.subTest(name=name):
                self.assertEqual(self.evaluate(name, count, log(cases, skipped=200)), 0)
                for index in range(count):
                    missing = cases[:index] + cases[index + 1 :]
                    self.assertEqual(
                        self.evaluate(name, count, log(missing, passed=count)), 1
                    )
                for extra in (cases[0], "unregistered::store"):
                    text = "test " + extra + " ... ok\n" + log(cases)
                    self.assertEqual(self.evaluate(name, count, text), 1)
                self.assertEqual(self.evaluate(name, count, log(cases, failed=1)), 1)
                self.assertEqual(self.evaluate(name, count + 1, log(cases)), 1)

    def test_existing_workflow_executes_complete_targets_without_filters(self):
        text = WORKFLOW.read_text()
        for target in ("--lib", "--test native_owner_lock", "--test native_volume"):
            command = next(
                line
                for line in text.splitlines()
                if "just test --locked -p codex-utils-windows-private-state "
                + target
                + " "
                in line
            )
            self.assertNotIn(" -E ", command)
            self.assertNotIn("--ignored", command)
        self.assertIn('tests private-owner-descriptor 40 "$codes"', text)
        self.assertIn('tests private-local-ntfs 4 "$codes"', text)
        self.assertIn('tests private-owner-lock 4 "$codes"', text)


    def test_new_query_group_requires_exact_source_roster_and_one_complete_summary(self):
        assignment = next(node for node in ast.parse(self.source).body
                          if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name)
                          and target.id == "query_existing_selectors" for target in node.targets))
        cases = ast.literal_eval(assignment.value)
        native = ROOT / "codex-rs/windows-sandbox-rs/src/prepared_filesystem_readback_tests.rs"
        actual = tuple("prepared_filesystem::readback_tests::" + line[3:line.index("(")]
                       for line in native.read_text().splitlines() if line.startswith("fn existing_"))
        self.assertEqual(cases, actual)
        self.assertEqual(len(cases), 6)
        complete = log(cases, skipped=200)
        self.assertEqual(self.evaluate("query-existing-readback", 6, complete), 0)
        invalid = (log(cases[:-1], passed=6), log(("unregistered::wrong",) + cases[1:]),
                   complete + "test " + cases[0] + " ... ok\n", complete + log(cases),
                   log(cases, failed=1), log(cases, passed=5), complete.replace("Summary", "Incomplete"))
        for text in invalid:
            with self.subTest(text=text):
                self.assertEqual(self.evaluate("query-existing-readback", 6, text), 1)
        for codes in ("1 0", "0 1"):
            self.assertEqual(self.evaluate("query-existing-readback", 6, complete, codes=codes), 1)
        self.assertEqual(self.evaluate("query-existing-readback", 5, complete), 1)

    def test_extended_v2_aggregate_still_requires_each_original_twenty_receipt(self):
        assignments = {target.id: node for node in ast.parse(self.source).body
                       if isinstance(node, ast.Assign) for target in node.targets if isinstance(target, ast.Name)}
        definition = next(node for node in ast.parse(self.source).body
                          if isinstance(node, ast.FunctionDef) and node.name == "extended_query_result")
        namespace = {"re": re}
        nodes = [assignments[name] for name in ("probes", "store_selectors", "required", "query_existing_selectors")]
        exec(compile(ast.Module(body=[*nodes, definition], type_ignores=[]), "extended-parser-only", "exec"), namespace)
        required, cases = namespace["required"], namespace["query_existing_selectors"]
        self.assertEqual(len(required), 20)
        original = {"status": "passed", "source": {"scope": "synthetic parser only"},
                    "tests": {name: {"status": "passed"} for name in required}}
        query = {"schema": "hepta-windows-query-existing-receipt-v1", "status": "passed",
                 "returncode": 0, "logging_returncode": 0, "log_sha256": "0" * 64,
                 "minimum_tests": 6, "observed_passed_tests": 6, "observed_failed_tests": 0,
                 "required_test_names": list(cases), "observed_passed_test_names": list(cases)}
        combine = namespace["extended_query_result"]
        self.assertEqual(combine(original, query)["status"], "passed")
        for name in required:
            with self.subTest(name=name):
                missing = {**original, "tests": {key: value for key, value in original["tests"].items() if key != name}}
                failed = {**original, "tests": {**original["tests"], name: {"status": "failed"}}}
                self.assertEqual(combine(missing, query)["status"], "failed")
                self.assertEqual(combine(failed, query)["status"], "failed")
        for bad in ([], {"status": "not_run"}, {**query, "status": "failed"},
                    {**query, "observed_passed_tests": 5}, {**query, "minimum_tests": 6.0},
                    {**query, "returncode": 1}, {**query, "logging_returncode": 1},
                    {**query, "log_sha256": "not-a-hash"},
                    {**query, "observed_passed_test_names": list(cases[:-1])}):
            self.assertEqual(combine(original, bad)["status"], "failed")
        self.assertEqual(combine({**original, "status": "failed"}, query)["status"], "failed")
        self.assertFalse(combine(original, query)["production_sandbox_admitted"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
