use crate::desktop::LaunchDesktop;
#[path = "owned_child_stdio.rs"]
mod owned_child_stdio;
use owned_child_stdio::OwnedChildStdio;
#[path = "prepared_process_context.rs"]
mod prepared_context;
use crate::logging;
use crate::proc_thread_attr::ProcThreadAttributeList;
use crate::winutil::argv_to_command_line;
use crate::winutil::format_last_error;
use crate::winutil::to_wide;
use anyhow::Context;
use anyhow::Result;
use anyhow::anyhow;
use codex_utils_pty::JobObject;
pub use prepared_context::PreparedProcessContext;
pub(crate) use prepared_context::PreparedFilesystemOwners;
use std::collections::HashMap;
use std::ffi::c_void;
use std::os::windows::io::AsHandle;
use std::os::windows::io::AsRawHandle;
use std::path::Path;
use std::ptr;
use std::sync::Arc;
use windows_sys::Win32::Foundation::CloseHandle;
use windows_sys::Win32::Foundation::GetLastError;
use windows_sys::Win32::Foundation::HANDLE;
use windows_sys::Win32::Storage::FileSystem::ReadFile;
use windows_sys::Win32::System::Pipes::CreatePipe;
use windows_sys::Win32::System::Threading::CREATE_NO_WINDOW;
use windows_sys::Win32::System::Threading::CREATE_UNICODE_ENVIRONMENT;
use windows_sys::Win32::System::Threading::CreateProcessAsUserW;
use windows_sys::Win32::System::Threading::EXTENDED_STARTUPINFO_PRESENT;
use windows_sys::Win32::System::Threading::PROCESS_INFORMATION;
use windows_sys::Win32::System::Threading::STARTUPINFOEXW;
use windows_sys::Win32::System::Threading::STARTUPINFOW;

pub struct CreatedProcess {
    pub process_info: PROCESS_INFORMATION,
    pub startup_info: STARTUPINFOW,
    pub(crate) job: Arc<JobObject>,
    _desktop: LaunchDesktop,
}

/// Keeps the original prepared owners local with their exact process transport.
/// This wrapper cannot release the transport or promote it to launch authority.
pub(crate) struct PreparedCreatedProcess {
    transport: CreatedProcess,
    owners: Box<PreparedFilesystemOwners>,
}

/// Controls console creation for pipe-backed child processes.
pub enum ConsoleMode {
    Inherit,
    NoWindow,
}

pub fn make_env_block(env: &HashMap<String, String>) -> Vec<u16> {
    let mut items: Vec<(String, String)> =
        env.iter().map(|(k, v)| (k.clone(), v.clone())).collect();
    items.sort_by(|a, b| {
        a.0.to_uppercase()
            .cmp(&b.0.to_uppercase())
            .then(a.0.cmp(&b.0))
    });
    let mut w: Vec<u16> = Vec::new();
    for (k, v) in items {
        let mut s = to_wide(format!("{k}={v}"));
        s.pop();
        w.extend_from_slice(&s);
        w.push(0);
    }
    w.push(0);
    w
}

/// Low-level process creation using the supplied token, without permission-profile
/// admission or any filesystem isolation guarantee.
///
/// # Safety
/// Caller must provide a valid primary token handle (`h_token`) with appropriate access,
/// and the `argv`, `cwd`, and `env_map` must remain valid for the duration of the call.
// Low-level CreateProcessAsUserW wrapper mirrors the Windows API shape.
#[allow(clippy::too_many_arguments)]
pub unsafe fn create_process_as_user(
    h_token: HANDLE,
    argv: &[String],
    cwd: &Path,
    env_map: &HashMap<String, String>,
    logs_base_dir: Option<&Path>,
    stdio: Option<(HANDLE, HANDLE, HANDLE)>,
    console_mode: ConsoleMode,
    use_private_desktop: bool,
) -> Result<CreatedProcess> {
    let desktop = LaunchDesktop::prepare(h_token, use_private_desktop, logs_base_dir)?;
    let job = Arc::new(JobObject::create().context("create process job")?);
    let (transport, ()) = create_process_on_desktop(
        h_token,
        argv,
        cwd,
        env_map,
        logs_base_dir,
        stdio,
        console_mode,
        desktop,
        job,
        /*owners*/ (),
    )?;
    Ok(transport)
}

/// Consumes and retains the prepared mechanism's one-use launch resources.
/// This provides no production admission, image initialization or terminal proof.
///
/// # Safety
/// All explicitly supplied stdio handles must remain valid until return.
#[allow(clippy::too_many_arguments)]
pub(crate) unsafe fn create_process_as_user_prepared(
    context: PreparedProcessContext,
    argv: &[String],
    cwd: &Path,
    env_map: &HashMap<String, String>,
    logs_base_dir: Option<&Path>,
    stdio: Option<(HANDLE, HANDLE, HANDLE)>,
    console_mode: ConsoleMode,
) -> Result<PreparedCreatedProcess> {
    let (owners, desktop, job) = context.into_parts()?;
    let h_token = owners.as_handle().as_raw_handle() as HANDLE;
    let (transport, owners) = create_process_on_desktop(
        h_token,
        argv,
        cwd,
        env_map,
        logs_base_dir,
        stdio,
        console_mode,
        desktop,
        job,
        owners,
    )?;
    Ok(PreparedCreatedProcess { transport, owners })
}

#[allow(clippy::too_many_arguments)]
unsafe fn create_process_on_desktop<Owners>(
    h_token: HANDLE,
    argv: &[String],
    cwd: &Path,
    env_map: &HashMap<String, String>,
    logs_base_dir: Option<&Path>,
    stdio: Option<(HANDLE, HANDLE, HANDLE)>,
    console_mode: ConsoleMode,
    desktop: LaunchDesktop,
    job: Arc<JobObject>,
    owners: Owners,
) -> Result<(CreatedProcess, Owners)> {
    let cmdline_str = argv_to_command_line(argv);
    let mut cmdline: Vec<u16> = to_wide(&cmdline_str);
    let env_block = make_env_block(env_map);
    let mut pi: PROCESS_INFORMATION = std::mem::zeroed();
    let cwd_wide = to_wide(cwd);
    let env_block_len = env_block.len();
    let console_flags = match (&stdio, console_mode) {
        (Some(_), ConsoleMode::NoWindow) => CREATE_NO_WINDOW,
        (Some(_), ConsoleMode::Inherit)
        | (None, ConsoleMode::Inherit)
        | (None, ConsoleMode::NoWindow) => 0,
    };
    let child_stdio = OwnedChildStdio::duplicate(stdio)?;
    let mut attrs = ProcThreadAttributeList::new(/*attr_count*/ 2)?;
    attrs.set_job(job.as_raw_handle() as HANDLE)?;

    let mut si: STARTUPINFOEXW = std::mem::zeroed();
    si.StartupInfo.cb = std::mem::size_of::<STARTUPINFOEXW>() as u32;
    // Some processes (e.g., PowerShell) can fail with STATUS_DLL_INIT_FAILED
    // if lpDesktop is not set when launching with a restricted token.
    // Point explicitly at the interactive desktop or a private desktop.
    si.StartupInfo.lpDesktop = desktop.startup_info_desktop();
    child_stdio.apply(&mut si.StartupInfo);
    attrs.set_handle_list(child_stdio.handle_list())?;
    si.lpAttributeList = attrs.as_mut_ptr();

    let creation_flags = CREATE_UNICODE_ENVIRONMENT | EXTENDED_STARTUPINFO_PRESENT | console_flags;
    let ok = CreateProcessAsUserW(
        h_token,
        std::ptr::null(),
        cmdline.as_mut_ptr(),
        std::ptr::null_mut(),
        std::ptr::null_mut(),
        1,
        creation_flags,
        env_block.as_ptr() as *mut c_void,
        cwd_wide.as_ptr(),
        &si.StartupInfo,
        &mut pi,
    );
    if ok == 0 {
        let err = GetLastError() as i32;
        let msg = format!(
            "CreateProcessAsUserW failed: {} ({}) | cwd={} | cmd={} | env_u16_len={} | si_flags={} | creation_flags={}",
            err,
            format_last_error(err),
            cwd.display(),
            cmdline_str,
            env_block_len,
            si.StartupInfo.dwFlags,
            creation_flags,
        );
        logging::debug_log(&msg, logs_base_dir);
        return Err(std::io::Error::from_raw_os_error(err)).context(msg);
    }

    let transport = CreatedProcess {
        process_info: pi,
        startup_info: si.StartupInfo,
        job,
        _desktop: desktop,
    };
    Ok((transport, owners))
}

/// Controls whether the child's stdin handle is kept open for writing.
#[allow(dead_code)]
pub enum StdinMode {
    Closed,
    Open,
}

/// Controls how stderr is wired for a pipe-spawned process.
#[allow(dead_code)]
pub enum StderrMode {
    MergeStdout,
    Separate,
}

/// Handles returned by `spawn_process_with_pipes`.
#[allow(dead_code)]
pub struct PipeSpawnHandles {
    pub process: PROCESS_INFORMATION,
    job: Arc<JobObject>,
    pub stdin_write: Option<HANDLE>,
    pub stdout_read: HANDLE,
    pub stderr_read: Option<HANDLE>,
    pub(crate) desktop: LaunchDesktop,
}

/// Borrowing endpoints does not transfer or discard the original proof owners.
/// The ordinary legacy transport keeps its original layout and auto-traits.
pub(crate) struct PreparedPipeSpawnHandles {
    transport: PipeSpawnHandles,
    _owners: Box<PreparedFilesystemOwners>,
}

impl PreparedPipeSpawnHandles {
    pub(crate) fn handles(&self) -> &PipeSpawnHandles {
        &self.transport
    }
}

impl PipeSpawnHandles {
    /// Returns the Job Object containing the spawned process.
    pub fn job(&self) -> Arc<JobObject> {
        Arc::clone(&self.job)
    }
}

/// Spawns a process with anonymous pipes and returns the relevant handles.
///
/// This low-level helper uses the supplied token without permission-profile
/// admission or any filesystem isolation guarantee.
#[allow(clippy::too_many_arguments)]
pub fn spawn_process_with_pipes(
    h_token: HANDLE,
    argv: &[String],
    cwd: &Path,
    env_map: &HashMap<String, String>,
    stdin_mode: StdinMode,
    stderr_mode: StderrMode,
    console_mode: ConsoleMode,
    use_private_desktop: bool,
    logs_base_dir: Option<&Path>,
) -> Result<PipeSpawnHandles> {
    let (transport, ()) = spawn_with_pipes(
        |stdio| unsafe {
            create_process_as_user(
                h_token,
                argv,
                cwd,
                env_map,
                logs_base_dir,
                stdio,
                console_mode,
                use_private_desktop,
            )
            .map(|transport| (transport, ()))
        },
        stdin_mode,
        stderr_mode,
    )?;
    Ok(transport)
}

/// Pipe launch retaining the prepared owners and the same EOF/output contracts.
#[allow(clippy::too_many_arguments)]
pub(crate) fn spawn_process_with_pipes_prepared(
    context: PreparedProcessContext,
    argv: &[String],
    cwd: &Path,
    env_map: &HashMap<String, String>,
    stdin_mode: StdinMode,
    stderr_mode: StderrMode,
    console_mode: ConsoleMode,
    logs_base_dir: Option<&Path>,
) -> Result<PreparedPipeSpawnHandles> {
    let (transport, owners) = spawn_with_pipes(
        |stdio| unsafe {
            let PreparedCreatedProcess { transport, owners } = create_process_as_user_prepared(
                context,
                argv,
                cwd,
                env_map,
                logs_base_dir,
                stdio,
                console_mode,
            )?;
            Ok((transport, owners))
        },
        stdin_mode,
        stderr_mode,
    )?;
    Ok(PreparedPipeSpawnHandles {
        transport,
        _owners: owners,
    })
}

fn spawn_with_pipes<Owners>(
    launch: impl FnOnce(Option<(HANDLE, HANDLE, HANDLE)>) -> Result<(CreatedProcess, Owners)>,
    stdin_mode: StdinMode,
    stderr_mode: StderrMode,
) -> Result<(PipeSpawnHandles, Owners)> {
    let mut in_r: HANDLE = 0;
    let mut in_w: HANDLE = 0;
    let mut out_r: HANDLE = 0;
    let mut out_w: HANDLE = 0;
    let mut err_r: HANDLE = 0;
    let mut err_w: HANDLE = 0;
    unsafe {
        if CreatePipe(&mut in_r, &mut in_w, ptr::null_mut(), 0) == 0 {
            return Err(anyhow!("CreatePipe stdin failed: {}", GetLastError()));
        }
        if CreatePipe(&mut out_r, &mut out_w, ptr::null_mut(), 0) == 0 {
            CloseHandle(in_r);
            CloseHandle(in_w);
            return Err(anyhow!("CreatePipe stdout failed: {}", GetLastError()));
        }
        if matches!(stderr_mode, StderrMode::Separate)
            && CreatePipe(&mut err_r, &mut err_w, ptr::null_mut(), 0) == 0
        {
            CloseHandle(in_r);
            CloseHandle(in_w);
            CloseHandle(out_r);
            CloseHandle(out_w);
            return Err(anyhow!("CreatePipe stderr failed: {}", GetLastError()));
        }
    }

    let stderr_handle = match stderr_mode {
        StderrMode::MergeStdout => out_w,
        StderrMode::Separate => err_w,
    };

    let stdio = Some((in_r, out_w, stderr_handle));
    let spawn_result = launch(stdio);
    let (created, owners) = match spawn_result {
        Ok(v) => v,
        Err(err) => {
            unsafe {
                CloseHandle(in_r);
                CloseHandle(in_w);
                CloseHandle(out_r);
                CloseHandle(out_w);
                if matches!(stderr_mode, StderrMode::Separate) {
                    CloseHandle(err_r);
                    CloseHandle(err_w);
                }
            }
            return Err(err);
        }
    };
    let CreatedProcess {
        process_info: pi,
        job,
        _desktop: desktop,
        startup_info: _,
    } = created;

    unsafe {
        CloseHandle(in_r);
        CloseHandle(out_w);
        if matches!(stderr_mode, StderrMode::Separate) {
            CloseHandle(err_w);
        }
        if matches!(stdin_mode, StdinMode::Closed) {
            CloseHandle(in_w);
        }
    }

    let transport = PipeSpawnHandles {
        process: pi,
        job,
        stdin_write: match stdin_mode {
            StdinMode::Open => Some(in_w),
            StdinMode::Closed => None,
        },
        stdout_read: out_r,
        stderr_read: match stderr_mode {
            StderrMode::Separate => Some(err_r),
            StderrMode::MergeStdout => None,
        },
        desktop,
    };
    Ok((transport, owners))
}

/// Reads a HANDLE until EOF and invokes `on_chunk` for each read.
pub fn read_handle_loop<F>(handle: HANDLE, mut on_chunk: F) -> std::thread::JoinHandle<()>
where
    F: FnMut(&[u8]) + Send + 'static,
{
    std::thread::spawn(move || {
        let mut buf = [0u8; 8192];
        loop {
            let mut read_bytes: u32 = 0;
            let ok = unsafe {
                ReadFile(
                    handle,
                    buf.as_mut_ptr(),
                    buf.len() as u32,
                    &mut read_bytes,
                    ptr::null_mut(),
                )
            };
            if ok == 0 || read_bytes == 0 {
                break;
            }
            on_chunk(&buf[..read_bytes as usize]);
        }
        unsafe {
            CloseHandle(handle);
        }
    })
}
