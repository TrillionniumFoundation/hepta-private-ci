from pathlib import Path
import ast,json,yaml,re,hashlib,subprocess
D=Path("work/ci-follow/ROG-d66-Windows-workflow-receipt-independent-readonly-20261026-001");rel='.github/workflows/hepta-windows-delete-boundary.yml'
old=yaml.load((D/'base2c301'/rel).read_text(),Loader=yaml.BaseLoader);new=yaml.load((D/'incomingd66'/rel).read_text(),Loader=yaml.BaseLoader)
for k in old:
 if k not in ['on','jobs']:assert old[k]==new[k],k
oldon=old['on'];newon=new['on'];oldpaths=oldon['pull_request']['paths'];newpaths=newon['pull_request']['paths'];assert[x for x in newpaths if x not in oldpaths]==['scripts/test_hepta_windows_terminal_receipts.py'];oncopy=json.loads(json.dumps(newon));oncopy['pull_request']['paths']=oldpaths;assert oncopy==oldon
assert set(old['jobs'])==set(new['jobs']);jobname=next(iter(old['jobs']));a=old['jobs'][jobname];b=new['jobs'][jobname]
for k in a:
 if k!='steps':assert a[k]==b[k],k
assert a['timeout-minutes']==b['timeout-minutes']=='60'
oldsteps=a['steps'];newsteps=b['steps'];key=lambda x:x.get('name',x.get('uses'));om={key(x):x for x in oldsteps};nm={key(x):x for x in newsteps};changed=[]
for k,v in om.items():
 assert k in nm
 if v!=nm[k]:changed.append(k)
assert changed==['Prepare diagnostic output and exact Windows checkout','Bind exact Windows source and retain native test evidence'];added=[k for k in nm if k not in om];assert len(added)==2
def reader(step):
 m=re.search(r'cat > "\$RUNNER_TEMP/windows-delete-boundary/check.py" <<\x27PY\x27\n(.*?)\nPY\n',step['run'],re.S);assert m
 return m[1]
o=ast.parse(reader(om['Bind exact Windows source and retain native test evidence']));n=ast.parse(reader(nm['Bind exact Windows source and retain native test evidence']))
assign=lambda t:{a.id:x for x in t.body if isinstance(x,ast.Assign)for a in x.targets if isinstance(a,ast.Name)};oa,na=assign(o),assign(n)
for k in ['probes','store_selectors','required']:assert ast.dump(oa[k],include_attributes=False)==ast.dump(na[k],include_attributes=False)
of={x.name:x for x in o.body if isinstance(x,ast.FunctionDef)};nf={x.name:x for x in n.body if isinstance(x,ast.FunctionDef)}
for k in of:assert ast.dump(of[k],include_attributes=False)==ast.dump(nf[k],include_attributes=False),k
names=[]
for item in na['required'].value.elts:
 if isinstance(item,ast.Constant):names.append(item.value)
 elif isinstance(item,ast.Starred)and isinstance(item.value,ast.Name):names.extend(ast.literal_eval(na[item.value.id].value))
 else:raise AssertionError('unexpectedrequiredshape')
assert len(names)==len(set(names))==20
query=ast.literal_eval(na['query_existing_selectors'].value);terminal=ast.literal_eval(na['terminal_selectors'].value)
qsource=(D/'incomingd66/codex-rs/windows-sandbox-rs/src/prepared_filesystem_readback_tests.rs').read_text();tsource=(D/'incomingd66/codex-rs/windows-sandbox-rs/src/bin/command_runner/win/process_observation_tests.rs').read_text()
qactual=tuple('prepared_filesystem::readback_tests::'+x for x in re.findall(r'^fn (existing_[a-z0-9_]+)\(',qsource,re.M));tactual=tuple('win::process_observation::tests::'+x for x in re.findall(r'^#\[test\]\nfn ([a-z0-9_]+)\(',tsource,re.M))
assert query==qactual and len(query)==6 and terminal==tactual and len(terminal)==3
R=Path('work/root-hepta-integration-20261026');base='2c301ec0b7c90d12a02a3f1d04500f0268197fb8';tip='d66fcaf9245846907f6266d544d22a0620604d94'
guard=lambda rev:subprocess.run(['git','-C',str(R),'show',rev+':codex-rs/windows-sandbox-rs/src/legacy_boundary.rs'],capture_output=True,check=True).stdout
gb,gt=guard(base),guard(tip);assert gb==gt;(D/'unchanged-production-legacy-boundary.rs').write_bytes(gt)
r={'workflow_job':jobname,'original_step_count':len(oldsteps),'new_step_count':len(newsteps),'all_original_step_names_retained_in_order':[key(x)for x in oldsteps]==[key(x)for x in newsteps if key(x)in om],'modified_existing_steps':changed,'added_steps':added,'all_other_original_steps_exact_deep_equal':True,'all_other_job_and_top_properties_exact_equal':True,'only_path_trigger_addition':'scripts/test_hepta_windows_terminal_receipts.py','timeout_minutes':60,'matrix':b['strategy']['matrix'],'env':b['env'],'original_required_groups':names,'all_original_20_groups_selectors_deep_AST_equal':True,'all_original_reader_function_bodies_AST_equal':list(of),'additional_query_six':query,'additional_terminal_three':terminal,'new_rosters_match_exact_Rust_sources':True,'production_guard_exact_unchanged_and_always_error':True,'production_guard_sha256':hashlib.sha256(gt).hexdigest(),'new_receipts_not_old_original_failure_closure':True,'no_tests_or_native_or_compile_executed':True}
(D/'workflow-static-contract-review.json').write_text(json.dumps(r,indent=2)+'\n');history=D/'analysis-extraction-history.txt';history.write_text(history.read_text()+'First staticASTroster decoder incorrectly assumed dict instead of existingstarredtuple, AttributeError after othercomparisons; corrected decoder expands literalprobes/storeselectornames without exec. No native/test/runtime/Git mutation.\n')
print(json.dumps({k:r[k]for k in ['original_step_count','new_step_count','all_original_step_names_retained_in_order','modified_existing_steps','added_steps','timeout_minutes','matrix','original_required_groups','production_guard_sha256']},indent=2))
