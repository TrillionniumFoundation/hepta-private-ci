"""Freeze independent LOCO baseline arithmetic; never imports/trains the advisor."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

INPUT = Path('/workspace/scratch/5fe4a47a9363/INDEPENDENT_OLD_TRAIN_SKILL_TRANSITION_AUDIT.json')
OUTPUT = Path('/workspace/scratch/5fe4a47a9363/INDEPENDENT_SKILL_COMPLETION_EXPECTED_BASELINES.json')
raw = INPUT.read_bytes()
audit = json.loads(raw)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def sha(value):
    return hashlib.sha256(value).hexdigest()


def metrics(rows, name):
    known = [(int(r['label']), r['probabilities'][name]) for r in rows if r['label'] is not None]
    result = {'total': len(rows), 'observed': len(known), 'censored': len(rows) - len(known),
              'brier': None, 'log_loss': None, 'accuracy': None, 'confusion': None}
    if known:
        n = len(known)
        result.update(brier=sum((p-y)**2 for y,p in known)/n,
                      log_loss=sum(-y*math.log(p)-(1-y)*math.log1p(-p) for y,p in known)/n,
                      accuracy=sum((p >= 0.5) == y for y,p in known)/n,
                      confusion={'true_positive': sum(p >= 0.5 and y == 1 for y,p in known),
                                 'false_positive': sum(p >= 0.5 and y == 0 for y,p in known),
                                 'true_negative': sum(p < 0.5 and y == 0 for y,p in known),
                                 'false_negative': sum(p < 0.5 and y == 1 for y,p in known)})
    return result


inputs = [{'task_id': r['task_id'], 'decision_index': r['decision_index'], 'group': r['group'],
           'entry_features': r['initiation_features'], 'label': r['whole_task_complete_online']}
          for r in audit['transitions']]
groups = sorted({r['group'] for r in inputs})
names = ['smoothed_constant', 'laplace_exact_feature_table']
predictions, folds = [], []
ordered_hashes, multiset_hashes = {}, {}
for held in [*groups, None]:
    training = [r for r in inputs if r['group'] != held and r['label'] is not None]
    pairs = [(r['entry_features'], int(r['label'])) for r in training]
    ordered_hashes[str(held)] = sha(canonical(pairs))
    multiset_hashes[str(held)] = sha(canonical(sorted(pairs)))
    if held is None:
        continue
    rate = (sum(r['label'] for r in training) + 1) / (len(training) + 2)
    table = defaultdict(list)
    for r in training:
        table[tuple(r['entry_features'])].append(int(r['label']))
    held_predictions = []
    for r in inputs:
        if r['group'] != held:
            continue
        labels = table.get(tuple(r['entry_features']))
        probability = (sum(labels) + 1) / (len(labels) + 2) if labels is not None else rate
        held_predictions.append({**r, 'probabilities': {'smoothed_constant': rate,
                                                       'laplace_exact_feature_table': probability}})
    predictions.extend(held_predictions)
    folds.append({'held_group': held, 'observed_training_rows': len(training),
                  'training_positive_rows': sum(r['label'] for r in training),
                  'held_entry_patterns_all_seen_in_training': all(tuple(r['entry_features']) in table for r in held_predictions),
                  'metrics': {name: metrics(held_predictions, name) for name in names}})
assert len(predictions) == 96 and len({(r['task_id'], r['decision_index']) for r in predictions}) == 96
assert len(set(ordered_hashes.values())) == 8 and len(set(multiset_hashes.values())) == 6
patterns = defaultdict(Counter)
for r in inputs:
    patterns[tuple(r['entry_features'])][str(r['label'])] += 1
known = [r for r in inputs if r['label'] is not None]
minimum_brier, minimum_logloss, maximum_correct = 0.0, 0.0, 0
for counts in patterns.values():
    positive, negative = counts['True'], counts['False']
    total = positive + negative
    if not total:
        continue
    rate = positive / total
    minimum_brier += positive*(1-rate)**2 + negative*rate**2
    if positive:
        minimum_logloss -= positive*math.log(rate)
    if negative:
        minimum_logloss -= negative*math.log1p(-rate)
    maximum_correct += max(positive, negative)
report = {
    'schema': 'hepta.independent-old-train-completion-baseline-expectations.v1',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'EXPECTED_BASELINE_ARITHMETIC_FROZEN_BEFORE_QUALIFIED_MODEL_FITS',
    'input_audit': str(INPUT), 'input_audit_sha256': sha(raw),
    'original_archive_sha256': audit['input_sha256'],
    'original_source_sha256': audit['original_source_sha256'],
    'math_inputs_sha256': sha(canonical(inputs)),
    'math_inputs': inputs,
    'formulas': {
        'grouping': 'Hold all exact keys-length/fault family rows together across destination/schema/replicate; nine families.',
        'mask': 'Only original subsequent actor-readback boolean labels in the other families enter training counts; None is never coerced to false.',
        'smoothed_constant': '(training positive count + 1) / (training observed count + 2)',
        'laplace_exact_feature_table': '(matching entry-feature training positive count + 1) / (matching entry-feature observed count + 2); fallback constant only if pattern absent',
        'decision_threshold': 'p >= 0.5',
        'brier': 'mean((p-y)^2) on observed heldout targets only',
        'log_loss': 'mean(-y*ln(p)-(1-y)*ln(1-p)) on observed heldout targets only',
        'aggregation': 'One out-of-fold prediction per original transition; pool observed rows, not unweighted fold metrics; two training seeds repeat these same baseline predictions, not new cases.',
    },
    'counts': {'original_episodes': 80, 'original_ensure_transitions': 96,
               'observed_outcomes': 80, 'censored_outcomes': 16, 'folds': 9,
               'folds_with_observed_outcomes': 7, 'fully_censored_folds': 2,
               'distinct_ordered_supervised_arrays': 8, 'distinct_supervised_feature_label_multisets': 6},
    'expected_baseline_metrics': {name: metrics(predictions, name) for name in names},
    'expected_fold_metrics': folds,
    'expected_predictions': predictions,
    'single_full_model_empirical_bounds': {
        'scope': 'On all80 observed original TRAIN rows, one deterministic predictor using only the exact three entry-feature vectors. These bounds do not constrain differing fold-specific models.',
        'maximum_accuracy': maximum_correct / len(known),
        'minimum_brier': minimum_brier / len(known),
        'minimum_log_loss': minimum_logloss / len(known),
        'reason': 'Two ambiguous entry vectors have equal true/false counts; the matched=0.5 vector has32 true outcomes. These are descriptive corpus constraints, not measured model gains.',
    },
    'limits': {
        'model_fits_executed_by_this_audit': 0, 'model_inferences_executed_by_this_audit': 0,
        'loader_or_consumer_imported_by_this_audit': False,
        'confirmation_data_used': False, 'privileged_database_values_used_in_math_inputs': False,
        'new_independent_tasks': 0, 'operational_comparison': False,
        'important_denominator_distinction': 'The table accuracy40%=32/80 observed old-TRAIN completion forecasts; it is not the fixed-workflow operational completion80%=512/640 confirmation executions. No conversion or efficacy comparison is valid between them.',
        'full_exact_feature_overlap': True, 'condition_dependent_censoring': True,
        'no_hyperparameter_or_seed_tuning_from_result': True,
    },
    'audit_script_sha256': sha(Path(__file__).read_bytes()),
}
OUTPUT.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + '\n')
print(json.dumps({'report': str(OUTPUT), 'sha256': sha(OUTPUT.read_bytes()), 'metrics': report['expected_baseline_metrics'],
                  'bounds': report['single_full_model_empirical_bounds']}))
