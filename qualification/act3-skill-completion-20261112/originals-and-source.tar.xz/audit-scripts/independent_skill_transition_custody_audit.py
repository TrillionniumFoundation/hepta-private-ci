"""Independent original ACT2 TRAIN custody/semantics audit; no loader/fit execution."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import lzma
from pathlib import Path
import sqlite3
import zipfile

ROOT = Path('/workspace/scratch/5fe4a47a9363/act-joint/qualification/act2-learning-20261110/run2')
OUT = Path('/workspace/scratch/5fe4a47a9363/INDEPENDENT_OLD_TRAIN_SKILL_TRANSITION_AUDIT.json')
PINS = {
    'SHA256SUMS.json': '16de01ad186843a08f115562ba6c3ade48ca43fe42b6c437399958d8cafb44df',
    'FROZEN_MANIFEST.json': '041b2b472a9ea366abacce273de43f19a59271c3d784328d4c5623d6f8436da9',
    'training-trajectories.jsonl.gz': '5512824dc9706ef8c5735eb94c6d500ec0a60ad42ea084db448398ab878b6eec',
    'source-postimages.zip': '8b2c18bbddf915e6f143d26871864d0ef27c657738d9f19198b4859f6e46d75c',
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


inputs = {name: (ROOT / name).read_bytes() for name in [*PINS, 'destination-databases.zip.xz']}
input_hashes = {name: sha(raw) for name, raw in inputs.items()}
assert all(input_hashes[n] == h for n, h in PINS.items())
sums = json.loads(inputs['SHA256SUMS.json'])
manifest = json.loads(inputs['FROZEN_MANIFEST.json'])
with zipfile.ZipFile(io.BytesIO(inputs['source-postimages.zip'])) as archive:
    source_hashes = {n: sha(archive.read(n)) for n in archive.namelist()}
assert source_hashes == manifest['source_files_sha256']
lines = gzip.decompress(inputs['training-trajectories.jsonl.gz']).splitlines(keepends=True)
rows = [json.loads(line) for line in lines]
tasks = {t['id']: t for t in manifest['train_tasks']}
assert len(rows) == len(tasks) == 80
assert [r['task_id'] for r in rows] == [t['id'] for t in manifest['train_tasks']]
with lzma.LZMAFile(io.BytesIO(inputs['destination-databases.zip.xz']), 'rb') as stream:
    database_zip = stream.read(268435457)
assert len(database_zip) <= 268435456
assert sha(database_zip) == sums['destination-databases.zip']
transitions, db_witnesses, opaque = [], [], []
patterns = defaultdict(Counter)
groups = defaultdict(set)
group_labels = defaultdict(Counter)
all_call_gaps = []
schemas = [('items', 'item_key', 'value'), ('objects', 'object_key', 'content')]
with zipfile.ZipFile(io.BytesIO(database_zip)) as archive:
    total_db_members = len(archive.namelist())
    assert sum(n.startswith('training/') for n in archive.namelist()) == 80
    for number, (row, line) in enumerate(zip(rows, lines), 1):
        task = tasks[row['task_id']]
        events = row['events']
        ensures = [i for i, d in enumerate(row['decisions']) if d == 'ensure']
        applies = [i for i, e in enumerate(events) if e['action'] == 'apply']
        assert len(ensures) == len(applies)
        assert all(a['at_ns'] <= b['at_ns'] for a, b in zip(events, events[1:]))
        expected_operations = {}
        for decision, apply_index in zip(ensures, applies):
            prior = max(i for i in range(apply_index) if events[i]['action'] == 'inspect')
            view = events[prior]['observation']
            assert view and not view['complete']
            key = view['index']
            entry = apply_index if view['staged'] else apply_index - 1
            assert [e['action'] for e in events[entry:apply_index+1]] == (['apply'] if view['staged'] else ['stage', 'apply'])
            assert entry == prior + 1
            x = row['policy_visible_features'][decision]
            assert x == [1, 0, int(view['staged']), 0, 1, 0, 0, view['matched'] / len(task['goals']), 0.0, 1]
            stop = next((i for i in range(apply_index+1, len(events)) if events[i]['action'] != 'inspect'), len(events))
            readbacks = list(range(apply_index+1, stop))
            assert readbacks and all(events[i]['action'] == 'inspect' for i in readbacks)
            observed = next((i for i in readbacks if events[i]['observation'] is not None), None)
            outcome = None if observed is None else events[observed]['observation']['complete']
            goal_observed = None if observed is None else events[observed]['observation']['index'] > key
            invocation = task['id'] + ':' + str(key)
            goal_hash = sha(task['goals'][key].encode())
            expected_operations[invocation] = goal_hash
            feature_key = canonical(x).decode()
            group = f"keys-{row['composition']}/{row['fault']}"
            groups[group].add(feature_key)
            group_labels[group][str(outcome)] += 1
            patterns[feature_key][str(outcome)] += 1
            gap = events[readbacks[0]]['at_ns'] - events[entry]['at_ns']
            assert gap >= 0
            all_call_gaps.append(gap)
            transitions.append({
                'task_id': task['id'], 'decision_index': decision,
                'training_line_number': number, 'training_line_sha256': sha(line),
                'invocation_derived_from_pinned_source': invocation, 'goal_sha256': goal_hash,
                'initiation_inspect_event_index': prior, 'mutation_entry_event_index': entry,
                'apply_event_index': apply_index, 'later_read_event_indices': readbacks,
                'label_read_event_index': observed, 'goal_observed_online': goal_observed,
                'whole_task_complete_online': outcome, 'initiation_features': x,
                'group': group, 'event_call_start_gap_ns': gap,
            })
        blob = archive.read(row['database_archive_member'])
        assert sha(blob) == row['database_sha256']
        db = sqlite3.connect(':memory:')
        db.deserialize(blob)
        db.execute('PRAGMA query_only=ON')
        actual_operations = dict(db.execute('SELECT operation,payload FROM applied'))
        actual_effects = list(db.execute('SELECT key,value FROM effects'))
        assert actual_operations == expected_operations
        assert len(actual_effects) == len(expected_operations)
        assert all(goal == task['goals'][int(key)] for key, goal in actual_effects)
        table, key_column, value_column = schemas[task['schema']]
        actual_rows = dict(db.execute(f'SELECT {key_column},{value_column} FROM {table}'))
        physical_complete = all(actual_rows[str(i)] == goal for i, goal in enumerate(task['goals']))
        db.close()
        db_witnesses.append({'task_id': task['id'], 'member': row['database_archive_member'],
                             'sha256': sha(blob), 'matched_applied_operations': actual_operations,
                             'effect_rows_checked': len(actual_effects),
                             'physical_whole_task_complete_privileged_audit_only': physical_complete})
        if task['fault'] == 'opaque_after_apply':
            opaque.append({'task_id': task['id'], 'physical_whole_task_complete_privileged_audit_only': physical_complete,
                           'original_policy_unknown': row['unknown'],
                           'online_labels': [t['whole_task_complete_online'] for t in transitions if t['task_id'] == task['id']]})
assert len(transitions) == 96
assert len({t['invocation_derived_from_pinned_source'] for t in transitions}) == 96
assert len(opaque) == 16 and all(x['original_policy_unknown'] and x['online_labels'] == [None] for x in opaque)
assert sum(x['physical_whole_task_complete_privileged_audit_only'] for x in opaque) == 8
folds = []
for group, features in sorted(groups.items()):
    other_features = set().union(*(v for g, v in groups.items() if g != group))
    folds.append({'heldout_family': group, 'target_counts': dict(group_labels[group]),
                  'unique_entry_vectors': len(features), 'entry_vectors_seen_in_other_families': len(features & other_features),
                  'all_entry_vectors_seen_in_other_families': features <= other_features})
assert len(folds) == 9 and all(f['all_entry_vectors_seen_in_other_families'] for f in folds)
assert len(patterns) == 3
report = {
    'schema': 'hepta.independent-old-train-skill-transition-audit.v1',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'result': 'PASS_SCOPED_ORIGINAL_TRAIN_CUSTODY_AND_SEMANTICS',
    'reviewer': '/root/act_ci_audit', 'archive': str(ROOT),
    'archive_origin_commit': '0584b3344f70ed51d9e09224e105bfa4d1a4635f',
    'input_sha256': input_hashes, 'original_source_sha256': source_hashes,
    'uncompressed_database_zip_sha256': sha(database_zip), 'uncompressed_database_zip_bytes': len(database_zip),
    'database_zip_total_members': total_db_members, 'database_members_read': 'training/ only; 80 of 3280',
    'counts': {'original_train_episodes': len(rows), 'episodes_without_ensure': sum('ensure' not in r['decisions'] for r in rows),
               'ensure_transitions': len(transitions), 'training_database_hashes_verified': len(db_witnesses),
               'derived_invocations_matching_actual_applied_operations': sum(len(w['matched_applied_operations']) for w in db_witnesses),
               'physical_effect_rows_matching_original_goal': sum(w['effect_rows_checked'] for w in db_witnesses),
               'goal_observed_true': sum(t['goal_observed_online'] is True for t in transitions),
               'goal_observed_false': sum(t['goal_observed_online'] is False for t in transitions),
               'goal_observed_unknown': sum(t['goal_observed_online'] is None for t in transitions),
               'whole_task_complete_true': sum(t['whole_task_complete_online'] is True for t in transitions),
               'whole_task_complete_false': sum(t['whole_task_complete_online'] is False for t in transitions),
               'whole_task_complete_unknown': sum(t['whole_task_complete_online'] is None for t in transitions),
               'opaque_policy_unknown_episodes': len(opaque),
               'opaque_physical_complete_despite_policy_unknown': sum(x['physical_whole_task_complete_privileged_audit_only'] for x in opaque),
               'unique_initiation_feature_vectors': len(patterns),
               'normalized_feature_decision_trajectories': len({canonical([r['policy_visible_features'], r['decisions']]) for r in rows}),
               'unique_feature_outcome_pairs_including_unknown': sum(len(c) for c in patterns.values()),
               'length_fault_transition_families': len(folds)},
    'source_semantics': {
        'ensure': 'Existing synchronous ensure executes optional stage then apply, sets last=ensure and returns; no goal check occurs inside ensure.',
        'entry_features': 'Exact original 10 features sampled before fixed policy selected ensure; all have task complete bit zero.',
        'label': 'First subsequent non-null original actor inspect before a later mutation; whole-task completion differs from invocation-goal confirmation.',
        'unknown': 'All unavailable original actor readbacks remain null; later/physical oracle information does not fill them.',
        'invocation': 'Original trace omits operation ID; derived from pinned apply source task.id + colon + original view.index. Separately corroborated against retained TRAIN SQLite applied rows.',
        'timing': 'at_ns is charged primitive-call entry before execution. First mutation entry to next read entry is a call-start gap, not ensure return duration, observation availability time, or skill completion latency.',
    },
    'leakage_and_scope': {
        'grouping': 'Keep all destinations, schema names, replicates, and same-episode transitions inside the same length/fault family.',
        'all_nine_folds_have_full_exact_feature_overlap': True,
        'feature_group_incidence_components': 1,
        'censored_only_families': ['keys-1/opaque_after_apply', 'keys-2/opaque_after_apply'],
        'censoring_not_random': 'All opaque-after-apply examples are masked; observed-only metrics cannot characterize this fault family.',
        'no_negative_known_invocation_goal_examples': True,
        'no_new_applications_versions_or_fault_families': True,
        'no_independent_holdout_or_execution_gain_claim': True,
    },
    'independence': {
        'loader_executed_by_this_audit': False,
        'learning_consumer_executed_by_this_audit': False,
        'fits_or_test_suites_executed': 0,
        'confirmation_trajectory_members_read': False,
        'confirmation_database_members_read': False,
        'original_source_executed': False,
        'original_files_modified': False,
        'sqlite_access': 'Only in-memory copies of original TRAIN database bytes, with query_only enabled; original files never opened for SQLite writes.',
        'privileged_database_evidence': 'Separate identity/custody corroboration only. Never passed as labels or inputs to loader or fit.',
        'loader_invocation_id_observed_directly_remains_false': True,
    },
    'entry_feature_outcome_counts': [{'features': json.loads(k), 'counts': dict(v)} for k, v in sorted(patterns.items())],
    'fold_overlap': folds, 'opaque_cases': opaque,
    'transitions': transitions, 'database_witnesses': db_witnesses,
    'audit_script_sha256': sha(Path(__file__).read_bytes()),
}
report['inputs_unchanged_after_audit'] = all(sha((ROOT / n).read_bytes()) == h for n, h in input_hashes.items())
assert report['inputs_unchanged_after_audit']
OUT.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + '\n')
print(json.dumps({'report': str(OUT), 'sha256': sha(OUT.read_bytes()), 'result': report['result'], 'counts': report['counts']}))
