"""Read retained qualification artifacts; no consumer imports, fitting, or tests."""
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import numpy as np

ROOT = Path('/workspace/scratch/5fe4a47a9363/skill-completion-source-2c77000-run1')
REPO = Path('/workspace/scratch/5fe4a47a9363/act-joint')
BASELINE = Path('/workspace/scratch/5fe4a47a9363/INDEPENDENT_SKILL_COMPLETION_EXPECTED_BASELINES.json')
CUSTODY = Path('/workspace/scratch/5fe4a47a9363/INDEPENDENT_OLD_TRAIN_SKILL_TRANSITION_AUDIT.json')
OUT = Path('/workspace/scratch/5fe4a47a9363/INDEPENDENT_SKILL_COMPLETION_RETAINED_AUDIT_2c77000.json')
COMMIT = '2c77000a6092f20eb28f7b65eef1940a33ac9b8b'
TREE = '2838a39764f31d191d91233acc2fcab6be47ab82'
checks = []


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def check(name, condition):
    checks.append({'check': name, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(name)


def close(a, b):
    return math.isclose(float(a), float(b), rel_tol=1e-12, abs_tol=2e-12)


def equal_metrics(actual, expected):
    return set(actual) == set(expected) and all(
        close(actual[k], v) if isinstance(v, float) else actual[k] == v
        for k, v in expected.items())


def read_json(path):
    return json.loads(path.read_bytes())


def git(*args):
    env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
    return subprocess.check_output(['git', *args], cwd=REPO, env=env)


def parameter_digest(p):
    return sha(b''.join(canonical([k, list(v.shape), '<f8']) + v.astype('<f8').tobytes()
                        for k, v in sorted(p.items())))


def tensors(path):
    expected = {'W': (10, 8), 'b': (8,), 'v': (8,), 'c': (1,)}
    with np.load(path, allow_pickle=False) as archive:
        assert set(archive.files) == set(expected)
        p = {k: archive[k].copy() for k in archive.files}
    assert all(v.shape == expected[k] and v.dtype == np.dtype('float64') and np.isfinite(v).all()
               for k, v in p.items())
    return p


def logits(p, x):
    # Independent direct tensor expression; no advisor or its prediction method imported.
    return np.tanh(x @ p['W'] + p['b']) @ p['v'] + p['c'][0]


def forecast(p, x):
    return np.exp(-np.logaddexp(0, -logits(p, x)))


def bce(p, x, y):
    z = logits(p, x)
    return float(np.mean(np.logaddexp(0, z) - y*z))


def metrics(rows, name):
    known = [(int(r['target']), float(r['probability'][name])) for r in rows if r['target'] is not None]
    result = {'total': len(rows), 'observed': len(known), 'censored': len(rows)-len(known),
              'brier': None, 'log_loss': None, 'accuracy': None, 'confusion': None}
    if known:
        n = len(known)
        result.update(brier=sum((p-y)**2 for y,p in known)/n,
                      log_loss=sum(-y*math.log(min(max(p,1e-12),1-1e-12))
                                   -(1-y)*math.log1p(-min(max(p,1e-12),1-1e-12)) for y,p in known)/n,
                      accuracy=sum((p >= .5) == y for y,p in known)/n,
                      confusion={'true_positive': sum(p >= .5 and y == 1 for y,p in known),
                                 'false_positive': sum(p >= .5 and y == 0 for y,p in known),
                                 'true_negative': sum(p < .5 and y == 0 for y,p in known),
                                 'false_negative': sum(p < .5 and y == 1 for y,p in known)})
    return result


sums = read_json(ROOT / 'SHA256SUMS.json')
actual_files = {str(p.relative_to(ROOT)): p for p in ROOT.rglob('*') if p.is_file()}
check('retained file roster exact and no symlinks',
      set(actual_files) == set(sums) | {'SHA256SUMS.json'} and not any(p.is_symlink() for p in ROOT.rglob('*')))
for name, digest in sums.items():
    check('retained digest ' + name, sha(actual_files[name].read_bytes()) == digest)
sums_hash = sha((ROOT / 'SHA256SUMS.json').read_bytes())
result = read_json(ROOT / 'RESULT.json')
manifest = read_json(ROOT / 'MANIFEST.json')
probe = read_json(ROOT / 'probe/RESULT.json')
plan = read_json(ROOT / 'probe/FROZEN_PLAN.json')
dataset = read_json(ROOT / 'probe/DATASET.json')
test_plan = read_json(ROOT / 'TEST_PLAN.json')
source = result['source_before']
check('exact common source commit and tree', source['commit'] == COMMIT and source['tree'] == TREE
      and git('rev-parse', COMMIT + '^{tree}').decode().strip() == TREE)
check('source before after and manifest match', source == result['source_after'] == manifest['source_before']
      and source['worktree_status'] == '')
check('retained source roster exact', {p.name for p in (ROOT/'source').iterdir()} == set(source['source_sha256']))
for name, digest in source['source_sha256'].items():
    retained = (ROOT/'source'/name).read_bytes()
    check('source bytes and exact Git blob ' + name, sha(retained) == digest
          and retained == git('show', COMMIT + ':scripts/act2_learning/' + name))
for name, digest in source['model_sha256'].items():
    check('historical model exact Git blob ' + name,
          sha(git('show', COMMIT + ':qualification/act2-learning-20261110/run2/' + name)) == digest)
check('all14 actually started passed and log corroborated', result['passed'] is True
      and result['planned_tests'] == result['executed_tests'] == len(test_plan) == 14
      and result['started_test_ids'] == result['passed_test_ids'] == test_plan
      and not result['skipped'] and not result['failed_test_ids'] and not result['error_test_ids']
      and result['probe_error'] is None and (ROOT/'tests.log').read_text().count(' ... ok\n') == 14
      and 'Ran 14 tests in ' in (ROOT/'tests.log').read_text())
check('nested and standalone probe result match', result['probe_result'] == probe)
check('baseline expectations were unchanged', sha(BASELINE.read_bytes()) == 'f61215725ec325af70245b33dca266959bf7a7af46194cc4382029bc64b3051d')
check('independent original custody audit unchanged', sha(CUSTODY.read_bytes()) == '666b03a5932370ea9701d51f2e574108b325e365395dd3f3df688a9a90b47ff1')
baseline, custody = read_json(BASELINE), read_json(CUSTODY)
check('baseline math input commitment', sha(canonical(baseline['math_inputs'])) == baseline['math_inputs_sha256'])
expected_inputs = {(r['task_id'],r['decision_index']): r for r in baseline['math_inputs']}
expected_records = {(r['task_id'],r['decision_index']): r for r in custody['transitions']}
expected_baselines = {(r['task_id'],r['decision_index']): r for r in baseline['expected_predictions']}
check('dataset commitment', sha(canonical({k:v for k,v in dataset.items() if k != 'dataset_sha256'})) == dataset['dataset_sha256']
      == plan['dataset_sha256'] == probe['dataset_sha256'])
check('plan binds exact loader and consumer source', plan['source_sha256'] == probe['source_sha256']
      == {k:source['source_sha256'][k] for k in ('ensure_transition_loader.py','skill_completion_advisory.py')})
check('fixed plan hyperparameters', plan['seeds'] == [4101,4102] and plan['planned_fits'] == 20
      and plan['optimizer'] == {'kind':'Adam','steps':200,'learning_rate':.025,'l2_weights':.001,'shape':[10,8,1]})
archive = REPO/'qualification/act2-learning-20261110/run2'
for name, digest in dataset['provenance']['archive_sha256'].items():
    check('original input pin ' + name, sha((archive/name).read_bytes()) == digest == custody['input_sha256'][name])
lines = gzip.decompress((archive/'training-trajectories.jsonl.gz').read_bytes()).splitlines(keepends=True)
original_rows = [json.loads(line) for line in lines]
original_manifest = read_json(archive/'FROZEN_MANIFEST.json')
original_tasks = {r['id']:r for r in original_manifest['train_tasks']}
records = dataset['records']
check('exact original transition roster', len(records) == len(expected_records) == 96
      and {(r['task_id'],r['decision_index']) for r in records} == set(expected_records))
for r in records:
    key = (r['task_id'],r['decision_index'])
    independent = expected_records[key]
    i = r['source']['line_number'] - 1
    row, task = original_rows[i], original_tasks[r['task_id']]
    check('exact original boundary and label ' + r['invocation_id'],
          r['initiation_features'] == independent['initiation_features'] == row['policy_visible_features'][r['decision_index']]
          and r['invocation_id'] == independent['invocation_derived_from_pinned_source']
          and r['goal_sha256'] == independent['goal_sha256']
          and r['invocation_id_observed_directly'] is False
          and r['target']['task_complete_on_readback'] is independent['whole_task_complete_online']
          and r['target']['goal_observed'] is independent['goal_observed_online']
          and r['target']['evidence_event_index'] == independent['label_read_event_index']
          and [w['index'] for w in r['readbacks']] == independent['later_read_event_indices']
          and r['measurements']['option_duration_ns'] is None
          and r['measurements']['event_start_gap_ns'] == independent['event_call_start_gap_ns'])
    check('original line task event record commitments ' + r['invocation_id'],
          sha(lines[i]) == r['source']['line_sha256'] and sha(canonical(row)) == r['source']['row_sha256']
          and sha(canonical(task)) == r['source']['task_sha256']
          and sha(canonical({k:v for k,v in r.items() if k != 'record_sha256'})) == r['record_sha256']
          and all(w['event'] == row['events'][w['index']] and sha(canonical(w['event'])) == w['sha256']
                  for w in [r['initiation'],*r['primitives'],*r['readbacks']]))
check('dataset no oracle or confirmation use flags preserved',
      dataset['provenance']['destination_databases_read'] is False
      and dataset['provenance']['confirmation_trajectories_read'] is False
      and dataset['provenance']['terminal_oracle_fields_used_for_labels'] is False)
check('original episode denominator retained', len(dataset['episodes']) == 80
      and sum(not r['ensure_decision_indices'] for r in dataset['episodes']) == 8)
x = np.asarray([r['initiation_features'] for r in records],dtype=np.float64)
y = np.asarray([np.nan if r['target']['task_complete_on_readback'] is None else float(r['target']['task_complete_on_readback']) for r in records])
groups = np.asarray([expected_inputs[(r['task_id'],r['decision_index'])]['group'] for r in records])
record_index = {r['record_sha256']:i for i,r in enumerate(records)}
check('original masking and feature denominator', len(set(map(tuple,x))) == 3 and np.isfinite(y).sum() == 80
      and np.isnan(y).sum() == 16 and (x[:,1] == 0).all())
for fold in plan['folds']:
    held = groups == fold['held_group']
    check('fold isolation and coverage ' + fold['held_group'],
          fold['held_records'] == [r['record_sha256'] for r,v in zip(records,held) if v]
          and fold['train_records'] == [r['record_sha256'] for r,v in zip(records,held) if not v]
          and fold['held_total'] == int(held.sum())
          and fold['held_observed'] == int(np.isfinite(y[held]).sum())
          and fold['held_rows_with_exact_feature_in_training'] == int(held.sum())
          and {tuple(v) for v in x[held]} <= {tuple(v) for v in x[~held]})
check('no independent feature holdout claim', len(plan['folds']) == 9
      and len(plan['feature_connected_components']) == 1 and plan['independent_task_and_feature_holdout_available'] is False)

fits = probe['fits']
check('exact20 fit directory roster', len(fits) == 20 and len({r['fit'] for r in fits}) == 20
      and {p.name for p in (ROOT/'probe').iterdir() if p.is_dir()} == {r['fit'] for r in fits})
final_parameters, fit_audits, ordered_hashes, multiset_hashes = {}, [], set(), set()
optimizer_records = 0
for fit in fits:
    name = fit['fit']
    destination = ROOT/'probe'/name
    check('fit report original ' + name, read_json(destination/'FIT.json') == fit)
    held = groups == fit['held_group'] if fit['held_group'] is not None else np.zeros(len(groups),dtype=bool)
    training = ~held & np.isfinite(y)
    init, final = tensors(destination/'initial.npz'), tensors(destination/'weights.npz')
    rng = np.random.default_rng(fit['seed'])
    expected_init = {'W':rng.normal(0,.08,(10,8)), 'b':np.zeros(8), 'v':rng.normal(0,.08,8), 'c':np.zeros(1)}
    check('exact seeded initialization and weights ' + name,
          all(np.array_equal(init[k],expected_init[k]) for k in init)
          and parameter_digest(init) == fit['initial_parameters_sha256']
          and parameter_digest(final) == fit['final_parameters_sha256']
          and sha((destination/'weights.npz').read_bytes()) == fit['weights_sha256'])
    train_hash = sha(x[training].astype('<f8').tobytes()+y[training].astype('<f8').tobytes())
    counts = Counter(tuple(row)+(float(target),) for row,target in zip(x[training],y[training]))
    multiset_hash = sha(canonical([[list(row),count] for row,count in sorted(counts.items())]))
    ordered_hashes.add(train_hash); multiset_hashes.add(multiset_hash)
    check('exact masked fold training data ' + name, train_hash == fit['training_data_sha256']
          and multiset_hash == fit['training_multiset_sha256']
          and int(training.sum()) == fit['observed_training_transitions'])
    log = [json.loads(line) for line in (destination/'optimizer.jsonl').read_bytes().splitlines()]
    optimizer_records += len(log)
    check('200 contiguous changed parameter links ' + name,
          len(log) == fit['optimizer_invocations'] == fit['parameter_mutations'] == 200
          and [r['step'] for r in log] == list(range(1,201))
          and log[0]['parameters_before_sha256'] == parameter_digest(init)
          and log[-1]['parameters_after_sha256'] == parameter_digest(final)
          and all(a['parameters_after_sha256'] == b['parameters_before_sha256'] for a,b in zip(log,log[1:]))
          and all(r['parameter_bytes_changed'] is True and r['parameters_before_sha256'] != r['parameters_after_sha256']
                  and all(math.isfinite(r[k]) and r[k] > 0 for k in ('bce_before','objective_before','gradient_l2','update_l2')) for r in log))
    initial_bce, final_bce = bce(init,x[training],y[training]), bce(final,x[training],y[training])
    objective = final_bce + .0005*(np.sum(final['W']**2)+np.sum(final['v']**2))
    check('independent initial final loss and objective ' + name, close(initial_bce,fit['initial_bce'])
          and close(initial_bce,log[0]['bce_before']) and close(final_bce,fit['final_bce'])
          and close(objective,fit['final_objective']) and final_bce < initial_bce)
    final_parameters[name] = final
    fit_audits.append({'fit':name,'seed':fit['seed'],'held_group':fit['held_group'],
                       'training_rows':int(training.sum()),'initial_parameter_sha256':parameter_digest(init),
                       'final_parameter_sha256':parameter_digest(final),'optimizer_links_verified':len(log),
                       'initial_bce_recomputed':initial_bce,'final_bce_recomputed':final_bce,
                       'final_objective_recomputed':float(objective),
                       'training_ordered_array_sha256':train_hash,'training_multiset_sha256':multiset_hash})
check('actual fit update diversity denominators', optimizer_records == probe['optimizer_invocations'] == 4000
      and probe['fit_count'] == 20 and len(ordered_hashes) == probe['distinct_ordered_supervised_arrays'] == 8
      and len(multiset_hashes) == probe['distinct_supervised_multisets'] == 6)
predictions = [json.loads(line) for line in (ROOT/'probe/PREDICTIONS.jsonl').read_bytes().splitlines()]
check('exact192 one-per-seed transition predictions', len(predictions) == 192
      and len({(r['seed'],r['record_sha256']) for r in predictions}) == 192
      and all(sum(p['seed'] == seed for p in predictions) == 96 for seed in (4101,4102)))
max_neural_difference, max_baseline_difference = 0.0, 0.0
for fit in fits:
    if fit['held_group'] is None:
        continue
    held_indices = np.flatnonzero(groups == fit['held_group'])
    direct = forecast(final_parameters[fit['fit']],x[held_indices])
    reported = {r['record_sha256']:r for r in predictions if r['fit'] == fit['fit']}
    check('OOF saved weight prediction roster ' + fit['fit'], set(reported) == {records[i]['record_sha256'] for i in held_indices})
    for index,p in zip(held_indices,direct):
        original = records[index]; r = reported[original['record_sha256']]
        key = (original['task_id'],original['decision_index']); expectation = expected_baselines[key]
        max_neural_difference = max(max_neural_difference,abs(float(p)-r['probability']['neural_advisory']))
        check('saved neural tensor and target ' + fit['fit'] + '/' + original['invocation_id'],
              close(p,r['probability']['neural_advisory']) and r['seed'] == fit['seed']
              and r['held_group'] == fit['held_group'] == expectation['group']
              and r['task_id'] == original['task_id']
              and r['target'] is original['target']['task_complete_on_readback']
              and r['censoring'] == original['target']['censoring'])
        for name, expected in expectation['probabilities'].items():
            max_baseline_difference = max(max_baseline_difference,abs(expected-r['probability'][name]))
            check('frozen independent baseline prediction ' + name + '/' + fit['fit'] + '/' + original['invocation_id'],
                  close(expected,r['probability'][name]))
metric_audit = {}
for seed in (4101,4102):
    selected = [r for r in predictions if r['seed'] == seed]
    metric_audit[str(seed)] = {name:metrics(selected,name) for name in ('neural_advisory','smoothed_constant','laplace_exact_feature_table')}
    for name, value in metric_audit[str(seed)].items():
        check('independent aggregate proper scores ' + str(seed) + '/' + name,
              equal_metrics(probe['by_seed'][str(seed)][name],value))
        if name != 'neural_advisory':
            check('frozen aggregate baseline ' + str(seed) + '/' + name,
                  equal_metrics(value,baseline['expected_baseline_metrics'][name]))
for fold in probe['fold_metrics']:
    selected = [r for r in predictions if r['fit'] == fold['fit']]
    for name,value in fold['metrics'].items():
        check('independent fold scores ' + fold['fit'] + '/' + name,equal_metrics(value,metrics(selected,name)))
check('fully censored folds report null rather than zero error',
      probe['fully_censored_folds'] == 2 and probe['folds_with_observed_targets'] == 7
      and sum(f['metrics']['neural_advisory']['observed'] == 0 for f in probe['fold_metrics']) == 4
      and all(all(v[k] is None for v in f['metrics'].values() for k in ('brier','log_loss','accuracy','confusion'))
              for f in probe['fold_metrics'] if f['metrics']['neural_advisory']['observed'] == 0))
full_fit_audit = []
for fit in fits:
    if fit['held_group'] is not None:
        continue
    direct = forecast(final_parameters[fit['fit']],x)
    rows = [{'target':None if np.isnan(t) else bool(t), 'probability':{'neural_advisory':float(p)}} for t,p in zip(y,direct)]
    scores = metrics(rows,'neural_advisory'); bounds = baseline['single_full_model_empirical_bounds']
    check('full-fit empirical information bounds ' + fit['fit'],scores['accuracy'] <= bounds['maximum_accuracy'] + 1e-12
          and scores['brier'] >= bounds['minimum_brier'] - 1e-12
          and scores['log_loss'] >= bounds['minimum_log_loss'] - 1e-12)
    full_fit_audit.append({'fit':fit['fit'],'observed_train_scores_only':scores,
                          'unique_entry_probabilities':[{'entry_features':list(pattern),
                                                        'probability':float(forecast(final_parameters[fit['fit']],np.asarray([pattern]))[0])}
                                                       for pattern in sorted(set(map(tuple,x)))]})
check('negative comparative proper scores preserved', all(
      values['neural_advisory']['brier'] > values[baseline_name]['brier']
      and values['neural_advisory']['log_loss'] > values[baseline_name]['log_loss']
      for values in metric_audit.values() for baseline_name in ('smoothed_constant','laplace_exact_feature_table')))
check('scope and negative adoption preserved', all(probe[k] is False for k in
      ('promotion','operational_evaluation_performed','learned_skill_selection_qualified','stop_authority'))
      and probe['fixed_skill_library_retained'] is True and probe['new_independent_real_tasks'] == probe['new_confirmation_tasks'] == 0
      and result['production_authority'] is False and result['operational_benefit_qualified'] is False
      and manifest['original_execution_host_contact'] is False)
check('retained originals unchanged after audit', all(sha((ROOT/n).read_bytes()) == h for n,h in sums.items())
      and sha((ROOT/'SHA256SUMS.json').read_bytes()) == sums_hash)
report = {
    'schema':'hepta.independent-skill-completion-retained-audit.v1',
    'created_at_utc':datetime.now(timezone.utc).isoformat(),
    'result':'PASS_SCOPED_RETAINED_ORIGINAL_AUDIT_WITH_NEGATIVE_ADVISORY_RESULT',
    'reviewer':'/root/act_ci_audit','qualification_directory':str(ROOT),
    'source_commit':COMMIT,'source_tree':TREE,'retained_sha256sums_sha256':sums_hash,
    'independent_baseline_sha256':sha(BASELINE.read_bytes()),'independent_custody_sha256':sha(CUSTODY.read_bytes()),
    'checks_passed':len(checks),'checks_failed':0,'checks':checks,
    'counts':{'retained_file_digests_verified':len(sums),'source_postimages_matched_exact_git_blobs':len(source['source_sha256']),
              'historical_gru_model_git_blob_hashes_verified_but_not_fitted':len(source['model_sha256']),
              'integrity_math_tests_actually_passed':14,'corpus_fit_directories':20,'saved_model_files_verified':40,
              'parameters_per_model':97,'corpus_optimizer_records_and_links_verified':optimizer_records,
              'separate_synthetic_unit_optimizer_updates_not_corpus_fits':30,
              'distinct_ordered_supervised_arrays':8,'distinct_supervised_multisets':6,
              'distinct_initial_parameter_snapshots':len({r['initial_parameter_sha256'] for r in fit_audits}),
              'distinct_final_parameter_snapshots':len({r['final_parameter_sha256'] for r in fit_audits}),
              'original_train_episodes':80,'original_ensure_transitions':96,'observed_labels':80,'censored_labels':16,
              'OOF_neural_predictions_recomputed_directly_from_saved_tensors':192,
              'OOF_baseline_predictions_compared_to_prior_independent_expected_values':384,
              'unique_initiation_feature_vectors':3,'families':9,'fully_censored_families':2},
    'qualification_wall_ns':result['wall_ns'],'corpus_campaign_wall_ns':probe['campaign_wall_ns'],
    'max_absolute_neural_probability_difference':max_neural_difference,
    'max_absolute_baseline_probability_difference':max_baseline_difference,
    'actual_recomputed_metrics_by_seed':metric_audit,
    'full_fit_observed_train_only_metrics':full_fit_audit,'fit_audits':fit_audits,
    'scope':{'source_or_repository_modified':False,'fits_rerun_by_auditor':0,'test_suites_rerun_by_auditor':0,
             'loader_or_consumer_imported_by_auditor':False,'inference_method':'Independent NumPy tanh/logistic formula from retained model tensors only.',
             'optimizer_verification':'4000 retained changed-parameter records, exact initial/final tensors, consecutive digest links and loss recomputation; no optimizer replay.',
             'not_a_tamper_proof_execution_attestation':True,
             'labels':'Only original subsequent actor readback; 16 UNKNOWN remain masked despite separate privileged custody knowledge.',
             'new_independent_tasks':0,'independent_feature_holdout':False,'new_application_version_fault_evidence':False,
             'operational_net_utility_evaluation':False,'new_tool_host_or_production_authority':False,
             'promotion':False,'fixed_skill_library_retained':True,
             'seeds_are_not_new_tasks':True,
             'denominator_warning':'Neural/table32/80forecast accuracy and constant56/80forecast accuracy refer to observed old-TRAIN labels; historical512/640 fixed-workflow completion is a different operational metric.'},
    'finding':'Both neural seeds match table40% forecast accuracy but have worse Brier/log-loss than both baselines. Fits and model changes are real retained work; this corpus shows no advisory predictive advantage and no operational gain.',
    'audit_script_sha256':sha(Path(__file__).read_bytes()),
}
OUT.write_text(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+'\n')
print(json.dumps({'audit':str(OUT),'sha256':sha(OUT.read_bytes()),'checks_passed':len(checks),
                  'counts':report['counts'],'metrics':metric_audit,'full_fit_metrics':full_fit_audit,
                  'max_probability_difference':max_neural_difference}))
