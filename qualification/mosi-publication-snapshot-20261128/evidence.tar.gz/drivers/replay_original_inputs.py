"""New snapshot-path compatibility replay on fixed GitHub originals; no live producer reads."""
import base64
import contextlib
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import stat
import sys
import time
import traceback

ROOT=Path(__file__).resolve().parent
COPIES=ROOT.parent/'mosi-recount'
TASK=ROOT/'original-inputs-4b84'
OUT=ROOT/'evidence/original-input-compatibility'
CANDIDATE=ROOT/'candidate/qualification/hcsn_sustained_20261128/mosi_recovery'
RAW_COMMIT='4b84b0431b089ccac84c75ac3ac19f96ad804fe4'
SOURCE_SHA='3d9acc0993287815783e839dd5672c0f32c11f017fd6aa5b089cdb9a8f7376cd'
DATA_SHA='968dfb23d19f7ba50c9907b2146810e09922283b4b4342618e8d2eac151c4f70'
FRESH_MANIFEST_SHA='1033cd2e6a0002eee1c4e9c4a1beecc43d27e096ebd22bc8bda99770a2898930'

def identity(data):
    return {'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
def read_copy(path):
    info=path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or path.is_symlink():
        raise ValueError('only independent regular audit copies are allowed: '+str(path))
    return path.read_bytes()
def put(name,data):
    path=TASK/name
    if path.exists():
        if read_copy(path)!=data:raise ValueError('overlapping archived input differs: '+name)
        return False
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as out:out.write(data)
    return True
def save(path,value):
    with path.open('x',encoding='utf-8') as out:
        out.write(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')
def main():
    if not __debug__:raise ValueError('assertions required')
    OUT.mkdir(exist_ok=False);TASK.mkdir(mode=0o700,exist_ok=False)
    started=time.monotonic();cpu=time.process_time()
    record={'schema':'hepta.mosi.frozen-original-input-compatibility.v1',
            'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'raw_commit':RAW_COMMIT,'source_sha256':SOURCE_SHA,
            'source_parent_commit':'41aae3602f9f24e80ccf70dcea1bbcaa99774cb3',
            'new_forward':False,'new_training':False,'network_publication':False,
            'original_producer_directory_read':False,'producer_timing_remeasured':False,
            'scope':'Necessary compatibility validation of the new frozen-publication implementation against already fixed original bytes. It is not another trained experiment.',
            'scopes':{},'copied_objects':[]}
    try:
        candidate_bytes=read_copy(CANDIDATE/'publish_mosi.py')
        if identity(candidate_bytes)['sha256']!=SOURCE_SHA:raise ValueError('candidate source identity')
        bundle=json.loads(read_copy(ROOT/'original-recovery-4b84.json'))
        if bundle['commit']!=RAW_COMMIT:raise ValueError('wrong fixed recovery commit')
        manifest_bytes=bundle['manifest_utf8'].encode()
        if identity(manifest_bytes)['git_blob']!=bundle['manifest_git_blob']:
            raise ValueError('recovery original canonical index identity')
        recovery_manifest=json.loads(manifest_bytes)
        if len(recovery_manifest)!=24 or len(bundle['objects'])!=24:raise ValueError('recovery object count')
        recovery_alias={'historical_SEAL.json':'source/SEAL.json',
                        'candidate_hash_seal.json':'candidate_replay/candidate_hash_seal.json',
                        'reconstruction_result.json':'candidate_replay/reconstruction_result.json'}
        for item in bundle['objects']:
            data=base64.b64decode(item['data_base64'],validate=True);actual=identity(data)
            if any(actual[k]!=item[k] for k in ('size','sha256','git_blob')):raise ValueError('recovery Git object identity')
            if any(actual[k]!=recovery_manifest[item['name']][k] for k in ('size','sha256')):raise ValueError('recovery canonical hash')
            name=item['name']
            if name.startswith('selected/'):target='candidate_replay/fits/'+name.removeprefix('selected/')
            elif name.startswith('cold/'):target='candidate_replay/'+name.removeprefix('cold/')
            else:target=recovery_alias.get(name,name)
            put(target,data);record['copied_objects'].append({'scope':'recovery','archived_name':name,'task_name':target,**actual})
        fresh_manifest_bytes=read_copy(COPIES/'raw/verified_objects.json')
        if identity(fresh_manifest_bytes)['sha256']!=FRESH_MANIFEST_SHA:raise ValueError('original fresh index identity')
        fresh_manifest=json.loads(fresh_manifest_bytes)
        if len(fresh_manifest)!=165:raise ValueError('fresh original object count')
        fresh_alias={'FRESH_SEAL.json':'fresh/FRESH_SEAL.json',
                     'terminal_manifest.json':'fresh/terminal_manifest.json',
                     'AV_input_provenance.json':'fresh/av_train_inputs/manifest.json',
                     'PROSPECTIVE_REPLICATION.md':'PROSPECTIVE_REPLICATION.md',
                     'fresh_study.py':'fresh_study.py','input_recovery.json':'input_recovery.json'}
        for name,item in fresh_manifest.items():
            data=read_copy(COPIES/'raw'/name);actual=identity(data)
            if any(actual[k]!=item[k] for k in ('size','sha256')):raise ValueError('fresh exact original object')
            if name.startswith(('models/','cold/','result/')):target='fresh/'+name
            elif name in fresh_alias:target=fresh_alias[name]
            else:raise ValueError('unexpected fresh root object')
            put(target,data);record['copied_objects'].append({'scope':'fresh','archived_name':name,'task_name':target,**actual})
        data=read_copy(COPIES/'data.json')
        if identity(data)['sha256']!=DATA_SHA:raise ValueError('recovered original data identity')
        put('reconstructed/data.json',data)
        verifier=read_copy(COPIES/'source/verify.py')
        if identity(verifier)['sha256']!='bdbb45e0ad4227ef2750bb7d35ca4d2035b1c9fd8257d2c4e2c7ed7fa76b17af':
            raise ValueError('original verifier identity')
        put('source/verify.py',verifier)
        before={str(path.relative_to(TASK)):identity(read_copy(path)) for path in TASK.rglob('*') if path.is_file()}
        (TASK/'publication').mkdir()
        sys.path.insert(0,str(CANDIDATE))
        import publish_mosi as relay
        for kind,mapper,expected in [
            ('mosi_recovery_raw',relay.recovery_map,recovery_manifest),
            ('mosi_fresh_raw',relay.fresh_map,{**fresh_manifest,'data.json':{'sha256':DATA_SHA,'size':len(data)}})
        ]:
            start=time.monotonic()
            with (OUT/(kind+'.stdout.log')).open('x') as stdout,(OUT/(kind+'.stderr.log')).open('x') as stderr:
                with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
                    frozen=relay.freeze_publication(TASK,TASK/'publication',kind,mapper)
            actual=json.loads(frozen.manifest)
            if actual!=expected:raise ValueError('new snapshot does not equal the original object set: '+kind)
            expected_bytes=(json.dumps({name:expected[name] for name in sorted(expected)},indent=2,allow_nan=False)+'\n').encode()
            if frozen.manifest!=expected_bytes:raise ValueError('canonical original manifest encoding differs')
            for name,payload in frozen.payloads:
                if identity(payload)['sha256']!=expected[name]['sha256']:raise ValueError('frozen original payload differs')
            (OUT/(kind+'.manifest.json')).write_bytes(frozen.manifest)
            record['scopes'][kind]={
                'status':'PASS','payload_objects':len(frozen.payloads),'receipt_objects_including_index':len(frozen.objects),
                'payload_bytes':sum(len(payload) for name,payload in frozen.payloads),
                'manifest_sha256':identity(frozen.manifest)['sha256'],
                'manifest_git_blob':frozen.objects['verified_objects.json'],
                'canonical_original_object_set_equal':True,
                'original_verifier_executions':1 if kind=='mosi_fresh_raw' else 0,
                'original_recovery_math_executions':1 if kind=='mosi_recovery_raw' else 0,
                'wall_s':time.monotonic()-start,
                'no_private_validation_directory_remains':not any((TASK/'publication').iterdir())}
        after={str(path.relative_to(TASK)):identity(read_copy(path)) for path in TASK.rglob('*') if path.is_file()}
        if before!=after:raise ValueError('original copied inputs changed during validation')
        record['copied_inputs_unchanged']=True
        record['copied_input_files']=len(before)
        record['copied_input_bytes']=sum(item['size'] for item in before.values())
        record['candidate_source_unchanged']=read_copy(CANDIDATE/'publish_mosi.py')==candidate_bytes
        record['status']='PASS'
    except BaseException:
        record['status']='FAIL';record['exception']=traceback.format_exc()
    finally:
        record['wall_s']=time.monotonic()-started;record['cpu_s']=time.process_time()-cpu
        record['peak_self_rss_KiB']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        record['exit_code']=0 if record['status']=='PASS' else 1
        save(OUT/'RESULT.json',record)
        print(json.dumps({key:record.get(key) for key in
                         ('status','scopes','copied_inputs_unchanged','copied_input_files','copied_input_bytes','wall_s','peak_self_rss_KiB','exit_code','exception')},sort_keys=True))
    return record['exit_code']
if __name__=='__main__':
    raise SystemExit(main())
