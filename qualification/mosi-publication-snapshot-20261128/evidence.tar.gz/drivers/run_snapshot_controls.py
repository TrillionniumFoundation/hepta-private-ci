"""Execute the frozen-publication controls on actual original validator code."""
import contextlib
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import sys
import tempfile
import time
import traceback
import unittest

ROOT=Path(__file__).resolve().parent
CANDIDATE=ROOT/'candidate'
MODULE=CANDIDATE/'qualification/hcsn_sustained_20261128/mosi_recovery'
EXPECTED_TESTS=37
SOURCES=[
 'qualification/hcsn_sustained_20261128/mosi_recovery/publish_mosi.py',
 'qualification/hcsn_sustained_20261128/mosi_recovery/test_publish_mosi.py',
 'qualification/hcsn_sustained_20261128/mosi_recovery/fresh_study.py',
 'qualification/hcsn_sustained_20261128/mosi_recovery/PROSPECTIVE_REPLICATION.md',
 'qualification/hcsn_sustained_20261128/crema/publish_results.py',
 'qualification/hcsn_sustained_20261128/crema/archive.py',
 'qualification/hcsn_mosi_three_stream_20261127/verify.py',
]
def identities():
    out={}
    for name in SOURCES:
        data=(CANDIDATE/name).read_bytes()
        out[name]={'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                   'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
    return out
def save(path,value):
    with path.open('x',encoding='utf-8') as output:
        output.write(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')

def main():
    name=sys.argv[1]
    if '/' in name or name in ('','.','..'):raise ValueError('invalid attempt name')
    out=ROOT/'evidence'/name;out.mkdir(exist_ok=False)
    owned_temp=out/'temporary';owned_temp.mkdir()
    tempfile.tempdir=str(owned_temp)
    before=identities()
    start=time.monotonic();cpu=time.process_time()
    record={'schema':'hepta.mosi.frozen-publication-controls.v1',
            'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'parent_commit':'41aae3602f9f24e80ccf70dcea1bbcaa99774cb3',
            'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
            'environment':{key:os.environ.get(key) for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','PYTHONOPTIMIZE','PYTHONDONTWRITEBYTECODE')},
            'priority_nice':os.getpriority(os.PRIO_PROCESS,0),
            'source_before':before,'events':[],
            'scope':'Original fixed mathematical validators execute on explicitly synthetic prediction fixtures. Real isolated Git objects exercise publication; no model forward, training or network publication.',
            'model_forward':False,'training':False,'network_publication':False}
    class Result(unittest.TextTestResult):
        def addSuccess(self,test):
            super().addSuccess(test);record['events'].append({'test':test.id(),'status':'PASS'})
        def preserve(self,test):
            task=getattr(test,'task',None)
            if task is not None and Path(task).exists():
                target=out/'failed-fixtures'/test.id().split('.')[-1]
                if not target.exists():shutil.copytree(task,target)
        def addError(self,test,error):
            super().addError(test,error);record['events'].append({'test':test.id(),'status':'ERROR'})
            self.preserve(test)
        def addFailure(self,test,error):
            super().addFailure(test,error);record['events'].append({'test':test.id(),'status':'FAIL'})
            self.preserve(test)
        def addSubTest(self,test,subtest,error):
            super().addSubTest(test,subtest,error)
            record['events'].append({'test':test.id(),'subtest':str(subtest),
                                     'status':'PASS' if error is None else 'FAIL'})
            if error is not None:self.preserve(test)
    try:
        sys.path.insert(0,str(MODULE))
        with (out/'stdout.log').open('x') as stdout,(out/'stderr.log').open('x') as stderr,(out/'unittest.log').open('x') as log:
            with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
                suite=unittest.defaultTestLoader.discover(str(MODULE),pattern='test_publish_mosi.py')
                record['planned_tests']=suite.countTestCases()
                result=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Result).run(suite)
        record.update(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=len(result.skipped))
        record['source_after']=identities()
        record['sources_unchanged']=record['source_after']==before
        record['successful']=(result.wasSuccessful() and result.testsRun==EXPECTED_TESTS
                              and not result.skipped and record['sources_unchanged'])
        record['status']='PASS' if record['successful'] else 'FAIL'
        import numpy as np
        record['numpy']=np.__version__
    except BaseException:
        record['status']='ERROR';record['exception']=traceback.format_exc()
    finally:
        record['wall_s']=time.monotonic()-start;record['cpu_s']=time.process_time()-cpu
        record['peak_self_rss_KiB']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        record['peak_children_rss_KiB']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
        record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        record['exit_code']=0 if record['status']=='PASS' else 1
        save(out/'RESULT.json',record)
        print(json.dumps({key:record.get(key) for key in ('status','tests','failures','errors','skips','wall_s','peak_self_rss_KiB','exit_code')},sort_keys=True))
    return record['exit_code']

if __name__=='__main__':
    raise SystemExit(main())
