"""Package the already executed snapshot qualification; do not rerun controls or validators."""
import ast
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

ROOT=Path(__file__).resolve().parent
CANDIDATE=ROOT/'candidate'
EVIDENCE=ROOT/'evidence'
PACKAGE_REL='qualification/mosi-publication-snapshot-20261128'
PACKAGE=CANDIDATE/PACKAGE_REL
PRODUCTION='qualification/hcsn_sustained_20261128/mosi_recovery/publish_mosi.py'
TEST='qualification/hcsn_sustained_20261128/mosi_recovery/test_publish_mosi.py'
PARENT='41aae3602f9f24e80ccf70dcea1bbcaa99774cb3'
PARENT_TREE='254862ae637e5a7d414f175c7b139bd1ae665105'
PRODUCTION_SHA='3d9acc0993287815783e839dd5672c0f32c11f017fd6aa5b089cdb9a8f7376cd'
TEST_SHA='544ed838b6810e1c25cb5368d70a3f1affe3cca7cd2f5038c3005e6a9075a3f9'

def identity(data):
    return {'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
def require(condition,message):
    if not condition:raise ValueError(message)
def write_new(path,data):
    if not isinstance(data,bytes):data=data.encode()
    with path.open('xb') as output:output.write(data)
def encoded(value):return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def function_text(data,name):
    source=data.decode()
    for node in ast.walk(ast.parse(source)):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name==name:
            return ast.get_source_segment(source,node)
    raise ValueError('missing function '+name)

def main():
    PACKAGE.mkdir(parents=True,exist_ok=False)
    production=(CANDIDATE/PRODUCTION).read_bytes();test=(CANDIDATE/TEST).read_bytes()
    require(identity(production)['sha256']==PRODUCTION_SHA,'tested production changed')
    require(identity(test)['sha256']==TEST_SHA,'tested tests changed')
    controls=json.loads((EVIDENCE/'attempt-01/RESULT.json').read_bytes())
    compatible=json.loads((EVIDENCE/'original-input-compatibility/RESULT.json').read_bytes())
    formatting=json.loads((EVIDENCE/'MOSI_FROZEN_FORMAT_RESULT.json').read_bytes())
    require(controls['status']=='PASS' and controls['tests']==37 and
            controls['failures']==controls['errors']==controls['skips']==0,'controls incomplete')
    require(controls['source_before']==controls['source_after'],'control source changed')
    require(compatible['status']=='PASS' and compatible['candidate_source_unchanged'] and
            compatible['copied_inputs_unchanged'],'original compatibility incomplete')
    require(formatting['exit_code']==0,'format driver failed')
    for row in formatting['candidate_files']:
        actual=PRODUCTION_SHA if row['path']==PRODUCTION else TEST_SHA
        require(row['before_sha256']==row['after_sha256']==actual,'format source pin differs')
    prior_payload=(EVIDENCE/'preceding-evidence.tar.gz').read_bytes()
    require(identity(prior_payload)['sha256']=='2bcc7b7871e9f106203fce4278c59620b5fecf6368e136486be9e9812c6f6c42','preceding evidence differs')
    prior={}
    with tarfile.open(fileobj=io.BytesIO(prior_payload),mode='r:gz') as archive:
        for member in archive.getmembers():
            name=member.name;parts=PurePosixPath(name).parts
            require(member.isfile() and name and not name.startswith('/') and
                    all(part not in ('.','..') for part in parts) and '/'.join(parts)==name,
                    'unsafe prior archive member')
            require(name not in prior and member.size<1024*1024,'duplicate or oversized prior member')
            with archive.extractfile(member) as handle:prior[name]=handle.read()
    old_production=prior['counterexample/source/publish_mosi.py']
    old_test=prior['counterexample/source/test_publish_mosi.py']
    require(identity(old_production)['sha256']=='ba76f99405fab27c1c21ee579602202c096cac9fea2abcaf0c7e0bf025e17f8e','counterexample source differs')
    require(identity(old_test)['sha256']=='041a353c9bb78438f7430e4bff54240d6ebef346004db147e631272a96b57ac4','counterexample tests differ')
    preserved=['object_id','validate_receipt','receipt_from','api_objects','native_objects',
               'verify_publication','digest','read','save','git','recovery_map']
    for name in preserved:
        require(function_text(old_production,name)==function_text(production,name),'unrelated function changed '+name)
    before_names={node.name for node in ast.walk(ast.parse(old_test))
                  if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')}
    after_names={node.name for node in ast.walk(ast.parse(test))
                 if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')}
    require(len(before_names)==21 and before_names<=after_names and len(after_names)==37,'old control coverage lost')
    scope={'parent_commit':PARENT,'parent_tree':PARENT_TREE,
           'current_source':{PRODUCTION:identity(production),TEST:identity(test)},
           'unchanged_function_source_segments':preserved,
           'prior_21_control_names_retained':sorted(before_names),
           'new_16_control_names':sorted(after_names-before_names),
           'original_scientific_verifier_file_modified':False,
           'original_publisher_helper_and_archive_dependency_modified':False,
           'private_source_and_manifest_bytes_flow':'capture -> independent ordinary private files -> original mathematics -> before/after file identity and bytes -> immutable captured payloads -> original API/native stdin -> exact remote commit verification',
           'test_freeze_mocked':False,'original_test_validator_main_replaced':False,
           'runtime_security_scope':'local process/filesystem mutation; no claim against arbitrary same-UID memory or host-kernel compromise',
           'working_copy':'fixed source bundle, not a full local Git checkout'}
    write_new(EVIDENCE/'FINAL_SOURCE_SCOPE.json',encoded(scope))
    patch=''
    for path,before,after in [(PRODUCTION,old_production,production),(TEST,old_test,test)]:
        patch+=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),
                                           after.decode().splitlines(keepends=True),
                                           fromfile='a/'+path,tofile='b/'+path))
    write_new(EVIDENCE/'FINAL_SOURCE.patch',patch)
    counterexample=json.loads(prior['counterexample/RESULT.json'])
    require(counterexample['status']=='COUNTEREXAMPLE_REPRODUCED' and counterexample['completed_with_unsealed_data'],
            'first false-completion counterexample absent')
    selected={}
    for label,payload in prior.items():selected['preceding/'+label]=payload
    for relative in [
        'attempt-01/RESULT.json','attempt-01/unittest.log','attempt-01/stdout.log','attempt-01/stderr.log',
        'original-input-compatibility/RESULT.json',
        'original-input-compatibility/mosi_recovery_raw.stdout.log',
        'original-input-compatibility/mosi_recovery_raw.stderr.log',
        'original-input-compatibility/mosi_recovery_raw.manifest.json',
        'original-input-compatibility/mosi_fresh_raw.stdout.log',
        'original-input-compatibility/mosi_fresh_raw.stderr.log',
        'original-input-compatibility/mosi_fresh_raw.manifest.json',
        'MOSI_FROZEN_FORMAT_RESULT.json','CONTROL_START_RECONCILIATION.json',
        'MOSI_ATTEMPT_SCOPED_OBSERVATION.json','PROFILE_BOUNDS.json',
        'FINAL_SOURCE_SCOPE.json','FINAL_SOURCE.patch',
    ]:selected['evidence/'+relative]=(EVIDENCE/relative).read_bytes()
    for path,item in controls['source_after'].items():
        payload=(CANDIDATE/path).read_bytes()
        require(identity(payload)==item,'source inventory differs '+path)
        selected['source/'+path]=payload
    for name in ('run_snapshot_controls.py','replay_original_inputs.py','package_snapshot_qualification.py'):
        selected['drivers/'+name]=(ROOT/name).read_bytes()
    inventory=[]
    archive_path=PACKAGE/'evidence.tar.gz'
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as archive:
                for name,payload in sorted(selected.items()):
                    info=tarfile.TarInfo(name);info.size=len(payload);info.mode=0o644
                    info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
                    archive.addfile(info,io.BytesIO(payload))
                    inventory.append({'path':name,**identity(payload)})
    archive_identity=identity(archive_path.read_bytes())
    require(archive_identity['size']<500*1024,'archive exceeds existing blob policy')
    controls_summary={key:value for key,value in controls.items() if key not in ('events','source_before','source_after')}
    compatible_summary={key:value for key,value in compatible.items() if key!='copied_objects'}
    result={
        'schema':'hepta.mosi.immutable-publication-qualification.v1',
        'parent_commit':PARENT,'parent_tree':PARENT_TREE,
        'status':'PASS_FOR_DECLARED_LOCAL_PUBLICATION_SCOPE',
        'source':scope['current_source'],
        'first_counterexample':{
            'old_production_sha256':identity(old_production)['sha256'],
            'result_sha256':identity(prior['counterexample/RESULT.json'])['sha256'],
            'wrong_completion_commit':counterexample['completed_receipt']['commit'],
            'wrong_completion_receipt_sha256':counterexample['receipt_sha256'],
            'published_data_sha256':counterexample['published_data_sha256'],
            'published_seal_expected_data_sha256':counterexample['published_seal_data_sha256'],
            'later_resume_refused':counterexample['next_resume_rejects'],
            'scope':'Deterministic synthetic fixture and real local Git. Not evidence of historic scientific corruption.'},
        'controls':controls_summary,'actual_original_input_compatibility':compatible_summary,
        'profile_bounds':json.loads((EVIDENCE/'PROFILE_BOUNDS.json').read_bytes()),
        'format':{
            'receipt_sha256':identity((EVIDENCE/'MOSI_FROZEN_FORMAT_RESULT.json').read_bytes())['sha256'],
            'exit_code':formatting['exit_code'],'wall_seconds':formatting['wall_seconds'],
            'scope':formatting['scope'],'stdout':formatting['stdout'],'qualification':formatting['qualification'],
            'candidate_hashes_unchanged':True,'tests_rerun_after_format':False},
        'start_reconciliation':{
            'first_write_outcome':'UNKNOWN',
            'scoped_observation_sha256':'9db303e9732928c11c9d0c7fef2a20e2c00ff047777c5579d8a4be8fd0d61b09',
            'same_session_request_id_and_input_retry':True,
            'runner_create_only_attempt_guard':True,
            'claim_first_write_never_executed':False,
            'unknown_external_task_restarted':False},
        'unchanged_core_functions':preserved,
        'original_21_control_names_retained':True,'new_control_methods':16,
        'new_forward_or_training':False,'real_remote_publication_during_controls':False,
        'scientific_results_or_quality_gates_changed':False,
        'preceding_published_data_closure_commit':PARENT,
        'security_scope':scope['runtime_security_scope'],
        'evidence_archive':archive_identity,'evidence_archive_members':len(inventory)
    }
    write_new(PACKAGE/'RESULT.json',encoded(result))
    readme="# Publish the bytes that passed the original MOSI validation\n\n## Defect and fix\n\nThe prior publisher validated live task paths, read those paths again to create\nits manifest, then hardlinked them into a staging directory. A deterministic\ncounterexample changed the data manifest after the original mapper returned\nand before the manifest read. The first publication completed with a data SHA\nthat contradicted its own published seal. Immutable Git readback accepted the\nnew manifest's objects. A later resume rejected the current data, but that did\nnot prevent the first incorrect completion receipt.\n\nThe retained counterexample is an explicitly synthetic publisher fixture using\nreal local Git objects. It does not establish corruption of any historical\nscientific result. Its first wrong receipt, local commit, driver, source\npreimages and fixture objects are archived without modification.\n\nThis change is based on commit 41aae3602f9f24e80ccf70dcea1bbcaa99774cb3. Both new\npublication and receipt resume now follow the same sequence:\n\n1. Capture small metadata once and derive all other canonical relative paths\n   from those captured bytes. Read through directory descriptors without\n   symlinks, reject nonregular files, and enforce finite byte and file-count\n   bounds. Source hardlinks remain valid. A final component is opened\n   nonblocking so a FIFO cannot stall before the regular-file check.\n2. Materialize independent ordinary files in a new private directory. The\n   directory is mode 0700, the input files are mode 0400, and no source hardlink\n   is reused. Verify file identity and contents before the original validators\n   run and again after they finish.\n3. Run the original recovery mathematics or the original saved-prediction\n   verifier against that private copy. Required task-local algorithm modules\n   are compiled from the same hash-checked bytes, without reusing task module\n   caches or changing global import paths.\n4. Require every mapper output to refer to the captured dependency closure.\n   Create the canonical manifest and Git IDs from the captured immutable byte\n   values. The private validation directory is removed.\n5. Give those same bytes to the original API publisher or to native Git.\n   FrozenFile implements the API helper's existing read_bytes/relative_to\n   protocol without reading a path. Native Git hashes stdin bytes. Retries\n   retain the same values. Final fixed-commit readback remains mandatory before\n   a completion receipt is saved.\n\nA producer may change after capture without changing the already validated\npublication. Replacement of a private validation input before or during\nvalidation is rejected by the original seals or the before/after identity and\ncontent checks. Replacing a private path after the final check cannot change\nthe byte values subsequently hashed or uploaded.\n\n## Dependency and source identity\n\nRecovery captures the historical seal, reconstruction result and candidate\nhash seal first. It then captures the enrolled saved predictions and selected\nweights, the recovery and source-transfer records, and the optional custody\naudit. The original recovery mathematical function is unchanged.\n\nFresh capture covers the fresh seal and terminal, all terminal-enrolled\nmodels/cold/result objects, the exact data manifest, AV provenance, protocol,\nfresh driver, recovery record and original verifier source. Fresh math uses\nthe original verifier with the same enrolled designs as the original driver.\n\nThe original verifier is SHA256\nbdbb45e0ad4227ef2750bb7d35ca4d2035b1c9fd8257d2c4e2c7ed7fa76b17af,\nfrom commit 4f80d069218e5416be0f51323a9db46b461d07dd. The driver is\ne7537324fb45f9bfbde4dc0078265442dd46d41e72a87eee5bdcaa12ba9fe0cd.\nThe source audit confirms the driver's module-level imports are all standard\nlibrary imports. NumPy, cold and verify imports inside its other functions\nare not executed by this loader; none of its training, scoring or run\nfunctions is called.\n\nThe unchanged publishing helper is pinned to\n0f182311ca3e2904e469580ecab2b58240991fbac2d3254e3286f3e5570ac60d.\nIts only local dependency, archive.py, is separately pinned to\nbe141f99e01d06eaee8febbf215cc13646f0de893f474816bf55cc4abe5c54a2\nand bound within the helper's own import namespace. Global module cache\nentries for archive, verify and fresh_study cannot replace those modules.\nThe original verifier's NumPy runtime is an explicit runtime dependency;\nthis is not an attestation of the entire interpreter environment.\n\n## Actual controls\n\nAll 37 methods passed, with zero failures, errors or skips, in 54.433833\nseconds. The original 21 control names are retained and adapted to the actual\ncapture/private-validation/immutable-byte flow. Freeze is not mocked.\nThe original mathematical verifier executes on clearly labeled synthetic\nsaved predictions. Module loading and temporary paths are observed; the\noriginal main function is not replaced.\n\nThe additional controls cover mutation after capture and after validation,\nreplacement of private files before and after validation, replacement with the\nsame bytes but a different inode, private symlink/hardlink substitution,\nlegitimate source hardlinks, source directory escapes, a real FIFO with a\nbounded subprocess, actual growth during a descriptor read, byte and\nfile-count bounds, duplicate or unsafe metadata, closure escapes, task module\ncache poisoning, changed algorithm source, and immutable destination binding.\nThe original API helper and the changed native stdin path both operate on\nreal isolated Git repositories. No real remote publication occurs in these\ncontrols.\n\nThe first terminal write had an UNKNOWN outcome. A separate scoped read\nobserved only the known shell and no attempt directory at that time. The\nparent authorized one retry with the identical session, request ID and input.\nThe runner additionally creates its attempt directory exclusively before any\ntests. The acknowledgement and the complete actual 37-control result are\nretained. The first write remains UNKNOWN; no assertion is made that it never\nexecuted, and no unknown external task was restarted.\n\n## Actual original-input compatibility\n\nA separate necessary compatibility run used the already retrieved originals\nfrom fixed raw commit\n[4b84b0431b089ccac84c75ac3ac19f96ad804fe4](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/4b84b0431b089ccac84c75ac3ac19f96ad804fe4/qualification/hcsn_sustained_20261128)\nand the genuinely recovered data manifest\n968dfb23d19f7ba50c9907b2146810e09922283b4b4342618e8d2eac151c4f70.\nIt used 190 copied original input files totaling 15,881,944 bytes. Every copied\ninput retained its hash. The producer's original scientific directories and\nhardlinks were not read.\n\n| Scope | Actual validation | Payload objects | Including canonical index | Payload bytes |\n| --- | --- | ---: | ---: | ---: |\n| Recovery | Original recovery math once | 24 | 25 | 568,777 |\n| Fresh | Original saved-prediction verifier once | 166 | 167 | 15,306,173 |\n\nBoth passed. The recovery manifest is byte-identical to the original fixed\nGit blob 562d179a273d674979b75c7e382009b187930d4d. The fresh manifest is exactly\nthe original 165-object manifest plus the original recovered data file; its\nSHA256 is\n10b2bb6d64bb2bb4ffe3410aa30a5efc9ee0694a1dcb67300a353077a0f25da1\nand Git blob is 1fb5117e94105c84e18f1783b53eaccdb228f93c.\n\nThe two-scope compatibility operation took 2.280853 seconds. This is validation\nruntime, not model training time. It performed no model forward inference,\ntraining, new experiment, physical retiming or remote publication. These\nresults do not alter any scientific quality or matched-quality speed gate.\n\n## Bounds, format and limits\n\nThis is a fixed MOSI publishing profile: at most 64 MiB of captured source\nbytes, 16 MiB per ordinary input, 1 MiB per metadata object, 64 KiB per local\nalgorithm/helper source and 1,024 captured inputs. A repeated input still has\nto satisfy a later stricter limit. These bounds do not claim to support\narbitrary model archives.\n\nThe real fresh set has a largest object of 391,018 bytes; the real recovery\nset has a largest object of 51,750 bytes. Both are well within the profile.\nAll input discovery and publication scope checks remain fail-closed.\n\nThe parent ran the exact original just fmt driver in a separate thin Git\ninventory with these two candidate files and the seven required fixed-byte\nfixtures. It exited zero in 0.106332177 seconds, reported no changed files\nneeded formatting, and left both tested SHA256 values unchanged. The driver's\nlanguage scope excludes qualification Python; this is neither a Python-format\nqualification nor a full-repository formatting claim. No tests were rerun\nafter that formatting invocation.\n\nThe guarantee covers this local process's publication flow and filesystem\nmutation boundary. It does not claim resistance to an attacker who can\narbitrarily rewrite the same process's memory, change its trusted runtime,\nor control the host kernel. It is also separate from scientific usefulness\nand distributed consensus. The earlier missing-data patch, its successful\noriginal replay, and all historical missing/wrong-manifest observations remain\nunchanged.\n"
    write_new(PACKAGE/'README.md',readme)
    paths=[PRODUCTION,TEST]+[PACKAGE_REL+'/'+name for name in ('README.md','RESULT.json','evidence.tar.gz')]
    manifest={'parent_commit':PARENT,'parent_tree':PARENT_TREE,
              'publication_status':'prepared; root agent performs GitHub CAS',
              'host':'desktop','full_local_git_commit_claimed':False,
              'files':[{'path':path,'native_path':str(CANDIDATE/path),'mode':'100644',
                        **identity((CANDIDATE/path).read_bytes())} for path in paths],
              'all_new_blobs_under_500_KiB':True,
              'archive_inventory':inventory,
              'source_and_tests_frozen_after_actual_execution_and_format':True,
              'packaging_runs_no_tests_or_models':True}
    write_new(ROOT/'PUBLICATION_MANIFEST.json',encoded(manifest))
    print(json.dumps({'manifest':str(ROOT/'PUBLICATION_MANIFEST.json'),
                      'manifest_identity':identity((ROOT/'PUBLICATION_MANIFEST.json').read_bytes()),
                      'files':manifest['files'],'archive_members':len(inventory)},sort_keys=True))

if __name__=='__main__':
    main()
