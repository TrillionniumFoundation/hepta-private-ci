"""Read-only AST audit of the pinned local algorithm/helper import closure."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import tarfile

root=Path('/home/qq/hepta-audit-20261128-5bdf/mosi-data')
archive_path=root/'candidate/qualification/mosi-replay-data-closure-20261128/original-replay.tar.gz'
sources={}
with tarfile.open(archive_path,'r:gz') as archive:
    for label,path in [('fresh_study.py','raw/fresh_study.py'),('verify.py','source/verify.py')]:
        with archive.extractfile(path) as handle:sources[label]=handle.read()
for name in ('publish_results.py','archive.py'):
    sources[name]=(root/'candidate/qualification/hcsn_sustained_20261128/crema'/name).read_bytes()
expected={'fresh_study.py':'e7537324fb45f9bfbde4dc0078265442dd46d41e72a87eee5bdcaa12ba9fe0cd',
          'verify.py':'bdbb45e0ad4227ef2750bb7d35ca4d2035b1c9fd8257d2c4e2c7ed7fa76b17af',
          'publish_results.py':'0f182311ca3e2904e469580ecab2b58240991fbac2d3254e3286f3e5570ac60d',
          'archive.py':'be141f99e01d06eaee8febbf215cc13646f0de893f474816bf55cc4abe5c54a2'}
report={'schema':'hepta.mosi.snapshot-local-source-import-audit.v1','scope':'Pinned local algorithm/helper source closure; not an interpreter/package attestation.',
        'execute_any_source_module':False,'new_forward_or_training':False,'sources':{}}
class Imports(ast.NodeVisitor):
    def __init__(self):self.scope=['module'];self.rows=[]
    def visit_FunctionDef(self,node):
        self.scope.append('function '+node.name);self.generic_visit(node);self.scope.pop()
    def visit_AsyncFunctionDef(self,node):self.visit_FunctionDef(node)
    def visit_If(self,node):
        self.scope.append('if '+ast.unparse(node.test));self.generic_visit(node);self.scope.pop()
    def visit_Import(self,node):
        for name in node.names:self.rows.append({'line':node.lineno,'module':name.name,
            'scope':list(self.scope),'stdlib':name.name.split('.')[0] in sys.stdlib_module_names})
    def visit_ImportFrom(self,node):
        self.rows.append({'line':node.lineno,'module':node.module,'level':node.level,
                          'names':[x.name for x in node.names],'scope':list(self.scope),
                          'stdlib':node.module.split('.')[0] in sys.stdlib_module_names})
for name,payload in sources.items():
    actual=hashlib.sha256(payload).hexdigest()
    if actual!=expected[name]:raise ValueError('source identity differs '+name)
    tree=ast.parse(payload);visitor=Imports();visitor.visit(tree)
    report['sources'][name]={'bytes':len(payload),'sha256':actual,'imports':visitor.rows,
                            'module_body':[{'line':node.lineno,'type':type(node).__name__,
                                            'summary':ast.unparse(node).splitlines()[0][:200]}
                                           for node in tree.body]}
fresh=report['sources']['fresh_study.py']['imports']
if any(not row['stdlib'] for row in fresh if row['scope']==['module']):
    raise ValueError('unexpected nonstdlib top-level driver import')
report['conclusion']={
 'fresh_driver_top_level_local_imports':False,
 'fresh_driver_functions_invoked_by_new_loader':False,
 'fresh_driver_main_guard_triggered':False,
 'original_verify_nonstdlib_runtime_import':'numpy',
 'helper_nonstdlib_local_dependency':'archive.py, separately pinned and injected only into helper module imports',
 'global_sys_path_or_task_module_cache_required':False}
out=root/'SNAPSHOT_IMPORT_CLOSURE_AST.json'
with out.open('x',encoding='utf-8') as handle:handle.write(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
                  'fresh_imports':fresh,'conclusion':report['conclusion']},sort_keys=True))
