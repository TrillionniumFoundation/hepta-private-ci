synthetic publisher fixture only: fresh_study.py
