synthetic publisher fixture only: PROSPECTIVE_REPLICATION.md
