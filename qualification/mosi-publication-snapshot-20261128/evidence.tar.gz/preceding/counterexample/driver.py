"""Synthetic publisher race counterexample; no network publication or model execution."""
import datetime
import hashlib
import importlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
import time
import traceback
from unittest import mock

SOURCE = Path("/home/qq/hepta-audit-20261128-5bdf/mosi-data/candidate/qualification/hcsn_sustained_20261128/mosi_recovery")
OUT = Path("/home/qq/hepta-audit-20261128-5bdf/mosi-publication-snapshot-review")
EXPECTED = {
    "publish_mosi.py": "ba76f99405fab27c1c21ee579602202c096cac9fea2abcaf0c7e0bf025e17f8e",
    "test_publish_mosi.py": "041a353c9bb78438f7430e4bff54240d6ebef346004db147e631272a96b57ac4",
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, value):
    with path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")

def main():
    OUT.mkdir(exist_ok=False)
    (OUT / "fixtures").mkdir()
    for name, expected in EXPECTED.items():
        data = (SOURCE / name).read_bytes()
        if sha(data) != expected:
            raise ValueError("candidate source changed")
        (OUT / name).write_bytes(data)
    result = {
        "schema": "hepta.mosi.publisher-input-race-probe.v1",
        "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "source_sha256": EXPECTED,
        "scope": "Synthetic recognizable publisher fixture; actual fresh_map, snapshot, staging, receipt and immutable local Git-tree readback. Original model arithmetic explicitly stubbed. No network.",
        "new_forward": False, "new_training": False, "remote_publication": False,
        "changed_frozen_candidate": False, "events": []
    }
    started = time.monotonic()
    case = None
    try:
        sys.path.insert(0, str(SOURCE))
        suite = importlib.import_module("test_publish_mosi")
        relay = suite.relay
        case = suite.PublicationResumeTests("test_fresh_new_publication_covers_data_in_manifest_and_fixed_tree")
        with mock.patch.object(tempfile, "tempdir", str(OUT / "fixtures")):
            case.setUp()
            actual_mapper = case.fresh_map_fixture()
            kind = case.kinds[1]
            case.marker(case.kinds[0]).write_text(json.dumps(case.receipt(case.kinds[0])) + "\n")
            initial_data = case.fresh_data.read_bytes()
            initial_seal = json.loads((case.task / "fresh/FRESH_SEAL.json").read_bytes())
            changed_data = initial_data.replace(b"1.25", b"9.25")
            if initial_data == changed_data or len(initial_data) != len(changed_data):
                raise ValueError("probe must be an actual same-size content change")
            original_snapshot = relay.publication_snapshot
            injected = False
            def scheduled_snapshot(files):
                nonlocal injected
                if "data.json" in files and not injected:
                    if case.arithmetic_stub.call_count != 1:
                        raise ValueError("expected actual mapper arithmetic gate before mutation")
                    if relay.digest(case.fresh_data) != initial_seal["data_manifest_sha256"]:
                        raise ValueError("initial fixture failed its seal")
                    files["data.json"].write_bytes(changed_data)
                    injected = True
                    result["events"].append({
                        "point": "after actual fresh_map returned; before publication_snapshot reads paths",
                        "before_sha256": sha(initial_data), "after_sha256": sha(changed_data),
                        "same_length": True, "source_bytes": len(initial_data)
                    })
                data, objects = original_snapshot(files)
                if "data.json" in files:
                    result["snapshot"] = {
                        "data": json.loads(data)["data.json"],
                        "data_git_blob": objects["data.json"],
                        "manifest_sha256": sha(data)
                    }
                return data, objects
            published = []
            def local_publish(selected_kind, paths, root):
                if selected_kind != kind:
                    raise ValueError("unexpected publication scope")
                case.command(["read-tree", case.commit])
                entries = []
                copied = {}
                for path in paths:
                    name = str(path.relative_to(root / kind))
                    payload = path.read_bytes()
                    oid = case.command(["hash-object", "-w", "--stdin"], payload)
                    entries.append(("100644 blob " + oid + "\t" + relay.PREFIX + kind + "/" + name + "\0").encode())
                    copied[name] = {"size": len(payload), "sha256": sha(payload), "git_blob": oid}
                case.command(["update-index", "-z", "--index-info"], b"".join(entries))
                tree = case.command(["write-tree"])
                commit = case.command(["-c", "user.name=Synthetic Race Audit",
                                       "-c", "user.email=fixture@example.invalid",
                                       "commit-tree", tree, "-p", case.commit],
                                      b"Synthetic after-verification mutation only\n")
                case.command(["update-ref", "refs/heads/" + relay.BRANCH, commit])
                published.append({"commit": commit, "tree": tree, "objects": copied})
                return commit
            case.push.side_effect = local_publish
            with mock.patch.object(relay, "publication_snapshot", side_effect=scheduled_snapshot):
                case.run_relay()
            receipt_bytes = case.marker(kind).read_bytes()
            receipt = relay.receipt_from(case.marker(kind), kind)
            data_blob = case.command(["show", receipt["commit"] + ":" + relay.PREFIX + kind + "/data.json"]).encode()
            # command() strips the original trailing newline; read the exact blob through cat-file.
            object_oid = published[0]["objects"]["data.json"]["git_blob"]
            completed = suite.subprocess.run(["git", "cat-file", "blob", object_oid],
                                             cwd=case.repo, capture_output=True, check=True, timeout=10)
            remote_data = completed.stdout
            remote_seal_oid = published[0]["objects"]["FRESH_SEAL.json"]["git_blob"]
            completed = suite.subprocess.run(["git", "cat-file", "blob", remote_seal_oid],
                                             cwd=case.repo, capture_output=True, check=True, timeout=10)
            remote_seal = json.loads(completed.stdout)
            result["completed_receipt"] = receipt
            result["receipt_sha256"] = sha(receipt_bytes)
            result["actual_local_publications"] = published
            result["arithmetic_stub_calls"] = case.arithmetic_stub.call_count
            result["published_data_sha256"] = sha(remote_data)
            result["published_seal_data_sha256"] = remote_seal["data_manifest_sha256"]
            result["completed_with_unsealed_data"] = sha(remote_data) != remote_seal["data_manifest_sha256"]
            result["staging_shares_source_inode"] = (
                (case.root / kind / "data.json").stat().st_ino == case.fresh_data.stat().st_ino)
            try:
                actual_mapper(case.task)
            except ValueError as error:
                result["fresh_mapper_recheck_of_published_inputs"] = str(error)
            else:
                raise ValueError("counterexample failed to violate original mapper")
            try:
                case.run_relay()
            except relay.PublicationIncomplete as error:
                result["next_resume_rejects"] = str(error)
            else:
                raise ValueError("expected existing resume gate to detect bad current inputs")
            result["receipt_preserved_on_next_resume"] = case.marker(kind).read_bytes() == receipt_bytes
            result["publication_calls_total"] = case.push.call_count
            if not (result["completed_with_unsealed_data"] and result["staging_shares_source_inode"]
                    and result["receipt_preserved_on_next_resume"] and case.push.call_count == 1):
                raise ValueError("expected counterexample conditions not observed")
            (OUT / "relay.stdout.log").write_text(case.output.getvalue(), encoding="utf-8")
            shutil.copytree(case.task, OUT / "preserved-synthetic-fixture")
            result["status"] = "COUNTEREXAMPLE_REPRODUCED"
            result["interpretation"] = (
                "A new publication completed with data bytes that no longer match its published seal. "
                "Actual immutable Git readback verified the newer snapshot, not the bytes validated by the mapper. "
                "A later resume rejects the changed source but does not retroactively prevent the first complete receipt. "
                "This is a deterministic schedule probe; no claim of historical producer corruption.")
    except BaseException:
        result["status"] = "ERROR"
        result["exception"] = traceback.format_exc()
    finally:
        if case is not None:
            case.doCleanups()
        result["wall_s"] = time.monotonic() - started
        result["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write_json(OUT / "RESULT.json", result)
        print(json.dumps(result, sort_keys=True))
    return 0 if result["status"] == "COUNTEREXAMPLE_REPRODUCED" else 1

if __name__ == "__main__":
    raise SystemExit(main())
