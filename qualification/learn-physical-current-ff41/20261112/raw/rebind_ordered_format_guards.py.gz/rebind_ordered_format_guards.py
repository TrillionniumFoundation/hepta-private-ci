"""Bind unchanged ordered rules to each actual rustfmt occurrence, never weaken matching."""

import copy
import json
from pathlib import Path
import re
import subprocess
import sys
import tomllib

ROOT = Path('/workspace/scratch/ff41dfc0f7bf/hepta-crypto-profile')
OUT = Path('/workspace/scratch/ff41dfc0f7bf/evidence-audit')
sys.path.insert(0, str(ROOT / 'scripts'))
import verify_hepta_callers as proof

manifest = ROOT / 'CALLERS.toml'
original = subprocess.check_output(['git', 'show', 'HEAD:CALLERS.toml'], cwd=ROOT, text=True)
assert manifest.read_text() == original
data = tomllib.loads(original)
expected = copy.deepcopy(data)
changed = set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines())
mappings = []
errors = []
overrides = {
    'MaterialResult::Page { offset, total, heads }': 'MaterialResult::Page{offset,total,heads,}',
    'channel: Mutex::new(Some(Channel { peer, next_request_id: 1, execution_requested }))': 'channel:Mutex::new(Some(Channel{peer,next_request_id:1,execution_requested,}))',
    'channel: Mutex::new(Some(Channel { peer, next_request_id: 1 }))': 'channel:Mutex::new(Some(Channel{peer,next_request_id:1,}))',
    'expected_binding(initial, scope, identity.operation, ResidentPurposeV3::Execute)': 'expected_binding(initial,scope,identity.operation,ResidentPurposeV3::Execute,)',
    'root, issuer, registry, profile, ResidentAuthorizationV3::Fresh)': 'root,issuer,registry,profile,ResidentAuthorizationV3::Fresh,)',
    'GateActionV3::Current => ResidentStoreActionV3::RequireDispatch': 'GateActionV3::Current=>{ResidentStoreActionV3::RequireDispatch',
    'GateActionV3::Begin(stage) => ResidentStoreActionV3::Begin': 'GateActionV3::Begin(stage)=>{ResidentStoreActionV3::Begin',
    'GateActionV3::Checkpoint(next) => ResidentStoreActionV3::Checkpoint': 'GateActionV3::Checkpoint(next)=>{ResidentStoreActionV3::Checkpoint',
}

def compact(text):
    positions = [i for i, c in enumerate(text) if not c.isspace()]
    return ''.join(text[i] for i in positions), positions

def bind(markers, before, after, raw_after, *, path, field, function=None, top_level=False, literals=()):
    # Cursor order exactly mirrors the unmodified verifier. The exact span
    # is recovered from raw source using positions in its code-only mask.
    flat, positions = compact(after)
    old_cursor = 0
    cursor = 0
    result = []
    for index, marker in enumerate(markers):
        old_at = before.find(marker, old_cursor if not top_level else 0)
        if old_at < 0 and marker not in literals:
            raise ValueError(f'original valid marker absent: {path}:{function}:{marker!r}')
        old_cursor = old_at + len(marker)
        target = ''.join(c for c in marker if not c.isspace())
        rewritten_punctuation = False
        starts = [m.start() for m in re.finditer(re.escape(target), flat) if m.start() >= (0 if top_level else cursor)]
        if not starts and marker in overrides:
            target = overrides[marker]
            rewritten_punctuation = True
            starts = [m.start() for m in re.finditer(re.escape(target), flat) if m.start() >= (0 if top_level else cursor)]
        if marker in literals:
            # Formatting does not alter these exact literal calls.
            assert marker in raw_after
            result.append(marker)
            continue
        if top_level:
            starts = [at for at in starts if after[:positions[at]].count('{') - after[:positions[at]].count('}') == 1]
            if len(starts) != 1:
                raise ValueError(f'top-level formatted span is not unique: {path}:{function}:{marker!r}')
        if not starts:
            raise ValueError(f'formatted marker absent: {path}:{function}:{marker!r}')
        at = starts[0]
        start, end = positions[at], positions[at + len(target) - 1] + 1
        replacement = raw_after[start:end]
        cursor = at + len(target)
        result.append(replacement)
        if replacement != marker:
            mappings.append({'path': path, 'function': function, 'field': field, 'index': index, 'old': marker, 'new': replacement, 'before_offset': old_at, 'after_offset': start, 'rustfmt_punctuation_only': rewritten_punctuation})
    return result

def function_span(raw, code, function):
    assert code.count(function) == 1, function
    start = code.index(function)
    end = proof._rust_item_end(code, start)
    assert end is not None
    return raw[start:end + 1], code[start:end + 1]

for row, new_row in zip(data['protected_file'], expected['protected_file']):
    path = row['path']
    if path not in changed:
        continue
    before_raw = subprocess.check_output(['git', 'show', f'HEAD:{path}'], cwd=ROOT, text=True)
    after_raw = (ROOT / path).read_text()
    before = proof._strip_cfg_test_items(proof._strip_rust_non_code(before_raw))
    after = proof._strip_cfg_test_items(proof._strip_rust_non_code(after_raw))
    try:
        # Required markers only assert existence, not order; bind independently.
        new_row['required'] = [bind([marker], before_raw, after_raw, after_raw, path=path, field='required')[0] for marker in row['required']]
        if 'required_order' in row:
            new_row['required_order'] = [bind(sequence, before, after, after_raw, path=path, field=f'required_order[{i}]') for i, sequence in enumerate(row['required_order'])]
        for rule, new_rule in zip(row.get('required_function_order', []), new_row.get('required_function_order', [])):
            function = rule['function']
            old_raw_body, old_body = function_span(before_raw, before, function)
            new_raw_body, new_body = function_span(after_raw, after, function)
            new_rule['sequence'] = bind(rule['sequence'], old_body, new_body, new_raw_body, path=path, function=function, field='sequence', literals=rule.get('literal_calls', ()))
            if rule.get('top_level'):
                new_rule['top_level'] = bind(rule['top_level'], old_body, new_body, new_raw_body, path=path, function=function, field='top_level', top_level=True)
    except (AssertionError, ValueError) as error:
        errors.append(str(error))

report = {'source_parent': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'mappings': mappings, 'errors': errors, 'boundaries': len(data['boundary']), 'protected_files': len(data['protected_file'])}
(OUT / 'upstream-ordered-format-marker-plan.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'mapped': len(mappings), 'errors': errors}, indent=2))
if errors:
    raise SystemExit(1)

def value(item):
    if isinstance(item, str):
        return json.dumps(item, ensure_ascii=False)
    if isinstance(item, list):
        return '[' + ', '.join(value(v) for v in item) + ']'
    if isinstance(item, dict):
        return '{ ' + ', '.join(k + ' = ' + value(v) for k, v in item.items()) + ' }'
    if isinstance(item, bool):
        return str(item).lower()
    if isinstance(item, int):
        return str(item)
    raise TypeError(type(item))

headers = list(re.finditer(r'^\[\[(?:protected_file|boundary)\]\]$', original, re.M))
row_index = 0
edits = []
for index, header in enumerate(headers):
    if header.group() != '[[protected_file]]':
        continue
    row, new_row = data['protected_file'][row_index], expected['protected_file'][row_index]
    row_index += 1
    if row == new_row:
        continue
    end = headers[index + 1].start() if index + 1 < len(headers) else len(original)
    comments = [line for line in original[header.start():end].splitlines() if line.lstrip().startswith('#')]
    body = '\n'.join(comments) + ('\n' if comments else '') + '[[protected_file]]\n'
    for key, item in new_row.items():
        if key == 'required_function_order':
            body += key + ' = [\n' + ''.join('  ' + value(rule) + ',\n' for rule in item) + ']\n'
        else:
            body += key + ' = ' + value(item) + '\n'
    edits.append((header.start(), end, body + '\n\n'))
updated = original
for start, end, body in reversed(edits):
    updated = updated[:start] + body + updated[end:]
assert tomllib.loads(updated) == expected
manifest.write_text(updated)
print(f'Wrote {len(edits)} protected-row bindings; all other manifest data identical')
