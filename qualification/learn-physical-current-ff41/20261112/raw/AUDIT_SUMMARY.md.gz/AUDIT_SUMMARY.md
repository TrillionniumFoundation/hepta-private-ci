# LEARN/EVAL read-only evidence audit

Observation window: 2026-11-12 00:12–00:22 UTC (2026-11-11 19:12–19:22 America/New_York). No source mutation, CI rerun, PR, branch or remote process was created.

## Critical assertion correction

- Frozen source: 7a6c00b8201f685db97ff52bc0b41094b9af1ed2, tree 2aa9a592262d5197cdd96e79128dc18a30332ebd.
- Test: neuron_cell_evaluation_execution_store::tests::original_execution_owner_physical_corruption_fences_even_after_restore.
- Exact source: codex-rs/hepta-agentd/src/neuron_cell_evaluation_execution_store_tests.rs, Git blob edbe3f1a81a375e13963fe5dd3efd9c709bf2565.
- Original panic is at line 376, the first read after corrupt bytes are written at line 375.
- Original bytes are restored at line 377; the post-restoration assertion is line 379.
- Observed actual is Ok(Completed(b"actual-retained-execution")); expected Err(StoreError::Indeterminate).
- Therefore this invocation proves that a physically corrupted store can still return Completed BEFORE restoration. It did not reach line 379 for the failing loop iteration. The test loops over raw and witness; JUnit does not identify the failing iteration.
- Source URL: https://github.com/TrillionniumFoundation/hepta-private-ci/blob/7a6c00b8201f685db97ff52bc0b41094b9af1ed2/codex-rs/hepta-agentd/src/neuron_cell_evaluation_execution_store_tests.rs

## Retained v8 original

Evidence commit 6d1f60b75f00fcd07949842cd58c04984af6bc6c. Directory qualification/learn-ordinary-ce434/integrated-failures/7a6c00b8201f-native-failure/native/.
Host job 1a1cccec57a-2564-1088. 109 selected = 89 pass + 20 fail, errors 0, selected skipped 0, filtered 1132, retries 0, native exit 100, timed_out false. Source before/after clean and exact.

Local originals:
- v8-focused-native.junit.xml: 57,899 bytes; SHA256 75d563cd4e8bf55eed20cf400f090368452c13022a49939edafe1729556dfbc4; Git blob 15bc6f757af0d08f4fd23faa1b6b8ed92df2f1b9.
- v8-raw.log: 129,513 bytes; SHA256 971795ce0588c93d53a3346bd699269214c132c3a1f9ac34bfd0c7c8855a6910.
- v8-result.json: 12,945 bytes; SHA256 989e8a8524396643b07f5f4173527c4214e17acc14ac1e7bbca73073cc6ddb2a.
- v8-execution.json: 22,857 bytes; SHA256 5a09a4d98814bf65b376f57bf618fb462204c6014db6663a61862d12e6dfdf18.

Failure groups: Training OwnerUnavailable 1; physical-corruption Completed 1; NextUse/Selector uncertainty 6; Selector command 6; Published read 5; Holdout Indeterminate mapping 1. Full positive, NoUpdate and daemon+Root cold restart accepted counts all 0.

## Independent hosted reproduction

https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43115842564/job/130843487277

Exact same 7a6c source, clean before/after, source-head lane, attempt 1. 1419 executed = 1399 pass + 20 fail; 73 filtered, retries 0, no timeout. Independently parsed JUnit confirms the failed testcase-name set equals the v8 20-case set exactly, including line 376 corruption failure. This is not just a single original-host observation.

Downloaded original artifact 13898784036:
- learn-7a6c-native-43115842564.zip: 3,628,298 bytes; SHA256 e508b94d13e35a65959f52801f399592a9c3055a077577c25b09b280612c9101; all 22 ZIP-member CRCs pass.
- hosted-native/ordinary.xml: 368,176 bytes; SHA256 54f422bb2320f94edb31f8d00be07252b2e769e0715504f6130898c649085a05.
- hosted-native/ordinary.json.f8d2adccade34374969a329aa3d09180.log: 1,005,003 bytes; SHA256 857d93cbed2ec58cb033150aed6951b8f825212c7a3160a988421cddc1683fa5.
- Full source identity / execution / collector records also extracted under hosted-native/.
- Root/maintenance stages were not reached after ordinary failure.

Shared-framework run 43115842817/job130843488055: 1311 run = 1292 pass + 19 fail, 71 excluded, TRY 2 retries present. These overlapping counts must not be added to the daemon native counts.

## #6006 and #6018

#6006 head remains 3c8dabe46598599e91b2b8b80081e09069ff9426. Original native log run43086818461/job130753255237 confirms source-head clean identity, 1231 ordinary passed / 78 filtered and 12 Root passed / 1030 filtered, retries0. These are component results; blocking run43086818548 remains failure.

#6018 head remains 95894b8c958a1fab691f7779942f5fb25b778f9f.
Attempt1 of run43098715965 is FAILURE. Actual original build-test job130784638065:
- checkout prospective merge bb876e4c9f61af8fe881f9664036ec6e810360f8, not the source head.
- PASS_HEPTA_CALLER_CLOSED_SET: 6369 Rust files, 330 boundaries/inventory, 264 protected entries.
- 207 subsequent QA cases OK.
- Then cancelled at README character check; full job is CANCELLED.
- Local 6018-attempt1-build-test.log: 341,572 bytes; SHA256 f87304c7ce51e896335ba117d5801ef3c58c10b7b1b676bbe4517c937470c9bf.
- URL: https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43098715965/job/130784638065

Attempt2 was already started by another actor at 2026-11-12T00:13:05Z and was in_progress at this audit. Do not erase attempt1 or claim overall PASS. This audit did not rerun it.

#6019 narrow C mask successor current head b60d7b886a38986c0d42df4228d3007559ef8bc4, branch audit/learning-c-mask-preflight-20261111. Stacked on #6018, separate from broker staging.

## Existing successor objects and refs

Verified using GitHub plugin github_fetch on REST commits/{sha}/branches-where-head, commits/{sha}/pulls and actions/runs?head_sha=...&per_page=100, plus search_branches and compare_commits.

1. fb32469525103d523d3240283b27467a8012c40e: tree987f647792b7036c7f5c932ddf32fb440bd91682. No direct head branch or associated PR returned, no Actions runs. It is parent of b514c3.
2. b514c3cacb73de1bb0adb46b202225e16d3b11c9: tree3e45a3eaac3c6a7f64a6e44467e5d04b3f7d5c0c; current branch codex/learn-original-current-repairs-ce434-20261111-v1. Five commits ahead of7a6c. No associated PR returned; all-event Actions runs total_count0. Existing physical witness CURRENT and permanent-fence repair, Holdout mapping, Training cancellation recheck, peer-before-clock correction already exist. PR5981 describes pending host format/source-only request blob f5793719e7320570516af8947fb08fde19fb7b08; no successful original qualification retrieved.
3. 715a5726f5031e50ad963812d2a1270e8d0cf769: tree1122b8a0f3342b0944313a895b6f8838918fcddd; branch codex/ordinary-owner-broker-staging-20261111-af52. Fifteen commits ahead of3c8dabe. Relative to6018 it is DIVERGED,15 ahead/1 behind, common ancestor3c8dabe. No associated PR; all-event Actions runs total_count0.
4. 715 source docs explicitly preserve a production reachability failure: true A process exit is required for fresh Starting/Root successor, while retained A authority is a private in-process Arc with no durable cross-incarnation reconstruction. Same-Running phase enrollment is also absent. Both capabilities cannot yet be supplied to the conditional successor constructor.
5. 715 saved NATIVE_V11_ORIGINAL_FAILED_PROGRESS.json belongs to parent19894714403a97fcd58ca8c592e75761de95687c: scoped fix failed E0599 Sha256Digest Display,26-file maintenance delta, no native tests.715 includes syntax/format correction; no new original qualification retrieved. Eight new test methods remain unexecuted; full chain counts remain0.
6. Key source documents: qualification/original-q24-successor-20261111/README.md and SOURCE_GAP.json at715a572.

No absence of Actions records is interpreted as proof that a separate host request never executed.

