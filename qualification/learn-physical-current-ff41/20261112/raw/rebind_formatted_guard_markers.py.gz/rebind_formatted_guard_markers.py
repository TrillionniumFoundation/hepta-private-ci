"""Rebind exact guard text to this worktree's rustfmt output, without changing rules."""

import json
from pathlib import Path
import re
import subprocess
import tomllib

ROOT = Path('/workspace/scratch/ff41dfc0f7bf/hepta-repair-integration')
OUT = Path('/workspace/scratch/ff41dfc0f7bf/evidence-audit')
manifest = ROOT / 'CALLERS.toml'
text = manifest.read_text()
headers = list(re.finditer(r'^\[\[(?:protected_file|boundary)\]\]$', text, re.M))
edits = []
unresolved = []
mappings = []

def strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, list):
        for item in value:
            yield from strings(item)
    elif isinstance(value, dict):
        for item in value.values():
            yield from strings(item)

for index, header in enumerate(headers):
    if header.group() != '[[protected_file]]':
        continue
    end = headers[index + 1].start() if index + 1 < len(headers) else len(text)
    block = text[header.start():end]
    row = tomllib.loads(block)['protected_file'][0]
    path = row['path']
    before = subprocess.check_output(['git', 'show', f'HEAD:{path}'], cwd=ROOT, text=True)
    after = (ROOT / path).read_text()
    if before == after:
        continue
    positions = [i for i, ch in enumerate(after) if not ch.isspace()]
    flat = ''.join(after[i] for i in positions)
    markers = set(strings({key: row[key] for key in ('required', 'required_order', 'required_function_order') if key in row}))
    new_block = block
    for marker in sorted(markers):
        if marker in after:
            continue
        if marker not in before:
            unresolved.append({'path': path, 'marker': marker, 'reason': 'absent before formatter'})
            continue
        target = ''.join(ch for ch in marker if not ch.isspace())
        starts = [match.start() for match in re.finditer(re.escape(target), flat)]
        matches = {after[positions[start]:positions[start + len(target) - 1] + 1] for start in starts}
        if len(matches) != 1:
            unresolved.append({'path': path, 'marker': marker, 'reason': f'{len(matches)} distinct whitespace-equivalent spans'})
            continue
        replacement = matches.pop()
        old_literal = json.dumps(marker, ensure_ascii=False)
        new_literal = json.dumps(replacement, ensure_ascii=False)
        if old_literal not in new_block:
            unresolved.append({'path': path, 'marker': marker, 'reason': 'non-JSON-compatible TOML spelling'})
            continue
        new_block = new_block.replace(old_literal, new_literal)
        mappings.append({'path': path, 'old': marker, 'new': replacement, 'match_count': len(starts)})
    if new_block != block:
        edits.append((header.start(), end, new_block))

(OUT / 'integration-format-marker-plan.json').write_text(json.dumps({'mappings': mappings, 'unresolved': unresolved}, indent=2) + '\n')
print(json.dumps({'mapped': len(mappings), 'unresolved': unresolved}, indent=2))
if unresolved:
    raise SystemExit(1)
for start, end, block in reversed(edits):
    text = text[:start] + block + text[end:]
tomllib.loads(text)
manifest.write_text(text)
