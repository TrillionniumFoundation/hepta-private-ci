# PR 6031 qualification and static repair audit

Observed source and first runs as of 2026-11-12 00:43 UTC. This is an intermediate audit; no complete ordinary Adopt, correct NoUpdate, or daemon-plus-Root cold-restart acceptance is claimed.

## Source identity

- PR: https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6031
- Base: `7a6c00b8201f685db97ff52bc0b41094b9af1ed2`.
- Submitted head: `b514c3cacb73de1bb0adb46b202225e16d3b11c9`, tree `3e45a3eaac3c6a7f64a6e44467e5d04b3f7d5c0c`.
- Synthetic merge: `d6c9f64f46919c6ad08591404c2a372e881601f0`; its tree is the same `3e45a3eaac3c6a7f64a6e44467e5d04b3f7d5c0c`.
- Repair worktree: `/workspace/scratch/ff41dfc0f7bf/hepta-repair`, branch `codex/learn-physical-current-guards-20261112-ff41`, based on exact b514c3. Other worktrees are not modified by this repair.

## First native workflow: stopped at original source controls

https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43126736311/job/130880612363

The original `python3 -m unittest discover -s qa/b4-no-bypass -p '*source_closure.py' -v` reports 234 test methods and 148 errors. These are repeated errors from baseline source proof inside the mutation controls, not 148 native behavior regressions. Rust compilation and the native owner test command were not reached.

- 113 errors: `unique top-level code marker required: if self.poisoned.load(Ordering::Acquire)` in `hepta-neuron/src/witness.rs`. The repaired current function intentionally contains a check before the mutex and another under the mutex. Its outer result closure also repeats a short marker used by a nested closure.
- 24 Holdout and 11 Root source-control errors: `required must be a list of non-empty strings`. The new protected-file entry for `hepta-intelligence-eval/src/fenced_holdout.rs` omitted the required field.
- Original source-control execution: 00:25:39.742537Z to 00:26:32.867733Z, 53.037878 seconds, not a timeout.
- Source before and after was clean exact b514c3.

Retained decoded job log: `6031-native-source-closure-job.log`, 2,032,655 UTF-8 bytes, SHA256 `1b9bb48daedb9441105b537082014cef6f689c74351f5eed3b855d4a30ab5431`.

## First blocking workflow: independently identified failures

https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43126736813

- Blob policy job 130880614906: CALLERS.toml is 666,200 bytes, above the 512,000-byte threshold. The submitted b514c3 allowlist has no exact CALLERS digest entry. An existing exact-digest mechanism, already used by successor 715a572, is reused for this repair; there is no wildcard or threshold change.
- Linux clippy job 130880798462: four denied `expect_used` calls in `neuron_cell_evaluation_execution_store_tests.rs`, at 26:18, 77:13, 78:13, and 78:26. The same four findings occur in both unit-tests-bin and cognitive-write-qualification-bin. These fixture expressions already existed in the base; the original repair changed only an assertion diagnostic later in the file. A minimal explicit match/panic cleanup has been authorized, with all test assertions, expected bytes and recover error classifications retained.
- Windows shard 1 job 130880798426: `remote_windows_sandbox_process_accepts_process_write` fails because the exec-server rejects legacy Windows sandbox isolation, specifically ambient parent FILE_DELETE_CHILD deletion-boundary bypass. This is retained as a separate blocking failure; the physical-owner repair does not change those permissions or their enforcement.
- Original full caller job 130880797559 remains in progress at the last observation.

Logs retained:

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `6031-linux-clippy-job.log` | 1,025,576 | `6c01923a2b36468f394820eca5c75a8ae75cd797149a8a3d452783fd12d59418` |
| `6031-windows-shard1-job.log` | 403,413 | `6ccb29b696325764a8f0b6fe8245f07a8d8f02fb6c4c66cb9baf1bedb7470619` |

The Windows decoded log's original CRLF line endings were preserved, including its single LF-only line.

## Local static repair, first verification snapshot

Candidate tree `522e9d55321c8df596e73022f4b65d8fe802f462` is based on b514c3 with two files staged: CALLERS.toml and `.github/blob-size-allowlist.txt`. It has not been submitted to the PR.

- Holdout required markers now include the crate-private read-consumption method, original store load, and DENY_ALL authority.
- Witness current top-level anchors use unique complete code fragments for the outer poison check and outer locked-read closure. All original ordered sequences, forbidden markers, boundary inventory, and verifier code are unchanged.
- The entire 292-entry protected-file verification passes.
- The original `just fmt --base b514c3...` entry point reports no changed files needing formatting for the TOML/text-only snapshot.
- Exact digest at this snapshot: CALLERS.toml 666,438 bytes, SHA256 `a7a8bbf80cab7aab09c5e9db16d9662481e5016db9756f9be9a4cf4148db4188`. Original blob checker passes both changed files against the 512,000-byte limit, using only this exact digest exception.
- Direct original 234-method source-control command completes in 96.101 seconds: 233 methods pass, one negative control fails. All 148 baseline errors have been removed.
- Remaining failure: `test_file_witness_open_and_cas_preserve_bounds_lock_and_physical_effect_order`, marker `poisoned: AtomicBool`. Removing the field declaration still lets the initializer `poisoned: AtomicBool::new(false)` satisfy this short required string. The planned correction is the exact field marker `poisoned: AtomicBool,`; the negative test and verifier are retained.
- Full caller command started 00:36:08Z and completed by 01:15:33.789793Z on this unchanged snapshot: `PASS_HEPTA_CALLER_CLOSED_SET`, exit 0, 6,412 Rust files, 373 boundaries and privileged inventory entries, 292 protected rows, authorityGranted=false. Log SHA256 `e17e6a519fec3646e9095ff4ff72e27e15f63ea608fe1ffc5e29fc02b1371494`. This is tree 522e only. The later correction was developed in another isolated worktree while this original proof continued.

The local CI collector wrapper first rejected the run because there is no CI `SOURCE_SHA` binding; that rejection is retained in `repair-source-closure.json`. The actual local verification used the original unittest command directly and is recorded in `repair-source-closure-direct.log`. It is not presented as a clean hosted execution receipt.

## Shared-owner native workflow

https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43126736569/job/130880613890

At 00:43:16Z the original inference helper build had passed and the scoped owner-libraries step was in progress. This scope includes automation, neuron, and agentd libraries, and is distinct from the daemon workflow's four-library scope. In-progress job logs were unavailable. No test result is inferred from the active step.

At completion, this source-head run reports **1,314 executed cases: 1,296 passed, 18 failed**, with 71 filtered out. The original execution record shows b514c3/3e45 clean before and after, timed_out=false, exit=100, command elapsed 1,117.958861093 seconds. All 18 failed names equal the GNU Bazel failure set. The default profile permits one retry: JUnit contains 18 rerunFailure elements, and raw output ends those cases at TRY 2 FAIL; this run is not described as zero-retry.

The original corruption regression and the three new witness physical-current tests each pass on their first attempt and have no failure or rerun children in JUnit. These are actual source-head physical-fence observations, not an inference from the static proof.

Artifact 13904558341 is retained as `6031-shared-owner-native.zip`: 188,667 bytes, SHA256 `8127de31ac8a7ebc51683bfd82f715e0c8dc624ad7772d6f9638973f28f466fc`, matching GitHub's digest, with all 14 member CRCs passing. Independently parsed `6031-shared-original.junit.xml` is 362,008 bytes, SHA256 `15b26d74e9dc1140d5c915d2c59e3768b7bdd3acff239a2941c3abf313bd6205`, with 1,314 testcase elements, 18 failures, zero skipped XML cases. Original `6031-shared-tests-execution.json` SHA256 is `247ec314822832f3fbff17bcb44a3bfb93c215121fc0f9f51e80a541368de495`.

Complete decoded job log: `6031-shared-owner-job.log`, 441,618 bytes, SHA256 `a1fc1f5c6debf45799c7f0174f6f3c7c36f18ab56d051fc8af0058e40d32686a`.

The original blocking caller invocation completed at 00:47:58Z after approximately 24 minutes 43 seconds, with `FAIL_HEPTA_CALLER_PROOF: required must be a list of non-empty strings`. It did not pass. Raw job log `6031-original-blocking-caller-job.log` is 53,796 bytes, SHA256 `69536977d101026620e035fcc75df3743a3e7e89b1ec46594642da313ea98217`. The repaired local invocation remains separate and is not replaced by this old failure.

## First actual Linux Bazel runtime results

https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43126736813/job/130880798428

The original GNU Bazel job executed the agentd unit-tests target: **993 passed, 18 failed, 71 ignored**, 116.38 seconds. It printed `original_execution_owner_physical_corruption_fences_even_after_restore ... ok` at 00:39:40.9628779Z. The actual regression is now observed passing on merge d6c9f64, whose tree equals submitted b514c3. This is distinct from the stopped daemon workflow and its required source-head receipt.

The 18 failed leaf names are an exact subset of the original focused JUnit's 20 failed names, with no new failing name. The difference is the physical-corruption regression and `holdout_current_completed_execution_readback_requires_physical_original`. The eval unit-tests target as a whole reports PASS in 1.2 seconds, but this raw log does not enumerate its passing cases; the Holdout case has not yet been independently parsed from JUnit here.

Failure evidence does not support one uniform cause:

- Four have explicit DeadlineElapsed evidence: three Published read cases, plus deferred Training whose diagnostic shows server DeadlineElapsed while the client maps to OwnerUnavailable.
- Eight show only original Selector completion uncertain.
- Four fail a Missing-matching assertion without printing the actual returned value.
- Two fail fixture expectations: actual Selection before lost ACK, and the malformed response was actually sent.

Raw decoded log: `6031-linux-gnu-test-job.log`, 1,230,356 bytes, SHA256 `98c099e7d30581ef2b68b483a1037626e294504bf12de828756acc351ae0d665`.

## Windows private-state native workflow

https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43126736341/job/130880612759

The source-head job finishes with failure. Its executed native scopes pass (15, 2, 3, 2, 12 cases), and the separate exact LEARN selected roster passes **36/36 with zero retries**. The collected LEARN JUnit is 9,050 bytes with SHA256 `9cbc1c3b32e49c8294b57dc8b1c9ad5e9a444a5711004246c5a7900ca0fbf768`; execution SHA256 is `38979173f54945f90b4343a1a66d1491699e336b72602723a76d17d6488ed81d`; reported source/tree is b514c3/3e45 and tracked source remains clean. These scopes do not represent a complete ordinary chain.

The only failing step is rustfmt: two diffs in the newly added cancellation fixture `cell_q24_training_command_support_tests.rs`, around lines 234 and 254. Rustfmt folds the poll_fn closure into a direct match and wraps the execute_training await expression. The later directory-acquisition attack qualification step is skipped because of this failure; it is not counted as passed. The repair will include these exact formatting corrections after the current full caller invocation ends, without changing the cancellation assertions, timeouts or permissions.

Independently downloaded and parsed original artifact 13904497466: `6031-windows-learn-regressions.zip`, 15,146 bytes, SHA256 `0b7447a83f43d6b29388612395ae3c23ed3b44ce2793bb63f827ed65cbd7657d`, matching GitHub's artifact digest. All six ZIP member CRCs pass. The original execution.json independently confirms source and tested SHA equal b514c3, both before/after dirty=false and tree=3e45. Parsing the original 9,050-byte native-junit.xml confirms 36 cases, zero failures/errors, zero skipped XML cases and the same reported JUnit hash.

The complete Windows private-state decoded job log is retained as `6031-windows-private-state-job.log`, 353,882 bytes, SHA256 `fe1efaa3c1a95e650471a59eb81b4fca136576dd1bc145c0b601dafecbe2ee3e`, with original CRLF positions preserved.

## Final local repair candidate committed

To preserve the running proof's original inputs while allowing the complete fix to proceed, a second isolated worktree was created at `/workspace/scratch/ff41dfc0f7bf/hepta-repair-final`, branch `codex/learn-physical-current-final-20261112-ff41`, again based on exact b514c3. The original `hepta-repair` snapshot remains unchanged.

- Commit: `0ec50310ce879e7f8e520c1ff46312cba45f70b0`.
- Tree: `8fbebb5918648cd697f9e85dea709d25a0c7eac8`.
- Sole parent: `b514c3cacb73de1bb0adb46b202225e16d3b11c9`.
- Clean final worktree. Four changed files, 29 insertions and 15 deletions; no production Rust source is changed by this follow-up.

The final candidate adds the exact `poisoned: AtomicBool,` field guard, the four explicit match/panic fixture checks, and the two rustfmt-only corrections to the queued-cancellation fixture. Every original ordered source sequence, forbidden marker, boundary and privileged inventory remains unchanged. All execution-store test bodies and assertions, beginning with the LostAck fixture enum, were compared byte-for-byte to the parent and are identical. No QA assertion, verifier rule, deadline or permission check is removed or relaxed.

Final local verification:

- Original source-control command: **234 methods, all PASS**, 92.796 seconds, process exit 0. Log `repair-final-source-closure.log`.
- All 292 protected-file entries pass; caller self-test passes.
- Original `just fmt --base b514c3...` passes.
- The exact six-package `cargo fmt ... -- --check` scope from the failing Windows workflow now exits 0. Log `repair-final-windows-format-scope.log`.
- Exact blob-size checker passes all four changed files. CALLERS.toml is 666,439 bytes, pinned by SHA256 `da134c34f5f447d2788b28598523876236e2e23248af4f1972f1ec00cddc0ca2`; no unbounded allowlist or threshold change. Log `repair-final-blob-size.log`.
- `git diff --check` passes.

Machine-readable local provenance, file blob identities and log digests are in `repair-final-validation.json`. Full caller on the earlier tree 522e independently passes as recorded above; that execution is not called a pass on final tree 8fbe. The final commit requires its own exact-source hosted full caller/native/blocking results. Local native compilation is deliberately not run concurrently with the parent task's reserved agentd target/JUnit resources.

### Published mapping

The parent advanced the independent PR 6031 head through the GitHub connector with an expected-old-head b514c3 lease. Published remote commit **`abc64c7874e85143c05f86b9eef465b2b1957f8a`** maps to local commit **`0ec50310ce879e7f8e520c1ff46312cba45f70b0`**. Their full trees are identical: **`8fbebb5918648cd697f9e85dea709d25a0c7eac8`**. All four blob identities and the complete tree were checked by the parent. Commit object identities differ because the remote commit was constructed through the API; no source difference is implied. The original PR #6031 was merged at 2026-11-12 01:10:59Z with old b514 before this branch update. Consequently, the closed PR did not emit CI for abc64 and continued to display its original b514 head. The parent opened independent Draft #6076 for the repair. Any exact abc64 or successor qualification remains separate from the earlier b514 results.


## Reconcile the new f8ea resident-owner base

The #6076 base advanced to `f8ea08942b68c84ccc105d17371f95ddd372d355`, containing 18 commits beyond b514. It already includes equivalent unique witness top-level anchors and four Holdout required markers; those upstream improvements were preserved. The two test files still needed the original fixture/format repair. The old CALLERS manifest itself could not parse because a training row defined an inline required_function_order array and then extended it as an array of tables. Its Candidate authority sequence also contained only one marker, which the unchanged verifier rejects.

A true two-parent repair merge checkpoint was created: `0ab0daa79feaa0eb3f0faa061c4cd1edd2b83bff`, tree `959f25fb75eca7c9db78b619a0f562a6061418a7`, ordered parents f8ea and abc64. The automatic merge had only CALLERS conflicted. The resolved tree differs from that automatic merge only in CALLERS and the exact digest allowlist, and differs from f8ea in the original four repair files. A parsed semantic comparison proves all 425 boundaries and all 329 protected rows are retained, with the training table structure normalized, witness field comma strengthened, and Candidate authority signature added before its retained DENY_ALL marker.

The original full source command on tree 959f completed **259 methods, eight errors**, in 101.967 seconds. Three errors share the old dot-call marker applied to the new readiness UFCS caller. Five more expose opaque or missing typed receivers in the newly composed Resident paths. These original failures are preserved in `integration-source-closure.log` and its execution JSON. The separate full caller process on the same tree exited by signal 9 after 57.94 seconds with zero log bytes; there is no verifier result and no proven explanation for the termination.

The next independent checkpoint, `eae14fd58ba4c500d431ddb82fd366bd6c370f6b`, keeps actual calls, arguments, deadlines, custody and verifier semantics unchanged while making every original receiver explicit. It retains the shared exact Selection marker and binds the new readiness Cell reference explicitly before both reads. Narrow pub(crate) reexports make two already pub(crate) types nameable for annotations; no constructor or factory is added. All ten runtime run receivers are concretely named, so unrelated same-name calls are classified instead of hidden. Existing source negatives are retained, and readiness gets an additional binding-removal control. The previously failing caller-control methods and all 329 protected rows pass after this correction.

The formatting checkpoint, `88e30974b8d2802f5f6819ed3411df09851ea755`, tree `b965c72c3a4432df6e059b36c7bc67d5bf6c2c76`, applies repository formatting to the changed source and rebinds exact guard spelling to the formatted code. Eighteen marker spellings and six existing QA needles are mapped to the same tokens. Two later occurrences of a three-check CURRENT sequence are separately rebound to their formatted await spans; all three ordered checks remain. The actual verifier, every boundary tuple, forbidden list and ordered business guard are preserved. CALLERS exact SHA256 is `e60414032a5b796e5fecd43dbeaf1beb16b8539886eeb6ec3ee270131b8d790e`.

The final original 259-method suite passes on clean exact 88e309/b965: 96.909 seconds, exit 0, unchanged clean source before and after, log SHA256 `23d579cc4c13248a828ac4b4cd5b4dc5966dbc4e866ebab7dc103d186867631b`. All 329 protected rows, caller self-test, scoped formatter and original blob-size policy also pass. Its separate full caller invocation started 01:54:12Z and was explicitly interrupted with observed exit 130 to serialize resource use with the parent task's frozen caller proof. No verifier receipt was produced and no caller pass is claimed. The actual six-package Windows format check still fails on 43 files, all unchanged from f8ea; that separate upstream formatting repair is developed on a child branch. No native or full blocking pass is inferred.

The retired old worktrees were removed only after their clean saved states were verified. First proof tree 522e is retained as local commit `5a46be484b7da82c83d6a55f32d1464f00fc66db`, with the exact two-file patch and original proof logs. Final old repair 0ec/abc remains in git with the same tree and original verification record. `retired-worktree-checkpoints.json` records the removal checks; current integration and profile worktrees remain intact.

The standalone caller-cache source commit is `1aef654b5bc03be53e2fcc440b2611f4c73ee870`, changing only `scripts/verify_hepta_callers.py`. Its raw GitHub commit and diff are retained in `caller-cache-original-commit.json`. It caches AuthorityFields only inside one verify invocation, retains the uncached helper, full per-boundary scans, original diagnostics and reports, and adds cached/uncached/source-mutation equivalence self-tests. Those self-tests actually pass in the f8ea integration. This does not substitute for full proof of another source tree.
