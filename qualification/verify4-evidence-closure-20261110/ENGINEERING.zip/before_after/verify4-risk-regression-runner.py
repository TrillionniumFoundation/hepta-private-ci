"""Run controlled stale-content comparisons from the candidate checkout."""
import argparse
from dataclasses import replace
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path.cwd()))
from experiments.verification_cell_verify1 import shadow_risk as current

parser = argparse.ArgumentParser()
parser.add_argument('--baseline', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
baseline_path = Path(args.baseline)
assert hashlib.sha256(baseline_path.read_bytes()).hexdigest() == '157e1e1f4e4940bfa4c3fd8525dc1cf6e9ab48f1dbfc0a1df3d72ed64170798b'
spec = importlib.util.spec_from_file_location('risk_before', baseline_path)
baseline = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = baseline
spec.loader.exec_module(baseline)


def fitted(module):
    sha = 'a' * 64
    target = module.Target('sqlite', 'terminal_goal_error', 4, sha)
    snapshots = [module.Snapshot(str(i), 'train', sha, target, step, ())
                 for i in range(2) for step in (0, 2)]
    labels = [module.TerminalLabel(str(i), 'train', sha, target, 'accept', bool(i),
                                   4, sha, None) for i in range(2)]
    model = module.fit_risk_table(snapshots, labels, target, ('train',), ('eval',))
    return model, module.Snapshot('t', 'eval', sha, target, 0, ())


record = {'schema': 'hepta.verify4.risk-binding.regressions.v1',
          'started_at_utc': datetime.now(timezone.utc).isoformat(),
          'baseline_remote_commit': 'a2cd828aad47c56ac8c01dc2e423454eca7eafae',
          'baseline_source_sha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
          'current_source_sha256': hashlib.sha256(Path(current.__file__).read_bytes()).hexdigest(),
          'cases': [], 'independent_real_tasks': 0, 'scientific_admission': 'HOLD',
          'production_authority': 'NONE'}
for case in ('stale_cells', 'stale_missing_denominator', 'post_construction_tamper'):
    outcomes = {}
    for name, module in (('baseline', baseline), ('current', current)):
        model, observed = fitted(module)
        old_identity = model.model_sha256
        try:
            changed_cells = tuple((step, features, 0, count) for step, features, _, count in model.cells)
            if case == 'stale_cells':
                model = replace(model, cells=changed_cells)
            elif case == 'stale_missing_denominator':
                model = replace(model, missing_training_labels=1)
            else:
                object.__setattr__(model, 'cells', changed_cells)
            result = model.predict(observed)
            outcomes[name] = {'accepted': True, 'model_identity_unchanged': result.model_sha256 == old_identity,
                              'probability': result.probability, 'missing_training_labels': model.missing_training_labels}
        except ValueError as error:
            outcomes[name] = {'accepted': False, 'reason': str(error)}
    assert outcomes['baseline']['accepted'] and not outcomes['current']['accepted'], case
    record['cases'].append({'name': case, **outcomes})
old, _ = fitted(baseline)
new, observed = fitted(current)
record['unchanged_prediction'] = {'baseline_model_sha256': old.model_sha256,
                                  'v2_model_sha256': new.model_sha256,
                                  'probability': new.predict(observed).probability}
try:
    replace(new, model_sha256=old.model_sha256)
except ValueError as error:
    record['legacy_v1_refused'] = str(error)
else:
    raise AssertionError('v1 digest silently accepted')
record['exit_code'] = 0
Path(args.output).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
