"""Controlled scoring counterexamples; execute from the candidate repository."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
from datetime import datetime, timezone

sys.path.insert(0, str(Path.cwd()))
from experiments.verification_cell_verify1.test_matched_qualification import example, design_receipt, verify_fixture_design
from experiments.verification_cell_verify1.matched_qualification import analyze_matched

parser = argparse.ArgumentParser()
parser.add_argument('--baseline', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
baseline_path = Path(args.baseline)
spec = importlib.util.spec_from_file_location('baseline_matched', baseline_path)
baseline = importlib.util.module_from_spec(spec)
spec.loader.exec_module(baseline)
current_path = Path('experiments/verification_cell_verify1/matched_qualification.py')
assert hashlib.sha256(baseline_path.read_bytes()).hexdigest() == '7bc6e21c589e85a2e7f3d99b6634083715555856d87b2c5e6500a6d985dd1738'
result = {
    'schema': 'hepta.verify4.eval-regressions.v1',
    'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'baseline_remote_commit': 'a2cd828aad47c56ac8c01dc2e423454eca7eafae',
    'baseline_source_sha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
    'current_source_sha256': hashlib.sha256(current_path.read_bytes()).hexdigest(),
    'cases': [], 'real_independent_tasks': 0,
    'production_authority': 'NONE', 'scientific_admission': 'HOLD',
}
started = time.perf_counter()
for name in ('no_authenticated_design', 'mixed_within_cluster_assignment', 'zero_net_benefit'):
    m, rows = example(16, clusters=[i // 2 for i in range(16)]) if name == 'mixed_within_cluster_assignment' else example()
    if name == 'mixed_within_cluster_assignment':
        for i, pair in enumerate(m['pairs']):
            if i % 2:
                pair['first_arm'] = 'voi' if pair['first_arm'] == 'fixed' else 'fixed'
                for row in rows[2 * i:2 * i + 2]:
                    row['environment_id'] = pair['environment_a'] if row['arm'] == pair['first_arm'] else pair['environment_b']
    if name == 'zero_net_benefit':
        m['criteria'].update(min_mean_gain=0, max_one_sided_p=1)
        for row in rows:
            row['cost_units'] = 1 if row['arm'] == 'voi' else 0
    callbacks = {'verify_label': lambda *args: True, 'verify_cost': lambda *args: True}
    old = baseline.analyze_matched(m, rows, **callbacks)
    if name != 'no_authenticated_design':
        callbacks.update(design=design_receipt(m), verify_design=verify_fixture_design)
    new = analyze_matched(m, rows, **callbacks)
    assert old['gates']['externally_reviewable'] is True, name
    assert new['gates']['externally_reviewable'] is False, name
    result['cases'].append({
        'name': name,
        'baseline_externally_reviewable': old['gates']['externally_reviewable'],
        'current_externally_reviewable': new['gates']['externally_reviewable'],
        'baseline_p': old['paired_group_signflip_one_sided_p'],
        'current_inferential_p': new['paired_group_signflip_one_sided_p'],
        'current_conditional_p': new['conditional_group_signflip_one_sided_p'],
        'current_gates': new['gates'],
    })
result.update(elapsed_wall_seconds=time.perf_counter() - started, exit_code=0)
Path(args.output).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
