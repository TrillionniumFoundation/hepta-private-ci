"""Run two fixture modules while retaining all real SQLite handles, without GC."""
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys
import unittest
from unittest.mock import patch

REPO = Path("/workspace/scratch/3a9f1e34ac14/hepta-verify4")
EVIDENCE = Path(__file__).parent
sys.path.insert(0, str(REPO))
mode, output = sys.argv[1:]
if mode not in {"before", "current"}:
    raise ValueError("expected before or current")
modules = []
for kind in ("repair", "label"):
    path = EVIDENCE / f"{kind}-{mode if mode == 'before' else 'combined-current'}.py"
    name = f"experiments.verification_cell_verify1._portability_{kind}_{mode}"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    modules.append(module)

real_connect = sqlite3.connect
connections = []
def retained_connect(*args, **kwargs):
    connection = real_connect(*args, **kwargs)
    connections.append((str(args[0] if args else kwargs["database"]), connection))
    return connection

suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(m) for m in modules)
with patch.object(sqlite3, "connect", retained_connect):
    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(suite)

unclosed, unexpected = [], []
for path, connection in connections:
    try:
        connection.execute("SELECT 1").fetchone()
    except sqlite3.ProgrammingError as error:
        if "closed" not in str(error):
            unexpected.append({"path": path, "error": str(error)})
    except Exception as error:
        unexpected.append({"path": path, "error": type(error).__name__ + ": " + str(error)})
    else:
        unclosed.append(path)
summary = {
    "schema": "hepta.verify.test-sqlite-lifetimes.v1",
    "test_source_snapshot": mode,
    "tests_run": result.testsRun,
    "tests_successful": result.wasSuccessful(),
    "connections_created_and_retained": len(connections),
    "connections_still_open_after_tests": len(unclosed),
    "open_connection_paths": unclosed,
    "unexpected_errors": unexpected,
    "forced_gc": False,
    "scope": "Local Linux lifetime audit; does not establish a native Windows CI pass",
}
print(json.dumps(summary, indent=2))
Path(output).write_text(json.dumps(summary, indent=2) + "\n")
for _, connection in connections:
    connection.close()
raise SystemExit(0 if result.wasSuccessful() and not unclosed and not unexpected else 1)
