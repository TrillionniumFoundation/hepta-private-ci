"""Retain every real SQLite connection; assert explicit closure without GC."""

import json
from pathlib import Path
import sqlite3
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, "/workspace/scratch/3a9f1e34ac14/hepta-verify4")
real_connect = sqlite3.connect
connections = []


def retained_connect(*args, **kwargs):
    connection = real_connect(*args, **kwargs)
    connections.append((str(args[0] if args else kwargs["database"]), connection))
    return connection


suite = unittest.defaultTestLoader.loadTestsFromName(
    "experiments.verification_cell_verify1.test_repair_lineage"
)
with patch.object(sqlite3, "connect", retained_connect):
    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(suite)

unclosed, unexpected = [], []
for path, connection in connections:
    try:
        connection.execute("SELECT 1").fetchone()
    except sqlite3.ProgrammingError as error:
        if "closed" not in str(error):
            unexpected.append({"path": path, "error": str(error)})
    except Exception as error:
        unexpected.append({"path": path, "error": type(error).__name__ + ": " + str(error)})
    else:
        unclosed.append(path)

summary = {
    "schema": "hepta.verify.test-sqlite-lifetimes.v1",
    "tests_run": result.testsRun,
    "tests_successful": result.wasSuccessful(),
    "connections_created_and_retained": len(connections),
    "connections_still_open_after_tests": len(unclosed),
    "open_connection_paths": unclosed,
    "unexpected_errors": unexpected,
    "forced_gc": False,
    "scope": "Local lifetime audit; does not establish a native Windows CI pass",
}
print(json.dumps(summary, indent=2))
if len(sys.argv) > 1:
    Path(sys.argv[1]).write_text(json.dumps(summary, indent=2) + "\n")
for _, connection in connections:
    connection.close()
raise SystemExit(0 if result.wasSuccessful() and not unclosed and not unexpected else 1)
