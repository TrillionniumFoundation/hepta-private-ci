"""Replay the five private, non-wire changes on source-bound checkouts."""
from pathlib import Path
from hashlib import sha1,sha256
import argparse, json, re, sys, tempfile

p=argparse.ArgumentParser();p.add_argument('base',type=Path);p.add_argument('candidate',type=Path);p.add_argument('--changes',type=Path,required=True);p.add_argument('--output',type=Path);args=p.parse_args();roots=[r.resolve()for r in [args.base,args.candidate]];sys.path.insert(0,str(roots[1]/'scripts'));import verify_hepta_callers as q

def git(text):
    raw=text.encode();return sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def signatures(src):
    return re.findall(r'(?ms)^\s*pub(?:\([^)]*\))?\s+(?:(?:async|unsafe|const)\s+)*fn\s+\w+\s*\(.*?\)\s*(?:->\s*[^\{;]+)?\s*[\{;]',src)

def source_manifest(path):
    return q._load_manifest(path/'CALLERS.toml')

types={'root_independent_b_client.rs':'TrainingMode','authority_host_publication_completed.rs':'ReadPhase','authority_host_learning_resident_gate.rs':'GateActionV3','cell_q24_training_command_connection.rs':'Origin','cell_q24_model_command_connection.rs':'Origin'}
results=[];changes=json.loads(args.changes.read_text());assert len(changes)==6
for row in changes:
    rel=row['path'];name=Path(rel).name;old,new=[(r/rel).read_text()for r in roots];assert git(old)==row['before'] and git(new)==row['after'];ref=old
    for a,b in row['replacements']:
        assert ref.count(a)==1;ref=ref.replace(a,b)
    assert ref==new and signatures(old)==signatures(new)
    if name in types:
        enum=types[name]
        for src in [old,new]:
            d=re.search(r'(?m)^enum '+enum+r'\b[^\n]*\{',src);assert d,(name,enum)
            prologue=src[:d.start()].rstrip().rsplit('\n',1)[-1];assert not prologue.startswith('#['),(name,prologue)
            assert re.search(r'(?m)^pub(?:\([^)]*\))?\s+enum\s+'+enum+r'\b',src) is None
    result={'path':rel,'private_enum':types.get(name),'source_hashes':[git(old),git(new)],'unchanged_public_and_scoped_signatures':len(signatures(old)),'only_listed_replacements':len(row['replacements'])};results.append(result)
mb,mc=map(source_manifest,roots);assert {k:v for k,v in mb.items()if k!='protected_file'}=={k:v for k,v in mc.items()if k!='protected_file'};assert len(mb['boundary'])==len(mc['boundary'])==1652
rows=[(a,b)for a,b in zip(mb['protected_file'],mc['protected_file'],strict=True)if a!=b];assert len(rows)==3
cross=[]
for a,b in rows:
    assert a.keys()==b.keys() and a['path']==b['path'];assert len(a['required_function_order'])==len(b['required_function_order'])
    for arm,root,row in [('new_source_old_guard',roots[1],a),('old_source_new_guard',roots[0],b)]:
        try:q._verify_protected_files(root,{'protected_file':[row]})
        except q.VerificationFailure as exc:cross.append({'path':a['path'],'direction':arm,'reason':str(exc)[:145]})
        else:raise AssertionError((a['path'],arm))
checked=[len(q._verify_protected_files(root,tab))for root,tab in zip(roots,[mb,mc])];assert checked==[826,826];result={'files':results,'untouched_boundaries':len(mb['boundary']),'protected_checks':checked,'specific_guard_cross_rejections':cross,'private_enum_count':len(types)};out=json.dumps(result,indent=2)+'\n';print(out,end='');
if args.output:args.output.write_text(out)
