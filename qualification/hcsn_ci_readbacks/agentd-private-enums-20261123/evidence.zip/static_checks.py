import argparse,hashlib,json,os,sys,time,subprocess,unittest,io
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('out',type=Path);a=p.parse_args();root=a.root.resolve();qa=root/'qa/b4-no-bypass';sys.path.insert(0,str(qa));sys.path.insert(0,str(root/'scripts'));import verify_hepta_callers as proof
m=proof._load_manifest(root/'CALLERS.toml');all_regions=proof._verify_protected_files(root,m);assert len(all_regions)==826
terms=['authority_host_publication_completed.rs','authority_host_learning_resident_gate.rs','cell_q24_training_command_connection.rs','cell_q24_model_command_connection.rs','root_independent_b_client','root_independent_b_training']
names=sorted({f.stem for f in qa.glob('test_*.py') if any(t in f.read_text()for t in terms)}|{'test_completed_publication_source_closure','test_original_training_initial_connection_source_closure','test_resident_candidate_stage_source_closure','test_original_candidate_operation_source_closure','test_original_b_routes_source_closure'})
records=[]
for n in names:
 print(n,flush=True);suite=unittest.defaultTestLoader.loadTestsFromName(n);s=io.StringIO();result=unittest.TextTestRunner(stream=s,verbosity=1).run(suite);records.append({'suite':n,'cases':result.testsRun,'red':len(result.failures)+len(result.errors),'failures':s.getvalue() if not result.wasSuccessful() else []})
rec={'protected':len(all_regions),'boundaries_in_manifest':len(m['boundary']),'suites':records};a.out.write_text(json.dumps(rec,indent=2)+'\n');print('total',sum(r['cases'] for r in records),'red',sum(r['red'] for r in records));sys.exit(any(r['red'] for r in records))
