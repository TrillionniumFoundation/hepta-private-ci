"""Recompute paired Clippy diagnostics and each EUID-specific libtest verdict from Action ZIPs."""
import argparse,collections,hashlib,json,re
from pathlib import Path
from zipfile import ZipFile
p=argparse.ArgumentParser();p.add_argument('strict',type=Path);p.add_argument('native',type=Path);p.add_argument('--output',type=Path);a=p.parse_args();B='d1ab8c895dbdceda956f7765da36e07a71c7f760';C='391b379f5225d28db21580f1df526a31f761dd2a';arms={'base':B,'candidate':C};results={'sources':arms,'artifacts':{},'strict':{},'native':{}}
with ZipFile(a.strict)as st,ZipFile(a.native)as nt:
    fixtures=[]
    for typ,z,path in [('strict',st,a.strict),('native',nt,a.native)]:
        assert z.testzip()is None;results['artifacts'][typ]={'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()};roster=json.loads(z.read('cases.json'));fixtures.append(z.read('fixtures-base.txt'));assert z.read('fixtures-candidate.txt')==fixtures[-1];assert len(fixtures[-1].splitlines())==len(set(roster['ordinary'])|set(roster['uid0']))
        for arm,ref in arms.items():assert z.read('identity-'+arm+'.txt').decode().strip()==ref
    assert fixtures[0]==fixtures[1] and st.read('cases.json')==nt.read('cases.json');roster=json.loads(nt.read('cases.json'));expected={mode:sorted(n for row in files.values()for n in row)for mode,files in roster.items()};assert len(expected['ordinary'])==27 and len(expected['uid0'])==30
    counts={}
    for arm in arms:
        s=st.read(f'strict-{arm}.log').decode();status=int(st.read(f'strict-{arm}.exit'));assert status==101 and not re.search(r'(?m)^error\[E\d+\]',s)
        errors=collections.Counter();pending=None
        for line in s.splitlines():
            if line.startswith('error: '):
                assert not pending
                if not line.startswith('error: could not compile'):pending=line[7:]
            elif pending:
                match=re.fullmatch(r'\s*--> ([^:]+):\d+:\d+\s*',line)
                if match:errors[(match[1],pending)]+=1;pending=None
        assert pending is None;counts[arm]=errors;cats=collections.Counter()
        for (path,m),n in errors.items():
            if 'too many arguments' in m:k='too_many_arguments'
            elif 'large size difference between variants'==m:k='large_enum_variant'
            elif any(t in m for t in ('never used','never read','never constructed')):k='dead_code'
            else:k=m
            cats[k]+=n
        results['strict'][arm]={'status':status,'rows':sum(errors.values()),'categories':dict(cats)}
    removed=sorted((counts['base']-counts['candidate']).elements());added=sorted((counts['candidate']-counts['base']).elements());names=['root_independent_b_client','authority_host_publication_completed','authority_host_learning_resident_gate','cell_q24_training_command_connection','cell_q24_model_command_connection'];exp=sorted(('hepta-agentd/src/'+n+'.rs','large size difference between variants')for n in names);assert removed==exp and not added;results['strict']['removed']=[list(x)for x in removed];cert=json.loads(st.read('strict.json'));assert cert['removed']==results['strict']['removed'] and cert['added']==added
    cert=json.loads(nt.read('native.json'));elfs=[]
    for arm in arms:
        results['native'][arm]={};elf=nt.read(f'binary-{arm}.txt').decode().split()[0];assert re.fullmatch(r'[0-9a-f]{64}',elf);elfs.append(elf)
        for mode,wanted in expected.items():
            raw=nt.read(f'{arm}-{mode}.log');txt=raw.decode();rows=re.findall(r'^test ([^ ]+) \.\.\. (ok|FAILED|ignored)\s*$',txt,re.M);assert len(rows)==len(wanted)and {n for n,v in rows}==set(wanted)
            uid='libtest actual real/effective UID: 0 0' in txt;assert uid==(mode=='uid0');m=re.search(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',txt,re.M);assert m;rc=cert[arm][mode]['code'];assert cert[arm][mode]['ELF']==elf and cert[arm][mode]['tests']==dict(rows)and cert[arm][mode]['log_sha256']==hashlib.sha256(raw).hexdigest()
            results['native'][arm][mode]={'ELF':elf,'cases':len(rows),'passed':int(m[2]),'failed':int(m[3]),'ignored':int(m[4]),'failed_names':[n for n,v in rows if v!='ok'],'code':rc,'uid0_attested':uid,'sha256':hashlib.sha256(raw).hexdigest()}
    assert len(set(elfs))==2
out=json.dumps(results,indent=2)+'\n';print(out,end='');
if a.output:a.output.write_text(out)
