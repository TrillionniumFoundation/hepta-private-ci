# Five private Agentd enum representations

The immutable baseline is `d1ab8c895dbdceda956f7765da36e07a71c7f760`. The product layout change is `c254e66d7acd975ba62d7eadd78d2a7dc0e963f1`. Its corrected fixture and final source are `391b379f5225d28db21580f1df526a31f761dd2a`. `changes.json` enumerates the exact representation changes in six Rust files, including a constructor in a child module. Each replacement is taken from the corresponding blob on the qualified donor at `24abd04c825cb0d5d0ce27b52ac5008eda13dde4`; `donor-identity.json` identifies all six Git blobs. The old and new trees preserve public and crate-scoped constructor signatures, wire declarations and variant meanings. Rust's default layout and allocation behavior can change. For the B client the existing allocation moves earlier; for the other four values the new boxed payload allocates at construction of the affected nonempty variant.

| Private enum | Value stored indirectly | Pre-change lower bound reported by the same Clippy toolchain |
| --- | --- | ---: |
| `root_independent_b_client::TrainingMode` | Original ready-source payload on `Complete` | 320 bytes |
| `authority_host_publication_completed::ReadPhase` | Observed completed publication | 336 bytes |
| `authority_host_learning_resident_gate::GateActionV3` | Checkpoint snapshot | 1,304 bytes |
| `cell_q24_training_command_connection::Origin` | Recovered receipt and attestation when present | 656 bytes |
| `cell_q24_model_command_connection::Origin` | Recovered snapshot and digest when present | 1,336 bytes |

The two `Origin` types keep distinct `Fresh`, `Recovered(None)` and `Recovered(Some(...))` paths. Both empty recovery paths remain allocation-free. `verify_sources.py` applies every change to the baseline text and compares the complete result with the candidate. It verifies six old/new cross-rejections across three changed protected records and equality of all 1,652 registered caller boundaries. `static_checks.py` executes all 826 protected-file checks plus 19 related source-closure suites. `rustfmt.json` records byte-for-byte Rust 1.96.0 formatting for each source. The final 13 changed Git blobs are recorded in `github-final-diff.json`. The additional fixture binds its already-signed values with the same private constructor conversion; its complete Git blob equals the pre-existing donor. The 57 named native parent cases and their test files are unchanged.

One additional private candidate, `Decision` in `memory_serving_qualification.rs`, was left for separate qualification: the fixed source inventory contains its public `MemoryServingQualificationV1` constructors and uses of already-qualified values. This review found no original test constructing `MemoryServingQualificationV1::selected` or `::rollback`. The enclosing public type has private representation, and a valid signed selection / rollback and citation fixture would exercise those constructors. The five admitted changes carry their own evidence. No performance or coverage instrumentation was used.

## Measured qualification

The original strict command gave 124 diagnostics on the baseline and 119 on the corrected candidate. The five named enum diagnostics disappeared and no new diagnostic was observed. Actual exits remained 101 with 71 argument-count, 35 large-enum and 13 dead-code findings. The corrected candidate passed all 27 ordinary and all 30 actual-UID0 tests. Its paired baseline passed the 27 ordinary and 29 of 30 UID0 tests. The same baseline had failed the same queued-cancellation readback assertion on a different runner in the preceding attempt. The original assertions and timeouts are unchanged. The native *pair* remains red because the baseline failed. The assertion output does not disclose the failing return variant. These runs do not establish that the five layout changes resolve the inherited transport behavior.

The first candidate's native build exposed a test-only `Origin` constructor that still used the previous representation. The correction uses the exact previous donor file, including all existing checks. The first run's source-specific compiler outputs and UID0 failure are retained in `v1/`. The second strict workflow verified and reused the unmodified baseline log from the first artifact and freshly compiled the corrected candidate. `verify_results.py` recomputes all diagnostic counts and every individual native verdict.

## Replay

From this directory, use Python 3.11+ with two clean worktrees pinned to the commits above. The original source checks read the fixed `qa`, `codex-rs`, `scripts`, root manifest and `.github/workflows/hepta-daemon-learning-native.yml`.

```bash
python3 verify_sources.py "$BASE_CHECKOUT" "$CANDIDATE_CHECKOUT" --changes changes.json
python3 static_checks.py "$BASE_CHECKOUT" base-static-replay.json
python3 static_checks.py "$CANDIDATE_CHECKOUT" candidate-static-replay.json
python3 verify_results.py strict.zip native.zip
```

The narrow source-specific hosted workflow checks out and builds both original libtest binaries and records distinct SHA-256 values. `cases.json` binds the unchanged native fixture files and exact libtest filters. Non-root and actual UID0 groups run serially. The UID0 group uses the original isolated `/run` fixture structure with two bind mounts and original root-only cases. Child helpers run through their parent fixtures. Raw fixture and test logs are retained in the Actions archives; shell exit status and individual tests have separate fields. The unchanged three-package strict command covers all build targets of the named packages. The two worktrees' full raw diagnostics are compared by path, complete message and multiplicity.

[Candidate](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/391b379f5225d28db21580f1df526a31f761dd2a) · [Paired hosted run](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45132769603) · [Frozen workflow and scripts](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/247e45bc43b29c7a429f2ae691cda3cd54edcf78/.github)
