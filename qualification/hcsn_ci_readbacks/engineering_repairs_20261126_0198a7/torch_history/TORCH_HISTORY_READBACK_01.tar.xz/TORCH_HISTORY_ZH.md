# 原 Torch probe 的真实历史：只读核对与不重放结论

## 结论

原小型 native probe 已实际失败过一次、随后成功；后继 current/archived 双 lane 及独立 current 运行也已有成功。不存在可以因本次字节恢复而重新领取的“尚未执行一次”。220 forward / 32 adjoint 是原单次 probe 上限，不是已结束运行留下的 54 / 22 次可用余额。

本次只读取 GitHub 原 job logs、Actions 元数据、既有 RESULT 与来源清单；没有导入或执行候选、模型、adjoint、optimizer 或原审核程序。

## 原身份与实际执行

原 REQUEST identity 为 `hcsn-continuous-adjoint-torch-20261112-c06d-stage1`，约束 N7/N12、69 个输入坐标、固定物理/支撑、0 optimizer。

| 既有执行 | 精确来源 | 真实工作与结果 |
|---|---|---|
| 原 red001 | `bc1b94039dea52c5426b99ba617f7a2f59742377`；run43216185145/job131175904511 | 原 pointer 记录完成 1 个 primal、0 adjoint，随后写只读 `ctx.metadata` 失败；`no_rerun=true`。 |
| 原 green002 | `975a169df5f3a1dd51b81ddd51b0a338592a0e0f`；run43217764472/job131181247635 | PASS，166 forwards、10 adjoints、32 backward attempts、20 guards、0 optimizer。 |
| 后继 archived lane | run45106995789/job137470458710；检出 `975a169…` | PASS，另一次真实 166/10/32/20/0，原数组 SHA 与 green002 一致。 |
| 后继 current lane | run45106995789/job137470458296；`7869063345ea43cc9cb83ff6d76d70bf94ff62a5` | PASS，另一次真实 166/10/32/20/0，采用显式 11 源清单。 |
| 独立 current 运行 | 同一 `7869063…`；既有 RESULT blob `57385a0d7ff446fde81e659154ef97ff36961e20` | Python3.12.14/Torch2.15.0+cpu/NumPy2.3.5/SciPy1.17.0，另一次166/10/32/20/0。 |

原 green002 的运行环境为 Python3.12.16/Torch2.8.0+cpu/NumPy2.3.5/SciPy1.17.0，单线程。后继两个 hosted lane 使用 Torch2.10.0+cpu。不能把这些不同执行合并为“一次”，也不能把上表当作全研究生命周期的完整账本。

直接读取的原 green002 job log 第275行绑定完整10源与清单，第310行给出PASS计数，第312行给出完整过程成本；原 current job log 第372/410/412行分别给出11源、PASS计数与成本。另读 archived job log 和两job的API success状态，均与持久原件一致。

## 精确成本与原件

| 执行 | 完整过程 wall / CPU 秒 | RSS KiB | 原 artifact |
|---|---:|---:|---|
| 原 green002 | 60.759934334 / 60.306657 | 454140 | 13943834079；254226B；SHA `8bca916a6f5dc7b346905268d005fab838805b475e39df738cb5a053b8ffe9d8` |
| archived lane | 56.723528189 / 56.285226 | 498460 | 14788591512；254035B；SHA `5483c43dbfb620ff89d6948bf88e1d163d89c513f9a42bcaf408a16ed4ece11b` |
| current lane | 65.028662539 / 64.542695 | 431404 | 14788432513；254354B；SHA `2f33d2a950a68d56711d0940d1bd55fe5ea8fe4d76d3e88300e308853a34df51` |
| 独立 current | 70.259465112 / 69.582394 | 319008 | 同源持久 RESULT/PROCESS-COST，见下方 immutable tree |

API直接回读核对了三个 hosted artifact 的ID、字节数、SHA、run和head；本次没有重新下载/解码其数组，也没有重算原数值比较。原 SciPy BDF invalid-subtraction warning 继续保留，不能据结果有限而声称已证明其无害。

- [#6248 原成功及原失败披露](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6248)
- [原成功 job](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43217764472/job/131181247635)
- [原成功持久原件：2147dd4e](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/2147dd4e9c844180657b7dfce33a3b827353f82a/qualification/hcsn_ci_readbacks/6248-green002)
- [#7000 独立 current 后继](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/7000)
- [后继双 lane 真实运行](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45106995789)
- [后继持久原件：f5dbb986](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/f5dbb9861674c85ac9711ade9a6f154a8201d6c7/qualification/hcsn_ci_readbacks/current-adjoint-7869063)

## 本次 frozen view 与历史成功的关系

成功头975a169的 `TORCH-SOURCE.json` Git blob为 `b563b033261deec74d145cb36602df198041de06`，SHA256为 `afcc90fb68730219a60a94a48e28c9169a060858c8b11b9be623b7f496c76de6`；`torch_flow.py` Git blob为 `4c1d0323b2ec3d11dc6f1800027eaabd4470643b`，SHA256为 `0f23d6ff6351be021f93d054b2cc2037ef76a87f29d11ca48fd4a725238bb5b4`。这两项正是本次物化视图保全的版本，原成功日志同时绑定其余九项源。

该 flow 已把保留字段改为 `ctx._hcsn_metadata`。旧失败只读属性碰撞不能作为还未修复、需要再跑的理由。

冻结 manifest 的原 `new_torch_executions=0` 和 `INTENT_NOT_EXECUTED` 是运行前身份的一部分，没有在执行后改写；它们不能替代后续实际日志账本。集成树中旧 README 的 INTENT 表述同样不能覆盖分支上已有成功。

本次 firstcycle/byte batch 的 model=0 与 Torch native=false 仅描述本次操作；已通过的旧probe不因恢复源码而重新获得额度。发布范围已用新的 scope-corrected README澄清，旧原件不修改。

## 当前集成阻塞的具体位置

对最新观测集成头 `55ffa46dc4a74e01714b13bb3625f9ca12aeb684` 与成功头 `7869063…`，按 CURRENT-SOURCE 的11路径逐项读取Git对象：9/11完全同blob，详见 `CURRENT_11_BLOB_COMPARISON.json`。

共同的9项包括REQUEST、torch_flow、refractory、spatial、graded model/spatial、initial adjoint solver、joint model及state_io。仅两项不同：

- workflow：当前 `9d908458d859bbe0fcf95d2c3c078a2c5139246d`，已成功后继 `5c95211cfd90f4c62a8d837a39b3c586a0ae8726`。
- native_probe：当前 `5fcce67fe9ca342c8d4f735e438f5300299ee953`，已成功后继 `887782b2f4fd1e1fae2b2baa5d4a11dc9c0b9e20`。

因此当前失败主要是仍使用旧10源准入/harness、未承接后继11源清单的集成问题。已有物理/伴随源码的精确对象可对应历史成功；当前整个head的harness/runtime资格仍需单列，不能仅以9/11相同签收整头。

不能直接重派或照搬触发#7000双lane来再执行既有166/10实验。下一步是只读承接原源、原结果、原成本及当前差异；任何新的执行方案均不能冒充旧机会未用。

所述成功只覆盖固定小模型的一阶输入梯度；不是adaptive-BDF指令级反向、自由边界/物理参数梯度、高阶梯度、全网络训练或N512资格。整体HCSN仍HOLD。
