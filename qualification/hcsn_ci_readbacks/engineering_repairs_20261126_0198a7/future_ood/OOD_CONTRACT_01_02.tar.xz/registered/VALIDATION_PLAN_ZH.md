# 113 项采集与一次合同执行的核对方案

状态：**仅静态方案，尚未执行采集、导入或测试。**

源：`ce6b9fe9dcb7d6bb8e78978c8b81a001ac7e2ea2`。完整测试名单在 `EXPECTED_NODEIDS.txt`，每行一个相对于 `tests/` 的实例 ID，保留类名和参数值后缀。

## 预期分布

| 测试文件 | unittest 实例 | pytest 实例 | 合计 |
|---|---:|---:|---:|
| test_bundle.py | 0 | 8 | 8 |
| test_checkpoint_receipt.py | 7 | 0 | 7 |
| test_component_resource_receipts.py | 12 | 0 | 12 |
| test_future_ood_matrix.py | 3 | 0 | 3 |
| test_harness_receipt_adapter.py | 6 | 0 | 6 |
| test_modality_descriptor_registry.py | 14 | 0 | 14 |
| test_prospective_plan.py | 13 | 0 | 13 |
| test_qualification.py | 0 | 25 | 25 |
| test_reader_fixture_bridge.py | 9 | 0 | 9 |
| test_resource_checkpoint_binding.py | 3 | 0 | 3 |
| test_stem_bridge.py | 13 | 0 | 13 |
| **合计** | **80** | **33** | **113** |

参数展开必须保留：

- invalid_label 的 4 个输入：`True`、`-1`、`4`、字符串 `'0'`；pytest 默认展示后缀依次预计为 `[True]`、`[-1]`、`[4]`、`[0]`。
- head kind 的 6 个输入：linear、film、lowrank8、lowrank16、mlp、swiglu。
- 新的 `test_dataset_cross_cell_pool_rejected` 必须在名单中。
- 类中的 subTest 循环仍属于同一个 pytest 实例，不能把循环次数计作额外收集项。

这些 ID 是静态预期；如果实际 pytest 9.0.2 输出的命名格式不同，先核对是否仅为路径/参数显示差异，不通过改总数来掩盖缺失实例。

## 后续执行前

由 root 在隔离目录和已有原 runtime 中进行，不在共享工作树执行。保持 `qualification/neuron-shared-encoder` 与相邻 Stem 文件的相对位置。先逐项比较 `SOURCE_MANIFEST.tsv` 的 Git blob，保存源读回记录；本次静态交付已核对 33/33。

记录 `python -VV`、解释器路径、torch/pytest 安装元数据与 pip check。预期直接版本 torch 2.10.0 CPU（通常报告为 2.10.0+cpu）、pytest 9.0.2；Python 版本要实录，不能假称观察到未运行的版本。只使用所需 CPU 合同依赖；不执行 Laya 安装步骤，不下载 checkpoint。

## 单次 pytest 会话

无需先运行一次 collect-only。一次正常 pytest 会话本身会收集并执行所有实例，使用详细输出和 JUnit 结果保留名单与结果。建议 root 将以下命令中的路径变量绑定到新的隔离目录，在一个新结果目录内执行一次：

```sh
cd "$OOD_SOURCE_ROOT/qualification/neuron-shared-encoder"
env -u PYTHONPATH PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTEST_ADDOPTS= \
  "$OOD_CONTRACT_PYTHON" -m pytest -vv -ra -p no:cacheprovider \
  --junitxml="$OOD_RECEIPT_DIR/junit.xml" tests/ \
  > "$OOD_RECEIPT_DIR/pytest.log" 2>&1
```

这是验证计划中的拟执行命令，未在准备阶段运行。关闭第三方自动插件、禁用 cacheprovider 和空的 PYTEST_ADDOPTS 只隔离宿主杂项，不改变测试 selector。不得增加 `-k`、`-m`、ignore、deselect、skip、xfail、重试插件或容忍失败的后缀。保留真实退出码；不因失败再运行第二遍。

## 单次会话后必须满足

1. 退出码为 0，详细原日志报告收集 113 项且实际完成 113 项。
2. 结果有恰好 113 个不同的实例；每项都在 `EXPECTED_NODEIDS.txt`，两侧多重集合相等。不能只比较总数。
3. 所有实例通过；failure、error、skip、xfail、xpass、deselected 均为 0。
4. 原 80 个 unittest 方法全部保留；两个此前导入失败的文件分别执行 8 和 25 个 pytest 实例。
5. 源文件执行前后 Git blob 不变。生成的临时数据和结果文件不混入源身份。
6. 保存 Python/依赖版本、命令、完整 stdout/stderr、JUnit、时间与退出码。结果仅说明这份快照的合同执行情况。

可从详细 pytest 行读取原 nodeid，并去掉到 `tests/` 的路径前缀，得到清单格式。用 JUnit 独立核对时，取 testcase.classname 中的 test_module 及后续类名，转换为 `test_module.py::Class`，然后追加 `::testcase.name`；无类的顶层函数直接追加名称。参数后缀原样保留。若日志或 XML 与命名预期不一致，记录差异并检查，不能丢弃不匹配项使集合相等。

## 已知执行内容与范围

完整集合包括既有的少量 synthetic 模型合同：40 行合成数据，12 个 head 候选中 2 个过预算，成功路径上其余 10 项各 2 steps、合计 20 个 AdamW 更新；另有 64 Cell / 1 round / batch 16 的 stress smoke（9 条结果、无优化器）。逐项范围见 `BOUNDED_SYNTHETIC_SCOPE_ZH.md`。不另行运行 experiment CLI grids，不运行 E1–E6，不重训 R20，不运行真实 Laya intake。它们的通过不提供真实模型效益、生产选择或 HCSN 科学资格。

此验证方案不改变候选 workflow 的 15 分钟超时，也不重置任何已登记 allowance。若源头在验证前变动，旧 113 名单和旧快照结果不能直接转移到新 head；应首先只读核对源差异。
