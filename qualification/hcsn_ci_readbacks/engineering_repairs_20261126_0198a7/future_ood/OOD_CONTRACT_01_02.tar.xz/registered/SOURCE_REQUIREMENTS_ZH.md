# 合同验证的精确源清单

源提交：`ce6b9fe9dcb7d6bb8e78978c8b81a001ac7e2ea2`。完整逐文件 blob 在 `SOURCE_MANIFEST.tsv`，所有列出的原文件已存入 `source/` 并复核 33/33 Git blob。

## 执行所需源码

| 路径 | 数量 | 用途 |
|---|---:|---|
| `qualification/neuron-shared-encoder/neuron_shared_encoder/*.py` | 17 | 完整模块目录，含 lazy/fallback 导入 |
| `qualification/neuron-shared-encoder/tests/test_*.py` | 11 | 原 workflow 的测试目录，113 个静态预期实例 |
| `qualification/neuron-shared-encoder/requirements.txt` | 1 | 原声明 torch>=2.0、pytest>=8；候选借用同仓固定直接版本 |
| `qualification/stem-transfer-cell-artifact-p0/stem_transfer_cell_artifact.py` | 1 | 相邻的纯标准库合同依赖，必须保留目录相对位置 |

相邻 Stem 文件 Git blob 为 `213a2b3ed8ebbbc2a4d83188be8c892cef5876b4`；modality_descriptor_registry、prospective_plan、stem_bridge 的导入及测试会使用它。只复制 neuron-shared-encoder 目录会缺少这个依赖。

## Fixtures 与模型资产

上述 11 个测试文件的 fixture 全部在函数中构造，或使用 pytest tmp_path、monkeypatch、tempfile：

- bundle 测试在临时目录写入假的 checkpoint 文件字节，测试散列、符号链接、硬链接和先验拒绝。
- Reader adapter 测试在临时目录生成最小假 evaluator 和 case JSON；原 `scripts/hepta_sngr_reader_eval.py` 与真实 case JSON 不是这 113 项合同的读取依赖。
- qualification 测试生成小型 synthetic JSONL；不读取真实 checkpoint 权重。
- 没有独立 fixture 文件目录、网络数据下载或真实 Laya/Transformers 包需求。

因此不需要取真实模型、真实 Reader 数据或运行 sibling workflow 中的额外 grids。合同验证不得自动扩展到 Laya intake。

## 指令与配置

根 `AGENTS.md`（blob `faa57cc0db48123e1011f1eb47692cd3bbbcfc3a`）已读取并保存在 `source/AGENTS.md`。检查了下列目录的完整 Git tree / contents，未发现更近 AGENTS：

- `.github/`、`.github/workflows/`
- `qualification/`、`qualification/neuron-shared-encoder/`
- `qualification/neuron-shared-encoder/neuron_shared_encoder/`、`qualification/neuron-shared-encoder/tests/`
- `qualification/stem-transfer-cell-artifact-p0/`

根、qualification、共享编码器根及所取模块/tests 目录没有 pyproject.toml、pytest.ini、setup.cfg、tox.ini 或 conftest.py。Python 补丁版仍须在实际 runtime 中记录，不能从缺少配置推定。

## 保留的配置参考

另存 3 个原文件以供审阅、不是新增测试对象：

- `AGENTS.md`
- `.github/workflows/hepta-future-ood-harness-contract.yml`
- `.github/workflows/hepta-neuron-shared-encoder-shadow.yml`

共享编码器根目录另有 `test_modality_registry.py`、`test_registry_bridge.py`、`test_stem_qualification.py`。它们原本不在本 workflow 的 `tests/` selector 内，本候选保持原 selector 范围。113 项不宣称覆盖这三个独立模块。
