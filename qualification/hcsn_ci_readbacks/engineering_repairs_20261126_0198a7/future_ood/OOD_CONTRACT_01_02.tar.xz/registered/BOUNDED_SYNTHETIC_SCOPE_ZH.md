# 原合同内 bounded synthetic 执行的精确范围

本页来自 ce6b9fe9dcb7d6bb8e78978c8b81a001ac7e2ea2 的静态源码审查，未执行任何模型或测试。以下次数是无异常成功路径的预期，不是实测回执。

## 唯一进行优化器更新的测试

实例：`test_qualification.py::test_synthetic_head_smoke_and_no_change_distinguisher`。

- 输入由 `generated()` 调用 `_sample_data(path, 42, 8, 4)`，合计 40 行：train 16、validation 8、future 8、OOD 8；类别数 4。
- encoder 为默认 `synthetic-hash`，256 维，CPU；没有神经编码器或 checkpoint 下载。
- 使用两档预算 2048、16384，6 种 head，总计 12 个候选。
- 明确传入 `--steps 2`，默认 `--threads 1`、seed 42、batch 32、lr 0.001。
- 每次梯度更新的实际采样数为 min(16,32)=16；优化器为 AdamW。
- 原实现先检查参数量，超预算候选不会调用 `_train`。

| head | 2048 预算参数量 | 2048 预算行为 | 16384 预算参数量 | 16384 预算行为 |
|---|---:|---|---:|---|
| linear | 1028 | 2 steps | 1028 | 2 steps |
| film | 1540 | 2 steps | 1540 | 2 steps |
| lowrank8 | 3108 | OVER_BUDGET，无拟合 | 3108 | 2 steps |
| lowrank16 | 5188 | OVER_BUDGET，无拟合 | 5188 | 2 steps |
| mlp | 1831 | 2 steps | 16186 | 2 steps |
| swiglu | 1558 | 2 steps | 16062 | 2 steps |

因此成功路径为 **10 次短拟合、20 个 AdamW 更新**，不是 12 次完整训练。参数量依据当前 Head 层定义逐项计算；参数量测试会在未来单次 pytest 会话中动态验证。报告仍被原代码标记为 SYNTHETIC_SMOKE、production_admission=BLOCKED。

## 一个无优化器的 tensor stress 测试

实例：`test_qualification.py::test_synthetic_stress_runs_and_records_real_batch_execution`。

显式参数为 cell-counts=64、rounds=1、inference-batch=16、allow-synthetic。其他默认参数包括 dimension=256、classes=4、threads=1、seed=42。

循环为 3 个 reuse（same、partial、distinct）×3 个 active ratio（0.1、0.5、1.0），共 **9 条结果**。活跃数依次为 6、32、64；每个 reuse 下共 102 requests，全部合计 306 requests。它执行合成线性投影与张量运算、缓存和批量路径，没有 optimizer、loss.backward 或参数更新，不运行其他默认 Cell 档位 256/1024/4096。报告仍明确是 SYNTHETIC_TENSOR_NOT_HEPTA_WORKER。

## 其他与模型有关的合同

- `test_heads_real_parameter_counts`：6 参数化实例，各构造 4 档预算的 Head 并做一次 batch=3 的 no_grad forward；合计 24 个 Head 构造/前向，没有优化器。
- `test_organ_bank_and_projection_deterministic`：随机小张量、冻结投影与 OrganExpertBank 前向，没有拟合。
- `test_batch_scalar_gating_parity`、`test_ood_auc_logic`：仅比较张量运算结果。
- 跨 Cell、缺失资产、不允许 synthetic representation 等原负控在拟合前拒绝。
- bundle 中的 OfflineEncoder 用 __new__ 构造并替换检查函数，测试在模型/Agent 调用之前拒绝；不加载真实 Laya/Transformers。

本候选不新增任何上述模型执行，也没有修改原测试。完整 113 项实际验证会执行这些既有 bounded 合同；无需另跑 experiment CLI、sibling grids、Laya intake、E1–E6 或 R20。
