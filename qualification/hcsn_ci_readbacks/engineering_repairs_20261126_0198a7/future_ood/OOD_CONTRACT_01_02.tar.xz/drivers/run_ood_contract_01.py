"""One exact-roster contract session in the separate pinned CPU environment."""
from datetime import datetime, timezone
import functools
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import resource
import signal
import sys
import time

ROOT = Path('/home/alex/hepta-hcsn-fixes-20261126-0198a7')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert len(sys.argv) == 3 and sha(__file__) == sys.argv[1]
    expected_path = ROOT / 'OOD_EXPECTED_NODEIDS.txt'
    assert sha(expected_path) == sys.argv[2]
    expected = expected_path.read_text().splitlines()
    assert len(expected) == len(set(expected)) == 113
    assert sys.executable == str(ROOT / 'ood-venv-2.10/bin/python')
    output = ROOT / 'ood_contract_01'
    output.mkdir(exist_ok=False)
    source = json.loads((ROOT / 'SOURCE_CAPSULE.json').read_text())
    pins = dict(source['baseline'], **source['changes'])
    assert all(sha(ROOT / 'source' / name) == pin['sha256'] for name, pin in pins.items())
    admission = {'scope': 'one complete pre-existing 113-item synthetic contract suite',
        'source_head': source['source_heads']['integration'], 'runner_sha256': sys.argv[1],
        'expected_nodeids_sha256': sys.argv[2], 'test_methods': 113, 'attempts': 1,
        'maximum_adamw_updates': 20, 'synthetic_rows': 40, 'stress_records': 9,
        'wall_limit_s': 150, 'cpu_limit_s': 120, 'threads': 1,
        'historical_E1_E6_trials_added': 0, 'laya_intake_calls': 0,
        'official_format_receipt_sha256': '342442e8e6d045a1101e7f740124a29fb7029c77865de59f70b787728775872e',
        'failure_policy': 'Retain failure; no automatic retry or selector change.',
        'started_utc': datetime.now(timezone.utc).isoformat()}
    (output / 'ROOT_ADMISSION.json').write_text(json.dumps(admission, sort_keys=True, indent=2) + '\n')
    def limit_hit(number, frame):
        raise TimeoutError('Bounded contract limit reached: ' + str(number))
    signal.signal(signal.SIGALRM, limit_hit)
    signal.signal(signal.SIGXCPU, limit_hit)
    signal.setitimer(signal.ITIMER_REAL, 150)
    resource.setrlimit(resource.RLIMIT_CPU, (120, 125))
    for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
        os.environ[key] = '1'
    os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
    os.environ['PYTEST_ADDOPTS'] = ''
    os.environ.pop('PYTHONPATH', None)
    sys.dont_write_bytecode = True
    result = {'status': 'FAILED', 'reports': [], 'adamw_updates': 0}
    started = time.perf_counter()
    try:
        import torch
        import pytest
        assert torch.__version__ == '2.10.0+cpu' and pytest.__version__ == '9.0.2'
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        result['runtime'] = {'python': platform.python_version(), 'executable': sys.executable,
            'torch': torch.__version__, 'pytest': pytest.__version__,
            'threads': torch.get_num_threads(), 'interop_threads': torch.get_num_interop_threads(),
            'packages': sorted((item.metadata['Name'], item.version) for item in importlib.metadata.distributions())}
        original_step = torch.optim.AdamW.step
        @functools.wraps(original_step)
        def counted_step(self, *args, **kwargs):
            if result['adamw_updates'] >= 20:
                raise RuntimeError('registered AdamW update bound exceeded')
            result['adamw_updates'] += 1
            return original_step(self, *args, **kwargs)
        torch.optim.AdamW.step = counted_step
        class Observer:
            def pytest_collection_finish(self, session):
                nodeids = [item.nodeid.removeprefix('tests/') for item in session.items]
                (output / 'COLLECTION.json').write_text(json.dumps(nodeids, indent=2) + '\n')
                if sorted(nodeids) != sorted(expected):
                    raise pytest.UsageError('actual nodeid roster differs from the 113 registered cases')
                result['collected'] = len(nodeids)
            def pytest_runtest_logreport(self, report):
                result['reports'].append({'nodeid': report.nodeid.removeprefix('tests/'),
                    'when': report.when, 'outcome': report.outcome,
                    'wasxfail': getattr(report, 'wasxfail', None)})
        os.chdir(ROOT / 'source/qualification/neuron-shared-encoder')
        code = pytest.main(['-vv', '-ra', '-p', 'no:cacheprovider',
                           '--junitxml=' + str(output / 'junit.xml'), 'tests/'], plugins=[Observer()])
        result['pytest_exit_code'] = int(code)
        calls = [r for r in result['reports'] if r['when'] == 'call']
        result['executed_nodeids_match'] = sorted(r['nodeid'] for r in calls) == sorted(expected)
        result['all_source_bytes_unchanged'] = all(sha(ROOT / 'source' / name) == pin['sha256'] for name, pin in pins.items())
        clean = all(r['outcome'] == 'passed' and r['wasxfail'] is None for r in result['reports'])
        if (int(code) == 0 and len(calls) == 113 and result['executed_nodeids_match']
                and result['all_source_bytes_unchanged'] and clean and result['adamw_updates'] == 20):
            result['status'] = 'PASSED_EXACT_ROSTER_CONTRACT'
    except BaseException as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        result.update(wall_s=time.perf_counter() - started, historical_E1_E6_trials_added=0,
                      real_model_intake_calls=0, production_adoption=False,
                      finished_utc=datetime.now(timezone.utc).isoformat())
        (output / 'RESULT.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
        summary = {k: v for k, v in result.items() if k not in ('reports', 'runtime')}
        print(json.dumps(summary), flush=True)
    return 0 if result['status'] == 'PASSED_EXACT_ROSTER_CONTRACT' else 1


if __name__ == '__main__':
    raise SystemExit(main())
