"""Audit retained pytest receipts only; do not import or execute the suite."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'evidence'
PINS = {
    'OOD_02_RESULT.original.json': '49990286864fb5af7b06cf3a156e1dcd7a62ce0b8445d38bff9abef99bbde4e8',
    'OOD_02_COLLECTION.json': 'e511ce409b42daeea9cdf32907c47ec328947c68e2eee682d69918506cb24784',
    'OOD_02_junit.xml': '3f46ae13cf9609673b00a84eddcc884445214acfdf8340d4170c1e98de7636de',
    'OOD_02_ood_contract_02.stdout': '7009072788493e3f19b6038614582b6b3a0a95163e5008741ae9a75f4a40f9be',
    'OOD_02_ood_contract_02.stderr': 'aa0ec6df27c557f19856f947bbfc0e725eafb2dec194fd33b27628405ac1bc19'}


def main():
    started = time.perf_counter()
    raw = {}
    for name, expected in PINS.items():
        raw[name] = (EVIDENCE / name).read_bytes()
        assert hashlib.sha256(raw[name]).hexdigest() == expected, name
    expected_raw = (ROOT / 'ood_candidate/EXPECTED_NODEIDS.txt').read_bytes()
    assert hashlib.sha256(expected_raw).hexdigest() == '148bfb7d28ee4278abe40067a2e41ad4fe18393af4e095f73c68052a6112890b'
    expected = expected_raw.decode().splitlines()
    assert len(expected) == len(set(expected)) == 113
    result = json.loads(raw['OOD_02_RESULT.original.json'])
    assert result['status'] == 'FAILED' and result['pytest_exit_code'] == 0
    assert result['collected'] == 113 and result['all_source_bytes_unchanged'] is True
    assert result['adamw_updates'] == 20 and result['historical_E1_E6_trials_added'] == 0
    assert result['runtime']['torch'] == '2.10.0+cpu' and result['runtime']['pytest'] == '9.0.2'
    collection = json.loads(raw['OOD_02_COLLECTION.json'])
    assert Counter(collection) == Counter(expected)
    reports = result['reports']
    assert len(reports) == 366
    assert all(r['outcome'] == 'passed' and r['wasxfail'] is None for r in reports)
    phase_counts = Counter(r['when'] for r in reports)
    assert phase_counts == {'setup': 113, 'call': 140, 'teardown': 113}
    for phase in ('setup', 'teardown'):
        assert Counter(r['nodeid'] for r in reports if r['when'] == phase) == Counter(expected)
    subtests = {
        'test_harness_receipt_adapter.py::HarnessFlagTypeTests::test_forbidden_flags_reject_non_boolean_values': 21,
        'test_harness_receipt_adapter.py::HarnessFlagTypeTests::test_literal_false_none_and_missing_flags_preserve_receipt': 6}
    calls = Counter(expected)
    calls.update(subtests)
    assert Counter(r['nodeid'] for r in reports if r['when'] == 'call') == calls
    tree = ET.fromstring(raw['OOD_02_junit.xml'])
    suites = tree.findall('.//testsuite')
    assert len(suites) == 1
    assert all(int(suites[0].get(k)) == 0 for k in ('errors', 'failures', 'skipped'))
    assert int(suites[0].get('tests')) == 140
    assert not tree.findall('.//error') and not tree.findall('.//failure') and not tree.findall('.//skipped')
    testcase_ids = []
    for case in tree.findall('.//testcase'):
        parts = case.get('classname').split('.')
        assert parts[0] == 'tests' and parts[1].startswith('test_')
        testcase_ids.append('::'.join([parts[1] + '.py', *parts[2:], case.get('name')]))
    assert Counter(testcase_ids) == Counter(expected)
    text = raw['OOD_02_ood_contract_02.stdout'].decode()
    assert re.search(r'=+ 113 passed, 27 subtests passed in [0-9.]+s =+', text)
    report = {
        'schema': 'hepta.ood.exact-roster-offline-audit.v1',
        'status': 'PASS_RETAINED_CONTRACT_EVIDENCE',
        'original_driver_status': 'FAILED', 'original_driver_receipt_unchanged': True,
        'reason': 'The driver counted 27 successful pytest subtest call reports as extra top-level tests. The predeclared plan counts unittest subTest loops within their original method.',
        'collected_methods': 113, 'junit_testcase_elements': 113, 'junit_tests_attribute': 140,
        'method_roster_matches_collection_junit_and_phase_reports': True,
        'phase_report_counts': dict(phase_counts), 'subtest_counts_by_method': subtests,
        'all_phase_reports_passed_without_xfail': True, 'subtest_parameter_labels_retained': False,
        'subtest_evidence_scope': 'source loop counts, exact parent-node report multiplicity, and raw summary; individual subtest parameter labels were not retained',
        'adamw_updates_in_original_execution': 20, 'source_bytes_unchanged_in_original_execution': True,
        'runtime': result['runtime'], 'raw_evidence_sha256': PINS,
        'audit_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'audit_model_loads': 0, 'audit_test_executions': 0, 'audit_training_updates': 0,
        'wall_s': time.perf_counter() - started, 'audited_utc': datetime.now(timezone.utc).isoformat(),
        'production_adoption': False, 'laya_intake_qualified': False}
    with (EVIDENCE / 'OOD_OFFLINE_AUDIT.json').open('x') as stream:
        json.dump(report, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps({k: report[k] for k in ('status', 'collected_methods', 'junit_testcase_elements', 'junit_tests_attribute', 'phase_report_counts', 'audit_test_executions', 'audit_training_updates', 'wall_s')}))


if __name__ == '__main__':
    main()
