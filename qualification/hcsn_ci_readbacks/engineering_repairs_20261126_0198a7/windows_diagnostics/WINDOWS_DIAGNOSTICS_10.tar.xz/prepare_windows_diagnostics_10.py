"""Prepare only the reviewed Windows diagnostics in an isolated local repository.

Root-owned invocation:
    python3.14 -B prepare_windows_diagnostics_10.py SELF_SHA256 INPUT_SHA256

This runner does not publish, compile, run tests, or qualify Windows.
"""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import stat
import subprocess
import sys
import time
import tomllib
import traceback

ROOT = Path("/Users/qianqi/work/hepta-hcsn-fixes-20261126-0198a7")
BASE = "4ffa56f6d0be94e68d23d1bfe72aa2cbfd50d479"
SCHEMA = "hepta.windows-diagnostics-preparation.v1"
INPUT = ROOT / "WINDOWS10_PREP_INPUT.json"
OUT = ROOT / "windows_candidate_10"
SOURCE = OUT / "source"
EVIDENCE = OUT / "evidence"
YAML = ".github/workflows/bazel.yml"
RUST = "codex-rs/ext/queue/tests/queue_service.rs"
TARGETS = {YAML, RUST}
JUST = "/opt/homebrew/bin/just"
GIT = "/usr/bin/git"
MAX_FILE = 16 * 1024 * 1024
MAX_INPUT_TOTAL = 32 * 1024 * 1024
ADDED_YAML = b"            --local_test_jobs=1\n"
YAML_ANCHOR = ("            --build_metadata=TAG_windows_test_shard=$"
               "{BAZEL_TEST_SHARD}\n").encode()
MARKER_LINES = {
    "import os",
    "marker_pid = os.getpid()",
    'Path(r"{started_path}").write_text(json.dumps({{"pid": marker_pid}}), encoding="utf-8")',
    'Path(r"{input_read_path}").write_text(json.dumps({{"pid": marker_pid, "prompt": payload["prompt"][:256]}}, ensure_ascii=True), encoding="utf-8")',
}
ASSERTS = {"assert", "assert_eq", "assert_ne", "debug_assert", "debug_assert_eq",
           "debug_assert_ne"}
METHODS = {"expect", "expect_err", "unwrap", "unwrap_err"}
PAIRS = {"(": ")", "[": "]", "{": "}"}
GIT_REDIRECT = {
    "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_COMMON_DIR",
    "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_CONFIG", "GIT_CONFIG_COUNT", "GIT_CONFIG_PARAMETERS",
}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def identity(raw):
    return {"bytes": len(raw), "sha256": digest(raw), "git_blob": blob(raw)}


def as_json(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def strict_json(raw):
    def pairs(items):
        answer = {}
        for key, value in items:
            need(key not in answer, "duplicate JSON key")
            answer[key] = value
        return answer

    def invalid_constant(value):
        raise ValueError("nonfinite JSON constant")

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid_constant)


def read_regular(path, maximum=MAX_FILE):
    need(path.is_absolute(), "read path must be absolute")
    for parent in (path.parent, *path.parents):
        need(not parent.is_symlink(), "symlinked input ancestor")
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1,
             "input must be a single-link regular file")
        need(0 <= before.st_size <= maximum, "input size bound")
        raw = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
    keys = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    need(all(getattr(before, key) == getattr(after, key) for key in keys)
         and len(raw) == before.st_size, "input changed while being read")
    return raw


def repo_path(value):
    need(isinstance(value, str) and value and "\\" not in value and "\0" not in value,
         "invalid repository path")
    path = PurePosixPath(value)
    need(not path.is_absolute() and str(path) == value
         and all(part not in {"", ".", "..", ".git"} for part in path.parts),
         "unsafe repository path")
    return value


def root_path(value):
    need(isinstance(value, str) and value and "\0" not in value, "invalid source path")
    path = Path(value)
    if not path.is_absolute():
        path = ROOT / path
    relative = path.relative_to(ROOT)
    need(all(part not in {".", ".."} for part in relative.parts)
         and relative.parts and relative.parts[0] != OUT.name,
         "input must be inside the fixed root and outside the output")
    return path


def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(raw)


def tokens(raw):
    """Lex Rust strings/comments as opaque tokens; never evaluate embedded Python."""
    text = raw.decode("utf-8")
    result, pos = [], 0
    while pos < len(text):
        if text[pos].isspace():
            pos += 1
            continue
        if text.startswith("//", pos):
            end = text.find("\n", pos)
            pos = len(text) if end < 0 else end + 1
            continue
        if text.startswith("/*", pos):
            depth, end = 1, pos + 2
            while depth:
                need(end < len(text), "unterminated Rust block comment")
                if text.startswith("/*", end):
                    depth, end = depth + 1, end + 2
                elif text.startswith("*/", end):
                    depth, end = depth - 1, end + 2
                else:
                    end += 1
            pos = end
            continue
        raw_start = re.match(r'(?:b|c)?r(#{0,255})"', text[pos:])
        if raw_start:
            finish = '"' + raw_start.group(1)
            end = text.find(finish, pos + raw_start.end())
            need(end >= 0, "unterminated Rust raw string")
            end += len(finish)
            result.append(("raw", text[pos:end]))
            pos = end
            continue
        quoted = re.match(r'(?:b|c)?"', text[pos:])
        if quoted:
            end = pos + quoted.end()
            while end < len(text):
                if text[end] == "\\":
                    end += 2
                elif text[end] == '"':
                    end += 1
                    break
                else:
                    end += 1
            else:
                raise ValueError("unterminated Rust quoted string")
            result.append(("string", text[pos:end]))
            pos = end
            continue
        char = re.match(r"(?:b)?'(?:\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.)|[^\\'\r\n])'",
                        text[pos:])
        if char:
            result.append(("char", char.group()))
            pos += char.end()
            continue
        word = re.match(r"(?:[^\W\d]|_)\w*|[0-9][A-Za-z0-9_]*(?:\.[0-9A-Za-z_]+)?",
                        text[pos:])
        if word:
            result.append(("word", word.group()))
            pos += word.end()
            continue
        punct = re.match(r"::|->|=>|==|!=|<=|>=|&&|\|\||\.\.=|\.\.|\S", text[pos:])
        need(punct is not None, "unrecognized Rust token")
        result.append(("punct", punct.group()))
        pos += punct.end()
    return result


def group_end(values, start):
    need(values[start] in PAIRS, "expected Rust group")
    stack = [PAIRS[values[start]]]
    for index in range(start + 1, len(values)):
        token = values[index]
        if token in PAIRS:
            stack.append(PAIRS[token])
        elif token in PAIRS.values():
            need(token == stack.pop(), "mismatched Rust delimiter")
            if not stack:
                return index
    raise ValueError("unterminated Rust group")


def critical_calls(lexed):
    values = [text for _, text in lexed]
    answer = []
    for index, (kind, token) in enumerate(lexed):
        if kind != "word":
            continue
        opening, name = None, None
        if (token == "Duration" and values[index + 1:index + 2] == ["::"]
                and index + 3 < len(values) and values[index + 3] == "("):
            opening, name = index + 3, "Duration::" + values[index + 2]
        elif (token in ASSERTS and values[index + 1:index + 2] == ["!"]
              and index + 2 < len(values) and values[index + 2] in PAIRS):
            opening, name = index + 2, token + "!"
        elif (token in METHODS and index > 0 and values[index - 1] == "."
              and values[index + 1:index + 2] == ["("]):
            opening, name = index + 1, "." + token
        elif (token == "wait_for_path" and index > 0 and values[index - 1] != "fn"
              and values[index + 1:index + 2] == ["("]):
            opening, name = index + 1, token
        if opening is not None:
            end = group_end(values, opening)
            answer.append({"name": name, "tokens": lexed[index:end + 1]})
    return answer


def wait_definition(lexed):
    values = [text for _, text in lexed]
    matches = []
    for index in range(len(values) - 1):
        if values[index:index + 2] == ["fn", "wait_for_path"]:
            start = index - 1 if index and values[index - 1] == "async" else index
            opening = values.index("{", index + 2)
            matches.append(lexed[start:group_end(values, opening) + 1])
    need(len(matches) == 1, "expected one original wait_for_path definition")
    return matches[0]


def raw_fixture_gate(original, candidate):
    old = [text for kind, text in original if kind == "raw"]
    new = [text for kind, text in candidate if kind == "raw"]
    need(len(old) == len(new), "raw-string denominator changed")
    changed = []
    for index, (before, after) in enumerate(zip(old, new)):
        if before == after:
            continue
        lines = after.splitlines(keepends=True)
        counts = Counter(line.rstrip("\r\n") for line in lines
                         if line.rstrip("\r\n") in MARKER_LINES)
        need(dict(counts) == {line: 1 for line in MARKER_LINES},
             "fixture diagnostics are not the four reviewed V2 lines")
        restored = "".join(line for line in lines if line.rstrip("\r\n") not in MARKER_LINES)
        need(restored == before, "original Python business/entered condition changed")
        changed.append(index)
    need(len(changed) == 2, "expected exactly two V2 Python marker fixtures")
    return {"raw_literals": len(old), "changed_fixtures": changed,
            "original_python_bytes_restored_by_four_line_removal": True}


def normalize_format_tokens(lexed):
    """Allow only rustfmt's optional diagnostic call commas/closure expression braces."""
    output = list(lexed)
    removable_commas = {"format", "queue_hook_timeout_context"}
    changed = True
    while changed:
        changed = False
        values = [text for _, text in output]
        for index, (kind, text) in enumerate(output):
            opening = None
            if kind == "word" and text in removable_commas:
                if text == "format" and values[index + 1:index + 3] == ["!", "("]:
                    opening = index + 2
                elif text == "queue_hook_timeout_context" and values[index + 1:index + 2] == ["("]:
                    opening = index + 1
            if opening is not None:
                end = group_end(values, opening)
                if values[end - 1] == ",":
                    del output[end - 1]
                    changed = True
                    break
            if text == "||" and values[index + 1:index + 2] == ["{"]:
                end = group_end(values, index + 1)
                expression = values[index + 2:end]
                if (expression[:2] == ["queue_hook_timeout_context", "("]
                        and group_end(expression, 1) == len(expression) - 1):
                    del output[end]
                    del output[index + 1]
                    changed = True
                    break
    return output


def rust_gate(original, candidate):
    old, new = tokens(original), tokens(candidate)
    calls_old, calls_new = critical_calls(old), critical_calls(new)
    need(calls_old == calls_new, "ordered Duration/assert/expect/unwrap/wait calls changed")
    need(wait_definition(old) == wait_definition(new), "original wait_for_path changed")
    fixtures = raw_fixture_gate(old, new)
    return {"critical_call_count": len(calls_old),
            "critical_counts": dict(sorted(Counter(x["name"] for x in calls_old).items())),
            "critical_calls_sha256": digest(as_json(calls_old)),
            "original_wait_for_path_preserved": True, **fixtures}


def yaml_gate(original, candidate):
    need(original.count(YAML_ANCHOR) == 1 and original.count(ADDED_YAML) == 0,
         "original Windows shard insertion anchor")
    need(candidate == original.replace(YAML_ANCHOR, ADDED_YAML + YAML_ANCHOR, 1),
         "YAML differs beyond the one reviewed local_test_jobs line")
    return {"added_line": "--local_test_jobs=1", "only_reviewed_line_added": True}


def tree_snapshot():
    answer = {}
    for current, directories, filenames in os.walk(SOURCE, followlinks=False):
        current = Path(current)
        if current == SOURCE:
            directories[:] = [name for name in directories if name != ".git"]
        need(all(not (current / name).is_symlink() for name in directories),
             "symlink appeared in isolated source")
        for name in filenames:
            path = current / name
            answer[str(path.relative_to(SOURCE))] = identity(read_regular(path))
    return answer


def main():
    need(len(sys.argv) == 3 and all(re.fullmatch("[0-9a-f]{64}", x) for x in sys.argv[1:]),
         "expected SELF_SHA256 INPUT_SHA256")
    self_path = Path(__file__).absolute()
    need(self_path.parent == ROOT and digest(read_regular(self_path)) == sys.argv[1],
         "runner location/self identity")
    OUT.mkdir(exist_ok=False)
    SOURCE.mkdir()
    EVIDENCE.mkdir()
    result = {
        "schema": SCHEMA, "base_commit": BASE, "status": "STARTED",
        "runner_sha256": sys.argv[1], "input_sha256": sys.argv[2],
        "tests": 0, "models": 0, "optimizer_calls": 0, "compilations": 0,
        "github_writes": 0, "windows_qualification": False,
        "commands": [], "input_files_before": {}, "input_files_after": {},
        "formatter_invocations": 0,
    }
    started, error = time.monotonic(), None
    inputs, originals, candidates, baseline = {}, {}, {}, None

    def bound(path, expected=None):
        raw = read_regular(path)
        record = identity(raw)
        if expected is not None:
            need(record["sha256"] == expected, "input SHA differs: " + path.name)
        previous = inputs.setdefault(str(path), record)
        need(record == previous, "input identity changed: " + path.name)
        need(sum(row["bytes"] for row in inputs.values()) <= MAX_INPUT_TOTAL,
             "input total byte bound")
        return raw

    def progress():
        temp = EVIDENCE / "PROGRESS.tmp"
        temp.write_bytes(as_json(result))
        os.replace(temp, EVIDENCE / "PROGRESS.json")

    def command(name, argv, timeout, env, cwd=SOURCE):
        need((argv[0] == GIT or argv == [JUST, "fmt"]) and cwd in {SOURCE, SOURCE / "codex-rs"},
             "unregistered preparation command")
        row = {"name": name, "argv": argv, "cwd": str(cwd), "timeout_s": timeout,
               "status": "INTENT", "returncode": None}
        result["commands"].append(row)
        progress()
        stdout, stderr = EVIDENCE / (name + ".stdout"), EVIDENCE / (name + ".stderr")
        child, begin = None, time.monotonic()
        try:
            with stdout.open("xb") as output, stderr.open("xb") as errors:
                child = subprocess.Popen(argv, cwd=cwd, env=env, stdout=output,
                                         stderr=errors, start_new_session=True)
                row.update(status="RUNNING", child_pid=child.pid)
                progress()
                try:
                    child.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    if child.poll() is None:
                        try:
                            os.killpg(child.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                    child.wait(timeout=10)
                    raise
            row.update(status="RETURNED", returncode=child.returncode)
        except BaseException as failure:
            if child is not None and child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait(timeout=10)
            row.update(status="FAILED_RETAINED", returncode=None if child is None else child.returncode,
                       error_type=type(failure).__name__, error=str(failure))
        finally:
            row["wall_s"] = time.monotonic() - begin
            for name_, path in (("stdout", stdout), ("stderr", stderr)):
                if path.exists():
                    row[name_] = {"path": str(path), **identity(read_regular(path))}
            progress()
        return row, stdout

    try:
        bound(self_path, sys.argv[1])
        document = strict_json(bound(INPUT, sys.argv[2]))
        need(document.get("schema") == SCHEMA and document.get("base_commit") == BASE,
             "preparation schema or fixed base")
        need(document.get("expected_scaffold_files") == 51
             and document.get("expected_formatter_guard_files") == 44
             and document.get("scientific_and_production_hold_unchanged") is True,
             "fixed scaffold/guard denominator and HOLD scope")
        reviews = document.get("review_paths")
        need(isinstance(reviews, list) and len(reviews) == 2, "two retained review records")
        result["retained_reviews"] = []
        for review in reviews:
            review_path = root_path(review["path"])
            review_raw = bound(review_path, review["sha256"])
            result["retained_reviews"].append({"path": str(review_path), **identity(review_raw)})
        need(sys.version_info[:2] == (3, 14), "preparation requires Python 3.14/tomllib")
        result["python"] = sys.version
        result["python_executable"] = sys.executable
        parts = document.get("scaffold_parts")
        need(isinstance(parts, list) and 1 <= len(parts) <= 64, "scaffold part denominator")
        joined = []
        for index, part in enumerate(parts):
            need(part.get("name") == "WINDOWS10_SCAFFOLD.part" + str(index).zfill(3),
                 "scaffold ordered part name")
            raw = bound(ROOT / part["name"], part["sha256"])
            need(type(part.get("bytes")) is int and len(raw) == part["bytes"],
                 "scaffold part length")
            joined.append(raw)
        scaffold_raw = b"".join(joined)
        result["scaffold_joined"] = identity(scaffold_raw)
        scaffold = strict_json(scaffold_raw)
        need(scaffold.get("base_commit") == BASE and isinstance(scaffold.get("files"), dict),
             "scaffold fixed base/files")
        files = scaffold["files"]
        need(len(files) == document["expected_scaffold_files"] == 51
             and not TARGETS.intersection(files), "scaffold denominator or source collision")
        baseline_bytes = {}
        for path, entry in files.items():
            path = repo_path(path)
            need(isinstance(entry, dict) and isinstance(entry.get("content"), str),
                 "scaffold text entry")
            raw = entry["content"].encode("utf-8")
            need(blob(raw) == entry.get("git_blob"), "scaffold Git blob: " + path)
            if "expected_sha256" in entry:
                need(digest(raw) == entry["expected_sha256"], "scaffold SHA: " + path)
            if "expected_bytes" in entry:
                need(type(entry["expected_bytes"]) is int and len(raw) == entry["expected_bytes"],
                     "scaffold bytes: " + path)
            baseline_bytes[path] = raw
        sources = document.get("source_files")
        need(isinstance(sources, list) and len(sources) == 2
             and {row.get("repo_path") for row in sources} == TARGETS,
             "exactly the two reviewed sources are required")
        for row in sources:
            path = repo_path(row["repo_path"])
            original = bound(root_path(row["original_path"]), row["original_sha256"])
            candidate = bound(root_path(row["candidate_path"]), row["candidate_sha256"])
            need(blob(original) == row["original_git_blob"], "original source Git blob")
            originals[path], candidates[path], baseline_bytes[path] = original, candidate, original
        result["reviewed_originals"] = {p: identity(raw) for p, raw in originals.items()}
        result["candidates_before_format"] = {p: identity(raw) for p, raw in candidates.items()}
        result["candidate_yaml_gate"] = yaml_gate(originals[YAML], candidates[YAML])
        result["candidate_rust_gate"] = rust_gate(originals[RUST], candidates[RUST])
        toolchains = [p for p in ("codex-rs/rust-toolchain.toml", "rust-toolchain.toml")
                      if p in baseline_bytes]
        need(toolchains, "fixed scaffold lacks the active Rust toolchain file")
        active_toolchain = toolchains[0]
        channel = tomllib.loads(baseline_bytes[active_toolchain].decode())["toolchain"]["channel"]
        need(channel in {"1.96", "1.96.0"}, "original toolchain must be Rust 1.96")
        result["toolchain"] = {"path": active_toolchain, "channel": channel,
                               **identity(baseline_bytes[active_toolchain])}
        need(not any(os.environ.get(key) for key in ("RUSTUP_TOOLCHAIN", "RUSTFMT")),
             "environment overrides the frozen toolchain or rustfmt")
        need(not any(os.environ.get(key) for key in GIT_REDIRECT),
             "inherited Git redirection would leave the isolated workspace")
        fmt_env = dict(os.environ)
        fmt_env["PATH"] = "/opt/homebrew/bin:" + os.environ.get("PATH", "")
        python3 = shutil.which("python3", path=fmt_env["PATH"])
        need(python3 and Path(python3).resolve() == Path(sys.executable).resolve(),
             "formatter python3 must resolve to this Python 3.14")
        result["formatter_python3"] = python3
        git_env = {key: value for key, value in fmt_env.items() if not key.startswith("GIT_")}
        git_env.update(GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL="/dev/null",
                       GIT_AUTHOR_NAME="workflow-test", GIT_AUTHOR_EMAIL="workflow-test@hepta.invalid",
                       GIT_COMMITTER_NAME="workflow-test", GIT_COMMITTER_EMAIL="workflow-test@hepta.invalid")
        for path, raw in baseline_bytes.items():
            write_new(SOURCE / path, raw)
        baseline = {path: identity(raw) for path, raw in baseline_bytes.items()}
        need(tree_snapshot() == baseline, "materialized baseline differs from original bytes")
        result["baseline_files"] = baseline
        result["scaffold_files"] = len(files)
        git_prefix = [GIT, "-c", "core.hooksPath=/dev/null", "-c", "core.autocrlf=false",
                      "-c", "commit.gpgsign=false", "-c", "core.attributesFile=/dev/null"]
        operations = [
            ("01-git-init", ["init", "--template=", "--initial-branch=windows-format-baseline"]),
            ("02-git-add", ["add", "--force", "--all", "--", "."]),
            ("03-git-baseline", ["commit", "--no-gpg-sign", "-m",
                                "Local formatting baseline from reviewed 4ffa sources"]),
        ]
        for name, args in operations:
            row, _ = command(name, git_prefix + args, 30, git_env)
            need(row["status"] == "RETURNED" and row["returncode"] == 0, name + " failed")
        row, output = command("04-git-index", git_prefix + ["ls-files", "--stage", "-z"], 30, git_env)
        need(row["status"] == "RETURNED" and row["returncode"] == 0, "local baseline index read")
        index = {}
        for entry in read_regular(output).split(b"\0"):
            if not entry:
                continue
            header, path = entry.split(b"\t", 1)
            mode, object_id, stage = header.decode().split()
            need(mode == "100644" and stage == "0", "unexpected local baseline index entry")
            index[path.decode()] = object_id
        need(index == {p: row["git_blob"] for p, row in baseline.items()},
             "local baseline Git objects differ from admitted raw bytes")
        row, output = command("05-git-head", git_prefix + ["rev-parse", "HEAD"], 30, git_env)
        local_head = read_regular(output).decode().strip()
        need(row["returncode"] == 0 and re.fullmatch("[0-9a-f]{40}", local_head),
             "local baseline commit identity")
        result["local_baseline_commit"] = local_head
        result["local_baseline_is_original_repository_commit"] = False
        for path, raw in candidates.items():
            (SOURCE / path).write_bytes(raw)
        expected_before = dict(baseline)
        expected_before.update({path: identity(raw) for path, raw in candidates.items()})
        need(tree_snapshot() == expected_before, "candidate materialization changed other files")
        result["workspace_before_format"] = expected_before
        progress()
        result["formatter_invocations"] = 1
        fmt, _ = command("06-just-fmt", [JUST, "fmt"], 600, fmt_env, SOURCE / "codex-rs")
        result["formatter"] = fmt
        after = tree_snapshot()
        result["workspace_after_format"] = after
        result["candidates_after_format"] = {path: after.get(path) for path in TARGETS}
        diff, output = command("07-git-diff", git_prefix + [
            "diff", "--binary", "--no-ext-diff", "--no-textconv", "--no-color", "HEAD", "--"
        ], 30, git_env)
        write_new(EVIDENCE / "DIFF.patch", read_regular(output))
        result["diff_patch"] = identity(read_regular(EVIDENCE / "DIFF.patch"))
        need(diff["returncode"] == 0, "could not preserve the local diff")
        need(set(after) == set(baseline), "formatter changed the source file denominator")
        other_changes = [path for path in baseline if path not in TARGETS
                         and baseline[path] != after[path]]
        result["other_baseline_changes"] = other_changes
        need(not other_changes, "formatter changed a noncandidate baseline file")
        formatted = {path: read_regular(SOURCE / path) for path in TARGETS}
        result["formatted_yaml_gate"] = yaml_gate(originals[YAML], formatted[YAML])
        result["formatted_rust_gate"] = rust_gate(originals[RUST], formatted[RUST])
        before_tokens = normalize_format_tokens(tokens(candidates[RUST]))
        after_tokens = normalize_format_tokens(tokens(formatted[RUST]))
        need(before_tokens == after_tokens, "formatter changed nonformat Rust tokens")
        result["rust_format_tokens_preserved"] = True
        need(fmt["status"] == "RETURNED" and fmt["returncode"] == 0, "fixed just fmt failed")
        result["status"] = "FORMATTED_REVIEW_REQUIRED_NO_WINDOWS_QUALIFICATION"
    except BaseException as failure:
        error = failure
        result.update(status="FAILED_RETAINED", error_type=type(failure).__name__, error=str(failure))
        write_new(EVIDENCE / "TRACEBACK.txt", traceback.format_exc().encode())
    finally:
        result["input_files_before"] = inputs
        try:
            after = {path: identity(read_regular(Path(path))) for path in inputs}
            result["input_files_after"] = after
            result["all_original_inputs_unchanged"] = bool(inputs) and after == inputs
            if not result["all_original_inputs_unchanged"]:
                result.update(status="FAILED_RETAINED", input_error="input identity changed")
        except BaseException as failure:
            result.update(status="FAILED_RETAINED", all_original_inputs_unchanged=False,
                          input_error=type(failure).__name__ + ": " + str(failure))
        result["wall_s"] = time.monotonic() - started
        result["retries"] = 0
        progress()
        write_new(EVIDENCE / "VALIDATION.json", as_json(result))
        ready = {
            "schema": SCHEMA, "status": result["status"], "base_commit": BASE,
            "runner_sha256": sys.argv[1], "input_sha256": sys.argv[2],
            "validation": {"path": str(EVIDENCE / "VALIDATION.json"),
                           **identity(read_regular(EVIDENCE / "VALIDATION.json"))},
            "windows_qualification": False, "tests": 0, "models": 0,
            "optimizer_calls": 0, "compilations": 0, "github_writes": 0,
            "formatted_source_files": [],
        }
        if result["status"] == "FORMATTED_REVIEW_REQUIRED_NO_WINDOWS_QUALIFICATION":
            ready["formatted_source_files"] = [
                {"repo_path": path, "path": str(SOURCE / path),
                 **result["candidates_after_format"][path]} for path in sorted(TARGETS)
            ]
        write_new(EVIDENCE / "READY.json", as_json(ready))
    print(json.dumps({"status": result["status"], "ready": str(EVIDENCE / "READY.json"),
                      "tests": 0, "models": 0, "windows_qualification": False}, sort_keys=True),
          flush=True)
    return 0 if result["status"] == "FORMATTED_REVIEW_REQUIRED_NO_WINDOWS_QUALIFICATION" else 1


if __name__ == "__main__":
    raise SystemExit(main())

