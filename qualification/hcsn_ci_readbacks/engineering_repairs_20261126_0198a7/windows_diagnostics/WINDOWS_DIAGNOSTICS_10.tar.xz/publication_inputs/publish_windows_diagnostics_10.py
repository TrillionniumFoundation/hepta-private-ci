"""Publish one formatted, unqualified Windows diagnostics branch; never update refs.

Root-owned invocation:
    python3.14 -B publish_windows_diagnostics_10.py SELF_SHA256 INPUT_SHA256

All input paths are explicit. Every API mutation has one transport attempt.
An uncertain write is retained for read-only reconciliation, never resent.
"""
import base64
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import signal
import stat
import subprocess
import sys
import tarfile
import time
import traceback

ROOT = Path("/Users/qianqi/work/hepta-hcsn-fixes-20261126-0198a7")
OUT = ROOT / "publication_10"
INPUT = ROOT / "WINDOWS10_PUBLICATION_INPUT.json"
GH = "/opt/homebrew/bin/gh"
REPO = "TrillionniumFoundation/hepta-private-ci"
API = "repos/" + REPO
ACCOUNT = "ProfHepta"
BASE = "4ffa56f6d0be94e68d23d1bfe72aa2cbfd50d479"
BRANCH = "fix/windows-ci-diagnostics-20261126-0198a7"
REF = "refs/heads/" + BRANCH
DEST = "qualification/hcsn_ci_readbacks/engineering_repairs_20261126_0198a7/windows_diagnostics/"
YAML = ".github/workflows/bazel.yml"
RUST = "codex-rs/ext/queue/tests/queue_service.rs"
TARGETS = {YAML, RUST}
SCHEMA = "hepta.windows-diagnostics-publication.v1"
PREPARED = "FORMATTED_REVIEW_REQUIRED_NO_WINDOWS_QUALIFICATION"
PUBLISHED = "FORMATTED_SOURCE_CANDIDATE_PUBLISHED_WINDOWS_UNVERIFIED"
ZERO_FIELDS = ("tests", "models", "optimizer_calls", "compilations", "github_writes")
MAX_FILE = 32 * 1024 * 1024
MAX_TOTAL = 64 * 1024 * 1024
PART_BYTES = 450000
ARCHIVE_NAME = "WINDOWS_DIAGNOSTICS_10.tar.xz"
HEX40 = re.compile("[0-9a-f]{40}")
HEX64 = re.compile("[0-9a-f]{64}")


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git_blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def identity(raw):
    return {"bytes": len(raw), "sha256": sha(raw), "git_blob": git_blob(raw)}


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False)
            + "\n").encode("utf-8")


def strict_json(raw):
    def pairs(items):
        answer = {}
        for key, value in items:
            need(key not in answer, "duplicate JSON key")
            answer[key] = value
        return answer

    def invalid_constant(value):
        raise ValueError("nonfinite JSON constant")

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid_constant)


def safe_relative(value):
    need(isinstance(value, str) and value and "\\" not in value and "\0" not in value,
         "invalid relative path")
    path = PurePosixPath(value)
    need(path.parts and not path.is_absolute() and str(path) == value
         and all(part not in {".", "..", ".git"} for part in path.parts),
         "unsafe relative path")
    return value


def input_path(value):
    need(isinstance(value, str) and value, "missing input path")
    path = Path(value)
    need(path.is_absolute(), "publication inputs must be absolute")
    relative = path.relative_to(ROOT)
    need(relative.parts and all(p not in {".", ".."} for p in relative.parts)
         and relative.parts[0] != OUT.name, "input is outside the allowed root")
    return path


def read_regular(path, maximum=MAX_FILE):
    for parent in path.parents:
        need(not parent.is_symlink(), "symlinked input ancestor")
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(descriptor, "rb") as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
             and 0 <= before.st_size <= maximum, "input must be a bounded single-link regular file")
        raw = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
    keys = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    need(len(raw) == before.st_size
         and all(getattr(before, k) == getattr(after, k) for k in keys), "input changed during read")
    return raw


def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(raw)


def tree_sha(entries):
    names, chunks = set(), []
    ordered = sorted(entries, key=lambda x: (x["path"] + ("/" if x["type"] == "tree" else "")).encode())
    for item in ordered:
        name = item["path"]
        need(isinstance(name, str) and name and "/" not in name and "\0" not in name
             and name not in {".", ".."} and name not in names, "invalid Git tree entry")
        need(item["mode"] in {"100644", "100755", "120000", "160000", "040000"}
             and HEX40.fullmatch(item["sha"]) is not None, "Git tree mode/object identity")
        need((item["mode"] == "040000" and item["type"] == "tree")
             or (item["mode"] == "160000" and item["type"] == "commit")
             or (item["mode"] in {"100644", "100755", "120000"} and item["type"] == "blob"),
             "Git tree mode/type mismatch")
        names.add(name)
        chunks.append(item["mode"].lstrip("0").encode() + b" " + name.encode()
                      + b"\0" + bytes.fromhex(item["sha"]))
    raw = b"".join(chunks)
    return hashlib.sha1(b"tree " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def http_json(raw):
    split = re.search(rb"\r?\n\r?\n", raw[:65540])
    need(split is not None and split.end() <= 65536, "incomplete API response header")
    first = raw[:split.start()].splitlines()[0].decode("ascii")
    match = re.fullmatch(r"HTTP/\d(?:\.\d)?[ \t]+([0-9]{3})(?:[ \t]+.*)?", first)
    need(match is not None, "invalid API status line")
    return int(match.group(1)), strict_json(raw[split.end():])


def main():
    need(len(sys.argv) == 3 and all(HEX64.fullmatch(x) for x in sys.argv[1:]),
         "expected SELF_SHA256 and INPUT_SHA256")
    self_path = Path(__file__).absolute()
    self_raw = read_regular(self_path)
    need(self_path.parent == ROOT and sha(self_raw) == sys.argv[1], "fixed runner/self SHA")
    OUT.mkdir(exist_ok=False)
    state = {
        "schema": SCHEMA, "status": "STARTED", "base_commit": BASE, "branch": BRANCH,
        "runner_sha256": sys.argv[1], "input_sha256": sys.argv[2],
        "operations": [], "branch_creation_attempts": 0, "publication_observed": False,
        "new_tests": 0, "new_models": 0, "new_optimizer_calls": 0, "new_compilations": 0,
        "pr_creations": 0, "manual_ci_dispatches": 0, "existing_ref_updates": 0,
        "scientific_and_production_hold_unchanged": True, "windows_qualification": False,
        "write_transport_retries": 0, "max_read_transport_attempts": 2,
        "termination_requested": False,
    }
    begin = time.monotonic()
    cache, read_inputs, input_bytes, published_files = {}, {}, {}, {}
    env = dict(os.environ)
    env["PATH"] = "/opt/homebrew/bin:" + env.get("PATH", "")
    previous_handlers = {}

    def save():
        temp = OUT / "STATE.tmp"
        temp.write_bytes(encoded(state))
        os.replace(temp, OUT / "STATE.json")

    def interrupt(signum, frame):
        state["termination_requested"] = True
        raise RuntimeError("publisher received a termination signal")

    def record_input(path, raw):
        name, row = str(path), identity(raw)
        need(name not in read_inputs or read_inputs[name] == row, "input identity changed")
        read_inputs[name], input_bytes[name] = row, raw

    def ensure_inputs():
        after = {name: identity(read_regular(Path(name))) for name in read_inputs}
        need(after == read_inputs, "a retained input changed during publication")
        state["input_files_after"] = after
        state["all_input_files_unchanged"] = True
        save()

    def registered(path):
        name = str(input_path(path))
        need(name in input_bytes, "referenced file is not in explicit raw_files: " + name)
        return input_bytes[name]

    def allowed_api(method, endpoint):
        if method == "POST":
            return endpoint in {API + "/git/blobs", API + "/git/trees",
                                API + "/git/commits", API + "/git/refs"}
        if method != "GET":
            return False
        if endpoint in {"user", API + "/git/ref/heads/" + BRANCH}:
            return True
        return re.fullmatch(re.escape(API) + r"/git/(?:blobs|trees|commits)/[0-9a-f]{40}", endpoint) is not None or re.fullmatch(
            re.escape(API) + r"/commits/[0-9a-f]{40}\?per_page=100", endpoint) is not None

    def call_api(label, endpoint, body=None, fresh=False, absent_ok=False):
        need(not state["termination_requested"], "publisher termination prevents a new request")
        method = "GET" if body is None else "POST"
        need(allowed_api(method, endpoint), "API endpoint/method outside publication allowlist")
        body_raw = b"" if body is None else encoded(body)
        request_sha = sha(method.encode() + b"\0" + endpoint.encode() + b"\0" + body_raw)
        if not fresh and request_sha in cache:
            prior = cache[request_sha]
            raw = read_regular(OUT / prior["stdout"])
            need(sha(raw) == prior["stdout_sha256"], "cached API response changed")
            status, value = http_json(raw)
            need(200 <= status < 300 or (absent_ok and status == 404), "cached API status")
            return status, value
        number = len(state["operations"])
        stem = str(number).zfill(4) + "-" + label
        need(re.fullmatch(r"[0-9A-Za-z_.-]+", stem), "invalid operation label")
        operation = {"label": label, "method": method, "endpoint": endpoint,
                     "request_sha256": request_sha, "status": "INTENT", "attempts": []}
        state["operations"].append(operation)
        write_new(OUT / (stem + ".request.json"), encoded({
            "method": method, "endpoint": endpoint, "body_sha256": sha(body_raw),
            "request_sha256": request_sha, "body_present": body is not None,
        }))
        payload = None
        if body is not None:
            payload = OUT / (stem + ".body.json")
            write_new(payload, body_raw)
        save()
        failure_text = "API operation did not complete"
        for attempt in range(1 if method == "POST" else 2):
            name = stem + "-" + str(attempt)
            stdout, stderr = OUT / (name + ".stdout"), OUT / (name + ".stderr")
            row = {"attempt": attempt, "status": "INTENT",
                   "stdout": stdout.name, "stderr": stderr.name}
            operation["attempts"].append(row)
            save()
            argv = [GH, "api", "--hostname", "github.com", "--include", "--method", method, endpoint]
            if payload is not None:
                argv.extend(["--input", str(payload)])
            child, started, failure = None, time.monotonic(), None
            try:
                with stdout.open("xb") as output, stderr.open("xb") as errors:
                    child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=output,
                                             stderr=errors, start_new_session=True)
                    row.update(status="RUNNING", child_pid=child.pid)
                    save()
                    child.wait(timeout=90)
            except BaseException as error:
                failure = error
                if child is not None and child.poll() is None:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    child.wait(timeout=10)
                row.update(status="FAILED_RETAINED", error_type=type(error).__name__,
                           error=str(error))
            finally:
                row["wall_s"] = time.monotonic() - started
                row["returncode"] = None if child is None else child.returncode
                for prefix, path in (("stdout", stdout), ("stderr", stderr)):
                    if path.exists():
                        raw = read_regular(path)
                        row[prefix + "_bytes"] = len(raw)
                        row[prefix + "_sha256"] = sha(raw)
                save()
            try:
                status, value = http_json(read_regular(stdout))
                row["http_status"] = status
                ok = failure is None and row["returncode"] == 0 and 200 <= status < 300
                missing = (failure is None and method == "GET" and absent_ok and status == 404
                           and isinstance(value, dict) and value.get("message") == "Not Found")
                if ok or missing:
                    row["status"] = "RETURNED_ABSENT" if missing else "RETURNED_SUCCESS"
                    operation["status"] = row["status"]
                    operation["response"] = row
                    cache[request_sha] = row
                    save()
                    return status, value
                failure_text = label + ": HTTP " + str(status) + ", exit " + str(row["returncode"])
            except (ValueError, UnicodeDecodeError, OSError) as error:
                failure_text = label + ": response cannot be bound: " + type(error).__name__
            operation["status"] = "UNKNOWN_WRITE_RETAINED" if method == "POST" else "READ_FAILED_RETAINED"
            row["status"] = operation["status"]
            save()
            if method == "POST" or (failure is not None and not isinstance(failure, subprocess.TimeoutExpired)):
                break
            if row.get("http_status") in {400, 401, 403, 404, 409, 422}:
                break
        raise RuntimeError(failure_text + "; no mutation was retried")

    def get_tree(object_id):
        need(HEX40.fullmatch(object_id) is not None, "tree object syntax")
        _, value = call_api("tree-read-" + object_id, API + "/git/trees/" + object_id)
        need(value.get("sha") == object_id and value.get("truncated") is False
             and isinstance(value.get("tree"), list)
             and tree_sha(value["tree"]) == object_id, "remote tree SHA mismatch")
        return {item["path"]: {k: item[k] for k in ("path", "mode", "type", "sha")}
                for item in value["tree"]}

    def lookup(root_tree, path):
        parts = safe_relative(path).split("/")
        current = root_tree
        for index, part in enumerate(parts):
            entry = get_tree(current).get(part)
            if entry is None:
                return None
            if index == len(parts) - 1:
                return entry
            need(entry["type"] == "tree", "non-directory in remote path")
            current = entry["sha"]
        raise ValueError("empty lookup")

    def get_blob(object_id):
        _, value = call_api("blob-read-" + object_id, API + "/git/blobs/" + object_id)
        need(value.get("sha") == object_id and value.get("encoding") == "base64",
             "remote blob response identity")
        raw = base64.b64decode("".join(value["content"].split()), validate=True)
        need(len(raw) == value.get("size") and git_blob(raw) == object_id,
             "remote blob bytes/hash mismatch")
        return raw

    try:
        for signum in (signal.SIGTERM, signal.SIGINT):
            previous_handlers[signum] = signal.getsignal(signum)
            signal.signal(signum, interrupt)
        record_input(self_path, self_raw)
        raw = read_regular(INPUT)
        need(sha(raw) == sys.argv[2], "publication input SHA")
        record_input(INPUT, raw)
        plan = strict_json(raw)
        for key, expected in {"schema": SCHEMA, "base_commit": BASE, "branch": BRANCH,
                              "repository": REPO, "account": ACCOUNT, "hold_unchanged": True}.items():
            need(plan.get(key) == expected, "publication input scope mismatch: " + key)
        rows = plan.get("raw_files")
        need(isinstance(rows, list) and 1 <= len(rows) <= 512, "explicit raw-file denominator")
        archive_payload, total = {}, 0
        raw_paths = set()
        for row in rows:
            path = input_path(row["path"])
            member = safe_relative(row["archive_member"])
            need(str(path) not in raw_paths and member not in archive_payload
                 and path not in {INPUT, self_path}, "duplicate or self-referential raw input")
            need(type(row.get("bytes")) is int and HEX64.fullmatch(row["sha256"]) is not None,
                 "raw-file metadata syntax")
            raw = read_regular(path)
            need(len(raw) == row["bytes"] and sha(raw) == row["sha256"], "explicit raw input mismatch")
            total += len(raw)
            need(total <= MAX_TOTAL, "retained input total byte cap")
            record_input(path, raw)
            raw_paths.add(str(path))
            archive_payload[member] = raw
        ready = strict_json(registered(plan["ready_path"]))
        validation = strict_json(registered(plan["validation_path"]))
        prep = strict_json(registered(plan["preparation_input_path"]))
        need(ready.get("status") == validation.get("status") == PREPARED
             and ready.get("base_commit") == validation.get("base_commit") == prep.get("base_commit") == BASE,
             "formatted source admission/base")
        need(ready.get("schema") == validation.get("schema") == prep.get("schema")
             == "hepta.windows-diagnostics-preparation.v1", "preparation schema")
        for document in (ready, validation):
            need(all(type(document.get(key)) is int and document[key] == 0 for key in ZERO_FIELDS)
                 and document.get("windows_qualification") is False, "preparation execution scope")
        need(ready["validation"]["path"] == plan["validation_path"]
             and identity(registered(plan["validation_path"])) ==
             {k: ready["validation"][k] for k in ("bytes", "sha256", "git_blob")},
             "READY does not bind exact VALIDATION")
        need(sha(registered(plan["preparation_input_path"])) == ready["input_sha256"] == validation["input_sha256"]
             and sha(registered(plan["preparation_runner_path"])) == ready["runner_sha256"] == validation["runner_sha256"],
             "preparation runner/input binding")
        need(validation.get("all_original_inputs_unchanged") is True
             and validation.get("input_files_before") == validation.get("input_files_after"),
             "preparation original input custody")
        for path, expected in validation["input_files_before"].items():
            need(identity(registered(path)) == expected, "preparation input no longer matches")
        baseline = validation["baseline_files"]
        before, after = validation["workspace_before_format"], validation["workspace_after_format"]
        need(len(baseline) == len(before) == len(after) == 53
             and set(baseline) == set(before) == set(after)
             and validation.get("scaffold_files") == prep.get("expected_scaffold_files") == 51
             and prep.get("expected_formatter_guard_files") == 44
             and validation.get("other_baseline_changes") == [], "formatter scaffold/guard denominator")
        workspace = ROOT / "windows_candidate_10" / "source"
        for path, expected in after.items():
            safe_relative(path)
            need(identity(registered(str(workspace / path))) == expected, "current formatted workspace changed")
            if path not in TARGETS:
                need(expected == before[path] == baseline[path], "a baseline/guard source changed")
        need(validation.get("rust_format_tokens_preserved") is True
             and validation["candidate_rust_gate"] == validation["formatted_rust_gate"]
             and validation["formatted_rust_gate"]["original_wait_for_path_preserved"] is True
             and validation["formatted_rust_gate"]["original_python_bytes_restored_by_four_line_removal"] is True
             and len(validation["formatted_rust_gate"]["changed_fixtures"]) == 2
             and validation["formatted_yaml_gate"]["only_reviewed_line_added"] is True,
             "formatted semantic/candidate gates")
        fmt = validation["formatter"]
        commands = validation["commands"]
        names = ["01-git-init", "02-git-add", "03-git-baseline", "04-git-index",
                 "05-git-head", "06-just-fmt", "07-git-diff"]
        need([row["name"] for row in commands] == names
             and all(row["status"] == "RETURNED" and row["returncode"] == 0 for row in commands)
             and fmt == commands[5] and fmt["argv"] == ["/opt/homebrew/bin/just", "fmt"]
             and fmt["cwd"] == str(workspace / "codex-rs")
             and validation.get("formatter_invocations") == 1
             and validation["toolchain"]["channel"] == "1.96.0", "fixed official formatter execution")
        for command in commands:
            for stream in ("stdout", "stderr"):
                row = command[stream]
                need(identity(registered(row["path"])) ==
                     {k: row[k] for k in ("bytes", "sha256", "git_blob")}, "formatter command stream changed")
        diff_path = str(ROOT / "windows_candidate_10/evidence/DIFF.patch")
        need(identity(registered(diff_path)) == validation["diff_patch"], "formatted source diff changed")
        source_rows = plan.get("source_files")
        need(isinstance(source_rows, list) and len(source_rows) == 2
             and {row.get("repo_path") for row in source_rows} == TARGETS, "two source publications only")
        ready_sources = {row["repo_path"]: row for row in ready["formatted_source_files"]}
        need(set(ready_sources) == TARGETS, "READY source denominator")
        originals, formatted = {}, {}
        for row in source_rows:
            path = row["repo_path"]
            original, value = registered(row["original_path"]), registered(row["formatted_path"])
            record = ready_sources[path]
            need(row["formatted_path"] == record["path"] == str(workspace / path)
                 and identity(value) == {k: record[k] for k in ("bytes", "sha256", "git_blob")}
                 == validation["candidates_after_format"][path] == after[path],
                 "formatted source identity")
            need(git_blob(original) == row["original_git_blob"]
                 and identity(original) == validation["reviewed_originals"][path] == baseline[path],
                 "original source identity")
            originals[path], formatted[path] = original, value
        state["input_files_before"] = read_inputs
        state["raw_input_count"], state["raw_input_bytes"] = len(rows), total
        state["formatted_sources"] = {path: identity(value) for path, value in formatted.items()}
        state["original_sources"] = {path: identity(value) for path, value in originals.items()}
        state["preparation_ready_sha256"] = sha(registered(plan["ready_path"]))
        state["preparation_validation_sha256"] = sha(registered(plan["validation_path"]))
        save()

        readme = """# Windows CI 诊断源码候选

本目录与同一提交中的两处源码构成一个已格式化、等待独立 Windows 验证的候选。
它没有取得 Windows 功能资格，也没有闭合整仓科学或生产门。

## 固定来源与修改范围

- 父提交固定为 4ffa56f6d0be94e68d23d1bfe72aa2cbfd50d479。
- 独立分支为 fix/windows-ci-diagnostics-20261126-0198a7；不更新 #6799 或其他分支。
- 原失败记录来自 run 45794035631 / job 139821215079；它不是“最新 head”的测试结论。
- 修改仅涉及 .github/workflows/bazel.yml 和 codex-rs/ext/queue/tests/queue_service.rs。
- Windows shard 新增 --local_test_jobs=1，只限制并行 test actions；
  libtest 线程数、构建并行度、4 个 shards 与原目标选择保持不变。
- Rust 增加有限的失败上下文及 Python fixture 标志，保留原成功条件与业务代码。
- 原 1 秒 / 500 毫秒 / 10 秒 / 20 秒期限、断言、expect_err、wait_for_path、
  entered 条件以及 JobObject / fsync 生产守卫保持原有定义；没有放宽通过判据。

## 诊断局限

每个 marker 最多读取 512 字节，两文件合计最多 1024 字节。
marker 可能陈旧或截断，记录的 pid / prompt 不能证明它属于当前调用。
新增标志写入与失败时读取会增加 I/O，可能影响时序；该候选尚未证明消除原失败。
owner_start.is_finished 仅提供失败时的观察值，不构成新的成功门。

## 已完成的准备

- 原 formatter / manifest / toolchain 与 44 份守卫原件共 51 份逐字节恢复。
- 在独立本地仓库保留原件 baseline 后，一次执行官方 just fmt，返回码为 0。
- 本地准备有 6 个 Git 命令和 1 个 formatter 入口；这不是 formatter 内部子进程总数。
- Rust 216 项关键调用序列、原 wait_for_path 及 raw Python 业务片段通过保留门。
- 两处 Python raw fixtures 删除各自四行新增诊断后，与原业务字节完全一致。
- formatter 前后守卫及其他 baseline 文件未变，原输入前后身份一致。
- 编译、测试、模型、optimizer 均为 0；发布器不创建 PR、不手动 dispatch CI。
- 分支创建后若仓库自动运行 CI，其资格须按实际 head / run 另行读取记录。

## 原件恢复

INDEX.json 给出真实 tar.xz 归档的完整 SHA256、字节数与 ordered_parts。
严格按该顺序连接分片，核对完整归档身份后再读取归档中的 MANIFEST.json。
归档完整保留显式输入清单、原失败日志、原源码与历史候选、formatter scaffold、
审阅记录、格式化原始 stdout / stderr、DIFF、READY / VALIDATION 和准备 / 发布脚本。
manifest 逐项列出成员字节数与 SHA256；读取与打包没有执行归档中的任何内容。
完整大清单保存在归档内，Git 正文只保留本说明与精简索引。
"""
        readme_raw = readme.encode("utf-8")
        generated = {
            "publication_inputs/WINDOWS10_PUBLICATION_INPUT.json": input_bytes[str(INPUT)],
            "publication_inputs/publish_windows_diagnostics_10.py": self_raw,
            "publication_inputs/README_ZH.md": readme_raw,
        }
        need(not set(generated).intersection(archive_payload) and "MANIFEST.json" not in archive_payload,
             "reserved archive member collision")
        archive_payload.update(generated)
        names_sorted = sorted(archive_payload)
        need(not any(b.startswith(a + "/") for a, b in zip(names_sorted, names_sorted[1:])),
             "archive file/directory collision")
        manifest = {
            "schema": "hepta.windows-diagnostics-archive-manifest.v1",
            "base_commit": BASE, "branch": BRANCH,
            "manifest_excludes_itself": True, "member_count_excluding_manifest": len(archive_payload),
            "members": {name: identity(raw) for name, raw in sorted(archive_payload.items())},
            "archived_code_executions": 0,
        }
        manifest_raw = encoded(manifest)
        archive_payload["MANIFEST.json"] = manifest_raw
        complete_names = sorted(archive_payload)
        need(not any(b.startswith(a + "/") for a, b in zip(complete_names, complete_names[1:])),
             "manifest introduces an archive path collision")
        archive_path = OUT / ARCHIVE_NAME
        with tarfile.open(archive_path, "x:xz", format=tarfile.PAX_FORMAT, preset=6) as archive:
            for name, raw in sorted(archive_payload.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                archive.addfile(info, io.BytesIO(raw))
        archive_raw = read_regular(archive_path)
        need(archive_raw.startswith(b"\xfd7zXZ\x00"), "archive is not an actual XZ stream")
        with tarfile.open(fileobj=io.BytesIO(archive_raw), mode="r:xz") as archive:
            members = archive.getmembers()
            need(len(members) == len(archive_payload)
                 and len({item.name for item in members}) == len(members)
                 and {item.name for item in members} == set(archive_payload),
                 "tar archive member denominator")
            for item in members:
                need(item.isfile() and not item.issym() and not item.islnk()
                     and item.name == safe_relative(item.name)
                     and item.size == len(archive_payload[item.name]), "unsafe or changed tar member")
                stream = archive.extractfile(item)
                need(stream is not None and stream.read() == archive_payload[item.name],
                     "tar member bytes differ from manifest-bound input")
        parts = []
        for index, offset in enumerate(range(0, len(archive_raw), PART_BYTES)):
            name = ARCHIVE_NAME if len(archive_raw) <= PART_BYTES else ARCHIVE_NAME + ".part" + str(index).zfill(3)
            raw = archive_raw[offset:offset + PART_BYTES]
            write_new(OUT / "files" / DEST / name, raw)
            published_files[DEST + name] = raw
            parts.append({"path": name, "bytes": len(raw), "sha256": sha(raw)})
        need(b"".join(published_files[DEST + row["path"]] for row in parts) == archive_raw,
             "archive ordered-part reconstruction differs")
        index = {
            "schema": "hepta.windows-diagnostics-archive-index.v1",
            "status": "FORMATTED_SOURCE_CANDIDATE_WINDOWS_UNVERIFIED",
            "base_commit": BASE, "branch": BRANCH,
            "archive_name": ARCHIVE_NAME, "archive_bytes": len(archive_raw),
            "archive_sha256": sha(archive_raw), "ordered_parts": parts,
            "archive_member_count": len(archive_payload), "raw_input_count": len(rows),
            "manifest": {"path": "MANIFEST.json", **identity(manifest_raw)},
            "formatted_sources": state["formatted_sources"],
            "original_sources": state["original_sources"],
            "ready_sha256": state["preparation_ready_sha256"],
            "validation_sha256": state["preparation_validation_sha256"],
            "formatter_returncode": 0, "formatter_invocations": 1,
            "tests": 0, "compilations": 0, "models": 0, "optimizer_calls": 0,
            "windows_qualification": False, "scientific_and_production_hold_unchanged": True,
        }
        for path, raw in {**formatted, DEST + "INDEX.json": encoded(index),
                          DEST + "README_ZH.md": readme_raw}.items():
            write_new(OUT / "files" / path, raw)
            published_files[path] = raw
        need(len(published_files) <= 100, "single commit diff page bound")
        state["published_file_plan"] = {path: identity(raw) for path, raw in published_files.items()}
        state["archive"] = index
        state["status"] = "PREPARED_FOR_SINGLE_BRANCH_PUBLICATION"
        ensure_inputs()

        _, user = call_api("account", "user", fresh=True)
        need(user.get("login") == ACCOUNT and type(user.get("id")) is int and user["id"] > 0,
             "active gh account is not ProfHepta")
        state["actor"] = {"login": user["login"], "id": user["id"]}
        _, parent = call_api("base-commit", API + "/git/commits/" + BASE)
        need(parent.get("sha") == BASE and HEX40.fullmatch(parent["tree"]["sha"]) is not None,
             "fixed remote parent identity")
        base_tree = parent["tree"]["sha"]
        get_tree(base_tree)
        for path, original in originals.items():
            entry = lookup(base_tree, path)
            need(entry is not None and entry["type"] == "blob" and entry["mode"] == "100644"
                 and entry["sha"] == git_blob(original)
                 and get_blob(entry["sha"]) == original, "remote original source differs from fixed parent")
        for path in published_files:
            if path not in TARGETS:
                need(lookup(base_tree, path) is None, "immutable evidence path already exists")
        status, _ = call_api("branch-absent-before-objects", API + "/git/ref/heads/" + BRANCH,
                             fresh=True, absent_ok=True)
        need(status == 404, "target branch already exists; no ref may be updated")
        changes = {}
        for path, raw in sorted(published_files.items()):
            _, created = call_api("blob-create-" + git_blob(raw), API + "/git/blobs",
                                  {"encoding": "base64", "content": base64.b64encode(raw).decode("ascii")})
            need(created.get("sha") == git_blob(raw), "created blob SHA mismatch")
            node = changes
            components = path.split("/")
            for component in components[:-1]:
                node = node.setdefault(component, {})
            node[components[-1]] = {"_leaf": git_blob(raw)}

        def make_tree(base, changed, prefix=""):
            old = {} if base is None else get_tree(base)
            combined = dict(old)
            updates = []
            for name, child in sorted(changed.items()):
                path = prefix + name
                if "_leaf" in child:
                    if path in TARGETS:
                        need(name in old and old[name]["sha"] == git_blob(originals[path]),
                             "original changed during tree construction")
                    else:
                        need(name not in old, "new evidence would replace a parent entry")
                    entry = {"path": name, "mode": "100644", "type": "blob", "sha": child["_leaf"]}
                else:
                    entry_before = old.get(name)
                    need(entry_before is None or entry_before["type"] == "tree", "tree collision")
                    subtree = make_tree(None if entry_before is None else entry_before["sha"],
                                        child, path + "/")
                    entry = {"path": name, "mode": "040000", "type": "tree", "sha": subtree}
                combined[name] = entry
                updates.append(entry)
            expected = tree_sha(list(combined.values()))
            body = {"tree": updates}
            if base is not None:
                body["base_tree"] = base
            _, value = call_api("tree-create-" + expected, API + "/git/trees", body)
            need(value.get("sha") == expected and get_tree(expected) == combined,
                 "created Git tree differs from locally recomputed tree")
            return expected

        tree = make_tree(base_tree, changes)
        state["candidate_tree"] = tree
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        author = {"name": ACCOUNT, "email": str(user["id"]) + "+" + ACCOUNT + "@users.noreply.github.com",
                  "date": now}
        message = "Prepare Windows CI action scheduling and bounded queue diagnostics"
        _, commit = call_api("candidate-commit", API + "/git/commits", {
            "tree": tree, "parents": [BASE], "message": message, "author": author, "committer": author,
        })
        commit_id = commit.get("sha", "")
        need(HEX40.fullmatch(commit_id) is not None, "candidate commit SHA")
        _, remote_commit = call_api("candidate-commit-readback", API + "/git/commits/" + commit_id)
        for value in (commit, remote_commit):
            need(value.get("sha") == commit_id and value["tree"]["sha"] == tree
                 and [parent["sha"] for parent in value["parents"]] == [BASE]
                 and value["message"].rstrip("\n") == message, "candidate commit parent/tree/message")
        state["candidate_commit"] = commit_id
        _, diff = call_api("candidate-diff", API + "/commits/" + commit_id + "?per_page=100")
        need(diff.get("sha") == commit_id and [p["sha"] for p in diff["parents"]] == [BASE]
             and isinstance(diff.get("files"), list)
             and len(diff["files"]) == len(published_files), "candidate diff denominator/parent")
        actual_files = {row["filename"]: row for row in diff["files"]}
        need(set(actual_files) == set(published_files)
             and all(actual_files[path]["sha"] == git_blob(raw) for path, raw in published_files.items()),
             "candidate diff includes unregistered paths or bytes")
        need(all(row["status"] == ("modified" if path in TARGETS else "added")
                 for path, row in actual_files.items()), "candidate diff status")
        stats = diff["stats"]
        need(all(type(stats.get(k)) is int and stats[k] >= 0 for k in ("total", "additions", "deletions"))
             and stats["total"] == stats["additions"] + stats["deletions"] < 800
             and sum(row["additions"] for row in diff["files"]) == stats["additions"]
             and sum(row["deletions"] for row in diff["files"]) == stats["deletions"],
             "commit must have a verified complete diff below 800 changed lines")
        state["diff_stats"] = stats
        state["diff_paths"] = sorted(actual_files)
        state["status"] = "CANDIDATE_OBJECTS_VERIFIED_REF_NOT_CREATED"
        ensure_inputs()
        status, _ = call_api("branch-absent-before-create", API + "/git/ref/heads/" + BRANCH,
                             fresh=True, absent_ok=True)
        need(status == 404, "target branch appeared; refusing any update")
        state["branch_creation_attempts"] = 1
        state["status"] = "BRANCH_CREATE_INTENT"
        save()
        creation_error = None
        try:
            _, created = call_api("branch-create-once", API + "/git/refs",
                                  {"ref": REF, "sha": commit_id})
            need(created.get("ref") == REF and created["object"]["type"] == "commit"
                 and created["object"]["sha"] == commit_id, "created ref response differs")
        except Exception as error:
            creation_error = type(error).__name__ + ": " + str(error)
            state["branch_create_error_retained"] = creation_error
            save()
        _, observed = call_api("branch-create-readonly-reconciliation",
                               API + "/git/ref/heads/" + BRANCH, fresh=True)
        need(observed.get("ref") == REF and observed["object"]["type"] == "commit"
             and observed["object"]["sha"] == commit_id, "created branch is not the exact candidate commit")
        state["publication_observed"] = True
        state["branch_create_reconciled_after_error"] = creation_error is not None
        state["remote_readback"] = {}
        for path, expected in sorted(published_files.items()):
            entry = lookup(tree, path)
            need(entry is not None and entry["type"] == "blob" and entry["mode"] == "100644"
                 and entry["sha"] == git_blob(expected), "published path tree binding differs")
            remote = get_blob(entry["sha"])
            need(remote == expected, "published remote bytes differ")
            state["remote_readback"][path] = identity(remote)
            save()
        ensure_inputs()
        state["status"] = PUBLISHED
        save()
    except BaseException as error:
        state.update(status="STOPPED_FOR_RECONCILIATION", error_type=type(error).__name__, error=str(error))
        write_new(OUT / "TRACEBACK.txt", traceback.format_exc().encode())
        save()
    finally:
        try:
            ensure_inputs()
        except BaseException as error:
            state.update(status="STOPPED_FOR_RECONCILIATION", all_input_files_unchanged=False,
                         input_error=type(error).__name__ + ": " + str(error))
        state["wall_s"] = time.monotonic() - begin
        save()
        write_new(OUT / "RESULT.json", encoded(state))
        for signum, handler in previous_handlers.items():
            signal.signal(signum, handler)
    print(json.dumps({
        "status": state["status"], "branch": BRANCH, "commit": state.get("candidate_commit"),
        "tree": state.get("candidate_tree"), "stats": state.get("diff_stats"),
        "publication_observed": state["publication_observed"],
        "branch_creation_attempts": state["branch_creation_attempts"],
        "new_tests": 0, "new_models": 0, "windows_qualification": False,
    }, sort_keys=True), flush=True)
    return 0 if state["status"] == PUBLISHED else 1


if __name__ == "__main__":
    raise SystemExit(main())

