"""Publish exact hosted metadata sources and a CTRL history-depth correction.

Root-owned main invocation:
    python3.14 -B publish_hosted_ctrl_13_02.py SELF_SHA256 INPUT_SHA256

The SHA-bound helper is loaded under a non-main namespace. Only its pure
definitions and bounded Git-data publisher are used. No retained preparation,
metadata validator, model, test, formatter, compiler, or workflow is executed.
"""
import base64
from datetime import datetime, timezone
import hashlib
import io
import os
from pathlib import Path
import re
import stat
import sys
import tarfile
import time
import traceback
import types

ROOT = Path("/Users/qianqi/work/hepta-hcsn-fixes-20261126-0198a7")
OUT = ROOT / "publication_13_02"
INPUT = ROOT / "HOSTED_CTRL13_PUBLICATION_INPUT.json"
HELPER = ROOT / "publish_vendor_whitespace_12.py"
SOURCE = ROOT / "hosted_ctrl_candidate_13/source"
EVIDENCE = ROOT / "hosted_ctrl_candidate_13/evidence"
REPO = "TrillionniumFoundation/hepta-private-ci"
API = "repos/" + REPO
ACCOUNT = "ProfHepta"
BASE = "6ca37caad90259aaad76c89d4f6a5a64715ab041"
CARRY_SOURCE = "32153753a33a86a30d5d38a53483146c66161acd"
BRANCH = "fix/hosted-source-carryforward-20261126-0198a7"
REF = "refs/heads/" + BRANCH
COMMON = "qualification/hcsn_ci_readbacks/engineering_repairs_20261126_0198a7/"
PROFILE = COMMON + "n256_host_profile/"
DEST = COMMON + "hosted_ctrl_source_carryforward/"
CTRL = ".github/workflows/ctrl-dependency-proposal.yml"
WORKFLOW = ".github/workflows/hepta-hcsn-n256-host-metadata-20261126.yml"
ADDED = {WORKFLOW} | {PROFILE + name for name in (
    "LEGACY_SOURCE.index.json", "LEGACY_SOURCE.tar.xz", "PROFILE.json", "README.md",
    "SOURCE_FREEZE.json", "requirements.txt", "run_profile.py")}
TARGETS = ADDED | {CTRL}
ARCHIVE_NAME = "HOSTED_CTRL13_PREPARATION.tar.xz"
SCHEMA = "hepta.hosted-ctrl-source-publication.v1"
PREPARED = "FORMATTED_EXACT_BYTES_READY_NO_EXECUTION_QUALIFICATION"
PUBLISHED = "SOURCE_CARRYFORWARD_PUBLISHED_NO_NEW_EXECUTION_QUALIFICATION"
MAX_WALL, MAX_HTTP, MAX_SLEEP = 900, 128, 312
DELAYS = (0, 2, 4, 8, 16, 16, 16, 16)
ZERO = ("tests", "models", "optimizer_calls", "compilations", "host_validator_calls",
        "metadata_observations", "github_writes", "ci_dispatches")
PINS = {
    "input": (38763, "75146631c8b75cd7bdc0dc4b383dad043e4baf4933397e7c0c3d0648ba467052"),
    "helper": (41524, "162b5687247840084351973e44ca156655cc0946564081c087de63c7e2de532c"),
    "candidates": (213437, "f853a3cb8c12bb8968f4e0a6728581e67bce5444b57e0892d818ec587bf51fba"),
    "ready": (5418, "5b47138263594a48ea775932e6d045febb55e03906d933379d72115214d56f3e"),
    "validation": (115079, "7decab0ad92643291869e7eec3a6ccf39b42d84a0db7766e120beb6ef57baaf9"),
    "preparer": (24262, "b965ad6d0e947e93828df578d9b2023013635872b894f5113a2ff217157e31e5"),
}
FIXED = {
    "candidates_input_path": ROOT / "HOSTED_CTRL13_CANDIDATES.json",
    "ready_path": EVIDENCE / "READY.json",
    "validation_path": EVIDENCE / "VALIDATION.json",
    "preparation_runner_path": ROOT / "prepare_hosted_ctrl_13.py",
}


def bootstrap_read(path):
    for parent in path.parents:
        if parent.is_symlink():
            raise ValueError("symlinked source ancestor")
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > 65536:
            raise ValueError("publisher/helper must be bounded single-link regular files")
        raw = stream.read(65537)
        after = os.fstat(stream.fileno())
    if len(raw) != before.st_size or any(getattr(before, key) != getattr(after, key)
          for key in ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")):
        raise ValueError("source changed during bootstrap read")
    return raw


def load_helper():
    raw = bootstrap_read(HELPER)
    if (len(raw), hashlib.sha256(raw).hexdigest()) != PINS["helper"]:
        raise ValueError("frozen helper identity mismatch")
    namespace = {"__name__": "_hepta_hosted_ctrl13_02_frozen_helpers", "__file__": str(HELPER)}
    exec(compile(raw, str(HELPER), "exec"), namespace)
    namespace.update(ROOT=ROOT, OUT=OUT, INPUT=INPUT, SOURCE=SOURCE, EVIDENCE=EVIDENCE,
        REPO=REPO, API=API, ACCOUNT=ACCOUNT, BASE=BASE, PREPARATION_BASE=BASE,
        BRANCH=BRANCH, REF=REF, DEST=DEST, MAX_WALL=MAX_WALL, MAX_HTTP=MAX_HTTP,
        MAX_VISIBILITY_SLEEP=MAX_SLEEP, VISIBILITY_DELAYS=DELAYS)
    return types.SimpleNamespace(**namespace), raw


def validate(h, state, own_raw, helper_raw):
    need, ident = h.need, h.identity
    input_raw = h.read_regular(INPUT)
    h.pinned(input_raw, PINS["input"])
    need(h.sha(input_raw) == sys.argv[2], "fixed INPUT argument")
    spec = h.strict_json(input_raw)
    for key, expected in {"schema": SCHEMA, "repository": REPO, "account": ACCOUNT,
            "publication_base": BASE, "preparation_base": BASE, "branch": BRANCH,
            "hold_unchanged": True}.items():
        need(spec.get(key) == expected, "publication input scope: " + key)
    for key, path in FIXED.items():
        need(h.input_path(spec[key]) == path, "fixed preparation path mismatch")
    rows = spec["raw_files"]
    need(isinstance(rows, list) and len(rows) == 90, "raw input denominator")
    raw_by_path, members, custody = {}, {}, {}
    for row in rows:
        need(set(row) == {"path", "archive_member", "bytes", "sha256"}, "raw row schema")
        path = h.input_path(row["path"])
        member = h.safe_relative(row["archive_member"])
        need(member == "retained/" + path.relative_to(ROOT).as_posix(),
             "archive member must identify its actual retained path")
        need(str(path) not in raw_by_path and member not in members
             and path not in {INPUT, HELPER, ROOT / "publish_hosted_ctrl_13_02.py"},
             "duplicate/self raw input")
        raw = h.read_regular(path)
        custody[str(path)] = h.check_identity(raw, row)
        raw_by_path[str(path)], members[member] = raw, raw
    need(sum(map(len, raw_by_path.values())) == 3067885, "exact raw byte denominator")
    for key, pin in (("candidates_input_path", "candidates"), ("ready_path", "ready"),
                     ("validation_path", "validation"), ("preparation_runner_path", "preparer")):
        h.pinned(raw_by_path[spec[key]], PINS[pin])
    candidate = h.strict_json(raw_by_path[spec["candidates_input_path"]])
    ready = h.strict_json(raw_by_path[spec["ready_path"]])
    valid = h.strict_json(raw_by_path[spec["validation_path"]])
    need(candidate["schema"] == "hepta.hosted-ctrl-source-candidates.v1", "candidate schema")
    for document in (candidate, ready, valid):
        need(document["publication_base"] == document["preparation_base"] == BASE
             and document["branch"] == BRANCH, "source/preparation base or branch drift")
    for document in (ready, valid):
        need(document["schema"] == "hepta.hosted-ctrl-source-preparation.v1"
             and document["status"] == PREPARED and document["qualification_gained"] is False,
             "successful source-only preparation required")
        need(all(type(document[k]) is int and document[k] == 0 for k in ZERO),
             "unexpected preparation execution")
        need(document["input_sha256"] == PINS["candidates"][1]
             and document["runner_sha256"] == PINS["preparer"][1], "preparation source pins")
    need(ready["validation"]["path"] == spec["validation_path"], "READY validation path")
    h.check_identity(raw_by_path[spec["validation_path"]], ready["validation"])
    need(valid["input_files_before"] == valid["input_files_after"]
         and len(valid["input_files_before"]) == 9
         and valid["all_original_inputs_unchanged"] is True, "retained inputs drift")
    need(valid["workspace_before_format"] == valid["workspace_after_format"]
         == valid["workspace_final"] and len(valid["workspace_final"]) == 60
         and len(valid["baseline_files"]) == 52, "prepared workspace drift/count")
    need(valid["formatter_guards_before"] == valid["formatter_guards_after"]
         == candidate["scaffold"]["formatter_guards"]
         and len(valid["formatter_guards_before"]) == 44, "44 original guards drift")
    need(valid["attempts"] == valid["formatter_invocations"] == 1
         and valid["automatic_retry"] is False and valid["toolchain"] == "1.96.0"
         and valid["source_verifier_calls"] == 0
         and valid["scientific_and_production_hold_unchanged"] is True,
         "preparation invocation/scope mismatch")
    need(all(valid[k] is False for k in ("all_closed", "production_adoption",
         "runtime_admitted", "resource_admitted")), "preparation cannot grant admission")
    expected_raw = set(valid["input_files_before"])
    for path, expected in valid["input_files_before"].items():
        h.check_identity(raw_by_path[path], expected)
    for relative, expected in valid["workspace_final"].items():
        path = str(SOURCE / h.safe_relative(relative))
        expected_raw.add(path)
        h.check_identity(raw_by_path[path], expected)
    names = ("01-git-init", "02-git-add", "03-git-baseline", "04-git-index",
             "05-git-head", "06-git-intent", "07-just-fmt",
             "08-git-diff-check", "09-git-diff")
    need(tuple(row["name"] for row in valid["commands"]) == names, "nine original commands")
    for command in valid["commands"]:
        need(command["status"] == "RETURNED" and command["returncode"] == 0,
             "failed original preparation command")
        for stream in ("stdout", "stderr"):
            row = command[stream]
            expected_raw.add(row["path"])
            h.check_identity(raw_by_path[row["path"]], row)
    fmt = valid["commands"][6]
    need(fmt["argv"] == ["/opt/homebrew/bin/just", "fmt"]
         and fmt["cwd"] == str(SOURCE / "codex-rs"), "official formatter command")
    need(raw_by_path[fmt["stdout"]["path"]] ==
         b"No changed files need formatting. Use --all for a full repository check.\n"
         and fmt["stderr"]["bytes"] == 0, "preserve actual no-op formatter result")
    need(all(valid["commands"][7][s]["bytes"] == 0 for s in ("stdout", "stderr")),
         "scoped diff --check was not silent")
    diff_path = str(EVIDENCE / "DIFF.patch")
    expected_raw |= {spec["ready_path"], spec["validation_path"], diff_path}
    need(set(raw_by_path) == expected_raw and len(expected_raw) == 90, "complete raw closure")
    h.check_identity(raw_by_path[diff_path], valid["diff_patch"])
    need(raw_by_path[diff_path] == raw_by_path[valid["commands"][8]["stdout"]["path"]],
         "original diff stream identity")
    changes = {row["repo_path"]: row for row in candidate["changes"]}
    prepared = {row["repo_path"]: row for row in ready["formatted_source_files"]}
    need(len(changes) == len(candidate["changes"]) == len(prepared) == 9
         and set(changes) == set(prepared) == TARGETS
         and ready["formatted_source_files"] == valid["formatted_source_files"],
         "exact nine prepared changes")
    files, originals = {}, {}
    for path in sorted(TARGETS):
        row, result = changes[path], prepared[path]
        need(row["source_mode"] == "100644" and result["path"] == str(SOURCE / path),
             "source mode/path mismatch")
        old = base64.b64decode(row["original"]["data_base64"], validate=True)
        raw = base64.b64decode(row["candidate"]["data_base64"], validate=True)
        h.check_identity(old, row["original"])
        h.check_identity(raw, row["candidate"])
        h.check_identity(raw, result)
        need(raw_by_path[result["path"]] == raw, "prepared source bytes changed")
        files[path], originals[path] = raw, old
        if path in ADDED:
            need(row["status"] == "added" and row["source_commit"] == CARRY_SOURCE
                 and row["destination_before"] is None and old == raw
                 and path not in valid["baseline_files"], "321 exact-byte source inheritance")
        else:
            need(row["status"] == "modified" and row["source_commit"] == BASE
                 and valid["baseline_files"][path] == ident(old), "CTRL original binding")
            needle = b"fetch-depth: 16\n"
            need(old.count(needle) == 1 and raw == old.replace(needle, b"fetch-depth: 0\n"),
                 "CTRL may change only fetch depth 16 to 0")
    for path, expected in valid["baseline_files"].items():
        if path != CTRL:
            need(valid["workspace_final"][path] == expected, "baseline/guard byte drift")
    capsule = files[PROFILE + "LEGACY_SOURCE.tar.xz"]
    h.pinned(capsule, (18964, "ce615707b677173cfd9ab8c9cdd80d8486218263860b2c26e3f2b675f78537c5"))
    # Do not decompress or execute the preserved legacy capsule or run_profile.py.
    for path, raw, member in (
            (ROOT / "publish_hosted_ctrl_13_02.py", own_raw, "publication/PUBLISHER.py"),
            (INPUT, input_raw, "publication/INPUT.json"),
            (HELPER, helper_raw, "publication/FROZEN_HELPER.py")):
        need(str(path) not in custody and member not in members, "publisher custody collision")
        custody[str(path)], members[member] = ident(raw), raw
    need(len(members) == 93, "90 raw plus SELF/INPUT/HELPER")
    state["inputs_before"] = custody
    state["preparation"] = {
        "status": PREPARED, "ready": ident(raw_by_path[spec["ready_path"]]),
        "validation": ident(raw_by_path[spec["validation_path"]]),
        "preparation_wall_s": valid["wall_s"], "formatter_wall_s": fmt["wall_s"],
        "formatter_stdout": "No changed files need formatting.",
        "retained_raw_files": 90, "workspace_files": 60, "formatter_guards": 44,
        "preparation_commands": 9, "tests": 0, "models": 0, "optimizer_calls": 0,
        "metadata_observations": 0, "host_validator_calls": 0}
    return files, originals, members, candidate["agent_instructions"]


def evidence(h, state, members, files):
    names = set(members)
    h.need("MANIFEST.json" not in names and all(not any(
        parent.as_posix() in names for parent in h.PurePosixPath(name).parents
        if parent.as_posix() != ".") for name in names), "archive path collision")
    manifest = h.encoded({"schema": "hepta.retained-byte-archive.v1",
        "manifest_excludes_itself": True,
        "files": {name: h.identity(raw) for name, raw in sorted(members.items())}})
    packed = members | {"MANIFEST.json": manifest}
    h.need(len(packed) == 94, "exact archive member denominator")
    output = io.BytesIO()
    state["archive_pack_attempts"] = 1
    with tarfile.open(fileobj=output, mode="w:xz", format=tarfile.PAX_FORMAT, preset=6) as archive:
        for name, raw in sorted(packed.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            archive.addfile(info, io.BytesIO(raw))
    compressed = output.getvalue()
    h.write_new(OUT / "generated" / ARCHIVE_NAME, compressed)
    state["archive"] = h.identity(compressed) | {
        "members": len(packed), "manifest_sha256": h.sha(manifest)}
    h.need(compressed.startswith(b"\xfd7zXZ\x00") and len(compressed) <= 450000,
           "single archive size limit; retain this archive, never repack")
    with tarfile.open(fileobj=io.BytesIO(compressed), mode="r:xz") as archive:
        seen = set()
        for row in archive.getmembers():
            h.need(row.isfile() and row.name in packed and row.name not in seen
                   and row.size == len(packed[row.name]), "archive member inventory")
            seen.add(row.name)
            h.need(archive.extractfile(row).read() == packed[row.name], "archive bytes readback")
        h.need(seen == set(packed), "archive completeness")
    index = {
        "schema": "hepta.hosted-ctrl-source-publication-index.v1",
        "publication_base": BASE, "preparation_base": BASE, "carry_source": CARRY_SOURCE,
        "branch": BRANCH, "preparation_status": PREPARED,
        "raw_files": 90, "archive_members": 94, "ordered_parts": [ARCHIVE_NAME],
        "archive": {"path": ARCHIVE_NAME, **state["archive"]},
        "extra_members": ["publication/PUBLISHER.py", "publication/INPUT.json",
                          "publication/FROZEN_HELPER.py", "MANIFEST.json"],
        "source_paths": sorted(files), "prepared_source_additions": 463,
        "prepared_source_deletions": 1, "binary_source_files": 1,
        "ready_sha256": PINS["ready"][1], "validation_sha256": PINS["validation"][1],
        "helper_sha256": PINS["helper"][1],
        "new_metadata_observations": 0, "new_host_validator_calls": 0,
        "new_tests": 0, "new_models": 0, "new_optimizer_calls": 0,
        "ctrl_fixed_source_qualification": False, "n256_numerical_qualification": False,
        "runtime_admitted": False, "resource_admitted": False, "production_adoption": False,
        "scientific_and_production_hold_unchanged": True}
    readme = (
        "# Hosted source carry-forward and CTRL history visibility\n\n"
        "This branch uses fixed source/preparation base " + BASE + ".\n"
        "It carries eight files byte-for-byte from " + CARRY_SOURCE + " and changes only\n"
        "CTRL checkout fetch-depth from 16 to 0. No source guard, whitelist, workflow\n"
        "trigger, Python version, old source freeze, or prior result is relaxed.\n\n"
        "## Evidence retained from the one preparation\n\n"
        "The nine registered preparation commands returned zero. Official just fmt\n"
        "reported no changed files needing formatting; this is not a claim that it\n"
        "parsed every copied Python or YAML file. The nine-path git diff --check passed.\n"
        "All 9 bound inputs, 60 workspace files and 44 formatter guards kept exact bytes.\n"
        "Preparation wall seconds: " + str(state["preparation"]["preparation_wall_s"]) + ".\n"
        "Formatter wall seconds: " + str(state["preparation"]["formatter_wall_s"]) + ".\n"
        "The original scoped diff is +463/-1 text lines and one unchanged binary source.\n"
        "This publisher runs zero formatters, tests, compilers, models or optimizers.\n\n"
        "## Existing metadata evidence, not a new observation\n\n"
        "Run 45786899259 attempt 1, job 139795831557, succeeded at source 32153753.\n"
        "Original artifact 15100974608 has 28,989 bytes and SHA256\n"
        "881930596a525c4fa5e6f073f1dfeaed02cf8bebb56c8f10478d0425f2505b36.\n"
        "Its original result SHA256 is\n"
        "96fdf513c6be0297180de2320b146d4b4c15f791159289bcc7e57083223743d4.\n"
        "That observation comprised six host validators, including five negatives,\n"
        "with zero N256 numerical/model work. Those validators are not run here.\n"
        "The copied workflow retains its exact original branch-creation/attempt guard;\n"
        "this independent carry-forward branch cannot enter that metadata job.\n"
        "The old V2 run 45794040857 remains failed, with its exact Python setup failure.\n\n"
        "## CTRL scope and limits\n\n"
        "Old run 45794043165 passed five preparation tests, then failed to find its\n"
        "fixed historical commit in the shallow checkout. Full history addresses only\n"
        "that visibility defect. The current 6ca base still differs at the three fixed\n"
        "source pins and must still fail the original proposal admission gates.\n"
        "No CTRL dependency qualification, N256 numerical admission or production GO\n"
        "is granted. Generic push CI has its own workload and must be accounted for;\n"
        "new-branch push comparisons may include inherited history beyond these files.\n\n"
        "## Byte custody\n\n"
        "INDEX.json identifies one real xz archive: 90 raw preparation files plus this\n"
        "publisher, its input, the frozen helper and MANIFEST.json (94 total members).\n"
        "Verify archive bytes/SHA and every manifest entry before use. The copied\n"
        "LEGACY_SOURCE.tar.xz is retained as opaque original bytes, never repacked.\n"
    ).encode("utf-8")
    index_raw = h.encoded(index)
    h.need(len(index_raw.splitlines()) + len(readme.splitlines()) < 200,
           "evidence text must stay below 200 lines")
    h.write_new(OUT / "generated" / "INDEX.json", index_raw)
    h.write_new(OUT / "generated" / "README.md", readme)
    return {DEST + ARCHIVE_NAME: compressed, DEST + "INDEX.json": index_raw,
            DEST + "README.md": readme}


def publish(h, state, candidates, originals, extra, instructions, started):
    class Publisher13(h.Publisher):
        def api(self, method, endpoint, payload=None):
            allowed_get = endpoint == "user" or endpoint == API + "/git/ref/heads/" + BRANCH
            allowed_get = allowed_get or re.fullmatch(
                re.escape(API) + r"/git/(?:blobs|trees|commits)/[0-9a-f]{40}", endpoint) is not None
            allowed_get = allowed_get or re.fullmatch(
                re.escape(API) + r"/commits/[0-9a-f]{40}\?per_page=100", endpoint) is not None
            h.need((method == "GET" and payload is None and allowed_get) or
                   (method == "POST" and endpoint in {API + "/git/blobs",
                    API + "/git/trees", API + "/git/commits", API + "/git/refs"}
                    and isinstance(payload, dict)), "publisher 13 API allowlist")
            # Each low-level attempt is separately retained by the frozen helper.
            # Never retry any POST. A transient GET can have at most three attempts.
            for attempt in range(1, 4 if method == "GET" else 2):
                code, response = super().api(method, endpoint, payload)
                self.ops[-1]["logical_read_transport_attempt"] = attempt if method == "GET" else None
                self.checkpoint()
                if method == "POST" or code not in {None, 408, 429, 500, 502, 503, 504}:
                    return code, response
            return code, response

        def get(self, suffix, allow_missing=False):
            if not allow_missing:
                return self.visible(suffix)
            code, response = self.api("GET", API + suffix)
            if code == 404:
                h.need(isinstance(response, dict) and response.get("message") == "Not Found",
                       "absence must be an explicit GitHub 404")
                return None
            h.need(code == 200, "GET failed; no missing-object inference")
            return response

        def tree(self, object_sha, visibility=False, refresh=False):
            # Even old immutable objects have shown delayed visibility. A 404 here
            # is never interpreted as deletion or permission to drift the base.
            return super().tree(object_sha, visibility=True, refresh=refresh)

    pub = Publisher13(state)
    pub.started = started
    code, actor = pub.api("GET", "user")
    h.need(code == 200 and actor.get("login") == ACCOUNT and actor.get("id") == 102159240,
           "main GitHub actor identity")
    h.need(pub.get("/git/ref/heads/" + BRANCH, allow_missing=True) is None,
           "target ref already exists; no update allowed")
    base = pub.visible("/git/commits/" + BASE)
    h.need(base["sha"] == BASE and h.HEX40.fullmatch(base["tree"]["sha"]),
           "fixed base commit identity")
    base_tree = base["tree"]["sha"]
    state["base_tree"] = base_tree
    for path in sorted(TARGETS):
        entry = pub.lookup(base_tree, path)
        if path in ADDED:
            h.need(entry is None, "carried source must be absent at fixed base")
        else:
            h.need(entry and entry["type"] == "blob" and entry["mode"] == "100644"
                   and entry["sha"] == h.git_blob(originals[path]), "original CTRL source drift")
            pub.blob(originals[path])
    agent_raw = base64.b64decode(instructions["data_base64"], validate=True)
    h.check_identity(agent_raw, instructions)
    entry = pub.lookup(base_tree, "AGENTS.md")
    h.need(instructions["ref"] == BASE and entry and entry["mode"] == "100644"
           and entry["type"] == "blob" and entry["sha"] == h.git_blob(agent_raw),
           "AGENTS exact base identity")
    pub.blob(agent_raw)
    h.need(pub.lookup(base_tree, DEST.removesuffix("/")) is None, "new evidence prefix exists")
    files = candidates | extra
    h.need(len(files) == 12 and set(extra) == {DEST + ARCHIVE_NAME,
           DEST + "INDEX.json", DEST + "README.md"}, "exact twelve-path publication")
    for path, raw in sorted(files.items()):
        h.write_new(OUT / "files" / path, raw)
    # The eight source blobs already exist at 321. A missing read cannot authorize
    # uploading alternate bytes or rerunning that original metadata observation.
    updates = {path: pub.blob(raw, upload=path not in ADDED)
               for path, raw in sorted(files.items())}
    root_sha, trees = pub.build_tree(base_tree, updates)
    h.write_new(OUT / "TREE_PLAN.json", h.encoded({
        "base_commit": BASE, "base_tree": base_tree, "expected_root": root_sha,
        "changed_leaves": updates, "complete_ancestor_trees": trees}))
    state["expected_tree"] = root_sha
    epoch = int(time.time())
    date = datetime.fromtimestamp(epoch, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    author = {"name": ACCOUNT, "email": "102159240+" + ACCOUNT + "@users.noreply.github.com",
              "date": date}
    person = f"{author['name']} <{author['email']}> {epoch} +0000"
    message = "Carry forward qualified hosted metadata source and fix CTRL history depth\n"
    commit_raw = (f"tree {root_sha}\nparent {BASE}\nauthor {person}\ncommitter {person}\n\n"
                  + message).encode("utf-8")
    commit_sha = hashlib.sha1(
        b"commit " + str(len(commit_raw)).encode() + b"\0" + commit_raw).hexdigest()
    h.write_new(OUT / "EXPECTED_COMMIT.raw", commit_raw)
    state["expected_commit"] = commit_sha
    pub.checkpoint()
    # GitHub rejected a sibling flat base_tree/full-path request with HTTP 422.
    # Submit complete nonrecursive trees in dependency order. A 201 is only an
    # acknowledgement; every complete tree is still freshly verified before ref.
    order, visited, active = [], set(), set()

    def schedule(object_sha):
        if object_sha in visited:
            return
        h.need(object_sha not in active, "cyclic local tree dependency")
        active.add(object_sha)
        expected = trees[object_sha]
        h.need(h.tree_sha(list(expected.values())) == object_sha,
               "local complete direct-child tree identity")
        for entry in expected.values():
            if entry["type"] == "tree" and entry["sha"] in trees:
                schedule(entry["sha"])
        active.remove(object_sha)
        visited.add(object_sha)
        order.append(object_sha)

    schedule(root_sha)
    h.need(set(order) == set(trees) and order[-1] == root_sha,
           "complete bottom-up tree publication inventory")
    state["tree_submission_strategy"] = "incremental_complete_direct_entries"
    state["tree_submission_order"] = order
    state["tree_submissions"] = []
    pub.checkpoint()
    for object_sha in order:
        expected = trees[object_sha]
        row = {"sha": object_sha, "direct_entries": len(expected), "status": "GET_INTENT"}
        state["tree_submissions"].append(row)
        pub.checkpoint()
        found = pub.get("/git/trees/" + object_sha, allow_missing=True)
        if found is not None:
            h.need(found.get("sha") == object_sha and found.get("truncated") is False
                   and isinstance(found.get("tree"), list), "existing tree completeness")
            entries = [{key: entry[key] for key in ("path", "mode", "type", "sha")}
                       for entry in found["tree"]]
            h.need(h.tree_sha(entries) == object_sha
                   and {entry["path"]: entry for entry in entries} == expected,
                   "existing complete tree differs from local expectation")
            pub.tree_cache[object_sha] = expected
            row["status"] = "REUSED_GET_200_FULL_HASH_VERIFIED"
        else:
            # Only a definite 404 permits this single immutable-object POST.
            # No base_tree and no slash-containing paths are sent.
            payload = {"tree": [expected[name] for name in sorted(expected)]}
            h.need(all("/" not in entry["path"] for entry in payload["tree"]),
                   "incremental tree payload contains a nested path")
            row["status"] = "SINGLE_POST_INTENT"
            pub.checkpoint()
            pub.create_once("tree", "/git/trees", object_sha, payload,
                            defer_visibility=True)
            row["status"] = "POST_ACKNOWLEDGED_OR_GET_RECONCILED"
        pub.checkpoint()
    # After the last root acknowledgement/reuse, create this orphan commit once.
    # Unknown writes are reconciled by exact-SHA GET only, never another POST.
    pub.create_once("commit", "/git/commits", commit_sha, {
        "message": message, "tree": root_sha, "parents": [BASE],
        "author": author, "committer": author}, defer_visibility=True)
    actual = pub.visible("/git/commits/" + commit_sha)
    h.need(actual["sha"] == commit_sha and actual["tree"]["sha"] == root_sha
           and [parent["sha"] for parent in actual["parents"]] == [BASE]
           and actual["message"].rstrip("\n") == message.rstrip("\n")
           and actual["author"] == author and actual["committer"] == author,
           "candidate commit differs from deterministic local object")
    for object_sha, expected in trees.items():
        h.need(pub.tree(object_sha, refresh=True) == expected,
               "complete ancestor/root tree mismatch")
    # Fresh complete blob readback, after full tree validation and before the ref.
    pub.blob_cache.clear()
    for path, raw in sorted(files.items()):
        entry = pub.lookup(root_sha, path)
        h.need(entry and entry["type"] == "blob" and entry["mode"] == "100644"
               and entry["sha"] == h.git_blob(raw), "complete candidate path mismatch")
        pub.blob(raw, upload=False)
    detail = pub.visible("/commits/" + commit_sha + "?per_page=100")
    changed = detail.get("files", [])
    h.need(detail["sha"] == commit_sha and detail["commit"]["tree"]["sha"] == root_sha
           and [parent["sha"] for parent in detail["parents"]] == [BASE]
           and len(changed) == 12 and {row["filename"] for row in changed} == set(files),
           "complete twelve-path diff required")
    for row in changed:
        path = row["filename"]
        h.need(row["status"] == ("modified" if path == CTRL else "added")
               and row["sha"] == h.git_blob(files[path]) and "previous_filename" not in row,
               "commit file status/blob mismatch")
        h.need(all(type(row[key]) is int and row[key] >= 0
                   for key in ("additions", "deletions")), "diff count type/range")
    stats = detail["stats"]
    h.need(all(type(stats[k]) is int and stats[k] >= 0
               for k in ("additions", "deletions", "total"))
           and stats["total"] == stats["additions"] + stats["deletions"]
           == sum(row["additions"] + row["deletions"] for row in changed)
           and 0 < stats["total"] < 800, "strict total changed-line cap")
    state["commit_stats"], state["verified_changed_paths"] = stats, sorted(files)
    state["complete_tree_file_blob_diff_gates_passed"] = True
    state["remote_readback_files"] = 12
    h.check_custody(state)
    pub.checkpoint()
    h.need(pub.get("/git/ref/heads/" + BRANCH, allow_missing=True) is None,
           "target branch raced; never patch/update it")
    state["branch_creation_attempts"] = 1
    pub.checkpoint()
    pub.create_once("ref", "/git/refs", commit_sha, {"ref": REF, "sha": commit_sha})
    state["ref_created_or_read_reconciled"] = True
    ref = pub.visible("/git/ref/heads/" + BRANCH)
    h.need(ref["ref"] == REF and ref["object"]["type"] == "commit"
           and ref["object"]["sha"] == commit_sha, "final exact branch binding")
    h.check_custody(state)
    state.update(status=PUBLISHED, commit_sha=commit_sha, tree_sha=root_sha,
                 runtime_admitted=False, resource_admitted=False, production_adoption=False,
                 n256_numerical_qualification=False, ctrl_fixed_source_qualification=False)
    pub.checkpoint()


def main():
    if sys.platform != "darwin" or len(sys.argv) != 3 or any(
            re.fullmatch("[0-9a-f]{64}", value) is None for value in sys.argv[1:]):
        raise ValueError("main macOS invocation requires SELF_SHA256 INPUT_SHA256")
    own = Path(__file__).absolute()
    if own != ROOT / "publish_hosted_ctrl_13_02.py":
        raise ValueError("fixed publisher path")
    own_raw = bootstrap_read(own)
    if hashlib.sha256(own_raw).hexdigest() != sys.argv[1]:
        raise ValueError("SELF SHA mismatch")
    h, helper_raw = load_helper()
    h.need(not OUT.exists() and not OUT.is_symlink(), "publication_13_02 is create-only")
    OUT.mkdir()
    started, result = time.monotonic(), 1
    state = {
        "schema": SCHEMA, "status": "STARTED", "publication_base": BASE,
        "preparation_base": BASE, "branch": BRANCH, "runner_sha256": sys.argv[1],
        "input_sha256": sys.argv[2], "helper_sha256": PINS["helper"][1],
        "tests": 0, "models": 0, "optimizer_calls": 0, "compilations": 0,
        "formatter_invocations": 0, "metadata_observations": 0, "host_validator_calls": 0,
        "source_verifier_calls": 0, "workflow_dispatches": 0, "pull_requests": 0,
        "existing_ref_updates": 0, "branch_creation_attempts": 0, "archive_pack_attempts": 0,
        "write_transport_retries": 0, "scientific_and_production_hold_unchanged": True,
        "runtime_admitted": False, "resource_admitted": False, "production_adoption": False,
        "all_closed": False, "source_qualification_gained": False,
        "prior_unexecuted_publisher_sha256":
            "2dd1b59d011341f2746d09293c07759ea382224b7ec5bc30046310f30439b5c1",
        "resource_limits": {"wall_s": MAX_WALL, "http_attempts": MAX_HTTP,
            "get_transport_attempts": 3, "visibility_delays": DELAYS,
            "visibility_sleep_total_s": MAX_SLEEP, "each_gh_timeout_s": 90}}
    old_handlers = {}

    def interrupt(signum, frame):
        state["termination_requested"] = True
        raise RuntimeError("publication interrupted; retain partial transport evidence")

    try:
        for signum in (h.signal.SIGTERM, h.signal.SIGINT):
            old_handlers[signum] = h.signal.getsignal(signum)
            h.signal.signal(signum, interrupt)
        candidates, originals, members, instructions = validate(h, state, own_raw, helper_raw)
        extra = evidence(h, state, members, candidates)
        publish(h, state, candidates, originals, extra, instructions, started)
        result = 0
    except BaseException as error:
        state["status"], state["error"] = "FAILED_RETAINED", str(error)
        h.write_new(OUT / "TRACEBACK.txt", traceback.format_exc().encode("utf-8"))
        if "inputs_before" in state:
            try:
                h.check_custody(state)
            except BaseException as custody_error:
                state["custody_after_error"] = str(custody_error)
    finally:
        state["wall_s"] = time.monotonic() - started
        h.write_new(OUT / "RESULT.json", h.encoded(state))
        for signum, previous in old_handlers.items():
            h.signal.signal(signum, previous)
    return result


if __name__ == "__main__":
    raise SystemExit(main())
