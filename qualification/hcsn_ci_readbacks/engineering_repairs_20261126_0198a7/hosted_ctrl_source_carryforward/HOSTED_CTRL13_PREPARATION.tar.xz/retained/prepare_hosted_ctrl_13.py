"""Prepare the exact nine hosted/CTRL source changes once, in a fresh local tree.

Root invocation: python3.14 -B prepare_hosted_ctrl_13.py SELF_SHA256 INPUT_SHA256
No tests, metadata observers, model code, compiler, network or publication command is invoked.
"""
import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import stat
import subprocess
import sys
import time
import tomllib
import traceback

ROOT = Path("/Users/qianqi/work/hepta-hcsn-fixes-20261126-0198a7")
INPUT = ROOT / "HOSTED_CTRL13_CANDIDATES.json"
INPUT_SHA = "f853a3cb8c12bb8968f4e0a6728581e67bce5444b57e0892d818ec587bf51fba"
BASE = "6ca37caad90259aaad76c89d4f6a5a64715ab041"
SCAFFOLD_BASE = "4ffa56f6d0be94e68d23d1bfe72aa2cbfd50d479"
CARRY_SOURCE = "32153753a33a86a30d5d38a53483146c66161acd"
BRANCH = "fix/hosted-source-carryforward-20261126-0198a7"
OUT = ROOT / "hosted_ctrl_candidate_13"
SOURCE = OUT / "source"
EVIDENCE = OUT / "evidence"
PREFIX = "qualification/hcsn_ci_readbacks/engineering_repairs_20261126_0198a7/n256_host_profile/"
HOST_WORKFLOW = ".github/workflows/hepta-hcsn-n256-host-metadata-20261126.yml"
CTRL = ".github/workflows/ctrl-dependency-proposal.yml"
ADDED = {HOST_WORKFLOW} | {PREFIX + name for name in (
    "LEGACY_SOURCE.index.json", "LEGACY_SOURCE.tar.xz", "PROFILE.json", "README.md",
    "SOURCE_FREEZE.json", "requirements.txt", "run_profile.py")}
TARGETS = ADDED | {CTRL}
BINARY = PREFIX + "LEGACY_SOURCE.tar.xz"
JUST = "/opt/homebrew/bin/just"
GIT = "/usr/bin/git"
SCHEMA = "hepta.hosted-ctrl-source-preparation.v1"
READY = "FORMATTED_EXACT_BYTES_READY_NO_EXECUTION_QUALIFICATION"
MAX_FILE = 16 * 1024 * 1024
MAX_INPUT_TOTAL = 32 * 1024 * 1024
IDENTITY_KEYS = ("bytes", "sha256", "git_blob")
GIT_REDIRECT = {"GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_COMMON_DIR",
                "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES",
                "GIT_CONFIG", "GIT_CONFIG_COUNT", "GIT_CONFIG_PARAMETERS"}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(raw):
    return {"bytes": len(raw), "sha256": sha(raw),
            "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    def constant(value):
        raise ValueError("nonfinite JSON constant: " + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)


def repo_path(value):
    need(isinstance(value, str) and value and "\\" not in value and "\0" not in value, "invalid repository path")
    path = PurePosixPath(value)
    need(not path.is_absolute() and str(path) == value and all(p not in {"", ".", "..", ".git"} for p in path.parts), "unsafe repository path")
    return value


def root_path(value):
    path = Path(value)
    need(path.is_absolute(), "absolute retained input required")
    relative = path.relative_to(ROOT)
    repo_path(str(relative))
    need(relative.parts[0] != OUT.name, "output cannot be an input")
    return path


def read_regular(path):
    need(path.is_absolute() and not any(p.is_symlink() for p in path.parents), "nonabsolute or symlinked input ancestor")
    with os.fdopen(os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)), "rb") as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and 0 <= before.st_size <= MAX_FILE, "bounded single-link regular file required")
        raw, after = stream.read(MAX_FILE + 1), os.fstat(stream.fileno())
    need(len(raw) == before.st_size and all(getattr(before, k) == getattr(after, k) for k in
         ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")), "input changed during read")
    return raw


def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(raw)


def decoded(entry):
    need(type(entry["bytes"]) is int and 0 <= entry["bytes"] <= MAX_FILE, "declared byte bound")
    raw = base64.b64decode(entry["data_base64"], validate=True)
    need(identity(raw) == {k: entry[k] for k in IDENTITY_KEYS}, "base64 payload identity differs")
    return raw


def snapshot():
    result = {}
    for current, directories, filenames in os.walk(SOURCE, followlinks=False):
        current = Path(current)
        if current == SOURCE:
            directories[:] = [name for name in directories if name != ".git"]
        need(all(not (current / name).is_symlink() for name in directories), "symlink in source tree")
        for name in filenames:
            path = current / name
            result[str(path.relative_to(SOURCE))] = identity(read_regular(path))
    return result


def main():
    need(len(sys.argv) == 3 and re.fullmatch("[0-9a-f]{64}", sys.argv[1]) and sys.argv[2] == INPUT_SHA, "SELF_SHA256 and exact INPUT_SHA256 required")
    sys.dont_write_bytecode = True
    self_path = Path(__file__).absolute()
    self_raw = read_regular(self_path)
    need(self_path == ROOT / "prepare_hosted_ctrl_13.py" and sha(self_raw) == sys.argv[1], "fixed runner/self identity")
    OUT.mkdir(exist_ok=False)
    SOURCE.mkdir()
    EVIDENCE.mkdir()
    started, inputs, candidates, baseline, handlers = time.monotonic(), {}, {}, None, {}
    result = {"schema": SCHEMA, "status": "STARTED", "publication_base": BASE, "preparation_base": BASE,
              "scaffold_source_base": SCAFFOLD_BASE, "branch": BRANCH, "runner_sha256": sys.argv[1],
              "input_sha256": INPUT_SHA, "commands": [], "formatter_invocations": 0, "attempts": 1,
              "automatic_retry": False, "tests": 0, "models": 0, "optimizer_calls": 0, "compilations": 0,
              "source_verifier_calls": 0, "host_validator_calls": 0, "metadata_observations": 0,
              "github_writes": 0, "ci_dispatches": 0, "qualification_gained": False,
              "scientific_and_production_hold_unchanged": True, "termination_requested": False,
              "runtime_admitted": False, "resource_admitted": False, "production_adoption": False, "all_closed": False}

    def save():
        (EVIDENCE / "PROGRESS.tmp").write_bytes(encoded(result))
        os.replace(EVIDENCE / "PROGRESS.tmp", EVIDENCE / "PROGRESS.json")

    def interrupt(signum, frame):
        result["termination_requested"] = True
        raise RuntimeError("preparation interrupted or 750-second wall budget exhausted")

    def bound(path, expected=None):
        path = root_path(str(path))
        raw = read_regular(path)
        actual = identity(raw)
        need(expected is None or actual == expected, "retained input differs: " + str(path))
        need(str(path) not in inputs or inputs[str(path)] == actual, "retained input changed")
        inputs[str(path)] = actual
        need(sum(item["bytes"] for item in inputs.values()) <= MAX_INPUT_TOTAL, "retained input total bound")
        return raw

    def command(name, argv, limit, env, cwd):
        need(name in commands and commands[name] == (argv, limit, cwd), "unregistered preparation command")
        need(name not in {row["name"] for row in result["commands"]} and len(result["commands"]) < 9, "command count or duplicate attempt")
        remaining = 750 - (time.monotonic() - started)
        need(remaining > 0 and not result["termination_requested"], "preparation deadline")
        row = {"name": name, "argv": argv, "cwd": str(cwd), "timeout_s": min(limit, remaining),
               "status": "INTENT", "returncode": None}
        result["commands"].append(row)
        save()
        stdout, stderr = EVIDENCE / (name + ".stdout"), EVIDENCE / (name + ".stderr")
        child, began = None, time.monotonic()
        try:
            with stdout.open("xb") as out, stderr.open("xb") as err:
                child = subprocess.Popen(argv, cwd=cwd, env=env, stdout=out, stderr=err, start_new_session=True)
                row.update(status="RUNNING", child_pid=child.pid)
                save()
                child.wait(timeout=row["timeout_s"])
            row.update(status="RETURNED", returncode=child.returncode)
        except BaseException as error:
            if child is not None and child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait(timeout=10)
            row.update(status="FAILED_RETAINED", returncode=None if child is None else child.returncode,
                       error_type=type(error).__name__, error=str(error))
        finally:
            row["wall_s"] = time.monotonic() - began
            for key, path in (("stdout", stdout), ("stderr", stderr)):
                if path.exists():
                    row[key] = {"path": str(path), **identity(read_regular(path))}
            save()
        return row, stdout

    try:
        for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM):
            handlers[signum] = signal.getsignal(signum)
            signal.signal(signum, interrupt)
        signal.alarm(750)
        bound(self_path, identity(self_raw))
        input_raw = bound(INPUT)
        need(sha(input_raw) == INPUT_SHA and len(input_raw) == 213437, "frozen candidate input")
        document = strict_json(input_raw)
        need(document["schema"] == "hepta.hosted-ctrl-source-candidates.v1" and document["publication_base"] == BASE
             and document["preparation_base"] == BASE and document["branch"] == BRANCH, "preparation source/ref identity")
        need(document["expected_counts"] == {"scaffold": 51, "formatter_guards": 44, "baseline": 52, "changes": 9,
             "added": 8, "modified": 1, "binary": 1, "after_candidates": 60}, "fixed file denominator")
        instructions = document["agent_instructions"]
        need(instructions["repo_path"] == "AGENTS.md" and instructions["ref"] == BASE
             and instructions["git_blob"] == "faa57cc0db48123e1011f1eb47692cd3bbbcfc3a", "AGENTS source binding")
        result["agent_instructions"] = identity(decoded(instructions))
        result["retained_reviews"] = []
        for review in document["review_files"]:
            expected = {key: review[key] for key in IDENTITY_KEYS}
            raw = bound(root_path(review["path"]), expected)
            result["retained_reviews"].append({"path": review["path"], **identity(raw)})
        need(len(result["retained_reviews"]) == 1, "one immutable static review")
        scaffold = document["scaffold"]
        need(scaffold["source_base"] == SCAFFOLD_BASE and scaffold["current_identity_ref"] == BASE
             and scaffold["current_exact_git_blobs_verified"] == 51, "scaffold provenance/current identity")
        validation = scaffold["prior_validation"]
        prior = strict_json(bound(root_path(validation["path"]), {k: validation[k] for k in IDENTITY_KEYS}))
        need(prior["status"] == "FORMATTED_REVIEW_REQUIRED_NO_WINDOWS_QUALIFICATION" and prior["scaffold_files"] == 51
             and prior["all_original_inputs_unchanged"] is True and prior["scaffold_joined"] == scaffold["joined"], "retained scaffold custody")
        need(len(scaffold["parts"]) == 5, "five exact scaffold parts")
        joined = []
        for index, part in enumerate(scaffold["parts"]):
            need(part["name"] == "WINDOWS10_SCAFFOLD.part" + str(index).zfill(3), "ordered scaffold part identity")
            raw = bound(ROOT / part["name"])
            need(len(raw) == part["bytes"] and sha(raw) == part["sha256"], "scaffold part bytes/SHA")
            joined.append(raw)
        joined_raw = b"".join(joined)
        need(identity(joined_raw) == scaffold["joined"], "complete original scaffold identity")
        source_bundle = strict_json(joined_raw)
        need(source_bundle["base_commit"] == SCAFFOLD_BASE and len(source_bundle["files"]) == 51
             and set(source_bundle["files"]) == set(scaffold["files"]) and not TARGETS.intersection(source_bundle["files"]), "scaffold file set")
        baseline_bytes = {}
        for path, entry in source_bundle["files"].items():
            repo_path(path)
            raw = entry["content"].encode("utf-8")
            need(identity(raw) == scaffold["files"][path] and identity(raw) == prior["baseline_files"][path]
                 and identity(raw)["git_blob"] == entry["git_blob"], "scaffold original bytes differ: " + path)
            baseline_bytes[path] = raw
        guards = scaffold["formatter_guards"]
        need(len(guards) == 44 and set(guards) <= set(baseline_bytes)
             and all(guards[p] == identity(baseline_bytes[p]) for p in guards), "all 44 formatter guard bytes")
        result["formatter_guards_before"] = guards
        need(len(document["changes"]) == 9 and {row["repo_path"] for row in document["changes"]} == TARGETS, "exact nine changes")
        for row in document["changes"]:
            path = repo_path(row["repo_path"])
            original, candidate = decoded(row["original"]), decoded(row["candidate"])
            need(row["source_mode"] == "100644" and row["binary"] is (path == BINARY), "candidate mode/binary identity")
            if path == CTRL:
                need(row["status"] == "modified" and row["source_commit"] == BASE and row["destination_before"] == identity(original)
                     and identity(original)["git_blob"] == "f349baef2de52950d59e1581ed16b31bcc7dd719", "original CTRL identity")
                old, new = b"          fetch-depth: 16\n", b"          fetch-depth: 0\n"
                need(original.count(old) == 1 and candidate == original.replace(old, new, 1), "only exact checkout-depth replacement allowed")
                baseline_bytes[path] = original
            else:
                need(row["status"] == "added" and row["source_commit"] == CARRY_SOURCE and row["destination_before"] is None
                     and candidate == original, "carry-forward must retain all original bytes")
            candidates[path] = candidate
        need(len(baseline_bytes) == 52, "52-file baseline")
        frozen = strict_json(candidates[PREFIX + "SOURCE_FREEZE.json"])
        need(set(frozen["files"]) == ADDED - {PREFIX + "README.md", PREFIX + "SOURCE_FREEZE.json"}, "original six-file metadata freeze")
        for path, expected in frozen["files"].items():
            need(len(candidates[path]) == expected["bytes"] and sha(candidates[path]) == expected["sha256"], "original metadata freeze changed")
        need(sys.version_info[:2] == (3, 14), "preparation requires the original Python 3.14")
        toolchain = tomllib.loads(baseline_bytes["codex-rs/rust-toolchain.toml"].decode())["toolchain"]["channel"]
        need(toolchain in {"1.96", "1.96.0"} and not any(os.environ.get(k) for k in ("RUSTUP_TOOLCHAIN", "RUSTFMT"))
             and not any(os.environ.get(k) for k in GIT_REDIRECT), "toolchain or Git environment override")
        env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
        env.update(PATH="/opt/homebrew/bin:" + os.environ.get("PATH", ""), PYTHONDONTWRITEBYTECODE="1",
                   GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL="/dev/null", GIT_AUTHOR_NAME="workflow-test",
                   GIT_AUTHOR_EMAIL="workflow-test@hepta.invalid", GIT_COMMITTER_NAME="workflow-test",
                   GIT_COMMITTER_EMAIL="workflow-test@hepta.invalid")
        python3 = shutil.which("python3", path=env["PATH"])
        need(python3 and Path(python3).resolve() == Path(sys.executable).resolve(), "formatter must use this Python 3.14")
        result.update(python=sys.version, python_executable=sys.executable, formatter_python3=python3, toolchain=toolchain)
        for path, raw in baseline_bytes.items():
            write_new(SOURCE / path, raw)
        baseline = {path: identity(raw) for path, raw in baseline_bytes.items()}
        need(snapshot() == baseline, "materialized baseline differs")
        result["baseline_files"] = baseline
        gp = [GIT, "-c", "core.hooksPath=/dev/null", "-c", "core.autocrlf=false",
              "-c", "commit.gpgsign=false", "-c", "core.attributesFile=/dev/null"]
        commands = {
            "01-git-init": (gp + ["init", "--template=", "--initial-branch=hosted-ctrl-format-baseline"], 30, SOURCE),
            "02-git-add": (gp + ["add", "--force", "--all", "--", "."], 30, SOURCE),
            "03-git-baseline": (gp + ["commit", "--no-gpg-sign", "-m", "Local formatting baseline from exact 6ca source bytes"], 30, SOURCE),
            "04-git-index": (gp + ["ls-files", "--stage", "-z"], 30, SOURCE),
            "05-git-head": (gp + ["rev-parse", "HEAD"], 30, SOURCE),
            "06-git-intent": (gp + ["add", "--intent-to-add", "--force", "--", *sorted(ADDED)], 30, SOURCE),
            "07-just-fmt": ([JUST, "fmt"], 600, SOURCE / "codex-rs"),
            "08-git-diff-check": (gp + ["diff", "--check", "--no-ext-diff", "--no-textconv", "HEAD", "--", *sorted(TARGETS)], 30, SOURCE),
            "09-git-diff": (gp + ["diff", "--binary", "--full-index", "--no-ext-diff", "--no-textconv", "--no-color", "HEAD", "--", *sorted(TARGETS)], 30, SOURCE),
        }
        for name in ("01-git-init", "02-git-add", "03-git-baseline"):
            row, _ = command(name, *commands[name][:2], env, commands[name][2])
            need(row["status"] == "RETURNED" and row["returncode"] == 0, name + " failed")
        row, output = command("04-git-index", *commands["04-git-index"][:2], env, SOURCE)
        need(row["returncode"] == 0, "baseline index read failed")
        index = {}
        for record in read_regular(output).split(b"\0"):
            if record:
                header, path = record.split(b"\t", 1)
                mode, object_id, stage = header.decode().split()
                need(mode == "100644" and stage == "0" and path.decode() not in index, "baseline index mode/stage/duplicate")
                index[path.decode()] = object_id
        need(index == {p: value["git_blob"] for p, value in baseline.items()}, "52 exact baseline Git objects")
        row, output = command("05-git-head", *commands["05-git-head"][:2], env, SOURCE)
        local_head = read_regular(output).decode().strip()
        need(row["returncode"] == 0 and re.fullmatch("[0-9a-f]{40}", local_head), "local baseline commit identity")
        result.update(local_baseline_commit=local_head, local_baseline_is_original_repository_commit=False)
        for path, raw in candidates.items():
            if path == CTRL:
                (SOURCE / path).write_bytes(raw)
            else:
                write_new(SOURCE / path, raw)
        before = dict(baseline)
        before.update({p: identity(raw) for p, raw in candidates.items()})
        need(len(before) == 60 and snapshot() == before, "60-file candidate materialization")
        result["workspace_before_format"] = before
        row, _ = command("06-git-intent", *commands["06-git-intent"][:2], env, SOURCE)
        need(row["returncode"] == 0, "intent-to-add all eight original new files including binary")
        result["formatter_invocations"] = 1
        fmt, _ = command("07-just-fmt", *commands["07-just-fmt"][:2], env, SOURCE / "codex-rs")
        after = snapshot()
        result["workspace_after_format"] = after
        result["formatter_guards_after"] = {p: after.get(p) for p in guards}
        check, _ = command("08-git-diff-check", *commands["08-git-diff-check"][:2], env, SOURCE)
        diff, output = command("09-git-diff", *commands["09-git-diff"][:2], env, SOURCE)
        patch = read_regular(output)
        write_new(EVIDENCE / "DIFF.patch", patch)
        result["diff_patch"] = identity(patch)
        need(fmt["status"] == "RETURNED" and fmt["returncode"] == 0, "official just fmt failed")
        need(check["status"] == "RETURNED" and check["returncode"] == 0, "scoped whitespace check failed")
        need(diff["status"] == "RETURNED" and diff["returncode"] == 0, "scoped binary diff failed")
        need(after == before and len(after) == 60, "formatter changed candidate or noncandidate bytes/file denominator")
        need(result["formatter_guards_after"] == guards, "formatter changed an original guard")
        blocks = patch.decode("utf-8").split("diff --git ")
        need(blocks[0] == "" and len(blocks) == 10, "exact nine-file diff denominator")
        seen = set()
        original_by_path = {row["repo_path"]: row["original"] for row in document["changes"]}
        for block in blocks[1:]:
            header = block.split("\n", 1)[0]
            matches = [p for p in TARGETS if header == "a/" + p + " b/" + p]
            need(len(matches) == 1 and matches[0] not in seen, "diff path set")
            path = matches[0]
            seen.add(path)
            old_id = original_by_path[path]["git_blob"] if path == CTRL else "0" * 40
            new_id = identity(candidates[path])["git_blob"]
            need(re.search(r"^index " + old_id + r"\.\." + new_id + r"(?: 100644)?$", block, re.MULTILINE), "exact diff Git preimage/result")
            need(("new file mode 100644\n" in block) == (path in ADDED)
                 and "deleted file mode " not in block and "rename from " not in block, "diff change type")
            need(("GIT binary patch\n" in block) == (path == BINARY), "binary capsule retained as a true Git binary diff")
        need(seen == TARGETS and len(result["commands"]) == 9, "all registered source checks completed")
        result["formatted_source_files"] = [{"repo_path": p, "path": str(SOURCE / p), **after[p]} for p in sorted(TARGETS)]
        result["status"] = READY
    except BaseException as error:
        result.update(status="FAILED_RETAINED", error_type=type(error).__name__, error=str(error))
        write_new(EVIDENCE / "TRACEBACK.txt", traceback.format_exc().encode())
    finally:
        signal.alarm(0)
        result["input_files_before"] = inputs
        try:
            result["input_files_after"] = {path: identity(read_regular(Path(path))) for path in inputs}
            result["all_original_inputs_unchanged"] = bool(inputs) and result["input_files_after"] == inputs
            need(result["all_original_inputs_unchanged"], "retained input changed during preparation")
            if baseline is not None:
                final = snapshot()
                result["workspace_final"] = final
                if result["status"] == READY:
                    need(final == result["workspace_before_format"], "workspace changed after diff validation")
        except BaseException as error:
            result.update(status="FAILED_RETAINED", input_or_final_error=type(error).__name__ + ": " + str(error))
        result["wall_s"] = time.monotonic() - started
        save()
        write_new(EVIDENCE / "VALIDATION.json", encoded(result))
        ready = {"schema": SCHEMA, "status": result["status"], "publication_base": BASE, "preparation_base": BASE,
                 "branch": BRANCH, "runner_sha256": sys.argv[1], "input_sha256": INPUT_SHA,
                 "validation": {"path": str(EVIDENCE / "VALIDATION.json"), **identity(read_regular(EVIDENCE / "VALIDATION.json"))},
                 "formatted_source_files": result.get("formatted_source_files", []) if result["status"] == READY else [],
                 "tests": 0, "models": 0, "optimizer_calls": 0, "compilations": 0, "host_validator_calls": 0,
                 "metadata_observations": 0, "github_writes": 0, "ci_dispatches": 0, "qualification_gained": False}
        write_new(EVIDENCE / "READY.json", encoded(ready))
        for signum, handler in handlers.items():
            signal.signal(signum, handler)
    print(encoded({"status": result["status"], "ready": str(EVIDENCE / "READY.json"),
                   "formatter_invocations": result["formatter_invocations"], "tests": 0, "models": 0}).decode(), flush=True)
    return 0 if result["status"] == READY else 1


if __name__ == "__main__":
    raise SystemExit(main())
