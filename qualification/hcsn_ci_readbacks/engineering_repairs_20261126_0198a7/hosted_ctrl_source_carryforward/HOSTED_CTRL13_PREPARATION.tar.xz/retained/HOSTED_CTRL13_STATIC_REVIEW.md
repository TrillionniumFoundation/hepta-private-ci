# Hosted snapshot / CTRL: static source continuation

Reviewed destination: `6ca37caad90259aaad76c89d4f6a5a64715ab041`.
This bundle contains a one-line CTRL checkout candidate and an exact-source
carry-forward plan for the already successful N256 host-metadata profile.
No program, AST parser, formatter, test, model, Git write or CI was run by this reviewer.

## 1. Hosted snapshot is already superseded by a successful, separate profile

Original run 45794040857 / job 139820001357 failed before scientific work.
Its run head was 4ffa56f6d0be94e68d23d1bfe72aa2cbfd50d479; checkout actually used
PR merge 3f6bcb32b554be590874617884e9ee627b6404de.
The raw job log reports Ubuntu 26.04.1 and exact Python 3.12.3 unavailable.
Installation, source verification, both five-test control invocations and capture
were skipped. This remains a failed original attempt.

The existing V2 verifier hashes its workflow. Changing ubuntu-latest in place
would break SOURCE_FREEZE_V2.json; changing that old hash would erase the original
source identity. Both original workflow and freeze must remain unchanged.

Commit 32153753a33a86a30d5d38a53483146c66161acd already supplies the required
independent successor: eight exact files, Ubuntu 24.04, CPython 3.12.3, NumPy 2.3.5
and SciPy 1.17.0 metadata. Its archive preserves 13 legacy files plus one manifest.
The new reader verifies the original V2's 11 source pins from those preserved
bytes without rerunning the old verifier, five controls or observe().

That successor has actual successful evidence, not only a registration:

- Run 45786899259, attempt 1, push on the exact registered branch.
- Job 139795831557: every actual step completed successfully.
- Original job log records CPython 3.12.3 downloaded for Ubuntu 24.04.
- Launcher status PASS_METADATA_ONLY_HOLD_ADMISSION, child exit 0.
- Actual counts: metadata observation 1; host validator 6, including 5 negative controls;
  original verifier 0; original observe 0; NumPy/SciPy numeric imports 0;
  N256 input/serializer/dynamic/expm/Torch/model/optimizer/training all 0.
- Original RESULT SHA256:
  96fdf513c6be0297180de2320b146d4b4c15f791159289bcc7e57083223743d4.
- Artifact 15100974608: 28,989 bytes, API digest
  881930596a525c4fa5e6f073f1dfeaed02cf8bebb56c8f10478d0425f2505b36;
  not expired at this read, expires 2026-12-26T09:15:21Z.
- Root already verified its 18-member original ZIP. This review did not download it again.

The exact 6ca destination has neither the profile directory nor its workflow:
both explicit fixed-ref content reads returned 404. SNAPSHOT_CARRY_FORWARD_PLAN.json
lists all eight original Git blobs and their byte sizes. Reuse them as is in an
independent integration candidate; do not create a third observation profile.

The retained workflow responds only to a first ordinary push creating its exact
original branch, with run_attempt=1. Its runner repeats repository/branch/event/
workflow/source checks and refuses the consumed alternative contexts.
An independently named carry-forward branch does not match that workflow's
branch filter. No PR or workflow_dispatch trigger is present. Do not recreate the
consumed branch or change those conditions to obtain another run.

The old PROFILE/README registration wording is immutable historical source.
If current-result context is needed, publish a separate receipt/reference pointing
to the successful original run. Do not relabel V2's failure or promote runtime,
resource, N256 numerical, production or all_closed admission.

Sources:
https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45794040857
https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45786899259
https://github.com/TrillionniumFoundation/hepta-private-ci/commit/32153753a33a86a30d5d38a53483146c66161acd

## 2. CTRL: missing history and wrong proposal source are separate failures

Original run 45794043165 / job 139820008314 checked out exact source 4ffa56f6
with fetch-depth 16. Five preparation unit tests passed in 0.043 seconds.
The original formatting check reported no changed files to format.
prepare_ctrl_dependency_candidate.py then called:

    git merge-base --is-ancestor 99b194e64c83eb997344680b715c318d8e0d3cc8 HEAD

Git reported "Not a valid commit name" and exit 128. Resolver, Bazel, scoped Rust
consumers, no-suppression policy and cargo-deny stages were skipped.

The minimal candidate changes only fetch-depth: 16 to fetch-depth: 0 in the
existing checkout step. It preserves the selected PR-head/source ref,
persist-credentials:false, contents:read, all triggers, 90-minute job cap,
preparation checks, fixed BASE, path whitelist, three Git-blob pins, exact manifest
preimages, archive checks, dependency versions, mandatory lock generation and
no-suppression checks. It adds no retry or exception handling.
A depth-1 fetch of BASE alone would not supply the missing ancestry graph for a
still-shallow HEAD; full checkout history is the simple complete repair.

This improves history availability and makes subsequent source rejection
diagnosable. It does not qualify the integrated 6ca source.

| Dependency input | Required original Git blob | Exact 6ca Git blob |
| --- | --- | --- |
| codex-rs/Cargo.toml | d9f1bb1db407de3c2f1650edc4da5009ba3adaf1 | bb0b17886ed261d3181209ed07912beba839d38f |
| codex-rs/Cargo.lock | 46b1be5a5534631bf3151fbf1b3b1884451a8df9 | 87d249a175e6d6a73c93a8fa266597a5dbaab060 |
| codex-rs/third_party/matrix-sdk-sqlite-0.19.1/Cargo.toml.orig | ed8456d7a2013e879d52c2a119738d0ea3df2fe7 | d713c61c1647ca5ddc14d4116758eb9d98b115cf |

All three integrated files differ from the original BASE and lie outside the
proposal's whitelist. The existing changed-path gate should therefore reject
the current source once the history gate can evaluate it. Its subsequent exact
pin gate also cannot pass. Do not change these identities to force green.

## 3. The source-correct historical branch is identified precisely

Commit 978d5c4e67bb8dcc173e4b635622723864c23579 has all three required blobs.
The GitHub comparison against fixed BASE reports ahead_by=5, behind_by=0, with
the same merge base and exactly these five changed files:

- .github/workflows/ctrl-dependency-proposal.yml
- qualification/ctrl-metacontrol-20261109/DEPENDENCY_PROPOSAL.md
- scripts/align_ctrl_bindgen_syn.py
- scripts/prepare_ctrl_dependency_candidate.py
- scripts/tests/test_prepare_ctrl_dependency_candidate.py

All five are in that historical prepare script's original whitelist.
The complete five-commit chain is 8d8878c6, d60218f6, fe09d190, c9649269, 978d5c4e.
The workflow is byte-identical between this source and 6ca (Git blob
f349baef2de52950d59e1581ed16b31bcc7dd719), so the same one-line patch applies.

If the original disposable proposal needs a new source-correct engineering
candidate, branch from exact 978d5c4e and change only the workflow checkout depth.
Do not transplant current dependency files into it, change the workflow to
silently test an old head while reporting a new head, or widen its whitelist.
This recommendation identifies a valid starting source; no new resolver, build,
security or consumer qualification is claimed or performed here.

For a current-integration branch based on 6ca, the same one-line patch is only
a history-visibility/diagnostic repair. The intentional source refusal remains.
No proposal promotion, SQLx implementation work or other owner's integration
work is part of this candidate.

Sources:
https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45794043165
https://github.com/TrillionniumFoundation/hepta-private-ci/compare/99b194e64c83eb997344680b715c318d8e0d3cc8...978d5c4e67bb8dcc173e4b635622723864c23579
https://github.com/TrillionniumFoundation/hepta-private-ci/blob/6ca37caad90259aaad76c89d4f6a5a64715ab041/scripts/prepare_ctrl_dependency_candidate.py

## 4. Trigger, workload and authority boundaries

The proposed publication paths are the eight preserved snapshot-profile paths
and/or the single CTRL workflow. The following exact current consumers were read:

| Workflow | Match for those publication paths |
| --- | --- |
| Original hosted-runtime-snapshot V2 | No: it lists the original V1/V2 source paths and its own workflow |
| Existing 321 fixed-host metadata | Paths match its eight-source profile, but a new integration branch does not match its single allowed branch; no replay |
| CTRL dependency proposal | PR on its own changed workflow matches; ordinary push has no dedicated CTRL trigger |
| hcsn-differentiable | No: only its differentiable/QVI/memory/proposal sources and its own workflow |
| hcsn-real-checkpoint-cpu | No: only replay_v1 and its own workflow |
| hepta-hcsn-training-bridge | No: original training/Rust owner paths and its own workflow; original branch gate also remains |
| hepta-neuron-experiments | No: tools/hepta-neuron-experiments and its own workflow |
| wsp-value-sensitive-20261122 | No: tools/hcsn/wsp_20261122_next and its own workflow |

Neither carry-forward nor the checkout-depth change introduces an E1–E6,
16/16 training-matrix or real-checkpoint recovery entrypoint.
The original CTRL workflow, on a source satisfying its gates, prepares one
disposable Rust dependency proposal and invokes the original scoped Cargo/Bazel/
Rust library/security stages. Its existing build/time costs are not reported as
HCSN model or training evidence. No new runs have been authorized or started by
this static bundle.

This is an exact-path review of the listed consumers, not a claim that all 589
current workflows were newly audited or that a repository push has zero generic
CI cost. Any ordinary source/blocking CI that actually runs must retain its own
head, job, counts, outcomes and evidence. Do not suppress unrelated red jobs.

Root AGENTS.md is byte-identical at current 6ca and historical 978d (Git blob
faa57cc0db48123e1011f1eb47692cd3bbbcfc3a). Relevant queried nested AGENTS files
were absent. The delegation explicitly reserves actual formatting/execution/
publication to root; no test for a statically defined YAML value was added.

## 5. Root-owned isolated preparation 13

Root has now authorized one isolated source preparation with PUBLICATION_BASE and PREPARATION_BASE fixed to 6ca37caad90259aaad76c89d4f6a5a64715ab041. The new branch is fix/hosted-source-carryforward-20261126-0198a7. This is not authorization to rerun metadata or dependency/model experiments.

The five exact WINDOWS10_SCAFFOLD.part000..004 files retain their original 4ffa provenance; all 51 constituent Git blobs, including all 44 formatter guards, have been independently compared to exact 6ca and match. Baseline is those 51 files plus original CTRL workflow (52). Reuse eight exact 321 files and replace only CTRL fetch-depth:16 with 0 (60 files, nine candidate paths).

The registered preparation has a 750-second outer wall cap, one official just fmt (600-second command cap), one nine-path git diff --check and one full binary DIFF. One fresh local Git init/add/baseline commit/index read establishes the disposable baseline; one add --intent-to-add exposes all eight new paths including the binary capsule. Local baseline identity is not the original repository commit.

No input, candidate, other scaffold file or guard may change after formatting. Whole source snapshots must retain exactly 60 files. Failed formatting, whitespace, source or diff checks remain failures with original stdout/stderr and receipts. No candidate repacking/reformat-to-new-hash, source verifier, host validator, legacy observer, tests, model, optimizer, compiler, GitHub write or CI dispatch is permitted by this preparation.
