"""Publish retained vendor provenance from exact preparation bytes; no runtime claim.

Root-owned invocation on main:
    python3.14 -B publish_vendor_whitespace_12.py SELF_SHA256 INPUT_SHA256

Only gh API reads and single-attempt object/ref creations are permitted.
No formatter, compiler, test, model, training, PR, or workflow dispatch is run.
"""
import base64
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import signal
import stat
import subprocess
import sys
import tarfile
import time
import traceback
from urllib.parse import quote

ROOT = Path("/Users/qianqi/work/hepta-hcsn-fixes-20261126-0198a7")
OUT = ROOT / "publication_12"
INPUT = ROOT / "VENDOR12_PUBLICATION_INPUT.json"
SOURCE = ROOT / "vendor_candidate_12_02/source"
EVIDENCE = ROOT / "vendor_candidate_12_02/evidence"
GH = "/opt/homebrew/bin/gh"
REPO = "TrillionniumFoundation/hepta-private-ci"
API = "repos/" + REPO
ACCOUNT = "ProfHepta"
BASE = "6ca37caad90259aaad76c89d4f6a5a64715ab041"
PREPARATION_BASE = "4ffa56f6d0be94e68d23d1bfe72aa2cbfd50d479"
BRANCH = "fix/vendor-whitespace-20261126-0198a7"
REF = "refs/heads/" + BRANCH
DEST = "qualification/hcsn_ci_readbacks/engineering_repairs_20261126_0198a7/vendor_whitespace/"
STAR = "codex-rs/third_party/starlark-0.14.2-blake3-backport/"
SERDE = "codex-rs/third_party/serde-saphyr-2.0.0/"
EXISTING_SOURCES = {STAR + "src/values/layout/heap/send.rs",
                    SERDE + "tests/test_suite/y_M9B4.rs"}
MODIFIED = {STAR + "HEPTA_PATCH.md", SERDE + "HEPTA_PATCH.md",
            "apps/hepta-native/resources/NATIVE-DEPENDENCIES.json"}
ADDED = {STAR + "SOURCE_WHITESPACE_20261126.json",
         SERDE + "SOURCE_WHITESPACE_20261126.json"}
TARGETS = EXISTING_SOURCES | MODIFIED | ADDED
SCHEMA = "hepta.vendor-whitespace-publication.v1"
PREPARED = "FORMATTED_SCOPED_WHITESPACE_PASS_NO_RUNTIME_QUALIFICATION"
PUBLISHED = "VENDOR_PROVENANCE_SOURCE_CANDIDATE_PUBLISHED_RUNTIME_UNVERIFIED"
ARCHIVE_NAME = "VENDOR_WHITESPACE_12.tar.xz"
ZERO_FIELDS = ("tests", "models", "optimizer_calls", "compilations")
MAX_FILE, MAX_TOTAL, PART_BYTES = 16 * 1024 * 1024, 64 * 1024 * 1024, 450000
MAX_WALL, MAX_HTTP, MAX_VISIBILITY_SLEEP = 1800, 192, 480
VISIBILITY_DELAYS = (0, 2, 4, 8, 16, 30, 45, 45, 45)
HEX40, HEX64 = re.compile("[0-9a-f]{40}"), re.compile("[0-9a-f]{64}")
PINS = {
    "input": (72986, "f0c4cdbb90c2ceae6a988fa8cb5715df7b0e60aab0ec45ec8be0e82112c91bd0"),
    "ready": (4107, "e565bcbe4f9e8e87056ddfdb1a7f849e1ec089a599e34c0bcda95ae59c3a3808"),
    "validation": (137166, "3c740465137b87c8864cbc4da1efdd4966bf6f904061a741b18199d9ca62b6ac"),
    "preparation_input": (47175, "eba43cd8298c866d12c23ffe678f2d788175aed9383eaf3cd08cc8378850ce15"),
    "preparation_runner": (26005, "23260922f075076d1e024793bc8aa4f210d2b2c1aa9aed9759b615d81e47b25a"),
    "cargo": (30734, "f06b00510ea311c973b99c8dce81791ac751cba9b8b4a496a68620f08497b733"),
}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git_blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def identity(raw):
    return {"bytes": len(raw), "sha256": sha(raw), "git_blob": git_blob(raw)}


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False,
                       allow_nan=False) + "\n").encode("utf-8")


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "duplicate JSON key")
            result[key] = value
        return result

    def invalid_constant(value):
        raise ValueError("nonfinite JSON constant")
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid_constant)


def safe_relative(value):
    need(isinstance(value, str) and value and "\\" not in value and "\0" not in value,
         "invalid relative path")
    path = PurePosixPath(value)
    need(not path.is_absolute() and str(path) == value
         and all(p not in {".", "..", ".git"} for p in path.parts),
         "unsafe relative path")
    return value


def input_path(value):
    need(isinstance(value, str) and value and "\0" not in value, "missing input path")
    path = Path(value)
    need(path.is_absolute() and str(path) == value, "input path must be canonical absolute")
    relative = path.relative_to(ROOT)
    safe_relative(relative.as_posix())
    need(relative.parts[0] != OUT.name, "publication output cannot be an input")
    return path


def read_regular(path, maximum=MAX_FILE):
    for parent in path.parents:
        need(not parent.is_symlink(), "symlinked input ancestor")
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(descriptor, "rb") as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
             and 0 <= before.st_size <= maximum, "input must be bounded single-link regular file")
        raw = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
    keys = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    need(len(raw) == before.st_size and
         all(getattr(before, k) == getattr(after, k) for k in keys), "input changed during read")
    return raw


def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(raw)


def tree_sha(entries):
    names, chunks = set(), []
    ordered = sorted(entries, key=lambda x: (
        x["path"] + ("/" if x["type"] == "tree" else "")).encode())
    for item in ordered:
        name = item["path"]
        need(isinstance(name, str) and name and "/" not in name and "\0" not in name
             and name not in {".", ".."} and name not in names, "invalid Git tree entry")
        need(item["mode"] in {"100644", "100755", "120000", "160000", "040000"}
             and HEX40.fullmatch(item["sha"]) is not None, "Git tree mode/object identity")
        need((item["mode"] == "040000" and item["type"] == "tree")
             or (item["mode"] == "160000" and item["type"] == "commit")
             or (item["mode"] in {"100644", "100755", "120000"} and item["type"] == "blob"),
             "Git tree mode/type mismatch")
        names.add(name)
        chunks.append(item["mode"].lstrip("0").encode() + b" " + name.encode()
                      + b"\0" + bytes.fromhex(item["sha"]))
    raw = b"".join(chunks)
    return hashlib.sha1(b"tree " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def http_json(raw):
    split = re.search(rb"\r?\n\r?\n", raw[:65540])
    need(split is not None and split.end() <= 65536, "incomplete API response header")
    first = raw[:split.start()].splitlines()[0].decode("ascii")
    match = re.fullmatch(r"HTTP/\d(?:\.\d)?[ \t]+([0-9]{3})(?:[ \t]+.*)?", first)
    need(match is not None, "invalid API status line")
    return int(match.group(1)), strict_json(raw[split.end():])


def pinned(raw, pin):
    need(len(raw) == pin[0] and sha(raw) == pin[1], "frozen bytes/SHA mismatch")


def check_identity(raw, expected):
    actual = identity(raw)
    need(all(actual[k] == expected[k] for k in ("bytes", "sha256")), "input identity mismatch")
    if "git_blob" in expected:
        need(actual["git_blob"] == expected["git_blob"], "input Git blob mismatch")
    return actual


def validate_inputs(state, self_sha, input_sha):
    own = input_path(str(Path(__file__).absolute()))
    need(own == ROOT / "publish_vendor_whitespace_12.py", "unexpected publisher path")
    raw_self, raw_input = read_regular(own), read_regular(INPUT)
    need(sha(raw_self) == self_sha and sha(raw_input) == input_sha, "SELF/INPUT binding")
    pinned(raw_input, PINS["input"])
    spec = strict_json(raw_input)
    for key, expected in {"schema": SCHEMA, "repository": REPO, "account": ACCOUNT,
                          "base_commit": BASE, "preparation_base_commit": PREPARATION_BASE,
                          "branch": BRANCH, "hold_unchanged": True}.items():
        need(spec.get(key) == expected, "publication scope mismatch: " + key)
    fixed = {"ready_path": EVIDENCE / "READY.json",
             "validation_path": EVIDENCE / "VALIDATION.json",
             "preparation_input_path": ROOT / "VENDOR12_PREP_INPUT.json",
             "preparation_runner_path": ROOT / "prepare_vendor_whitespace_12_02.py"}
    for key, path in fixed.items():
        need(input_path(spec[key]) == path, "unexpected fixed preparation path")
    need(len(spec["raw_files"]) == 174, "explicit raw file count")
    raw_by_path, members, custody = {}, {}, {}
    for row in spec["raw_files"]:
        need(set(row) == {"path", "archive_member", "bytes", "sha256"}, "raw file schema")
        path, member = input_path(row["path"]), safe_relative(row["archive_member"])
        need(str(path) not in raw_by_path and member not in members, "duplicate raw input")
        raw = read_regular(path)
        custody[str(path)] = check_identity(raw, row)
        raw_by_path[str(path)], members[member] = raw, raw
    need(sum(len(raw) for raw in raw_by_path.values()) == 4384576, "raw total bytes")
    for key, path in fixed.items():
        pinned(raw_by_path[str(path)], PINS[key.removesuffix("_path")])
    cargo_path = str(ROOT / "VENDOR12_FORMATTER_CARGO.json")
    pinned(raw_by_path[cargo_path], PINS["cargo"])
    ready = strict_json(raw_by_path[spec["ready_path"]])
    valid = strict_json(raw_by_path[spec["validation_path"]])
    prep = strict_json(raw_by_path[spec["preparation_input_path"]])
    for item in (ready, valid, prep):
        need(item["schema"] == "hepta.vendor-whitespace-preparation.v1"
             and item["base_commit"] == PREPARATION_BASE, "preparation identity")
    for item in (ready, valid):
        need(item["status"] == PREPARED and item["runtime_qualification"] is False
             and item["whole_repository_whitespace_gate_closed"] is False, "preparation scope")
        need(all(type(item[k]) is int and item[k] == 0 for k in ZERO_FIELDS), "nonzero runtime work")
        need(item["runner_sha256"] == PINS["preparation_runner"][1]
             and item["input_sha256"] == PINS["preparation_input"][1]
             and item["cargo_input_sha256"] == PINS["cargo"][1], "preparation pins")
    check_identity(raw_by_path[spec["validation_path"]], ready["validation"])
    need(ready["validation"]["path"] == spec["validation_path"], "validation path binding")
    need(valid["inputs_before"] == valid["inputs_after"] and len(valid["inputs_before"]) == 95,
         "retained preparation inputs differ")
    for path, expected in valid["inputs_before"].items():
        check_identity(raw_by_path[path], expected)
    need(valid["workspace_before_format"] == valid["workspace_after_format"]
         and len(valid["workspace_after_format"]) == 60 and len(valid["baseline_files"]) == 58,
         "preparation workspace changed")
    for relative, expected in valid["workspace_after_format"].items():
        check_identity(raw_by_path[str(SOURCE / safe_relative(relative))], expected)
    need(all(valid[k] is True for k in ("all_input_files_unchanged",
             "candidate_bytes_unchanged_by_formatter", "other_baseline_and_guards_unchanged")),
         "preparation custody flags")
    need(valid["scaffold_counts"] == {"additional_exact_manifests": 2, "original_guards": 44,
             "original_scaffold": 51, "total_scaffold": 53} and valid["toolchain"] == "1.96.0",
         "formatter scaffold/guard identity")
    names = ("01-init", "02-add-baseline", "03-commit-baseline", "04-index", "05-just-fmt",
             "06-add-intent-only-two-new", "07-scoped-diff-check", "08-scoped-diff-binary")
    need(tuple(c["name"] for c in valid["commands"]) == names, "preparation command inventory")
    for command in valid["commands"]:
        need(command["status"] == "RETURNED" and command["returncode"] == 0, "failed preparation")
        for stream in ("stdout", "stderr"):
            check_identity(raw_by_path[command[stream]["path"]], command[stream])
    need(valid["commands"][4]["argv"] == ["/opt/homebrew/bin/just", "fmt"]
         and valid["commands"][4]["cwd"] == str(SOURCE / "codex-rs"), "official fmt command")
    for i in (4, 6):
        need(all(valid["commands"][i][s]["bytes"] == 0 for s in ("stdout", "stderr")),
             "fmt/scoped diff-check streams are not empty")
    need(set(valid["scoped_paths"]) == TARGETS and
         valid["scoped_diff_check"] == {"paths": sorted(TARGETS), "returncode": 0,
                                        "whole_repository_gate": False}, "scoped whitespace gate")
    diff = raw_by_path[str(EVIDENCE / "DIFF.patch")]
    check_identity(diff, valid["diff_patch"])
    need(diff == raw_by_path[valid["commands"][7]["stdout"]["path"]], "diff stream mismatch")
    need(valid["prior_preparation"]["status"] == "FAILED_RETAINED"
         and valid["prior_preparation"]["old_preparation_rerun"] is False, "prior failure custody")
    changes = {x["path"]: x for x in prep["changes"]}
    ready_rows = {x["repo_path"]: x for x in ready["candidate_files"]}
    need(len(changes) == len(prep["changes"]) == len(ready_rows) == 7
         and set(changes) == set(ready_rows) == TARGETS, "exact seven candidate scope")
    candidates, originals = {}, {}
    for path in sorted(TARGETS):
        row, prepared = changes[path], ready_rows[path]
        need(prepared["path"] == str(SOURCE / path), "prepared source path")
        raw = raw_by_path[prepared["path"]]
        check_identity(raw, row["candidate"])
        check_identity(raw, prepared)
        need(raw == row["candidate"]["content"].encode("utf-8"), "candidate text mismatch")
        candidates[path] = raw
        original = row["original"]
        need((original is None) == (path in ADDED), "added/modified source inventory")
        if original is not None:
            originals[path] = original["content"].encode("utf-8")
            check_identity(originals[path], original)
            need(valid["baseline_files"][path] == identity(originals[path]), "original baseline mismatch")
        else:
            need(path not in valid["baseline_files"], "new provenance existed in baseline")
    for path, expected in valid["baseline_files"].items():
        if path not in TARGETS:
            need(valid["workspace_after_format"][path] == expected, "guard/noncandidate changed")
    custody[str(own)], custody[str(INPUT)] = identity(raw_self), identity(raw_input)
    members["publication/PUBLISHER.py"], members["publication/INPUT.json"] = raw_self, raw_input
    need(sum(map(len, members.values())) <= MAX_TOTAL, "archive input size limit")
    state["inputs_before"], state["preparation"] = custody, {
        "status": PREPARED, "preparation_base": PREPARATION_BASE, "publication_base": BASE,
        "validation": identity(raw_by_path[spec["validation_path"]]),
        "ready": identity(raw_by_path[spec["ready_path"]]), "retained_inputs": 95,
        "retained_raw_files": 174, "workspace_files": 60, "formatter_guards": 44,
        "preparation_commands": 8, "formatter_wall_s": valid["commands"][4]["wall_s"],
        "preparation_wall_s": valid["wall_s"], "scoped_paths": sorted(TARGETS),
        "tests": 0, "models": 0, "compilations": 0, "optimizer_calls": 0,
        "runtime_qualification": False, "whole_repository_whitespace_gate_closed": False}
    return candidates, originals, members


def make_evidence(state, members, candidates):
    report = state["preparation"] | {
        "schema": "hepta.vendor-whitespace-publication-readback.v1",
        "rust_sources_already_present_at_publication_base": sorted(EXISTING_SOURCES),
        "actual_metadata_notice_changes": sorted(MODIFIED | ADDED),
        "all_seven_candidate_identities": {p: identity(b) for p, b in sorted(candidates.items())},
        "scientific_and_production_hold_unchanged": True,
        "accesskit_missing_readme_hunk_closed": False,
        "publisher_runs_no_formatter_test_compiler_or_model": True}
    members["publication/PREPARATION_READBACK.json"] = encoded(report)
    names = set(members)
    need("MANIFEST.json" not in names and
         all(not any(parent.as_posix() in names for parent in PurePosixPath(n).parents
                     if parent.as_posix() != ".") for n in names), "archive member collision")
    manifest = encoded({"schema": "hepta.retained-byte-archive.v1",
                        "manifest_excludes_itself": True,
                        "files": {p: identity(b) for p, b in sorted(members.items())}})
    members = members | {"MANIFEST.json": manifest}
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:xz", format=tarfile.PAX_FORMAT, preset=6) as archive:
        for name, raw in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            archive.addfile(info, io.BytesIO(raw))
    compressed = output.getvalue()
    need(compressed.startswith(b"\xfd7zXZ\x00") and len(compressed) <= PART_BYTES,
         "single true xz archive exceeds fixed eight-path publication scope")
    with tarfile.open(fileobj=io.BytesIO(compressed), mode="r:xz") as archive:
        seen = set()
        for member in archive.getmembers():
            need(member.isfile() and member.name in members and member.name not in seen
                 and member.size == len(members[member.name]), "archive member structure")
            seen.add(member.name)
            need(archive.extractfile(member).read() == members[member.name], "archive byte readback")
        need(seen == set(members), "archive member inventory")
    index = {
        "schema": "hepta.vendor-whitespace-publication-index.v1",
        "preparation_base_commit": PREPARATION_BASE, "publication_base_commit": BASE,
        "preparation_status": PREPARED, "raw_inputs": 174, "archive_members": len(members),
        "archive": {"path": ARCHIVE_NAME, **identity(compressed)},
        "manifest_sha256": sha(manifest), "ordered_parts": [ARCHIVE_NAME],
        "verification": "Join ordered_parts; verify archive bytes/SHA; read MANIFEST.json and verify every member.",
        "actual_changed_source_paths": sorted(MODIFIED | ADDED),
        "already_present_rust_source_paths": sorted(EXISTING_SOURCES),
        "runtime_qualification": False, "whole_repository_whitespace_gate_closed": False,
        "scientific_and_production_hold_unchanged": True}
    readme = (
        "# Vendor whitespace 候选的来源与限定核验\n\n"
        "准备基准为 " + PREPARATION_BASE + "，发布基准为 " + BASE + "。\n"
        "发布基准已包含两处完全相同的 Rust 源码字节；本分支只增加两份说明、两份来源 JSON、"
        "通知清单四标量校正与三份证据文件，不把已集成源码再次算作新增修复。\n\n"
        "## 已有实测\n\n"
        "第二次隔离准备的八个登记命令全部 exit 0。官方 just fmt 成功，七路径 git diff --check "
        "成功；二者 stdout/stderr 均为空。95 个前置文件和 60 个准备后文件前后逐字一致，"
        "44 个原 formatter guard 保留。准备耗时 " + str(report["preparation_wall_s"]) +
        " 秒，其中 formatter " + str(report["formatter_wall_s"]) + " 秒。\n\n"
        "第一次失败的完整证据仍在档案内：稀疏准备遗漏两个原 Cargo.toml，构造格式化命令时"
        "落到虚 workspace 的 manifest，触发 KeyError package。该次未启动 rustfmt。"
        "第二次仅从原基准补齐两个 crate manifest；未改候选、原 guard、toolchain 或旧失败结果。"
        "两次 DIFF.patch 的 SHA256 相同。\n\n"
        "## 具体范围\n\n"
        "- Starlark 只删除空文档注释后的两个空格；旧 registry/checksum、78 文件收据及三份 patch.gz 保留。\n"
        "- Serde 仅把 raw YAML 字面量改为 escaped Rust 字面量，运行时 20 字节、空格与制表符及三个尾 LF 不变；"
        "原断言未改，未执行这个 fixture。\n"
        "- 两份 HEPTA_PATCH.md 仅在原正文后追加来源说明；两份新 provenance 保持准备基准 4ffa，"
        "旧五 fixture 成功没有转授给本候选。\n"
        "- AccessKit 通知清单仅更新两个既有通知文件的 bytes/SHA 四个标量；"
        "缺失的 common README hunk 仍未闭合。\n\n"
        "## 资格边界与恢复\n\n"
        "本次发布器只做字节核验、真实 tar.xz 归档与 Git 数据发布，0 次新增格式化、编译、"
        "测试、模型、训练及 optimizer 调用。准备阶段同样 0 次编译、测试、模型或 optimizer 调用。"
        "七路径增量检查不等于旧 8ce 来源运行所记录的 183 路径/243 警告门通过，也不提供 Windows/native 运行资格；"
        "全仓科学与生产 HOLD 保持。\n\n"
        "按 INDEX.json 的 ordered_parts 顺序连接（当前为一个真实 .tar.xz），先核完整 bytes/SHA，"
        "再读取档案内 MANIFEST.json 逐成员核验。档案保存 174 份显式原始输入、两个准备尝试的原件、"
        "完整 scaffold/guards、原失败与成功命令流、当前七候选、发布输入和发布脚本。"
        "读取脚本字节不代表运行脚本；恢复原件后不要自动执行其中程序。\n"
    ).encode("utf-8")
    files = {DEST + ARCHIVE_NAME: compressed, DEST + "INDEX.json": encoded(index),
             DEST + "README_ZH.md": readme}
    for path, raw in files.items():
        write_new(OUT / "generated" / Path(path).name, raw)
    state["archive"] = {"bytes": len(compressed), "sha256": sha(compressed),
                        "members": len(members), "manifest_sha256": sha(manifest)}
    return files


class Publisher:
    def __init__(self, state):
        self.state, self.started = state, time.monotonic()
        self.ops, self.posted, self.tree_cache, self.blob_cache = [], set(), {}, {}
        self.sleep_total = 0

    def checkpoint(self):
        self.state["operations"] = self.ops
        self.state["visibility_sleep_s"] = self.sleep_total
        temporary = OUT / "PROGRESS.next"
        write_new(temporary, encoded(self.state))
        os.replace(temporary, OUT / "PROGRESS.json")

    def api(self, method, endpoint, payload=None):
        need(method in {"GET", "POST"}, "only GET and one-attempt POST allowed")
        need(endpoint == "user" or endpoint.startswith(API + "/"), "API repository scope")
        need(method != "POST" or endpoint in {API + "/git/blobs", API + "/git/trees",
             API + "/git/commits", API + "/git/refs"}, "mutation endpoint not permitted")
        remaining = MAX_WALL - (time.monotonic() - self.started)
        need(remaining > 0 and len(self.ops) < MAX_HTTP, "HTTP/wall budget exhausted")
        number = len(self.ops) + 1
        prefix = OUT / "operations" / f"{number:03d}"
        request_path, stdout_path, stderr_path = (
            prefix.with_suffix(s) for s in (".request.json", ".stdout", ".stderr"))
        write_new(request_path, encoded({"method": method, "endpoint": endpoint,
                                        "payload": payload}))
        argv = [GH, "api", "--hostname", "github.com", "--method", method,
                "--include", "-H", "Accept: application/vnd.github+json", endpoint]
        if payload is not None:
            payload_path = prefix.with_suffix(".payload.json")
            write_new(payload_path, encoded(payload))
            argv += ["--input", str(payload_path)]
        op = {"number": number, "method": method, "endpoint": endpoint,
              "request": {"path": str(request_path), **identity(read_regular(request_path))},
              "status": "STARTED", "transport_attempts": 1}
        self.ops.append(op)
        self.checkpoint()
        env = os.environ.copy()
        env["GH_PROMPT_DISABLED"], env["GH_PAGER"] = "1", "cat"
        env.pop("GH_DEBUG", None)
        child, started = None, time.monotonic()
        try:
            with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
                child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                         stdout=stdout, stderr=stderr, start_new_session=True)
                op["pid"] = child.pid
                try:
                    op["returncode"] = child.wait(timeout=min(90, remaining))
                    op["status"] = "RETURNED"
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                    op["returncode"], op["status"] = child.returncode, "TIMED_OUT_RETAINED"
        except BaseException:
            if child is not None and child.poll() is None:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            op["status"] = "PROCESS_ERROR_RETAINED"
            raise
        finally:
            op["wall_s"] = time.monotonic() - started
            for key, path in (("stdout", stdout_path), ("stderr", stderr_path)):
                if path.is_file():
                    op[key] = {"path": str(path), **identity(read_regular(path))}
            self.checkpoint()
        try:
            code, response = http_json(read_regular(stdout_path))
            op["http_status"], op["response_json"] = code, response
        except (ValueError, UnicodeError, KeyError, IndexError) as error:
            code, response = None, None
            op["parse_error"] = str(error)
        self.checkpoint()
        return code, response

    def get(self, suffix, allow_missing=False):
        code, response = self.api("GET", API + suffix)
        if allow_missing and code == 404:
            return None
        need(code == 200, "GET unavailable; no write retry: " + suffix)
        return response

    def visible(self, suffix):
        for delay in VISIBILITY_DELAYS:
            if delay:
                need(self.sleep_total + delay <= MAX_VISIBILITY_SLEEP
                     and time.monotonic() - self.started + delay < MAX_WALL,
                     "read-only visibility budget exhausted")
                self.sleep_total += delay
                self.checkpoint()
                time.sleep(delay)
            code, response = self.api("GET", API + suffix)
            if code == 200:
                return response
            need(code in {None, 404, 408, 429, 500, 502, 503, 504},
                 "visibility read failed with definite HTTP status")
        raise ValueError("object/ref read visibility pending; every prior POST is retained")

    def create_once(self, kind, endpoint, expected, payload, defer_visibility=False):
        key = kind + ":" + expected
        need(key not in self.posted, "duplicate object/ref POST forbidden")
        self.posted.add(key)
        self.state.setdefault("write_intents", []).append(
            {"kind": kind, "expected": expected, "payload_sha256": sha(encoded(payload)),
             "status": "SINGLE_TRANSPORT_ATTEMPT"})
        self.checkpoint()
        code, response = self.api("POST", API + endpoint, payload)
        intent = self.state["write_intents"][-1]
        if code == 201:
            actual = response.get("object", {}).get("sha") if kind == "ref" else response.get("sha")
            need(actual == expected, "acknowledged object SHA differs from local prediction")
            if kind == "ref":
                need(response.get("ref") == REF, "acknowledged ref name differs")
            intent["status"] = "ACKNOWLEDGED_201_NOT_YET_READ_VERIFIED"
            self.checkpoint()
            if defer_visibility:
                return response
        elif code is not None and code < 500 and code not in {408, 429}:
            intent["status"] = "DEFINITE_HTTP_REJECTION_RETAINED"
            self.checkpoint()
            raise ValueError("POST rejected; no resend: " + str(code))
        else:
            intent["status"] = "UNKNOWN_WRITE_RETAINED_GET_ONLY"
            self.checkpoint()
        suffix = "/git/ref/heads/" + BRANCH if kind == "ref" else endpoint + "/" + expected
        found = self.visible(suffix)
        actual = found.get("object", {}).get("sha") if kind == "ref" else found.get("sha")
        need(actual == expected and (kind != "ref" or found.get("ref") == REF),
             "read-only write reconciliation identity mismatch")
        intent["status"] = "READ_RECONCILED_NO_RESEND"
        self.checkpoint()
        return found

    def tree(self, object_sha, visibility=False, refresh=False):
        if not refresh and object_sha in self.tree_cache:
            return self.tree_cache[object_sha]
        response = (self.visible if visibility else self.get)("/git/trees/" + object_sha)
        need(response["sha"] == object_sha and response.get("truncated") is False,
             "complete nonrecursive tree required")
        entries = [{k: entry[k] for k in ("path", "mode", "type", "sha")}
                   for entry in response["tree"]]
        need(tree_sha(entries) == object_sha, "complete Git tree hash mismatch")
        result = {entry["path"]: entry for entry in entries}
        self.tree_cache[object_sha] = result
        return result

    def lookup(self, root_sha, path):
        parts, current = safe_relative(path).split("/"), root_sha
        for i, part in enumerate(parts):
            entry = self.tree(current).get(part)
            if entry is None:
                return None
            if i == len(parts) - 1:
                return entry
            need(entry["type"] == "tree" and entry["mode"] == "040000", "non-directory ancestor")
            current = entry["sha"]
        raise ValueError("empty lookup")

    def blob(self, raw, upload=False):
        expected = git_blob(raw)
        if expected in self.blob_cache:
            need(self.blob_cache[expected] == raw, "local Git blob collision")
            return expected
        found = self.get("/git/blobs/" + expected, allow_missing=upload)
        if found is None:
            found = self.create_once("blob", "/git/blobs", expected,
                                     {"encoding": "base64",
                                      "content": base64.b64encode(raw).decode("ascii")})
        need(found["sha"] == expected and found["encoding"] == "base64"
             and found["size"] == len(raw), "remote blob metadata mismatch")
        actual = base64.b64decode("".join(found["content"].split()), validate=True)
        need(actual == raw and git_blob(actual) == expected, "remote blob bytes mismatch")
        self.blob_cache[expected] = actual
        return expected

    def build_tree(self, base_sha, updates):
        expected_trees = {}

        def visit(old_sha, rows):
            entries = dict(self.tree(old_sha)) if old_sha else {}
            groups = {}
            for relative, leaf_sha in rows.items():
                part, slash, tail = relative.partition("/")
                groups.setdefault(part, {})[tail if slash else ""] = leaf_sha
            for part, nested in groups.items():
                prior = entries.get(part)
                if "" in nested:
                    need(len(nested) == 1 and (prior is None or prior["type"] == "blob"),
                         "leaf/directory replacement forbidden")
                    entries[part] = {"path": part, "type": "blob", "mode": "100644", "sha": nested[""]}
                else:
                    need(prior is None or prior["type"] == "tree", "non-directory tree ancestor")
                    child = visit(prior["sha"] if prior else None, nested)
                    entries[part] = {"path": part, "type": "tree", "mode": "040000", "sha": child}
            new_sha = tree_sha(list(entries.values()))
            expected_trees[new_sha] = entries
            return new_sha
        return visit(base_sha, updates), expected_trees


def check_custody(state):
    after = {path: identity(read_regular(input_path(path))) for path in state["inputs_before"]}
    need(after == state["inputs_before"], "retained inputs changed during publication")
    state["inputs_after"] = after


def publish(state, candidates, originals, evidence):
    pub = Publisher(state)
    code, user = pub.api("GET", "user")
    need(code == 200 and user.get("login") == ACCOUNT and user.get("id") == 102159240, "wrong GitHub account")
    need(pub.get("/git/ref/heads/" + BRANCH, allow_missing=True) is None,
         "target branch exists; never update or overwrite it")
    base = pub.get("/git/commits/" + BASE)
    prep = pub.get("/git/commits/" + PREPARATION_BASE)
    need(base["sha"] == BASE and prep["sha"] == PREPARATION_BASE, "base commit mismatch")
    base_tree, prep_tree = base["tree"]["sha"], prep["tree"]["sha"]
    need(HEX40.fullmatch(base_tree) and HEX40.fullmatch(prep_tree), "base tree identity")
    for path in sorted(TARGETS):
        previous = pub.lookup(prep_tree, path)
        current = pub.lookup(base_tree, path)
        if path in ADDED:
            need(previous is None and current is None, "new provenance path is not absent")
        else:
            need(previous is not None and previous["mode"] == "100644"
                 and previous["type"] == "blob" and previous["sha"] == git_blob(originals[path]),
                 "preparation base original Git blob mismatch")
            pub.blob(originals[path])
            expected = candidates[path] if path in EXISTING_SOURCES else originals[path]
            need(current is not None and current["mode"] == "100644"
                 and current["type"] == "blob" and current["sha"] == git_blob(expected),
                 "publication base source/metadata drift")
            pub.blob(expected)
    need(pub.lookup(base_tree, DEST.removesuffix("/")) is None, "new evidence prefix already exists")
    files = {p: candidates[p] for p in sorted(MODIFIED | ADDED)} | evidence
    need(len(files) == 8 and set(files) == MODIFIED | ADDED | set(evidence),
         "exact five changed paths plus three evidence files")
    updates = {p: pub.blob(raw, upload=True) for p, raw in sorted(files.items())}
    new_tree, expected_trees = pub.build_tree(base_tree, updates)
    tree_plan = {"base_commit": BASE, "base_tree": base_tree, "expected_root": new_tree,
                 "changed_leaves": updates, "complete_ancestor_trees": expected_trees}
    write_new(OUT / "TREE_PLAN.json", encoded(tree_plan))
    state["expected_tree"] = new_tree
    pub.checkpoint()
    # One nested root-tree POST. No parent subtree entries and no subtree POSTs.
    # A correct 201 SHA is only an acknowledgement, never a complete tree proof.
    pub.create_once("tree", "/git/trees", new_tree,
                    {"base_tree": base_tree,
                     "tree": [{"path": p, "mode": "100644", "type": "blob", "sha": s}
                              for p, s in sorted(updates.items())]}, defer_visibility=True)
    epoch = int(time.time())
    date = datetime.fromtimestamp(epoch, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    author = {"name": ACCOUNT, "email": "102159240+" + ACCOUNT + "@users.noreply.github.com", "date": date}
    message = "Document vendor whitespace provenance and retain scoped preparation evidence\n"
    person = f"{author['name']} <{author['email']}> {epoch} +0000"
    commit_raw = (f"tree {new_tree}\nparent {BASE}\nauthor {person}\ncommitter {person}\n\n"
                  + message).encode()
    commit_sha = hashlib.sha1(
        b"commit " + str(len(commit_raw)).encode() + b"\0" + commit_raw).hexdigest()
    write_new(OUT / "EXPECTED_COMMIT.raw", commit_raw)
    state["expected_commit"] = commit_sha
    pub.checkpoint()
    # Creating an unreferenced candidate commit is permitted after the root ack.
    # The only ref write remains downstream of every complete-content/diff gate.
    pub.create_once("commit", "/git/commits", commit_sha,
                    {"message": message, "tree": new_tree, "parents": [BASE],
                     "author": author, "committer": author}, defer_visibility=True)
    actual_commit = pub.visible("/git/commits/" + commit_sha)
    need(actual_commit["sha"] == commit_sha and actual_commit["tree"]["sha"] == new_tree
         and [p["sha"] for p in actual_commit["parents"]] == [BASE]
         and actual_commit["message"].rstrip("\n") == message.rstrip("\n")
         and actual_commit["author"] == author and actual_commit["committer"] == author,
         "candidate commit metadata differs from deterministic local object")
    for object_sha, expected in expected_trees.items():
        need(pub.tree(object_sha, visibility=True, refresh=True) == expected,
             "complete remote ancestor tree differs from local merged tree")
    for path, raw in (candidates | evidence).items():
        entry = pub.lookup(new_tree, path)
        need(entry and entry["type"] == "blob" and entry["mode"] == "100644"
             and entry["sha"] == git_blob(raw), "final candidate/evidence tree path mismatch")
        pub.blob(raw)
    detail = pub.visible("/commits/" + commit_sha + "?per_page=100")
    changed = detail.get("files", [])
    need(detail["sha"] == commit_sha and detail["commit"]["tree"]["sha"] == new_tree
         and [p["sha"] for p in detail["parents"]] == [BASE]
         and len(changed) == 8 and {f["filename"] for f in changed} == set(files),
         "complete exact eight-path commit diff required")
    for row in changed:
        path = row["filename"]
        need(row["status"] == ("modified" if path in MODIFIED else "added")
             and row["sha"] == git_blob(files[path]) and "previous_filename" not in row,
             "changed file status/blob mismatch")
    stats = detail["stats"]
    need(stats["total"] == stats["additions"] + stats["deletions"]
         == sum(row["additions"] + row["deletions"] for row in changed)
         and 0 < stats["total"] < 800, "commit changed-line limit")
    state["commit_stats"], state["verified_changed_paths"] = stats, sorted(files)
    state["complete_tree_and_diff_gates_passed"] = True
    check_custody(state)
    pub.checkpoint()
    need(pub.get("/git/ref/heads/" + BRANCH, allow_missing=True) is None,
         "target ref raced; no update permitted")
    pub.create_once("ref", "/git/refs", commit_sha, {"ref": REF, "sha": commit_sha})
    state["ref_created_or_read_reconciled"] = True
    for path, expected in sorted((candidates | evidence).items()):
        remote = pub.visible("/contents/" + quote(path, safe="/") + "?ref=" + commit_sha)
        need(remote["type"] == "file" and remote["path"] == path
             and remote["sha"] == git_blob(expected) and remote["encoding"] == "base64"
             and remote["size"] == len(expected), "published file metadata readback")
        raw = base64.b64decode("".join(remote["content"].split()), validate=True)
        need(raw == expected and git_blob(raw) == remote["sha"], "published file byte readback")
    ref = pub.visible("/git/ref/heads/" + BRANCH)
    need(ref["ref"] == REF and ref["object"]["type"] == "commit"
         and ref["object"]["sha"] == commit_sha, "final ref identity")
    check_custody(state)
    state.update({"status": PUBLISHED, "commit_sha": commit_sha, "tree_sha": new_tree,
                  "branch": BRANCH, "remote_readback_files": 10,
                  "runtime_qualification": False, "whole_repository_whitespace_gate_closed": False,
                  "scientific_and_production_hold_unchanged": True})
    pub.checkpoint()


def main():
    need(sys.platform == "darwin" and len(sys.argv) == 3, "main macOS and two SHA arguments required")
    need(all(HEX64.fullmatch(value) for value in sys.argv[1:]), "invalid SHA argument")
    need(not OUT.exists() and not OUT.is_symlink(), "publication_12 must be create-only")
    OUT.mkdir()
    state = {"schema": SCHEMA, "status": "STARTED", "publication_base": BASE,
             "preparation_base": PREPARATION_BASE, "branch": BRANCH,
             "tests": 0, "models": 0, "optimizer_calls": 0, "compilations": 0,
             "formatter_invocations": 0, "workflow_dispatches": 0, "pull_requests": 0,
             "scientific_and_production_hold_unchanged": True,
             "resource_limits": {"wall_s": MAX_WALL, "http_attempts": MAX_HTTP,
                                 "visibility_sleep_s": MAX_VISIBILITY_SLEEP,
                                 "each_gh_timeout_s": 90, "visibility_delays": VISIBILITY_DELAYS}}
    started, code = time.monotonic(), 1
    try:
        candidates, originals, members = validate_inputs(state, sys.argv[1], sys.argv[2])
        evidence = make_evidence(state, members, candidates)
        publish(state, candidates, originals, evidence)
        code = 0
    except BaseException as error:
        state["status"] = "FAILED_RETAINED"
        state["error"] = str(error)
        write_new(OUT / "TRACEBACK.txt", traceback.format_exc().encode())
        if "inputs_before" in state:
            try:
                check_custody(state)
            except BaseException as custody_error:
                state["custody_after_error"] = str(custody_error)
    finally:
        state["wall_s"] = time.monotonic() - started
        write_new(OUT / "RESULT.json", encoded(state))
    return code


if __name__ == "__main__":
    raise SystemExit(main())

