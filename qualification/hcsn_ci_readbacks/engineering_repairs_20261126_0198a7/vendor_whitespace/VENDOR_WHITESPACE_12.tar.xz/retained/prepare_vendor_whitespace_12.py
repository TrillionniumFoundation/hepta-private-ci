"""Prepare seven scoped vendor/notice candidates; never compile or run tests."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import stat
import subprocess
import sys
import time
import tomllib
import traceback

ROOT = Path("/Users/qianqi/work/hepta-hcsn-fixes-20261126-0198a7")
OUT, INPUT = ROOT / "vendor_candidate_12", ROOT / "VENDOR12_PREP_INPUT.json"
SRC, EVIDENCE = OUT / "source", OUT / "evidence"
BASE = "4ffa56f6d0be94e68d23d1bfe72aa2cbfd50d479"
STAR = "codex-rs/third_party/starlark-0.14.2-blake3-backport/"
SERDE = "codex-rs/third_party/serde-saphyr-2.0.0/"
SOURCES = {STAR: "src/values/layout/heap/send.rs", SERDE: "tests/test_suite/y_M9B4.rs"}
PROVENANCE = "SOURCE_WHITESPACE_20261126.json"
ADDED = {crate + PROVENANCE for crate in SOURCES}
NOTICE = "apps/hepta-native/resources/NATIVE-DEPENDENCIES.json"
TARGETS = ADDED | {NOTICE} | {crate + path for crate, path in SOURCES.items()} | {crate + "HEPTA_PATCH.md" for crate in SOURCES}
SCHEMA = "hepta.vendor-whitespace-preparation.v1"
SUCCESS = "FORMATTED_SCOPED_WHITESPACE_PASS_NO_RUNTIME_QUALIFICATION"
GIT, JUST, LIMIT = "/usr/bin/git", "/opt/homebrew/bin/just", 16 * 1024 * 1024
NOTICE_ROWS = [
    (3, "HEPTA_UPSTREAM.json", 18144, "7950d3af65034dc8ea038377adccc16d634cab62d7119ef0dd4cc88112c7b435",
     18388, "13b7cb9c6c8659b2e9ed0479fe1dd9a0504c0186dd63cf961e8fa56cac156412"),
    (5, "HEPTA_PATCH.md", 5454, "294e50a9ce31acfe15c90d48174989b9d82200b6cd5f308c9e220e182f25854b",
     5604, "1f56d5dcdfeb4818a4ceda387ea06e5336c289bcd545fa4e844b5d34a8a51fea"),
]


def need(ok, message):
    if not ok:
        raise ValueError(message)


def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def decoded(raw):
    def pairs(items):
        value = {}
        for key, item in items:
            need(key not in value, "duplicate JSON key")
            value[key] = item
        return value
    def bad(value):
        raise ValueError("nonfinite JSON constant")
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad)


def relative(value):
    path = PurePosixPath(value)
    need(isinstance(value, str) and path.parts and not path.is_absolute() and str(path) == value
         and "\\" not in value and "\0" not in value and all(p not in {".", "..", ".git"} for p in path.parts),
         "unsafe relative path")
    return value


def read(path):
    need(path.is_absolute() and all(not p.is_symlink() for p in path.parents), "input ancestor")
    with os.fdopen(os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)), "rb") as stream:
        a = os.fstat(stream.fileno())
        need(stat.S_ISREG(a.st_mode) and a.st_nlink == 1 and 0 <= a.st_size <= LIMIT, "bounded regular input")
        raw, b = stream.read(LIMIT + 1), os.fstat(stream.fileno())
    need(len(raw) == a.st_size and all(getattr(a, k) == getattr(b, k)
         for k in ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")), "input changed")
    return raw


def write(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(raw)


def snapshot():
    result = {}
    for current, directories, names in os.walk(SRC, followlinks=False):
        current = Path(current)
        if current == SRC:
            directories[:] = [x for x in directories if x != ".git"]
        need(all(not (current / x).is_symlink() for x in directories), "workspace directory link")
        for name in names:
            path = current / name
            result[str(path.relative_to(SRC))] = identity(read(path))
    return result


def narrow_gates(old, new, reviews):
    lines = old[STAR + SOURCES[STAR]].splitlines(keepends=True)
    need(lines[55] == b"///  \n", "original Starlark line 56")
    lines[55] = b"///\n"
    need(new[STAR + SOURCES[STAR]] == b"".join(lines), "Starlark change exceeds two spaces")
    literal = b'r#"|\n literal\n \ttext\n\n\n"#'
    original = old[SERDE + SOURCES[SERDE]]
    need(original.count(literal) == 1 and len(literal[3:-2]) == 20
         and new[SERDE + SOURCES[SERDE]] == original.replace(literal, b'"|\\n literal\\n \\ttext\\n\\n\\n"', 1),
         "serde literal must preserve all 20 bytes and three final LF")
    for crate, source in SOURCES.items():
        doc = crate + "HEPTA_PATCH.md"
        need(new[doc].startswith(old[doc]) and len(new[doc]) > len(old[doc]), "documentation must append only")
        provenance = decoded(new[crate + PROVENANCE])
        need(provenance["base_commit"] == BASE and provenance["source"]["path"] == source
             and provenance["source"]["original"] == identity(old[crate + source])
             and provenance["source"]["candidate"] == identity(new[crate + source])
             and provenance["documentation"]["original"] == identity(old[doc])
             and provenance["documentation"]["candidate"] == identity(new[doc])
             and provenance["windows_qualified"] is False and provenance["native_qualified"] is False
             and provenance["historical_results_transferred"] is False, "independent provenance source binding")
    before, after = decoded(old[NOTICE]), decoded(new[NOTICE])
    expected_bytes = old[NOTICE]
    for index, name, old_size, old_sha, size, digest in NOTICE_ROWS:
        entry = before["files"][index]
        need(entry == {"path": "dependency-notices/accesskit/" + name, "bytes": old_size, "sha256": old_sha},
             "original AccessKit notice entry")
        source = ROOT / ("ACCESSKIT_NOTICE_ONLY_SOURCE_" + name)
        need(str(source) in reviews and reviews[str(source)]["bytes"] == size
             and reviews[str(source)]["sha256"] == digest, "actual notice source must be a pinned review file")
        for a, b in ((('"bytes": ' + str(old_size)).encode(), ('"bytes": ' + str(size)).encode()),
                     (old_sha.encode(), digest.encode())):
            need(expected_bytes.count(a) == 1, "notice scalar replacement is ambiguous")
            expected_bytes = expected_bytes.replace(a, b, 1)
        entry.update(bytes=size, sha256=digest)
    need(new[NOTICE] == expected_bytes and after == before, "notice change exceeds the four identity scalars")
    return {"starlark_only_two_spaces": True, "serde_fixture_bytes": 20, "serde_terminal_lf": 3,
            "docs_original_prefix_preserved": True, "provenance_matches_sources": True,
            "notice_only_four_scalars": True, "accesskit_missing_readme_hunk_closed": False}


def main():
    need(len(sys.argv) == 3 and all(re.fullmatch("[0-9a-f]{64}", x) for x in sys.argv[1:]), "SELF_SHA INPUT_SHA")
    self_path = Path(__file__).absolute()
    need(self_path == ROOT / "prepare_vendor_whitespace_12.py"
         and identity(read(self_path))["sha256"] == sys.argv[1], "runner identity")
    OUT.mkdir(exist_ok=False)
    SRC.mkdir()
    EVIDENCE.mkdir()
    result = {"schema": SCHEMA, "status": "STARTED", "base_commit": BASE, "runner_sha256": sys.argv[1],
              "input_sha256": sys.argv[2], "commands": [], "tests": 0, "models": 0, "compilations": 0,
              "optimizer_calls": 0, "github_writes": 0, "runtime_qualification": False,
              "whole_repository_whitespace_gate_closed": False, "scoped_paths": sorted(TARGETS), "retries": 0}
    pins, original, candidates, baseline, handlers = {}, {}, {}, {}, {}
    start, terminating = time.monotonic(), False

    def save():
        (EVIDENCE / "PROGRESS.tmp").write_bytes(encoded(result))
        os.replace(EVIDENCE / "PROGRESS.tmp", EVIDENCE / "PROGRESS.json")

    def stop(signum, frame):
        nonlocal terminating
        terminating = True
        raise RuntimeError("preparation termination requested")

    def bound(path, expected=None, size=None):
        parts = path.relative_to(ROOT).parts
        need(parts and parts[0] != OUT.name and all(p not in {".", ".."} for p in parts), "input root/scope")
        raw, row = read(path), None
        row = identity(raw)
        need((expected is None or row["sha256"] == expected) and (size is None or len(raw) == size), "input pin")
        need(str(path) not in pins or pins[str(path)] == row, "input changed between reads")
        pins[str(path)] = row
        return raw

    def command(name, argv, env, cwd=SRC, timeout=30):
        need(not terminating and name not in {x["name"] for x in result["commands"]}
             and (argv[0] == GIT or argv == [JUST, "fmt"]), "one registered command attempt only")
        row = {"name": name, "argv": argv, "cwd": str(cwd), "timeout_s": timeout, "status": "INTENT"}
        result["commands"].append(row)
        stdout, stderr, child, began = EVIDENCE / (name + ".stdout"), EVIDENCE / (name + ".stderr"), None, time.monotonic()
        save()
        try:
            with stdout.open("xb") as out, stderr.open("xb") as err:
                child = subprocess.Popen(argv, cwd=cwd, env=env, stdout=out, stderr=err, start_new_session=True)
                row.update(status="RUNNING", child_pid=child.pid)
                save()
                child.wait(timeout=timeout)
            row["status"] = "RETURNED"
        except BaseException as error:
            if child is not None and child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait(timeout=10)
            row.update(status="FAILED_RETAINED", error=type(error).__name__ + ": " + str(error))
        finally:
            row.update(returncode=None if child is None else child.returncode, wall_s=time.monotonic() - began)
            for key, path in (("stdout", stdout), ("stderr", stderr)):
                if path.exists():
                    row[key] = {"path": str(path), **identity(read(path))}
            save()
        return row, stdout

    try:
        for signum in (signal.SIGTERM, signal.SIGINT):
            handlers[signum] = signal.getsignal(signum)
            signal.signal(signum, stop)
        bound(self_path, sys.argv[1])
        plan = decoded(bound(INPUT, sys.argv[2]))
        need(plan["schema"] == SCHEMA and plan["base_commit"] == BASE
             and plan["expected_scaffold_files"] == 51 and plan["expected_formatter_guard_files"] == 44
             and plan["scientific_and_production_hold_unchanged"] is True
             and all(type(plan[k]) is int and plan[k] == 0 for k in ("models", "tests", "compilations")), "preparation scope")
        reviews = {}
        for row in plan["review_files"]:
            path = Path(row["path"])
            reviews[str(path)] = identity(bound(path, row["sha256"], row["bytes"]))
        parts = plan["scaffold_parts"]
        need(len(parts) == 5 and len(plan["changes"]) == 7, "fixed input denominator")
        raw_parts = []
        for i, row in enumerate(parts):
            need(row["name"] == "WINDOWS10_SCAFFOLD.part" + str(i).zfill(3), "ordered scaffold name")
            raw_parts.append(bound(ROOT / row["name"], row["sha256"], row["bytes"]))
        scaffold = decoded(b"".join(raw_parts))
        need(scaffold["base_commit"] == BASE and len(scaffold["files"]) == 51, "scaffold fixed identity")
        for path, row in scaffold["files"].items():
            raw = row["content"].encode()
            need(relative(path) not in TARGETS and identity(raw)["git_blob"] == row["git_blob"]
                 and row.get("expected_sha256", identity(raw)["sha256"]) == identity(raw)["sha256"]
                 and row.get("expected_bytes", len(raw)) == len(raw), "scaffold original bytes")
            baseline[path] = raw
        need({x["path"] for x in plan["changes"]} == TARGETS, "exact seven candidate paths")
        for row in plan["changes"]:
            path = relative(row["path"])
            raw = row["candidate"]["content"].encode()
            need(identity(raw) == {k: row["candidate"][k] for k in ("bytes", "sha256", "git_blob")}, "candidate identity")
            candidates[path] = raw
            need((row["original"] is None) == (path in ADDED), "only two provenance files may be new")
            if row["original"] is not None:
                old = row["original"]["content"].encode()
                need(identity(old) == {k: row["original"][k] for k in ("bytes", "sha256", "git_blob")}, "original identity")
                original[path] = baseline[path] = old
        result["static_scope_gates"] = narrow_gates(original, candidates, reviews)
        need(len(baseline) == 56 and sys.version_info[:2] == (3, 14)
             and tomllib.loads(baseline["codex-rs/rust-toolchain.toml"].decode())["toolchain"]["channel"] == "1.96.0",
             "baseline/Python 3.14/Rust 1.96.0")
        fmt_env = dict(os.environ)
        fmt_env["PATH"] = "/opt/homebrew/bin:" + fmt_env.get("PATH", "")
        need(not any(os.environ.get(k) for k in ("RUSTUP_TOOLCHAIN", "RUSTFMT", "GIT_DIR", "GIT_WORK_TREE",
             "GIT_INDEX_FILE", "GIT_COMMON_DIR", "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES",
             "GIT_CONFIG", "GIT_CONFIG_COUNT", "GIT_CONFIG_PARAMETERS")), "environment override")
        python3 = shutil.which("python3", path=fmt_env["PATH"])
        need(python3 and Path(python3).resolve() == Path(sys.executable).resolve(), "formatter Python must be this 3.14")
        git_env = {k: v for k, v in fmt_env.items() if not k.startswith("GIT_")}
        git_env.update(GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL="/dev/null", GIT_AUTHOR_NAME="workflow-test",
                       GIT_AUTHOR_EMAIL="workflow-test@hepta.invalid", GIT_COMMITTER_NAME="workflow-test",
                       GIT_COMMITTER_EMAIL="workflow-test@hepta.invalid")
        for path, raw in baseline.items():
            write(SRC / path, raw)
        result["baseline_files"] = {p: identity(r) for p, r in baseline.items()}
        need(snapshot() == result["baseline_files"] and not ADDED.intersection(baseline), "baseline bytes/new paths")
        git = [GIT, "-c", "core.hooksPath=/dev/null", "-c", "core.autocrlf=false", "-c", "commit.gpgsign=false", "-c", "core.attributesFile=/dev/null"]
        for name, args in [("01-init", ["init", "--template=", "--initial-branch=vendor-whitespace-baseline"]),
                           ("02-add-baseline", ["add", "--force", "--all", "--", "."]),
                           ("03-commit-baseline", ["commit", "--no-gpg-sign", "-m", "Local original vendor whitespace baseline"])]:
            row, _ = command(name, git + args, git_env)
            need(row["status"] == "RETURNED" and row["returncode"] == 0, name + " failed")
        row, output = command("04-index", git + ["ls-files", "--stage", "-z"], git_env)
        index = {}
        for item in read(output).split(b"\0"):
            if item:
                head, path = item.split(b"\t", 1)
                mode, object_id, stage = head.decode().split()
                need(mode == "100644" and stage == "0", "baseline Git index entry")
                index[path.decode()] = object_id
        need(row["returncode"] == 0 and index == {p: identity(r)["git_blob"] for p, r in baseline.items()}, "baseline Git objects")
        for path, raw in candidates.items():
            if path in ADDED:
                write(SRC / path, raw)
            else:
                (SRC / path).write_bytes(raw)
        expected = {**result["baseline_files"], **{p: identity(r) for p, r in candidates.items()}}
        need(snapshot() == expected and len(expected) == 58, "candidate materialization")
        result["workspace_before_format"] = expected
        result["python"], result["toolchain"] = sys.version, "1.96.0"
        fmt, _ = command("05-just-fmt", [JUST, "fmt"], fmt_env, SRC / "codex-rs", 600)
        result["workspace_after_format"] = after = snapshot()
        intent, _ = command("06-add-intent-only-two-new", git + ["add", "-N", "--", *sorted(ADDED)], git_env)
        check, _ = command("07-scoped-diff-check", git + ["diff", "--check", "--no-ext-diff", "--no-textconv", "HEAD", "--", *sorted(TARGETS)], git_env)
        diff, output = command("08-scoped-diff-binary", git + ["diff", "--binary", "--no-ext-diff", "--no-textconv", "--no-color", "HEAD", "--", *sorted(TARGETS)], git_env)
        write(EVIDENCE / "DIFF.patch", read(output))
        result["diff_patch"] = identity(read(EVIDENCE / "DIFF.patch"))
        result["candidate_bytes_unchanged_by_formatter"] = all(after.get(p) == expected[p] for p in TARGETS)
        result["other_baseline_and_guards_unchanged"] = all(after.get(p) == expected[p] for p in baseline if p not in TARGETS)
        result["scoped_diff_check"] = {"paths": sorted(TARGETS), "returncode": check["returncode"], "whole_repository_gate": False}
        need(after == expected, "formatter changed candidate pins, baseline bytes, or file denominator")
        need(all(r["status"] == "RETURNED" and r["returncode"] == 0 for r in (fmt, intent, check, diff)), "formatter or seven-path whitespace/diff command failed")
        result["status"] = SUCCESS
    except BaseException as error:
        result.update(status="FAILED_RETAINED", error=type(error).__name__ + ": " + str(error))
        write(EVIDENCE / "TRACEBACK.txt", traceback.format_exc().encode())
    finally:
        result["inputs_before"] = pins
        try:
            result["inputs_after"] = after_inputs = {p: identity(read(Path(p))) for p in pins}
            result["all_input_files_unchanged"] = bool(pins) and after_inputs == pins
            if not result["all_input_files_unchanged"]:
                result["status"] = "FAILED_RETAINED"
        except BaseException as error:
            result.update(status="FAILED_RETAINED", all_input_files_unchanged=False, input_error=str(error))
        result["wall_s"] = time.monotonic() - start
        save()
        write(EVIDENCE / "VALIDATION.json", encoded(result))
        ready = {"schema": SCHEMA, "base_commit": BASE, "status": result["status"],
                 "runner_sha256": sys.argv[1], "input_sha256": sys.argv[2], "tests": 0, "models": 0,
                 "compilations": 0, "optimizer_calls": 0, "runtime_qualification": False,
                 "whole_repository_whitespace_gate_closed": False,
                 "validation": {"path": str(EVIDENCE / "VALIDATION.json"), **identity(read(EVIDENCE / "VALIDATION.json"))},
                 "candidate_files": [{"repo_path": p, "path": str(SRC / p), **identity(r)} for p, r in sorted(candidates.items())] if result["status"] == SUCCESS else []}
        write(EVIDENCE / "READY.json", encoded(ready))
        for signum, previous in handlers.items():
            signal.signal(signum, previous)
    print(json.dumps({"status": result["status"], "ready": str(EVIDENCE / "READY.json"), "scoped_paths": 7,
                      "whole_repository_whitespace_gate_closed": False, "tests": 0, "models": 0}), flush=True)
    return 0 if result["status"] == SUCCESS else 1


if __name__ == "__main__":
    raise SystemExit(main())

