# 原 ZIP 的离线字节核对要求

本文件供 root 的一次数据核对使用；本 child 没有下载/解析 ZIP、导入 Torch、解码 checkpoint、执行 adapter 或启动恢复。

## 1. 固定 Git 和 archive 身份

- 使用不可变提交 `917e4886658ae9f0c342eb1fa0f545d79c39e2c8`，不要把可变 branch 名代替最终内容身份。
- 清单：`qualification/hcsn_differentiable/replay_v1/artifact/EXPORT.json`，Git blob `3f0460737ffc61d814e4383d01a93cbafac6f2db`，470 字节；在原出版提交和 ce6 两处读取的 blob 相同。
- 唯一 part：同目录 `part-000.zip`，Git blob `2afc4e810f1c75a1ff5b9fb85464f6dda6c43245`，**11,397,159 字节**；下载后独立重算 SHA256 必须为 `37d387507ec150abfdad4065c23612e18fca6643d489f3555874c8e57a514b75`。同时重算 Git blob SHA1 可交叉确认下载来自已观察的 Git 对象。
- `EXPORT.json` 的 schema 是 `hcsn-real-replay-export-parts-v1`，archive 和唯一有序 part 的 bytes/SHA 均相同；source_parent 为 `5cb83d9c76beedf4c1c917e4bf561f5f26261ce7`，receipt_parent 为 `a832b028abdf1a1c9ab66534332457c6d76a91ca`。

## 2. ZIP / INDEX 结构

按当前原 `cpu_migration.extract_verified` 的拒绝条件，核对：

1. 中央目录中的文件名唯一，条目不超过 2,001；总声明解压大小不超过 128 MiB；实际逐成员读取也应保持这个上界。
2. 每个 ZIP 名是规范相对 POSIX 路径，无反斜杠、NUL、绝对路径、空组件、点或父目录组件；无目录、加密条目或符号链接/特殊文件。mode 文件类型只允许 0 或 regular file。
3. `INDEX.json` 存在且最多 2 MiB；JSON 拒绝重复 key、NaN、Infinity 和溢出非有限数值。读取全部成员以验证 ZIP CRC/解压完整性，不执行其中任何内容。
4. INDEX schema 为 `hcsn-six-real-checkpoint-export-v1`，source_commit 为原 `5cb83d9c...`，model_executions 为 0；其 preexecution_sha256 应为 `49a624205233078044c3dcf5d53f26ca83a76f4e0e897dc39c98ffb9d5f41653`。
5. INDEX 每个 original_path 必须是唯一、规范绝对 POSIX 路径；member 必须精确等于 `root/` + 去除开头斜线后的原路径。每个 bytes 是真实整数且不越上界，必须与 ZIP file_size 和实际读取长度一致；逐个重算 SHA256 匹配原 index。
6. ZIP 成员集合必须恰等于所有 index member 加 `INDEX.json`，无额外和缺失条目。记录原文件大小之和与全部 ZIP 成员大小之和，区分是否包含 INDEX。

**计数注意：** 原 export 日志的 `entries: 555` 来自 `len(files)`，writer 随后另外加入 INDEX.json。因此预期是 **555 个原文件 + 1 个 INDEX = 556 个 ZIP 成员**。原文件总 bytes 日志为 **56,675,710**，不包括 INDEX。旧 prose 的“555 members”不能覆盖原 writer/实际中央目录计数。

## 3. 绑定原计划与六 fit

- 找到唯一的原 `.../PREEXECUTION.json`，完整字节 SHA256 为上面的 `49a624...`；其 schema/steps/六 fit 清单保持原样。原路径是 `/home/qian-qi/hcsn-real-checkpoint-replay-20261112-c06d-run-v1/PREEXECUTION.json`。
- 把原计划的 program_inputs 与六 fit.inputs 联集，和 INDEX 原文件映射逐字核对；重复路径必须是同一 bytes/SHA。只读取 JSON，不执行计划。
- 使用随附 `SELECTION.original.json`：该文件从原模型源 `5cb83d9c...` 到 ce6 的 Git blob 均为 `2adba4aadb5d693fcf2df5abc027d72c814d7d78`。六个被选 checkpoint 的原路径、bytes、SHA 均应存在于 INDEX 并与实际 archive member bytes 一致。
- 原 checkpoint epochs 为 **116、76、126、50、127、72**，其 logical_main_updates 为 **1392、912、1512、600、1524、864**。这些是原选择/计划声明；离线字节核对不打开 .pt/pickle，不另行宣称解码后状态或实际连续性成立。
- 保留原 34 仓库源码和三份 Torch Python 源码的 SHA 要求；此处只证明 archive 内原件身份，不能证明未来 CPU Torch 安装与这些原件兼容。

## 4. 结果不转移的范围

若这些数据检查通过，能够把“Git 中未观察到原 archive”的旧说法更正为“已观察且独立 byte-verified 的原 archive”。不能因此宣告 CPU runtime、六 checkpoint continuation、原完整训练重放、当前预算余额或科学目标通过。

原 pointer 当前仍 MISSING，budget REQUEST 仍 HOLD / replay_admitted=false / resource_admitted=false / execution_key=null / current per-fit balance UNKNOWN。当前 CPU workflow 没有调用该 current-budget contract；直接把 pointer 改为 FROZEN 会让匹配路径的下一次 CI 越过目前的 pre-model 挡板，因此本次只做离线证据更正，不能据此改 pointer 或启动恢复。
