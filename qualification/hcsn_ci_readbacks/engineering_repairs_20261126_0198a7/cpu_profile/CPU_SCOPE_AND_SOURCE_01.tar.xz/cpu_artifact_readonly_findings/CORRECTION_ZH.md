# 追加更正：原 archive 已有 Git 出版对象，pointer 和预算仍未闭合

本更正保留此前 CPU 宿主/版本候选静态快照。新发现只来自已登记的 artifact 路径、原 job 收据和不可变提交读取，没有全盘搜索、desktop 重启、checkpoint 反序列化或模型执行。

原 `CPU-ARTIFACT.json` 一直保留 MISSING 及“immutable GitHub publication is not yet observed”文案。但已知精确目录中，原 archive 在 [917e4886](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/917e4886658ae9f0c342eb1fa0f545d79c39e2c8) 于 2026-11-12 08:00:25 UTC 出版，登记分支 `artifact/hcsn-c2-export-20261112-c06d-v1` 当前仍指向该提交；[PR #6214](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6214) 是对应的零模型 artifact 出版 PR。ce6 已包含同一 11,397,159 字节 Git blob 和原 EXPORT 清单。

因此，旧 MISSING 文案不能继续作为“原 ZIP 在 Git 中不存在”的事实依据。当前确定的是：**Git 对象及原声明已经可读；pointer 仍为 MISSING；本 child 尚未独立重算二进制 archive SHA256。** Root 正按不可变提交做独立数据核验，结果应另加回执，不回写旧日志或旧候选快照。

原导出 job 是 `1a1ce7e3837-2564-16c9`，host desktop，原 idempotency key `hcsn-real-checkpoint-readonly-export-c06d-v1`；原路径 `/home/qian-qi/hcsn-real-replay-c06d-export-v1.zip`。其 retained terminal 是 succeeded / exit 0，原日志记录 SHA256 `37d387507ec150abfdad4065c23612e18fca6643d489f3555874c8e57a514b75`、555 份原文件、56,675,710 原始字节、0 模型执行。只需读取已存在的 Git 原件，无须再次启动原导出 job，也不能用 4092 diagnostic archive、d706 NATIVE_ORIGINALS 或其他 checkpoint 替代。

## 已知预算路径的后续检查

在受审 ce6 及其可达路径历史中，`current_budget_admission_v1/REQUEST.json` 只有 2026-11-15 的 `fd353cd2...` 提交；仍为 HOLD，replay_admitted=false、resource_admitted=false、execution_key=null、current per-fit balance UNKNOWN。它记录已完成诊断 optimizer calls 为 52，lifetime total 和原 controller terminal 仍 UNKNOWN。

已登记原 ledger 的最后修改是 2026-11-14 的 `72a6984e...`，只澄清原始 charged remainder 与同一总额内的 finalization reserve。原 172,938.8845898183 秒不是新的可执行余额；全部后续失败、取消和未知尝试必须不退款计入。读取的明确路径没有后续合法准入或已核定当前余额；这不是对仓库所有未知分支的不存在证明。

更关键的是，当前 CPU recovery workflow 调用 artifact pointer 后直接进入安装/ci_replay，没有接入这个独立 budget contract。原件恢复与执行准入必须分开保留。当前 pointer 不改、预算不改、不启动 recovery。三行 host/runtime 源修补不会给六 checkpoint 恢复授予执行权限。

完整小原件见本目录；`ZIP_VERIFICATION_REQUIREMENTS.md` 列出不解码 .pt 的原文件数据核对要求，`BUDGET_OBSERVATION.json` 与两份原预算 JSON 保留精确状态和历史。
