# CPU 恢复 workflow：宿主固定与原精确 Torch profile 对齐

本候选基于集成源 `ce6b9fe9dcb7d6bb8e78978c8b81a001ac7e2ea2`，只改同一 workflow 的 **3 行**：两个 job 的宿主固定为 Ubuntu 24.04，并把安装器恢复为原 profile 明确要求的 `torch==2.8.0+cpu`。原 profile、模型源码、冻结摘要、pointer、触发器、测试与恢复程序均不修改。

新候选源在 `candidate/.github/workflows/hcsn-real-checkpoint-cpu.yml`，原件在 `original/`，逐行 diff 在 `minimal.diff`。候选为 4,000 字节，Git blob `413df1cd25ee4bd46c49f2b749ae24a6c6496c31`，SHA256 `aa7b2aaf12bd3f4be713e525d0569624cfea05f9fe128024560299f6e1e7894b`。

## 原约束与错误来源

| 身份 | 查到的原始行为 |
|---|---|
| [0de7f86e 初始 CPU profile](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/0de7f86e0636c585a7f15a580a889990e29e0a4b) | 2026-11-12 明确 Python 3.12.3 / Torch 2.8.0+cpu / NumPy 2.3.5 / mpmath 1.3.0；安装行也是 2.8。 |
| [2a52aa78 严格 artifact admission](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/2a52aa78fe597c24d088bdc2d9230df60331c81d) | 保留 2.8 安装行，修正普通与优化模式下的 pointer 守卫。 |
| [520f5c1d 集成提交](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/520f5c1dd0f284d1b7f790d0f027267011044639) | 2026-11-15 把本 workflow 的安装行从 2.8 改到 2.10。提交说明提及多 workflow 的 Torch60 compatibility；没有改本 CPU profile 或 replay_v1 源码。 |
| [24de2762 已验证宿主修补](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/24de27627ff72e5e482ab083c39c9e506382eeb4) | 2026-11-25 只改两处 ubuntu-24.04，继承了已有 2.10 安装行。其真实运行未执行安装步骤。 |

在 ce6 可达的路径历史中，`CPU-PROFILE.md` 和 `cpu_migration.py` 各只有初始提交；读取初始源后，两个 Git blob 与 ce6 **逐字相同**。详细路径历史、原修改 diff、原文和身份保存在 `evidence/`。因此，没有在这条受审历史中找到合法把此独立 CPU profile 改为 2.10 的 amendment。这里恢复安装器与原约束的一致性，不放宽资格要求。

`cpu_migration.py:141` 精确要求 `runtime['torch_version'] == '2.8.0+cpu'`、无 CUDA build；第 171 行继续逐字核对原三份 Torch Python 源码 SHA256，并要求原 34 份模型仓库源码。只满足版本字符串不能替代这些检查。`ci_replay.py` 从实际导入的 Torch 读取版本和 build；冻结 worker 还核对计划中的 Torch version/build 与实际 loaded model source。原 archive 仍缺失，本静态审查不能证明未来安装包一定通过三份原源码摘要，更没有新的实际 runtime SHA/安装成功回执。

## 旧 28 次测试的真实范围

[原 run 45689386079](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45689386079) 的完整结论是 **failure**：

- [adapter job 139470474673](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45689386079/job/139470474673) 成功：18 次 archive/relocation 测试、5 次 pointer 普通测试、相同 5 次 pointer 优化模式测试，共 **28 次执行、23 个不同方法**。这些是 stdlib 合成 adapter 测试，没有实际 Torch 安装或模型调用。
- [recovery job 139498353187](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45689386079/job/139498353187) 在模型设置前被原 `CPU-ARTIFACT.json` 的 `MISSING` 拒绝，原件 checkout、Python/Torch 设置及六 checkpoint 恢复均 skipped。错误是 `HOLD: immutable archive publication is not yet observed; zero model calls`。

原两个测试文件、adapter、pointer、worker、pointer 数据从原 host 资格源到 ce6 的 6 份 Git blob 均相同；它们支持复用旧 adapter 源码证据。**新增的安装行没有实测，旧 28 次测试不能作为新 Torch runtime 通过证据。** 原日志及完整 job/run API 在相邻 `cpu_host_candidate/evidence/`；这里的身份文件记录相同 run/job 和日志 SHA256。根任务发布时可以引用原 run 或一并纳入原日志，不需要为此再次执行。

## 自动 CI 及执行边界

两套原 `push` / `pull_request` 路径均匹配 workflow 自身；两事件的 concurrency group 含各自 `github.ref`，且 `cancel-in-progress: false`。普通推送预计会启动 adapter，再进入原 artifact 守卫。以当前未变的 MISSING pointer，恢复 job 预期仍在模型设置之前拒绝；新 head 的实际 CI 结论必须另行回读，不能预写 PASS。

当前 root 指令允许必要的普通 push 自动 CI；同一个 CPU head 不再额外开 PR 制造 push + PR 重复触发，不手动 dispatch/rerun。本候选没有改触发器，也没有远端写入或执行。本段只描述该 workflow 的明确路径和守卫，不把其他全仓 CI 的内部调用计数混入此结论。

修好 3 行不产生实际 CPU 恢复的执行权限。原 archive 仍为 **MISSING**：11,397,159 字节，SHA256 `37d387507ec150abfdad4065c23612e18fca6643d489f3555874c8e57a514b75`；原 lifetime optimizer calls 仍是 UNKNOWN，当前预算 admission 不变，HOLD_NO_GO 不变。不能用其他 checkpoint 顶替原件，也不能把尚未完成的六 checkpoint 恢复宣称为通过。

## 本准备阶段的实际执行记录

只进行了 GitHub 源码/历史/既有日志读取、静态文件写入和本地字节摘要检查。新增 adapter/test/model/optimizer/CI 执行均为 **0**。没有 pytest、模型导入、适配器运行、formatter 或手动重跑。
