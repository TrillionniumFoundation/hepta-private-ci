# CPU 26-call 诊断与完整六 fit 训练：范围纠正及发布前静态检查

## 结论

**不能把 current_budget_admission_v1 直接接为原 CPU 短诊断的前置门。** 它绑定原始 epoch 46/47 父状态的完整 six-fit replay；原 CPU-PROFILE 则绑定 epoch 116/76/126/50/127/72 的六个后期 checkpoint，进行两步 reference / producer / resume 及两个控制，总计一次完整诊断 26 个 optimizer calls。HOLD_NO_GO 和 full replay 0/6 不表示这些短诊断从未完成，也不自动禁止所有普通 CI fixture。

此前新 gate 的 7/7 本地 PASS 只证明它会按设计拒绝冻结 HOLD 请求，**没有证明这条 full-replay 合同适用于 CPU 短诊断**。这条跨范围连接不发布；原源码、7 项执行结果和错误设计历史保留。此前 `cpu_budget_gate_candidate/PUBLICATION_README_ZH.md` 关于这道门可作为 CPU 修复发布的判断，由本范围复核替代。

在 root 本轮已明确按原 CPU profile **单次普通 push** 执行诊断、不开重复 PR、不 dispatch/rerun、不改 600/660 秒限制的前提下，**原 CPU workflow + 两处 Ubuntu 24.04 + Torch 2.8.0+cpu 安装对齐 + 精确 FROZEN 原件 pointer，可以原子发布**。下文列出的原件与冻结 helper 静态条件均满足。实际 runtime 和 loaded-source 守卫仍必须原样执行；源码可发布不等于未来运行一定成功。

## 1. 三份原协议说的是不同事情

| 协议 / 原始来源 | 原状态与工作 | 证据范围 |
|---|---|---|
| [PR #6130](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6130)；原 worker source `5cb83d9c...` | 固定六个后期真实 checkpoint：116/76/126/50/127/72；每 fit 两步 reference 与 1+1 resume，各 4 次实际更新，加两个控制 | 新的短诊断。它创建时原 C2 controller 仍 UNKNOWN；原 controller 没有重启。 |
| [PR #6188](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6188)；[CPU-PROFILE](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/ce6b9fe9dcb7d6bb8e78978c8b81a001ac7e2ea2/qualification/hcsn_differentiable/replay_v1/CPU-PROFILE.md) | 独立 Ubuntu CPU profile：Python 3.12.3、Torch 2.8.0+cpu、NumPy 2.3.5、mpmath 1.3.0；2 workers × 1 thread；600 秒 worker / 660 秒 outer | 保留原 checkpoint、34 仓库源及三份 Torch Python 源摘要；不继承原 +cu128 runtime 或性能资格。原剩余前提是 immutable artifact 出版。 |
| [PR #6315](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6315) 与 [PR #6362](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6362) | 原 epoch 46/47 父状态；43,200 秒每 fit 总 cap、其中 600 秒 finalization reserve；重建完整六 fit 训练的当前非退款余额 | 原始 start ledger 及未来 full six-fit replay admission。它们没有把 CPU 的后期 checkpoint/26-call plan 作为本合同的任务身份。 |

关键原文：

- #6130 描述“six genuine C2 checkpoint identities”，并说明“original C2 job was never restarted”；短诊断本来就是独立的新 execution。
- #6188 明确称“separate CPU lane”。一次完成的 CPU attempt 只确认本次 26 calls；其 lifetime total 仍可 UNKNOWN，新增完整 C2 training replay 仍为 0。
- #6362 明确“does not admit or execute the six-fit replay”。它另列 CPU fixture 的 9 次 Adam/AdamW 更新，并写明这些更新“are separate from the historical 52 successful diagnostic calls and from full replay”。
- 4092 的 [RESULTS](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/ce6b9fe9dcb7d6bb8e78978c8b81a001ac7e2ea2/qualification/hcsn_differentiable/replay_v1/evidence/real-recovery-20261112-4092/RESULTS.md) 将已完成短诊断与后续 full C2 training 分开，后者需要另一份 source-bound execution 与原六父 roster。

因此，不能从完整训练的原 controller terminal、缺失历史 cursor 或当前总 wall UNKNOWN，推导出另一份已注册短诊断必须等待这些 full-replay blocker 全部闭合。共享历史成本不等于共享同一任务的准入条件。

## 2. 52 次已完成诊断更新的分账

两次均使用原 source `5cb83d9c76beedf4c1c917e4bf561f5f26261ce7` 和同一六 checkpoint 选择。两份 SUMMARY 各记录 6 个 completed diagnostics、26 次 optimizer calls、0 个 independently complete training replays。

| 项目 | 4092 | d706 |
|---|---|---|
| 执行身份 | job `1a1ce749808-2564-1688` | terminal `dpty-97b62bd80e16bfacc031131f5226dea8c3e65618c1e6968c7eb32b3a5cbd03ed` |
| 原唯一 key | `hcsn-real-checkpoint-replay-4092-6130-attempt001` | `c2-d706-fixed-5cb-real-replay-attempt001` |
| 状态 | succeeded / exit 0 | completed / exit 0 |
| 物理 optimizer calls | 24（六组各 4）+ 2 controls = **26** | 24 + 2 controls = **26** |
| Plan SHA256 | `cfa808f0547e8bf412009294451c54e9b479f981723cd936fcae9a957aab59b9` | `8cc02362280deab3a51162f4d55fd41da8a5016beb341a241c116fabfd57c442` |
| Orchestrator 内部 wall | 908.8070661991369 秒 | 905.1290415551048 秒 |
| 实际 runtime | Python 3.12.3 / Torch 2.8.0+cu128，在 CPU 运行 | Python 3.12.3 / Torch 2.8.0+cu128，在 CPU 运行 |

d706 的外层 native EXIT 另记 905.7613612581044 秒，包含范围与内部 orchestrator 不同，不混写成一个时间。

每次 attempt 内，六组 reference/resume 都有完整 model/Adam/RNG/cursor equality、相同 batch/loss/gradient 收据；omit-Adam 与 crash-before-publication 控制被检测。只读对照发现两次 attempt 之间六个 semantic SHA 均不同；不能把两个 attempt 的状态整体宣称逐字相同。

已有原件：

- **4092**：[诊断原文](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/ce6b9fe9dcb7d6bb8e78978c8b81a001ac7e2ea2/qualification/hcsn_differentiable/replay_v1/evidence/real-recovery-20261112-4092/RESULTS.md)、SUMMARY、原 native status/stdout 均直接可读。后续 [PR #6222](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6222) 出版原 archive：7,070,892 字节，SHA256 `f3f6992f31d7ab85a10eaa727dfc894fdb72ef5dafbba6bc43fc36d23a899dc7`，Git blob `44262f5f9e8a94abe8d70125d874392d2a927089`，commit `f515d4fac88171d93be0cb648dca434a2b926856`。当前树以 lossless gzip chunks 保存。原 manifest 绑定 118 份文件，包括 5,562 字节 AUDIT.json / SHA256 `342ce2498e6e95c9233564aa7210058fc0abb98115059f5a6b86d156bb96af70`；本 child 尚未读取该 audit 的原 body，不把旧 UNKNOWN/PENDING operation 改写成已确认 terminal。
- **d706**：[完整 README](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/ce6b9fe9dcb7d6bb8e78978c8b81a001ac7e2ea2/qualification/hcsn_differentiable/replay_v1/evidence/native-desktop-20261112-d706/README.md) 与 INDEPENDENT_AUDIT.json 直接可读。独立 audit 解码 26 个 checkpoint 文件、核对 554 份不同原输入、计数 26 calls，0 新 forward/optimizer。原 ZIP 为 10,976,581 字节 / SHA256 `d17e71b766631f3789dcb43bdd312dacfbc4ea0ce7e4fc14074587584900a2fe` / Git blob `deededd79d8a72d55059e7b7c439f66434a679f0`。

两次已完成 26-call 短诊断是 **52** 的来源。它们不抹去另两次 cancelled attempt 和原 controller 的 UNKNOWN，也不等于整个研究历史的 optimizer 总数。PR #6362 另发生的 9 fixture 更新属于另一个账目。

## 3. 哪个 CPU profile 仍未执行

两份成功原 SUMMARY 都写 Torch **2.8.0+cu128**，build `a1cb3cc05d46d198467bebbb6e8fba50a325d4e7`。它们是在 CPU 上运行原 300/330 秒 worker profile；不是 #6188 新定义的 **2.8.0+cpu / 600/660 秒** Actions profile。

受审的 #6188 原 run 43172821314 和后续宿主 run 45689386079 都在旧 MISSING pointer 处停止，Python/Torch 设置和实际 recovery skipped。不能用旧 18/28 adapter PASS 或上述两个 +cu128 诊断，把尚未运行的新 +cpu profile 填为成功。它们已经足以证明原旧-kernel checkpoint 的短连续性；新 +cpu profile 若执行，只新增本 profile 的一次独立 runtime/迁移诊断证据，不新增完整训练 replay。

## 4. 原 workflow 的前置条件与 provenance

按原三行候选和 FROZEN pointer（无新增 full-replay gate）审查：

1. `actions/checkout` 在 source 目录使用 `github.event.pull_request.head.sha || github.sha`；单次 push 时就是本次新 commit。
2. `artifact_pointer.py` 从这份当前 checkout 读取 CPU-ARTIFACT.json，严格要求原 schema、repo、manifest、archive bytes/SHA 和完整小写 commit。它运行 `git rev-parse HEAD`，把实际 source commit 与 pointer 记录到 `$RUNNER_TEMP/hcsn-cpu-source-identity.json`，再输出 artifact commit。
3. 第二份 checkout 只使用上述输出的不可变 `917e4886...`，目录为 original-artifact；source 与 artifact 不互相覆盖。
4. Root 已独立核验原 input ZIP 的 555 份原文件 + INDEX、全部 SHA/CRC、原 PREEXECUTION 与六 checkpoint 绑定。原 artifact 不需重新生成。
5. 当前 ce6 四份固定 helper 已重新按实际文件数据算 SHA，与 ci_replay 的原常量 **4/4 相同**：

| Helper | SHA256 |
|---|---|
| checkpoint_replay.py | `9fc8d5cc1541643ea46c3c9ef159a56e70ce1f2be20329ed2fd31185c86b7d9a` |
| c2_io.py | `db799aea7014bc60ad00dd7032f8753f356e3460743611d6baf243adfb840378` |
| c2_boundary.py | `177a23a3d0502a79912efdd2a14a365bc716961698a6949bb45d380ba147e6dd` |
| c2_durable.py | `c02d45119837c1b25a4b6ee0788b0c638718486c0301a8e90c5aa6d1f6252157` |

没有为了过门修改任何 frozen hash。Python 3.12.3、Torch 2.8.0+cpu、无 CUDA build、原三份 Torch Python 源摘要与 34 份模型源、六 checkpoint 和 prepared episode 等仍由原运行期门验证。任何实际不一致应如实失败。

## 5. 26-call 尝试的预算与日志边界

原 orchestration 最多两个并发 fit worker，每个 fit 按 reference 2 / producer 1 / resume 1 执行一次，完整六组共 24；仅在全部成功后运行两个一调用控制，完整 attempt 总计 26。没有内部自动重试。600 秒 inner、660 秒每个 subprocess outer、workflow recovery job 的 60 分钟总 timeout 都保持原值；这些上限不保证一定成功完成。

已有日志可记录：

- source commit + pointer、完整 pip freeze、实际 CPU-PREEXECUTION 的 runtime/version/build/program-input digests；
- 每个已启动 child 的 command、exit / timeout、stdout/stderr 和原 worker RESULT；
- 六组 FIT-RESULTS，即使部分 fit 失败也保留其 error/UNKNOWN；
- 完整成功时 SUMMARY 明确本次 26 verified calls、lifetime UNKNOWN 和新增完整 training replays=0；
- 原件核验、导入与本程序 wall，以及 CI 外层 checkout / 安装 / job 时序。

这些足以支持这一次声明短诊断的可观察结果与分账。部分 worker 超时或缺 RESULT 时仍可能只有 UNKNOWN，而不是 0；不能由后来的成功补写已丢失的调用数。CI job 与 worker overlap 时间不能相加当作 elapsed wall；SUMMARY 的程序 wall 不含之前 checkout/pip 安装，完整冷启动成本应从外层 job 另记。

## 6. 普通 push 还会触发独立 CI

CPU-ARTIFACT 路径同时匹配当前 `hcsn-differentiable.yml`。该 workflow 有 source/event 两个 lane，即使 push 时二者检查同一 head，仍是两次独立普通 CI，不能把整个 push 的执行量称为“只有 26 calls”。

已读的直接入口范围：

- run_qualification 只 discover `qualification/hcsn_differentiable/tests`，源码声明不启动 cloud job、不消费旧 study ledger、不授 formal completion。它会运行真实的小型 CPU mechanism/gradient fixtures。
- persistence successor CLI 只选择原 28 个 inherited software tests，另一个 terminal CLI 明确原 8 + 新 7 = 15 个 opaque-artifact terminal fixtures；不是重启原 C2 controller。
- neural_control_study 明确是 affine neural control task，不是 localization/C2 training。每 lane 固定 3 tasks × 3 initial gaps = 9 次 LBFGS step 调用，每个优化器 max_iter=100；实际 closure_calls 分别写入输出。两 lane 若都到达该步，则是 18 次 LBFGS 调用，不能等同于 18 次 Adam 参数更新或假定 closure 数固定。
- 当前普通 CI 每 lane timeout 30 分钟、CPU thread 1；完整实际 fixture/optimizer 计数以新 run/log 为准，不能套用 #6362 旧版本的“9 Adam/AdamW 更新”充当当前总数。

这些直接入口没有指向已耗尽的 `qualification/pft_six_experiments_20261125` E1–E6 driver。更细的 discovered-test / materialized-source 静态依赖复核应另加审查记录；没有为了避开正常 CI 修改触发器，也没有把普通 fixture 等同于原 frozen science campaign。

## 本审查的实际动作

本 child 只读取 GitHub 原文、原 JSON、当前源码，保存来源副本并做少量文件 SHA 与两份既有 SUMMARY 字段对照。没有执行任何新模型、checkpoint 解码、optimizer、测试、workflow 或旧 job；没有远端写入。原过度 gate 的 7 项测试结果由 root 原次执行保留，未重跑、未伪造为领域准入证明。
