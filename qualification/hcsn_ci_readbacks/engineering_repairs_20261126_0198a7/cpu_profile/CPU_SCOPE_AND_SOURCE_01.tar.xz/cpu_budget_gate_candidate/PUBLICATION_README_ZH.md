# CPU 原件身份闭合与预算执行门：已完成有限本地验证，远端 CI 待观察

本后继候选修复 CPU 恢复路径的三个工程问题：宿主与原精确 runtime 安装不一致、原件 pointer 没有反映已经发生的 Git 出版、以及 workflow 没有执行当前预算准入检查。**原件可以定位和逐字核验，恢复执行仍保持 HOLD。** 源码门和 7 项新 stdlib 回归已由 root 各执行一次并通过；没有重跑原 28 adapter 测试，没有启动 CPU checkpoint 恢复或训练。新分支自动 CI 尚未执行，不能预写其结论。

## 1. 原 archive 已可用，旧 MISSING 文案应被更正

原件由 [917e4886658ae9f0c342eb1fa0f545d79c39e2c8](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/917e4886658ae9f0c342eb1fa0f545d79c39e2c8) 于 2026-11-12 出版，[PR #6214](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6214) 与登记分支 `artifact/hcsn-c2-export-20261112-c06d-v1` 均保留这一身份。集成源 ce6 已包含原 Git 对象，但 `CPU-ARTIFACT.json` 一直保留 MISSING 和“publication not yet observed”的旧文案；因此该文案不能证明原 ZIP 在 Git 中不存在。

| 原件 | 固定身份 |
|---|---|
| Manifest | `qualification/hcsn_differentiable/replay_v1/artifact/EXPORT.json`；Git blob `3f0460737ffc61d814e4383d01a93cbafac6f2db` |
| 唯一 part | [part-000.zip](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/917e4886658ae9f0c342eb1fa0f545d79c39e2c8/qualification/hcsn_differentiable/replay_v1/artifact/part-000.zip)；Git blob `2afc4e810f1c75a1ff5b9fb85464f6dda6c43245` |
| Archive 大小与 SHA256 | 11,397,159 字节；`37d387507ec150abfdad4065c23612e18fca6643d489f3555874c8e57a514b75` |
| 原源与收据 parent | `5cb83d9c76beedf4c1c917e4bf561f5f26261ce7` / `a832b028abdf1a1c9ab66534332457c6d76a91ca` |
| 原只读 export job | desktop `1a1ce7e3837-2564-16c9`；原路径 `/home/qian-qi/hcsn-real-replay-c06d-export-v1.zip` |

Root 已对登记 desktop 原件完成独立数据审计：job `1a216c3cd10-ffbe-44e2` succeeded / exit 0，wall 0.470607 秒。原大小、SHA256 和 Git blob 重算均吻合；**555/555 indexed originals + INDEX.json = 556 ZIP 成员**，原文件总量 56,675,710 字节；全部成员 SHA/CRC、原 PREEXECUTION 的 555 份绑定、六 checkpoint 身份/epoch/每 fit 37 份源均吻合。整个核对没有 Torch/pickle/model/optimizer 调用。

原 export writer 报告的 entries=555 是原文件数，不含后来写入的 INDEX.json。此处明确更正旧 prose 的“555 members”，不改原日志。

两次直接 Git 下载发生 HTTP/2 CANCEL，原失败被保留。本次成功的字节审计来自登记 desktop 原件，并与已观察到的不可变 Git 对象身份交叉核对；不能改写成“两次 Git 下载成功”。最终归档由 root 保留完整 native 审计与下载失败，通过 SOURCE_CUSTODY 索引和上述不可变 Git 路径引用原 ZIP，避免再重复保存一份 11 MB archive。

## 2. 四个源码路径必须原子发布

| 路径 | 实际修改 |
|---|---|
| `.github/workflows/hcsn-real-checkpoint-cpu.yml` | 两个 job 固定 Ubuntu 24.04；安装器恢复原 `torch==2.8.0+cpu`；adapter job 接入 7 个新回归；recovery 在 pointer 和任何模型设置前执行冻结源门与显式预算 gate。 |
| `qualification/hcsn_differentiable/replay_v1/CPU-ARTIFACT.json` | 按原 validator 已允许的 schema 改为 FROZEN，指向精确 `917e4886...`；原 repository、manifest path、archive bytes/SHA 不变。 |
| `.../cpu_replay_admission_gate.py` | 新 stdlib CLI，绑定原 REQUEST SHA，调用原 contract，并把 HOLD、原 blockers、未准入 flags 或缺失 execution_key 转成非 0 拒绝。 |
| `.../test_cpu_replay_admission_gate.py` | 7 个新 stdlib 方法，覆盖拒绝语义、正常与优化模式 CLI、冻结 request 字节变化及 workflow 执行顺序。 |

原 `artifact_pointer.py` 未修改。原预算 contract、REQUEST、SOURCE_FREEZE 和 11 份绑定历史文件均未修改。不得先单独发布 FROZEN pointer，再补预算门。

两个宿主固定沿用已验证 [24de2762](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/24de27627ff72e5e482ab083c39c9e506382eeb4) 的两行修补。Torch 安装行冲突来自 [520f5c1d](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/520f5c1dd0f284d1b7f790d0f027267011044639)：当时安装器改为 2.10，但 CPU-PROFILE 与 cpu_migration 的精确 2.8 要求从最初 0de7f86e 到 ce6 均未变。本次对齐安装器，没有放宽原 Torch version/build 或三份 Torch Python 源码摘要要求；实际 2.8 runtime 安装与六 checkpoint 恢复仍未执行。

## 3. source PASS 与 execution admission 的语义

原 `verify_frozen_sources` 在确认完整冻结源、原历史和 **仍为 HOLD** 时返回 0，并输出：

```text
PASS_C2_CURRENT_BUDGET_ADMISSION_HOLD
```

它是 source 守卫，不能单独用作恢复准入。新 workflow 在其后运行 `cpu_replay_admission_gate.py`。新 CLI 固定原 REQUEST SHA256 `bb35a50f6344fb0669a2bffff5e14a30cc0496692930cc2be7b05ed2fd6fc343`，调用原 `validate_current_budget_admission`，随后显式要求执行状态和 flags；当前冻结请求必然被拒绝，返回 2。手工把旧 JSON 的几个字段改成“已解决”会先触发字节身份拒绝。

本 v1 没有自行产生可执行后继。真实后续准入必须另行绑定完整历史、当前资源、实际余额、执行身份和对应 source/runtime/model/data；不能修改旧冻结摘要来声称当前 HOLD 已经解除。

执行顺序经新回归核对为：source checkout → 原冻结 source verifier → 新 budget gate → artifact pointer → artifact checkout → Python/Torch 设置 → ci_replay。原件可用与执行授权因此分开处理。

## 4. 已发生的有限本地验证

Root 的 `local_residuals_01/RESULT.json` 记录两项 CPU 验证均只执行一次，automatic_retries=0：

| 验证 | 实际结果 | 外层 wall / CPU |
|---|---|---|
| 原冻结 source CLI | exit 0，原 stdout 为 PASS_C2_CURRENT_BUDGET_ADMISSION_HOLD；7 份 source SHA 与 11 份原 Git blob 守卫通过 | 0.065217785 / 0.050371 秒 |
| 7 项新 stdlib 回归 | 7/7 方法 ok，exit 0；正常与 `-O` 的两个新 gate 子进程均按预期拒绝 | 0.266092999 / 0.233127 秒 |

原 unittest stderr 的内部汇总是 **Ran 7 tests in 0.181s**。该内部计时与外层进程 wall 是不同范围；此处均保留实际记录，不作训练性能推断。

7 项回归覆盖：

1. 当前原请求保留原历史 blockers 并被拒绝。
2. 原 contract 的 metadata 正例不能覆盖 HOLD status。
3. 与证据矛盾的 replay_admitted flag 被原 contract 拒绝。
4. 未识别的 READY status 不构成执行准入。
5. 原 REQUEST 只增一个换行也不能替换冻结记录。
6. 正常与 `-O` 各一个 CLI 子进程都返回拒绝，记录 0 模型/0 Torch/0 优化器。
7. workflow 冻结源门与执行 gate 位于 pointer 和模型设置之前，未加 continue-on-error 或忽略错误。

执行前后 **23/23 文件 SHA 相同**。独立只读复核再次对这 23 份当前落盘文件重算 SHA，与原 before 表全部一致；并核对原 stdout/stderr 摘要。这些是文件数据检查，没有重跑任何测试。

| 原证据 | SHA256 |
|---|---|
| `local_residuals_01/RESULT.json` | `59968a7d0704012935fc053b6139e724add0ef9f6a463edd5b85994aa40a783e` |
| `cpu-source-hold.stdout` | `e6d3e3def061f6a5f673c78a03d0bf3a7732111a3b59bb8720357900c8d9688b` |
| `cpu-seven-regressions.stderr` | `0d173707adf9fd47ddc87faaf1a7a430a3c3e288609a1c4b92aed499a253a6c7` |

source stderr 和 regression stdout 均为空。原 28 adapter 手工执行次数为 0；本轮 CPU 验证 model_calls=0、optimizer_updates=0。对源码、pointer 和预算闭包的两名同伴审查均为静态审查，没有额外执行。

## 5. 远端自动 CI 与剩余证据

截至本说明形成时，新分支自动 CI 尚未执行。一次普通 push 若运行全部 adapter 步骤，预期为旧 28 次执行加新 7 方法，即 35 次测试执行、30 个不同方法；新回归内部另有两个只执行拒绝 gate 的子进程。其后 recovery 预期在 budget HOLD 门停止，实际 run/job/exit 必须回读后追加。不得预先称整体 workflow 通过；同 head 不再额外开 PR 重复触发，不手动 dispatch/rerun。

旧 [run 45689386079](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45689386079) 的事实保持：adapter job 139470474673 的 28 次执行通过，而 recovery job 139498353187 在旧 MISSING pointer 处失败；整体 failure。新证据不能改写这些历史结果。

当前预算仍是 **HOLD / replay_admitted=false / resource_admitted=false / execution_key=null**。原 controller terminal、lifetime optimizer total、各 fit 当前余额仍 UNKNOWN；已知完成诊断计数仍 52，完整独立训练重放仍 0/6。原 ledger 的 172,938.8845898183 秒是历史决策时的 charged remainder，不是当前可用余额，也不因原件找回而退款。

本次闭合的是原件身份、runtime 安装配置冲突和缺失的执行预算门。真实 CPU runtime、六 checkpoint continuation、完整训练重放以及科学/生产资格各自仍需对应的新证据和有效准入。
