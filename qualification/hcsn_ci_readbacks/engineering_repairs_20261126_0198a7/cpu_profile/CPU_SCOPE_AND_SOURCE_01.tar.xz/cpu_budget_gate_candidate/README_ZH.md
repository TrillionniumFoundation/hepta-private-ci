# CPU 原件指针与真实预算门的原子后继候选

原 archive 已找到并经 root 独立字节审计；CPU 恢复仍没有当前预算和资源准入。本候选把这两个状态正确分开：原件 pointer 采用原允许的 FROZEN 格式指向不可变 `917e4886...`，workflow 在接触 pointer、原件 checkout 和任何模型设置之前先运行冻结源验证与显式执行拒绝门。

旧两行、旧三行候选及其证据快照保持原样。本目录是后继候选；**4 个源码路径必须同一原子 commit 发布，不能先单独发布 FROZEN pointer。**

## 修改与保持的原约束

| 路径 | 变化 |
|---|---|
| `.github/workflows/hcsn-real-checkpoint-cpu.yml` | 继承两处 Ubuntu 24.04 与 Torch 2.8.0+cpu 安装对齐；adapter job 新增 7 项 stdlib 回归；recovery job 在 pointer 前依次运行原冻结源 CLI 和新执行 gate。 |
| `qualification/hcsn_differentiable/replay_v1/CPU-ARTIFACT.json` | 由 MISSING 改为 FROZEN，新增精确原 artifact commit；原 schema、repository、manifest path、archive bytes/SHA 均保持。claim 明确原件可用不构成执行准入。 |
| `.../cpu_replay_admission_gate.py` | 新 stdlib CLI，绑定原 REQUEST SHA，调用原 metadata contract，并显式拒绝 HOLD、未准入 flags、blockers 和缺失 execution_key。拒绝返回 2，输出零模型/零 Torch/零优化器回执。 |
| `.../test_cpu_replay_admission_gate.py` | 7 项有限 stdlib 回归，包括正常和 `-O` 两个新 gate 子进程以及 workflow 顺序核对。 |

`artifact_pointer.py`、`current_budget_admission_v1/` 全部冻结源、原数据和历史摘要均未修改。原 helper 的条件、UNKNOWN、失败、已用成本与 HOLD 都继续存在。

## 原 CLI 的语义为何不能误用

原可复用函数是 `budget_contract.validate_current_budget_admission(record)`，当前 REQUEST 正常返回 `admitted=False` 和原 blockers。它没有执行 CLI。原 `verify_frozen_sources` CLI 在 **确认仍为 HOLD** 时输出 `PASS_C2_CURRENT_BUDGET_ADMISSION_HOLD` 并返回 0。仅把这个 CLI 接入 workflow，不会阻止后续恢复。

现在 workflow 先运行原 source verifier，再运行新 gate。新 gate 的原 REQUEST SHA 是 `bb35a50f6344fb0669a2bffff5e14a30cc0496692930cc2be7b05ed2fd6fc343`，与原 SOURCE_FREEZE 相同；改变任一 request 字节会拒绝。当前记录没有执行准入，必然非 0 退出。原 contract 的合成 metadata 正例仍可以测试边界，但即使 metadata 的 decision 为 true，只要 status 仍 HOLD，新 gate 就拒绝。

这个 v1 入口只支持原冻结请求，不能被“补全几个字段”的新 metadata 自动放行。真实后续准入需要单独审查的新协议/入口及实际历史、资源、预算证据；不能改旧 freeze/hash 假装原 v1 早已满足。

## 原件身份与 root 的独立审计

登记的 artifact 出版提交是 [917e4886658ae9f0c342eb1fa0f545d79c39e2c8](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/917e4886658ae9f0c342eb1fa0f545d79c39e2c8)，[PR #6214](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6214)。原 manifest 的 Git blob 是 `3f0460737ffc61d814e4383d01a93cbafac6f2db`，唯一 ZIP part 的 Git blob 是 `2afc4e810f1c75a1ff5b9fb85464f6dda6c43245`。

Root 已对原登记 desktop 路径做独立数据审计：job `1a216c3cd10-ffbe-44e2` succeeded / exit 0，wall 0.470607 秒；11,397,159 字节、SHA256 `37d387507ec150abfdad4065c23612e18fca6643d489f3555874c8e57a514b75`、Git blob 重算均吻合。555 份 indexed originals 加 INDEX 共 556 个成员、56,675,710 原文件字节、所有 SHA/CRC、原 PREEXECUTION 的 555 份绑定、六 checkpoint 身份/epoch/每 fit 37 份源均吻合。没有 Torch/pickle/model/optimizer 调用。

两次直接 Git 下载遇到 HTTP/2 CANCEL，仍保留为失败，不写成下载成功。本 child 只读了 Git 元数据、清单及原 job 收据，没有重做 ZIP 审计。完整新的 root 字节回执应随最终发布附上；本候选的身份文件明确标注审计来自 root。

## 验证计划与当前状态

本 child **没有执行** source verifier、测试、gate、adapter、CI 或模型。静态同伴审查未发现 gate 漏放或意外模型入口；实际 source/stdlib 验证由 root 按 `VALIDATION_PLAN.json` 最多各一次执行。

`source_prerequisites/` 已保存原 source verifier 所需的 **19 份实际 ce6 文件**：7 份 source SHA 文件、11 份绑定 Git blob 和 SOURCE_FREEZE 本体。11 个 bound blob 的 GitHub 身份全部吻合；未改变冻结摘要。Root 可在这个独立目录运行一次原只读 source gate，然后在隔离副本叠加新候选、运行 7 个新测试。原 28 adapter 测试不需在这次手工验证中重复。

普通单次 push 自动 CI 会执行旧 28 次 adapter 加新 7 方法，共 35 次测试执行、30 个不同方法；新测试内另有两个只运行 gate 的 Python 子进程。随后 recovery job 预期在 HOLD 门拒绝，实际结论需回读。不得把整个 workflow 写成成功、把旧 28 次测试转称新 runtime 已通过，或为同 head 再开 PR 重复触发。禁止手动 dispatch/rerun。

## 剩余预算与科学边界

当前 REQUEST 仍是 HOLD，replay_admitted=false、resource_admitted=false、execution_key=null；原 controller terminal、lifetime optimizer total、各 fit 当前余量仍 UNKNOWN。已知完成诊断计数仍是 52，完整独立训练重放仍 0/6。原 ledger 的 172,938.8845898183 秒是历史决策时的 charged remainder，不是当前可执行余额。

原件身份闭合、source/stdlib 门正确与真实六 checkpoint continuation 是不同证据。三行 host/runtime 对齐和本预算门不会授予新 26-call 恢复、新训练或生产/科学 GO。
