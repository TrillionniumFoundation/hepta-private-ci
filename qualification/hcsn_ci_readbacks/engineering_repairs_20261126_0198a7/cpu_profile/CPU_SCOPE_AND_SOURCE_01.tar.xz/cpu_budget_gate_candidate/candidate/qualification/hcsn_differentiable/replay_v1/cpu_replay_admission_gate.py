"""Require the frozen C2 budget decision before CPU recovery setup.

The v1 request remains HOLD. Changing this executable boundary does not create
an admitted successor, replenish a budget, or authorize model execution.
"""

import hashlib
import json
from pathlib import Path
import sys

from current_budget_admission_v1 import budget_contract


REQUEST_PATH = (
    Path(__file__).resolve().parent / "current_budget_admission_v1/REQUEST.json"
)
FROZEN_REQUEST_SHA256 = (
    "bb35a50f6344fb0669a2bffff5e14a30cc0496692930cc2be7b05ed2fd6fc343"
)


class CpuReplayAdmissionError(ValueError):
    """The frozen metadata does not authorize CPU recovery."""


def read_frozen_request(path=REQUEST_PATH):
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != FROZEN_REQUEST_SHA256:
        raise CpuReplayAdmissionError(
            "current-budget request SHA-256 differs; a reviewed successor is required"
        )
    return json.loads(raw)


def require_current_admission(record):
    decision = budget_contract.validate_current_budget_admission(record)
    blockers = list(decision.blockers)
    if record["status"] != "ADMITTED":
        blockers.append("status is not ADMITTED: " + str(record["status"]))
    if record["replay_admitted"] is not True:
        blockers.append("replay_admitted is not true")
    if record["resource_admitted"] is not True:
        blockers.append("resource_admitted is not true")
    if not isinstance(record["execution_key"], str) or not record["execution_key"]:
        blockers.append("execution_key is missing")
    if decision.admitted is not True or blockers:
        raise CpuReplayAdmissionError(
            "HOLD: current CPU replay budget/resources are not admitted; "
            + "; ".join(blockers)
        )
    return decision


def main():
    try:
        require_current_admission(read_frozen_request())
    except (OSError, ValueError, TypeError, KeyError) as error:
        print(
            json.dumps(
                {
                    "schema": "hcsn-cpu-current-budget-execution-gate-v1",
                    "admitted": False,
                    "reason": str(error),
                    "model_calls": 0,
                    "torch_calls": 0,
                    "optimizer_calls": 0,
                },
                sort_keys=True,
                allow_nan=False,
            ),
            file=sys.stderr,
        )
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
