"""Bounded stdlib-only checks for the CPU execution admission boundary."""

import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import cpu_replay_admission_gate as gate


ROOT = Path(__file__).resolve().parents[3]


def resolved_metadata_fixture():
    """Exercise the old metadata positive boundary; this grants no execution."""
    record = copy.deepcopy(gate.read_frozen_request())
    record.update(
        complete_history_accounted=True,
        complete_history_budget_ledger=True,
        lifetime_optimizer_calls=123,
        lifetime_optimizer_calls_status="RESOLVED",
        original_controller_terminal="SUCCEEDED",
        execution_key="fixture-only-no-execution",
        single_campaign_freeze_complete=True,
        current_resource_capture_sha256="a" * 64,
        allocation_reservation_sha256="b" * 64,
        source_runtime_model_data_freeze_sha256="c" * 64,
        successor_cursor_protocol_sha256="d" * 64,
        replay_admitted=True,
        resource_admitted=True,
    )
    for attempt in record["historical_attempts"]:
        if attempt["status"] == "UNKNOWN":
            attempt["status"] = "RESOLVED_TERMINAL"
        attempt["complete_wall"] = True
        attempt["optimizer_count"] = 0
    for row in record["fits"]:
        row["complete_attempt_history"] = True
        for value, status in (
            ("later_non_refunded_wall_seconds", "later_non_refunded_wall_status"),
            ("per_fit_exit_overhead_seconds", "per_fit_exit_overhead_status"),
            ("current_remaining_wall_seconds", "current_remaining_wall_status"),
            ("current_worker_active_ceiling_seconds", "current_worker_active_ceiling_status"),
        ):
            row[value] = 1.0
            row[status] = "RESOLVED"
    return record


class CpuReplayAdmissionGateTests(unittest.TestCase):
    def test_current_request_is_rejected_with_original_blockers(self):
        with self.assertRaisesRegex(gate.CpuReplayAdmissionError, "historical_attempt_ledger"):
            gate.require_current_admission(gate.read_frozen_request())

    def test_metadata_positive_boundary_does_not_override_hold_status(self):
        record = resolved_metadata_fixture()
        self.assertTrue(gate.budget_contract.validate_current_budget_admission(record).admitted)
        self.assertEqual(record["status"], "HOLD")
        with self.assertRaisesRegex(gate.CpuReplayAdmissionError, "status is not ADMITTED: HOLD"):
            gate.require_current_admission(record)

    def test_inconsistent_admission_flag_is_rejected_by_original_contract(self):
        record = gate.read_frozen_request()
        record["replay_admitted"] = True
        with self.assertRaisesRegex(gate.budget_contract.BudgetAdmissionError, "flag disagrees"):
            gate.require_current_admission(record)

    def test_unknown_status_does_not_grant_execution(self):
        record = resolved_metadata_fixture()
        record["status"] = "READY"
        with self.assertRaisesRegex(gate.CpuReplayAdmissionError, "status is not ADMITTED: READY"):
            gate.require_current_admission(record)

    def test_byte_changed_request_cannot_replace_frozen_record(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "REQUEST.json"
            path.write_bytes(gate.REQUEST_PATH.read_bytes() + b"\n")
            with self.assertRaisesRegex(gate.CpuReplayAdmissionError, "SHA-256 differs"):
                gate.read_frozen_request(path)

    def test_cli_rejects_current_request_normally_and_with_optimization(self):
        for flags in ([], ["-O"]):
            result = subprocess.run(
                [sys.executable, "-B", *flags, str(Path(gate.__file__).resolve())],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
            self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
            self.assertEqual(result.stdout, "")
            receipt = json.loads(result.stderr)
            self.assertIs(receipt["admitted"], False)
            self.assertIn("HOLD", receipt["reason"])
            self.assertIn("historical_attempt_ledger", receipt["reason"])
            self.assertEqual(
                [receipt[name] for name in ("model_calls", "torch_calls", "optimizer_calls")],
                [0, 0, 0],
            )

    def test_workflow_checks_frozen_sources_then_admission_before_pointer(self):
        workflow = (ROOT / ".github/workflows/hcsn-real-checkpoint-cpu.yml").read_text(
            encoding="utf-8"
        )
        recovery = workflow.split("  real-recovery:\n", 1)[1]
        verifier = (
            "python3 -B -m qualification.hcsn_differentiable.replay_v1."
            "current_budget_admission_v1.verify_frozen_sources"
        )
        command = (
            "python3 -B qualification/hcsn_differentiable/replay_v1/"
            "cpu_replay_admission_gate.py"
        )
        self.assertEqual(recovery.count(verifier), 1)
        self.assertEqual(recovery.count(command), 1)
        positions = [
            recovery.index("path: source"),
            recovery.index(verifier),
            recovery.index(command),
            recovery.index("id: artifact"),
            recovery.index("path: original-artifact"),
            recovery.index("actions/setup-python@"),
            recovery.index("Install the separate pinned CPU runtime"),
            recovery.index("Execute the actual six-checkpoint recovery"),
        ]
        self.assertEqual(positions, sorted(positions))
        self.assertNotIn("continue-on-error", recovery)
        self.assertNotIn("|| true", recovery)


if __name__ == "__main__":
    unittest.main()
