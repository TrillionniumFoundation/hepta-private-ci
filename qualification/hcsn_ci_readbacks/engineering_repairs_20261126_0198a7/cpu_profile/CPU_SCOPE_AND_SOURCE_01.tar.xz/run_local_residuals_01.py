"""Execute only the admitted stdlib gate tests and retained arithmetic readback."""
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'local_residuals_01'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    OUT.mkdir(exist_ok=False)
    format_plan = json.loads((ROOT / 'FORMAT_05_INPUTS.json').read_text())
    assert sha((ROOT / 'FORMAT_05_INPUTS.json').read_bytes()) == '85b4eba33372f53d6cc87e39868790735cd3a79735c81cc6e3b83d4b4363ee48'
    result = {'status': 'STARTED', 'steps': [], 'automatic_retries': 0,
              'model_calls': 0, 'optimizer_updates': 0, 'old_adapter_tests_repeated': 0,
              'official_format_receipt_sha256': '461c1e45f0a6eed27e4956cf467df3bad7ec3381c4bfb8a9d10b79d61e8e87d3'}
    def save():
        (OUT / 'RESULT.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    def run(label, argv, cwd, wall, cpu=None):
        row = {'label': label, 'argv': argv, 'cwd': str(cwd), 'state': 'INTENT', 'wall_limit_s': wall, 'per_process_cpu_limit_s': cpu}
        result['steps'].append(row)
        save()
        def limits():
            if cpu is not None:
                resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu))
            resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024 * 1024, 8 * 1024 * 1024))
        before = resource.getrusage(resource.RUSAGE_CHILDREN)
        begin = time.perf_counter()
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
        with (OUT / (label + '.stdout')).open('xb') as stdout, (OUT / (label + '.stderr')).open('xb') as stderr:
            child = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stdout, stderr=stderr,
                                     start_new_session=True, preexec_fn=limits)
            try:
                child.wait(timeout=wall)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=5)
                row['timed_out'] = True
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
        row.update(state='RETURNED', exit_code=child.returncode, wall_s=time.perf_counter() - begin,
                   cpu_s=after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime)
        for stream in ('stdout', 'stderr'):
            data = (OUT / (label + '.' + stream)).read_bytes()
            row[stream] = {'bytes': len(data), 'sha256': sha(data)}
        save()
        if child.returncode:
            raise RuntimeError(label + ' failed; preserve original output')
        return (OUT / (label + '.stdout')).read_text()
    try:
        cpu_root = OUT / 'cpu_source'
        pins = json.loads((ROOT / 'cpu_budget_gate_candidate/SOURCE_PREREQUISITES.json').read_text())
        for row in pins['files']:
            raw = (ROOT / 'cpu_budget_gate_candidate/source_prerequisites' / row['path']).read_bytes()
            assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['git_blob']
            if row['expected_sha256']:
                assert sha(raw) == row['expected_sha256']
            target = cpu_root / row['path']
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        candidate = ROOT / 'cpu_budget_gate_candidate/candidate'
        for path in sorted(candidate.rglob('*')):
            if path.is_file():
                name = str(path.relative_to(candidate))
                raw = path.read_bytes()
                assert sha(raw) == format_plan['files'][name]['sha256']
                target = cpu_root / name
                assert not target.exists()
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(raw)
        cpu_before = {str(p.relative_to(cpu_root)): sha(p.read_bytes()) for p in cpu_root.rglob('*') if p.is_file()}
        result['cpu_source_before'] = cpu_before
        source_output = run('cpu-source-hold', [sys.executable, '-B', '-m', 'qualification.hcsn_differentiable.replay_v1.current_budget_admission_v1.verify_frozen_sources'], cpu_root, 10, 5)
        assert source_output.strip() == 'PASS_C2_CURRENT_BUDGET_ADMISSION_HOLD'
        run('cpu-seven-regressions', [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'qualification/hcsn_differentiable/replay_v1', '-p', 'test_cpu_replay_admission_gate.py', '-v'], cpu_root, 30, 5)
        stderr = (OUT / 'cpu-seven-regressions.stderr').read_text()
        assert 'Ran 7 tests' in stderr and stderr.endswith('\nOK\n')
        cpu_after = {str(p.relative_to(cpu_root)): sha(p.read_bytes()) for p in cpu_root.rglob('*') if p.is_file()}
        assert cpu_before == cpu_after
        result['cpu_source_unchanged'] = True
        result['cpu_tests'] = {'methods': 7, 'guard_child_processes': 2, 'source_gate_remains_hold': True}
        hx = ROOT / 'hx_residual_candidate'
        registration_raw = (hx / 'REGISTRATION.json').read_bytes()
        registration = json.loads(registration_raw)
        for name, identity in registration['files'].items():
            raw = (hx / name).read_bytes()
            assert {'bytes': len(raw), 'sha256': sha(raw)} == identity
        for name in ('materialize_frozen_views.py', 'run_retained_firstcycle.py'):
            remote_name = 'qualification/hcsn_ci_readbacks/engineering_repairs_20261126_0198a7/frozen_views/' + name
            assert sha((hx / name).read_bytes()) == format_plan['files'][remote_name]['sha256']
        result['frozen_view_registration_sha256'] = sha(registration_raw)
        snapshot = OUT / 'frozen_snapshot'
        run('frozen-byte-materialization', [sys.executable, '-I', '-B', str(hx / 'materialize_frozen_views.py'), '--output', str(snapshot)], hx, 30, 10)
        verifier_out = OUT / 'firstcycle_verifier'
        run('firstcycle-retained-readback', [sys.executable, '-I', '-B', str(hx / 'run_retained_firstcycle.py'), '--snapshot', str(snapshot), '--output', str(verifier_out)], hx, 60)
        verified = json.loads((verifier_out / 'RESULT.json').read_text())
        assert verified['status'] == 'RETAINED_CUSTODY_ARITHMETIC_PASS' and verified['scientific_status'] == 'HOLD_NO_GO'
        result.update(status='PASS_BOUNDED_LOCAL_RESIDUALS', frozen_view_byte_gate='PASS',
                      firstcycle_engineering_status=verified['status'], scientific_status='HOLD_NO_GO',
                      firstcycle_result_sha256=sha((verifier_out / 'RESULT.json').read_bytes()))
    except BaseException as error:
        result.update(status='FAILED_RETAINED', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        save()
        print(json.dumps({k: result.get(k) for k in ('status', 'cpu_tests', 'frozen_view_byte_gate', 'firstcycle_engineering_status', 'error')}), flush=True)


if __name__ == '__main__':
    main()
