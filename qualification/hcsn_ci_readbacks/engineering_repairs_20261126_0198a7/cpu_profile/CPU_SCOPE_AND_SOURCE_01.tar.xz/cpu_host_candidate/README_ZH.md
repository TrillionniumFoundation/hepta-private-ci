# CPU 恢复宿主：已有两行修补的静态交付

本候选把已验证提交 [24de27627ff72e5e482ab083c39c9e506382eeb4](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/24de27627ff72e5e482ab083c39c9e506382eeb4) 的 workflow 原字节，原样叠加到当前集成源 `ce6b9fe9dcb7d6bb8e78978c8b81a001ac7e2ea2`。没有重新执行 adapter、模型、优化器或 CI。

## 唯一源码修改

`.github/workflows/hcsn-real-checkpoint-cpu.yml` 第 31、50 行，分别属于 `adapter-tests` 和 `real-recovery`：

```diff
-    runs-on: ubuntu-latest
+    runs-on: ubuntu-24.04
```

原文件 4,003 字节，Git blob `7633c1bb728b74bb14a3af11536b99683f052d4e`；候选 4,001 字节，Git blob `98a91198c465dfbeda02656eda236d7c6e630da6`。保存后已用 `git hash-object --no-filters` 核对两个精确 blob。除这两行，其余字节相同。Python、依赖安装、5/60 分钟期限、测试、pointer 检查、权限和触发器均保持原字节。

完整源分别在 `original/.github/workflows/` 和 `candidate/.github/workflows/`；`minimal.diff` 是两处修改的统一 diff；所有身份见 `SOURCE_IDENTITY.json`。

## 原生证据及其边界

[原 run 45689386079](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45689386079) 是上述 `24de2762` 的第一次 push 运行，最终 **failure**。其中：

- [adapter-tests job139470474673](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45689386079/job/139470474673) **success**：Ubuntu 24.04 镜像 `20261116.376.1` 配置了精确 Python `3.12.3`。18 个 archive/relocation 测试、5 个 pointer 普通测试、相同 5 个 pointer 优化模式测试通过，共 **28 次执行、23 个不同方法**。原日志三个汇总分别为 0.637、1.585、1.558 秒。这些测试没有加载实际 Torch 模型。
- [real-recovery job139498353187](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45689386079/job/139498353187) **failure**：在任何模型设置之前被原 `CPU-ARTIFACT.json` 的 `MISSING` 状态拒绝。原件 checkout、Python/Torch 设置、六 checkpoint 恢复均 skipped；不得把 adapter 成功写成整个 workflow 成功。

两份完整解码日志、原 run/job API 回读和原 pointer 均在 `evidence/`。日志 SHA256 记录在身份文件中。两个测试文件、`cpu_migration.py`、`artifact_pointer.py`、`checkpoint_replay.py` 和 `CPU-ARTIFACT.json` 从原资格源到 ce6 的 Git blob **6/6 相同**。这不将其他集成源或未执行的恢复步骤声明为通过。

## 原 source / artifact 守卫

已读取的执行链中，`artifact_pointer.py` 固定原 archive identity；`ci_replay.py` 固定 worker 及相应模型源码，并构造独立 CPU plan。它们没有把这份 CPU workflow 的字节放入原运行期冻结表。

同目录 `current_budget_admission_v1/SOURCE_FREEZE.json` 固定的是另一个 `.github/workflows/hcsn-c2-current-budget-admission.yml`，不是本候选 workflow。其 `HOLD`、未知 lifetime 成本和未获执行 admission 保持不变。本审查不声称全仓不存在其他历史引用。

原 pointer 仍为 `MISSING`，要求的 archive 仍是 **11,397,159 字节**、SHA256 `37d387507ec150abfdad4065c23612e18fca6643d489f3555874c8e57a514b75`。本候选不补造数据、不修改摘要，也不改变拒绝位置。

## 自动触发必须明确

原 workflow 的 `push` 和 `pull_request` 两套路径均包含其自身文件；普通推送或开 PR 会匹配。其 concurrency group 包含 `github.ref`，且 `cancel-in-progress: false`，不能假定 push/PR 会相互消除。

因此，本候选只是源码和既有证据交付，**不保证普通发布不会重复 adapter**。在本轮零重复执行约束下，应由 root 控制发布方式并保留“新 head 未运行”的真实状态，不能新增派发或删除原门。本准备阶段未发生远端写入或调度。

## 另一个已定位但未修改的错误

当前安装行是 `torch==2.10.0+cpu`，而 `cpu_migration.py` 第 141 行明确要求 `runtime['torch_version'] == '2.8.0+cpu'`；`CPU-PROFILE.md` 同样规定 2.8.0+cpu。即使将来找回原 archive，这两者仍不相容，届时会由原运行期守卫拒绝。

这与宿主两行修补是两项独立问题。28 次 stdlib adapter 通过不能证明真实 Torch 兼容；本候选没有顺手改版本或放宽 source/hash 检查。后续若修复，应优先让 installer 恢复已声明的精确 2.8.0+cpu profile，并保持原三份 Torch Python 源码的逐字验证；真实恢复仍需原工件、当前有效预算及单独执行回执。
