"""Read original Git bytes and audit ZIP custody without loading checkpoints."""
import base64
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import time
import zipfile


ROOT = Path('/home/qian-qi/hepta-hcsn-fixes-20261126-0198a7')
OUT = ROOT / 'cpu_archive_audit_native_01'
GH = '/opt/homebrew/bin/gh'
REPO = 'repos/TrillionniumFoundation/hepta-private-ci'
COMMIT = '917e4886658ae9f0c342eb1fa0f545d79c39e2c8'
PREFIX = 'qualification/hcsn_differentiable/replay_v1/artifact/'
ARCHIVE_SHA = '37d387507ec150abfdad4065c23612e18fca6643d489f3555874c8e57a514b75'
ARCHIVE_BLOB = '2afc4e810f1c75a1ff5b9fb85464f6dda6c43245'
PRE_SHA = '49a624205233078044c3dcf5d53f26ca83a76f4e0e897dc39c98ffb9d5f41653'
SOURCE = '5cb83d9c76beedf4c1c917e4bf561f5f26261ce7'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def strict_json(raw):
    def pairs(rows):
        result = {}
        for key, value in rows:
            require(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def constant(value):
        raise ValueError('nonfinite JSON constant: ' + value)
    def finite(value):
        number = float(value)
        require(math.isfinite(number), 'nonfinite JSON float')
        return number
    result = json.loads(raw, object_pairs_hook=pairs, parse_constant=constant, parse_float=finite)
    require(type(result) is dict, 'JSON must be an object')
    return result


def git_blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def main():
    require(len(sys.argv) == 2 and digest(Path(__file__).read_bytes()) == sys.argv[1], 'auditor identity differs')
    ROOT.mkdir(exist_ok=True)
    OUT.mkdir(exist_ok=False)
    started = time.perf_counter()
    cpu_started = time.process_time()
    result = {'schema': 'hepta.hcsn.original-cpu-archive-independent-audit.v1', 'status': 'STARTED',
              'artifact_commit': COMMIT, 'source_commit': SOURCE, 'auditor_sha256': sys.argv[1],
              'started_utc': datetime.now(timezone.utc).isoformat(), 'commands': [],
              'model_loads': 0, 'torch_imports': 0, 'pickle_deserializations': 0,
              'forward_calls': 0, 'optimizer_updates': 0, 'training_replays': 0,
              'pointer_modified': False, 'execution_admission_granted': False}

    def save():
        (OUT / 'RESULT.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')

    try:
        archive_path = Path('/home/qian-qi/hcsn-real-replay-c06d-export-v1.zip')
        before = archive_path.stat()
        require(not archive_path.is_symlink() and stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'original archive must be a single regular file')
        require(before.st_dev == 2050 and before.st_ino == 49963775 and before.st_size == 11397159, 'registered original file identity changed')
        archive_raw = archive_path.read_bytes()
        expected = {'bytes': 11397159, 'sha256': ARCHIVE_SHA}
        require(len(archive_raw) == expected['bytes'] and digest(archive_raw) == ARCHIVE_SHA
                and git_blob(archive_raw) == ARCHIVE_BLOB, 'original archive bytes differ')
        result['byte_source'] = 'Original retained desktop export; no GitHub binary download claimed'
        result['original_path'] = str(archive_path)
        result['git_path_metadata_observed_at_commit'] = COMMIT
        result['git_binary_download_attempts'] = [
            {'host': 'main', 'result_sha256': '9f7d05b53ae1c413c589a50b7f58be7ae93212d3b08aa09739ff1e6d7f65a7f7', 'status': 'FAILED_RETAINED'},
            {'host': 'main', 'result_sha256': 'df601869da7842ded9b9cf8be0699c596d18ee203b655d151d704eee3a84b61e', 'status': 'FAILED_RETAINED'}]
        result['archive'] = {**expected, 'git_blob': ARCHIVE_BLOB, 'matches_observed_git_path_blob': True}
        save()
        with zipfile.ZipFile(archive_path) as archive:
            infos = archive.infolist()
            names = [item.filename for item in infos]
            require(len(infos) <= 2001 and len(names) == len(set(names)), 'duplicate or excess ZIP members')
            require(sum(item.file_size for item in infos) <= 128 * 1024 * 1024, 'ZIP raw expansion exceeds original gate')
            for item in infos:
                name = item.filename
                path = PurePosixPath(name)
                require(name and '\\' not in name and '\x00' not in name and not path.is_absolute()
                        and all(part not in ('', '.', '..') for part in path.parts)
                        and path.as_posix() == name, 'noncanonical ZIP path')
                require(not item.is_dir() and stat.S_IFMT(item.external_attr >> 16) in (0, stat.S_IFREG)
                        and not item.flag_bits & 1, 'nonregular or encrypted ZIP entry')
            require('INDEX.json' in names and archive.getinfo('INDEX.json').file_size <= 2 * 1024 * 1024, 'missing or oversized index')
            index_raw = archive.read('INDEX.json')
            index = strict_json(index_raw)
            require(index['schema'] == 'hcsn-six-real-checkpoint-export-v1' and index['source_commit'] == SOURCE
                    and index['preexecution_sha256'] == PRE_SHA and type(index['model_executions']) is int
                    and index['model_executions'] == 0, 'original index identity differs')
            mapping = {}
            rows = []
            for item in index['files']:
                original = item['original_path']
                path = PurePosixPath(original)
                require(path.is_absolute() and path.as_posix() == original and not original.startswith('//')
                        and '\\' not in original and '..' not in path.parts and original not in mapping, 'ambiguous original path')
                member = item['member']
                require(member == 'root/' + original.lstrip('/') and member in names, 'index member differs')
                require(type(item['bytes']) is int and 0 <= item['bytes'] <= 128 * 1024 * 1024
                        and archive.getinfo(member).file_size == item['bytes'], 'member byte size differs')
                hasher = hashlib.sha256()
                total = 0
                with archive.open(member) as stream:
                    for data in iter(lambda: stream.read(1024 * 1024), b''):
                        total += len(data)
                        require(total <= item['bytes'], 'inflated member exceeds commitment')
                        hasher.update(data)
                require(total == item['bytes'] and hasher.hexdigest() == item['sha256'], 'member content differs')
                mapping[original] = item
                rows.append({'original_path': original, 'member': member, 'bytes': total,
                             'sha256': hasher.hexdigest(), 'crc_verified_by_zip_read': True})
            require({item['member'] for item in mapping.values()} | {'INDEX.json'} == set(names), 'unindexed ZIP member')
            require(len(mapping) == 555 and len(infos) == 556
                    and sum(item['bytes'] for item in mapping.values()) == 56675710, 'original full roster differs')
            pre_rows = [row for row in mapping.values() if row['sha256'] == PRE_SHA]
            require(len(pre_rows) == 1, 'original preexecution plan missing or ambiguous')
            pre_raw = archive.read(pre_rows[0]['member'])
            pre = strict_json(pre_raw)
            require(pre['schema'] == 'hcsn-real-checkpoint-replay-plan-v1' and pre['steps'] == 2
                    and pre['confirmation_access'] is False and len(pre['fits']) == 6, 'original six-fit plan differs')
            bindings = dict(pre['program_inputs'])
            fits = []
            for fit in pre['fits']:
                for path, expected_input in fit['inputs'].items():
                    require(path not in bindings or bindings[path] == expected_input, 'conflicting original input binding')
                    bindings[path] = expected_input
                checkpoint = mapping[fit['checkpoint']]
                require(fit['checkpoint_identity'] == {'bytes': checkpoint['bytes'], 'sha256': checkpoint['sha256']}, 'checkpoint identity differs')
                require(len(fit['model_sources']) == 37, 'original 37 model sources differ')
                for path, source_sha in fit['model_sources'].items():
                    require(mapping[path]['sha256'] == source_sha, 'model source not bound in original export')
                fits.append({'fit': fit['fit'], 'epoch': fit['expected_epoch'], 'logical_main_updates': fit['expected_main_updates'],
                             'checkpoint': fit['checkpoint_identity'], 'checkpoint_member': checkpoint['member'],
                             'bound_model_sources': len(fit['model_sources'])})
            require(sorted((f['epoch'], f['logical_main_updates']) for f in fits)
                    == sorted([(116, 1392), (76, 912), (126, 1512), (50, 600), (127, 1524), (72, 864)]), 'selected fit clocks differ')
            bindings[pre_rows[0]['original_path']] = {'bytes': len(pre_raw), 'sha256': digest(pre_raw)}
            require(set(bindings) == set(mapping), 'export roster differs from original plan inputs')
            require(all(bindings[path] == {'bytes': row['bytes'], 'sha256': row['sha256']} for path, row in mapping.items()),
                    'original plan input commitments differ')
            (OUT / 'INDEX.original.json').write_bytes(index_raw)
            (OUT / 'PREEXECUTION.original.json').write_bytes(pre_raw)
            (OUT / 'MEMBER_AUDIT.json').write_text(json.dumps(rows, sort_keys=True, indent=2) + '\n')
            after = archive_path.stat()
            require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'original archive changed during read')
            result.update(status='PASS_ORIGINAL_ARCHIVE_CUSTODY', indexed_original_files=len(mapping), zip_members=len(infos),
                          original_file_raw_bytes=56675710, zip_raw_bytes_with_index=sum(i.file_size for i in infos),
                          original_index_sha256=digest(index_raw), original_plan_sha256=digest(pre_raw),
                          complete_original_plan_bindings_verified=True, all_member_sha256_and_crc_verified=True,
                          six_checkpoints=fits, checkpoint_payloads_interpreted=False,
                          original_pointer_status='MISSING', pointer_claim_stale=True,
                          actual_cpu_recovery_qualified=False, budget_status='HOLD_UNKNOWN_UNCHANGED')
    except BaseException as error:
        result.update(status='FAILED_RETAINED', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        result.update(finished_utc=datetime.now(timezone.utc).isoformat(), wall_s=time.perf_counter() - started,
                      auditor_cpu_s=time.process_time() - cpu_started)
        save()
        print(json.dumps({key: result.get(key) for key in ('status', 'archive', 'indexed_original_files', 'zip_members',
                                                         'wall_s', 'auditor_cpu_s', 'error')}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
