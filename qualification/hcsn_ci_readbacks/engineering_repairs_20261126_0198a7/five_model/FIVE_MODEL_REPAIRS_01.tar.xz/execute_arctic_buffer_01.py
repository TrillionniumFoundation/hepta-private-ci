"""Root-owned hard bounded execution of the registered no-training contract."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time
import zlib


ROOT = Path('/home/alex/hepta-hcsn-fixes-20261126-0198a7')
PYTHON = '/home/alex/pft-six-actual-hcsn-20261125/venv/bin/python'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    assert len(sys.argv) == 4 and sha(Path(__file__).read_bytes()) == sys.argv[1]
    compressed = (ROOT / 'ARCTIC_BUFFER_01.json.zlib').read_bytes()
    assert sha(compressed) == sys.argv[2]
    raw = zlib.decompress(compressed)
    assert sha(raw) == sys.argv[3]
    package = json.loads(raw)
    target = ROOT / 'arctic_buffer_01'
    target.mkdir(exist_ok=False)
    for name, item in package['files'].items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        content = item['content'].encode('utf-8')
        assert len(content) == item['bytes'] and sha(content) == item['sha256']
        path = target / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
    registration = json.loads((target / 'ARCTIC_BUFFER_REGISTRATION.json').read_text())
    assert registration['max_attempts'] == 1 and registration['exact_counts']['optimizer_steps'] == 0
    record = {'status': 'STARTED', 'package_sha256': sha(raw), 'launcher_sha256': sys.argv[1],
              'registration_sha256': sha((target / 'ARCTIC_BUFFER_REGISTRATION.json').read_bytes()),
              'hard_child_cpu_soft_hard_s': [20, 21], 'hard_child_wall_s': 30, 'automatic_retry': False,
              'official_format_receipt_sha256': 'dd056af59588d64f9c0ecaf1ff23f17f425c044d08cd06ad5560634199db574b'}
    (target / 'LAUNCH.json').write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
    def limits():
        resource.setrlimit(resource.RLIMIT_CPU, (20, 21))
        resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024 * 1024, 8 * 1024 * 1024))
    started = time.perf_counter()
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
    with (target / 'contract.stdout').open('xb') as stdout, (target / 'contract.stderr').open('xb') as stderr:
        child = subprocess.Popen([PYTHON, '-B', str(target / 'run_arctic_buffer_contract.py'), str(target / 'RESULT.json')],
                                 cwd=target, env=env, stdout=stdout, stderr=stderr,
                                 start_new_session=True, preexec_fn=limits)
        try:
            child.wait(timeout=30)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=5)
            record['timed_out'] = True
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    record.update(exit_code=child.returncode, wall_s=time.perf_counter() - started,
                  child_cpu_s=after.ru_utime + after.ru_stime - usage.ru_utime - usage.ru_stime,
                  sources_unchanged=all(sha((target / name).read_bytes()) == item['sha256'] for name, item in package['files'].items()))
    if (target / 'RESULT.json').exists():
        result = json.loads((target / 'RESULT.json').read_text())
        record['contract_status'] = result['status']
        record['contract_result_sha256'] = sha((target / 'RESULT.json').read_bytes())
        record['observed_counts'] = result['counts']
    record['status'] = 'PASS' if child.returncode == 0 and record.get('contract_status') == 'PASS' and record['sources_unchanged'] else 'FAILED_RETAINED'
    (target / 'LAUNCH_RESULT.json').write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
    print(json.dumps(record, sort_keys=True), flush=True)
    if record['status'] != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
