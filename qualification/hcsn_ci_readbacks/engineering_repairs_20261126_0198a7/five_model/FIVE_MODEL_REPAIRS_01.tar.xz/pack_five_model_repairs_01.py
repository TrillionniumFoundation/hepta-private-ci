"""Preserve existing repair evidence; standard-library byte operations only."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile


ROOT = Path('/tmp/hepta_hcsn_fix_20261126_0198a7')
STEM = 'FIVE_MODEL_REPAIRS_01'
MAX_MEMBERS = 160
MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_TOTAL_BYTES = 10 * 1024 * 1024
PUBLIC_SINGLE_FILE_BYTES = 430_000
PART_BYTES = 400_000
EXTRA = [
    'execute_head_finalize_01.py',
    'HEAD_FINALIZE_01.json',
    'HEAD_FINALIZE_01.json.zlib',
    'execute_arctic_buffer_01.py',
    'ARCTIC_BUFFER_01.json',
    'ARCTIC_BUFFER_01.json.zlib',
    'FORMAT_05_INPUTS.json',
    'FORMAT_05_INPUTS.json.zlib',
    'FORMAT_06_INPUTS.json',
    'FORMAT_06_INPUTS.json.zlib',
    'format_validation_03.py',
    'format_validation_04.py',
    'peer_base/justfile',
    'peer_base/scripts/format.py',
    'peer_base/scripts/just-shell.py',
    'evidence/FORMAT_05.json',
    'evidence/FORMAT_06.json',
    'evidence/HEAD_FINALIZE_RESULT.json',
    'evidence/HEAD_FINALIZE_LAUNCH.json',
    'evidence/HEAD_FINALIZE_LAUNCH_RESULT.json',
    'evidence/HEAD_FINALIZE_contract.stdout',
    'evidence/HEAD_FINALIZE_contract.stderr',
    'evidence/HEAD_FINALIZE_REMOTE_FILES.json',
    'evidence/ARCTIC_RESULT.json',
    'evidence/ARCTIC_LAUNCH.json',
    'evidence/ARCTIC_LAUNCH_RESULT.json',
    'evidence/ARCTIC_contract.stdout',
    'evidence/ARCTIC_contract.stderr',
    'pack_five_model_repairs_01.py',
]
EXPECTED = {
    'evidence/HEAD_FINALIZE_RESULT.json': 'e9546450e9fa0203baf32a70edf214bb250524c852e75cbaf448661050eb0578',
    'evidence/HEAD_FINALIZE_LAUNCH_RESULT.json': 'ee634ba4c6b556c956ea67a63cc37c80ac0d07ac9fd12edfb423b0f8026897f2',
    'evidence/ARCTIC_RESULT.json': '862013b1f7e91e0fe7f5eb6e26a0bd2d58c5dd08ddb5f2175ffb86ed49748d69',
    'evidence/ARCTIC_LAUNCH_RESULT.json': '8c1e05c3ed6fdf2724d45a2ab97f371eb25dc7f6d9c7d4cd753b1894955350dd',
    'evidence/FORMAT_05.json': '461c1e45f0a6eed27e4956cf467df3bad7ec3381c4bfb8a9d10b79d61e8e87d3',
    'evidence/FORMAT_06.json': 'dd056af59588d64f9c0ecaf1ff23f17f425c044d08cd06ad5560634199db574b',
    'repo_residual_candidate/HEAD_FINALIZE_REGISTRATION.json': '34c02649b04f8ca3ce52dee83fc1a44db9d33a4c952b49fa1a4c559f30dd1915',
    'repo_residual_candidate/arctic_candidate/ARCTIC_BUFFER_REGISTRATION.json': '25f576cac36ce408abe042f6761753298f55f8027c3f966b470eab5ad983ab87',
    'repo_residual_candidate/source/qa/stem-bakeoff/replacement_physical.py': '8285304efd6003c7e7fdc87e32349d85e9cd5fc247879e625e9973d35fbc1067',
    'repo_residual_candidate/arctic_candidate/combined_source/qa/stem-bakeoff/replacement_physical.py': 'cc89aa970014c689d5ad8920972bdbcaf8faffdd1b231d01a87d1228b1e10873',
    'peer_base/justfile': '74f869224eba12fc4212b043428e7f5b35b551d26f5b06161c25d8aca525f124',
    'peer_base/scripts/format.py': '8d93d7a6261bbe5f2b9fceea228154f0be29f721015d05b4f538c30076dd80b3',
    'peer_base/scripts/just-shell.py': '444d6b328d44abf6453b77b6acce2a0c881fc162ff30b20f352c85067797fbe9',
}


def require(condition, description):
    if not condition:
        raise ValueError(description)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(name, data):
    return {'path': name, 'bytes': len(data), 'sha256': sha(data)}


def main():
    output = ROOT / (STEM + '.tar.xz')
    index_path = ROOT / (STEM + '.index.json')
    require(not output.exists() and not index_path.exists(), 'existing output: do not replace')
    names = set(EXTRA)
    for path in (ROOT / 'repo_residual_candidate').rglob('*'):
        require(not path.is_symlink(), 'symlink in residual snapshot')
        if path.is_dir():
            continue
        require(path.is_file(), 'nonregular residual entry')
        if not path.name.startswith(STEM):
            names.add(path.relative_to(ROOT).as_posix())
    require(len(names) + 1 <= MAX_MEMBERS, 'member cap exceeded')
    payload = {}
    for name in sorted(names):
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and '..' not in relative.parts, 'unsafe member')
        path = ROOT / name
        require(path.is_file() and not path.is_symlink(), 'missing or linked input: ' + name)
        require(path.stat().st_size <= MAX_FILE_BYTES, 'input size cap: ' + name)
        payload[name] = path.read_bytes()
    require(sum(map(len, payload.values())) <= MAX_TOTAL_BYTES, 'total payload cap exceeded')
    for name, digest in EXPECTED.items():
        require(sha(payload[name]) == digest, 'frozen byte identity differs: ' + name)

    bindings = []
    for label, base, registration_name, prefix, count, package, launcher, format_name in [
        ('harrier', 'repo_residual_candidate', 'HEAD_FINALIZE_REGISTRATION.json',
         'HEAD_FINALIZE', 6, 'HEAD_FINALIZE_01.json', 'execute_head_finalize_01.py', 'FORMAT_05'),
        ('arctic', 'repo_residual_candidate/arctic_candidate', 'ARCTIC_BUFFER_REGISTRATION.json',
         'ARCTIC', 14, 'ARCTIC_BUFFER_01.json', 'execute_arctic_buffer_01.py', 'FORMAT_06'),
    ]:
        registration_path = base + '/' + registration_name
        registration = json.loads(payload[registration_path])
        require(len(registration['files']) == count, 'registration denominator differs')
        for relative, identity in registration['files'].items():
            data = payload[base + '/' + relative]
            require(len(data) == identity['bytes'] and sha(data) == identity['sha256'],
                    'registered source differs: ' + relative)
        result_path = 'evidence/' + prefix + '_RESULT.json'
        launch_path = 'evidence/' + prefix + '_LAUNCH_RESULT.json'
        result = json.loads(payload[result_path])
        launch = json.loads(payload[launch_path])
        require(result['status'] == launch['status'] == 'PASS', 'non-PASS original receipt')
        require(result['counts'] == launch['observed_counts'] == registration['exact_counts'],
                'original count denominator differs')
        require(launch['sources_unchanged'] is True and launch['automatic_retry'] is False,
                'original source/retry scope differs')
        for name, key in [(result_path, 'contract_result_sha256'),
                          (registration_path, 'registration_sha256'),
                          (package, 'package_sha256'), (launcher, 'launcher_sha256'),
                          ('evidence/' + format_name + '.json', 'official_format_receipt_sha256')]:
            require(sha(payload[name]) == launch[key], 'launch receipt byte link differs: ' + key)
        format_result = json.loads(payload['evidence/' + format_name + '.json'])
        require(format_result['status'] == 'PASS' and format_result['sources_unchanged'] is True,
                'original formatter receipt differs')
        bindings.append({'contract': label, 'registered_files_verified': count,
                         'result': pin(result_path, payload[result_path])})

    manifest = {
        'schema': 'hepta.five-model-repair-evidence-archive.v1',
        'base_head': 'eadf2999991c147759785f5eec722b9d6e796a9a',
        'scope': 'Byte preservation only; no model, test, formatter, import of project sources, or CI invocation.',
        'historical_registration_statuses_preserved': True,
        'historical_packaging_proposal_preserved': True,
        'packaging_bounds': {'members_including_manifest': MAX_MEMBERS,
                             'max_file_bytes': MAX_FILE_BYTES, 'max_payload_bytes': MAX_TOTAL_BYTES},
        'payload_count': len(payload),
        'payload_bytes': sum(map(len, payload.values())),
        'contracts': bindings,
        'members': [pin(name, data) for name, data in payload.items()],
    }
    manifest_data = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    require(len(manifest_data) <= MAX_FILE_BYTES, 'manifest size cap exceeded')
    all_members = {'MANIFEST.json': manifest_data, **payload}
    with tarfile.open(output, mode='x:xz', format=tarfile.PAX_FORMAT, preset=6) as archive:
        for name, data in sorted(all_members.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.mode = len(data), 0, 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            archive.addfile(info, io.BytesIO(data))

    with tarfile.open(output, mode='r:xz') as archive:
        members = archive.getmembers()
        require(len(members) == len(all_members), 'archive member count differs')
        require({member.name for member in members} == set(all_members), 'archive member set differs')
        for member in members:
            require(member.isfile() and member.size <= MAX_FILE_BYTES, 'unsafe archive entry')
            recovered = archive.extractfile(member).read()
            require(recovered == all_members[member.name], 'archive byte roundtrip differs')
    for name, data in payload.items():
        require((ROOT / name).read_bytes() == data, 'source changed while preserving: ' + name)

    archive_data = output.read_bytes()
    parts = []
    if len(archive_data) > PUBLIC_SINGLE_FILE_BYTES:
        for number, start in enumerate(range(0, len(archive_data), PART_BYTES), 1):
            name = STEM + '.tar.xz.part' + str(number).zfill(3)
            chunk = archive_data[start:start + PART_BYTES]
            with (ROOT / name).open('xb') as stream:
                stream.write(chunk)
            parts.append(pin(name, chunk))
        require(b''.join((ROOT / item['path']).read_bytes() for item in parts) == archive_data,
                'ordered part roundtrip differs')
    index = {
        'schema': 'hepta.five-model-repair-evidence-index.v1',
        'archive': pin(output.name, archive_data),
        'manifest': pin('MANIFEST.json', manifest_data),
        'archive_members_verified': len(all_members),
        'payload_members_verified': len(payload),
        'payload_bytes': sum(map(len, payload.values())),
        'parts_in_order': parts,
        'source_base_head': manifest['base_head'],
        'harrier_registered_files_verified': 6,
        'arctic_registered_files_verified': 14,
        'harrier_result_sha256': EXPECTED['evidence/HEAD_FINALIZE_RESULT.json'],
        'arctic_result_sha256': EXPECTED['evidence/ARCTIC_RESULT.json'],
        'historical_originals_preserved': True,
        'new_model_test_formatter_or_ci_calls_during_packaging': 0,
        'full_member_list': 'MANIFEST.json#members',
        'scope': 'Two once-only synthetic contracts; real model/full workflow/production qualification not asserted.',
    }
    index_text = '{\n' + ',\n'.join('  ' + json.dumps(key) + ': ' + json.dumps(value, ensure_ascii=False, sort_keys=True)
                                   for key, value in index.items()) + '\n}\n'
    require(len(index_text.splitlines()) <= 50, 'public index line budget exceeded')
    with index_path.open('x') as stream:
        stream.write(index_text)
    print(json.dumps({'status': 'PRESERVED_AND_BYTE_VERIFIED', 'archive': index['archive'],
                      'index': pin(index_path.name, index_path.read_bytes()),
                      'members_verified': len(all_members), 'payload_bytes': index['payload_bytes'],
                      'index_lines': len(index_text.splitlines()), 'parts': parts}, sort_keys=True))


if __name__ == '__main__':
    main()
