"""Stage only registered repair sources and run the official scoped formatter."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zlib


ROOT = Path('/Users/qianqi/work/hepta-hcsn-fixes-20261126-0198a7')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    if len(sys.argv) != 4 or sha(Path(__file__).read_bytes()) != sys.argv[1]:
        raise ValueError('formatter driver identity differs')
    encoded = (ROOT / 'FORMAT_05_INPUTS.json.zlib').read_bytes()
    if sha(encoded) != sys.argv[2]:
        raise ValueError('format transport differs')
    raw = zlib.decompress(encoded)
    if sha(raw) != sys.argv[3]:
        raise ValueError('format input differs')
    plan = json.loads(raw)
    receipt = ROOT / 'FORMAT_05.json'
    if receipt.exists():
        raise FileExistsError('format receipt already exists')
    for name, row in plan['files'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts:
            raise ValueError('invalid relative source')
        content = row['content'].encode()
        if sha(content) != row['sha256']:
            raise ValueError('source bytes differ')
        target = ROOT / 'source' / name
        if target.exists() and name.endswith('.py') and target.read_bytes() != content:
            raise ValueError('existing owned source would be overwritten: ' + name)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    environment['PATH'] = '/opt/homebrew/bin:' + environment.get('PATH', '')
    process = subprocess.run(['/opt/homebrew/bin/just', 'fmt'], cwd=ROOT / 'source',
                             env=environment, capture_output=True, text=True, timeout=90)
    unchanged = all(sha((ROOT / 'source' / name).read_bytes()) == row['sha256'] for name, row in plan['files'].items())
    result = {'status': 'PASS' if process.returncode == 0 and unchanged else 'FAILED',
              'exit_code': process.returncode, 'sources_unchanged': unchanged,
              'input_sha256': sha(raw), 'runner_sha256': sys.argv[1],
              'files': {name: row['sha256'] for name, row in plan['files'].items()},
              'stdout': process.stdout, 'stderr': process.stderr,
              'tests_or_models_run': 0, 'scope': 'Official just fmt in owned source subset; not a full repository checkout.'}
    receipt.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'files': len(plan['files']), 'receipt_sha256': sha(receipt.read_bytes())}))
    if result['status'] != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
