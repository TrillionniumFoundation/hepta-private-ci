# Harrier 冻结完成修复与一次零训练合同

## 已观察的失败

当前源固定为 `eadf2999991c147759785f5eec722b9d6e796a9a`。最新已完成可读失败是 [run 45725442385 / Harrier job 139594026260](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45725442385/job/139594026260)，源头 `61a32d54afbb57af1dfeb52e7f8c703fc2599d63`。栈由 `replacement_physical.py:291` 进入 `replacement_head_scale.py:77`，原 guard 拒绝 “trained Head must be evaluation-only and frozen”。当前源两文件的相关实现没有吸收清理修复。

原训练循环每轮开头 zero_grad、backward、step；最后一次 step 后只 eval 和 requires_grad_(False)。最后梯度仍存于 param.grad，因而不满足原 guard 的 grad is None 条件。该判断来自源与原日志；本次未重新训练。

## 最小生产源码候选

`source/qa/stem-bakeoff/replacement_physical.py` 新增短函数 `finalize_task_head(head)`，依次调用 `head.zero_grad(set_to_none=True)`、`head.eval()`、`head.requires_grad_(False)`，返回原对象。训练循环之后调用该函数。200 次 AdamW 更新、初始化、学习率、校准、pooling、数据与真实模型路径不变；原 fanout guard 文件字节保持不变。

本目录的 source 是隔离验证所需的五个源码文件。只有 replacement_physical.py 是修复候选，另外四个均为原 eadf2999 文件，不应在发布 PR 中重复新增。

## 固定一次验证

执行前注册文件为 `HEAD_FINALIZE_REGISTRATION.json`，runner 为 `run_head_finalize_contract.py`；当前状态 REGISTERED_NOT_EXECUTED。源文件与 runner 的 bytes/SHA256 全部固定。

- 使用已存在的 `/home/alex/pft-six-actual-hcsn-20261125/venv/bin/python`：Python 3.14.4、Torch 2.15.0+cpu、NumPy 2.5.5，两个线程设置均为 1。
- 仅构造一次 CPU float32 Linear(4,4)，固定 seed 7；weight 人工 grad=0.25，bias 人工 grad=0.5。没有输入样本或标签。
- 第一次原 guard 调用：先设 eval/requires_grad false，但保留人工梯度，应在原冻结 guard 拒绝。然后恢复 training/requires_grad true，调用候选 finalizer 一次，检验完整状态转换。
- 第二次原 guard 调用：清理后必须穿过原冻结条件，随后因 features=None 在原 CPU feature 检查拒绝。两个调用均在 fanout 分配和前向之前终止。
- 两个参数逐项 torch.equal，完整原 tensor_digest 前后相等。Linear 本身没有 buffers；回执明确记录 buffer_tensor_count=0，不把空集合说成实际测试过非空 buffer。
- 精确次数：1 tiny Linear 构造、2 guard 调用、1 finalizer、2 digest；0 checkpoint load、forward、backward、autograd.grad、optimizer 构造/更新、训练函数、seed search。runner 对训练函数、autograd、optimizer 构造和 Head 前向设拒绝探针。
- 上限 30 秒 wall / 20 秒 CPU，max_attempts=1；独立新输出文件，失败原件必须保留。原 formal 的 3 loads / 3 forwards 已用预算保持原状。

该合同只验证生命周期清理及原拒绝条件的连接，不证明 Torch 2.10.0 / NumPy 2.2.6 的原五模型 runtime，也不证明 Harrier 物理成功或任务收益。禁止调用原 deterministic 训练测试或五模型工作流；不重新执行任何成功 Laya。

## 独立 NumPy 依赖候选

`candidate_workflow/.github/workflows/hepta-neuron-five-model-physical-shadow.yml` 只在 contracts venv 安装 Torch 后增加固定 NumPy 2.2.6 的两行 pip 命令，版本直接来自同仓 requirements-real.txt。原 [physical-contracts job 139594025984](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45725442385/job/139594025984) 在原 digest 的 .numpy() 因缺 NumPy 失败。

这个 workflow 同时含五模型 PR 触发；不得为验证两行依赖而开触发全部五模型的 PR。当前仅准备独立候选分支材料，不安装依赖、不执行测试、不改 trigger 或模型矩阵、不 dispatch。
