# R20 frontier identity v2：专项托管 CI 已闭合

只读取证时间：2026-11-26。没有 dispatch、rerun、取消或新的本地测试。

[run 45770786793](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45770786793) / [job 139742648761](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45770786793/job/139742648761)，PR #7123，exact head `8fd7241aee850d3e2823d4f699d242525838f42e`：completed / success。工作流使用 exact PR head checkout，原 job 日志也记录此 SHA。

原日志逐项列出 9 个回归成功，摘要 `Ran 9 tests in 0.047s / OK`。其中实际 CLI 方法在精确测试源 Git blob `98bad1551737c8b2ec34a0f12cb23217e618feea` 中只有一次 subprocess.run：a=1.54696889、b=0.44887401、cap=1、timeout=10 秒。成功断言为新 schema、nodes_split=1、passes_frozen_global_threshold=False、frontier 的所有 ID 唯一。

子进程使用 capture_output=True，因此 hosted 日志没有独立保存其原 stdout/stderr；不能把测试源码中的命令文本称为独立原 CLI 日志。固定源码、唯一调用与该测试成功可支持一次真实 CLI 调用的结论。没有扩展 CLI 内部算术调用计数的主张。

闭合范围是这次 exact head 的独立 v2 frontier 身份专项 CI：root-stop、stop/reinsert、nonstop 第二次分裂、pruning、旧重复 ID 反例、数学 receipt/boxes 保持、算术源拒绝以及真实 CLI 路由。旧冻结全局阈值失败继续保留；这不等于旧 80 项原数学审核重新通过、其他全仓 workflow 通过或生产 qualification。

原件：RUN_45770786793.json SHA256 `a180a3d14575214588882a84e6cad7e4f1244daae6036fcd40f80af52dae78eb`；JOBS_45770786793.json `580bf5a89a600a0b6785d68143d2601a2386d043e5f3436c6465520788ccff99`；JOB_139742648761.log `29d3c84a1efe3f0b14cb85509eda083a5da93f82a51c4a92d107bc1bce3b1c42`。同时保留原 WORKFLOW.yml 和 test_frontier_identity.py。
