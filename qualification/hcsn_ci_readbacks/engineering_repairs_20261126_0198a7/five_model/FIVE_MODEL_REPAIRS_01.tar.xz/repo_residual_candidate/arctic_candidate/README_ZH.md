# Arctic 增量移植与固定模拟合同

## 来源与历史成功

基线 `eadf2999991c147759785f5eec722b9d6e796a9a` 的 Arctic 尚缺 RoPE 非持久 buffers 和 Transformers 5 兼容处理。[现有修复链 #3970](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/3970) → [#3985](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/3985) → [#3989](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/3989) → [#3990](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/3990) 已分别实现四个 buffer 重建、加载后参数一致性、单行 unpadded mask 和严格回执类型。源末端为 `1adc9c57449964f5848b29c7e2063a983e110b43`；这里复用这些实现，未重新研究替代算法。

#3989 的 exact head `3ee6d658c34762c886d4fa4a9772d8cc1740fd8a` 已在 [run 40261162978](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/40261162978) 获得七个 job 全部 success。重新读取的 [Arctic 原 job 121373660461](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/40261162978/job/121373660461) 日志明确记录 40 次真实前向和 production_activation_allowed=false；原 [cross-arm job 121411135431](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/40261162978/job/121411135431) 记录五份 ZIP digest 匹配以及 HOLD_NO_GO / REVIEW_REQUIRED。当前 artifact API 列表为空；本次只保全仍可读取的原日志与元数据，没有重新获取不存在的 raw output，也没有重跑成功模型。

该旧协议成功不等于当前 eadf 增加 fanout 后的全协议成功，也不构成生产资格。现行 requirements-real.txt 与旧/新原日志都固定 Transformers **5.20.2**；4.57 来自另一路环境，不能混为本协议。专用 shim 继续拒绝非 5.20.2、已有 get_extended_attention_mask、非 CPU float32、启用 unpadding/xFormers 或不符合单行全 1 mask 的输入。

## 可移植差分

`source/` 为独立 Arctic 增量；`combined_source/` 是在其上叠加已验证的 Harrier finalizer 的发布候选。不要用独立 source 的整文件覆盖已验证的 finalizer。原登记 Harrier 文件保留于父目录，并没有被改写或再次执行。

| 文件 | Arctic 新增行 | 合并 Harrier 后 |
|---|---:|---:|
| replacement_arctic_unpadded_mask.py（新） | 47 | 47 |
| replacement_parameter_identity.py（新） | 85 | 85 |
| replacement_physical.py | 90 | +99 / -3 |
| replacement_physical_audit.py | 33 | 33 |
| test_replacement_arctic_unpadded_mask.py（新） | 64 | 64 |
| test_replacement_parameter_identity.py（新） | 106 | 106 |
| test_replacement_physical.py | 69 | 69 |
| test_replacement_physical_audit.py | 73 | 73 |

Arctic 为 +567/-0；合并源码/测试为 +576/-3，总 579 行。原 200-step 函数、初始化/学习率/数据/模型 pins/Laya、当前 fanout 和 scale audit 都保留。COMPOSITION.json 直接比较已验证 Harrier 的 finalizer 函数和整个训练函数字节，均相同；组合后的文件 SHA256 为 `cc89aa970014c689d5ad8920972bdbcaf8faffdd1b231d01a87d1228b1e10873`。

当前 qa/ 与 qa/stem-bakeoff/ 树均没有更近 AGENTS.md，适用根 AGENTS。四个新增 Python 文件没有 __future__ import；现有 replacement_physical.py 的原 future 保留。辅助的五个未修改依赖只是隔离验证输入，不是额外发布改动。

## 一次固定模拟合同：尚未执行

`ARCTIC_BUFFER_REGISTRATION.json` 固定 13 个源/fixture 与 runner 的字节；`run_arctic_buffer_contract.py` 只使用普通 Python Gte/Embeddings/Rotary 模拟对象各一个、一个 4-byte 值为 3.0 的 tensor 假参数。它不构造 nn.Module、真实 GTE 或 Transformers 模型，不调用原完整 test discovery。

| 操作 | 固定次数 | 判据 |
|---|---:|---|
| restore | 3 | 1 次非默认 rope_scaling 拒绝，2 次重建；首次发现坏 buffer，重复时确认确定性 |
| 参数 identity | 6 | 4 次在两次重建内部、2 次独立前后比较；假参数 torch.equal 且 digest 不变 |
| 合成 RoPE 索引 | 2 | 原巨大 position_ids 对长度 13 的表拒绝；修复后得到 13×64 |
| install mask | 5 | 非 5.20.2 两次、unpad=True、已有 API 共 4 次拒绝；合法配置 1 次安装 |
| mask | 8 | 长度 13/192 两次零 additive bias；padding、batch2、193、float mask、shape 不符、空长六次拒绝 |

真实 checkpoint load、nn.Module forward、模型 run、训练函数、backward、autograd.grad、optimizer 构造/更新和 seed search 都为 0，代码中设拒绝探针。没有重新执行 Harrier 清理合同或任何旧五模型/200-step试验。

runtime 为已经存在的 formal venv：Python 3.14.4 / Torch 2.15.0+cpu / NumPy 2.5.5，threads/interop_threads=1。**metadata.version 的 4.57.1、5.20.3、5.20.2 是模拟分支输入；这不是实际 Transformers 5.20.2 运行期资格。**登记要求外层 hard wall 30 秒、CPU soft/hard 20/21 秒；driver 本身另有 30 wall / 20 CPU 事后验收，不能代替外层硬限制。max_attempts=1，失败原件不得覆盖或自动重试。

合同比较范围仅为假坏 buffer 的确定性重建、参数保全和原版本/API/输入拒绝边界。它不证明真实新 head 的 Arctic 前向、任务质量、4096 fanout、原五模型全协议或生产采用。

## 发布布局

正式差分只需上述 8 文件，加精简说明/原结果和有界原件归档。未修改的依赖不重复发布。driver、registration、原静态说明、完整源身份、全部原始输出/日志可按既有归档方式保留；不得为行数预算改 guard、改执行源码或删原始失败。加独立 NumPy 两行恢复仍只有 581 行源码/测试变更，留有正文与索引空间；最终必须按实际 commit diff 计算 <800。
