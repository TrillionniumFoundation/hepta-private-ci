"""Fixed plain-object RoPE/mask contract; no Encoder construction or forward."""

import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
import time
from types import SimpleNamespace
from unittest import mock


ROOT = Path(__file__).resolve().parent


def file_identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def simulated_encoder(torch):
    class RotaryEmbedding:
        dim, base, max_position_embeddings = 64, 160000, 8192
        max_seq_len_cached = 8192

        def __init__(self):
            self._non_persistent_buffers_set = {"inv_freq", "cos_cached", "sin_cached"}
            self.inv_freq = torch.full((32,), float("nan"))
            self.cos_cached = torch.full((8192, 64), float("nan"))
            self.sin_cached = torch.full((8192, 64), float("nan"))

        def register_buffer(self, name, value, *, persistent):
            require(persistent is False and name in self._non_persistent_buffers_set,
                    "unexpected simulated rotary buffer registration")
            setattr(self, name, value)

    class GteEmbeddings:
        def __init__(self):
            self._non_persistent_buffers_set = {"position_ids"}
            self.position_ids = torch.full((8192,), 2**62, dtype=torch.long)
            self.rotary_emb = RotaryEmbedding()

        def register_buffer(self, name, value, *, persistent):
            require(persistent is False and name == "position_ids",
                    "unexpected simulated position buffer registration")
            setattr(self, name, value)

    class GteModel:
        def __init__(self):
            self.config = SimpleNamespace(max_position_embeddings=8192, hidden_size=768,
                num_attention_heads=12, rope_theta=160000, rope_scaling=None,
                position_embedding_type="rope", use_memory_efficient_attention=False,
                unpad_inputs=False)
            self.embeddings = GteEmbeddings()
            self.weight = torch.tensor([3.0], dtype=torch.float32)

        def parameters(self):
            return iter((self.weight,))

        def named_parameters(self, *, remove_duplicate):
            return iter((("weight", self.weight),))

        def state_dict(self):
            return {"weight": self.weight}

    return GteModel()


def main():
    require(len(sys.argv) == 2, "one new result path is required")
    output = Path(sys.argv[1])
    require(not output.exists(), "one-shot result already exists")
    wall, cpu = time.perf_counter(), time.process_time()
    counts = dict(simulated_gte_objects=0, simulated_embedding_objects=0,
                  simulated_rotary_objects=0, restore_calls=0,
                  parameter_identity_snapshots=0, synthetic_rope_index_calls=0,
                  install_mask_calls=0, synthetic_mask_calls=0,
                  checkpoint_loads=0, nn_module_calls=0, model_run_calls=0,
                  training_function_calls=0, backward_calls=0, autograd_grad_calls=0,
                  optimizer_constructions=0, optimizer_steps=0, seed_searches=0)
    result = {"schema": "hepta.arctic-plain-object-buffer-contract.v1",
              "status": "STARTED", "counts": counts,
              "transformers_version_check_mocked": True}

    def forbid(name):
        def fail(*args, **kwargs):
            counts[name] += 1
            raise RuntimeError("forbidden operation: " + name)
        return fail

    def rejected(kind, callback, message):
        try:
            callback()
        except kind as error:
            require(message in str(error), "unexpected rejection: " + str(error))
            return str(error)
        raise ValueError("expected rejection was absent")

    try:
        registration_path = ROOT / "ARCTIC_BUFFER_REGISTRATION.json"
        registration = json.loads(registration_path.read_text())
        sources = registration["files"]
        result["registration"] = file_identity(registration_path)
        for name, identity in sources.items():
            require(not Path(name).is_absolute() and ".." not in Path(name).parts,
                    "invalid registered source path")
            require(file_identity(ROOT / name) == identity, "source mismatch: " + name)
        result["source_files"] = sources
        import numpy
        import torch
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        runtime = dict(python=platform.python_version(), torch=torch.__version__,
                       numpy=numpy.__version__, threads=torch.get_num_threads(),
                       interop_threads=torch.get_num_interop_threads())
        require(runtime == registration["runtime"], "registered runtime differs")
        result.update(runtime=runtime, executable=sys.executable)
        try:
            result["actual_transformers_distribution"] = importlib.metadata.version("transformers")
        except importlib.metadata.PackageNotFoundError:
            result["actual_transformers_distribution"] = None
        source = ROOT / "combined_source" / "qa" / "stem-bakeoff"
        sys.path.insert(0, str(source))
        import replacement_physical as physical
        import replacement_parameter_identity as identity
        import replacement_arctic_unpadded_mask as shim
        for module in (physical, identity, shim):
            require(Path(module.__file__).resolve().parent == source.resolve(),
                    "unexpected imported module origin")
        original_identity = identity.parameter_identity

        def snapshot(encoder):
            counts["parameter_identity_snapshots"] += 1
            return original_identity(encoder)

        def restore(encoder):
            counts["restore_calls"] += 1
            return physical.restore_arctic_nonpersistent_buffers(encoder)

        def install(encoder, version):
            counts["install_mask_calls"] += 1
            with mock.patch.object(shim.metadata, "version", return_value=version):
                return shim.install_arctic_unpadded_mask(encoder)

        def index(encoder):
            counts["synthetic_rope_index_calls"] += 1
            return encoder.embeddings.rotary_emb.cos_cached[:13][encoder.embeddings.position_ids[:13]]

        with mock.patch.object(physical, "parameter_identity", snapshot), \
             mock.patch.object(physical, "run", forbid("model_run_calls")), \
             mock.patch.object(physical, "train_task_head", forbid("training_function_calls")), \
             mock.patch.object(torch, "load", forbid("checkpoint_loads")), \
             mock.patch.object(torch.nn.Module, "_call_impl", forbid("nn_module_calls")), \
             mock.patch.object(torch.autograd, "backward", forbid("backward_calls")), \
             mock.patch.object(torch.Tensor, "backward", forbid("backward_calls")), \
             mock.patch.object(torch.autograd, "grad", forbid("autograd_grad_calls")), \
             mock.patch.object(torch.optim.Optimizer, "__init__", forbid("optimizer_constructions")), \
             torch.no_grad():
            encoder = simulated_encoder(torch)
            counts.update(simulated_gte_objects=1, simulated_embedding_objects=1,
                          simulated_rotary_objects=1)
            before = snapshot(encoder)
            weight_before = encoder.weight.clone()
            result["invalid_position_error"] = rejected(IndexError, lambda: index(encoder), "out of bounds")
            encoder.config.rope_scaling = {"type": "linear", "factor": 2}
            rejected(ValueError, lambda: restore(encoder), "unexpected pinned Arctic")
            encoder.config.rope_scaling = None
            first, second = restore(encoder), restore(encoder)
            require(first["original_position_buffer_valid"] is False
                    and first["original_rope_cache_valid"] is False,
                    "corrupt synthetic buffers were not detected")
            require(second["original_position_buffer_valid"] is True
                    and second["original_rope_cache_valid"] is True,
                    "repeat reconstruction was not stable")
            require(tuple(index(encoder).shape) == (13, 64), "repaired bounded index failed")
            require(torch.equal(encoder.embeddings.position_ids, torch.arange(8192)),
                    "position sequence differs")
            rotary = encoder.embeddings.rotary_emb
            require(torch.isfinite(rotary.cos_cached).all() and torch.isfinite(rotary.sin_cached).all(),
                    "repaired RoPE cache is nonfinite")
            require(torch.equal(rotary.cos_cached[0], torch.ones(64))
                    and torch.equal(rotary.sin_cached[0], torch.zeros(64)), "RoPE origin differs")
            for version in ("4.57.1", "5.20.3"):
                rejected(ValueError, lambda: install(encoder, version), "unexpected pinned Arctic")
                require(not hasattr(encoder, "get_extended_attention_mask"), "rejected version installed API")
            encoder.config.unpad_inputs = True
            rejected(ValueError, lambda: install(encoder, "5.20.2"), "unexpected pinned Arctic")
            encoder.config.unpad_inputs = False
            mask_receipt = install(encoder, "5.20.2")
            installed = encoder.get_extended_attention_mask
            rejected(ValueError, lambda: install(encoder, "5.20.2"), "unexpected pinned Arctic")
            require(encoder.get_extended_attention_mask is installed, "existing API was replaced")
            for length in (13, 192):
                counts["synthetic_mask_calls"] += 1
                value = installed(torch.ones(1, length, dtype=torch.long), (1, length))
                require(tuple(value.shape) == (1, 1, 1, length)
                        and value.dtype == torch.float32 and torch.count_nonzero(value) == 0,
                        "unpadded additive mask differs")
            invalid_masks = [(torch.tensor([[1, 0]]), (1, 2)),
                (torch.ones(2, 3, dtype=torch.long), (2, 3)),
                (torch.ones(1, 193, dtype=torch.long), (1, 193)),
                (torch.ones(1, 3), (1, 3)),
                (torch.ones(1, 3, dtype=torch.long), (1, 2)),
                (torch.ones(1, 0, dtype=torch.long), (1, 0))]
            for mask, shape in invalid_masks:
                counts["synthetic_mask_calls"] += 1
                rejected(ValueError, lambda: installed(mask, shape), "one unpadded bounded binary mask")
            after = snapshot(encoder)
            require(before == after and torch.equal(weight_before, encoder.weight),
                    "simulated parameter bytes changed")
            require(first["loaded_parameter_identity"]["before"] == before
                    and second["loaded_parameter_identity"]["after"] == after,
                    "parameter identity receipts differ")
            result.update(parameter_before=before, parameter_after=after,
                          parameter_torch_equal=True, restore_receipts=[first, second],
                          mask_receipt=mask_receipt)
        require(counts == registration["exact_counts"], "fixed operation counts differ")
        require(all(file_identity(ROOT / name) == value for name, value in sources.items()),
                "registered source changed during contract")
        result["status"] = "PASS"
    except BaseException as error:
        result.update(status="FAILED", error=type(error).__name__ + ": " + str(error))
    result.update(wall_s=time.perf_counter() - wall, process_cpu_s=time.process_time() - cpu,
                  real_transformers_runtime_qualified=False, real_arctic_execution=False,
                  original_five_model_protocol_replayed=False, production_adoption=False)
    if result["wall_s"] > 30 or result["process_cpu_s"] > 20:
        result.update(status="FAILED", error="30 wall / 20 CPU second acceptance limit exceeded")
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, sort_keys=True, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "result": str(output), "counts": counts}))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
