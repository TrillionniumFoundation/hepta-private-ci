# N256：历史宿主观察已完成，当前为宿主标签漂移

## 固定源和原件

本次只读基线为 [PR #6799](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6799) 的 `eadf2999991c147759785f5eec722b9d6e796a9a`。本目录 `n256_original/` 保留当前相关源码与 V1/V2 冻结记录；没有修改旧 hash、启动观察、导入模型或创建 V3。

[原 PR #6627](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6627) 的最终归档头为 `4f58ca6b956620fcea05d52e274aa9fc6ac3d29b`。原 attempt002 在源 `1960091ad47d51a27b5ef6cabd2413f24bf9346e`、[run 44253300311 / job 134628918636](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/44253300311/job/134628918636) 已成功。此次重新读取 GitHub job 元数据、完整原日志和原 `evidence/attempt002/TERMINAL.json`（Git blob `71bfd144d096f591182fc5c0d9ed71d13ff817ed`），没有重跑。

原日志直接记录 Ubuntu 24.04、成功设置 CPython 3.12.3、安装 NumPy 2.3.5 / SciPy 1.17.0、5 个 normal 和 5 个 optimized stdlib 控制通过。原 artifact 为 14404508535，1718 bytes，ZIP SHA256 `8c0f54e7a49353615bac59c19e6072445b3453aa829b0d6d31e9a709b135fb13`；观察 JSON 3358 bytes，SHA256 `c68136d3c80ff4f46feee57556a4d09adaf2e1e1fa6dd14828d353bfc6b64233`。原 terminal 的 runtime/resource admission 与 all_closed 均为 false，零 N256 输入、动态步、expm、Torch、optimizer。

[PR #6635](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6635) 保留由 evidence commit 的累计 PR 路径意外触发的第三次零模型观察；它没有增加 qualification。原先运行成功不能解释为未来宿主自动获准，也不能重新开启旧 dense-oracle 数值预算。

## 当前失败的具体边界

[run 45737994728 / job 139635794328](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45737994728/job/139635794328) 的原日志为 Ubuntu 26.04.1，setup-python 报 exact 3.12.3 x64 不可用。失败发生在 install / source verifier / capture 之前。当前 eadf 的新 run 45773724852 / job 139752242809 在本次取证时仍 queued，不能把较早失败标作其终局。

旧 live workflow 一直写 `runs-on: ubuntu-latest`。当前 workflow 与 #6627/#6635 历史文件为相同 Git blob `e453fab8231e24518f9fa6dfebd5a376b8049005`；当前本地取回字节 SHA256 为 `3d69f39a83742f187a8d491517cc581cfd960d20f086fdf698334a78192c5a17`，正是旧 `SOURCE_FREEZE_V2.json` 的 workflow pin。原 request 也明确 runner=ubuntu-latest。

因此改为 ubuntu-24.04 虽能针对已观察的宿主问题，却必然改变被旧协议固定的 workflow 字节。把旧冻结 hash 改为新 hash 来求绿，会丢失旧注册的含义；本次没有这样做。

## 已有修复和本次处理

[PR #6740](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6740)（`aaf21cfe196d53aaf5c80e15777fd36d4509e981`）和 [PR #6817](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6817)（`4ed09f519f5788d5a4bd9b10cf2902a11a9738cc`）已有 Ubuntu 24.04 修复，但对象为独立 dense-oracle job。其原 warm-1 执行已经完成，不是重新获得一次数值执行机会。

本次交付为原源、原 job、原终局和修复范围的说明。历史宿主观察无需再做；当前 workflow 的未来迁移如被安排，应作为新的、明确版本化的宿主契约保留旧注册，而不是宣称旧 source guard 已允许改动。这里没有造 V3、改触发器、放宽 guard 或重启任何 workflow。现有全仓 HOLD 与所有未闭合科学/生产边界保持其真实状态。
