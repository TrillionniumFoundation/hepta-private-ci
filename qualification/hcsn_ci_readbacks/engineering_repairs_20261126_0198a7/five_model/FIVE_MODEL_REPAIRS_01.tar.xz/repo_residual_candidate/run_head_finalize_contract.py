"""One fixed synthetic lifecycle contract; no fitting or model forward."""

import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
import time
from unittest import mock


ROOT = Path(__file__).resolve().parent


def file_identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    if len(sys.argv) != 2:
        raise ValueError("one new result path is required")
    output = Path(sys.argv[1])
    if output.exists():
        raise FileExistsError("the one-shot result path already exists")
    started_wall, started_cpu = time.perf_counter(), time.process_time()
    counts = dict(linear_constructions=0, checkpoint_loads=0,
                  head_guard_calls=0, finalize_calls=0, digest_calls=0,
                  forward_calls=0, backward_calls=0, autograd_grad_calls=0,
                  optimizer_constructions=0, optimizer_steps=0,
                  training_function_calls=0, seed_searches=0)
    result = {"schema": "hepta.head-finalize-zero-training-contract.v1",
              "status": "STARTED", "counts": counts}

    def forbidden(name):
        def fail(*args, **kwargs):
            counts[name] += 1
            raise RuntimeError("forbidden contract operation: " + name)
        return fail

    try:
        registration_path = ROOT / "HEAD_FINALIZE_REGISTRATION.json"
        registration = json.loads(registration_path.read_text())
        result["registration"] = file_identity(registration_path)
        sources = registration["files"]
        for name, identity in sources.items():
            if Path(name).is_absolute() or ".." in Path(name).parts:
                raise ValueError("invalid registered relative source path")
            if file_identity(ROOT / name) != identity:
                raise ValueError("registered source mismatch: " + name)
        result["source_files"] = sources
        import numpy
        import torch
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        runtime = {"python": platform.python_version(), "torch": torch.__version__,
                   "numpy": numpy.__version__, "threads": torch.get_num_threads(),
                   "interop_threads": torch.get_num_interop_threads()}
        if runtime != registration["runtime"]:
            raise ValueError("registered synthetic-contract runtime mismatch")
        result["runtime"] = runtime
        result["executable"] = sys.executable
        result["packages"] = sorted(
            (item.metadata["Name"], item.version)
            for item in importlib.metadata.distributions())
        source = ROOT / "source" / "qa" / "stem-bakeoff"
        sys.path.insert(0, str(source))
        import replacement_physical as physical
        import replacement_head_scale as scale
        for module in (physical, scale):
            if Path(module.__file__).resolve().parent != source.resolve():
                raise ValueError("unexpected imported module origin")

        with mock.patch.object(physical, "train_task_head", forbidden("training_function_calls")), \
             mock.patch.object(torch.autograd, "backward", forbidden("backward_calls")), \
             mock.patch.object(torch.Tensor, "backward", forbidden("backward_calls")), \
             mock.patch.object(torch.autograd, "grad", forbidden("autograd_grad_calls")), \
             mock.patch.object(torch.optim.Optimizer, "__init__", forbidden("optimizer_constructions")):
            torch.manual_seed(7)
            head = torch.nn.Linear(4, 4, device="cpu", dtype=torch.float32)
            counts["linear_constructions"] += 1
            hook = head.register_forward_pre_hook(forbidden("forward_calls"))
            before_parameters = {name: tensor.detach().clone()
                                 for name, tensor in head.named_parameters()}
            before_buffers = {name: tensor.detach().clone()
                              for name, tensor in head.named_buffers()}
            before_digest = physical.tensor_digest(head)
            counts["digest_calls"] += 1
            for index, parameter in enumerate(head.parameters()):
                parameter.grad = torch.full_like(parameter, (index + 1) * 0.25)
            head.eval().requires_grad_(False)

            def expect_guard(expected):
                counts["head_guard_calls"] += 1
                try:
                    scale.measure_trained_head_fanout(head, None)
                except ValueError as error:
                    if str(error) != expected:
                        raise
                    return str(error)
                raise RuntimeError("original guard did not reject None feature")

            result["before_guard_error"] = expect_guard(
                "trained Head must be evaluation-only and frozen")
            head.train().requires_grad_(True)
            returned = physical.finalize_task_head(head)
            counts["finalize_calls"] += 1
            if returned is not head or head.training:
                raise ValueError("finalizer replaced the Head or left training mode")
            if any(p.requires_grad or p.grad is not None for p in head.parameters()):
                raise ValueError("finalizer did not clear the full gradient state")
            result["after_guard_error"] = expect_guard("physical CPU source feature required")
            after_parameters, after_buffers = dict(head.named_parameters()), dict(head.named_buffers())
            if set(before_parameters) != set(after_parameters) or set(before_buffers) != set(after_buffers):
                raise ValueError("finalizer changed parameter or buffer names")
            equal = {
                "parameters": {name: torch.equal(value, after_parameters[name])
                               for name, value in before_parameters.items()},
                "buffers": {name: torch.equal(value, after_buffers[name])
                            for name, value in before_buffers.items()}}
            if not all(all(group.values()) for group in equal.values()):
                raise ValueError("finalizer changed parameter or buffer values")
            after_digest = physical.tensor_digest(head)
            counts["digest_calls"] += 1
            if before_digest != after_digest:
                raise ValueError("complete state_dict digest changed")
            hook.remove()
            result.update(tensor_equal=equal, parameter_tensor_count=len(before_parameters),
                          buffer_tensor_count=len(before_buffers),
                          state_digest_before=before_digest, state_digest_after=after_digest,
                          head_training=head.training, all_parameter_gradients_none=True,
                          all_parameters_require_grad_false=True)
        if counts != registration["exact_counts"]:
            raise ValueError("fixed semantic-operation count mismatch")
        if any(file_identity(ROOT / name) != identity for name, identity in sources.items()):
            raise ValueError("source bytes changed during contract")
        result["status"] = "PASS"
    except BaseException as error:
        result.update(status="FAILED", error=type(error).__name__ + ": " + str(error))
    result.update(wall_s=time.perf_counter() - started_wall,
                  process_cpu_s=time.process_time() - started_cpu,
                  original_five_model_runtime_qualified=False,
                  original_training_replayed=False, production_adoption=False)
    if result["wall_s"] > 30 or result["process_cpu_s"] > 20:
        result.update(status="FAILED", error="fixed 30 wall / 20 CPU second budget exceeded")
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, sort_keys=True, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "result": str(output), "counts": counts}))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
