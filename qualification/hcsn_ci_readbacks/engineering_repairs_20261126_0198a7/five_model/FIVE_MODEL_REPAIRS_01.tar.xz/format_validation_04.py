"""Run the original formatter in a new isolated Arctic source subset."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zlib

ROOT = Path('/Users/qianqi/work/hepta-hcsn-fixes-20261126-0198a7')
SCAFFOLD = {
    'justfile': '74f869224eba12fc4212b043428e7f5b35b551d26f5b06161c25d8aca525f124',
    'scripts/format.py': '8d93d7a6261bbe5f2b9fceea228154f0be29f721015d05b4f538c30076dd80b3',
    'scripts/just-shell.py': '444d6b328d44abf6453b77b6acce2a0c881fc162ff30b20f352c85067797fbe9',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    if len(sys.argv) != 4 or sha(Path(__file__).read_bytes()) != sys.argv[1]:
        raise ValueError('formatter driver identity differs')
    encoded = (ROOT / 'FORMAT_06_INPUTS.json.zlib').read_bytes()
    if sha(encoded) != sys.argv[2]:
        raise ValueError('format transport differs')
    raw = zlib.decompress(encoded)
    if sha(raw) != sys.argv[3]:
        raise ValueError('format input differs')
    plan = json.loads(raw)
    target = ROOT / 'source_arctic_format_06'
    target.mkdir(exist_ok=False)
    receipt = ROOT / 'FORMAT_06.json'
    if receipt.exists():
        raise FileExistsError('format receipt already exists')
    for name, identity in SCAFFOLD.items():
        content = (ROOT / 'source' / name).read_bytes()
        if sha(content) != identity:
            raise ValueError('original formatter scaffold differs')
        path = target / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
    (target / 'codex-rs').mkdir()
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    environment['PATH'] = '/opt/homebrew/bin:' + environment.get('PATH', '')
    def command(argv):
        return subprocess.run(argv, cwd=target, env=environment,
                              capture_output=True, text=True, timeout=90, check=True)
    command(['git', 'init', '-q'])
    command(['git', 'add', '--', *SCAFFOLD])
    command(['git', '-c', 'user.name=workflow-test', '-c', 'user.email=workflow-test@example.invalid',
             'commit', '-q', '-m', 'Pin original formatter scaffold in isolated source subset'])
    for name, item in plan['files'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts:
            raise ValueError('invalid relative source')
        content = item['content'].encode()
        if sha(content) != item['sha256']:
            raise ValueError('source bytes differ')
        path = target / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(content)
    process = command(['/opt/homebrew/bin/just', 'fmt'])
    unchanged = all(sha((target / name).read_bytes()) == item['sha256']
                    for name, item in plan['files'].items())
    result = {'status': 'PASS' if unchanged else 'FAILED', 'exit_code': process.returncode,
              'sources_unchanged': unchanged, 'input_sha256': sha(raw),
              'runner_sha256': sys.argv[1], 'scaffold': SCAFFOLD,
              'files': {name: item['sha256'] for name, item in plan['files'].items()},
              'stdout': process.stdout, 'stderr': process.stderr, 'tests_or_models_run': 0,
              'scope': 'Official just fmt in fresh isolated source subset; qa and qualification have no owning formatter. Not a full repository checkout.'}
    with receipt.open('x') as stream:
        stream.write(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'files': len(plan['files']),
                      'receipt_sha256': sha(receipt.read_bytes())}))
    if not unchanged:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
