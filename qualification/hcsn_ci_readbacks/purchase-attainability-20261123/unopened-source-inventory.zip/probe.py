"""Read only the two pre-existing originals without cached four-quarter receipts."""
import hashlib
import json
from pathlib import Path
import sys
import time
from concurrent.futures import ThreadPoolExecutor

ROOT = Path.cwd()
OUT = ROOT / "lab3/new_source_inventory_20261123"
QUAL = ROOT / "lab3/recordings"
sys.path.insert(0, str(QUAL))
import technical

def check(page):
    raw = next((ROOT / "lab2/commons/media-cache").glob(f"{page}.*"))
    catalog = json.loads((ROOT / "lab2/commons/all_metadata.json").read_text())
    meta = next(row for row in catalog if row["pageid"] == page)
    data = raw.read_bytes()
    sha1 = hashlib.sha1(data).hexdigest()
    assert len(data) == meta["size"] and sha1 == meta["sha1"]
    digest = hashlib.sha256(data).hexdigest()
    del data
    started = time.time()
    result = technical.qualify(raw)
    result.update(pageid=page, source_sha1=sha1, source_sha256=digest,
                  size=raw.stat().st_size, elapsed_seconds=time.time() - started,
                  protocol_sha256=technical.build.digest(QUAL / "plan.json"),
                  implementation=technical.build.digest(QUAL / "technical.py"),
                  frozen_decoder=technical.build.digest(Path(technical.fixed.__file__)))
    (OUT / f"physical_{page}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(page, result["eligible"], len(result["quarters"]), result.get("reason"), flush=True)

if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=2) as workers:
        list(workers.map(check, (66612778, 67928188)))
