"""Inventory published descriptors and original source bytes, without model or feature access."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import unicodedata

OUT = Path(__file__).resolve().parent
LOCAL = Path.cwd()
PRIOR = [Path("trial/qualification/hcsn_intervention_value/media/sources.json"),
         Path("lab3/recordings/sources.json")]
CATALOG = [Path("lab2/commons/all_metadata.json"), Path("lab2/commons/extra_metadata.json")]
QUAL = Path("lab3/recordings")
RAW = [Path("lab2/commons/media-cache"), QUAL / "media-cache"]
DIRECT = {
 9917138: ("publisher_self_release", "Rerumirf's own recording; Saint-Saëns / Steinway XR / roll 5973-4. The prior Chris Strobel / Weber roll is a different production, work and instrument."),
 121725321: ("external_license_review_pending", "Leezy is credited for the cover; Commons lists CC BY 3.0 and flags independent license review as pending."),
 66612778: ("primary_instrument_unresolved", "2010 Yamaha recital, Eri and Mari Yoshizawa; Flickr publisher spontaneity, CC BY 2.0 reviewed by Rodrigolopes in 2019. Publisher credits the pianist as composer; Commons records piano and violin. Neither source designates the primary instrument."),
 67928188: ("synthetic_piano", "Commons' German description explicitly states synthetically generated piano sound. Recording credit turbine1974, Schubert as composer."),
 22010132: ("original_clock_failure", "Tomschryer's own guitar demonstration failed the first chronological quarter."),
 34218111: ("original_clock_failure", "Grimes guitar study supplement S2 failed the second chronological quarter."),
}
GU = {
 174106788:("prior_producer","U.S. Department of State produced a prior Blinken recording. This and page 174106828 cover the same Kerry occasion."),
 174106828:("prior_producer","Same State Department producer and same Kerry occasion as 174106788."),
 138262187:("too_short","11.918 s; the guarded four-quarter protocol cannot fit four complete windows."),
 144376117:("too_short","6.481 s; the guarded four-quarter protocol cannot fit four complete windows."),
 143685534:("sampled_toy","The producer describes a six-button toy playing recorded samples."),
 90638569:("performance_unsubstantiated","The producer describes parts of a classical guitar, including a derivative source. No credited primary performance in the metadata."),
 34218106:("metadata_guitar_lead","Grimes 2014 supplement S1. One common uploader for all Grimes/EEG leads; at most one retained from the group."),
 34218119:("metadata_guitar_lead","Grimes 2014 supplement S3. One common uploader for all Grimes/EEG leads; at most one retained from the group."),
 34218120:("synthetic_demo","Grimes 2014 supplement S4 describes MIDI, a pure tone and simulated string bending."),
 28328874:("metadata_guitar_lead","2013 Müller/Sänger/Lindenberger guitar duet/EEG. Shares the same uploader with Grimes and the other guitar EEG study."),
 37320740:("metadata_guitar_lead","2009 Lindenberger/Li/Gruber/Müller guitar duet/EEG. Shares named research authors with the 2013 EEG study and uploader with Grimes."),
}
PI = {
 23799932:("reconstructed_motion","Publisher describes reconstructed hand-marker data, not a filmed pianist performance."),
 152992954:("primary_instrument_unresolved","WikiOrchestra closing ceremony, mixed ensemble. Source lists multiple bowed strings."),
 201918224:("primary_instrument_unresolved","Violin and piano medley. Original description does not specify the primary instrument."),
 189849157:("physical_performance_unsubstantiated","Metadata credit includes an AI concept design; physical performance and real footage need evidence."),
 50008504:("primary_instrument_unresolved","Workshop activity, one Cantoreanu Vasile production and uploader shared with takes 50008510 and 50008513."),
 50008510:("primary_instrument_unresolved","Same Cantoreanu Vasile workshop/uploader as 50008504 and 50008513."),
 50008513:("primary_instrument_unresolved","Same Cantoreanu Vasile workshop/uploader as 50008504 and 50008510."),
 126248598:("metadata_piano_lead","Latsos piano duo; shares producer and uploader with 133834518."),
 133834518:("metadata_piano_lead","Latsos piano duo, Greystone Mansion in 2023; shares producer and uploader with 126248598."),
 19826559:("metadata_piano_lead","Darren Foreman recorded a vintage player piano at Musée Mécanique."),
 141599859:("metadata_piano_lead","PoseidonSports claims its own piano recording."),
 134436235:("metadata_piano_lead","Сарапулов credits own recording of a pianist in Kyiv."),
 153974356:("physical_performance_unsubstantiated","Luis A Kayser describes photons following the piano; scene and original physical performance need evidence."),
 198865237:("metadata_piano_lead","Credits Ledundead footage of a PAX East piano performance. Opening/closing and all four physical quarters are unverified."),
}

def load(p):
    return json.loads(p.read_text())

def dig(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def hashes(path):
    sha1, sha256 = hashlib.sha1(), hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(2 ** 20):
            sha1.update(block)
            sha256.update(block)
    return sha1.hexdigest(), sha256.hexdigest()

def norm(s):
    return unicodedata.normalize("NFKC", s).replace("_", " ").strip().casefold()

def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")

def main():
    lists = [load(p) for p in PRIOR]
    used = {r["pageid"]: r for roster in lists for r in roster}
    assert len(used) == sum(map(len, lists)) == 44
    uploaders = {norm(r["uploader"]) for r in used.values()}
    old_sha1 = {r["sha1"] for r in used.values()}
    metadata = {r["pageid"]:r for p in CATALOG for r in load(p)}
    new_meta = {int(p.stem):load(p) for p in (QUAL / "metadata").glob("*.json")}
    metadata.update(new_meta)
    assert set(used) <= metadata.keys()
    originals = {}
    for cache in RAW:
        for file in sorted(cache.iterdir()):
            if not file.is_file() or file.suffix not in {".ogv",".webm"}:
                continue
            i = int(file.stem)
            assert i not in originals
            sha1, sha256 = hashes(file)
            assert metadata[i]["size"] == file.stat().st_size and sha1 == metadata[i]["sha1"]
            originals[i] = dict(path=str(file), size=file.stat().st_size, sha1=sha1, sha256=sha256)
    assert set(used) <= originals.keys()
    used_details = [dict(pageid=i,title=r["title"],instrument=r["instrument"],producer=r["producer"],
                        uploader=r["uploader"],sha1=r["sha1"],group=r["group"],
                        permanent=r["page_permanent"]) for i,r in sorted(used.items())]
    save("historical_exclusions.json",used_details)
    save("verified_local_originals.json",originals)
    rows = []
    for i,r in sorted(metadata.items()):
        if i in used: continue
        m = r["metadata"]
        same_account = norm(r["uploader"]) in uploaders
        status, rationale = ("metadata_only", "Original bytes and producer adjudication outstanding.")
        if same_account:
            status, rationale = "prior_uploader","Both preceding rosters are exclusion lists for this study."
        elif i in DIRECT: status, rationale = DIRECT[i]
        elif i in GU: status, rationale = GU[i]
        elif i in PI: status, rationale = PI[i]
        if r["sha1"] in old_sha1:
            status, rationale = "prior_master", "Published original file checksum already present in exclusion set."
        row = dict(pageid=i,instrument=r["instrument"],title=r["title"],uploader=r["uploader"],
                   artist=m.get("Artist"),credit=m.get("Credit"),page=r["page"],
                   permanent=f"https://commons.wikimedia.org/w/index.php?oldid={r['page_revision']}",
                   original_url=r["url"],published_sha1=r["sha1"],published_size=r["size"],
                   license=m.get("LicenseShortName"),license_url=m.get("LicenseUrl"),
                   published_duration_seconds=r.get("duration"),in_lab3_metadata=i in new_meta,
                   published_sha_in_old=bool(r["sha1"] in old_sha1),prior_uploader=same_account,
                   raw_present=i in originals,status=status,reason=rationale)
        if i in originals:
            physical = QUAL / "technical" / f"{i}.json"
            if not physical.is_file(): physical=OUT / f"physical_{i}.json"
            proof=load(physical)
            assert proof["source_sha1"]==originals[i]["sha1"] and proof["source_sha256"]==originals[i]["sha256"]
            assert proof["protocol_sha256"]==dig(QUAL/"plan.json")
            assert proof["implementation"]==dig(QUAL/"technical.py")
            row.update(physical_receipt=physical.name,physical_sha256=dig(physical),eligible_four_quarters=proof["eligible"],source_sha256=originals[i]["sha256"],
                       starts=[q["start_seconds"] for q in proof["quarters"]],first_failed_quarter=proof.get("first_failed_quarter"),
                       rejection_counts=proof["rejections"])
            if physical.parent!=OUT:(OUT / f"original_receipt_{i}.json").write_bytes(physical.read_bytes())
        rows.append(row)
    save("unused_works.json",rows)
    counts=Counter(x["instrument"] for x in rows)
    extra=[x for x in rows if x["raw_present"]]
    summary={
      "prior_rosters":[{"path":str(p),"sha256":dig(p),"works":len(rr),
                        "distinct_uploader_accounts":len({norm(r["uploader"]) for r in rr}),
                        "credited_groups":len({r["group"] for r in rr})} for p,rr in zip(PRIOR,lists)],
      "public_attribution_limit":"Paper credits and account/group overlap; closed-world documentary comparison, no performer identity inference.",
      "union_metadata_pages":len(metadata),"union_prior_works":len(used),"union_excluded_uploader_accounts":len(uploaders),
      "lab3_pages":len(new_meta),"lab3_unused":dict(Counter(r["instrument"] for i,r in new_meta.items() if i not in used)),
      "union_unused":dict(counts),"never_cached_unused_pages":len(rows)-len(extra),
      "matched_prior_master_sha1_count":sum(r["published_sha_in_old"] for r in rows),
      "matched_prior_uploader_counts":dict(Counter(r["instrument"] for r in rows if r["prior_uploader"])),
      "originals_verified_count":len(originals),"originals_verified_bytes":sum(r["size"] for r in originals.values()),
      "by_cache":{str(p):{"files":sum(Path(row["path"]).parent==p for row in originals.values()),
                          "bytes":sum(row["size"] for row in originals.values() if Path(row["path"]).parent==p)} for p in RAW},
      "unused_actual_files":dict(Counter(r["instrument"] for r in extra)),
      "unused_actual_bytes":{k:sum(x["published_size"] for x in extra if x["instrument"]==k) for k in counts},
      "unused_four_quarter_pass":dict(Counter(r["instrument"] for r in extra if r["eligible_four_quarters"])),
      "eligible_known_upstream_rights_piano_guitar":[1,0],"corresponding_deficit":[5,6],
      "eligible_if_project_accepts_publisher_disclosed_review_pending_piano_guitar":[2,0],"corresponding_deficit_for_project_rule":[4,6],
      "guitar_rows_with_new_uploader":sum(r["instrument"]=="guitar" and not r["prior_uploader"] for r in rows),
      "distinct_new_guitar_uploaders":len({norm(r["uploader"]) for r in rows if r["instrument"]=="guitar" and not r["prior_uploader"]}),
      "guitar_optimistic_total_uploader_groups_in_105_where_something_remains_to_check":2,
      "registered_plan_sha256":dig(QUAL/"plan.json"),"technical_code_sha256":dig(QUAL/"technical.py"),
      "price":0.30,"duration_seconds_per_window":2.88,"quarters_needed_per_source":4,
      "new_original_downloads":0,"new_model_evaluations":0}
    assert summary["eligible_known_upstream_rights_piano_guitar"]==[sum(x["status"]=="publisher_self_release" and x["eligible_four_quarters"] for x in extra),0]
    assert sum(x["published_size"] for x in extra)==215549142
    save("inventory_summary.json",summary)
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()
