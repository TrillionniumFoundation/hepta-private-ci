"""Verify the changed boundary against the pinned full Rust inventory in a clean Git checkout."""
import argparse
from hashlib import sha1
import json
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('checkout', type=Path)
args = parser.parse_args()
root = args.checkout.resolve()
head = subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
assert head in ('813d3d32ced3147ec012fd363d6d7cec1db21bf8','78be5a8d71a6993a8ffad275fac5fbbf59d42e26'), head
sys.path.insert(0,str(root/'scripts'))
import verify_hepta_callers as proof

manifest = proof._load_manifest(root/'CALLERS.toml')
files = proof._source_files(root,proof._string_tuple(manifest,'source_roots'))
paths = {path.relative_to(root).as_posix():path for path in files}
expected = {}
listing = subprocess.check_output(['git','-C',str(root),'ls-tree','-rz',head,'--','codex-rs'])
for item in listing.split(b'\0'):
    if not item: continue
    meta,name = item.split(b'\t',1)
    if name.endswith(b'.rs'):
        mode,kind,oid = meta.split();assert kind == b'blob' and mode != b'120000'
        expected[name.decode()] = oid.decode()
assert set(paths) == set(expected) and len(paths)==9141
index={}
for relative,path in paths.items():
    raw=path.read_bytes();oid=sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert oid==expected[relative],relative
    index[relative]=proof._strip_cfg_test_items(proof._strip_rust_non_code(raw.decode()))
rows=proof._boundary_rows(manifest)
privileged=proof._verify_privileged_inventory(manifest,rows)
boundary=next(row for row in rows if row.identifier=='learning_original_evaluation_panel_member_current')
checked=proof._verify_boundary(root,boundary,index,proof._string_tuple(manifest,'ignored_path_fragments'))
assert checked['productCallers']==['codex-rs/hepta-agentd/src/neuron_cell_evaluation_panel.rs']
print(json.dumps({'head':head,'rust_files_verified':len(index),'declared_privileged_ids':len(privileged),'boundary':checked},indent=2))
