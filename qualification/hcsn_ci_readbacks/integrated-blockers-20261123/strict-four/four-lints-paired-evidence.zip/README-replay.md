# Four isolated Agentd Clippy diagnostics

The product branch is `fix/agentd-four-isolated-lints-20261123`. The original baseline is `59e2fdbe06161833a7883ccf166b2fcb3d197e72`. The final candidate, including all three source-closure guards, is `78be5a8d71a6993a8ffad275fac5fbbf59d42e26`. The native pair tested `813d3d32ced3147ec012fd363d6d7cec1db21bf8`. Both candidate commits have the same `codex-rs` tree `e28c709047b81709dff897948f82f2a00a0355b5`; `source-identity.json` binds the only follow-up change, a Python source-closure test.

The original strict command returned 101 on both sources. Its true diagnostic count fell from 128 to 124. Exactly the four submitted diagnostics disappeared and zero new diagnostics occurred. The residual counts are 71 `too_many_arguments`, 40 `large_enum_variant` and 13 `dead_code`. The two different Linux musl ELFs each passed all 51 named owner tests. On each source all 826 protected records and 42 targeted source-closure test cases passed. `verified.json` records recomputed counts and checksums. `SHA256SUMS` covers every evidence file in this ZIP except itself.

## Reproduce the raw-log comparison

```bash
python3 verify_evidence.py strict.zip native.zip --cases native_cases.json
```

This reconstructs all posted diagnostic and per-case results, verifies two different ELF identities, and confirms the ten native fixture-file Git IDs on both sources. The workflow at commit `2036ecff73b26fd3ff313f9da10f1b7392486703` records the pinned runner, original Cargo and Bazel commands and every test name. Its job outcomes describe the comparison. The actual exit status of each unmodified strict command is stored separately inside `strict.zip`. The narrow native suite uses all 51 named originals and one test thread per ELF.

- [Paired original strict and native jobs](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45127907565)
- [Frozen diagnostic source](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/2036ecff73b26fd3ff313f9da10f1b7392486703/.github)
- [Rejected first native/strict pair](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/45126913057)

## Replay source guards from two clean worktrees

Use Bash, Python 3.11+ and a repository checkout containing the three source commits. Run from the directory containing these evidence files. `$REPO` points to the repository.

```bash
work=$(mktemp -d)
git -C "$REPO" worktree add --detach "$work/base" 59e2fdbe06161833a7883ccf166b2fcb3d197e72
git -C "$REPO" worktree add --detach "$work/final" 78be5a8d71a6993a8ffad275fac5fbbf59d42e26
python3 check_sources.py "$work/base" "$work/final"
python3 test_data_guard.py "$work/base"
python3 test_data_guard.py "$work/final"
python3 check_bound_checkout.py "$work/final"
```

The source replay checks all 826 protected records on both sources, both directions of old/new rejection, all ordered source statements across the five modified Rust files, eight call sites and the four possible bootstrap origin/action combinations. The two affected stateful suites contain 16 cases per tree. Three additional original suites contain 26 per tree. The last command verifies all 9,141 Rust source hashes against Git and runs the one definition-marker boundary whose indentation changed across that complete inventory. The other 1,651 boundary declarations and the registered callers did not change. `boundary_result.json` is the equivalent measured full-roster scan performed on the content-addressed local mirror.

The submitted patch adds a documentation paragraph boundary, passes the private decoder's fixed eight-byte magic by value, unifies two equal pure predicates, and releases a seven-borrow qualification context with a lexical block. The temporary qualification `Vec<u8>` is released before subsequent fresh reads. All actual input reads, authority checks, time checks, awaits, and error-return order surrounding that block are preserved.

The rejected initial candidate `45993a8e72bff68dfcee78cb797ca20731c34576` omitted two callers in the historical data child module. Both original compiler modes produced the same two E0308 errors there. The original data source guard then rejected the corrected by-value literal syntax. The final source guard binds request and result literals to their respective byte buffers at real code spans, with wrong-buffer and missing-dereference negative controls. Both rejected compiler archives and the source-guard rejection are retained.
