"""Independently recompute the original compiler and libtest results from the two Action ZIPs."""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile

p=argparse.ArgumentParser();p.add_argument('strict_zip',type=Path);p.add_argument('native_zip',type=Path);p.add_argument('--cases',type=Path,required=True);p.add_argument('--output',type=Path);args=p.parse_args()
refs={'base':'59e2fdbe06161833a7883ccf166b2fcb3d197e72','candidate':'813d3d32ced3147ec012fd363d6d7cec1db21bf8'}
cases=json.loads(args.cases.read_text());names=set(n for group in cases.values() for n in group);assert len(names)==sum(map(len,cases.values()))==51
summary={'sources':refs,'archives':{},'strict':{},'native':{}}
with ZipFile(args.strict_zip) as strict, ZipFile(args.native_zip) as native:
    for key,path,z in [('native',args.native_zip,native),('strict',args.strict_zip,strict)]:
        assert z.testzip() is None
        summary['archives'][key]={'file_bytes':path.stat().st_size,'sha256':sha256(path.read_bytes()).hexdigest()}
        fixture=None
        for arm,ref in refs.items():
            assert z.read('identity-'+arm+'.txt').decode().strip()==ref
            f=z.read('fixtures-'+arm+'.txt');assert len(f.splitlines())==len(cases);assert fixture is None or f==fixture;fixture=f
        summary['archives'][key]['fixture_roster_sha256']=sha256(fixture).hexdigest();summary['archives'][key]['fixture_files']=len(cases)
    stored=json.loads(strict.read('strict.json'));counters={}
    for arm in refs:
        data=strict.read('strict-'+arm+'.log').decode(); exitcode=int(strict.read('strict-'+arm+'.exit')); assert exitcode==stored['original_exit_codes'][arm]!=0
        locations=Counter();pending=None
        for line in data.splitlines():
            if line.startswith('error: '):
                assert pending is None,pending
                title=line.removeprefix('error: ')
                if not title.startswith('could not compile'): pending=title
            elif pending is not None:
                loc=re.fullmatch(r'\s*--> ([^:]+):\d+:\d+\s*',line)
                if loc: locations[(loc[1],pending)]+=1;pending=None
        assert pending is None;assert sum(locations.values())==stored[arm+'_diagnostics'];counters[arm]=locations
        summary['strict'][arm]={'status':exitcode,'diagnostics':sum(locations.values())}
    delta=counters['base']-counters['candidate'];assert not (counters['candidate']-counters['base']) and sum(delta.values())==4
    expected={'cell_split_owner.rs':'doc list item without indentation','circuit_task_source_codec.rs':'this argument (8 byte) is passed by reference','cell_q24_training_bootstrap_service.rs':'this `if` has identical blocks','neuron_cell_evaluation_panel_member.rs':'call to `std::mem::drop` with a value that does not implement `Drop`'}
    for file,prefix in expected.items():assert sum(v for (path,msg),v in delta.items() if path=='hepta-agentd/src/'+file and msg.startswith(prefix))==1
    summary['strict']['removed']=[list(row)for row in sorted(delta.elements())];assert stored['removed']==summary['strict']['removed'] and stored['added']==[]
    cert=json.loads(native.read('native.json'));bins=[]
    for arm in refs:
        data=native.read('native-'+arm+'.log');out=data.decode(); results=re.findall(r'^test ([^ ]+) \.\.\. (ok|FAILED|ignored)\s*$',out,re.M);assert len(results)==len(names) and set(n for n,v in results)==names and {v for _,v in results}=={'ok'}
        assert re.search(r'^test result: ok\. 51 passed; 0 failed; 0 ignored;',out,re.M)
        assert cert[arm]['cases']==dict(results) and cert[arm]['code']==0 and cert[arm]['sha256']==sha256(data).hexdigest();binary=native.read('binary-'+arm+'.txt').decode().split()[0];assert re.fullmatch('[0-9a-f]{64}',binary);bins.append(binary)
        summary['native'][arm]={'ok':len(results),'elf_sha256':binary,'log_sha256':sha256(data).hexdigest()}
    assert len(set(bins))==2
result=json.dumps(summary,indent=2)+'\n';print(result,end='')
if args.output:args.output.write_text(result)
