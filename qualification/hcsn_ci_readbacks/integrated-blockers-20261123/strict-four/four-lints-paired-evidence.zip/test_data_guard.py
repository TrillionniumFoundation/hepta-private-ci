from pathlib import Path
import importlib.util,sys,unittest
p=Path(sys.argv[1]).resolve();qa=p/'qa/b4-no-bypass';sys.path.insert(0,str(qa));modules=['test_original_task_data_source_closure','test_successor_historical_client_source_closure','test_root_publication_existing_owner_source_closure'];tests=unittest.TestSuite()
for name in modules:
    spec=importlib.util.spec_from_file_location(name,qa/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=p
    if hasattr(m,'route'):m.route.ROOT=p
    tests.addTests(unittest.defaultTestLoader.loadTestsFromModule(m))
r=unittest.TextTestRunner(verbosity=1).run(tests);sys.exit(not r.wasSuccessful())
