"""Check the whole affected source transformations and the two original closure suites."""
from argparse import ArgumentParser
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import tempfile
import unittest

parser=ArgumentParser()
parser.add_argument('baseline',type=Path)
parser.add_argument('candidate',type=Path)
parser.add_argument('--output',type=Path)
a=parser.parse_args()
roots=[p.resolve() for p in (a.baseline,a.candidate)]
agent='codex-rs/hepta-agentd/src/'
qa='qa/b4-no-bypass/'
sys.path.insert(0,str(roots[1]/'scripts'))
import verify_hepta_callers as proof

def source(name):
    return [((p/agent)/name).read_text() for p in roots]

def replace_once(text,needle,new):
    assert text.count(needle)==1,needle
    return text.replace(needle,new)

def whole_source(name):
    b,c=source(name)
    return {'path':agent+name,'sha256':[hashlib.sha256(t.encode()).hexdigest() for t in (b,c)]}

files=['cell_split_owner.rs','circuit_task_source_codec.rs','cell_q24_training_bootstrap_service.rs','neuron_cell_evaluation_panel_member.rs']
b,c=source(files[0]);assert replace_once(b,'/// The executor never manufactures','///\n/// The executor never manufactures')==c
b,c=source(files[1]);calls=re.findall(r'Reader::new\(bytes, b"([A-Z0-9]+)"\)',b);assert len(calls)==6 and all(len(n.encode())==8 for n in calls)
expected=replace_once(b,'magic: &[u8; 8]','magic: [u8; 8]');expected=replace_once(expected,'bytes.strip_prefix(magic)','bytes.strip_prefix(&magic)');assert expected.replace('Reader::new(bytes, b"','Reader::new(bytes, *b"')==c
b,c=source(files[2]);left='let result = if '; right='let _permit = self.bootstrap_lane'; bf=b[b.index(left):b.index(right)];cf=c[c.index(left):c.index(right)];assert replace_once(b,bf,cf)==c
ws=lambda s: re.sub(r'\s+','',s)
assert ws(bf)==ws('''let result = if matches!(self.origin, Origin::Recovered) && request.action == wire::Action::Execute { wire::CommandResult::ReadbackRequired } else if matches!(self.origin, Origin::Fresh) && request.action == wire::Action::Readback { wire::CommandResult::ReadbackRequired } else {''')
assert ws(cf)==ws('''let result = if (matches!(self.origin, Origin::Recovered) && request.action == wire::Action::Execute) || (matches!(self.origin, Origin::Fresh) && request.action == wire::Action::Readback) { wire::CommandResult::ReadbackRequired } else {''')

def variants(name,what):
    pair=source(name);assert pair[0]==pair[1];m=re.search(r'enum '+what+r'\s*\{([^}]+)\}',pair[0]);return [s.strip() for s in m[1].split(',') if s.strip()]
origins=variants('cell_q24_training_bootstrap.rs','Origin');actions=variants('cell_q24_training_command_wire.rs','Action');assert origins==['Fresh','Recovered'] and actions==['Execute','Readback'];truth=[]
for origin in origins:
    for action in actions:
        first=origin=='Recovered' and action=='Execute';second=origin=='Fresh' and action=='Readback'
        before='ReadbackRequired' if first else 'ReadbackRequired' if second else 'original else block'
        after='ReadbackRequired' if first or second else 'original else block';assert before==after
        truth.append([origin,action,after])
b,c=source(files[3]); start=b.index('        let mut sources =');end=b.index('        drop(sources);',start);old=b[start:end].rstrip();new=('        let (prepared, qualification) = {\n'+'\n'.join('    '+line for line in old.splitlines())+'\n            (prepared, qualification)\n        };');assert replace_once(b,b[start:end]+'        drop(sources);',new)==c
data_file='circuit_task_source_data.rs'
b,c=source(data_file); pairs=[('request_bytes','HCSTREQ1'),('result_bytes','HCSTRES1')];assert b.count('Reader::new(')==len(pairs)
for var,header in pairs:
    needle=f'Reader::new(&{var}, b"{header}")';b=replace_once(b,needle,needle.replace(', b"',', *b"'));calls.append(header)
assert b==c
for root in roots:
    base=root/agent
    assert '#[path = "circuit_task_source_data.rs"]\nmod data;' in (base/files[1]).read_text()
    assert '#[path = "circuit_task_source_data_decision.rs"]\nmod decision;' in (base/data_file).read_text()
    assert 'Reader::new(' not in (base/'circuit_task_source_data_decision.rs').read_text()
    assert 'struct Reader<' in (base/'circuit_task_source_policy.rs').read_text()
mb,mc=[proof._load_manifest(root/'CALLERS.toml') for root in roots];assert not any(mc['authority'].values());assert mb['authority']==mc['authority'];assert mb['privileged_inventory']==mc['privileged_inventory']
bd,cd=mb['boundary'],mc['boundary'];assert len(bd)==len(cd)==1652
changed=[(x,y) for x,y in zip(bd,cd,strict=True) if x!=y];assert len(changed)==1
x,y=changed[0];assert x['id']==y['id']=='learning_original_evaluation_panel_member_current';assert {k:v for k,v in x.items() if k!='definition_markers'}=={k:v for k,v in y.items() if k!='definition_markers'};assert [ws(t) for t in x['definition_markers']]==[ws(t) for t in y['definition_markers']]
pb,pc=mb['protected_file'],mc['protected_file'];assert len(pb)==len(pc)==826;delta=[(x,y) for x,y in zip(pb,pc,strict=True) if x!=y];assert [x['path'] for x,y in delta]==[agent+n for n in files[2:]] or set(x['path'] for x,y in delta)==set(agent+n for n in files[2:]);controls=[]
for x,y in delta:
    assert x['path']==y['path'];assert {k:v for k,v in x.items() if k!='required_function_order'}=={k:v for k,v in y.items() if k!='required_function_order'}
    for name,root,row in [('old_on_new',roots[1],x),('new_on_old',roots[0],y)]:
        try: proof._verify_protected_files(root,{'protected_file':[row]})
        except proof.VerificationFailure as exc: controls.append({'path':x['path'],'arm':name,'error':str(exc)[:160]})
        else: raise AssertionError((x['path'],name))
rows={}
for arm,root,manifest in zip(('base','candidate'),roots,(mb,mc)):
    checked=proof._verify_protected_files(root,manifest);assert len(checked)==len(set(checked))==826
    suite={};folder=root/qa;sys.path.insert(0,str(folder))
    for i,name in enumerate(('test_original_training_bootstrap_source_closure','test_original_evaluation_panel_source_closure')):
        spec=importlib.util.spec_from_file_location(f'{arm}_{name}',folder/(name+'.py'));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        # The local overlay may link unchanged files, so explicitly use the input root.
        mod.ROOT=root
        classes=[v for v in vars(mod).values() if isinstance(v,type) and issubclass(v,unittest.TestCase) and v is not unittest.TestCase];assert len(classes)==1
        cls=classes[0];original=cls.rejects;mutations=[]
        def counted(self,*args,**kwargs):
            original(self,*args,**kwargs);mutations.append(list(args))
        cls.rejects=counted
        tests=unittest.defaultTestLoader.loadTestsFromTestCase(cls);out=unittest.TestResult();tests.run(out);assert out.wasSuccessful(),[out.errors,out.failures]
        suite[name]={'test_cases':out.testsRun,'function_mutations_rejected':len(mutations)}
    rows[arm]={'protected_files':len(checked),'suites':suite}
result={'files':[whole_source(n) for n in [*files,data_file]],'codec_headers':dict(collections.Counter(calls)),'bootstrap_table':truth,'panel_observation':'Seven borrowed dependencies retained. The temporary Vec<u8> for qualification bytes is released at lexical block exit before the next currentness read. The verified source inputs, calls, awaits and fallible branches remain in identical order.','boundaries':len(bd),'changed_definition_marker':changed[0][0]['id'],'changed_protected_rows':[x['path'] for x,y in delta],'cross_version_rejections':controls,'tests':rows}
encoded=json.dumps(result,indent=2,ensure_ascii=False)+'\n';print(encoded)
if a.output: a.output.write_text(encoded)
