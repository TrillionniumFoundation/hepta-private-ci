"""Read-only audit of exact published source bytes, workflow runs, and first failed guards."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import tomllib

root = Path(__file__).resolve().parent
read = lambda p: json.loads((root / p).read_text())
def digest(value): return hashlib.sha256(value).hexdigest()
def _pin_inventory(body):
    return ast.literal_eval(re.search(r"^          PINS = (\{[\s\S]*?^          \})", body, re.M)[1])
def source(tag, ref, objects):
    data = (root / (tag+'.workflow')).read_bytes()
    body = data.decode()
    methods = {name:len(ast.literal_eval(rhs)) for name,rhs in re.findall(r"^\s*(\w+_METHODS) = (\[.*?\])",body,re.M)}
    expected = re.search(r'OTHER_LOCK_TOML_SHA256 = "([0-9a-f]+)"',body)[1]
    lock = (root / (tag+'.lock')).read_bytes()
    model = tomllib.loads(lock.decode())
    package = model['package']
    # Execute the exact registered section in isolation using the real immutable lock.
    original = body[body.index('                      parsed = tomllib.loads'):body.index('              # The workflow cannot contain')]
    first = body.split('          ANYHOW_RECORD = ',1)[1].split('\n          }',1)[0]+'}'
    observed = {}
    def require(value, reason):
        observed[reason] = bool(value)
    import textwrap
    ns = dict(data=lock,tomllib=tomllib,json=json,hashlib=hashlib,
              ANYHOW_RECORD=ast.literal_eval(first),require=require,OTHER_LOCK_TOML_SHA256=expected)
    exec(compile(textwrap.dedent(original),'<immutable-review-lock-section>','exec'),ns)
    snapshot = ns['canonical']
    if isinstance(snapshot,str): snapshot = snapshot.encode()
    pins=_pin_inventory(body)
    diff = {p:[pins[p]['oid'],rec['oid']] for p,rec in objects.get(tag,{}).items() if pins[p]['oid']!=rec['oid']}
    return dict(tag=tag,ref=ref,workflow_sha256=digest(data),workflow_bytes=len(data),bound_sources=len(pins),bound_method_counts=methods,
                lock_bytes_sha256=digest(lock),total_packages=len(package),
                normalized_expected=expected, normalized_observed=digest(snapshot),actual_raw_lock_checks=observed,
                git_blob_mismatches=diff)
allruns = read('recent.json')
jobs = read('all_jobs.json')
release_index = next(i for i,r in enumerate(allruns) if r['head_sha'].startswith('0cee57ca'))
post = allruns[:release_index+1]
a=source('original',post[-1]['head_sha'],read('objects.json'))
b=source('combined',post[0]['head_sha'],read('objects.json'))
assert a['workflow_sha256']==b['workflow_sha256']
assert set(a['git_blob_mismatches'])=={'codex-rs/Cargo.toml'} and len(b['git_blob_mismatches'])==4
assert a['normalized_expected']==b['normalized_expected'] and a['normalized_observed']!=a['normalized_expected'] and b['normalized_observed']!=b['normalized_expected']
assert all(r['conclusion']=='failure' for r in post)
counts=Counter((job[1],job[2]) for r in post for job in jobs[str(r['id'])])
last = next(r for r in allruns if r['conclusion']=='success')
old_body=(root/'green.workflow').read_bytes()
old_methods={name:len(ast.literal_eval(rhs)) for name,rhs in re.findall(r"^\s*(\w+_METHODS) = (\[.*?\])",old_body.decode(),re.M)}
result=dict(workflow='.github/workflows/ndu-windows-storage-probe.yml',cutoff=post[0]['created_at'],history_count=len(allruns),
            history_conclusions=dict(Counter(r['conclusion'] for r in allruns)),since_release=len(post),since_release_jobs={'/'.join(k):v for k,v in counts.items()},
            addresses={c['tag']:c for c in (a,b)},latest_previous_complete_success=dict(ref=last['head_sha'],run=last['id'],jobs={x[1]:x[2] for x in jobs[str(last['id'])]},workflow_sha256=digest(old_body),reviewed_sources=len(_pin_inventory(old_body.decode())),registered_methods=old_methods),
            actual_logs=read('job_log_signatures.json'),
            scope='All returned workflow-history entries, all jobs in every run from publication inclusive, latest prior success, and real published lock-guard blocks and source Git blob identities. No Windows run, qualification, or change performed.')
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(len(allruns),len(post),counts,a['normalized_observed'],b['normalized_observed'],result['latest_previous_complete_success'])
