"""Retrospective causal controls for the frozen conditional edit, without optimization."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import time

import numpy as np
import torch

root = Path(__file__).resolve().parent
source = root / "qualification/hcsn_ci_readbacks/qvi-conditional-edit-20261123/compare.py"
out = root / "replay_20261124/ablation_attempt002"
out.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location("frozen_compare", source)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
observed = json.loads((out.parent / "results.json").read_text())
d = np.array([observed["arms"]["structural"][k] for k in ("cost_delta", "offset_delta")])
b = np.array([observed["arms"]["BP"][k] for k in ("cost_delta", "offset_delta")])
unit = np.random.default_rng(20261124).normal(size=2)
unit /= np.linalg.norm(unit)
arms = {"KEEP": np.zeros(2), "DIRECT": d, "BP": b, "COST_ONLY": d*[1,0],
        "BIAS_ONLY": d*[0,1], "HALF": .5*d, "REVERSED": -d, "MATCHED_NORM_RANDOM": np.linalg.norm(d)*unit}
points = sorted(set(np.linspace(.56, 1.4, 17).tolist() + [.72, .65, .79, 1.05]))
protocol = dict(schema="hepta-qvi-conditional-edit-causal-controls-v1", relation="Post hoc diagnosis, not a new held-out generalization experiment",
                parent_result_sha256=hashlib.sha256((out.parent/"results.json").read_bytes()).hexdigest(),
                source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(), edited_coordinates=["A.spike_cost", "B.offset"],
                arms={k:v.tolist() for k,v in arms.items()}, initial_grid=points, original_anchor=.72,
                anchor_tolerance=1e-7, boundary_tolerance=1e-7, evaluate_all_49_receiver_features=True,
                training_calls=0, candidate_selection=False, random_seed=20261124,
                global_retention_check="For x->infinity all finite-horizon source hit probabilities vanish; receiver input shift tends to dc+DIRECT*(new_b-old_b).")
(out/"protocol.json").write_text(json.dumps(protocol,indent=2,allow_nan=False)+"\n")
started = time.perf_counter()
with torch.no_grad():
    old = m.tensor([m.setup.A[-1], m.setup.OFFSET]); old_theta = m.theta(old[0]); old_b=m.optimal_boundary(old_theta)
    second=m.tensor(m.setup.B); receiver_boundary=m.optimal_boundary(second)
    baseline={}
    for x in points:
        y=m.receiver_start(old_b,old_theta,x,old[1])
        baseline[x]=(y,m.receiver_features(y,second,receiver_boundary))
    rows={}
    for label,delta in arms.items():
        chosen=old+m.tensor(delta); theta=m.theta(chosen[0]); boundary=m.optimal_boundary(theta)
        panels=[]
        for x in points:
            y=m.receiver_start(boundary,theta,x,chosen[1]); values=m.receiver_features(y,second,receiver_boundary)
            y0,v0=baseline[x]
            panels.append(dict(initial=x,receiver_start_delta=float(y-y0),max_feature_change=float((values-v0).abs().max()),
                               receiver_features=values.tolist()))
        anchor=next(p for p in panels if p["initial"]==.72)
        err=abs(float(boundary)-observed["arms"]["structural"]["target"])
        rows[label]=dict(delta=delta.tolist(),boundary=float(boundary),boundary_error=err,
                        anchor_max_feature_change=anchor["max_feature_change"],grid_max_feature_change=max(p["max_feature_change"] for p in panels),
                        x_infinity_receiver_input_delta=float(chosen[1]-old[1]+m.setup.DIRECT*(boundary-old_b)),
                        original_gates_pass=bool(err<=1e-7 and anchor["max_feature_change"]<=1e-7 and np.abs(delta).max()<=.10),
                        every_grid_point_retained=all(p["max_feature_change"]<=1e-7 for p in panels),panels=panels)
    receipt=dict(arms=rows,points=len(points),features_per_point=49,torch=str(torch.__version__),
                 threads=torch.get_num_threads(),wall_seconds=time.perf_counter()-started,optimizer_calls=0,
                 parent_candidate_unchanged=True,scope=protocol["relation"])
    (out/"results.json").write_text(json.dumps(receipt,indent=2,allow_nan=False)+"\n")
    print(json.dumps({"points":len(points),"wall_seconds":receipt["wall_seconds"],"arms":{k:{f:v[f] for f in
        ("delta","boundary_error","anchor_max_feature_change","grid_max_feature_change","x_infinity_receiver_input_delta","original_gates_pass","every_grid_point_retained")} for k,v in rows.items()}},indent=2))
