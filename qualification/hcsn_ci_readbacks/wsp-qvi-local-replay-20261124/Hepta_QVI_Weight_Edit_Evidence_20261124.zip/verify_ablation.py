"""Independent scalar boundary, source signal and receiver phase checks; no Torch import."""
import json
from pathlib import Path
import numpy as np
from qualification.hcsn_halfline_transport import verify_qvi_finite_bridge as f

root=Path(__file__).resolve().parent
folder=root/"replay_20261124/ablation_attempt002"
data=json.loads((folder/"results.json").read_text())
errors=dict(boundary=0.,receiver_start_delta=0.,receiver_terminal_phase=0.,asymptotic_input_delta=0.)
base_b=f.scalar_boundary(f.A)
def start(params,initial,offset):
    s=f.scalar_neuron(params,initial,f.HORIZONS[0],f.MARKS[0],f.RESET_MAPS[0])
    return offset+f.DIRECT*s["boundary"]+f.SIGNED*float(np.dot(f.PROJECTION,s["marked_hits"]))
count=0
for name,row in data["arms"].items():
    dk,dc=row["delta"];params=(*f.A[:-1],f.A[-1]+dk)
    b=f.scalar_boundary(params)
    errors["boundary"]=max(errors["boundary"],abs(b-row["boundary"]))
    errors["asymptotic_input_delta"]=max(errors["asymptotic_input_delta"],abs(dc+f.DIRECT*(b-base_b)-row["x_infinity_receiver_input_delta"]))
    for p in row["panels"]:
        initial=p["initial"]
        y=start(params,initial,f.OFFSET+dc);old=start(f.A,initial,f.OFFSET)
        errors["receiver_start_delta"]=max(errors["receiver_start_delta"],abs((y-old)-p["receiver_start_delta"]))
        receiver=f.scalar_neuron(f.B,y,f.HORIZONS[1],f.MARKS[1],f.RESET_MAPS[1])
        recorded_phase=sum(p["receiver_features"][len(f.EDGES):len(f.EDGES)+len(f.FRACTIONS)-1])
        errors["receiver_terminal_phase"]=max(errors["receiver_terminal_phase"],abs(receiver["terminal_phase"]-recorded_phase))
        count+=1
assert max(errors.values())<3e-13, errors
report=dict(verified=True,arms=len(data["arms"]),forward_panels=count,maximum_errors=errors,
            full_49_feature_claim="All 49 arrays are source outputs; this independent path validates boundaries, all start displacements and the receiver terminal-phase aggregate.")
(folder/"independent.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
