"""One new CPU replay of the frozen 2026-11-23 conditional edit experiment."""
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
source = root / "qualification/hcsn_ci_readbacks/qvi-conditional-edit-20261123"
out = root / "replay_20261124"
out.mkdir(exist_ok=False)
env = dict(os.environ, PYTHONPATH=f"{root / 'torch_deps'}:{root}", OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
files = sorted((root / "qualification").rglob("*.py")) + [source / "protocol.json"]
manifest = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
freeze = dict(schema="hepta-qvi-conditional-edit-local-replay-v1", source_commit="610f91087b598656f7f3913e600c705b95bf071f", files=manifest,
              command=[sys.executable, str(source / "compare.py"), "--output", str(out / "results.json")],
              python=sys.version, platform=platform.platform(), threads=1, timeout_seconds=45,
              scope="Unmodified original three-arm fixed-fixture replay; no real-market or new-source generalization claim")
(out / "source_freeze.json").write_text(json.dumps(freeze, indent=2) + "\n")
t = time.perf_counter()
r = subprocess.run(freeze["command"], env=env, cwd=root, capture_output=True, timeout=45)
wall = time.perf_counter() - t
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
(out / "stdout.txt").write_bytes(r.stdout)
(out / "stderr.txt").write_bytes(r.stderr)
receipt = dict(returncode=r.returncode, wall_seconds=wall, child_user_seconds=usage.ru_utime,
               child_system_seconds=usage.ru_stime, child_peak_rss_kib=usage.ru_maxrss)
if r.returncode == 0:
    for name in ("independent.py", "protocol.json"):
        shutil.copyfile(source / name, out / name)
    v = subprocess.run([sys.executable, str(out / "independent.py")], env=env, cwd=root, capture_output=True, timeout=15)
    (out / "independent_stdout.txt").write_bytes(v.stdout)
    (out / "independent_stderr.txt").write_bytes(v.stderr)
    receipt["independent_returncode"] = v.returncode
    if v.returncode == 0:
        (out / "independent.json").write_bytes(v.stdout)
    result = json.loads((out / "results.json").read_text())
    receipt["torch"] = result["torch"]
    receipt["median_inclusive_seconds"] = result["median_inclusive_seconds"]
    receipt["original_protocol_sha256_matches"] = result["protocol_sha256"] == "6df773f53cf63158598a3b307352234eafad5dcfdb694eb797c01326eafceb68"
    receipt["result_sha256"] = hashlib.sha256((out / "results.json").read_bytes()).hexdigest()
(out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
if r.returncode:
    print(r.stderr.decode(errors="replace"))
    raise SystemExit(r.returncode)
