"""Compare an independently computed JSON to the project's published summary without project code."""
import json,sys
from pathlib import Path
from math import comb,fsum
import numpy as np
out=Path(sys.argv[1]); project=Path(sys.argv[2]); lab=Path(sys.argv[3])
ours=json.loads((out/'scores.json').read_bytes()); official=json.loads(project.read_bytes())
acts=json.loads((lab/'actions.json').read_bytes()); row=json.loads((lab/'roster.json').read_bytes())
with np.load(lab/'free.npz') as a:fp=a['scores'].argmax(-1)
with np.load(lab/'camera.npz') as a:cp=a['probability'].argmax(-1)
checks=[];maxerr=0.
def check(path,x,y):
 global maxerr
 if isinstance(x,bool) or isinstance(y,bool):assert bool(x)==bool(y),(path,x,y)
 else:
    err=abs(x-y);assert err<1e-12,(path,x,y);maxerr=max(err,maxerr)
 checks.append(path)
def av(v):return fsum(v)/len(v)
def sign(v):
 p=sum(k>1e-12 for k in v);n=sum(abs(k)>1e-12 for k in v)
 return sum(comb(n,k) for k in range(p,n+1))/2**n
base={k:v['by_source'] for k,v in ours['policy_scores'].items()}
for k,v in official['scores'].items():
 p=ours['policy_scores'][k]
 for g,val in v['source_utility'].items():check(f'{k}/{g}',val,p['by_source'][g]['utility'])
 for name,a,b in [('utility',v['utility'],p['source_mean_utility']),('accuracy',v['accuracy'],p['accuracy']),('purchases',v['purchases'],p['purchases']),('waits',v['waits'],p['windows_waited']),('wait_seconds_mean',v['wait_seconds_mean'],p['wait_transitions']*.48/48)]:check(k+'/'+name,a,b)
 for j,b in enumerate(('free','paid')):
  delta=[p['by_source'][g]['utility']-base[b][g]['utility'] for g in base[b]]
  check(f'{k}/delta/{b}',v['gain_vs_'+b],av(delta));check(f'{k}/p/{b}',v['p_vs_free_paid'][j],sign(delta))
  if b=='free':check(k+'/worst_free',v['worst_vs_free'],min(delta))
 if k in ours['immediate_comparators']:
  check(k+'/adopt',v['original_first_prefix_adoption'],ours['immediate_comparators'][k]['adopted'])
 a=acts[k]['action'];t=acts[k]['end'];bb=[(fp[i,t[i]]==r['label'],cp[i,t[i]]==r['label']) for i,r in enumerate(row) if a[i]]
 check(k+'/rescues',v['rescues_at_exit'],sum(not f and c for f,c in bb));check(k+'/harms',v['harms_at_exit'],sum(f and not c for f,c in bb))
for m in ('bp','keep'):
 a=official['primary'][m];b=ours['three_seed_comparisons'][m]
 for i,key in enumerate(('qvi_minus_fixed','qvi_minus_learned')):
  d=b[key];check(m+'/'+key,a['qvi_minus_fixed_learned'][i],d['mean']);check(m+'/'+key+'/p',a['p_vs_fixed_learned'][i],d['one_sided_sign_p'])
  for g,v in d['by_source'].items():check(m+'/'+key+'/'+g,a['paired_source_differences'][g][i],v)
 for k,v in b['source_seed_mean'].items():check(m+'/average/'+k,a['source_macro'][k],av(list(v.values())))
 check(m+'/floor',a['qvi_worst_vs_free'],b['qvi_minus_free']['worst'])
 check(m+'/gate',a['passes_predeclared_superiority'],b['meets_numerical_criteria'])
w=ours['wait_hindsight'];a=official['opportunity']
for g,v in w['by_source'].items():check('oracle/'+g,v,a['source_gains'][g])
for k,j in [('mean','waiting_gain'),('positive','helped_sources'),('improved_windows','helped_queries'),('opportunity_criterion','passes_old_opportunity_gate')]:check('oracle/'+k,w[k],a[j])
for k,j in [('first_prefix_hindsight_source_utility','first_prefix_oracle'),('six_prefix_hindsight_source_utility','any_prefix_oracle')]:check(k,av(list(w[k].values())),a[j])
check('anytime_oracle_upper_p',a['anytime_upper_p_vs_free'],sign([v-base['free'][g]['utility'] for g,v in w['six_prefix_hindsight_source_utility'].items()]))
s=ours['audio_guitar_gallery_piano_low_margin'];t=official['prior_audio_subgroup']
for k,j in [('harms','harms'),('windows','n'),('rescues','rescues'),('net_per_purchase','net_per_purchase'),('sources','sources')]:check('subgroup/'+k,s[k],t[j])
print(len(checks),maxerr);(out/'agreement.json').write_text(json.dumps({'numeric_and_boolean_fields':len(checks),'max_absolute_difference':maxerr,'all_agree_within':1e-12,'policy_source_means':24*12,'planned_pairwise_source_differences':2*2*12},sort_keys=True,indent=2)+'\n')
