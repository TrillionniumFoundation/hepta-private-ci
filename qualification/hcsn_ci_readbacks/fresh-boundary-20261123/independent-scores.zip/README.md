# Independent readback of the 12-production prospective study

The four inputs are the public sealed decisions and roster and the two frontend posterior arrays. These arrays are sufficient to compute all policy outcomes. No evaluation or model module from the study is imported.

With Python 3.10+ and NumPy installed, unpack this archive and run:

```sh
python score_published_actions.py input scores.replayed.json
cmp scores.replayed.json scores.json
python compare.py . official-result.json input
```

The terminal reward is the binary top-ranked answer's correctness, minus 0.30 for a purchased camera, discounted by exp(-0.20 t). Deduct 0.40 times the discounted integral of elapsed time. The first decision is at t = 0 and each additional step is 0.48 seconds. The independent scorer averages the four windows of each recording and the three matched seeds, then applies the exact one-sided source sign test excluding ties within 1e-12. The primary Holm family contains just the two preregistered BP contrasts.

The optional preroll proof reads publisher file 37320740.ogv and needs ffmpeg on PATH. Run `python preroll_pts.py /path/to/37320740.ogv` to reproduce the six image hashes in preroll-pts.json. The original full-sequence timestamp validator rejected this window's pre-observation decode. The six in-window images match byte for byte across three independent disk decode starts. All other sources and decision timestamps use their original data. No original movie is redistributed.

The additional file agreement.json records the check of 670 numeric and Boolean fields against the published evaluator. The tolerance is 1e-12. Stable digests for the input arrays, code and outputs are available in manifest.json.
