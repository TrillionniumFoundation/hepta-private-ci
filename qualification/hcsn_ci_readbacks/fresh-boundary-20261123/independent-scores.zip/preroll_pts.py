"""Tie physical RGB frames across three decoder starts, independently of task outcomes."""
import hashlib,json,re,subprocess,sys
from fractions import Fraction as F
from pathlib import Path
from bisect import bisect_left
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/hepta-independent-20261123/media-cache/37320740.ogv')
root=Path(__file__).resolve().parent
width,height=720,480
start=F('5.33958');ends=[start+F(12*j,25) for j in range(1,7)]
rx=re.compile(rb'\bn:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:[^\r\n]*?\bs:(\d+)x(\d+)')
sha=lambda b:hashlib.sha256(b).hexdigest()
def probe(seek,postroll=F(0)):
 length=start+F(29,10)-seek+postroll
 cmd=['ffmpeg','-hide_banner','-nostdin','-v','info','-threads','1','-copyts','-ss',f'{float(seek):.6f}','-t',f'{float(length):.6f}','-i',str(p),'-map','0:v:0','-an','-filter_threads','1']
 r=subprocess.run(cmd+['-vf','showinfo=checksum=0','-fps_mode','passthrough','-f','null','-'],check=True,capture_output=True)
 n=[tuple(map(int,x)) for x in rx.findall(r.stderr)]
 assert set(re.findall(rb'config in time_base:\s*(\d+)/(\d+)',r.stderr))=={(b'1',b'24')}
 assert all(r[0]==i and tuple(r[2:])==(width,height) for i,r in enumerate(n))
 reversals=[{'first_pts':a[1],'next_pts':b[1]} for a,b in zip(n,n[1:]) if a[1]>b[1]]
 assert all(F(x['first_pts'],24)<start for x in reversals)
 after=[r for r in n if F(r[1],24)>=start]
 assert all(a[1]<b[1] for a,b in zip(after,after[1:]))
 chosen=[]
 for t in ends:
  tick=max(r[1] for r in n if F(r[1],24)<t)
  ids=[r[0] for r in n if r[1]==tick]
  assert len(ids)==1 and F(tick,24)>=start
  chosen.append((ids[0],tick))
 terms='+'.join('eq(n\\,'+str(i)+')' for i,_ in chosen)
 proc=subprocess.run(cmd+['-vf',f'select={terms},format=rgb24,showinfo=checksum=0','-fps_mode','passthrough','-c:v','rawvideo','-threads:v','1','-f','rawvideo','-'],check=True,capture_output=True)
 checks=[tuple(map(int,x)) for x in rx.findall(proc.stderr)]
 ticks=[t for _,t in chosen];assert ticks==[r[1] for r in checks]
 size=width*height*3;assert len(proc.stdout)==len(ends)*size
 return dict(seek=float(seek),postroll=float(postroll),reversals=reversals,checked_rendered_frames=len(n),chosen_ticks=ticks,
             chosen_rgb24_sha256=[sha(proc.stdout[i*size:(i+1)*size]) for i in range(len(ends))],
             concatenated_rgb_sha256=sha(proc.stdout))
rows=[probe(F(0)),probe(start-2),probe(start-F(1,5),F(1,4))]
truncated=probe(start-F(1,5))
assert len({str((r['chosen_ticks'],r['chosen_rgb24_sha256'])) for r in rows})==1 and not rows[-1]['reversals']
res={'raw_source_sha256':sha(p.read_bytes()),'source_transport':'original registered ogg','start':float(start),'prefix_end':[str(e) for e in ends],'absolute_time_base':'1/24','execution':rows,'truncated_short_seek_diagnostic':truncated,'raw_original_selector_outcome':'rejects nonmonotone PTS in pre-roll before the registered observation','in_window_rgb_equality':True}
out=root/'preroll-pts.json';out.write_text(json.dumps(res,sort_keys=True,indent=2)+'\n');print(rows[0]['chosen_ticks'],rows[0]['concatenated_rgb_sha256'],sha(out.read_bytes()))
