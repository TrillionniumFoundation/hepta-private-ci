"""Score the sealed acoustic actions against the released posteriors using direct formulas.

This program reads just four study data files. It needs Python 3.10+ and NumPy.
The roster order and action file are fixed by the prospective acoustic action seal.
"""
import argparse
from collections import Counter
from hashlib import sha256
import json
from math import comb, exp, expm1, fsum
from pathlib import Path
import numpy as np

SEEDS = (181391, 284729, 395201)
PRICE, RHO, FLOW = .30, .20, .40
FIXED_HASHES = {
    'free.npz': '5be8322e0e256f70119facde0b312b1d878b0ca76d870b32bb61e80b5be8d6c9',
    'actions.json': 'b76f924fef28528cefcab1bbe97f98e4a9e4627d841ed7c97f1668536496905a',
    'roster.json': 'd4a0146197403ffe5e425e09593968329fde5db7e063f1add87df6ee190edcd9',
}
EPS = 1e-12


def mean(seq):
    return fsum(seq) / len(seq)


def numeric_summary(deltas):
    values=list(deltas.values())
    pos,neg=sum(x>EPS for x in values),sum(x < -EPS for x in values)
    n=pos+neg
    p=sum(comb(n,k) for k in range(pos,n+1))/(2**n)
    return dict(by_source=deltas, mean=mean(values), worst=min(values), best=max(values),
                positive=pos, negative=neg, tied=len(values)-n, one_sided_sign_p=p)


def holm(a,b):
    """Exactly two planned tests, smaller p at .025 and larger at .05."""
    return min(a,b)<=.025 and max(a,b)<=.05


def score(root):
    hashes={n:sha256((root/n).read_bytes()).hexdigest()
            for n in ('roster.json','actions.json','free.npz','camera.npz')}
    assert all(hashes[n]==s for n,s in FIXED_HASHES.items())
    roster=json.loads((root/'roster.json').read_bytes())
    actions=json.loads((root/'actions.json').read_bytes())
    with np.load(root/'free.npz',allow_pickle=False) as f:
        free=f['scores'].copy()
        gallery=f['gallery_audio'].copy()
    with np.load(root/'camera.npz',allow_pickle=False) as f:
        assert list(f['query_id'])==[e['query_id'] for e in roster]
        camera=f['probability'].copy()
    assert len(actions)==24 and len(roster)==48==len({s['query_id'] for s in roster})
    assert free.shape==gallery.shape==camera.shape==(48,6,2)
    for mat in (free,gallery,camera):
        assert np.isfinite(mat).all() and (mat >= 0).all() and (mat <= 1).all()
        assert np.allclose(mat.sum(axis=-1),1.,rtol=0,atol=1e-8)
    groups=sorted({r['group'] for r in roster}); labels=[r['label'] for r in roster]
    pos={g:[i for i,row in enumerate(roster) if row['group']==g] for g in groups}
    assert len(groups)==12 and all(len(ix)==4 and len(set(labels[i] for i in ix))==1 for ix in pos.values())
    assert Counter(labels)=={0:24,1:24} and all(row['dt']==[.48]*6 for row in roster)
    raw=np.stack([free,camera],axis=2).argmax(-1)
    correct=raw==np.asarray(labels)[:,None,None]
    for a,side in [(0,'free'),(1,'paid')]:
        assert all(x==a for x in actions[side]['action']) and not any(actions[side]['end'])
    U=np.empty(correct.shape,dtype=float)
    for i,row in enumerate(roster):
        for t in range(6):
            seconds=fsum(row['dt'][1:t+1])
            discount=exp(-RHO*seconds)
            flow=FLOW*expm1(-RHO*seconds)/RHO
            for buy in (0,1):
                U[i,t,buy]=discount*(float(correct[i,t,buy])-PRICE*buy)+flow
    keys=set(actions)
    assert keys=={'free','paid','svd','lp','gradient','train_only_six'}|{f'read-{m}-{a}-{s}' for m in ('fixed','learned','qvi') for a in ('keep','bp') for s in SEEDS}
    curves={}
    all_scores={}
    for key in sorted(keys):
        a=actions[key]['action'];t=actions[key]['end']
        assert len(a)==len(t)==48 and all(type(x) is int and x in (0,1) for x in a) and all(type(x) is int and 0<=x<=5 for x in t)
        v=[float(U[i,t[i],a[i]]) for i in range(48)]
        hit=[int(correct[i,t[i],a[i]]) for i in range(48)]
        curves[key]=v
        by_source={}
        for g,ix in pos.items():
            by_source[g]=dict(utility=mean([v[i] for i in ix]),correct=sum(hit[i] for i in ix),
                              windows=4,purchases=sum(a[i] for i in ix),windows_waited=sum(t[i]>0 for i in ix),
                              wait_transitions=sum(t[i] for i in ix))
        all_scores[key]=dict(by_source=by_source,source_mean_utility=mean([r['utility'] for r in by_source.values()]),
                             correct=sum(hit),accuracy=sum(hit)/48,purchases=sum(a),windows_waited=sum(s>0 for s in t),
                             wait_transitions=sum(t),terminal_prefix_counts=[t.count(j) for j in range(6)],
                             worst_source_utility=min(r['utility'] for r in by_source.values()))
    smean=lambda x:{g: mean([float(x[i]) for i in ix]) for g,ix in pos.items()}
    def contrast(x,y):
        return numeric_summary(smean([p-q for p,q in zip(x,y)]))
    def family(name,adapt):
        return [mean([curves[f'read-{name}-{adapt}-{s}'][i] for s in SEEDS]) for i in range(48)]
    comparisons={}
    for adapt in ('bp','keep'):
        q=family('qvi',adapt)
        fixed=contrast(q,family('fixed',adapt)); learned=contrast(q,family('learned',adapt))
        floor=contrast(q,curves['free'])
        passes=holm(fixed['one_sided_sign_p'],learned['one_sided_sign_p'])
        comparisons[adapt]=dict(source_seed_mean={m:smean(family(m,adapt)) for m in ('fixed','learned','qvi')},
            qvi_minus_fixed=fixed,qvi_minus_learned=learned,qvi_minus_free=floor,holm_both=passes,
            both_mean_cutoffs=min(fixed['mean'],learned['mean'])>=.03-EPS, worst_free_floor=floor['worst']>=-.05-EPS)
        comparisons[adapt]['meets_numerical_criteria']=all(comparisons[adapt][k] for k in ('holm_both','both_mean_cutoffs','worst_free_floor'))
    immediate={}
    for k in ('svd','lp','gradient','train_only_six'):
        assert not any(actions[k]['end'])
        f,c=contrast(curves[k],curves['free']),contrast(curves[k],curves['paid'])
        a=actions[k]['action'];b=np.array(a,dtype=bool);fh=correct[:,0,0];ch=correct[:,0,1]
        passes=holm(f['one_sided_sign_p'],c['one_sided_sign_p'])
        immediate[k]=dict(minus_free=f,minus_paid=c,buys=int(b.sum()),
            rescued=int((b&~fh&ch).sum()),harmed=int((b&fh&~ch).sum()),missed_rescue=int((~b&~fh&ch).sum()),
            bought_both_right=int((b&fh&ch).sum()),bought_both_wrong=int((b&~fh&~ch).sum()),holm_both=passes,
            adopted=bool(0<sum(a)<48 and min(f['mean'],c['mean'])>=.03-EPS and f['worst']>=-.05-EPS and passes))
    best_now=U[:,0,:].max(axis=1)
    best_over_time=U.max(axis=(1,2))
    waiting=contrast(best_over_time,best_now)
    waiting.update(first_prefix_hindsight_source_utility=smean(best_now),six_prefix_hindsight_source_utility=smean(best_over_time),
                   improved_windows=int((best_over_time>best_now+EPS).sum()),
                   opportunity_criterion=bool(waiting['mean']>=.015-EPS and waiting['positive']>=2))
    selected=(free[:,0,1]>=.5)&(gallery[:,0,1]<.5)&(abs(2*free[:,0,1]-1)<=.65)
    rescue=correct[:,0,1]&~correct[:,0,0];harm=~correct[:,0,1]&correct[:,0,0]
    per={}
    for g,ix in pos.items():
        ii=np.asarray(ix)[selected[ix]];n=len(ii)
        a,b=int(rescue[ii].sum()),int(harm[ii].sum())
        per[g]=dict(windows=n,rescues=a,harms=b,neutral=n-a-b,net_sum=a-b-PRICE*n,
                    conditional_net_per_purchase=((a-b)/n-PRICE) if n else None,
                    four_window_delta_vs_free=(a-b-PRICE*n)/4)
    n=int(selected.sum());a=int((selected&rescue).sum());b=int((selected&harm).sum())
    cue=dict(windows=n,sources=sum(row['windows']>0 for row in per.values()),rescues=a,harms=b,neutral=n-a-b,
             net_per_purchase=((a-b)/n-PRICE) if n else None,
             all_source_mean_delta_vs_free=mean([r['four_window_delta_vs_free'] for r in per.values()]),by_source=per)
    return dict(data_sha256=hashes,source_count=12,window_count=48,policy_count=24,policy_scores=all_scores,
                three_seed_comparisons=comparisons,immediate_comparators=immediate,wait_hindsight=waiting,
                audio_guitar_gallery_piano_low_margin=cue,program_sha256=sha256(Path(__file__).read_bytes()).hexdigest())


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('input',type=Path);p.add_argument('output',type=Path)
    args=p.parse_args(); result=score(args.input)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(sha256(args.output.read_bytes()).hexdigest())
