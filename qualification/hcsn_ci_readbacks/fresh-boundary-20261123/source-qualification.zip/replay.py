"""Rehash all media and rerun the locked four-window protocol directly out of the original repo's ZIP."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha1, sha256
import json
from pathlib import Path
import subprocess
import sys
import types
from zipfile import ZipFile

def replay(repository, directories, evidence, order_file, cohort_file):
    with ZipFile(repository/'qualification/hcsn_blocker_followup/media/source_replay.zip') as packed:
        source=packed.read('pinned/technical.py')
    assert sha256(source).hexdigest()=='ebf2c136c99260a238286e3c24c745b70868a010cce3f7b7ebfdc2b5a91830cb'
    sys.path.insert(0,str(repository))
    verifier=types.ModuleType('pinned_counterpart')
    verifier.__file__=str(evidence/'technical.py')
    exec(compile(source,verifier.__file__,'exec'),verifier.__dict__)
    queue=json.loads((evidence/order_file).read_text())['queue']
    frozen=json.loads((evidence/cohort_file).read_text())
    reports={r['pageid']:r for r in frozen['sources']}
    def check(item):
        pid=item['pageid']
        name=str(pid)+Path(item['title']).suffix
        candidates=[p/name for p in directories if (p/name).is_file()]
        if not candidates:raise FileNotFoundError(f'Original {pid}, see URL in frozen-queue.json')
        p=candidates[0];h1=sha1();h2=sha256()
        with p.open('rb') as f:
            for block in iter(lambda:f.read(1<<20),b''):h1.update(block);h2.update(block)
        assert (h1.hexdigest(),h2.hexdigest(),p.stat().st_size)==(item['sha1'],reports[pid]['source_sha256'],item['size'])
        prior=json.loads((evidence/'checks'/f'{pid}.json').read_text())
        try:
            fresh=verifier.qualify(p)
        except (ValueError,IndexError,subprocess.CalledProcessError) as error:
            fresh={'eligible':False,'reason':'technical_exception','exception':str(error),'quarters':[]}
        for key,value in fresh.items():assert value==prior[key],(pid,key)
        assert len(fresh['quarters'])==len(reports[pid]['starts'])
        return {'pageid':pid,'sha256':h2.hexdigest(),'bytes':p.stat().st_size,'eligible':fresh['eligible'],'windows':len(fresh['quarters'])}
    with ThreadPoolExecutor(max_workers=2) as pool:result=list(pool.map(check,queue))
    return {'locked_verifier_sha256':sha256(source).hexdigest(),'records':result,'all_originals':len(result),'all_bytes':sum(r['bytes'] for r in result),'clock_passes':sum(r['eligible'] for r in result),'selected_complete_windows':sum(r['windows'] for r in result if r['pageid'] in frozen['qualified_ids'])}

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--repo',required=True,type=Path)
    cli.add_argument('--originals',required=True,type=Path,nargs='+')
    cli.add_argument('--output',required=True,type=Path)
    cli.add_argument('--order',default='all-checked-order.json');cli.add_argument('--cohort',default='final-cohort.json')
    args=cli.parse_args()
    result=replay(args.repo.resolve(),[p.resolve() for p in args.originals],Path(__file__).resolve().parent,args.order,args.cohort)
    args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(result['all_originals'],result['all_bytes'],result['clock_passes'],result['selected_complete_windows'])
