"""Create one isolated driver worktree only after the root supplies final pins."""

from pathlib import Path
import hashlib
import json
import resource
import subprocess
import sys
import time

config = json.load(sys.stdin)
assert config['status'] == 'development_only_frozen_common_source'
head, tree = config['driver_head'], config['driver_tree']
assert len(head) == len(tree) == 40
assert all(c in '0123456789abcdef' for c in head + tree)
W, base = Path(config['driver_worktree']), Path(config['git_source'])
E = Path(config['setup_output'])
assert not W.exists() and not E.exists()
E.mkdir(parents=True)
started = time.monotonic()
cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
report = {'schema': 'hepta.repo-mdv.common-worktree-setup.v1', 'head': head, 'tree': tree,
          'worktree': str(W), 'source': str(base), 'scientific_status': 'HOLD',
          'production_status': 'production_not_adopted', 'steps': [], 'status': 'started'}

def save():
    (E / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')

def run(name, argv, cwd):
    result = subprocess.run(argv, cwd=cwd, capture_output=True, timeout=120)
    for suffix, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (E / (name + '.' + suffix)).write_bytes(raw)
    report['steps'].append({'name': name, 'argv': argv, 'cwd': str(cwd), 'exit': result.returncode})
    save()
    assert result.returncode == 0, name
    return result.stdout.decode()

try:
    assert run('tree-before', ['git', 'rev-parse', head + '^{tree}'], base).strip() == tree
    run('create-worktree', ['git', 'worktree', 'add', '--detach', str(W), head], base)
    assert run('identity', ['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], W).splitlines() == [head, tree]
    assert run('status', ['git', 'status', '--porcelain=v1'], W) == ''
    report['driver_files'] = {}
    for relative, pin in config['inputs']['driver_files'].items():
        path = W / relative
        assert path.is_file() and not path.is_symlink() and path.stat().st_size <= 65536
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        assert digest == pin['sha256'], relative
        report['driver_files'][relative] = {'sha256': digest, 'bytes': len(raw)}
    report['status'] = 'isolated_frozen_driver_ready_no_task_executed'
except Exception as error:
    report['status'] = 'setup_incomplete'
    report['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    now = resource.getrusage(resource.RUSAGE_CHILDREN)
    report['wall_seconds'] = time.monotonic() - started
    report['reaped_child_cpu_seconds'] = now.ru_utime + now.ru_stime - cpu.ru_utime - cpu.ru_stime
    save()
    print(json.dumps(report, indent=2), flush=True)
