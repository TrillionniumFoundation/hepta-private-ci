from pathlib import Path
import datetime,hashlib,json,os,resource,shutil,subprocess,sys,time
sys.dont_write_bytecode=True
config=json.load(sys.stdin)
W=Path(config['driver_worktree'])
BASE=Path(config['git_source'])
E=Path(config['output'])
R='cfe941b4762a773679a552068d1560ae17a3f226'
S='693a013b254d07779f6f2b2a78d0ee31481f4ea9'
DRIVER=config['driver_head']
DRIVER_TREE=config['driver_tree']
RW=Path(config['task_R_worktree'])
SW=Path(config['task_S_worktree'])
TARGET=Path(config['cargo_target'])
CACHE=Path('/home/qian-qi/work/cell-ui-ime-20261108-08b6-evidence/runtime-assets')
changed='apps/hepta-control-ui/rust/robrix-ui/src/robrix/room_ime_commit_tests.rs'
fontroot='apps/hepta-control-ui/rust/robrix-ui/resources/fonts'
payload=config['inputs']
assert config['status']=='development_only_frozen_common_source'
assert len(DRIVER)==len(DRIVER_TREE)==40 and all(c in '0123456789abcdef' for c in DRIVER+DRIVER_TREE)
assert not E.exists() and not RW.exists() and not SW.exists()
assert config['cache_mode'] in ['new_own_target_global_caches_may_be_warm','reused_own_target_after_a51_development']
assert (not TARGET.exists()) if config['cache_mode'].startswith('new_') else TARGET.is_dir()
E.mkdir(parents=True);(E/'inputs').mkdir()
sys.path.insert(0,str(W/'scripts'))
from ndu_real_runtime.subprocess_supervisor import run_logged
started=time.monotonic();cpu0=resource.getrusage(resource.RUSAGE_CHILDREN)
report={'schema':'hepta.repo-mdv.native-dev-campaign.v1','status':'started','driver':DRIVER,'source_S':S,'source_R':R,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'tasks':[],'scientific_qualified':False,'production_qualified':False,'formal_adoption_receipt':None,'independent_task_count':0,'independent_benefit':None,'cache_mode':config['cache_mode'],'whole_prior_preparation_cost_known':False}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save():
 (E/'RESULT.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
def git(*args,cwd=W):
 return subprocess.check_output(['git',*args],cwd=cwd,text=True,timeout=30)
assert git('rev-parse','HEAD').strip()==DRIVER and git('status','--porcelain=v1')==''
report['driver_tree']=git('rev-parse','HEAD^{tree}').strip()
assert report['driver_tree']==DRIVER_TREE
assert payload['driver_files'] and set(payload['driver_files'])=={'scripts/cell_repo_mdv/'+name for name in ['__init__.py','contracts.py','memory.py','runner.py','test_memory.py','test_runner.py']}
for relative,pin in payload['driver_files'].items():
 assert sha((W/relative).read_bytes())==pin['sha256']
report['driver_files']=dict(payload['driver_files'])
for relative in ['scripts/ndu_real_runtime/__init__.py','scripts/ndu_real_runtime/span_meter.py','scripts/ndu_real_runtime/subprocess_supervisor.py']:
 raw=(W/relative).read_bytes()
 committed=subprocess.check_output(['git','show',DRIVER+':'+relative],cwd=W,timeout=30)
 assert raw==committed
 report['driver_files'][relative]={'sha256':sha(raw),'bytes':len(raw)}
report['controller_sha256']=config['controller_sha256']
report['input_config_sha256']=sha(json.dumps(config,sort_keys=True,separators=(',',':')).encode())
report['scientific_status']='HOLD'
report['production_status']='production_not_adopted'
env=dict(os.environ)
env.update({'PATH':'/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/work/cell-dependency-pin-20261108-08b6-evidence/tools/bin:/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/.local/bin:/home/qian-qi/.cargo/bin:'+env.get('PATH',''),'PYTHONPATH':str(W/'scripts'),'PYTHONDONTWRITEBYTECODE':'1','RUSTUP_TOOLCHAIN':'1.95.0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(TARGET),'CARGO_NET_OFFLINE':'true'})
report['environment']={k:env[k] for k in ['PATH','PYTHONPATH','PYTHONDONTWRITEBYTECODE','RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','CARGO_TARGET_DIR','CARGO_NET_OFFLINE']}
report['python']=sys.version
report['runtime_tools']={}
for name in ['python3','rustc','cargo','cargo-clippy','clippy-driver','just','cargo-nextest']:
 executable=shutil.which(name,path=env['PATH'])
 assert executable is not None,name
 resolved=Path(executable).resolve(strict=True)
 assert resolved.is_file()
 h=hashlib.sha256()
 with resolved.open('rb') as stream:
  while chunk:=stream.read(1024*1024):h.update(chunk)
 report['runtime_tools'][name]={'invoked_path':executable,'resolved_path':str(resolved),'bytes':resolved.stat().st_size,'sha256':h.hexdigest()}
save()
def run(name,argv,cwd,timeout=300,required=True):
 t=time.monotonic();c=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (E/(name+'.stdout')).open('xb') as out,(E/(name+'.stderr')).open('xb') as err:
  old=Path.cwd();os.chdir(cwd)
  try:r=run_logged(argv,stdout=out,stderr=err,timeout=timeout,env=env)
  finally:os.chdir(old)
 now=resource.getrusage(resource.RUSAGE_CHILDREN)
 row={'name':name,'argv':argv,'cwd':str(cwd),'wall_seconds':time.monotonic()-t,'child_cpu_seconds':now.ru_utime+now.ru_stime-c.ru_utime-c.ru_stime,'supervision':r}
 for stream in ['stdout','stderr']:
  raw=(E/(name+'.'+stream)).read_bytes();row[stream]={'bytes':len(raw),'sha256':sha(raw),'path':name+'.'+stream}
 report['steps'].append(row);save();print(json.dumps({'name':name,'exit':r['returncode'],'error':r['error']}),flush=True)
 if required:assert r['returncode']==0 and r['error'] is None and r['cleanup_complete'],name
 return r
def file_from_git(commit,relative):
 obj=commit+':'+relative
 size=int(git('cat-file','-s',obj))
 assert size<=16*1024*1024
 raw=subprocess.check_output(['git','show',obj],cwd=W,timeout=30)
 assert len(raw)==size
 return raw
def pins(commit):
 return {p:sha(file_from_git(commit,p)) for p in payload['source_paths']}
fontspec=payload['fonts']
font_status=''.join('?? '+row['path']+'\n' for row in fontspec)
def step(kind,argv,timeout=600,**extra):
 return {'kind':kind,'argv':argv,'timeout_seconds':timeout,**extra}
def clippy():
 return ['cargo','clippy','--locked','--manifest-path','apps/hepta-control-ui/rust/Cargo.toml','-p','hepta-robrix-ui','--all-targets','--features','ui,native-host,native-presentation','--','-D','warnings']
def ui():
 return ['just','test','--manifest-path',str(SW/'apps/hepta-control-ui/rust/Cargo.toml'),'--locked','-p','hepta-robrix-ui','--lib','--features','ui']
def task(number,workspace,commit,learn,query,recipes,before,after,before_status,after_status,evidence):
 return {'schema':'hepta.repo-mdv.dev-task.v1','task_id':'repo-dev/'+number,'lineage_group':'R-S-native-clippy-20261108','split':'development','query':query,'workspace':str(workspace),'origin':{'kind':'observed_repository_ci' if learn else 'declared_development_followup','evidence_sha256':evidence},'source':{'head':commit,'tree':git('rev-parse',commit+'^{tree}').strip(),'before_pins':before,'after_pins':after,'before_status':before_status,'after_status':after_status},'budget':{'wall_seconds':1500 if learn else 900,'tool_calls':16},'environment':report['environment'],'learn_on_success':learn,'recipes':recipes}
try:
 run('rustc',['/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc','--version'],W,30)
 run('cargo',['/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/cargo','--version'],W,30)
 run('worktree-R',['git','worktree','add','--detach',str(RW),R],BASE,120)
 run('worktree-S',['git','worktree','add','--detach',str(SW),S],BASE,120)
 for tag,workspace in [('R',RW),('S',SW)]:
  run('fonts-'+tag,[sys.executable,'apps/hepta-control-ui/tools/prepare-fonts.py','--cache',str(CACHE),'--offline','--install',str(workspace/fontroot)],workspace,180)
  for f in fontspec:
   raw=(workspace/f['path']).read_bytes()
   assert len(raw)==f['bytes'] and sha(raw)==f['sha256']
 patch=subprocess.check_output(['git','diff','--no-ext-diff',R,S,'--',changed],cwd=W,timeout=30)
 old,new=file_from_git(R,changed),file_from_git(S,changed)
 assert old.count(b'root.text_input(&mut cx, ids!(message_input))')==1
 assert old.replace(b'root.text_input(&mut cx, ids!(message_input))',b'root.text_input(&cx, ids!(message_input))',1)==new
 patchpath=E/'inputs/clippy-repair.patch';patchpath.write_bytes(patch)
 corpuspath=E/'inputs/corpus.json';corpuspath.write_text(json.dumps(payload['corpus'],indent=2)+'\n')
 rp,sp=pins(R),pins(S)
 for f in fontspec:
  rp[f['path']]=sp[f['path']]=f['sha256']
 repair=[step('observe',clippy(),800,expected_returncode=101,required_output={'stderr':'unnecessary_mut_passed'}),step('repair',['git','apply','--check',str(patchpath)],30),step('repair',['git','apply',str(patchpath)],30),step('verify',clippy(),600)]
 inspect_ime=[step('observe',['git','show','HEAD:apps/hepta-control-ui/rust/robrix-ui/src/robrix/room.rs'],30),step('verify',clippy(),600)]
 inspect_lock=[step('observe',['git','show','HEAD:apps/hepta-control-ui/rust/Cargo.lock'],30),step('verify',clippy(),600)]
 first=task('M-001-clippy-repair',RW,R,True,'Rust 1.95 native Clippy unnecessary_mut_passed root.text_input mutable borrow repair',{'native-clippy-borrow':repair,'ime-owner-commit':inspect_ime,'official-pin-utils-parents':inspect_lock},rp,sp,font_status,' M '+changed+'\n'+font_status,'c90b87478b55293da6d51a4d1ba1e7029f2e0a9524f6b8697729b75ea0de3df1')
 second=task('M-002-native-ui-followup',SW,S,False,'After strict Clippy immutable text_input repair, execute the actual native UI regression library package tests',{'native-clippy-borrow':[step('verify',ui(),800,required_output={'stderr':'33 passed, 0 skipped'})],'ime-owner-commit':[step('observe',['git','show','HEAD:apps/hepta-control-ui/rust/robrix-ui/src/robrix/room.rs'],30),step('verify',ui(),800,required_output={'stderr':'33 passed, 0 skipped'})],'official-pin-utils-parents':[step('observe',['git','show','HEAD:apps/hepta-control-ui/rust/Cargo.lock'],30),step('verify',ui(),800,required_output={'stderr':'33 passed, 0 skipped'})]},sp,sp,font_status,font_status,'c88446616596b73c02d99005c373c16a0e503fe2b046132d7ebb51a676033e65')
 for name,value in [('task1.json',first),('task2.json',second)]:
  (E/'inputs'/name).write_text(json.dumps(value,indent=2)+'\n')
 report['input_files']={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted((E/'inputs').iterdir())}
 report['pre_execution_plan_scope']='two already-exposed development tasks of one family; approved recipes, no independent holdout, no adaptive query selection after task outcomes'
 save();(E/'PRE_EXECUTION.json').write_text(json.dumps(report,indent=2)+'\n')
 firstout=E/'task1';secondout=E/'task2'
 argv=[sys.executable,'-B','-m','cell_repo_mdv.runner','--task',str(E/'inputs/task1.json'),'--corpus',str(corpuspath),'--output',str(firstout)]
 r=run('task1',argv,W,1600,False)
 if (firstout/'result.json').exists():report['tasks'].append(json.loads((firstout/'result.json').read_text()));save()
 assert r['returncode']==0 and r['error'] is None and r['cleanup_complete'] and report['tasks'][0]['terminal']=='proved','first real development task did not complete'
 argv=[sys.executable,'-B','-m','cell_repo_mdv.runner','--task',str(E/'inputs/task2.json'),'--corpus',str(corpuspath),'--state',str(firstout/'state.json'),'--state-receipt',str(firstout/'result.json'),'--output',str(secondout)]
 r=run('task2',argv,W,1000,False)
 if (secondout/'result.json').exists():report['tasks'].append(json.loads((secondout/'result.json').read_text()));save()
 assert r['returncode']==0 and r['error'] is None and r['cleanup_complete'] and len(report['tasks'])==2 and report['tasks'][1]['terminal']=='proved','second real development task did not complete'
 assert report['tasks'][0]['state_after_digest']==report['tasks'][1]['state_before_digest']
 assert json.loads((firstout/'state.json').read_text())['production_update']=='not_requested'
 assert report['tasks'][1]['state_updates_before']==1
 assert report['tasks'][1]['baseline_executed'] is False
 assert all(task['formal_adoption_receipt'] is None and not task['scientific_qualified'] and not task['production_qualified'] for task in report['tasks'])
 assert report['tasks'][0]['training_updates_consumed']==1 and report['tasks'][1]['training_updates_consumed']==0
 assert git('diff','--no-ext-diff',R,'--',changed,cwd=RW).encode()==patch
 report['status']='two_actual_development_tasks_completed_with_verified_private_state_consumption'
except Exception as error:
 report['status']='development_incomplete'
 report['error']={'type':type(error).__name__,'message':str(error)}
 raise
finally:
 report['font_cleanup']=[]
 for workspace in [RW,SW]:
  for f in fontspec:
   p=workspace/f['path']
   if p.is_file():
    raw=p.read_bytes()
    if len(raw)==f['bytes'] and sha(raw)==f['sha256']:
     p.unlink();report['font_cleanup'].append({'path':str(p),'removed_after_pin_check':True})
    else:report['font_cleanup'].append({'path':str(p),'removed_after_pin_check':False})
 report['worktree_statuses']={}
 for label,workspace in [('driver',W),('task_R',RW),('task_S',SW)]:
  if workspace.exists():report['worktree_statuses'][label]=git('status','--porcelain=v1',cwd=workspace)
 report['driver_after']=git('rev-parse','HEAD').strip()
 report['driver_tree_after']=git('rev-parse','HEAD^{tree}').strip()
 report['driver_file_pins_after']={relative:sha((W/relative).read_bytes()) for relative in report['driver_files']}
 report['driver_source_unchanged']=(report['driver_after']==DRIVER and report['driver_tree_after']==DRIVER_TREE and report['worktree_statuses']['driver']=='' and all(report['driver_file_pins_after'][p]==pin['sha256'] for p,pin in report['driver_files'].items()))
 now=resource.getrusage(resource.RUSAGE_CHILDREN)
 report['observed_campaign_wall_seconds']=time.monotonic()-started
 report['observed_reaped_child_cpu_seconds']=now.ru_utime+now.ru_stime-cpu0.ru_utime-cpu0.ru_stime
 report['nested_costs_not_additive']=True
 report['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 if not report['driver_source_unchanged']:
  report['status']='development_incomplete'
  report['error']={'type':'SourceChanged','message':'frozen driver source changed'}
 save();print(json.dumps({k:v for k,v in report.items() if k not in ['tasks','driver_files','steps']},indent=2),flush=True)
 assert report['driver_source_unchanged'],'frozen driver source changed'
