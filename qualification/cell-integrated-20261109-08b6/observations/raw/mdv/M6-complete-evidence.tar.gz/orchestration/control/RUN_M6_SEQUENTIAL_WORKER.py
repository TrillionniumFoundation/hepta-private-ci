"""Run the unchanged MDV setup, campaign and archive controllers in one bounded worker."""
from pathlib import Path
import contextlib
import datetime
import gzip
import hashlib
import io
import json
import os
import resource
import signal
import stat
import sys
import tarfile
import time
import traceback

sys.dont_write_bytecode = True
started = time.monotonic()
self0 = resource.getrusage(resource.RUSAGE_SELF)
child0 = resource.getrusage(resource.RUSAGE_CHILDREN)
input_raw = sys.stdin.buffer.read(1024 * 1024 + 1)
assert len(input_raw) <= 1024 * 1024
payload = json.loads(input_raw)
config = json.loads(payload["profile_text"])
assert config["status"] == "development_only_frozen_common_source"
head, tree = config["driver_head"], config["driver_tree"]
assert head == "885dae0f3285267e9e9c49d8b43b0d009779f9e8"
assert tree == "293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb"
base = Path(config["git_source"])
root = Path("/home/qian-qi/work/cell-repo-mdv-20261109-08b6-evidence")
out = root / "common-M6-orchestration-001"
delivery = root / "common-M6-delivery-001"
assert not out.exists()
out.mkdir(parents=True)
with (out / "WORKER_INPUT.json").open("xb") as stream:
    stream.write(input_raw)
control = out / "control"
control.mkdir()
report = {
    "schema": "hepta.repo-mdv.common-M6-sequential-worker.v1",
    "status": "started", "head": head, "tree": tree,
    "started_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "guards": [], "phases": [], "scientific_status": "HOLD",
    "production_status": "production_not_adopted", "confirmation_tasks": 0,
    "root_freeze_job_terminal_used_as_evidence": False,
    "phase_execution": "unchanged controller bytes in fresh exec namespaces; original RUN still spawns fresh task processes",
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read_bound(path, limit=1024 * 1024):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        assert stat.S_ISREG(info.st_mode) and info.st_size <= limit
        raw = stream.read(limit + 1)
    assert len(raw) == info.st_size and len(raw) <= limit
    return raw

def save():
    (out / "WORKER_RESULT.json").write_text(json.dumps(report, indent=2) + "\n")

def file_pin(path):
    raw = read_bound(path, 16 * 1024 * 1024)
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}

class BoundedText:
    def __init__(self, stream):
        self.stream, self.retained = stream, 0
    def write(self, text):
        raw = text.encode("utf-8")
        if self.retained + len(raw) > 8 * 1024 * 1024:
            raise RuntimeError("worker phase text output limit exceeded")
        self.stream.write(raw)
        self.retained += len(raw)
        return len(text)
    def flush(self):
        self.stream.flush()

def alarm_expired(signum, frame):
    raise TimeoutError("worker phase deadline exhausted")

signal.signal(signal.SIGALRM, alarm_expired)
save()
try:
    for name, item in payload["files"].items():
        assert "/" not in name and ".." not in name
        raw = item["text"].encode()
        assert len(raw) <= 1024 * 1024 and sha(raw) == item["sha256"]
        with (control / name).open("xb") as stream:
            stream.write(raw)
    assert read_bound(control / "COMMON_M6_LAUNCH_PROFILE.json").decode() == payload["profile_text"]
    supervisor = base / "scripts/ndu_real_runtime/subprocess_supervisor.py"
    source = read_bound(supervisor, 65536)
    assert sha(source) == "2679c877f630148edddd17183e6d3766b9c690d57ce8465308eb8d84a5aafb81"
    namespace = {"__name__": "mdv_m6_bound_guard_supervisor", "__file__": str(supervisor)}
    exec(compile(source, str(supervisor), "exec"), namespace)
    run_logged = namespace["run_logged"]
    report["guard_supervisor_pin"] = file_pin(supervisor)

    def guard(name, argv, expected):
        before = time.monotonic()
        paths = [out / (name + ".stdout"), out / (name + ".stderr")]
        previous = Path.cwd()
        try:
            os.chdir(base)
            with paths[0].open("xb") as stdout, paths[1].open("xb") as stderr:
                result = run_logged(argv, stdout=stdout, stderr=stderr,
                                    timeout=30, env=dict(os.environ))
        finally:
            os.chdir(previous)
        row = {"name": name, "argv": argv, "cwd": str(base),
               "wall_seconds": time.monotonic() - before, "supervision": result,
               "stdout": file_pin(paths[0]), "stderr": file_pin(paths[1])}
        report["guards"].append(row)
        save()
        assert result["returncode"] == 0 and result["error"] is None and result["cleanup_complete"]
        assert read_bound(paths[0], 8 * 1024 * 1024) == expected, name

    guard("source-identity", ["git", "rev-parse", "HEAD", "HEAD^{tree}"], (head + "\n" + tree + "\n").encode())
    guard("source-parent", ["git", "rev-parse", "HEAD^"], (config["root_released_parent"] + "\n").encode())
    guard("source-status", ["git", "status", "--porcelain=v1"], b"")
    guard("supervisor-git-blob", ["git", "show", head + ":scripts/ndu_real_runtime/subprocess_supervisor.py"], source)
    report["independent_git_guard_passed"] = True
    save()

    def phase(name, script_name, input_text, deadline):
        script = read_bound(control / script_name)
        input_path = out / (name + ".input.json")
        with input_path.open("x") as stream:
            stream.write(input_text)
        paths = [out / (name + ".stdout"), out / (name + ".stderr")]
        row = {"name": name, "script": file_pin(control / script_name),
               "input": file_pin(input_path), "deadline_seconds": deadline,
               "status": "started"}
        report["phases"].append(row)
        save()
        at = time.monotonic()
        own = resource.getrusage(resource.RUSAGE_SELF)
        child = resource.getrusage(resource.RUSAGE_CHILDREN)
        previous_cwd, previous_stdin = Path.cwd(), sys.stdin
        try:
            os.chdir(base)
            sys.stdin = io.StringIO(input_text)
            with paths[0].open("xb") as stdout, paths[1].open("xb") as stderr:
                with contextlib.redirect_stdout(BoundedText(stdout)), contextlib.redirect_stderr(BoundedText(stderr)):
                    signal.setitimer(signal.ITIMER_REAL, deadline)
                    try:
                        exec(compile(script, str(control / script_name), "exec"),
                             {"__name__": "__main__", "__file__": str(control / script_name)})
                        row["status"] = "completed"
                    except BaseException as error:
                        row["status"] = "failed"
                        row["error"] = {"type": type(error).__name__, "message": str(error)}
                        traceback.print_exc()
                        raise
                    finally:
                        signal.setitimer(signal.ITIMER_REAL, 0)
                        stdout.flush(); stderr.flush()
                        os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            sys.stdin = previous_stdin
            os.chdir(previous_cwd)
            now_own = resource.getrusage(resource.RUSAGE_SELF)
            now_child = resource.getrusage(resource.RUSAGE_CHILDREN)
            row["wall_seconds"] = time.monotonic() - at
            row["worker_self_cpu_seconds"] = now_own.ru_utime + now_own.ru_stime - own.ru_utime - own.ru_stime
            row["reaped_child_cpu_seconds"] = now_child.ru_utime + now_child.ru_stime - child.ru_utime - child.ru_stime
            row["stdout"], row["stderr"] = file_pin(paths[0]), file_pin(paths[1])
            save()

    phase("setup", "PREPARE_COMMON_WORKTREE.py", payload["profile_text"], 300)
    phase("campaign", "RUN_NATIVE_COMMON_DEV.py", payload["profile_text"], 3600)
    report["status"] = "two_development_tasks_done_archive_not_started"
    save()
    pre_archive = (out / "WORKER_RESULT.json").read_text()
    archive_payload = dict(payload["files"])
    archive_payload["ORCHESTRATION_PRE_ARCHIVE.json"] = {"text": pre_archive, "sha256": sha(pre_archive.encode())}
    for path in sorted(out.iterdir()):
        if path.suffix in [".stdout", ".stderr"]:
            raw = read_bound(path, 8 * 1024 * 1024)
            assert len(raw) <= 1024 * 1024
            archive_payload["worker-" + path.name] = {"text": raw.decode(), "sha256": sha(raw)}
    phase("archive", "ARCHIVE_COMMON_M6_DEV.py", json.dumps(archive_payload), 300)
    report["status"] = "three_original_phases_completed"
except BaseException as error:
    report["status"] = "worker_incomplete"
    report["error"] = {"type": type(error).__name__, "message": str(error)}
    raise
finally:
    now_self = resource.getrusage(resource.RUSAGE_SELF)
    now_child = resource.getrusage(resource.RUSAGE_CHILDREN)
    report["observed_through_phase_archive_wall_seconds"] = time.monotonic() - started
    report["worker_self_cpu_seconds"] = now_self.ru_utime + now_self.ru_stime - self0.ru_utime - self0.ru_stime
    report["reaped_child_cpu_seconds"] = now_child.ru_utime + now_child.ru_stime - child0.ru_utime - child0.ru_stime
    report["nested_phase_and_task_windows_not_additive"] = True
    report["final_complete_pack_not_in_above_window"] = True
    report["complete_end_to_end_cost_established"] = False
    report["finished_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()

assert report["status"] == "three_original_phases_completed"
pack_started = time.monotonic()
pack_cpu0 = resource.getrusage(resource.RUSAGE_SELF)
with (delivery / "WORKER_RESULT.json").open("xb") as stream:
    stream.write(read_bound(out / "WORKER_RESULT.json"))
members = {}
for path in sorted(out.rglob("*")):
    assert not path.is_symlink()
    if path.is_file():
        members["orchestration/" + str(path.relative_to(out))] = read_bound(path, 8 * 1024 * 1024)
for name in ["RESULT.json", "RAW_EVIDENCE_MANIFEST.json", "raw-evidence.tar.gz"]:
    members["original-delivery/" + name] = read_bound(delivery / name, 16 * 1024 * 1024)
assert sum(map(len, members.values())) < 16 * 1024 * 1024
manifest = {"schema": "hepta.repo-mdv.M6-complete-package-manifest.v1",
            "files": [{"path": name, "bytes": len(raw), "sha256": sha(raw)} for name, raw in sorted(members.items())]}
with (delivery / "COMPLETE_MANIFEST.json").open("x") as stream:
    stream.write(json.dumps(manifest, indent=2) + "\n")
complete = delivery / "complete-evidence.tar.gz"
with complete.open("xb") as file:
    with gzip.GzipFile(filename="", fileobj=file, mode="wb", mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w|", format=tarfile.PAX_FORMAT) as tar:
            for name, raw in sorted(members.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(raw), 0o600, 0
                tar.addfile(item, io.BytesIO(raw))
    file.flush(); os.fsync(file.fileno())
with tarfile.open(complete, "r:gz") as tar:
    actual = tar.getmembers()
    assert len(actual) == len(members) == len({x.name for x in actual})
    for item in actual:
        assert item.isfile() and tar.extractfile(item).read() == members[item.name]
pack_cpu1 = resource.getrusage(resource.RUSAGE_SELF)
final = {"schema": "hepta.repo-mdv.M6-complete-delivery.v1",
         "driver_head": head, "driver_tree": tree,
         "status": "original_phases_and_complete_archive_verified",
         "scientific_status": "HOLD", "production_status": "production_not_adopted",
         "confirmation_tasks": 0, "complete_package": file_pin(complete),
         "complete_package_members": len(members),
         "complete_manifest": file_pin(delivery / "COMPLETE_MANIFEST.json"),
         "original_summary": file_pin(delivery / "RESULT.json"),
         "original_raw_package": file_pin(delivery / "raw-evidence.tar.gz"),
         "worker_result": file_pin(delivery / "WORKER_RESULT.json"),
         "complete_pack_wall_seconds": time.monotonic() - pack_started,
         "complete_pack_worker_cpu_seconds": pack_cpu1.ru_utime + pack_cpu1.ru_stime - pack_cpu0.ru_utime - pack_cpu0.ru_stime,
         "complete_end_to_end_cost_established": False,
         "h_job_terminal_requires_separate_readback": True}
with (delivery / "DELIVERY.json").open("x") as stream:
    stream.write(json.dumps(final, indent=2) + "\n")
print(json.dumps(final, indent=2), flush=True)
