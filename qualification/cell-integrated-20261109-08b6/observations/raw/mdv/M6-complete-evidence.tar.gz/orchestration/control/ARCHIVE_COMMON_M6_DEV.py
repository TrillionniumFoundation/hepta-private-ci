"""Seal the completed common-source development run; never starts a test."""

from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import resource
import stat
import subprocess
import sys
import tarfile
import time

ROOT = Path('/home/qian-qi/work/cell-repo-mdv-20261109-08b6-evidence')
E = ROOT / 'common-M6-delivery-001'
W = Path('/home/qian-qi/work/cell-repo-mdv-common-M6-20261109-08b6')
HEAD = '885dae0f3285267e9e9c49d8b43b0d009779f9e8'
TREE = '293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb'
payload = json.load(sys.stdin)
started = time.monotonic()
cpu0 = resource.getrusage(resource.RUSAGE_CHILDREN)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=W, timeout=30).decode()

assert git('rev-parse', 'HEAD', 'HEAD^{tree}').splitlines() == [HEAD, TREE]
assert git('status', '--porcelain=v1') == ''
E.mkdir(parents=True, exist_ok=False)
files = {}
for directory in ['common-M6-setup-001', 'common-M6-campaign-001']:
    root = ROOT / directory
    assert root.is_dir() and not root.is_symlink()
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink()
        if path.is_dir():
            continue
        info = path.stat()
        assert stat.S_ISREG(info.st_mode) and info.st_size <= 8 * 1024 * 1024
        raw = path.read_bytes()
        assert len(raw) == info.st_size
        files[str(path.relative_to(ROOT))] = raw
assert sum(map(len, files.values())) < 16 * 1024 * 1024
for name, row in payload.items():
    assert '/' not in name and '..' not in name
    raw = row['text'].encode()
    assert len(raw) <= 1024 * 1024 and sha(raw) == row['sha256']
    files['execution-profile/' + name] = raw

setup = json.loads(files['common-M6-setup-001/RESULT.json'])
run = json.loads(files['common-M6-campaign-001/RESULT.json'])
assert setup['head'] == HEAD and setup['tree'] == TREE
assert run['driver'] == run['driver_after'] == HEAD
assert run['driver_tree'] == run['driver_tree_after'] == TREE
assert run['driver_source_unchanged']
assert run['status'] == 'two_actual_development_tasks_completed_with_verified_private_state_consumption'
first, second = run['tasks']
assert first['terminal'] == second['terminal'] == 'proved'
assert first['training_updates_consumed'] == 1 and second['training_updates_consumed'] == 0
assert first['state_after_digest'] == second['state_before_digest'] == second['state_after_digest']
state = json.loads(files['common-M6-campaign-001/task1/state.json'])
assert state['production_update'] == 'not_requested' and state['updates'] == 1
assert sha(files['common-M6-campaign-001/task1/state.json']) == second['released_checkpoint']['file_sha256']
assert all(not task['baseline_executed'] for task in [first, second])
assert '33 passed, 0 skipped' in files['common-M6-campaign-001/task2/tool-02.stderr'].decode()
for relative, pin in run['driver_files'].items():
    assert sha((W / relative).read_bytes()) == pin['sha256'] == run['driver_file_pins_after'][relative]
assert not run['scientific_qualified'] and not run['production_qualified']
assert run['formal_adoption_receipt'] is None and run['independent_task_count'] == 0
assert len(run['font_cleanup']) == 4 and all(x['removed_after_pin_check'] for x in run['font_cleanup'])

manifest = {'schema': 'hepta.repo-mdv.common-M6-evidence-manifest.v1',
            'files': [{'path': name, 'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(files.items())]}
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
(E / 'RAW_EVIDENCE_MANIFEST.json').write_bytes(manifest_raw)
archive = E / 'raw-evidence.tar.gz'
with archive.open('xb') as output:
    with gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0) as compressed:
        with tarfile.open(mode='w|', fileobj=compressed, format=tarfile.PAX_FORMAT) as tar:
            for name, raw in sorted(files.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(raw), 0o600, 0
                tar.addfile(entry, io.BytesIO(raw))
    output.flush()
    os.fsync(output.fileno())
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len({member.name for member in members}) == len(files)
    for member in members:
        assert member.isfile() and tar.extractfile(member).read() == files[member.name]
assert git('rev-parse', 'HEAD', 'HEAD^{tree}').splitlines() == [HEAD, TREE]
assert git('status', '--porcelain=v1') == ''
now = resource.getrusage(resource.RUSAGE_CHILDREN)
summary = {
    'schema': 'hepta.repo-mdv.common-M6-result.v1',
    'driver_head': HEAD, 'driver_tree': TREE, 'driver_source_unchanged': True,
    'driver_scope': 'actual common-candidate Python MDV driver and supervisor/meter; 9 direct source files bound before/after',
    'historical_task_sources': {'task1_before': run['source_R'], 'task1_after': 'R HEAD with exactly the known one-line S repair; raw file pins and dirty status retained', 'task2': run['source_S']},
    'ui_test_scope': '33 passed/0 skipped on historical S task source, not common M6 UI package tests',
    'common_project_full_archive_checked_by_this_package': False,
    'outcome': 'two exposed development tasks completed and one verified private-state update consumed by the second process',
    'natural_independent_confirmation_tasks': 0,
    'development_logical_tasks': 2, 'development_attempts': 2, 'exposed_root_families': 1,
    'training_updates': 1, 'followup_additional_training_updates': 0,
    'checkpoint': second['released_checkpoint'],
    'state_marker': state['production_update'],
    'selected_document': second['selected_document'],
    'learned_association': second['ranking'][0]['learned_association'],
    'baseline_executed': False, 'ranking_order_changed': second['ranking_order_changed'],
    'selected_document_changed': second['selected_document_changed'],
    'scientific_status': 'HOLD', 'learning_gain_established': False,
    'production_status': 'production_not_adopted', 'formal_adoption_receipt': None,
    'cache_mode': run['cache_mode'], 'cache_history_note': 'own target previously used by a51, M3, M4 and M5; warm, no performance comparison', 'python': run['python'], 'runtime_tools': run['runtime_tools'],
    'costs': {
        'setup_wall_seconds': setup['wall_seconds'], 'setup_reaped_child_cpu_seconds': setup['reaped_child_cpu_seconds'],
        'campaign_wall_seconds': run['observed_campaign_wall_seconds'], 'campaign_reaped_child_cpu_seconds': run['observed_reaped_child_cpu_seconds'],
        'known_nonoverlapping_setup_plus_campaign_wall_seconds': setup['wall_seconds'] + run['observed_campaign_wall_seconds'],
        'known_nonoverlapping_setup_plus_campaign_reaped_child_cpu_seconds': setup['reaped_child_cpu_seconds'] + run['observed_reaped_child_cpu_seconds'],
        'nested_task_tool_windows_not_additive': True,
        'complete_end_to_end_cost_established': False,
        'outer_controller_cpu_seconds': None, 'peak_memory_bytes': None, 'energy_joules': None, 'financial_cost': None,
        'prior_preparation_failures_recovery_and_transfer_not_included': True,
        'cross_head_performance_comparison_admitted': False},
    'raw_result': {'path': str(ROOT / 'common-M6-campaign-001/RESULT.json'), 'sha256': sha(files['common-M6-campaign-001/RESULT.json']), 'bytes': len(files['common-M6-campaign-001/RESULT.json'])},
    'profile_sha256': sha(files['execution-profile/COMMON_M6_LAUNCH_PROFILE.json']),
    'archive': {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'members': len(files)},
    'manifest': {'path': str(E / 'RAW_EVIDENCE_MANIFEST.json'), 'bytes': len(manifest_raw), 'sha256': sha(manifest_raw)},
    'packaging_window_wall_seconds': time.monotonic() - started,
    'packaging_reaped_child_cpu_seconds': now.ru_utime + now.ru_stime - cpu0.ru_utime - cpu0.ru_stime}
(E / 'RESULT.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
