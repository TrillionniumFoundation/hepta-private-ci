"""Complete only the failed development follow-up; retain its original attempt."""

from pathlib import Path
import datetime
import hashlib
import json
import os
import resource
import subprocess
import sys
import time

sys.dont_write_bytecode = True
W = Path('/home/qian-qi/work/cell-repo-mdv-20261109-08b6')
OLD = Path('/home/qian-qi/work/cell-repo-mdv-20261109-08b6-evidence/dev-campaign-001')
E = OLD.parent / 'dev-followup-recovery-001'
SW = Path('/home/qian-qi/work/cell-repo-mdv-task-S-20261109-08b6')
CACHE = Path('/home/qian-qi/work/cell-ui-ime-20261108-08b6-evidence/runtime-assets')
DRIVER = 'a51bac8b4fcb52dff626b172f62d2fae3a2202ea'
S = '693a013b254d07779f6f2b2a78d0ee31481f4ea9'
fontroot = 'apps/hepta-control-ui/rust/robrix-ui/resources/fonts'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*args, cwd=W):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True, timeout=30)

assert git('rev-parse', 'HEAD').strip() == DRIVER
assert git('status', '--porcelain=v1') == ''
assert git('rev-parse', 'HEAD', cwd=SW).strip() == S
assert git('status', '--porcelain=v1', cwd=SW) == ''
assert not E.exists()
E.mkdir()
(E / 'inputs').mkdir()
sys.path.insert(0, str(W / 'scripts'))
from ndu_real_runtime.subprocess_supervisor import run_logged

started = time.monotonic()
cpu0 = resource.getrusage(resource.RUSAGE_CHILDREN)
task1 = json.loads((OLD / 'task1/result.json').read_text())
original_task = json.loads((OLD / 'inputs/task2.json').read_text())
original_result = json.loads((OLD / 'task2/result.json').read_text())
assert task1['terminal'] == 'proved' and task1['training_updates_consumed'] == 1
assert original_result['terminal'] == 'refuted'
assert original_result['state_updates_before'] == 1
assert original_result['state_updated'] is False
for relative, pin in json.loads((OLD / 'RESULT.json').read_text())['driver_files'].items():
    assert sha((W / relative).read_bytes()) == pin['sha256']
env = dict(os.environ)
env.update(original_task['environment'])
report = {
    'schema': 'hepta.repo-mdv.native-dev-recovery.v1',
    'status': 'started',
    'driver': DRIVER,
    'driver_tree': git('rev-parse', 'HEAD^{tree}').strip(),
    'source_task': S,
    'scope': 'same exposed development follow-up, second attempt; not another independent task',
    'recovery_of': {
        'campaign_job': '1a1be2f14bd-138b0-907',
        'task_result_path': str(OLD / 'task2/result.json'),
        'task_result_sha256': sha((OLD / 'task2/result.json').read_bytes()),
        'reason': 'just runs its recipe under codex-rs; relative manifest input did not exist there',
        'change': 'absolute manifest path in recipes; new attempt identifier; same query/corpus/state/source',
    },
    'original_task1_result_sha256': sha((OLD / 'task1/result.json').read_bytes()),
    'original_state_sha256': sha((OLD / 'task1/state.json').read_bytes()),
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'python': sys.version,
    'steps': [],
    'scientific_qualified': False,
    'production_qualified': False,
    'formal_adoption_receipt': None,
    'independent_task_count': 0,
    'independent_benefit': None,
    'cache_mode': 'same own target after initial Clippy; global compiler/Cargo caches may also be warm',
    'complete_end_to_end_cost_established': False,
}

def save():
    (E / 'RESULT.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

def run(name, argv, cwd, timeout):
    t = time.monotonic()
    c = resource.getrusage(resource.RUSAGE_CHILDREN)
    with (E / (name + '.stdout')).open('xb') as out, (E / (name + '.stderr')).open('xb') as err:
        old = Path.cwd()
        os.chdir(cwd)
        try:
            result = run_logged(argv, stdout=out, stderr=err, timeout=timeout, env=env)
        finally:
            os.chdir(old)
    now = resource.getrusage(resource.RUSAGE_CHILDREN)
    row = {'name': name, 'argv': argv, 'cwd': str(cwd), 'wall_seconds': time.monotonic() - t,
           'child_cpu_seconds': now.ru_utime + now.ru_stime - c.ru_utime - c.ru_stime,
           'supervision': result}
    for stream in ('stdout', 'stderr'):
        raw = (E / (name + '.' + stream)).read_bytes()
        row[stream] = {'path': name + '.' + stream, 'bytes': len(raw), 'sha256': sha(raw)}
    report['steps'].append(row)
    save()
    print(json.dumps({'name': name, 'exit': result['returncode'], 'error': result['error']}), flush=True)
    return result

fonts = {k: v for k, v in original_task['source']['before_pins'].items() if k.startswith(fontroot + '/')}
try:
    r = run('fonts', [sys.executable, 'apps/hepta-control-ui/tools/prepare-fonts.py', '--cache', str(CACHE),
                      '--offline', '--install', str(SW / fontroot)], SW, 120)
    assert r['returncode'] == 0 and r['error'] is None and r['cleanup_complete']
    for p, digest in fonts.items():
        assert sha((SW / p).read_bytes()) == digest
    task = json.loads(json.dumps(original_task))
    task['task_id'] = 'repo-dev/003-native-ui-followup-recovery'
    for recipe in task['recipes'].values():
        for step in recipe:
            argv = step['argv']
            if argv[:2] == ['just', 'test']:
                pos = argv.index('--manifest-path') + 1
                assert argv[pos] == 'apps/hepta-control-ui/rust/Cargo.toml'
                argv[pos] = str(SW / argv[pos])
    (E / 'inputs/task.json').write_text(json.dumps(task, indent=2) + '\n')
    (E / 'inputs/corpus.json').write_bytes((OLD / 'inputs/corpus.json').read_bytes())
    report['input_files'] = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                             for p in sorted((E / 'inputs').iterdir())}
    save()
    (E / 'PRE_EXECUTION.json').write_text(json.dumps(report, indent=2) + '\n')
    argv = [sys.executable, '-B', '-m', 'cell_repo_mdv.runner', '--task', str(E / 'inputs/task.json'),
            '--corpus', str(E / 'inputs/corpus.json'), '--state', str(OLD / 'task1/state.json'),
            '--state-receipt', str(OLD / 'task1/result.json'), '--output', str(E / 'task')]
    r = run('task', argv, W, 1000)
    if (E / 'task/result.json').exists():
        report['task_result'] = json.loads((E / 'task/result.json').read_text())
    save()
    assert r['returncode'] == 0 and r['error'] is None and r['cleanup_complete']
    result = report['task_result']
    assert result['terminal'] == 'proved'
    assert result['state_before_digest'] == task1['state_after_digest']
    assert result['state_updates_before'] == 1 and result['training_updates_consumed'] == 0
    assert result['state_after_digest'] == result['state_before_digest']
    report['status'] = 'same_development_followup_completed_using_original_verified_update'
except Exception as error:
    report['status'] = 'development_recovery_incomplete'
    report['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    report['font_cleanup'] = []
    for relative, digest in fonts.items():
        path = SW / relative
        if path.is_file() and sha(path.read_bytes()) == digest:
            path.unlink()
            report['font_cleanup'].append({'path': str(path), 'removed_after_pin_check': True})
    report['driver_after'] = git('rev-parse', 'HEAD').strip()
    report['driver_status_after'] = git('status', '--porcelain=v1')
    report['task_status_after'] = git('status', '--porcelain=v1', cwd=SW)
    now = resource.getrusage(resource.RUSAGE_CHILDREN)
    report['observed_recovery_wall_seconds'] = time.monotonic() - started
    report['observed_reaped_child_cpu_seconds'] = now.ru_utime + now.ru_stime - cpu0.ru_utime - cpu0.ru_stime
    report['nested_costs_not_additive'] = True
    report['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({k: v for k, v in report.items() if k not in ['task_result', 'steps']}, indent=2), flush=True)
