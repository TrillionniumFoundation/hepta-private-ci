from pathlib import Path
import hashlib,json,os,subprocess,sys,time,resource
W=Path('/home/qian-qi/work/cell-repo-mdv-20261109-08b6')
E=Path('/home/qian-qi/work/cell-repo-mdv-20261109-08b6-evidence/implementation-001')
S='693a013b254d07779f6f2b2a78d0ee31481f4ea9'
payload=json.load(sys.stdin)
expected={'scripts/cell_repo_mdv/'+n for n in ['__init__.py','contracts.py','memory.py','runner.py','test_memory.py','test_runner.py']}
assert set(payload)==expected
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==S
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=W,text=True)==''
E.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(W/'scripts'))
from ndu_real_runtime.subprocess_supervisor import run_logged
started=time.monotonic()
report={'scope':'S-based isolated development implementation, not confirmation or production adoption','base':S,'source':str(W),'steps':[],'commits':[]}
def save():
 (E/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,argv,cwd=W,timeout=600):
 t=time.monotonic();cpu=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (E/(name+'.stdout')).open('xb') as out,(E/(name+'.stderr')).open('xb') as err:
  old=Path.cwd();os.chdir(cwd)
  try:r=run_logged(argv,stdout=out,stderr=err,timeout=timeout,env=env)
  finally:os.chdir(old)
 now=resource.getrusage(resource.RUSAGE_CHILDREN)
 row={'name':name,'argv':argv,'cwd':str(cwd),'wall_seconds':time.monotonic()-t,'child_cpu_seconds':now.ru_utime+now.ru_stime-cpu.ru_utime-cpu.ru_stime,'supervision':r}
 report['steps'].append(row);save();print(json.dumps({'name':name,'exit':r['returncode'],'error':r['error']}),flush=True)
 assert r['returncode']==0 and r['error'] is None and r['cleanup_complete'],name
 return (E/(name+'.stdout')).read_text()
env=dict(os.environ)
env['PATH']='/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/work/cell-dependency-pin-20261108-08b6-evidence/tools/bin:/home/qian-qi/.local/bin:/home/qian-qi/.cargo/bin:'+env.get('PATH','')
env['PYTHONDONTWRITEBYTECODE']='1'
env['PYTHONPATH']=str(W/'scripts')
report['python']=sys.version
for name,row in payload.items():
 raw=row['content'].encode()
 assert hashlib.sha256(raw).hexdigest()==row['sha256']
 p=W/name;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(raw)
report['transferred']={name:row['sha256'] for name,row in payload.items()};save()
run('just-fmt',['/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin/just','fmt'],W/'codex-rs')
assert subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True)=='','formatter modified baseline tracked source'
actual=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines()
assert set(actual)==expected,actual
groups=[(['__init__.py','contracts.py','memory.py'],'feat(research): add bounded development retrieval state'),(['runner.py'],'feat(research): execute real repository development recipes'),(['test_memory.py','test_runner.py'],'test(research): bind memory updates to verified task outcomes')]
for index,(names,message) in enumerate(groups):
 paths=['scripts/cell_repo_mdv/'+name for name in names]
 run('stage-'+str(index),['git','add','--',*paths])
 changes=subprocess.check_output(['git','diff','--cached','--numstat'],cwd=W,text=True).splitlines()
 count=sum(int(row.split()[0])+int(row.split()[1]) for row in changes)
 assert count<500,(paths,count)
 run('diff-check-'+str(index),['git','diff','--cached','--check'])
 run('commit-'+str(index),['git','commit','-m',message])
 report['commits'].append({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=W,text=True).strip(),'changed_lines':count,'paths':paths});save()
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=W,text=True)==''
report['tested_head']=report['commits'][-1]['head'];report['tested_tree']=report['commits'][-1]['tree']
report['formatted_source']={name:{'sha256':hashlib.sha256((W/name).read_bytes()).hexdigest(),'bytes':(W/name).stat().st_size,'lines':len((W/name).read_text().splitlines())} for name in sorted(expected)};save()
run('native-controls',[sys.executable,'-B','-m','unittest','cell_repo_mdv.test_memory','cell_repo_mdv.test_runner','-v'],timeout=120)
report['status_after']=subprocess.check_output(['git','status','--porcelain=v1'],cwd=W,text=True)
assert report['status_after']==''
report['toolchain_readonly']=[]
for argv in [['du','-sk','/home/qian-qi/work/cell-integration-20261108-08b6/clippy-target'],['df','-Pk',str(W)],['stat','-f','-c','%T',str(W)]]:
 p=subprocess.run(argv,cwd=W,capture_output=True,text=True,timeout=30)
 report['toolchain_readonly'].append({'argv':argv,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});save()
report['total_wall_seconds']=time.monotonic()-started;report['complete']=True;save()
print(json.dumps(report,indent=2),flush=True)
