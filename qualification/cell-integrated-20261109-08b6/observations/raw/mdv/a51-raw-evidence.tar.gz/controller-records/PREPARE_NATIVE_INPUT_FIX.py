"""Freeze the bounded-open and non-authority marker revision after a51 dev ends."""

from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import sys
import time

sys.dont_write_bytecode = True
W = Path('/home/qian-qi/work/cell-repo-mdv-20261109-08b6')
E = Path('/home/qian-qi/work/cell-repo-mdv-20261109-08b6-evidence/implementation-003')
OLD = 'a51bac8b4fcb52dff626b172f62d2fae3a2202ea'
payload = json.load(sys.stdin)
expected = {'scripts/cell_repo_mdv/' + name for name in ('contracts.py', 'memory.py', 'test_memory.py')}
assert set(payload) == expected

def git(*args):
    return subprocess.check_output(['git', *args], cwd=W, text=True, timeout=30)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

assert git('rev-parse', 'HEAD').strip() == OLD
assert git('status', '--porcelain=v1') == ''
recovery = json.loads((E.parent / 'dev-followup-recovery-001/RESULT.json').read_text())
assert recovery['status'] == 'same_development_followup_completed_using_original_verified_update'
assert recovery['driver_after'] == OLD and recovery['driver_status_after'] == ''
E.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(W / 'scripts'))
from ndu_real_runtime.subprocess_supervisor import run_logged

started = time.monotonic()
cpu0 = resource.getrusage(resource.RUSAGE_CHILDREN)
env = dict(os.environ)
env['PATH'] = '/home/qian-qi/work/cell-rsi-p0p2-20261108-858e/tools/uv-0.11.3:/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/bin:/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/.local/bin:/home/qian-qi/.cargo/bin:' + env.get('PATH', '')
env.update({'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(W / 'scripts')})
report = {'schema': 'hepta.repo-mdv.input-fix-validation.v1', 'scope': 'engineering controls only; a51 real development remains separately pinned',
          'source': str(W), 'before': {'head': OLD, 'tree': git('rev-parse', 'HEAD^{tree}').strip(), 'status': ''},
          'python': sys.version, 'steps': [], 'scientific_qualified': False, 'production_qualified': False,
          'prior_checkpoint_migration': 'none; archived a51 state is unchanged and is not valid for the new non-authority marker'}

def save():
    (E / 'RESULT.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')

def run(name, argv, cwd=W, timeout=120):
    t = time.monotonic()
    cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
    with (E / (name + '.stdout')).open('xb') as out, (E / (name + '.stderr')).open('xb') as err:
        old = Path.cwd()
        os.chdir(cwd)
        try:
            result = run_logged(argv, stdout=out, stderr=err, timeout=timeout, env=env)
        finally:
            os.chdir(old)
    now = resource.getrusage(resource.RUSAGE_CHILDREN)
    row = {'name': name, 'argv': argv, 'cwd': str(cwd), 'wall_seconds': time.monotonic() - t,
           'child_cpu_seconds': now.ru_utime + now.ru_stime - cpu.ru_utime - cpu.ru_stime, 'supervision': result}
    for stream in ('stdout', 'stderr'):
        raw = (E / (name + '.' + stream)).read_bytes()
        row[stream] = {'bytes': len(raw), 'sha256': sha(raw), 'path': name + '.' + stream}
    report['steps'].append(row)
    save()
    print(json.dumps({'name': name, 'exit': result['returncode'], 'error': result['error']}), flush=True)
    assert result['returncode'] == 0 and result['error'] is None and result['cleanup_complete'], name

try:
    for relative, row in payload.items():
        raw = row['content'].encode()
        assert sha((W / relative).read_bytes()) == row['before_sha256']
        assert sha(raw) == row['after_sha256']
    report['inputs'] = {name: {k: v for k, v in row.items() if k != 'content'} for name, row in payload.items()}
    save()
    for relative, row in payload.items():
        (W / relative).write_text(row['content'])
    run('just-fmt', ['/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin/just', 'fmt'], W / 'codex-rs', 600)
    assert set(git('diff', '--name-only').splitlines()) == expected
    assert git('ls-files', '--others', '--exclude-standard') == ''
    run('stage', ['git', 'add', '--', *sorted(expected)])
    lines = sum(int(r.split()[0]) + int(r.split()[1]) for r in git('diff', '--cached', '--numstat').splitlines())
    assert lines < 100
    report['changed_lines'] = lines
    (E / 'change.patch').write_text(git('diff', '--cached', '--no-ext-diff'))
    run('diff-check', ['git', 'diff', '--cached', '--check'])
    run('commit', ['git', 'commit', '-m', 'fix(research): bound special-file opens and clarify private state'])
    report['tested_head'] = git('rev-parse', 'HEAD').strip()
    report['tested_tree'] = git('rev-parse', 'HEAD^{tree}').strip()
    assert git('status', '--porcelain=v1') == ''
    report['source_files'] = {str(p.relative_to(W)): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                              for p in sorted((W / 'scripts/cell_repo_mdv').glob('*.py'))}
    save()
    run('native-controls', [sys.executable, '-B', '-m', 'unittest', 'cell_repo_mdv.test_memory', 'cell_repo_mdv.test_runner', '-v'])
    report['after'] = {'head': git('rev-parse', 'HEAD').strip(), 'tree': git('rev-parse', 'HEAD^{tree}').strip(), 'status': git('status', '--porcelain=v1')}
    assert report['after'] == {'head': report['tested_head'], 'tree': report['tested_tree'], 'status': ''}
    report['status'] = 'frozen_engineering_controls_passed'
except Exception as error:
    report['status'] = 'incomplete'
    report['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    now = resource.getrusage(resource.RUSAGE_CHILDREN)
    report['observed_window_wall_seconds'] = time.monotonic() - started
    report['observed_reaped_child_cpu_seconds'] = now.ru_utime + now.ru_stime - cpu0.ru_utime - cpu0.ru_stime
    report['nested_costs_not_additive'] = True
    save()
    print(json.dumps({k: v for k, v in report.items() if k != 'steps'}, indent=2), flush=True)
