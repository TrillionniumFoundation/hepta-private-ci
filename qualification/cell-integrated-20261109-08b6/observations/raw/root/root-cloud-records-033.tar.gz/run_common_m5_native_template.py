from pathlib import Path
import subprocess,json,datetime,hashlib,time,resource,os
root=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
out=root/'common-M5-native-gates-023';out.mkdir(exist_ok=False)
work=root/'integration-source'
S='693a013b254d07779f6f2b2a78d0ee31481f4ea9';H='81da60b349e32d89d0e4c4674a517a66af7e5eee'
env=os.environ.copy()
env.update({'PATH':'/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/work/cell-dependency-pin-20261108-08b6-evidence/tools/bin:/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/.local/bin:/home/qian-qi/.cargo/bin:'+'/home/qian-qi/work/cell-rsi-p0p2-20261108-858e/tools/uv-0.11.3:/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/bin:'+env.get('PATH',''),'RUSTUP_TOOLCHAIN':'1.96.0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/qian-qi/work/cell-continuation-lifecycle-20261109-08b6/target','CARGO_TERM_COLOR':'never','PYTHONDONTWRITEBYTECODE':'1'})
records=[]
def run(name,argv,cwd,expected=0,timeout=600):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.perf_counter();cpu=resource.getrusage(resource.RUSAGE_CHILDREN);failure=None
 (out/(name+'.intent.json')).write_text(json.dumps({'argv':argv,'cwd':str(cwd),'started_at_utc':start})+'\n')
 with (out/(name+'.stdout')).open('wb') as so,(out/(name+'.stderr')).open('wb') as se:
  try:r=subprocess.run(argv,cwd=cwd,env=env,stdout=so,stderr=se,timeout=timeout);rc=r.returncode
  except BaseException as e:rc=None;failure=repr(e)
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 rec={'name':name,'argv':argv,'cwd':str(cwd),'exit':rc,'failure':failure,'wall_seconds':time.perf_counter()-t,'child_cpu_seconds':after.ru_utime+after.ru_stime-cpu.ru_utime-cpu.ru_stime,'started_at_utc':start,'ended_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 for stream in ['stdout','stderr']:
  p=out/(name+'.'+stream);b=p.read_bytes();rec[stream]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 records.append(rec);(out/'STEPS.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
 assert failure is None,(name,failure)
 if expected is not None:assert rc==expected,(name,rc)
 return rc



import sys,tarfile,stat
fixture_manifest=json.load(sys.stdin)
M='__M5_SOURCE__';T='__M5_TREE__'
canonical=(work/'codex-rs/Cargo.lock').read_bytes()
assert hashlib.sha256(canonical).hexdigest()=='48b55c7ff5c23516fd0aeedca7c10a6e7902aeb5dc49fa4cef80971e1ae57d3f'
run('head-before',['git','rev-parse','HEAD','HEAD^{tree}'],work)
assert (out/'head-before.stdout').read_text().splitlines()==[M,T]
run('status-before',['git','status','--porcelain=v1'],work);assert not (out/'status-before.stdout').read_text()
run('rustc-version',['rustc','-Vv'],work)
run('cargo-version',['cargo','-V'],work)
run('nextest-version',['cargo','nextest','--version'],work)
(out/'ENVIRONMENT.json').write_text(json.dumps({**{key:env.get(key) for key in ['PATH','RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','CARGO_TARGET_DIR','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']},'managed_memory_max_bytes':12884901888,'managed_cpu_quota_percent':200,'cache':'reused owned lifecycle target after authoritative completed M4 run'},indent=2)+'\n')
original=Path(fixture_manifest['original_archive'])
raw=original.read_bytes();assert hashlib.sha256(raw).hexdigest()==fixture_manifest['archive_sha256']
assert len(raw)==50640 and fixture_manifest['real_user_data'] is False
with tarfile.open(original,'r:gz') as archive:
 members=archive.getmembers()
 assert all(m.isdir() or m.isreg() for m in members)
 assert all(m.name.startswith('old-sdk018-fixture-v3') and '..' not in Path(m.name).parts and not Path(m.name).is_absolute() for m in members)
 archive.extractall(out/'fixture-copy',filter='data')
fixture=out/'fixture-copy/old-sdk018-fixture-v3'
actual={}
for p in fixture.rglob('*'):
 assert not p.is_symlink()
 if p.is_file():
  s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
  actual[str(p.relative_to(fixture))]={'bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
expected={p['path']:{'bytes':p['size'],'mode':p['mode'],'sha256':p['sha256']} for p in fixture_manifest['files']}
assert actual==expected and len(actual)==12
(out/'FIXTURE_BEFORE.json').write_text(json.dumps({'original_archive_sha256':fixture_manifest['archive_sha256'],'copied_root':str(fixture),'files':actual,'copy_complete_before_any_database_open':True},indent=2)+'\n')
gates={}
gates['fmt-check']=run('fmt-check',['just','fmt-check'],work,expected=None,timeout=600)
gates['scoped-clippy-fix']=run('scoped-clippy-fix',['just','fix','-p','codex-hepta-infer-core','-p','codex-hepta-automation','-p','codex-hepta-agentd','--locked','--offline'],work/'codex-rs',expected=None,timeout=1800)
run('status-after-clippy',['git','status','--porcelain=v1'],work);assert not (out/'status-after-clippy.stdout').read_text()
gates['scoped-strict-clippy']=run('scoped-strict-clippy',['just','clippy','-p','codex-hepta-infer-core','-p','codex-hepta-automation','-p','codex-hepta-agentd','--locked','--offline','--','-D','warnings'],work/'codex-rs',expected=None,timeout=1800)
base=['just','test','--locked','--offline','--retries','0']
specs=[
 ('infer-core-package',base+['-p','codex-hepta-infer-core','--lib']),
 ('infer-core-history-measurement',base+['-p','codex-hepta-infer-core','--lib','--run-ignored','only','--success-output','immediate']),
 ('automation-package',base+['-p','codex-hepta-automation']),
 ('agentd-lifecycle-scope',base+['-p','codex-hepta-agentd','--lib','-E','test(learning_iteration) | test(circuit_task) | test(objective_)']),
 ('matrix-shared-graph',base+['-p','codex-hepta-matrix-sdk','-p','codex-network-proxy','-p','codex-execpolicy','-p','codex-aws-auth']),
]
for name,argv in specs:
 gates[name]=run(name,argv,work/'codex-rs',expected=None,timeout=2400)
 print(json.dumps({'gate':name,'stderr_tail':(out/(name+'.stderr')).read_text(errors='replace')[-2500:]}),flush=True)
env['HEPTA_MATRIX_MIGRATION_FIXTURE']=str(fixture)
gates['old018-to-new019-consumer']=run('old018-to-new019-consumer',base+['-p','codex-hepta-matrix-sdk','--test','store_version_migration','--run-ignored','only','-E','test(=reopen_old_version_fixture)'],work/'codex-rs',expected=None,timeout=600)
print((out/'old018-to-new019-consumer.stderr').read_text()[-4500:],flush=True)
assert hashlib.sha256(original.read_bytes()).hexdigest()==fixture_manifest['archive_sha256']
after_fixture={str(p.relative_to(fixture)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(fixture.rglob('*')) if p.is_file()}
(out/'FIXTURE_AFTER.json').write_text(json.dumps(after_fixture,indent=2)+'\n')
run('head-after',['git','rev-parse','HEAD','HEAD^{tree}'],work)
run('status-after',['git','status','--porcelain=v1'],work)
assert (out/'head-before.stdout').read_bytes()==(out/'head-after.stdout').read_bytes()
assert not (out/'status-after.stdout').read_text()
assert (work/'codex-rs/Cargo.lock').read_bytes()==canonical
summary={'source':[M,T],'gates':gates,'automatic_test_retries':0,'target_reused_warm':env['CARGO_TARGET_DIR'],'fixture_original_unchanged':True,'fixture_initial_files':actual,'consumer_copy':str(fixture),'steps':records,'scope':'Exact common M5 engineering gates; ignored and unselected tests remain separate; includes real original SDK0.18 encrypted-store consumer; no production adoption or scientific benefit claim'}
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'source':summary['source'],'gates':gates}),flush=True)
raise SystemExit(0 if all(v==0 for v in gates.values()) else 1)
