from pathlib import Path
import subprocess,json,datetime,hashlib,time,resource,os
root=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
out=root/'integration-freeze-006';out.mkdir(exist_ok=False)
work=root/'integration-source'
S='693a013b254d07779f6f2b2a78d0ee31481f4ea9';H='81da60b349e32d89d0e4c4674a517a66af7e5eee'
env=os.environ.copy()
env.update({'PATH':'/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/work/cell-dependency-pin-20261108-08b6-evidence/tools/bin:/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/.local/bin:/home/qian-qi/.cargo/bin:'+'/home/qian-qi/work/cell-rsi-p0p2-20261108-858e/tools/uv-0.11.3:/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/bin:'+env.get('PATH',''),'RUSTUP_TOOLCHAIN':'1.96.0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':str(root/'control-target'),'CARGO_TERM_COLOR':'never','PYTHONDONTWRITEBYTECODE':'1'})
records=[]
def run(name,argv,cwd,expected=0,timeout=600):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.perf_counter();cpu=resource.getrusage(resource.RUSAGE_CHILDREN);failure=None
 (out/(name+'.intent.json')).write_text(json.dumps({'argv':argv,'cwd':str(cwd),'started_at_utc':start})+'\n')
 with (out/(name+'.stdout')).open('wb') as so,(out/(name+'.stderr')).open('wb') as se:
  try:r=subprocess.run(argv,cwd=cwd,env=env,stdout=so,stderr=se,timeout=timeout);rc=r.returncode
  except BaseException as e:rc=None;failure=repr(e)
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 rec={'name':name,'argv':argv,'cwd':str(cwd),'exit':rc,'failure':failure,'wall_seconds':time.perf_counter()-t,'child_cpu_seconds':after.ru_utime+after.ru_stime-cpu.ru_utime-cpu.ru_stime,'started_at_utc':start,'ended_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 for stream in ['stdout','stderr']:
  p=out/(name+'.'+stream);b=p.read_bytes();rec[stream]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 records.append(rec);(out/'STEPS.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
 assert failure is None,(name,failure)
 if expected is not None:assert rc==expected,(name,rc)
 return rc




run('head-before',['git','rev-parse','HEAD','MERGE_HEAD'],work)
assert (out/'head-before.stdout').read_text().splitlines()==['293b7b18766ca604cda20aefbecd85f14d4f551b',H]
bridge=work/'scripts/ndu_real_runtime/training_job_result.py'
assert hashlib.sha256(bridge.read_bytes()).hexdigest()=='30e64e042634ed9b59d3c2a059d141d03219030c1d6bcdf8136230126f82df71'
env['PYTHONPATH']=str(work/'scripts')
command=['/usr/bin/python3','-B','-m','unittest','-v','ndu_real_runtime.test_training_job_result']
run('fmt-scoped-integration',['just','fmt','--base',H],work/'codex-rs',timeout=600)
run('diff-check',['git','diff','--check'],work)
run('stage-resolution',['git','add','--','scripts/ndu_real_runtime/pipeline.py','scripts/ndu_real_runtime/training_job_result.py','scripts/ndu_real_runtime/test_training_job_result.py','codex-rs/Cargo.toml','codex-rs/Cargo.lock','MODULE.bazel.lock'],work)
run('unresolved',['git','diff','--name-only','--diff-filter=U'],work)
assert not (out/'unresolved.stdout').read_text()
run('cached-check',['git','diff','--cached','--check'],work)
run('merge-commit',['git','commit','-m','merge: integrate frozen Cell sources with bounded training admission'],work,timeout=120)
run('merge-identity',['git','rev-parse','HEAD','HEAD^{tree}','HEAD^1','HEAD^2'],work)
merge=(out/'merge-identity.stdout').read_text().splitlines()
assert merge[2:]==['293b7b18766ca604cda20aefbecd85f14d4f551b',H]
run('format-commit-import',['git','cherry-pick','605acd5ee2f0db4bd4df9f475aa0206873bbe8ab'],work)
run('fmt',['just','fmt'],work/'codex-rs')
run('full-fmt-check',['just','fmt-check'],work,timeout=600)
run('frozen-head',['git','rev-parse','HEAD','HEAD^{tree}'],work)
run('frozen-status',['git','status','--porcelain=v1'],work)
assert not (out/'frozen-status.stdout').read_text()
rc=run('admission-green',command,work,timeout=120,expected=None)
print((out/'admission-green.stderr').read_text()[-16000:],flush=True)
assert rc==0
run('final-head',['git','rev-parse','HEAD','HEAD^{tree}'],work)
run('final-status',['git','status','--porcelain=v1'],work)
assert not (out/'final-status.stdout').read_text()
assert (out/'final-head.stdout').read_text()==(out/'frozen-head.stdout').read_text()
summary={'merge_identity':merge,'tested_identity':(out/'frozen-head.stdout').read_text().splitlines(),'tests':'actual pipeline/protocol controls only, not fitted weights or production authority','scope':'initial common merge, lifecycle/dev stages still pending','unresolved_original_jobs':['1a1be2dd555-138b0-902','1a1be32c644-138b0-91e'],'original_operation_rule':'Both original requests reconciled using unchanged keys; missing terminal stays UNKNOWN. Reviewed source changed using an immutable version guard, so both original old-source guards reject any late mutation. This distinct freeze validates the new byte identity; no red attempt claimed.','steps':records}
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'merge_identity':merge,'tested_identity':summary['tested_identity'],'state':'INITIAL_COMMON_MERGE_ADMISSION_PASSED'}),flush=True)

