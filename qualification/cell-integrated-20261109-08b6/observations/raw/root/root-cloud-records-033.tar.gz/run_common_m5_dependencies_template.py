from pathlib import Path
import subprocess,json,datetime,hashlib,time,resource,os
root=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
out=root/'common-M5-dependency-gates-025';out.mkdir(exist_ok=False)
work=root/'canonical-source'
S='693a013b254d07779f6f2b2a78d0ee31481f4ea9';H='81da60b349e32d89d0e4c4674a517a66af7e5eee'
env=os.environ.copy()
env.update({'PATH':'/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/work/cell-dependency-pin-20261108-08b6-evidence/tools/bin:/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/.local/bin:/home/qian-qi/.cargo/bin:'+'/home/qian-qi/work/cell-rsi-p0p2-20261108-858e/tools/uv-0.11.3:/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/bin:'+env.get('PATH',''),'RUSTUP_TOOLCHAIN':'1.96.0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/qian-qi/work/cell-continuation-lifecycle-20261109-08b6/target','CARGO_TERM_COLOR':'never','PYTHONDONTWRITEBYTECODE':'1'})
records=[]
def run(name,argv,cwd,expected=0,timeout=600):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.perf_counter();cpu=resource.getrusage(resource.RUSAGE_CHILDREN);failure=None
 (out/(name+'.intent.json')).write_text(json.dumps({'argv':argv,'cwd':str(cwd),'started_at_utc':start})+'\n')
 with (out/(name+'.stdout')).open('wb') as so,(out/(name+'.stderr')).open('wb') as se:
  try:r=subprocess.run(argv,cwd=cwd,env=env,stdout=so,stderr=se,timeout=timeout);rc=r.returncode
  except BaseException as e:rc=None;failure=repr(e)
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 rec={'name':name,'argv':argv,'cwd':str(cwd),'exit':rc,'failure':failure,'wall_seconds':time.perf_counter()-t,'child_cpu_seconds':after.ru_utime+after.ru_stime-cpu.ru_utime-cpu.ru_stime,'started_at_utc':start,'ended_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 for stream in ['stdout','stderr']:
  p=out/(name+'.'+stream);b=p.read_bytes();rec[stream]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 records.append(rec);(out/'STEPS.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
 assert failure is None,(name,failure)
 if expected is not None:assert rc==expected,(name,rc)
 return rc



import re,shutil
M='__M5_SOURCE__';T='__M5_TREE__'
run('head-before',['git','rev-parse','HEAD','HEAD^{tree}'],work)
assert (out/'head-before.stdout').read_text().splitlines()==[M,T]
run('status-before',['git','status','--porcelain=v1'],work);assert not (out/'status-before.stdout').read_text()
pins={}
for name in ['codex-rs/Cargo.toml','codex-rs/Cargo.lock','codex-rs/deny.toml','MODULE.bazel','MODULE.bazel.lock']:
 p=work/name;pins[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(out/'SOURCE_PINS.json').write_text(json.dumps(pins,indent=2)+'\n')
toolpins={}
for tool,args in [('cargo',['-Vv']),('cargo-deny',['--version']),('bazel',['--version'])]:
 p=Path(shutil.which(tool,path=env['PATH'])).resolve()
 run(tool+'-version',[str(p),*args],work,timeout=60)
 toolpins[tool]={'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'version':(out/(tool+'-version.stdout')).read_text().strip()}
(out/'TOOL_PINS.json').write_text(json.dumps(toolpins,indent=2)+'\n')
run('deny-check-help',['cargo','deny','check','--help'],work,timeout=60)
assert '--disable-fetch' in (out/'deny-check-help.stdout').read_text()
def db():
 return [{'path':str(p),'head':subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD^{tree}'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(p),'status','--porcelain'],text=True),'origin':subprocess.check_output(['git','-C',str(p),'remote','get-url','origin'],text=True).strip()} for p in sorted(Path('/home/qian-qi/.cargo/advisory-dbs').glob('advisory-db-*')) if (p/'.git').exists()]
before=db();assert before and all(not row['status'] for row in before)
(out/'ADVISORY_DB_BEFORE.json').write_text(json.dumps(before,indent=2)+'\n')
gates={}
gates['cargo-all-features-locked']=run('cargo-all-features-locked',['cargo','metadata','--format-version','1','--locked','--offline','--all-features'],work/'codex-rs',expected=None,timeout=300)
gates['bazel-lock-error']=run('bazel-lock-error',['bazel','--host_jvm_args=-Xmx1024m','mod','deps','--lockfile_mode=error'],work,expected=None,timeout=600)
gates['cargo-deny']=run('cargo-deny',['cargo','deny','--locked','--log-level','warn','--manifest-path','./codex-rs/Cargo.toml','--all-features','check','--disable-fetch'],work,expected=None,timeout=600)
after=db();(out/'ADVISORY_DB_AFTER.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
errors=re.findall(r'^error[^\n]*',(out/'cargo-deny.stderr').read_text(),re.MULTILINE)
advisories=sorted(set(re.findall(r'ID: (RUSTSEC-\d+-\d+)',(out/'cargo-deny.stderr').read_text())))
run('head-after',['git','rev-parse','HEAD','HEAD^{tree}'],work)
run('status-after',['git','status','--porcelain=v1'],work)
assert (out/'head-before.stdout').read_bytes()==(out/'head-after.stdout').read_bytes()
assert not (out/'status-after.stdout').read_text()
for name,pin in pins.items():assert hashlib.sha256((work/name).read_bytes()).hexdigest()==pin['sha256']
summary={'source':[M,T],'gates':gates,'source_pins':pins,'tools':toolpins,'advisory_db_before':before,'advisory_db_after':after,'error_headers':errors,'advisory_ids':advisories,'steps':records,'scope':'Exact M5 locked all-features metadata, Bazel error mode, and configured deny checks against the recorded unchanged advisory database; repository original ignores unchanged; no new security exception'}
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='steps'}),flush=True)
raise SystemExit(0 if all(v==0 for v in gates.values()) else 1)

