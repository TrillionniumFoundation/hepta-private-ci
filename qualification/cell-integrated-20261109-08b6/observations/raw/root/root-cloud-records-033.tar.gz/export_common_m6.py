from pathlib import Path
import subprocess,json,datetime,hashlib,time,resource,os
root=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
out=root/'source-export-028';out.mkdir(exist_ok=False)
work=root/'canonical-source'
S='693a013b254d07779f6f2b2a78d0ee31481f4ea9';H='81da60b349e32d89d0e4c4674a517a66af7e5eee'
env=os.environ.copy()
env.update({'PATH':'/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/work/cell-dependency-pin-20261108-08b6-evidence/tools/bin:/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/.local/bin:/home/qian-qi/.cargo/bin:'+'/home/qian-qi/work/cell-rsi-p0p2-20261108-858e/tools/uv-0.11.3:/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/bin:'+env.get('PATH',''),'RUSTUP_TOOLCHAIN':'1.96.0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/qian-qi/work/cell-continuation-lifecycle-20261109-08b6/target','CARGO_TERM_COLOR':'never','PYTHONDONTWRITEBYTECODE':'1'})
records=[]
def run(name,argv,cwd,expected=0,timeout=600):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.perf_counter();cpu=resource.getrusage(resource.RUSAGE_CHILDREN);failure=None
 (out/(name+'.intent.json')).write_text(json.dumps({'argv':argv,'cwd':str(cwd),'started_at_utc':start})+'\n')
 with (out/(name+'.stdout')).open('wb') as so,(out/(name+'.stderr')).open('wb') as se:
  try:r=subprocess.run(argv,cwd=cwd,env=env,stdout=so,stderr=se,timeout=timeout);rc=r.returncode
  except BaseException as e:rc=None;failure=repr(e)
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 rec={'name':name,'argv':argv,'cwd':str(cwd),'exit':rc,'failure':failure,'wall_seconds':time.perf_counter()-t,'child_cpu_seconds':after.ru_utime+after.ru_stime-cpu.ru_utime-cpu.ru_stime,'started_at_utc':start,'ended_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 for stream in ['stdout','stderr']:
  p=out/(name+'.'+stream);b=p.read_bytes();rec[stream]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 records.append(rec);(out/'STEPS.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
 assert failure is None,(name,failure)
 if expected is not None:assert rc==expected,(name,rc)
 return rc



M='885dae0f3285267e9e9c49d8b43b0d009779f9e8';T='293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb'
run('head',['git','rev-parse','HEAD','HEAD^{tree}'],work)
assert (out/'head.stdout').read_text().splitlines()==[M,T]
run('status',['git','status','--porcelain=v1'],work);assert not (out/'status.stdout').read_text()
bundle=out/'M6-over-S-H.bundle'
run('source-bundle',['git','bundle','create',str(bundle),'refs/heads/engineering/cell-integrated-20261109-08b6-canonical','^'+S,'^'+H],work,timeout=300)
run('bundle-verify',['git','bundle','verify',str(bundle)],work)
run('source-commits',['git','log','--format=%H %P %s',H+'..'+M],work)
run('source-numstat',['git','diff','--numstat','--no-renames',H,M],work)
run('source-stat',['git','diff','--stat',H,M],work)
run('source-parents',['git','show','-s','--format=%P',M],work)
run('ancestry-H',['git','merge-base','--is-ancestor',H,M],work)
run('ancestry-S',['git','merge-base','--is-ancestor',S,M],work)
run('status-after',['git','status','--porcelain=v1'],work);assert not (out/'status-after.stdout').read_text()
run('head-after',['git','rev-parse','HEAD','HEAD^{tree}'],work);assert (out/'head-after.stdout').read_bytes()==(out/'head.stdout').read_bytes()
summary={'source':M,'source_tree':T,'source_parent':(out/'source-parents.stdout').read_text().strip(),'base_H':H,'S':S,'bundle':{'path':str(bundle),'bytes':bundle.stat().st_size,'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest()},'change_stat':(out/'source-stat.stdout').read_text(),'source_commits':(out/'source-commits.stdout').read_text(),'steps':records}
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='steps'}),flush=True)
