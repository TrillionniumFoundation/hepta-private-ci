"""Publish one frozen common source through the original Mac gh identity."""

import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('/Users/qianqi/work/cell-integration-20261108-08b6-publication')
REPO = 'TrillionniumFoundation/hepta-private-ci'
GH = '/opt/homebrew/bin/gh'
S = '693a013b254d07779f6f2b2a78d0ee31481f4ea9'
H = '81da60b349e32d89d0e4c4674a517a66af7e5eee'
BASE = 'engineering/cell-integrated-20261109-08b6-base-H'
BRANCH = 'engineering/cell-integrated-20261109-08b6'


def require(value, message):
    if not value:
        raise RuntimeError(message)


def main():
    os.umask(0o077)
    data = json.load(sys.stdin)
    for key in ('source', 'source_tree', 'source_parent'):
        require(re.fullmatch('[0-9a-f]{40}', data[key]), 'Invalid source identity')
    require(data['source'] == '__M6_SOURCE__', 'Unreviewed source')
    require(data['source_tree'] == '__M6_TREE__', 'Unreviewed tree')
    require(data['source_parent'] == '__M6_PARENT__', 'Unexpected parent')
    body = base64.b64decode(data['body_base64'], validate=True)
    require(hashlib.sha256(body).hexdigest() == data['body_sha256'], 'Body differs')
    bundle_spec = data['bundle']
    require(bundle_spec['path'] == '/home/qian-qi/work/cell-continuation-20261109-08b6/source-export-028/M6-over-S-H.bundle', 'Unexpected bundle path')
    require(0 < bundle_spec['bytes'] < 32 * 1024 * 1024 and re.fullmatch('[0-9a-f]{64}', bundle_spec['sha256']), 'Invalid bundle pin')
    out = ROOT / 'common-M6-source-publication-003'
    out.mkdir(mode=0o700, exist_ok=False)
    (out / 'FROZEN_INPUT.json').write_text(json.dumps(data, indent=2) + '\n')
    (out / 'PR_BODY.zh-CN.md').write_bytes(body)
    env = dict(os.environ)
    for name in ('GH_HOST', 'GH_DEBUG', 'GIT_TRACE', 'GIT_TRACE_CURL', 'GIT_CURL_VERBOSE'):
        env.pop(name, None)
    env['GIT_TERMINAL_PROMPT'] = '0'
    steps = []

    def run(name, argv, timeout=120):
        (out / (name + '.intent.json')).write_text(json.dumps({'argv': argv, 'timeout_seconds': timeout}) + '\n')
        start = time.monotonic()
        code, error = None, None
        with (out / (name + '.stdout')).open('xb') as stdout, (out / (name + '.stderr')).open('xb') as stderr:
            try:
                code = subprocess.run(argv, env=env, stdout=stdout, stderr=stderr, timeout=timeout).returncode
            except (OSError, subprocess.TimeoutExpired) as exception:
                error = repr(exception)
            finally:
                for stream in (stdout, stderr):
                    stream.flush()
                    os.fsync(stream.fileno())
        row = {'name': name, 'exit_code': code, 'error': error, 'state': 'RETURNED' if code is not None else 'UNKNOWN', 'wall_seconds': time.monotonic() - start}
        for stream in ('stdout', 'stderr'):
            raw = (out / (name + '.' + stream)).read_bytes()
            row[stream] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        steps.append(row)
        (out / 'STEPS.json').write_text(json.dumps(steps, indent=2) + '\n')
        print(json.dumps(row), flush=True)
        return code

    def checked(name, argv, timeout=120):
        require(run(name, argv, timeout) == 0, name + ' failed; no automatic write replay')
        return (out / (name + '.stdout')).read_text().strip()

    git = ['/usr/bin/git', '-C', str(ROOT / 'evidence-git-publication-001/objects.git'), '-c', 'protocol.version=2', '-c', 'credential.helper=', '-c', 'credential.https://github.com.helper=!/opt/homebrew/bin/gh auth git-credential']
    url = 'https://github.com/' + REPO + '.git'
    require(checked('github-login', [GH, 'api', '--hostname', 'github.com', 'user', '--jq', '.login']) == 'ProfHepta', 'Original GitHub identity differs')
    repository = json.loads(checked('repository', [GH, 'api', '--hostname', 'github.com', 'repos/' + REPO, '--jq', '{id,node_id,full_name,private,visibility,push:.permissions.push}']))
    require(repository == {'id': 1320694176, 'node_id': 'R_kgDOTrgxoA', 'full_name': REPO, 'private': False, 'visibility': 'public', 'push': True}, 'Repository identity/capability differs')
    prior = json.loads(checked('prior-owned-source-pr', [GH, 'api', '--hostname', 'github.com', 'repos/' + REPO + '/pulls/5406', '--jq', '{number,state,draft,author:.user.login,head:{sha:.head.sha,repo:.head.repo.full_name,repo_id:.head.repo.id}}']))
    require(prior == {'number': 5406, 'state': 'open', 'draft': True, 'author': 'ProfHepta', 'head': {'sha': S, 'repo': REPO, 'repo_id': 1320694176}}, 'Previously authorized source/repository differs')
    require(checked('origin', git + ['remote', 'get-url', 'origin']) == url, 'Origin differs')
    require(checked('push-urls', git + ['remote', 'get-url', '--push', '--all', 'origin']).splitlines() == [url], 'Push destination differs')
    refs = ['refs/heads/' + BASE, 'refs/heads/' + BRANCH]
    require(checked('refs-before', git + ['ls-remote', '--refs', 'origin', *refs]) == '', 'New branch name already exists')
    prs = json.loads(checked('prs-before', [GH, 'pr', 'list', '--repo', REPO, '--state', 'all', '--head', BRANCH, '--json', 'number,state,isDraft,headRefName,headRefOid,baseRefName,url']))
    require(prs == [], 'Source PR already exists')
    bundle = out / 'frozen-M6.bundle'
    checked('copy-bundle', ['/usr/bin/scp', '-oBatchMode=yes', '-oStrictHostKeyChecking=yes', 'rog-ts:' + bundle_spec['path'], str(bundle)])
    raw = bundle.read_bytes()
    require(len(raw) == bundle_spec['bytes'] and hashlib.sha256(raw).hexdigest() == bundle_spec['sha256'], 'Transferred bundle differs')
    for label, commit in [('S', S), ('H', H)]:
        if run('has-' + label, git + ['cat-file', '-e', commit + '^{commit}'], 30) != 0:
            checked('fetch-' + label, git + ['fetch', '--no-tags', '--no-write-fetch-head', 'origin', commit], 300)
    checked('bundle-verify', git + ['bundle', 'verify', str(bundle)])
    checked('bundle-import', git + ['bundle', 'unbundle', str(bundle)])
    source = data['source']
    require(checked('source-tree', git + ['rev-parse', source + '^{tree}']) == data['source_tree'], 'Imported tree differs')
    require(checked('source-parent', git + ['show', '-s', '--format=%P', source]) == data['source_parent'], 'Imported parent differs')
    checked('H-ancestor', git + ['merge-base', '--is-ancestor', H, source])
    checked('S-ancestor', git + ['merge-base', '--is-ancestor', S, source])
    checked('source-stat', git + ['diff', '--stat', H, source])
    checked('source-commits', git + ['log', '--format=%H %P %s', H + '..' + source])
    require(checked('refs-prewrite', git + ['ls-remote', '--refs', 'origin', *refs]) == '', 'Branches changed before write')
    push_code = run('push-create-only', git + ['push', '--atomic', '--porcelain', '--force-with-lease=' + refs[0] + ':', '--force-with-lease=' + refs[1] + ':', 'origin', H + ':' + refs[0], source + ':' + refs[1]], 180)
    observed = checked('refs-after', git + ['ls-remote', '--refs', 'origin', *refs])
    expected = {refs[0]: H, refs[1]: source}
    require(dict((line.split('\t')[1], line.split('\t')[0]) for line in observed.splitlines()) == expected, 'Push outcome unresolved; original request retained, no replay')
    request = {'title': data['title'], 'head': BRANCH, 'base': BASE, 'draft': True, 'body': body.decode()}
    (out / 'CREATE_PR.json').write_text(json.dumps(request, ensure_ascii=False, indent=2) + '\n')
    fields = '{number,url:.html_url,state,draft,title,body,author:.user.login,head:{sha:.head.sha,ref:.head.ref,repo:.head.repo.full_name},base:{sha:.base.sha,ref:.base.ref,repo:.base.repo.full_name}}'
    create_code = run('create-pr', [GH, 'api', '--hostname', 'github.com', '--method', 'POST', 'repos/' + REPO + '/pulls', '--input', str(out / 'CREATE_PR.json'), '--jq', fields], 120)
    created = None
    for attempt in range(5):
        candidates = json.loads(checked('prs-after-' + str(attempt), [GH, 'pr', 'list', '--repo', REPO, '--state', 'all', '--head', BRANCH, '--json', 'number,state,isDraft,headRefName,headRefOid,baseRefName,url']))
        if candidates:
            require(len(candidates) == 1, 'Multiple matching PRs')
            number = candidates[0]['number']
            created = json.loads(checked('pr-readback', [GH, 'api', '--hostname', 'github.com', 'repos/' + REPO + '/pulls/' + str(number), '--jq', fields]))
            break
        if attempt < 4:
            time.sleep(1)
    require(created is not None, 'PR write outcome unresolved; no replay')
    require(created['state'] == 'open' and created['draft'] is True and created['author'] == 'ProfHepta', 'PR state/owner differs')
    require(created['head'] == {'sha': source, 'ref': BRANCH, 'repo': REPO} and created['base'] == {'sha': H, 'ref': BASE, 'repo': REPO}, 'PR source/base differs')
    require(created['title'] == data['title'] and hashlib.sha256(created['body'].encode()).hexdigest() == data['body_sha256'], 'PR content readback differs')
    result = {'source': source, 'source_tree': data['source_tree'], 'base_H': H, 'source_branch': BRANCH, 'base_branch': BASE, 'pr': created['number'], 'url': created['url'], 'draft': True, 'body_sha256': data['body_sha256'], 'push_exit': push_code, 'create_exit': create_code, 'readback_verified': True, 'scientific_status': 'HOLD', 'production_status': 'not_adopted', 'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'steps': steps}
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'steps'}), flush=True)


if __name__ == '__main__':
    main()
