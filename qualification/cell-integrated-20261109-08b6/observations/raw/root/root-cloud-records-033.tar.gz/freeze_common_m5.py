from pathlib import Path
import subprocess,json,datetime,hashlib,time,resource,os
root=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
out=root/'common-M5-freeze-022';out.mkdir(exist_ok=False)
work=root/'integration-source'
S='693a013b254d07779f6f2b2a78d0ee31481f4ea9';H='81da60b349e32d89d0e4c4674a517a66af7e5eee'
env=os.environ.copy()
env.update({'PATH':'/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/work/cell-dependency-pin-20261108-08b6-evidence/tools/bin:/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/.local/bin:/home/qian-qi/.cargo/bin:'+'/home/qian-qi/work/cell-rsi-p0p2-20261108-858e/tools/uv-0.11.3:/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/bin:'+env.get('PATH',''),'RUSTUP_TOOLCHAIN':'1.96.0','CARGO_BUILD_JOBS':'2','CARGO_TARGET_DIR':'/home/qian-qi/work/cell-continuation-lifecycle-20261109-08b6/target','CARGO_TERM_COLOR':'never','PYTHONDONTWRITEBYTECODE':'1'})
records=[]
def run(name,argv,cwd,expected=0,timeout=600):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.perf_counter();cpu=resource.getrusage(resource.RUSAGE_CHILDREN);failure=None
 (out/(name+'.intent.json')).write_text(json.dumps({'argv':argv,'cwd':str(cwd),'started_at_utc':start})+'\n')
 with (out/(name+'.stdout')).open('wb') as so,(out/(name+'.stderr')).open('wb') as se:
  try:r=subprocess.run(argv,cwd=cwd,env=env,stdout=so,stderr=se,timeout=timeout);rc=r.returncode
  except BaseException as e:rc=None;failure=repr(e)
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 rec={'name':name,'argv':argv,'cwd':str(cwd),'exit':rc,'failure':failure,'wall_seconds':time.perf_counter()-t,'child_cpu_seconds':after.ru_utime+after.ru_stime-cpu.ru_utime-cpu.ru_stime,'started_at_utc':start,'ended_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 for stream in ['stdout','stderr']:
  p=out/(name+'.'+stream);b=p.read_bytes();rec[stream]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 records.append(rec);(out/'STEPS.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
 assert failure is None,(name,failure)
 if expected is not None:assert rc==expected,(name,rc)
 return rc



import sys,base64
payload=json.load(sys.stdin)
M4='cb5c06441ae6a23b53af55b3e9e4aa6efb3fe1ed';T4='30d47443ae052a18ae43eef992e1e167a605cec7'
UI='34041fbbb8fc6dcb716853973c848ed41cdec331';UT='9dd509d3855914f0ad0ae1977c93820b52eab2c9'
assert payload['reviewed_ui_commit']==UI and payload['reviewed_ui_tree']==UT
workflow='.github/workflows/hepta-cell-framework-native.yml'
new=base64.b64decode(payload['workflow_base64'],validate=True)
assert hashlib.sha256(new).hexdigest()==payload['workflow_sha256']=='8239a3f1da63e910f8f267966854d6c24733382f12a8c1ccd02494b235a0d209'
run('base-head',['git','rev-parse','HEAD','HEAD^{tree}'],work)
assert (out/'base-head.stdout').read_text().splitlines()==[M4,T4]
run('base-status',['git','status','--porcelain=v1'],work);assert not (out/'base-status.stdout').read_text()
canonical=root/'canonical-source'
run('canonical-base-head',['git','rev-parse','HEAD','HEAD^{tree}'],canonical)
assert (out/'canonical-base-head.stdout').read_text().splitlines()==[M4,T4]
run('canonical-base-status',['git','status','--porcelain=v1'],canonical);assert not (out/'canonical-base-status.stdout').read_text()
run('reviewed-ui-identity',['git','show','-s','--format=%H%n%T%n%P',UI],work)
assert (out/'reviewed-ui-identity.stdout').read_text().splitlines()==[UI,UT,M4]
run('ui-paths',['git','diff','--name-only',M4,UI],work)
assert set((out/'ui-paths.stdout').read_text().splitlines())=={r['path'] for r in payload['ui_files']}
for pin in payload['ui_files']:
 raw=subprocess.check_output(['git','show',UI+':'+pin['path']],cwd=work)
 assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],pin['path']
(out/'REVIEWED_UI_PINS.json').write_text(json.dumps(payload['ui_files'],indent=2)+'\n')
run('advance-ui',['git','merge','--ff-only',UI],work)
old=(work/workflow).read_bytes()
assert hashlib.sha256(old).hexdigest()==payload['workflow_base_sha256']=='6e2915f6602ab8ce8d748ee4b42070d6d98d8ac289127dc0ff4491786168dc4f'
assert new.count(b'      - engineering/cell-integrated-20261109-08b6\n')==1
assert new.count(b'--timeout-seconds 180 --minimum-tests 22')==1
assert new.count(b'cell_repo_mdv.test_memory')==1 and new.count(b'cell_repo_mdv.test_runner')==1
(work/workflow).write_bytes(new)
run('format',['just','fmt'],work/'codex-rs')
assert (work/workflow).read_bytes()==new
run('changed-paths',['git','diff','--name-only'],work)
assert (out/'changed-paths.stdout').read_text().splitlines()==[workflow]
run('diff-check',['git','diff','--check'],work)
run('diff',['git','diff','--no-ext-diff'],work)
run('numstat',['git','diff','--numstat'],work)
assert sum(sum(map(int,line.split('\t')[:2])) for line in (out/'numstat.stdout').read_text().splitlines())<30
run('stage',['git','add','--',workflow],work)
run('commit',['git','commit','-m','ci: qualify the frozen integrated Cell candidate'],work)
run('frozen-head',['git','rev-parse','HEAD','HEAD^{tree}'],work)
run('frozen-parent',['git','show','-s','--format=%P','HEAD'],work)
assert (out/'frozen-parent.stdout').read_text().strip()==UI
run('frozen-status',['git','status','--porcelain=v1'],work);assert not (out/'frozen-status.stdout').read_text()
M,T=(out/'frozen-head.stdout').read_text().splitlines()
run('advance-canonical',['git','merge','--ff-only',M],canonical)
run('canonical-final-head',['git','rev-parse','HEAD','HEAD^{tree}'],canonical)
assert (out/'canonical-final-head.stdout').read_text().splitlines()==[M,T]
run('canonical-final-status',['git','status','--porcelain=v1'],canonical);assert not (out/'canonical-final-status.stdout').read_text()
summary={'source':M,'source_tree':T,'source_parent':UI,'M4':M4,'M4_tree':T4,'reviewed_ui_files':payload['ui_files'],'workflow_sha256':payload['workflow_sha256'],'changed_in_final_stage':[workflow],'source_worktree':str(work),'canonical_worktree':str(canonical),'steps':records,'qualification_status':'FROZEN_AWAITING_FINAL_COMMON_HEAD_TESTS'}
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='steps'}),flush=True)

