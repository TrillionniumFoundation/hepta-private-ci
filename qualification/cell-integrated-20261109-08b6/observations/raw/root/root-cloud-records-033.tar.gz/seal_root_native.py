from pathlib import Path
import sys,json,os,stat,hashlib,gzip,tarfile,io,time,datetime
os.umask(0o077)
root=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
out=root/'root-native-evidence-seal-032';out.mkdir(mode=0o700,exist_ok=False)
inputs=json.load(sys.stdin)
started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.perf_counter()
names=inputs['directories'];assert len(names)==len(set(names)) and all('/' not in n and '..' not in n for n in names)
files=[];missing=[]
for name in names:
 base=root/name
 if not base.exists():missing.append(name);continue
 assert base.is_dir() and not base.is_symlink()
 for p in sorted(base.rglob('*')):
  assert not p.is_symlink(),str(p)
  if p.is_dir():continue
  s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
  assert p.name!='source.tar','Full tracked source archives remain independently pinned in Git, never duplicated here'
  assert s.st_size<256*1024*1024
  files.append((p,s))
assert sum(s.st_size for _,s in files)<1024*1024*1024
manifest={'schema':'hepta.root-native-evidence.v1','directories':names,'missing_at_inventory':missing,'missing_does_not_prove_nonexecution':True,'source_final':'885dae0f3285267e9e9c49d8b43b0d009779f9e8','source_tree_final':'293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb','files':[]}
archive=out/'root-native-evidence.tar.gz'
with archive.open('xb') as handle:
 with gzip.GzipFile(filename='',fileobj=handle,mode='wb',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w|',format=tarfile.PAX_FORMAT) as tar:
   for p,before in files:
    raw=p.read_bytes();after=p.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    rel=str(p.relative_to(root));row={'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':oct(stat.S_IMODE(before.st_mode))}
    manifest['files'].append(row)
    entry=tarfile.TarInfo(rel);entry.size=len(raw);entry.mode=stat.S_IMODE(before.st_mode);entry.mtime=0;tar.addfile(entry,io.BytesIO(raw))
   meta=(json.dumps(manifest,indent=2)+'\n').encode()
   entry=tarfile.TarInfo('NATIVE_MANIFEST.json');entry.size=len(meta);entry.mode=0o600;entry.mtime=0;tar.addfile(entry,io.BytesIO(meta))
(out/'NATIVE_MANIFEST.json').write_bytes(meta)
expected={r['path']:r for r in manifest['files']}
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(expected)+1
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  raw=tar.extractfile(member).read()
  if member.name=='NATIVE_MANIFEST.json':assert raw==meta;continue
  row=expected[member.name];assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'] and oct(member.mode)==row['mode']
result={'archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'manifest':{'path':str(out/'NATIVE_MANIFEST.json'),'bytes':len(meta),'sha256':hashlib.sha256(meta).hexdigest()},'members':len(expected)+1,'original_regular_bytes':sum(r['bytes'] for r in manifest['files']),'missing_at_inventory':missing,'source_final':manifest['source_final'],'member_bytes_and_modes_verified':True,'started_at_utc':started,'wall_seconds':time.perf_counter()-tick}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)

