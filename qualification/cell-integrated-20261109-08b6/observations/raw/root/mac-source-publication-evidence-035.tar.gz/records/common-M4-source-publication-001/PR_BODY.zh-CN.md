## 为什么需要这次集成

上一轮 S 与并行候选 H 互不为祖先，两边已有的通过结果不能构成一个实际受测系统。本 PR 冻结它们的真实合并，并修复共同调用链与恢复路径中发现的缺口。所有最终验证绑定下面这一份源码；开发中间态和失败记录单独保留。

| 身份 | 精确值 |
| --- | --- |
| 本 PR 共同源码 M4 | `cb5c06441ae6a23b53af55b3e9e4aa6efb3fe1ed` |
| M4 tree | `30d47443ae052a18ae43eef992e1e167a605cec7` |
| 固定比较基底 H | `81da60b349e32d89d0e4c4674a517a66af7e5eee` |
| 已共同合入 S | `693a013b254d07779f6f2b2a78d0ee31481f4ea9` |
| 实际双亲合并 | `96d279e1c5f8ac06c40ae0d7562e665f4f2654fc`，双亲为 journal-lock 修复 K 与 H |

## 改动与行为

- 显式释放 inference journal owner 的文件锁，覆盖重复文件描述符仍存活时的重开场景；原 CI 失败的精确调度原因仍属待证推断。
- 普通 ObjectiveStart 完成后写入有界、持久的 learning outbox；从原 RunStart 与完整 Circuit history 补漏，持久 claim 后由原 runtime 验证 NextUse 再 ACK。256 个身份槽包括已 ACK 条目；不静默丢弃恢复身份。
- 合并 S 的有界子进程监督与 H 的观察策略/记忆模式。真实 fit_grid 每个 job 携带冻结源码摘要；较短任务预算进入准入、启动剩余时限和最终复验。两处调用链修复均保留真实红→绿回归。
- 复用 H 的 Matrix SDK/crypto/sqlite 0.19.1 与兼容依赖图，保留 S 已升级的实际上游 Smithy/loom 版本。Cargo package 块按 Cargo 原生顺序保存，所有非相关依赖边保持；Bazel 锁同步核验。
- 集成真实仓库开发运行器：真实工具失败/修复/验证、一次受验证结果约束的私有记忆状态更新、后继进程读取。状态标为 `not_requested`，没有签发生产采用决定。
- 保留 S 的 IME 完整状态提交与严格 Clippy 修复，修复 H 的 MEM-1 格式阻断。

复核顺序见提交链：原 S 系列 → 双亲集成 → MEM 格式 → outbox/恢复三阶段 → 开发运行器四阶段 → grid 源码传播 → 任务预算 → lock 原生顺序。新增复杂功能按小阶段提交供独立审阅；相对于 H 的整体差异还包含已经在 S 发表的资格记录。

## 当前已观测的 M4 验证

| 范围 | 结果 |
| --- | --- |
| 完整指定 Python 组 | 91/91，通过，0 skip；独立 Linux Python 3.12.14、Torch 2.9.1+cpu、NumPy 1.26.4、Pillow 12.0.0；93 项源/资源逐项绑定 M4 Git 对象 |
| Cargo 全 features locked metadata | 通过 |
| `cargo deny --locked --all-features check` | advisories / bans / licenses / sources 全通过；沿用仓库原有 ignore，没有新增例外 |
| Bazel lock update 后 error 模式 | 通过；最终锁与 M4 源码一致 |
| 完整源码归档 | 210,585,600 bytes；13,681 项 = 13,680 regular + 1 symlink；完整原始字节、mode、symlink 与 Git tree 比对通过 |
| 原生 lifecycle/AWS、Matrix 旧库消费者、Firefox 与 UI Clippy | 最终 M4 独立验证进行中，未借用历史 S/H/M3 通过数 |

M4 完整 source.tar SHA256：`1cb4bab9d4c3a8a92daa681b8b93a017aaea75e168e475ecda53ad63b0370a19`。外部 Makepad SDK、字体、浏览器、编译器与 Python 环境各有独立配置和摘要；源码归档不等于离线运行镜像。完整结果及失败/恢复成本将作为 M4 的独立 evidence child 发表，不改变此受测源码。

## 资格边界

生产普通 CLI 的 provider/owner/custody 组合、自动 outbox worker、独立评价与真实后继采用仍未闭环；持久 claim 后缺失 backend 状态的窗口保持未决，没有自动重放。当前真实开发任务来自一个已暴露的 R/S 故障家族，历史开发运行中学习状态与强 BM25 排序/选择相同，未建立独立学习收益。

PRED-1 原 HOLD 保持；原确认与已使用的新确认均继续封存，未再次调参或重跑。本轮 MEM/VERIFY/NDU/HCSN 后续方案保持审阅稿，组织演化与改进器实验未启动。此 PR 保持 draft，工程通过不能升级为科学收益或生产采用。
