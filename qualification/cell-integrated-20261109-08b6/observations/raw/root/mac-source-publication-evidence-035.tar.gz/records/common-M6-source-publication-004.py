"""Create the frozen M6 draft through the original Mac gh identity after offline import."""
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path("/Users/qianqi/work/cell-integration-20261108-08b6-publication")
REPO = "TrillionniumFoundation/hepta-private-ci"
GH = "/opt/homebrew/bin/gh"
GIT = "/usr/bin/git"
S = "693a013b254d07779f6f2b2a78d0ee31481f4ea9"
H = "81da60b349e32d89d0e4c4674a517a66af7e5eee"
M6 = "885dae0f3285267e9e9c49d8b43b0d009779f9e8"
TREE = "293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb"
PARENT = "953d548d25b1e050109b1b93e1ea474b2ac7c801"
BASE = "engineering/cell-integrated-20261109-08b6-base-H"
BRANCH = "engineering/cell-integrated-20261109-08b6"
NATIVE = "/home/qian-qi/work/cell-continuation-20261109-08b6/"
OUTNAME = "common-M6-source-publication-004"

def require(value, message):
    if not value:
        raise RuntimeError(message)

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    os.umask(0o077)
    input_path = Path(sys.argv[1])
    data = json.loads(input_path.read_text())
    require((data["source"], data["source_tree"], data["source_parent"]) == (M6, TREE, PARENT), "Frozen source differs")
    require(data["previous_prewrite_steps_sha256"] == "90b5cf9f77851850c4697d44cb3c6bc2a924393a97e0301cf11d9660285f8cd0", "Unreviewed previous operation")
    old_steps_path = ROOT / "common-M6-source-publication-003/STEPS.json"
    require(digest(old_steps_path) == data["previous_prewrite_steps_sha256"], "Previous journal changed")
    old_steps = json.loads(old_steps_path.read_text())
    require(old_steps[-1]["name"] == "fetch-H" and not any(x["name"].startswith(("push-", "create-pr")) for x in old_steps), "Previous operation may have written")
    body_path = Path(data["body"]["path"])
    require(body_path == ROOT / (OUTNAME + ".body.md"), "Unexpected body path")
    require(body_path.stat().st_size == data["body"]["bytes"] and digest(body_path) == data["body"]["sha256"], "Body differs")
    body = body_path.read_bytes()
    out = ROOT / OUTNAME
    out.mkdir(mode=0o700, exist_ok=False)
    shutil.copyfile(input_path, out / "FROZEN_INPUT.json")
    shutil.copyfile(Path(__file__), out / "CONTROLLER.py")
    shutil.copyfile(ROOT / (OUTNAME + ".REQUEST.json"), out / "CONTROL_REQUEST.json")
    (out / "PR_BODY.zh-CN.md").write_bytes(body)
    env = dict(os.environ)
    for name in list(env):
        if name.startswith("GIT_") or name in ("GH_HOST", "GH_DEBUG"):
            env.pop(name, None)
    env.update({"GIT_TERMINAL_PROMPT":"0", "GIT_CONFIG_NOSYSTEM":"1",
                "GIT_CONFIG_GLOBAL":"/dev/null", "GIT_NO_LAZY_FETCH":"1",
                "GIT_NO_REPLACE_OBJECTS":"1", "GH_PROMPT_DISABLED":"1", "GH_PAGER":"cat"})
    steps = []
    outer_start = time.monotonic()

    def run(name, argv, timeout=120, stdin_path=None):
        require(re.fullmatch("[a-zA-Z0-9-]+", name), "Invalid stage label")
        intent = {"argv":argv, "timeout_seconds":timeout, "stdin_path":str(stdin_path) if stdin_path else None}
        (out / (name + ".intent.json")).write_text(json.dumps(intent) + "\n")
        start = time.monotonic()
        code, error = None, None
        stdin = stdin_path.open("rb") if stdin_path else subprocess.DEVNULL
        try:
            with (out / (name+".stdout")).open("xb") as stdout, (out / (name+".stderr")).open("xb") as stderr:
                try:
                    code = subprocess.run(argv, env=env, stdin=stdin, stdout=stdout, stderr=stderr, timeout=timeout).returncode
                except (OSError, subprocess.TimeoutExpired) as exc:
                    error = repr(exc)
                finally:
                    for stream in (stdout, stderr):
                        stream.flush()
                        os.fsync(stream.fileno())
        finally:
            if stdin_path:
                stdin.close()
        row = {"name":name, "exit_code":code, "error":error,
               "state":"RETURNED" if code is not None else "UNKNOWN",
               "wall_seconds":time.monotonic()-start}
        for stream in ("stdout","stderr"):
            path = out/(name+"."+stream)
            row[stream] = {"bytes":path.stat().st_size, "sha256":digest(path)}
        steps.append(row)
        (out/"STEPS.json").write_text(json.dumps(steps,indent=2)+"\n")
        print(json.dumps(row),flush=True)
        return code

    def checked(name, argv, timeout=120, stdin_path=None):
        require(run(name,argv,timeout,stdin_path)==0, name+" failed; no automatic write replay")
        return (out/(name+".stdout")).read_text().strip()

    def copy_artifact(name, spec, target):
        require(spec["path"].startswith(NATIVE) and re.fullmatch("[0-9a-f]{64}",spec["sha256"]), "Invalid native artifact")
        require(0 < spec["bytes"] <= 80*1024*1024, "Unreviewed transport size")
        checked(name, ["/usr/bin/scp","-oBatchMode=yes","-oStrictHostKeyChecking=yes","rog-ts:"+spec["path"],str(target)],180)
        require(target.stat().st_size==spec["bytes"] and digest(target)==spec["sha256"], "Transported artifact differs")

    gh = [GH,"api","--hostname","github.com"]
    require(checked("github-login",gh+["user","--jq",".login"])=="ProfHepta","Original identity differs")
    repository = json.loads(checked("repository",gh+["repos/"+REPO,"--jq","{id,node_id,full_name,private,visibility,push:.permissions.push}"]))
    require(repository=={"id":1320694176,"node_id":"R_kgDOTrgxoA","full_name":REPO,"private":False,"visibility":"public","push":True},"Repository identity/capability differs")
    prior = json.loads(checked("prior-owned-source-pr",gh+["repos/"+REPO+"/pulls/5406","--jq","{number,state,draft,author:.user.login,head:{sha:.head.sha,repo:.head.repo.full_name,repo_id:.head.repo.id}}"]))
    require(prior=={"number":5406,"state":"open","draft":True,"author":"ProfHepta","head":{"sha":S,"repo":REPO,"repo_id":1320694176}},"Previous authorized source differs")
    refs = ["refs/heads/"+BASE,"refs/heads/"+BRANCH]
    def remote_refs(name):
        rows = json.loads(checked(name,gh+["repos/"+REPO+"/git/matching-refs/heads/"+BRANCH,"--jq","[.[] | {ref,sha:.object.sha}]"]))
        require(isinstance(rows,list) and len({x["ref"] for x in rows})==len(rows),"Invalid remote refs")
        return {x["ref"]:x["sha"] for x in rows}
    require(remote_refs("refs-before")=={},"New branch prefix already exists")
    prlist = [GH,"pr","list","--repo",REPO,"--state","all","--head",BRANCH,"--json","number,state,isDraft,headRefName,headRefOid,baseRefName,url"]
    require(json.loads(checked("prs-before",prlist))==[],"Source PR already exists")
    pack=out/"S-H-frontier-and-M6.pack"
    bundle=out/"frozen-M6.bundle"
    shallow=out/"shallow-boundaries.txt"
    copy_artifact("copy-pack",data["pack"],pack)
    copy_artifact("copy-bundle",data["bundle"],bundle)
    copy_artifact("copy-shallow",data["shallow"],shallow)
    require(set(shallow.read_text().splitlines())=={S,H} and len(shallow.read_text().splitlines())==2,"Unexpected shallow boundary")
    bare=out/"objects.git"
    offline=[GIT,"-c","protocol.allow=never"]
    checked("init-offline-bare",offline+["init","--bare",str(bare)])
    git=[GIT,"-C",str(bare),"-c","protocol.allow=never","-c","color.ui=false","-c","core.quotePath=true"]
    (bare/"shallow").write_bytes(shallow.read_bytes())
    checked("index-offline-pack",git+["index-pack","--strict","--stdin"],180,pack)
    checked("frontier-S",git+["update-ref","refs/bootstrap/S",S,"0"*40])
    checked("frontier-H",git+["update-ref","refs/bootstrap/H",H,"0"*40])
    require(not (bare/"objects/info/alternates").exists(),"Unexpected alternates")
    require(checked("remotes-offline",git+["remote"])=="","Unexpected offline remote")
    config=checked("offline-config",git+["config","--local","--list"])
    require(not any(word in config.lower() for word in ("promisor","partialclone","alternates","url.")),"Unexpected object provider")
    checked("bundle-verify",git+["bundle","verify",str(bundle)])
    checked("bundle-import",git+["bundle","unbundle",str(bundle)])
    checked("local-source",git+["update-ref","refs/bootstrap/M6",M6,"0"*40])
    checked("offline-fsck",git+["fsck","--full","--strict","--no-reflogs",S,H,M6],180)
    require(checked("source-tree",git+["rev-parse",M6+"^{tree}"])==TREE,"Imported tree differs")
    require(checked("source-parent",git+["show","-s","--format=%P",M6])==PARENT,"Imported parent differs")
    checked("H-ancestor",git+["merge-base","--is-ancestor",H,M6])
    checked("S-ancestor",git+["merge-base","--is-ancestor",S,M6])
    checked("source-diff-raw",git+["diff","--raw","--no-abbrev","--no-renames",H,M6])
    require(digest(out/"source-diff-raw.stdout")=="d17774fc72ecc93f58aa2a7b39c5ffd9f641fcf1ad58e0fc5e372211249a5f70","Offline source diff differs")
    checked("source-stat",git+["diff","--stat",H,M6])
    require(digest(out/"source-stat.stdout")=="f2feef104e7f82219671c5469155c4f0cbc131fdd77fa38e73396468f6393df3","Offline source stat differs")
    url="https://github.com/"+REPO+".git"
    checked("configure-origin",git+["remote","add","origin",url])
    require(checked("origin",git+["remote","get-url","origin"])==url,"Origin differs")
    require(checked("push-urls",git+["remote","get-url","--push","--all","origin"]).splitlines()==[url],"Push destination differs")
    require(remote_refs("refs-prewrite")=={},"Branches changed before write")
    network_git=git+["-c","protocol.https.allow=always","-c","protocol.version=2","-c","credential.helper=","-c","credential.https://github.com.helper=!/opt/homebrew/bin/gh auth git-credential"]
    push_exit=run("push-create-only",network_git+["push","--atomic","--porcelain","--force-with-lease="+refs[0]+":","--force-with-lease="+refs[1]+":","origin",H+":"+refs[0],M6+":"+refs[1]],600)
    observed=remote_refs("refs-after")
    require(observed=={refs[0]:H,refs[1]:M6},"Push outcome unresolved; no replay")
    request={"title":data["title"],"head":BRANCH,"base":BASE,"draft":True,"body":body.decode("utf-8")}
    (out/"CREATE_PR.json").write_text(json.dumps(request,ensure_ascii=False,indent=2)+"\n")
    fields="{number,url:.html_url,state,draft,title,body,author:.user.login,head:{sha:.head.sha,ref:.head.ref,repo:.head.repo.full_name},base:{sha:.base.sha,ref:.base.ref,repo:.base.repo.full_name}}"
    create_exit=run("create-pr",gh+["--method","POST","repos/"+REPO+"/pulls","--input",str(out/"CREATE_PR.json"),"--jq",fields],120)
    created=None
    for attempt in range(5):
        candidates=json.loads(checked("prs-after-"+str(attempt),prlist))
        if candidates:
            require(len(candidates)==1,"Multiple matching PRs")
            created=json.loads(checked("pr-readback",gh+["repos/"+REPO+"/pulls/"+str(candidates[0]["number"]),"--jq",fields]))
            break
        if attempt < 4:
            time.sleep(1)
    require(created is not None,"PR outcome unresolved; no replay")
    require(created["state"]=="open" and created["draft"] is True and created["author"]=="ProfHepta","PR state/owner differs")
    require(created["head"]=={"sha":M6,"ref":BRANCH,"repo":REPO} and created["base"]=={"sha":H,"ref":BASE,"repo":REPO},"PR source/base differs")
    require(created["title"]==data["title"] and hashlib.sha256(created["body"].encode()).hexdigest()==data["body"]["sha256"],"PR content differs")
    result={"source":M6,"source_tree":TREE,"source_parent":PARENT,"base_H":H,"source_branch":BRANCH,"base_branch":BASE,"pr":created["number"],"url":created["url"],"draft":True,"body_sha256":data["body"]["sha256"],"push_exit":push_exit,"create_exit":create_exit,"readback_verified":True,"scientific_status":"HOLD","production_status":"not_adopted","source_archive_sha256":"dfc9484fc2dab61b37801e8197774a67365fb185fedc620a9b970e2f0e9d284e","offline_transport_shallow_frontier_only":True,"native_complete_history_source":data["native_complete_history"],"outer_wall_seconds":time.monotonic()-outer_start,"completed_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"steps":steps}
    (out/"RESULT.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k!="steps"}),flush=True)

if __name__=="__main__":
    main()
