"""Export exact S/H frontier plus M6 objects, and prove import in an offline bare repo."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time

ROOT = Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
SOURCE = ROOT / 'canonical-source'
OUT = ROOT / 'offline-publication-prerequisites-001'
S = '693a013b254d07779f6f2b2a78d0ee31481f4ea9'
H = '81da60b349e32d89d0e4c4674a517a66af7e5eee'
M = '885dae0f3285267e9e9c49d8b43b0d009779f9e8'
TREE = '293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb'
BUNDLE = ROOT / 'source-export-028/M6-over-S-H.bundle'
BUNDLE_SHA = '4203f99cf1128a4548cb6a885d3b748d70e6ba46d90aae8b6c2017ebc7db0033'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_NO_REPLACE_OBJECTS='1', GIT_TERMINAL_PROMPT='0')
for key in ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_SHALLOW_FILE', 'GIT_TRACE', 'GIT_TRACE_CURL', 'GIT_CURL_VERBOSE']:
    ENV.pop(key, None)
PREFIX = ['git', '-c', 'protocol.allow=never', '-c', 'protocol.file.allow=never', '-c', 'protocol.ssh.allow=never', '-c', 'protocol.https.allow=never', '-c', 'pack.threads=2', '-c', 'pack.windowMemory=128m']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while block := f.read(1024 * 1024): h.update(block)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True); f.write('\n'); f.flush(); os.fsync(f.fileno())


def main():
    os.umask(0o077); OUT.mkdir(mode=0o700, exist_ok=False)
    (OUT / 'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
    steps=[]; started=time.monotonic()

    def run(label, args, cwd=SOURCE, data=None, timeout=120, required=True, output=None):
        argv=PREFIX+args
        save(OUT/(label+'.intent.json'), {'argv':argv,'cwd':str(cwd),'timeout_seconds':timeout,
            'stdin_bytes':len(data) if data is not None else None,'stdin_sha256':sha(data) if data is not None else None,
            'network_policy':'All Git transport protocols denied; no-lazy-fetch and no replacement objects'})
        dest=output or OUT/(label+'.stdout'); begin=time.monotonic()
        with dest.open('xb') as out, (OUT/(label+'.stderr')).open('xb') as err:
            p=subprocess.run(argv,cwd=cwd,env=ENV,input=data,stdout=out,stderr=err,timeout=timeout)
        row={'label':label,'exit_code':p.returncode,'wall_seconds':time.monotonic()-begin,'stdout':pin(dest),'stderr':pin(OUT/(label+'.stderr'))}
        steps.append(row);save(OUT/(label+'.result.json'),row);print(json.dumps({'label':label,'exit_code':p.returncode,'wall_seconds':row['wall_seconds']}),flush=True)
        if required and p.returncode:raise RuntimeError(label+' failed offline; no network fallback')
        return dest.read_bytes() if output is None else None

    result={'source':M,'source_tree':TREE,'frontier':[S,H],'steps':steps,'github_writes':False,'source_mutation':False}
    try:
        head=run('source-head',['rev-parse','HEAD','HEAD^{tree}']).decode().splitlines()
        if head != [M,TREE] or run('source-status',['status','--porcelain=v1','--untracked-files=all']):raise RuntimeError('Frozen source changed')
        raw=BUNDLE.read_bytes()
        if len(raw)!=50239 or sha(raw)!=BUNDLE_SHA:raise RuntimeError('Frozen source bundle changed')
        (OUT/'M6-over-S-H.bundle').write_bytes(raw)
        header=raw.split(b'\n\n',1)[0].decode()
        requirements={line[1:41] for line in header.splitlines() if line.startswith('-')}
        if requirements!={S,H}:raise RuntimeError('Unexpected frozen bundle prerequisites')
        result['bundle_header']=header
        commits={}
        objects=set(run('m6-new-objects',['rev-list','--objects','--no-object-names',M,'^'+S,'^'+H]).decode().splitlines())
        for label, commit in [('S',S),('H',H),('M6',M)]:
            body=run('raw-'+label,['cat-file','commit',commit])
            if hashlib.sha1(b'commit '+str(len(body)).encode()+b'\0'+body).hexdigest()!=commit:raise RuntimeError('Raw commit Git identity changed')
            (OUT/(label+'.commit')).write_bytes(body)
            header=body.split(b'\n\n',1)[0].decode()
            tree=next(line[5:] for line in header.splitlines() if line.startswith('tree '))
            parents=[line[7:] for line in header.splitlines() if line.startswith('parent ')]
            commits[label]={'commit':commit,'tree':tree,'parents':parents,'raw':pin(OUT/(label+'.commit'))}
            if label in ['S','H']:
                objects.update([commit,tree])
                listing=run('tree-'+label,['ls-tree','-r','-t','-z',tree])
                for entry in listing.split(b'\0'):
                    if entry:objects.add(entry.split(b'\t',1)[0].split()[2].decode())
        if commits['M6']['tree']!=TREE or commits['M6']['parents']!=['953d548d25b1e050109b1b93e1ea474b2ac7c801']:raise RuntimeError('M6 identity differs')
        identities=('\n'.join(sorted(objects))+'\n').encode();(OUT/'OBJECT_IDS.txt').write_bytes(identities)
        types=run('objects-present',['cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],data=identities)
        if b' missing\n' in types or len(types.splitlines())!=len(objects):raise RuntimeError('Required source object absent; no promisor fetch allowed')
        pack=OUT/'S-H-frontier-and-M6.pack'
        run('self-contained-pack',['pack-objects','--stdout','--no-reuse-delta','--no-reuse-object','--delta-base-offset'],data=identities,timeout=240,output=pack)
        verify=OUT/'offline-verify.git'
        run('bare-init',['init','--bare',str(verify)],cwd=OUT)
        boundaries=(S+'\n'+H+'\n').encode();(OUT/'shallow-boundaries.txt').write_bytes(boundaries);(verify/'shallow').write_bytes(boundaries)
        run('pack-import',['index-pack','--stdin','--strict'],cwd=verify,data=pack.read_bytes(),timeout=180)
        refs=('create refs/bootstrap/S '+S+'\ncreate refs/bootstrap/H '+H+'\n').encode()
        run('frontier-refs',['update-ref','--stdin'],cwd=verify,data=refs)
        run('bundle-verify',['bundle','verify',str(OUT/'M6-over-S-H.bundle')],cwd=verify)
        run('bundle-unbundle',['bundle','unbundle',str(OUT/'M6-over-S-H.bundle')],cwd=verify)
        run('source-ref',['update-ref','refs/heads/offline-M6',M,'0'*40],cwd=verify)
        run('offline-fsck',['fsck','--strict','--no-dangling'],cwd=verify,timeout=180)
        if run('imported-tree',['rev-parse',M+'^{tree}'],cwd=verify).decode().strip()!=TREE:raise RuntimeError('Imported tree differs')
        if run('imported-parent',['show','-s','--format=%P',M],cwd=verify).decode().strip()!=commits['M6']['parents'][0]:raise RuntimeError('Imported parent differs')
        for label,commit in [('S',S),('H',H)]:run('ancestor-'+label,['merge-base','--is-ancestor',commit,M],cwd=verify)
        native_diff=run('native-diff-raw',['diff','--raw','--no-abbrev','--no-renames',H,M])
        if run('offline-diff-raw',['diff','--raw','--no-abbrev','--no-renames',H,M],cwd=verify)!=native_diff:raise RuntimeError('Offline changed objects differ')
        native_stat=run('native-stat',['diff','--stat',H,M])
        if run('offline-stat',['diff','--stat',H,M],cwd=verify)!=native_stat:raise RuntimeError('Offline stat differs')
        history=run('native-commit-graph',['log','--format=%H %P %s',H+'..'+M])
        raw_dir=OUT/'native-history-commit-objects';raw_dir.mkdir()
        history_commits=[]
        for line in history.decode().splitlines():
            oid=line.split()[0];body=subprocess.check_output(PREFIX+['cat-file','commit',oid],cwd=SOURCE,env=ENV,timeout=20)
            if hashlib.sha1(b'commit '+str(len(body)).encode()+b'\0'+body).hexdigest()!=oid:raise RuntimeError('Native graph raw identity failed')
            path=raw_dir/(oid+'.commit');path.write_bytes(body);history_commits.append({'git_commit':oid,**pin(path)})
        if run('source-status-after',['status','--porcelain=v1','--untracked-files=all']):raise RuntimeError('Source status changed')
        if run('source-head-after',['rev-parse','HEAD','HEAD^{tree}']).decode().splitlines()!=[M,TREE]:raise RuntimeError('Source identity changed')
        result.update(passed=True,commits=commits,object_count=len(objects),pack=pin(pack),bundle=pin(OUT/'M6-over-S-H.bundle'),
            shallow_boundaries=pin(OUT/'shallow-boundaries.txt'),offline_verify_git=str(verify),native_history_commits=history_commits,
            limitations='New isolated verification/publishing repo has explicit S/H shallow boundaries; raw commit bytes/parents are unchanged. Full H..M6 history is independently retained as native raw commit sidecars, not inferred from the shallow walk. No remote/promisor/alternates or network Git protocol permitted.')
    except BaseException as exc:
        result.update(passed=False,failure=repr(exc))
    result['outer_wall_seconds']=time.monotonic()-started
    save(OUT/'RESULT.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['steps','native_history_commits']}),flush=True)
    if not result.get('passed'):sys.exit(1)


if __name__=='__main__':main()
