import gzip,hashlib,io,json,os,tarfile
from pathlib import Path
ROOT=Path('/Users/qianqi/work/cell-continuation-20261109-08b6')
SOURCE=ROOT/'post-M6-hosted-ci-read-002';OUT=ROOT/'post-M6-hosted-ci-seal-003'
def require(v,m):
    if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def encoded(o):return (json.dumps(o,sort_keys=True,indent=2)+'\n').encode()
def main():
    os.umask(0o077);OUT.mkdir(mode=0o700,exist_ok=False)
    snapshot=json.loads((SOURCE/'SNAPSHOT.json').read_text())
    require(snapshot['pr']['number']==5433 and snapshot['pr']['head']['sha']=='885dae0f3285267e9e9c49d8b43b0d009779f9e8' and snapshot['pr']['base']['sha']=='81da60b349e32d89d0e4c4674a517a66af7e5eee','Source differs')
    require([r['run']['id'] for r in snapshot['runs']]==[42565769665,42565757710],'Unexpected run scope')
    jobs=[job for r in snapshot['runs'] for job in r['jobs']]
    require(len(jobs)==8 and all(j['status']=='queued' and j['conclusion'] is None for j in jobs),'Pending receipt differs from observed jobs')
    require(snapshot['actual_checkout_verified'] is False and snapshot['actual_browser_execution_verified'] is False,'Metadata promoted into execution')
    connector=json.loads((ROOT/'post-M6-hosted-ci-read-002.CONNECTOR.json').read_text())
    terminal=json.loads(connector['terminal_response']['content'][0]['text'])
    require(terminal['job_id']=='1a1bec38798-5e21-264' and terminal['state']=='succeeded' and terminal['exit_code']==0 and terminal['output_complete'] is True,'Connector state differs')
    allowed={'CONTROLLER.py','SNAPSHOT.json'};files={}
    for call in snapshot['calls']:
        require(call['method']=='GET' and call['exit_code']==0,'Incomplete command')
        name=call['name'];allowed.update(name+'.'+suffix for suffix in ('intent.json','result.json','stdout','stderr'))
        intent=json.loads((SOURCE/(name+'.intent.json')).read_text())
        require(intent['method']=='GET' and intent['argv'][4:6]==['--method','GET'],'Unexpected mutation')
        for stream in ('stdout','stderr'):
            b=(SOURCE/(name+'.'+stream)).read_bytes()
            require(len(b)==call[stream]['bytes'] and sha(b)==call[stream]['sha256'],'Output bytes differ')
    require({p.name for p in SOURCE.iterdir()}==allowed and len(snapshot['calls'])==6,'Unexpected source members')
    for name in sorted(allowed):
        p=SOURCE/name;require(p.is_file() and not p.is_symlink(),'Nonregular member');files['snapshot002/'+name]=p.read_bytes()
    require(files['snapshot002/viewer.stdout'].strip()==b'ProfHepta','Reduced viewer differs')
    files['control/CONNECTOR.json']=encoded(connector);files['control/SEAL_CONTROLLER.py']=Path(__file__).read_bytes()
    files['control/SEAL_PREPARATION_FAILURE.json']=(ROOT/'post-M6-hosted-ci-seal-002.FAILURE.json').read_bytes()
    receipt={'schema':'hepta.M6.hosted-CI.final-pre-freeze-targeted-receipt.v1','observed_at_utc':snapshot['observed_at_utc'],'pr':5433,'source':'885dae0f3285267e9e9c49d8b43b0d009779f9e8','source_tree':'293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb','source_tree_provenance':'immutable commit GET in initial snapshot001; no runner checkout yet','base':'81da60b349e32d89d0e4c4674a517a66af7e5eee','runs':snapshot['runs'],'command_calls':6,'read_window_atomic':False,'wall_seconds':snapshot['wall_seconds'],'actual_checkout_verified':False,'actual_browser_execution_verified':False,'execution_logs_requested':0,'execution_logs_reason':'all eight selected jobs still queued; no completed execution logs available','hosted_CI_status':'PENDING_QUEUED','whole_CI_pass_claim':False,'science':'HOLD','production_adopted':False,'source_mutations':0,'github_mutations':0,'full_user_profile_collected':False,'host_hardware_inventory_collected':False,'snapshot_sha256':sha(files['snapshot002/SNAPSHOT.json']),'initial_metadata_archive_sha256':'aec14dac5c255feee77a45da0d81a66328efc67b80f1a83bfada59eb58f302bb'}
    files['RECEIPT.json']=encoded(receipt);files['README.zh-CN.md']=(ROOT/'post-M6-hosted-ci-read-002.README.zh-CN.md').read_bytes()
    manifest={'files':[{'path':n,'bytes':len(b),'sha256':sha(b),'scope':'two selected existing CI runs; GET command output and control receipt only'} for n,b in sorted(files.items())]}
    mb=encoded(manifest);archive=OUT/'M6_HOSTED_CI_PRE_FREEZE_TARGETED.tar.gz'
    with archive.open('xb') as output:
        with gzip.GzipFile(filename='',fileobj=output,mode='wb',mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for name,data in [*sorted(files.items()),('MANIFEST.json',mb)]:
                    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=info.uid=info.gid=0;tar.addfile(info,io.BytesIO(data))
        output.flush();os.fsync(output.fileno())
    with tarfile.open(archive,'r:gz') as verify:
        members=verify.getmembers();require(len(members)==len(files)+1 and len({m.name for m in members})==len(members),'Archive membership differs')
        for m in members:require(verify.extractfile(m).read()==(mb if m.name=='MANIFEST.json' else files[m.name]),'Archive bytes differ')
    for name,b in [('RECEIPT.json',files['RECEIPT.json']),('README.zh-CN.md',files['README.zh-CN.md']),('MANIFEST.json',mb)]:(OUT/name).write_bytes(b)
    result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(files)+1,'manifest_sha256':sha(mb),'receipt_sha256':sha(files['RECEIPT.json']),'observed_at_utc':snapshot['observed_at_utc'],'hosted_CI_status':'PENDING_QUEUED','logs_requested':0}
    (OUT/'DELIVERY.json').write_bytes(encoded(result));print(json.dumps(result),flush=True)
if __name__=='__main__':main()
