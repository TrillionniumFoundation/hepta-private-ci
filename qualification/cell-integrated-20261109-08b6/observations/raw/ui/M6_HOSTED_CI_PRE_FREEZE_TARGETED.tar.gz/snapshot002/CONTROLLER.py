"""Final pre-freeze read of exactly the existing UI and Cell runs; GET only."""
import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path('/Users/qianqi/work/cell-continuation-20261109-08b6')
OUT=ROOT/'post-M6-hosted-ci-read-002'
GH='/opt/homebrew/bin/gh';REPO='TrillionniumFoundation/hepta-private-ci'
M6='885dae0f3285267e9e9c49d8b43b0d009779f9e8';H='81da60b349e32d89d0e4c4674a517a66af7e5eee'
RUNS={42565769665:'.github/workflows/ui-product-foundation.yml',42565757710:'.github/workflows/hepta-cell-framework-native.yml'}
def require(v,m):
    if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,o):
    with p.open('x',encoding='utf-8') as f:json.dump(o,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def main():
    os.umask(0o077);OUT.mkdir(mode=0o700,exist_ok=False)
    (OUT/'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
    env=dict(os.environ)
    for key in ('GH_DEBUG','GH_HOST','GIT_TRACE','GIT_TRACE_CURL'):env.pop(key,None)
    env.update(GH_PROMPT_DISABLED='1',GH_PAGER='cat')
    calls=[];begin=time.monotonic()
    def api(name,endpoint,jq):
        argv=[GH,'api','--hostname','github.com','--method','GET',endpoint,'--jq',jq]
        save(OUT/(name+'.intent.json'),{'method':'GET','argv':argv,'timeout_seconds':60,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        start=time.monotonic();code=None;error=None
        with (OUT/(name+'.stdout')).open('xb') as stdout,(OUT/(name+'.stderr')).open('xb') as stderr:
            try:code=subprocess.run(argv,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=60).returncode
            except (OSError,subprocess.TimeoutExpired) as exc:error=type(exc).__name__+': '+str(exc)
            for f in (stdout,stderr):f.flush();os.fsync(f.fileno())
        row={'name':name,'method':'GET','exit_code':code,'error':error,'state':'RETURNED' if code is not None else 'UNKNOWN','wall_seconds':time.monotonic()-start}
        for key in ('stdout','stderr'):
            raw=(OUT/(name+'.'+key)).read_bytes();row[key]={'bytes':len(raw),'sha256':sha(raw)}
        save(OUT/(name+'.result.json'),row);calls.append(row)
        require(code==0,'GET failed: '+name)
        return (OUT/(name+'.stdout')).read_text()
    require(api('viewer','user','.login').strip()=='ProfHepta','Viewer differs')
    pr=json.loads(api('pr','repos/'+REPO+'/pulls/5433','{number,state,draft,author:.user.login,head:{sha:.head.sha,ref:.head.ref,repo:.head.repo.full_name},base:{sha:.base.sha,ref:.base.ref,repo:.base.repo.full_name},merge_commit_sha,updated_at}'))
    require(pr['number']==5433 and pr['state']=='open' and pr['draft'] is True and pr['author']=='ProfHepta' and pr['head']['sha']==M6 and pr['base']['sha']==H and pr['head']['repo']==REPO and pr['base']['repo']==REPO,'PR changed')
    results=[]
    for runid,path in RUNS.items():
        run=json.loads(api('run-'+str(runid),'repos/'+REPO+'/actions/runs/'+str(runid),'{id,name,path,event,status,conclusion,head_branch,head_sha,run_attempt,created_at,updated_at,html_url}'))
        require(run['id']==runid and run['head_sha']==M6 and run['path']==path,'Run identity differs')
        jobs=json.loads(api('jobs-'+str(runid),'repos/'+REPO+'/actions/runs/'+str(runid)+'/jobs?per_page=100&filter=latest','{total_count,jobs:[.jobs[]|{id,run_id,run_attempt,head_sha,name,status,conclusion,started_at,completed_at,html_url,steps:[.steps[]|{name,status,conclusion,number,started_at,completed_at}]}]}'))
        require(jobs['total_count']<=100,'Unexpected job pagination')
        results.append({'run':run,'jobs':jobs['jobs']})
    report={'schema':'hepta.M6.hosted-CI.pre-freeze-targeted-metadata.v1','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':pr,'runs':results,'calls':calls,'wall_seconds':time.monotonic()-begin,'read_window_atomic':False,'actual_checkout_verified':False,'actual_browser_execution_verified':False,'new_github_mutations':0}
    save(OUT/'SNAPSHOT.json',report)
    print(json.dumps({'root':str(OUT),'observed_at_utc':report['observed_at_utc'],'wall_seconds':report['wall_seconds'],'runs':[{'run':r['run'],'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'failed_steps':[s['name'] for s in j['steps'] if s['conclusion'] in ('failure','cancelled','timed_out')]} for j in r['jobs']]} for r in results]}),flush=True)
if __name__=='__main__':main()
