# M6 证据冻结前的定向托管 CI 观察

观测完成时间：2026-11-09T05:24:18.389009+00:00。6 个顺序 GET 的外层窗口为 10.466975042 秒；各请求开始时间与命令输出原件保留。这不是原子时间点快照，也不代表此后状态。

source PR #5433 仍为 ProfHepta 的 open draft，head M6 `885dae0f3285267e9e9c49d8b43b0d009779f9e8`、base H `81da60b349e32d89d0e4c4674a517a66af7e5eee`。精确源码 tree 的 GitHub commit 回读已在初次快照中保留；它不代替尚未发生的 runner checkout。

UI run 42565769665（pull_request，attempt 1）五个 jobs 全部 queued，包括 source-head 与 base-merge 两条完整浏览器 lane、两条 native-presentation lane 和锁提案。Cell run 42565757710（push，attempt 1）三项 jobs 也全部 queued。所有 conclusion 为 null。

没有已完成的执行日志可取，因此没有请求空日志，也没有推出受测 checkout、tree、测试数、三浏览器通过或全 CI 通过。记录为 PENDING_QUEUED；本地 Firefox 与原生测试保留其独立已证范围。原科学 HOLD、生产未采用均不变。

本包只含这两条既有 run 的安全精简元数据、GET intent/result、控制器及 h 权威 succeeded/exit0 回执；没有完整 /user、任何主机硬件清单、dispatch、rerun、cancel、GitHub 写入或新测试。初始 15-workflow 快照继续保留在独立包 aec14dac5c255feee77a45da0d81a66328efc67b80f1a83bfada59eb58f302bb 中。本轮按冻结计划结束观察，不预写未来通过。
