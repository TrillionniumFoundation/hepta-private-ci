"""Fetch exactly three completed jobs through the original Mac GitHub identity."""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import tarfile
import time

ROOT = Path("/Users/qianqi/work/cell-continuation-20261109-08b6/targeted-ci-read-001")
REPO = "TrillionniumFoundation/hepta-private-ci"
S = "693a013b254d07779f6f2b2a78d0ee31481f4ea9"
H = "81da60b349e32d89d0e4c4674a517a66af7e5eee"
JOBS = {
    128871499102: (42526574689, S, "failure"),
    128872055455: (42526700562, H, "success"),
    128872055457: (42526700562, H, "failure"),
    128871800688: (42526700342, H, "failure"),
}
ENV = os.environ.copy()
for key in ("GH_DEBUG", "GH_HOST"):
    ENV.pop(key, None)


def require(value, message):
    if not value:
        raise RuntimeError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def pin(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": digest.hexdigest(),
    }


def dump(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def limit_output():
    resource.setrlimit(resource.RLIMIT_FSIZE, (96 * 1024 * 1024, 96 * 1024 * 1024))


def fetch(name, endpoint, *, include=False, jq=None, timeout=180):
    directory = ROOT / name
    directory.mkdir(mode=0o700, exist_ok=False)
    args = [
        "/opt/homebrew/bin/gh",
        "api",
        "--hostname",
        "github.com",
        "--method",
        "GET",
    ]
    if include:
        args.append("--include")
    if jq:
        args += ["--jq", jq]
    args.append(endpoint)
    row = {
        "name": name,
        "endpoint": endpoint,
        "method": "GET",
        "argv": args,
        "started_at_utc": now(),
        "timeout_seconds": timeout,
        "gh_debug_removed": True,
        "state": "INTENT",
        "source_or_github_mutation": False,
    }
    dump(directory / "intent.json", row)
    start = time.monotonic()
    with (
        (directory / "stdout.bin").open("xb") as out,
        (directory / "stderr.bin").open("xb") as err,
    ):
        try:
            proc = subprocess.run(
                args,
                stdout=out,
                stderr=err,
                env=ENV,
                timeout=timeout,
                check=False,
                preexec_fn=limit_output,
            )
            row.update(
                exit_code=proc.returncode,
                state="COMPLETED" if proc.returncode == 0 else "FAILED",
            )
        except subprocess.TimeoutExpired:
            row.update(exit_code=None, state="TIMEOUT_UNKNOWN_COMPLETENESS")
    row.update(
        finished_at_utc=now(),
        wall_seconds=time.monotonic() - start,
        stdout=pin(directory / "stdout.bin"),
        stderr=pin(directory / "stderr.bin"),
    )
    dump(directory / "result.json", row)
    require(
        row["state"] == "COMPLETED", name + " fetch failed; original bytes retained"
    )
    raw = (directory / "stdout.bin").read_bytes()
    require(0 < len(raw) < 96 * 1024 * 1024, "Missing or oversized output")
    if include:
        normalized = raw.replace(b"\r\n", b"\n")
        header, body = normalized.split(b"\n\n", 1)
        status = re.match(rb"HTTP/\S+ (\d+)", header)
        require(
            status and status.group(1) == b"200", "Expected HTTP 200 metadata response"
        )
        return json.loads(body), row
    return raw, row


def one(job_id):
    job, metadata = fetch(
        "metadata-" + str(job_id),
        f"repos/{REPO}/actions/jobs/{job_id}",
        include=True,
        timeout=40,
    )
    require(
        job["id"] == job_id
        and job["run_id"] == JOBS[job_id][0]
        and job["run_attempt"] == 1
        and job["status"] == "completed"
        and job["conclusion"] == JOBS[job_id][2]
        and job["head_sha"] == JOBS[job_id][1],
        "Job identity/status differs from requested snapshot",
    )
    dump(ROOT / ("job-" + str(job_id) + ".json"), job)
    raw, log_fetch = fetch(
        "log-" + str(job_id), f"repos/{REPO}/actions/jobs/{job_id}/logs"
    )
    text = raw.decode("utf-8-sig")
    lines = text.splitlines()
    plain = [
        re.sub(r"^\d{4}-\d\d-\d\dT\S+\s*", "", re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", s))
        for s in lines
    ]
    checkout = []
    for i, line in enumerate(plain):
        if re.search(r"git\s+log\s+-1\s+--format=", line):
            for j in range(i + 1, min(i + 5, len(lines))):
                if re.fullmatch(r"['\"]?[0-9a-f]{40}['\"]?", plain[j].strip()):
                    checkout.append(
                        {
                            "command_line": i + 1,
                            "line": j + 1,
                            "sha": plain[j].strip("'\""),
                            "command": lines[i],
                            "response": lines[j],
                        }
                    )
    marked = []
    for i, line in enumerate(plain):
        if re.search(
            r"^error\[|^ERROR:|^FAIL:|^FAILED|##\[error\]|^failures:|^test result: FAILED|advisories FAILED|Process completed with exit code",
            line,
        ):
            marked.append({"line": i + 1, "text": lines[i]})
    error_positions = [x["line"] - 1 for x in marked]
    contexts = sorted(
        {
            j
            for i in error_positions
            for j in range(max(0, i - 2), min(len(lines), i + 12))
        }
    )
    extract = {
        "job_id": job_id,
        "job_conclusion": job["conclusion"],
        "job_name": job["name"],
        "line_count": len(lines),
        "workflow_head_sha_metadata_only": job["head_sha"],
        "checkout_from_git_log": checkout,
        "failed_steps": [
            s for s in job.get("steps", []) if s.get("conclusion") == "failure"
        ],
        "failure_lines": marked,
        "failure_context": [{"line": i + 1, "text": lines[i]} for i in contexts],
        "advisory_ids": sorted(set(re.findall(r"ID: (RUSTSEC-\d+-\d+)", text))),
        "raw_log": log_fetch["stdout"],
        "raw_log_scope": "Complete bytes emitted by successful original-Mac gh GET /actions/jobs/{id}/logs after gh handles the API redirect; not a ZIP/wire-byte hash.",
        "fetch": log_fetch,
        "metadata_fetch": metadata,
    }
    dump(ROOT / ("EXTRACT-" + str(job_id) + ".json"), extract)
    print(
        json.dumps(
            {
                "job_id": job_id,
                "checkout": checkout,
                "failed_steps": extract["failed_steps"],
                "raw_log": extract["raw_log"],
                "failure_lines_count": len(marked),
                "advisory_ids": extract["advisory_ids"],
            }
        ),
        flush=True,
    )
    return extract


def main():
    os.umask(0o077)
    require(
        ROOT.is_dir() and not (ROOT / "FETCH_SUMMARY.json").exists(),
        "Unique fetch directory missing",
    )
    started = now()
    (ROOT / "CONTROLLER.py").write_bytes(Path(__file__).read_bytes())
    raw, identity = fetch("identity", "user", jq=".login", timeout=40)
    require(raw.decode().strip() == "ProfHepta", "Original GitHub viewer differs")
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(one, JOBS))
    observed = sorted({x["sha"] for r in results for x in r["checkout_from_git_log"]})
    require(
        all(r["checkout_from_git_log"] for r in results),
        "At least one actual checkout is unproven",
    )
    commit_pins = []
    for sha in observed:
        commit, receipt = fetch(
            "checkout-commit-" + sha,
            f"repos/{REPO}/git/commits/{sha}",
            include=True,
            timeout=40,
        )
        require(commit["sha"] == sha, "Checkout commit response differs")
        dump(ROOT / ("checkout-commit-" + sha + ".json"), commit)
        commit_pins.append(
            {
                "commit": sha,
                "tree": commit["tree"]["sha"],
                "parents": [x["sha"] for x in commit["parents"]],
                "receipt": receipt,
            }
        )
    summary = {
        "schema": "hepta.continuation-four-targeted-job-fetch.v1",
        "viewer": "ProfHepta",
        "repository": REPO,
        "started_at_utc": started,
        "finished_at_utc": now(),
        "requested_source_heads": {str(k): list(v) for k, v in JOBS.items()},
        "requested_jobs": list(JOBS),
        "all_calls_get": True,
        "source_or_github_mutation": False,
        "workflow_head_not_used_as_checkout_proof": True,
        "identity_fetch": identity,
        "checkout_commits": commit_pins,
        "jobs": [
            {
                "job_id": r["job_id"],
                "name": r["job_name"],
                "raw_log": r["raw_log"],
                "fetch": r["fetch"],
                "metadata_fetch": r["metadata_fetch"],
            }
            for r in results
        ],
    }
    dump(ROOT / "FETCH_SUMMARY.json", summary)
    members = [p for p in sorted(ROOT.rglob("*")) if p.is_file()]
    manifest = {
        "schema": "hepta.failed-job-raw-log-manifest.v1",
        "files": [pin(p) for p in members],
        "scope": "Four requested completed jobs only; S deny, H deny, H build-test and H UI source-head. No other CI logs.",
    }
    dump(ROOT / "MANIFEST.json", manifest)
    archive = ROOT.parent / "targeted-ci-read-001-raw.tar.gz"
    with (
        archive.open("xb") as out,
        gzip.GzipFile(filename="", fileobj=out, mode="wb", mtime=0) as gz,
        tarfile.open(fileobj=gz, mode="w", format=tarfile.PAX_FORMAT) as tar,
    ):
        for path in [*members, ROOT / "MANIFEST.json"]:
            item = tarfile.TarInfo(path.relative_to(ROOT).as_posix())
            item.size = path.stat().st_size
            item.mtime = item.uid = item.gid = 0
            item.mode = 0o600
            with path.open("rb") as stream:
                tar.addfile(item, stream)
    print(
        json.dumps(
            {
                "archive_path": str(archive),
                "bytes": archive.stat().st_size,
                "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                "members": len(members) + 1,
                "checkout_commits": commit_pins,
                "completed": True,
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
