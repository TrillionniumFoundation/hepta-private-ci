"""Seal existing bounded CI captures, preserving incomplete transfers."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile
import time

PARENT=Path('/Users/qianqi/work/cell-continuation-20261109-08b6')
OLD=PARENT/'targeted-ci-read-001'
OUT=PARENT/'targeted-ci-seal-001'
JOBS=[128871499102,128872055455,128872055457,128871800688]
REPO='TrillionniumFoundation/hepta-private-ci'
ENV=os.environ.copy()
for key in ['GH_DEBUG','GH_HOST']:ENV.pop(key,None)

def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,value):path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def fetch(name,endpoint):
    args=['/opt/homebrew/bin/gh','api','--hostname','github.com','--method','GET',endpoint]
    row={'argv':args,'method':'GET','started_at_utc':datetime.now(timezone.utc).isoformat(),'timeout_seconds':40}
    save(OUT/(name+'.intent.json'),row)
    start=time.monotonic()
    proc=subprocess.run(args,env=ENV,capture_output=True,timeout=40,check=False)
    for key,data in [('stdout',proc.stdout),('stderr',proc.stderr)]:
        (OUT/(name+'.'+key)).write_bytes(data)
        row[key]={'bytes':len(data),'sha256':sha(data)}
    row.update(exit_code=proc.returncode,wall_seconds=time.monotonic()-start)
    save(OUT/(name+'.result.json'),row)
    if proc.returncode:raise RuntimeError(name+' read failed')
    return json.loads(proc.stdout)

def main():
    os.umask(0o077)
    OUT.mkdir(mode=0o700,exist_ok=False)
    (OUT/'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
    viewer=fetch('viewer','user')
    if viewer.get('login')!='ProfHepta':raise RuntimeError('Wrong viewer')
    rows=[]
    for job in JOBS:
        raw=(OLD/f'log-{job}/stdout.bin').read_bytes()
        receipt=json.loads((OLD/f'log-{job}/result.json').read_text())
        if len(raw)!=receipt['stdout']['bytes'] or sha(raw)!=receipt['stdout']['sha256']:
            raise RuntimeError('Original capture changed')
        metadata=json.loads((OLD/f'job-{job}.json').read_text())
        lines=raw.decode('utf-8',errors='replace').splitlines()
        plain=[re.sub(r'^\d{4}-\d\d-\d\dT\S+\s*','',re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',s)) for s in lines]
        checkouts=[]
        for i,s in enumerate(plain):
            if re.search(r'git\s+log\s+-1\s+--format=',s):
                for j in range(i+1,min(len(lines),i+5)):
                    if re.fullmatch("['\"]?[0-9a-f]{40}['\"]?",plain[j].strip()):
                        checkouts.append({'command_line':i+1,'response_line':j+1,'sha':plain[j].strip("'\""),'raw_command':lines[i],'raw_response':lines[j]})
        rows.append({'job_id':job,'job_status':metadata['status'],'job_conclusion_metadata_only':metadata['conclusion'],'metadata_head_not_checkout':metadata['head_sha'],'capture_state':receipt['state'],'complete':receipt['state']=='COMPLETED','raw_bytes':len(raw),'raw_sha256':sha(raw),'checkouts':checkouts,'observed_advisory_ids':sorted(set(re.findall(r'RUSTSEC-\d{4}-\d+',raw.decode('utf-8',errors='replace'))))})
        if job==128871800688:
            detail='\n'.join(f'{i+1}: {lines[i]}' for i in range(12000,min(12630,len(lines))))+'\n'
            (OUT/'H_UI_FAILURE_DETAIL.txt').write_text(detail)
    commits=[]
    for commit in sorted({c['sha'] for r in rows for c in r['checkouts']}):
        obj=fetch('commit-'+commit,f'repos/{REPO}/git/commits/{commit}')
        if obj['sha']!=commit:raise RuntimeError('Commit response mismatch')
        commits.append({'commit':commit,'tree':obj['tree']['sha'],'parents':[p['sha'] for p in obj['parents']]})
    summary={'schema':'hepta.targeted-ci.partial-capture-seal.v1','viewer':'ProfHepta','collector_job':'1a1be16f13b-138b0-85a','collector_terminal':'failed','collector_failure':'Two 180 second deny log GETs timed out; H format/UI captures complete. No execution conclusions inferred from truncated deny bytes.','jobs':rows,'commit_bindings':commits,'source_or_github_mutations':False,'all_new_remote_calls':'GET commits and viewer only; no additional CI log fetch or execution','source_root':str(OLD)}
    save(OUT/'SUMMARY.json',summary)
    members={}
    for prefix,root in [('attempt001',OLD),('seal001',OUT)]:
        for path in sorted(root.rglob('*')):
            if path.is_file():
                if path.is_symlink():raise RuntimeError('Unexpected symlink')
                members[prefix+'/'+path.relative_to(root).as_posix()]=path.read_bytes()
    manifest={'files':[{'path':p,'bytes':len(d),'sha256':sha(d)} for p,d in members.items()], 'scope':'Four already requested jobs only; timeout captures retained as incomplete; no other-task inventory.'}
    manifest_bytes=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
    archive=PARENT/'targeted-ci-partial-capture-evidence.tar.gz'
    with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
        for name,data in [*members.items(),('MANIFEST.json',manifest_bytes)]:
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=info.uid=info.gid=0
            tar.addfile(info,io.BytesIO(data))
    result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(members)+1,'summary':summary}
    save(OUT/'DELIVERY.json',result)
    print(json.dumps(result),flush=True)

if __name__=='__main__':main()
