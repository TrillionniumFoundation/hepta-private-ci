# -*- coding: utf-8 -*-
"""Repackage four retained CI jobs through an exact file allowlist; no network."""
import datetime,gzip,hashlib,io,json,os,re,tarfile,time
from pathlib import Path,PurePosixPath
ROOT=Path('/Users/qianqi/work/cell-continuation-20261109-08b6')
SOURCE=ROOT/'targeted-ci-partial-capture-evidence.tar.gz'
OUT=ROOT/'targeted-ci-safe-native-seal-003'
JOBS=[128871499102,128872055455,128872055457,128871800688]
COMMITS=['782e8c8e37898d2e72d164085375dd9f5acd303e','7d91ebfd0d27354bb549deb4558de6c8ae433616','81da60b349e32d89d0e4c4674a517a66af7e5eee']
def require(v,m):
    if not v: raise RuntimeError(m)
def sha(b): return hashlib.sha256(b).hexdigest()
def encoded(o): return (json.dumps(o,sort_keys=True,indent=2)+'\n').encode()
def main():
    os.umask(0o077)
    begin=time.monotonic()
    OUT.mkdir(mode=0o700,exist_ok=False)
    source=SOURCE.read_bytes()
    require(len(source)==1919047 and sha(source)=='32f89dd8f02f5b8bb0b33ad74a5b8a7907226a0f9bf5d5d3dc73c56bea3715eb','Source differs')
    allowed={'attempt001/CONTROLLER.py','attempt001/EXTRACT-128871800688.json','attempt001/EXTRACT-128872055457.json'}
    allowed.update('attempt001/identity/'+x for x in ('intent.json','result.json','stderr.bin','stdout.bin'))
    for job in JOBS:
        allowed.add('attempt001/job-'+str(job)+'.json')
        for scope in ('log','metadata'):
            allowed.update('attempt001/'+scope+'-'+str(job)+'/'+x for x in ('intent.json','result.json','stderr.bin','stdout.bin'))
    allowed.update('seal001/'+x for x in ('CONTROLLER.py','H_UI_FAILURE_DETAIL.txt','SUMMARY.json'))
    for commit in COMMITS:
        allowed.update('seal001/commit-'+commit+'.'+x for x in ('intent.json','result.json','stderr','stdout'))
    payload={}
    with tarfile.open(fileobj=io.BytesIO(source),mode='r:gz') as archive:
        members=archive.getmembers()
        names=[x.name for x in members]
        require(len(names)==len(set(names))==63,'Duplicate/unexpected old members')
        for item in members:
            path=PurePosixPath(item.name)
            require(item.isfile() and not path.is_absolute() and '..' not in path.parts and 0<=item.size<12*1024*1024,'Invalid member')
        require(allowed.issubset(names),'Missing approved files')
        oldmanifest=json.load(archive.extractfile('MANIFEST.json'))
        oldpins={row['path']:row for row in oldmanifest['files']}
        for name in sorted(allowed):
            value=archive.extractfile(name).read()
            require(oldpins[name]['bytes']==len(value) and oldpins[name]['sha256']==sha(value),'Original payload differs: '+name)
            payload[name]=value
    require(payload['attempt001/identity/stdout.bin'].strip()==b'ProfHepta','Original reduced identity differs')
    summary=json.loads(payload['seal001/SUMMARY.json'])
    require([row['job_id'] for row in summary['jobs']]==JOBS,'Job scope differs')
    require([row['complete'] for row in summary['jobs']]==[False,False,True,True],'Capture completeness differs')
    forbidden=[rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{50,}',rb'AKIA[A-Z0-9]{16}',rb'-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----']
    for name,value in payload.items():
        require(not any(re.search(pattern,value) for pattern in forbidden),'Credential-like payload; do not publish: '+name)
        if name.endswith('.json'):
            require(not any(key in value for key in (b'"private_gists"',b'"total_private_repos"',b'"disk_usage"',b'"two_factor_authentication"')),'Full user-profile fields found')
    excluded=sorted(set(names)-allowed-{'MANIFEST.json'})
    require(excluded==['seal001/viewer.intent.json','seal001/viewer.result.json','seal001/viewer.stderr','seal001/viewer.stdout'],'Unexpected exclusion')
    terminal=json.loads((ROOT/'targeted-ci-safe-native-original-collector-terminal.json').read_text())
    require(terminal['job_id']=='1a1be16f13b-138b0-85a' and terminal['state']=='failed' and terminal['exit_code']==1 and terminal['output_complete'] is True,'Collector receipt differs')
    profile={'schema':'hepta.targeted-ci.safe-native-reseal.v1','original_private_archive':{'path':str(SOURCE),'bytes':len(source),'sha256':sha(source),'included':False},'excluded_original_members':excluded,'source_payload_files':len(allowed),'source_payload_bytes':sum(map(len,payload.values())),'jobs':summary['jobs'],'original_collector_terminal':'failed/exit1; two log transfers timed out','previous_cloud_safe_archive':{'bytes':1920113,'sha256':'44de5d072f8a16a41c2a9a6553f5216e67b75f3361fca7b6275d6b98f00b1e8f','availability':'Cloud executor currently unavailable; not represented as this archive'},'new_github_calls':0,'new_ci_or_tests':0,'credentials_pattern_matches':0,'complete_user_profile_included':False,'source_payload_bytes_preserved':True,'no_archive_extraction':True,'scientific_gain_established':False}
    payload['reseal001/FILTER_PROFILE.json']=encoded(profile)
    payload['reseal001/ORIGINAL_COLLECTOR_TERMINAL.json']=encoded(terminal)
    payload['reseal001/PREPARATION_FAILURES.json']=(ROOT/'targeted-ci-safe-native-preparation-failures.json').read_bytes()
    payload['reseal001/CONTROLLER.py']=Path(__file__).read_bytes()
    payload['README.zh-CN.md']=('''# 四项历史 CI 原件的安全重封版

范围仅原来已请求的四个 job。S deny 与 H deny 的下载因 180 秒上限中断，保留完整已收到 bytes，但完整性为 unknown；不能从这两份部分日志推出完整安全检查结果。H format 与 source-head UI 日志完整。实际 checkout 取原日志中的 git log 响应，并单独保存提交对象的只读回执；workflow head 元数据不代替 checkout。

此包从固定 SHA 的原始私有归档按精确 58 文件白名单读取，不把旧归档嵌套打包，不在磁盘解压。排除旧 seal001/viewer.* 四文件，包括完整 /user 资料；只保留最初已经 --jq 缩减为 ProfHepta 的身份回执。没有用户主机全量 inventory，没有 token/env 导出。原始 CI 日志可含托管 runner 的一般构建能力信息。

所有保留原件的内容、大小、SHA 与旧 manifest 逐项核对；各 stdout/stderr 未编辑。原 collector 的失败权威终态也保留。此操作没有重新抓取 GitHub 日志、运行 CI、测试或写 GitHub。

先前 44de5d… / 1,920,113 B 的安全包在当前不可读的 cloud 环境。本包是从相同原件新建的独立重封版，有自己的 SHA；不声称与它字节相等。失败、部分传输及其成本不因重封而消失。这里只支持历史诊断，不计入 M6 共同测试分母、科学收益或生产采用。
''').encode()
    manifest={'schema':'hepta.exact-payload-manifest.v1','files':[{'path':name,'bytes':len(value),'sha256':sha(value),'scope':'original_targeted_ci_capture' if name in allowed else 'safe_reseal_control'} for name,value in sorted(payload.items())]}
    mb=encoded(manifest)
    archive_path=OUT/'targeted-ci-safe-native-evidence.tar.gz'
    with archive_path.open('xb') as output:
        with gzip.GzipFile(filename='',fileobj=output,mode='wb',mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for name,value in [*sorted(payload.items()),('MANIFEST.json',mb)]:
                    info=tarfile.TarInfo(name);info.size=len(value);info.mode=0o600;info.mtime=info.uid=info.gid=0
                    tar.addfile(info,io.BytesIO(value))
        output.flush();os.fsync(output.fileno())
    with tarfile.open(archive_path,'r:gz') as verify:
        items=verify.getmembers()
        require(len(items)==len(payload)+1 and len({x.name for x in items})==len(items),'New manifest mismatch')
        for item in items:
            value=verify.extractfile(item).read()
            require(value==(mb if item.name=='MANIFEST.json' else payload[item.name]),'Repack verification failed')
    for name,value in [('MANIFEST.json',mb),('FILTER_PROFILE.json',payload['reseal001/FILTER_PROFILE.json']),('README.zh-CN.md',payload['README.zh-CN.md'])]:
        with (OUT/name).open('xb') as stream:stream.write(value);stream.flush();os.fsync(stream.fileno())
    result={'archive':str(archive_path),'bytes':archive_path.stat().st_size,'sha256':sha(archive_path.read_bytes()),'members':len(payload)+1,'original_payload_members':len(allowed),'manifest_sha256':sha(mb),'filter_profile_sha256':sha(payload['reseal001/FILTER_PROFILE.json']),'wall_seconds':time.monotonic()-begin,'no_network_or_source_changes':True,'original_payload_preserved':True,'new_archive_not_byte_equal_to_cloud_original':True,'credential_pattern_matches':0,'excluded_full_user_response':True}
    with (OUT/'DELIVERY.json').open('xb') as stream:stream.write(encoded(result));stream.flush();os.fsync(stream.fileno())
    descriptor=os.open(OUT,os.O_RDONLY);os.fsync(descriptor);os.close(descriptor)
    print(json.dumps(result),flush=True)
if __name__=='__main__':main()
