"""Real negative/positive regression and a three-file isolated UI commit."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
SOURCE=ROOT/'sidebar-geometry-fix-source'
OUT=ROOT/'sidebar-geometry-fix-001/red-green'
BASE='cb5c06441ae6a23b53af55b3e9e4aa6efb3fe1ed'
os.umask(0o077);OUT.mkdir(mode=0o700,exist_ok=False)
(OUT/'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
payload=json.loads((ROOT/'SIDEBAR_PATCH_INPUT.json').read_text())
(OUT/'PATCH_INPUT.json').write_bytes((ROOT/'SIDEBAR_PATCH_INPUT.json').read_bytes())
env=os.environ.copy()
env.update(RUSTUP_TOOLCHAIN='1.95.0',CARGO_TERM_COLOR='never',PYTHONDONTWRITEBYTECODE='1')
env['PATH']='/home/qian-qi/work/cell-rsi-p0p2-20261108-858e/tools/uv-0.11.3:/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/bin:/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/.cargo/bin:'+env.get('PATH','')
steps=[];start=time.monotonic()
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=SOURCE).decode()
def save(name,value):
 with (OUT/name).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def state():return {'head':git('rev-parse','HEAD').strip(),'tree':git('rev-parse','HEAD^{tree}').strip(),'status':git('status','--porcelain=v1')}
def run(label,args,cwd=SOURCE):
 row={'label':label,'argv':list(map(str,args)),'cwd':str(cwd),'started_at_utc':datetime.now(timezone.utc).isoformat()};save(label+'.intent.json',row)
 begin=time.monotonic()
 with (OUT/(label+'.stdout')).open('xb') as out,(OUT/(label+'.stderr')).open('xb') as err:
  p=subprocess.run(row['argv'],cwd=cwd,env=env,stdout=out,stderr=err)
 row.update(exit_code=p.returncode,wall_seconds=time.monotonic()-begin,finished_at_utc=datetime.now(timezone.utc).isoformat())
 for name in ['stdout','stderr']:
  path=OUT/(label+'.'+name);data=path.read_bytes();row[name]={'path':str(path),'bytes':len(data),'sha256':sha(data)}
 save(label+'.result.json',row);steps.append(row);print(json.dumps(row),flush=True)
 return p.returncode
result={'schema':'hepta.sidebar-geometry.fix.v1','base':BASE,'started_at_utc':datetime.now(timezone.utc).isoformat(),'steps':steps,'scientific_benefit':False,'production_qualification':False}
ok=False
try:
 result['before']=state()
 if result['before']['head']!=BASE or result['before']['status']:raise RuntimeError('Expected clean M4 base')
 for f in payload['files']:
  if sha((SOURCE/f['path']).read_bytes())!=f['old_sha256']:raise RuntimeError('Source before pin mismatch: '+f['path'])
 unit=next(f for f in payload['files'] if f['path'].endswith('robrix-pixel-plan.test.mjs'))
 (SOURCE/unit['path']).write_text(unit['content'])
 result['red_source']=state()
 if run('red-unit',['node','--test','test/robrix-pixel-plan.test.mjs'],SOURCE/'apps/hepta-control-ui')==0:
  raise RuntimeError('Actual fractional viewport regression did not fail old checker')
 for f in payload['files']:(SOURCE/f['path']).write_text(f['content'])
 if run('green-unit',['node','--test','test/robrix-pixel-plan.test.mjs'],SOURCE/'apps/hepta-control-ui'):
  raise RuntimeError('Geometry unit controls failed')
 if run('just-fmt',['just','fmt'],SOURCE/'codex-rs'):raise RuntimeError('just fmt failed')
 if run('diff-check',['git','diff','--check']):raise RuntimeError('Whitespace check failed')
 for f in payload['files']:
  if sha((SOURCE/f['path']).read_bytes())!=f['new_sha256']:raise RuntimeError('Unexpected formatted bytes: '+f['path'])
 if set(git('diff','--name-only').splitlines())!={f['path'] for f in payload['files']}:raise RuntimeError('Unexpected scope')
 stats=git('diff','--numstat')
 if sum(int(n) for row in stats.splitlines() for n in row.split('\t')[:2])>=800:raise RuntimeError('Stage exceeds 800-line bound')
 result['numstat']=stats
 if run('stage',['git','add','--',*[f['path'] for f in payload['files']]]):raise RuntimeError('Stage failed')
 if run('commit',['git','commit','-m','fix(ui): bind sidebar viewport checks to physical pixels']):raise RuntimeError('Commit failed')
 result['after']=state()
 if result['after']['status'] or git('rev-parse','HEAD^').strip()!=BASE:raise RuntimeError('Frozen source mismatch')
 (OUT/'PATCH.diff').write_text(git('show','--format=fuller','--no-ext-diff','HEAD'))
 ok=True
except BaseException as exc:result['failure']=type(exc).__name__+': '+str(exc)
finally:
 result.update(passed=ok,outer_wall_seconds=time.monotonic()-start,finished_at_utc=datetime.now(timezone.utc).isoformat())
 save('RESULT.json',result);print(json.dumps({'passed':ok,'after':result.get('after'),'failure':result.get('failure')}),flush=True)
if not ok:raise SystemExit(1)
