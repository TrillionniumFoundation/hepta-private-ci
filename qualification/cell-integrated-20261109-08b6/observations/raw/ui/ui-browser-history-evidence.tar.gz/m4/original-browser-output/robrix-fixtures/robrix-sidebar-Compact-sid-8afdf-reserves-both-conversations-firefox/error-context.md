# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: robrix-sidebar.spec.mjs >> Compact sidebar creates once and preserves both conversations
- Location: e2e/robrix-sidebar.spec.mjs:11:1

# Error details

```
AssertionError: Canvas CSS bounds must match the full capture viewport
+ actual - expected

  {
+   height: 799.7999877929688,
+   width: 640.2000122070312,
-   height: 800,
-   width: 640,
    x: 0,
    y: 0
  }

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic "Hepta conversations" [ref=e2]
  - textbox [active] [ref=e3]
```

# Test source

```ts
  1  | // Fixture evidence validation only. Never writes app state or controls rendering.
  2  | import assert from 'node:assert/strict';
  3  | export function validateSidebarSurface({viewport,metrics,drawDpiFactor,pngSize}){
  4  |  assert.ok([viewport.width,viewport.height].every(value=>Number.isInteger(value)&&value>0),'Viewport must be positive integer CSS dimensions');
> 5  |  assert.deepEqual(metrics.css,{x:0,y:0,...viewport},'Canvas CSS bounds must match the full capture viewport');
     |         ^ AssertionError: Canvas CSS bounds must match the full capture viewport
  6  |  assert.ok(Number.isFinite(metrics.dpr)&&metrics.dpr>0,'Browser DPR must be finite and positive');
  7  |  assert.ok(Number.isFinite(drawDpiFactor)&&drawDpiFactor>0&&drawDpiFactor<=metrics.dpr,'Real Rust draw-pass DPI must be positive and bounded by browser DPR');
  8  |  // Pinned web.js budgets the drawable and floors physical dimensions, then
  9  |  // sends the same effective scale to Rust in window_info.dpi_factor. PNGs use
  10 |  // the browser device scale independently; neither scale is inferred from text.
  11 |  assert.deepEqual(metrics.buffer,{width:Math.floor(viewport.width*drawDpiFactor),height:Math.floor(viewport.height*drawDpiFactor)},'Backing dimensions must agree with the observed Rust draw-pass DPI');
  12 |  assert.deepEqual(metrics.drawingBuffer,metrics.buffer,'Actual GL drawable and canvas backing dimensions must agree');
  13 |  assert.equal(metrics.contextLost,false,'GL context must remain live');
  14 |  assert.equal(metrics.retained,true,'The qualified host retains its drawable');
  15 |  if(pngSize)assert.deepEqual(pngSize,{width:Math.round(viewport.width*metrics.dpr),height:Math.round(viewport.height*metrics.dpr)},'PNG dimensions must agree with the independent browser DPR');
  16 | }
  17 | export function requireSidebarLabel(text,label){
  18 |  const patterns={brand:/\bHEPTA\b/,group:/\bCONVERSATIONS\b/,newDraft:/\bNew\s+draft\b/i};
  19 |  assert.ok(Object.hasOwn(patterns,label),'Unknown sidebar text assertion');
  20 |  assert.match(text,patterns[label],'The complete exact sidebar label must be visible');
  21 | }
  22 | export function requireCompletedSidebarEvidence(evidence,finalTest){
  23 |  assert.equal(evidence.scenarioComplete,true,'All required input actions and assertions must have completed');
  24 |  assert.equal(finalTest.status,'expected','The final Playwright reporter must accept this case');
  25 |  assert.equal(finalTest.expectedStatus,'passed','Expected failures cannot qualify the scenario');
  26 |  assert.equal(finalTest.results.length,1,'A retry cannot silently qualify the scenario');
  27 |  assert.equal(finalTest.results[0].status,'passed','The final test execution must have passed');
  28 | }
  29 | 
  30 | export function observedAreaCenter(area,viewport){
  31 |  assert.ok(Array.isArray(area)&&area.length===4,'A current real draw Area is required');
  32 |  const [x,y,width,height]=area;
  33 |  assert.ok(area.every(Number.isFinite)&&width>0&&height>0,'Draw Area must be finite and positive');
  34 |  assert.ok(x>=0&&y>=0&&x+width<=viewport.width&&y+height<=viewport.height,'Complete draw Area must remain strictly inside the viewport');
  35 |  return{x:x+width/2,y:y+height/2};
  36 | }
  37 | 
```