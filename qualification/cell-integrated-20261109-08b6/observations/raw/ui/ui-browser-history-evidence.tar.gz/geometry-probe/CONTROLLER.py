import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
SOURCE=ROOT/'firefox-source-m4'
OUT=ROOT/'sidebar-geometry-probe-001'
OUT.mkdir(mode=0o700,exist_ok=False)
(OUT/'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
(OUT/'PROBE.mjs').write_bytes((ROOT/'probe_sidebar_geometry.mjs').read_bytes())
env=os.environ.copy();env.update(PLAYWRIGHT_BROWSERS_PATH=str(ROOT/'firefox-tools/browsers'),HEPTA_ROBRIX_FIXTURES='1',PORT='4176')
before=subprocess.check_output(['git','status','--porcelain=v1'],cwd=SOURCE)
if before:raise RuntimeError('Source dirty')
if subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE).decode().strip()!='cb5c06441ae6a23b53af55b3e9e4aa6efb3fe1ed':raise RuntimeError('Wrong source')
start=time.monotonic()
with (OUT/'server.stdout').open('xb') as stdout,(OUT/'server.stderr').open('xb') as stderr:
 server=subprocess.Popen(['node','tools/serve-robrix.mjs'],cwd=SOURCE/'apps/hepta-control-ui',env=env,stdout=stdout,stderr=stderr)
 try:
  with (OUT/'probe.stdout').open('xb') as output,(OUT/'probe.stderr').open('xb') as error:
   client=subprocess.run(['xvfb-run','-a','node',str(OUT/'PROBE.mjs')],env=env,stdout=output,stderr=error,timeout=90)
 finally:
  server.terminate();server.wait(timeout=5)
after=subprocess.check_output(['git','status','--porcelain=v1'],cwd=SOURCE)
sources=[]
for name in ['web.js','web_gl.js']:
 p=SOURCE/'apps/hepta-control-ui/dist-robrix-fixtures/makepad_platform'/name
 data=p.read_bytes();(OUT/name).write_bytes(data)
 lines=data.decode().splitlines();selected=set()
 for i,line in enumerate(lines):
  if any(key in line for key in ['innerWidth','innerHeight','canvas.style.width','canvas.style.height','canvas.width =','canvas.height =']):selected.update(range(max(0,i-4),min(len(lines),i+5)))
 sources.append({'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'lines':[{'line':i+1,'text':lines[i]} for i in sorted(selected)]})
result={'source':'cb5c06441ae6a23b53af55b3e9e4aa6efb3fe1ed','exit_code':client.returncode,'outer_wall_seconds':time.monotonic()-start,'source_before_status':before.decode(),'source_after_status':after.decode(),'sdk_runtime_sources':sources}
(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
if client.returncode or after:raise SystemExit(1)
