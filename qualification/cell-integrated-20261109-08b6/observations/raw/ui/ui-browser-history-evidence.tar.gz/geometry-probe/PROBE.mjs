import {writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const root='/home/qian-qi/work/cell-continuation-20261109-08b6';
const {firefox,devices}=await import(pathToFileURL(root+'/firefox-tools/npm-root/node_modules/playwright/index.mjs'));
const {sharedFontFamilyReady}=await import(pathToFileURL(root+'/firefox-source-m4/apps/hepta-control-ui/tools/robrix-font-readiness.mjs'));
const browser=await firefox.launch({headless:false});
const observations=[];
try{
 const context=await browser.newContext({...devices['Desktop Firefox']});
 const page=await context.newPage();let latestState=null;
 let readyResolve;const ready=new Promise(resolve=>readyResolve=resolve);
 page.on('console',message=>{
  if(sharedFontFamilyReady(message.text()))readyResolve();
  const m=message.text().match(/HEPTA_FIXTURE_SIDEBAR sample=(\d+) frame=(\d+) receipt=([a-z-]+) (\{.*\})/);
  if(m)latestState={sample:Number(m[1]),frame:Number(m[2]),receipt:m[3],...JSON.parse(m[4])};
 });
 await page.setViewportSize({width:640,height:800});await page.goto('http://127.0.0.1:4176/');
 await page.locator('.canvas_loader').waitFor({state:'hidden',timeout:60000});
 let fontTimer;
 try{await Promise.race([ready,new Promise((_,reject)=>{fontTimer=setTimeout(()=>reject(new Error('Font readiness deadline')),60000);})]);}
 finally{clearTimeout(fontTimer);}
 for(const viewport of [{width:640,height:800},{width:1280,height:800},{width:640,height:800}]){
  await page.setViewportSize(viewport);
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  const metrics=await page.locator('canvas').evaluate(canvas=>{
   const rect=canvas.getBoundingClientRect(),style=getComputedStyle(canvas),gl=canvas.getContext('webgl2');
   return {dpr:devicePixelRatio,inner:{width:innerWidth,height:innerHeight},outer:{width:outerWidth,height:outerHeight},
    visualViewport:{width:visualViewport.width,height:visualViewport.height,scale:visualViewport.scale},
    css:{x:rect.x,y:rect.y,width:rect.width,height:rect.height},inlineStyle:canvas.getAttribute('style'),
    computed:{width:style.width,height:style.height,zoom:style.zoom,transform:style.transform,boxSizing:style.boxSizing},
    document:{width:document.documentElement.clientWidth,height:document.documentElement.clientHeight,
     scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight},
    buffer:{width:canvas.width,height:canvas.height},drawingBuffer:{width:gl.drawingBufferWidth,height:gl.drawingBufferHeight},
    contextLost:gl.isContextLost(),retained:gl.getContextAttributes().preserveDrawingBuffer};
  });
  observations.push({requestedViewport:viewport,playwrightViewport:page.viewportSize(),metrics,rustState:latestState});
 }
 await writeFile(root+'/sidebar-geometry-probe-001/OBSERVATIONS.json',JSON.stringify({source:'cb5c06441ae6a23b53af55b3e9e4aa6efb3fe1ed',browser:browser.version(),device:devices['Desktop Firefox'],scope:'Read-only original M4 package, original Firefox device options; resize observations only; not acceptance',observations},null,2)+'\n');
 console.log(JSON.stringify(observations.map(({requestedViewport,metrics,rustState})=>({requestedViewport,metrics,drawDpiFactor:rustState?.drawDpiFactor}))));
}finally{await browser.close();}
