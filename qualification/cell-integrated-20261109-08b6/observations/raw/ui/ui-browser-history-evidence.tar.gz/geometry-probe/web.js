import{WasmBridge}from"../makepad_wasm_bridge/wasm_bridge.js"
export const MAKEPAD_WEB_IME_MAX_UNITS=1_048_576;
function makepad_ime_scalar(codepoint){
return Number.isInteger(codepoint)&&codepoint>=0&&codepoint<=0x10ffff
&&(codepoint<0xd800||codepoint>0xdfff)?codepoint:0xfffd;
}
export function makepad_ime_codepoints(text){
if(text.length>MAKEPAD_WEB_IME_MAX_UNITS)throw new RangeError('Web IME text exceeds the native input limit');
return Array.from(text,character=>makepad_ime_scalar(character.codePointAt(0)));
}
export function makepad_ime_string(codepoints){
if(!Array.isArray(codepoints))throw new TypeError('Invalid Web IME scalar payload');
if(codepoints.length>MAKEPAD_WEB_IME_MAX_UNITS)throw new RangeError('Web IME text exceeds the native input limit');
const text=codepoints.map(codepoint=>String.fromCodePoint(makepad_ime_scalar(codepoint))).join('');
if(text.length>MAKEPAD_WEB_IME_MAX_UNITS)throw new RangeError('Web IME text exceeds the native input limit');
return text;
}
export function makepad_ime_offset(text,offset){
offset=Number.isFinite(offset)?Math.max(0,Math.min(text.length,Math.floor(offset))):0;
if(offset>0&&offset<text.length&&text.charCodeAt(offset)>=0xdc00
&&text.charCodeAt(offset)<=0xdfff&&text.charCodeAt(offset-1)>=0xd800
&&text.charCodeAt(offset-1)<=0xdbff)offset--;
return offset;
}
export class MakepadWebIme{
constructor(host,text_area){
this.host=host;
this.ta=text_area;
this.active=false;
this.editable=false;
this.ta.readOnly=true;
this.applying=false;
this.composition=null;
this.last_state=null;
this.pending_commit=null;
}
show(){
this.editable=true;
this.ta.readOnly=false;
}
state(text=this.ta.value,start=this.ta.selectionStart,
end=this.ta.selectionEnd,composition=null,was_paste=false){
start=makepad_ime_offset(text,start);
end=makepad_ime_offset(text,end);
const backward=start>end||(start!==end&&this.ta.selectionDirection==='backward');
const comp_start=composition?makepad_ime_offset(text,composition[0]):0;
const comp_end=composition?makepad_ime_offset(text,composition[1]):0;
return{
text,selection_start:Math.min(start,end),selection_end:Math.max(start,end),
selection_backward:backward,
has_composition:comp_start!==comp_end,
composition_start:Math.min(comp_start,comp_end),
composition_end:Math.max(comp_start,comp_end),
was_paste,
};
}
write(state){
this.applying=true;
try{
if(this.ta.value!==state.text)this.ta.value=state.text;
const anchor=makepad_ime_offset(state.text,state.selection_start);
const cursor=makepad_ime_offset(state.text,state.selection_end);
const start=Math.min(anchor,cursor),end=Math.max(anchor,cursor);
const backward=start!==end&&(state.selection_backward||anchor>cursor);
const direction=backward?'backward':'forward';
if(this.ta.selectionStart!==start||this.ta.selectionEnd!==end
||(start!==end&&this.ta.selectionDirection!==direction)){
this.ta.setSelectionRange(start,end,direction);
}
}finally{
this.applying=false;
}
}
sync(state){
state={...state,text:makepad_ime_string(state.text)};
const comp_start=makepad_ime_offset(state.text,state.composition_start);
const comp_end=makepad_ime_offset(state.text,state.composition_end);
state={...state,has_composition:state.has_composition&&comp_start!==comp_end,
composition_start:Math.min(comp_start,comp_end),
composition_end:Math.max(comp_start,comp_end)};
this.active=true;
if(this.composition&&state.has_composition){
this.composition.prefix=state.text.slice(0,state.composition_start);
this.composition.suffix=state.text.slice(state.composition_end);
this.last_state=null;
return;
}
if(this.composition&&!state.has_composition
&&state.text===this.composition.prefix+this.composition.suffix
&&makepad_ime_offset(state.text,state.selection_start)===this.composition.prefix.length
&&makepad_ime_offset(state.text,state.selection_end)===this.composition.prefix.length){
this.last_state=this.state(state.text,state.selection_start,state.selection_end);
return;
}
if(this.composition){
this.composition=null;
this.pending_commit=null;
}
this.write(state);
this.last_state=this.state();
}
send(state){
if(!this.active||!this.editable||this.applying||this.host.webgl_context_lost)return;
const previous=this.last_state;
if(previous&&Object.keys(state).every(key=>state[key]===previous[key]))return;
let codepoints;
try{codepoints=makepad_ime_codepoints(state.text);}
catch(error){
if(previous)this.write(previous);
throw error;
}
const normalized=makepad_ime_string(codepoints);
if(normalized!==state.text){
state={...state,text:normalized};
this.write(state);
}
this.last_state={...state};
this.host.to_wasm.ToWasmImeState({...state,text:codepoints});
this.host.do_wasm_pump();
}
flush(){
if(this.host.webgl_context_lost)return;
this.host.to_wasm.ToWasmImeRequestState({time:performance.now()/1000});
this.host.do_wasm_pump();
}
start(){
if(!this.active||!this.editable)return;
this.pending_commit=null;
const start=this.ta.selectionStart;
const end=this.ta.selectionEnd;
this.composition={
native_prefix:this.ta.value.slice(0,start),
native_suffix:this.ta.value.slice(end),
prefix:this.ta.value.slice(0,start),
suffix:this.ta.value.slice(end),
data:'',
};
}
update(data){
const composition=this.composition;
if(!composition)return;
composition.data=data||'';
const start=composition.prefix.length;
const end=start+composition.data.length;
this.send(this.state(
composition.prefix+composition.data+composition.suffix,
end,end,end>start?[start,end]:null,
));
}
end(data){
const composition=this.composition;
if(!composition)return;
const input=data||'';
const end=composition.prefix.length+input.length;
const final_state=this.state(composition.prefix+input+composition.suffix,end,end);
this.composition=null;
this.pending_commit={data:input,state:final_state};
this.write(final_state);
this.send(final_state);
this.flush();
}
before_input(event){
if(!this.active||this.applying)return;
if(!this.composition&&!event.isComposing
&&!/Composition/.test(event.inputType||'')){
this.pending_commit=null;
}
}
input(event){
if(!this.active||this.applying)return;
if(this.composition){
if(typeof event.data==='string')this.update(event.data);
return;
}
if(event.isComposing||/Composition/.test(event.inputType||'')){
if(this.pending_commit)this.write(this.pending_commit.state);
return;
}
this.send(this.state(undefined,undefined,undefined,null,
event.inputType==='insertFromPaste'));
this.flush();
}
select(){
if(!this.active||this.applying||this.composition)return;
this.send(this.state());
}
clipboard(event,cut){
if(!this.active||!event.clipboardData||this.host.webgl_context_lost)return;
event.preventDefault();
if(this.composition)this.end(this.composition.data);
this.host.text_copy_response='';
if(cut&&this.editable)this.host.to_wasm.ToWasmTextCut();
else this.host.to_wasm.ToWasmTextCopy();
this.host.do_wasm_pump();
event.clipboardData.setData('text/plain',this.host.text_copy_response||'');
this.flush();
}
paste(event){
if(!this.active||!this.editable||!event.clipboardData||this.host.webgl_context_lost)return;
event.preventDefault();
if(this.composition)this.end(this.composition.data);
this.flush();
const text=event.clipboardData.getData('text/plain');
const start=this.ta.selectionStart;
const end=start+text.length;
const state=this.state(this.ta.value.slice(0,start)+text
+this.ta.value.slice(this.ta.selectionEnd),end,end,null,true);
this.pending_commit=null;
this.write(state);
this.send(state);
this.flush();
}
hide(){
this.active=false;
this.editable=false;
this.ta.readOnly=true;
this.composition=null;
this.pending_commit=null;
this.last_state=null;
this.write(this.state('',0,0));
}
blur(){
if(this.composition)this.end(this.composition.data);
this.pending_commit=null;
}
}
export const MAKEPAD_WEBGL_PIXEL_BUDGET=2*1024*1024;
export const MAKEPAD_WEBGL_DPR_CEILING=1.5;
export const MAKEPAD_WEBGL_PHONE_DPR_CEILING=1.0;
function makepad_positive_number(value,fallback){
const number=Number(value);
return Number.isFinite(number)&&number>0?number:fallback;
}
export function makepad_device_pixel_ratio(value){
return makepad_positive_number(value,1.0);
}
export function makepad_compute_webgl_size(
width,
height,
scale_ceiling,
limits={},
pixel_budget=MAKEPAD_WEBGL_PIXEL_BUDGET,
){
const logical_width=Number.isFinite(Number(width))&&Number(width)>0
?Number(width)
:0;
const logical_height=Number.isFinite(Number(height))&&Number(height)>0
?Number(height)
:0;
const max_width=makepad_positive_number(limits.max_width,Number.MAX_SAFE_INTEGER);
const max_height=makepad_positive_number(limits.max_height,Number.MAX_SAFE_INTEGER);
const budget=makepad_positive_number(pixel_budget,MAKEPAD_WEBGL_PIXEL_BUDGET);
let scale=makepad_positive_number(scale_ceiling,1.0);
if(logical_width===0||logical_height===0){
return{
logical_width,
logical_height,
width:0,
height:0,
scale,
};
}
const budget_scale=Math.sqrt(budget)
/Math.sqrt(logical_width)
/Math.sqrt(logical_height);
scale=Math.min(
scale,
budget_scale,
max_width/logical_width,
max_height/logical_height,
);
if(!Number.isFinite(scale)||scale<=0){
return{
logical_width,
logical_height,
width:0,
height:0,
scale:0,
};
}
const physical_width=Math.max(1,Math.min(max_width,Math.floor(logical_width*scale)));
const physical_height=Math.max(1,Math.min(max_height,Math.floor(logical_height*scale)));
return{
logical_width,
logical_height,
width:physical_width,
height:physical_height,
scale,
};
}
const MAKEPAD_CRASH_MAX_REPORTS=20;
const MAKEPAD_CRASH_POST_BYTES=64*1024;
const MAKEPAD_CRASH_GET_BYTES=8*1024;
const makepad_page_console={};
for(const level of["log","warn","error"]){
const method=typeof console!=="undefined"?console[level]:undefined;
makepad_page_console[level]=typeof method==="function"?method.bind(console):()=>{};
}
function makepad_json_replacer(_key,value){
if(typeof value==="bigint"){
return value.toString();
}
if(value instanceof Error){
return{
name:value.name,
message:value.message,
stack:value.stack||""
};
}
if(typeof value==="function"){
return`[function ${value.name || "anonymous"}]`;
}
return value;
}
function makepad_safe_json(value){
const seen=new WeakSet();
try{
const text=JSON.stringify(value,(key,item)=>{
item=makepad_json_replacer(key,item);
if(item&&typeof item==="object"){
if(seen.has(item)){
return"[circular]";
}
seen.add(item);
}
return item;
});
return text===undefined?"null":text;
}catch(_error){
return JSON.stringify("[unserializable]");
}
}
function makepad_json_bytes(text){
if(typeof TextEncoder!=="undefined"){
return new TextEncoder().encode(text).byteLength;
}
return unescape(encodeURIComponent(text)).length;
}
function makepad_console_text(parts){
const values=Array.isArray(parts)?parts:[parts];
return values.map(value=>{
if(typeof value==="string"){
return value;
}
if(value instanceof Error){
return value.stack||`${value.name}: ${value.message}`;
}
if(value&&typeof value==="object"){
return makepad_safe_json(value);
}
try{
return String(value);
}catch(_error){
return"[unprintable]";
}
}).join(" ").replace(/\s*\r?\n\s*/g," ");
}
export function makepad_create_breadcrumb_ring(limit=30,max_length=300,started_at=Date.now()){
const entries=[];
return{
push(level,parts,now=Date.now(),worker_index){
try{
const entry={
ms:Math.max(0,Math.round(now-started_at)),
level:String(level),
text:makepad_console_text(parts).slice(0,max_length)
};
if(worker_index!==undefined&&worker_index!==null){
entry.worker=worker_index;
}
entries.push(entry);
if(entries.length>limit){
entries.splice(0,entries.length-limit);
}
}catch(_error){
}
},
snapshot(){
return entries.map(entry=>({...entry}));
}
};
}
function makepad_report_message(data){
if(!data||typeof data!=="object"){
return data===undefined?"":String(data);
}
for(const key of["message","reason_message","text","error"]){
if(data[key]!==undefined&&data[key]!==null){
return String(data[key]);
}
}
return"";
}
function makepad_report_stack(data){
if(!data||typeof data!=="object"){
return"";
}
return String(data.stack||data.reason_stack||data.trap_stack||"");
}
export function makepad_report_key(kind,data){
const stack_lines=makepad_report_stack(data)
.split("\n")
.map(line=>line.trim())
.filter(Boolean);
const top_frame=stack_lines.find(line=>/^(at\s|.*wasm-function|.*\.wasm(?:\?|:|$))/.test(line))
||stack_lines[1]
||stack_lines[0]
||"";
return`${kind}\n${makepad_report_message(data)}\n${top_frame}`;
}
export function makepad_create_report_gate(max_reports=MAKEPAD_CRASH_MAX_REPORTS){
const seen=new Set();
let count=0;
return{
accept(kind,data){
const key=makepad_report_key(kind,data);
if(count>=max_reports||seen.has(key)){
return false;
}
seen.add(key);
count+=1;
return true;
},
count(){
return count;
}
};
}
export function makepad_truncate_report(report,max_bytes=MAKEPAD_CRASH_GET_BYTES){
const fits=value=>makepad_json_bytes(value)<=max_bytes;
let candidate={...report};
let text=makepad_safe_json(candidate);
if(fits(text)){
return text;
}
delete candidate.breadcrumbs;
text=makepad_safe_json(candidate);
if(fits(text)){
return text;
}
const original_data=makepad_safe_json(candidate.data);
candidate.data={truncated:true,text:""};
let low=0;
let high=original_data.length;
while(low<high){
const middle=Math.ceil((low+high)/2);
candidate.data.text=original_data.slice(0,middle);
if(fits(makepad_safe_json(candidate))){
low=middle;
}else{
high=middle-1;
}
}
candidate.data.text=original_data.slice(0,low);
text=makepad_safe_json(candidate);
if(fits(text)){
return text;
}
candidate={
v:report.v,
kind:String(report.kind||"").slice(0,200),
app:String(report.app||"").slice(0,200),
href:String(report.href||"").slice(0,512),
user_agent:String(report.user_agent||"").slice(0,512),
time:report.time,
wasm_memory_bytes:report.wasm_memory_bytes,
hardware_concurrency:report.hardware_concurrency,
has_thread_support:report.has_thread_support,
data:{truncated:true}
};
text=makepad_safe_json(candidate);
if(fits(text)){
return text;
}
return makepad_safe_json({v:1,kind:"report.truncated",data:{truncated:true}});
}
function makepad_is_wasm_trap(kind,data){
if(kind!=="window.error"&&kind!=="window.unhandledrejection"&&kind!=="startup.exception"){
return false;
}
const detail=`${makepad_report_message(data)}\n${makepad_report_stack(data)}`;
return/WebAssembly(?:\.|\s)|RuntimeError|wasm-function|\.wasm(?:\?|:|\b)|unreachable|memory access out of bounds|table index is out of bounds|null function/i.test(detail);
}
function makepad_create_crash_reporter(){
const breadcrumbs=makepad_create_breadcrumb_ring();
const gate=makepad_create_report_gate();
let wasm=null;
let page_hiding=false;
let pending_panic=null;
let dead=false;
let dead_error=null;
let suppressed_followups=0;
const app_name=()=>{
try{
return location.pathname.split("/").filter(Boolean)[0]||"";
}catch(_error){
return"";
}
};
const memory_bytes=()=>{
try{
const memory=wasm&&(wasm._memory||(wasm.exports&&wasm.exports.memory));
return memory&&memory.buffer?memory.buffer.byteLength:null;
}catch(_error){
return null;
}
};
const thread_support=()=>{
try{
if(wasm&&typeof wasm._has_thread_support==="boolean"){
return wasm._has_thread_support;
}
return typeof SharedArrayBuffer!=="undefined"
&&(typeof crossOriginIsolated==="undefined"||crossOriginIsolated===true);
}catch(_error){
return false;
}
};
const build_payload=(kind,data)=>({
v:1,
kind,
app:app_name(),
href:typeof location==="undefined"?"":String(location.href),
user_agent:typeof navigator==="undefined"?"":String(navigator.userAgent||""),
time:Date.now(),
wasm_memory_bytes:memory_bytes(),
hardware_concurrency:typeof navigator!=="undefined"&&Number.isFinite(navigator.hardwareConcurrency)
?navigator.hardwareConcurrency
:null,
has_thread_support:thread_support(),
breadcrumbs:breadcrumbs.snapshot(),
data
});
const send=async()=>false;
const take_pending_panic=()=>{
if(!pending_panic||Date.now()-pending_panic.time>1000){
return null;
}
const panic=pending_panic;
pending_panic=null;
clearTimeout(panic.timer);
return panic;
};
const reporter={
report(kind,data){
try{
kind=String(kind||"unknown");
if(kind==="wasm.panic"){
if(pending_panic){
clearTimeout(pending_panic.timer);
void send("wasm.panic",pending_panic.data);
}
const panic={data,time:Date.now(),timer:null};
panic.timer=setTimeout(()=>{
if(pending_panic===panic){
pending_panic=null;
void send("wasm.panic",data);
}
},1000);
pending_panic=panic;
return Promise.resolve(true);
}
if(makepad_is_wasm_trap(kind,data)){
reporter.mark_wasm_dead(data);
const panic=take_pending_panic();
if(panic){
return send("wasm.panic",{
...panic.data,
trap_message:makepad_report_message(data),
trap_stack:makepad_report_stack(data)
});
}
}
return send(kind,data);
}catch(_error){
return Promise.resolve(false);
}
},
set_wasm(next_wasm){
try{
wasm=next_wasm;
}catch(_error){
}
},
add_breadcrumb(level,parts,worker_index){
breadcrumbs.push(level,parts,Date.now(),worker_index);
},
mark_wasm_dead(error){
try{
if(dead){
return;
}
dead=true;
dead_error={
message:makepad_report_message(error),
stack:makepad_report_stack(error)
};
setTimeout(()=>{
void send("wasm.dead",{
suppressed_followups,
first_trap:dead_error
});
},2000);
}catch(_error){
}
},
is_wasm_dead(){
return dead;
},
suppress_followup(){
if(dead){
suppressed_followups+=1;
}
},
set_page_hiding(value){
page_hiding=!!value;
if(page_hiding&&pending_panic){
const panic=pending_panic;
pending_panic=null;
clearTimeout(panic.timer);
void send("wasm.panic",panic.data);
}
}
};
return reporter;
}
export const makepad_crash_reporter=makepad_create_crash_reporter();
if(typeof window!=="undefined"){
window.makepad_crash_reporter=makepad_crash_reporter;
for(const level of["log","warn","error"]){
try{
const original=console[level];
if(typeof original!=="function"){
continue;
}
console[level]=function(...parts){
makepad_crash_reporter.add_breadcrumb(level,parts);
return original.apply(console,parts);
};
}catch(_error){
}
}
window.addEventListener("pagehide",()=>makepad_crash_reporter.set_page_hiding(true));
window.addEventListener("pageshow",()=>makepad_crash_reporter.set_page_hiding(false));
}
export class WasmWebBrowser extends WasmBridge{
constructor(wasm,dispatch,canvas){
super(wasm,dispatch);
if(wasm===undefined){
return
}
makepad_crash_reporter.set_wasm(wasm);
this.wasm_app=this.wasm_create_app();
this.create_js_message_bridge(this.wasm_app);
this.dispatch=dispatch;
this.canvas=canvas;
this.canvas.style.touchAction='none';
const browser=this;
this.handlers=new Proxy({},{
set(target,property,value){
target[property]=typeof value==="function"?(...args)=>{
if(browser.webgl_context_lost){
return;
}
if(makepad_crash_reporter.is_wasm_dead()){
makepad_crash_reporter.suppress_followup();
return;
}
return value(...args);
}:value;
return true;
}
});
this.timers=[];
this.text_copy_response="";
this.web_sockets=[];
this.network_web_sockets={};
this.network_http_requests=new Map();
this.network_http_hosts=new Map();
this.legacy_http_requests=new Set();
this.storage_db_promise=null;
this.window_info={}
this.physical_device_dpi=makepad_device_pixel_ratio(window.devicePixelRatio);
this.render_quality=null;
this.webgl_context_lost=false;
this.xr_capabilities={
vr_supported:false,
ar_supported:false
};
this.xr_supported=false;
this.signal_timeout=null;
this.workers=new Map();
this.worker_console_recent=new Map();
this.thread_stack_arena=[];
this.thread_stack_size=2*1024*1024;
this.ui_wake_queued=false;
this.buffer_upload_serial=0;
this.loader_removed=false;
this.loader_seen_animation_frame=false;
this.loader_quiet_animation_frames=0;
this.loader_after_presented_frame_id=0;
this.loader_fallback_timer=null;
this.virtual_file_max_size=512*1024*1024;
this.virtual_file_max_total_size=512*1024*1024;
this.init_detection();
this.midi_inputs=[];
this.midi_outputs=[];
this.audio_context=null;
this.audio_worklet=null;
this.audio_callback_started=false;
this.audio_callback_watchdog=null;
this.audio_startup_cancel=null;
this.dispatch_first_msg();
}
js_monotonic_now(){
return performance.now()/1000.0;
}
js_worker_wait(_timeout_ms){
throw new Error("js_worker_wait may only run in a Web Worker");
}
js_wake_ui(){
if(this.webgl_context_lost){
return;
}
if(makepad_crash_reporter.is_wasm_dead()){
makepad_crash_reporter.suppress_followup();
return;
}
if(this.ui_wake_queued){
return;
}
this.ui_wake_queued=true;
queueMicrotask(()=>{
this.ui_wake_queued=false;
if(this.webgl_context_lost){
return;
}
if(makepad_crash_reporter.is_wasm_dead()){
makepad_crash_reporter.suppress_followup();
return;
}
const flags=this.exports.wasm_check_signal();
if(flags!==0){
this.to_wasm.ToWasmSignal({flags});
this.do_wasm_pump();
}
});
}
js_spawn_thread(request_id,context_ptr,stack_size,name_ptr,name_len){
if(this.webgl_context_lost||!this.wasm._has_thread_support){
return 0;
}
const name=this.u8_to_string(name_ptr,name_len);
this.create_thread({request_id,context_ptr,stack_size,name});
return 1;
}
stop_terminal_web_runtime(){
if(this._terminal_web_runtime_stopped){
return;
}
this._terminal_web_runtime_stopped=true;
this.ui_wake_queued=false;
const safely=(name,cleanup)=>{
try{
cleanup();
}catch(error){
console.error(`makepad: terminal ${name} cleanup failed: ${error}`);
}
};
for(const record of this.workers||[]){
const worker_record=record[1];
worker_record.closed=true;
worker_record.worker.onmessage=null;
worker_record.worker.onerror=null;
worker_record.worker.onmessageerror=null;
safely("worker",()=>worker_record.worker.terminate());
}
if(this.workers){
this.workers.clear();
}
if(this.thread_stack_arena){
this.thread_stack_arena.length=0;
}
for(const entry of this.network_http_requests||[]){
const request=entry[1];
request.state="terminal";
if(request.stall_timer!==null){
window.clearTimeout(request.stall_timer);
request.stall_timer=null;
}
if(request.controller){
safely("fetch",()=>request.controller.abort("WebGL context lost"));
}
}
if(this.network_http_requests){
this.network_http_requests.clear();
}
if(this.network_http_hosts){
this.network_http_hosts.clear();
}
for(const request of this.legacy_http_requests||[]){
safely("XHR",()=>request.abort());
}
if(this.legacy_http_requests){
this.legacy_http_requests.clear();
}
for(const socket of Object.values(this.network_web_sockets||{})){
socket.onopen=null;
socket.onmessage=null;
socket.onerror=null;
socket.onclose=null;
safely("WebSocket",()=>socket.close());
}
this.network_web_sockets={};
for(const input of this.midi_inputs||[]){
if(input.port){
input.port.onmidimessage=null;
}
}
this.reload_midi_ports=null;
if(this.geo_watch_id!==undefined&&navigator.geolocation){
const watch_id=this.geo_watch_id;
this.geo_watch_id=undefined;
safely("geolocation",()=>navigator.geolocation.clearWatch(watch_id));
}
safely("audio",()=>this.stop_audio_output());
}
shutdown_thread_runtime(){
for(const[request_id,record]of this.workers){
record.closed=true;
record.worker.terminate();
if(record.started){
this.exports.wasm_thread_worker_lost(request_id);
}else{
this.exports.wasm_thread_failed_to_start(request_id);
}
if(!record.thread_info.wasm_bindgen&&record.thread_info.tls_ptr){
this.thread_stack_arena.push({
ptr:record.thread_info.tls_ptr,
words:record.thread_info.alloc_words
});
}
}
this.workers.clear();
for(const block of this.thread_stack_arena){
this.exports.wasm_thread_dealloc_tls_and_stack(block.ptr,block.words);
}
this.thread_stack_arena.length=0;
}
emit_app_lifecycle(state){
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmAppLifecycle({state});
}
emit_app_inactive(){
if(!this.lifecycle_is_visible){
return;
}
this.lifecycle_is_visible=false;
this.emit_app_lifecycle(2);
this.emit_app_lifecycle(1);
}
emit_app_active(){
if(this.lifecycle_is_visible){
return;
}
this.lifecycle_is_visible=true;
this.lifecycle_shutdown_sent=false;
this.emit_app_lifecycle(0);
this.emit_app_lifecycle(3);
}
emit_app_shutdown(){
if(this.lifecycle_shutdown_sent){
return;
}
this.lifecycle_shutdown_sent=true;
this.emit_app_lifecycle(4);
}
bind_app_lifecycle(){
this.lifecycle_is_visible=!document.hidden;
this.lifecycle_shutdown_sent=false;
document.addEventListener("visibilitychange",()=>{
if(this.webgl_context_lost){
return;
}
if(document.hidden){
this.emit_app_inactive();
}else{
this.emit_app_active();
}
this.do_wasm_pump();
});
window.addEventListener("pagehide",(event)=>{
if(this.webgl_context_lost){
return;
}
this.emit_app_inactive();
if(!event.persisted){
this.emit_app_shutdown();
}
this.do_wasm_pump();
if(!event.persisted){
this.shutdown_thread_runtime();
}
});
window.addEventListener("pageshow",(event)=>{
if(this.webgl_context_lost){
return;
}
if(event.persisted){
this.emit_app_active();
this.do_wasm_pump();
}
});
}
emit_location_change(){
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmLocationChange({
pathname:location.pathname+"",
search:location.search+"",
hash:location.hash+"",
});
}
install_live_reload_bridge(){
window.makepad_wasm_live_file_change=(file_name,content)=>{
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmLiveFileChange({file_name,content});
this.do_wasm_pump();
};
let queue=window.makepad_wasm_live_file_change_queue||[];
while(queue.length>0){
let[file_name,content]=queue.shift();
window.makepad_wasm_live_file_change(file_name,content);
}
}
async load_deps(){
this.to_wasm=this.new_to_wasm();
this.install_live_reload_bridge();
await this.query_xr_capabilities();
if(this.webgl_context_lost){
return;
}
this.update_window_info();
const hardware_concurrency=Number.isFinite(navigator.hardwareConcurrency)
?Math.max(1,Math.floor(navigator.hardwareConcurrency))
:1;
this.to_wasm.ToWasmInit({
gpu_info:this.gpu_info,
cpu_cores:hardware_concurrency,
wasm_memory_max_pages:this.wasm._memory_max_pages||16384,
xr_capabilities:this.xr_capabilities,
browser_info:{
protocol:location.protocol+"",
host:location.host+"",
hostname:location.hostname+"",
pathname:location.pathname+"",
search:location.search+"",
hash:location.hash+"",
has_thread_support:this.wasm._has_thread_support,
is_phone:WasmBridge.is_phone()
},
window_info:this.window_info,
});
this.do_wasm_pump();
this.bind_mouse_and_touch();
this.bind_file_drop();
this.bind_keyboard();
this.bind_screen_resize();
this.bind_app_lifecycle();
window.addEventListener("popstate",()=>{
this.emit_location_change();
this.do_wasm_pump();
});
window.addEventListener("hashchange",()=>{
this.emit_location_change();
this.do_wasm_pump();
});
this.focus_keyboard_input();
this.to_wasm.ToWasmRedrawAll();
this.start_signal_poll();
this.do_wasm_pump();
this.schedule_loader_fallback();
}
remove_canvas_loader(){
if(this.loader_removed){
return;
}
this.loader_removed=true;
if(this.loader_after_presented_frame_id){
window.cancelAnimationFrame(this.loader_after_presented_frame_id);
this.loader_after_presented_frame_id=0;
}
if(this.loader_fallback_timer){
clearTimeout(this.loader_fallback_timer);
this.loader_fallback_timer=null;
}
var loaders=document.getElementsByClassName('canvas_loader');
while(loaders.length>0){
let loader=loaders[0];
if(loader.parentNode){
loader.parentNode.removeChild(loader);
}
else{
break;
}
}
}
schedule_loader_fallback(){
if(this.loader_removed||this.loader_fallback_timer){
return;
}
this.loader_fallback_timer=window.setTimeout(()=>{
this.remove_canvas_loader();
},1500);
}
cancel_loader_after_presented_frame(){
if(!this.loader_after_presented_frame_id){
return;
}
window.cancelAnimationFrame(this.loader_after_presented_frame_id);
this.loader_after_presented_frame_id=0;
}
schedule_loader_after_presented_frame(){
if(this.loader_removed||this.loader_after_presented_frame_id){
return;
}
this.loader_after_presented_frame_id=window.requestAnimationFrame(()=>{
this.loader_after_presented_frame_id=0;
if(
!this.loader_removed&&
this.loader_seen_animation_frame&&
this.loader_quiet_animation_frames>=2
){
this.remove_canvas_loader();
}
});
}
update_startup_loader(pump_duration_ms){
if(this.loader_removed){
return;
}
this.schedule_loader_fallback();
if(!this.in_animation_frame){
if(this.loader_seen_animation_frame){
this.loader_quiet_animation_frames=0;
this.cancel_loader_after_presented_frame();
}
return;
}
this.loader_seen_animation_frame=true;
if(pump_duration_ms<=16){
this.loader_quiet_animation_frames+=1;
}
else{
this.loader_quiet_animation_frames=0;
this.cancel_loader_after_presented_frame();
return;
}
if(this.loader_quiet_animation_frames>=2){
this.schedule_loader_after_presented_frame();
}
else{
this.cancel_loader_after_presented_frame();
}
}
FromWasmOpenUrl(args){
if(args.in_place){
window.location.href=args.url;
}
else{
var link=document.createElement("a");
link.href=args.url;
link.target="_blank";
link.click();
}
}
FromWasmBrowserUpdateUrl(args){
const next=new URL(args.url||"",window.location.href);
const nextHref=next.pathname+next.search+next.hash;
const currentHref=location.pathname+location.search+location.hash;
if(nextHref===currentHref){
return;
}
if(args.replace){
window.history.replaceState(null,"",nextHref);
}
else{
window.history.pushState(null,"",nextHref);
}
}
FromWasmBrowserHistoryGo(args){
if(args.delta===-1){
window.history.back();
}
else if(args.delta===1){
window.history.forward();
}
else{
window.history.go(args.delta);
}
}
FromWasmStartTimer(args){
if(this.webgl_context_lost){
return;
}
let timer_id=args.timer_id;
const interval_seconds=Number(args.interval);
if(!Number.isFinite(interval_seconds)||interval_seconds<0){
console.error(`Invalid timer interval for ${timer_id}: ${args.interval}`);
return;
}
const interval_ms=Math.min(interval_seconds*1000.0,2147483647);
for(let i=0;i<this.timers.length;i++){
if(this.timers[i].timer_id==timer_id){
console.error("Timer ID collision!")
return
}
}
var timer={timer_id,repeats:args.repeats};
if(args.repeats===true){
timer.sys_id=window.setInterval(e=>{
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmTimerFired({timer_id});
this.do_wasm_pump();
},Math.max(4,interval_ms));
}
else{
timer.sys_id=window.setTimeout(e=>{
if(this.webgl_context_lost){
return;
}
for(let i=0;i<this.timers.length;i++){
let timer=this.timers[i];
if(timer.timer_id==timer_id){
this.timers.splice(i,1);
break;
}
}
this.to_wasm.ToWasmTimerFired({timer_id});
this.do_wasm_pump();
},interval_ms);
}
this.timers.push(timer)
}
FromWasmStopTimer(args){
for(let i=0;i<this.timers.length;i++){
let timer=this.timers[i];
if(timer.timer_id==args.timer_id){
if(timer.repeats){
window.clearInterval(timer.sys_id);
}
else{
window.clearTimeout(timer.sys_id);
}
this.timers.splice(i,1);
return
}
}
}
FromWasmStartLocationUpdates(){
if(this.webgl_context_lost){
return;
}
if(this.geo_watch_id!==undefined){
return;
}
if(!navigator.geolocation){
this.to_wasm.ToWasmLocationError({code:0,message:"geolocation API unavailable"});
this.do_wasm_pump();
return;
}
this.geo_watch_id=navigator.geolocation.watchPosition(
(pos)=>{
if(this.webgl_context_lost){
return;
}
let c=pos.coords;
this.to_wasm.ToWasmLocationUpdate({
lon:c.longitude,
lat:c.latitude,
accuracy_m:c.accuracy,
altitude_m:c.altitude===null?undefined:c.altitude,
speed_mps:c.speed===null?undefined:c.speed,
heading_deg:(c.heading===null||isNaN(c.heading))?undefined:c.heading,
time:pos.timestamp/1000.0,
});
this.do_wasm_pump();
},
(err)=>{
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmLocationError({code:err.code,message:err.message});
this.do_wasm_pump();
},
{enableHighAccuracy:true,maximumAge:1000}
);
}
FromWasmStopLocationUpdates(){
if(this.geo_watch_id!==undefined){
navigator.geolocation.clearWatch(this.geo_watch_id);
this.geo_watch_id=undefined;
}
}
FromWasmFullScreen(){
if(document.body.requestFullscreen){
document.body.requestFullscreen();
return
}
if(document.body.webkitRequestFullscreen){
document.body.webkitRequestFullscreen();
return
}
if(document.body.mozRequestFullscreen){
document.body.mozRequestFullscreen();
return
}
}
FromWasmNormalScreen(){
if(!is_fullscreen()){
return
}
if(document.exitFullscreen){
document.exitFullscreen();
return
}
if(document.webkitExitFullscreen){
document.webkitExitFullscreen();
return
}
if(document.mozCancelFullScreen){
document.mozCancelFullScreen();
return
}
}
FromWasmRequestAnimationFrame(){
if(this.webgl_context_lost||this.xr!==undefined||this.req_anim_frame_id){
return;
}
this.req_anim_frame_id=window.requestAnimationFrame(time=>{
this.req_anim_frame_id=0;
if(this.wasm==null||this.webgl_context_lost){
return
}
if(this.xr!==undefined){
return
}
this.to_wasm.ToWasmAnimationFrame({time:time/1000.0});
this.in_animation_frame=true;
this.do_wasm_pump();
this.in_animation_frame=false;
})
}
FromWasmSetDocumentTitle(args){
document.title=args.title
}
FromWasmSetMouseCursor(args){
document.body.style.cursor=web_cursor_map[args.web_cursor]||'default'
}
FromWasmTextCopyResponse(args){
this.text_copy_response=makepad_ime_string(args.response)
}
storage_database(){
if(this.storage_db_promise!==null){
return this.storage_db_promise;
}
this.storage_db_promise=new Promise((resolve,reject)=>{
const request=indexedDB.open("makepad-storage",1);
request.onupgradeneeded=()=>{
const db=request.result;
const store=db.objectStoreNames.contains("values")
?request.transaction.objectStore("values")
:db.createObjectStore("values",{keyPath:"id"});
if(!store.indexNames.contains("namespace")){
store.createIndex("namespace","namespace",{unique:false});
}
};
request.onsuccess=()=>resolve(request.result);
request.onerror=()=>reject(request.error||new Error("could not open IndexedDB"));
request.onblocked=()=>reject(new Error("IndexedDB upgrade was blocked"));
});
return this.storage_db_promise;
}
storage_id(namespace,key){
return namespace+"\u0000"+key;
}
storage_error_text(error){
if(error&&error.message){
return error.message;
}
return String(error||"unknown IndexedDB error");
}
storage_send_result(args,op,result={}){
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmStorageResult({
request_id_lo:args.request_id_lo,
request_id_hi:args.request_id_hi,
op,
found:result.found===true,
value:result.value||new Uint8Array(0),
keys:result.keys||[],
has_next:result.next!==undefined,
next:result.next||"",
length_lo:result.length===undefined?0:result.length>>>0,
length_hi:result.length===undefined?0:Math.floor(result.length/0x100000000),
usage_lo:result.usage===undefined?0:result.usage>>>0,
usage_hi:result.usage===undefined?0:Math.floor(result.usage/0x100000000),
quota_lo:result.quota===undefined?0:result.quota>>>0,
quota_hi:result.quota===undefined?0:Math.floor(result.quota/0x100000000),
error_kind:result.error_kind||0,
error:result.error||""
});
this.do_wasm_pump();
}
storage_request(request){
return new Promise((resolve,reject)=>{
request.onsuccess=()=>resolve(request.result);
request.onerror=()=>reject(request.error||new Error("IndexedDB request failed"));
});
}
FromWasmStorageGet(args){
this.storage_database().then(db=>{
const request=db.transaction("values","readonly")
.objectStore("values").get(this.storage_id(args.namespace,args.key));
return this.storage_request(request);
}).then(record=>{
this.storage_send_result(args,0,record===undefined
?{found:false}
:{found:true,value:record.value});
}).catch(error=>{
this.storage_send_result(args,0,{error:this.storage_error_text(error)});
});
}
FromWasmStorageSet(args){
const value=this.clone_data_u8(args.value);
this.free_data_u8(args.value);
this.storage_database().then(db=>new Promise((resolve,reject)=>{
const transaction=db.transaction("values","readwrite");
transaction.oncomplete=()=>resolve();
transaction.onerror=()=>reject(transaction.error||new Error("IndexedDB write failed"));
transaction.onabort=()=>reject(transaction.error||new Error("IndexedDB write aborted"));
transaction.objectStore("values").put({
id:this.storage_id(args.namespace,args.key),
namespace:args.namespace,
key:args.key,
value:value.buffer
});
})).then(()=>{
this.storage_send_result(args,1);
}).catch(error=>{
this.storage_send_result(args,1,{
error:this.storage_error_text(error),
error_kind:error&&error.name==="QuotaExceededError"?1:0
});
});
}
FromWasmStorageDelete(args){
this.storage_database().then(db=>new Promise((resolve,reject)=>{
const transaction=db.transaction("values","readwrite");
transaction.oncomplete=()=>resolve();
transaction.onerror=()=>reject(transaction.error||new Error("IndexedDB delete failed"));
transaction.onabort=()=>reject(transaction.error||new Error("IndexedDB delete aborted"));
transaction.objectStore("values").delete(this.storage_id(args.namespace,args.key));
})).then(()=>{
this.storage_send_result(args,2);
}).catch(error=>{
this.storage_send_result(args,2,{error:this.storage_error_text(error)});
});
}
FromWasmStorageList(args){
this.storage_database().then(db=>new Promise((resolve,reject)=>{
const keys=[];
const request=db.transaction("values","readonly")
.objectStore("values").index("namespace")
.openCursor(IDBKeyRange.only(args.namespace));
request.onerror=()=>reject(request.error||new Error("IndexedDB cursor failed"));
request.onsuccess=()=>{
const cursor=request.result;
if(cursor===null){
resolve(keys);
return;
}
const key=cursor.value.key;
if(key.startsWith(args.prefix)&&(!args.has_after||key>args.after)){
keys.push(key);
if(keys.length>args.limit){
resolve(keys);
return;
}
}
cursor.continue();
};
})).then(keys=>{
let next;
if(keys.length>args.limit){
keys.length=args.limit;
next=keys[keys.length-1];
}
this.storage_send_result(args,3,{keys,next});
}).catch(error=>{
this.storage_send_result(args,3,{error:this.storage_error_text(error)});
});
}
FromWasmStorageGetRange(args){
this.storage_database().then(db=>{
const request=db.transaction("values","readonly")
.objectStore("values").get(this.storage_id(args.namespace,args.key));
return this.storage_request(request);
}).then(record=>{
if(record===undefined){
this.storage_send_result(args,4,{found:false});
return;
}
const value=new Uint8Array(record.value);
const offset=args.offset_hi>0x1fffff
?Number.MAX_SAFE_INTEGER
:args.offset_lo+args.offset_hi*0x100000000;
const end=Math.min(value.length,offset+args.len);
const range=offset>=value.length?new Uint8Array(0):value.slice(offset,end);
this.storage_send_result(args,4,{found:true,value:range});
}).catch(error=>{
this.storage_send_result(args,4,{error:this.storage_error_text(error)});
});
}
FromWasmStorageStat(args){
this.storage_database().then(db=>{
const request=db.transaction("values","readonly")
.objectStore("values").get(this.storage_id(args.namespace,args.key));
return this.storage_request(request);
}).then(record=>{
this.storage_send_result(args,5,record===undefined
?{found:false}
:{found:true,length:record.value.byteLength});
}).catch(error=>{
this.storage_send_result(args,5,{error:this.storage_error_text(error)});
});
}
FromWasmStorageEstimate(args){
const estimate=navigator.storage&&navigator.storage.estimate;
if(!estimate){
this.storage_send_result(args,6,{error:"storage estimate is unavailable"});
return;
}
navigator.storage.estimate().then(result=>{
this.storage_send_result(args,6,{
usage:Math.max(0,Math.floor(result.usage||0)),
quota:Math.max(0,Math.floor(result.quota||0))
});
}).catch(error=>{
this.storage_send_result(args,6,{error:this.storage_error_text(error)});
});
}
FromWasmShowTextIME(args){
if(this.ime)this.ime.show();
this.update_text_area_pos(args);
}
FromWasmSyncImeState(args){
if(this.ime)this.ime.sync(args);
}
FromWasmHideTextIME(){
if(this.ime){
const old_area=this.text_area;
const had_focus=document.activeElement===old_area;
this.ime.hide();
old_area.remove();
this.bind_keyboard(had_focus);
}
this.update_text_area_pos({x:-3000,y:-3000});
}
FromWasmWebSocketSend(args){
let web_socket=this.web_sockets[args.web_socket_id];
if(web_socket.readyState==0){
web_socket._queue.push(this.clone_data_u8(args.data))
}
else{
web_socket.send(this.clone_data_u8(args.data));
}
this.free_data_u8(args.data);
}
dispose_audio_worklet(audio_worklet){
if(!audio_worklet){
return;
}
if(audio_worklet.port){
audio_worklet.port.onmessage=null;
}
audio_worklet.onprocessorerror=null;
try{
audio_worklet.disconnect();
}catch(_error){
}
}
stop_audio_output(){
this.audio_start_args=null;
if(this.audio_callback_watchdog!==null){
clearTimeout(this.audio_callback_watchdog);
this.audio_callback_watchdog=null;
}
if(this.audio_startup_cancel){
this.audio_startup_cancel();
this.audio_startup_cancel=null;
}
if(this.audio_worklet){
this.dispose_audio_worklet(this.audio_worklet);
this.audio_worklet=null;
}
const audio_context=this.audio_context;
this.audio_context=null;
if(audio_context){
try{
const closing=audio_context.close();
if(closing&&typeof closing.catch==="function"){
closing.catch(error=>{
console.error(`web audio: close failed: ${error}`);
});
}
}catch(error){
console.error(`web audio: close failed: ${error}`);
}
}
}
FromWasmStopAudioOutput(_args){
this.stop_audio_output();
}
watch_audio_callback(audio_context){
if(this.webgl_context_lost
||!this.audio_worklet
||this.audio_callback_started
||this.audio_callback_watchdog!==null){
return;
}
this.audio_callback_watchdog=setTimeout(()=>{
this.audio_callback_watchdog=null;
if(this.audio_context===audio_context&&!this.audio_callback_started){
console.error(
`web audio: callback never called state=${audio_context.state} sample_rate=${audio_context.sampleRate} buffer=pending`,
);
}
},3000);
}
resume_audio_from_gesture(){
if(this.webgl_context_lost){
return;
}
this.had_user_gesture=true;
if(!this.audio_context&&this.audio_start_args){
const args=this.audio_start_args;
this.audio_start_args=null;
this.start_audio_output(args,1);
return;
}
const audio_context=this.audio_context;
if(!audio_context){
return;
}
if(audio_context.state==="running"){
this.watch_audio_callback(audio_context);
return;
}
if(audio_context.state!=="suspended"||audio_context._makepad_resume_pending){
return;
}
audio_context._makepad_resume_pending=true;
audio_context.resume().then(()=>{
audio_context._makepad_resume_pending=false;
if(this.audio_context!==audio_context){
return;
}
if(audio_context.state==="running"){
this.watch_audio_callback(audio_context);
}else{
console.error(
`web audio: context suspended after canvas gesture state=${audio_context.state} sample_rate=${audio_context.sampleRate} buffer=pending`,
);
}
}).catch(error=>{
audio_context._makepad_resume_pending=false;
console.error(
`web audio: resume failed state=${audio_context.state} sample_rate=${audio_context.sampleRate} buffer=pending: ${error}`,
);
});
}
FromWasmStartAudioOutput(args){
if(this.webgl_context_lost||this.audio_context){
return
}
if(!this.had_user_gesture){
this.audio_start_args=args;
return;
}
this.start_audio_output(args,1);
}
start_audio_output(args,attempt){
if(this.webgl_context_lost||this.audio_context){
return
}
let audio_context;
try{
audio_context=new AudioContext({
latencyHint:"interactive"
});
}catch(error){
console.error(`web audio: context creation failed: ${error}`);
return;
}
this.audio_context=audio_context;
this.audio_callback_started=false;
const start_worklet=async()=>{
let cancel_startup;
const cancelled=new Promise((_,reject)=>{
cancel_startup=()=>reject(new Error("audio startup cancelled"));
});
this.audio_startup_cancel=cancel_startup;
if(this.wasm._secondary_ready){
await Promise.race([this.wasm._secondary_ready,cancelled]);
}
if(this.webgl_context_lost||this.audio_context!==audio_context){
throw new Error("audio startup cancelled");
}
if(!this.wasm._has_thread_support){
throw new Error("wasm threading support is unavailable");
}
const thread_info=this.alloc_thread_stack(0,args.context_ptr);
if(!thread_info){
throw new Error("thread stack allocation prerequisites are unavailable");
}
let load_timeout=null;
try{
await Promise.race([
audio_context.audioWorklet.addModule("./makepad_platform/audio_worklet.js",{credentials:'omit'}),
new Promise((_,reject)=>{
load_timeout=setTimeout(()=>reject(new Error("worklet module load stalled")),4000);
}),
cancelled,
]);
}finally{
if(load_timeout!==null){
clearTimeout(load_timeout);
}
if(this.audio_startup_cancel===cancel_startup){
this.audio_startup_cancel=null;
}
}
if(this.webgl_context_lost||this.audio_context!==audio_context){
throw new Error("audio startup cancelled");
}
const audio_worklet=new AudioWorkletNode(audio_context,'audio-worklet',{
numberOfInputs:0,
numberOfOutputs:1,
outputChannelCount:[2],
processorOptions:{thread_info}
});
audio_worklet.port.onmessage=(e)=>{
if(this.webgl_context_lost||this.audio_context!==audio_context){
return;
}
let data=e.data;
switch(data.message_type){
case"console_log":
console.log(data.value);
break;
case"console_error":
console.error(data.value);
break;
case"wake_ui":
this.do_wasm_pump();
break;
case"audio_callback_started":
this.audio_callback_started=true;
if(this.audio_callback_watchdog!==null){
clearTimeout(this.audio_callback_watchdog);
this.audio_callback_watchdog=null;
}
console.log(
`web audio: callback running state=${audio_context.state} sample_rate=${data.sample_rate} buffer=${data.frames}x${data.channels}`,
);
break;
}
};
audio_worklet.onprocessorerror=(err)=>{
console.error(`web audio: processor failed: ${err}`);
}
audio_worklet.connect(audio_context.destination);
return audio_worklet;
};
start_worklet().then(audio_worklet=>{
if(this.webgl_context_lost||this.audio_context!==audio_context){
this.dispose_audio_worklet(audio_worklet);
return;
}
this.audio_worklet=audio_worklet;
if(audio_context.state==="running"){
this.watch_audio_callback(audio_context);
}
}).catch(error=>{
if(this.webgl_context_lost||this.audio_context!==audio_context){
return;
}
console.error(`web audio: start failed (attempt ${attempt}): ${error}`);
this.audio_context=null;
audio_context.close().catch(()=>{});
if(attempt<3){
this.start_audio_output(args,attempt+1);
}
});
}
FromWasmQueryAudioDevices(args){
if(this.webgl_context_lost){
return;
}
const publish_devices=(devices_enum)=>{
if(this.webgl_context_lost){
return;
}
let devices=[]
for(let device of devices_enum){
if(device.kind=="audioinput"){
devices.push({
web_device_id:""+device.deviceId,
label:""+device.label,
is_output:false
});
}
}
const output=devices_enum.find(device=>
device.kind=="audiooutput"&&device.deviceId=="default"
)||devices_enum.find(device=>device.kind=="audiooutput");
devices.push({
web_device_id:output?""+output.deviceId:"default",
label:output&&output.label?""+output.label:"Browser audio",
is_output:true
});
this.to_wasm.ToWasmAudioDeviceList({devices});
this.do_wasm_pump();
};
const query=navigator.mediaDevices?.enumerateDevices();
if(!query){
console.warn("web audio: device enumeration unavailable; using browser default");
publish_devices([]);
return;
}
query.then(publish_devices).catch(error=>{
if(this.webgl_context_lost){
return;
}
console.warn(`web audio: device enumeration failed; using browser default: ${error}`);
publish_devices([]);
});
}
FromWasmUseMidiInputs(args){
if(this.webgl_context_lost){
return;
}
outer:
for(let input of this.midi_inputs){
for(let uid of args.input_uids){
if(input.uid==uid){
input.port.onmidimessage=(e)=>{
if(this.webgl_context_lost){
return;
}
let data=e.data;
this.to_wasm.ToWasmMidiInputData({
uid,
data:(data[0]<<16)|(data[1]<<8)|data[2],
});
this.do_wasm_pump();
}
continue outer;
}
}
input.onmidimessage=undefined
}
}
FromWasmSendMidiOutput(args){
for(let output of this.midi_outputs){
if(output.uid==args.uid){
output.port.send([(data>>16)&0xff,(data>>8)&0xff,(data>>0)&0xff]);
}
}
}
FromWasmQueryMidiPorts(){
if(this.webgl_context_lost){
return;
}
if(this.reload_midi_ports){
return this.reload_midi_ports();
}
if(navigator.requestMIDIAccess){
navigator.requestMIDIAccess().then((midi)=>{
if(this.webgl_context_lost){
midi.onstatechange=null;
return;
}
this.reload_midi_ports=()=>{
if(this.webgl_context_lost){
return;
}
this.midi_inputs.length=0;
this.midi_outputs.length=0;
let ports=[];
for(let input_pair of midi.inputs){
let port=input_pair[1];
this.midi_inputs.push({
uid:""+port.id,
port
});
ports.push({
uid:""+port.id,
name:port.name,
is_output:false
});
}
for(let output_pair of midi.outputs){
let port=output_pair[1];
this.midi_outputs.push({
uid:""+port.id,
port
});
ports.push({
uid:""+port.id,
name:port.name,
is_output:true
});
}
this.to_wasm.ToWasmMidiPortList({ports});
this.do_wasm_pump();
}
midi.onstatechange=(e)=>{
this.reload_midi_ports();
}
this.reload_midi_ports();
},()=>{});
}
}
FromWasmStartPresentingXR(){
}
alloc_thread_stack(request_id,context_ptr,requested_stack_size){
if(!this.wasm._has_thread_support){
console.warn("alloc_thread_stack unavailable: wasm threading support is disabled");
return null;
}
if(this.exports.__stack_pointer===undefined){
console.warn("alloc_thread_stack unavailable: missing __stack_pointer export");
return null;
}
var ret={
request_id,
module:this.wasm._module,
secondary_module:this.wasm._secondary_module,
memory:this.wasm._memory,
context_ptr
};
if(typeof this.exports.__wbindgen_start!=='undefined'){
if(requested_stack_size&&requested_stack_size!==this.thread_stack_size){
console.warn("custom worker stack size is unavailable for wasm-bindgen workers");
return null;
}
ret.wasm_bindgen=true;
}else{
if(this.exports.__tls_size===undefined){
console.warn("alloc_thread_stack unavailable: missing __tls_size export");
return null;
}
if(typeof this.exports.wasm_thread_alloc_tls_and_stack!=="function"){
console.warn("alloc_thread_stack unavailable: missing wasm_thread_alloc_tls_and_stack export");
return null;
}
const raw_tls_size=this.exports.__tls_size.value;
const tls_size=(raw_tls_size+7)&~7;
const stack_size=requested_stack_size||this.thread_stack_size;
if(((tls_size+stack_size)&7)!==0){
console.warn("alloc_thread_stack unavailable: stack size is not 8-byte aligned");
return null;
}
const alloc_words=(tls_size+stack_size)>>3;
const arena_index=this.thread_stack_arena.findIndex(block=>block.words===alloc_words);
if(arena_index>=0){
const block=this.thread_stack_arena.splice(arena_index,1)[0];
ret.tls_ptr=block.ptr;
}else{
ret.tls_ptr=this.exports.wasm_thread_alloc_tls_and_stack(alloc_words);
this.update_array_buffer_refs();
}
ret.alloc_words=alloc_words;
ret.stack_ptr=ret.tls_ptr+tls_size+stack_size-8;
ret.wasm_bindgen=false;
}
return ret;
}
create_thread(args){
if(this.webgl_context_lost){
return;
}
let allocated_thread_info=null;
(async()=>{
if(this.wasm._secondary_ready){
await this.wasm._secondary_ready;
}
if(this.webgl_context_lost){
return;
}
if(!this.wasm._has_thread_support){
throw new Error("wasm file was not compiled with threading support");
}
let thread_info=this.alloc_thread_stack(args.request_id,args.context_ptr,args.stack_size);
if(!thread_info){
throw new Error("thread stack allocation prerequisites are missing");
}
allocated_thread_info=thread_info;
let worker=new Worker(
'./makepad_platform/web_worker.js',
{type:'module',name:args.name||`makepad-worker-${args.request_id}`}
);
const record={worker,thread_info,started:false,closed:false};
this.workers.set(args.request_id,record);
const release=()=>{
if(record.closed){
return;
}
record.closed=true;
worker.terminate();
this.workers.delete(args.request_id);
if(!thread_info.wasm_bindgen&&thread_info.tls_ptr){
this.thread_stack_arena.push({ptr:thread_info.tls_ptr,words:thread_info.alloc_words});
}
};
worker.onmessage=event=>{
if(record.closed||this.webgl_context_lost){
return;
}
const message=event.data||{};
const message_kind=message.kind||message.type;
if(message_kind==='breadcrumb'){
const level=["log","warn","error"].includes(message.level)
?message.level
:"log";
const text=message.text||"";
makepad_crash_reporter.add_breadcrumb(`worker.${level}`,[text],args.request_id);
const key=`${level}\n${text}`;
const now=performance.now();
const previous=this.worker_console_recent.get(key);
this.worker_console_recent.set(key,now);
if(previous===undefined||now-previous>100){
makepad_page_console[level](`[worker ${args.request_id}] ${text}`);
}
if(this.worker_console_recent.size>100){
for(const[old_key,seen_at]of this.worker_console_recent){
if(now-seen_at>100){
this.worker_console_recent.delete(old_key);
}
}
}
}else if(message_kind==='panic'){
record.last_panic={text:String(message.text||""),time:Date.now()};
}else if(message_kind==='spawn_request'){
this.create_thread(message);
}else if(message_kind==='wake_ui'){
this.js_wake_ui();
}else if(message_kind==='started'){
record.started=true;
this.exports.wasm_thread_started(args.request_id);
}else if(message_kind==='finished'){
this.exports.wasm_thread_finished(args.request_id);
release();
}else if(message_kind==='trapped'){
report_browser_issue("worker.error",{
worker_index:args.request_id,
message:message.message||message.error||"worker trapped",
filename:message.filename||"",
lineno:message.lineno||0,
stack:message.stack||"",
panic:record.last_panic&&Date.now()-record.last_panic.time<=1000
?record.last_panic.text
:""
});
this.exports.wasm_thread_worker_lost(args.request_id);
release();
}else if(message_kind==='failed_to_start'){
report_browser_issue("worker.error",{
worker_index:args.request_id,
message:message.message||message.error||"worker failed to start",
filename:message.filename||"",
lineno:message.lineno||0,
stack:message.stack||""
});
this.exports.wasm_thread_failed_to_start(args.request_id);
release();
}
};
const on_worker_error=error=>{
if(record.closed){
return;
}
console.error(error);
report_browser_issue("worker.error",{
worker_index:args.request_id,
message:error&&error.message?String(error.message):String(error),
filename:error&&error.filename?String(error.filename):"",
lineno:error&&error.lineno?error.lineno:0,
colno:error&&error.colno?error.colno:0,
stack:error&&error.error&&error.error.stack?String(error.error.stack):"",
panic:record.last_panic&&Date.now()-record.last_panic.time<=1000
?record.last_panic.text
:""
});
if(record.started){
this.exports.wasm_thread_worker_lost(args.request_id);
}else{
this.exports.wasm_thread_failed_to_start(args.request_id);
}
release();
};
worker.onerror=on_worker_error;
worker.addEventListener("error",on_worker_error);
worker.addEventListener("messageerror",error=>{
if(record.closed){
return;
}
report_browser_issue("worker.error",{
worker_index:args.request_id,
message:error&&error.message?String(error.message):"worker message could not be decoded",
filename:"",
lineno:0,
stack:""
});
if(record.started){
this.exports.wasm_thread_worker_lost(args.request_id);
}else{
this.exports.wasm_thread_failed_to_start(args.request_id);
}
release();
});
worker.postMessage(thread_info);
})().catch(err=>{
if(this.webgl_context_lost){
return;
}
console.error(err);
report_browser_issue("worker.error",{
worker_index:args.request_id,
message:err&&err.message?String(err.message):String(err),
filename:err&&err.fileName?String(err.fileName):"",
lineno:err&&err.lineNumber?err.lineNumber:0,
stack:err&&err.stack?String(err.stack):""
});
const record=this.workers.get(args.request_id);
if(record){
record.closed=true;
record.worker.terminate();
this.workers.delete(args.request_id);
}
if(allocated_thread_info&&!allocated_thread_info.wasm_bindgen){
this.thread_stack_arena.push({
ptr:allocated_thread_info.tls_ptr,
words:allocated_thread_info.alloc_words
});
}
this.exports.wasm_thread_failed_to_start(args.request_id);
});
}
start_signal_poll(){
if(this.webgl_context_lost){
return;
}
this.poll_timer=window.setInterval(e=>{
if(this.webgl_context_lost||makepad_crash_reporter.is_wasm_dead()){
return;
}
let flags=this.exports.wasm_check_signal();
if(flags!=0){
this.to_wasm.ToWasmSignal({flags});
this.do_wasm_pump();
}
},0.016*1000.0);
}
parse_and_set_headers(request,headers_string){
let lines=headers_string.split("\r\n");
for(let line of lines){
let parts=line.split(": ");
if(parts.length==2){
request.setRequestHeader(parts[0],parts[1]);
}
}
}
id_to_key(id_lo,id_hi){
return`${id_lo}:${id_hi}`;
}
alloc_u8(input_u8){
let ptr=this.wasm_new_data_u8(input_u8.length);
let out=new Uint8Array(this.memory.buffer,ptr,input_u8.length);
out.set(input_u8);
return{ptr,len:input_u8.length};
}
string_to_u8(s){
const encoder=new TextEncoder();
return this.alloc_u8(encoder.encode(s));
}
array_to_u8(u8_array){
return this.alloc_u8(u8_array);
}
u8_to_array(ptr,len){
let u8=new Uint8Array(this.memory.buffer,ptr,len);
let copy=new Uint8Array(len);
copy.set(u8);
return copy;
}
js_network_http_request(
request_id_lo,
request_id_hi,
metadata_id_lo,
metadata_id_hi,
url_ptr,
url_len,
method_ptr,
method_len,
headers_ptr,
headers_len,
body_ptr,
body_len,
max_body_lo,
max_body_hi
){
if(this.webgl_context_lost){
return;
}
let url=this.u8_to_string(url_ptr,url_len);
let method=this.u8_to_string(method_ptr,method_len);
let headers_raw=this.u8_to_string(headers_ptr,headers_len);
let body=body_len>0?this.u8_to_array(body_ptr,body_len):undefined;
let request_key=this.id_to_key(request_id_lo,request_id_hi);
let max_body=max_body_lo+max_body_hi*4294967296;
let headers=new Headers();
for(let line of headers_raw.split("\r\n")){
if(!line){
continue;
}
let sep=line.indexOf(":");
if(sep<=0){
continue;
}
let key=line.slice(0,sep).trim();
let value=line.slice(sep+1).trim();
if(!key){
continue;
}
try{
headers.append(key,value);
}
catch(_error){
}
}
let parsed_url;
try{
parsed_url=new URL(url,window.location.href);
}
catch(_error){
parsed_url=new URL(window.location.href);
}
const telemetry=new URLSearchParams(parsed_url.hash.slice(1));
const is_archive=telemetry.get("makepad-http")==="archive";
const is_archive_range=is_archive&&telemetry.get("range")==="1";
const tile_keys=telemetry.get("tiles")||"-";
const priority=Number(telemetry.get("priority")||Number.MAX_SAFE_INTEGER);
const range_bytes=Number(telemetry.get("bytes")||0);
parsed_url.hash="";
const fetch_url=parsed_url.href;
const host_key=parsed_url.origin;
const entry={
request_key,
request_id_lo,
request_id_hi,
metadata_id_lo,
metadata_id_hi,
fetch_url,
method,
headers,
body,
max_body,
host_key,
is_archive,
is_archive_range,
tile_keys,
priority,
range_bytes,
state:"queued",
controller:null,
stall_timer:null,
started_at:0,
response_bytes:0,
};
this.network_http_requests.set(request_key,entry);
if(!is_archive){
this.network_http_dispatch(entry);
return;
}
let host=this.network_http_hosts.get(host_key);
if(!host){
host={active:0,pending:0,queue:[],round:null};
this.network_http_hosts.set(host_key,host);
}
host.pending+=1;
host.queue.push(entry);
host.queue.sort((left,right)=>
left.priority-right.priority
||right.range_bytes-left.range_bytes
||left.fetch_url.localeCompare(right.fetch_url)
);
this.network_http_pump(host_key);
}
network_http_pump(host_key){
if(this.webgl_context_lost){
return;
}
const host=this.network_http_hosts.get(host_key);
if(!host){
return;
}
while(host.active<5&&host.queue.length>0){
const entry=host.queue.shift();
if(this.network_http_requests.get(entry.request_key)!==entry){
continue;
}
host.active+=1;
this.network_http_dispatch(entry);
}
}
network_http_dispatch(entry){
if(this.webgl_context_lost||entry.state==="terminal"){
return;
}
entry.state="active";
entry.controller=new AbortController();
entry.started_at=performance.now();
if(entry.is_archive_range){
let host=this.network_http_hosts.get(entry.host_key);
if(!host.round){
host.round={
started_at:entry.started_at,
ranges:0,
bytes:0,
tiles:new Set(),
};
}
host.round.ranges+=1;
for(const key of entry.tile_keys.split(",")){
if(key&&key!=="-"){
host.round.tiles.add(key);
}
}
}
const arm_stall_timer=()=>{
if(this.webgl_context_lost||entry.state==="terminal"){
return;
}
if(entry.stall_timer!==null){
window.clearTimeout(entry.stall_timer);
}
entry.stall_timer=window.setTimeout(()=>{
entry.controller.abort("HTTP request stalled for 20 seconds after dispatch");
},20000);
};
arm_stall_timer();
this.exports.wasm_network_http_progress(
entry.request_id_lo,
entry.request_id_hi,
0,
0
);
fetch(entry.fetch_url,{
method:entry.method,
headers:entry.headers,
body:entry.body,
signal:entry.controller.signal,
redirect:"manual",
}).then(async response=>{
if(this.webgl_context_lost||entry.state==="terminal"){
return;
}
arm_stall_timer();
let response_headers="";
response.headers.forEach((value,key)=>{
response_headers+=`${key}: ${value}\r\n`;
});
const declared=response.headers.get("content-length");
if(entry.method!=="HEAD"&&declared!==null&&Number(declared)>entry.max_body){
entry.controller.abort();
throw"response body exceeds configured limit";
}
let chunks=[];
let response_body_len=0;
if(response.body!==null){
const reader=response.body.getReader();
for(;;){
const item=await reader.read();
if(this.webgl_context_lost||entry.state==="terminal"){
return;
}
if(item.done){
break;
}
arm_stall_timer();
response_body_len+=item.value.byteLength;
if(response_body_len>entry.max_body){
entry.controller.abort();
throw"response body exceeds configured limit";
}
chunks.push(item.value);
}
}
let response_body=new Uint8Array(response_body_len);
let body_at=0;
for(const chunk of chunks){
response_body.set(chunk,body_at);
body_at+=chunk.byteLength;
}
if(this.webgl_context_lost||entry.state==="terminal"){
return;
}
let headers_u8=this.string_to_u8(response_headers);
let body_u8=this.array_to_u8(response_body);
entry.response_bytes=response_body.length;
if(response.status>=400){
console.error("[makepad][http][fail]",response.status,entry.fetch_url);
}
this.exports.wasm_network_http_response(
entry.request_id_lo,
entry.request_id_hi,
entry.metadata_id_lo,
entry.metadata_id_hi,
response.status,
headers_u8.ptr,
headers_u8.len,
body_u8.ptr,
body_u8.len
);
}).catch(error=>{
if(this.webgl_context_lost||entry.state==="terminal"){
return;
}
console.error(
"[makepad][http][err]",
entry.method,
entry.fetch_url,
""+error,
`tiles=${entry.tile_keys}`
);
let message_u8=this.string_to_u8(""+error);
this.exports.wasm_network_http_error(
entry.request_id_lo,
entry.request_id_hi,
entry.metadata_id_lo,
entry.metadata_id_hi,
message_u8.ptr,
message_u8.len
);
}).finally(()=>{
this.network_http_finish(entry);
});
}
network_http_finish(entry){
if(entry.stall_timer!==null){
window.clearTimeout(entry.stall_timer);
entry.stall_timer=null;
}
if(this.network_http_requests.get(entry.request_key)===entry){
this.network_http_requests.delete(entry.request_key);
}
entry.state="done";
if(this.webgl_context_lost){
return;
}
if(!entry.is_archive){
return;
}
const host=this.network_http_hosts.get(entry.host_key);
if(!host){
return;
}
host.active=Math.max(0,host.active-1);
host.pending=Math.max(0,host.pending-1);
if(host.round&&entry.is_archive_range){
host.round.bytes+=entry.response_bytes;
}
this.network_http_pump(entry.host_key);
if(host.pending===0){
if(host.round){
host.round=null;
}
if(host.active===0&&host.queue.length===0){
this.network_http_hosts.delete(entry.host_key);
}
}
}
js_network_http_cancel(request_id_lo,request_id_hi){
let request_key=this.id_to_key(request_id_lo,request_id_hi);
let entry=this.network_http_requests.get(request_key);
if(!entry){
return;
}
if(entry.is_archive&&entry.state==="queued"){
const host=this.network_http_hosts.get(entry.host_key);
if(host){
host.queue=host.queue.filter(item=>item!==entry);
host.pending=Math.max(0,host.pending-1);
if(host.pending===0&&host.round){
host.round=null;
}
}
this.network_http_requests.delete(request_key);
entry.state="cancelled";
const message_u8=this.string_to_u8("HTTP request cancelled before dispatch");
this.exports.wasm_network_http_error(
entry.request_id_lo,
entry.request_id_hi,
entry.metadata_id_lo,
entry.metadata_id_hi,
message_u8.ptr,
message_u8.len
);
if(host&&host.pending===0&&host.active===0){
this.network_http_hosts.delete(entry.host_key);
}
return;
}
if(entry.is_archive&&entry.state==="active"){
return;
}
entry.controller.abort();
this.network_http_requests.delete(request_key);
}
js_network_ws_open(socket_id_lo,socket_id_hi,url_ptr,url_len,_headers_ptr,_headers_len){
if(this.webgl_context_lost){
return;
}
let socket_key=this.id_to_key(socket_id_lo,socket_id_hi);
let url=this.u8_to_string(url_ptr,url_len);
let web_socket=new WebSocket(url);
web_socket.binaryType="arraybuffer";
this.network_web_sockets[socket_key]=web_socket;
web_socket.onclose=_e=>{
if(this.webgl_context_lost){
return;
}
this.exports.wasm_network_ws_closed(socket_id_lo,socket_id_hi);
delete this.network_web_sockets[socket_key];
};
web_socket.onerror=e=>{
if(this.webgl_context_lost){
return;
}
let message=this.string_to_u8(""+e);
this.exports.wasm_network_ws_error(
socket_id_lo,
socket_id_hi,
message.ptr,
message.len
);
};
web_socket.onmessage=e=>{
if(this.webgl_context_lost){
return;
}
if(typeof e.data=="string"){
let data=this.string_to_u8(""+e.data);
this.exports.wasm_network_ws_text(
socket_id_lo,
socket_id_hi,
data.ptr,
data.len
);
}
else{
let data=this.array_to_u8(new Uint8Array(e.data));
this.exports.wasm_network_ws_binary(
socket_id_lo,
socket_id_hi,
data.ptr,
data.len
);
}
};
web_socket.onopen=_e=>{
if(this.webgl_context_lost){
return;
}
this.exports.wasm_network_ws_opened(socket_id_lo,socket_id_hi);
};
}
js_network_ws_send_binary(socket_id_lo,socket_id_hi,data_ptr,data_len){
let socket=this.network_web_sockets[this.id_to_key(socket_id_lo,socket_id_hi)];
if(socket&&socket.readyState===WebSocket.OPEN){
socket.send(this.u8_to_array(data_ptr,data_len));
}
}
js_network_ws_send_text(socket_id_lo,socket_id_hi,data_ptr,data_len){
let socket=this.network_web_sockets[this.id_to_key(socket_id_lo,socket_id_hi)];
if(socket&&socket.readyState===WebSocket.OPEN){
socket.send(this.u8_to_string(data_ptr,data_len));
}
}
js_network_ws_close(socket_id_lo,socket_id_hi){
let socket_key=this.id_to_key(socket_id_lo,socket_id_hi);
let socket=this.network_web_sockets[socket_key];
if(socket){
socket.close();
delete this.network_web_sockets[socket_key];
}
}
FromWasmHTTPRequest(args){
if(this.webgl_context_lost){
return;
}
const req=new XMLHttpRequest();
this.legacy_http_requests.add(req);
req.open(args.method,args.url);
req.responseType="arraybuffer";
this.parse_and_set_headers(req,args.headers);
const body=this.clone_data_u8(args.body);
req.addEventListener("load",event=>{
if(this.webgl_context_lost){
return;
}
let responseEvent=event.target;
if(responseEvent.status<200||responseEvent.status>=300){
report_browser_issue("xhr.http_error",{
method:args.method,
url:args.url,
status:responseEvent.status,
});
}
this.to_wasm.ToWasmHTTPResponse({
request_id_lo:args.request_id_lo,
request_id_hi:args.request_id_hi,
metadata_id_lo:args.metadata_id_lo,
metadata_id_hi:args.metadata_id_hi,
status:responseEvent.status,
body:responseEvent.response,
headers:responseEvent.getAllResponseHeaders()
});
this.do_wasm_pump();
});
req.addEventListener("error",event=>{
if(this.webgl_context_lost){
return;
}
let errorMessage="An error occurred with the HTTP request.";
if(!navigator.onLine){
errorMessage="The browser is offline.";
}
report_browser_issue("xhr.error",{
method:args.method,
url:args.url,
message:errorMessage,
});
this.to_wasm.ToWasmHttpRequestError({
request_id_lo:args.request_id_lo,
request_id_hi:args.request_id_hi,
error:errorMessage,
});
this.do_wasm_pump();
});
req.addEventListener("timeout",event=>{
if(this.webgl_context_lost){
return;
}
report_browser_issue("xhr.timeout",{
method:args.method,
url:args.url,
});
this.to_wasm.ToWasmHttpRequestError({
request_id_lo:args.request_id_lo,
request_id_hi:args.request_id_hi,
error:"The HTTP request timed out.",
});
this.do_wasm_pump();
});
req.addEventListener("abort",event=>{
if(this.webgl_context_lost){
return;
}
report_browser_issue("xhr.abort",{
method:args.method,
url:args.url,
});
this.to_wasm.ToWasmHttpRequestError({
request_id_lo:args.request_id_lo,
request_id_hi:args.request_id_hi,
error:"The HTTP request was aborted.",
});
this.do_wasm_pump();
});
req.addEventListener("progress",event=>{
if(this.webgl_context_lost){
return;
}
if(event.lengthComputable){
this.to_wasm.ToWasmHttpResponseProgress({
request_id_lo:args.request_id_lo,
request_id_hi:args.request_id_hi,
loaded:event.loaded,
total:event.total,
});
this.do_wasm_pump();
}
});
req.upload.addEventListener("progress",(event)=>{
if(this.webgl_context_lost){
return;
}
if(event.lengthComputable){
this.to_wasm.ToWasmHttpUploadProgress({
request_id_lo:args.request_id_lo,
request_id_hi:args.request_id_hi,
loaded:event.loaded,
total:event.total,
});
this.do_wasm_pump();
}
});
req.addEventListener("loadend",()=>{
this.legacy_http_requests.delete(req);
});
try{
req.send(body);
}finally{
this.free_data_u8(args.body);
}
}
FromWasmCancelHTTPRequest(args){
}
FromWasmSetVirtualFileLimits(args){
this.virtual_file_max_size=args.max_file_size;
this.virtual_file_max_total_size=args.max_total_size;
}
read_virtual_files(file_list,max_file_size,max_total_size){
const files=Array.from(file_list);
let total=0;
for(const file of files){
if(file.size>max_file_size){
return Promise.reject(new Error(
`file '${file.name}' is ${file.size} bytes, exceeding the per-file limit of ${max_file_size} bytes`
));
}
total+=file.size;
if(!Number.isSafeInteger(total)||total>max_total_size){
return Promise.reject(new Error(
`selected files total ${total} bytes, exceeding the per-drop limit of ${max_total_size} bytes`
));
}
}
return Promise.all(files.map(async file=>{
const bytes=await file.arrayBuffer();
if(bytes.byteLength>max_file_size){
throw new Error(
`file '${file.name}' grew to ${bytes.byteLength} bytes, exceeding the per-file limit of ${max_file_size} bytes`
);
}
return{
name:file.name+"",
mime:file.type+"",
bytes,
};
})).then(loaded=>{
const loaded_total=loaded.reduce((sum,file)=>sum+file.bytes.byteLength,0);
if(!Number.isSafeInteger(loaded_total)||loaded_total>max_total_size){
throw new Error(
`loaded files total ${loaded_total} bytes, exceeding the per-drop limit of ${max_total_size} bytes`
);
}
return loaded;
});
}
FromWasmSelectFileDialog(args){
if(this.webgl_context_lost){
return;
}
const input=document.createElement('input');
input.type='file';
input.style.display='none';
input.multiple=args.multiple;
if(args.accept){
input.accept=args.accept;
}
document.body.appendChild(input);
let settled=false;
let selection_started=false;
let picker_blurred_window=false;
const cleanup=()=>{
window.removeEventListener('blur',on_blur);
window.removeEventListener('focus',on_focus);
if(input.parentNode){
input.parentNode.removeChild(input);
}
};
const finish=(cancelled,files,error)=>{
if(settled){
return;
}
settled=true;
cleanup();
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmFileDialogResult({
id_lo:args.id_lo,
id_hi:args.id_hi,
cancelled,
error,
files,
});
this.do_wasm_pump();
};
const cancel=()=>finish(true,[],"");
const on_blur=()=>{
picker_blurred_window=true;
};
const on_focus=()=>{
if(picker_blurred_window){
window.setTimeout(()=>{
if(!selection_started){
cancel();
}
},0);
}
};
input.addEventListener('change',()=>{
selection_started=true;
if(!input.files||input.files.length===0){
cancel();
return;
}
this.read_virtual_files(input.files,args.max_file_size,args.max_total_size)
.then(files=>finish(false,files,""))
.catch(error=>finish(true,[],""+error));
});
input.addEventListener('cancel',cancel);
window.addEventListener('blur',on_blur);
window.addEventListener('focus',on_focus);
try{
input.click();
}
catch(error){
finish(true,[],"browser rejected file picker: "+error);
}
}
async FromWasmCheckPermission(args){
if(this.webgl_context_lost){
return;
}
try{
if(args.permission==='microphone'||args.permission==='camera'||args.permission==='geolocation'){
if(navigator.permissions&&navigator.permissions.query){
const result=await navigator.permissions.query({name:args.permission});
if(this.webgl_context_lost){
return;
}
let status;
switch(result.state){
case'granted':
status=1;
break;
case'denied':
status=3;
break;
case'prompt':
default:
status=0;
break;
}
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:status
});
}else if(args.permission==='geolocation'){
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:0
});
}else{
const kind=args.permission==='microphone'?'audioinput':'videoinput';
try{
const devices=await navigator.mediaDevices.enumerateDevices();
if(this.webgl_context_lost){
return;
}
const hasDevice=devices.some(device=>device.kind===kind&&device.label!=='');
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:hasDevice?1:0
});
}catch{
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:0
});
}
}
}else{
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:3
});
}
}catch(error){
if(this.webgl_context_lost){
return;
}
console.error('Permission check failed:',error);
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:3
});
}
this.do_wasm_pump();
}
async FromWasmRequestPermission(args){
if(this.webgl_context_lost){
return;
}
try{
if(args.permission==='microphone'||args.permission==='camera'){
try{
const constraints=args.permission==='microphone'?{audio:true}:{video:true};
const stream=await navigator.mediaDevices.getUserMedia(constraints);
stream.getTracks().forEach(track=>track.stop());
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:1
});
}catch(error){
if(this.webgl_context_lost){
return;
}
let status=3;
if(error.name==='NotAllowedError'||error.name==='PermissionDeniedError'){
status=3;
}else if(error.name==='NotFoundError'||error.name==='DevicesNotFoundError'){
status=3;
}else if(error.name==='NotReadableError'||error.name==='TrackStartError'){
status=2;
}
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:status
});
}
}else if(args.permission==='geolocation'&&navigator.geolocation){
navigator.geolocation.getCurrentPosition(
(_pos)=>{
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:1
});
this.do_wasm_pump();
},
(err)=>{
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:err.code===1?3:2
});
this.do_wasm_pump();
},
{timeout:30000}
);
return;
}else{
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:3
});
}
}catch(error){
if(this.webgl_context_lost){
return;
}
console.error('Permission request failed:',error);
this.to_wasm.ToWasmPermissionResult({
permission:args.permission,
request_id:args.request_id,
status:3
});
}
this.do_wasm_pump();
}
wasm_create_app(){
let new_ptr=this.exports.wasm_create_app();
this.update_array_buffer_refs();
return new_ptr
}
wasm_return_first_msg(){
let ret_ptr=this.exports.wasm_return_first_msg(this.wasm_app)
this.update_array_buffer_refs();
return this.new_from_wasm(ret_ptr);
}
dispatch_first_msg(){
let from_wasm=this.wasm_return_first_msg();
from_wasm.dispatch_on_app();
from_wasm.free();
}
do_wasm_pump(){
if(this.webgl_context_lost){
return;
}
if(makepad_crash_reporter.is_wasm_dead()){
makepad_crash_reporter.suppress_followup();
return;
}
let started=performance.now();
try{
this.buffer_upload_serial+=1;
let to_wasm=this.to_wasm;
this.to_wasm=this.new_to_wasm();
let from_wasm=this.wasm_process_msg(to_wasm);
from_wasm.dispatch_on_app();
from_wasm.free();
this.update_startup_loader(performance.now()-started);
}catch(error){
let context_lost=this.webgl_context_lost;
if(!context_lost&&this.gl&&typeof this.gl.isContextLost==="function"){
try{
context_lost=this.gl.isContextLost();
}catch(_query_error){
}
}
if(context_lost){
if(typeof this.handle_webgl_context_lost==="function"){
this.handle_webgl_context_lost();
}
return;
}
makepad_crash_reporter.mark_wasm_dead(error);
void makepad_crash_reporter.report("window.error",{
message:error&&error.message?String(error.message):String(error),
stack:error&&error.stack?String(error.stack):""
});
throw error;
}
}
wasm_process_msg(to_wasm){
if(this.debug_sum_ptr!==undefined){
let ptr=this.debug_sum_ptr;
this.debug_sum_ptr=undefined;
var u8_out=new Uint8Array(this.memory.buffer,ptr.ptr,ptr.len);
let sum=0
for(let i=0;i<ptr.len;i++){
sum+=u8_out[i];
}
}
let ret_ptr=this.exports.wasm_process_msg(to_wasm.release_ownership(),this.wasm_app)
this.update_array_buffer_refs();
return this.new_from_wasm(ret_ptr);
}
init_detection(){
this.detect={
user_agent:window.navigator.userAgent,
is_mobile_safari:window.navigator.platform.match(/iPhone|iPad/i),
is_touch_device:('ontouchstart'in window||navigator.maxTouchPoints),
is_firefox:navigator.userAgent.toLowerCase().indexOf('firefox')>-1,
use_touch_scroll_overlay:window.ontouchstart===null,
};
this.detect.is_android=this.detect.user_agent.match(/Android/i)
this.detect.is_add_to_homescreen_safari=this.is_mobile_safari&&navigator.standalone
}
ensure_render_quality(){
if(this.render_quality!==null){
return this.render_quality;
}
const canvas=this.canvas;
const read_number=(name,fallback)=>{
const attribute=canvas.getAttribute(name);
return makepad_positive_number(attribute,fallback);
};
const phone_ceiling=WasmBridge.is_phone()
?MAKEPAD_WEBGL_PHONE_DPR_CEILING
:MAKEPAD_WEBGL_DPR_CEILING;
this.render_quality={
pixel_budget:read_number("renderpixelbudget",MAKEPAD_WEBGL_PIXEL_BUDGET),
dpr_ceiling:read_number("maxdpr",phone_ceiling),
};
return this.render_quality;
}
update_window_info(){
var w;
var h;
var canvas=this.canvas;
if(canvas.getAttribute("fullpage")){
if(this.detect.is_add_to_homescreen_safari){
if(window.orientation==90||window.orientation==-90){
h=screen.width;
w=screen.height-90;
}
else{
w=screen.width;
h=screen.height-80;
}
}
else{
w=window.innerWidth;
h=window.innerHeight;
}
}
else{
w=canvas.offsetWidth;
h=canvas.offsetHeight;
}
const physical_device_dpi=makepad_device_pixel_ratio(window.devicePixelRatio);
this.physical_device_dpi=physical_device_dpi;
const quality=this.ensure_render_quality();
const size=makepad_compute_webgl_size(
w,
h,
Math.min(physical_device_dpi,quality.dpr_ceiling),
this.webgl_limits,
quality.pixel_budget,
);
if(canvas.width!==size.width){
canvas.width=size.width;
}
if(canvas.height!==size.height){
canvas.height=size.height;
}
if(this.gl&&!this.webgl_context_lost){
this.gl.viewport(0,0,size.width,size.height);
}
this.dpi_factor=size.scale;
this.window_info.dpi_factor=size.scale;
this.window_info.inner_width=size.logical_width;
this.window_info.inner_height=size.logical_height;
this.window_info.is_fullscreen=is_fullscreen();
this.window_info.can_fullscreen=can_fullscreen();
}
query_xr_capabilities(){
return Promise.all([]);
}
bind_screen_resize(){
this.handlers.on_screen_resize=()=>{
if(this.webgl_context_lost){
return;
}
this.update_window_info();
if(this.to_wasm!==undefined){
this.to_wasm.ToWasmResizeWindow({window_info:this.window_info});
this.FromWasmRequestAnimationFrame();
}
}
this.handlers.on_app_got_focus=()=>{
this.to_wasm.ToWasmWindowGotFocus();
this.do_wasm_pump();
}
this.handlers.on_app_lost_focus=()=>{
this.to_wasm.ToWasmWindowLostFocus();
this.do_wasm_pump();
}
window.addEventListener('resize',_=>this.handlers.on_screen_resize())
window.addEventListener('orientationchange',_=>this.handlers.on_screen_resize())
document.addEventListener('fullscreenchange',_=>this.handlers.on_screen_resize())
document.addEventListener('webkitfullscreenchange',_=>this.handlers.on_screen_resize())
}
bind_mouse_and_touch(){
var canvas=this.canvas
function mouse_to_wasm_wmouse(e){
return{
x:e.pageX,
y:e.pageY,
button:e.button,
time:e.timeStamp/1000.0,
modifiers:pack_key_modifier(e)
}
}
this.handlers.on_mouse_down=e=>{
this.resume_audio_from_gesture();
e.preventDefault();
this.focus_keyboard_input();
this.to_wasm.ToWasmMouseDown({mouse:mouse_to_wasm_wmouse(e)});
this.do_wasm_pump();
if(this.ime&&this.ime.active)this.ime.flush();
this.resume_audio_from_gesture();
}
this.handlers.on_mouse_up=e=>{
e.preventDefault();
this.to_wasm.ToWasmMouseUp({mouse:mouse_to_wasm_wmouse(e)});
this.do_wasm_pump();
if(this.ime&&this.ime.active)this.ime.flush();
}
this.handlers.on_mouse_move=e=>{
document.body.scrollTop=0;
document.body.scrollLeft=0;
this.to_wasm.ToWasmMouseMove({was_out:false,mouse:mouse_to_wasm_wmouse(e)});
this.do_wasm_pump();
if(this.ime&&this.ime.active)this.ime.flush();
}
this.handlers.on_mouse_out=e=>{
this.to_wasm.ToWasmMouseMove({was_out:true,mouse:mouse_to_wasm_wmouse(e)});
this.do_wasm_pump();
}
canvas.addEventListener('mousedown',e=>this.handlers.on_mouse_down(e))
window.addEventListener('mouseup',e=>this.handlers.on_mouse_up(e))
window.addEventListener('mousemove',e=>this.handlers.on_mouse_move(e));
window.addEventListener('mouseout',e=>this.handlers.on_mouse_out(e));
this.handlers.on_contextmenu=e=>{
e.preventDefault()
return false
}
canvas.addEventListener('contextmenu',e=>this.handlers.on_contextmenu(e))
function touch_to_wasm_wtouch(t,state){
return{
state,
x:t.pageX,
y:t.pageY,
radius_x:t.radiusX,
radius_y:t.radiusY,
rotation_angle:t.rotationAngle,
force:t.force,
uid:t.identifier===undefined?i:t.identifier,
}
}
function touches_to_wasm_wtouches(e,state){
let f=[];
for(let i=0;i<e.changedTouches.length;i++){
f.push(touch_to_wasm_wtouch(e.changedTouches[i],state));
}
touch_loop:
for(let i=0;i<e.touches.length;i++){
let t=e.touches[i];
for(let j=0;j<e.changedTouches.length;j++){
if(e.changedTouches[j].identifier==t.identifier){
continue touch_loop;
}
}
f.push(touch_to_wasm_wtouch(t,0));
}
return f
}
this.handlers.on_touchstart=e=>{
this.resume_audio_from_gesture();
e.preventDefault()
this.to_wasm.ToWasmTouchUpdate({
time:e.timeStamp/1000.0,
modifiers:pack_key_modifier(e),
touches:touches_to_wasm_wtouches(e,1)
});
this.do_wasm_pump();
this.resume_audio_from_gesture();
return false
}
this.handlers.on_touchmove=e=>{
e.preventDefault();
this.to_wasm.ToWasmTouchUpdate({
time:e.timeStamp/1000.0,
modifiers:pack_key_modifier(e),
touches:touches_to_wasm_wtouches(e,2)
});
this.do_wasm_pump();
return false
}
this.handlers.on_touch_end_cancel_leave=e=>{
e.preventDefault();
this.to_wasm.ToWasmTouchUpdate({
time:e.timeStamp/1000.0,
modifiers:pack_key_modifier(e),
touches:touches_to_wasm_wtouches(e,e.type==="touchend"?3:4)
});
this.do_wasm_pump();
return false
}
canvas.addEventListener('touchstart',e=>this.handlers.on_touchstart(e),{passive:false})
canvas.addEventListener('touchmove',e=>this.handlers.on_touchmove(e),{passive:false})
canvas.addEventListener('touchend',e=>this.handlers.on_touch_end_cancel_leave(e),{passive:false});
canvas.addEventListener('touchcancel',e=>this.handlers.on_touch_end_cancel_leave(e),{passive:false});
canvas.addEventListener('touchleave',e=>this.handlers.on_touch_end_cancel_leave(e),{passive:false});
var last_wheel_time;
var last_was_wheel;
this.handlers.on_mouse_wheel=e=>{
e.preventDefault()
let delta=e.timeStamp-last_wheel_time;
last_wheel_time=e.timeStamp;
if(this.detect.is_firefox){
last_was_wheel=e.deltaMode==1
}
else{
if(Math.abs(Math.abs((e.deltaY/e.wheelDeltaY))-(1./3.))<0.00001||!last_was_wheel&&delta<250){
last_was_wheel=false;
}
else{
last_was_wheel=true;
}
}
var fac=1
if(e.deltaMode===1)fac=40
else if(e.deltaMode===2)fac=window.offsetHeight
this.to_wasm.ToWasmScroll({
x:e.pageX,
y:e.pageY,
modifiers:pack_key_modifier(e),
is_touch:!last_was_wheel,
scroll_x:e.deltaX*fac,
scroll_y:e.deltaY*fac,
time:e.timeStamp/1000.0,
});
this.do_wasm_pump();
};
canvas.addEventListener('wheel',e=>this.handlers.on_mouse_wheel(e))
}
bind_file_drop(){
const canvas=this.canvas;
const file_count=event=>{
if(event.dataTransfer.files&&event.dataTransfer.files.length){
return event.dataTransfer.files.length;
}
return Array.from(event.dataTransfer.items||[])
.filter(item=>item.kind==='file').length;
};
const position=event=>{
const rect=canvas.getBoundingClientRect();
return{
x:event.clientX-rect.left,
y:event.clientY-rect.top,
};
};
const emit_drag=(event,left)=>{
if(this.webgl_context_lost){
return;
}
const pos=position(event);
this.to_wasm.ToWasmFileDrag({
x:pos.x,
y:pos.y,
modifiers:pack_key_modifier(event),
file_count:file_count(event),
left,
});
this.do_wasm_pump();
};
canvas.addEventListener('dragenter',event=>{
event.preventDefault();
emit_drag(event,false);
});
canvas.addEventListener('dragover',event=>{
event.preventDefault();
if(event.dataTransfer){
event.dataTransfer.dropEffect='copy';
}
emit_drag(event,false);
});
canvas.addEventListener('dragleave',event=>{
event.preventDefault();
emit_drag(event,true);
});
canvas.addEventListener('drop',event=>{
event.preventDefault();
if(this.webgl_context_lost){
return;
}
const pos=position(event);
const modifiers=pack_key_modifier(event);
this.read_virtual_files(
event.dataTransfer.files,
this.virtual_file_max_size,
this.virtual_file_max_total_size,
).then(files=>{
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmFileDrop({
x:pos.x,
y:pos.y,
modifiers,
files,
});
this.do_wasm_pump();
}).catch(error=>{
if(this.webgl_context_lost){
return;
}
this.to_wasm.ToWasmFileDropError({error:""+error});
this.do_wasm_pump();
});
});
}
bind_keyboard(focus=true){
if(this.detect.is_mobile_safari||this.detect.is_android){
return
}
var ta=this.text_area=document.createElement('textarea')
ta.className="cx_webgl_textinput"
ta.setAttribute('autocomplete','off')
ta.setAttribute('autocorrect','off')
ta.setAttribute('autocapitalize','off')
ta.setAttribute('spellcheck','false')

ta.style.left=-100+'px'
ta.style.top=-100+'px'
ta.style.height=1+'px'
ta.style.width=1+'px'
this.ime=new MakepadWebIme(this,ta);
const ime=this.ime;
ta.addEventListener('copy',event=>ime.clipboard(event,false));
ta.addEventListener('cut',event=>ime.clipboard(event,true));
ta.addEventListener('paste',event=>ime.paste(event));
ta.addEventListener('beforeinput',event=>ime.before_input(event));
ta.addEventListener('input',event=>ime.input(event));
ta.addEventListener('select',()=>ime.select());
ta.addEventListener('compositionstart',()=>ime.start());
ta.addEventListener('compositionupdate',event=>ime.update(event.data));
ta.addEventListener('compositionend',event=>ime.end(event.data));
ta.addEventListener('blur',()=>ime.blur());
ta.addEventListener('mousedown',event=>this.handlers.on_mouse_down(event));
ta.addEventListener('mouseup',event=>this.handlers.on_mouse_up(event));
ta.addEventListener('wheel',event=>this.handlers.on_mouse_wheel(event));
ta.addEventListener('contextmenu',event=>this.handlers.on_contextmenu(event));
this.handlers.on_keydown=event=>{
this.resume_audio_from_gesture();
if(event.isComposing||ime.composition||event.keyCode===229)return;
const code=event.keyCode;
const primary=event.ctrlKey||event.metaKey;
if([8,9,13,33,34,35,36,37,38,39,40,46].includes(code)
||(primary&&[65,89,90].includes(code))
||(code===121&&event.shiftKey&&!primary&&!event.altKey)){
event.preventDefault();
}
this.to_wasm.ToWasmKeyDown({key:{
key_code:code,char_code:event.charCode,is_repeat:event.repeat,
time:event.timeStamp/1000,modifiers:pack_key_modifier(event),
}});
this.do_wasm_pump();
ime.flush();
};
this.handlers.on_keyup=event=>{
if(event.isComposing||ime.composition||event.keyCode===229)return;
this.to_wasm.ToWasmKeyUp({key:{
key_code:event.keyCode,char_code:event.charCode,
is_repeat:event.repeat,time:event.timeStamp/1000,
modifiers:pack_key_modifier(event),
}});
this.do_wasm_pump();
};
ta.addEventListener('keydown',event=>this.handlers.on_keydown(event));
ta.addEventListener('keyup',event=>this.handlers.on_keyup(event));
document.body.appendChild(ta);
if(focus)ta.focus();
}
update_text_area_pos(pos){
if(this.text_area&&pos){
this.text_area.style.left=(Math.round(pos.x)-2)+"px";
this.text_area.style.top=(Math.round(pos.y)+4)+"px"
}
}
focus_keyboard_input(){
if(!this.text_area)return;
this.text_area.focus();
}
}
function can_fullscreen(){
return(document.fullscreenEnabled||document.webkitFullscreenEnabled||document.mozFullscreenEnabled)?true:false
}
function is_fullscreen(){
return(document.fullscreenElement||document.webkitFullscreenElement||document.mozFullscreenElement)?true:false
}
function report_browser_issue(kind,data){
try{
if(typeof window.makepad_report_browser_issue==="function"){
window.makepad_report_browser_issue(kind,data);
return;
}
makepad_crash_reporter.report(kind,data);
}catch(_error){
}
}
let web_cursor_map=[
"none",
"default",
"crosshair",
"pointer",
"default",
"move",
"text",
"wait",
"help",
"not-allowed",
"n-resize",
"ne-resize",
"e-resize",
"se-resize",
"s-resize",
"sw-resize",
"w-resize",
"nw-resize",
"ns-resize",
"nesw-resize",
"ew-resize",
"nwse-resize",
"col-resize",
"row-resize",
"grab",
"grabbing",
]
function pack_key_modifier(e){
return(e.shiftKey?1:0)|(e.ctrlKey?2:0)|(e.altKey?4:0)|(e.metaKey?8:0)
}