"""Seal only this task's frozen historical browser evidence, not source/SDK binaries."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile
import time

ROOT = Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
OUT = ROOT / 'ui-browser-history-seal-001'
SCOPES = [('m3', ROOT / 'firefox-validation-m3'),
          ('m4', ROOT / 'firefox-validation-m4'),
          ('m5', ROOT / 'firefox-validation-m5'),
          ('sidebar-fix', ROOT / 'sidebar-geometry-fix-001'),
          ('geometry-probe', ROOT / 'sidebar-geometry-probe-001')]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    os.umask(0o077)
    OUT.mkdir(mode=0o700, exist_ok=False)
    started = time.monotonic()
    files = {}
    for label, root in SCOPES:
        if not root.is_dir():
            raise RuntimeError('Missing required historical scope: ' + label)
        for path in sorted(root.rglob('*')):
            if path.is_symlink():
                raise RuntimeError('Unexpected evidence symlink')
            if not path.is_file() or path.name == 'source.tar':
                continue
            files[label + '/' + path.relative_to(root).as_posix()] = path
    for tag in ['m3', 'm4', 'm5']:
        root = ROOT / ('firefox-source-' + tag) / 'apps/hepta-control-ui/test-results'
        for path in sorted(root.rglob('*')):
            if path.is_symlink():
                raise RuntimeError('Unexpected browser output symlink')
            if path.is_file():
                files[tag + '/original-browser-output/' + path.relative_to(root).as_posix()] = path
    for path in sorted((ROOT / 'ui-browser-history-control-001').rglob('*')):
        if path.is_symlink():
            raise RuntimeError('Unexpected control evidence symlink')
        if path.is_file():
            files['control/' + path.relative_to(ROOT / 'ui-browser-history-control-001').as_posix()] = path
    rows = []
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        rows.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                     'original_path': str(path), 'scope': name.split('/')[0]})
    source_archives = []
    for tag in ['m3', 'm4', 'm5']:
        p = ROOT / ('firefox-validation-' + tag) / 'source.tar'
        h = hashlib.sha256()
        with p.open('rb') as f:
            while block := f.read(1024 * 1024):
                h.update(block)
        source_archives.append({'source_scope': tag, 'native_path': str(p),
                                'bytes': p.stat().st_size, 'sha256': h.hexdigest(),
                                'included': False})
    readme = ('# Historical UI evidence\n\nThese are separate source-specific outcomes, not a combined passing system. '
              'M4 sidebar failed on actual Firefox fractional CSS bounds. The three-file geometry fix has unit red-green; '
              'its34041 intermediate browser build remains UNKNOWN. M5 then executed original Firefox default2 andfixtures3, '
              'and16JavaScript controls successfully. M3/M4/M5 nativeUI and strictClippy were not started by this worker. '
              'Each full three-engine pixel verifier retains its failure for unrun Chromium/WebKit. '
              'Final M6 qualification must execute on its own frozen source; no previous test credit. '
              'Nested command costs are already included in their outer phase windows. Startup UNKNOWN and end-to-end costs '
              'are not silently set to zero. Complete source archives remain at manifest-pinned native paths.\n').encode()
    extras = {'README.md': readme, 'SEAL_CONTROLLER.py': Path(__file__).read_bytes()}
    for name, data in extras.items():
        rows.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                     'original_path': str(Path(__file__)) if name == 'SEAL_CONTROLLER.py' else None,
                     'scope': 'packaging-description'})
    manifest = {'schema': 'hepta.ui.historical-evidence-manifest.v1', 'files': rows,
                'source_archives_retained_separately': source_archives,
                'scope': 'Historical M3/M4/M5 browser builds/tests, actual M4 sidebar red, unit red-green and34041 unknown build. No final-candidate credit; no source archive, SDK checkout, browser installation or compiler cache packed.'}
    extras['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    archive = OUT / 'ui-browser-history-evidence.tar.gz'
    with archive.open('xb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for name in sorted(set(files) | set(extras)):
            data = extras[name] if name in extras else files[name].read_bytes()
            if name in files:
                required = next(x for x in rows if x['path'] == name)
                if len(data) != required['bytes'] or sha(data) != required['sha256']:
                    raise RuntimeError('Historical file changed during sealing')
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o600
            info.mtime = info.uid = info.gid = 0
            tar.addfile(info, io.BytesIO(data))
    data = archive.read_bytes()
    result = {'archive': {'path': str(archive), 'bytes': len(data), 'sha256': sha(data)},
              'member_count': len(files) + len(extras), 'payload_members': len(files) + 2,
              'manifest_sha256': sha(extras['MANIFEST.json']),
              'source_archives': source_archives, 'outer_wall_seconds': time.monotonic() - started,
              'finished_at_utc': datetime.now(timezone.utc).isoformat(),
              'scientific_benefit': False, 'production_qualification': False}
    with (OUT / 'RESULT.json').open('x') as f:
        json.dump(result, f, indent=2, sort_keys=True)
        f.write('\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
