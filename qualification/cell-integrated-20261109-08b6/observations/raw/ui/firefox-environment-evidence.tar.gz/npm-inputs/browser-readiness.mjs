import {firefox} from '@playwright/test';
const browser=await firefox.launch({headless:false});
try{const page=await browser.newPage();const gl=await page.evaluate(()=>{const c=document.createElement('canvas');const g=c.getContext('webgl2');return {webgl2:!!g,renderer:g?.getParameter(g.RENDERER),vendor:g?.getParameter(g.VENDOR)}});console.log(JSON.stringify({version:browser.version(),...gl}));if(!gl.webgl2)process.exitCode=1;}finally{await browser.close();}
