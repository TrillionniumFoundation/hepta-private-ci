"""Complete the original installer's pinned FFmpeg dependency, preserving Firefox."""
import hashlib
from http.server import BaseHTTPRequestHandler,HTTPServer
import importlib.util
import json
import os
from pathlib import Path,PurePosixPath
import re
import sys
import threading
import time
import zipfile

ROOT=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
OUT=ROOT/'firefox-tools-preparation-004'
URL='https://cdn.playwright.dev/dbazure/download/playwright/builds/ffmpeg/1011/ffmpeg-linux.zip'

def digest(stream):
    h=hashlib.sha256()
    while chunk:=stream.read(1024*1024):h.update(chunk)
    return h.hexdigest()

def main():
    spec=importlib.util.spec_from_file_location('transport',ROOT/'recover_firefox_via_curl.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    os.umask(0o077);OUT.mkdir(mode=0o700,exist_ok=False)
    (OUT/'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
    m.E=OUT;m.STEPS=[]
    start=time.monotonic();result={'schema':'hepta.firefox.auxiliary-completion.v1','official_url':URL,'steps':m.STEPS,'started_at_utc':m.now(),'product_tests_run':False,'scope':'Pinned FFmpeg1011 install and full installed Firefox archive-byte binding; no product test or source edits'}
    ok=False
    try:
        browser=m.TOOLS/'browsers/firefox-1543/firefox/firefox'
        before=m.sha(browser.read_bytes())
        if before!='062272ac4d851eade5b75db2dc7c14569d96cb3ca38f949337cdc1b74367e35b':raise RuntimeError('Firefox changed')
        if not m.run('ffmpeg-head',['curl','--head','--location','--silent','--show-error','--proto','=https','--proto-redir','=https','--connect-timeout','20','--max-time','40',URL],timeout=45):raise RuntimeError('Official HEAD failed')
        headers=(OUT/'ffmpeg-head.stdout').read_text()
        lengths=re.findall(r'^content-length:\s*(\d+)\s*$',headers,re.I|re.M)
        if not lengths:raise RuntimeError('No official byte bound')
        size=int(lengths[-1])
        if not 0<size<=16*1024*1024:raise RuntimeError('Auxiliary archive exceeds bound')
        archive=OUT/'ffmpeg-linux.zip'
        if not m.run('ffmpeg-official-get',['curl','--fail','--location','--silent','--show-error','--proto','=https','--proto-redir','=https','--connect-timeout','30','--max-time','180','--max-filesize',str(size),'--output',str(archive),'--write-out','%{http_code} %{size_download}\n',URL],timeout=190):raise RuntimeError('Official GET failed')
        if archive.stat().st_size!=size or (OUT/'ffmpeg-official-get.stdout').read_text().split()[0]!='200':raise RuntimeError('Incomplete official archive')
        result['archive']={'path':str(archive),'bytes':size,'sha256':m.sha(archive.read_bytes())}
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None or sum(i.file_size for i in z.infolist())>64*1024*1024:raise RuntimeError('Invalid bounded ZIP')
            if any(PurePosixPath(i.filename).is_absolute() or '..' in PurePosixPath(i.filename).parts for i in z.infolist()):raise RuntimeError('Unsafe ZIP path')
        requests=[]
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path!='/builds/ffmpeg/1011/ffmpeg-linux.zip':self.send_error(404);return
                self.send_response(200);self.send_header('Content-Length',str(size));self.end_headers()
                data=archive.read_bytes();self.wfile.write(data);requests.append({'path':self.path,'bytes_sent':len(data),'sha256':result['archive']['sha256']})
            def log_message(self,*args):pass
        server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        env=dict(m.ENV);env['PLAYWRIGHT_DOWNLOAD_HOST']='http://127.0.0.1:'+str(server.server_port)
        try:installed=m.run('original-playwright-install',['node',str(m.NPM/'node_modules/playwright/cli.js'),'install','firefox'],env=env,timeout=120)
        finally:server.shutdown();server.server_close();thread.join(timeout=5)
        result['loopback_requests']=requests
        if not installed or not requests:raise RuntimeError('Original full installer still failed')
        if m.sha(browser.read_bytes())!=before:raise RuntimeError('Firefox launcher changed')
        rows=[]
        original=ROOT/'firefox-tools-preparation-003/firefox-ubuntu-24.04.zip'
        with zipfile.ZipFile(original) as z:
            for item in z.infolist():
                if item.is_dir():continue
                actual=m.TOOLS/'browsers/firefox-1543'/item.filename
                if not actual.is_file() or actual.is_symlink() or actual.stat().st_size!=item.file_size:raise RuntimeError('Installed browser file mismatch')
                with z.open(item) as s,actual.open('rb') as a:
                    expected=digest(s);observed=digest(a)
                if observed!=expected:raise RuntimeError('Installed browser bytes differ from official archive')
                rows.append({'path':item.filename,'bytes':item.file_size,'sha256':observed,'actual_mode':oct(actual.stat().st_mode&0o777)})
        m.save(OUT/'FIREFOX_INSTALLED_INVENTORY.json',{'archive_sha256':m.sha(original.read_bytes()),'files':rows,'scope':'Exact ZIP file bytes; installer markers outside firefox/ not source archive entries'})
        result['firefox_files_verified']=len(rows);result['firefox_inventory_sha256']=m.sha((OUT/'FIREFOX_INSTALLED_INVENTORY.json').read_bytes())
        ok=True
    except BaseException as exc:result['failure']=type(exc).__name__+': '+str(exc)
    finally:
        result.update(result='READY' if ok else 'INCOMPLETE',finished_at_utc=m.now(),outer_wall_seconds=time.monotonic()-start)
        m.save(OUT/'RESULT.json',result);print(json.dumps({'result':result['result'],'failure':result.get('failure'),'receipt':str(OUT/'RESULT.json')}),flush=True)
    if not ok:sys.exit(1)

if __name__=='__main__':main()
