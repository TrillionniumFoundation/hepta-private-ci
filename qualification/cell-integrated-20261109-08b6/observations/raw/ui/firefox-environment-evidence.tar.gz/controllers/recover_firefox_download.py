"""One bounded retry of the same official browser package with more transfer time."""
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

ROOT=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
HELPER=ROOT/'prepare_firefox_native.py'
OUT=ROOT/'firefox-tools-preparation-002'

def main():
    spec=importlib.util.spec_from_file_location('original_setup',HELPER)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    OUT.mkdir(mode=0o700,exist_ok=False)
    (OUT/'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
    module.E=OUT;module.STEPS=[]
    module.ENV['PLAYWRIGHT_DOWNLOAD_CONNECTION_TIMEOUT']='120000'
    prior=ROOT/'firefox-tools-preparation-001/RESULT.json'
    old=json.loads(prior.read_text())
    if old['result']!='SETUP_INCOMPLETE':raise RuntimeError('Unexpected prior state')
    package=json.loads((module.NPM/'node_modules/playwright/package.json').read_text())
    if package['version']!='1.63.0':raise RuntimeError('Playwright version changed')
    manifest=module.NPM/'node_modules/playwright-core/browsers.json'
    browser=next(x for x in json.loads(manifest.read_text())['browsers'] if x['name']=='firefox')
    if browser['revision']!='1543' or browser['browserVersion']!='155.0':raise RuntimeError('Browser revision changed')
    result={'schema':'hepta.firefox.bounded-download-recovery.v1','started_at_utc':datetime.now(timezone.utc).isoformat(),'prior_result_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256(HELPER.read_bytes()).hexdigest(),'package':package['version'],'browser':browser,'policy':'Same official URLs/revision and existing CA/proxy configuration; transport connection budget 120000ms, whole install step 900 seconds; product browser timeouts unchanged','steps':module.STEPS,'source_modified':False,'product_tests_run':False}
    start=time.monotonic();ok=False
    try:
        installed=module.run('official-firefox-download',['node',str(module.NPM/'node_modules/playwright/cli.js'),'install','firefox'],timeout=900)
        if installed:
            probe=module.NPM/'browser-readiness.mjs'
            probe.write_text("import {firefox} from '@playwright/test';\nconst browser=await firefox.launch({headless:false});\ntry{const page=await browser.newPage();const gl=await page.evaluate(()=>{const c=document.createElement('canvas');const g=c.getContext('webgl2');return {webgl2:!!g,renderer:g?.getParameter(g.RENDERER),vendor:g?.getParameter(g.VENDOR)}});console.log(JSON.stringify({version:browser.version(),...gl}));if(!gl.webgl2)process.exitCode=1;}finally{await browser.close();}\n")
            ok=module.run('headed-webgl-readiness',['xvfb-run','-a','node',str(probe)],cwd=module.NPM,timeout=90)
        result['browser_executables']=[]
        for path in sorted((module.TOOLS/'browsers').glob('firefox-*/firefox/firefox')):
            result['browser_executables'].append({'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    finally:
        result.update(result='READY' if ok else 'INCOMPLETE',finished_at_utc=datetime.now(timezone.utc).isoformat(),outer_wall_seconds=time.monotonic()-start)
        module.save(OUT/'RESULT.json',result)
        print(json.dumps({'result':result['result'],'receipt':str(OUT/'RESULT.json')}),flush=True)
    if not ok:sys.exit(1)

if __name__=='__main__':main()
