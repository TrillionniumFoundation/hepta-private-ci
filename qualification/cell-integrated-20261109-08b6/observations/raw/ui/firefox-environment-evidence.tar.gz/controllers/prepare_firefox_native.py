"""Prepare isolated browser dependencies; no product tests and no M writes."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
SOURCE=ROOT/'mem1-format-source'
E=ROOT/'firefox-tools-preparation-001'
TOOLS=ROOT/'firefox-tools'
NPM=TOOLS/'npm-root'
H='81da60b349e32d89d0e4c4674a517a66af7e5eee'
ENV=os.environ.copy()
ENV.update(PLAYWRIGHT_BROWSERS_PATH=str(TOOLS/'browsers'),npm_config_cache=str(TOOLS/'npm-cache'),HEPTA_CJK_FONT_CACHE=str(TOOLS/'font-assets'))
ENV['PATH']='/home/qian-qi/.cargo/bin:'+ENV.get('PATH','')
STEPS=[]

def sha(data):return hashlib.sha256(data).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
def run(label,argv,cwd=TOOLS,timeout=300,required=True):
    row={'label':label,'argv':argv,'cwd':str(cwd),'started_at_utc':now(),'required':required}
    save(E/(label+'.intent.json'),row)
    start=time.monotonic()
    with (E/(label+'.stdout')).open('xb') as out,(E/(label+'.stderr')).open('xb') as err:
        try:
            p=subprocess.run(argv,cwd=cwd,env=ENV,stdout=out,stderr=err,timeout=timeout,check=False)
            row.update(exit_code=p.returncode,state='completed')
        except subprocess.TimeoutExpired:row.update(exit_code=None,state='timeout')
    row.update(finished_at_utc=now(),wall_seconds=time.monotonic()-start)
    for kind in ['stdout','stderr']:
        path=E/(label+'.'+kind);data=path.read_bytes();row[kind]={'path':str(path),'bytes':len(data),'sha256':sha(data)}
    save(E/(label+'.result.json'),row);STEPS.append(row);print(json.dumps(row),flush=True)
    return row['exit_code']==0

def main():
    os.umask(0o077);E.mkdir(mode=0o700,exist_ok=False);TOOLS.mkdir(mode=0o700,exist_ok=False);NPM.mkdir()
    (E/'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
    begin=time.monotonic()
    result={'schema':'hepta.firefox.dependency-preparation.v1','scope':'Setup only; no M checkout or product-test execution','source_reference':H,'started_at_utc':now(),'steps':STEPS,'environment_overrides':{k:ENV[k] for k in ['PLAYWRIGHT_BROWSERS_PATH','npm_config_cache','HEPTA_CJK_FONT_CACHE','PATH']},'inputs':[]}
    try:
        for name in ['package.json','package-lock.json']:
            rel='apps/hepta-control-ui/'+name
            data=subprocess.check_output(['git','show',H+':'+rel],cwd=SOURCE,timeout=60)
            (NPM/name).write_bytes(data)
            result['inputs'].append({'repository_path':rel,'head':H,'bytes':len(data),'sha256':sha(data)})
        run('platform',['/usr/bin/python3','-c','import json,platform; print(json.dumps({"platform":platform.platform(),"python":platform.python_version()}))'])
        run('node-version',['node','--version']);run('npm-version',['npm','--version'])
        run('rustup-before',['rustup','toolchain','list'])
        npm_ok=run('npm-ci',['npm','ci','--prefix',str(NPM),'--ignore-scripts','--no-audit','--no-fund'],timeout=600)
        if npm_ok:
            run('playwright-version',['node',str(NPM/'node_modules/playwright/cli.js'),'--version'])
            installed=run('firefox-install',['node',str(NPM/'node_modules/playwright/cli.js'),'install','firefox'],timeout=600)
            if installed:
                probe=NPM/'browser-readiness.mjs'
                probe.write_text("import {firefox} from '@playwright/test';\nconst browser=await firefox.launch({headless:false});\ntry{const page=await browser.newPage();const gl=await page.evaluate(()=>{const c=document.createElement('canvas');const g=c.getContext('webgl2');return {webgl2:!!g,renderer:g?.getParameter(g.RENDERER),vendor:g?.getParameter(g.VENDOR)}});console.log(JSON.stringify({version:browser.version(),...gl}));if(!gl.webgl2)process.exitCode=1;}finally{await browser.close();}\n")
                run('firefox-headed-webgl-readiness',['xvfb-run','-a','node',str(probe)],cwd=NPM,timeout=90)
        run('rust-stable-inputs',['rustup','toolchain','install','1.95.0','--profile','minimal','--component','rustfmt,clippy','--target','wasm32-unknown-unknown'],timeout=600)
        run('rust-nightly-inputs',['rustup','toolchain','install','nightly-2026-10-02','--profile','minimal','--component','rust-src'],timeout=600)
        run('rust-stable-version',['rustup','run','1.95.0','rustc','--version'])
        run('rust-nightly-version',['rustup','run','nightly-2026-10-02','rustc','--version'])
        run('fonts',['/usr/bin/python3',str(SOURCE/'apps/hepta-control-ui/tools/prepare-fonts.py'),'--cache',str(TOOLS/'font-assets')],timeout=240)
        run('ocr-binaries',['/usr/bin/python3','-c','import json,shutil;print(json.dumps({x:shutil.which(x) for x in ["tesseract","xvfb-run","dpkg-query"]}))'])
        run('ocr-python',['/usr/bin/python3','-c','from PIL import Image; import PIL; print(PIL.__version__)'],required=False)
        if shutil.which('tesseract'):
            run('ocr-version',['tesseract','--version'],required=False)
            run('ocr-languages',['tesseract','--list-langs'],required=False)
        result['ready_required_steps']=all(s['exit_code']==0 for s in STEPS if s['required'])
        result['result']='SETUP_STEPS_COMPLETED' if result['ready_required_steps'] else 'SETUP_INCOMPLETE'
        result['browser_executable']=[]
        for manifest in sorted((NPM/'node_modules/playwright-core').glob('browsers.json')):
            result['browser_manifest']={'path':str(manifest),'bytes':manifest.stat().st_size,'sha256':sha(manifest.read_bytes())}
        for firefox in sorted((TOOLS/'browsers').glob('firefox-*/firefox/firefox')):
            result['browser_executable'].append({'path':str(firefox),'bytes':firefox.stat().st_size,'sha256':sha(firefox.read_bytes())})
    except BaseException as exc:
        result['result']='FAILED';result['failure']=type(exc).__name__+': '+str(exc);raise
    finally:
        result.update(finished_at_utc=now(),outer_wall_seconds=time.monotonic()-begin)
        save(E/'RESULT.json',result)
        print(json.dumps({'result':result.get('result'),'receipt':str(E/'RESULT.json')}),flush=True)

if __name__=='__main__':main()
