"""Install the same official Firefox archive using an evidenced curl transport."""
from datetime import datetime,timezone
import hashlib
from http.server import BaseHTTPRequestHandler,HTTPServer
import json
import os
from pathlib import Path,PurePosixPath
import subprocess
import sys
import threading
import time
import zipfile

ROOT=Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
TOOLS=ROOT/'firefox-tools'
E=ROOT/'firefox-tools-preparation-003'
NPM=TOOLS/'npm-root'
URL='https://cdn.playwright.dev/dbazure/download/playwright/builds/firefox/1543/firefox-ubuntu-24.04.zip'
EXPECTED_BYTES=114822786
ENV=os.environ.copy()
ENV['PLAYWRIGHT_BROWSERS_PATH']=str(TOOLS/'browsers')
ENV['npm_config_cache']=str(TOOLS/'npm-cache')
STEPS=[]

def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def now():return datetime.now(timezone.utc).isoformat()
def run(label,argv,env=ENV,timeout=600):
    row={'label':label,'argv':argv,'started_at_utc':now(),'timeout_seconds':timeout}
    save(E/(label+'.intent.json'),row);start=time.monotonic()
    with (E/(label+'.stdout')).open('xb') as out,(E/(label+'.stderr')).open('xb') as err:
        try:
            p=subprocess.run(argv,cwd=NPM,env=env,stdout=out,stderr=err,timeout=timeout,check=False)
            row.update(exit_code=p.returncode,state='completed')
        except subprocess.TimeoutExpired:row.update(exit_code=None,state='timeout')
    row.update(wall_seconds=time.monotonic()-start,finished_at_utc=now())
    for kind in ['stdout','stderr']:
        p=E/(label+'.'+kind);data=p.read_bytes();row[kind]={'path':str(p),'bytes':len(data),'sha256':sha(data)}
    save(E/(label+'.result.json'),row);STEPS.append(row);print(json.dumps(row),flush=True)
    return row['exit_code']==0

def main():
    os.umask(0o077);E.mkdir(mode=0o700,exist_ok=False)
    (E/'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
    begin=time.monotonic()
    result={'schema':'hepta.firefox.same-archive-transport-recovery.v1','started_at_utc':now(),'official_url':URL,'expected_content_length_from_successful_head':EXPECTED_BYTES,'steps':STEPS,'policy':'curl uses inherited CA/proxy and HTTPS-only redirects. Original Playwright 1.63.0 installs exact revision 1543 from a loopback server exposing only the downloaded archive. No product source/test changes.','product_tests_run':False}
    ready=False
    try:
        package=json.loads((NPM/'node_modules/playwright/package.json').read_text())
        if package['version']!='1.63.0':raise RuntimeError('Playwright changed')
        if (TOOLS/'browsers/firefox-1543/firefox/firefox').exists():raise RuntimeError('Browser unexpectedly already installed')
        archive=E/'firefox-ubuntu-24.04.zip'
        ok=run('official-curl-download',['curl','--fail','--location','--silent','--show-error','--proto','=https','--proto-redir','=https','--connect-timeout','30','--max-time','600','--max-filesize',str(EXPECTED_BYTES),'--output',str(archive),'--write-out','%{http_code} %{size_download} %{time_total}\n',URL],timeout=610)
        if archive.exists():result['archive']={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())}
        if not ok or archive.stat().st_size!=EXPECTED_BYTES:raise RuntimeError('Official transfer incomplete')
        download=(E/'official-curl-download.stdout').read_text().split()
        if not download or download[0]!='200':raise RuntimeError('Official GET was not HTTP 200')
        with zipfile.ZipFile(archive) as z:
            info=z.infolist();names=[i.filename for i in info]
            if len(names)!=len(set(names)) or sum(i.file_size for i in info)>2*1024**3:raise RuntimeError('Archive inventory bound failed')
            for name in names:
                p=PurePosixPath(name)
                if p.is_absolute() or '..' in p.parts or not p.parts or p.parts[0]!='firefox':raise RuntimeError('Unexpected archive path')
            if z.testzip() is not None:raise RuntimeError('Archive CRC failed')
            result['zip_inventory']={'entries':len(info),'expanded_bytes':sum(i.file_size for i in info),'crc_passed':True,'safe_path_prefix':'firefox/'}
        requests=[]
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path!='/builds/firefox/1543/firefox-ubuntu-24.04.zip':self.send_error(404);return
                self.send_response(200);self.send_header('Content-Type','application/zip');self.send_header('Content-Length',str(EXPECTED_BYTES));self.end_headers()
                sent=0
                with archive.open('rb') as f:
                    while data:=f.read(65536):self.wfile.write(data);sent+=len(data)
                requests.append({'path':self.path,'bytes_sent':sent,'archive_sha256':result['archive']['sha256']})
            def log_message(self,*args):pass
        server=HTTPServer(('127.0.0.1',0),Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        env=dict(ENV);env['PLAYWRIGHT_FIREFOX_DOWNLOAD_HOST']='http://127.0.0.1:'+str(server.server_port)
        result['installer_override']={'name':'PLAYWRIGHT_FIREFOX_DOWNLOAD_HOST','value':env['PLAYWRIGHT_FIREFOX_DOWNLOAD_HOST'],'scope':'Only this bounded installer child; no persistent config'}
        try:installed=run('original-playwright-install',['node',str(NPM/'node_modules/playwright/cli.js'),'install','firefox'],env=env,timeout=240)
        finally:server.shutdown();server.server_close();thread.join(timeout=5)
        result['loopback_requests']=requests;result['installer_success']=installed
        if not requests or any(r['bytes_sent']!=EXPECTED_BYTES for r in requests):raise RuntimeError('Installer did not consume full exact archive')
        binary=TOOLS/'browsers/firefox-1543/firefox/firefox'
        if not binary.is_file():raise RuntimeError('Original installer produced no Firefox binary')
        result['browser_binary']={'path':str(binary),'bytes':binary.stat().st_size,'sha256':sha(binary.read_bytes())}
        probe=NPM/'browser-readiness.mjs'
        probe.write_text("import {firefox} from '@playwright/test';\nconst browser=await firefox.launch({headless:false});\ntry{const page=await browser.newPage();const gl=await page.evaluate(()=>{const c=document.createElement('canvas');const g=c.getContext('webgl2');return {webgl2:!!g,renderer:g?.getParameter(g.RENDERER),vendor:g?.getParameter(g.VENDOR)}});console.log(JSON.stringify({version:browser.version(),...gl}));if(!gl.webgl2)process.exitCode=1;}finally{await browser.close();}\n")
        ready=run('headed-webgl-readiness',['xvfb-run','-a','node',str(probe)],timeout=90)
        result['result']='FIREFOX_READY' if ready else 'INCOMPLETE'
    except BaseException as exc:
        result['result']='FAILED';result['failure']=type(exc).__name__+': '+str(exc)
    finally:
        result.update(finished_at_utc=now(),outer_wall_seconds=time.monotonic()-begin)
        save(E/'RESULT.json',result)
        print(json.dumps({'result':result['result'],'failure':result.get('failure'),'receipt':str(E/'RESULT.json')}),flush=True)
    if not ready:sys.exit(1)

if __name__=='__main__':main()
