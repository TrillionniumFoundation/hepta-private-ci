import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path('/home/qian-qi/work/cell-continuation-20261109-08b6/firefox-transport-probe-001')
ROOT.mkdir(mode=0o700,exist_ok=False)
url='https://cdn.playwright.dev/dbazure/download/playwright/builds/firefox/1543/firefox-ubuntu-24.04.zip'
argv=['curl','--head','--location','--silent','--show-error','--connect-timeout','20','--max-time','40',url]
request={'argv':argv,'method':'HEAD','scope':'Same official public Firefox revision endpoint; standard inherited TLS and proxy settings unchanged','proxy_variables_present':[k for k in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy'] if k in os.environ]}
(ROOT/'REQUEST.json').write_text(json.dumps(request,indent=2)+'\n')
start=time.monotonic()
p=subprocess.run(argv,capture_output=True,timeout=45,check=False)
for n,b in [('stdout',p.stdout),('stderr',p.stderr)]:
    (ROOT/(n+'.raw')).write_bytes(b)
headers=[]
for s in p.stdout.decode('utf-8',errors='replace').splitlines():
    if s.startswith('HTTP/') or s.lower().startswith(('content-type:','content-length:','accept-ranges:','x-mitmproxy-blocked-reason:')):headers.append(s)
r={'exit_code':p.returncode,'wall_seconds':time.monotonic()-start,'public_headers':headers,'stderr':p.stderr.decode('utf-8',errors='replace'),'raw_pins':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in [('stdout',p.stdout),('stderr',p.stderr)]},'raw_headers_private_only':'Redirect/query headers, if any, are not included in public delivery.'}
(ROOT/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r),flush=True)
