"""Seal only this task's browser setup receipts; browser archives remain native."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
OUT = ROOT / 'firefox-tools-preparation-seal-002'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def main():
    os.umask(0o077)
    OUT.mkdir(mode=0o700, exist_ok=False)
    members = {'CONTROLLER.py': Path(__file__).read_bytes()}
    private = []
    costs = []
    for name in ['firefox-tools-preparation-001', 'firefox-tools-preparation-002',
                 'firefox-transport-probe-001', 'firefox-tools-preparation-003',
                 'firefox-tools-preparation-004']:
        directory = ROOT / name
        result = json.loads((directory / 'RESULT.json').read_text())
        costs.append({'path': str(directory / 'RESULT.json'),
                      'result': result.get('result'),
                      'outer_wall_seconds': result.get('outer_wall_seconds', result.get('wall_seconds')),
                      'started_at_utc': result.get('started_at_utc'),
                      'finished_at_utc': result.get('finished_at_utc')})
        for path in sorted(directory.iterdir()):
            if not path.is_file() or path.is_symlink():
                continue
            if path.suffix == '.zip' or ('head' in path.name and path.suffix == '.stdout') or (name == 'firefox-transport-probe-001' and path.name == 'stdout.raw'):
                private.append(pin(path))
                continue
            if path.stat().st_size > 512000:
                raise RuntimeError('Unexpected large receipt: ' + str(path))
            members[name + '/' + path.name] = path.read_bytes()
    for name in ['prepare_firefox_native.py', 'recover_firefox_download.py',
                 'probe_firefox_transport.py', 'recover_firefox_via_curl.py',
                 'complete_firefox_auxiliary.py']:
        members['controllers/' + name] = (ROOT / name).read_bytes()
    for name in ['package.json', 'package-lock.json', 'browser-readiness.mjs']:
        members['npm-inputs/' + name] = (ROOT / 'firefox-tools/npm-root' / name).read_bytes()
    source = ROOT / 'mem1-format-source'
    all_paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', 'HEAD'], cwd=source).decode().splitlines()
    instructions = [p for p in all_paths if p == 'apps/AGENTS.md' or (p.endswith('/AGENTS.md') and p.startswith('apps/hepta-control-ui/'))]
    for name in instructions:
        members['instructions/' + name] = (source / name).read_bytes()
    summary = {'schema': 'hepta.firefox.setup-seal.v1', 'product_tests_run': False,
               'science_pass': False, 'production_pass': False,
               'attempts': costs, 'private_native_files': private,
               'runtime_root': str(ROOT / 'firefox-tools'),
               'instructions_retained': instructions,
               'packaging_history': {'prior_job': '1a1be49329a-5e21-18', 'state': 'failed', 'exit_code': 1, 'reason': 'Missing retained copy of probe controller; no archive was emitted; all setup inputs unchanged'},
               'cost_scope': 'Each setup outer window is separate; its inner steps must not be added again. Probe may expose only its measured request window. Connector latency is separate.'}
    members['SUMMARY.json'] = (json.dumps(summary, indent=2, sort_keys=True) + '\n').encode()
    members['README.txt'] = b'Browser dependency preparation only. Failed Node downloads and successful curl/original-installer recovery are preserved. No product test or scientific result is claimed. Official browser/FFmpeg ZIPs remain at pinned native paths. Raw redirect HEAD headers remain private; their identities are recorded. Installation uses exact official URLs, inherited CA/proxy, and an ephemeral loopback server exposing only the verified downloaded archive to the unchanged installer.\n'
    manifest = {'files': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())]}
    archive = OUT / 'firefox-environment-evidence.tar.gz'
    with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as tar:
        for name, data in [*sorted(members.items()), ('MANIFEST.json', (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode())]:
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o600
            info.mtime = info.uid = info.gid = 0
            tar.addfile(info, io.BytesIO(data))
    delivery = {'archive': pin(archive), 'members': len(members) + 1, 'summary': summary}
    (OUT / 'DELIVERY.json').write_text(json.dumps(delivery, indent=2, sort_keys=True) + '\n')
    print(json.dumps(delivery), flush=True)


if __name__ == '__main__':
    main()
