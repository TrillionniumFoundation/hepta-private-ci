"""Read one bounded hosted CI snapshot for the already published M6 draft; GET only."""
import datetime,hashlib,json,os,re,subprocess,time
from pathlib import Path
ROOT=Path('/Users/qianqi/work/cell-continuation-20261109-08b6')
OUT=ROOT/'post-M6-hosted-ci-read-001'
GH='/opt/homebrew/bin/gh'
REPO='TrillionniumFoundation/hepta-private-ci'
M6='885dae0f3285267e9e9c49d8b43b0d009779f9e8'
TREE='293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb'
H='81da60b349e32d89d0e4c4674a517a66af7e5eee'
BRANCH='engineering/cell-integrated-20261109-08b6'
def require(v,m):
    if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,o):
    with p.open('x',encoding='utf-8') as f:json.dump(o,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def main():
    os.umask(0o077);OUT.mkdir(mode=0o700,exist_ok=False)
    (OUT/'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
    env=dict(os.environ)
    for k in ('GH_DEBUG','GH_HOST','GIT_TRACE','GIT_TRACE_CURL'):env.pop(k,None)
    env.update(GH_PROMPT_DISABLED='1',GH_PAGER='cat')
    calls=[];start=time.monotonic()
    def api(name,endpoint,jq):
        require(re.fullmatch('[a-zA-Z0-9-]+',name),'Bad label')
        argv=[GH,'api','--hostname','github.com','--method','GET',endpoint,'--jq',jq]
        save(OUT/(name+'.intent.json'),{'method':'GET','argv':argv,'timeout_seconds':60,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        before=time.monotonic();code=None;error=None
        with (OUT/(name+'.stdout')).open('xb') as stdout,(OUT/(name+'.stderr')).open('xb') as stderr:
            try:code=subprocess.run(argv,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=60).returncode
            except (OSError,subprocess.TimeoutExpired) as exc:error=type(exc).__name__+': '+str(exc)
            for f in (stdout,stderr):f.flush();os.fsync(f.fileno())
        row={'name':name,'method':'GET','exit_code':code,'error':error,'wall_seconds':time.monotonic()-before,'state':'RETURNED' if code is not None else 'UNKNOWN'}
        for key in ('stdout','stderr'):
            b=(OUT/(name+'.'+key)).read_bytes();row[key]={'bytes':len(b),'sha256':sha(b)}
        save(OUT/(name+'.result.json'),row);calls.append(row)
        require(code==0,'Read failed: '+name)
        return (OUT/(name+'.stdout')).read_text()
    require(api('viewer','user','.login').strip()=='ProfHepta','Viewer differs')
    pr=json.loads(api('pr','repos/'+REPO+'/pulls/5433','{number,state,draft,author:.user.login,head:{sha:.head.sha,ref:.head.ref,repo:.head.repo.full_name},base:{sha:.base.sha,ref:.base.ref,repo:.base.repo.full_name},merge_commit_sha,created_at,updated_at,mergeable,mergeable_state}'))
    require(pr['number']==5433 and pr['state']=='open' and pr['draft'] is True and pr['author']=='ProfHepta','PR state differs')
    require(pr['head']=={'sha':M6,'ref':BRANCH,'repo':REPO} and pr['base']['sha']==H and pr['base']['repo']==REPO,'PR source/base differs')
    commit=json.loads(api('source-commit','repos/'+REPO+'/git/commits/'+M6,'{sha,tree:.tree.sha,parents:[.parents[].sha]}'))
    require(commit['sha']==M6 and commit['tree']==TREE,'Published source tree differs')
    runs=json.loads(api('runs','repos/'+REPO+'/actions/runs?head_sha='+M6+'&per_page=100','{total_count,workflow_runs:[.workflow_runs[]|{id,name,path,event,status,conclusion,head_branch,head_sha,run_attempt,run_number,created_at,updated_at,html_url,check_suite_id,pull_requests:[.pull_requests[]|{number,head:.head.sha,base:.base.sha}]}]}'))
    require(runs['total_count']<=100 and len(runs['workflow_runs'])<=30,'Run snapshot exceeds bounded scope')
    checks=json.loads(api('checks','repos/'+REPO+'/commits/'+M6+'/check-runs?per_page=100','{total_count,check_runs:[.check_runs[]|{id,name,head_sha,status,conclusion,started_at,completed_at,details_url,check_suite_id:.check_suite.id}]}'))
    require(checks['total_count']<=100,'Check snapshot needs explicit pagination')
    alljobs=[]
    for run in runs['workflow_runs']:
        require(run['head_sha']==M6,'Unexpected run head')
        runid=str(run['id'])
        jobs=json.loads(api('jobs-'+runid,'repos/'+REPO+'/actions/runs/'+runid+'/jobs?per_page=100&filter=latest','{total_count,jobs:[.jobs[]|{id,run_id,run_attempt,head_sha,name,status,conclusion,started_at,completed_at,html_url,runner_name,labels,steps:[.steps[]|{name,status,conclusion,number,started_at,completed_at}]}]}'))
        require(jobs['total_count']<=100,'Job snapshot needs explicit pagination')
        alljobs.append({'run_id':run['id'],'workflow_name':run['name'],'workflow_path':run['path'],'event':run['event'],'status':run['status'],'conclusion':run['conclusion'],'jobs':jobs['jobs']})
    summary={'schema':'hepta.hosted-ci.metadata-snapshot.v1','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':pr,'source_commit':commit,'workflow_runs':runs,'checks':checks,'jobs_by_run':alljobs,'actual_checkout_verified':False,'actual_browser_execution_verified':False,'metadata_not_test_proof':True,'new_github_mutations':0,'wall_seconds':time.monotonic()-start,'calls':calls}
    save(OUT/'SNAPSHOT.json',summary)
    condensed={'root':str(OUT),'source':M6,'tree':TREE,'run_count':len(alljobs),'runs':[{'run':r['run_id'],'workflow':r['workflow_path'],'status':r['status'],'conclusion':r['conclusion'],'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion']} for j in r['jobs']]} for r in alljobs],'wall_seconds':summary['wall_seconds']}
    print(json.dumps(condensed),flush=True)
if __name__=='__main__':main()
