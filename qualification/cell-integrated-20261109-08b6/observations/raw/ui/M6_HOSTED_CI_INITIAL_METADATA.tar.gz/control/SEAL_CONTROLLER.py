import datetime,gzip,hashlib,io,json,os,tarfile,time
from pathlib import Path
ROOT=Path('/Users/qianqi/work/cell-continuation-20261109-08b6')
SOURCE=ROOT/'post-M6-hosted-ci-read-001'
OUT=ROOT/'post-M6-hosted-ci-seal-001'
def require(v,m):
    if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def encoded(o):return (json.dumps(o,sort_keys=True,indent=2)+'\n').encode()
def main():
    os.umask(0o077);OUT.mkdir(mode=0o700,exist_ok=False)
    snapshot=json.loads((SOURCE/'SNAPSHOT.json').read_text())
    require(snapshot['pr']['number']==5433 and snapshot['source_commit']['sha']=='885dae0f3285267e9e9c49d8b43b0d009779f9e8' and snapshot['source_commit']['tree']=='293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb','Source differs')
    require(snapshot['actual_checkout_verified'] is False and snapshot['actual_browser_execution_verified'] is False,'Metadata promoted into test proof')
    connector=json.loads((ROOT/'post-M6-hosted-ci-read-001.CONNECTOR.json').read_text())
    state=json.loads(connector['terminal_response']['content'][0]['text'])
    require(state['job_id']=='1a1bebae2c9-5e21-246' and state['state']=='succeeded' and state['exit_code']==0 and state['output_complete'] is True,'Connector final state differs')
    files={}
    allowed={'CONTROLLER.py','SNAPSHOT.json'}
    for call in snapshot['calls']:
        require(call['method']=='GET' and call['exit_code']==0,'Incomplete metadata command')
        name=call['name']
        allowed.update(name+'.'+suffix for suffix in ('intent.json','result.json','stdout','stderr'))
        intent=json.loads((SOURCE/(name+'.intent.json')).read_text())
        require(intent['method']=='GET' and intent['argv'][4:6]==['--method','GET'],'Non-GET command')
        for stream in ('stdout','stderr'):
            value=(SOURCE/(name+'.'+stream)).read_bytes()
            require((len(value),sha(value))==(call[stream]['bytes'],call[stream]['sha256']),'Command output changed')
    require({p.name for p in SOURCE.iterdir()}==allowed,'Unexpected metadata payload')
    for name in sorted(allowed):
        path=SOURCE/name
        require(path.is_file() and not path.is_symlink(),'Nonregular input')
        files['snapshot001/'+name]=path.read_bytes()
    require(files['snapshot001/viewer.stdout'].strip()==b'ProfHepta','Reduced identity differs')
    files['control/CONNECTOR.json']=encoded(connector)
    files['control/SEAL_CONTROLLER.py']=Path(__file__).read_bytes()
    jobs=[j for r in snapshot['jobs_by_run'] for j in r['jobs']]
    counts={}
    for job in jobs:
        label=job['status']+':'+str(job['conclusion']);counts[label]=counts.get(label,0)+1
    selected=[r for r in snapshot['jobs_by_run'] if r['run_id'] in (42565769665,42565757710)]
    receipt={'schema':'hepta.M6.hosted-CI.initial-metadata-receipt.v1','observed_at_utc':snapshot['observed_at_utc'],'read_window_is_atomic':False,'pr':5433,'head':snapshot['source_commit']['sha'],'tree':snapshot['source_commit']['tree'],'workflow_runs':len(snapshot['jobs_by_run']),'command_calls':len(snapshot['calls']),'job_status_counts':counts,'selected_UI_and_Cell':selected,'actual_checkout_verified':False,'actual_browser_execution_verified':False,'no_overall_ci_pass_claim':True,'science':'HOLD','production_adopted':False,'wall_seconds':snapshot['wall_seconds'],'cost_scope':'20 sequential read-only command windows; no hosted runner execution cost inferred','connector_job':'1a1bebae2c9-5e21-246','source_snapshot_sha256':sha(files['snapshot001/SNAPSHOT.json']),'full_user_profile_collected':False,'host_hardware_inventory_collected':False,'source_changes':0,'github_mutations':0}
    files['RECEIPT.json']=encoded(receipt)
    files['README.zh-CN.md']=(ROOT/'post-M6-hosted-ci-read-001.README.zh-CN.md').read_bytes()
    manifest={'files':[{'path':name,'bytes':len(data),'sha256':sha(data),'scope':'selected_GH_metadata_command_outputs' if name.startswith('snapshot001/') else 'read_only_CI_observation_control'} for name,data in sorted(files.items())]}
    mb=encoded(manifest);archive=OUT/'M6_HOSTED_CI_INITIAL_METADATA.tar.gz'
    with archive.open('xb') as output:
        with gzip.GzipFile(filename='',fileobj=output,mode='wb',mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for name,data in [*sorted(files.items()),('MANIFEST.json',mb)]:
                    item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o600;item.mtime=item.uid=item.gid=0
                    tar.addfile(item,io.BytesIO(data))
        output.flush();os.fsync(output.fileno())
    with tarfile.open(archive,'r:gz') as check:
        members=check.getmembers();require(len(members)==len(files)+1 and len({m.name for m in members})==len(members),'Member count differs')
        for m in members:require(check.extractfile(m).read()==(mb if m.name=='MANIFEST.json' else files[m.name]),'Archive byte mismatch')
    for name,value in [('RECEIPT.json',files['RECEIPT.json']),('MANIFEST.json',mb),('README.zh-CN.md',files['README.zh-CN.md'])]:
        (OUT/name).write_bytes(value)
    delivery={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(files)+1,'manifest_sha256':sha(mb),'receipt_sha256':sha(files['RECEIPT.json']),'observed_at_utc':snapshot['observed_at_utc'],'selected_runs_pending':True,'actual_checkout_verified':False,'actual_browser_execution_verified':False}
    (OUT/'DELIVERY.json').write_bytes(encoded(delivery));print(json.dumps(delivery),flush=True)
if __name__=='__main__':main()
