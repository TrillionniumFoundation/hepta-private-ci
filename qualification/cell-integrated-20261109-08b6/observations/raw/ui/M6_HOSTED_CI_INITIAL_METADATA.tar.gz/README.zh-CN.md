# M6 新 PR 的首次托管 CI 只读快照

目标是已发布的 draft PR #5433，source M6 `885dae0f3285267e9e9c49d8b43b0d009779f9e8`，tree `293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb`，base H `81da60b349e32d89d0e4c4674a517a66af7e5eee`。精确 PR 与 commit/tree 已通过原 Mac 的 ProfHepta gh 身份 GET 回读。

本次 20 个顺序 GET 命令共 34.731568958000004 秒，观察时间及每条调用开始时间见 RECEIPT/SNAPSHOT 和各 intent。它不是原子时间点快照，也不包含后续状态；不同 jobs 的状态来自各自读回时刻。15 个工作流已经出现。UI run 42565769665 的 source-head / base-merge 两条 browser lane 以及两条 native-presentation lane 均 queued；Cell run 42565757710 的三项作业均 queued。尚未取得实际执行日志，实际 checkout/三浏览器执行全部保持未验证。不能把工作流 head、job metadata success、PRED 回归 success 或 skipped 解释成科学收益、完整 CI 通过或生产采用。

GH 只读原命令输出按原 bytes 保留。元数据读取使用显式 --jq 精简字段，不冒充完整 HTTP 响应；只有 viewer login 被读取，没有完整 /user、token/env 导出或主机/runner 硬件清单。没有 dispatch、rerun、取消、写入或新测试。原 source-head 和 base-merge 必须后续分别核实际 checkout；本地 Firefox 两套不能代替托管 Chromium/Firefox/WebKit。

包内 manifest 覆盖所有原始精简输出、intent、result、控制器和 h 权威 succeeded/exit0 回执。取得 metadata 的控制进程成功，不代表 runner 执行成功。root evidence 冻结前可再作一次同 UI/Cell run 的只读观察；若仍 queued，应如实记录，不能预写未来通过。
