"""Sequential fixed-M6 validation under one shared h process-group budget."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
OUT = ROOT / 'ui-m6-worker-001'
EXPECTED = {'commit': '885dae0f3285267e9e9c49d8b43b0d009779f9e8',
            'tree': '293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb'}


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n'); f.flush(); os.fsync(f.fileno())


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    os.umask(0o077)
    OUT.mkdir(mode=0o700, exist_ok=False)
    browser = ROOT / 'run_firefox_candidate_m6.py'
    native = ROOT / 'run_native_ui_m6.py'
    profile = ROOT / 'firefox-M6-PROFILE.json'
    config = json.loads(profile.read_text())
    if config['source'] != EXPECTED or config['combined_h_budget_seconds'] != 1200:
        raise RuntimeError('Wrong M6 source/runtime configuration')
    (OUT / 'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
    stages = [(phase, ['/usr/bin/python3', '-B', str(browser), str(profile), phase])
              for phase in ['prepare', 'default-build', 'default-test', 'fixtures-build', 'fixtures-test']]
    stages += [(phase, ['/usr/bin/python3', '-B', str(native), phase])
               for phase in ['native-ui', 'native-clippy']]
    result = {'schema': 'hepta.m6.ui-sequential-worker.v1', 'source': EXPECTED,
              'started_at_utc': now(), 'shared_h_budget_seconds': 1200,
              'budget_scope': 'All stages share the same h process-group deadline; no fresh per-stage budget',
              'profile': pin(profile), 'browser_controller': pin(browser), 'native_controller': pin(native),
              'stages': [], 'science_pass': False, 'production_pass': False}
    started = time.monotonic()
    ok = False
    try:
        for phase, argv in stages:
            row = {'phase': phase, 'argv': argv, 'cwd': str(ROOT), 'started_at_utc': now()}
            save(OUT / (phase + '.intent.json'), row)
            begin = time.monotonic()
            with (OUT / (phase + '.stdout')).open('xb') as stdout, (OUT / (phase + '.stderr')).open('xb') as stderr:
                child = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
                while child.poll() is None:
                    try:
                        child.wait(timeout=30)
                    except subprocess.TimeoutExpired:
                        print(json.dumps({'running': phase, 'stage_wall_seconds': time.monotonic() - begin}), flush=True)
            row.update(exit_code=child.returncode, wall_seconds=time.monotonic() - begin,
                       finished_at_utc=now(), stdout=pin(OUT / (phase + '.stdout')), stderr=pin(OUT / (phase + '.stderr')))
            save(OUT / (phase + '.result.json'), row)
            result['stages'].append(row)
            print(json.dumps({'completed': phase, 'exit_code': child.returncode, 'wall_seconds': row['wall_seconds']}), flush=True)
            if child.returncode:
                raise RuntimeError('Stage failed: ' + phase)
        ok = True
    except BaseException as exc:
        result['failure'] = type(exc).__name__ + ': ' + str(exc)
    finally:
        result.update(scoped_worker_passed=ok, outer_wall_seconds=time.monotonic() - started,
                      finished_at_utc=now(), not_started=[x[0] for x in stages[len(result['stages']):]])
        save(OUT / 'RESULT.json', result)
        print(json.dumps({'passed': ok, 'receipt': str(OUT / 'RESULT.json'), 'failure': result.get('failure')}), flush=True)
    if not ok:
        sys.exit(1)


if __name__ == '__main__':
    main()
