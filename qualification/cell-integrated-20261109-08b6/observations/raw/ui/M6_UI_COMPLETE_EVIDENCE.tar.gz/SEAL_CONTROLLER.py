"""Seal the actual M6 UI execution and review the bounded publication payloads."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import tarfile
import time
import zipfile

ROOT = Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
SOURCE = ROOT / 'firefox-source-m6'
EVIDENCE = ROOT / 'firefox-validation-m6'
OUT = ROOT / 'ui-m6-evidence-seal-001'
EXPECTED = {'commit': '885dae0f3285267e9e9c49d8b43b0d009779f9e8',
            'tree': '293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb'}
HISTORY = ROOT / 'ui-browser-history-seal-001/ui-browser-history-evidence.tar.gz'
HISTORY_SHA = 'e647505eb41b752096a13b3af9bec85f913c449f39f4a2e2132c11b9f732bbc6'
PHASES = ['prepare', 'default-build', 'default-test', 'fixtures-build', 'fixtures-test', 'native-ui', 'native-clippy']
SECRET = re.compile(rb'\b(?:gh[opsu]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[0-9A-Z]{16})\b|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|Bearer [A-Za-z0-9._~+/=-]{24,}')
FORBIDDEN = [b'api.github.com/user', b'targeted-ci-read-001', b'private-staging', b'BEGIN OPENSSH PRIVATE KEY']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while block := f.read(1024 * 1024):
            h.update(block)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')


def scan(name, data, counts, depth=0):
    counts['files'] += 1
    if SECRET.search(data):
        raise RuntimeError('Credential-shaped material requires private review: ' + name)
    if any(value in data for value in FORBIDDEN):
        raise RuntimeError('Previously excluded source appeared: ' + name)
    if data.startswith(b'PK\x03\x04'):
        if depth:
            raise RuntimeError('Unexpected nested ZIP')
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            if sum(x.file_size for x in z.infolist()) > 128 * 1024 * 1024:
                raise RuntimeError('ZIP audit bound exceeded')
            for item in z.infolist():
                if not item.is_dir():
                    scan(name + '!' + item.filename, z.read(item), counts, depth + 1)
                    counts['zip_members'] += 1


def main():
    os.umask(0o077)
    OUT.mkdir(mode=0o700, exist_ok=False)
    begin = time.monotonic()
    import importlib.util
    helper = ROOT / 'run_firefox_candidate_m6.py'
    if pin(helper)['sha256'] != '6fe725b132e16734b998cb16d4fbf3fb8fca6784676d868c150880245ec623e2':
        raise RuntimeError('Shared immutable controller changed')
    spec = importlib.util.spec_from_file_location('shared', helper)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    before = module.source_state(SOURCE, EXPECTED)
    receipts = {phase: json.loads((EVIDENCE / phase / 'RESULT.json').read_text()) for phase in PHASES}
    if any(r['source'] != EXPECTED or r.get('scoped_gate_passed') is not True for r in receipts.values()):
        raise RuntimeError('Incomplete exact-M6 qualification')
    worker = json.loads((ROOT / 'ui-m6-worker-001/RESULT.json').read_text())
    if worker['source'] != EXPECTED or worker.get('scoped_worker_passed') is not True:
        raise RuntimeError('Common worker did not complete')
    integrity_path = EVIDENCE / 'archive-integrity.json'
    integrity = json.loads(integrity_path.read_text())
    if not integrity['integrity_verified'] or integrity['tested_source']['commit'] != EXPECTED['commit'] or integrity['tested_source']['tree'] != EXPECTED['tree']:
        raise RuntimeError('Complete source archive does not bind M6')
    archive = pin(EVIDENCE / 'source.tar')
    if any(archive[k] != receipts['prepare']['source_archive'][k] for k in ['bytes', 'sha256']):
        raise RuntimeError('Complete source archive changed')
    archive_summary = {'source': EXPECTED, 'archive': archive, 'integrity': pin(integrity_path),
        'integrity_verified': True, 'file_count': len(integrity['files']),
        'regular_files': sum(x['git_mode'] != '120000' for x in integrity['files']),
        'symlinks': sum(x['git_mode'] == '120000' for x in integrity['files']),
        'inventory_sha256': integrity['inventory_sha256'],
        'scope': 'Complete tracked bytes, Git modes and symlink targets. Integrity only; no execution-authenticity or production inference.'}
    save(OUT / 'SOURCE_ARCHIVE.json', archive_summary)
    packages = {}
    for scope in ['default', 'fixtures']:
        dist = SOURCE / 'apps/hepta-control-ui' / ('dist' if scope == 'default' else 'dist-robrix-fixtures')
        packages[scope] = module.package_state(dist, receipts[scope + '-build']['build_manifest'])
    # The full historical pack was selected only from this task's UI scopes.
    if pin(HISTORY)['sha256'] != HISTORY_SHA:
        raise RuntimeError('Full historical archive changed')
    history_audit = {'files': 0, 'zip_members': 0}
    with tarfile.open(HISTORY, 'r:gz') as tar:
        manifest_raw = tar.extractfile('MANIFEST.json').read()
        original = json.loads(manifest_raw)
        rows = {x['path']: x for x in original['files']}
        if set(tar.getnames()) != set(rows) | {'MANIFEST.json'}:
            raise RuntimeError('Historical manifest mismatch')
        for item in tar.getmembers():
            if not item.isfile() or item.name.split('/')[0] not in {'m3', 'm4', 'm5', 'sidebar-fix', 'geometry-probe', 'control', 'README.md', 'SEAL_CONTROLLER.py', 'MANIFEST.json'}:
                raise RuntimeError('Unexpected historical source scope')
            data = tar.extractfile(item).read()
            if item.name != 'MANIFEST.json' and (len(data) != rows[item.name]['bytes'] or sha(data) != rows[item.name]['sha256']):
                raise RuntimeError('Historical original bytes changed')
            scan(item.name, data, history_audit)
    contents = {}
    for label, root in [('evidence', EVIDENCE), ('worker', ROOT / 'ui-m6-worker-001'),
                        ('control', ROOT / 'ui-m6-delivery-control-001')]:
        for path in sorted(root.rglob('*')):
            if path.is_symlink():
                raise RuntimeError('Unexpected evidence symlink')
            if path.is_file() and path.name != 'source.tar':
                contents[label + '/' + path.relative_to(root).as_posix()] = path.read_bytes()
    browser_outputs = SOURCE / 'apps/hepta-control-ui/test-results'
    for path in sorted(browser_outputs.rglob('*')):
        if path.is_symlink():
            raise RuntimeError('Unexpected browser output symlink')
        if path.is_file():
            contents['original-browser-output/' + path.relative_to(browser_outputs).as_posix()] = path.read_bytes()
    audit = {'files': 0, 'zip_members': 0}
    for name, data in contents.items():
        scan(name, data, audit)
    publication = {'schema': 'hepta.ui.payload-provenance-review.v1',
        'history': {**pin(HISTORY), 'manifest_sha256': sha(manifest_raw), 'checked_payloads': history_audit},
        'final_checked_payloads': audit,
        'source_scope': 'Only this task UI phases, original localhost fixture outputs, controllers and exact process requests/receipts. No targeted CI or general host inventory imported.',
        'credential_shape_matches': 0, 'forbidden_source_matches': 0,
        'bounded_archive_contents_verified': True,
        'browser_runtime_metadata_present': 'DPR, visualViewport, userAgent emulation and browser-reported WebGL renderer; standard compiler/OCR capability/version lines. These are runtime observations, not a private machine hardware inventory.',
        'no_full_github_user_response_or_unsafe_targeted_ci_pack': True,
        'review_limit': 'Bounded provenance plus credential-pattern inspection, not a universal proof that arbitrary data could never contain a secret.'}
    save(OUT / 'PUBLICATION_PAYLOAD_REVIEW.json', publication)
    costs = {'source': EXPECTED, 'measured_worker_outer_wall_seconds': worker['outer_wall_seconds'],
        'phase_outer_seconds': {phase: receipts[phase]['outer_wall_seconds'] for phase in PHASES},
        'aggregation': 'Worker outer includes all phase and nested command windows; do not add those again. Warm compiler-cache run. No previous source test credit.',
        'control_plane_model_time_included': False, 'end_to_end_cost_complete': False,
        'historical_unknown': 'Intermediate34041 build remains UNKNOWN and is never charged as zero; original history is separately retained.'}
    save(OUT / 'COSTS.json', costs)
    source_after = module.source_state(SOURCE, EXPECTED)
    summary = {'schema': 'hepta.m6.ui-final-qualification.v1', 'source': EXPECTED,
        'source_before_seal': before, 'source_after_seal': source_after,
        'groups': {'javascript_controls': {'passed': 16, 'skipped': 0},
            'firefox_default': receipts['default-test']['playwright_stats'],
            'firefox_fixtures': receipts['fixtures-test']['playwright_stats'],
            'native_ui_rust_1_96': {'passed': 33, 'skipped': 0, 'retry_lines': receipts['native-ui']['retry_lines']},
            'strict_native_clippy_rust_1_95': {'exit_code': 0}},
        'firefox_pixels': {scope: {k: v for k, v in receipts[scope + '-test']['firefox_pixels'].items() if k != 'rows'} for scope in ['default', 'fixtures']},
        'verified_packages_after_all_phases': packages, 'source_archive': archive_summary,
        'phase_receipts': {phase: pin(EVIDENCE / phase / 'RESULT.json') for phase in PHASES},
        'worker_receipt': pin(ROOT / 'ui-m6-worker-001/RESULT.json'), 'costs': costs,
        'scope_limit': 'Actual Firefox and specified native scopes only. Full local three-engine verifier remains false for unrun Chromium/WebKit; hosted complete UI CI is independent. No production/scientific qualification.',
        'scientific_benefit': False, 'production_qualification': False, 'joint_learning_configuration': None}
    save(OUT / 'FINAL_VALIDATION.json', summary)
    readme = '# M6 共同 UI 验证\n\n精确受测源码为885dae0f3285267e9e9c49d8b43b0d009779f9e8，tree293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb。\n\n本次独立实际执行16项JavaScript控制、Firefox默认2项及fixtures3项、Rust1.96原生UI33项和Rust1.95严格Clippy。Firefox两组零跳过、零意外失败、零flaky；分别20/20截图与46/46检查、26/26截图与146/146检查。Native33零跳过、零重试，Clippy原all-targets及ui,native-host,native-presentation范围exit0。\n\n七阶段均绑定同一M6，源码前后clean；原生字体在执行期间仅有两件明确记录的untracked资源，按manifest哈希清理后恢复clean。Makepad独立checkout的完整tracked物理字节清单前后相同，Git状态仅既有.cargo-ok；原29件非Rust换行物化没有被掩掉。WASM使用原构建器生成的受检补丁overlay，原生不应用该WASMoverlay。\n\n仅复用已完成M5的两处独占编译缓存；仍实际执行M6原构建、生成新overlay/dist/manifest并完整核对构建到服务之间的文件集合和逐文件SHA。没有借M5的测试成绩，不能称cold。Node依赖按同一package-lock安装并检查锁字节；不声称对整个node_modules进行完整物理字节前后盘点。\n\n完整source.tar独立保留native路径及SHA，原脚本核对全部tracked字节、Git mode与symlink；本包包含完整校验inventory而不重复210MB源码tar。源码归档只证明完整性，不建立测试执行真实性或生产通过。\n\n完整三engine像素检查器的原失败结果保留：Chromium/WebKit未在本地运行。工作流ui-product-foundation.yml在同仓库PR路径匹配时运行source-head/base-merge完整三engine；真实托管结果必须发布后另外读取。\n\n成本以worker外层窗口为总观测值，已包含各阶段和命令，不能重复相加；启动/控制面与模型费用未完整计量。M3/M4/M5与34041UNKNOWN均单独保留，不能合并成M6分母。Scientific、production均false，joint_learning_configuration为null。\n'
    (OUT / 'README.zh-CN.md').write_text(readme)
    for path in sorted(OUT.iterdir()):
        if path.is_file():
            contents['summary/' + path.name] = path.read_bytes()
    contents['SEAL_CONTROLLER.py'] = Path(__file__).read_bytes()
    manifest = {'schema': 'hepta.m6.ui-evidence-manifest.v1', 'source': EXPECTED,
        'files': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(contents.items())],
        'source_archive_retained_separately': archive}
    contents['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    artifact = OUT / 'M6_UI_COMPLETE_EVIDENCE.tar.gz'
    with artifact.open('xb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for name, data in sorted(contents.items()):
            item = tarfile.TarInfo(name); item.size = len(data); item.mode = 0o600
            item.mtime = item.uid = item.gid = 0
            tar.addfile(item, io.BytesIO(data))
    result = {'source': EXPECTED, 'archive': pin(artifact), 'member_count': len(contents),
        'manifest_sha256': sha(contents['MANIFEST.json']), 'source_archive': archive_summary,
        'summary_files': {p.name: pin(p) for p in OUT.iterdir() if p.is_file() and p != artifact},
        'full_history': pin(HISTORY), 'outer_sealing_wall_seconds': time.monotonic() - begin,
        'finished_at_utc': datetime.now(timezone.utc).isoformat()}
    save(OUT / 'DELIVERY.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
