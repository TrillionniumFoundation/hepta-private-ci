"""Run original Firefox build/test phases on one separately frozen worktree."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
TOOLS = ROOT / 'firefox-tools'
PHASES = {'prepare', 'default-build', 'default-test', 'fixtures-build', 'fixtures-test'}


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def pin(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def git(source, *args):
    return subprocess.check_output(['git', *args], cwd=source, timeout=90)


def source_state(source, expected):
    head = git(source, 'rev-parse', 'HEAD').decode().strip()
    tree = git(source, 'rev-parse', 'HEAD^{tree}').decode().strip()
    status = git(source, 'status', '--porcelain=v1', '--untracked-files=all').decode()
    row = {'head': head, 'tree': tree, 'status': status, 'observed_at_utc': now()}
    if head != expected['commit'] or tree != expected['tree'] or status:
        raise RuntimeError('Frozen source identity/status changed: ' + json.dumps(row))
    return row


def physical_inventory(source, scope=None):
    args = ['ls-tree', '-r', '-z', 'HEAD']
    if scope:
        args += ['--', scope]
    rows = []
    for entry in git(source, *args).split(b'\0'):
        if not entry:
            continue
        header, name = entry.split(b'\t', 1)
        mode, kind, blob = header.decode().split()
        path = source / os.fsdecode(name)
        if kind != 'blob':
            raise RuntimeError('Unexpected source kind')
        data = os.fsencode(os.readlink(path)) if mode == '120000' else path.read_bytes()
        rows.append({'path': os.fsdecode(name), 'git_mode': mode, 'git_blob': blob,
                     'actual_bytes': len(data), 'actual_sha256': sha(data)})
    return rows


def package_state(dist, manifest_pin):
    observed = pin(dist / 'build-manifest.json')
    if any(observed[k] != manifest_pin[k] for k in ['bytes', 'sha256']):
        raise RuntimeError('Serving manifest differs from successful build')
    manifest = json.loads((dist / 'build-manifest.json').read_text())
    expected = manifest['files']
    actual = set()
    for path in dist.rglob('*'):
        if path.is_symlink():
            raise RuntimeError('Unexpected packaged symlink')
        if path.is_file():
            actual.add(path.relative_to(dist).as_posix())
    if actual != set(expected) | {'build-manifest.json'}:
        raise RuntimeError('Serving resource set differs from successful build')
    for name, required in expected.items():
        logical = PurePosixPath(name)
        if logical.is_absolute() or '..' in logical.parts or str(logical) != name:
            raise RuntimeError('Noncanonical packaged resource')
        observed_file = pin(dist / name)
        if any(observed_file[k] != required[k] for k in ['bytes', 'sha256']):
            raise RuntimeError('Serving resource changed: ' + name)
    return {'manifest': observed, 'files_verified': len(expected),
            'inventory_sha256': sha(json.dumps(expected, sort_keys=True).encode())}


def main():
    profile_path, phase = Path(sys.argv[1]), sys.argv[2]
    if phase not in PHASES:
        raise ValueError('Unknown phase')
    profile = json.loads(profile_path.read_text())
    if sha(Path(__file__).read_bytes()) != profile['controller_sha256']:
        raise RuntimeError('Controller differs from frozen runtime profile')
    expected = profile['source']
    if not all(re.fullmatch('[0-9a-f]{40}', expected[k]) for k in ['commit', 'tree']):
        raise ValueError('Invalid frozen source identity')
    tag = profile['tag']
    if not re.fullmatch('m[0-9]+', tag):
        raise ValueError('Invalid task scope')
    source = ROOT / ('firefox-source-' + tag)
    evidence = ROOT / ('firefox-validation-' + tag)
    ui = source / 'apps/hepta-control-ui'
    os.umask(0o077)
    if phase == 'prepare':
        evidence.mkdir(mode=0o700, exist_ok=False)
        (evidence / 'FROZEN_PROFILE.json').write_bytes(profile_path.read_bytes())
    elif (evidence / 'FROZEN_PROFILE.json').read_bytes() != profile_path.read_bytes():
        raise RuntimeError('Profile changed after preparation')
    out = evidence / phase
    out.mkdir(mode=0o700, exist_ok=False)
    (out / 'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
    env = os.environ.copy()
    overrides = dict(profile['environment'])
    overrides['SOURCE_SHA'] = expected['commit']
    overrides['PATH'] = '/home/qian-qi/.cargo/bin:' + env.get('PATH', '')
    for key in ['HEPTA_ROBRIX_FIXTURES', 'HEPTA_ROBRIX_DIAGNOSTICS', 'CARGO_TARGET_DIR']:
        env.pop(key, None)
    if phase.startswith('fixtures'):
        overrides['HEPTA_ROBRIX_FIXTURES'] = '1'
    env.update(overrides)
    steps = []
    started = time.monotonic()
    result = {'schema': 'hepta.firefox.candidate-phase.v1', 'source': expected,
              'phase': phase, 'profile': pin(profile_path), 'started_at_utc': now(),
              'environment_overrides': overrides, 'steps': steps,
              'science_pass': False, 'production_pass': False}

    def run(label, argv, cwd=ui, required=True):
        row = {'label': label, 'argv': [str(v) for v in argv], 'cwd': str(cwd),
               'started_at_utc': now(), 'required': required}
        save(out / (label + '.intent.json'), row)
        begin = time.monotonic()
        with (out / (label + '.stdout')).open('xb') as stdout, (out / (label + '.stderr')).open('xb') as stderr:
            process = subprocess.Popen(row['argv'], cwd=cwd, env=env, stdout=stdout, stderr=stderr)
            # The h job supplies the explicit process-group deadline; do not
            # kill a Rust compiler because it is waiting for a Cargo lock.
            while process.poll() is None:
                try:
                    process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    print(json.dumps({'running': label, 'wall_seconds': time.monotonic() - begin}), flush=True)
            row['exit_code'] = process.returncode
        row.update(finished_at_utc=now(), wall_seconds=time.monotonic() - begin,
                   stdout=pin(out / (label + '.stdout')), stderr=pin(out / (label + '.stderr')))
        save(out / (label + '.result.json'), row)
        steps.append(row)
        print(json.dumps({'completed': label, 'exit_code': row['exit_code'], 'wall_seconds': row['wall_seconds']}), flush=True)
        if required and row['exit_code']:
            raise RuntimeError(label + ' failed with exit ' + str(row['exit_code']))
        return row

    ok = False
    gate_passed = True
    try:
        if phase == 'prepare':
            run('worktree-add', ['git', 'worktree', 'add', '--detach', source, expected['commit']], ROOT / 'integration-source')
        result['source_before'] = source_state(source, expected)
        before = physical_inventory(source, 'apps/hepta-control-ui')
        save(out / 'UI_SOURCE_BEFORE.json', before)
        result['ui_source_before'] = pin(out / 'UI_SOURCE_BEFORE.json')
        if phase == 'prepare':
            for name in ['package.json', 'package-lock.json']:
                if (ui / name).read_bytes() != (TOOLS / 'npm-root' / name).read_bytes():
                    raise RuntimeError('Prepared npm input no longer equals frozen candidate: ' + name)
            (ui / 'node_modules').symlink_to(TOOLS / 'npm-root/node_modules', target_is_directory=True)
            result['node_modules'] = {'path': str(ui / 'node_modules'), 'target': str(TOOLS / 'npm-root/node_modules'), 'role': 'Exact locked prepared dependencies; ignored runtime link'}
            reuse = profile.get('compiler_cache_reuse')
            if reuse:
                receipt = Path(reuse['completed_browser_receipt']['path'])
                observed = pin(receipt)
                if any(observed[k] != reuse['completed_browser_receipt'][k] for k in ['bytes', 'sha256']):
                    raise RuntimeError('Prior cache owner completion receipt changed')
                prior = json.loads(receipt.read_text())
                if prior.get('scoped_gate_passed') is not True or prior['source'] != reuse['prior_source']:
                    raise RuntimeError('Prior cache owner did not complete its frozen browser scope')
                prior_source = ROOT / 'firefox-source-m5'
                source_state(prior_source, reuse['prior_source'])
                links = []
                for relative in ['robrix-tools', 'robrix-build/workspace/target']:
                    original = prior_source / 'apps/hepta-control-ui/rust/target' / relative
                    destination = ui / 'rust/target' / relative
                    if original.is_symlink() or not original.is_dir() or destination.exists() or destination.is_symlink():
                        raise RuntimeError('Unexpected owned compiler-cache path')
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.symlink_to(original, target_is_directory=True)
                    links.append({'path': str(destination), 'target': str(original)})
                result['compiler_cache_reuse'] = {'links': links, 'completed_prior_receipt': observed,
                    'scope': 'Owned mutable compiler outputs only. Original build regenerates M6 source overlays and packaged artifacts; no prior test credit.'}
            for name, argv in [('node', ['node', '--version']), ('npm', ['npm', '--version']),
                               ('rust-stable', ['rustup', 'run', '1.95.0', 'rustc', '--version']),
                               ('rust-nightly', ['rustup', 'run', 'nightly-2026-10-02', 'rustc', '--version']),
                               ('tesseract', ['tesseract', '--version']), ('ocr-languages', ['tesseract', '--list-langs']),
                               ('pillow', ['/usr/bin/python3', '-c', 'import PIL,platform;print(platform.python_version(),PIL.__version__)']),
                               ('fonts', ['/usr/bin/python3', 'tools/prepare-fonts.py', '--offline'])]:
                run(name, argv)
            js_gate = run('javascript-controls', ['node', '--test', 'test/robrix-pixel-plan.test.mjs'])
            js_text = (out / 'javascript-controls.stdout').read_text()
            counts = {name: int(re.search(r'^# ' + name + r' (\d+)$', js_text, re.M).group(1))
                      for name in ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']}
            result['javascript_controls'] = counts
            if counts != {'tests': 16, 'pass': 16, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}:
                raise RuntimeError('Unexpected original JavaScript control counts')
            sdk = Path(profile['makepad_checkout'])
            result['sdk'] = {'path': str(sdk), 'head': git(sdk, 'rev-parse', 'HEAD').decode().strip(),
                             'tree': git(sdk, 'rev-parse', 'HEAD^{tree}').decode().strip(),
                             'status': git(sdk, 'status', '--porcelain=v1', '--untracked-files=all').decode()}
            if result['sdk']['head'] != profile['makepad_revision']:
                raise RuntimeError('Unexpected Makepad dependency revision')
            git(sdk, 'diff', '--exit-code', 'HEAD', '--')
            save(out / 'SDK_PHYSICAL_INPUTS.json', physical_inventory(sdk))
            result['sdk']['physical_inventory'] = pin(out / 'SDK_PHYSICAL_INPUTS.json')
            run('source-archive', ['git', 'archive', '--format=tar', '--prefix=source/', '--output=' + str(evidence / 'source.tar'), expected['commit']], source)
            result['source_archive'] = pin(evidence / 'source.tar')
            binding = {'schema': 'hepta.source-archive-binding.v1',
                       'tested_source': expected, 'archive_prefix': 'source',
                       'archive': {**result['source_archive'], 'path': 'source.tar'},
                       'runtime_configuration': {**pin(evidence / 'FROZEN_PROFILE.json'), 'path': 'FROZEN_PROFILE.json'}}
            save(evidence / 'archive-binding.json', binding)
            run('source-archive-integrity', ['/usr/bin/python3', '-B', 'scripts/hepta_source_archive.py',
                '--binding', evidence / 'archive-binding.json', '--source-root', source,
                '--artifact-root', evidence, '--output', evidence / 'archive-integrity.json'], source)
        elif phase.endswith('-build'):
            argv = ['npm', 'run', 'build'] if phase == 'default-build' else ['node', 'tools/build-robrix.mjs', '--fixtures']
            run('build', argv)
            dist = ui / ('dist-robrix-fixtures' if phase.startswith('fixtures') else 'dist')
            (out / 'BUILD_MANIFEST.json').write_bytes((dist / 'build-manifest.json').read_bytes())
            result['build_manifest'] = pin(out / 'BUILD_MANIFEST.json')
        else:
            scope = phase.split('-')[0]
            build_receipt = evidence / (scope + '-build') / 'RESULT.json'
            built = json.loads(build_receipt.read_text())
            if (built['source'] != expected or built['profile'] != pin(profile_path)
                    or built.get('scoped_gate_passed') is not True):
                raise RuntimeError('Matching successful build receipt required')
            dist = ui / ('dist-robrix-fixtures' if scope == 'fixtures' else 'dist')
            result['build_receipt'] = pin(build_receipt)
            result['package_before'] = package_state(dist, built['build_manifest'])
            suite = run('firefox-suite', ['xvfb-run', '-a', 'npm', 'run', 'test:robrix', '--', '--project=firefox'], required=False)
            result['package_after'] = package_state(dist, built['build_manifest'])
            if result['package_before'] != result['package_after']:
                raise RuntimeError('Package changed during browser execution')
            run('original-pixel-verifier', ['node', 'tools/verify-robrix-evidence.mjs', 'test-results/robrix-' + scope, scope], required=False)
            for name in ['robrix-' + scope + '-results.json', 'robrix-' + scope + '-pixel-results.json']:
                actual = ui / 'test-results' / name
                if actual.is_file():
                    (out / name).write_bytes(actual.read_bytes())
            actual = out / ('robrix-' + scope + '-results.json')
            if actual.is_file():
                report = json.loads(actual.read_text())
                result['playwright_stats'] = report.get('stats')
            actual = out / ('robrix-' + scope + '-pixel-results.json')
            if actual.is_file():
                report = json.loads(actual.read_text())
                rows = [r for r in report['results'] if r['browser'] == 'firefox']
                checks = [c for r in rows for c in r.get('checks', [])]
                result['firefox_pixels'] = {'scope': 'Firefox subset of unchanged full three-engine verifier',
                    'full_verifier_passed': report['passed'],
                    'required_captures': report['captures']['required'] // 3,
                    'passed_captures': sum(bool(r.get('name') and r['passed']) for r in rows),
                    'required_checks': report['semanticChecks']['required'] // 3,
                    'evaluated_checks': len(checks), 'passed_checks': sum(c['passed'] for c in checks),
                    'rows': rows, 'passed': bool(rows) and all(r['passed'] for r in rows)
                        and len(rows) == report['captures']['required'] // 3
                        and len(checks) == report['semanticChecks']['required'] // 3}
            stats = result.get('playwright_stats') or {}
            gate_passed = (suite['exit_code'] == 0
                and stats.get('expected') == (3 if scope == 'fixtures' else 2)
                and stats.get('unexpected') == stats.get('flaky') == stats.get('skipped') == 0
                and result.get('firefox_pixels', {}).get('passed') is True)
            if phase == 'fixtures-test':
                sdk = Path(profile['makepad_checkout'])
                sdk_after = physical_inventory(sdk)
                save(out / 'SDK_PHYSICAL_AFTER.json', sdk_after)
                result['sdk_after'] = {'head': git(sdk, 'rev-parse', 'HEAD').decode().strip(),
                    'tree': git(sdk, 'rev-parse', 'HEAD^{tree}').decode().strip(),
                    'status': git(sdk, 'status', '--porcelain=v1', '--untracked-files=all').decode(),
                    'physical_inventory': pin(out / 'SDK_PHYSICAL_AFTER.json')}
                if sdk_after != json.loads((evidence / 'prepare/SDK_PHYSICAL_INPUTS.json').read_text()):
                    raise RuntimeError('Makepad physical inputs changed across browser execution')
        after = physical_inventory(source, 'apps/hepta-control-ui')
        save(out / 'UI_SOURCE_AFTER.json', after)
        result['ui_source_after'] = pin(out / 'UI_SOURCE_AFTER.json')
        if before != after:
            raise RuntimeError('Physical UI tracked bytes changed during phase')
        ok = True
    except BaseException as exc:
        result['failure'] = type(exc).__name__ + ': ' + str(exc)
    finally:
        try:
            result['source_after'] = source_state(source, expected)
        except BaseException as exc:
            result['source_after_error'] = type(exc).__name__ + ': ' + str(exc)
            ok = False
        result.update(result='PHASE_COMPLETED' if ok else 'PHASE_FAILED',
                      execution_completed=ok, scoped_gate_passed=ok and gate_passed,
                      finished_at_utc=now(), outer_wall_seconds=time.monotonic() - started)
        save(out / 'RESULT.json', result)
        print(json.dumps({'phase': phase, 'result': result['result'], 'failure': result.get('failure'), 'receipt': str(out / 'RESULT.json')}), flush=True)
    if not ok or not gate_passed:
        sys.exit(1)


if __name__ == '__main__':
    main()
