"""Additional original native UI and strict Clippy gates on frozen M6."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/cell-continuation-20261109-08b6')
SOURCE = ROOT / 'firefox-source-m6'
EVIDENCE = ROOT / 'firefox-validation-m6'
EXPECTED = {'commit': '885dae0f3285267e9e9c49d8b43b0d009779f9e8',
            'tree': '293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb'}
CONTROLLER_SHA = '6fe725b132e16734b998cb16d4fbf3fb8fca6784676d868c150880245ec623e2'
JUST = Path('/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin/just')
NEXTEST = Path('/home/qian-qi/work/cell-dependency-pin-20261108-08b6-evidence/tools/bin/cargo-nextest')


def main():
    phase = sys.argv[1]
    if phase not in ['native-ui', 'native-clippy']:
        raise ValueError('Unsupported phase')
    helper = ROOT / 'run_firefox_candidate_m6.py'
    if hashlib.sha256(helper.read_bytes()).hexdigest() != CONTROLLER_SHA:
        raise RuntimeError('Frozen shared evidence helper changed')
    spec = importlib.util.spec_from_file_location('evidence', helper)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    os.umask(0o077)
    out = EVIDENCE / phase
    out.mkdir(mode=0o700, exist_ok=False)
    (out / 'CONTROLLER.py').write_bytes(Path(__file__).read_bytes())
    toolchain = '1.96.0' if phase == 'native-ui' else '1.95.0'
    toolbin = Path('/home/qian-qi/.rustup/toolchains/' + toolchain + '-x86_64-unknown-linux-gnu/bin')
    target = ROOT / ('ui-native-target-m6-' + toolchain)
    env = os.environ.copy()
    overrides = {'RUSTUP_TOOLCHAIN': toolchain, 'CARGO_BUILD_JOBS': '2',
        'CARGO_TARGET_DIR': str(target), 'CARGO_TERM_COLOR': 'never',
        'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
        'CARGO_PROFILE_TEST_DEBUG': '0', 'PYTHONDONTWRITEBYTECODE': '1',
        'HEPTA_CJK_FONT_CACHE': str(ROOT / 'firefox-tools/font-assets'),
        'PATH': ':'.join(map(str, [toolbin, NEXTEST.parent, JUST.parent])) + ':' + env.get('PATH', '')}
    env.update(overrides)
    font_root = SOURCE / 'apps/hepta-control-ui/rust/robrix-ui/resources/fonts'
    manifest = json.loads((font_root / 'MANIFEST.json').read_text())
    assets = manifest['assets']
    if hashlib.sha256((font_root / 'MANIFEST.json').read_bytes()).hexdigest() != 'fb9e49a7f14b742ac7e390ceee9be115ad6e04a5f852eec67fb0a126870070a3':
        raise RuntimeError('Unexpected font manifest')
    argv = ([str(JUST), 'test', '--manifest-path', str(SOURCE / 'apps/hepta-control-ui/rust/Cargo.toml'),
             '--locked', '-p', 'hepta-robrix-ui', '--lib', '--features', 'ui']
            if phase == 'native-ui' else
            [str(toolbin / 'cargo'), 'clippy', '--locked', '--manifest-path',
             'apps/hepta-control-ui/rust/Cargo.toml', '-p', 'hepta-robrix-ui',
             '--all-targets', '--features', 'ui,native-host,native-presentation', '--', '-D', 'warnings'])
    prepared = json.loads((EVIDENCE / 'prepare/RESULT.json').read_text())
    if prepared['source'] != EXPECTED or prepared.get('scoped_gate_passed') is not True:
        raise RuntimeError('Matching completed source/archive preparation required')
    profile = {'schema': 'hepta.m6.native-ui-profile.v1', 'source': EXPECTED, 'phase': phase,
        'command': argv, 'environment_overrides': overrides, 'target': str(target),
        'controller': module.pin(Path(__file__)), 'shared_helper': module.pin(helper),
        'font_manifest': module.pin(font_root / 'MANIFEST.json'), 'assets': assets,
        'asset_policy': 'Absent before setup; exact manifest bytes temporarily installed; only those exact bytes removed in finally; clean after',
        'sdk_baseline': module.pin(EVIDENCE / 'prepare/SDK_PHYSICAL_INPUTS.json'),
        'browser_profile': module.pin(EVIDENCE / 'FROZEN_PROFILE.json'),
        'source_archive_sha256': prepared['source_archive']['sha256'],
        'prepare_receipt': module.pin(EVIDENCE / 'prepare/RESULT.json'),
        'h_budget_scope': 'Shared outer M6 sequential worker; only remaining time, not a fresh phase deadline',
        'h_budget_seconds': 1200, 'h_cpu_percent': 200, 'h_memory_bytes': 4294967296,
        'scientific_benefit': False, 'production_qualification': False, 'joint_learning_configuration': None}
    module.save(out / 'PROFILE.json', profile)
    result = {'schema': 'hepta.m6.native-ui-result.v1', 'source': EXPECTED, 'phase': phase,
              'profile': module.pin(out / 'PROFILE.json'), 'steps': [], 'started_at_utc': module.now()}
    started = time.monotonic()

    def run(label, command):
        row = {'label': label, 'argv': command, 'cwd': str(SOURCE), 'started_at_utc': module.now()}
        module.save(out / (label + '.intent.json'), row)
        begin = time.monotonic()
        with (out / (label + '.stdout')).open('xb') as stdout, (out / (label + '.stderr')).open('xb') as stderr:
            child = subprocess.Popen(command, cwd=SOURCE, env=env, stdout=stdout, stderr=stderr)
            while child.poll() is None:
                try:
                    child.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    print(json.dumps({'running': label, 'wall_seconds': time.monotonic() - begin}), flush=True)
        row.update(exit_code=child.returncode, wall_seconds=time.monotonic() - begin,
                   finished_at_utc=module.now(), stdout=module.pin(out / (label + '.stdout')),
                   stderr=module.pin(out / (label + '.stderr')))
        module.save(out / (label + '.result.json'), row)
        result['steps'].append(row)
        print(json.dumps({'completed': label, 'exit_code': child.returncode, 'wall_seconds': row['wall_seconds']}), flush=True)
        return row

    ok = False
    installed = False
    before = None
    sdk = Path('/home/qian-qi/.cargo/git/checkouts/makepad-69d78fae78fc8901/337566c')
    try:
        result['source_before'] = module.source_state(SOURCE, EXPECTED)
        before = module.physical_inventory(SOURCE, 'apps/hepta-control-ui')
        module.save(out / 'UI_SOURCE_BEFORE.json', before)
        baseline = json.loads((EVIDENCE / 'prepare/SDK_PHYSICAL_INPUTS.json').read_text())
        result['sdk_before'] = {'head': module.git(sdk, 'rev-parse', 'HEAD').decode().strip(),
            'tree': module.git(sdk, 'rev-parse', 'HEAD^{tree}').decode().strip(),
            'status': module.git(sdk, 'status', '--porcelain=v1', '--untracked-files=all').decode()}
        if result['sdk_before']['head'] != '337566c8b25d47f7e4fff6a202157b65bf183330':
            raise RuntimeError('SDK revision changed')
        module.git(sdk, 'diff', '--exit-code', 'HEAD', '--')
        if module.physical_inventory(sdk) != baseline:
            raise RuntimeError('SDK differs from frozen browser preparation inputs')
        result['tools'] = {}
        for name, path in [('just', JUST), ('nextest', NEXTEST), ('rustc', toolbin / 'rustc'), ('cargo', toolbin / 'cargo')]:
            result['tools'][name] = module.pin(path)
            version = run(name + '-version', [str(path), '--version'])
            if version['exit_code']:
                raise RuntimeError('Tool version check failed')
        for asset in assets:
            if (font_root / asset['file']).exists() or (font_root / asset['file']).is_symlink():
                raise RuntimeError('Font destination already exists')
        installed = True
        font_step = run('font-setup', ['/usr/bin/python3', str(SOURCE / 'apps/hepta-control-ui/tools/prepare-fonts.py'),
            '--cache', str(ROOT / 'firefox-tools/font-assets'), '--offline', '--install', str(font_root)])
        if font_step['exit_code']:
            raise RuntimeError('Font setup failed')
        during = {'head': module.git(SOURCE, 'rev-parse', 'HEAD').decode().strip(),
                  'tree': module.git(SOURCE, 'rev-parse', 'HEAD^{tree}').decode().strip(),
                  'status': module.git(SOURCE, 'status', '--porcelain=v1', '--untracked-files=all').decode()}
        result['source_during_fonts'] = during
        allowed = {'?? ' + str((font_root / asset['file']).relative_to(SOURCE)) for asset in assets}
        if during['head'] != EXPECTED['commit'] or during['tree'] != EXPECTED['tree'] or set(during['status'].splitlines()) != allowed:
            raise RuntimeError('Unexpected source state during native resource setup')
        gate = run('original-gate', argv)
        ok = gate['exit_code'] == 0
        if phase == 'native-ui':
            text = (out / 'original-gate.stdout').read_text(errors='replace') + (out / 'original-gate.stderr').read_text(errors='replace')
            text = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', text)
            matches = re.findall(r'(\d+) tests run: (\d+) passed(?:[^\n]*?), (\d+) skipped', text)
            result['summary_matches'] = matches
            result['summary_lines'] = [line for line in text.splitlines() if 'Summary' in line]
            result['retry_lines'] = [line for line in text.splitlines() if re.search(r'\b(?:RETRY|TRY|FLAKY)\b', line)]
            ok = ok and matches[-1:] == [('33', '33', '0')]
    except BaseException as exc:
        result['failure'] = type(exc).__name__ + ': ' + str(exc)
        ok = False
    finally:
        try:
            if installed:
                for asset in assets:
                    path = font_root / asset['file']
                    if path.exists() or path.is_symlink():
                        actual = module.pin(path)
                        if path.is_symlink() or any(actual[k] != asset[k] for k in ['bytes', 'sha256']):
                            raise RuntimeError('Refusing cleanup of changed font bytes')
                        path.unlink()
            result['source_after'] = module.source_state(SOURCE, EXPECTED)
            after = module.physical_inventory(SOURCE, 'apps/hepta-control-ui')
            module.save(out / 'UI_SOURCE_AFTER.json', after)
            if before is not None and after != before:
                raise RuntimeError('Tracked UI bytes changed')
            actual_sdk = module.physical_inventory(sdk)
            module.save(out / 'SDK_PHYSICAL_AFTER.json', actual_sdk)
            if actual_sdk != json.loads((EVIDENCE / 'prepare/SDK_PHYSICAL_INPUTS.json').read_text()):
                raise RuntimeError('SDK physical input changed')
            result['sdk_after'] = {'head': module.git(sdk, 'rev-parse', 'HEAD').decode().strip(),
                'tree': module.git(sdk, 'rev-parse', 'HEAD^{tree}').decode().strip(),
                'status': module.git(sdk, 'status', '--porcelain=v1', '--untracked-files=all').decode(),
                'physical_inventory': module.pin(out / 'SDK_PHYSICAL_AFTER.json')}
            if any(result['sdk_after'][k] != result['sdk_before'][k] for k in ['head', 'tree', 'status']):
                raise RuntimeError('SDK Git identity/status changed')
        except BaseException as exc:
            result['cleanup_or_integrity_failure'] = type(exc).__name__ + ': ' + str(exc)
            ok = False
        result.update(scoped_gate_passed=ok, finished_at_utc=module.now(),
                      outer_wall_seconds=time.monotonic() - started, scientific_benefit=False, production_qualification=False)
        module.save(out / 'RESULT.json', result)
        print(json.dumps({'phase': phase, 'passed': ok, 'failure': result.get('failure'),
                          'integrity_failure': result.get('cleanup_or_integrity_failure')}), flush=True)
    if not ok:
        sys.exit(1)


if __name__ == '__main__':
    main()
