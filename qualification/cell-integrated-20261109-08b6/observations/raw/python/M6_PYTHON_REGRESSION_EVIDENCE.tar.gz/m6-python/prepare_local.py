from pathlib import Path
import datetime
import hashlib
import json
import os
import resource
import shutil
import stat
import subprocess
import time

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'm3-python'
SOURCE = ROOT / 'source-subset'
PYTHON = OLD / 'venv/bin/python'
started = time.monotonic()
cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
assert not SOURCE.exists()
manifest = json.loads((OLD / 'SOURCE_MANIFEST.json').read_text())
SOURCE.mkdir()
for row in manifest['files']:
    relative = Path(row['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    src, dst = OLD / 'source-subset' / relative, SOURCE / relative
    assert src.is_file() and not src.is_symlink()
    raw = src.read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['git_blob']
    assert stat.S_IMODE(src.stat().st_mode) == int(row['git_mode'][-3:], 8)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(raw)
    dst.chmod(int(row['git_mode'][-3:], 8))
(ROOT / 'SOURCE_MANIFEST_ORIGIN.json').write_bytes((OLD / 'SOURCE_MANIFEST.json').read_bytes())
controller = (OLD / 'run_final_suite.py').read_text()
controller = controller.replace(str(OLD), str(ROOT))
controller = controller.replace("PYTHON = ROOT / 'venv/bin/python'", 'PYTHON = Path(' + repr(str(PYTHON)) + ')')
controller = controller.replace("assert binding['final_head'] != binding['export_origin_head']", "assert binding['final_head'] == '885dae0f3285267e9e9c49d8b43b0d009779f9e8'\nassert binding['final_tree'] == '293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb'")
controller = controller.replace("if name == 'repo-mdv':\n        row['qualified_pass'] = row['qualified_pass'] and row['tests_run'] == 13", "expected = {'joint-config': 23, 'state-codec': 6, 'subprocess-supervisor': 8, 'training-result': 14, 'source-archive': 13, 'pred-training-diagnosis': 14, 'repo-mdv': 13}\n    row['qualified_pass'] = row['qualified_pass'] and row['tests_run'] == expected[name]")
with (ROOT / 'run_final_suite.py').open('x') as f:
    f.write(controller)
env = dict(os.environ)
env.update(PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
code = 'import sys,torch,numpy,PIL,json,platform; print(json.dumps(dict(python=sys.version,executable=sys.executable,platform=platform.platform(),torch=torch.__version__,numpy=numpy.__version__,Pillow=PIL.__version__,cuda=torch.version.cuda,torch_tensor_sum=torch.tensor([1.0,2.0]).sum().item()))); assert torch.__version__=="2.9.1+cpu" and numpy.__version__=="1.26.4" and PIL.__version__=="12.0.0" and torch.version.cuda is None'
argv = [str(PYTHON), '-B', '-c', code]
(ROOT / 'RUNTIME_IMPORT_INTENT.json').write_text(json.dumps({'argv': argv, 'cwd': str(ROOT)}, indent=2) + '\n')
begin = time.monotonic()
with (ROOT / 'runtime-import.stdout').open('xb') as out, (ROOT / 'runtime-import.stderr').open('xb') as err:
    result = subprocess.run(argv, cwd=ROOT, env=env, stdout=out, stderr=err, timeout=60)
import_wall = time.monotonic() - begin
after = resource.getrusage(resource.RUSAGE_CHILDREN)
report = {'schema': 'cell.m6.python-local-preparation.v1', 'state': 'SOURCE_COPIED_AWAITING_EXACT_FINAL_GIT_BINDING', 'source_files': len(manifest['files']), 'source_bytes': sum(x['bytes'] for x in manifest['files']), 'runtime_reused_from': str(PYTHON), 'runtime_install_executed': False, 'runtime_import_exit': result.returncode, 'runtime_import_wall_seconds': import_wall, 'observed_wall_seconds': time.monotonic()-started, 'reaped_child_cpu_seconds': after.ru_utime+after.ru_stime-cpu.ru_utime-cpu.ru_stime, 'nested_costs_not_additive': True, 'cold_cache_claim': False, 'prior_controller_sha256': hashlib.sha256((OLD/'run_final_suite.py').read_bytes()).hexdigest(), 'controller_sha256': hashlib.sha256(controller.encode()).hexdigest(), 'original_rog_install_011': 'UNKNOWN_NOT_REPLAYED', 'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(ROOT / 'LOCAL_PREPARATION.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report), flush=True)
raise SystemExit(result.returncode)
