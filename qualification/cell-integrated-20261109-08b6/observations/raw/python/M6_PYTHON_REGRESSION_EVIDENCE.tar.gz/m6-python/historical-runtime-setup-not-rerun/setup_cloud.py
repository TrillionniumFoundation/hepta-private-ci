from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import resource
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/08b6dd5f2d10/continuation-lifecycle/m3-python')
OUT = ROOT / 'cloud-setup-001'
VENV = ROOT / 'venv'
assert not OUT.exists() and not VENV.exists()
OUT.mkdir(parents=True)
ENV = dict(os.environ)
ENV.update(PYTHONDONTWRITEBYTECODE='1', UV_HTTP_TIMEOUT='60')
started = time.monotonic()
initial = resource.getrusage(resource.RUSAGE_CHILDREN)
report = {'schema': 'cell.m3.python-setup.v1', 'platform': platform.platform(),
          'base_python': sys.version, 'base_executable': sys.executable,
          'direct_pins': ['torch==2.9.1+cpu', 'numpy==1.26.4', 'Pillow==12.0.0'],
          'venv': str(VENV), 'steps': [], 'state': 'STARTED',
          'independent_environment_from_unknown_rog_011': True,
          'original_rog_job_status': 'UNKNOWN_NOT_REPLAYED',
          'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}

def save():
    (OUT / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')

def run(name, argv, timeout=600):
    intent = {'argv': argv, 'cwd': str(ROOT), 'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (OUT / (name + '.intent.json')).write_text(json.dumps(intent, indent=2) + '\n')
    begin = time.monotonic()
    cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
    code, error = None, None
    with (OUT / (name + '.stdout')).open('xb') as stdout, (OUT / (name + '.stderr')).open('xb') as stderr:
        try:
            code = subprocess.run(argv, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr, timeout=timeout).returncode
        except BaseException as exc:
            error = {'type': type(exc).__name__, 'message': str(exc)}
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    row = {**intent, 'name': name, 'exit_code': code, 'error': error,
           'wall_seconds': time.monotonic() - begin,
           'reaped_child_cpu_seconds': after.ru_utime + after.ru_stime - cpu.ru_utime - cpu.ru_stime}
    for stream in ('stdout', 'stderr'):
        p = OUT / (name + '.' + stream)
        data = p.read_bytes()
        row[stream] = {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    report['steps'].append(row)
    save()
    print(json.dumps(row), flush=True)
    if error is not None or code != 0:
        raise RuntimeError(name + ' failed')

try:
    uv = '/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/uv'
    run('create-venv', [uv, 'venv', '--python', sys.executable, str(VENV)], 60)
    python = str(VENV / 'bin/python')
    run('install-torch-cpu', [uv, '--native-tls', 'pip', 'install', '--python', python,
        '--index-url', 'https://download.pytorch.org/whl/cpu', 'torch==2.9.1+cpu'], 600)
    run('install-numpy-pillow', [uv, '--native-tls', 'pip', 'install', '--python', python,
        'numpy==1.26.4', 'Pillow==12.0.0'], 300)
    run('actual-import', [python, '-B', '-c',
        'import sys,torch,numpy,PIL,json; print(json.dumps(dict(python=sys.version,executable=sys.executable,torch=torch.__version__,numpy=numpy.__version__,Pillow=PIL.__version__,cuda=torch.version.cuda))); assert torch.__version__=="2.9.1+cpu" and numpy.__version__=="1.26.4" and PIL.__version__=="12.0.0" and torch.version.cuda is None'], 60)
    run('freeze', [uv, 'pip', 'freeze', '--python', python], 60)
    report['state'] = 'READY_FIXED_VERSIONS_ACTUALLY_IMPORTED'
except BaseException as exc:
    report['state'] = 'SETUP_FAILED'
    report['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
finally:
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    report['observed_setup_wall_seconds'] = time.monotonic() - started
    report['observed_reaped_child_cpu_seconds'] = after.ru_utime + after.ru_stime - initial.ru_utime - initial.ru_stime
    report['nested_costs_not_additive'] = True
    report['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({'state': report['state'], 'wall_seconds': report['observed_setup_wall_seconds']}), flush=True)
if report['state'] != 'READY_FIXED_VERSIONS_ACTUALLY_IMPORTED':
    raise SystemExit(1)
