from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
VENV = ROOT.parent / 'm3-python/venv'
phase = sys.argv[1]
assert phase in ('BEFORE', 'AFTER')
output = ROOT / ('RUNTIME_INVENTORY_' + phase + '.json')
assert not output.exists()
started = time.monotonic()
rows = []
for p in sorted(VENV.rglob('*')):
    if p.is_symlink():
        rows.append({'path': str(p.relative_to(VENV)), 'kind': 'symlink', 'target': os.readlink(p)})
    elif p.is_file():
        h = hashlib.sha256()
        with p.open('rb') as f:
            for part in iter(lambda: f.read(1024*1024), b''):
                h.update(part)
        rows.append({'path': str(p.relative_to(VENV)), 'kind': 'file', 'bytes': p.stat().st_size, 'sha256': h.hexdigest()})
base = (VENV / 'bin/python').resolve()
report = {'schema': 'cell.m6.runtime-inventory.v1', 'phase': phase, 'platform': platform.platform(), 'venv': str(VENV), 'files': rows, 'file_count': len(rows), 'regular_bytes': sum(x.get('bytes', 0) for x in rows), 'base_interpreter': {'path': str(base), 'sha256': hashlib.sha256(base.read_bytes()).hexdigest()}, 'git_version': subprocess.check_output(['git', '--version'], text=True).strip(), 'fingerprint_wall_seconds': time.monotonic()-started, 'scope': 'all installed venv regular bytes and symlink target strings; base interpreter separately pinned; external dynamic libraries not completely inventoried', 'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
if phase == 'AFTER':
    before = json.loads((ROOT/'RUNTIME_INVENTORY_BEFORE.json').read_text())
    report['same_as_before'] = rows == before['files'] and report['base_interpreter'] == before['base_interpreter'] and report['git_version'] == before['git_version']
output.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}), flush=True)
if phase == 'AFTER' and not report['same_as_before']:
    raise SystemExit(1)
