import time
from pathlib import Path
print('started', flush=True)
while not Path('/tmp/tmpr31x0yyj/finish').exists(): time.sleep(0.01)
print('finished', flush=True)
