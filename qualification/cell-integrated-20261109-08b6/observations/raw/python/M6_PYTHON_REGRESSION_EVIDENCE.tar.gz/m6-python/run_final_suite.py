from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import re
import resource
import stat
import subprocess
import time

ROOT = Path('/workspace/scratch/08b6dd5f2d10/continuation-lifecycle/m6-python')
SOURCE = ROOT / 'source-subset'
PYTHON = Path('/workspace/scratch/08b6dd5f2d10/continuation-lifecycle/m3-python/venv/bin/python')
BINDING = ROOT / 'FINAL_SOURCE_BINDING.json'
OUT = ROOT / 'final-suite-001'
GROUPS = [
    ('joint-config', ['test_hepta_cell_joint_config']),
    ('state-codec', ['ndu_real_runtime.test_state_codec']),
    ('subprocess-supervisor', ['ndu_real_runtime.test_subprocess_supervisor']),
    ('training-result', ['ndu_real_runtime.test_training_job_result']),
    ('source-archive', ['test_hepta_source_archive']),
    ('pred-training-diagnosis', ['hepta_pred1.test_diagnose_training']),
    ('repo-mdv', ['cell_repo_mdv.test_memory', 'cell_repo_mdv.test_runner']),
]
assert BINDING.exists() and not OUT.exists()
binding = json.loads(BINDING.read_text())
assert binding['state'] == 'EXACT_FINAL_GIT_BLOBS_VERIFIED'
assert binding['final_head'] == '885dae0f3285267e9e9c49d8b43b0d009779f9e8'
assert binding['final_tree'] == '293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb'
manifest = json.loads((ROOT / 'SOURCE_MANIFEST.json').read_text())
assert binding['file_count'] == len(manifest['files'])
OUT.mkdir()
env = dict(os.environ)
env.update(PYTHONPATH=os.pathsep.join([str(SOURCE / 'scripts'), str(SOURCE)]),
           PATH=str(PYTHON.parent) + os.pathsep + env.get('PATH', ''),
           PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
           OPENBLAS_NUM_THREADS='1', HEPTA_SUPERVISOR_QA_ROOT=str(OUT / 'supervisor-raw'))
started = time.monotonic()
initial_cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
report = {'schema': 'cell.final-python-regression.v1', 'final_source': binding,
          'platform': platform.platform(), 'source_scope': '93-file exact Git source subset; not a full repository archive',
          'source_directory': str(SOURCE), 'python': str(PYTHON),
          'controller_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'environment_overrides': {key: env[key] for key in ('PYTHONPATH','PATH','PYTHONDONTWRITEBYTECODE','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','HEPTA_SUPERVISOR_QA_ROOT')},
          'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scientific_confirmation_executed': False, 'production_learning_claimed': False,
          'original_rog_install_011': 'UNKNOWN_NOT_REPLAYED', 'groups': [], 'state': 'RUNNING'}

def save():
    (OUT / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')

def source_inventory():
    rows = []
    for item in manifest['files']:
        path = SOURCE / item['path']
        data = path.read_bytes()
        sha = hashlib.sha256(data).hexdigest()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert sha == item['sha256'] and blob == item['git_blob'] and len(data) == item['bytes'], item['path']
        assert stat.S_IMODE(path.stat().st_mode) == int(item['git_mode'][-3:], 8), item['path']
        rows.append({'path': item['path'], 'bytes': len(data), 'sha256': sha, 'git_blob': blob})
    assert {str(p.relative_to(SOURCE)) for p in SOURCE.rglob('*') if p.is_file()} == {row['path'] for row in rows}
    return rows

def run_group(name, modules):
    argv = [str(PYTHON), '-B', '-m', 'unittest', '-v', *modules]
    row = {'name': name, 'argv': argv, 'cwd': str(SOURCE),
           'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (OUT / (name + '.intent.json')).write_text(json.dumps(row, indent=2) + '\n')
    begin = time.monotonic()
    cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
    code, error = None, None
    with (OUT / (name + '.stdout')).open('xb') as stdout, (OUT / (name + '.stderr')).open('xb') as stderr:
        try:
            code = subprocess.run(argv, cwd=SOURCE, env=env, stdout=stdout, stderr=stderr, timeout=300).returncode
        except BaseException as exc:
            error = {'type': type(exc).__name__, 'message': str(exc)}
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    row.update(exit_code=code, error=error, wall_seconds=time.monotonic()-begin,
               reaped_child_cpu_seconds=after.ru_utime+after.ru_stime-cpu.ru_utime-cpu.ru_stime,
               ended_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    for stream in ('stdout','stderr'):
        data = (OUT / (name + '.' + stream)).read_bytes()
        row[stream] = {'path': name + '.' + stream, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    text = (OUT / (name + '.stderr')).read_text(errors='replace')
    count = re.findall(r'^Ran ([0-9]+) tests? in ([0-9.]+)s$', text, flags=re.MULTILINE)
    summary = re.findall(r'^(OK(?: \([^\n]*\))?|FAILED(?: \([^\n]*\))?)$', text, flags=re.MULTILINE)
    row['tests_run'] = int(count[-1][0]) if len(count) == 1 else None
    row['unittest_wall_seconds'] = float(count[-1][1]) if len(count) == 1 else None
    row['summary'] = summary[-1] if len(summary) == 1 else None
    row['skips'] = int(re.search(r'skipped=([0-9]+)', row['summary'] or '').group(1)) if 'skipped=' in (row['summary'] or '') else 0
    row['qualified_pass'] = code == 0 and error is None and row['tests_run'] is not None and row['tests_run'] > 0 and row['summary'] == 'OK'
    expected = {'joint-config': 23, 'state-codec': 6, 'subprocess-supervisor': 8, 'training-result': 14, 'source-archive': 13, 'pred-training-diagnosis': 14, 'repo-mdv': 13}
    row['qualified_pass'] = row['qualified_pass'] and row['tests_run'] == expected[name]
    report['groups'].append(row)
    save()
    print(json.dumps({k:row[k] for k in ('name','exit_code','tests_run','skips','summary','qualified_pass','wall_seconds')}), flush=True)

try:
    before = source_inventory()
    (OUT / 'SOURCE_BEFORE.json').write_text(json.dumps(before, indent=2) + '\n')
    save()
    for name, modules in GROUPS:
        run_group(name, modules)
    report['state'] = 'ALL_REQUESTED_GROUPS_PASSED' if all(g['qualified_pass'] for g in report['groups']) else 'REGRESSION_FAILED_OR_INCOMPLETE'
except BaseException as exc:
    report['state'] = 'REGRESSION_FAILED_OR_INCOMPLETE'
    report['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
finally:
    try:
        after = source_inventory()
        (OUT / 'SOURCE_AFTER.json').write_text(json.dumps(after, indent=2) + '\n')
        report['source_unchanged'] = before == after
    except BaseException as exc:
        report['source_unchanged'] = False
        report['source_after_error'] = {'type': type(exc).__name__, 'message': str(exc)}
        report['state'] = 'REGRESSION_FAILED_OR_INCOMPLETE'
    cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
    report['observed_suite_wall_seconds'] = time.monotonic()-started
    report['observed_suite_reaped_child_cpu_seconds'] = cpu.ru_utime+cpu.ru_stime-initial_cpu.ru_utime-initial_cpu.ru_stime
    report['nested_costs_not_additive'] = True
    report['tests_run'] = sum(g['tests_run'] or 0 for g in report['groups'])
    report['skips'] = sum(g['skips'] for g in report['groups'])
    report['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({k:report[k] for k in ('state','tests_run','skips','source_unchanged','observed_suite_wall_seconds')}), flush=True)
if report['state'] != 'ALL_REQUESTED_GROUPS_PASSED':
    raise SystemExit(1)
