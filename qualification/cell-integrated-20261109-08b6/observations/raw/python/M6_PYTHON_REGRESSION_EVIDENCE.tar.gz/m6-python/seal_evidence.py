from pathlib import Path
import datetime
import hashlib
import json
import shutil
import tarfile
import time

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'm3-python'
ARCHIVE = ROOT.parent / 'M6_PYTHON_REGRESSION_EVIDENCE.tar.gz'
assert not ARCHIVE.exists() and not (ROOT/'DELIVERY.json').exists()
result = json.loads((ROOT/'final-suite-001/RESULT.json').read_text())
binding = json.loads((ROOT/'FINAL_SOURCE_BINDING.json').read_text())
before = json.loads((ROOT/'RUNTIME_INVENTORY_BEFORE.json').read_text())
after = json.loads((ROOT/'RUNTIME_INVENTORY_AFTER.json').read_text())
prep = json.loads((ROOT/'LOCAL_PREPARATION.json').read_text())
freeze = json.loads((ROOT/'RUNTIME_FREEZE_RESULT.json').read_text())
runtime = json.loads((ROOT/'runtime-import.stdout').read_text())
assert result['state']=='ALL_REQUESTED_GROUPS_PASSED' and result['tests_run']==91 and result['skips']==0 and result['source_unchanged']
assert after['same_as_before'] and prep['runtime_import_exit']==0 and freeze['exit_code']==0
historical = ROOT/'historical-runtime-setup-not-rerun'
shutil.copytree(OLD/'cloud-setup-001', historical)
shutil.copyfile(OLD/'setup_cloud.py', historical/'setup_cloud.py')
prior_m5 = ROOT.parent/'m5-python'
history_m5 = ROOT/'historical-M5-not-counted'
history_m5.mkdir()
for name in ['REPORT.zh-CN.md','COST_LEDGER.json','DELIVERY.json','INITIAL_PREPARATION_FAILURES.json','M5_SOURCE_BINDING_READ_RECEIPT.json']:
    shutil.copyfile(prior_m5/name, history_m5/name)
shutil.copyfile(prior_m5/'final-suite-001/RESULT.json',history_m5/'ORIGINAL_PYTHON_RESULT.json')
prior_setup = json.loads((OLD/'cloud-setup-001/RESULT.json').read_text())
cost = {
    'schema':'cell.m6.python-cost-ledger.v1',
    'source_commit':binding['final_head'],
    'regression':{'outer_wall_seconds':result['observed_suite_wall_seconds'],'reaped_child_cpu_seconds':result['observed_suite_reaped_child_cpu_seconds'],'nested_commands':result['groups']},
    'local_preparation':prep,
    'separate_observed_wall_windows':{'native_exact_source_binding':binding['observed_wall_seconds'],'runtime_fingerprint_before':before['fingerprint_wall_seconds'],'runtime_fingerprint_after':after['fingerprint_wall_seconds'],'runtime_freeze':freeze['wall_seconds']},
    'failures':'No new M6 preparation or regression failure. Necessary prior M5 failure records are preserved under historical-M5-not-counted; not attributed to M6. Root native freeze process terminal remains external UNKNOWN.',
    'historical_environment_setup':{'executed_in_M6':False,'source_record':'historical-runtime-setup-not-rerun/RESULT.json','note':'Original M4 environment creation and installation logs retained unchanged; not charged again as new M6 installation.'},
    'nested_costs_not_additive':True,'cold_cache_claim':False,'no_complete_end_to_end_cost_claim':True,
    'unmeasured':['tool RPC transfer/wait','reasoning','prior container/global cache and bytecode cache preparation','external standard library and dynamic library full inventory','peak memory','energy','provider charges','original UNKNOWN rog install011 cost'],
    'original_rog_install_011':'UNKNOWN_NOT_REPLAYED'}
(ROOT/'COST_LEDGER.json').write_text(json.dumps(cost,indent=2)+'\n')
profile={'schema':'cell.m6.python-runtime-profile.v1','actual_import':runtime,'installed_versions':(ROOT/'runtime-freeze.stdout').read_text(),'before_inventory':'RUNTIME_INVENTORY_BEFORE.json','after_inventory':'RUNTIME_INVENTORY_AFTER.json','files_before_after_identical':True,'file_count':after['file_count'],'regular_bytes':after['regular_bytes'],'base_interpreter':after['base_interpreter'],'git_version':after['git_version'],'runtime_reused_from_previous_run':True,'runtime_install_executed':False,'delta_from_previous_M4':'RUNTIME_DELTA_FROM_M4.json','complete_machine_image':False}
(ROOT/'RUNTIME_PROFILE.json').write_text(json.dumps(profile,indent=2)+'\n')
groups='\n'.join(f"| `{g['name']}` | {g['tests_run']} | {g['skips']} | {g['exit_code']} | {g['wall_seconds']:.6f} |" for g in result['groups'])
report=f'''# M6 独立 Cloud Python 回归证据

## 结论

精确 M6 的所要求七组测试本次重新执行 **91/91 通过、0 skip、七个测试进程均 exit 0**。受测 93 个源码/资源文件前后完全一致；独立 Cloud 真实 Torch 环境在本次前后完整指纹一致。这不是托管 CI 结论、生产学习收益或采用证明。

## 共同候选与受测范围

- M6 commit：`{binding['final_head']}`
- M6 tree：`{binding['final_tree']}`
- parent：`{binding['final_parent']}`
- 原生精确 Git 核对来自 `{binding['source_git_repository']}`；当时工作树 HEAD 为 M6、status 为空。
- 93 个文件，共 {binding['source_bytes']:,} bytes，逐项核对 Git mode/blob ID、字节数和 SHA256；映射 SHA256 为 `{binding['checked_mapping_sha256']}`。
- 实际运行目录为 `{ROOT/'source-subset'}`，从既有源副本复制后重新绑定 M6 Git 对象；没有借用 M4/M5 的通过结果。
- `SOURCE_MANIFEST.json` 与 `source-subset/` 完整列出并保留此次输入。**这是 93 文件受测子集，不是完整仓库归档**；共同完整源码由根任务另行归档。

## 实际执行

命令均为真实 venv Python 的 `-B -m unittest -v`，完整模块名、cwd、环境覆盖、开始/结束时间及原始 stdout/stderr 位于 `final-suite-001/`。监督器实际子进程的保留记录位于其 `supervisor-raw/`。

| 组 | 测试数 | skip | exit | 命令 wall 秒 |
|---|---:|---:|---:|---:|
{groups}
| 合计 | 91 | 0 | 全部 0 | 见外层费用 |

开始 `{result['started_at_utc']}`，结束 `{result['finished_at_utc']}`。外层测试 wall **{result['observed_suite_wall_seconds']:.9f} 秒**，已回收子进程 CPU **{result['observed_suite_reaped_child_cpu_seconds']:.6f} 秒**。各命令/测试内部耗时包含在外层内，不重复相加。

## 真实运行环境

- {runtime['platform']}；Python `{runtime['python'].split()[0]}`。
- Torch `{runtime['torch']}` CPU、NumPy `{runtime['numpy']}`、Pillow `{runtime['Pillow']}`；实际导入和张量运算成功，CUDA 为 null。未使用 stub 或为缺依赖跳过测试。
- 使用原私有 venv `{OLD/'venv'}`，本次没有重新安装。`runtime-freeze.stdout` 保留完整实际依赖版本。
- 本次前后核对 {after['file_count']:,} 个 venv 文件/符号链接目标、{after['regular_bytes']:,} regular bytes，并单独绑定基础 Python 可执行文件；全部一致。外部标准库和系统动态库未做完整机器镜像归档。
- 相较 M4 后置指纹，新增 1,530 个 `.pyc` 缓存，原有文件零删除、零字节变化；本次缓存已纳入独立前后指纹，且与 M5 后置指纹完全一致。缓存准备成本未知，**不宣称冷缓存**。

## 准备、失败与费用边界

- 精确 Git readback 远程操作 `1a1be910114-5e21-177` 最终为 succeeded/exit 0，stdout 1,123 bytes、无截断。本次只读请求一次启动返回 job id，未重放根侧冻结请求。根侧冻结进程终态仍未知；这里仅依据独立 Git 读回确认源码身份。
- 本次 M6 准备、绑定及回归未出现失败。必要 M5 原始失败、费用和结果保留在 `historical-M5-not-counted/`，不作为 M6 新执行或额外通过项。
- 实际本地复制/运行时导入准备 {prep['observed_wall_seconds']:.9f} 秒（其中导入 {prep['runtime_import_wall_seconds']:.9f} 秒，包含关系）；原生精确绑定 {binding['observed_wall_seconds']:.9f} 秒。
- 环境指纹前置 {before['fingerprint_wall_seconds']:.9f} 秒、后置 {after['fingerprint_wall_seconds']:.9f} 秒；freeze {freeze['wall_seconds']:.9f} 秒，均为测试外独立窗口。
- 原有环境安装原日志保留在 `historical-runtime-setup-not-rerun/`，明确为历史准备，不是本次重新执行。工具传输/等待、缓存准备、峰值内存、能耗、收费及原 rog 011 未知成本未完整测量；不声称完整端到端费用。
- 原 rog 安装 job011 仍为 UNKNOWN，未触碰或重放。

## 结论用途与限制

本次是冻结共同源码的工程回归。state-codec 使用真实 Torch；监督器使用真实 POSIX 子进程。协议/训练结果测试含既有合成 fixture，MDV 的 13 项是控制回归，不作为真实独立任务学习增益。PRED 仅执行既有诊断单测，未重跑确认集或改变 HOLD。生产 owner、独立评价/采用与普通后继任务收益不由这 91 项证明。

发布 head、最终托管 CI 与实际 checkout 身份须由后续独立回执说明；此文不声明新 PR 已发布或 CI 已绿。M4、M5 证据包和报告保持原样。
'''
(ROOT/'REPORT.zh-CN.md').write_text(report)
files=[]
for p in sorted(ROOT.rglob('*')):
    assert not p.is_symlink(), str(p)
    if p.is_file():
        assert p.name not in ('EVIDENCE_MANIFEST.json','DELIVERY.json')
        data=p.read_bytes()
        files.append({'path':str(p.relative_to(ROOT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':'cell.m6.python-evidence-manifest.v1','source_commit':binding['final_head'],'files':files,'scope':'All source-subset inputs, controller files, exact Git readbacks, original command logs, runtime fingerprints and cost records; historical environment setup explicitly labeled.'}
(ROOT/'EVIDENCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
started=time.monotonic()
with tarfile.open(ARCHIVE,'w:gz') as archive:
    for item in files:
        archive.add(ROOT/item['path'],arcname='m6-python/'+item['path'],recursive=False)
    archive.add(ROOT/'EVIDENCE_MANIFEST.json',arcname='m6-python/EVIDENCE_MANIFEST.json',recursive=False)
expected={'m6-python/'+x['path']:x for x in files}
manifest_raw=(ROOT/'EVIDENCE_MANIFEST.json').read_bytes()
expected['m6-python/EVIDENCE_MANIFEST.json']={'bytes':len(manifest_raw),'sha256':hashlib.sha256(manifest_raw).hexdigest()}
with tarfile.open(ARCHIVE,'r:gz') as archive:
    members=archive.getmembers()
    assert len(members)==len(expected) and {m.name for m in members}==set(expected)
    for member in members:
        assert member.isfile() and '..' not in Path(member.name).parts
        raw=archive.extractfile(member).read()
        assert len(raw)==expected[member.name]['bytes'] and hashlib.sha256(raw).hexdigest()==expected[member.name]['sha256']
raw=ARCHIVE.read_bytes()
result_raw=(ROOT/'final-suite-001/RESULT.json').read_bytes()
delivery={'schema':'cell.m6.python-evidence-delivery.v1','source_commit':binding['final_head'],'source_tree':binding['final_tree'],'tests':91,'skips':0,'all_process_exits':0,'runtime_before_after_equal':True,'source_before_after_equal':True,'complete_repository_archive':False,'archive':{'path':str(ARCHIVE),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'members':len(expected),'all_members_verified':True},'result':{'path':str(ROOT/'final-suite-001/RESULT.json'),'bytes':len(result_raw),'sha256':hashlib.sha256(result_raw).hexdigest()},'manifest_sha256':hashlib.sha256(manifest_raw).hexdigest(),'archive_creation_and_full_verification_wall_seconds':time.monotonic()-started,'cloud_suite_terminal':{'session_id':69663,'chunk_id':'7ad69f','exit_code':0},'native_binding_terminal':{'job_id':'1a1be910114-5e21-177','state':'succeeded','exit_code':0,'output_complete':True},'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(ROOT/'DELIVERY.json').write_text(json.dumps(delivery,indent=2)+'\n')
print(json.dumps(delivery),flush=True)
