from pathlib import Path
import datetime,hashlib,json,tarfile,time
ROOT=Path(__file__).resolve().parent
ARCHIVE=ROOT.parent/"M6_PYTHON_REGRESSION_EVIDENCE.tar.gz"
assert not ARCHIVE.exists() and not (ROOT/"EVIDENCE_MANIFEST.json").exists() and not (ROOT/"DELIVERY.json").exists()
binding=json.loads((ROOT/"FINAL_SOURCE_BINDING.json").read_text())
files=[]
for p in sorted(ROOT.rglob('*')):
    assert not p.is_symlink(), str(p)
    if p.is_file():
        assert p not in (ROOT/'EVIDENCE_MANIFEST.json', ROOT/'DELIVERY.json')
        data=p.read_bytes()
        files.append({'path':str(p.relative_to(ROOT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':'cell.m6.python-evidence-manifest.v1','source_commit':binding['final_head'],'files':files,'scope':'All source-subset inputs, controller files, exact Git readbacks, original command logs, runtime fingerprints and cost records; historical environment setup explicitly labeled.'}
(ROOT/'EVIDENCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
started=time.monotonic()
with tarfile.open(ARCHIVE,'w:gz') as archive:
    for item in files:
        archive.add(ROOT/item['path'],arcname='m6-python/'+item['path'],recursive=False)
    archive.add(ROOT/'EVIDENCE_MANIFEST.json',arcname='m6-python/EVIDENCE_MANIFEST.json',recursive=False)
expected={'m6-python/'+x['path']:x for x in files}
manifest_raw=(ROOT/'EVIDENCE_MANIFEST.json').read_bytes()
expected['m6-python/EVIDENCE_MANIFEST.json']={'bytes':len(manifest_raw),'sha256':hashlib.sha256(manifest_raw).hexdigest()}
with tarfile.open(ARCHIVE,'r:gz') as archive:
    members=archive.getmembers()
    assert len(members)==len(expected) and {m.name for m in members}==set(expected)
    for member in members:
        assert member.isfile() and '..' not in Path(member.name).parts
        raw=archive.extractfile(member).read()
        assert len(raw)==expected[member.name]['bytes'] and hashlib.sha256(raw).hexdigest()==expected[member.name]['sha256']
raw=ARCHIVE.read_bytes()
result_raw=(ROOT/'final-suite-001/RESULT.json').read_bytes()
delivery={'schema':'cell.m6.python-evidence-delivery.v1','source_commit':binding['final_head'],'source_tree':binding['final_tree'],'tests':91,'skips':0,'all_process_exits':0,'runtime_before_after_equal':True,'source_before_after_equal':True,'complete_repository_archive':False,'archive':{'path':str(ARCHIVE),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'members':len(expected),'all_members_verified':True},'result':{'path':str(ROOT/'final-suite-001/RESULT.json'),'bytes':len(result_raw),'sha256':hashlib.sha256(result_raw).hexdigest()},'manifest_sha256':hashlib.sha256(manifest_raw).hexdigest(),'archive_creation_and_full_verification_wall_seconds':time.monotonic()-started,'cloud_suite_terminal':{'session_id':69663,'chunk_id':'7ad69f','exit_code':0},'native_binding_terminal':{'job_id':'1a1be910114-5e21-177','state':'succeeded','exit_code':0,'output_complete':True},'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(ROOT/'DELIVERY.json').write_text(json.dumps(delivery,indent=2)+'\n')
print(json.dumps(delivery),flush=True)
