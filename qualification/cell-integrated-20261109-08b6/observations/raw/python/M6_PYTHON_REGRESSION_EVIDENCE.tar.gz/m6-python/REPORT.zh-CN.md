# M6 独立 Cloud Python 回归证据

## 结论

精确 M6 的所要求七组测试本次重新执行 **91/91 通过、0 skip、七个测试进程均 exit 0**。受测 93 个源码/资源文件前后完全一致；独立 Cloud 真实 Torch 环境在本次前后完整指纹一致。这不是托管 CI 结论、生产学习收益或采用证明。

## 共同候选与受测范围

- M6 commit：`885dae0f3285267e9e9c49d8b43b0d009779f9e8`
- M6 tree：`293ece7ffdffa2332ccfdec4fbbc4b7dcb3363cb`
- parent：`953d548d25b1e050109b1b93e1ea474b2ac7c801`
- 原生精确 Git 核对来自 `/home/qian-qi/work/cell-continuation-20261109-08b6/canonical-source`；当时工作树 HEAD 为 M6、status 为空。
- 93 个文件，共 1,168,871 bytes，逐项核对 Git mode/blob ID、字节数和 SHA256；映射 SHA256 为 `25f1894c1e981a172b2d2ba4292f99d3993d6c74ecbce2074c0a887ddf53a57a`。
- 实际运行目录为 `/workspace/scratch/08b6dd5f2d10/continuation-lifecycle/m6-python/source-subset`，从既有源副本复制后重新绑定 M6 Git 对象；没有借用 M4/M5 的通过结果。
- `SOURCE_MANIFEST.json` 与 `source-subset/` 完整列出并保留此次输入。**这是 93 文件受测子集，不是完整仓库归档**；共同完整源码由根任务另行归档。

## 实际执行

命令均为真实 venv Python 的 `-B -m unittest -v`，完整模块名、cwd、环境覆盖、开始/结束时间及原始 stdout/stderr 位于 `final-suite-001/`。监督器实际子进程的保留记录位于其 `supervisor-raw/`。

| 组 | 测试数 | skip | exit | 命令 wall 秒 |
|---|---:|---:|---:|---:|
| `joint-config` | 23 | 0 | 0 | 4.591899 |
| `state-codec` | 6 | 0 | 0 | 8.955312 |
| `subprocess-supervisor` | 8 | 0 | 0 | 2.654601 |
| `training-result` | 14 | 0 | 0 | 3.486494 |
| `source-archive` | 13 | 0 | 0 | 1.067755 |
| `pred-training-diagnosis` | 14 | 0 | 0 | 0.165504 |
| `repo-mdv` | 13 | 0 | 0 | 0.465710 |
| 合计 | 91 | 0 | 全部 0 | 见外层费用 |

开始 `2026-11-09T04:31:31.349869+00:00`，结束 `2026-11-09T04:31:52.768329+00:00`。外层测试 wall **21.420148971 秒**，已回收子进程 CPU **16.543231 秒**。各命令/测试内部耗时包含在外层内，不重复相加。

## 真实运行环境

- Linux-6.18.57-x86_64-with-glibc2.39；Python `3.12.14`。
- Torch `2.9.1+cpu` CPU、NumPy `1.26.4`、Pillow `12.0.0`；实际导入和张量运算成功，CUDA 为 null。未使用 stub 或为缺依赖跳过测试。
- 使用原私有 venv `/workspace/scratch/08b6dd5f2d10/continuation-lifecycle/m3-python/venv`，本次没有重新安装。`runtime-freeze.stdout` 保留完整实际依赖版本。
- 本次前后核对 17,139 个 venv 文件/符号链接目标、997,330,764 regular bytes，并单独绑定基础 Python 可执行文件；全部一致。外部标准库和系统动态库未做完整机器镜像归档。
- 相较 M4 后置指纹，新增 1,530 个 `.pyc` 缓存，原有文件零删除、零字节变化；本次缓存已纳入独立前后指纹，且与 M5 后置指纹完全一致。缓存准备成本未知，**不宣称冷缓存**。

## 准备、失败与费用边界

- 精确 Git readback 远程操作 `1a1be910114-5e21-177` 最终为 succeeded/exit 0，stdout 1,123 bytes、无截断。本次只读请求一次启动返回 job id，未重放根侧冻结请求。根侧冻结进程终态仍未知；这里仅依据独立 Git 读回确认源码身份。
- 本次 M6 准备、绑定及回归未出现失败。必要 M5 原始失败、费用和结果保留在 `historical-M5-not-counted/`，不作为 M6 新执行或额外通过项。
- 实际本地复制/运行时导入准备 2.353572230 秒（其中导入 2.324493514 秒，包含关系）；原生精确绑定 0.164969334 秒。
- 环境指纹前置 7.951748650 秒、后置 2.781150212 秒；freeze 0.016103820 秒，均为测试外独立窗口。
- 原有环境安装原日志保留在 `historical-runtime-setup-not-rerun/`，明确为历史准备，不是本次重新执行。工具传输/等待、缓存准备、峰值内存、能耗、收费及原 rog 011 未知成本未完整测量；不声称完整端到端费用。
- 原 rog 安装 job011 仍为 UNKNOWN，未触碰或重放。

- 首次封包控制器因历史 M5 的 `DELIVERY.json` 与过宽 basename 检查冲突而退出 1（0.062897029 秒），当时尚未创建归档。失败原件保留在 `PACKAGING_ATTEMPT_001.json`；随后只修正收集路径范围并封包，未重跑测试。

## 结论用途与限制

本次是冻结共同源码的工程回归。state-codec 使用真实 Torch；监督器使用真实 POSIX 子进程。协议/训练结果测试含既有合成 fixture，MDV 的 13 项是控制回归，不作为真实独立任务学习增益。PRED 仅执行既有诊断单测，未重跑确认集或改变 HOLD。生产 owner、独立评价/采用与普通后继任务收益不由这 91 项证明。

发布 head、最终托管 CI 与实际 checkout 身份须由后续独立回执说明；此文不声明新 PR 已发布或 CI 已绿。M4、M5 证据包和报告保持原样。
