# M5 独立 Cloud Python 回归证据

## 结论

精确 M5 的所要求七组测试本次重新执行 **91/91 通过、0 skip、七个测试进程均 exit 0**。受测 93 个源码/资源文件前后完全一致；独立 Cloud 真实 Torch 环境在本次前后完整指纹一致。这不是托管 CI 结论、生产学习收益或采用证明。

## 共同候选与受测范围

- M5 commit：`953d548d25b1e050109b1b93e1ea474b2ac7c801`
- M5 tree：`268a17afd9cb6e268ab3ba50541f2bbc6310998c`
- parent：`34041fbbb8fc6dcb716853973c848ed41cdec331`
- 原生精确 Git 核对来自 `/home/qian-qi/work/cell-continuation-20261109-08b6/canonical-source`；当时工作树 HEAD 为 M5、status 为空。
- 93 个文件，共 1,168,871 bytes，逐项核对 Git mode/blob ID、字节数和 SHA256；映射 SHA256 为 `25f1894c1e981a172b2d2ba4292f99d3993d6c74ecbce2074c0a887ddf53a57a`。
- 实际运行目录为 `/workspace/scratch/08b6dd5f2d10/continuation-lifecycle/m5-python/source-subset`，从既有源副本复制后重新绑定 M5 Git 对象；没有借用 M4 的通过结果。
- `SOURCE_MANIFEST.json` 与 `source-subset/` 完整列出并保留此次输入。**这是 93 文件受测子集，不是完整仓库归档**；共同完整源码由根任务另行归档。

## 实际执行

命令均为真实 venv Python 的 `-B -m unittest -v`，完整模块名、cwd、环境覆盖、开始/结束时间及原始 stdout/stderr 位于 `final-suite-001/`。监督器实际子进程的保留记录位于其 `supervisor-raw/`。

| 组 | 测试数 | skip | exit | 命令 wall 秒 |
|---|---:|---:|---:|---:|
| `joint-config` | 23 | 0 | 0 | 4.707569 |
| `state-codec` | 6 | 0 | 0 | 8.943986 |
| `subprocess-supervisor` | 8 | 0 | 0 | 2.740271 |
| `training-result` | 14 | 0 | 0 | 3.539141 |
| `source-archive` | 13 | 0 | 0 | 1.548011 |
| `pred-training-diagnosis` | 14 | 0 | 0 | 0.267825 |
| `repo-mdv` | 13 | 0 | 0 | 0.617136 |
| 合计 | 91 | 0 | 全部 0 | 见外层费用 |

开始 `2026-11-09T04:11:12.875050+00:00`，结束 `2026-11-09T04:11:35.279329+00:00`。外层测试 wall **22.405946905 秒**，已回收子进程 CPU **17.534845 秒**。各命令/测试内部耗时包含在外层内，不重复相加。

## 真实运行环境

- Linux-6.18.57-x86_64-with-glibc2.39；Python `3.12.14`。
- Torch `2.9.1+cpu` CPU、NumPy `1.26.4`、Pillow `12.0.0`；实际导入和张量运算成功，CUDA 为 null。未使用 stub 或为缺依赖跳过测试。
- 使用原私有 venv `/workspace/scratch/08b6dd5f2d10/continuation-lifecycle/m3-python/venv`，本次没有重新安装。`runtime-freeze.stdout` 保留完整实际依赖版本。
- 本次前后核对 17,139 个 venv 文件/符号链接目标、997,330,764 regular bytes，并单独绑定基础 Python 可执行文件；全部一致。外部标准库和系统动态库未做完整机器镜像归档。
- 相较 M4 后置指纹，新增 1,530 个 `.pyc` 缓存，原有文件零删除、零字节变化；本次新增缓存已纳入独立前后指纹。缓存准备成本未知，**不宣称冷缓存**。

## 准备、失败与费用边界

- 精确 Git readback 远程操作 `1a1be7cf239-5e21-11b` 最终为 succeeded/exit 0，stdout 1,123 bytes、无截断。首次 MCP 调用超时；相同请求/key 的 reconcile 返回 reused=true，未重发不同操作。
- 初始控制器使用不可用 `structuredClone` 的错误发生在远程调用前；首次 MCP 错误文本又触发一次本地 JSON 解析错误。原始失败保存在 `INITIAL_PREPARATION_FAILURES.json`，未隐藏为成功。
- 实际本地复制/运行时导入准备 1.847831465 秒（其中导入 1.819122705 秒，包含关系）；原生精确绑定 0.183863261 秒。
- 环境指纹前置 6.443445499 秒、后置 2.655608763 秒；freeze 0.032740064 秒，均为测试外独立窗口。
- 原有环境安装原日志保留在 `historical-runtime-setup-not-rerun/`，明确为历史准备，不是本次重新执行。工具传输/等待、缓存准备、峰值内存、能耗、收费及原 rog 011 未知成本未完整测量；不声称完整端到端费用。
- 原 rog 安装 job011 仍为 UNKNOWN，未触碰或重放。

## 结论用途与限制

本次是冻结共同源码的工程回归。state-codec 使用真实 Torch；监督器使用真实 POSIX 子进程。协议/训练结果测试含既有合成 fixture，MDV 的 13 项是控制回归，不作为真实独立任务学习增益。PRED 仅执行既有诊断单测，未重跑确认集或改变 HOLD。生产 owner、独立评价/采用与普通后继任务收益不由这 91 项证明。

发布 head、最终托管 CI 与实际 checkout 身份须由后续独立回执说明；此文不声明新 PR 已发布或 CI 已绿。M4 证据包和报告保持原样。
