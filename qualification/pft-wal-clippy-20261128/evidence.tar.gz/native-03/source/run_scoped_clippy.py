"""Finish independent strict gates after the unmodified multi-package gate SIGKILL."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/5bdf905e9cad/hepta-pft-wal')
OUT = Path(__file__).resolve().parent / 'native-03'
SOURCE = 'b9be1a277bf664eb4be5fbf39868e74509136edd'
TOOLS = Path('/workspace/scratch/5bdf905e9cad/opaque-native-toolchain')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resources():
    return dict(
        meminfo=Path('/proc/meminfo').read_text(),
        oom_kill=[line for line in Path('/proc/vmstat').read_text().splitlines() if line.startswith('oom_kill ')],
        process_limits=Path('/proc/self/limits').read_text(),
        workspace_free_bytes=shutil.disk_usage(ROOT).free,
        tmp_free_bytes=shutil.disk_usage('/tmp').free,
    )


def main():
    if git('rev-parse', 'HEAD') != SOURCE or git('status', '--porcelain'):
        raise ValueError('candidate must remain frozen and clean')
    OUT.mkdir(exist_ok=False)
    settings = dict(
        CARGO_HOME='/workspace/scratch/5bdf905e9cad/chain-cargo',
        CARGO_TARGET_DIR='/tmp/hepta-opaque-native-target',
        CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_INCREMENTAL='0',
        BINDGEN_EXTRA_CLANG_ARGS='-isystem /usr/lib/gcc/x86_64-linux-gnu/14/include',
    )
    env = {**os.environ, **settings, 'PATH': os.pathsep.join([
        str(TOOLS / 'installed/bin'), str(TOOLS / 'buildenv/bin'),
        '/workspace/scratch/5bdf905e9cad/learning-tools/bin', os.environ.get('PATH', ''),
    ])}
    commands = [
        ['cargo', 'clippy', '--manifest-path', 'codex-rs/Cargo.toml', '--locked',
         '-p', 'codex-hepta-cell-roles', '--all-targets', '--', '-D', 'warnings'],
        ['cargo', 'clippy', '--manifest-path', 'codex-rs/Cargo.toml', '--locked',
         '-p', 'codex-hepta-bellman-operator', '--all-targets', '--features', 'compatibility-api',
         '--', '-D', 'warnings'],
    ]
    files = ['codex-rs/hepta-cell-roles/src/control_wal.rs', 'codex-rs/Cargo.lock',
             'codex-rs/.config/nextest.toml', 'scripts/run-nextest.py', 'justfile',
             'qualification/pft-wal-clippy-20261128/PROTOCOL.json']
    hashes = {path: sha(ROOT / path) for path in files}
    for path in files:
        destination = OUT / 'source' / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / path, destination)
    shutil.copyfile(__file__, OUT / 'source/run_scoped_clippy.py')
    frozen = dict(
        source_commit=SOURCE, source_tree=git('rev-parse', 'HEAD^{tree}'),
        inputs_sha256=hashes, commands=commands, environment=settings,
        rustc=subprocess.check_output([str(TOOLS / 'installed/bin/rustc'), '-Vv'], text=True),
        protocol='Both strict commands retain --locked --all-targets -- -D warnings; no test or CI deadline changed.',
        reason='The original multi-package gate ended at codex-protocol SIGKILL, before this WAL crate. These are independent gates, not a replacement PASS for the original gate.',
        previous_original_gate='native-02/02.log', tests_rerun_after_format=False,
        runner_sha256=sha(Path(__file__)), resources_before=resources(),
    )
    (OUT / 'FROZEN.json').write_text(json.dumps(frozen, indent=2) + '\n')
    results = []
    for index, command in enumerate(commands, 1):
        start = time.monotonic()
        logfile = OUT / f'{index:02d}.log'
        before = resources()
        print(json.dumps(dict(stage=index, command=command, event='started')), flush=True)
        with logfile.open('wb') as stream:
            process = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                       stdout=stream, stderr=subprocess.STDOUT)
            _, wait_status, usage = os.wait4(process.pid, 0)
            status = os.waitstatus_to_exitcode(wait_status)
            process.returncode = status
        resource_file = OUT / f'{index:02d}.resources.json'
        native_usage = {name: getattr(usage, name) for name in (
            'ru_utime', 'ru_stime', 'ru_maxrss', 'ru_minflt', 'ru_majflt',
            'ru_inblock', 'ru_oublock', 'ru_nvcsw', 'ru_nivcsw',
        )}
        resource_file.write_text(json.dumps(native_usage, indent=2) + '\n')
        row = dict(stage=index, command=command, exit_code=status,
                   wall_seconds=time.monotonic()-start, log=logfile.name,
                   log_bytes=logfile.stat().st_size, log_sha256=sha(logfile),
                   resources_log=resource_file.name, resources_before=before, resources_after=resources())
        results.append(row)
        (OUT / 'COMMANDS.json').write_text(json.dumps(results, indent=2) + '\n')
        print(json.dumps({key: row[key] for key in ('stage', 'exit_code', 'wall_seconds', 'log_sha256')}), flush=True)
    unchanged = (git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain')
                 and hashes == {path: sha(ROOT / path) for path in files})
    report = dict(source_commit=SOURCE, all_scoped_commands_passed=all(row['exit_code'] == 0 for row in results),
                  original_multi_package_gate_passed=False, source_unchanged=unchanged, results=results)
    (OUT / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key != 'results'}), flush=True)
    raise SystemExit(not (report['all_scoped_commands_passed'] and unchanged))


if __name__ == '__main__':
    main()
