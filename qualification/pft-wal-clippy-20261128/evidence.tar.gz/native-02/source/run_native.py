"""Execute the frozen WAL candidate under the existing, unchanged native gates."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/5bdf905e9cad/hepta-pft-wal')
OUT = Path(__file__).resolve().parent/'native-02'
SOURCE = 'b9be1a277bf664eb4be5fbf39868e74509136edd'
TOOLS = Path('/workspace/scratch/5bdf905e9cad/opaque-native-toolchain')


def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resources():
    memory = Path('/proc/meminfo').read_text()
    oom = [line for line in Path('/proc/vmstat').read_text().splitlines() if line.startswith('oom_kill ')]
    return dict(meminfo=memory, oom_kill=oom, process_limits=Path('/proc/self/limits').read_text(),
                workspace_free_bytes=shutil.disk_usage(ROOT).free,
                tmp_free_bytes=shutil.disk_usage('/tmp').free)


def main():
    if git('rev-parse','HEAD') != SOURCE or git('status','--porcelain'):
        raise ValueError('candidate must be frozen and clean')
    OUT.mkdir(exist_ok=False)
    inputs = ['codex-rs/hepta-cell-roles/src/control_wal.rs', 'codex-rs/Cargo.lock',
              'codex-rs/.config/nextest.toml', 'scripts/run-nextest.py', 'justfile',
              'qualification/pft-wal-clippy-20261128/PROTOCOL.json']
    fingerprints = {path:sha(ROOT/path) for path in inputs}
    for path in inputs:
        saved = OUT/'source'/path
        saved.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(ROOT/path,saved)
    commands = [
        ['just','test','-p','codex-hepta-cell-roles','--lib','--locked'],
        ['cargo','clippy','--manifest-path','codex-rs/Cargo.toml','--locked',
         '-p','codex-hepta-bellman-operator','-p','codex-hepta-agentd','-p','codex-hepta-shadow-qualification',
         '--all-targets','--','-D','warnings'],
        ['cargo','clippy','--manifest-path','codex-rs/Cargo.toml','--locked',
         '-p','codex-hepta-bellman-operator','--all-targets','--features','compatibility-api','--','-D','warnings'],
    ]
    settings = dict(
        CARGO_HOME='/workspace/scratch/5bdf905e9cad/chain-cargo',
        CARGO_TARGET_DIR='/tmp/hepta-opaque-native-target',
        CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_INCREMENTAL='0',
        BINDGEN_EXTRA_CLANG_ARGS='-isystem /usr/lib/gcc/x86_64-linux-gnu/14/include',
    )
    env = {**os.environ, **settings,
           'PATH':os.pathsep.join([str(TOOLS/'installed/bin'),str(TOOLS/'buildenv/bin'),
                                   '/workspace/scratch/5bdf905e9cad/learning-tools/bin',os.environ.get('PATH','')])}
    frozen = dict(source_commit=SOURCE,source_tree=git('rev-parse','HEAD^{tree}'),
                  inputs_sha256=fingerprints,commands=commands,environment=settings,
                  rustc=subprocess.check_output([str(TOOLS/'installed/bin/rustc'),'-Vv'],text=True),
                  protocol='Existing repo deadlines and retry settings retained; no test or CI gate is weakened.',
                  original_ci_job_budget_minutes=180,
                  outer_watchdog_change=None,tests_rerun_after_format=False,
                  runner_sha256=sha(Path(__file__)), resources_before=resources(),
                  resource_collector='Linux os.wait4 child rusage; no extra timing binary',
                  setup_retry_of='native-01: /usr/bin/time absent; no build/test had started')
    (OUT/'FROZEN.json').write_text(json.dumps(frozen,indent=2)+'\n')
    junit = Path(settings['CARGO_TARGET_DIR'])/'nextest/local/junit.xml'
    if junit.is_file():
        shutil.copyfile(junit,OUT/'borrowed-cache-junit-before.xml')
    began = time.monotonic()
    results=[]
    for index, command in enumerate(commands,1):
        start=time.monotonic()
        logfile=OUT/f'{index:02d}.log'
        resource_file=OUT/f'{index:02d}.resources.json'
        before=resources()
        print(json.dumps({'stage':index,'command':command,'event':'started'}),flush=True)
        with logfile.open('wb') as stream:
            process=subprocess.Popen(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT)
            _,wait_status,usage=os.wait4(process.pid,0)
            status=os.waitstatus_to_exitcode(wait_status)
            process.returncode=status
        native_usage={name:getattr(usage,name) for name in ('ru_utime','ru_stime','ru_maxrss','ru_minflt','ru_majflt','ru_inblock','ru_oublock','ru_nvcsw','ru_nivcsw')}
        resource_file.write_text(json.dumps(native_usage,indent=2)+'\n')
        row=dict(stage=index,command=command,exit_code=status,wall_seconds=time.monotonic()-start,
                 log=logfile.name,log_bytes=logfile.stat().st_size,log_sha256=sha(logfile),
                 resources_log=resource_file.name,resources_before=before,resources_after=resources())
        if index == 1 and junit.is_file():
            shutil.copyfile(junit,OUT/'01-junit.xml')
        results.append(row)
        print(json.dumps(row),flush=True)
        (OUT/'COMMANDS.json').write_text(json.dumps(results,indent=2)+'\n')
        if status:
            break
    source_unchanged = git('rev-parse','HEAD')==SOURCE and not git('status','--porcelain') and fingerprints=={path:sha(ROOT/path) for path in inputs}
    report=dict(source_commit=SOURCE,commands_completed=len(results),all_commands_passed=len(results)==3 and all(row['exit_code']==0 for row in results),source_unchanged=source_unchanged,total_wall_seconds=time.monotonic()-began,results=results)
    (OUT/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)
    raise SystemExit(not (report['all_commands_passed'] and source_unchanged))


if __name__ == '__main__':
    main()
