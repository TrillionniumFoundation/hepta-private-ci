"""Independent coordinate arithmetic/source review for graded variational arrays."""

import ast
import hashlib
import json
from pathlib import Path
import sys
import tarfile

import numpy as np


def identity(path):
    raw=Path(path).read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def main(root,output):
    root=Path(root);e=root/'qualification/hcsn_joint_dde/evidence/graded-physical-20261112'
    paths=[e/'ARRAYS-002.json',e/'TESTED-SOURCES.tar.gz',Path(__file__)]
    before={str(p):identity(p) for p in paths}
    record=json.loads(paths[0].read_bytes())
    with tarfile.open(paths[1]) as archive:
        preserved={item.name:archive.extractfile(item).read() for item in archive.getmembers() if item.isfile()}
    relations={}
    for name,expected in record['sources'].items():
        relative='qualification/'+name;raw=preserved[relative];current=root/relative
        if hashlib.sha256(raw).hexdigest()!=expected:
            raise ValueError('exact tested source bytes missing')
        if ast.dump(ast.parse(raw),include_attributes=False)!=ast.dump(ast.parse(current.read_bytes()),include_attributes=False):
            raise ValueError('tested-to-published AST changed')
        relations[name]={'tested_sha256':expected,'current_sha256':identity(current)['sha256'],
                         'exact_tested_bytes_preserved':True,'normalized_AST_equal':True}
        before[str(current)]=identity(current)
    expected={(case,parameter) for case in ('graded_point','graded_atom','graded_uniform','training_range_profile')
              for parameter in ('log_boundary','mu','sigma','absolute_reset','discount')}
    if len(record['cases'])!=20 or {(c['case'],c['parameter']) for c in record['cases']}!=expected:
        raise ValueError('full new-geometry physical roster required')
    max_abs=max_ratio=max_stability=max_stability_ratio=0.;undefined=tiny=0;coordinate_rows=[]
    for case in record['cases']:
        expected_count=138 if case['case']=='training_range_profile' else 63
        jac=np.array(case['variational']);coarse=np.array(case['coarse_fd']);fine=np.array(case['fine_fd'])
        if any(value.shape!=(expected_count,) for value in (jac,coarse,fine)) or not np.isfinite([jac,coarse,fine]).all():
            raise ValueError('array extent or finite values differ')
        if case['steps']!=[2e-4,1e-4]:raise ValueError('declared FD steps differ')
        all_errors=[]
        for fd in (coarse,fine):
            error=abs(jac-fd);limit=record['absolute_tolerance']+record['relative_tolerance']*abs(fd)
            if np.any(error>limit):raise ValueError('physical FD gate failure')
            max_ratio=max(max_ratio,float(max(error/limit)));all_errors.append(error)
        if max(all_errors[1])!=case['maximum_absolute_error']:raise ValueError('stored maximum differs')
        stability=abs(coarse-fine);stability_limit=5e-6+6e-4*abs(fine)
        if np.any(stability>stability_limit):raise ValueError('coarse/fine stability gate failure')
        max_abs=max(max_abs,float(max(all_errors[1])));max_stability=max(max_stability,float(max(stability)))
        max_stability_ratio=max(max_stability_ratio,float(max(stability/stability_limit)))
        undefined+=int(np.sum(fine==0));tiny+=int(np.sum(abs(fine)<record['absolute_tolerance']))
        coordinate_rows.extend({'case':case['case'],'parameter':case['parameter'],'coordinate':i,
            'absolute_error':float(all_errors[1][i]),'fine_tolerance_ratio':float(all_errors[1][i]/(record['absolute_tolerance']+record['relative_tolerance']*abs(fine[i]))),
            'ordinary_relative_error':None if fine[i]==0 else float(all_errors[1][i]/abs(fine[i]))} for i in range(expected_count))
    if len(coordinate_rows)!=1635 or before!={str(p):identity(p) for p in map(Path,before)}:
        raise ValueError('complete coverage or source stability differs')
    result={'schema':'hcsn-independent-graded-physical-array-review-v1','inputs':before,'source_relations':relations,
            'coordinates':coordinate_rows,'coordinate_count':len(coordinate_rows),'fine_gate_failures':0,'coarse_gate_failures':0,
            'maximum_fine_absolute_error':max_abs,'maximum_coarse_or_fine_tolerance_ratio':max_ratio,
            'maximum_coarse_fine_absolute_difference':max_stability,'maximum_stability_tolerance_ratio':max_stability_ratio,
            'undefined_relative_ratios':undefined,'fine_FD_below_absolute_tolerance':tiny,
            'maximum_ordinary_relative_error':max(r['ordinary_relative_error'] for r in coordinate_rows if r['ordinary_relative_error'] is not None),
            'scope':'retained new-graded arrays/source review only; no new model/optimizer execution, no automatic n512/migrated-prior or full network AD admission'}
    with Path(output).open('x') as out:json.dump(result,out,indent=2,sort_keys=True,allow_nan=False);out.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('inputs','source_relations','coordinates')},sort_keys=True))


if __name__=='__main__':main(*sys.argv[1:])
