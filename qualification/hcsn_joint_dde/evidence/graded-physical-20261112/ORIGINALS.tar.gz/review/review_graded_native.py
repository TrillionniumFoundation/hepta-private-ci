"""Read-only graded native PT recovery, live-VJP and Adam evidence review."""

import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np

from review_native_checkpoints import read,compare,identity


def main(root,output):
    root=Path(root);e=root/'qualification/hcsn_joint_dde/evidence/graded-physical-20261112'
    native=e/'native001';data=native/'native-result'
    index=json.loads((native/'FILES.json').read_bytes())
    inputs={};members={}
    for item in index['files']:
        path=(native/item['path']).resolve()
        if not path.is_relative_to(native.resolve()) or item['path'] in members:
            raise ValueError('archive member path or uniqueness differs')
        expected={'bytes':item['bytes'],'sha256':item['sha256']}
        if identity(path)!=expected:raise ValueError('native original member differs')
        inputs[str(path)]=expected;members[item['path']]=expected
    if len(members)!=22:raise ValueError('complete 22 original data members required')
    states={}
    for name in ('continuous','first','resumed','source-mismatch','runtime-mismatch'):
        path=data/(name+'.pt' if 'mismatch' in name else name+'/state.pt')
        states[name],_=read(path)
    tensors=compare(states['continuous'],states['resumed'])
    first=states['first']
    for name,field,key,value in (
        ('source-mismatch','sources','hcsn_joint_dde/torch_physical.py','0'*64),
        ('runtime-mismatch','runtime','python','different runtime'),
    ):
        altered=dict(first[field]);altered[key]=value
        if states[name][field]!=altered:raise ValueError('negative-control mutation differs')
        repaired=dict(states[name]);repaired[field]=first[field];compare(first,repaired)
    numerical=json.loads((e/'ARRAYS-002.json').read_bytes())
    cases={row['parameter']:row for row in numerical['cases'] if row['case']=='graded_point'}
    native_report=json.loads((data/'RESULT.json').read_bytes())
    records=native_report['records']
    if native_report['geometry']!='graded' or not all(native_report[name] for name in
        ('gradcheck','parameter_version_guard','unsafe_data_mutation_guard','runtime_mismatch_refused','source_mismatch_refused')):
        raise ValueError('new geometry or declared controls not passed')
    for name in ('continuous','first','resumed'):
        state=states[name];result=json.loads((data/name/'RESULT.json').read_bytes())
        if (state['records']!=result['records'] or state['sources']!=result['source_sha256']
                or state['step']!=result['step'] or state['binding']['geometry']!='graded'
                or identity(data/name/'state.pt')['sha256']!=result['checkpoint_sha256']):
            raise ValueError('checkpoint/actor record or binding differs')
    compare(states['first']['records'],records[:1])
    if states['continuous']['records']!=records or states['continuous']['step']!=2 or states['first']['step']!=1:
        raise ValueError('actual step coverage differs')
    # Raw graded arrays contain three channels. Select probability M/H/A;
    # convert Vr chain from exp(.53) to native exp(.54), retaining reset .53.
    select=[51,54,57]
    features=np.array(cases['mu']['primal'])[select]
    params=('log_boundary','mu','sigma','absolute_reset','discount')
    jac=np.column_stack([np.array(cases[name]['variational'])[select] for name in params]);jac[:,3]*=math.exp(-.01)
    gradient=(2/3)*(features-np.array(records[0]['target']))@jac
    gradient_difference=float(max(abs(gradient-np.array(records[0]['gradient']))))
    if gradient_difference>2e-8:raise ValueError('first live loss VJP differs from raw variational arrays')
    theta=np.array([.01,-.12,.5,math.exp(.54),.15]);moment=np.zeros(5);variance=np.zeros(5);updates=[]
    for step,row in enumerate(records,1):
        g=np.array(row['gradient']);moment=.9*moment+.1*g;variance=.999*variance+.001*g*g
        theta-=5e-5*(moment/(1-.9**step))/(np.sqrt(variance/(1-.999**step))+1e-8)
        difference=float(max(abs(theta-np.array(row['parameters']))))
        if difference>1e-15:raise ValueError('actual Adam parameter update arithmetic differs')
        updates.append({'step':step,'parameter_update_maximum_error':difference})
    final=states['continuous']
    if not np.array_equal(final['parameters'].data,np.array(records[-1]['parameters'])):
        raise ValueError('actual PT parameters differ from records')
    opt=final['optimizer']['state'][0]
    m_error=float(max(abs(opt['exp_avg'].data-moment)));v_error=float(max(abs(opt['exp_avg_sq'].data-variance)))
    if m_error>1e-15 or v_error>1e-15 or opt['step'].data.item()!=2:
        raise ValueError('actual Adam moments or step differ')
    if inputs!={path:identity(path) for path in map(Path,inputs)}:
        # Dictionary keys are strings in the original readback.
        after={str(path):identity(path) for path in map(Path,inputs)}
        if inputs!=after:raise ValueError('native inputs changed during review')
    result={'schema':'hcsn-independent-graded-native-recovery-review-v1','input_identities':inputs,
        'continuous_resumed_full_state_exact':True,'tensor_count':len(tensors),'tensor_metadata':tensors,
        'runtime_and_fixed_input_binding_exact':True,'negative_source_and_runtime_only_mutations_verified':True,
        'first_loss_VJP_from_original_graded_arrays':gradient.tolist(),'first_loss_VJP_maximum_absolute_difference':gradient_difference,
        'adam_updates':updates,'actual_first_moment_maximum_error':m_error,'actual_second_moment_maximum_error':v_error,
        'new_model_executions':0,'new_optimizer_calls':0,'torch_imported':False,
        'scope':'graded n16/L2/stretch4 fixed-prior five-parameter diagnostic only; no n512 migrated-law or new near-boundary v3 AD/training qualification'}
    with Path(output).open('x') as out:json.dump(result,out,indent=2,sort_keys=True,allow_nan=False);out.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('input_identities','tensor_metadata')},sort_keys=True))


if __name__=='__main__':main(*sys.argv[1:])
