"""Strict non-executing reader for these pinned small Torch ZIP checkpoints.

Only Tensor-v2 reconstruction metadata, three primitive storage tags and empty
OrderedDict hooks are admitted. No torch import, arbitrary pickle globals,
model execution or optimizer invocation occurs.
"""

import argparse
from collections import OrderedDict
from dataclasses import dataclass
import hashlib
import io
import json
from pathlib import Path
import pickle
import zipfile

import numpy as np


@dataclass(frozen=True)
class StorageTag:
    name: str
    dtype: str


@dataclass
class Storage:
    tag: StorageTag
    key: str
    elements: int
    data: bytes


@dataclass
class Tensor:
    dtype: str
    shape: tuple
    stride: tuple
    offset: int
    requires_grad: bool
    data: np.ndarray


def rebuild_tensor(storage,offset,shape,stride,requires_grad,hooks,metadata=None):
    if (not isinstance(storage,Storage) or type(offset) is not int or offset<0
            or type(shape) is not tuple or type(stride) is not tuple or len(shape)!=len(stride)
            or len(shape)>16 or any(type(x) is not int or x<0 for x in shape+stride)
            or type(requires_grad) is not bool or hooks not in (None,OrderedDict())
            or metadata is not None):
        raise ValueError('unsupported tensor reconstruction metadata')
    extent=offset+sum((size-1)*step for size,step in zip(shape,stride) if size)
    if extent>=storage.elements or np.prod(shape,dtype=np.int64)>1_000_000:
        raise ValueError('tensor storage bounds exceeded')
    raw=np.frombuffer(storage.data,dtype=np.dtype(storage.tag.dtype))
    view=np.lib.stride_tricks.as_strided(raw[offset:],shape=shape,
        strides=tuple(x*raw.itemsize for x in stride),writeable=False)
    return Tensor(storage.tag.name,shape,stride,offset,requires_grad,view.copy())


class Reader(pickle.Unpickler):
    def __init__(self,archive,prefix,payload):
        super().__init__(io.BytesIO(payload));self.archive=archive;self.prefix=prefix;self.storages={}

    def find_class(self,module,name):
        allowed={('torch._utils','_rebuild_tensor_v2'):rebuild_tensor,
                 ('collections','OrderedDict'):OrderedDict,
                 ('torch','DoubleStorage'):StorageTag('float64','<f8'),
                 ('torch','FloatStorage'):StorageTag('float32','<f4'),
                 ('torch','ByteStorage'):StorageTag('uint8','u1')}
        if (module,name) not in allowed:raise ValueError('unsupported pickle global')
        return allowed[module,name]

    def persistent_load(self,item):
        if (type(item) is not tuple or len(item)!=5 or item[0]!='storage'
                or not isinstance(item[1],StorageTag) or type(item[2]) is not str
                or not item[2].isdigit() or item[3]!='cpu' or type(item[4]) is not int
                or not 0<item[4]<=1_000_000):
            raise ValueError('unsupported Torch storage descriptor')
        _,tag,key,_,count=item
        raw=self.archive.read(self.prefix+'data/'+key)
        if len(raw)!=count*np.dtype(tag.dtype).itemsize:raise ValueError('storage extent differs')
        value=Storage(tag,key,count,raw)
        if key in self.storages and self.storages[key]!=value:raise ValueError('storage alias descriptor differs')
        self.storages[key]=value
        return value


def identity(path):
    raw=path.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def read(path):
    if not 0<path.stat().st_size<1_000_000:raise ValueError('small pinned checkpoint required')
    with zipfile.ZipFile(path) as archive:
        infos=archive.infolist();names=[entry.filename for entry in infos]
        if len(names)!=len(set(names)) or sum(entry.file_size for entry in infos)>1_000_000:
            raise ValueError('duplicate or oversized ZIP members')
        data=[name for name in names if name.endswith('/data.pkl')]
        if len(data)!=1:raise ValueError('one Torch data pickle required')
        prefix=data[0][:-len('data.pkl')]
        if archive.read(prefix+'byteorder')!=b'little':raise ValueError('unsupported byteorder')
        parser=Reader(archive,prefix,archive.read(data[0]));value=parser.load()
        return value,len(parser.storages)


def compare(left,right,path='root',tensors=None):
    tensors=[] if tensors is None else tensors
    if type(left) is not type(right):raise ValueError('metadata type differs at '+path)
    if isinstance(left,Tensor):
        for name in ('dtype','shape','stride','offset','requires_grad'):
            if getattr(left,name)!=getattr(right,name):raise ValueError('tensor metadata differs at '+path)
        if not np.array_equal(left.data,right.data):raise ValueError('tensor value differs at '+path)
        tensors.append({'path':path,'dtype':left.dtype,'shape':list(left.shape),'stride':list(left.stride),
                        'storage_offset':left.offset,'requires_grad':left.requires_grad,
                        'logical_bytes_sha256':hashlib.sha256(left.data.tobytes()).hexdigest()})
    elif isinstance(left,dict):
        if left.keys()!=right.keys():raise ValueError('dict keys differ at '+path)
        for key in left:compare(left[key],right[key],path+'/'+str(key),tensors)
    elif isinstance(left,(tuple,list)):
        if len(left)!=len(right):raise ValueError('sequence length differs at '+path)
        for index,(a,b) in enumerate(zip(left,right)):compare(a,b,path+'/'+str(index),tensors)
    elif type(left) in (int,float,bool,str,type(None)):
        if left!=right:raise ValueError('metadata value differs at '+path)
    else:raise ValueError('unsupported metadata type at '+path)
    return tensors


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args();receipt=json.loads((args.root/'BINARY-READBACK.json').read_bytes())
    states={};identities={};storage_counts={}
    for name in ('continuous','first','resumed','source-mismatch'):
        path=args.root/(name+'.pt' if name=='source-mismatch' else name+'/state.pt')
        observed=identity(path);expected=receipt['files'][name]
        if observed!={'bytes':expected['size'],'sha256':expected['chunk_sha256']} or not expected['eof']:
            raise ValueError('pinned original bytes differ: '+name)
        identities[name]=observed;states[name],storage_counts[name]=read(path)
    tensors=compare(states['continuous'],states['resumed'])
    for name in ('continuous','first','resumed'):
        result=json.loads((args.root/name/'RESULT.json').read_bytes())
        state=states[name]
        if state['schema']!='hcsn-fixed-prior-physical-adam-v1':raise ValueError('checkpoint schema differs')
        if state['step']!=result['step'] or state['records']!=result['records'] or state['sources']!=result['source_sha256']:
            raise ValueError('checkpoint/result metadata differs: '+name)
        if identities[name]['sha256']!=result['checkpoint_sha256']:raise ValueError('result checkpoint hash differs')
        if not np.array_equal(state['parameters'].data,np.array(state['records'][-1]['parameters'])):
            raise ValueError('actual saved parameters differ from update records')
        if state['optimizer']['state'][0]['step'].data.item()!=state['step']:
            raise ValueError('Adam internal step differs')
    if states['first']['step']!=1 or states['continuous']['step']!=2:raise ValueError('two-step recovery coverage differs')
    compare(states['first']['records'],states['continuous']['records'][:1])
    expected_damaged=dict(states['first']['sources']);expected_damaged['hcsn_joint_dde/torch_physical.py']='0'*64
    if states['source-mismatch']['sources']!=expected_damaged:raise ValueError('negative control source mutation differs')
    repaired=dict(states['source-mismatch']);repaired['sources']=states['first']['sources']
    compare(states['first'],repaired)
    for name in identities:
        path=args.root/(name+'.pt' if name=='source-mismatch' else name+'/state.pt')
        if identity(path)!=identities[name]:raise ValueError('checkpoint changed while reviewing')
    report={'schema':'hcsn-independent-native-full-state-review-v1','identities':identities,
            'continuous_resumed_full_state_exact':True,'tensor_count':len(tensors),'tensors':tensors,
            'primitive_storage_count_per_checkpoint':storage_counts,'model_parameters_exact':True,
            'adam_first_second_moments_and_step_exact':True,'rng_bytes_exact':True,'records_metadata_exact':True,
            'first_checkpoint_matches_step1':True,'negative_control_changes_only_source_digest':True,
            'new_optimizer_calls':0,'new_model_executions':0,'torch_imported':False,
            'snapshot_scope':'four individually hash-bound originals; no atomic cross-file custody assertion',
            'scope':'small fixed-prior uniform-grid physical Adam diagnostic; no complete HCSN training or graded/prior/network AD qualification'}
    with args.output.open('x') as out:json.dump(report,out,indent=2,sort_keys=True,allow_nan=False);out.write('\n')
    print(json.dumps(report,sort_keys=True,allow_nan=False))


if __name__=='__main__':main()
