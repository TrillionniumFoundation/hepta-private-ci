"""Read-only independent arithmetic admission of physical-Jacobian arrays."""

import argparse
import ast
import hashlib
import json
from pathlib import Path
import tarfile

import numpy as np


def digest(path):
    data=Path(path).read_bytes()
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('arrays',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--tested-bundle',type=Path)
    parser.add_argument('--preformat-ast',type=Path)
    args=parser.parse_args()
    original=digest(args.arrays)
    report=json.loads(args.arrays.read_bytes())
    sources=report['source_sha256']
    current_sources={path:digest(path) for path in sources}
    format_relations={}
    snapshots={} if args.preformat_ast is None else json.loads(args.preformat_ast.read_bytes())
    preserved={} 
    if args.tested_bundle is not None:
        with tarfile.open(args.tested_bundle) as archive:
            for member in archive.getmembers():
                if member.isfile():preserved[member.name]=archive.extractfile(member).read()
    for path,expected_sha in sources.items():
        current=current_sources[path]['sha256']
        if current==expected_sha:
            format_relations[path]={'tested_sha256':expected_sha,'current_sha256':current,'verification':'exact_bytes'}
            continue
        relative='qualification/'+path.split('/qualification/',1)[1]
        current_ast=ast.dump(ast.parse(Path(path).read_bytes()),include_attributes=False)
        raw=preserved.get(relative)
        if raw is not None and hashlib.sha256(raw).hexdigest()==expected_sha and ast.dump(ast.parse(raw),include_attributes=False)==current_ast:
            mode='exact_tested_bytes_in_bundle_and_identical_normalized_AST'
        elif snapshots.get(relative,{}).get('sha256')==expected_sha and snapshots[relative]['ast']==current_ast:
            mode='matching_preserved_normalized_AST_only_original_bytes_not_retained'
        else:
            raise ValueError('declared executing source is not the current reviewed snapshot')
        format_relations[path]={'tested_sha256':expected_sha,'current_sha256':current,'verification':mode}
    if not report['source_unchanged']:raise ValueError('producer source mutation declared')
    expected={(case,parameter) for case in ('point','atom','uniform') for parameter in
              ('log_boundary','mu','sigma','absolute_reset','discount')}
    actual={(row['case'],row['parameter']) for row in report['cases']}
    if actual!=expected or len(report['cases'])!=15:
        raise ValueError('complete physical coordinate roster required')
    coordinates=[]
    maximum_absolute=maximum_ratio=maximum_stability=0.
    undefined=tiny=0
    for row in report['cases']:
        jac=np.asarray(row['variational']);fine=np.asarray(row['fine_fd']);coarse=np.asarray(row['coarse_fd'])
        if jac.shape!=(39,) or fine.shape!=(39,) or coarse.shape!=(39,) or not np.isfinite([jac,fine,coarse]).all():
            raise ValueError('finite complete array dimensions required')
        difference=abs(jac-fine);stability=abs(coarse-fine)
        limit=report['absolute_tolerance']+report['relative_tolerance']*abs(fine)
        if float(max(difference))!=row['maximum_absolute_error'] or float(max(stability))!=row['coarse_fine_maximum']:
            raise ValueError('stored summary differs from original arrays')
        if np.any(difference>limit):raise ValueError('physical Jacobian gate failed')
        maximum_absolute=max(maximum_absolute,float(max(difference)))
        maximum_ratio=max(maximum_ratio,float(max(difference/limit)))
        maximum_stability=max(maximum_stability,float(max(stability)))
        undefined+=int(np.sum(fine==0));tiny+=int(np.sum(abs(fine)<report['absolute_tolerance']))
        coordinates.extend(dict(case=row['case'],parameter=row['parameter'],coordinate=i,
            absolute_error=float(difference[i]),tolerance_ratio=float(difference[i]/limit[i]),
            ordinary_relative_error=None if fine[i]==0 else float(difference[i]/abs(fine[i]))) for i in range(39))
    if digest(args.arrays)!=original or current_sources!={path:digest(path) for path in sources}:
        raise ValueError('arrays or source changed during review')
    result={'schema':'hcsn-independent-physical-partial-array-review-v2','input':original,
        'declared_executing_sources':sources,'source_and_arrays_unchanged':True,'coordinate_count':len(coordinates),
        'tested_to_formatted_source_relation':format_relations,
        'gate_failures':0,'maximum_absolute_error':maximum_absolute,'maximum_tolerance_ratio':maximum_ratio,
        'maximum_coarse_fine_difference':maximum_stability,'undefined_relative_ratios':undefined,
        'fine_FD_below_absolute_tolerance':tiny,'maximum_ordinary_relative_error':max(row['ordinary_relative_error'] for row in coordinates if row['ordinary_relative_error'] is not None),
        'coordinates':coordinates,'scope':'retained arrays recomputation; no new Torch/model execution or graded/continuum AD admission'}
    with args.output.open('x') as stream:
        json.dump(result,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('coordinates','declared_executing_sources')},sort_keys=True))


if __name__=='__main__':main()
