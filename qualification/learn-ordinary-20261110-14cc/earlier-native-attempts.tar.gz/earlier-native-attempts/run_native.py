import gzip, hashlib, json, os, pathlib, resource, subprocess, sys, time
ROOT = pathlib.Path('/home/qq/hepta-learn-ordinary-14cc-20261110')
SOURCE = ROOT / 'source'
EVIDENCE = ROOT / 'evidence'
EVIDENCE.mkdir(exist_ok=True)
name, expected, *command = sys.argv[1:]
assert name and '/' not in name and command
record_path = EVIDENCE / (name + '.json')
log_path = EVIDENCE / (name + '.log')
assert not record_path.exists() and not log_path.exists(), 'create-only attempt'
def git(*args):
 return subprocess.check_output(['git', *args], cwd=SOURCE, text=True).strip()
def snapshot():
 return {'head':git('rev-parse','HEAD'), 'tree':git('rev-parse','HEAD^{tree}'), 'status':git('status','--porcelain=v1','--untracked-files=all')}
before = snapshot()
assert before['head'] == expected and not before['status'], before
settings = {
 'PATH':'/home/qq/hepta-learning-native-4f559bf-d9fb-20261108/transfer:/home/qq/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
 'RUSTUP_HOME':'/home/qq/.rustup', 'RUSTUP_TOOLCHAIN':'1.96.0', 'CARGO_HOME':'/home/qq/.cargo',
 'LIBCLANG_PATH':'/usr/lib/llvm-21/lib', 'BINDGEN_EXTRA_CLANG_ARGS':'-isystem/usr/lib/gcc/x86_64-linux-gnu/15/include',
 'CARGO_TARGET_DIR':str(ROOT/'target'), 'CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'4',
 'CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_DEV_DEBUG':'0','CODEX_REPO_ROOT':str(SOURCE),
 'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(SOURCE/'scripts')+':'+str(SOURCE),
 'TMPDIR':str(ROOT/'tmp'),'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','RUST_MIN_STACK':'8388608'
}
(ROOT/'tmp').mkdir(exist_ok=True)
env = {**os.environ, **settings}
record = {'schema':'hepta.learn.ordinary.command.v1','name':name,'command':command,'cwd':str(SOURCE), 'source_before':before,'environment':settings,'started_unix':time.time(),'exit_code':None,'scope':'native engineering validation; no autonomous learning or scientific benefit claim'}
record['toolchain'] = {name: subprocess.check_output(args, env=env, text=True).strip() for name, args in {'rustc':['rustc','-vV'],'cargo':['cargo','--version'],'nextest':['cargo','nextest','--version'],'just':['just','--version']}.items()}
record['tool_sha256'] = {name: hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest() for name, path in {'rustc':'/home/qq/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin/rustc','cargo':'/home/qq/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin/cargo','just':'/home/qq/hepta-learning-native-4f559bf-d9fb-20261108/transfer/just'}.items()}
record_path.write_text(json.dumps(record,indent=2))
with log_path.open('xb') as log:
 process = subprocess.Popen(command, cwd=SOURCE, env=env, stdout=log, stderr=subprocess.STDOUT)
 record['pid']=process.pid
 record_path.write_text(json.dumps(record,indent=2))
 print(json.dumps({'started':name,'pid':process.pid,'log':str(log_path)}),flush=True)
 status=process.wait()
usage=resource.getrusage(resource.RUSAGE_CHILDREN)
raw=log_path.read_bytes()
record.update({'exit_code':status,'source_after':snapshot(),'completed_unix':time.time(),'stdout_sha256':hashlib.sha256(raw).hexdigest(),'stdout_bytes':len(raw),'child_user_cpu_seconds':usage.ru_utime,'child_system_cpu_seconds':usage.ru_stime,'max_rss_kib':usage.ru_maxrss})
log_path.with_suffix('.log.gz').write_bytes(gzip.compress(raw,mtime=0))
for p in [ROOT/'target/nextest/local/junit.xml',SOURCE/'codex-rs/target/nextest/local/junit.xml']:
 if p.exists() and p.stat().st_mtime >= record['started_unix']:
  data=p.read_bytes(); (EVIDENCE/(name+'.junit.xml')).write_bytes(data);record['junit_sha256']=hashlib.sha256(data).hexdigest()
record_path.write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2),flush=True)
assert record['source_after'] == before, 'source changed during native validation'
sys.exit(status)
