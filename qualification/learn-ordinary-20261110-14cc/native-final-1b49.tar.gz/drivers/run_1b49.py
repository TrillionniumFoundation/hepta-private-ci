import hashlib, pathlib, subprocess, sys
r=pathlib.Path('/home/qq/hepta-learn-ordinary-14cc-20261110')
p=r/'final-protocol-1b49.bundle'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='954486acbc580205b2a68384398829a1d96a2ddae4e1ddb0765d04b1d9814aa5'
s=r/'source'
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=s,text=True).strip()
subprocess.run(['git','fetch',str(p),'HEAD'],cwd=s,check=True)
subprocess.run(['git','checkout','--detach','1b49f8746ec48a333c34f8a00a693c18248709fb'],cwd=s,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip()=='8489fdedce2b9e7dd4df9a3854b6056fbb6ee619'
raise SystemExit(subprocess.call(['python3',str(r/'run_final_qualification.py'),'learn-final-1b49-v1','1b49f8746ec48a333c34f8a00a693c18248709fb']))
