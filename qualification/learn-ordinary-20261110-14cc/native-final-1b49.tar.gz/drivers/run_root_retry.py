"""Retry the same six actual-Root parents with CI-equivalent temp placement.

The earlier attempt is retained.  It forwarded a private /home/qq TMPDIR that
UID60001 cannot traverse, unlike the repository workflow's clean Root env.
"""

import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET


ROOT = Path("/home/qq/hepta-learn-ordinary-14cc-20261110")
SOURCE = ROOT / "source"
PRIOR = ROOT / "evidence/learn-final-1b49-v1"
RECORDS = ROOT / "evidence/learn-final-1b49-root-v2"
ROOT_DIR = Path("/run/hepta-learn-14cc-learn-final-1b49-root-v2")
EXPECTED = "1b49f8746ec48a333c34f8a00a693c18248709fb"
sys.path.insert(0, str(ROOT))
from run_final_qualification import PARENTS, digest, snapshot


def save(name, data):
    with (RECORDS / name).open("x") as output:
        json.dump(data, output, indent=2, sort_keys=True)


def main():
    RECORDS.mkdir()
    before = snapshot()
    assert before == json.loads((PRIOR / "source-before.json").read_text())
    assert before["head"] == EXPECTED and before["status"] == ""
    settings = json.loads((PRIOR / "environment.json").read_text())
    os.environ.update(settings)
    os.chdir(SOURCE)
    sys.path.insert(0, str(SOURCE / "scripts"))
    from hepta_ci_junit import collect
    save("source-before.json", before)
    save("prior-attempt.json", {"path": str(PRIOR), "ordinary_record_sha256": digest(PRIOR / "ordinary.json"),
                               "failed_root_record_sha256": digest(PRIOR / "root.json")})
    diagnostic = ["sudo", "-n", "setpriv", "--reuid=60001", "--regid=60001", "--clear-groups", "--no-new-privs",
                  "--inh-caps=-all", "--ambient-caps=-all", "--bounding-set=-all", "python3", "-I", "-B", "-c",
                  "import os,json; print(json.dumps({'uid':os.getuid(),'euid':os.geteuid(),'traverse':{p:os.access(p,os.X_OK) for p in ['/home/qq','/home/qq/hepta-learn-ordinary-14cc-20261110/tmp','/tmp']}}))"]
    observed = subprocess.run(diagnostic, capture_output=True, text=True, check=True)
    save("tmpdir-diagnosis.json", {"command": diagnostic, "exit_code": observed.returncode,
                                  "stdout": observed.stdout, "stderr": observed.stderr,
                                  "change": "omit TMPDIR from Root env-i, matching existing repository CI; keep all directory permissions unchanged"})
    parsed = json.loads(observed.stdout)
    assert parsed["uid"] == parsed["euid"] == 60001
    assert not parsed["traverse"]["/home/qq/hepta-learn-ordinary-14cc-20261110/tmp"] and parsed["traverse"]["/tmp"]
    environment = {key: value for key, value in settings.items() if key != "TMPDIR"}
    environment.update(
        GIT_CONFIG_COUNT="1", GIT_CONFIG_KEY_0="safe.directory", GIT_CONFIG_VALUE_0=str(SOURCE),
        HEPTA_HOST_AUTHORITY_QUALIFICATION_STATE_PARENT=str(ROOT_DIR / "bind"),
        HEPTA_HOST_AUTHORITY_QUALIFICATION_SOURCE=str(ROOT_DIR / "source"),
        HEPTA_CHECKPOINT_TEST_ROOT=str(ROOT_DIR / "checkpoints"),
    )
    environment.update(json.loads((PRIOR / "helpers/env.json").read_text()))
    save("root-environment.json", environment)
    save("driver-sha256.json", {"path": str(Path(__file__).resolve()), "sha256": digest(Path(__file__).resolve())})
    steps = []
    failed = None

    def run(name, args, root=False, minimum=0):
        command = ["python3", "scripts/hepta_ci_exec.py", "--timeout-seconds", "7200", "--minimum-tests", str(minimum),
                   "--output", str(RECORDS / (name + ".json")), "--", *args]
        if root:
            check = "import os,runpy,sys; assert os.getuid()==os.geteuid()==0; print('Root test uid=0',flush=True); runpy.run_path(sys.argv.pop(1),run_name='__main__')"
            command = ["sudo", "-n", "env", "-i", *(key + "=" + value for key, value in sorted(environment.items())),
                       "python3", "-c", check, *command[1:]]
        save(name + "-launch.json", {"command": command, "required_euid": 0 if root else os.geteuid()})
        with (RECORDS / (name + "-driver.log")).open("xb") as log:
            process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
            print(json.dumps({"stage": name, "pid": process.pid, "source": EXPECTED}), flush=True)
            code = process.wait()
        steps.append({"stage": name, "exit_code": code})
        return code

    def chown():
        paths = [ROOT / "target", RECORDS, SOURCE / "codex-rs/target/nextest"]
        subprocess.run(["sudo", "-n", "chown", "-R", f"{os.getuid()}:{os.getgid()}",
                        *(str(path) for path in paths if path.exists())], check=True)

    helper = ["python3", "scripts/hepta_cell_test_helpers.py", "--package", "codex-hepta-infer-worker-host",
              "--output-dir", str(PRIOR / "helpers"), "--verify-only"]
    try:
        if run("helper-before", helper):
            raise RuntimeError("same-source pinned helper changed before Root retry")
        setup = ("import os,subprocess,sys; from pathlib import Path; assert os.getuid()==os.geteuid()==0; "
                 "p=Path(sys.argv[1]); p.mkdir(mode=0o700); [(p/n).mkdir(mode=0o700) for n in ('source','bind','checkpoints')]; "
                 "subprocess.run(['mount','--bind',str(p/'source'),str(p/'bind')],check=True); print('Root fixture uid=0 path='+str(p),flush=True)")
        if run("root-setup", ["sudo", "-n", "python3", "-c", setup, str(ROOT_DIR)]):
            raise RuntimeError("Root bind fixture setup failed")
        report = SOURCE / "codex-rs/target/nextest/local/junit.xml"
        if report.exists():
            report.rename(RECORDS / "prior-junit-excluded.xml")
        code = run("root", ["just", "test", "--locked", "--offline", "-p", "codex-hepta-agentd", "--lib",
                            "--run-ignored", "only", "-E", " | ".join("test(=" + name + ")" for name in PARENTS),
                            "--test-threads", "1", "--retries", "0", "--success-output", "final", "--failure-output", "final"],
                   root=True, minimum=6)
        chown()
        retained = collect(RECORDS / "root.json", report, RECORDS / "root.xml")
        cases = list(ET.parse(RECORDS / "root.xml").iter("testcase"))
        observed = [case.attrib["name"] for case in cases if case.find("skipped") is None]
        save("root-parent-coverage.json", {"expected": PARENTS, "observed": observed})
        assert sorted(observed) == sorted(PARENTS)
        if code or retained:
            raise RuntimeError("Root retry failed; retained full source-bound evidence")
        if run("helper-after", helper):
            raise RuntimeError("same-source pinned helper changed after Root retry")
    except Exception as error:
        failed = f"{type(error).__name__}: {error}"
    finally:
        try:
            chown()
            if subprocess.run(["sudo", "-n", "mountpoint", "-q", str(ROOT_DIR / "bind")]).returncode == 0:
                if run("root-unmount", ["sudo", "-n", "umount", str(ROOT_DIR / "bind")]):
                    raise RuntimeError("Root fixture unmount failed")
            after = snapshot()
            save("source-after.json", after)
            assert before == after
        except Exception as error:
            failed = failed or f"cleanup: {type(error).__name__}: {error}"
        for path in list(RECORDS.glob("*.log")):
            path.with_suffix(path.suffix + ".gz").write_bytes(gzip.compress(path.read_bytes(), mtime=0))
        result = {"source": EXPECTED, "steps": steps, "failed": failed is not None, "error": failed,
                  "maintenance_run": False, "finished_unix": time.time(), "root_fixture": str(ROOT_DIR),
                  "scope": "actual-EUID-0 fixture components; no ordinary-task or daemon/Root cold-restart claim"}
        save("qualification-status.json", result)
        save("evidence-inventory.json", [{"path": path.name, "bytes": path.stat().st_size, "sha256": digest(path)}
                                          for path in sorted(RECORDS.iterdir()) if path.is_file()])
        print(json.dumps(result, indent=2), flush=True)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
