"""Run scoped native and explicit Root fixture checks on one clean source HEAD.

This task-owned driver uses the repository's existing source-head execution and
JUnit collectors.  Its results are component evidence, not ordinary-task closure
or a daemon/Root cold-restart qualification.
"""

import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET


ROOT = Path("/home/qq/hepta-learn-ordinary-14cc-20261110")
SOURCE = ROOT / "source"
TARGET = ROOT / "target"
PARENTS = [
    "authority_host_service::writer::learning_registration::tests::root_learning_registration_reopens_without_replacing_original_history",
    "authority_host_service::writer::learning_registration::tests::root_learning_sealed_pin_and_dedicated_uds_recover_original_checkpoint",
    "authority_host_service::writer::learning_registration::tests::root_scoped_learning_reopens_exact_scope_and_refuses_legacy_client",
    "root_production_handoff::learning::tests::root_learning_handoff_reaches_dedicated_uid_with_original_root_pin",
    "authority_host_learning_service_root_tests::root_learning_public_registration_serves_retained_writer_and_recovers_history",
    "learning_iteration_evidence_client::tests::root::original_external_uid_returns_a_verified_receipt_through_held_pidfd",
]
PACKAGES = [
    "codex-hepta-agentd",
    "codex-hepta-automation",
    "codex-hepta-learning-artifacts",
    "codex-hepta-intelligence-eval",
]
FILTER = "test(q24) | test(learning) | test(circuit_learning)"


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def git(*arguments):
    return subprocess.check_output(["git", *arguments], cwd=SOURCE, text=True).strip()


def snapshot():
    return {
        "head": git("rev-parse", "HEAD"),
        "tree": git("rev-parse", "HEAD^{tree}"),
        "status": git("status", "--porcelain=v1", "--untracked-files=all"),
    }


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def main():
    name, expected = sys.argv[1:]
    assert re.fullmatch(r"[a-z0-9-]+", name)
    assert re.fullmatch(r"[0-9a-f]{40}", expected)
    assert os.geteuid() != 0, "ordinary launch must use the regular account"
    records = ROOT / "evidence" / name
    records.mkdir()
    root_dir = Path("/run") / ("hepta-learn-14cc-" + name)
    before = snapshot()
    save(records / "source-before.json", before)
    assert before["head"] == expected and before["status"] == "", before
    settings = {
        "PATH": "/home/qq/hepta-learning-native-4f559bf-d9fb-20261108/transfer:/home/qq/.cargo/bin:/usr/local/bin:/usr/bin:/bin",
        "RUSTUP_HOME": "/home/qq/.rustup",
        "RUSTUP_TOOLCHAIN": "1.96.0",
        "CARGO_HOME": "/home/qq/.cargo",
        "LIBCLANG_PATH": "/usr/lib/llvm-21/lib",
        "BINDGEN_EXTRA_CLANG_ARGS": "-isystem/usr/lib/gcc/x86_64-linux-gnu/15/include",
        "CARGO_TARGET_DIR": str(TARGET),
        "CARGO_INCREMENTAL": "0",
        "CARGO_BUILD_JOBS": "4",
        "CARGO_PROFILE_TEST_DEBUG": "0",
        "CARGO_PROFILE_DEV_DEBUG": "0",
        "CARGO_NET_OFFLINE": "true",
        "CODEX_REPO_ROOT": str(SOURCE),
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(SOURCE / "scripts") + ":" + str(SOURCE),
        "TMPDIR": str(ROOT / "tmp"),
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "RUST_MIN_STACK": "8388608",
        "SOURCE_SHA": expected,
        "TESTED_SHA": expected,
        "HEPTA_CI_LANE": "source-head",
    }
    os.environ.update(settings)
    os.chdir(SOURCE)
    sys.path.insert(0, str(SOURCE / "scripts"))
    from hepta_ci_junit import collect

    save(records / "environment.json", settings)
    save(records / "toolchain.json", {
        label: subprocess.check_output(command, text=True).strip()
        for label, command in {
            "rustc": ["rustc", "-vV"],
            "cargo": ["cargo", "--version"],
            "nextest": ["cargo", "nextest", "--version"],
            "just": ["just", "--version"],
        }.items()
    })
    save(records / "tools-sha256.json", {
        label: digest(Path(path))
        for label, path in {
            "rustc": "/home/qq/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin/rustc",
            "cargo": "/home/qq/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin/cargo",
            "just": "/home/qq/hepta-learning-native-4f559bf-d9fb-20261108/transfer/just",
            "driver": str(Path(__file__).resolve()),
        }.items()
    })
    steps = []
    failure = None

    def command(stage, arguments, root=False, minimum_tests=0):
        output = records / (stage + ".json")
        launch = [
            "python3", "scripts/hepta_ci_exec.py", "--timeout-seconds", "7200",
            "--minimum-tests", str(minimum_tests), "--output", str(output),
            "--", *arguments,
        ]
        if root:
            environment = {
                **settings,
                "GIT_CONFIG_COUNT": "1",
                "GIT_CONFIG_KEY_0": "safe.directory",
                "GIT_CONFIG_VALUE_0": str(SOURCE),
                "HEPTA_HOST_AUTHORITY_QUALIFICATION_STATE_PARENT": str(root_dir / "bind"),
                "HEPTA_HOST_AUTHORITY_QUALIFICATION_SOURCE": str(root_dir / "source"),
                "HEPTA_CHECKPOINT_TEST_ROOT": str(root_dir / "checkpoints"),
                **json.loads((records / "helpers/env.json").read_text()),
            }
            check = "import os,runpy,sys; assert os.getuid()==os.geteuid()==0; print('Root test uid=0',flush=True); runpy.run_path(sys.argv.pop(1),run_name='__main__')"
            launch = [
                "sudo", "-n", "env", "-i",
                *(key + "=" + value for key, value in sorted(environment.items())),
                "python3", "-c", check, *launch[1:],
            ]
        save(records / (stage + "-launch.json"), {
            "command": launch,
            "required_euid": 0 if root else os.geteuid(),
            "started_unix": time.time(),
        })
        with (records / (stage + "-driver.log")).open("xb") as log:
            process = subprocess.Popen(launch, cwd=SOURCE, stdout=log, stderr=subprocess.STDOUT)
            print(json.dumps({"stage": stage, "pid": process.pid, "source": expected}), flush=True)
            status = process.wait()
        steps.append({"stage": stage, "exit_code": status})
        return status

    def restore_ownership():
        paths = [TARGET, records, SOURCE / "codex-rs/target/nextest"]
        subprocess.run([
            "sudo", "-n", "chown", "-R", f"{os.getuid()}:{os.getgid()}",
            *(str(path) for path in paths if path.exists()),
        ], check=True)

    def tests(stage, arguments, root=False):
        report = SOURCE / "codex-rs/target/nextest/local/junit.xml"
        if report.exists():
            report.rename(records / (stage + "-prior-junit-excluded.xml"))
        code = command(stage, [
            "just", "test", "--locked", "--offline", *arguments,
            "--retries", "0", "--success-output", "final", "--failure-output", "final",
        ], root=root, minimum_tests=1)
        if root:
            restore_ownership()
        retained = collect(records / (stage + ".json"), report, records / (stage + ".xml"))
        execution = json.loads((records / (stage + ".json")).read_text())
        if "log_file" in execution:
            raw = (records / execution["log_file"]).read_text(errors="replace")
            cleaned = re.sub(r"\x1b\[[0-9;]*m", "", raw)
            summaries = [line for line in cleaned.splitlines() if re.search(r"Summary.*\d+ tests? run:", line)]
            save(records / (stage + "-terminal-summary.json"), {"summary_lines": summaries})
        if root and (records / (stage + ".xml")).exists():
            cases = list(ET.parse(records / (stage + ".xml")).iter("testcase"))
            observed = [case.attrib["name"] for case in cases if case.find("skipped") is None]
            save(records / "root-parent-coverage.json", {"expected": PARENTS, "observed": observed})
            assert sorted(observed) == sorted(PARENTS), "requested Root parents differ from JUnit"
        if code or retained:
            raise RuntimeError(stage + " failed; execution, log, and JUnit retained")

    helper = [
        "python3", "scripts/hepta_cell_test_helpers.py", "--package",
        "codex-hepta-infer-worker-host", "--output-dir", str(records / "helpers"),
    ]
    try:
        if command("helper-build", helper):
            raise RuntimeError("same-source helper preparation failed")
        os.environ.update(json.loads((records / "helpers/env.json").read_text()))
        packages = [part for package in PACKAGES for part in ["-p", package]]
        tests("ordinary", [*packages, "--lib", "-E", FILTER, "--test-threads", "2"])
        setup = (
            "import os,subprocess,sys; from pathlib import Path; "
            "assert os.getuid()==os.geteuid()==0; p=Path(sys.argv[1]); p.mkdir(mode=0o700); "
            "[(p/n).mkdir(mode=0o700) for n in ('source','bind','checkpoints')]; "
            "subprocess.run(['mount','--bind',str(p/'source'),str(p/'bind')],check=True); "
            "print('Root fixture uid='+str(os.geteuid())+' path='+str(p),flush=True)"
        )
        if command("root-setup", ["sudo", "-n", "python3", "-c", setup, str(root_dir)]):
            raise RuntimeError("actual-Root private mount fixture setup failed")
        tests("root", [
            "-p", "codex-hepta-agentd", "--lib", "--run-ignored", "only",
            "-E", " | ".join("test(=" + parent + ")" for parent in PARENTS),
            "--test-threads", "1",
        ], root=True)
        if command("helper-verification", [*helper, "--verify-only"]):
            raise RuntimeError("same-source helper verification failed")
    except Exception as error:
        failure = f"{type(error).__name__}: {error}"
        print(json.dumps({"qualification_error": failure}), flush=True)
    finally:
        try:
            restore_ownership()
            mounted = subprocess.run(["sudo", "-n", "mountpoint", "-q", str(root_dir / "bind")]).returncode
            if mounted == 0:
                if command("root-unmount", ["sudo", "-n", "umount", str(root_dir / "bind")]):
                    raise RuntimeError("task Root fixture unmount failed")
            after = snapshot()
            save(records / "source-after.json", after)
            assert before == after, "source changed during native qualification"
        except Exception as error:
            failure = failure or f"cleanup: {type(error).__name__}: {error}"
        for path in list(records.glob("*.log")):
            path.with_suffix(path.suffix + ".gz").write_bytes(gzip.compress(path.read_bytes(), mtime=0))
        result = {
            "source": expected,
            "scope": "native engineering and actual-EUID-0 fixture components; no ordinary A/B/C closure or daemon/Root cold-restart claim",
            "maintenance_run": False,
            "steps": steps,
            "failed": failure is not None,
            "error": failure,
            "root_fixture": str(root_dir),
            "finished_unix": time.time(),
        }
        save(records / "qualification-status.json", result)
        inventory = []
        for path in sorted(records.rglob("*")):
            if path.is_file() and "helpers/bin" not in str(path.relative_to(records)):
                inventory.append({"path": str(path.relative_to(records)), "bytes": path.stat().st_size, "sha256": digest(path)})
        save(records / "evidence-inventory.json", inventory)
        print(json.dumps(result, indent=2), flush=True)
    return 1 if failure else 0


if __name__ == "__main__":
    raise SystemExit(main())
