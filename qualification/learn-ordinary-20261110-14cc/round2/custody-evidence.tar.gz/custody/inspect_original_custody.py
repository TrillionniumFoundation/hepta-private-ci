"""Bounded read-only inventory along observed original service bindings.

Outputs file metadata, structural field names, and explicit public digests only.
Never emits task contents, signing keys, authentication tokens, or credentials.
"""
import ast
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import stat
import sys
import time

SENSITIVE=re.compile(r'private.?key|secret|password|token|credential|signing.?key|api.?key|auth.?key',re.I)
INTEREST=re.compile(r'authbus|learn|owner|register|enroll|current|checkpoint|scope|principal|capabil|generation|authority|trust|profile|version',re.I)
CANDIDATE=re.compile(r'authbus|learn|owner|register|enroll|current|checkpoint|trust|profile|binding|claims|plan|seal|manifest|config|state|registry|routing|policy',re.I)
report={'schema':'hepta.learn.original.custody.inventory.v1','started_unix':time.time(),'platform':platform.system(),'euid':os.geteuid(),'services_changed':False,'private_key_material_output':False,'claim':'No original custody inferred from metadata or uid','files':[],'directories':[],'source_metadata':[],'limits':{'directory_depth':2,'children_per_directory':100,'json_max_bytes':1048576,'json_structural_nodes':300}}
seen=set()
json_paths=set()
known_roots=set()

def metadata(path):
    try:
        s=path.lstat()
        return {'path':str(path),'uid':s.st_uid,'gid':s.st_gid,'mode':oct(stat.S_IMODE(s.st_mode)),'bytes':s.st_size,'kind':'symlink' if path.is_symlink() else 'directory' if path.is_dir() else 'socket' if stat.S_ISSOCK(s.st_mode) else 'file'}
    except OSError as error:
        return {'path':str(path),'error':type(error).__name__}

def discover(path,depth=2):
    if str(path) in seen:
        return
    seen.add(str(path))
    row=metadata(path)
    if path.is_dir() and not path.is_symlink():
        try:
            children=sorted(path.iterdir())
            row['children']=[metadata(p) for p in children[:100]]
            row['children_omitted']=max(0,len(children)-100)
            for child in children[:100]:
                if child.is_symlink():
                    continue
                if child.is_dir() and depth>1 and child.name not in {'logs','tls','auth','keys','__pycache__'}:
                    discover(child,depth-1)
                elif child.is_file() and child.suffix=='.json' and CANDIDATE.search(child.name) and not SENSITIVE.search(child.name):
                    json_paths.add(child)
                elif child.is_file() and child.name=='CURRENT':
                    current=metadata(child)
                    if child.stat().st_size<=256:
                        value=child.read_text(errors='replace').strip()
                        if re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}',value):
                            current['public_current_digest']=value
                    report['files'].append(current)
        except OSError as error:
            row['error']=type(error).__name__
    report['directories'].append(row)

def inspect_json(path):
    row=metadata(path)
    if not path.is_file() or path.is_symlink() or row.get('bytes',0)>1048576 or SENSITIVE.search(path.name):
        row['content_inspected']=False
        report['files'].append(row)
        return
    try:
        data=json.loads(path.read_bytes())
        row['content_inspected']='structural metadata only'
        row['top_level_fields']=sorted(data) if isinstance(data,dict) else {'container':type(data).__name__,'entries':len(data) if isinstance(data,list) else None}
        row['interesting_field_paths']=[]
        row['public_digest_fields']={}
        row['learn_scope_tags']=[]
        count=0
        def visit(value,parts):
            nonlocal count
            count+=1
            if count>300:
                return
            if isinstance(value,dict):
                for key,child in value.items():
                    if SENSITIVE.search(str(key)):
                        continue
                    field='.'.join([*parts,str(key)])
                    if INTEREST.search(str(key)):
                        row['interesting_field_paths'].append({'field':field,'type':type(child).__name__})
                    if isinstance(child,str) and re.search(r'digest|sha256|source_sha|source_commit|tree_oid',str(key),re.I) and re.fullmatch(r'(?:sha256:)?[0-9a-f]{40}|(?:sha256:)?[0-9a-f]{64}',child):
                        row['public_digest_fields'][field]=child
                    if isinstance(child,str) and re.search(r'scope|capabil|role|kind|schema|type',str(key),re.I) and re.search(r'learn|training|evaluat|select|version.owner|authbus',child,re.I) and re.fullmatch(r'[A-Za-z0-9_.:/-]{1,160}',child):
                        row['learn_scope_tags'].append({'field':field,'tag':child})
                    if len(parts)<6:
                        visit(child,[*parts,str(key)])
            elif isinstance(value,list):
                for child in value[:20]:
                    visit(child,[*parts,'[]'])
        visit(data,[])
        row['structural_scan_limit_reached']=count>300
    except (OSError,ValueError) as error:
        row['parse_error']=type(error).__name__
    report['files'].append(row)

if platform.system()=='Linux':
    sources=[Path('/usr/local/libexec/hepta-root-guard/monitor.py')]
    known_roots.add(Path('/var/lib/hepta-root-guard'))
    for source in sources:
        row=metadata(source)
        try:
            body=source.read_bytes()
            row['sha256']=hashlib.sha256(body).hexdigest()
            text=body.decode('utf-8')
            row['owner_protocol_token_presence']={token:token in text for token in ['AuthBus','RootLearning','learning_stage','original_task','checkpoint','CURRENT']}
            tree=ast.parse(text)
            paths=sorted({node.value for node in ast.walk(tree) if isinstance(node,ast.Constant) and isinstance(node.value,str) and node.value.startswith(('/etc/hepta-root-guard','/var/lib/hepta-root-guard','/run/hepta-root-guard','/usr/local/libexec/hepta-root-guard')) and '\n' not in node.value and not SENSITIVE.search(node.value)})
            row['bound_path_literals']=paths
            for value in paths:
                path=Path(value)
                if path.is_dir():
                    known_roots.add(path)
                elif path.suffix=='.json':
                    json_paths.add(path)
                    known_roots.add(path.parent)
        except (OSError,ValueError,SyntaxError) as error:
            row['read_error']=type(error).__name__
        report['source_metadata'].append(row)
else:
    provider=Path('/Users/qianqi/Library/Application Support/HEPTA/provider')
    kv=Path('/Volumes/T5/hepta-vnext-recovery-20261013/heptabao-production-20261104-r1/formal-kv2-current-20261106-r1')
    known_roots.update([provider/'v149-r2',provider/'state/provider',provider/'state/bridge',kv/'config',kv/'manager'])
    json_paths.update([provider/'v149-r2/retained-claims.json',provider/'v149-r2/installed-plan.json',provider/'v149-r2/installed-source-seal.json',kv/'manager/launch-binding.private.json'])

for root in sorted(known_roots):
    discover(root)
for path in sorted(json_paths):
    inspect_json(path)
report['finished_unix']=time.time()
output=Path(sys.argv[1])
assert not output.exists() and output.is_absolute()
with output.open('x') as f:
    json.dump(report,f,indent=2,sort_keys=True)
os.chmod(output,0o600)
if platform.system()=='Linux' and os.geteuid()==0:
    os.chown(output,1000,1000)
print(json.dumps({'output':str(output),'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'bytes':output.stat().st_size,'directories_inspected':len(report['directories']),'files_inspected':len(report['files']),'source_metadata':report['source_metadata'],'interesting_fields':[{'path':r['path'],'fields':r.get('interesting_field_paths',[]),'learn_scope_tags':r.get('learn_scope_tags',[])} for r in report['files'] if r.get('interesting_field_paths') or r.get('learn_scope_tags')]}),flush=True)
