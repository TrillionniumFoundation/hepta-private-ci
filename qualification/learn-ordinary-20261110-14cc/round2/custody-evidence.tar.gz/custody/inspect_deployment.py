"""Bounded deployment metadata inventory.  Never emit credential values."""

import hashlib
import json
import os
from pathlib import Path
import platform
import plistlib
import re
import shlex
import shutil
import stat
import subprocess
import sys
import time


MATCH = re.compile(r"hepta|codex|authbus|learning|authority|neuron", re.I)
SAFE_PATH_FLAGS = {
    "--config", "--config-file", "--profile", "--profile-file", "--home-root", "--state-dir",
    "--authbus-trust-file", "--authbus-checkpoint-file", "--objective-profile-file",
    "--automation-effect-host-file", "--evidence-trust-file", "--evidence-recovery-frontier-file",
    "--evidence-recovery-frontier-trust-file", "--plasticity-bootstrap-descriptor",
    "--neuron-generation-bootstrap-descriptor", "--intelligence-authority-file", "--socket",
}


def command(args, timeout=15):
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return {"exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr[:1000]}
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"error": type(error).__name__, "detail": str(error)[:500]}


def metadata(path):
    try:
        data = path.lstat()
        return {"path": str(path), "mode": oct(stat.S_IMODE(data.st_mode)), "uid": data.st_uid,
                "gid": data.st_gid, "bytes": data.st_size,
                "kind": "symlink" if path.is_symlink() else "directory" if path.is_dir() else "socket" if stat.S_ISSOCK(data.st_mode) else "file"}
    except OSError as error:
        return {"path": str(path), "error": type(error).__name__}


def argv_metadata(arguments):
    result = {"executable": arguments[0] if arguments else None, "flags": [], "path_bindings": {}}
    for index, arg in enumerate(arguments[1:], 1):
        if not isinstance(arg, str) or not arg.startswith("-"):
            continue
        name, separator, value = arg.partition("=")
        result["flags"].append(name)
        if name in SAFE_PATH_FLAGS:
            candidate = value if separator else arguments[index + 1] if index + 1 < len(arguments) else None
            if isinstance(candidate, str) and candidate.startswith("/"):
                result["path_bindings"][name] = candidate
    return result


def main():
    output = Path(sys.argv[1])
    assert output.is_absolute() and not output.exists()
    report = {"schema": "hepta.learn.deployment.metadata.v1", "started_unix": time.time(),
              "platform": platform.system(), "account_uid": os.getuid(), "account_euid": os.geteuid(),
              "scope": "read-only deployment metadata; existence/UID is not original owner custody",
              "private_key_material_read": False, "services_changed": False}
    processes = command(["ps", "-eo", "pid,uid,comm"])
    report["matching_processes"] = [line for line in processes.get("stdout", "").splitlines() if MATCH.search(line)]
    report["process_inventory_status"] = {k: v for k, v in processes.items() if k != "stdout"}
    home = Path.home()
    if platform.system() == "Linux":
        units = []
        scans = []
        for user in [False, True]:
            prefix = ["systemctl", *(["--user"] if user else [])]
            result = command([*prefix, "list-unit-files", "--type=service", "--no-legend", "--no-pager", "--plain"])
            lines = [line for line in result.get("stdout", "").splitlines() if MATCH.search(line.split()[0] if line.split() else "")]
            scans.append({"scope": "user" if user else "system", "matched": lines, **{k: v for k, v in result.items() if k != "stdout"}})
            for line in lines[:40]:
                name = line.split()[0]
                result = command([*prefix, "show", name, "--no-pager", "--property=Id,LoadState,ActiveState,SubState,MainPID,ExecMainStartTimestamp,User,Group,FragmentPath,WorkingDirectory,RootDirectory"])
                record = {"name": name, "scope": "user" if user else "system", **result}
                units.append(record)
        report["unit_discovery"] = scans
        report["units"] = units
        sockets = command(["ss", "-xlH"])
        report["matching_unix_sockets"] = [line for line in sockets.get("stdout", "").splitlines() if MATCH.search(line)][:100]
        report["socket_inventory_status"] = {k: v for k, v in sockets.items() if k != "stdout"}
        sudo = command(["sudo", "-n", "id", "-u"])
        report["existing_sudo_euid_probe"] = sudo
        config_roots = [Path(x) for x in ["/etc/hepta", "/etc/codex", "/var/lib/hepta", "/run/hepta", "/run/codex"]]
        config_roots += [home / ".config/hepta", home / ".config/codex", home / ".hepta"]
        report["native_cache"] = {}
        for key, path in {"source": home / "hepta-learn-ordinary-14cc-20261110/source",
                          "target": home / "hepta-learn-ordinary-14cc-20261110/target",
                          "rustc": home / ".rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin/rustc",
                          "cargo": home / ".rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin/cargo",
                          "just": home / "hepta-learning-native-4f559bf-d9fb-20261108/transfer/just"}.items():
            report["native_cache"][key] = metadata(path)
        report["native_cache"]["disk_free_bytes"] = shutil.disk_usage(home).free
        report["native_cache"]["target_size"] = command(["du", "-sh", str(home / "hepta-learn-ordinary-14cc-20261110/target")])
        old_source = home / "hepta-learn-ordinary-14cc-20261110/source"
        report["native_cache"]["old_source_identity"] = command(["git", "-C", str(old_source), "rev-parse", "HEAD", "HEAD^{tree}"])
    else:
        listed = command(["launchctl", "list"])
        report["matching_loaded_launchd_labels"] = [line for line in listed.get("stdout", "").splitlines() if MATCH.search(line)][:100]
        report["launchd_inventory_status"] = {k: v for k, v in listed.items() if k != "stdout"}
        plists = []
        for directory in [home / "Library/LaunchAgents", Path("/Library/LaunchAgents"), Path("/Library/LaunchDaemons")]:
            if not directory.exists():
                continue
            for path in sorted(directory.glob("*.plist")):
                if not MATCH.search(path.name):
                    continue
                entry = metadata(path)
                try:
                    document = plistlib.loads(path.read_bytes())
                    arguments = document.get("ProgramArguments", [document.get("Program", "")])
                    entry.update(label=document.get("Label"), argv=argv_metadata(arguments),
                                 environment_names=sorted(document.get("EnvironmentVariables", {})),
                                 working_directory=document.get("WorkingDirectory"),
                                 user=document.get("UserName"), group=document.get("GroupName"))
                except (OSError, ValueError, plistlib.InvalidFileException) as error:
                    entry["parse_error"] = type(error).__name__
                plists.append(entry)
        report["matching_plists"] = plists
        config_roots = [home / ".config/hepta", home / ".config/codex", home / ".hepta", Path("/etc/hepta"), Path("/etc/codex")]
        gh = Path("/opt/homebrew/bin/gh")
        report["github_channel"] = metadata(gh)
        report["github_permissions"] = command([str(gh), "api", "repos/TrillionniumFoundation/hepta-private-ci", "--jq", "{full_name,default_branch,permissions}"], timeout=30)
    inventories = []
    for directory in config_roots:
        row = metadata(directory)
        if directory.is_dir():
            try:
                entries = sorted(directory.iterdir())
                row["children"] = [metadata(path) for path in entries[:100]]
                row["children_omitted"] = max(0, len(entries) - 100)
            except OSError as error:
                row["list_error"] = type(error).__name__
        inventories.append(row)
    report["configuration_directory_metadata"] = inventories
    report["finished_unix"] = time.time()
    output.write_text(json.dumps(report, indent=2, sort_keys=True))
    print(json.dumps(report, indent=2, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
