"""Only inspect previously observed provider registration paths, never task bodies."""
import hashlib
import json
from pathlib import Path
import re
import stat
import sys

ROOT=Path('/Users/qianqi/Library/Application Support/HEPTA/provider')
DIRECTORIES=[ROOT/'state/provider/task-contracts/bindings',ROOT/'state/provider/task-contracts/templates',ROOT/'state/provider/evidence/claims']
FILES=[ROOT/'v149-r2/retained-claims.json']
DENY=re.compile(r'token|secret|password|credential|private.?key|signing.?key|api.?key',re.I)
INTEREST=re.compile(r'authbus|learn|owner|scope|current|checkpoint|principal|capabil|register|enroll|profile',re.I)

def meta(path):
    try:
        s=path.lstat()
        return {'path':str(path),'uid':s.st_uid,'gid':s.st_gid,'mode':oct(stat.S_IMODE(s.st_mode)),'bytes':s.st_size,'kind':'symlink' if path.is_symlink() else 'directory' if path.is_dir() else 'file'}
    except OSError as error:
        return {'path':str(path),'error':type(error).__name__}

result={'schema':'hepta.learn.provider.claim.metadata.v1','scope':'Only previously discovered provider bindings/templates/claims; no task body output','directories':[],'files':[],'services_changed':False}
for directory in DIRECTORIES:
    row=meta(directory)
    try:
        children=sorted(directory.iterdir())
        row['children']=[meta(path) for path in children[:100]]
        row['children_omitted']=max(0,len(children)-100)
        FILES.extend(path for path in children[:100] if path.is_file() and not path.is_symlink() and (path.suffix=='.json' or re.fullmatch(r'[0-9a-f]{64}',path.name)) and not DENY.search(path.name))
    except OSError as error:
        row['read_error']=type(error).__name__
    result['directories'].append(row)
for path in FILES:
    row=meta(path)
    if path.is_file() and not path.is_symlink() and row['bytes']<=524288:
        try:
            data=json.loads(path.read_bytes())
            row['top_level_fields']=sorted(data) if isinstance(data,dict) else {'container':type(data).__name__,'entries':len(data) if isinstance(data,list) else None}
            row['public_profile_metadata']=[]
            row['interesting_field_paths']=[]
            row['public_digest_fields']=[]
            count=[0]
            def visit(value,parts):
                count[0]+=1
                if count[0]>500 or len(parts)>7:
                    return
                if isinstance(value,dict):
                    for key,child in value.items():
                        if DENY.search(str(key)):
                            continue
                        field='.'.join([*parts,str(key)])
                        if INTEREST.search(str(key)):
                            row['interesting_field_paths'].append({'field':field,'type':type(child).__name__})
                        if str(key) in {'schema','profile_id','owner_kind','scope_kind','capability_kind','provider_kind'} and isinstance(child,str) and re.fullmatch(r'[A-Za-z0-9_.:/-]{1,160}',child):
                            row['public_profile_metadata'].append({'field':field,'value':child})
                        if re.search(r'digest|sha256',str(key),re.I) and isinstance(child,str) and re.fullmatch(r'(?:sha256:)?[0-9a-f]{64}',child):
                            row['public_digest_fields'].append({'field':field,'value':child})
                        visit(child,[*parts,str(key)])
                elif isinstance(value,list):
                    for child in value[:30]:
                        visit(child,[*parts,'[]'])
            visit(data,[])
            row['structural_limit_reached']=count[0]>500
        except (OSError,ValueError) as error:
            row['read_error']=type(error).__name__
    result['files'].append(row)
output=Path(sys.argv[1])
assert output.is_absolute() and not output.exists()
with output.open('x') as stream:
    json.dump(result,stream,indent=2,sort_keys=True)
print(json.dumps({'output':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'file_metadata':[{'path':row['path'],'schema_profiles':row.get('public_profile_metadata'),'fields':row.get('interesting_field_paths')} for row in result['files']]}),flush=True)
