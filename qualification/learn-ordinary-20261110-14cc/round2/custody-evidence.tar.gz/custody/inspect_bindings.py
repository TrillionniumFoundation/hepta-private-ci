"""Read only deployment bindings and bounded cache metadata; never emit secrets."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import plistlib
import re
import shlex
import stat
import subprocess
import sys
import time

BASE = Path(__file__).parent
spec = importlib.util.spec_from_file_location("inventory", BASE / "inspect_deployment.py")
inventory = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inventory)
inventory.SAFE_PATH_FLAGS.update({"--binding", "--state", "--provider-state", "--provider-source", "--remote-source", "--retained-claims", "--codex", "--policy", "--policy-file", "--manifest", "--manifest-file"})
TOKENS = ["AuthBus", "authbus", "OriginalTask", "original_task", "RootBootstrap", "root_bootstrap", "learning_stage", "stage_evidence", "version_owner", "Training", "Evaluator", "Selector", "Observer", "checkpoint", "CURRENT", "api_key", "oauth", "credential", "capability"]

def source_metadata(path):
    row = inventory.metadata(path)
    if path.is_file() and not path.is_symlink() and path.suffix in {".py", ".rs", ".sh"} and row.get("bytes", 0) <= 500000:
        data = path.read_bytes()
        source = data.decode("utf-8", errors="replace")
        row["sha256"] = hashlib.sha256(data).hexdigest()
        row["source_token_counts"] = {word: source.count(word) for word in TOKENS if word in source}
        row["python_definitions"] = re.findall(r"^(?:async\s+)?def\s+([A-Za-z_][A-Za-z0-9_]*)", source, flags=re.M)[:100]
        row["classes"] = re.findall(r"^class\s+([A-Za-z_][A-Za-z0-9_]*)", source, flags=re.M)[:100]
    return row

def listing(directory, depth=1):
    result = inventory.metadata(directory)
    if directory.is_dir() and not directory.is_symlink():
        try:
            entries = sorted(directory.iterdir())
            result["children"] = []
            for path in entries[:100]:
                row = inventory.metadata(path)
                if path.is_file() and path.suffix in {".py", ".rs", ".sh"}:
                    row = source_metadata(path)
                elif path.is_dir() and depth > 1 and not path.is_symlink() and path.name not in {"__pycache__", "logs", "node_modules", "target", "models"}:
                    row = listing(path, depth - 1)
                result["children"].append(row)
            result["children_omitted"] = max(0, len(entries) - 100)
        except OSError as error:
            result["error"] = type(error).__name__
    return result

def args_metadata(args):
    row = inventory.argv_metadata(args)
    row["positional_source_paths"] = [arg for arg in args[1:] if isinstance(arg, str) and arg.startswith("/") and Path(arg).suffix in {".py", ".sh", ".rs"}]
    return row

report = {"schema": "hepta.learn.deployment.bindings.v1", "started_unix": time.time(), "platform": platform.system(), "scope": "Read-only exact observed service bindings; not proof of original custody", "services_changed": False, "private_key_material_output": False}
home = Path.home()
if platform.system() == "Linux":
    units = []
    roots = set()
    for name in ["hepta-root-guard.service", "hepta-llm-private.service", "hepta-llm-candidate.service", "hepta-gateway-private.service", "hepta-gateway-candidate.service", "hepta-gpu-owner-audit.service", "hepta-gpu-owner-audit.socket", "hepta-ingress-fence-observe.service"]:
        path = Path("/etc/systemd/system") / name
        row = inventory.metadata(path)
        try:
            text = path.read_text()
            row["directive_names"] = sorted(set(re.findall(r"^([A-Za-z][A-Za-z0-9]+)=", text, re.M)))
            row["safe_directives"] = {}
            row["commands"] = {}
            for line in text.splitlines():
                key, sep, value = line.partition("=")
                if not sep:
                    continue
                if key in {"Description", "WorkingDirectory", "User", "Group", "ListenStream", "Service", "Type", "SocketUser", "SocketGroup", "SocketMode"}:
                    row["safe_directives"][key] = value
                    if key == "WorkingDirectory" and value.startswith("/"):
                        roots.add(value)
                if key.startswith("Exec"):
                    try:
                        args = shlex.split(value)
                        row["commands"][key] = args_metadata(args)
                        if args and args[0].startswith("/"):
                            roots.add(str(Path(args[0]).parent))
                    except ValueError:
                        row["commands"][key] = {"parse_error": True}
        except OSError as error:
            row["read_error"] = type(error).__name__
        units.append(row)
    report["system_units"] = units
    roots = {p for p in roots if p not in {"/usr/bin", "/bin", "/usr/sbin", "/sbin"}}
    report["bound_directory_metadata"] = [listing(Path(path), 2) for path in sorted(roots)]
    targets = []
    for parent in [home, home / "work"]:
        if not parent.is_dir():
            continue
        for directory in sorted(parent.iterdir()):
            if not directory.is_dir() or directory.is_symlink():
                continue
            for name in ["target", "target-native", "target-fixed", "target-debug", "codex-rs/target"]:
                candidate = directory / name
                if candidate.is_dir():
                    row = inventory.metadata(candidate)
                    row["size"] = inventory.command(["du", "-sh", str(candidate)], timeout=30)
                    deps = candidate / "debug/deps"
                    if deps.is_dir():
                        entries = sorted(deps.glob("codex_hepta_agentd-*"))
                        row["agentd_artifacts"] = [inventory.metadata(p) for p in entries[:10]]
                        row["agentd_artifacts_omitted"] = max(0, len(entries)-10)
                    targets.append(row)
    report["cache_targets"] = targets
    report["cargo_homes"] = [listing(p) for p in [home / ".cargo", home / "hepta-cell-common-e1c98-20261109/cargo", home / "hepta-learn-ordinary-14cc-20261110/cargo"] if p.exists()]
else:
    selected = ["org.trillionnium.hepta.daily-provider", "org.trillionnium.hepta.daily-bridge", "org.heptabao.kv2", "ai.openclaw.authbus-relay.proxy", "ai.openclaw.authbus-relay.front", "ai.openclaw.authbus-relay.bridge"]
    plists = []
    roots = set()
    for name in selected:
        path = home / "Library/LaunchAgents" / (name + ".plist")
        row = inventory.metadata(path)
        try:
            doc = plistlib.loads(path.read_bytes())
            args = doc.get("ProgramArguments", [doc.get("Program", "")])
            row["argv"] = args_metadata(args)
            row["working_directory"] = doc.get("WorkingDirectory")
            row["environment_names"] = sorted(doc.get("EnvironmentVariables", {}))
            if row["working_directory"]:
                roots.add(row["working_directory"])
            row["source_scripts"] = [source_metadata(Path(p)) for p in row["argv"]["positional_source_paths"]]
            status = inventory.command(["launchctl", "print", "gui/" + str(os.getuid()) + "/" + name])
            text = status.pop("stdout", "")
            row["launchctl_gui_status"] = {**status, "state": re.findall(r"^\s*state = ([A-Za-z_]+)", text, re.M), "pid": re.findall(r"^\s*pid = ([0-9]+)", text, re.M), "domain": re.findall(r"^\s*domain = (gui/[0-9]+)", text, re.M)}
        except (OSError, ValueError, plistlib.InvalidFileException) as error:
            row["read_error"] = type(error).__name__
        plists.append(row)
    report["launchagents"] = plists
    report["bound_directory_metadata"] = [listing(Path(path), 2) for path in sorted(roots)]

report["finished_unix"] = time.time()
output = Path(sys.argv[1])
assert output.is_absolute() and not output.exists()
output.write_text(json.dumps(report, indent=2, sort_keys=True))
print(json.dumps({"output": str(output), "sha256": hashlib.sha256(output.read_bytes()).hexdigest(), "bytes": output.stat().st_size, "cache_targets": report.get("cache_targets", []), "units": [{"path": r["path"], "commands": r.get("commands"), "safe_directives": r.get("safe_directives")} for r in report.get("system_units", [])], "launchagents": [{"path": r["path"], "argv": r.get("argv"), "status": r.get("launchctl_gui_status"), "source_scripts": r.get("source_scripts")} for r in report.get("launchagents", [])]}, indent=2), flush=True)
