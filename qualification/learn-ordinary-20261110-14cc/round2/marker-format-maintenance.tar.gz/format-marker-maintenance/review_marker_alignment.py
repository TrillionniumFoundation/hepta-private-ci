"""Read back formatting-only markers; do not run tests or the full caller scan."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tomllib

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
BASE = "bbab98d805f5c44c1a70a91f0dfd98821adddecc"

def normalized(value):
    chars = [c for c in value if not c.isspace()]
    return "".join(c for i, c in enumerate(chars)
                   if not (c == "," and i + 1 < len(chars) and chars[i + 1] in ")]}"))

def base_bytes(path):
    return subprocess.check_output(["git", "show", BASE + ":" + path], cwd=ROOT)

before = tomllib.loads(base_bytes("CALLERS.toml").decode())
after = tomllib.loads((ROOT / "CALLERS.toml").read_text())
changes = []

def equivalent(a, b, path=()):
    assert type(a) is type(b), path
    if isinstance(a, dict):
        assert a.keys() == b.keys(), path
        for key in a:
            equivalent(a[key], b[key], path + (key,))
    elif isinstance(a, list):
        assert len(a) == len(b), path
        for i, (left, right) in enumerate(zip(a, b, strict=True)):
            equivalent(left, right, path + (i,))
    elif a != b:
        assert isinstance(a, str), path
        assert any(k in path for k in ("definition_markers", "caller_markers", "required", "required_order", "required_function_order")), path
        assert "forbidden" not in path and normalized(a) == normalized(b), path
        changes.append({"path": list(path), "before": a, "after": b})

equivalent(before, after)
assert len(after["boundary"]) == 211 and len(after["protected_file"]) == 215
spec = importlib.util.spec_from_file_location("format_marker_readback", ROOT / "scripts/verify_hepta_callers.py")
proof = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = proof
spec.loader.exec_module(proof)
protected = proof._verify_protected_files(ROOT, after)
marker_count = 0
for row in after["boundary"]:
    for marker in row.get("definition_markers", []):
        assert marker in (ROOT / row["definition_path"]).read_text(), (row["id"], marker)
        marker_count += 1
    for path in row["product_callers"]:
        for marker in row.get("caller_markers", []):
            assert marker in (ROOT / path).read_text(), (row["id"], path, marker)
            marker_count += 1

class NormalizeStrings(ast.NodeTransformer):
    def visit_Constant(self, node):
        if isinstance(node.value, str):
            node.value = normalized(node.value)
        return node

qa_changes = []
for path in sorted((ROOT / "qa/b4-no-bypass").glob("test_*source_closure.py")):
    relative = str(path.relative_to(ROOT))
    original = base_bytes(relative).decode()
    current = path.read_text()
    if original == current:
        continue
    old_tree, new_tree = ast.parse(original), ast.parse(current)
    old_strings = [n.value for n in ast.walk(old_tree) if isinstance(n, ast.Constant) and isinstance(n.value, str)]
    new_strings = [n.value for n in ast.walk(new_tree) if isinstance(n, ast.Constant) and isinstance(n.value, str)]
    assert len(old_strings) == len(new_strings)
    for a, b in zip(old_strings, new_strings, strict=True):
        if a != b:
            assert normalized(a) == normalized(b)
            qa_changes.append({"path": relative, "old": a, "new": b})
    assert ast.dump(NormalizeStrings().visit(old_tree)) == ast.dump(NormalizeStrings().visit(new_tree))

manifest = json.loads((OUT.parent / "maintenance-review-bbab-v1/postimages.json").read_text())
for row in manifest["files"]:
    content = (ROOT / row["path"]).read_bytes()
    assert len(content) == row["bytes"]
    assert hashlib.sha256(content).hexdigest() == row["sha256"]
    assert hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest() == row["blob"]

result = {
    "schema": "hepta.learn.format-marker-readback.v1",
    "status": "PASS_STATIC_FORMAT_MARKER_READBACK",
    "behavior_source": BASE,
    "boundaries": len(after["boundary"]),
    "protected_rows": len(protected),
    "protected_files": len(set(protected)),
    "definition_and_caller_literal_occurrences": marker_count,
    "authority_and_caller_sets_unchanged": True,
    "forbidden_markers_unchanged": True,
    "required_guards_and_order_unchanged": True,
    "rust_files_match_native_postimages": len(manifest["files"]),
    "full_caller_scan_executed": False,
    "behavior_or_mutation_tests_executed": False,
    "manifest_marker_changes": changes,
    "qa_marker_changes": qa_changes,
    "callers_sha256": hashlib.sha256((ROOT / "CALLERS.toml").read_bytes()).hexdigest(),
}
OUT.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in ("manifest_marker_changes", "qa_marker_changes")} | {
    "manifest_marker_changes": len(changes), "qa_marker_changes": len(qa_changes)
}))
