These records are post-maintenance text alignment and read-only review, not behavior tests.
The alignment helper changed 81 CALLERS literal values and 13 unambiguous QA literals.
Two source.read_run_publication markers were then aligned separately in their respective
NextUse and historical-recovery function scopes. The final static readback covers all
81 manifest changes and 15 QA literals and verifies the unchanged AST apart from strings.
All authorities, caller sets, forbidden markers, guard order and 44 native Rust postimages
remain unchanged. The full caller scanner and all behavior/mutation tests were not rerun.
