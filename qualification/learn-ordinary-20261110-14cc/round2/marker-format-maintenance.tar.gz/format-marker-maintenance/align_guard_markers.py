"""Align literal source markers with an already reviewed rustfmt postimage.

No boundary, authority, caller set or guard condition may change. This script
only replaces text with its same whitespace/trailing-comma-normalized match.
It is maintenance of source text markers, not a behavior/test-suite execution.
"""
import ast
from collections import defaultdict
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import tomllib

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
BASE = "bbab98d805f5c44c1a70a91f0dfd98821adddecc"
before_text = subprocess.check_output(["git", "show", BASE + ":CALLERS.toml"], cwd=ROOT, text=True)
assert (ROOT / "CALLERS.toml").read_text() == before_text
sources = {}
old_sources = {}
spec = importlib.util.spec_from_file_location("marker_source_parser", ROOT / "scripts/verify_hepta_callers.py")
proof = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = proof
spec.loader.exec_module(proof)

def source(path):
    if path not in sources:
        sources[path] = (ROOT / path).read_text()
    return sources[path]

def normalized(value, commas=False):
    positions = [i for i, c in enumerate(value) if not c.isspace()]
    if commas:
        positions = [p for k, p in enumerate(positions)
                     if not (value[p] == "," and k + 1 < len(positions)
                             and value[positions[k + 1]] in ")]}")]
    return "".join(value[i] for i in positions), positions

def in_scope(path, function):
    text = source(path)
    if function is None:
        return text
    clean = proof._strip_rust_non_code(text)
    assert clean.count(function) == 1, (path, function)
    start = clean.index(function)
    end = proof._rust_item_end(clean, start)
    assert end is not None
    return text[start:end + 1]

def candidates(marker, path, function):
    text = in_scope(path, function)
    if marker in text:
        return {marker}
    for commas in (False, True):
        needle, _ = normalized(marker, commas)
        haystack, positions = normalized(text, commas)
        start = 0
        found = set()
        while needle and (offset := haystack.find(needle, start)) >= 0:
            found.add(text[positions[offset]:positions[offset + len(needle) - 1] + 1])
            start = offset + 1
        if found:
            return found
    return set()

changes = []
unresolved = []
global_replacements = defaultdict(set)
blocks = re.split(r"(?=^\[\[(?:boundary|protected_file)\]\])", before_text, flags=re.M)
result = [blocks[0]]
for block in blocks[1:]:
    parsed = tomllib.loads(block)
    kind = "boundary" if "boundary" in parsed else "protected_file"
    row = parsed[kind][0]
    groups = []
    if kind == "boundary":
        groups.append((row.get("definition_markers", []), [row["definition_path"]], None))
        groups.append((row.get("caller_markers", []), row["product_callers"], None))
    else:
        paths = [row["path"]]
        groups.append((row.get("required", []), paths, None))
        groups.extend((sequence, paths, None) for sequence in row.get("required_order", []))
        for item in row.get("required_function_order", []):
            groups.append(([item["function"]] + item["sequence"] + item.get("top_level", []), paths, item["function"]))
    replacements = {}
    for markers, paths, function in groups:
        for marker in markers:
            if not paths or all(marker in in_scope(path, function) for path in paths):
                continue
            choices = set.intersection(*(candidates(marker, path, function) for path in paths))
            if len(choices) != 1:
                unresolved.append({"kind": kind, "row": row.get("id", row.get("path")),
                                   "paths": paths, "marker": marker, "matches": sorted(choices)})
                continue
            replacement = choices.pop()
            assert normalized(marker, True)[0] == normalized(replacement, True)[0]
            key = (function, marker)
            if key in replacements:
                assert replacements[key] == replacement
            replacements[key] = replacement
            changes.append({"kind": kind, "row": row.get("id", row.get("path")),
                            "paths": paths, "function": function, "old": marker, "new": replacement})
            global_replacements[marker].add(replacement)
    for (function, old), new in sorted(replacements.items(), key=lambda item: item[0][0] is None):
        encoded = json.dumps(old, ensure_ascii=False)
        start = block.index("function = " + json.dumps(function)) if function else 0
        end = block.find("function = ", start + 12) if function else len(block)
        if end < 0:
            end = len(block)
        part = block[start:end]
        assert encoded in part or json.dumps(new, ensure_ascii=False) in part, (kind, row.get("id", row.get("path")), old)
        block = block[:start] + part.replace(encoded, json.dumps(new, ensure_ascii=False)) + block[end:]
    result.append(block)

report = {"schema": "hepta.learn.marker-format-alignment.v1", "behavior_source": BASE,
          "changes": changes, "unresolved": unresolved, "tests_executed": False}
OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
if unresolved:
    print(json.dumps({"changes_ready": len(changes), "unresolved": unresolved}, indent=2))
    sys.exit(1)

updated = "".join(result)
old = tomllib.loads(before_text)
new = tomllib.loads(updated)
assert len(old["boundary"]) == len(new["boundary"]) == 211
assert len(old["protected_file"]) == len(new["protected_file"]) == 215
assert old["authority"] == new["authority"]
assert old["privileged_inventory"] == new["privileged_inventory"]
for a, b in zip(old["boundary"], new["boundary"], strict=True):
    for key in set(a) - {"definition_markers", "caller_markers"}:
        assert a[key] == b[key], key
for a, b in zip(old["protected_file"], new["protected_file"], strict=True):
    assert a["path"] == b["path"]
    assert a.get("forbidden", []) == b.get("forbidden", [])
(ROOT / "CALLERS.toml").write_text(updated)

# Keep the exact marker literals in the already-tested source-mutation suite
# aligned as text. Do not execute that suite after repository maintenance.
qa_changes = []
for path in sorted((ROOT / "qa/b4-no-bypass").glob("test_*source_closure.py")):
    text = path.read_text()
    encoded = text.encode()
    line_offsets = [0]
    for line in encoded.splitlines(keepends=True):
        line_offsets.append(line_offsets[-1] + len(line))
    edits = []
    for node in ast.walk(ast.parse(text)):
        if not isinstance(node, ast.Constant) or not isinstance(node.value, str):
            continue
        replacements = global_replacements.get(node.value, set())
        if len(replacements) == 1:
            replacement = next(iter(replacements))
            edits.append((line_offsets[node.lineno - 1] + node.col_offset,
                          line_offsets[node.end_lineno - 1] + node.end_col_offset,
                          json.dumps(replacement, ensure_ascii=False).encode()))
            qa_changes.append({"path": str(path.relative_to(ROOT)), "old": node.value, "new": replacement})
    for start, end, replacement in sorted(edits, reverse=True):
        encoded = encoded[:start] + replacement + encoded[end:]
    if edits:
        path.write_bytes(encoded)
report["qa_marker_changes"] = qa_changes
OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"marker_changes": len(changes), "qa_marker_changes": len(qa_changes),
                  "caller_sets_unchanged": True, "forbidden_markers_unchanged": True,
                  "tests_executed": False}))
