"""Retain exact source identity and selected learning mutation-test results."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import unittest

root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
expected = sys.argv[3]
output.mkdir()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()

def state():
    return {"head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "status": git("status", "--porcelain=v1", "--untracked-files=all")}

before = state()
assert before["head"] == expected and before["status"] == "", before
patterns = ["test_*learning*source_closure.py", "test_q24_training_plan_source_closure.py",
            "test_training_no_update_source_closure.py"]
qa = root / "qa/b4-no-bypass"
suite = unittest.TestSuite()
loader = unittest.TestLoader()
for pattern in patterns:
    suite.addTests(loader.discover(str(qa), pattern=pattern))
names = []

def collect(value):
    for case in value:
        if isinstance(case, unittest.TestSuite):
            collect(case)
        else:
            names.append(case.id())

collect(suite)
assert len(names) == len(set(names)), "duplicate selected test cases"
started = time.time()
with (output / "unittest.log").open("x") as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
after = state()
report = {
    "schema": "hepta.learn.source-mutation-checks.v1", "source_before": before,
    "source_after": after, "started_unix": started, "completed_unix": time.time(),
    "patterns": patterns, "tests_selected": names, "tests_run": result.testsRun,
    "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
    "success": result.wasSuccessful() and before == after,
    "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "log_sha256": hashlib.sha256((output / "unittest.log").read_bytes()).hexdigest(),
}
(output / "result.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(json.dumps(report, sort_keys=True))
sys.exit(0 if report["success"] else 1)
