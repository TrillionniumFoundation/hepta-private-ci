"""Source-pinned round-two native component qualification; no service mutation."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/home/qq/hepta-learn-ordinary-14cc-round2-20261110')
SOURCE = ROOT / 'source'
TARGET = ROOT / 'target'
PACKAGES = ['codex-hepta-agentd']
FILTER = 'test(ordinary_source_) | test(q24_feature_)'

def digest(path):
    result=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):
            result.update(block)
    return result.hexdigest()

def save(path,data):
    with path.open('x') as f:
        json.dump(data,f,indent=2,sort_keys=True)
        f.write('\n')

def git(*args):
    return subprocess.check_output(['git',*args],cwd=SOURCE,text=True).strip()

def snapshot():
    return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain=v1','--untracked-files=all')}

def main():
    name,expected=sys.argv[1:]
    assert re.fullmatch(r'[a-z0-9-]+',name)
    assert re.fullmatch(r'[0-9a-f]{40}',expected)
    assert os.getuid()==os.geteuid()==1000
    records=ROOT/'evidence'/name
    records.mkdir()
    before=snapshot()
    save(records/'source-before.json',before)
    assert before['head']==expected and before['status']=='',before
    settings={
      'PATH':'/home/qq/hepta-learning-native-4f559bf-d9fb-20261108/transfer:/home/qq/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
      'RUSTUP_HOME':'/home/qq/.rustup','RUSTUP_TOOLCHAIN':'1.96.0','CARGO_HOME':'/home/qq/.cargo',
      'LIBCLANG_PATH':'/usr/lib/llvm-21/lib','BINDGEN_EXTRA_CLANG_ARGS':'-isystem/usr/lib/gcc/x86_64-linux-gnu/15/include',
      'CARGO_TARGET_DIR':str(TARGET),'CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'4',
      'CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_NET_OFFLINE':'true',
      'CODEX_REPO_ROOT':str(SOURCE),'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(SOURCE/'scripts')+':'+str(SOURCE),
      'TMPDIR':str(ROOT/'tmp'),'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','RUST_MIN_STACK':'8388608',
      'SOURCE_SHA':expected,'TESTED_SHA':expected,'HEPTA_CI_LANE':'source-head',
    }
    os.environ.update(settings)
    os.chdir(SOURCE)
    sys.path.insert(0,str(SOURCE/'scripts'))
    from hepta_ci_junit import collect
    save(records/'environment.json',settings)
    save(records/'toolchain.json',{label:subprocess.check_output(command,text=True).strip() for label,command in {
      'rustc':['rustc','-vV'],'cargo':['cargo','--version'],'nextest':['cargo','nextest','--version'],'just':['just','--version']}.items()})
    save(records/'driver-sha256.json',{'path':str(Path(__file__).resolve()),'sha256':digest(Path(__file__).resolve())})
    steps=[]
    failure=None

    def execute(stage,args,minimum_tests=0):
        launch=['python3','scripts/hepta_ci_exec.py','--timeout-seconds','7200','--minimum-tests',str(minimum_tests),'--output',str(records/(stage+'.json')),'--',*args]
        save(records/(stage+'-launch.json'),{'argv':launch,'started_unix':time.time(),'uid':os.getuid(),'euid':os.geteuid()})
        with (records/(stage+'-driver.log')).open('xb') as log:
            process=subprocess.Popen(launch,cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT)
            print(json.dumps({'stage':stage,'pid':process.pid,'source':expected,'records':str(records)}),flush=True)
            code=process.wait()
        steps.append({'stage':stage,'exit_code':code,'finished_unix':time.time()})
        print(json.dumps(steps[-1]),flush=True)
        return code

    helper=['python3','scripts/hepta_cell_test_helpers.py','--package','codex-hepta-infer-worker-host','--output-dir',str(records/'helpers')]
    try:
        if execute('helper-build',helper):
            raise RuntimeError('same-source helper preparation failed')
        os.environ.update(json.loads((records/'helpers/env.json').read_text()))
        junit=SOURCE/'codex-rs/target/nextest/local/junit.xml'
        if junit.exists():
            junit.rename(records/'prior-junit-excluded.xml')
        arguments=[p for package in PACKAGES for p in ['-p',package]]
        code=execute('ordinary',['just','test','--locked','--offline',*arguments,'--lib','-E',FILTER,'--test-threads','2','--retries','0','--success-output','final','--failure-output','final'],minimum_tests=1)
        collected=collect(records/'ordinary.json',junit,records/'ordinary.xml')
        if (records/'ordinary.xml').exists():
            cases=list(ET.parse(records/'ordinary.xml').iter('testcase'))
            save(records/'ordinary-cases.json',{'filter':FILTER,'packages':PACKAGES,'cases':[{'classname':c.get('classname'),'name':c.get('name'),'time':c.get('time'),'skipped':c.find('skipped') is not None,'failed':c.find('failure') is not None,'error':c.find('error') is not None} for c in cases]})
        if code or collected:
            raise RuntimeError('native component tests failed; raw execution and JUnit retained')
        if execute('helper-verify',[*helper,'--verify-only']):
            raise RuntimeError('same-source helper verification failed')
    except Exception as error:
        failure=repr(error)
    finally:
        after=snapshot()
        save(records/'source-after.json',after)
        if after!=before:
            failure=failure or 'source changed during qualification'
        status={'schema':'hepta.learn.round2.native.v1','candidate':expected,'source_tree':before['tree'],'kind':'intermediate component qualification','ordinary_abc_route_executed':False,'real_daemon_root_cold_restart_executed':False,'source_unchanged':after==before,'steps':steps,'failure':failure,'finished_unix':time.time()}
        save(records/'qualification-status.json',status)
        print(json.dumps(status),flush=True)
    raise SystemExit(1 if failure else 0)

if __name__=='__main__':
    main()
