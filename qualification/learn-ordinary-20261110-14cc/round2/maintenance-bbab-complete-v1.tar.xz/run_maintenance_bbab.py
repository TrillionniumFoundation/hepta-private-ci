"""Scoped post-test maintenance, with exact postimages and compile-only checks."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


ROOT = Path("/home/qq/hepta-learn-ordinary-14cc-round2-20261110")
SOURCE = ROOT / "source"
RECORDS = ROOT / "evidence/maintenance-bbab-v1"
EXPECTED = "bbab98d805f5c44c1a70a91f0dfd98821adddecc"
BASE = "abf75d8e2097785b2ad01897c15a7531eebe6e44"
PACKAGES = ["codex-hepta-agentd", "codex-hepta-intelligence-eval", "codex-hepta-learning-ledger", "codex-hepta-neuron"]


def git(*args):
    return subprocess.check_output(["git", *args], cwd=SOURCE)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(name, data):
    with (RECORDS / name).open("x") as output:
        json.dump(data, output, indent=2, sort_keys=True)


def snapshot(name):
    patch = git("diff", "--binary", "HEAD", "--")
    result = {"head": git("rev-parse", "HEAD").decode().strip(),
              "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
              "status": git("status", "--porcelain=v1", "--untracked-files=all").decode(),
              "patch_sha256": digest(patch), "patch_bytes": len(patch)}
    save(name + ".json", result)
    (RECORDS / (name + ".patch")).write_bytes(patch)
    return result


def main():
    RECORDS.mkdir()
    settings = json.loads((ROOT / "evidence/final-bbab-v1/environment.json").read_text())
    os.environ.update(settings)
    os.chdir(SOURCE)
    before = snapshot("before")
    assert before["head"] == EXPECTED and before["status"] == ""
    for path in [ROOT / "evidence/final-bbab-v1/ordinary.json", ROOT / "evidence/final-bbab-v1/root.json"]:
        rec = json.loads(path.read_text())
        assert rec["status"] == "passed" and rec["source_sha"] == EXPECTED and rec["before"] == rec["after"]
    preserved = {os.fsdecode(raw): digest((SOURCE / os.fsdecode(raw)).read_bytes())
                 for raw in git("ls-files", "-z", "qualification/learn-ordinary-20261110-14cc").split(b"\0") if raw}
    save("preserved-qualification-before.json", preserved)
    pack = ROOT / "format-base-abf.pack"
    assert digest(pack.read_bytes()) == "6a2097ff0d05ebfd18c74f0fa8a9a9b39d5fc0a21c553814c39b171a6cb5d184"
    with pack.open("rb") as stream:
        installed = subprocess.check_output(["git", "index-pack", "--stdin"], stdin=stream, cwd=SOURCE).decode().strip()
    assert git("rev-parse", BASE + "^{tree}").decode().strip() == "d1369f99861524fe49d90cabb57b021e6bac23b8"
    save("format-base.json", {"commit": BASE, "tree": "d1369f99861524fe49d90cabb57b021e6bac23b8",
                              "object_pack_sha256": digest(pack.read_bytes()), "index_pack": installed})
    save("environment.json", settings)
    save("toolchain.json", {name: subprocess.check_output(args, text=True).strip()
                            for name, args in {"rustc": ["rustc", "-vV"], "clippy": ["cargo", "clippy", "--version"],
                                               "rustfmt": ["rustfmt", "--version"], "just": ["just", "--version"]}.items()})
    save("driver.json", {"path": str(Path(__file__).resolve()), "sha256": digest(Path(__file__).read_bytes())})
    sys.path.insert(0, str(SOURCE / "scripts"))
    from hepta_ci_exec import execute_logged
    steps = []
    failed = None

    def stage(name, command, cwd=SOURCE):
        os.chdir(cwd)
        print(json.dumps({"stage": name, "source_head": EXPECTED, "command": command}), flush=True)
        execution = execute_logged(command, RECORDS / (name + ".log"), timeout_seconds=7200)
        record = {"command": command, "working_directory": str(cwd), "source_head": EXPECTED,
                  "kind": "post-test maintenance or compile-only; no behavior execution", **execution}
        save(name + ".json", record)
        steps.append({"stage": name, "exit_code": execution["returncode"]})
        return execution["returncode"] or execution["timed_out"] or execution["output_limit_exceeded"]

    try:
        arguments = [part for package in PACKAGES for part in ["-p", package]]
        if stage("fix", ["just", "fix", "--locked", "--offline", *arguments]):
            failed = "scoped just fix did not complete successfully"
        snapshot("after-fix")
        if stage("fmt", ["just", "fmt", "--base", BASE]):
            failed = failed or "scoped just fmt did not complete successfully"
        maintained = snapshot("after-fmt")
        if stage("compile-only", ["cargo", "check", "--locked", "--offline", *arguments, "--tests", "--bins"], SOURCE / "codex-rs"):
            failed = failed or "post-maintenance compile-only check failed"
        os.chdir(SOURCE)
        assert maintained == snapshot("after-compile"), "compiler check changed source bytes"
    except Exception as error:
        failed = failed or f"{type(error).__name__}: {error}"
    finally:
        os.chdir(SOURCE)
        patch = git("diff", "--binary", "HEAD", "--")
        (RECORDS / "maintenance.patch").write_bytes(patch)
        untracked = git("ls-files", "--others", "--exclude-standard", "-z")
        rows = []
        for raw in git("diff", "--name-only", "--no-renames", "-z", "HEAD", "--").split(b"\0"):
            if not raw:
                continue
            name = os.fsdecode(raw)
            path = SOURCE / name
            if path.is_symlink() or not path.is_file():
                failed = failed or "maintenance altered file kind: " + name
                continue
            data = path.read_bytes()
            row = {"path": name, "bytes": len(data), "sha256": digest(data),
                   "blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
                   "mode": "100755" if path.stat().st_mode & 0o111 else "100644"}
            rows.append(row)
            output = RECORDS / "postimages" / name
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(data)
            if not name.startswith(("codex-rs/hepta-agentd/", "codex-rs/hepta-intelligence-eval/", "codex-rs/hepta-learning-ledger/", "codex-rs/hepta-neuron/")) or not name.endswith(".rs"):
                failed = failed or "maintenance changed a file outside requested Rust owners: " + name
        if untracked:
            failed = failed or "maintenance created untracked source files"
        save("postimages.json", {"source_head": EXPECTED, "format_base": BASE, "patch_sha256": digest(patch),
                                 "patch_bytes": len(patch), "files": rows, "untracked": os.fsdecode(untracked)})
        for path in list(RECORDS.glob("*.log")):
            path.with_suffix(path.suffix + ".gz").write_bytes(gzip.compress(path.read_bytes(), mtime=0))
        preserved_after = {name: digest((SOURCE / name).read_bytes()) for name in preserved}
        save("preserved-qualification-after.json", preserved_after)
        if preserved_after != preserved:
            failed = failed or "preexisting qualification bytes changed"
        final = snapshot("final")
        result = {"tested_source": EXPECTED, "maintained_head_still": final["head"], "steps": steps,
                  "failed": failed is not None, "error": failed, "behavior_tests_after_maintenance": False,
                  "postimage_files": len(rows), "finished_unix": time.time()}
        save("maintenance-status.json", result)
        save("evidence-inventory.json", [{"path": str(path.relative_to(RECORDS)), "bytes": path.stat().st_size,
                                          "sha256": digest(path.read_bytes())} for path in sorted(RECORDS.rglob("*")) if path.is_file()])
        print(json.dumps(result, indent=2), flush=True)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
