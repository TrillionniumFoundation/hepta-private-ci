use super::*;
use ed25519_dalek::Signer;
use ed25519_dalek::SigningKey;
use pretty_assertions::assert_eq;

fn id(value: &str) -> StableId {
    StableId::new(value.to_owned()).expect("valid test id")
}
fn digest(value: &str) -> Digest32 {
    Digest32::of_bytes(value.as_bytes())
}
fn signer(
    name: &str,
    controller: &str,
    seed: u8,
    role: LearningEvidenceRoleV1,
) -> TrustedLearningSignerV1 {
    let key = SigningKey::from_bytes(&[seed; 32])
        .verifying_key()
        .to_bytes();
    TrustedLearningSignerV1 {
        principal: AuthenticatedPrincipalV1 {
            principal_id: id(name),
            credential_chain_digest: digest(name),
            signing_key_digest: Digest32::of_bytes(&key),
            scope_digest: digest("scope"),
            authority_epoch: 7,
            authenticated_at: 10,
            expires_at: 100,
        },
        controller_id: id(controller),
        verifying_key: key,
        roles: vec![role],
        revoked_at: None,
    }
}
fn trust() -> LearningEvidenceTrustV1 {
    LearningEvidenceTrustV1 {
        scope_digest: digest("scope"),
        objective_digest: digest("objective"),
        authority_epoch: 7,
        signers: vec![
            signer(
                "generator",
                "controller-a",
                1,
                LearningEvidenceRoleV1::Generator,
            ),
            signer(
                "evaluator",
                "controller-b",
                2,
                LearningEvidenceRoleV1::Evaluator,
            ),
        ],
    }
}
fn sign(
    verifier: &LearningEvidenceVerifierV1,
    name: &str,
    role: LearningEvidenceRoleV1,
    seed: u8,
    payload: &[u8],
) -> SignedLearningEvidenceV1 {
    let mut evidence = SignedLearningEvidenceV1 {
        evidence_id: id("evidence"),
        principal_id: id(name),
        role,
        trust_digest: verifier.trust_digest(),
        scope_digest: digest("scope"),
        objective_digest: digest("objective"),
        authority_epoch: 7,
        issued_at: 20,
        expires_at: 90,
        payload_digest: Digest32::of_bytes(payload),
        signature: [0; 64],
    };
    evidence.signature = SigningKey::from_bytes(&[seed; 32])
        .sign(&evidence.signing_bytes())
        .to_bytes();
    evidence
}

#[test]
fn original_owner_enrollment_is_read_only_exact_and_current() {
    let mut host = trust();
    host.signers[1].roles.push(LearningEvidenceRoleV1::Observer);
    host.signers[1].revoked_at = Some(80);
    let mut owner = host.signers[1].clone();
    let verifier = LearningEvidenceVerifierV1::new(host).expect("host trust");
    owner.roles.reverse();
    assert_eq!(
        verifier.require_signer_binding(LearningEvidenceRoleV1::Evaluator, &owner, 50),
        Ok(())
    );
    assert_eq!(
        verifier.require_signer_binding(LearningEvidenceRoleV1::Generator, &owner, 50),
        Err(SignedEvidenceError::RoleMismatch)
    );
    assert_eq!(
        verifier.require_signer_binding(LearningEvidenceRoleV1::Evaluator, &owner, 80),
        Err(SignedEvidenceError::Revoked)
    );
    assert!(matches!(
        verifier.require_signer_binding(LearningEvidenceRoleV1::Evaluator, &owner, 101),
        Err(SignedEvidenceError::Principal(_))
    ));
    let mut changed = owner.clone();
    changed.controller_id = id("substituted-controller");
    assert_eq!(
        verifier.require_signer_binding(LearningEvidenceRoleV1::Evaluator, &changed, 50),
        Err(SignedEvidenceError::InvalidTrust)
    );
    changed = owner.clone();
    changed.revoked_at = None;
    assert_eq!(
        verifier.require_signer_binding(LearningEvidenceRoleV1::Evaluator, &changed, 50),
        Err(SignedEvidenceError::InvalidTrust)
    );
    changed = owner.clone();
    changed.roles.push(LearningEvidenceRoleV1::Evaluator);
    assert_eq!(
        verifier.require_signer_binding(LearningEvidenceRoleV1::Evaluator, &changed, 50),
        Err(SignedEvidenceError::InvalidTrust)
    );
    changed = owner;
    changed.principal.principal_id = id("unregistered");
    assert_eq!(
        verifier.require_signer_binding(LearningEvidenceRoleV1::Evaluator, &changed, 50),
        Err(SignedEvidenceError::UnknownSigner)
    );
}

#[test]
fn signed_evidence_binds_actual_bytes_and_credential_not_digest_claims() {
    let verifier = LearningEvidenceVerifierV1::new(trust()).expect("host trust");
    let signed = sign(
        &verifier,
        "evaluator",
        LearningEvidenceRoleV1::Evaluator,
        2,
        b"observed metrics",
    );
    let admitted = verifier
        .verify(
            LearningEvidenceRoleV1::Evaluator,
            &signed,
            b"observed metrics",
            50,
        )
        .expect("authentic evidence");
    assert_eq!(admitted.principal(), &trust().signers[1].principal);
    assert_eq!(
        verifier.verify(
            LearningEvidenceRoleV1::Evaluator,
            &signed,
            b"edited metrics",
            50
        ),
        Err(SignedEvidenceError::PayloadMismatch)
    );
    let forged = sign(
        &verifier,
        "evaluator",
        LearningEvidenceRoleV1::Evaluator,
        1,
        b"observed metrics",
    );
    assert_eq!(
        verifier.verify(
            LearningEvidenceRoleV1::Evaluator,
            &forged,
            b"observed metrics",
            50
        ),
        Err(SignedEvidenceError::InvalidSignature)
    );
    let mut edited = signed;
    edited.evidence_id = id("relabelled");
    assert_eq!(
        verifier.verify(
            LearningEvidenceRoleV1::Evaluator,
            &edited,
            b"observed metrics",
            50
        ),
        Err(SignedEvidenceError::InvalidSignature)
    );
}

#[test]
fn trust_epoch_revocation_scope_and_expiry_fail_closed() {
    let verifier = LearningEvidenceVerifierV1::new(trust()).expect("host trust");
    let signed = sign(
        &verifier,
        "evaluator",
        LearningEvidenceRoleV1::Evaluator,
        2,
        b"metrics",
    );
    let mut new_trust = trust();
    new_trust.authority_epoch = 8;
    for signer in &mut new_trust.signers {
        signer.principal.authority_epoch = 8;
    }
    let rotated = LearningEvidenceVerifierV1::new(new_trust).expect("rotated trust");
    assert_eq!(
        rotated.verify(LearningEvidenceRoleV1::Evaluator, &signed, b"metrics", 50),
        Err(SignedEvidenceError::ContextMismatch)
    );
    let mut revoked_trust = trust();
    revoked_trust.signers[1].revoked_at = Some(40);
    let revoked = LearningEvidenceVerifierV1::new(revoked_trust).expect("revoked trust");
    let resigned = sign(
        &revoked,
        "evaluator",
        LearningEvidenceRoleV1::Evaluator,
        2,
        b"metrics",
    );
    assert_eq!(
        revoked.verify(LearningEvidenceRoleV1::Evaluator, &resigned, b"metrics", 50),
        Err(SignedEvidenceError::Revoked)
    );
    let observer_before_revocation = revoked
        .verify(LearningEvidenceRoleV1::Evaluator, &resigned, b"metrics", 30)
        .expect("not yet revoked");
    let generator_before_revocation = revoked
        .verify(
            LearningEvidenceRoleV1::Generator,
            &sign(
                &revoked,
                "generator",
                LearningEvidenceRoleV1::Generator,
                1,
                b"plan",
            ),
            b"plan",
            30,
        )
        .expect("generator");
    assert_eq!(
        verify_signed_role_separation(
            &generator_before_revocation,
            &observer_before_revocation,
            50
        ),
        Err(SignedEvidenceError::Revoked)
    );
    assert_eq!(
        verify_signed_role_separation(
            &generator_before_revocation,
            &observer_before_revocation,
            15
        ),
        Err(SignedEvidenceError::ValidityWindow)
    );
    assert_eq!(
        verifier.verify(LearningEvidenceRoleV1::Evaluator, &signed, b"metrics", 91),
        Err(SignedEvidenceError::ValidityWindow)
    );
    let mut wrong_scope = signed.clone();
    wrong_scope.scope_digest = digest("other-scope");
    assert_eq!(
        verifier.verify(
            LearningEvidenceRoleV1::Evaluator,
            &wrong_scope,
            b"metrics",
            50
        ),
        Err(SignedEvidenceError::ContextMismatch)
    );
    assert_eq!(
        verifier.verify(LearningEvidenceRoleV1::Observer, &signed, b"metrics", 50),
        Err(SignedEvidenceError::RoleMismatch)
    );
}

#[test]
fn distinct_keys_do_not_make_one_controller_independent() {
    let mut shared = trust();
    shared.signers[1].controller_id = shared.signers[0].controller_id.clone();
    let verifier = LearningEvidenceVerifierV1::new(shared).expect("host trust");
    let generator = verifier
        .verify(
            LearningEvidenceRoleV1::Generator,
            &sign(
                &verifier,
                "generator",
                LearningEvidenceRoleV1::Generator,
                1,
                b"plan",
            ),
            b"plan",
            50,
        )
        .expect("generator");
    let evaluator = verifier
        .verify(
            LearningEvidenceRoleV1::Evaluator,
            &sign(
                &verifier,
                "evaluator",
                LearningEvidenceRoleV1::Evaluator,
                2,
                b"metrics",
            ),
            b"metrics",
            50,
        )
        .expect("evaluator");
    assert_eq!(
        verify_signed_role_separation(&generator, &evaluator, 50),
        Err(SignedEvidenceError::ControllerCollision)
    );
    let verifier = LearningEvidenceVerifierV1::new(trust()).expect("independent trust");
    let generator = verifier
        .verify(
            LearningEvidenceRoleV1::Generator,
            &sign(
                &verifier,
                "generator",
                LearningEvidenceRoleV1::Generator,
                1,
                b"plan",
            ),
            b"plan",
            50,
        )
        .expect("generator");
    let evaluator = verifier
        .verify(
            LearningEvidenceRoleV1::Evaluator,
            &sign(
                &verifier,
                "evaluator",
                LearningEvidenceRoleV1::Evaluator,
                2,
                b"metrics",
            ),
            b"metrics",
            50,
        )
        .expect("evaluator");
    assert_eq!(
        verify_signed_role_separation(&generator, &evaluator, 50),
        Ok(())
    );
}

#[test]
fn observer_and_evaluator_require_pairwise_independence() {
    let mut independent = trust();
    independent.signers.push(signer(
        "observer",
        "controller-c",
        3,
        LearningEvidenceRoleV1::Observer,
    ));
    let verifier = LearningEvidenceVerifierV1::new(independent).expect("host trust");
    let observer = verifier
        .verify(
            LearningEvidenceRoleV1::Observer,
            &sign(
                &verifier,
                "observer",
                LearningEvidenceRoleV1::Observer,
                3,
                b"frontier",
            ),
            b"frontier",
            50,
        )
        .expect("observer");
    let evaluator = verifier
        .verify(
            LearningEvidenceRoleV1::Evaluator,
            &sign(
                &verifier,
                "evaluator",
                LearningEvidenceRoleV1::Evaluator,
                2,
                b"metrics",
            ),
            b"metrics",
            50,
        )
        .expect("evaluator");
    assert_eq!(
        verify_signed_independent_roles_v1(&observer, &evaluator, 50),
        Ok(())
    );

    let mut shared = trust();
    shared.signers.push(signer(
        "observer",
        "controller-b",
        3,
        LearningEvidenceRoleV1::Observer,
    ));
    let verifier = LearningEvidenceVerifierV1::new(shared).expect("shared controller trust");
    let observer = verifier
        .verify(
            LearningEvidenceRoleV1::Observer,
            &sign(
                &verifier,
                "observer",
                LearningEvidenceRoleV1::Observer,
                3,
                b"frontier",
            ),
            b"frontier",
            50,
        )
        .expect("observer");
    let evaluator = verifier
        .verify(
            LearningEvidenceRoleV1::Evaluator,
            &sign(
                &verifier,
                "evaluator",
                LearningEvidenceRoleV1::Evaluator,
                2,
                b"metrics",
            ),
            b"metrics",
            50,
        )
        .expect("evaluator");
    assert_eq!(
        verify_signed_independent_roles_v1(&observer, &evaluator, 50),
        Err(SignedEvidenceError::ControllerCollision)
    );
}
