//! Deterministic, bounded temporal signal runtime for qualification use.
//!
//! Pure mechanisms emit state and signal receipts. An optional host-authorized
//! journal persists owned checkpoints; it grants no model dispatch, physical
//! effect, selection, promotion or release authority.

#![forbid(unsafe_code)]

use std::error::Error as StdError;
use std::fmt;

use codex_hepta_types::AuthorityPosture;
use codex_hepta_types::Digest32;
use codex_hepta_types::FixedQ32;
use codex_hepta_types::Generation;
use codex_hepta_types::StableId;

pub use codex_hepta_infer_core::NeuronFeatureObservationV1;
pub use codex_hepta_infer_core::NeuronFeatureReceiptV1;
pub use codex_hepta_infer_core::NeuronFeatureRequestV1;
pub use codex_hepta_infer_core::NeuronFeatureTerminalStatusV1;
pub use codex_hepta_infer_core::NeuronModelRuntimeTupleV1;
pub use codex_hepta_infer_core::durable_control::DurableInferenceControl;

mod cell;
mod cell_batch;
mod cell_binding;
mod cell_generation_control;
mod cell_generation_current;
mod cell_generation_journal;
mod cell_generation_observation;
mod cell_generation_state;
mod cell_generation_types;
mod cell_inference;
#[cfg(target_os = "linux")]
mod cell_joint_generation;
#[cfg(target_os = "linux")]
mod cell_joint_observed;
#[cfg(target_os = "linux")]
mod cell_joint_process;
#[cfg(target_os = "linux")]
mod cell_joint_protocol;
mod cell_journal;
mod cell_journal_codec;
mod cell_owner;
mod cell_task_cost;
#[cfg(test)]
mod cell_test_support;
mod cell_types;
mod cell_update;
#[cfg(target_os = "linux")]
mod cell_v13_assets;
#[cfg(target_os = "linux")]
mod cell_v13_generation;
#[cfg(target_os = "linux")]
mod cell_v13_process;
#[cfg(target_os = "linux")]
mod cell_v13_protocol;
mod deletion;
mod feature_control;
mod inference_control;
mod journal;
mod journal_lock;
mod perception;
mod perception_encoder;
mod perception_proposal;
mod perception_source;
#[cfg(test)]
mod perception_test_support;
mod plasticity;
mod population_v2;
mod protocol;
mod qualification;
mod runtime;
mod runtime_types;
mod sparse;
mod witness;

pub use cell::commit_cell_step;
pub use cell::decide_cell;
pub use cell::enter_cell_step;
pub use cell::prepare_cell_step;
pub use cell_batch::CellBatchQueueV1;
pub use cell_batch::CellBatchResultV1;
pub use cell_batch::CellMicrobatchInferenceControlPortV1;
pub use cell_binding::canonical_cell_step_request_digest_v1;
pub use cell_generation_control::CellGenerationWorkerV2;
pub use cell_generation_control::ControlledCellGenerationConfigV2;
pub use cell_generation_control::ControlledCellGenerationPortV2;
pub use cell_generation_current::CellGenerationCurrentV1;
pub use cell_generation_current::CellGenerationOpenModeV1;
pub use cell_generation_current::CellGenerationOwnerBindingV1;
pub use cell_generation_current::CellGenerationPreparedCheckpointV1;
pub use cell_generation_journal::CellGenerationExpectedContextV1;
pub use cell_generation_journal::CellGenerationJournalV2;
pub use cell_generation_observation::CellGenerationObservationV1;
pub use cell_generation_state::CellGenerationConfigV2;
pub use cell_generation_types::CellBackendManifestV2;
pub use cell_generation_types::CellEvolutionBindingV2;
pub use cell_generation_types::CellGenerationControlPortV2;
pub use cell_generation_types::CellGenerationDispositionV2;
pub use cell_generation_types::CellGenerationErrorV2;
pub use cell_generation_types::CellGenerationIntentV2;
pub use cell_generation_types::CellGenerationProposalV2;
pub use cell_generation_types::CellGenerationReceiptV2;
pub use cell_generation_types::CellGenerationRequestV2;
pub use cell_generation_types::CellGenerationScopeV2;
pub use cell_generation_types::CellLearningBindingV2;
pub use cell_generation_types::CellOutputChunkV2;
pub use cell_generation_types::CellRuntimeSnapshotV2;
pub use cell_inference::CellInferenceReadbackPortV1;
pub use cell_inference::infer_cell;
pub use cell_inference::infer_cell_with_clock;
pub use cell_inference::recover_cell_inference;
#[cfg(target_os = "linux")]
pub use cell_joint_generation::JointGenerationProcessConfigV1;
#[cfg(target_os = "linux")]
pub use cell_joint_generation::JointGenerationProcessFilesV1;
#[cfg(target_os = "linux")]
pub use cell_joint_generation::JointGenerationProcessWorkerV1;
#[cfg(target_os = "linux")]
pub use cell_joint_observed::JointGenerationCommandV2;
#[cfg(target_os = "linux")]
pub use cell_joint_observed::JointGenerationDeliveryContractV2;
#[cfg(target_os = "linux")]
pub use cell_joint_observed::JointGenerationInputV2;
#[cfg(target_os = "linux")]
pub use cell_joint_protocol::JointGenerationActionV1;
#[cfg(target_os = "linux")]
pub use cell_joint_protocol::JointGenerationCommandV1;
#[cfg(target_os = "linux")]
pub use cell_joint_protocol::JointGenerationInputV1;
#[cfg(target_os = "linux")]
pub use cell_joint_protocol::JointGenerationModalityV1;
#[cfg(target_os = "linux")]
pub use cell_joint_protocol::JointGenerationSamplerV1;
pub use cell_journal::CellJournalPartitionV1;
pub use cell_journal::CellOwnerJournalReadbackV1;
pub use cell_journal::CellOwnerJournalV1;
pub use cell_owner::CellPartitionOwnerV1;
pub use cell_task_cost::CellCostAccountingV2;
pub use cell_task_cost::CellCostEntryV2;
pub use cell_task_cost::CellCostMetricsV2;
pub use cell_task_cost::CellCostOutcomeV2;
pub use cell_task_cost::CellCostRecordV2;
pub use cell_task_cost::CellCostStageV2;
pub use cell_task_cost::CellCostTotalV2;
pub use cell_task_cost::CellTaskCostErrorV2;
pub use cell_task_cost::CellTaskCostIdentityV2;
pub use cell_task_cost::CellTaskCostSummaryV2;
pub use cell_task_cost::CellTaskCostV2;
pub use cell_types::CellCandidateKindV1;
pub use cell_types::CellCandidateMaskV1;
pub use cell_types::CellCandidateV1;
pub use cell_types::CellDecisionReceiptV1;
pub use cell_types::CellDefinitionV1;
pub use cell_types::CellEncodedInputV1;
pub use cell_types::CellEncodingRequestV1;
pub use cell_types::CellExecutionCostV1;
pub use cell_types::CellExecutionError;
pub use cell_types::CellInferenceAdmissionV1;
pub use cell_types::CellInputEncoderV1;
pub use cell_types::CellOwnerSnapshotV1;
pub use cell_types::CellPolicyEntryV1;
pub use cell_types::CellRepresentationV1;
pub use cell_types::CellScopeV1;
pub use cell_types::CellStateOwnerV1;
pub use cell_types::CellStateProposalV1;
pub use cell_types::CellStepEntryV1;
pub use cell_types::CellStepInputV1;
pub use cell_types::InferredCellStepV1;
pub use cell_types::PreparedCellStepV1;
pub use cell_update::CellUpdateBudgetV1;
pub use cell_update::CellUpdateCandidateV1;
pub use cell_update::CellUpdateOutcomeV1;
pub use cell_update::CellUpdatePortV1;
pub use cell_update::CellUpdateRequestV1;
pub use cell_update::propose_cell_update;
#[cfg(target_os = "linux")]
pub use cell_v13_generation::V13GenerationAssetFileV1;
#[cfg(target_os = "linux")]
pub use cell_v13_generation::V13GenerationProcessConfigV1;
#[cfg(target_os = "linux")]
pub use cell_v13_generation::V13GenerationProcessFilesV1;
#[cfg(target_os = "linux")]
pub use cell_v13_generation::V13GenerationProcessWorkerV1;
#[cfg(target_os = "linux")]
pub use cell_v13_protocol::V13LearningClosureV1;
#[cfg(target_os = "linux")]
pub use cell_v13_protocol::V13TaskInputV1;
pub use deletion::DeletionRebuildError;
pub use deletion::NeuronDeletionRebuildPlanV1;
pub use deletion::NeuronDeletionRebuildReceiptV1;
pub use deletion::validate_deletion_rebuild;
pub use feature_control::ControlledNeuronFeaturePortV1;
pub use feature_control::NeuronFeatureWorkerV1;
pub use inference_control::InferenceControlModelPort;
pub use inference_control::NeuronInferenceControlPort;
pub use journal::JournalAnchor;
pub use journal::JournalError;
pub use journal::JournalScope;
pub use journal::SparseJournal;
pub use perception::PerceptionEncoderBindingV1;
pub use perception::PerceptionLatentV1;
pub use perception::PerceptionObservationV1;
pub use perception::PerceptionRepresentationV1;
pub use perception_encoder::PerceptionCellEncoderV1;
pub use perception_proposal::PerceptionObservationProposalV1;
pub use perception_proposal::PerceptionObservationTargetV1;
pub use perception_proposal::PerceptionProposalAssessmentV1;
pub use perception_proposal::PerceptionProposalDispositionV1;
pub use perception_proposal::PerceptionProposalErrorV1;
pub use perception_proposal::PerceptionProposalPolicyV1;
pub use perception_source::PerceptionActorSourceV1;
pub use perception_source::PerceptionCoordinatesV1;
pub use perception_source::PerceptionErrorV1;
pub use perception_source::PerceptionEvidenceV1;
pub use perception_source::PerceptionSourceLayoutV1;
pub use perception_source::PerceptionSourcePinV1;
pub use plasticity::EligibilityTraceSampleV1;
pub use plasticity::IndependentModulatorV1;
pub use plasticity::ParameterGroupDeltaV1;
pub use plasticity::ParameterGroupMapV1;
pub use plasticity::PlasticityError;
pub use plasticity::PlasticitySufficientStatisticsV1;
pub use plasticity::PlasticityTrustRegionV1;
pub use plasticity::accumulate_plasticity;
pub use population_v2::ActivationPopulationV2;
pub use population_v2::PopulationSparseCheckpointV2;
pub use population_v2::PopulationSparseConfigV2;
pub use population_v2::PopulationSparseError;
pub use population_v2::PopulationSparseSignalReceiptV2;
pub use population_v2::PopulationSparseTickV2;
pub use population_v2::TemporalProjectionEdgeV2;
pub use population_v2::population_sparse_tick_v2;
pub use protocol::NeuronActivationSummaryV1;
pub use protocol::NeuronCheckpointV1;
pub use protocol::NeuronProtocolError;
pub use protocol::NeuronRuntimeConfigProtocolV1;
pub use protocol::NeuronTickReceiptProtocolV1;
pub use protocol::canonical_checkpoint_v1;
pub use protocol::canonical_runtime_config_v1;
pub use protocol::canonical_tick_receipt_v1;
pub use protocol::decode_neuron_checkpoint_v1;
pub use protocol::decode_neuron_runtime_config_v1;
pub use protocol::decode_neuron_signal_receipt_v1;
pub use protocol::decode_neuron_tick_input_v1;
pub use protocol::decode_neuron_tick_receipt_v1;
pub use protocol::encode_neuron_checkpoint_v1;
pub use protocol::encode_neuron_runtime_config_v1;
pub use protocol::encode_neuron_signal_receipt_v1;
pub use protocol::encode_neuron_tick_input_v1;
pub use protocol::encode_neuron_tick_receipt_v1;
pub use qualification::NeuronAblationProfileV1;
pub use qualification::NeuronResourceSampleV1;
pub use qualification::NeuronResourceSummaryV1;
pub use qualification::QualificationError;
pub use qualification::ablate_eligibility_history;
pub use qualification::ablate_parameter_groups;
pub use qualification::ablate_sparse_config;
pub use qualification::requires_external_replay_ablation;
pub use qualification::summarize_resource_samples;
pub use runtime::NeuronRuntime;
pub use runtime_types::AnchorWitnessStore;
pub use runtime_types::LocalModelRuntimeReceiptV1;
pub use runtime_types::NeuronCalibrationProfileV1;
pub use runtime_types::NeuronModelError;
pub use runtime_types::NeuronModelOutputV1;
pub use runtime_types::NeuronModelPort;
pub use runtime_types::NeuronModelRequestV1;
pub use runtime_types::NeuronResourceEnvelopeV1;
pub use runtime_types::NeuronResourceReceiptV1;
pub use runtime_types::NeuronRuntimeConfigV1;
pub use runtime_types::NeuronRuntimeError;
pub use runtime_types::NeuronRuntimeOutputV1;
pub use runtime_types::NeuronSignalReceiptV1;
pub use runtime_types::NeuronTickInputV1;
pub use runtime_types::NeuronTickReceiptV1;
pub use runtime_types::WitnessStoreError;
pub use runtime_types::canonical_feature_vector_digest_v1;
pub use runtime_types::canonical_model_output_digest_v1;
pub use sparse::InhibitoryEdge;
pub use sparse::SparseCheckpoint;
pub use sparse::SparseConfig;
pub use sparse::SparseError;
pub use sparse::SparseSignalReceipt;
pub use sparse::SparseTick;
pub use sparse::sparse_tick;
pub use witness::FileAnchorWitnessStore;

const MAX_FEATURES: usize = 4_096;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NeuronState {
    pub model_digest: Digest32,
    pub generation: Generation,
    pub values: Vec<FixedQ32>,
    pub state_digest: Digest32,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StepRequest {
    pub run_id: StableId,
    pub model_digest: Digest32,
    pub source_digest: Digest32,
    pub generation: Generation,
    pub decay: FixedQ32,
    pub features: Vec<FixedQ32>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NeuronSignalReceipt {
    pub run_id: StableId,
    pub model_digest: Digest32,
    pub source_digest: Digest32,
    pub state_digest: Digest32,
    pub signal_digest: Digest32,
    pub authority: AuthorityPosture,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Error {
    EmptyFeatures,
    FeatureLimitExceeded,
    EmptyDigest(&'static str),
    InvalidDecay,
    ModelDrift,
    WidthDrift,
    GenerationNotAdvanced,
    Arithmetic,
}

impl fmt::Display for Error {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{self:?}")
    }
}

impl StdError for Error {}

pub fn step(
    request: StepRequest,
    previous: Option<&NeuronState>,
) -> Result<(NeuronState, NeuronSignalReceipt), Error> {
    validate_request(&request, previous)?;

    let complement = FixedQ32::ONE
        .checked_sub(request.decay)
        .map_err(|_| Error::Arithmetic)?;
    let mut values = Vec::with_capacity(request.features.len());
    for (index, feature) in request.features.iter().copied().enumerate() {
        let prior = previous.map_or(FixedQ32::ZERO, |state| state.values[index]);
        let retained = prior
            .checked_mul(request.decay)
            .map_err(|_| Error::Arithmetic)?;
        let injected = feature
            .checked_mul(complement)
            .map_err(|_| Error::Arithmetic)?;
        values.push(
            retained
                .checked_add(injected)
                .map_err(|_| Error::Arithmetic)?,
        );
    }

    let previous_digest = previous.map_or(Digest32::ZERO, |state| state.state_digest);
    let state_digest = digest_state(&request, previous_digest, &values);
    let signal_digest = digest_signal(&request, state_digest, &values);
    let state = NeuronState {
        model_digest: request.model_digest,
        generation: request.generation,
        values,
        state_digest,
    };
    let receipt = NeuronSignalReceipt {
        run_id: request.run_id,
        model_digest: request.model_digest,
        source_digest: request.source_digest,
        state_digest,
        signal_digest,
        authority: AuthorityPosture::DENY_ALL,
    };
    Ok((state, receipt))
}

fn validate_request(request: &StepRequest, previous: Option<&NeuronState>) -> Result<(), Error> {
    if request.features.is_empty() {
        return Err(Error::EmptyFeatures);
    }
    if request.features.len() > MAX_FEATURES {
        return Err(Error::FeatureLimitExceeded);
    }
    if request.model_digest.is_zero() {
        return Err(Error::EmptyDigest("model"));
    }
    if request.source_digest.is_zero() {
        return Err(Error::EmptyDigest("source"));
    }
    if request.decay < FixedQ32::ZERO || request.decay > FixedQ32::ONE {
        return Err(Error::InvalidDecay);
    }
    if let Some(state) = previous {
        if state.model_digest != request.model_digest {
            return Err(Error::ModelDrift);
        }
        if state.values.len() != request.features.len() {
            return Err(Error::WidthDrift);
        }
        if request.generation <= state.generation {
            return Err(Error::GenerationNotAdvanced);
        }
        if state.state_digest.is_zero() {
            return Err(Error::EmptyDigest("previous state"));
        }
    }
    Ok(())
}

fn digest_state(request: &StepRequest, previous_digest: Digest32, values: &[FixedQ32]) -> Digest32 {
    let mut bytes = Vec::new();
    bytes.extend_from_slice(b"hepta.neuron.state.v1");
    push_id(&mut bytes, &request.run_id);
    bytes.extend_from_slice(request.model_digest.as_array());
    bytes.extend_from_slice(request.source_digest.as_array());
    bytes.extend_from_slice(&request.generation.get().to_be_bytes());
    bytes.extend_from_slice(&request.decay.raw().to_be_bytes());
    bytes.extend_from_slice(previous_digest.as_array());
    for value in values {
        bytes.extend_from_slice(&value.raw().to_be_bytes());
    }
    Digest32::of_bytes(&bytes)
}

fn digest_signal(request: &StepRequest, state_digest: Digest32, values: &[FixedQ32]) -> Digest32 {
    let mut bytes = Vec::new();
    bytes.extend_from_slice(b"hepta.neuron.signal.v1");
    push_id(&mut bytes, &request.run_id);
    bytes.extend_from_slice(state_digest.as_array());
    for value in values {
        bytes.extend_from_slice(&value.raw().to_be_bytes());
    }
    Digest32::of_bytes(&bytes)
}

fn push_id(bytes: &mut Vec<u8>, value: &StableId) {
    let raw = value.as_str().as_bytes();
    bytes.extend_from_slice(&u32::try_from(raw.len()).unwrap_or(u32::MAX).to_be_bytes());
    bytes.extend_from_slice(raw);
}

#[cfg(test)]
#[path = "lib_tests.rs"]
mod tests;
