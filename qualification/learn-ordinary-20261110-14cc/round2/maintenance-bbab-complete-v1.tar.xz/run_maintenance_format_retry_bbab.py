"""Retry only formatting after exact baseline tree hydration; no behavior tests."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import run_maintenance_bbab as original

ROOT = original.ROOT
SOURCE = original.SOURCE
EXPECTED = original.EXPECTED
BASE = original.BASE
PACKAGES = original.PACKAGES
PRIOR = ROOT / "evidence/maintenance-bbab-v1"
RECORDS = ROOT / "evidence/maintenance-bbab-format-retry-v1"
original.RECORDS = RECORDS
git = original.git
digest = original.digest
save = original.save
snapshot = original.snapshot


def main():
    RECORDS.mkdir()
    settings = json.loads((ROOT / "evidence/final-bbab-v1/environment.json").read_text())
    os.environ.update(settings)
    os.chdir(SOURCE)
    before = snapshot("before")
    prior_final = json.loads((PRIOR / "final.json").read_text())
    prior_status = json.loads((PRIOR / "maintenance-status.json").read_text())
    assert before == prior_final and before["head"] == EXPECTED
    assert prior_status["steps"] == [
        {"stage": "fix", "exit_code": 0},
        {"stage": "fmt", "exit_code": 2},
        {"stage": "compile-only", "exit_code": 0},
    ]
    save("prior-attempt.json", {"path": str(PRIOR), "status": prior_status,
                               "status_sha256": digest((PRIOR / "maintenance-status.json").read_bytes())})
    preserved = json.loads((PRIOR / "preserved-qualification-before.json").read_text())
    assert {name: digest((SOURCE / name).read_bytes()) for name in preserved} == preserved
    save("preserved-qualification-before.json", preserved)
    pack = ROOT / "format-base-abf-bbab-missing-trees.pack"
    assert digest(pack.read_bytes()) == "800f772466d565332247263adf21be62ffd95d3a9d2868ece4117c6bbe4f11a8"
    with pack.open("rb") as stream:
        indexed = subprocess.check_output(["git", "index-pack", "--stdin"], stdin=stream, cwd=SOURCE).decode().strip()
    tree = git("rev-parse", BASE + "^{tree}").decode().strip()
    assert tree == "d1369f99861524fe49d90cabb57b021e6bac23b8"
    scope = git("diff", "--name-only", "--diff-filter=ACDMRT", "--no-renames", "-z", BASE, "--")
    save("format-base.json", {"commit": BASE, "tree": tree, "pack_sha256": digest(pack.read_bytes()),
                              "index_pack": indexed, "scope_paths": [os.fsdecode(p) for p in scope.split(b"\0") if p]})
    save("environment.json", settings)
    save("driver.json", {"path": str(Path(__file__).resolve()), "sha256": digest(Path(__file__).read_bytes()),
                         "imported_driver_sha256": digest(Path(original.__file__).read_bytes())})
    sys.path.insert(0, str(SOURCE / "scripts"))
    from hepta_ci_exec import execute_logged
    steps = []
    failed = None

    def stage(name, command, cwd=SOURCE):
        os.chdir(cwd)
        print(json.dumps({"stage": name, "source_head": EXPECTED, "command": command}), flush=True)
        execution = execute_logged(command, RECORDS / (name + ".log"), timeout_seconds=7200)
        save(name + ".json", {"command": command, "working_directory": str(cwd), "source_head": EXPECTED,
                              "kind": "formatter retry or compile-only; no behavior execution", **execution})
        steps.append({"stage": name, "exit_code": execution["returncode"]})
        return execution["returncode"] or execution["timed_out"] or execution["output_limit_exceeded"]

    try:
        if stage("fmt", ["just", "fmt", "--base", BASE]):
            failed = "format retry did not complete successfully"
        maintained = snapshot("after-fmt")
        arguments = [part for package in PACKAGES for part in ["-p", package]]
        if stage("compile-only", ["cargo", "check", "--locked", "--offline", *arguments, "--tests", "--bins"], SOURCE / "codex-rs"):
            failed = failed or "post-format compile-only check failed"
        os.chdir(SOURCE)
        assert maintained == snapshot("after-compile"), "compiler check changed source bytes"
    except Exception as error:
        failed = failed or f"{type(error).__name__}: {error}"
    finally:
        os.chdir(SOURCE)
        patch = git("diff", "--binary", "HEAD", "--")
        (RECORDS / "maintenance.patch").write_bytes(patch)
        untracked = git("ls-files", "--others", "--exclude-standard", "-z")
        rows = []
        for raw in git("diff", "--name-only", "--no-renames", "-z", "HEAD", "--").split(b"\0"):
            if not raw:
                continue
            name = os.fsdecode(raw)
            path = SOURCE / name
            if path.is_symlink() or not path.is_file():
                failed = failed or "maintenance altered file kind: " + name
                continue
            data = path.read_bytes()
            row = {"path": name, "bytes": len(data), "sha256": digest(data),
                   "blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
                   "mode": "100755" if path.stat().st_mode & 0o111 else "100644"}
            rows.append(row)
            output = RECORDS / "postimages" / name
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(data)
            if not name.startswith(("codex-rs/hepta-agentd/", "codex-rs/hepta-intelligence-eval/", "codex-rs/hepta-learning-ledger/", "codex-rs/hepta-neuron/")) or not name.endswith(".rs"):
                failed = failed or "maintenance changed file outside requested Rust owners: " + name
        if untracked:
            failed = failed or "maintenance created untracked source files"
        save("postimages.json", {"source_head": EXPECTED, "format_base": BASE, "patch_sha256": digest(patch),
                                 "patch_bytes": len(patch), "files": rows, "untracked": os.fsdecode(untracked)})
        for path in list(RECORDS.glob("*.log")):
            path.with_suffix(path.suffix + ".gz").write_bytes(gzip.compress(path.read_bytes(), mtime=0))
        preserved_after = {name: digest((SOURCE / name).read_bytes()) for name in preserved}
        save("preserved-qualification-after.json", preserved_after)
        if preserved_after != preserved:
            failed = failed or "preexisting qualification bytes changed"
        final = snapshot("final")
        result = {"tested_source": EXPECTED, "maintained_head_still": final["head"], "steps": steps,
                  "failed": failed is not None, "error": failed, "behavior_tests_after_maintenance": False,
                  "fix_repeated": False, "postimage_files": len(rows), "finished_unix": time.time()}
        save("maintenance-status.json", result)
        save("evidence-inventory.json", [{"path": str(path.relative_to(RECORDS)), "bytes": path.stat().st_size,
                                          "sha256": digest(path.read_bytes())} for path in sorted(RECORDS.rglob("*")) if path.is_file()])
        print(json.dumps(result, indent=2), flush=True)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
