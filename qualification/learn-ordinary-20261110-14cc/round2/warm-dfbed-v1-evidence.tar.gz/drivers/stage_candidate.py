"""Import one pinned source bundle into this round's idle task checkout."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path('/home/qq/hepta-learn-ordinary-14cc-round2-20261110')
SOURCE=ROOT/'source'
bundle_name,sha256,expected,name=sys.argv[1:]
assert re.fullmatch(r'[a-z0-9.-]+',bundle_name)
assert re.fullmatch(r'[0-9a-f]{64}',sha256)
assert re.fullmatch(r'[0-9a-f]{40}',expected)
assert re.fullmatch(r'[a-z0-9-]+',name)
bundle=ROOT/bundle_name
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==sha256
assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=SOURCE,text=True).strip()==''
assert subprocess.check_output(['git','bundle','list-heads',str(bundle)],cwd=SOURCE,text=True).strip()==expected+' HEAD'
before=subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=SOURCE,text=True).splitlines()
subprocess.run(['git','bundle','verify',str(bundle)],cwd=SOURCE,check=True)
subprocess.run(['git','fetch',str(bundle),'HEAD'],cwd=SOURCE,check=True)
subprocess.run(['git','checkout','--detach',expected],cwd=SOURCE,check=True)
after=subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=SOURCE,text=True).splitlines()
assert after[0]==expected
assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=SOURCE,text=True).strip()==''
with (ROOT/(name+'-source-import.json')).open('x') as f:
    json.dump({'schema':'hepta.learn.source.import.v1','before':before,'after':after,'bundle':str(bundle),'sha256':sha256,'finished_unix':time.time()},f,indent=2)
raise SystemExit(subprocess.run(['python3',str(ROOT/'run_native_candidate.py'),name,expected],cwd=ROOT).returncode)
