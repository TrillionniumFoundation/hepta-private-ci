import base64, hashlib, json, os, pathlib, shutil, subprocess, sys, time, traceback, zipfile
started=time.perf_counter()
SOURCE="a0b38d3d12c45a4fd254ca27fe1d4266b4c75c53"
formal=pathlib.Path("/home/qian-qi/hcsn-sixwork-20261121-e29f")
work=pathlib.Path("/home/qian-qi/hcsn-sixwork-windows-followup-20261121-e29f")
evidence=pathlib.Path("/home/qian-qi/hcsn-sixwork-evidence-20261121-e29f/windows-runfiles-followup")
evidence.mkdir(parents=True, exist_ok=False)
record={"schema":"hcsn-isolated-windows-runfiles-attempt-v1","source":SOURCE,"formal_checkout":str(formal),"worktree":str(work),"state":"running","timeout_seconds":300,"cpu_quota_percent":100,"memory_max_bytes":6442450944,"full_build_or_test_requested":False,"patch_sha256":"9b1093b603b2b6dcd127b85323b27a89ab867ecfc24ab120643ec16c61204bc4","steps":[]}
def save():
    (evidence/"receipt.json").write_text(json.dumps(record,indent=2)+"\n")
def run(label,args,cwd,required=True):
    entry={"label":label,"argv":list(args),"cwd":str(cwd),"state":"running"}
    entry["stdout"]=str(evidence/(label+".stdout"))
    entry["stderr"]=str(evidence/(label+".stderr"))
    record["steps"].append(entry); record["active_step"]=label; save()
    print("START "+label,flush=True)
    t=time.perf_counter()
    with open(entry["stdout"],"xb") as out, open(entry["stderr"],"xb") as err:
        rc=subprocess.call(args,cwd=cwd,env=os.environ.copy(),stdout=out,stderr=err)
    entry.update(state="finished",exit_code=rc,wall_seconds=time.perf_counter()-t)
    save(); print("END "+label+" exit="+str(rc)+" wall="+str(entry["wall_seconds"]),flush=True)
    if required and rc: raise RuntimeError(label+" exited "+str(rc))
    return pathlib.Path(entry["stdout"]).read_bytes()
def digest(path):
    data=path.read_bytes()
    return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}
def gittext(label,args,cwd=formal):
    return run(label,["/usr/bin/git",*args],cwd).decode().strip()
def formal_sparse_identity(label):
    path=pathlib.Path(gittext(label,["rev-parse","--git-path","info/sparse-checkout"]))
    if not path.is_absolute(): path=formal/path
    return {"path":str(path),**digest(path)}
try:
    record["formal_head_before"]=gittext("formal-head-before",["rev-parse","HEAD"])
    if record["formal_head_before"]!=SOURCE: raise RuntimeError("formal source drift")
    clean=run("formal-status-before",["/usr/bin/git","status","--porcelain","--untracked-files=normal"],formal)
    if clean: raise RuntimeError("formal source is dirty")
    record["formal_sparse_before"]=formal_sparse_identity("formal-sparse-before")
    if hashlib.sha256((formal/"AGENTS.md").read_bytes()).hexdigest()!="c3f80e8386eb170b00af1e21de40d770c4941e464915687e728e2d14a7e79480":
        raise RuntimeError("unreviewed root AGENTS")
    if work.exists(): raise RuntimeError("isolated worktree already exists; no reuse")
    run("worktree-create",["/usr/bin/git","worktree","add","--detach","--no-checkout",str(work),SOURCE],formal)
    trees=gittext("top-level-tree-dirs",["ls-tree","-d","--name-only",SOURCE],work).splitlines()
    dirs=[d for d in trees if d!="qualification"]
    dirs.extend(["qualification/memory-cell-mem8-ci-followup/pending-model-wire-cache","qualification/memory-cell-mem8-ci-followup/v17/memory-coverage-diagnostic-preparation"])
    record["checkout_scope"]={"all_top_level_directories_except":["qualification"],"formatter_guard_directories":dirs[-2:]}
    run("worktree-materialize",["/usr/bin/git","sparse-checkout","set","--cone",*dirs],work)
    run("checkout-clean",["/usr/bin/git","status","--porcelain","--untracked-files=normal"],work)
    originals={
      "codex-rs/hepta-infer-worker-host/tests/native_host_process_e2e.rs":"8bed084564a7d779f6c26925882713faa224cabf",
      "codex-rs/hepta-infer-worker-host/Cargo.toml":"5acf4b087d087805db81c49e03a9a099c2c4573e"}
    for index,(name,expected) in enumerate(originals.items()):
        got=gittext("verify-original-"+str(index),["hash-object",name],work)
        if got!=expected: raise RuntimeError("original blob mismatch: "+name)
    for name in ["codex-rs/AGENTS.md","codex-rs/hepta-infer-worker-host/AGENTS.md","codex-rs/hepta-infer-worker-host/tests/AGENTS.md"]:
        if (work/name).exists(): raise RuntimeError("unreviewed nested AGENTS: "+name)
    patch=base64.b64decode("LS0tIGEvY29kZXgtcnMvaGVwdGEtaW5mZXItd29ya2VyLWhvc3QvdGVzdHMvbmF0aXZlX2hvc3RfcHJvY2Vzc19lMmUucnMKKysrIGIvY29kZXgtcnMvaGVwdGEtaW5mZXItd29ya2VyLWhvc3QvdGVzdHMvbmF0aXZlX2hvc3RfcHJvY2Vzc19lMmUucnMKQEAgLTEsOCArMSwxMCBAQAordXNlIGNvZGV4X3V0aWxzX2NhcmdvX2Jpbjo6Y2FyZ29fYmluOwogdXNlIHN0ZDo6cHJvY2Vzczo6Q29tbWFuZDsKIAogI1t0ZXN0XQogZm4gbmF0aXZlX3dvcmtlcl9oZWxwX2V4ZWN1dGVzX3RoZV9yZWFsX2JpbmFyeV93aXRob3V0X3N0YXRlKCkgewotICAgIGxldCBvdXRwdXQgPSBDb21tYW5kOjpuZXcoZW52ISgiQ0FSR09fQklOX0VYRV9oZXB0YS1pbmZlci13b3JrZXIiKSkKKyAgICBsZXQgYmluYXJ5ID0gY2FyZ29fYmluKCJoZXB0YS1pbmZlci13b3JrZXIiKS5leHBlY3QoInJlc29sdmUgbmF0aXZlIHdvcmtlciBiaW5hcnkiKTsKKyAgICBsZXQgb3V0cHV0ID0gQ29tbWFuZDo6bmV3KGJpbmFyeSkKICAgICAgICAgLmFyZygiLS1oZWxwIikKICAgICAgICAgLm91dHB1dCgpCiAgICAgICAgIC5leHBlY3QoImV4ZWN1dGUgbmF0aXZlIHdvcmtlciBoZWxwIik7CkBAIC0xNSw3ICsxNyw4IEBACiAKICNbdGVzdF0KIGZuIG5hdGl2ZV93b3JrZXJfZmFpbHNfY2xvc2VkX3dpdGhvdXRfYW5fZXhwbGljaXRfcHJvZmlsZSgpIHsKLSAgICBsZXQgb3V0cHV0ID0gQ29tbWFuZDo6bmV3KGVudiEoIkNBUkdPX0JJTl9FWEVfaGVwdGEtaW5mZXItd29ya2VyIikpCisgICAgbGV0IGJpbmFyeSA9IGNhcmdvX2JpbigiaGVwdGEtaW5mZXItd29ya2VyIikuZXhwZWN0KCJyZXNvbHZlIG5hdGl2ZSB3b3JrZXIgYmluYXJ5Iik7CisgICAgbGV0IG91dHB1dCA9IENvbW1hbmQ6Om5ldyhiaW5hcnkpCiAgICAgICAgIC5vdXRwdXQoKQogICAgICAgICAuZXhwZWN0KCJleGVjdXRlIG5hdGl2ZSB3b3JrZXIgd2l0aG91dCBwcm9maWxlIik7CiAgICAgYXNzZXJ0ISgKLS0tIGEvY29kZXgtcnMvaGVwdGEtaW5mZXItd29ya2VyLWhvc3QvQ2FyZ28udG9tbAorKysgYi9jb2RleC1ycy9oZXB0YS1pbmZlci13b3JrZXItaG9zdC9DYXJnby50b21sCkBAIC00MCw2ICs0MCw3IEBACiAKIFtkZXYtZGVwZW5kZW5jaWVzXQogY29kZXgtaGVwdGEtaW5mZXItY29yZSA9IHsgcGF0aCA9ICIuLi9oZXB0YS1pbmZlci1jb3JlIiwgZmVhdHVyZXMgPSBbInF1YWxpZmljYXRpb24tb3duZWQtZmlsZS1yZWFkIl0gfQorY29kZXgtdXRpbHMtY2FyZ28tYmluID0geyB3b3Jrc3BhY2UgPSB0cnVlIH0KIGNvcmVfdGVzdF9zdXBwb3J0ID0geyB3b3Jrc3BhY2UgPSB0cnVlIH0KIAogdGVtcGZpbGUgPSB7IHdvcmtzcGFjZSA9IHRydWUgfQo=",validate=True)
    if len(patch)!=1352 or hashlib.sha256(patch).hexdigest()!=record["patch_sha256"]: raise RuntimeError("patch bytes mismatch")
    (evidence/"review.patch").write_bytes(patch)
    run("patch-check",["/usr/bin/git","apply","--check",str(evidence/"review.patch")],work)
    run("patch-apply",["/usr/bin/git","apply",str(evidence/"review.patch")],work)
    record["patch_applied"]=True
    real_bazel=shutil.which("bazel")
    if real_bazel is None: raise RuntimeError("Bazel executable missing")
    shim=evidence/"bin"; shim.mkdir()
    shimcode="#!/usr/bin/python3\nimport os,sys\nos.execv("+repr(real_bazel)+",["+repr(real_bazel)+",'--batch',"+repr("--output_user_root="+str(evidence/"bazel-output"))+"]+sys.argv[1:])\n"
    (shim/"bazel").write_text(shimcode); (shim/"bazel").chmod(0o755)
    record["bazel_real_executable"]=real_bazel
    record["bazel_mode"]="temporary PATH shim injects --batch and isolated output_user_root; real repository just recipe"
    os.environ["PATH"]=str(shim)+":"+os.environ["PATH"]
    record["environment"]={k:os.environ[k] for k in ["PATH","CARGO_HTTP_TIMEOUT","CARGO_NET_RETRY","CARGO_BUILD_JOBS","UV_CACHE_DIR","UV_PYTHON","UV_PROJECT_ENVIRONMENT","UV_PYTHON_DOWNLOADS"] if k in os.environ}
    cg=pathlib.Path("/proc/self/cgroup").read_text()
    record["cgroup_membership"]=cg
    for line in cg.splitlines():
        if line.startswith("0::"):
            cgdir=pathlib.Path("/sys/fs/cgroup")/line[3:].lstrip("/")
            record["actual_cgroup_limits"]={n:(cgdir/n).read_text().strip() for n in ["cpu.max","memory.max"] if (cgdir/n).exists()}
    record["before_locks"]={name:digest(work/name) for name in ["codex-rs/Cargo.lock","MODULE.bazel.lock"]}
    save()
    run("cargo-metadata",["/home/qian-qi/.cargo/bin/cargo","metadata","--manifest-path","codex-rs/Cargo.toml","--format-version","1"],work)
    run("bazel-lock-update",["/home/qian-qi/.cargo/bin/just","bazel-lock-update"],work)
    run("bazel-lock-check",["/home/qian-qi/.cargo/bin/just","bazel-lock-check"],work)
    run("just-fmt",["/home/qian-qi/.cargo/bin/just","fmt","--base",SOURCE],work/"codex-rs")
    record["state"]="success"
except Exception as exc:
    record["state"]="blocked"; record["error"]=str(exc)
    (evidence/"driver-error.txt").write_text(traceback.format_exc())
    print("BLOCKED "+str(exc),flush=True)
finally:
    if (work/".git").exists():
        try:
            run("final-diff",["/usr/bin/git","diff","--binary",SOURCE,"--"],work,False)
            run("final-numstat",["/usr/bin/git","diff","--numstat",SOURCE,"--"],work,False)
            run("final-status",["/usr/bin/git","status","--porcelain","--untracked-files=normal"],work,False)
            record["after_locks"]={name:digest(work/name) for name in ["codex-rs/Cargo.lock","MODULE.bazel.lock"] if (work/name).is_file()}
        except Exception as exc: record["collection_error"]=repr(exc)
    try:
        record["formal_head_after"]=gittext("formal-head-after",["rev-parse","HEAD"])
        after=run("formal-status-after",["/usr/bin/git","status","--porcelain","--untracked-files=normal"],formal)
        record["formal_sparse_after"]=formal_sparse_identity("formal-sparse-after")
        record["formal_checkout_unchanged"]=(record["formal_head_after"]==SOURCE and not after and record["formal_sparse_after"]==record["formal_sparse_before"])
        if not record["formal_checkout_unchanged"]: record["state"]="blocked"; record["formal_error"]="formal checkout identity changed"
    except Exception as exc: record["formal_verification_error"]=repr(exc)
    record["wrapper_wall_seconds"]=time.perf_counter()-started
    record["active_step"]=None; save()
    inventory={str(f.relative_to(evidence)):digest(f) for f in evidence.rglob("*") if f.is_file() and "bazel-output" not in f.parts and f.name not in ["evidence.zip","archive.json"]}
    with zipfile.ZipFile(evidence/"evidence.zip","x",zipfile.ZIP_DEFLATED) as z:
        for name in inventory: z.write(evidence/name,name)
        z.writestr("ORIGINALS.json",json.dumps(inventory,indent=2)+"\n")
    archive={"path":str(evidence/"evidence.zip"),**digest(evidence/"evidence.zip"),"original_files":len(inventory)}
    (evidence/"archive.json").write_text(json.dumps(archive,indent=2)+"\n")
    print(json.dumps({"receipt":str(evidence/"receipt.json"),"state":record["state"],"wall_seconds":record["wrapper_wall_seconds"],"formal_checkout_unchanged":record.get("formal_checkout_unchanged"),"archive":archive}),flush=True)
sys.exit(0 if record["state"]=="success" else 1)

