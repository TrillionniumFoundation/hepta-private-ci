"""Actual CPU ATen dispatch audit; all profiler time is instrumentation cost."""
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import platform
import resource
import subprocess
import sys
import time

ROOT = Path("/home/qian-qi/hcsn-sixwork-20261121-e29f")
EXPECTED_HEAD = "29197571b0e9d26251d7b95c47f824ecdf423f6b"
OUTPUT = Path(__file__).with_name("backend-operator-audit.json")
started = time.perf_counter()
report = {
    "kind": "development_cpu_operator_dispatch_audit",
    "status": "started",
    "expected_source": EXPECTED_HEAD,
    "claims": "Observed ATen call counts in complete sequence forward and backward; no timing or task-quality comparison.",
    "cost_scope": "Process wall includes imports and Torch profiler initialization/instrumentation; never model runtime.",
    "aggregate_count_note": "Family aggregates include nested ATen wrapper/internal calls; inspect per-operation aten_counts for exact dispatch counts.",
    "arms": {},
}
with OUTPUT.open("x") as handle:
    handle.write(json.dumps(report) + "\n")
try:
    head = subprocess.check_output(
        ["/usr/bin/git", "-C", str(ROOT), "--no-optional-locks", "rev-parse", "HEAD"],
        text=True,
    ).strip()
    assert head == EXPECTED_HEAD, head
    subprocess.run(
        ["/usr/bin/git", "-C", str(ROOT), "--no-optional-locks", "diff", "--quiet", "HEAD", "--", "qualification"],
        check=True,
    )
    available = int(next(line for line in Path("/proc/meminfo").read_text().splitlines() if line.startswith("MemAvailable:")).split()[1])
    assert available >= 6 * 1024 * 1024, available
    import torch
    from qualification.hcsn_adaptive.batched_flow import BatchedFlow, FlowConfig
    from qualification.hcsn_adaptive.uniformized_flow import UniformizedFlow

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    report["identity"] = {
        "source": head,
        "python": sys.version,
        "platform": platform.platform(),
        "versions": {package: importlib.metadata.version(package) for package in ("torch", "numpy", "ncps", "future", "packaging")},
        "threads": [torch.get_num_threads(), torch.get_num_interop_threads()],
        "torch_config": torch.__config__.show(),
        "profiler_signature": str(inspect.signature(torch.profiler.profile)),
        "mem_available_kib_before_import": available,
        "cpu_models": sorted({line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines() if line.startswith("model name")}),
        "environment": {name: os.environ.get(name) for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "PYTHONPATH", "CUDA_VISIBLE_DEVICES")},
    }
    report["sources"] = {
        name: hashlib.sha256((ROOT / "qualification/hcsn_adaptive" / name).read_bytes()).hexdigest()
        for name in ("batched_flow.py", "finite_control.py", "uniformized_flow.py")
    }
    report["script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    torch.manual_seed(74120)
    config = FlowConfig(input_size=4, content_size=4, bins=6, stages=3, dt=0.05)
    dense, action = BatchedFlow(config), UniformizedFlow(config)
    action.load_state_dict(dense.state_dict())
    inputs = torch.randn(2, 2, 4, dtype=torch.float64) * 0.2
    report["case"] = {"batch": 2, "bins": 6, "stages": 3, "length": 2, "input_size": 4, "content_size": 4, "dtype": "float64", "seed": 74120}
    for name, model in (("dense", dense), ("action", action)):
        model.zero_grad(set_to_none=True)
        with torch.profiler.profile(
            activities=[torch.profiler.ProfilerActivity.CPU],
            record_shapes=False,
            profile_memory=False,
            with_stack=False,
        ) as profiler:
            features, state = model(inputs)
            loss = features.square().mean() + state.density.square().mean()
            loss.backward()
        counts = {entry.key: entry.count for entry in profiler.key_averages()}
        aten = dict(sorted((key, value) for key, value in counts.items() if key.startswith("aten::")))
        matrix_exp_calls = sum(count for key, count in aten.items() if key in ("aten::linalg_matrix_exp", "aten::matrix_exp"))
        solve_calls = sum(count for key, count in aten.items() if key.startswith("aten::linalg_solve"))
        report["arms"][name] = {
            "aten_counts": aten,
            "matrix_exp_family_aten_event_count": matrix_exp_calls,
            "linalg_solve_family_aten_event_count": solve_calls,
            "parameter_tensors_with_grad": sum(parameter.grad is not None for parameter in model.parameters()),
            "parameter_tensors_total": sum(1 for _ in model.parameters()),
            "all_parameter_gradients_finite": all(parameter.grad is not None and bool(torch.isfinite(parameter.grad).all()) for parameter in model.parameters()),
            "loss": float(loss.detach()),
            "features_shape": list(features.shape),
            "density_shape": list(state.density.shape),
        }
    assert report["arms"]["dense"]["matrix_exp_family_aten_event_count"] > 0, "dense backend did not dispatch matrix exponential"
    assert report["arms"]["action"]["matrix_exp_family_aten_event_count"] == 0, "action backend dispatched matrix exponential"
    assert report["arms"]["dense"]["linalg_solve_family_aten_event_count"] > 0, "dense continuation solve missing"
    assert report["arms"]["action"]["linalg_solve_family_aten_event_count"] > 0, "action continuation solve missing"
    report["status"] = "observed_expected_backend_dispatch"
except Exception as error:
    report["status"] = "failed"
    report["error"] = repr(error)
    raise
finally:
    report["whole_instrumented_process_wall_seconds"] = time.perf_counter() - started
    report["process_maxrss_kib"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    OUTPUT.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"status": report["status"], "artifact": str(OUTPUT), "sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(), "whole_instrumented_process_wall_seconds": report["whole_instrumented_process_wall_seconds"]}), flush=True)
