Source bd91312a6ee8442f65ebb0f8115d6072cd9688cb
Remote job 1a1fea87b8b-ffbe-211f
Key hcsn-sixwork-s3-unit-validation-20261121-e29f-001
22 tests passed; 0 failure, error or skip.
Python3.12.3 / Torch2.8.0+cpu / one intra-op and inter-op thread.
Total wall 7.9701571529731154s; unittest wall6.142s; maxRSS232260KiB.
New mathematical/integration fixtures only. No benchmark/training claim and no old N256/C2/HPCA execution.
One non-failing tensor-to-float warning is retained in stderr.
