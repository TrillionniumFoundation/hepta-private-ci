# Native host Windows runfiles repair: read-only proposal

Reviewed candidate: `61e9c1e880ddb2dc52ed1a7aa918f0eae4a3cc48`.
Observed failure: old PR #6909 head `29197571b0e9d26251d7b95c47f824ecdf423f6b`,
merge `044b9dfab1bcaa73b3f94a8ab339a8d3d239bff1`, workflow run `44918663193`,
Windows shard 1/4 job `136890277726`.

No source worktree, learning code, final data, platform guard or generated lock
has been changed. `before/`, `after/` and `review.patch` are review artifacts only.
No Rust build/test or Windows execution was performed by this audit.

## Finding and proposed code

Both native_host_process_e2e tests panic at process creation with Windows Os(3)
NotFound before any behavioral assertion executes. Their file has the same Git
blob `8bed084564a7d779f6c26925882713faa224cabf` in the failed head and reviewed
candidate. Both call Command::new on the compile-time CARGO_BIN_EXE value.

At the reviewed candidate:

- `defs.bzl` 492–496 binds this crate's binary to a `$(rlocationpath ...)` logical
  runfile key; 567–569 carries it into integration binaries/environment.
- The unsharded native rust_test at 735–756 includes the binary in `data` and
  receives `integration_test_cargo_env`. The binary dependency is already present.
- `.bazelrc` uses `common --noenable_runfiles`.
- `codex-rs/utils/cargo-bin/src/lib.rs` documents and implements runtime
  Cargo/Bazel/nextest lookup and manifest-based runfile resolution.

The evidence therefore points to a test-side path-consumption bug, not a missing
binary-data declaration. The proposed patch changes only the two process-path
lookups to `codex_utils_cargo_bin::cargo_bin("hepta-infer-worker")` and adds its
workspace dev-dependency. It retains the real binary, help arguments, expected
profile error, success/failure assertions and stdout/stderr checks.

## Cargo and Bazel dependency closure

Required authored files:

1. `codex-rs/hepta-infer-worker-host/tests/native_host_process_e2e.rs`.
2. `codex-rs/hepta-infer-worker-host/Cargo.toml`.

Required generated/verified files before publication:

3. `codex-rs/Cargo.lock`: the native-host package currently lacks the direct
   `codex-utils-cargo-bin` dependency. The helper package is already locked at
   0.0.0, including runfiles and thiserror; no new package version is intended.
   Generate the new dependency edge through Cargo, not a hand-written lock edit.
4. `MODULE.bazel.lock`: regenerate with the repository recipe. Its original blob
   identity is recorded; the GitHub file tool did not return its contents, so
   this review does not assert a predicted generated diff.

An explicit `BUILD.bazel` dependency addition is unnecessary for this crate's
existing `codex_rust_crate` rule: `defs.bzl` 609–610 uses normal+normal_dev Cargo
dependencies/aliases for integration tests; 743–744 supplies them to rust_test.
`MODULE.bazel` 319–337 derives the graph from the workspace Cargo.toml/Cargo.lock.
Thus regenerated normal_dev metadata supplies the actual test target dependency.
Do not add a global `deps_extra` entry, which would unnecessarily alter product
targets. An established equivalent pattern exists in
`codex-rs/exec-server/Cargo.toml` 75–79 and `exec-server/BUILD.bazel`: the helper is
a workspace dev-dependency, without a bespoke BUILD entry for it.

The root justfile (not codex-rs/justfile) defines working-directory codex-rs.
Its no-cd `bazel-lock-update` recipe is exactly
`bazel mod deps --lockfile_mode=update`. The Unix lock-check recipe delegates to
`scripts/check-module-bazel-lock.sh`, which uses the repository BuildBuddy wrapper
and `mod deps --lockfile_mode=error`.

## Required execution sequence for root

After applying the two-file patch in the actual Git worktree, run independently:

```sh
cargo metadata --manifest-path codex-rs/Cargo.toml --format-version 1 --offline > /ABS/EVIDENCE/native-runfiles-cargo-metadata.json
just bazel-lock-update
just bazel-lock-check
just fmt
just test -p codex-hepta-infer-worker-host --test native_host_process_e2e
```

Full Cargo metadata is requested rather than --no-deps, so dependency resolution
can update the lock. Offline metadata may fail if required pinned sources are
not cached; that is an explicit generator/dependency blocker, not permission to
fabricate lock files. Root can use its already authorized dependency workflow
and retain exact command outputs. Review resulting Cargo/Bazel diffs before
publication; unrelated version churn is not intended.

The decisive regression gate is the existing native Windows Bazel target:

```sh
bazel test //codex-rs/hepta-infer-worker-host:hepta-infer-worker-host-native_host_process_e2e-test --test_output=errors
```

Use the existing CI-native Windows configuration and wrapper. A Linux Cargo pass
does not by itself prove the manifest-only Windows path. No new fixture, skipped
case, relaxed assertion or fake binary is required.

## Other Windows failures: classification only

Source log: `29197571b0e9-job-136890277739.log`.

| Observation | Classification | Evidence limit |
|---|---|---|
| restricted_tokens_select_stable_routes_and_cleanup: capability-only workspace tokens require a private desktop | Fixture/capability-admission contract mismatch, not a missing executable | Candidate fixture calls the child launcher with use_private_desktop=false. Preserve production admission; separately qualify the fixture's intended desktop/token lifecycle. |
| Three elevated windows_sandbox cases reject ambient parent FILE_DELETE_CHILD | Explicit fail-closed production isolation limitation | The error says the preserving replacement is not qualified. No basis to bypass the guard, turn failures into skips, or weaken ACL assertions. |
| deferred_executor_spawn_agent_inherits_ready_step_environments::test_case_1_v1: websocket timeout, then teardown panic | Remote-environment protocol/lifecycle or timing failure requiring separate diagnosis | remote_env.rs:1027 waits five seconds; log also shows mock HTTP /v1/responses 404 and teardown failure at 2253. A single observed execution does not establish flakiness or prove a timeout increase is correct. |

These classes are independent of the native-worker runfile lookup. They should
remain visible after that focused repair; this proposal does not claim to turn
the entire Windows matrix green.
