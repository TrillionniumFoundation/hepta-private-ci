# Bellman dead_code：当前 a0 的只读可达性审查

- 固定源码：`a0b38d3d12c45a4fd254ca27fe1d4266b4c75c53`。
- 失败原件：blocking run `44922509419` / exact-source job `136902076024`；`a0b38d3d12c4-job-136902076024.log`。
- 此次只读取得该 crate 全部25个 Cargo/BUILD/src/tests/examples 文件，逐文件重算Git blob SHA-1与API原SHA吻合；源快照为 `bellman_cfg_review_source.json`，SHA-256 `829283acbfaa674dcc0c75321ef1aa7d460bf327f43c20cf338f1c17465b949e`。
- 这是静态修复建议；没有修改冻结源码，没有编译、dispatch或声称修复已通过CI。

## 结论

最小合法候选是只给下面三项各补一行：

```rust
#[cfg(any(test, feature = "compatibility-api"))]
```

| 声明 | a0 原行号 | 原因 |
|---|---:|---|
| `src/learned.rs` 的 `predict_tabular_operator` | 359 | 唯一crate内调用在 `learned_tests.rs:151,160`，通过 `#[cfg(test)]` 子模块及 `use super::*` 调用；对外导出在 `lib.rs:86–87` 已受 compatibility-api gate |
| `src/world_model.rs` 的 `MAX_COMPATIBILITY_SAMPLES`（16_384） | 22 | 只由下面的 compatibility wrapper 在同文件:132引用；应与wrapper拥有相同cfg |
| `src/world_model.rs` 的 `fit_transition_model` | 122 | 默认生产路径没有调用。crate内非测试调用为 `dataset_bound.rs:88`，而该模块在 `lib.rs:32–33` 已限定 compatibility-api；其余调用在 `world_model_tests.rs:27,63,89,102,112`。对外导出在 `lib.rs:121–122` 同样受 feature gate |

`Cargo.toml` 声明 `default=[]`、`compatibility-api=[]`。当前问题是 **导出已按feature限制，但私有模块里的定义仍无条件编译**，默认生产lib因此触发dead_code。给定义补同等可达性，并额外保留unit-test可达性，修复的是条件编译边界，不是放宽检查或删除业务实现。附近 `world_model.rs:276` 的 `predict_transition` 已采用同一模式，可作为仓内先例。

私有模块 `learned`/`world_model` 没有公开模块路径；外部crate无法绕过这些已受feature限定的re-export直接调用。完整crate源码检索未发现上述两个函数的其它调用。例子与integration test也无其它直接引用。

## 不应顺手门控的近似项

不要把 `learned.rs:25` 的另一个 `MAX_COMPATIBILITY_SAMPLES=100_000` 或 `learned.rs:137` 的 `fit_tabular_operator` 一并门控。它们被默认生产可达的 `learned_strict.rs:20,26` 使用，后者 `fit_tabular_operator_strict_v2` 在 `lib.rs` 无条件导出。相同名称不等于相同feature可达性。

保留两个controlled_v3路径、strict默认路径、全部类型及现有公共feature表面；不添加 `allow(dead_code)`、不新增空调用、不改gate命令、不移除真实业务逻辑。

## 验证应如何解释

当前exact-source脚本先执行default/compatibility的cargo check与test，之后执行default严格Clippy；本次正是该default Clippy发现三错误。最小候选应在独立修复分支依次接受已有default和compatibility-api的 `cargo clippy --all-targets -- -D warnings`，并保留已有两种feature测试。需要真实编译验证才能说修复成功，静态论证不能代替该门禁。现有已冻a0科学结果与CI失败保持原身份。

