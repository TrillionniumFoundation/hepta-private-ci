# H1 / H2 独立只读审阅

审阅对象：`advance_runtime/formal/final_batch/report.md`。其 SHA-256 为 `39b6262031222846574b9d052f6b765af7b92f3886d498045a91b797771f6c51`，与 `final-batch.json` 的原件元数据一致。研究源码为 `a0b38d3d12c45a4fd254ca27fe1d4266b4c75c53`。

本次阅读了原报告、冻结的 H1/H2/总计划协议、相应模型源码及三个 H2 fit 原件。以下是表内方向与科学表述核对；没有重新生成数据、执行训练或修改冻结源码。完整 236 原件的 custody 检查仍以主审计归档为准。

## 总体结论

报告的科学边界基本正确：保留三个 seed、逐任务与时钟报告差异、没有 p 值、没有把窗口当成独立训练复本，并明确了已知动力学与未知程序设计成本。主说明应把“630/630 admitted”解释为 **213 个 fit method-case + 417 个 final method-cell 的完整性和准入**。它不是 630 次独立统计试验，也不是六项科学假设都成功。

“Complete campaign: True”和各节“unresolved issues: None”适合解释为数据/协议完整性字段；建议在主报告旁注明这一点，保留原生成报告不变。

## H1：本次没有支持同生成元 value/risk 的增量预测优势

预声明主对照是 `same_generator − ordinary_tanh` 的 MSE，越小越好。八个 task × clock 条件中：

- 没有一个条件出现三个 seed 全部更低。
- association/IID、asynchronous/IID、asynchronous/clock、burst/clock 四个条件三个 seed 全部更高。
- 其余四个条件方向混合。
- 逐行核对为 24 个配对差异中 19 个为正、5 个为负；这个计数仅描述表中方向，不把 24 行当成独立统计检验样本。

可用表述：“在这组预声明的小型冻结特征与 ridge 读出实验里，同生成元 value/risk 特征未表现出稳定的增量预测收益，多项条件下出现负结果。”

范围必须保留：三臂保持同一固定 HCSN 动力学及其余特征，普通臂只把 last/mean 的 call/risk 四列替换为两个固定输入投影的 tanh 输出。所有臂都付完整公共 flow/bank 的计算成本；该实验不测删除 value solve 后的速度，也不证明所有自由边界特征、端到端 HCSN 或其他参数规模必然更差。较大的 shifted-clock MSE 是预测误差证据，单凭这些 MSE 不能判定生成元传播数值发散。

`same_generator` 的命名指法则一致。实际网络 risk 仍是区间起点 active cohort 的首击概率，call 是区间结束分布加权的冻结 continuation value；不是全群体首事件概率或金融 call/put 对。详见同目录 `risk_cohort_static_review.json`。

## H2：小型已知模型控制的正结果，不能外推为神经网络免 BP

预声明 Howard QVI 减 lookup-gate BP 的三个 final return 差异为：

| Seed | 完整期望收益差 |
|---|---:|
| 1907341 | 0.01557033 |
| 4812467 | 0.01636945 |
| 8629119 | 0.01342370 |

描述均值约 0.01512116，三个方向均正；两种控制器相对 never-reset 也均有正收益。报告这样陈述符合数据方向。

这些收益是在已知六状态生成元、五个 active state、一个 locked reset phase、固定折现/重置收益及独立外部合成 reward measurements 下，求出的完整折现期望收益。Final 的 128 个 reward vectors 衡量 reward measurement 不确定性，不是 128 个独立训练控制器，也不是采样物理轨迹收益。

三个 fit 原件都选择 Howard mask `[1,0,0,0,0]`，每个 3 次 policy-evaluation solve，Bellman residual 约 `2.22e-16`。BP 使用 128 次完整 value solve/backward；其首状态概率约 0.9934–0.9940，其余约 0.0024–0.0100。它已经接近相同硬决策。报告应保留有限 sigmoid 优化预算与决策时钟的区别：soft gate 在固定 uniformization epoch 作 Bernoulli 决策，hard mask 是瞬时 impulse intervention；只有硬端点共享精确的 impulse 方程。当前结果没有区分这些因素对约 0.015 收益差的全部贡献。

可用表述：“在这一已知有限生成元任务和固定优化预算内，Howard policy iteration 得到的硬策略在三个独立训练 seed 的新 reward measurements 上均优于 128 步软 lookup gate。它证明了局部模型求解可行；没有证明从未知神经元动力学或多模态表示中直接编辑出全任务最优网络。”

Howard 是迭代有限动态规划加线性求解，不是 He–Xiong 原论文解析式直接给出整个网络的最优权重。

## 成本与联合更新的解释

报告将 fit/final 子进程累计 77.273247 秒、freeze 子进程 10.417943 秒与 registration 分列，并保留 program design cost unknown，范围处理正确。H2 的 per-arm adaptation 时间存在第一 seed 的 BP 冷初始化差异；单次记录和 standalone lower bound 不足以声称普适端到端训练加速。此处也没有 GPU、大模型或能耗结果。

联合实验中多个 H3 screen 的零差值来自共享初始 checkpoint 与 NoUpdate。它们是“保留 incumbent 后满足描述性容差”，不是证明不同学习算法同样成功地更新了整个网络。主结论应和报告已有的 34/48 NoUpdate、12 个 reference、2 个 selected 一起呈现。

## 审阅决定

H1/H2 表内方向、预声明对照及主要限制未发现实质科学错误。建议把以上完整性定义、H1 的负结果、H2 的已知模型/固定预算/时钟差异、NoUpdate 的含义写进主叙述，避免只引用 admitted 数量或三个正号。冻结报告与源码保持不变；这些结果不改变 N256、C2、HPCA 的原有开放状态。

