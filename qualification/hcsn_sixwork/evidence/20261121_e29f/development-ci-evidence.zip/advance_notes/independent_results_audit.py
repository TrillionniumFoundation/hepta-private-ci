"""Post-final read-only arithmetic/hash audit; no learner import or data generation."""
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path('/workspace/scratch/e29f99df125f/advance_runtime/formal')
BASE = ROOT / 'final_snapshot'
SEEDS = [1907341, 4812467, 8629119]
TASKS = ['first_passage', 'burst', 'asynchronous', 'association']
ARMS = {
    'readout': ['direct', 'local_bp', 'semantic_program', 'program_then_bp'],
    'joint': ['conditional_direct', 'joint_bp', 'semantic_program', 'program_then_bp'],
    'architecture': ['hcsn_finite', 'gru', 'diagonal_linear_ct_ssm', 'lif_surrogate', 'causal_transformer', 'official_cfc'],
    'feature': ['same_generator', 'drop_value_risk', 'ordinary_tanh'],
    'boundary': ['howard_qvi', 'lookup_gate_bp', 'never_reset'],
}


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def state_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def finite(x):
    return type(x) in (int, float) and math.isfinite(x)


plan = load(BASE / 'campaign/ROOT_PLAN.json')
bindings = load(BASE / 'campaign/ROOT_FINAL_BINDINGS.json')
assert plan['source_git_sha'] == bindings['source_git_sha'] == 'a0b38d3d12c45a4fd254ca27fe1d4266b4c75c53'
assert plan['seeds'] == SEEDS
assert sha(ROOT / 'formal-evidence.zip') == '3d0c033923c8ccc3d617bfa36531fd544b712b4ac516d133df5c3885e3967455'
report = load(BASE / 'report/report.json')
batch = load(ROOT / 'final_batch/final-batch.json')
assert sha(BASE / 'report/report.json') == batch['reporter']['files']['report.json']['sha256']
assert sha(BASE / 'report/report.md') == sha(ROOT / 'final_batch/report.md')
summary = {'source': plan['source_git_sha'], 'stages': {}, 'contrasts': [], 'checks': []}
metrics, fitted, max_error = {}, {}, 0.
for stage, methods in ARMS.items():
    directory = BASE / 'campaign' / stage
    attempt = directory / 'attempt'
    cfg = load(directory / 'freeze.json')
    identity = sha(directory / 'freeze.json')
    selection, final = load(attempt / 'selection.json'), load(attempt / 'final.json')
    selected_sha = sha(attempt / 'selection.json')
    assert sha(ROOT / 'fit_snapshot/campaign' / stage / 'attempt/selection.json') == selected_sha
    assert bindings['selections'][stage] == selected_sha
    assert (attempt / 'FINAL_CONSUMED').read_bytes() == selected_sha.encode()
    assert len((attempt / 'FINAL_CONSUMED').read_bytes()) == 64
    key = hashlib.sha256(cfg['namespace'].encode()).hexdigest()
    record = load(BASE / 'registry' / (key + '.json'))
    registry = BASE / 'registry' / key
    fit_end, final_end = (load(registry / (phase + '.finished.json')) for phase in ('fit', 'final'))
    assert record['source_git_sha'] == plan['source_git_sha'] and record['plan_sha256'] == sha(BASE / 'campaign/ROOT_PLAN.json')
    assert record['manifest'] == plan['stages'][stage]['manifest'] and record['attempt'] == plan['stages'][stage]['attempt']
    assert fit_end['validated_selection_sha256'] == fit_end['validation']['receipt_sha256'] == selected_sha
    assert final_end['validation']['receipt_sha256'] == sha(attempt / 'final.json')
    assert load(registry / 'final.reserved.json')['selection_sha256'] == selected_sha
    assert len(list(registry.glob('final.reserved.json'))) == len(list(registry.glob('final.finished.json'))) == 1
    for phase, end in [('fit', fit_end), ('final', final_end)]:
        assert end['source_git_sha'] == plan['source_git_sha'] and end['manifest_sha256'] == identity
        assert end['status'] == 'complete' and end['process']['returncode'] == 0 and not end['process']['timed_out']
        assert end['validation']['passed'] and end['validation']['integrity_ok'] and not end['validation']['defects']
    wall = fit_end['process']['wall_seconds'] + final_end['process']['wall_seconds']
    assert wall == final_end['cumulative_fit_final_child_wall_seconds'] and wall <= cfg['budget']['wall_seconds']
    assert selection['manifest_sha256'] == final['manifest_sha256'] == identity
    assert selection['phase'] == 'fit' and final['phase'] == 'final'
    final_ledger = (attempt / 'cost.jsonl').read_bytes()
    assert final_ledger.startswith((ROOT / 'fit_snapshot/campaign' / stage / 'attempt/cost.jsonl').read_bytes())
    previous, pending, work, settled_wall, failed = '0'*64, None, Counter(), 0., 0
    for encoded in final_ledger.splitlines():
        entry = json.loads(encoded)
        fingerprint = entry.pop('hash')
        assert hashlib.sha256(json.dumps(entry, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest() == fingerprint
        assert entry['previous'] == previous and entry['identity'] == identity and entry['budget'] == cfg['budget']
        if entry['kind'] == 'reserve':
            assert pending is None
            pending = entry['operation']
            assert all(type(v) is int and v >= 0 for v in entry['charge'].values())
            work.update(entry['charge'])
        else:
            assert entry['kind'] == 'settle' and pending == entry['operation']
            assert finite(entry['cumulative_wall_seconds']) and entry['cumulative_wall_seconds'] >= settled_wall
            settled_wall = entry['cumulative_wall_seconds']
            failed += entry['status'] != 'completed'
            pending = None
        previous = fingerprint
    assert pending is None and failed == 0 and all(v <= cfg['budget'][k] for k, v in work.items())
    sidecar = load(attempt / 'final.cost.json')
    assert sidecar['tail'] == previous and sidecar['pending'] is None and sidecar['wall_overrun_seconds'] == 0
    assert settled_wall <= sidecar['wall_seconds'] <= cfg['budget']['wall_seconds']
    assert all(sidecar[k] == v for k, v in work.items())
    decisions, cost_arms, changed_cases, parameters = defaultdict(Counter), defaultdict(list), [], {}
    expected_case_keys, final_count, fit_count = set(), 0, 0
    common_cost = []
    for task in (['finite_control'] if stage == 'boundary' else TASKS):
        for seed in SEEDS:
            base_key = str(seed) if stage == 'boundary' else f'{task}/{seed}'
            if stage != 'architecture':
                case = selection['cases'][base_key]
                common_cost.append(case.get('common_setup_seconds', case.get('complete_feature_bank_seconds', 0.)))
                assert set(case['methods']) == set(methods)
            for method in methods:
                case_key = f'{base_key}/{method}' if stage == 'architecture' else base_key
                expected_case_keys.add(case_key)
                case = selection['cases'][case_key]
                arm = case if stage == 'architecture' else case['methods'][method]
                fitted[(stage,task,seed,method)] = (case,arm)
                fit_count += 1
                decisions[method][arm['status']] += 1
                base = arm.get('zero_dev_mse',case.get('base_dev_mse',case.get('base_dev_return')))
                candidate = arm.get('dev_mse',arm.get('candidate_dev_mse',arm.get('candidate_dev_return')))
                assert finite(candidate) and finite(base)
                if arm['status'] != 'reference':
                    assert (arm['status'] == 'selected') == (candidate > base if stage == 'boundary' else candidate < base)
                if stage in ('joint','architecture'):
                    assert state_sha(arm['selected_state']) == arm['selected_sha256']
                    assert arm['selected_sha256'] == (arm['candidate_sha256'] if arm['status'] == 'selected' else case['base_sha256'])
                if stage in ('readout','feature') and arm['status'] == 'no_update':
                    assert arm['bias'] == 0 and all(x == 0 for x in arm['weight'])
                if stage == 'boundary' and arm['status'] in ('reference','no_update'):
                    assert arm['selected_probability'] == [0.]*5
                if arm['status'] == 'selected' and stage == 'joint':
                    changed_cases.append({'case':case_key,'method':method,'candidate_dev':candidate,'base_dev':base,
                        'applied_changed_names':[k for k,v in arm['selected_state'].items() if v != case['base_state'][k]]})
                if stage == 'architecture':
                    parameters[method] = case['architecture']['parameters']
                elif stage != 'boundary':
                    parameters[method] = case['eligible_parameters']
                cost_arms[method].append({k:arm.get(k,case.get(k)) for k in ('adaptation_wall_seconds','standalone_wall_lower_bound','whole_fit_case_wall_seconds','diagnostics','optimizer_steps_completed','optimizer_steps')})
                for split in (['final'] if stage == 'boundary' else ['final_iid','final_clock']):
                    if stage == 'boundary':
                        matches = [x for x in final['results'] if x['seed'] == seed]
                        assert len(matches) == 1
                        row = matches[0]['methods'][method]
                    else:
                        matches = [x for x in final['results'] if x.get('case') == case_key and x.get('split') == split
                                   and (stage == 'architecture' or x.get('method') == method)]
                        assert len(matches) == 1
                        row = matches[0]
                    assert row['status'] == arm['status']
                    values = row.get('sample_squared_errors',row.get('measured_returns'))
                    mse = row.get('mse',row.get('mean_full_return'))
                    assert len(values) == cfg['final'] and all(finite(x) for x in values) and finite(mse)
                    assert math.isclose(statistics.fmean(values),mse,rel_tol=1e-12,abs_tol=1e-12)
                    max_error = max(max_error,abs(statistics.fmean(values)-mse))
                    if stage != 'boundary':
                        assert len(set(row['ids'])) == len(values)
                        assert all(math.isclose((p-y)**2,e,rel_tol=1e-12,abs_tol=1e-12) for p,y,e in zip(row['prediction'],row['target'],values))
                    metrics[(stage,task,split,seed,method)] = row
                    final_count += 1
    assert set(selection['cases']) == expected_case_keys
    assert fit_count == fit_end['validation']['valid_cells'] and final_count == final_end['validation']['valid_cells']
    summary['stages'][stage] = {'fit_cells':fit_count,'final_cells':final_count,'decisions':decisions,'parameters':parameters,
        'applied_joint_changes':changed_cases,'cost_by_arm':cost_arms,'common_setup_seconds_sum':sum(common_cost),
        'fit_child_seconds':fit_end['process']['wall_seconds'],'final_child_seconds':final_end['process']['wall_seconds'],
        'fit_final_child_seconds':wall,'final_ledger_work':dict(work),'selection_sha256':selected_sha,'final_sha256':sha(attempt/'final.json')}

for stage in ARMS:
    for task in (['finite_control'] if stage == 'boundary' else TASKS):
        for split in (['final'] if stage == 'boundary' else ['final_iid','final_clock']):
            for seed in SEEDS:
                if stage != 'boundary':
                    group=[metrics[stage,task,split,seed,m] for m in ARMS[stage]]
                    assert all((r['data_sha256'],r['ids'],r['target']) == (group[0]['data_sha256'],group[0]['ids'],group[0]['target']) for r in group)

definitions=[('H1','feature','same_generator','ordinary_tanh'),('H2','boundary','howard_qvi','lookup_gate_bp')]
definitions += [('H3',s,m,b) for s,b in [('readout','local_bp'),('joint','joint_bp')] for m in ARMS[s] if m != b]
for hypothesis,stage,left,right in definitions:
    for task in (['finite_control'] if stage == 'boundary' else TASKS):
        for split in (['final'] if stage == 'boundary' else ['final_iid','final_clock']):
            delta=[]
            tolerances=[]
            for seed in SEEDS:
                value=lambda m: metrics[stage,task,split,seed,m].get('mse',metrics[stage,task,split,seed,m].get('mean_full_return'))
                delta.append(value(left)-value(right))
                case,arm=fitted[stage,task,seed,left]
                tolerances.append(max(1e-6,.01*arm['zero_dev_mse']) if stage=='readout' else max(1e-6,.01*case['base_dev_mse']) if stage=='joint' else None)
            recomputed={'hypothesis':hypothesis,'stage':stage,'task':task,'split':split,'left':left,'right':right,
                'differences':delta,'mean_difference':statistics.fmean(delta),'tolerances':tolerances,
                'screen':all(d<=t for d,t in zip(delta,tolerances)) if hypothesis=='H3' else None}
            stored=[x for x in report['contrasts'] if all(x[k]==recomputed[k] for k in ('hypothesis','stage','task','split','left','right'))]
            assert len(stored)==1 and all(a==b['difference'] for a,b in zip(delta,stored[0]['paired']))
            if hypothesis=='H3': assert recomputed['screen'] == (stored[0]['quality_tolerance_screen']=='meets')
            summary['contrasts'].append(recomputed)

summary['readout_no_update_cases']=[{'task':t,'seed':s,'method':m} for (stage,t,s,m),(case,arm) in fitted.items() if stage=='readout' and arm['status']=='no_update']
summary['h2_policies']=[{'seed':s,'method':m,'status':a['status'],'policy':a['selected_probability'],'diagnostics':a['diagnostics']}
    for (stage,t,s,m),(c,a) in fitted.items() if stage=='boundary']
summary['architecture_target_prediction_bounds']=[{'task':t,'seed':s,'mse':r['mse'],'target_min':min(r['target']),'target_max':max(r['target']),
    'prediction_min':min(r['prediction']),'prediction_max':max(r['prediction'])} for (stage,t,split,s,m),r in metrics.items() if stage=='architecture' and split=='final_clock' and m=='hcsn_finite']
summary['checks']=['zip SHA correct','all five original fit selection bytes unchanged','all five externally bound selections consumed exactly',
    'original source and allocation bindings match','213 fit and 417 final cells independently enumerated','selected versus NoUpdate decisions match dev rule',
    'joint/architecture chosen states match stored hashes and selected/incumbent identities','final metrics recalculated from stored predictions/targets or returns',
    'paired methods use identical stored final samples','all fit ledgers are byte prefixes of final ledgers; hashes settle with no failures/pending work',
    'predeclared H1/H2/H3 differences and all tolerance screens exactly reproduce frozen reporter']
summary['max_metric_reduction_roundoff']=max_error
summary['complete_fit_final_child_seconds']=sum(s['fit_final_child_seconds'] for s in summary['stages'].values())
destination=Path('/workspace/scratch/e29f99df125f/advance_notes/independent_results_audit.json')
destination.write_text(json.dumps(summary,indent=2,sort_keys=True,allow_nan=False)+'\n')
print(json.dumps({'checks':summary['checks'],'decisions':{s:v['decisions'] for s,v in summary['stages'].items()},
    'parameters':{s:v['parameters'] for s,v in summary['stages'].items()},'readout_no_update':summary['readout_no_update_cases'],
    'wall':summary['complete_fit_final_child_seconds'],'max_roundoff':max_error,'output':str(destination)},indent=2))
