"""Read existing, consumed evidence only; never imports or executes a learner."""
import collections
import hashlib
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "hcsn-work"
sys.path.insert(0, str(SOURCE))
from qualification.hcsn_sixwork.integrity import validate

FORMAL = ROOT / "advance_runtime/formal"
RAW = FORMAL / "final_snapshot"
FIT = FORMAL / "fit_snapshot"
STAGES = ("readout", "joint", "architecture", "feature", "boundary")
SEEDS = (1907341, 4812467, 8629119)
TASKS = ("first_passage", "burst", "asynchronous", "association")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def main():
    snapshot = read(RAW / "SNAPSHOT.json")
    for item in snapshot["files"]:
        data = (RAW / item["archive_path"]).read_bytes()
        assert len(data) == item["bytes"] and digest(data) == item["sha256"]
    for path, expected in snapshot["registered_source_files"].items():
        assert digest((SOURCE / path).read_bytes()) == expected, path
    frozen = read(RAW / "report/report.json")
    reported = {
        (r["stage"], r["task"], r["seed"], r["method"], r["split"]): r
        for r in frozen["rows"] if r["phase"] == "final"
    }
    values, decisions, checks, selections, costs = {}, {}, {}, {}, {}
    for stage in STAGES:
        attempt = RAW / "campaign" / stage / "attempt"
        manifest = RAW / "campaign" / stage / "freeze.json"
        cfg, identity = read(manifest), digest(manifest.read_bytes())
        selected = (attempt / "selection.json").read_bytes()
        selected_sha = digest(selected)
        assert selected == (FIT / "campaign" / stage / "attempt/selection.json").read_bytes()
        assert (attempt / "FINAL_CONSUMED").read_bytes() == selected_sha.encode("ascii")
        fit_check = validate(FIT / "campaign" / stage / "attempt", cfg, stage, "fit", identity)
        final_check = validate(attempt, cfg, stage, "final", identity, selected_sha)
        assert fit_check["passed"] and final_check["passed"]
        checks[stage] = {"fit": fit_check, "final": final_check}
        selections[stage] = selected_sha
        decision = collections.defaultdict(collections.Counter)
        for case_key, case in read(attempt / "selection.json")["cases"].items():
            methods = {case_key.split("/")[2]: case} if stage == "architecture" else case["methods"]
            for name, method in methods.items():
                decision[name][method["status"]] += 1
        decisions[stage] = dict(decision)
        for item in read(attempt / "final.json")["results"]:
            if stage == "boundary":
                task, seed, split = "finite_control", item["seed"], "final"
                arms = item["methods"]
            else:
                parts = item["case"].split("/")
                task, seed, split = parts[0], int(parts[1]), item["split"]
                method = parts[2] if stage == "architecture" else item["method"]
                arms = {method: item}
            for method, result in arms.items():
                key = (stage, task, seed, method, split)
                assert key not in values
                metric = result["mean_full_return"] if stage == "boundary" else result["mse"]
                values[key] = metric
                assert metric == reported[key]["value"]
                assert result["status"] == reported[key]["status"]
        registry_key = digest(cfg["namespace"].encode())
        costs[stage] = {}
        for phase in ("freeze", "fit", "final"):
            original = read(RAW / "registry" / registry_key / (phase + ".finished.json"))
            assert original["source_git_sha"] == snapshot["source"]
            costs[stage][phase] = original["process"]["wall_seconds"]
    assert len(values) == len(reported) == 417
    contrast_checks = []
    for contrast in frozen["contrasts"]:
        pairs = []
        for seed in SEEDS:
            prefix = (contrast["stage"], contrast["task"], seed)
            left = values[(*prefix, contrast["left"], contrast["split"])]
            right = values[(*prefix, contrast["right"], contrast["split"])]
            pair = next(p for p in contrast["paired"] if p["seed"] == seed)
            assert pair["difference"] == left - right
            assert pair["left_value"] == left and pair["right_value"] == right
            if contrast["hypothesis"] == "H3":
                row = reported[(*prefix, contrast["left"], contrast["split"])]
                tau = max(1e-6, .01 * row["incumbent_dev"])
                assert pair["tau"] == tau and pair["within_tolerance"] == (left - right <= tau)
            pairs.append(left - right)
        assert math.isclose(sum(pairs) / 3, contrast["difference_summary"]["mean"], rel_tol=1e-14)
        contrast_checks.append({k: contrast[k] for k in ("hypothesis", "stage", "task", "split", "left", "right")})
    h1 = [c for c in frozen["contrasts"] if c["hypothesis"] == "H1"]
    h3 = {s: [c for c in frozen["contrasts"] if c["hypothesis"] == "H3" and c["stage"] == s]
          for s in ("readout", "joint")}
    screens = {}
    for stage, contrasts in h3.items():
        methods = sorted({c["left"] for c in contrasts})
        screens[stage] = {m: {
            "passed_conditions": sum(c["quality_tolerance_screen"] == "meets" for c in contrasts if c["left"] == m),
            "expected_conditions": sum(c["left"] == m for c in contrasts),
            "all_three_exact_ties": sum(all(p["difference"] == 0 for p in c["paired"]) for c in contrasts if c["left"] == m),
        } for m in methods}
    architecture = []
    for task in TASKS:
        for split in ("final_iid", "final_clock"):
            for method in decisions["architecture"]:
                metrics = [values[("architecture", task, seed, method, split)] for seed in SEEDS]
                architecture.append({"task": task, "split": split, "method": method,
                                     "seeds": list(SEEDS), "metrics": metrics, "mean": sum(metrics)/3})
    result = {
        "source": snapshot["source"], "scope": "read-only replay and direct raw metric arithmetic; no new training or selection",
        "archive_sha256": digest((FORMAL / "formal-evidence.zip").read_bytes()),
        "verified_original_files": len(snapshot["files"]),
        "verified_registered_source_files": len(snapshot["registered_source_files"]),
        "fit_cells": sum(x["fit"]["valid_cells"] for x in checks.values()),
        "final_cells": len(values), "all_original_selections_unchanged": True,
        "all_markers_exact_64_bytes": True, "all_report_final_metrics_match_raw": True,
        "predeclared_contrasts_independently_recomputed": len(contrast_checks),
        "h1": {"conditions": len(h1), "all_three_benefit": sum(c["all_three_benefit"] for c in h1),
               "seed_differences_positive": sum(p["difference"] > 0 for c in h1 for p in c["paired"]),
               "seed_differences_negative": sum(p["difference"] < 0 for c in h1 for p in c["paired"]),
               "mean_difference_positive_conditions": sum(c["difference_summary"]["mean"] > 0 for c in h1)},
        "h3_screens": screens, "fit_decisions_by_method": decisions,
        "architecture": architecture, "child_costs": costs,
        "complete_fit_final_child_seconds": sum(v[p] for v in costs.values() for p in ("fit", "final")),
        "selection_sha256": selections, "validation": checks,
        "limits": ["Three paired seeds are descriptive, not a significance claim.",
                   "Quality ties from NoUpdate do not establish editing success.",
                   "Architecture pilot has one tiny capacity and 12 BP steps.",
                   "Unknown design/API costs are not zero."]
    }
    output = FORMAL / "root_final_full_grid_review.json"
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({k: result[k] for k in ("source", "verified_original_files", "verified_registered_source_files", "fit_cells", "final_cells", "predeclared_contrasts_independently_recomputed", "h1", "h3_screens", "complete_fit_final_child_seconds")}, indent=2))


if __name__ == "__main__":
    main()
