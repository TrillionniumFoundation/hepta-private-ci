"""Render consumed study results. This file cannot run training or selection."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("report_json", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    report = json.loads(args.report_json.read_bytes())
    seeds = (1907341, 4812467, 8629119)
    tasks = ("first_passage", "burst", "asynchronous", "association")
    names = {"first_passage": "First passage", "burst": "Burst",
             "asynchronous": "Asynchronous", "association": "Association"}
    h1 = {(c["task"], c["split"]): c for c in report["contrasts"] if c["hypothesis"] == "H1"}
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.titleweight": "bold", "svg.fonttype": "none"})
    fig = plt.figure(figsize=(14, 9.1), facecolor="#f9fbfd")
    grid = fig.add_gridspec(2, 2, width_ratios=(1.32, 1), left=.14, right=.97,
                           bottom=.23, top=.83, wspace=.35, hspace=.56)
    ax = fig.add_subplot(grid[:, 0])
    ax.set_facecolor("#ffffff")
    conditions = [(t, s) for t in tasks for s in ("final_iid", "final_clock")]
    colors = ("#326A9B", "#BB6D1F", "#7752A0")
    for i, seed in enumerate(seeds):
        vals = [next(p["difference"] for p in h1[c]["paired"] if p["seed"] == seed) for c in conditions]
        y = np.arange(8) + (i - 1) * .15
        ax.scatter(vals, y, label=str(seed), s=41, color=colors[i], zorder=3)
    ax.axvline(0, color="#303E4A", lw=1.2)
    ax.set_xscale("symlog", linthresh=.01)
    ax.set_xlim(-70, 900)
    ax.set_xticks([-10, -1, -.01, 0, .01, 1, 10, 100])
    ax.set_xticklabels(["−10", "−1", "−.01", "0", ".01", "1", "10", "100"])
    ax.set_yticks(range(8), [names[t] + " / " + ("IID" if s == "final_iid" else "new clock") for t, s in conditions])
    ax.invert_yaxis()
    ax.grid(axis="x", color="#E0E6EC", lw=.8)
    ax.set_title("A. Shared value/risk features: no consistent benefit", loc="left", pad=20, fontsize=12)
    ax.set_xlabel("MSE difference: same generator − ordinary tanh\nNegative favors same generator; symmetric-log scale", labelpad=12)
    handles, labels = ax.get_legend_handles_labels()
    fig.legend(handles, ["Seed " + label for label in labels], frameon=False,
               loc="lower left", bbox_to_anchor=(.14, .085), ncol=3, fontsize=9)
    ax.text(0, 1.015, "19 of 24 differences are positive; 0 of 8 conditions improve on all three seeds",
            transform=ax.transAxes, fontsize=9, color="#515E6A")

    bx = fig.add_subplot(grid[0, 1])
    bx.set_facecolor("#ffffff")
    rows = [r for r in report["rows"] if r["stage"] == "boundary" and r["phase"] == "final"]
    for i, seed in enumerate(seeds):
        qvi = next(r["value"] for r in rows if r["seed"] == seed and r["method"] == "howard_qvi")
        gate = next(r["value"] for r in rows if r["seed"] == seed and r["method"] == "lookup_gate_bp")
        bx.plot([gate, qvi], [i, i], color="#8B98A2", lw=2)
        bx.scatter(gate, i, color="#74818E", s=48, label="Lookup gate / BP" if i == 0 else None, zorder=3)
        bx.scatter(qvi, i, color="#157B62", s=48, label="Howard QVI" if i == 0 else None, zorder=3)
        bx.text((gate+qvi)/2, i-.21, f"+{qvi-gate:.5f}", ha="center", color="#12634F", fontsize=9)
    bx.set_yticks(range(3), [str(s) for s in seeds])
    bx.set_ylim(2.45, -.65)
    bx.set_xlim(.54, .65)
    bx.set_xlabel("Full expected return (higher is better)")
    bx.set_title("B. Task boundary: limited positive evidence", loc="left", pad=17, fontsize=12)
    bx.grid(axis="x", color="#E0E6EC", lw=.8)
    bx.legend(frameon=False, fontsize=8, loc="lower left")
    bx.text(0, 1.015, "Known six-state dynamics; soft and hard intervention clocks differ",
            transform=bx.transAxes, fontsize=8.5, color="#515E6A")

    cx = fig.add_subplot(grid[1, 1])
    cx.set_facecolor("#ffffff")
    # Retained development benchmark means (repetitions 1 and 2, cold repetition 0 retained).
    ratios = [5.045810, 2.032184, 1.621875, 2.100814, 1.541959]
    configs = ["8 / 6 / 3", "16 / 24 / 8", "8 / 48 / 12", "4 / 64 / 32", "4 / 64 / 128"]
    cx.barh(range(5), ratios, color="#B65B4F", height=.53)
    cx.axvline(1, color="#253D4B", lw=1, ls="--")
    cx.set_yticks(range(5), configs)
    cx.invert_yaxis()
    cx.set_xlim(0, 5.75)
    for i, v in enumerate(ratios):
        cx.text(v+.07, i, f"{v:.2f}×", va="center", fontsize=9)
    cx.set_xlabel("Action / dense full forward + backward time\nLabels: batch / active bins / refractory phases")
    cx.set_title("C. Matrix action: five slower configurations", loc="left", pad=17, fontsize=12)
    cx.text(0, 1.015, "FP64 CPU development timings; dense remains the default",
            transform=cx.transAxes, fontsize=8.5, color="#515E6A")

    fig.suptitle("HCSN: independent evidence changes the research direction", x=.07,
                 y=.97, ha="left", fontsize=20, fontweight="bold", color="#17344A")
    fig.text(.07, .92, "Frozen source a0b38d3d12c4 · 213 fit + 417 final cells · new namespaces and three predeclared seeds",
             fontsize=11, color="#526576")
    fig.text(.07, .025, "Descriptive results, not significance claims. Full per-seed values, NoUpdate decisions and original receipts are retained.\n"
             "Panels A/B use the prospective final data; panel C uses separate numerical development benchmarks. No post-final model selection.",
             fontsize=9, color="#526576", linespacing=1.6)
    args.output.mkdir(parents=True, exist_ok=True)
    for extension in ("png", "svg"):
        fig.savefig(args.output / ("results_overview." + extension), dpi=180, facecolor=fig.get_facecolor())
    plt.close(fig)


if __name__ == "__main__":
    main()
