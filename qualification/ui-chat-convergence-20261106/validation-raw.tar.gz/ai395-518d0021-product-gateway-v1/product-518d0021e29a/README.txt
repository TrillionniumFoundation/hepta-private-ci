Final 518d0021 gateway build and first boundary-scope execution evidence.

Read QUALIFICATION_INDEX.json and source-sync.json first. All four gateway groups and the original preview builder ran on clean commit518d0021e29a32e07c14d92b4c4e0cab5c4c4e8e/tree20834ab797f13ece7a89ae954b9505fc076e9be9.
The original hepta_ci_exec receipts retain raw log identities, minimum counts, deadlines, source parents and terminal states. Each original JUnit was copied before the next group could overwrite it.
Earlier Agentd/Memory/shared tests remain in a separate768f94ef archive; they are not relabeled as final-source runs. This bundle contains no binary, registry or target objects, and does not claim browser, provider or physical-device qualification.
FILE_MANIFEST.json hashes every other file and intentionally excludes itself.
