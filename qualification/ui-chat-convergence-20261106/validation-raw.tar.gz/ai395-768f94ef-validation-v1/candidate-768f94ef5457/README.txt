AI395 exact-source validation evidence.

Read QUALIFICATION_INDEX.json first. All selected Rust test runs bind to commit 768f94ef5457d0dbd0355cfdf3cb125fb966ee9f, tree 8df7e3a8abff4eacbb8d8a61b50daf9d29bea4e9.
The final formatter changed only test import formatting; its patch and both formatter attempts are preserved. The later approved source is not assigned these earlier run identities.
Original stdout/stderr files are complete and untrimmed. Receipt followups have distinct names and run IDs. Historical-source-fixtures are retained only as collector diagnostic copies and are not test runs of this candidate.
FILE_MANIFEST.json hashes every other file in this directory and intentionally excludes itself. No registry, target binaries or repository object cache is packaged.
