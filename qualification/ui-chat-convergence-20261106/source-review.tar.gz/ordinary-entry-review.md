# UI Owner 接线与精确源码审查

观察日期：2026-11-06 UTC。本文只读核查 Git 原始对象、远端固定提交、原 GitHub CI；没有改变产品源码、依赖 pin、工作流、Root 配置或授权。[旧源 a43/768 CI 快照](original-ci-snapshot.json) 和 [新源 65f/518 审查结束时快照](original-ci-snapshot-65f-518-review-close.json) 分别保留原身份与取值时刻。

## 结论

本轮 #4952/#4953 是向 67 Objective 分支的选择性修复：修复原 SDK 编辑事务、输入上限和原 Objective 客户端终态跟进。它们不能被称为普通产品入口已经闭合。

d4 分支存在替代 Owner 架构，不能因为旧 `desktop_objective_ui` 接口不在该分支而认定功能退化。外部 Desktop 有真实 `NativeChatComposition` 实现、Root 认证文本 adapter、原 thread/审批/历史和 Notes 控制。后续产品接线应沿这条既有 Owner 路线整合，保留一个 ChatWorkspace 和聊天内 Console；不把旧 port 注入为第二套 Owner，不从 renderer 创建 grant。

接口连续并不允许直接更换伴随仓库 pin。af0 声明的 194 个 Hepta 文件对原 14e 全部一致，对 d4 只有 147 个一致、47 个变化、0 个缺失；其中包含实际 Root、lease、Memory writer 和 Cargo.lock。必须重新形成精确两仓来源、六根锁、构建与真实运行收据。

## 精确来源

| 对象 | 完整提交 | 本次观察范围 |
| --- | --- | --- |
| Objective 分支基础 | 67cc5c28c4adf82f6ef97c34a18b8b13f3ac27ed | 本轮选择性修复的基础 |
| #4952 历史修复 head | a43c83afc89fd7fe84025bad66556fae23a6dbb3 | UI/IME/输入上限修复；下文已完成的旧 CI 保留原身份 |
| #4953 历史合并 head | 768f94ef5457d0dbd0355cfdf3cb125fb966ee9f | UI 与 Objective 跟进；下文 native 实测只属于此源 |
| #4952 最新格式修复 head | 65f266d07e3606ddeb109ef4683e1aecd201334c | basic_tests.rs 按原 Item imports 配方拆行 |
| #4953 最新最终 head | 518d0021e29a32e07c14d92b4c4e0cab5c4c4e8e | 双父合并 768 与 65f；tree 20834ab797f13ece7a89ae954b9505fc076e9be9，单独等待新 CI |
| 新 Owner/UI 候选 | d4a6e26bf7a79879118420db27d10e5e054ca9c8 | 本次静态接口与 source contract 对照 |
| Desktop af0 | af0e75dcb1e4868606aaf0b818b8b3e993534f10 | 实际 Cargo/profile pin 是 Hepta 14e |
| Desktop 1c8 | 1c8b37da8382862b35791044f444396423da4f8d | 实际 Cargo/profile pin 是 Hepta bfdf |
| Hepta 14e | 14e2d89b3367232ec5dbe6187f09feed0f2b68d3 | tree 0e12d53adf6a13721fdb2feef0e974d903b92e85 |
| Hepta bfdf | bfdf51e19efdfd38f6f6825372e81a790ed40c90 | tree ca6c2d3ad2951b8d5f4fa656dac49dbc434c533a |

af0 的提交本身是实验 G2 owner image profile，提交说明明确 source-only，没有更新当前产品 pin；不能把该分支名称当成当前已经安装的产品身份。af0/1c8 的 TEXT_SESSION.md 仍链接 a39 并称为当前 Cargo source，与实际 Cargo pin 不一致。源码判断以固定提交内实际 manifest、锁和 shared profile 为准。

来源：[af0 原提交](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/commit/af0e75dcb1e4868606aaf0b818b8b3e993534f10)、[af0 shared profile](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/af0e75dcb1e4868606aaf0b818b8b3e993534f10/support/ui/HEPTA_SHARED_PRESENTER.json)、[1c8 manifest](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/1c8b37da8382862b35791044f444396423da4f8d/services/hepta-session-host/Cargo.toml)。

## 普通入口的代码事实

### 67/768 旧 Objective port

对不可变 768 执行 `git grep install_original_objective_ui`，除了定义、导出和 TASK_LIFECYCLE.md，仅发现 desktop_objective_ui_tests.rs 调用，没有生产调用方。默认 Robrix main 直接启动 App，不会创建可信 Owner。原 `run_native_presentation` 在该仓库也没有生产组合实现。

因此，当前旧 port 提供的是受信任宿主可注入的 API。只凭代码中存在 worker、测试能 install、默认聊天外观可运行，不能证明普通用户能发出已授权任务。

来源：[768 install API](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/768f94ef5457d0dbd0355cfdf3cb125fb966ee9f/codex-rs/hepta-agentd/src/desktop_objective_ui.rs)、[768 测试调用](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/768f94ef5457d0dbd0355cfdf3cb125fb966ee9f/codex-rs/hepta-agentd/src/desktop_objective_ui_tests.rs)。

### d4 与真实 Desktop adapter

Desktop af0 的 `ui/shell/src/native_makepad.rs` 实现 `NativeChatComposition for DesktopComposition`，从既有 Desktop DraftBook 借用唯一 ChatWorkspace；`set_waker` 启动 `TextChatAdapter::start`；生产 `run` 调用原 `run_native_presentation`。Send、Stop、历史翻页、审批、Notes write/refresh/cancel 和 Console 都有真实调用。Console 的周期读取和恢复状态借用同一 Desktop bridge/reducer。

`services/hepta-session-host/src/text.rs` 的 adapter 只给 worker 提供 Root socket、预期 Root PID 与 UI waker。原 worker 通过 UID 0 peer 和 Root 返回的实际 owner/thread route，发出 Authenticated 后才安装 owner；普通 Connected 或健康状态不能启用 Send。发出任务前，原 ChatWorkspace 接受确切 signed reference 并给出 dispatch ticket；未知投递按原 identity 查回，不重新签发新的输入。独立审批能力与 Stop 能力分别检查。

d4 的 `authority_host_native_launch.rs` 有实际 trusted-host CLI 调用，验证 Root0600 profile、原程序摘要、原 Agentd/thread route、期限和进程身份；UI 获得 socket/PID 提示，没有 signer key。原 `objective_submission.rs` 和 `desktop_objective_state.rs` 保留实际 Notes/Calculator writer 路径与原 operation 终态映射，不能把它们视为纯 presenter。

来源：[Desktop 组合入口](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/af0e75dcb1e4868606aaf0b818b8b3e993534f10/ui/shell/src/native_makepad.rs)、[真实文本 adapter](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/af0e75dcb1e4868606aaf0b818b8b3e993534f10/services/hepta-session-host/src/text.rs)、[d4 原文本会话合同](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/d4a6e26bf7a79879118420db27d10e5e054ca9c8/codex-rs/hepta-agentd/NATIVE_TEXT_SESSION.md)、[d4 原生组合合同](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/d4a6e26bf7a79879118420db27d10e5e054ca9c8/apps/hepta-control-ui/rust/robrix-ui/NATIVE_COMPOSITION.md)。

## 194 文件与接口差异

[完整 source contract 差异](desktop-af0-vs-hepta-d4-source-contract.json) 保存每条路径的预期和实际 Git blob、字节数、SHA-256。方法为一次 `git cat-file --batch` 读取每个不可变 commit/path 的原字节，没有从工作区可能变动的文件计算。194/194 原 14e hash 校验通过，排除了错误基准。

| d4 相对 af0 所声明的 14e 文件清单 | 数量 |
| --- | ---: |
| 完全相同 | 147 |
| 内容变化 | 47 |
| 缺失 | 0 |

47 个变化分布：UI 3、Agentd 28、contracts 3、Memory 10、原 Cargo.lock 1、CALLERS.toml 1、源合同 QA 1。具体变化包含 composer transaction、Root admin/service/config/启动、issuer/Notes/Calculator deployment、authority lease/revoke、Memory outbox/production writer，以及 Cargo.lock。完整路径和前后 hash 见 JSON，不以抽样替代完整清单。

[独立接口子集差异](native-owner-interface-diff.json) 覆盖 chat_owner、native_presentation、全部 text_session 文件、native launch、desktop_objective_state 与 objective_submission。该子集中只有两份 text session 测试改变；生产接口和 worker 同字节。这解释了为什么外部 adapter 路线可继续对接，也解释了为什么「API 相同」仍不能取代完整 source profile 更新。上述 194 文件比较没有覆盖候选新增、但旧 profile 尚未列出的所有文件，不能作为新 profile 完备性认证。

## 六锁实际读回

[六锁 pin 与 SHA-256](desktop-candidates-six-lock-pins.json) 对 af0 和 1c8 共 12 份远端固定 Git 文件实际读取、解析 TOML；全部成功。没有运行新的 Cargo resolution，也没有改锁。

| 锁文件 | af0 的 Hepta source | 1c8 的 Hepta source | 补充 |
| --- | --- | --- | --- |
| ui/Cargo.lock | 14e，157 个 Hepta 包 | bfdf，157 个 Hepta 包 | 普通 Makepad Git SDK 均为 337566c8b25d47f7e4fff6a202157b65bf183330 |
| services/hepta-session-host/Cargo.lock | 14e，152 个 Hepta 包 | bfdf，152 个 Hepta 包 | 原 Root/Agentd 依赖图 |
| services/hepta-os/Cargo.lock | 无 Hepta Git 依赖 | 无 Hepta Git 依赖 | 两候选字节相同 |
| support/ui/Cargo.lock | 无 Hepta Git 依赖 | 无 Hepta Git 依赖 | 两候选字节相同 |
| tests/ui/Cargo.lock | 无 Hepta Git 依赖 | 无 Hepta Git 依赖 | 两候选字节相同 |
| support/ui/preedit-sdk/Cargo.lock | 14e，157 个 Hepta 包 | bfdf，157 个 Hepta 包 | 独立 prepared SDK 图；没有普通 Makepad Git source 条目 |

普通与 prepared 两图的不同是原产品合同的一部分。记录中的文件 hash 支持后续精确对照；它们不是新的编译、installed-product 或效果回执。

新 Owner 的 `native_presentation/chat_controls.rs::permits_submit` 已检查 InputLimit、非空文本、8192-byte 限制、room epoch/active 和 composing；Notes write 也已有 InputLimit 门。因此本轮 `objective_can_submit` 修复对应旧 port 的具体缺口，新路径已有等价约束，不需要无差别复制旧 UI controls。

## 部署状态与最小下一步

后续有界只读盘点已取得当前部署元数据，见 [deployment-metadata.md](deployment-metadata.md) 与两份原任务回执。2026-11-06 10:04:48 UTC 的 ai395 上，/var/lib/trill、/opt/trill、/run/trill 均 ENOENT；526 个 PID 的 comm 扫描未匹配已知产品进程。10:05:12 UTC 的 desktop 上，/var/lib/trill 为 UID 0/GID 0、0755，含 10 个 UID 0/GID 1000 的直接子目录；另外两个指定路径 ENOENT；912 个 PID 的 comm 扫描未匹配已知产品进程，有一个读取途中消失的 PID。两任务均使用固定幂等键、现有 UID/GID 1000 权限，succeeded/exit 0，输出完整且没有自动重试。目录列表和进程扫描均无截断。

因此已确认 desktop 有可继续核对的 Root 所属目录痕迹；**当前受信安装的 binary/source pin、Root profile 与服务身份仍 unknown**。没有进入子目录、读取 profile/环境/命令行或启动产品；目录名称和没有匹配 comm 都不能证明具体版本、授权状态或其他路径不存在安装。此前本 agent 的 inventory 查询超时，root 取得了 ai395、desktop、mac、main、pocket4、rog、x230 七个 configured aliases；这次实际元数据观察与配置清单严格分开。没有读取配置 secret，没有用历史 EAGAIN 推断当前失败，也没有把 Desktop main 路径不存在当成所有候选均不存在。本轮两 host 一轮盘点到此停止。

已核对的部署输入合同要求实际 Root-owned 程序与 source freeze、真实非 Root UID/GID、受保护 prefix、资源和显示环境、有限 owner/人类期限，以及具体原 Agentd/Core thread 和 Notes/Calculator 目标身份。产品 Root 的已实现有限 profile 使用原 provider 配置并有明确执行限制；这些配置声明不证明当前服务可用或实际模型完成任务。

可实施的下一步是：选定拥有真实 Desktop adapter 的具体两仓候选，复核并生成完整 source profile 和六锁，构建同源原 Shell/Root/Agentd/AppServer/Session；在已经获授的真实登录/issuer 边界下，核对当前 installed profile 后启动一次真实任务，保留原 thread、operation/run identity、独立效果回读与可靠终态。现有 API 不缺一个新造 renderer grant。旧 Objective port 的 bounded follow/backoff 思路如需迁入新 Owner，应先对其已有每 250 ms reconcile、每 1 s history observation 的状态机做等价性检查，不整文件复制第二套 worker。

来源：[产品 Root 配置与装配合同](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/af0e75dcb1e4868606aaf0b818b8b3e993534f10/services/hepta-session-host/src/product_root/README.md)、[精确 f5/14e source checkpoint](https://github.com/TrillionniumFoundation/trillionnium-os-desktop/blob/d27ae5dede3ebd91614b40fa6a9b47f5425f955e/results/integration/2026-11-03-organ-followup/joint-desktop-canonical14-source-20261104/README.md)。后者明确只完成源码/六锁图检查，未编译或运行验证该产品组合。

## 本轮 CI 与边界

[CI 原始 jobs snapshot](original-ci-snapshot.json) 保存 #4952 a43 与 #4953 768 的原工作流/step 状态。当前快照中，两个 PR 的 UI 工作流仍有运行 job；不会把排队、运行或跳过记成 pass。architecture/base-merge 的整体 success 也不能把其中跳过的原生步骤计成执行通过。

#4953 的原 native/source-head job 127816602180 已成功，并取得完整原日志：

- immutable tested SHA 768f94ef5457d0dbd0355cfdf3cb125fb966ee9f，tree 8df7e3a8abff4eacbb8d8a61b50daf9d29bea4e9，before/after clean。
- headless 原库 28/28、0 skipped。
- `ui,native-host,native-presentation` 原库 37/37、0 skipped。
- 六项真实 Makepad TextInput composer transaction 回归逐项 PASS：unchanged commit、预编辑保持/取消、超限选择区与 undo 回滚、跨会话隔离。
- 这是实际 SDK 组件执行；没有授予真人输入法、真实 GUI 设备、provider 或 Notes 效果资格。

[原 native 来源回执](native-768-source-head-evidence.json) 和 [完整原 job 日志](native-768-source-head-full.log) 保留旧源身份。原 job：[42195199219 / 127816602180](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42195199219/job/127816602180)。

同一快照中 #4953 Windows private-state、Windows Memory gate、musl build/process smoke 完成成功；Linux Memory/完整 owner 与更多 required jobs 仍运行。#4952 cargo-deny job 127817511806 与 macOS Intel Bazel job 127817512273 已失败；#4953 cargo-deny job 127820526212 已失败。新 cargo-deny 完整日志获取仍报 Transport closed，**尚不能将历史 pin-utils advisory 作为这两个新 job 的已证原因**。

root 独立读取 [#4952 Intel 原 job 日志](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42194800442/job/127817512273)，定位 `tests::pty_dropped_output_receiver_keeps_draining_child` deadline elapsed；PTY 30 pass/1 fail/0 ignored，Bazel 437 pass/1 fail/167 skip。该源文件不在本轮 UI 修改中，但原 required failure 仍保留，不能宣称全仓绿。

#4952 owner job 127815251013 的 format step 已 failure；root 随后用原格式配方定位本轮 basic_tests.rs 的 grouped imports，只做 Item 拆行并发布 65f 与双父合并 518。旧 original-ci-snapshot.json 和 native 通过记录仍绑定 a43/768，最新 head 的结果另存，不能继承这些值。

审查结束时，新源 65f/518 的两个 UI、两个 Objective owner、两个 blocking-ci 均 pending 且 jobs 为空；新源其他原生 gate 仍 queued/in_progress。V8 canary 的 success 由 metadata 成功、两个 build skipped 构成，不能作为新的 V8 构建结果。新源尚无 UI/native 完整通过记录，也无已失败的新 job 可取原日志。

## TASK_LIFECYCLE.md 核对

768 文档与本次代码相符：可信宿主注入；无 owner 的默认入口不授予发送；单 worker 观察、正常 1 s，Unknown 2/4/5 s 上限；窗口关闭/期限失效/终态停止；不重复 effectful Submit/Cancel；除 request_id 外相同原 response 去重，保留 64-event 边界；恢复只查原 run、不恢复新发送资格；只有原 Memory 保存与独立 ACK 后才能呈现可靠结果。

本地 Cancel 已保存而第二 checkpoint ACK 丢失的跟进缺口经独立审查发现并修复：follow 使用 started 或 cancelled。新的确定性回归先使第二 ACK 不可见，再通过第三次只读 ACK 恢复 LocalCancelled，assert starts/cancels/lookups/effects 均为 0。文档也明确 client recovery 不等于 Agentd/AppServer 双进程恢复，fixture 不能作为真实外部效果回执。未发现文档将这些局部测试写成产品闭环。
