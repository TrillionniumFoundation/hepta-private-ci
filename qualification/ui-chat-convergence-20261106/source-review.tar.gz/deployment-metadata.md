# 当前部署元数据：ai395 与 desktop

2026-11-06 UTC，仅对 root 指定的两个 configured hosts 各执行一次固定幂等键的只读盘点。没有 sudo、没有启动 UI/provider、没有改变服务或配置；没有读取 profile 内容、进程环境或进程命令行。探测源码见 [deployment-metadata-probe.py](deployment-metadata-probe.py)。

## 任务终态

| Host | 原任务 ID | 幂等键 | 结果 | 元数据观察时刻 |
| --- | --- | --- | --- | --- |
| ai395 | 1a1b051681e-fc05-6fb8 | ui-deploy-metadata-ai395-20261106-v1 | succeeded，exit 0；stderr 0 bytes | 10:04:48 UTC |
| desktop | 1a1b051c3e4-fc05-6fba | ui-deploy-metadata-desktop-20261106-v1 | succeeded，exit 0；stderr 0 bytes | 10:05:12 UTC |

两个探测均以现有 operator UID/GID 1000 执行，无 automatic retry；两个 stdout 均读到 EOF。执行和原终态回执分别见 [ai395 原记录](deployment-metadata-ai395.json) 与 [desktop 原记录](deployment-metadata-desktop.json)。

## 实际观察

| Host | /var/lib/trill | /opt/trill | /run/trill | 已知进程名称匹配 |
| --- | --- | --- | --- | --- |
| ai395 | ENOENT | ENOENT | ENOENT | 526 个 PID 的 comm 扫描中未发现匹配 |
| desktop | 物理目录，UID 0/GID 0，0755；直接子目录 10 个 | ENOENT | ENOENT | 912 个 PID 的 comm 扫描中未发现匹配；1 个 PID 在读取时消失，返回 ENOENT |

目录列表和 /proc 扫描均未达到截断上限。只枚举三个指定目录的直接子项，没有深入子目录或读取其中文件。

desktop 的十个直接子目录全部是 UID 0/GID 1000：

| 模式 | 目录名称 |
| --- | --- |
| 0750 | d1104n2、d1104s2、ne74e8704、o1104s2、s1104s2、se74e8704 |
| 0700 | o1103n1、o1104n1、s1103as1、s1104n1 |

进程匹配范围为 hepta-agentd、hepta-authority、hepta-authority-host、hepta-desktop、hepta-desktop-root、trill-shell、trill-session、trill-app-window、hepta-app-server，并考虑 Linux comm 的 15 字符截断。只对匹配项才会读取 /proc/PID/exe 符号链接；本轮没有匹配项，因此没有取得这些产品进程的 executable path。

## 结论边界

已经确认 **desktop 当前存在可继续核对的 Root 所属目录痕迹**，因此不能笼统写成当前部署位置完全未知。ai395 在三个指定路径没有对应目录；两台机器在这次扫描时没有发现指定名称的产品进程。

这些元数据仍不足以证明十个目录中的哪一个是当前受信安装，也不足以确认 installed binary/source pin、Root profile、服务状态、授权期限或真实用户入口。目录名称不作为版本或运行资格；没有匹配 comm 不证明其他名称、其他路径或其他时刻不存在安装。当前服务和配置身份仍待受限的后续核对，**本轮到此停止**。

本次没有读取任何 profile/环境/命令行，没有用历史 EAGAIN 推断当前失败，也没有进行第二轮探测或遍历其他 host。
