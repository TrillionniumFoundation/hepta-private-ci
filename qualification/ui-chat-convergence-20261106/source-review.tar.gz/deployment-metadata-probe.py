import os
import stat
import json
import signal
import time
import datetime

result = {
    "schema": "hepta.deployment-metadata.v1",
    "observed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "effective_uid": os.geteuid(),
    "effective_gid": os.getegid(),
    "scope": "Metadata only: specified directory names/owner/mode; known process comm, PID, executable path. No profile content, environment, command line, sudo, service changes or process starts.",
    "directories": [],
    "processes": [],
    "complete": False,
}

class ReadTimeout(Exception):
    pass

def deadline(signum, frame):
    raise ReadTimeout("15-second metadata deadline reached")

def issue(error):
    return {
        "type": type(error).__name__,
        "errno": getattr(error, "errno", None),
        "message": str(error),
    }

def metadata(path, st):
    return {
        "path": path,
        "uid": st.st_uid,
        "gid": st.st_gid,
        "mode": oct(stat.S_IMODE(st.st_mode)),
        "kind": "directory" if stat.S_ISDIR(st.st_mode) else "symlink" if stat.S_ISLNK(st.st_mode) else "regular" if stat.S_ISREG(st.st_mode) else "other",
    }

signal.signal(signal.SIGALRM, deadline)
signal.alarm(15)
try:
    for path in ("/var/lib/trill", "/opt/trill", "/run/trill"):
        row = {"path": path}
        result["directories"].append(row)
        try:
            st = os.stat(path, follow_symlinks=False)
            row.update(metadata(path, st))
        except OSError as error:
            row["stat_error"] = issue(error)
            continue
        if not stat.S_ISDIR(st.st_mode):
            row["list_skipped"] = "Exact path is not a physical directory"
            continue
        row["entries"] = []
        row["list_truncated"] = False
        try:
            with os.scandir(path) as entries:
                for i, entry in enumerate(entries):
                    if i >= 64:
                        row["list_truncated"] = True
                        break
                    item = {"name": entry.name}
                    try:
                        item.update(metadata(entry.path, entry.stat(follow_symlinks=False)))
                    except OSError as error:
                        item["stat_error"] = issue(error)
                    row["entries"].append(item)
            row["entries"].sort(key=lambda item: item["name"])
        except OSError as error:
            row["list_error"] = issue(error)

    names = (
        "hepta-agentd",
        "hepta-authority",
        "hepta-authority-host",
        "hepta-desktop",
        "hepta-desktop-root",
        "trill-shell",
        "trill-session",
        "trill-app-window",
        "hepta-app-server",
    )
    accepted = set(names) | {name[:15] for name in names}
    proc = {
        "requested_names": list(names),
        "linux_comm_truncation_considered": True,
        "pid_scan_limit": 4096,
        "pids_observed": 0,
        "comm_errors": {},
        "error_examples": [],
        "truncated": False,
    }
    result["process_scan"] = proc
    try:
        with os.scandir("/proc") as entries:
            for entry in entries:
                if not entry.name.isdigit():
                    continue
                if proc["pids_observed"] >= proc["pid_scan_limit"]:
                    proc["truncated"] = True
                    break
                proc["pids_observed"] += 1
                try:
                    with open(entry.path + "/comm", "r", encoding="utf-8", errors="replace") as stream:
                        comm = stream.read(64).rstrip("\n")
                except OSError as error:
                    code = str(getattr(error, "errno", None))
                    proc["comm_errors"][code] = proc["comm_errors"].get(code, 0) + 1
                    if len(proc["error_examples"]) < 8:
                        proc["error_examples"].append({"pid": int(entry.name), "error": issue(error)})
                    continue
                if comm not in accepted:
                    continue
                item = {"pid": int(entry.name), "comm": comm}
                try:
                    item["exe"] = os.readlink(entry.path + "/exe")
                except OSError as error:
                    item["exe_error"] = issue(error)
                result["processes"].append(item)
        result["processes"].sort(key=lambda item: item["pid"])
    except OSError as error:
        proc["scan_error"] = issue(error)
    result["complete"] = True
except ReadTimeout as error:
    result["timeout"] = str(error)
finally:
    signal.alarm(0)

result["finished_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
print(json.dumps(result, ensure_ascii=False, sort_keys=True))
