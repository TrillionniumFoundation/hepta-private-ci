set -euo pipefail
cd /home/qq/hepta-ui-qualification-20261106-768f94ef/repo
sha256sum -c "$EVIDENCE_DIR/original-lock.sha256"
test "$(git rev-parse HEAD)" = 518d0021e29a32e07c14d92b4c4e0cab5c4c4e8e
test "$(git rev-parse 'HEAD^{tree}')" = 20834ab797f13ece7a89ae954b9505fc076e9be9
test -z "$(git status --porcelain)"
git diff --exit-code HEAD --
