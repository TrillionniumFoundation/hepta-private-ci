Exact final source UI verification on ai395

Read final-verification-summary.json first. The complete original browser matrices failed because WebKit host validation requires a system ldconfig cache entry. Chromium and Firefox executed their original scenarios successfully. The product/gateway and HTTP gates passed only their stated missing-owner/transport scopes; no real task effect-to-terminal acceptance is claimed.

The original scripts, pins, headless settings, selectors, payload limits and deadlines were retained. Node/Rust/browser and Ubuntu dependency inputs were prepared only in this task directory. No system configuration, sandbox, Playwright dependency validation or product source was changed to obtain a pass.

All original text reports/logs and build manifests are included. Raw PNGs remain at their original task/archived paths and are inventoried by digest, dimensions and path. They are omitted from this text bundle. The three manual QA images were transferred separately by root; images are supplemental QA.

hepta_ci_exec records exit/identity but does not parse Playwright counts: use the original Playwright JSON stats and runner logs for 4/6, 7/7 and 6/9 counts. The earlier 768 native 28/37 bundle is separate and is not promoted to this commit.
