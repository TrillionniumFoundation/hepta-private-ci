source /home/qq/hepta-ui-qualification-20261106-768f94ef/ui-env.sh
export SOURCE_SHA=518d0021e29a32e07c14d92b4c4e0cab5c4c4e8e TESTED_SHA=518d0021e29a32e07c14d92b4c4e0cab5c4c4e8e
export EVIDENCE_DIR="$UI_ROOT/evidence/518d0021"
export GST_PLUGIN_PATH="$UI_ROOT/deps/prefix/usr/lib/x86_64-linux-gnu/gstreamer-1.0"
export HEPTA_GATEWAY_EXAMPLE=/home/qq/hepta-ui-convergence-20261106-50b100/target/debug/examples/ui_product_preview
