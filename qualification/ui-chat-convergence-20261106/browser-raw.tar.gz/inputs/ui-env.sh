UI_ROOT=/home/qq/hepta-ui-qualification-20261106-768f94ef
export RUSTUP_HOME="$UI_ROOT/rustup" CARGO_HOME="$UI_ROOT/cargo-home" RUSTUP_TOOLCHAIN=1.95.0
export PATH="$UI_ROOT/deps/prefix/usr/bin:$UI_ROOT/tools/node-v22.21.1-linux-x64/bin:$UI_ROOT/tools/bin:/home/qq/.cargo/bin:$PATH"
export LD_LIBRARY_PATH="$UI_ROOT/deps/prefix/usr/lib/x86_64-linux-gnu"
export LIBRARY_PATH="$UI_ROOT/deps/prefix/usr/lib/x86_64-linux-gnu"
export PKG_CONFIG_PATH="$UI_ROOT/deps/prefix/usr/lib/x86_64-linux-gnu/pkgconfig"
export TESSDATA_PREFIX="$UI_ROOT/deps/prefix/usr/share/tesseract-ocr/5/tessdata"
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_RELEASE_DEBUG=0
export CARGO_TARGET_DIR="$UI_ROOT/native-target"
export CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER=/opt/rocm/llvm/bin/clang
export SOURCE_SHA=768f94ef5457d0dbd0355cfdf3cb125fb966ee9f TESTED_SHA=768f94ef5457d0dbd0355cfdf3cb125fb966ee9f
export HEPTA_CI_LANE=source-head PLAYWRIGHT_BROWSERS_PATH="$UI_ROOT/browsers"
export HEPTA_CHROMIUM_EXECUTABLE="$UI_ROOT/chromium-pin/chrome-headless-shell-linux64/chrome-headless-shell"
export TMPDIR="$UI_ROOT/tmp"
