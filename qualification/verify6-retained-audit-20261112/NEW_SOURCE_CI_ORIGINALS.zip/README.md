# VERIFY-5 successor CI receipts

Read-only original GitHub responses and complete decoded logs. No dispatch,
rerun or local model execution occurred during this audit.

| Source | Run / macOS job | Observed result |
| --- | --- | --- |
| `4a08232dbf90f4cbfa995dcaa29607cbd097762e` | 43160116619 / 130989017014 | 242 tests, 132 trajectories, success |
| `3ace899a1c61bfda1a46074a5dacc655dda22b09` | 43160483678 / 130990206102 | 255 tests, 132 trajectories, `CONSISTENT_COMPLETE_RECORDS`, success |
| `b4717e6db7dbb933abb473752ca8f6223638e8a8` | 43160576871 / 130990511646 | 260 tests, 132 trajectories, `CONSISTENT_COMPLETE_RECORDS`, success |

Each log binds the exact source checkout and reports the existing SQLite
72/72 rows and dispatch 9 scenarios / 17 subprocesses. Each new study reports
one frequency-model fit and sixty frequency predictions. Four arms each accept
six of eighteen; no known value error is accepted. Test-level skips/failures
were not reported in these three completed logs. Repeated controlled cases are
not independent new business tasks. Scientific admission remains HOLD.

The attribution head's paid-observation shell step includes the actual
`observation_attribution --input ... --output .../observation-attribution.json`
command and completed successfully. That command writes a file without a
scalar stdout summary. The log does not independently disclose its numerical
attribution results; its uploaded output artifact was not downloaded in this
bounded readback. Do not infer those numerical results from step success.

Current job snapshots retain Ubuntu queued and Windows in progress for the
attribution head. Other platform states belong to their own retained snapshots;
no full-matrix success is claimed. Packaging blocking run 43160116750 returned
an empty job list on three direct reads. Its blob-policy outcome remains
unverified. The original oversize failure remains in the separate earlier
`ci-audit` evidence and was not overwritten.

`AUDIT.json` records source/log SHA-256 identities and exact summary lines.
`MANIFEST.json` binds all retained files. Decoded-log hashes cover UTF-8 bytes,
including original BOM/CRLF where returned, not compressed provider archives.
