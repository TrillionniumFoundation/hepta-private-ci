"""Archive the frozen wall-budget campaign without rerunning its models."""

import hashlib
import io
import json
from pathlib import Path
import statistics
import tarfile


ROOT = Path('/workspace/scratch/d741f7769aeb')
STUDY = ROOT / 'hx-wall-budget-20261119'
DIAGNOSTIC = ROOT / 'hx-wall-first-fit-diagnostic-20261119'
CODE = ROOT / 'worktrees/hx-cell'
DEST = CODE / 'qualification/hcsn/campaign_audits/hx-wall-20261119'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def mean(values):
    return statistics.mean(values) if values else None


def stdev(values):
    return statistics.stdev(values) if len(values) > 1 else None


def measurement(row):
    record = row['result']
    budget = record['training_wall_budget']
    return dict(
        task=record['task'], model=record['model'], seed=record['seed'],
        validation_mse=record['best_validation_mse'], test_mse=record['test_mse'],
        actual_steps=record['training_steps_completed'],
        in_budget_steps=record['optimizer_steps_within_wall_budget'],
        selected_step=budget['best_checkpoint_step'],
        selected_wall=budget['best_checkpoint_wall_seconds'],
        training_wall=record['training_wall_seconds_including_validation'],
        training_cpu=record['training_process_cpu_seconds_including_validation'],
        process_wall=row['process']['wall_seconds'], overrun=budget['overrun_seconds'],
        peak_rss_bytes=record['process_peak_rss']['bytes'],
        raw_parameter_gradient_max_l2=record['gradient_l2_max_by_parameter'].get('encoder.raw_financial'),
        selected_raw_parameter_delta_l2=record['selected_parameter_delta_l2'].get('encoder.raw_financial'),
        constant_predictor_test_mse=record['attempts'][0]['dataset']['constant_predictor_test_mse'])


report = json.loads((STUDY / 'RESULT.json').read_text())
config = report['config']
records = [row['result'] for row in report['rows'] if row.get('result')]
expected = {(task, model, seed) for task in config['tasks']
            for model in config['models'] for seed in config['seeds']}
observed = [(row['task'], row['model'], row['seed']) for row in report['rows']]
assert len(observed) == len(set(observed)) and set(observed) == expected
frozen = json.loads((STUDY / 'SOURCE.json').read_text())
source_data = {}
for relative, expected_sha in frozen.items():
    data = (CODE / 'qualification/hcsn' / relative).read_bytes()
    assert digest(data) == expected_sha, relative
    source_data['frozen-source/qualification/hcsn/' + relative] = data
split_hashes = {}
selected = []
for row in report['rows']:
    record = row.get('result')
    if record is None:
        continue
    raw_report = json.loads((STUDY / row['report']).read_text())
    assert raw_report['source_files_sha256'] == frozen
    if record['status'] != 'completed':
        continue
    budget = record['training_wall_budget']
    assert budget['best_checkpoint_eligible']
    assert budget['best_checkpoint_wall_seconds'] <= config['training_wall_seconds']
    assert budget['filled']
    curve = [point for point in record['validation_curve'] if point['eligible']]
    assert all(point['wall_seconds'] <= config['training_wall_seconds'] for point in curve)
    assert record['best_validation_mse'] == min(point['mse'] for point in curve)
    checkpoint = Path(record['best_checkpoint'])
    assert digest(checkpoint.read_bytes()) == record['best_checkpoint_sha256']
    assert row['process']['returncode'] == 0 and not row['process']['timed_out']
    assert row['process']['direct_child_reaped']
    attempt = record['attempts'][0]
    sha = attempt['dataset']['split_sha256']
    previous = split_hashes.setdefault(record['task'], sha)
    assert sha == previous
    selected.append(measurement(row))

diagnostic_report = json.loads((DIAGNOSTIC/'RESULT.json').read_text())
assert diagnostic_report['config'] == json.loads((STUDY/'000-delayed_recall-hx_dual-101/CONFIG.json').read_text())
assert diagnostic_report['source_files_sha256'] == frozen
assert diagnostic_report['requested'] == 1
diagnostic_row = diagnostic_report['rows'][0]
diagnostic_result = diagnostic_row.get('result')
diagnostic = dict(reason='one repeat for the documented concurrent scalar-review/import window in original fit 000',
                  included_in_main_statistics=False, original=selected[0], repeat_status=diagnostic_row['status'])
if diagnostic_result is not None and diagnostic_result['status'] == 'completed':
    assert diagnostic_result['training_wall_budget']['best_checkpoint_eligible']
    assert diagnostic_result['training_wall_budget']['best_checkpoint_wall_seconds'] <= 20
    assert diagnostic_result['training_wall_budget']['filled']
    assert diagnostic_result['attempts'][0]['dataset']['split_sha256'] == split_hashes['delayed_recall']
    assert digest(Path(diagnostic_result['best_checkpoint']).read_bytes()) == diagnostic_result['best_checkpoint_sha256']
    assert diagnostic_row['process']['returncode'] == 0 and diagnostic_row['process']['direct_child_reaped']
    diagnostic['repeat'] = measurement(diagnostic_row)
else:
    diagnostic['repeat'] = diagnostic_row

groups = []
for task in config['tasks']:
    for model in config['models']:
        rows = [row for row in report['rows'] if row['task'] == task and row['model'] == model]
        fits = [row['result'] for row in rows if row.get('result', {}).get('status') == 'completed']
        measurements = [row for row in selected if row['task'] == task and row['model'] == model]
        group = dict(task=task, model=model, requested=len(config['seeds']), completed=len(fits),
                     failed_or_censored=len(rows)-len(fits),
                     selected_initial_checkpoint_count=sum(row['selected_step'] == 0 for row in measurements))
        for key in ('test_mse', 'actual_steps', 'in_budget_steps', 'selected_step', 'training_wall',
                    'training_cpu', 'process_wall', 'overrun', 'peak_rss_bytes'):
            values = [row[key] for row in measurements]
            group[key + '_mean'] = mean(values)
            group[key + '_sample_sd'] = stdev(values)
            group[key + '_range'] = [min(values), max(values)] if values else None
        group['total_process_wall_all_attempts'] = sum(row['process']['wall_seconds']
                                                      for row in rows if row['process'])
        group['time_to_quality'] = []
        for ratio in config['quality_ratios']:
            reached = []
            for fit in fits:
                target = ratio * fit['validation_constant_mse']
                point = next((p for p in fit['validation_curve']
                              if p['eligible'] and p['best_mse'] <= target), None)
                reached.append(dict(seed=fit['seed'], target_validation_mse=target,
                                    wall_seconds=point['wall_seconds'] if point else None))
            group['time_to_quality'].append(dict(ratio=ratio, reached=sum(r['wall_seconds'] is not None for r in reached),
                                                requested=len(config['seeds']), observations=reached))
        group['parameters'] = sorted(set(fit['trainable_parameters'] for fit in fits))
        group['state_bytes_per_example'] = sorted(set(fit['persistent_state']['bytes'] /
                                                       fit['persistent_state']['batch_size'] for fit in fits))
        group['inference_p50_ms_mean'] = mean([fit['latency_p50_ms'] for fit in fits])
        groups.append(group)

pairs = []
for task in config['tasks']:
    for other in ('hx_dual_prepared', 'matched_gate', 'hx_call', 'hx_risk', 'gru'):
        differences = []
        for seed in config['seeds']:
            fit = {r['model']: r for r in selected if r['task'] == task and r['seed'] == seed}
            if 'hx_dual' in fit and other in fit:
                differences.append(dict(seed=seed, test_mse_hx_minus_control=fit['hx_dual']['test_mse']-fit[other]['test_mse']))
        pairs.append(dict(task=task, control=other, observations=differences,
                          mean_hx_minus_control=mean([r['test_mse_hx_minus_control'] for r in differences])))

summary = dict(schema='hepta.hx-wall-evidence.v1', source_commit='7f86d02273a',
               original_report='wall-budget-20261119/RESULT.json', config=config,
               status=report['status'], requested=report['requested'], completed=report['completed'],
               controller_wall_seconds=report['wall_seconds'],
               selected_initial_checkpoint_count=sum(row['selected_step'] == 0 for row in selected),
               source_files_sha256=frozen, independent_split_sha256=split_hashes,
               groups=groups, selected_runs=selected, paired_comparisons=pairs,
               first_fit_diagnostic=diagnostic,
               validation='complete matrix, frozen source, eligible selected checkpoints, checkpoint SHA256, '
                          'independent split identity and exited/reaped child processes checked without model rerun',
               limitations=['small synthetic feature-cell tasks; not Cell E07 or regenerative HCSN',
                            'three seeds, 20-second budget, no convergence or multimodal scaling claim',
                            'shared managed CPU, not an exclusive reserved host; scalar review/import window within first fit documented in provenance review',
                            'process RSS includes runtime; persistent state excludes parameters/optimizer',
                            'physical energy unavailable and retained as null',
                            'periodic validation selection; final unvalidated updates do not select weights',
                            'memory checkpoint cloning is timed; final torch.save/test/latency is outside the 20-second timer'])
DEST.mkdir(parents=True, exist_ok=False)
(DEST/'WALL_BUDGET.json').write_text(json.dumps(summary, ensure_ascii=False, separators=(',', ':'))+'\n')

files = dict(source_data)
for path in sorted(STUDY.rglob('*')):
    if path.is_file():
        files['wall-budget-20261119/' + path.relative_to(STUDY).as_posix()] = path.read_bytes()
for path in sorted(DIAGNOSTIC.rglob('*')):
    if path.is_file():
        files['first-fit-diagnostic-20261119/' + path.relative_to(DIAGNOSTIC).as_posix()] = path.read_bytes()
for filename in ('hx-wall-budget-20261119.log', 'hx-wall-budget-tests.log', 'hx-wall-budget-plan.json',
                 'hx-wall-first-fit-diagnostic-20261119.log', 'hx-wall-budget-review.txt',
                 'hx-source-publish-manifest.json', 'hx-cell-fmt.log',
                 'archive_hx_wall.py', 'render_hx_wall_report.py'):
    files['provenance/'+filename] = (ROOT/filename).read_bytes()
for filename in ('configs/hx-wall-budget-small.json', 'README.md', 'EQUITY_REUSE.md'):
    files['frozen-source/qualification/hcsn/'+filename] = (CODE/'qualification/hcsn'/filename).read_bytes()
manifest = {name:digest(data) for name,data in sorted(files.items())}
files['MANIFEST.json'] = (json.dumps(manifest, indent=2)+'\n').encode()
archive = DEST/'wall-budget-originals.tar.gz'
with tarfile.open(archive, 'w:gz') as target:
    for name,data in sorted(files.items()):
        member=tarfile.TarInfo(name)
        member.size=len(data)
        target.addfile(member, io.BytesIO(data))
print(json.dumps(dict(artifact=str(archive), archive_sha256=digest(archive.read_bytes()),
                      archive_bytes=archive.stat().st_size, archived_files=len(files), groups=groups), indent=2))
