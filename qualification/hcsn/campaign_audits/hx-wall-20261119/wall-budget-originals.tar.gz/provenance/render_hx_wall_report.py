"""Render the retained experiment measurements, without rerunning models."""

from pathlib import Path
import json
import statistics

root = Path('/workspace/scratch/d741f7769aeb/worktrees/hx-cell/qualification/hcsn/campaign_audits/hx-wall-20261119')
report = json.loads((root/'WALL_BUDGET.json').read_text())
groups, fits = report['groups'], report['selected_runs']


def quality(group):
    return f"{group['test_mse_mean']:.6g} ± {group['test_mse_sample_sd']:.6g}"


lines = [
    '# Parameter-matched HX feature study: filled 20-second budgets', '',
    f"The prespecified matrix completed **{report['completed']}/{report['requested']} fits** "
    f"in {report['controller_wall_seconds']:.3f} controller seconds. Each fit has a new process. "
    'All original samples remain in the main statistics. One separately identified repeat of the first fit '
    'diagnoses a documented concurrent review process; it is excluded from the 36-fit statistics.', '',
    'The existing delayed-recall and adding generators use data seed 271828 and independent '
    '512/128/256 train/validation/test examples. Initialization/minibatch seeds are 101, 211 and 307. '
    'Length is 16, width 8, batch 32, dt 0.1, eager FP32, Adam learning rate 0.003, and one PyTorch/BLAS CPU thread. '
    'The parameter-matched gate shares the HX memory/recovery maps and common initial tensor values; '
    'its sigmoid features replace the finance functions. Equal initial tensors do not imply equal initial outputs.', '',
    '## Deadline and selection rule', '',
    'The 20-second interval starts before initial validation and includes training, gradient/parameter checks, '
    'periodic validation and in-memory checkpoint copies. Validation is scheduled every four elapsed seconds. '
    'Both validation and the candidate copy must finish by 20 seconds to select weights. An in-flight operation '
    'may overrun: its entire time and actual optimizer update are retained, but a late checkpoint is ineligible. '
    'The selected checkpoint is tested once. Final torch.save, test and latency measurements, imports, model/data '
    'construction and the persistent-state probe lie outside this interval and inside the measured child process. '
    'The process timeout is 90 seconds, campaign cap 1,500 seconds, and 100,000 steps is only a nonbinding guard.', '',
    '## Main results', '',
    'MSE is lower-is-better; uncertainty is sample standard deviation over three initialization/minibatch seeds '
    'on one shared independent test set, not a confidence interval over new datasets. Update ranges include '
    'the final in-flight update. The JSON separately records in-budget updates and checkpoint selection.', '',
    '| Task | Model | Fits | Test MSE mean ± sample SD | Actual updates, min–max | Selected step 0 |',
    '| --- | --- | ---: | ---: | ---: | ---: |',
]
for group in groups:
    low, high = group['actual_steps_range']
    lines.append(f"| {group['task']} | {group['model']} | {group['completed']}/3 | {quality(group)} | "
                 f"{low}–{high} | {group['selected_initial_checkpoint_count']} |")
lines += ['', 'A completed fit means execution completed; a selected initial checkpoint or failure to beat the '
          'constant predictor is not evidence of successful learning. Raw per-seed validation curves, test '
          'MSE, actual and in-budget updates, gradients, selected parameter changes and all cost records are retained.', '',
          '## Cost and state', '',
          '| Model | Parameters | Persistent bytes/example | Process RSS range, MiB | Training CPU/wall range |',
          '| --- | ---: | ---: | ---: | ---: |']
for model in report['config']['models']:
    selected = [fit for fit in fits if fit['model'] == model]
    group = next(group for group in groups if group['model'] == model)
    rss = [fit['peak_rss_bytes']/1024**2 for fit in selected]
    ratios = [fit['training_cpu']/fit['training_wall'] for fit in selected]
    lines.append(f"| {model} | {group['parameters'][0]} | {group['state_bytes_per_example'][0]:g} | "
                 f"{min(rss):.2f}–{max(rss):.2f} | {min(ratios):.3f}–{max(ratios):.3f} |")
lines += ['', 'HX/gate retained state is the actual memory and recovery tensor payload. GRU retains its hidden tensor. '
          'Parameter and optimizer bytes are separate. These feature cells have no density or refractory queue. '
          'RSS is a child-process lifetime high-water mark including Python, libraries, datasets, test and inference; '
          'it is not training-only allocator memory. Energy is unavailable (`null` with a reason), not inferred from runtime.', '',
          '## First observed time to half the constant-predictor validation error', '',
          'These are validation observations, not exact crossing times. All three seeds remain in each denominator; '
          'not reaching the target by the budget is censored. Full 0.9/0.75/0.5 target records are in the JSON.', '',
          '| Task | Model | Reached within budget | Observed seconds, reached seeds |',
          '| --- | --- | ---: | --- |']
for group in groups:
    target = next(item for item in group['time_to_quality'] if item['ratio'] == 0.5)
    times = ', '.join(f"{item['seed']}: {item['wall_seconds']:.3f}" for item in target['observations']
                      if item['wall_seconds'] is not None) or 'not reached'
    lines.append(f"| {group['task']} | {group['model']} | {target['reached']}/3 | {times} |")
lines += ['', '## Environment and the separate first-fit repeat', '',
          'This is a shared managed CPU host, not an exclusive reservation. An independent eight-scalar '
          'tail review had a script/result timestamp window 05:39:42.608–05:39:44.556 UTC, within original '
          'fit 000’s process interval 05:39:32.506–05:39:58.268 UTC. Its 0.0823 CPU seconds cover the scalar '
          'calculation only, excluding Python/Torch imports. The concurrent window is retained as a known '
          'environment limitation. Later fits began after that review completed. Other observed timing '
          'variation remains part of the evidence; there is no post-hoc outlier deletion.', '',
          'After all 36 fits, only original fit 000 was repeated once with the exact source, configuration, '
          'seed and data in a new output directory. The repeat is diagnostic and does not replace the original.', '',
          '| First-fit observation | Actual / in-budget updates | Selected step | Validation MSE | Test MSE | Training wall / CPU seconds |',
          '| --- | ---: | ---: | ---: | ---: | ---: |']
diagnostic = report['first_fit_diagnostic']
for label in ('original', 'repeat'):
    fit = diagnostic[label]
    if 'actual_steps' not in fit:
        lines.append(f"| {label} | {diagnostic['repeat_status']} | — | — | — | — |")
        continue
    lines.append(f"| {label} | {fit['actual_steps']} / {fit['in_budget_steps']} | {fit['selected_step']} | "
                 f"{fit['validation_mse']:.6g} | {fit['test_mse']:.6g} | "
                 f"{fit['training_wall']:.3f} / {fit['training_cpu']:.3f} |")
largest = max(fits, key=lambda fit: fit['overrun'])
lines += ['', f"The largest retained overrun is {largest['overrun']:.3f} seconds in "
          f"`{largest['task']}/{largest['model']}/{largest['seed']}`. The deadline eligibility rule is unchanged.", '',
          '## Scope and reproducibility', '',
          'This study addresses the cost and usefulness of **HX equity/V and first-passage probability features**. '
          'The second feature is a probability, not a put price or a self-exciting run process. This cell does '
          'not implement hitting/reset/refractory population flow. Its financial boundary is not a solved '
          'neural-task intervention objective. Results do not replace original170, localization/original42 or Cell E07, '
          'and do not establish convergence, an advantage over SNN/Transformer, GPU scaling or multimodal suitability.', '',
          'The paired prepared evaluator retains the complete HX expression and gradients, and its scientific '
          'source remains frozen at `7f86d02273ab665b9789c3058613ca350f9919d7`. The default direct arm remains direct. '
          'No later far-tail fix is included in these runs. Four targeted tests passed, including actual optimizer '
          'updates followed by rejected late validation and rejected late checkpoint copies. A static cross-review '
          'found no late selection or held-out-test leakage. The earlier canonical 112-test suite applies to the '
          'fixed-update source; the prepared evaluator has its separately retained equivalence evidence.', '',
          '`WALL_BUDGET.json` supplies complete per-seed measurements and paired differences. '
          '`wall-budget-originals.tar.gz` retains all 36 original fits, the separate diagnostic, checkpoints, '
          'immutable attempts, logs, exact frozen Python source/config and the archive script. Its internal '
          '`MANIFEST.json` binds every archived file. Verification checked complete identities, source/split '
          'hashes, checkpoint SHA256, eligible deadlines, process return codes and reaped children without rerunning models.', '']
(root/'README.md').write_text('\n'.join(lines))
print(root/'README.md')
