"""One bounded recovery per uncompleted identity; preserve the original batch."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import psutil

repo = Path('/workspace/scratch/d741f7769aeb/worktrees/hx-cell')
root = Path('/workspace/scratch/d741f7769aeb/hx-ablation-20261119')
out = Path('/workspace/scratch/d741f7769aeb/hx-ablation-recovery-20261119')
original = json.loads((root / 'RESULT.json').read_text())
source = json.loads((root / 'SOURCE.json').read_text())

def write(path, value):
    with path.open('x') as target:
        json.dump(value, target, separators=(',', ':'), allow_nan=False)
        target.write('\n')

def check_source():
    actual = {str(p.relative_to(repo / 'qualification/hcsn')): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted((repo / 'qualification/hcsn').rglob('*.py'))}
    if actual != source:
        raise RuntimeError('Original model/benchmark source changed')

check_source()
out.mkdir(exist_ok=False)
missing = [(i, row) for i, row in enumerate(original['rows']) if row['status'] != 'completed']
if any(row['status'] not in {'interrupted', 'not_started'} or
       (row['status'] == 'interrupted' and not row['process']['timed_out']) for _, row in missing):
    raise RuntimeError('Uncertain original execution is not eligible for replay')
write(out / 'PLAN.json', dict(original_result_sha256=hashlib.sha256((root/'RESULT.json').read_bytes()).hexdigest(),
      source=source, identities=[(i, row['task'], row['model'], row['seed']) for i, row in missing],
      per_identity_attempts=1, process_wall_limit_seconds=240,
      original_termination='subprocess.run timeout path kills and waits for its CPU-only direct child; CPU benchmark creates no worker subprocesses',
      controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
started = time.perf_counter()
rows = []
for index, old in missing:
    check_source()
    dest = out / f'{index:03d}-{old["task"]}-{old["model"]}-{old["seed"]}'
    dest.mkdir()
    prior = root / dest.name
    config = dict(original['config'], tasks=[old['task']], models=[old['model']], seeds=[old['seed']])
    if (prior/'CONFIG.json').exists() and json.loads((prior/'CONFIG.json').read_text()) != config:
        raise RuntimeError('Original fit configuration differs')
    write(dest / 'CONFIG.json', config)
    if (prior/'RESULT.runs').exists():
        shutil.copytree(prior/'RESULT.runs', dest/'RESULT.runs')
    command = [sys.executable, '-m', 'qualification.hcsn.benchmark', '--config',
               str(dest/'CONFIG.json'), '--output', str(dest/'RESULT.json')]
    began = time.perf_counter()
    children = {}
    timed_out = False
    with (dest/'stdout.log').open('xb') as stdout, (dest/'stderr.log').open('xb') as stderr:
        process = subprocess.Popen(command, cwd=repo, stdout=stdout, stderr=stderr)
        write(dest/'PROCESS_STARTED.json', dict(pid=process.pid, command=command,
                                                controller_pid=os.getpid(), original_status=old['status']))
        while process.poll() is None:
            try:
                for child in psutil.Process(process.pid).children(recursive=True):
                    children[child.pid] = child.create_time()
            except psutil.NoSuchProcess:
                pass
            if time.perf_counter()-began >= 240:
                timed_out = True
                process.kill()
                break
            try:
                process.wait(timeout=.5)
            except subprocess.TimeoutExpired:
                pass
        code = process.wait()
    for pid, creation in children.items():
        try:
            child = psutil.Process(pid)
            if child.create_time() == creation and child.is_running():
                child.kill()
                child.wait(timeout=10)
        except psutil.NoSuchProcess:
            pass
    row = dict(index=index, task=old['task'], model=old['model'], seed=old['seed'],
               original_status=old['status'], returncode=code, timed_out=timed_out,
               direct_child_reaped=True, observed_child_processes=children,
               wall_seconds=time.perf_counter()-began, result=None)
    if (dest/'RESULT.json').exists():
        result = json.loads((dest/'RESULT.json').read_text())
        if result['source_files_sha256'] != source or len(result['runs']) != 1:
            raise RuntimeError('Recovered result lost source identity')
        row['result'] = result['runs'][0]
        row['report'] = str((dest/'RESULT.json').relative_to(out))
        row['report_sha256'] = hashlib.sha256((dest/'RESULT.json').read_bytes()).hexdigest()
    row['status'] = row['result']['status'] if row['result'] else 'interrupted'
    write(dest/'RECOVERY_PROCESS.json', {k:v for k,v in row.items() if k != 'result'})
    rows.append(row)
    print(index, old['task'], old['model'], old['seed'], row['status'], row['wall_seconds'], flush=True)
    check_source()
write(out/'RESULT.json', dict(original_status=original['status'], original_completed=original['completed'],
      original_wall_seconds=original['wall_seconds'], rows=rows,
      recovery_wall_seconds=time.perf_counter()-started,
      completed_after_recovery=original['completed']+sum(r['status']=='completed' for r in rows),
      repeated_failed_attempts_are_retained=True))
