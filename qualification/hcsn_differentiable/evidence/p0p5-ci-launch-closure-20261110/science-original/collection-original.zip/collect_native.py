"""One authorized read-only gh download; preserve every outcome and exact artifact."""
import time
STARTED = time.monotonic()
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import traceback
from zipfile import ZipFile

BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
OUT = BASE / 'science-ci-artifact-42899977177-v1'
ENDPOINT = 'repos/TrillionniumFoundation/hepta-private-ci/actions/artifacts/13802347858/zip'
EXPECTED_SHA = 'df70358ffc892bfc535fd6d209fbc81b6c70bc20c0f7d295aec6d1df71c03d22'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def identity(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def alarm(*unused):
    raise TimeoutError('whole collection 360 second limit')


def main():
    OUT.mkdir(exist_ok=False)
    signal.signal(signal.SIGALRM, alarm)
    signal.setitimer(signal.ITIMER_REAL, max(.001, 360 - (time.monotonic() - STARTED)))
    target = OUT / 'science-run-42899977177-attempt1-artifact-13802347858.zip'
    record = {'schema': 'science-artifact-readonly-collection-v2', 'status': 'started',
              'source': identity(__file__), 'run_id': '42899977177', 'run_attempt': '1',
              'artifact_id': 13802347858, 'download_attempts': 1, 'automatic_retry': False,
              'endpoint': ENDPOINT, 'expected': {'bytes': 91935, 'sha256': EXPECTED_SHA},
              'started_utc': datetime.now(timezone.utc).isoformat(), 'training_steps': 0,
              'model_reads': 0, 'CI_reruns': 0, 'release_mutations': 0,
              'whole_cap_seconds': 360, 'download_cap_seconds': 240,
              'overall_CI': 'not_assessed_by_this_science_artifact'}
    process, usage = None, None
    env = dict(os.environ)
    env.pop('GH_DEBUG', None)
    save(OUT / 'INTENT.json', record)
    try:
        tick = time.monotonic()
        with target.open('xb') as stdout, (OUT / 'download.stderr').open('xb') as stderr:
            process = subprocess.Popen(['/usr/bin/gh', 'api', ENDPOINT], stdout=stdout, stderr=stderr,
                                       env=env, stdin=subprocess.DEVNULL)
            record['gh_pid'] = process.pid
            while True:
                pid, status, usage = os.wait4(process.pid, os.WNOHANG)
                if pid:
                    process.returncode = os.waitstatus_to_exitcode(status)
                    break
                if time.monotonic() - tick >= 240:
                    process.kill()
                    _, status, usage = os.wait4(process.pid, 0)
                    process.returncode = os.waitstatus_to_exitcode(status)
                    raise TimeoutError('gh download timeout; no retry')
                time.sleep(.05)
        record['download_wall_seconds'] = time.monotonic() - tick
        require(process.returncode == 0, 'gh download nonzero exit')
        require(identity(target) == record['expected'], 'artifact byte identity mismatch')
        with ZipFile(target) as archive:
            names = archive.namelist()
            require(len(names) == len(set(names)) == 14, 'wrong or duplicate members')
            for member in archive.infolist():
                name = member.filename
                require(not Path(name).is_absolute() and '..' not in Path(name).parts and '\\' not in name,
                        'unsafe ZIP path')
                require(((member.external_attr >> 16) & 0o170000) != 0o120000, 'ZIP symlink')
            require(archive.testzip() is None, 'ZIP CRC failure')
            members = {name: {'bytes': len(archive.read(name)),
                             'sha256': hashlib.sha256(archive.read(name)).hexdigest()} for name in names}
            original_identity = json.loads(archive.read('identity.json'))
            require(original_identity['run_id'] == '42899977177' and original_identity['run_attempt'] == '1', 'run differs')
            require(original_identity['source_head'] == '652263b31ebebc4e85b5b2986cb144f0127cbad2'
                    and original_identity['source_tree'] == original_identity['tested_tree']
                    == 'aa5cc6bc55b0dc1cb68adf62886fb9646962de03'
                    and original_identity['trees_equal'] is True, 'actual artifact source/tree differs')
            integrity = json.loads(archive.read('evidence-integrity.json'))
            save(OUT / 'ACTUAL-IDENTITY.json', original_identity)
            save(OUT / 'ARTIFACT-MEMBERS.json', members)
            save(OUT / 'ACTUAL-INTEGRITY.json', integrity)
        encoded = base64.b64encode(target.read_bytes()).decode()
        parts = []
        for index, offset in enumerate(range(0, len(encoded), 45000)):
            path = OUT / f'artifact-base64-{index:02d}.txt'
            with path.open('x') as stream:
                stream.write(encoded[offset:offset+45000])
            parts.append({'path': str(path), **identity(path)})
        save(OUT / 'TEXT-TRANSPORT.json', {'archive': identity(target), 'encoding': 'base64', 'parts': parts})
        record.update(status='exact_artifact_verified', artifact=identity(target), members=14,
                      source_and_tested_identity=original_identity, CRC_and_paths_passed=True)
    except Exception:
        record.update(status='failed_preserved_no_retry', error=traceback.format_exc())
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        if process is not None and process.returncode is None:
            try:
                process.kill()
                _, status, usage = os.wait4(process.pid, 0)
                process.returncode = os.waitstatus_to_exitcode(status)
            except Exception:
                record['cleanup_error'] = traceback.format_exc()
        if process is not None:
            record['returncode'] = process.returncode
        if usage is not None:
            record.update(whole_gh_CPU_seconds=usage.ru_utime+usage.ru_stime,
                          gh_peak_rss_bytes=usage.ru_maxrss*1024)
        record.update(whole_script_wall_seconds=time.monotonic()-STARTED,
                      own_full_process_CPU_seconds=time.process_time(),
                      own_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
                      finished_utc=datetime.now(timezone.utc).isoformat(), energy_joules=None,
                      timing_scope='script wall includes gh, parse/hash/transport encoding; gh CPU is a disjoint child; hosted job CPU/billing unknown')
        record['retained_artifact'] = identity(target) if target.exists() else None
        save(OUT / 'RESULT.json', record)
        print(json.dumps({'status': record['status'], 'result': identity(OUT/'RESULT.json')}), flush=True)
    return 0 if record['status'] == 'exact_artifact_verified' else 2


if __name__ == '__main__':
    raise SystemExit(main())
