"""Recover the single native download without further network access or CI execution."""
import base64
import hashlib
import json
from pathlib import Path
import resource
import time
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent
START = time.monotonic()


def ident(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n')


def main():
    metadata = json.loads((ROOT/'METADATA-READBACK.json').read_bytes())
    body = json.loads(next(v['text'] for v in metadata['content'] if v['type']=='text'))
    originals = ROOT/'originals'
    originals.mkdir(exist_ok=False)
    for entry in body['files']:
        raw = entry['text'].encode()
        assert ident(raw) == {'bytes':entry['size'], 'sha256':entry['sha256']}
        (originals/Path(entry['path']).name).write_bytes(raw)
    transport = json.loads((originals/'TEXT-TRANSPORT.json').read_bytes())
    joined = b''
    for entry in transport['parts']:
        # apply_patch's text transport adds one final newline; this is not part
        # of the native encoded file. Hash exact bytes after removing that one.
        raw = (ROOT/Path(entry['path']).name).read_bytes()
        if len(raw) == entry['bytes']+1 and raw.endswith(b'\n'):
            raw = raw[:-1]
        assert ident(raw) == {'bytes':entry['bytes'], 'sha256':entry['sha256']}
        joined += raw
    raw = base64.b64decode(joined, validate=True)
    assert ident(raw) == transport['archive']
    archive = originals/'science-run-42899977177-attempt1-artifact-13802347858.zip'
    archive.write_bytes(raw)
    (originals/'download.stderr').write_bytes(b'')
    with ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 14
        members = json.loads((originals/'ARTIFACT-MEMBERS.json').read_bytes())
        assert all(ident(z.read(name)) == item for name,item in members.items())
        identity = json.loads(z.read('identity.json'))
        integrity = json.loads(z.read('evidence-integrity.json'))
        outcome = json.loads(z.read('outcome.json'))
        (originals/'evidence-integrity.json').write_bytes(z.read('evidence-integrity.json'))
        (originals/'identity.json').write_bytes(z.read('identity.json'))
        (originals/'outcome.json').write_bytes(z.read('outcome.json'))
        timers = {}
        for name in ('qualification.json','error-budget.json','qvi-oracle.json'):
            value=json.loads(z.read(name))
            timers[name] = {k:v for k,v in value.items() if any(s in k.lower() for s in ('wall','cpu','seconds','elapsed','time'))}
        for name in ('qualification.log','memory-controls-tests.log','qvi-tests.log'):
            lines=z.read(name).decode().splitlines()
            timers[name] = [line for line in lines if 'Ran ' in line or ' in ' in line and 'OK' in line]
    report = {'schema':'science-artifact-independent-cloud-byte-verification-v1','status':'passed_exact_bytes',
              'artifact':ident(raw),'members':members,'actual_source_identity':identity,'actual_outcome':outcome,
              'integrity_summary':{k:v for k,v in integrity.items() if k not in ('files','zips','links','inputs')},
              'hosted_fixture_timers':timers,'hosted_job_CPU_seconds':None,'hosted_billing':None,
              'hosted_timer_scope':'retained inner fixture timers overlap hosted job; not download costs or complete job CPU',
              'workflow_rerun':False,'model_reads':0,'download_attempts':1,'overall_CI':'not_established',
              'cloud_recovery_wall_seconds':time.monotonic()-START,'cloud_recovery_CPU_seconds':time.process_time()}
    save(ROOT/'VERIFICATION.json',report)
    included=['PLAN.json','collect_native.py','recover_and_seal.py','NATIVE-ACK.json','PTY-READBACK.json',
              'METADATA-READBACK.json','BINARY-READBACK.json','VERIFICATION.json']
    selected=[ROOT/n for n in included]+sorted(p for p in originals.iterdir() if p.is_file())
    manifest={str(p.relative_to(ROOT)):ident(p.read_bytes()) for p in selected}
    save(ROOT/'MANIFEST.json',{'files':manifest})
    save(ROOT/'COPY_LIST.json',{'root':str(ROOT),'files':list(manifest)+['MANIFEST.json'],
                               'scope':'frozen collection source, original bytes, tool receipts and independent verification; no mutable work files'})
    zipped=ROOT.with_suffix('.zip')
    with ZipFile(zipped,'x',compression=ZIP_DEFLATED) as z:
        for p in selected+[ROOT/'MANIFEST.json',ROOT/'COPY_LIST.json']:
            z.write(p,str(p.relative_to(ROOT)))
    print(json.dumps({'archive':str(zipped),**ident(zipped.read_bytes()),'verification':ident((ROOT/'VERIFICATION.json').read_bytes()),
                      'identity':identity,'outcome':outcome,'integrity_keys':list(integrity)}))


if __name__=='__main__':
    main()
