"""Archive stable first C2 terminal metadata only; no model/trace arrays."""
import time

STARTED = time.monotonic()

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import zipfile

BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
RUN = BASE / 'c2-native-execution-20261110-c385-v1'
NAME = 'hcsn-s211-lr0.003'
FIT = RUN / 'fits' / NAME
OUT = BASE / 'c2-first-terminal-metadata-archive-20261110-c385-v1'
RESULT_SHA = 'c5c3f1f75a305fff6d97fdfd263ca8aac0c765698ba94c1debc17b01978b889d'


def identity(path):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise ValueError('nonregular metadata file')
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    OUT.mkdir(exist_ok=False)
    result_path = FIT / 'result.json'
    if identity(result_path) != {'bytes': 360283, 'sha256': RESULT_SHA}:
        raise ValueError('original terminal result differs from prior read-only file identity')
    result = json.loads(result_path.read_bytes())
    outer_path = RUN / 'attempts' / NAME / 'RESULT.json'
    outer = json.loads(outer_path.read_bytes())
    if (outer.get('process_started') is not True or outer.get('child_terminal_unknown') is not False
            or type(outer.get('returncode')) is not int or outer.get('result') != identity(result_path)
            or outer.get('fit_status') != result['status']):
        raise ValueError('no byte-bound completed child outer record')
    pid = outer['pid']
    proc = Path('/proc') / str(pid) / 'cmdline'
    if proc.exists() and b'c2_runner.py' in proc.read_bytes() and NAME.encode() in proc.read_bytes():
        raise ValueError('original fit process still live')
    members = {}
    for leaf in ('result.json', 'events.jsonl', 'ADMISSION.json', 'RESUME-START.json'):
        members['fit/' + leaf] = FIT / leaf
    for path in sorted((FIT / 'commits').glob('*.json')):
        members['fit/' + str(path.relative_to(FIT))] = path
    for folder, leaves in (('posterior-windows', ('RESULT.json',)), ('optimization-windows', ('CAPTURE.json', 'STEP-COMPLETED.json'))):
        for leaf in leaves:
            for path in sorted((FIT / folder).glob('*/' + leaf)):
                members['fit/' + str(path.relative_to(FIT))] = path
    for leaf in ('RESULT.json', 'stdout', 'stderr'):
        members['outer/' + leaf] = RUN / 'attempts' / NAME / leaf
    members['parent/outer-record.json'] = RUN / 'parent-records' / (NAME + '.json')
    for leaf in ('plan.json', 'result.json'):
        members['parent/' + leaf] = BASE / 'campaign-v2' / NAME / leaf
    program = BASE / 'c2-execution-source-v4-20261110-c385'
    for leaf in ('PROGRAM-MANIFEST.json', 'CONTRACT.json', 'POSTERIOR-POLICY.json', 'OPTIMIZATION-POSTERIOR-POLICY-v2.json'):
        members['source-identities/' + leaf] = program / leaf
    members['source-identities/DECISION.json'] = BASE / 'c2-execution-decision-v1-20261110-c385.json'
    members['archive-program.py'] = Path(__file__)
    before = {name: identity(path) for name, path in sorted(members.items())}
    if sum(item['bytes'] for item in before.values()) > 16 * 1024**2:
        raise ValueError('metadata-only byte bound exceeded')
    archive = OUT / 'hcsn-c2-first-terminal-metadata-20261110-v1.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, path in sorted(members.items()):
            zipped.write(path, name)
        zipped.writestr('MEMBER-MANIFEST.json', json.dumps(before, sort_keys=True, indent=2) + '\n')
    with zipfile.ZipFile(archive) as zipped:
        if zipped.testzip() is not None:
            raise ValueError('archive CRC failure')
        for name, expected in before.items():
            raw = zipped.read(name)
            if len(raw) != expected['bytes'] or hashlib.sha256(raw).hexdigest() != expected['sha256']:
                raise ValueError('metadata archive member changed')
    if any(identity(path) != before[name] for name, path in members.items()):
        raise ValueError('selected metadata changed during read-only archive')
    report = {'schema': 'hcsn-c2-single-terminal-metadata-archive-v1',
        'status': 'completed_readonly_metadata_archive', 'completed_utc': datetime.now(timezone.utc).isoformat(),
        'candidate': NAME, 'archive': {'path': str(archive), **identity(archive)},
        'members': len(members) + 1, 'selected_metadata_unchanged': True,
        'model_or_probability_arrays_read': False, 'original_directories_written': False,
        'fit_result': identity(result_path), 'outer_result': identity(outer_path),
        'producer': {key: result.get(key) for key in ('status', 'stop_reason', 'training_adequacy_established',
            'parent_retained_epochs', 'cumulative_epochs_completed', 'new_main_updates', 'new_unretained_logged_updates',
            'best_epoch', 'best_checkpoint_sha256', 'last_checkpoint_sha256', 'selected_development',
            'source_and_parent_inputs_unchanged', 'common_and_physical_weights_unchanged')},
        'whole_attempt_outer_wall_seconds': outer['whole_process_wall_seconds'],
        'exact_child_wait4_cpu_seconds': outer['child_cpu_seconds'], 'child_peak_rss_bytes': outer['child_peak_rss_bytes'],
        'training_returncode': outer['returncode'],
        'interpretation': 'Observed producer result only. Independent C2 terminal/recording/full-D audit pending; no early LR/seed selection, no E access, remaining candidates unchanged.',
        'scientific_admission': 'HOLD', 'numerical_admission': 'HOLD',
        'archive_wall_seconds': time.monotonic() - STARTED, 'archive_full_cpu_prefix_seconds': time.process_time(),
        'archive_peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024}
    write(OUT / 'RESULT.json', report)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
