"""Streaming recorded-visit provenance, separate actual steps and no-grad captures."""
import hashlib
import json
import math
from pathlib import Path

from audit_io import require
from bound_io import identity, safe_child
from checks import expected_capture, finite


def trace(path, item, expected, sources, policy_sha, data_sha, max_bytes, inputs):
    path = inputs.bind(path, item)
    require(path.stat().st_size <= max_bytes, 'trace exceeds fixed byte ceiling')
    seen, samples, footer, header = 0, 0, None, None
    prefix = hashlib.sha256()
    with path.open('rb') as stream:
        for raw in stream:
            inputs.budget()
            row = json.loads(raw)
            if header is None:
                require(row['kind'] == 'header' and row['schema'] == 'hcsn-training-domain-v1' and row['data_sha256'] == data_sha
                        and row['configuration_sha256'] == policy_sha and row['sources'] == sources
                        and row['max_bytes'] == max_bytes and row['max_records'] == 256,
                        'trace header source/data/cap identity')
                header = row
                prefix.update(raw)
            elif row['kind'] == 'end':
                require(footer is None, 'duplicate trace footer')
                require(row['prefix_sha256'] == prefix.hexdigest(), 'trace prefix digest differs')
                footer = row
            else:
                require(footer is None and row['kind'] == 'visit', 'visit outside trace body')
                require(seen < len(expected['expected_positions']), 'unexpected extra position')
                indices = expected['expected_batch_indices_by_position'][seen]
                require(row['index'] == seen and row['capture'] == 0 and row['layer'] == 0
                        and row['position'] == expected['expected_positions'][seen], 'visit slot/layer/position')
                require(row['batch_indices'] == indices and row['dt'] == expected['expected_dt_by_position'][seen],
                        'visit actual batch indices/dt differs')
                require(row['episode_id'] == '+'.join(expected['microbatch_episode_ids'])
                        and row['update_index'] == expected['logical_completed_updates_before_step']
                        and row['model_sha256'] == expected['network_model_sha256'], 'visit model/update/episode')
                for key in ('grid', 'operator', 'parameters'):
                    if key in expected:
                        require(row[key] == expected[key], 'visit '+key+' differs')
                require(len(row['prior']) == len(row['posterior']) == len(row['expected_events']) == len(indices),
                        'visit sample coverage')
                for probability in row['prior'] + row['posterior']:
                    require(len(probability) == expected['probability_state_count']
                            and all(finite(p) and p >= 0 for p in probability)
                            and abs(sum(probability)-1) <= 1e-10, 'probability consistency diagnostic')
                require(all(finite(v) and v >= 0 for v in row['expected_events']), 'invalid event readout')
                seen += 1
                samples += len(indices)
                prefix.update(raw)
    require(footer is not None and footer['captures'] == 1 and footer['seen_records'] == seen
            and footer['retained_records'] == seen == len(expected['expected_positions'])
            and footer['dropped_records'] == 0 and footer['truncated'] is False and footer['drop_reason'] is None,
            'trace incomplete/dropped records')
    require(footer['source_unchanged'] is True and footer['sources_after'] == sources
            and footer['padded_states_excluded'] == expected['expected_padded_sample_states']
            and samples == expected['expected_valid_sample_states'], 'trace footer source/sample coverage')
    require(identity(path) == item, 'trace changed while streaming')
    return {'time_rows': seen, 'valid_sample_states': samples, 'excluded_padding': footer['padded_states_excluded'],
            'footer': footer, 'trace': item, 'normalization_scope': 'internal consistency only; no continuum accuracy claim'}


def audit_optimization(root, report, journal, episodes, states, source_map, trace_sources, policy, policy_item, inputs):
    root = Path(root)
    first = report['parent_retained_epochs'] + 1
    scheduled = sorted({first, *policy['absolute_epoch_slots']})
    rows, physical_paths = [], set()
    for epoch in scheduled:
        labels = (['resume-first-main-microbatch'] if epoch == first else [])
        if epoch in policy['absolute_epoch_slots']:
            labels.append(f'epoch-{epoch:04d}-first-main-microbatch')
        if epoch not in journal['started_epochs']:
            rows.append({'epoch': epoch, 'labels': labels, 'status': 'not_reached'})
            continue
        directory = root/'optimization-windows'/f'epoch-{epoch:04d}-first-main-microbatch'
        capture_path = directory/'CAPTURE.json'
        if not capture_path.is_file():
            rows.append({'epoch': epoch, 'labels': labels, 'status': 'missing_actual_capture', 'recording_integrity': 'HOLD'})
            continue
        capture = inputs.json(capture_path)
        predecessor = states[epoch-1]
        expected = expected_capture(episodes, journal['started_epochs'][epoch]['order'],
                                    predecessor['main_updates'], predecessor['grid_states'])
        expected.update(network_model_sha256=predecessor['network_sha256'], **predecessor['visit_configuration'])
        require(all(capture.get(k) == v for k, v in expected.items() if k not in ('grid', 'operator', 'parameters')),
                'recorded expectation differs from independent data/order/checkpoint reconstruction')
        require(capture['labels'] == labels and capture['epoch'] == epoch and capture['effective_batch_index'] == 0
                and capture['capture_grad_enabled'] is True and capture['status'] == 'captured_actual_gradient_microbatch'
                and capture['optimizer_step_completed'] is False, 'CAPTURE must precede its actual step')
        require(capture['checkpoint'] == predecessor['identity'] and capture['checkpoint_path'] == predecessor['path']
                and capture['model_semantic_sha256'] == predecessor['model_semantic_sha256']
                and capture['model_configuration'] == report['model_configuration']
                and capture['source_before'] == source_map and capture['trace_source_hashes'] == trace_sources
                and capture['policy'] == policy_item, 'capture checkpoint/source binding')
        expected_actual = report['parent_work']['total_logged_main_optimizer_completions'] + (
            predecessor['main_updates']-report['retained_main_updates_at_resume'])
        require(capture['actual_logged_main_updates_before_step'] == expected_actual, 'parent partial work omitted')
        path = safe_child(directory, capture['path'])
        require(str(path) not in physical_paths, 'duplicate physical optimization capture')
        physical_paths.add(str(path))
        result = trace(path, capture['trace'], expected, trace_sources, policy_item['sha256'],
                       report['model_data_manifest_sha256'], policy['maximum_bytes_per_slot'], inputs)
        require(result['footer'] == capture['footer'], 'capture footer differs from actual trace')
        logical_next = predecessor['main_updates'] + 1
        completion = journal['completions'].get(logical_next)
        step_path = directory/'STEP-COMPLETED.json'
        if completion is not None:
            step = inputs.json(step_path)
            require(step['capture'] == identity(capture_path) and step['slot'] == capture['slot']
                    and step['logical_step'] == logical_next and step['new_step'] == completion['new']
                    and step['optimizer_step_completed'] is True, 'step completion linkage')
            state = 'captured_and_step_completed'
        else:
            require(not step_path.exists(), 'completion artifact without actual completed step')
            state = 'captured_before_uncompleted_step'
        rows.append({'epoch': epoch, 'labels': labels, 'status': state, 'CAPTURE': identity(capture_path), **result})
    return {'slots': rows, 'unique_physical_captures': len(physical_paths),
            'valid_sample_states': sum(r.get('valid_sample_states', 0) for r in rows),
            'whole_training_domain': 'HOLD', 'live_independent_observation': False,
            'ordering_scope': 'byte-bound witness, step journal and frozen writer sequence; not independent live observation',
            'passed_recording_integrity': not any(r.get('recording_integrity') == 'HOLD' for r in rows)}


def audit_supplement(root, report, episodes, states_by_path, source_map, trace_sources, policy, policy_item, inputs):
    by_id = {r['id']: r for r in episodes}
    scheduled = ['resume-start'] + [f'epoch-{e:04d}' for e in policy['absolute_complete_epoch_slots']] + ['terminal-last', 'terminal-best']
    summary = {r['slot']: r for r in report['posterior_recording']['slots']}
    require(set(summary) == set(scheduled), 'supplement fixed roster differs')
    results = []
    for slot in scheduled:
        row = summary[slot]
        epoch = int(slot[6:]) if slot.startswith('epoch-') else None
        if epoch is not None and epoch > report['cumulative_epochs_completed']:
            require(row['status'] == 'not_reached', 'unreached supplement status differs')
            results.append({'slot': slot, 'status': 'not_reached'})
            continue
        path = Path(root)/'posterior-windows'/slot/'RESULT.json'
        if row['status'] != 'captured_complete_window':
            results.append({'slot': slot, 'status': row['status'], 'recording_integrity': 'HOLD'})
            if path.exists():
                inputs.bind(path)
            continue
        receipt = inputs.json(path, row['receipt'])
        require({k: v for k, v in row.items() if k != 'receipt'} == receipt, 'supplement report/receipt differs')
        state = states_by_path.get(receipt['checkpoint_path'])
        require(state is not None and receipt['checkpoint'] == state['identity']
                and receipt['model_semantic_sha256'] == state['model_semantic_sha256']
                and receipt['epoch'] == state['epoch'] and receipt['logical_main_updates'] == state['main_updates'],
                'supplement checkpoint binding')
        require(receipt['status'] == 'captured_complete_window' and all(receipt['neutrality'].values())
                and receipt['source_unchanged'] is True and receipt['source_before'] == receipt['source_after'] == source_map
                and receipt['policy'] == policy_item and receipt['optimizer_steps'] == 0
                and receipt['configuration'] == report['model_configuration']
                and receipt['data_manifest_sha256'] == report['model_data_manifest_sha256'],
                'supplement source/neutrality evidence differs')
        require(finite(receipt['wall_seconds']) and receipt['wall_seconds'] >= 0, 'supplement clock')
        require(len(receipt['episodes']) == 3, 'supplement whole three-episode slot incomplete')
        counts = []
        for entry, original in zip(receipt['episodes'], policy['episodes']):
            require(entry['episode'] == original, 'supplement episode order differs')
            episode = by_id[original['id']]
            n = len(episode['y'])
            expected = {'microbatch_episode_ids': [original['id']], 'expected_positions': list(range(n)),
                        'expected_batch_indices_by_position': [[0] for _ in range(n)],
                        'expected_dt_by_position': [[dt] for dt in episode['dt']],
                        'logical_completed_updates_before_step': state['main_updates'],
                        'expected_valid_sample_states': n, 'expected_padded_sample_states': 0,
                        'probability_state_count': state['grid_states'], 'network_model_sha256': state['network_sha256'],
                        **state['visit_configuration']}
            count = trace(path.parent/(original['id']+'.jsonl'), entry['trace'], expected, trace_sources,
                          policy_item['sha256'], report['model_data_manifest_sha256'],
                          policy['maximum_bytes_per_episode'], inputs)
            require(count['footer'] == entry['footer'], 'supplement footer differs')
            counts.append(count)
        results.append({'slot': slot, 'status': 'bound_separate_no_grad_capture', 'episodes': counts,
                        'reported_neutrality_only': True, 'whole_slot_wall_seconds': receipt['wall_seconds'],
                        'soft120s_scope': 'three episode loop; reported cleanup/write may exceed soft check',
                        'separate_from_optimizer_visits': True})
    return {'slots': results, 'passed_recording_integrity': not any(r.get('recording_integrity') == 'HOLD' for r in results),
            'whole_training_domain': 'HOLD', 'scope': 'no-grad checkpoint replay; never optimizer-time coverage'}
