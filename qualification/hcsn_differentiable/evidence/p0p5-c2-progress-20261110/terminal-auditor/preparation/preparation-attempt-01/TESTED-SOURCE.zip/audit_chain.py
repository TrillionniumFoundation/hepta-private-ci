"""One independent recovery/commit/recording audit. Never calls producer admission."""
from dataclasses import asdict
import importlib.metadata
import json
import math
from pathlib import Path
import platform
import sys
import traceback

from audit_io import construction, require, save
from bound_io import Inputs, PROGRAM, identity, safe_child
from checkpoint_checks import equal, model_and_groups, semantic_digest, validate_state, validate_witness
from checks import matrix_metrics, reconstruct_journal, stopping, verify_commit
from trace_checks import audit_optimization, audit_supplement


def runtime_identity():
    value = {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
             'resolved_executable_sha256': identity(Path(sys.executable).resolve())['sha256'], 'packages': {}}
    for name in ('torch', 'numpy', 'mpmath', 'ncps', 'spikingjelly', 'einops', 'torchvision'):
        try:
            distribution = importlib.metadata.distribution(name)
        except importlib.metadata.PackageNotFoundError:
            value['packages'][name] = {'installed': False}
            continue
        record = distribution.read_text('RECORD')
        import hashlib
        value['packages'][name] = {'version': distribution.version,
                                  'record_sha256': hashlib.sha256(record.encode()).hexdigest() if record else None}
    return value


def load_rows(context, inputs, partition='train'):
    prepared = Path(context['prepared'])
    rows = []
    for entry in context['data_manifest']['episodes']:
        if entry['partition'] != partition:
            continue
        require(entry['id'][0] in ('ABC' if partition == 'train' else 'D'), 'split differs')
        row = inputs.json(safe_child(prepared, prepared/entry['path']), entry['sha256'])
        n = entry['events']
        require(row['id'] == entry['id'] and row['partition'] == partition
                and all(len(row[k]) == n for k in ('x', 'dt', 'y', 'source_rows', 'delta_ticks')), 'episode identity/geometry')
        require(row['dt'] == [v/10000000 for v in row['delta_ticks']]
                and all(type(y) is int and 0 <= y < 11 for y in row['y']), 'episode labels/time differs')
        rows.append(row)
    require(len({r['id'] for r in rows}) == len(rows), 'episode duplicates')
    return rows


def run(context_path, context_sha, name, output, budget):
    import torch
    inputs = Inputs(budget)
    context = inputs.json(context_path, context_sha)
    require(context['status'] == 'passed_terminal_context', 'unbound context')
    for path, item in context['inputs'].items():
        inputs.bind(path, item)
    require(runtime_identity() == context['runtime'], 'native runtime differs')
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    root = Path(context['controller'])/'fits'/name
    parent = Path(context['original_campaign'])/name
    outer, parent_outer = context['attempts'][name], context['parents'][name]
    require(outer['process_started'] is True and outer.get('terminal_evidence_complete') is True, 'terminal model report unavailable')
    report = inputs.json(root/'result.json', outer['result'])
    prior = inputs.json(parent/'result.json', parent_outer['result_sha256'])
    fit_plan = inputs.json(parent/'plan.json', prior['plan_sha256'])
    require(name == f"hcsn-s{fit_plan['seed']}-lr{fit_plan['learning_rate']:g}", 'candidate identity')
    require(report['schema'] == 'hcsn-c2-soft-wall-continuation-v1' and report['production_execution'] is True
            and report['arm'] == 'hcsn' and report['seed'] == fit_plan['seed']
            and report['learning_rate'] == fit_plan['learning_rate'] and report['confirmation_access'] is False,
            'terminal report identity/scope')
    require(report['parent_outer'] == parent_outer and report['parent_report'] == identity(parent/'result.json')
            and report['parent'] == str(parent) and report['parent_full_outer_wall_charged'] == parent_outer['whole_process_wall_seconds']
            and report['refund_for_discarded_parent_work_seconds'] == 0, 'parent linkage/refund')
    require(report['fresh_independent_fits_started'] == 0 and report['continuation_attempts_started'] == 1
            and report['new_diagnostic_updates'] == 0 and report['inherited_memorization'] == prior['memorization'], 'repeated/new diagnostic')
    require(report['source_before'] == report['source_after'] == prior['source_before'] == prior['source_after']
            and report['source_and_parent_inputs_unchanged'] is True
            and report['common_and_physical_weights_unchanged'] is True, 'terminal input/shared integrity')
    for path, digest in prior['source_before'].items():
        inputs.bind(path, digest)
    require(torch.__version__ == prior['torch_version'] and torch.version.git_version == prior['torch_git_version'], 'Torch build differs')
    require(fit_plan['batch_size'] == 32 and fit_plan['micro_batch_size'] == 8 and fit_plan['threads'] == 1
            and fit_plan['min_epochs'] == 30 and fit_plan['patience'] == 10 and fit_plan['plateau_delta'] == .002,
            'frozen training regime differs')
    episodes = load_rows(context, inputs)
    require(len(episodes) == 356 and sum(len(r['y']) for r in episodes) == prior['train_events'], 'training population')
    def load(path, expected):
        path = inputs.bind(path, expected)
        state = torch.load(path, weights_only=True, mmap=True, map_location='cpu')
        require(identity(path) == inputs.files[str(path)], 'checkpoint changed while loading')
        budget()
        return state
    initial = load(parent/'initial.pt', prior['initialization_sha256'])
    parent_last = load(parent/'last.pt', prior['last_checkpoint_sha256'])
    parent_best = load(parent/'best.pt', prior['best_checkpoint_sha256'])
    events0 = inputs.lines(parent/'events.jsonl', prior['events_sha256'])
    j0 = reconstruct_journal(events0, episodes, fit_plan['seed'], 32, 8)
    retained = parent_last['epochs_completed']
    require(len(j0['completed']) == retained == len(prior['epochs']) and j0['logged_new_updates'] == prior['main_updates'],
            'parent complete anchor/partial work differs')
    require([{k: v for k, v in r.items() if k != 'kind'} for r in j0['completed']] == prior['epochs'], 'parent epoch journal differs')
    parent_stop, old_plateau = stopping(prior['epochs'])
    require(old_plateau is None and parent_stop['best_epoch'] == parent_best['epochs_completed'] == prior['best_epoch'],
            'invalid parent strict best/plateau')
    require(report['parent_retained_epochs'] == retained and report['retained_main_updates_at_resume'] == retained*12,
            'resume boundary differs')
    work = {'retained_main_updates': retained*12, 'completed_updates_after_anchor': prior['main_updates']-retained*12,
            'complete_epochs_after_anchor': 0, 'optimizer_step_in_flight': j0['unclosed_optimizer_call'],
            'unclosed_forward_or_backward': j0['unclosed_forward_backward'],
            'inflight_optimizer_updates_unknown_interval': j0['possibly_unlogged_optimizer_updates'],
            'steps_per_epoch': 12, 'total_logged_main_optimizer_completions': prior['main_updates']}
    require(report['parent_work'] == work, 'partial parent work omitted or relabelled')
    model, groups, frozen = model_and_groups(context, fit_plan, initial, prior['source_before'])
    cfg = construction(fit_plan)
    require(report['model_configuration'] == cfg, 'report construction')
    layer = model.core.network.layers[0]
    physics = layer.physics()
    visit_cfg = {'grid': asdict(layer.grid), 'operator': layer.operator.configuration(),
                 'parameters': {n: float(v.detach()) for n, v in zip(
                     ('log_boundary', 'mu', 'sigma', 'absolute_reset', 'discount'), physics.tensors())}}
    def validate(payload, path, epoch, order):
        value = validate_state(payload, initial, groups, frozen, cfg, epoch, epoch*12,
                               fit_plan['manifest_sha256'], order, parent_last['torch_rng'])
        return dict(value, identity=identity(path), path=str(path), grid_states=layer.grid.state_count,
                    visit_configuration=visit_cfg)
    states = {retained: validate(parent_last, parent/'last.pt', retained, j0['boundary_rng'][retained])}
    best_epoch = parent_best['epochs_completed']
    best_info = validate(parent_best, parent/'best.pt', best_epoch, j0['boundary_rng'][best_epoch])
    restored = load(root/'resume-start.pt', report['resume_start_checkpoint'])
    witness = inputs.json(root/'RESUME-START.json', report['resume_start_receipt'])
    validate_witness(parent_last, restored, witness, identity(parent/'last.pt'), identity(root/'resume-start.pt'),
                     parent_outer['whole_process_wall_seconds'], prior['source_before'], work)
    states[retained] = dict(states[retained], identity=identity(root/'resume-start.pt'), path=str(root/'resume-start.pt'))
    inputs.bind(root/'inherited-best.pt', identity(parent/'best.pt'))
    best_info = dict(best_info, identity=identity(root/'inherited-best.pt'), path=str(root/'inherited-best.pt'))
    by_path = {states[retained]['path']: states[retained], best_info['path']: best_info}
    del restored, parent_best
    events = inputs.lines(root/'events.jsonl', report['events'])
    require(events[-1]['status'] == report['status'], 'terminal event/report status differs')
    j = reconstruct_journal(events, episodes, fit_plan['seed'], 32, 8, parent_epoch=retained,
                            parent_updates=retained*12, order_state=parent_last['order_rng'], phase=True)
    resume_events = [r for r in events if r['kind'] == 'resume_start_committed']
    require(len(resume_events) == 1 and resume_events[0]['receipt'] == report['resume_start_receipt']
            and resume_events[0]['checkpoint'] == report['resume_start_checkpoint'], 'witness/journal mismatch')
    require(report['new_main_updates'] == j['logged_new_updates'] and report['logical_main_updates'] == j['logical_updates']
            and report['actual_executed_main_updates_logged_all_phases'] == prior['main_updates']+j['logged_new_updates'],
            'actual/logical update accounting')
    require(len(report['epochs']) == len(j['completed']), 'complete epoch report/journal count')
    history, previous = list(prior['epochs']), None
    commit_paths, checkpoint_paths = set(), set()
    for row, event in zip(report['epochs'], j['completed']):
        budget()
        require(row == {k: v for k, v in event.items() if k not in ('kind', 'commit')}, 'complete epoch record differs')
        n = row['epoch']
        require(n <= 200 and row['cumulative_process_wall_seconds']
                == parent_outer['whole_process_wall_seconds']+row['phase_process_wall_seconds'], 'cumulative clock/epoch ceiling')
        path, cp = root/'commits'/f'epoch-{n:04d}.json', root/'checkpoints'/f'epoch-{n:04d}.pt'
        commit = inputs.json(path)
        require(event['commit'] == {'path': str(path), **identity(path)}, 'epoch event commit identity')
        payload = load(cp, commit['checkpoint'])
        info = validate(payload, cp, n, j['boundary_rng'][n])
        states[n], by_path[str(cp)] = info, info
        history.append(row)
        state, _ = stopping(history)
        if state['best_epoch'] == n:
            best_info = info
        verify_commit(commit, row, info['identity'], cp, best_info['identity'], best_info['path'], previous, history, 12)
        previous = {'path': str(path), **identity(path)}
        commit_paths.add(str(path)); checkpoint_paths.add(str(cp))
        del payload
    stop, first_plateau = stopping(history)
    final_epoch = len(history)
    require(report['stopping'] == stop and report['last_commit'] == previous
            and report['cumulative_epochs_completed'] == final_epoch and report['best_epoch'] == stop['best_epoch'],
            'terminal best/stopping/commit mismatch')
    require(first_plateau is None or first_plateau == final_epoch, 'continued after plateau')
    require(report['new_unretained_logged_updates'] == report['logical_main_updates']-final_epoch*12, 'new partial work missing')
    require(report['cumulative_active_wall_cap_seconds'] == 43200 and report['maximum_cumulative_epochs'] == 200, 'terminal cap differs')
    inputs.bind(root/'last.pt', states[final_epoch]['identity'])
    inputs.bind(root/'best.pt', best_info['identity'])
    require(report['last_checkpoint_sha256'] == states[final_epoch]['identity']['sha256']
            and report['best_checkpoint_sha256'] == best_info['identity']['sha256'], 'terminal aliases')
    adequate = report['status'] == 'completed_development' and report.get('stop_reason') == 'development_plateau' and prior['memorization']['passed']
    require(report['training_adequacy_established'] is adequate, 'adequacy status differs')
    if adequate:
        require(first_plateau == final_epoch, 'claimed plateau not found')
    if report['status'] == 'completed_development':
        require(outer['returncode'] == 0 and report.get('stop_reason') in ('development_plateau', 'epoch_cap_not_convergence'), 'success terminal code/reason')
        require(report['logical_main_updates'] == final_epoch*12 and not j['unclosed_optimizer_call']
                and not j['unclosed_forward_backward'], 'successful fit has partial work')
    elif outer['returncode'] == 0:
        raise ValueError('zero exit without complete fit report')
    dangling = [str(p) for folder, admitted in [('checkpoints', checkpoint_paths), ('commits', commit_paths)]
                for p in sorted((root/folder).glob('*')) if p.is_file() and str(p) not in admitted]
    for path in dangling:
        inputs.bind(path)
    if 'interrupted_checkpoint' in report:
        interrupted = load(root/'interrupted.pt', report['interrupted_checkpoint'])
        validate_state(interrupted, initial, groups, frozen, cfg, final_epoch, report['logical_main_updates'],
                       fit_plan['manifest_sha256'], j['final_order_rng'], parent_last['torch_rng'])
        del interrupted
    source_names = ('contract.py', 'operator.py', 'network.py', 'encoder.py', 'value.py',
                    'regenerative.py', 'training_domain.py', 'training_domain_audit.py')
    trace_sources = {n: prior['source_before'][str(Path(context['source'])/'qualification/hcsn_differentiable'/n)] for n in source_names}
    result = {'schema': 'independent-c2-chain-v1', 'name': name, 'seed': fit_plan['seed'], 'learning_rate': fit_plan['learning_rate'],
              'status': 'FAILED_OR_INCOMPLETE_CHAIN', 'quality_checkpoint_bound': True,
              'original_status': prior['status'], 'C2_status': report['status'], 'reported_adequacy': adequate,
              'parent_work': work, 'new_logged_updates': j['logged_new_updates'], 'new_partial_updates': report['new_unretained_logged_updates'],
              'unclosed_optimizer_call': j['unclosed_optimizer_call'], 'possibly_unlogged_updates': j['possibly_unlogged_optimizer_updates'],
              'best': best_info, 'best_epoch_metrics': history[stop['best_epoch']-1]['development'],
              'last_complete_epoch': final_epoch, 'report_path': str(root/'result.json'), 'report_identity': identity(root/'result.json'),
              'initial_path': str(parent/'initial.pt'), 'initial_identity': identity(parent/'initial.pt'),
              'fit_plan': fit_plan, 'source_map': prior['source_before'], 'inputs': inputs.files,
              'dangling_uncommitted_files': dangling, 'scientific_admission': 'HOLD', 'whole_training_domain': 'HOLD',
              'live_recovery_observation': False, 'zero_optimizer_construction_or_restoration': True}
    # Save a separately bound checkpoint gate before trace streaming; a recording
    # failure can still permit a diagnostic replay, without upgrading chain status.
    inputs.verify()
    save(Path(output)/'BEST-BINDING.json', result)
    report = dict(report, model_data_manifest_sha256=fit_plan['manifest_sha256'])
    program = Path(json.loads((PROGRAM/'PLAN.json').read_bytes())['native_paths']['program'])
    try:
        result['actual_optimization'] = audit_optimization(root, report, j, episodes, states, prior['source_before'], trace_sources,
            context['optimization_policy'], identity(program/'OPTIMIZATION-POSTERIOR-POLICY-v2.json'), inputs)
        result['supplemental'] = audit_supplement(root, report, episodes, by_path, prior['source_before'], trace_sources,
            context['supplement_policy'], identity(program/'POSTERIOR-POLICY.json'), inputs)
        require(result['actual_optimization']['passed_recording_integrity'] and result['supplemental']['passed_recording_integrity'],
                'scheduled recording missing/incomplete')
        result['status'] = 'PASSED_BOUND_EVIDENCE_ONLY'
    except Exception:
        result['recording_error'] = traceback.format_exc()
    inputs.verify()
    result['inputs_unchanged'] = True
    save(Path(output)/'CHAIN.json', result)
    return {'status': 'passed' if result['status'] == 'PASSED_BOUND_EVIDENCE_ONLY' else 'failed_recording_chain',
            'artifact': identity(Path(output)/'CHAIN.json'), 'quality_checkpoint_bound': True,
            'BEST_BINDING': identity(Path(output)/'BEST-BINDING.json'), 'inputs_unchanged': True}
