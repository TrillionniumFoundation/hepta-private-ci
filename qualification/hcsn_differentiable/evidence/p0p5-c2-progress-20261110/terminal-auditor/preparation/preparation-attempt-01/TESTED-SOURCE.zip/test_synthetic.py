"""Synthetic state, trace, journal and real short child-process failures only.

No production input is read. No optimizer is constructed/restored/stepped.
"""
import copy
import hashlib
import inspect
import json
import os
from pathlib import Path
import random
import sys
import tempfile
import unittest
from zipfile import ZipFile

import torch

from audit_io import save
from audit_process import admit_stage, audit_costs, ensure_roster, run_child
from bound_io import Inputs, RSS, ROSTER, identity, terminal_barrier
from checkpoint_checks import semantic_digest, validate_state, validate_witness
from checks import matrix_metrics, stopping, reconstruct_journal, verify_commit, expected_capture, choose_common_lr
from launch import verify_archive
from run_audit import grant_for, withhold_source_failure
from trace_checks import trace


def cm_score(correct=6):
    matrix = [[0]*11 for _ in range(11)]
    for i in range(11):
        matrix[i][i], matrix[i][(i+1)%11] = correct, 10-correct
    return {'events': 110, 'accuracy': correct/10, 'macro_f1_11_classes': correct/10, 'confusion_matrix': matrix}


def epoch(n=1, correct=6):
    return {'epoch': n, 'complete': True, 'development': cm_score(correct)}


def episodes(n=5):
    return [{'id': f'A-{i}', 'y': [0]*(i%3+1), 'dt': [i/10+.01]*(i%3+1)} for i in range(n)]


def journal(partial=False):
    data = episodes()
    ids = [r['id'] for r in data]
    counts = {r['id']:len(r['y']) for r in data}
    rng, rows, updates = random.Random(7), [], 0
    for e in range(1, 3 if partial else 2):
        order = list(ids); rng.shuffle(order)
        rows.append({'kind':'epoch_started','epoch':e,'episode_order':order})
        for b in range(0,len(order),2):
            batch=order[b:b+2]
            rows.append({'kind':'update_started','phase':'main','episode_ids':batch})
            rows.append({'kind':'optimizer_started','phase':'main'})
            updates+=1
            rows.append({'kind':'optimizer_completed','phase':'main','number':updates,
                         'events':sum(counts[i] for i in batch),'loss':1.,'gradient_norm':.3,
                         'micro_forward_calls':len(batch)})
            if partial and e==2:
                break
        if e==1:
            rows.append({'kind':'epoch_completed',**epoch(), 'events':sum(counts.values()),
                         'process_wall_seconds':5.,'process_cpu_seconds':4.})
    rows.append({'kind':'finished','status':'budget_exhausted'})
    return rows, data


def state_fixture():
    model={'frontend.weight':torch.tensor([1.],dtype=torch.float64),
           'core.network.weight':torch.tensor([.4,.6],dtype=torch.float64)}
    defaults={k:v.default for k,v in inspect.signature(torch.optim.AdamW.__init__).parameters.items()
              if k not in ('self','params','lr','weight_decay') and v.default is not inspect.Parameter.empty}
    group={'lr':.001,'weight_decay':0.,'params':[0],**defaults}
    state={'model':copy.deepcopy(model),'model_configuration':{'synthetic':True},'epochs_completed':1,'main_updates':3,
           'data_manifest_sha256':'d'*64,'order_rng':random.Random(7).getstate(),'torch_rng':torch.get_rng_state().clone(),
           'optimizer':{'param_groups':[group],'state':{0:{'step':torch.tensor(3.),
               'exp_avg':torch.zeros(2,dtype=torch.float64),'exp_avg_sq':torch.ones(2,dtype=torch.float64)}}}}
    initial={'model':model,'model_configuration':{'synthetic':True}}
    return state, initial, [{'lr':.001,'weight_decay':0.,'names':['core.network.weight']}]


def trace_fixture(path, transform=None):
    expected=expected_capture(episodes(9),[r['id'] for r in episodes(9)],3,2)
    expected['network_model_sha256']='a'*64
    source={'network.py':'b'*64}
    rows=[{'kind':'header','schema':'hcsn-training-domain-v1','data_sha256':'d'*64,
           'configuration_sha256':'c'*64,'sources':source,'max_bytes':8*1024**2,'max_records':256}]
    for n,p in enumerate(expected['expected_positions']):
        indices=expected['expected_batch_indices_by_position'][n]
        rows.append({'kind':'visit','index':n,'capture':0,'layer':0,'position':p,
                     'batch_indices':indices,'dt':expected['expected_dt_by_position'][n],
                     'episode_id':'+'.join(expected['microbatch_episode_ids']),'update_index':3,
                     'model_sha256':'a'*64,'prior':[[.3,.7] for _ in indices],
                     'posterior':[[.4,.6] for _ in indices],'expected_events':[.1 for _ in indices]})
    if transform:
        transform(rows,expected)
    prefix=b''.join((json.dumps(row)+'\n').encode() for row in rows)
    footer={'kind':'end','captures':1,'seen_records':len(rows)-1,'retained_records':len(rows)-1,
            'dropped_records':0,'truncated':False,'drop_reason':None,'source_unchanged':True,
            'sources_after':source,'padded_states_excluded':expected['expected_padded_sample_states'],
            'prefix_sha256':hashlib.sha256(prefix).hexdigest()}
    path.write_bytes(prefix+(json.dumps(footer)+'\n').encode())
    return expected, source


class JournalTests(unittest.TestCase):
    def test_partial_work_and_boundary_rng(self):
        events,data=journal(True)
        result=reconstruct_journal(events,data,7,2,1)
        self.assertEqual(result['logged_new_updates'],4)
        self.assertEqual(len(result['completed']),1)
        self.assertEqual(result['steps_per_epoch'],3)
        self.assertNotEqual(result['boundary_rng'][1],result['final_order_rng'])

    def test_duplicate_optimizer_completion(self):
        events,data=journal()
        events.insert(4,copy.deepcopy(events[3]))
        with self.assertRaises(ValueError): reconstruct_journal(events,data,7,2,1)

    def test_wrong_batch_or_shuffle(self):
        events,data=journal()
        events[1]['episode_ids']=list(reversed(events[1]['episode_ids']))
        with self.assertRaises(ValueError): reconstruct_journal(events,data,7,2,1)

    def test_cm_and_earlier_plateau(self):
        rows=[epoch(i,6) for i in range(1,41)]
        _,first=stopping(rows)
        self.assertEqual(first,30)
        bad=cm_score();bad['macro_f1_11_classes']=.7
        with self.assertRaises(ValueError): matrix_metrics(bad)

    def test_strict_first_max_and_broken_commit(self):
        rows=[epoch(1,6),epoch(2,6)]
        stop,_=stopping(rows)
        self.assertEqual(stop['best_epoch'],1)
        cp={'bytes':1,'sha256':'a'*64};prior={'path':'p','bytes':1,'sha256':'b'*64}
        commit={'schema':'hcsn-c2-complete-epoch-commit-v1','epoch':rows[-1],'checkpoint':cp,
                'checkpoint_path':'epoch2.pt','best_checkpoint':cp,'best_path':'epoch1.pt',
                'previous_commit':prior,'logical_main_updates':6,'stopping':stop}
        verify_commit(commit,rows[-1],cp,'epoch2.pt',cp,'epoch1.pt',prior,rows,3)
        commit['previous_commit']=None
        with self.assertRaises(ValueError): verify_commit(commit,rows[-1],cp,'epoch2.pt',cp,'epoch1.pt',prior,rows,3)


class StateTests(unittest.TestCase):
    def test_witness_full_moments_and_rng(self):
        state,_,_=state_fixture(); item={'bytes':1,'sha256':'a'*64};work={'partial':2}
        receipt={'schema':'hcsn-c2-before-first-step-witness-v1','checkpoint':item,'parent_last':item,
                 'semantic_sha256':semantic_digest(state),'new_optimizer_steps_before_receipt':0,
                 'actual_restored_state_equal_parent_last':True,'parent_complete_outer_wall_charged':12.,
                 'source':{'x':'b'*64},'discarded_parent_work':work}
        validate_witness(state,copy.deepcopy(state),receipt,item,item,12.,{'x':'b'*64},work)
        changed=copy.deepcopy(state);changed['optimizer']['state'][0]['exp_avg'][0]=.01
        with self.assertRaises(ValueError): validate_witness(state,changed,receipt,item,item,12.,{'x':'b'*64},work)
        changed=copy.deepcopy(state);changed['order_rng']=random.Random(8).getstate()
        with self.assertRaises(ValueError): validate_witness(state,changed,receipt,item,item,12.,{'x':'b'*64},work)

    def test_state_frozen_moment_counter_and_dtype(self):
        state,initial,groups=state_fixture()
        args=(initial,groups,{'frontend.weight'},{'synthetic':True},1,3,'d'*64)
        validate_state(state,*args)
        mutations=[lambda v:v['model']['frontend.weight'].add_(1),
                   lambda v:v['optimizer']['state'][0]['exp_avg_sq'].fill_(-1),
                   lambda v:v['optimizer']['state'][0]['step'].fill_(4),
                   lambda v:v['optimizer']['param_groups'][0].update(betas=(.8,.9))]
        for mutate in mutations:
            bad=copy.deepcopy(state);mutate(bad)
            with self.subTest(mutate=mutate), self.assertRaises(ValueError): validate_state(bad,*args)


class TraceTests(unittest.TestCase):
    def test_exact_valid_samples_padding_and_stream(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'trace.jsonl';expected,sources=trace_fixture(path)
            result=trace(path,identity(path),expected,sources,'c'*64,'d'*64,8*1024**2,Inputs())
            self.assertEqual(result['valid_sample_states'],15)
            self.assertEqual(result['excluded_padding'],9)

    def test_wrong_dt_indices_model_or_probability(self):
        mutations=[lambda rows,e:rows[1]['dt'].__setitem__(0,.999),
                   lambda rows,e:rows[1]['batch_indices'].__setitem__(0,4),
                   lambda rows,e:rows[1].update(model_sha256='e'*64),
                   lambda rows,e:rows[1]['posterior'].__setitem__(0,[.3,.3])]
        for mutate in mutations:
            with tempfile.TemporaryDirectory() as directory:
                path=Path(directory)/'trace.jsonl';expected,sources=trace_fixture(path,mutate)
                with self.subTest(mutate=mutate),self.assertRaises(ValueError):
                    trace(path,identity(path),expected,sources,'c'*64,'d'*64,8*1024**2,Inputs())

    def test_footer_prefix_and_padding(self):
        for key,value in [('prefix_sha256','0'*64),('padded_states_excluded',8),('truncated',True)]:
            with tempfile.TemporaryDirectory() as directory:
                path=Path(directory)/'trace.jsonl';expected,sources=trace_fixture(path)
                rows=path.read_bytes().splitlines(keepends=True);footer=json.loads(rows[-1]);footer[key]=value
                path.write_bytes(b''.join(rows[:-1])+(json.dumps(footer)+'\n').encode())
                with self.subTest(key=key),self.assertRaises(ValueError):
                    trace(path,identity(path),expected,sources,'c'*64,'d'*64,8*1024**2,Inputs())


class TerminalAndResourceTests(unittest.TestCase):
    def good(self):
        outer={'status':'completed','returncode':0,'wall_limit_seconds':10.,'RSS_limit_bytes':RSS,
               'whole_child_wall_seconds':1.,'waited_child_CPU_seconds':.1,
               'sampled_peak_rss_bytes':1000,'wait4_peak_rss_bytes':2000}
        artifact={'schema':'independent-c2-audit-stage-v1','stage':'replay','name':'x','inputs_unchanged':True,
                  'declared_wall_seconds':10.,'declared_RSS_bytes':RSS,'process_wall_seconds':.9,
                  'self_peak_rss_bytes':1000,'status':'passed','program_before':'a'*64,'program_after':'a'*64}
        return outer,artifact

    def test_missing_artifact_nonfinite_wall_and_all_rss_views(self):
        outer,artifact=self.good();admit_stage(outer,artifact,'replay','x',10.,'a'*64)
        with self.assertRaises(ValueError): admit_stage(outer,None,'replay','x',10.,'a'*64)
        mutations=[lambda o,a:o.update(whole_child_wall_seconds=10.001),
                   lambda o,a:o.update(whole_child_wall_seconds=float('nan')),
                   lambda o,a:o.update(sampled_peak_rss_bytes=RSS+1),
                   lambda o,a:o.update(wait4_peak_rss_bytes=RSS+1),
                   lambda o,a:a.update(self_peak_rss_bytes=RSS+1),
                   lambda o,a:o.update(RSS_limit_bytes=3*1024**3),
                   lambda o,a:a.update(declared_wall_seconds=900),
                   lambda o,a:a.update(program_after='b'*64)]
        for mutate in mutations:
            o,a=self.good();mutate(o,a)
            with self.subTest(mutate=mutate),self.assertRaises(ValueError): admit_stage(o,a,'replay','x',10.,'a'*64)

    def test_real_exit0_no_artifact_retains_cost(self):
        with tempfile.TemporaryDirectory() as directory:
            result=run_child([sys.executable,'-B','-c','pass'],Path(directory)/'child',5,dict(os.environ))
            self.assertEqual(result['returncode'],0)
            self.assertGreater(result['whole_child_wall_seconds'],0)
            self.assertGreaterEqual(result['waited_child_CPU_seconds'],0)
            with self.assertRaises(ValueError): admit_stage(result,None,'replay','x',5,'a'*64)

    def test_real_timeout_preserves_stdout_and_cost(self):
        with tempfile.TemporaryDirectory() as directory:
            result=run_child([sys.executable,'-B','-c','import time;print("synthetic",flush=True);time.sleep(2)'],Path(directory)/'child',.1,dict(os.environ))
            self.assertEqual(result['status'],'wall_capped')
            self.assertIsNotNone(result['waited_child_CPU_seconds'])
            self.assertGreater(result['stdout']['bytes'],0)

    def test_terminal_barrier_rejects_missing_pid_or_candidate(self):
        attempts=[{'name':n,'status':'failed','process_started':True,'pid':100+i,'returncode':2} for i,n in enumerate(ROSTER)]
        commands=[r for a in attempts for r in [dict(a,status='running'),a]]
        outer={'status':'completed_attempt_roster','execution_requested':True,'confirmation_access':False,
               'source_inputs_unchanged':True,'attempts':attempts}
        self.assertEqual(len(terminal_barrier(outer,commands,ROSTER,lambda pid:'absent')),6)
        with self.assertRaises(ValueError): terminal_barrier(outer,commands,ROSTER,lambda pid:'running')
        outer['attempts']=attempts[:-1]
        with self.assertRaises(ValueError): terminal_barrier(outer,commands,ROSTER,lambda pid:'absent')

    def test_remaining_budget_roster_and_failed_known_cost(self):
        self.assertEqual(grant_for('chain',359,0),1)
        self.assertEqual(grant_for('chain',361,0),0)
        self.assertEqual(grant_for('replay',1741,0),0)
        self.assertEqual(len(ensure_roster([],ROSTER)),6)
        result=audit_costs([{'label':'failed','outer':{'whole_child_wall_seconds':3.,'waited_child_CPU_seconds':2.}},
                            {'label':'unknown','cost_is_unknown':True}])
        self.assertEqual(result['sum_known_stage_CPU_seconds'],2.)
        self.assertTrue(result['CPU_sum_is_lower_bound'])

    def test_source_change_withholds_claim_but_preserves_values(self):
        r={'execution_status':'completed_fixed_audit_roster','common_lr':{'common_lr':.001},
           'entries':[{'quality_reproducibility':'passed','fresh_development':{'accuracy':.9}}]}
        withhold_source_failure(r,'synthetic source tamper')
        self.assertEqual(r['entries'][0]['quality_reproducibility'],'HOLD')
        self.assertEqual(r['entries'][0]['fresh_development']['accuracy'],.9)
        self.assertNotEqual(r['execution_status'],'completed_fixed_audit_roster')

    def test_selection_never_drops_missing_seed(self):
        rows=[{'name':n,'seed':s,'learning_rate':lr,'quality_reproducibility':'passed',
               'fresh_development':{'macro_f1_11_classes':lr*100}}
              for n,(s,lr) in zip(ROSTER,[(s,l) for s in (101,211,307) for l in (.001,.003)])]
        self.assertEqual(choose_common_lr(rows,ROSTER)['common_lr'],.003)
        rows[-1]['quality_reproducibility']='HOLD'
        self.assertIsNone(choose_common_lr(rows,ROSTER)['all_seed_means'])
        with self.assertRaises(ValueError): choose_common_lr(rows[:-1],ROSTER)


class ArchiveTests(unittest.TestCase):
    def make_archive(self,path,mutate=None):
        summary={'execution_status':'completed_fixed_audit_roster','program_manifest_before':'a'*64,
                 'program_manifest_after':'a'*64,'own_peak_rss_bytes':1000,'complete_process_wall_seconds':10.,
                 'entries':[{'name':n} for n in ROSTER]}
        if mutate: mutate(summary)
        raw=(json.dumps(summary)+'\n').encode()
        manifest={'files':{'SUMMARY.json':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}}}
        with ZipFile(path,'x') as z:
            z.writestr('SUMMARY.json',raw);z.writestr('MANIFEST.json',json.dumps(manifest))

    def test_valid_crc_manifest_and_source_envelope(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'audit.zip';self.make_archive(path)
            verify_archive(path,'a'*64,1000,20.)
            with self.assertRaises(ValueError): verify_archive(path,'a'*64,RSS+1,20.)
            with self.assertRaises(ValueError): verify_archive(path,'a'*64,1000,1800.1)
        for mutate in [lambda v:v.update(program_manifest_after='b'*64),lambda v:v.update(final_program_error='changed')]:
            with tempfile.TemporaryDirectory() as directory:
                path=Path(directory)/'audit.zip';self.make_archive(path,mutate)
                with self.assertRaises(ValueError): verify_archive(path,'a'*64,1000,20.)

    def test_ordinary_file_cannot_be_finalized_as_zip(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'audit.zip';path.write_text('not a ZIP')
            with self.assertRaises(Exception): verify_archive(path,'a'*64,1000,20.)


if __name__=='__main__':
    unittest.main(verbosity=2)
