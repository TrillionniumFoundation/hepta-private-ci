"""Synthetic control-flow probes only: no child launch, model or oracle call."""
from argparse import Namespace
import hashlib
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace
from unittest.mock import patch
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT/'candidate-source'
sys.path.insert(0, str(SOURCE))
import run_audit
import launch
from bound_io import RSS, identity


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True)+'\n')


def fake_run_child(argv, output, grant, environment):
    """Explicit fixture data; this never launches argv."""
    target=Path(argv[argv.index('--output')+1])
    target.mkdir(parents=True,exist_ok=False)
    stage=argv[argv.index('--stage')+1]
    name=argv[argv.index('--name')+1] if '--name' in argv else None
    artifact={'schema':'independent-c2-audit-stage-v1','stage':stage,'name':name,
              'inputs_unchanged':True,'declared_wall_seconds':grant,'declared_RSS_bytes':RSS,
              'process_wall_seconds':.001,'self_peak_rss_bytes':1024,'status':'passed'}
    if stage=='context':
        path=target/'CONTEXT.json';write(path,{'costs_all_six':[]})
    elif stage=='chain':
        path=target/'CHAIN.json';write(path,{'status':'passed','C2_status':'synthetic','reported_adequacy':False})
        best=target/'BEST-BINDING.json';write(best,{'scope':'synthetic fixture'})
        artifact['BEST_BINDING']=identity(best)
    else:
        path=target/'REPLAY.json';write(path,{'quality_reproducibility':'PASS_SYNTHETIC',
             'fresh_development':{'macro_f1_11_classes':.5},'best_epoch':1})
    artifact['artifact']=identity(path)
    write(target/'STAGE.json',artifact)
    return {'status':'completed','returncode':0,'wall_limit_seconds':grant,'RSS_limit_bytes':RSS,
            'whole_child_wall_seconds':.002,'waited_child_CPU_seconds':.001,
            'sampled_peak_rss_bytes':1024,'wait4_peak_rss_bytes':1024}


def source_finality_case():
    output=ROOT/'source-finality-fixture'
    args=Namespace(output=str(output),authorization='synthetic-only',authorization_sha='synthetic-only',
                   binding='synthetic-only',binding_sha='synthetic-only')
    run_audit.START=time.monotonic()
    with patch.object(run_audit,'read_authorization',return_value={}), \
         patch.object(run_audit,'run_child',side_effect=fake_run_child), \
         patch.object(run_audit,'verify_program',side_effect=['synthetic-before',ValueError('synthetic changed auditor source')]), \
         patch.object(run_audit,'choose_common_lr',return_value={'status':'synthetic selection produced'}):
        code=run_audit.main(args)
    summary=json.loads((output/'SUMMARY.json').read_bytes())
    return {'case':'final_program_failure_retains_completed_exit_and_selection','returncode':code,
            'execution_status':summary['execution_status'],'final_program_error_present':'final_program_error' in summary,
            'common_lr':summary.get('common_lr'),
            'six_entries_preserved':len(summary['entries'])==6,
            'raw_quality_pass_count':sum(r['quality_reproducibility']=='PASS_SYNTHETIC' for r in summary['entries']),
            'summary_sha256':hashlib.sha256((output/'SUMMARY.json').read_bytes()).hexdigest()}


def launcher_case(name, bad_zip, peak):
    output=ROOT/name
    args=Namespace(output=str(output),launch_directory=str(ROOT/(name+'-launch')),
                   authorization='synthetic-only',authorization_sha='synthetic-only',
                   binding='synthetic-only',binding_sha='synthetic-only')
    class FakeProcess:
        pid=999991
        returncode=0
        def __init__(self,*unused,**unused_kw):
            if bad_zip:
                Path(str(output)+'.zip').write_bytes(b'not a ZIP archive')
            else:
                with ZipFile(str(output)+'.zip','x') as archive:
                    archive.writestr('synthetic.txt','No process/model execution. This only isolates launcher behavior.')
        def wait(self,timeout=None):
            return 0
        def poll(self):
            return 0
    usage=SimpleNamespace(ru_utime=0.,ru_stime=0.,ru_maxrss=peak//1024)
    launch.START=time.monotonic()
    with patch.object(launch,'read_authorization',return_value={}), \
         patch.object(launch.subprocess,'Popen',FakeProcess), \
         patch.object(launch.resource,'getrusage',return_value=usage):
        code=launch.main(args)
    receipt=json.loads((Path(args.launch_directory)/'RECEIPT.json').read_bytes())
    return {'case':name,'returncode':code,'status':receipt['status'],
            'archive_finalized':receipt.get('archive_finalized',False),
            'waited_peak_rss_bytes':receipt['waited_peak_rss_bytes'],
            'is_invalid_zip':bad_zip,'declared_fixed_RSS_bytes':RSS,
            'scope':'subprocess.Popen and rusage were replaced by explicit metadata fakes; no child or memory load occurred.',
            'receipt_sha256':hashlib.sha256((Path(args.launch_directory)/'RECEIPT.json').read_bytes()).hexdigest()}


def main():
    cases=[source_finality_case(),launcher_case('invalid-archive-fixture',True,1048576),
           launcher_case('outer-memory-fixture',False,RSS+1024)]
    assert cases[0]['returncode']==0 and cases[0]['final_program_error_present']
    assert cases[1]['archive_finalized'] and cases[1]['is_invalid_zip']
    assert cases[2]['archive_finalized'] and cases[2]['waited_peak_rss_bytes']>RSS
    assert 'torch' not in sys.modules and 'mpmath' not in sys.modules
    value={'schema':'C2-auditor-numerics-independent-metadata-counterexamples-v1',
           'candidate_sources':json.loads((ROOT/'CANDIDATE-MANIFEST.json').read_bytes()),
           'actual_model_reads':0,'actual_subprocess_launches':0,'actual_training_or_oracle_calls':0,
           'cases':cases,'interpretation':'These expose control/metadata admission holes in the captured candidate source. They are not observations of production C2 attempts and confer no scientific result.'}
    (ROOT/'COUNTEREXAMPLES.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
    print(json.dumps(value))


if __name__=='__main__':
    main()
