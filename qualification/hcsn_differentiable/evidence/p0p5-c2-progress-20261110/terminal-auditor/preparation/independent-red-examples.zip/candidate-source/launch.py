"""Whole 1800-second process-group envelope. Requires later explicit authorization."""
import time
START = time.monotonic()
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import traceback

from audit_io import require, save
from bound_io import PROGRAM, WHOLE, RSS, AS, identity, read_authorization


def main(args):
    launch = Path(args.launch_directory)
    launch.mkdir(exist_ok=False)
    process = None
    row = {'schema': 'independent-c2-audit-launch-v1', 'process_started': False, 'status': 'started',
           'whole_hard_wall_seconds': WHOLE, 'started_utc': datetime.now(timezone.utc).isoformat(),
           'scientific_admission': 'HOLD', 'confirmation_E_access': False, 'training_steps': 0}
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    try:
        read_authorization(args.authorization, args.authorization_sha, args.binding, args.binding_sha)
        require(not Path(args.output).exists() and not Path(str(args.output)+'.zip').exists(), 'output already exists; no retry')
        argv = [sys.executable, '-B', str(PROGRAM/'run_audit.py'), '--output', args.output,
                '--authorization', args.authorization, '--authorization-sha', args.authorization_sha,
                '--binding', args.binding, '--binding-sha', args.binding_sha]
        row['argv'] = argv
        save(launch/'INTENT.json', row)
        env = dict(os.environ, HCSN_C2_AUDIT_STARTED=str(START), OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                   MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1')
        with (launch/'stdout').open('xb') as stdout, (launch/'stderr').open('xb') as stderr:
            process = subprocess.Popen(argv, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            row.update(process_started=True, pid=process.pid)
            try:
                process.wait(timeout=max(.001, WHOLE-(time.monotonic()-START)))
                row.update(status='completed' if process.returncode == 0 else 'failed', returncode=process.returncode)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                row.update(status='whole_budget_exhausted', returncode=process.returncode,
                           unaccounted_orphan_stage_CPU_possible=True)
        archive = Path(str(args.output)+'.zip')
        if row['status'] == 'completed':
            require(archive.is_file(), 'completed controller lacks archive')
            row['archive'] = identity(archive)
            require(time.monotonic()-START <= WHOLE, 'whole archive verification exceeded envelope')
            row['archive_finalized'] = True
    except Exception:
        row.update(status='launch_or_artifact_failed', error=traceback.format_exc())
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
    finally:
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        row.update(whole_wall_seconds=time.monotonic()-START, own_process_CPU_seconds=time.process_time(),
                   waited_controller_and_descendant_CPU_seconds=usage.ru_utime+usage.ru_stime-before.ru_utime-before.ru_stime,
                   CPU_is_lower_bound=row.get('unaccounted_orphan_stage_CPU_possible', False),
                   waited_peak_rss_bytes=usage.ru_maxrss*1024,
                   finished_utc=datetime.now(timezone.utc).isoformat(), energy_joules=None,
                   scope='whole controller/stage/output archive envelope; nested stage costs not additive')
        for name in ('stdout', 'stderr'):
            row[name] = identity(launch/name) if (launch/name).exists() else None
        save(launch/'RECEIPT.json', row)
        print(json.dumps(row), flush=True)
    return 0 if row['status'] == 'completed' else 2


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('authorization', 'authorization-sha', 'binding', 'binding-sha', 'output', 'launch-directory'):
        parser.add_argument('--'+key, required=True)
    raise SystemExit(main(parser.parse_args()))
