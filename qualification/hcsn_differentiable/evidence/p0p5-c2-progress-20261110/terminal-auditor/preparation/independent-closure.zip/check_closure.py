"""Independent metadata-only closure of three captured control-flow defects."""
from argparse import Namespace
import hashlib
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace
from unittest.mock import patch
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'candidate-source'
sys.path.insert(0, str(SOURCE))
import run_audit
import launch
from bound_io import RSS, ROSTER, identity

PROGRAM_SHA = 'explicit-synthetic-program-sha'


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True) + '\n')


def fake_child(argv, output, grant, environment):
    """Never executes argv; emits only explicitly synthetic metadata."""
    target = Path(argv[argv.index('--output') + 1])
    target.mkdir(parents=True, exist_ok=False)
    stage = argv[argv.index('--stage') + 1]
    name = argv[argv.index('--name') + 1] if '--name' in argv else None
    artifact = dict(schema='independent-c2-audit-stage-v1', stage=stage, name=name,
                    inputs_unchanged=True, declared_wall_seconds=grant, declared_RSS_bytes=RSS,
                    process_wall_seconds=.001, self_peak_rss_bytes=1024, status='passed',
                    program_before=PROGRAM_SHA, program_after=PROGRAM_SHA)
    if stage == 'context':
        path = target / 'CONTEXT.json'
        write(path, {'costs_all_six': []})
    elif stage == 'chain':
        path = target / 'CHAIN.json'
        write(path, dict(status='PASSED_BOUND_EVIDENCE_ONLY', C2_status='synthetic',
                         reported_adequacy=False, independent_adequacy_supported=False))
        best = target / 'BEST-BINDING.json'
        write(best, {'scope': 'synthetic fixture; no real checkpoint'})
        artifact['BEST_BINDING'] = identity(best)
    else:
        path = target / 'REPLAY.json'
        write(path, dict(quality_reproducibility='passed',
                         fresh_development={'macro_f1_11_classes': .5}, best_epoch=1))
    artifact['artifact'] = identity(path)
    write(target / 'STAGE.json', artifact)
    return dict(status='completed', returncode=0, wall_limit_seconds=grant, RSS_limit_bytes=RSS,
                whole_child_wall_seconds=.002, waited_child_CPU_seconds=.001,
                sampled_peak_rss_bytes=1024, wait4_peak_rss_bytes=1024)


def controller_case(name, source_changed=False, prelaunch_failure=False):
    output = ROOT / name
    args = Namespace(output=str(output), authorization='synthetic', authorization_sha='synthetic',
                     binding='synthetic', binding_sha='synthetic')
    final = ValueError('explicit synthetic auditor source mutation') if source_changed else PROGRAM_SHA
    child = OSError('explicit synthetic prelaunch failure') if prelaunch_failure else fake_child
    run_audit.START = time.monotonic()
    with patch.object(run_audit, 'read_authorization', return_value={}), \
         patch.object(run_audit, 'verify_program', side_effect=[PROGRAM_SHA, final]), \
         patch.object(run_audit, 'run_child', side_effect=child):
        code = run_audit.main(args)
    summary = json.loads((output / 'SUMMARY.json').read_bytes())
    assert len(summary['entries']) == 6
    if source_changed:
        assert code == 2 and summary['execution_status'] == 'failed_audit_source_changed'
        assert all(e['quality_reproducibility'] == 'HOLD' for e in summary['entries'])
        assert all(e['fresh_development']['macro_f1_11_classes'] == .5 for e in summary['entries'])
        assert summary['common_lr']['status'] == 'withheld_source_integrity_failure'
        assert summary['unadmitted_derived_common_lr']['common_lr'] == .001
    elif prelaunch_failure:
        assert code == 2 and summary['audit_stage_costs']['CPU_sum_is_lower_bound']
        assert summary['audit_stage_costs']['unknown_CPU_stage_names'] == ['context']
        assert all(e['quality_reproducibility'] == 'HOLD' for e in summary['entries'])
    else:
        assert code == 0 and summary['execution_status'] == 'completed_fixed_audit_roster'
        assert all(e['quality_reproducibility'] == 'passed' for e in summary['entries'])
        assert summary['common_lr']['common_lr'] == .001
    return dict(case=name, returncode=code, execution_status=summary['execution_status'],
                six_entries_preserved=True, quality_flags=[e['quality_reproducibility'] for e in summary['entries']],
                common_lr=summary.get('common_lr'), summary=identity(output / 'SUMMARY.json'))


def valid_archive(path, source_changed=False):
    summary = dict(execution_status='completed_fixed_audit_roster',
                   program_manifest_before=PROGRAM_SHA,
                   program_manifest_after='different' if source_changed else PROGRAM_SHA,
                   own_peak_rss_bytes=1024, complete_process_wall_seconds=.001,
                   entries=[{'name': n} for n in ROSTER])
    raw = (json.dumps(summary, sort_keys=True) + '\n').encode()
    manifest = {'files': {'SUMMARY.json': dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())}}
    with ZipFile(path, 'x') as archive:
        archive.writestr('SUMMARY.json', raw)
        archive.writestr('MANIFEST.json', json.dumps(manifest))


def launcher_case(name, bad_zip=False, peak=1024, source_changed=False):
    output = ROOT / name
    args = Namespace(output=str(output), launch_directory=str(ROOT / (name + '-launch')),
                     authorization='synthetic', authorization_sha='synthetic', binding='synthetic', binding_sha='synthetic')
    class FakeProcess:
        pid = 999991
        returncode = None
        def __init__(self, *unused, **unused_keywords):
            if bad_zip:
                Path(str(output) + '.zip').write_bytes(b'not a ZIP archive')
            else:
                valid_archive(str(output) + '.zip', source_changed)
        def poll(self):
            return self.returncode
        def wait(self, timeout=None):
            return self.returncode
    usage = SimpleNamespace(ru_utime=0., ru_stime=0., ru_maxrss=peak // 1024)
    launch.START = time.monotonic()
    with patch.object(launch, 'read_authorization', return_value={'program_manifest_sha256': PROGRAM_SHA}), \
         patch.object(launch.subprocess, 'Popen', FakeProcess), \
         patch.object(launch.os, 'wait4', return_value=(999991, 0, usage)), \
         patch.object(launch.resource, 'getrusage', return_value=usage), \
         patch.object(launch.os, 'killpg', side_effect=AssertionError('No real process may be killed')):
        code = launch.main(args)
    receipt = json.loads((Path(args.launch_directory) / 'RECEIPT.json').read_bytes())
    rejected = bad_zip or peak > RSS or source_changed
    assert (code == 2) == rejected
    assert receipt.get('archive_finalized', False) == (not rejected)
    if bad_zip:
        assert 'BadZipFile' in receipt['error']
    if peak > RSS:
        assert 'whole RSS/wall cap exceeded' in receipt['error']
    if source_changed:
        assert 'controller/source summary failed' in receipt['error']
    return dict(case=name, returncode=code, status=receipt['status'],
                archive_finalized=receipt.get('archive_finalized', False),
                exact_waited_peak_rss_bytes=receipt['exact_waited_peak_rss_bytes'],
                receipt=identity(Path(args.launch_directory) / 'RECEIPT.json'))


def main():
    cases = [controller_case('positive-controller'),
             controller_case('final-source-tamper', source_changed=True),
             controller_case('prelaunch-failure', prelaunch_failure=True),
             launcher_case('positive-launcher'),
             launcher_case('non-ZIP', bad_zip=True),
             launcher_case('outer-RSS-exceeded', peak=RSS + 1024),
             launcher_case('archive-source-tamper', source_changed=True)]
    assert 'torch' not in sys.modules and 'mpmath' not in sys.modules
    manifest = json.loads((ROOT / 'CANDIDATE-MANIFEST.json').read_bytes())
    for name, item in manifest['files'].items():
        assert identity(SOURCE / name) == item
    result = dict(schema='independent-C2-auditor-metadata-closure-v1', status='passed_all_seven_metadata_cases',
                  source_manifest=identity(ROOT / 'CANDIDATE-MANIFEST.json'), cases=cases,
                  actual_model_reads=0, actual_training_or_oracle_calls=0, actual_subprocess_launches_inside_probes=0,
                  positive_controls=2, negative_controls=5,
                  mock_protocol_change='wait4 metadata protocol replaces original wait protocol; valid archive and unchanged source positive controls pass',
                  original_red_evidence_preserved='c2-auditor-numerics-static-review-v1.zip',
                  interpretation='Only control/metadata admission closure. No C2 production execution, checkpoint, numerical or scientific approval.')
    write(ROOT / 'CLOSURE.json', result)
    print(json.dumps({'status': result['status'], 'cases': len(cases), 'CLOSURE': identity(ROOT / 'CLOSURE.json')}))


if __name__ == '__main__':
    main()
