"""One serial, fixed-roster terminal audit. Never starts an optimization process."""
import os
import time
START = float(os.environ.get('HCSN_C2_AUDIT_STARTED', time.monotonic()))
import argparse
import json
from pathlib import Path
import resource
import sys
import traceback
from zipfile import ZipFile, ZIP_DEFLATED

from audit_io import require, save, verify_program
from audit_process import admit_stage, audit_costs, ensure_roster, run_child
from bound_io import PROGRAM, AS, WHOLE, RESERVE, METADATA, REPLAY, ROSTER, RSS, identity, read_authorization
from checks import choose_common_lr


def grant_for(stage, now, start=START):
    whole = WHOLE - (now-start) - RESERVE
    limit = METADATA-(now-start) if stage in ('context', 'chain') else REPLAY
    return max(0.0, min(limit, whole))


def withhold_source_failure(result, error):
    result['final_program_error'] = error
    result['execution_status'] = 'failed_audit_source_changed'
    result['unadmitted_derived_common_lr'] = result.pop('common_lr', None)
    result['common_lr'] = {'status': 'withheld_source_integrity_failure', 'all_seed_means': None}
    for entry in result['entries']:
        entry['raw_quality_reproducibility_before_source_gate'] = entry.get('quality_reproducibility')
        entry['quality_reproducibility'] = 'HOLD'
        entry['status'] = 'FAILED_OR_INCOMPLETE_CHAIN'


def main(args):
    out = Path(args.output)
    out.mkdir(exist_ok=False)
    (out/'stages').mkdir()
    stages, entries = [], [{'name': n, 'seed': int(n.split('-s')[1].split('-')[0]),
                           'learning_rate': float(n.split('-lr')[1]),
                           'status': 'UNRUN_WITHIN_AUDIT_BUDGET', 'quality_reproducibility': 'HOLD'} for n in ROSTER]
    result = {'schema': 'independent-c2-terminal-audit-v1', 'scientific_admission': 'HOLD',
              'whole_training_numerical_admission': 'HOLD', 'confirmation_E_access': False,
              'training_steps': 0, 'optimizer_construct_restore_step_calls': 0, 'original_budget_curves_modified': False}
    env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
               NUMEXPR_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
    required = ['--authorization', args.authorization, '--authorization-sha', args.authorization_sha,
                '--binding', args.binding, '--binding-sha', args.binding_sha]
    def launch(stage, name=None, extra=None):
        label = stage + ('-'+name if name else '')
        granted = grant_for(stage, time.monotonic())
        receipt = {'label': label, 'stage': stage, 'name': name, 'planned_grant_seconds': granted,
                   'status': 'unrun_budget', 'admitted': False}
        stages.append(receipt)
        if granted <= 0:
            return None
        target = out/'stages'/label
        wrapper = ('import resource,runpy,sys;resource.setrlimit(resource.RLIMIT_AS,('
                   +str(AS)+','+str(AS)+'));p=sys.argv[1];sys.argv=sys.argv[1:];'
                   'sys.path.insert(0,str(__import__("pathlib").Path(p).parent));runpy.run_path(p,run_name="__main__")')
        argv = [sys.executable, '-B', '-c', wrapper, str(PROGRAM/'stage.py'), *required,
                '--stage', stage, '--output', str(target)]
        if name:
            argv += ['--name', name]
        argv += extra or []
        try:
            outer = run_child(argv, out/'stages'/(label+'-process'), granted, env)
            receipt.update(outer=outer, status=outer['status'])
            path = target/'STAGE.json'
            artifact = json.loads(path.read_bytes())
            receipt['artifact'] = identity(path)
            admit_stage(outer, artifact, stage, name, granted, result['program_manifest_before'])
            receipt.update(admitted=True, result=artifact)
            return target, artifact
        except Exception:
            if 'outer' not in receipt:
                receipt.update(status='prelaunch_or_wrapper_exception', process_started=None,
                               known_cost=None, cost_is_unknown=True)
            receipt['admission_error'] = traceback.format_exc()
            return None
        finally:
            save(out/'stages'/(label+'-admission.json'), receipt)
    try:
        read_authorization(args.authorization, args.authorization_sha, args.binding, args.binding_sha)
        result['program_manifest_before'] = verify_program(PROGRAM)
        root_stage = launch('context')
        require(root_stage is not None, 'terminal context failed or unrun')
        context_path = root_stage[0]/'CONTEXT.json'
        context_item = identity(context_path)
        require(context_item == root_stage[1]['artifact'], 'context output hash differs')
        context = json.loads(context_path.read_bytes())
        result['opportunity_costs_all_six'] = context['costs_all_six']
        shared = ['--context', str(context_path), '--context-sha', context_item['sha256']]
        bests = {}
        for entry in entries:
            candidate = launch('chain', entry['name'], shared)
            if candidate is None:
                entry['status'] = 'FAILED_OR_INCOMPLETE_CHAIN' if stages[-1].get('outer') else 'UNRUN_WITHIN_AUDIT_BUDGET'
                continue
            path, artifact = candidate
            chain = json.loads((path/'CHAIN.json').read_bytes())
            require(identity(path/'CHAIN.json') == artifact['artifact'], 'chain output hash differs')
            entry.update(status=chain['status'], chain_result=identity(path/'CHAIN.json'),
                         C2_status=chain['C2_status'], reported_adequacy=chain['reported_adequacy'])
            best = path/'BEST-BINDING.json'
            require(identity(best) == artifact['BEST_BINDING'], 'best binding output hash differs')
            bests[entry['name']] = best
        for entry in entries:
            if entry['name'] not in bests:
                stages.append({'label': 'replay-'+entry['name'], 'stage': 'replay', 'name': entry['name'],
                               'status': 'unrun_unbound_checkpoint', 'admitted': False})
                continue
            best = bests[entry['name']]
            replay = launch('replay', entry['name'], shared+['--best', str(best), '--best-sha', identity(best)['sha256']])
            if replay is None:
                entry['quality_reproducibility'] = 'HOLD'
                continue
            path, artifact = replay
            row = json.loads((path/'REPLAY.json').read_bytes())
            require(identity(path/'REPLAY.json') == artifact['artifact'], 'replay output hash differs')
            entry.update(quality_reproducibility=row['quality_reproducibility'], fresh_development=row['fresh_development'],
                         replay_result=identity(path/'REPLAY.json'), best_epoch=row['best_epoch'])
        result['common_lr'] = choose_common_lr(entries, ROSTER)
        result['execution_status'] = 'completed_fixed_audit_roster'
    except Exception:
        result.update(execution_status='failed_or_budget_censored_audit', error=traceback.format_exc())
    finally:
        raw_costs = out/'stages/context/TERMINAL-ROSTER.json'
        if raw_costs.is_file() and 'opportunity_costs_all_six' not in result:
            result['unadmitted_raw_terminal_costs'] = {'artifact': identity(raw_costs),
                'scope': 'raw process cost evidence retained; context/source admission did not complete'}
        result.update(entries=ensure_roster(entries, ROSTER), stages=stages, audit_stage_costs=audit_costs(stages),
                      complete_process_wall_seconds=time.monotonic()-START, own_process_CPU_seconds=time.process_time(),
                      own_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
                      energy_joules=None, whole_training_domain='HOLD',
                      archive_status='provisional_until_external_launch_terminal_and_archive_SHA')
        try:
            result['program_manifest_after'] = verify_program(PROGRAM)
            require(result['program_manifest_after'] == result.get('program_manifest_before'), 'auditor source changed')
        except Exception:
            withhold_source_failure(result, traceback.format_exc())
        save(out/'SUMMARY.json', result)
        save(out/'MANIFEST.json', {'files': {str(p.relative_to(out)): identity(p) for p in sorted(out.rglob('*')) if p.is_file()}})
        with ZipFile(str(out)+'.zip', 'x', compression=ZIP_DEFLATED) as archive:
            for path in sorted(out.rglob('*')):
                if path.is_file():
                    archive.write(path, str(path.relative_to(out)))
    return 0 if result['execution_status'] == 'completed_fixed_audit_roster' else 2


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('authorization', 'authorization-sha', 'binding', 'binding-sha', 'output'):
        parser.add_argument('--'+key, required=True)
    raise SystemExit(main(parser.parse_args()))
