"""Actual controller paths under explicit metadata mocks, never model processes."""
from argparse import Namespace
import json
from pathlib import Path
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from zipfile import ZipFile

import launch
import run_audit
from bound_io import RSS, ROSTER, identity


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True)+'\n')


def fake_stage(argv, output, grant, environment):
    target=Path(argv[argv.index('--output')+1]);target.mkdir(parents=True)
    stage=argv[argv.index('--stage')+1]
    name=argv[argv.index('--name')+1] if '--name' in argv else None
    artifact={'schema':'independent-c2-audit-stage-v1','stage':stage,'name':name,'inputs_unchanged':True,
              'declared_wall_seconds':grant,'declared_RSS_bytes':RSS,'process_wall_seconds':.001,
              'self_peak_rss_bytes':1024,'status':'passed','program_before':'synthetic-before','program_after':'synthetic-before'}
    if stage=='context':
        path=target/'CONTEXT.json';write(path,{'costs_all_six':[]})
    elif stage=='chain':
        path=target/'CHAIN.json';write(path,{'status':'PASSED_BOUND_EVIDENCE_ONLY','C2_status':'synthetic','reported_adequacy':False})
        best=target/'BEST-BINDING.json';write(best,{'scope':'synthetic fixture'})
        artifact['BEST_BINDING']=identity(best)
    else:
        path=target/'REPLAY.json';write(path,{'quality_reproducibility':'passed','fresh_development':{'macro_f1_11_classes':.5},'best_epoch':1})
    artifact['artifact']=identity(path);write(target/'STAGE.json',artifact)
    return {'status':'completed','returncode':0,'wall_limit_seconds':grant,'RSS_limit_bytes':RSS,
            'whole_child_wall_seconds':.002,'waited_child_CPU_seconds':.001,
            'sampled_peak_rss_bytes':1024,'wait4_peak_rss_bytes':1024}


class ClosureTests(unittest.TestCase):
    def test_final_source_failure_revokes_all_six_and_selection(self):
        with tempfile.TemporaryDirectory() as directory:
            args=Namespace(output=str(Path(directory)/'output'),authorization='synthetic',authorization_sha='synthetic',
                           binding='synthetic',binding_sha='synthetic')
            with patch.object(run_audit,'read_authorization',return_value={}), \
                 patch.object(run_audit,'run_child',side_effect=fake_stage), \
                 patch.object(run_audit,'verify_program',side_effect=['synthetic-before',ValueError('synthetic source tamper')]):
                code=run_audit.main(args)
            summary=json.loads((Path(args.output)/'SUMMARY.json').read_bytes())
            self.assertNotEqual(code,0)
            self.assertEqual([r['quality_reproducibility'] for r in summary['entries']],['HOLD']*6)
            self.assertEqual(summary['common_lr']['status'],'withheld_source_integrity_failure')
            self.assertEqual(summary['unadmitted_derived_common_lr']['common_lr'],.001)
            self.assertEqual(len(summary['entries']),6)
            self.assertTrue(all(r['fresh_development']['macro_f1_11_classes']==.5 for r in summary['entries']))

    def launcher_case(self,bad_zip,peak):
        with tempfile.TemporaryDirectory() as directory:
            output=Path(directory)/'out'
            args=Namespace(output=str(output),launch_directory=str(Path(directory)/'launch'),
                           authorization='synthetic',authorization_sha='synthetic',binding='synthetic',binding_sha='synthetic')
            class FakeProcess:
                pid=999991
                returncode=0
                def __init__(self,*unused,**kw):
                    if bad_zip:
                        Path(str(output)+'.zip').write_bytes(b'not a ZIP archive')
                    else:
                        # Deliberately incomplete manifest isolates the memory gate,
                        # which runs before any archive/member acceptance.
                        with ZipFile(str(output)+'.zip','x') as archive:
                            archive.writestr('synthetic.txt','No process/model executed.')
                def poll(self): return 0
            usage=SimpleNamespace(ru_utime=0.,ru_stime=0.,ru_maxrss=peak//1024)
            with patch.object(launch,'read_authorization',return_value={'program_manifest_sha256':'synthetic'}), \
                 patch.object(launch.subprocess,'Popen',FakeProcess), \
                 patch.object(launch.os,'wait4',return_value=(999991,0,usage)), \
                 patch.object(launch.resource,'getrusage',return_value=usage):
                code=launch.main(args)
            receipt=json.loads((Path(args.launch_directory)/'RECEIPT.json').read_bytes())
            self.assertNotEqual(code,0)
            self.assertFalse(receipt.get('archive_finalized',False))
            return receipt

    def test_non_zip_never_finalized(self):
        receipt=self.launcher_case(True,1024)
        self.assertIn('BadZipFile',receipt['error'])

    def test_controller_peak_RSS_never_finalized(self):
        receipt=self.launcher_case(False,RSS+1024)
        self.assertIn('whole RSS/wall cap exceeded',receipt['error'])

    def test_wrapper_exception_preserves_six_and_unknown_cost(self):
        with tempfile.TemporaryDirectory() as directory:
            args=Namespace(output=str(Path(directory)/'out'),authorization='synthetic',authorization_sha='synthetic',
                           binding='synthetic',binding_sha='synthetic')
            with patch.object(run_audit,'read_authorization',return_value={}), \
                 patch.object(run_audit,'run_child',side_effect=OSError('synthetic mkdir failure')), \
                 patch.object(run_audit,'verify_program',return_value='same'):
                code=run_audit.main(args)
            summary=json.loads((Path(args.output)/'SUMMARY.json').read_bytes())
            self.assertNotEqual(code,0)
            self.assertEqual({r['name'] for r in summary['entries']},set(ROSTER))
            self.assertTrue(summary['audit_stage_costs']['CPU_sum_is_lower_bound'])
            self.assertEqual(summary['audit_stage_costs']['unknown_CPU_stage_names'],['context'])


if __name__=='__main__':
    unittest.main(verbosity=2)
