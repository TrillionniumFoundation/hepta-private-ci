"""One full-D replay from an independently bound strict-best checkpoint."""
import json
from pathlib import Path
import time

from audit_io import require, read_dev, save
from bound_io import Inputs, identity
from checkpoint_checks import model_and_groups
from independent_metrics import metrics, compare_metrics
from prior_replay_fit import fresh_forward, tensor_digest


def run(context_path, context_sha, best_path, best_sha, output, budget):
    import numpy as np
    import torch
    from audit_chain import runtime_identity
    inputs = Inputs(budget)
    context = inputs.json(context_path, context_sha)
    bound = inputs.json(best_path, best_sha)
    require(bound['quality_checkpoint_bound'] is True, 'strict-best chain not bound')
    for path, item in {**context['inputs'], **bound['inputs']}.items():
        inputs.bind(path, item)
    require(runtime_identity() == context['runtime'], 'native runtime differs')
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    temporary = {}
    rows = read_dev(context['original_replay_plan'], temporary)
    for path, digest in temporary.items():
        inputs.bind(path, digest)
    best = bound['best']
    state_path = inputs.bind(best['path'], best['identity'])
    initial_path = inputs.bind(bound['initial_path'], bound['initial_identity'])
    state = torch.load(state_path, weights_only=True, mmap=True, map_location='cpu')
    initial = torch.load(initial_path, weights_only=True, mmap=True, map_location='cpu')
    require(state['epochs_completed'] == best['epoch'] and state['main_updates'] == best['main_updates'], 'best boundary changed')
    model, _, _ = model_and_groups(context, bound['fit_plan'], initial, bound['source_map'])
    model.load_state_dict(state['model'], strict=True)
    from hcsn_study_support import batches, sources
    require(model.core.recorder is None, 'unexpected recorder on quality replay')
    del state, initial
    with (Path(output)/'batches.jsonl').open('x') as journal:
        def record(row):
            journal.write(json.dumps(row, allow_nan=False)+'\n')
            journal.flush()
        logits, labels, before = fresh_forward(model, rows, 32, batches, budget, record)
    wanted = torch.tensor([y for row in rows for y in row['y']], dtype=torch.long)
    require(torch.equal(labels, wanted) and logits.shape == (31952, 11), 'full D labels/shape/order')
    actual = metrics(logits.numpy(), labels.numpy())
    differences = compare_metrics(actual, bound['best_epoch_metrics'], 2e-12)
    report = inputs.json(bound['report_path'], bound['report_identity'])
    saved = {'status': 'legitimately_absent_in_failed_terminal'}
    root = Path(bound['report_path']).parent
    if (root/'development_logits.pt').exists():
        require('selected_development_logits' in report and 'selected_development' in report,
                'unbound saved logits artifact')
        path = inputs.bind(root/'development_logits.pt', report['selected_development_logits'])
        stored = torch.load(path, weights_only=True, mmap=True, map_location='cpu')
        require(stored['episode_ids'] == [r['id'] for r in rows] and torch.equal(stored['labels'], labels), 'saved D labels/order')
        saved_metrics = metrics(stored['logits'].numpy(), stored['labels'].numpy())
        compare_metrics(saved_metrics, report['selected_development'], 2e-12)
        compare_metrics(saved_metrics, bound['best_epoch_metrics'], 2e-12)
        maximum = float((stored['logits']-logits).abs().max())
        require(maximum <= 2e-12, 'fresh/saved logits differ')
        saved = {'status': 'bound_saved_logits_and_metrics_match', 'max_logit_difference': maximum, 'file': identity(path)}
    else:
        require(report['status'] != 'completed_development'
                and 'selected_development' not in report and 'selected_development_logits' not in report,
                'successful report missing selected artifact')
    path = Path(output)/'fresh-development-logits.pt'
    with path.open('xb') as stream:
        torch.save({'logits': logits, 'labels': labels, 'episode_ids': [r['id'] for r in rows],
                    'event_episode_index': torch.tensor([i for i, r in enumerate(rows) for _ in r['y']]),
                    'event_position': torch.tensor([i for r in rows for i in range(len(r['y']))]),
                    'source_rows': torch.tensor([i for r in rows for i in r['source_rows']]),
                    'best_epoch': best['epoch'], 'best_checkpoint': best['identity']}, stream)
    require(sources(model) == bound['source_map'] and before == tensor_digest(model.state_dict()), 'source/tensors changed during replay')
    inputs.verify()
    result = {'schema': 'independent-c2-best-D-v1', 'status': 'passed', 'name': bound['name'], 'seed': bound['seed'],
              'learning_rate': bound['learning_rate'], 'quality_reproducibility': 'passed',
              'best_epoch': best['epoch'], 'best_checkpoint': best['identity'], 'best_path': best['path'],
              'original_status': bound['original_status'], 'C2_status': bound['C2_status'],
              'reported_adequacy': bound['reported_adequacy'], 'fresh_development': actual,
              'metric_absolute_differences': differences, 'saved_logits': saved, 'fresh_logits': identity(path),
              'tensor_digest_before': before, 'tensor_digest_after': tensor_digest(model.state_dict()),
              'inputs': inputs.files, 'inputs_unchanged': True, 'confirmation_E_access': False,
              'optimizer_construct_restore_step_calls': 0, 'backward_calls': 0,
              'scientific_admission': 'HOLD', 'whole_training_domain': 'HOLD',
              'scope': 'same D tuning subject; no independent confirmation or new training-adequacy credit'}
    save(Path(output)/'REPLAY.json', result)
    return {'status': 'passed', 'artifact': identity(Path(output)/'REPLAY.json'), 'inputs_unchanged': True}
