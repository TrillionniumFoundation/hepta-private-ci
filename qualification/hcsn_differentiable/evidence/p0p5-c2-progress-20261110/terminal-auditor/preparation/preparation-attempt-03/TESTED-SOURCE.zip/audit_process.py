"""Exact per-child wait4 accounting and independent resource/artifact admission."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import traceback

from audit_io import require, save
from bound_io import RSS, AS, identity
from checks import finite


def admit_stage(outer, artifact, stage, name, grant, program_sha):
    require(outer.get('status') == 'completed' and outer.get('returncode') == 0, 'stage process did not complete')
    require(outer.get('wall_limit_seconds') == grant and 0 < grant <= (360 if stage in ('context', 'chain') else 210)
            and outer.get('RSS_limit_bytes') == RSS, 'declared stage cap changed')
    require(finite(outer.get('whole_child_wall_seconds')) and 0 <= outer['whole_child_wall_seconds'] <= grant
            and finite(outer.get('waited_child_CPU_seconds')) and outer['waited_child_CPU_seconds'] >= 0, 'invalid/over-budget wall/CPU')
    require(all(type(outer.get(k)) is int and 0 <= outer[k] <= RSS for k in ('sampled_peak_rss_bytes', 'wait4_peak_rss_bytes')),
            'outer memory missing or above fixed cap')
    require(isinstance(artifact, dict), 'exit0 lacks readable result artifact')
    require(artifact.get('schema') == 'independent-c2-audit-stage-v1' and artifact.get('stage') == stage
            and artifact.get('name') == name and artifact.get('inputs_unchanged') is True,
            'stage artifact identity/integrity differs')
    require(artifact.get('declared_wall_seconds') == grant and artifact.get('declared_RSS_bytes') == RSS,
            'artifact changed declared resource limits')
    require(finite(artifact.get('process_wall_seconds')) and 0 <= artifact['process_wall_seconds'] <= grant
            and type(artifact.get('self_peak_rss_bytes')) is int and 0 <= artifact['self_peak_rss_bytes'] <= RSS,
            'artifact wall/RSS outside grant')
    require(artifact.get('status') in ('passed', 'failed_recording_chain'), 'stage evidence failed')
    require(artifact.get('program_before') == artifact.get('program_after') == program_sha, 'stage source identity differs')
    return artifact


def run_child(argv, output, grant, environment):
    output = Path(output)
    output.mkdir(exist_ok=False)
    started = time.monotonic()
    row = {'status': 'started', 'process_started': False, 'wall_limit_seconds': grant, 'RSS_limit_bytes': RSS,
           'sampled_peak_rss_bytes': 0, 'wait4_peak_rss_bytes': None, 'waited_child_CPU_seconds': None,
           'started_utc': datetime.now(timezone.utc).isoformat(), 'argv': argv}
    process, usage = None, None
    try:
        env = dict(environment, HCSN_C2_AUDIT_STAGE_START=str(started), HCSN_C2_AUDIT_STAGE_GRANT=str(grant))
        with (output/'stdout').open('xb') as stdout, (output/'stderr').open('xb') as stderr:
            process = subprocess.Popen(argv, env=env, stdout=stdout, stderr=stderr, stdin=subprocess.DEVNULL)
            row.update(process_started=True, pid=process.pid)
            killed = False
            while True:
                pid, status, observed = os.wait4(process.pid, os.WNOHANG)
                if pid:
                    usage = observed
                    process.returncode = os.waitstatus_to_exitcode(status)
                    break
                try:
                    lines = Path(f'/proc/{process.pid}/status').read_text().splitlines()
                    values = [int(line.split()[1])*1024 for line in lines if line.startswith('VmRSS:')]
                    if values:
                        row['sampled_peak_rss_bytes'] = max(row['sampled_peak_rss_bytes'], values[0])
                except (FileNotFoundError, ProcessLookupError):
                    pass
                over_wall = time.monotonic()-started > grant
                over_rss = row['sampled_peak_rss_bytes'] > RSS
                if (over_wall or over_rss) and not killed:
                    row['status'] = 'wall_capped' if over_wall else 'RSS_capped'
                    os.kill(process.pid, signal.SIGKILL)
                    killed = True
                time.sleep(.02)
        row['returncode'] = process.returncode
        if row['status'] == 'started':
            row['status'] = 'completed' if process.returncode == 0 else 'failed'
    except Exception:
        row.update(status='launch_or_monitor_failed', error=traceback.format_exc())
        if process is None:
            row['process_started'] = None
        elif process.returncode is None:
            try:
                os.kill(process.pid, signal.SIGKILL)
                _, status, usage = os.wait4(process.pid, 0)
                process.returncode = os.waitstatus_to_exitcode(status)
                row['returncode'] = process.returncode
            except Exception:
                row.update(child_terminal_unknown=True, cleanup_error=traceback.format_exc())
    finally:
        if usage is not None:
            row.update(waited_child_CPU_seconds=usage.ru_utime+usage.ru_stime, wait4_peak_rss_bytes=usage.ru_maxrss*1024)
        row.update(whole_child_wall_seconds=time.monotonic()-started,
                   finished_utc=datetime.now(timezone.utc).isoformat(),
                   cost_scope='whole single child; includes import/hash/audit/forward/output; never added to nested inner timer',
                   CPU_cost_complete=usage is not None, energy_joules=None)
        for name in ('stdout', 'stderr'):
            row[name] = identity(output/name) if (output/name).exists() else None
        save(output/'OUTER.json', row)
    return row


def ensure_roster(entries, roster):
    known = {r['name']: r for r in entries}
    require(len(known) == len(entries), 'duplicate roster record')
    return [known.get(name, {'name': name, 'status': 'UNRUN_WITHIN_AUDIT_BUDGET', 'process_started': False,
                             'quality_reproducibility': 'HOLD', 'unknown_cost': True}) for name in roster]


def audit_costs(stages):
    observed = [r['outer'] for r in stages if 'outer' in r]
    missing = [r.get('label') for r in stages if r.get('cost_is_unknown') or
               'outer' in r and r['outer'].get('waited_child_CPU_seconds') is None]
    return {'sum_known_stage_wall_seconds': sum(r['whole_child_wall_seconds'] for r in observed),
            'sum_known_stage_CPU_seconds': sum(r['waited_child_CPU_seconds'] for r in observed if r.get('waited_child_CPU_seconds') is not None),
            'CPU_sum_is_lower_bound': bool(missing), 'unknown_CPU_stage_names': missing,
            'nested_timers_are_not_added': True, 'energy_joules': None}
