"""Synthetic serialized CAPTURE/STEP tests; no training or production state."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import torch

from bound_io import Inputs, identity
from checkpoint_checks import semantic_digest
from checks import expected_capture
from trace_checks import audit_optimization
from test_synthetic import episodes, trace_fixture


def make_capture(root):
    data=episodes(9)
    path=root/'optimization-windows/epoch-0047-first-main-microbatch'
    path.mkdir(parents=True)
    expected,sources=trace_fixture(path/'trace.jsonl')
    order=[r['id'] for r in data]
    prior={'main_updates':3,'grid_states':2,'network_sha256':'a'*64,'visit_configuration':{},
           'identity':{'bytes':1,'sha256':'p'*64},'path':str(root/'predecessor.pt'),'model_semantic_sha256':'m'*64}
    mask=torch.tensor([[p < len(r['y']) for p in range(3)] for r in data],dtype=torch.bool)
    footer=json.loads((path/'trace.jsonl').read_bytes().splitlines()[-1])
    capture={**expected,'slot':'epoch-0047-first-main-microbatch','labels':['resume-first-main-microbatch'],
             'epoch':47,'effective_batch_index':0,'capture_grad_enabled':True,'status':'captured_actual_gradient_microbatch',
             'optimizer_step_completed':False,'checkpoint':prior['identity'],'checkpoint_path':prior['path'],
             'model_semantic_sha256':prior['model_semantic_sha256'],'model_configuration':{'synthetic':True},
             'source_before':{'source.py':'s'*64},'trace_source_hashes':sources,'policy':{'bytes':1,'sha256':'c'*64},
             'actual_logged_main_updates_before_step':5,'path':str(path/'trace.jsonl'),'trace':identity(path/'trace.jsonl'),
             'footer':footer,'effective_batch_valid_mask_sha256':semantic_digest(mask),
             'microbatch_valid_mask_sha256':semantic_digest(mask[:8])}
    (path/'CAPTURE.json').write_text(json.dumps(capture)+'\n')
    step={'capture':identity(path/'CAPTURE.json'),'slot':capture['slot'],'logical_step':4,'new_step':1,'optimizer_step_completed':True}
    (path/'STEP-COMPLETED.json').write_text(json.dumps(step)+'\n')
    report={'parent_retained_epochs':46,'retained_main_updates_at_resume':3,
            'parent_work':{'total_logged_main_optimizer_completions':5},'model_configuration':{'synthetic':True},
            'model_data_manifest_sha256':'d'*64,'actual_optimization_recording':{'slots':[
                {**capture,'label':'resume-first-main-microbatch','receipt':identity(path/'CAPTURE.json'),
                 'optimizer_step_completed':True,'optimizer_completion':identity(path/'STEP-COMPLETED.json')}]}}
    journal={'started_epochs':{47:{'order':order}},'completions':{4:{'new':1}}}
    args=[root,report,journal,data,{46:prior},{'source.py':'s'*64},sources,
          {'absolute_epoch_slots':[],'maximum_bytes_per_slot':8*1024**2},{'bytes':1,'sha256':'c'*64},Inputs()]
    return path,args


class RecordingLinkTests(unittest.TestCase):
    def test_bound_capture_plus_completed_step(self):
        with tempfile.TemporaryDirectory() as directory:
            _,args=make_capture(Path(directory))
            value=audit_optimization(*args)
            self.assertTrue(value['passed_recording_integrity'])
            self.assertEqual(value['unique_physical_captures'],1)
            self.assertEqual(value['valid_sample_states'],15)

    def test_missing_step_cannot_claim_completion(self):
        with tempfile.TemporaryDirectory() as directory:
            path,args=make_capture(Path(directory));(path/'STEP-COMPLETED.json').unlink()
            with self.assertRaises(ValueError): audit_optimization(*args)

    def test_false_valid_mask_or_summary_cannot_pass(self):
        for change in ('mask','summary'):
            with tempfile.TemporaryDirectory() as directory:
                path,args=make_capture(Path(directory))
                if change=='mask':
                    row=json.loads((path/'CAPTURE.json').read_bytes());row['microbatch_valid_mask_sha256']='0'*64
                    (path/'CAPTURE.json').write_text(json.dumps(row)+'\n')
                else:
                    args[1]['actual_optimization_recording']['slots'][0]['expected_valid_sample_states']=999
                with self.subTest(change=change),self.assertRaises(ValueError): audit_optimization(*args)

    def test_started_epoch_missing_capture_is_hold_even_if_producer_says_not_reached(self):
        with tempfile.TemporaryDirectory() as directory:
            path,args=make_capture(Path(directory));(path/'CAPTURE.json').unlink()
            args[1]['actual_optimization_recording']['slots']=[{'label':'resume-first-main-microbatch','status':'not_reached'}]
            value=audit_optimization(*args)
            self.assertFalse(value['passed_recording_integrity'])
            self.assertTrue(value['slots'][0]['independent_schedule_reached_from_epoch_started'])


if __name__=='__main__':
    unittest.main(verbosity=2)
