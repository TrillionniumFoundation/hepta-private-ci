# Independent C2 terminal auditor — preparation only

This program is prepared before the six real C2 attempts finish. It has not read
their active outputs or models. The original proposed plan is preserved verbatim
as `PLAN.json`; the parent subsequently approved the audit preparation limits.
Actual input binding and execution require a separate, later decision. No such
authorization or production snapshot is included in this program.

## Fixed scope and limits

The roster contains both original learning rates and all three seeds, in the
plan's order. One worker and one numerical thread use CPU FP64. A launcher bounds
the entire audit process group to 1,800 seconds and checks the controller's RSS;
each stage has a 2 GiB RSS ceiling and 8 GiB address-space ceiling. Context and
all six checkpoint/recording audits together receive at most the first 360
seconds. Each eligible full-D replay receives at most 210 seconds, clipped to
the remaining whole budget minus the internal 60-second finalization reserve.
The reserve does not guarantee archive completion. Unrun stages remain in the
roster, and all observed failed work remains charged. There is no retry.

The sole execution entry point is `launch.py`. It requires a separately signed
off local JSON authorization and an exact post-terminal binding, both supplied
with SHA256 digests. The authorization must bind this program's `MANIFEST.json`,
the preserved plan, the input binding, and the exact resource fields described
below. Merely possessing this source or passing its software tests does not
authorize reading the C2 run.

```text
python -B launch.py --authorization DECISION.json --authorization-sha SHA \
  --binding TERMINAL-BINDING.json --binding-sha SHA \
  --output NEW-EXCLUSIVE-OUTPUT --launch-directory NEW-EXCLUSIVE-LAUNCH
```

Authorization schema fields are:

```json
{
  "execution_authorized": true,
  "scope": "independent-c2-terminal-audit-only",
  "confirmation_E_access": false,
  "program_manifest_sha256": "later exact program manifest digest",
  "plan_sha256": "1fc0d941bc9d96544c8caa5740aaba130685fed74b620f6e62dc22bec4a715ad",
  "binding_sha256": "later exact post-terminal binding digest",
  "resources": {
    "whole_hard_wall_seconds": 1800,
    "metadata_soft_wall_seconds": 360,
    "per_full_D_hard_wall_seconds": 210,
    "final_reserve_seconds": 60,
    "RSS_bytes": 2147483648,
    "address_space_bytes": 8589934592,
    "workers": 1,
    "threads": 1
  }
}
```

This example is documentation, not an authorization file. The later binding
contains schema `independent-c2-terminal-binding-v1`, `all_attempts_terminal:
true`, `controller_result` as `{bytes, sha256}`, the original
`native_job_id`, `controller_pid`, `decision_path`, and
`native_terminal: {path, identity: {bytes, sha256}}`. `native_terminal.path`
must be an exact raw durable daemon terminal JSON, not a caller-written boolean
summary. The program also reads the byte-bound controller result and command
journal, requires all six original names and known terminal child PIDs, and
independently requires those PIDs and the controller PID to be absent or zombie.
Uncertain, unreadable or active process state blocks model reads. If the
controller never produces its immutable final roster, this version stays HOLD;
a later separately reviewed postmortem adapter would be required.

## Evidence checks

The audit implements its own journal reconstruction, confusion-matrix arithmetic,
strict first-maximum selection and plateau history. It does not call producer
admission decisions as an independent verdict. Checkpoints are read with
`weights_only=True`; optimizer groups, moments and ages are inspected as saved
data. No optimizer is constructed or restored, no backward pass runs, and no
optimization step occurs. The original complete boundary and actual C2
resume-start witness are compared deeply, including model configuration, tensor
bytes, optimizer state, order RNG and Torch RNG. Every committed epoch is bound
to its immutable checkpoint, predecessor commit, exact order and best policy.
Dangling files are inventoried but do not become completed epochs.

Original partial-epoch updates remain executed work. They are disclosed separately
from the logical resumed trajectory and receive no wall or CPU refund. The
original complete process wall remains charged. Exact C2 per-PID wait4 CPU and
unknown original exit CPU remain different scopes; cumulative per-fit CPU is not
invented. A one-microsecond resolution allowance is declared solely when comparing
the producer's process-CPU sample with wait4's microsecond counter. Wall and RSS
admission have no such tolerance.

The actual optimization recorder is audited from independently reconstructed
first batches and microbatches, exact bound episode lengths/dt and predecessor
model digests. Every trace line, source map, header schema, prefix digest, valid
batch index and padding count is checked. CAPTURE and STEP-COMPLETED artifacts
are linked to the actual logged update. A shared physical capture is counted once
when it satisfies two schedule labels. The audit uses `epoch_started` to detect
a reached partial epoch even if the producer summary says `not_reached` based on
completed epochs. Missing coverage remains HOLD.

Separate supplemental captures are kept in a different section. Their model,
configuration, source/data, fixed three-episode roster and recorded neutrality
receipts are bound. Neutrality remains the producer's archived assertion rather
than a new live observation. The original 120-second soft check covers the whole
three-episode slot; reported cleanup can exceed that check. Neither sparse
recording type establishes whole-trajectory numerical qualification.

Every safely bound strict-best checkpoint is eligible for one full-D replay in
the fixed order, including a checkpoint from an insufficient or failed fit.
Recording failure does not convert a stable diagnostic replay into training
credit. The replay uses the exact v8 constructor, data/runtime/source identities,
CPU FP64, full batch32, no-grad and a fresh cache. Independent metrics include all
11-class F1, accuracy, NLL, both Brier conventions and ECE. Confusion matrices must
match exactly; scalar absolute differences must not exceed 2e-12. Full fresh
logits, labels and episode/position/source-row order are saved. Missing original
selected logits in a failed fit is retained as absence, and the bound best-epoch
metrics remain the comparison target. E is never read.

## Results and admission

`PASSED_BOUND_EVIDENCE_ONLY`, `FAILED_OR_INCOMPLETE_CHAIN` and
`UNRUN_WITHIN_AUDIT_BUDGET` describe audit evidence. Fit execution status,
producer-reported adequacy, independently supported adequacy and quality
reproducibility remain separate. All six results must be available before a
descriptive common-LR mean is formed; failed seeds are never dropped. The mean
and SD describe initialization variability on reused D, not independently held
out data uncertainty. The original 300/900/1800-second curves are not modified.

An rc0 child requires its identified result, exact declared/actual budgets, all
three RSS views and matching before/after auditor source. Final source failure
revokes aggregate quality/selection admission while retaining raw values. The
launcher checks actual whole RSS, complete ZIP CRC, safe and unique member paths,
manifest coverage/member hashes and the final source-bound summary. A controller
summary inside the ZIP remains provisional until the separate launch receipt
confirms terminal completion and the archive SHA. A hard group kill keeps waited
CPU as a lower bound because unreaped stage CPU may be absent. Nested timings are
not added. Energy, VRAM and billing remain unknown.

Scientific benefit, independent E confirmation and whole-training numerical
qualification remain HOLD regardless of software-test or replay outcomes.

## Preparation validation and reused code

`REUSE.json` records exact byte copies of the prior independently checked metric,
fresh-forward and input helper code, plus its frozen source/data plan. Only helper
functions are reused; the prior replay script's old CLI is not an entry point for
this audit. No production model is loaded by imports or synthetic tests.

Run the synthetic suites from this directory:

```text
python -B -m unittest test_synthetic test_controller_closure test_recording_links -v
```

The tests use tiny manually serialized tensors, synthetic order/commit/trace
files, explicit process metadata mocks, and short non-model subprocesses. They
exercise corrupt witnesses and moments, duplicate steps, wrong strict-best
links, altered dt/batch/mask/padding/model/source data, missing artifacts, resource
overruns, all-six opportunity retention, final source failure, non-ZIP archives
and final RSS gates. The earlier failed candidate tests and independent red
examples are retained outside this immutable program, with their original source
and execution costs. Preparation testing is not a native production audit.
