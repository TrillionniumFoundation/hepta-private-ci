"""Single bounded audit stage; no input read until separately authorized."""
import os
import time
START = float(os.environ.get('HCSN_C2_AUDIT_STAGE_START', time.monotonic()))
import argparse
from pathlib import Path
import resource
import traceback

from audit_io import require, save, verify_program
from bound_io import PROGRAM, RSS, read_authorization


def main(args):
    output = Path(args.output)
    output.mkdir(exist_ok=False)
    grant = float(os.environ['HCSN_C2_AUDIT_STAGE_GRANT'])
    record = {'schema': 'independent-c2-audit-stage-v1', 'stage': args.stage, 'name': args.name,
              'status': 'failed', 'declared_wall_seconds': grant, 'declared_RSS_bytes': RSS,
              'inputs_unchanged': False, 'scientific_admission': 'HOLD', 'confirmation_E_access': False}
    def budget():
        require(0 < grant <= (360 if args.stage in ('context', 'chain') else 210), 'invalid stage grant')
        require(time.monotonic()-START <= grant, 'stage wall exceeded')
        require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024 <= RSS, 'stage self RSS exceeded')
    try:
        record['program_before'] = verify_program(PROGRAM)
        read_authorization(args.authorization, args.authorization_sha, args.binding, args.binding_sha)
        budget()
        if args.stage == 'context':
            from bound_io import context
            value = context(args.binding, args.binding_sha, output, budget)
        elif args.stage == 'chain':
            from audit_chain import run
            value = run(args.context, args.context_sha, args.name, output, budget)
        else:
            from replay_best import run
            value = run(args.context, args.context_sha, args.best, args.best_sha, output, budget)
        record.update(value)
        budget()
        record['program_after'] = verify_program(PROGRAM)
        require(record['program_before'] == record['program_after'], 'audit source changed')
    except Exception:
        record.update(status='failed', inputs_unchanged=False, error=traceback.format_exc())
    finally:
        record.update(process_wall_seconds=time.monotonic()-START, process_CPU_seconds=time.process_time(),
                      self_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
        save(output/'STAGE.json', record)
    # A complete best-chain may be eligible for diagnostic replay even if sparse
    # recording failed. The recording verdict remains separate and false.
    return 0 if record['inputs_unchanged'] and record['status'] in ('passed', 'failed_recording_chain') else 2


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('authorization', 'authorization-sha', 'binding', 'binding-sha', 'output'):
        parser.add_argument('--'+key, required=True)
    parser.add_argument('--stage', choices=('context', 'chain', 'replay'), required=True)
    parser.add_argument('--name')
    for key in ('context', 'context-sha', 'best', 'best-sha'):
        parser.add_argument('--'+key)
    raise SystemExit(main(parser.parse_args()))
