"""Whole 1800-second process-group envelope. Requires later explicit authorization."""
import time
START = time.monotonic()
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import traceback
import hashlib
from zipfile import ZipFile

from audit_io import require, save
from bound_io import PROGRAM, WHOLE, RSS, AS, ROSTER, identity, read_authorization


def verify_archive(path, program_sha, peak_rss, wall):
    require(type(peak_rss) is int and 0 <= peak_rss <= RSS and 0 <= wall <= WHOLE, 'whole RSS/wall cap exceeded')
    with ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)) and archive.testzip() is None, 'archive CRC/duplicate failure')
        require(all(not Path(n).is_absolute() and '..' not in Path(n).parts and '\\' not in n for n in names), 'unsafe archive member')
        require(all(((i.external_attr >> 16)&0o170000) != 0o120000 for i in archive.infolist()), 'archive symlink')
        manifest = json.loads(archive.read('MANIFEST.json'))['files']
        require(set(names) == set(manifest) | {'MANIFEST.json'}, 'archive manifest coverage differs')
        for name, item in manifest.items():
            raw = archive.read(name)
            require({'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} == item, 'archive member identity differs')
        summary = json.loads(archive.read('SUMMARY.json'))
        require(summary['execution_status'] == 'completed_fixed_audit_roster'
                and summary.get('program_manifest_before') == summary.get('program_manifest_after') == program_sha
                and not summary.get('final_program_error'), 'controller/source summary failed')
        require(summary['own_peak_rss_bytes'] <= RSS and summary['complete_process_wall_seconds'] <= WHOLE,
                'controller normal-exit cap violated')
        require(len(summary['entries']) == 6 and {e['name'] for e in summary['entries']} == set(ROSTER), 'archive roster incomplete')
        return {'archive': identity(path), 'summary': manifest['SUMMARY.json'], 'members': len(names),
                'CRC_members_manifest_verified': True}


def main(args):
    launch = Path(args.launch_directory)
    launch.mkdir(exist_ok=False)
    process = None
    row = {'schema': 'independent-c2-audit-launch-v1', 'process_started': False, 'status': 'started',
           'whole_hard_wall_seconds': WHOLE, 'started_utc': datetime.now(timezone.utc).isoformat(),
           'scientific_admission': 'HOLD', 'confirmation_E_access': False, 'training_steps': 0}
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    try:
        authorization = read_authorization(args.authorization, args.authorization_sha, args.binding, args.binding_sha)
        require(not Path(args.output).exists() and not Path(str(args.output)+'.zip').exists(), 'output already exists; no retry')
        argv = [sys.executable, '-B', str(PROGRAM/'run_audit.py'), '--output', args.output,
                '--authorization', args.authorization, '--authorization-sha', args.authorization_sha,
                '--binding', args.binding, '--binding-sha', args.binding_sha]
        row['argv'] = argv
        save(launch/'INTENT.json', row)
        env = dict(os.environ, HCSN_C2_AUDIT_STARTED=str(START), OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                   MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1')
        wrapper = ('import os,resource,sys;resource.setrlimit(resource.RLIMIT_AS,('
                   +str(AS)+','+str(AS)+'));os.execv(sys.argv[1],sys.argv[1:])')
        with (launch/'stdout').open('xb') as stdout, (launch/'stderr').open('xb') as stderr:
            process = subprocess.Popen([sys.executable, '-B', '-c', wrapper, *argv], env=env,
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            row.update(process_started=True, pid=process.pid)
            row['sampled_controller_peak_rss_bytes'] = 0
            killed = False
            while True:
                pid, status, waited = os.wait4(process.pid, os.WNOHANG)
                if pid:
                    process.returncode = os.waitstatus_to_exitcode(status)
                    row.update(returncode=process.returncode, exact_waited_peak_rss_bytes=waited.ru_maxrss*1024)
                    if not killed:
                        row['status'] = 'completed' if process.returncode == 0 else 'failed'
                    if process.returncode != 0:
                        try:
                            os.killpg(process.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                        row['unaccounted_orphan_stage_CPU_possible'] = True
                    break
                try:
                    lines = Path(f'/proc/{process.pid}/status').read_text().splitlines()
                    rss = [int(v.split()[1])*1024 for v in lines if v.startswith('VmRSS:')]
                    if rss:
                        row['sampled_controller_peak_rss_bytes'] = max(row['sampled_controller_peak_rss_bytes'], rss[0])
                except (FileNotFoundError, ProcessLookupError):
                    pass
                over_wall = time.monotonic()-START >= WHOLE
                over_rss = row['sampled_controller_peak_rss_bytes'] > RSS
                if (over_wall or over_rss) and not killed:
                    os.killpg(process.pid, signal.SIGKILL)
                    row.update(status='whole_budget_exhausted' if over_wall else 'controller_RSS_exhausted',
                               unaccounted_orphan_stage_CPU_possible=True)
                    killed = True
                time.sleep(.02)
        archive = Path(str(args.output)+'.zip')
        if row['status'] == 'completed':
            require(archive.is_file(), 'completed controller lacks archive')
            row.update(verify_archive(archive, authorization['program_manifest_sha256'],
                max(row['sampled_controller_peak_rss_bytes'], row['exact_waited_peak_rss_bytes']), time.monotonic()-START))
            require(time.monotonic()-START <= WHOLE, 'whole archive verification exceeded envelope')
            row['archive_finalized'] = True
    except Exception:
        row.update(status='launch_or_artifact_failed', error=traceback.format_exc())
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            row['unaccounted_orphan_stage_CPU_possible'] = True
    finally:
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        row.update(whole_wall_seconds=time.monotonic()-START, own_process_CPU_seconds=time.process_time(),
                   waited_controller_and_descendant_CPU_seconds=usage.ru_utime+usage.ru_stime-before.ru_utime-before.ru_stime,
                   CPU_is_lower_bound=row.get('unaccounted_orphan_stage_CPU_possible', False),
                   waited_peak_rss_bytes=usage.ru_maxrss*1024,
                   finished_utc=datetime.now(timezone.utc).isoformat(), energy_joules=None,
                   scope='whole controller/stage/output archive envelope; nested stage costs not additive')
        for name in ('stdout', 'stderr'):
            row[name] = identity(launch/name) if (launch/name).exists() else None
        save(launch/'RECEIPT.json', row)
        print(json.dumps(row), flush=True)
    return 0 if row['status'] == 'completed' else 2


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('authorization', 'authorization-sha', 'binding', 'binding-sha', 'output', 'launch-directory'):
        parser.add_argument('--'+key, required=True)
    raise SystemExit(main(parser.parse_args()))
