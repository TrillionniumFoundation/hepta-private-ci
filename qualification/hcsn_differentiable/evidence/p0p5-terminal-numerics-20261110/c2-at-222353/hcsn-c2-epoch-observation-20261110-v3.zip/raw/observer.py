"""One bounded read of immutable epoch nodes and small C2 status files."""
import os
import time

STARTED = time.monotonic()

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import zipfile

BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
RUN = BASE / 'c2-native-execution-20261110-c385-v1'
PROGRAM = BASE / 'c2-execution-source-v4-20261110-c385'
OUT = BASE / 'c2-epoch-observation-20261110-c385-v3'
NAMES = [f'hcsn-s{seed}-lr{lr}' for seed in (101, 211, 307) for lr in ('0.001', '0.003')]


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    OUT.mkdir(exist_ok=False)
    raw = OUT / 'raw'
    raw.mkdir()
    (raw / 'observer.py').write_bytes(Path(__file__).read_bytes())
    total, reads = 0, []

    def capture(path, name, jsonl=False):
        nonlocal total
        if not path.is_file() or path.is_symlink():
            return None
        before = path.stat()
        if before.st_size > 2 * 1024**2 or total + before.st_size > 32 * 1024**2:
            raise ValueError('small-observation byte bound exceeded')
        data = path.read_bytes()
        after = path.stat()
        total += len(data)
        target = raw / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(data)
        stable = (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino)
        entry = {'original': str(path), 'copy': name, **identity(data), 'same_stat_during_read': stable,
            'observed_utc': datetime.now(timezone.utc).isoformat()}
        reads.append(entry)
        try:
            value = [json.loads(line) for line in data.splitlines()] if jsonl else json.loads(data)
        except ValueError:
            entry['status'] = 'incomplete_live_write_at_observation'
            return None
        entry['status'] = 'stable_byte_snapshot' if stable else 'changed_during_read'
        return value if stable else None

    source_before = (PROGRAM / 'PROGRAM-MANIFEST.json').read_bytes()
    if identity(source_before)['sha256'] != '322eb8f76cce589ba44ed66eff822f7b497e6507106a1ad56a65bdc8c83f7f57':
        raise ValueError('unexpected C2 source manifest')
    report = {'schema': 'hcsn-c2-one-epoch-node-observation-v3',
        'started_utc': datetime.now(timezone.utc).isoformat(), 'reads': reads, 'fits': [],
        'source_manifest': identity(source_before), 'model_loads_forward_backward_optimizer_steps': 0,
        'probability_trace_arrays_read': False, 'original_directories_written': False,
        'scientific_admission': 'HOLD', 'numerical_admission': 'HOLD', 'live_observation_not_independent_terminal_audit': True}
    commands = capture(RUN / 'commands.jsonl', 'controller/commands.jsonl', jsonl=True)
    latest = {row['name']: row for row in commands or []}
    controller_terminal = capture(RUN / 'RESULT.json', 'controller/RESULT.json')
    report['controller_terminal_observed'] = controller_terminal is not None
    for name in NAMES:
        fit = RUN / 'fits' / name
        row = {'name': name, 'dispatch': latest.get(name), 'complete_epochs': []}
        pid = (row['dispatch'] or {}).get('pid')
        row['pid_exists_at_observation'] = Path('/proc/' + str(pid)).exists() if isinstance(pid, int) else None
        paths = sorted((fit / 'commits').glob('epoch-*.json'))
        if len(paths) > 200:
            raise ValueError('unexpected complete epoch roster')
        for path in paths:
            commit = capture(path, name + '/commits/' + path.name)
            if commit is not None:
                row['complete_epochs'].append({'original': str(path), 'identity': {key: reads[-1][key] for key in ('bytes', 'sha256')},
                    'epoch': commit['epoch'], 'stopping': commit['stopping'],
                    'checkpoint': commit['checkpoint'], 'previous_commit': commit['previous_commit']})
        events = capture(fit / 'events.jsonl', name + '/events.jsonl', jsonl=True)
        if events:
            done = [event for event in events if event.get('kind') == 'optimizer_completed']
            row['optimizer_completions_observed'] = len(done)
            row['latest_optimizer_completion'] = done[-1] if done else None
            row['last_event_kind'] = events[-1].get('kind')
        terminal = capture(fit / 'result.json', name + '/result.json')
        outer = capture(RUN / 'attempts' / name / 'RESULT.json', name + '/outer-RESULT.json')
        row['fit_terminal_report_observed'] = terminal is not None
        row['outer_terminal_record_observed'] = outer is not None
        row['outer_terminal_record'] = outer
        if terminal:
            row['terminal'] = {key: terminal.get(key) for key in ('status', 'stop_reason', 'best_epoch',
                'cumulative_epochs_completed', 'new_main_updates', 'training_adequacy_established',
                'last_checkpoint_sha256', 'best_checkpoint_sha256', 'selected_development',
                'source_and_parent_inputs_unchanged', 'common_and_physical_weights_unchanged')}
        report['fits'].append(row)
    report['source_manifest_unchanged'] = source_before == (PROGRAM / 'PROGRAM-MANIFEST.json').read_bytes()
    report.update(observed_bytes=total, wall_seconds=time.monotonic() - STARTED,
        cpu_seconds=time.process_time(), peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024)
    write(OUT / 'SUMMARY.json', report)
    manifest = {str(path.relative_to(OUT)): identity(path.read_bytes()) for path in sorted(raw.rglob('*')) if path.is_file()}
    manifest['SUMMARY.json'] = identity((OUT / 'SUMMARY.json').read_bytes())
    write(OUT / 'MANIFEST.json', manifest)
    archive = OUT / 'hcsn-c2-epoch-observation-20261110-v3.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name in sorted(manifest):
            zipped.write(OUT / name, name)
        zipped.write(OUT / 'MANIFEST.json', 'MANIFEST.json')
    with zipfile.ZipFile(archive) as zipped:
        if zipped.testzip() is not None:
            raise ValueError('observation CRC failed')
        for name, item in manifest.items():
            if identity(zipped.read(name)) != item:
                raise ValueError('member byte identity changed')
    result = {'schema': 'hcsn-c2-one-epoch-observation-archive-v3',
        'status': 'read_only_observation_completed', 'archive': {'path': str(archive), **identity(archive.read_bytes())},
        'summary': identity((OUT / 'SUMMARY.json').read_bytes()),
        'whole_script_wall_seconds': time.monotonic() - STARTED, 'whole_script_cpu_seconds': time.process_time(),
        'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        'fits': [{'name': row['name'], 'latest_complete_epoch': row['complete_epochs'][-1]['epoch']['epoch'] if row['complete_epochs'] else None,
            'latest_stopping': row['complete_epochs'][-1]['stopping'] if row['complete_epochs'] else None,
            'new_optimizer_completions_observed': row.get('optimizer_completions_observed'),
            'terminal_status': (row.get('terminal') or {}).get('status'),
            'stop_reason': (row.get('terminal') or {}).get('stop_reason'),
            'pid_exists': row['pid_exists_at_observation']} for row in report['fits']]}
    write(OUT / 'RESULT.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
