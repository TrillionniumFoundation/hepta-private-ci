"""One bounded delta read, linked to a complete prior metadata snapshot."""
import os
import time

STARTED = time.monotonic()

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import zipfile

BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
RUN = BASE / 'c2-native-execution-20261110-c385-v1'
PROGRAM = BASE / 'c2-execution-source-v4-20261110-c385'
OUT = BASE / 'c2-epoch-observation-20261110-c385-v4'
PARENT = BASE / 'c2-epoch-observation-20261110-c385-v3'
PARENT_SUMMARY_SHA = '4b23893083c3cac51343dd1cd9dd23ca4a3f5f18f0f1dd31d7cc3cd83f890a17'
PARENT_ZIP_SHA = '8a52c3e6ebdfa289c348c726e8b4383b277bc81e912462c1c237515eca48cded'
NAMES = [f'hcsn-s{seed}-lr{lr}' for seed in (101, 211, 307) for lr in ('0.001', '0.003')]


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    OUT.mkdir(exist_ok=False)
    raw = OUT / 'raw'
    raw.mkdir()
    (raw / 'observer.py').write_bytes(Path(__file__).read_bytes())
    parent_raw = (PARENT / 'SUMMARY.json').read_bytes()
    if identity(parent_raw)['sha256'] != PARENT_SUMMARY_SHA:
        raise ValueError('parent snapshot identity differs')
    parent = json.loads(parent_raw)
    prior_fits = {row['name']: row for row in parent['fits']}
    if set(prior_fits) != set(NAMES):
        raise ValueError('parent roster differs')
    parent_reads = {row['original']: row for row in parent['reads']}
    parent_reference = {'summary_path': str(PARENT / 'SUMMARY.json'), **identity(parent_raw),
        'archive_path': str(PARENT / 'hcsn-c2-epoch-observation-20261110-v3.zip'),
        'archive_sha256': PARENT_ZIP_SHA,
        'scope': 'New complete epoch nodes after this parent only; old raw prefix remains in the source-bound parent archive.'}
    write(raw / 'PARENT-REFERENCE.json', parent_reference)
    total, reads = len(parent_raw), []

    def capture(path, name, jsonl=False):
        nonlocal total
        if not path.is_file() or path.is_symlink():
            return None
        before = path.stat()
        if before.st_size > 2 * 1024**2 or total + before.st_size > 32 * 1024**2:
            raise ValueError('small-observation byte bound exceeded')
        data = path.read_bytes()
        after = path.stat()
        total += len(data)
        target = raw / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(data)
        stable = (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino)
        entry = {'original': str(path), 'copy': name, **identity(data), 'same_stat_during_read': stable,
            'observed_utc': datetime.now(timezone.utc).isoformat()}
        reads.append(entry)
        try:
            value = [json.loads(line) for line in data.splitlines()] if jsonl else json.loads(data)
        except ValueError:
            entry['status'] = 'incomplete_live_write_at_observation'
            return None
        entry['status'] = 'stable_byte_snapshot' if stable else 'changed_during_read'
        return value if stable else None

    source_before = (PROGRAM / 'PROGRAM-MANIFEST.json').read_bytes()
    if identity(source_before)['sha256'] != '322eb8f76cce589ba44ed66eff822f7b497e6507106a1ad56a65bdc8c83f7f57':
        raise ValueError('unexpected C2 source manifest')
    report = {'schema': 'hcsn-c2-delta-epoch-node-observation-v4',
        'started_utc': datetime.now(timezone.utc).isoformat(), 'reads': reads, 'fits': [],
        'source_manifest': identity(source_before), 'parent_snapshot': parent_reference,
        'complete_epoch_node_scope': 'delta after parent; complete prefix is retained in parent archive',
        'model_loads_forward_backward_optimizer_steps': 0,
        'probability_trace_arrays_read': False, 'original_directories_written': False,
        'scientific_admission': 'HOLD', 'numerical_admission': 'HOLD', 'live_observation_not_independent_terminal_audit': True}
    commands = capture(RUN / 'commands.jsonl', 'controller/commands.jsonl', jsonl=True)
    latest = {row['name']: row for row in commands or []}
    controller_terminal = capture(RUN / 'RESULT.json', 'controller/RESULT.json')
    report['controller_terminal_observed'] = controller_terminal is not None
    for name in NAMES:
        fit = RUN / 'fits' / name
        prior = prior_fits[name]
        prefix_last = prior['complete_epochs'][-1]
        cutoff = prefix_last['epoch']['epoch']
        row = {'name': name, 'dispatch': latest.get(name), 'complete_epochs': [],
            'parent_complete_epoch_cutoff': cutoff, 'parent_last_epoch_node': prefix_last}
        pid = (row['dispatch'] or {}).get('pid')
        row['pid_exists_at_observation'] = Path('/proc/' + str(pid)).exists() if isinstance(pid, int) else None
        paths = sorted((fit / 'commits').glob('epoch-*.json'))
        if len(paths) > 200:
            raise ValueError('unexpected complete epoch roster')
        if paths and int(paths[-1].stem.split('-')[-1]) < cutoff:
            raise ValueError('native commit roster regressed behind immutable parent')
        paths = [path for path in paths if int(path.stem.split('-')[-1]) > cutoff]
        for path in paths:
            commit = capture(path, name + '/commits/' + path.name)
            if commit is not None:
                row['complete_epochs'].append({'original': str(path), 'identity': {key: reads[-1][key] for key in ('bytes', 'sha256')},
                    'epoch': commit['epoch'], 'stopping': commit['stopping'],
                    'checkpoint': commit['checkpoint'], 'previous_commit': commit['previous_commit']})
        events = capture(fit / 'events.jsonl', name + '/events.jsonl', jsonl=True)
        if events:
            done = [event for event in events if event.get('kind') == 'optimizer_completed']
            row['optimizer_completions_observed'] = len(done)
            row['latest_optimizer_completion'] = done[-1] if done else None
            row['last_event_kind'] = events[-1].get('kind')
        if prior['fit_terminal_report_observed'] and prior['outer_terminal_record_observed']:
            terminal_refs = []
            for path in (fit / 'result.json', RUN / 'attempts' / name / 'RESULT.json'):
                expected = parent_reads[str(path)]
                observed = identity(path.read_bytes())
                total += observed['bytes']
                if observed != {key: expected[key] for key in ('bytes', 'sha256')}:
                    raise ValueError('previously closed terminal metadata changed')
                terminal_refs.append({'original': str(path), **observed, 'raw_bytes_retained_in_parent_archive': True})
            terminal, outer = prior['terminal'], prior['outer_terminal_record']
            row['prior_terminal_identity_reverified'] = terminal_refs
        else:
            terminal = capture(fit / 'result.json', name + '/result.json')
            outer = capture(RUN / 'attempts' / name / 'RESULT.json', name + '/outer-RESULT.json')
        row['fit_terminal_report_observed'] = terminal is not None
        row['outer_terminal_record_observed'] = outer is not None
        row['outer_terminal_record'] = outer
        if terminal:
            row['terminal'] = {key: terminal.get(key) for key in ('status', 'stop_reason', 'best_epoch',
                'cumulative_epochs_completed', 'new_main_updates', 'training_adequacy_established',
                'last_checkpoint_sha256', 'best_checkpoint_sha256', 'selected_development',
                'source_and_parent_inputs_unchanged', 'common_and_physical_weights_unchanged')}
        row['latest_complete_epoch_record'] = row['complete_epochs'][-1] if row['complete_epochs'] else prefix_last
        report['fits'].append(row)
    report['source_manifest_unchanged'] = source_before == (PROGRAM / 'PROGRAM-MANIFEST.json').read_bytes()
    report['parent_snapshot_unchanged'] = parent_raw == (PARENT / 'SUMMARY.json').read_bytes()
    if not report['parent_snapshot_unchanged']:
        raise ValueError('parent snapshot changed during observation')
    report.update(observed_bytes=total, wall_seconds=time.monotonic() - STARTED,
        cpu_seconds=time.process_time(), peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024)
    write(OUT / 'SUMMARY.json', report)
    manifest = {str(path.relative_to(OUT)): identity(path.read_bytes()) for path in sorted(raw.rglob('*')) if path.is_file()}
    manifest['SUMMARY.json'] = identity((OUT / 'SUMMARY.json').read_bytes())
    write(OUT / 'MANIFEST.json', manifest)
    archive = OUT / 'hcsn-c2-epoch-observation-20261110-v4.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name in sorted(manifest):
            zipped.write(OUT / name, name)
        zipped.write(OUT / 'MANIFEST.json', 'MANIFEST.json')
    with zipfile.ZipFile(archive) as zipped:
        if zipped.testzip() is not None:
            raise ValueError('observation CRC failed')
        for name, item in manifest.items():
            if identity(zipped.read(name)) != item:
                raise ValueError('member byte identity changed')
    result = {'schema': 'hcsn-c2-delta-epoch-observation-archive-v4',
        'status': 'read_only_observation_completed', 'archive': {'path': str(archive), **identity(archive.read_bytes())},
        'summary': identity((OUT / 'SUMMARY.json').read_bytes()),
        'whole_script_wall_seconds': time.monotonic() - STARTED, 'whole_script_cpu_seconds': time.process_time(),
        'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        'fits': [{'name': row['name'], 'latest_complete_epoch': row['latest_complete_epoch_record']['epoch']['epoch'],
            'latest_stopping': row['latest_complete_epoch_record']['stopping'],
            'new_optimizer_completions_observed': row.get('optimizer_completions_observed'),
            'terminal_status': (row.get('terminal') or {}).get('status'),
            'stop_reason': (row.get('terminal') or {}).get('stop_reason'),
            'pid_exists': row['pid_exists_at_observation']} for row in report['fits']]}
    write(OUT / 'RESULT.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
