import base64,hashlib,json,os,sys
from pathlib import Path
payload=json.load(sys.stdin)
expected_source='8409832f5c6561075634fc86cae060fc9c3212c4098679fb00b9d38dbc181cc3'
expected_plan='6dee938a4031a320137da5ccbf82835f2ad6a17a5cbc604df5f7b63ceb64fbbb'
assert payload['uploader_source']['sha256']==expected_source and payload['plan']['sha256']==expected_plan
root=Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training/terminal-numerics-draft-uploader-program-v1')
root.mkdir(exist_ok=False)
for item in [payload['uploader_source'],payload['plan']]+payload['extra_files']:
 name=item['name']; assert Path(name).name==name
 data=base64.b64decode(item['data_base64'],validate=True)
 assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
 with (root/name).open('xb') as stream: stream.write(data)
print(json.dumps({'state':'prepared_for_single_uploader_exec','source_sha256':expected_source,'plan_sha256':expected_plan,'key':'hcsn-terminal-numerics-draft-upload-c385-v1'}),flush=True)
os.execv(sys.executable,[sys.executable,'-B',str(root/'uploader.py'),'--plan',str(root/'PLAN.json'),'--plan-sha256',expected_plan])
