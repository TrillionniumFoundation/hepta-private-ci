"""Archive the completed uploader's raw logs; never modify or reupload assets."""
import hashlib
import json
from pathlib import Path
import resource
import time
from datetime import datetime, timezone
from zipfile import ZipFile, ZIP_DEFLATED

STARTED, CPU = time.monotonic(), time.process_time()
BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
UPLOADER = BASE / 'terminal-numerics-draft-upload-v1'
PROGRAM = BASE / 'terminal-numerics-draft-uploader-program-v1'
INVENTORY = BASE / 'terminal-numerics-draft-input-inventory-v1'
OUT = BASE / 'terminal-numerics-upload-control-archive-v1'


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main():
    OUT.mkdir(exist_ok=False)
    terminal = (UPLOADER / 'RESULT.json').read_bytes()
    assert identity(terminal) == {'bytes': 15937, 'sha256': '7a76efd2467e897c19c15bfabc044242c786a0719a364b86dce7a64fab0ad07d'}
    result = json.loads(terminal)
    assert result['status'] == 'both_assets_authenticated_verified_draft_unchanged'
    assert len(result['assets']) == 2 and all(a['authenticated_full_readback_verified'] for a in result['assets'])
    paths = []
    for prefix, root in [('uploader', UPLOADER), ('program', PROGRAM), ('input-inventory', INVENTORY)]:
        for path in sorted(root.rglob('*')):
            assert not path.is_symlink()
            if not path.is_file():
                continue
            relative = path.relative_to(root)
            if prefix == 'uploader' and ('authenticated-readback' in relative.parts or path.suffix == '.zip'):
                continue
            paths.append((prefix + '/' + str(relative), path))
    paths += [('outer/uploader-GNU-TIME.txt', BASE / 'terminal-numerics-draft-upload-v1.time.txt'),
              ('outer/inventory-GNU-TIME.txt', BASE / 'terminal-numerics-draft-input-inventory-v1.time.txt'),
              ('archive-program.py', Path(__file__))]
    assert len(paths) <= 200 and sum(p.stat().st_size for _, p in paths) <= 16 * 1024**2
    raw = {name: p.read_bytes() for name, p in paths}
    manifest = {name: {'original_path': str(p), **identity(raw[name])} for name, p in paths}
    (OUT / 'MANIFEST.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    archive = OUT / 'hcsn-terminal-numerics-upload-control-20261110-v1.zip'
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zipped:
        for name in sorted(raw):
            zipped.writestr(name, raw[name])
        zipped.write(OUT / 'MANIFEST.json', 'MANIFEST.json')
    with ZipFile(archive) as zipped:
        assert zipped.testzip() is None and len(zipped.namelist()) == len(manifest) + 1
        for name, item in manifest.items():
            assert identity(zipped.read(name)) == {k: item[k] for k in ('bytes', 'sha256')}
    assert all(p.read_bytes() == raw[name] for name, p in paths)
    receipt = {'schema': 'terminal-numerics-upload-control-archive-v1', 'status': 'completed_read_only_archive',
               'archive': {'path': str(archive), **identity(archive.read_bytes())},
               'members_including_manifest': len(manifest) + 1, 'original_inputs_unchanged': True,
               'models_loaded': 0, 'new_uploads': 0, 'main_asset_repacked': False,
               'whole_script_wall_sample_seconds': time.monotonic() - STARTED,
               'whole_script_CPU_sample_seconds': time.process_time() - CPU,
               'peak_RSS_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
               'finished_utc': datetime.now(timezone.utc).isoformat(),
               'cost_scope': 'Separate metadata/log-only archive job; GNU complete process includes imports. Earlier uploader and inventory costs are not included.'}
    (OUT / 'RESULT.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
