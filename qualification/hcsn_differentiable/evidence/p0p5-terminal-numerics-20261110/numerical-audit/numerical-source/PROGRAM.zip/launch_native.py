"""Hard whole-attempt deadline including imports, stages and serialization."""

import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time
import traceback

from terminal_inputs import read, require, save, sha


def run_controller(argv, launch_dir, ceiling):
    launch_dir=Path(launch_dir);launch_dir.mkdir(parents=True,exist_ok=False)
    require(0<ceiling<=10800,'whole-attempt wall ceiling cannot be increased')
    started=time.monotonic();usage0=resource.getrusage(resource.RUSAGE_CHILDREN)
    env=dict(os.environ,HCSN_AUDIT_PROCESS_STARTED=str(started),OMP_NUM_THREADS='1',
             MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1')
    row={'schema':'terminal-HCSN-hard-deadline-launch-v1','started_utc':datetime.now(timezone.utc).isoformat(),
         'argv':argv,'hard_whole_wall_seconds':ceiling,'process_started':False,
         'scope':'Complete controller process and its inherited stage process group; child timers are nested, not additional.'}
    save(launch_dir/'launch.json',row)
    process=None
    try:
        with (launch_dir/'stdout').open('xb') as stdout,(launch_dir/'stderr').open('xb') as stderr:
            process=subprocess.Popen(argv,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
            row.update(process_started=True,pid=process.pid)
            try:
                process.wait(timeout=max(.001,ceiling-(time.monotonic()-started)))
                row.update(status='completed' if process.returncode==0 else 'failed',returncode=process.returncode)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL);process.wait()
                row.update(status='whole_budget_exhausted',returncode=process.returncode,
                           stop_cause='predeclared_hard10800_whole_process_group_limit')
    except Exception:
        row.update(status='launch_or_monitor_failed',error=traceback.format_exc(),returncode=None)
        if process is not None and process.poll() is None:
            os.killpg(process.pid,signal.SIGKILL);process.wait()
            row['returncode']=process.returncode
    usage=resource.getrusage(resource.RUSAGE_CHILDREN)
    row.update(whole_process_wall_seconds=time.monotonic()-started,
               waited_controller_and_descendant_CPU_seconds=usage.ru_utime+usage.ru_stime-usage0.ru_utime-usage0.ru_stime,
               child_peak_rss_bytes=usage.ru_maxrss*1024,finished_utc=datetime.now(timezone.utc).isoformat(),energy_joules=None)
    for stream in ('stdout','stderr'):
        p=launch_dir/stream;row[stream]={'bytes':p.stat().st_size,'sha256':sha(p)} if p.exists() else {'missing':True}
    save(launch_dir/'receipt.json',row)
    return row


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--launch-dir',type=Path,required=True)
    parser.add_argument('--terminal-snapshot',type=Path,required=True)
    parser.add_argument('--terminal-snapshot-sha256',required=True)
    args=parser.parse_args()
    program=Path(__file__).parent
    for name,item in read(program/'MANIFEST.json')['files'].items():
        require(sha(program/name)==item['sha256'],'frozen auditor source capsule differs')
    require(not args.output.exists(),'new audit output must be absent')
    argv=[sys.executable,'-B',str(program/'run_audit.py'),'--base',str(args.base),'--output',str(args.output),
          '--terminal-snapshot',str(args.terminal_snapshot),'--terminal-snapshot-sha256',args.terminal_snapshot_sha256]
    row=run_controller(argv,args.launch_dir,10800)
    print(row,flush=True)
    return 0 if row['status']=='completed' else 1


if __name__=='__main__':
    raise SystemExit(main())
