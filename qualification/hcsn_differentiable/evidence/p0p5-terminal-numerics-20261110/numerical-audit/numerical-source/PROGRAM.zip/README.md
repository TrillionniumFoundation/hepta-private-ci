# Terminal HCSN bounded numerical auditor v1

This separately frozen executor consumes PLAN SHA256
`6ae8bb984d994f0d3fa6963e37d0f4180366a3a7bafd316d887e74f2ef1c7d26`.
No real model was loaded to choose the implementation, tests, query rules or
stage order. The original terminal handoff is separately SHA-bound.

## Eligibility and checkpoint meaning

The original command journal must show one launch and one terminal row, agreeing
with the retained handoff before any fit directory is opened. Complete original
artifact hashes, source/dependency bytes, data identity, construction derived
independently from the fit plan, checkpoint counters, optimizer state and sample
order RNG are checked. A terminal soft-budget report may be audited without
claiming training adequacy. Actual elapsed wall and peak RSS are both retained to
identify the observed budget trigger. A hard kill or missing result is HOLD.

Every candidate uses its first strict D-best complete epoch, and its last complete
epoch as a separate diagnostic. `last.pt` does not claim to include later partial
epoch updates. Those extra terminal updates are counted explicitly. `interrupted.pt`
is not substituted. No source, checkpoint, original trace, footer or training
classification is modified, and no optimizer step is executed.

Torch RNG validation proves that the saved state is loadable, not that the full
historical random trajectory was replayed. Sample-order RNG is independently
advanced from its seed through exactly the checkpoint's complete epoch count.
Supplemental exports also require the actually loaded model-module paths/hashes
and Torch version to match the original trainer; checking old files still exist
would not suffice. NumPy/mpmath versions are separately reported for each stage.

The original training trace is audited only as its unchanged first16 retained
vector rows. Its truncation, retained/seen counts, source match and audit status
are surfaced in the small summary. Supplemental fixed-model evaluations remain
separate and cannot repair its missing historical/content coverage.

## Fixed numerical and execution details

Best-checkpoint pressure sentinels must contain all three predeclared states;
last-checkpoint pressure is explicitly not applicable. Artificial infinite-repeat
failures do not erase finite-schedule results and are never hidden by an empty
list passing `all()`.

The log-risk distance set includes the largest nonzero **finite active cell**
center. If tail mass is positive, an additional `L + 1 / tail_rate` representative
is included; it is not the maximum support of an infinite tail. The fixed finite
difference half-step is `2^-20 * max(abs(theta), 1e-8)`. Exact representable low/high
values are retained. AD is checked against80-digit differentiation and80-digit
central differences at those fixed points. Direct FP64 finite differences are
reported independently with a predeclared ULP-based resolution estimate. An
unresolved difference is labelled inconclusive; a resolved disagreement fails the
primary log-risk check. No step is adapted after seeing errors.

Both the declared scaled2e-9 basis-gradient threshold and the existing P1
absolute2e-9 guard are applied. The latter is an explicitly additional conservative
guard, not a reinterpretation of the PLAN's scaled field. The finite value/count
gate remains `abs(error)/max(1,abs(reference)) <= .01`; absolute and relative errors
are also retained. The8/16 quadrature difference is sensitivity, not a proof bound.

The96 fixed stages for six eligible candidates are: all export-best, all
export-last, all original-prefix, all domain-best, all domain-last, all log-risk;
then each of nine best finite fixtures across the six-candidate roster in fixed
order; then all six last burst8 fixtures. Each finite fixture is one900-second
stage. Stage failures are not retried or used to drop candidates.

The hard launcher grants10800 seconds to the entire controller process group,
including imports, stage work, result serialization and archive generation.
Stages inherit that group. The per-stage monitor also enforces the remaining
whole budget,900-second stage cap,2GiB sampled RSS cap and8GiB address-space cap.
A completed child's reported high-water RSS above2GiB also fails its resource
gate. Sampled RSS and the child high-water sample before serialization are not
mislabelled as exact per-child exit RSS. Every start, failure, missing/corrupt
artifact, raw log and observed cost is retained. Nested timers are not added.

Numerical pass flags are raw values unless their explicit source/identity gate
also passes. Whole-training-domain and scientific admission remain HOLD. D best
scores from original epoch records are labelled as such; this executor does not
silently claim an independent full-D logits recomputation or choose a common LR
from uncertified metrics.

## Validation

Tests use synthetic metadata and a tiny HCSN fixture, with no scientific training
credit or real optimizer step. They cover live/hard-kill rejection, censored
eligibility without adequacy, strict-best and complete-epoch counters, source/data
binding, preserved future gaps and actual wrapper laws, reference stages, failed
launches, missing/malformed artifacts and stage/whole-process resource limits.
`VALIDATION.json` binds the precise tested source and retains complete raw logs.

Native launch uses the existing original trainer's Python environment. The
program capsule is verified against its manifest before invoking `launch_native.py`.
The original failed-v1/C1 clock review and its costs remain separate earlier
evidence; this numerical executor does not rewrite them.
