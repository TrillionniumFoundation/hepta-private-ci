"""Frozen-step log-risk diagnostics at actual terminal model parameter values."""

import math
from pathlib import Path
import statistics

import mpmath as mp
import torch

from export_checkpoint import bind_runtime
from numerical_stages import load_export
from terminal_inputs import require, sha


def representable_fd_points(value):
    h = 2.0**-20 * max(abs(value),1e-8)
    low, high = float(value-h), float(value+h)
    require(math.isfinite(low) and math.isfinite(high) and low < value < high,
            'fixed finite difference step is not representable')
    return low, high


def log_risk_stage(receipt, plan, out):
    bind_runtime(receipt['source'])
    from qualification.hcsn_differentiable.operator import _first_hit_logprob, _first_hit
    from qualification.hcsn_differentiable.training_domain import read_trace
    from reference_logrisk import reference
    report=load_export(out,'best')
    params=report['physical_parameters']
    grid=plan['expected_construction']['grid']
    gaps=[]; largest=-1; tail=False
    for exported in report['traces']:
        path=Path(out)/exported['trace']
        require(sha(path)==exported['trace_sha256'],'logrisk trace identity differs')
        _,visits,_,_=read_trace(path)
        for visit in visits:
            gaps += [d for d in visit['dt'] if d>0]
            for posterior in visit['posterior']:
                indices=[i for i,p in enumerate(posterior[:grid['active_cells']]) if p>0]
                if indices: largest=max(largest,max(indices))
                tail |= posterior[grid['active_cells']]>0
    require(bool(gaps) and largest>=0,'no positive-time active support exists')
    width=grid['endpoint']/grid['active_cells']
    distances=[width/2,math.log(params['absolute_reset'])-params['log_boundary'],
               grid['endpoint'],(largest+.5)*width]
    if tail:
        distances.append(grid['endpoint']+1/grid['tail_rate'])
    points=[]
    with mp.workdps(80):
        for x in sorted(set(distances)):
            for dt in sorted(set((min(gaps),statistics.median(gaps),max(gaps)))):
                for discount in (None,params['discount']):
                    raw=(x,dt,params['mu'],params['sigma'])
                    if discount is not None: raw=(*raw,discount)
                    tensors=[torch.tensor(v,dtype=torch.float64,requires_grad=True) for v in raw]
                    actual=_first_hit_logprob(*tensors)
                    expected=reference(*raw)
                    derivatives=torch.autograd.grad(actual,tensors)
                    checks=[]
                    for index,derivative in enumerate(derivatives):
                        args=[mp.mpf(v) for v in raw]
                        def changed(value):
                            changed=list(args);changed[index]=value
                            return reference(*changed)
                        exact=mp.diff(changed,args[index])
                        low,high=representable_fd_points(raw[index])
                        fd=(changed(mp.mpf(high))-changed(mp.mpf(low)))/(mp.mpf(high)-mp.mpf(low))
                        lo,hi=list(raw),list(raw);lo[index]=low;hi[index]=high
                        left=float(_first_hit_logprob(*(torch.tensor(v,dtype=torch.float64) for v in lo)))
                        right=float(_first_hit_logprob(*(torch.tensor(v,dtype=torch.float64) for v in hi)))
                        ordinary=(right-left)/(high-low)
                        scale=max(1,abs(float(exact)))
                        ad_error=abs(float(derivative)-float(exact))/scale
                        reference_fd_error=abs(float(fd)-float(exact))/scale
                        fd_error=abs(ordinary-float(exact))/scale
                        rounding=4*(math.ulp(left)+math.ulp(right))/(high-low)/scale
                        resolved=rounding<=3e-10
                        disposition=('passed_at_declared_resolution' if fd_error<=3e-10 else 'disagrees_above_resolution') if resolved else 'roundoff_limited_not_a_FD_pass'
                        checks.append({'parameter_index':index,'AD':float(derivative),'reference_derivative':float(exact),
                            'AD_scaled_error':ad_error,'representable_low':low,'representable_high':high,
                            'reference_FD':float(fd),'reference_FD_scaled_error':reference_fd_error,
                            'FP64_FD':ordinary,'FP64_FD_scaled_error':fd_error,
                            'FP64_FD_roundoff_resolution_estimate':rounding,'FP64_FD_disposition':disposition,
                            'primary_derivative_passed':ad_error<=3e-10 and reference_fd_error<=3e-10 and disposition!='disagrees_above_resolution'})
                    log_error=abs(float(actual.detach())-float(expected))
                    probability=float(torch.exp(actual.detach()))
                    high_precision_probability=mp.exp(expected)
                    relative=float(abs(mp.mpf(probability)-high_precision_probability)/high_precision_probability)
                    points.append({'inputs':raw,'log_probability':float(actual.detach()),'reference_log_probability':float(expected),
                        'log_absolute_error':log_error,'probability':probability,
                        'probability_absolute_error':float(abs(mp.mpf(probability)-high_precision_probability)),
                        'probability_relative_error':relative,'probability_underflow':probability==0,
                        'derivatives':checks,'primary_passed':log_error<=3e-10+5e-13*abs(float(expected)) and all(c['primary_derivative_passed'] for c in checks)})
    zero_x=torch.tensor(distances[0],dtype=torch.float64,requires_grad=True)
    zero=_first_hit(zero_x,zero_x.new_tensor(0.),zero_x.new_tensor(params['mu']),zero_x.new_tensor(params['sigma']))
    zero_log=_first_hit_logprob(zero_x,zero_x.new_tensor(0.),zero_x.new_tensor(params['mu']),zero_x.new_tensor(params['sigma']))
    zero_gradient=float(torch.autograd.grad(zero,zero_x)[0])
    zero_ok=float(zero)==0 and bool(torch.isneginf(zero_log)) and zero_gradient==0
    dispositions=[d['FP64_FD_disposition'] for p in points for d in p['derivatives']]
    return {'execution_status':'completed_logrisk','primary_passed':all(p['primary_passed'] for p in points) and zero_ok,
            'direct_FD_all_resolved_pass':'disagrees_above_resolution' not in dispositions,
            'direct_FD_inconclusive_count':dispositions.count('roundoff_limited_not_a_FD_pass'),
            'direct_FD_resolved_disagreement_count':dispositions.count('disagrees_above_resolution'),
            'queries':points,'physical_parameters':params,'query_gaps':sorted(set((min(gaps),statistics.median(gaps),max(gaps)))),
            'distances':sorted(set(distances)),'largest_nonzero_finite_cell':largest,
            'tail_representative_included':tail,'tail_scope':'Optional L+1/tail_rate is a representative distance, not the largest infinite-tail support or a relative-tail guarantee.',
            'fixed_FD_step':'2^-20 * max(abs(theta),1e-8); exact representable low/high retained; no adaptive retry.',
            'FP64_FD_scope':'Direct float64 finite differences and their predeclared rounding-resolution estimate are separately reported; unresolved cases are not passes.',
            'zero_deadline_probability':float(zero),'zero_deadline_log_probability':'-Infinity',
            'zero_deadline_probability_x_gradient':zero_gradient,'zero_deadline_passed':zero_ok,
            'whole_training_domain_admission':'HOLD'}
