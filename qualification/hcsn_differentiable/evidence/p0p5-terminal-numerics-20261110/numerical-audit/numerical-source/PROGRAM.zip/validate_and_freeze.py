"""Retain precise source, raw validation and full child costs, then freeze once."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import sys
import time
from zipfile import ZipFile, ZIP_DEFLATED

from terminal_inputs import save, sha, require


def main():
    root=Path(__file__).parent;started=time.monotonic()
    out=root/'validation';out.mkdir(exist_ok=False)
    before={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',CUDA_VISIBLE_DEVICES='')
    commands=[('tests',[sys.executable,'-B','-m','unittest','discover','-s',str(root),'-p','test_*.py','-v'],0,23),
              ('help',[sys.executable,'-B',str(root/'run_audit.py'),'--help'],0,None),
              ('disabled_assertions',[sys.executable,'-B','-O',str(root/'run_audit.py'),'--help'],1,None)]
    executions=[]
    for name,argv,expected,count in commands:
        clock=time.monotonic();usage0=resource.getrusage(resource.RUSAGE_CHILDREN)
        with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
            proc=subprocess.run(argv,env=env,stdout=stdout,stderr=stderr,timeout=90,check=False)
        usage=resource.getrusage(resource.RUSAGE_CHILDREN)
        row={'name':name,'argv':argv,'returncode':proc.returncode,'expected_returncode':expected,
             'whole_child_wall_seconds':time.monotonic()-clock,
             'waited_child_CPU_seconds':usage.ru_utime+usage.ru_stime-usage0.ru_utime-usage0.ru_stime,
             'stdout_sha256':sha(out/(name+'.stdout')),'stderr_sha256':sha(out/(name+'.stderr')),
             'passed':proc.returncode==expected}
        if count:
            text=(out/(name+'.stderr')).read_text()
            match=re.search(r'Ran\s+(\d+)\s+tests?\s+in\s+([0-9.]+)s',text)
            row.update(expected_tests=count,observed_tests=int(match.group(1)) if match else None,
                       unittest_seconds=float(match.group(2)) if match else None)
            row['passed'] &= bool(match and int(match.group(1))==count and '\nOK\n' in text)
        executions.append(row);print(json.dumps(row),flush=True)
    after={name:sha(root/name) for name in before}
    report={'schema':'terminal-HCSN-auditor-validation-v1','created_utc':datetime.now(timezone.utc).isoformat(),
            'source_before':before,'source_after':after,'source_unchanged':before==after,
            'executions':executions,'passed':before==after and all(row['passed'] for row in executions),
            'actual_trained_model_read':False,'optimizer_steps_executed':0,
            'fixture_scope':'Synthetic metadata and synthetic tiny model states only; no scientific training credit.',
            'python':sys.version,'driver_wall_sample_seconds':time.monotonic()-started,
            'driver_CPU_sample_seconds':time.process_time(),'energy_joules':None}
    save(root/'VALIDATION.json',report)
    require(report['passed'],'frozen validation failed; retain originals and do not launch')
    manifest={'files':{str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)}
                       for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}}
    save(root/'MANIFEST.json',manifest)
    archive=root.parent/'final-hcsn-auditor-program-v1.zip'
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as zipped:
        for name in sorted([*manifest['files'],'MANIFEST.json']):zipped.write(root/name,name)
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None,'program archive CRC failed')
        for name,identity in manifest['files'].items():
            import hashlib
            require(hashlib.sha256(zipped.read(name)).hexdigest()==identity['sha256'],'program member differs')
    receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),
             'manifest_sha256':sha(root/'MANIFEST.json'),'validation_sha256':sha(root/'VALIDATION.json'),
             'members':len(manifest['files'])+1,'all_members_verified':True,'passed':True,
             'actual_trained_model_read':False}
    save(root.parent/'final-hcsn-auditor-program-v1-receipt.json',receipt)
    print(json.dumps(receipt),flush=True)


if __name__=='__main__':main()
