"""Synthetic boundary/fault fixtures only; no scientific training credit."""

import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

from terminal_inputs import (PLAN_SHA256, bind_candidate, checkpoint_counters, construction_from_plan,
                             read, remaining_seconds, sha, strict_best, terminal_kind)
from run_audit import fixed_stages, launch_stage, summarize
from launch_native import run_controller
from logrisk_stage import representable_fd_points


class TerminalAndBudgetTests(unittest.TestCase):
    def test_live_candidate_rejected_before_fit_directory_read(self):
        plan={'fit_roster':['hcsn-s101-lr0.001']}
        snapshot={'fits':[{'name':'hcsn-s101-lr0.001','outer':{'status':'started','returncode':None}}]}
        with self.assertRaisesRegex(ValueError,'terminal'):
            bind_candidate('/path-that-does-not-exist','hcsn-s101-lr0.001',plan,snapshot)

    def test_hardkill_cannot_promote_an_intact_looking_budget_report(self):
        with self.assertRaisesRegex(ValueError,'hard-killed'):
            terminal_kind({'status':'failed','returncode':-9,'fit_status':'budget_exhausted'},
                          {'status':'budget_exhausted','training_adequacy_established':False})

    def test_soft_budget_checkpoint_is_allowed_without_adequacy(self):
        kind=terminal_kind({'status':'failed','returncode':2,'fit_status':'budget_exhausted'},
                           {'status':'budget_exhausted','training_adequacy_established':False})
        self.assertEqual(kind,'soft_budget_censored_trained_checkpoint')

    def test_censored_report_cannot_claim_training_adequacy(self):
        with self.assertRaisesRegex(ValueError,'adequacy'):
            terminal_kind({'status':'failed','returncode':2,'fit_status':'budget_exhausted'},
                          {'status':'budget_exhausted','training_adequacy_established':True})

    def test_other_failure_cannot_be_relabelled_soft_budget(self):
        with self.assertRaisesRegex(ValueError,'soft-budget'):
            terminal_kind({'status':'failed','returncode':2,'fit_status':'failed'}, {'status':'failed'})

    def test_best_is_first_strict_maximum_not_last_epoch(self):
        rows=[{'complete':True,'epoch':i+1,'development':{'macro_f1_11_classes':v}} for i,v in enumerate([.1,.4,.4,.2])]
        self.assertEqual(strict_best(rows)['epoch'],2)
        rows[2]['complete']=False
        with self.assertRaisesRegex(ValueError,'incomplete'):
            strict_best(rows)

    def test_last_complete_epoch_may_precede_terminal_partial_updates(self):
        plan={'batch_size':32,'manifest_sha256':'abc'}
        report={'episodes_train':356,'main_updates':559,'model_configuration':{'a':1}}
        checkpoint={'epochs_completed':46,'main_updates':552,'data_manifest_sha256':'abc','model_configuration':{'a':1}}
        checkpoint_counters(checkpoint,46,plan,report)
        checkpoint['main_updates']=559
        with self.assertRaisesRegex(ValueError,'complete-epoch'):
            checkpoint_counters(checkpoint,46,plan,report)

    def test_constructor_is_derived_from_plan_not_report_self_agreement(self):
        plan={'arm':'hcsn','width':16,'seed':101,'hcsn_grid_json':{'cells':256},
              'train_shared':False,'cache_frozen_tables':True,'learn_core_adapter':True}
        expected=construction_from_plan(plan)
        self.assertTrue(expected['freeze_shared'])
        wrong=dict(expected,freeze_shared=False)
        self.assertNotEqual(wrong,construction_from_plan(plan))

    def test_exact_plan_hash_rejects_even_valid_json_tamper(self):
        plan_path=Path(__file__).parent/'PLAN.json'
        read(plan_path,PLAN_SHA256)
        with tempfile.TemporaryDirectory() as folder:
            changed=Path(folder)/'plan.json';changed.write_bytes(plan_path.read_bytes()+b' ')
            with self.assertRaisesRegex(ValueError,'SHA mismatch'):
                read(changed,PLAN_SHA256)

    def test_source_byte_tamper_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'source.json';path.write_text('{"source":1}')
            digest=sha(path);path.write_text('{"source":2}')
            with self.assertRaisesRegex(ValueError,'SHA mismatch'):
                read(path,digest)

    def test_budget_has_no_refund_or_nonfinite_clock(self):
        self.assertEqual(remaining_seconds(10,15,8),3)
        self.assertEqual(remaining_seconds(10,20,8),0)
        for now in (9,float('nan')):
            with self.assertRaises(ValueError):remaining_seconds(10,now,8)

    def test_fixed_order_contains_all60_finite_and_exact96_stages(self):
        names=[f'model-{i}' for i in range(6)]
        tasks=fixed_stages(names,9)
        self.assertEqual(len(tasks),96)
        self.assertEqual(sum(stage.startswith('finite-') for _,stage in tasks),60)
        self.assertEqual(tasks[36:42],[(name,'finite-best-0') for name in names])
        self.assertEqual(tasks[-6:],[(name,'finite-last-0') for name in names])

    def test_missing_executable_retains_failed_outer_and_cost(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            result=launch_stage(['/nonexistent-executable'],root,'failure',1,2**30,2**33)
            self.assertFalse(result['process_started'])
            self.assertNotEqual(result['execution_status'],'completed')
            self.assertTrue((root/'failure-outer.json').is_file())
            self.assertGreaterEqual(result['whole_process_wall_seconds'],0)

    def test_zero_exit_without_artifact_is_not_completed(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            result=launch_stage([sys.executable,'-c','pass'],root,'missing',2,2**30,2**33)
            self.assertEqual(result['returncode'],0)
            self.assertEqual(result['execution_status'],'artifact_failed')

    def test_malformed_success_artifact_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);target=root/'bad.json'
            result=launch_stage([sys.executable,'-c',f"open({str(target)!r},'w').write('broken')"],root,'bad',2,2**30,2**33)
            self.assertEqual(result['execution_status'],'artifact_failed')
            self.assertIn('result_error',result)

    def test_stage_wall_limit_retains_partial_stdout(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            result=launch_stage([sys.executable,'-u','-c',"import time;print('begun',flush=True);time.sleep(10)"],root,'capped',.15,2**30,2**33)
            self.assertEqual(result['stop_cause'],'declared_stage_or_remaining_whole_wall_cap')
            self.assertLess(result['returncode'],0)
            self.assertIn('begun',(root/'capped.stdout').read_text())

    def test_reported_peak_over_cap_is_rejected_even_if_sampler_missed_it(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);target=root/'rss.json'
            payload={'stage':'rss','execution_status':'completed','result':{},'peak_rss_bytes':3*2**30}
            code=f"import json;json.dump({payload!r},open({str(target)!r},'w'))"
            result=launch_stage([sys.executable,'-c',code],root,'rss',2,2*2**30,2**33)
            self.assertEqual(result['stop_cause'],'reported_child_peak_RSS_above_cap')
            self.assertEqual(result['reported_child_peak_RSS_sample_bytes'],3*2**30)
            self.assertNotEqual(result['execution_status'],'completed')

    def test_missing_late_stage_json_does_not_abort_summary(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            receipt={'terminal_kind':'soft_budget_censored_trained_checkpoint','training_adequacy_established':False,
                     'complete_epochs':46,'best_epoch':40,'best_D_metrics_from_original_complete_epoch':{'macro_f1_11_classes':.2}}
            result=summarize({('one','finite-best-0'):{'execution_status':'completed','result_sha256':'missing'}},{'one':receipt},root)
            self.assertEqual(len(result[0]['aggregation_read_errors']),1)
            self.assertFalse(result[0]['passed_named_finite_fixtures_with_source_gate'])

    def test_hard_whole_budget_includes_controller_process(self):
        with tempfile.TemporaryDirectory() as folder:
            result=run_controller([sys.executable,'-c','import time;time.sleep(10)'],Path(folder)/'launch',.12)
            self.assertEqual(result['status'],'whole_budget_exhausted')
            self.assertLess(result['returncode'],0)
            self.assertGreaterEqual(result['whole_process_wall_seconds'],.12)
            self.assertTrue((Path(folder)/'launch/receipt.json').is_file())

    def test_fixed_FD_step_is_representable_at_actual_tiny_gap(self):
        for value in (1e-7,.35,-.12,0.,4.8):
            lo,hi=representable_fd_points(value)
            self.assertLess(lo,value);self.assertGreater(hi,value)
            if value>0:self.assertGreater(lo,0)


if __name__=='__main__':unittest.main()
