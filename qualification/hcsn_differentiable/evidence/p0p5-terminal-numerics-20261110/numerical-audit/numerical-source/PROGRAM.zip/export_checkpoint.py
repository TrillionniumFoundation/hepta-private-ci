"""Exact frozen-v8 wrapper export after terminal identity preflight."""

from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
import math
import random

import torch

from terminal_inputs import checkpoint_counters, construction_from_plan, read, require, save, sha, verify_data


def bind_runtime(source):
    source = Path(source)
    sys.path.insert(0, str(source))
    sys.path.insert(0, str(source/'proposals/localization-v3'))
    import cores
    require(Path(cores.__file__).resolve() == source/'proposals/localization-v3/cores.py', 'wrong loaded wrapper source')
    return cores


def imported_source_receipt(receipt):
    source=Path(receipt['source']).resolve();checked={}
    for name,module in list(sys.modules.items()):
        if name.startswith('qualification.hcsn_differentiable') or name in ('cores','frozen_tables','hcsn_study_support'):
            filename=getattr(module,'__file__',None)
            require(filename is not None,'loaded numerical module has no source identity')
            path=Path(filename).resolve()
            require(path.is_relative_to(source),'loaded numerical module escapes exact v8 source: '+name)
            require(str(path) in receipt['report']['source_before'] and sha(path)==receipt['report']['source_before'][str(path)],'loaded numerical module hash differs: '+name)
            checked[name]={'path':str(path),'sha256':sha(path)}
    require(torch.__version__==receipt['report']['torch_version'],'export runtime Torch version differs from original trainer')
    return checked


def export_checkpoint(receipt, plan, output, which):
    require(which in ('best','last'), 'unsupported checkpoint selection')
    out, root = Path(output), Path(receipt['root'])
    cores = bind_runtime(receipt['source'])
    from qualification.hcsn_differentiable.training_domain import TrainingDomainRecorder, model_digest, read_trace
    checkpoint = torch.load(root/(which+'.pt'), weights_only=True, map_location='cpu')
    epoch = receipt['best_epoch'] if which=='best' else receipt['complete_epochs']
    checkpoint_counters(checkpoint, epoch, receipt['fit_plan'], receipt['report'])
    model = cores.CoreStudyModel(**checkpoint['model_configuration'])
    model.load_state_dict(checkpoint['model'], strict=True)
    model.eval()
    from hcsn_study_support import sources
    require(sources(model)==receipt['report']['source_before'],'actual model/module dependency source map differs from original trainer')
    loaded=imported_source_receipt(receipt)
    expected_groups=receipt['report']['optimizer_groups']
    trainable=dict((n,p) for n,p in model.named_parameters() if p.requires_grad)
    expected_names=[name for group in expected_groups for name in group['parameter_names']]
    require(set(expected_names)==set(trainable) and len(expected_names)==len(trainable),'checkpoint optimizer omits/duplicates trained parameters')
    saved_groups=checkpoint['optimizer']['param_groups'];identifiers=[]
    require(len(saved_groups)==len(expected_groups),'optimizer group count differs')
    for group,expected_group in zip(saved_groups,expected_groups):
        require(group['lr']==expected_group['lr'] and group['weight_decay']==expected_group['weight_decay'],'optimizer LR/decay differs')
        require(len(group['params'])==len(expected_group['parameter_names']),'optimizer membership differs')
        for identifier,name in zip(group['params'],expected_group['parameter_names']):
            identifiers.append(identifier);state=checkpoint['optimizer']['state'][identifier]
            require(float(state['step'])==checkpoint['main_updates'],'Adam step counter differs from checkpoint')
            for moment in ('exp_avg','exp_avg_sq'):
                require(state[moment].shape==trainable[name].shape and bool(torch.isfinite(state[moment]).all()),'invalid Adam moment')
            require(bool((state['exp_avg_sq']>=0).all()),'negative Adam second moment')
    require(len(set(identifiers))==len(identifiers) and set(identifiers)==set(checkpoint['optimizer']['state']),'extra/missing optimizer state')
    generator=torch.Generator();generator.set_state(checkpoint['torch_rng'])
    rng=random.Random(receipt['fit_plan']['seed'])
    for _ in range(epoch):
        order=list(range(receipt['report']['episodes_train']));rng.shuffle(order)
    require(rng.getstate()==checkpoint['order_rng'],'checkpoint sample-order RNG differs from complete epochs')
    initial_checkpoint = torch.load(root/'initial.pt', weights_only=True, map_location='cpu')
    require(initial_checkpoint['model_configuration']==construction_from_plan(receipt['fit_plan']),'initial construction differs from independent plan')
    initial=initial_checkpoint['model']
    for name, tensor in model.state_dict().items():
        if name.startswith(('frontend.','head.')) or '.physics.' in name:
            require(torch.equal(tensor, initial[name]), 'fixed shared/physical tensor changed')
    network = model.core.network
    require(all(not p.requires_grad for layer in network.layers for p in layer.physics.parameters()), 'physics is unexpectedly learnable')
    require(len(network.layers)==1, 'unplanned layer count')
    before = model_digest(model)
    layer = network.layers[0]
    require(asdict(layer.grid)==plan['expected_construction']['grid'], 'loaded checkpoint grid differs')
    params = dict(zip(('log_boundary','mu','sigma','absolute_reset','discount'),
                      [float(p.detach()) for p in layer.physics().tensors()]))
    selected = plan['supplemental_export']['primary_episodes_per_checkpoint'] if which=='best' else [plan['supplemental_export']['last_episode_per_checkpoint']]
    fixtures = plan['finite_schedule_fixtures_per_primary_checkpoint'] if which=='best' else [plan['last_checkpoint_fixture']]
    episodes = verify_data(receipt['prepared'], plan)
    capture = {}
    def hook(module, arguments, keywords, returned):
        capture['returned'] = returned
    handle = network.register_forward_hook(hook, with_kwargs=True)
    rows, laws = [], {}
    try:
        for eid in selected:
            episode = episodes[eid]
            expected = next(e for e in plan['fixed_episodes'] if e['id']==eid)
            trace_path = out/(which+'-'+eid+'.jsonl')
            recorder = TrainingDomainRecorder(trace_path, data_sha256=expected['sha256'],
                configuration_sha256=sha(out/'input-receipt.json'), max_records=512, max_bytes=33554432)
            model.core.recorder = recorder
            model.core.record_context = {'episode_id':eid, 'update_index':checkpoint['main_updates']}
            x, dt = [torch.tensor(episode[name], dtype=torch.float64)[None] for name in ('x','dt')]
            require(bool(x[...,12:24].bool().any(-1).all()), 'predeclared fixed window unexpectedly contains padding')
            try:
                with torch.no_grad():
                    prediction = model(x,dt)
            finally:
                recorder.close()
                model.core.recorder = None
            actual = capture.pop('returned')
            header, visits, footer, trace_sha = read_trace(trace_path)
            require(not footer['truncated'] and len(visits)==len(episode['y']), 'supplemental export lost records')
            require(bool(torch.isfinite(prediction).all()), 'nonfinite output')
            content = []
            for position, visit in enumerate(visits):
                state = actual.trace[position][0]
                require(torch.equal(torch.tensor(visit['posterior'],dtype=torch.float64),state['probability']), 'recorder and actual wrapper posterior differ')
                require(bool(torch.isfinite(state['content_mass']).all()), 'nonfinite actual content state')
                content.append({'position':position,'maximum_absolute_content':float(state['content_mass'].abs().max()),
                                'content_sha256':hashlib.sha256(state['content_mass'].contiguous().numpy().tobytes()).hexdigest()})
            prediction_path = out/(which+'-'+eid+'-predictions.pt')
            torch.save({'logits':prediction[0],'labels':torch.tensor(episode['y']), 'episode_id':eid},prediction_path)
            for index, fixture in enumerate(fixtures):
                if fixture['episode_id'] != eid:
                    continue
                position = fixture['posterior_after_position']
                durations = episode['dt'][position+1:position+1+fixture['intervals']]
                require(durations==fixture['durations'], 'future gap selection differs from frozen plan')
                probability = actual.trace[position][0]['probability'][0].detach().clone()
                laws[str(index)] = {'probability':probability,'durations':durations,
                    'grid':asdict(layer.grid),'operator':layer.operator.configuration(),'parameters':params,
                    'fixture':fixture,'trace_sha256':trace_sha,'checkpoint_sha256':sha(root/(which+'.pt')),
                    'trace_position':position,'episode_sha256':expected['sha256']}
            rows.append({'episode_id':eid,'trace':trace_path.name,'trace_sha256':trace_sha,'records':len(visits),
                         'footer':footer,'prediction_file':prediction_path.name,'prediction_sha256':sha(prediction_path),
                         'content_state_checks':content,'network_model_sha256':model_digest(network),
                         'scope':'Supplemental fixed-checkpoint evaluation, not historical training capture.'})
    finally:
        handle.remove()
        model.core.recorder = None
    require(len(laws)==len(fixtures), 'missing predeclared finite starting law')
    require(before==model_digest(model), 'export mutated trained wrapper tensors')
    law_path=out/(which+'-laws.pt')
    torch.save(laws,law_path)
    return {'execution_status':'completed_export','which':which,'checkpoint_sha256':sha(root/(which+'.pt')),
            'checkpoint_epoch':epoch,'checkpoint_main_updates':checkpoint['main_updates'],
            'terminal_report_main_updates':receipt['report']['main_updates'],
            'terminal_updates_beyond_this_complete_epoch_checkpoint':receipt['report']['main_updates']-checkpoint['main_updates'],
            'checkpoint_scope':'First strict D-best complete epoch' if which=='best' else 'Last complete epoch; not a claim to contain later partial-epoch optimizer updates.',
            'optimizer_parameters_checked':len(identifiers),'order_rng_complete_epoch_recurrence_checked':True,
            'actual_loaded_model_module_sources':loaded,'runtime_Torch_matches_original':True,
            'wrapper_model_sha256':before,'wrapper_tensors_unchanged':True,'physical_parameters':params,
            'traces':rows,'laws_file':law_path.name,'laws_sha256':sha(law_path),
            'cache_receipts':[layer.operator.cache_receipt() for layer in network.layers],
            'whole_training_domain_admission':'HOLD','scientific_admission':'HOLD'}
