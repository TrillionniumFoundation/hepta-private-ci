"""Fixed-order bounded audit of genuinely terminal HCSN checkpoint artifacts."""

import os
import time

PROCESS_STARTED=float(os.environ.get('HCSN_AUDIT_PROCESS_STARTED',time.monotonic()))
os.environ.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
                  CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1')

import argparse
from datetime import datetime, timezone
from pathlib import Path
import resource
import signal
import subprocess
import sys
import traceback
from zipfile import ZipFile,ZIP_DEFLATED

from terminal_inputs import PLAN_SHA256, bind_candidate, read, remaining_seconds, require, save, sha, verify_bound


def fixed_stages(names, fixture_count):
    tasks=[]
    for stage in ('export-best','export-last','original-prefix','domain-best','domain-last','logrisk'):
        tasks.extend((name,stage) for name in names)
    for index in range(fixture_count):
        tasks.extend((name,f'finite-best-{index}') for name in names)
    tasks.extend((name,'finite-last-0') for name in names)
    return tasks


def launch_stage(argv, output, stage, seconds, rss_limit, address_limit):
    start=time.monotonic();usage0=resource.getrusage(resource.RUSAGE_CHILDREN)
    row={'argv':argv,'started_utc':datetime.now(timezone.utc).isoformat(),
         'whole_stage_wall_ceiling_seconds':seconds,'RSS_limit_bytes':rss_limit,'address_limit_bytes':address_limit}
    process=None;peak=0;cause=None
    row['process_started']=False
    try:
      with (output/(stage+'.stdout')).open('xb') as stdout,(output/(stage+'.stderr')).open('xb') as stderr:
        def limits():resource.setrlimit(resource.RLIMIT_AS,(address_limit,address_limit))
        # Inherit the controller group: its hard whole-budget launcher can
        # terminate controller and stage together. A stage spawns no children.
        process=subprocess.Popen(argv,stdout=stdout,stderr=stderr,preexec_fn=limits)
        row.update(pid=process.pid,process_started=True)
        while process.poll() is None:
            try:
                fields=(Path('/proc')/str(process.pid)/'status').read_text().splitlines()
                rss=next(int(v.split()[1])*1024 for v in fields if v.startswith('VmRSS:'))
                peak=max(peak,rss)
            except (FileNotFoundError,StopIteration,ProcessLookupError):
                pass
            if time.monotonic()-start>=seconds:
                cause='declared_stage_or_remaining_whole_wall_cap'
            elif peak>rss_limit:
                cause='declared_RSS_cap'
            if cause:
                try:process.kill()
                except ProcessLookupError:pass
                break
            time.sleep(.1)
        process.wait()
    except Exception:
        row['launch_or_monitor_error']=traceback.format_exc()
        if process is not None and process.poll() is None:
            process.kill();process.wait()
    usage1=resource.getrusage(resource.RUSAGE_CHILDREN)
    returncode=process.returncode if process is not None else None
    row.update(returncode=returncode,stop_cause=cause,
        execution_status='completed' if returncode==0 and cause is None and 'launch_or_monitor_error' not in row else 'failed_or_budget_exhausted',
        whole_process_wall_seconds=time.monotonic()-start,
        waited_child_CPU_seconds=usage1.ru_utime+usage1.ru_stime-usage0.ru_utime-usage0.ru_stime,
        sampled_peak_RSS_bytes=peak,finished_utc=datetime.now(timezone.utc).isoformat())
    for stream in ('stdout','stderr'):
        p=output/(stage+'.'+stream);row[stream]={'bytes':p.stat().st_size,'sha256':sha(p)} if p.exists() else {'missing':True}
    result=output/(stage+'.json')
    try:
        if result.exists():
            row['result_sha256']=sha(result)
            payload=read(result)
            row['inner_execution_status']=payload.get('execution_status')
            require(payload.get('stage')==stage,'returned stage identity differs')
            if row['execution_status']=='completed':
                require(payload.get('execution_status')=='completed' and isinstance(payload.get('result'),dict),'successful process lacks a complete result object')
                require(type(payload.get('peak_rss_bytes')) is int and payload['peak_rss_bytes']>=0,'child peak RSS sample is missing/invalid')
                row['reported_child_peak_RSS_sample_bytes']=payload['peak_rss_bytes']
                if payload['peak_rss_bytes']>rss_limit:
                    row.update(execution_status='failed_or_budget_exhausted',stop_cause='reported_child_peak_RSS_above_cap')
        elif row['execution_status']=='completed':
            raise ValueError('successful process did not retain its stage result')
    except Exception:
        row.update(execution_status='artifact_failed',result_error=traceback.format_exc())
    save(output/(stage+'-outer.json'),row)
    return row


def summarize(results, receipts, root, source_ok=True):
    candidates=[]
    for name,receipt in receipts.items():
        available={};read_errors=[]
        for (candidate,stage),outer in results.items():
            if candidate==name and outer['execution_status']=='completed':
                try:
                    path=root/name/(stage+'.json')
                    require(sha(path)==outer['result_sha256'],'stage result changed before aggregation')
                    available[stage]=read(path)['result']
                except Exception:read_errors.append({'stage':stage,'error':traceback.format_exc()})
        finite=[value for stage,value in available.items() if stage.startswith('finite-')]
        domains=[value for stage,value in available.items() if stage.startswith('domain-')]
        candidates.append({'name':name,'terminal_kind':receipt['terminal_kind'],
            'training_adequacy_established':receipt['training_adequacy_established'],
            'complete_epochs':receipt['complete_epochs'],'best_epoch':receipt['best_epoch'],
            'best_D_metrics_from_original_complete_epoch':receipt['best_D_metrics_from_original_complete_epoch'],
            'D_metrics_independently_recomputed':False,'common_LR_independently_selected':False,
            'finite_fixtures_completed':len(finite),'finite_fixtures_passed':sum(v['status']=='passed_fixture' for v in finite),
            'all10_named_finite_fixtures_passed':len(finite)==10 and all(v['status']=='passed_fixture' for v in finite),
            'passed_named_finite_fixtures_with_source_gate':source_ok and not read_errors and len(finite)==10 and all(v['status']=='passed_fixture' for v in finite),
            'raw_numerical_fields_scope':'Raw completed stage values; qualification additionally requires the explicit source/identity gate.',
            'aggregation_read_errors':read_errors,
            'state_gradient_checks_passed':len(domains)==2 and all(v['state_gradient_checks_passed'] for v in domains),
            'pressure_failures':[p for v in domains for p in v['pressure_sentinels'] if not p['passed']],
            'logrisk_primary_passed':available.get('logrisk',{}).get('primary_passed',False),
            'logrisk_direct_FD_inconclusive_count':available.get('logrisk',{}).get('direct_FD_inconclusive_count'),
            'logrisk_direct_FD_resolved_disagreement_count':available.get('logrisk',{}).get('direct_FD_resolved_disagreement_count'),
            'original_trace_audit_status':available.get('original-prefix',{}).get('status','not_completed'),
            'original_trace_audited_records':available.get('original-prefix',{}).get('audited_records'),
            'original_trace_source_matches':available.get('original-prefix',{}).get('source_matches_trace'),
            'original_trace_complete_retained_coverage':available.get('original-prefix',{}).get('complete_retained_coverage'),
            'original_trace_summary':available.get('original-prefix',{}).get('trace_summary'),
            'numerical_scope':'Only explicitly completed actual checkpoint fixtures; no whole-domain or task-oracle claim.',
            'whole_training_domain_admission':'HOLD','scientific_admission':'HOLD'})
    return candidates


def main():
    require(__debug__,'assertions must remain enabled')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--terminal-snapshot',type=Path,required=True)
    parser.add_argument('--terminal-snapshot-sha256',required=True)
    parser.add_argument('--plan',type=Path,default=Path(__file__).parent/'PLAN.json')
    args=parser.parse_args()
    plan=read(args.plan,PLAN_SHA256)
    terminal=read(args.terminal_snapshot,args.terminal_snapshot_sha256)
    out=args.output;out.mkdir(parents=True,exist_ok=False)
    source_before={str(p):sha(p) for p in Path(__file__).parent.glob('*.py')}
    save(out/'launch.json',{'started_utc':datetime.now(timezone.utc).isoformat(),'args':{k:str(v) for k,v in vars(args).items()},
                          'plan_sha256':sha(args.plan),'auditor_sources':source_before,'resource_caps':plan['resource_caps']})
    (out/'terminal-snapshot.json').write_bytes(args.terminal_snapshot.read_bytes())
    (out/'PLAN.json').write_bytes(args.plan.read_bytes())
    receipts={};receipt_hashes={};failures=[];results={};unrun=[]
    for name in plan['fit_roster']:
        try:
            value=bind_candidate(args.base,name,plan,terminal)
            (out/name).mkdir()
            save(out/name/'input-receipt.json',value)
            receipts[name]=value
            receipt_hashes[name]=sha(out/name/'input-receipt.json')
        except Exception:
            failures.append({'name':name,'preflight_status':'HOLD','error':traceback.format_exc()})
    caps=plan['resource_caps']
    tasks=fixed_stages(list(receipts),len(plan['finite_schedule_fixtures_per_primary_checkpoint']))
    for index,(name,stage) in enumerate(tasks):
        remaining=remaining_seconds(PROCESS_STARTED,time.monotonic(),caps['whole_attempt_wall_seconds'])
        if remaining<=0:
            unrun=[{'name':n,'stage':s,'reason':'whole_attempt_wall_cap'} for n,s in tasks[index:]]
            break
        prerequisites=['export-best','export-last'] if stage=='logrisk' else []
        if stage.startswith(('domain-','finite-')):
            prerequisites=['export-'+stage.split('-')[1]]
        if any(results.get((name,p),{}).get('execution_status')!='completed' for p in prerequisites):
            unrun.append({'name':name,'stage':stage,'reason':'required_export_failed'})
            continue
        argv=[sys.executable,'-B',str(Path(__file__).parent/'stage.py'),'--receipt',str(out/name/'input-receipt.json'),
              '--receipt-sha256',receipt_hashes[name],
              '--plan',str(args.plan),'--output',str(out/name),'--stage',stage]
        row=launch_stage(argv,out/name,stage,min(caps['per_stage_wall_seconds'],remaining),
                         caps['peak_RSS_limit_bytes'],caps['address_space_limit_bytes'])
        results[(name,stage)]=row
        print({'name':name,'stage':stage,'status':row['execution_status']},flush=True)
    stable=True
    for name,value in receipts.items():
        try:
            verify_bound(value)
            require(sha(out/name/'input-receipt.json')==receipt_hashes[name],'generated input receipt changed')
        except Exception:stable=False;failures.append({'name':name,'final_identity_error':traceback.format_exc()})
    source_unchanged=all(sha(p)==d for p,d in source_before.items()) and sha(args.plan)==PLAN_SHA256
    try:
        candidates=summarize(results,receipts,out,stable and source_unchanged)
    except Exception:
        candidates=[];failures.append({'aggregation_error':traceback.format_exc()})
    report={'schema':'terminal-HCSN-bounded-audit-v1','execution_status':'completed_declared_stages' if not unrun and not failures and stable and source_unchanged and all(r['execution_status']=='completed' for r in results.values()) else 'incomplete_or_failed_stages',
            'candidates':candidates,'preflight_or_identity_failures':failures,'unrun':unrun,
            'stage_receipts':[{'name':n,'stage':s,**r} for (n,s),r in results.items()],
            'original_inputs_unchanged':stable,'auditor_source_unchanged':source_unchanged,
            'controller_wall_sample_seconds':time.monotonic()-PROCESS_STARTED,
            'controller_CPU_sample_seconds':time.process_time(),
            'sum_completed_stage_outer_wall_seconds':sum(r['whole_process_wall_seconds'] for r in results.values()),
            'sum_waited_stage_CPU_seconds':sum(r['waited_child_CPU_seconds'] for r in results.values()),
            'timing_scope':'Controller sample includes its serial children; do not add overlapping timers. Launcher retains whole exit cost.',
            'energy_joules':None,'scientific_admission':'HOLD','whole_training_domain_admission':'HOLD',
            'finished_utc':datetime.now(timezone.utc).isoformat()}
    save(out/'RESULT.json',report)
    save(out/'SUMMARY.json',{k:report[k] for k in ('schema','execution_status','candidates','preflight_or_identity_failures','unrun','original_inputs_unchanged','auditor_source_unchanged','controller_wall_sample_seconds','sum_completed_stage_outer_wall_seconds','sum_waited_stage_CPU_seconds','finished_utc')})
    manifest={'files':{str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.rglob('*')) if p.is_file()}}
    save(out/'MANIFEST.json',manifest)
    archive=Path(str(out)+'.zip')
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as zipped:
        for p in sorted(out.rglob('*')):
            if p.is_file():zipped.write(p,str(p.relative_to(out)))
    with ZipFile(archive) as zipped:require(zipped.testzip() is None,'output archive CRC failed')
    save(out/'ARCHIVE.json',{'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'manifest_sha256':sha(out/'MANIFEST.json')})
    return 0 if report['execution_status']=='completed_declared_stages' and stable and source_unchanged else 1


if __name__=='__main__':
    raise SystemExit(main())
