"""Fail-closed binding of genuinely terminal, possibly censored checkpoints."""

import hashlib
import json
import math
from pathlib import Path

PLAN_SHA256='6ae8bb984d994f0d3fa6963e37d0f4180366a3a7bafd316d887e74f2ef1c7d26'


def construction_from_plan(plan):
    return {'arm':plan['arm'],'width':plan['width'],'seed':plan['seed'],
            's4_repo':str(plan['s4_repo']) if plan.get('s4_repo') is not None else None,
            'hcsn_grid':plan['hcsn_grid_json'],'freeze_shared':not plan['train_shared'],
            'cache_frozen_tables':plan['cache_frozen_tables'],'learn_core_adapter':plan['learn_core_adapter'],
            'plif_configuration':None}


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1048576), b''):
            result.update(part)
    return result.hexdigest()


def read(path, expected=None):
    if expected is not None:
        require(sha(path) == expected, 'input SHA mismatch: ' + str(path))
    return json.loads(Path(path).read_bytes())


def save(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def terminal_kind(outer, report):
    require(outer.get('status') in ('completed', 'failed'), 'original process is not acknowledged terminal')
    require(type(outer.get('returncode')) is int and outer['returncode'] in (0, 2), 'hard-killed/unknown exit cannot establish a complete parent')
    require(report.get('status') == outer.get('fit_status'), 'outer/report terminal status differs')
    if report['status'] == 'completed_development':
        require(outer['returncode'] == 0, 'completed report has a nonzero exit')
        return 'completed_trained_checkpoint'
    require(report['status'] == 'budget_exhausted' and outer['returncode'] == 2,
            'only intact soft-budget terminal reports permit a censored checkpoint audit')
    require(report.get('training_adequacy_established') is False, 'censored attempt cannot claim training adequacy')
    return 'soft_budget_censored_trained_checkpoint'


def strict_best(epochs):
    require(bool(epochs), 'no complete epoch exists')
    for index, row in enumerate(epochs, 1):
        require(row.get('complete') is True and row.get('epoch') == index, 'epoch history is incomplete or noncontiguous')
        score = row['development']['macro_f1_11_classes']
        require(type(score) in (int, float) and math.isfinite(score) and 0 <= score <= 1, 'invalid D score')
    return max(epochs, key=lambda row: row['development']['macro_f1_11_classes'])


def checkpoint_counters(checkpoint, epoch, plan, report):
    expected_updates = epoch * math.ceil(report['episodes_train'] / plan['batch_size'])
    require(checkpoint['epochs_completed'] == epoch and checkpoint['main_updates'] == expected_updates,
            'checkpoint is not the named complete-epoch state')
    require(checkpoint['main_updates'] <= report['main_updates'], 'checkpoint updates exceed terminal report')
    require(checkpoint['data_manifest_sha256'] == plan['manifest_sha256'], 'checkpoint data identity differs')
    require(checkpoint['model_configuration'] == report['model_configuration'], 'checkpoint construction differs')


def remaining_seconds(start, now, ceiling):
    require(all(type(v) in (int, float) and math.isfinite(v) for v in (start, now, ceiling)), 'nonfinite budget clock')
    require(now >= start and ceiling > 0, 'invalid budget clock order')
    return max(0.0, ceiling - (now - start))


def bind_candidate(base, name, frozen_plan, terminal_snapshot):
    """Look at terminal evidence before opening any fit-directory artifact."""
    require(name in frozen_plan['fit_roster'], 'candidate is not predeclared')
    entries = [row for row in terminal_snapshot['fits'] if row['name'] == name]
    require(len(entries) == 1, 'missing/duplicate terminal candidate')
    entry = entries[0]
    outer = entry['outer']
    # Reject a live/hard-killed row before touching the candidate directory.
    require(outer.get('status') in ('completed', 'failed') and outer.get('returncode') in (0, 2),
            'candidate is not an admissible terminal process')
    journal_path=Path(base)/'campaign-v2/commands.jsonl'
    command_bytes=journal_path.read_bytes()
    commands=[json.loads(line) for line in command_bytes.splitlines()]
    commands=[row for row in commands if row['name']==name]
    require(len(commands)==2 and commands[0]['status']=='started' and commands[1]['status'] in ('completed','failed'),
            'original command journal does not prove a single terminal process')
    require(all(commands[1].get(key)==value for key,value in outer.items()),'terminal handoff differs from original process journal')
    root = Path(base) / 'campaign-v2' / name
    identities = entry['artifact_identities']
    for filename in ('result.json', 'plan.json', 'initial.pt', 'best.pt', 'last.pt', 'events.jsonl'):
        require(filename in identities, 'required terminal artifact identity missing')
    before = {str(journal_path):hashlib.sha256(command_bytes).hexdigest()}
    for filename, identity in identities.items():
        require(Path(filename).name == filename, 'unsafe artifact name')
        path = root / filename
        require(path.stat().st_size == identity['bytes'] and sha(path) == identity['sha256'], 'terminal artifact changed: ' + filename)
        before[str(path)] = identity['sha256']
    report = read(root/'result.json', outer['result_sha256'])
    plan = read(root/'plan.json', report['plan_sha256'])
    kind = terminal_kind(outer, report)
    budget_evidence = {'wall_observed_above_limit': report.get('wall_seconds',0)>plan['wall_seconds'],
                       'peak_RSS_observed_above_limit': report.get('peak_rss_bytes',0)>plan['rss_bytes'],
                       'original_error': report.get('error')}
    require(report['source_unchanged'] and report['source_before'] == report['source_after'], 'trained source changed')
    require(report['common_weights_unchanged'], 'frozen shared tensors changed')
    require(not report['confirmation_access'], 'confirmation split accessed')
    require(plan['arm'] == report['arm'] == 'hcsn' and report['seed'] == plan['seed'], 'candidate identity differs')
    require(name == f"hcsn-s{plan['seed']}-lr{plan['learning_rate']:g}", 'candidate name/config differs')
    require(plan['manifest_sha256'] == frozen_plan['data_manifest_sha256'], 'data manifest differs')
    expected = frozen_plan['expected_construction']
    require(plan['width'] == expected['width'] and not plan['train_shared']
            and plan['cache_frozen_tables'] and plan['learn_core_adapter'], 'model regime differs')
    require(plan['hcsn_grid_json'] == expected['grid'], 'full grid differs')
    require(report['model_configuration']==construction_from_plan(plan),'reported construction is not independently implied by fit plan')
    for path, digest in report['source_before'].items():
        require(sha(path) == digest, 'actual trained source/dependency changed: ' + path)
        before[path] = digest
    source = Path(base)/'run-source-v8'
    for suffix, digest in frozen_plan['source_files'].items():
        require(sha(source/suffix) == digest, 'frozen v8 implementation differs')
        before[str(source/suffix)] = digest
    best = strict_best(report['epochs'])
    require(best['epoch'] == report['best_epoch'], 'reported best is not first strict D maximum')
    for filename, field in [('best.pt','best_checkpoint_sha256'), ('last.pt','last_checkpoint_sha256'),
                            ('initial.pt','initialization_sha256'), ('events.jsonl','events_sha256')]:
        require(report[field] == identities[filename]['sha256'], 'report/artifact binding differs: ' + filename)
    events = [json.loads(line) for line in (root/'events.jsonl').read_bytes().splitlines()]
    require(events and events[-1].get('kind') == 'finished' and events[-1]['status'] == report['status'], 'terminal journal is incomplete')
    require([r for r in events if r['kind'] == 'epoch_completed'] and
            [r['epoch'] for r in events if r['kind'] == 'epoch_completed'] == list(range(1,len(report['epochs'])+1)), 'journal complete-epoch roster differs')
    completed_updates = [r['number'] for r in events if r['kind'] == 'optimizer_completed' and r.get('phase') == 'main']
    require(completed_updates == list(range(1,report['main_updates']+1)), 'main update journal differs')
    trace = root/'training-domain.jsonl'
    require(trace.is_file(), 'original training trace absent')
    before[str(trace)] = sha(trace)
    for path, digest in before.items():
        require(sha(path) == digest, 'input changed during terminal binding')
    return {'name':name, 'root':str(root), 'source':str(source), 'prepared':plan['prepared'],
            'terminal_kind':kind, 'original_outer':outer, 'original_report_status':report['status'],
            'original_terminal_command':commands[1],
            'budget_trigger_evidence':budget_evidence,
            'report':report, 'fit_plan':plan, 'original_training_trace':str(trace),
            'original_training_trace_sha256':before[str(trace)], 'bound_files':before,
            'best_epoch':best['epoch'], 'best_D_metrics_from_original_complete_epoch':best['development'],
            'best_D_independently_recomputed':False, 'complete_epochs':len(report['epochs']),
            'training_adequacy_established':report['training_adequacy_established'],
            'numerical_admission':'HOLD', 'whole_training_domain_admission':'HOLD'}


def verify_bound(receipt):
    for path, digest in receipt['bound_files'].items():
        require(sha(path) == digest, 'bound original changed: ' + path)


def verify_data(prepared, plan):
    root = Path(prepared)
    manifest = read(root/'data-manifest.json', plan['data_manifest_sha256'])
    require(not manifest['confirmation_access'] and manifest['mode']=='all-development', 'unexpected data scope')
    rows = {}
    for fixed in plan['fixed_episodes']:
        entry = next(r for r in manifest['episodes'] if r['id']==fixed['id'])
        require(entry['sha256']==fixed['sha256'], 'predeclared episode differs')
        row = read(root/entry['path'], fixed['sha256'])
        require(row['partition']==fixed['partition'] and len(row['y'])==fixed['events'], 'episode semantics differ')
        require(row['dt']==[v/10000000 for v in row['delta_ticks']], 'gap identity differs')
        rows[fixed['id']] = row
    return rows
