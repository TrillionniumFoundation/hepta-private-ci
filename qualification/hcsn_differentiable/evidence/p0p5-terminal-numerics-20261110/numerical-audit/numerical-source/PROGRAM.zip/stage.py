"""One resource-bounded, source-bound numerical/export stage."""

import os
import time

PROCESS_STARTED=time.monotonic()
os.environ.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
                  CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1')

import argparse
from datetime import datetime, timezone
from pathlib import Path
import resource
import sys
import traceback

import mpmath as mp
import numpy as np
import torch

from terminal_inputs import PLAN_SHA256, read, require, save, sha, verify_bound
from export_checkpoint import export_checkpoint, imported_source_receipt
from numerical_stages import domain_stage, original_prefix_stage, finite_stage
from logrisk_stage import log_risk_stage


def main():
    require(__debug__,'assertions must remain enabled')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--receipt',type=Path,required=True)
    parser.add_argument('--receipt-sha256',required=True)
    parser.add_argument('--plan',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--stage',required=True)
    args=parser.parse_args()
    target=args.output/(args.stage+'.json')
    require(not target.exists(),'stage output already exists; no silent retry')
    receipt=read(args.receipt,args.receipt_sha256);plan=read(args.plan,PLAN_SHA256)
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    sources={str(p):sha(p) for p in Path(__file__).parent.glob('*.py')}
    report={'schema':'terminal-HCSN-stage-v1','stage':args.stage,
            'started_utc':datetime.now(timezone.utc).isoformat(),
            'input_receipt_sha256':sha(args.receipt),'plan_sha256':sha(args.plan),
            'auditor_sources_before':sources,'python':sys.version,'torch':torch.__version__,
            'numpy':np.__version__,'mpmath':mp.__version__,
            'original_terminal_kind':receipt['terminal_kind'],
            'training_adequacy_established':receipt['training_adequacy_established'],
            'whole_training_domain_admission':'HOLD','scientific_admission':'HOLD'}
    try:
        verify_bound(receipt)
        require(sha(args.plan)==PLAN_SHA256 and sha(args.receipt)==args.receipt_sha256,'fixed plan/input receipt changed during stage')
        if args.stage.startswith('export-'):
            result=export_checkpoint(receipt,plan,args.output,args.stage.split('-')[1])
        elif args.stage.startswith('domain-'):
            result=domain_stage(receipt,plan,args.output,args.stage.split('-')[1])
        elif args.stage=='original-prefix':
            result=original_prefix_stage(receipt)
        elif args.stage=='logrisk':
            result=log_risk_stage(receipt,plan,args.output)
        elif args.stage.startswith('finite-'):
            _,which,index=args.stage.split('-')
            result=finite_stage(receipt,plan,args.output,which,int(index))
        else:
            raise ValueError('unknown frozen stage')
        verify_bound(receipt)
        require(all(sha(p)==d for p,d in sources.items()),'auditor source changed')
        loaded=imported_source_receipt(receipt)
        report.update(execution_status='completed',result=result,original_inputs_unchanged=True,auditor_source_unchanged=True,
                      actual_loaded_numerical_module_sources=loaded)
    except Exception:
        report.update(execution_status='failed',error=traceback.format_exc())
    report.update(finished_utc=datetime.now(timezone.utc).isoformat(),
                  wall_sample_seconds=time.monotonic()-PROCESS_STARTED,
                  CPU_sample_seconds=time.process_time(),peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
                  timer_scope='Child sample before final serialization; controller records complete waited wall/CPU/RSS separately.')
    report['fixed_plan_sha256_after']=sha(args.plan)
    report['input_receipt_sha256_after']=sha(args.receipt)
    if report['fixed_plan_sha256_after']!=PLAN_SHA256 or report['input_receipt_sha256_after']!=args.receipt_sha256:
        report['execution_status']='failed_input_identity'
    save(target,report)
    print({'stage':args.stage,'execution_status':report['execution_status']},flush=True)
    return 0 if report['execution_status']=='completed' else 1


if __name__=='__main__':
    raise SystemExit(main())
