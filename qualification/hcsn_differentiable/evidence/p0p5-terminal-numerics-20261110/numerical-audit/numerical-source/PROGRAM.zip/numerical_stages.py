"""Bounded numerical checks of exact exported laws; preserve stress failures."""

import math
import json
from pathlib import Path

import mpmath as mp
import torch

from terminal_inputs import read, require, sha
from export_checkpoint import bind_runtime


PARAMETERS = ('log_boundary','mu','sigma','absolute_reset','discount')


def configuration(visit):
    from qualification.hcsn_differentiable.contract import GridSpec, PhysicalParameters
    from frozen_tables import FrozenTableOperator
    grid = GridSpec(**visit['grid'])
    config = visit['operator']
    operator = FrozenTableOperator(grid, **{k:config[k] for k in
        ('active_reward','hit_reward','terminal_reward','reset_enabled')})
    require(operator.configuration()==config and operator.reset_enabled, 'reference operator configuration differs')
    values = [visit['parameters'][name] for name in PARAMETERS]
    params = PhysicalParameters(*(torch.tensor(v,dtype=torch.float64) for v in values))
    return grid, operator, values, params


def load_export(out, which):
    report = read(Path(out)/('export-'+which+'.json'))['result']
    require(report['execution_status']=='completed_export', 'export did not complete')
    require(sha(Path(out)/report['laws_file'])==report['laws_sha256'], 'starting laws changed')
    return report


def domain_stage(receipt, plan, out, which):
    bind_runtime(receipt['source'])
    from qualification.hcsn_differentiable.training_domain import read_trace, source_hashes
    from qualification.hcsn_differentiable.training_domain_audit import _basis_gradients, _reference
    from qualification.hcsn_differentiable.value import perpetual_basis_value
    report = load_export(out,which)
    records, pressure = [], []
    cached = {}
    with torch.no_grad(), mp.workdps(80):
        for exported in report['traces']:
            path = Path(out)/exported['trace']
            require(sha(path)==exported['trace_sha256'], 'exported trace changed')
            header, visits, footer, _ = read_trace(path)
            require(header['sources']==source_hashes() and footer['source_unchanged'], 'trace/source mismatch')
            for visit in visits:
                grid, operator, values, params = configuration(visit)
                key = json.dumps([values, visit['grid'], visit['operator']],sort_keys=True)
                if key not in cached:
                    gradient, reference_gradient = _basis_gradients(grid,values,operator)
                    cached[key] = (operator,gradient,reference_gradient,
                                   _reference(grid,values,mp.mpf(operator.active_reward),mp.mpf(operator.hit_reward)))
                operator,gradient,reference_gradient,reference_value = cached[key]
                prior = torch.tensor(visit['prior'],dtype=torch.float64)
                posterior = torch.tensor(visit['posterior'],dtype=torch.float64)
                duration = torch.tensor(visit['dt'],dtype=torch.float64)
                expected = torch.tensor(visit['expected_events'],dtype=torch.float64)
                require(bool(torch.isfinite(prior).all() and torch.isfinite(posterior).all()), 'nonfinite recorded probability')
                require(bool((prior>=0).all() and (posterior>=0).all()), 'negative recorded probability')
                flow = operator.advance(prior,prior[...,None],duration,params)
                mass = float(torch.cat((flow.mass_residual.abs(),(prior.sum(-1)-1).abs(),(posterior.sum(-1)-1).abs())).max())
                event_error = float((flow.expected_events-expected).abs().max())
                basis_error = float((gradient-reference_gradient).abs().max())
                basis_scaled = float(((gradient-reference_gradient).abs()/reference_gradient.abs().clamp_min(1)).max())
                weighted_error = float(((posterior@gradient-posterior@reference_gradient).abs()/(posterior@reference_gradient).abs().clamp_min(1)).max())
                row = {'episode_id':exported['episode_id'],'position':visit['position'],'dt':visit['dt'],
                       'mass_error':mass,'event_replay_error':event_error,'basis_gradient_absolute_error':basis_error,
                       'basis_gradient_scaled_error':basis_scaled,
                       'posterior_weighted_gradient_scaled_error':weighted_error,
                       'tail_mass':float(posterior[0,grid.active_cells]),
                       'phase_mass':float(posterior[0,grid.active_count:].sum()),
                       'first_cell_mass':float(posterior[0,0]),'batch_samples':len(posterior),
                       'passed':mass<=5e-11 and event_error<=5e-11 and basis_error<=2e-9 and basis_scaled<=2e-9 and weighted_error<=2e-9}
                records.append(row)
                if which=='best' and {'episode_id':exported['episode_id'],'position':visit['position']} in plan['state_and_gradient_checks']['perpetual_pressure_sentinels']:
                    dt=float(duration[0]) if float(duration[0])>0 else grid.refractory/2
                    actual=float(posterior[0]@perpetual_basis_value(operator,params,dt).value)
                    reference=float(mp.fsum(mp.mpf(float(w))*v for w,v in zip(posterior[0],reference_value)))
                    error=abs(actual-reference)/max(1,abs(reference))
                    pressure.append({'episode_id':exported['episode_id'],'position':visit['position'],'dt':dt,
                        'projected':actual,'reference':reference,'scaled_error':error,'passed':error<=.01,
                        'scope':'Artificial infinite repeat, separate from real finite schedule.'})
    require(which!='best' or len(pressure)==len(plan['state_and_gradient_checks']['perpetual_pressure_sentinels']), 'missing declared pressure sentinel')
    return {'execution_status':'completed_domain_checks','which':which,'records':records,
            'state_gradient_checks_passed':bool(records) and all(r['passed'] for r in records),
            'gradient_scope':'All basis derivatives and every exported batch posterior held fixed;80digit central differences, step1e-25.',
            'basis_gate_scope':'Original absolute2e-9 guard is retained in addition to scaled2e-9; no old threshold is relaxed.',
            'pressure_sentinels':pressure,'pressure_all_passed':all(r['passed'] for r in pressure) if which=='best' else None,
            'pressure_scope_status':'completed_declared_sentinels' if which=='best' else 'not_applicable_last_checkpoint',
            'whole_training_domain_admission':'HOLD'}


def original_prefix_stage(receipt):
    bind_runtime(receipt['source'])
    from qualification.hcsn_differentiable.training_domain_audit import audit_trace
    result=audit_trace(receipt['original_training_trace'],max_records=16)
    require(result['trace_sha256']==receipt['original_training_trace_sha256'], 'original trace changed')
    require(result['data_sha256']==receipt['fit_plan']['manifest_sha256'] and
            result['configuration_sha256']==receipt['report']['plan_sha256'], 'training trace input binding differs')
    result['execution_status']='completed_original_prefix_audit'
    result['scope']='Unmodified original trace; first16 retained vector rows. Truncation and incomplete coverage are not repaired.'
    return result


def finite_stage(receipt, plan, out, which, index):
    bind_runtime(receipt['source'])
    from qualification.hcsn_differentiable.training_domain_finite import audit_finite_schedule
    from qualification.hcsn_differentiable.training_domain import read_trace
    report=load_export(out,which)
    laws=torch.load(Path(out)/report['laws_file'],weights_only=True)
    law=laws[str(index)]
    fixtures=plan['finite_schedule_fixtures_per_primary_checkpoint'] if which=='best' else [plan['last_checkpoint_fixture']]
    require(law['fixture']==fixtures[index] and law['durations']==fixtures[index]['durations'], 'finite fixture differs')
    trace=Path(out)/(which+'-'+law['fixture']['episode_id']+'.jsonl')
    _,visits,_,digest=read_trace(trace)
    require(digest==law['trace_sha256'], 'finite law trace identity differs')
    require(torch.equal(law['probability'],torch.tensor(visits[law['trace_position']]['posterior'][0],dtype=torch.float64)), 'finite starting law is not the actual exported posterior')
    grid,operator,values,params=configuration(law)
    # Use the original production operator, without memoization strategy changes.
    from qualification.hcsn_differentiable.operator import DifferentiableDistributionOperator
    exact=DifferentiableDistributionOperator(grid,**{k:law['operator'][k] for k in ('active_reward','hit_reward','terminal_reward','reset_enabled')})
    result=audit_finite_schedule(law['probability'],grid,params,law['durations'],reference_order=8,operator=exact)
    result.update(execution_status='completed_finite_fixture',which=which,fixture_index=index,
                  fixture=law['fixture'],checkpoint_sha256=law['checkpoint_sha256'],trace_sha256=digest,
                  absolute_errors=[abs(a-b) for a,b in zip(result['projected'],result['reference'])],
                  relative_errors=[abs(a-b)/abs(b) if b!=0 else None for a,b in zip(result['projected'],result['reference'])],
                  relative_error_gate=False,whole_training_domain_admission='HOLD')
    return result
