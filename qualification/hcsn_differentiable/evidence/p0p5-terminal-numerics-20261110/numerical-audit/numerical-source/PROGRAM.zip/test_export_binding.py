"""Synthetic model/data fixtures for export binding; no real fit/optimizer step."""

import copy
import json
import os
from pathlib import Path
import random
import tempfile
import unittest

import torch

from export_checkpoint import bind_runtime, export_checkpoint
from numerical_stages import domain_stage, finite_stage
from logrisk_stage import log_risk_stage
from terminal_inputs import construction_from_plan, save, sha


SOURCE=Path(os.environ.get('HCSN_NUMERICS_TEST_SOURCE','/workspace/scratch/c385a7439f8e/v8-local-validation/source'))


class ExportBindingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        cls.cores=bind_runtime(SOURCE)

    def fixture(self, root):
        grid={'active_cells':8,'endpoint':2.0,'initial_log_std':.08,'phase_cells':2,
              'quadrature_order':8,'refractory':.2,'tail_rate':1.0}
        fit={'arm':'hcsn','width':2,'seed':101,'hcsn_grid_json':grid,'train_shared':False,
             'cache_frozen_tables':True,'learn_core_adapter':True,'batch_size':1,'manifest_sha256':None}
        model=self.cores.CoreStudyModel(**construction_from_plan(fit))
        initial={k:v.clone() for k,v in model.state_dict().items()}
        trained=[(n,p) for n,p in model.named_parameters() if p.requires_grad]
        optimizer=torch.optim.AdamW([p for _,p in trained],lr=.001,weight_decay=0)
        state=optimizer.state_dict()
        # Explicit synthetic state, not a trained checkpoint or executed step.
        for identity,(_,parameter) in zip(state['param_groups'][0]['params'],trained):
            state['state'][identity]={'step':torch.tensor(1.),'exp_avg':torch.zeros_like(parameter),'exp_avg_sq':torch.zeros_like(parameter)}
        prepared=root/'data';prepared.mkdir()
        x=[[0.0]*25 for _ in range(4)]
        for row in x:row[12:15]=[1.,1.,1.]
        episode={'id':'A00-0','partition':'train','sequence':'A00','x':x,'dt':[0.,.02,.03,.01],
                 'delta_ticks':[0,200000,300000,100000],'y':[0,1,2,3]}
        save(prepared/'episode.json',episode)
        episode_sha=sha(prepared/'episode.json')
        save(prepared/'data-manifest.json',{'mode':'all-development','confirmation_access':False,
             'episodes':[{'id':'A00-0','path':'episode.json','sha256':episode_sha}]})
        fit['manifest_sha256']=sha(prepared/'data-manifest.json')
        from hcsn_study_support import sources
        report={'model_configuration':model.construction_configuration,'episodes_train':1,'main_updates':1,
                'source_before':sources(model),'torch_version':torch.__version__,
                'optimizer_groups':[{'parameter_names':[n for n,_ in trained],'lr':.001,'weight_decay':0}]}
        rng=random.Random(101);order=[0];rng.shuffle(order)
        checkpoint={'model':initial,'model_configuration':model.construction_configuration,'optimizer':state,
                    'torch_rng':torch.get_rng_state(),'order_rng':rng.getstate(),'epochs_completed':1,
                    'main_updates':1,'data_manifest_sha256':fit['manifest_sha256']}
        models=root/'fit';models.mkdir()
        torch.save({'model':initial,'model_configuration':model.construction_configuration},models/'initial.pt')
        torch.save(checkpoint,models/'best.pt');torch.save(checkpoint,models/'last.pt')
        output=root/'output';output.mkdir()
        receipt={'root':str(models),'source':str(SOURCE),'prepared':str(prepared),'fit_plan':fit,'report':report,
                 'best_epoch':1,'complete_epochs':1}
        save(output/'input-receipt.json',receipt)
        fixture={'episode_id':'A00-0','posterior_after_position':0,'intervals':2,'durations':[.02,.03],'future_observations':False}
        plan={'data_manifest_sha256':fit['manifest_sha256'],
              'fixed_episodes':[{'id':'A00-0','partition':'train','events':4,'sha256':episode_sha}],
              'expected_construction':{'grid':grid},'supplemental_export':{'primary_episodes_per_checkpoint':['A00-0'],'last_episode_per_checkpoint':'A00-0'},
              'finite_schedule_fixtures_per_primary_checkpoint':[fixture],'last_checkpoint_fixture':fixture,
              'state_and_gradient_checks':{'perpetual_pressure_sentinels':[{'episode_id':'A00-0','position':i} for i in (0,1,2)]}}
        return receipt,plan,output

    def test_same_wrapper_export_law_and_domain_bindings(self):
        with tempfile.TemporaryDirectory() as folder:
            receipt,plan,out=self.fixture(Path(folder))
            before=sha(Path(receipt['root'])/'best.pt')
            exported=export_checkpoint(receipt,plan,out,'best')
            self.assertTrue(exported['wrapper_tensors_unchanged'])
            self.assertEqual(exported['traces'][0]['records'],4)
            self.assertEqual(exported['terminal_updates_beyond_this_complete_epoch_checkpoint'],0)
            self.assertEqual(sha(Path(receipt['root'])/'best.pt'),before)
            save(out/'export-best.json',{'result':exported})
            domain=domain_stage(receipt,plan,out,'best')
            self.assertEqual(len(domain['records']),4)
            self.assertEqual(len(domain['pressure_sentinels']),3)
            self.assertTrue(domain['state_gradient_checks_passed'])
            result=finite_stage(receipt,plan,out,'best',0)
            self.assertEqual(result['execution_status'],'completed_finite_fixture')
            self.assertFalse(result['relative_error_gate'])
            risk=log_risk_stage(receipt,plan,out)
            self.assertTrue(risk['zero_deadline_passed'])
            self.assertIn('direct_FD_inconclusive_count',risk)
            self.assertTrue(all(p['primary_passed'] for p in risk['queries']))

    def test_wrong_declared_future_gaps_fail_export_binding(self):
        with tempfile.TemporaryDirectory() as folder:
            receipt,plan,out=self.fixture(Path(folder))
            plan['finite_schedule_fixtures_per_primary_checkpoint'][0]['durations']=[.03,.02]
            with self.assertRaisesRegex(ValueError,'gap selection'):
                export_checkpoint(receipt,plan,out,'best')

    def test_actual_loaded_module_map_must_equal_original_bound_source(self):
        with tempfile.TemporaryDirectory() as folder:
            receipt,plan,out=self.fixture(Path(folder))
            first=next(iter(receipt['report']['source_before']))
            receipt['report']['source_before'][first]='0'*64
            with self.assertRaisesRegex(ValueError,'dependency source map differs'):
                export_checkpoint(receipt,plan,out,'best')


if __name__=='__main__':unittest.main()
