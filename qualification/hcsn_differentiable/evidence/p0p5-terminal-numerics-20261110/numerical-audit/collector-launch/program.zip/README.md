# Terminal-only numerical evidence collector

This program collects existing artifacts of the uniquely launched terminal-HCSN numerical audit. It never imports Torch, mpmath, a trained model, or the numerical oracle. It never trains, evaluates a model, retries a numerical fixture, changes a difference step, extends the original budget, or writes inside any original audit/source/launch directory.

## Original attempt remains authoritative

The original key is `hcsn-terminal-numerics-audit-c385-v1`, with controller PID1969758 and the predeclared10800-second ceiling. The collector requires the original final launcher and bootstrap receipts, verifies the exact controller and hard limit, and checks that no original numerical process is executing before creating its separate output. An unreadable known or same-user process is an unresolved absence check and fails closed; unrelated denied reads are retained.

The frozen plan SHA256 is `6ae8bb984d994f0d3fa6963e37d0f4180366a3a7bafd316d887e74f2ef1c7d26`; the original auditor manifest SHA256 is `154826bbabda6cd44b552e1215f4b5ea5d471ff7b6c2fd7e5abd927ee753f75e`. The declared roster is exactly96 stages, including60 finite fixtures. Nothing is reordered or rerun. Original missing aggregates, stage timeouts, invalid artifacts, started-without-completion observations, and unobserved starts remain distinct.

## Interpretation

`qualified_named_finite_fixture` is a conservative metadata classification of an already computed, source-bound original result. It requires the original completed result/outer/stream hash chain, final source and input closure, the original stored scalar gates, and recorded outer budget bounds. It establishes no new whole-domain, training-adequacy, or scientific admission. The additional metadata closure guard also withholds this named-fixture flag if actual recorded outer wall exceeds its granted wall, any recorded RSS peak exceeds the original2GiB limit, or the original limit has changed. Raw original pass/failure fields remain visible and unchanged.

The finite scaled error is `abs(projected-reference)/max(1,abs(reference)) <= .01`. This is not a blanket relative1% gate. Reference-order sensitivity and mass gates are2e-8 and5e-11. No complete continuum-reference error bound is inferred from order doubling. Log-risk primary failure, ordinary-FP64 FD inconclusive/disagreement counts, original-prefix limitations, and repeated-tiny-gap pressure results are preserved separately.

## Cost and finality

Bootstrap, launcher, controller and per-stage timers are nested. They must not be added together. A hard process-group kill can leave an active stage un-reaped by the killed controller; whole-attempt waited CPU is then marked an incomplete lower bound, and the missing CPU is not reconstructed from wall time. Existing observer CPU samples overlap waited CPU and are not added. Energy remains unmeasured. This separate metadata collection has its own CPU/wall/RSS samples and no numerical-computation credit.

The collector hashes original outputs, exact source capsule, input receipts, trained checkpoints as opaque bytes, original traces, prepared manifest and six fixed episodes. It creates a new archive and verifies CRC and every original member hash, then rechecks all original bytes and bound inputs. It never deserializes a model checkpoint.

**Archive-internal RESULT and SUMMARY are provisional until the external `COLLECTION-RECEIPT.json` says `metadata_collection_status=completed` and its archive SHA256 matches.** A failed collector can leave a partial/provisional archive; that archive must not be treated as finalized. The external receipt is written after stability and complete archive checks, so it cannot be included in its own hashed archive. It must be preserved alongside the archive. Original artifact byte identity and collection success are distinct from numerical/scientific qualification.

## Validation

Tests use copies of an already computed128-gap original JSON and outer receipt, plus explicit metadata corruption. They do not execute model or numerical functions. They cover missing outer records, changed hashes, NaNs, altered scaled values, source/receipt changes, ordinary-FD failure preservation, actual outer wall/RSS excess, changed resource limit, output isolation, terminal/ceiling guards, and unreadable known-process fail-closed behavior. The provisional11-test source/receipt and the independent four budget counterexamples remain separate historical evidence; final validation is recorded against the final source bytes.
