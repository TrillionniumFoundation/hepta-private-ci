from datetime import datetime, timezone
import hashlib,json,os,platform,resource,sys,time,traceback,unittest
from pathlib import Path
out=Path(sys.argv[1]); root=Path.cwd()
sys.path.insert(0,str(root))
started=time.perf_counter(); cpu=time.process_time()
paths=['qualification/hcsn_differentiable/'+name for name in (
'contract.py','operator.py','network.py','encoder.py','checkpoint.py','value.py','regenerative.py',
'training_domain.py','training_domain_audit.py','training_domain_projected_gradients.py',
'test_training_domain_projected_gradients.py','test_training_domain_strict_trace.py','tests/test_training_domain.py')]
def sources():
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=sources()
report={'schema':'hcsn-projected-native-tests-v1','source_head':'5a1db6f9da54d877e1660c4c964df0e227745719',
 'host_alias':'desktop','started_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,
 'python_executable':sys.executable,'platform':platform.platform(),'source_before':before,
 'scientific_admission':'HOLD_NO_GO','full_numerical_admission':'HOLD_NO_GO',
 'formal_fits_started':0,'independent_c2_replays':0,'phases':[]}
rc=2
try:
 import torch,numpy,mpmath
 from qualification.hcsn_differentiable.run_qualification import RecordedResult,_json_safe
 report['runtime']={'torch':torch.__version__,'numpy':numpy.__version__,'mpmath':mpmath.__version__,
                    'execution_device':'cpu','cuda_build':torch.version.cuda,'cuda_visible':torch.cuda.is_available()}
 assert torch.__version__=='2.8.0+cpu' and numpy.__version__=='2.5.4' and mpmath.__version__=='1.3.0'
 assert sys.version_info[:3]==(3,12,3)
 torch.set_num_threads(1); torch.set_num_interop_threads(1); torch.use_deterministic_algorithms(True)
 for label,names in [
 ('projected_gradients',['qualification.hcsn_differentiable.test_training_domain_projected_gradients']),
 ('existing_trace_regression',['qualification.hcsn_differentiable.tests.test_training_domain','qualification.hcsn_differentiable.test_training_domain_strict_trace'])]:
  suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in names)
  with (out/(label+'.log')).open('x') as stream:
   result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=RecordedResult).run(suite)
  record={'label':label,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
          'skipped':len(result.skipped),'success':result.wasSuccessful() and result.testsRun>0 and not result.skipped,'tests':result.records}
  report['phases'].append(record)
  if label=='projected_gradients':
   from qualification.hcsn_differentiable import test_training_domain_projected_gradients as fixture
   trace=getattr(fixture.ProjectedGradientTests,'trace_bytes',None)
   if trace is not None:
    (out/'fixture-trace.jsonl').write_bytes(trace)
    report['fixture_trace_sha256']=hashlib.sha256(trace).hexdigest()
 rc=0 if all(p['success'] for p in report['phases']) and len(report['phases'])==2 else 1
 report['status']='passed_scoped_tests' if rc==0 else 'failed_scoped_tests'
except Exception:
 report.update(status='runner_error',detail=traceback.format_exc())
finally:
 after=sources()
 report.update(source_after=after,source_unchanged=before==after,wall_seconds=time.perf_counter()-started,
  process_cpu_seconds=time.process_time()-cpu,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
  finished_utc=datetime.now(timezone.utc).isoformat(),returncode=rc)
 if before!=after: report['status']='source_changed';rc=2;report['returncode']=rc
 def safe(v):
  if isinstance(v,float):
   import math
   return v if math.isfinite(v) else {'nonfinite':str(v)}
  if isinstance(v,dict): return {k:safe(x) for k,x in v.items()}
  if isinstance(v,(list,tuple)): return [safe(x) for x in v]
  return v
 (out/'native-report.json').write_text(json.dumps(safe(report),indent=2,sort_keys=True,allow_nan=False)+'\n')
 print(json.dumps({'status':report['status'],'returncode':rc,'phases':[{k:p[k] for k in ('label','tests_run','failures','errors','skipped')} for p in report['phases']]}),flush=True)
raise SystemExit(rc)
