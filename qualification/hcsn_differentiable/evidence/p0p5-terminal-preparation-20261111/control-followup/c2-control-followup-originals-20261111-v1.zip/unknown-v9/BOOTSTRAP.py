import base64,hashlib,json,os,sys
from pathlib import Path,PurePosixPath
payload=json.load(sys.stdin)
raw=base64.b64decode(payload['manifest_raw_base64'],validate=True)
assert hashlib.sha256(raw).hexdigest()=='44fb4265b3b58e7c158baf1c86ca70ec64894b46da20aaa84c61c5fe3bf91d6f'
manifest=json.loads(raw)
root=Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training/c2-epoch-observer-program-v9');root.mkdir(exist_ok=False)
assert len(payload['files'])==len(manifest) and {x['path'] for x in payload['files']}==set(manifest)
for item in payload['files']:
 relative=PurePosixPath(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
 data=base64.b64decode(item['data_base64'],validate=True)
 assert {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}==manifest[item['path']]
 p=root/item['path'];p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as stream:stream.write(data)
with (root/'DEPLOYMENT-MANIFEST.json').open('xb') as stream:stream.write(raw)
os.execv(sys.executable,[sys.executable,'-B',str(root/'observer.py')])
