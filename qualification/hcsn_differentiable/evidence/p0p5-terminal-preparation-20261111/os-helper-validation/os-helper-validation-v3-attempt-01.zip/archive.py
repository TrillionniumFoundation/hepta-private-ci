"""Seal the one completed new validation attempt without rerunning it."""
from pathlib import Path
import hashlib
import json
import time
import zipfile

START = time.perf_counter()
ROOT = Path(__file__).resolve().parent
ATTEMPT = ROOT/'attempt-01'

def ident(path):
    raw = path.read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def emit(path, value):
    with path.open('x') as f:
        json.dump(value,f,sort_keys=True,indent=2,allow_nan=False)
        f.write('\n')

outer = json.loads((ATTEMPT/'output/RESULT.json').read_bytes())
suite = json.loads((ATTEMPT/'output/worker/RESULT.json').read_bytes())
terminal = json.loads((ATTEMPT/'POLL1-RAW.json').read_bytes())
assert terminal['raw']['exit_code']==0 and outer['status']=='completed_all_new_tests_passed'
assert suite['passed'] is True and suite['tests_run']==9 and not suite['old_lost_test_credit_inherited']
assert outer['source_before']==outer['source_after'] and not outer['final_remaining_original_identities']
for p, expected in outer['source_before'].items():
    assert ident(Path(p))==expected
cases=[]
for path in sorted((ATTEMPT/'output/worker').glob('test_*/OBSERVE-ORIGINAL.json')):
    observed=json.loads(path.read_bytes())
    cleanup=json.loads((path.parent/'INDEPENDENT-CLEANUP.json').read_bytes())
    cases.append({'case':path.parent.name,'observe_identity':ident(path),
                  'direct_process_started':observed['process_started'],'direct_returncode':observed['returncode'],
                  'admitted':observed['process_gate_passed'],'wait4_CPU_seconds':observed['wait4_child_CPU_seconds'],
                  'adopted_wait4':observed.get('adopted_child_wait4'),
                  'helper_remaining_or_unknown':observed['unreaped_descendants'],'independent_cleanup':cleanup})
emit(ROOT/'SUMMARY.json',{'schema':'new-os-helper-validation-v3-summary','status':'nine_new_cases_passed',
    'actual_execution_attempts':1,'software_tests_run':9,'real_direct_child_cases':8,'refused_before_spawn_cases':1,
    'cases':cases,'exact_helper_sha256':suite['source_sha256'],
    'whole_guard_wall_prefix_seconds':outer['whole_guard_wall_prefix_seconds'],
    'exact_worker_wait4_CPU_seconds':outer['known_disjoint_wait4_CPU_seconds'],
    'guard_self_CPU_prefix_seconds':outer['guard_self_CPU_prefix_seconds'],
    'observed_aggregate_peak_RSS_bytes':outer['observed_aggregate_peak_RSS_bytes'],
    'source_unchanged':True,'all_original_test_process_identities_reaped':True,
    'scope':['Fresh cloud stdlib lifecycle validation, not recovery of the lost old twelve-test result.',
             'Cases07/08 use explicit observation/kill fault injection around actual tiny child processes; raw original observer rows remain separate from independent cleanup.',
             'Production complete_os_envelope authorization/artifact checking was not invoked.',
             'External timeout60 returned exit0. Aggregate RSS is sampled and bounded by the independent guard; per-process AS128MiB is kernel-enforced. No cgroup-memory-hardcap claim.',
             'Complete worker wait4 includes its reaped children. Nested per-case CPU must not be added again. Guard self CPU/wall are prefixes; exact outer timeout/shell/guard exit CPU is unavailable.',
             'No native operator call, C2 work, model import/forward/optimizer, E access or numerical oracle.'],
    'old_lost_test_credit_inherited':False,'production_deployment_authorized_by_this_result':False})
files=sorted(p for p in ATTEMPT.rglob('*') if p.is_file())+[ROOT/'SUMMARY.json',Path(__file__)]
before={str(p.relative_to(ROOT)):ident(p) for p in files}
emit(ROOT/'MANIFEST.json',{'schema':'source-and-raw-result-manifest-v1','files':before})
archive=ROOT/'os-helper-validation-v3-attempt-01.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in files+[ROOT/'MANIFEST.json']: z.write(p,str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for member,expected in before.items():
        raw=z.read(member)
        assert {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}==expected
after={str(p.relative_to(ROOT)):ident(p) for p in files}
assert before==after
emit(ROOT/'ARCHIVE-RECEIPT.json',{'archive':str(archive),'identity':ident(archive),'members':len(before)+1,
    'payload_SHA_and_CRC_verified':True,'source_and_raw_files_unchanged':True,
    'packing_body_wall_seconds':time.perf_counter()-START,'packing_scope':'Metadata/archive only; no repeat execution.'})
copies=[('SUMMARY.json','SUMMARY.json'),('attempt-01/PLAN.json','PLAN.json'),
        ('attempt-01/output/RESULT.json','OUTER-RESULT.json'),('attempt-01/output/worker/RESULT.json','SUITE-RESULT.json'),
        ('attempt-01/output/stderr','TEST-STDERR.txt'),(archive.name,archive.name),('ARCHIVE-RECEIPT.json','ARCHIVE-RECEIPT.json')]
emit(ROOT/'COPY_LIST.json',{'schema':'copy-list-v1','files':[{'source':str(ROOT/p),'suggested_name':n,**ident(ROOT/p)} for p,n in copies]})
print(json.dumps({'copy_list':str(ROOT/'COPY_LIST.json'),**ident(ROOT/'COPY_LIST.json'),'archive':ident(archive)}))
