"""Independent local 60s/256MiB validation guard; never imports the tested helper."""
import time
START = time.monotonic()
import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys

SOURCE, OUTPUT = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
OUTPUT.mkdir(parents=True,exist_ok=False)
SELF, CHILD, KNOWN = os.getpid(), None, {}
PEAK, ERRORS, REAPED = 0, [], []
LIMIT = 256*1024**2
libc = ctypes.CDLL(None,use_errno=True)
assert libc.prctl(36,1,0,0,0)==0
subreaper = ctypes.c_int()
assert libc.prctl(37,ctypes.byref(subreaper),0,0,0)==0 and subreaper.value==1
resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))

def identity(p):
    b=p.read_bytes()
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def stat(pid):
    b=Path(f'/proc/{pid}/stat').read_bytes(); f=b[b.rfind(b')')+2:].split()
    return {'pid':pid,'ppid':int(f[1]),'start':int(f[19]),'rss':max(0,int(f[21]))*os.sysconf('SC_PAGE_SIZE')}

def scan():
    global PEAK
    found={}
    for p in Path('/proc').iterdir():
        if p.name.isdecimal():
            try: found[int(p.name)]=stat(int(p.name))
            except (FileNotFoundError,ProcessLookupError): pass
            except Exception as e:
                if int(p.name) in KNOWN: ERRORS.append(str(e))
    owned={pid for pid,r in found.items() if r['ppid']==SELF or pid==CHILD}
    while True:
        grown=owned|{pid for pid,r in found.items() if r['ppid'] in owned}
        if grown==owned: break
        owned=grown
    owned|={pid for pid,r in found.items() if pid in KNOWN and r['start']==KNOWN[pid]}
    for pid in owned: KNOWN.setdefault(pid,found[pid]['start'])
    PEAK=max(PEAK,found.get(SELF,{}).get('rss',0)+sum(found[pid]['rss'] for pid in owned))
    return {pid:found[pid] for pid in owned}

def kill_current():
    for pid,r in scan().items():
        if r['start']==KNOWN[pid]:
            try: os.kill(pid,signal.SIGKILL)
            except ProcessLookupError: pass
            except Exception as e: ERRORS.append(str(e))

def reap():
    while True:
        try: pid,status,usage=os.wait4(-1,os.WNOHANG)
        except ChildProcessError: return
        if not pid: return
        REAPED.append({'pid':pid,'returncode':os.waitstatus_to_exitcode(status),
            'CPU_seconds':usage.ru_utime+usage.ru_stime,'peak_RSS_bytes':usage.ru_maxrss*1024,
            'observed_monotonic':time.monotonic()})

before={str(p):identity(p) for p in sorted(SOURCE.glob('*')) if p.is_file()}
row={'schema':'independent-os-validation-guard-v3','status':'failed_or_incomplete',
     'external_timeout_seconds':60,'internal_kill_deadline_seconds':50,'aggregate_RSS_limit_bytes':LIMIT,
     'memory_enforcement':'independent sampled aggregate RSS guard plus inherited per-process 128MiB AS limit',
     'old_lost_test_credit_inherited':False,'source_before':before,'automatic_retry':False,
     'model_operations':0,'native_operator_calls':0,'timed_out':False,'rss_exceeded':False}
worker=None
try:
    command=[sys.executable,'-I','-B',str(SOURCE/'worker.py'),str(SOURCE),str(OUTPUT/'worker')]
    row['argv']=command
    with (OUTPUT/'stdout').open('xb') as stdout,(OUTPUT/'stderr').open('xb') as stderr:
        row['popen_started_monotonic']=time.monotonic()
        worker=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
        CHILD=worker.pid; row['worker_pid']=CHILD
        while time.monotonic()-START<54:
            scan(); reap()
            if any(r['pid']==CHILD for r in REAPED): break
            row['timed_out']|=time.monotonic()-START>=50
            row['rss_exceeded']|=PEAK>LIMIT
            if row['timed_out'] or row['rss_exceeded'] or ERRORS: kill_current()
            time.sleep(.01)
except Exception as e:
    ERRORS.append(type(e).__name__+': '+str(e))
finally:
    until=min(START+58,time.monotonic()+3)
    while time.monotonic()<until:
        alive=scan(); reap()
        if not alive: break
        kill_current(); time.sleep(.01)
    final=scan(); reap()
    after={str(p):identity(p) for p in sorted(SOURCE.glob('*')) if p.is_file()}
    direct=next((r for r in REAPED if r['pid']==CHILD),None)
    if worker is not None and direct is not None: worker.returncode=direct['returncode']
    suite_path=OUTPUT/'worker/RESULT.json'
    suite=json.loads(suite_path.read_bytes()) if suite_path.is_file() else None
    passed=bool(direct and direct['returncode']==0 and suite and suite['passed'] and suite['tests_run']==9
        and not final and not ERRORS and not row['timed_out'] and not row['rss_exceeded']
        and before==after and time.monotonic()-START<60 and PEAK<=LIMIT)
    row.update(status='completed_all_new_tests_passed' if passed else 'failed_or_incomplete',
        source_after=after,source_unchanged=before==after,final_remaining_original_identities=final,
        errors=ERRORS,full_wait4=REAPED,worker_terminal=direct,observed_aggregate_peak_RSS_bytes=PEAK,
        known_disjoint_wait4_CPU_seconds=sum(r['CPU_seconds'] for r in REAPED),
        guard_self_CPU_prefix_seconds=time.process_time(),whole_guard_wall_prefix_seconds=time.monotonic()-START,
        suite_result=identity(suite_path) if suite_path.is_file() else None,
        cost_scope='Outer wait4 includes worker and children reaped by worker; separately adopted outer wait4 rows are disjoint. Do not add nested observe or case CPU again. Guard prefix excludes its own final JSON/OS exit.')
    with (OUTPUT/'RESULT.json').open('x') as f: json.dump(row,f,sort_keys=True,indent=2); f.write('\n')
print(json.dumps({'status':row['status'],'tests':suite['tests_run'] if suite else None,
                  'whole_guard_wall_prefix_seconds':row['whole_guard_wall_prefix_seconds'],
                  'observed_aggregate_peak_RSS_bytes':PEAK,'output':str(OUTPUT)}),flush=True)
raise SystemExit(0 if passed else 1)
