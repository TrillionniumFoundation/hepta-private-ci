"""Nine new bounded lifecycle tests against the exact restored helper; no models."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import time
import unittest
from unittest import mock

SOURCE, OUTPUT = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
OUTPUT.mkdir(parents=True, exist_ok=False)
EXPECTED = 'f58ca60428d3abafea377ca64e1d71040df98c4f149adce88436951187c990d6'
assert hashlib.sha256((SOURCE/'os_processes.py').read_bytes()).hexdigest() == EXPECTED
spec = importlib.util.spec_from_file_location('exact_restored_os_processes', SOURCE/'os_processes.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
CASES = []

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')

def external_cleanup(tree):
    """Separate test cleanup; never mutates the helper's original wait4 ledger."""
    killed, reaped, errors = [], [], []
    if tree is None:
        return {'killed':killed, 'wait4':reaped, 'errors':errors}
    for pid, old in tree.known.items():
        try:
            current = helper.read_stat(pid)
            if current['start_ticks'] != old['start_ticks']:
                errors.append({'pid':pid, 'reason':'PID reuse; no signal sent'})
                continue
            os.kill(pid, signal.SIGKILL)
            killed.append(pid)
        except (FileNotFoundError, ProcessLookupError):
            pass
    alive = []
    deadline = time.monotonic()+1
    while time.monotonic() < deadline:
        progress = False
        for pid in tree.known:
            try:
                waited, status, usage = os.wait4(pid, os.WNOHANG)
                if waited:
                    progress = True
                    reaped.append({'pid':pid,'returncode':os.waitstatus_to_exitcode(status),
                        'CPU_seconds':usage.ru_utime+usage.ru_stime,'peak_RSS_bytes':usage.ru_maxrss*1024})
            except ChildProcessError:
                pass
        alive = []
        for pid, old in tree.known.items():
            try:
                now = helper.read_stat(pid)
                if now['start_ticks'] == old['start_ticks']:
                    alive.append(pid)
            except (FileNotFoundError, ProcessLookupError):
                pass
        if not alive:
            break
        if not progress:
            time.sleep(.01)
    return {'killed':killed,'wait4':reaped,'errors':errors,'remaining_original_identities':alive}

class Lifecycle(unittest.TestCase):
    def setUp(self):
        self.name = self._testMethodName
        self.directory = OUTPUT/self.name
        self.directory.mkdir()
        self.tree, self.row = None, None
        self.started = time.monotonic()

    def observe(self, code, wall=2, rss=96*1024**2, cleanup=.4, deadline=None):
        command = [sys.executable,'-I','-B','-c',code]
        self.row, self.tree = helper.observe(command,self.directory,ENV,wall,rss,
                                             cleanup_seconds=cleanup,launch_deadline=deadline)
        save(self.directory/'OBSERVE-ORIGINAL.json',self.row)
        return self.row

    def direct_reaped(self, row):
        self.assertTrue(row['direct_child_CPU_complete'])
        self.assertIsInstance(row['wait4_child_CPU_seconds'],(int,float))
        self.assertGreaterEqual(row['wait4_child_CPU_seconds'],0)
        self.assertGreaterEqual(row['whole_child_wall_seconds'],0)
        with self.assertRaises((FileNotFoundError,ProcessLookupError)):
            helper.read_stat(row['pid'])

    def tearDown(self):
        cleanup = external_cleanup(self.tree)
        save(self.directory/'INDEPENDENT-CLEANUP.json',cleanup)
        records = {'name':self.name,'whole_case_wall_seconds':time.monotonic()-self.started,
                   'original_observe_file':str(self.directory/'OBSERVE-ORIGINAL.json'),
                   'external_cleanup':cleanup}
        CASES.append(records)
        save(self.directory/'CASE.json',records)
        self.assertFalse(cleanup['errors'])
        self.assertFalse(cleanup.get('remaining_original_identities',[]))

    def test_01_normal_exit(self):
        row = self.observe("import sys,time; assert sys.stdin.read()==''; print('normal'); time.sleep(.03)")
        self.direct_reaped(row)
        self.assertEqual(row['returncode'],0)
        self.assertTrue(row['process_gate_passed'])
        self.assertFalse(row['total_attempt_CPU_unknown_or_lower_bound'])

    def test_02_nonzero_exit(self):
        row = self.observe("import sys; print('intentional exit7'); sys.exit(7)")
        self.direct_reaped(row)
        self.assertEqual(row['returncode'],7)
        self.assertFalse(row['process_gate_passed'])
        self.assertFalse(row['timed_out'])

    def test_03_timeout_kill_reap(self):
        row = self.observe('import time; time.sleep(10)',wall=.15)
        self.direct_reaped(row)
        self.assertEqual(row['returncode'],-signal.SIGKILL)
        self.assertTrue(row['timed_out'])
        self.assertFalse(row['process_gate_passed'])

    def test_04_RSS_kill_reap(self):
        row = self.observe("import time; memory=bytearray(32*1024**2); print(len(memory),flush=True); time.sleep(3)",rss=24*1024**2)
        self.direct_reaped(row)
        self.assertEqual(row['returncode'],-signal.SIGKILL)
        self.assertGreater(max(row['sampled_peak_RSS_bytes'],row['wait4_peak_RSS_bytes']),24*1024**2)
        self.assertFalse(row['process_gate_passed'])

    def test_05_detached_grandchild(self):
        code="import subprocess,sys,time; subprocess.Popen([sys.executable,'-I','-B','-c','import time; time.sleep(10)'],start_new_session=True); time.sleep(.08)"
        row = self.observe(code)
        self.direct_reaped(row)
        self.assertFalse(row['process_gate_passed'])
        self.assertTrue(row['adopted_child_wait4'])
        self.assertTrue(row['total_attempt_CPU_unknown_or_lower_bound'])
        self.assertTrue(any(r['pid']!=row['pid'] and r['pgrp']!=row['pid'] for r in row['process_observations']['tracked_identities']))

    def test_06_immediate_orphan_adoption(self):
        code="import os,time\npid=os.fork()\nif pid: os._exit(0)\ntime.sleep(10)"
        row = self.observe(code)
        self.direct_reaped(row)
        self.assertTrue(row['adopted_child_wait4'])
        self.assertFalse(row['process_gate_passed'])
        self.assertFalse(row['unreaped_descendants'])

    def test_07_final_observation_unreadable(self):
        original = helper.ProcessTree.cleanup
        def injected(tree, deadline):
            original(tree, deadline)
            raise PermissionError('synthetic final observation failure after real cleanup')
        with mock.patch.object(helper.ProcessTree,'cleanup',injected):
            row = self.observe('import time; time.sleep(.03)')
        self.direct_reaped(row)
        self.assertFalse(row['process_gate_passed'])
        self.assertTrue(row['descendant_terminal_unknown'])
        self.assertTrue(row['total_attempt_CPU_unknown_or_lower_bound'])

    def test_08_residual_child_refused(self):
        code="import subprocess,sys,time; subprocess.Popen([sys.executable,'-I','-B','-c','import time; time.sleep(10)'],start_new_session=True); time.sleep(.05)"
        with mock.patch.object(helper.ProcessTree,'kill_owned',lambda tree,direct_unreaped=False:[]):
            row = self.observe(code,cleanup=.08)
        self.direct_reaped(row)
        self.assertFalse(row['process_gate_passed'])
        self.assertTrue(row['unreaped_descendants'])
        self.assertTrue(row['process_observations']['after_cleanup']['adopted_children'])
        self.assertTrue(row['total_attempt_CPU_unknown_or_lower_bound'])

    def test_09_expired_start_deadline(self):
        row = self.observe("raise RuntimeError('must not execute')",deadline=time.monotonic()-1)
        self.assertIs(row['process_started'],False)
        self.assertIs(row['spawn_attempted'],False)
        self.assertIsNone(row['popen_started_monotonic'])
        self.assertIsNone(row['wait4_child_CPU_seconds'])
        self.assertFalse(row['process_gate_passed'])

started = time.monotonic()
suite = unittest.defaultTestLoader.loadTestsFromTestCase(Lifecycle)
result = unittest.TextTestRunner(verbosity=2).run(suite)
source_unchanged = hashlib.sha256((SOURCE/'os_processes.py').read_bytes()).hexdigest() == EXPECTED
save(OUTPUT/'RESULT.json',{'schema':'new-os-helper-lifecycle-validation-v3','tests_run':result.testsRun,
    'passed':result.wasSuccessful() and source_unchanged,'failures':len(result.failures),'errors':len(result.errors),
    'whole_worker_body_wall_seconds':time.monotonic()-started,'cases':CASES,'source_unchanged':source_unchanged,
    'old_lost_test_credit_inherited':False,'source_sha256':EXPECTED,'production_supervisor_invoked':False,
    'model_imports':0,'training_steps':0,'native_operator_calls':0,'confirmation_E_access':False})
raise SystemExit(0 if result.wasSuccessful() and source_unchanged else 1)
