"""Commit exact curated evidence in two stages and extend existing ledgers."""

import hashlib
import json
from pathlib import Path
import subprocess


root = Path("/workspace/scratch/c385a7439f8e")
repo = root / "hcsn-repo"
ledger = root / "hcsn-c2-progress-local-stages-v1.json"
stages = json.loads(ledger.read_bytes())
prefix = "qualification/hcsn_differentiable/evidence/p0p5-terminal-preparation-20261111"
base = "7464da11c756db858a23f8a91fb18e4f682c363b"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo, text=True).strip()


def save(path, value):
    temp = path.with_name(path.name + ".pending")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temp.replace(path)


assert git("rev-parse", "HEAD") == base
assert set(git("diff", "--cached", "--name-only").splitlines()) <= {prefix + "/STATUS.json"}
plans = [
    ([prefix], "evidence(hcsn): freeze terminal verification preparation and native observations",
     "Mechanical curation of exact frozen component files, validation and independent review originals; no actual C2 audit, analysis or render."),
    (["qualification/hcsn_differentiable/CURRENT.md", ".github/workflows/hcsn-differentiable.yml"],
     "docs(hcsn): bind current C2 progress and terminal preparation checks",
     "Current source/status and explicit 13-manifest/28-Markdown integrity scope; no new scientific admission."),
]
for paths, message, scope in plans:
    parent = git("rev-parse", "HEAD")
    subprocess.run(["git", "add", "-f", "--", *paths], cwd=repo, check=True)
    staged = git("diff", "--cached", "--name-only").splitlines()
    assert staged
    subprocess.run(["git", "commit", "-m", message], cwd=repo, check=True,
                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    commit, tree = git("rev-parse", "HEAD"), git("rev-parse", "HEAD^{tree}")
    stages.append({"local_parent": parent, "local_commit": commit, "tree": tree,
                   "message": message, "files": len(staged), "scope": scope})
    save(ledger, stages)
    print(json.dumps(stages[-1]), flush=True)
head = git("rev-parse", "HEAD")
binary = []
for line in git("diff", "--name-status", base, head).splitlines():
    status, name = line.split("\t")
    assert status in ("A", "M")
    raw = subprocess.check_output(["git", "show", head + ":" + name], cwd=repo)
    is_binary = b"\0" in raw
    try:
        raw.decode("utf-8")
    except UnicodeDecodeError:
        is_binary = True
    assert len(raw) <= 500000
    if is_binary:
        binary.append({"path": name, "absolute_path": str(repo / name), "bytes": len(raw),
                       "sha256": hashlib.sha256(raw).hexdigest(), "git_blob_sha": git("rev-parse", head + ":" + name)})
save(root / "evidence-c2-progress-binary-files.json", binary)
print(json.dumps({"head": head, "tree": git("rev-parse", "HEAD^{tree}"),
                  "changed_files": len(git("diff", "--name-only", base, head).splitlines()),
                  "binary_files": len(binary), "worktree": git("status", "--short")}))
