## Why

C2 still needs an independently verified all-six terminal barrier before its longer-budget results can be admitted. The scratch recovery also left preparation-source gaps, and native control reads temporarily failed. This change preserves the actual originals, supplies explicitly new validated preparation, and keeps producer progress, numerical qualification and scientific benefit separate.

## Changes

- Add an immutable 320-file terminal-preparation appendix with exact source manifests, original logs, failed attempts, independent counterexamples, corrections and scoped costs.
- Freeze a new resource metadata core: 52 tests pass on its exact final source. Preserve the earlier failed integration fixture and the independently exposed native CPU/wall/PID contradictions.
- Bind bootstrap v3, the complete OS supervisor and renderer v3 to the frozen core. Bootstrap v2's 21 tests and v3's 4 targeted tests retain separate source scopes; the process helper has 9 new tests; the renderer's native gate has 8 pure-JSON tests. None is an actual C2 audit or rendering run.
- Check original native requests/ACKs, complete durable log pages, source and command identities, the 1800/1950-second auditor envelopes and the 120/155-second resource envelopes. Preserve parent cost, every candidate opportunity, failed work and final wrapper tails without redistributing overhead over earlier quality timestamps.
- Update CURRENT and the science workflow's explicit integrity scope to 13 manifests and 28 Markdown inputs.

## Latest original C2 observation

The original job was read as running at 2026-11-11 01:50:50.391–01:50:52.855 UTC, with the same process identities. Its entire 01:52 command journal still contains three `.003` producer terminals; controller RESULT is absent. Three `.001` immutable complete-epoch nodes read at 01:55 report epochs 105/104/105, strict-best D macro-F1 0.3380742987/0.3432623605/0.3192009721, and stale counts 1/0/2. These are producer metadata, not independent replay or a new common-rate comparison. No replacement training or observer job was launched.

## Verification

- Local evidence check: 1983 files, 137 ZIPs and 506 relative links; zero errors.
- Committed-object check: 1986 regular evidence/extra files and 13 manifest identities; zero errors.
- `just fmt`, scoped repository codespell and `git diff --check` pass; worktree is clean.
- A fresh remote Git object store read all 322 changed files in full, matching bytes, SHA256 and Git blob identities. The initial unfiltered bulk transfer failed; its raw error is retained. One bounded remote-only filtered prefetch succeeded, after which the original verifier completed every file. No local object seeding or alternates were used.
- Remote head `ed22b39f66ad9e933ce620b132414a13c4448437`; tree `b34822b45e6c849e5ee1d3652a500fcf7861d368`, identical to local commit `22e54d6b94446b240381ba4153b954dd8734d7c3`.

## CI and scientific limits

At the retained new-head observation, science PR run [42944038500](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42944038500) and push run [42944030037](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42944030037) are queued; blocking run [42944038652](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42944038652) is pending. No new-head hosted pass is claimed. The separately archived prior-head science artifact passed 92 fixtures only at its recorded 9f16 tree; that equality included the then-current CURRENT.md and does not extend to later edits.

All-six independent C2 admission, actual terminal assembly/audit/resource analysis/rendering, whole-training-domain numerics and scientific benefit remain pending or HOLD. Existing tiny-gap counterexamples and incomplete numerical stages remain visible. Subject E was not scored here; historical E metadata exposure remains explicitly disclosed. P5 remains gated on demonstrated real-task benefit.

## Review entry points

- [CURRENT](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/ed22b39f66ad9e933ce620b132414a13c4448437/qualification/hcsn_differentiable/CURRENT.md)
- [Terminal preparation appendix](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/ed22b39f66ad9e933ce620b132414a13c4448437/qualification/hcsn_differentiable/evidence/p0p5-terminal-preparation-20261111/README.md)

This PR remains a draft. No main-branch merge or release publication is part of this update.
