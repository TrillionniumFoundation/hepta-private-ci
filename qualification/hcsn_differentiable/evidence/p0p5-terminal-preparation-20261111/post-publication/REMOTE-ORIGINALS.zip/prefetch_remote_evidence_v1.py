"""One bounded remote-only prefetch into the existing fresh Git object store."""

import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import time


root = Path("/workspace/scratch/c385a7439f8e")
repo = root / "hcsn-repo"
gitdir = root / "terminal-preparation-remote-readback-v1/fresh-objects.git"
output = root / "terminal-preparation-remote-prefetch-assist-v1"
base = "7464da11c756db858a23f8a91fb18e4f682c363b"
head = "22e54d6b94446b240381ba4153b954dd8734d7c3"
output.mkdir(exist_ok=False)
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
assert not (gitdir / "objects/info/alternates").exists()
origin = subprocess.check_output(["git", "--git-dir", str(gitdir), "config", "--get", "remote.origin.url"], text=True).strip()
assert origin == "https://github.com/TrillionniumFoundation/hepta-private-ci.git"
paths = subprocess.check_output(["git", "diff", "--name-only", base, head], cwd=repo, text=True).splitlines()
assert len(paths) == 322
oids = sorted({subprocess.check_output(["git", "rev-parse", head + ":" + p], cwd=repo, text=True).strip() for p in paths})
data = ("\n".join(oids) + "\n").encode()
(output / "REQUESTED-REMOTE-OBJECTS.txt").write_bytes(data)
command = ["git", "--git-dir", str(gitdir), "-c", "fetch.negotiationAlgorithm=noop",
           "fetch", "origin", "--no-tags", "--no-write-fetch-head",
           "--recurse-submodules=no", "--filter=blob:none", "--stdin"]
started = time.monotonic()
with (output / "stdout").open("xb") as out, (output / "stderr").open("xb") as err:
    completed = subprocess.run(command, input=data, stdout=out, stderr=err,
                               env={**os.environ, "GIT_TERMINAL_PROMPT": "0"}, timeout=90)
record = {"schema": "hcsn-remote-prefetch-assistance-v1", "command": command,
          "returncode": completed.returncode, "wall_prefix_seconds": time.monotonic() - started,
          "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "requested_objects": len(oids), "request_sha256": hashlib.sha256(data).hexdigest(),
          "local_object_seeding": False, "source_tree_modified": False,
          "scope": "One additional remote Git transfer, following the initial unfiltered batch error. The existing verifier still reads every complete blob and checks bytes/SHA. Concurrent Git object writes are immutable content-addressed additions. This receipt is not a verification pass, scientific result or complete OS cost."}
(output / "RESULT.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
print(json.dumps(record))
raise SystemExit(completed.returncode)
