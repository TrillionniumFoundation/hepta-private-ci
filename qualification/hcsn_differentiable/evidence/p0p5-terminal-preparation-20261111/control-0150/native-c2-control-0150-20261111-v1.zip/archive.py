"""Seal the already-returned native metadata reads; no further native access."""
from pathlib import Path
import hashlib
import json
import time
import zipfile

START = time.perf_counter()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent

def ident(path):
    b = path.read_bytes()
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def load(path):
    return json.loads(path.read_bytes())

def emit(name,value):
    with (OUT/name).open('x') as f:
        json.dump(value,f,sort_keys=True,indent=2,allow_nan=False)
        f.write('\n')

status_raw=load(OUT/'raw/01-ORIGINAL-STATUS.json')
status=json.loads(status_raw['raw']['content'][0]['text'])
assert status['job_id']=='1a1c74f3308-be2a-75' and status['state']=='running'
assert status['systemd']['InvocationID']=='c869c0b70cfe4caeb69bb49f8890b12e'
command_bytes=(OUT/'decoded/commands.jsonl').read_bytes()
assert hashlib.sha256(command_bytes).hexdigest()=='2830d8017b5612319fd24ad816f43595bf1ceff2abb5b124e85a833f8c86b082'
commands=[json.loads(x) for x in command_bytes.splitlines()]
terminal=[r for r in commands if r.get('status') not in ('preparing','running')]
assert len(terminal)==3
progress=[]
for seed in (101,211,307):
    raw_path=OUT/f'raw/LATEST-COMMIT-s{seed}.json'
    raw=load(raw_path)
    path=OUT/f'decoded/latest-commit-s{seed}.json'
    commit=load(path);epoch=commit['epoch']
    assert commit['schema']=='hcsn-c2-complete-epoch-commit-v1' and epoch['complete'] is True
    assert epoch['epoch']==raw['epoch'] and commit['logical_main_updates']==12*epoch['epoch']
    progress.append({'name':f'hcsn-s{seed}-lr0.001','seed':seed,'learning_rate':.001,
       'latest_visible_complete_epoch':epoch['epoch'],'development':epoch['development'],
       'stopping':commit['stopping'],'logical_main_updates':commit['logical_main_updates'],
       'latest_epoch_cumulative_process_wall_seconds':epoch['cumulative_process_wall_seconds'],
       'latest_epoch_phase_process_wall_seconds':epoch['phase_process_wall_seconds'],
       'latest_epoch_phase_process_CPU_seconds':epoch['phase_process_cpu_seconds'],
       'selected_best_checkpoint_identity_reported':commit['best_checkpoint'],
       'checkpoint_identity_reported':commit['checkpoint'],
       'commit_source_path':raw['request']['path'],'commit_identity':ident(path),
       'raw_response_identity':ident(raw_path),'read_span':{k:raw[k] for k in ('started','finished','control_wall_seconds')},
       'independent_model_replay_performed':False,'numeric_admission':'HOLD','whole_training_domain':'HOLD'})
emit('PROGRESS-SNAPSHOT.json',{'schema':'source-bound-latest-visible-complete-epoch-metadata-v1',
    'fits':progress,'interpretation':'The prefix clocks belong to the latest visible epoch, not to the best checkpoint or a first threshold crossing. No missing epochs were inferred or replayed.',
    'selected_model_bytes_read':False,'probability_arrays_read':False,'first_crossing_recomputed':False})
calls=[]
for p in sorted((OUT/'raw').glob('*.json')):
    r=load(p)
    if 'request' in r and 'started' in r:
        calls.append({'member':str(p.relative_to(OUT)),'identity':ident(p),'request':r['request'],
                      'started':r['started'],'finished':r['finished'],'control_wall_seconds':r['control_wall_seconds'],
                      'isError':r.get('raw',{}).get('isError'),'thrown':r.get('thrown')})
assert len(calls)==10
emit('SUMMARY.json',{'schema':'native-control-restoration-0150-snapshot-v1','status':'original_job_reported_running_all_six_terminal_not_established',
    'native_job_id':status['job_id'],'original_idempotency_key':'hcsn-c2-native-execution-c385-v1',
    'native_running_response':status,'native_status_read_span':{k:status_raw[k] for k in ('started','finished','control_wall_seconds')},
    'native_exact_sample_timestamp':None,'commands_identity':ident(OUT/'decoded/commands.jsonl'),
    'command_rows':len(commands),'terminal_rows_observed':len(terminal),'terminal_candidate_names':[r['name'] for r in terminal],
    'commands_identical_to_prior_v8_and_0033_snapshot':True,'all_six_terminal_established':False,
    'controller_RESULT_read':'Structured INVALID_ARGUMENT with FileNotFoundError for RESULT.json; not a durable terminal receipt.',
    'v9_RESULT_read':'Structured INVALID_ARGUMENT with FileNotFoundError for the v9 observation directory; original launch acknowledgement remains unknown.',
    'latest_visible_complete_epochs':{r['name']:r['latest_visible_complete_epoch'] for r in progress},
    'read_only_control_calls':calls,'control_cost_scope':'Concurrent call spans are retained individually. Do not sum overlapping calls as elapsed time or add them to already-overlapping training wall. Native helper CPU was not provided.',
    'new_job_starts':0,'new_training_steps':0,'model_or_probability_array_reads':0,'service_or_credential_mutations':0,
    'native_state_after_last_read':'not rechecked by this snapshot','whole_training_numeric_admission':'HOLD','scientific_admission':'HOLD',
    'scope':'Ten bounded existing-metadata reads only; no new observer, no model evaluation, no reconfiguration or restart.'})
capsule=BASE/'hcsn-repo/qualification/hcsn_differentiable/evidence/p0p5-c2-launch-20261110/launch/source-v4.zip'
with zipfile.ZipFile(capsule) as z:
    code=z.read('c2_runner.py')
emit('SOURCE-BOUND-INDEX.json',{'schema':'native-metadata-source-index-v1',
    'frozen_expected_producer_capsule':{'path':str(capsule),**ident(capsule)},
    'producer_member':{'name':'c2_runner.py','bytes':len(code),'sha256':hashlib.sha256(code).hexdigest()},
    'source_read_scope':'Local frozen producer source was used only to locate immutable commit files. Active native source and checkpoint bytes were not newly verified here.',
    'raw_inputs':{str(p.relative_to(OUT)):ident(p) for p in sorted((OUT/'raw').glob('*.json'))},
    'decoded_originals':{str(p.relative_to(OUT)):ident(p) for p in sorted((OUT/'decoded').iterdir()) if p.is_file()}})
files=sorted(p for p in OUT.rglob('*') if p.is_file())
before={str(p.relative_to(OUT)):ident(p) for p in files}
emit('MANIFEST.json',{'schema':'native-control-and-commit-raw-manifest-v1','files':before})
archive=OUT/'native-c2-control-0150-20261111-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in files+[OUT/'MANIFEST.json']:z.write(p,str(p.relative_to(OUT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for member, expected in before.items():
        b=z.read(member)
        assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==expected
assert before=={str(p.relative_to(OUT)):ident(p) for p in files}
emit('ARCHIVE-RECEIPT.json',{'archive':str(archive),'identity':ident(archive),'members':len(before)+1,
    'all_listed_member_SHA_and_CRC_verified':True,'local_raw_inputs_unchanged':True,
    'local_packing_body_wall_seconds':time.perf_counter()-START,'scope':'Packing only; no further native call.'})
names=['SUMMARY.json','PROGRESS-SNAPSHOT.json','SOURCE-BOUND-INDEX.json','decoded/commands.jsonl',
       *[f'decoded/latest-commit-s{s}.json' for s in (101,211,307)],archive.name,'ARCHIVE-RECEIPT.json']
emit('COPY_LIST.json',{'schema':'copy-list-v1','files':[{'source':str(OUT/n),'suggested_name':n,**ident(OUT/n)} for n in names]})
print(json.dumps({'copy_list':str(OUT/'COPY_LIST.json'),**ident(OUT/'COPY_LIST.json'),'archive':ident(archive)}))
