"""Read changed Git blobs from a fresh remote object store and check full bytes."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--local-repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    out = args.output
    out.mkdir(exist_ok=False)
    source_head = "b908827abcf60b7ce22fe1b8b299206a31484550"
    local_head = "7464da11c756db858a23f8a91fb18e4f682c363b"
    remote_head = "9f16aa325b12004ddc0d9fa325fdc67531d027fc"
    expected_tree = "92f8647353bd34a194b94fde015428641e3549e4"
    environment = {**os.environ, "GIT_TERMINAL_PROMPT": "0"}
    gitdir = out / "fresh-objects.git"
    with (out / "git-transfer.log").open("xb") as log:
        subprocess.run([
            "git", "clone", "--bare", "--filter=blob:none", "--depth", "1", "--single-branch",
            "--branch", "codex/hcsn-c2-launch-api-20261110-c385",
            "https://github.com/TrillionniumFoundation/hepta-private-ci.git", str(gitdir),
        ], check=True, env=environment, stdout=log, stderr=log, timeout=120)

        def remote(*words):
            return subprocess.check_output(["git", "--git-dir", str(gitdir), *words], env=environment, stderr=log, timeout=120)

        actual_head, actual_tree = remote("rev-parse", "HEAD", "HEAD^{tree}").decode().splitlines()
        if (actual_head, actual_tree) != (remote_head, expected_tree):
            raise ValueError("remote branch changed; no automatic retry")
        names = subprocess.check_output(["git", "diff", "--name-only", source_head, local_head], cwd=args.local_repo, text=True).splitlines()
        assert len(names) == 87
        results = []
        for name in names:
            oid = subprocess.check_output(["git", "rev-parse", local_head + ":" + name], cwd=args.local_repo, text=True).strip()
            remote_oid = remote("rev-parse", remote_head + ":" + name).decode().strip()
            assert oid == remote_oid
            expected = (args.local_repo / name).read_bytes()
            raw = remote("cat-file", "blob", remote_oid)
            actual = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
            assert actual == {"bytes": len(expected), "sha256": hashlib.sha256(expected).hexdigest()}
            assert hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == oid
            results.append({"path": name, "git_blob": oid, **actual})
    result = {
        "schema": "hcsn-fresh-remote-git-object-readback-v1", "passed": True,
        "local_commit": local_head, "remote_commit": actual_head, "tree": actual_tree,
        "all_changed_files": results, "fresh_git_object_directory": True,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Read every changed regular-file blob through a new filtered Git clone. No shared alternates or local-object seeding. Complete byte count, SHA256 and Git blob identity checked. This is archival verification, not CI or scientific admission.",
    }
    with (out / "RESULT.json").open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"passed": True, "files": len(results), "remote_commit": actual_head, "tree": actual_tree}))


if __name__ == "__main__":
    main()
