"""Retrieve one exact hosted science artifact; never rerun its tests."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import urllib.request
import zipfile


def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    metadata_path, url_path, output = map(Path, sys.argv[1:4])
    metadata = json.loads(metadata_path.read_bytes())
    output.mkdir(exist_ok=False)
    with urllib.request.urlopen(url_path.read_text().strip(), timeout=30) as response:
        raw = response.read(metadata["original_zip"]["bytes"] + 1)
    assert identity(raw) == metadata["original_zip"], "Hosted artifact bytes differ"
    archive_path = output / "ORIGINAL.zip"
    archive_path.write_bytes(raw)
    members = {}
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert sum(i.file_size for i in archive.infolist()) <= 8 * 1024**2
        for item in archive.infolist():
            path = PurePosixPath(item.filename)
            assert not path.is_absolute() and ".." not in path.parts
            assert "\\" not in item.filename and not item.is_dir()
            assert not stat.S_ISLNK(item.external_attr >> 16)
            data = archive.read(item)
            members[item.filename] = identity(data)
        assert archive.testzip() is None
        for name in ("identity.json", "outcome.json", "runtime.json"):
            (output / name).write_bytes(archive.read(name))
    result = {
        "schema": "hcsn-hosted-science-artifact-readback-v2",
        "metadata": metadata,
        "metadata_identity": identity(metadata_path.read_bytes()),
        "original_zip": identity(raw),
        "members": members,
        "CRC_and_all_member_SHA_verified": True,
        "tests_rerun": False,
        "scope": "Exact hosted artifact retrieval and byte integrity only. Test and commit interpretation is separately recorded. Transfer URL is temporary and excluded from publication.",
    }
    (output / "READBACK.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"members": len(members), "original_zip": identity(raw)}))


if __name__ == "__main__":
    main()
