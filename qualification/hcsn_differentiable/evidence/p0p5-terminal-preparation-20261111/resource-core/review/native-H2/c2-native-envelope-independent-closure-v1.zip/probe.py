"""Four synthetic native-account probes. No native, C2, model or E access."""
import json
from pathlib import Path
import sys
from unittest.mock import patch

SOURCE = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
sys.path.insert(0, str(SOURCE))
from test_native_envelope_v2 import fixture, raw, identity
from metadata_io import Inputs
import native_envelope as gate


def rewrite(spec, value):
    Path(spec['path']).write_bytes(raw(value))
    spec['identity'] = identity(Path(spec['path']))


def run_case(name, mutation, expected_error):
    root = OUT / name
    root.mkdir()
    spec, external, pins = fixture(root)
    envelope = json.loads(Path(spec['path']).read_bytes())
    receipt_spec = envelope['bootstrap_receipt']
    receipt = json.loads(Path(receipt_spec['path']).read_bytes())
    # H2 adds producer-required observation clocks. This version uses its
    # chronological fixture unchanged: main8, before8.1, preflight8.25..8.5,
    # core10..11, after11.2, prefix3.5. Only bad values below are mutated.
    if mutation == 'zero_GNU_CPU':
        timefile = Path(envelope['gnu_time']['path'])
        lines = timefile.read_text().splitlines()
        lines = [line.split(':', 1)[0] + ': 0.00'
                 if line.strip().startswith(('User time (seconds):', 'System time (seconds):'))
                 else line for line in lines]
        timefile.write_text('\n'.join(lines) + '\n')
        envelope['gnu_time']['identity'] = identity(timefile)
    if mutation == 'bootstrap_prefix_beyond_whole':
        receipt['whole_bootstrap_wall_prefix_seconds'] = 1960.
    if mutation == 'after_PID_scan_beyond_whole':
        receipt['after']['observed_monotonic'] = 2000.
    rewrite(receipt_spec, receipt)
    rewrite(spec, envelope)
    try:
        with patch.object(gate, 'BOOTSTRAP', pins):
            admitted = gate.verify_native(spec, Inputs(), external)
    except ValueError as exc:
        accepted, error, admitted = False, str(exc), None
    else:
        accepted, error = True, None
    correct = accepted if expected_error is None else not accepted and expected_error in error
    return {'case': name, 'mutation': mutation, 'accepted': accepted,
            'error': error, 'expected_error_substring': expected_error,
            'passed': correct, 'result': admitted,
            'fixture_scope': 'All files are synthetic. The sole qualified-source trust anchor is explicitly patched to synthetic source bytes; actual parser/identity/gate code is unchanged.'}


OUT.mkdir(exist_ok=False)
roster = [('positive_control', None, None),
          ('native_CPU_too_small', 'zero_GNU_CPU', 'disjoint CPU observations exceed GNU whole CPU'),
          ('bootstrap_prefix_too_large', 'bootstrap_prefix_beyond_whole', 'bootstrap prefix exceeds native whole wall'),
          ('PID_scan_after_native_exit', 'after_PID_scan_beyond_whole', 'bootstrap/preflight/audit/original PID chronology differs')]
cases = [run_case(*case) for case in roster]
report = {'schema': 'independent-native-envelope-account-closure-v1',
          'cases': cases, 'passed': all(case['passed'] for case in cases),
          'old_counterexamples_sha256': '897f7d5c2a6f9f9bfb99dd04e64bacf1f27c0e79b34376f7bbeb2a382df83a3c',
          'unchanged_bad_values': {'GNU_user_and_system_seconds': 0., 'bootstrap_prefix_seconds': 1960., 'after_PID_monotonic': 2000.},
          'positive_fixture_adaptation': 'Adopt H2 required scan times and source-exact sequential preflight/core chronology. This is a new closure fixture; the H1 red fixture and outputs remain unchanged.',
          'real_native_or_C2_or_model_or_E_access': False,
          'model_or_oracle_execution': False, 'owner_test_suite_reexecuted': False,
          'scope': 'One positive and three negative pure metadata cases only; no claim about actual future execution or scientific qualification.',
          'scientific_admission': 'HOLD'}
(OUT / 'CLOSURE.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'cases': len(cases), 'passed': report['passed'], 'actual_native_execution': False}))
raise SystemExit(0 if report['passed'] else 2)
