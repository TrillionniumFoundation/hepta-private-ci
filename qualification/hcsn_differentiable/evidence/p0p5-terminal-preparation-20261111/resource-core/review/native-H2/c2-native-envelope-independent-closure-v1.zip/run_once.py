"""Single bounded independent metadata probe; full child wait4 accounting."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
LIMIT = 30.
RSS = 256 * 1024 * 1024


def hashes():
    return {str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted((ROOT / 'candidate-source').glob('*.py'))}


def restrict():
    resource.setrlimit(resource.RLIMIT_AS, (RSS, RSS))


before = hashes()
command = [sys.executable, '-B', str(ROOT / 'probe.py'), str(ROOT / 'candidate-source'), str(ROOT / 'cases')]
start = time.monotonic()
with (ROOT / 'stdout').open('xb') as stdout, (ROOT / 'stderr').open('xb') as stderr:
    child = subprocess.Popen(command, stdout=stdout, stderr=stderr, cwd=ROOT, start_new_session=True,
                             preexec_fn=restrict, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
    timed_out = False
    while True:
        pid, status, usage = os.wait4(child.pid, os.WNOHANG)
        if pid:
            break
        if time.monotonic() - start >= LIMIT:
            timed_out = True
            os.killpg(child.pid, signal.SIGKILL)
            pid, status, usage = os.wait4(child.pid, 0)
            break
        time.sleep(.005)
end = time.monotonic()
code = os.waitstatus_to_exitcode(status)
child.returncode = code
after = hashes()
receipt = {'schema': 'independent-metadata-child-execution-v1', 'argv': command,
           'complete_child_wall_seconds': end - start,
           'complete_wait4_child_CPU_seconds': usage.ru_utime + usage.ru_stime,
           'complete_wait4_peak_RSS_bytes': usage.ru_maxrss * 1024,
           'returncode': code, 'timed_out': timed_out,
           'limits': {'whole_child_seconds': LIMIT, 'address_space_bytes': RSS, 'workers': 1, 'retry': False},
           'source_before': before, 'source_after': after, 'source_unchanged': before == after,
           'real_native_or_model_or_E_access': False,
           'outer_receipt_save_and_exit_cost': 'Not included in complete child cost; no separate full supervisor exit measurement.'}
(ROOT / 'EXECUTION.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ('returncode', 'complete_child_wall_seconds', 'complete_wait4_child_CPU_seconds', 'complete_wait4_peak_RSS_bytes', 'source_unchanged')}))
raise SystemExit(0 if code == 0 and not timed_out and before == after and end - start <= LIMIT and usage.ru_maxrss * 1024 <= RSS else 2)
