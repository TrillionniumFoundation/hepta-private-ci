# synthetic bootstrap.py
