"""Freeze this review and exact read-only input snapshots; performs no model work."""
from pathlib import Path
import hashlib
import json
import resource
import time
import zipfile

start, cpu = time.perf_counter(), time.process_time()
base = Path('/workspace/scratch/c385a7439f8e')
out = Path(__file__).resolve().parent
expected = {
 'c2-resource-analysis-program-v2/resource_arithmetic.py': '8a1befdf5803ecaf5f260057259ba0e482438b202ac9a7cd845fe81286833dbd',
 'c2-resource-analysis-program-v2/old_metadata.py': 'd92aae6a419e0a32c0e67756fed09fd158d764ae1079687fa492c1f62366ba3c',
 'c2-resource-analysis-program-v2/candidate_accounting.py': '081f983b59083f5b706802e1b92694716d5b206abbb7669ba78f935549e2d526',
 'c2-resource-analysis-program-v2/historical_review.py': '3df4c6857c651e58c11a1c1a26bdf5cd827d231a8536aa2c15fc2d692be393ed',
 'c2-resource-analysis-program-v2/build_report.py': '124e8db6f29a045a9599b1f8ad8c7cf68e32637c5be52e9b833c9e39f451a75b',
 'c2-terminal-bootstrap-recovery-v2/bootstrap.py': 'c18f7341f0ca972c6070b8b440b0b6c7679368a0b798a935f9b301b6532da63b',
 'c2-terminal-bootstrap-recovery-v3/bootstrap.py': 'fedff1dde25bdff874b99ad2a13a0b39a12a4452bd5e38bb262c0f96db77697e',
 'c2-terminal-bootstrap-recovery-v3/os_processes.py': 'f58ca60428d3abafea377ca64e1d71040df98c4f149adce88436951187c990d6',
}

def identity(path):
 b = path.read_bytes()
 return {'path': str(path), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def emit(name, value):
 data = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
 with (out / name).open('xb') as f: f.write(data)

sources = []
for rel, sha in expected.items():
 p = base / rel
 b = p.read_bytes()
 assert hashlib.sha256(b).hexdigest() == sha
 dest = out / 'source' / rel
 dest.parent.mkdir(parents=True, exist_ok=True)
 with dest.open('xb') as f: f.write(b)
 sources.append({**identity(p), 'snapshot': str(dest.relative_to(out))})
emit('SOURCE-IDENTITIES.json', {'sources': sources})
emit('RESOURCE-REVIEW.json', {
 'schema': 'independent-resource-arithmetic-static-review-v1',
 'status': 'no_static_arithmetic_blocker_found_in_reviewed_five_files',
 'reviewer': '/root/training', 'source_capture_utc': '2026-11-11T01:04:57Z',
 'reviewed_files': [r for r in sources if 'resource-analysis' in r['path']],
 'findings': [
  'Every core requires all six seed/LR opportunities. Missing or failed opportunities retain original cost and any known continuation lower bound; cost_sum does not replace absent full cost with zero.',
  'Original full process wall is charged without refund for discarded partial work. Final opportunity cost uses the complete continuation wrapper, while quality uses the recorded process prefix. Controller and audit ledgers stay separate from overlapping fit sums.',
  'Historical C1 preserves its two sampling times as early <= late <= outer, rather than rewriting the original microsecond discrepancy. C2 cumulative epoch wall is checked against original full wall plus the single phase sample.',
  'Strict best is the first strict maximum over all complete epochs. The .002 plateau anchor is tracked independently, and an earlier recorded plateau cannot be erased by a later improvement.',
  'Original 300/900/1800 views and points are copied as exact bytes. C2 contributes only to the separate longer-resource view.',
  'HCSN common LR requires all three verified seeds at both LRs, chooses the highest three-seed mean with lower-LR tie break, and never filters LRs by adequacy first. Baseline common LRs remain the frozen historical choices.',
  'A selected trained comparison requires all three selected seeds to have independently supported adequacy and verified quality. A better-mean but inadequate LR remains selected with HOLD; there is no fallback that hides a failed seed.',
  'First target crossings use recorded complete-epoch evaluations only. Missing crossings remain censored rather than assigned zero or interpolated. Initial-evaluation eligibility is separately disclosed.',
  'Original exact exit CPU remains unknown; observed prefix/fit-entry values and C2 wait4 are lower bounds on the full chain. Per-attempt maximum RSS is not memory at crossing, tree memory or GPU VRAM; energy remains null.',
  'A C2 selected best may still be an original-phase checkpoint. Its old epoch identity is retained while all additional training cost is charged, so continuation adequacy is not automatically a quality gain.'
 ],
 'scope_limits': [
  'Static review only; no tests, model imports, forward/backward, optimizer steps, numerical oracle, live C2 input, E access, native calls or new process launch.',
  'The remaining metadata I/O, archive, terminal roster and native resource-envelope files were not reviewed in this narrow pass.',
  'Actual six-chain terminal provenance, independent audit results and runtime resource enforcement remain separate pending gates.',
  'Right censoring is for first recorded evaluations. It does not locate a latent first threshold crossing between observations.',
  'Per-fit controller wrapper CPU and unsupplied upstream tuning/publication costs remain explicitly outside the summed complete-fit CPU account.'
 ], 'tests_run_by_reviewer': 0, 'native_calls': 0, 'training_steps': 0,
 'scientific_admission': 'HOLD', 'whole_training_numerical_admission': 'HOLD',
})
emit('BOOTSTRAP-CLOCK-REVIEW.json', {
 'schema': 'independent-bootstrap-clock-delta-static-review-v1',
 'status': 'no_new_static_clock_blocker_found', 'reviewer': '/root/training',
 'reviewed_files': [r for r in sources if 'bootstrap-recovery' in r['path']],
 'findings': [
  'The v3 caller passes Reader absolute 120-second setup deadline into observe; the unchanged helper rejects an expired deadline immediately before attempting Popen.',
  'setup_wall_seconds is actual popen_started_monotonic minus bootstrap start, including preparation inside observe. None, negative, and greater-than-120 starts are rejected.',
  'A small check-to-Popen race cannot receive successful admission when the actual recorded startup exceeds 120 seconds.',
  'The 1800-second core envelope and required 1950-second native outer envelope remain unchanged. This is not a budget extension.'
 ],
 'limits': ['Only this timing delta and the relevant unchanged helper path were reviewed.',
            'No tests or actual core/native execution were run by this reviewer.',
            'Earlier v2 wrapper/process-source review and its eighteen-test snapshot remain separate; no lost fourteen-test credit is inherited.',
            'Actual original C2 terminal barrier and a separately bound root execution decision are still required.'],
 'tests_run_by_reviewer': 0, 'native_calls': 0, 'model_operations': 0,
})
for rel, sha in expected.items():
 assert hashlib.sha256((base / rel).read_bytes()).hexdigest() == sha
emit('PACKING-RECEIPT.json', {'schema':'static-review-source-freeze-v1', 'sources_unchanged':True,
 'wall_seconds':time.perf_counter()-start, 'cpu_seconds':time.process_time()-cpu,
 'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
 'scope':'Local packing body only; excludes interpreter startup, tool transport and model reasoning. No native/model work.'})
rows = [identity(p) | {'member':str(p.relative_to(out))} for p in sorted(out.rglob('*')) if p.is_file()]
emit('MANIFEST.json', {'files':rows})
archive = out / 'c2-followup-training-static-review-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file() and p != archive: z.write(p,str(p.relative_to(out)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for r in rows:
  data=z.read(r['member'])
  assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
emit('ARCHIVE-RECEIPT.json', {'archive':identity(archive),'payload_members_verified':len(rows), 'CRC_passed':True})
names=['RESOURCE-REVIEW.json','BOOTSTRAP-CLOCK-REVIEW.json','SOURCE-IDENTITIES.json','PACKING-RECEIPT.json','ARCHIVE-RECEIPT.json',archive.name]
emit('COPY_LIST.json', {'schema':'copy-list-v1','files':[identity(out/n)|{'source':str(out/n),'suggested_name':n} for n in names]})
print(json.dumps(identity(out/'COPY_LIST.json')))
