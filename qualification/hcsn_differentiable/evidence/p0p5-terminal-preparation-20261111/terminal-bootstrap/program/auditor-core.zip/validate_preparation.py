"""Freeze and test only synthetic software fixtures; never bind production data."""
import argparse
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import sys
import time
from zipfile import ZipFile, ZIP_DEFLATED


def identity(path):
    raw=Path(path).read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def main(output):
    root=Path(__file__).resolve().parent
    out=Path(output).resolve();out.mkdir(exist_ok=False)
    source={str(p.relative_to(root)):identity(p) for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
    with ZipFile(out/'TESTED-SOURCE.zip','x',compression=ZIP_DEFLATED) as archive:
        for name in source:archive.write(root/name,name)
    start=time.monotonic();u0=resource.getrusage(resource.RUSAGE_CHILDREN)
    runs=[]
    commands=[('synthetic-tests',[sys.executable,'-B','-m','unittest','test_synthetic','test_controller_closure','test_recording_links','-v']),
              ('help',[sys.executable,'-B',str(root/'launch.py'),'--help'])]
    for label,command in commands:
        tick=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
        with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
            child=subprocess.run(command,cwd=root,stdout=stdout,stderr=stderr,timeout=90)
        usage=resource.getrusage(resource.RUSAGE_CHILDREN)
        runs.append({'label':label,'argv':command,'returncode':child.returncode,
                     'whole_child_wall_seconds':time.monotonic()-tick,
                     'waited_child_CPU_seconds':usage.ru_utime+usage.ru_stime-before.ru_utime-before.ru_stime,
                     'stdout':identity(out/(label+'.stdout')),'stderr':identity(out/(label+'.stderr'))})
    after={name:identity(root/name) for name in source}
    usage=resource.getrusage(resource.RUSAGE_CHILDREN)
    value={'schema':'c2-independent-terminal-auditor-software-validation-v1','status':'passed' if source==after and all(r['returncode']==0 for r in runs) else 'failed',
           'source_before':source,'source_after':after,'source_unchanged':source==after,'runs':runs,
           'whole_validation_interval_seconds':time.monotonic()-start,
           'waited_children_CPU_seconds':usage.ru_utime+usage.ru_stime-u0.ru_utime-u0.ru_stime,
           'own_CPU_sample_seconds':time.process_time(),'child_peak_rss_bytes':usage.ru_maxrss*1024,
           'production_C2_files_read':0,'production_model_reads':0,'training_or_oracle_calls':0,
           'test_scope':'synthetic tensors/journals/traces, explicitly mocked metadata, and short non-model subprocesses only',
           'actual_audit_execution_authorized':False,'scientific_admission':'HOLD',
           'source_capsule':identity(out/'TESTED-SOURCE.zip')}
    (out/'RESULT.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in value.items() if not k.startswith('source_')}))
    return 0 if value['status']=='passed' else 2


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True)
    raise SystemExit(main(parser.parse_args().output))
