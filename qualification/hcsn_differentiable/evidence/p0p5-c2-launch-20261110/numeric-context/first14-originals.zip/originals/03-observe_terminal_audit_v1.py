"""Read-only progress and active-process CPU lower bounds; no model imports."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time
import traceback

BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
ROOT = Path('/home/qian-qi/hepta-hcsn-final-numerics-20261110-c385-v1')
PROGRAM = Path('/home/qian-qi/hepta-hcsn-final-numerics-program-20261110-c385-v1')
PLAN_SHA = '6ae8bb984d994f0d3fa6963e37d0f4180366a3a7bafd316d887e74f2ef1c7d26'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    started = time.monotonic()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
    out = BASE/('numerics-status-'+stamp+'-v1')
    out.mkdir(exist_ok=False)
    source = Path(__file__).read_text() if '__file__' in globals() else sys.orig_argv[sys.orig_argv.index('-c')+1]
    (out/'source.py').write_text(source)
    payload = (ROOT/'PLAN.json').read_bytes()
    if sha(payload)!=PLAN_SHA:
        raise ValueError('fixed plan differs')
    plan = json.loads(payload)
    tasks = [(name, stage) for stage in ['export-best','export-last','original-prefix','domain-best','domain-last','logrisk'] for name in plan['fit_roster']]
    tasks += [(name, 'finite-best-'+str(index)) for index in range(9) for name in plan['fit_roster']]
    tasks += [(name, 'finite-last-0') for name in plan['fit_roster']]
    report = {'schema':'read-only-terminal-audit-progress-v1','observed_utc':datetime.now(timezone.utc).isoformat(),
              'source_sha256':sha(source.encode()),'plan_sha256':PLAN_SHA,'rows':[],
              'scientific_admission':'HOLD','whole_training_domain_admission':'HOLD',
              'scope':'Progress snapshot only; raw numerical pass fields are copied from completed source-bound stages, not a whole-domain admission.'}
    for name, stage in tasks:
        row = {'name':name,'stage':stage}
        outer_path = ROOT/name/(stage+'-outer.json')
        if not outer_path.exists():
            row['status']='artifact_pending_or_unfinished' if (ROOT/name/(stage+'.stdout')).exists() else 'not_yet_observed_started'
        else:
            try:
                outer_bytes = outer_path.read_bytes()
                outer = json.loads(outer_bytes)
                row.update(status=outer['execution_status'],outer_sha256=sha(outer_bytes),
                           returncode=outer['returncode'],stop_cause=outer['stop_cause'],
                           wall_seconds=outer['whole_process_wall_seconds'],CPU_seconds=outer['waited_child_CPU_seconds'])
                if row['status']=='completed':
                    raw = (ROOT/name/(stage+'.json')).read_bytes()
                    result = json.loads(raw)
                    if sha(raw)!=outer['result_sha256'] or result['stage']!=stage or result['execution_status']!='completed':
                        raise ValueError('completed stage identity/status mismatch')
                    if not result['original_inputs_unchanged'] or not result['auditor_source_unchanged'] or result['fixed_plan_sha256_after']!=PLAN_SHA:
                        raise ValueError('stage source/input gate failed')
                    row['result_sha256']=sha(raw)
                    value=result['result']
                    if stage.startswith('finite-'):
                        row['numerical']={k:value[k] for k in ['status','horizon','intervals','scaled_errors','reference_refinement_delta','mass_residual','reference','projected']}
                    elif stage.startswith('domain-'):
                        row['numerical']={'state_gradient_checks_passed':value['state_gradient_checks_passed'],'records':len(value['records']),'pressure_sentinels':value['pressure_sentinels']}
                    elif stage=='logrisk':
                        row['numerical']={k:value[k] for k in ['primary_passed','direct_FD_all_resolved_pass','direct_FD_inconclusive_count','direct_FD_resolved_disagreement_count','query_gaps','distances']}
                    elif stage=='original-prefix':
                        row['numerical']={k:value[k] for k in ['status','audited_records','source_matches_trace','complete_retained_coverage']}
            except Exception:
                row.update(status='snapshot_read_or_identity_failed',error=traceback.format_exc())
        report['rows'].append(row)
    process_rows=[];queue=[1969395];seen=set()
    while queue:
        pid=queue.pop()
        if pid in seen:continue
        seen.add(pid)
        try:
            proc=Path('/proc')/str(pid)
            command=(proc/'cmdline').read_bytes().split(b'\0')
            words=[c.decode(errors='replace') for c in command if c]
            if pid==1969395 and ('-c' not in words or sha(words[words.index('-c')+1].encode())!='da15ff9b0dcf6ba8e2b08af1800763845ad0b7551671d7a33f74190aebc9fd47'):
                continue
            label='bootstrap' if pid==1969395 else next((Path(w).name for w in words if str(PROGRAM)+'/' in w),None)
            if label is None:continue
            children=[int(p) for p in (proc/'task'/str(pid)/'children').read_text().split()]
            queue.extend(children)
            raw=(proc/'stat').read_text();fields=raw.rsplit(')',1)[1].split()
            hz=os.sysconf('SC_CLK_TCK')
            row={'pid':pid,'process':label,'state':fields[0],
                 'own_CPU_seconds_lower_bound':(int(fields[11])+int(fields[12]))/hz,
                 'num_threads':int(fields[17]),'stat_sha256':sha(raw.encode()),
                 'observed_utc':datetime.now(timezone.utc).isoformat()}
            if label=='stage.py':
                row['stage']=words[words.index('--stage')+1]
                row['name']=Path(words[words.index('--receipt')+1]).parent.name
            process_rows.append(row)
        except (FileNotFoundError,ProcessLookupError):pass
        except Exception:process_rows.append({'pid':pid,'read_error':traceback.format_exc()})
    report['active_process_CPU_samples']=process_rows
    report['CPU_sample_scope']='Each live process own CPU lower bound from /proc, without children; overlaps its eventual waited stage CPU and must not be added unless a later hard kill leaves that stage unaccounted. Not exact exit rusage.'
    report['outer_stages_complete']=sum(r['status']=='completed' for r in report['rows'])
    finite=[r for r in report['rows'] if r['stage'].startswith('finite-') and r['status']=='completed']
    report['finite_completed']=len(finite)
    report['finite_passed']=sum(r['numerical']['status']=='passed_fixture' for r in finite)
    report['finite_HOLD']=[r for r in finite if r['numerical']['status']!='passed_fixture']
    report['stage_failures']=[r for r in report['rows'] if r['status'] not in ['completed','not_yet_observed_started','artifact_pending_or_unfinished']]
    receipt=BASE/'numerics-final-audit-launch-v1/receipt.json'
    report['original_launcher_receipt_present']=receipt.exists()
    if receipt.exists():report['original_launcher_receipt']=read(receipt)
    report.update(output=str(out),wall_sample_seconds=time.monotonic()-started,CPU_sample_seconds=time.process_time(),
                  observer_peak_RSS_sample_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
                  observer_timing_scope='This short read-only JSON/proc snapshot sample before serialization; separate from and possibly overlapping main audit.',energy_joules=None)
    (out/'RESULT.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    summary={k:v for k,v in report.items() if k!='rows'}
    summary['completed_logrisk']=[r for r in report['rows'] if r['stage']=='logrisk' and r['status']=='completed']
    (out/'SUMMARY.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
    print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
