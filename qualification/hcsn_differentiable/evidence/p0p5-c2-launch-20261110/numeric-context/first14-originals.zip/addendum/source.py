"""Join an existing nine-case observer with five subsequently recovered originals."""
import hashlib
import json
import math
from pathlib import Path
import time
import zipfile

BASE = Path('/workspace/scratch/c385a7439f8e')
OUT = BASE / 'terminal-finite-first14-provenance-v1'
NATIVE = '/home/qian-qi/hepta-hcsn-final-numerics-20261110-c385-v1'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_values(value):
    a, r, e = value['projected'], value['reference'], value['scaled_errors']
    assert len(a) == len(r) == len(e) == 4
    assert all(math.isfinite(x) for x in a + r + e)
    assert all(abs(abs(x-y)/max(1,abs(y))-z) <= 1e-15 for x,y,z in zip(a,r,e))
    assert value['status'] == 'passed_fixture'
    assert max(e) <= .01 and value['reference_refinement_delta'] <= 2e-8
    assert value['mass_residual'] <= 5e-11


def main():
    start = time.monotonic()
    OUT.mkdir(exist_ok=False)
    observer_dir = BASE / 'final-numerics-observer-202639-v1'
    observer_path = observer_dir / 'RESULT.json'
    assert sha(observer_path) == '15a18874be1496c84234dcf1c61f9ddd0ec4bb4adf83d4e575487d88066e348b'
    observer = json.loads(observer_path.read_bytes())
    summary_path = observer_dir / 'SUMMARY.json'
    summary = json.loads(summary_path.read_bytes())
    assert all(observer[k] == v for k,v in summary.items() if k != 'completed_logrisk')
    source = BASE / 'observe_terminal_audit_v1.py'
    assert sha(source) == observer['source_sha256']
    plan_path = BASE / 'final-hcsn-auditor-v1/PLAN.json'
    assert sha(plan_path) == observer['plan_sha256']
    plan = json.loads(plan_path.read_bytes())
    rows = []
    inputs = [observer_path, summary_path, observer_dir/'RESULT-DOWNLOAD.json', source, plan_path]
    for row in observer['rows']:
        if not row['stage'].startswith('finite-') or row['status'] != 'completed':
            continue
        value = row['numerical']
        check_values(value)
        rows.append({'name': row['name'], 'stage': row['stage'],
                     'original_result_path': NATIVE+'/'+row['name']+'/'+row['stage']+'.json',
                     'original_result_sha256': row['result_sha256'],
                     'original_outer_sha256': row['outer_sha256'],
                     'source_scope': 'Original source-bound observer copied these fields after checking the full stage hash, status, source/input stability and plan SHA.',
                     'observer_original_sha256': sha(observer_path),
                     'original_numerical_status_field': 'result.status',
                     'original_numerical_status_value': value['status'],
                     'primary_scaled_pass': True, 'primary_scaled_pass_is_derived_alias': True,
                     'numerical_fields': value, 'original_returncode': row['returncode'],
                     'original_outer_wall_seconds': row['wall_seconds'],
                     'original_waited_stage_CPU_seconds': row['CPU_seconds']})
    assert len(rows) == observer['finite_completed'] == observer['finite_passed'] == 9
    later = [('final-numerics-provisional-2043-v1', 'hcsn-s211-lr0.003', 'finite-best-1'),
             ('final-numerics-provisional-2043-v1', 'hcsn-s307-lr0.001', 'finite-best-1'),
             ('final-numerics-provisional-2043-v1', 'hcsn-s307-lr0.003', 'finite-best-1'),
             ('final-numerics-provisional-2056-v1', 'hcsn-s101-lr0.001', 'finite-best-2'),
             ('final-numerics-provisional-2056-v1', 'hcsn-s101-lr0.003', 'finite-best-2')]
    for directory, name, stage in later:
        path = BASE / directory / (name+'__'+stage+'.json')
        outer_path = BASE / directory / (name+'__'+stage+'-outer.json')
        payload, outer = json.loads(path.read_bytes()), json.loads(outer_path.read_bytes())
        assert sha(path) == outer['result_sha256']
        assert payload['stage'] == stage and payload['execution_status'] == outer['execution_status'] == 'completed'
        assert outer['returncode'] == 0 and outer['stop_cause'] is None
        argv = outer['argv']
        assert argv[argv.index('--output')+1] == NATIVE+'/'+name
        assert argv[argv.index('--stage')+1] == stage
        assert payload['input_receipt_sha256'] == payload['input_receipt_sha256_after'] == argv[argv.index('--receipt-sha256')+1]
        assert payload['original_inputs_unchanged'] and payload['auditor_source_unchanged']
        assert payload['plan_sha256'] == payload['fixed_plan_sha256_after'] == sha(plan_path)
        value = payload['result']
        assert value['fixture'] == plan['finite_schedule_fixtures_per_primary_checkpoint'][int(stage.rsplit('-',1)[1])]
        check_values(value)
        inputs += [path, outer_path]
        rows.append({'name': name, 'stage': stage,
                     'original_result_path': NATIVE+'/'+name+'/'+stage+'.json',
                     'original_result_sha256': sha(path), 'original_outer_sha256': sha(outer_path),
                     'source_scope': 'Complete original result and original outer receipt recovered and SHA-verified in cloud.',
                     'original_numerical_status_field': 'result.status',
                     'original_numerical_status_value': value['status'],
                     'primary_scaled_pass': True, 'primary_scaled_pass_is_derived_alias': True,
                     'numerical_fields': {key:value.get(key) for key in ('status','horizon','intervals','scaled_errors','relative_errors','reference_refinement_delta','mass_residual','reference','projected')},
                     'original_returncode': outer['returncode'],
                     'original_outer_wall_seconds': outer['whole_process_wall_seconds'],
                     'original_waited_stage_CPU_seconds': outer['waited_child_CPU_seconds']})
    expected = [(name, 'finite-best-'+str(index)) for index in (0,1) for name in plan['fit_roster']]
    expected += [(name, 'finite-best-2') for name in plan['fit_roster'][:2]]
    assert [(r['name'], r['stage']) for r in rows] == expected
    assert len(set((r['name'],r['stage']) for r in rows)) == 14
    report = {'schema': 'terminal-finite-first14-source-chain-addendum-v1',
              'no_model_or_oracle_execution': True, 'scope': 'Only the first14 already completed finite fixtures, as used by the frozen C2 decision; no later fixtures or full-domain admission.',
              'observed_case_count': 14, 'original_passed_fixture_count': 14,
              'primary_scaled_pass_definition': 'Derived alias for original result.status == passed_fixture, independently checked against the stored scalar gate. The raw original JSON has no primary_scaled_pass field.',
              'scaled_definition': 'abs(projected-reference)/max(1,abs(reference)); not a blanket relative1% guarantee.',
              'scaled_limit': .01, 'reference_refinement_limit': 2e-8, 'mass_residual_limit': 5e-11,
              'first9_scope': 'Original immutable observer full report with per-case result/outer SHA and copied numeric fields.',
              'subsequent5_scope': 'Complete original per-stage result and outer files.',
              'original_observer_sha256': sha(observer_path), 'original_observer_summary_sha256': sha(summary_path),
              'plan_sha256': sha(plan_path), 'source_sha256': sha(__file__), 'rows': rows,
              'scientific_admission': 'HOLD', 'whole_training_domain_admission': 'HOLD',
              'C2_decision_modified': False,
              'original_14_stage_outer_wall_seconds_nested_not_additional': sum(r['original_outer_wall_seconds'] for r in rows),
              'original_14_waited_stage_CPU_seconds_nested_not_additional': sum(r['original_waited_stage_CPU_seconds'] for r in rows),
              'extraction_wall_sample_seconds': time.monotonic()-start,
              'extraction_CPU_sample_seconds': time.process_time()}
    (OUT/'RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    files=[('addendum/RESULT.json',OUT/'RESULT.json'), ('addendum/source.py',Path(__file__))]
    for index,path in enumerate(inputs):
        files.append((f'originals/{index:02d}-'+path.name,path))
    manifest=[{'path':member,'bytes':path.stat().st_size,'sha256':sha(path)} for member,path in files]
    (OUT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    archive=Path(str(OUT)+'.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as zipped:
        for member,path in files:zipped.write(path,member)
        zipped.write(OUT/'MANIFEST.json','MANIFEST.json')
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        for item in manifest:
            raw=zipped.read(item['path']);assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
    receipt={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(manifest)+1,
             'RESULT_sha256':sha(OUT/'RESULT.json'),'CRC_and_each_member_verified':True}
    (OUT/'ARCHIVE-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
