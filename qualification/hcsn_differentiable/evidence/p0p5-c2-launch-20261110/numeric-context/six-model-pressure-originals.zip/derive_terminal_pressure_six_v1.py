"""Read-only six-model pressure summary from the complete original observer JSON."""
import hashlib
import json
import math
from pathlib import Path
import time
import zipfile


BASE = Path('/workspace/scratch/c385a7439f8e')
OUT = BASE/'terminal-six-model-pressure-summary-v1'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    started = time.monotonic()
    original = BASE/'final-numerics-observer-202639-v1/RESULT.json'
    assert sha(original) == '15a18874be1496c84234dcf1c61f9ddd0ec4bb4adf83d4e575487d88066e348b'
    observer = json.loads(original.read_bytes())
    source = BASE/'observe_terminal_audit_v1.py'
    assert sha(source) == observer['source_sha256']
    names = [f'hcsn-s{seed}-lr{lr}' for seed in (101,211,307) for lr in ('0.001','0.003')]
    domains = [r for r in observer['rows'] if r['stage'] in ('domain-best','domain-last')]
    assert len(domains) == 12 and all(r['status']=='completed' for r in domains)
    assert {(r['name'],r['stage']) for r in domains} == {(n,s) for n in names for s in ('domain-best','domain-last')}
    records, sentinels = [], []
    for row in domains:
        value = row['numerical']
        count = value['records']
        assert count == (1536 if row['stage']=='domain-best' else 256)
        records.append({'name':row['name'],'stage':row['stage'],'original_result_sha256':row['result_sha256'],
                        'original_outer_sha256':row['outer_sha256'],
                        'original_result_path':'/home/qian-qi/hepta-hcsn-final-numerics-20261110-c385-v1/'+row['name']+'/'+row['stage']+'.json',
                        'original_records_field':count,
                        'original_state_gradient_checks_passed_field':value['state_gradient_checks_passed']})
        pressure = value['pressure_sentinels']
        if row['stage']=='domain-last':
            assert pressure == []
            continue
        assert len(pressure)==3
        assert [(p['episode_id'],p['position'],p['dt']) for p in pressure] == [
            ('A01-0',31,.0540586),('A04-3072',48,8e-7),('A04-3072',49,1e-7)]
        for p in pressure:
            denominator=max(1.0,abs(p['reference']))
            error=abs(p['projected']-p['reference'])/denominator
            assert math.isfinite(error) and abs(error-p['scaled_error']) <= 1e-14
            assert p['passed'] == (error<=.01)
            sentinels.append({'name':row['name'],'original_domain_result_sha256':row['result_sha256'],
                              **p,'denominator_max1_abs_reference':denominator,
                              'relative_value_error_equals_scaled_here':abs(p['reference'])>1})
    assert len(sentinels)==18 and sum(not p['passed'] for p in sentinels)==12
    groups=[]
    for dt in (.0540586,8e-7,1e-7):
        group=[p for p in sentinels if p['dt']==dt]
        assert len(group)==6
        groups.append({'dt':dt,'case_count':len(group),'passed_count':sum(p['passed'] for p in group),
                       'failed_count':sum(not p['passed'] for p in group),
                       'scaled_error_range':[min(p['scaled_error'] for p in group),max(p['scaled_error'] for p in group)],
                       'reference_value_range':[min(p['reference'] for p in group),max(p['reference'] for p in group)]})
    OUT.mkdir(exist_ok=False)
    report={'schema':'terminal-six-model-original-pressure-summary-v1',
            'source_sha256':sha(__file__),'original_observer_result_sha256':sha(original),
            'original_observer_source_sha256':sha(source),'plan_sha256':observer['plan_sha256'],
            'scope':'Read-only arithmetic on original copied scalar fields in the full observer report. No model, probability flow, reference function, derivative, oracle or training rerun. No new reading of the12 complete domain reports is claimed here.',
            'field_paths':{'domain_record_count':'rows[].numerical.records',
                           'domain_state_gradient_flag':'rows[].numerical.state_gradient_checks_passed',
                           'sentinels':'rows[].numerical.pressure_sentinels[]',
                           'original_pressure_flag':'pressure_sentinels[].passed',
                           'original_error':'pressure_sentinels[].scaled_error'},
            'supplemental_vector_record_count':sum(r['original_records_field'] for r in records),
            'best_supplemental_vector_records':6*1536,'last_supplemental_vector_records':6*256,
            'raw_state_gradient_stage_flags_true':sum(r['original_state_gradient_checks_passed_field'] is True for r in records),
            'domain_stage_count':12,
            'record_denominator_scope':'10752 is the number of supplemental final-checkpoint vector records in these12 stages, not a fraction or count of retained historical training updates. It does not repair the original truncated training trace. This summary reads the observer counts, not each underlying domain vector record.',
            'gradient_scope':'Original stage flag covers mass/event replay and basis plus posterior-held-fixed physical derivative checks on exported states; it is not an end-to-end learned-network gradient proof.',
            'pressure_quantity':'Infinite-repeat discounted value, not finite-horizon event count or probability.',
            'pressure_error_definition':'abs(projected-reference)/max(1,abs(reference)); original pass threshold .01. All18 stored reference magnitudes exceed1, so these particular scaled errors equal relative value errors.',
            'pressure_case_count':18,'pressure_passed_count':6,'pressure_failed_count':12,
            'last_checkpoint_pressure_scope':'not_applicable: no last-checkpoint infinite-repeat sentinel is in this plan.',
            'finite_burst_distinction':'Finite burst fixtures begin at posterior position47 and use the actual future gap string. Tiny-gap pressure sentinels begin at posteriors48/49 and artificially repeat their specified gap forever; the conditions and horizons differ.',
            'groups':groups,'domain_stages':records,'pressure_cases':sentinels,
            'scientific_admission':'HOLD','whole_training_domain_admission':'HOLD',
            'metadata_wall_sample_seconds':time.monotonic()-started,'metadata_CPU_sample_seconds':time.process_time()}
    assert report['supplemental_vector_record_count']==10752
    (OUT/'RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    members=[('RESULT.json',OUT/'RESULT.json'),('derive_terminal_pressure_six_v1.py',Path(__file__)),
             ('original-observer-RESULT.json',original),('original-observer-source.py',source)]
    manifest=[{'path':name,'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in members]
    (OUT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    archive=Path(str(OUT)+'.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as zipped:
        for name,path in members:zipped.write(path,name)
        zipped.write(OUT/'MANIFEST.json','MANIFEST.json')
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        for item in manifest:
            raw=zipped.read(item['path']);assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
    receipt={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),
             'result_sha256':sha(OUT/'RESULT.json'),'CRC_and_each_member_verified':True}
    (OUT/'ARCHIVE-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
