"""Read-only arithmetic extraction of already computed native log-risk JSON.

This reads one complete original plus source-bound complete query fragments.
It does not import Torch, mpmath, a model, or an oracle, and changes no result.
"""

import hashlib
import json
import math
import pathlib
import resource
import time
from datetime import datetime, timezone


BASE = pathlib.Path('/workspace/scratch/c385a7439f8e')
RECOVERY = BASE / 'final-logrisk-six-originals-recovery-v1'
OUTPUT = BASE / 'six-logrisk-query-confirmation-v1'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    started = time.monotonic()
    OUTPUT.mkdir(exist_ok=False)
    original = BASE / 'final-logrisk-original-v1/hcsn-s101-lr0.001-logrisk.json'
    raw = original.read_bytes()
    report = json.loads(raw)
    reference_query = report['result']['queries'][5]
    reference_bad = [d for d in reference_query['derivatives']
                     if d['FP64_FD_disposition'] == 'disagrees_above_resolution']
    assert len(reference_bad) == 1 and reference_bad[0]['parameter_index'] == 4
    bad = reference_bad[0]
    observer_path = BASE / 'final-numerics-observer-202639-v1/SUMMARY.json'
    observer_raw = observer_path.read_bytes()
    observer = json.loads(observer_raw)
    observed = {r['name']: r for r in observer['completed_logrisk']}
    transfers_path = RECOVERY / 'DOWNLOAD-PARTIAL.json'
    transfer_raw = transfers_path.read_bytes()
    transfers = json.loads(transfer_raw)
    entries = []
    name = 'hcsn-s101-lr0.001'
    assert digest(raw) == observed[name]['result_sha256']
    entries.append({'name': name, 'full_original_sha256': digest(raw),
                    'full_original_bytes': len(raw), 'read_scope': 'complete_original',
                    'query_index': 5, 'query_matches_first_original': True})
    for info in transfers['sources']:
        name = pathlib.PurePosixPath(info['path']).parent.name
        assert info['sha256'] == observed[name]['result_sha256']
        path = RECOVERY / name / '16384.bin'
        fragment = path.read_bytes()
        explicit = RECOVERY / name / 'query-fragment-read.json'
        if explicit.exists():
            metadata = json.loads(explicit.read_bytes())
        else:
            metadata = next(x['chunk'] for x in transfers['chunks']
                            if x['name'] == name and x['offset'] == 16384)
        assert digest(fragment) == metadata['chunk_sha256']
        assert metadata['version'] == info['version']
        assert metadata['offset'] == 16384 and metadata['next_offset'] == 32768
        text = fragment.decode('utf-8')
        decoder = json.JSONDecoder()
        matches = []
        for position, character in enumerate(text):
            if character != '{':
                continue
            try:
                value, length = decoder.raw_decode(text[position:])
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict) and value == reference_query:
                matches.append((position, length))
        assert len(matches) == 1, (name, len(matches))
        position, length = matches[0]
        # All bytes before this ASCII JSON point are ASCII; byte offsets are exact.
        query_raw = text[position:position + length].encode('utf-8')
        assert json.loads(query_raw) == reference_query
        (OUTPUT / (name + '-query.json')).write_bytes(query_raw)
        entries.append({'name': name, 'native_original_path': info['path'],
                        'full_original_sha256': info['sha256'],
                        'full_original_bytes': info['size'], 'version': info['version'],
                        'read_scope': 'complete_query_in_pinned_version_binary_fragment',
                        'fragment_sha256': digest(fragment),
                        'fragment_byte_range': [16384, 32768],
                        'query_original_byte_range': [16384 + position, 16384 + position + length],
                        'query_raw_sha256': digest(query_raw),
                        'query_matches_first_original_index': 5,
                        'query_matches_first_original': True})
    for row in entries:
        numerical = observed[row['name']]['numerical']
        assert numerical['primary_passed'] is False
        assert numerical['direct_FD_inconclusive_count'] == 96
        assert numerical['direct_FD_resolved_disagreement_count'] == 1
        row['original_summary_fields'] = numerical
        row['outer_sha256'] = observed[row['name']]['outer_sha256']
    derivative_limit = 3e-10
    scalar = dict(bad)
    scalar.update(coordinate='discount', query_index_in_complete_first_original=5,
                  function='log G', inputs=reference_query['inputs'],
                  fixed_nominal_h=2 ** -20 * max(abs(reference_query['inputs'][4]), 1e-8),
                  scaled_error_limit=derivative_limit,
                  AD_absolute_error=abs(bad['AD'] - bad['reference_derivative']),
                  reference_FD_absolute_error=abs(bad['reference_FD'] - bad['reference_derivative']),
                  FP64_FD_absolute_error=abs(bad['FP64_FD'] - bad['reference_derivative']))
    assert scalar['AD_scaled_error'] <= derivative_limit
    assert scalar['reference_FD_scaled_error'] <= derivative_limit
    assert scalar['FP64_FD_scaled_error'] > derivative_limit
    result = {
        'schema': 'six-native-logrisk-original-query-confirmation-v1',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'source_sha256': digest(pathlib.Path(__file__).read_bytes()),
        'original_observer_summary_sha256': digest(observer_raw),
        'partial_download_metadata_sha256': digest(transfer_raw),
        'same_complete_query_confirmed_for_all_six': len(entries) == 6,
        'scope': 'Original stored query and scalar arithmetic only; no model or oracle rerun. '
                 'Five source-bound fragments confirm this query, not a new full-report read.',
        'six_original_primary_passed_fields_remain_false': True,
        'new_scientific_or_whole_domain_admission': False,
        'failure': scalar, 'query': reference_query, 'fits': entries,
        'interpretation': 'The ordinary FP64 finite-difference confirmation gate did not pass. '
                          'At this recorded point, AD and both 80-digit derivative checks agree '
                          'within the frozen gate. This is not evidence of an erroneous training '
                          'gradient. The rounding-resolution estimate is not a complete bound '
                          'on function-evaluation or finite-difference truncation error.',
        'sampling_scope': 'Local metadata/JSON/scalar extraction sampled before serialization; '
                          'no native audit CPU included.',
        'CPU_sample_seconds': time.process_time(),
        'wall_sample_seconds': time.monotonic() - started,
        'peak_RSS_sample_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
    }
    save(OUTPUT / 'RESULT.json', result)
    save(OUTPUT / 'MANIFEST.json', [
        {'path': p.name, 'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())}
        for p in sorted(OUTPUT.iterdir()) if p.is_file()
    ])
    print(json.dumps({'path': str(OUTPUT / 'RESULT.json'),
                      'sha256': digest((OUTPUT / 'RESULT.json').read_bytes()),
                      'all_six_match': result['same_complete_query_confirmed_for_all_six'],
                      'failure': scalar}))


if __name__ == '__main__':
    main()
