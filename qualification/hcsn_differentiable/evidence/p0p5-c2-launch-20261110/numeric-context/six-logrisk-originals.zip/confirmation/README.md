# Six terminal-checkpoint log-risk query confirmation

This is a read-only extraction of existing native results. No model, oracle, derivative, training step or alternate finite-difference step was executed. All six original `primary_passed` fields remain false.

The one resolved ordinary-FP64 finite-difference disagreement is the same complete stored query in all six fits: log G, distance 0.009375, gap 0.1081168, drift -0.11999999999999998, noise 0.35 and discount 0.15, derivative with respect to discount. AD differs from the stored 80-digit reference by 5.204170427930421e-17; the ordinary FP64 FD differs by 5.99673686575708e-10, above the frozen 3e-10 scaled gate. The recorded high-precision central FD agrees with the reference to the report's FP64 representation.

This identifies a failed ordinary-FD confirmation gate. It does not establish a wrong AD derivative or an erroneous trained-model gradient. The rounding-resolution estimate is not a complete bound on function-evaluation error or truncation error. No qualification or parameter-domain claim is upgraded.

The first report is recovered in full and bound by SHA256. For the other five, the complete query is parsed from an immutable-version binary fragment, tied to each full file SHA256 and to the earlier original stage observer. The full original reports remain in the original native audit output; these five full reports have not all been recovered to cloud. Partial transport errors are preserved separately and are not numerical failures.

`RESULT.json` records all five fragment byte ranges and independent hashes, the six complete original identities, and the original failure values. `confirm_six_logrisk_query_v1.py` is the exact scalar-only extraction source; its observed cloud command exit was 0 in 0.047539261 s (tool wall scope), with the separate self CPU/wall samples in RESULT. The package includes exact input bytes and a member manifest. This evidence is supplementary to the unchanged original 96-stage audit and its original 3-hour ceiling.
