if result_path.is_file():
    row['result'] = identity(result_path)
    result = json.loads(result_path.read_bytes())
    row.update(fit_status=result['status'], adequate=result['training_adequacy_established'], cumulative_epochs_completed=result['cumulative_epochs_completed'])
row['status'] = 'timed_out' if row['hard_timeout_sent'] else 'completed' if row['returncode'] == 0 else 'failed'

def cost_totals(attempts, names):
    missing_terminal = sorted(set(names) - {r['name'] for r in attempts})
    incomplete = set(missing_terminal)
    unknown_launch = set(missing_terminal)
    for row in attempts:
        if row.get('process_started') is None:
            unknown_launch.add(row['name'])
        if row.get('whole_process_wall_seconds') is None or row.get('attempt_wrapper_wall_seconds') is None or row.get('terminal_accounting_incomplete') or row.get('journal_errors') or row.get('child_terminal_unknown') or (row.get('process_started') is True and row.get('child_cpu_seconds') is None):
            incomplete.add(row['name'])
    return {'missing_terminal_attempt_names': missing_terminal, 'actual_continuations_started': sum((r.get('process_started') is True for r in attempts)), 'launch_status_unknown_names': sorted(unknown_launch), 'actual_continuations_started_is_lower_bound': bool(unknown_launch), 'sum_attempt_outer_wall_seconds': sum((r['whole_process_wall_seconds'] for r in attempts if r.get('whole_process_wall_seconds') is not None)), 'sum_attempt_wrapper_wall_seconds': sum((r['attempt_wrapper_wall_seconds'] for r in attempts if r.get('attempt_wrapper_wall_seconds') is not None)), 'sum_exact_per_child_cpu_seconds': sum((r['child_cpu_seconds'] for r in attempts if r.get('child_cpu_seconds') is not None)), 'attempt_cost_accounting_complete': not incomplete, 'incomplete_attempt_accounting_names': sorted(incomplete), 'attempt_sums_are_lower_bounds': bool(incomplete)}
