# Candidate v3: actual visit coverage and reserved finalization budget

The v1 and v2 source capsules, validation logs and discovered counterexamples are retained unchanged. Independent review reproduced the old optimization trace gate accepting duplicate time positions, omitted batch members, changed dt and an incorrect network digest while preserving the expected row count. The counterexample used pure metadata and no production model or optimization.

V3 binds every recorded optimization row to the actual input microbatch: the exact time position, ordered valid batch indices, dt values, network model digest, logical update index, episode order, one-layer/capture identity and probability-state shape. The footer must match retained rows, excluded padding, zero drops, exact source hashes and the counted valid sample states. These checks run before the optimizer step. They do not grant numerical accuracy or full training-domain coverage.

V3 also changes the finalization reserve from120 to600 seconds. The cumulative active wall cap remains43,200 seconds. Reserving600 seconds means the main loop stops earlier within the same envelope; recording, complete D evaluation, cache work, checkpoint I/O and any failed finalization remain charged. No unused parent work or new phase work is refunded. The old120-second contract is preserved in earlier capsules. A hard deadline or failed terminal artifact still prevents a success/adequacy claim.

No core numerical method, physical parameter domain, model initialization, gradient formula, learning rate, seed or diagnostic is changed. Real C2 execution remains unstarted. The pending native preflight is limited to synthetic software tests and read-only structural admission of the six existing parent chains.
