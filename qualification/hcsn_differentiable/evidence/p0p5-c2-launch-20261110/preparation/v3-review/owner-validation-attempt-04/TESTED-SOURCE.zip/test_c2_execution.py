"""Real tiny-model software tests; synthetic metadata is never native research evidence."""
import copy
from concurrent.futures import Future
import importlib.util
import json
from pathlib import Path
import random
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

import torch

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE / 'guards/c1-local-validation/source'
sys.path.insert(0, str(ORIGINAL / 'proposals/localization-v3'))
spec = importlib.util.spec_from_file_location('tiny_c2_execution_fixture', ORIGINAL / 'proposals/localization-v3/test_continuation.py')
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)

from c2_boundary import Ineligible
from c2_controller import child_deadline, cost_totals, harvest_futures, wait_child, verify_roster
from c2_io import (bind_parent, bind_study, exclusive_json, identity, immutable_checkpoint,
                   runtime_identity, semantic_digest, sha, state_equal)
from c2_recording import OptimizationRecorder, ProgressRecorder, RecordingHold
from c2_runner import Budget, ResourceStop, epoch_clocks, require_decision, run_bound


def write(path, value):
    Path(path).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
    return sha(path)


class ExecutionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture.ContinuationTests.setUpClass()
        cls.fixture = fixture.ContinuationTests(methodName='test_hcsn_cold_cache_rebuild_preserves_exact_updates')
        cls.fixture.setUp()
        manifest_path = cls.fixture.prepared / 'data-manifest.json'
        manifest = json.loads(manifest_path.read_bytes())
        manifest['confirmation_access'] = False
        cls.fixture.manifest_sha = write(manifest_path, manifest)
        cls.parent, _, cls.original_report = cls.fixture.run_original(
            cls.fixture.arguments(cls.fixture.root / 'base-two', arm='hcsn', max_epochs=2))
        cls.full, _, cls.full_report = cls.fixture.run_original(
            cls.fixture.arguments(cls.fixture.root / 'reference-four', arm='hcsn', max_epochs=4))
        cls.study = bind_study(ORIGINAL)

    @classmethod
    def tearDownClass(cls):
        cls.fixture.doCleanups()

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='explicit-synthetic-c2-execution-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def context(self, partial=False):
        """Construct labelled terminal metadata around an actual tiny checkpoint.

        Wall and diagnostic fields are guard-input fixtures, not measured native
        outcomes. The optional partial optimizer update is actually executed.
        """
        campaign = self.root / 'synthetic-campaign'
        campaign.mkdir()
        parent = campaign / 'tiny-hcsn'
        shutil.copytree(self.parent, parent)
        plan = json.loads((parent / 'plan.json').read_bytes())
        plan['output'] = str(parent)
        report = copy.deepcopy(self.original_report)
        report['plan_sha256'] = write(parent / 'plan.json', plan)
        report.update(status='budget_exhausted', error='declared resource limit; not convergence',
            wall_seconds=14371.0, peak_rss_bytes=500_000_000,
            memorization={'passed': True, 'scope': 'explicit synthetic guard metadata; not a measured diagnostic'},
            software_fixture_not_native_evidence=True)
        report.pop('stop_reason', None)
        events = [json.loads(line) for line in (parent / 'events.jsonl').read_bytes().splitlines()]
        events = [r for r in events if r['kind'] != 'finished']
        if partial:
            state = torch.load(parent / 'last.pt', weights_only=True)
            data, _, _ = self.fixture.read_fixture(plan['prepared'], plan['manifest_sha256'])
            model = self.study.CoreStudyModel(**state['model_configuration'])
            model.load_state_dict(state['model'])
            optimizer, _ = self.study.adamw(model, plan['learning_rate'], 0.0)
            optimizer.load_state_dict(copy.deepcopy(state['optimizer']))
            rng = random.Random()
            rng.setstate(state['order_rng'])
            torch.set_rng_state(state['torch_rng'])
            order = list(range(len(data['train'])))
            rng.shuffle(order)
            ids, x, dt, y = next(self.study.batches(data['train'], order, plan['batch_size']))
            weights = torch.bincount(torch.tensor([y for r in data['train'] for y in r['y']]), minlength=11).double().rsqrt()
            weights /= weights.mean()
            model.train()
            optimizer.zero_grad(set_to_none=True)
            loss = self.study.backward_effective_batch(model, x, dt, y, weights, micro_batch_size=plan['micro_batch_size'])
            norm = torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
            optimizer.step()
            events.extend([{'kind': 'epoch_started', 'epoch': 3, 'episode_order': [data['train'][i]['id'] for i in order]},
                {'kind': 'update_started', 'phase': 'main', 'episode_ids': ids},
                {'kind': 'optimizer_started', 'phase': 'main'},
                {'kind': 'optimizer_completed', 'phase': 'main', 'number': 7, 'gradient_norm': float(norm), **loss}])
            report['main_updates'] = 7
            interrupted = {'model': model.state_dict(), 'model_configuration': model.construction_configuration,
                'optimizer': optimizer.state_dict(), 'torch_rng': torch.get_rng_state(), 'order_rng': rng.getstate(),
                'epochs_completed': 2, 'main_updates': 7, 'data_manifest_sha256': plan['manifest_sha256']}
            torch.save(interrupted, parent / 'interrupted.pt')
            report['interrupted_checkpoint_sha256'] = sha(parent / 'interrupted.pt')
        events.append({'kind': 'finished', 'status': 'budget_exhausted'})
        (parent / 'events.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in events))
        report['events_sha256'] = sha(parent / 'events.jsonl')
        write(parent / 'result.json', report)
        outer = {'name': parent.name, 'status': 'failed', 'returncode': 2, 'fit_status': 'budget_exhausted',
            'result_sha256': sha(parent / 'result.json'), 'whole_process_wall_seconds': 14374.0,
            'hard_wall_seconds': 14400.0}
        outer_path = self.root / 'outer.json'
        write(outer_path, outer)
        campaign_sha = write(campaign / 'RESULT.json', {'schema': 'explicit-synthetic-roster', 'attempts': [outer]})
        runtime_path = self.root / 'RUNTIME.json'
        runtime_sha = write(runtime_path, runtime_identity())
        contract = {'parent_campaign_result_sha256': campaign_sha,
            'data_manifest_sha256': plan['manifest_sha256'], 'runtime_identity_path': str(runtime_path),
            'runtime_identity_sha256': runtime_sha, 'cumulative_active_wall_seconds': 43200,
            'maximum_epochs': 4, 'finalization_reserve_seconds': 1}
        bound = bind_parent(parent, outer_path, ORIGINAL, contract, data_reader=self.fixture.read_fixture)
        rows = bound.data['train'][:3]
        manifest = bound.manifest
        entries = {json.loads((self.fixture.prepared / e['path']).read_bytes())['id']: e for e in manifest['episodes']}
        policy = json.loads((HERE / 'POSTERIOR-POLICY.json').read_bytes())
        policy.update(data_manifest_sha256=plan['manifest_sha256'], absolute_complete_epoch_slots=[3, 4],
            maximum_slots_per_fit=5, maximum_records_per_episode=5,
            episodes=[{'id': r['id'], 'events': len(r['y']), 'path': entries[r['id']]['path'],
                       'sha256': entries[r['id']]['sha256']} for r in rows])
        policy_path = self.root / 'supplement.json'
        write(policy_path, policy)
        actual = json.loads((HERE / 'OPTIMIZATION-POSTERIOR-POLICY-v2.json').read_bytes())
        actual.update(data_manifest_sha256=plan['manifest_sha256'], absolute_epoch_slots=[3, 4],
            maximum_slots_per_fit=3, maximum_records_per_slot=5)
        actual_path = self.root / 'actual.json'
        write(actual_path, actual)
        return bound, contract, policy_path, actual_path

    def run_candidate(self, bound, contract, policy, actual):
        torch.manual_seed(8721)
        return run_bound(bound, self.root / 'continued', contract, policy,
            optimization_policy_path=actual, process_started=time.monotonic(), production=False)

    def test_real_partial_discard_and_two_epoch_replay_equal_uninterrupted(self):
        bound, contract, policy, actual = self.context(partial=True)
        before = {name: identity(name) for name in bound.inputs}
        result = self.run_candidate(bound, contract, policy, actual)
        self.assertEqual(result['status'], 'completed_development', result.get('error'))
        self.assertEqual(result['new_main_updates'], 6)
        self.assertEqual(result['logical_main_updates'], 12)
        self.assertEqual(result['actual_executed_main_updates_logged_all_phases'], 13)
        self.assertEqual(result['parent_work']['completed_updates_after_anchor'], 1)
        self.assertEqual(result['refund_for_discarded_parent_work_seconds'], 0)
        self.fixture.assert_checkpoint_equal(self.full / 'last.pt', self.root / 'continued/last.pt')
        self.fixture.assert_checkpoint_equal(self.full / 'best.pt', self.root / 'continued/best.pt')
        self.fixture.assert_checkpoint_equal(bound.parent / 'last.pt', self.root / 'continued/resume-start.pt')
        self.assertEqual(before, {name: identity(name) for name in bound.inputs})
        report = json.loads((self.root / 'continued/RESUME-START.json').read_bytes())
        self.assertTrue(report['actual_restored_state_equal_parent_last'])
        self.assertEqual(report['new_optimizer_steps_before_receipt'], 0)
        events = [json.loads(line) for line in (self.root / 'continued/events.jsonl').read_bytes().splitlines()]
        self.assertLess(next(i for i,r in enumerate(events) if r['kind'] == 'resume_start_committed'),
                        next(i for i,r in enumerate(events) if r['kind'] == 'optimizer_started'))
        a = next(r for r in events if r['kind'] == 'optimizer_completed')
        b = next(r for r in bound.events if r['kind'] == 'optimizer_completed' and r.get('number') == 7)
        self.assertEqual(a['loss'], b['loss'])
        self.assertEqual(a['gradient_norm'], b['gradient_norm'])
        for row in result['epochs']:
            self.assertEqual(row['cumulative_process_wall_seconds'], 14374.0 + row['phase_process_wall_seconds'])
        slots = result['actual_optimization_recording']['slots']
        self.assertTrue(all(r['status'] == 'captured_actual_gradient_microbatch' for r in slots))
        self.assertTrue(all(r['optimizer_step_completed'] for r in slots))
        self.assertEqual(slots[0]['logical_completed_updates_before_step'], 6)
        self.assertEqual(slots[0]['actual_logged_main_updates_before_step'], 7)
        self.assertTrue(all(r['neutrality']['existing_gradients_unchanged'] for r in result['posterior_recording']['slots']))

    def test_truncated_actual_microbatch_stops_before_first_optimizer_step(self):
        bound, contract, policy, actual = self.context()
        value = json.loads(actual.read_bytes())
        value['maximum_records_per_slot'] = 1
        write(actual, value)
        result = self.run_candidate(bound, contract, policy, actual)
        self.assertEqual(result['status'], 'recording_hold', result.get('error'))
        self.assertEqual(result['new_main_updates'], 0)
        self.assertEqual(result['logical_main_updates'], 6)
        slots = result['actual_optimization_recording']['slots']
        self.assertTrue(slots[0]['footer']['truncated'])
        self.assertFalse(slots[0]['optimizer_step_completed'])
        self.assertFalse((self.root / 'continued/optimization-windows/epoch-0003-first-main-microbatch/STEP-COMPLETED.json').exists())

    def test_resume_witness_io_failure_prevents_optimization(self):
        bound, contract, policy, actual = self.context()
        original = immutable_checkpoint
        def fail_witness(path, state):
            if Path(path).name == 'resume-start.pt':
                raise OSError('deliberate witness write failure')
            return original(path, state)
        with mock.patch('c2_runner.immutable_checkpoint', side_effect=fail_witness):
            result = self.run_candidate(bound, contract, policy, actual)
        self.assertEqual(result['new_main_updates'], 0)
        self.assertEqual(result['status'], 'failed')
        self.assertFalse((self.root / 'continued/RESUME-START.json').exists())

    def test_epoch_commit_failure_does_not_advance_retained_boundary(self):
        bound, contract, policy, actual = self.context()
        original = exclusive_json
        def fail_commit(path, value):
            if Path(path).parent.name == 'commits':
                raise OSError('deliberate complete-epoch commit failure')
            return original(path, value)
        with mock.patch('c2_runner.exclusive_json', side_effect=fail_commit):
            result = self.run_candidate(bound, contract, policy, actual)
        self.assertEqual(result['status'], 'failed')
        self.assertEqual(result['cumulative_epochs_completed'], 2)
        self.assertEqual(result['new_main_updates'], 3)
        self.assertEqual(result['new_unretained_logged_updates'], 3)
        self.fixture.assert_checkpoint_equal(bound.parent / 'last.pt', self.root / 'continued/last.pt')

    def test_bound_parent_modified_after_admission_prevents_first_step(self):
        bound, contract, policy, actual = self.context()
        path = bound.parent / 'plan.json'
        path.write_bytes(path.read_bytes() + b' ')
        result = self.run_candidate(bound, contract, policy, actual)
        self.assertEqual(result['new_main_updates'], 0)
        self.assertEqual(result['status'], 'source_or_parent_changed')
        self.assertFalse(result['source_and_parent_inputs_unchanged'])

    def test_runtime_mismatch_rejects_rebound_manifest_before_model_step(self):
        bound, contract, _, _ = self.context()
        runtime_path = Path(contract['runtime_identity_path'])
        value = json.loads(runtime_path.read_bytes())
        value['packages']['torch']['version'] = 'different-build'
        contract['runtime_identity_sha256'] = write(runtime_path, value)
        with self.assertRaisesRegex(Ineligible, 'runtime differs'):
            bind_parent(bound.parent, self.root / 'outer.json', ORIGINAL, contract, data_reader=self.fixture.read_fixture)

    def test_wrong_parent_outer_even_rehashed_still_rejected_by_roster(self):
        bound, contract, _, _ = self.context()
        outer = json.loads((self.root / 'outer.json').read_bytes())
        outer['whole_process_wall_seconds'] -= 100
        write(self.root / 'outer.json', outer)
        with self.assertRaisesRegex(Ineligible, 'original terminal roster'):
            bind_parent(bound.parent, self.root / 'outer.json', ORIGINAL, contract, data_reader=self.fixture.read_fixture)

    def test_program_input_mismatch_is_before_any_new_step(self):
        bound, contract, policy, actual = self.context()
        path = self.root / 'bound_program.txt'
        path.write_text('original')
        expected = {str(path): identity(path)}
        path.write_text('changed')
        result = run_bound(bound, self.root / 'continued', contract, policy,
            program_inputs=expected, optimization_policy_path=actual,
            process_started=time.monotonic(), production=False)
        self.assertEqual(result['new_main_updates'], 0)
        self.assertEqual(result['status'], 'source_or_parent_changed')

    def test_budget_exhausted_before_restoration_does_not_refund_parent(self):
        bound, contract, policy, actual = self.context()
        result = run_bound(bound, self.root / 'continued', contract, policy,
            optimization_policy_path=actual, process_started=time.monotonic() - 30000, production=False)
        self.assertEqual(result['new_main_updates'], 0)
        self.assertEqual(result['status'], 'budget_exhausted')
        self.assertEqual(result['parent_full_outer_wall_charged'], 14374)
        self.assertFalse(result['training_adequacy_established'])

    def test_changed_parent_during_resume_observation_stops_before_step(self):
        bound, contract, policy, actual = self.context()
        original = ProgressRecorder.capture
        def mutate_after_observation(recorder, slot, *args, **kwargs):
            result = original(recorder, slot, *args, **kwargs)
            if slot == 'resume-start':
                path = bound.parent / 'plan.json'
                path.write_bytes(path.read_bytes() + b' ')
            return result
        with mock.patch.object(ProgressRecorder, 'capture', new=mutate_after_observation):
            result = self.run_candidate(bound, contract, policy, actual)
        self.assertEqual(result['new_main_updates'], 0)
        self.assertEqual(result['status'], 'source_or_parent_changed')

    def test_terminal_capture_budget_failure_cannot_return_completed(self):
        bound, contract, policy, actual = self.context()
        original = ProgressRecorder.capture
        def terminal_budget(recorder, slot, *args, **kwargs):
            if slot.startswith('terminal-'):
                raise ResourceStop('explicit software-only terminal budget fixture')
            return original(recorder, slot, *args, **kwargs)
        with mock.patch.object(ProgressRecorder, 'capture', new=terminal_budget):
            result = self.run_candidate(bound, contract, policy, actual)
        self.assertEqual(result['status'], 'budget_exhausted_finalization')
        self.assertFalse(result['training_adequacy_established'])
        self.assertEqual(result['posterior_recording']['slots'][-1]['status'], 'not_captured_budget')


class ProtocolTests(unittest.TestCase):
    def test_complete_six_seed_lr_roster_cannot_select_by_quality_or_drop_seed(self):
        originals = [{'arm': 'hcsn', 'name': f'hcsn-s{s}-lr{lr}', 'seed': s, 'learning_rate': lr,
            'status': 'failed', 'fit_status': 'budget_exhausted', 'returncode': 2,
            'development_quality': 0.0} for s in (101,211,307) for lr in (.001,.003)]
        baselines = [{'arm': 'baseline', 'name': f'baseline-{i}'} for i in range(36)]
        campaign = {'status': 'completed_attempt_roster', 'source_unchanged': True, 'attempts': originals + baselines}
        contract = {'fit_names': [r['name'] for r in originals]}
        self.assertEqual(len(verify_roster(contract, campaign)), 6)
        originals[0]['development_quality'] = 1.0
        self.assertEqual(len(verify_roster(contract, campaign)), 6)
        contract['fit_names'].pop()
        with self.assertRaises(Ineligible):
            verify_roster(contract, campaign)

    def test_epoch_clocks_single_sample_exact_cumulative(self):
        clock = mock.Mock(side_effect=[25.25, 9999.0])
        cpu = mock.Mock(return_value=3.75)
        row = epoch_clocks(14374.1, 20.0, monotonic=clock, cpu=cpu)
        self.assertEqual(clock.call_count, 1)
        self.assertEqual(cpu.call_count, 1)
        self.assertEqual(row['cumulative_process_wall_seconds'], 14374.1 + 5.25)
        self.assertIsNone(row['cumulative_process_cpu_seconds'])

    def test_full_parent_cost_and_prelaunch_work_consume_deadline(self):
        end = child_deadline({'cumulative_active_wall_seconds': 43200},
            {'whole_process_wall_seconds': 14374.5, 'hard_wall_seconds': 14400}, 100)
        self.assertEqual(end, 100 + 43200 - 14374.5)
        self.assertEqual(end - 150, 43200 - 14374.5 - 50)
        self.assertNotEqual(end, 100 + 43200 - 552)

    def test_rss_and_finalization_reserve_do_not_extend_budget(self):
        budget = Budget(14374, 43200, 0, 100, 120, lambda: 50, monotonic=lambda: 28750)
        with self.assertRaises(ResourceStop):
            budget.check()
        budget.check(finalizing=True)
        self.assertEqual(budget.remaining(), 76)
        with self.assertRaises(ResourceStop):
            Budget(14374, 43200, 0, 10, 120, lambda: 11, monotonic=lambda: 1).check(finalizing=True)

    def test_no_decision_cannot_enable_real_execution(self):
        with self.assertRaises(Ineligible):
            require_decision(None, None, HERE / 'CONTRACT.json', HERE / 'absent-manifest')

    def test_immutable_checkpoint_and_json_reject_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'state.pt'
            state = {'value': torch.tensor([1.0], dtype=torch.float64)}
            before = immutable_checkpoint(path, state)
            with self.assertRaises(FileExistsError):
                immutable_checkpoint(path, {'value': torch.tensor([2.0])})
            self.assertEqual(identity(path), before)
            receipt = Path(directory) / 'receipt.json'
            exclusive_json(receipt, {'state': before})
            with self.assertRaises(FileExistsError):
                exclusive_json(receipt, {})

    def test_future_failure_still_harvests_other_dispatches_and_unknown_cost(self):
        failed, complete = Future(), Future()
        failed.set_exception(OSError('deliberate worker failure'))
        complete.set_result({'name': 'b', 'process_started': True, 'whole_process_wall_seconds': 3,
            'attempt_wrapper_wall_seconds': 4, 'child_cpu_seconds': 2})
        rows = list(harvest_futures({failed: 'a', complete: 'b'}, {}, lambda row: None))
        totals = cost_totals(rows, ['a', 'b', 'c'])
        self.assertEqual(len(rows), 2)
        self.assertEqual(totals['actual_continuations_started'], 1)
        self.assertEqual(totals['missing_terminal_attempt_names'], ['c'])
        self.assertEqual(totals['sum_exact_per_child_cpu_seconds'], 2)
        self.assertFalse(totals['attempt_cost_accounting_complete'])
        self.assertTrue(totals['attempt_sums_are_lower_bounds'])
        self.assertTrue(totals['actual_continuations_started_is_lower_bound'])

    def test_wait4_captures_real_child_cpu_and_timeout_failure(self):
        # These are tiny OS accounting fixtures, not model training processes.
        process = subprocess.Popen([sys.executable, '-c', 'sum(i*i for i in range(20000))'],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        result = wait_child(process, time.monotonic() + 10, poll_seconds=.005)
        self.assertEqual(result['returncode'], 0)
        self.assertGreater(result['child_cpu_seconds'], 0)
        self.assertFalse(result['child_terminal_unknown'])
        process = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(5)'],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        result = wait_child(process, time.monotonic() + .03, poll_seconds=.005)
        self.assertEqual(result['returncode'], -9)
        self.assertTrue(result['hard_timeout_sent'])
        self.assertIsNotNone(result['child_cpu_seconds'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
