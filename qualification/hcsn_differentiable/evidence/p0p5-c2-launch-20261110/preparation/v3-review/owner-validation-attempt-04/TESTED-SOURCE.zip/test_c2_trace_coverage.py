"""Pure metadata regression cases for independently discovered visit-coverage gaps."""
import copy
import unittest

from c2_boundary import Ineligible
from c2_recording import validate_optimization_trace


class TraceCoverageTests(unittest.TestCase):
    def setUp(self):
        self.expected = {'data_manifest_sha256': 'a'*64, 'policy': {'sha256': 'b'*64},
            'trace_source_hashes': {'recorder.py': 'c'*64}, 'expected_positions': [0, 1],
            'expected_batch_indices_by_position': [[0, 1], [0]],
            'expected_dt_by_position': [[0.0, 0.0], [.2]], 'expected_valid_sample_states': 3,
            'expected_padded_sample_states': 1, 'network_model_sha256': 'd'*64,
            'logical_completed_updates_before_step': 9, 'microbatch_episode_ids': ['first', 'second'],
            'probability_state_count': 2}
        self.header = {'data_sha256': 'a'*64, 'configuration_sha256': 'b'*64,
                       'sources': self.expected['trace_source_hashes']}
        self.footer = {'source_unchanged': True, 'sources_after': self.expected['trace_source_hashes'],
            'truncated': False, 'dropped_records': 0, 'captures': 1, 'seen_records': 2,
            'retained_records': 2, 'padded_states_excluded': 1}
        self.visits = []
        for i, indices in enumerate(self.expected['expected_batch_indices_by_position']):
            self.visits.append({'index': i, 'capture': 0, 'layer': 0, 'position': i,
                'batch_indices': indices, 'dt': self.expected['expected_dt_by_position'][i],
                'model_sha256': 'd'*64, 'update_index': 9, 'episode_id': 'first+second',
                'prior': [[.5, .5] for _ in indices], 'posterior': [[.4, .6] for _ in indices],
                'expected_events': [0.0 for _ in indices]})

    def gate(self, visits=None, header=None, footer=None):
        return validate_optimization_trace(self.expected, header or self.header,
            visits if visits is not None else self.visits, footer or self.footer)

    def test_control_counts_exact_valid_samples_and_padding(self):
        self.assertEqual(self.gate(), {'retained_time_rows': 2, 'retained_valid_sample_states': 3,
                                     'excluded_padded_sample_states': 1})

    def test_same_row_count_cannot_hide_duplicate_positions_or_missing_samples(self):
        for field, value in [('position', 0), ('batch_indices', [1])]:
            rows = copy.deepcopy(self.visits)
            rows[1][field] = value
            with self.subTest(field=field), self.assertRaises(Ineligible):
                self.gate(rows)
        rows = copy.deepcopy(self.visits)
        rows[0]['batch_indices'] = [0]
        with self.assertRaises(Ineligible):
            self.gate(rows)

    def test_actual_dt_network_digest_update_episode_and_capture_are_bound(self):
        for field, value in [('dt', [9.0, 9.0]), ('model_sha256', 'e'*64), ('update_index', 0),
                ('episode_id', 'second+first'), ('capture', 1), ('layer', 1)]:
            rows = copy.deepcopy(self.visits)
            rows[0][field] = value
            with self.subTest(field=field), self.assertRaises(Ineligible):
                self.gate(rows)

    def test_footer_counts_and_probability_rows_cannot_omit_valid_state(self):
        for field, value in [('padded_states_excluded', 0), ('seen_records', 3),
                ('retained_records', 1), ('dropped_records', 1), ('truncated', True)]:
            footer = dict(self.footer, **{field: value})
            with self.subTest(field=field), self.assertRaises(Ineligible):
                self.gate(footer=footer)
        rows = copy.deepcopy(self.visits)
        rows[0]['prior'] = [[1.0]]
        with self.assertRaises(Ineligible):
            self.gate(rows)

    def test_trace_header_and_footer_source_maps_must_match_bound_recorder(self):
        with self.assertRaises(Ineligible):
            self.gate(header=dict(self.header, sources={'recorder.py': '0'*64}))
        with self.assertRaises(Ineligible):
            self.gate(footer=dict(self.footer, sources_after={'recorder.py': '0'*64}))


if __name__ == '__main__':
    unittest.main(verbosity=2)
