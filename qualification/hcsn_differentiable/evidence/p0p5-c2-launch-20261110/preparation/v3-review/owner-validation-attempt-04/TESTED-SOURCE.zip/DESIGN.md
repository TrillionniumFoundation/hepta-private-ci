# C2 candidate: bounded continuation from a censored complete epoch

This directory is a preparation artifact. No real C2 optimizer step, snapshot loop, new fit, new learning rate, new seed, or renewed memorization diagnostic is authorized or started. The original v8, C1, and their evidence remain immutable.

## Entry and retained trajectory

The six original HCSN attempts remain the full roster. Selection of an eligible parent depends on its terminal evidence, never on whether its D score is attractive. The controller binds the original campaign result and plan, each final outer row, every parent report/plan/journal/checkpoint, the prepared data manifest, the original loaded source map, and the original runtime identity. It rejects a live or hard-killed process, absent/truncated result, changed source/configuration/data/shared or physical weights, non-passing inherited diagnostic, RSS failure, prior plateau, or inconsistent complete-epoch boundary.

The existing frozen `c2_boundary.py` v2 is reused byte for byte. Its 21 tests remain a separate software qualification record. Its actual complete-epoch ordering, strict prefix-best, optimizer moment age and nonnegative second moments, Torch/order RNG, source-independent configuration, and first historical plateau checks cannot be bypassed by relabeling the parent as completed. The parent remains `budget_exhausted`.

Recovery starts from the original atomic `last.pt` at its latest journal-consistent complete epoch. `interrupted.pt` is preserved as evidence but cannot supply the recovered trajectory. Every logged parent update after the retained epoch is counted as discarded executed work. Any optimizer-start-without-completion interval remains unknown rather than becoming zero. Replayed work is charged again. The parent's complete measured outer wall is deducted from the cumulative allowance; no retained-prefix refund is allowed.

## Budget and clocks

Each fit has at most 43,200 seconds of cumulative active process wall and at most 200 complete logical epochs. The inherited seed, learning rate, effective batch 32, microbatch 8, min-epoch 30, patience 10, delta .002, frozen common frontend/head and physical parameters, learned adapter, and exact full GridSpec stay fixed. The original 300/900/1800-second comparison remains the original budget view. C2 is a separately measured longer-resource view and can extend calendar time beyond the original campaign's 15,000-second endpoint.

Per-fit dispatch precedes its validation/imports, so these costs, cold table reconstruction, checkpoints, posterior observations, final evaluation, failures and cleanup consume the remaining allowance. A finalization reserve is declared rather than silently adding time. Shared controller/source/test preparation is charged once as a separate campaign cost; it is not hidden as free setup. Per-epoch phase wall is sampled once and the cumulative wall is derived from that exact value plus the full original outer cost. New process CPU is measured directly; no exact original parent exit CPU is fabricated. The new controller will retain per-child `wait4` usage as well as aggregate child CPU, with explicit unknown bounds if collection fails.

## First-step witness and checkpoint commits

After restoring the model, optimizer and both RNG states, the runner writes an exclusive `resume-start.pt` from the actual restored objects and validates it against the parent last checkpoint before any optimizer step. An immutable receipt binds its file SHA, semantic state identity, parent sources/weights/plan, retained epoch and update counts, discarded-work accounting and charged parent cost. Failure to finish this witness prevents the first step.

Every newly complete epoch receives an immutable checkpoint and a commit receipt binding the complete epoch metrics, strict best reference, plateau state, model/optimizer/RNG state, and previous commit. Only after that commit are mutable `last.pt`/`best.pt` aliases advanced. A partially completed later epoch remains separately recorded. At most 200 epoch checkpoints exist per fit; all checkpoint I/O and storage are counted.

## Posterior recording frozen before execution

`POSTERIOR-POLICY.json` fixes the three real ABC episodes, their exact hashes, the resume-start window, absolute complete epochs 50/75/100/125/150/175/200, and terminal last/best windows. Each supplied checkpoint is observed on all 256 events of each episode, batch one, with the original model and exact dt, in `no_grad` mode. Every episode gets its own recorder and an 8 MiB/256-record budget. The maximum is ten windows, 240 MiB per fit, 1,440 MiB across six fits. This avoids spending a single recording allowance only on early training.

These are separately labelled evaluation posteriors from the actual current trained checkpoint. They are not a record of every minibatch visited during optimization. They do not repair or overwrite the original truncated trace, and they do not provide whole-training numerical admission. Duplicate model states across scheduled slots are disclosed. Unreached epochs remain unreached. A mandatory scheduled trace that truncates or fails stops further updates with `recording_hold`; a terminal window that cannot fit the remaining resource budget is explicitly absent, without extending or refunding the budget.

The trace operation must preserve model tensors, existing gradients, Torch/order RNG and training mode. Cache counters/tables may change because real cold-cache work is measured and charged, while their exact semantics remain the frozen v8 implementation. The recorder itself and all core numerical/gradient code are unchanged. Window receipts bind checkpoint bytes, full model digest, data and source hashes, footer coverage, wall/CPU/RSS and the exact episode order. Independent numerical analysis remains a later operation.

## Validation before any real execution

The candidate tests will use explicitly synthetic small HCSN fixtures and real model/optimizer updates. Required checks cover uninterrupted versus recovered state, an actual partial epoch discarded and replayed, an immutable first-step witness, source/data/optimizer/RNG/configuration tampering, historical plateau, full parent wall charging, missing or uncertain cost, once-sampled epoch clocks, trace scheduling and budget failures, trace neutrality, and collection of every dispatched controller outcome. These are software tests, not new scientific training evidence. Production source/runtime/data admission and a later explicit execution decision remain separate.
