"""Package the already tested C2 preparation; no native access or training."""
import hashlib
import json
from pathlib import Path
import time
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'c2-candidate-handoff-v1'


def identity(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(path, value):
    Path(path).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def main():
    started, cpu = time.monotonic(), time.process_time()
    OUT.mkdir(exist_ok=False)
    candidate = ROOT / 'c2-execution-candidate-v1'
    one, two = [ROOT / f'c2-execution-validation-attempt-{i:02d}' for i in (1, 2)]
    first, last = [json.loads((p / 'RESULT.json').read_bytes()) for p in (one, two)]
    assert first['returncode'] == 0 and last['all_passed'] and last['source_unchanged']
    for name, digest in last['source_before'].items():
        assert identity(candidate / name)['sha256'] == digest
    handoff = {'schema': 'hcsn-c2-preparation-handoff-v1', 'status': 'software-tested-awaiting-independent-review',
        'real_production_optimizer_steps': 0, 'real_production_checkpoint_reads': 0,
        'execution_authorized': False, 'source_candidate': identity(two / 'TESTED-SOURCE.zip'),
        'program_manifest': identity(candidate / 'PROGRAM-MANIFEST.json'),
        'guard_sha256': identity(candidate / 'c2_boundary.py')['sha256'],
        'candidate_contract': identity(candidate / 'CONTRACT.json'),
        'original_supplement_policy_unchanged': identity(candidate / 'POSTERIOR-POLICY.json'),
        'optimization_policy_v2': identity(candidate / 'OPTIMIZATION-POSTERIOR-POLICY-v2.json'),
        'latest_software_tests': {'original_guard_tests': 21, 'new_execution_tests': 19,
            'total': 40, 'passed': True, 'receipt': identity(two / 'RESULT.json'),
            'whole_wrapper_wall_seconds': last['whole_process_wall_seconds'], 'children_cpu_seconds': last['children_cpu_seconds']},
        'earlier_attempt_preserved': {'tests': 16, 'passed': True, 'receipt': identity(one / 'RESULT.json'),
            'tested_source': identity(one / 'TESTED-SOURCE.zip'),
            'whole_wrapper_wall_seconds': first['whole_process_wall_seconds'], 'children_cpu_seconds': first['children_cpu_seconds']},
        'all_measured_test_attempts_wall_seconds': first['whole_process_wall_seconds'] + last['whole_process_wall_seconds'],
        'all_measured_test_attempts_cpu_seconds': first['children_cpu_seconds'] + last['children_cpu_seconds'],
        'unmeasured_preparation_costs': 'interactive source editing, inspection and preliminary compile were not separately metered; not zero',
        'production_runtime_receipt': identity(candidate / 'NATIVE-RUNTIME-IDENTITY.json'),
        'runtime_read_cost_scope': 'single original byte read; reported functions call wall2.5s includes local filename lookup; individual native CPU unknown',
        'pending': ['independent static review', 'root numerical/full-D assessment and explicit later decision',
                    'native same-runtime software preflight before any production C2 optimizer step'],
        'coverage': 'v2 actual main gradient microbatches are distinct from v1 no-grad checkpoint supplements; sparse visits do not establish whole-training qualification',
        'science_and_numerics': 'HOLD', 'confirmation_E_access': False}
    write(OUT / 'HANDOFF.json', handoff)
    (OUT / 'README.md').write_text('''# C2 implementation candidate\n\nThis is a source-and-software-test handoff, not an executed continuation. The original six HCSN fits remain soft-wall-censored and unchanged. C2 production optimization is still unstarted.\n\n`source-candidate.zip` is the exact final source tested by the 21 original guards and 19 new software tests. `attempt-01` retains the earlier 16-test source and logs. `attempt-02` retains the final test invocation, original stderr and source-before/after digests. No failed attempt is omitted; both measured invocations passed. The native runtime file is an original read-only receipt, not a new runtime installation or model execution.\n\nThe runner binds original terminal outer/report/plan/data/source/runtime/checkpoints, restores only the latest complete last checkpoint, preserves full parent partial-work charges, writes an immutable before-first-step model/Adam/RNG witness, and commits each new complete epoch before advancing last/best aliases. The controller is non-retrying, keeps all six seed/LR opportunities, enforces a cumulative 43,200-second active envelope and 200 epochs, and collects per-PID exit CPU using wait4. Its default mode performs no child training launch; a future execution decision must bind the candidate manifest and contract.\n\nThe preserved v1 recording policy is supplemental no-grad evaluation on three fixed ABC episodes. The separate v2 addendum observes actual main-gradient microbatches at the resume start and fixed epoch boundaries, closes and verifies each trace before the optimizer step, and halts on truncation. Neither form establishes full training-domain numerical qualification. All new captures, failures, cache reconstruction, checkpoint I/O and replay costs are charged. The combined trace payload cap is496MiB per fit.\n\nSoftware tests use explicitly synthetic tiny HCSN data and true model/Adam updates, plus labelled metadata and I/O failure fixtures. They include exact uninterrupted-versus-replayed state after discarding a real partial update, nonzero optimization visit indices without changed gradients, immutable snapshot and commit failures, source/runtime/parent binding, full wall charging, single-sample clocks, complete roster accounting and actual OS timeout/CPU collection. They are not research training evidence.\n\nThe exact candidate has not been deployed or run against the real six models. Independent source review and the original models' numerical/full-D reviews remain separate. No E data are read.\n''')
    members = {'HANDOFF.json': OUT / 'HANDOFF.json', 'README.md': OUT / 'README.md',
               'source-candidate.zip': two / 'TESTED-SOURCE.zip', 'package_c2_candidate_handoff_v1.py': Path(__file__)}
    for label, directory in [('attempt-01', one), ('attempt-02', two)]:
        for path in sorted(directory.iterdir()):
            if path.is_file() and not (label == 'attempt-02' and path.name == 'TESTED-SOURCE.zip'):
                members[label + '/' + path.name] = path
    manifest = {name: identity(path) for name, path in members.items()}
    archive = OUT / 'hcsn-c2-execution-candidate-20261110-v1.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
        for name, path in sorted(members.items()):
            zipped.write(path, name)
        zipped.writestr('MEMBER-MANIFEST.json', json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        for name, item in manifest.items():
            raw = zipped.read(name)
            assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
    assert all(identity(path) == manifest[name] for name, path in members.items())
    write(OUT / 'PACKAGE-RECEIPT.json', {'schema': 'c2-candidate-handoff-archive-v1',
        'archive': identity(archive), 'members': len(manifest) + 1, 'all_hash_and_crc_verified': True,
        'inputs_unchanged': True, 'wall_seconds': time.monotonic() - started,
        'cpu_seconds': time.process_time() - cpu, 'real_optimizer_steps': 0})
    selected = [archive, OUT / 'HANDOFF.json', OUT / 'README.md', OUT / 'PACKAGE-RECEIPT.json']
    for name in ('c2_io.py', 'c2_runner.py', 'c2_recording.py', 'c2_controller.py',
                 'OPTIMIZATION-POSTERIOR-POLICY-v2.json', 'DESIGN-ADDENDUM-v2.md',
                 'CONTRACT.json', 'NATIVE-RUNTIME-IDENTITY.json', 'RUNTIME-READ-RECEIPT.json'):
        selected.append(candidate / name)
    write(OUT / 'COPY_LIST.json', {'schema': 'original-byte-copy-list-v1',
        'files': [{'path': str(path), **identity(path)} for path in selected]})
    print(json.dumps({'archive_path': str(archive), **identity(archive),
        'copy_list': str(OUT / 'COPY_LIST.json'), 'copy_list_sha256': identity(OUT / 'COPY_LIST.json')['sha256']}, sort_keys=True))


if __name__ == '__main__':
    main()
