"""Freeze the reporting-only v4 handoff; never execute a research model."""
from __future__ import annotations

import hashlib
import json
import resource
import time
import zipfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUT = BASE / "c2-candidate-handoff-v4"


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def write_json(path: Path, value: object) -> None:
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def main() -> None:
    started, cpu_started = time.monotonic(), time.process_time()
    OUT.mkdir(exist_ok=False)
    source = BASE / "c2-execution-candidate-v4"
    test_dir = BASE / "c2-execution-validation-attempt-05"
    review_dir = BASE / "c2-v4-budget-reporting-independent-review-v1"
    capsule = test_dir / "TESTED-SOURCE.zip"
    assert identity(capsule)["sha256"] == "95d53c9a8fd7b6d0d60388b29d58519160c1d04357069bd805e5f4bfa2c91079"
    test = json.loads((test_dir / "RESULT.json").read_bytes())
    assert test["returncode"] == 0 and test["source_before"] == test["source_after"]
    review = json.loads((review_dir / "RESULT.json").read_bytes())
    assert review["source_blocker_identified_in_reporting_delta"] is False
    assert review["unchanged_boundary_io_recording_contract_policies"] is True
    assert review["runner_AST_equal_after_stripping_only_reporting_fields"] is True

    payload: dict[str, bytes] = {}
    for path in sorted(test_dir.iterdir()):
        if path.is_file():
            payload["cloud-targeted-tests/" + path.name] = path.read_bytes()
    for path in sorted(review_dir.iterdir()):
        if path.is_file():
            payload["independent-static-review/" + path.name] = path.read_bytes()
    for name in ["PROGRAM-MANIFEST.json", "REPORTING-DELTA.json", "DIFF-v3-to-v4.patch", "REVISION-v4.md"]:
        payload["candidate-identity/" + name] = (source / name).read_bytes()
    payload["packaging-source.py"] = Path(__file__).read_bytes()
    members = {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()} for name, data in sorted(payload.items())}
    payload["PAYLOAD-MANIFEST.json"] = (json.dumps(members, indent=2, sort_keys=True) + "\n").encode()
    archive = OUT / "hcsn-c2-execution-candidate-20261110-v4.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, data in sorted(payload.items()):
            output.writestr(name, data)
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None
        assert set(check.namelist()) == set(payload)
        for name, data in payload.items():
            assert check.read(name) == data

    handoff = {
        "schema": "c2-v4-reporting-only-handoff-v1",
        "source_manifest": identity(source / "PROGRAM-MANIFEST.json"),
        "source_capsule": identity(capsule),
        "candidate_bundle": identity(archive),
        "original_v3_native_receipt": identity(BASE / "c2-native-preflight-recovered-v1" / "RESULT.json"),
        "native_test_scope": "V3 only: 53 synthetic software tests plus six real parent bind-only validations. Model/optimizer construction and loading occurred; no real-data forward/backward/optimizer step.",
        "v4_test_scope": "One existing tiny synthetic exact-replay test plus four reporting regressions. V4 did not receive another native preflight.",
        "v4_targeted_result": identity(test_dir / "RESULT.json"),
        "independent_static_review_result": identity(review_dir / "RESULT.json"),
        "v4_training_recovery_recording_budget_changed": False,
        "cumulative_active_wall_limit_seconds": 43200,
        "max_total_epochs": 200,
        "finalization_reserve_seconds_inside_same_cap": 600,
        "reserve_is_not_a_completion_guarantee": True,
        "supplemental_three_episode_slot_soft_budget_seconds": 120,
        "slot_budget_scope": "One shared soft clock for all three episodes in the capture slot, not 120 seconds for each episode; operation-level overruns may still cause honest budget failure.",
        "real_c2_execution_started": False,
        "real_c2_execution_authorized_by_this_handoff": False,
        "numerical_admission": "HOLD",
        "scientific_admission": "HOLD",
        "all_previous_versions_and_attempt_costs_remain": True,
    }
    write_json(OUT / "HANDOFF.json", handoff)
    write_json(OUT / "PACKAGE-RECEIPT.json", {
        "schema": "local-artifact-packaging-cost-v1",
        "archive": identity(archive),
        "members": len(payload),
        "uncompressed_bytes": sum(map(len, payload.values())),
        "all_original_member_hashes_and_crc_verified": True,
        "wall_seconds": time.monotonic() - started,
        "cpu_seconds": time.process_time() - cpu_started,
        "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        "scope": "Local packaging only, no model execution, test rerun, native deployment or training.",
    })
    copy = [archive, OUT / "HANDOFF.json", OUT / "PACKAGE-RECEIPT.json"]
    copy.extend(source / name for name in ["c2_controller.py", "c2_runner.py", "test_c2_reporting.py", "REVISION-v4.md", "REPORTING-DELTA.json", "DIFF-v3-to-v4.patch"])
    write_json(OUT / "COPY_LIST.json", {"schema": "original-byte-copy-list-v1", "files": [identity(path) for path in copy]})
    print(json.dumps({"copy_list": identity(OUT / "COPY_LIST.json"), "archive": identity(archive)}, sort_keys=True))


if __name__ == "__main__":
    main()
