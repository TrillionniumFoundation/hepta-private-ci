"""Pinned, create-only small-file deployment inside the unique timed C2 job."""
import base64
import hashlib
import json
import os
from pathlib import Path
import sys

BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
PYTHON = '/home/qian-qi/hepta-hcsn-trainer-20261108-s3-v1/dependency-recovery-v2/venv/bin/python'
EXPECTED = {
    'native-c2-execution-bootstrap-20261110-c385-v1.py': (8807, '0216804222e042df1b7d21dc989840bf5d56cf279e72ba79eedeefd022691dc6'),
    'c2-execution-decision-v1-20261110-c385.json': (7524, 'bee192193f0f12599f783f348b6dea8c10b2a18df359487c3cc0c0c44d071370'),
}
data = sys.stdin.buffer.read(1024 * 1024 + 1)
if len(data) > 1024 * 1024:
    raise ValueError('oversized deployment stdin')
payload = json.loads(data)
if set(payload) != set(EXPECTED):
    raise ValueError('deployment payload roster changed')
decoded = {}
for name, (size, digest) in EXPECTED.items():
    raw = base64.b64decode(payload[name], validate=True)
    if len(raw) != size or hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError('deployment bytes changed: ' + name)
    if (BASE / name).exists() or (BASE / name).is_symlink():
        raise ValueError('create-only destination already exists: ' + name)
    decoded[name] = raw
for name, raw in decoded.items():
    with (BASE / name).open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    if hashlib.sha256((BASE / name).read_bytes()).hexdigest() != EXPECTED[name][1]:
        raise ValueError('small-file readback mismatch: ' + name)
command = [PYTHON, '-B', str(BASE / 'native-c2-execution-bootstrap-20261110-c385-v1.py'),
    '--source-archive', str(BASE / 'c2-execution-candidate-v4-20261110-c385.zip'),
    '--program', str(BASE / 'c2-execution-source-v4-20261110-c385'),
    '--decision', str(BASE / 'c2-execution-decision-v1-20261110-c385.json'),
    '--controller-output', str(BASE / 'c2-native-execution-20261110-c385-v1'),
    '--bootstrap-output', str(BASE / 'c2-native-execution-bootstrap-20261110-c385-v1')]
print(json.dumps({'status': 'small_files_created_and_readback_verified',
    'files': {name: {'bytes': pair[0], 'sha256': pair[1]} for name, pair in EXPECTED.items()},
    'bootstrap_command': command}), flush=True)
os.execv(PYTHON, command)
