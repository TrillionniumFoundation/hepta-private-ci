"""One read-only observation of already launched C2; never load a model."""
from __future__ import annotations

import os
import time

STARTED = time.monotonic()

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import traceback
import zipfile

BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
RUN = BASE / 'c2-native-execution-20261110-c385-v1'
BOOT = BASE / 'c2-native-execution-bootstrap-20261110-c385-v1'
OUT = BASE / 'c2-start-observation-20261110-c385-v1'
NAMES = [f'hcsn-s{seed}-lr{lr}' for seed in (101, 211, 307) for lr in ('0.001', '0.003')]


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def capture(source, name, *, jsonl=False, limit=1024 * 1024):
    if not source.is_file() or source.is_symlink():
        return {'source': str(source), 'status': 'not_observed'}, None
    before = source.stat()
    if before.st_size > limit:
        return {'source': str(source), 'status': 'larger_than_declared_read_bound', 'size': before.st_size}, None
    data = source.read_bytes()
    after = source.stat()
    destination = OUT / 'raw' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as stream:
        stream.write(data)
    stable = (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino)
    receipt = {'source': str(source), 'copy': str(destination), **identity(data),
        'same_stat_before_after_read': stable, 'captured_utc': datetime.now(timezone.utc).isoformat(),
        'source_stat_before': {'size': before.st_size, 'mtime_ns': before.st_mtime_ns, 'inode': before.st_ino},
        'source_stat_after': {'size': after.st_size, 'mtime_ns': after.st_mtime_ns, 'inode': after.st_ino},
        'status': 'stable_observed_bytes' if stable else 'changed_during_read'}
    try:
        value = [json.loads(line) for line in data.splitlines()] if jsonl else json.loads(data)
    except Exception:
        receipt.update(status='not_parseable_at_observation', error=traceback.format_exc())
        return receipt, None
    return receipt, value if stable else None


def main():
    OUT.mkdir(exist_ok=False)
    (OUT / 'raw').mkdir()
    (OUT / 'raw' / 'observer.py').write_bytes(Path(__file__).read_bytes())
    report = {'schema': 'hcsn-c2-start-readonly-observation-v1',
        'observed_utc': datetime.now(timezone.utc).isoformat(), 'original_directories_written': False,
        'model_loads': 0, 'model_forward_backward_optimizer_steps': 0,
        'training_restart_or_retry': False, 'scientific_admission': 'HOLD', 'numerical_admission': 'HOLD',
        'live_observation_not_terminal_audit': True, 'source_program': identity(Path(__file__).read_bytes()),
        'reads': [], 'fits': []}
    for name in ('INTENT.json', 'READY.json'):
        item, _ = capture(BOOT / name, 'bootstrap/' + name)
        report['reads'].append(item)
    item, rows = capture(RUN / 'commands.jsonl', 'controller/commands.jsonl', jsonl=True)
    report['reads'].append(item)
    dispatches = {row['name']: row for row in rows or []}
    for name in NAMES:
        directory = RUN / 'fits' / name
        fit = {'name': name, 'dispatch': dispatches.get(name), 'observations': []}
        pid = (fit['dispatch'] or {}).get('pid')
        if isinstance(pid, int):
            proc = Path('/proc') / str(pid)
            fit['pid_exists_at_observation'] = proc.exists()
            try:
                fit['process_cmdline'] = (proc / 'cmdline').read_bytes().replace(b'\0', b' ').decode()
                fit['process_stat_original'] = (proc / 'stat').read_text()
            except FileNotFoundError:
                fit['process_disappeared_during_read'] = True
        item, witness = capture(directory / 'RESUME-START.json', name + '/RESUME-START.json')
        report['reads'].append(item)
        if witness:
            fit['resume_start'] = {key: witness.get(key) for key in ('actual_restored_state_equal_parent_last',
                'new_optimizer_steps_before_receipt', 'checkpoint', 'parent_last',
                'parent_complete_outer_wall_charged', 'discarded_parent_work', 'phase_process_wall_seconds')}
        item, events = capture(directory / 'events.jsonl', name + '/events.jsonl', jsonl=True)
        report['reads'].append(item)
        if events:
            completed = [event for event in events if event.get('kind') == 'optimizer_completed']
            fit['optimizer_completion_events_observed'] = len(completed)
            fit['last_optimizer_completion_event'] = completed[-1] if completed else None
            fit['last_complete_epoch_event'] = next((event for event in reversed(events) if event.get('kind') == 'epoch_completed'), None)
        item, supplement = capture(directory / 'posterior-windows/resume-start/RESULT.json',
            name + '/supplemental-resume-start-RESULT.json')
        report['reads'].append(item)
        if supplement:
            fit['supplemental_resume_window_status'] = supplement.get('status')
        optimization = directory / 'optimization-windows'
        for slot in sorted(optimization.glob('*')) if optimization.is_dir() else []:
            entry = {'slot': slot.name}
            for leaf in ('CAPTURE.json', 'STEP-COMPLETED.json'):
                item, value = capture(slot / leaf, name + '/optimization/' + slot.name + '/' + leaf)
                report['reads'].append(item)
                if value is not None:
                    if leaf == 'CAPTURE.json':
                        keys = ('status', 'scope', 'capture_grad_enabled', 'coverage_verified', 'trace', 'footer',
                            'logical_completed_updates_before_step', 'actual_logged_main_updates_before_step',
                            'expected_valid_sample_states', 'expected_padded_sample_states', 'microbatch_range',
                            'epoch', 'effective_batch_index', 'network_model_sha256')
                        entry['capture'] = {key: value.get(key) for key in keys}
                    else:
                        entry['step_completed'] = value
            fit['observations'].append(entry)
        report['fits'].append(fit)
    report['six_state_witnesses_observed'] = all(f.get('resume_start', {}).get('actual_restored_state_equal_parent_last') is True for f in report['fits'])
    report['six_actual_gradient_captures_observed'] = all(any(item.get('capture', {}).get('status') == 'captured_actual_gradient_microbatch' for item in f['observations']) for f in report['fits'])
    report['six_captured_optimizer_steps_observed'] = all(any(item.get('step_completed', {}).get('optimizer_step_completed') is True for item in f['observations']) for f in report['fits'])
    report.update(wall_seconds=time.monotonic() - STARTED, cpu_seconds=time.process_time(),
        peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024)
    write(OUT / 'SUMMARY.json', report)
    manifest = {str(path.relative_to(OUT)): identity(path.read_bytes()) for path in sorted((OUT / 'raw').rglob('*')) if path.is_file()}
    manifest['SUMMARY.json'] = identity((OUT / 'SUMMARY.json').read_bytes())
    write(OUT / 'MANIFEST.json', manifest)
    archive = OUT / 'hcsn-c2-start-observation-20261110-v1.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name in sorted(manifest):
            zipped.write(OUT / name, name)
        zipped.write(OUT / 'MANIFEST.json', 'MANIFEST.json')
    with zipfile.ZipFile(archive) as zipped:
        if zipped.testzip() is not None:
            raise ValueError('observation archive CRC failed')
        for name, expected in manifest.items():
            if identity(zipped.read(name)) != expected:
                raise ValueError('observation archive hash failed: ' + name)
    result = {'schema': 'hcsn-c2-start-observation-archive-v1', 'status': 'read_only_observation_completed',
        'summary': identity((OUT / 'SUMMARY.json').read_bytes()), 'archive': {'path': str(archive), **identity(archive.read_bytes())},
        'whole_script_wall_seconds': time.monotonic() - STARTED, 'whole_script_cpu_seconds': time.process_time(),
        'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        'six_state_witnesses_observed': report['six_state_witnesses_observed'],
        'six_actual_gradient_captures_observed': report['six_actual_gradient_captures_observed'],
        'six_captured_optimizer_steps_observed': report['six_captured_optimizer_steps_observed']}
    write(OUT / 'RESULT.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
