"""Freeze recovered preflight and initial real-C2 evidence as separate handoffs."""
from pathlib import Path
import hashlib
import json
import resource
import time
import zipfile

BASE = Path(__file__).resolve().parent


def ident(path):
    data = Path(path).read_bytes()
    return {'path': str(Path(path).resolve()), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def archive_control(root, inputs):
    files = {}
    for path in inputs:
        if path.is_dir():
            for item in sorted(path.rglob('*')):
                if item.is_file():
                    files[str(item.relative_to(BASE))] = item
        elif path.is_file():
            files[str(path.relative_to(BASE))] = path
        else:
            raise ValueError('missing original control receipt: ' + str(path))
    files[Path(__file__).name] = Path(__file__)
    manifest = {name: ident(path) for name, path in files.items()}
    archive = root / 'control-plane-originals-v1.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, path in sorted(files.items()):
            zipped.write(path, name)
        zipped.writestr('MEMBER-MANIFEST.json', json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        for name, item in manifest.items():
            raw = zipped.read(name)
            assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
    parts = []
    if archive.stat().st_size > 500000:
        raw = archive.read_bytes()
        for i, offset in enumerate(range(0, len(raw), 500000), 1):
            path = archive.with_name(archive.name + f'.part-{i:02d}')
            with path.open('xb') as stream:
                stream.write(raw[offset:offset + 500000])
            parts.append({'offset': offset, **ident(path)})
    metadata = {'schema': 'original-control-responses-compressed-v1', 'archive': ident(archive),
        'parts': parts, 'members': len(files) + 1, 'all_member_sha_and_crc_verified': True,
        'scope': 'Raw available tool response objects, including original Base64 content, retained inside ZIP. No raw Base64 JSON needs to be added individually to the evidence tree.',
        'reconstruction': 'If parts are listed, concatenate them in offset order; do not recompress.'}
    write(root / 'CONTROL-PLANE-ARCHIVE.json', metadata)
    return [Path(item['path']) for item in parts] if parts else [archive]


def main():
    started, cpu_started = time.monotonic(), time.process_time()
    pre = BASE / 'c2-native-preflight-recovered-v1'
    original = json.loads((pre / 'RESULT.json').read_bytes())
    assert original['status'] == 'passed_native_preflight_only' and original['source_unchanged']
    assert len(original['attempts']) == 10 and all(item['returncode'] == 0 for item in original['attempts'])
    pre_inputs = [BASE / 'c2-native-preflight-preparation-v1', pre / 'control-plane-raw',
        pre / 'READBACK.json', pre / 'PROCESS-TERMINAL.json', pre / 'DUPLICATE-READ-OBSERVATION.json',
        BASE / 'native_c2_preflight_v1.py', BASE / 'archive_c2_native_preflight_v1.py',
        BASE / 'assemble_c2_preflight_archive_v1.py']
    pre_inputs.extend(sorted((pre / 'zip-chunks').glob('*.json')))
    pre_control = archive_control(pre, pre_inputs)
    pre_handoff = {
        'schema': 'c2-v3-native-preflight-handoff-v1', 'status': original['status'],
        'source_version': 'v3', 'native_software_tests_passed': 53, 'actual_parent_bind_only_checks_passed': 6,
        'production_forward_backward_optimizer_steps': 0,
        'model_and_optimizer_states_constructed_and_loaded_for_validation': True,
        'v4_native_full_test_claim': False,
        'original_result': ident(pre / 'RESULT.json'),
        'original_archive': ident(pre / 'hcsn-c2-native-preflight-20261110-v1.zip'),
        'gnu_outer_full_wall_seconds_rounded': 58.69,
        'gnu_outer_user_seconds_rounded': 51.23, 'gnu_outer_system_seconds_rounded': 5.94,
        'gnu_outer_peak_rss_bytes': 909975552,
        'script_wall_prefix_seconds': original['whole_process_wall_seconds'],
        'script_controller_cpu_prefix_seconds': original['controller_full_cpu_seconds'],
        'exact_child_wait4_cpu_sum_seconds': original['children_cpu_seconds'],
        'native_archive_gnu_full_wall_seconds_rounded': 0.35,
        'native_archive_gnu_user_system_seconds_rounded': [0.33, 0.01],
        'native_archive_peak_rss_bytes': 19668992,
        'cost_overlap_rule': 'GNU total already contains child/controller work. Do not add those overlapping views. Archive work is a separate real process. RPC transfer wall is separately retained, including failures/reconciliation and duplicate read observations.',
        'source_transport_initial_timeout_retained': True,
        'byte_read_recovery_did_not_restart_native_jobs': True,
        'numerical_admission': 'HOLD', 'scientific_admission': 'HOLD',
        'scope': 'V1-V3 failures and earlier cloud attempts remain separate original evidence. V3 validation does not claim production C2 execution.'}
    write(pre / 'HANDOFF.json', pre_handoff)
    pre_copy = [pre / 'hcsn-c2-native-preflight-20261110-v1.zip.part-01', pre / 'hcsn-c2-native-preflight-20261110-v1.zip.part-02',
        pre / 'ORIGINAL-ZIP-PARTS.json', pre / 'RECOVERY-RECEIPT.json', pre / 'RESULT.json', pre / 'GNU-TIME.txt',
        pre / 'ARCHIVE-GNU-TIME.txt', pre / 'HANDOFF.json', pre / 'CONTROL-PLANE-ARCHIVE.json', *pre_control]

    start = BASE / 'c2-start-observation-recovered-v1'
    summary = json.loads((start / 'payload/SUMMARY.json').read_bytes())
    assert summary['six_state_witnesses_observed'] and summary['six_actual_gradient_captures_observed'] and summary['six_captured_optimizer_steps_observed']
    start_inputs = [BASE / 'c2-native-execution-preparation-v1', BASE / 'c2-start-observation-preparation-v1',
        start / 'control-plane-raw', BASE / 'native_c2_execution_bootstrap_v1.py', BASE / 'native_c2_stdin_deploy_v1.py',
        BASE / 'native_c2_start_observer_v1.py']
    start_inputs.extend(sorted(start.glob('archive-*.json')))
    start_inputs.append(start / 'GNU-TIME.json')
    start_control = archive_control(start, start_inputs)
    handoff = {
        'schema': 'c2-v4-authorized-launch-and-first-step-handoff-v1',
        'source_version': 'v4', 'source_manifest_sha256': '322eb8f76cce589ba44ed66eff822f7b497e6507106a1ad56a65bdc8c83f7f57',
        'source_capsule_sha256': '95d53c9a8fd7b6d0d60388b29d58519160c1d04357069bd805e5f4bfa2c91079',
        'decision': ident(BASE / 'c2-execution-decision-v1/DECISION.json'),
        'actual_job_id': '1a1c74f3308-be2a-75', 'stable_key': 'hcsn-c2-native-execution-c385-v1',
        'created_utc': '2026-11-10T21:13:38.824Z',
        'first_dispatch_utc': '2026-11-10T21:13:44.057721+00:00',
        'last_dispatch_utc': '2026-11-10T21:13:44.061997+00:00',
        'actual_continuations_started': 6, 'fresh_independent_fits_started': 0,
        'cumulative_active_wall_cap_per_fit': 43200, 'max_total_epochs': 200,
        'original_partial_work_refund_seconds': 0,
        'first_observation_original_archive': ident(start / 'hcsn-c2-start-observation-20261110-v1.zip'),
        'first_observation_summary': ident(start / 'payload/SUMMARY.json'),
        'six_complete_state_witnesses': True, 'six_actual_gradient_microbatch_captures': True,
        'six_corresponding_optimizer_steps_completed': True,
        'total_first_capture_valid_sample_states': sum(f['observations'][0]['capture']['expected_valid_sample_states'] for f in summary['fits']),
        'total_first_capture_time_rows': sum(f['observations'][0]['capture']['coverage_verified']['retained_time_rows'] for f in summary['fits']),
        'padding_exclusion_verified_in_observed_capture_receipts': True,
        'observer_gnu_full_wall_seconds_rounded': 0.26,
        'observer_gnu_user_system_seconds_rounded': [0.22, 0.04],
        'observer_gnu_peak_rss_bytes': 19296256,
        'observer_model_loads_forward_backward_optimizer_steps': 0,
        'observation_scope': 'Existing C2 work observed read-only. Six optimizer completion witnesses refer to actual production training; the observer performs none.',
        'cost_overlap_rule': 'Observer GNU total contains its deploy/import/archive work. Do not add script prefixes. Actual C2 global GNU and per-child wait4 totals remain pending until terminal, never estimated as complete.',
        'v3_native_vs_v4_scope': 'V3 received 53 native software tests and six bind-only validations. Reporting-only v4 received five cloud targeted tests plus independent static review, then this separately authorized actual continuation.',
        'training_terminal_status': 'pending_at_observation', 'training_adequacy': 'not_yet_granted',
        'whole_training_numerical_admission': 'HOLD', 'scientific_admission': 'HOLD'}
    write(start / 'HANDOFF.json', handoff)
    start_copy = [start / 'hcsn-c2-start-observation-20261110-v1.zip', start / 'payload/SUMMARY.json',
        start / 'RECOVERY-RECEIPT.json', start / 'GNU-TIME.txt', start / 'HANDOFF.json', start / 'CONTROL-PLANE-ARCHIVE.json',
        *start_control, BASE / 'c2-native-execution-preparation-v1/LAUNCH-RESPONSE.json',
        BASE / 'c2-native-execution-preparation-v1/LAUNCH-INTENT.json',
        BASE / 'c2-native-execution-preparation-v1/FIRST-COMMANDS.jsonl']
    packaging = {'schema': 'local-two-handoff-packaging-cost-v1', 'wall_seconds': time.monotonic() - started,
        'cpu_seconds': time.process_time() - cpu_started,
        'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        'scope': 'Single local packaging process shared by both handoffs. Charge once, not once per package; no model execution.'}
    write(start / 'PACKAGE-RECEIPT.json', packaging)
    start_copy.append(start / 'PACKAGE-RECEIPT.json')
    for root, files in ((pre, pre_copy), (start, start_copy)):
        assert all(path.stat().st_size <= 500000 for path in files)
        write(root / 'COPY_LIST.json', {'schema': 'original-byte-copy-list-v1', 'files': [ident(path) for path in files]})
        print(json.dumps({'copy_list': ident(root / 'COPY_LIST.json'), 'files': len(files)}))


if __name__ == '__main__':
    main()
