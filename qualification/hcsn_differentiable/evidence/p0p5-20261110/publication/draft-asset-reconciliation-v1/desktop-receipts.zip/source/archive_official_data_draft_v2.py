"""One bounded official-data attempt after the separately retained curl TLS failure.

No release publication, ref mutation, overwrite, deletion, or upload retry.
Run on the configured native desktop; authentication remains inside existing gh.
"""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import resource
import shutil
import subprocess
import sys
import time
import traceback
import zipfile


BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
OUT = BASE / 'official-data-draft-v2'
REPO = 'TrillionniumFoundation/hepta-private-ci'
RELEASE = 440410488
TAG = 'hcsn-research-20261110-c385'
KEY = 'hcsn-official-data-draft-c385-v2'
PRIOR_ATTEMPT = BASE / 'draft-three-assets-reconcile-v1/receipt.json'
OFFICIAL_URL = 'https://archive.ics.uci.edu/static/public/196/localization%2Bdata%2Bfor%2Bperson%2Bactivity.zip'
TARGETS = [
    {'name': 'official-localization-cloud.zip', 'asset_id': None,
     'bytes': 6290730, 'sha256': '6660124b4d1fd98963c56a6804bbb0ca0c5ee12edc9b772c8a867148af20d0da',
     'upload_if_missing': True},
]



def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def identity(path):
    path = Path(path)
    return {'bytes': path.stat().st_size, 'sha256': digest(path)}


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def save(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def redact(text):
    def clean(match):
        url = match.group(0)
        return url.split('?', 1)[0] + '?[query-redacted]' if '?' in url else url
    text = re.sub(r'https?://[^\s<>\"\']+', clean, text)
    return re.sub(r'(?i)(authorization\s*[:=]\s*|token\s*[:=]\s*)[^\s]+',
                  r'\1[redacted]', text)


def validate_zip(path, expected):
    observed = identity(path)
    need(observed == {'bytes': expected['bytes'], 'sha256': expected['sha256']},
         'Full-file size/SHA256 mismatch: ' + expected['name'])
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        need(len(names) == len(set(names)), 'Duplicate ZIP members')
        for name in names:
            need(not name.startswith('/') and '..' not in PurePosixPath(name).parts
                 and '\\' not in name, 'Unsafe ZIP member')
        need(archive.testzip() is None, 'ZIP CRC mismatch')
    return {**observed, 'zip_crc_passed': True, 'zip_members': len(names)}


def main():
    OUT.mkdir(exist_ok=False)
    started = time.perf_counter()
    started_children = resource.getrusage(resource.RUSAGE_CHILDREN)
    commands = []
    report = {'schema': 'hcsn-official-data-draft-attempt-v2',
              'status': 'started', 'repository': REPO, 'release_id': RELEASE,
              'tag': TAG, 'idempotency_key': KEY, 'started_utc': utc(),
              'script': identity(__file__), 'assets': [], 'commands': commands,
              'publish_requested': False, 'overwrite_requested': False,
              'energy_joules': None, 'currency_cost': None,
              'prior_main_partial_readback': 'Preserved by owner; never accessed or overwritten here.'}
    gh = shutil.which('gh')
    curl = shutil.which('curl')
    immutable_release = {}

    def run(label, argv, timeout, binary_destination=None):
        before_cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
        tick = time.perf_counter()
        output = binary_destination or (OUT / (label + '.stdout'))
        record = {'label': label, 'argv': argv, 'started_utc': utc(),
                  'timeout_seconds': timeout, 'stdout_file': str(output),
                  'status': 'launching'}
        commands.append(record)
        stderr = b''
        try:
            with output.open('xb') as stream:
                process = subprocess.Popen(argv, stdout=stream, stderr=subprocess.PIPE,
                                           env={**os.environ, 'GH_PROMPT_DISABLED': '1',
                                                'GH_PAGER': 'cat', 'PAGER': 'cat'})
                record['pid'] = process.pid
                record['status'] = 'running'
                try:
                    _, stderr = process.communicate(timeout=timeout)
                except subprocess.TimeoutExpired:
                    process.kill()
                    _, stderr = process.communicate()
                    record['status'] = 'timeout_outcome_unknown' if argv[1:3] == ['release', 'upload'] else 'timeout'
                    record['returncode'] = process.returncode
                    raise RuntimeError(label + ' exceeded bounded timeout; no blind retry')
                record['returncode'] = process.returncode
                record['status'] = 'completed' if process.returncode == 0 else 'failed'
                need(process.returncode == 0, label + ' failed; no blind retry')
        except Exception as error:
            if record['status'] == 'launching':
                record['status'] = 'launch_failed'
            record['error'] = redact(str(error))
            raise
        finally:
            after_cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
            record['whole_subprocess_wall_seconds'] = time.perf_counter() - tick
            record['child_cpu_seconds'] = (after_cpu.ru_utime + after_cpu.ru_stime -
                                           before_cpu.ru_utime - before_cpu.ru_stime)
            record['completed_utc'] = utc()
            record['raw_stderr_sha256'] = hashlib.sha256(stderr).hexdigest()
            record['raw_stderr_bytes'] = len(stderr)
            safe = redact(stderr.decode('utf-8', errors='replace')).encode()
            log = OUT / (label + '.stderr.redacted')
            log.write_bytes(safe)
            record['retained_stderr'] = identity(log)
            record['stderr_redacted'] = safe != stderr
            if output.is_file():
                record['retained_stdout'] = identity(output)
            save(label + '.process.json', record)
        return output

    def get_release(label):
        path = run(label, [gh, 'api', f'repos/{REPO}/releases/{RELEASE}'], 120)
        value = json.loads(path.read_text())
        need(value['id'] == RELEASE and value['draft'] is True and value['tag_name'] == TAG,
             'Authorized unpublished draft identity changed')
        selected = {k: value[k] for k in ('id', 'draft', 'prerelease', 'tag_name', 'target_commitish')}
        if immutable_release:
            need(selected == immutable_release, 'Draft metadata changed during reconciliation')
        else:
            immutable_release.update(selected)
        return value

    def anon(label, url):
        # curl configuration files are disabled and no authorization header is supplied.
        path = run(label, [curl, '--disable', '--silent', '--show-error', '--location',
                          '--connect-timeout', '20', '--max-time', '60', '--output', '/dev/null',
                          '--write-out', '%{http_code}', url], 70)
        status = path.read_text().strip()
        need(status == '404', 'Anonymous draft isolation was not established')
        return {'url': url, 'http_status': status, 'authorization_header_sent': False}

    def list_assets(label):
        path = run(label, [gh, 'api',
                          f'repos/{REPO}/releases/{RELEASE}/assets?per_page=100'], 120)
        assets = json.loads(path.read_text())
        need(isinstance(assets, list) and len(assets) < 100,
             'Complete one-page asset listing is required before declaring absence')
        return assets

    try:
        need(gh is not None and curl is not None, 'Existing gh/curl executables are required')
        prior = PRIOR_ATTEMPT.read_bytes()
        (OUT / 'prior-attempt-receipt.json').write_bytes(prior)
        parsed_prior = json.loads(prior)
        report['prior_attempt_receipt'] = {'original_path': str(PRIOR_ATTEMPT),
                                            **identity(PRIOR_ATTEMPT),
                                            'status': parsed_prior.get('status')}
        # Capture intent before the first external API call; it contains no credentials.
        save('intent.json', {'idempotency_key': KEY, 'script': identity(__file__),
                            'targets': TARGETS, 'release_id': RELEASE, 'tag': TAG,
                            'allowed_mutation': 'Upload official data once only if fresh metadata says absent.',
                            'forbidden_mutations': ['Publish release', 'Replace existing asset', 'Move refs',
                                                    'Merge PR', 'Delete asset', 'Retry uncertain upload']})
        get_release('release-before')
        for index, target in enumerate(TARGETS):
            prefix = f'asset-{index}'
            row = {'expected': target, 'status': 'started', 'upload_attempted': False}
            report['assets'].append(row)
            try:
                current = get_release(prefix + '-fresh-release')
                # Existing asset IDs are authoritative; validate the returned name as well.
                if target['asset_id'] is not None:
                    matches = [a for a in current['assets'] if a['id'] == target['asset_id']]
                else:
                    matches = [a for a in list_assets(prefix + '-fresh-assets')
                               if a['name'] == target['name']]
                need(len(matches) <= 1, 'Duplicate target asset identity')
                if not matches:
                    need(target['upload_if_missing'], 'Pre-existing asset missing; upload is unauthorized')
                    source = OUT / target['name']
                    downloader = (
                        "import sys, urllib.request, hashlib, json; "
                        "request = urllib.request.Request(sys.argv[1], "
                        "headers={'User-Agent':'HCSN-evidence-archive/1.0'}); "
                        "response = urllib.request.urlopen(request, timeout=120); "
                        "payload = response.read(6290731); "
                        "sys.stderr.write(json.dumps({'http_status': response.status, "
                        "'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest(), "
                        "'tls_certificate_verification': 'Python default enabled'}) + '\\n'); "
                        "sys.stdout.buffer.write(payload)"
                    )
                    run(prefix + '-official-source-download',
                        [sys.executable, '-B', '-c', downloader, OFFICIAL_URL],
                        310, binary_destination=source)
                    row['official_download'] = {'url': OFFICIAL_URL, **validate_zip(source, target)}
                    get_release(prefix + '-pre-upload-release')
                    matches = [a for a in list_assets(prefix + '-pre-upload-assets')
                               if a['name'] == target['name']]
                    need(len(matches) <= 1, 'Duplicate asset name before upload')
                    if not matches:
                        save(prefix + '-upload-intent.json',
                             {'source': str(source), **identity(source), 'retry_permitted': False})
                        row['upload_attempted'] = True
                        run(prefix + '-upload', [gh, 'release', 'upload', TAG,
                                                str(source), '--repo', REPO], 600)
                        after = get_release(prefix + '-after-upload-release')
                        matches = [a for a in after['assets'] if a['name'] == target['name']]
                need(len(matches) == 1, 'Target asset was not uniquely identified')
                asset = matches[0]
                need(asset['name'] == target['name'], 'Asset name differs from frozen intent')
                need(asset['size'] == target['bytes'], 'Server size differs')
                server_digest = asset.get('digest')
                need(server_digest in (None, 'sha256:' + target['sha256']), 'Server digest differs')
                need(asset['url'] == f'https://api.github.com/repos/{REPO}/releases/assets/{asset["id"]}',
                     'Unexpected asset API endpoint')
                browser_url = asset['browser_download_url']
                need(browser_url.startswith(f'https://github.com/{REPO}/releases/download/')
                     and '?' not in browser_url and '#' not in browser_url,
                     'Unexpected public asset URL')
                row.update(asset_id=asset['id'], server_digest=server_digest,
                           disposition='uploaded_once' if row['upload_attempted'] else 'preexisting_reconciled')
                readback = OUT / (prefix + '-authenticated-readback.zip')
                run(prefix + '-authenticated-readback',
                    [gh, 'api', '-H', 'Accept: application/octet-stream',
                     f'repos/{REPO}/releases/assets/{asset["id"]}'],
                    600, binary_destination=readback)
                row['authenticated_readback'] = {'path': str(readback), **validate_zip(readback, target)}
                row['anonymous_probes'] = [anon(prefix + '-anonymous-api', asset['url']),
                                            anon(prefix + '-anonymous-browser', browser_url)]
                row['status'] = 'full_bytes_crc_and_anonymous_isolation_verified'
                save(prefix + '-verified.json', row)
            except Exception:
                row['status'] = 'failed_or_unknown_no_retry'
                row['error'] = redact(traceback.format_exc())
                save(prefix + '-failed.json', row)
            print(json.dumps({'asset': target['name'], 'status': row['status'],
                              'upload_attempted': row['upload_attempted']}), flush=True)
        report['draft_after'] = get_release('release-final')['draft']
        report['anonymous_release_probe'] = anon('anonymous-release',
            f'https://api.github.com/repos/{REPO}/releases/{RELEASE}')
        report['status'] = ('all_targets_verified' if all(
            r['status'] == 'full_bytes_crc_and_anonymous_isolation_verified' for r in report['assets'])
                            else 'completed_with_failed_or_unknown_assets')
    except Exception:
        report['status'] = 'failed_or_unknown_no_retry'
        report['error'] = redact(traceback.format_exc())
    finally:
        after_children = resource.getrusage(resource.RUSAGE_CHILDREN)
        report['driver_wall_seconds_after_imports'] = time.perf_counter() - started
        report['driver_process_cpu_seconds_since_process_start'] = time.process_time()
        report['waited_children_cpu_seconds'] = (after_children.ru_utime + after_children.ru_stime -
                                                 started_children.ru_utime - started_children.ru_stime)
        report['cost_scope'] = 'Separate reconciliation attempt; no addition of overlapping command wall to driver wall; prior failed attempts excluded and retained separately.'
        report['completed_utc'] = utc()
        report['script_unchanged'] = report['script'] == identity(__file__)
        report['scientific_credit'] = False
        save('receipt.json', report)
        members = {str(p.relative_to(OUT)): identity(p) for p in OUT.rglob('*') if p.is_file()}
        save('MANIFEST.json', {'schema': 'hcsn-draft-reconciliation-files-v1', 'files': members})
        print(json.dumps({'status': report['status'], 'receipt': str(OUT / 'receipt.json'),
                          'verified_assets': sum(r['status'] == 'full_bytes_crc_and_anonymous_isolation_verified'
                                                 for r in report['assets']),
                          'driver_wall_seconds_after_imports': report['driver_wall_seconds_after_imports']}), flush=True)
    return 0 if report['status'] == 'all_targets_verified' else 2


if __name__ == '__main__':
    sys.exit(main())
