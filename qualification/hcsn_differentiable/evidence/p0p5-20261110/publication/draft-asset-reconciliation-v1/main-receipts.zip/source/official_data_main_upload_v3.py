"""Use the already verified official file for one missing draft upload.

Full authenticated readback is a separate desktop phase. This program never
downloads the two existing research assets, publishes a release or replaces assets.
"""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import resource
import subprocess
import time
import traceback
import zipfile


ROOT = Path('/Users/qianqi/hepta-hcsn-p0p5-20261110-c385/recovery')
OUT = ROOT / 'official-data-draft-v3-main'
GH = '/opt/homebrew/bin/gh'
REPO = 'TrillionniumFoundation/hepta-private-ci'
RID = 440410488
TAG = 'hcsn-research-20261110-c385'
NAME = 'official-localization-cloud.zip'
EXPECTED = {'bytes': 6290730, 'sha256': '6660124b4d1fd98963c56a6804bbb0ca0c5ee12edc9b772c8a867148af20d0da'}
KEY = 'hcsn-official-data-main-upload-c385-v3'


def identity(path):
    data = Path(path).read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def safe(text):
    text = re.sub(r'(?im)(authorization\s*[:=]\s*).*$', r'\1[redacted]', text)
    return re.sub(r'(https?://[^\s?]+)\?[^\s]+', r'\1?[query-redacted]', text)


def main():
    import os

    OUT.mkdir(exist_ok=False)
    tick = time.perf_counter()
    cpu0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    records = []
    report = {'schema': 'hcsn-official-data-main-upload-v3', 'repository': REPO,
              'release_id': RID, 'tag': TAG, 'idempotency_key': KEY,
              'status': 'started', 'commands': records, 'publish_requested': False,
              'overwrite_requested': False, 'upload_attempted': False,
              'full_authenticated_readback': 'Not performed here; assigned to desktop next.',
              'started_utc': datetime.now(timezone.utc).isoformat(),
              'script': identity(__file__), 'energy_joules': None, 'currency_cost': None}

    def run(label, argv, timeout=120):
        start = time.perf_counter()
        before = resource.getrusage(resource.RUSAGE_CHILDREN)
        row = {'label': label, 'argv': argv, 'timeout_seconds': timeout, 'status': 'launching'}
        records.append(row)
        stdout = b''
        stderr = b''
        try:
            process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       env={**os.environ, 'GH_DEBUG': '', 'GH_PROMPT_DISABLED': '1',
                                            'GH_PAGER': 'cat', 'PAGER': 'cat'})
            row['pid'] = process.pid
            try:
                stdout, stderr = process.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
                row['returncode'] = process.returncode
                row['status'] = 'timeout_outcome_unknown' if label == 'upload-once' else 'timeout'
                raise RuntimeError(label + ' timed out; no upload retry')
            row['returncode'] = process.returncode
            row['status'] = 'completed' if process.returncode == 0 else 'failed'
            need(process.returncode == 0, label + ' failed')
            return json.loads(stdout) if label != 'upload-once' else None
        finally:
            after = resource.getrusage(resource.RUSAGE_CHILDREN)
            row['whole_subprocess_wall_seconds'] = time.perf_counter() - start
            row['child_cpu_seconds'] = after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime
            row['raw_stderr_sha256'] = hashlib.sha256(stderr).hexdigest()
            row['raw_stderr_bytes'] = len(stderr)
            (OUT / (label + '.stdout')).write_bytes(stdout)
            retained = safe(stderr.decode('utf-8', errors='replace')).encode()
            (OUT / (label + '.stderr.redacted')).write_bytes(retained)
            row['stderr_redacted'] = retained != stderr
            row['stdout'] = identity(OUT / (label + '.stdout'))
            row['stderr'] = identity(OUT / (label + '.stderr.redacted'))
            save(label + '.process.json', row)

    def release(label):
        value = run(label, [GH, 'api', f'repos/{REPO}/releases/{RID}'])
        need(value['id'] == RID and value['draft'] is True and value['tag_name'] == TAG,
             'Authorized draft identity changed')
        return value

    def assets(label):
        value = run(label, [GH, 'api', f'repos/{REPO}/releases/{RID}/assets?per_page=100'])
        need(isinstance(value, list) and len(value) < 100, 'Complete asset list required')
        rows = [a for a in value if a['name'] == NAME]
        need(len(rows) <= 1, 'Duplicate official asset name')
        return rows

    try:
        source = ROOT / NAME
        need(identity(source) == EXPECTED, 'Original official source bytes differ')
        with zipfile.ZipFile(source) as archive:
            need(archive.testzip() is None, 'Original official source ZIP CRC failed')
            report['source_zip_members'] = len(archive.namelist())
        report['source'] = {'path': str(source), **identity(source),
                            'scope': 'Existing official file; no new successful UCI download claimed.'}
        prior = ROOT / 'cloud-p2-draft-upload-v1/receipt.json'
        (OUT / 'prior-main-uploader-receipt.json').write_bytes(prior.read_bytes())
        report['prior_main_uploader_receipt'] = {'path': str(prior), **identity(prior)}
        save('intent.json', {'release_id': RID, 'tag': TAG, 'idempotency_key': KEY,
                            'script': report['script'], 'source': report['source'],
                            'allowed_action': 'Upload exact official file once only if absent; no overwrite or publication.',
                            'desktop_failures_retained_separately': [
                                'ca219a8cc0fb92beccc5bc29db3da7ccb9de7754106de25d65884e17f7089c0c',
                                'b66a43d9fb3aff563172056fea3267c260cc3c9c6c4cceb98d6812376382a261']})
        before = release('release-before')
        matches = assets('assets-before')
        if not matches:
            release('release-immediately-before-upload')
            matches = assets('assets-immediately-before-upload')
        if not matches:
            report['upload_attempted'] = True
            try:
                run('upload-once', [GH, 'release', 'upload', TAG, str(source), '--repo', REPO], 600)
            except Exception:
                report['upload_command_error'] = safe(traceback.format_exc())
            # Reconcile the same single invocation even after timeout/failure; never re-upload.
            matches = assets('assets-after-single-upload-invocation')
        need(len(matches) == 1, 'Official asset still absent after bounded attempt')
        asset = matches[0]
        need(asset['size'] == EXPECTED['bytes'], 'Server asset size differs')
        need(asset.get('digest') in (None, 'sha256:' + EXPECTED['sha256']), 'Server asset digest differs')
        after = release('release-after')
        for key in ('id', 'tag_name', 'draft', 'prerelease', 'target_commitish'):
            need(before[key] == after[key], 'Release metadata changed: ' + key)
        report['asset'] = {'name': NAME, 'asset_id': asset['id'], 'bytes': asset['size'],
                           'server_digest': asset.get('digest'),
                           'expected_sha256': EXPECTED['sha256'], 'api_url': asset['url'],
                           'browser_download_url': asset['browser_download_url']}
        report['draft_after'] = True
        report['status'] = 'asset_present_metadata_verified_pending_desktop_full_readback'
    except Exception:
        report['status'] = 'failed_or_unknown_no_retry'
        report['error'] = safe(traceback.format_exc())
    finally:
        cpu1 = resource.getrusage(resource.RUSAGE_CHILDREN)
        report['driver_wall_seconds_after_imports'] = time.perf_counter() - tick
        report['driver_process_cpu_seconds_since_process_start'] = time.process_time()
        report['waited_children_cpu_seconds'] = cpu1.ru_utime + cpu1.ru_stime - cpu0.ru_utime - cpu0.ru_stime
        report['completed_utc'] = datetime.now(timezone.utc).isoformat()
        report['script_unchanged'] = report['script'] == identity(__file__)
        report['cost_scope'] = 'This main upload phase only; prior failed reads/downloads/transfer and future desktop readback are separate.'
        save('receipt.json', report)
        save('MANIFEST.json', {'files': {p.name: identity(p) for p in OUT.iterdir() if p.is_file()}})
        print(json.dumps({'status': report['status'], 'upload_attempted': report['upload_attempted'],
                          'asset': report.get('asset'), 'receipt': str(OUT / 'receipt.json'),
                          'driver_wall_seconds_after_imports': report['driver_wall_seconds_after_imports']}), flush=True)
    return 0 if report['status'] == 'asset_present_metadata_verified_pending_desktop_full_readback' else 2


if __name__ == '__main__':
    raise SystemExit(main())
