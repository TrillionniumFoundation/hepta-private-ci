"""Archive completed reconciliation receipts; large payloads stay SHA-referenced."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import time
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': sha(data)}


def require(value, message):
    if not value:
        raise ValueError(message)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, action='append', required=True)
parser.add_argument('--source', type=Path, action='append', default=[])
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
start = time.perf_counter()
included, references, original_hashes = {}, [], {}
secret = re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|[?&](?:X-Amz-Signature|X-Goog-Signature|sig|token)=)', re.I)
for root in args.root:
    require((root / 'receipt.json').is_file(), 'Completed receipt missing: ' + str(root))
    for path in sorted(root.rglob('*')):
        if not path.is_file():
            continue
        require(not path.is_symlink(), 'Symlink is outside this capsule scope')
        observed = identity(path)
        original_hashes[str(path)] = observed
        if path.suffix == '.zip' or path.stat().st_size > 262144:
            references.append({'path': str(path), **observed,
                               'embedded': False, 'reason': 'Raw payload retained at original path; exact identity referenced.'})
            continue
        data = path.read_bytes()
        require(secret.search(data) is None, 'Potential credential-bearing log excluded pending review: ' + path.name)
        name = 'runs/' + root.name + '/' + path.relative_to(root).as_posix()
        require(name not in included, 'Duplicate archive member')
        included[name] = data
for path in args.source + [Path(__file__).resolve()]:
    require(path.is_file() and not path.is_symlink(), 'Source missing or symlink')
    data = path.read_bytes()
    original_hashes[str(path)] = {'bytes': len(data), 'sha256': sha(data)}
    included['source/' + path.name] = data
included['PAYLOAD_REFERENCES.json'] = (json.dumps({'payloads': references,
    'scope': 'Reference identities include failed partial/empty payloads and successful full readbacks; consult each original receipt for status.'},
    indent=2, sort_keys=True) + '\n').encode()
for path, expected in original_hashes.items():
    require(identity(Path(path)) == expected, 'Original file changed while packaging')
manifest = {'schema': 'hcsn-asset-reconciliation-receipts-capsule-v1',
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'scope': 'Original small receipts, API metadata, logs, and source bytes. Large raw readbacks/failed partials are referenced, not embedded.',
            'source_and_original_files_unchanged': True,
            'files': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in included.items()},
            'original_files': original_hashes}
included['CAPSULE_MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
with zipfile.ZipFile(args.output, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(included.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(args.output) as archive:
    require(archive.testzip() is None, 'Capsule CRC mismatch')
    require(len(archive.namelist()) == len(included), 'Capsule member count differs')
    for name, data in included.items():
        require(archive.read(name) == data, 'Archived bytes differ: ' + name)
receipt = {'path': str(args.output), **identity(args.output), 'members': len(included),
           'excluded_payloads': len(references), 'originals_unchanged': True,
           'archive_crc_and_all_included_bytes_verified': True,
           'wall_seconds_after_imports': time.perf_counter() - start,
           'process_cpu_seconds_since_process_start': time.process_time(),
           'scientific_credit': False}
with Path(str(args.output) + '.receipt.json').open('x') as stream:
    json.dump(receipt, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(receipt), flush=True)
