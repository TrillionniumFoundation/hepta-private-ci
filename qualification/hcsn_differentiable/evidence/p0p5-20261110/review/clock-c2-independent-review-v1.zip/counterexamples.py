"""Independent structural counterexamples; no forward/backward/optimizer steps.

These are manufactured inputs to the frozen C2 proposal guard. They are not
native training observations, qualified checkpoints, or authorization to resume.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import time

STARTED = time.monotonic()
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "c2-feasibility-v1/c2_boundary.py"
PINNED = "9b6bd43ebde5317d62c55fbc37b5fb2309f89178d195c529598529caf1e99f4f"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert digest(SOURCE) == PINNED
    spec = importlib.util.spec_from_file_location("frozen_c2_guard_review", SOURCE)
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    torch = guard.torch

    # Valid numeric scores with an earlier stop followed by an impossible reset.
    # The exact producer would have stopped at 30; the structural guard should
    # reject this internally inconsistent history independently of its last row.
    epochs = [
        {"kind": "epoch_completed", "epoch": i, "complete": True,
         "development": {"macro_f1_11_classes": 0.5 if i < 40 else 0.6}}
        for i in range(1, 41)
    ]
    plan = {"min_epochs": 30, "patience": 10, "plateau_delta": 0.002,
            "wall_seconds": 100.0, "rss_bytes": 1024}
    stopping = guard.plateau_state(epochs, plan["plateau_delta"])
    boundary = {"boundary_structurally_consistent": True, "retained_epochs": 40,
                "logical_epochs": epochs, "stopping": stopping,
                "work": {"complete_epochs_after_anchor": 0,
                         "total_logged_main_optimizer_completions": 40,
                         "completed_updates_after_anchor": 0}}
    report = {"status": "budget_exhausted", "error": "declared resource limit; not convergence",
              "source_unchanged": True, "common_weights_unchanged": True,
              "memorization": {"passed": True}, "wall_seconds": 101.0,
              "peak_rss_bytes": 512, "main_updates": 40,
              "epochs": [{k: v for k, v in row.items() if k != "kind"} for row in epochs]}
    outer = {"status": "failed", "returncode": 2, "fit_status": "budget_exhausted",
             "whole_process_wall_seconds": 102.0, "hard_wall_seconds": 130.0}
    terminal_result = guard.terminal_guard(outer=outer, report=report, plan=plan, boundary=boundary)
    assert terminal_result["structural_terminal_checks_passed"]
    assert terminal_result["execution_authorized"] is False

    # Complete one-batch metadata with negative first cumulative clock samples.
    rng = random.Random(101)
    order = [0]
    rng.shuffle(order)
    journal = [
        {"kind": "epoch_started", "epoch": 1, "episode_order": ["synthetic-1"]},
        {"kind": "update_started", "phase": "main", "episode_ids": ["synthetic-1"]},
        {"kind": "optimizer_started", "phase": "main"},
        {"kind": "optimizer_completed", "phase": "main", "number": 1,
         "events": 1, "loss": 1.0, "gradient_norm": 0.0, "micro_forward_calls": 1},
        {"kind": "epoch_completed", "epoch": 1, "complete": True, "events": 1,
         "process_wall_seconds": -0.5, "process_cpu_seconds": -0.5},
    ]
    clock_result = guard.journal_boundary(
        journal, {"seed": 101, "batch_size": 1, "micro_batch_size": 1},
        [{"id": "synthetic-1", "y": [0]}], 1, rng.getstate())
    assert clock_result["retained_main_updates"] == 1

    # Manufacturing an AdamW state does not execute an optimizer step. A
    # nonnegative second moment is an algebraic invariant, even before replay.
    def model_factory(seed):
        torch.manual_seed(seed)
        return torch.nn.Linear(1, 1, dtype=torch.float64)

    def optimizer_factory(model, lr, weight_decay):
        return torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay), None

    cfg = {"seed": 47}
    model = model_factory(**cfg)
    optimizer, _ = optimizer_factory(model, 0.001, 0.0)
    optimizer_state = optimizer.state_dict()
    ids = optimizer_state["param_groups"][0]["params"]
    for key, parameter in zip(ids, model.parameters()):
        optimizer_state["state"][key] = {
            "step": torch.tensor(1.0), "exp_avg": torch.zeros_like(parameter),
            "exp_avg_sq": -torch.ones_like(parameter),
        }
    initial = {"model_configuration": cfg, "model": copy.deepcopy(model.state_dict())}
    state = {"model_configuration": cfg, "model": copy.deepcopy(model.state_dict()),
             "epochs_completed": 1, "main_updates": 1, "optimizer": optimizer_state,
             "torch_rng": torch.get_rng_state(), "order_rng": random.Random(47).getstate()}
    guard.validate_checkpoint(state, cfg, 1, 1, initial, model_factory, optimizer_factory, 0.001)

    result = {
        "schema": "independent-c2-structural-counterexamples-v1",
        "source_sha256": PINNED, "source_unchanged": digest(SOURCE) == PINNED,
        "scope": "Manufactured metadata/tensors only; no production checkpoint read and no training execution.",
        "forward_calls": 0, "backward_calls": 0, "optimizer_steps_executed": 0,
        "native_admission_performed": False, "scientific_admission": "HOLD",
        "findings": [
            {"id": "C2-01", "expected_first_plateau_epoch": 30,
             "final_stopping_state": stopping, "terminal_guard_accepted": True,
             "execution_authorized": terminal_result["execution_authorized"],
             "fixture_scope": "terminal guard only; boundary truth manufactured, not an actual validated native checkpoint"},
            {"id": "C2-02", "accepted_first_wall_seconds": -0.5,
             "accepted_first_cpu_seconds": -0.5, "journal_guard_accepted": True},
            {"id": "C2-03", "manufactured_second_moment_all_values": -1.0,
             "checkpoint_guard_accepted": True, "fixture_model": "synthetic Linear(1,1), no forward or step"},
        ],
        "wall_sample_before_result_serialization_seconds": time.monotonic() - STARTED,
        "absolute_process_cpu_sample_before_result_serialization_seconds": time.process_time(),
    }
    assert result["source_unchanged"]
    output = Path(__file__).with_name("COUNTEREXAMPLES.json")
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"result": str(output), "sha256": digest(output),
                      "counterexamples": 3, "optimizer_steps_executed": 0}))


if __name__ == "__main__":
    main()
