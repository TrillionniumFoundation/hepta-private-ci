"""Bind the static review, retained owner receipts and independent counterexamples."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(path):
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}


def save(name, value):
    with (OUT / name).open("x") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n")


def verify_zip(path):
    with ZipFile(path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) and archive.testzip() is None
        for name in names:
            pure = PurePosixPath(name)
            assert not pure.is_absolute() and ".." not in pure.parts and "\\" not in name
    return {**identity(path), "members": len(names), "crc_unique_safe_paths": True}


def main():
    clock = ROOT / "hcsn-clock-fix"
    commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=clock, text=True).strip()
    assert commit == "7d7fa1dff8ea8259b1bae0a9e1889183325693bf"
    changed = subprocess.check_output(["git", "diff-tree", "--no-commit-id", "--name-only", "-r", "HEAD"], cwd=clock, text=True).splitlines()
    assert changed == ["proposals/localization-v3/continuation.py", "proposals/localization-v3/test_continuation.py"]
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=clock)
    diff = subprocess.check_output(["git", "show", "--format=fuller", "HEAD"], cwd=clock)
    with (OUT / "future-producer.patch").open("xb") as stream:
        stream.write(diff)
    validation = ROOT / "continuation-clock-fix-validation-v1"
    owner = json.loads((validation / "SUMMARY.json").read_bytes())
    green = json.loads((validation / "green.json").read_bytes())
    for name in changed:
        assert sha(clock / name) == green["source"][name]
    assert owner["total_continuation_tests"] == 12 and owner["green_all_tests_passed"]
    assert owner["red_old_source_expected_failure"] and not owner["native_training_executed"]
    clock_manifest = json.loads((validation / "MANIFEST.json").read_bytes())["files"]
    for name, record in clock_manifest.items():
        assert (validation / name).stat().st_size == record["bytes"] and sha(validation / name) == record["sha256"]

    program = ROOT / "baseline36-c1-reviewer-v2"
    manifest = json.loads((program / "MANIFEST.json").read_bytes())["files"]
    archive_path = ROOT / "baseline36-c1-independent-reviewer-program-v2.zip"
    assert sha(archive_path) == "6ede11014d33e219f6ebc109911ad50a8550bb585388b16b5c604a2d4cb54c51"
    with ZipFile(archive_path) as archive:
        assert set(archive.namelist()) == set(manifest) | {"MANIFEST.json"}
        for name, record in manifest.items():
            raw = archive.read(name)
            assert raw == (program / name).read_bytes()
            assert len(raw) == record["bytes"] and hashlib.sha256(raw).hexdigest() == record["sha256"]
    preparation = json.loads((program / "VALIDATION.json").read_bytes())
    assert preparation["passed"] and preparation["source_before"] == preparation["source_after"]
    for name, digest in preparation["source_after"].items():
        assert sha(program / name) == digest
    for event in preparation["executions"]:
        for suffix in ("stdout", "stderr"):
            assert sha(program / "validation" / (event["name"] + "." + suffix)) == event[suffix + "_sha256"]
    findings = json.loads((OUT / "COUNTEREXAMPLES.json").read_bytes())
    execution = json.loads((OUT / "COUNTEREXAMPLE-EXECUTION.json").read_bytes())
    assert findings["source_unchanged"] and execution["returncode"] == 0 and execution["source_unchanged"]
    sources = [clock / name for name in changed]
    sources += [program / name for name in ("clock_sampling.py", "subset_c1.py", "run_c1_clock_supplement.py", "run_subset_review.py", "subset_context.py", "test_clock_sampling.py")]
    sources += [ROOT / "c2-feasibility-v1" / name for name in ("c2_boundary.py", "test_c2_boundary.py", "FEASIBILITY.md", "PROPOSED-C2-PLAN.json", "validation-attempt2/RESULT.json")]
    result = {
        "schema": "independent-continuation-clock-and-C2-static-review-v1",
        "reviewed_input_identities": [identity(path) for path in sources],
        "future_producer": {"commit": commit, "static_review": "no_scope_blocker_found", "changed_files": changed,
                            "owner_validation": identity(validation / "SUMMARY.json"), "owner_manifest_members_checked": len(clock_manifest),
                            "owner_12_tests_rerun_by_this_reviewer": False, "historical_C1_source_replaced": False},
        "historical_clock_adapter": {"program": verify_zip(archive_path), "all_manifest_members_exact": len(manifest),
                                     "static_review": "no_new_blocker_found", "owner_preparation": identity(program / "VALIDATION.json"),
                                     "actual_native_supplement_verified_by_this_review": False,
                                     "preserves_raw_later_cumulative_and_prior_failed_review": True},
        "C2_proposal": {"program": verify_zip(ROOT / "hcsn-c2-feasibility-20261110-v1.zip"),
                        "static_review": "three_reproduced_structural_guard_gaps", "native_impact_observed": False,
                        "counterexamples": identity(OUT / "COUNTEREXAMPLES.json"), "complete_execution_cost": execution,
                        "requires_independent_versioned_fix_before_admission": True},
        "training_performed": False, "optimizer_steps_executed": 0, "production_checkpoint_forward_executed": False,
        "scientific_admission": "HOLD", "whole_training_numerical_qualification_granted": False,
        "overall_repository_CI_claim": False, "canonical_files_modified": False,
    }
    save("RESULT.json", result)
    files = {path.name: {"bytes": path.stat().st_size, "sha256": sha(path)} for path in OUT.iterdir() if path.is_file()}
    save("MANIFEST.json", {"schema": "independent-clock-C2-review-capsule-v1", "files": files})
    archive = ROOT / "clock-c2-independent-review-v1.zip"
    with ZipFile(archive, "x", ZIP_DEFLATED, compresslevel=9) as zipped:
        for path in sorted(OUT.iterdir()):
            if path.is_file():
                zipped.write(path, path.name)
    print(json.dumps({"archive": verify_zip(archive), "result": identity(OUT / "RESULT.json"),
                      "review": identity(OUT / "REVIEW.md"), "manifest": identity(OUT / "MANIFEST.json")}, indent=2))


if __name__ == "__main__":
    main()
