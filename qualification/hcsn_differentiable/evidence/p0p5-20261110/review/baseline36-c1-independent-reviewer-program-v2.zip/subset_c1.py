"""Actual C1 artifacts joined to independently audited original parents."""

import copy
import math

import torch

from subset_context import exact_tree_equal, frozen, inherited_source_equivalence, require
from subset_checkpoints import verify_optimizer, frozen_shared, saved_metrics, fresh_predictions
from audit_phase_chain import audit_phase_chain, check_first_continued_order, validate_parent_for_c1, validate_phase_roster
from clock_sampling import late_clock_view, verify_source_sampling_order


def check_continued_journal(events, child, parent, plan, training_events):
    """Run frozen journal invariants on an explicitly renumbered phase view.

    Clock aliases are exact *phase* clocks only for finite-value validation;
    they do not claim exact cumulative CPU. Phase-chain clocks are checked by
    the separate frozen audit_phase_chain helper.
    """
    require(all(event.get('phase') != 'diagnostic' and event['kind'] != 'memorization_evaluated' for event in events),
            'continuation replayed a diagnostic')
    offset, old_updates = len(parent['epochs']), parent['main_updates']

    def convert(row):
        value = copy.deepcopy(row)
        if 'epoch' in value:
            value['epoch'] -= offset
        if value.get('kind') == 'optimizer_completed':
            require(value.get('phase') == 'main', 'continued optimizer phase differs')
            value['number'] -= old_updates
        if value.get('kind') == 'epoch_completed' or ('development' in value and 'complete' in value):
            value['process_wall_seconds'] = value['phase_process_wall_seconds']
            value['process_cpu_seconds'] = value['phase_full_process_cpu_seconds']
        return value

    local_events = [convert(event) for event in events]
    local_report = {'status': child['status'], 'epochs': [convert(row) for row in child['epochs']],
                    'main_updates': child['main_updates'] - old_updates, 'diagnostic_updates': 0,
                    'main_micro_forward_attempts': sum(row['micro_forward_calls'] for row in events if row['kind'] == 'optimizer_completed'),
                    'diagnostic_micro_forward_attempts': 0}
    receipt, _ = frozen.check_journal(local_events, local_report, training_events, plan)
    receipt.update({'cumulative_main_updates': child['main_updates'],
                    'parent_main_updates': old_updates, 'new_epochs_start_at': offset + 1,
                    'clock_alias_scope': 'phase wall/full phase CPU only; no cumulative CPU imputation'})
    return receipt


def mechanical_roster(context, parents):
    eligible, excluded = [], []
    for name in context.baselines:
        item = parents[name]
        if item['report']['stop_reason'] == 'epoch_cap_not_convergence':
            validate_parent_for_c1(item['report'], item['outer'], item['plan'])
            eligible.append(name)
        else:
            excluded.append({'name': name, 'reason': item['report']['stop_reason']})
    declared = context.c1_controller['declared_continuation_names']
    validate_phase_roster(list(context.roster), eligible, list(context.c1_outer))
    require(sorted(eligible) == sorted(declared) == sorted(context.c1_outer), 'C1 omitted or added a mechanically eligible parent')
    require(sorted(excluded, key=lambda r: r['name']) == sorted(context.c1_controller['excluded'], key=lambda r: r['name']), 'C1 exclusion roster differs')
    return {'mechanically_eligible': sorted(eligible), 'excluded_original_baselines': excluded,
            'original_HCSN_fits_excluded': [name for name in context.roster if name.startswith('hcsn-')]}


def audit_child(context, name, parent_data):
    parent, parent_outer, plan = (parent_data[key] for key in ('report', 'outer', 'plan'))
    root = context.c1 / name
    outer = context.c1_outer[name]
    require(outer['status'] == 'completed' and outer['returncode'] == 0 and outer['process_started'], 'C1 process did not complete')
    require(outer['source_unchanged'] is True and outer['common_weights_unchanged'] is True,
            'outer C1 source/shared gate failed')
    parent_record = context.read(context.c1 / 'parent-records' / (name + '.json'), outer['parent_outer_record_sha256'])
    require(parent_record == parent_outer, 'retained parent outer record differs from original terminal journal')
    for stream in ('stdout', 'stderr'):
        context.bind(context.c1 / (name + '.' + stream), outer[stream + '_sha256'])
    child_plan = context.read(root / 'plan.json')
    child = context.read(root / 'result.json', outer['result_sha256'])
    require(child['parent_outer_record_sha256'] == outer['parent_outer_record_sha256'], 'child parent-outer hash differs')
    require(child['parent_report_sha256'] == outer['parent_result_sha256'] == parent_outer['result_sha256'], 'child parent result differs')
    for filename, field in [('plan.json', 'plan_sha256'), ('events.jsonl', 'events_sha256'),
                            ('best.pt', 'best_checkpoint_sha256'), ('last.pt', 'last_checkpoint_sha256')]:
        context.bind(root / filename, child[field])
    require(not (root / 'initial.pt').exists() and not (root / 'memorization.pt').exists(), 'C1 contains unexpected fresh initialization/diagnostic artifact')
    for path in root.iterdir():
        if path.is_file():
            context.bind(path)
    context.verify_sources(child)
    equivalence = inherited_source_equivalence(context, child, parent)
    events, partial = frozen.read_journal(root / 'events.jsonl')
    require(not partial, 'completed C1 journal has partial tail')
    journal_check = check_continued_journal(events, child, parent, plan, context.training_events)
    weighted_checks = context.weight_denominators(events)
    parent_last = parent_data['checkpoints']['last.pt']
    first_order = check_first_continued_order(parent_last, events, [row['id'] for row in context.train])
    best = context.checkpoint(root / 'best.pt', child['best_checkpoint_sha256'])
    last = context.checkpoint(root / 'last.pt', child['last_checkpoint_sha256'])
    updates_per_epoch = math.ceil(len(context.train) / plan['batch_size'])
    optimizer = {}
    for filename, checkpoint in [('best.pt', best), ('last.pt', last)]:
        frozen.validate_configuration(checkpoint['model_configuration'], plan)
        require(checkpoint['model_configuration'] == child['model_configuration'] == parent['model_configuration'], 'continued model configuration differs')
        epoch = child['best_epoch'] if filename == 'best.pt' else child['cumulative_epochs_completed']
        require(checkpoint['epochs_completed'] == epoch and checkpoint['main_updates'] == epoch * updates_per_epoch, 'C1 checkpoint counters differ')
        require(checkpoint['data_manifest_sha256'] == plan['manifest_sha256'], 'C1 checkpoint data differs')
        frozen_shared(parent_data['checkpoints']['initial.pt']['model'], checkpoint)
        optimizer[filename] = verify_optimizer(checkpoint, parent_data['optimizer_groups'], checkpoint['main_updates'])
        require(exact_tree_equal(checkpoint['optimizer']['param_groups'], parent_last['optimizer']['param_groups']), 'optimizer parameter groups changed across C1')
    order_epochs = context.check_order(events, parent_last['order_rng'], last['order_rng'])
    require(torch.equal(last['torch_rng'], parent_last['torch_rng']), 'draw-free continued cores changed Torch RNG endpoint')
    sampling_source = verify_source_sampling_order(context.c1_source / 'proposals/localization-v3/continuation.py')
    logical_child, sampling_receipt = late_clock_view(child, parent_outer, outer)
    logic = audit_phase_chain(parent, parent_outer, plan, logical_child, outer, child_plan, updates_per_epoch)
    require(child['training_adequacy_established'] == outer['adequate'], 'outer C1 adequacy differs from fit')
    require(outer['cumulative_epochs'] == child['cumulative_epochs_completed'] and outer['epochs_added'] == len(child['epochs']), 'outer cumulative epoch metadata differs')
    require(outer['phase_full_process_cpu_seconds'] == child['phase_full_process_cpu_seconds'], 'phase CPU outer/inner disagreement')
    phase_cpu = child['phase_full_process_cpu_seconds']
    require(math.isfinite(phase_cpu) and phase_cpu >= 0
            and phase_cpu >= max(row['phase_full_process_cpu_seconds'] for row in child['epochs']),
            'final reported phase CPU precedes an observed epoch or is invalid')
    require(outer['selected_development'] == child['selected_development'], 'outer selected metrics differ')
    stored, metrics = saved_metrics(context, root, child, best, parent['epochs'] + child['epochs'])
    fresh = fresh_predictions(context, 'C1-' + name, child['model_configuration'], best, stored)
    return {'name': name, 'audit_status': 'passed_completed_C1_chain_artifacts',
            'parent_report_sha256': parent_outer['result_sha256'], 'child_report_sha256': outer['result_sha256'],
            'parent_last_checkpoint_sha256': parent['last_checkpoint_sha256'],
            'parent_best_checkpoint_sha256': parent['best_checkpoint_sha256'],
            'child_best_checkpoint_sha256': child['best_checkpoint_sha256'],
            'child_last_checkpoint_sha256': child['last_checkpoint_sha256'],
            'source_equivalence': equivalence, 'journal': journal_check,
            'independent_ABC_class_weight_denominators_checked': weighted_checks,
            'first_continued_order': first_order,
            'all_continued_orders_and_final_order_rng_checked': order_epochs,
            'optimizer_checks': optimizer, 'parent_child_last_torch_rng_equal': True,
            'resume_start_state_directly_observed': False,
            'resume_evidence_scope': 'Parent checkpoint/plan/source binding, complete sample-order recurrence, final RNG and Adam counters/groups, plus separately retained frozen implementation/equivalence tests. No pre-first-update resume snapshot exists; no training replay was performed.',
            'phase_final_report_CPU_scope': 'Absolute time.process_time sampled before final report/artifact serialization, not independently recorded exit rusage. Whole waited-children CPU is available only in the C1 controller aggregate including preflight.',
            'phase_chain': logic, 'inherited_memorization_passed': parent['memorization']['passed'],
            'clock_sampling_source': sampling_source, 'clock_sampling_adapter': sampling_receipt,
            'new_diagnostic_updates': 0, **metrics, 'fresh_forward': fresh,
            'scientific_admission': 'HOLD'}
