"""Regression for observed positive elapsed-sample gaps; reject false refunds."""

import copy
import json
from pathlib import Path
import unittest

from clock_sampling import late_clock_view, verify_source_sampling_order

HERE = Path(__file__).resolve().parent


def fixture():
    value = json.loads((HERE / 'fixtures/actual-attention101-clock-samples.json').read_bytes())
    return ({'epochs': value['epochs']}, {'whole_process_wall_seconds': value['parent_outer_wall_seconds']},
            {'whole_process_wall_seconds': value['child_outer_wall_seconds']})


class ClockSamplingTests(unittest.TestCase):
    def test_exact_C1_source_has_two_ordered_clock_reads(self):
        result = verify_source_sampling_order(HERE / 'fixtures/continuation-c1.py')
        self.assertIn('second elapsed()', result['source_semantics'])

    def test_actual_23_positive_gaps_preserve_original_later_cost_and_raw_bytes(self):
        values = fixture()
        before = copy.deepcopy(values)
        view, receipt = late_clock_view(*values)
        self.assertEqual(values, before)
        self.assertEqual(len(receipt['intervals']), 23)
        self.assertGreater(min(row['sample_gap_seconds'] for row in receipt['intervals']), 1e-6)
        for raw, derived in zip(values[0]['epochs'], view['epochs']):
            self.assertEqual(raw['cumulative_process_wall_seconds'], derived['cumulative_process_wall_seconds'])
            self.assertEqual(derived['cumulative_process_wall_seconds'] - values[1]['whole_process_wall_seconds'] - derived['phase_process_wall_seconds'], 0.)

    def test_negative_gap_is_rejected_without_tolerance(self):
        values = fixture()
        values[0]['epochs'][0]['cumulative_process_wall_seconds'] = values[1]['whole_process_wall_seconds'] + values[0]['epochs'][0]['phase_process_wall_seconds'] - .00001
        with self.assertRaisesRegex(ValueError, 'unordered'):
            late_clock_view(*values)

    def test_late_sample_after_outer_end_is_rejected(self):
        values = fixture()
        values[0]['epochs'][0]['cumulative_process_wall_seconds'] = values[1]['whole_process_wall_seconds'] + values[2]['whole_process_wall_seconds'] + .01
        with self.assertRaisesRegex(ValueError, 'out-of-bounds'):
            late_clock_view(*values)

    def test_nonfinite_clock_is_rejected(self):
        values = fixture()
        values[0]['epochs'][0]['phase_process_wall_seconds'] = float('nan')
        with self.assertRaisesRegex(ValueError, 'nonfinite'):
            late_clock_view(*values)


if __name__ == '__main__':
    unittest.main()
