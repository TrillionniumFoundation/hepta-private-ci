"""Checkpoint tensors, registered optimizer groups, and saved/fresh predictions."""

import math
import inspect
from pathlib import Path
import sys
import time

import numpy as np
import torch

from subset_context import exact_tree_equal, frozen, require, sha


def construction(context, configuration, initial, report, fit_plan):
    sys.path.insert(0, str(context.source / 'proposals/localization-v3'))
    from cores import CoreStudyModel
    import cores
    require(Path(cores.__file__).resolve() == context.source / 'proposals/localization-v3/cores.py',
            'fresh constructor imported a different candidate source')
    model = CoreStudyModel(**configuration)
    require(exact_tree_equal(dict(model.state_dict()), dict(initial)), 'recorded initialization differs from original seeded constructor')
    groups = {}
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        hints = getattr(parameter, '_optim', {})
        require(isinstance(hints, dict) and not set(hints) - {'lr', 'weight_decay'}, 'unsupported optimizer hint')
        lr, decay = hints.get('lr', fit_plan['learning_rate']), hints.get('weight_decay', 0.)
        require(math.isfinite(lr) and lr > 0 and math.isfinite(decay) and decay >= 0, 'invalid optimizer hint')
        groups.setdefault((lr, decay), []).append(name)
    expected = [{'lr': lr, 'weight_decay': decay, 'parameter_names': names} for (lr, decay), names in groups.items()]
    require(report['optimizer_groups'] == expected, 'reported optimizer group names/LR differ from source parameter hints')
    return expected


def verify_optimizer(checkpoint, expected_groups, expected_steps):
    optimizer = checkpoint['optimizer']
    require(isinstance(optimizer, dict), 'optimizer state missing')
    groups = optimizer['param_groups']
    require(len(groups) == len(expected_groups), 'optimizer group count mismatch')
    identifiers = []
    defaults = {name: item.default for name, item in inspect.signature(torch.optim.AdamW.__init__).parameters.items()
                if name not in ('self', 'params', 'lr', 'weight_decay') and item.default is not inspect.Parameter.empty}
    for actual, expected in zip(groups, expected_groups):
        require(actual['lr'] == expected['lr'] and actual['weight_decay'] == expected['weight_decay'], 'optimizer LR/decay changed')
        require(all(name in actual and actual[name] == value for name, value in defaults.items()),
                'optimizer defaults differ from pinned AdamW constructor')
        require(len(actual['params']) == len(expected['parameter_names']), 'optimizer parameter membership mismatch')
        for ident, name in zip(actual['params'], expected['parameter_names']):
            identifiers.append(ident)
            state = optimizer['state'][ident]
            require(float(state['step']) == expected_steps, 'optimizer counter differs from completed update count')
            for moment in ('exp_avg', 'exp_avg_sq'):
                require(state[moment].shape == checkpoint['model'][name].shape, 'Adam moment shape differs from named parameter')
                require(bool(torch.isfinite(state[moment]).all()), 'nonfinite Adam moment')
            second = state['exp_avg_sq']
            second = torch.view_as_real(second) if second.is_complex() else second
            require(bool((second >= 0).all()), 'negative Adam second moment')
    require(len(identifiers) == len(set(identifiers)) and set(identifiers) == set(optimizer['state']), 'missing/duplicate optimizer state')
    require(checkpoint['torch_rng'].dtype == torch.uint8 and checkpoint['torch_rng'].ndim == 1, 'invalid Torch RNG state')
    generator = torch.Generator(device='cpu')
    generator.set_state(checkpoint['torch_rng'])
    return {'optimizer_parameters': len(identifiers), 'optimizer_steps': expected_steps,
            'optimizer_group_names_and_hints_verified': True,
            'AdamW_constructor_default_fields_checked': sorted(defaults), 'second_moments_nonnegative': True,
            'torch_rng_format_valid': True,
            'torch_rng_bytes_sha256': frozen.tensor_digest({'state': checkpoint['torch_rng']})}


def frozen_shared(initial, checkpoint):
    names = [name for name in initial if name.startswith(('frontend.', 'head.'))]
    require(all(torch.equal(initial[name], checkpoint['model'][name]) for name in names), 'frozen shared tensor changed')


def saved_metrics(context, root, report, best, epochs):
    stored = context.checkpoint(root / 'development_logits.pt')
    require(stored['episode_ids'] == context.dev_ids, 'development episode order differs')
    require(np.array_equal(stored['labels'].numpy(), context.labels), 'saved development labels differ')
    logits = stored['logits'].numpy()
    require(logits.shape == (len(context.labels), 11) and np.isfinite(logits).all(), 'invalid development logits')
    actual = frozen.independent_metrics(logits, context.labels)
    differences = frozen.metric_differences(actual, report['selected_development'])
    combined = dict(report, epochs=epochs)
    best_differences = frozen.selected_best_metric_differences(actual, combined, best['epochs_completed'])
    return stored, {'saved_logits_sha256': sha(root / 'development_logits.pt'),
                    'independent_selected_development': actual,
                    'metric_absolute_differences': differences,
                    'strict_best_metric_absolute_differences': best_differences}


def fresh_predictions(context, name, configuration, best, stored):
    started = time.monotonic()
    logits = frozen.fresh_forward(context.source, configuration, best['model'], context.dev, context.plan['batch_size'])
    actual = frozen.independent_metrics(logits.numpy(), context.labels)
    frozen.metric_differences(actual, frozen.independent_metrics(stored['logits'].numpy(), context.labels))
    maximum = float((logits - stored['logits']).abs().max())
    require(maximum <= 2e-12, 'fresh predictions disagree with retained selected logits')
    path = context.output / ('fresh-' + name + '.pt')
    torch.save({'logits': logits, 'labels': torch.from_numpy(context.labels),
                'episode_ids': context.dev_ids, 'model_configuration': configuration,
                'candidate_source': str(context.source)}, path)
    return {'performed': True, 'max_logit_absolute_difference': maximum,
            'file': path.name, 'sha256': sha(path), 'bytes': path.stat().st_size,
            'seconds': time.monotonic() - started, 'batch_size': context.plan['batch_size'],
            'gradients': False, 'source': str(context.source),
            'scope': 'Exact original-v8 constructor and model forward; C1 inherited implementation identities are audited separately.'}
