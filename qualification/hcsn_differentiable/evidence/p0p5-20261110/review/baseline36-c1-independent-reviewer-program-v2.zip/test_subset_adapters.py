"""Meaningful failure cases for new subset/C1 artifact adapters; no training."""

import copy
import inspect
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

import numpy as np
import torch

from subset_context import exact_tree_equal, frozen, inherited_source_equivalence
from subset_checkpoints import saved_metrics, verify_optimizer
from subset_c1 import check_continued_journal
from run_subset_review import check_launch_sequence


def journal_fixture():
    parent = {'epochs': [{}] * 100, 'main_updates': 200}
    row = {'epoch': 101, 'complete': True, 'events': 12,
           'training_target_weight_sum': 6., 'training_weighted_loss_numerator': 12.,
           'training_weighted_loss': 2., 'development': {'macro_f1_11_classes': .4},
           'phase_process_wall_seconds': 2., 'cumulative_process_wall_seconds': 1002.,
           'phase_full_process_cpu_seconds': 1.8}
    events = [{'kind': 'epoch_started', 'epoch': 101, 'episode_order': ['A', 'B', 'C']}]
    for number, ids, count, weight in [(201, ['A', 'B'], 8, 4.), (202, ['C'], 4, 2.)]:
        events += [{'kind': 'update_started', 'phase': 'main', 'episode_ids': ids},
                   {'kind': 'optimizer_completed', 'phase': 'main', 'number': number,
                    'events': count, 'target_weight_sum': weight, 'weighted_loss_numerator': 2 * weight,
                    'loss': 2., 'gradient_norm': .2, 'micro_forward_calls': 1}]
    events.append({'kind': 'epoch_completed', **row})
    child = {'status': 'completed_development', 'main_updates': 202, 'epochs': [row]}
    return events, child, parent, {'batch_size': 2, 'micro_batch_size': None}, {'A': 4, 'B': 4, 'C': 4}


class SubsetAdapterTests(unittest.TestCase):
    def test_two_intents_one_PID_terminal_protocol_and_duplicate_launch_rejected(self):
        rows = [{'status': 'started', 'process_started': False},
                {'status': 'started', 'process_started': False, 'argv': ['python']},
                {'status': 'started', 'process_started': True, 'argv': ['python'], 'pid': 123},
                {'status': 'completed', 'process_started': True, 'argv': ['python'], 'pid': 123}]
        self.assertEqual(check_launch_sequence(rows, rows[-1]), 123)
        for bad in [rows[:3] + [copy.deepcopy(rows[2])] + rows[3:],
                    [*rows[:2], dict(rows[2], pid=124), rows[3]]]:
            with self.assertRaises(ValueError):
                check_launch_sequence(bad, bad[-1])

    def test_real_cumulative_journal_converts_without_mutating_original(self):
        values = journal_fixture()
        before = copy.deepcopy(values)
        receipt = check_continued_journal(*values)
        self.assertEqual(receipt['main_updates'], 2)
        self.assertEqual(receipt['cumulative_main_updates'], 202)
        self.assertEqual(values, before)

    def test_reset_optimizer_number_is_rejected(self):
        values = journal_fixture()
        values[0][2]['number'] = 1
        with self.assertRaises((ValueError, AssertionError)):
            check_continued_journal(*values)

    def test_missing_episode_and_weighted_numerator_are_rejected(self):
        for kind in ('episode', 'weight'):
            values = journal_fixture()
            if kind == 'episode':
                values[0][3]['episode_ids'] = ['B']
            else:
                values[0][2]['weighted_loss_numerator'] = 9.
            with self.assertRaises((ValueError, AssertionError)):
                check_continued_journal(*values)

    def test_replayed_diagnostic_is_rejected(self):
        values = journal_fixture()
        values[0].insert(0, {'kind': 'memorization_evaluated', 'update': 64})
        with self.assertRaisesRegex(ValueError, 'diagnostic'):
            check_continued_journal(*values)

    def test_source_formatting_is_distinguished_from_semantic_change(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            old, new = root / 'v8', root / 'c1'
            for path in (old, new):
                (path / 'proposals').mkdir(parents=True)
            a, b = old / 'proposals/core.py', new / 'proposals/core.py'
            a.write_text('x=1\n')
            b.write_text('x = 1\n')
            parent = {'source_before': {str(a): frozen.sha(a)}}
            child = {'source_before': {str(b): frozen.sha(b)}, 'inherited_source_equivalence': {str(b): True}}
            result = inherited_source_equivalence(SimpleNamespace(source=old, c1_source=new), child, parent)
            self.assertEqual(result[str(b)], 'different_bytes_equal_AST')
            b.write_text('x = 2\n')
            child['source_before'][str(b)] = frozen.sha(b)
            with self.assertRaisesRegex(ValueError, 'AST changed'):
                inherited_source_equivalence(SimpleNamespace(source=old, c1_source=new), child, parent)

    def test_adam_state_requires_group_counter_and_tensor_geometry(self):
        checkpoint = {'model': {'weight': torch.zeros(2, dtype=torch.float64)},
                      'torch_rng': torch.get_rng_state(),
                      'optimizer': {'param_groups': [{'lr': .003, 'weight_decay': 0., 'params': [0]}],
                                    'state': {0: {'step': torch.tensor(5.), 'exp_avg': torch.zeros(2), 'exp_avg_sq': torch.ones(2)}}}}
        checkpoint['optimizer']['param_groups'][0].update(
            {name: item.default for name, item in inspect.signature(torch.optim.AdamW.__init__).parameters.items()
             if name not in ('self', 'params', 'lr', 'weight_decay') and item.default is not inspect.Parameter.empty})
        groups = [{'lr': .003, 'weight_decay': 0., 'parameter_names': ['weight']}]
        self.assertEqual(verify_optimizer(checkpoint, groups, 5)['optimizer_steps'], 5)
        for field in ('step', 'exp_avg', 'exp_avg_sq'):
            bad = copy.deepcopy(checkpoint)
            bad['optimizer']['state'][0][field] = (torch.tensor(0.) if field == 'step' else
                                                   -torch.ones(2) if field == 'exp_avg_sq' else torch.zeros(3))
            with self.assertRaises(ValueError):
                verify_optimizer(bad, groups, 5)

    def test_saved_logits_are_bound_to_D_labels_and_cumulative_strict_best(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            logits = torch.arange(44, dtype=torch.float64).reshape(4, 11) / 100
            labels = torch.tensor([0, 1, 2, 3])
            torch.save({'logits': logits, 'labels': labels, 'episode_ids': ['D01']}, root / 'development_logits.pt')
            context = SimpleNamespace(labels=labels.numpy(), dev_ids=['D01'],
                                      checkpoint=lambda path: torch.load(path, weights_only=True))
            metrics = frozen.independent_metrics(logits.numpy(), labels.numpy())
            epochs = [{'epoch': 1, 'development': metrics}, {'epoch': 2, 'development': metrics}]
            report = {'selected_development': metrics, 'best_epoch': 1}
            saved_metrics(context, root, report, {'epochs_completed': 1}, epochs)
            with self.assertRaisesRegex(ValueError, 'first strict-best'):
                saved_metrics(context, root, report, {'epochs_completed': 2}, epochs)
            context.labels = np.array([3, 2, 1, 0])
            with self.assertRaisesRegex(ValueError, 'labels'):
                saved_metrics(context, root, report, {'epochs_completed': 1}, epochs)

    def test_tensor_tree_equality_checks_dtype_and_full_optimizer_structure(self):
        left = {'state': {1: {'moment': torch.ones(2, dtype=torch.float64)}}, 'groups': [.001]}
        self.assertTrue(exact_tree_equal(left, copy.deepcopy(left)))
        right = copy.deepcopy(left)
        right['state'][1]['moment'] = right['state'][1]['moment'].float()
        self.assertFalse(exact_tree_equal(left, right))


if __name__ == '__main__':
    unittest.main()
