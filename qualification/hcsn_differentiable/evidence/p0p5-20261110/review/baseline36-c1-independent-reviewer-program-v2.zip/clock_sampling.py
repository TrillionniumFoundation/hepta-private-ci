"""Derive one conservative observation clock from two ordered source samples."""

import ast
import copy
import math
from pathlib import Path

from subset_context import require, sha


def verify_source_sampling_order(source):
    tree = ast.parse(Path(source).read_text())
    matches = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Dict):
            continue
        keys = [key.value if isinstance(key, ast.Constant) else None for key in node.keys]
        early, cumulative = 'phase_process_wall_seconds', 'cumulative_process_wall_seconds'
        if early not in keys or cumulative not in keys:
            continue
        first, second = node.values[keys.index(early)], node.values[keys.index(cumulative)]
        call = lambda value: isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == 'elapsed' and not value.args and not value.keywords
        require(keys.index(early) < keys.index(cumulative) and call(first), 'early phase time is not sampled first')
        require(isinstance(second, ast.BinOp) and isinstance(second.op, ast.Add)
                and call(second.right) and isinstance(second.left, ast.Subscript)
                and isinstance(second.left.value, ast.Name) and second.left.value.id == 'outer'
                and isinstance(second.left.slice, ast.Constant)
                and second.left.slice.value == 'whole_process_wall_seconds', 'cumulative clock is not a second elapsed sample plus complete parent wall')
        matches.append(node.lineno)
    require(len(matches) == 1, 'ambiguous/missing double-sampled epoch clock')
    return {'source_sha256': sha(source), 'epoch_dictionary_line': matches[0],
            'source_semantics': 'Python dict value evaluation samples early phase first, then cumulative at a second elapsed() call.'}


def late_clock_view(child, parent_outer, child_outer):
    parent = parent_outer['whole_process_wall_seconds']
    end = child_outer['whole_process_wall_seconds']
    require(all(type(v) in (int, float) and math.isfinite(v) and v >= 0 for v in (parent, end)), 'invalid full outer wall')
    view = copy.deepcopy(child)
    intervals = []
    for raw, derived in zip(child['epochs'], view['epochs']):
        early, cumulative = raw['phase_process_wall_seconds'], raw['cumulative_process_wall_seconds']
        require(all(type(v) in (int, float) and math.isfinite(v) for v in (early, cumulative)), 'nonfinite or invalid raw sample')
        late = cumulative - parent
        require(math.isfinite(late) and 0 <= early <= late <= end, 'unordered or out-of-bounds double clock sample')
        derived['phase_process_wall_seconds'] = late
        intervals.append({'epoch': raw['epoch'], 'raw_phase_early_seconds': early,
                          'derived_phase_late_seconds': late,
                          'sample_gap_seconds': late - early,
                          'original_cumulative_seconds_unchanged': cumulative,
                          'child_complete_outer_wall_seconds': end})
    require(bool(intervals), 'no continued observations')
    return view, {'schema': 'C1-double-sampled-clock-adapter-v1', 'raw_report_modified': False,
                  'helper_receives_deep_copy_with_late_phase_clock': True,
                  'existing_helper_tolerance_changed': False,
                  'quality_cost_axis': 'Original later cumulative_process_wall_seconds, unchanged',
                  'checks': 'Every row finite and 0 <= raw_early <= raw_cumulative - complete_parent_outer <= complete_child_outer; no added tolerance.',
                  'intervals': intervals}
