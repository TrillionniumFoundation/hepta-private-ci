"""Audit already completed original baselines without requiring a final42 result."""

import math
import random

import torch

from subset_context import frozen, require
from subset_checkpoints import construction, verify_optimizer, frozen_shared, saved_metrics, fresh_predictions


def audit_baseline(context, name, fresh):
    root = context.campaign / name
    arm, seed, lr = context.roster[name]
    require(arm != 'hcsn', 'HCSN is outside this completed-baseline subset')
    outer, plan = context.outer[name], context.read(root / 'plan.json')
    require((plan['arm'], plan['seed'], plan['learning_rate']) == (arm, seed, lr), 'fit identity differs')
    require(plan['manifest_sha256'] == context.plan['manifest_sha256'] and not plan['train_shared'] and plan['learn_core_adapter'], 'data/shared regime differs')
    for field in ('width', 'batch_size', 'min_epochs', 'max_epochs', 'patience', 'memorization_updates',
                  'memorization_check_every', 'plateau_delta', 'quality_threshold', 'threads', 's4_repo'):
        require(plan[field] == context.plan[field], 'fit plan differs: ' + field)
    require(plan['micro_batch_size'] == context.plan['micro_batch_sizes'].get(arm), 'microbatch differs')
    require(plan['wall_seconds'] == max(1, outer['hard_wall_seconds'] - 30), 'inner budget differs')
    require(plan['rss_bytes'] == context.plan['peak_rss_bytes'], 'RSS ceiling differs')
    require(plan['hcsn_grid_json'] is None, 'baseline has unexpected physical grid')
    require(plan['plif_config_json'] == (context.plan['plif_configuration'] if arm == 'snn_plif' else None), 'PLIF configuration differs')
    for suffix in ('stdout', 'stderr'):
        context.bind(context.campaign / (name + '.' + suffix), outer[suffix + '_sha256'])
    report = context.read(root / 'result.json', outer['result_sha256'])
    require(report['status'] == 'completed_development' and not report['confirmation_access']
            and report['scientific_admission'] == 'HOLD' and report['resume_supported'] is False, 'original fit status/scope differs')
    require(report['plan_sha256'] == context.bind(root / 'plan.json'), 'plan binding differs')
    required = frozen.require_retained_artifacts(root, report, plan)
    context.verify_sources(report)
    adequacy = frozen.validate_adequacy(report, plan)
    for path in root.iterdir():
        if path.is_file():
            context.bind(path)
    journal, partial = frozen.read_journal(root / 'events.jsonl')
    require(not partial, 'completed baseline has partial journal')
    journal_receipt, observations = frozen.check_journal(journal, report, context.training_events, plan)
    weighted_checks = context.weight_denominators(journal)
    checkpoints = {}
    fields = [('initial.pt', 'initialization_sha256'), ('memorization.pt', 'memorization_checkpoint_sha256'),
              ('best.pt', 'best_checkpoint_sha256'), ('last.pt', 'last_checkpoint_sha256')]
    for filename, field in fields:
        checkpoint = context.checkpoint(root / filename, report[field])
        frozen.validate_configuration(checkpoint['model_configuration'], plan)
        require(checkpoint['model_configuration'] == report['model_configuration'], 'report/checkpoint construction differs')
        checkpoints[filename] = checkpoint
    initial = checkpoints['initial.pt']['model']
    expected_groups = construction(context, report['model_configuration'], initial, report, plan)
    optimizer_checks = {}
    updates_per_epoch = math.ceil(len(context.train) / plan['batch_size'])
    for filename in ('memorization.pt', 'best.pt', 'last.pt'):
        checkpoint = checkpoints[filename]
        frozen_shared(initial, checkpoint)
        if filename == 'memorization.pt':
            require(checkpoint['main_updates'] == 0, 'diagnostic checkpoint includes main updates')
            steps = report['diagnostic_updates']
        else:
            epoch = report['best_epoch'] if filename == 'best.pt' else len(report['epochs'])
            require(checkpoint['epochs_completed'] == epoch and checkpoint['main_updates'] == epoch * updates_per_epoch, 'epoch/update checkpoint metadata differs')
            steps = checkpoint['main_updates']
        require(checkpoint['data_manifest_sha256'] == plan['manifest_sha256'], 'checkpoint data differs')
        optimizer_checks[filename] = verify_optimizer(checkpoint, expected_groups, steps)
    order_epochs = context.check_order(journal, random.Random(seed).getstate(), checkpoints['last.pt']['order_rng'])
    shared = {prefix: frozen.tensor_digest(initial, prefix + '.') for prefix in ('frontend', 'head', 'temporal_adapter')}
    for prefix, field in [('frontend', 'initial_frontend_sha256'), ('head', 'initial_head_sha256'),
                          ('temporal_adapter', 'initial_temporal_adapter_sha256')]:
        require(shared[prefix] == report[field], 'common initialization tensor hash differs')
    require(torch.equal(initial['temporal_adapter.weight'], torch.eye(plan['width'], dtype=torch.float64))
            and not bool(torch.count_nonzero(initial['temporal_adapter.bias'])), 'adapter is not identity initialized')
    require(seed not in context.shared or context.shared[seed] == shared, 'initial shared tensors differ across cores/LR')
    context.shared[seed] = shared
    initial_digest = frozen.tensor_digest(initial)
    require((arm, seed) not in context.initials or context.initials[(arm, seed)] == initial_digest, 'core initialization differs across learning rates')
    context.initials[(arm, seed)] = initial_digest
    stored, metrics = saved_metrics(context, root, report, checkpoints['best.pt'], report['epochs'])
    result = {'name': name, 'arm': arm, 'seed': seed, 'learning_rate': lr,
              'audit_status': 'passed_completed_original_baseline', 'required_artifacts': required,
              'report_sha256': context.bind(root / 'result.json'), 'model_configuration': report['model_configuration'],
              'independent_adequacy': adequacy, 'original_stop_reason': report['stop_reason'],
              'memorization_passed': report['memorization']['passed'],
              'diagnostic_updates': report['diagnostic_updates'], 'main_updates': report['main_updates'],
              'epochs': len(report['epochs']), 'best_epoch': report['best_epoch'],
              'journal': journal_receipt, 'independent_ABC_class_weight_denominators_checked': weighted_checks,
              'all_main_epoch_orders_and_final_rng_checked': order_epochs,
              'optimizer_checks': optimizer_checks, 'shared_initial_tensor_hashes': shared,
              'initial_seeded_constructor_exact': True, 'all_common_tensors_frozen': True,
              **metrics, 'fresh_forward': {'performed': False, 'scope': 'one predeclared representative per original core'},
              'whole_original_process_wall_seconds': outer['whole_process_wall_seconds'],
              'actual_original_outer_wall_ceiling_seconds': outer['hard_wall_seconds'],
              'original_fit_cpu_seconds': report['cpu_seconds'],
              'original_full_process_cpu_lower_bound': max(report['cpu_seconds'], *(row['process_cpu_seconds'] for row in report['epochs'])),
              'original_full_process_cpu_exact': None, 'peak_rss_bytes': report['peak_rss_bytes'],
              'scientific_admission': 'HOLD'}
    if fresh:
        result['fresh_forward'] = fresh_predictions(context, 'original-' + name, report['model_configuration'], checkpoints['best.pt'], stored)
    return result, {'plan': plan, 'report': report, 'outer': outer, 'checkpoints': checkpoints,
                    'journal': journal, 'optimizer_groups': expected_groups}
