"""Read-only identities and shared data for the completed baseline subset."""

import ast
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import random
import sys

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'frozen-v2'))
import review_campaign_fresh42 as frozen


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def exact_tree_equal(left, right):
    if isinstance(left, torch.Tensor):
        return isinstance(right, torch.Tensor) and left.dtype == right.dtype and torch.equal(left, right)
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(exact_tree_equal(left[k], right[k]) for k in left)
    if isinstance(left, (tuple, list)):
        return len(left) == len(right) and all(exact_tree_equal(a, b) for a, b in zip(left, right))
    return left == right


class Context:
    def __init__(self, base, output):
        self.base, self.output = Path(base).resolve(), Path(output).resolve()
        self.source = self.base / 'run-source-v8'
        self.c1_source = self.base / 'run-source-c1-v1'
        self.campaign = self.base / 'campaign-v2'
        self.c1 = self.base / 'campaign-v2-continuation-c1'
        self.inputs, self.sources, self.shared, self.initials = {}, {}, {}, {}
        self.bindings = self.read(HERE / 'bindings.json')
        for name, digest in self.bindings['frozen_reviewer_files'].items():
            self.bind(HERE / 'frozen-v2' / name, digest, source=True)
        for path in HERE.glob('*.py'):
            self.bind(path, source=True)
        expected = self.read(HERE / 'frozen-v2/expected-v8-source.json')
        for name, digest in expected['files'].items():
            self.bind(self.source / name, digest, source=True)
        for name, digest in self.bindings['c1_source_files'].items():
            self.bind(self.c1_source / name, digest, source=True)
        self.bind(self.base / 'native_continuation_controller_v3.py',
                  self.bindings['c1_controller_sha256'], source=True)
        self.plan = self.read(self.campaign / 'locked-plan.json', frozen.EXPECTED_PLAN)
        require(self.plan['source_capsule_sha256'] == frozen.EXPECTED_CAPSULE, 'wrong v8 capsule')
        for name, digest in self.read(self.campaign / 'source-manifest.json').items():
            self.bind(self.source / name, digest, source=True)
        tasks = [(a, s, lr) for s in self.plan['seeds'] for lr in self.plan['learning_rates'] for a in self.plan['arms']]
        if self.plan['dispatch_hcsn_first']:
            tasks.sort(key=lambda item: item[0] != 'hcsn')
        self.roster = {f'{a}-s{s}-lr{lr:g}': (a, s, lr) for a, s, lr in tasks}
        require(len(self.roster) == 42, 'wrong original roster')
        self.baselines = [name for name, (arm, _, _) in self.roster.items() if arm != 'hcsn']
        require(len(self.baselines) == 36, 'wrong baseline subset')
        self.command_bytes = (self.campaign / 'commands.jsonl').read_bytes()
        self.commands, self.partial_command_tail = frozen.read_journal(None, allow_partial=True, data=self.command_bytes)
        (output / 'original-commands-context.jsonl').write_bytes(self.command_bytes)
        self.outer = {}
        for name in self.baselines:
            rows = [row for row in self.commands if row['name'] == name]
            require(len(rows) == 2 and rows[0]['status'] == 'started' and rows[1]['status'] == 'completed',
                    'all 36 original baselines must already be terminal completed')
            require(rows[1]['returncode'] == 0, 'nonzero original baseline exit')
            actual = min(self.plan['per_fit_wall_seconds'], self.plan['whole_wall_seconds'] - rows[0]['dispatch_offset_seconds'])
            require(rows[0]['hard_wall_seconds'] == actual == rows[1]['hard_wall_seconds'], 'actual dispatch wall ceiling mismatch')
            self.outer[name] = rows[1]
        self.c1_controller = self.read(self.c1 / 'RESULT.json', self.bindings['c1_result_sha256'])
        require(self.c1_controller['status'] == 'completed_continuation_roster', 'C1 controller is incomplete')
        require(self.c1_controller['source_archive_sha256'] == self.bindings['c1_source_zip_sha256'], 'wrong C1 capsule')
        self.c1_outer = {row['name']: row for row in self.c1_controller['attempts']}
        require(len(self.c1_outer) == len(self.c1_controller['attempts']) == 7, 'wrong/duplicate C1 roster')
        require(self.c1_controller['source_unchanged'] and not self.c1_controller['confirmation_access'], 'C1 source/access gate')
        self.read_data()

    def bind(self, path, expected=None, source=False):
        path = Path(path).resolve()
        actual = sha(path)
        if expected is not None:
            require(actual == expected, f'file hash mismatch: {path}')
        target = self.sources if source else self.inputs
        require(str(path) not in target or target[str(path)] == actual, f'input changed during read: {path}')
        target[str(path)] = actual
        return actual

    def read(self, path, expected=None):
        self.bind(path, expected)
        return json.loads(Path(path).read_bytes())

    def checkpoint(self, path, expected=None):
        self.bind(path, expected)
        return torch.load(path, map_location='cpu', weights_only=True)

    def read_data(self):
        prepared = Path(self.plan['prepared']).resolve()
        self.manifest = self.read(prepared / 'data-manifest.json', self.plan['manifest_sha256'])
        require(self.manifest['mode'] == 'all-development' and not self.manifest['confirmation_access'], 'wrong data mode')
        for name, key in [('frontend.json', 'frontend_sha256'), ('selection.json', 'selection_sha256')]:
            self.bind(prepared / name, self.manifest[key])
        self.episodes, self.train, self.dev = {}, [], []
        for item in self.manifest['episodes']:
            path = (prepared / item['path']).resolve()
            require(path.is_relative_to(prepared), 'episode path escapes prepared data')
            row = self.read(path, item['sha256'])
            require(row['id'] == item['id'] and row['partition'] == item['partition'] and len(row['y']) == item['events'], 'episode metadata mismatch')
            require(all(type(y) is int and 0 <= y < 11 for y in row['y']), 'invalid label')
            require(row['dt'] == [tick / 10000000 for tick in row['delta_ticks']], 'duration identity mismatch')
            self.episodes[row['id']] = row
            if row['partition'] == 'train':
                require(row['sequence'][0] in 'ABC', 'unexpected training subject')
                self.train.append(row)
            else:
                require(row['partition'] == 'dev' and row['sequence'].startswith('D'), 'unexpected development subject')
                self.dev.append(row)
        self.training_events = {row['id']: len(row['y']) for row in self.train}
        self.labels = np.array([y for row in self.dev for y in row['y']], dtype=np.int64)
        self.dev_ids = [row['id'] for row in self.dev]
        require(len(self.episodes) == 484 and len(self.labels) == 31952 and sum(self.training_events.values()) == 89216, 'unexpected ABC/D dimensions')
        counts = np.bincount([y for row in self.train for y in row['y']], minlength=11)
        require((counts > 0).all(), 'training lacks class support')
        weights = np.power(counts.astype(np.float64), -.5)
        weights /= weights.mean()
        self.episode_target_weights = {row['id']: float(weights[row['y']].sum()) for row in self.train}

    def verify_sources(self, report):
        require(report['source_before'] == report['source_after'] and report['source_unchanged'], 'source identity changed')
        for path, digest in report['source_before'].items():
            self.bind(path, digest, source=True)

    def weight_denominators(self, events):
        pending, count = None, 0
        for row in events:
            if row['kind'] == 'update_started':
                require(pending is None, 'overlapping update')
                pending = row['episode_ids']
            elif row['kind'] == 'optimizer_completed':
                require(pending is not None, 'optimizer without batch')
                expected = sum(self.episode_target_weights[eid] for eid in pending)
                require(abs(row['target_weight_sum'] - expected) < 1e-8, 'class-weight denominator differs from actual ABC labels')
                pending = None
                count += 1
        return count

    def check_order(self, events, initial_state, last_state):
        rng = random.Random()
        rng.setstate(initial_state)
        ids = [row['id'] for row in self.train]
        checked = 0
        for event in events:
            if event['kind'] == 'epoch_started':
                order = list(range(len(ids)))
                rng.shuffle(order)
                require(event['episode_order'] == [ids[i] for i in order], 'epoch permutation differs from retained RNG')
                checked += 1
        require(rng.getstate() == last_state, 'final sample-order RNG differs from all recorded epochs')
        return checked

    def final_identity_check(self):
        for path, digest in {**self.inputs, **self.sources}.items():
            require(sha(path) == digest, f'pinned input changed during review: {path}')
        now = (self.campaign / 'commands.jsonl').read_bytes()
        require(now.startswith(self.command_bytes), 'live original command journal was rewritten')
        rows, tail = frozen.read_journal(None, allow_partial=True, data=now)
        for name in self.baselines:
            require([r for r in rows if r['name'] == name] == [r for r in self.commands if r['name'] == name], 'baseline terminal outer records changed')
        (self.output / 'original-commands-context-after.jsonl').write_bytes(now)
        return {'pinned_inputs_unchanged': True, 'source_unchanged': True,
                'live_command_journal_append_only': True,
                'context_is_atomic_full42_snapshot': False,
                'initial_partial_context_tail': self.partial_command_tail,
                'final_partial_context_tail': tail}


def inherited_source_equivalence(context, child, parent):
    checks, relations = {}, {}
    for name, digest in child['source_before'].items():
        if name in parent['source_before']:
            require(digest == parent['source_before'][name], 'shared dependency changed')
            checks[name], relations[name] = True, 'exact_same_path_bytes'
            continue
        path = Path(name)
        if path.is_relative_to(context.c1_source):
            suffix = path.relative_to(context.c1_source)
            old = context.source / suffix
            if suffix.as_posix() in ('proposals/localization-v3/continuation.py', 'proposals/localization-v3/continuation_state.py', 'proposals/localization-v3/test_continuation.py'):
                relations[name] = 'new_explicitly_pinned_continuation_module'
                continue
            require(old.is_file(), 'unmatched inherited source')
            if sha(old) == digest:
                relations[name] = 'exact_bytes'
            else:
                require(ast.dump(ast.parse(path.read_text()), include_attributes=False) == ast.dump(ast.parse(old.read_text()), include_attributes=False), 'inherited AST changed')
                relations[name] = 'different_bytes_equal_AST'
            checks[name] = True
        else:
            raise ValueError('unbound continuation source: ' + name)
    require(checks == child['inherited_source_equivalence'], 'reported source equivalence differs from independent check')
    return relations
