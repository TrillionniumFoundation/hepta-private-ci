"""Read-only review of the completed original36 baseline subset plus seven C1 phases."""

import os
import time

PROCESS_STARTED = time.monotonic()
os.environ.update(OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                  CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1')

import argparse
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import json
import resource
import traceback
from zipfile import ZipFile, ZIP_DEFLATED

import torch

from subset_context import Context, HERE, frozen, require, save, sha
from subset_baselines import audit_baseline
from subset_c1 import audit_child, mechanical_roster


def check_launch_sequence(rows, outer):
    """The pinned controller emits two intents, one PID, then one terminal row."""
    require(len(rows) == 4 and [row['status'] for row in rows] == ['started'] * 3 + ['completed'],
            'C1 launch journal differs from pinned successful dispatch protocol')
    require([row['process_started'] for row in rows] == [False, False, True, True],
            'C1 has duplicate, missing, or ambiguous process launch')
    require(rows[-1] == outer, 'C1 terminal journal/controller differs')
    pid = rows[2].get('pid')
    require(type(pid) is int and pid > 0 and outer.get('pid') == pid, 'C1 PID identity differs')
    require(all('pid' not in row for row in rows[:2]), 'prelaunch record already has a PID')
    require(rows[1]['argv'] == rows[2]['argv'] == outer['argv'], 'C1 argv changed across launch')
    return pid


def controller_checks(context):
    report = context.c1_controller
    for name, digest in context.read(context.c1 / 'source-manifest.json').items():
        context.bind(context.c1_source / name, digest, source=True)
    context.bind(context.c1 / 'locked-parent-plan.json', frozen.EXPECTED_PLAN)
    commands, partial = frozen.read_journal(context.c1 / 'commands.jsonl')
    context.bind(context.c1 / 'commands.jsonl')
    require(not partial, 'terminal C1 command journal has partial tail')
    pids = []
    for name, outer in context.c1_outer.items():
        rows = [row for row in commands if row['name'] == name]
        pids.append(check_launch_sequence(rows, outer))
    require(len(set(pids)) == 7, 'C1 process PID repeated across candidate phases')
    require(set(row['name'] for row in commands) == set(context.c1_outer), 'unexpected C1 process in journal')
    require(report['actual_continuations_started'] == 7 and report['original_baselines_terminal'] == 36, 'C1 cardinality differs')
    require(report['attempt_cost_accounting_complete'] and not report['attempt_wall_sum_is_lower_bound'], 'incomplete C1 attempt cost ledger')
    require(not report['new_diagnostics'] and not report['new_learning_rates'] and not report['fit_restarts'], 'C1 policy changed')
    require(not report['launch_status_unknown_names'] and not report['missing_terminal_attempt_names'], 'unreconciled C1 process identity')
    for name, field in [('outer', 'whole_process_wall_seconds'), ('wrapper', 'attempt_wrapper_wall_seconds')]:
        expected = sum(row[field] for row in report['attempts'])
        require(abs(expected - report['sum_attempt_' + name + '_wall_seconds']) < 1e-8, 'C1 aggregate cost differs')
    for row in report['preflight']:
        require(row['returncode'] == 0 and row['status'] == 'completed', 'actual C1 preflight failed')
        for stream in ('stdout', 'stderr'):
            context.bind(context.c1 / ('continuation-tests.' + stream), row[stream + '_sha256'])
    return {'original_baseline_processes': 36, 'C1_processes': len(pids), 'independently_counted_C1_PIDs': pids,
            'C1_controller_wall_seconds': report['whole_wall_seconds'],
            'C1_sum_child_outer_wall_seconds': report['sum_attempt_outer_wall_seconds'],
            'C1_sum_wrapper_wall_seconds': report['sum_attempt_wrapper_wall_seconds'],
            'C1_waited_children_cpu_seconds_including_preflight': report['children_cpu_seconds'],
            'C1_controller_cpu_seconds': report['controller_cpu_seconds'],
            'original42_controller_final_CPU_available_in_this_subset': False,
            'scope': 'C1 controller/child timers overlap. Original42 is still outside this subset; no complete campaign CPU total is inferred.'}


def summarize_candidates(context, baselines, continuations):
    child_by_name = {row['name']: row for row in continuations if row['audit_status'].startswith('passed_')}
    candidates = []
    for row in baselines:
        if not row['audit_status'].startswith('passed_'):
            continue
        child = child_by_name.get(row['name'])
        quality = (child or row)['independent_selected_development']['macro_f1_11_classes']
        candidates.append({'name': row['name'], 'arm': row['arm'], 'seed': row['seed'], 'learning_rate': row['learning_rate'],
                           'quality': quality, 'selected_phase': 'C1' if child else 'original',
                           'original_adequacy': row['independent_adequacy']['independently_recomputed'],
                           'combined_chain_adequacy': child['phase_chain']['derived_chain_adequacy'] if child else row['independent_adequacy']['independently_recomputed'],
                           'memorization_passed': row['memorization_passed'],
                           'charged_complete_process_wall_seconds': child['phase_chain']['charged_chain_outer_wall_seconds'] if child else row['whole_original_process_wall_seconds'],
                           'actual_original_outer_wall_ceiling_seconds': row['actual_original_outer_wall_ceiling_seconds'],
                           'scientific_admission': 'HOLD'})
    selections = []
    for arm in context.plan['arms']:
        if arm == 'hcsn':
            continue
        rows = [row for row in candidates if row['arm'] == arm]
        means = []
        for lr in context.plan['learning_rates']:
            group = [row for row in rows if row['learning_rate'] == lr]
            complete = sorted(row['seed'] for row in group) == sorted(context.plan['seeds'])
            means.append({'learning_rate': lr, 'all_three_seeds_present': complete,
                          'mean_D_macro_f1_if_complete': sum(row['quality'] for row in group) / 3 if complete else None,
                          'adequate_chain_count': sum(row['combined_chain_adequacy'] for row in group),
                          'memo_failures_retained': [row['name'] for row in group if not row['memorization_passed']]})
        selected = max(means, key=lambda item: item['mean_D_macro_f1_if_complete'])['learning_rate'] if all(item['all_three_seeds_present'] for item in means) else None
        charged_names = [name for name in context.baselines if context.roster[name][0] == arm]
        require(len(charged_names) == 6, 'cost roster omits original candidate')
        charged = sum(context.outer[name]['whole_process_wall_seconds'] for name in charged_names)
        charged += sum(row['whole_process_wall_seconds'] for name, row in context.c1_outer.items() if name in charged_names)
        selections.append({'arm': arm, 'both_learning_rate_rosters': means,
                           'one_common_LR_by_three_seed_mean_D': selected,
                           'all_six_original_candidates_plus_C1_active_wall_seconds': charged,
                           'all_six_original_candidates_charged_even_when_independent_audit_fails': charged_names,
                           'scope': 'Descriptive development selection, including memo-failed candidates. Neither an independent confirmation nor a scientific admission.'})
    return candidates, selections


def main():
    require(__debug__, 'review must run with assertions enabled')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    started_utc = datetime.now(timezone.utc).isoformat()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    report = {'schema': 'fresh42-completed-baseline36-plus-C1-independent-review-v1',
              'mode': 'completed_baseline_subset_and_C1_phase_chains', 'expected_original_roster': 42,
              'original_HCSN_final_review_performed': False, 'full42_final_audit': False,
              'training_performed': False, 'optimizer_steps_executed': 0,
              'scientific_admission': 'HOLD', 'confirmation_access': False,
              'started_utc': started_utc, 'concurrency_scope': 'Read-only single-thread reviewer; original native HCSN jobs may run concurrently. Reviewer costs are separate.'}
    records, children, parents = [], [], {}
    try:
        context = Context(args.base, out)
        report['controller_checks'] = controller_checks(context)
        seen_cores = set()
        for name in context.baselines:
            arm = context.roster[name][0]
            try:
                result, data = audit_baseline(context, name, arm not in seen_cores)
                parents[name] = data
                seen_cores.add(arm)
            except Exception:
                result = {'name': name, 'audit_status': 'audit_failed', 'error': traceback.format_exc()}
            records.append(result)
            save(out / ('original-' + name + '.json'), result)
            print(json.dumps({'stage': 'original', 'name': name, 'audit_status': result['audit_status'],
                              'original_adequacy': result.get('independent_adequacy', {}).get('independently_recomputed')}), flush=True)
        if len(parents) == 36:
            report['mechanical_C1_roster'] = mechanical_roster(context, parents)
        for name in sorted(context.c1_outer):
            try:
                require(name in parents, 'parent did not pass baseline audit')
                result = audit_child(context, name, parents[name])
            except Exception:
                result = {'name': name, 'audit_status': 'audit_failed', 'error': traceback.format_exc()}
            children.append(result)
            save(out / ('C1-' + name + '.json'), result)
            print(json.dumps({'stage': 'C1', 'name': name, 'audit_status': result['audit_status']}), flush=True)
        report['identity_checks'] = context.final_identity_check()
        report['source_sha256'], report['input_sha256'] = context.sources, context.inputs
        report['candidate_chains'], report['development_LR_selection'] = summarize_candidates(context, records, children)
        report['original_baseline_complete_process_wall_seconds'] = sum(row['whole_process_wall_seconds'] for row in context.outer.values())
        report['baseline_plus_C1_active_process_wall_seconds'] = report['original_baseline_complete_process_wall_seconds'] + context.c1_controller['sum_attempt_outer_wall_seconds']
        report['cost_scope'] = 'Sum of retained active process walls across this subset. It excludes inter-phase waiting and differs from concurrent calendar wall. No total original42 CPU or energy is imputed.'
        report['original_baseline_cpu_lower_bound'] = sum(row['original_full_process_cpu_lower_bound'] for row in records if 'original_full_process_cpu_lower_bound' in row)
        report['cpu_lower_bound_audited_baseline_rows'] = sum('original_full_process_cpu_lower_bound' in row for row in records)
        report['original_baseline_exact_exit_cpu_seconds'] = None
        report['original_baseline_heuristic_adequacy_passes'] = sum(row.get('independent_adequacy', {}).get('independently_recomputed', False) for row in records)
        report['combined_baseline_chain_heuristic_adequacy_passes'] = sum(row['combined_chain_adequacy'] for row in report['candidate_chains'])
        report['memorization_failures_retained'] = [row['name'] for row in report['candidate_chains'] if not row['memorization_passed']]
        report['fresh_forward_files'] = [row['fresh_forward'] for row in records + children if row.get('fresh_forward', {}).get('performed')]
        report['passed'] = len(records) == 36 and len(children) == 7 and all(row['audit_status'].startswith('passed_') for row in records + children)
    except Exception:
        report.update(passed=False, global_error=traceback.format_exc())
    report.update(original_baseline_records=records, C1_records=children,
                  finished_utc=datetime.now(timezone.utc).isoformat(),
                  review_process_wall_seconds=time.monotonic() - PROCESS_STARTED,
                  review_process_cpu_sample_seconds=time.process_time(),
                  review_timer_scope='Process-entry wall and absolute process CPU sampled before final result/manifest/ZIP serialization. Separate launcher receipt must retain full waited-process wall and child CPU.',
                  peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                  energy_joules=None, torch=torch.__version__, numpy=frozen.np.__version__)
    save(out / 'RESULT.json', report)
    summary = {key: report.get(key) for key in ['schema', 'mode', 'passed', 'full42_final_audit',
               'started_utc', 'finished_utc', 'original_baseline_heuristic_adequacy_passes',
               'combined_baseline_chain_heuristic_adequacy_passes', 'memorization_failures_retained',
               'review_process_wall_seconds', 'review_process_cpu_sample_seconds', 'peak_rss_bytes']}
    summary.update(original_baseline_audit_counts=dict(Counter(row['audit_status'] for row in records)),
                   C1_audit_counts=dict(Counter(row['audit_status'] for row in children)),
                   result_sha256=sha(out / 'RESULT.json'), scientific_admission='HOLD')
    save(out / 'SUMMARY.json', summary)
    manifest = {'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in out.iterdir() if p.is_file()},
                'scope': 'Independent subset review artifacts; original sources/data/checkpoints remain at hash-bound inputs.'}
    save(out / 'MANIFEST.json', manifest)
    archive = Path(str(out) + '.zip')
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zipped:
        for path in sorted(out.iterdir()):
            if path.is_file():
                zipped.write(path, path.name)
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None, 'audit archive CRC failed')
        for name, identity in manifest['files'].items():
            raw = zipped.read(name)
            require(len(raw) == identity['bytes'] and frozen.hashlib.sha256(raw).hexdigest() == identity['sha256'], 'audit archive member mismatch')
    save(out / 'ARCHIVE.json', {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive),
                               'manifest_sha256': sha(out / 'MANIFEST.json'), 'all_manifest_members_exact': True})
    print(json.dumps(summary), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
