"""Audit seven actual C1 chains with ordered late clocks; reuse pinned original36."""

import os
import time

PROCESS_STARTED = time.monotonic()
os.environ.update(OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                  CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1')

import argparse
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import resource
import statistics
import traceback
from zipfile import ZipFile, ZIP_DEFLATED

import torch

from subset_context import Context, HERE, frozen, require, save, sha
from subset_c1 import audit_child, mechanical_roster
from run_subset_review import controller_checks, summarize_candidates


def reuse_originals(context):
    lineage = context.read(HERE / 'PRIOR-REVIEW.json')
    prior_root = Path(lineage['prior_output_root'])
    prior = context.read(prior_root / 'RESULT.json', lineage['prior_result_sha256'])
    require(prior['passed'] is False and prior['full42_final_audit'] is False, 'prior overall failure must remain explicit')
    require(prior['identity_checks']['pinned_inputs_unchanged'] and prior['identity_checks']['source_unchanged'], 'prior identity check failed')
    rows = prior['original_baseline_records']
    require(len(rows) == 36 and {row['name'] for row in rows} == set(context.baselines), 'prior baseline roster differs')
    require(all(row['audit_status'] == 'passed_completed_original_baseline' for row in rows), 'prior baseline record did not pass')
    for path, digest in prior['source_sha256'].items():
        context.bind(path, digest, source=True)
    for path, digest in prior['input_sha256'].items():
        context.bind(path, digest)
    fresh = []
    for row in rows:
        require(row['report_sha256'] == context.outer[row['name']]['result_sha256'], 'original terminal report changed since prior review')
        if row['fresh_forward']['performed']:
            identity = row['fresh_forward']
            context.bind(prior_root / identity['file'], identity['sha256'])
            fresh.append({'name': row['name'], 'path': str(prior_root / identity['file']), 'sha256': identity['sha256']})
    require(len(fresh) == 6, 'prior representative forward coverage differs')
    receipt = context.read(context.base / 'baseline36-c1-review-launch-v1/receipt.json', lineage['prior_execution_receipt_sha256'])
    require(receipt['status'] == 'failed' and receipt['returncode'] == 1 and receipt['result_sha256'] == lineage['prior_result_sha256'], 'prior process receipt binding differs')
    context.bind(Path(str(prior_root) + '.zip'), lineage['prior_archive_sha256'])
    parents = {}
    for name in context.baselines:
        root = context.campaign / name
        report = context.read(root / 'result.json', context.outer[name]['result_sha256'])
        plan = context.read(root / 'plan.json', report['plan_sha256'])
        value = {'report': report, 'plan': plan, 'outer': context.outer[name], 'optimizer_groups': report['optimizer_groups']}
        if name in context.c1_outer:
            value['checkpoints'] = {filename: context.checkpoint(root / filename, report[field]) for filename, field in
                                    [('initial.pt', 'initialization_sha256'), ('last.pt', 'last_checkpoint_sha256'), ('best.pt', 'best_checkpoint_sha256')]}
        parents[name] = value
    return rows, parents, {'prior_result': str(prior_root / 'RESULT.json'),
                           'prior_result_sha256': lineage['prior_result_sha256'],
                           'prior_overall_status': 'failed', 'original36_passed_subrecords_reused': 36,
                           'all_prior_input_and_source_file_hashes_rechecked': True,
                           'baseline_fresh_forward_reexecuted': False, 'prior_fresh_files_reverified': fresh,
                           'prior_full_review_wall_seconds_still_charged': receipt['whole_review_process_wall_seconds'],
                           'prior_waited_child_CPU_seconds_still_charged': receipt['waited_review_child_cpu_seconds']}


def core_table(context, originals, children, parents, candidates, selections):
    records = {row['name']: row for row in originals}
    records.update({row['name']: row for row in children if row['audit_status'].startswith('passed_')})
    child_records = {row['name']: row for row in children if row['audit_status'].startswith('passed_')}
    table = []
    for selection in selections:
        lr = selection['one_common_LR_by_three_seed_mean_D']
        if lr is None:
            table.append({'arm': selection['arm'], 'incomplete_quality_roster': True})
            continue
        selected = sorted([row for row in candidates if row['arm'] == selection['arm'] and row['learning_rate'] == lr], key=lambda row: row['seed'])
        require(len(selected) == 3, 'common-LR result lacks a declared seed')
        individual = []
        for candidate in selected:
            name = candidate['name']
            if name in child_records:
                point = child_records[name]['phase_chain']['first_observed_quality_crossing']
                crossing = point['cumulative_process_wall_seconds'] if point else None
            else:
                crossing = parents[name]['report'].get('process_time_to_quality_seconds')
            individual.append({**candidate, 'D_metrics': records[name]['independent_selected_development'],
                               'first_observed_0p30_active_wall_seconds': crossing})
        fields = ['macro_f1_11_classes', 'accuracy', 'nll', 'brier_half_sum', 'brier_mean_classes', 'ece_15_equal_width_bins']
        means = {key: sum(row['D_metrics'][key] for row in individual) / 3 for key in fields}
        f1 = [row['D_metrics']['macro_f1_11_classes'] for row in individual]
        times = [row['first_observed_0p30_active_wall_seconds'] for row in individual]
        table.append({'arm': selection['arm'], 'common_learning_rate': lr, 'D_three_seed_mean': means,
                      'D_macro_f1_seed_min': min(f1), 'D_macro_f1_seed_max': max(f1),
                      'D_macro_f1_sample_standard_deviation': statistics.stdev(f1),
                      'selected_LR_adequate_chains': sum(row['combined_chain_adequacy'] for row in individual),
                      'selected_LR_complete_process_wall_sum_seconds': sum(row['charged_complete_process_wall_seconds'] for row in individual),
                      'all_six_original_plus_C1_process_wall_sum_seconds': selection['all_six_original_candidates_plus_C1_active_wall_seconds'],
                      'median_first_observed_0p30_if_all_three_crossed_seconds': statistics.median(times) if all(value is not None for value in times) else None,
                      'right_censored_seed_names': [row['name'] for row in individual if row['first_observed_0p30_active_wall_seconds'] is None],
                      'individual_seeds': individual,
                      'selection_scope': 'One LR by mean D macro-F1 over all three declared seeds; both LR rosters retained and all six processes plus C1 charged. D is tuning data, not independent confirmation.'})
    return table


def main():
    require(__debug__, 'assertions must remain enabled')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    report = {'schema': 'baseline36-C1-independent-clock-supplement-v2',
              'mode': 'seven_C1_actual_chains_plus_hash_reused_original36',
              'started_utc': datetime.now(timezone.utc).isoformat(),
              'full42_final_audit': False, 'HCSN_final_model_read': False,
              'training_performed': False, 'optimizer_steps_executed': 0,
              'scientific_admission': 'HOLD', 'confirmation_access': False}
    children, originals = [], []
    try:
        context = Context(args.base, out)
        report['controller_checks'] = controller_checks(context)
        originals, parents, reuse = reuse_originals(context)
        report['original36_reuse'] = reuse
        report['mechanical_C1_roster'] = mechanical_roster(context, parents)
        for name in sorted(context.c1_outer):
            try:
                row = audit_child(context, name, parents[name])
            except Exception:
                row = {'name': name, 'audit_status': 'audit_failed', 'error': traceback.format_exc()}
            children.append(row)
            save(out / ('C1-' + name + '.json'), row)
            print(frozen.json.dumps({'name': name, 'audit_status': row['audit_status']}), flush=True)
        report['identity_checks'] = context.final_identity_check()
        report['source_sha256'], report['input_sha256'] = context.sources, context.inputs
        report['candidate_chains'], selections = summarize_candidates(context, originals, children)
        report['development_LR_selection'] = selections
        all_children_passed = len(children) == 7 and all(row['audit_status'].startswith('passed_') for row in children)
        report['core_fixed_LR_table'] = core_table(context, originals, children, parents, report['candidate_chains'], selections) if all_children_passed else []
        report['core_fixed_LR_table_scope'] = 'Complete independently audited subset' if all_children_passed else 'Withheld because at least one C1 audit failed; original candidate summaries are not a replacement for the failed phase.'
        report['original_baseline_heuristic_adequacy_passes'] = sum(row['original_adequacy'] for row in report['candidate_chains'])
        report['combined_baseline_chain_heuristic_adequacy_passes'] = sum(row['combined_chain_adequacy'] for row in report['candidate_chains'])
        report['memorization_failures_retained'] = [row['name'] for row in report['candidate_chains'] if not row['memorization_passed']]
        report['original36_plus_C1_active_process_wall_seconds'] = sum(row['all_six_original_candidates_plus_C1_active_wall_seconds'] for row in selections)
        report['cost_scope'] = 'Complete process walls over36 original candidates plus7 C1 phases; distinct from calendar wall. C1 controller waited CPU includes preflight; per-fit exit CPU/energy remain unknown. Prior failed review and this supplement are separate overheads.'
        report['passed'] = all_children_passed
    except Exception:
        report.update(passed=False, global_error=traceback.format_exc())
    report.update(C1_records=children, finished_utc=datetime.now(timezone.utc).isoformat(),
                  review_process_wall_seconds=time.monotonic()-PROCESS_STARTED,
                  review_process_cpu_sample_seconds=time.process_time(),
                  review_timer_scope='Sample before final serialization/ZIP; launcher retains full waited wall/CPU separately.',
                  peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
                  energy_joules=None, torch=torch.__version__, numpy=frozen.np.__version__)
    save(out / 'RESULT.json', report)
    summary = {key: report.get(key) for key in ['schema', 'mode', 'passed', 'full42_final_audit',
               'started_utc', 'finished_utc', 'original_baseline_heuristic_adequacy_passes',
               'combined_baseline_chain_heuristic_adequacy_passes', 'memorization_failures_retained',
               'review_process_wall_seconds', 'review_process_cpu_sample_seconds', 'peak_rss_bytes']}
    summary.update(C1_audit_counts=dict(Counter(row['audit_status'] for row in children)),
                   original_baseline_passed_records_reused=len(originals), result_sha256=sha(out/'RESULT.json'),
                   scientific_admission='HOLD')
    save(out/'SUMMARY.json', summary)
    if report.get('core_fixed_LR_table'):
        save(out/'CORE_TABLE.json', report['core_fixed_LR_table'])
        lines = ['# Completed baseline36 plus C1: independently audited D results', '',
                 'D is development/tuning data. One common LR is selected by the mean macro-F1 over all three seeds. Both declared LR rosters and all C1 phases are charged. HCSN is excluded; no full42 or scientific-benefit claim is made.', '',
                 '| Core | Common LR | Mean D macro-F1 | Seed range | Mean accuracy | Mean NLL | Adequate selected chains | All6 + C1 active process seconds |',
                 '|---|---:|---:|---:|---:|---:|---:|---:|']
        for row in report['core_fixed_LR_table']:
            m = row['D_three_seed_mean']
            lines.append(f"| {row['arm']} | {row['common_learning_rate']:g} | {m['macro_f1_11_classes']:.6f} | {row['D_macro_f1_seed_min']:.6f}–{row['D_macro_f1_seed_max']:.6f} | {m['accuracy']:.6f} | {m['nll']:.6f} | {row['selected_LR_adequate_chains']}/3 | {row['all_six_original_plus_C1_process_wall_sum_seconds']:.6f} |")
        lines += ['', 'The original v1 review remains overall failed on a two-sample clock identity. This supplement preserves every raw time, verifies ordered finite sampling intervals, and uses the original later cumulative observation time for all cuts. Original36 hashes and six prior fresh forwards are reverified, with no original training/forward replay. Seven C1 selected checkpoints receive fresh original-v8 no-grad forward checks.', '',
                  'The three memorization failures remain: ' + ', '.join(report['memorization_failures_retained']) + '.', '',
                  'Reported child CPU samples precede final serialization. Exact C1 waited-child CPU is an aggregate including its preflight. Active process-wall sums are not elapsed calendar time; energy is unknown.']
        (out/'README.md').write_text('\n'.join(lines)+'\n')
    manifest = {'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in out.iterdir() if p.is_file()}}
    save(out/'MANIFEST.json', manifest)
    archive = Path(str(out)+'.zip')
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zipped:
        for path in sorted(out.iterdir()):
            if path.is_file():
                zipped.write(path, path.name)
    with ZipFile(archive) as zipped:
        require(zipped.testzip() is None, 'archive CRC failed')
        for name, item in manifest['files'].items():
            raw = zipped.read(name)
            require(len(raw) == item['bytes'] and frozen.hashlib.sha256(raw).hexdigest() == item['sha256'], 'archive member mismatch')
    save(out/'ARCHIVE.json', {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive),
                             'manifest_sha256': sha(out/'MANIFEST.json'), 'all_manifest_members_exact': True})
    print(frozen.json.dumps(summary), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
