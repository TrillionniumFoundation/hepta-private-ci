# Fresh42 independent reviewer v2

This is an independently frozen reviewer for the original immutable v8 source
and fresh42 plan. It preserves the v1 reviewer and the original raw36 reviewer.
It never trains or edits a candidate. The full 42-fit audit and C1 production
phase audit have **not** been executed by this preparation package.

The original candidate archive is SHA256
`288283cae2b2cf4e7b68432e040e643a5e1b00a7de961fc848dd5cf20eb46102`;
the original plan is SHA256
`e13f97aafdaf66548f016f2dcc3a38dd7e641a2ea83d52b8bea89f4c7e0cf114`.
The recovered v1 archive is 29,872 bytes, SHA256
`efda735f48ba9aea1e6fad9576807da944d311596ef861d74d4c8202bb384bb5`.
Its CRC, all member hashes, cloud bytes and read-back Git base64 copy agree.
See `v1-recovery.json`. The original native read-only preflight request remains
unconfirmed; reconcile key `hcsn-fresh42-independent-preflight-c385-v1` before
launching another preflight.

## Changes in v2

- Completed fits require initial, diagnostic, best and last checkpoints, saved
  development logits, plan and event journal. An HCSN completed fit also requires
  its original trace, whose retained content and truncation are checked separately.
  Every artifact explicitly claimed by a report file SHA is required even if the
  attempt failed. Missing never-created artifacts of a failed fit remain a distinct
  case; a missing claimed artifact fails review.
- Every saved-logit metric is connected to the first strict-best development epoch
  and the checkpoint's epoch, not only the final selected-metric dictionary.
- Full construction configuration is checked against the fit plan, including the
  S4 dependency path. Checkpoints use `{model, model_configuration}` payloads.
- Actual outer wall ceilings are retained per fit. The original controller uses
  `min(14400, 15000 - dispatch_elapsed)`; 14,400 seconds is only the nominal maximum.
  Fixed wall-budget rows disclose whether that fit actually had that opportunity.
  A later cap-limited or timed-out fit does not gain an unobserved result.
- `audit_phase_chain.py` and its tests independently check the proposed C1 logical
  contract: complete original baseline cap, exact actual remaining budget, inherited
  strict best and plateau state, no refreshed diagnostic, cumulative updates,
  first continued sample order, and cost/quality clocks. These functions do **not**
  constitute a full C1 file, tensor, source or production-run audit. The outstanding
  integration is specified in `PHASE-CHAIN-REVIEW.md`.

## Run the original 42-fit audit

Run after the original controller has written its complete final RESULT. Use a
new output directory; no original file is overwritten.

```sh
python review_campaign_fresh42.py \
  --source /home/qian-qi/hepta-hcsn-core-study-20261110-c385-training/run-source-v8 \
  --campaign /home/qian-qi/hepta-hcsn-core-study-20261110-c385-training/campaign-v2 \
  --output /home/qian-qi/hepta-hcsn-independent-fresh42-NEW
```

`--preflight-fit gru-s101-lr0.001` limits review to one terminal fit, with an
explicitly non-atomic outer-journal context. Native v1 preflight reconciliation
must precede another attempt. Do not point the original-v8 reviewer at a C1
directory: the latter has a different source identity and report/checkpoint scope.

The reviewer checks all 484 ABC/D episode identities, original D labels and
31,952 saved logits per completed fit; recomputes metrics with NumPy; validates
epochs, weighted-loss numerators/denominators, optimizer/microbatch counters and
frozen frontend/head tensors; and freshly evaluates one representative checkpoint
per available core. Fresh evaluation uses original full batch 32/no-grad. HCSN's
training microbatch 8 is not the original evaluation layout.

The .30 quality target and 300/900/1800-second cuts are descriptive fixed-budget
observations, with no interpolation. Final fit CPU excludes imports; per-epoch
process CPU is absolute. Aggregate CPU ranges use the final waited-child ledger
minus justified per-fit lower bounds, with the remainder a shared uncertainty
budget. It cannot be added separately to every child as an exact overhead.

All three seeds and both learning rates remain visible. One common learning rate
is selected from the mean D score over all three seeds, only when both complete
LR rosters have observations. Per-seed tuning envelopes and best-seed results are
not expected quality or independent confirmation. D subject selection is not an
estimate of held-out data uncertainty. Prior PLIF tuning, diagnostic failures,
HCSN qualification and failed probes remain separately costed; historical totals
are incomplete. Energy was not measured.

The actual ncps 1.0.1 default CfC output is a convex combination of tanh outputs
and is bounded by [-1,1]. The raw-readout GRU box-domain confidence analysis also
applies to this outer CfC domain. Class feasibility in an outer output domain does
not prove dynamic reachability. The common learned adapter makes the effective
classifier trainable even though stored common-head tensors remain frozen.

Preparation validation is recorded in `VALIDATION.json`. Successful unit tests
and provenance checks grant neither whole-training numerical qualification nor
scientific benefit. All scientific admission remains HOLD.
