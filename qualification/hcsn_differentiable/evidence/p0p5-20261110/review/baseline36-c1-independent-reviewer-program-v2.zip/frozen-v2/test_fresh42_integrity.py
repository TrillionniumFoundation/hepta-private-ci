import copy
import hashlib
from pathlib import Path
import tempfile
import unittest

from audit_fresh42_integrity import (FILE_DIGEST_FIELDS, require_retained_artifacts,
                                     selected_best_metric_differences, validate_configuration)


class RetainedEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        self.plan = {"memorization_updates": 1024, "arm": "gru", "width": 16, "seed": 101,
                     "s4_repo": "/pinned/s4", "hcsn_grid_json": None, "train_shared": False,
                     "cache_frozen_tables": False, "learn_core_adapter": True, "plif_config_json": None}
        self.report = {"status": "completed_development"}
        for name, field in FILE_DIGEST_FIELDS.items():
            if name == "interrupted.pt":
                continue
            raw = ("retained-" + name).encode()
            (self.root / name).write_bytes(raw)
            self.report[field] = hashlib.sha256(raw).hexdigest()
        (self.root / "development_logits.pt").write_bytes(b"saved-logits")

    def tearDown(self):
        self.directory.cleanup()

    def test_deleted_completed_checkpoint_or_logits_cannot_pass(self):
        require_retained_artifacts(self.root, self.report, self.plan)
        for name in ["initial.pt", "memorization.pt", "best.pt", "last.pt", "development_logits.pt"]:
            with self.subTest(name=name):
                raw = (self.root / name).read_bytes()
                (self.root / name).unlink()
                with self.assertRaises(ValueError):
                    require_retained_artifacts(self.root, self.report, self.plan)
                (self.root / name).write_bytes(raw)

    def test_missing_identity_and_changed_bytes_cannot_pass(self):
        report = dict(self.report)
        del report["best_checkpoint_sha256"]
        with self.assertRaises(ValueError):
            require_retained_artifacts(self.root, report, self.plan)
        (self.root / "best.pt").write_bytes(b"different-model")
        with self.assertRaises(ValueError):
            require_retained_artifacts(self.root, self.report, self.plan)

    def test_failed_fit_keeps_declared_files_but_not_never_created_files(self):
        report = {"status": "failed", "initialization_sha256": self.report["initialization_sha256"]}
        (self.root / "last.pt").unlink()
        require_retained_artifacts(self.root, report, self.plan)
        (self.root / "initial.pt").unlink()
        with self.assertRaises(ValueError):
            require_retained_artifacts(self.root, report, self.plan)

    def test_completed_hcsn_requires_original_trace_even_if_truncated(self):
        plan = dict(self.plan, arm="hcsn")
        with self.assertRaises(ValueError):
            require_retained_artifacts(self.root, self.report, plan)
        (self.root / "training-domain.jsonl").write_text('{"truncated": true}\n')
        checked = require_retained_artifacts(self.root, self.report, plan)
        self.assertIn("training-domain.jsonl", checked["required_files_checked"])
        # Presence alone earns no trace-content or numerical qualification.

    def test_dependency_path_is_part_of_constructor_identity(self):
        cfg = {"arm": "gru", "width": 16, "seed": 101, "s4_repo": "/pinned/s4",
               "hcsn_grid": None, "freeze_shared": True, "cache_frozen_tables": False,
               "learn_core_adapter": True, "plif_configuration": None}
        validate_configuration(cfg, self.plan)
        with self.assertRaises(ValueError):
            validate_configuration(dict(cfg, s4_repo="/other/s4"), self.plan)

    def test_selected_metrics_must_match_strict_best_and_checkpoint(self):
        a = {"macro_f1_11_classes": .3, "accuracy": .5, "confusion_matrix": [[1, 2], [3, 4]]}
        b = dict(a, macro_f1_11_classes=.4)
        report = {"best_epoch": 2, "epochs": [
            {"epoch": 1, "development": a}, {"epoch": 2, "development": b},
            {"epoch": 3, "development": dict(b)}]}
        selected_best_metric_differences(b, report, 2)
        with self.assertRaises(ValueError):
            selected_best_metric_differences(a, report, 2)
        with self.assertRaises(ValueError):
            selected_best_metric_differences(b, report, 3)
        tied = copy.deepcopy(report)
        tied["best_epoch"] = 3
        with self.assertRaises(ValueError):
            selected_best_metric_differences(b, tied, 3)


if __name__ == "__main__":
    unittest.main()
