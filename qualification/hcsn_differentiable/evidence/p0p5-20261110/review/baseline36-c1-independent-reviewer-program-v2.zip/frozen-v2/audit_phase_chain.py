"""Independent logical checks for the proposed C1 continuation contract.

This is not a complete C1 file/checkpoint audit. Callers must independently bind
all JSON, source and tensor bytes. It never imports the continuation helpers,
trains a candidate, or upgrades the frozen v8 runner's generic resume support.
"""

import math
import random


def require(condition, message):
    if not condition:
        raise ValueError(message)


def epoch_state(epochs, plan):
    best, best_epoch, anchor, stale, first_plateau = -1.0, None, -1.0, 0, None
    for number, row in enumerate(epochs, 1):
        require(row["epoch"] == number and row["complete"] is True,
                "epoch sequence must be contiguous and complete")
        score = row["development"]["macro_f1_11_classes"]
        require(math.isfinite(score) and 0 <= score <= 1, "invalid development score")
        if score > best:
            best, best_epoch = score, number
        if score > anchor + plan["plateau_delta"]:
            anchor, stale = score, 0
        else:
            stale += 1
        if number >= plan["min_epochs"] and stale >= plan["patience"] and first_plateau is None:
            first_plateau = number
    return {"best": best, "best_epoch": best_epoch, "anchor": anchor,
            "stale": stale, "first_plateau_epoch": first_plateau}


def validate_parent_for_c1(parent, outer, plan):
    require(plan["arm"] != "hcsn", "C1 does not authorize original HCSN continuation")
    require(outer["status"] == "completed" and outer["returncode"] == 0
            and outer["fit_status"] == "completed_development", "parent process did not complete")
    require(parent["status"] == "completed_development"
            and parent["stop_reason"] == "epoch_cap_not_convergence", "parent is not an epoch cap")
    require(parent["source_unchanged"] is True and parent["common_weights_unchanged"] is True
            and outer["source_unchanged"] is True and outer["common_weights_unchanged"] is True,
            "parent source/shared identity gate failed")
    require(parent["source_before"] == parent["source_after"], "parent source receipt conflicts")
    require(plan["max_epochs"] == 100 and len(parent["epochs"]) == 100,
            "C1 requires the original complete 100-epoch cap")
    require(plan["train_shared"] is False and plan["learn_core_adapter"] is True,
            "wrong common-interface regime")
    ceiling = outer["hard_wall_seconds"]
    require(math.isfinite(ceiling) and 0 < ceiling <= 14400,
            "parent actual wall ceiling is missing or exceeds nominal maximum")
    cost = outer["whole_process_wall_seconds"]
    require(math.isfinite(cost) and 0 < cost < ceiling, "parent outer wall is missing/exhausted")
    state = epoch_state(parent["epochs"], plan)
    require(state["first_plateau_epoch"] is None, "parent should already have stopped for plateau")
    require(parent["best_epoch"] == state["best_epoch"], "parent strict best is inconsistent")
    return state


def validate_phase_roster(original_roster, eligible_names, child_names):
    require(len(child_names) == len(set(child_names)), "duplicate continuation of a parent")
    require(set(child_names) <= set(eligible_names) <= set(original_roster),
            "continuation roster escapes mechanically eligible original attempts")
    require(all(not name.startswith("hcsn-") for name in child_names), "HCSN is outside C1")


def check_first_continued_order(parent_last, child_events, training_ids):
    require(all(row.get("phase") != "diagnostic" for row in child_events),
            "continuation replayed a diagnostic")
    starts = [row for row in child_events if row["kind"] == "epoch_started"]
    require(bool(starts), "no continued complete-epoch attempt to check")
    rng = random.Random()
    rng.setstate(parent_last["order_rng"])
    order = list(range(len(training_ids)))
    rng.shuffle(order)
    require(starts[0]["epoch"] == parent_last["epochs_completed"] + 1,
            "continued epoch numbering was reset/repeated")
    require(starts[0]["episode_order"] == [training_ids[i] for i in order],
            "first continued sample order does not follow parent RNG")
    return {"first_continued_order_matches_parent_rng": True,
            "diagnostic_events_repeated": False,
            "optimizer_and_torch_rng_restoration_proven_by_this_check": False}


def audit_phase_chain(parent, parent_outer, plan, child, child_outer, child_plan,
                     updates_per_epoch, budgets=(300, 900, 1800)):
    """Check linked report semantics and full outer-wall accounting.

    Return independent observation curves. Parent full final CPU is unknown;
    the continuation CPU curve therefore has a lower bound, not an invented
    exact cumulative process CPU. Full file/tensor/journal auditing is separate.
    """
    inherited = validate_parent_for_c1(parent, parent_outer, plan)
    parent_wall = parent_outer["whole_process_wall_seconds"]
    ceiling = parent_outer["hard_wall_seconds"]
    remaining = ceiling - parent_wall
    require(child_outer["name"] == parent_outer["name"], "child points to a different parent")
    require(child_outer["hard_remaining_wall_seconds"] == remaining,
            "remaining budget must subtract complete parent outer wall")
    require(child["parent_report_sha256"] == parent_outer["result_sha256"],
            "parent report identity is disconnected")
    require(child["parent_source_sha256"] == parent["source_before"], "parent source identity changed")
    require(child_plan["parent_plan"] == plan and child_plan["parent_outer_record"] == parent_outer,
            "child changed parent plan or outer record")
    require(child_plan["total_wall_seconds"] == ceiling and child_plan["max_epochs"] == 400
            and child_plan["new_learning_rate_or_diagnostic"] is False, "unauthorized continuation policy")
    require(child["model_configuration"] == parent["model_configuration"], "construction config changed")
    require(child["memorization"] == parent["memorization"] and child.get("diagnostic_updates", 0) == 0,
            "diagnostic outcome was replaced or replayed")
    require(child["source_unchanged"] is True and child["source_before"] == child["source_after"]
            and child["common_weights_unchanged"] is True, "continued source/shared gate failed")
    require(child["scientific_admission"] == "HOLD" and child["confirmation_access"] is False,
            "continuation cannot grant scientific admission or confirmation access")
    require(child["parent_complete_epochs"] == 100
            and child["cumulative_epochs_completed"] == 100 + len(child["epochs"]) <= 400,
            "incorrect cumulative epoch count")
    combined = parent["epochs"] + child["epochs"]
    state = epoch_state(combined, plan)
    require(child["best_epoch"] == state["best_epoch"], "child forgot the parent strict best")
    require(child["inherited_best_checkpoint_sha256"] == parent["best_checkpoint_sha256"],
            "parent best identity was not retained")
    if state["best_epoch"] <= 100:
        require(child["best_checkpoint_sha256"] == parent["best_checkpoint_sha256"],
                "tie/regression replaced parent best bytes")
    else:
        require(child["best_checkpoint_sha256"] != parent["best_checkpoint_sha256"],
                "strict improvement still points to parent checkpoint")
    completed = child["status"] == "completed_development"
    minimum_updates = parent["main_updates"] + len(child["epochs"]) * updates_per_epoch
    require(child["main_updates"] >= minimum_updates, "continued optimizer counter was reset")
    if completed:
        require(child["main_updates"] == minimum_updates, "completed phase has unexplained extra updates")
        if child["stop_reason"] == "development_plateau":
            require(state["first_plateau_epoch"] == len(combined), "plateau anchor/stale state was reset")
        else:
            require(child["stop_reason"] == "epoch_cap_not_convergence" and len(combined) == 400
                    and state["first_plateau_epoch"] is None, "completed child stopped without declared rule")
        require(abs(child["selected_development"]["macro_f1_11_classes"] - state["best"]) < 2e-12,
                "selected metrics differ from cumulative strict best")
    adequate = (completed and child["stop_reason"] == "development_plateau"
                and bool(parent["memorization"].get("passed", False)))
    require(child["training_adequacy_established"] == adequate, "continuation claimed unsupported adequacy")
    child_wall = child_outer["whole_process_wall_seconds"]
    require(math.isfinite(child_wall) and child_wall >= 0, "invalid child outer wall")
    require(abs(child_outer["cumulative_outer_wall_seconds"] - parent_wall - child_wall) < 1e-6,
            "outer ledger omitted or duplicated a phase")
    require(child["parent_whole_process_wall_seconds"] == parent_wall
            and child["parent_recorded_fit_cpu_seconds"] == parent["cpu_seconds"]
            and child["parent_full_process_cpu_seconds"] is None, "parent CPU/wall scopes changed")
    require(child["phase_process_wall_seconds"] <= child_wall + 1e-6,
            "child inner process wall exceeds recorded outer wall")
    lower_cpu = max(parent["cpu_seconds"], *(r["process_cpu_seconds"] for r in parent["epochs"]))
    points = [{"phase": "parent", "epoch": r["epoch"],
               "quality": r["development"]["macro_f1_11_classes"],
               "cumulative_process_wall_seconds": r["process_wall_seconds"],
               "cumulative_cpu_lower_seconds": r["process_cpu_seconds"],
               "cumulative_cpu_upper_seconds": r["process_cpu_seconds"]} for r in parent["epochs"]]
    for row in child["epochs"]:
        require(abs(row["cumulative_process_wall_seconds"] - parent_wall - row["phase_process_wall_seconds"]) < 1e-6,
                "epoch clock refunded parent startup/diagnostic work")
        require(row["phase_process_wall_seconds"] <= child_wall + 1e-6,
                "epoch observation occurred after recorded phase end")
        points.append({"phase": "C1", "epoch": row["epoch"],
                       "quality": row["development"]["macro_f1_11_classes"],
                       "cumulative_process_wall_seconds": row["cumulative_process_wall_seconds"],
                       "cumulative_cpu_lower_seconds": lower_cpu + row["phase_full_process_cpu_seconds"],
                       "cumulative_cpu_upper_seconds": None})
    for name in ["cumulative_process_wall_seconds", "cumulative_cpu_lower_seconds"]:
        values = [p[name] for p in points]
        require(all(math.isfinite(v) and v >= 0 for v in values) and values == sorted(values),
                "nonfinite/nonmonotonic continued observation clock")
    first = next((p for p in points if p["quality"] >= plan["quality_threshold"]), None)
    if first is not None and first["phase"] == "parent":
        expected_clock = parent.get("process_time_to_quality_seconds")
    else:
        expected_clock = first["cumulative_process_wall_seconds"] if first else None
    require(child["first_observed_quality_crossing_cumulative_wall_seconds"] == expected_clock,
            "first observed quality crossing was reset")
    wall_cuts = []
    for cut in budgets:
        eligible = [p for p in points if p["cumulative_process_wall_seconds"] <= cut]
        wall_cuts.append({"budget": cut, "best_observed": max(eligible, key=lambda p: p["quality"]) if eligible else None,
                          "no_interpolation": True})
    return {"logical_phase_chain_checks_passed": True, "original_epoch_cap_retained": True,
            "derived_chain_adequacy": adequate, "inherited_plateau_state": inherited,
            "combined_state": state, "observed_points": points, "wall_budget_cuts": wall_cuts,
            "first_observed_quality_crossing": first,
            "crossing_status": "observed" if first else "right_censored",
            "charged_chain_outer_wall_seconds": parent_wall + child_wall,
            "actual_parent_outer_wall_ceiling_seconds": ceiling,
            "nominal_outer_wall_ceiling_seconds": 14400,
            "wall_cost_scope": "sum of parent and child complete process wall; excludes inter-phase waiting and is not calendar latency",
            "cumulative_full_process_cpu_seconds": None,
            "cpu_scope": "Original per-epoch CPU is exact. C1 cumulative CPU has a parent lower bound; complete parent exit CPU was not recorded.",
            "full_file_and_checkpoint_audit_completed_by_this_function": False,
            "scientific_admission": "HOLD"}
