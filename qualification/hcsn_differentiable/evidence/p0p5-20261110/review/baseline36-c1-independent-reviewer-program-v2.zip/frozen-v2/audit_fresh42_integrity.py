"""Fail closed on missing retained evidence and disconnected selections.

These helpers verify artifact presence/identities and the selected-epoch link.
They neither train a model nor grant numerical or scientific qualification.
"""

import hashlib
import math
from pathlib import Path
import re


FILE_DIGEST_FIELDS = {
    "plan.json": "plan_sha256",
    "events.jsonl": "events_sha256",
    "initial.pt": "initialization_sha256",
    "memorization.pt": "memorization_checkpoint_sha256",
    "best.pt": "best_checkpoint_sha256",
    "last.pt": "last_checkpoint_sha256",
    "interrupted.pt": "interrupted_checkpoint_sha256",
}


def require_retained_artifacts(root, report, fit_plan):
    """A completed fit cannot pass by deleting a checkpoint or saved logits.

    Failed/interrupted fits may legitimately lack never-created artifacts, but
    an artifact explicitly claimed by the report must still exist and match.
    Tensor digests are not confused with file digests.
    """
    root = Path(root)
    required = set()
    if report.get("status") == "completed_development":
        required.update(["plan.json", "events.jsonl", "initial.pt", "best.pt",
                         "last.pt", "development_logits.pt"])
        if fit_plan["memorization_updates"] > 0:
            required.add("memorization.pt")
        if fit_plan["arm"] == "hcsn":
            required.add("training-domain.jsonl")
    if report.get("selected_development") is not None:
        required.update(["best.pt", "development_logits.pt"])
    for name, field in FILE_DIGEST_FIELDS.items():
        if field in report:
            required.add(name)
        if name in required and (field not in report or not isinstance(report[field], str)
                                 or re.fullmatch(r"[0-9a-f]{64}", report[field]) is None):
            raise ValueError("missing/invalid retained file digest: " + field)
    for name in sorted(required):
        path = root / name
        if not path.is_file():
            raise ValueError("required retained artifact missing: " + name)
        field = FILE_DIGEST_FIELDS.get(name)
        if field and hashlib.sha256(path.read_bytes()).hexdigest() != report[field]:
            raise ValueError("retained artifact digest mismatch: " + name)
    return {"required_files_checked": sorted(required),
            "declared_files_checked": sorted(n for n, k in FILE_DIGEST_FIELDS.items() if k in report),
            "logit_binding": "observed file hash plus independent selected/strict-best metrics; representative fresh forward remains separate"}


def validate_configuration(configuration, fit_plan):
    expected = {
        "arm": fit_plan["arm"], "width": fit_plan["width"], "seed": fit_plan["seed"],
        "s4_repo": str(fit_plan["s4_repo"]) if fit_plan["s4_repo"] is not None else None,
        "hcsn_grid": fit_plan["hcsn_grid_json"], "freeze_shared": not fit_plan["train_shared"],
        "cache_frozen_tables": fit_plan["cache_frozen_tables"],
        "learn_core_adapter": fit_plan["learn_core_adapter"],
        "plif_configuration": fit_plan["plif_config_json"],
    }
    if configuration != expected:
        raise ValueError("checkpoint construction differs from exact fit plan")


def selected_best_metric_differences(actual, report, checkpoint_epoch, tolerance=2e-12):
    """Bind recomputed saved logits to strict best, including the checkpoint.

    Selection uses strict improvement; a tie must keep the earlier epoch.
    """
    epochs = report["epochs"]
    if not epochs:
        raise ValueError("selected logits have no complete epoch provenance")
    best = max(epochs, key=lambda row: row["development"]["macro_f1_11_classes"])
    if report["best_epoch"] != best["epoch"] or checkpoint_epoch != best["epoch"]:
        raise ValueError("selected checkpoint is not the first strict-best epoch")
    expected = best["development"]
    differences = {}
    for key, value in actual.items():
        if key == "confusion_matrix":
            if value != expected[key]:
                raise ValueError("selected logits disagree with strict-best confusion matrix")
        else:
            difference = abs(value - expected[key])
            if not math.isfinite(difference) or difference > tolerance:
                raise ValueError("selected logits disagree with strict-best metric: " + key)
            differences[key] = difference
    return differences
