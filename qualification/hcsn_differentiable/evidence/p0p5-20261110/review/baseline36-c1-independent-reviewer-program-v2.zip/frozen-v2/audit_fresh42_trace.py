"""Stream-check recorded HCSN visits without granting numerical qualification."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path


def network_digest(state):
    digest=hashlib.sha256();prefix='core.network.'
    for key,value in sorted(state.items()):
        if not key.startswith(prefix):continue
        name=key[len(prefix):]
        digest.update((json.dumps([name,str(value.dtype),list(value.shape)],sort_keys=True,separators=(',',':'))+'\n').encode())
        digest.update(value.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


def audit_trace(path, fit_plan, episodes, initial_state, source_files, completed_main_updates, source_root):
    digest=hashlib.sha256();initial_digest=network_digest(initial_state);header=footer=None;records=states=matched_initial=0
    updates=Counter();captures=Counter();models=set();episodes_seen=set()
    with Path(path).open('rb') as stream:
        for line in stream:
            row=json.loads(line)
            if footer is not None:raise ValueError('content after trace footer')
            if row['kind']=='header':
                if header is not None or records:raise ValueError('duplicate/misplaced trace header')
                header=row
                for name,expected in row['sources'].items():
                    resolved=Path(name) if Path(name).is_absolute() else Path(source_root)/'qualification/hcsn_differentiable'/name
                    resolved=resolved.resolve()
                    if not resolved.is_relative_to(Path(source_root).resolve()):raise ValueError('trace source escapes pinned candidate')
                    if hashlib.sha256(resolved.read_bytes()).hexdigest()!=expected:raise ValueError('trace source hash mismatch')
                    source_files[str(resolved)]=expected
            elif row['kind']=='end':
                footer=row
                if row['prefix_sha256']!=digest.hexdigest():raise ValueError('trace footer prefix mismatch')
                continue
            else:
                if header is None or row['kind']!='visit' or row['index']!=records:raise ValueError('invalid trace visit order')
                if row['grid']!=fit_plan['hcsn_grid_json']:raise ValueError('trace grid mismatch')
                ids=row['episode_id'].split('+')
                if any(eid not in episodes or episodes[eid]['partition']!='train' for eid in ids):raise ValueError('non-training content in training trace')
                valid=row['batch_indices'];pos=row['position']
                if not(len(valid)==len(row['dt'])==len(row['prior'])==len(row['posterior'])):raise ValueError('trace batch shapes differ')
                for j,index in enumerate(valid):
                    ep=episodes[ids[index]]
                    if not 0<=pos<len(ep['y']) or row['dt'][j]!=ep['dt'][pos]:raise ValueError('trace duration/padding mismatch')
                    if not any(ep['x'][pos][12:24]):raise ValueError('invalid observed-mask state retained')
                    for name in ['prior','posterior']:
                        p=row[name][j]
                        if any(not math.isfinite(x) or x<0 for x in p) or abs(sum(p)-1)>2e-11:raise ValueError('invalid retained probability law')
                update=row['update_index']
                if not 0<=update<=completed_main_updates:raise ValueError('trace update outside main ledger')
                if update==0:
                    if row['model_sha256']!=initial_digest:raise ValueError('first main trace did not restore initial network weights')
                    matched_initial+=1
                records+=1;states+=len(valid);updates[update]+=1;captures[row['capture']]+=1
                models.add(row['model_sha256']);episodes_seen.update(ids)
            digest.update(line)
    if header is None or footer is None:raise ValueError('incomplete trace; no whole-trace identity can be claimed')
    if footer['retained_records']!=records:raise ValueError('retained count mismatch')
    if footer['seen_records']!=records+footer['dropped_records']:raise ValueError('seen/drop count mismatch')
    if not footer['source_unchanged'] or footer['sources_after']!=header['sources']:raise ValueError('trace sources changed')
    if header['data_sha256']!=fit_plan['manifest_sha256']:raise ValueError('trace data manifest mismatch')
    config=hashlib.sha256(Path(fit_plan['output']).joinpath('plan.json').read_bytes()).hexdigest()
    if header['configuration_sha256']!=config:raise ValueError('trace configuration mismatch')
    return {'retained_records':records,'retained_probability_states':states,'seen_records':footer['seen_records'],
        'dropped_records':footer['dropped_records'],'truncated':footer['truncated'],
        'drop_reason':footer['drop_reason'],'updates_retained':dict(updates),'captures':dict(captures),
        'distinct_recorded_network_digests':len(models),'training_episodes_retained':sorted(episodes_seen),
        'initial_restored_network_records_independently_matched':matched_initial,
        'padded_states_excluded':footer['padded_states_excluded'],
        'complete_retained_prefix_integrity':True,'complete_executed_stream_capture':not footer['truncated'],'whole_training_domain_qualified':False,
        'numerical_qualification':False,'scientific_admission':'HOLD',
        'scope':'Recorded-prefix bytes, source/data/config/model identities and probability mass only; no continuum accuracy or complete intermediate-model reconstruction.'}
