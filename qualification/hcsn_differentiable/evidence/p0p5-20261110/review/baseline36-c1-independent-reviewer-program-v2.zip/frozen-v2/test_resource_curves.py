import unittest
from resource_curves import aggregate_curves, per_fit_curve, cpu_accounting, opportunity_points, bounded_envelope


def point(name, seed, lr, epoch, wall, cpu, quality):
    return dict(name=name,arm='a',seed=seed,learning_rate=lr,epoch=epoch,
                process_wall_seconds=wall,process_cpu_seconds=cpu,quality=quality)


def fit(name, seed, lr, points, wall, cpu, status='completed', adequate=True):
    return dict(name=name,arm='a',seed=seed,learning_rate=lr,observations=points,
                whole_process_wall_seconds=wall,fit_cpu_seconds=cpu,fit_status=status,
                adequate=adequate,selected_quality=max((p['quality'] for p in points),default=None))


class ResourceEvidenceTests(unittest.TestCase):
    def test_nonfinite_clock_or_cpu_total_cannot_receive_budget_credit(self):
        f=fit('nan',1,.001,[point('nan',1,.001,1,float('nan'),5,.2)],20,10)
        with self.assertRaises(ValueError):
            per_fit_curve(f,{'process_wall_seconds':[300]},.3)
        with self.assertRaises(ValueError):
            cpu_accounting([],float('nan'))

    def test_shortened_outer_limit_does_not_claim_full_common_budget_opportunity(self):
        f=fit('short',1,.001,[point('short',1,.001,1,200,180,.2)],249,220,'timed_out',False)
        f['actual_outer_wall_limit_seconds']=250
        row=per_fit_curve(f,{'process_wall_seconds':[300,900],'process_cpu_seconds':[300]},.3)
        self.assertFalse(row['fixed_budgets']['process_wall_seconds'][0]['actual_outer_wall_limit_allows_budget'])
        self.assertEqual(row['fixed_budgets']['process_wall_seconds'][0]['observed_best']['quality'],.2)
        self.assertEqual(row['crossing_status'],'right_censored')
        self.assertIsNone(row['fixed_budgets']['process_cpu_seconds'][0]['actual_outer_wall_limit_allows_budget'])

    def test_no_quality_interpolation_or_future_credit(self):
        f=fit('a',1,.001,[point('a',1,.001,1,100,80,.2),point('a',1,.001,2,400,320,.4)],430,330)
        r=per_fit_curve(f,{'process_wall_seconds':[300,900],'process_cpu_seconds':[300,900]},.3)
        self.assertEqual(r['fixed_budgets']['process_wall_seconds'][0]['observed_best']['quality'],.2)
        self.assertFalse(r['fixed_budgets']['process_cpu_seconds'][0]['threshold_observed_by_budget'])
        self.assertEqual(r['first_observed_crossing']['process_wall_seconds'],400)

    def test_failed_work_is_charged_before_later_quality(self):
        f1=fit('failed',1,.001,[],200,100,'failed',False)
        f2=fit('second',1,.003,[point('second',1,.003,1,30,50,.4)],70,80)
        ledger=cpu_accounting([f1,f2],200)
        rows,cost=opportunity_points(['failed','second'],{f['name']:f for f in [f1,f2]}, {'failed','second'},ledger)
        self.assertEqual(rows[0]['opportunity_process_wall_seconds'],230)
        self.assertEqual(rows[0]['opportunity_cpu_lower_seconds'],150)
        self.assertEqual(rows[0]['opportunity_cpu_upper_seconds'],170)
        self.assertEqual(cost['process_wall_seconds'],270)
        cut=bounded_envelope(rows,160,.3,[1])
        self.assertFalse(cut['quality_threshold_guaranteed'])
        self.assertTrue(cut['quality_threshold_possible'])

    def test_missing_seed_never_becomes_three_seed_mean(self):
        fs=[fit('s1',1,.001,[point('s1',1,.001,1,10,5,.5)],20,10),
            fit('s2',2,.001,[point('s2',2,.001,1,10,5,.6)],20,10),
            fit('s3',3,.001,[],20,10,'failed',False)]
        r=aggregate_curves(fs,['s1','s2','s3'],['a'],[1,2,3],[.001],
            {'process_wall_seconds':[300],'process_cpu_seconds':[300]},.3,33)
        arm=r['arms'][0]
        self.assertIsNone(arm['learning_rate_selection']['rows'][0]['mean_all_seeds_if_complete'])
        self.assertIsNone(arm['wall_budget_envelopes'][0]['all_seed_median_if_complete'])
        self.assertFalse(arm['all_seeds_observed_crossing'])
        self.assertIsNone(arm['median_all_seed_first_crossing_wall_if_all_observed'])

    def test_completion_order_does_not_change_declared_opportunity_order(self):
        f1=fit('one',1,.001,[point('one',1,.001,1,80,50,.2)],100,60)
        f2=fit('two',1,.003,[point('two',1,.003,1,30,20,.4)],50,30)
        params=(['one','two'],['a'],[1],[.001,.003],{'process_wall_seconds':[100,200],'process_cpu_seconds':[100,200]},.3,100)
        a=aggregate_curves([f1,f2],*params)['arms'][0]
        b=aggregate_curves([f2,f1],*params)['arms'][0]
        self.assertEqual(a['ordered_points'],b['ordered_points'])
        self.assertEqual(a['first_observed_opportunity_crossing']['opportunity_process_wall_seconds'],130)

    def test_inconsistent_child_cpu_ledger_fails_closed(self):
        f=fit('x',1,.001,[point('x',1,.001,1,10,12,.2)],20,15)
        with self.assertRaises(ValueError):cpu_accounting([f],14)

    def test_cpu_epoch_clock_is_not_rebased_to_fit_delta(self):
        f=fit('x',1,.001,[point('x',1,.001,1,100,80,.2)],110,70)
        ledger=cpu_accounting([f],90)
        self.assertEqual(ledger['fit_cpu_lower_bounds']['x'],80)
        self.assertEqual(ledger['unallocated_cpu_upper_budget'],10)
        row=per_fit_curve(f,{'process_cpu_seconds':[75,85],'process_wall_seconds':[75,105]},.3)
        self.assertTrue(row['fixed_budgets']['process_cpu_seconds'][0]['missing_evaluation'])
        self.assertEqual(row['fixed_budgets']['process_cpu_seconds'][1]['observed_best']['quality'],.2)


if __name__=='__main__':unittest.main()
