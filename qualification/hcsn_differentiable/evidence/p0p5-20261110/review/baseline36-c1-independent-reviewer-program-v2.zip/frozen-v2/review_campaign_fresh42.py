"""Independent immutable-v8 fresh42 audit. Never trains or edits a candidate."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback
from zipfile import ZipFile, ZIP_DEFLATED

if not __debug__:
    raise RuntimeError('Independent reviewer must run with Python assertions enabled')

os.environ.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1')
import numpy as np
import torch
from resource_curves import aggregate_curves, per_fit_curve
from audit_fresh42_trace import audit_trace
from audit_fresh42_integrity import require_retained_artifacts, validate_configuration, selected_best_metric_differences

AUDIT_OUTPUT=None
EXPECTED_PLAN='e13f97aafdaf66548f016f2dcc3a38dd7e641a2ea83d52b8bea89f4c7e0cf114'
EXPECTED_CAPSULE='288283cae2b2cf4e7b68432e040e643a5e1b00a7de961fc848dd5cf20eb46102'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
canonical_sha=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
artifact=lambda p:{'bytes':Path(p).stat().st_size,'sha256':sha(p)}


def tensor_digest(state,prefix=''):
    digest=hashlib.sha256()
    for name,value in sorted(state.items()):
        if name.startswith(prefix):
            digest.update(name[len(prefix):].encode());digest.update(str((tuple(value.shape),value.dtype)).encode())
            digest.update(value.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


def independent_metrics(logits,labels):
    shifted=logits-logits.max(axis=1,keepdims=True)
    logp=shifted-np.log(np.exp(shifted).sum(axis=1,keepdims=True));prob=np.exp(logp);pred=logits.argmax(1)
    matrix=np.zeros((11,11),dtype=np.int64);np.add.at(matrix,(labels,pred),1)
    support,predicted,correct=matrix.sum(1),matrix.sum(0),matrix.diagonal()
    f1=np.divide(2*correct,support+predicted,out=np.zeros(11),where=support+predicted>0)
    confidence=prob.max(1);bins=np.minimum(14,np.floor(confidence*15).astype(int));ece=0.
    for index in range(15):
        selected=bins==index
        if selected.any():ece+=selected.mean()*abs(confidence[selected].mean()-(pred[selected]==labels[selected]).mean())
    squared=np.square(prob-np.eye(11)[labels])
    return {'events':len(labels),'accuracy':float(np.mean(pred==labels)),
        'macro_f1_11_classes':float(f1.mean()),'macro_f1_present_classes':float(f1[support>0].mean()),
        'balanced_accuracy_present_classes':float(np.mean(correct[support>0]/support[support>0])),
        'nll':float(-logp[np.arange(len(labels)),labels].mean()),'brier_half_sum':float(.5*squared.sum(1).mean()),
        'brier_mean_classes':float(squared.mean()),'ece_15_equal_width_bins':float(ece),'confusion_matrix':matrix.tolist()}


def metric_differences(actual,expected):
    assert actual['confusion_matrix']==expected['confusion_matrix']
    differences={k:abs(v-expected[k]) for k,v in actual.items() if k!='confusion_matrix'}
    assert max(differences.values())<=2e-12,differences
    return differences


def read_journal(path,allow_partial=False,data=None):
    rows=[];partial_tail=False
    lines=(Path(path).read_bytes() if data is None else data).splitlines(keepends=True)
    for index,line in enumerate(lines):
        try:rows.append(json.loads(line))
        except (json.JSONDecodeError,UnicodeDecodeError):
            if allow_partial and index==len(lines)-1 and not line.endswith(b'\n'):partial_tail=True
            else:raise
    return rows,partial_tail


def check_journal(rows,report,training_events,fit_plan):
    completed={p:[] for p in ['main','diagnostic']};starts=Counter();micro=Counter()
    epochs=[];current_order=None;visited=[];pending=None;weighted=[];observations=[]
    for event in rows:
        kind=event['kind']
        if kind=='epoch_started':
            assert current_order is None
            current_order=event['episode_order'];visited=[];weighted=[]
            assert len(current_order)==len(training_events) and set(current_order)==set(training_events)
        elif kind=='update_started':
            assert pending is None;pending=event;starts[event['phase']]+=1
            assert all(eid in training_events for eid in event['episode_ids'])
            if event['phase']=='main':assert current_order is not None;visited.extend(event['episode_ids'])
        elif kind=='optimizer_completed':
            phase=event['phase'];assert pending is not None and pending['phase']==phase
            assert event['events']==sum(training_events[eid] for eid in pending['episode_ids'])
            assert math.isfinite(event['gradient_norm']) and math.isfinite(event['loss'])
            assert event['target_weight_sum']>0
            assert abs(event['weighted_loss_numerator']/event['target_weight_sum']-event['loss'])<2e-14
            expected_micro=math.ceil(len(pending['episode_ids'])/(fit_plan['micro_batch_size'] or fit_plan['batch_size']))
            assert event['micro_forward_calls']==expected_micro
            completed[phase].append(event['number']);micro[phase]+=event['micro_forward_calls']
            if phase=='main':weighted.append(event)
            pending=None
        elif kind=='epoch_completed':
            assert visited==current_order and event['events']==sum(training_events.values())
            denominator=sum(x['target_weight_sum'] for x in weighted);numerator=sum(x['weighted_loss_numerator'] for x in weighted)
            assert abs(event['training_target_weight_sum']-denominator)<1e-8
            assert abs(event['training_weighted_loss_numerator']-numerator)<1e-8
            assert abs(event['training_weighted_loss']-numerator/denominator)<2e-12
            assert event['complete'] and all(math.isfinite(event[k]) for k in ['process_wall_seconds','process_cpu_seconds'])
            observations.append(event);epochs.append(event['epoch']);current_order=None;visited=[]
    if report:
        for phase in completed:
            assert completed[phase]==list(range(1,report[phase+'_updates']+1))
            assert report[phase+'_micro_forward_attempts']>=micro[phase]
        assert epochs==list(range(1,len(report['epochs'])+1))
        for observed,retained in zip(observations,report['epochs']):
            for key,value in retained.items():assert observed[key]==value,(key,observed[key],value)
        if report['status']=='completed_development':
            assert pending is None and current_order is None
            assert all(starts[p]==len(completed[p]) and report[p+'_micro_forward_attempts']==micro[p] for p in completed)
    return {'main_updates':len(completed['main']),'diagnostic_updates':len(completed['diagnostic']),
            'completed_epochs':len(epochs),'micro_forward_calls':dict(micro),'every_completed_epoch_complete_ABC':True,
            'partial_update_retained':pending is not None,'partial_epoch_retained':current_order is not None},observations


def validate_adequacy(report,fit_plan):
    anchor=-1.;stale=0;first_plateau=None;best=-1.;best_epoch=None
    for row in report['epochs']:
        score=row['development']['macro_f1_11_classes']
        if score>best:best=score;best_epoch=row['epoch']
        if score>anchor+fit_plan['plateau_delta']:anchor=score;stale=0
        else:stale+=1
        if row['epoch']>=fit_plan['min_epochs'] and stale>=fit_plan['patience'] and first_plateau is None:first_plateau=row['epoch']
    if best_epoch is not None:assert report['best_epoch']==best_epoch
    mem=report.get('memorization')
    if mem:
        passing=[r['update'] for r in mem['curve'] if r['update']>0 and r['metrics']['accuracy']>=.95 and r['metrics']['macro_f1_present_classes']>=.9]
        assert mem['first_observed_passing_update']==(passing[0] if passing else None)
        assert mem['passed']==(mem['after']['accuracy']>=.95 and mem['after']['macro_f1_present_classes']>=.9)
        assert report['diagnostic_updates']==mem['curve'][-1]['update']
    if report.get('stop_reason')=='development_plateau':assert first_plateau==len(report['epochs'])
    expected=(report['status']=='completed_development' and report.get('stop_reason')=='development_plateau' and bool(mem and mem['passed']) and report['source_unchanged'])
    assert report['training_adequacy_established']==expected
    return {'independently_recomputed':expected,'strict_best_epoch':best_epoch,'first_plateau_epoch':first_plateau,
            'quality_target_is_separate_from_adequacy':True}


def fresh_forward(source,configuration,state,dev_episodes,batch_size):
    sys.path.insert(0,str(source/'proposals/localization-v3'))
    from cores import CoreStudyModel
    model=CoreStudyModel(**configuration);model.load_state_dict(state,strict=True);model.eval();outputs=[]
    with torch.no_grad():
        for start in range(0,len(dev_episodes),batch_size):
            group=dev_episodes[start:start+batch_size];length=max(len(row['y']) for row in group)
            x=torch.zeros(len(group),length,25,dtype=torch.float64);dt=torch.zeros(len(group),length,dtype=torch.float64)
            for index,episode in enumerate(group):
                n=len(episode['y']);x[index,:n]=torch.tensor(episode['x'],dtype=torch.float64);dt[index,:n]=torch.tensor(episode['dt'],dtype=torch.float64)
            values=model(x,dt);outputs.extend(values[i,:len(ep['y'])] for i,ep in enumerate(group))
    return torch.cat(outputs)


def main():
    global AUDIT_OUTPUT
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True);parser.add_argument('--campaign',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True);parser.add_argument('--preflight-fit')
    args=parser.parse_args();started,cpu_started=time.monotonic(),time.process_time()
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=False);AUDIT_OUTPUT=out
    source,campaign=args.source.resolve(),args.campaign.resolve();here=Path(__file__).resolve().parent
    own_files=['review_campaign_fresh42.py','resource_curves.py','audit_fresh42_trace.py','audit_fresh42_integrity.py','expected-v8-source.json','extra-overheads.json','overhead-ledger-snapshot.json']
    for name in own_files:(out/name).write_bytes((here/name).read_bytes())
    own_hashes={name:sha(out/name) for name in own_files}
    sources_checked={};inputs={};records=[];fresh_arms=set();shared_by_seed={};initial_by_arm_seed={};curves=[]
    def bound(path):inputs[str(path)]=sha(path);return load(path)
    plan=bound(campaign/'locked-plan.json');assert sha(campaign/'locked-plan.json')==EXPECTED_PLAN
    assert plan['source_capsule_sha256']==EXPECTED_CAPSULE
    expected=load(here/'expected-v8-source.json');assert expected['source_capsule_sha256']==EXPECTED_CAPSULE
    for name,digest in expected['files'].items():assert sha(source/name)==digest;sources_checked[str(source/name)]=digest
    source_manifest=bound(campaign/'source-manifest.json')
    for name,digest in source_manifest.items():assert sha(source/name)==digest;sources_checked[str(source/name)]=digest
    tasks=[(arm,seed,lr) for seed in plan['seeds'] for lr in plan['learning_rates'] for arm in plan['arms']]
    if plan['dispatch_hcsn_first']:tasks.sort(key=lambda row:row[0]!='hcsn')
    roster=[f'{a}-s{s}-lr{lr:g}' for a,s,lr in tasks];assert len(roster)==len(set(roster))==42
    identities={name:(a,s,lr) for name,(a,s,lr) in zip(roster,tasks)}
    command_bytes=(campaign/'commands.jsonl').read_bytes();commands,_=read_journal(campaign/'commands.jsonl',allow_partial=bool(args.preflight_fit),data=command_bytes)
    (out/'commands-context-snapshot.jsonl').write_bytes(command_bytes)
    live_context={'commands_sha256_at_read':hashlib.sha256(command_bytes).hexdigest(),'atomic_snapshot':False}
    if args.preflight_fit:
        assert args.preflight_fit in roster
        target_names=[args.preflight_fit]
        campaign_result=None
        attempts={r['name']:r for r in commands if r['status']!='started'}
        assert args.preflight_fit in attempts,'preflight requires an already terminal attempt'
    else:
        campaign_result=bound(campaign/'RESULT.json');inputs[str(campaign/'commands.jsonl')]=sha(campaign/'commands.jsonl')
        assert campaign_result['source_unchanged'] and campaign_result['plan_sha256']==EXPECTED_PLAN
        assert campaign_result['confirmation_access'] is False and campaign_result['scientific_admission']=='HOLD'
        assert sorted(r['name'] for r in campaign_result['attempts'])==sorted(roster)
        attempts={r['name']:r for r in campaign_result['attempts']};target_names=roster
    prepared=Path(plan['prepared']);manifest=bound(prepared/'data-manifest.json');assert sha(prepared/'data-manifest.json')==plan['manifest_sha256']
    assert manifest['mode']=='all-development' and manifest['confirmation_access'] is False
    for name,key in [('frontend.json','frontend_sha256'),('selection.json','selection_sha256')]:
        assert sha(prepared/name)==manifest[key];inputs[str(prepared/name)]=sha(prepared/name)
    episodes={};dev=[];training_events={}
    for entry in manifest['episodes']:
        path=(prepared/entry['path']).resolve();assert path.is_relative_to(prepared.resolve()) and sha(path)==entry['sha256'];inputs[str(path)]=entry['sha256']
        ep=load(path);assert ep['id']==entry['id'] and ep['partition']==entry['partition'] and len(ep['y'])==entry['events']
        assert all(type(y)is int and 0<=y<11 for y in ep['y']);assert ep['dt']==[tick/10000000 for tick in ep['delta_ticks']]
        episodes[ep['id']]=ep
        if ep['partition']=='dev':assert ep['sequence'].startswith('D');dev.append(ep)
        else:assert ep['partition']=='train' and ep['sequence'][0] in 'ABC';training_events[ep['id']]=len(ep['y'])
    labels=np.array([y for ep in dev for y in ep['y']],dtype=np.int64);dev_ids=[ep['id'] for ep in dev]
    assert len(labels)==31952 and sum(training_events.values())==89216 and len(episodes)==484
    budgets={'process_wall_seconds':plan['equal_resource_process_elapsed_seconds'],'process_cpu_seconds':plan['equal_resource_process_cpu_seconds']}
    for name in target_names:
        arm,seed,lr=identities[name];root=campaign/name;outer=attempts[name]
        row={'name':name,'arm':arm,'seed':seed,'learning_rate':lr,'audit_status':'started','fresh_forward':False,'original_outer_status':outer['status']}
        fit_curve={'name':name,'arm':arm,'seed':seed,'learning_rate':lr,'fit_status':outer['status'],'observations':[],'whole_process_wall_seconds':outer.get('whole_process_wall_seconds'),'actual_outer_wall_limit_seconds':outer.get('hard_wall_seconds'),'fit_cpu_seconds':None,'adequate':False,'selected_quality':None}
        try:
            command_rows=[r for r in commands if r['name']==name]
            if outer['status']=='not_started_whole_budget':
                assert len(command_rows)==1 and not root.exists();row['audit_status']='retained_not_started';records.append(row);curves.append(fit_curve);continue
            assert len(command_rows)==2 and command_rows[0]['status']=='started' and command_rows[-1]['status']==outer['status']
            for suffix in ['stdout','stderr']:
                p=campaign/f'{name}.{suffix}';assert sha(p)==outer[suffix+'_sha256'];inputs[str(p)]=sha(p)
            assert math.isfinite(outer['hard_wall_seconds']) and 0 < outer['hard_wall_seconds'] <= plan['per_fit_wall_seconds']
            fit_plan=bound(root/'plan.json');assert (fit_plan['arm'],fit_plan['seed'],fit_plan['learning_rate'])==(arm,seed,lr)
            assert fit_plan['manifest_sha256']==plan['manifest_sha256'] and not fit_plan['train_shared'] and fit_plan['learn_core_adapter']
            for k in ['width','batch_size','min_epochs','max_epochs','patience','memorization_updates','memorization_check_every','plateau_delta','quality_threshold','threads']:
                assert fit_plan[k]==plan[k]
            assert fit_plan['micro_batch_size']==plan['micro_batch_sizes'].get(arm)
            assert fit_plan['wall_seconds']==max(1,outer['hard_wall_seconds']-30)
            assert fit_plan['hcsn_grid_json']==(plan['hcsn_grid'] if arm=='hcsn' else None)
            assert fit_plan['plif_config_json']==(plan['plif_configuration'] if arm=='snn_plif' else None)
            fit=bound(root/'result.json') if (root/'result.json').exists() else None
            if fit:
                row['required_artifact_check']=require_retained_artifacts(root,fit,fit_plan)
                assert sha(root/'result.json')==outer['result_sha256']
                assert fit['confirmation_access'] is False and fit['scientific_admission']=='HOLD' and fit['resume_supported'] is False
                assert fit['plan_sha256']==sha(root/'plan.json') and fit['source_unchanged'] and fit['source_before']==fit['source_after']
                for path,digest in fit['source_before'].items():assert sha(path)==digest;sources_checked[path]=digest
                assert sha(root/'events.jsonl')==fit['events_sha256']
                row.update(original_fit_status=fit['status'],original_adequacy=fit['training_adequacy_established'],original_stop_reason=fit.get('stop_reason'))
                row['adequacy_check']=validate_adequacy(fit,fit_plan)
                fit_curve.update(fit_status=fit['status'],fit_cpu_seconds=fit['cpu_seconds'],adequate=fit['training_adequacy_established'])
            row['files']={p.name:artifact(p) for p in root.iterdir() if p.is_file()}
            for filename,a in row['files'].items():inputs[str(root/filename)]=a['sha256']
            journal,partial_tail=read_journal(root/'events.jsonl',allow_partial=not fit or fit['status']!='completed_development')
            row['journal'],observed=check_journal(journal,fit,training_events,fit_plan);row['journal']['partial_final_json_line']=partial_tail
            fit_curve['observations']=[{'name':name,'arm':arm,'seed':seed,'learning_rate':lr,'epoch':p['epoch'],
                'quality':p['development']['macro_f1_11_classes'],'process_wall_seconds':p['process_wall_seconds'],'process_cpu_seconds':p['process_cpu_seconds']} for p in observed]
            checkpoints={};cfg=None;initial=None
            for filename,key in [('initial.pt','initialization_sha256'),('memorization.pt','memorization_checkpoint_sha256'),('best.pt','best_checkpoint_sha256'),('last.pt','last_checkpoint_sha256'),('interrupted.pt','interrupted_checkpoint_sha256')]:
                path=root/filename
                if not path.exists():continue
                if fit and key in fit:assert sha(path)==fit[key]
                value=torch.load(path,map_location='cpu',weights_only=True)
                assert set(['model','model_configuration'])<=set(value)
                if cfg is None:cfg=value['model_configuration']
                assert value['model_configuration']==cfg
                validate_configuration(cfg,fit_plan)
                if fit:assert cfg==fit['model_configuration']
                assert cfg['arm']==arm and cfg['seed']==seed and cfg['width']==plan['width'] and cfg['freeze_shared'] and cfg['learn_core_adapter']
                assert cfg['hcsn_grid']==fit_plan['hcsn_grid_json'] and cfg['plif_configuration']==fit_plan['plif_config_json']
                assert cfg['cache_frozen_tables']==fit_plan['cache_frozen_tables']
                if filename=='initial.pt':initial=value['model']
                if initial is not None:
                    common=[k for k in initial if k.startswith(('frontend.','head.'))]
                    assert all(torch.equal(initial[k],value['model'][k]) for k in common)
                if filename in ['best.pt','last.pt']:
                    expected_epoch=fit['best_epoch'] if filename=='best.pt' and fit else value['epochs_completed']
                    if filename=='last.pt' and fit:expected_epoch=len(fit['epochs'])
                    assert value['epochs_completed']==expected_epoch and value['main_updates']==expected_epoch*math.ceil(len(training_events)/plan['batch_size'])
                    assert value['data_manifest_sha256']==plan['manifest_sha256']
                    assert all(float(v['step'])==value['main_updates'] for v in value['optimizer']['state'].values())
                if filename=='memorization.pt' and fit:
                    assert value['main_updates']==0 and all(float(v['step'])==fit['diagnostic_updates'] for v in value['optimizer']['state'].values())
                checkpoints[filename]=value
            if initial is not None:
                common={p:tensor_digest(initial,p+'.') for p in ['frontend','head','temporal_adapter']}
                if fit:
                    assert common['frontend']==fit['initial_frontend_sha256'] and common['head']==fit['initial_head_sha256']
                    assert common['temporal_adapter']==fit['initial_temporal_adapter_sha256']
                assert torch.equal(initial['temporal_adapter.weight'],torch.eye(plan['width'],dtype=torch.float64)) and torch.count_nonzero(initial['temporal_adapter.bias'])==0
                if seed in shared_by_seed:assert common==shared_by_seed[seed]
                else:shared_by_seed[seed]=common
                ident=tensor_digest(initial)
                if (arm,seed) in initial_by_arm_seed:assert initial_by_arm_seed[(arm,seed)]==ident
                else:initial_by_arm_seed[(arm,seed)]=ident
                row.update(shared_initial_hashes=common,all_available_checkpoints_shared_tensors_unchanged=True,
                    initial_tensor_sha256=ident,initial_dtype_counts=dict(Counter(str(t.dtype) for t in initial.values())))
            if arm=='hcsn' and (root/'training-domain.jsonl').exists():
                try:row['training_trace']=audit_trace(root/'training-domain.jsonl',fit_plan,episodes,initial,sources_checked,row['journal']['main_updates'],source)
                except Exception:
                    row['training_trace']={'integrity_verified':False,'error':traceback.format_exc(),'scientific_admission':'HOLD'}
                    if fit and fit['status']=='completed_development':raise
            best=checkpoints.get('best.pt');expected_metrics=None;stored=None
            if (root/'development_logits.pt').exists():
                stored=torch.load(root/'development_logits.pt',map_location='cpu',weights_only=True)
                assert stored['episode_ids']==dev_ids and np.array_equal(stored['labels'].numpy(),labels)
                logits=stored['logits'].numpy();assert logits.shape==(len(labels),11) and np.isfinite(logits).all()
                actual=independent_metrics(logits,labels);expected_metrics=fit['selected_development']
                row['metric_absolute_differences']=metric_differences(actual,expected_metrics);row['independent_metrics']=actual
                row['strict_best_metric_absolute_differences']=selected_best_metric_differences(actual,fit,best['epochs_completed'])
                fit_curve['selected_quality']=actual['macro_f1_11_classes'];fit_curve['selected_quality_scope']='saved selected development logits independently recomputed'
            elif best and fit and fit['epochs']:
                expected_metrics=fit['epochs'][best['epochs_completed']-1]['development']
                fit_curve['selected_quality']=expected_metrics['macro_f1_11_classes'];fit_curve['selected_quality_scope']='best retained complete epoch on original journal; final selected logits absent after interrupted attempt'
            if best and expected_metrics and arm not in fresh_arms:
                clock=time.monotonic();logits=fresh_forward(source,cfg,best['model'],dev,fit_plan['batch_size'])
                actual=independent_metrics(logits.numpy(),labels);metric_differences(actual,expected_metrics)
                error=float((logits-stored['logits']).abs().max()) if stored else None
                if error is not None:assert error<=2e-12
                path=out/f'fresh-forward-{arm}.pt';torch.save({'logits':logits,'labels':torch.from_numpy(labels),'episode_ids':dev_ids,'model_configuration':cfg},path)
                row.update(fresh_forward=True,maximum_logit_absolute_difference=error,fresh_forward_file=path.name,fresh_forward_sha256=sha(path),fresh_forward_seconds=time.monotonic()-clock,fresh_forward_batch_size=fit_plan['batch_size'],fresh_forward_gradients=False)
                fresh_arms.add(arm)
            row['audit_status']='passed_completed_fit' if fit and fit['status']=='completed_development' else 'retained_original_incomplete_or_failed_attempt'
        except Exception:row.update(audit_status='audit_failed',error=traceback.format_exc())
        records.append(row);curves.append(fit_curve)
        print(json.dumps({k:row.get(k) for k in ['name','audit_status','original_adequacy','fresh_forward']}),flush=True)
    source_unchanged=all(sha(p)==digest for p,digest in sources_checked.items())
    inputs_unchanged=all(Path(p).is_file() and sha(p)==digest for p,digest in inputs.items())
    per_fit=[per_fit_curve(f,budgets,plan['quality_threshold']) for f in curves]
    aggregate=None
    if not args.preflight_fit and all(r['audit_status']!='audit_failed' for r in records):
        assert abs(sum(f.get('whole_process_wall_seconds') or 0. for f in curves)-campaign_result['sum_attempt_wall_seconds'])<1e-7
        aggregate=aggregate_curves(curves,roster,plan['arms'],plan['seeds'],plan['learning_rates'],budgets,plan['quality_threshold'],campaign_result['children_cpu_seconds'])
    own_sources_unchanged=all(sha(here/name)==digest for name,digest in own_hashes.items())
    passed=source_unchanged and inputs_unchanged and own_sources_unchanged and all(r['audit_status']!='audit_failed' for r in records)
    report={'schema':'hcsn-independent-fresh42-audit-v2','created_utc':datetime.now(timezone.utc).isoformat(),
        'mode':'completed-fit-preflight' if args.preflight_fit else 'complete-roster-audit',
        'passed':passed,'expected_full_roster':42,'audited_attempts':len(records),'scientific_admission':'HOLD',
        'confirmation_access':False,'source_capsule_sha256':EXPECTED_CAPSULE,'plan_sha256':EXPECTED_PLAN,
        'review_source_sha256':own_hashes,'review_sources_unchanged':own_sources_unchanged,'candidate_source':str(source),'campaign':str(campaign),
        'records':records,'per_fit_resource_curves':per_fit,'aggregate_opportunity_curves':aggregate,
        'actual_outer_wall_limit_coverage':[{'budget':cut,'fits_with_sufficient_declared_wall_limit':[f['name'] for f in curves if f.get('actual_outer_wall_limit_seconds') is not None and f['actual_outer_wall_limit_seconds']>=cut], 'fits_with_shorter_or_unknown_wall_limit':[f['name'] for f in curves if f.get('actual_outer_wall_limit_seconds') is None or f['actual_outer_wall_limit_seconds']<cut]} for cut in budgets['process_wall_seconds']],
        'extra_tuning_and_qualification_overhead':load(out/'extra-overheads.json'),
        'source_unchanged':source_unchanged,'inputs_unchanged':inputs_unchanged,'source_sha256':sources_checked,'input_sha256':inputs,
        'live_context_snapshot':live_context,'fresh_forward_arms':sorted(fresh_arms),'shared_by_seed':shared_by_seed,
        'numpy':np.__version__,'torch':torch.__version__,'review_wall_seconds':time.monotonic()-started,'review_cpu_seconds':time.process_time()-cpu_started,
        'energy_joules':None,'scope':'Independent saved-logit metrics and source/model/data/update identities; representative fresh forward per available core. Epoch curves use original complete evaluation journals. Development tuning envelopes, adequacy, numerical coverage and scientific benefit are separate.'}
    (out/'RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+'\n')
    summary={'schema':report['schema'],'mode':report['mode'],'passed':passed,'audited_attempts':len(records),
        'audit_status_counts':dict(Counter(r['audit_status'] for r in records)),
        'original_adequacy_passes':sum(r.get('original_adequacy',False) for r in records),
        'fresh_forward_arms':sorted(fresh_arms),'source_unchanged':source_unchanged,'inputs_unchanged':inputs_unchanged,
        'scientific_admission':'HOLD','result_sha256':sha(out/'RESULT.json'),'review_wall_seconds':report['review_wall_seconds']}
    (out/'SUMMARY.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    files={str(p.relative_to(out)):artifact(p) for p in out.rglob('*') if p.is_file()}
    (out/'MANIFEST.json').write_text(json.dumps({'files':files,'scope':report['scope']},indent=2,sort_keys=True)+'\n')
    archive=Path(str(out)+'.zip')
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as zipped:
        for p in sorted(out.rglob('*')):
            if p.is_file():zipped.write(p,str(p.relative_to(out)))
    with ZipFile(archive) as zipped:assert zipped.testzip() is None and len(zipped.namelist())==len(set(zipped.namelist()))
    (out/'ARCHIVE.json').write_text(json.dumps({'path':str(archive),**artifact(archive),'manifest_sha256':sha(out/'MANIFEST.json')},indent=2)+'\n')
    print(json.dumps(summary),flush=True)
    return 0 if passed else 1


if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception:
        error=traceback.format_exc()
        if AUDIT_OUTPUT is not None:
            path=AUDIT_OUTPUT/'ERROR.json'
            if not path.exists():path.write_text(json.dumps({'schema':'fresh42-audit-global-error-v1','error':error,'source_sha256':sha(Path(__file__)),'scientific_admission':'HOLD'},indent=2)+'\n')
        print(error,file=sys.stderr,flush=True)
        raise SystemExit(2)
