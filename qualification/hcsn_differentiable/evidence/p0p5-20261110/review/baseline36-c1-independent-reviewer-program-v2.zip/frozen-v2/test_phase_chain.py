import copy
import random
import unittest

from audit_phase_chain import (audit_phase_chain, check_first_continued_order,
                               epoch_state, validate_parent_for_c1, validate_phase_roster)


def fixture(improve=False, memorization=True):
    plan = {"arm": "gru", "max_epochs": 100, "min_epochs": 30, "patience": 10,
            "plateau_delta": .002, "quality_threshold": .30, "train_shared": False,
            "learn_core_adapter": True}
    scores = [.1 + .003 * i for i in range(1, 92)]
    scores += [scores[-1] - .001] * 9
    epochs = [{"epoch": i, "complete": True, "development": {"macro_f1_11_classes": q},
               "process_wall_seconds": i * 10., "process_cpu_seconds": i * 8.}
              for i, q in enumerate(scores, 1)]
    first = next(row for row in epochs if row["development"]["macro_f1_11_classes"] >= .30)
    parent = {"status": "completed_development", "stop_reason": "epoch_cap_not_convergence",
              "source_unchanged": True, "common_weights_unchanged": True,
              "source_before": {"original.py": "b" * 64}, "source_after": {"original.py": "b" * 64},
              "epochs": epochs, "best_epoch": 91, "main_updates": 1200,
              "best_checkpoint_sha256": "a" * 64, "memorization": {"passed": memorization, "updates": 768},
              "model_configuration": {"arm": "gru", "width": 16}, "cpu_seconds": 750.,
              "process_time_to_quality_seconds": first["process_wall_seconds"]}
    outer = {"name": "gru-s101-lr0.001", "status": "completed", "returncode": 0,
             "fit_status": "completed_development", "source_unchanged": True,
             "common_weights_unchanged": True, "result_sha256": "c" * 64,
             "hard_wall_seconds": 14000., "whole_process_wall_seconds": 1200.}
    child_scores = [scores[90] + .01] * 11 if improve else [scores[-1]]
    rows = [{"epoch": 100+i, "complete": True, "development": {"macro_f1_11_classes": q},
             "phase_process_wall_seconds": i*10., "cumulative_process_wall_seconds": 1200+i*10.,
             "phase_full_process_cpu_seconds": i*9.} for i, q in enumerate(child_scores, 1)]
    child = {"status": "completed_development", "stop_reason": "development_plateau",
             "parent_report_sha256": outer["result_sha256"], "parent_source_sha256": parent["source_before"],
             "model_configuration": parent["model_configuration"], "memorization": parent["memorization"],
             "source_unchanged": True, "common_weights_unchanged": True,
             "source_before": {"continued.py": "e" * 64}, "source_after": {"continued.py": "e" * 64},
             "scientific_admission": "HOLD", "confirmation_access": False,
             "parent_complete_epochs": 100, "cumulative_epochs_completed": 100+len(rows), "epochs": rows,
             "best_epoch": 101 if improve else 91, "main_updates": 1200+len(rows)*12,
             "inherited_best_checkpoint_sha256": parent["best_checkpoint_sha256"],
             "best_checkpoint_sha256": "d"*64 if improve else parent["best_checkpoint_sha256"],
             "selected_development": {"macro_f1_11_classes": child_scores[0] if improve else scores[90]},
             "training_adequacy_established": memorization,
             "parent_whole_process_wall_seconds": 1200., "parent_recorded_fit_cpu_seconds": 750.,
             "parent_full_process_cpu_seconds": None, "phase_process_wall_seconds": len(rows)*10.+5,
             "phase_full_process_cpu_seconds": len(rows)*9.+5,
             "first_observed_quality_crossing_cumulative_wall_seconds": parent["process_time_to_quality_seconds"]}
    child_outer = {"name": outer["name"], "hard_remaining_wall_seconds": 12800.,
                   "whole_process_wall_seconds": len(rows)*10.+10,
                   "cumulative_outer_wall_seconds": 1200+len(rows)*10.+10}
    child_plan = {"parent_plan": plan, "parent_outer_record": outer, "total_wall_seconds": 14000.,
                  "max_epochs": 400, "new_learning_rate_or_diagnostic": False}
    return parent, outer, plan, child, child_outer, child_plan


class PhaseChainTests(unittest.TestCase):
    def test_actual_shortened_ceiling_and_full_parent_cost_are_preserved(self):
        values = fixture()
        result = audit_phase_chain(*values, updates_per_epoch=12)
        self.assertEqual(result["charged_chain_outer_wall_seconds"], 1220.)
        self.assertEqual(result["actual_parent_outer_wall_ceiling_seconds"], 14000.)
        self.assertEqual(result["observed_points"][-1]["cumulative_process_wall_seconds"], 1210.)
        bad = copy.deepcopy(values)
        bad[4]["hard_remaining_wall_seconds"] = 14400-1200
        with self.assertRaises(ValueError):
            audit_phase_chain(*bad, updates_per_epoch=12)
        bad = copy.deepcopy(values)
        bad[3]["epochs"][0]["cumulative_process_wall_seconds"] = 1010.
        with self.assertRaises(ValueError):
            audit_phase_chain(*bad, updates_per_epoch=12)

    def test_inherited_stale_count_stops_next_epoch_without_replacing_best(self):
        values = fixture()
        result = audit_phase_chain(*values, updates_per_epoch=12)
        self.assertEqual(result["inherited_plateau_state"]["stale"], 9)
        self.assertEqual(result["combined_state"]["first_plateau_epoch"], 101)
        self.assertEqual(result["combined_state"]["best_epoch"], 91)
        values[3]["best_checkpoint_sha256"] = "f"*64
        with self.assertRaises(ValueError):
            audit_phase_chain(*values, updates_per_epoch=12)

    def test_strict_improvement_resets_plateau_but_ties_keep_first_best(self):
        values = fixture(improve=True)
        result = audit_phase_chain(*values, updates_per_epoch=12)
        self.assertEqual(result["combined_state"]["best_epoch"], 101)
        self.assertEqual(result["combined_state"]["first_plateau_epoch"], 111)
        values[3]["best_epoch"] = 111
        with self.assertRaises(ValueError):
            audit_phase_chain(*values, updates_per_epoch=12)

    def test_memorization_failure_cannot_be_repaired_by_main_training(self):
        values = fixture(memorization=False)
        self.assertFalse(audit_phase_chain(*values, updates_per_epoch=12)["derived_chain_adequacy"])
        values[3]["training_adequacy_established"] = True
        with self.assertRaises(ValueError):
            audit_phase_chain(*values, updates_per_epoch=12)

    def test_c1_cpu_is_a_lower_bound_not_parent_fit_delta_sum(self):
        result = audit_phase_chain(*fixture(), updates_per_epoch=12)
        last = result["observed_points"][-1]
        self.assertEqual(last["cumulative_cpu_lower_seconds"], 809.)
        self.assertIsNone(last["cumulative_cpu_upper_seconds"])
        self.assertIsNone(result["cumulative_full_process_cpu_seconds"])
        self.assertEqual(result["first_observed_quality_crossing"]["phase"], "parent")

    def test_noncap_incomplete_and_hcsn_parents_are_rejected(self):
        for key, value in [("status", "budget_exhausted"), ("stop_reason", "development_plateau")]:
            values = fixture(); values[0][key] = value
            with self.assertRaises(ValueError):
                validate_parent_for_c1(*values[:3])
        values = fixture(); values[0]["epochs"].pop()
        with self.assertRaises(ValueError):
            validate_parent_for_c1(*values[:3])
        values = fixture(); values[2]["arm"] = "hcsn"
        with self.assertRaises(ValueError):
            validate_parent_for_c1(*values[:3])

    def test_duplicate_branch_and_noneligible_parent_rejected(self):
        roster = ["gru-s101-lr0.001", "cfc-s101-lr0.001", "hcsn-s101-lr0.001"]
        validate_phase_roster(roster, roster[:1], roster[:1])
        for child in [[roster[0], roster[0]], [roster[1]], [roster[2]]]:
            with self.assertRaises(ValueError):
                validate_phase_roster(roster, roster[:1], child)

    def test_sample_order_uses_parent_rng_and_no_diagnostic_is_replayed(self):
        rng = random.Random(101); old = list(range(30)); rng.shuffle(old)
        last = {"epochs_completed": 100, "order_rng": rng.getstate()}
        ids = ["A01-"+str(i) for i in range(30)]
        next_order = list(range(30)); rng.shuffle(next_order)
        events = [{"kind": "epoch_started", "epoch": 101, "episode_order": [ids[i] for i in next_order]}]
        check_first_continued_order(last, events, ids)
        with self.assertRaises(ValueError):
            check_first_continued_order(last, events + [{"kind": "update_started", "phase": "diagnostic"}], ids)
        events[0]["episode_order"] = ids
        with self.assertRaises(ValueError):
            check_first_continued_order(last, events, ids)

    def test_optimizer_counter_reset_and_constructor_change_rejected(self):
        values = fixture(); values[3]["main_updates"] = 12
        with self.assertRaises(ValueError):
            audit_phase_chain(*values, updates_per_epoch=12)
        values = fixture(); values[3]["model_configuration"] = {"arm": "gru", "width": 32}
        with self.assertRaises(ValueError):
            audit_phase_chain(*values, updates_per_epoch=12)


if __name__ == "__main__":
    unittest.main()
