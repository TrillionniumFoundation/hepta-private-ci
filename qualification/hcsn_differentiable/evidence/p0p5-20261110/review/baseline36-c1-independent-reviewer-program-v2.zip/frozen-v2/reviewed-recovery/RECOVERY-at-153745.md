# HCSN recovery checkpoint — 10 November 2026

Recorded at 2026-11-10 15:37:45 UTC. This is an operational checkpoint for the P0–P5 research work. It does not replace raw experiment logs, grant training-domain admission, or claim a completed comparison.

## What is confirmed remotely

The verified source stack reaches commit `3e49eda398778220fc45604908aaedb9bca9f1a0`. Its development PRs remain draft. The subsequent local v8 commit is `6d18f16050dabab063a324087a7b4e00618bd1bb`; the intended remote v8 branch returned HTTP 404 during the latest check, so its publication is unconfirmed.

GitHub release `440410488`, tag `hcsn-research-20261110-c385`, remains **draft, unpublished, and prerelease**. The repository itself is public. Sixteen assets were visible to the authenticated API. The [observation record](outage-observation-v1.json) preserves their identities and the CI observations.

Four server-side asset identities were compared with earlier local size/SHA256 receipts and matched:

| Archive | Bytes | SHA256 |
| --- | ---: | --- |
| P1 numerical evidence v2 | 2,199,349 | `a1a32db092bce32db2d5e75804cbca316d4bab02080cc57ace5f6490390c0b79` |
| Dependency/runtime evidence | 209,485 | `b2fa90124835a0c8a1d5275284b6d4a4dff9e3894aa91f97d98d621e15f55625` |
| Cloud P2 diagnostics v1 | 17,670,639 | `f54585285973bd29c80cbb6fc258bb48513f79e7629296bac3ca2c384a4e76a2` |
| Width-16 v6 numerical audit | 4,460,517 | `b7beeba44a945baf32c4d27efaa214fe35fc1a704a94927b77f583e9e02b5be0` |

This new check compared authenticated API metadata. It did not download those bytes again. The original upload processes' final readback receipts for the last two archives are still unreadable. Do not re-upload an asset merely because its terminal acknowledgement was lost.

## Execution outage and uncertain actions

The cloud execution environment became unavailable. The native control connector reports that its tunnel client has not been seen for 300 seconds. A lost control channel does not establish that a persistent native process stopped or completed.

The fresh 42-fit campaign was dispatched before this outage. The latest readable observation was at **14:59:52 UTC**; all subsequent progress is unknown. Its original persistent job must be inspected before considering any restart.

The following actions have uncertain final acknowledgements and must be reconciled using their original identifiers:

| Action | Original idempotency/request key | Required readback |
| --- | --- | --- |
| Fresh42 launch | `native-fresh42-source-v8-campaign-v2-launch-once` | Original campaign launch receipt, monitor and fit outputs |
| v8 source publication | `hcsn-p2-adequate-runner-publish-c385-v1` | Original publisher receipt and exact remote branch SHA |
| Cloud P2 archive upload | `hcsn-cloud-p2-draft440410488-c385-v1` | Original upload receipt and authenticated archive byte readback |
| Width-16 audit upload | `width16-draft440410488-c385-v1` | Original upload receipt and authenticated archive byte readback |
| Fresh42 independent preflight | `hcsn-fresh42-independent-preflight-c385-v1` | Original read-only preflight output |
| Epoch-cap checkpoint inspection | `native-fresh42-cap-checkpoint-readonly-v1` | Original cap-review report |

The official data ZIP was absent from the observed draft asset list. Its uploader had also been started; absence in this snapshot is not permission to duplicate a possibly pending action.

## Fresh42 comparison contract

Seven temporal cores use the same stored frontend and output head: GRU, CfC, PLIF, event-time LIF, official S4D, Attention, and HCSN. Each core also has the same trainable identity-initialized 16-by-16 linear adapter with bias (272 parameters). Because this adapter makes the effective classifier learnable, the comparison must disclose that effective learned readout.

Each core has seeds 101, 211, and 307, and learning rates 0.001 and 0.003, giving 42 fits. The controller uses at most nine workers: six HCSN fits and at most three baseline fits at a time. Each fit has one CPU thread, an 8 GiB address-space limit, a 6 GiB soft RSS limit, and a four-hour outer wall budget.

The training protocol requires 30 epochs before plateau stopping, permits 100 epochs initially, and uses ten stale epochs with a 0.002 significant-improvement threshold. The strict best checkpoint is tracked independently of that plateau threshold. The development macro-F1 resource-to-quality target is 0.30.

Every core uses the same training-only memorization diagnostic: up to 1,024 updates, checked every 64 updates, with accuracy at least 0.95 and present-class macro-F1 at least 0.90. A diagnostic failure stays in the cost ledger. PLIF uses the preregistered exponential spike trace; HCSN uses an effective batch of 32 via microbatches of eight.

The actual immutable source archive is `training-source-v8.zip`, 121,388 bytes, SHA256 `288283cae2b2cf4e7b68432e040e643a5e1b00a7de961fc848dd5cf20eb46102`. The plan SHA256 is `e13f97aafdaf66548f016f2dcc3a38dd7e641a2ea83d52b8bea89f4c7e0cf114`.

HCSN's scientific and complete training-domain numerical status remain HOLD regardless of its training accuracy. Earlier two-update numerical probes do not qualify final trained checkpoints.

## Exact continuation is implemented and tested, not dispatched

Some baseline fits were observed to reach the original 100-epoch cap while still improving. Their cap is not a convergence certificate. The proposed C1 phase continues only an original completed baseline `epoch_cap` fit, retains the same total four-hour budget, and subtracts the parent's complete outer wall time. It does not repeat the diagnostic or add tuning opportunities.

The implementation restores the complete model and construction configuration, optimizer, Torch RNG, sample-order RNG, completed epoch, update count, plateau anchor and stale count. It preserves the prior best checkpoint byte-for-byte until a strict improvement occurs. Source, data, plan and checkpoint identities are checked before creating a new output.

Eleven tests passed across two frozen test executions: ten original tests and a separate Attention test. GRU, PLIF spike trace, a small-grid cached HCSN, official S4D and Attention matched uninterrupted training exactly in the tested full states. These are synthetic-data implementation tests, not evidence of scientific training or a qualified numerical domain.

The validation archive is `hcsn-continuation-validation-20261110.zip`, 305,937 bytes, SHA256 `0cd5d6c99e7c5ccf7d86b8a80f091ed87a435d7408dca9f13bca2b2c115a94d9`. It was verified locally before the cloud outage. A verified remote copy is not yet recorded.

The Attention test itself passed with exit 0. Its evidence wrapper initially misparsed singular `Ran 1 test` as a failure. The original failed wrapper receipt and logs were retained, and a separate read-only reconciliation was generated. No experiment was rerun or original evidence overwritten.

C1 has **not** been launched. After recovery, freeze the tested continuation source, preserve the original v8 snapshot, and launch at most three continuation workers only after all original 36 baseline fits are terminal. Six original HCSN workers may continue within the overall nine-worker ceiling. Continue only complete epoch boundaries, with maximum 400 epochs and the original remaining wall budget. Charge new imports and cold-cache rebuilding to that remaining budget.

## Separate gates and evidence limits

| Gate | Status in this checkpoint | Reason |
| --- | --- | --- |
| Overall CI | Pending | P1 blocking CI was in progress; P2 blocking CI and architecture jobs were queued. Both observed v8-canary runs passed. The connector response covers only the first page of PR-triggered runs. |
| Numerical domain | HOLD | Scoped finite-schedule passes exist, along with pressure-domain and coarse-grid failures. Final trained posteriors have not been independently admitted. |
| Sufficiently trained comparison | Pending | Original 36-fit raw-readout study completed but only 2/36 met its adequacy gate. Fresh42 outcomes and possible C1 phases still require review. |
| Scientific benefit | HOLD | Development selection is not independent confirmation; no claim of superiority or measured energy saving is made. |
| Task-derived free boundary | HOLD | The finite CTMDP/QVI oracle is a small-model fixture, not continuum or neural-mechanism benefit. |
| Scale, mixed precision and deployment | HOLD | These remain conditional on demonstrated benefit. |

The complete result must retain all three seeds; include tuning, diagnostic failures, failed probes and retries in costs; and distinguish outer wall time, full-process CPU time, fit-only CPU time, peak memory and unmeasured energy. Do not sum a fit-only CPU counter as if it included imports. Do not interpolate an unobserved quality crossing.

## Recovery order

1. Inspect the original native campaign and uncertain upload/publication jobs using their original identifiers. Do not start duplicate fits.
2. Recover the exact local working tree and evidence archives. Verify every recorded SHA256 before using an artifact.
3. Finish the original campaign. If needed, deploy the frozen C1 implementation and continue only eligible cap-limited fits under their remaining original budgets.
4. Run the independently frozen reviewer against the actual saved plans, initial/last/best checkpoints, logits, data identities and source snapshots. Include each continuation phase and all cost counters.
5. Audit the selected final HCSN checkpoints and actual posteriors against high-precision finite-schedule, conservation and derivative references. Earlier candidate passes do not transfer automatically.
6. Reconcile the uncommitted CURRENT/evidence assembly. Its working manifest had become stale after `prepared-selection.json` was replaced by its exact ZIP and more files were added; regenerate it, check every link/hash, and preserve the earlier failed assembly review.
7. Publish only verified source/evidence updates as reviewable draft PRs, read their exact branch heads back, and report CI, numerical qualification and scientific benefit separately.

Main was not merged, the release was not published, and no original experiment artifact was overwritten during this checkpoint.
