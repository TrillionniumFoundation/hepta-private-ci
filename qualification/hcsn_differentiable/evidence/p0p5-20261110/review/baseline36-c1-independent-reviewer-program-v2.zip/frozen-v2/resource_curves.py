"""Observed development envelopes with explicit censoring and CPU cost bounds.

No quality interpolation, missing-seed imputation or reconstruction of unknown
per-child CPU totals is performed. All budgets refer to the fresh roster only;
prior tuning/qualification is carried separately by the calling audit.
"""
import math
from statistics import mean, median


def _best(points):
    return max(points, key=lambda p: p['quality']) if points else None


def _summary(point):
    return None if point is None else {k: point[k] for k in ['name', 'arm', 'seed', 'learning_rate', 'epoch', 'quality']}


def per_fit_curve(fit, budgets, threshold):
    points = fit['observations']
    for clock in ['process_wall_seconds', 'process_cpu_seconds']:
        values = [p[clock] for p in points]
        if any(not math.isfinite(x) or x < 0 for x in values) or values != sorted(values):
            raise ValueError('nonmonotonic process observation clock')
    if any(not math.isfinite(p['quality']) or not 0 <= p['quality'] <= 1 for p in points):
        raise ValueError('invalid observed quality')
    first = next((p for p in points if p['quality'] >= threshold), None)
    result = {'name': fit['name'], 'status': fit['fit_status'],
              'adequate': fit.get('adequate', False), 'epochs_observed': len(points),
              'observations': points,
              'first_observed_quality_threshold': threshold,
              'first_observed_crossing': first,
              'crossing_status': 'observed' if first else 'right_censored' if points else 'unobserved',
              'last_completed_evaluation': points[-1] if points else None,
              'whole_process_wall_seconds': fit.get('whole_process_wall_seconds'),
              'actual_outer_wall_limit_seconds': fit.get('actual_outer_wall_limit_seconds'),
              'nominal_outer_wall_limit_seconds': 14400,
              'wall_limit_scope': 'actual per-fit limit may be shorter because the original campaign has a shared 15000-second deadline',
              'recorded_fit_cpu_seconds_excluding_startup': fit.get('fit_cpu_seconds'),
              'whole_child_cpu_seconds': None,
              'whole_child_cpu_identification': 'not recorded per fit; per-epoch process_time is exact process CPU, final fit delta is a different scope',
              'fixed_budgets': {}}
    for clock, cuts in budgets.items():
        result['fixed_budgets'][clock] = []
        for cut in cuts:
            eligible = [p for p in points if p[clock] <= cut]
            best = _best(eligible)
            result['fixed_budgets'][clock].append({'budget':cut,'observed_best':_summary(best),
                'eligible_evaluations':len(eligible),
                'threshold_observed_by_budget':any(p['quality'] >= threshold for p in eligible),
                'missing_evaluation':not eligible,
                'actual_outer_wall_limit_allows_budget':(
                    cut <= fit['actual_outer_wall_limit_seconds']
                    if clock == 'process_wall_seconds' and fit.get('actual_outer_wall_limit_seconds') is not None else None),
                'stopped_before_budget':bool(fit.get('whole_process_wall_seconds') is not None
                    and clock == 'process_wall_seconds' and fit['whole_process_wall_seconds'] < cut),
                'no_interpolation':True})
    return result


def cpu_accounting(fits, campaign_child_cpu):
    """Every child's actual CPU is at least its fit delta and last epoch clock.

    R = campaign waited-child CPU - sum lower bounds. R is shared uncertainty,
    not a separate surcharge to add to every fit. Nested child CPU, startup,
    final evaluation/serialization and failed unobserved work may contribute.
    """
    if not math.isfinite(campaign_child_cpu) or campaign_child_cpu < 0:
        raise ValueError('invalid aggregate child CPU ledger')
    bounds = {}
    for fit in fits:
        epoch_cpu = [p['process_cpu_seconds'] for p in fit['observations']]
        if any(not math.isfinite(v) or v < 0 for v in [fit.get('fit_cpu_seconds') or 0., *epoch_cpu]):
            raise ValueError('invalid per-fit CPU evidence')
        lower = max([fit.get('fit_cpu_seconds') or 0., *epoch_cpu])
        bounds[fit['name']] = lower
    residual = campaign_child_cpu - sum(bounds.values())
    if residual < -1e-5:
        raise ValueError('campaign child CPU is smaller than independent per-fit lower bounds')
    residual = max(0., residual)
    return {'complete_campaign_children_cpu_seconds':campaign_child_cpu,
            'fit_cpu_lower_bounds':bounds, 'sum_fit_cpu_lower_bounds':sum(bounds.values()),
            'unallocated_cpu_upper_budget':residual,
            'allocation_is_shared_not_per_fit_additive':True,
            'epoch_cpu_scope':'exact process_time observations; waited nested-child CPU is not in this clock',
            'aggregate_child_cpu_scope':'conservative ranges bounded by final waited-child ledger'}


def opportunity_points(roster, fits_by_name, names, cpu_ledger):
    prefix_wall = prefix_cpu_lower = 0.
    previous = []
    rows = []
    for name in roster:
        if name not in names:
            continue
        fit = fits_by_name[name]
        for p in fit['observations']:
            row = dict(p)
            row['opportunity_process_wall_seconds'] = prefix_wall + p['process_wall_seconds']
            row['opportunity_cpu_lower_seconds'] = prefix_cpu_lower + p['process_cpu_seconds']
            # The first fit has no previous-fit overhead, but nested-child CPU
            # inside its current process is still not identified. Keep the same
            # residual bound for a complete child-opportunity account.
            row['opportunity_cpu_upper_seconds'] = row['opportunity_cpu_lower_seconds'] + cpu_ledger['unallocated_cpu_upper_budget']
            row['previous_attempts_charged'] = list(previous)
            rows.append(row)
        prefix_wall += fit.get('whole_process_wall_seconds') or 0.
        prefix_cpu_lower += cpu_ledger['fit_cpu_lower_bounds'][name]
        previous.append(name)
    return rows, {'attempts_charged':previous, 'process_wall_seconds':prefix_wall,
                  'child_cpu_lower_seconds':prefix_cpu_lower,
                  'child_cpu_upper_seconds':prefix_cpu_lower+cpu_ledger['unallocated_cpu_upper_budget']}


def bounded_envelope(points, cut, threshold, seeds):
    guaranteed = [p for p in points if p['opportunity_cpu_upper_seconds'] <= cut]
    possible = [p for p in points if p['opportunity_cpu_lower_seconds'] <= cut]
    best_g, best_p = _best(guaranteed), _best(possible)
    seed_rows = []
    for seed in seeds:
        g = _best([p for p in guaranteed if p['seed']==seed])
        p = _best([p for p in possible if p['seed']==seed])
        seed_rows.append({'seed':seed,'guaranteed_best':_summary(g),'possible_best':_summary(p)})
    gs=[p['guaranteed_best']['quality'] if p['guaranteed_best'] else None for p in seed_rows]
    ps=[p['possible_best']['quality'] if p['possible_best'] else None for p in seed_rows]
    return {'budget':cut,'guaranteed_observed_best':_summary(best_g),'possible_observed_best':_summary(best_p),
            'quality_threshold_guaranteed':any(p['quality']>=threshold for p in guaranteed),
            'quality_threshold_possible':any(p['quality']>=threshold for p in possible),
            'by_seed':seed_rows,
            'all_seed_median_guaranteed_if_complete':median(gs) if all(v is not None for v in gs) else None,
            'all_seed_median_possible_if_complete':median(ps) if all(v is not None for v in ps) else None,
            'all_seed_guaranteed_reach':all(v is not None and v>=threshold for v in gs),
            'all_seed_possible_reach':all(v is not None and v>=threshold for v in ps),
            'scope':'CPU eligibility may be uncertain because complete per-child CPU was not retained'}


def exact_envelope(points, cut, threshold, seeds):
    eligible=[p for p in points if p['opportunity_process_wall_seconds']<=cut]
    values=[];by_seed=[]
    for seed in seeds:
        best=_best([p for p in eligible if p['seed']==seed])
        by_seed.append({'seed':seed,'observed_best':_summary(best)})
        values.append(best['quality'] if best else None)
    return {'budget':cut,'observed_tuning_envelope_best':_summary(_best(eligible)),
            'eligible_evaluations':len(eligible),'by_seed':by_seed,
            'all_seed_median_if_complete':median(values) if all(v is not None for v in values) else None,
            'observed_seed_count':sum(v is not None for v in values),
            'all_seed_reach':all(v is not None and v>=threshold for v in values),
            'best_seed_is_not_expected_quality':True}


def aggregate_curves(fits, roster, arms, seeds, learning_rates, budgets, threshold, campaign_child_cpu):
    by_name={f['name']:f for f in fits}
    if len(by_name)!=len(fits) or set(roster)!=set(by_name):raise ValueError('roster mismatch')
    ledger=cpu_accounting(fits,campaign_child_cpu)
    result={'budget_scope':'fresh predeclared opportunity roster only; prior tuning/qualification remains separate and historically incomplete',
            'threshold':threshold,'cpu_accounting':ledger,'arms':[]}
    for arm in arms:
        selected=[f for f in fits if f['arm']==arm]
        points,cost=opportunity_points(roster,by_name,{f['name'] for f in selected},ledger)
        wall=[exact_envelope(points,b,threshold,seeds) for b in budgets['process_wall_seconds']]
        cpu=[bounded_envelope(points,b,threshold,seeds) for b in budgets['process_cpu_seconds']]
        first=next((p for p in points if p['quality']>=threshold),None)
        seed_opportunities=[]
        for seed in seeds:
            subset={f['name'] for f in selected if f['seed']==seed}
            rows,cost_seed=opportunity_points(roster,by_name,subset,ledger)
            crossing=next((p for p in rows if p['quality']>=threshold),None)
            seed_opportunities.append({'seed':seed,'cost':cost_seed,'first_observed_crossing':crossing,
                'status':'observed' if crossing else 'right_censored' if rows else 'unobserved',
                'wall_budgets':[exact_envelope(rows,b,threshold,[seed]) for b in budgets['process_wall_seconds']],
                'cpu_budget_bounds':[bounded_envelope(rows,b,threshold,[seed]) for b in budgets['process_cpu_seconds']]})
        crossings=[s['first_observed_crossing'] for s in seed_opportunities]
        all_crossed=all(p is not None for p in crossings)
        lr_rows=[]
        for lr in learning_rates:
            group=[f for f in selected if f['learning_rate']==lr]
            vals={f['seed']:f.get('selected_quality') for f in group}
            complete=set(vals)==set(seeds) and all(v is not None for v in vals.values())
            lr_rows.append({'learning_rate':lr,'all_seed_values':[{'seed':s,'quality':vals.get(s)} for s in seeds],
                'mean_all_seeds_if_complete':mean(vals.values()) if complete else None,
                'median_all_seeds_if_complete':median(vals.values()) if complete else None,
                'all_seed_adequate':len(group)==len(seeds) and all(f.get('adequate',False) for f in group),
                'all_outcomes_retained':True})
        eligible=[r for r in lr_rows if r['mean_all_seeds_if_complete'] is not None]
        selected_lr=max(eligible,key=lambda r:r['mean_all_seeds_if_complete'])['learning_rate'] if len(eligible)==len(learning_rates) else None
        result['arms'].append({'arm':arm,'opportunity_cost':cost,'ordered_points':points,
            'wall_budget_envelopes':wall,'cpu_budget_envelope_bounds':cpu,
            'first_observed_opportunity_crossing':first,
            'crossing_status':'observed' if first else 'right_censored' if points else 'unobserved',
            'per_seed_lr_opportunities':seed_opportunities,
            'all_seeds_observed_crossing':all_crossed,
            'median_all_seed_first_crossing_wall_if_all_observed':median(p['opportunity_process_wall_seconds'] for p in crossings) if all_crossed else None,
            'median_all_seed_first_crossing_cpu_lower_if_all_observed':median(p['opportunity_cpu_lower_seconds'] for p in crossings) if all_crossed else None,
            'median_all_seed_first_crossing_cpu_upper_if_all_observed':median(p['opportunity_cpu_upper_seconds'] for p in crossings) if all_crossed else None,
            'learning_rate_selection':{'rows':lr_rows,'selected_learning_rate':selected_lr,
                'rule':'maximum mean selected development macro-F1 across all three seeds, only when both complete LR rosters have metric observations; no missing-seed averaging',
                'scientific_admission':'HOLD'}})
    return result
