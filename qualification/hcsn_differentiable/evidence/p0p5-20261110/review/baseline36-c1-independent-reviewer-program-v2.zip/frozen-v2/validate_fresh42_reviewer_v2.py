"""Freeze checks of independent reviewer preparation; never runs training."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import time
from zipfile import ZipFile, ZIP_DEFLATED


BASE = Path('/workspace/scratch/c385a7439f8e')
ROOT = BASE / 'fresh42-review-prep-v2'
PYTHON = BASE / 'hcsn-env/bin/python'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def files():
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(ROOT.glob('*.py'))}


def artifact(path):
    return {'bytes': path.stat().st_size, 'sha256': sha(path)}


def main():
    out = ROOT / 'validation'
    out.mkdir(exist_ok=False)
    before = files()
    for path in ROOT.glob('*.py'):
        compile(path.read_text(), str(path), 'exec')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1',
               MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='')
    commands = [
        ('unit-tests', [str(PYTHON), '-B', '-m', 'unittest', 'discover', '-s', str(ROOT), '-p', 'test_*.py', '-v'], 0),
        ('entrypoint-help', [str(PYTHON), '-B', str(ROOT/'review_campaign_fresh42.py'), '--help'], 0),
        ('reject-disabled-assertions', [str(PYTHON), '-B', '-O', str(ROOT/'review_campaign_fresh42.py'), '--help'], 1),
    ]
    executions = []
    for name, argv, expected in commands:
        wall = time.monotonic()
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        child_cpu = usage.ru_utime + usage.ru_stime
        with (out/(name+'.stdout')).open('xb') as stdout, (out/(name+'.stderr')).open('xb') as stderr:
            result = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, timeout=60, check=False)
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        executions.append({'name': name, 'argv': argv, 'returncode': result.returncode,
                           'expected_returncode': expected, 'passed': result.returncode == expected,
                           'whole_process_wall_seconds': time.monotonic()-wall,
                           'children_cpu_seconds': usage.ru_utime+usage.ru_stime-child_cpu,
                           'stdout': artifact(out/(name+'.stdout')), 'stderr': artifact(out/(name+'.stderr'))})
    text = (out/'unit-tests.stderr').read_text()
    match = re.search(r'Ran\s+(\d+)\s+tests?\s+in\s+([0-9.]+)s', text)
    assert match and int(match.group(1)) == 23 and '\nOK\n' in text
    assert 'assertions enabled' in (out/'reject-disabled-assertions.stderr').read_text()
    after = files()
    report = {'schema': 'fresh42-independent-reviewer-preparation-validation-v2',
              'created_utc': datetime.now(timezone.utc).isoformat(),
              'passed': before == after and all(e['passed'] for e in executions),
              'source_before': before, 'source_after': after, 'source_unchanged': before == after,
              'tests': int(match.group(1)), 'unit_test_reported_seconds': float(match.group(2)),
              'executions': executions, 'validation_driver_sha256': sha(__file__),
              'original_fresh42_roster_audited': False, 'native_preflight_status': 'unconfirmed',
              'production_continuation_audited': False, 'training_performed': False,
              'scientific_admission': 'HOLD',
              'scope': 'Reviewer behavior and entrypoint preparation only. C1 logical checks do not replace production source/model/data/checkpoint auditing.'}
    (ROOT/'VALIDATION.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    assert report['passed'], report
    manifest = {'schema': 'fresh42-reviewer-program-v2-files',
                'files': {str(p.relative_to(ROOT)): artifact(p) for p in sorted(ROOT.rglob('*'))
                          if p.is_file() and '__pycache__' not in p.parts and p.name != 'MANIFEST.json'},
                'scope': report['scope'], 'scientific_admission': 'HOLD'}
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest, indent=2, sort_keys=True)+'\n')
    archive = BASE/'fresh42-independent-reviewer-program-v2.zip'
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zipped:
        for name in sorted([*manifest['files'], 'MANIFEST.json']):
            zipped.write(ROOT/name, name)
    with ZipFile(archive) as zipped:
        assert zipped.testzip() is None and len(zipped.namelist()) == len(set(zipped.namelist()))
        for name, identity in manifest['files'].items():
            raw = zipped.read(name)
            assert len(raw) == identity['bytes'] and hashlib.sha256(raw).hexdigest() == identity['sha256']
    receipt = {'archive': str(archive), **artifact(archive), 'members': len(manifest['files'])+1,
               'manifest_sha256': sha(ROOT/'MANIFEST.json'), 'validation_sha256': sha(ROOT/'VALIDATION.json'),
               'passed': True, 'training_performed': False, 'scientific_admission': 'HOLD'}
    (BASE/'fresh42-independent-reviewer-program-v2-RECEIPT.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
