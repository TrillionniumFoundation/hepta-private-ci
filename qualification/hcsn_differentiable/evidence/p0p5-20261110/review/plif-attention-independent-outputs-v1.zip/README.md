# Independent PLIF and Attention review outputs

This archive complements the existing `../p2/plif-analog-diagnostics.zip`. Its original attempts, source capsule and shared metadata cover40 original members. This archive retains35 more original members:33 independent PLIF/Attention review outputs (including each of the four profiler attempts and its own empty stderr), the original combined MANIFEST, and the missing full A01-0 input.

UNION-COVERAGE.json maps every original member to exact bytes and SHA256. Together the two archives reproduce all75 original uncompressed members. The original729786-byte combined ZIP remains unchanged; it was not re-uploaded or claimed to be byte-for-byte reconstructed as a compressed ZIP. No experiment was rerun.

The original package contained one of the32 Attention profiling input episodes. DATA-DEPENDENCIES.json preserves the remaining31 exact episode identities and the complete prepared-data manifest SHA. Those remain dependencies of the wider study data chain; two small archives are not a standalone copy of that dataset.

Run `python verify_union.py verify --input-archive INPUT.zip --review-archive REVIEW.zip`. Optionally pass `--combined-archive ORIGINAL.zip` for direct member-byte equality, or `--restore-dir NEW_DIRECTORY` for a verified member-tree restoration. The verifier checks manifests, CRC, duplicate/unsafe paths and all75 identities.

The evidence still supports only the stated diagnostic/replay and measured CPU operator-path observations. It grants no training adequacy, whole-training numerical qualification, GPU performance, energy saving or scientific benefit.
