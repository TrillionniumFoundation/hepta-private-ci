"""Freeze subset-review adapter checks, without reading production candidates."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import sys
import time
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path('/workspace/scratch/c385a7439f8e/baseline36-c1-reviewer-v1')
PYTHON = Path('/workspace/scratch/c385a7439f8e/hcsn-env/bin/python')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    begun = time.monotonic()
    out = ROOT / 'validation'
    out.mkdir(exist_ok=False)
    (ROOT / 'validation_driver.py').write_bytes(Path(__file__).read_bytes())
    sources = {str(p.relative_to(ROOT)): sha(p) for p in ROOT.rglob('*')
               if p.is_file() and '__pycache__' not in p.parts}
    for path in ROOT.glob('*.py'):
        compile(path.read_text(), str(path), 'exec')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1',
               MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='')
    commands = [
        ('adapter-tests', [str(PYTHON), '-B', '-m', 'unittest', 'discover', '-s', str(ROOT), '-p', 'test_subset_adapters.py', '-v'], 0, 9),
        ('frozen-helper-tests', [str(PYTHON), '-B', '-m', 'unittest', 'discover', '-s', str(ROOT/'frozen-v2'), '-p', 'test_*.py', '-v'], 0, 23),
        ('help', [str(PYTHON), '-B', str(ROOT/'run_subset_review.py'), '--help'], 0, None),
        ('disabled-assertions-rejected', [str(PYTHON), '-B', '-O', str(ROOT/'run_subset_review.py'), '--help'], 1, None),
    ]
    executions = []
    for name, argv, expected, count in commands:
        started = time.monotonic()
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        cpu = usage.ru_utime + usage.ru_stime
        with (out/(name+'.stdout')).open('xb') as stdout, (out/(name+'.stderr')).open('xb') as stderr:
            result = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, timeout=90, check=False)
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        row = {'name': name, 'argv': argv, 'returncode': result.returncode, 'expected_returncode': expected,
               'whole_process_wall_seconds': time.monotonic() - started,
               'waited_children_cpu_seconds': usage.ru_utime + usage.ru_stime - cpu,
               'stdout_sha256': sha(out/(name+'.stdout')), 'stderr_sha256': sha(out/(name+'.stderr')),
               'passed': result.returncode == expected}
        if count:
            text = (out/(name+'.stderr')).read_text()
            match = re.search(r'Ran\s+(\d+)\s+tests?\s+in\s+([0-9.]+)s', text)
            row.update(expected_tests=count, observed_tests=int(match.group(1)) if match else None,
                       unittest_seconds=float(match.group(2)) if match else None)
            row['passed'] &= bool(match and int(match.group(1)) == count and '\nOK\n' in text)
        executions.append(row)
        print(json.dumps(row), flush=True)
    unchanged = all(sha(ROOT/name) == digest for name, digest in sources.items())
    report = {'schema': 'baseline36-C1-subset-review-preparation-v1',
              'created_utc': datetime.now(timezone.utc).isoformat(),
              'source_before': sources, 'source_after': {name: sha(ROOT/name) for name in sources},
              'source_unchanged': unchanged, 'executions': executions,
              'passed': unchanged and all(row['passed'] for row in executions),
              'production_review_executed': False, 'training_performed': False,
              'scientific_admission': 'HOLD', 'energy_joules': None,
              'driver_elapsed_seconds': time.monotonic() - begun,
              'driver_cpu_sample_seconds': time.process_time(), 'python': sys.version}
    (ROOT/'VALIDATION.json').write_text(json.dumps(report, indent=2)+'\n')
    if not report['passed']:
        raise SystemExit(1)
    manifest = {'schema': 'baseline36-C1-subset-review-program-v1',
                'files': {str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                          for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}}
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
    archive = ROOT.parent/'baseline36-c1-independent-reviewer-program-v1.zip'
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zipped:
        for name in sorted([*manifest['files'], 'MANIFEST.json']):
            zipped.write(ROOT/name, name)
    with ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        for name, item in manifest['files'].items():
            raw = zipped.read(name)
            assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
    receipt = {'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive),
               'members': len(manifest['files']) + 1, 'validation_sha256': sha(ROOT/'VALIDATION.json'),
               'production_review_executed': False, 'passed': True}
    (ROOT.parent/'baseline36-c1-reviewer-program-v1-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
