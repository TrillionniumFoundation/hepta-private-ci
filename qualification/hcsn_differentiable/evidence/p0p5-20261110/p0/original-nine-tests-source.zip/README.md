# Exact source listed by the original P0 nine-test receipt

All 24 Python file digests match the original receipt byte-for-byte. Files were recovered from preserved pre-format local copies or pinned git objects; current formatted bytes are used only if they already match the original digest. Original stdout, stderr and durable process status (exit 0, complete, untruncated) are included. No new test was run in packaging.

This is a minimal reconstruction of the entire source set explicitly hashed by the old receipt, not the unlisted contents of the original native workspace. The requested full native capsule remains a separate, currently unconfirmed operation. Dependency binaries are not vendored.

From source/, with Torch 2.8 and mpmath available:

```sh
python -m unittest qualification.hcsn_differentiable.tests.test_semantics qualification.hcsn_differentiable.tests.test_readout_semantics qualification.hcsn_differentiable.tests.test_value -v
```
