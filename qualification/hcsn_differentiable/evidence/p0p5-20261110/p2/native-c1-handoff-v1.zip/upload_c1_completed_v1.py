"""Attach the completed-chain archive to the existing unpublished research draft."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import time
import traceback

BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
OUT = BASE / 'c1-evidence-upload-v1'
REPO = 'TrillionniumFoundation/hepta-private-ci'
RELEASE = 440410488
TAG = 'hcsn-research-20261110-c385'
TARGET = 'd2fd5faaf08f1349d02f10086322b99b3222f2a3'
ARCHIVE_RECEIPT = BASE / 'c1-evidence-archive-v1/ARCHIVE-RECEIPT.json'


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def main():
    started, own_cpu = time.monotonic(), time.process_time()
    OUT.mkdir(exist_ok=False)
    readback = OUT / 'authenticated-readback'
    readback.mkdir()
    report = {'schema': 'hcsn-c1-completed-chain-draft-upload-v1', 'status': 'started',
        'repository': REPO, 'release_id': RELEASE, 'tag': TAG, 'publish_requested': False,
        'overwrite_existing_assets': False, 'repository_visibility': 'public',
        'access_scope': 'unpublished draft; push-permission access', 'scientific_admission': 'HOLD',
        'uploader_sha256': sha(Path(__file__)), 'started_utc': datetime.now(timezone.utc).isoformat(),
        'commands': [], 'assets': [], 'automatic_retry': False}

    def run(label, argv, timeout=120):
        tick = time.monotonic()
        before = resource.getrusage(resource.RUSAGE_CHILDREN)
        row = {'label': label, 'argv': argv}
        output, error = b'', b''
        try:
            result = subprocess.run(argv, capture_output=True, timeout=timeout)
            output, error = result.stdout, result.stderr
            row.update(status='completed', returncode=result.returncode)
            if result.returncode:
                raise RuntimeError(label + ' failed; no blind retry')
            return output
        except subprocess.TimeoutExpired as failure:
            output, error = failure.stdout or b'', failure.stderr or b''
            row['status'] = 'timeout_outcome_unknown'
            raise
        except Exception as failure:
            row.setdefault('status', 'command_exception')
            row['error_type'] = type(failure).__name__
            raise
        finally:
            (OUT / (label + '.stdout')).write_bytes(output)
            (OUT / (label + '.stderr')).write_bytes(error)
            after = resource.getrusage(resource.RUSAGE_CHILDREN)
            row.update(wall_seconds=time.monotonic() - tick,
                children_cpu_seconds=(after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime),
                stdout_sha256=hashlib.sha256(output).hexdigest(), stderr_sha256=hashlib.sha256(error).hexdigest())
            report['commands'].append(row)

    def release(label):
        value = json.loads(run(label, ['/usr/bin/gh', 'api', f'repos/{REPO}/releases/{RELEASE}']))
        if (value['id'] != RELEASE or value['draft'] is not True or value['prerelease'] is not True
                or value['tag_name'] != TAG or value['target_commitish'] != TARGET):
            raise ValueError('research draft identity or publication state changed')
        return value

    def anonymous(label, url):
        status = run(label, ['/usr/bin/curl', '--disable', '--silent', '--show-error', '--location',
            '--max-time', '60', '--output', '/dev/null', '--write-out', '%{http_code}', url], timeout=70).decode().strip()
        probe = {'url': url, 'http_status': status, 'client_authorization_sent': False}
        if status != '404':
            raise ValueError('anonymous unpublished-draft isolation not established: ' + status)
        return probe

    try:
        identity = json.loads(run('repository-check', ['/usr/bin/gh', 'api', f'repos/{REPO}',
            '--jq', '{full_name: .full_name, private: .private}']))
        assert identity == {'full_name': REPO, 'private': False}
        report['repository_readback'] = identity
        current = release('draft-before')
        report['anonymous_release_before'] = anonymous('anonymous-release-before',
            f'https://api.github.com/repos/{REPO}/releases/{RELEASE}')
        archive_receipt = json.loads(ARCHIVE_RECEIPT.read_bytes())
        assert archive_receipt['status'] == 'archive_complete_all_member_hashes_and_crc_verified'
        item = archive_receipt['archive']
        path = Path(item['path'])
        assert path.name == 'hcsn-c1-completed-chains-20261110-v1.zip'
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
        report['archive_receipt_sha256'] = sha(ARCHIVE_RECEIPT)
        matches = [a for a in current['assets'] if a['name'] == path.name]
        disposition = 'existing_asset_reconciled_no_overwrite'
        if not matches:
            run('upload', ['/usr/bin/gh', 'release', 'upload', TAG, str(path), '--repo', REPO], timeout=300)
            disposition = 'uploaded_once'
            current = release('draft-after-upload')
            matches = [a for a in current['assets'] if a['name'] == path.name]
        if len(matches) != 1 or matches[0]['size'] != item['bytes']:
            raise ValueError('asset name or size does not match source archive')
        asset = matches[0]
        row = {'name': path.name, 'asset_id': asset['id'], 'bytes': item['bytes'],
            'sha256': item['sha256'], 'disposition': disposition, 'readback_verified': False,
            'api_url': asset['url'], 'browser_download_url': asset['browser_download_url']}
        report['assets'].append(row)
        run('authenticated-readback', ['/usr/bin/gh', 'release', 'download', TAG, '--repo', REPO,
            '--pattern', path.name, '--dir', str(readback)], timeout=600)
        actual = readback / path.name
        assert actual.stat().st_size == item['bytes'] and sha(actual) == item['sha256']
        row.update(readback_verified=True, authenticated_readback_sha256=sha(actual),
            anonymous_asset_api=anonymous('anonymous-asset-api', asset['url']),
            anonymous_asset_browser=anonymous('anonymous-asset-browser', asset['browser_download_url']))
        release('draft-final')
        report['anonymous_release_after'] = anonymous('anonymous-release-after',
            f'https://api.github.com/repos/{REPO}/releases/{RELEASE}')
        report['status'] = 'uploaded_full_byte_readback_and_unpublished_isolation_verified'
    except Exception:
        report.update(status='failed_or_unknown_no_blind_retry', error=traceback.format_exc())
    finally:
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        report.update(whole_wall_seconds=time.monotonic() - started,
            own_cpu_seconds=time.process_time() - own_cpu,
            children_cpu_seconds=usage.ru_utime + usage.ru_stime,
            finished_utc=datetime.now(timezone.utc).isoformat(),
            cost_scope='uploader main-entry wall and own CPU; child CPU includes every command including failures; these scopes overlap')
        (OUT / 'RESULT.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
        print(json.dumps(report, sort_keys=True), flush=True)
    return 0 if report['status'] == 'uploaded_full_byte_readback_and_unpublished_isolation_verified' else 2


if __name__ == '__main__':
    raise SystemExit(main())
