"""Archive completed C1 chains and their exact parent fits, without changing either."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import resource
import sys
import time
import traceback
import zipfile

BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
C1 = BASE / 'campaign-v2-continuation-c1'
PARENT = BASE / 'campaign-v2'
OUT = BASE / 'c1-evidence-archive-v1'
NAME = 'hcsn-c1-completed-chains-20261110-v1.zip'
REPORT_SHA = 'f09e2d72f9c8c49fc03c0669713faba46cd634fb26185f33f2ae962c0350c894'
DATA_MANIFEST = Path('/home/qian-qi/hepta-hcsn-discriminative-20261109-7e8f70f19cba/execution/data/data-manifest.json')
DATA_SHA = '0eb233da8d0b766c35356ba450d0572f1e6a87a47f1d8a17cd32c2ae6f25a1cb'
JOB = Path('/home/qian-qi/.local/state/hepta-runtime-mac-worker/jobs/1a1c6608a96-5074-e0')


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write(path, data):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(data, sort_keys=True, indent=2) + '\n')


def main():
    started, cpu_started = time.monotonic(), time.process_time()
    OUT.mkdir(exist_ok=False)
    receipt = {'schema': 'hcsn-c1-completed-chain-archive-v1', 'status': 'started',
        'started_utc': datetime.now(timezone.utc).isoformat(),
        'archiver_sha256': sha(Path(__file__)), 'scientific_admission': 'HOLD',
        'independent_audit': 'separate pending process; archive checks are not scientific validation',
        'confirmation_access': False, 'energy_joules': None, 'sources_modified': False,
        'host_nice': os.getpriority(os.PRIO_PROCESS, 0),
        'archive_cost_scope': 'this process from main entry; upstream transfer/RPC and later upload are separate'}
    try:
        if sha(C1 / 'RESULT.json') != REPORT_SHA:
            raise ValueError('completed C1 controller receipt differs')
        report = json.loads((C1 / 'RESULT.json').read_bytes())
        attempts = report['attempts']
        assert report['status'] == 'completed_continuation_roster'
        assert report['original_baselines_terminal'] == 36 and len(attempts) == 7
        assert report['source_unchanged'] and report['attempt_cost_accounting_complete']
        assert report['missing_terminal_attempt_names'] == []
        members = {}

        def add(path, name=None):
            path = Path(path)
            if path.is_symlink() or not path.is_file():
                raise ValueError('not a regular source file: ' + str(path))
            name = name or str(path.relative_to(BASE))
            if name.startswith('/') or '..' in Path(name).parts or '\\' in name:
                raise ValueError('unsafe archive name')
            if name in members and members[name] != path:
                raise ValueError('archive name collision')
            members[name] = path

        def tree(directory):
            if not directory.is_dir():
                raise ValueError('missing completed directory: ' + str(directory))
            for path in sorted(directory.rglob('*')):
                if '__pycache__' in path.parts or '.git' in path.parts:
                    continue
                if path.is_file():
                    add(path)

        tree(C1)
        external = {}
        rows = []
        for row in attempts:
            name = row['name']
            assert name in report['declared_continuation_names'] and row['status'] == 'completed'
            parent, phase = PARENT / name, C1 / name
            for directory, digest in ((parent, row['parent_result_sha256']), (phase, row['result_sha256'])):
                if sha(directory / 'result.json') != digest:
                    raise ValueError('fit report changed: ' + str(directory))
                fit = json.loads((directory / 'result.json').read_bytes())
                assert fit['status'] == 'completed_development'
                assert fit['source_before'] == fit['source_after']
                for checkpoint, field in (('best.pt', 'best_checkpoint_sha256'),
                        ('last.pt', 'last_checkpoint_sha256'), ('memorization.pt', 'memorization_checkpoint_sha256')):
                    if field in fit and sha(directory / checkpoint) != fit[field]:
                        raise ValueError('checkpoint differs: ' + str(directory / checkpoint))
                for original, expected in fit['source_before'].items():
                    path = Path(original)
                    if sha(path) != expected:
                        raise ValueError('actually loaded source changed: ' + original)
                    if path.is_relative_to(BASE):
                        add(path)
                    else:
                        target = 'external-loaded-source/' + expected[:20] + '/' + path.name
                        add(path, target)
                        external[original] = {'archive_path': target, 'sha256': expected}
            parent_record = C1 / 'parent-records' / (name + '.json')
            assert sha(parent_record) == row['parent_outer_record_sha256']
            outer = json.loads(parent_record.read_bytes())
            assert outer['hard_wall_seconds'] == row['original_total_wall_seconds']
            assert 0 < row['original_total_wall_seconds'] <= 14400
            assert row['cumulative_outer_wall_seconds'] <= row['original_total_wall_seconds']
            tree(parent)
            for suffix in ('.stdout', '.stderr'):
                add(PARENT / (name + suffix))
            rows.append({key: row[key] for key in ('name', 'parent_result_sha256', 'result_sha256',
                'parent_outer_record_sha256', 'original_total_wall_seconds', 'parent_outer_wall_seconds',
                'whole_process_wall_seconds', 'cumulative_outer_wall_seconds', 'phase_full_process_cpu_seconds',
                'cumulative_epochs', 'adequate')})
        for directory in ('run-source-v8', 'run-source-c1-v1'):
            tree(BASE / directory)
        for name in ('training-source-v8.zip', 'training-source-c1.zip', 'campaign-v2-plan.json',
                     'native_continuation_controller_v3.py'):
            add(BASE / name)
        assert sha(BASE / 'campaign-v2-plan.json') == report['parent_plan_sha256']
        assert sha(BASE / 'training-source-c1.zip') == report['source_archive_sha256']
        assert sha(BASE / 'native_continuation_controller_v3.py') == report['controller_source_sha256']
        assert sha(DATA_MANIFEST) == DATA_SHA
        add(DATA_MANIFEST, 'data-identity/data-manifest.json')
        for name in ('request.json', 'started.json', 'launch.json', 'child.json', 'exit.json',
                     'exit.witness.json', 'stdout.log', 'stderr.log'):
            add(JOB / name, 'native-c1-job/' + name)
        add(Path(__file__), 'archive-operation/' + Path(__file__).name)
        runtime = {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
            'resolved_executable_sha256': sha(Path(sys.executable).resolve()), 'packages': {}}
        for package in ('torch', 'numpy', 'mpmath', 'ncps', 'spikingjelly', 'einops', 'torchvision'):
            try:
                dist = importlib.metadata.distribution(package)
            except importlib.metadata.PackageNotFoundError:
                runtime['packages'][package] = {'installed': False, 'metadata': 'not present in this interpreter'}
                continue
            record = dist.read_text('RECORD')
            runtime['packages'][package] = {'version': dist.version,
                'RECORD_sha256': hashlib.sha256(record.encode()).hexdigest() if record else None}
            if record:
                path = OUT / (package + '-installed-RECORD.txt')
                with path.open('x') as stream:
                    stream.write(record)
                add(path, 'archive-operation/' + path.name)
        summary = {'schema': 'hcsn-c1-completed-chain-summary-v1', 'rows': rows,
            'controller_result_sha256': REPORT_SHA, 'data_manifest_sha256': DATA_SHA,
            'scope': 'seven completed C1 phases and their exact seven completed parent fits',
            'remaining_original_hcsn': 'not included, not read by this archive operation',
            'scientific_admission': 'HOLD', 'independent_phase_chain_audit': 'separate; not credited here',
            'confirmation_access': False, 'data_reconstruction': 'exact prepared manifest; official data is a separate archive',
            'parent_total_wall_seconds_for_seven': sum(row['parent_outer_wall_seconds'] for row in rows),
            'parent_full_process_cpu': 'unknown per PID; original final fit CPU delta excludes imports',
            'costs': {key: report[key] for key in ('whole_wall_seconds', 'children_cpu_seconds',
                'controller_cpu_seconds', 'sum_attempt_outer_wall_seconds', 'sum_attempt_wrapper_wall_seconds',
                'source_copy_and_hash_seconds', 'wait_for_original_baselines_seconds', 'wall_scope', 'cpu_scope',
                'calendar_scope', 'actual_budget_rule', 'preflight')}}
        for name, value in (('CHAIN-SUMMARY.json', summary), ('EXTERNAL-SOURCE-MAP.json', external),
                            ('RUNTIME-IDENTITY.json', runtime)):
            path = OUT / name
            write(path, value)
            add(path, 'archive-operation/' + name)
        manifest = {name: {'bytes': path.stat().st_size, 'sha256': sha(path), 'original_path': str(path)}
                    for name, path in sorted(members.items())}
        archive_path = OUT / NAME
        with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for name, path in sorted(members.items()):
                archive.write(path, name)
            archive.writestr('MEMBER-MANIFEST.json', json.dumps(manifest, sort_keys=True, indent=2) + '\n')
        with zipfile.ZipFile(archive_path) as archive:
            assert archive.testzip() is None
            assert len(archive.namelist()) == len(manifest) + 1
            for name, expected in manifest.items():
                digest, size = hashlib.sha256(), 0
                with archive.open(name) as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b''):
                        digest.update(block)
                        size += len(block)
                assert digest.hexdigest() == expected['sha256'] and size == expected['bytes']
        changed = [name for name, path in members.items() if sha(path) != manifest[name]['sha256']]
        if changed:
            raise ValueError('source files changed during archive: ' + repr(changed))
        receipt.update(status='archive_complete_all_member_hashes_and_crc_verified',
            archive={'path': str(archive_path), 'name': NAME, 'bytes': archive_path.stat().st_size,
                     'sha256': sha(archive_path), 'members': len(manifest) + 1},
            source_files_unchanged=True, payload_bytes=sum(m['bytes'] for m in manifest.values()),
            controller_result_sha256=REPORT_SHA, archived_phase_chains=len(rows),
            summary_sha256=sha(OUT / 'CHAIN-SUMMARY.json'))
    except Exception:
        receipt.update(status='failed_no_retry_or_deletion', error=traceback.format_exc())
    finally:
        child = resource.getrusage(resource.RUSAGE_CHILDREN)
        receipt.update(whole_wall_seconds=time.monotonic() - started,
            own_cpu_seconds=time.process_time() - cpu_started,
            child_cpu_seconds=child.ru_utime + child.ru_stime,
            peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            finished_utc=datetime.now(timezone.utc).isoformat())
        write(OUT / 'ARCHIVE-RECEIPT.json', receipt)
        print(json.dumps(receipt, sort_keys=True), flush=True)
    return 0 if receipt['status'] == 'archive_complete_all_member_hashes_and_crc_verified' else 2


if __name__ == '__main__':
    raise SystemExit(main())
