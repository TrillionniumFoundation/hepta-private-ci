"""Structural guard tests using the actual frozen v8 tiny HCSN writer.

The data are explicitly synthetic unit fixtures. Metadata-only budget cases
exercise rejection rules; none is an observed native budget outcome. No C2
runner, production snapshot or new scientific training campaign is executed.
"""
import copy
import importlib.util
import json
from pathlib import Path
import random
import sys
import unittest

import torch

from c2_boundary import Ineligible, first_plateau_epoch, plateau_state, terminal_guard, validate_boundary

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL = ROOT / 'c1-local-validation/source/proposals/localization-v3'
sys.path.insert(0, str(ORIGINAL))
spec = importlib.util.spec_from_file_location('exact_c1_test_fixture_for_c2', ORIGINAL / 'test_continuation.py')
fixture_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture_module)
from cores import CoreStudyModel
from capacity import adamw
from hcsn_study_support import batches, backward_effective_batch


class BoundaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture_module.ContinuationTests.setUpClass()
        cls.fixture = fixture_module.ContinuationTests(methodName='test_hcsn_cold_cache_rebuild_preserves_exact_updates')
        cls.fixture.setUp()
        cls.parent, cls.outer_path, cls.report = cls.fixture.run_original(
            cls.fixture.arguments(cls.fixture.root / 'tiny-hcsn', arm='hcsn', max_epochs=2))
        cls.plan = json.loads((cls.parent / 'plan.json').read_bytes())
        cls.data, _, _ = cls.fixture.read_fixture(cls.plan['prepared'], cls.plan['manifest_sha256'])
        cls.initial = torch.load(cls.parent / 'initial.pt', weights_only=False)
        cls.last = torch.load(cls.parent / 'last.pt', weights_only=False)
        cls.best = torch.load(cls.parent / 'best.pt', weights_only=False)
        cls.events = [json.loads(line) for line in (cls.parent / 'events.jsonl').read_text().splitlines()]

    @classmethod
    def tearDownClass(cls):
        cls.fixture.doCleanups()

    def args(self):
        return {'checkpoint': copy.deepcopy(self.last), 'best': copy.deepcopy(self.best),
            'initial': copy.deepcopy(self.initial), 'events': copy.deepcopy(self.events),
            'plan': copy.deepcopy(self.plan), 'episodes': self.data['train'],
            'model_factory': CoreStudyModel, 'optimizer_factory': adamw, 'candidate_origin': 'last.pt'}

    def next_epoch_start(self, args):
        rng = random.Random()
        rng.setstate(args['checkpoint']['order_rng'])
        order = list(range(len(self.data['train'])))
        rng.shuffle(order)
        row = {'kind': 'epoch_started', 'epoch': 3, 'episode_order': [self.data['train'][i]['id'] for i in order]}
        return rng, order, row

    def real_partial_update(self):
        args = self.args()
        state = args['checkpoint']
        model = CoreStudyModel(**state['model_configuration'])
        model.load_state_dict(state['model'])
        optimizer, _ = adamw(model, self.plan['learning_rate'], 0.0)
        # load_state_dict can share moment tensors with the supplied mapping;
        # keep the immutable anchor input separate from the advancing model.
        optimizer.load_state_dict(copy.deepcopy(state['optimizer']))
        torch.set_rng_state(state['torch_rng'])
        rng, order, start = self.next_epoch_start(args)
        ids, x, dt, y = next(batches(self.data['train'], order, self.plan['batch_size']))
        weights = torch.bincount(torch.tensor([y for row in self.data['train'] for y in row['y']]), minlength=11).double().rsqrt()
        weights /= weights.mean()
        model.train()
        optimizer.zero_grad(set_to_none=True)
        receipt = backward_effective_batch(model, x, dt, y, weights, micro_batch_size=self.plan['micro_batch_size'])
        norm = torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
        optimizer.step()
        args['events'] += [start, {'kind': 'update_started', 'phase': 'main', 'episode_ids': ids},
            {'kind': 'optimizer_started', 'phase': 'main'},
            {'kind': 'optimizer_completed', 'phase': 'main', 'number': 7, 'gradient_norm': float(norm), **receipt}]
        partial = {'model': copy.deepcopy(model.state_dict()), 'model_configuration': state['model_configuration'],
            'optimizer': copy.deepcopy(optimizer.state_dict()), 'torch_rng': torch.get_rng_state(),
            'order_rng': rng.getstate(), 'epochs_completed': 2, 'main_updates': 7,
            'data_manifest_sha256': state['data_manifest_sha256']}
        return args, partial

    def test_real_v8_atomic_last_boundary_and_prefix_best_pass(self):
        result = validate_boundary(**self.args())
        self.assertTrue(result['boundary_structurally_consistent'])
        self.assertEqual(result['retained_epochs'], 2)
        self.assertEqual(result['work']['retained_main_updates'], 6)
        self.assertFalse(result['execution_authorized'])

    def test_actual_partial_update_is_counted_then_replayed_from_same_anchor(self):
        args, first = self.real_partial_update()
        result = validate_boundary(**args)
        self.assertEqual(result['work']['completed_updates_after_anchor'], 1)
        self.assertEqual(result['work']['complete_epochs_after_anchor'], 0)
        _, replay = self.real_partial_update()
        self.fixture.assert_nested_equal(first, replay, 'cold-cache one-update replay')

    def test_interrupted_payload_with_partial_step_cannot_be_epoch_boundary(self):
        args, partial = self.real_partial_update()
        args['checkpoint'] = partial
        with self.assertRaises(Ineligible):
            validate_boundary(**args)

    def test_interrupted_filename_origin_rejected_even_if_metadata_looks_complete(self):
        args = self.args()
        args['candidate_origin'] = 'interrupted.pt'
        with self.assertRaises(Ineligible):
            validate_boundary(**args)

    def test_optimizer_started_without_completion_retains_unknown_interval(self):
        args = self.args()
        _, order, start = self.next_epoch_start(args)
        args['events'] += [start,
            {'kind': 'update_started', 'phase': 'main', 'episode_ids': [self.data['train'][i]['id'] for i in order[:2]]},
            {'kind': 'optimizer_started', 'phase': 'main'}]
        result = validate_boundary(**args)
        self.assertEqual(result['work']['inflight_optimizer_updates_unknown_interval'], [0, 1])

    def test_order_rng_tamper_rejected(self):
        args = self.args()
        args['checkpoint']['order_rng'] = random.Random(99).getstate()
        with self.assertRaises(Ineligible):
            validate_boundary(**args)

    def test_declared_episode_order_tamper_rejected(self):
        args = self.args()
        row = next(x for x in args['events'] if x['kind'] == 'epoch_started')
        row['episode_order'].reverse()
        with self.assertRaises(Ineligible):
            validate_boundary(**args)

    def test_frozen_head_tamper_rejected(self):
        args = self.args()
        args['checkpoint']['model']['head.bias'][0] += 0.1
        with self.assertRaises(Ineligible):
            validate_boundary(**args)

    def test_optimizer_age_tamper_rejected(self):
        args = self.args()
        next(iter(args['checkpoint']['optimizer']['state'].values()))['step'] += 1
        with self.assertRaises(Ineligible):
            validate_boundary(**args)

    def test_full_grid_configuration_tamper_rejected(self):
        args = self.args()
        args['checkpoint']['model_configuration']['hcsn_grid']['endpoint'] += 1
        with self.assertRaises(Ineligible):
            validate_boundary(**args)

    def test_best_ahead_of_last_rejected(self):
        args = self.args()
        args['best']['epochs_completed'] = 3
        with self.assertRaises(Ineligible):
            validate_boundary(**args)

    def test_epoch_commit_journal_missing_rejected(self):
        args = self.args()
        args['events'] = [x for x in args['events'] if not (x['kind'] == 'epoch_completed' and x['epoch'] == 2)]
        with self.assertRaises(Ineligible):
            validate_boundary(**args)

    def terminal_metadata_fixture(self):
        # Pure guard input values, explicitly not a real native terminal outcome.
        boundary = validate_boundary(**self.args())
        plan, report = copy.deepcopy(self.plan), copy.deepcopy(self.report)
        report.update(status='budget_exhausted', error='declared resource limit; not convergence',
            wall_seconds=14371.0, peak_rss_bytes=500_000_000, memorization={'passed': True})
        report.pop('stop_reason', None)
        outer = {'status': 'failed', 'returncode': 2, 'fit_status': 'budget_exhausted',
            'whole_process_wall_seconds': 14374.0, 'hard_wall_seconds': 14400.0}
        return {'outer': outer, 'report': report, 'plan': plan, 'boundary': boundary}

    def test_entire_parent_wall_is_charged_no_prefix_refund(self):
        result = terminal_guard(**self.terminal_metadata_fixture())
        self.assertEqual(result['remaining_before_c2_setup_and_validation_seconds'], 43200 - 14374)
        self.assertEqual(result['refund_for_discarded_parent_work_seconds'], 0)
        self.assertFalse(result['execution_authorized'])

    def test_rss_or_missing_clock_cannot_be_called_wall_only(self):
        for field, value in [('peak_rss_bytes', 10**12), ('wall_seconds', 1.0)]:
            args = self.terminal_metadata_fixture()
            args['report'][field] = value
            with self.assertRaises(Ineligible):
                terminal_guard(**args)

    def test_hard_kill_without_final_result_is_hold(self):
        args = self.terminal_metadata_fixture()
        args.update(report=None)
        args['outer'].update(status='timed_out', returncode=None)
        with self.assertRaises(Ineligible):
            terminal_guard(**args)

    def test_already_plateau_final_eval_timeout_is_not_more_training(self):
        args = self.terminal_metadata_fixture()
        args['report']['stop_reason'] = 'development_plateau'
        with self.assertRaises(Ineligible):
            terminal_guard(**args)

    def test_recomputed_plateau_guard_independent_of_stop_reason_string(self):
        args = self.terminal_metadata_fixture()
        args['plan'].update(min_epochs=1, patience=1)
        args['boundary']['stopping']['stale_epochs'] = 1
        with self.assertRaises(Ineligible):
            terminal_guard(**args)

    def test_limits_cannot_expand_to_more_than_twelve_hours_or_two_hundred_epochs(self):
        for changes in ({'max_active_wall': 43201}, {'max_epochs': 201}):
            with self.assertRaises(Ineligible):
                terminal_guard(**self.terminal_metadata_fixture(), **changes)

    def test_first_epoch_process_clocks_cannot_be_negative(self):
        for field in ('process_wall_seconds', 'process_cpu_seconds'):
            args = self.args()
            row = next(x for x in args['events'] if x['kind'] == 'epoch_completed')
            row[field] = -0.5
            with self.assertRaises(Ineligible):
                validate_boundary(**args)

    def test_adamw_second_moment_cannot_be_negative(self):
        args = self.args()
        moment = next(iter(args['checkpoint']['optimizer']['state'].values()))['exp_avg_sq']
        moment.reshape(-1)[0] = -1
        with self.assertRaises(Ineligible):
            validate_boundary(**args)

    def test_historical_plateau_is_not_erased_by_a_later_new_high(self):
        # Pure metadata reproduction of the independent v1 counterexample.
        # These 40 rows are not claimed to be an actual executed trajectory.
        args = self.terminal_metadata_fixture()
        epochs = [{'kind': 'epoch_completed', 'epoch': i, 'complete': True,
            'development': {'macro_f1_11_classes': 0.5 if i < 40 else 0.6},
            'process_wall_seconds': float(i), 'process_cpu_seconds': float(i)}
            for i in range(1, 41)]
        args['plan'].update(min_epochs=30, patience=10, max_epochs=100)
        args['boundary'].update(retained_epochs=40, logical_epochs=epochs,
            all_complete_epochs=epochs, stopping=plateau_state(epochs, .002))
        args['boundary']['work'].update(complete_epochs_after_anchor=0,
            total_logged_main_optimizer_completions=120, retained_main_updates=120)
        args['report'].update(epochs=[{k:v for k,v in row.items() if k != 'kind'} for row in epochs],
                              main_updates=120)
        self.assertEqual(args['boundary']['stopping']['stale_epochs'], 0)
        self.assertEqual(first_plateau_epoch(epochs, .002, 30, 10), 30)
        with self.assertRaises(Ineligible):
            terminal_guard(**args)


if __name__ == '__main__':
    unittest.main(verbosity=2)
