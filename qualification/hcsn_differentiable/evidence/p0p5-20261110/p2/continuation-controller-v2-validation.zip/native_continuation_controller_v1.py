"""Source-bound C1 continuation of completed baseline epoch-cap attempts only.

This controller never changes, resumes or relaunches the original campaign.
It waits for all original baseline attempts to end, then uses at most three
new CPU workers beside the original six HCSN fits. Each fit spends only the
remaining part of its original 14,400-second full-process wall allowance.
"""

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import subprocess
import threading
import time
import traceback
import zipfile

TERMINAL = {"completed", "failed", "timed_out", "launch_failed", "evidence_failed",
            "not_started_whole_budget"}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_journal(path):
    result = []
    if not Path(path).exists():
        return result
    lines = Path(path).read_bytes().splitlines()
    for index, line in enumerate(lines):
        try:
            result.append(json.loads(line))
        except json.JSONDecodeError:
            if index != len(lines) - 1:
                raise
    return result


def remaining_budget(original):
    total, consumed = original["hard_wall_seconds"], original["whole_process_wall_seconds"]
    if not all(isinstance(v, (int, float)) and math.isfinite(v) for v in (total, consumed)):
        raise ValueError("missing/nonfinite original outer wall cost")
    if total != 14400 or consumed <= 0:
        raise ValueError("parent wall envelope is not the authorized original policy")
    return total - consumed


def source_identity(root):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob("*"))
            if p.is_file() and "__pycache__" not in p.parts}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parent-campaign", type=Path, required=True)
    parser.add_argument("--parent-plan", type=Path, required=True)
    parser.add_argument("--parent-plan-sha256", required=True)
    parser.add_argument("--source-archive", type=Path, required=True)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--source-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--maximum-wait-seconds", type=float, default=14400)
    args = parser.parse_args()
    if digest(args.parent_plan) != args.parent_plan_sha256:
        raise ValueError("original declared plan bytes changed")
    if digest(args.source_archive) != args.source_sha256:
        raise ValueError("continuation source capsule differs from tested identity")
    plan = json.loads(args.parent_plan.read_bytes())
    if (plan["per_fit_wall_seconds"] != 14400 or plan["address_space_bytes"] != 8 * 1024**3
            or plan["peak_rss_bytes"] != 6 * 1024**3 or plan["threads"] != 1):
        raise ValueError("original resource policy does not match authorized C1 scope")
    campaign, source, out = (p.resolve() for p in (args.parent_campaign, args.source_dir, args.output))
    out.mkdir(parents=True, exist_ok=False)
    (out / "parent-records").mkdir()
    started, cpu_started = time.monotonic(), time.process_time()
    lock = threading.Lock()
    journal = (out / "commands.jsonl").open("x")
    report = {
        "schema": "hcsn-epoch-cap-continuation-controller-v1", "status": "started",
        "source_archive_sha256": args.source_sha256, "parent_plan_sha256": args.parent_plan_sha256,
        "parent_campaign": str(campaign), "maximum_new_workers": 3, "maximum_total_workers": 9,
        "scope": "completed baseline epoch caps only; original HCSN and original files unchanged",
        "policy_amendment": "separate continuation stage increases total epoch ceiling to400 while preserving original total14400s outer wall, min30, plateau delta/patience, LR and diagnostic",
        "fit_restarts": False, "new_learning_rates": False, "new_diagnostics": False,
        "formal_fits_started": 0, "scientific_admission": "HOLD", "confirmation_access": False,
        "energy_joules": None, "attempts": [], "preflight": [],
        "dispatch_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "controller_source_sha256": digest(Path(__file__)),
    }
    source_before = None

    def record(row):
        with lock:
            journal.write(json.dumps(row, allow_nan=False) + "\n")
            journal.flush()

    def save():
        temporary = out / "RESULT.tmp"
        temporary.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
        temporary.replace(out / "RESULT.json")

    env = dict(os.environ, OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
               PYTHONDONTWRITEBYTECODE="1", CUDA_VISIBLE_DEVICES="", HCSN_S4_REPO=plan["s4_repo"])

    def run_one(parent_row):
        name = parent_row["name"]
        seconds = remaining_budget(parent_row)
        row = {"name": name, "parent_result_sha256": parent_row["result_sha256"],
               "parent_outer_wall_seconds": parent_row["whole_process_wall_seconds"],
               "original_total_wall_seconds": parent_row["hard_wall_seconds"],
               "hard_remaining_wall_seconds": seconds, "status": "started"}
        if seconds <= 30:
            row["status"] = "not_started_no_remaining_budget"
            record(row)
            return row
        parent_record = out / "parent-records" / (name + ".json")
        parent_record.write_text(json.dumps(parent_row, sort_keys=True, indent=2) + "\n")
        bootstrap = (
            "import resource,runpy,sys;resource.setrlimit(resource.RLIMIT_AS,"
            f"({plan['address_space_bytes']},{plan['address_space_bytes']}));"
            "script=sys.argv[1];sys.argv=sys.argv[1:];"
            "sys.path.insert(0,str(__import__('pathlib').Path(script).parent));"
            "runpy.run_path(script,run_name='__main__')"
        )
        argv = [plan["python"], "-B", "-c", bootstrap,
                str(source / "proposals/localization-v3/continuation.py"),
                "--parent-dir", str(campaign / name), "--parent-outer-record", str(parent_record),
                "--output", str(out / name), "--max-epochs", "400", "--total-wall-seconds", "14400"]
        dispatch = time.monotonic()
        row.update(argv=argv, dispatch_offset_seconds=dispatch-started,
                   dispatch_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   parent_outer_record_sha256=digest(parent_record))
        record(row)
        child_env = dict(env, HCSN_PROCESS_STARTED=str(dispatch))
        try:
            with (out / (name + ".stdout")).open("xb") as stdout, (out / (name + ".stderr")).open("xb") as stderr:
                process = subprocess.run(argv, cwd=source, env=child_env, stdout=stdout, stderr=stderr,
                                         timeout=seconds, check=False)
            row.update(status="completed" if process.returncode == 0 else "failed", returncode=process.returncode)
        except subprocess.TimeoutExpired:
            row.update(status="timed_out", returncode=None)
        except Exception:
            row.update(status="launch_failed", returncode=None, launch_error=traceback.format_exc())
        row["whole_process_wall_seconds"] = time.monotonic()-dispatch
        row["cumulative_outer_wall_seconds"] = parent_row["whole_process_wall_seconds"] + row["whole_process_wall_seconds"]
        for stream in ("stdout", "stderr"):
            path = out / (name + "." + stream)
            row[stream+"_sha256"] = digest(path) if path.exists() else None
        try:
            result = out / name / "result.json"
            if result.exists():
                fit = json.loads(result.read_bytes())
                row.update(result_sha256=digest(result), fit_status=fit["status"],
                           epochs_added=len(fit["epochs"]), cumulative_epochs=fit["cumulative_epochs_completed"],
                           adequate=fit["training_adequacy_established"],
                           source_unchanged=fit["source_unchanged"],
                           common_weights_unchanged=fit["common_weights_unchanged"],
                           selected_development=fit.get("selected_development"),
                           phase_full_process_cpu_seconds=fit["phase_full_process_cpu_seconds"],
                           peak_rss_bytes=fit["peak_rss_bytes"])
            else:
                row["fit_evidence_missing"] = True
        except Exception:
            row.update(evidence_error=traceback.format_exc(), adequate=False)
        record(row)
        print(json.dumps({key: row.get(key) for key in ("name", "status", "cumulative_epochs", "adequate", "whole_process_wall_seconds")}), flush=True)
        return row

    try:
        if source.exists():
            raise ValueError("continuation source destination already exists; reconcile before any retry")
        tick = time.monotonic()
        with zipfile.ZipFile(args.source_archive) as archive:
            for name in archive.namelist():
                if name.startswith("/") or ".." in Path(name).parts:
                    raise ValueError("unsafe capsule member")
            archive.extractall(source)
        source_before = source_identity(source)
        if not (source / "proposals/localization-v3/continuation.py").is_file():
            raise ValueError("tested capsule must use the declared root layout")
        report["source_copy_and_hash_seconds"] = time.monotonic()-tick
        (out / "source-manifest.json").write_text(json.dumps(source_before, sort_keys=True, indent=2)+"\n")
        (out / "locked-parent-plan.json").write_bytes(args.parent_plan.read_bytes())
        test_argv = [plan["python"], "-B", "-m", "unittest", "discover", "-s",
                     str(source / "proposals/localization-v3"), "-p", "test_continuation.py", "-v"]
        tick = time.monotonic()
        with (out / "continuation-tests.stdout").open("xb") as stdout, (out / "continuation-tests.stderr").open("xb") as stderr:
            test = subprocess.run(test_argv, cwd=source, env=env, stdout=stdout, stderr=stderr, timeout=180)
        report["preflight"].append({"argv": test_argv, "returncode": test.returncode,
                                    "whole_process_wall_seconds": time.monotonic()-tick,
                                    "stdout_sha256": digest(out/"continuation-tests.stdout"),
                                    "stderr_sha256": digest(out/"continuation-tests.stderr")})
        if test.returncode:
            raise RuntimeError("frozen continuation tests failed; no continued fits started")
        expected = {f"{arm}-s{seed}-lr{lr:g}" for arm in plan["arms"] if arm != "hcsn"
                    for seed in plan["seeds"] for lr in plan["learning_rates"]}
        if len(expected) != 36:
            raise ValueError("original baseline roster is not the declared36")
        wait_started = time.monotonic()
        while True:
            latest = {}
            for row in read_journal(campaign / "commands.jsonl"):
                latest[row["name"]] = row
            complete = {name for name, row in latest.items() if name in expected and row["status"] in TERMINAL}
            report.update(status="waiting_for_original36_baselines", original_baselines_terminal=len(complete))
            save()
            if complete == expected:
                break
            if time.monotonic()-wait_started >= args.maximum_wait_seconds:
                raise TimeoutError("bounded wait for original baseline completion exceeded")
            time.sleep(30)
        report["wait_for_original_baselines_seconds"] = time.monotonic()-wait_started
        tasks, excluded = [], []
        for name in sorted(expected):
            row = latest[name]
            path = campaign / name / "result.json"
            if row["status"] != "completed" or row.get("returncode") != 0 or not path.exists():
                excluded.append({"name": name, "reason": "original attempt not completed with usable result", "outer_status": row["status"]})
                continue
            if digest(path) != row.get("result_sha256"):
                raise ValueError("completed parent result identity changed: " + name)
            original = json.loads(path.read_bytes())
            if original.get("stop_reason") != "epoch_cap_not_convergence":
                excluded.append({"name": name, "reason": original.get("stop_reason", "not a cap")})
                continue
            if (original.get("status") != "completed_development" or original.get("source_unchanged") is not True
                    or original.get("common_weights_unchanged") is not True):
                raise ValueError("cap parent fails the bound identity gates: " + name)
            remaining_budget(row)
            tasks.append(row)
        report.update(status="continuations_running", declared_continuation_names=[row["name"] for row in tasks],
                      excluded=excluded, host_load_before_continuations=os.getloadavg(),
                      meminfo_before_continuations=Path("/proc/meminfo").read_text())
        save()
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = [pool.submit(run_one, row) for row in tasks]
            for future in as_completed(futures):
                report["attempts"].append(future.result())
                save()
        report["status"] = "completed_continuation_roster"
    except Exception:
        report.update(status="controller_failed_or_wait_exhausted", error=traceback.format_exc())
    finally:
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        report.update(whole_wall_seconds=time.monotonic()-started,
                      controller_cpu_seconds=time.process_time()-cpu_started,
                      children_cpu_seconds=usage.ru_utime+usage.ru_stime,
                      sum_attempt_outer_wall_seconds=sum(r.get("whole_process_wall_seconds", 0) for r in report["attempts"]),
                      source_unchanged=source_before == source_identity(source) if source_before is not None else False,
                      finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      cpu_scope="children CPU includes native preflight tests and all continuation subprocesses; never add to a duplicated perfit subtotal")
        if not report["source_unchanged"] and report["status"] == "completed_continuation_roster":
            report["status"] = "source_changed"
        save()
        journal.close()
        print(json.dumps({"status": report["status"], "attempts": len(report["attempts"]), "wall_seconds": report["whole_wall_seconds"]}), flush=True)
    return 0 if report["status"] == "completed_continuation_roster" else 2


if __name__ == "__main__":
    raise SystemExit(main())
