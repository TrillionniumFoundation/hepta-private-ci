"""Run the retained continuation fixtures; no scientific training credit."""
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
source = root / "source"
s4 = Path("/workspace/scratch/c385a7439f8e/hcsn-study-runtime-20261110/s4")
manifest = json.loads((root / "source-manifest.json").read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory():
    return {name: sha(source / name) for name in manifest}


plan = {
    "schema": "hcsn-continuation-fixture-validation-v1",
    "scientific_training_credit": False,
    "test_count_expected": 10,
    "argv": [sys.executable, "-B", str(source / "proposals/localization-v3/test_continuation.py"), "-v"],
    "source_before": inventory(),
    "source_snapshot_matches_manifest": inventory() == manifest,
    "s4_commit": subprocess.check_output(["git", "-C", str(s4), "rev-parse", "HEAD"], text=True).strip(),
    "s4_dirty_before": subprocess.check_output(["git", "-C", str(s4), "status", "--porcelain"], text=True),
    "s4_full_source_manifest_sha256": sha(s4.parent / "s4-source-manifest.json"),
    "python": sys.version,
    "packages": {name: metadata.version(name) for name in ("torch", "numpy", "mpmath", "ncps", "spikingjelly", "einops")},
    "concurrency_scope": "native v8 training is on a different host; no fair-training timing comparison",
}
assert plan["source_snapshot_matches_manifest"]
assert plan["s4_commit"] == "e757cef57d89e448c413de7325ed5601aceaac13"
assert not plan["s4_dirty_before"]
(root / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
env = dict(os.environ, HCSN_S4_REPO=str(s4), OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
           OPENBLAS_NUM_THREADS="1", CUDA_VISIBLE_DEVICES="", PYTHONDONTWRITEBYTECODE="1")
started = time.perf_counter()
before = resource.getrusage(resource.RUSAGE_CHILDREN)
report = {"started_utc": datetime.now(timezone.utc).isoformat()}
with (root / "stdout.log").open("xb") as stdout, (root / "stderr.log").open("xb") as stderr:
    process = subprocess.run(plan["argv"], env=env, cwd=source, stdout=stdout, stderr=stderr, timeout=300)
report["wall_seconds"] = time.perf_counter() - started
after = resource.getrusage(resource.RUSAGE_CHILDREN)
log = (root / "stderr.log").read_text()
count = re.search(r"Ran (\d+) tests in ([\d.]+)s", log)
report.update(
    completed_utc=datetime.now(timezone.utc).isoformat(), returncode=process.returncode,
    test_count=int(count.group(1)) if count else None,
    unittest_seconds=float(count.group(2)) if count else None,
    child_cpu_seconds=(after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime),
    peak_rss_bytes=after.ru_maxrss * 1024,
    source_after=inventory(), source_unchanged=inventory() == plan["source_before"],
    stdout_sha256=sha(root / "stdout.log"), stderr_sha256=sha(root / "stderr.log"),
    energy_joules=None, currency_cost=None,
    scientific_training_credit=False,
)
report["s4_dirty_after"] = subprocess.check_output(["git", "-C", str(s4), "status", "--porcelain"], text=True)
report["status"] = "passed" if process.returncode == 0 and report["test_count"] == 10 and report["source_unchanged"] and not report["s4_dirty_after"] else "failed"
(root / "result.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: report[key] for key in ("status", "test_count", "returncode", "wall_seconds", "child_cpu_seconds", "peak_rss_bytes", "source_unchanged")}))
raise SystemExit(0 if report["status"] == "passed" else 1)
