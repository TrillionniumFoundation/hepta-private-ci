"""Reconcile singular unittest output without repeating or altering the run."""
import hashlib
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
raw = json.loads((root / "result.json").read_bytes())
log = (root / "stderr.log").read_text()
match = re.search(r"Ran (\d+) tests? in ([\d.]+)s", log)
assert raw["returncode"] == 0 and raw["source_unchanged"]
assert match and int(match.group(1)) == 1
assert log.rstrip().endswith("OK") and "... skipped" not in log
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
report = {
    **raw,
    "status": "passed_underlying_test_after_readback_reconciliation",
    "test_count": int(match.group(1)),
    "unittest_seconds": float(match.group(2)),
    "reconciliation_reason": "Original wrapper expected the plural word tests; unittest emits test for one case. Raw test subprocess exited 0 with OK; only the metadata wrapper exited 1. No test or training was rerun.",
    "original_wrapper_status": raw["status"],
    "original_wrapper_exit_code_observed": 1,
    "original_result_sha256": sha(root / "result.json"),
    "original_runner_sha256": sha(root / "run.py"),
    "reconciliation_runner_sha256": sha(Path(__file__)),
    "raw_log_sha256": sha(root / "stderr.log"),
    "scientific_training_credit": False,
}
assert report["raw_log_sha256"] == raw["stderr_sha256"]
(root / "result-reconciled.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: report[key] for key in ("status", "test_count", "unittest_seconds", "original_wrapper_status")}))
