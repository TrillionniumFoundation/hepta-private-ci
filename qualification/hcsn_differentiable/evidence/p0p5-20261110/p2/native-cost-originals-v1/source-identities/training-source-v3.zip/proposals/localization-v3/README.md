# Temporal-core study, development stage

This is an executable continuation on the real UCI localization data. It uses
all 89,216 A/B/C training events and all 31,952 D development events, split into
the existing nonoverlapping 256-event windows. Original gaps and each final
short window are retained. E has no training, tuning or scoring entry point.

## Isolation and fair opportunity

The primary regime freezes both the deterministic normalized 25-feature input
and the same `25 -> d` projection/tanh and `d -> 11` output head. The latter two
have identical actual initial weights for a given seed, independent of how
many RNG draws each temporal-core constructor consumes. They remain frozen
throughout optimization; every epoch and final receipt verifies their hashes.
Only the temporal core learns. `--train-shared` is an explicitly separate,
secondary regime and cannot be mixed into this comparison.

The cores are PyTorch GRU, pinned official CfCCell, pinned official recurrent
PLIF, an analytic event-time LIF reference, pinned official S4D-Lin, causal
PyTorch Transformer, and existing HCSN. CfC receives actual elapsed times; the
Transformer uses cumulative elapsed time in its positional features. PLIF and
S4D remain event-indexed and receive elapsed time in the common input. This CPU
FP64 study does not qualify an optimized GPU Transformer or GPU efficiency.

Same common dimensions do not imply equal parameter count, state size or work.
Receipts separate common frozen parameters from each core, count complex
parameters as two real scalars, and retain source/dependency hashes. No padding
weights create a fictional parameter match. The declared opportunity roster
applies equal learning-rate choices, seeds, full-data exposure limits and
per-attempt wall/RSS limits. Each arm's failures remain in that roster.

## Event derivative and HCSN qualification boundaries

`event_time_lif` integrates a leaky integrate-and-fire model exactly under
piecewise constant current, threshold 1 and reset 0, without refractory delay.
It analytically sums all spikes within the interval into an exponential trace;
its output is membrane plus trace. AD differentiates event times inside a fixed
event-count active set. No surrogate spike derivative is used. Grazing events
and event-count changes are nonsmooth, and this is not an implementation or
validation of the published EventProp algorithm. More than one million events
in one interval is rejected as outside the reference's declared numeric domain.
Stable `log1p` expressions avoid cancellation at large current. Tests compare
all smooth inputs' AD derivatives with finite differences, as well as direct
multi-spike summation and the no-spike limit.

HCSN uses frozen physics, the existing probability/content network and explicit
fresh state at each training window. Its construction is not numerical
admission. Tail padding has zero duration and is passed with `observed=False`
and `valid_mask=False`; it cannot create extra observation conditioning. A
development trace records actual posteriors before optimizer steps and excludes
padding. Truncation, unsupported physics, failed physical error limits or
missing independent audit keep HCSN scientific admission at HOLD. A changed grid
requires a fresh initialization and separately bound numerical receipt.

The HCSN CLI requires `--hcsn-grid-json` with all seven `GridSpec` fields:
`active_cells`, `endpoint`, `phase_cells`, `refractory`, `tail_rate`,
`quadrature_order`, and `initial_log_std`. Missing or extra fields are rejected.
The run records the full network/operator configuration, probability and
content coefficient counts, their FP64 state payload, and per-gap matrix size.
Those payload bytes exclude autograd, parameter snapshots and temporary work;
measured peak RSS is the separate process-level memory result. A constructor
accepting a grid does not certify it. The current 128/4.8/16/.2/1/32/.08
development candidate requires its own actual-posterior and finite-schedule
evidence, and does not grant arbitrary tiny-gap qualification.

`--cache-frozen-tables` optionally reuses exactly equal frozen-physics tables
within one fit. Its key includes the complete physical tensor bytes, exact
float64 duration, grid/reward configuration, dtype/device and fixed buffers.
It performs no time rounding or interpolation, rejects differentiable physical
parameters, and clears the cache whenever a checkpoint is loaded. Each fit
starts cold. Table construction/rebuild wall time, hit/miss counts, tensor
storage bytes and process RSS remain part of the measured cost. Tests require
bitwise equality of probability/content transports, network outputs and learned
parameter gradients against the original uncached operator. Cache equality
does not establish continuous-model accuracy or a hardware performance claim.

## Training, evidence and costs

Each fit first runs a training-only memorization diagnostic, restores every
initial tensor, and creates a fresh main optimizer. A complete epoch visits
every ABC event exactly once. The permutation is seeded identically across
cores. The normal plan requires at least 30 epochs, plus the declared D plateau
and successful diagnostic before reporting training adequacy. An epoch cap,
wall cap or incomplete process is not convergence. No interrupted fit is
resumed automatically; retained partial checkpoints are inspection artifacts,
not an exact-resume promise.

`campaign.py` reads a frozen JSON plan, records each subprocess's argv and full
elapsed time including import/startup, and keeps stdout/stderr and outcome even
on failure. Workers retain initial/best/last model and optimizer checkpoints,
development logits, complete update journals, source hashes, per-epoch curves,
measured CPU time and peak RSS. A source change forces a failing result and
removes adequacy credit. Same-quality time uses a predeclared D macro-F1 target;
it does not establish held-out generalization. Energy and unmeasured VRAM stay
null. The Linux campaign enforces a declared address-space limit before Torch
loads, plus a subprocess wall deadline; measured RSS has a separate soft limit.

The first frozen `run-source-v1` campaign retains its original checkpoint rule:
it saves improvements larger than `plateau_delta`, so its selected checkpoint
need not be the strict development-set argmax. Its first-observed threshold
time and selected checkpoint quality must be reported separately. The next
source stage saves every strict score improvement and uses `plateau_delta`
only for the stopping counter. Historical snapshots and receipts are unchanged.

The campaign is a development study. Three seeds and two learning rates do not
complete the larger twelve-configuration/five-confirmation-seed protocol.
Historical data preparation, prior unknown cloud reservations and complete
physical energy are not silently counted as zero. Confirmation, full HCSN
domain admission, real multimodal tasks, physical-mechanism superiority and
production adoption remain separate gates.
