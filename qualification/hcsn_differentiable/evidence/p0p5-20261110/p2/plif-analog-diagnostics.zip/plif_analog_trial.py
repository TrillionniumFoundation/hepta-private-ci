"""One fresh training-only PLIF initialization trial; threshold travels with weights."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import time
import traceback

BASE = Path('/workspace/scratch/c385a7439f8e')
SOURCE = BASE / 'v6-local-validation/source'
sys.path.insert(0, str(SOURCE / 'proposals/localization-v3'))
import torch
from cores import CoreStudyModel, tensor_digest
from hcsn_study_support import batches, sources, backward_effective_batch
from capacity import adamw
from train_development import metrics, peak_rss


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class AnalogPLIFReadout(torch.nn.Module):
    """Official surrogate PLIF dynamics with explicit analog output state."""
    def __init__(self, original, mode):
        super().__init__()
        self.input, self.recurrent, self.node = original.input, original.recurrent, original.node
        self.mode = mode
        self.diagnostics = {}

    def forward(self, x, dt):
        self.node.reset()
        state, trace = torch.zeros_like(x[:, 0]), torch.zeros_like(x[:, 0])
        rows, spikes = [], []
        for observation in x.unbind(1):
            state = self.node(self.input(observation) + self.recurrent(state))
            spikes.append(state)
            trace = .75 * trace + .25 * state
            rows.append(self.node.v if self.mode == 'membrane' else trace)
        spike = torch.stack(spikes, 1)
        self.diagnostics = {'spike_fraction': float(spike.detach().mean()),
            'active_neurons': int((spike.detach().sum((0, 1)) > 0).sum()),
            'tau': float(1 / self.node.w.detach().sigmoid()), 'readout': self.mode,
            'trace_time_constant_event_steps': 4.0,
            'time_semantics': 'event-indexed; physical dt also appears in common input'}
        return torch.stack(rows, 1)


def construct(configuration):
    model = CoreStudyModel('snn_plif', width=16, seed=101, learn_core_adapter=True)
    model.core.node.v_threshold = configuration['threshold']
    with torch.no_grad():
        model.core.node.w.fill_(-math.log(configuration['init_tau'] - 1.))
        model.core.input.weight.mul_(configuration['input_weight_gain'])
    model.core = AnalogPLIFReadout(model.core, configuration['readout'])
    return model


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--tau', type=float, choices=[2.0], required=True)
    parser.add_argument('--threshold', type=float, choices=[1.], required=True)
    parser.add_argument('--gain', type=float, choices=[1.], required=True)
    parser.add_argument('--readout', choices=['membrane', 'spike_trace'], required=True)
    args = parser.parse_args()
    out = args.output; out.mkdir(exist_ok=False)
    started, cpu_started = time.monotonic(), time.process_time()
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    prepared = BASE / 'uci-cloud-prepared-v1'
    manifest_path = prepared / 'data-manifest.json'
    assert sha(manifest_path) == '0eb233da8d0b766c35356ba450d0572f1e6a87a47f1d8a17cd32c2ae6f25a1cb'
    manifest = json.loads(manifest_path.read_text())
    frontend_path = prepared / 'frontend.json'
    assert sha(frontend_path) == manifest['frontend_sha256']
    frontend = json.loads(frontend_path.read_text())
    identity = next(r for r in manifest['episodes'] if r['id'] == 'A01-0' and r['partition'] == 'train')
    episode_path = prepared / identity['path']; assert sha(episode_path) == identity['sha256']
    episode = json.loads(episode_path.read_text())
    assert len(set(episode['y'])) > 1
    _, x, dt, y = next(batches([episode], [0], 1))
    counts = torch.tensor([frontend['class_counts'][str(i)] for i in range(11)], dtype=torch.float64)
    assert int(counts.sum()) == 89216
    weights = counts.rsqrt(); weights /= weights.mean()
    configuration = {'init_tau': args.tau, 'threshold': args.threshold, 'input_weight_gain': args.gain,
        'gain_semantics': 'multiply learnable input weight at initialization only; bias unchanged',
        'readout': args.readout, 'trace_time_constant_event_steps': 4.,
        'output': 'explicit analog PLIF readout followed by common trainable identity adapter and frozen head'}
    model = construct(configuration); optimizer, _ = adamw(model, .003, 0.)
    plan = {'configuration': configuration, 'seed': 101, 'learning_rate': .003, 'updates': 256,
        'episode_id': episode['id'], 'episode_sha256': sha(episode_path),
        'data_manifest_sha256': sha(manifest_path), 'frontend_sha256': sha(frontend_path),
        'weights': weights.tolist(), 'source_capsule_sha256': sha(BASE / 'training-source-v6.zip'),
        'driver_sha256': sha(Path(__file__)), 'wall_seconds': 160, 'peak_rss_bytes': 1536 * 1024**2,
        'evaluation_updates': [0, 32, 64, 128, 256], 'D_access': False, 'E_access': False}
    (out / 'plan.json').write_text(json.dumps(plan, sort_keys=True, indent=2) + '\n')
    torch.save({'configuration': configuration, 'model': model.state_dict()}, out / 'initial.pt')
    report = {'status': 'started', 'curve': [], 'updates': 0, 'complete_epochs': 0,
        'formal_fits_started': 0, 'scientific_admission': 'HOLD', 'source_before': sources(model),
        'first_passing_update': None, 'configuration': configuration}
    journal = (out / 'updates.jsonl').open('x')

    def evaluate(step):
        model.eval()
        with torch.no_grad():
            score = metrics(model(x, dt)[y >= 0], y[y >= 0])
        passed = score['accuracy'] >= .95 and score['macro_f1_present_classes'] >= .9
        if passed and report['first_passing_update'] is None: report['first_passing_update'] = step
        report['curve'].append({'update': step, 'wall_seconds': time.monotonic()-started,
            'metrics': score, 'passed': passed, 'diagnostics': model.core.diagnostics})

    try:
        with torch.no_grad():
            original = model(x, dt)
            changed = x.clone(); changed[:, 128:] += 7
            altered = model(changed, dt)
            prefix_error = float((original[:, :128] - altered[:, :128]).abs().max())
            if prefix_error != 0: raise ValueError('noncausal analog readout')
            report['causal_prefix_max_abs_error'] = prefix_error
        evaluate(0)
        for step in range(1, 257):
            if time.monotonic()-started > plan['wall_seconds'] or peak_rss() > plan['peak_rss_bytes']:
                raise TimeoutError('bounded training-only tuning trial')
            model.train(); optimizer.zero_grad(set_to_none=True)
            receipt = backward_effective_batch(model, x, dt, y, weights)
            parameters = [p for p in model.parameters() if p.requires_grad]
            if any(p.grad is None or not bool(torch.isfinite(p.grad).all()) for p in parameters):
                raise FloatingPointError('missing or nonfinite gradient')
            norm = torch.nn.utils.clip_grad_norm_(parameters, 1.)
            if not bool(torch.isfinite(norm)): raise FloatingPointError('nonfinite norm')
            optimizer.step(); report['updates'] = step
            journal.write(json.dumps({'update': step, 'gradient_norm': float(norm), **receipt})+'\n'); journal.flush()
            if step in plan['evaluation_updates']: evaluate(step)
        checkpoint = {'configuration': configuration, 'model': model.state_dict(), 'optimizer': optimizer.state_dict()}
        torch.save(checkpoint, out / 'trained.pt')
        restored = construct(configuration)
        restored.load_state_dict(torch.load(out / 'trained.pt', weights_only=False)['model'])
        restored.eval(); model.eval()
        with torch.no_grad():
            expected, actual = model(x, dt), restored(x, dt)
        error = float((expected-actual).abs().max())
        if error != 0: raise ValueError('fresh configured checkpoint inference differs')
        report.update(status='completed_tuning_trial', fresh_checkpoint_forward_max_abs_error=error,
            reconstructed_threshold=restored.core.node.v_threshold, final_metrics=report['curve'][-1]['metrics'],
            passed=report['curve'][-1]['passed'])
    except Exception:
        report.update(status='failed_or_budget_exhausted', error=traceback.format_exc(), passed=False)
    finally:
        journal.close()
        report.update(wall_seconds=time.monotonic()-started, cpu_seconds=time.process_time()-cpu_started,
            peak_rss_bytes=peak_rss(), source_after=sources(model), energy_joules=None,
            common_weights_unchanged=tensor_digest(model.frontend)==model.initial_frontend_sha256
            and tensor_digest(model.head)==model.initial_head_sha256)
        report['source_unchanged'] = report['source_before'] == report['source_after']
        report['artifacts'] = {p.name: sha(p) for p in out.iterdir() if p.is_file()}
        (out / 'RESULT.json').write_text(json.dumps(report, sort_keys=True, indent=2)+'\n')
    print(json.dumps({k: report[k] for k in ('status', 'passed', 'updates', 'wall_seconds')}), flush=True)
    return 0 if report['status'] == 'completed_tuning_trial' else 2


if __name__ == '__main__':
    raise SystemExit(main())
