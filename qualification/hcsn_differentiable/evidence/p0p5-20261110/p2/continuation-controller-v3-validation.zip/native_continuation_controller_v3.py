"""Source-bound C1 continuation of completed baseline epoch-cap attempts only.

Wait for all 36 original baselines to terminate, then allow up to three C1
workers. The original HCSN attempts are untouched. Each continuation inherits
its actual original outer wall ceiling, which may be below the nominal 14,400
seconds because v8 also imposed a 15,000-second global dispatch deadline.
"""

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import subprocess
import threading
import time
import traceback
import zipfile

TERMINAL = {
    "completed", "failed", "timed_out", "launch_failed", "evidence_failed",
    "not_started_whole_budget",
}
NOMINAL_TOTAL_WALL_SECONDS = 14400


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_journal(path):
    if not Path(path).exists():
        return []
    result = []
    lines = Path(path).read_bytes().splitlines()
    for index, line in enumerate(lines):
        try:
            result.append(json.loads(line))
        except json.JSONDecodeError:
            if index != len(lines) - 1:
                raise
    return result


def remaining_budget(original):
    total = original["hard_wall_seconds"]
    consumed = original["whole_process_wall_seconds"]
    if not all(type(value) in (int, float) and math.isfinite(value)
               for value in (total, consumed)):
        raise ValueError("missing/nonfinite original outer wall cost")
    if not 0 < total <= NOMINAL_TOTAL_WALL_SECONDS or consumed <= 0:
        raise ValueError("parent wall ceiling exceeds or contradicts original policy")
    return total - consumed


def source_identity(root):
    return {
        str(path.relative_to(root)): digest(path)
        for path in sorted(root.rglob("*"))
        if path.is_file() and "__pycache__" not in path.parts
    }


def continuation_command(plan, source, campaign, out, parent_record, parent_row):
    bootstrap = (
        "import resource,runpy,sys;resource.setrlimit(resource.RLIMIT_AS,"
        f"({plan['address_space_bytes']},{plan['address_space_bytes']}));"
        "script=sys.argv[1];sys.argv=sys.argv[1:];"
        "sys.path.insert(0,str(__import__('pathlib').Path(script).parent));"
        "runpy.run_path(script,run_name='__main__')"
    )
    name = parent_row["name"]
    return [
        plan["python"], "-B", "-c", bootstrap,
        str(source / "proposals/localization-v3/continuation.py"),
        "--parent-dir", str(campaign / name),
        "--parent-outer-record", str(parent_record),
        "--output", str(out / name), "--max-epochs", "400",
        "--total-wall-seconds", str(parent_row["hard_wall_seconds"]),
    ]


def run_continuation(parent_row, *, plan, source, campaign, out, started, env,
                     record, remember):
    """Retain every dispatch, even setup, launch, or result-parse failures."""
    dispatch = time.monotonic()
    name = parent_row["name"]
    row = {
        "name": name, "status": "started", "process_started": False,
        "adequate": False, "returncode": None,
        "dispatch_monotonic": dispatch,
        "dispatch_offset_seconds": dispatch - started,
        "dispatch_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "nominal_total_wall_seconds": NOMINAL_TOTAL_WALL_SECONDS,
        "parent_result_sha256": parent_row.get("result_sha256"),
        "parent_outer_wall_seconds": parent_row.get("whole_process_wall_seconds"),
        "original_total_wall_seconds": parent_row.get("hard_wall_seconds"),
    }
    process = None
    process_finished = None

    def emit(required=False):
        remember(name, dict(row))
        try:
            record(dict(row))
        except Exception:
            row.setdefault("journal_errors", []).append(traceback.format_exc())
            remember(name, dict(row))
            if required:
                raise

    try:
        seconds = remaining_budget(parent_row)
        row["hard_remaining_wall_seconds"] = seconds
        emit(required=True)
        if seconds <= 30:
            row["status"] = "not_started_no_remaining_budget"
        else:
            parent_record = out / "parent-records" / (name + ".json")
            parent_record.write_text(json.dumps(parent_row, sort_keys=True, indent=2) + "\n")
            row["parent_outer_record_sha256"] = digest(parent_record)
            argv = continuation_command(plan, source, campaign, out, parent_record, parent_row)
            row["argv"] = argv
            emit(required=True)
            child_env = dict(env, HCSN_PROCESS_STARTED=str(dispatch))
            with (out / (name + ".stdout")).open("xb") as stdout, \
                    (out / (name + ".stderr")).open("xb") as stderr:
                remaining = seconds - (time.monotonic() - dispatch)
                if remaining <= 30:
                    row["status"] = "not_started_no_remaining_budget"
                else:
                    process = subprocess.Popen(argv, cwd=source, env=child_env,
                                               stdout=stdout, stderr=stderr)
                    row.update(process_started=True, pid=process.pid,
                               launch_offset_seconds=time.monotonic() - dispatch)
                    emit(required=True)
                    process.wait(timeout=max(0.001, seconds - (time.monotonic() - dispatch)))
                    row.update(status="completed" if process.returncode == 0 else "failed",
                               returncode=process.returncode)
    except subprocess.TimeoutExpired:
        row["status"] = "timed_out"
    except Exception:
        row.update(status="attempt_failed" if row["process_started"] else "launch_failed",
                   error=traceback.format_exc())
    finally:
        if process is not None:
            try:
                if process.poll() is None:
                    process.kill()
                process.wait()
                row["returncode"] = process.returncode
            except Exception:
                row.update(cleanup_error=traceback.format_exc(), child_terminal_unknown=True)
        process_finished = time.monotonic()
        row["whole_process_wall_seconds"] = process_finished - dispatch
        parent_wall = parent_row.get("whole_process_wall_seconds")
        if type(parent_wall) in (int, float) and math.isfinite(parent_wall):
            row["cumulative_outer_wall_seconds"] = parent_wall + row["whole_process_wall_seconds"]
        for stream in ("stdout", "stderr"):
            try:
                path = out / (name + "." + stream)
                row[stream + "_sha256"] = digest(path) if path.exists() else None
            except Exception:
                row.setdefault("evidence_errors", []).append(traceback.format_exc())
        try:
            result = out / name / "result.json"
            if result.exists():
                row["result_sha256"] = digest(result)
                fit = json.loads(result.read_bytes())
                row.update(
                    fit_status=fit["status"], epochs_added=len(fit["epochs"]),
                    cumulative_epochs=fit["cumulative_epochs_completed"],
                    adequate=fit["training_adequacy_established"],
                    source_unchanged=fit["source_unchanged"],
                    common_weights_unchanged=fit["common_weights_unchanged"],
                    selected_development=fit.get("selected_development"),
                    phase_full_process_cpu_seconds=fit["phase_full_process_cpu_seconds"],
                    peak_rss_bytes=fit["peak_rss_bytes"],
                )
            elif row["process_started"]:
                row["fit_evidence_missing"] = True
                if row["status"] == "completed":
                    row["status"] = "evidence_failed"
        except Exception:
            row.setdefault("evidence_errors", []).append(traceback.format_exc())
        if row.get("evidence_errors"):
            if row["status"] == "completed":
                row["status"] = "evidence_failed"
            row["adequate"] = False
        if row.get("journal_errors"):
            if row["status"] == "completed":
                row["status"] = "accounting_failed"
            row["adequate"] = False
        if row["status"] != "completed":
            row["adequate"] = False
        row["attempt_wrapper_wall_seconds"] = time.monotonic() - dispatch
        row["evidence_processing_wall_seconds"] = time.monotonic() - process_finished
        emit()
        if row.get("journal_errors"):
            row["adequate"] = False
            if row["status"] == "completed":
                row["status"] = "accounting_failed"
            remember(name, dict(row))
    return row


def harvest_futures(future_parents, snapshots, record):
    """One failed future must not discard other submitted attempts or costs."""
    for future in as_completed(future_parents):
        parent = future_parents[future]
        try:
            row = future.result()
            if not isinstance(row, dict) or row.get("name") != parent["name"]:
                raise ValueError("worker returned no matching terminal attempt")
        except Exception:
            row = dict(snapshots.get(parent["name"], {"name": parent["name"]}))
            row.update(status="worker_exception", adequate=False,
                       worker_error=traceback.format_exc(),
                       terminal_accounting_incomplete=True)
            # Never turn an unobserved launch or wall cost into a zero.
            row.setdefault("process_started", None)
            row.setdefault("whole_process_wall_seconds", None)
            row.setdefault("attempt_wrapper_wall_seconds", None)
            try:
                record(dict(row))
            except Exception:
                row.setdefault("journal_errors", []).append(traceback.format_exc())
        yield row


def cost_totals(attempts, declared_names=()):
    missing = [row["name"] for row in attempts
               if row.get("whole_process_wall_seconds") is None
               or row.get("attempt_wrapper_wall_seconds") is None
               or row.get("terminal_accounting_incomplete")
               or row.get("journal_errors") or row.get("child_terminal_unknown")]
    missing_terminal = sorted(set(declared_names) - {row["name"] for row in attempts})
    missing = sorted(set(missing) | set(missing_terminal))
    unknown_launches = sorted(set(missing_terminal) | {
        row["name"] for row in attempts if row.get("process_started") is None})
    return {
        "missing_terminal_attempt_names": missing_terminal,
        "actual_continuations_started": sum(row.get("process_started") is True for row in attempts),
        "actual_continuations_started_is_lower_bound": bool(unknown_launches),
        "launch_status_unknown_names": unknown_launches,
        "sum_attempt_outer_wall_seconds": sum(row["whole_process_wall_seconds"] for row in attempts
                                               if row.get("whole_process_wall_seconds") is not None),
        "sum_attempt_wrapper_wall_seconds": sum(row["attempt_wrapper_wall_seconds"] for row in attempts
                                                 if row.get("attempt_wrapper_wall_seconds") is not None),
        "attempt_cost_accounting_complete": not missing,
        "incomplete_attempt_accounting_names": missing,
        "attempt_wall_sum_is_lower_bound": bool(missing),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parent-campaign", type=Path, required=True)
    parser.add_argument("--parent-plan", type=Path, required=True)
    parser.add_argument("--parent-plan-sha256", required=True)
    parser.add_argument("--source-archive", type=Path, required=True)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--source-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--maximum-wait-seconds", type=float, default=14400)
    args = parser.parse_args()
    if digest(args.parent_plan) != args.parent_plan_sha256:
        raise ValueError("original declared plan bytes changed")
    if digest(args.source_archive) != args.source_sha256:
        raise ValueError("continuation source capsule differs from tested identity")
    plan = json.loads(args.parent_plan.read_bytes())
    if (plan["per_fit_wall_seconds"] != NOMINAL_TOTAL_WALL_SECONDS
            or plan["whole_wall_seconds"] != 15000
            or plan["address_space_bytes"] != 8 * 1024**3
            or plan["peak_rss_bytes"] != 6 * 1024**3 or plan["threads"] != 1):
        raise ValueError("original resource policy does not match authorized C1 scope")
    campaign, source, out = (path.resolve() for path in
                             (args.parent_campaign, args.source_dir, args.output))
    out.mkdir(parents=True, exist_ok=False)
    (out / "parent-records").mkdir()
    started, cpu_started = time.monotonic(), time.process_time()
    lock = threading.Lock()
    journal = (out / "commands.jsonl").open("x")
    report = {
        "schema": "hcsn-epoch-cap-continuation-controller-v3", "status": "started",
        "source_archive_sha256": args.source_sha256,
        "parent_plan_sha256": args.parent_plan_sha256, "parent_campaign": str(campaign),
        "maximum_new_workers": 3, "maximum_original_hcsn_plus_c1_workers": 9,
        "scope": "completed baseline epoch caps only; original HCSN and original files unchanged",
        "policy_amendment": "separate C1 extends the cumulative epoch ceiling to400; each fit retains its actual original outer hard wall ceiling, min30, plateau delta/patience, LR and diagnostic",
        "nominal_per_fit_wall_seconds": NOMINAL_TOTAL_WALL_SECONDS,
        "original_global_dispatch_window_seconds": plan["whole_wall_seconds"],
        "actual_budget_rule": "each parent outer.hard_wall_seconds minus parent whole_process_wall_seconds; no restoration to nominal14400",
        "calendar_scope": "C1 is an additional phase and can extend beyond the original15000s campaign endpoint; perfit active process wall envelopes remain unchanged; no equal end-to-end calendar claim",
        "fit_restarts": False, "new_learning_rates": False, "new_diagnostics": False,
        "formal_fits_started": 0, "formal_scope": "larger confirmatory protocol remains unstarted",
        "actual_continuations_started": 0, "scientific_admission": "HOLD",
        "confirmation_access": False, "energy_joules": None, "attempts": [], "preflight": [],
        "dispatch_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "controller_source_sha256": digest(Path(__file__)),
    }
    source_before = None
    snapshots = {}

    def remember(name, row):
        with lock:
            snapshots[name] = row

    def record(row):
        with lock:
            journal.write(json.dumps(row, allow_nan=False) + "\n")
            journal.flush()

    def save():
        temporary = out / "RESULT.tmp"
        temporary.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
        temporary.replace(out / "RESULT.json")

    env = dict(os.environ, OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
               PYTHONDONTWRITEBYTECODE="1", CUDA_VISIBLE_DEVICES="", HCSN_S4_REPO=plan["s4_repo"])
    try:
        if source.exists():
            raise ValueError("continuation source destination exists; reconcile before retry")
        tick = time.monotonic()
        with zipfile.ZipFile(args.source_archive) as archive:
            for name in archive.namelist():
                if name.startswith("/") or ".." in Path(name).parts:
                    raise ValueError("unsafe capsule member")
            archive.extractall(source)
        source_before = source_identity(source)
        if not (source / "proposals/localization-v3/continuation.py").is_file():
            raise ValueError("tested capsule must use the declared root layout")
        report["source_copy_and_hash_seconds"] = time.monotonic() - tick
        (out / "source-manifest.json").write_text(json.dumps(source_before, sort_keys=True, indent=2) + "\n")
        (out / "locked-parent-plan.json").write_bytes(args.parent_plan.read_bytes())
        test_argv = [plan["python"], "-B", "-m", "unittest", "discover", "-s",
                     str(source / "proposals/localization-v3"), "-p", "test_continuation.py", "-v"]
        tick = time.monotonic()
        preflight = {"argv": test_argv, "returncode": None, "status": "started"}
        report["preflight"].append(preflight)
        try:
            with (out / "continuation-tests.stdout").open("xb") as stdout, \
                    (out / "continuation-tests.stderr").open("xb") as stderr:
                test = subprocess.run(test_argv, cwd=source, env=env,
                                      stdout=stdout, stderr=stderr, timeout=180)
            preflight.update(returncode=test.returncode, status="completed")
        except Exception:
            preflight.update(status="failed", error=traceback.format_exc())
        finally:
            preflight["whole_process_wall_seconds"] = time.monotonic() - tick
            for stream in ("stdout", "stderr"):
                path = out / ("continuation-tests." + stream)
                preflight[stream + "_sha256"] = digest(path) if path.exists() else None
        if preflight["returncode"] != 0:
            raise RuntimeError("frozen continuation tests failed; no continued fits started")
        expected = {f"{arm}-s{seed}-lr{lr:g}" for arm in plan["arms"] if arm != "hcsn"
                    for seed in plan["seeds"] for lr in plan["learning_rates"]}
        if len(expected) != 36:
            raise ValueError("original baseline roster is not the declared36")
        wait_started = time.monotonic()
        while True:
            latest = {row["name"]: row for row in read_journal(campaign / "commands.jsonl")}
            complete = {name for name, row in latest.items()
                        if name in expected and row["status"] in TERMINAL}
            report.update(status="waiting_for_original36_baselines", original_baselines_terminal=len(complete))
            save()
            if complete == expected:
                break
            if time.monotonic() - wait_started >= args.maximum_wait_seconds:
                raise TimeoutError("bounded wait for original baseline completion exceeded")
            time.sleep(30)
        report["wait_for_original_baselines_seconds"] = time.monotonic() - wait_started
        tasks, excluded = [], []
        for name in sorted(expected):
            row = latest[name]
            path = campaign / name / "result.json"
            if row["status"] != "completed" or row.get("returncode") != 0 or not path.exists():
                excluded.append({"name": name, "reason": "original attempt not completed with usable result", "outer_status": row["status"]})
                continue
            if digest(path) != row.get("result_sha256"):
                raise ValueError("completed parent result identity changed: " + name)
            original = json.loads(path.read_bytes())
            if original.get("stop_reason") != "epoch_cap_not_convergence":
                excluded.append({"name": name, "reason": original.get("stop_reason", "not a cap")})
                continue
            if (original.get("status") != "completed_development"
                    or original.get("source_unchanged") is not True
                    or original.get("common_weights_unchanged") is not True):
                raise ValueError("cap parent fails the bound identity gates: " + name)
            remaining_budget(row)
            tasks.append(row)
        report.update(status="continuations_running",
                      declared_continuation_names=[row["name"] for row in tasks],
                      excluded=excluded, host_load_before_continuations=os.getloadavg(),
                      meminfo_before_continuations=Path("/proc/meminfo").read_text())
        save()
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = {}
            for row in tasks:
                try:
                    future = pool.submit(run_continuation, row, plan=plan, source=source,
                                         campaign=campaign, out=out, started=started, env=env,
                                         record=record, remember=remember)
                    futures[future] = row
                except Exception:
                    failed = {"name": row["name"], "status": "submission_failed",
                              "process_started": False, "adequate": False,
                              "whole_process_wall_seconds": 0.0,
                              "attempt_wrapper_wall_seconds": 0.0,
                              "error": traceback.format_exc(),
                              "cost_scope": "no worker dispatched; submission overhead included in controller"}
                    report["attempts"].append(failed)
                    try:
                        record(failed)
                    except Exception:
                        failed.setdefault("journal_errors", []).append(traceback.format_exc())
            for row in harvest_futures(futures, snapshots, record):
                report["attempts"].append(row)
                report.update(cost_totals(report["attempts"]))
                try:
                    save()
                except Exception:
                    report.setdefault("controller_save_errors", []).append(traceback.format_exc())
                try:
                    print(json.dumps({key: row.get(key) for key in (
                        "name", "status", "cumulative_epochs", "adequate", "whole_process_wall_seconds")}), flush=True)
                except Exception:
                    report.setdefault("progress_output_errors", []).append(traceback.format_exc())
        report.update(cost_totals(report["attempts"]))
        report["status"] = "completed_continuation_roster"
        if not report["attempt_cost_accounting_complete"] or report.get("controller_save_errors"):
            report["status"] = "completed_roster_accounting_hold"
    except Exception:
        report.update(status="controller_failed_or_wait_exhausted", error=traceback.format_exc())
    finally:
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        report.update(cost_totals(report["attempts"], report.get("declared_continuation_names", [])))
        report.update(
            whole_wall_seconds=time.monotonic() - started,
            controller_cpu_seconds=time.process_time() - cpu_started,
            children_cpu_seconds=usage.ru_utime + usage.ru_stime,
            source_unchanged=source_before == source_identity(source) if source_before is not None else False,
            finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            cpu_scope="children CPU includes native preflight and all C1 subprocesses; phase report CPU is a subset, not an additive extra",
            wall_scope="whole controller includes source/test/wait/evidence cost; attempt outer stops after child wait; wrapper adds evidence processing; overlapping walls are not summed as elapsed time",
        )
        if not report["source_unchanged"] and report["status"].startswith("completed"):
            report["status"] = "source_changed"
        save()
        journal.close()
        print(json.dumps({"status": report["status"], "attempts": len(report["attempts"]),
                          "actual_continuations_started": report["actual_continuations_started"],
                          "wall_seconds": report["whole_wall_seconds"]}), flush=True)
    return 0 if report["status"] == "completed_continuation_roster" else 2


if __name__ == "__main__":
    raise SystemExit(main())
