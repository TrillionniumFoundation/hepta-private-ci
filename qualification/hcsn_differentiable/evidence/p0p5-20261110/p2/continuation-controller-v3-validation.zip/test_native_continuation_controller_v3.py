"""Controller budget/accounting regression tests; no model training is performed."""

from concurrent.futures import Future
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

import native_continuation_controller_v3 as controller


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.source = self.base / "source"
        (self.source / "proposals/localization-v3").mkdir(parents=True)
        self.out = self.base / "out"
        (self.out / "parent-records").mkdir(parents=True)
        self.parent = {"name": "attention-s101-lr0.001", "hard_wall_seconds": 13500.25,
                       "whole_process_wall_seconds": 1000.5, "result_sha256": "parent-fixture"}
        self.plan = {"python": sys.executable, "address_space_bytes": 8 * 1024**3}
        self.records = []
        self.snapshots = {}

    def remember(self, name, row):
        self.snapshots[name] = row

    def write_child(self, malformed=False):
        child = '''import argparse,json,os,resource,time
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--parent-dir');p.add_argument('--parent-outer-record')
p.add_argument('--output');p.add_argument('--max-epochs');p.add_argument('--total-wall-seconds',type=float)
a=p.parse_args();out=Path(a.output);out.mkdir()
(out/'observed.json').write_text(json.dumps({'actual_ceiling':a.total_wall_seconds,'as_limit':resource.getrlimit(resource.RLIMIT_AS)[0],'process_start_before_import':float(os.environ['HCSN_PROCESS_STARTED'])<=time.monotonic()}))
fit={'status':'completed_development','epochs':[{'epoch':101}], 'cumulative_epochs_completed':101,
'training_adequacy_established':True,'source_unchanged':True,'common_weights_unchanged':True,
'selected_development':{'macro_f1_11_classes':.31},'phase_full_process_cpu_seconds':time.process_time(),'peak_rss_bytes':1024}
(out/'result.json').write_text('BAD_JSON' if MALFORMED else json.dumps(fit))
'''.replace("MALFORMED", repr(malformed))
        (self.source / "proposals/localization-v3/continuation.py").write_text(child)

    def run_attempt(self, record=None):
        return controller.run_continuation(
            self.parent, plan=self.plan, source=self.source,
            campaign=self.base / "parent", out=self.out, started=time.monotonic(),
            env=dict(os.environ), record=record or self.records.append, remember=self.remember)

    def test_late_dispatch_keeps_smaller_actual_ceiling_in_child(self):
        self.write_child()
        self.assertEqual(controller.remaining_budget(self.parent), 12499.75)
        row = self.run_attempt()
        self.assertEqual(row["status"], "completed")
        seen = json.loads((self.out / self.parent["name"] / "observed.json").read_text())
        self.assertEqual(seen["actual_ceiling"], 13500.25)
        self.assertEqual(seen["as_limit"], 8 * 1024**3)
        self.assertTrue(seen["process_start_before_import"])
        self.assertTrue(row["process_started"])
        self.assertEqual(row["original_total_wall_seconds"], 13500.25)
        self.assertEqual(row["nominal_total_wall_seconds"], 14400)
        self.assertGreater(row["whole_process_wall_seconds"], 0)
        self.assertLess(row["cumulative_outer_wall_seconds"], 13500.25)
        self.assertEqual(controller.cost_totals([row])["actual_continuations_started"], 1)

    def test_nonfinite_expanded_or_zero_budget_rejected(self):
        for total in (14400.01, 0, -1, float("nan"), True):
            with self.subTest(total=total), self.assertRaises(ValueError):
                controller.remaining_budget(dict(self.parent, hard_wall_seconds=total))
        with self.assertRaises(ValueError):
            controller.remaining_budget(dict(self.parent, whole_process_wall_seconds=float("inf")))

    def test_prelaunch_parent_write_failure_has_terminal_cost_and_no_launch(self):
        (self.out / "parent-records").rmdir()
        row = self.run_attempt()
        self.assertEqual(row["status"], "launch_failed")
        self.assertFalse(row["process_started"])
        self.assertGreater(row["whole_process_wall_seconds"], 0)
        self.assertEqual(self.records[-1]["status"], "launch_failed")
        self.assertTrue(controller.cost_totals([row])["attempt_cost_accounting_complete"])

    def test_malformed_result_is_charged_failure_after_real_child(self):
        self.write_child(malformed=True)
        row = self.run_attempt()
        self.assertEqual(row["status"], "evidence_failed")
        self.assertTrue(row["process_started"])
        self.assertFalse(row["adequate"])
        self.assertGreater(row["whole_process_wall_seconds"], 0)
        self.assertTrue(row["evidence_errors"])

    def test_final_journal_error_is_visible_without_losing_attempt(self):
        self.write_child()

        def record(row):
            if row["status"] == "completed":
                raise OSError("injected terminal journal failure")
            self.records.append(row)

        row = self.run_attempt(record)
        self.assertEqual(row["status"], "accounting_failed")
        self.assertTrue(row["process_started"])
        self.assertFalse(row["adequate"])
        totals = controller.cost_totals([row])
        self.assertEqual(totals["actual_continuations_started"], 1)
        self.assertFalse(totals["attempt_cost_accounting_complete"])
        self.assertGreater(totals["sum_attempt_outer_wall_seconds"], 0)

    def test_worker_exception_does_not_stop_other_futures(self):
        bad, good = Future(), Future()
        bad.set_exception(OSError("injected future failure"))
        good.set_result({"name": "other", "status": "completed", "process_started": True,
                         "whole_process_wall_seconds": 3.0, "attempt_wrapper_wall_seconds": 3.1})
        rows = list(controller.harvest_futures(
            {bad: {"name": "bad"}, good: {"name": "other"}}, {}, self.records.append))
        self.assertEqual({row["name"] for row in rows}, {"bad", "other"})
        missing = next(row for row in rows if row["name"] == "bad")
        self.assertEqual(missing["status"], "worker_exception")
        self.assertIsNone(missing["whole_process_wall_seconds"])
        totals = controller.cost_totals(rows)
        self.assertEqual(totals["sum_attempt_outer_wall_seconds"], 3.0)
        self.assertEqual(totals["actual_continuations_started"], 1)
        self.assertEqual(totals["launch_status_unknown_names"], ["bad"])
        self.assertTrue(totals["attempt_wall_sum_is_lower_bound"])

    def test_timeout_kills_own_child_and_counts_started_attempt(self):
        process = mock.Mock(pid=12345, returncode=None)
        process.wait.side_effect = [subprocess.TimeoutExpired("fixture", 1), None]
        process.poll.return_value = None
        with mock.patch.object(controller.subprocess, "Popen", return_value=process):
            row = self.run_attempt()
        process.kill.assert_called_once()
        self.assertEqual(process.wait.call_count, 2)
        self.assertEqual(row["status"], "timed_out")
        self.assertTrue(row["process_started"])
        self.assertGreater(row["whole_process_wall_seconds"], 0)
        self.assertEqual(controller.cost_totals([row])["actual_continuations_started"], 1)

    def test_declared_missing_terminal_attempt_forces_incomplete_lower_bound(self):
        recorded = {"name": "known", "process_started": True,
                    "whole_process_wall_seconds": 2.0, "attempt_wrapper_wall_seconds": 2.1}
        totals = controller.cost_totals([recorded], ["known", "missing"])
        self.assertEqual(totals["missing_terminal_attempt_names"], ["missing"])
        self.assertEqual(totals["incomplete_attempt_accounting_names"], ["missing"])
        self.assertFalse(totals["attempt_cost_accounting_complete"])
        self.assertTrue(totals["attempt_wall_sum_is_lower_bound"])
        self.assertEqual(totals["sum_attempt_outer_wall_seconds"], 2.0)
        self.assertEqual(totals["actual_continuations_started"], 1)
        self.assertEqual(totals["launch_status_unknown_names"], ["missing"])
        self.assertTrue(totals["actual_continuations_started_is_lower_bound"])

    def test_exhausted_parent_creates_no_child_and_empty_roster_is_accountable(self):
        self.parent["whole_process_wall_seconds"] = self.parent["hard_wall_seconds"] - 20
        with mock.patch.object(controller.subprocess, "Popen") as process:
            row = self.run_attempt()
        process.assert_not_called()
        self.assertEqual(row["status"], "not_started_no_remaining_budget")
        self.assertFalse(row["process_started"])
        self.assertEqual(controller.cost_totals([])["actual_continuations_started"], 0)
        self.assertTrue(controller.cost_totals([])["attempt_cost_accounting_complete"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
