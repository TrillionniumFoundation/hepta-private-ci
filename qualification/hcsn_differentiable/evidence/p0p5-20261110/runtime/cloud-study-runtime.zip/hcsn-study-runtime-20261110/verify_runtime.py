"""Record the isolated baseline environment and pinned official S4 source."""
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import importlib.util
import inspect
import json
from pathlib import Path
import platform
import subprocess
import sys

root = Path(__file__).resolve().parent
s4 = root / "s4"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(s4), *args], text=True).strip()


assert git("rev-parse", "HEAD") == "e757cef57d89e448c413de7325ed5601aceaac13"
assert not git("status", "--porcelain")
import torch
import numpy
import mpmath
from ncps.torch.cfc_cell import CfCCell
from spikingjelly.activation_based import neuron, surrogate

sys.path.insert(0, str(s4))
spec = importlib.util.spec_from_file_location("hcsn_pinned_official_s4d", s4 / "models/s4/s4d.py")
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
assert callable(module.S4D)
assert callable(CfCCell) and callable(neuron.ParametricLIFNode) and callable(surrogate.ATan)
expected = {"torch": "2.8.0+cpu", "numpy": "2.5.4", "mpmath": "1.3.0", "ncps": "1.0.1",
            "spikingjelly": "0.0.0.0.14", "einops": "0.8.1", "torchvision": "0.23.0+cpu"}
versions = {name: metadata.version(name) for name in expected}
assert versions == expected, versions
source_files = {}
for relative in git("ls-files").splitlines():
    path = s4 / relative
    source_files[relative] = {"bytes": path.stat().st_size, "sha256": sha(path)}
(root / "s4-source-manifest.json").write_text(json.dumps({"repository": git("remote", "get-url", "origin"),
    "commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
    "working_tree_clean": not bool(git("status", "--porcelain")), "files": source_files}, indent=2) + "\n")
imported_sources = {}
for name, obj in {"CfCCell": CfCCell, "ParametricLIFNode": neuron.ParametricLIFNode,
                  "ATan": surrogate.ATan, "S4D": module.S4D}.items():
    path = Path(inspect.getsourcefile(obj))
    imported_sources[name] = {"path": str(path), "sha256": sha(path)}
qualified = root.parent / "hcsn-env"
before = json.loads((root / "qualified-environment-before.json").read_text())
after = {str(p.relative_to(qualified)): sha(p) for p in qualified.glob("lib/python*/site-packages/*.dist-info/METADATA")}
assert after == before
freeze = subprocess.check_output([sys.executable, "-m", "pip", "freeze", "--all"], text=True)
(root / "requirements.lock.txt").write_text(freeze)
check = subprocess.run([sys.executable, "-m", "pip", "check"], capture_output=True, text=True)
(root / "pip-check.stdout").write_text(check.stdout)
(root / "pip-check.stderr").write_text(check.stderr)
receipt = {"schema": "hcsn-cloud-study-runtime-receipt-v1", "status": "ready" if check.returncode == 0 else "dependency_conflict",
    "python": sys.version, "executable": sys.executable, "platform": platform.platform(),
    "direct_versions": versions, "torch_cuda_version": torch.version.cuda, "cuda_available": torch.cuda.is_available(),
    "import_checks": {"CfCCell": True, "ParametricLIFNode": True, "ATan": True, "official_S4D": True},
    "imported_sources": imported_sources, "s4_commit": git("rev-parse", "HEAD"),
    "s4_manifest_sha256": sha(root / "s4-source-manifest.json"), "s4_tree_clean_after_import": not bool(git("status", "--porcelain")),
    "requirements_lock_sha256": sha(root / "requirements.lock.txt"), "pip_check_exit_code": check.returncode,
    "qualified_environment_metadata_unchanged": after == before,
    "qualified_environment_scope": "Original environment was read only; all setup mutations target the new hcsn-study-env and study-runtime directories.",
    "new_host_attempt": True, "training_started": False,
    "created_utc": datetime.now(timezone.utc).isoformat()}
(root / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
raise SystemExit(check.returncode)
