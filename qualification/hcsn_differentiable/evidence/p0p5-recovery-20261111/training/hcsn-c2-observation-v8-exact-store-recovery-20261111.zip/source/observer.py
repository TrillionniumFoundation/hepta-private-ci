"""Bounded metadata suffix observation with exact parent journal byte lineage."""
import os
import time

STARTED = time.monotonic()

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import zipfile
from journal_delta import read_journal_delta

BASE = Path('/home/qian-qi/hepta-hcsn-core-study-20261110-c385-training')
RUN = BASE / 'c2-native-execution-20261110-c385-v1'
PROGRAM = BASE / 'c2-execution-source-v4-20261110-c385'
OUT = BASE / 'c2-epoch-observation-20261110-c385-v8'
PARENT = BASE / 'c2-epoch-observation-20261110-c385-v7'
PARENT_SUMMARY_SHA = '88cfdd4371d5ee93b2fb2b91a20f5e72081ef4a9d4936a8f59cb0b5ed9dfbb74'
PARENT_ZIP_SHA = '72364b58d0fada4ff022559a54378fcb4e127597b836dff899e137b152b99beb'
NAMES = [f'hcsn-s{seed}-lr{lr}' for seed in (101, 211, 307) for lr in ('0.001', '0.003')]


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    total, reads = 0, []
    max_input_payload_bytes = 32 * 1024**2

    def charge(size):
        nonlocal total
        if type(size) is not int or size < 0 or total + size > max_input_payload_bytes:
            raise ValueError('whole observation input-byte budget exceeded')
        total += size

    def read_stable_metadata(path, per_file_limit=2 * 1024**2):
        if path.is_symlink() or not path.is_file():
            raise ValueError('nonregular metadata input')
        with path.open('rb') as stream:
            before = os.fstat(stream.fileno())
            if before.st_size > per_file_limit:
                raise ValueError('metadata file exceeds per-file byte budget')
            charge(before.st_size)
            data = stream.read(before.st_size)
            after = os.fstat(stream.fileno())
        current = path.stat()
        fields = ('st_size', 'st_mtime_ns', 'st_ino', 'st_dev')
        if (path.is_symlink() or len(data) != before.st_size
                or any(getattr(before, k) != getattr(after, k) for k in fields)
                or any(getattr(after, k) != getattr(current, k) for k in fields)):
            raise ValueError('metadata changed during bounded read')
        return data
    OUT.mkdir(exist_ok=False)
    raw = OUT / 'raw'
    raw.mkdir()
    (raw / 'observer.py').write_bytes(read_stable_metadata(Path(__file__)))
    (raw / 'journal_delta.py').write_bytes(read_stable_metadata(Path(__file__).parent / 'journal_delta.py'))
    observer_sources = {'observer.py': (raw / 'observer.py').read_bytes(), 'journal_delta.py': (raw / 'journal_delta.py').read_bytes()}
    parent_raw = read_stable_metadata(PARENT / 'SUMMARY.json')
    if identity(parent_raw)['sha256'] != PARENT_SUMMARY_SHA:
        raise ValueError('parent snapshot identity differs')
    parent_archive_raw = read_stable_metadata(PARENT / 'hcsn-c2-epoch-observation-20261110-v7.zip')
    if identity(parent_archive_raw)['sha256'] != PARENT_ZIP_SHA:
        raise ValueError('parent ZIP identity differs')
    parent = json.loads(parent_raw)
    prior_fits = {row['name']: row for row in parent['fits']}
    if set(prior_fits) != set(NAMES):
        raise ValueError('parent roster differs')
    parent_reads = {row['original']: row for row in parent['reads']}
    parent_reference = {'summary_path': str(PARENT / 'SUMMARY.json'), **identity(parent_raw),
        'archive_path': str(PARENT / 'hcsn-c2-epoch-observation-20261110-v7.zip'),
        'archive_sha256': PARENT_ZIP_SHA, 'archive_identity_verified': True,
        'scope': 'New complete epoch nodes after this parent only; old raw prefix remains in the source-bound parent archive.'}
    write(raw / 'PARENT-REFERENCE.json', parent_reference)

    def capture(path, name, jsonl=False):
        nonlocal total
        if not path.is_file() or path.is_symlink():
            return None
        data = read_stable_metadata(path)
        target = raw / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(data)
        stable = True  # read_stable_metadata checked descriptor and path identity
        entry = {'original': str(path), 'copy': name, **identity(data), 'same_stat_during_read': stable,
            'observed_utc': datetime.now(timezone.utc).isoformat()}
        reads.append(entry)
        try:
            value = [json.loads(line) for line in data.splitlines()] if jsonl else json.loads(data)
        except ValueError:
            entry['status'] = 'incomplete_live_write_at_observation'
            return None
        entry['status'] = 'stable_byte_snapshot' if stable else 'changed_during_read'
        return value if stable else None

    def capture_journal(path, name, prior):
        nonlocal total
        parent_state = prior.get('journal_for_next_observation')
        if parent_state is None:
            previous = parent_reads[str(path)]
            if previous['status'] != 'stable_byte_snapshot':
                raise ValueError('parent journal has no stable reusable full prefix')
            parent_state = {'source_snapshot': {key: previous[key] for key in ('bytes', 'sha256')},
                'completed_updates': prior['optimizer_completions_observed'],
                'latest_optimizer_completion': prior.get('latest_optimizer_completion'),
                'last_event_kind': prior.get('last_event_kind')}
        if type(parent_state['completed_updates']) is not int or parent_state['completed_updates'] < 0:
            raise ValueError('parent journal completed-update counter unavailable')
        try:
            reserved_bytes = path.stat().st_size
            if reserved_bytes > 8 * 1024**2:
                raise ValueError('journal exceeds per-source byte budget')
            charge(reserved_bytes)
            value = read_journal_delta(path, parent_state['source_snapshot'], max_source_bytes=reserved_bytes)
        except (OSError, ValueError) as error:
            detail = {'original': str(path), 'error': repr(error), 'observed_utc': datetime.now(timezone.utc).isoformat(),
                'parent_prefix_not_advanced': True, 'prior_snapshot': parent_state}
            target = raw / name / 'JOURNAL-READ-ERROR.json'
            target.parent.mkdir(parents=True, exist_ok=True)
            write(target, detail)
            return {'journal_for_next_observation': parent_state, 'journal_observation_error': detail,
                'optimizer_completions_observed': None, 'latest_optimizer_completion': None}
        fragment, events = value.pop('fragment'), value.pop('rows')
        target = raw / name / 'events-suffix.jsonl'
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(fragment)
        completed = [event for event in events if event.get('kind') == 'optimizer_completed']
        count = parent_state['completed_updates'] + len(completed)
        latest = completed[-1] if completed else parent_state['latest_optimizer_completion']
        kind = events[-1].get('kind') if events else parent_state['last_event_kind']
        entry = {'original': str(path), 'copy': name + '/events-suffix.jsonl', **identity(fragment),
            'status': 'stable_jsonl_suffix_snapshot', 'source_snapshot': value['source_snapshot'],
            'parent_prefix': value['parent_prefix'], 'retained_range': value['retained_range'],
            'observed_utc': datetime.now(timezone.utc).isoformat(), 'complete_records_in_suffix': len(events),
            'optimizer_completions_in_suffix': len(completed)}
        reads.append(entry)
        write(raw / name / 'JOURNAL-SUFFIX-IDENTITY.json', entry)
        return {'journal_for_next_observation': {'source_snapshot': value['source_snapshot'], 'completed_updates': count,
                    'latest_optimizer_completion': latest, 'last_event_kind': kind},
                'journal_suffix_identity': entry, 'optimizer_completions_observed': count,
                'optimizer_completions_observed_in_suffix': len(completed),
                'latest_optimizer_completion': latest, 'last_event_kind': kind}

    source_before = read_stable_metadata(PROGRAM / 'PROGRAM-MANIFEST.json')
    if identity(source_before)['sha256'] != '322eb8f76cce589ba44ed66eff822f7b497e6507106a1ad56a65bdc8c83f7f57':
        raise ValueError('unexpected C2 source manifest')
    report = {'schema': 'hcsn-c2-journal-suffix-epoch-observation-v8',
        'started_utc': datetime.now(timezone.utc).isoformat(), 'reads': reads, 'fits': [],
        'source_manifest': identity(source_before), 'parent_snapshot': parent_reference,
        'complete_epoch_node_scope': 'delta after parent; complete prefix is retained in parent archive',
        'event_journal_scope': 'exact new JSONL byte suffix only; parent-prefix SHA and new full-prefix SHA bound',
        'model_loads_forward_backward_optimizer_steps': 0,
        'probability_trace_arrays_read': False, 'original_directories_written': False,
        'scientific_admission': 'HOLD', 'numerical_admission': 'HOLD', 'live_observation_not_independent_terminal_audit': True}
    commands = capture(RUN / 'commands.jsonl', 'controller/commands.jsonl', jsonl=True)
    latest = {row['name']: row for row in commands or []}
    controller_terminal = capture(RUN / 'RESULT.json', 'controller/RESULT.json')
    report['controller_terminal_observed'] = controller_terminal is not None
    for name in NAMES:
        fit = RUN / 'fits' / name
        prior = prior_fits[name]
        prefix_last = prior['latest_complete_epoch_record'] if 'latest_complete_epoch_record' in prior else prior['complete_epochs'][-1]
        cutoff = prefix_last['epoch']['epoch']
        row = {'name': name, 'dispatch': latest.get(name), 'complete_epochs': [],
            'parent_complete_epoch_cutoff': cutoff, 'parent_last_epoch_node': prefix_last}
        pid = (row['dispatch'] or {}).get('pid')
        row['pid_exists_at_observation'] = Path('/proc/' + str(pid)).exists() if isinstance(pid, int) else None
        paths = sorted((fit / 'commits').glob('epoch-*.json'))
        if len(paths) > 200:
            raise ValueError('unexpected complete epoch roster')
        if not paths or int(paths[-1].stem.split('-')[-1]) < cutoff:
            raise ValueError('native commit roster regressed behind immutable parent')
        paths = [path for path in paths if int(path.stem.split('-')[-1]) > cutoff]
        for path in paths:
            commit = capture(path, name + '/commits/' + path.name)
            if commit is not None:
                row['complete_epochs'].append({'original': str(path), 'identity': {key: reads[-1][key] for key in ('bytes', 'sha256')},
                    'epoch': commit['epoch'], 'stopping': commit['stopping'],
                    'checkpoint': commit['checkpoint'], 'previous_commit': commit['previous_commit']})
        row.update(capture_journal(fit / 'events.jsonl', name, prior))
        if prior['fit_terminal_report_observed'] and prior['outer_terminal_record_observed']:
            terminal_refs = []
            for path in (fit / 'result.json', RUN / 'attempts' / name / 'RESULT.json'):
                expected = parent_reads.get(str(path))
                if expected is None:
                    expected = next(item for item in prior['prior_terminal_identity_reverified'] if item['original'] == str(path))
                observed = identity(read_stable_metadata(path))
                if observed != {key: expected[key] for key in ('bytes', 'sha256')}:
                    raise ValueError('previously closed terminal metadata changed')
                terminal_refs.append({'original': str(path), **observed, 'raw_bytes_retained_in_parent_archive': True})
            terminal, outer = prior['terminal'], prior['outer_terminal_record']
            row['prior_terminal_identity_reverified'] = terminal_refs
        else:
            terminal = capture(fit / 'result.json', name + '/result.json')
            outer = capture(RUN / 'attempts' / name / 'RESULT.json', name + '/outer-RESULT.json')
        row['fit_terminal_report_observed'] = terminal is not None
        row['outer_terminal_record_observed'] = outer is not None
        row['outer_terminal_record'] = outer
        if terminal:
            row['terminal'] = {key: terminal.get(key) for key in ('status', 'stop_reason', 'best_epoch',
                'cumulative_epochs_completed', 'new_main_updates', 'training_adequacy_established',
                'last_checkpoint_sha256', 'best_checkpoint_sha256', 'selected_development',
                'source_and_parent_inputs_unchanged', 'common_and_physical_weights_unchanged')}
        row['latest_complete_epoch_record'] = row['complete_epochs'][-1] if row['complete_epochs'] else prefix_last
        report['fits'].append(row)
    report['source_manifest_unchanged'] = source_before == read_stable_metadata(PROGRAM / 'PROGRAM-MANIFEST.json')
    report['parent_snapshot_unchanged'] = parent_raw == read_stable_metadata(PARENT / 'SUMMARY.json')
    if not report['parent_snapshot_unchanged'] or not report['source_manifest_unchanged']:
        raise ValueError('parent snapshot or C2 source manifest changed during observation')
    report['observer_sources_unchanged'] = all(read_stable_metadata(Path(__file__).parent / name) == value for name, value in observer_sources.items())
    report['parent_archive_unchanged'] = parent_archive_raw == read_stable_metadata(PARENT / 'hcsn-c2-epoch-observation-20261110-v7.zip')
    if not report['observer_sources_unchanged'] or not report['parent_archive_unchanged']:
        raise ValueError('observer or parent archive changed')
    report['journal_observation_complete'] = all('journal_observation_error' not in row for row in report['fits'])
    report.update(charged_input_payload_bytes=total, max_input_payload_bytes=max_input_payload_bytes,
        input_byte_budget_scope='Every explicit original payload/source-proof read charged before read; journal reservations are not refunded on invalid/changed suffix. Output ZIP reads and interpreter imports are outside this data-byte budget but inside whole process costs.', wall_seconds=time.monotonic() - STARTED,
        cpu_seconds=time.process_time(), peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024)
    write(OUT / 'SUMMARY.json', report)
    manifest = {str(path.relative_to(OUT)): identity(path.read_bytes()) for path in sorted(raw.rglob('*')) if path.is_file()}
    manifest['SUMMARY.json'] = identity((OUT / 'SUMMARY.json').read_bytes())
    write(OUT / 'MANIFEST.json', manifest)
    archive = OUT / 'hcsn-c2-epoch-observation-20261110-v8.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name in sorted(manifest):
            zipped.write(OUT / name, name)
        zipped.write(OUT / 'MANIFEST.json', 'MANIFEST.json')
    with zipfile.ZipFile(archive) as zipped:
        if zipped.testzip() is not None:
            raise ValueError('observation CRC failed')
        for name, item in manifest.items():
            if identity(zipped.read(name)) != item:
                raise ValueError('member byte identity changed')
    result = {'schema': 'hcsn-c2-journal-suffix-observation-archive-v8',
        'status': 'read_only_observation_completed' if report['journal_observation_complete'] else 'read_only_observation_completed_with_journal_hold', 'archive': {'path': str(archive), **identity(archive.read_bytes())},
        'summary': identity((OUT / 'SUMMARY.json').read_bytes()),
        'whole_script_wall_seconds': time.monotonic() - STARTED, 'whole_script_cpu_seconds': time.process_time(),
        'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        'fits': [{'name': row['name'], 'latest_complete_epoch': row['latest_complete_epoch_record']['epoch']['epoch'],
            'latest_stopping': row['latest_complete_epoch_record']['stopping'],
            'C2_cumulative_optimizer_completions_observed': row.get('optimizer_completions_observed'),
            'optimizer_completions_in_this_suffix': row.get('optimizer_completions_observed_in_suffix'),
            'journal_observation_error': row.get('journal_observation_error'),
            'terminal_status': (row.get('terminal') or {}).get('status'),
            'stop_reason': (row.get('terminal') or {}).get('stop_reason'),
            'pid_exists': row['pid_exists_at_observation']} for row in report['fits']]}
    write(OUT / 'RESULT.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
