import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from journal_delta import read_journal_delta


class JournalDeltaTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.path = Path(self.directory.name) / 'events.jsonl'
        self.prefix = (json.dumps({'kind': 'complete', 'text': '先前'}, ensure_ascii=False) + '\n').encode()
        self.expected = {'bytes': len(self.prefix), 'sha256': hashlib.sha256(self.prefix).hexdigest()}

    def tearDown(self):
        self.directory.cleanup()

    def test_exact_bytes_with_unicode_prefix_and_multiple_new_records(self):
        suffix = b'{"kind":"forward_started"}\n{"kind":"optimizer_completed"}\n'
        self.path.write_bytes(self.prefix + suffix)
        result = read_journal_delta(self.path, self.expected)
        self.assertEqual(result['fragment'], suffix)
        self.assertEqual(result['retained_range'], [len(self.prefix), len(self.prefix + suffix)])
        self.assertEqual(result['source_snapshot']['sha256'], hashlib.sha256(self.prefix + suffix).hexdigest())
        self.assertEqual([r['kind'] for r in result['rows']], ['forward_started', 'optimizer_completed'])

    def test_unchanged_journal_retains_empty_suffix(self):
        self.path.write_bytes(self.prefix)
        result = read_journal_delta(self.path, self.expected)
        self.assertEqual(result['fragment'], b'')
        self.assertEqual(result['rows'], [])
        self.assertEqual(result['source_snapshot'], self.expected)

    def test_same_length_parent_corruption_is_rejected(self):
        self.path.write_bytes(self.prefix.replace(b'complete', b'coMplete') + b'{}\n')
        with self.assertRaisesRegex(ValueError, 'digest mismatch'):
            read_journal_delta(self.path, self.expected)

    def test_truncated_source_is_rejected(self):
        self.path.write_bytes(self.prefix[:-1])
        with self.assertRaisesRegex(ValueError, 'truncated'):
            read_journal_delta(self.path, self.expected)

    def test_partial_final_line_cannot_advance_prefix(self):
        self.path.write_bytes(self.prefix + b'{"kind":"optimizer_completed"}')
        with self.assertRaisesRegex(ValueError, 'inside a record'):
            read_journal_delta(self.path, self.expected)

    def test_parent_boundary_inside_record_is_rejected(self):
        prefix = self.prefix[:-1]
        expected = {'bytes': len(prefix), 'sha256': hashlib.sha256(prefix).hexdigest()}
        self.path.write_bytes(self.prefix + b'{}\n')
        with self.assertRaisesRegex(ValueError, 'inside a record'):
            read_journal_delta(self.path, expected)

    def test_malformed_json_suffix_is_rejected(self):
        self.path.write_bytes(self.prefix + b'{broken}\n')
        with self.assertRaises(ValueError):
            read_journal_delta(self.path, self.expected)

    def test_nonobject_suffix_is_rejected(self):
        self.path.write_bytes(self.prefix + b'[]\n')
        with self.assertRaisesRegex(ValueError, 'nonobject'):
            read_journal_delta(self.path, self.expected)

    def test_suffix_budget_is_enforced(self):
        self.path.write_bytes(self.prefix + b'{}\n')
        with self.assertRaisesRegex(ValueError, 'bounded read'):
            read_journal_delta(self.path, self.expected, max_fragment_bytes=2)


if __name__ == '__main__':
    unittest.main()
