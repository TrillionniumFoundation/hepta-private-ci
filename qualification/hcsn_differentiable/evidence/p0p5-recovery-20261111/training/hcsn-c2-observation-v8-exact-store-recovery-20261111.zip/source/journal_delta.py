"""Read a complete JSONL suffix while binding the exact immutable prior prefix."""
import hashlib
import json
import os
from pathlib import Path


def read_journal_delta(path, expected, *, max_source_bytes=8 * 1024**2, max_fragment_bytes=2 * 1024**2):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError('journal is not a regular nonsymlink file')
    offset = expected['bytes']
    if type(offset) is not int or offset < 0:
        raise ValueError('invalid parent byte count')
    with path.open('rb') as stream:
        before = os.fstat(stream.fileno())
        if before.st_size < offset or before.st_size > max_source_bytes or before.st_size - offset > max_fragment_bytes:
            raise ValueError('journal was truncated or exceeds bounded read')
        data = stream.read(before.st_size)
        after = os.fstat(stream.fileno())
    fields = ('st_size', 'st_mtime_ns', 'st_ino', 'st_dev')
    current = path.stat()
    if (path.is_symlink() or len(data) != before.st_size
            or any(getattr(before, k) != getattr(after, k) for k in fields)
            or any(getattr(after, k) != getattr(current, k) for k in fields)):
        raise ValueError('journal changed during bounded read; parent prefix must not advance')
    prefix, fragment = data[:offset], data[offset:]
    if hashlib.sha256(prefix).hexdigest() != expected['sha256']:
        raise ValueError('parent journal prefix digest mismatch')
    if (prefix and not prefix.endswith(b'\n')) or (fragment and not fragment.endswith(b'\n')):
        raise ValueError('journal prefix/suffix ends inside a record')
    rows = [json.loads(line) for line in fragment.splitlines()]
    if any(not isinstance(row, dict) for row in rows):
        raise ValueError('journal suffix contains nonobject records')
    return {'source_snapshot': {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()},
            'parent_prefix': dict(expected), 'retained_range': [offset, len(data)],
            'fragment_identity': {'bytes': len(fragment), 'sha256': hashlib.sha256(fragment).hexdigest()},
            'fragment': fragment, 'rows': rows}
