import ast, importlib.util, json, sys, time
from pathlib import Path
BASE=Path('/workspace/scratch/ff41dfc0f7bf')
REPO=BASE/'hepta-retirement-barrier-cloud'
OUT=BASE/'tooling/validation/root-33a5a338-artifact-open-diagnostic-v1'
OUT.mkdir(exist_ok=False)
helpers=ast.parse((BASE/'tooling/run_root_32a7d4df_full_source_ci_evidence_v1.py').read_text())
exec(compile(ast.Module(body=[n for n in helpers.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))],type_ignores=[]),'retained-snapshot-functions','exec'))
before=snapshot();assert before['head']=='33a5a338637a4787237bc4154b23a06f6ad34357' and not before['status']
sys.path.insert(0,str(REPO/'scripts'))
import verify_hepta_callers as proof
data=proof._load_manifest(REPO/'CALLERS.toml')
files=proof._source_files(REPO,proof._string_tuple(data,'source_roots'))
ignored=proof._string_tuple(data,'ignored_path_fragments')
row=next(x for x in proof._boundary_rows(data) if x.identifier=='post_a_artifact_existing_owner_open')
result={'status':'running','before':before,'boundary':row.identifier,'scope':'diagnostic: one original typed boundary over complete original Rust index, collect all unresolved calls; not full CLI','native_tests':0,'started':utc()}
save(OUT/'result.json',result)
start=time.monotonic()
index={p.relative_to(REPO).as_posix():proof._strip_cfg_test_items(proof._strip_rust_non_code(p.read_text())) for p in files}
fields=proof.authority_fields(index,row.receiver_type)
errors=[];observed=[]
for path,code in index.items():
 if path==row.definition_path or proof._is_ignored(path,ignored):continue
 try:
  if proof.has_authority_call(code,row.receiver_type,'open',fields):observed.append(path)
 except proof.UnresolvedTypedReceiver as error:
  errors.append({'path':path,'error':str(error)})
result.update(status='completed',finished=utc(),elapsed_seconds=time.monotonic()-start,rust_files=len(files),observed=observed,expected=row.product_callers,unresolved=errors,after=snapshot())
result['source_unchanged']=result['before']==result['after']
save(OUT/'result.json',result)
print(json.dumps(result,indent=2))
