import importlib.util,pathlib,hashlib,sys,json
r=pathlib.Path('/Users/qianqi/work/hepta-chrono-otel-joint-20261118-2e9b')
p=r/'source/qualification/chrono-otel-joint-20261118/native_owner.py'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='bfe6f5b2dac795fb3d0b6626d419339e0a3bdc01c6c1fb789e8d285056b60ff5'
s=importlib.util.spec_from_file_location('frozen_native_owner',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.OUT=r/'native-validation-2'
sys.argv=[str(p),'f1f036ee44476eec54a79fcbde6a8a99cdcf5829']
raise SystemExit(m.main())
