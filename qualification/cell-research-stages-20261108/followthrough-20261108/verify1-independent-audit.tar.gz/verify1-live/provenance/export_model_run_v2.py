"""Capture a terminal native pilot without changing its files or running models."""

from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile
import time


PILOT = Path('/Users/qianqi/work/verification-cell-verify1-20261108-771b/model-pilot')
RUN = PILOT / 'run-v2'
SOURCE = PILOT / 'source-v2'
OUT = PILOT / 'delivery-v2'
ROOT_FILES = {
    'plan.json', 'asset_preparation_manifest.json', 'runtime_identity.json', 'backend_check.json',
    'trained_readouts.json', 'result.json', 'attempts.jsonl', 'operations.jsonl', 'assessments.jsonl',
    'training_features.jsonl', 'diagnostic_predictions.jsonl', 'panel_labels.jsonl',
    'calibration_observations.jsonl', 'calibration_reports.jsonl', 'verification_receipts.jsonl',
    'trajectory_attempts.jsonl', 'risk_predictions.jsonl', 'decisions.jsonl', 'trajectory_rows.jsonl',
    'failures.jsonl',
}
SOURCE_MANIFEST_SHA = 'ad3ebffe2c6cf39f4c9158901a2b626d1d20c5c206498f0642a8cf50aea9f02d'
SOURCE_CAPSULE_SHA = 'a3f87c341f5b0acbd58af4719eda440bed7e6ffd762634601c8732bd81eafed3'
PROTOCOL_SHA = '3cc0d85a1bedbcf0985be2cf7893455711a09e87695da93188da524c55852bf8'
ASSET_SHA = 'cd66fdf58653d1cf5ee52f4b596debc75fececb0684eeb3ec8f4085d28fde8fc'
PHASE1 = {
    'runtime.py': 'af8b6cf4ed31cb6024c536771f056c5a3481902e011990ab70d43b8e961079a4',
    'contracts.py': '60a38923c46e3df3ad4ec357cbe0287062986e84aa8123267b5ef2954062730d',
    'metrics.py': '3e0a9a996ad62a0feae24a9905c7885352917b195146564b04ac6b15771b302d',
}
MAX_TOTAL = 256 * 1024**2
MAX_FILE = 64 * 1024**2
SECRET = re.compile(rb'(?i)(x-amz-(?:signature|credential|security-token)=|x-goog-signature=|key-pair-id=|[?&](?:signature|policy|access_token)=|authorization[\s"\\:]+(?:bearer|basic)\s+|hf_[A-Za-z0-9]{20,})')


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def key(st):
    return st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns


def read_stable(path, limit=MAX_FILE):
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > limit:
            raise ValueError('unsafe or oversized native file: ' + path.name)
        raw = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
    if len(raw) != before.st_size or key(before) != key(after) or key(after) != key(path.stat(follow_symlinks=False)):
        raise ValueError('native file changed while reading: ' + path.name)
    return raw, key(after)


def write_new(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def scan(raw, name):
    # Do not redact source bytes. If a possible credential appears, stop for a separate derived export.
    if SECRET.search(raw.replace(b'\\/', b'/')):
        raise ValueError('possible signed URL or authorization material in ' + name)


def root_inventory():
    if RUN.is_symlink() or not RUN.is_dir():
        raise ValueError('native run root is unavailable or unsafe')
    selected, excluded = [], []
    for directory, dirs, names in os.walk(RUN, followlinks=False):
        directory = Path(directory)
        for name in list(dirs):
            path = directory / name
            if path.is_symlink():
                raise ValueError('symlink directory in native run')
            if name in {'__pycache__', '.cache', 'hf-cache', 'hf-home', 'hf-xet-cache'}:
                excluded.append({'path': path.relative_to(RUN).as_posix(), 'reason': 'cache directory; retained natively'})
                dirs.remove(name)
        for name in names:
            path = directory / name
            relative = path.relative_to(RUN).as_posix()
            if path.is_symlink():
                raise ValueError('symlink file in native run')
            if name.endswith(('.safetensors', '.gguf', '.bin', '.pt', '.pth')):
                excluded.append({'path': relative, 'reason': 'pretrained model asset not permitted in export', 'bytes': path.stat().st_size})
                continue
            if relative in ROOT_FILES or re.fullmatch(r'state/[0-9a-f]{24}/effects\.sqlite(?:-wal|-shm|-journal)?', relative):
                selected.append(path)
            else:
                raise ValueError('unregistered native run file: ' + relative)
    if len(selected) > 2048:
        raise ValueError('native file inventory exceeds its bound')
    return sorted(selected), excluded


def main():
    started = time.monotonic()
    stdin = sys.stdin.buffer.read(65537)
    if len(stdin) > 65536:
        raise ValueError('delivery binding exceeds its bound')
    binding = json.loads(stdin)
    terminal = binding['pilot_terminal']
    if (terminal.get('job_id') != '1a1bb3d51b5-13c47-15f'
            or terminal.get('state') not in {'succeeded', 'failed', 'cancelled', 'timed_out'}
            or not terminal.get('terminal_publication_confirmed') or not terminal.get('output_complete')
            or not terminal.get('output_durable')):
        raise ValueError('pilot is not authoritatively terminal')
    for name, value in binding['root_reported_terminal'].items():
        if terminal.get(name) != value:
            raise ValueError('parent-provided terminal binding differs')
    if PILOT.is_symlink() or OUT.exists():
        raise ValueError('delivery destination is not create-only')
    stdout, stderr = bytes.fromhex(binding['stdout_hex']), bytes.fromhex(binding['stderr_hex'])
    if len(stdout) != terminal['log_bytes']['stdout']['stored'] or len(stderr) != terminal['log_bytes']['stderr']['stored']:
        raise ValueError('native terminal output is incomplete')
    scan(stdout, 'pilot.stdout.log')
    scan(stderr, 'pilot.stderr.log')
    selected, excluded = root_inventory()
    entries, contents, sources = [], {}, {}

    def include(name, raw, path=None, identity=None, classification='raw observation'):
        relative = PurePosixPath(name)
        if name in contents or relative.is_absolute() or '..' in relative.parts or str(relative) != name:
            raise ValueError('invalid or repeated archive path')
        scan(raw, name)
        if sum(len(item) for item in contents.values()) + len(raw) > MAX_TOTAL:
            raise ValueError('native export exceeds its complete-output bound')
        contents[name] = raw
        entries.append({'path': name, 'bytes': len(raw), 'sha256': sha(raw), 'classification': classification,
                        'native_path': str(path) if path else None,
                        'native_identity': list(identity) if identity else None})
        if path:
            sources[path] = identity

    for path in selected:
        raw, identity = read_stable(path)
        include('run-v2/' + path.relative_to(RUN).as_posix(), raw, path, identity)
    if 'run-v2/plan.json' not in contents:
        raise ValueError('original plan is absent; preserve native attempt for separate failure capture')
    plan = json.loads(contents['run-v2/plan.json'])
    for filename, expected in [('source-manifest-v2.json', SOURCE_MANIFEST_SHA),
                               ('source-capsule-v2.json.gz', SOURCE_CAPSULE_SHA),
                               ('protocol-snapshot-v2.json', PROTOCOL_SHA)]:
        raw, identity = read_stable(PILOT / filename, 131072)
        if sha(raw) != expected:
            raise ValueError('frozen source or protocol identity changed')
        include('binding/' + filename, raw, PILOT / filename, identity, 'frozen source/protocol')
    manifest = json.loads(contents['binding/source-manifest-v2.json'])
    expected_source = {Path(row['path']).name: row['sha256'] for row in manifest['files'] if row['path'].endswith('.py')}
    if plan['source_sha256'] != expected_source or plan['asset_manifest_sha256'] != ASSET_SHA:
        raise ValueError('executed plan differs from source/asset freeze')
    for row in manifest['files']:
        relative = PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or not row['path'].startswith('experiments/verification_cell_verify1/'):
            raise ValueError('unsafe frozen source member')
        path = SOURCE / row['path']
        raw, identity = read_stable(path, 131072)
        if sha(raw) != row['sha256'] or len(raw) != row['bytes']:
            raise ValueError('original tested model source changed')
        include('tested-source/' + row['path'], raw, path, identity, 'original preformat source')
    for name, expected in PHASE1.items():
        path = PILOT / 'phase1-dependency' / 'experiments' / 'verification_cell_verify1' / name
        raw, identity = read_stable(path, 131072)
        if sha(raw) != expected or plan['phase1_sha256'][name.removesuffix('.py')] != expected:
            raise ValueError('frozen host dependency changed')
        include('frozen-phase1/' + name, raw, path, identity, 'actual frozen runtime dependency')
    asset_raw, asset_identity = read_stable(PILOT / 'assets-rog-v3' / 'manifest.json', 131072)
    if sha(asset_raw) != ASSET_SHA:
        raise ValueError('bound native asset manifest changed')
    include('binding/mac-assets-ready-manifest.json', asset_raw, PILOT / 'assets-rog-v3' / 'manifest.json', asset_identity, 'metadata only; no pretrained weights')
    include('binding/pilot-terminal.json', encoded(terminal), classification='authoritative terminal')
    include('binding/parent-terminal-binding.json', encoded(binding['root_reported_terminal']), classification='parent observed terminal binding')
    include('binding/pilot.stdout.log', stdout, classification='complete native pilot output')
    include('binding/pilot.stderr.log', stderr, classification='complete native pilot output')
    own_raw, own_identity = read_stable(Path(__file__), 131072)
    observed_roots = {path.relative_to(RUN).as_posix() for path in selected}
    inventory = {'schema': 'hepta.verify1.model-delivery.v1', 'status': 'CAPTURED_ORIGINAL_TERMINAL_RUN',
        'created_at_utc': datetime.now(timezone.utc).isoformat(), 'native_run': str(RUN),
        'terminal': terminal, 'files': entries, 'excluded_native_paths': excluded,
        'absent_registered_root_files': sorted(ROOT_FILES - observed_roots),
        'sqlite_databases': sum(name.endswith('/effects.sqlite') for name in observed_roots),
        'sqlite_sidecars': sorted(name for name in observed_roots if re.search(r'effects\.sqlite-', name)),
        'planned_trajectories': len(plan['planned_trajectories']),
        'uncompressed_member_bytes': sum(len(value) for value in contents.values()),
        'semantics': 'Original bytes; no pilot rerun, checkpoint, cleanup, summary substitution or JSON rewriting.',
        'learned_readout_parameters_exported': True, 'pretrained_model_bytes_exported': False,
        'export_helper_sha256': sha(own_raw),
        'raw_asset_download_logs_exported': False, 'pilot_rerun': False,
        'archive_metadata': 'Container uid/gid/mtime normalized; original descriptor identities retained here.'}
    inventory_raw = encoded(inventory)
    contents['binding/inventory.json'] = inventory_raw
    # Recheck every named original after all reads; copying cannot silently race an active writer.
    for path, identity in sources.items():
        if key(path.stat(follow_symlinks=False)) != identity:
            raise ValueError('original run or source changed during capture')
    OUT.mkdir()
    write_new(OUT / 'inventory.json', inventory_raw)
    archive_path = OUT / 'verify1-model-run-v2.tar.gz'
    with archive_path.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, raw in sorted(contents.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.uid, info.gid, info.mtime = len(raw), 0o644, 0, 0, 0
                    archive.addfile(info, io.BytesIO(raw))
        output.flush()
        os.fsync(output.fileno())
    for path, identity in sources.items():
        if key(path.stat(follow_symlinks=False)) != identity:
            raise ValueError('original run or source changed while archiving')
    archive_raw, _ = read_stable(archive_path, MAX_FILE)
    receipt = {'schema': 'hepta.verify1.model-export-receipt.v1', 'status': 'EXPORTED_ORIGINAL_BYTES',
        'archive': str(archive_path), 'archive_bytes': len(archive_raw), 'archive_sha256': sha(archive_raw),
        'inventory_sha256': sha(inventory_raw), 'member_count': len(contents),
        'run_file_count': len(selected), 'sqlite_databases': inventory['sqlite_databases'],
        'source_capsule_sha256': SOURCE_CAPSULE_SHA, 'source_manifest_sha256': SOURCE_MANIFEST_SHA,
        'protocol_snapshot_sha256': PROTOCOL_SHA, 'asset_manifest_sha256': ASSET_SHA,
        'wall_seconds': time.monotonic() - started, 'bytes_read_for_member_capture': inventory['uncompressed_member_bytes'],
        'physical_network_bytes': None, 'original_run_bytes_unchanged': True, 'model_calls': 0,
        'export_helper_sha256': sha(own_raw)}
    write_new(OUT / 'export-receipt.json', encoded(receipt))
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(json.dumps({'event': 'model-export-failed', 'error_type': type(error).__name__,
                          'message': str(error)}, sort_keys=True), flush=True)
        sys.exit(1)
