"""Audit exported VERIFY-1 bytes without importing the pilot or running a model."""

from collections import Counter, defaultdict
from datetime import datetime, timezone
import base64
import gzip
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import sys


ROOT = Path(__file__).resolve().parent
RAW = ROOT / "original"
RUN = RAW / "run-v2"
checks = []


def pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def read(relative):
    return parse((RAW / relative).read_bytes())


def rows(name):
    return [parse(line) for line in (RUN / name).read_bytes().splitlines() if line]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False).encode()


def digest(value):
    return sha(canonical(value))


def check(name, condition, details=None):
    checks.append({"check": name, "passed": bool(condition), "details": details})


def close(left, right):
    return math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-12)


def audit():
    inventory = read("binding/inventory.json")
    plan = read("run-v2/plan.json")
    result = read("run-v2/result.json")
    manifest = read("binding/source-manifest-v2.json")
    protocol = read("binding/protocol-snapshot-v2.json")
    runtime = read("run-v2/runtime_identity.json")
    assets = read("run-v2/asset_preparation_manifest.json")
    receipt = parse((ROOT / "provenance/native-export-receipt.json").read_bytes())
    originals = {entry["path"]: entry for entry in inventory["files"]}
    original_hashes = {path: sha((RAW / path).read_bytes()) for path in originals}
    check("all_exported_original_bytes", all(
        (RAW / path).stat().st_size == entry["bytes"] and
        original_hashes[path] == entry["sha256"]
        for path, entry in originals.items()), {"members": len(originals)})
    check("archive_and_inventory_bindings",
          sha((ROOT / "verify1-model-run-v2.tar.gz").read_bytes()) == receipt["archive_sha256"]
          and sha((RAW / "binding/inventory.json").read_bytes()) == receipt["inventory_sha256"])
    check("terminal_binding",
          inventory["terminal"] == read("binding/pilot-terminal.json")
          and inventory["terminal"]["job_id"] == "1a1bb3d51b5-13c47-15f"
          and inventory["terminal"]["state"] == "succeeded"
          and inventory["terminal"]["exit_code"] == 0)
    check("stdout_equals_original_result", read("binding/pilot.stdout.log") == {
        key: result[key] for key in ["status", "observed_trajectories", "planned_trajectories",
                                     "model_forwards", "failure"]})
    check("runtime_protocol_diff_only_asset_binding",
          {key: value for key, value in plan.items() if key != "asset_manifest_sha256"}
          == {key: value for key, value in protocol.items() if key != "asset_manifest_sha256"}
          and protocol["asset_manifest_sha256"] is None)
    check("frozen_source_protocol_hashes",
          sha((RAW / "binding/source-manifest-v2.json").read_bytes()) == receipt["source_manifest_sha256"]
          and sha((RAW / "binding/source-capsule-v2.json.gz").read_bytes()) == receipt["source_capsule_sha256"]
          and sha((RAW / "binding/protocol-snapshot-v2.json").read_bytes()) == receipt["protocol_snapshot_sha256"])
    source_ok = all(
        sha((RAW / "tested-source" / entry["path"]).read_bytes()) == entry["sha256"]
        and (RAW / "tested-source" / entry["path"]).stat().st_size == entry["bytes"]
        for entry in manifest["files"])
    expected_python = {Path(entry["path"]).name: entry["sha256"]
                       for entry in manifest["files"] if entry["path"].endswith(".py")}
    capsule = parse(gzip.decompress((RAW / "binding/source-capsule-v2.json.gz").read_bytes()))
    capsule_ok = len(capsule) == len(manifest["files"]) and all(
        base64.b64decode(item["base64"], validate=True) == (RAW / "tested-source" / item["path"]).read_bytes()
        and item["sha256"] == sha((RAW / "tested-source" / item["path"]).read_bytes())
        for item in capsule)
    check("tested_source_capsule_and_plan_bindings", source_ok and capsule_ok
          and expected_python == plan["source_sha256"],
          {"source_files": len(manifest["files"]), "python_files": len(expected_python)})
    check("frozen_phase1_dependencies", all(
        sha((RAW / "frozen-phase1" / (name + ".py")).read_bytes()) == value
        for name, value in plan["phase1_sha256"].items()))
    original_asset_bytes = (RAW / "binding/mac-assets-ready-manifest.json").read_bytes()
    check("asset_manifest_binding", sha(original_asset_bytes)
          == plan["asset_manifest_sha256"] == runtime["asset_manifest_sha256"]
          == receipt["asset_manifest_sha256"] and parse(original_asset_bytes) == assets,
          {"bound_original_sha256": sha(original_asset_bytes),
           "journal_serialized_copy_sha256": sha((RUN / "asset_preparation_manifest.json").read_bytes()),
           "parsed_content_equal": parse(original_asset_bytes) == assets,
           "byte_identity_equated": False})
    models = []
    for key, item in runtime["models"].items():
        asset = next(row for row in assets["models"] if row["repo_id"] == item["repo"])
        declared_files = {row["filename"]: row["sha256"] for row in asset["files"]
                          if row["status"] == "VERIFIED"}
        check("model_binding:" + key,
              all(item[field] == plan["models"][key][field] for field in ["repo", "revision", "config_sha256"])
              and item["files"] == declared_files
              and asset["resolved_revision"] == item["revision"]
              and item["base_sha256"] == digest({field: item[field] for field in ["repo", "revision", "files"]}))
        models.append({"key": key, "repository": item["repo"], "revision": item["revision"],
                       "base_identity_sha256": item["base_sha256"],
                       "weights_sha256": item["files"]["model.safetensors"],
                       "weights_rehashed_in_this_audit": False,
                       "reason": "Pretrained weights remain on the original host; this audit checks retained native asset receipts."})

    ops = rows("operations.jsonl")
    starts = rows("attempts.jsonl")
    opmap = {row["operation_id"]: row for row in ops}
    expected_ids = {f"op/{i}" for i in range(1, len(ops) + 1)}
    check("operation_roster_complete", len(opmap) == len(ops) == len(starts)
          and set(opmap) == expected_ids
          and {row["operation_id"] for row in starts} == expected_ids
          and all(row["status"] == "started" for row in starts)
          and all(opmap[row["operation_id"]][key] == row[key]
                  for row in starts for key in ["kind", "context", "started_unix_ns"]))
    check("operation_statuses_completed", all(row["status"] == "completed" for row in ops))
    counters = Counter(assessments=0, forward_passes=0, input_tokens=0)
    cumulative_errors, likelihood_errors, prompt_errors = [], [], []
    for row in ops:
        if row["kind"] in {"model_score", "model_features"}:
            counters["assessments"] += 1
            token_count = len(row["prompt_token_ids"])
            if row["kind"] == "model_features":
                counters["forward_passes"] += 1
                counters["input_tokens"] += token_count
            else:
                candidates = row["candidate_token_ids"]
                single = all(len(ids) == 1 for ids in candidates)
                counters["forward_passes"] += 1 if single else len(candidates)
                counters["input_tokens"] += token_count if single else sum(token_count + len(ids) - 1 for ids in candidates)
                yes, no = row["candidate_log_likelihoods"]
                normalized = 1 / (1 + math.exp(no - yes))
                if not close(normalized, row["score"]):
                    likelihood_errors.append(row["operation_id"])
            if (row["prompt_tokens"] != token_count or digest(row["prompt"]) != row["prompt_sha256"]
                    or digest(row["view"]) != row["evidence_sha256"]
                    or set(row["view"]) != {"version", "tick", "acks"}
                    or row["view"]["tick"] != len(row["view"]["acks"])
                    or row["view"]["version"] != "ack-only-v1"):
                prompt_errors.append(row["operation_id"])
        if dict(counters) != row["counters"]:
            cumulative_errors.append(row["operation_id"])
    check("independently_recomputed_forward_token_counters",
          not cumulative_errors and dict(counters) == result["inference_counters"]
          and counters["forward_passes"] == result["model_forwards"],
          {"counters": dict(counters), "mismatched_operations": cumulative_errors})
    check("model_score_likelihood_recomputation", not likelihood_errors,
          {"scores": sum(row["kind"] == "model_score" for row in ops), "mismatches": likelihood_errors})
    check("model_prompt_and_public_view_bindings", not prompt_errors,
          {"mismatches": prompt_errors})

    cases = {split: {row["goal"]["task_id"]: row for row in roster}
             for split, roster in plan["cases"].items()}
    all_cases = {key: row for roster in cases.values() for key, row in roster.items()}
    check("split_case_and_group_identifiers_disjoint", len(all_cases) == sum(map(len, cases.values()))
          and all(not {row["source_group"] for row in cases[left].values()}
                  & {row["source_group"] for row in cases[right].values()}
                  for left, right in [("train", "calibration"), ("train", "confirmation"), ("calibration", "confirmation")]))
    training = rows("training_features.jsonl")
    heads = read("run-v2/trained_readouts.json")
    training_keys = {(row["case_id"], row["tick"]) for row in training}
    check("training_rows_are_complete_and_train_only",
          len(training_keys) == len(training) == 36
          and training_keys == {(case, tick) for case in cases["train"] for tick in [0, 2, 3]}
          and all(row["split"] == "train" and row["source_group"] == cases["train"][row["case_id"]]["source_group"] for row in training)
          and all(opmap[row["feature_operation_id"]]["feature_sha256"] == digest(row["feature"])
                  and opmap[row["label_operation_id"]]["result"] == row["label"]
                  for row in training))
    head_checks = []
    for head in heads:
        head_checks.append(
            head["training_data_sha256"] == digest(training)
            and set(head["training_case_ids"]) == set(cases["train"])
            and set(head["bootstrap_case_ids"]) <= set(cases["train"])
            and not set(head["bootstrap_case_ids"]) & set(cases["confirmation"])
            and head["parameters_sha256"] == digest({key: head[key] for key in ["mean", "scale", "coefficients", "bias"]})
            and head["adapter_sha256"] == digest({key: value for key, value in head.items() if key != "adapter_sha256"})
            and head["base_weights_updated"] is False and head["lora"] is False)
    check("three_real_train_only_readout_parameter_bindings", all(head_checks)
          and len(heads) == len({head["parameters_sha256"] for head in heads}) == 3
          and [head["seed"] for head in heads] == plan["head_training"]["seeds"])
    training_operation = [row for row in ops if row["kind"] == "readout_training"]
    first_calibration = min(row["started_unix_ns"] for row in ops if row["context"].get("split") == "calibration")
    first_confirmation = min(row["started_unix_ns"] for row in ops if row["context"].get("split") == "confirmation")
    last_training = max(row["started_unix_ns"] for row in ops if row["context"].get("split") == "train")
    last_calibration = max(row["started_unix_ns"] for row in ops if row["context"].get("split") == "calibration")
    check("observed_training_calibration_confirmation_order", len(training_operation) == 1
          and last_training < first_calibration and last_calibration < first_confirmation,
          {"readout_training_operations": len(training_operation),
           "no_after_confirmation_training_operations": not any(row["kind"] == "readout_training" and row["started_unix_ns"] >= first_confirmation for row in ops)})

    assessments = rows("assessments.jsonl")
    amap = {row["assessment_id"]: row for row in assessments}
    assessment_errors = []
    prior = (sum({row["case_id"]: row["label"] for row in training}.values()) + 1) / (len(cases["train"]) + 2)
    for row in assessments:
        expected_members = 0 if row["arm"] in {"constant_prior", "fixed_check"} else 1 if row["arm"] == "single" else 2
        value = sum(member["score"] for member in row["members"]) / len(row["members"]) if row["members"] else prior
        valid = row["assessment_id"] in opmap and opmap[row["assessment_id"]]["kind"] == "score_aggregation"
        valid &= len(row["members"]) == expected_members and close(row["score"], value)
        valid &= row["evidence_sha256"] == digest(row["view"]) and row["production_authority"] == "NONE" and row["calibrated"] is False
        for member in row["members"]:
            observed = opmap.get(member["operation_id"], {})
            valid &= all(observed.get(key) == member[key] for key in ["base_sha256", "adapter_sha256", "prompt_sha256", "evidence_sha256", "score"])
        if not valid:
            assessment_errors.append(row["assessment_id"])
    check("all_aggregated_scores_bind_original_member_operations", not assessment_errors
          and len(amap) == len(assessments), {"assessments": len(assessments), "errors": assessment_errors})
    calibration = rows("calibration_observations.jsonl")
    reports = rows("calibration_reports.jsonl")
    calibration_errors = []
    for report in reports:
        arm, tick = report["scope"]["attempt_id"].split("/tick/")
        group = [row for row in calibration if row["arm"] == arm and row["tick"] == int(tick)]
        value = sum((row["score"] - row["label"]) ** 2 for row in group) / len(group)
        if (len(group) != report["sample_count"] or digest(group) != report["data_sha256"]
                or not close(value, report["metric_value"])
                or {row["case_id"] for row in group} != set(cases["calibration"])
                or any(opmap[row["label_operation_id"]]["result"] != row["label"] for row in group)):
            calibration_errors.append(report["scope"]["attempt_id"])
    check("calibration_brier_reports_recomputed_from_disjoint_rows", len(reports) == 14 and not calibration_errors,
          {"reports": len(reports), "observations": len(calibration), "errors": calibration_errors})

    trajectories = rows("trajectory_rows.jsonl")
    trajectory_attempts = rows("trajectory_attempts.jsonl")
    panels = rows("panel_labels.jsonl")
    expected = {(row["case_id"], row["arm"]) for row in plan["planned_trajectories"]}
    tmap = {(row["case_id"], row["arm"]): row for row in trajectories}
    start_roster = Counter((row["case_id"], row["arm"], row["status"]) for row in trajectory_attempts)
    check("108_planned_trajectories_have_unique_started_and_completed_rows",
          set(tmap) == expected and len(tmap) == len(trajectories) == len(expected) == 108
          and all(row["status"] == "completed" and row["split"] == "confirmation" for row in trajectories)
          and start_roster == Counter({(case, arm, status): 1 for case, arm in expected for status in ["started", "completed"]}))
    expected_panels = {(split, key) for split in ["train", "calibration"] for key in cases[split]}
    check("24_uninterrupted_panels_complete", len(panels) == len(expected_panels)
          and {(row["split"], row["case_id"]) for row in panels} == expected_panels
          and all(row["all_three_effect_steps_completed"] for row in panels))
    db_errors, db_records = [], []
    db_expected = {(row["case_id"], row["arm"]): row for row in trajectories}
    db_expected.update({(row["case_id"], row["attempt"]): row for row in panels})
    for (case_id, attempt), row in db_expected.items():
        path = RUN / "state" / digest({"case": case_id, "attempt": attempt})[:24] / "effects.sqlite"
        goal = all_cases[case_id]["goal"]
        with sqlite3.connect("file:" + path.as_posix() + "?mode=ro&immutable=1", uri=True) as connection:
            resources = dict(connection.execute("SELECT name,value FROM resources"))
            accepted = connection.execute("SELECT epoch,goal,evidence FROM accepted").fetchall()
            meta = connection.execute("SELECT epoch,tick FROM meta").fetchall()
            goal_rows = connection.execute("SELECT payload FROM journal WHERE kind='goal'").fetchall()
            intents = connection.execute("SELECT operation_id,tick,finished FROM intents").fetchall()
        actual_error = resources != {key: goal[key] for key in ["left", "right"]}
        expected_error = row.get("outcome_error", row.get("label"))
        actual_accepted = bool(accepted)
        expected_accepted = row.get("accepted", False)
        valid = actual_error is expected_error and actual_accepted is expected_accepted
        valid &= len(goal_rows) == 1 and parse(goal_rows[0][0]) == goal
        valid &= len(meta) == 1 and len(accepted) <= 1
        valid &= not accepted or (accepted[0][0] == meta[0][0] and accepted[0][1] == digest(goal))
        reached = row.get("reached_step", 3)
        valid &= len(intents) == reached and {entry[1] for entry in intents} == set(range(1, reached + 1))
        valid &= all(entry[0] == f"{case_id}/step/{entry[1]}" and entry[2] == 1 for entry in intents)
        if not valid:
            db_errors.append({"case_id": case_id, "attempt": attempt})
        db_records.append({"case_id": case_id, "attempt": attempt, "outcome_error": actual_error,
                           "accepted": actual_accepted, "intent_count": len(intents)})
    check("132_original_sqlite_states_independently_match_labels_and_acceptance",
          len(db_records) == 132 and len(list((RUN / "state").glob("*/effects.sqlite"))) == 132
          and not db_errors, {"databases": len(db_records), "errors": db_errors})

    decisions = rows("decisions.jsonl")
    risks = rows("risk_predictions.jsonl")
    rmap = {(row["scope"]["task_id"], row["scope"]["attempt_id"], row["observed_step"]): row for row in risks}
    decision_errors = []
    for row in decisions:
        key = (row["case_id"], row["arm"], row["tick"])
        risk = rmap.get(key)
        assessment = amap[row["assessment_id"]]
        goal = cases["confirmation"][row["case_id"]]["goal"]
        valid = risk is not None and risk["probability"] == row["raw_model_score"] == assessment["score"]
        valid &= risk is not None and risk["evidence_sha256"] == row["evidence_sha256"] == assessment["evidence_sha256"]
        valid &= risk is not None and risk["scope"]["event"] == plan["event"]
        valid &= risk is not None and risk["scope"]["subject_sha256"] == digest(goal)
        valid &= risk is not None and risk["scope"]["state_version"] == row["tick"]
        if not valid:
            decision_errors.append(key)
    check("risk_event_and_online_decision_bindings", len(rmap) == len(decisions) == len(risks) == 156
          and not decision_errors, {"errors": decision_errors})
    checks_ops = [row for row in ops if row["kind"] in {"mandatory_host_check", "optional_host_check"}]
    verification = rows("verification_receipts.jsonl")
    verification_errors = []
    for index, (operation, report) in enumerate(zip(checks_ops, verification)):
        host = operation["result"]
        ctx, scope = operation["context"], report["scope"]
        valid = all(report[key] == host[key] for key in ["property", "assumptions", "checker_id", "checker_version", "evidence_sha256", "checked_step", "verdict", "reason", "residual_obligations"])
        valid &= scope["task_id"] == ctx["case_id"] and scope["attempt_id"] == ctx["arm"]
        valid &= scope["subject_sha256"] == host["subject_sha256"] and scope["state_version"] == host["state_version"]
        valid &= scope["event"] == "actual_goal_and_owner_snapshot_property" and scope["event"] != plan["event"]
        valid &= host["production_authority"] == "NONE" and (not host["accepted"] or operation["kind"] == "mandatory_host_check")
        if not valid:
            verification_errors.append(index)
    check("host_property_receipts_are_distinct_from_risk_event", len(checks_ops) == len(verification) == 178
          and not verification_errors, {"errors": verification_errors})

    arm_results = {}
    for arm in sorted({row["arm"] for row in trajectories}):
        group = [row for row in trajectories if row["arm"] == arm]
        ds = [row for row in decisions if row["arm"] == arm]
        accepted = [row for row in group if row["accepted"]]
        declared = sum(row["declared_check_cost"] for row in ds if row["selection"] == "check")
        compact = {"planned": sum(candidate == arm for _, candidate in expected),
                   "completed": sum(row["status"] == "completed" for row in group),
                   "accepted": len(accepted), "accepted_errors": sum(row["outcome_error"] is True for row in accepted),
                   "unknown_labels": sum(row["outcome_error"] is None for row in group),
                   "observed_final_value_errors": sum(row["outcome_error"] is True for row in group),
                   "interrupted": sum(row["interrupted"] for row in group),
                   "checks": sum(row["selection"] == "check" for row in ds),
                   "deferred": sum(row["selection"] == "defer" for row in ds),
                   "declared_optional_cost_units": declared,
                   "distinct_initial_scores": sorted({row["risk"] for row in group if row["initial_assessment"] is not None})}
        original = result["arms"][arm]
        check("original_arm_summary_recomputed:" + arm,
              compact["planned"] == original["planned"] and compact["completed"] == original["completed"]
              and compact["accepted"] == original["actual_policy_accepted"]["count"]
              and compact["accepted_errors"] == original["actual_policy_accepted"]["known_errors"]
              and compact["observed_final_value_errors"] == original["observed_actual_state_errors"]["known_errors"]
              and close(declared, original["declared_optional_cost_spent"]))
        arm_results[arm] = compact
    interventions = defaultdict(dict)
    for row in decisions:
        if row["intervention"] is not None:
            interventions[row["case_id"]][row["intervention"]["name"]] = row
    intervention_ok = len(interventions) == 6
    for panel in interventions.values():
        intervention_ok &= set(panel) == {"risk_low", "risk_high", "cost_low", "cost_high"}
        intervention_ok &= len({row["matched_evidence_parent_sha256"] for row in panel.values()}) == 1
        intervention_ok &= len({row["raw_model_score"] for row in panel.values()}) == 1
        intervention_ok &= panel["risk_low"]["selection"] == panel["cost_high"]["selection"] == "defer"
        intervention_ok &= panel["risk_high"]["selection"] == panel["cost_low"]["selection"] == "check"
    check("six_actual_matched_risk_cost_interventions", intervention_ok)
    check("all_primary_arms_accept_positive_controls_and_reject_wrong_values", all(
        all(row["accepted"] for row in trajectories if row["arm"] == arm and row["fault"] in {"clean", "missing_receipt"})
        and all(not row["accepted"] for row in trajectories if row["arm"] == arm and row["fault"] in {"semantic_error", "partial_success", "common_misjudgment"})
        for arm in plan["arms"]))

    cost_by_kind = {}
    for kind in sorted({row["kind"] for row in ops}):
        group = [row for row in ops if row["kind"] == kind]
        cost_by_kind[kind] = {"operations": len(group), "wall_ns": sum(row["wall_ns"] for row in group),
                              "cpu_ns": sum(row["cpu_ns"] for row in group),
                              "failed": sum(row["status"] != "completed" for row in group)}
    check("operation_cost_totals_recomputed", cost_by_kind == result["cost"]["operations_by_kind"])
    check("no_failed_or_unresolved_pilot_attempt_hidden",
          result["failure"] is None and not (RUN / "failures.jsonl").exists()
          and all(row["status"] == "completed" for row in ops + trajectories)
          and set(inventory["absent_registered_root_files"]) == {"failures.jsonl"})
    check("all_raw_member_hashes_stable_after_readonly_audit", all(
        sha((RAW / path).read_bytes()) == old_hash for path, old_hash in original_hashes.items()))

    preparation = parse((ROOT / "provenance/preparation-cost-description.json").read_bytes())
    return {
        "schema": "hepta.verify1.independent-export-audit.v1",
        "observed_at_utc": datetime.now(timezone.utc).isoformat(),
        "audit_method": "Independent standard-library arithmetic, scope/operation joins and read-only SQLite queries; pilot source was read but not imported or executed.",
        "model_calls_during_audit": 0, "training_runs_during_audit": 0,
        "engineering_audit_status": "PASS" if all(row["passed"] for row in checks) else "FAIL",
        "scientific_admission": "HOLD", "production_authority": "NONE",
        "published_model_source_commit": None,
        "publication_state": "The model candidate is native-executed and exported; no claim that it exists in observed PR 5351 head 6eb0f8d717cfd1234bbbe385d5d5fb99bde5c521.",
        "source": {"archive_sha256": receipt["archive_sha256"], "source_capsule_sha256": receipt["source_capsule_sha256"],
                   "source_manifest_sha256": receipt["source_manifest_sha256"], "protocol_snapshot_sha256": receipt["protocol_snapshot_sha256"],
                   "asset_manifest_sha256": receipt["asset_manifest_sha256"], "native_job_id": inventory["terminal"]["job_id"],
                   "native_run": inventory["native_run"], "tested_source_files": len(manifest["files"]),
                   "frozen_phase1_sha256": plan["phase1_sha256"]},
        "models": models, "runtime_dependencies": runtime["dependencies"], "runtime_device": runtime["device"],
        "counts": {"planned_trajectories": len(expected), "completed_trajectories": len(trajectories),
                   "primary_trajectories": sum(row["arm"] in plan["arms"] for row in trajectories),
                   "intervention_trajectories": sum(row["arm"].startswith("intervention/") for row in trajectories),
                   "uninterrupted_panels": len(panels), "sqlite_databases": len(db_records),
                   "operation_started_records": len(starts), "operation_terminal_records": len(ops),
                   "operation_failures": sum(row["status"] != "completed" for row in ops),
                   "trajectory_failures": sum(row["status"] != "completed" for row in trajectories),
                   "model_forwards": counters["forward_passes"], "backend_assessments": counters["assessments"],
                   "aggregated_assessments": len(assessments), "input_tokens": counters["input_tokens"],
                   "model_score_operations": sum(row["kind"] == "model_score" for row in ops),
                   "model_feature_operations": sum(row["kind"] == "model_features" for row in ops),
                   "risk_predictions": len(risks), "policy_decisions": len(decisions),
                   "property_receipts": len(verification), "trained_readouts": len(heads)},
        "scope_and_splits": {"task_kind": "Controlled synthetic SQLite two-field tasks with genuine local model forwards",
                             "cases_per_split": {key: len(value) for key, value in cases.items()},
                             "source_groups_per_split": {key: sorted({row["source_group"] for row in value.values()}) for key, value in cases.items()},
                             "training_features": len(training), "readout_seeds": [head["seed"] for head in heads],
                             "primary_readout_seeds": [head["seed"] for head in heads[:2]],
                             "diagnostic_only_readout_seed": heads[2]["seed"],
                             "base_weights_updated": False, "lora": False,
                             "administrative_split_identifiers_disjoint": True,
                             "independent_natural_tasks_established": False,
                             "public_observation_templates_shared_across_splits": True,
                             "population_reliability_or_trajectory_coverage_established": False},
        "arm_results": arm_results,
        "cost": {"overall_execution_wall_seconds": result["cost"]["overall_wall_ns"] / 1e9,
                 "controller_cpu_seconds": result["cost"]["controller_cpu_ns"] / 1e9,
                 "accumulated_preparation_wall_seconds": preparation["accumulated_preparation_wall_seconds"],
                 "preparation_wall_scope": preparation["accumulated_preparation_scope"],
                 "retained_prior_preparation_terminal_states": [row["terminal"]["state"] for row in preparation["prior_attempts"]],
                 "observed_application_download_payload_bytes": preparation["range_download"]["application_cost"]["network_payload_bytes_observed"],
                 "physical_energy_joules": None, "provider_cost": None, "network_wire_bytes": None,
                 "full_physical_cost_qualified": False, "matched_actual_budget_qualified": False,
                 "components_are_additive_elapsed_time": False,
                 "operation_costs_by_kind": cost_by_kind},
        "remaining_limits": [
            "Original native receipts bind asset identities, but pretrained weights are not present in this archive for this reviewer to rehash.",
            "All models see only ACK booleans and tick; initial inputs are identical and most injected errors are observationally indistinguishable.",
            "Uncalibrated YES/NO likelihood scores and frozen-feature readouts do not establish a calibrated probability or independent-voter gain.",
            "Each primary arm accepted 4 of 12 trajectories with 0 accepted errors because mandatory host readback retains effect authority; selector superiority is unestablished.",
            "Separate split/group names reuse synthetic templates and do not establish independent natural tasks or external evaluator authentication.",
            "Two primary voter invocations are an opportunity cap; actual token, forward, training and wall costs are unequal.",
            "Preparation cancellation and timeout are retained; energy, wire bytes, provider cost and complete historical construction cost are unknown.",
            "The scientific S1 same-budget net-terminal-benefit and old-capability-retention gate remains unqualified."
        ],
        "checks": checks,
    }


if __name__ == "__main__":
    output = audit()
    destination = ROOT / "AUDIT_V2.json"
    with destination.open("x", encoding="utf-8") as stream:
        json.dump(output, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"output": str(destination), "engineering_audit_status": output["engineering_audit_status"],
                      "checks": len(checks), "failed_checks": [row["check"] for row in checks if not row["passed"]],
                      "scientific_admission": output["scientific_admission"], "counts": output["counts"]}, sort_keys=True))
    sys.exit(0 if output["engineering_audit_status"] == "PASS" else 1)
