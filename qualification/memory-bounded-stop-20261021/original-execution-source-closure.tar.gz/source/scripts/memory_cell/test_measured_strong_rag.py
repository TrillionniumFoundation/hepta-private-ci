"""Observer transparency and failure durability, using no pretrained weights."""

import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest

import torch

from measured_strong_rag import CallObserver


class TinyModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.tensor([1.0]), requires_grad=False)
        self.generation_config = SimpleNamespace(to_dict=lambda: {"do_sample": False})

    def generate(self, *, input_ids):
        return torch.cat((input_ids, torch.tensor([[9, 10]])), dim=1)


class TinyReader:
    identity = "test-reader"
    profile = "test-profile"

    def __init__(self, *, fail=False):
        self.model = TinyModel().eval()
        self.fail = fail

    def compile_input(self, *_args, **_kwargs):
        return [1, 2, 3], {"input_tokens": 3}

    def answer(self, query, bundle, originals, **kwargs):
        ids, receipt = self.compile_input(query, bundle, originals, **kwargs)
        if self.fail:
            raise ValueError("original failure is retained")
        self.model.generate(input_ids=torch.tensor([ids]))
        return "raw answer [E1]", receipt | {"generated_tokens": 2}


class ObserverTests(unittest.TestCase):
    def run_observed(self, *, fail=False):
        query = SimpleNamespace(identity="q", family="family")
        bundle = SimpleNamespace(seal=lambda: "bundle", mode="test")
        with TemporaryDirectory() as tmp:
            path = Path(tmp) / "observations.jsonl"
            with path.open("x", encoding="utf-8") as stream:
                reader = TinyReader(fail=fail)
                observer = CallObserver(stream)
                observer.attach(reader)
                if fail:
                    with self.assertRaisesRegex(ValueError, "original failure"):
                        reader.answer(query, bundle, {})
                    result = None
                else:
                    result = reader.answer(query, bundle, {})
                self.assertIsNone(observer.active)
                self.assertEqual(observer.ordinal, 1)
            return result, json.loads(path.read_text())

    def test_observer_preserves_values_and_full_tokens(self):
        result, row = self.run_observed()
        self.assertEqual(result, ("raw answer [E1]", {"input_tokens": 3, "generated_tokens": 2}))
        self.assertEqual(row["raw_answer"], result[0])
        self.assertEqual(row["input_token_ids"], [1, 2, 3])
        self.assertEqual(row["complete_output_token_ids"], [1, 2, 3, 9, 10])
        self.assertEqual(row["status"], "succeeded")
        self.assertGreater(row["sampled_peak_rss_bytes"], 0)
        self.assertIsNone(row["joules"])
        self.assertIsNone(row["physical_flops"])

    def test_observer_durably_records_original_exception(self):
        _, row = self.run_observed(fail=True)
        self.assertEqual(row["status"], "failed")
        self.assertEqual(row["error_type"], "ValueError")
        self.assertEqual(row["input_token_ids"], [1, 2, 3])
        self.assertNotIn("raw_answer", row)
        self.assertNotIn("complete_output_token_ids", row)


if __name__ == "__main__":
    unittest.main()
