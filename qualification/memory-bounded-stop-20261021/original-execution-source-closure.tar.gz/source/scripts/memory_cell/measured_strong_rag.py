"""Observe the original pinned 40+72 reader trial without changing its policy.

This opt-in observer records complete input/output token IDs, raw answers,
per-call sampled process RSS and CPU seconds. It delegates all selection,
generation, scoring, label timing and the 180-second host stop to the original
runner. RSS is sampled, not an exact allocator high-water mark. FLOPs/energy
remain unknown. These exposed development tasks do not become a new holdout.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import subprocess
import sys
import threading
import time


def utc():
    return datetime.now(timezone.utc).isoformat()


def seal(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


class CallObserver:
    def __init__(self, journal, *, interval=0.025):
        self.journal = journal
        self.interval = interval
        self.ordinal = 0
        self.active = None

    @staticmethod
    def rss():
        # /proc/self remains correct when PID namespaces make getpid() differ
        # from the PIDs exposed by the mounted procfs. Never inspect another PID.
        return int(Path("/proc/self/statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")

    def attach(self, reader):
        answer = reader.answer
        compile_input = reader.compile_input
        generate = reader.model.generate

        def observed_input(*args, **kwargs):
            ids, receipt = compile_input(*args, **kwargs)
            if self.active is not None:
                self.active["input_token_ids"] = list(ids)
                self.active["input_receipt"] = receipt
            return ids, receipt

        def observed_generate(*args, **kwargs):
            if self.active is not None:
                self.active["explicit_generation_arguments"] = {
                    key: value for key, value in kwargs.items()
                    if key not in ("input_ids", "attention_mask")
                }
                self.active["model_generation_config"] = reader.model.generation_config.to_dict()
            output = generate(*args, **kwargs)
            if self.active is not None:
                self.active["complete_output_token_ids"] = output[0].tolist()
            return output

        def observed_answer(query, bundle, originals, **kwargs):
            import torch

            if self.active is not None:
                raise RuntimeError("observer requires serial original reader calls")
            self.ordinal += 1
            cpu_start = resource.getrusage(resource.RUSAGE_SELF)
            started = time.perf_counter()
            row = dict(
                schema="hepta.memory-strong-rag.call-observation.v1",
                call_ordinal=self.ordinal,
                question_id=query.identity,
                question_family=query.family,
                evidence_bundle_digest=bundle.seal(),
                arm=bundle.mode,
                started_at=utc(),
                pid=os.getpid(),
                procfs_self_pid=os.readlink("/proc/self"),
                sampled_peak_rss_bytes=self.rss(),
                rss_sample_count=1,
                rss_sample_interval_seconds=self.interval,
                rss_measurement="sampled whole process; not exact allocator peak",
                torch_seed_observed=torch.initial_seed(),
                seed_overridden=False,
                torch_intra_op_threads=torch.get_num_threads(),
                torch_inter_op_threads=torch.get_num_interop_threads(),
                device="cpu",
                dtype=str(next(reader.model.parameters()).dtype),
                model_training=reader.model.training,
                reader_identity=reader.identity,
                reader_profile=reader.profile,
                physical_flops=None,
                joules=None,
                billed_cost=None,
                production_accepted=False,
            )
            self.active = row
            stopped = threading.Event()

            def sample():
                while not stopped.wait(self.interval):
                    row["sampled_peak_rss_bytes"] = max(
                        row["sampled_peak_rss_bytes"], self.rss()
                    )
                    row["rss_sample_count"] += 1

            sampler = threading.Thread(target=sample, daemon=True)
            sampler.start()
            try:
                result = answer(query, bundle, originals, **kwargs)
                row.update(status="succeeded", raw_answer=result[0], receipt=result[1])
                return result
            except BaseException as error:
                row.update(
                    status="failed", error_type=type(error).__name__,
                    error=str(error)[:1024],
                )
                raise
            finally:
                stopped.set()
                sampler.join()
                row["sampled_peak_rss_bytes"] = max(
                    row["sampled_peak_rss_bytes"], self.rss()
                )
                row["rss_sample_count"] += 1
                cpu_end = resource.getrusage(resource.RUSAGE_SELF)
                row.update(
                    completed_at=utc(),
                    observed_call_seconds=time.perf_counter() - started,
                    process_user_cpu_seconds=cpu_end.ru_utime - cpu_start.ru_utime,
                    process_system_cpu_seconds=cpu_end.ru_stime - cpu_start.ru_stime,
                    cumulative_process_high_water_rss_bytes=cpu_end.ru_maxrss * 1024,
                    observer_included_in_process_measurement=True,
                )
                self.active = None
                self.journal.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
                self.journal.flush()
                os.fsync(self.journal.fileno())
                print(json.dumps({
                    "observed_call": self.ordinal, "question": query.identity,
                    "status": row["status"],
                    "seconds": row["observed_call_seconds"],
                    "sampled_peak_rss_bytes": row["sampled_peak_rss_bytes"],
                }), flush=True)

        reader.compile_input = observed_input
        reader.model.generate = observed_generate
        reader.answer = observed_answer
        return reader


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--observations", type=Path, required=True)
    parser.add_argument("original_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    inner = args.original_args
    if inner and inner[0] == "--":
        inner = inner[1:]
    if not inner or inner[0] not in ("calibrate", "evaluate"):
        parser.error("delegate exactly one original calibrate/evaluate command")
    import strong_rag_trial as original

    source = Path(original.__file__).resolve()
    repo = source.parents[2]
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
    if head != os.environ.get("HEPTA_MEMORY_TESTED_COMMIT"):
        raise ValueError("source commit must be the actual checked-out HEAD")
    subprocess.run(["git", "diff", "--exit-code", "HEAD", "--", "scripts/memory_cell"],
                   cwd=repo, check=True, stdout=subprocess.DEVNULL)
    args.observations.mkdir()
    seal(args.observations / "observer-run.json", dict(
        schema="hepta.memory-strong-rag.observer.v1",
        source_commit=head,
        observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        original_runner_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        original_arguments=inner,
        hostname=platform.node(),
        platform=platform.platform(),
        python=sys.version,
        started_at=utc(),
        temporary_execution_container=True,
        dedicated_project_host_attested=False,
        original_generation_and_scoring_unchanged=True,
        original_host_stop_seconds=original.MAX_READER_CALL_SECONDS,
        original_cases_are_exposed_development=True,
        independent_source_family_count=0,
        authority="DENY_ALL", mode="SHADOW_ONLY", release="NO_GO",
    ))
    make_reader = original._reader
    with (args.observations / "calls.jsonl").open("x", encoding="utf-8") as journal:
        observer = CallObserver(journal)

        def observed_reader(*params, **options):
            reader, stage, inventory = make_reader(*params, **options)
            return observer.attach(reader), stage, inventory

        original._reader = observed_reader
        sys.argv = [str(source), *inner]
        try:
            original.main()
        finally:
            seal(args.observations / "observer-completion.json", dict(
                completed_at=utc(), observed_calls=observer.ordinal,
                call_journal_sha256=hashlib.sha256(
                    (args.observations / "calls.jsonl").read_bytes()
                ).hexdigest(),
                original_success_requires_original_reports=True,
                production_accepted=False,
            ))


if __name__ == "__main__":
    main()
