"""Assemble C + frozen P + frozen U in the task-owned followup worktree."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path("/home/qian-qi/work/cell-integration-20261108-08b6")
SOURCE = ROOT / "followup-source"
OUTPUT = ROOT / "followup-validation-001"
C = "b839558b26c2e5b667055ca4af4ad749ae41c043"
P = "54d73e897e088369b37db1575af146d228b5db25"
U = "0e6fbff34b4f9ad9555de057d8807666f2668e84"
UTREE = "4f9e28301d0568b199074d920fd2e90cf181c940"
BRANCH = "engineering/cell-integrated-20261108-08b6-followup"
ENV = os.environ.copy()
ENV.update(RUSTUP_TOOLCHAIN="1.96.0", CARGO_BUILD_JOBS="2", CARGO_TERM_COLOR="never")
ENV["PATH"] = ":".join(
    [
        "/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin",
        "/home/qian-qi/work/cell-dependency-pin-20261108-08b6-evidence/tools/bin",
        "/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin",
        ENV["PATH"],
    ]
)


def git(*args):
    return subprocess.check_output(["git", "-C", str(SOURCE), *args]).decode().strip()


def identity():
    return {
        k: git(*args)
        for k, args in {
            "head": ("rev-parse", "HEAD"),
            "tree": ("rev-parse", "HEAD^{tree}"),
            "index_tree": ("write-tree",),
            "branch": ("branch", "--show-current"),
            "status": ("status", "--porcelain", "--untracked-files=all"),
        }.items()
    }


def pin(path):
    raw = path.read_bytes()
    return {
        "path": path.name,
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


def main():
    OUTPUT.mkdir(exist_ok=False)
    report = {
        "schema": "hepta.followup-source-assembly.v1",
        "C": C,
        "P": P,
        "U": U,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "steps": [],
    }

    def save():
        path = OUTPUT / "ASSEMBLY.json"
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
        os.replace(temp, path)

    def run(label, args, cwd=SOURCE, timeout=120):
        start = time.monotonic()
        out = OUTPUT / (label + ".stdout")
        err = OUTPUT / (label + ".stderr")
        with out.open("xb") as stdout, err.open("xb") as stderr:
            process = subprocess.run(
                args,
                cwd=cwd,
                env=ENV,
                stdout=stdout,
                stderr=stderr,
                timeout=timeout,
                check=False,
            )
        report["steps"].append(
            {
                "name": label,
                "argv": args,
                "cwd": str(cwd),
                "exit_code": process.returncode,
                "wall_seconds": time.monotonic() - start,
                "stdout": pin(out),
                "stderr": pin(err),
            }
        )
        save()
        if process.returncode:
            raise RuntimeError(label + " failed")

    try:
        before = identity()
        if before["head"] != P or before["status"] or before["branch"] != BRANCH:
            raise RuntimeError("Followup worktree is not the clean task-owned P branch")
        if (
            git("show", "-s", "--format=%P", P) != C
            or git("show", "-s", "--format=%P", U) != C
        ):
            raise RuntimeError("P/U bases differ")
        if git("rev-parse", U + "^{tree}") != UTREE:
            raise RuntimeError("U tree differs")
        report["before"] = before
        for label, head in [("C-to-P", P), ("C-to-U", U)]:
            (OUTPUT / (label + ".patch")).write_bytes(
                subprocess.check_output(
                    ["git", "-C", str(SOURCE), "diff", "--binary", C, head]
                )
            )
        save()
        run("cherry-pick-U", ["git", "cherry-pick", U])
        run("just-fmt", ["just", "fmt"], SOURCE / "codex-rs")
        run(
            "committed-format-check",
            ["/usr/bin/python3", "scripts/format.py", "--check", "--base", C],
        )
        run("diff-check", ["git", "diff", "--check", C, "HEAD"])
        after = identity()
        if (
            after["status"]
            or after["index_tree"] != after["tree"]
            or git("show", "-s", "--format=%P", "HEAD") != P
        ):
            raise RuntimeError("Integration changed after commit or parent differs")
        expected = sorted(
            git("diff", "--name-only", C, P).splitlines()
            + git("diff", "--name-only", C, U).splitlines()
        )
        actual = git("diff", "--name-only", C, "HEAD").splitlines()
        if sorted(actual) != expected or len(expected) != 4:
            raise RuntimeError("R contains unexpected source paths")
        for path in actual:
            owner = U if path.startswith("apps/") else P
            if git("rev-parse", "HEAD:" + path) != git("rev-parse", owner + ":" + path):
                raise RuntimeError("Integrated bytes differ from frozen owner: " + path)
        (OUTPUT / "C-to-R.patch").write_bytes(
            subprocess.check_output(
                ["git", "-C", str(SOURCE), "diff", "--binary", C, "HEAD"]
            )
        )
        report.update(
            after=after,
            R=after["head"],
            R_tree=after["tree"],
            parents=git("show", "-s", "--format=%P", "HEAD"),
            numstat=git("diff", "--numstat", C, "HEAD"),
            source_files_exact_frozen_owner=True,
            exit_code=0,
        )
    except BaseException as error:
        report.update(
            exit_code=1, error={"type": type(error).__name__, "message": str(error)}
        )
    finally:
        report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        save()
        print(json.dumps(report), flush=True)
    return report["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
