"""Retain one distinct frozen replay's outer process and artifact receipts."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

wall, cpu = time.perf_counter(), time.process_time()
repo = Path('/workspace/scratch/4456254f9cc2/pred-work')
run = Path('/workspace/scratch/4456254f9cc2/pred-reexecution-004')
out = Path('/workspace/scratch/4456254f9cc2/pred-replay-004')
reg = repo / 'qualification/pred-reexecution-20261110-4456'
sys.path.insert(0, str(repo / 'scripts'))
from hepta_pred1.cached_replay import source_hashes

def digest(path):
    h = sha256()
    with path.open('rb') as stream:
        for b in iter(lambda: stream.read(65536), b''):
            h.update(b)
    return h.hexdigest()

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

out.mkdir(exist_ok=False)
argv = [sys.executable, '-B', '-m', 'hepta_pred1.cached_replay',
        '--campaign', str(run / 'campaign'),
        '--execution-receipt', str(run / 'EXECUTION_RECEIPT.json'),
        '--training-freeze', str(reg / 'ORIGINAL_DESIGN_FREEZE.json'),
        '--registered-config', str(reg / 'registered_config.json'),
        '--replay-freeze', str(reg / 'ORIGINAL_REPLAY_FREEZE.json'),
        '--output', str(out / 'campaign')]
env = {**os.environ, 'PYTHONPATH': str(repo / 'scripts'),
       'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
       'MKL_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1'}
started = {'execution_id': 'PRED1-CROSSED-REEXEC-004-20261110-4456',
           'replay_id': 'PRED1-MATCHED-CACHE-REPLAY-004-20261110-4456',
           'new_training_fits': 0, 'original_execution_recovered': False,
           'started_at_utc': datetime.now(timezone.utc).isoformat(),
           'argv': argv, 'source_sha256': source_hashes(),
           'training_receipt_sha256': digest(run / 'EXECUTION_RECEIPT.json'),
           'new_execution_pregate_sha256': digest(run / 'NEW_EXECUTION_PREGATE.json'),
           'complete_campaign_gate_sha256': digest(run / 'COMPLETE_CAMPAIGN_GATE.json')}
write(out / 'REPLAY_STARTED.json', started)
before = resource.getrusage(resource.RUSAGE_CHILDREN)
with (out / 'stdout.log').open('xb') as stdout, (out / 'stderr.log').open('xb') as stderr:
    child = subprocess.Popen(argv, cwd=repo, env=env, stdout=stdout, stderr=stderr)
    code = child.wait()
after = resource.getrusage(resource.RUSAGE_CHILDREN)
source_after = source_hashes()
receipt = {**started, 'status': 'EXITED' if source_after == started['source_sha256'] else 'SOURCE_CHANGED',
           'exit_code': code, 'child_pid': child.pid,
           'finished_at_utc': datetime.now(timezone.utc).isoformat(),
           'source_sha256_after': source_after,
           'outer_wall_seconds': time.perf_counter() - wall,
           'wrapper_cpu_seconds': time.process_time() - cpu,
           'child_user_cpu_seconds': after.ru_utime - before.ru_utime,
           'child_system_cpu_seconds': after.ru_stime - before.ru_stime,
           'children_peak_rss_kib_highwater': after.ru_maxrss,
           'logs': {n: {'bytes': (out / n).stat().st_size, 'sha256': digest(out / n)}
                    for n in ('stdout.log', 'stderr.log')},
           'result_present': (out / 'campaign/RESULT.json').is_file(),
           'result_sha256': digest(out / 'campaign/RESULT.json') if (out / 'campaign/RESULT.json').is_file() else None,
           'scope': 'outer code entry through child termination and artifact hashing; excludes interpreter startup and final receipt serialization',
           'physical_cost_complete': False, 'energy_joules': None, 'financial_cost': None}
write(out / 'REPLAY_RECEIPT.json', receipt)
print(json.dumps({k: receipt[k] for k in ('status', 'exit_code', 'result_present')}))
raise SystemExit(0 if receipt['status'] == 'EXITED' and code == 0 else 1)
