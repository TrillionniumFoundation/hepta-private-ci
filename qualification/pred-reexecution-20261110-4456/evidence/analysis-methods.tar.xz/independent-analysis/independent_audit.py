"""Independent arithmetic on authorized new004 fit JSON only."""
from collections import defaultdict
from hashlib import sha256
from itertools import combinations, product
import json
from math import fsum, isclose, isfinite, sqrt
from pathlib import Path
ROOT=Path('/workspace/scratch/4456254f9cc2/pred-reexecution-004')
OUT=Path('/workspace/scratch/4456254f9cc2/analysis-004')
REPO=Path('/workspace/scratch/4456254f9cc2/pred-work')
FACTORS=('data','init','order')
METRICS={
 'dev_observed_nll':lambda r:r['dev_observed_nll'],
 'legacy_dev_net_utility':lambda r:r['dev']['net_utility'],
 'expanded_cheap_fixed1_net_utility':lambda r:r['resource_panels']['expanded_resources']['arms']['fixed_1_cheap']['expected_net_utility'],
 'expanded_adaptive_net_utility':lambda r:r['resource_panels']['expanded_resources']['arms']['adaptive_shared_panel']['expected_net_utility']}
def read(path):return json.loads(path.read_bytes())
def mean(v):
 v=list(v);return fsum(v)/len(v)
def digest(path):return sha256(path.read_bytes()).hexdigest()
def stats(v):
 m=mean(v);return dict(mean=m,minimum=min(v),maximum=max(v),finite_grid_sd=sqrt(mean((x-m)**2 for x in v)))
def decompose(values):
 cells=tuple(product(range(3),repeat=3));lookup=dict(zip(cells,values))
 subsets=[a for size in range(4) for a in combinations(range(3),size)];conditional={}
 for axes in subsets:
  grouped=defaultdict(list)
  for cell,v in lookup.items():grouped[tuple(cell[i] for i in axes)].append(v)
  conditional[axes]={key:mean(v) for key,v in grouped.items()}
 components={}
 for axes in subsets[1:]:
  terms=[fsum((-1)**(len(axes)-len(s))*conditional[s][tuple(cell[i] for i in s)] for s in subsets if set(s).issubset(axes)) for cell in cells]
  components[':'.join(FACTORS[i] for i in axes)]=mean(v*v for v in terms)
 grand=mean(values);variance=mean((v-grand)**2 for v in values)
 assert isclose(fsum(components.values()),variance,rel_tol=1e-10,abs_tol=1e-14)
 return dict(grand_mean=grand,grid_shape=[3,3,3],cells=27,finite_grid_variance=variance,mean_squared_components=components,
  fraction_of_grid_variance={k:v/variance if variance else None for k,v in components.items()},
  marginal_means={name:[conditional[(i,)][(j,)] for j in range(3)] for i,name in enumerate(FACTORS)})

assert read(ROOT/'NEW_EXECUTION_PREGATE.json')['status']=='NEW_EXECUTION_OUTER_RECEIPT_VERIFIED'
assert read(ROOT/'COMPLETE_CAMPAIGN_GATE.json')['completed_fits']==189
cfg,result,receipt,reg=(read(ROOT/p) for p in ('registered_config.json','campaign/RESULT.json','EXECUTION_RECEIPT.json','registration.json'))
assert result['status']=='COMPLETE' and result['expected_fits']==result['completed_fits']==189
assert result['failed_fits']==result['unstarted_fits']==0 and not result['failures']
assert result['source_unchanged'] is True and receipt['source_closure_unchanged'] is True
assert receipt['status']=='EXITED' and receipt['exit_code']==receipt['child_exit_code']==0
assert result['confirmation_data_read'] is False and result['confirmation_samples_generated']==0
assert digest(ROOT/'campaign/RESULT.json')==receipt['result_sha256']
for name,expected in reg['source_sha256'].items():
 assert digest(ROOT/'scripts/hepta_pred1'/name)==digest(ROOT/'campaign/source'/name)==digest(REPO/'scripts/hepta_pred1'/name)==expected
cells=tuple(product(*(cfg[f+'_seeds'] for f in FACTORS)))
ids={f'{v}-d{d}-i{i}-o{o}':(v,d,i,o) for d,i,o in cells for v in cfg['variants']}
paths={p.stem:p for p in (ROOT/'campaign/fits').glob('*.json') if not p.name.endswith('.started.json')}
assert set(paths)==set(ids) and len(paths)==189
rows={};steps=examples=episode_checks=stop_rows=0
init_hashes,order_hashes=defaultdict(set),defaultdict(set)
for name,identity in ids.items():
 r=read(paths[name]);start=read(paths[name].with_name(name+'.started.json'))
 assert tuple(r[k] for k in ('variant','data_seed','init_seed','order_seed'))==identity
 assert tuple(start[k] for k in ('variant','data_seed','init_seed','order_seed'))==identity
 assert r['status']=='COMPLETE' and r['epochs_consumed']==30
 assert r['fit_step_calls_consumed']==r['optimizer_steps_consumed']==960
 assert r['training_examples_consumed']==4096*30 and len(r['curve'])==30
 curve=r['curve'];assert [e['epoch'] for e in curve]==list(range(1,31))
 assert all(isfinite(e[k]) for e in curve for k in ('train_nll','dev_observed_nll'))
 best=min(range(30),key=lambda j:curve[j]['dev_observed_nll'])
 assert r['best_epoch']==best+1 and r['selected_checkpoint_steps']==(best+1)*32
 assert r['dev_observed_nll']==curve[best]['dev_observed_nll'] and r['checkpoint']==name+'.npz'
 steps+=r['fit_step_calls_consumed'];examples+=r['training_examples_consumed']
 init_hashes[(r['variant'],r['init_seed'])].add(r['initial_parameter_sha256'])
 order_hashes[r['order_seed']].add(r['batch_order_sha256'])
 for panel,body in r['resource_panels'].items():
  for arm,record in body['arms'].items():
   per=record['per_episode'];assert all(len(value)==512 for value in per.values())
   for key in ('expected_net_utility','realized_net_utility','complete_environment_cost'):
    assert isclose(mean(per[key]),record[key],rel_tol=1e-12,abs_tol=1e-12);episode_checks+=1
   stopped=sum(a==-1 for a in per['selected_action']);assert stopped/512==record['stop_rate']
   if panel=='original_resources':
    assert stopped==512 and all(h is None for h in per['selected_horizon']);stop_rows+=512
 rows[identity]={key:get(r) for key,get in METRICS.items()}
assert steps==181440 and examples==23224320
assert all(len(v)==1 for v in init_hashes.values()) and all(len(v)==1 for v in order_hashes.values())
assert len({next(iter(v)) for v in order_hashes.values()})==3
arrays={v:{m:[rows[(v,*cell)][m] for cell in cells] for m in METRICS} for v in cfg['variants']}
model_stats={v:{m:stats(a) for m,a in by.items()} for v,by in arrays.items()}
recomputed={'per_variant':{},'paired_factor_cell_differences':{}}
for v,by in arrays.items():recomputed['per_variant'][v]={m:decompose(a) for m,a in by.items()}
paired={}
for other in ('single_step','gru_reset','gru_no_action','gru_no_time'):
 key='gru_minus_'+other
 by={m:[a-b for a,b in zip(arrays['gru'][m],arrays[other][m])] for m in METRICS}
 paired[key]={m:stats(a) for m,a in by.items()}
 recomputed['paired_factor_cell_differences'][key]={m:decompose(a) for m,a in by.items()}
differences=[]
def compare(new,old,path=''):
 if isinstance(new,dict):
  assert set(new).issubset(old),path
  for k in new:compare(new[k],old[k],path+'/'+str(k))
 elif isinstance(new,list):
  assert len(new)==len(old),path
  for i,(a,b) in enumerate(zip(new,old)):compare(a,b,path+'/'+str(i))
 elif new is None:assert old is None,path
 else:
  assert isclose(new,old,rel_tol=1e-9,abs_tol=1e-12),(path,new,old)
  differences.append(abs(new-old))
compare(recomputed,result['summary'])
summary={
 'schema':'pred-new004-independent-arithmetic-audit-v1','execution_id':receipt['execution_id'],
 'execution_registration_commit':receipt['execution_registration_commit'],'result_sha256':receipt['result_sha256'],
 'fits':189,'factor_cells':27,'epochs_each':30,'optimizer_calls_each':960,'optimizer_calls_total':steps,
 'training_example_presentations_total':examples,'all_fit_identities_exact':True,'source_nine_files_unchanged':True,
 'selected_epoch_and_nll_consistent':True,'initialization_hash_isolation_verified':True,'batch_order_hash_isolation_verified':True,
 'per_episode_aggregate_metrics_checked':episode_checks,'original_resource_all_stop_rows_across_fits_and_arms':stop_rows,
 'summary_numeric_leaves_checked':len(differences),'summary_max_abs_difference':max(differences),
 'method':'Independent pure-Python conditional means and inclusion-exclusion on fit JSON; no shared decompose import',
 'model_statistics':model_stats,'gru_decomposition':recomputed['per_variant']['gru'],
 'paired_gru_contrasts':paired,'paired_gru_decompositions':recomputed['paired_factor_cell_differences'],
 'data_observation_counts':{seed:{k:v[k] for k in ('train_episodes','dev_episodes','train_observation_counts','dev_observation_counts')} for seed,v in result['datasets'].items()},
 'scope':'Only new004 finite train/dev simulator grid; dependent shared factors, no population variance/p-value/independent-task-gain claim. Raw NLL between-data variation may include task difficulty and coarsening entropy, not optimizer-instability causation.',
 'checkpoint_arrays_opened':False,'old_confirmation_opened':False,'new_model_fits':0,'qualification':'HOLD_UNCHANGED'}
(OUT/'SUMMARY.json').write_text(json.dumps(summary,indent=2,sort_keys=True,allow_nan=False)+'\n')
print(json.dumps({'fits':189,'numeric_leaves':len(differences),'max_abs_difference':max(differences),
 'model_means':{v:{m:s['mean'] for m,s in by.items()} for v,by in model_stats.items()},
 'gru_variance_fractions':{m:d['fraction_of_grid_variance'] for m,d in summary['gru_decomposition'].items()},
 'paired_means':{v:{m:s['mean'] for m,s in by.items()} for v,by in paired.items()}},indent=2))
