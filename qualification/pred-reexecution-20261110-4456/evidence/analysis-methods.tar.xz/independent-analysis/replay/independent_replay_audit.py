"""Independent arithmetic audit of only authorized new execution 004 replay."""

from collections import defaultdict
from hashlib import sha256
from itertools import combinations, product
import json
from math import fsum, isclose
from pathlib import Path
from time import perf_counter

RUN = Path('/workspace/scratch/4456254f9cc2/pred-replay-004/campaign')
TRAIN = Path('/workspace/scratch/4456254f9cc2/pred-reexecution-004/campaign')
OUT = Path('/workspace/scratch/4456254f9cc2/analysis-004/replay')
ARMS = ('matched_cached_fixed1', 'cached_short13', 'cached_adaptive136')
METRICS = ('expected_net_utility', 'realized_net_utility', 'complete_environment_cost', 'stop_rate')
COUNTS = ('prediction_calls', 'prediction_rows', 'state_update_calls',
          'state_update_rows', 'history_encodings', 'planning_candidate_rows')
FACTORS = ('data', 'init', 'order')


def read(path):
    raw = path.read_bytes()
    return json.loads(raw), sha256(raw).hexdigest()


def mean(values):
    values = tuple(values)
    return fsum(values) / len(values)


def decompose(values):
    cells = tuple(product(range(3), repeat=3))
    subsets = [s for size in range(4) for s in combinations(range(3), size)]
    conditional = {}
    for axes in subsets:
        grouped = defaultdict(list)
        for cell,value in zip(cells,values):
            grouped[tuple(cell[i] for i in axes)].append(value)
        conditional[axes] = {k:mean(v) for k,v in grouped.items()}
    components = {}
    for axes in subsets[1:]:
        terms = [fsum((-1)**(len(axes)-len(sub))
                      * conditional[sub][tuple(cell[i] for i in sub)]
                      for sub in subsets if set(sub).issubset(axes)) for cell in cells]
        components[':'.join(FACTORS[i] for i in axes)] = mean(v*v for v in terms)
    grand = mean(values)
    variance = mean((v-grand)**2 for v in values)
    assert isclose(fsum(components.values()),variance,abs_tol=1e-12,rel_tol=1e-9)
    return {'grand_mean':grand,'grid_shape':[3,3,3],'cells':27,
            'finite_grid_variance':variance,'mean_squared_components':components,
            'fraction_of_grid_variance':{k:v/variance if variance else None for k,v in components.items()},
            'marginal_means':{factor:[conditional[(i,)][(j,)] for j in range(3)]
                              for i,factor in enumerate(FACTORS)}}


def main():
    wall = perf_counter()
    config,_ = read(RUN/'config.json')
    result,result_sha = read(RUN/'RESULT.json')
    training,_ = read(TRAIN/'RESULT.json')
    assert result['status']=='COMPLETE' and result['replayed_checkpoints']==result['expected_checkpoints']==189
    assert result['new_fits']==0 and result['failure'] is None and result['source_unchanged'] is True
    assert result['qualification']=='HOLD_UNCHANGED' and result['confirmation_data_read'] is False
    assert result['confirmation_samples_generated']==0
    cells = tuple(product(*(config[factor+'_seeds'] for factor in FACTORS)))
    ids = {f'{v}-d{d}-i{i}-o{o}':(v,d,i,o) for d,i,o in cells for v in config['variants']}
    assert {p.stem for p in (RUN/'fits').glob('*.json')} == set(ids)
    records, parity_panels, episode_panels, scalar_checks = {},0,0,0
    totals = {resource:{arm:dict.fromkeys(COUNTS,0) for arm in (*ARMS,'additional_oldcheap_bridge')}
              for resource in ('original_resources','expanded_resources')}
    for name,identity in ids.items():
        replay,_ = read(RUN/'fits'/(name+'.json'))
        original, original_sha = read(TRAIN/'fits'/(name+'.json'))
        assert tuple(replay[k] for k in ('variant','data_seed','init_seed','order_seed'))==identity
        assert replay['status']=='COMPLETE' and replay['original_fit_sha256']==original_sha
        for key in ('checkpoint_sha256','selected_parameter_sha256','selected_optimizer_state_sha256'):
            assert replay[key]==original[key]
        assert replay['dataset_sha256']==training['datasets'][str(identity[1])]['dev_sha256']
        for resource,panel in replay['resource_panels'].items():
            assert panel['formal_oldcheap_parity'] is True
            current = panel['arms']['matched_cached_fixed1']
            old = original['resource_panels'][resource]['arms']['fixed_1_cheap']
            assert set(current)=={'complete_environment_cost','expected_net_utility','per_episode','realized_net_utility','stop_rate'}
            assert all(current[key]==old[key] for key in current)
            assert set(old)-set(current)=={'bayes_regret'}
            parity_panels += 1
            for key in COUNTS:
                assert panel['policy_meters']['matched_cached_fixed1'][key] == original['resource_panels'][resource]['meter']['fixed_1_cheap'][key]
            for arm in ARMS:
                record,meter = panel['arms'][arm],panel['policy_meters'][arm]
                per=record['per_episode']
                assert all(len(values)==512 for values in per.values())
                episode_panels += 512
                for metric in METRICS[:3]:
                    assert isclose(mean(per[metric]),record[metric],abs_tol=1e-12,rel_tol=1e-12)
                    scalar_checks += 1
                stopped = sum(action==-1 for action in per['selected_action'])/512
                assert stopped==record['stop_rate']
                assert meter['planning_candidate_rows']==meter['reserved_planning_candidate_rows']==meter['prediction_rows']
                for key in COUNTS:
                    totals[resource][arm][key] += meter[key]
                for key in ('history_encodings','state_update_calls','state_update_rows','retained_state_bytes'):
                    assert meter[key]==panel['policy_meters']['matched_cached_fixed1'][key]
                if resource=='original_resources':
                    assert stopped==1.0 and all(meter[key]==0 for key in COUNTS)
                else:
                    assert stopped==0.0
                    ratio={'matched_cached_fixed1':1,'cached_short13':2,'cached_adaptive136':3}[arm]
                    assert meter['prediction_calls']==ratio*panel['policy_meters']['matched_cached_fixed1']['prediction_calls']
                    assert meter['prediction_rows']==ratio*panel['policy_meters']['matched_cached_fixed1']['prediction_rows']
            for key in COUNTS:
                bridge = panel['old_cheap_bridge']
                totals[resource]['additional_oldcheap_bridge'][key] += (bridge[key] if key=='planning_candidate_rows' else bridge['meter'][key])
        records[identity] = {resource:{arm:{metric:record[metric] for metric in METRICS}
                                      for arm,record in panel['arms'].items()}
                             for resource,panel in replay['resource_panels'].items()}
    assert totals==result['completed_checkpoint_operation_totals']
    means,contrasts,recomputed = {},{},{}
    numeric_differences=[]

    def compare(new,old,path=''):
        if isinstance(new,dict):
            assert set(new).issubset(old),path
            for key,value in new.items():compare(value,old[key],path+'/'+key)
        elif isinstance(new,list):
            assert len(new)==len(old),path
            for i,(a,b) in enumerate(zip(new,old)):compare(a,b,path+'/'+str(i))
        elif new is None:
            assert old is None,path
        else:
            assert isclose(new,old,rel_tol=1e-8,abs_tol=1e-12),(path,new,old)
            numeric_differences.append(abs(new-old))
    for variant in config['variants']:
        means[variant],contrasts[variant],recomputed[variant]={},{},{}
        for resource in ('original_resources','expanded_resources'):
            arrays={arm:{metric:[records[(variant,*cell)][resource][arm][metric] for cell in cells]
                         for metric in METRICS} for arm in ARMS}
            means[variant][resource]={arm:{metric:mean(values) for metric,values in metrics.items()}
                                      for arm,metrics in arrays.items()}
            contrasts[variant][resource]={}
            paired={}
            for arm in ARMS[1:]:
                key=arm+'_minus_matched_cached_fixed1'
                values={metric:[a-b for a,b in zip(arrays[arm][metric],arrays[ARMS[0]][metric])]
                        for metric in METRICS}
                contrasts[variant][resource][key]={metric:{'mean':mean(v),'min':min(v),'max':max(v),
                    'positive_cells':sum(x>0 for x in v),'negative_cells':sum(x<0 for x in v),
                    'zero_cells':sum(x==0 for x in v)} for metric,v in values.items()}
                paired[key]={metric:decompose(v) for metric,v in values.items()}
            recomputed[variant][resource]={'means':means[variant][resource],'paired_factor_cell_differences':paired}
    compare(recomputed,result['summary'])
    summary={'schema':'pred004-independent-replay-audit-v1','execution_scope':'Distinct new004, not missing original',
             'replay_result_sha256':result_sha,'status':'VERIFIED','checkpoints':189,'new_fits':0,
             'exact_oldcheap_parity_panels':parity_panels,'exact_oldcheap_episode_comparisons':parity_panels*512,
             'parity_scope':'All persisted replay arm fields, including complete per_episode dictionaries, equal original cheap Fixed1. Original-only bayes_regret is not a replay arm field.',
             'per_policy_episode_panels_checked':episode_panels,'per_episode_aggregate_scalar_checks':scalar_checks,
             'summary_numeric_leaves_checked':len(numeric_differences),
             'summary_numeric_max_abs_difference':max(numeric_differences),
             'operation_totals_exact':True,'matched_prefix_counts_equal_for_all_panels':True,
             'expanded_head_call_ratios_fixed_short_long':[1,2,3],
             'means':means,'paired_deltas':contrasts,'operation_totals':totals,
             'qualification':'HOLD_UNCHANGED','independent_task_gain_established':False,
             'scope':'Finite reused train/dev grid; shared factor levels; no population variance or p-value. Monetary/energy/full physical costs incomplete. Direct option forecasting, not latent rollout.',
             'method':'Raw JSON exact parity and episode aggregation; math.fsum conditional means/inclusion-exclusion, no shared summarize/decompose imports.',
             'audit_wall_seconds':perf_counter()-wall}
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'SUMMARY.json').write_text(json.dumps(summary,indent=2,sort_keys=True,allow_nan=False)+'\n')
    lines=['# 新004 matched-cache replay 独立算术核验','',
           '189 个检查点全部完成，未新增训练。两种资源面板的 378 个 Fixed1 原件对照在全部重放保留字段上完全相同，共 193,536 个逐 episode 对照；状态编码、head 和 planning 操作计数也一致。原训练记录另有的 bayes_regret 不属于 replay arm 字段。',
           '','扩展资源（budget16/deadline20）下，每个模型均有27个依赖的 data×init×order 单元。下表单位是该模拟研究净效用；成本为模拟环境工作单位，未包括完整物理成本。','',
           '| 模型 | 短13−Fixed1 期望 | 长136−Fixed1 期望 | 短13−Fixed1 实际 | 长136−Fixed1 实际 |',
           '|---|---:|---:|---:|---:|']
    for v in config['variants']:
        z=contrasts[v]['expanded_resources'];s=z['cached_short13_minus_matched_cached_fixed1'];l=z['cached_adaptive136_minus_matched_cached_fixed1']
        lines.append(f"| {v} | {s['expected_net_utility']['mean']:+.9f} | {l['expected_net_utility']['mean']:+.9f} | {s['realized_net_utility']['mean']:+.9f} | {l['realized_net_utility']['mean']:+.9f} |")
    lines += ['',
       '七种模型的短／长候选面板平均模拟期望净效用均低于廉价 Fixed1，模拟环境成本均更高；实际样本净效用的方向并不一致，不能声称 Fixed1 在所有模型的实际样本上都占优。',
       '',
       'GRU 的 Fixed1 期望／实际净效用为 0.635655795／0.633427337；短13为 0.633934056／0.631681183，长136为 0.633743018／0.631383957。相对 Fixed1，短／长平均模拟环境成本增加 0.033609961／0.037669864。三者扩展资源 STOP 率均0。',
       '',
       '原始资源面板全部策略 STOP 率均1，并且零 forecast/head/state 工作。扩展资源共享前缀计数完全一致，但 short/long 的 head 调用及预测行数分别为 Fixed1 的2倍／3倍。',
       '',
       f"独立纯Python条件均值／容斥分解核对了 {len(numeric_differences)} 个 summary 数值叶子，最大绝对差 {max(numeric_differences):.3g}；逐 episode 聚合和总操作计数亦通过。",
       '',
       '这些结论只适用于本轮冻结有限 train/dev 模拟网格及声明的资源干预。因共享因子和重复数据，不能视为独立确认、总体方差估计、新 p 值或真实任务收益。时间／能耗／资金／完整生命周期成本仍不完整；本实验不是递归 latent rollout。HOLD 保留。']
    (OUT/'REPORT.zh-CN.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:summary[k] for k in ('status','checkpoints','exact_oldcheap_parity_panels','exact_oldcheap_episode_comparisons','summary_numeric_leaves_checked','summary_numeric_max_abs_difference','audit_wall_seconds')},indent=2))


if __name__=='__main__':
    main()
