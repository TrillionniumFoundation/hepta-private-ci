"""Verify outer evidence before the unchanged legacy campaign gate.

Run only after the supervising session also reports wrapper exit 0. This never
opens RESULT, fit JSON, checkpoints or log contents; logs are hashed as bytes.
"""

from datetime import datetime
from hashlib import sha1, sha256
import json
from pathlib import Path

RUN = Path('/workspace/scratch/4456254f9cc2/pred-reexecution-004')
REPO = Path('/workspace/scratch/4456254f9cc2/pred-work')
REG = REPO / 'qualification/pred-reexecution-20261110-4456'
EXECUTION_ID = 'PRED1-CROSSED-REEXEC-004-20261110-4456'
NEW_COMMIT = '260922ba18438a24b2941c306606ec853f4a7348'
OLD_DESIGN = 'd2e39332b28a7c1564330bad95ff651fcc276bab'
OLD_SOURCE = 'd5f30f0a15af065281f80a10e4cbc210af07b8fb'
REG_SHA = '243f5b637aacaf9511ec62134de833d4a56e84d588c044e5ea01bce8b1304c5f'
RUNNER_SHA = '5baec8bc185e419a4e4a62eeb719c0e9dc22df2468b1953692e8383afe7581b7'
CONFIG_SHA = '3380171a5e53f7a1efafedfbc6239bdeffe5b05f2bf444e789c52024e542d621'
# Independently retrieved at NEW_COMMIT through the connected GitHub API.
PUBLISHED_GIT_BLOBS = {
    REG / 'REGISTRATION.json': 'd9bc768870d12b330bf3143c18ac163c8fdf7220',
    REG / 'registered_config.json': '4de3c3456b6898a63ecf6401d1bdec1ed84c1625',
    REPO / 'scripts/hepta_pred1/reexecute_crossed.py': '7d11773d3ff1b44eb33a39276c9a88ef6334c263',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def ordinary(path):
    require(path.is_file() and not path.is_symlink(), f'ordinary file required: {path}')


def digest(path):
    ordinary(path)
    h = sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def read(path):
    ordinary(path)
    with path.open('rb') as stream:
        raw = stream.read(1048577)
    require(len(raw) <= 1048576, 'metadata byte limit exceeded')

    def pairs(items):
        value = {}
        for key, item in items:
            require(key not in value, 'duplicate JSON key')
            value[key] = item
        return value

    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def verify():
    for path, expected in PUBLISHED_GIT_BLOBS.items():
        ordinary(path)
        raw = path.read_bytes()
        actual = sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        require(actual == expected, f'published reference changed: {path}')
    require(digest(REG / 'REGISTRATION.json') == digest(RUN / 'registration.json') == REG_SHA,
            'new registration bytes differ')
    plan, started, receipt = (read(RUN / name) for name in
                             ('registration.json', 'EXECUTION_STARTED.json', 'EXECUTION_RECEIPT.json'))
    require(started['schema'] == 'pred1-crossed-new-execution-start-v1'
            and receipt['schema'] == 'pred1-crossed-new-execution-receipt-v1', 'wrong receipt schema')
    require(receipt.get('status') == 'EXITED', 'wrapper did not exit successfully')
    for field in ('exit_code', 'child_exit_code'):
        require(type(receipt.get(field)) is int and receipt[field] == 0, f'{field} is not zero')
    require(receipt.get('error') is None and receipt.get('source_read_errors') == []
            and receipt.get('source_closure_unchanged') is True, 'outer source/error failure')
    for field, value in started.items():
        if field != 'schema':
            require(receipt.get(field) == value, f'start/exit binding differs: {field}')
    expected = {
        'execution_id': EXECUTION_ID, 'execution_registration_commit': NEW_COMMIT,
        'registration_commit': OLD_DESIGN, 'execution_source_commit': OLD_SOURCE,
        'registration_sha256': REG_SHA, 'runner_sha256': RUNNER_SHA, 'config_sha256': CONFIG_SHA,
        'new_execution_only': True, 'original_execution_recovered': False,
    }
    for field, value in expected.items():
        require(started.get(field) == value and type(started[field]) is type(value),
                f'new execution binding differs: {field}')
    require(plan['execution_id'] == EXECUTION_ID and plan['new_execution_only'] is True
            and plan['original_artifacts_status'] == 'ORIGINAL_ARTIFACTS_NOT_LOCATED'
            and plan['design_registration_commit'] == OLD_DESIGN
            and plan['execution_source_commit'] == OLD_SOURCE, 'registration identity differs')
    require(digest(REPO / 'scripts/hepta_pred1/reexecute_crossed.py') == plan['runner_sha256'] == RUNNER_SHA,
            'wrapper source differs')
    require(digest(RUN / 'registered_config.json') == digest(REG / 'registered_config.json')
            == plan['config_sha256'] == CONFIG_SHA, 'config bytes differ')
    require(plan['source_sha256'] == started['source_sha256']
            == receipt['source_sha256_after'] == receipt['executed_source_sha256_after'],
            'source closure binding differs')
    sources, package = plan['source_sha256'], RUN / 'scripts/hepta_pred1'
    require(len(sources) == 9 and {p.name for p in package.iterdir()} == set(sources),
            'isolated nine-file inventory differs')
    for name, expected_sha in sources.items():
        require(Path(name).name == name, 'invalid source basename')
        require(digest(package / name) == digest(REPO / 'scripts/hepta_pred1' / name) == expected_sha,
                f'current/copied source bytes differ: {name}')
    argv = started['argv']
    require(type(argv) is list and len(argv) == 8
            and argv[1:5] == ['-B', '-m', 'hepta_pred1.crossed_training', '--config']
            and argv[5] == str(RUN / 'registered_config.json')
            and argv[6:] == ['--output', str(RUN / 'campaign')], 'launch argv differs')
    require(started['environment']['PYTHONPATH'] == str(RUN / 'scripts')
            and all(started['environment'][name] == '1' for name in
                    ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS')),
            'isolated environment differs')
    require(datetime.fromisoformat(started['started_at_utc'])
            <= datetime.fromisoformat(receipt['finished_at_utc']), 'invalid chronology')
    require(set(receipt['logs']) == {'stdout.log', 'stderr.log'}, 'log inventory differs')
    for name, metadata in receipt['logs'].items():
        path = RUN / name
        require(digest(path) == metadata['sha256'] and path.stat().st_size == metadata['bytes'],
                f'complete log bytes differ: {name}')
    require(receipt.get('result_present') is True and receipt.get('fit_outcomes_parsed') is False
            and receipt.get('confirmation_data_read') is False
            and receipt.get('qualification') == 'HOLD_UNCHANGED', 'outer scope differs')
    return {'status': 'NEW_EXECUTION_OUTER_RECEIPT_VERIFIED', 'execution_id': EXECUTION_ID,
            'execution_registration_commit': NEW_COMMIT,
            'receipt_sha256': digest(RUN / 'EXECUTION_RECEIPT.json'), 'fit_outcomes_opened': False,
            'legacy_complete_campaign_gate_still_required': True}


if __name__ == '__main__':
    print(json.dumps(verify(), sort_keys=True))
