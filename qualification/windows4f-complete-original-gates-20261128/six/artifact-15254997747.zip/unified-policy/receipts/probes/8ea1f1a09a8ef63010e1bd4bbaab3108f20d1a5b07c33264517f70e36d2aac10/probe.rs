use std::hint::black_box;
#[inline(never)] fn twice(value:usize)->usize { value*2 }
fn main() {
 std::panic::set_hook(Box::new(|_|{}));
 match std::panic::catch_unwind(||twice(black_box(usize::MAX))) {
  Ok(value)=>println!("wrapping:{value}"), Err(_)=>println!("checked")
 }
}
