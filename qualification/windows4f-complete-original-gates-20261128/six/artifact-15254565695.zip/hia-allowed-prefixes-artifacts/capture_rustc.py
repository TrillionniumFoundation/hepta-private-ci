#!/usr/bin/python3
import json, os, sys
from pathlib import Path
args = sys.argv[2:]
if '--crate-name' in args and args[args.index('--crate-name') + 1] == 'codex_execpolicy':
    kind = args[args.index('--crate-type') + 1] if '--crate-type' in args else 'bin'
    suffix = 'lib' if kind in ('lib', 'rlib') else 'bin'
    externs = dict(args[index + 1].split('=', 1) for index, arg in enumerate(args) if arg == '--extern')
    path = Path(os.environ['CODEX_HIA_COMPILER_CAPTURE'] + '.' + suffix + '.json')
    with path.open('x') as output:
        json.dump({'compiler': sys.argv[1], 'argv': args, 'externs': externs}, output, indent=2)
os.execv(sys.argv[1], sys.argv[1:])
