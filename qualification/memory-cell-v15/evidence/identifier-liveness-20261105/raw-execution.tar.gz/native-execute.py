"""Isolated native qualification; argv[1] is a compressed source/fixture bundle."""
import base64
import gzip
import hashlib
import json
import pathlib
import platform
import resource
import subprocess
import sys
import tempfile
import time

files = json.loads(gzip.decompress(base64.b64decode(sys.argv[1])))
root = pathlib.Path(tempfile.mkdtemp(prefix='hepta-memory-identifiers-659d-'))
for name, content in files.items():
    if name not in ('transfer.rs', 'runner.rs', 'identifier_tests.rs', 'commands.txt', 'expected.txt'):
        raise ValueError('unexpected qualification input')
    (root / name).write_text(content)
tool = pathlib.Path('/home/qian/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
rust = [str(root / name) for name in ('transfer.rs', 'runner.rs', 'identifier_tests.rs')]
steps = {}
started = time.perf_counter()
usage = resource.getrusage(resource.RUSAGE_CHILDREN)


def run(name, arguments, stdin=None):
    result = subprocess.run(arguments, input=stdin, capture_output=True, text=True, timeout=60)
    steps[name] = dict(exit=result.returncode, stdout=result.stdout, stderr=result.stderr)
    if result.returncode:
        print(json.dumps(dict(root=str(root), steps=steps)))
        raise SystemExit(result.returncode)
    return result.stdout


run('format', [str(tool / 'rustfmt'), '--edition', '2024', *rust])
run('format_check', [str(tool / 'rustfmt'), '--check', '--edition', '2024', *rust])
run('compile_tests', [str(tool / 'rustc'), '--edition=2024', '-Dwarnings', '--test',
                      str(root / 'transfer.rs'), '-o', str(root / 'identifier-tests')])
tests = run('identifier_tests', [str(root / 'identifier-tests'), '--nocapture'])
run('compile_runner', [str(tool / 'rustc'), '--edition=2024', '-Dwarnings', '-O',
                       str(root / 'runner.rs'), '-o', str(root / 'runner')])
actual = run('differential', [str(root / 'runner')], files['commands.txt'])
expected = files['expected.txt'].splitlines()
observed = actual.splitlines()
differences = [dict(line=index + 1, expected=left, actual=right)
               for index, (left, right) in enumerate(zip(expected, observed))
               if left.rstrip() != right.rstrip()]
after = resource.getrusage(resource.RUSAGE_CHILDREN)
report = dict(host=platform.platform(), root=str(root),
              rustc=subprocess.check_output([str(tool / 'rustc'), '--version'], text=True).strip(),
              passed=len(expected) == len(observed) and not differences,
              expected_lines=len(expected), actual_lines=len(observed), mismatches=differences,
              actual_sha256=hashlib.sha256(actual.encode()).hexdigest(),
              source_sha256={name: hashlib.sha256((root / name).read_bytes()).hexdigest()
                             for name in ('transfer.rs', 'runner.rs', 'identifier_tests.rs')},
              input_sha256={name: hashlib.sha256(content.encode()).hexdigest() for name, content in files.items()},
              binaries_sha256={name: hashlib.sha256((root / name).read_bytes()).hexdigest()
                               for name in ('identifier-tests', 'runner')},
              wall_seconds=time.perf_counter() - started,
              child_cpu_seconds=after.ru_utime + after.ru_stime - usage.ru_utime - usage.ru_stime,
              scope='Isolated native fixture: format, compile, three identifier tests and original differential traces; no production service.')
raw = json.dumps(steps, sort_keys=True).encode()
result = dict(receipt=report, raw_steps_gzip_base64=base64.b64encode(gzip.compress(raw)).decode(),
              formatted_sources={name: (root / name).read_text() for name in ('transfer.rs', 'runner.rs', 'identifier_tests.rs')
                                 if (root / name).read_text() != files[name]})
(root / 'receipt.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
raise SystemExit(0 if report['passed'] else 1)
