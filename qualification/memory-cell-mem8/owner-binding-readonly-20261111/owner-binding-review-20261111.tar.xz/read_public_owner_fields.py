import pathlib,json,hashlib,re,stat
base=pathlib.Path('/home/qian-qi/.local/state')
specs=[
 ('roles',base/'hepta-real-source-native-signer-20261012/public_roles.json'),
 ('cleanup',base/'hepta-real-source-native-signer-20261012/test-only-key-cleanup-receipt.json'),
 ('startup',base/'hepta-native/last-startup.json')]
def walk(value,path=()):
 if isinstance(value,dict):
  yield path,value
  for k,v in value.items():
   if isinstance(v,(dict,list)):yield from walk(v,path+(str(k),))
 elif isinstance(value,list):
  for i,v in enumerate(value):
   if isinstance(v,(dict,list)):yield from walk(v,path+(str(i),))
out=[]
for kind,path in specs:
 try:
  st=path.lstat();assert stat.S_ISREG(st.st_mode) and not path.is_symlink() and st.st_size<=8192
  data=path.read_bytes();assert path.stat().st_size==len(data)
  obj=json.loads(data)
  selected=[]
  for pointer,node in walk(obj):
   if kind=='roles' and 'test_only' in node:
    names={k:v for k,v in node.items() if k in ['role','role_id','role_name','name','id'] and isinstance(v,str) and len(v)<=128}
    selected.append({'pointer':'/'+('/'.join(pointer)),**names,'test_only':node['test_only'] if isinstance(node['test_only'],bool) else 'unexpected_type'})
   elif kind=='cleanup':
    for k,v in node.items():
     if re.search('disposition|removed|deleted|status|cleanup|remaining',k,re.I) and not isinstance(v,(dict,list)):
      if isinstance(v,(bool,int,float)) or isinstance(v,str) and len(v)<=256:
       selected.append({'pointer':'/'+('/'.join(pointer+(k,))),'value':v})
     elif re.search('removed|deleted',k,re.I) and isinstance(v,list):
      selected.append({'pointer':'/'+('/'.join(pointer+(k,))),'items':len(v)})
   elif kind=='startup':
    for k,v in node.items():
     if re.search('release|numeric',k,re.I) and isinstance(v,(bool,int,float)):
      selected.append({'pointer':'/'+('/'.join(pointer+(k,))),'value':v})
     if re.search('time|date|_at$',k,re.I) and (isinstance(v,(int,float)) or isinstance(v,str) and re.match(r'^20\d\d[-/]',v)):
      selected.append({'pointer':'/'+('/'.join(pointer+(k,))),'value':v})
  out.append({'kind':kind,'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'selected_fields':selected})
 except (OSError,ValueError,AssertionError) as e:
  out.append({'kind':kind,'path':str(path),'error_type':type(e).__name__,'readable':False})
print(json.dumps({'schema':'mem8-existing-public-owner-fields-v1','files':out,'credential_values_read':False,'key_files_read':False,'service_environment_read':False,'service_mutations':False},indent=2),flush=True)
