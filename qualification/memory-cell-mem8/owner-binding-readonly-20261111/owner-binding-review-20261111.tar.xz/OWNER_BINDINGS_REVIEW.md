# Original MEM owner and cold-recovery bindings

Reviewed source: `0c32926cfec58d986477fc72ba3a4787ab75fde9` (F2), tree
`0d5aa1544aad103f9099c7c8347d8075d6ecc76e`. This is a read-only deployment-binding
review. The complete owner bridge passed exact-source native tests at `66f570a`;
F2's focused configuration and owner tests also passed. Those results do not
authenticate a deployed original MEM owner.

**No host examined in this bounded review has yet supplied an authenticated
original MEM writer, source verifier, independent final-use issuer and effect
owner as one usable deployment.** The statement is about the retained evidence,
not a claim that no such deployment exists anywhere.

## What the observed hosts actually establish

| Host / principal | Readable, retained evidence | What remains unbound |
| --- | --- | --- |
| `ai395`, operator `qq` | Original MEM6 archive; exact-source native build/test workspaces, including the F2 run; fresh CLI binary and clean source receipts. | No authenticated original MEM fleet entry, live writer lease/cut, source-owner adapter, final-use issuer or external-effect owner was supplied by these runs. Test-created SQLite owners and grants are fixtures. |
| `desktop`, operator `qian-qi` (UID 1000) | Existing inference service metadata; loopback Responses route GET observations; generic `hepta-secrets-*` service names and sockets; the bounded public reports below. | The generic secrets services have no authenticated binding here to MEM's `AgentdProductionWriterHost`, a source namespace, or `runtime.codex.turn_start`. Earlier protected runtime-directory / service-environment access was denied and was not bypassed. |
| GitHub actor `ProfHepta` and this workspace | Repository access; complete archive publication/copy; source and native evidence. | Repository administration and matching archive hashes do not supply runtime writer or issuer capabilities, independent trust, or effect custody. |

The desktop owner inventories were observed at 03:08:24 and 03:11:21 UTC on
2026-11-11. They list active inference/desktop services and generic secrets
sockets, but do not bind an original MEM Agentd control socket and generation.
The inventory is bounded; an absent matching row is not global nonexistence.

The separate 02:26:36 route observation recorded HTTP 200 for `/health`,
`/routing` and `/v1/models` at `http://127.0.0.1:18083/v1`, with model ID
`qwen38-flash-next-uc`. It made zero inference calls. An ordinary provider smoke
owned by another task remains a separate run; even a successful fixture smoke
would not authenticate this original memory/source/effect chain.

## The old public roles are explicitly test roles

A new, bounded read of only three already identified public JSON files completed
successfully on desktop at approximately 04:40:48 UTC. No signing-key file,
credential value, service environment, model request or service mutation was
involved. The selected fields and source-file hashes are retained in
`PUBLIC_OWNER_FIELDS.json`.

- `/home/qian-qi/.local/state/hepta-real-source-native-signer-20261012/public_roles.json`
  contains `evaluator`, `generator`, `observer`, `privacy` and `root`; each has
  `test_only=true`. The file is 1,943 bytes, SHA256
  `5cefa4958db77790e7a1d88c53af2bbde54ab6bb89f4f5cc87234d35300592c0`.
- The adjacent `test-only-key-cleanup-receipt.json` reports five key files
  removed, each `test_only_private_key_file_removed=true`, at
  `2026-10-12T01:25:51.153933+00:00`. This is a cleanup-receipt observation,
  not a new inspection of key material or proof of physical erasure. The file is
  932 bytes, SHA256
  `d981af4e6f28c25e467e1370795e2ec87cb1a847fd975e857022165c0f6c657e`.
- `/home/qian-qi/.local/state/hepta-native/last-startup.json` reports
  `release=false`. No startup timestamp was emitted by the limited-field read;
  this review does not infer a date or a current active release from it. The file
  is 597 bytes, SHA256
  `4148ff55e9e11ae2d1ef445822ef98fb626ea42d20965a9999d4a5f8e4cb7046`.

The role named `root` is still explicitly a test role. These old receipts have
no authenticated association with the MEM owner under review. Generic live
secrets services and these old test-role files are separate observations.

## The concrete bindings still needed

| Binding | Existing implementation and exact inputs | Current evidence boundary |
| --- | --- | --- |
| Original Agentd identity | `AgentdConfig::from_process_environment` / `load` require fleet root, agent ID, spawn generation, home/run roots, Codex home and workspace; the registry must admit the exact Starting generation and matching paths. The recovered writer must match the agent ID and spawn generation. | No original MEM registry entry, home/run layout or control/App Server socket has been authenticated. Environment strings alone do not create that registry admission. |
| Canonical memory owner | `AgentdProductionWriterHost::open_with_recovery(config, requirement, authority, verifier, lease_id, lease_generation)` checks `verify_sender_process_binding` and opens the canonical store under the supplied recovery requirement. The required current lease and exact recovery cut come from the original authority/custody path. | Native tests supply explicit fixture capabilities. The original deployed lease/verifier and exact cut have not been supplied. A fresh fixture owner would not recover the original owner. |
| Source namespace | `AgentdConfig::with_episodic_snapshot_import(namespace, Arc<dyn EpisodicSnapshotVerifier>)` requires an already attached writer with `production_mutation() != None`. Namespace is host-fixed and imports are agent-private. | A production source-owner adapter has not been authenticated or deployed. Ordinary environment startup initializes both writer and episodic ingress as absent. A provider URL cannot supply this adapter. |
| Actual source admission | `EpisodicSnapshotVerifier: Send + Sync` exposes `verify_current(&str) -> Result<EpisodicSnapshotAdmission, String>`. The return value contains `BTreeMap<record_id, EpisodicRecordAdmission { source: SourceDraft, verification: MemoryVerification }>` and an optional withdrawal `SourceDraft`. | The original source owner must attest the complete current namespace, exact observed fact bytes and source metadata, versions/dependencies and withdrawal events. The verifier is not deserialized from the import request. Custody/digests do not promote Provisional facts to Verified. |
| Fresh native inference | `hepta-infer-worker --profile native-app-server` needs original Agentd socket/agent/generation, observed model, retained journal/request ID, in-flight bound and final-use authority config; `--context-query` selects explicit owner context. | Existing provider reachability and ordinary smoke fixtures do not bind the original MEM owner or native worker final-use grant. F2 closes the selected automatic memory/history contributors only when the host has configured episodic ingress. |
| Independent final-use issuer | `FinalUseAuthorizerConfig` requires `issuer_socket`, `issuer_uid`, `signer_id`, public `verifying_key`, retained `authority_state_dir`, `authority_epoch`, `revocation_revision`, revoked grant IDs and timeout. The worker requests and consumes an exact `runtime.codex.turn_start` grant and checks the issuer peer. | No observed service/config has yet been authenticated for this operation and original owner. No signing key belongs in the worker or a request. A second operator-controlled copy is not evidence of independent issuer custody. |
| Real effect and outstanding requests | `AgentdProductionOperationRuntimeConfig` / `attach_target` bind the original `FinalUseProductionOutboxTarget`, stable destination ID, final-use authority, external grant provider and reconcile interval. `production_writer_reconcile.rs::reconcile` observes pending outcomes; reauthorization remains through the original grant provider. `DurableInferenceControl` retains request state across uncertain dispatch. | Original external target state, destination registration, pending outbox requests, grants/revocations and inference journal have not been restored together. Copying a delivery receipt or inventing a new request ID cannot settle an unknown effect. |

The current control request is usable once the original host supplies those
bindings: `AgentdClient::import_episodic_snapshot(snapshot_json)` sends at
most 20 KiB to the ordinary UDS path. It carries no source verifier, verification
level or caller-selected authority. Canonical import/replay/update/withdrawal and
drain/cancellation behavior are implemented and tested; the deployment binding
is the remaining work.

## A concrete execution order using existing entries

1. **Obtain the original deployment descriptor, not a new registration.** The
   original operator needs to identify the existing authority config,
   registration and native profile, original fleet/agent/generation/socket
   metadata, and the pre-held owner pidfd. The existing
   `hepta-authority-host diagnose-native --config ... --registration ...
   --native-profile ... --owner-pidfd-stdin` is the closest read-only executable
   entry for those original inputs. It cannot be made valid by placing a numeric
   PID in stdin. No matching MEM descriptor has been verified here.
2. **Diagnose the existing provider route with its existing route file.**
   `hepta-authority-host provider-status --route ...` is available and reads the
   original route configuration. A bare loopback URL is not that route file or
   an owner authorization. The ongoing provider smoke remains under its original
   task/request identity; this review makes no additional provider request.
3. **Wire the authenticated source adapter in the original embedding.** Reuse
   the recovered `AgentdProductionWriterHost`; attach it with
   `with_production_writer_host`, then use
   `with_episodic_snapshot_import` with the permitted namespace and original
   source verifier. The remaining adapter must have a real source custody
   interface and bounded current-state reads. Adding a JSON/hash verifier or a
   fixture grant would not implement this step. Existing Notes/Desktop objective
   compositions are explicitly rejected by this new ingress; their identities
   must not be borrowed for MEM.
4. **Reconcile the current snapshot before the first explicit read.** Send the
   original current namespace through the normal control client and retain the
   returned canonical bindings/receipt. E deliberately rejects a cold configured
   reader until a current import/reconcile establishes its retained source
   observation. Reuse the original namespace and receipt identity after a lost
   ACK. V1 retired fact slots remain closed even for a later Python version;
   that narrower policy is not a full Python rebuild guarantee.
5. **Run one fresh native session with the retained request journal.** Use the
   original socket, agent/generation and final-use config, and capture the actual
   provider input/output and canonical context/revalidation receipts. Native
   `hepta-infer-worker` has the existing empty tool router. F2 additionally
   disables automatic Hepta memory, independent MemoryTool, TokenBudget/history
   and model cognitive writes. Host prompt runtime and skills remain outside
   that profile's claimed isolation and must be accounted for in any off/on
   payload comparison.
6. **Only then qualify a cold owner/effect restart.** Recover the same canonical
   store and authorized successor owner generation using the original authority,
   restore the retained inference/outbox identities, and reconcile against the
   original registered target/readback. An unknown dispatched request must be
   reconciled under its existing ID; no second effect is authorized merely to
   obtain a clean receipt. This requires the real owner/target inputs above and
   has not been executed by this review.

No new owner, grant, signer, source role, service configuration or protected
credential is created by this plan. Until the original deployment descriptor and
source custody interface are supplied, repeating native fixture tests cannot
close the deployment boundary.

## Archive and trust boundary

The MEM6 archive is now completely copied/published: 61,412,948 bytes, SHA256
`f77acd9feb27fda3f8000b0d089dbdbe258a4adfb7acedcb2e0cd590cc4f361e`, with a verified
second-host file restore. Its `ARCHIVE_COMPLETE_INDEX.json` explicitly records
`external_runtime_inputs_included=false`, `full_owner_cold_recovery=false`, and
`independent_trust_domain=false`. Those fields remain accurate: source/runtime
capabilities, independent issuer state and real external effects have not been
recovered by archive copying or the new software tests.

## Source and retained evidence

- [Product memory contract](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/qualification/memory-cell-mem7/PRODUCT_MEMORY_CONTRACT.md): historical implementation/execution contract. Its old “bridge absent” finding is superseded by the tested MEM8 source; its original-owner/effect acceptance boundary is not.
- [Owner recovery and target seam](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-agentd/src/production_writer_host.rs), [config composition](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-agentd/src/config.rs), [episodic configuration](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-agentd/src/config_episodic.rs), [typed source admission](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-memory/src/episodic_source.rs).
- [Original Root launcher](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-agentd/src/production_launcher.rs), [authority-host CLI](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-agentd/src/bin/hepta-authority-host.rs), [independent final-use configuration](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-infer-worker-host/src/final_use_authorizer.rs), [native request reconciliation](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-infer-worker-host/src/native_run_control.rs), [effect reconciliation](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/0c32926cfec58d986477fc72ba3a4787ab75fde9/codex-rs/hepta-agentd/src/production_writer_reconcile.rs).
- Retained metadata in this directory: `OWNER_RUNTIME_INVENTORY.json` (18,322 bytes, SHA256 `3dbcca410cf103319f8aab703c52dad5c7dcbcc341ce70ae793dfca0f8a3a0eb`), `OWNER_RUNTIME_INVENTORY_V2.json` (5,724 bytes, SHA256 `94c8f2b63f675e2e605737e541a2a4c3a21972e042187c7fa6b623fcbb13e388`), `METADATA_READBACK.json`, `PUBLIC_OWNER_FIELDS.json`, `PUBLIC_OWNER_FIELDS_TRANSPORT.json`, and the exact restricted read script.
- Historical desktop operator/service evidence: `mem-next-runtime/RUNTIME_STATUS.json`, `desktop-bindings-resources.json`, `desktop-inventory.json`. Their old transport outage and partial-archive fields have been superseded and are not used as current blockers.

Scientific adoption remains **HOLD / NoUpdate**. No new actor-benefit result or
original-owner cold-recovery result is asserted here.
