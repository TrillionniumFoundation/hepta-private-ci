"""Check this evidence bundle; never execute its retained collector."""

import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile


def identity(raw):
    return {
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "git_blob": hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest(),
    }


def verify(files):
    manifest = json.loads(files["PACKAGE_MANIFEST.json"])
    expected = manifest["files"]
    paths = [entry["path"] for entry in expected]
    assert len(paths) == len(set(paths))
    assert set(files) == set(paths) | {"PACKAGE_MANIFEST.json"}
    for entry in expected:
        assert identity(files[entry["path"]]) == {
            key: entry[key] for key in ("bytes", "sha256", "git_blob")
        }, entry["path"]
    original = json.loads(files["MANIFEST.json"])
    for entry in original["files"]:
        assert identity(files[entry["path"]]) == {
            key: entry[key] for key in ("bytes", "sha256", "git_blob")
        }, entry["path"]
    return {"passed": True, "members": len(files), "indexed_files": len(paths)}


if len(sys.argv) == 2:
    with tarfile.open(sys.argv[1], "r:xz") as archive:
        entries = archive.getmembers()
        names = [entry.name for entry in entries]
        assert len(names) == len(set(names))
        assert all(
            entry.isfile()
            and not PurePosixPath(entry.name).is_absolute()
            and ".." not in PurePosixPath(entry.name).parts
            for entry in entries
        )
        payload = {entry.name: archive.extractfile(entry).read() for entry in entries}
elif len(sys.argv) == 1:
    root = Path(__file__).resolve().parent
    entries = list(root.iterdir())
    assert all(entry.is_file() and not entry.is_symlink() for entry in entries)
    payload = {entry.name: entry.read_bytes() for entry in entries}
else:
    raise SystemExit("usage: python3 -B verify_bundle.py [archive.tar.xz]")

print(json.dumps(verify(payload), sort_keys=True))
