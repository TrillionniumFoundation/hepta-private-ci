# PR 5406：两个 native presentation 失败日志诊断

本次读取两个已完成 job 的完整日志，确认共同阻断是 **Clippy 对本轮新增测试辅助代码的 `unnecessary_mut_passed` 诊断**，最终步骤退出码均为 101。不是观察到的测试断言失败；此前两个 Rust 测试组和 JUnit 检查已经通过。本次只读诊断未修改源码、重跑测试或写入 GitHub。

## 来源与实际受测身份

仓库：`TrillionniumFoundation/hepta-private-ci`；PR 5406；workflow run `42521292085`，attempt 1。原 Mac 使用 `ProfHepta` 的 gh 身份读取 job metadata 与完整日志。Workflow 的 `head_sha` 只作为关联字段，下面的实际受测身份来自日志中的 `hepta_ci_exec.py` before/after 回执。

| Job | 实际受测 commit | 实际 tree |
|---|---|---|
| `128855152428`，source-head | `cfe941b4762a773679a552068d1560ae17a3f226`（R） | `e6fc9a1cb7c2441c1811d08356f7e31b2e886177` |
| `128855152530`，base-merge | `29e4c3e669089e3efa50a1948496e452c6802b59` | `e6fc9a1cb7c2441c1811d08356f7e31b2e886177` |

合并 commit 的回执 parents 为 C `b839558b26c2e5b667055ca4af4ad749ae41c043` 与 R；其 tree 恰好相同，commit 身份仍须分开。三个受监督执行组均记录 before/after 相同、`dirty=false`。Clippy 之后的 `sha256sum` 和最终 `git diff --exit-code` 因 `set -euo pipefail` 提前终止，没有执行；不能扩大为整个 job 最终 clean 已确认。

这两个 hosted job 都安装并绑定 **Rust 1.95.0**，断言 `rustc 1.95.0 (59807616e 2026-04-14)`。这与此前本地 R/U 使用的 Rust 1.96 是不同环境。

## 已执行内容及失败位置

两个 lane 都得到同样的测试计数：

| 阶段 | 实际结果（每 lane） |
|---|---|
| `test_native_composition_junit.py` | 12 passed，0 failed |
| `--no-default-features --features native-presentation --lib --profile native-composition-headless` | 29 passed，0 skipped |
| `--features ui,native-host,native-presentation --lib --profile native-composition-native` | 54 passed，0 skipped |
| JUnit required-name checks | headless 和 native 均 passed |
| 后续 Clippy | failure，exit 101 |

失败命令由完整步骤日志明确给出：

```sh
cargo clippy --locked --manifest-path apps/hepta-control-ui/rust/Cargo.toml   -p hepta-robrix-ui --all-targets   --features ui,native-host,native-presentation -- -D warnings
```

诊断位置为 `apps/hepta-control-ui/rust/robrix-ui/src/robrix/room_ime_commit_tests.rs:34:37`：

```rust
let input = root.text_input(&mut cx, ids!(message_input));
```

Clippy 明确指出 `text_input` 不需要可变引用；`-D warnings` 将 `clippy::unnecessary_mut_passed` 提升为错误，并给出 `&cx` 的建议。没有必要添加 allow、削弱门禁或改变测试断言。另有依赖库 warning，但日志的最终致命诊断明确落在上述新增测试代码。

## 归因与范围

封存的 U commit `0e6fbff34b4f9ad9555de057d8807666f2668e84` 的 `U.patch` 将该文件标记为新增，并包含上述 `+` 行；两个 R 相关 job 又报告同一行。因此有直接对比证据将这个具体 lint 问题归为本轮 U/R 引入，归因不扩大到其它 CI 失败。

建议的最小修复为这一处 `&mut cx` → `&cx`。此报告只记录观察与建议；修复及其验证应另建源码身份和回执。已经通过的 29/54 测试属于这两个实际执行 lane，不能替代浏览器 Firefox E2E、设备 renderer、其余 CI 或生产学习闭环证明。

## 原始证据完整性

| 完整日志 | Bytes | SHA-256 |
|---|---:|---|
| `job-128855152428.log` | 1,666,900 | `c90b87478b55293da6d51a4d1ba1e7029f2e0a9524f6b8697729b75ea0de3df1` |
| `job-128855152530.log` | 1,672,193 | `2db9ce8736e5263d6524f4e5929b313e0b59951f9cc9c68b79ad1320b7903632` |

两文件合计 3,339,093 bytes、20,071 行。完整文件均已读取、扫描并保留，没有用 tail 代替原始日志。关键命令、测试回执、checkout pins 与完整错误上下文另存包内 `ANALYSIS.json`，原始日志不做裁剪或清洗。

同目录 `ui-native-failure-evidence.tar.gz` 包含完整日志、原 GET 请求/响应、下载命令与真实 returncode、远端 manifest、来源 pins、引入该行的 U patch 与本地分析。`RECEIPT.json` 保存原 Mac h job 的权威终态、分块版本与各块 SHA、原始归档 SHA 和最终交付包 SHA。

只读抓取 h job：`1a1bcf30414-138b0-538`；权威状态 `succeeded`，exit 0，`timed_out=false`，日志完整且未截断。这是取证过程成功，不是 CI job 成功。
