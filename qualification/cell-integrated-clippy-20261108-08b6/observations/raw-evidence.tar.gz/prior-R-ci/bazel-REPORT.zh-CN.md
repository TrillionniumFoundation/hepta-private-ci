# PR 5406 的三个已完成失败 job：只读诊断

这三项失败仍然成立。**cargo-deny 只剩已知的 `RUSTSEC-2026-0451`；GNU 和 musl 的 Bazel job 各有六个失败目标，其中五个与原 C 对应 PR 的既有失败症状相同，另一个是新增观察到的终态恢复测试 `WriterUnavailable`。** 不能将两个 Bazel job 的所有失败都称为旧问题；也没有足够证据把新增观察归因为 R 引入。

本次仅下载所指定的三个已完成 job 的原始日志，读取各自 metadata、当前账号 login，以及日志实际 checkout 的一个 Git commit 对象。没有请求整个 workflow 后续 jobs、修改源码、重跑 CI 或写入 GitHub。

## 实际 checkout 与失败身份

工作流为 `blocking-ci`，run `42521292055`，attempt 1。三个 job metadata 都是 completed/failure，workflow head 为 R `cfe941b4762a773679a552068d1560ae17a3f226`。

**实际 checkout 不能由 workflow head 推断。** 三份原日志都明确记录了 `/usr/bin/git log -1 --format=%H` 及其完整返回值：`4bc603a8e38886b72c3ab4a3367cc9cf9968d234`。这是 PR 5406 的 merge commit；随后只读 Git commit API 证实其父提交为 C `b839558b26c2e5b667055ca4af4ad749ae41c043` 和 R，tree 为 `e6fc9a1cb7c2441c1811d08356f7e31b2e886177`，精确等于 R 的 Git tree。

| Job | 已完成的失败步骤 | 日志中的实际 checkout 证据 |
| --- | --- | --- |
| `128855244522` cargo-deny | Run cargo-deny | 原日志第 234–235 行 |
| `128855244828` Ubuntu GNU Bazel | bazel test //... | 第 129–130 行 |
| `128855244840` Ubuntu musl Bazel | bazel test //... | 第 129–130 行 |

此身份是日志所证实的 checkout commit 与 Git tree；本次没有额外获取 CI 工作树执行前后的全文件字节快照，因此不将它升级为整个 CI 运行期间的物理字节不变证明。

## cargo-deny：一个阻断公告

原日志只有一条 `error[...]` 阻断头：`error[vulnerability]: Degraded secret zeroization capabilities`，指向 **vodozemac 0.10.0 / RUSTSEC-2026-0451**。终局输出为 `advisories FAILED, bans ok, licenses ok, sources ok`。

原 C 对应 job `128831894830` 的已存诊断有两个阻断：pin-utils 的 `RUSTSEC-2026-0441` 和 vodozemac 的 `0451`。本次三个日志中，cargo-deny 没有再报 pin-utils 的 unmaintained error，只有 `0451`。这是对 P/R 所消除的 pin-utils 阻断的托管日志观察，不能解释成 cargo-deny 通过，也不替代未完成的 Matrix/vodozemac 升级。

当前证据定位：cargo-deny 原日志第 **172432** 行为唯一阻断头，紧随其后的 crate、公告与修复范围均保留在原件和 `EXTRACT-128855244522.json`。

## Bazel：五个重现症状与一个新增观察

两个 job 最终均报告：**408 tests pass、6 fail remotely、164 skipped，共 578 个目标**。GNU 实际执行 142 个目标，musl 执行 153 个；这里的缓存/目标计数不是本机共同验证的 112 项测试分母。

| 失败目标 | 实际错误 | 与原 C 对应 Linux 日志的关系 |
| --- | --- | --- |
| `exec-server-capability_discovery-test` | 测试要求原 PATH 中存在真实 bubblewrap | 相同症状已见 |
| `exec-server-file_system_unix-test` | `real bubblewrap must be available on the original PATH` | 相同症状已见 |
| `hepta-agentd-cognitive-product-qualification-test` | `current projection rows did not match their generation receipt` | 相同症状已见 |
| `hepta-operator-acceptance-tests` | 签名 fixture 找不到平台目录或绝对 PATH 中的 OpenSSH `ssh-keygen` | 相同症状已见 |
| `core-all-wine-exec-test` | `abort_tasks.rs:211` 的 remote cwd/workspace roots 比较失败；涉及 `/%00/bad/path` 和 `/C:/...` 路径 | 相同症状已见 |
| `hepta-infer-worker-host-unit-tests` | 终态恢复测试 unwrap `Err(WriterUnavailable)` | **本次新增失败观察**；旧 C 对应目标为缓存通过 |

新增目标中的真实失败测试是：

```text
native_app_server::recovery::reconciliation_tests::
reopened_terminal_reconciliation_preserves_usage_and_irreversible_boundaries
```

它在 `hepta-infer-worker-host/src/native_reconciliation_tests.rs:250:80` 调用 `Result::unwrap()` 时得到 `WriterUnavailable`。该目标真实分母为 **49 passed / 1 failed / 0 ignored**，16.93 秒。GNU 第 **7998–8006** 行、musl 第 **7854–7862** 行完整保留了 panic 和结果；日志后面的诊断汇总再次打印相同内容，不能重复计算成新的失败样本。

旧 C 对应 PR 5395 的 GNU/musl 日志分别为 `128831895074` / `128831895303`，实际 checkout 是另一个 merge commit `52844015bb029bc6ac52cc4545555c491562543e`。它们各有五个失败目标、409 pass、164 skipped，而且本次新增的 infer-worker-host 目标明确标记为 `(cached) PASSED in 16.8s`。因此，旧缓存通过不能充当同条件重新执行的因果对照。

C..R 的已核验四文件变更不包含该恢复测试源码，但包含依赖锁变化。本次没有做最小复现、依赖归因或时序对照实验，不能据“该源码未改”排除关联，也不能据新增失败就断言由 R 引入。两个 job 还会使用远程执行/缓存；没有把相同失败输出当作独立科学重复实验。

## 获取过程、原件与限制

首次原 Mac `gh` 身份 GET 在 TCP 建连时超时，exit 1，30.082223 秒，尚未请求任何 job 日志。原请求、空 stdout、stderr 和 h 终态完整保留；只对该 GET 做了一次具名补取，成功确认 viewer 为 `ProfHepta`。随后三个 metadata GET 均为 HTTP 200，三个 logs GET 均 exit 0，每个 job 日志只下载一次；最后读取一个实际 checkout commit 对象。全部为 GET，清除了 `GH_DEBUG`，没有打印或转存登录凭据。

`failed-job-raw.tar.gz` 是 47 个成员的确定性 gzip/tar，包含三份完整 `gh api /actions/jobs/{id}/logs` 输出、metadata HTTP 原件、提取内容、实际 checkout commit 对象、所有获取 intent/result、控制程序和逐文件 MANIFEST。日志 hash 绑定 gh 完成 API redirect 后返回的完整字节；**不是**服务器 ZIP 或 HTTP wire bytes 的 hash。第一次身份 GET 的失败也在包中。

| 完整日志 | Bytes | SHA256 |
| --- | ---: | --- |
| cargo-deny `128855244522` | 19,617,552 | `b4a1738afb4c84bd229a6ef1bab6b247917c0b057bd6cf952228bef1a86856ca` |
| GNU `128855244828` | 1,112,383 | `ad04910b3abce8896340f1e96dc6c04297317586598ceb280acad139bc9eb361` |
| musl `128855244840` | 1,099,162 | `3e915fa50eb5c53db35c72b8d93b807b526a0549b48256367e3a9a3a18b840c1` |

原始包为 **1,864,338 bytes**，SHA256 `9cdcff5dec447eee0581a24d9824170217d6c65ede957462c2aebc82e820da68`。本地转运逐 chunk 绑定原文件 version，并已核验全包及全部 manifest 成员的 bytes/SHA。`RECEIPT.json` 保留 h 任务权威终态、获取/转运身份、源码 pins、比较基线日志 pins 和分析边界。

这三项失败不能被本机 112 项共同控制的通过抵消；本机 Bazel error-mode 验证的是锁一致性，托管 `bazel test //...` 验证的范围不同。本报告没有宣称整体 CI、科学收益、生产资格或新的 S 修复已经通过。R 的另一项 Rust 1.95 Clippy 问题由独立任务处理，不混入这三个 job 的诊断。
