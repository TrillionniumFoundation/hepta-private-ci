"""Prepare a separate exact-S worktree and verify inputs before any S common test."""

from datetime import datetime, timezone
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path("/home/qian-qi/work/cell-integration-20261108-08b6")
OUTPUT = ROOT / "clippy-common-preflight-001"
SOURCE = ROOT / "clippy-validation-source"
S = "693a013b254d07779f6f2b2a78d0ee31481f4ea9"
ST = "f06389aa4f5caf0af5fec419da6473e198796b24"
R = "cfe941b4762a773679a552068d1560ae17a3f226"
FILE = "apps/hepta-control-ui/rust/robrix-ui/src/robrix/room_ime_commit_tests.rs"


def main():
    module_path = ROOT / "clippy-common-validation-001/validate_successor_s.py"
    spec = importlib.util.spec_from_file_location("validate_s", module_path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    require = m.require
    start = time.monotonic()
    report = {
        "schema": "hepta.successor-S-preflight.v1",
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "source": S,
        "tree": ST,
        "base_R": R,
        "test_execution": False,
        "steps": [],
        "resources_before": m.resources(),
    }
    env = os.environ.copy()
    env.update(
        RUSTUP_TOOLCHAIN="1.96.0",
        CARGO_BUILD_JOBS="2",
        CARGO_TARGET_DIR=m.UI_TARGET,
        CARGO_TERM_COLOR="never",
        PYTHONDONTWRITEBYTECODE="1",
    )
    env["PATH"] = ":".join([m.RUST_BIN, str(m.TOOLS), m.CHAIN_BIN, env["PATH"]])

    def save():
        m.dump(OUTPUT / "PREFLIGHT.json", report)

    def run(name, args, cwd=SOURCE):
        before = resource.getrusage(resource.RUSAGE_CHILDREN)
        clock = time.monotonic()
        out, err = OUTPUT / (name + ".stdout"), OUTPUT / (name + ".stderr")
        with out.open("xb") as stdout, err.open("xb") as stderr:
            p = subprocess.run(
                args,
                cwd=cwd,
                env=env,
                stdout=stdout,
                stderr=stderr,
                timeout=120,
                check=False,
            )
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
        report["steps"].append(
            {
                "name": name,
                "argv": args,
                "cwd": str(cwd),
                "exit_code": p.returncode,
                "wall_seconds": time.monotonic() - clock,
                "child_cpu_seconds": after.ru_utime
                + after.ru_stime
                - before.ru_utime
                - before.ru_stime,
                "stdout": m.pin(out),
                "stderr": m.pin(err),
            }
        )
        save()
        require(p.returncode == 0, name + " preflight failed")
        return out

    try:
        require(
            m.git(ROOT / "clippy-source", "rev-parse", "HEAD") == S
            and not m.git(
                ROOT / "clippy-source", "status", "--porcelain", "--untracked-files=all"
            ),
            "Owner S not frozen/clean",
        )
        require(
            m.git(ROOT / "followup-source", "show", "-s", "--format=%P", S) == R,
            "S parent differs",
        )
        require(
            m.git(ROOT / "followup-source", "diff", "--name-only", R, S) == FILE,
            "S has unexpected paths",
        )
        require(
            m.git(ROOT / "followup-source", "diff", "--numstat", R, S)
            == "1\t1\t" + FILE,
            "S diff is not the frozen one-line change",
        )
        run(
            "create-validation-worktree",
            [
                "git",
                "worktree",
                "add",
                "-b",
                "engineering/cell-integrated-20261108-08b6-clippy-validation",
                str(SOURCE),
                S,
            ],
            ROOT / "followup-source",
        )
        run("just-fmt", ["just", "fmt"], SOURCE / "codex-rs")
        run(
            "committed-format-check",
            [sys.executable, "-B", "scripts/format.py", "--check", "--base", R],
        )
        run("diff-check", ["git", "diff", "--check", R, S])
        sys.path.insert(0, str(SOURCE / "scripts"))
        report["source_before"] = m.tracked_identity(SOURCE, S, ST)
        profile = json.loads(m.PROFILE_PATH.read_text())
        actual = {
            name: importlib.metadata.version(name) for name in profile["dependencies"]
        }
        require(
            actual == profile["dependencies"] and sys.version_info[:3] == (3, 12, 3),
            "Python profile mismatch",
        )
        clippy = ROOT / "clippy-evidence/CLIPPY_RESULT.json"
        require(
            m.pin(clippy)["sha256"]
            == "e37938f2d00069298698ff914c262a1da794ed6b31bbcd5895457c1d16afe645",
            "Clippy receipt differs",
        )
        receipt = json.loads(clippy.read_text())
        require(
            receipt["source"] == S
            and receipt["tree"] == ST
            and receipt["clippy_returncode"] == 0
            and receipt["before"] == receipt["after"]
            and receipt["after"]["status"] == "",
            "Clippy did not finish on exact clean S",
        )
        report["same_source_clippy_receipt"] = m.pin(clippy)
        report["sdk_before"] = m.sdk_identity()
        assets = json.loads((m.OWNER / "RUNTIME_ASSETS.json").read_text())
        report["runtime_assets"] = assets
        for a in assets["assets"]:
            got = m.pin(Path(a["retained_path"]))
            require(
                all(got[k] == a[k] for k in ("bytes", "sha256")),
                "Retained font cache mismatch",
            )
            require(
                not (SOURCE / a["repo_path"]).exists(),
                "Font unexpectedly installed during preflight",
            )
        metadata = run(
            "locked-offline-ui-metadata",
            [
                "cargo",
                "metadata",
                "--locked",
                "--offline",
                "--format-version",
                "1",
                "--manifest-path",
                str(SOURCE / "apps/hepta-control-ui/rust/Cargo.toml"),
            ],
        )
        values = json.loads(metadata.read_text())
        packages = [
            {k: p[k] for k in ("name", "version", "source", "manifest_path")}
            for p in values["packages"]
            if p["name"] in ("makepad-draw", "makepad-platform", "makepad-widgets")
        ]
        require(
            len(packages) == 3
            and all(
                str(m.SDK) + "/" in p["manifest_path"]
                and p["source"].endswith("#" + m.SDK_HEAD)
                for p in packages
            ),
            "Actual SDK resolution differs",
        )
        report["resolved_makepad"] = packages
        report["sdk_after"] = m.sdk_identity()
        require(
            report["sdk_after"] == report["sdk_before"], "SDK changed during preflight"
        )
        report["source_after"] = m.tracked_identity(SOURCE, S, ST)
        require(
            report["source_before"] == report["source_after"],
            "S changed during preflight",
        )
        report["exit_code"] = 0
    except BaseException as error:
        report.update(
            exit_code=1, error={"type": type(error).__name__, "message": str(error)}
        )
    finally:
        report.update(
            finished_at_utc=datetime.now(timezone.utc).isoformat(),
            wall_seconds=time.monotonic() - start,
            resources_after=m.resources(),
            cost_scope="S worktree/input preparation only; excludes later common validation and separate Rust 1.95 clippy. Nested steps not additive.",
        )
        save()
        print(
            json.dumps(
                {
                    "exit_code": report["exit_code"],
                    "source": S,
                    "tree": ST,
                    "wall_seconds": report["wall_seconds"],
                    "error": report.get("error"),
                }
            ),
            flush=True,
        )
    return report["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
