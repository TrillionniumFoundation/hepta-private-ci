"""Run common engineering gates on exact S; retain the expected deny failure."""

from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import resource
import shutil
import signal
import stat
import subprocess
import sys
import time
import tomllib

ROOT = Path("/home/qian-qi/work/cell-integration-20261108-08b6")
SOURCE = ROOT / "clippy-validation-source"
OUTPUT = ROOT / "clippy-common-validation-001"
PRIOR = ROOT / "followup-validation-001"
HEAD = "693a013b254d07779f6f2b2a78d0ee31481f4ea9"
TREE = "f06389aa4f5caf0af5fec419da6473e198796b24"
PYTHON = ROOT / "validation-venv/bin/python"
OWNER = Path("/home/qian-qi/work/cell-ui-ime-20261108-08b6-evidence")
SDK = Path("/home/qian-qi/.cargo/git/checkouts/makepad-69d78fae78fc8901/337566c")
SDK_HEAD = "337566c8b25d47f7e4fff6a202157b65bf183330"
SDK_TREE = "c6e18be7754f9634492ec5251bac3e8b4f7e09b7"
TOOLS = Path("/home/qian-qi/work/cell-dependency-pin-20261108-08b6-evidence/tools/bin")
AWS_TARGET = "/home/qian-qi/work/cell-dependency-pin-20261108-08b6-target"
UI_TARGET = (
    "/home/qian-qi/work/cell-ui-ime-20261108-08b6/apps/hepta-control-ui/rust/target"
)
PROFILE_PATH = (
    SOURCE / "qualification/cell-integrated-20261108-08b6/VALIDATION_PROFILE.json"
)
RUST_BIN = "/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin"
CHAIN_BIN = "/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin"


def require(value, message):
    if not value:
        raise RuntimeError(message)


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args]).decode().strip()


def pin(path, name=None):
    path = Path(path)
    require(
        path.is_file() and not path.is_symlink(), "Regular file required: " + str(path)
    )
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while raw := stream.read(1024 * 1024):
            digest.update(raw)
    return {
        "path": name or str(path),
        "bytes": path.stat().st_size,
        "sha256": digest.hexdigest(),
    }


def dump(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def resources():
    child = resource.getrusage(resource.RUSAGE_CHILDREN)
    result = {
        "self_cpu_seconds": time.process_time(),
        "child_user_seconds": child.ru_utime,
        "child_system_seconds": child.ru_stime,
        "child_maxrss_kib": child.ru_maxrss,
    }
    try:
        name = next(
            x[3:]
            for x in Path("/proc/self/cgroup").read_text().splitlines()
            if x.startswith("0::")
        )
        group = Path("/sys/fs/cgroup") / name.lstrip("/")
        result["cgroup_path"] = str(group)
        result["cgroup_values"] = {
            x: (group / x).read_text().strip()
            for x in ("cpu.max", "cpu.stat", "memory.max", "memory.peak")
        }
    except (OSError, StopIteration):
        result["cgroup_values"] = None
    return result


def tracked_identity(root, head, tree, allowed=(), raw_pins=()):
    """Complete raw-byte/mode check with an explicit, reported untracked set."""
    from hepta_cell_joint_config import (
        directory_root,
        file_fingerprint,
        parent_directory,
        regular_file,
    )

    status = git(root, "status", "--porcelain", "--untracked-files=all")
    require(
        status.splitlines() == sorted("?? " + name for name in allowed),
        "Unexpected checkout status: " + status,
    )
    identity = {
        "commit": git(root, "rev-parse", "HEAD"),
        "tree": git(root, "rev-parse", "HEAD^{tree}"),
        "index_tree": git(root, "write-tree"),
    }
    require(
        identity == {"commit": head, "tree": tree, "index_tree": tree},
        "Source identity differs",
    )
    versions = []
    exceptions = {p["path"]: p for p in raw_pins}
    seen_exceptions = set()
    rust_files = 0
    entries = subprocess.check_output(["git", "-C", str(root), "ls-tree", "-rz", tree])
    with directory_root(root) as root_fd:
        for entry in entries.split(b"\0"):
            if not entry:
                continue
            header, name = entry.split(b"\t", 1)
            mode, kind, oid = header.split()
            name = os.fsdecode(name)
            require(
                kind == b"blob" and mode in (b"100644", b"100755", b"120000"),
                "Nonblob source",
            )
            if mode == b"120000":
                with parent_directory(root_fd, name) as (parent, leaf):
                    before = os.stat(leaf, dir_fd=parent, follow_symlinks=False)
                    raw = os.fsencode(os.readlink(leaf, dir_fd=parent))
                    digest = hashlib.sha1(
                        b"blob " + str(len(raw)).encode() + b"\0" + raw
                    )
                    after = os.stat(leaf, dir_fd=parent, follow_symlinks=False)
                    require(
                        stat.S_ISLNK(before.st_mode)
                        and digest.hexdigest().encode() == oid
                        and file_fingerprint(before) == file_fingerprint(after),
                        "Symlink differs",
                    )
            else:
                with regular_file(root_fd, name) as stream:
                    before = os.fstat(stream.fileno())
                    actual_mode = b"100755" if before.st_mode & 0o111 else b"100644"
                    digest = hashlib.sha1(
                        b"blob " + str(before.st_size).encode() + b"\0"
                    )
                    sha256 = hashlib.sha256()
                    total = 0
                    while raw := stream.read(1024 * 1024):
                        total += len(raw)
                        require(total <= before.st_size, "Source grew")
                        digest.update(raw)
                        sha256.update(raw)
                    expected_oid = oid
                    if name in exceptions:
                        exact = exceptions[name]
                        require(
                            exact["expected_oid"].encode() == oid
                            and exact["expected_mode"].encode() == mode
                            and exact["bytes"] == total
                            and exact["sha256"] == sha256.hexdigest(),
                            "SDK physical bytes differ from frozen pins",
                        )
                        expected_oid = exact["actual_oid"].encode()
                        seen_exceptions.add(name)
                    if name.endswith(".rs"):
                        require(
                            digest.hexdigest().encode() == oid,
                            "Rust SDK source must equal Git blob",
                        )
                        rust_files += 1
                    require(
                        total == before.st_size
                        and actual_mode == mode
                        and digest.hexdigest().encode() == expected_oid
                        and file_fingerprint(before)
                        == file_fingerprint(os.fstat(stream.fileno())),
                        "Tracked bytes/mode differ: " + name,
                    )
            versions.append((name, file_fingerprint(before)))
        for name, fingerprint in versions:
            with parent_directory(root_fd, name) as (parent, leaf):
                require(
                    file_fingerprint(
                        os.stat(leaf, dir_fd=parent, follow_symlinks=False)
                    )
                    == fingerprint,
                    "Tracked path changed during complete check",
                )
    require(
        git(root, "status", "--porcelain", "--untracked-files=all") == status,
        "Status changed during check",
    )
    require(seen_exceptions == set(exceptions), "Unaccounted SDK physical pin")
    return {
        **identity,
        "status_porcelain": status,
        "allowed_untracked": list(allowed),
        "complete_tracked_files_verified": len(versions),
        "tracked_raw_bytes_modes_verified": True,
        "raw_bytes_equal_git_tree": not exceptions,
        "physical_byte_exceptions_bound": len(exceptions),
        "rust_source_files_verified_equal_git_blobs": rust_files,
    }


def sdk_identity():
    path = PRIOR / "SDK_CHECKOUT_NORMALIZATION.json"
    require(
        pin(path)["sha256"]
        == "cada5b43e95561b21a825b45ff23947dcb010f7dfccf22b89aafc4656109a096",
        "SDK normalization input changed",
    )
    normalization = json.loads(path.read_text())
    exact = normalization["raw_exceptions"]
    require(
        len(exact) == 29
        and all(p["normalization"] == "checkout_CRLF_to_git_LF" for p in exact),
        "SDK transform set differs",
    )
    require(
        git(SDK, "check-attr", "--all", "--", *[p["path"] for p in exact])
        == normalization["attributes"].strip(),
        "SDK attributes changed",
    )
    observed = tracked_identity(SDK, SDK_HEAD, SDK_TREE, [".cargo-ok"], exact)
    observed["checkout_physical_byte_normalization"] = normalization
    observed["normalization_input_pin"] = pin(path)
    observed["scope"] = (
        "29 explicitly pinned CRLF materializations of LF Git blobs per SDK gitattributes; all Rust sources and all other tracked files equal raw Git bytes; no SDK or Git configuration was modified."
    )
    observed["cargo_marker"] = pin(SDK / ".cargo-ok")
    observed["key_files"] = [
        pin(SDK / name, name)
        for name in (
            "widgets/src/text_input.rs",
            "platform/src/event/keyboard.rs",
            "platform/src/os/web/web.js",
            "platform/src/os/web/to_wasm.rs",
        )
    ]
    observed["wasm_ime_patch_applied"] = False
    return observed


def advisory_db():
    return [
        {
            "path": str(p),
            "head": git(p, "rev-parse", "HEAD"),
            "status": git(p, "status", "--porcelain"),
            "origin": git(p, "remote", "get-url", "origin"),
        }
        for p in sorted(Path("/home/qian-qi/.cargo/advisory-dbs").glob("advisory-db-*"))
        if (p / ".git").exists()
    ]


def main():
    require(
        OUTPUT.is_dir() and not (OUTPUT / "VALIDATION.json").exists(),
        "New validation receipt required",
    )
    sys.path.insert(0, str(SOURCE / "scripts"))
    from hepta_cell_joint_config import source_identity

    inherited = json.loads(PROFILE_PATH.read_text())
    require(
        pin(PROFILE_PATH)["sha256"]
        == "3e93559bfe523de91ca8a9366a645aaedbe232a2b60ef4839cd57361e94e4df3",
        "C Python profile drift",
    )
    assets = json.loads((OWNER / "RUNTIME_ASSETS.json").read_text())
    require(
        assets["manifestSha256"]
        == "fb9e49a7f14b742ac7e390ceee9be115ad6e04a5f852eec67fb0a126870070a3",
        "Font manifest drift",
    )
    allowed = sorted(a["repo_path"] for a in assets["assets"])
    env = os.environ.copy()
    env.update(inherited["thread_environment"])
    env.update(
        RUSTUP_TOOLCHAIN="1.96.0",
        CARGO_BUILD_JOBS="2",
        CARGO_TERM_COLOR="never",
        PYTHONDONTWRITEBYTECODE="1",
        PYTHONPATH=str(SOURCE / "scripts") + ":" + str(SOURCE),
    )
    env["PATH"] = ":".join([RUST_BIN, str(TOOLS), CHAIN_BIN, env["PATH"]])
    start = time.monotonic()
    receipt = {
        "schema": "hepta.clippy-followup-common-native-validation.v1",
        "source_commit": HEAD,
        "source_tree": TREE,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "steps": [],
        "production_qualification": False,
        "scientific_qualification": False,
        "joint_learning_configuration": None,
        "overall_gate_pass": False,
        "resources_before": resources(),
    }
    fonts_present = False

    def save():
        dump(OUTPUT / "VALIDATION.json", receipt)

    def identity():
        return tracked_identity(SOURCE, HEAD, TREE, allowed if fonts_present else ())

    def check_fonts():
        for asset in assets["assets"]:
            actual = pin(SOURCE / asset["repo_path"])
            require(
                all(actual[k] == asset[k] for k in ("bytes", "sha256")),
                "Installed font differs",
            )

    def run(name, args, timeout, *, target=None, expect=0, font_transition=False):
        runtime = env.copy()
        if target:
            runtime["CARGO_TARGET_DIR"] = target
        row = {
            "name": name,
            "argv": [str(a) for a in args],
            "cwd": str(SOURCE),
            "timeout_seconds": timeout,
            "source_before": identity(),
            "started_at_utc": datetime.now(timezone.utc).isoformat(),
            "cargo_target_dir": target,
        }
        if fonts_present:
            check_fonts()
        stdout, stderr = OUTPUT / (name + ".stdout"), OUTPUT / (name + ".stderr")
        before = resource.getrusage(resource.RUSAGE_CHILDREN)
        clock = time.monotonic()
        timed_out = False
        with stdout.open("xb") as out, stderr.open("xb") as err:
            child = subprocess.Popen(
                row["argv"],
                cwd=SOURCE,
                env=runtime,
                stdout=out,
                stderr=err,
                start_new_session=True,
            )
            try:
                code = child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    code = child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    code = child.wait(timeout=5)
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
        row.update(
            exit_code=code,
            timed_out=timed_out,
            wall_seconds=time.monotonic() - clock,
            child_cpu_seconds=after.ru_utime
            + after.ru_stime
            - before.ru_utime
            - before.ru_stime,
            finished_at_utc=datetime.now(timezone.utc).isoformat(),
            stdout=pin(stdout, stdout.name),
            stderr=pin(stderr, stderr.name),
        )
        receipt["steps"].append(row)
        save()
        if not font_transition:
            row["source_after"] = identity()
        if fonts_present:
            check_fonts()
        save()
        print(
            json.dumps(
                {
                    k: row[k]
                    for k in ("name", "exit_code", "wall_seconds", "stdout", "stderr")
                }
            ),
            flush=True,
        )
        require(
            not timed_out and (expect is None or code == expect),
            name + " unexpected exit",
        )
        return row

    def counts(row, expected):
        text = (OUTPUT / row["stderr"]["path"]).read_text()
        matches = re.findall(
            r"Summary\s+\[[^\]]+\]\s+(\d+) tests run: (\d+) passed, (\d+) skipped", text
        )
        require(
            matches == [(str(expected), str(expected), "0")],
            "Wrong nextest denominator: " + row["name"],
        )
        row.update(tests=expected, passed=expected, skipped=0, failed=0)
        save()

    try:
        receipt["source_before"] = identity()
        require(
            source_identity(SOURCE)
            == {"commit": HEAD, "tree": TREE, "index_tree": TREE},
            "Original clean source checker differs",
        )
        versions = {
            name: importlib.metadata.version(name) for name in inherited["dependencies"]
        }
        require(
            versions == inherited["dependencies"]
            and sys.version_info[:3] == (3, 12, 3),
            "Python runtime differs",
        )
        sdk_before = sdk_identity()
        tool_versions = {}
        for tool, args in [
            ("rustc", ["-Vv"]),
            ("cargo", ["-Vv"]),
            ("just", ["--version"]),
            ("cargo-nextest", ["--version"]),
            ("cargo-deny", ["--version"]),
            ("bazel", ["--version"]),
        ]:
            path = shutil.which(tool, path=env["PATH"])
            require(path, "Missing tool " + tool)
            tool_versions[tool] = {
                "binary": pin(Path(path).resolve()),
                "version": subprocess.check_output([path, *args], env=env, timeout=20)
                .decode()
                .strip(),
            }
        require(
            tool_versions["rustc"]["version"].startswith("rustc 1.96.0 "),
            "Rust version differs",
        )
        for a in assets["assets"]:
            value = pin(Path(a["retained_path"]))
            require(
                all(value[k] == a[k] for k in ("bytes", "sha256")),
                "Retained font differs",
            )
            require(
                not (SOURCE / a["repo_path"]).exists(),
                "Font destination must initially be absent",
            )
        lock = SOURCE / "apps/hepta-control-ui/rust/Cargo.lock"
        packages = tomllib.loads(lock.read_text())["package"]
        makepad_packages = [
            {k: p[k] for k in ("name", "version", "source")}
            for p in packages
            if p["name"] in ("makepad-draw", "makepad-platform", "makepad-widgets")
        ]
        require(
            len(makepad_packages) == 3
            and all(p["source"].endswith("#" + SDK_HEAD) for p in makepad_packages),
            "Makepad lock differs",
        )
        profile = {
            "schema": "hepta.clippy-followup-validation-profile.v1",
            "preflight_receipt": pin(
                ROOT / "clippy-common-preflight-001/PREFLIGHT.json"
            ),
            "same_source_separate_clippy_receipt": pin(
                ROOT / "clippy-evidence/CLIPPY_RESULT.json"
            ),
            "separate_clippy_scope": "Rust 1.95 original CI clippy runs on the same S in its owner worktree; exact receipt and artifact are separately preserved in G, not inferred from these 112 tests.",
            "source": {"commit": HEAD, "tree": TREE},
            "python_profile_exact_copy": inherited,
            "python_profile_source_pin": pin(PROFILE_PATH),
            "python_runtime": {
                "version": sys.version,
                "platform": platform.platform(),
                "executable": pin(Path(sys.executable).resolve()),
                "dependencies": versions,
            },
            "tools": tool_versions,
            "explicit_environment_additions": {
                k: env[k]
                for k in (
                    "RUSTUP_TOOLCHAIN",
                    "CARGO_BUILD_JOBS",
                    "CARGO_TERM_COLOR",
                    "PYTHONPATH",
                    "PYTHONDONTWRITEBYTECODE",
                    "PATH",
                    *inherited["thread_environment"],
                )
            },
            "other_environment": "Inherited host environment preserved, not dumped; no secret environment capture.",
            "job_budget": {
                "cpu_quota_percent": 200,
                "memory_max_bytes": 6442450944,
                "outer_timeout_seconds": 2400,
            },
            "targets": {
                "aws": AWS_TARGET,
                "ui": UI_TARGET,
                "ownership": "Both source owners explicitly released before R use.",
            },
            "fonts": assets,
            "font_policy": "Strict clean before installation; exactly two pinned untracked resources during UI test; exact-hash cleanup then strict clean.",
            "makepad": {
                "cargo_lock": pin(lock),
                "packages": makepad_packages,
                "actual_checkout_before": sdk_before,
                "web_patch": pin(
                    SOURCE
                    / "apps/hepta-control-ui/rust/robrix-ui/patches/makepad-wasm-ime.patch"
                ),
                "web_patch_applied_to_native_checkout": False,
                "scope": "Native SDK FullTextState/RoomScreen path; browser JS/WASM transport not exercised.",
            },
            "joint_learning_configuration": None,
            "production_qualification": False,
            "scientific_qualification": False,
            "required_tests": {
                "python_common_controls": 74,
                "aws_auth": 5,
                "native_ui_package": 33,
            },
            "expected_remaining_blocker": "RUSTSEC-2026-0451; no all-gates-green claim",
            "not_run": [
                "PRED confirmation",
                "Firefox/WASM/Playwright acceptance",
                "full hosted CI",
                "joint learned successor trial",
            ],
        }
        dump(OUTPUT / "VALIDATION_PROFILE.json", profile)
        receipt["profile"] = pin(
            OUTPUT / "VALIDATION_PROFILE.json", "VALIDATION_PROFILE.json"
        )
        receipt["makepad_before"] = sdk_before
        receipt["runtime_inputs"] = {
            "python_profile": profile["python_profile_source_pin"],
            "ui_lock": pin(lock),
            "cargo_lock": pin(SOURCE / "codex-rs/Cargo.lock"),
            "module_lock": pin(SOURCE / "MODULE.bazel.lock"),
        }
        save()
        row = run(
            "common-python-controls",
            [str(PYTHON), "-B", "-m", "unittest", "-v", *inherited["test_modules"]],
            360,
        )
        log = (OUTPUT / "common-python-controls.stderr").read_text()
        found = re.findall(r"^Ran (\d+) tests in ([0-9.]+)s$", log, re.MULTILINE)
        require(
            len(found) == 1
            and found[0][0] == "74"
            and re.search(r"^OK$", log, re.MULTILINE)
            and not re.search(r"\bskipped\b|\bexpected failure\b|^FAILED", log),
            "Common controls not exactly 74 passing",
        )
        row.update(
            tests=74,
            passed=74,
            skipped=0,
            failed=0,
            unittest_wall_seconds=float(found[0][1]),
        )
        save()
        counts(
            run(
                "aws-auth-tests",
                ["just", "test", "-p", "codex-aws-auth", "--locked"],
                900,
                target=AWS_TARGET,
            ),
            5,
        )
        meta = run(
            "ui-dependency-metadata",
            [
                "cargo",
                "metadata",
                "--format-version",
                "1",
                "--locked",
                "--manifest-path",
                str(SOURCE / "apps/hepta-control-ui/rust/Cargo.toml"),
            ],
            120,
            target=UI_TARGET,
        )
        metadata = json.loads((OUTPUT / meta["stdout"]["path"]).read_text())
        resolved = [
            {k: p[k] for k in ("name", "version", "source", "manifest_path")}
            for p in metadata["packages"]
            if p["name"] in ("makepad-draw", "makepad-platform", "makepad-widgets")
        ]
        require(
            len(resolved) == 3
            and all(str(SDK) + "/" in p["manifest_path"] for p in resolved),
            "Actual resolved SDK path differs",
        )
        dump(
            OUTPUT / "MAKEPAD_RESOLUTION.json",
            {
                "metadata_pin": meta["stdout"],
                "packages": resolved,
                "checkout_before_ui": sdk_identity(),
            },
        )
        row = run(
            "font-install",
            [
                str(PYTHON),
                "apps/hepta-control-ui/tools/prepare-fonts.py",
                "--cache",
                str(OWNER / "runtime-assets"),
                "--offline",
                "--install",
                str(SOURCE / "apps/hepta-control-ui/rust/robrix-ui/resources/fonts"),
            ],
            60,
            font_transition=True,
        )
        fonts_present = True
        row["source_after"] = identity()
        check_fonts()
        receipt["font_test_interval_before"] = identity()
        save()
        try:
            counts(
                run(
                    "native-ui-package",
                    [
                        "just",
                        "test",
                        "--manifest-path",
                        str(SOURCE / "apps/hepta-control-ui/rust/Cargo.toml"),
                        "--locked",
                        "-p",
                        "hepta-robrix-ui",
                        "--lib",
                        "--features",
                        "ui",
                    ],
                    900,
                    target=UI_TARGET,
                ),
                33,
            )
            receipt["font_test_interval_after"] = identity()
            receipt["makepad_after_ui"] = sdk_identity()
            require(
                receipt["makepad_after_ui"] == sdk_before,
                "SDK bytes changed during S tests",
            )
        finally:
            check_fonts()
            for asset in assets["assets"]:
                (SOURCE / asset["repo_path"]).unlink()
            fonts_present = False
            receipt["font_cleanup"] = {
                "removed_only_hash_verified_paths": allowed,
                "source_after": identity(),
            }
            save()
        run(
            "bazel-lock-error-check",
            [
                str(TOOLS / "bazel"),
                "--batch",
                "--output_user_root=" + str(ROOT / "clippy-common-bazel-user-root"),
                "--host_jvm_args=-Xmx1024m",
                "mod",
                "deps",
                "--lockfile_mode=error",
            ],
            600,
        )
        db_before = advisory_db()
        deny = run(
            "cargo-deny",
            [
                "/home/qian-qi/.cargo/bin/cargo",
                "deny",
                "--log-level",
                "warn",
                "--manifest-path",
                "./codex-rs/Cargo.toml",
                "--all-features",
                "check",
            ],
            300,
            target=AWS_TARGET,
            expect=None,
        )
        denylog = (OUTPUT / "cargo-deny.stderr").read_text()
        deny.update(
            advisory_db_before=db_before,
            advisory_db_after=advisory_db(),
            error_headers=re.findall(r"^error[^\n]*", denylog, re.MULTILINE),
            advisory_ids=sorted(set(re.findall(r"ID: (RUSTSEC-\d+-\d+)", denylog))),
            terminal_summary=(OUTPUT / "cargo-deny.stdout").read_text().strip(),
            gate_pass=False,
        )
        require(
            deny["exit_code"] == 1
            and deny["advisory_ids"] == ["RUSTSEC-2026-0451"]
            and deny["error_headers"]
            == ["error[vulnerability]: Degraded secret zeroization capabilities"],
            "Deny result changed; inspect actual log",
        )
        receipt["remaining_blockers"] = ["RUSTSEC-2026-0451"]
        save()
        archive = OUTPUT / "source.tar"
        run(
            "complete-source-archive",
            [
                "git",
                "archive",
                "--format=tar",
                "--prefix=source/",
                "--output=" + str(archive),
                HEAD,
            ],
            120,
        )
        binding = {
            "schema": "hepta.source-archive-binding.v1",
            "tested_source": {"commit": HEAD, "tree": TREE},
            "release_source": {"commit": HEAD, "tree": TREE},
            "archive": pin(archive, "source.tar"),
            "archive_prefix": "source",
            "runtime_configuration": pin(
                OUTPUT / "VALIDATION_PROFILE.json", "VALIDATION_PROFILE.json"
            ),
        }
        dump(OUTPUT / "archive-binding.json", binding)
        run(
            "complete-archive-integrity",
            [
                str(PYTHON),
                "-B",
                "scripts/hepta_source_archive.py",
                "--binding",
                str(OUTPUT / "archive-binding.json"),
                "--source-root",
                str(SOURCE),
                "--artifact-root",
                str(OUTPUT),
                "--output",
                str(OUTPUT / "archive-integrity.json"),
            ],
            180,
        )
        integrity = json.loads((OUTPUT / "archive-integrity.json").read_text())
        require(
            integrity["integrity_verified"] is True
            and integrity["integrity_only"] is True
            and integrity["tested_source"]
            == {"commit": HEAD, "tree": TREE, "index_tree": TREE},
            "Archive integrity differs",
        )
        receipt["archive"] = {
            "native_path": str(archive),
            **pin(archive, "source.tar"),
            "report": pin(OUTPUT / "archive-integrity.json", "archive-integrity.json"),
            "complete_tracked_files": len(integrity["files"]),
            "inventory_sha256": integrity["inventory_sha256"],
            "integrity_only": True,
            "test_execution_authenticated": False,
        }
        receipt["source_after"] = identity()
        require(
            source_identity(SOURCE)
            == {"commit": HEAD, "tree": TREE, "index_tree": TREE},
            "Final clean S source check differs",
        )
        receipt.update(
            validation_completed=True,
            successful_engineering_tests=112,
            harness_exit_code=0,
            release_observation_scope="Local S Git commit/tree only; no publication or hosted-CI claim.",
        )
    except BaseException as error:
        receipt.update(
            validation_completed=False,
            harness_exit_code=1,
            error={"type": type(error).__name__, "message": str(error)},
        )
    finally:
        receipt.update(
            finished_at_utc=datetime.now(timezone.utc).isoformat(),
            total_wall_seconds=time.monotonic() - start,
            resources_after=resources(),
            cost_scope="S validation process and children only, including failed cargo-deny; excludes prior C/P/U/R validation, S preparation, separate Rust 1.95 clippy, transfer and publication. Per-step costs are nested within total.",
        )
        save()
        print(
            json.dumps(
                {
                    "completed": receipt.get("validation_completed"),
                    "overall_gate_pass": False,
                    "harness_exit_code": receipt["harness_exit_code"],
                    "error": receipt.get("error"),
                    "source_commit": HEAD,
                    "source_tree": TREE,
                }
            ),
            flush=True,
        )
    return receipt["harness_exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
