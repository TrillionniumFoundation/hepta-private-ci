"""Freeze evidence-only G for actual common S validation; never publish."""

from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time

ROOT = Path("/home/qian-qi/work/cell-integration-20261108-08b6")
SOURCE = ROOT / "clippy-validation-source"
DEST = ROOT / "clippy-evidence-source-003"
OUT = ROOT / "clippy-delivery-003"
INPUTS = ROOT / "clippy-package-inputs-003"
FINAL = ROOT / "clippy-common-validation-001"
PRE = ROOT / "clippy-common-preflight-001"
CLIPPY = ROOT / "clippy-evidence"
C = "b839558b26c2e5b667055ca4af4ad749ae41c043"
E = "6c63d1aab2a4914c3559b368b1ade5a4748e8df7"
R = "cfe941b4762a773679a552068d1560ae17a3f226"
F = "fbccef047dfdd435808796dfc5d2d4223eb645c8"
S = "693a013b254d07779f6f2b2a78d0ee31481f4ea9"
ST = "f06389aa4f5caf0af5fec419da6473e198796b24"
SREF = "fix/cell-ui-ime-clippy-20261108-08b6"
GREF = "engineering/cell-integrated-20261108-08b6-clippy-evidence"
PREVIOUS_G = "ed6bd2eaa281c0ee9d718e5a03f4c92c3d5ec061"
PREVIOUS_GREF = GREF + "-second-unpublished"
OBS = Path("qualification/cell-integrated-clippy-20261108-08b6/observations")
ALLOW = ".github/blob-size-allowlist.txt"
PYTHON = ROOT / "validation-venv/bin/python"


def require(value, message):
    if not value:
        raise RuntimeError(message)


def git_bytes(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args])


def git(root, *args):
    return git_bytes(root, *args).decode().strip()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pin(path, name=None):
    require(path.is_file() and not path.is_symlink(), "Unexpected file type")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while raw := stream.read(1024 * 1024):
            digest.update(raw)
    return {
        "path": name or str(path),
        "bytes": path.stat().st_size,
        "sha256": digest.hexdigest(),
    }


def dump(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")


def read(path):
    return json.loads(path.read_text())


def clean(root, head):
    require(git(root, "rev-parse", "HEAD") == head, "Wrong frozen head")
    require(
        not git(root, "status", "--porcelain", "--untracked-files=all"),
        "Dirty frozen source",
    )
    return {"commit": head, "tree": git(root, "rev-parse", "HEAD^{tree}"), "status": ""}


def cpu(record):
    return sum(
        record["resources_after"][k] - record["resources_before"][k]
        for k in ("self_cpu_seconds", "child_user_seconds", "child_system_seconds")
    )


def main():
    OUT.mkdir(exist_ok=False)
    result, pre = read(FINAL / "VALIDATION.json"), read(PRE / "PREFLIGHT.json")
    profile, clippy = (
        read(FINAL / "VALIDATION_PROFILE.json"),
        read(CLIPPY / "CLIPPY_RESULT.json"),
    )
    connector = read(INPUTS / "CONNECTOR_JOB_OBSERVATIONS.json")
    startup = read(INPUTS / "STARTUP_RECONCILIATION.json")
    initial = read(INPUTS / "PREVIOUS_G_DELIVERY.json")
    require(
        initial["evidence"] == PREVIOUS_G and initial["published"] is False,
        "Initial unpublished evidence identity differs",
    )
    require(
        startup["original_001_request_was_sent"] is None
        and startup["original_001_cost"] is None,
        "Startup uncertainty was erased",
    )
    inventory_pin = startup["complete_retained_inventory"]
    require(
        all(
            pin(Path(inventory_pin["path"]))[k] == inventory_pin[k]
            for k in ("bytes", "sha256")
        ),
        "Inventory observation changed",
    )
    subset_pin = startup["published_inventory_extract"]
    require(
        all(
            pin(INPUTS / subset_pin["path"])[k] == subset_pin[k]
            for k in ("bytes", "sha256")
        ),
        "Interval extract changed",
    )
    clean(ROOT / "clippy-evidence-source-002", PREVIOUS_G)
    require(
        all(
            x["terminal"]["state"] == "succeeded"
            and x["terminal"]["exit_code"] == 0
            and x["terminal"]["output_complete"]
            for x in connector["jobs"]
        ),
        "Missing authoritative terminal",
    )
    require(
        result["source_commit"] == S
        and result["source_tree"] == ST
        and result["validation_completed"]
        and result["harness_exit_code"] == 0
        and result["successful_engineering_tests"] == 112
        and not result["overall_gate_pass"],
        "Common validation differs",
    )
    require(
        pre["source"] == S and pre["tree"] == ST and pre["exit_code"] == 0,
        "Preflight differs",
    )
    expected = {
        "common-python-controls": 74,
        "aws-auth-tests": 5,
        "native-ui-package": 33,
    }
    for step in result["steps"]:
        require(
            step["source_before"]["commit"] == S == step["source_after"]["commit"]
            and step["source_before"]["tree"] == ST == step["source_after"]["tree"],
            "Step source drift",
        )
        for stream in ("stdout", "stderr"):
            p = step[stream]
            require(
                all(pin(FINAL / p["path"])[k] == p[k] for k in ("bytes", "sha256")),
                "Raw log changed",
            )
        if step["name"] in expected:
            count = expected[step["name"]]
            require(
                step["exit_code"] == 0
                and step["tests"] == count
                and step["passed"] == count
                and step["skipped"] == 0,
                "Wrong test result",
            )
    require(
        set(expected).issubset(x["name"] for x in result["steps"]), "Missing test group"
    )
    deny = next(x for x in result["steps"] if x["name"] == "cargo-deny")
    require(
        deny["exit_code"] == 1 and deny["advisory_ids"] == ["RUSTSEC-2026-0451"],
        "Deny blocker differs",
    )
    require(
        all(x["exit_code"] == 0 for x in result["steps"] if x is not deny),
        "Other common gate failed",
    )
    require(
        pin(CLIPPY / "CLIPPY_RESULT.json")["sha256"]
        == "e37938f2d00069298698ff914c262a1da794ed6b31bbcd5895457c1d16afe645",
        "Clippy receipt drift",
    )
    require(
        pin(CLIPPY / "clippy-S-native-evidence.tar.gz")["sha256"]
        == "dcb07fcf1426bf2cd3c0ffa0e4b4af7cc212c5f3533bc78ef3fad0c6a7aaaf0f",
        "Clippy archive drift",
    )
    require(
        clippy["source"] == S
        and clippy["tree"] == ST
        and clippy["clippy_returncode"] == 0
        and clippy["before"] == clippy["after"]
        and clippy["after"]["status"] == "",
        "Clippy source/result differs",
    )
    require(profile["source"] == {"commit": S, "tree": ST}, "Profile source drift")
    require(
        all(
            result[k] is False
            for k in ("production_qualification", "scientific_qualification")
        )
        and result["joint_learning_configuration"] is None,
        "Qualification overclaim",
    )
    states = {
        "C": clean(ROOT / "source", C),
        "E": clean(ROOT / "evidence-source", E),
        "R": clean(ROOT / "followup-source", R),
        "F": clean(ROOT / "followup-evidence-source", F),
        "S_owner": clean(ROOT / "clippy-source", S),
        "S_validation": clean(SOURCE, S),
    }
    require(
        states["S_validation"]["tree"] == ST
        and git(SOURCE, "show", "-s", "--format=%P", S) == R,
        "S ancestry drift",
    )
    archive = pin(FINAL / "source.tar")
    require(
        all(archive[k] == result["archive"][k] for k in ("bytes", "sha256")),
        "Source archive drift",
    )
    integrity = read(FINAL / "archive-integrity.json")
    require(
        integrity["integrity_verified"]
        and integrity["integrity_only"]
        and len(integrity["files"]) == 11387,
        "Archive proof differs",
    )
    clippy_step = next(x for x in clippy["steps"] if x["name"] == "clippy-S-rust195")
    costs = {
        "schema": "hepta.successor-S-costs.v1",
        "source": S,
        "preflight": {
            "wall_seconds": pre["wall_seconds"],
            "cpu_seconds": cpu(pre),
            "scope": pre["cost_scope"],
            "started_at_utc": pre["started_at_utc"],
            "finished_at_utc": pre["finished_at_utc"],
        },
        "common_validation": {
            "wall_seconds": result["total_wall_seconds"],
            "cpu_seconds": cpu(result),
            "scope": result["cost_scope"],
            "started_at_utc": result["started_at_utc"],
            "finished_at_utc": result["finished_at_utc"],
        },
        "separate_clippy": {
            "wall_seconds": clippy["total_wall_seconds"],
            "command_wall_seconds_nested": clippy_step["wall_seconds"],
            "measured_child_cpu_seconds": sum(
                x["child_user_seconds"] + x["child_system_seconds"]
                for x in clippy["steps"]
            ),
            "controller_cpu_seconds": None,
            "scope": clippy["scope"],
            "started_at_utc": clippy["started_at_utc"],
            "finished_at_utc": clippy["finished_at_utc"],
        },
        "measured_active_window_wall_seconds": pre["wall_seconds"]
        + result["total_wall_seconds"]
        + clippy["total_wall_seconds"],
        "nested_steps_not_additive": True,
        "excluded": [
            "R and earlier validation/history",
            "S source edit/freeze and dependency preparation outside the windows",
            "CI log diagnosis",
            "evidence packaging/transfer/publication",
            "unmeasured controller CPU for separate clippy",
        ],
        "cache_state": "Reused released Cargo targets and dependency caches; no cold-build claim.",
        "training_or_scientific_trials": 0,
        "client_startup_record_gap": startup,
        "complete_end_to_end_cost_established": False,
        "unrecovered_001_request_cost": None,
    }
    dump(OUT / "COSTS.json", costs)
    report = f"""# 修复 Clippy 回归后的共同候选 S

在精确 S 上重新实际运行的 **74 项 Python 控制、5 项 AWS Auth 测试和 33 项原生 UI 包测试全部通过，零跳过**。Bazel 锁一致检查与完整 tracked 源码归档核验通过。独立 Rust 1.95 Clippy 原失败命令也实际通过。**cargo-deny 仍只因 RUSTSEC-2026-0451 失败；整体门禁未通过。**

## 源码和证据身份

| 身份 | Commit | Tree |
| --- | --- | --- |
| 原冻结 C | {C} | {states["C"]["tree"]} |
| 原证据 E | {E} | {states["E"]["tree"]} |
| 前一共同源码 R | {R} | {states["R"]["tree"]} |
| 前一证据 F | {F} | {states["F"]["tree"]} |
| 本次实际受测 S | {S} | {ST} |

S 的 parent 是 R。R..S 仅 `room_ime_commit_tests.rs` 一行 `text_input(&mut cx, ...)` 改为 `text_input(&cx, ...)`，1 行新增/1 行删除。原生产接线、测试断言和锁文件不变；源码冻结前后格式检查通过。本证据分支 G 从 S 建立，只新增 observations 文件及原始证据包的精确 SHA256 allowance，运行源码与 S 相同。G 自身 head/tree 与发布回读由独立交付收据记录，不预填未来提交身份。

## R 的托管失败历史与 S 的新验证

R 的 hosted native-presentation jobs 128855152428/128855152530 使用 Rust 1.95.0，实际 source-head 是 R，base-merge `29e4c3e669089e3efa50a1948496e452c6802b59` 的 tree 也为 R tree。原 before/after 执行回执和完整日志定位到上述新增测试行的 `clippy::unnecessary_mut_passed`；`-D warnings` 令该命令退出 101。R 上已通过的测试不计入下面 S 的分母。

另三个 R 相关已结束 job：cargo-deny 128855244522、Bazel GNU 128855244828/musl 128855244840，日志实际 checkout 是 `4bc603a8e38886b72c3ab4a3367cc9cf9968d234`（parents C/R、tree 为 R tree）。deny 仅 0451；两 Bazel lane 各 408 passed/6 failed/164 skipped。五个此前 C 相关失败症状复现，另 `hepta-infer-worker-host` 的终局 reconciliation 测试出现 WriterUnavailable（该包 49 passed/1 failed）；此新增观察的因果尚未证明。不能把这些失败统称旧问题，也不能说本次一行 Clippy 修复已解决它们。历史报告和原件 pins 放在 raw 包的 `prior-R-ci/`；未重跑或改写这些 CI 结果。

S 的本地共同验证与 Rust 1.95 Clippy 分别记录；没有用本地检查代替新的托管 CI 回读。

## S 实际验证窗口

| 门禁 | 实际结果 | Wall 秒 |
| --- | --- | ---: |
"""
    for step in result["steps"]:
        if step["name"] in expected or step["name"] in (
            "bazel-lock-error-check",
            "cargo-deny",
            "complete-archive-integrity",
        ):
            value = (
                f"{step['passed']}/{step['tests']}，0 skipped"
                if "tests" in step
                else ("通过" if step["exit_code"] == 0 else "失败：0451")
            )
            report += f"| {step['name']} | {value} | {step['wall_seconds']:.6f} |\n"
    report += f"| 独立 Rust 1.95 Clippy 原命令 | exit 0 | {clippy_step['wall_seconds']:.6f} |\n"
    report += f"""
`VALIDATION.json` 保存共同窗口的所有 argv/cwd/env、每一步前后源码身份、stdout/stderr 长度及 SHA、退出值与成本。三个测试组均在 S 上从头执行；112 只是这三组工程测试之和，不是科学样本数或项目总覆盖率。Bazel 这里只执行 `mod deps --lockfile_mode=error`，没有执行上述 578 个 hosted targets。

共同窗口 Python 3.12.3，torch 2.9.1+cpu、numpy 1.26.4、Pillow 12.0.0；四个线程变量均为 1，六个模块与原 C profile 的精确字节另行保留。Rust 共同测试使用 1.96.0，通过 `just test` 执行。独立 Clippy 使用 1.95.0，命令为 `cargo clippy --locked --manifest-path apps/hepta-control-ui/rust/Cargo.toml -p hepta-robrix-ui --all-targets --features ui,native-host,native-presentation -- -D warnings`。各环境真实二进制 pins、目标目录与预算见各自 profile/receipt；不能说两窗口环境完全相同。

### 字体与实际 SDK 字节

两个窗口各自记录：安装前源码严格 clean；测试期间只有 manifest 指定的两份 Noto 字体为受控 untracked 文件；按各自 bytes/SHA 核对清理后恢复 clean。manifest SHA `fb9e49a7f14b742ac7e390ceee9be115ad6e04a5f852eec67fb0a126870070a3`；URL、大小、SHA 和保留缓存路径均在 profile。字体不是 tracked source archive 的一部分，不宣称运行期间 status 始终为空。

共同 112 窗口实际解析 Makepad checkout `/home/qian-qi/.cargo/git/checkouts/makepad-69d78fae78fc8901/337566c`，HEAD `337566c8b25d47f7e4fff6a202157b65bf183330`，tree `c6e18be7754f9634492ec5251bac3e8b4f7e09b7`。前后 status 都保留 `?? .cargo-ok`。29 个 CSV/PS1/CMD/BAT 按 SDK attributes 从 Git LF 字节物化为 CRLF，精确 Git/实际 SHA、bytes、变换与 attributes 在 `runtime-inputs/SDK_CHECKOUT_NORMALIZATION.json`。全部 {result["makepad_before"]["rust_source_files_verified_equal_git_blobs"]} 个 Rust 文件均原始 Git blob 相等，其他受控 SDK 文件与冻结物理 pins 相等；UI 前后完整 SDK 输入身份相等。未改 SDK/Git 配置，也未删除 Cargo marker。

独立 Clippy 的依赖核验范围较窄：SDK HEAD/tree/status/tracked diff 加两个物理 SDK 文件、8 个源码/锁/helper 文件，均前后相同。不能把共同 112 窗口的全量 SDK 检查追溯归给 Clippy。原 WASM IME patch 有独立 SHA，但未应用于原生 SDK；浏览器 JS→WASM、Firefox、Playwright 和设备 renderer 未由本报告证明。

## 准备、执行与成本

本次先完成 S 独立 worktree、格式、Python/字体/SDK/原 Clippy 回执和 `cargo metadata --locked --offline` 的非测试 preflight，再冻结新 profile 并运行共同测试。旧 R 的失败尝试与局部成功保留在 R/F 历史，不混入 S 成绩或成本。

**启动记录缺口保留未决。** 已确认的共同 job `1a1bd027b6b-138b0-572` 的 idempotency key 是 `cell-clippy-08b6-S-common-validation-002`，输出目录仍为 `clippy-common-validation-001`。001 这个 key 的原客户端请求/拒绝文本在上下文压缩后未恢复，是否发起、是否在 admission 前拒绝均不能确认；不能写成肯定未调用，也不能记为 0 成本。完整 `h_process_list(host=rog)` retained inventory 中，指定区间仅有 preflight 56c 和共同 572 两个身份，未发现另一个已登记 job；该 API 不暴露 key 字段，也不是未登记请求未发生的证明。完整主机 inventory 原件仅留 native 私有路径与 SHA/bytes，不进入最终 Git/交付包。`STARTUP_RECONCILIATION.json` 与 raw 包 `startup-evidence/retained-jobs-rog-interval.json` 只收入这两行、过滤条件、请求参数、完整性/总数和私有原件 identity。

112 项只归属于已有权威 succeeded/exit 0 的 job 572，独立 Clippy 仍归属于其原 job。以下费用只覆盖已观测执行窗口；完整客户端启动历史和端到端费用尚未建立。本次未因证据缺口重跑测试。

前份未发布证据 G2 commit `{PREVIOUS_G}`（tree `18acea79275b7bc47ed74f46c28a27f9404f0ce2`）保留在 native 分支 `{PREVIOUS_GREF}`，其原 delivery、包 SHA 和操作回执也保留。G2 已明确启动记录缺口，但本地原始包误含完整主机 inventory，因此被仅包含最小区间摘录的本份 G3 替代。G3 直接以 S 为 parent，最终 R..G3 bundle 的可达对象不含 G1/G2 的旧证据包。首份未发布 G1 `a35cbe7a73ffbbb3ec76ed0d9f8c6a9deca4ac81` 则因遗漏启动记录缺口而被替代，其原 identity/pins 也在历史交付收据中。两个旧版本均仅保留本地未发布历史，未重写原件；C/E/R/F/S 与实际测试原件均不变，本版亦不声称已发布。

| 独立窗口 | Wall 秒 | CPU 范围 |
| --- | ---: | --- |
| S 非测试准备 | {pre["wall_seconds"]:.6f} | 进程及后代 {cpu(pre):.6f} 秒 |
| S 共同验证，含失败 deny | {result["total_wall_seconds"]:.6f} | 进程及后代 {cpu(result):.6f} 秒 |
| S Rust 1.95 Clippy 验证 | {clippy["total_wall_seconds"]:.6f} | 已记录子进程 {costs["separate_clippy"]["measured_child_cpu_seconds"]:.6f} 秒；controller CPU 未测 |

三个不重叠活跃窗口 wall 合计 {costs["measured_active_window_wall_seconds"]:.6f} 秒；Clippy 命令 {clippy_step["wall_seconds"]:.6f} 秒包含在其 {clippy["total_wall_seconds"]:.6f} 秒窗口中，各子步骤不能再累加。复用了已释放 Cargo targets 与缓存，不声称冷构建。源码修改/冻结、窗口外依赖准备、CI 诊断、封存、传输和发布成本不在此表，亦无新增训练或确认集实验。

## 完整源码归档与限制

`git archive --format=tar --prefix=source/ {S}` 的完整原件保留在 `{archive["path"]}`，{archive["bytes"]} bytes，SHA256 `{archive["sha256"]}`。原 `hepta_source_archive.py` 对 11,387 tracked 文件的完整集合、原始字节、模式和 symlink 实际核验。完整 inventory 在 raw 包 `clippy-common-validation-001/archive-integrity.json`，SHA `{pin(FINAL / "archive-integrity.json")["sha256"]}`。归档是 S 的 Git 字节；运行字体和 SDK 的物理字节身份另行绑定。162 MB 源码 tar 未重复入 Git 证据包。

archive 核验只有 integrity 意义，不认证测试执行或发布。`joint_learning_configuration` 仍为 null，scientific/production qualification 均 false，overall gate false；vodozemac 0451、其余托管失败与跨平台限制仍需处理。没有运行新的固定图学习采用实验，没有重跑 PRED 确认，原 HOLD 不变。

复现入口是 raw 包保留的原 `prepare_successor_s.py`、`validate_successor_s.py` 和独立 `clippy-S-native-evidence.tar.gz` 内的 worker；固定路径、原始命令及输入 pins 均需按各自记录核对，不得把改路径或环境后的结果称为同一原始执行。`CONNECTOR_JOB_OBSERVATIONS.json` 保存实际 h 权威终态；控制进程 succeeded 不覆盖内部 cargo-deny failure。
"""
    (OUT / "README.zh-CN.md").write_text(report)
    files = []
    for directory, scope in (
        (PRE, "S non-test preflight"),
        (FINAL, "Actual S common validation"),
    ):
        for path in sorted(directory.rglob("*")):
            if path.is_dir() or path == FINAL / "source.tar":
                continue
            require(
                "__pycache__" not in path.parts,
                "Unexpected generated cache in evidence",
            )
            files.append((path, path.relative_to(ROOT).as_posix(), scope))
    norm = ROOT / "followup-validation-001/SDK_CHECKOUT_NORMALIZATION.json"
    require(
        pin(norm)["sha256"]
        == "cada5b43e95561b21a825b45ff23947dcb010f7dfccf22b89aafc4656109a096",
        "SDK materialization pins changed",
    )
    files.append(
        (
            norm,
            "runtime-inputs/SDK_CHECKOUT_NORMALIZATION.json",
            "Frozen physical SDK input pins; not reused test results",
        )
    )
    for name in (
        "CLIPPY_RESULT.json",
        "FROZEN_S.json",
        "clippy-S-native-evidence.tar.gz",
    ):
        files.append(
            (
                CLIPPY / name,
                "separate-clippy/" + name,
                "Exact S Rust 1.95 clippy originals; narrower dependency scope",
            )
        )
    for path in sorted(INPUTS.rglob("*")):
        if path.is_file():
            files.append(
                (
                    path,
                    path.relative_to(INPUTS).as_posix(),
                    "Connector observations, packager or explicitly historical R diagnosis",
                )
            )
    for name in ("README.zh-CN.md", "COSTS.json"):
        files.append((OUT / name, name, "Scope and measured cost boundaries"))
    require(len({name for _, name, _ in files}) == len(files), "Duplicate archive name")
    require(
        all(pin(p)["sha256"] != inventory_pin["sha256"] for p, _, _ in files),
        "Full private inventory must not enter final archive",
    )
    manifest = {
        "schema": "hepta.successor-S-raw-evidence-manifest.v1",
        "source_commit": S,
        "source_tree": ST,
        "files": [{**pin(p, name), "scope": scope} for p, name, scope in files],
        "excluded_source_archive": archive,
        "excluded_private_host_inventory": startup["complete_retained_inventory"],
        "manifest_scope": "All payload members; manifest itself bound by outer SHA.",
        "production_qualification": False,
        "scientific_qualification": False,
    }
    dump(OUT / "RAW_EVIDENCE_MANIFEST.json", manifest)
    payload = OUT / "raw-evidence.tar.gz"
    with (
        payload.open("xb") as raw,
        gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0) as gz,
        tarfile.open(fileobj=gz, mode="w", format=tarfile.PAX_FORMAT) as tar,
    ):
        for path, name, _ in [
            *files,
            (OUT / "RAW_EVIDENCE_MANIFEST.json", "MANIFEST.json", ""),
        ]:
            item = tarfile.TarInfo(name)
            item.size, item.mtime, item.uid, item.gid, item.mode = (
                path.stat().st_size,
                0,
                0,
                0,
                0o644,
            )
            with path.open("rb") as stream:
                tar.addfile(item, stream)
    raw_pin = pin(payload)
    require(512000 < raw_pin["bytes"] < 8 * 1024 * 1024, "Unexpected package size")
    with tarfile.open(payload, "r:gz") as tar:
        members = tar.getmembers()
        require(
            len(members) == len(files) + 1
            and len({x.name for x in members}) == len(members),
            "Archive member mismatch",
        )
        for row in manifest["files"]:
            member = tar.getmember(row["path"])
            require(
                member.isfile()
                and member.size == row["bytes"]
                and sha(tar.extractfile(member).read()) == row["sha256"],
                "Archive payload drift",
            )
    require(
        git(SOURCE, "rev-parse", "refs/heads/" + GREF) == PREVIOUS_G,
        "Initial evidence ref changed",
    )
    subprocess.run(
        [
            "git",
            "-C",
            str(ROOT / "clippy-evidence-source-002"),
            "branch",
            "-m",
            GREF,
            PREVIOUS_GREF,
        ],
        check=True,
    )
    subprocess.run(
        ["git", "-C", str(SOURCE), "worktree", "add", "-b", GREF, str(DEST), S],
        check=True,
    )
    observations = DEST / OBS
    observations.mkdir(parents=True, exist_ok=False)
    copies = [
        (payload, "raw-evidence.tar.gz"),
        (OUT / "README.zh-CN.md", "README.zh-CN.md"),
        (OUT / "RAW_EVIDENCE_MANIFEST.json", "RAW_EVIDENCE_MANIFEST.json"),
        (OUT / "COSTS.json", "COSTS.json"),
        (FINAL / "VALIDATION.json", "VALIDATION.json"),
        (FINAL / "VALIDATION_PROFILE.json", "VALIDATION_PROFILE.json"),
        (FINAL / "archive-binding.json", "SOURCE_ARCHIVE_BINDING.json"),
        (PRE / "PREFLIGHT.json", "PREFLIGHT.json"),
        (CLIPPY / "CLIPPY_RESULT.json", "CLIPPY_RESULT.json"),
        (CLIPPY / "FROZEN_S.json", "FROZEN_S.json"),
        (INPUTS / "CONNECTOR_JOB_OBSERVATIONS.json", "CONNECTOR_JOB_OBSERVATIONS.json"),
        (INPUTS / "STARTUP_RECONCILIATION.json", "STARTUP_RECONCILIATION.json"),
        (INPUTS / "PREVIOUS_G_DELIVERY.json", "PREVIOUS_G_DELIVERY.json"),
    ]
    for path, name in copies:
        shutil.copyfile(path, observations / name)
    before_allow = git_bytes(SOURCE, "show", S + ":" + ALLOW)
    append = (
        "\n# Exact frozen S common and separate Clippy observation archive.\n"
        + f"sha256:{raw_pin['sha256']} {(OBS / 'raw-evidence.tar.gz').as_posix()}\n"
    ).encode()
    require(
        (DEST / ALLOW).read_bytes() == before_allow, "Allowlist starting bytes differ"
    )
    (DEST / ALLOW).write_bytes(before_allow + append)
    env = os.environ.copy()
    env.update(RUSTUP_TOOLCHAIN="1.96.0", PYTHONDONTWRITEBYTECODE="1")
    env["PATH"] = (
        "/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:" + env["PATH"]
    )
    operations = []

    def run(label, args, cwd=DEST):
        start = time.monotonic()
        with (
            (OUT / (label + ".stdout")).open("xb") as stdout,
            (OUT / (label + ".stderr")).open("xb") as stderr,
        ):
            proc = subprocess.run(
                args,
                cwd=cwd,
                env=env,
                stdout=stdout,
                stderr=stderr,
                timeout=120,
                check=False,
            )
        operations.append(
            {
                "name": label,
                "argv": args,
                "cwd": str(cwd),
                "exit_code": proc.returncode,
                "wall_seconds": time.monotonic() - start,
                "stdout": pin(OUT / (label + ".stdout")),
                "stderr": pin(OUT / (label + ".stderr")),
            }
        )
        require(proc.returncode == 0, "Evidence operation failed: " + label)

    run("evidence-just-fmt", ["just", "fmt"], DEST / "codex-rs")
    run("evidence-diff-check", ["git", "diff", "--check"])
    subprocess.run(["git", "-C", str(DEST), "add", "--", str(OBS), ALLOW], check=True)
    staged = git(DEST, "write-tree")
    run(
        "blob-policy-tests",
        [
            str(PYTHON),
            "-B",
            "-m",
            "unittest",
            "discover",
            "-s",
            "scripts/tests",
            "-p",
            "test_blob_size_policy.py",
        ],
    )

    def policy(label, base, head):
        run(
            label,
            [
                str(PYTHON),
                "-B",
                "scripts/check_blob_size.py",
                "--base",
                base,
                "--head",
                head,
                "--max-bytes",
                "512000",
                "--allowlist",
                ALLOW,
            ],
        )

    policy("staged-blob-policy", S, staged)
    run(
        "commit-G",
        [
            "git",
            "commit",
            "-m",
            "docs: preserve common S validation and exact Rust 1.95 Clippy evidence",
        ],
    )
    g = git(DEST, "rev-parse", "HEAD")
    gt = git(DEST, "rev-parse", "HEAD^{tree}")
    require(
        gt == staged and git(DEST, "show", "-s", "--format=%P", g) == S,
        "Evidence parent/tree changed",
    )
    diff = git(DEST, "diff", "--no-renames", "--name-status", S, g).splitlines()
    changed = []
    for line in diff:
        status, path = line.split("\t")
        require(
            (path == ALLOW and status == "M")
            or (path.startswith(str(OBS) + "/") and status == "A"),
            "Evidence scope exceeds additions",
        )
        require(
            git(DEST, "ls-tree", g, "--", path).split()[0] == "100644",
            "Evidence mode differs",
        )
        changed.append(path)
    after_allow = git_bytes(DEST, "show", g + ":" + ALLOW)
    require(
        after_allow.startswith(before_allow)
        and after_allow[len(before_allow) :] == append,
        "Not exact append-only allowance",
    )
    artifacts = []
    for line in append.decode().splitlines():
        if not line or line.startswith("#"):
            continue
        hash_token, path = line.split(" ", 1)
        data = git_bytes(DEST, "show", g + ":" + path)
        require(
            hash_token == "sha256:" + sha(data), "Allowance does not bind Git object"
        )
        artifacts.append({"path": path, "bytes": len(data), "sha256": sha(data)})
    require(len(artifacts) == 1, "Unexpected allowance count")
    policy("final-blob-policy", R, g)
    require(
        git(SOURCE, "rev-parse", "refs/heads/" + SREF) == S, "Source branch changed"
    )
    clean(DEST, g)
    bundle = OUT / "R-to-G.bundle"
    run(
        "create-bundle",
        [
            "git",
            "bundle",
            "create",
            str(bundle),
            "refs/heads/" + SREF,
            "refs/heads/" + GREF,
            "^" + R,
        ],
    )
    run("verify-bundle", ["git", "bundle", "verify", str(bundle)])
    heads = git(DEST, "bundle", "list-heads", str(bundle)).splitlines()
    require(
        set(heads) == {S + " refs/heads/" + SREF, g + " refs/heads/" + GREF},
        "Bundle heads differ",
    )
    reachable = {
        x.split()[0]
        for x in git(DEST, "rev-list", "--objects", g, "^" + R).splitlines()
    }
    excluded_objects = [PREVIOUS_G, "a35cbe7a73ffbbb3ec76ed0d9f8c6a9deca4ac81"]
    for path in (
        Path(inventory_pin["path"]),
        ROOT / "clippy-delivery-001/raw-evidence.tar.gz",
        ROOT / "clippy-delivery-002/raw-evidence.tar.gz",
    ):
        excluded_objects.append(git(DEST, "hash-object", "--no-filters", str(path)))
    require(
        not reachable.intersection(excluded_objects),
        "Private prior evidence reachable from final bundle",
    )
    dump(OUT / "EVIDENCE_OPERATIONS.json", operations)
    (OUT / "S-to-G.diff").write_bytes(
        git_bytes(DEST, "diff", "--no-renames", "--stat", S, g)
    )
    delivery = {
        "schema": "hepta.successor-S-G-delivery.v1",
        "source": S,
        "source_tree": ST,
        "source_parent": R,
        "source_branch": SREF,
        "evidence": g,
        "evidence_tree": gt,
        "evidence_branch": GREF,
        "evidence_parent": S,
        "native_test_counts": {"python": 74, "aws": 5, "ui": 33},
        "skipped": 0,
        "cargo_deny_remaining": ["RUSTSEC-2026-0451"],
        "overall_gate_pass": False,
        "native_validation": pin(FINAL / "VALIDATION.json"),
        "profile": pin(FINAL / "VALIDATION_PROFILE.json"),
        "preflight": pin(PRE / "PREFLIGHT.json"),
        "clippy_receipt": pin(CLIPPY / "CLIPPY_RESULT.json"),
        "clippy_raw": pin(CLIPPY / "clippy-S-native-evidence.tar.gz"),
        "costs": pin(OUT / "COSTS.json"),
        "source_changed_paths": git(
            SOURCE, "diff", "--no-renames", "--name-only", R, S
        ).splitlines(),
        "evidence_changed_paths": changed,
        "evidence_name_status": diff,
        "runtime_code_unchanged_from_S": True,
        "allowlist_append_sha256": sha(append),
        "allowlist_append_bytes": len(append),
        "allowlisted_artifacts": artifacts,
        "bundle": pin(bundle),
        "bundle_prerequisite": R,
        "bundle_heads": heads,
        "private_prior_evidence_objects_excluded_from_bundle": excluded_objects,
        "raw_evidence": raw_pin,
        "raw_evidence_members": len(files) + 1,
        "raw_manifest": pin(OUT / "RAW_EVIDENCE_MANIFEST.json"),
        "source_archive": archive,
        "source_archive_integrity": pin(FINAL / "archive-integrity.json"),
        "evidence_operations": pin(OUT / "EVIDENCE_OPERATIONS.json"),
        "connector_observations": pin(INPUTS / "CONNECTOR_JOB_OBSERVATIONS.json"),
        "startup_reconciliation": pin(INPUTS / "STARTUP_RECONCILIATION.json"),
        "complete_end_to_end_cost_established": False,
        "unrecovered_001_request_cost": None,
        "replaces_unpublished_evidence": {
            "commit": PREVIOUS_G,
            "tree": initial["evidence_tree"],
            "retained_branch": PREVIOUS_GREF,
            "delivery": pin(INPUTS / "PREVIOUS_G_DELIVERY.json"),
            "original_native_delivery_path": str(
                ROOT / "clippy-delivery-002/FINAL_DELIVERY.json"
            ),
            "raw_evidence": initial["raw_evidence"],
            "bundle": initial["bundle"],
            "reason": "Remove complete host inventory from final distribution; retain only scoped two-job extract and private-original pins. Source/tests unchanged.",
        },
        "final_source_states": {
            **states,
            "S_validation": clean(SOURCE, S),
            "G": clean(DEST, g),
            "initial_unpublished_G": clean(
                ROOT / "clippy-evidence-source-002", PREVIOUS_G
            ),
        },
        "production_qualification": False,
        "scientific_qualification": False,
        "joint_learning_configuration": None,
        "hosted_S_CI_rerun": False,
        "published": False,
        "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    dump(OUT / "FINAL_DELIVERY.json", delivery)
    print(json.dumps(delivery), flush=True)


if __name__ == "__main__":
    main()
