set -eu
umask 077
test "$(uname -m)" = x86_64
test -x /usr/bin/ssh-keygen
readlink -f /usr/bin/ssh-keygen
sha256sum /usr/bin/ssh-keygen
dpkg-query -W openssh-client libc6
ssh -V
ldd /usr/bin/ssh-keygen > /tmp/keygen-ldd.txt
cat /tmp/keygen-ldd.txt
if grep -F 'not found' /tmp/keygen-ldd.txt; then exit 1; fi
mkdir /tmp/state
cd /tmp/state
/usr/bin/ssh-keygen -q -t ed25519 -N '' -f key
printf 'qualification ' > allowed_signers
cat key.pub >> allowed_signers
printf 'hepta-rbe-image-qualification-v1\n' > message
/usr/bin/ssh-keygen -Y sign -f key -n hepta-rbe-image message
/usr/bin/ssh-keygen -Y verify -f allowed_signers -I qualification -n hepta-rbe-image -s message.sig < message
printf 'changed-message\n' > tampered
set +e
/usr/bin/ssh-keygen -Y verify -f allowed_signers -I qualification -n hepta-rbe-image -s message.sig < tampered
rejected=$?
set -e
test "$rejected" -ne 0
printf 'TAMPER_REFUSAL_EXIT=%s\nRBE_OPENSSH_PROBE_PASS\n' "$rejected"
