"""Collect actual original full-length calibration without rerunning any model."""
import base64
import collections
import hashlib
import json
import pathlib
import shutil
import tarfile
import time
ROOT = pathlib.Path("/home/qian-qi/work/hepta-upstream-layout-learning-20261118-2e9b-checkpoint2")
OUT = ROOT / "fullgate-publication-1"
RAW = OUT / "raw"
RAW.mkdir(exist_ok=False)
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("xb") as stream:
        stream.write((json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode())
def copy(p, rel):
    target = RAW / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    assert p.is_file() and not p.is_symlink()
    with target.open("xb") as stream:
        stream.write(p.read_bytes())
    assert sha(target) == sha(p)
for folder in ("retained/calibration", "owned-calibration_only-1"):
    for path in sorted((ROOT / folder).rglob("*")):
        if path.is_file():
            copy(path, path.relative_to(ROOT))
for name in ("DEPLOYMENT.json", "TRAINING_ADMISSION.json", "retained/calibration-RETENTION.json"):
    copy(ROOT / name, pathlib.Path(name))
for name in ("INTENT.json", "EXIT.json", "STDOUT.txt", "STDERR.txt", "collect_originals.py"):
    copy(OUT / name, pathlib.Path("admission-freeze") / name)
job = pathlib.Path("/home/qian-qi/.local/state/hepta-runtime-mac-worker/jobs/1a1f05cbf17-ffbe-78b")
for name in ("request.json", "started.json", "child.json", "launch.json", "owner-intent.json", "exit.json", "exit.witness.json"):
    copy(job / name, pathlib.Path("original-job") / name)
result = json.loads((ROOT / "retained/calibration/RESULT.json").read_bytes())
owner = json.loads((ROOT / "owned-calibration_only-1/COMPLETE.json").read_bytes())
actual_exit = json.loads((job / "exit.json").read_bytes())
witness = json.loads((job / "exit.witness.json").read_bytes())
assert actual_exit["exit_code"] == 0 and not actual_exit["timed_out"] and actual_exit["output_durable"]
assert witness["exit_sha256"] == sha(job / "exit.json")
assert result["status"] == "PASS" and result["optimizer_updates"] == 0 and result["model_generation_calls"] == 0
assert sha(ROOT / "TRAINING_ADMISSION.json") == "6e17e6b1fcc13cfad448448c871c9c15f09bb970334bfc060d47e24cd746a04d"
events = [json.loads(line) for line in (ROOT / "retained/calibration/COMPUTE.jsonl").read_bytes().splitlines()]
readout = {
    "schema": "hepta.upstream-layout-full-calibration-readout.v1",
    "created_at_ns": time.time_ns(),
    "execution_source_commit": "02b3fb49ac00ccb7ad28e5d803af5675fbd28e26",
    "protocol_sha256": "c71f8348977e955b1d5b6b98e8780ff13188b88b141fad683efb6f08bb03814f",
    "status": "ACTUAL_FULL_LENGTH_GATE_PASSED",
    "original_job_id": job.name,
    "original_idempotency_key": "e123-checkpoint2-full-gate-02b3fb-2e9b-001",
    "recovery": "same original job recovered read-only through supported persistent PTY; no resubmission",
    "original_request_sha256": sha(job / "request.json"),
    "original_exit_sha256": sha(job / "exit.json"),
    "original_exit_witness_sha256": sha(job / "exit.witness.json"),
    "result_sha256": sha(ROOT / "retained/calibration/RESULT.json"),
    "training_admission_sha256": sha(ROOT / "TRAINING_ADMISSION.json"),
    "training_engine_receipt_sha256": sha(ROOT / "retained/calibration/TRAINING_ENGINE.json"),
    "full_gate_result": result,
    "compute_trace_records": len(events),
    "compute_event_counts": dict(collections.Counter(str(e.get("event", "UNDECLARED")) for e in events)),
    "owner_actual": owner,
    "short_A_exact_logit_and_all_LoRA_gradient_result_sha256": "22e9642729084223acf0058606ef01132c7e8b5f707eafb8e37c3002eb87586a",
    "full_gate_is_memory_execution_gate_not_independent_learning_gain": True,
    "training_updates_completed_at_this_freeze": 0,
    "generation_calls": 0,
    "B3_materials_read": False,
    "old_NoUpdate_decisions_unchanged": True,
    "prior_failures_and_SDPA_numerical_reject_retained": True,
    "same_physical_compute_as_prior_eager": False,
    "full_cost_known": False,
    "gpu_energy_joules": None,
    "network_energy_joules": None,
    "monetary_cost": None,
}
write(OUT / "READOUT.json", readout)
entries = [{"archive_path": str(p.relative_to(RAW)), "bytes": p.stat().st_size, "sha256": sha(p)} for p in sorted(RAW.rglob("*")) if p.is_file()]
write(OUT / "INDEX.json", {"schema":"hepta.raw-evidence-index.v1","entries":entries,"files":len(entries),"uncompressed_bytes":sum(x["bytes"] for x in entries)})
archive = OUT / "RAW_EVIDENCE.tar.xz"
with tarfile.open(archive, "x:xz", preset=6) as tar:
    for p in sorted(RAW.rglob("*")):
        if p.is_file():
            tar.add(p, arcname=str(p.relative_to(RAW)), recursive=False)
archive_meta = {"path":str(archive),"bytes":archive.stat().st_size,"sha256":sha(archive),"index_sha256":sha(OUT/"INDEX.json"),"readout_sha256":sha(OUT/"READOUT.json"),"all_originals_preserved":True,"model_calls_added":0}
write(OUT / "ARCHIVE.json", archive_meta)
for p in (OUT/"READOUT.json", OUT/"INDEX.json", OUT/"ARCHIVE.json", ROOT/"TRAINING_ADMISSION.json"):
    print(json.dumps({"path":str(p),"sha256":sha(p),"text":p.read_text()}),flush=True)
print(json.dumps({"archive_base64":base64.b64encode(archive.read_bytes()).decode(),"sha256":sha(archive),"bytes":archive.stat().st_size}),flush=True)
