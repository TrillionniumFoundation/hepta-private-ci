"""Retain completed actual training and both adapters without model execution."""

import hashlib
import importlib
import json
import os
from pathlib import Path
import tarfile
import time
import sys

ROOT = Path(
    "/home/qian-qi/work/hepta-upstream-layout-learning-20261118-2e9b-checkpoint2"
)
SOURCE = ROOT / "source/qualification/cell-upstream-layout-learning-20261118"
sys.path.insert(0, str(SOURCE))
ctx = importlib.import_module("layout_context")
OUT = ROOT / "training-publication-1"
RAW = OUT / "raw"
EXPECTED_PROTOCOL = "c71f8348977e955b1d5b6b98e8780ff13188b88b141fad683efb6f08bb03814f"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def write(path, value):
    with Path(path).open("xb") as stream:
        stream.write(ctx.data.canonical(value) + b"\n")


def copy(path, relative):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise ValueError("only immutable ordinary originals may be retained")
    target = RAW / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        stream.write(path.read_bytes())
    if sha(target) != sha(path):
        raise ValueError("retained original bytes differ")
    return target


def main():
    os.nice(19)
    owner = read(ROOT / "owned-training-1/COMPLETE.json")
    frozen_path = ROOT / "retained/WEIGHTS_FROZEN.json"
    frozen = read(frozen_path)
    if (
        owner["status"] != "COMPLETE"
        or frozen["status"] != "MATCHED_AND_WEIGHTS_FROZEN"
    ):
        raise ValueError("complete actual training and frozen audit required")
    if any(
        row["wait_returncode"] != 0 or row["timed_out"] for row in owner["stage_exits"]
    ):
        raise ValueError("all actual training stages must exit successfully")
    if sha(SOURCE / "prepared/PROTOCOL.json") != EXPECTED_PROTOCOL:
        raise ValueError("fixed training protocol differs")
    protocol = read(SOURCE / "prepared/PROTOCOL.json")
    OUT.mkdir(exist_ok=False)
    RAW.mkdir()
    for name, expected in protocol["candidate_files"].items():
        if sha(SOURCE / name) != expected:
            raise ValueError("frozen training source differs: " + name)
        copy(SOURCE / name, Path("source") / name)
    copy(SOURCE / "prepared/PROTOCOL.json", Path("source/prepared/PROTOCOL.json"))
    summaries = {}
    for mode in ("document_evidence", "native_feedback"):
        folder = ROOT / "retained" / mode
        retention = read(ROOT / "retained" / (mode + "-RETENTION.json"))
        for name, expected in retention.items():
            path = folder / name
            if (
                sha(path) != expected["sha256"]
                or path.stat().st_size != expected["bytes"]
            ):
                raise ValueError("owner retention index differs")
            copy(path, Path("retained") / mode / name)
        copy(
            ROOT / "retained" / (mode + "-RETENTION.json"),
            Path("retained") / (mode + "-RETENTION.json"),
        )
        manifest = read(folder / "manifest.json")
        fit = read(folder / "TRAINING.json")
        if sha(folder / "manifest.json") != frozen["arms"][mode]["manifest_sha256"]:
            raise ValueError("frozen actual manifest differs")
        if sha(folder / "TRAINING.json") != frozen["arms"][mode]["training_sha256"]:
            raise ValueError("frozen actual training result differs")
        if ctx.data.digest(manifest) != frozen["arms"][mode]["model_digest"]:
            raise ValueError("actual model identity differs")
        if fit["steps"] != 32 or fit["status"] != "COMPLETE":
            raise ValueError("32 completed updates required")
        summaries[mode] = {
            "manifest_path": str(folder / "manifest.json"),
            "manifest_sha256": sha(folder / "manifest.json"),
            "model_digest": fit["model_digest"],
            "parameter_before": fit["parameter_before"],
            "parameter_after": fit["parameter_after"],
            "training_sha256": sha(folder / "TRAINING.json"),
            "adapter_files": manifest["adapter_files"],
            "cost": fit["cost"],
        }
    if sha(ctx.FIT_ROOT / "WEIGHTS_FROZEN.json") != sha(frozen_path):
        raise ValueError("retained and original frozen weights receipt differ")
    copy(frozen_path, Path("retained/WEIGHTS_FROZEN.json"))
    for path in sorted((ROOT / "owned-training-1").rglob("*")):
        if path.is_file():
            copy(path, path.relative_to(ROOT))
    for name in (
        "DEPLOYMENT.json",
        "TRAINING_DEPLOYMENT.json",
        "TRAINING_ADMISSION.json",
    ):
        copy(ROOT / name, Path(name))
    copy(Path(__file__), Path("collection-source/collect_training.py"))
    terminal = Path(
        "/home/qian-qi/.local/state/hepta-runtime-mac-worker/terminals/dpty-83e22ffc6ebedf522aa8cc44df8db0a6e4001caec6e52903f00b7c5dd9793d62/output.log"
    )
    if terminal.is_file():
        copy(terminal, Path("training-pty/output.log"))
    entries = [
        {
            "path": str(path.relative_to(RAW)),
            "bytes": path.stat().st_size,
            "sha256": sha(path),
        }
        for path in sorted(RAW.rglob("*"))
        if path.is_file()
    ]
    write(
        OUT / "INDEX.json",
        {
            "schema": "hepta.actual-training-raw-index.v1",
            "files": len(entries),
            "entries": entries,
            "uncompressed_bytes": sum(row["bytes"] for row in entries),
        },
    )
    archive = OUT / "ACTUAL_TRAINING.tar.xz"
    with tarfile.open(archive, "x:xz", preset=6) as tar:
        for row in entries:
            tar.add(RAW / row["path"], arcname=row["path"], recursive=False)
    with tarfile.open(archive, "r:xz") as tar:
        members = {member.name: member for member in tar.getmembers()}
        if set(members) != {row["path"] for row in entries}:
            raise ValueError("archive membership differs")
        for row in entries:
            value = tar.extractfile(members[row["path"]]).read()
            if (
                len(value) != row["bytes"]
                or hashlib.sha256(value).hexdigest() != row["sha256"]
            ):
                raise ValueError("archive member differs")
    archive_bytes = archive.read_bytes()
    metadata = {
        "path": str(archive),
        "bytes": len(archive_bytes),
        "sha256": sha(archive),
        "git_blob_sha1": hashlib.sha1(
            b"blob " + str(len(archive_bytes)).encode() + b"\0" + archive_bytes
        ).hexdigest(),
        "index_sha256": sha(OUT / "INDEX.json"),
        "all_archive_members_verified": True,
        "base_weights_referenced_by_original_manifest_not_duplicated": True,
        "new_model_or_verifier_calls": 0,
    }
    write(OUT / "ARCHIVE.json", metadata)
    readout = {
        "schema": "hepta.upstream-layout-actual-training-readout.v1",
        "collected_at_ns": time.time_ns(),
        "source_commit": "78099aa6af4c70c00f26cb11888e20aa59510014",
        "executable_files_identical_to": "02b3fb49ac00ccb7ad28e5d803af5675fbd28e26",
        "protocol_sha256": EXPECTED_PROTOCOL,
        "weights_frozen_path": str(frozen_path),
        "weights_frozen_sha256": sha(frozen_path),
        "weights_frozen_at_ns": str(frozen["created_at_ns"]),
        "primary": frozen["designated_candidate"],
        "control": frozen["control"],
        "actual_completed_updates": 64,
        "actual_generation_calls": 0,
        "arms": summaries,
        "owner": owner,
        "old_NoUpdate_decisions_unchanged": True,
        "B3_material_read_before_weights_frozen": False,
        "training_loss_not_independent_task_gain": True,
        "native_adoption": False,
        "full_system_cost_known": False,
        "gpu_energy_joules": None,
        "network_energy_joules": None,
        "monetary_cost": None,
        "nested_windows_are_not_additive": True,
    }
    write(OUT / "READOUT.json", readout)
    selected = [
        frozen_path,
        ROOT / "retained/document_evidence/manifest.json",
        ROOT / "retained/native_feedback/manifest.json",
        ROOT / "retained/document_evidence/TRAINING.json",
        ROOT / "retained/native_feedback/TRAINING.json",
        OUT / "READOUT.json",
        OUT / "INDEX.json",
        OUT / "ARCHIVE.json",
    ]
    for path in selected:
        print(
            json.dumps(
                {
                    "path": str(path),
                    "sha256": sha(path),
                    "bytes": path.stat().st_size,
                    "text": path.read_text(),
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
