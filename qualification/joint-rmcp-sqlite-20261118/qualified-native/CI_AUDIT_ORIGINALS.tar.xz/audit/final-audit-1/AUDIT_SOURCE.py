import pathlib,os,json,re,hashlib,zipfile,subprocess,time,base64
root=pathlib.Path("/home/qian-qi/work/hepta-e1e6-dependency-joint-20261118-2e9b")
ci=root/"ci-qualification-7fc46c193-1"
out=ci/"final-audit-1";out.mkdir(exist_ok=False)
repo="TrillionniumFoundation/hepta-private-ci"
expected={
"rmcp":{"zip_sha256":"f8afadfbaf42a5305c7b5e22e5550f7f15ec728871ae42699f38840a21e08d29","run":44359468610,"job":134996522149,"artifact":14456513074,"passed":278,"ignored":7,"executed_targets":24,"skipped_targets":18,"sections":34,"prefix":"hepta-rmcp-upgrade"},
"sqlite":{"zip_sha256":"a2af9f6c35daf91c047071845964a855ac763305f8a29b7f5faff4078fc53ecf","run":44359468771,"job":134996523370,"artifact":14454168128,"passed":284,"ignored":2,"executed_targets":9,"skipped_targets":5,"sections":12,"prefix":"hepta-sqlite-upgrade"}}
report={"schema":"hepta.actual-joint-ci-case-lock-audit.v1","execution_source":"7fc46c193a9ff8726e43fca2982d9b8f455e3dac","runtime_source_parent":"2b3642214ba5ff4aaac27de13322a354a69507e7","no_tests_reexecuted":True,"scopes":{},"full_repository_qualification":False,"energy_joules":None,"monetary_cost":None}
for label,e in expected.items():
    archive=ci/label/"original.zip";data=archive.read_bytes()
    assert hashlib.sha256(data).hexdigest()==e["zip_sha256"]
    with zipfile.ZipFile(archive) as z:
        members=[]
        for n in z.namelist():
            pp=pathlib.PurePosixPath(n)
            assert not pp.is_absolute() and ".." not in pp.parts
            if n.endswith("/"):continue
            b=z.read(n);existing=ci/label/"originals"/n
            assert existing.read_bytes()==b
            members.append({"path":n,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()})
        text=z.read(e["prefix"]+"/tests.log").decode()
        locks={}
        for name,digest in [("Cargo.lock","dab5a95131e1b9c9b75144f6309d3a5686c2b82a5aee6a830d31bbeebfc8faf7"),("MODULE.bazel.lock","d240b972292c4101a01eceb1281dd15cdc43c77979711281bcaa5d0c680580c1")]:
            matches=[n for n in z.namelist() if n.endswith("/"+name)]
            assert len(matches)==1
            actual=hashlib.sha256(z.read(matches[0])).hexdigest();assert actual==digest
            locks[name]=actual
        source_files=[n for n in z.namelist() if n.endswith("/source-head.txt")]
        assert len(source_files)==1 and z.read(source_files[0]).decode().strip()==report["execution_source"]
        patches=[n for n in z.namelist() if n.endswith("/both-locks.patch")]
        assert len(patches)==1 and z.read(patches[0])==b""
    group=None;cases=[];summaries=[];sections=[];targets=[]
    for lineno,raw in enumerate(text.splitlines(),1):
        line=re.sub(r"\x1b\[[0-9;]*m","",raw)
        m=re.match(r"^INFO: From Testing (.*):$",line)
        if m:group=m.group(1);sections.append({"line":lineno,"section":group})
        m=re.match(r"^test (\S+) \.\.\. (ok|ignored(?:,.*)?|FAILED)$",line)
        if m:
            assert group
            cases.append({"line":lineno,"target_section":group,"target":re.sub(r" \(shard \d+ of \d+\)$","",group),"name":m.group(1),"status":m.group(2)})
        m=re.match(r"^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;",line)
        if m:summaries.append({"line":lineno,"target_section":group,**dict(zip(("passed","failed","ignored","measured","filtered"),map(int,m.groups())))})
        m=re.match(r"^(//\S+)\s+(PASSED|SKIPPED)(?: in ([0-9.]+)s)?$",line)
        if m:targets.append({"name":m.group(1),"status":m.group(2),"wall_seconds":float(m.group(3)) if m.group(3) else None})
    passed=[c for c in cases if c["status"]=="ok"];ignored=[c for c in cases if c["status"].startswith("ignored")]
    assert len(passed)==sum(s["passed"] for s in summaries)==e["passed"]
    assert len(ignored)==sum(s["ignored"] for s in summaries)==e["ignored"]
    assert len(summaries)==e["sections"] and not any(s["failed"] for s in summaries)
    assert not any(c["status"]=="FAILED" for c in cases)
    assert len({t["name"] for t in targets})==len(targets)
    assert sum(t["status"]=="PASSED" for t in targets)==e["executed_targets"]
    assert sum(t["status"]=="SKIPPED" for t in targets)==e["skipped_targets"]
    grouped={}
    for c in cases:grouped.setdefault((c["target"],c["name"]),[]).append(c)
    duplicates=[{"target":k[0],"name":k[1],"observations":v} for k,v in grouped.items() if len(v)>1]
    case_raw=(json.dumps({"cases":cases,"result_sections":summaries,"target_results":targets,"repeated_case_identities":duplicates},indent=2)+"\n").encode()
    (out/(label+"-cases.json")).write_bytes(case_raw)
    row={**e,"archive_bytes":len(data),"members":members,"locks":locks,"both_locks_patch_bytes":0,"actual_case_pass_executions":len(passed),"distinct_passing_target_case_identities":len({(c["target"],c["name"]) for c in passed}),"ignored_registrations":ignored,"test_summary_sections":len(summaries),"target_log_sections":len(sections),"repeated_case_identities":duplicates,"case_index_sha256":hashlib.sha256(case_raw).hexdigest(),"native_windows_qualification":False,"junit_artifacts_present":False,"count_scope":"Pass counts include real spawned subprocess probes; distinct identities are also retained. Windows cross-target SKIPPED rows are not native executions."}
    report["scopes"][label]=row
    payload=out/(label+"-blob-request.json")
    payload.write_text(json.dumps({"content":base64.b64encode(data).decode(),"encoding":"base64"}))
    t=time.monotonic()
    p=subprocess.run(["gh","api","--method","POST","repos/"+repo+"/git/blobs","--input",str(payload)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (out/(label+"-blob-response.json")).write_bytes(p.stdout)
    (out/(label+"-blob.stderr")).write_bytes(p.stderr)
    assert p.returncode==0
    uploaded=json.loads(p.stdout)
    gitsha=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
    assert uploaded["sha"]==gitsha
    row["published_git_blob"]=gitsha;row["blob_upload_wall_seconds"]=time.monotonic()-t
    payload.unlink()
    print(json.dumps({"scope":label,"passed_executions":len(passed),"distinct_pass_names":row["distinct_passing_target_case_identities"],"blob":gitsha,"archive_sha256":e["zip_sha256"]}),flush=True)
(out/"READOUT.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({"status":"AUDITED_AND_ORIGINAL_ZIPS_UPLOADED","readout_sha256":hashlib.sha256((out/"READOUT.json").read_bytes()).hexdigest()}),flush=True)
