import pathlib, subprocess, os, json, time, hashlib, resource
root=pathlib.Path("/Users/qianqi/work/hepta-root-mac-fixtures-shallow-20261118-2e9b")
source=root/"source"
out=root/"locked-fetch-1";out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(PATH="/opt/homebrew/bin:/opt/homebrew/opt/rustup/bin:/Users/qianqi/.cargo/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin",RUSTUP_TOOLCHAIN="1.96.0",CARGO_TARGET_DIR=str(root/"native-target-9aaa"),CARGO_BUILD_JOBS="2",GIT_TERMINAL_PROMPT="0")
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=source,env=env,text=True).strip();assert head=="9aaac03f5f6bcad3ff14ffe2ecfb11aa4299f16f"
lock=source/"codex-rs/Cargo.lock";before=hashlib.sha256(lock.read_bytes()).hexdigest();start=time.monotonic();cpu=resource.getrusage(resource.RUSAGE_CHILDREN)
command=["cargo","fetch","--locked","--target","aarch64-apple-darwin"]
with (out/"stdout.log").open("wb") as so,(out/"stderr.log").open("wb") as se:p=subprocess.run(command,cwd=source/"codex-rs",env=env,stdout=so,stderr=se)
after=resource.getrusage(resource.RUSAGE_CHILDREN);status=subprocess.check_output(["git","status","--porcelain","--untracked-files=all"],cwd=source,env=env,text=True)
result={"schema":"hepta.mac-locked-dependency-acquisition.v1","source":head,"command":command,"exit_code":p.returncode,"wall_seconds":time.monotonic()-start,"child_cpu_seconds":after.ru_utime+after.ru_stime-cpu.ru_utime-cpu.ru_stime,"lock_before_sha256":before,"lock_after_sha256":hashlib.sha256(lock.read_bytes()).hexdigest(),"source_status":status,"source_unchanged":not status.strip() and before==hashlib.sha256(lock.read_bytes()).hexdigest(),"tests_executed":0,"purpose":"Resolve the actual offline sqlx-sqlite cache miss without changing source, dependency versions or test predicates."}
(out/"RESULT.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result),flush=True)
raise SystemExit(0 if p.returncode==0 and result["source_unchanged"] else 1)
