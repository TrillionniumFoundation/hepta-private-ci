import pathlib, subprocess, os, json, time, hashlib, gzip, resource, datetime, re, stat, xml.etree.ElementTree as ET
root=pathlib.Path("/Users/qianqi/work/hepta-root-mac-fixtures-shallow-20261118-2e9b")
source=root/"joint-source-2b364221"
out=root/"joint-native-validation-1"
out.mkdir(exist_ok=False)
target=root/"native-target-joint2b-run1"
oldtarget=root/"native-target-9aaa-run2"
assert not target.exists()
env=os.environ.copy()
env.update(PATH="/opt/homebrew/bin:/opt/homebrew/opt/rustup/bin:/Users/qianqi/.cargo/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin",CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS="2",RUSTUP_TOOLCHAIN="1.96.0",GIT_NO_LAZY_FETCH="1",GIT_TERMINAL_PROMPT="0",GH_PROMPT_DISABLED="1")
prior_raw=(root/"native-validation-3/RESULT.json").read_bytes()
assert hashlib.sha256(prior_raw).hexdigest()=="93396ec6cd66d9bbc6546614468335f4a10d86d9674ed40832e0ca4d5c12ef0d"
prior=json.loads(prior_raw)
expected=set(prior["expected_cases"])
command=next(s["command"] for s in prior["stages"] if s["name"]=="original-macos-fixtures")
assert len(expected)==11 and command[command.index("--retries")+1]=="0" and command[command.index("--no-tests")+1]=="fail"
rec=root/"native-validation-3-recovered"
rec.mkdir(exist_ok=False)
xmlpath=root/"source/codex-rs/target/nextest/local/junit.xml"
xml=xmlpath.read_bytes()
assert hashlib.sha256(xml).hexdigest()=="2335596975d306299217427e112d6677eaaebcdb00c95a2b318c3bf89a2cce5d"
parsed=ET.fromstring(xml)
rawstderr=(root/"native-validation-3/original-macos-fixtures.stderr").read_bytes()
assert hashlib.sha256(rawstderr).hexdigest()=="418c3bf2803008a616e5aeed888291f25d47d2c9807fac263ef3f82a9fe2db25"
runid=parsed.attrib["uuid"]
assert runid=="fec7d29f-a476-4fd4-a1f8-9312cf519221" and runid.encode() in rawstderr
names=[c.attrib["name"].rsplit("::",1)[-1] for c in parsed.findall(".//testcase")]
assert len(names)==11 and set(names)==expected
assert all(c.find("failure") is None and c.find("error") is None and c.find("skipped") is None for c in parsed.findall(".//testcase"))
assert all(parsed.attrib[k]=="0" for k in ("failures","errors","skipped"))
stamp=datetime.datetime.fromisoformat(parsed.attrib["timestamp"])
assert datetime.datetime.fromisoformat(prior["started"]) <= stamp <= datetime.datetime.fromisoformat(prior["finished"])
assert prior["source_unchanged"] and next(s for s in prior["stages"] if s["name"]=="original-macos-fixtures")["exit_code"]==0
(rec/"original-junit.xml").write_bytes(xml)
recovered={"schema":"hepta.readonly-recovered-original-junit.v1","source_head":prior["source_head"],"source_tree":prior["source_tree"],"original_job":"1a1efdc129f-ffbe-639","original_owner_exit":1,"original_result_sha256":hashlib.sha256(prior_raw).hexdigest(),"original_result_preserved":True,"original_native_command_exit":0,"report_path":str(xmlpath),"junit_sha256":hashlib.sha256(xml).hexdigest(),"stderr_sha256":hashlib.sha256(rawstderr).hexdigest(),"run_id":runid,"same_original_run":True,"expected_cases_present_exactly_once":True,"tests":11,"passed":11,"failed":0,"errors":0,"skipped":0,"additional_native_executions":0,"case_names":names,"scope":"Recovery of the actual original report; does not rewrite the failed owner receipt."}
(rec/"READOUT.json").write_text(json.dumps(recovered,indent=2)+"\n")
assert (root/"native-validation-3/RESULT.json").read_bytes()==prior_raw
start=time.monotonic()
report={"schema":"hepta.actual-macos-joint-fixture-validation.v1","source_head":"2b3642214ba5ff4aaac27de13322a354a69507e7","source_tree":"4f558b31a5ea13d3ddf7fa43aec605dd478ef072","started":datetime.datetime.now(datetime.timezone.utc).isoformat(),"expected_cases":sorted(expected),"stages":[],"original_negative_controls_retained":True,"same_original_command":command,"full_platform_qualification":False,"energy_joules":None,"monetary_cost":None,"model_calls":0,"training_steps":0,"original_old_source_pass_not_inherited":True,"owner_script_sha256":hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
def save():
    (out/"RESULT.json").write_text(json.dumps(report,indent=2)+"\n")
def run(name,args,cwd=source):
    t=time.monotonic()
    before=resource.getrusage(resource.RUSAGE_CHILDREN)
    with (out/(name+".stdout")).open("wb") as stdout,(out/(name+".stderr")).open("wb") as stderr:
        p=subprocess.run(args,cwd=cwd,env=env,stdout=stdout,stderr=stderr)
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    row={"name":name,"command":args,"exit_code":p.returncode,"wall_seconds":time.monotonic()-t,"owned_child_user_cpu_seconds":after.ru_utime-before.ru_utime,"owned_child_system_cpu_seconds":after.ru_stime-before.ru_stime}
    report["stages"].append(row);save();print(json.dumps(row),flush=True)
    return p.returncode
def require_source():
    head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=source,env=env,text=True).strip()
    tree=subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=source,env=env,text=True).strip()
    dirty=subprocess.check_output(["git","status","--porcelain","--untracked-files=all"],cwd=source,env=env,text=True)
    assert head==report["source_head"] and tree==report["source_tree"] and not dirty.strip()
    raw=gzip.decompress((root/"compile-input-materialization-3/joint2b/source-before-v3.json.gz").read_bytes())
    assert hashlib.sha256(raw).hexdigest()=="972bb31325a567812e6d22666ddfab4cb24ee790e00a49643d6ae55b491c42af"
    entries=json.loads(raw)
    assert len(entries)==11598
    for item in entries:
        p=source/item["path"]
        data=os.fsencode(os.readlink(p)) if item["mode"]=="120000" else p.read_bytes()
        assert len(data)==item["bytes"] and hashlib.sha256(data).hexdigest()==item["sha256"],item["path"]
    return {"head":head,"tree":tree,"files":len(entries),"inventory_sha256":hashlib.sha256(raw).hexdigest(),"status":dirty}
try:
    fetchraw=(root/"joint-locked-fetch-1/RESULT.json").read_bytes()
    assert hashlib.sha256(fetchraw).hexdigest()=="e5a571a0e6cd994d5833f3497ddfd7473e3180d8f5b11d43d756fcdaa9bb28aa"
    fetched=json.loads(fetchraw)
    assert fetched["exit_code"]==0 and fetched["source_unchanged"]
    report["dependency_fetch_sha256"]=hashlib.sha256(fetchraw).hexdigest()
    report["before"]=require_source()
    junit=source/"codex-rs/target/nextest/local/junit.xml"
    assert not junit.exists()
    assert run("clone-owned-completed-cache",["/bin/cp","-cR",str(oldtarget),str(target)],cwd=root)==0
    count=0
    for base,dirs,files in os.walk(target):
        for name in files:
            dst=pathlib.Path(base)/name
            a=dst.lstat()
            if stat.S_ISREG(a.st_mode):
                original=oldtarget/dst.relative_to(target)
                b=original.lstat()
                assert stat.S_ISREG(b.st_mode) and (a.st_dev,a.st_ino)!=(b.st_dev,b.st_ino) and a.st_nlink==1
                count+=1
    report["cache_clone"]={"method":"APFS cp -cR copy-on-write","regular_files_verified_no_shared_inode":count,"source_target":str(oldtarget),"new_target":str(target),"prior_owner_terminal":True,"shared_writable_hardlinks":False}
    for label,args in [("platform",["uname","-srm"]),("rustc-version",["rustc","-vV"]),("just-version",["just","--version"]),("nextest-version",["cargo","nextest","--version"])]:
        assert run(label,args)==0
    test_started=time.time_ns()
    code=run("original-macos-fixtures",command)
    report["native_exit_code"]=code
    report["junit_path"]=str(junit)
    report["junit_present"]=junit.is_file()
    if junit.is_file():
        data=junit.read_bytes()
        assert junit.stat().st_mtime_ns>=test_started
        (out/"original-macos-fixtures.xml").write_bytes(data)
        tree=ET.fromstring(data);cases=tree.findall(".//testcase")
        names=[c.attrib["name"].rsplit("::",1)[-1] for c in cases]
        failed=sum(c.find("failure") is not None or c.find("error") is not None for c in cases)
        skipped=sum(c.find("skipped") is not None for c in cases)
        stderr=(out/"original-macos-fixtures.stderr").read_bytes()
        assert tree.attrib["uuid"].encode() in stderr
        assert tree.attrib["uuid"]!=runid
        report["junit"]={"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data),"cases":len(cases),"names":names,"failures":failed,"skipped":skipped,"run_id":tree.attrib["uuid"],"timestamp_ns":str(junit.stat().st_mtime_ns)}
        report["all_expected_cases_present_exactly_once"]=len(names)==len(expected) and set(names)==expected
        report["passed"]=code==0 and failed==0 and skipped==0 and report["all_expected_cases_present_exactly_once"]
    else:
        report["passed"]=False
    report["status"]="passed" if report["passed"] else "failed"
except BaseException as error:
    report.update(status="failed",passed=False,error=repr(error))
finally:
    try:
        report["after"]=require_source()
        report["source_unchanged"]=report.get("before")==report["after"]
    except BaseException as error:
        report["source_unchanged"]=False;report["after_error"]=repr(error)
    report["wall_seconds_including_nested_stages"]=time.monotonic()-start
    report["cost_scope"]="Owned validation stages; nested command costs are not additional to total wall. Physical full cost remains unmeasured."
    report["finished"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
    save();print(json.dumps({"status":report.get("status"),"passed":report.get("passed"),"source_unchanged":report["source_unchanged"],"error":report.get("error")}),flush=True)
raise SystemExit(0 if report.get("passed") and report["source_unchanged"] else 1)
