import pathlib, subprocess, os, json, time, hashlib, gzip, resource, datetime, xml.etree.ElementTree as ET
root = pathlib.Path("/Users/qianqi/work/hepta-root-mac-fixtures-shallow-20261118-2e9b")
source = root / "source"
out = root / "native-validation-2"
cache_raw = (root / "locked-fetch-1/RESULT.json").read_bytes()
cache = json.loads(cache_raw)
assert cache["exit_code"] == 0 and cache["source_unchanged"] and cache["tests_executed"] == 0
assert cache["source"] == "9aaac03f5f6bcad3ff14ffe2ecfb11aa4299f16f"
previous_raw = (root / "native-validation-1/RESULT.json").read_bytes()
assert hashlib.sha256(previous_raw).hexdigest() == "de979e4651e8dc64955b0caeb31bb48b0ba0a64738874f48773a665cdc99efce"
previous = json.loads(previous_raw)
assert previous["source_unchanged"] and previous["junit_present"] is False
out.mkdir(exist_ok=False)
target = root / "native-target-9aaa-run2"
assert not target.exists()
env = os.environ.copy()
env.update(PATH="/opt/homebrew/bin:/opt/homebrew/opt/rustup/bin:/Users/qianqi/.cargo/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin", CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS="2", RUSTUP_TOOLCHAIN="1.96.0", GIT_NO_LAZY_FETCH="1", GIT_TERMINAL_PROMPT="0", GH_PROMPT_DISABLED="1")
expected = {
"research_material_rejects_duplicate_json_keys_at_any_depth",
"research_material_canonicalization_sorts_every_object_level",
"research_material_tensors_reject_overlap_holes_trailing_and_nonfinite",
"research_material_reads_reject_leaf_ancestor_and_hardlink_aliases",
"research_material_size_reference_and_mutation_checks_use_actual_bytes",
"research_owner_publication_is_create_only_and_detects_directory_replacement",
"research_owner_concurrent_handles_cas_has_exactly_one_retained_winner",
"research_owner_partial_entries_are_observable_and_never_replaced",
"research_owner_initial_freeze_rejects_existing_training_or_evaluation",
"causal_readback_joins_original_clocks_and_survives_circuit_reopen_without_contact",
"causal_readback_refuses_substituted_inputs_and_absent_cell_owner_history"}
start = time.monotonic()
report = {"schema": "hepta.actual-macos-fixture-validation.v1", "source_head": "9aaac03f5f6bcad3ff14ffe2ecfb11aa4299f16f", "source_tree": "c25c9a3d93e799c275ba4888eef1148e6507d420", "expected_cases": sorted(expected), "source_preparation_job": "1a1efaf5812-ffbe-5a6", "source_preparation_files": 11217, "started": datetime.datetime.now(datetime.timezone.utc).isoformat(), "stages": [], "original_negative_controls_retained": True, "full_platform_qualification": False, "energy_joules": None, "monetary_cost": None}
report.update(attempt=2, previous_zero_case_job="1a1efb163e3-ffbe-5a9", dependency_acquisition_job="1a1efb48370-ffbe-5b3", dependency_acquisition_sha256=hashlib.sha256(cache_raw).hexdigest(), previous_validation_sha256=hashlib.sha256(previous_raw).hexdigest(), owner_script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(), model_calls=0, training_steps=0)
def save():
    (out / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
def run(name, args, cwd=source):
    t = time.monotonic()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    with (out / (name + ".stdout")).open("wb") as stdout, (out / (name + ".stderr")).open("wb") as stderr:
        p = subprocess.run(args, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    row = {"name": name, "command": args, "exit_code": p.returncode, "wall_seconds": time.monotonic() - t, "owned_child_user_cpu_seconds": after.ru_utime-before.ru_utime, "owned_child_system_cpu_seconds": after.ru_stime-before.ru_stime}
    report["stages"].append(row)
    save()
    print(json.dumps(row), flush=True)
    return p.returncode
def require_source():
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, env=env, text=True).strip()
    tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=source, env=env, text=True).strip()
    status = subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=all"], cwd=source, env=env, text=True)
    assert head == report["source_head"] and tree == report["source_tree"] and not status.strip()
    original = gzip.decompress((root / "recovery-3/source-before.json.gz").read_bytes())
    entries = json.loads(original)
    for item in entries:
        p = source / item["path"]
        data = os.fsencode(os.readlink(p)) if item["mode"] == "120000" else p.read_bytes()
        assert len(data) == item["bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"], item["path"]
    return {"head": head, "tree": tree, "files": len(entries), "inventory_sha256": hashlib.sha256(original).hexdigest(), "status": status}
try:
    prep = json.loads((root / "recovery-3/RESULT.json").read_text())
    assert prep["status"] == "prepared" and prep["verified_materialized_files"] == 11217
    report["before"] = require_source()
    assert run("platform", ["uname", "-srm"]) == 0
    assert run("rustc-version", ["rustc", "-vV"]) == 0
    assert run("just-version", ["just", "--version"]) == 0
    assert run("nextest-version", ["cargo", "nextest", "--version"]) == 0
    test_started = time.time_ns()
    command = ["just", "test", "--locked", "--offline", "-p", "codex-hepta-agentd", "--lib", "-E", "test(research_material_) | test(research_owner_) | test(causal_readback_)", "--retries", "0", "--test-threads", "1", "--no-tests", "fail", "--success-output", "final", "--failure-output", "final"]
    code = run("original-macos-fixtures", command)
    junit = target / "nextest/local/junit.xml"
    report["junit_present"] = junit.is_file()
    if junit.is_file():
        assert junit.stat().st_mtime_ns >= test_started
        data = junit.read_bytes()
        (out / "original-macos-fixtures.xml").write_bytes(data)
        parsed = ET.fromstring(data)
        cases = parsed.findall(".//testcase")
        names = [case.attrib["name"].rsplit("::", 1)[-1] for case in cases]
        failures = sum(case.find("failure") is not None or case.find("error") is not None for case in cases)
        skipped = sum(case.find("skipped") is not None for case in cases)
        report["junit"] = {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data), "cases": len(cases), "names": names, "failures": failures, "skipped": skipped, "timestamp_ns": str(junit.stat().st_mtime_ns)}
        report["all_expected_cases_present_exactly_once"] = len(names) == len(expected) and set(names) == expected
        report["passed"] = code == 0 and failures == 0 and skipped == 0 and report["all_expected_cases_present_exactly_once"]
    else:
        report["passed"] = False
    report["status"] = "passed" if report["passed"] else "failed"
except BaseException as error:
    report.update(status="failed", passed=False, error=repr(error))
finally:
    try:
        report["after"] = require_source()
        report["source_unchanged"] = report.get("before") == report["after"]
    except BaseException as error:
        report["source_unchanged"] = False
        report["after_error"] = repr(error)
    report["wall_seconds_including_nested_stages"] = time.monotonic() - start
    report["cost_scope"] = "Owned validation stages; command CPU/wall is nested and must not be added to this overall wall again. Full physical cost is unmeasured."
    report["finished"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({"status": report.get("status"), "passed": report.get("passed"), "source_unchanged": report["source_unchanged"], "error": report.get("error")}), flush=True)
raise SystemExit(0 if report.get("passed") and report["source_unchanged"] else 1)
