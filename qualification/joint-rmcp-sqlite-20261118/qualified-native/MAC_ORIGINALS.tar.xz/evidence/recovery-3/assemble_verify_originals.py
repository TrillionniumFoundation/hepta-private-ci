import pathlib, subprocess, os, json, time, hashlib, gzip, stat
root = pathlib.Path("/Users/qianqi/work/hepta-root-mac-fixtures-shallow-20261118-2e9b")
out = root / "recovery-3"
source = root / "source"
env = os.environ.copy()
env.update(PATH="/opt/homebrew/bin:/opt/homebrew/opt/rustup/bin:/Users/qianqi/.cargo/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin", GIT_NO_LAZY_FETCH="1", GIT_TERMINAL_PROMPT="0")
report = {"schema": "hepta.mac-original-source-materialization.v3", "started_ns": str(time.time_ns()), "expected_commit": "9aaac03f5f6bcad3ff14ffe2ecfb11aa4299f16f", "original_pack_sha256": "d025a9f26c4e7facf85112601f53fe0d19699c1a0894b595bea9bbc59c37d748", "original_pack_bytes": 11643657, "tests_executed": 0, "stages": []}
def save():
    (out / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
def run(name, args, input_file=None):
    start = time.monotonic()
    with (out / (name + ".stdout")).open("wb") as stdout, (out / (name + ".stderr")).open("wb") as stderr:
        p = subprocess.run(args, cwd=source, env=env, stdin=input_file, stdout=stdout, stderr=stderr, timeout=180)
    row = {"name": name, "command": args, "exit_code": p.returncode, "wall_seconds": time.monotonic() - start}
    report["stages"].append(row)
    save()
    print(json.dumps(row), flush=True)
    assert p.returncode == 0, name
def git(*args, **kwargs):
    return subprocess.check_output(["git", "-c", "remote.origin.promisor=false", *args], cwd=source, env=env, **kwargs)
try:
    assert git("rev-parse", "HEAD", text=True).strip() == report["expected_commit"]
    parts = sorted(out.glob("original-pack-part-*.bin"))
    assert len(parts) == 12, len(parts)
    with (out / "original-blobs.pack").open("xb") as joined:
        for i, path in enumerate(parts):
            assert path.name == "original-pack-part-%02d.bin" % i
            b = path.read_bytes()
            assert len(b) == (1048560 if i < 11 else 109497), (path, len(b))
            joined.write(b)
    data = (out / "original-blobs.pack").read_bytes()
    assert len(data) == report["original_pack_bytes"]
    assert hashlib.sha256(data).hexdigest() == report["original_pack_sha256"]
    with (out / "original-blobs.pack").open("rb") as pack:
        run("strict-original-pack-import", ["git", "index-pack", "--stdin", "--strict"], pack)
    entries = []
    for entry in git("ls-tree", "-r", "-z", "HEAD").split(b"\0"):
        if not entry:
            continue
        header, raw_path = entry.split(b"\t", 1)
        mode, kind, sha = header.decode().split()
        path = raw_path.decode()
        if kind == "blob" and ("/" not in path or any(path.startswith(p + "/") for p in ("codex-rs", "scripts", "config", ".cargo", "hia"))):
            entries.append({"path": path, "mode": mode, "git_sha1": sha})
    unique = sorted({entry["git_sha1"] for entry in entries})
    result = subprocess.run(["git", "-c", "remote.origin.promisor=false", "cat-file", "--batch-check"], cwd=source, env=env, input=("\n".join(unique) + "\n").encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
    (out / "all-original-object-check.stdout").write_bytes(result.stdout)
    (out / "all-original-object-check.stderr").write_bytes(result.stderr)
    assert result.returncode == 0 and not any(line.endswith(b" missing") for line in result.stdout.splitlines())
    assert len(result.stdout.splitlines()) == len(unique)
    run("materialize-owned-source", ["git", "-c", "remote.origin.promisor=false", "read-tree", "-mu", "HEAD"])
    run("source-status", ["git", "status", "--porcelain", "--untracked-files=all"])
    assert not (out / "source-status.stdout").read_text().strip()
    for entry in entries:
        path = source / entry["path"]
        mode = path.lstat().st_mode
        if entry["mode"] == "120000":
            assert stat.S_ISLNK(mode)
            data = os.fsencode(os.readlink(path))
        else:
            assert stat.S_ISREG(mode)
            assert bool(mode & stat.S_IXUSR) == (entry["mode"] == "100755")
            data = path.read_bytes()
        assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == entry["git_sha1"], entry["path"]
        entry.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    body = (json.dumps(entries, sort_keys=True, separators=(",", ":")) + "\n").encode()
    compressed = gzip.compress(body, mtime=0)
    (out / "source-before.json.gz").write_bytes(compressed)
    report.update(status="prepared", tree=git("rev-parse", "HEAD^{tree}", text=True).strip(), verified_materialized_files=len(entries), verified_unique_original_objects=len(unique), source_status="", source_inventory_sha256=hashlib.sha256(body).hexdigest(), source_inventory_gzip_sha256=hashlib.sha256(compressed).hexdigest())
except BaseException as error:
    report.update(status="failed", error=repr(error))
    raise
finally:
    report["finished_ns"] = str(time.time_ns())
    save()
    print(json.dumps({"status": report.get("status"), "files": report.get("verified_materialized_files"), "error": report.get("error")}), flush=True)
