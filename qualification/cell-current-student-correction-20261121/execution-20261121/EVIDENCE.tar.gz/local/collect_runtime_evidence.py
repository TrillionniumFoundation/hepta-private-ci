"""Read-only evidence collection after bounded recovery; excludes weights and wheels."""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

ROOT = Path('/home/qian-qi/work/hepta-e2-wheel-transfer-20261121-ac5459')
JOBS = ['1a1fc221b14-ffbe-1cc1', '1a1fc276130-ffbe-1cd8', '1a1fc293e04-ffbe-1ce1',
        '1a1fc2c2bce-ffbe-1cef', '1a1fc3a1378-ffbe-1d1d', '1a1fc41e715-ffbe-1d32',
        '1a1fc434359-ffbe-1d35', '1a1fc46d2d2-ffbe-1d3f', '1a1fc4a6a53-ffbe-1d48',
        '1a1fc4bfbd1-ffbe-1d4d', '1a1fc4d4273-ffbe-1d50', '1a1fc4e50d2-ffbe-1d51',
        '1a1fc515d8b-ffbe-1d56', '1a1fc54ef3b-ffbe-1d5b']
CODE = r'''import hashlib,json,time
from pathlib import Path
root=Path('/home/qian-qi/work/hepta-current-student-correction-20261121-ac5459')
runtime=root/'runtime-recovery'
prepared=root/'source/qualification/cell-current-student-correction-20261121/prepared'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
files={}
paths=[root/'DEPLOYMENT.json',root/'RETAINED_COPY.json']
for pat in ['*.json','*.txt','*.py','logs/*.log']:paths+=list(runtime.glob(pat))
for p in sorted(set(paths)):
 if p.is_file() and p.stat().st_size<2000000:files[p.relative_to(root).as_posix()]=p.read_text()
bundle=json.loads((prepared/'CORRECTIONS.json').read_text())
protocol=json.loads((prepared/'PROTOCOL.json').read_text())
inventories=[]
for mode,binding in bundle['parents'].items():
 m=binding['manifest']
 for label,artifacts in [('original',Path('/dev/shm/hepta-cell-experiments-v3-20261116-0c078a')),('retained',root/'artifacts')]:
  for row in m['adapter_files']:
   p=artifacts/m['adapter_directory']/row['path']
   actual={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
   inventories.append({'role':label,'mode':mode,'expected':row,'actual':actual,'matches':actual['bytes']==row['bytes'] and actual['sha256']==row['sha256']})
base_inventory=[]
base=bundle['parents']['native_feedback']['manifest']
for label,artifacts in [('original',Path('/dev/shm/hepta-cell-experiments-v3-20261116-0c078a')),('retained',root/'artifacts')]:
 for row in base['base_manifest']['files']:
  p=artifacts/base['runtime']['base_directory']/row['path']
  actual={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
  base_inventory.append({'role':label,'expected':row,'actual':actual,'matches':actual['bytes']==row['bytes'] and actual['sha256']==row['sha256']})
source_inventory=[{'name':name,'expected_sha256':value,'actual_sha256':sha(prepared.parent/name)} for name,value in protocol['source_files'].items()]
state={'observed_at_ns':time.time_ns(),'candidate_digest':protocol['candidate_digest'],'encoding_exists':(prepared/'ENCODING.json').exists(),'claims_present':[p.name for p in prepared.glob('CLAIM-*')],'training_artifact_directory_exists':(root/'artifacts/research-current-student-correction-20261121').exists(),'adapter_inventory':inventories,'all_original_and_retained_parents_unchanged':all(x['matches'] for x in inventories),'base_inventory':base_inventory,'all_original_and_retained_base_files_unchanged':all(x['matches'] for x in base_inventory),'source_inventory':source_inventory,'published_source_unchanged':all(x['expected_sha256']==x['actual_sha256'] for x in source_inventory),'model_downloads':0,'model_calls':0,'optimizer_updates':0,'native_calls':0}
own=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  raw=(proc/'cmdline').read_bytes();args=[x.decode() for x in raw.split(b'\0') if x]
  if args and (args[0].startswith(str(runtime)+'/') or any(str(runtime/p) in args for p in ['SOURCE_SWITCH_OPERATOR.py','DEADLINE_GUARD_OPERATOR.py'])):
   st=(proc/'stat').read_text().rsplit(') ',1)[1].split()
   own.append({'pid':int(proc.name),'ppid':int(st[1]),'start_ticks':int(st[19]),'argv':args,'cmdline_sha256':hashlib.sha256(raw).hexdigest()})
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
state['owned_runtime_processes_still_observed']=own
files['FINAL_MODEL_AND_SOURCE_READBACK.json']=json.dumps(state,sort_keys=True)+'\n'
print(json.dumps(files))
'''


def main():
    started = time.time()
    result = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=5', 'desktop', 'python3 -'], input=CODE, capture_output=True, text=True, timeout=60)
    if result.returncode:
        raise RuntimeError('desktop evidence read failed: ' + result.stderr[-1000:])
    desktop = json.loads(result.stdout)
    contents = {'desktop/' + name: content.encode() for name, content in desktop.items()}
    for pattern in ['*.json', '*.txt', '*.log', '*.py']:
        for path in ROOT.glob(pattern):
            if path.is_file() and path.stat().st_size < 2000000:
                contents['rog/' + path.name] = path.read_bytes()
    partials = []
    for subdir in ['torch-pieces', 'torch-suffix-once', 'wheels']:
        for path in sorted((ROOT / subdir).glob('*')):
            if path.is_file():
                partials.append({'path': str(path), 'bytes': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns, 'included_in_archive': False})
    contents['ROG_MATERIALS_INVENTORY.json'] = (json.dumps(partials, sort_keys=True) + '\n').encode()
    terminal = []
    registry = Path('/home/qian-qi/.local/state/hepta-runtime-mac-worker/jobs')
    for identity in JOBS:
        folder = registry / identity
        row = {'job_id': identity, 'terminal_observed': (folder / 'exit.json').exists()}
        if row['terminal_observed']:
            row['exit'] = json.loads((folder / 'exit.json').read_text())
        terminal.append(row)
        for name in ['request.json', 'started.json', 'owner-intent.json', 'launch.json', 'child.json', 'exit.json', 'exit.witness.json', 'stdout.log', 'stderr.log']:
            path = folder / name
            if path.is_file():
                if path.stat().st_size > 2000000:
                    raise ValueError('unexpected large job metadata: ' + str(path))
                contents['jobs/' + identity + '/' + name] = path.read_bytes()
    contents['DURABLE_JOB_TERMINALS.json'] = (json.dumps(terminal, sort_keys=True) + '\n').encode()
    manifest = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(contents.items())]
    contents['REMOTE_ARCHIVE_MANIFEST.json'] = (json.dumps({'created_at_ns': time.time_ns(), 'collection_wall_seconds': time.time() - started, 'files': manifest, 'weights_included': False, 'wheels_included': False}, sort_keys=True) + '\n').encode()
    destination = ROOT / 'RUNTIME_EVIDENCE_FINAL.tar.gz'
    with destination.open('xb') as output:
        with tarfile.open(fileobj=output, mode='w:gz') as archive:
            for name, data in sorted(contents.items()):
                member = tarfile.TarInfo(name)
                member.size = len(data)
                member.mode = 0o644
                member.mtime = 0
                archive.addfile(member, io.BytesIO(data))
        output.flush()
        os.fsync(output.fileno())
    print(json.dumps({'path': str(destination), 'bytes': destination.stat().st_size, 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'members': len(contents), 'terminal_states': [{'id': x['job_id'], 'observed': x['terminal_observed']} for x in terminal]}), flush=True)


if __name__ == '__main__':
    main()
