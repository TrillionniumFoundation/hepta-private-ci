"""Bounded official direct dependencies while the separately owned Torch suffix finishes."""
import email.parser
import hashlib
import html.parser
import json
import os
from pathlib import Path
import subprocess
import time
import urllib.parse
import urllib.request

ROOT = Path('/home/qian-qi/work/hepta-e2-wheel-transfer-20261121-ac5459')
DEADLINE = json.loads((ROOT / 'RELAY_STARTED.json').read_text())['original_deadline']
FILENAME = 'torch-2.9.1+cu128-cp312-cp312-manylinux_2_28_x86_64.whl'


def remaining():
    value = DEADLINE - time.time()
    if value <= 0:
        raise TimeoutError('original recovery deadline exhausted')
    return value


def save(name, value):
    with (ROOT / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def command(name, argv):
    with (ROOT / (name + '.log')).open('xb') as log:
        child = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT)
        fields = (Path('/proc') / str(child.pid) / 'stat').read_text().rsplit(') ', 1)[1].split()
        save(name + '-PROCESS.json', {'argv': argv, 'pid': child.pid, 'ppid': int(fields[1]), 'start_ticks': int(fields[19])})
        try:
            result = child.wait(timeout=remaining())
        except BaseException:
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=5)
            raise
    save(name + '-EXIT.json', {'returncode': result, 'ended_at_ns': time.time_ns()})
    if result:
        raise RuntimeError(name + ' failed ' + str(result))


class Links(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.match = None

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == 'a' and urllib.parse.unquote(urllib.parse.urlsplit(values.get('href', '')).path).endswith('/' + FILENAME):
            self.match = values


def main():
    save('DEPENDENCY_SEED_CLAIM.json', {'deadline': DEADLINE, 'started_at_ns': time.time_ns(), 'original_elapsed': time.time() - (DEADLINE - 3600), 'model_calls': 0, 'updates': 0, 'retries': 0})
    parser = Links()
    index = 'https://download.pytorch.org/whl/cu128/torch/'
    with urllib.request.urlopen(index, timeout=min(20, remaining())) as response:
        parser.feed(response.read().decode())
    if parser.match is None:
        raise ValueError('official exact wheel index entry absent')
    entry = parser.match
    metadata_hash = entry.get('data-core-metadata', entry.get('data-dist-info-metadata', ''))
    if not metadata_hash.startswith('sha256='):
        raise ValueError('official metadata has no authenticated SHA256')
    url = urllib.parse.urljoin(index, entry['href']).split('#')[0] + '.metadata'
    with urllib.request.urlopen(url, timeout=min(20, remaining())) as response:
        metadata = response.read()
    if hashlib.sha256(metadata).hexdigest() != metadata_hash.split('=', 1)[1]:
        raise ValueError('official metadata SHA mismatch')
    (ROOT / 'OFFICIAL_TORCH_METADATA.txt').write_bytes(metadata)
    requirements = email.parser.BytesParser().parsebytes(metadata).get_all('Requires-Dist')
    save('DEPENDENCY_METADATA_BINDING.json', {'url': url, 'sha256': hashlib.sha256(metadata).hexdigest(), 'requirements': requirements})
    retained_name = 'nvidia_cusparselt_cu12-0.7.1-py3-none-manylinux2014_x86_64.whl'
    pending = ROOT / (retained_name + '.retained-pending')
    source = 'desktop:/home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery/tmp/pip-unpack-i9vjm6r_/' + retained_name
    command('retained-cusparselt-copy', ['scp', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=5', source, str(pending)])
    with urllib.request.urlopen('https://pypi.org/pypi/nvidia-cusparselt-cu12/0.7.1/json', timeout=min(20, remaining())) as response:
        release = json.load(response)
    item = next(row for row in release['urls'] if row['filename'] == retained_name)
    digest = hashlib.sha256()
    with pending.open('rb') as stream:
        for data in iter(lambda: stream.read(1048576), b''):
            remaining()
            digest.update(data)
    if pending.stat().st_size != item['size'] or digest.hexdigest() != item['digests']['sha256']:
        raise ValueError('retained cusparselt does not match official PyPI SHA')
    os.link(pending, ROOT / 'wheels' / retained_name)
    save('RETAINED_CUSPARSELT_VERIFIED.json', {'filename': retained_name, 'source': source, 'url': item['url'], 'bytes': item['size'], 'sha256': digest.hexdigest()})
    command('dependency-venv', ['/usr/bin/python3.12', '-m', 'venv', str(ROOT / 'dependency-venv')])
    argv = [str(ROOT / 'dependency-venv/bin/python'), '-B', '-m', 'pip', '--isolated', '--disable-pip-version-check', 'download', '--no-deps', '--only-binary=:all:', '--retries', '0', '--timeout', '20', '--index-url', 'https://pypi.org/simple', '--find-links', str(ROOT / 'wheels'), '--dest', str(ROOT / 'wheels'), '--progress-bar', 'off', *requirements, 'transformers==4.57.3', 'tokenizers==0.22.2', 'safetensors==0.7.0', 'peft==0.18.0']
    command('dependency-direct-download', argv)
    save('DEPENDENCY_SEED_COMPLETE.json', {'original_elapsed': time.time() - (DEADLINE - 3600), 'wheels_pending_full_verification': len(list((ROOT / 'wheels').glob('*.whl'))), 'model_calls': 0, 'updates': 0})
    print('DEPENDENCY_SEED_COMPLETE', flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('DEPENDENCY_SEED_BLOCKED.json', {'status': 'BLOCKED', 'error': str(error), 'original_elapsed': time.time() - (DEADLINE - 3600), 'no_retry': True, 'model_calls': 0, 'updates': 0})
        raise
