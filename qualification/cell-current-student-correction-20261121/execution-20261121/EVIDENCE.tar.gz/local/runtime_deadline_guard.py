"""Record and stop only the owned desktop installer at its unchanged deadline."""
import hashlib
import json
import os
from pathlib import Path
import signal
import time

ROOT = Path('/home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery')
CLAIM = json.loads((ROOT / 'INSTALL_CLAIM.json').read_text())
START = CLAIM['started_at_ns'] / 1e9
DEADLINE = START + 3600


def save(name, value):
    with (ROOT / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(ROOT, os.O_DIRECTORY)
    os.fsync(fd)
    os.close(fd)


save('DEADLINE_GUARD_CLAIM.json', {'armed_at_ns': time.time_ns(), 'deadline_unix': DEADLINE, 'original_started_unix': START, 'scope': 'only own exact original pip command and report binding; no new downloads or installation'})
print('GUARD_ARMED', DEADLINE, flush=True)
while time.time() < DEADLINE:
    if (ROOT / 'RECOVERY_COMPLETE.json').exists():
        save('DEADLINE_GUARD_EXIT.json', {'status': 'RECOVERY_ALREADY_COMPLETE', 'observed_at_ns': time.time_ns()})
        print('RECOVERY_ALREADY_COMPLETE', flush=True)
        raise SystemExit(0)
    time.sleep(min(1, DEADLINE - time.time()))

retained = ROOT / 'retained-at-deadline'
retained.mkdir(exist_ok=False)
materials = []
for path in (ROOT / 'tmp').glob('pip-unpack-*/*.whl'):
    destination = retained / (path.parent.name + '__' + path.name)
    try:
        os.link(path, destination)
        materials.append({'path': str(path), 'retained': str(destination), 'bytes': path.stat().st_size, 'official_hash_verified': False})
    except FileNotFoundError:
        materials.append({'path': str(path), 'retained': None, 'raced_owner_cleanup': True})

reports = {str(ROOT / 'TORCH_INSTALL.json'), str(ROOT / 'LIBRARIES_INSTALL.json')}
identities = []
for process in Path('/proc').iterdir():
    if not process.name.isdigit():
        continue
    try:
        raw = (process / 'cmdline').read_bytes()
        argv = [s.decode() for s in raw.split(b'\0') if s]
        if argv[:5] != [str(ROOT / 'venv/bin/python'), '-m', 'pip', '--isolated', 'install'] or not reports.intersection(argv):
            continue
        stat = (process / 'stat').read_text().rsplit(') ', 1)[1].split()
        identities.append({'pid': int(process.name), 'ppid': int(stat[1]), 'start_ticks': int(stat[19]), 'argv': argv, 'cmdline_sha256': hashlib.sha256(raw).hexdigest()})
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        continue
save('DEADLINE_OWNED_PROCESS_IDENTITIES.json', {'identities': identities, 'observed_at_ns': time.time_ns(), 'retained_materials': materials})
if len(identities) > 1:
    save('RECOVERY_BUDGET_TERMINAL.json', {'status': 'BLOCKED', 'reason': 'original recovery deadline exhausted; ambiguous original pip owner, no process signalled', 'original_elapsed': time.time() - START, 'matches': len(identities), 'model_calls': 0, 'optimizer_updates': 0})
    raise RuntimeError('ambiguous owned pip identity')
stopped = []
for identity in identities:
    process = Path('/proc') / str(identity['pid'])
    try:
        raw = (process / 'cmdline').read_bytes()
        stat = (process / 'stat').read_text().rsplit(') ', 1)[1].split()
        if hashlib.sha256(raw).hexdigest() != identity['cmdline_sha256'] or int(stat[1]) != identity['ppid'] or int(stat[19]) != identity['start_ticks']:
            raise RuntimeError('owned process identity changed, no signal sent')
        os.kill(identity['pid'], signal.SIGTERM)
        end = time.time() + 10
        alive = True
        while time.time() < end:
            try:
                if (process / 'stat').read_text().rsplit(') ', 1)[1].split()[0] == 'Z':
                    alive = False
                    break
            except FileNotFoundError:
                alive = False
                break
            time.sleep(.2)
        stopped.append({'identity': identity, 'signal': 'SIGTERM', 'still_running': alive})
    except ProcessLookupError:
        stopped.append({'identity': identity, 'already_exited': True})
save('RECOVERY_BUDGET_TERMINAL.json', {'status': 'BLOCKED', 'reason': 'original 3600-second runtime recovery deadline exhausted without a complete verified installed closure', 'original_started_unix': START, 'original_deadline_unix': DEADLINE, 'original_elapsed': time.time() - START, 'owned_process_results': stopped, 'retained_wheels_incomplete_or_unqualified': len(materials), 'automatic_retry': False, 'model_calls': 0, 'optimizer_updates': 0, 'native_calls': 0, 'encoding_exists': (ROOT.parent / 'source/qualification/cell-current-student-correction-20261121/prepared/ENCODING.json').exists()})
print('RECOVERY_BUDGET_BLOCKED', time.time() - START, flush=True)
