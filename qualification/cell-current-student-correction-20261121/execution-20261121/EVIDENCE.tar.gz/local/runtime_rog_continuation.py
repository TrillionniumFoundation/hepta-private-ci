"""One explicitly authorized suffix continuation, retaining the original recovery deadline."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import urllib.request

ROOT = Path('/home/qian-qi/work/hepta-e2-wheel-transfer-20261121-ac5459')
DESKTOP = '/home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=5', 'desktop']
START = json.loads((ROOT / 'RELAY_STARTED.json').read_text())
DEADLINE = START['original_deadline']
TOTAL = START['total_bytes']
EXPECTED = START['sha256']
FILENAME = 'torch-2.9.1+cu128-cp312-cp312-manylinux_2_28_x86_64.whl'
URL = 'https://download-r2.pytorch.org/whl/cu128/torch-2.9.1%2Bcu128-cp312-cp312-manylinux_2_28_x86_64.whl'
CORE = ['torch==2.9.1+cu128', 'transformers==4.57.3', 'tokenizers==0.22.2', 'safetensors==0.7.0', 'peft==0.18.0']


def remaining():
    r = DEADLINE - time.time()
    if r <= 0:
        raise TimeoutError('original recovery deadline exhausted')
    return r


def save(name, value):
    with (ROOT / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(ROOT, os.O_DIRECTORY)
    os.fsync(fd)
    os.close(fd)


def hash_file(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            remaining()
            digest.update(data)
    return digest.hexdigest()


def command(name, argv):
    with (ROOT / (name + '.log')).open('xb') as log:
        child = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT)
        stat = (Path('/proc') / str(child.pid) / 'stat').read_text().rsplit(') ', 1)[1].split()
        save(name + '-PROCESS.json', {'pid': child.pid, 'ppid': int(stat[1]), 'start_ticks': int(stat[19]), 'argv': argv})
        try:
            code = child.wait(timeout=remaining())
        except BaseException:
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=5)
            raise
        save(name + '-EXIT.json', {'returncode': code, 'ended_at_ns': time.time_ns()})
        if code:
            raise RuntimeError(name + ' failed: ' + str(code))
    print('PHASE_COMPLETE', name, flush=True)


def main():
    remaining()
    blocked = json.loads((ROOT / 'RELAY_BLOCKED.json').read_text())
    if blocked['status'] != 'BLOCKED':
        raise ValueError('original range owner has no terminal receipt')
    matches = []
    registry = Path('/home/qian-qi/.local/state/hepta-runtime-mac-worker/jobs')
    for entry in registry.iterdir():
        if entry.name < '1a1fc434359':
            continue
        request = entry / 'request.json'
        if not request.exists():
            continue
        record = json.loads(request.read_text())
        args = record.get('args', [])
        if record.get('timeout_seconds') == 1500 and any('torch-pieces' in arg and 'ThreadPoolExecutor' in arg for arg in args):
            terminal = entry / 'exit.json'
            if not terminal.exists():
                raise ValueError('original durable range job has no terminal exit')
            matches.append({'job_id': entry.name, 'request': record, 'exit': json.loads(terminal.read_text())})
    if len(matches) != 1:
        raise ValueError('original relay owner not unambiguous: ' + str(len(matches)))
    save('ORIGINAL_RELAY_ENVELOPE.json', matches[0])
    print('ORIGINAL_RELAY_JOB', matches[0]['job_id'], flush=True)
    suffixes = ROOT / 'torch-suffix-once'
    suffixes.mkdir(exist_ok=False)
    width = (TOTAL + 7) // 8
    plan = []
    for index in range(8):
        begin, end = index * width, min((index + 1) * width, TOTAL) - 1
        old = ROOT / 'torch-pieces' / ('%02d.part' % index)
        size = old.stat().st_size
        if not 0 <= size <= end - begin + 1:
            raise ValueError('invalid retained range length')
        plan.append({'index': index, 'begin': begin, 'end': end, 'retained_bytes': size, 'retained_sha256': hash_file(old), 'resume_from': begin + size})
    save('SUFFIX_CONTINUATION_CLAIM.json', {'original_deadline': DEADLINE, 'elapsed': time.time() - (DEADLINE - 3600), 'original_terminal': blocked, 'original_job': matches[0]['job_id'], 'source_url': URL, 'whole_sha256': EXPECTED, 'plan': plan, 'authorization': 'Root allowed one bounded official R2 remaining-offset continuation after explicit terminal original owner; no new budget', 'retries': 0, 'model_calls': 0, 'updates': 0})

    def fetch(row):
        if row['resume_from'] > row['end']:
            return
        began = time.time()
        request = urllib.request.Request(URL, headers={'Range': 'bytes=%d-%d' % (row['resume_from'], row['end'])})
        with urllib.request.urlopen(request, timeout=min(30, remaining())) as response:
            expected_range = 'bytes %d-%d/%d' % (row['resume_from'], row['end'], TOTAL)
            if response.status != 206 or response.headers.get('Content-Range') != expected_range:
                raise ValueError('range response identity mismatch')
            suffix = suffixes / ('%02d.suffix' % row['index'])
            with suffix.open('xb') as stream:
                while True:
                    remaining()
                    data = response.read(131072)
                    if not data:
                        break
                    stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            if suffix.stat().st_size != row['end'] - row['resume_from'] + 1:
                raise ValueError('incomplete suffix')
        print('SUFFIX_COMPLETE', row['index'], suffix.stat().st_size, time.time() - began, flush=True)

    with concurrent.futures.ThreadPoolExecutor(max_workers=7) as executor:
        for future in concurrent.futures.as_completed([executor.submit(fetch, row) for row in plan]):
            future.result()
    target = ROOT / 'wheels' / FILENAME
    with target.open('xb') as destination:
        for row in plan:
            files = [ROOT / 'torch-pieces' / ('%02d.part' % row['index'])]
            suffix = suffixes / ('%02d.suffix' % row['index'])
            if suffix.exists():
                files.append(suffix)
            for path in files:
                with path.open('rb') as source:
                    for data in iter(lambda: source.read(1024 * 1024), b''):
                        remaining()
                        destination.write(data)
        destination.flush()
        os.fsync(destination.fileno())
    if target.stat().st_size != TOTAL or hash_file(target) != EXPECTED:
        raise ValueError('whole official Torch size/SHA mismatch')
    save('TORCH_SUFFIX_VERIFIED.json', {'filename': FILENAME, 'bytes': TOTAL, 'sha256': EXPECTED, 'url': URL, 'original_elapsed': time.time() - (DEADLINE - 3600)})
    print('TORCH_WHOLE_VERIFIED', TOTAL, EXPECTED, flush=True)
    command('resolver-venv', ['/usr/bin/python3.12', '-m', 'venv', str(ROOT / 'resolver-venv')])
    pip = [str(ROOT / 'resolver-venv/bin/python'), '-B', '-m', 'pip', '--isolated', '--disable-pip-version-check']
    command('remaining-official-download', pip + ['download', '--only-binary=:all:', '--index-url', 'https://pypi.org/simple', '--find-links', str(ROOT / 'wheels'), '--dest', str(ROOT / 'wheels'), '--progress-bar', 'off', str(target), *CORE[1:]])
    verified = []
    for wheel in sorted((ROOT / 'wheels').glob('*.whl')):
        if wheel.name == FILENAME:
            url, expected = URL, EXPECTED
        else:
            name, version = wheel.name.split('-')[:2]
            with urllib.request.urlopen('https://pypi.org/pypi/%s/%s/json' % (name, version), timeout=min(30, remaining())) as response:
                metadata = json.load(response)
            row = next(row for row in metadata['urls'] if row['filename'] == wheel.name)
            if wheel.stat().st_size != row['size']:
                raise ValueError('official wheel size mismatch')
            url, expected = row['url'], row['digests']['sha256']
        actual = hash_file(wheel)
        if actual != expected:
            raise ValueError('official wheel SHA mismatch: ' + wheel.name)
        verified.append({'filename': wheel.name, 'url': url, 'bytes': wheel.stat().st_size, 'sha256': actual})
    save('OFFICIAL_CLOSURE_VERIFIED.json', verified)
    command('offline-plan', pip + ['install', '--dry-run', '--ignore-installed', '--no-index', '--find-links', str(ROOT / 'wheels'), '--report', str(ROOT / 'OFFLINE_PLAN.json'), *CORE])
    destination = DESKTOP + '/rog-relay-wheelhouse'
    command('desktop-wheelhouse-create', SSH + ['mkdir', destination])
    command('desktop-wheelhouse-copy', ['scp', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=5', *[str(p) for p in sorted((ROOT / 'wheels').glob('*.whl'))], str(ROOT / 'OFFICIAL_CLOSURE_VERIFIED.json'), 'desktop:' + destination + '/'])
    save('ROG_MATERIALS_TRANSFER_COMPLETE.json', {'original_elapsed': time.time() - (DEADLINE - 3600), 'destination': destination, 'verified_wheels': len(verified), 'desktop_rehash_pending': True, 'model_calls': 0, 'updates': 0})
    print('MATERIALS_TRANSFER_COMPLETE', len(verified), flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('SUFFIX_PHASE_BLOCKED.json', {'status': 'BLOCKED', 'type': type(error).__name__, 'error': str(error), 'original_elapsed': time.time() - (DEADLINE - 3600), 'no_retry': True, 'model_calls': 0, 'updates': 0})
        raise
