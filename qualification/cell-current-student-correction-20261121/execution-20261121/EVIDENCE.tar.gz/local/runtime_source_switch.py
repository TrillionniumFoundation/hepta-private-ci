"""Linux-only recovery operator; downloads packages, never model artifacts."""

import hashlib
import html.parser
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import time
import urllib.parse
import urllib.request
import venv

from pip._vendor.packaging.utils import parse_wheel_filename

ROOT = Path('/home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery')
CLAIM = json.loads((ROOT / 'INSTALL_CLAIM.json').read_text())
DEADLINE = CLAIM['started_at_ns'] / 1e9 + 3600
WHEELS = ROOT / 'official-pypi-wheelhouse'
CORE = ['torch==2.9.1+cu128', 'transformers==4.57.3', 'tokenizers==0.22.2',
        'safetensors==0.7.0', 'peft==0.18.0']
METADATA = {}


def remaining():
    value = DEADLINE - time.time()
    if value <= 0:
        raise TimeoutError('original 3600-second recovery budget exhausted')
    return value


def save(name, value):
    with (ROOT / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            remaining()
            digest.update(chunk)
    return digest.hexdigest()


def official(filename):
    name, version, _, _ = parse_wheel_filename(filename)
    key = (str(name), str(version))
    if key not in METADATA:
        url = 'https://pypi.org/pypi/' + key[0] + '/' + key[1] + '/json'
        with urllib.request.urlopen(url, timeout=min(30, remaining())) as response:
            METADATA[key] = json.load(response)
    return next(row for row in METADATA[key]['urls'] if row['filename'] == filename)


def command(label, argv):
    print('RECOVERY_PHASE', label, flush=True)
    environment = dict(os.environ, TMPDIR=str(ROOT / 'tmp'), PYTHONDONTWRITEBYTECODE='1')
    with (ROOT / 'logs' / (label + '.log')).open('xb') as log:
        child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=environment)
        save(label + '-PROCESS.json', {'pid': child.pid, 'argv': argv, 'started_at_ns': time.time_ns()})
        selector = selectors.DefaultSelector()
        selector.register(child.stdout, selectors.EVENT_READ)
        try:
            while selector.get_map():
                for key, _ in selector.select(timeout=min(1, remaining())):
                    data = os.read(key.fd, 65536)
                    if not data:
                        selector.unregister(key.fd)
                        continue
                    log.write(data)
                    log.flush()
                    print(data.decode(errors='replace'), end='', flush=True)
            result = child.wait(timeout=remaining())
            if result:
                raise RuntimeError(label + ' exited ' + str(result))
        except BaseException:
            child.terminate()
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=5)
            raise
        finally:
            selector.close()


class Links(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            self.links.extend(value for key, value in attrs if key == 'href')


def stop_old_owned_pip():
    matches = []
    wanted_reports = {str(ROOT / 'TORCH_INSTALL.json'), str(ROOT / 'LIBRARIES_INSTALL.json')}
    for process in Path('/proc').iterdir():
        if not process.name.isdigit():
            continue
        try:
            raw = (process / 'cmdline').read_bytes()
            argv = [x.decode() for x in raw.split(b'\0') if x]
            if (argv[:5] != [str(ROOT / 'venv/bin/python'), '-m', 'pip', '--isolated', 'install']
                    or not wanted_reports.intersection(argv)):
                continue
            stat = (process / 'stat').read_text()
            tail = stat.rsplit(') ', 1)[1].split()
            matches.append({'pid': int(process.name), 'ppid': int(tail[1]),
                            'start_ticks': int(tail[19]), 'argv': argv,
                            'cmdline_sha256': hashlib.sha256(raw).hexdigest()})
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            pass
    if len(matches) > 1:
        raise ValueError('ambiguous original pip owner; no process stopped')
    save('ORIGINAL_OWNER_BEFORE_STOP.json', {'matches': matches, 'observed_at_ns': time.time_ns()})
    for identity in matches:
        process = Path('/proc') / str(identity['pid'])
        raw = (process / 'cmdline').read_bytes()
        current = (process / 'stat').read_text().rsplit(') ', 1)[1].split()
        if (hashlib.sha256(raw).hexdigest() != identity['cmdline_sha256']
                or int(current[19]) != identity['start_ticks'] or int(current[1]) != identity['ppid']):
            raise ValueError('original owner identity changed before stop')
        os.kill(identity['pid'], signal.SIGTERM)
        until = min(DEADLINE, time.time() + 20)
        while process.exists() and time.time() < until:
            try:
                if (process / 'stat').read_text().rsplit(') ', 1)[1].split()[0] == 'Z':
                    break
            except FileNotFoundError:
                break
            time.sleep(0.2)
        if process.exists() and (process / 'stat').read_text().rsplit(') ', 1)[1].split()[0] != 'Z':
            raise RuntimeError('owned pip did not stop; offline installation not started')
    save('ORIGINAL_OWNER_STOPPED.json', {'identities': matches, 'signal': 'SIGTERM',
                                       'ended_at_ns': time.time_ns(), 'shared_processes_touched': False})


def main():
    remaining()
    WHEELS.mkdir(exist_ok=False)
    save('SOURCE_SWITCH_STARTED.json', {'started_at_ns': time.time_ns(), 'original_deadline_unix': DEADLINE,
         'original_elapsed_seconds': time.time() - CLAIM['started_at_ns'] / 1e9,
         'new_model_downloads': 0, 'optimizer_updates': 0, 'versions': CORE})
    reused = []
    for old in (ROOT / 'tmp').glob('pip-unpack-*/*.whl'):
        if old.name.startswith('torch-'):
            continue
        try:
            metadata = official(old.name)
            if old.stat().st_size != metadata['size'] or sha(old) != metadata['digests']['sha256']:
                continue
            destination = WHEELS / old.name
            if not destination.exists():
                os.link(old, destination)
            reused.append({'filename': old.name, 'sha256': metadata['digests']['sha256'],
                           'official_pypi_url': metadata['url'], 'bytes': metadata['size']})
        except (ValueError, StopIteration, FileNotFoundError):
            continue
    save('REUSED_VERIFIED_WHEELS.json', reused)
    parser = Links()
    with urllib.request.urlopen('https://download.pytorch.org/whl/cu128/torch/', timeout=min(30, remaining())) as response:
        parser.feed(response.read().decode())
    filename = 'torch-2.9.1+cu128-cp312-cp312-manylinux_2_28_x86_64.whl'
    torch_url = next(urllib.parse.urljoin('https://download.pytorch.org/whl/cu128/torch/', url)
                     for url in parser.links if urllib.parse.unquote(urllib.parse.urlsplit(url).path).endswith('/' + filename))
    torch_hash = urllib.parse.parse_qs(urllib.parse.urlsplit(torch_url).fragment)['sha256'][0]
    save('TORCH_OFFICIAL_WHEEL.json', {'url': torch_url, 'sha256': torch_hash, 'filename': filename})
    pip = [str(ROOT / 'venv/bin/python'), '-B', '-m', 'pip', '--isolated', '--disable-pip-version-check']
    command('official-wheel-download', pip + ['download', '--progress-bar', 'off', '--cache-dir', str(ROOT / 'cache-switch'),
            '--only-binary=:all:', '--index-url', 'https://pypi.org/simple', '--find-links', str(WHEELS),
            '--dest', str(WHEELS), 'torch @ ' + torch_url, *CORE[1:]])
    verified = []
    for wheel in sorted(WHEELS.glob('*.whl')):
        metadata = {'digests': {'sha256': torch_hash}, 'url': torch_url} if wheel.name == filename else official(wheel.name)
        actual = sha(wheel)
        if actual != metadata['digests']['sha256']:
            raise ValueError('official wheel hash mismatch: ' + wheel.name)
        verified.append({'filename': wheel.name, 'bytes': wheel.stat().st_size, 'sha256': actual, 'url': metadata['url']})
    save('VERIFIED_OFFICIAL_WHEELS.json', verified)
    command('offline-resolution', pip + ['install', '--dry-run', '--ignore-installed', '--no-index', '--find-links', str(WHEELS),
            '--report', str(ROOT / 'OFFLINE_PLAN.json'), *CORE])
    stop_old_owned_pip()
    final = ROOT / 'offline-venv'
    if final.exists():
        raise FileExistsError('final offline environment already exists')
    venv.EnvBuilder(with_pip=True, symlinks=True).create(final)
    command('offline-install', [str(final / 'bin/python'), '-B', '-m', 'pip', '--isolated', '--disable-pip-version-check',
            'install', '--no-index', '--no-compile', '--find-links', str(WHEELS), '--report', str(ROOT / 'FINAL_INSTALL.json'), *CORE])
    result = subprocess.run([str(final / 'bin/python'), '-B', '-m', 'pip', 'freeze', '--all'],
                            capture_output=True, text=True, check=True, timeout=remaining())
    (ROOT / 'FINAL_FREEZE.txt').write_text(result.stdout)
    save('RECOVERY_COMPLETE.json', {'status': 'COMPLETE', 'python': str(final / 'bin/python'),
         'original_recovery_wall_seconds': time.time() - CLAIM['started_at_ns'] / 1e9,
         'verified_wheels': len(verified), 'new_model_downloads': 0, 'optimizer_updates': 0})
    print('RECOVERY_COMPLETE', str(final / 'bin/python'), flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('SOURCE_SWITCH_BLOCKED.json', {'status': 'BLOCKED', 'error_type': type(error).__name__, 'error': str(error),
             'original_recovery_wall_seconds': time.time() - CLAIM['started_at_ns'] / 1e9,
             'automatic_retry': False, 'model_calls': 0, 'optimizer_updates': 0})
        raise
