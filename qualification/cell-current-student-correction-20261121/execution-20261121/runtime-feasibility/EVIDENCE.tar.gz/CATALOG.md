# 已知依赖目录：不是已经完成的完整闭包

表中 `unknown` 表示旧证据没有保留该项官方值，不能按 0 处理。10 份已有完整官方 SHA 的 wheel 合计 2,500,004,536 字节；全部精确路径、来源与资格状态见 CATALOG.json。

| 包 | 固定或观察版本 | 官方完整字节数 | 官方 SHA256 | 材料资格 |
|---|---|---:|---|---|
| torch | 2.9.1+cu128 | 900881648 | 7cb4018f4ce68b61fd3ef87dc1c4ca520731c7b5b200e360ad47b612d7844063 | SOURCE_BOUND_PARTIAL_RANGES_NO_WHOLE_OFFICIAL_SHA |
| transformers | 4.57.3 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| tokenizers | 0.22.2 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| safetensors | 0.7.0 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| peft | 0.18.0 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| filelock | desktop_original_torch_index: 4.2.4; rog_official_pypi_seed: 4.2.12 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| typing-extensions | desktop_original_torch_index: 4.16.0; rog_official_pypi_seed: 4.16.0 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| setuptools | desktop_original_torch_index: 78.1.0; rog_official_pypi_seed: 84.2.1 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| sympy | desktop_original_torch_index: 1.14.0; rog_official_pypi_seed: 1.14.0 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| networkx | desktop_original_torch_index: 3.7; rog_official_pypi_seed: 3.7 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| jinja2 | desktop_original_torch_index: 3.1.6; rog_official_pypi_seed: 3.1.6 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| fsspec | desktop_original_torch_index: 2026.9.0; rog_official_pypi_seed: 2026.9.0 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| nvidia-cuda-nvrtc-cu12 | 12.8.93 | 88040029 | a7756528852ef889772a84c6cd89d41dfa74667e24cca16bb31f8f061e3e9994 | full SHA 已核：desktop |
| nvidia-cuda-runtime-cu12 | 12.8.90 | 954765 | adade8dcbd0edf427b7204d480d6066d33902cab2a4707dcfc48a2d0fd44ab90 | full SHA 已核：desktop |
| nvidia-cuda-cupti-cu12 | 12.8.90 | 10248621 | ea0cb07ebda26bb9b29ba82cda34849e73c166c18162d3913575b0c9db9a6182 | full SHA 已核：desktop |
| nvidia-cudnn-cu12 | 9.10.2.21 | 706758467 | 949452be657fa16687d0930933f032835951ef0892b37d2d53824d1a84dc97a8 | full SHA 已核：desktop |
| nvidia-cublas-cu12 | 12.8.4.1 | 594346921 | 8ac4e771d5a348c551b2a426eda6193c19aa630236b418086020df5ba9667142 | full SHA 已核：desktop |
| nvidia-cufft-cu12 | 11.3.3.83 | 193118695 | 4d2dd21ec0b88cf61b62e6b43564355e5222e4a3fb394cac0db101f2dd0d4f74 | full SHA 已核：desktop |
| nvidia-curand-cu12 | 10.3.9.90 | 63619976 | b32331d4f4df5d6eefa0554c565b626c7216f87a06a4f56fab27c3b68a830ec9 | full SHA 已核：desktop |
| nvidia-cusolver-cu12 | 11.7.3.90 | 267506905 | 4376c11ad263152bd50ea295c05370360776f8c3427b30991df774f9fb26c450 | full SHA 已核：desktop |
| nvidia-cusparse-cu12 | 12.5.8.93 | 288216466 | 1ec05d76bbbd8b61b06a80e1eaf8cf4959c3d4ce8e711b65ebd0443bb0ebb13b | full SHA 已核：desktop |
| nvidia-cusparselt-cu12 | 0.7.1 | 287193691 | f1bb701d6b930d5a7cea44c19ceb973311500847f81b634d802b7b539dc55623 | full SHA 已核：rog |
| nvidia-nccl-cu12 | 2.27.5 | unknown | unknown | OBSERVED_POTENTIALLY_COMPLETE_FILE_OFFICIAL_SIZE_AND_SHA_UNKNOWN; observed 322348229 bytes |
| nvidia-nvshmem-cu12 | 3.3.20 | unknown | unknown | RETAINED_PARTIAL_PREFIX_OFFICIAL_SIZE_AND_SHA_UNKNOWN; observed 38901760 bytes |
| nvidia-nvtx-cu12 | 12.8.90 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| nvidia-nvjitlink-cu12 | 12.8.93 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| nvidia-cufile-cu12 | 1.13.1.3 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |
| triton | 3.5.1 | unknown | unknown | UNKNOWN_OFFICIAL_WHEEL_IDENTITY_AND_NO_QUALIFIED_RETAINED_WHEEL |

## 精确官方 URL 与已核主机路径

### torch

https://download-r2.pytorch.org/whl/cu128/torch-2.9.1%2Bcu128-cp312-cp312-manylinux_2_28_x86_64.whl#sha256=7cb4018f4ce68b61fd3ef87dc1c4ca520731c7b5b200e360ad47b612d7844063

### nvidia-cuda-nvrtc-cu12

https://files.pythonhosted.org/packages/05/6b/32f747947df2da6994e999492ab306a903659555dddc0fbdeb9d71f75e52/nvidia_cuda_nvrtc_cu12-12.8.93-py3-none-manylinux2010_x86_64.manylinux_2_12_x86_64.whl

desktop: /home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery/official-pypi-wheelhouse/nvidia_cuda_nvrtc_cu12-12.8.93-py3-none-manylinux2010_x86_64.manylinux_2_12_x86_64.whl

### nvidia-cuda-runtime-cu12

https://files.pythonhosted.org/packages/0d/9b/a997b638fcd068ad6e4d53b8551a7d30fe8b404d6f1804abf1df69838932/nvidia_cuda_runtime_cu12-12.8.90-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl

desktop: /home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery/official-pypi-wheelhouse/nvidia_cuda_runtime_cu12-12.8.90-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl

### nvidia-cuda-cupti-cu12

https://files.pythonhosted.org/packages/f8/02/2adcaa145158bf1a8295d83591d22e4103dbfd821bcaf6f3f53151ca4ffa/nvidia_cuda_cupti_cu12-12.8.90-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl

desktop: /home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery/official-pypi-wheelhouse/nvidia_cuda_cupti_cu12-12.8.90-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl

### nvidia-cudnn-cu12

https://files.pythonhosted.org/packages/ba/51/e123d997aa098c61d029f76663dedbfb9bc8dcf8c60cbd6adbe42f76d049/nvidia_cudnn_cu12-9.10.2.21-py3-none-manylinux_2_27_x86_64.whl

desktop: /home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery/official-pypi-wheelhouse/nvidia_cudnn_cu12-9.10.2.21-py3-none-manylinux_2_27_x86_64.whl

### nvidia-cublas-cu12

https://files.pythonhosted.org/packages/dc/61/e24b560ab2e2eaeb3c839129175fb330dfcfc29e5203196e5541a4c44682/nvidia_cublas_cu12-12.8.4.1-py3-none-manylinux_2_27_x86_64.whl

desktop: /home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery/official-pypi-wheelhouse/nvidia_cublas_cu12-12.8.4.1-py3-none-manylinux_2_27_x86_64.whl

### nvidia-cufft-cu12

https://files.pythonhosted.org/packages/1f/13/ee4e00f30e676b66ae65b4f08cb5bcbb8392c03f54f2d5413ea99a5d1c80/nvidia_cufft_cu12-11.3.3.83-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl

desktop: /home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery/official-pypi-wheelhouse/nvidia_cufft_cu12-11.3.3.83-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl

### nvidia-curand-cu12

https://files.pythonhosted.org/packages/fb/aa/6584b56dc84ebe9cf93226a5cde4d99080c8e90ab40f0c27bda7a0f29aa1/nvidia_curand_cu12-10.3.9.90-py3-none-manylinux_2_27_x86_64.whl

desktop: /home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery/official-pypi-wheelhouse/nvidia_curand_cu12-10.3.9.90-py3-none-manylinux_2_27_x86_64.whl

### nvidia-cusolver-cu12

https://files.pythonhosted.org/packages/85/48/9a13d2975803e8cf2777d5ed57b87a0b6ca2cc795f9a4f59796a910bfb80/nvidia_cusolver_cu12-11.7.3.90-py3-none-manylinux_2_27_x86_64.whl

desktop: /home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery/official-pypi-wheelhouse/nvidia_cusolver_cu12-11.7.3.90-py3-none-manylinux_2_27_x86_64.whl

### nvidia-cusparse-cu12

https://files.pythonhosted.org/packages/c2/f5/e1854cb2f2bcd4280c44736c93550cc300ff4b8c95ebe370d0aa7d2b473d/nvidia_cusparse_cu12-12.5.8.93-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl

desktop: /home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery/official-pypi-wheelhouse/nvidia_cusparse_cu12-12.5.8.93-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl

### nvidia-cusparselt-cu12

https://files.pythonhosted.org/packages/56/79/12978b96bd44274fe38b5dde5cfb660b1d114f70a65ef962bcbbed99b549/nvidia_cusparselt_cu12-0.7.1-py3-none-manylinux2014_x86_64.whl

rog: /home/qian-qi/work/hepta-e2-wheel-transfer-20261121-ac5459/wheels/nvidia_cusparselt_cu12-0.7.1-py3-none-manylinux2014_x86_64.whl

## 仍缺的目录信息

上述是 5 个核心包加 Torch 的 23 个直接必需依赖，共 28 个已知包位。它不包含尚未展开的 Transformers、Tokenizers、Safetensors、PEFT 传递依赖闭包。Torch 的三个 optional extras 不在本次默认环境里。

缺少官方 size/SHA 的 17 个已知包位：transformers, tokenizers, safetensors, peft, filelock, typing-extensions, setuptools, sympy, networkx, jinja2, fsspec, nvidia-nccl-cu12, nvidia-nvshmem-cu12, nvidia-nvtx-cu12, nvidia-nvjitlink-cu12, nvidia-cufile-cu12, triton.

NCCL 的 322,348,229 是旧截止留存文件的 stat 大小；现有证据没有它的官方精确 size 或官方 SHA，因此不能把它算为已完整校验。nvshmem 仅留存 38,901,760 字节；pip 的 124.7 MB 是四舍五入显示，不能用来计算精确缺口。ROG 失败的 NCCL 5.8 MB 没有本证据集中的可定位留存文件，不能额外计入可复用覆盖。
