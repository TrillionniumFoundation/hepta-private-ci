"""One bounded static inventory; no framework imports or runtime mutation."""
import concurrent.futures
import hashlib
import json
import subprocess
import sys
import time

HOST_SCANNER = r'''
import csv
import email.parser
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import time
import zipfile

cfg=json.loads(sys.stdin.readline())
deadline=cfg['scan_deadline_unix']
pins={'torch':'2.9.1+cu128','transformers':'4.57.3','tokenizers':'0.22.2','safetensors':'0.7.0','peft':'0.18.0'}
module_pins={'torch/utils/checkpoint.py':'431b229da53972d79bed7e5dbfb6ace2922fff30192ea103208f484e59490f23','transformers/masking_utils.py':'7a963feed8173b8265298dd24350c166222ce6b4719442fce48ab414d0478a6a','transformers/models/qwen2/modeling_qwen2.py':'08742a7c82a8713bc22f632f01c97b7eca3ef0e947180e7d6c9beec4897c4ff8'}
result={'host':cfg['host'],'scanner_pid':os.getpid(),'started_at_ns':time.time_ns(),'scope':'static_metadata_only','framework_imports':0,'cuda_calls':0,'installs':0,'downloads':0,'material_copies':0,'model_calls':0,'optimizer_updates':0,'roots':[],'distributions':[],'wheels':[],'python_configs':[],'errors':[],'bounds_hit':[],'site_candidates':[]}
visited=set(); metadata_paths=[];wheel_paths=[];body_paths=[];cfg_paths=[];entries=0
def check():
 if time.time()>=deadline:raise TimeoutError('shared static scan deadline')
def small(path,limit=1048576):
 check()
 if path.stat().st_size>limit:raise ValueError('metadata size bound')
 return path.read_bytes()
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):
   check();h.update(b)
 return h.hexdigest()
def note_error(path,error):
 if len(result['errors'])<12:result['errors'].append({'path':str(path),'type':type(error).__name__,'detail':str(error)[:220]})
def core_filename(name):
 value=name.lower().replace('_','-')
 return next((p for p in pins if value.startswith(p+'-')),None)
try:
 for text in cfg['roots']:
  check();root=Path(text)
  try:
   info=root.stat()
  except FileNotFoundError:
   result['roots'].append({'path':text,'exists':False});continue
  except OSError as e:
   note_error(root,e);continue
  root_row={'path':text,'exists':True,'is_directory':stat.S_ISDIR(info.st_mode)}
  if root.is_file():
   with root.open('rb') as stream:header=stream.read(64)
   root_row.update({'bytes':info.st_size,'resolved_path':str(root.resolve()),'elf':header[:4]==b'\x7fELF','sha256':sha(root) if info.st_size<50000000 else None})
   if header[:4]==b'\x7fELF' and len(header)>=20:root_row['elf_machine']=int.from_bytes(header[18:20],'little' if header[5]==1 else 'big')
  result['roots'].append(root_row)
  if not root.is_dir():continue
  for current,dirs,files in os.walk(root,followlinks=False):
   check();p=Path(current);depth=len(p.parts)-len(root.parts)
   if depth>7:
    dirs[:]=[];continue
   if len(visited)>=7000 or entries>=60000:
    result['bounds_hit'].append('directory_or_entry_cap');dirs[:]=[];break
   try:identity=(p.stat().st_dev,p.stat().st_ino)
   except OSError as e:note_error(p,e);dirs[:]=[];continue
   if identity in visited:dirs[:]=[];continue
   visited.add(identity);entries+=len(dirs)+len(files)
   keep=[]
   for name in dirs:
    if name.endswith('.dist-info'):
     if core_filename(name) and len(metadata_paths)<64:metadata_paths.append(p/name)
     continue
    if name in {'__pycache__','.git','node_modules','include','share','man','doc','docs','test','tests','test_data','target','torch','transformers','tokenizers','safetensors','peft','numpy','scipy','nvidia','triton'}:continue
    if name.endswith('.data'):continue
    keep.append(name)
   dirs[:]=keep
   if 'pyvenv.cfg' in files and len(cfg_paths)<32:cfg_paths.append(p/'pyvenv.cfg')
   for name in files:
    if name.endswith('.whl') and core_filename(name):
     if len(wheel_paths)<48:wheel_paths.append(p/name)
    elif name.endswith('.body') and len(body_paths)<120:
     try:
      size=(p/name).stat().st_size
      if size==900881648 or 250000<=size<=35000000:body_paths.append((size,p/name))
     except OSError as e:note_error(p/name,e)
 for path in cfg_paths:
  try:
   raw=small(path,8192);fields={}
   for line in raw.decode(errors='replace').splitlines():
    if '=' in line:
     k,v=line.split('=',1)
     if k.strip() in ['version','version_info','home','executable','base-executable','include-system-site-packages']:fields[k.strip()]=v.strip()
   result['python_configs'].append({'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'fields':fields})
  except (OSError,ValueError) as e:note_error(path,e)
 sites={}
 for folder in metadata_paths:
  check()
  try:
   raw=small(folder/'METADATA');m=email.parser.BytesParser().parsebytes(raw)
   name=m['Name'].lower().replace('_','-');version=m['Version']
   if name not in pins:continue
   wheel=small(folder/'WHEEL',65536) if (folder/'WHEEL').is_file() else b''
   record=small(folder/'RECORD',2097152) if (folder/'RECORD').is_file() else b''
   missing=[];count=0;external=0
   site=folder.parent
   boundary=site
   if site.name in ['site-packages','dist-packages'] and site.parent.name.startswith('python3.'):
    boundary=site.parent.parent.parent
   for row in csv.reader(io.StringIO(record.decode())):
    check();count+=1
    if count>24000:raise ValueError('RECORD entry bound')
    candidate=(site/row[0]).resolve()
    if not candidate.is_relative_to(boundary.resolve()):external+=1;continue
    if not candidate.is_file() and len(missing)<12:missing.append(row[0])
   modules=[]
   for relative,expected in module_pins.items():
    if relative.startswith(name+'/'):
     target=site/relative
     if target.is_file():
      actual=sha(target);modules.append({'path':str(target),'sha256':actual,'expected_sha256':expected,'matches':actual==expected})
     else:modules.append({'path':str(target),'exists':False,'matches':False})
   row={'name':name,'version':version,'expected_version':pins[name],'version_matches':version==pins[name],'metadata_path':str(folder/'METADATA'),'metadata_sha256':hashlib.sha256(raw).hexdigest(),'requires_python':m.get('Requires-Python'),'requires_dist':m.get_all('Requires-Dist',[])[:36],'requires_dist_total':len(m.get_all('Requires-Dist',[])),'wheel_tags':[x[5:].strip() for x in wheel.decode().splitlines() if x.startswith('Tag:')],'record_sha256':hashlib.sha256(record).hexdigest() if record else None,'record_entries':count,'missing_record_files_sample':missing,'external_record_entries_unchecked':external,'qualified_runtime_modules':modules}
   result['distributions'].append(row);sites.setdefault(str(site),{})[name]=row
  except (OSError,ValueError,UnicodeError) as e:note_error(folder,e)
 for site,ds in sites.items():
  exact={name:ds[name]['version'] for name in pins if name in ds and ds[name]['version_matches']}
  result['site_candidates'].append({'site':site,'exact_core_versions':exact,'all_five_core_versions_present':len(exact)==5,'critical_modules_match':all(item['matches'] for d in ds.values() for item in d['qualified_runtime_modules']) and 'torch' in ds and 'transformers' in ds,'all_core_records_present_without_observed_missing_files':len(exact)==5 and all(d['record_sha256'] is not None and not d['missing_record_files_sample'] for d in ds.values()),'complete_transitive_dependency_closure_verified':False})
 bodies=sorted(body_paths,key=lambda x:(x[0]!=900881648,-x[0]))[:40]
 for path in [*wheel_paths,*[p for _,p in bodies]]:
  check()
  if len(result['wheels'])>=24:result['bounds_hit'].append('wheel_result_cap');break
  try:
   if not zipfile.is_zipfile(path):
    if path in wheel_paths:result['wheels'].append({'path':str(path),'bytes':path.stat().st_size,'complete_zip':False})
    continue
   with zipfile.ZipFile(path) as archive:
    names=archive.namelist()
    metadata=next((n for n in names if n.endswith('.dist-info/METADATA') and core_filename(n.rsplit('/',1)[0])),None)
    if metadata is None:continue
    if archive.getinfo(metadata).file_size>1048576:raise ValueError('wheel metadata bound')
    m=email.parser.BytesParser().parsebytes(archive.read(metadata));name=m['Name'].lower().replace('_','-')
    if name not in pins:continue
    version=m['Version'];tagpath=metadata.rsplit('/',1)[0]+'/WHEEL'
    tagdata=archive.read(tagpath).decode() if tagpath in names and archive.getinfo(tagpath).file_size<65536 else ''
    actual=sha(path) if version==pins[name] else None
    result['wheels'].append({'path':str(path),'bytes':path.stat().st_size,'complete_zip':True,'name':name,'version':version,'version_matches':version==pins[name],'sha256':actual,'tags':[x[5:].strip() for x in tagdata.splitlines() if x.startswith('Tag:')],'official_torch_sha_matches':actual=='7cb4018f4ce68b61fd3ef87dc1c4ca520731c7b5b200e360ad47b612d7844063' if name=='torch' and actual else None,'payload_crc_not_tested':True})
  except (OSError,ValueError,KeyError,zipfile.BadZipFile) as e:note_error(path,e)
 result['status']='STATIC_INVENTORY_COMPLETE_WITHIN_DECLARED_BOUNDS'
except TimeoutError as e:
 result['status']='BOUNDED_PARTIAL_INVENTORY';result['bounds_hit'].append(str(e))
except BaseException as e:
 result['status']='STATIC_INVENTORY_FAILED';note_error(cfg['host'],e)
result['visited_directories']=len(visited);result['directory_entries_seen']=entries
result['wheel_body_candidates_seen']=len(body_paths);result['wheel_body_candidates_examined_max']=40
result['ended_at_ns']=time.time_ns()
result['closure_qualification']='NOT_PROVEN; static metadata does not import or execute the framework and does not establish CUDA readiness'
encoded=json.dumps(result,sort_keys=True)
if len(encoded.encode())>28000:
 for row in result['distributions']:row.pop('requires_dist',None)
 result['bounds_hit'].append('requires_dist_text_omitted_for_output_bound');encoded=json.dumps(result,sort_keys=True)
if len(encoded.encode())>32000:
 result={'host':cfg['host'],'status':'OUTPUT_BOUND_EXCEEDED','bounds_hit':['32000_bytes'],'framework_imports':0,'cuda_calls':0,'installs':0,'downloads':0,'material_copies':0,'model_calls':0,'optimizer_updates':0}
print(encoded,flush=True)
'''


def roots(home, host):
    values = [home + '/.local/share/uv/python',
              home + '/.local/lib/python3.12', home + '/.venvs', home + '/venvs',
              home + '/miniconda3', home + '/mambaforge', '/opt/conda',
              '/usr/lib/python3.12', '/usr/local/lib/python3.12', '/usr/lib/python3/dist-packages']
    specific = []
    if host == 'rog':
        specific = ['/home/qian-qi/work/hepta-e2-wheel-transfer-20261121-ac5459',
                   '/home/qian-qi/work/hepta-e16-ac5459-20261121/.venv',
                   '/home/qian-qi/work/hepta-e16-ac5459-20261121/venv']
    elif host == 'desktop':
        specific = ['/home/qian-qi/work/hepta-current-student-correction-20261121-ac5459/runtime-recovery',
                   '/home/qian-qi/hepta-cell-experiments-v3-20261116-0c078a/venv',
                   '/home/qian-qi/work/hepta-upstream-raw-function-learning-20261119-2e9b/venv',
                   '/home/qian-qi/work/hepta-upstream-raw-function-learning-20261119-2e9b/.venv']
    else:
        specific = ['/home/qq/hepta-learn-ff41-tools/python',
                   '/home/qq/hepta-learn-ff41-tools/lib/python3.12',
                   '/home/qq/hepta-learn-ff41-tools/.venv',
                   '/home/qq/hepta-learn-ff41-tools/venv',
                   '/home/qq/work/hepta-e16-ac5459-20261121/.venv',
                   '/home/qq/work/hepta-e16-ac5459-20261121/venv']
    return specific + values + [home + '/.cache/pip', home + '/.cache/uv']


def main():
    started = time.time()
    hard_deadline = started + 180
    plan = {'schema': 'hepta.runtime-static-inventory.v1', 'scope': 'new independent read-only 180-second inventory; does not extend original recovery',
            'started_at_unix': started, 'deadline_unix': hard_deadline,
            'metadata_scan_deadline_unix': started + 165, 'max_result_bytes_per_host': 32000,
            'hosts': ['rog', 'desktop', 'ai395'], 'framework_imports': 0, 'cuda_calls': 0,
            'installs': 0, 'downloads': 0, 'material_copies': 0, 'model_calls': 0, 'optimizer_updates': 0}
    print('READ_ONLY_INVENTORY_CLAIM ' + json.dumps(plan, sort_keys=True), flush=True)

    def inspect(host):
        home = '/home/qq' if host == 'ai395' else '/home/qian-qi'
        cfg = {'host': host, 'roots': roots(home, host), 'scan_deadline_unix': started + 165}
        script = 'import sys,io\nsys.stdin=io.StringIO(' + repr(json.dumps(cfg) + '\n') + ')\n' + HOST_SCANNER
        argv = [sys.executable, '-I', '-S', '-B', '-'] if host == 'rog' else [
            'ssh', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=5', host,
            'python3 -I -S -B -']
        began = time.time()
        child = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            stdout, stderr = child.communicate(script, timeout=max(1, hard_deadline - time.time() - 3))
            result = json.loads(stdout) if child.returncode == 0 else {'status': 'READ_CONNECTION_OR_SCANNER_FAILED', 'stderr': stderr[-1200:]}
            return {'host': host, 'returncode': child.returncode, 'wall_seconds': time.time() - began, 'inventory': result}
        except subprocess.TimeoutExpired:
            child.terminate()
            try:
                stdout, stderr = child.communicate(timeout=1)
            except subprocess.TimeoutExpired:
                child.kill();stdout, stderr = child.communicate(timeout=1)
            return {'host': host, 'status': 'READ_SUPERVISOR_TIMEOUT', 'local_child_exit': child.returncode,
                    'remote_readonly_process_terminal_unconfirmed': host != 'rog', 'stdout_prefix': stdout[:800],
                    'wall_seconds': time.time() - began}

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        futures = {executor.submit(inspect, host): host for host in plan['hosts']}
        results = []
        for future in concurrent.futures.as_completed(futures):
            try:
                result = future.result()
            except BaseException as error:
                result = {'host': futures[future], 'status': 'OBSERVER_FAILED', 'error': str(error)[:600]}
            results.append(result)
            print('HOST_INVENTORY ' + json.dumps(result, sort_keys=True), flush=True)
    print('READ_ONLY_INVENTORY_TERMINAL ' + json.dumps({'status': 'FINISHED_READ_ONLY_SCOPE',
          'elapsed_seconds': time.time() - started, 'deadline_unix': hard_deadline,
          'complete_host_results': len(results), 'runtime_usable_claim': False,
          'automatic_followup_execution': False, 'optimizer_updates': 0}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
