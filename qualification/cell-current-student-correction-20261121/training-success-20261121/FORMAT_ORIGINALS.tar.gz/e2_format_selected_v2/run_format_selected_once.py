import base64
import gzip
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


payload = Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(payload).hexdigest() == sys.argv[2]
plan = json.loads(gzip.decompress(payload))
owner = Path(plan['owner'])
owner.mkdir(exist_ok=False)
source = owner / 'source'
started = time.monotonic()
records = []
result = {'status': 'STARTED', 'science_calls': 0, 'format_calls': 0}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(name, raw):
    path = owner / name
    with path.open('xb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2) + '\n').encode()


def command(label, argv, cwd, seconds, required=True):
    remaining = 180 - (time.monotonic() - started)
    if remaining <= 0:
        raise TimeoutError('setup and format owner deadline')
    bound = min(seconds, remaining)
    before = time.monotonic()
    timed_out = False
    with (owner / (label + '.stdout')).open('xb') as stdout, (owner / (label + '.stderr')).open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=cwd, env=plan['environment'], stdin=subprocess.DEVNULL,
                                 stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = child.wait(timeout=bound)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait(timeout=10)
        stdout.flush()
        stderr.flush()
        os.fsync(stdout.fileno())
        os.fsync(stderr.fileno())
    row = {'label': label, 'argv': argv, 'cwd': str(cwd), 'limit_seconds': bound,
           'returncode': code, 'timed_out': timed_out, 'wall_seconds': time.monotonic() - before,
           'direct_child_waited': True}
    for channel in ('stdout', 'stderr'):
        raw = (owner / (label + '.' + channel)).read_bytes()
        row[channel] = {'bytes': len(raw), 'sha256': sha(raw)}
    records.append(row)
    write(label + '.json', canonical(row))
    if required and (code != 0 or timed_out):
        raise RuntimeError(label + ': exit=' + str(code) + ', timed_out=' + str(timed_out))
    return code, (owner / (label + '.stdout')).read_bytes()


def file_hashes(paths):
    return {name: {'bytes': len(raw), 'sha256': sha(raw)}
            for name in paths for raw in [(source / name).read_bytes()]}


write('PLAN.json', canonical(plan))
try:
    if sha(Path(plan['format_executable']).read_bytes()) != plan['format_tool_sha256']:
        raise RuntimeError('just identity changed')
    command('01-clone', ['git', 'clone', '--shared', '--no-checkout', plan['clone_source'], str(source)], owner, 30)
    command('02-checkout', ['git', 'checkout', '--detach', plan['checkout_head']], source, 30)
    _, head = command('03-head', ['git', 'rev-parse', 'HEAD'], source, 10)
    if head.decode().strip() != plan['checkout_head']:
        raise RuntimeError('unexpected existing object checkout')
    _, clean = command('04-status-clean', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], source, 10)
    if clean:
        raise RuntimeError('new selected-source checkout not clean')
    for item in plan['format_sources']:
        raw = (source / item['path']).read_bytes()
        if len(raw) != item['bytes'] or sha(raw) != item['sha256']:
            raise RuntimeError('existing formatter source is not exact4778: ' + item['path'])
    for item in plan['files']:
        name = item['path']
        if not name.startswith('qualification/cell-current-student-correction-20261121/training-document-envelope-20261121/') or '..' in Path(name).parts:
            raise RuntimeError('materialization scope escaped')
        raw = base64.b64decode(item['base64'], validate=True)
        if len(raw) != item['bytes'] or sha(raw) != item['sha256']:
            raise RuntimeError('selected original file differs')
        target = source / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as f:
            f.write(raw)
            f.flush()
            os.fsync(f.fileno())
    _, before_status = command('05-status-before', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], source, 10)
    _, changed = command('06-untracked', ['git', 'ls-files', '--others', '--exclude-standard'], source, 10)
    if set(changed.decode().splitlines()) != set(plan['changed_paths']):
        raise RuntimeError('selected nine-path scope differs')
    before = file_hashes(plan['changed_paths'])
    write('FILES_BEFORE.json', canonical(before))
    result['format_calls'] = 1
    command('07-fmt', [plan['format_executable'], 'fmt', '--base', plan['checkout_head']], source / 'codex-rs', 30)
    after = file_hashes(plan['changed_paths'])
    write('FILES_AFTER.json', canonical(after))
    _, after_status = command('08-status-after', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], source, 10)
    result['files_unchanged'] = before == after
    result['status_unchanged'] = before_status == after_status
    result['just_identity_unchanged'] = sha(Path(plan['format_executable']).read_bytes()) == plan['format_tool_sha256']
    if not all(result[k] for k in ('files_unchanged', 'status_unchanged', 'just_identity_unchanged')):
        raise RuntimeError('unexpected post-format change; retained, not applied to active source')
    result['status'] = 'FORMAT_COMMAND_COMPLETE_PENDING_H_TERMINAL'
    result['error'] = None
except BaseException as error:
    result['status'] = 'FAILED'
    result['error'] = repr(error)
finally:
    result['records'] = records
    result['wall_seconds'] = time.monotonic() - started
    result['selected_source_commit'] = plan['commit']
    result['checkout_head'] = plan['checkout_head']
    result['complete_exact4778_checkout'] = False
    result['published_change_base'] = plan['base']
    result['format_command_base'] = plan['checkout_head']
    result['registry_limit'] = plan['registry_limit']
    result['automatic_retry'] = False
    result['prior_format_not_reused_as_validation'] = True
    receipt = write('RESULT.json', canonical(result))
    fd = os.open(owner, os.O_RDONLY | os.O_DIRECTORY)
    os.fsync(fd)
    os.close(fd)
    print(json.dumps({'result': receipt, 'status': result['status'], 'automatic_retry': False}), flush=True)
sys.exit(0 if result['status'] == 'FORMAT_COMMAND_COMPLETE_PENDING_H_TERMINAL' else 1)
