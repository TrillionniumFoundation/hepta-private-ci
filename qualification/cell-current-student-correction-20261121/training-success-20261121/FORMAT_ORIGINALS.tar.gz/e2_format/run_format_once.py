import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


plan = json.loads(sys.stdin.read())
owner = Path(plan['owner'])
owner.mkdir(exist_ok=False)
source = owner / 'source'
started = time.monotonic()
records = []
result = {'status': 'STARTED', 'science_calls': 0, 'format_calls': 0}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(name, raw):
    path = owner / name
    with path.open('xb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2) + '\n').encode()


def command(label, argv, cwd, seconds, required=True):
    remaining = 180 - (time.monotonic() - started)
    if remaining <= 0:
        raise TimeoutError('setup and format owner deadline')
    bound = min(seconds, remaining)
    before = time.monotonic()
    timed_out = False
    with (owner / (label + '.stdout')).open('xb') as stdout, (owner / (label + '.stderr')).open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=cwd, env=plan['environment'], stdin=subprocess.DEVNULL,
                                 stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = child.wait(timeout=bound)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait(timeout=10)
        stdout.flush()
        stderr.flush()
        os.fsync(stdout.fileno())
        os.fsync(stderr.fileno())
    row = {'label': label, 'argv': argv, 'cwd': str(cwd), 'limit_seconds': bound,
           'returncode': code, 'timed_out': timed_out, 'wall_seconds': time.monotonic() - before,
           'direct_child_waited': True}
    for channel in ('stdout', 'stderr'):
        raw = (owner / (label + '.' + channel)).read_bytes()
        row[channel] = {'bytes': len(raw), 'sha256': sha(raw)}
    records.append(row)
    write(label + '.json', canonical(row))
    if required and (code != 0 or timed_out):
        raise RuntimeError(label + ': exit=' + str(code) + ', timed_out=' + str(timed_out))
    return code, (owner / (label + '.stdout')).read_bytes()


def file_hashes(paths):
    return {name: {'bytes': len(raw), 'sha256': sha(raw)}
            for name in paths for raw in [(source / name).read_bytes()]}


write('PLAN.json', canonical(plan))
try:
    tool = Path(plan['format_executable']).read_bytes()
    if sha(tool) != plan['format_tool_sha256']:
        raise RuntimeError('just identity changed')
    command('01-clone', ['git', 'clone', '--shared', '--no-checkout', plan['clone_source'], str(source)], owner, 30)
    missing = []
    for index, commit in enumerate((plan['commit'], plan['base'])):
        code, _ = command('02-object-' + str(index), ['git', 'cat-file', '-e', commit + '^{commit}'], source, 10, False)
        if code:
            missing.append(commit)
    if missing:
        command('03-fetch', ['git', 'fetch', '--no-tags', 'https://github.com/TrillionniumFoundation/hepta-private-ci.git', plan['commit']], source, 75)
    for index, commit in enumerate((plan['commit'], plan['base'])):
        command('04-confirm-object-' + str(index), ['git', 'cat-file', '-e', commit + '^{commit}'], source, 10)
    command('05-checkout', ['git', 'checkout', '--detach', plan['commit']], source, 30)
    _, head = command('06-head', ['git', 'rev-parse', 'HEAD'], source, 10)
    if head.decode().strip() != plan['commit']:
        raise RuntimeError('unexpected checkout head')
    _, status = command('07-status-before', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], source, 10)
    if status:
        raise RuntimeError('new checkout is not clean')
    _, paths_raw = command('08-changed-paths', ['git', 'diff', '--name-only', '--no-renames', plan['base'], plan['commit'], '--'], source, 10)
    if set(paths_raw.decode().splitlines()) != set(plan['changed_paths']):
        raise RuntimeError('changed file scope differs')
    for item in plan['format_sources']:
        raw = (source / item['path']).read_bytes()
        if len(raw) != item['bytes'] or sha(raw) != item['sha256']:
            raise RuntimeError('format entry source differs: ' + item['path'])
    before = file_hashes(plan['changed_paths'])
    write('FILES_BEFORE.json', canonical(before))
    result['format_calls'] = 1
    command('09-fmt', [plan['format_executable'], 'fmt', '--base', plan['base']], source / 'codex-rs', 30)
    after = file_hashes(plan['changed_paths'])
    write('FILES_AFTER.json', canonical(after))
    _, after_status = command('10-status-after', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], source, 10)
    result['files_unchanged'] = before == after
    result['clean_after'] = not after_status
    result['just_identity_unchanged'] = sha(Path(plan['format_executable']).read_bytes()) == plan['format_tool_sha256']
    if not all(result[k] for k in ('files_unchanged', 'clean_after', 'just_identity_unchanged')):
        raise RuntimeError('unexpected post-format change; retained, not applied to active source')
    result['status'] = 'FORMAT_COMMAND_COMPLETE_PENDING_H_TERMINAL'
    result['error'] = None
except BaseException as error:
    result['status'] = 'FAILED'
    result['error'] = repr(error)
finally:
    result['records'] = records
    result['wall_seconds'] = time.monotonic() - started
    result['commit'] = plan['commit']
    result['base'] = plan['base']
    result['registry_limit'] = plan['registry_limit']
    result['automatic_retry'] = False
    result['prior_format_not_reused_as_validation'] = True
    receipt = write('RESULT.json', canonical(result))
    fd = os.open(owner, os.O_RDONLY | os.O_DIRECTORY)
    os.fsync(fd)
    os.close(fd)
    print(json.dumps({'result': receipt, 'status': result['status'], 'automatic_retry': False}), flush=True)
sys.exit(0 if result['status'] == 'FORMAT_COMMAND_COMPLETE_PENDING_H_TERMINAL' else 1)
