import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import time

root = Path('/tmp/hepta-pft-binary-cache-6523704f97df')
source = root / 'source'
run = root / 'runs/attempt-1'
budget = root / 'runs/BUDGET.json'
assert not budget.exists(), 'The first attempt must not reset an existing budget'
run.mkdir(parents=True, exist_ok=False)
q = source / 'qualification/hcsn_closure_20261124'
names = ['pft_binary_cache_network.py','pft_cache_network.py','pft_online_peer.py','pft_binary_peer.py','pft_statistics.py','pft_linear.py','pft_statistics_codec.py']
hashes, blobs = {}, {}
for name in names:
    raw = (q / name).read_bytes()
    hashes[name] = hashlib.sha256(raw).hexdigest()
    blobs[name] = hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()
    dest = run / 'executed-source' / name
    dest.parent.mkdir(exist_ok=True)
    dest.write_bytes(raw)
for name in ['pft_cache_network/INPUTS.json','pft_binary_cache_network/PROTOCOL.md','pft_binary_cache_network/DEPENDENCIES.json']:
    dest = run / 'registered-inputs' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(q / name, dest)
shutil.copyfile(__file__, run / 'supervisor.py')
command = ['python','-m','qualification.hcsn_closure_20261124.pft_binary_cache_network','--fixture-root','/tmp/hepta-learning-6523704f97df','--output',str(run / 'qualification'),'--budget',str(budget)]
frozen = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_commit='1149fa3a5aea9da81030d9c70ab42e9625fa31b8', protocol_commit='93a854807b5883b9bac987498977f81277d9081a', base_commit='db152bb76d77ecdc6cc6d10747574471ef183b8e', sha256=hashes, git_blobs=blobs, command=command, whole_process_group_timeout_seconds=600, threads=dict(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
(run / 'RUN_FROZEN.json').write_text(json.dumps(frozen, indent=2) + '\n')
env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
started = time.monotonic()
before = resource.getrusage(resource.RUSAGE_CHILDREN)
with (run / 'run.log').open('xb') as log:
    child = subprocess.Popen(command, cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    timed_out = False
    try:
        returncode = child.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(child.pid, signal.SIGKILL)
        returncode = child.wait()
after = resource.getrusage(resource.RUSAGE_CHILDREN)
receipt = dict(returncode=returncode, pid=child.pid, timed_out=timed_out, seconds=time.monotonic()-started, user_cpu_seconds=after.ru_utime-before.ru_utime, system_cpu_seconds=after.ru_stime-before.ru_stime, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(run / 'OUTER_RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
