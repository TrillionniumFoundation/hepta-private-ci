import datetime
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import time

root = Path('/tmp/hepta-pft-ci-admission-6523704f97df')
run = root / 'runs/local-attempt-1'
run.mkdir(parents=True, exist_ok=False)
capsule = json.loads((root / 'LOCAL_CAPSULE.json').read_text())
shutil.copyfile(root / 'LOCAL_CAPSULE.json', run / 'LOCAL_CAPSULE.json')
shutil.copyfile(root / 'DEPENDENCIES.json', run / 'DEPENDENCIES.json')
shutil.copyfile(__file__, run / 'SUPERVISOR.py')
command = ['timeout', '--signal=TERM', '--kill-after=5s', '120s', 'python', '-m',
    'qualification.hcsn_closure_20261124.pft_online_regression', '--output',
    str(run / 'tests'), '--expected-head', capsule['local_capsule_head'],
    '--expected-python', '3.12.14']
frozen = dict(protocol_commit='80eeaf44191cfddedad93329308817eb84226216',
    source_commit='c1366672bdef9bcb534ea52996ecd186244c1f8b', command=command,
    local_capsule=capsule, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    hosted_ci_result=False, runtime_closure_complete=False, original_science_budget_used=False)
(run / 'RUN_FROZEN.json').write_text(json.dumps(frozen, indent=2)+'\n')
env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1',
    MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0',
    PFT_FORMAT_BASE=capsule['local_formatter_baseline'])
for key in ['GITHUB_ACTIONS', 'GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT', 'GITHUB_EVENT_NAME', 'GITHUB_SHA']:
    env.pop(key, None)
started = time.monotonic()
before = resource.getrusage(resource.RUSAGE_CHILDREN)
with (run / 'DRIVER.log').open('xb') as log:
    child = subprocess.Popen(command, cwd=root/'source', env=env, stdout=log,
        stderr=subprocess.STDOUT, start_new_session=True)
    outer_timeout = False
    try:
        returncode = child.wait(timeout=130)
    except subprocess.TimeoutExpired:
        outer_timeout = True
        os.killpg(child.pid, signal.SIGKILL)
        returncode = child.wait()
after = resource.getrusage(resource.RUSAGE_CHILDREN)
receipt = dict(returncode=returncode, pid=child.pid, outer_timeout=outer_timeout,
    seconds=time.monotonic()-started, user_cpu_seconds=after.ru_utime-before.ru_utime,
    system_cpu_seconds=after.ru_stime-before.ru_stime, hosted_ci_result=False,
    finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(run / 'OUTER_RECEIPT.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
