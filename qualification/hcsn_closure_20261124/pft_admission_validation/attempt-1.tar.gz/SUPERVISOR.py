import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import time

root = Path('/tmp/hepta-pft-validation-6523704f97df')
run = root / 'runs/attempt-1'
budget_path = root / 'runs/BUDGET.json'
assert not budget_path.exists(), 'Do not reset an existing scope budget'
run.mkdir(parents=True, exist_ok=False)
started = time.monotonic()
q = 'qualification/hcsn_closure_20261124/'
manifest = json.loads((root / 'source' / q / 'pft_admission_validation/BASELINE.json').read_text())
names = [entry['path'] for entry in manifest['source']] + [q + 'pft_admission_validation_tests.py']
identities = {}
for phase, source in [('baseline',root/'baseline'),('candidate',root/'source')]:
    identities[phase] = {}
    for name in names:
        raw = (source / name).read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        identities[phase][name] = digest
        target = run / ('executed-' + phase) / name
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(raw)
    if phase == 'baseline':
        for entry in manifest['source']:
            assert identities[phase][entry['path']] == entry['sha256']
assert identities['baseline'][names[-1]] == identities['candidate'][names[-1]]
for name in ['PROTOCOL.md','BASELINE.json']:
    shutil.copyfile(root/'source'/q/'pft_admission_validation'/name,run/name)
shutil.copyfile(__file__,run/'SUPERVISOR.py')
frozen = dict(protocol_commit='3559730592d9d3b8fa1f87aa4084e7cebcb2f854',source_commit='24bab56ad9ce7f1158a35b7e2668cb0a0ff68010',baseline_commit=manifest['base_commit'],sha256=identities,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase_caps=dict(baseline=20,candidate=60),total_cap_seconds=90,threads=dict(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
(run/'RUN_FROZEN.json').write_text(json.dumps(frozen,indent=2)+'\n')
budget = dict(schema='pft-admission-validation-budget-v1',protocol_commit=frozen['protocol_commit'],limit_seconds=90,attempts=[dict(source_commit=frozen['source_commit'],phases=[])])
env = dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def save_budget():
    temporary = budget_path.with_suffix('.pending')
    temporary.write_text(json.dumps(budget,indent=2)+'\n')
    os.replace(temporary,budget_path)
save_budget()
for phase, source, cap in [('baseline',root/'baseline',20),('candidate',root/'source',60)]:
    allowance = min(cap,90-(time.monotonic()-started))
    assert allowance > 0
    command = ['python','-m','qualification.hcsn_closure_20261124.pft_admission_validation_tests','--phase',phase,'--output',str(run/(phase+'.json'))]
    if phase == 'candidate':
        command += ['--baseline',str(run/'baseline.json')]
    entry = dict(phase=phase,command=command,reserved_seconds=allowance,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    budget['attempts'][0]['phases'].append(entry)
    save_budget()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    phase_started = time.monotonic()
    with (run/(phase+'.log')).open('xb') as log:
        child = subprocess.Popen(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        timed_out = False
        try:
            returncode = child.wait(timeout=allowance)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid,signal.SIGKILL)
            returncode = child.wait()
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    entry.update(returncode=returncode,pid=child.pid,timed_out=timed_out,elapsed_seconds=time.monotonic()-phase_started,user_cpu_seconds=after.ru_utime-before.ru_utime,system_cpu_seconds=after.ru_stime-before.ru_stime)
    save_budget()
    print(json.dumps(entry),flush=True)
    if returncode or timed_out:
        break
budget['attempts'][0]['elapsed_seconds'] = time.monotonic()-started
save_budget()
shutil.copyfile(budget_path,run/'FINAL_BUDGET.json')
print(json.dumps(dict(total_seconds=budget['attempts'][0]['elapsed_seconds'],phases_completed=len(budget['attempts'][0]['phases']))))
