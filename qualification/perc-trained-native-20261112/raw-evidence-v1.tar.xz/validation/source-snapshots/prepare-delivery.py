"""Create-only packaging of completed historical PERC native qualification.

Run on the validation host after final execution. No inference, source edits,
metric repair, or promotion occurs here. Original failed attempts are preserved.
"""

import hashlib
import json
import math
from pathlib import Path
import sys
import tarfile

BASE = Path('/home/qian-qi')
VALIDATION = BASE / 'perc-trained-native-validation-20261112-1c26'
BUILD_PREFIX = 'perc-semantic-native-build-20261112-1c26-final-fmt-'
PARENT = 'a5583f0f4a12d9618a3a5bc5ed0e7062a7463f39'
ARCHIVE_SOURCE = 'c57d32d04d3927a5457fec2e4d2a8a8840976df754e90b644b36f0ff414466cf'
PASS = 'PASS_HISTORICAL_HEAD_AND_OWNER_REPLAY_ONLY'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    require(path.is_file() and not path.is_symlink(), 'regular JSON required: ' + str(path))
    return json.loads(path.read_bytes())


def write_new(path, value):
    with path.open('xb') as stream:
        stream.write(canonical(value) + b'\n')


def regular_tree(root):
    require(root.is_dir() and not root.is_symlink(), 'regular input directory required: ' + str(root))
    result = []
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'refuse symlink in archive: ' + str(path))
        if path.is_dir():
            continue
        require(path.is_file(), 'refuse nonregular archive member: ' + str(path))
        result.append(path)
    return result


def prepare(repo):
    repo = Path(repo).resolve(strict=True)
    run = VALIDATION / 'run-v3'
    report = read_json(run / 'REPORT.json')
    rows = read_json(run / 'ROWS.json')
    sources = read_json(run / 'SOURCE_MANIFEST.json')
    tests = read_json(VALIDATION / 'TESTS_V4.json')
    build = read_json(BASE / (BUILD_PREFIX + 'v5') / 'build.json')
    target = repo / 'qualification/perc-trained-native-20261112'
    require(not target.exists(), 'delivery already exists; inspect instead of overwriting')
    require(report['engineering_status'] == PASS and report['scientific_status'] == 'HOLD'
            and report['adoption'] == 'NoUpdate', 'final run qualification gate failed')
    expected = {'historical_cases': 180, 'unique_historical_tasks': 30, 'models': 6,
                'new_confirmation_sources': 0, 'ranking_matches': 180,
                'cold_process_replays_without_new_inference': 180,
                'lost_ack_recoveries_without_new_inference': 6, 'expected_refusals': 2}
    require(all(type(report[k]) is int and report[k] == v for k, v in expected.items()),
            'final run denominator/recovery/refusal gate failed')
    require(report['candidate_identity_mapping_validated'] is True
            and report['source_unchanged'] is True
            and report['production_daemon_integrated'] is False
            and report['native_visual_encoder_exercised'] is False
            and report['new_training_performed'] is False
            and report['terminal_quality_gain_established'] is False,
            'final report identity/qualification boundary failed')
    require(tests['tests'] == 8 and tests['failures'] == tests['errors'] == tests['skips'] == 0
            and tests['passed'] is True, 'strict eight-test no-skip gate failed')
    require(tests['binary_sha256'] == report['native_binary_sha256'] == build['binary_sha256']
            and tests['probe_source_sha256'] == build['probe_source_sha256'],
            'test/run/build binary or source identity mismatch')
    require(build['source_ref'] == PARENT and build['sources_unchanged'] is True
            and type(build['returncode']) is int and build['returncode'] == 0,
            'build baseline/source gate failed')
    binary = BASE / (BUILD_PREFIX + 'v5') / 'target/debug/perc1-native-cell-probe'
    require(digest(binary.read_bytes()) == build['binary_sha256'], 'current binary changed')
    probe = (repo / 'scripts/perc1_semantic_native_probe.rs').read_text()
    marker = 'include!("perc1_semantic_native_model.rs");'
    require(probe.count(marker) == 1, 'native include marker changed')
    probe = probe.replace(marker, (repo / 'scripts/perc1_semantic_native_model.rs').read_text())
    require(digest(probe.encode()) == build['probe_source_sha256'], 'compiled native source differs')
    require(sources['archive_sha256'] == ARCHIVE_SOURCE
            and sources['historical_replay_only'] is True
            and sources['independent_new_sources'] == 0
            and sources['actual_task_counts'] == {'train': 60, 'dev': 20, 'confirmation': 30}
            and digest(canonical(sources)) == report['source_manifest_sha256'],
            'historical source manifest gate failed')
    for relative, expected_sha in report['source_pins'].items():
        path = repo / relative
        require(not Path(relative).is_absolute() and '..' not in Path(relative).parts
                and path.resolve(strict=True).is_relative_to(repo)
                and path.is_file() and not path.is_symlink()
                and digest(path.read_bytes()) == expected_sha,
                'current source pin mismatch: ' + relative)
    require(type(rows) is list and len(rows) == 180, 'row denominator changed')
    identities = {(r['task_id'], r['arm'], r['seed']) for r in rows}
    require(len(identities) == 180 and len({r['task_id'] for r in rows}) == 30,
            'duplicate/missing historical row identities')
    for arm in ('global', 'dense'):
        for seed in (1101, 2202, 3303):
            require(sum(r['arm'] == arm and r['seed'] == seed for r in rows) == 30,
                    'model-specific denominator changed')
    require(all(r['ranking_equal'] is True and r['replay_equal'] is True for r in rows),
            'row arithmetic/replay gate failed')
    require(all(type(r['sparse_cell_abstained']) is bool
                and (r['sparse_cell_selected_candidate'] is None) == r['sparse_cell_abstained']
                and type(r['native_cell_selected_candidate']) is str for r in rows),
            'row candidate/abstention mapping inconsistent')
    abstentions = sum(r['sparse_cell_abstained'] for r in rows)
    matches = sum(r['sparse_cell_selected_candidate'] == r['raw_mlp_top_candidate'] for r in rows)
    require(report['cell_abstentions'] == abstentions
            and report['sparse_cell_choice_matches_raw_mlp_top'] == matches
            and report['sparse_cell_choice_differs_from_raw_mlp_top'] == 180 - matches,
            'row/report sparse choice counts differ')
    worst = max(r['max_abs_logit_error'] for r in rows)
    require(math.isfinite(worst) and worst >= 0 and worst == report['max_abs_logit_error'],
            'row/report arithmetic error differs')
    classifications = {
        'schema': 'perc1.semantic-native-run-classification.v1',
        'run-v1': {'classification': 'FAILED_FP64_SELF_PARSE',
                   'scope': 'Original FP64 score self-parse failure; retained, not arithmetic qualification.'},
        'run-v2': {'classification': 'RAW_MATH_PASS_CELL_ID_COMPARISON_INVALID',
                   'scope': 'Raw arithmetic passed; old 0/180 Cell comparison used different candidate IDs. That metric is invalid and is not a negative policy result.'},
        'run-v3': {'classification': PASS,
                   'scope': 'Final candidate identity mapping validated; raw ranking and diagnostic sparse Cell decisions remain separate.'},
        'TESTS_V1': {'classification': 'FAILED_INITIAL_HEAD_CODE_SHA_SCHEMA',
                     'scope': 'Initial code_sha256 map-versus-string schema failure; original logs retained.'},
        'promotion': 'NoUpdate', 'new_training': False, 'new_sources': 0,
        'production_daemon_integrated': False,
    }
    write_new(VALIDATION / 'RUN_CLASSIFICATION.json', classifications)
    archive_inputs = [(p, 'validation/' + p.relative_to(VALIDATION).as_posix())
                      for p in regular_tree(VALIDATION)]
    for kind, versions in (('tests', range(1, 5)), ('run', range(1, 4))):
        for version in versions:
            path = BASE / f'perc-trained-native-{kind}-v{version}.log'
            require(path.is_file() and not path.is_symlink(), 'original log missing: ' + str(path))
            archive_inputs.append((path, 'logs/' + path.name))
    for version in range(2, 6):
        root = BASE / (BUILD_PREFIX + f'v{version}')
        for relative in ('build.json', 'Cargo.toml', 'Cargo.lock', 'src/main.rs'):
            path = root / relative
            require(path.is_file() and not path.is_symlink(), 'build snapshot missing: ' + str(path))
            archive_inputs.append((path, f'builds/final-fmt-v{version}/' + relative))
    inventory = []
    for path, name in archive_inputs:
        raw = path.read_bytes()
        require(len(raw) < 64 or (raw[:4] != b'\x7fELF' and raw[:2] != b'MZ'),
                'native executable forbidden in evidence archive')
        inventory.append({'path': name, 'bytes': len(raw), 'sha256': digest(raw)})
    require(len({r['path'] for r in inventory}) == len(inventory), 'duplicate archive path')
    target.mkdir(parents=True)
    for name, value in (('REPORT.json', report), ('ROWS.json', rows), ('TESTS.json', tests),
                        ('SOURCE_MANIFEST.json', sources), ('RUN_CLASSIFICATION.json', classifications)):
        write_new(target / name, value)
    write_new(target / 'RAW_FILE_MANIFEST.json', {'schema': 'perc1.raw-delivery-manifest.v1',
                                               'files': inventory})
    archive = target / 'raw-evidence-v1.tar.xz'
    with archive.open('xb') as output:
        with tarfile.open(fileobj=output, mode='w:xz', preset=6) as bundle:
            for path, name in archive_inputs:
                bundle.add(path, arcname=name, recursive=False)
            bundle.add(target / 'RAW_FILE_MANIFEST.json', arcname='RAW_FILE_MANIFEST.json', recursive=False)
    with tarfile.open(archive, mode='r:xz') as bundle:
        members = bundle.getmembers()
        require(len(members) == len(inventory) + 1 and all(m.isfile() for m in members),
                'packed archive inventory mismatch')
        for member in members:
            raw = bundle.extractfile(member).read()
            if member.name == 'RAW_FILE_MANIFEST.json':
                require(raw == (target / 'RAW_FILE_MANIFEST.json').read_bytes(), 'packed manifest changed')
                continue
            expected_entry = next(r for r in inventory if r['path'] == member.name)
            require(len(raw) == expected_entry['bytes'] and digest(raw) == expected_entry['sha256'],
                    'packed original differs: ' + member.name)
    evidence = {'schema': 'perc1.trained-native-delivery.v1', 'parent_source_ref': PARENT,
                'engineering_status': PASS, 'scientific_status': 'HOLD', 'adoption': 'NoUpdate',
                'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
                            'sha256': digest(archive.read_bytes()), 'files_including_manifest': len(inventory) + 1,
                            'verified_all_member_hashes': True},
                'raw_manifest_sha256': digest((target / 'RAW_FILE_MANIFEST.json').read_bytes()),
                'report_sha256': digest((target / 'REPORT.json').read_bytes()),
                'tests_sha256': digest((target / 'TESTS.json').read_bytes()),
                'source_manifest_sha256': report['source_manifest_sha256'],
                'source_pins': report['source_pins'], 'native_binary_sha256': report['native_binary_sha256'],
                'new_training': False, 'new_sources': 0, 'production_daemon_integrated': False,
                'contains_native_executables': False, 'contains_private_FUNSD': False,
                'cost_scope': report['cost_scope']}
    write_new(target / 'EVIDENCE.json', evidence)
    elapsed = report['driver_wall_ns'] / 1e9
    readme = f'''# Historical PERC trained-head native ownership qualification

Scientific status: **HOLD / NoUpdate**. Engineering: **{PASS}**.

Six archived trained tanh ranking heads were executed through native inference
and durable Cell ownership: **180 historical cases, 30 reused tasks, six models**.
No new training, capture, OCR, backbone inference, independent source confirmation,
production daemon enrollment, or terminal-task benefit qualification occurred.

## Final observed gates

| Gate | Result |
| --- | --- |
| Actual native boundary tests | {tests['tests']}/{tests['tests']} passed; zero failures, errors, or skips |
| Python/native ranking agreement | {report['ranking_matches']}/180 |
| Maximum absolute FP64 logit difference | {worst:.17g} |
| Cold process replay without inference | {report['cold_process_replays_without_new_inference']}/180 |
| Lost-ACK original readback without inference | {report['lost_ack_recoveries_without_new_inference']}/6 |
| Expected refusal controls | {report['expected_refusals']}/2 |
| Candidate identity mapping | Validated |
| Diagnostic sparse Cell matches raw MLP top | {matches}/180 |
| Diagnostic sparse Cell abstentions | {abstentions}/180 |
| Inclusive final driver wall time | {elapsed:.6f} seconds |

The original FP64 row/head bytes are frozen. Native outputs retain IEEE-754 bit
patterns for exact replay and commit their digest through the owner output.
The auxiliary 32-value prediction channel stores digest bytes and has no
predictive interpretation; calibration remains a hand-authored fixture.
Python/native initial JSON arithmetic parity is measured above; it is not claimed
bit-identical. Sparse Cell/calibration guards retain diagnostic settings. Raw MLP
ranking, sparse selection, and abstention are separate observed quantities; none
establishes product adoption or task benefit.

## Historical identities and failed attempts

The loader verifies the original archive `{ARCHIVE_SOURCE}` and reconstructs
TRAIN feature digests for all six heads. Actual historical counts are
60 TRAIN / 20 DEV / 30 confirmation; stale descriptive panel metadata differs.
DEV was not reexecuted. All 180 cases reuse the historical confirmation panel.

`RUN_CLASSIFICATION.json` preserves run-v1 FP64 self-parse failure, run-v2 raw
math success with invalid different-ID Cell comparison, and final run-v3.
The old run-v2 0/180 comparison is invalid, not a negative policy result. Original
TESTS_V1 code_sha256 map-versus-string failure, all four test snapshots, all three
runs, logs, and selected build/source snapshots remain in the verified archive.

## Reproduce and review

Use `.github/workflows/hepta-perc-trained-native.yml` for the isolated native
build and prerequisite pins. With the configured native binary:

```sh
export PYTHONPATH=scripts
export PERC1_SEMANTIC_NATIVE_BINARY=/absolute/path/to/native-binary
python3 -m unittest discover -s scripts -p test_perc_semantic_native.py -v
python3 -m perc1.semantic_native_qualification --native-binary "$PERC1_SEMANTIC_NATIVE_BINARY" --archive qualification/perc-semantic-owner-20261110/raw-evidence-v1.tar.xz --output /absolute/new/run-directory
```

Outputs are create-only. `RAW_FILE_MANIFEST.json` commits every archived original;
`EVIDENCE.json` identifies the archive and verifies all members. No executables,
private FUNSD originals, or earlier unrelated ZIP are included.

Process envelopes and inclusive driver wall overlap; do not add them. Older
inclusive timings describe their own attempts. No product cost saving, energy,
billing, distributed recovery, power-loss, or daemon qualification is established.

Four review stages: bounded model port; owner/output commitment and recovery;
archive loader/replay driver; boundary tests, strict CI, and evidence.
'''
    require(len(readme.splitlines()) <= 100, 'README exceeds review bound')
    with (target / 'README.md').open('x') as stream:
        stream.write(readme)
    print(json.dumps({'delivery': str(target), 'archive': evidence['archive'],
                      'historical_cases': 180, 'native_tests': 8, 'cell_abstentions': abstentions,
                      'sparse_matches': matches, 'max_abs_logit_error': worst}, indent=2))
    return target


if __name__ == '__main__':
    prepare(Path(sys.argv[1]) if len(sys.argv) == 2 else Path.cwd())
