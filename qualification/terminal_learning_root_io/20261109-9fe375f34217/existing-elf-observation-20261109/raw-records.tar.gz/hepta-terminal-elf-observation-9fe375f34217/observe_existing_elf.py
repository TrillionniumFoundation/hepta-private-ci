#!/usr/bin/env python3
"""Supplement an existing Hepta test ELF receipt without a build or source edit."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/worktrees/hepta-terminal-root-io-9fe375f34217')
OUT = Path('/home/qian-qi/work/hepta-terminal-elf-observation-9fe375f34217')
ORIGINAL = 'ebdc64a4cd4bfd67e53d2f88490185a47d1faeee'
BRANCH = 'codex/hepta-terminal-root-io-20261109-9fe375f34217'
TESTED = '756968dba94e969a1ee9bc151683682b6fb4da31'
ELF = Path('/home/qian-qi/work/hepta-terminal-root-io-9fe375f34217-target/dev-small/deps/codex_hepta_agentd-1791ccae65de1a11')
ELF_SHA = '935957f46aefb677732c508501a8566ccbb9b973eb012c11155ed2410fe43d95'
HELPERS = {
    'pinned_native_process.py': '2f46137a7b74c8930e83114fc9844f540e81b3e4f95919f2a12c5256d76ab462',
    'verify_ci_source.py': '0ddfd07719eae98913348c82b06d3e4522d721c353d9b01d6deac0dfda619946',
}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


for name, expected in HELPERS.items():
    if digest(OUT / name) != expected:
        raise SystemExit('fixed observer helper mismatch: ' + name)
sys.path.insert(0, str(OUT))
from pinned_native_process import run_pinned
from verify_ci_source import verify

environment = {
    'GIT_NO_LAZY_FETCH': '1', 'GIT_NO_REPLACE_OBJECTS': '1',
    'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1',
    'RUST_MIN_STACK': '8388608', 'NEXTEST_PROFILE': 'local',
    'CODEX_REPO_ROOT': str(ROOT), 'JUST_SHELL': str(ROOT / 'scripts/just-shell.py'),
    'RUST_TEST_THREADS': '1',
}
os.environ.update(environment)
record = {
    'schema': 'hepta-existing-elf-observation-v1', 'status': 'running',
    'started_unix_ns': time.time_ns(), 'original_branch': BRANCH,
    'original_head': ORIGINAL, 'tested_commit': TESTED,
    'observer_source_commit': '75dc7ec3973ce3661c27c895418efd5c6cc8b4a8',
    'observer_helpers': HELPERS, 'elf_path': str(ELF),
    'expected_elf_sha256': ELF_SHA, 'expected_elf_bytes': 165440216,
    'explicit_environment': environment, 'commands': [],
    'new_source_or_build': False, 'distinct_native_test_count_expected': 12,
    'performance_qualified': False, 'complete_hepta_loop_qualified': False,
    'whole_chain_quantum_security_qualified': False, 'qualification': 'HOLD',
}
with (OUT / 'record.json').open('x') as stream:
    json.dump(record, stream, sort_keys=True, indent=2)


def save():
    (OUT / 'record.json').write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args],
                                   cwd=ROOT, text=True).strip()


def command(label, args):
    result = subprocess.run(args, cwd=ROOT, capture_output=True, check=False)
    stdout, stderr = OUT / (label + '.stdout'), OUT / (label + '.stderr')
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    row = {'label': label, 'argv': args, 'cwd': str(ROOT), 'exit_code': result.returncode,
           'stdout': str(stdout), 'stdout_sha256': digest(stdout),
           'stderr': str(stderr), 'stderr_sha256': digest(stderr)}
    record['commands'].append(row)
    save()
    if result.returncode:
        raise RuntimeError('command failed: ' + label)


def source(label, commit):
    result = verify('head', commit, root=ROOT)
    (OUT / (label + '.json')).write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    record[label] = result
    save()
    return result


detached = False
try:
    if git('rev-parse', 'HEAD') != ORIGINAL or git('symbolic-ref', '--short', 'HEAD') != BRANCH:
        raise ValueError('exclusive original checkout changed')
    if git('status', '--porcelain', '--untracked-files=all'):
        raise ValueError('original checkout is not clean')
    original_agents = git('rev-parse', ORIGINAL + ':AGENTS.md')
    if git('rev-parse', TESTED + ':AGENTS.md') != original_agents:
        raise ValueError('tested AGENTS differs; must read before execution')
    record['agents_blob'] = original_agents
    record['agents_sha256'] = digest(ROOT / 'AGENTS.md')
    record['justfile_sha256'] = digest(ROOT / 'justfile')
    if ELF.stat().st_size != 165440216 or digest(ELF) != ELF_SHA:
        raise ValueError('existing ELF size or hash changed')
    source('original-source-before', ORIGINAL)
    command('detach-tested', ['git', '--no-replace-objects', 'checkout', '--detach', TESTED])
    detached = True
    before = source('tested-source-before', TESTED)
    listing_args = [str(ELF), 'terminal_learning', '--list', '--format', 'terse']
    listing_log = OUT / 'terminal-learning-list.log'
    with listing_log.open('xb') as stream:
        listing_code, listing_identity = run_pinned(
            listing_args, ROOT / 'codex-rs/hepta-agentd', stream, ELF_SHA)
    record['listing'] = {'argv': listing_args, 'exit_code': listing_code,
                         'native_execution': listing_identity,
                         'log': str(listing_log), 'log_sha256': digest(listing_log)}
    listing = listing_log.read_text()
    names = [line[:-6] for line in listing.splitlines() if line.endswith(': test')]
    record['listed_tests'] = names
    record['distinct_native_test_count'] = len(set(names))
    save()
    if listing_code != 0 or len(names) != 12 or len(set(names)) != 12:
        raise ValueError('actual terminal_learning roster is not exactly 12 unique tests')
    if any('terminal_learning' not in name for name in names):
        raise ValueError('unexpected listing name')
    print(json.dumps({'event': 'listed_exactly_12', 'tests': names}), flush=True)
    run_args = [str(ELF), 'terminal_learning', '--nocapture',
                '--test-threads=1', '--format=pretty']
    raw = OUT / 'terminal-learning-native.log'
    with raw.open('xb') as stream:
        native_code, identity = run_pinned(
            run_args, ROOT / 'codex-rs/hepta-agentd', stream, ELF_SHA)
    transcript = raw.read_text()
    executed = re.findall(r'^test ([A-Za-z_][A-Za-z0-9_:]*) \.\.\.', transcript, re.MULTILINE)
    summary_pattern = (r'^test result: ok\. 12 passed; 0 failed; 0 ignored; 0 measured; '
                       r'[0-9]+ filtered out; finished in [0-9]+(?:\.[0-9]+)?s$')
    summaries = re.findall(summary_pattern, transcript, re.MULTILINE)
    record['native'] = {'argv': run_args, 'cwd': str(ROOT / 'codex-rs/hepta-agentd'),
                        'exit_code': native_code, 'native_execution': identity,
                        'log': str(raw), 'log_sha256': digest(raw),
                        'log_bytes': raw.stat().st_size, 'executed_tests': executed,
                        'exact_roster_match': sorted(executed) == sorted(names),
                        'complete_12_pass_summary_count': len(summaries)}
    save()
    after = source('tested-source-after', TESTED)
    record['tested_source_before_after_equal'] = before == after
    record['elf_after_sha256'] = digest(ELF)
    if (native_code != 0 or identity['status'] != 'PINNED_AND_OBSERVED'
            or listing_identity['status'] != 'PINNED_AND_OBSERVED'
            or sorted(executed) != sorted(names) or len(summaries) != 1
            or before != after or record['elf_after_sha256'] != ELF_SHA):
        raise ValueError('supplemental observation incomplete or unsuccessful')
    record['status'] = 'observed_existing_12_test_execution'
except BaseException as error:
    record.update(status='observation_failed', error=repr(error))
    print(json.dumps({'event': 'observation_failed', 'error': repr(error)}), flush=True)
finally:
    if detached:
        try:
            if git('rev-parse', 'HEAD') != TESTED:
                raise ValueError('concurrent HEAD change; refusing forced restoration')
            if git('rev-parse', 'refs/heads/' + BRANCH) != ORIGINAL:
                raise ValueError('original branch changed; refusing history rewrite')
            if git('status', '--porcelain', '--untracked-files=all'):
                raise ValueError('source changed; refusing to discard modifications')
            if 'tested-source-after' not in record:
                source('tested-source-after', TESTED)
            command('restore-original-branch', ['git', '--no-replace-objects', 'checkout', BRANCH])
            record['restored_head'] = git('rev-parse', 'HEAD')
            record['restored_branch'] = git('symbolic-ref', '--short', 'HEAD')
            record['restored_status'] = git('status', '--porcelain', '--untracked-files=all')
            if record['restored_head'] != ORIGINAL or record['restored_branch'] != BRANCH or record['restored_status']:
                raise ValueError('original branch/head/clean state not restored')
            source('original-source-after', ORIGINAL)
            record['original_source_before_after_equal'] = (
                record.get('original-source-before') == record['original-source-after'])
            record['restoration_succeeded'] = True
        except BaseException as error:
            record.update(status='restoration_failed', restoration_succeeded=False,
                          restoration_error=repr(error))
    record['finished_unix_ns'] = time.time_ns()
    save()
    print(json.dumps({'event': 'observation_finished', 'status': record['status'],
                      'restoration_succeeded': record.get('restoration_succeeded'),
                      'record': str(OUT / 'record.json')}), flush=True)

raise SystemExit(0 if record['status'] == 'observed_existing_12_test_execution' else 1)
