"""Only two predeclared split meshes; no mesh search or qualification gate."""

import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np
from scipy.linalg import expm
from scipy.special import log_ndtr


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "p1-split-successor"
mesh_path = SOURCE / "qualification/hcsn_split_mesh/mesh.py"
expected_mesh_sha256 = "c4a343e919c25c2c06cdbe14318ab9769106ca6132949df255ff2b5a872e455a"
assert hashlib.sha256(mesh_path.read_bytes()).hexdigest() == expected_mesh_sha256
sys.path.insert(0, str(SOURCE))
from qualification.hcsn_split_mesh.mesh import split_model as aligned_model


def hit(distance, drift, sigma, time):
    scale = sigma * math.sqrt(time)
    return float(np.exp(np.logaddexp(log_ndtr((-distance-drift*time)/scale),
        -2*drift*distance/sigma**2+log_ndtr((-distance+drift*time)/scale))))


cases = []
for left_grading, right_grading in ((1., 0.), (0., 0.)):
    geometry = dict(left_intervals=32, right_intervals=32, endpoint=2.,
                    grading=left_grading, right_grading=right_grading, delay=.2)
    theta = np.array([.01, -.12, .5, math.exp(.51), .15])
    model, _ = aligned_model(theta, **geometry)
    records = []
    for time in (.01, .1):
        value = float(expm(time*model.spatial.matrix())[32, 0])
        reference = hit(.5, -.12, .5, time)
        records.append(dict(time=time, ctmc=value, continuum_halfline=reference,
            upper_reach_probability_bound=hit(1.5, .12, .5, time),
            relative_error=value/reference-1))
    theta[2] = .08
    low, _ = aligned_model(theta, **geometry)
    cases.append(dict(geometry=geometry, first_hit=records,
        negative_drift_low_noise_accepted=True,
        minimum_down=float(np.min(low.spatial.rates[0])),
        minimum_up=float(np.min(low.spatial.rates[1])),
        nodal_law_rows=64, phase_rows_available_under_current_native_cap=0))
paths = ["qualification/hcsn_split_mesh/mesh.py", "qualification/hcsn_reset_aligned/mesh.py", "qualification/hcsn_joint_dde/state_io.py",
         "qualification/hcsn_joint_dde/model.py", "qualification/hcsn_joint_dde/graded.py",
         "qualification/hcsn_boundary_audit/spatial_generator.py",
         "qualification/hcsn_boundary_audit/refractory_transport.py"]
report = dict(schema="hcsn-two-declared-split-mesh-review-v1",
    source_sha256={p:hashlib.sha256((SOURCE/p).read_bytes()).hexdigest() for p in paths},
    probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    cases=cases, exploratory_only=True, operator_source_modified=False, torch_adapter_for_split_candidate=False,
    original_f934_counterexamples_preserved=True,
    common_candidate_pass_changed=False, qualification_threshold_added_or_relaxed=False)
(ROOT / "REVIEW.json").write_text(json.dumps(report, indent=2, sort_keys=True)+"\n")
print(json.dumps(report, indent=2, sort_keys=True))
