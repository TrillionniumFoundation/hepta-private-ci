use std::io::ErrorKind;
#[cfg(unix)]
use std::path::Path;
#[cfg(unix)]
use std::path::PathBuf;
#[cfg(unix)]
use std::sync::Arc;
#[cfg(unix)]
use std::sync::atomic::AtomicU64;
#[cfg(unix)]
use std::sync::atomic::Ordering;
#[cfg(unix)]
use std::time::Duration;
#[cfg(unix)]
use std::time::Instant;

#[cfg(any(unix, test))]
use codex_hepta_contracts::AgentId;
#[cfg(any(unix, test))]
use codex_hepta_fleet::AgentLifecycle;
#[cfg(unix)]
use codex_hepta_fleet::FleetRegistry;
#[cfg(any(unix, test))]
use codex_hepta_fleet::FleetRegistryError;
#[cfg(any(unix, test))]
use codex_hepta_fleet::ReleaseId;
use codex_hepta_paths::HeptaFleetRoot;
#[cfg(unix)]
use codex_uds::UnixListener;
#[cfg(unix)]
use codex_uds::UnixStream;
#[cfg(any(unix, test))]
use constant_time_eq::constant_time_eq_32;
#[cfg(any(unix, test))]
use serde::Serialize;
#[cfg(any(unix, test))]
use sha2::Digest;
#[cfg(any(unix, test))]
use sha2::Sha256;
#[cfg(unix)]
use tokio::io::AsyncBufReadExt;
#[cfg(unix)]
use tokio::io::AsyncReadExt;
#[cfg(unix)]
use tokio::io::AsyncWriteExt;
#[cfg(unix)]
use tokio::io::BufReader;
#[cfg(unix)]
use tokio::sync::Semaphore;
#[cfg(unix)]
use tokio::task::JoinSet;
#[cfg(unix)]
use tokio::time::MissedTickBehavior;
#[cfg(unix)]
use tokio::time::timeout;
use tokio_util::sync::CancellationToken;

#[cfg(unix)]
use crate::AgentRelease;
#[cfg(any(unix, test))]
use crate::AgentSupervisorSnapshot;
#[cfg(unix)]
use crate::H7H89ProductionGrant;
use crate::H7H89ProductionGrantVerifier;
#[cfg(unix)]
use crate::H7H89ProductionTransition;
#[cfg(unix)]
use crate::ProcessDriver;
#[cfg(unix)]
use crate::ProductionRecoveryDecision;
#[cfg(unix)]
use crate::Supervisor;
#[cfg(unix)]
use crate::SupervisorConfig;
use crate::SupervisorError;
#[cfg(unix)]
use crate::UnixProcessDriver;
#[cfg(any(unix, test))]
use crate::daemon_protocol::ControlStateDigest;
#[cfg(unix)]
use crate::daemon_protocol::MAX_SUPERVISORD_CONTROL_FRAME_BYTES;
#[cfg(unix)]
use crate::daemon_protocol::MAX_SUPERVISORD_CONTROL_REQUEST_BYTES;
#[cfg(unix)]
use crate::daemon_protocol::MAX_SUPERVISORD_ROSTER;
#[cfg(unix)]
use crate::daemon_protocol::SUPERVISORD_CONTROL_SCHEMA_VERSION;
#[cfg(any(unix, test))]
use crate::daemon_protocol::SupervisorEpoch;
#[cfg(any(unix, test))]
use crate::daemon_protocol::SupervisordAgentStatus;
#[cfg(any(unix, test))]
use crate::daemon_protocol::SupervisordControlFence;
#[cfg(unix)]
use crate::daemon_protocol::SupervisordHealth;
#[cfg(any(unix, test))]
use crate::daemon_protocol::SupervisordMatrixStatus;
#[cfg(unix)]
use crate::daemon_protocol::SupervisordMethod;
#[cfg(unix)]
use crate::daemon_protocol::SupervisordMutation;
#[cfg(any(unix, test))]
use crate::daemon_protocol::SupervisordPayload;
#[cfg(unix)]
use crate::daemon_protocol::SupervisordRequest;
#[cfg(unix)]
use crate::daemon_protocol::SupervisordRequestValidationError;
#[cfg(unix)]
use crate::daemon_protocol::SupervisordResponse;
#[cfg(unix)]
use crate::signed_authority::authority_epoch_for_supervisor_epoch;

#[cfg(unix)]
#[path = "daemon_execution.rs"]
mod execution;
#[cfg(all(unix, not(feature = "qualification")))]
#[path = "daemon_mutex.rs"]
mod mutex;
#[cfg(all(unix, feature = "qualification"))]
use crate::qualification_mutex as mutex;
#[cfg(unix)]
#[path = "daemon_owner.rs"]
mod owner;
#[cfg(unix)]
#[path = "daemon_read_view.rs"]
mod read_view;
#[cfg(unix)]
use mutex::MeasuredMutex as Mutex;
#[cfg(unix)]
use owner::SingleInstanceLock;

#[cfg(unix)]
const CONNECTION_CAPACITY: usize = 64;
#[cfg(unix)]
const IO_TIMEOUT: Duration = Duration::from_secs(2);
#[cfg(unix)]
const TICK_INTERVAL: Duration = Duration::from_millis(25);
#[cfg(any(unix, test))]
const CONTROL_STATE_DIGEST_DOMAIN: &[u8] = b"hepta.supervisord.control-state.v2\0";
#[cfg(any(unix, test))]
const CONTROL_FENCE_IDENTITY_DOMAIN: &[u8] = b"hepta.supervisord.control-fence-identity.v2\0";

/// Compile-time gate for the externally-authorized mutation entry point.
/// Unit tests may still exercise the signed state machine as qualification
/// fixtures, but a non-test/default daemon build cannot activate it merely by
/// supplying a verifier at runtime.
pub const PRODUCTION_AUTHORITY_FEATURE_ENABLED: bool =
    cfg!(feature = "production-authority") || cfg!(test);

#[cfg(unix)]
struct DaemonState<D: ProcessDriver> {
    registry: FleetRegistry,
    supervisor: Mutex<Supervisor<D>>,
    supervisor_epoch: SupervisorEpoch,
    production_grant_verifier: Option<H7H89ProductionGrantVerifier>,
    observed_faults: AtomicU64,
    execution: execution::Execution,
    // Drop after the writer. Detached or cancelling tasks retain the same guard
    // through their Arc<DaemonState>; returning from run_supervisord is not a fence.
    _instance: SingleInstanceLock,
}

/// Runs the one lifecycle-only supervisor daemon for a fleet.
///
/// This service owns no chat ingress, model provider, token stream, tool
/// dispatcher, or execution queue. Every mutation is a bounded per-Agent
/// lifecycle operation.
/// Returns an unsupported-platform I/O error before accessing fleet state on
/// non-Unix hosts, where no concrete process driver is implemented.
pub async fn run_supervisord(
    fleet_root: HeptaFleetRoot,
    cancellation: CancellationToken,
) -> Result<(), SupervisorError> {
    run_supervisord_inner(fleet_root, cancellation, None).await
}

/// Production entry point for a daemon whose trust root was pinned by an
/// external authority/configuration ceremony.  The verifier is intentionally
/// a parameter: the daemon never reads a public key from a mutation request
/// and the legacy entry point keeps signed mutations disabled.
/// After the feature gate, non-Unix hosts return an unsupported-platform I/O
/// error before accessing fleet state.
pub async fn run_supervisord_with_grant_verifier(
    fleet_root: HeptaFleetRoot,
    cancellation: CancellationToken,
    verifier: H7H89ProductionGrantVerifier,
) -> Result<(), SupervisorError> {
    if !PRODUCTION_AUTHORITY_FEATURE_ENABLED {
        return Err(SupervisorError::ProductionAuthorityFeatureDisabled);
    }
    run_supervisord_inner(fleet_root, cancellation, Some(verifier)).await
}

#[cfg(unix)]
async fn run_supervisord_inner(
    fleet_root: HeptaFleetRoot,
    cancellation: CancellationToken,
    production_grant_verifier: Option<H7H89ProductionGrantVerifier>,
) -> Result<(), SupervisorError> {
    // Cancelling/dropping the outer future must also stop the ticker and server.
    let _shutdown = cancellation.clone().drop_guard();
    // Opening an existing registry may migrate legacy Matrix directories. The
    // exact kernel owner must therefore precede opening, not only recovery.
    let instance = SingleInstanceLock::acquire_for_fleet(&fleet_root)?;
    let registry = FleetRegistry::open_existing(fleet_root)?;
    let snapshot = registry.load()?;
    if snapshot.agents.len() > usize::from(MAX_SUPERVISORD_ROSTER) {
        return Err(SupervisorError::Invalid(format!(
            "fleet has {} agents but supervisord supports at most {MAX_SUPERVISORD_ROSTER}",
            snapshot.agents.len()
        )));
    }
    let layout = registry.layout().clone();
    let driver =
        UnixProcessDriver::new(256).map_err(|error| SupervisorError::Invalid(error.to_string()))?;
    let (supervisor, recovery) = Supervisor::recover(
        registry.clone(),
        driver,
        SupervisorConfig::local_default(),
        Instant::now(),
    )?;
    let state = Arc::new(DaemonState {
        registry,
        supervisor: Mutex::new(supervisor),
        supervisor_epoch: SupervisorEpoch::new(),
        production_grant_verifier,
        observed_faults: AtomicU64::new(recovery.faults.len() as u64),
        execution: execution::Execution::new(cancellation.clone()),
        _instance: instance,
    });
    {
        let supervisor = state.supervisor.lock().await;
        execution::refresh(&state, &supervisor);
    }
    let server = SupervisordServer::bind(
        layout.supervisor_socket().to_path_buf(),
        Arc::clone(&state),
        cancellation.clone(),
    )
    .await?;
    let tick_state = Arc::clone(&state);
    let tick_cancellation = cancellation.clone();
    let ticker = tokio::spawn(async move {
        let mut interval = tokio::time::interval(TICK_INTERVAL);
        interval.set_missed_tick_behavior(MissedTickBehavior::Skip);
        loop {
            tokio::select! {
                _ = tick_cancellation.cancelled() => return,
                scheduled = interval.tick() => {
                    execution::tick(Arc::clone(&tick_state), scheduled.into_std()).await;
                }
            }
        }
    });
    let result = server.run().await;
    cancellation.cancel();
    let ticker_result = ticker.await;
    if ticker_result.is_err() || state.execution.failed() {
        return Err(SupervisorError::Invalid(
            "supervisord lifecycle worker failed; durable recovery is required".to_string(),
        ));
    }
    result
}

#[cfg(not(unix))]
async fn run_supervisord_inner(
    _fleet_root: HeptaFleetRoot,
    _cancellation: CancellationToken,
    _production_grant_verifier: Option<H7H89ProductionGrantVerifier>,
) -> Result<(), SupervisorError> {
    Err(std::io::Error::new(
        ErrorKind::Unsupported,
        "supervisord process hosting is supported only on Unix hosts",
    )
    .into())
}

#[cfg(unix)]
struct SupervisordServer {
    listener: UnixListener,
    socket_path: PathBuf,
    state: Arc<DaemonState<UnixProcessDriver>>,
    cancellation: CancellationToken,
    connections: Arc<Semaphore>,
}

#[cfg(unix)]
impl SupervisordServer {
    async fn bind(
        socket_path: PathBuf,
        state: Arc<DaemonState<UnixProcessDriver>>,
        cancellation: CancellationToken,
    ) -> Result<Self, SupervisorError> {
        prepare_socket(&socket_path).await?;
        let listener = UnixListener::bind(&socket_path).await?;
        set_owner_only(&socket_path).await?;
        Ok(Self {
            listener,
            socket_path,
            state,
            cancellation,
            connections: Arc::new(Semaphore::new(CONNECTION_CAPACITY)),
        })
    }

    async fn run(mut self) -> Result<(), SupervisorError> {
        let mut tasks = JoinSet::new();
        let mut result = loop {
            let stream = tokio::select! {
                _ = self.cancellation.cancelled() => break Ok(()),
                joined = tasks.join_next(), if !tasks.is_empty() => {
                    if matches!(joined, Some(Err(_))) {
                        break Err(SupervisorError::Invalid(
                            "supervisord connection task failed".to_string(),
                        ));
                    }
                    continue;
                }
                accepted = self.listener.accept() => match accepted {
                    Ok(stream) => stream,
                    Err(error) => break Err(error.into()),
                },
            };
            let Ok(permit) = Arc::clone(&self.connections).try_acquire_owned() else {
                drop(stream);
                continue;
            };
            let state = Arc::clone(&self.state);
            tasks.spawn(async move {
                let _permit = permit;
                let _ = timeout(IO_TIMEOUT, serve_connection(stream, state)).await;
            });
        };
        self.cancellation.cancel();
        if result.is_err() {
            tasks.abort_all();
        }
        // Drain already accepted requests before normal shutdown. On future drop,
        // JoinSet aborts them; a still-running synchronous task retains state/lock.
        while let Some(joined) = tasks.join_next().await {
            if let Err(error) = joined
                && error.is_panic()
            {
                self.state.observed_faults.fetch_add(1, Ordering::Relaxed);
                result = Err(SupervisorError::Invalid(
                    "supervisord connection task failed during shutdown".to_string(),
                ));
            }
        }
        result
    }
}

#[cfg(unix)]
impl Drop for SupervisordServer {
    fn drop(&mut self) {
        if let Err(error) = std::fs::remove_file(&self.socket_path)
            && error.kind() != ErrorKind::NotFound
        {
            eprintln!(
                "failed to remove supervisord control socket {}: {error}",
                self.socket_path.display()
            );
        }
    }
}

#[cfg(unix)]
async fn serve_connection(
    stream: UnixStream,
    state: Arc<DaemonState<UnixProcessDriver>>,
) -> Result<(), SupervisorError> {
    codex_uds::ensure_current_user_peer(&stream)?;
    let (reader, mut writer) = tokio::io::split(stream);
    let mut reader = BufReader::new(reader).take(MAX_SUPERVISORD_CONTROL_REQUEST_BYTES + 1);
    let mut frame = Vec::new();
    let count = reader.read_until(b'\n', &mut frame).await?;
    if count == 0 || count as u64 > MAX_SUPERVISORD_CONTROL_REQUEST_BYTES || !frame.ends_with(b"\n")
    {
        return Ok(());
    }
    let request: SupervisordRequest = match serde_json::from_slice(&frame) {
        Ok(request) => request,
        Err(_) => {
            write_response(
                &mut writer,
                error_response(
                    0,
                    "invalid_frame",
                    "request is not valid supervisord control JSON",
                    None,
                ),
            )
            .await?;
            return Ok(());
        }
    };
    let response = match request.validate() {
        Err(SupervisordRequestValidationError::UnsupportedSchema) => error_response(
            request.request_id,
            "unsupported_schema",
            "unsupported supervisord control schema",
            None,
        ),
        Err(SupervisordRequestValidationError::InvalidRequest) => error_response(
            request.request_id,
            "invalid_frame",
            "request is not valid supervisord control JSON",
            None,
        ),
        Ok(()) => SupervisordResponse {
            schema_version: SUPERVISORD_CONTROL_SCHEMA_VERSION,
            request_id: request.request_id,
            payload: execution::handle(Arc::clone(&state), request.method).await,
        },
    };
    write_response(&mut writer, response).await
}

#[cfg(unix)]
async fn write_response(
    writer: &mut tokio::io::WriteHalf<UnixStream>,
    response: SupervisordResponse,
) -> Result<(), SupervisorError> {
    let mut bytes = serde_json::to_vec(&response)
        .map_err(|error| SupervisorError::Invalid(format!("encode control response: {error}")))?;
    bytes.push(b'\n');
    if bytes.len() as u64 > MAX_SUPERVISORD_CONTROL_FRAME_BYTES {
        return Err(SupervisorError::Invalid(
            "supervisord response exceeded frame bound".to_string(),
        ));
    }
    writer.write_all(&bytes).await?;
    writer.shutdown().await?;
    Ok(())
}

#[cfg(unix)]
async fn handle_request<D: ProcessDriver>(
    state: Arc<DaemonState<D>>,
    method: SupervisordMethod,
) -> SupervisordPayload {
    match method {
        SupervisordMethod::Health => {
            let registered_agents = match state.registry.load() {
                Ok(snapshot) => snapshot.agents.len(),
                Err(error) => {
                    return safe_rejection(
                        error.into(),
                        /*actual*/ None,
                        /*mutation_started*/ false,
                    );
                }
            };
            let registered_agents = match u16::try_from(registered_agents) {
                Ok(count) => count,
                Err(_) => {
                    return safe_rejection(
                        SupervisorError::Invalid("registered agent count exceeds u16".to_string()),
                        /*actual*/ None,
                        /*mutation_started*/ false,
                    );
                }
            };
            let recovery_required = state
                .supervisor
                .lock()
                .await
                .any_production_recovery_required();
            SupervisordPayload::Health(SupervisordHealth {
                ready: !recovery_required,
                supervisor_epoch: state.supervisor_epoch.clone(),
                process_id: std::process::id(),
                registered_agents,
                observed_faults: state.observed_faults.load(Ordering::Relaxed),
            })
        }
        SupervisordMethod::Roster { limit } => {
            if !(1..=MAX_SUPERVISORD_ROSTER).contains(&limit) {
                return error_payload(
                    "invalid_frame",
                    "request is not valid supervisord control JSON",
                    /*actual*/ None,
                );
            }
            let supervisor = state.supervisor.lock().await;
            let records = match state.registry.load() {
                Ok(snapshot) => snapshot.agents,
                Err(error) => {
                    return safe_rejection(
                        error.into(),
                        /*actual*/ None,
                        /*mutation_started*/ false,
                    );
                }
            };
            let agents = match records
                .into_iter()
                .take(usize::from(limit))
                .map(|(agent_id, record)| {
                    status_from(
                        &state.supervisor_epoch,
                        &record,
                        supervisor.snapshot(&agent_id),
                    )
                })
                .collect::<Result<Vec<_>, _>>()
            {
                Ok(agents) => agents,
                Err(error) => {
                    return safe_rejection(
                        error, /*actual*/ None, /*mutation_started*/ false,
                    );
                }
            };
            SupervisordPayload::Roster { agents }
        }
        SupervisordMethod::Snapshot { agent_id } => match agent_status(&state, &agent_id).await {
            Ok(status) => SupervisordPayload::Agent(status),
            Err(error) => {
                safe_rejection(error, /*actual*/ None, /*mutation_started*/ false)
            }
        },
        SupervisordMethod::ReleaseSelection { agent_id } => {
            let supervisor = state.supervisor.lock().await;
            match supervisor.release_selection_snapshot(&agent_id) {
                Ok(selection) => SupervisordPayload::ReleaseSelection { selection },
                Err(error) => {
                    safe_rejection(error, /*actual*/ None, /*mutation_started*/ false)
                }
            }
        }
        SupervisordMethod::ProductionMutationStatus { agent_id } => {
            let supervisor = state.supervisor.lock().await;
            match supervisor.production_mutation_state(&agent_id) {
                Ok(state) => SupervisordPayload::ProductionMutationStatus { state },
                Err(error) => {
                    safe_rejection(error, /*actual*/ None, /*mutation_started*/ false)
                }
            }
        }
        SupervisordMethod::Start { fence, release_id } => {
            let target = match resolve_release_outside_lock(
                Arc::clone(&state),
                fence.agent_id.clone(),
                release_id,
            ) {
                Ok(target) => target,
                Err(error) => {
                    let actual = agent_status(&state, &fence.agent_id).await.ok();
                    return safe_rejection(error, actual, /*mutation_started*/ false);
                }
            };
            handle_mutation(state, SupervisordMutation::Start, fence, Some(target)).await
        }
        SupervisordMethod::Drain { fence } => {
            handle_mutation(
                state,
                SupervisordMutation::Drain,
                fence,
                /*target*/ None,
            )
            .await
        }
        SupervisordMethod::Stop { fence } => {
            handle_mutation(
                state,
                SupervisordMutation::Stop,
                fence,
                /*target*/ None,
            )
            .await
        }
        SupervisordMethod::Kill { fence } => {
            handle_mutation(
                state,
                SupervisordMutation::Kill,
                fence,
                /*target*/ None,
            )
            .await
        }
        SupervisordMethod::Restart { fence } => {
            handle_mutation(
                state,
                SupervisordMutation::Restart,
                fence,
                /*target*/ None,
            )
            .await
        }
        SupervisordMethod::Upgrade { fence, release_id } => {
            let target = match resolve_release_outside_lock(
                Arc::clone(&state),
                fence.agent_id.clone(),
                release_id,
            ) {
                Ok(target) => target,
                Err(error) => {
                    let actual = agent_status(&state, &fence.agent_id).await.ok();
                    return safe_rejection(error, actual, /*mutation_started*/ false);
                }
            };
            handle_mutation(state, SupervisordMutation::Upgrade, fence, Some(target)).await
        }
        SupervisordMethod::Rollback { fence } => {
            handle_mutation(
                state,
                SupervisordMutation::Rollback,
                fence,
                /*target*/ None,
            )
            .await
        }
        SupervisordMethod::SignedUpgrade {
            fence,
            grant,
            h7_envelope,
        } => {
            handle_signed_mutation(
                state,
                H7H89ProductionTransition::Upgrade,
                fence,
                grant,
                h7_envelope,
            )
            .await
        }
        SupervisordMethod::SignedRollback {
            fence,
            grant,
            h7_envelope,
        } => {
            handle_signed_mutation(
                state,
                H7H89ProductionTransition::Rollback,
                fence,
                grant,
                h7_envelope,
            )
            .await
        }
        SupervisordMethod::ResolveProductionRecovery { fence, decision } => {
            handle_recovery_resolution(state, fence, decision).await
        }
    }
}

#[cfg(unix)]
async fn handle_recovery_resolution<D: ProcessDriver>(
    state: Arc<DaemonState<D>>,
    fence: SupervisordControlFence,
    decision: ProductionRecoveryDecision,
) -> SupervisordPayload {
    if !PRODUCTION_AUTHORITY_FEATURE_ENABLED {
        return error_payload(
            "production_authority_unavailable",
            "signed production recovery is disabled in this build",
            /*actual*/ None,
        );
    }
    let Some(verifier) = state.production_grant_verifier.clone() else {
        return error_payload(
            "production_authority_unavailable",
            "signed production recovery requires an externally pinned verifier",
            /*actual*/ None,
        );
    };
    let agent_id = fence.agent_id.clone();
    let mut supervisor = state.supervisor.lock().await;
    let actual = match agent_status_locked(&state, &supervisor, &agent_id) {
        Ok(actual) => actual,
        Err(error) => {
            return safe_rejection(error, /*actual*/ None, /*mutation_started*/ false);
        }
    };
    if !control_fence_matches(&fence, &actual.control_fence) {
        return error_payload(
            "stale_control_fence",
            "selected Agent changed; refresh before recovery",
            Some(actual),
        );
    }
    let authority_epoch = authority_epoch_for_supervisor_epoch(state.supervisor_epoch.as_str());
    if let Err(error) = supervisor.resolve_production_recovery(
        &agent_id,
        &decision,
        &verifier,
        authority_epoch,
        unix_seconds_now(),
    ) {
        let post = agent_status_locked(&state, &supervisor, &agent_id).ok();
        return safe_rejection(
            error,
            post.or(Some(actual)),
            /*mutation_started*/ false,
        );
    }
    match supervisor.production_mutation_state(&agent_id) {
        Ok(state) => SupervisordPayload::ProductionMutationStatus { state },
        Err(error) => safe_rejection(error, Some(actual), /*mutation_started*/ true),
    }
}

#[cfg(unix)]
async fn handle_signed_mutation<D: ProcessDriver>(
    state: Arc<DaemonState<D>>,
    transition: H7H89ProductionTransition,
    fence: SupervisordControlFence,
    grant: H7H89ProductionGrant,
    h7_envelope: codex_hepta_memory::H7SignedArtifactEnvelope,
) -> SupervisordPayload {
    if !PRODUCTION_AUTHORITY_FEATURE_ENABLED {
        return error_payload(
            "production_authority_unavailable",
            "signed production mutations are disabled in this build",
            /*actual*/ None,
        );
    }
    let Some(verifier) = state.production_grant_verifier.clone() else {
        return error_payload(
            "production_authority_unavailable",
            "signed production mutations require an externally pinned verifier",
            /*actual*/ None,
        );
    };
    if grant.transition != transition {
        return error_payload(
            "production_authority_rejected",
            "signed operation transition does not match the requested RPC method",
            /*actual*/ None,
        );
    }
    let agent_id = fence.agent_id.clone();
    let accepted_state_digest = fence.state_digest.clone();
    let mut supervisor = state.supervisor.lock().await;
    let actual = match agent_status_locked(&state, &supervisor, &agent_id) {
        Ok(actual) => actual,
        Err(error) => {
            return safe_rejection(error, /*actual*/ None, /*mutation_started*/ false);
        }
    };
    if !control_fence_matches(&fence, &actual.control_fence) {
        return error_payload(
            "stale_control_fence",
            "selected Agent changed; refresh before retry",
            Some(actual),
        );
    }
    match supervisor.production_recovery_required(&agent_id) {
        Ok(true) => {
            return error_payload(
                "signed_intent_recovery_required",
                "resolve the quarantined production mutation before admitting another signed transition",
                Some(actual),
            );
        }
        Ok(false) => {}
        Err(error) => {
            return safe_rejection(error, Some(actual), /*mutation_started*/ false);
        }
    }
    let authority_epoch = authority_epoch_for_supervisor_epoch(state.supervisor_epoch.as_str());
    let receipt = match supervisor.apply_production_grant(
        &agent_id,
        &grant,
        &h7_envelope,
        &verifier,
        authority_epoch,
        unix_seconds_now(),
        Instant::now(),
    ) {
        Ok(receipt) => receipt,
        Err(error) => {
            let post = agent_status_locked(&state, &supervisor, &agent_id).ok();
            return safe_rejection(
                error,
                post.or(Some(actual)),
                /*mutation_started*/ false,
            );
        }
    };
    let post = agent_status_locked(&state, &supervisor, &agent_id).ok();
    let Some(agent) = post else {
        return error_payload(
            "operation_indeterminate",
            "signed operation outcome is indeterminate; refresh before retry",
            /*actual*/ None,
        );
    };
    SupervisordPayload::MutationAccepted {
        operation: match transition {
            H7H89ProductionTransition::Upgrade => SupervisordMutation::Upgrade,
            H7H89ProductionTransition::Rollback => SupervisordMutation::Rollback,
        },
        accepted_state_digest,
        agent,
        production_receipt: Some(receipt),
    }
}

#[cfg(unix)]
fn unix_seconds_now() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|duration| duration.as_secs())
        .unwrap_or(0)
}

#[cfg(unix)]
async fn handle_mutation<D: ProcessDriver>(
    state: Arc<DaemonState<D>>,
    operation: SupervisordMutation,
    fence: SupervisordControlFence,
    target: Option<AgentRelease>,
) -> SupervisordPayload {
    let agent_id = fence.agent_id.clone();
    let accepted_state_digest = fence.state_digest.clone();
    let mut supervisor = state.supervisor.lock().await;
    let actual = match agent_status_locked(&state, &supervisor, &agent_id) {
        Ok(actual) => actual,
        Err(error) => {
            return safe_rejection(error, /*actual*/ None, /*mutation_started*/ false);
        }
    };
    if !control_fence_matches(&fence, &actual.control_fence) {
        return error_payload(
            "stale_control_fence",
            "selected Agent changed; refresh before retry",
            Some(actual),
        );
    }
    match supervisor.production_recovery_required(&agent_id) {
        Ok(true) if operation != SupervisordMutation::Kill => {
            return error_payload(
                "signed_intent_recovery_required",
                "this Agent has a quarantined production mutation; only status, recovery, or emergency kill is allowed",
                Some(actual),
            );
        }
        Ok(_) => {}
        Err(error) => {
            return safe_rejection(error, Some(actual), /*mutation_started*/ false);
        }
    }
    if state.production_grant_verifier.is_some()
        && matches!(
            operation,
            SupervisordMutation::Upgrade | SupervisordMutation::Rollback
        )
    {
        return error_payload(
            "signed_release_authority_required",
            "production mode requires SignedUpgrade or SignedRollback for release transitions",
            Some(actual),
        );
    }

    let prepared = match (operation, target) {
        (SupervisordMutation::Start, Some(target)) => PreparedMutation::Start(target),
        (SupervisordMutation::Drain, None) => PreparedMutation::Drain,
        (SupervisordMutation::Stop, None) => PreparedMutation::Stop,
        (SupervisordMutation::Kill, None) => PreparedMutation::Kill,
        (SupervisordMutation::Restart, None) => PreparedMutation::Restart,
        (SupervisordMutation::Upgrade, Some(target)) => PreparedMutation::Upgrade(target),
        (SupervisordMutation::Rollback, None) => PreparedMutation::Rollback,
        (SupervisordMutation::Start | SupervisordMutation::Upgrade, None) => {
            return error_payload(
                "invalid_frame",
                "request is not valid supervisord control JSON",
                Some(actual),
            );
        }
        (
            SupervisordMutation::Drain
            | SupervisordMutation::Stop
            | SupervisordMutation::Kill
            | SupervisordMutation::Restart
            | SupervisordMutation::Rollback,
            Some(_),
        ) => {
            return error_payload(
                "invalid_frame",
                "request is not valid supervisord control JSON",
                Some(actual),
            );
        }
    };

    if state.production_grant_verifier.is_some()
        && let PreparedMutation::Start(target) = &prepared
    {
        // A failed hydration (for example a revoked selected artifact) can
        // leave the runtime projection without an active release. It does not
        // erase the durable selection or authorize a new unsigned selection.
        let records = match state.registry.load() {
            Ok(records) => records,
            Err(error) => {
                return safe_rejection(error.into(), Some(actual), /*mutation_started*/ false);
            }
        };
        let Some(record) = records.agent(&agent_id) else {
            return safe_rejection(
                SupervisorError::UnknownAgent(agent_id),
                Some(actual),
                /*mutation_started*/ false,
            );
        };
        if record
            .release_state
            .current
            .as_ref()
            .is_some_and(|selected| selected != target.release_id())
        {
            return error_payload(
                "signed_release_authority_required",
                "production Start must use the selected release; a different release requires signed transition authority",
                Some(actual),
            );
        }
    }

    let preflight = match &prepared {
        PreparedMutation::Start(_) => supervisor.preflight_start(&agent_id),
        PreparedMutation::Drain => supervisor.preflight_drain(&agent_id),
        PreparedMutation::Stop | PreparedMutation::Kill => {
            supervisor.preflight_stop_or_kill(&agent_id)
        }
        PreparedMutation::Restart => supervisor.preflight_restart(&agent_id),
        PreparedMutation::Upgrade(target) => supervisor.preflight_upgrade(&agent_id, target),
        PreparedMutation::Rollback => supervisor.preflight_rollback(&agent_id),
    };
    if let Err(error) = preflight {
        let refreshed = agent_status_locked(&state, &supervisor, &agent_id).ok();
        return safe_rejection(
            error,
            refreshed.or(Some(actual)),
            /*mutation_started*/ false,
        );
    }

    let next_revision = match supervisor.next_control_revision(&agent_id) {
        Ok(revision) => revision,
        Err(error) => return safe_rejection(error, Some(actual), /*mutation_started*/ false),
    };
    if let Err(error) = supervisor.set_control_revision(&agent_id, next_revision) {
        return safe_rejection(error, Some(actual), /*mutation_started*/ false);
    }

    let mutation = match prepared {
        PreparedMutation::Start(target) => {
            supervisor.start_release(&agent_id, target, Instant::now())
        }
        PreparedMutation::Drain => supervisor.drain(&agent_id, Instant::now()),
        PreparedMutation::Stop => supervisor.stop(&agent_id, Instant::now()),
        PreparedMutation::Kill => supervisor.kill(&agent_id),
        PreparedMutation::Restart => supervisor.restart(&agent_id, Instant::now()),
        PreparedMutation::Upgrade(target) => supervisor.upgrade(&agent_id, target, Instant::now()),
        PreparedMutation::Rollback => supervisor.rollback(&agent_id, Instant::now()),
    };
    let post = agent_status_locked(&state, &supervisor, &agent_id).ok();
    if let Err(_error) = mutation {
        return error_payload(
            "operation_indeterminate",
            "operation outcome is indeterminate; refresh before retry",
            post,
        );
    }
    let Some(agent) = post else {
        return error_payload(
            "operation_indeterminate",
            "operation outcome is indeterminate; refresh before retry",
            /*actual*/ None,
        );
    };
    SupervisordPayload::MutationAccepted {
        operation,
        accepted_state_digest,
        agent,
        production_receipt: None,
    }
}

#[cfg(unix)]
enum PreparedMutation {
    Start(AgentRelease),
    Drain,
    Stop,
    Kill,
    Restart,
    Upgrade(AgentRelease),
    Rollback,
}

#[cfg(unix)]
fn resolve_release_outside_lock<D: ProcessDriver>(
    state: Arc<DaemonState<D>>,
    agent_id: AgentId,
    release_id: ReleaseId,
) -> Result<AgentRelease, SupervisorError> {
    // Dispatch already runs on the blocking owner worker. A second blocking
    // job could be queued behind that worker when the pool has no free thread,
    // preventing Start/Upgrade, ticks and shutdown from ever completing.
    // This read remains outside the lifecycle mutex and creates no new writer.
    let release = state.registry.resolve_release(&agent_id, &release_id)?;
    AgentRelease::try_from(release)
}

#[cfg(unix)]
async fn agent_status<D: ProcessDriver>(
    state: &DaemonState<D>,
    agent_id: &AgentId,
) -> Result<SupervisordAgentStatus, SupervisorError> {
    let supervisor = state.supervisor.lock().await;
    agent_status_locked(state, &supervisor, agent_id)
}

#[cfg(unix)]
fn agent_status_locked<D: ProcessDriver>(
    state: &DaemonState<D>,
    supervisor: &Supervisor<D>,
    agent_id: &AgentId,
) -> Result<SupervisordAgentStatus, SupervisorError> {
    let record = state
        .registry
        .load()?
        .agent(agent_id)
        .cloned()
        .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
    status_from(
        &state.supervisor_epoch,
        &record,
        supervisor.snapshot(agent_id),
    )
}

#[cfg(any(unix, test))]
pub(crate) fn status_from(
    supervisor_epoch: &SupervisorEpoch,
    record: &codex_hepta_fleet::AgentRecord,
    snapshot: Option<AgentSupervisorSnapshot>,
) -> Result<SupervisordAgentStatus, SupervisorError> {
    let agent_id = record.manifest.agent_id.clone();
    let snapshot = snapshot.ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
    let current_release = snapshot
        .active_release
        .clone()
        .map(ReleaseId::parse)
        .transpose()?;
    let previous_release = snapshot
        .previous_release
        .clone()
        .map(ReleaseId::parse)
        .transpose()?;
    let serving_eligible = record.lifecycle.lifecycle == AgentLifecycle::Running
        && snapshot.runtime_generation == Some(record.lifecycle.generation)
        && !snapshot.runtime_fenced;
    let mut status = SupervisordAgentStatus {
        agent_id: agent_id.clone(),
        lifecycle: record.lifecycle.lifecycle,
        lifecycle_generation: record.lifecycle.generation,
        active: snapshot.active,
        healthy: snapshot.healthy && serving_eligible,
        process_id: snapshot.process_system_id,
        spawn_generation: snapshot.spawn_generation,
        runtime_generation: snapshot.runtime_generation,
        current_release: current_release.clone(),
        previous_release: previous_release.clone(),
        release_change_pending: snapshot.release_change_pending,
        control_fence: SupervisordControlFence {
            agent_id,
            supervisor_epoch: supervisor_epoch.clone(),
            lifecycle: record.lifecycle.lifecycle,
            lifecycle_generation: record.lifecycle.generation,
            spawn_generation: snapshot.spawn_generation,
            runtime_generation: snapshot.runtime_generation,
            current_release,
            previous_release,
            release_change_pending: snapshot.release_change_pending,
            state_digest: ControlStateDigest::from_bytes([0_u8; 32]),
        },
        matrix: SupervisordMatrixStatus {
            configured: snapshot.matrix.configured,
            active: snapshot.matrix.active,
            healthy: snapshot.matrix.healthy
                && serving_eligible
                && snapshot.active
                && snapshot.matrix.attached_agent_generation == snapshot.spawn_generation,
            degraded: snapshot.matrix.degraded,
            process_id: snapshot.matrix.process_system_id,
            attached_agent_generation: snapshot.matrix.attached_agent_generation,
            binding_revision: snapshot.matrix.binding_revision,
            restart_attempt: snapshot.matrix.restart_attempt,
            // Driver errors can contain hostile path text. Retain the exact
            // error in the live CAS material, but bound and clean its display.
            last_error: snapshot.matrix.last_error.as_deref().map(|message| {
                crate::runtime::bounded_message(
                    message
                        .chars()
                        .map(|character| {
                            if character.is_control()
                                || matches!(
                                    character,
                                    '\u{061c}'
                                        | '\u{200e}'..='\u{200f}'
                                        | '\u{202a}'..='\u{202e}'
                                        | '\u{2066}'..='\u{2069}'
                                )
                            {
                                ' '
                            } else {
                                character
                            }
                        })
                        .collect(),
                )
            }),
        },
    };
    status.control_fence.state_digest =
        control_state_digest(&status.control_fence, &status, record, &snapshot)?;
    Ok(status)
}

#[cfg(any(unix, test))]
fn control_fence_matches(
    provided: &SupervisordControlFence,
    actual: &SupervisordControlFence,
) -> bool {
    let (Ok(provided_identity), Ok(actual_identity)) = (
        fence_identity_digest(provided),
        fence_identity_digest(actual),
    ) else {
        return false;
    };
    let identity_matches = constant_time_eq_32(&provided_identity, &actual_identity);
    let state_matches = constant_time_eq_32(
        &provided.state_digest.decode(),
        &actual.state_digest.decode(),
    );
    identity_matches & state_matches
}

#[derive(Serialize)]
#[cfg(any(unix, test))]
struct FenceIdentity<'a> {
    agent_id: &'a AgentId,
    supervisor_epoch: &'a SupervisorEpoch,
    lifecycle: AgentLifecycle,
    lifecycle_generation: u64,
    spawn_generation: Option<u64>,
    runtime_generation: Option<u64>,
    current_release: &'a Option<ReleaseId>,
    previous_release: &'a Option<ReleaseId>,
    release_change_pending: bool,
}

#[cfg(any(unix, test))]
impl<'a> From<&'a SupervisordControlFence> for FenceIdentity<'a> {
    fn from(fence: &'a SupervisordControlFence) -> Self {
        Self {
            agent_id: &fence.agent_id,
            supervisor_epoch: &fence.supervisor_epoch,
            lifecycle: fence.lifecycle,
            lifecycle_generation: fence.lifecycle_generation,
            spawn_generation: fence.spawn_generation,
            runtime_generation: fence.runtime_generation,
            current_release: &fence.current_release,
            previous_release: &fence.previous_release,
            release_change_pending: fence.release_change_pending,
        }
    }
}

#[derive(Serialize)]
#[cfg(any(unix, test))]
struct HiddenControlState<'a> {
    control_revision: u64,
    active: bool,
    healthy: bool,
    process_id: Option<u64>,
    release_state_generation: u64,
    registry_current_release: &'a Option<ReleaseId>,
    registry_previous_release: &'a Option<ReleaseId>,
    restart_pending: bool,
    restart_attempt: u32,
    runtime_phase: &'a Option<crate::ControlRuntimePhase>,
    runtime_release: &'a Option<String>,
    runtime_incarnation: &'a Option<String>,
    runtime_fenced: bool,
    release_change: &'a Option<crate::ControlReleaseChange>,
    has_last_command: bool,
    matrix: &'a SupervisordMatrixStatus,
    matrix_runtime_healthy: bool,
    matrix_last_error: &'a Option<String>,
}

#[derive(Serialize)]
#[cfg(any(unix, test))]
struct ControlStateMaterial<'a> {
    fence: FenceIdentity<'a>,
    hidden: HiddenControlState<'a>,
}

#[cfg(any(unix, test))]
fn control_state_digest(
    fence: &SupervisordControlFence,
    status: &SupervisordAgentStatus,
    record: &codex_hepta_fleet::AgentRecord,
    snapshot: &AgentSupervisorSnapshot,
) -> Result<ControlStateDigest, SupervisorError> {
    let material = ControlStateMaterial {
        fence: FenceIdentity::from(fence),
        hidden: HiddenControlState {
            control_revision: snapshot.control_revision,
            active: status.active,
            healthy: snapshot.healthy,
            process_id: status.process_id,
            release_state_generation: snapshot.release_state_generation,
            registry_current_release: &record.release_state.current,
            registry_previous_release: &record.release_state.previous,
            restart_pending: snapshot.restart_pending,
            restart_attempt: snapshot.restart_attempt,
            runtime_phase: &snapshot.runtime_phase,
            runtime_release: &snapshot.runtime_release,
            runtime_incarnation: &snapshot.runtime_incarnation,
            runtime_fenced: snapshot.runtime_fenced,
            release_change: &snapshot.release_change,
            has_last_command: snapshot.has_last_command,
            matrix: &status.matrix,
            matrix_runtime_healthy: snapshot.matrix.healthy,
            matrix_last_error: &snapshot.matrix.last_error,
        },
    };
    let encoded = serde_json::to_vec(&material)
        .map_err(|_| SupervisorError::Invalid("encode control state digest".to_string()))?;
    let mut hasher = Sha256::new();
    hasher.update(CONTROL_STATE_DIGEST_DOMAIN);
    hasher.update(encoded);
    Ok(ControlStateDigest::from_bytes(hasher.finalize().into()))
}

#[cfg(any(unix, test))]
fn fence_identity_digest(fence: &SupervisordControlFence) -> Result<[u8; 32], serde_json::Error> {
    let encoded = serde_json::to_vec(&FenceIdentity::from(fence))?;
    let mut hasher = Sha256::new();
    hasher.update(CONTROL_FENCE_IDENTITY_DOMAIN);
    hasher.update(encoded);
    Ok(hasher.finalize().into())
}

#[cfg(any(unix, test))]
fn safe_rejection(
    error: SupervisorError,
    actual: Option<SupervisordAgentStatus>,
    mutation_started: bool,
) -> SupervisordPayload {
    if mutation_started {
        return error_payload(
            "operation_indeterminate",
            "operation outcome is indeterminate; refresh before retry",
            actual,
        );
    }
    match error {
        SupervisorError::UnknownAgent(_) => {
            error_payload(
                "unknown_agent",
                "selected Agent is not registered",
                /*actual*/ None,
            )
        }
        SupervisorError::Registry(FleetRegistryError::UnknownRelease(_)) => error_payload(
            "release_not_found",
            "selected release is not installed",
            actual,
        ),
        SupervisorError::Registry(FleetRegistryError::ReleaseNotAllowed { .. }) => error_payload(
            "release_not_allowed",
            "selected release is not allowed for this Agent",
            actual,
        ),
        SupervisorError::Registry(FleetRegistryError::ReleaseRevoked { .. }) => error_payload(
            "release_revoked",
            "selected release is revoked for this Agent",
            actual,
        ),
        SupervisorError::NoPreviousRelease(_) => error_payload(
            "no_previous_release",
            "selected Agent has no previous release",
            actual,
        ),
        SupervisorError::NoPreviousCommand(_) => error_payload(
            "no_previous_command",
            "selected Agent has no runnable release",
            actual,
        ),
        SupervisorError::ReleaseChangePending(_) => error_payload(
            "release_change_pending",
            "selected Agent already has a lifecycle change in progress",
            actual,
        ),
        SupervisorError::RestartBudgetExhausted(_) => error_payload(
            "restart_budget_exhausted",
            "selected Agent exhausted its bounded restart budget",
            actual,
        ),
        SupervisorError::TargetReleaseUnchanged(_) => error_payload(
            "target_release_unchanged",
            "selected release is already active for this Agent",
            actual,
        ),
        SupervisorError::UnresolvedLease(_) => error_payload(
            "unresolved_lease",
            "selected Agent has an unresolved process lease",
            actual,
        ),
        SupervisorError::GenerationFence { .. }
        | SupervisorError::Registry(FleetRegistryError::StaleGeneration { .. })
        | SupervisorError::Registry(FleetRegistryError::StaleReleaseGeneration { .. }) => {
            error_payload(
                "generation_fenced",
                "selected Agent generation changed; refresh before retry",
                actual,
            )
        }
        SupervisorError::Registry(FleetRegistryError::InvalidTransition { .. })
        | SupervisorError::AlreadyActive(_)
        | SupervisorError::Invalid(_) => error_payload(
            "invalid_transition",
            "selected Agent cannot transition from its current state",
            actual,
        ),
        SupervisorError::Driver { .. } => error_payload(
            "control_state_unavailable",
            "Agent control state is unavailable; refresh before retry",
            actual,
        ),
        SupervisorError::ProductionAuthority(_) => error_payload(
            "production_authority_rejected",
            "signed production authority grant was rejected",
            actual,
        ),
        SupervisorError::ProductionAuthorityFeatureDisabled => error_payload(
            "production_authority_unavailable",
            "signed production mutations are disabled in this build",
            actual,
        ),
        SupervisorError::SignedIntentRecoveryRequired(_) => error_payload(
            "signed_intent_recovery_required",
            "a prior signed lifecycle operation requires recovery",
            actual,
        ),
        SupervisorError::SignedMutationIndeterminate(_) => error_payload(
            "operation_indeterminate",
            "signed operation outcome is indeterminate; refresh before retry",
            actual,
        ),
        SupervisorError::CorruptLease(_)
        | SupervisorError::Registry(_)
        | SupervisorError::Io(_) => error_payload(
            "control_state_unavailable",
            "Agent control state is unavailable; refresh before retry",
            actual,
        ),
    }
}

#[cfg(any(unix, test))]
fn error_payload(
    code: &str,
    message: &str,
    actual: Option<SupervisordAgentStatus>,
) -> SupervisordPayload {
    SupervisordPayload::Error {
        code: code.to_string(),
        message: message.to_string(),
        actual,
    }
}

#[cfg(unix)]
fn error_response(
    request_id: u64,
    code: &str,
    message: &str,
    actual: Option<SupervisordAgentStatus>,
) -> SupervisordResponse {
    SupervisordResponse {
        schema_version: SUPERVISORD_CONTROL_SCHEMA_VERSION,
        request_id,
        payload: SupervisordPayload::Error {
            code: code.to_string(),
            message: message.to_string(),
            actual,
        },
    }
}

#[cfg(unix)]
async fn prepare_socket(socket_path: &Path) -> Result<(), SupervisorError> {
    let parent = socket_path.parent().ok_or_else(|| {
        SupervisorError::Invalid("supervisord socket has no parent directory".to_string())
    })?;
    codex_uds::prepare_private_socket_directory(parent).await?;
    match UnixStream::connect(socket_path).await {
        Ok(_) => {
            return Err(SupervisorError::Io(std::io::Error::new(
                ErrorKind::AddrInUse,
                format!(
                    "supervisord socket is already live at {}",
                    socket_path.display()
                ),
            )));
        }
        Err(error) if error.kind() == ErrorKind::NotFound => return Ok(()),
        Err(error) if error.kind() == ErrorKind::ConnectionRefused => {}
        Err(_error) if !socket_path.exists() => return Ok(()),
        Err(error) => return Err(error.into()),
    }
    if codex_uds::is_stale_socket_path(socket_path).await? {
        tokio::fs::remove_file(socket_path).await?;
        Ok(())
    } else {
        Err(SupervisorError::Io(std::io::Error::new(
            ErrorKind::AlreadyExists,
            format!(
                "supervisord socket path is not a stale socket: {}",
                socket_path.display()
            ),
        )))
    }
}

#[cfg(unix)]
async fn set_owner_only(path: &Path) -> Result<(), SupervisorError> {
    use std::os::unix::fs::PermissionsExt;
    tokio::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600)).await?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use codex_hepta_contracts::AgentId;
    use codex_hepta_fleet::AgentLifecycle;
    use codex_hepta_fleet::AgentManifest;
    use codex_hepta_fleet::FleetRegistry;
    use codex_hepta_fleet::ReleaseId;
    use codex_hepta_fleet::ResourceBudget;
    use codex_hepta_fleet::WorkspaceBinding;
    use codex_hepta_paths::HeptaFleetRoot;

    use super::*;
    use crate::MatrixSupervisorSnapshot;

    const AGENT_ID: &str = "018f4f72-5f8f-7cc1-8f55-df9fb3aa2c12";
    const PEER_AGENT_ID: &str = "019153a4-3088-7e03-a56a-9b1964f75dd3";
    const EPOCH: &str = "018f4f72-5f8f-4cc1-8f55-df9fb3aa2c12";
    const PEER_EPOCH: &str = "019153a4-3088-4e03-a56a-9b1964f75dd3";
    const DIGEST: &str = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    const PEER_DIGEST: &str = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";

    fn fence() -> SupervisordControlFence {
        SupervisordControlFence {
            agent_id: AgentId::parse(AGENT_ID).expect("fixed AgentId"),
            supervisor_epoch: SupervisorEpoch::parse(EPOCH).expect("fixed epoch"),
            lifecycle: AgentLifecycle::Running,
            lifecycle_generation: 7,
            spawn_generation: Some(5),
            runtime_generation: Some(7),
            current_release: Some(ReleaseId::parse("agentd-v1").expect("fixed release")),
            previous_release: None,
            release_change_pending: false,
            state_digest: ControlStateDigest::parse(DIGEST).expect("fixed digest"),
        }
    }

    #[test]
    fn every_external_fence_field_participates_in_constant_time_cas_identity() {
        let actual = fence();
        assert!(control_fence_matches(&actual, &actual));

        let mut stale_fences = Vec::new();
        let mut stale = actual.clone();
        stale.agent_id = AgentId::parse(PEER_AGENT_ID).expect("fixed peer AgentId");
        stale_fences.push(stale);
        let mut stale = actual.clone();
        stale.supervisor_epoch = SupervisorEpoch::parse(PEER_EPOCH).expect("fixed peer epoch");
        stale_fences.push(stale);
        let mut stale = actual.clone();
        stale.lifecycle = AgentLifecycle::Draining;
        stale_fences.push(stale);
        let mut stale = actual.clone();
        stale.lifecycle_generation += 1;
        stale_fences.push(stale);
        let mut stale = actual.clone();
        stale.spawn_generation = Some(6);
        stale_fences.push(stale);
        let mut stale = actual.clone();
        stale.runtime_generation = Some(8);
        stale_fences.push(stale);
        let mut stale = actual.clone();
        stale.current_release = Some(ReleaseId::parse("agentd-v2").expect("fixed release"));
        stale_fences.push(stale);
        let mut stale = actual.clone();
        stale.previous_release =
            Some(ReleaseId::parse("agentd-v0").expect("fixed previous release"));
        stale_fences.push(stale);
        let mut stale = actual.clone();
        stale.release_change_pending = true;
        stale_fences.push(stale);
        let mut stale = actual.clone();
        stale.state_digest = ControlStateDigest::parse(PEER_DIGEST).expect("fixed peer digest");
        stale_fences.push(stale);

        for stale in stale_fences {
            assert!(
                !control_fence_matches(&stale, &actual),
                "accepted {stale:?}"
            );
        }
    }

    #[test]
    fn every_matrix_control_field_participates_in_state_digest() {
        let baseline = MatrixSupervisorSnapshot {
            configured: true,
            active: true,
            healthy: true,
            degraded: false,
            process_system_id: Some(4321),
            attached_agent_generation: Some(7),
            binding_revision: Some(11),
            restart_attempt: 2,
            last_error: Some("bounded fault".to_string()),
        };
        let baseline_digest = matrix_control_digest(baseline.clone());

        let mut variants = Vec::new();
        let mut changed = baseline.clone();
        changed.configured = false;
        variants.push(changed);
        let mut changed = baseline.clone();
        changed.active = false;
        variants.push(changed);
        let mut changed = baseline.clone();
        changed.healthy = false;
        variants.push(changed);
        let mut changed = baseline.clone();
        changed.degraded = true;
        variants.push(changed);
        let mut changed = baseline.clone();
        changed.process_system_id = Some(4322);
        variants.push(changed);
        let mut changed = baseline.clone();
        changed.attached_agent_generation = Some(8);
        variants.push(changed);
        let mut changed = baseline.clone();
        changed.binding_revision = Some(12);
        variants.push(changed);
        let mut changed = baseline.clone();
        changed.restart_attempt = 3;
        variants.push(changed);
        let mut changed = baseline;
        changed.last_error = Some("different bounded fault".to_string());
        variants.push(changed);

        for changed in variants {
            assert_ne!(matrix_control_digest(changed), baseline_digest);
        }
    }

    fn matrix_control_digest(matrix: MatrixSupervisorSnapshot) -> ControlStateDigest {
        matrix_control_status(matrix).control_fence.state_digest
    }

    #[test]
    fn matrix_diagnostics_are_bounded_safe_and_keep_exact_live_cas_identity() {
        let baseline = MatrixSupervisorSnapshot {
            configured: true,
            active: false,
            healthy: false,
            degraded: true,
            process_system_id: None,
            attached_agent_generation: None,
            binding_revision: None,
            restart_attempt: 1,
            last_error: Some(format!("hostile\n\u{202e}{}", "多".repeat(512))),
        };
        let status = matrix_control_status(baseline.clone());
        let message = status.matrix.last_error.as_deref().expect("diagnostic");
        assert!(message.len() <= crate::runtime::MAX_FAULT_BYTES);
        assert!(!message.contains('\n') && !message.contains('\u{202e}'));
        let response =
            crate::robrix_protocol::RobrixSupervisordResponse::try_from(SupervisordResponse {
                schema_version: SUPERVISORD_CONTROL_SCHEMA_VERSION,
                request_id: 1,
                payload: SupervisordPayload::Agent(status.clone()),
            })
            .expect("read-only projection");
        response.validate(1).expect("safe bounded diagnostic");

        let mut changed = baseline;
        changed.last_error.as_mut().expect("diagnostic").push('x');
        let changed = matrix_control_status(changed);
        assert_eq!(changed.matrix, status.matrix);
        assert_ne!(
            changed.control_fence.state_digest,
            status.control_fence.state_digest
        );
    }

    fn matrix_control_status(matrix: MatrixSupervisorSnapshot) -> SupervisordAgentStatus {
        let temp = tempfile::tempdir().expect("create temporary fleet");
        let fleet_root =
            HeptaFleetRoot::parse(temp.path().join("fleet")).expect("parse temporary fleet root");
        let registry = FleetRegistry::initialize(fleet_root.clone()).expect("initialize registry");
        let workspace = temp.path().join("workspace");
        std::fs::create_dir(&workspace).expect("create workspace");
        let agent_id = AgentId::parse(AGENT_ID).expect("fixed AgentId");
        let record = registry
            .register(
                AgentManifest::new(
                    agent_id,
                    WorkspaceBinding::new(
                        workspace.canonicalize().expect("canonical workspace"),
                        &fleet_root,
                    )
                    .expect("workspace binding"),
                    ResourceBudget::local_default(),
                )
                .expect("agent manifest"),
            )
            .expect("register agent");
        let snapshot = AgentSupervisorSnapshot {
            active: false,
            healthy: false,
            runtime_generation: None,
            spawn_generation: None,
            process_system_id: None,
            active_release: None,
            previous_release: None,
            release_change_pending: false,
            matrix,
            events: Vec::new(),
            logs: Vec::new(),
            control_revision: 0,
            restart_pending: false,
            restart_attempt: 0,
            release_state_generation: record.release_state.generation,
            runtime_phase: None,
            runtime_release: None,
            runtime_incarnation: None,
            runtime_fenced: false,
            release_change: None,
            has_last_command: false,
        };
        status_from(
            &SupervisorEpoch::parse(EPOCH).expect("fixed epoch"),
            &record,
            Some(snapshot),
        )
        .expect("derive status")
    }

    #[test]
    fn wire_errors_are_closed_and_never_expose_driver_or_filesystem_detail() {
        let agent_id = AgentId::parse(AGENT_ID).expect("fixed AgentId");
        let cases = [
            safe_rejection(
                SupervisorError::UnknownAgent(agent_id.clone()),
                /*actual*/ None,
                /*mutation_started*/ false,
            ),
            safe_rejection(
                SupervisorError::NoPreviousRelease(agent_id.clone()),
                /*actual*/ None,
                /*mutation_started*/ false,
            ),
            safe_rejection(
                SupervisorError::NoPreviousCommand(agent_id.clone()),
                /*actual*/ None,
                /*mutation_started*/ false,
            ),
            safe_rejection(
                SupervisorError::ReleaseChangePending(agent_id.clone()),
                /*actual*/ None,
                /*mutation_started*/ false,
            ),
            safe_rejection(
                SupervisorError::UnresolvedLease(agent_id.clone()),
                /*actual*/ None,
                /*mutation_started*/ false,
            ),
            safe_rejection(
                SupervisorError::GenerationFence {
                    agent_id: agent_id.clone(),
                    runtime: 1,
                    registry: 2,
                },
                /*actual*/ None,
                /*mutation_started*/ false,
            ),
            safe_rejection(
                SupervisorError::TargetReleaseUnchanged(agent_id.clone()),
                /*actual*/ None,
                /*mutation_started*/ false,
            ),
            safe_rejection(
                SupervisorError::Driver {
                    agent_id: agent_id.clone(),
                    message: "/secret/bin/agentd --token raw-driver-secret".to_string(),
                },
                /*actual*/ None,
                /*mutation_started*/ false,
            ),
            safe_rejection(
                SupervisorError::SignedMutationIndeterminate(agent_id),
                /*actual*/ None,
                /*mutation_started*/ false,
            ),
        ];
        let allowed = [
            "unknown_agent",
            "invalid_transition",
            "release_change_pending",
            "release_not_found",
            "release_not_allowed",
            "target_release_unchanged",
            "no_previous_release",
            "no_previous_command",
            "unresolved_lease",
            "generation_fenced",
            "control_state_unavailable",
            "operation_indeterminate",
            "invalid_frame",
            "unsupported_schema",
        ];
        for payload in cases {
            let SupervisordPayload::Error { code, .. } = &payload else {
                panic!("safe rejection returned a non-error payload");
            };
            assert!(
                allowed.contains(&code.as_str()),
                "unapproved wire code {code}"
            );
            let encoded = serde_json::to_string(&payload).expect("serialize safe error");
            assert!(!encoded.contains("/secret"));
            assert!(!encoded.contains("raw-driver-secret"));
            assert!(!encoded.contains("--token"));
        }
    }

    #[cfg(unix)]
    #[tokio::test(flavor = "current_thread")]
    async fn unresolved_signed_intent_keeps_daemon_reachable_but_not_ready() {
        let temp = tempfile::tempdir().expect("create temporary fleet");
        let fleet_root = HeptaFleetRoot::parse(temp.path().join("fleet")).expect("fleet root");
        let registry = FleetRegistry::initialize(fleet_root.clone()).expect("initialize registry");
        let workspace = temp.path().join("workspace");
        std::fs::create_dir(&workspace).expect("create workspace");
        let agent_id = AgentId::parse(AGENT_ID).expect("fixed AgentId");
        let record = registry
            .register(
                AgentManifest::new(
                    agent_id.clone(),
                    WorkspaceBinding::new(
                        workspace.canonicalize().expect("canonical workspace"),
                        &fleet_root,
                    )
                    .expect("workspace binding"),
                    ResourceBudget::local_default(),
                )
                .expect("agent manifest"),
            )
            .expect("register agent");
        registry
            .compare_and_transition(
                &agent_id,
                record.lifecycle.generation,
                AgentLifecycle::Starting,
            )
            .expect("advance lifecycle generation");
        let record = registry
            .load()
            .expect("reload transitioned agent")
            .agent(&agent_id)
            .cloned()
            .expect("registered agent");
        let intent = crate::signed_intent::SignedSupervisorIntent::new(
            codex_hepta_contracts::Sha256Digest::for_bytes(b"unresolved-grant"),
            agent_id.to_string(),
            crate::H7H89ProductionTransition::Upgrade,
            "release-v1",
            "release-v2",
            0,
            record.lifecycle.generation,
            1,
            crate::signed_intent::SignedIntentStatus::Queued,
        )
        .expect("signed intent");
        crate::signed_intent::write_intent(record.layout.run_root(), &intent)
            .expect("persist signed intent");

        let cancellation = CancellationToken::new();
        let daemon = tokio::spawn(run_supervisord_inner(
            fleet_root.clone(),
            cancellation.clone(),
            None,
        ));
        let client =
            crate::SupervisordClient::new(registry.layout().supervisor_socket().to_path_buf())
                .expect("client");
        let deadline = Instant::now() + Duration::from_secs(2);
        let health = loop {
            match client.health().await {
                Ok(health) => break health,
                Err(error) => {
                    assert!(
                        Instant::now() < deadline,
                        "recovery daemon did not bind a reachable socket: {error}"
                    );
                    tokio::time::sleep(Duration::from_millis(10)).await;
                }
            }
        };
        assert!(
            !health.ready,
            "unresolved production recovery must keep daemon health not-ready"
        );

        let mutation = client
            .production_mutation_status(agent_id.clone())
            .await
            .expect("query recovery status")
            .expect("durable recovery status");
        assert_eq!(
            mutation.receipt.status,
            crate::ProductionMutationStatus::RecoveryRequired
        );

        let status = client
            .snapshot(agent_id.clone())
            .await
            .expect("recovery snapshot");
        let restart_error = client
            .restart(status.control_fence)
            .await
            .expect_err("ordinary mutation must remain blocked during production recovery");
        assert!(
            restart_error
                .to_string()
                .contains("signed_intent_recovery_required"),
            "unexpected recovery rejection: {restart_error}"
        );

        cancellation.cancel();
        daemon
            .await
            .expect("join recovery daemon")
            .expect("shutdown recovery daemon");
    }
}

#[cfg(all(test, not(unix)))]
#[path = "daemon_platform_tests.rs"]
mod platform_tests;

#[cfg(all(test, unix))]
#[path = "daemon_shutdown_tests.rs"]
mod shutdown_tests;

#[cfg(all(test, unix))]
#[path = "daemon_startup_tests.rs"]
mod startup_tests;

#[cfg(all(test, unix))]
#[path = "daemon_authority_tests.rs"]
mod authority_tests;
