use std::collections::BTreeMap;
use std::time::Instant;

use codex_hepta_contracts::AgentId;
use codex_hepta_contracts::Sha256Digest;
use codex_hepta_fleet::AgentLifecycle;
use codex_hepta_fleet::AgentRecord;
use codex_hepta_fleet::FleetRegistry;
use codex_hepta_fleet::ReleaseId;
use codex_hepta_memory::H7SignedArtifactEnvelope;

use crate::AgentCommand;
use crate::AgentFault;
use crate::AgentRelease;
use crate::AgentSupervisorSnapshot;
use crate::ControlReleaseChange;
use crate::ControlReleaseChangePhase;
use crate::ControlRuntimePhase;
use crate::ManagedProcess;
use crate::MatrixSupervisorSnapshot;
use crate::ProcessDriver;
use crate::SupervisorConfig;
use crate::SupervisorError;
use crate::SupervisorEventKind;
use crate::TickReport;
use crate::release_transaction::DurableReleaseTransaction;
use crate::release_transaction::ReleaseTransactionPhase;
use crate::release_transaction::read_release_transaction;
use crate::release_transaction::write_release_transaction;
use crate::runtime::AgentSlot;
use crate::runtime::RuntimePhase;
use crate::runtime::bounded_message;
use crate::signed_authority::H7H89ProductionGrant;
use crate::signed_authority::H7H89ProductionGrantVerifier;
use crate::signed_authority::H7H89ProductionTransition;
use crate::signed_authority::ProductionMutationReceipt;
use crate::signed_authority::ProductionMutationState;
use crate::signed_authority::ProductionRecoveryDecision;
use crate::signed_authority::ProductionRecoveryOutcome;
use crate::signed_intent::SignedIntentStatus;
use crate::signed_intent::SignedSupervisorIntent;
use crate::signed_intent::read_intent;
use crate::signed_intent::write_intent;

/// Lifecycle-only controller with one process handle and bounded buffers per agent.
pub struct Supervisor<D: ProcessDriver> {
    pub(crate) registry: FleetRegistry,
    pub(crate) driver: D,
    pub(crate) config: SupervisorConfig,
    slots: BTreeMap<AgentId, AgentSlot<D::Process>>,
}

#[cfg(test)]
#[path = "supervisor_tests.rs"]
mod tests;

#[path = "recovery_denial.rs"]
mod recovery_denial;

#[path = "constructor_recovery_probe.rs"]
mod recovery_probe;

impl<D: ProcessDriver> Supervisor<D> {
    pub fn recover(
        registry: FleetRegistry,
        driver: D,
        config: SupervisorConfig,
        now: Instant,
    ) -> Result<(Self, TickReport), SupervisorError> {
        config.validate()?;
        let snapshot = registry.load()?;
        let slots = snapshot
            .agents
            .keys()
            .cloned()
            .map(|agent_id| (agent_id, AgentSlot::new(&config)))
            .collect();
        let mut supervisor = Self {
            registry,
            driver,
            config,
            slots,
        };
        let mut report = TickReport::default();
        for (agent_id, record) in snapshot.agents {
            let result = supervisor.with_slot(&agent_id, |supervisor, slot| {
                let mut faults = supervisor.validate_durable_recovery(&agent_id, &record);
                if let Err(error) = supervisor.restore_release_state(&agent_id, slot, &record) {
                    faults.push(error);
                }
                if let Some(error) = faults.first() {
                    // Deny semantic replay before acquisition, while leaving
                    // both independent lease-bound adoption attempts enabled.
                    slot.recovery_blocker = Some(bounded_message(error.to_string()));
                }
                // Even failed semantic preparation cannot skip independent
                // lease-bound acquisition of main and Matrix ownership.
                if let Err(error) = supervisor.recover_slot(&agent_id, slot, &record, now) {
                    faults.push(error);
                }
                // A failed signal on an admitted, exact owned incarnation is
                // a control retry, not corrupt durable recovery evidence.
                // recover_slot marks all admission/hydration failures itself.
                for (restore, evidence_present) in [
                    Self::recover_restart_budget,
                    Self::recover_release_transaction,
                ]
                .into_iter()
                .zip([
                    recovery_probe::restart_required(record.layout.run_root()),
                    recovery_probe::release_required(record.layout.run_root()),
                ]) {
                    if slot.recovery_blocker.is_some() {
                        break;
                    }
                    if !evidence_present {
                        continue;
                    }
                    if let Err(error) = restore(supervisor, &agent_id, slot, now) {
                        if !Self::recovery_control_fault_is_retryable(slot, &error) {
                            slot.recovery_blocker = Some(bounded_message(error.to_string()));
                        }
                        faults.push(error);
                    }
                }
                // A retryable release Drain must not hide independent signed
                // authority recovery. Its exact staged control remains owned.
                if slot.recovery_blocker.is_none()
                    && let Err(error) = supervisor.recover_signed_intent(&agent_id, slot, &record)
                {
                    slot.recovery_blocker = Some(bounded_message(error.to_string()));
                    faults.push(error);
                }
                if slot.recovery_blocker.is_some()
                    && let Some(error) = faults.first()
                {
                    supervisor.deny_failed_recovery(&agent_id, slot, error, now);
                }
                Ok(faults)
            });
            match result {
                Ok(faults) => {
                    for error in faults {
                        supervisor.record_fault(&agent_id, &error, &mut report);
                    }
                }
                Err(error) => return Err(error),
            }
        }
        Ok((supervisor, report))
    }

    pub fn snapshot(&self, agent_id: &AgentId) -> Option<AgentSupervisorSnapshot> {
        let mut snapshot = self.metadata_snapshot(agent_id)?;
        let slot = self.slots.get(agent_id)?;
        snapshot.events = slot.events.items.iter().cloned().collect();
        snapshot.logs = slot.logs.items.iter().cloned().collect();
        Some(snapshot)
    }

    /// Control observations never consume diagnostic buffers. Keep their
    /// metadata and hidden CAS fields identical to the public full snapshot.
    pub(crate) fn metadata_snapshot(&self, agent_id: &AgentId) -> Option<AgentSupervisorSnapshot> {
        self.slots
            .get(agent_id)
            .map(|slot| AgentSupervisorSnapshot {
                active: slot.runtime.is_some(),
                healthy: slot
                    .runtime
                    .as_ref()
                    .is_some_and(|runtime| runtime.healthy && !runtime.fenced),
                runtime_generation: slot.runtime.as_ref().map(|runtime| runtime.generation),
                spawn_generation: slot
                    .runtime
                    .as_ref()
                    .map(|runtime| runtime.spawn_generation),
                process_system_id: slot
                    .runtime
                    .as_ref()
                    .map(|runtime| runtime.identity.system_id()),
                active_release: slot
                    .active_release
                    .as_ref()
                    .map(|release| release.identity().to_string()),
                previous_release: slot
                    .previous_release
                    .as_ref()
                    .map(|release| release.identity().to_string()),
                release_change_pending: slot.release_change.is_some(),
                matrix: MatrixSupervisorSnapshot {
                    configured: slot.matrix.configured,
                    active: slot.matrix.runtime.is_some(),
                    healthy: slot
                        .matrix
                        .runtime
                        .as_ref()
                        .is_some_and(|runtime| runtime.healthy && !runtime.fenced),
                    degraded: slot.matrix.degraded,
                    process_system_id: slot
                        .matrix
                        .runtime
                        .as_ref()
                        .map(|runtime| runtime.identity.system_id()),
                    attached_agent_generation: slot
                        .matrix
                        .runtime
                        .as_ref()
                        .map(|runtime| runtime.attached_agent_generation),
                    binding_revision: slot
                        .matrix
                        .runtime
                        .as_ref()
                        .map(|runtime| runtime.binding_revision),
                    restart_attempt: slot.matrix.restart_attempt,
                    last_error: slot.matrix.last_error.clone(),
                },
                events: Vec::new(),
                logs: Vec::new(),
                control_revision: slot.control_revision,
                restart_pending: slot.restart_pending,
                restart_attempt: slot.restart_attempt,
                release_state_generation: slot.release_state_generation,
                runtime_phase: slot.runtime.as_ref().map(|runtime| match runtime.phase {
                    crate::runtime::RuntimePhase::AwaitingHealth { .. } => {
                        ControlRuntimePhase::AwaitingHealth
                    }
                    crate::runtime::RuntimePhase::Running => ControlRuntimePhase::Running,
                    crate::runtime::RuntimePhase::Draining { .. } => ControlRuntimePhase::Draining,
                    crate::runtime::RuntimePhase::Stopping { .. } => ControlRuntimePhase::Stopping,
                    crate::runtime::RuntimePhase::Killing => ControlRuntimePhase::Killing,
                }),
                runtime_release: slot
                    .runtime
                    .as_ref()
                    .map(|runtime| runtime.release_id.to_string()),
                runtime_incarnation: slot
                    .runtime
                    .as_ref()
                    .map(|runtime| runtime.identity.incarnation().to_string()),
                runtime_fenced: slot.runtime.as_ref().is_some_and(|runtime| runtime.fenced),
                release_change: slot
                    .release_change
                    .as_ref()
                    .map(|change| ControlReleaseChange {
                        origin_release: change.origin.identity().to_string(),
                        target_release: change.target.identity().to_string(),
                        prior_previous_release: change
                            .prior_previous
                            .as_ref()
                            .map(|release| release.identity().to_string()),
                        phase: match change.phase {
                            crate::runtime::ReleaseChangePhase::WaitingForTargetExit => {
                                ControlReleaseChangePhase::WaitingForTargetExit
                            }
                            crate::runtime::ReleaseChangePhase::TargetStarting => {
                                ControlReleaseChangePhase::TargetStarting
                            }
                            crate::runtime::ReleaseChangePhase::AutomaticRollbackStarting => {
                                ControlReleaseChangePhase::AutomaticRollbackStarting
                            }
                        },
                        explicit_rollback: change.explicit_rollback,
                    }),
                has_last_command: slot.last_command.is_some(),
            })
    }

    pub(crate) fn next_control_revision(&self, agent_id: &AgentId) -> Result<u64, SupervisorError> {
        self.slots
            .get(agent_id)
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?
            .control_revision
            .checked_add(1)
            .ok_or_else(|| SupervisorError::Invalid("control revision overflow".to_string()))
    }

    pub(crate) fn set_control_revision(
        &mut self,
        agent_id: &AgentId,
        revision: u64,
    ) -> Result<(), SupervisorError> {
        let slot = self
            .slots
            .get_mut(agent_id)
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
        if revision != slot.control_revision.saturating_add(1) {
            return Err(SupervisorError::Invalid(
                "control revision must advance exactly once".to_string(),
            ));
        }
        slot.control_revision = revision;
        Ok(())
    }

    fn next_control_revision_for_slot(
        slot: &AgentSlot<D::Process>,
    ) -> Result<u64, SupervisorError> {
        slot.control_revision
            .checked_add(1)
            .ok_or_else(|| SupervisorError::Invalid("control revision overflow".to_string()))
    }

    fn set_control_revision_for_slot(
        slot: &mut AgentSlot<D::Process>,
        revision: u64,
    ) -> Result<(), SupervisorError> {
        if revision != slot.control_revision.saturating_add(1) {
            return Err(SupervisorError::Invalid(
                "control revision must advance exactly once".to_string(),
            ));
        }
        slot.control_revision = revision;
        Ok(())
    }

    #[cfg(unix)]
    pub(crate) fn preflight_drain(&self, agent_id: &AgentId) -> Result<(), SupervisorError> {
        self.ensure_mutation_admitted(agent_id)?;
        let record = self.record(agent_id)?;
        let slot = self
            .slots
            .get(agent_id)
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
        let runtime = slot
            .runtime
            .as_ref()
            .ok_or_else(|| SupervisorError::Invalid(format!("agent {agent_id} is not active")))?;
        if runtime.generation != record.lifecycle.generation {
            return Err(SupervisorError::GenerationFence {
                agent_id: agent_id.clone(),
                runtime: runtime.generation,
                registry: record.lifecycle.generation,
            });
        }
        if !matches!(
            record.lifecycle.lifecycle,
            AgentLifecycle::Running | AgentLifecycle::Draining
        ) {
            return Err(SupervisorError::Invalid(format!(
                "agent {agent_id} cannot drain from {:?}",
                record.lifecycle.lifecycle
            )));
        }
        Ok(())
    }

    fn ensure_start_admitted(&self, agent_id: &AgentId) -> Result<(), SupervisorError> {
        self.ensure_mutation_admitted(agent_id)?;
        let slot = self
            .slots
            .get(agent_id)
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
        if slot.release_change.is_some()
            || slot.restart_pending
            || slot.failed_restart_spawn.is_some()
        {
            return Err(SupervisorError::Invalid(format!(
                "agent {agent_id} has an in-flight release change or restart"
            )));
        }
        Ok(())
    }

    #[cfg(unix)]
    pub(crate) fn preflight_start(&self, agent_id: &AgentId) -> Result<(), SupervisorError> {
        self.ensure_start_admitted(agent_id)?;
        let record = self.record(agent_id)?;
        let slot = self
            .slots
            .get(agent_id)
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
        if slot.runtime.is_some() {
            return Err(SupervisorError::AlreadyActive(agent_id.clone()));
        }
        if crate::lease::read_lease(record.layout.run_root())?.is_some()
            || slot.matrix.runtime.is_some()
            || crate::lease::read_matrix_lease(record.layout.matrixd_process_lease())?.is_some()
        {
            return Err(SupervisorError::UnresolvedLease(agent_id.clone()));
        }
        if !matches!(
            record.lifecycle.lifecycle,
            AgentLifecycle::Stopped | AgentLifecycle::Failed
        ) {
            return Err(SupervisorError::Invalid(format!(
                "agent {agent_id} cannot start from {:?}",
                record.lifecycle.lifecycle
            )));
        }
        Ok(())
    }

    #[cfg(unix)]
    pub(crate) fn preflight_stop_or_kill(&self, agent_id: &AgentId) -> Result<(), SupervisorError> {
        let record = self.record(agent_id)?;
        let slot = self
            .slots
            .get(agent_id)
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
        let runtime = slot
            .runtime
            .as_ref()
            .ok_or_else(|| SupervisorError::Invalid(format!("agent {agent_id} is not active")))?;
        if runtime.generation != record.lifecycle.generation {
            return Err(SupervisorError::GenerationFence {
                agent_id: agent_id.clone(),
                runtime: runtime.generation,
                registry: record.lifecycle.generation,
            });
        }
        Ok(())
    }

    #[cfg(unix)]
    pub(crate) fn preflight_restart(&self, agent_id: &AgentId) -> Result<(), SupervisorError> {
        self.ensure_mutation_admitted(agent_id)?;
        let record = self.record(agent_id)?;
        let available = crate::restart_budget::restart_available(
            record.layout.run_root(),
            self.config.restart_max_attempts,
            self.config.restart_window,
        )
        .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
        if !available {
            return Err(SupervisorError::RestartBudgetExhausted(agent_id.clone()));
        }
        let slot = self
            .slots
            .get(agent_id)
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
        if slot.release_change.is_some()
            || slot.restart_pending
            || slot.failed_restart_spawn.is_some()
        {
            return Err(SupervisorError::ReleaseChangePending(agent_id.clone()));
        }
        if slot.active_release.is_none() && slot.last_command.is_none() {
            return Err(SupervisorError::NoPreviousCommand(agent_id.clone()));
        }
        match slot.runtime.as_ref() {
            Some(runtime) if runtime.generation != record.lifecycle.generation => {
                Err(SupervisorError::GenerationFence {
                    agent_id: agent_id.clone(),
                    runtime: runtime.generation,
                    registry: record.lifecycle.generation,
                })
            }
            Some(_) => Ok(()),
            None => {
                if crate::lease::read_lease(record.layout.run_root())?.is_some() {
                    return Err(SupervisorError::UnresolvedLease(agent_id.clone()));
                }
                if !matches!(
                    record.lifecycle.lifecycle,
                    AgentLifecycle::Stopped | AgentLifecycle::Failed
                ) {
                    return Err(SupervisorError::Invalid(format!(
                        "agent {agent_id} cannot start from {:?}",
                        record.lifecycle.lifecycle
                    )));
                }
                Ok(())
            }
        }
    }

    pub(crate) fn preflight_upgrade(
        &self,
        agent_id: &AgentId,
        target: &AgentRelease,
    ) -> Result<(), SupervisorError> {
        // Resolve again before consuming the caller's control revision so a
        // revoked/withdrawn predecessor remains a clean pre-dispatch rejection.
        self.ensure_mutation_admitted(agent_id)?;
        let slot = self
            .slots
            .get(agent_id)
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
        self.preflight_upgrade_slot(agent_id, slot, target)
    }

    fn preflight_upgrade_slot(
        &self,
        agent_id: &AgentId,
        slot: &AgentSlot<D::Process>,
        target: &AgentRelease,
    ) -> Result<(), SupervisorError> {
        let target = self.refresh_release_for_transition(agent_id, target)?;
        let record = self.record(agent_id)?;
        if slot.release_change.is_some()
            || slot.restart_pending
            || slot
                .release_transaction
                .as_ref()
                .is_some_and(|transaction| !transaction.phase.terminal())
        {
            return Err(SupervisorError::ReleaseChangePending(agent_id.clone()));
        }
        let current = slot.active_release.as_ref().ok_or_else(|| {
            SupervisorError::Invalid(format!(
                "agent {agent_id} has no explicit active release identity"
            ))
        })?;
        if current.identity() == target.identity()
            || (current.command() == target.command()
                && current.matrixd_command() == target.matrixd_command())
        {
            return Err(SupervisorError::TargetReleaseUnchanged(agent_id.clone()));
        }
        if record.lifecycle.lifecycle != AgentLifecycle::Running {
            return Err(SupervisorError::Invalid(format!(
                "agent {agent_id} cannot change release from {:?}",
                record.lifecycle.lifecycle
            )));
        }
        let runtime = slot
            .runtime
            .as_ref()
            .ok_or_else(|| SupervisorError::Invalid(format!("agent {agent_id} is not active")))?;
        if runtime.generation != record.lifecycle.generation {
            return Err(SupervisorError::GenerationFence {
                agent_id: agent_id.clone(),
                runtime: runtime.generation,
                registry: record.lifecycle.generation,
            });
        }
        Ok(())
    }

    #[cfg(unix)]
    pub(crate) fn preflight_rollback(&self, agent_id: &AgentId) -> Result<(), SupervisorError> {
        self.ensure_mutation_admitted(agent_id)?;
        let slot = self
            .slots
            .get(agent_id)
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
        let target = slot
            .previous_release
            .as_ref()
            .ok_or_else(|| SupervisorError::NoPreviousRelease(agent_id.clone()))?;
        self.preflight_upgrade(agent_id, target)
    }

    pub fn agent_ids(&self) -> Vec<AgentId> {
        self.slots.keys().cloned().collect()
    }

    pub fn start(
        &mut self,
        agent_id: &AgentId,
        command: AgentCommand,
        now: Instant,
    ) -> Result<(), SupervisorError> {
        self.ensure_start_admitted(agent_id)?;
        self.with_slot(agent_id, |supervisor, slot| {
            supervisor.start_slot(agent_id, slot, command, now)
        })
    }

    pub fn start_release(
        &mut self,
        agent_id: &AgentId,
        release: AgentRelease,
        now: Instant,
    ) -> Result<(), SupervisorError> {
        self.ensure_start_admitted(agent_id)?;
        self.with_slot(agent_id, |supervisor, slot| {
            supervisor.start_release_slot(agent_id, slot, release, now)
        })
    }

    pub fn drain(&mut self, agent_id: &AgentId, now: Instant) -> Result<(), SupervisorError> {
        self.ensure_mutation_admitted(agent_id)?;
        self.with_slot(agent_id, |supervisor, slot| {
            supervisor.drain_slot(agent_id, slot, now)
        })
    }

    pub fn stop(&mut self, agent_id: &AgentId, now: Instant) -> Result<(), SupervisorError> {
        self.ensure_recovery_unblocked(agent_id)?;
        self.with_slot(agent_id, |supervisor, slot| {
            supervisor.stop_slot(agent_id, slot, now)
        })
    }

    pub fn kill(&mut self, agent_id: &AgentId) -> Result<(), SupervisorError> {
        self.with_slot(agent_id, |supervisor, slot| {
            supervisor.kill_slot(agent_id, slot)
        })
    }

    pub fn restart(&mut self, agent_id: &AgentId, now: Instant) -> Result<(), SupervisorError> {
        self.ensure_mutation_admitted(agent_id)?;
        self.with_slot(agent_id, |supervisor, slot| {
            supervisor.restart_slot(agent_id, slot, now)
        })
    }

    pub fn upgrade(
        &mut self,
        agent_id: &AgentId,
        target: AgentRelease,
        now: Instant,
    ) -> Result<(), SupervisorError> {
        self.ensure_mutation_admitted(agent_id)?;
        self.with_slot(agent_id, |supervisor, slot| {
            supervisor.upgrade_slot(
                agent_id, slot, target, now, /*explicit_rollback*/ false,
                /*authority*/ None,
            )
        })
    }

    pub fn rollback(&mut self, agent_id: &AgentId, now: Instant) -> Result<(), SupervisorError> {
        self.ensure_mutation_admitted(agent_id)?;
        self.with_slot(agent_id, |supervisor, slot| {
            let target = slot
                .previous_release
                .clone()
                .ok_or_else(|| SupervisorError::NoPreviousRelease(agent_id.clone()))?;
            supervisor.upgrade_slot(
                agent_id, slot, target, now, /*explicit_rollback*/ true,
                /*authority*/ None,
            )
        })
    }

    /// Admit one externally signed H7/OPE operation into the real lifecycle
    /// supervisor.  The H7 envelope remains a qualification artifact; the
    /// independent production grant is the only object that carries
    /// production authority.  This method queues the existing drain/start
    /// state machine and records a fsynced intent before touching the child.
    #[expect(
        clippy::too_many_arguments,
        reason = "grant admission keeps verifier, epochs and clocks explicit"
    )]
    pub fn apply_production_grant(
        &mut self,
        agent_id: &AgentId,
        grant: &H7H89ProductionGrant,
        h7_envelope: &H7SignedArtifactEnvelope,
        verifier: &H7H89ProductionGrantVerifier,
        expected_authority_epoch: u64,
        now_unix_seconds: u64,
        now: Instant,
    ) -> Result<ProductionMutationReceipt, SupervisorError> {
        self.ensure_mutation_admitted(agent_id)?;
        self.with_slot(agent_id, |supervisor, slot| {
            let record = supervisor.record(agent_id)?;
            let current = slot.active_release.as_ref().ok_or_else(|| {
                SupervisorError::Invalid(format!(
                    "agent {agent_id} has no explicit active release identity"
                ))
            })?;
            let target_id = ReleaseId::parse(grant.target_release.clone())?;
            let target =
                AgentRelease::try_from(supervisor.registry.resolve_release(agent_id, &target_id)?)?;
            if grant.transition == H7H89ProductionTransition::Rollback {
                let previous = slot
                    .previous_release
                    .as_ref()
                    .ok_or_else(|| SupervisorError::NoPreviousRelease(agent_id.clone()))?;
                if previous.identity() != target.identity() {
                    return Err(SupervisorError::Invalid(format!(
                        "signed rollback target {} is not the recorded previous release {}",
                        target.identity(),
                        previous.identity()
                    )));
                }
            }
            verifier
                .verify(
                    grant,
                    h7_envelope,
                    agent_id,
                    current.identity(),
                    target.identity(),
                    slot.control_revision,
                    record.lifecycle.generation,
                    expected_authority_epoch,
                    now_unix_seconds,
                )
                .map_err(|error| SupervisorError::ProductionAuthority(error.to_string()))?;
            let admitted_source = supervisor
                .registry
                .resolve_release(agent_id, current.release_id())
                .map_err(|error| {
                    SupervisorError::ProductionAuthority(format!(
                        "production source release must remain catalog-admitted: {error}"
                    ))
                })?;
            let admitted_source = AgentRelease::try_from(admitted_source)?;
            if current.command() != admitted_source.command()
                || current.matrixd_command() != admitted_source.matrixd_command()
            {
                return Err(SupervisorError::ProductionAuthority(
                    "active source commands do not match the canonical admitted release"
                        .to_string(),
                ));
            }
            // with_slot temporarily removes this Agent from the map. Use the
            // exact held slot instead of looking it up through the public
            // preflight entry point, after grant verification and before writes.
            supervisor.preflight_upgrade_slot(agent_id, slot, &target)?;
            if slot.signed_intent.as_ref().is_some_and(|intent| {
                !matches!(
                    intent.status,
                    SignedIntentStatus::Committed | SignedIntentStatus::RolledBack
                )
            }) {
                return Err(SupervisorError::SignedIntentRecoveryRequired(
                    agent_id.clone(),
                ));
            }
            let next_control_revision = Self::next_control_revision_for_slot(slot)?;
            let intent = SignedSupervisorIntent::new(
                grant.digest().clone(),
                agent_id.to_string(),
                grant.transition,
                current.identity().to_string(),
                target.identity().to_string(),
                slot.control_revision,
                record.lifecycle.generation,
                expected_authority_epoch,
                SignedIntentStatus::Prepared,
            )
            .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
            write_intent(record.layout.run_root(), &intent)
                .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
            Self::set_control_revision_for_slot(slot, next_control_revision)?;
            slot.signed_intent = Some(intent.clone());
            let explicit_rollback = grant.transition == H7H89ProductionTransition::Rollback;
            if let Err(error) = supervisor.upgrade_slot(
                agent_id,
                slot,
                target,
                now,
                explicit_rollback,
                Some((grant.digest().clone(), expected_authority_epoch)),
            ) {
                let recovery = intent
                    .with_status(SignedIntentStatus::RecoveryRequired)
                    .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
                let _ = write_intent(record.layout.run_root(), &recovery);
                slot.signed_intent = Some(recovery);
                return Err(error);
            }
            let queued = intent
                .with_status(SignedIntentStatus::Queued)
                .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
            write_intent(record.layout.run_root(), &queued)
                .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
            slot.signed_intent = Some(queued);
            Ok(ProductionMutationReceipt::queued(
                grant,
                next_control_revision,
            ))
        })
    }

    pub(crate) fn commit_signed_intent_if_target(
        &self,
        agent_id: &AgentId,
        slot: &mut AgentSlot<D::Process>,
    ) -> Result<(), SupervisorError> {
        let Some(intent) = slot.signed_intent.clone() else {
            return Ok(());
        };
        if !matches!(
            intent.status,
            SignedIntentStatus::Prepared | SignedIntentStatus::Queued
        ) {
            return Ok(());
        }
        let Some(active) = slot.active_release.as_ref() else {
            return Ok(());
        };
        let Some(transaction) = slot.release_transaction.as_ref() else {
            return Ok(());
        };
        let outcome = match transaction.phase {
            ReleaseTransactionPhase::Committed => ProductionRecoveryOutcome::Committed,
            ReleaseTransactionPhase::RolledBack => ProductionRecoveryOutcome::RolledBack,
            _ => return Ok(()),
        };
        let record = self.record(agent_id)?;
        let Ok((observed, _)) =
            Self::signed_recovery_outcome(&intent, transaction, &record.release_state, outcome)
        else {
            return Ok(());
        };
        if active.identity() != observed {
            return Ok(());
        }
        let terminal_status = match outcome {
            ProductionRecoveryOutcome::Committed => SignedIntentStatus::Committed,
            ProductionRecoveryOutcome::RolledBack => SignedIntentStatus::RolledBack,
        };
        let terminal = intent
            .with_status(terminal_status)
            .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
        write_intent(record.layout.run_root(), &terminal)
            .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
        slot.signed_intent = Some(terminal);
        Ok(())
    }

    fn recover_signed_intent(
        &mut self,
        agent_id: &AgentId,
        slot: &mut AgentSlot<D::Process>,
        record: &AgentRecord,
    ) -> Result<(), SupervisorError> {
        let intent = read_intent(record.layout.run_root())
            .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
        let Some(intent) = intent else {
            return Ok(());
        };
        if intent.agent_id != agent_id.to_string() {
            return Err(SupervisorError::Invalid(
                "signed supervisor intent agent binding mismatch".to_string(),
            ));
        }
        slot.signed_intent = Some(intent.clone());
        if matches!(
            intent.status,
            SignedIntentStatus::Committed | SignedIntentStatus::RolledBack
        ) {
            return Ok(());
        }

        // A terminal release transaction is the durable owner witness that the
        // exact signed transition crossed its lifecycle boundary. This closes
        // the crash cut between terminal transaction publication and the
        // matching signed-intent update. Matching release state is required so
        // a detached or unrelated terminal journal cannot close the intent.
        if let Some(transaction) = read_release_transaction(record.layout.run_root())
            .map_err(|error| SupervisorError::Invalid(error.to_string()))?
        {
            let outcome = match transaction.phase {
                ReleaseTransactionPhase::Committed => Some(ProductionRecoveryOutcome::Committed),
                ReleaseTransactionPhase::RolledBack => Some(ProductionRecoveryOutcome::RolledBack),
                _ => None,
            };
            let terminal_status = outcome
                .filter(|outcome| {
                    Self::signed_recovery_outcome(
                        &intent,
                        &transaction,
                        &record.release_state,
                        *outcome,
                    )
                    .is_ok()
                })
                .map(|outcome| match outcome {
                    ProductionRecoveryOutcome::Committed => SignedIntentStatus::Committed,
                    ProductionRecoveryOutcome::RolledBack => SignedIntentStatus::RolledBack,
                });
            if let Some(status) = terminal_status {
                let terminal = intent
                    .with_status(status)
                    .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
                write_intent(record.layout.run_root(), &terminal)
                    .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
                slot.signed_intent = Some(terminal);
                return Ok(());
            }
        }

        // Keep the daemon reachable for the status/recovery ceremony while
        // quarantining this Agent generation. Ordinary mutation admission is
        // blocked until the signed intent reaches a terminal state.
        let recovery = if intent.status == SignedIntentStatus::RecoveryRequired {
            intent
        } else {
            intent
                .with_status(SignedIntentStatus::RecoveryRequired)
                .map_err(|error| SupervisorError::Invalid(error.to_string()))?
        };
        write_intent(record.layout.run_root(), &recovery)
            .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
        slot.signed_intent = Some(recovery);

        let lifecycle = self.record(agent_id)?.lifecycle;
        if matches!(
            lifecycle.lifecycle,
            AgentLifecycle::Starting | AgentLifecycle::Running | AgentLifecycle::Draining
        ) {
            self.transition_without_runtime(
                agent_id,
                slot,
                lifecycle.generation,
                AgentLifecycle::Failed,
            )?;
        }
        if let Some(runtime) = slot.runtime.as_mut() {
            // Process adoption may already have fenced and successfully requested
            // termination. Hydrating the signed-intent fence is not a second kill.
            let already_requested =
                runtime.fenced && matches!(runtime.phase, RuntimePhase::Killing);
            runtime.fenced = true;
            if !already_requested {
                runtime
                    .process
                    .kill()
                    .map_err(|error| crate::runtime::driver_error(agent_id, error))?;
                runtime.phase = RuntimePhase::Killing;
            }
        }
        Ok(())
    }

    pub fn production_recovery_required(
        &self,
        agent_id: &AgentId,
    ) -> Result<bool, SupervisorError> {
        let slot = self
            .slots
            .get(agent_id)
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
        Ok(slot.recovery_blocker.is_some()
            || slot
                .signed_intent
                .as_ref()
                .is_some_and(|intent| intent.status == SignedIntentStatus::RecoveryRequired))
    }

    pub fn any_production_recovery_required(&self) -> bool {
        self.slots.values().any(|slot| {
            slot.recovery_blocker.is_some()
                || slot
                    .signed_intent
                    .as_ref()
                    .is_some_and(|intent| intent.status == SignedIntentStatus::RecoveryRequired)
        })
    }

    pub fn release_selection_snapshot(
        &self,
        agent_id: &AgentId,
    ) -> Result<Option<DurableReleaseTransaction>, SupervisorError> {
        let record = self.record(agent_id)?;
        read_release_transaction(record.layout.run_root())
            .map_err(|error| SupervisorError::Invalid(error.to_string()))
    }

    pub fn production_mutation_state(
        &self,
        agent_id: &AgentId,
    ) -> Result<Option<ProductionMutationState>, SupervisorError> {
        let record = self.record(agent_id)?;
        let Some(intent) = read_intent(record.layout.run_root())
            .map_err(|error| SupervisorError::Invalid(error.to_string()))?
        else {
            return Ok(None);
        };
        if intent.agent_id != agent_id.to_string() {
            return Err(SupervisorError::Invalid(
                "signed production receipt belongs to another Agent".to_string(),
            ));
        }
        let status = match intent.status {
            SignedIntentStatus::Prepared | SignedIntentStatus::Queued => {
                crate::ProductionMutationStatus::Queued
            }
            SignedIntentStatus::Committed => crate::ProductionMutationStatus::Committed,
            SignedIntentStatus::RolledBack => crate::ProductionMutationStatus::RolledBack,
            SignedIntentStatus::RecoveryRequired => {
                crate::ProductionMutationStatus::RecoveryRequired
            }
            SignedIntentStatus::Aborted => crate::ProductionMutationStatus::Aborted,
        };
        let control_revision = intent
            .expected_control_revision
            .checked_add(1)
            .ok_or_else(|| SupervisorError::Invalid("control revision overflow".to_string()))?;
        let transaction = read_release_transaction(record.layout.run_root())
            .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
        let release_transaction_sha256 = transaction
            .as_ref()
            .filter(|value| Self::signed_transaction_matches(&intent, value))
            .map(|value| value.transaction_sha256.clone());
        Ok(Some(ProductionMutationState {
            receipt: ProductionMutationReceipt {
                grant_sha256: intent.grant_sha256.clone(),
                agent_id: intent.agent_id.clone(),
                transition: intent.transition,
                source_release: intent.source_release.clone(),
                target_release: intent.target_release.clone(),
                control_revision,
                status,
                production_authority: true,
                external_effects: true,
                operator_acceptance: true,
                promotion: true,
            },
            intent_sha256: intent.intent_sha256,
            release_transaction_sha256,
        }))
    }

    pub fn resolve_production_recovery(
        &mut self,
        agent_id: &AgentId,
        decision: &ProductionRecoveryDecision,
        verifier: &H7H89ProductionGrantVerifier,
        expected_authority_epoch: u64,
        now_unix_seconds: u64,
    ) -> Result<ProductionMutationReceipt, SupervisorError> {
        self.ensure_recovery_unblocked(agent_id)?;
        self.with_slot(agent_id, |supervisor, slot| {
            let record = supervisor.record(agent_id)?;
            let intent = read_intent(record.layout.run_root())
                .map_err(|error| SupervisorError::Invalid(error.to_string()))?
                .ok_or_else(|| SupervisorError::SignedIntentRecoveryRequired(agent_id.clone()))?;
            let transaction = read_release_transaction(record.layout.run_root())
                .map_err(|error| SupervisorError::Invalid(error.to_string()))?
                .ok_or_else(|| SupervisorError::SignedIntentRecoveryRequired(agent_id.clone()))?;
            let terminal_retry = matches!(
                transaction.phase,
                ReleaseTransactionPhase::Committed | ReleaseTransactionPhase::RolledBack
            ) && transaction.recovery_decision_sha256.as_ref() == Some(decision.digest());
            if intent.status != SignedIntentStatus::RecoveryRequired
                && !(terminal_retry
                    && matches!(
                        intent.status,
                        SignedIntentStatus::Committed | SignedIntentStatus::RolledBack
                    ))
            {
                return Err(SupervisorError::Invalid(
                    "production recovery requires its exact quarantined or resolved signed intent"
                        .to_string(),
                ));
            }
            if transaction.phase != ReleaseTransactionPhase::RecoveryRequired && !terminal_retry {
                return Err(SupervisorError::SignedIntentRecoveryRequired(
                    agent_id.clone(),
                ));
            }
            // A writer may have published terminal bytes before failing its
            // durability acknowledgment. Reconstruct only the exact signed
            // decision's preimages; verification below still checks its
            // signature, expiry, authority, lifecycle and current admission.
            let recovery_intent = intent
                .with_status(SignedIntentStatus::RecoveryRequired)
                .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
            let recovery_transaction = transaction
                .with_phase(ReleaseTransactionPhase::RecoveryRequired)
                .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
            if slot.runtime.as_ref().is_some_and(|runtime| !runtime.fenced) {
                return Err(SupervisorError::Invalid(
                    "production recovery requires the ambiguous process to be fenced or absent"
                        .to_string(),
                ));
            }

            let (expected_release, expected_wire) = Self::signed_recovery_outcome(
                &recovery_intent, &recovery_transaction, &record.release_state, decision.outcome)?;
            let expected_release_id = ReleaseId::parse(expected_release.to_string())?;
            if record.release_state.current.as_ref() != Some(&expected_release_id) {
                return Err(SupervisorError::Invalid(format!(
                    "recovery outcome expects release {expected_release} but durable current release differs"
                )));
            }
            let binding = supervisor
                .registry
                .resolve_release_binding(agent_id, &expected_release_id)?;
            if expected_wire.release_id != binding.release_id.to_string()
                || expected_wire.manifest_sha256.as_str() != binding.manifest_sha256.as_str()
                || expected_wire.agentd_program_sha256.as_str()
                    != binding.agentd_program_sha256.as_str()
                || expected_wire.matrixd_program_sha256.as_deref()
                    != binding.matrixd_program_sha256.as_deref()
                || expected_wire.admission_frontier_sha256.as_str()
                    != binding.admission_frontier_sha256.as_str()
            {
                return Err(SupervisorError::ProductionAuthority(
                    "release binding changed since the production transition was admitted"
                        .to_string(),
                ));
            }
            let parse = |value: String, label: &str| {
                Sha256Digest::parse(value)
                    .map_err(|_| SupervisorError::Invalid(format!("{label} digest is malformed")))
            };
            let manifest = parse(binding.manifest_sha256, "recovery observed manifest")?;
            let agentd = parse(binding.agentd_program_sha256, "recovery observed agentd")?;
            let matrixd = binding
                .matrixd_program_sha256
                .map(|value| parse(value, "recovery observed matrixd"))
                .transpose()?;

            verifier
                .verify_recovery(
                    decision,
                    agent_id,
                    &recovery_intent.grant_sha256,
                    &recovery_intent.intent_sha256,
                    &recovery_transaction.transaction_sha256,
                    expected_release,
                    &manifest,
                    &agentd,
                    matrixd.as_ref(),
                    record.lifecycle.generation,
                    expected_authority_epoch,
                    now_unix_seconds,
                )
                .map_err(|error| SupervisorError::ProductionAuthority(error.to_string()))?;

            let terminal_phase = match (intent.transition, decision.outcome) {
                (
                    H7H89ProductionTransition::Upgrade,
                    ProductionRecoveryOutcome::Committed,
                ) => ReleaseTransactionPhase::Committed,
                (
                    H7H89ProductionTransition::Upgrade,
                    ProductionRecoveryOutcome::RolledBack,
                )
                | (
                    H7H89ProductionTransition::Rollback,
                    ProductionRecoveryOutcome::RolledBack,
                ) => ReleaseTransactionPhase::RolledBack,
                (
                    H7H89ProductionTransition::Rollback,
                    ProductionRecoveryOutcome::Committed,
                ) => {
                    return Err(SupervisorError::Invalid(
                        "a rollback transition cannot recover as a committed upgrade".to_string(),
                    ));
                }
            };
            let terminal_intent_status = match (intent.transition, decision.outcome) {
                (
                    H7H89ProductionTransition::Upgrade,
                    ProductionRecoveryOutcome::Committed,
                ) => SignedIntentStatus::Committed,
                (
                    H7H89ProductionTransition::Upgrade,
                    ProductionRecoveryOutcome::RolledBack,
                )
                | (
                    H7H89ProductionTransition::Rollback,
                    ProductionRecoveryOutcome::RolledBack,
                ) => SignedIntentStatus::RolledBack,
                (
                    H7H89ProductionTransition::Rollback,
                    ProductionRecoveryOutcome::Committed,
                ) => unreachable!("invalid rollback recovery outcome rejected above"),
            };
            let terminal_transaction = recovery_transaction
                .with_recovery_resolution(terminal_phase, decision.digest().clone())
                .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
            let terminal_intent = recovery_intent
                .with_status(terminal_intent_status)
                .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
            if terminal_retry
                && (transaction != terminal_transaction
                    || (intent.status != SignedIntentStatus::RecoveryRequired
                        && intent != terminal_intent))
            {
                return Err(SupervisorError::Invalid(
                    "production recovery replay differs from its recorded terminal outcome"
                        .to_string(),
                ));
            }
            let already_acknowledged = slot.control_revision > 0
                && transaction == terminal_transaction
                && intent == terminal_intent
                && slot.release_transaction.as_ref() == Some(&terminal_transaction)
                && slot.signed_intent.as_ref() == Some(&terminal_intent);
            let next_control_revision = if already_acknowledged {
                slot.control_revision
            } else {
                Self::next_control_revision_for_slot(slot)?
            };
            if !already_acknowledged {
                // Republish both records on an ambiguous acknowledgment; an
                // on-disk terminal value alone cannot discharge this owner.
                write_release_transaction(record.layout.run_root(), &terminal_transaction)
                    .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
                slot.release_transaction = Some(terminal_transaction);
                write_intent(record.layout.run_root(), &terminal_intent)
                    .map_err(|error| SupervisorError::Invalid(error.to_string()))?;
                slot.signed_intent = Some(terminal_intent.clone());

                Self::set_control_revision_for_slot(slot, next_control_revision)?;
            }
            Ok(ProductionMutationReceipt {
                grant_sha256: terminal_intent.grant_sha256,
                agent_id: terminal_intent.agent_id,
                transition: terminal_intent.transition,
                source_release: terminal_intent.source_release,
                target_release: terminal_intent.target_release,
                control_revision: next_control_revision,
                status: match (terminal_intent.transition, decision.outcome) {
                    (
                        H7H89ProductionTransition::Upgrade,
                        ProductionRecoveryOutcome::Committed,
                    ) => crate::ProductionMutationStatus::Committed,
                    (
                        H7H89ProductionTransition::Upgrade,
                        ProductionRecoveryOutcome::RolledBack,
                    )
                    | (
                        H7H89ProductionTransition::Rollback,
                        ProductionRecoveryOutcome::RolledBack,
                    ) => crate::ProductionMutationStatus::RolledBack,
                    (
                        H7H89ProductionTransition::Rollback,
                        ProductionRecoveryOutcome::Committed,
                    ) => unreachable!("invalid rollback recovery outcome rejected above"),
                },
                production_authority: true,
                external_effects: true,
                operator_acceptance: true,
                promotion: true,
            })
        })
    }

    pub fn tick(&mut self, now: Instant) -> TickReport {
        let mut report = TickReport::default();
        let agent_ids: Vec<_> = self.slots.keys().cloned().collect();
        for agent_id in agent_ids {
            let result = self.with_slot(&agent_id, |supervisor, slot| {
                supervisor.tick_slot_with_report(&agent_id, slot, now, &mut report)
            });
            if let Err(error) = result {
                self.record_fault(&agent_id, &error, &mut report);
            }
        }
        report
    }

    fn with_slot<R>(
        &mut self,
        agent_id: &AgentId,
        operation: impl FnOnce(&mut Self, &mut AgentSlot<D::Process>) -> Result<R, SupervisorError>,
    ) -> Result<R, SupervisorError> {
        let mut slot = self
            .slots
            .remove(agent_id)
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))?;
        let result = operation(self, &mut slot);
        self.slots.insert(agent_id.clone(), slot);
        result
    }

    pub(crate) fn transition_without_runtime(
        &self,
        agent_id: &AgentId,
        slot: &mut AgentSlot<D::Process>,
        expected: u64,
        lifecycle: AgentLifecycle,
    ) -> Result<u64, SupervisorError> {
        let next = self
            .registry
            .compare_and_transition(agent_id, expected, lifecycle)?;
        slot.event(next.generation, SupervisorEventKind::Lifecycle(lifecycle));
        Ok(next.generation)
    }

    pub(crate) fn record(&self, agent_id: &AgentId) -> Result<AgentRecord, SupervisorError> {
        self.registry
            .load()?
            .agent(agent_id)
            .cloned()
            .ok_or_else(|| SupervisorError::UnknownAgent(agent_id.clone()))
    }

    fn record_fault(
        &mut self,
        agent_id: &AgentId,
        error: &SupervisorError,
        report: &mut TickReport,
    ) {
        if let Some(slot) = self.slots.get_mut(agent_id) {
            Self::record_slot_fault(agent_id, slot, error, report);
        } else {
            report.faults.push(AgentFault {
                agent_id: agent_id.clone(),
                message: bounded_message(error.to_string()),
            });
        }
    }

    pub(crate) fn record_slot_fault(
        agent_id: &AgentId,
        slot: &mut AgentSlot<D::Process>,
        error: &SupervisorError,
        report: &mut TickReport,
    ) {
        let message = bounded_message(error.to_string());
        let generation = slot
            .runtime
            .as_ref()
            .map(|runtime| runtime.generation)
            .unwrap_or(0);
        slot.event(
            generation,
            SupervisorEventKind::DriverFault(message.clone()),
        );
        report.faults.push(AgentFault {
            agent_id: agent_id.clone(),
            message,
        });
    }
}
