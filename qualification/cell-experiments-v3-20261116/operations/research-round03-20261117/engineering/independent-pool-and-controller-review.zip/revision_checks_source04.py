"""Independent read-only execution of sealed source-04 lifecycle tests."""

import ast
from hashlib import sha256
import importlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import time
from types import ModuleType
import unittest

ROOT = Path(__file__).parent
SOURCE = Path('/dev/shm/hepta-e1e6-next-20261117-0c078a/onpolicy/source-04/online_v4')
EXPECTED = {
    'shared_pool_v4.py': '02c3c7311a8b2834523b2995b831b90e6d9ff6495702418eadf59a5ba17594fc',
    'onpolicy_train.py': '64db149bee43242e68703a30ce090c3c2a3eb38f3d0347ac8c152d63898255f8',
    'test_shared_pool_cleanup.py': '5fee971d8affb9c084b016bfc620340469f7b1387c1458540b1d0f2355776e54',
}
for name, identity in EXPECTED.items():
    assert sha256((SOURCE / name).read_bytes()).hexdigest() == identity, name
before = {p.name: sha256(p.read_bytes()).hexdigest() for p in SOURCE.glob('*.py')}
sys.path.insert(0, '/workspace/scratch/0c078af77c37/cell_experiments_v3_20261116/scripts')
import cell_experiments

package = ModuleType('cell_experiments.independent_pool_source04')
package.__path__ = [str(SOURCE)]
sys.modules[package.__name__] = package
setattr(cell_experiments, 'independent_pool_source04', package)
modules = [importlib.import_module(package.__name__ + '.' + name)
           for name in ('test_shared_pool_cleanup', 'test_onpolicy_cache')]
suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(module) for module in modules)
log, tick = io.StringIO(), time.perf_counter()
result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
elapsed = time.perf_counter() - tick

pool = importlib.import_module(package.__name__ + '.shared_pool_v4')
cell_experiments.__path__.insert(0, str(ROOT.parent / 'source02'))
contract = importlib.import_module('cell_experiments.online_v4.circuit_contract')
obj = pool.SharedAdapterPool.__new__(pool.SharedAdapterPool)
obj._entries = {'safe': {'model_digest': '1' * 64,
    'training': {'trainable_parameters': 8, 'parameter_after': '2' * 64}}}
obj.pool_identity, obj.base_parameters, obj.resident_parameters = '3' * 64, 100, 124
evidence = obj.parameter_evidence('safe')
cell = contract.CellSpec('safe', '1' * 64, '4' * 64, '5' * 64, '6' * 64,
    active_parameters=evidence['active_parameters'],
    parameter_evidence_digest=evidence['parameter_evidence_digest'])
measured = contract.measured_output({'answer': 'ok', 'loaded_model_digest': '1' * 64,
    'input_tokens': 2, 'output_tokens': 1, 'wall_seconds': 0.0, **evidence}, cell, contract.Budget())
assert measured['reported_active_parameters'] == 108
assert evidence['parameter_source_digest'] == evidence['parameter_evidence_digest']


def functions(tree):
    return {node.name: ast.dump(node, include_attributes=False)
            for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}


old_functions = functions(ast.parse((ROOT / 'source-reviewed/shared_pool_v4.py').read_text()))
new_functions = functions(ast.parse((SOURCE / 'shared_pool_v4.py').read_text(), feature_version=(3, 10)))
unchanged = {name: old_functions[name] == new_functions[name] for name in
             ('adapter_parameters', '_install', '_activate', 'snapshot', 'parameter_evidence', 'generate')}
assert all(unchanged.values())
after = {p.name: sha256(p.read_bytes()).hexdigest() for p in SOURCE.glob('*.py')}
assert before == after
success = result.wasSuccessful() and result.testsRun == 11
report = {
    'schema': 'hepta.shared-pool-independent-revision-tests.v1',
    'source_directory': str(SOURCE), 'source_files_sha256': before,
    'source_unchanged_during_checks': True, 'tests': result.testsRun, 'success': success,
    'failures': [(str(test), reason) for test, reason in result.failures],
    'errors': [(str(test), reason) for test, reason in result.errors],
    'wall_seconds': elapsed, 'log': log.getvalue(),
    'circuit_parameter_evidence_check': 'PASS_INTERFACE_ONLY',
    'unchanged_normal_path_methods': unchanged, 'python310_grammar_parse': True,
    'python310_exception_api_fallback': 'PASS_API_SIMULATION_ON_PYTHON312' if success else 'NOT_CONFIRMED',
    'python310_interpreter_test': 'NOT_RUN', 'tensor_A_B_A_status': 'NOT_RUN',
    'actual_gpu_memory_release': 'NOT_MEASURED',
    'dependencies': {name: bool(importlib.util.find_spec(name)) for name in
                     ('torch', 'peft', 'transformers', 'safetensors', 'numpy')},
    'GPU_jobs_launched': 0, 'remote_calls': 0, 'sibling_files_modified': False,
    'independent_sample_increment': 0,
    'previous_attempt': 'REVISION_TESTS_SOURCE04.json',
    'previous_attempt_correction': 'The first reviewer harness did not bind its namespace package to the parent. Both test modules failed import, so no regression tests or fallback API case ran in that attempt; its fallback-exercised field was incorrect. That raw attempt is preserved. This attempt fixes only the reviewer harness and executes the same unchanged source-04.',
}
with (ROOT / 'REVISION_TESTS_SOURCE04_ATTEMPT02.json').open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
print(json.dumps({key: value for key, value in report.items() if key != 'source_files_sha256'}, indent=2))
sys.exit(0 if success else 1)
