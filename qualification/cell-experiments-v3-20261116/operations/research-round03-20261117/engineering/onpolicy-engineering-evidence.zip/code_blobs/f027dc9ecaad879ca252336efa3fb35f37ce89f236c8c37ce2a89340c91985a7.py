"""Explicit old-A/backend compatibility smoke. No model load, training, or new C."""

import hashlib
import json
from pathlib import Path
import sys


def main():
    root, new_scripts, output = map(Path, sys.argv[1:4])
    inputs = root / "research-sft-02" / "INPUTS.json"
    expected = "691945696e7dad9ee0f3023617edf5ca0f787850c16f2623c08d14bc6cfbeaf3"
    if hashlib.sha256(inputs.read_bytes()).hexdigest() != expected:
        raise ValueError("actual old Run02 inputs changed")
    sys.path.insert(0, str(root / "candidate-qwen-03" / "scripts"))
    sys.path.insert(0, str(root / "research-sft-v1-source"))
    import cell_experiments
    cell_experiments.__path__.append(str(new_scripts / "cell_experiments"))
    import research_sft_contract_v1 as original
    original.bind_helpers(root / "e1e2-operation-helpers-04")
    from cell_experiments import data, repo_execution
    from cell_experiments.coding_sft import write_new
    from cell_experiments.online_v4.onpolicy_backend import ResearchBackend
    from cell_experiments.online_v4.onpolicy_contract import validate_plan

    output.mkdir(parents=True, exist_ok=False)
    write_new(output / "INTENT.json", {
        "engineering_compatibility_only": True, "actual_inputs_sha256": expected,
        "GPU_jobs_launched": 0, "model_loads": 0, "independent_sample_increment": 0})
    context = data._parse(inputs.read_bytes())
    initial_path = root / "research-sft-02/workers/controlled_correction-primary/research-model/manifest.json"
    initial = data._parse(initial_path.read_bytes())
    backend = ResearchBackend(context, root)
    repo_execution.load_catalog("open")
    originals = context["records"][:6]
    collection = backend.collect(originals, initial, output / "teacher-collection", "teacher", 2)
    corrected = backend.corrections(originals, collection, "teacher", 0, output / "corrections")
    plan = backend.make_plan(corrected, initial, "engineering-compatibility-only", 0, "teacher")
    validate_plan(corrected, initial, root, context, plan)
    if not (collection["model_calls"] == collection["student_verifier_calls"] == 0
            and plan["previous_training"]["candidate_model_digest"] == data.digest(initial)
            and all(row["onpolicy_derivation"]["external_teacher"] is False for row in corrected)):
        raise ValueError("default backend compatibility failed")
    write_new(output / "CORRECTED_RECORDS.json", corrected)
    write_new(output / "PLAN.json", plan)
    result = {"status": "COMPLETE", "engineering_compatibility_only": True,
              "actual_inputs_sha256": expected, "old_A_reference_rechecks": len(corrected),
              "actual_previous_training": plan["previous_training"],
              "student_model_calls": 0, "model_loads": 0, "GPU_jobs_launched": 0,
              "independent_sample_increment": 0, "scientific_confirmation_qualified": False}
    write_new(output / "RESULT.json", result)
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
