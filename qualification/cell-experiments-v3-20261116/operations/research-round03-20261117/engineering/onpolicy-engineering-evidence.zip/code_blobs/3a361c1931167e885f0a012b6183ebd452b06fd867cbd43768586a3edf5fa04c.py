"""Dependency-free interface/failure checks; no tensor or GPU validation claim."""

from contextlib import ExitStack
import importlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import threading
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).parent
CORE = Path('/workspace/scratch/0c078af77c37/cell_experiments_v3_20261116/scripts')
NEW = Path('/dev/shm/hepta-e1e6-next-20261117-0c078a/onpolicy/new')
sys.path.insert(0, str(CORE))
import cell_experiments

package = ModuleType('cell_experiments.shared_pool_review_v4')
package.__path__ = [str(ROOT / 'source-reviewed'), str(NEW)]
sys.modules[package.__name__] = package
pool_module = importlib.import_module(package.__name__ + '.shared_pool_v4')
cell_experiments.__path__.insert(0, str(ROOT.parent / 'source02'))
contract = importlib.import_module('cell_experiments.online_v4.circuit_contract')
observations = {}


class FakeCuda:
    def __init__(self):
        self.empty_calls, self.fractions = 0, []

    def empty_cache(self):
        self.empty_calls += 1

    def set_per_process_memory_fraction(self, fraction, device):
        self.fractions.append((fraction, device))

    def is_available(self):
        return True


class FakeTorch:
    def __init__(self):
        self.cuda = FakeCuda()

    def device(self, value):
        return value


runtime = {'device': 'cuda:0', 'dtype': 'bfloat16',
           'min_cuda_free_bytes': pool_module.probe.MIN_CUDA_FREE_BYTES,
           'max_input_tokens': 4096, 'max_new_tokens': 384}


def constructor_case(fail_during_constructor):
    created, torch = [], FakeTorch()

    class FakePredictor:
        def __init__(self, manifest, root):
            self.model, self.close_calls = object(), 0
            created.append(self)
            if fail_during_constructor:
                raise RuntimeError('constructor failed after model assignment')

        def close(self):
            self.close_calls += 1
            self.model = None

    def fail_install(*args):
        raise RuntimeError('adapter installation failed')

    with ExitStack() as stack:
        stack.enter_context(patch.object(pool_module, 'verified_entries', return_value=({}, {'runtime': runtime})))
        stack.enter_context(patch.object(pool_module.probe, '_libraries', return_value=(torch, None)))
        stack.enter_context(patch.object(pool_module.probe, 'check_device', return_value=None))
        stack.enter_context(patch.object(pool_module.probe, 'Predictor', FakePredictor))
        stack.enter_context(patch.object(pool_module.SharedAdapterPool, '_install', fail_install))
        try:
            pool_module.SharedAdapterPool({}, ROOT)
        except RuntimeError as error:
            outcome = str(error)
    return {'error': outcome, 'close_calls': created[0].close_calls,
            'model_reference_retained': created[0].model is not None,
            'empty_cache_calls': torch.cuda.empty_calls,
            'allocation': 'plain Python sentinel, not real tensor memory'}


observations['constructor_failure'] = constructor_case(True)
observations['adapter_install_failure'] = constructor_case(False)
assert observations['constructor_failure']['close_calls'] == 0
assert observations['adapter_install_failure']['close_calls'] == 1

torch = FakeTorch()
pool = pool_module.SharedAdapterPool.__new__(pool_module.SharedAdapterPool)
pool._lock, pool._owner_pid, pool._closed = threading.Lock(), os.getpid(), False


def close_error():
    raise RuntimeError('cleanup failure')


pool._view = SimpleNamespace(torch=torch, close=close_error)
try:
    pool.close()
except RuntimeError:
    pass
observations['close_failure'] = {'closed_flag': pool._closed,
    'view_reference_retained': pool._view is not None, 'empty_cache_calls': torch.cuda.empty_calls}

tokens = [object() for _ in range(4)]
names = ['base_model.model.q.lora_A.cell_0.weight', 'base_model.model.q.lora_A.cell_1.weight',
         'base_model.model.q.lora_B.cell_0.weight', 'base_model.model.q.base_layer.weight']
model = SimpleNamespace(named_parameters=lambda: list(zip(names, tokens)))
normalized = pool_module.adapter_parameters(model, 'cell_0')
assert normalized == [('base_model.model.q.lora_A.default.weight', tokens[0]),
                      ('base_model.model.q.lora_B.default.weight', tokens[2])]
observations['named_adapter_normalization'] = {'normalized_names': [n for n, _ in normalized],
    'selection_and_name_mapping_correct': True, 'tensor_hash_validated': False}

pool._entries = {'safe': {'model_digest': '1' * 64,
    'training': {'trainable_parameters': 8, 'parameter_after': '2' * 64}}}
pool.pool_identity, pool.base_parameters, pool.resident_parameters = '3' * 64, 100, 124
evidence = pool.parameter_evidence('safe')
cell = contract.CellSpec('safe', '1' * 64, '4' * 64, '5' * 64, '6' * 64,
    active_parameters=evidence['active_parameters'],
    parameter_evidence_digest=evidence['parameter_evidence_digest'])
measured = contract.measured_output({'answer': 'ok', 'loaded_model_digest': '1' * 64,
    'input_tokens': 2, 'output_tokens': 1, 'wall_seconds': 0.0, **evidence}, cell, contract.Budget())
assert measured['reported_active_parameters'] == 108
assert evidence['parameter_source_digest'] == evidence['parameter_evidence_digest']
observations['circuit_evidence_interface'] = {'accepted': True, 'active_parameters': 108,
    'resident_parameters': 124, 'actual_model_parameter_count_validated': False}

entries_root = ROOT / 'tmp' / 'entry-validation'
entries_root.mkdir(exist_ok=False)
base = {'runtime': runtime, 'backend_versions': {}}
manifests = {}
for index, cell_id in enumerate(('invalid/id', 'safe_B', 'safe_C')):
    adapter = entries_root / str(index) / 'adapter'
    adapter.mkdir(parents=True)
    manifest = {'schema': 'review-only', 'base_manifest': base, 'runtime': runtime,
                'backend_versions': {}, 'adapter_directory': adapter.relative_to(entries_root).as_posix()}
    pool_module.write_new(adapter.parent / 'TRAINING.json', {'status': 'COMPLETE', 'steps': 64,
        'research_model_digest': pool_module.data.digest(manifest),
        'parameter_after': '7' * 64, 'trainable_parameters': 8})
    manifests[cell_id] = manifest
old = SimpleNamespace(MODEL_SCHEMA='review-only', TRAINING={'steps': 64},
                      verify_model=lambda manifest, root: pool_module.data.digest(manifest))
with patch.object(pool_module, 'legacy', return_value=old):
    entries, _ = pool_module.verified_entries(manifests, entries_root)
registry = {name: contract.CellSpec(name, item['model_digest'], '4' * 64, '5' * 64, '6' * 64)
            for name, item in entries.items()}
try:
    contract.validate(registry, contract.Graph('g', ('safe_B', 'safe_C')), contract.Budget())
except ValueError as error:
    id_error = str(error)
assert id_error == 'invalid Cell ID'
observations['cell_identifier_domain'] = {'pool_accepts_slash_id': 'invalid/id' in entries,
    'circuit_rejection': id_error, 'legacy_model_validator': 'isolated stub; no real manifest qualification'}

report = {'schema': 'hepta.shared-pool-independent-review-checks.v1',
          'observations': observations, 'torch_peft_numerical_test_executed': False,
          'dependencies': {name: bool(importlib.util.find_spec(name))
                           for name in ('torch', 'peft', 'transformers', 'numpy', 'safetensors')},
          'sibling_code_modified': False, 'remote_calls': 0, 'independent_sample_increment': 0}
with (ROOT / 'REVIEW_CHECKS.json').open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
print(json.dumps(report, indent=2))
