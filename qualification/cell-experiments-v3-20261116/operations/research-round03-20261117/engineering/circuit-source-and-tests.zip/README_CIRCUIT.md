# Online Circuit execution v4

This research module executes new provider calls and resettable repository
business tests. It does not select cached answers. All source files belong in
`scripts/cell_experiments/online_v4/` alongside the shared `onpolicy_feedback.py`.

## Interfaces

```python
from cell_experiments.online_v4.circuit_contract import CellSpec, Graph, Budget
from cell_experiments.online_v4.circuit_router import RouterPlan, fit_router
from cell_experiments.online_v4.circuit_study import evaluate_suite

budget = Budget(max_input_tokens_per_call=4096,
                max_output_tokens_per_call=384, max_relay_bytes=8192)
# Each CellSpec binds the exact model, shared base, bundle and chat protocol.
# Unknown parameter counts remain None; measured counts need their evidence digest.
graphs = [Graph("full", ("answer_cell", "trajectory_cell")),
          Graph("answer_only", ("answer_cell", "trajectory_cell"), ("answer",)),
          Graph("feedback_only", ("answer_cell", "trajectory_cell"), ("feedback",))]
router, search = fit_router(A, graphs, cells, budget, generate, verify,
                           output / "search", plan=RouterPlan(execution_digest))
study = evaluate_suite(B, cells, budget, generate, verify, output / "evaluation",
                       router=router, single_cell="answer_cell",
                       fixed_graph=graphs[0], random_seed=1729,
                       execution_binding_digest=execution_digest)
```

`generate(cell_id, request, call_dir)` receives only `record_id` and
`task.input/messages`; targets, trajectories and verifier parameters are absent.
The directory already exists and contains `REQUEST.json`. The callback must not
overwrite the engine's REQUEST/OUTPUT/VERIFICATION/STEP files. It returns actual
`answer`, `loaded_model_digest`, `input_tokens`, `output_tokens` and either
`wall_seconds` or `elapsed_seconds`. Existing Qwen source/runtime/device/model
admission remains the callback's obligation; no fallback or limit relaxation is
provided here. A rendered context overflow must fail rather than truncate.

`verify(original_record, answer)` returns the full fresh `data.verify_answer`
receipt for `repo_patch` version 1. The engine binds record/input/answer/fixture
parameters and checks real original/control observations. Source-pinned stable
feedback exposes bounded categories and counts, never raw answer/exception text.

## Learning and interventions

The search plan is written before execution. Every predeclared graph runs on
authorized A records. Signed lexical hashes of the original visible prompt feed
a regularized ridge predictor of each graph's observed utility. Feature width,
regularization, token/call penalties, graph candidates and callback/runtime
binding are frozen before search. Search calls and costs are retained in
`SEARCH.json`; they are not included in evaluation totals or treated as free.

The frozen router binds its Cell registry and token/call budget. Evaluation
chooses each route before task execution. It executes a repeated single Cell,
fixed process, seeded random sparse graph and learned prompt-conditional graph.
The learned route is then re-executed with each message edge and each registered
Cell removed. Removing a Cell skips all its occurrences; an unused Cell
intervention is marked a no-op. Every main arm and intervention returns the
earliest surviving output with an actual successful business verification,
otherwise the last surviving output; no output fails. This uses only the paid
current-run business feedback. Both live opportunities are executed and charged,
including a failed second call after a successful first call. There is no
retraining or rerouting under intervention. `first_success` means the first live
output, including when the first slot has been removed. `final_slot` identifies
the retained answer; `last_executed_slot` identifies the last call performed.

Answer and feedback are independent payload fields. Removing the answer edge
does not retain an assistant-history copy of that answer. All normal arms use
two call opportunities even if the first output succeeds. An ablation's saved
calls are actual savings, not charged as completed work. Token counts, provider
timings, verifier execution and measured CPU scopes are retained separately.
Equal caps are not asserted to be equal actual compute, latency or full cost.

**Context review:** the relay limit is 8192 UTF-8 bytes, potentially over 1000
tokens. Review and freeze this bound before GPU execution. Native tokenizer
limits remain authoritative; messages are not silently truncated.

## Executed CPU validation

The first nine behavior/integration tests passed in `CPU_COMBINED_TESTS_02.json`.
The pre-GPU output-selection revision adds a real first-success/second-failure
test and an empty-surviving-graph case; all ten tests passed in
`CPU_COMBINED_TESTS_03.json`. The tests use
explicitly scripted byte-tokenizer providers and actual resettable repository
function/control execution. They check both real message removals, real skipped
Cell calls, conditional numerical router fitting, frozen identities, A-only
search, four-arm/all-intervention execution and retained failure costs.
These tests are engineering evidence, not language-model success, independent
data or E4 scientific confirmation. The prior four-test receipts are preserved.

No model/GPU run, production adoption, HIA/native-Cell execution or independent
source qualification is claimed by this module. The coordinator must freeze the
actual source/data/model/runtime tuple, run GPU work, retain original receipts,
and run the repository's required final `just fmt` after integrating code.
