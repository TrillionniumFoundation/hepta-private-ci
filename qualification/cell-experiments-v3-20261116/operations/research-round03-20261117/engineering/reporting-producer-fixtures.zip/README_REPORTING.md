# E2/E4 receipt aggregation

`reporting_v4.py` is a standard-library-only importer. It does not load models,
open receipt-supplied paths, execute verifiers, authenticate provenance, or grant
scientific qualification. Pass parsed objects from the producers' original JSON.

```python
from reporting_v4 import aggregate

report = aggregate(
    {
        "teacher": {"freeze": teacher_freeze, "result": teacher_result,
                    "training": [teacher_training_0, teacher_training_1]},
        "shadow": {"freeze": shadow_freeze, "result": shadow_result,
                   "training": [shadow_training_0, shadow_training_1]},
        "controlled": {"freeze": controlled_freeze, "result": controlled_result,
                       "training": [controlled_training_0, controlled_training_1]},
    },
    search,
    {"A": a_study, "B": b_study},
    search_plan=search_plan,
    study_plans={"A": a_evaluation_plan, "B": b_evaluation_plan},
)
```

The `training` lists are optional inputs, but absence is explicitly incomplete;
their token counts become null. These are actual `TRAINING.json` objects, with
their digests checked against each RESULT round. No extra field is required from
the producers. Missing or failed RESULT/FREEZE objects may be passed as `None` or
their actual failure object; they cannot become zero-cost completed work.

## Binding and accounting

- All three E2 arms must have the same initial model, context, A digest, source
  inventory, retry cap, round/step budget, optimizer declaration and retention.
  Each FREEZE binds to RESULT; the two candidate updates form a continuous chain.
- The profile requires two rounds of 64 optimizer steps, adapter-weight warm
  start and fresh AdamW. Supplied TRAINING receipts additionally bind actual
  per-round step counts, tensor continuity and training-token measurements.
- SEARCH/STUDY summaries contain plan digests, not their budgets. Supply the
  actual existing search/evaluation PLAN objects to verify those bindings,
  shared budgets, execution identity and declared Cell interventions. Missing
  plans produce unknown budget consistency and incomplete status.
- Search, each of the four arms and every edge/Cell intervention have separate
  ledger entries. Execution-receipt reuse is rejected to avoid double-counting.
  Summary totals are checked against the supplied execution rows.
- `reported_scope_totals` covers inference-call/token counts and the reported
  verifier subset. Its E2 `verifier_calls` contribution is **student checks
  only**. Both correction references and model/reference rechecks remain outside
  that subset; `reference_verifier_calls` and `all_verifier_calls` remain null.
- Unknown components make the corresponding complete totals null.
  `known_measured_subtotals` retains the other validated observations without
  implying that missing work cost zero. Training token positions are separate
  from inference tokens; nested wall/CPU timings are not added together.

`input_validation=CONSISTENT` means the supplied structures and bindings pass.
The overall `status` remains `INCOMPLETE`: reference-verifier coverage and full
system cost are not established by these inputs. `matched_actual_cost_claim`
is false. Independent N is always zero and scientific/PoUW/adoption eligibility
is always false. Original A/B exposure is unchanged.

## Behavior evidence

The tests call the existing `onpolicy_loop` and Circuit search/study producers,
retain their JSON, parse that JSON back, and check aggregation. They use explicit
scripted model outputs and structured optimizer receipts. Repository business
fixtures run on CPU. The optimizer/token values in the structured training
fixture are authored test values, not GPU or numerical-training measurements.

Six tests cover successful structure binding; cross-arm identity/budget/optimizer
mismatch; missing/failed costs; plan budget mismatch; duplicate execution and
missing ablations; and training-digest tampering/noninteger counters. TEST_RUN_01
preserves an initial fixture-import failure; TEST_RUN_02 and TEST_RUN_03 passed.
The final test change makes the no-torch-import assertion safe when other tests
had already imported torch. No claims are based on test fixture success rates.

The final retained fixture root is recorded in TEST_RUN_03. The example report
is explicitly labelled CPU protocol-fixture evidence. The archive also retains
that fixture tree. Final integrated repository formatting remains the root
controller's `just fmt` gate; it has not been claimed by this child.
