import subprocess,hashlib,json
repo='/home/qian-qi/work/chain-known-invalid-backpressure-20261118-392934'
refs={'base':'119cbdc8b7060df28b74230fa9265ada7bc75541','head':'cf54f385930258b601339777dc18da487a34d797'}
paths=['config/pon/pq128-source-correspondence-current-v2.json','scripts/ci/pq_lifetime_current_v2.py','.github/workflows/pon-recent-batch-acceptance.yml','trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs','trillionnium/crates/trnm-pon-node/tests/public_v3_multiprocess.rs']
def git(*argv):return subprocess.check_output(['git','-C',repo,*argv])
out={'schema':'chain.r21.source-pin-static-readback.v1','read_only':True,'no_validator_or_test_execution':True,'local_git_refs':{},'files':{}}
for label,ref in refs.items():
 out['local_git_refs'][label]={'commit':git('rev-parse',ref).decode().strip(),'tree':git('rev-parse',ref+'^{tree}').decode().strip()}
 source={}
 for p in paths:
  raw=git('show',ref+':'+p);source[p]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':git('rev-parse',ref+':'+p).decode().strip()}
 mapping=json.loads(git('show',ref+':'+paths[0]));p=paths[-2]
 source[p]['map_expected_sha256']=mapping['current_source_files_sha256'][p]
 source[p]['matches_declared_map']=source[p]['sha256']==source[p]['map_expected_sha256']
 out['files'][label]=source
print(json.dumps(out,sort_keys=True,indent=2))
