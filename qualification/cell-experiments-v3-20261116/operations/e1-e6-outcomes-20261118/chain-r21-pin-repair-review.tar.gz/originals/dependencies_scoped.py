import hashlib,json,subprocess
from pathlib import Path
root=Path("/home/qian-qi/work/chain-known-invalid-backpressure-20261118-392934")
patterns=["5328f618642aa14125b6325ebcc2285f8be85cf39843a11c6d9157863a0c27c6","f9991545b8b43b870559106d7be807d286f4b2ac555a2a10dbaf6c6e850ac8fd","pq128-source-correspondence-current-v2.json","pq_lifetime_current_v2"]
args=["rg","--hidden","-n","-F"]
for p in patterns:args+=["-e",p]
args+=["scripts","config",".github"]
out={"schema":"chain.r21.current-pin-dependency-scan.v2","scope":["scripts","config",".github"],"read_only":True,"no_tests_or_validators":True,"argv":args}
try:
 p=subprocess.run(args,cwd=root,text=True,capture_output=True,timeout=20)
 out.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
 paths=sorted({s.split(":",1)[0] for s in p.stdout.splitlines()})
 out["matched_files"]=[]
 for rel in paths:
  b=(root/rel).read_bytes();actual=hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
  expected=subprocess.run(["git","rev-parse","HEAD:"+rel],cwd=root,text=True,capture_output=True,timeout=5).stdout.strip()
  out["matched_files"].append({"path":rel,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":actual,"head_git_blob":expected,"exact_head_match":actual==expected})
except subprocess.TimeoutExpired as e:
 out.update(status="TIMEOUT",partial_stdout=e.stdout.decode() if isinstance(e.stdout,bytes) else e.stdout,partial_stderr=e.stderr.decode() if isinstance(e.stderr,bytes) else e.stderr)
print(json.dumps(out,indent=2,sort_keys=True))
