import hashlib,json,re,subprocess
from pathlib import Path
repo=Path("/home/qian-qi/work/chain-backpressure-bindings-20261118-392934")
diff_path=Path("/home/qian-qi/work/chain-backpressure-bindings-evidence-20261118-392934/pin-repair.diff")
raw=diff_path.read_bytes(); expected="fa67cb5aa6dc747cc6734f3812c02194824700ae216ce049460a06d64c2bae2b"
assert hashlib.sha256(raw).hexdigest()==expected
baseline_tree="bba212bffc9debcdf4a3f82fef7e1516ba7c8593"
def git(args):
 p=subprocess.run(["git"]+args,cwd=repo,capture_output=True,timeout=20)
 if p.returncode:raise RuntimeError((args,p.returncode,p.stderr.decode()))
 return p.stdout
names=git(["diff",baseline_tree,"--name-only"]).decode().splitlines()
paths=re.findall(r"^diff --git a/(.+) b/(.+)$",raw.decode(),re.M)
assert all(a==b for a,b in paths)
diff_names=[a for a,b in paths]
out={"schema":"chain.r21.pin-repair-readonly-source.v1","read_only":True,"no_tests_or_validators":True,"repo":str(repo),"head":git(["rev-parse","HEAD"]).decode().strip(),"baseline_tree":baseline_tree,"working_diff_names":names,"provided_diff_names":diff_names,"provided_diff_path":str(diff_path),"provided_diff_bytes":len(raw),"provided_diff_sha256":hashlib.sha256(raw).hexdigest(),"provided_diff_text":raw.decode(),"files":[]}
for path in diff_names:
 b=git(["show",baseline_tree+":"+path]);a=(repo/path).read_bytes()
 out["files"].append({"path":path,"before":{"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest(),"content":b.decode()},"after":{"bytes":len(a),"sha256":hashlib.sha256(a).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(a)).encode()+b"\0"+a).hexdigest(),"content":a.decode()}})
out["scope_matches_provided_diff"]=sorted(names)==sorted(diff_names)
print(json.dumps(out,sort_keys=True,indent=2))
