import json, subprocess
root="/home/qian-qi/work/chain-known-invalid-backpressure-20261118-392934"
patterns=["5328f618642aa14125b6325ebcc2285f8be85cf39843a11c6d9157863a0c27c6","f9991545b8b43b870559106d7be807d286f4b2ac555a2a10dbaf6c6e850ac8fd","pq128-source-correspondence-current-v2.json","pq_lifetime_current_v2"]
def call(args):
    p=subprocess.run(["git", "-C", root]+args, text=True, capture_output=True, timeout=45)
    return {"argv":["git","-C",root]+args,"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr}
args=[]
for p in patterns: args+=["-e",p]
result={"schema":"chain.r21.current-pin-dependencies.v1","read_only":True,"no_tests_or_validators":True,"head":call(["rev-parse","HEAD"]),"tree":call(["rev-parse","HEAD^{tree}"]),"matching_tracked_paths":call(["grep","-I","-l","-F"]+args+["HEAD"]),"current_gate_lines":call(["grep","-I","-n","-F"]+args+["HEAD","--","scripts","config",".github"])}
print(json.dumps(result,indent=2,sort_keys=True))
