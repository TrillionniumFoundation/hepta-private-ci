import ast,copy,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
source=json.loads((root/"originals/source_readback.json").read_text())
files={f["path"]:f for f in source["files"]}
expected_scope={".github/workflows/pon-recent-batch-acceptance.yml","config/pon/pq128-lifetime-composition-current-v3.json","config/pon/pq128-source-correspondence-current-v2.json","scripts/ci/pq_lifetime_composition.py","scripts/ci/pq_lifetime_current_v2.py"}
assert source["scope_matches_provided_diff"] and set(source["working_diff_names"])==expected_scope
for f in files.values():
 for side in ("before","after"):
  b=f[side]["content"].encode()
  assert len(b)==f[side]["bytes"] and hashlib.sha256(b).hexdigest()==f[side]["sha256"]
  assert hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()==f[side]["git_blob"]
def diff_paths(a,b,prefix=()):
 if type(a) is not type(b):return [prefix]
 if isinstance(a,dict):
  assert set(a)==set(b)
  return sum((diff_paths(a[k],b[k],prefix+(k,)) for k in a),[])
 if isinstance(a,list):
  assert len(a)==len(b)
  return sum((diff_paths(x,y,prefix+(i,)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [prefix]
map_path="config/pon/pq128-source-correspondence-current-v2.json"
comp_path="config/pon/pq128-lifetime-composition-current-v3.json"
ingress="trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs"
mapping={s:json.loads(files[map_path][s]["content"]) for s in ("before","after")}
composition={s:json.loads(files[comp_path][s]["content"]) for s in ("before","after")}
map_changes=diff_paths(mapping["before"],mapping["after"])
comp_changes=diff_paths(composition["before"],composition["after"])
assert set(map_changes)=={("current_source_files_sha256",ingress),("current_source_snapshot_sha256",)}
assert set(comp_changes)=={("current_lifetime_correspondence","sha256"),("current_lifetime_correspondence","source_snapshot_sha256")}
assert mapping["after"]["status"]=="HOLD" and mapping["after"]["qualification"]==mapping["before"]["qualification"]
assert mapping["after"]["frozen_model"]==mapping["before"]["frozen_model"]
assert len(mapping["after"]["current_source_files_sha256"])==21
canonical=json.dumps(mapping["after"]["current_source_files_sha256"],sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()
snapshot=hashlib.sha256(canonical).hexdigest();map_sha=files[map_path]["after"]["sha256"]
assert snapshot==mapping["after"]["current_source_snapshot_sha256"]=="a576e79285e1d9b592de4b54acd7c0f9d97df19df7a82d448358e8f8ac9d26a6"
assert mapping["after"]["current_source_files_sha256"][ingress]=="1d676ba96d3486be0822273268375015e0649457ba2f00abc810756c366c29e4"
assert composition["after"]["current_lifetime_correspondence"]=={"path":map_path,"sha256":map_sha,"source_snapshot_sha256":snapshot}
def strip_constant_assignments(tree,names):
 out=[];values={}
 for node in tree.body:
  if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in names:
   values[node.targets[0].id]=ast.literal_eval(node.value)
  else:out.append(node)
 assert set(values)==set(names)
 tree.body=out
 return ast.dump(tree,include_attributes=False),values
ast_results=[]
for path,names in {"scripts/ci/pq_lifetime_current_v2.py":{"EXPECTED_MAP_SHA256","EXPECTED_CURRENT_FILES_SHA256"},"scripts/ci/pq_lifetime_composition.py":{"CURRENT_CORRESPONDENCE"}}.items():
 before,bvals=strip_constant_assignments(ast.parse(files[path]["before"]["content"]),names)
 after,avals=strip_constant_assignments(ast.parse(files[path]["after"]["content"]),names)
 assert before==after
 expected={"EXPECTED_MAP_SHA256":map_sha,"EXPECTED_CURRENT_FILES_SHA256":snapshot} if "EXPECTED_MAP_SHA256" in names else {"CURRENT_CORRESPONDENCE":{"path":map_path,"sha256":map_sha,"source_snapshot_sha256":snapshot}}
 assert avals==expected
 ast_results.append({"path":path,"only_changed_assignments":sorted(names),"all_other_ast_equal":True,"before_assignments":bvals,"after_assignments":avals})
workflow=files[".github/workflows/pon-recent-batch-acceptance.yml"]
old="1f4dd178a9493b71340a8684a9338a7782e0760d";new="7053c78e6a6626af763092fa4d8a031e48f6122e"
assert workflow["before"]["content"].count(old)==1
assert workflow["before"]["content"].replace(old,new)==workflow["after"]["content"]
dependency=json.loads((root/"originals/dependencies_scoped_stdout.json").read_text())
assert dependency["returncode"]==0 and all(f["exact_head_match"] for f in dependency["matched_files"])
review={
 "schema":"chain.r21.pin-repair-independent-static-review.v1",
 "status":"PASS_FOR_CURRENT_SOURCE_REBINDING",
 "reviewed_diff_sha256":source["provided_diff_sha256"],
 "reviewed_diff_bytes":source["provided_diff_bytes"],
 "baseline_commit":source["head"],
 "baseline_tree":source["baseline_tree"],
 "source_scope_exactly_five_paths":True,
 "review_did_not_run_repository_tests_or_validators":True,
 "review_did_not_modify_repository_or_workflows":True,
 "map_changed_json_paths":[list(p) for p in map_changes],
 "composition_changed_json_paths":[list(p) for p in comp_changes],
 "current_source_path_count":21,
 "changed_current_source_path_count":1,
 "current_map_sha256":map_sha,
 "recomputed_canonical_source_snapshot_sha256":snapshot,
 "workflow_only_change":"one expected Git blob, matching actual r21 multiprocess bytes",
 "python_ast_reviews":ast_results,
 "historical_frozen_files_unchanged_by_scope":True,
 "frozen_identity_values_unchanged":True,
 "hold_unchanged":True,
 "qualification_objects_and_all_other_json_fields_unchanged":True,
 "strict_check_control_flow_unchanged":True,
 "runtime_workload_source_unchanged":True,
 "reviewed_files":[{"path":f["path"],"before_sha256":f["before"]["sha256"],"after_sha256":f["after"]["sha256"],"after_git_blob":f["after"]["git_blob"]} for f in files.values()],
 "dependency_scan":{"scope":dependency["scope"],"matched_paths":len(dependency["matched_files"]),"all_matched_bytes_equal_prior_head":True,"additional_current_literal_map_or_snapshot_pin_outside_five_files_found":False,"historical_corpus":"config/pon/pq-cross-branch-corpus-v1.json contains historical Git blobs and remains unchanged.","limitations":"Whole-repository git grep timed out at45seconds and is preserved. The successful follow-up scan was limited to scripts/config/.github, so no exhaustive whole-repository claim is made."},
 "limitations":["This is source review, not a new execution of CI.","Successful business windows and any reported prior green regression counts are outside this independent static review.","No security theorem, production activation, or whole-chain qualification is granted."]
}
raw=json.dumps(review,indent=2,sort_keys=True)+"\n"
with (root/"REVIEW.json").open("x") as f:f.write(raw)
print(json.dumps({"review_path":str(root/"REVIEW.json"),"bytes":len(raw.encode()),"sha256":hashlib.sha256(raw.encode()).hexdigest(),"status":review["status"],"only_current_bindings_changed":True},indent=2))

