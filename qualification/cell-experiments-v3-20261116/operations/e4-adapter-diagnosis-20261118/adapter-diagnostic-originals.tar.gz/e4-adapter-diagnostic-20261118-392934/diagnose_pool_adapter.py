"""Inspect real loaded adapter bytes without generation or changing any admission gate."""

from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import time

ROOT = Path("/dev/shm/hepta-cell-experiments-v3-20261116-0c078a")
SOURCE = ROOT / "e4-controls-source-20261118-392934"
OUT = ROOT / "operations/e4-adapter-diagnostic-20261118-392934/run-01"
PERSIST = Path(
    "/home/qian-qi/hepta-cell-experiments-v3-20261116-0c078a/operations/e4-adapter-diagnostic-20261118-392934/run-01"
)


def write(name, value):
    raw = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    for root in (OUT, PERSIST):
        with (root / name).open("xb") as stream:
            stream.write(raw)


def main():
    OUT.mkdir(exist_ok=False)
    PERSIST.mkdir(exist_ok=False)
    started = time.monotonic()
    write(
        "INTENT.json",
        {
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "operation": "Inspect C load as first named adapter, extra default, extra trainable label",
            "generation_calls": 0,
            "training_steps": 0,
            "production_gate_changed": False,
            "failed_protocol_sha256": "951c24b55bf1afcc9e4e6dc57aaf746bf52f7c4836da0d57c3f9acd386612b8e",
        },
    )

    def expired(signum, frame):
        raise TimeoutError("owned adapter inspection exceeded 300 seconds")

    signal.signal(signal.SIGALRM, expired)
    signal.alarm(300)
    path = SOURCE / "run_extended_circuit_once.py"
    if (
        hashlib.sha256(path.read_bytes()).hexdigest()
        != "b584f456fc83b06f655efc732e34172659ae3470f5a50df2ca558da155d40d05"
    ):
        raise ValueError("frozen diagnostic admission source differs")
    spec = importlib.util.spec_from_file_location(
        "frozen_e4_inspection_admission", path
    )
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    guard.admission(
        "951c24b55bf1afcc9e4e6dc57aaf746bf52f7c4836da0d57c3f9acd386612b8e", full=True
    )
    inventory = json.loads((guard.MODULE / "SOURCE.json").read_text())
    cli_sha = next(
        row["sha256"] for row in inventory["files"] if row["path"] == "round03_cli.py"
    )
    cli = guard.exact_module(
        guard.MODULE / "online_v4/round03_cli.py", cli_sha, "frozen_original_bootstrap"
    )
    cli.bootstrap(ROOT, guard.MODULE)
    from cell_experiments import causal_probe_v3 as probe, causal_train_v3 as numeric
    from cell_experiments.online_v4.round03_plan import material_inputs
    from cell_experiments.online_v4.shared_pool_v4 import (
        adapter_parameters,
        _release_view,
    )
    from safetensors.torch import load_file
    import peft

    context, manifests = material_inputs(ROOT)
    manifest = manifests["controlled_correction"]
    directory = ROOT / manifest["adapter_directory"]
    training = json.loads((directory.parent / "TRAINING.json").read_text())
    saved = load_file(str(directory / "adapter_model.safetensors"), device="cpu")
    torch, _ = probe._libraries()
    torch.cuda.set_per_process_memory_fraction(
        0.70, torch.device(manifest["runtime"]["device"])
    )
    torch.cuda.reset_peak_memory_stats()
    view, model, observations = None, None, []
    try:
        view = probe.Predictor(manifest["base_manifest"], ROOT)
        model = peft.PeftModel.from_pretrained(
            view.model,
            str(directory),
            adapter_name="cell_0",
            is_trainable=False,
            local_files_only=True,
        )
        view.model = model
        for label, trainable in (
            ("cell_0", False),
            ("default", False),
            ("cell_1", True),
        ):
            if label != "cell_0":
                model.load_adapter(
                    str(directory),
                    adapter_name=label,
                    is_trainable=trainable,
                    local_files_only=True,
                )
            model.set_adapter(label)
            model.eval()
            model.requires_grad_(False)
            parameters = adapter_parameters(model, label)
            tensors = []
            for name, value in parameters:
                key = name.replace(".lora_A.default.", ".lora_A.").replace(
                    ".lora_B.default.", ".lora_B."
                )
                original = saved[key]
                actual = value.detach().cpu().contiguous()
                actual_bytes = actual.view(torch.uint8).numpy().tobytes()
                original_bytes = (
                    original.contiguous().view(torch.uint8).numpy().tobytes()
                )
                tensors.append(
                    {
                        "normalized_name": name,
                        "saved_key": key,
                        "loaded_dtype": str(actual.dtype),
                        "saved_dtype": str(original.dtype),
                        "loaded_shape": list(actual.shape),
                        "saved_shape": list(original.shape),
                        "loaded_bytes_sha256": hashlib.sha256(actual_bytes).hexdigest(),
                        "saved_bytes_sha256": hashlib.sha256(
                            original_bytes
                        ).hexdigest(),
                        "bytes_equal": actual_bytes == original_bytes,
                        "max_absolute_difference": float(
                            (actual.float() - original.float()).abs().max()
                        ),
                    }
                )
            write("TENSORS_" + label + ".json", tensors)
            observation = {
                "label": label,
                "load_is_trainable": trainable,
                "actual_normalized_hash": numeric._parameter_hash(parameters, torch),
                "expected_training_after": training["parameter_after"],
                "tensor_count": len(tensors),
                "byte_identical_tensors": sum(row["bytes_equal"] for row in tensors),
                "loaded_dtypes": dict(Counter(row["loaded_dtype"] for row in tensors)),
                "loaded_raw_names": [
                    name
                    for name, _ in model.named_parameters()
                    if any(
                        "." + kind + "." + label + "." in name
                        for kind in ("lora_A", "lora_B")
                    )
                ],
                "normalized_names": [name for name, _ in parameters],
            }
            observations.append(observation)
            print(
                json.dumps(
                    {
                        key: value
                        for key, value in observation.items()
                        if key not in ("loaded_raw_names", "normalized_names")
                    }
                ),
                flush=True,
            )
        write(
            "RESULT.json",
            {
                "status": "INSPECTED",
                "observations": observations,
                "total_wall_seconds": time.monotonic() - started,
                "peak_cuda_allocated_bytes": torch.cuda.max_memory_allocated(),
                "generation_calls": 0,
                "training_steps": 0,
                "qualification": False,
            },
        )
    finally:
        model = None
        if view is not None:
            _release_view(view, torch)
        signal.alarm(0)


if __name__ == "__main__":
    os.environ.update(
        HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", TOKENIZERS_PARALLELISM="false"
    )
    main()
