"""Own each previously frozen Round03 stage and retain its actual process result."""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tarfile
import time

ROOT = Path("/dev/shm/hepta-cell-experiments-v3-20261116-0c078a")
RUNTIME = Path("/home/qian-qi/hepta-cell-experiments-v3-20261116-0c078a")
MODULE = ROOT / "round03-source-20261118-392934-b"
RUN = "research-round03-20261118-392934-b"
JOBS = ("prepare", "e2-teacher", "eval-teacher-primary", "eval-teacher-cold",
        "e2-shadow", "eval-shadow-primary", "eval-shadow-cold", "e2-controlled",
        "eval-controlled-primary", "eval-controlled-cold")


CLOSURE = ROOT / "operations/ROUND03_CLOSURE_20261118_392934_V4.json"
CLOSURE_SHA = "9e56b5cb0e906568a17c17f3aeeaf3979766fdcee880bac6fd40a78f310f5f12"
RESTORATION = RUNTIME / "operations/recovery-20261118-e4c/install/RESULT.json"
RESTORATION_SHA = "fbf283210529410a5708e366468078f38107b2ae6b60d55ad993e80b985eecf1"


def verify_full_closure():
    if hashlib.sha256(CLOSURE.read_bytes()).hexdigest() != CLOSURE_SHA:
        raise ValueError("retained source closure receipt changed")
    closure = json.loads(CLOSURE.read_text())
    for dirname, expected in closure["complete_directory_file_hashes"].items():
        directory = ROOT / dirname
        actual = {p.relative_to(directory).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in directory.rglob("*") if p.is_file()}
        if actual != expected:
            raise ValueError("retained source or audit material changed: " + dirname)
    if hashlib.sha256(RESTORATION.read_bytes()).hexdigest() != RESTORATION_SHA:
        raise ValueError("runtime restoration receipt changed")
    runtime_check = json.loads(RESTORATION.read_text())
    if runtime_check["status"] != "COMPLETE" or runtime_check["verified"]["missing"] or runtime_check["verified"]["different"]:
        raise ValueError("complete original runtime verification required")
    io_path = ROOT / "e1e2-operation-helpers-04/qwen_development_io_v3.py"
    spec = importlib.util.spec_from_file_location("round03_frozen_io_preflight", io_path)
    io = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(io)
    context = json.loads((ROOT / "research-sft-02/INPUTS.json").read_text())
    io.runtime_guard(RUNTIME, context["runtime"])


def main():
    if sys.argv[1:] != ["run-sequence-once"]:
        raise ValueError("explicit single sequence launch required")
    verify_full_closure()
    inventory_path = MODULE / "SOURCE.json"
    if hashlib.sha256(inventory_path.read_bytes()).hexdigest() != "928aaa75c75023954432302b46d2064311ccf5e290e3e605e82193e4c7ba7814":
        raise ValueError("source inventory differs")
    inventory = json.loads(inventory_path.read_text())
    for item in inventory["files"]:
        raw = (MODULE / "online_v4" / item["path"]).read_bytes()
        if len(raw) != item["bytes"] or hashlib.sha256(raw).hexdigest() != item["sha256"]:
            raise ValueError("frozen source differs: " + item["path"])
    wrapper = ROOT / "operations/launch_qwen_research_owned_v1_02.py"
    spec = importlib.util.spec_from_file_location("retained_owned_launcher", wrapper)
    owner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owner)
    receipts = ROOT / "operations/round03-owned-20261118-392934-b"
    receipts.mkdir(exist_ok=False)
    archive_root = RUNTIME / "operations/round03-checkpoints-20261118-392934-b"
    archive_root.mkdir(exist_ok=False)
    environment = dict(os.environ)
    for key, name in (("TMPDIR", "tmp"), ("XDG_CACHE_HOME", "cache"),
                      ("CUDA_CACHE_PATH", "cuda-cache"), ("TRITON_CACHE_DIR", "triton-cache"),
                      ("TORCH_HOME", "torch-cache"), ("HF_HOME", "hf-cache")):
        environment[key] = str(ROOT / name)
    environment.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                       HF_HUB_DISABLE_TELEMETRY="1", TOKENIZERS_PARALLELISM="false",
                       OMP_NUM_THREADS="2", OPENBLAS_NUM_THREADS="2")
    sequence = {"schema": "hepta.round03-owned-sequence.v1", "jobs": JOBS,
                "run_name": RUN, "source_base_commit": inventory["origin_commit"],
                "source_patches": inventory["patches"],
                "source_inventory_sha256": owner.checksum(inventory_path),
                "retained_source_closure_sha256": CLOSURE_SHA,
                "runtime_restoration_sha256": RESTORATION_SHA,
                "source_identity_scope": "source119 matches eb56; online_v4 has explicit test-only fixture correction; research/helper tuple separately pinned",
                "owned_wrapper_sha256": owner.checksum(wrapper),
                "sequence_wrapper_sha256": owner.checksum(Path(__file__).absolute()),
                "automatic_retry": False, "new_independent_tasks": 0,
                "scientific_confirmation_qualified": False,
                "native_cell_adoption": False, "full_system_cost_complete": False}
    owner.write_new(receipts / "SEQUENCE.json", sequence)
    for index, job in enumerate(JOBS):
        verify_full_closure()
        argv = [str(RUNTIME / "venv/bin/python"), "-I", "-B",
                str(MODULE / "online_v4/round03_cli.py"), "--artifact-root", str(ROOT),
                "--module-root", str(MODULE), "--run-name", RUN, job]
        code = owner.run_owned(receipts / job, argv, ROOT, environment,
            {"role": job, "operation_key": RUN + ":" + job,
             "source_inventory_sha256": sequence["source_inventory_sha256"],
             "automatic_retry": False})
        started = time.perf_counter()
        archive = archive_root / (str(index).zfill(2) + "-" + job + ".tar.gz")
        with tarfile.open(archive, "x:gz") as stream:
            if (ROOT / RUN).exists():
                stream.add(ROOT / RUN, arcname=RUN)
            stream.add(receipts, arcname=receipts.name)
            stream.add(MODULE, arcname=MODULE.name)
            stream.add(Path(__file__).absolute(), arcname=Path(__file__).name)
            stream.add(CLOSURE, arcname=CLOSURE.name)
            stream.add(RESTORATION, arcname="RUNTIME_RESTORATION.json")
            stream.add(wrapper, arcname=wrapper.name)
            for name in ("candidate-qwen-03", "research-sft-v1-source", "e1e2-operation-helpers-04"):
                stream.add(ROOT / name, arcname=name)
        owner.write_new(archive.with_suffix(".json"),
            {"archive": str(archive), "bytes": archive.stat().st_size,
             "sha256": owner.checksum(archive), "job_wait_returncode": code,
             "archive_wall_seconds": time.perf_counter() - started})
        print(json.dumps({"stage": job, "wait_returncode": code,
                          "checkpoint": str(archive)}), flush=True)
        if code:
            return code if code > 0 else 128 - code
    owner.write_new(receipts / "SEQUENCE_COMPLETE.json",
                    {"all_jobs_wait_returncode_zero": True, "GPU_released": True,
                     "business_outcome_claim": "inspect retained verifiers and reports"})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
