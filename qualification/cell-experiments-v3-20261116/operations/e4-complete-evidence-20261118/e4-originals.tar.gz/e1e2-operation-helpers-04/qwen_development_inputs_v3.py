"""Bind exposed A/B, actual parent attempts, and A-only retrieval without execution."""

import copy
import hashlib
from pathlib import Path

import qwen_development_io_v3 as io


RECORD_IDS = ("A-counter", "A-mse", "A-readout-score", "A-clipped-metrics",
              "A-pair-map", "A-colon-repair", "B-stable-frame", "B-json-format",
              "B-wire-digest")
QUALIFICATION = "qualification/cell-experiments-v3-20261116"
FORBIDDEN = {
    "qualification/cell-experiments-v2-20261116/task-fixtures/catalog-C.sealed.json",
    "qualification/cell-experiments-v2-20261116/task-fixtures/specs-confirmation.json",
}


def semantic(record, answer, verification):
    from cell_experiments import data, repo_execution
    from cell_experiments.circuit_receipts_v3 import business_evidence

    io.require(verification.get("record_id") == record["record_id"]
               and verification.get("input_sha256")
               == hashlib.sha256(record["task"]["input"].encode()).hexdigest()
               and verification.get("parameters_sha256")
               == data.digest(record["task"]["verifier"]["parameters"])
               and verification.get("verifier_source_sha256")
               == io.file_hash(Path(repo_execution.__file__)),
               "semantic receipt belongs to another task, input or verifier")
    return business_evidence({"semantic_receipt": verification,
                             "semantic_receipt_sha256": verification.get("receipt_sha256"),
                             "raw_answer": answer, "success": verification.get("success")})


def bound_readiness(records, parent, readiness, generation_digest, raw_directory=None):
    """Validate actual raw requests/answers before using their A success or feedback."""
    from cell_experiments import data, protocol_v3 as protocol

    io.verify_receipt(readiness)
    io.require(readiness.get("schema") == "hepta.development-readiness.v3"
               and readiness.get("model_digest") == data.digest(parent)
               and len(readiness.get("rows", [])) == len(records),
               "complete readiness for this parent/panel required")
    successful_a, calls, controlled = 0, 0, []
    for index, (record, row) in enumerate(zip(records, readiness["rows"])):
        io.require(row.get("task_digest") == data.digest(record)
                   and all(row.get(key) == record[key] for key in
                           ("record_id", "task_id", "source_id", "lineage_id")),
                   "readiness row identity changed")
        steps, messages = row.get("steps", []), copy.deepcopy(protocol.require_prepared(record))
        io.require(1 <= len(steps) <= io.BUDGET["maximum_attempts"], "bounded actual attempts required")
        successes = []
        for number, step in enumerate(steps):
            io.verify_receipt(step)
            request = {"record_id": record["record_id"],
                       "task": {"input": record["task"]["input"], "messages": copy.deepcopy(messages)}}
            output = step["output"]
            io.require(step.get("number") == number
                       and step.get("request_sha256") == data.digest(request)
                       and output.get("loaded_model_digest") == data.digest(parent)
                       and output.get("input_sha256") == hashlib.sha256(record["task"]["input"].encode()).hexdigest()
                       and output.get("messages_sha256") == data.digest(messages)
                       and output.get("generation_config_sha256") == generation_digest,
                       "readiness output does not bind the actual native request")
            io.require(type(output.get("pid")) is int and output["pid"] > 0
                       and type(output.get("input_tokens")) is int
                       and 0 < output["input_tokens"] <= io.BUDGET["max_input_tokens"]
                       and type(output.get("output_tokens")) is int
                       and output["output_tokens"] == len(output.get("output_token_ids", []))
                       and 0 <= output["output_tokens"] <= io.BUDGET["max_new_tokens"]
                       and output.get("max_new_tokens") == io.BUDGET["max_new_tokens"],
                       "native token/worker accounting differs from the frozen budget")
            evidence = semantic(record, output["answer"], step["verification"])
            expected_feedback = protocol.feedback(step["verification"])
            io.require(step.get("execution_summary") == protocol.execution_summary(step["verification"])
                       and step.get("executed") is evidence["verifier_executed"]
                       and step.get("semantic_measurement") == "measured"
                       and step.get("feedback") == expected_feedback
                       and not any(successes), "readiness observation/history changed")
            if raw_directory is not None:
                directory = Path(raw_directory) / str(index)
                io.require(io.read(directory / f"request-{number}.json") == request
                           and io.read(directory / f"output-{number}.json") == output
                           and io.read(directory / f"step-{number}.json") == step,
                           "readiness aggregate differs from retained raw artifacts")
            successes.append(evidence["business_success"] is True)
            messages.extend([{"role": "assistant", "content": output["answer"]},
                             {"role": "tool", "content": expected_feedback}])
        io.require(row.get("success") is successes[-1]
                   and row.get("first_attempt_success") is successes[0]
                   and row.get("semantic_measurement") == "measured",
                   "readiness task summary differs from business observations")
        calls += len(steps)
        if record["split"] == "train":
            successful_a += successes[-1]
            controlled.append(copy.deepcopy(row))
    io.require(readiness.get("model_calls") == calls
               and readiness.get("successful_tasks") == sum(row["success"] for row in readiness["rows"]),
               "readiness counters disagree with retained attempts")
    return {"successful_A_tasks": successful_a, "prior_model_calls": calls,
            "controlled_observations": controlled,
            "controlled_new_model_calls": 0, "controlled_new_verifier_calls": 0,
            "controlled_provenance": "reuse of prior A readiness executions; not shadow or new experience"}


def retrieval_panels(a_records, panels):
    """Use the frozen v2 lexical rule; exclude self/lineage from A retention."""
    from cell_experiments import data, protocol_v3 as protocol, study_v2

    io.require(a_records and all(row["split"] == "train" and row["exposure"] == "development"
                               for row in a_records), "retrieval examples must be exposed A only")
    shown, bindings = {}, {}
    for panel, records in panels.items():
        shown[panel], bindings[panel] = [], []
        for record in records:
            choices = [row for row in a_records
                       if row["task_id"] != record["task_id"] and row["lineage_id"] != record["lineage_id"]]
            io.require(bool(choices), "no eligible A-only retrieval example; no self-answer fallback")
            item = study_v2.retrieve(choices, [record])[0]
            chosen_id = item.pop("retrieval_record_id")
            chosen = next(row for row in choices if row["record_id"] == chosen_id)
            # Bind this frozen augmentation without executing B's authored answer.
            item.pop("verified_outcome", None)
            item.pop("protocol_reference_receipt", None)
            item["action_protocol_v3"] = {
                **copy.deepcopy(record["action_protocol_v3"]),
                "prepared_input_sha256": data.digest(item["task"]["input"]),
                "prepared_messages_sha256": data.digest(item["task"]["messages"]),
                "retrieval_source_record_digest": data.digest(chosen),
                "original_prepared_record_digest": data.digest(record),
                "reference_reverified_for_augmented_prompt": False,
            }
            protocol.require_prepared(item)
            immutable = lambda row: {
                key: value for key, value in row.items()
                if key not in ("task", "verified_outcome", "protocol_reference_receipt", "action_protocol_v3")}
            io.require(immutable(item) == immutable(record)
                       and {k: v for k, v in item["task"].items() if k not in ("input", "messages")}
                       == {k: v for k, v in record["task"].items() if k not in ("input", "messages")},
                       "retrieval changed task identity, source, labels or verifier")
            shown[panel].append(item)
            bindings[panel].append({"task_id": record["task_id"], "original_digest": data.digest(record),
                                    "shown_digest": data.digest(item), "retrieved_record_id": chosen_id,
                                    "retrieved_record_digest": data.digest(chosen),
                                    "rule": "study_v2.retrieve lexical overlap; A-only, self/lineage excluded"})
    return shown, bindings


def load_inputs(root, source, readiness_directory):
    """Read and bind existing evidence; never load a model or rerun references."""
    from cell_experiments import data, protocol_v3 as protocol, causal_probe_v3 as probe

    root, source, directory = Path(root), Path(source), Path(readiness_directory)
    io.workspace_guard(root, source, directory)
    for path in (source, directory):
        io.require(path.is_dir() and not path.is_symlink() and path.resolve().is_relative_to(root),
                   "source and prior readiness must be local artifact-root directories")
    completed = io.read(directory / "RESULT.json")
    io.verify_receipt(completed)
    io.require(completed.get("schema") == "hepta.qwen-readiness-operation-result.v3"
               and completed.get("status") == "COMPLETE"
               and completed.get("new_C") is False and completed.get("training_started") is False,
               "a completed, exposed parent readiness operation is required")
    retained = completed["retained_file_sha256"]
    io.verify_inventory(directory, retained)
    frozen = io.read(directory / "FREEZE.json")
    source_record = io.read(directory / "SOURCE.json")
    io.require(completed["freeze_digest"] == data.digest(frozen)
               and frozen["source"] == source_record
               and source_record["archive_sha256"] == io.SOURCE_SHA
               and source_record["manifest_sha256"] == io.SOURCE_MANIFEST_SHA,
               "readiness source archive identity changed")
    source_inventory = source_record["materialized_files"]
    source_manifest = io.read(root / "operations/QWEN_SOURCE_02.json", io.SOURCE_MANIFEST_SHA)
    io.require(source_manifest["files"] == source_inventory
               and len(source_inventory) == 119 and not FORBIDDEN.intersection(source_inventory),
               "exact source02 inventory without confirmation required")
    io.verify_inventory(source, source_inventory, exact=True)
    parent, records = io.read(directory / "parent.json"), io.read(directory / "PREPARED_RECORDS.json")
    io.require((parent.get("schema"), parent.get("family"), parent.get("model_id"))
               == (probe.SCHEMA, probe.FAMILY, probe.MODEL_ID), "fixed Qwen parent required")
    runtime = parent["runtime"]
    io.require(runtime["device"] == "cuda:0" and runtime["dtype"] == "bfloat16"
               and runtime["max_input_tokens"] == io.BUDGET["max_input_tokens"]
               and runtime["max_new_tokens"] == io.BUDGET["max_new_tokens"]
               and runtime["generation"]["max_new_tokens"] == 384
               and runtime["generation"]["do_sample"] is False
               and runtime["generation"]["num_beams"] == 1,
               "same frozen greedy CUDA parent and 384-token output budget required")
    io.require(tuple(row["record_id"] for row in records) == RECORD_IDS
               and io.read(directory / "PREPARED_A_RECORDS.json") == records[:6]
               and frozen["records_digest"] == data.digest(records)
               and frozen["A_records_digest"] == data.digest(records[:6])
               and frozen["model_digest"] == completed["model_digest"] == data.digest(parent),
               "exact old A/B panel or parent identity differs")
    original_path = source / QUALIFICATION / "development-old-open.records.jsonl"
    original = [data._parse(line) for line in original_path.read_bytes().splitlines() if line.strip()]
    io.require(tuple(row["record_id"] for row in original) == RECORD_IDS, "old source panel changed")
    for index, (row, old) in enumerate(zip(records, original)):
        data.validate_record(row)
        protocol.require_prepared(row)
        expected = protocol.prepare_record(old)
        stripped = {k: v for k, v in row.items() if k not in ("verified_outcome", "protocol_reference_receipt")}
        io.require(stripped == expected and row["exposure"] == "development"
                   and row["split"] == ("train" if index < 6 else "selection")
                   and (index >= 6 or row["authorization"]["training_allowed"] is True),
                   "prepared task or source/provenance/authorization changed")
        reference = row["protocol_reference_receipt"]
        io.require(semantic(row, row["final_answer"], reference)["business_success"] is True
                   and row["verified_outcome"]["receipt_sha256"] == reference["receipt_sha256"],
                   "saved authored reference binding is incomplete")
    repository = directory / "repository"
    readiness, panel_freeze = io.read(repository / "READINESS.json"), io.read(repository / "FREEZE.json")
    io.require(io.read(repository / "RECORDS.json") == records
               and readiness["freeze_digest"] == data.digest(panel_freeze)
               and panel_freeze["records_digest"] == data.digest(records)
               and panel_freeze["model_digest"] == data.digest(parent)
               and panel_freeze["source_inventory"] == {
                   Path(name).name: value for name, value in source_inventory.items()
                   if name.startswith("scripts/cell_experiments/")}
               and panel_freeze["maximum_attempts"] == 2,
               "parent readiness panel/freeze differs")
    loaded = io.read(directory / "MODEL_LOADED.json")
    io.require(loaded["model_digest"] == data.digest(parent)
               and data.digest(loaded["generation"]) == loaded["generation_digest"]
               and all(loaded["generation"].get(key) == value for key, value in runtime["generation"].items()),
               "loaded generation receipt differs")
    gate = bound_readiness(records, parent, readiness, loaded["generation_digest"], repository)
    io.require(completed["successful_A_tasks"] == gate["successful_A_tasks"],
               "parent A count differs from actual bound business results")
    panels = {"B_exposed": records[6:], "A_retention": records[:6]}
    shown, retrieval_bindings = retrieval_panels(records[:6], panels) if gate["successful_A_tasks"] else ({}, {})
    runtime_receipt = io.read(directory / "RUNTIME.json")
    io.require(frozen["runtime"] == runtime_receipt, "runtime evidence changed")
    return {"parent": parent, "records": records, "readiness": readiness, "gate": gate,
            "panels": panels, "retrieval_panels": shown, "retrieval_bindings": retrieval_bindings,
            "runtime": runtime_receipt, "source_inventory": source_inventory,
            "readiness_inventory": {**retained, "RESULT.json": io.file_hash(directory / "RESULT.json")},
            "generation_digest": loaded["generation_digest"]}


def corrected(original, observed, mode, directory):
    """One saved reference recheck per correction, separate from model experience."""
    from cell_experiments import data, protocol_v3 as protocol
    from cell_experiments.repo_interaction_v2 import corrected_record

    io.require(mode in ("shadow", "controlled") and original["split"] == "train",
               "A-only explicit correction mode required")
    if mode == "shadow":
        io.require(all(step["verification"] is None and step["executed"] is False
                       and step["semantic_measurement"] == "unmeasured" for step in observed["steps"]),
                   "executed observations cannot be relabeled shadow")
    record = corrected_record(original, observed, mode)
    io.require(all(event.get("trainable") is False for event in record["trajectory"]
                   if event["actor"] == "student"), "student actions cannot become targets")
    protocol.require_prepared(record)
    # Same binding as protocol.verify_reference, with its single verifier call
    # saved before admission so even a failing reference receipt is retained.
    receipt = data.verify_answer(record, record["final_answer"])
    io.write_new(Path(directory) / "REFERENCE.json", receipt)
    io.require(semantic(record, record["final_answer"], receipt)["business_success"] is True,
               "authored correction reference failed business verification")
    record["protocol_reference_receipt"] = receipt
    record["verified_outcome"] = {"success": True, "receipt_sha256": receipt["receipt_sha256"],
                                  "verifier_name": "repo_patch", "verifier_version": "1"}
    data.validate_record(record)
    io.write_new(Path(directory) / "RECORD.json", record)
    return data._parse(data.canonical(record))
