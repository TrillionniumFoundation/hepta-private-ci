"""Prepare or run bounded E1/E2 development after an actual Qwen A success.

Default mode is preflight: no model loading, reference execution, or child jobs.
Use the recovered interpreter with -I -B. All fits and regressions are separate
owned workers. Only already exposed A/B enter this operation; no new C is read.
"""

import argparse
import json
from pathlib import Path
import signal
import sys
import time
import traceback

sys.path.insert(0, str(Path(__file__).resolve().parent))
import qwen_development_io_v3 as io
import qwen_development_inputs_v3 as inputs


def schedule():
    return [{"arm": "corrections", "phase": "collect", "wall_seconds": io.BUDGET["shadow_wall_seconds"]},
            *[{"arm": arm, "phase": phase,
               "wall_seconds": io.BUDGET["fit_and_evaluation_wall_seconds"]
               if arm in io.FIT_MODES and phase == "primary" else io.BUDGET["evaluation_wall_seconds"]}
              for arm in io.ARMS for phase in ("primary", "cold")]]


def prepare(root, source, readiness_directory, output, mode):
    """Only verify retained bytes and compute prompts; never execute a reference."""
    root, source, readiness_directory, output = map(Path, (root, source, readiness_directory, output))
    io.require(mode in ("preflight", "run"), "explicit local preparation mode required")
    io.workspace_guard(root, source, readiness_directory, output)
    io.require(not output.is_relative_to(source) and not output.is_relative_to(readiness_directory)
               and source != readiness_directory, "output must not modify frozen source or prior readiness")
    output.mkdir(parents=True, exist_ok=False)
    before = io.usage()
    io.write_new(output / "STARTED.json", {"schema": "hepta.qwen-development-operation.v3",
                 "mode": mode, "started_at_ns": time.time_ns(), "budget": io.BUDGET, **io.SCOPE})
    try:
        # Verify source membership before importing it; the only source manifest
        # is source02, whose two historical confirmation members were excluded.
        source_manifest = io.read(root / "operations/QWEN_SOURCE_02.json", io.SOURCE_MANIFEST_SHA)
        io.require(not inputs.FORBIDDEN.intersection(source_manifest["files"]), "confirmation source forbidden")
        io.verify_inventory(source, source_manifest["files"], exact=True)
        io.bootstrap(source)
        context = inputs.load_inputs(root, source, readiness_directory)
        io.runtime_guard(io.RUNTIME_ROOT, context["runtime"])
        status = "ACTION_READY" if context["gate"]["successful_A_tasks"] > 0 else "NOT_READY"
        io.write_new(output / "INPUTS.json", context)
        freeze = io.sealed({
            "schema": "hepta.qwen-development-freeze.v3", "status": status,
            "operation_id": "qwen-e1e2-" + io.digest({"output": str(output), "started": time.time_ns()}),
            "created_at_ns": time.time_ns(), "artifact_root": str(root), "source": str(source),
            "workspace_root": str(root), "runtime_root": str(io.RUNTIME_ROOT),
            "output": str(output), "readiness_directory": str(readiness_directory),
            "inputs_path": str(output / "INPUTS.json"), "inputs_sha256": io.file_hash(output / "INPUTS.json"),
            "parent_digest": io.digest(context["parent"]),
            "parent_readiness_digest": io.digest(context["readiness"]),
            "successful_A_tasks": context["gate"]["successful_A_tasks"],
            "source_inventory": context["source_inventory"], "helper_inventory": io.helper_inventory(),
            "readiness_inventory": context["readiness_inventory"], "runtime": context["runtime"],
            "budget": io.BUDGET, "schedule": schedule() if status == "ACTION_READY" else [],
            "fitting_modes": io.FIT_MODES, "fit_plans_must_precede_all_fits": True,
            "reference_rechecks": "12 authored correction checks plus 24 mandatory fit admission checks; no new student experience",
            "controlled_reuse": "prior A readiness raw steps; zero new model/verifier calls for reused steps",
            "retrieval_rule": "frozen study_v2.retrieve; A-only and no same task/lineage examples",
            "selection": "no candidate winner selected; old B is exposed development only", **io.SCOPE})
        io.write_new(output / "FREEZE.json", freeze)
        report = io.sealed({"schema": "hepta.qwen-development-preflight.v3", "status": status,
                            "mode": mode, "freeze_digest": io.digest(freeze),
                            "successful_A_tasks": freeze["successful_A_tasks"],
                            "fits_started": 0, "model_loads": 0, "new_model_calls": 0,
                            "new_reference_calls": 0, "cost": io.cost(before), **io.SCOPE})
        io.write_new(output / "PREFLIGHT.json", report)
        return context, freeze, before
    except BaseException as error:
        io.write_new(output / "PREPARATION_FAILED.json", {
            "error": repr(error), "traceback": traceback.format_exc(),
            "model_loads": 0, "fits_started": 0, "new_reference_calls": 0,
            "cost": io.cost(before), "automatic_retry": False, **io.SCOPE})
        raise


def child(freeze, entry, extra, deadline):
    output = Path(freeze["output"])
    io.guard(freeze)
    remaining = deadline - time.monotonic()
    io.require(remaining > 0, "frozen operation wall budget exhausted")
    seconds = min(entry["wall_seconds"], remaining)
    name = entry["arm"] + "-" + entry["phase"]
    job = io.sealed({"schema": "hepta.qwen-development-job.v3", "schedule_entry": entry,
                     "freeze_path": str(output / "FREEZE.json"),
                     "freeze_sha256": io.file_hash(output / "FREEZE.json"),
                     "worker_wall_seconds": seconds, **extra})
    job_path = output / "jobs" / (name + ".json")
    io.write_new(job_path, job)
    command = [freeze["runtime"]["python"], "-I", "-B",
               str(Path(__file__).parent / "qwen_development_execution_v3.py"), "--job", str(job_path)]
    exited = io.launch(command, output / "processes" / name, seconds)
    result_path = output / "workers" / name / "RESULT.json"
    result = None
    if exited["exit_code"] == 0:
        result = io.read(result_path)
        io.verify_receipt(result)
        io.require(result["job_digest"] == io.digest(job)
                   and result["freeze_digest"] == io.digest(freeze)
                   and result["pid"] == exited["pid"], "child result identity differs")
    return {"arm": entry["arm"], "phase": entry["phase"], "exit": exited,
            "result_path": str(result_path) if result is not None else None,
            "result_sha256": io.file_hash(result_path) if result is not None else None,
            "result": result}


def cold_comparison(primary, cold):
    """Repeated business observations, with exact candidate bytes and real outcomes."""
    io.require(primary["manifest"] == cold["manifest"] and primary["pid"] != cold["pid"],
               "cold load must use the same manifest in a separate process")
    a, b = primary["evaluation"], cold["evaluation"]
    io.require(a["model_digest"] == b["model_digest"]
               and a["generation_digest"] == b["generation_digest"]
               and a["original_panels_digest"] == b["original_panels_digest"]
               and a["shown_panels_digest"] == b["shown_panels_digest"],
               "cold regression inputs or loaded model changed")
    def outcomes(report):
        return [(row["panel"], row["task_id"], row["success"], row["first_attempt_success"])
                for row in report["rows"]]
    def outputs(report):
        return [[(step["output"]["answer"], step["output"]["output_token_ids"])
                 for step in row["steps"]] for row in report["rows"]]
    return {"same_manifest": True, "different_worker_pid": True,
            "business_outcomes_equal": outcomes(a) == outcomes(b),
            "raw_answers_and_tokens_equal": outputs(a) == outputs(b),
            "primary_successful_tasks": a["successful_tasks"],
            "cold_successful_tasks": b["successful_tasks"],
            "repeated_observation": True, "independent_sample_increment": 0,
            "native_cell_adoption": False, "new_C": False}


def raw_ledger(output, children):
    """Count retained evidence; killed/missing outputs do not become measured zero."""
    workers = Path(output) / "workers"
    outputs = [io.read(path) for path in sorted(workers.rglob("output-*.json"))]
    requests = list(workers.rglob("request-*.json"))
    steps = [io.read(path) for path in sorted(workers.rglob("step-*.json"))]
    references = [io.read(path) for path in sorted(workers.rglob("REFERENCE.json"))]
    reference_batches = [io.read(path) for path in sorted(workers.rglob("REFERENCE_RECHECKS.json"))]
    complete = all(row["exit"]["exit_code"] == 0 for row in children)
    finished_steps = []
    for path in workers.rglob("STEPS.jsonl"):
        for raw in path.read_bytes().splitlines():
            try:
                finished_steps.append(json.loads(raw))
            except ValueError:
                # A killed final line is retained; earlier durable lines still count.
                complete = False
    io.require(len(outputs) <= io.BUDGET["maximum_model_calls"]
               and len(requests) <= io.BUDGET["maximum_model_calls"]
               and len(finished_steps) <= io.BUDGET["maximum_training_steps"],
               "retained execution exceeded the frozen operation budget")
    verified = sum(step["verification"] is not None for step in steps)
    reference_count = len(references) + sum(map(len, reference_batches))
    output_tokens = sum(row["output_tokens"] for row in outputs)
    io.require(output_tokens <= io.BUDGET["maximum_generated_tokens"]
               and verified <= io.BUDGET["maximum_evaluation_verifier_calls"]
               and reference_count <= io.BUDGET["maximum_reference_rechecks"],
               "retained tokens or verification exceeded the frozen budget")
    return {"persisted_requests": len(requests), "completed_output_receipts": len(outputs),
            "model_calls": len(outputs) if complete and len(outputs) == len(requests) else None,
            "calls_without_completed_output_receipt": len(requests) - len(outputs),
            "input_tokens_measured_subtotal": sum(row["input_tokens"] for row in outputs),
            "output_tokens_measured_subtotal": output_tokens,
            "student_verification_receipts": verified, "authored_reference_receipts": reference_count,
            "reference_calls": reference_count if complete else None,
            "completed_training_step_receipts": len(finished_steps),
            "failed_attempt_measurement_complete": complete,
            "controlled_reuse_adds_model_calls": 0, "controlled_reuse_adds_verifier_calls": 0,
            "cold_outputs_are_repeated_observations": True,
            "scope": "new retained worker files only; prior readiness cost excluded and linked separately"}


def run(context, freeze, before):
    output = Path(freeze["output"])
    if freeze["status"] == "NOT_READY":
        result = io.sealed({"schema": "hepta.qwen-development-result.v3", "status": "NOT_READY",
                            "reason": "no actual bound A business success by this parent",
                            "fits_started": 0, "model_loads": 0, "new_model_calls": 0,
                            "new_reference_calls": 0, "freeze_digest": io.digest(freeze), **io.SCOPE})
        io.write_new(output / "RESULT.json", result)
        return result
    deadline = time.monotonic() + max(0, io.BUDGET["operation_wall_seconds"] - (time.perf_counter() - before["wall"]))
    children, comparisons = [], {}
    try:
        collection = child(freeze, freeze["schedule"][0], {}, deadline)
        children.append(collection)
        io.require(collection["result"] is not None
                   and collection["result"]["status"] == "PLANS_FROZEN",
                   "correction/plan preparation failed; zero fits started")
        for arm in io.ARMS:
            primary_entry = next(row for row in freeze["schedule"] if row["arm"] == arm and row["phase"] == "primary")
            if arm in io.FIT_MODES:
                extra = {**collection["result"]["plans"][arm],
                         "collection_result_sha256": collection["result_sha256"]}
            else:
                path = Path(freeze["readiness_directory"]) / "parent.json"
                extra = {"manifest_path": str(path), "manifest_sha256": io.file_hash(path)}
            primary = child(freeze, primary_entry, extra, deadline)
            children.append(primary)
            if primary["result"] is None:
                comparisons[arm] = {"status": "BLOCKED", "reason": "primary failed; retained without retry"}
                continue
            identity = primary["result"]["manifest"]
            cold_entry = next(row for row in freeze["schedule"] if row["arm"] == arm and row["phase"] == "cold")
            cold = child(freeze, cold_entry, {
                "manifest_path": identity["path"], "manifest_sha256": identity["sha256"],
                "primary_manifest": identity, "primary_pid": primary["result"]["pid"],
                "primary_result_sha256": primary["result_sha256"]}, deadline)
            children.append(cold)
            comparisons[arm] = cold_comparison(primary["result"], cold["result"]) if cold["result"] else {
                "status": "BLOCKED", "reason": "cold regression failed; retained without retry"}
        io.guard(freeze)
        ledger = raw_ledger(output, children)
        fits_started = sum((output / "workers" / (arm + "-primary") / "candidate/STARTED.json").exists()
                           for arm in io.FIT_MODES)
        complete = len(children) == len(freeze["schedule"]) and all(row["result"] is not None for row in children)
        result = io.sealed({"schema": "hepta.qwen-development-result.v3",
                            "status": "DEVELOPMENT_COMPLETE" if complete else "DEVELOPMENT_PARTIAL",
                            "freeze_digest": io.digest(freeze), "fits_started": fits_started,
                            "children": children, "cold_comparisons": comparisons, "ledger": ledger,
                            "cost": {**io.cost(before), "scope": "whole coordinator and completed children; nested worker figures are not additive"},
                            "prior_readiness_digest": io.digest(context["readiness"]),
                            "prior_readiness_cost_included": False,
                            "candidate_selected": None, "E1_E2_scope": "descriptive old-B and A-retention comparisons only",
                            "no_positive_capability_conclusion_from_completion": True, **io.SCOPE})
        io.write_new(output / "RESULT.json", result)
        return result
    except BaseException as error:
        io.write_new(output / "FAILED.json", {"status": "FAILED_PRESERVED", "error": repr(error),
                     "traceback": traceback.format_exc(), "children": children,
                     "cost": io.cost(before), "automatic_retry": False, "partial_files_preserved": True,
                     "fits_started": sum((output / "workers" / (arm + "-primary") / "candidate/STARTED.json").exists()
                                         for arm in io.FIT_MODES), **io.SCOPE})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("artifact-root", "source", "readiness-directory", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--mode", choices=("preflight", "run"), default="preflight")
    args = parser.parse_args()
    def interrupted(signum, _frame):
        raise KeyboardInterrupt("coordinator interrupted: " + str(signum))
    signal.signal(signal.SIGTERM, interrupted)
    context, freeze, before = prepare(args.artifact_root, args.source, args.readiness_directory, args.output, args.mode)
    result = run(context, freeze, before) if args.mode == "run" else {
        "status": freeze["status"], "mode": "preflight", "fits_started": 0}
    print(io.canonical({"status": result["status"], "output": str(args.output)}).decode(), flush=True)


if __name__ == "__main__":
    main()
