"""Immutable local I/O and bounded Linux child processes for E1/E2 development."""

import hashlib
from importlib import metadata
import json
import os
from pathlib import Path, PurePosixPath
import re
import resource
import signal
import subprocess
import sys
import time


HELPERS = (
    "qwen_development_io_v3.py", "qwen_development_inputs_v3.py",
    "qwen_development_execution_v3.py", "run_qwen_development_v3.py",
)
SOURCE_SHA = "38a6f8bbc8a602befcd45ebd919bbcb2eca12d9f105798b29d72b2eb051c42d7"
SOURCE_MANIFEST_SHA = "f4baf14dfb07513ade469adf6877ce6cd15ac98fbcc0e390854fcf24c85ae2be"
RUNTIME_ROOT = Path("/home/qian-qi/hepta-cell-experiments-v3-20261116-0c078a")
WORKSPACE_ROOT = Path("/dev/shm/hepta-cell-experiments-v3-20261116-0c078a")
ARMS = ("parent", "retrieval", "final_answer", "trajectory",
        "shadow_correction", "controlled_correction")
FIT_MODES = {"final_answer": "final_answer", "trajectory": "trajectory",
             "shadow_correction": "trajectory", "controlled_correction": "trajectory"}
BUDGET = {
    "fit_steps_per_arm": 64, "fit_arms": 4, "maximum_training_steps": 256,
    "sequence_tokens": 1536, "maximum_padded_training_positions": 393216,
    "maximum_attempts": 2, "max_new_tokens": 384, "max_input_tokens": 4096,
    "shadow_calls": 6, "maximum_model_calls": 222,
    "maximum_generated_tokens": 85248, "maximum_reference_rechecks": 36,
    "maximum_evaluation_verifier_calls": 216,
    "shadow_wall_seconds": 600, "fit_and_evaluation_wall_seconds": 1800,
    "evaluation_wall_seconds": 600, "operation_wall_seconds": 14400,
    "automatic_retry": False, "truncation": False,
}
SCOPE = {
    "exposure": "old_exposed_development_only", "new_C": False,
    "independent_sample_increment": 0, "external_teacher_count_added": 0,
    "new_users": 0, "scientific_confirmation_qualified": False,
    "independent_selection": False, "native_cell_adoption": False,
    "E3": "BLOCKED: no authenticated additional teachers",
    "E4": "BLOCKED: no trained circuit and matched ablation experiment",
    "E5": "BLOCKED: no independent source-growth cohorts",
    "E6": "BLOCKED: cold regression repeats exposed tasks; no new C or adoption",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def safe_path(root, relative):
    path = PurePosixPath(relative)
    require(not path.is_absolute() and path.parts and ".." not in path.parts
            and str(path) == relative and "\\" not in relative,
            "bounded relative artifact path required")
    current = Path(root)
    require(not current.is_symlink(), "artifact root symlink rejected")
    for part in path.parts:
        current /= part
        require(not current.is_symlink(), "artifact symlink rejected")
    return current


def file_hash(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), "regular artifact required")
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b""):
            result.update(block)
    return result.hexdigest()


def read(path, expected=None):
    path = Path(path)
    require(path.stat().st_size <= 64 * 1024**2, "JSON artifact exceeds bound")
    if expected is not None:
        require(file_hash(path) == expected, "artifact bytes changed: " + str(path))
    else:
        require(path.is_file() and not path.is_symlink(), "regular JSON required")
    return json.loads(path.read_text())


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(canonical(value) + b"\n")
        stream.flush()
        os.fsync(stream.fileno())


def sealed(value):
    return {**value, "receipt_sha256": digest(value)}


def verify_receipt(value):
    require(digest({k: v for k, v in value.items() if k != "receipt_sha256"})
            == value.get("receipt_sha256"), "receipt digest differs")


def verify_inventory(root, inventory, *, exact=False):
    require(isinstance(inventory, dict) and 0 < len(inventory) <= 2048,
            "bounded file inventory required")
    if exact:
        observed = {p.relative_to(root).as_posix()
                    for p in Path(root).rglob("*") if not p.is_dir()}
        require(observed == set(inventory), "artifact file inventory changed")
    for relative, expected in inventory.items():
        require(file_hash(safe_path(root, relative)) == expected,
                "artifact content changed: " + relative)


def helper_inventory():
    root = Path(__file__).parent
    return {name: file_hash(root / name) for name in HELPERS}


def bootstrap(source):
    directory = Path(source).resolve() / "scripts"
    for name, module in tuple(sys.modules.items()):
        if name.split(".")[0] in ("cell_experiments", "hepta_cells"):
            require(Path(module.__file__).resolve().is_relative_to(directory),
                    "preloaded project module escaped frozen source")
    sys.path.insert(0, str(directory))


def workspace_guard(root, *paths):
    root = Path(root)
    require(root == WORKSPACE_ROOT and root.is_dir() and root == root.resolve(),
            "fixed nonsymlink DATA workspace required")
    for value in paths:
        path = Path(value)
        require(path.is_absolute() and path == path.resolve() and path != root
                and path.is_relative_to(root),
                "operation paths must be strict nonsymlink descendants of DATA workspace")


def runtime_guard(root, runtime):
    root = Path(root)
    require(root == RUNTIME_ROOT and root.is_dir() and root == root.resolve(),
            "fixed original nonsymlink runtime root required")
    require(sys.platform == "linux" and sys.flags.isolated and sys.dont_write_bytecode,
            "Linux isolated (-I -B) interpreter required")
    require(str(Path(sys.executable)) == runtime["python"]
            == str(Path(root) / "venv/bin/python")
            and Path(sys.prefix) == Path(root) / "venv",
            "use the already recovered, pinned interpreter")
    verify_inventory(root, runtime["recovery_bindings"])
    saved = read(Path(root) / "operations/recovery-03/PIP_FREEZE.json")
    installed = {re.sub(r"[-_.]+", "-", row.metadata["Name"]).lower(): row.version
                 for row in metadata.distributions()}
    require(installed == saved["distributions"], "installed dependencies changed")
    require({name: metadata.version(name) for name in runtime["versions"]}
            == runtime["versions"], "pinned runtime versions changed")


def guard(freeze):
    require(freeze["workspace_root"] == freeze["artifact_root"] == str(WORKSPACE_ROOT)
            and freeze["runtime_root"] == str(RUNTIME_ROOT),
            "runtime or DATA workspace root changed")
    workspace_guard(freeze["workspace_root"], freeze["source"],
                    freeze["readiness_directory"], freeze["output"], freeze["inputs_path"])
    require(freeze["budget"] == BUDGET, "operation budget changed")
    require(helper_inventory() == freeze["helper_inventory"], "operation source changed")
    verify_inventory(freeze["source"], freeze["source_inventory"], exact=True)
    verify_inventory(freeze["readiness_directory"], freeze["readiness_inventory"])
    runtime_guard(freeze["runtime_root"], freeze["runtime"])


def usage():
    own = resource.getrusage(resource.RUSAGE_SELF)
    children = resource.getrusage(resource.RUSAGE_CHILDREN)
    return {"wall": time.perf_counter(), "own_cpu": own.ru_utime + own.ru_stime,
            "child_cpu": children.ru_utime + children.ru_stime,
            "peak_rss_bytes": own.ru_maxrss * 1024}


def cost(before):
    now = usage()
    return {"wall_seconds": now["wall"] - before["wall"],
            "own_cpu_seconds": now["own_cpu"] - before["own_cpu"],
            "completed_child_cpu_seconds": now["child_cpu"] - before["child_cpu"],
            "process_lifetime_peak_rss_bytes": now["peak_rss_bytes"],
            "energy_joules": None, "monetary_cost": None, "gpu_active_seconds": None,
            "complete": False, "nested_scopes_are_not_additive": True}


def _stop_owned(process):
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=5)


def launch(argv, directory, seconds):
    """Start exactly one owned child; bounded timeout preserves its raw files."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    require(type(seconds) in (int, float) and 0 < seconds <= 1800,
            "bounded positive worker wall budget required")
    before = usage()
    environment = {**os.environ, "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                   "HF_HUB_DISABLE_TELEMETRY": "1", "TOKENIZERS_PARALLELISM": "false",
                   "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2"}
    write_new(directory / "LAUNCH.json", {"argv": argv, "timeout_seconds": seconds,
              "started_at_ns": time.time_ns(), "automatic_retry": False})
    with (directory / "stdout.log").open("xb") as stdout, (directory / "stderr.log").open("xb") as stderr:
        process = subprocess.Popen(argv, stdout=stdout, stderr=stderr, env=environment,
                                   start_new_session=True)
        timed_out = False
        deadline = time.monotonic() + seconds
        try:
            while process.poll() is None:
                try:
                    process.wait(timeout=max(0.01, min(30, deadline - time.monotonic())))
                except subprocess.TimeoutExpired:
                    if time.monotonic() < deadline:
                        continue
                    timed_out = True
                    _stop_owned(process)
        except BaseException as error:
            _stop_owned(process)
            write_new(directory / "INTERRUPTED.json", {
                "error": repr(error), "pid": process.pid, "exit_code": process.returncode,
                "cost": cost(before), "automatic_retry": False})
            raise
    result = sealed({"exit_code": process.returncode, "timed_out": timed_out,
                     "pid": process.pid, "cost": cost(before), "automatic_retry": False,
                     "stdout_sha256": file_hash(directory / "stdout.log"),
                     "stderr_sha256": file_hash(directory / "stderr.log"),
                     "completed_at_ns": time.time_ns()})
    write_new(directory / "EXIT.json", result)
    return result
