"""Synthetic retained-receipt attacks; execute_logged is mocked, zero real models."""

import copy
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

repo = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(repo / "scripts"))
from ndu_real_runtime.test_episodic_local_provider import LocalProviderTests
from ndu_real_runtime import episodic_local_provider as provider

case = LocalProviderTests()
case.setUp()
try:
    model_input = provider._canonical({
        "schema": "hepta.mem12.model-input.v1",
        "request_sha256": provider._pin(case.request)["sha256"],
        "rendered_prompt": "public rendered C",
        "tensors": {
            "input_ids": {"dtype": "torch.int64", "shape": [1, 2], "values": [[7, 9]]},
            "attention_mask": {"dtype": "torch.int64", "shape": [1, 2], "values": [[1, 1]]},
        },
    })
    bootstrap = {"empty": True, "namespaces": {
        name: "fixture-" + name for name in ("mnt", "pid", "net", "ipc", "uts", "user")
    }}
    result = {"request_sha256": provider._pin(case.request)["sha256"],
              "model_input": provider._pin(model_input), "prompt_tokens": 2}

    def log_bytes(boot):
        return (b"MEM11_BOOTSTRAP " + provider._canonical(boot)
                + b"\nMEM12_MODEL_INPUT " + model_input
                + b"\nMEM11_RESULT " + provider._canonical(result) + b"\n")

    def capture(command, log, **kwargs):
        log.write_bytes(log_bytes(bootstrap))
        return {"returncode": 0, "timed_out": False, "output_limit_exceeded": False}

    with patch.object(provider, "execute_logged", side_effect=capture):
        first = case.run_provider()
    output = case.root / "journal" / hashlib.sha256(b"fixture-id").hexdigest()
    rows = []
    for change in ("nonempty_bootstrap", "same_namespaces", "changed_runtime", "changed_source"):
        receipt, boot = copy.deepcopy(first), copy.deepcopy(bootstrap)
        if change == "nonempty_bootstrap":
            boot["empty"] = False
            receipt["bootstrap"] = boot
        elif change == "same_namespaces":
            boot["namespaces"] = receipt["host_namespaces"]
            receipt["bootstrap"] = boot
        elif change == "changed_runtime":
            receipt["runtime_after"]["sha256"] = "0" * 64
        else:
            receipt["source_unchanged"] = False
        raw = log_bytes(boot)
        (output / "combined.log").write_bytes(raw)
        receipt["combined_log"] = provider._pin(raw)
        (output / "RECEIPT.json").write_bytes(provider._canonical(receipt))
        with patch.object(provider, "execute_logged") as execute:
            try:
                returned = case.run_provider()
                row = {"case": change, "observed_status": returned["status"],
                       "local_generation_returned": returned["local_generation_returned"],
                       "reexecuted": execute.called}
            except Exception as error:
                row = {"case": change, "rejected": type(error).__name__ + ": " + str(error),
                       "reexecuted": execute.called}
        rows.append(row)
    print(json.dumps(rows, indent=2))
finally:
    case.doCleanups()
