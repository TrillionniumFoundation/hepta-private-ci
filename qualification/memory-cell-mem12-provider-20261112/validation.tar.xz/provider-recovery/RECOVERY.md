# MEM11 original provider readback

The previously unavailable v3 result was recovered through the configured
`ai395` host's bounded read-only file API. The original operation was not
restarted, cancelled, or relabelled under another generation key.

## Original identity and observed result

- Operation key: `mem11-first-local-generation-20261112-21bb-v3`.
- Generation request: `mem11-offline-first-generation-v3-001`.
- Original directory: `/home/qq/work/mem11-local-provider-20261112-21bb-v3`.
- Original request is the 169-byte fixed greeting request, not a memory task.
- Recorded provider outcome: `RETURNED`, process exit 0, no timeout or output
  overflow; one generation result with text `Hello!` and token IDs
  `[19556, 17, 2]`.
- The model is the frozen CPU `SmolLM2-135M-Instruct` revision
  `12fd25f77366fa6b3b4b768ec3050bf629380bac`; the eight individual asset pins,
  Python pin, runtime inventory, request and worker pins are retained in the
  original `PREEXECUTION.json` and journal.
- Original outer runtime job identity/terminal acknowledgement remain
  unrecovered. The original stored generation result is available independently.

`INDEPENDENT_RECHECK.json` independently recomputes 26 consistency checks over
the ten original retained files, including the original isolated actor output,
request bytes, launch receipt, preparation record, generation admission,
provider receipt, complete stdout markers, six distinct namespace identities,
empty private state, and unchanged pinned dependency inventory. Every file's
version, size and SHA-256 from the read API are retained alongside original tool
results. This is a readback, not a second execution.

## Source boundary

The recovered v3 provider source is SHA-256
`592d05bb0e1294afe679f8ec281ba2467a7270a9b2a15c056ae14ee35c8b83bf`, while
PR #6136's provider source is
`ca65a34310b3cb108508b1d0bf90546d4f0e7b62b806e0102a6b47f22ce3a32f`.
Its handoff dependency also differs. The historical generation therefore does
not qualify the composed #6136 source or any subsequent source.

`FIRST_GENERATION_V3_COMMAND.py` and the historical checkpoint are copied from
the retained #6134 archive. Five embedded source postimages are decoded as data
into `original-source/`, and their bytes and hashes independently equal the
recovered preexecution source roster. They are not executed by this recovery.

## Execution resources available for new work

The configured host exposes existing operator execution and file access.
The successful read-only inventory job was `1a1ce68242b-2564-164a`; its complete
status and stdout are retained. It found `/home/qq/.cargo/bin/` Rust tools,
`/usr/bin/git`, `/usr/bin/bwrap` and `/usr/bin/python3.14`. Rust and `just` were
not in the default PATH. The model and public dependency runtime remain at the
paths recorded in the original profile. A new campaign must independently freeze
and check its own exact source and inputs before using them.

The bounded, read-only attempt to locate the historical outer job used key
`mem11-readonly-original-job-identity-20261112-ef0c-v1`. Its acknowledgement
timed out and it was not repeated. This lookup contains no model invocation;
the outcome stays UNKNOWN. No full historical job sweep was performed.

## Scientific disposition

The original receipt explicitly retains `observer_authenticated=false`,
`original_owner_authority=false`, `causal_scoring=false` and `HOLD`. This
readback establishes recorded local diagnostic generation and byte consistency;
it supplies no causal memory benefit, production adoption, independent new-task
exposure, owner recovery or complete cost comparison. New real model executions
in this recovery: **0**. Scored memory-benefit episodes: **0**.

## Independent source review

`replay-counterexample.py` reconstructs four synthetic retained-receipt attacks
with `execute_logged` mocked. The retained original output in
`replay-counterexample.json` shows that the initial MEM12 implementation accepted
all four contradictions on readback: nonempty bootstrap, unchanged host
namespace identities, a changed runtime inventory, and source-change evidence.
No real model was called. The shared initial/retained-success validator at
source `83e88f62205bf60da5f631d41677355c9ead99e2` was then independently checked
with the same four attacks. All four were rejected with `ValueError`, and no
new provider execution was attempted. The complete output is retained in
`replay-counterexample-after.json`; `REPLAY_REVIEW_GREEN.json` records the exact
source and three file pins. These are four subcases within an existing control,
not four independent model tasks. They establish only this replay-contract fix;
exact final-source native execution and scientific efficacy remain separate.
