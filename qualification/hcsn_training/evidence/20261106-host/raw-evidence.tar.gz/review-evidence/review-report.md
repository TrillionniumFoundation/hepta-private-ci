# Independent read-only HCSN review

Source reviewed: 21f99f78e6a176233e711ce5ad233cec0166b8d6 (#4950).

## P1: saved initial numerical state is silently discarded by the training worker

Source: qualification/hcsn_training/joint_graph.py::load_model returns only index 0 of load_training_checkpoint; worker.py lines 66 and 167 use load_model, task_gradients line 28 calls model without state, final forward line 111 likewise uses its default initial state. load_training_checkpoint permits saved final_state and last_end_micros, but worker never ties that state/time to request.intervals[0].start_micros or the independently acknowledged Rust outer clock anchor. README promises one real outer checkpoint; neither the request schema nor the worker makes explicit reset a required policy. Thus a valid state-bearing checkpoint is accepted but silently reset.

Reproduced on a scratch copy of exact #4950 .py sources: two logical cells, two examples, four intervals, one SGD step per arm. A checkpoint with every state tensor set to 2 and last_end_micros=999999999 was accepted for intervals starting at 17. Correct resumed vs reset forward output differs by 0.39040655942360714, while the worker produced bit-identical gradient digest, candidate weights and final prediction for model-only base versus state-bearing base. See state-reset-repro.json. This is an engineering unit-size CPU audit, not another scientific run.

Smallest coherent fix: add explicit fresh/reset versus resume initialization mode bound into the request digest; load complete training checkpoint; for resume validate full state digest/shape and exact ending timestamp against independently admitted outer anchor, then pass the same immutable initial state into every optimization forward and the final candidate forward. Fresh mode must reject state-bearing checkpoint unless reset is explicit and independently bound to an initial anchor. Candidate metadata.binding.model_digest is predecessor provenance, so do not require it to equal the newly hashed candidate bytes. Add rejection tests for mismatched timestamp/state and an actual resumed second training block fixture.

## Scope checks

No other concrete blocking defect found in continuous_time.rs or hcsn_candidate.rs after reading their complete admission/restore/planning/publication paths. The Rust clock code validates actual positive integer elapsed time, bounded gap/grid/horizon and exact identity/profile/anchor, with one final commit only. The candidate bridge checks external expected binding, task BP tag, complete counts, payload/diagnostic hashes and lineage, then delegates publication to the existing fenced owner. This is candidate provenance admission, not a native mathematical proof of the gradients or production adoption; docs already state that scope.

## Hosted CI on the previous exact head

Run 42186837493 completed successfully at 2026-11-06T08:40:26Z, head 21f99f78e6a176233e711ce5ad233cec0166b8d6. Job source-and-owner 127789087188 succeeded. 194 native tests passed; 1 deliberately ignored owner-host child helper skipped by the test runner (its source says it is invoked by owner_host_process_kill_reopen_matrix). Python: 8 tests passed. Direct bridge verifies 2 cells, 172/172 parameter gradients, exact full state/output cold recovery, unchanged base, wrong dispatch/changed receipt/fenced writer rejection. It explicitly records synthetic trust, DENY_ALL, candidate_only=true, production_trust=false. Artifact 13488444231 retained. This result must not be described as CI of a future changed head.

## Existing CUDA campaign observation

Process status for existing controller 1a1acdd69f2-fc05-5757: running. Retained stdout/stderr both empty. Exact known progress file was subsequently read successfully in full through read_multiple_files. Source updated 2026-11-06T08:56:02.242807+00:00; observed at 2026-11-06T08:56:51.008Z; SHA256 80a286caa01b94e9b9f612352431db3f7ae56d47381812f13372a4fc391d2a3a. active_stage=full; completed_cuda_runs=0/170; registered indexes completed=failed=unavailable=0; qualification=open. Full stage running child_pid 3244204 since 08:08:57Z. original-b-fullshape remains exit1; other nine returned stages exit0. This is the progress file's observation, not proof no unregistered work has executed. No new process, installer, training, retry, cancellation, configuration or PR write was performed.

Earlier rejected guessed progress-path read and directory read capacity refusal are retained in campaign-read-results.json; the successful read used the exact path recovered from prior observation's manifest. No failed result was replaced.
