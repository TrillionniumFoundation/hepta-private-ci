"""Read-only artifact audit: hashes, recorded identities, receipts and SQLite.

Does not import repository modules, run workers, verify new signatures, or build
anything. The complete downloaded archive and extracted files remain intact.
"""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import sqlite3
import subprocess
import tomllib
import zipfile

BASE = Path('/workspace/scratch/7b4b0c316c52')
REPO = BASE / 'hcsn-prod'
REVIEW = BASE / 'hcsn-evidence-stage/ci-agentd-42253531173'
STAGE = REVIEW
RAW = REVIEW / 'original-extracted'
CI = RAW / '_temp/hcsn-agentd'
SOURCE = 'a20ea6a862e501d8a4993195c7da1ac52ca9a7be'
TREE = 'b8e8b66b957aaf1e5e1cd9db8bb479137cf9fceb'
ARTIFACT = json.loads((REVIEW / 'artifact-identity.json').read_text())
assert ARTIFACT['run_id'] == 42253531173
assert ARTIFACT['job_id'] == 128014547600
assert ARTIFACT['head_sha'] == SOURCE


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def read(path):
    return json.loads(path.read_bytes())


def write(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def source_bytes(path):
    return subprocess.check_output(['git', 'show', SOURCE + ':' + path], cwd=REPO)


def safe_relative(name):
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts
    assert str(path) == name and '\\' not in name
    return path


def typed_observation(value):
    def identity(item):
        return {key: item[key] for key in ('key', 'payload_sha256', 'job_id', 'output_id')}
    result = {key: value[key] for key in ('schema_version', 'dispatch', 'target', 'state', 'process', 'evidence')}
    result['dispatch'] = identity(value['dispatch'])
    result['target'] = identity(value['target'])
    result['process'] = {key: value['process'][key] for key in ('host_id', 'process_id', 'incarnation')}
    result['evidence'] = {key: value['evidence'][key] for key in ('receipt_sha256', 'candidate_sha256', 'handoff_sha256')}
    return json.dumps(result, separators=(',', ':'), ensure_ascii=False).encode()


def projected_receipt(event, original_observation):
    return {
        'owner_agent_id': event['owner_agent_id'], 'run_id': event['run_id'],
        'step_id': event['step_id'], 'attempt': event['attempt'],
        'state': event['event_kind'], 'intent_digest': event['intent_digest'],
        'payload_digest': event['payload_digest'], 'event_seq': event['event_seq'],
        'last_command_id': event['command_id'], 'receipt_digest': event['receipt_digest'],
        'observation': original_observation, 'final_outcome': event['final_outcome'],
        'fence': {key: event[key] for key in ('owner_agent_id', 'owner_id', 'owner_epoch', 'generation', 'fencing_token')},
    }


STAGE.mkdir(exist_ok=True)
complete_zip = REVIEW / 'agentd-complete.zip'
assert complete_zip.stat().st_size == ARTIFACT['size_in_bytes']
assert sha(complete_zip) == ARTIFACT['sha256']
assert (CI / 'source.txt').read_text().splitlines() == [SOURCE, TREE]
assert (CI / 'source-unchanged.log').read_bytes() == b''

pins = read(CI / 'source-pins.json')
declared = {entry['path']: entry['source_sha256'] for entry in tomllib.loads(source_bytes('CALLERS.toml').decode())['protected_file'] if 'source_sha256' in entry}
assert len(pins) == len(declared) == 11
assert {row['path']: row['sha256'] for row in pins} == declared
for row in pins:
    assert digest(source_bytes(row['path'])) == row['sha256']

tracked = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', SOURCE, '--', 'qualification/hcsn', 'qualification/hcsn_training', 'qualification/__init__.py'], cwd=REPO).decode().splitlines()
python_paths = sorted(path for path in tracked if path.endswith('.py'))
python_sources = {path: digest(source_bytes(path)) for path in python_paths}
assert len(python_sources) == 54

tests_text = (CI / 'tests.log').read_text()
passed_tests = re.findall(r'^\s*PASS\s+\[.*?\]\s+codex-hepta-agentd\s+(\S+)', tests_text, re.M)
assert len(passed_tests) == len(set(passed_tests)) == 23
assert '23 tests run: 23 passed, 169 skipped' in tests_text
assert 'Finished `dev` profile' in (CI / 'ordinary-build-check.log').read_text()
assert 'Finished `dev` profile' in (CI / 'clippy.log').read_text()
executable = read(CI / 'agentd-executable.json')
nextest = read(CI / 'nextest-list.json')
suites = [suite for suite in nextest['rust-suites'].values() if suite['package-name'] == 'codex-hepta-agentd' and suite['kind'] == 'lib']
assert len(suites) == 1 and suites[0]['binary-path'] == executable['path']
test_name = 'automation_effect_host::hcsn_pq::tests::real_worker::pq_host_real_worker_cancel_cold_recovery'
assert suites[0]['testcases'][test_name]['ignored'] is True

backend_rows = []
for backend in ('value_kernel', 'population_grid', 'population_age'):
    root = CI / ('pq-host-' + backend)
    result, host = read(root / 'result.json'), read(root / 'pq-host.json')
    assert read(CI / ('pq-host-' + backend + '-status.json')) == {'backend': backend, 'pipeline_exit_code': 0}
    assert result['status'] == host['status'] == 'passed' and result['backend'] == backend
    assert result['authority_profile'] == host['authority_profile'] == 'production_ml_dsa65_v2'
    for field in ('optimizer_entry_proven', 'agentd_daemon_booted', 'authbus_ingress_exercised', 'independent_custody_proven', 'production_trust', 'production_deployment', 'production_adoption', 'lost_replies_injected'):
        assert result[field] is host[field] is False
    assert result['local_fixture_trust'] is host['local_fixture_trust'] is True

    retained = read(root / 'retained-files.json')
    assert len(retained) == 53 and sha(root / 'retained-files.json') == result['retained_files_sha256']
    for name, expected in retained.items():
        path = root.joinpath(*safe_relative(name).parts)
        assert path.is_file() and not path.is_symlink() and sha(path) == expected, name
    actual = {path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file()}
    assert actual == set(retained) | {'retained-files.json', 'result.json'}

    before, after = read(root / 'sources-before.json'), read(root / 'sources-after.json')
    assert before == after and before['deployment_sources'] == python_sources
    config = read(root / 'pq-host-config.json')
    assert config['schema_version'] == 3 and config['authority_profile'] == 'production_ml_dsa65_v2'
    assert config['deployment']['source_manifest'] == python_sources == read(root / 'deployment-sources.json')
    supervisor_config = read(root / 'supervisor-config.json')
    assert all(config['deployment'][key] == value for key, value in supervisor_config.items())
    assert config['deployment']['supervisor_sha256'] == python_sources['qualification/hcsn_training/supervisor.py']
    assert sha(root / 'pq-host-config.json') == host['host_config_sha256']
    assert sha(root / 'supervisor-config.json') == host['supervisor_config_sha256']
    dispatches = read(root / 'pq-dispatches.json')
    dispatch = read(root / 'dispatch.json')
    for name, expected in dispatch['pinned_files'].items():
        assert sha(root / name) == expected
    assert dispatch['executable']['sha256'] == result['agentd_executable_sha256'] == executable['sha256']
    assert read(root / 'agentd-test-executable.json')['sha256'] == executable['sha256']
    assert dispatches['host_config_sha256'] == host['host_config_sha256']
    assert dispatches['supervisor_config_sha256'] == host['supervisor_config_sha256']
    process_record = read(root / 'pq-host-real-worker.process.json')
    assert process_record['returncode'] == 0 and process_record['error'] is None
    assert process_record['argv'] == [executable['path'], '--ignored', '--exact', test_name, '--nocapture']
    assert process_record['pid'] == host['parent_pid'] == dispatches['parent_pid']
    for channel in ('stdout', 'stderr'):
        assert sha(root / ('pq-host-real-worker.' + channel)) == process_record[channel + '_sha256']
    assert '1 passed; 0 failed; 0 ignored;' in (root / 'pq-host-real-worker.stdout').read_text()
    child = read(root / 'pq-host-child.json')
    assert child['success'] is True and '1 passed; 0 failed; 0 ignored;' in child['stdout']
    assert host['parent_pid'] != host['cold_native_pid']

    initial = read(root / 'pq-initial-receipts.json')
    receipts, observations = host['taskflow_step_receipts'], host['observations']
    assert initial == host['initial_step_receipts'] and len(initial) == len(receipts) == len(observations) == 2
    assert [x['observation'] for x in initial] == [x['observation'] for x in receipts] == ['indeterminate', 'indeterminate']
    assert [x['final_outcome'] for x in receipts] == ['failed', 'succeeded']
    target = observations[0]['target']
    wire = (root / 'request.json').read_bytes()
    assert digest(wire) == target['payload_sha256'] == host['request_file_sha256']
    identity_bytes = (target['key'] + '\0' + target['payload_sha256']).encode()
    assert target['job_id'] == digest(b'hepta.hcsn.job.v1\0' + identity_bytes)
    assert target['output_id'] == digest(b'hepta.hcsn.output.v1\0' + identity_bytes)
    assert read(root / 'cancel-request.json') == target
    assert sha(root / 'cancel-request.json') == host['cancel_request_sha256']
    job = root / result['retained_job']
    assert job.name == digest(target['key'].encode()) and job.parent == root / 'supervisor-store/jobs'
    terminal = read(job / 'terminal.json')
    terminal_sha = sha(job / 'terminal.json')
    assert terminal_sha == result['terminal_sha256']
    assert terminal['state'] == 'cancelled' and terminal['reason'] == 'cancelled_worker_stopped'
    assert terminal['termination_confirmed'] is True and terminal['identity'] == target
    worker = read(job / 'worker.json')
    assert worker == terminal['process'] == result['worker']
    running = read(root / 'pq-running.json')
    assert running == host['running'] and running['observation']['state'] == 'running'
    assert running['observation']['process'] == worker
    assert sha(job / 'worker.json') == running['worker_sha256']
    assert sha(job / 'runner.json') == running['runner_sha256']
    stat = running['proc_stat']
    fields = stat.rsplit(')', 1)[1].split()
    assert int(stat.split(' ', 1)[0]) == worker['process_id'] and fields[0] not in ('Z', 'X')
    assert digest(running['boot_id'].encode() + b'\0' + fields[19].encode()) == worker['incarnation']
    if host['proc_stat_after'] is not None:
        after_stat = host['proc_stat_after']
        after_fields = after_stat.rsplit(')', 1)[1].split()
        same_pid = int(after_stat.split(' ', 1)[0]) == worker['process_id']
        same_birth = digest(running['boot_id'].encode() + b'\0' + after_fields[19].encode()) == worker['incarnation']
        assert not (same_pid and same_birth and after_fields[0] not in ('Z', 'X'))
    assert worker['host_id'] == read(root / 'supervisor-store/store.json')['host_id']
    cancellation_files = list((root / 'supervisor-store/cancellations').iterdir())
    assert len(cancellation_files) == len(list((root / 'supervisor-store/jobs').iterdir())) == 1
    cancellation = read(cancellation_files[0])
    assert cancellation == read(job / 'cancel.json') and cancellation['target'] == target
    assert cancellation_files[0].name == digest(cancellation['dispatch']['key'].encode())
    assert observations[1]['dispatch'] == cancellation['dispatch']
    assert observations[0]['dispatch'] == target and observations[0]['dispatch'] != observations[1]['dispatch']
    assert read(job / 'reservation.json')['sources'] == before['execution']
    assert (job / 'request.json').read_bytes() == wire
    for name in ('candidate.pt', 'receipt.json', 'handoff.bin', 'failed.json'):
        assert not (job / target['output_id'] / name).exists()
    for observed, receipt in zip(observations, receipts):
        assert observed['state'] == 'cancelled' and observed['target'] == target and observed['process'] == worker
        assert observed['evidence'] == {'receipt_sha256': terminal_sha, 'candidate_sha256': None, 'handoff_sha256': None}
        assert digest(b'hepta.hcsn.observation.v1\0' + typed_observation(observed)) == receipt['receipt_digest']

    dbs = list(root.rglob('automation_1.sqlite3'))
    assert len(dbs) == 1 and not Path(str(dbs[0]) + '-wal').exists()
    assert len(list((root / 'supervisor-store/taskflow-requests').iterdir())) == 2
    connection = sqlite3.connect(dbs[0].as_uri() + '?mode=ro&immutable=1', uri=True)
    connection.row_factory = sqlite3.Row
    assert connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
    assert connection.execute('SELECT count(*) FROM taskflow_effect_dispatch_attempts').fetchone()[0] == 2
    for index, kind in enumerate(('start', 'cancel')):
        signed = dispatches[kind]
        run_id = signed['intent']['run_id']
        events = [dict(row) for row in connection.execute('SELECT * FROM taskflow_step_outbox WHERE run_id=? ORDER BY event_seq', (run_id,))]
        assert [event['event_kind'] for event in events] == ['prepared', 'claimed', 'recorded', 'reconciled']
        assert projected_receipt(events[2], events[2]['observation']) == initial[index]
        assert projected_receipt(events[3], events[2]['observation']) == receipts[index]
        row = dict(connection.execute('SELECT * FROM taskflow_effect_dispatch_reconciliations WHERE run_id=?', (run_id,)).fetchone())
        assert row['observation'] == receipts[index]['final_outcome'] and row['evidence_digest'] == receipts[index]['receipt_digest']
        run = dict(connection.execute('SELECT * FROM taskflow_runs WHERE run_id=?', (run_id,)).fetchone())
        assert run['state'] == receipts[index]['final_outcome'] and run['lease_expires_at_ms'] is None
        saved = read(root / 'supervisor-store/taskflow-requests' / (receipts[index]['intent_digest'] + '.json'))
        assert saved['intent'] == signed['intent']
        assert digest(saved['wire_payload'].encode()) == signed['intent']['payload_digest'] == receipts[index]['payload_digest']
    connection.close()
    authority = dbs[0].parent / 'final-use-authority'
    snapshot = read(authority / 'authority.json')
    claims = (authority / 'authority.claims').read_bytes()
    assert snapshot['schema'] == 4 and len(claims) == 80 and 'PqIssuerKeyRing' in snapshot['trust']
    nonces = {claims[offset + 8:offset + 40] for offset in (0, 40)}
    assert all(int.from_bytes(claims[offset:offset + 8], 'big') == 9 for offset in (0, 40))
    assert len(nonces) == 2 and nonces == {bytes(dispatches[kind]['signed']['grant']['nonce']) for kind in ('start', 'cancel')}
    head = snapshot['head']
    state = b'hepta.kernel.authority.final-use-frontier.pq.v2\0'
    for value in (head['authority_epoch'], head['revision'], len(head['revoked_grant_ids'])):
        state += value.to_bytes(8, 'little')
    for grant_id in sorted(head['revoked_grant_ids']):
        state += len(grant_id.encode()).to_bytes(8, 'little') + grant_id.encode()
    state += len(nonces).to_bytes(8, 'little') + b''.join(sorted(nonces))
    frontier = read(root / 'pq-services/frontier.json')
    assert bytes(frontier['state_sha256']).hex() == digest(state)
    assert frontier['authority_epoch'] == head['authority_epoch'] and frontier['revocation_revision'] == head['revision']
    assert not (root / 'pq-feed.json').exists()
    feed = read(root / 'pq-feed-before-terminal-readback.json')
    assert read(root / 'pq-services/clock.json') > feed['update']['expires_at_unix_ms']
    assert all(read(root / 'pq-services/clock.json') > dispatches[kind]['signed']['grant']['expires_at_unix_ms'] for kind in ('start', 'cancel'))
    contacts = read(root / 'pq-service-requests.json')
    assert contacts['clock'] > 0 and contacts['frontier'] > 0
    assert host['consumed_nonces'] == 2
    backend_rows.append({
        'backend': backend, 'status': 'passed', 'result_sha256': sha(root / 'result.json'),
        'retained_manifest_sha256': sha(root / 'retained-files.json'), 'retained_files_verified': len(retained),
        'source_files_verified_against_exact_git': len(python_sources),
        'worker': worker, 'parent_pid': host['parent_pid'], 'cold_native_pid': host['cold_native_pid'],
        'terminal_sha256': terminal_sha, 'terminal_reason': terminal['reason'],
        'raw_terminal_bound_to_cold_receipts': True, 'sqlite_receipts_match_exactly': True,
        'sqlite_sha256': sha(dbs[0]), 'initial_observations': [item['observation'] for item in initial],
        'final_outcomes': [item['final_outcome'] for item in receipts],
        'consumed_nonces_verified_from_raw_claim_frames': len(nonces), 'external_frontier_recomputed': True,
        'missing_expired_feed_terminal_readback_recorded': True,
        'test_executable_sha256': executable['sha256'], 'clock_requests': contacts['clock'],
        'frontier_requests': contacts['frontier'], 'cancellation_workload': result['cancellation_workload'],
        'scope': 'retained native CI evidence audited offline; no new worker or signature execution',
    })

inventory = []
excluded = []
for path in sorted(p for p in RAW.rglob('*') if p.is_file()):
    assert not path.is_symlink()
    raw = path.read_bytes()
    compiled = raw.startswith(b'\x7fELF') or raw[:4] in (b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe')
    if raw[:2] == b'MZ' and len(raw) >= 64:
        offset = int.from_bytes(raw[60:64], 'little')
        compiled = compiled or raw[offset:offset+4] == b'PE\0\0'
    compiled = compiled or (raw.startswith(b'!<arch>\n') and path.suffix in ('.a', '.rlib', '.lib'))
    record = {'path': path.relative_to(RAW).as_posix(), 'size': len(raw), 'sha256': digest(raw)}
    if compiled:
        excluded.append({**record, 'reason': 'confirmed compiled binary format', 'source_artifact': ARTIFACT})
    else:
        inventory.append(record)
assert len(inventory) + len(excluded) == 185
with zipfile.ZipFile(complete_zip) as archive:
    assert {entry.filename for entry in archive.infolist() if not entry.is_dir()} == {row['path'] for row in inventory + excluded}
    for row in inventory + excluded:
        original = archive.read(row['path'])
        assert len(original) == row['size'] and digest(original) == row['sha256']
filtered = STAGE / 'pq-host-raw-filtered.zip'
with zipfile.ZipFile(filtered, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for record in inventory:
        info = zipfile.ZipInfo(record['path'], date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100600 << 16
        archive.writestr(info, (RAW / record['path']).read_bytes())
with zipfile.ZipFile(filtered) as archive:
    assert set(archive.namelist()) == {record['path'] for record in inventory}
    for record in inventory:
        raw = archive.read(record['path'])
        assert len(raw) == record['size'] and digest(raw) == record['sha256']
        assert sha(RAW / record['path']) == record['sha256']

raw_inventory = {'schema_version': 1, 'source_artifact': ARTIFACT, 'source_sha': SOURCE,
    'complete_archive_local_path': str(complete_zip), 'complete_extraction_local_path': str(RAW),
    'filtered_archive': {'path': filtered.name, 'size': filtered.stat().st_size, 'sha256': sha(filtered)},
    'included': inventory, 'excluded_compiled_binaries': excluded,
    'all_included_files_reopened_and_sha256_verified': True, 'raw_files_deleted': False}
write(STAGE / 'pq-host-raw-inventory.json', raw_inventory)
audit = {'schema_version': 1, 'status': 'passed', 'source_sha': SOURCE, 'source_tree': TREE,
    'source_artifact': ARTIFACT, 'source_pins_verified': pins, 'python_source_file_count': len(python_sources),
    'ordinary_library_build': 'passed; ordinary-build-check.log has finished dev profile',
    'scoped_clippy': 'passed; clippy.log has finished dev profile; warnings retained',
    'tracked_source_unchanged_log_empty': True,
    'host_tests': {'passed': 23, 'failed': 0, 'skipped_by_filter_or_ignore': 169, 'test_names': passed_tests},
    'backends': backend_rows, 'filtered_raw_inventory': 'pq-host-raw-inventory.json',
    'filtered_raw_archive': raw_inventory['filtered_archive'], 'excluded_compiled_binary_count': len(excluded),
    'scope': {'new_tests_executed_in_this_audit': False, 'signatures_reverified_offline': False,
        'live_proc_observation_repeated': False, 'native_ci_process_evidence_and_retained_bytes_cross_checked': True,
        'optimizer_entry_proven': False, 'agentd_daemon_booted': False, 'authbus_ingress_exercised': False,
        'independent_production_custody_proven': False, 'production_deployment': False,
        'runtime_and_source_atomic_custody_proven': False}}
write(STAGE / 'pq-host-audit.json', audit)
print(json.dumps({'audit': str(STAGE / 'pq-host-audit.json'), 'audit_sha256': sha(STAGE / 'pq-host-audit.json'),
    'backends': [row['backend'] for row in backend_rows], 'verified_retained_files': sum(row['retained_files_verified'] for row in backend_rows),
    'raw_files': len(inventory), 'excluded': len(excluded), 'filtered_archive': raw_inventory['filtered_archive']}, indent=2))
