"""Retain and hash existing CI artifact bytes; never execute archive members."""

import argparse
import copy
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import struct
import zipfile


HEAD = "a20ea6a862e501d8a4993195c7da1ac52ca9a7be"
TREE = "b8e8b66b957aaf1e5e1cd9db8bb479137cf9fceb"
RUN = 42253531173
JOB = 128014547080
PREFIX = "_temp/hcsn-training-bridge/"
EXPECTED_NATIVE = {PREFIX + name + "/native-fixture" for name in (
    "bridge-a", "bridge-b", "bridge-b-age"
)}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, data):
    with path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("artifact_metadata", type=Path)
    args = parser.parse_args()
    stage = args.archive.resolve().parent
    metadata = json.loads(args.artifact_metadata.read_text())
    archive_bytes = args.archive.read_bytes()
    archive_digest = sha(archive_bytes)
    assert metadata["digest"] == "sha256:" + archive_digest
    assert metadata["workflow_run"]["id"] == RUN
    assert metadata["workflow_run"]["head_sha"] == HEAD
    assert metadata["name"] == f"hcsn-training-bridge-{HEAD}-1"
    assert metadata["expired"] is False
    assert metadata["size_in_bytes"] == len(archive_bytes)
    extraction = stage / "original-extracted"
    extraction.mkdir()
    inventory = []
    excluded = []
    retained_extensions = {}
    archive_paths = []
    filtered_path = stage / "source-raw-filtered.zip"
    with zipfile.ZipFile(args.archive) as source:
        infos = source.infolist()
        assert len(infos) <= 10000
        assert sum(info.file_size for info in infos) <= 512 * 1024 * 1024
        names = [info.filename for info in infos]
        assert len(names) == len(set(names)), "duplicate ZIP member"
        contents = {}
        for info in infos:
            name = info.filename
            relative = PurePosixPath(name)
            assert name and not relative.is_absolute()
            assert ".." not in relative.parts and "\\" not in name and "\0" not in name
            assert name == relative.as_posix() + ("/" if info.is_dir() else "")
            assert not info.flag_bits & 1, "encrypted member"
            mode = info.external_attr >> 16
            assert stat.S_IFMT(mode) in (0, stat.S_IFREG, stat.S_IFDIR)
            path = extraction.joinpath(*relative.parts)
            if info.is_dir():
                path.mkdir(parents=True, exist_ok=True)
                continue
            data = source.read(info)  # zipfile validates the member CRC.
            contents[name] = data
            digest = sha(data)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("xb") as handle:
                handle.write(data)
            assert sha(path.read_bytes()) == digest
            record = {
                "path": name, "bytes": len(data), "sha256": digest,
                "compressed_bytes": info.compress_size,
                "zip_crc32": f"{info.CRC:08x}", "zip_unix_mode": oct(mode),
            }
            inventory.append(record)
            archive_paths.append(name)
        assert contents[PREFIX + "source.txt"].decode().splitlines() == [HEAD, TREE]
        for name, data in contents.items():
            if not data.startswith(b"\x7fELF"):
                continue
            assert name in EXPECTED_NATIVE, "unclassified ELF member; refuse to filter"
            assert len(data) >= 64 and data[4] in (1, 2) and data[5] in (1, 2)
            endian = "<" if data[5] == 1 else ">"
            kind, machine = struct.unpack(endian + "HH", data[16:20])
            assert kind in (2, 3), "ELF is not executable or PIE"
            receipt_path = str(PurePosixPath(name).parent / "native-build.json")
            receipt = json.loads(contents[receipt_path])
            assert receipt["executable_sha256"] == sha(data)
            record = next(row for row in inventory if row["path"] == name)
            excluded.append({
                **record, "elf_class_bits": {1: 32, 2: 64}[data[4]],
                "elf_type": kind, "elf_machine": machine,
                "matching_build_receipt": receipt_path,
                "matching_build_receipt_sha256": sha(contents[receipt_path]),
                "confirmation": "ELF executable bytes and matching native-build.json executable_sha256",
                "reason_not_in_git_package": "compiled native executable; original bytes remain in complete original ZIP and scratch extraction",
            })
        excluded_paths = {row["path"] for row in excluded}
        with zipfile.ZipFile(filtered_path, "x", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9) as filtered:
            for info in infos:
                if info.filename in excluded_paths:
                    continue
                filtered.writestr(copy.copy(info), b"" if info.is_dir() else contents[info.filename])
                if not info.is_dir():
                    suffix = PurePosixPath(info.filename).suffix
                    retained_extensions[suffix] = retained_extensions.get(suffix, 0) + 1
        with zipfile.ZipFile(filtered_path) as filtered:
            assert set(filtered.namelist()) == set(names) - excluded_paths
            for name in archive_paths:
                if name not in excluded_paths:
                    assert filtered.read(name) == contents[name]
    filtered_bytes = filtered_path.read_bytes()
    retained = [row for row in inventory if row["path"] not in excluded_paths]
    write_json(stage / "original-artifact-files.json", inventory)
    write_json(stage / "artifact-identity.json", {
        "run_id": RUN, "job_id": JOB, "artifact_id": metadata["id"],
        "head": HEAD, "tree": TREE, "bytes": len(archive_bytes),
        "sha256": archive_digest, "api_digest_matches_downloaded_bytes": True,
    })
    provenance = {
        "schema_version": 1,
        "repository": "TrillionniumFoundation/hepta-private-ci",
        "head": HEAD, "tree": TREE, "run_id": RUN, "job_id": JOB,
        "artifact_id": metadata["id"], "artifact_name": metadata["name"],
        "artifact_created_at": metadata["created_at"],
        "artifact_expires_at": metadata["expires_at"],
        "original_zip": {
            "path": str(args.archive.resolve()), "bytes": len(archive_bytes),
            "sha256": archive_digest, "regular_files": len(inventory),
            "uncompressed_regular_bytes": sum(row["bytes"] for row in inventory),
        },
        "scratch_extraction": str(extraction),
        "filtered_git_package": {
            "path": str(filtered_path), "bytes": len(filtered_bytes),
            "sha256": sha(filtered_bytes), "regular_files": len(retained),
            "uncompressed_regular_bytes": sum(row["bytes"] for row in retained),
            "all_included_files_byte_identical_to_original": True,
            "complete_original_artifact": False,
        },
        "excluded_native_executables": excluded,
        "expected_bridge_executables_absent": sorted(EXPECTED_NATIVE - set(archive_paths)),
        "retained_extension_counts": dict(sorted(retained_extensions.items())),
        "retention_boundary": "Only independently identified compiled native executables are excluded from the filtered Git package. Every other original member is retained byte-for-byte. Complete original ZIP and full extraction remain in scratch. No archive member was executed.",
    }
    write_json(stage / "source-raw-provenance.json", provenance)
    print(json.dumps({key: provenance[key] for key in (
        "artifact_id", "original_zip", "filtered_git_package"
    )}, indent=2))


if __name__ == "__main__":
    main()
