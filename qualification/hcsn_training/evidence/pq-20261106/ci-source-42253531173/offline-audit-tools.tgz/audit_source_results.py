"""Audit retained final CI results and source hashes without running their code."""

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess


HEAD = "a20ea6a862e501d8a4993195c7da1ac52ca9a7be"
TREE = "b8e8b66b957aaf1e5e1cd9db8bb479137cf9fceb"
BACKENDS = ("value_kernel", "population_grid", "population_age")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def checked_relative(name):
    value = PurePosixPath(name)
    assert name and not value.is_absolute() and ".." not in value.parts
    assert "\\" not in name and str(value) == name
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", type=Path)
    parser.add_argument("repo", type=Path)
    args = parser.parse_args()
    stage = args.stage.resolve()
    root = stage / "original-extracted/_temp/hcsn-training-bridge"
    assert (root / "source.txt").read_text().splitlines() == [HEAD, TREE]
    assert subprocess.check_output(["git", "rev-parse", HEAD + "^{tree}"],
                                   cwd=args.repo, text=True).strip() == TREE
    checked_sources = {}

    def check_source(path, expected):
        checked_relative(path)
        if path not in checked_sources:
            data = subprocess.check_output(["git", "show", HEAD + ":" + path],
                                           cwd=args.repo)
            checked_sources[path] = hashlib.sha256(data).hexdigest()
        assert checked_sources[path] == expected, path

    cancellations = []
    for backend in BACKENDS:
        base = root / ("cancel-" + backend)
        result = read(base / "result.json")
        signed = read(base / "signed-cancel.json")
        request = read(base / "request.json")
        cancel = read(base / "cancel-request.json")
        assert result["status"] == signed["status"] == "passed"
        assert result["backend"] == backend
        assert result["authority_profile"] == signed["authority_profile"] == "synthetic_ed25519_v1"
        for field in ("signed_start_and_cancel_real_worker", "independent_worker_exit_verified",
                      "cold_owner_recovery", "terminal_step_readback_exact"):
            assert result[field] is True
        for field in ("production", "production_trust", "production_adoption",
                      "optimizer_entry_proven", "host_registration_exercised"):
            assert result[field] is False
        for field in ("changed_payload_rejected_before_contact",
                      "invalid_signature_rejected_before_contact", "start_grant_cannot_cancel",
                      "historical_observations_preserved", "independent_worker_exit_verified",
                      "lost_start_and_cancel_replies_injected", "terminal_step_readback_exact"):
            assert signed[field] is True
        assert signed["consumed_nonces"] == 2 and signed["replay_contacts"] == 0
        assert signed["retained_job_count"] == signed["retained_cancellation_count"] == 1
        assert signed["running"]["observation"]["state"] == "running"
        assert signed["running"]["proc_stat"] and signed["proc_stat_after"] is None
        observation = signed["observation"]
        assert observation["state"] == "cancelled"
        assert observation["target"] == observation["dispatch"] == cancel
        worker = observation["process"]
        assert worker == signed["running"]["observation"]["process"] == result["worker"]
        assert len({worker["process_id"], signed["parent_pid"], signed["cold_native_pid"]}) == 3
        assert digest(base / "request.json") == signed["request_file_sha256"] == cancel["payload_sha256"]
        assert digest(base / "cancel-request.json") == signed["cancel_request_sha256"]
        assert digest(base / "base.pt") == request["binding"]["model_digest"]
        job = base.joinpath(*checked_relative(result["retained_job"]).parts)
        terminal = read(job / "terminal.json")
        assert terminal["state"] == "cancelled" and terminal["reason"] == "cancelled_worker_stopped"
        assert terminal["termination_confirmed"] is True and terminal["no_retry"] is True
        assert terminal["process"] == worker and terminal["identity"] == cancel
        terminal_digest = digest(job / "terminal.json")
        assert terminal_digest == result["terminal_sha256"] == observation["evidence"]["receipt_sha256"]
        assert observation["evidence"]["candidate_sha256"] is None
        assert observation["evidence"]["handoff_sha256"] is None
        for name in ("candidate.pt", "receipt.json", "handoff.bin"):
            assert not list(job.rglob(name)), name
        receipts = signed["taskflow_step_receipts"]
        assert [row["final_outcome"] for row in receipts] == ["failed", "succeeded"]
        assert all(row["observation"] == "indeterminate" for row in receipts)
        assert receipts[0]["payload_digest"] == signed["request_file_sha256"]
        assert receipts[1]["payload_digest"] == signed["cancel_request_sha256"]
        retained = read(base / "retained-files.json")
        assert digest(base / "retained-files.json") == result["retained_files_sha256"]
        for path, expected in retained.items():
            assert digest(base.joinpath(*checked_relative(path).parts)) == expected, path
        sources = read(base / "sources-before.json")
        assert sources == read(base / "sources-after.json")
        for path, expected in sources["execution"].items():
            check_source("qualification/" + path, expected)
        for path, expected in sources["fixtures"].items():
            check_source("qualification/hcsn_training/" + path, expected)
        check_source("qualification/hcsn_training/verify_cancel.py", sources["cancellation_verifier"])
        process = read(base / "signed-cancel-real-worker.process.json")
        assert process["returncode"] == 0 and process["pid"] == signed["parent_pid"]
        assert process["error"] is None and process["cleanup_error"] is None
        assert digest(base / "signed-cancel-real-worker.stdout") == process["stdout_sha256"]
        assert digest(base / "signed-cancel-real-worker.stderr") == process["stderr_sha256"]
        assert read(base / "signed-cancel-child.json")["success"] is True
        preflight = result["admission_preflight"]
        assert preflight == read(base / "cancellation-preflight/result.json")
        assert preflight["status"] == "passed" and preflight["admitted_optimizer_steps"] == 1
        assert preflight["cancellation_optimizer_steps"] == 64
        assert preflight["optimizer_entry_in_cancelled_process_proven"] is False
        assert preflight["uncancelled_64_step_duration_measured"] is False
        assert preflight["checkpoint_sha256"] == digest(base / "cancellation-preflight/candidate.pt")
        workload = result["cancellation_workload"]
        assert workload == read(base / "cancellation-workload.json")
        assert workload["working_elements"] <= workload["maximum_elements"] == 1048576
        assert workload["maximum_optimizer_steps"] == 64
        assert workload["request_bytes"] == (base / "request.json").stat().st_size
        assert workload["request_bytes"] <= workload["maximum_host_wire_bytes"] == 24576
        cancellations.append({
            "backend": backend, "status": "passed", "worker": worker,
            "workload": workload, "preflight_optimizer_steps": 1,
            "actual_optimizer_entry_proven": False, "requested_cancellation_steps": 64,
            "lost_replies_injected": True, "parent_pid": signed["parent_pid"],
            "cold_native_pid": signed["cold_native_pid"],
            "retained_file_hashes_verified": len(retained), "terminal_state": terminal["state"],
            "terminal_reason": terminal["reason"], "termination_confirmed": True,
            "historical_observations_preserved": True, "mutating_replay_contacts": 0,
            "final_outcomes": [row["final_outcome"] for row in receipts],
            "candidate_output_absent": True, "preflight_wall_seconds": preflight["wall_seconds"],
            "cpu_seconds_to_observed_termination": terminal["child_cpu_seconds"],
            "wall_seconds_to_observed_termination": terminal["wall_seconds"],
            "source_hashes_match_exact_published_checkout": True,
        })
    bridges = []
    for directory, backend in zip(("bridge-a", "bridge-b", "bridge-b-age"), BACKENDS):
        base = root / directory
        result = read(base / "result.json")
        second = read(base / "second-block/result.json")
        build = read(base / "native-build.json")
        assert result["status"] == second["status"] == "passed"
        assert result["backend"] == backend and result["supervised"] and result["signed_taskflow"]
        assert read(base / "signed-taskflow-child.json")["success"] is True
        assert len({result["caller_pid"], result["worker_pid"], result["cold_python_pid"]}) == 3
        assert result["runtime_tuple"]["torch"] == "2.8.0+cpu"
        assert result["runtime_tuple"]["numpy"] == "2.3.5"
        assert result["runtime_tuple"]["scipy"] == "1.17.0"
        assert result["runtime_tuple"]["device"] == "cpu"
        assert result["runtime_tuple"]["dtype"] == "torch.float64"
        assert result["logical_cells"] == result["gradient_cells"] == 2
        assert result["gradient_parameters"] == result["trainable_parameters"] > 0
        assert result["optimizer_steps"] == result["completed_optimizer_steps"] == 1
        assert second["optimizer_steps"] == 2 and second["mode"] == "resume"
        assert result["second_training_block"] == second
        for field in ("resumed_output_exact", "resumed_all_state_exact", "base_bytes_unchanged"):
            assert result[field] is True
        for field in ("complete_state_exact", "weights_exact", "prediction_exact",
                      "initial_state_unchanged", "original_checkpoint_unchanged"):
            assert second[field] is True
        assert result["signed_owner"]["candidate_only"] and second["native_publication"]["candidate_only"]
        assert result["production_trust"] is False and result["production_adoption"] is False
        assert result["task_gain_qualified"] is False and result["cuda_campaign_started"] is False
        assert digest(base / "base.pt") == result["base_checkpoint_digest"]
        for block, item in ((base, result), (base / "second-block", second)):
            assert digest(block / "worker/candidate.pt") == item["candidate_digest"]
            assert digest(block / "readback.pt") == item["candidate_digest"]
        assert second["base_checkpoint_digest"] == result["candidate_digest"]
        assert digest(base / "native-fixture") == build["executable_sha256"]
        for path, expected in build["rust_sources"].items():
            check_source("codex-rs/" + path, expected)
        bridges.append({
            "backend": backend, "status": "passed", "logical_cells": 2, "gradient_cells": 2,
            "trainable_parameters": result["trainable_parameters"],
            "gradient_parameters": result["gradient_parameters"],
            "first_block_optimizer_steps": 1, "second_block_optimizer_steps": 2,
            "second_block_full_state_weights_and_prediction_exact": True,
            "second_block_starts_detached": True, "candidate_only": True,
            "runtime_tuple": result["runtime_tuple"],
        })
    python_log = (root / "python-tests.log").read_text()
    match = re.search(r"Ran (\d+) tests in ([\d.]+)s", python_log)
    assert match and int(match[1]) == 69
    assert re.search(r"^OK$", python_log, re.MULTILINE)
    test_lines = re.findall(r"^test_\S+ \(([^)]+)\) \.\.\. ", python_log, re.MULTILINE)
    passed_lines = re.findall(
        r"^test_\S+ \(([^)]+)\) \.\.\. (?:retained_supervisor_fixture=[^\n]+\n)?ok$",
        python_log, re.MULTILINE,
    )
    assert len(test_lines) == len(passed_lines) == 69 and test_lines == passed_lines
    modules_passed = {}
    for test_name in passed_lines:
        module = test_name.rsplit(".", 2)[0]
        modules_passed[module] = modules_passed.get(module, 0) + 1
    rust = (root / "rust-tests.log").read_text()
    automation = (root / "taskflow-tests.log").read_text()
    assert re.search(r"392 tests run: 392 passed, 1 skipped", rust)
    assert re.search(r"120 tests run: 120 passed, 2 skipped", automation)
    assert not (root / "source-unchanged.log").read_bytes()
    assert not (root / "source-diff-check.log").read_bytes()
    report = {
        "schema_version": 1,
        "scope": "offline audit of retained CI bytes, receipt consistency and exact Git source hashes; no numerical code, native fixture, supervisor or training was rerun",
        "head": HEAD, "tree": TREE, "run_id": 42253531173, "job_id": 128014547080,
        "artifact": read(stage / "artifact-identity.json"),
        "cancellation": cancellations, "bridges": bridges,
        "tests": {"python_passed": 69, "python_skipped": 0, "python_seconds": float(match[2]),
                  "python_modules_passed": modules_passed,
                  "numerical_artifact_contracts_passed": 392, "numerical_artifact_contracts_skipped": 1,
                  "automation_passed": 120, "automation_skipped": 2},
        "checked_source_files": checked_sources,
        "tracked_source_unchanged_logs_empty": True,
        "scope_limits": [
            "Numerical exactness and native signature/recovery assertions are results of the recorded CI executions; this audit checks their retained evidence and identity, not an independent numerical recomputation.",
            "Persistence restores complete numerical state; next-block autograd begins from detached state.",
            "Cancellation proves real worker identity and exit; optimizer entry in that cancelled process is explicitly not proven.",
            "These three cancellations use synthetic Ed25519 fixture trust, not the separate Agentd production-profile composition fixture.",
            "No production deployment, model adoption, scientific gain or physical energy claim."
        ],
    }
    output = stage / "artifact-review.json"
    with output.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"report": str(output), "sha256": digest(output),
                      "source_files_checked": len(checked_sources), "tests": report["tests"],
                      "bridges": len(bridges), "cancellations": len(cancellations)}, indent=2))


if __name__ == "__main__":
    main()
