#![forbid(unsafe_code)]

mod agent_id;
mod authbus;
#[cfg(feature = "authbus-local-qualification")]
pub mod authbus_b3_adapter;
#[cfg(any(test, feature = "authbus-local-qualification"))]
pub mod authbus_b4;
#[cfg(any(test, feature = "authbus-local-qualification"))]
pub mod authbus_b5;
#[cfg(test)]
#[path = "authbus_tests.rs"]
mod authbus_tests;
mod authority_authentication;
pub mod authority_lease;
pub mod authority_trust;
mod authority_trust_release;
pub mod authority_trust_unix;
mod learning_authentication;
pub mod pq_auth;
pub use authority_authentication::FinalUseAuthenticationProfile;
pub use authority_authentication::PqAuthorityTrustKey;
pub use learning_authentication::LearningAuthenticationProfile;
pub use learning_authentication::LearningSignature;
pub use learning_authentication::LearningVerificationKey;
#[cfg(test)]
mod callers_manifest_tests;
mod canonical;
mod final_use;
mod final_use_control;
#[cfg(windows)]
pub use codex_utils_windows_private_state::stage::SynchronousStageFile;
#[cfg(windows)]
pub use codex_utils_windows_private_state::stage::replace_synced_state_stage;
mod identity;
mod memory;
mod provider;
mod provider_effect;
mod qualification_receipt;
mod receipt;
mod stable_id;
mod verified_use_witness;
#[cfg(all(test, windows))]
#[path = "windows_state_stage_tests.rs"]
mod windows_state_stage_tests;

pub use authority_lease::deliver_authority_lease_with_witness;
pub use authority_lease::dispatch_authority_lease_with_witness;
pub use authority_trust::AuthorityClock;
pub use authority_trust::AuthorityFrontierStore;
pub use authority_trust::AuthorityTrustError;
pub use authority_trust::SystemAuthorityClock;
pub use authority_trust_release::ReleaseFrontierV1;

pub use final_use::EnteredUseToken;
pub use final_use::FinalUseAuthority;
pub use final_use::FinalUseBinding;
pub use final_use::FinalUseCapacity;
pub use final_use::FinalUseError;
pub use final_use::FinalUseFrontier;
pub use final_use::FinalUseGrant;
pub use final_use::FinalUseIssuerTrustKey;
pub use final_use::FinalUseRevocations;
pub use final_use::SignedFinalUseGrant;
pub use final_use::VerifiedUseToken;
pub use final_use::claim_final_use;
pub use final_use::deliver_final_use;
pub use final_use::deliver_final_use_with_witness;
pub use final_use::dispatch_final_use;
pub use final_use::dispatch_final_use_with_witness;
pub use final_use_control::FinalUseApproval;
pub use final_use_control::FinalUseApprovalVerifier;
pub use final_use_control::FinalUseControlError;
pub use final_use_control::FinalUseRevocationAck;
pub use final_use_control::FinalUseRevocationConvergenceReport;
pub use final_use_control::FinalUseRevocationConvergenceVerifier;
pub use final_use_control::FinalUseRevocationFeedVerifier;
pub use final_use_control::FinalUseRevocationNodeTrust;
pub use final_use_control::FinalUseRevocationReceipt;
pub use final_use_control::FinalUseRevocationUpdate;
pub use final_use_control::FinalUseTrustKey;
pub use final_use_control::MAX_REVOCATION_FEED_LIFETIME_MS;
pub use final_use_control::PqFinalUseRevocationNodeTrust;
pub use final_use_control::SignedFinalUseApproval;
pub use final_use_control::SignedFinalUseRevocationAck;
pub use final_use_control::SignedFinalUseRevocationUpdate;
pub use verified_use_witness::AuthorityLeaseWitnessRefV1;
pub use verified_use_witness::FinalUseWitnessRefV1;
pub use verified_use_witness::VERIFIED_USE_TOKEN_WITNESS_SCHEMA_VERSION;
pub use verified_use_witness::VerifiedUseAuthorityRefV1;
pub use verified_use_witness::VerifiedUseBoundaryV1;
pub use verified_use_witness::VerifiedUseTokenWitnessV1;
pub use verified_use_witness::VerifiedUseWitnessError;

pub use agent_id::AgentId;
pub use agent_id::AgentIdParseError;
pub use authbus::AUTHBUS_CONTRACT_NAMESPACE;
pub use authbus::AUTHBUS_CONTRACT_SCHEMA_VERSION;
pub use authbus::AUTHBUS_PLAN_ID;
pub use authbus::AUTHBUS_SOURCE_MANIFEST_JSON;
pub use authbus::AUTHBUS_SOURCE_MANIFEST_SCHEMA;
pub use authbus::AuthBusAuthorityFlags;
pub use authbus::AuthBusCandidateBinding;
pub use authbus::AuthBusContractError;
pub use authbus::AuthBusRefSet;
pub use authbus::AuthBusSourceAttachment;
pub use authbus::AuthBusSourceManifest;
pub use authbus::AuthBusUpstreamPin;
pub use authbus::AuthRequest;
pub use authbus::AuthResource;
pub use authbus::BASIL_LATEST_RELEASE;
pub use authbus::BASIL_LICENSE;
pub use authbus::BASIL_UPSTREAM_COMMIT;
pub use authbus::BASIL_UPSTREAM_REPOSITORY;
pub use authbus::BASIL_WORKSPACE_VERSION;
pub use authbus::LeaseState;
pub use authbus::Principal;
pub use authbus::QuotaConfidence;
pub use authbus::QuotaContract;
pub use authbus::QuotaSnapshot;
pub use authbus::ResourceLease;
pub use authbus::Revoke;
pub use authbus::SecretRef;
pub use authbus::SubjectRef;
pub use authbus::UsagePermit;
pub use authbus::UsageReceipt;
pub use authbus::UsageTerminal;
pub use authbus::b1::AUTHBUS_B1_CONTRACT_SCHEMA_VERSION;
pub use authbus::b1::AUTHBUS_B1_PROFILE_ID;
pub use authbus::b1::BASIL_B1_ALLOWED_ROUTES;
pub use authbus::b1::BASIL_B1_DENIED_ROUTES;
pub use authbus::b1::BASIL_B1_OPTIONAL_PROCESS_BOUND_ROUTES;
pub use authbus::b1::BasilKeyGenerationMode;
pub use authbus::b1::BasilKeyRegistration;
pub use authbus::b1::BasilRouteClass;
pub use authbus::b1::BasilServiceProfile;
pub use authbus::b1::IdentityBinding;
pub use authbus::b1::IdentityPeerEvidence;
pub use authbus::b2::AUTHBUS_B2_AUTHORITY_DEFAULT;
pub use authbus::b2::AUTHBUS_B2_CONTRACT_SCHEMA_VERSION;
pub use authbus::b2::AdmissionDecision;
pub use authbus::b2::AdmissionDecisionKind;
pub use authbus::b2::CapabilityAttenuation;
pub use authbus::b2::ClockSnapshot;
pub use authbus::b2::ClockSource;
pub use authbus::b2::OperationRef;
pub use authbus::b2::PeerSession;
pub use authbus::b2::PeerTrustMode;
pub use authbus::b2::ProviderStatus;
pub use authbus::b2::ProviderStatusKind;
pub use authbus::b2::ProviderStatusState;
pub use authbus::b2::QuotaReservation;
pub use authbus::b2::QuotaReservationState;
pub use authbus::b2::ResourceAdvertisement;
pub use authbus::b2::ResourceAdvertisementState;
pub use authbus::b3::AUTHBUS_B3_CONTRACT_SCHEMA_VERSION;
pub use authbus::b3::AUTHBUS_B3_QUALIFICATION_ONLY;
pub use authbus::b3::AUTHBUS_B3_RAW_SECRET_BYTES_ALLOWED;
pub use authbus::b3::AUTHBUS_B3_STATUS_LOOKUP_ONLY;
pub use authbus::b3::OpaqueSecretRef;
pub use authbus::b3::ProcessBoundSecretRef;
pub use authbus::b3::RefreshStatusByOperationKeyRequest;
pub use authbus::b3::RefreshStatusByOperationKeyResponse;
pub use authbus::b3::RefreshWithSecretRefRequest;
pub use authbus::b3::RefreshWithSecretRefResponse;
pub use authbus::b3::RotateSecretRefRequest;
pub use authbus::b3::RotateSecretRefResponse;
pub use authbus::b3::SecretProviderStatus;
pub use authbus::b3::SecretRefBinding;
pub use authbus::b3::SecretRefCallbackFence;
pub use authbus::b3::SecretRefErrorClass;
pub use authbus::b3::SecretRefEvent;
pub use authbus::b3::SecretRefOperationRecord;
pub use authbus::b3::SecretRefOutcome;
pub use authbus::b3::SecretRefState;
pub use authbus::b3::derive_refresh_operation_id;
pub use authbus::b3::derive_refresh_operation_key;
pub use authbus::embedded_source_manifest;
pub use authbus::embedded_source_manifest_for_candidate;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::AUTHBUS_B4_AUTHORITY;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::AUTHBUS_B4_EFFECT_AUTHORITY;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::AUTHBUS_B4_EXECUTE_ALLOWED;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::AUTHBUS_B4_G5_ALLOWED;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::AUTHBUS_B4_OPERATOR_ACCEPTANCE;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::AUTHBUS_B4_PRODUCTION_CALLER;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::AUTHBUS_B4_PRODUCTION_WRITER;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::AUTHBUS_B4_PROMOTION;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::AUTHBUS_B4_QUALIFICATION_ONLY;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::LocalScheduler;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::QuotaLimits;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::QuotaVector;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::ResourceState;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::SchedulerError;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::SchedulerPermit;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::SchedulerRequest;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::SchedulerResource;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b4::jain_fairness_ppm;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::AUTHBUS_B5_AUTHORITY;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::AUTHBUS_B5_EFFECT_AUTHORITY;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::AUTHBUS_B5_EXECUTE_ALLOWED;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::AUTHBUS_B5_G5_ALLOWED;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::AUTHBUS_B5_OPERATOR_ACCEPTANCE;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::AUTHBUS_B5_PRODUCTION_CALLER;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::AUTHBUS_B5_PRODUCTION_WRITER;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::AUTHBUS_B5_PROMOTION;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::AUTHBUS_B5_QUALIFICATION_ONLY;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::B5AppendDisposition;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::B5DispatchResponse;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::B5DispatchTicket;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::B5EffectState;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::B5Error;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::B5Fence;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::B5Intent;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::B5LookupOutcome;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::B5OutboxDelivery;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::B5RecoveryAction;
#[cfg(feature = "authbus-local-qualification")]
pub use authbus_b5::LocalB5Wal;
pub use identity::ActionId;
pub use identity::DecisionId;
pub use identity::ReceiptId;
pub use memory::AttachmentTrust;
pub use memory::CrossThreadScope;
pub use memory::MEMORY_CONTRACT_SCHEMA_VERSION;
pub use memory::MemoryAttachmentMetadata;
pub use memory::MemoryId;
pub use memory::MemoryLifecycle;
pub use memory::MemoryProvenance;
pub use memory::MemoryRevision;
pub use memory::MemoryScope;
pub use memory::MemorySourceKind;
pub use memory::QueryFingerprint;
pub use memory::RankedMemoryRef;
pub use memory::RecallAuthority;
pub use memory::RecallEligibility;
pub use memory::RecallLimits;
pub use memory::RecallRequest;
pub use memory::RecallRequestId;
pub use memory::RecallScorePpm;
pub use memory::RevisionStamp;
pub use memory::SCORE_SCALE_PPM;
pub use provider::PROVIDER_EVIDENCE_SCHEMA_VERSION;
pub use provider::ProviderAttemptId;
pub use provider::ProviderInvocationIntent;
pub use provider::ProviderInvocationReceipt;
pub use provider::ProviderReceiptId;
pub use provider::ProviderRequestBinding;
pub use provider::ProviderRequestKind;
pub use provider::ProviderTerminal;
pub use provider::ProviderTransport;
pub use provider::RequestBindingId;
pub use provider_effect::PROVIDER_EFFECT_SCHEMA_VERSION;
pub use provider_effect::ProviderEffectAck;
pub use provider_effect::ProviderEffectAckSource;
pub use provider_effect::ProviderEffectAckStatus;
pub use provider_effect::ProviderEffectAdapter;
pub use provider_effect::ProviderEffectAppendDisposition;
pub use provider_effect::ProviderEffectBindingError;
pub use provider_effect::ProviderEffectCoordinator;
pub use provider_effect::ProviderEffectCoordinatorError;
pub use provider_effect::ProviderEffectDispatch;
pub use provider_effect::ProviderEffectDispatchReceipt;
pub use provider_effect::ProviderEffectFuture;
pub use provider_effect::ProviderEffectIdempotencyCapability;
pub use provider_effect::ProviderEffectIntent;
pub use provider_effect::ProviderEffectJournal;
pub use provider_effect::ProviderEffectKey;
pub use provider_effect::ProviderEffectLookup;
pub use provider_effect::ProviderEffectState;
pub use provider_effect::ProviderEffectStatusObservation;
pub use provider_effect::ProviderEffectUncertainty;
pub use provider_effect::reconcile_provider_lookup;
pub use qualification_receipt::GovernanceQualificationReceipt;
pub use qualification_receipt::QUALIFICATION_RECEIPT_EFFECT_AUTHORITY;
pub use qualification_receipt::QUALIFICATION_RECEIPT_EXECUTE_ALLOWED;
pub use qualification_receipt::QUALIFICATION_RECEIPT_G5_ALLOWED;
pub use qualification_receipt::QUALIFICATION_RECEIPT_GOVERNANCE_BYPASS;
pub use qualification_receipt::QUALIFICATION_RECEIPT_NAMESPACE;
pub use qualification_receipt::QUALIFICATION_RECEIPT_OPERATOR_ACCEPTANCE;
pub use qualification_receipt::QUALIFICATION_RECEIPT_PRODUCTION_CALLER;
pub use qualification_receipt::QUALIFICATION_RECEIPT_PRODUCTION_WRITER;
pub use qualification_receipt::QUALIFICATION_RECEIPT_PROMOTION;
pub use qualification_receipt::QUALIFICATION_RECEIPT_SCHEMA_VERSION;
pub use qualification_receipt::QualificationGovernanceReceipt;
pub use qualification_receipt::QualificationReceiptStatus;
pub use qualification_receipt::SupervisorRollbackReceipt;
pub use receipt::GOVERNANCE_SCHEMA_VERSION;
pub use receipt::GovernanceDecision;
pub use receipt::GovernanceDecisionRecord;
pub use receipt::GovernanceMode;
pub use receipt::GovernanceReceipt;
pub use receipt::HandlerOutcome;
pub use receipt::PolicyPhase;
pub use receipt::PolicyStamp;
pub use receipt::Sha256Digest;
pub use receipt::ToolAction;
pub use receipt::ToolActionSource;

pub use learning_authentication::LearningTrustFrontier;

#[cfg(windows)]
pub use codex_utils_windows_private_state::parent_anchor as windows_private_owner;
