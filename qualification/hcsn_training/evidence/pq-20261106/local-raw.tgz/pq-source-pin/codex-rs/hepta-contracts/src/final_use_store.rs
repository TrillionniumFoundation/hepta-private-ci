//! Persistent nonce/revocation owner. OS locks are released on process death.
//!
//! Revocation/trust state is a small atomic snapshot. Replay claims use a
//! fixed-width append-only journal so the dispatch hot path does not rewrite an
//! ever-growing JSON set.

use super::FinalUseAuthenticationProfile;
use super::FinalUseError;
use super::FinalUseRevocations;
use super::MAX_CLAIMS;
use super::State;
use super::valid_head_with_profile;
use serde::Deserialize;
use serde::Serialize;
use std::collections::BTreeSet;
#[cfg(not(windows))]
use std::fs::File;
use std::io::Seek;
use std::io::SeekFrom;
use std::io::Write;
use std::path::Path;

const STATE_SCHEMA_V1: u32 = 1;
const STATE_SCHEMA_V2: u32 = 2;
const STATE_SCHEMA_V3: u32 = 3;
const STATE_SCHEMA_PQ_V4: u32 = 4;
const CLAIM_FRAME_BYTES: usize = 8 + 32;

#[derive(Deserialize)]
struct StoredHeader {
    schema: u32,
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct StoredV1 {
    schema: u32,
    signer_id: String,
    verifying_key: [u8; 32],
    state: State,
}

// Schema 2 was independently used by the key-ring snapshot and the
// single-key journal. Distinct fields make both legacy formats unambiguous.
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct StoredV2 {
    schema: u32,
    signer_id: String,
    issuer_trust_sha256: [u8; 32],
    state: State,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct StoredJournalV2 {
    schema: u32,
    signer_id: String,
    verifying_key: [u8; 32],
    head: FinalUseRevocations,
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct StoredV3 {
    schema: u32,
    signer_id: String,
    trust: StoreTrust,
    head: FinalUseRevocations,
}

#[derive(Clone, Copy, Deserialize, Eq, PartialEq, Serialize)]
pub(super) enum StoreTrust {
    SingleKey([u8; 32]),
    IssuerKeyRing([u8; 32]),
    PqIssuerKeyRing([u8; 32]),
}

pub(super) struct Store {
    root: io::Directory,
    signer_id: String,
    trust: StoreTrust,
    #[cfg(not(windows))]
    _lock: File,
}

impl Store {
    /// Probe the actual retained Windows namespace and original owner marker.
    /// The caller holds the authority state lock and permanently fences state
    /// on any refusal; this never reopens or manufactures store authority.
    #[cfg(windows)]
    pub(super) fn revalidate_owner(&self) -> Result<(), FinalUseError> {
        self.root
            .revalidate_shared()
            .map_err(|_| FinalUseError::Unavailable)
    }

    pub(super) fn open_pq_key_ring_exact(
        root: &Path,
        signer_id: &str,
        issuer_trust_sha256: [u8; 32],
        initial: FinalUseRevocations,
    ) -> Result<(Self, State), FinalUseError> {
        Self::open_inner(
            root,
            signer_id,
            StoreTrust::PqIssuerKeyRing(issuer_trust_sha256),
            initial,
            /*allow_startup_head_advance*/ false,
        )
    }
    pub(super) fn open(
        root: &Path,
        signer_id: &str,
        verifying_key: [u8; 32],
        initial: FinalUseRevocations,
    ) -> Result<(Self, State), FinalUseError> {
        Self::open_inner(
            root,
            signer_id,
            StoreTrust::SingleKey(verifying_key),
            initial,
            /*allow_startup_head_advance*/ true,
        )
    }

    pub(super) fn open_exact(
        root: &Path,
        signer_id: &str,
        verifying_key: [u8; 32],
        initial: FinalUseRevocations,
    ) -> Result<(Self, State), FinalUseError> {
        Self::open_inner(
            root,
            signer_id,
            StoreTrust::SingleKey(verifying_key),
            initial,
            /*allow_startup_head_advance*/ false,
        )
    }

    pub(super) fn open_key_ring_exact(
        root: &Path,
        signer_id: &str,
        issuer_trust_sha256: [u8; 32],
        initial: FinalUseRevocations,
    ) -> Result<(Self, State), FinalUseError> {
        Self::open_inner(
            root,
            signer_id,
            StoreTrust::IssuerKeyRing(issuer_trust_sha256),
            initial,
            /*allow_startup_head_advance*/ false,
        )
    }

    fn open_inner(
        root: &Path,
        signer_id: &str,
        trust: StoreTrust,
        initial: FinalUseRevocations,
        allow_startup_head_advance: bool,
    ) -> Result<(Self, State), FinalUseError> {
        let opened = io::lock_directory(root)?;
        Self::open_locked(
            opened,
            signer_id,
            trust,
            initial,
            allow_startup_head_advance,
            #[cfg(windows)]
            /*frontier_store*/
            None,
        )
    }

    #[cfg(windows)]
    pub(super) fn open_windows(
        directory: crate::windows_private_owner::PrivateStoreDirectory,
        signer_id: &str,
        trust: StoreTrust,
        initial: FinalUseRevocations,
        frontier_store: &dyn crate::AuthorityFrontierStore<super::FinalUseFrontier>,
    ) -> Result<(Self, State), FinalUseError> {
        let opened = io::LockedDirectory::from_windows(directory)?;
        Self::open_locked(
            opened,
            signer_id,
            trust,
            initial,
            /*allow_startup_head_advance*/ false,
            Some(frontier_store),
        )
    }

    fn open_locked(
        opened: io::LockedDirectory,
        signer_id: &str,
        trust: StoreTrust,
        initial: FinalUseRevocations,
        allow_startup_head_advance: bool,
        #[cfg(windows)] frontier_store: Option<
            &dyn crate::AuthorityFrontierStore<super::FinalUseFrontier>,
        >,
    ) -> Result<(Self, State), FinalUseError> {
        let initialized = opened.initialized;
        let store = Self {
            root: opened.root,
            signer_id: signer_id.to_owned(),
            trust,
            #[cfg(not(windows))]
            _lock: opened.lock,
        };
        let has_state = entry_exists(&store.root, "authority.json")?;
        let mut state = if has_state {
            let bytes = read_bounded(&store.root, "authority.json", 8 * 1024 * 1024)?;
            let header: StoredHeader =
                serde_json::from_slice(&bytes).map_err(|_| FinalUseError::InvalidTrust)?;
            let (mut state, legacy_snapshot) = match (trust, header.schema) {
                (StoreTrust::SingleKey(verifying_key), STATE_SCHEMA_V1) => {
                    let stored: StoredV1 =
                        serde_json::from_slice(&bytes).map_err(|_| FinalUseError::InvalidTrust)?;
                    if stored.signer_id != signer_id || stored.verifying_key != verifying_key {
                        return Err(FinalUseError::InvalidTrust);
                    }
                    (stored.state, true)
                }
                (StoreTrust::IssuerKeyRing(issuer_trust_sha256), STATE_SCHEMA_V2) => {
                    let stored: StoredV2 =
                        serde_json::from_slice(&bytes).map_err(|_| FinalUseError::InvalidTrust)?;
                    if stored.schema != STATE_SCHEMA_V2
                        || stored.signer_id != signer_id
                        || stored.issuer_trust_sha256 != issuer_trust_sha256
                    {
                        return Err(FinalUseError::InvalidTrust);
                    }
                    (stored.state, true)
                }
                (StoreTrust::SingleKey(verifying_key), STATE_SCHEMA_V2) => {
                    let stored: StoredJournalV2 =
                        serde_json::from_slice(&bytes).map_err(|_| FinalUseError::InvalidTrust)?;
                    if stored.schema != STATE_SCHEMA_V2
                        || stored.signer_id != signer_id
                        || stored.verifying_key != verifying_key
                    {
                        return Err(FinalUseError::InvalidTrust);
                    }
                    (
                        State {
                            used_nonces: store.read_claims(stored.head.authority_epoch)?,
                            head: stored.head,
                            failed: false,
                        },
                        false,
                    )
                }
                (StoreTrust::SingleKey(_) | StoreTrust::IssuerKeyRing(_), STATE_SCHEMA_V3)
                | (StoreTrust::PqIssuerKeyRing(_), STATE_SCHEMA_PQ_V4) => {
                    let stored: StoredV3 =
                        serde_json::from_slice(&bytes).map_err(|_| FinalUseError::InvalidTrust)?;
                    if stored.signer_id != signer_id || stored.trust != trust {
                        return Err(FinalUseError::InvalidTrust);
                    }
                    (
                        State {
                            used_nonces: store.read_claims(stored.head.authority_epoch)?,
                            head: stored.head,
                            failed: false,
                        },
                        false,
                    )
                }
                _ => return Err(FinalUseError::InvalidTrust),
            };
            let profile = match trust {
                StoreTrust::SingleKey(_) | StoreTrust::IssuerKeyRing(_) => {
                    FinalUseAuthenticationProfile::ClassicalV1
                }
                StoreTrust::PqIssuerKeyRing(_) => FinalUseAuthenticationProfile::MlDsa65V2,
            };
            if !valid_head_with_profile(&state.head, profile)
                || state.used_nonces.len() > MAX_CLAIMS
            {
                return Err(FinalUseError::InvalidTrust);
            }
            state.failed = false;
            #[cfg(windows)]
            io::validate_windows_prewrite(&state, &initial, signer_id, frontier_store)?;
            if header.schema != STATE_SCHEMA_V3 && header.schema != STATE_SCHEMA_PQ_V4 {
                // Publish a complete legacy nonce set before its journal-based
                // snapshot. Retrying an interrupted migration is idempotent.
                if legacy_snapshot {
                    store.replace_claims(state.head.authority_epoch, &state.used_nonces)?;
                }
                store.persist_snapshot(&state.head)?;
            }
            state
        } else {
            // Once initialized, absence is data loss, never permission to
            // reset the replay registry. An interrupted first start also
            // fails closed and needs explicit owner recovery.
            if initialized {
                return Err(FinalUseError::InvalidTrust);
            }
            let state = State {
                head: initial.clone(),
                used_nonces: Default::default(),
                failed: false,
            };
            #[cfg(windows)]
            io::validate_windows_prewrite(&state, &initial, signer_id, frontier_store)?;
            store.replace_claims(initial.authority_epoch, &state.used_nonces)?;
            store.persist_snapshot(&initial)?;
            state
        };

        if allow_startup_head_advance {
            if initial.authority_epoch >= state.head.authority_epoch
                && initial.revision > state.head.revision
                && (initial.authority_epoch > state.head.authority_epoch
                    || initial
                        .revoked_grant_ids
                        .is_superset(&state.head.revoked_grant_ids))
            {
                if initial.authority_epoch > state.head.authority_epoch {
                    state.used_nonces.clear();
                }
                state.head = initial;
                store.persist(&state)?;
            } else if state.head.authority_epoch < initial.authority_epoch
                || state.head.revision < initial.revision
                || (state.head.authority_epoch == initial.authority_epoch
                    && !state
                        .head
                        .revoked_grant_ids
                        .is_superset(&initial.revoked_grant_ids))
            {
                return Err(FinalUseError::InvalidTrust);
            }
        } else if state.head != initial {
            return Err(FinalUseError::InvalidTrust);
        }

        Ok((store, state))
    }

    /// Persist a revocation/epoch transition. This path is not the per-claim
    /// hot path, so it may compact the claim journal to the current epoch.
    pub(super) fn persist(&self, state: &State) -> Result<(), FinalUseError> {
        self.persist_snapshot(&state.head)?;
        self.replace_claims(state.head.authority_epoch, &state.used_nonces)
    }

    /// Durably burn one nonce. The fixed frame makes claim persistence O(1)
    /// in the number of prior claims.
    pub(super) fn append_claim(
        &self,
        authority_epoch: u64,
        nonce: [u8; 32],
    ) -> Result<(), FinalUseError> {
        if authority_epoch == 0 || nonce == [0; 32] {
            return Err(FinalUseError::InvalidTrust);
        }
        let mut file = open_private(&self.root, "authority.claims", Access::Write)?;
        file.seek(SeekFrom::End(0))
            .map_err(|_| FinalUseError::Unavailable)?;
        file.write_all(&authority_epoch.to_be_bytes())
            .and_then(|()| file.write_all(&nonce))
            .and_then(|()| file.sync_all())
            .map_err(|_| FinalUseError::Unavailable)
    }

    fn persist_snapshot(&self, head: &FinalUseRevocations) -> Result<(), FinalUseError> {
        let stored = StoredV3 {
            schema: match self.trust {
                StoreTrust::SingleKey(_) | StoreTrust::IssuerKeyRing(_) => STATE_SCHEMA_V3,
                StoreTrust::PqIssuerKeyRing(_) => STATE_SCHEMA_PQ_V4,
            },
            signer_id: self.signer_id.clone(),
            trust: self.trust,
            head: head.clone(),
        };
        let bytes = serde_json::to_vec(&stored).map_err(|_| FinalUseError::Unavailable)?;
        let mut file = open_private(&self.root, "authority.next", Access::Create)?;
        file.set_len(0).map_err(|_| FinalUseError::Unavailable)?;
        file.write_all(&bytes)
            .and_then(|()| file.sync_all())
            .map_err(|_| FinalUseError::Unavailable)?;
        replace_state(&self.root, &file)?;
        self.root.sync_all().map_err(|_| FinalUseError::Unavailable)
    }

    fn read_claims(&self, authority_epoch: u64) -> Result<BTreeSet<[u8; 32]>, FinalUseError> {
        if !entry_exists(&self.root, "authority.claims")? {
            return Err(FinalUseError::InvalidTrust);
        }
        let maximum = MAX_CLAIMS
            .checked_mul(CLAIM_FRAME_BYTES)
            .and_then(|value| value.checked_add(CLAIM_FRAME_BYTES))
            .ok_or(FinalUseError::InvalidTrust)?;
        let bytes = read_bounded(&self.root, "authority.claims", maximum)?;
        if bytes.len() % CLAIM_FRAME_BYTES != 0 {
            return Err(FinalUseError::InvalidTrust);
        }
        let mut claims = BTreeSet::new();
        for frame in bytes.chunks_exact(CLAIM_FRAME_BYTES) {
            let mut epoch_bytes = [0u8; 8];
            epoch_bytes.copy_from_slice(&frame[..8]);
            let epoch = u64::from_be_bytes(epoch_bytes);
            if epoch == 0 || epoch > authority_epoch {
                return Err(FinalUseError::InvalidTrust);
            }
            if epoch == authority_epoch {
                let mut nonce = [0u8; 32];
                nonce.copy_from_slice(&frame[8..]);
                if nonce == [0; 32] || !claims.insert(nonce) {
                    return Err(FinalUseError::InvalidTrust);
                }
            }
        }
        if claims.len() > MAX_CLAIMS {
            return Err(FinalUseError::InvalidTrust);
        }
        Ok(claims)
    }

    fn replace_claims(
        &self,
        authority_epoch: u64,
        claims: &BTreeSet<[u8; 32]>,
    ) -> Result<(), FinalUseError> {
        if authority_epoch == 0 || claims.len() > MAX_CLAIMS || claims.contains(&[0; 32]) {
            return Err(FinalUseError::InvalidTrust);
        }
        let mut file = open_private(&self.root, "authority.claims.next", Access::Create)?;
        file.set_len(0).map_err(|_| FinalUseError::Unavailable)?;
        for nonce in claims {
            if *nonce == [0; 32] {
                return Err(FinalUseError::InvalidTrust);
            }
            file.write_all(&authority_epoch.to_be_bytes())
                .and_then(|()| file.write_all(nonce))
                .map_err(|_| FinalUseError::Unavailable)?;
        }
        file.sync_all().map_err(|_| FinalUseError::Unavailable)?;
        replace_claims(&self.root, &file)?;
        self.root.sync_all().map_err(|_| FinalUseError::Unavailable)
    }
}

#[path = "final_use_store_io.rs"]
mod io;
use io::Access;
use io::entry_exists;
use io::open_private;
use io::read_bounded;
use io::replace_claims;
use io::replace_state;

#[cfg(all(test, unix))]
#[path = "final_use_store_tests.rs"]
mod tests;
