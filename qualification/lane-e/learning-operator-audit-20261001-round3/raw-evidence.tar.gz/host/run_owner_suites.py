import datetime, hashlib, json, os, pathlib, subprocess, time
root = pathlib.Path('/workspace/scratch/99c8d2276f89/hepta-private-ci')
out = pathlib.Path('/workspace/scratch/99c8d2276f89/round3-validation')
env = dict(os.environ)
env.update({
 'PATH': '/workspace/scratch/99c8d2276f89/tooling/native/usr/bin:/workspace/scratch/99c8d2276f89/tooling/bin:/workspace/scratch/99c8d2276f89/toolchain/cargo/bin:' + env['PATH'],
 'LD_LIBRARY_PATH': '/workspace/scratch/99c8d2276f89/tooling/native/usr/lib/x86_64-linux-gnu',
 'RUSTUP_HOME': '/tmp/hepta-round3-rustup',
 'CARGO_HOME': '/tmp/hepta-round3-cargo',
 'CARGO_TARGET_DIR': '/tmp/hepta-operator-round3-target',
 'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0',
 'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
 'OPENSSL_LIB_DIR': '/usr/lib/x86_64-linux-gnu', 'OPENSSL_INCLUDE_DIR': '/usr/include',
 'RUST_BACKTRACE': '1',
 'PKG_CONFIG': '/workspace/scratch/99c8d2276f89/tooling/native/usr/bin/pkgconf',
})
for line in (out / 'v8.env').read_text().splitlines():
 key, value = line.split('=', 1)
 assert key in {'RUSTY_V8_ARCHIVE', 'RUSTY_V8_SRC_BINDING_PATH'}
 assert pathlib.Path(value).is_file()
 env[key] = value

def inventory():
 files = [p for p in (root/'codex-rs').rglob('*') if p.is_file() and p.suffix in {'.rs', '.toml', '.lock'} and 'target' not in p.parts and '.git' not in p.parts]
 files.extend([root/'justfile',root/'scripts/run-nextest.py',root/'scripts/just-shell.py',root/'scripts/hepta_ci_v8.py'])
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}

base = ['just', 'test', '--locked', '-p', 'codex-hepta-agentd']
serial = ['--test-threads=1', '--no-tests=fail']
stages = [
 ('operator-default', ['just', 'test', '--locked', '-p', 'codex-hepta-bellman-operator']),
 ('operator-compatibility', ['just', 'test', '--locked', '-p', 'codex-hepta-bellman-operator', '--features', 'qualification-unverified-input']),
 ('terminal-cell-owner', base + ['--test', 'terminal_cell_owner']),
 ('operator-owner-ports', base + ['--lib', 'learning_operator_'] + serial),
 ('cognitive-ranker', base + ['--lib', 'cognitive_ranker'] + serial),
 ('sealed-product-evaluation', base + ['--lib', 'intelligence_product::evaluation_tests'] + serial),
 ('plasticity-runtime', base + ['--lib', 'plasticity_runtime::'] + serial),
 ('plasticity-process-bootstrap', base + ['--lib', 'plasticity_process_bootstrap::'] + serial),
 ('plasticity-process-e2e', base + ['--features', 'qualification-cognitive-write', '--test', 'plasticity_process_e2e'] + serial),
 ('cross-owner-libraries', ['just', 'test', '--locked', '-p', 'codex-hepta-contracts', '-p', 'codex-hepta-types', '-p', 'codex-hepta-learning-ledger', '-p', 'codex-hepta-learning-artifacts', '-p', 'codex-hepta-intelligence-eval', '-p', 'codex-hepta-intelligence', '--lib']),
 ('canonical-json-feature-unification', ['just', 'test', '--locked', '-p', 'codex-hepta-contracts', '--lib', 'learning_operator_protocol::tests', '--features', 'serde_json/preserve_order,serde_json/arbitrary_precision,serde_json/raw_value', '--test-threads=1']),
 ('external-api-consumers', ['python3', '../scripts/hepta-learning-operator-api-surface.py']),
 ('operator-default-strict-clippy', ['cargo', 'clippy', '--locked', '-p', 'codex-hepta-bellman-operator', '--all-targets', '--', '-D', 'warnings']),
 ('operator-compat-strict-clippy', ['cargo', 'clippy', '--locked', '-p', 'codex-hepta-bellman-operator', '--all-targets', '--features', 'qualification-unverified-input', '--', '-D', 'warnings']),
 ('scoped-just-fix', ['just', 'fix', '--locked', '-p', 'codex-hepta-bellman-operator', '-p', 'codex-hepta-agentd']),
]
before = inventory()
(out/'agentd-suites-source-before.json').write_text(json.dumps(before, indent=2)+'\n')
manifest = {'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceFileCount':len(before),'priorPassedChecksArchive':'operator-import-failure-attempt/agentd-suites.json', 'stages':[]}
for name, command in stages:
 started = datetime.datetime.now(datetime.timezone.utc).isoformat()
 begin = time.monotonic()
 log = out/(name+'.log')
 print('START', name, ' '.join(command), flush=True)
 with log.open('wb') as sink:
  process = subprocess.run(command, cwd=root/'codex-rs', env=env, stdout=sink, stderr=subprocess.STDOUT)
 after = inventory()
 delta = sorted(k for k in set(before)|set(after) if before.get(k)!=after.get(k))
 record = {'name':name,'command':command,'cwd':str(root/'codex-rs'),'startedAt':started,
  'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':time.monotonic()-begin,
  'exitCode':process.returncode,'log':str(log),'logSha256':hashlib.sha256(log.read_bytes()).hexdigest(),
  'sourceChangedPaths':delta}
 manifest['stages'].append(record)
 (out/'agentd-suites.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('FINISH',name,'exit',process.returncode,'seconds',round(record['elapsedSeconds'],2),'changed',len(delta),flush=True)
 print('\n'.join(log.read_text(errors='replace').splitlines()[-18:]),flush=True)
 if delta or process.returncode not in (0,100):
  print('STOP: source mutation or non-test execution failure',flush=True)
  break
(out/'agentd-suites-source-after.json').write_text(json.dumps(inventory(),indent=2)+'\n')
