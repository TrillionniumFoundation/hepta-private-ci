import json
import pathlib
import runpy
import sys

root = pathlib.Path('/workspace/scratch/99c8d2276f89/hepta-private-ci')
sys.path.insert(0, str(root / 'scripts'))
path = root / 'docs/modules/learning.operator/IMPLEMENTATION_MAP.json'
row = json.loads(path.read_text())
base = 'codex-rs/hepta-bellman-operator/src/'
extra = {
    'issue_tabular_final_use_capability_v1': (
        [base + 'final_use_preflight.rs::tabular'],
        [base + 'owner_issuance_resource_tests.rs::tabular_tiny_byte_budget_rejects_before_invalid_observer_signature'],
    ),
    'issue_world_model_final_use_capability_v1': (
        [base + 'final_use_preflight.rs::world'],
        [base + 'owner_issuance_resource_tests.rs::world_tiny_operation_budget_rejects_before_invalid_observer_signature'],
    ),
    'fit_tabular_final_use_v1': (
        [base + 'final_use_clock.rs::FinalUseClockV1', base + 'final_use_release.rs::FinalUseCandidateReleaseV1::finish'],
        [base + 'owner_forward_clock_tests.rs::tabular_forward_clock_jump_cannot_publish_after_root_distribution_expiry',
         base + 'owner_candidate_release_tests.rs::tabular_outer_release_revalidates_root_and_signed_row_evidence',
         base + 'owner_candidate_release_tests.rs::healthy_outer_handoff_records_the_actual_release_time'],
    ),
    'fit_world_model_final_use_v1': (
        [base + 'final_use_clock.rs::FinalUseClockV1', base + 'final_use_release.rs::FinalUseCandidateReleaseV1::finish'],
        [base + 'owner_forward_clock_tests.rs::world_forward_clock_jump_cannot_publish_after_model_retention',
         base + 'owner_candidate_release_tests.rs::world_outer_release_revalidates_model_retention_after_inner_fit'],
    ),
}
clock_tests = [base + 'final_use_clock_tests.rs::' + name for name in [
    'forward_host_floor_advances_during_fit_instead_of_freezing_at_the_jump',
    'latest_supplied_witness_anchors_the_entire_synchronous_call',
    'frozen_and_equal_floors_preserve_every_elapsed_microsecond',
    'elapsed_regression_and_unix_time_overflow_fail_closed',
    'rebased_release_deadline_is_exclusive_and_cancellation_still_wins',
]]
ranker_tests = ['codex-rs/hepta-agentd/src/cognitive_ranker_evaluated_tests.rs::' + name for name in [
    'evaluated_rank_rechecks_real_current_head_expiry_and_known_signer_revocation',
    'evaluated_rank_restores_exact_input_when_the_guard_expires_after_reordering',
    'evaluated_rank_enforces_elapsed_time_when_the_host_sample_stays_frozen',
    'evaluated_rank_restores_input_when_root_expires_during_consumption',
    'evaluated_rank_rejects_oversized_owned_content_without_copying_or_mutating_it',
    'evaluated_rank_enforces_known_root_revocation_with_a_frozen_host_clock',
]]
old_boundary = dict(row['claimBoundary'])
for operation in row['operations']:
    name = operation['operation']
    if name in extra:
        delegates, tests = extra[name]
        for delegate in delegates:
            source, symbol = delegate.split('::', 1)
            entry = {'path': source, 'symbol': symbol}
            if entry not in operation['delegatedCallees']:
                operation['delegatedCallees'].append(entry)
        operation['tests'] = list(dict.fromkeys(operation['tests'] + tests + (clock_tests if name.startswith('fit_') else [])))
        if name.startswith('fit_'):
            operation['state'] = 'pre_post_fit_and_actual_outer_release_currentness_implemented'
    if name == 'construct_ranker_admission_snapshot_v2':
        operation['tests'] = ranker_tests
        operation['delegatedCallees'] = [{'path': 'codex-rs/hepta-agentd/src/cognitive_ranker.rs', 'symbol': 'PinnedCognitiveRanker::rank'}]
        operation['state'] = 'opaque_root_admitted_current_head_final_use_and_transactional_ordering_implemented'
row['sourceObjects'] = runpy.run_path(str(root / 'scripts/hepta-implementation-maps.py'))['current_source_objects'](row)
assert row['claimBoundary'] == old_boundary
path.write_text(json.dumps(row, indent=2, ensure_ascii=False) + '\n')
print('Preserved completion flags; linked 12 core and 6 ranker regressions')
