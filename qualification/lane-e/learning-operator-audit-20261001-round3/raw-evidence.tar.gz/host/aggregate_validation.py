"""Summarize original execution records without renewing their source identity."""
import hashlib
import json
import pathlib
import re

workspace = pathlib.Path('/workspace/scratch/99c8d2276f89')
out = workspace / 'round3-validation'
destination = workspace / 'hepta-private-ci/qualification/lane-e/learning-operator-audit-20261001-round3'
destination.mkdir(parents=True, exist_ok=True)
records = []
for relative in [
    'controlled-pause-attempt/agentd-suites.json',
    'operator-import-failure-attempt/agentd-suites.json',
    'first-owner-batch-attempt/agentd-suites.json',
    'agentd-suites.json',
]:
    path = out / relative
    manifest = json.loads(path.read_text())
    for stage in manifest['stages']:
        record = dict(stage)
        record['originalManifestMember'] = 'host/' + relative
        record['originalManifestSha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        record['atRunSourceHead'] = manifest.get('sourceHead')
        record['atRunSourceHeadMissing'] = 'sourceHead' not in manifest
        original_log = pathlib.Path(stage['log'])
        copied_log = path.parent / original_log.name
        actual_log = copied_log if copied_log.is_file() else original_log
        data = actual_log.read_bytes()
        assert hashlib.sha256(data).hexdigest() == stage['logSha256'], (relative, stage['name'])
        record['rawLogMember'] = 'host/' + str(actual_log.relative_to(out))
        text = data.decode(errors='replace')
        if stage['exitCode'] == 0:
            delta = stage['sourceChangedPaths']
            if not delta:
                record['status'] = 'passed'
            elif delta == ['codex-rs/.round3-validation-pause.toml']:
                record['status'] = 'passed-with-control-artifact-delta'
            else:
                record['status'] = 'passed-with-source-delta'
        elif 'Operation not permitted' in text and 'bind agentd control socket' in text:
            record['status'] = 'environment-blocked'
        else:
            record['status'] = 'failed-attempt'
        match = re.search(r'Summary.*? (\d+) tests run: (\d+) passed(?:, (\d+) failed)?(?:, (\d+) skipped)?', text)
        if match:
            record['observedTests'] = {'run': int(match[1]), 'passed': int(match[2]), 'failed': int(match[3] or 0), 'skippedOrFiltered': int(match[4] or 0)}
        if stage['name'] == 'external-api-consumers' and stage['exitCode'] == 0:
            api = json.loads(text.splitlines()[-1])
            record['observedApiConsumers'] = {'count': len(api['results']), 'passed': api['passed'], 'positive': 3, 'compileFail': 16}
        records.append(record)
controls = []
for relative in ['root-control-validation.json', 'final-navigation-validation.json', 'resolved-anchor-validation.json', 'postfix-navigation-validation.json']:
    path = out / relative
    controls.append({'member': 'host/' + relative, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'original': json.loads(path.read_text())})
summary = {
    'schema': 'hepta.learning-operator-local-audit-round3.v1',
    'module': 'learning.operator',
    'baselineRemoteSha': '38b9ec0a6a37c389ba5ca478f520967098a30fd7',
    'latestMainObserved': '997e7beef8151160065df36b024bc8da5c989e93',
    'coreSourceCheckpoint': {'sha': 'a180997d54925a77d7720246adb558224a11d318', 'tree': 'b6b33bea1ef48394d757b2482c51f21040ff750b'},
    'terminalFixtureCheckpoint': {'sha': 'f6a6e497c00807da4444fde00a74c7d111bf4f8c', 'tree': 'a24c9f580215b46454620234a72501abf75c24fb'},
    'mechanicalFixCheckpoint': {'sha': '177bd36d4feac6d84a5ba0c3f9e6daec52a6d390', 'tree': 'da20391fe414c7ffaae4f12711c152a117d10afb'},
    'finalNavigationCheckpoint': {'sha': 'd46c0e624889bd69c937d6a9c0f66fcf58e28b05', 'tree': '00a4ab3b910e9c09d9314a4eb890623c51fd04d0'},
    'toolchain': {'rust': '1.95.0', 'just': '1.51.0', 'nextest': '0.9.103', 'debugInfo': False, 'incremental': False},
    'rawEvidenceArchive': 'raw-evidence.tar.gz',
    'rawEvidenceIndex': 'evidence-index.json',
    'observations': records,
    'controlObservations': controls,
    'engineeringQualified': False,
    'defaultLoopWired': False,
    'independentScientificAcceptance': False,
    'targetHostCapacityAccepted': False,
    'activation': False,
    'release': False,
    'hostedFinalHeadCi': 'pending at publication; observe linked GitHub runs separately',
    'claimBoundary': 'Actual scoped builds/tests/lint and source navigation only. Initial host batch retained a non-Cargo imported controlled-pause marker; final resumed batch explicitly checked its absence. Raw failures, source hashes and original source-head gaps are not rewritten. Unix socket tests remain required and environment-blocked locally. Historical counts, performance and science receipts are not transferred. Global strict qualification remains blocked by nine inherited nonancestor provenance anchors.',
}
(destination / 'validation.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'observations': len(records), 'controlGroups': len(controls)}))
