#!/usr/bin/env python3
"""Lane E entrypoint: preserved contract checks plus blob-bound writer audit.

The closed-world verifier is retained as hepta_lane_e_contract.py, including
operator supplemental inventory and truthful integration work. This entrypoint
replaces only its writer audit; no contract finding is filtered or converted
into a success.
"""

from __future__ import annotations

import argparse
<<<<<<< /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/1-2
import hashlib
=======
import importlib.util
>>>>>>> /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/2-2
import json
import re
import tempfile
import tomllib
from pathlib import Path

import hepta_lane_e_contract as contract

ROOT = Path(__file__).resolve().parents[1]
<<<<<<< /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/1-2
EXCEPTIONS = "qualification/lane-e/LEGACY_WRITER_EXCEPTIONS.json"
FEATURE = "qualification-legacy-learning-write"
MANIFEST = "codex-rs/hepta-agentd/Cargo.toml"
FORBIDDEN = {
    r"\bDurableLearningJournal\b": "legacy durable journal trait",
    r"\bLedgerEvent\s*::\s*Decision\b": "raw V1 Decision append",
    r"\bLedgerEvent\s*::\s*Outcome\b": "raw V1 Outcome append",
    r"\bLedgerEvent\s*::\s*Credit\b": "raw V1 Credit append",
    r"\bLedgerEvent\s*::\s*Revocation\b": "raw V1 Revocation append",
}
# Preserve the established import surface for Lane E behavior regressions.
Findings = contract.Findings
MATRIX_PATH = contract.MATRIX_PATH
verify_matrix = contract.verify_matrix
=======
MATRIX_PATH = ROOT / "docs/lane-e/LANE_E_IMPLEMENTATION_MATRIX.json"
TRACE_PATH = ROOT / "qualification/lane-e/TEST_TRACEABILITY.json"
WORKFLOW_PATH = ROOT / ".github/workflows/hepta-lane-e-gap-closure.yml"
PRODUCTION_CONTRACT_PATH = (
    ROOT / "codex-rs/hepta-intelligence-eval/PRODUCTION_CONTRACT.md"
)
EVIDENCE_SCRIPT_PATH = ROOT / "scripts/hepta-learning-eval-evidence.py"
TEMPORARY_WORKFLOW_PATH = (
    ROOT / ".github/workflows/hepta-lane-e-materialize-generated.yml"
)

EXPECTED_MODULES = {
    "learning.ledger",
    "learning.operator",
    "learning.eval",
    "learning.artifacts",
}
EXPECTED_EXTERNAL_GATES = {f"RDY-EXT-{index:03d}" for index in range(1, 10)}
EXPECTED_CRATES = {
    "codex-hepta-learning-ledger",
    "codex-hepta-learning-artifacts",
    "codex-hepta-bellman-operator",
    "codex-hepta-intelligence-eval",
    "codex-hepta-intelligence",
    "codex-hepta-shadow-qualification",
}


# Reuse the repository's bounded lexical inventory for API navigation. Actual
# Rust compilation and signed/holdout regressions remain qualification gates.
_SOURCE_SPEC = importlib.util.spec_from_file_location(
    "lane_e_source_inventory", ROOT / "scripts/hepta-implementation-maps.py"
)
assert _SOURCE_SPEC is not None and _SOURCE_SPEC.loader is not None
_SOURCE_INVENTORY = importlib.util.module_from_spec(_SOURCE_SPEC)
_SOURCE_SPEC.loader.exec_module(_SOURCE_INVENTORY)


def unsigned_root_exports(source: str) -> set[str]:
    # Use-tree braces group imported names, not nested item scopes. Preserve
    # their tokens before the shared inventory masks actual nested modules.
    source = re.sub(
        r"\bpub\s+use\s+[^;]+;",
        lambda match: match.group().replace("{", " ").replace("}", " "),
        source,
    )
    source = _SOURCE_INVENTORY.top_level_rust_source(source)
    forbidden = {
        "evaluate",
        "decide_independently",
        "decide_independently_v2",
        "decide_with_signed_evidence_v1",
    }
    declarations = re.findall(
        r"\bpub\s+(?:(?:async|const|unsafe)\s+)*fn\s+(\w+)\b", source
    )
    exposed = forbidden.intersection(declarations)
    for declaration in re.findall(r"\bpub\s+use\s+([^;]+);", source):
        exposed.update(forbidden.intersection(re.findall(r"\b\w+\b", declaration)))
        if "*" in declaration and re.search(
            r"\b(?:closure|metric_roles)\b", declaration
        ):
            exposed.add("unsigned_wildcard")
    return exposed


@dataclass(frozen=True)
class Finding:
    code: str
    message: str
>>>>>>> /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/2-2


def blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def isolated_feature(manifest: str) -> bool:
    """Resolve the default feature closure, including dependency forwarding."""
    try:
        features = tomllib.loads(manifest).get("features", {})
        if not isinstance(features, dict) or FEATURE not in features:
            return False
        todo, seen = ["default"], set()
        while todo:
            value = todo.pop()
            if value in seen:
                continue
            seen.add(value)
            if value.split("/")[-1] in {FEATURE, "qualification-legacy-write"}:
                return False
            edges = features.get(value, [])
            if not isinstance(edges, list) or not all(
                isinstance(x, str) for x in edges
            ):
                return False
            todo.extend(edges)
        return True
    except (tomllib.TOMLDecodeError, TypeError):
        return False


def verify_product_writer_exclusivity(findings, root: Path | None = None) -> None:
    if root is None:
        root = ROOT
    try:
        document = json.loads((root / EXCEPTIONS).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        findings.add("legacy_writer_exception_document", str(error))
        return
    if not isinstance(document, dict):
        findings.add("legacy_writer_exception_schema", "writer audit must be an object")
        return
    findings.require(
        document.get("schema") == "hepta.lane-e-legacy-writer-exceptions.v2",
        "legacy_writer_exception_schema",
        "expected blob-bound writer audit v2",
    )
    findings.require(
        document.get("authorityDelta") == "none",
        "authority_delta",
        "writer exceptions cannot grant authority",
    )
    pins = document.get("reviewedBlobs", {})
    records = document.get("exceptions", [])
    if not isinstance(pins, dict) or not isinstance(records, list):
        findings.add(
            "legacy_writer_exception_records", "invalid pins or exception records"
        )
        return
    exceptions = {}
    for record in records:
        if not isinstance(record, dict):
            findings.add(
                "legacy_writer_exception_record", "exception must be an object"
            )
            continue
        path, description = record.get("path"), record.get("finding")
        if (
            not isinstance(path, str)
            or Path(path).is_absolute()
            or ".." in Path(path).parts
            or description not in FORBIDDEN.values()
            or record.get("classification")
            not in {"read_only_runstart_bridge", "qualification_feature_only"}
            or not record.get("owner")
            or not record.get("rationale")
        ):
            findings.add(
                "legacy_writer_exception_record", f"invalid audit record: {record!r}"
            )
            continue
        key = (path, description)
        if key in exceptions:
            findings.add("legacy_writer_exception_duplicate", repr(key))
        exceptions[key] = record
    expected_pins = {path for path, _ in exceptions} | {MANIFEST}
    findings.require(
        set(pins) == expected_pins,
        "legacy_writer_exception_pin_set",
        "audit must pin exactly the excepted source files and feature manifest",
    )
    for relative in sorted(expected_pins):
        try:
            data = (root / relative).read_bytes()
        except OSError:
            findings.add("legacy_writer_exception_source", relative)
            continue
<<<<<<< /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/1-2
        findings.require(
            blob_sha(data) == pins.get(relative),
            "legacy_writer_exception_source_drift",
            f"source changed; re-audit required: {relative}",
=======
        operations: dict[str, dict[str, Any]] = {}
        for operation in operations_raw:
            if not isinstance(operation, dict) or not isinstance(
                operation.get("operation"), str
            ):
                findings.add("invalid_operation", f"{module} has an invalid operation")
                continue
            name = operation["operation"]
            if not name.strip() or name in operations:
                findings.add(
                    "duplicate_or_empty_operation",
                    f"{module} has an invalid operation identity: {name!r}",
                )
                continue
            operations[name] = operation
        findings.require(
            bool(operations),
            "operations_missing",
            f"{module} has no registered source operations",
>>>>>>> /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/2-2
        )
    try:
        feature_ok = isolated_feature((root / MANIFEST).read_text(encoding="utf-8"))
    except OSError:
        feature_ok = False
    seen = set()
    allowed_roots = {
        "codex-rs/hepta-learning-ledger",
        "codex-rs/hepta-shadow-qualification",
    }
    for path in sorted((root / "codex-rs").rglob("*.rs")):
        relative = path.relative_to(root).as_posix()
        if any(relative.startswith(prefix + "/") for prefix in allowed_roots):
            continue
        if "/tests/" in relative or path.name.endswith(
            ("_tests.rs", "_test_support.rs")
        ):
            continue
        text = path.read_text(encoding="utf-8")
        for pattern, description in FORBIDDEN.items():
            if re.search(pattern, text) is None:
                continue
            key = (relative, description)
            record = exceptions.get(key)
            if record is None:
                findings.add(
                    "legacy_learning_writer_product_bypass",
                    f"{relative}: {description}",
                )
                continue
            seen.add(key)
            markers = record.get("requiredMarkers")
            findings.require(
                isinstance(markers, list)
                and bool(markers)
                and all(isinstance(x, str) and x in text for x in markers),
                "legacy_writer_exception_marker",
                repr(key),
            )
<<<<<<< /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/1-2
            if record["classification"] == "qualification_feature_only":
                findings.require(
                    feature_ok and f'#[cfg(feature = "{FEATURE}")]' in text,
                    "legacy_writer_exception_feature",
                    repr(key),
                )
            else:
                forbidden = record.get("forbiddenMarkers")
=======
        else:
            findings.add("cross_crate_source", "cross-crate test source is missing")
    return modules


def verify_traceability(
    trace: dict[str, Any], modules: dict[str, dict[str, Any]], findings: Findings
) -> None:
    findings.require(
        trace.get("schema") == "hepta.lane-e-test-traceability.v1",
        "trace_schema",
        "unexpected Lane E traceability schema",
    )
    cases_raw = trace.get("cases")
    if not isinstance(cases_raw, list):
        findings.add("trace_cases", "traceability cases must be an array")
        return
    cases: dict[str, dict[str, Any]] = {}
    for item in cases_raw:
        if not isinstance(item, dict) or not isinstance(item.get("id"), str):
            findings.add("invalid_case", "traceability contains an invalid case")
            continue
        case_id = item["id"]
        if case_id in cases:
            findings.add("duplicate_case", f"duplicate case: {case_id}")
            continue
        cases[case_id] = item
    findings.require(
        {case.get("module") for case in cases.values()} == set(modules),
        "case_module_coverage",
        "registered modules must each retain native behavioral traceability",
    )

    source_cache: dict[Path, str] = {}
    for case_id, case in cases.items():
        module = case.get("module")
        findings.require(
            module in modules,
            "case_module",
            f"{case_id} has invalid module {module!r}",
        )
        tests = case.get("tests")
        if not isinstance(tests, list) or not tests:
            findings.add("case_tests_missing", f"{case_id} has no mapped native tests")
            continue
        for index, test in enumerate(tests):
            context = f"{case_id}.tests[{index}]"
            if not isinstance(test, dict):
                findings.add("invalid_test_mapping", f"{context} is not an object")
                continue
            source_path = relative_path(
                test.get("source"), findings, f"{context}.source"
            )
            function = test.get("function")
            if source_path is None or not source_path.is_file():
                findings.add("test_source_missing", f"{context} source is missing")
                continue
            if not isinstance(function, str):
                findings.add("test_function_missing", f"{context} function is missing")
                continue
            source_text = source_cache.setdefault(
                source_path, source_path.read_text(encoding="utf-8")
            )
            findings.require(
                bool(re.search(rf"\bfn\s+{re.escape(function)}\s*\(", source_text)),
                "test_function_unresolved",
                f"{function} is absent from {source_path.relative_to(ROOT)}",
            )
        findings.require(
            case.get("status") == "native_test_mapped",
            "case_status",
            f"{case_id} is not marked native_test_mapped",
        )

    cross_raw = trace.get("crossCrateCases")
    findings.require(
        isinstance(cross_raw, list) and bool(cross_raw),
        "cross_case_count",
        "at least one Lane E cross-crate case is required",
    )
    if isinstance(cross_raw, list):
        for item in cross_raw:
            if not isinstance(item, dict):
                findings.add("invalid_cross_case", "invalid cross-crate case")
                continue
            source_path = relative_path(
                item.get("source"), findings, "crossCase.source"
            )
            function = item.get("function")
            if (
                source_path is not None
                and source_path.is_file()
                and isinstance(function, str)
            ):
                text = source_path.read_text(encoding="utf-8")
>>>>>>> /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/2-2
                findings.require(
                    isinstance(forbidden, list)
                    and bool(forbidden)
                    and all(isinstance(x, str) and x not in text for x in forbidden),
                    "legacy_writer_exception_write",
                    repr(key),
                )
    for key in sorted(set(exceptions) - seen):
        findings.add("legacy_writer_exception_stale", repr(key))

<<<<<<< /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/1-2

def run_self_test():
    findings = contract.Findings()
    findings.items.extend(contract.run_self_test())
    for variant in ("Decision", "Outcome", "Credit", "Revocation"):
        pattern = next(p for p in FORBIDDEN if variant in p)
        for separator in ("::", " :: "):
=======
    # Product-boundary tests are tracked separately from the Lane E causal
    # chain: they exercise a real non-Rust consumer and an injected fault.
    # Keeping this as an explicit trace prevents a passing unit test from being
    # mistaken for cross-language product evidence.
    boundary_raw = trace.get("productBoundaryCases")
    findings.require(
        isinstance(boundary_raw, list) and bool(boundary_raw),
        "product_boundary_case_count",
        "at least one product-boundary case is required",
    )
    if isinstance(boundary_raw, list):
        for item in boundary_raw:
            if not isinstance(item, dict):
                findings.add("invalid_boundary_case", "invalid product-boundary case")
                continue
            source_path = relative_path(
                item.get("source"), findings, "productBoundaryCase.source"
            )
            function = item.get("function")
            if source_path is None or not source_path.is_file():
                findings.add(
                    "boundary_source_missing", "product-boundary source is missing"
                )
                continue
>>>>>>> /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/2-2
            findings.require(
                re.search(pattern, f"LedgerEvent{separator}{variant}(value)")
                is not None,
                "self_test_writer_positive",
                variant,
            )
        findings.require(
            re.search(pattern, f"LedgerEvent::{variant}Digest(value)") is None,
            "self_test_writer_negative",
            variant,
        )
<<<<<<< /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/1-2
    manifest = (
        '[features]\ndefault=["product"]\nproduct=[]\n'
        + FEATURE
        + '=["ledger/qualification-legacy-write"]\n'
    )
    findings.require(
        isolated_feature(manifest),
        "self_test_feature_positive",
        "forwarded feature rejected",
    )
    findings.require(
        not isolated_feature(
            manifest.replace("product=[]", 'product=["' + FEATURE + '"]')
        ),
        "self_test_feature_negative",
        "transitive default bypass accepted",
    )
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        relative = "codex-rs/hepta-agentd/src/product.rs"
        text = (
            '#[cfg(feature = "'
            + FEATURE
            + '")]\nfn append_decision() { LedgerEvent::Decision(value); }\n'
=======
    if not all(path.is_file() for path in required):
        return

    lib = lib_path.read_text(encoding="utf-8")
    closure = closure_path.read_text(encoding="utf-8")
    metric = metric_path.read_text(encoding="utf-8")
    durable = durable_path.read_text(encoding="utf-8")
    cargo = cargo_path.read_text(encoding="utf-8")
    api_contract = api_contract_path.read_text(encoding="utf-8")
    production = PRODUCTION_CONTRACT_PATH.read_text(encoding="utf-8")
    evidence_script = EVIDENCE_SCRIPT_PATH.read_text(encoding="utf-8")

    for source, label in (
        (lib, "crate root"),
        (closure, "closure"),
        (metric, "metric roles"),
    ):
        exposed = unsigned_root_exports(source)
        findings.require(
            not exposed,
            "learning_eval_unsigned_public",
            f"{label} exposes unsigned default decision entrypoints: {sorted(exposed)}",
        )
    for token in (
        "trusted-inprocess-eval = []",
        "pub mod trusted_inprocess",
    ):
        findings.require(
            token in (cargo + "\n" + lib),
            "learning_eval_signed_surface",
            f"missing required production/compatibility surface token: {token}",
>>>>>>> /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/2-2
        )
        for name, content in ((relative, text), (MANIFEST, manifest)):
            file = root / name
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_text(content, encoding="utf-8")
        record = {
            "path": relative,
            "finding": "raw V1 Decision append",
            "owner": "fixture",
            "rationale": "isolated self-test only",
            "classification": "qualification_feature_only",
            "requiredMarkers": ["fn append_decision"],
        }
        document = {
            "schema": "hepta.lane-e-legacy-writer-exceptions.v2",
            "authorityDelta": "none",
            "reviewedBlobs": {
                relative: blob_sha(text.encode()),
                MANIFEST: blob_sha(manifest.encode()),
            },
            "exceptions": [record],
        }
        target = root / EXCEPTIONS
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(document), encoding="utf-8")
        checks = contract.Findings()
        verify_product_writer_exclusivity(checks, root)
        findings.require(
            not checks.items, "self_test_audit_positive", repr(checks.items)
        )
        (root / relative).write_text(text + "// changed\n", encoding="utf-8")
        checks = contract.Findings()
        verify_product_writer_exclusivity(checks, root)
        findings.require(
            any(x.code == "legacy_writer_exception_source_drift" for x in checks.items),
            "self_test_audit_drift",
            "changed audited blob accepted",
        )
        (root / relative).write_text("fn append_decision() {}\n", encoding="utf-8")
        checks = contract.Findings()
        verify_product_writer_exclusivity(checks, root)
        findings.require(
            any(x.code == "legacy_writer_exception_stale" for x in checks.items),
            "self_test_audit_stale",
            "stale audit accepted",
        )
        (root / relative).write_text(
            text + "\nLedgerEvent::Outcome(value);\n", encoding="utf-8"
        )
        checks = contract.Findings()
        verify_product_writer_exclusivity(checks, root)
        findings.require(
            any(
                x.code == "legacy_learning_writer_product_bypass" for x in checks.items
            ),
            "self_test_audit_new_writer",
            "unregistered writer accepted",
        )
<<<<<<< /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/1-2
=======
    findings.require(
        any(command[:2] == ["cargo", "fmt"] for command in commands),
        "workflow_gate_missing",
        "workflow is missing cargo fmt",
    )
    findings.require(
        any(
            command[:3] == ["python3", "scripts/hepta-lane-e-closure.py", "verify"]
            for command in commands
        ),
        "workflow_gate_missing",
        "workflow is missing source closure verification",
    )
    findings.require(
        any(
            "lane_e_causal_candidate_chain_is_digest_bound_and_deny_all" in command
            and any(
                command[index : index + 2] == ["-p", "codex-hepta-shadow-qualification"]
                for index in range(len(command) - 1)
            )
            for command in test_commands
        ),
        "workflow_gate_missing",
        "workflow is missing the cross-crate causal regression",
    )
    findings.require(
        any(
            "cross_language_wire_fault" in command
            and any(
                command[index : index + 2] == ["-p", "codex-hepta-shadow-qualification"]
                for index in range(len(command) - 1)
            )
            for command in test_commands
        ),
        "workflow_gate_missing",
        "workflow is missing the cross-language payload-fault regression",
    )
    findings.require(
        bool(re.search(r"^  synthetic-merge:\s*$", text, re.MULTILINE)),
        "workflow_gate_missing",
        "workflow is missing synthetic-merge job",
    )
    for token, message in (
        (
            "learning-eval-qualification:",
            "workflow is missing learning-eval qualification job",
        ),
        (
            "cargo-llvm-cov@0.9.1",
            "workflow is missing pinned learning-eval coverage tooling",
        ),
        ("fenced_holdout", "workflow is missing fenced holdout stress execution"),
        (
            "qualification.json",
            "workflow is missing commit-addressed qualification manifest",
        ),
        (
            "actions/attest-build-provenance@0f67c3f4856b2e3261c31976d6725780e5e4c373",
            "workflow is missing pinned provenance attestation",
        ),
        (
            "actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02",
            "workflow is missing retained qualification artifact",
        ),
        (
            "trusted-inprocess-eval",
            "workflow is missing explicit compatibility-surface verification",
        ),
        (
            "--test operator_claim",
            "workflow is missing the trusted compatibility regression",
        ),
        (
            "evaluated_shadow",
            "workflow is missing terminal product-receipt consumer execution",
        ),
        (
            "--fail-under-lines 85",
            "workflow is missing enforced evaluator coverage floor",
        ),
    ):
        findings.require(
            token in text,
            "workflow_gate_missing",
            message,
        )
    findings.require(
        "signed_qualification_e2e" in text
        and "--features trusted-inprocess-eval" in text,
        "learning_eval_workflow_tests",
        "workflow must execute signed E2E and explicit trusted compatibility tests",
    )
    for token in (
        "scripts/hepta-learning-eval-evidence.py emit",
        "scripts/hepta-learning-eval-evidence.py verify",
        "actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02",
        "actions/attest-build-provenance@4d101475d8b20a2381f78447822ac1eab6504dd8",
        "id-token: write",
        "attestations: write",
        "cargo-llvm-cov@0.9.0",
        "--fail-under-lines 85",
        "Adversarial qualification stress",
        "evaluated_shadow",
        "Strict merged Lane E lint",
        "--coverage .hepta-evidence/learning-eval/coverage.json",
        "--stress .hepta-evidence/learning-eval/stress.json",
        "--stress-log .hepta-evidence/learning-eval/stress.log",
        "--runtime-log .hepta-evidence/learning-eval/runtime-e2e.log",
        "github.event.before",
    ):
        findings.require(
            token in text,
            "learning_eval_workflow_evidence",
            f"workflow is missing qualification evidence control: {token}",
        )
    findings.require(
        not TEMPORARY_WORKFLOW_PATH.exists(),
        "temporary_workflow_present",
        "temporary generated-file materializer must not remain in the candidate",
    )


def run_self_test() -> list[Finding]:
    findings = Findings()
    findings.require(
        verify_symbol(
            "pub struct Demo; impl Demo { pub fn execute(&self) {} }",
            "crate::Demo::execute",
        ),
        "self_test_method",
        "method symbol resolver failed",
    )
    findings.require(
        verify_symbol("pub fn execute() {}", "crate::execute"),
        "self_test_function",
        "free-function symbol resolver failed",
    )
    findings.require(
        not verify_symbol("pub fn another() {}", "crate::execute"),
        "self_test_false_positive",
        "symbol resolver accepted a missing function",
    )
>>>>>>> /workspace/scratch/99c8d2276f89/round3-ci/merge-preview/2-2
    return findings.items


def verify():
    findings = contract.Findings()
    matrix = contract.load_json(contract.MATRIX_PATH, findings)
    trace = contract.load_json(contract.TRACE_PATH, findings)
    modules = contract.verify_matrix(matrix, findings)
    contract.verify_traceability(trace, modules, findings)
    contract.verify_learning_eval_production_boundary(findings)
    verify_product_writer_exclusivity(findings)
    contract.verify_authority_posture(findings)
    contract.verify_workflow(findings)
    for relative in (
        ".github/workflows/learning-operator-p0-materialize.yml",
        "scripts/learning-operator-p0-materialize.py",
        ".github/workflows/learning-operator-writer-verifier-fix.yml",
    ):
        findings.require(
            not (ROOT / relative).exists(), "temporary_workflow_present", relative
        )
    return findings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "command", choices=("verify", "self-test"), nargs="?", default="verify"
    )
    args = parser.parse_args()
    if args.command == "self-test":
        findings = run_self_test()
        integration_work = {}
    else:
        result = verify()
        findings = result.items
        integration_work = result.integration_work
    print(
        json.dumps(
            {
                "schema": "hepta.lane-e-closure-verification.v1",
                "command": args.command,
                "ok": not findings,
                "findingCount": len(findings),
                "findings": [x.__dict__ for x in findings],
                "remainingIntegrationWork": integration_work,
                "repositoryIntegrationComplete": (
                    args.command == "verify"
                    and not findings
                    and not any(integration_work.values())
                ),
            },
            indent=2,
            sort_keys=True,
        )
    )
    return int(bool(findings))


if __name__ == "__main__":
    raise SystemExit(main())

