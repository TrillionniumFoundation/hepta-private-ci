from pathlib import Path
import hashlib
import importlib.util
import json
import resource
import subprocess
import sys
import time
import tomllib

ROOT = Path('/workspace/scratch/ff41dfc0f7bf/hepta-current-history-guards-cloud')
OUT = Path('/workspace/scratch/ff41dfc0f7bf/local-validation/current-history-guards-fae79880')
OUT.mkdir(parents=True, exist_ok=True)
resource.setrlimit(resource.RLIMIT_AS, (1024 * 1024 * 1024,) * 2)
started = time.time()
git = lambda *args: subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()
head, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
assert head == 'fae798807b888d48f38b5e1a667309598e04d8a7'
assert not git('status', '--porcelain')
spec = importlib.util.spec_from_file_location('current_history_full_index', ROOT/'scripts/verify_hepta_callers.py')
v = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = v
spec.loader.exec_module(v)
m = tomllib.loads((ROOT/'CALLERS.toml').read_text())
paths = {
 'codex-rs/hepta-agentd/src/authority_host_publication_'+suffix+'.rs' for suffix in (
 'acceptance', 'completed_refusal', 'completed', 'completed_open', 'completed_next_use',
 'completed_files', 'completed_successor', 'deployment_inputs')
}
paths.update(('codex-rs/hepta-agentd/src/authority_host_completed_publication_deployment.rs',
              'codex-rs/hepta-neuron/src/cell_generation_feature_observer.rs'))
boundaries = v._boundary_rows(m)
selected = [b for b in boundaries if b.definition_path in paths or any(p in paths for p in b.product_callers)]
files = v._source_files(ROOT, tuple(m['source_roots']))
def fingerprint():
    h = hashlib.sha256()
    for path in files:
        h.update(path.relative_to(ROOT).as_posix().encode()+b'\0')
        h.update(hashlib.sha256(path.read_bytes()).digest())
    return h.hexdigest()
before = fingerprint()
index = {p.relative_to(ROOT).as_posix(): v._strip_cfg_test_items(v._strip_rust_non_code(p.read_text())) for p in files}
print(json.dumps({'head':head,'tree':tree,'rust_files':len(files),'selected_boundaries':len(selected),'source_before':before}), flush=True)
rows, failures = [], []
fields = {}
for boundary in selected:
    try:
        row = v._verify_boundary(ROOT, boundary, index, tuple(m['ignored_path_fragments']), fields_by_receiver_type=fields)
        rows.append(row)
        print('PASS '+boundary.identifier, flush=True)
    except v.VerificationFailure as e:
        failures.append({'boundary':boundary.identifier,'error':str(e)})
        print('FAIL '+boundary.identifier+': '+str(e), flush=True)
protected = v._verify_protected_files(ROOT, {'protected_file':[r for r in m['protected_file'] if r['path'] in paths]})
after = fingerprint()
clean = not git('status','--porcelain') and git('rev-parse','HEAD') == head
result = {'schema':'current-history-selected-closure.v1','scope':'selected boundaries over full Rust source index, not the full caller CLI and not native',
 'head':head,'tree':tree,'rust_files':len(files),'selected_boundaries':len(selected),'passed_boundaries':len(rows),'failures':failures,
 'protected_rows':len(protected),'source_before':before,'source_after':after,'source_unchanged':clean and before==after,
 'duration_seconds':time.time()-started,'address_space_limit_bytes':1024*1024*1024,'authority_granted':False}
result['exit_code'] = 0 if not failures and result['source_unchanged'] else 1
(OUT/'selected-callers.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result), flush=True)
sys.exit(result['exit_code'])
