import os,hashlib,pathlib,json
base=pathlib.Path('/home/qq/work/hepta-e16-ac5459-20261121/e6-lifecycle-successor-v1')
pins={'dispatch_lifecycle.py':'51dd8925c9c384b6c7fa0beebce3162741c832eae39d37cc52ae311d09e1030b','run_lifecycle.py':'1496bea8180126b6e905b04ec2ba1e92f23f10a2fa529010ec194357b73ebeea','lifecycle_binding.py':'f3fce6f8d439c871c53c08bf1487f6839fa3b56bf1bc6a45750b669cd990e898','successor_binding.py':'14eeb80d87bdbdae0295191ec7275f30fd56257635a5ed17b219551e2a5bd9ab','REVIEW_MANIFEST.json':'9fa4a9db58269942cf8c0fabb10a1d1518549fcc52e21f3fdad615bac3aeff5a','LIFECYCLE_PROTOCOL.json':'fb390d8316e63f26126c2852b518901aeb9d4660a89ff0eec83d2aa032343224','DEPLOYMENT.json':'34ccfb508487b93aa90fa21b50a48248c77a3e749f208ca07b673294c73e72dc'}
assert os.getuid()==os.geteuid()==os.getgid()==1000
for name,expected in pins.items():
 path=base/name;assert not path.is_symlink() and path.resolve()==path
 assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,name
assert not os.path.lexists(base/'DISPATCH_STARTED.json') and not os.path.lexists(base/'complete-lifecycle-v1')
os.chdir(base)
os.execv('/usr/bin/python3',['/usr/bin/python3','-B',str(base/'dispatch_lifecycle.py')])
