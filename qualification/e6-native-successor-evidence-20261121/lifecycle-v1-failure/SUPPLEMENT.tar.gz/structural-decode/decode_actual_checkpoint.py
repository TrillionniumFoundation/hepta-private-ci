"""Read-only structural decoding of the retained fixture record using its pinned Rust codec.
No owner/authorization is constructed; this does not re-run Rust verification or training.
"""
from pathlib import Path
import base64,hashlib,json,datetime
HERE=Path(__file__).resolve().parent
path=next((HERE/'forensics/actual-checkpoint').glob('*.json'))
raw=path.read_bytes();outer=json.loads(raw)
assert outer['schema']==1 and outer['owner_id']=='root-learning-checkpoint-v1'
assert outer['frontier']['schema']==2
encoded=outer['frontier']['snapshot'];data=base64.b64decode(encoded+'='*((-len(encoded))%4),validate=True)
assert base64.b64encode(data).decode().rstrip('=')==encoded
assert len(data)<=8192
class Reader:
 def __init__(self,b):self.b=b;self.i=0
 def take(self,n):
  out=self.b[self.i:self.i+n];assert len(out)==n;self.i+=n;return out
 def integer(self,n):return int.from_bytes(self.take(n),'big')
 def u8(self):return self.integer(1)
 def digest(self):return self.take(32).hex()
 def identifier(self):
  n=self.u8();assert 1<=n<=128
  text=self.take(n).decode('utf-8');return text
 def optional_digest(self):
  tag=self.u8();assert tag in (0,1);return self.digest() if tag else None
 def bundle(self):
  start=self.i;out={'artifact_id':self.identifier(),'generation':self.integer(8)}
  assert out['generation']>0
  names=['base','heads','composition','encoder','tokenizer','normalizer','calibration','numeric_profile','output_schema','state_schema','state_semantics']
  out['components']={name:self.digest() for name in names}
  out['components'].update(organ_adapter=self.optional_digest(),cell_adapter=self.optional_digest())
  out['rollback_predecessor']=self.optional_digest();tag=self.u8();assert tag in (0,1)
  out['training_lineage']={name:self.digest() for name in ['source_bundle','dataset','update_rule','evaluation_profile']} if tag else None
  out['encoded_byte_span']=[start,self.i];return out
r=Reader(data);magic=r.take(8).decode();assert magic=='HEPLCP02'
request={name:r.identifier() for name in ['operation_id','principal_id','agent_id','cell_id','source_run_id']}
request.update({name:r.digest() for name in ['completed_task_receipt','selected_artifact_digest','evaluation_profile']})
request['selected_bundle']=r.bundle()
envelope={'envelope_id':r.identifier()};envelope.update({name:r.digest() for name in ['base_commit','base_tree','objective_digest','grammar_digest']})
envelope.update(maximum_files=r.integer(2),maximum_diff_bytes=r.integer(8),maximum_candidates=r.integer(2),maximum_parallel_sandboxes=r.u8(),expiry_unix_seconds=r.integer(8))
request['envelope']=envelope
request['budget']={'maximum_dataset_rows':r.integer(4),**{name:r.integer(8) for name in ['maximum_dataset_bytes','maximum_training_steps','maximum_training_milliseconds','maximum_artifact_bytes']}}
owners={'evidence_trust_digest':r.digest(),**{name:r.identifier() for name in ['experience','dataset','trainer','evaluator','proposal','selector','next_use_observer']}}
count=r.u8();assert count<=7
receipts=[]
for index in range(count):
 start=r.i;row={'operation_id':r.identifier(),'predecessor':r.digest(),'actor_id':r.identifier(),'evidence_digest':r.digest(),'observed_unix_seconds':r.integer(8)}
 tag=r.u8()
 if tag==0:ob={'variant':'Experience','episode_digest':r.digest(),'completed_task_receipt':r.digest()}
 elif tag==1:ob={'variant':'Dataset','snapshot_digest':r.digest(),'episode_digest':r.digest(),'withdrawal_frontier':r.digest(),'rows':r.integer(4),'bytes':r.integer(8)}
 elif tag==2:ob={'variant':'Training','candidate':r.bundle(),'steps':r.integer(8),'milliseconds':r.integer(8),'artifact_bytes':r.integer(8)}
 elif tag==3:
  ob={'variant':'Evaluation','candidate_bundle':r.digest(),'evaluation_profile':r.digest()};d=r.u8();assert d in (0,1);ob['disposition']=['Qualified','NoUpdate'][d]
 elif tag==4:
  ob={'variant':'Proposal','candidate_bundle':r.digest(),'proposal_id':r.identifier(),'composition_digest':r.digest()};d=r.u8();assert d in (0,1);ob['disposition']=['UpdateCandidates','NoAdmissibleUpdate'][d]
 else:raise AssertionError('Unexpected tag in this retained pre-decision failure record: '+str(tag))
 row.update(index=index,encoded_byte_span=[start,r.i],observation=ob,observed_utc=datetime.datetime.fromtimestamp(row['observed_unix_seconds'],datetime.timezone.utc).isoformat());receipts.append(row)
head=r.digest();assert r.i==len(data)
assert [row['observation']['variant'] for row in receipts]==['Experience','Dataset','Training','Evaluation','Proposal']
assert all(row['operation_id']==request['operation_id'] for row in receipts)
assert [row['actor_id'] for row in receipts]==[owners[n] for n in ['experience','dataset','trainer','evaluator','proposal']]
assert all(a['observed_unix_seconds']<=b['observed_unix_seconds'] for a,b in zip(receipts,receipts[1:]))
training=receipts[2]['observation'];evaluation=receipts[3]['observation'];proposal=receipts[4]['observation']
assert evaluation['disposition']=='Qualified' and proposal['disposition']=='UpdateCandidates'
assert evaluation['candidate_bundle']==proposal['candidate_bundle']
assert evaluation['evaluation_profile']==request['evaluation_profile']
assert outer['frontier']['predecessor']==receipts[-1]['predecessor']
codec=HERE/'codec_source/source/codex-rs/hepta-agentd/src/learning_iteration_checkpoint_codec.rs'
report={'schema':'hepta-e6-actual-checkpoint-structural-readback-v1','source':'84721f3da92ffaac3e7c7e2e39de2df985834370','input':{'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'original_codec':{'path':'codex-rs/hepta-agentd/src/learning_iteration_checkpoint_codec.rs','sha256':hashlib.sha256(codec.read_bytes()).hexdigest()},'decoder_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'forensics_archive_sha256':'9685c2cf85e1bfe37550ef360aaf45e162b6bcc537e2fcd1d701453dc0869359','method':'Read-only translation of the pinned Rust codec field order, bounds, big-endian widths and variant tags; exact bytes consumed. No Rust rerun, owner construction or new authorization. Cryptographic receipt-chain verification was not independently re-executed by this Python decoder.','magic':magic,'snapshot_bytes':len(data),'snapshot_sha256':hashlib.sha256(data).hexdigest(),'all_snapshot_bytes_consumed':True,'outer_scope_binding':outer['frontier']['binding'],'outer_predecessor':outer['frontier']['predecessor'],'head_digest':head,'request':request,'owners':owners,'receipt_count':count,'receipts':receipts,'actual_training_receipt_fields':{name:training[name] for name in ['steps','milliseconds','artifact_bytes']},'fields_not_in_this_training_observation':['optimizer_steps','parameter_updates','examples_seen'],'local_decision_recorded':False,'artifact_selection_recorded':False,'next_use_recorded':False,'candidate_head_component_differs':training['candidate']['components']['heads']!=request['selected_bundle']['components']['heads'],'root_final_fixture_adoption_claimed':False,'cold_cases_started':0}
(HERE/'ACTUAL_CHECKPOINT_DECODED.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['magic','receipt_count','actual_training_receipt_fields','fields_not_in_this_training_observation','local_decision_recorded','artifact_selection_recorded','next_use_recorded','candidate_head_component_differs']},indent=2))
print(json.dumps([{'variant':x['observation']['variant'],'disposition':x['observation'].get('disposition'),'observed_utc':x['observed_utc']} for x in receipts],indent=2))
print('report_sha256',hashlib.sha256((HERE/'ACTUAL_CHECKPOINT_DECODED.json').read_bytes()).hexdigest())
