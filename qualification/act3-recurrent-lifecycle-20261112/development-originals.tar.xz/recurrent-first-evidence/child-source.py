
import json,os,signal,sys
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from durable_lifecycle import canonical
from recurrent_lifecycle import RecurrentLifecycle
from skill_lifecycle import SkillContract
root=Path(sys.argv[2]); mode=sys.argv[3]
inputs=json.loads((root/'inputs.json').read_text())
args=(inputs['task'],SkillContract(**inputs['contract']),root/'model.npz',root/'session')
if mode=='restore_once':
    d=RecurrentLifecycle.restore(*args)
    before=json.loads(canonical(d.policy))
    def forbid(*args): raise AssertionError('pending decision was inferred twice')
    d.model.choose=forbid
    more=d.step()
    after=json.loads(canonical(d.policy))
    print(json.dumps({'pid':os.getpid(),'before':before,'after':after,'more':more,'result':d.report()}))
    d.close()
else:
    d=RecurrentLifecycle.start(*args)
    original_save=d._save; original_apply=d.owner.original.apply
    def die():
        raw=d.db.execute('SELECT body FROM state WHERE id=1').fetchone()[0]
        with (root/'interrupted-checkpoint.json').open('wb') as f:
            f.write(raw); f.flush(); os.fsync(f.fileno())
        with (root/'cut.json').open('w') as f:
            json.dump({'pid':os.getpid(),'uid':os.geteuid(),'mode':mode,'policy':d.policy,'calls':d.calls},f)
            f.flush(); os.fsync(f.fileno())
        os.kill(os.getpid(),signal.SIGKILL)
    def save():
        original_save()
        if mode=='prepared' and d.policy['phase']=='prepared' and d.policy['pending']['action']=='ensure': die()
    def apply(*args):
        if mode=='before_apply': die()
        result=original_apply(*args)
        if mode=='after_publish': die()
        return result
    d._save=save; d.owner.original.apply=apply
    while d.step(): pass
    raise AssertionError('requested real crash boundary was never reached')
