"""Run one existing Attach fixture on the unchanged, already tested delivery tree.

stdin: {"expected_source": <stage TESTED_IDENTITY>,
        "postimages": <stage final-postimages array>}
This runner never checks out, edits, formats, fixes, or retries source code.
"""

import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import tarfile
import time
import traceback
import xml.etree.ElementTree as ET

REMOTE_HOME = pathlib.Path("/home/qian-qi")
ROOT = REMOTE_HOME / "mem-native-5af6-20261111"
SRC = ROOT / "source"
CWD = SRC / "codex-rs"
STAGE = "delivery-legacy-attach-v1"
RECORDS = ROOT / STAGE
BASE = "189711e3563ea13a5328d52e99a286f082045b98"
BASE_TREE = "e253b99e0a5c3b3a680569da0d224fabff0781ba"
EXACT = "native_app_server::tests::real_agentd_worker_accepts_fresh_context_and_rejects_final_use_tombstone"
FIXTURE = "codex-rs/hepta-infer-worker-host/src/native_app_server_tests.rs"
FIXTURE_BLOB = "d4febb0e80cd39554370de03af686fa1839aa6ed"
EXPECTED_PATHS = {
    "codex-rs/hepta-infer-worker-host/src/native_app_server.rs",
    "codex-rs/hepta-infer-worker-host/src/native_run_control.rs",
    "codex-rs/hepta-infer-worker-host/src/native_run_control_tests.rs",
    "codex-rs/hepta-infer-worker-host/src/native_context.rs",
    "codex-rs/hepta-infer-worker-host/src/native_context_tests.rs",
    "codex-rs/hepta-agentd/src/test_support.rs",
}
IDENTITY_KEYS = {"commit", "tree", "status", "cargo_lock_sha256", "bazel_lock_sha256"}
JUST = str(REMOTE_HOME / ".cargo/bin/just")
COMMAND = [
    JUST, "test", "--locked", "-p", "codex-hepta-infer-worker-host", "--lib",
    "-E", "test(=" + EXACT + ")", "--no-capture", "--retries", "0",
]
ENV = {
    **os.environ,
    "PATH": str(REMOTE_HOME / ".cargo/bin") + ":" + os.environ.get("PATH", ""),
    "RUSTUP_TOOLCHAIN": "1.96.0",
    "CARGO_TARGET_DIR": str(ROOT / "target"),
    "CARGO_BUILD_JOBS": "4",
    "PYTHONDONTWRITEBYTECODE": "1",
    "RUST_BACKTRACE": "1",
    "TMPDIR": "/tmp",
    "BASE_SHA": BASE,
    "HEPTA_CI_LANE": "source-head",
}
for key in ("CARGO_BIN_EXE_codex", "NEXTEST_BIN_EXE_codex"):
    ENV.pop(key, None)


def save(name, value):
    with (RECORDS / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def git(*args):
    return subprocess.check_output(
        ["/usr/bin/git", "-C", str(SRC), *args], env=ENV, text=True
    ).strip()


def identity():
    return {
        "commit": git("rev-parse", "HEAD"),
        "tree": git("rev-parse", "HEAD^{tree}"),
        "status": git("status", "--porcelain"),
        "cargo_lock_sha256": digest(CWD / "Cargo.lock"),
        "bazel_lock_sha256": digest(SRC / "MODULE.bazel.lock"),
    }


def receipt_identity(source):
    parents = git("rev-list", "--parents", "-n", "1", "HEAD").split()[1:]
    return {
        "commit": source["commit"], "tree": source["tree"],
        "parents": parents, "dirty": bool(source["status"]),
    }


def file_record(path):
    stat = path.stat()
    return {"path": str(path), "bytes": stat.st_size,
            "sha256": digest(path), "mtime_ns": stat.st_mtime_ns}


def validate_input(value):
    if not isinstance(value, dict) or set(value) != {"expected_source", "postimages"}:
        raise ValueError("INPUT_KEYS_MUST_BE_EXPECTED_SOURCE_AND_POSTIMAGES")
    source = value["expected_source"]
    if not isinstance(source, dict) or set(source) != IDENTITY_KEYS or source["status"] != "":
        raise ValueError("EXPECTED_SOURCE_MUST_BE_COMPLETE_AND_CLEAN")
    for key, width in (("commit", 40), ("tree", 40),
                       ("cargo_lock_sha256", 64), ("bazel_lock_sha256", 64)):
        if not isinstance(source[key], str) or re.fullmatch("[0-9a-f]{" + str(width) + "}", source[key]) is None:
            raise ValueError("INVALID_SOURCE_IDENTITY:" + key)
    images = value["postimages"]
    if not isinstance(images, list) or len(images) != 6:
        raise ValueError("EXACTLY_SIX_POSTIMAGES_REQUIRED")
    if {f["path"] for f in images} != EXPECTED_PATHS:
        raise ValueError("POSTIMAGE_PATH_SET_CHANGED")
    for image in images:
        if set(image) != {"path", "blob", "sha256", "bytes", "mode"}:
            raise ValueError("POSTIMAGE_FIELDS_CHANGED")
        if image["mode"] != "100644" or type(image["bytes"]) is not int or image["bytes"] <= 0:
            raise ValueError("INVALID_POSTIMAGE_MODE_OR_SIZE")
        for key, width in (("blob", 40), ("sha256", 64)):
            if re.fullmatch("[0-9a-f]{" + str(width) + "}", image[key]) is None:
                raise ValueError("INVALID_POSTIMAGE_DIGEST")
    return source, sorted(images, key=lambda entry: entry["path"])


def source_snapshot(label, expected_source, expected_images):
    observed_source = identity()
    observed_images = []
    for image in expected_images:
        path = SRC / image["path"]
        if path.is_symlink():
            raise RuntimeError("SOURCE_SYMLINK:" + image["path"])
        data = path.read_bytes()
        mode, kind, committed_blob = git("ls-tree", "HEAD", "--", image["path"]).split("\t", 1)[0].split()
        observed = {"path": image["path"], "blob": blob(data),
                    "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data), "mode": mode}
        if kind != "blob" or committed_blob != observed["blob"]:
            raise RuntimeError("HEAD_AND_WORKTREE_POSTIMAGE_DIFFER:" + image["path"])
        observed_images.append(observed)
    fixture_data = (SRC / FIXTURE).read_bytes()
    fixture = {"path": FIXTURE, "blob": blob(fixture_data),
               "sha256": hashlib.sha256(fixture_data).hexdigest(), "bytes": len(fixture_data)}
    snapshot = {"source": observed_source, "postimages": observed_images, "fixture": fixture}
    save(label + ".json", snapshot)
    if observed_source != expected_source or observed_images != expected_images:
        raise RuntimeError("SOURCE_OR_POSTIMAGE_MISMATCH:" + label)
    if fixture["blob"] != FIXTURE_BLOB or git("rev-parse", "HEAD:" + FIXTURE) != FIXTURE_BLOB:
        raise RuntimeError("EXISTING_FIXTURE_CHANGED:" + label)
    return snapshot


def inventory(source):
    binaries = []
    for path in sorted((ROOT / "target/debug/deps").glob("codex_hepta_infer_worker_host-*")):
        if path.is_file() and path.suffix == "" and os.access(path, os.X_OK):
            binaries.append(file_record(path))
    result = {
        "source": source, "binaries": binaries,
        "actual_self_executable_contract": "std::env::current_exe() of the native test; core_test_support registers arg0 helpers",
        "scope": "Post-run matching test artifacts. Inventory alone does not identify one consumed executable; the original Nextest receipt and JUnit bind the case and source.",
        "separate_cli_required": False, "separate_cli_consumption_claimed": False,
    }
    save("NATIVE_TEST_BINARY_INVENTORY.json", result)
    return result


def run_case(expected_source, expected_images):
    before = source_snapshot("SOURCE_BEFORE", expected_source, expected_images)
    expected_receipt_source = receipt_identity(expected_source)
    junit_path = CWD / "target/nextest/local/junit.xml"
    prior = file_record(junit_path) if junit_path.is_file() else None
    if prior:
        (RECORDS / "PREVIOUS_JUNIT.xml").write_bytes(junit_path.read_bytes())
    save("PREVIOUS_JUNIT.json", prior)
    receipt_path = RECORDS / "legacy-attach.receipt.json"
    wrapper = ["/usr/bin/python3", "-B", str(SRC / "scripts/hepta_ci_exec.py"),
               "--output", str(receipt_path), "--minimum-tests", "1",
               "--timeout-seconds", "1800", "--", *COMMAND]
    save("COMMAND.json", {
        "command": COMMAND, "wrapper": wrapper, "cwd": str(CWD),
        "expected_source": expected_source,
        "env": {key: ENV[key] for key in (
            "RUSTUP_TOOLCHAIN", "CARGO_TARGET_DIR", "CARGO_BUILD_JOBS", "SOURCE_SHA",
            "TESTED_SHA", "BASE_SHA", "HEPTA_CI_LANE")},
        "removed_binary_overrides": ["CARGO_BIN_EXE_codex", "NEXTEST_BIN_EXE_codex"],
        "retry_policy": "one invocation, nextest retries 0; no driver retry",
    })
    started_ns = time.time_ns()
    started = time.monotonic()
    print(json.dumps({"stage": STAGE, "phase": "STARTED", "case": EXACT}), flush=True)
    completed = None
    execution_error = None
    try:
        with (RECORDS / "wrapper.stdout.log").open("xb") as stdout, (RECORDS / "wrapper.stderr.log").open("xb") as stderr:
            completed = subprocess.run(wrapper, cwd=CWD, env=ENV, stdout=stdout, stderr=stderr, timeout=1920)
    except Exception as error:
        execution_error = {"error": repr(error), "traceback": traceback.format_exc()}
    after = source_snapshot("SOURCE_AFTER", expected_source, expected_images)
    receipt = json.loads(receipt_path.read_text()) if receipt_path.is_file() else None
    wrapper_exit = completed.returncode if completed is not None else None
    audit = {"command": COMMAND, "wrapper_exit": wrapper_exit, "execution_error": execution_error,
             "seconds": time.monotonic() - started, "before": before, "after": after,
             "source_unchanged": before == after, "receipt": receipt, "gate_passed": False}
    raw_ok = False
    receipt_ok = False
    if receipt:
        log_name = receipt.get("log_file")
        if isinstance(log_name, str) and pathlib.Path(log_name).name == log_name:
            raw = RECORDS / log_name
            if raw.is_file() and not raw.is_symlink():
                audit["raw_log"] = file_record(raw)
                raw_ok = raw.stat().st_size == receipt.get("log_bytes") and digest(raw) == receipt.get("log_sha256")
        receipt_ok = all((
            receipt.get("status") == "passed", receipt.get("command") == COMMAND,
            receipt.get("working_directory") == str(CWD), receipt.get("minimum_tests") == 1,
            receipt.get("source_sha") == expected_source["commit"],
            receipt.get("tested_sha") == expected_source["commit"], receipt.get("base_sha") == BASE,
            receipt.get("lane") == "source-head", receipt.get("before") == expected_receipt_source,
            receipt.get("after") == expected_receipt_source, receipt.get("command_exit_code") == 0,
            receipt.get("returncode") == 0, receipt.get("exit_code") == 0,
            receipt.get("observed_passed_tests") == 1, receipt.get("observed_failed_tests") == 0,
            receipt.get("timed_out") is False, receipt.get("output_limit_exceeded") is False,
        ))
    junit_ok = False
    if junit_path.is_file():
        data = junit_path.read_bytes()
        (RECORDS / "legacy-attach.junit.xml").write_bytes(data)
        report = file_record(junit_path)
        document = ET.fromstring(data)
        cases = [{"name": case.get("name"), "classname": case.get("classname"),
                  "bad_outcomes": [item.tag for item in case.iter()
                                   if item.tag in {"failure", "error", "skipped", "rerunFailure", "flakyFailure"}]}
                 for case in document.iter("testcase")]
        bad_totals = [{"tag": item.tag, "attribute": key, "value": item.get(key)}
                      for item in document.iter() if item.tag in {"testsuites", "testsuite"}
                      for key in ("failures", "errors", "skipped", "disabled")
                      if int(item.get(key, "0")) != 0]
        fresh = report["mtime_ns"] >= started_ns and (prior is None or report["sha256"] != prior["sha256"])
        junit_ok = fresh and len(cases) == 1 and cases[0]["name"] == EXACT and not cases[0]["bad_outcomes"] and not bad_totals
        audit["junit"] = {"file": report, "fresh": fresh, "cases": cases,
                          "bad_totals": bad_totals,
                          "tests": len(cases), "duplicate_ids": len(cases) - len({(case["classname"], case["name"]) for case in cases})}
    audit.update({"raw_verified": raw_ok, "receipt_verified": receipt_ok,
                  "junit_verified": junit_ok,
                  "gate_passed": execution_error is None and wrapper_exit == 0 and before == after and raw_ok and receipt_ok and junit_ok})
    save("AUDIT.json", audit)
    binaries = inventory(expected_source)
    if not audit["gate_passed"] or not binaries["binaries"]:
        raise RuntimeError("LEGACY_ATTACH_GATE_FAILED")
    return audit


def main():
    value = json.load(sys.stdin)
    save("INPUT.json", value)
    expected_source, expected_images = validate_input(value)
    ENV.update({"SOURCE_SHA": expected_source["commit"], "TESTED_SHA": expected_source["commit"]})
    if git("rev-parse", BASE + "^{tree}") != BASE_TREE:
        raise RuntimeError("BASE_TREE_CHANGED")
    changed = set(git("diff", "--name-only", BASE, "HEAD").splitlines())
    if changed != EXPECTED_PATHS:
        raise RuntimeError("DELIVERY_TREE_MUST_CHANGE_EXACTLY_SIX_PATHS")
    if "__file__" in globals() and pathlib.Path(__file__).is_file():
        (RECORDS / "invocation-driver.py").write_bytes(pathlib.Path(__file__).read_bytes())
    elif sys.argv[0] == "-c":
        argv = pathlib.Path("/proc/self/cmdline").read_bytes().split(b"\0")
        position = argv.index(b"-c")
        (RECORDS / "invocation-driver.py").write_bytes(argv[position + 1])
    else:
        raise RuntimeError("ORIGINAL_DRIVER_SOURCE_NOT_AVAILABLE")
    save("FIXTURE_BINARY_CONTRACT.json", {
        "fixture": EXACT, "expected_fixture_blob": FIXTURE_BLOB,
        "actual_self_executable": "std::env::current_exe() of the native test with core_test_support arg0 dispatch",
        "separate_cli_required": False, "separate_cli_consumption_claimed": False,
        "provider_scope": "Loopback HTTP mock Responses in a native fixture; not a production provider or real-model episode.",
        "scientific_adoption": "HOLD",
    })
    audit = run_case(expected_source, expected_images)
    final = source_snapshot("SOURCE_FINAL", expected_source, expected_images)
    save("RESULT.json", {
        "schema": "hepta.mem.delivery-legacy-attach.v1", "stage": STAGE,
        "status": "PASS_DECLARED_NATIVE_SCOPE_ONLY", "source": final,
        "exact_case": EXACT, "observed_passed_tests": 1, "gate_passed": audit["gate_passed"],
        "production_provider_requests": 0, "real_model_episodes": 0,
        "scientific_adoption": "HOLD",
    })
    print(json.dumps({"stage": STAGE, "phase": "COMPLETED", "status": "PASS_DECLARED_NATIVE_SCOPE_ONLY"}), flush=True)


def archive():
    manifest = [{"path": path.relative_to(RECORDS).as_posix(),
                 "bytes": path.stat().st_size, "sha256": digest(path)}
                for path in sorted(RECORDS.rglob("*")) if path.is_file()]
    save("ARCHIVE_MANIFEST.json", manifest)
    archive_path = ROOT / (STAGE + ".tar.xz")
    with tarfile.open(archive_path, "x:xz") as stream:
        stream.add(RECORDS, arcname=STAGE)
    print(json.dumps({"stage": STAGE, "phase": "ARCHIVE", **file_record(archive_path)}), flush=True)


if __name__ == "__main__":
    if (ROOT / (STAGE + ".tar.xz")).exists():
        raise RuntimeError("ARCHIVE_ALREADY_EXISTS_NO_RETRY")
    RECORDS.mkdir(mode=0o700)
    try:
        main()
    except BaseException as error:
        try:
            observed = identity()
        except Exception as identity_error:
            observed = {"identity_error": repr(identity_error)}
        save("DRIVER_FAILURE.json", {"error": repr(error), "traceback": traceback.format_exc(), "source": observed})
        print(json.dumps({"stage": STAGE, "phase": "DRIVER_FAILURE", "error": repr(error)}), flush=True)
        raise
    finally:
        archive()
