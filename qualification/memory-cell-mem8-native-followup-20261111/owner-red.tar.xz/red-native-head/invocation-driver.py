import os,sys,pathlib,json,subprocess,hashlib,time,shutil,xml.etree.ElementTree as ET
home=pathlib.Path("/home/qian-qi");root=home/"mem-native-5af6-20261111";src=root/"source";records=root/"red-native-head";records.mkdir(mode=0o700);files=json.load(sys.stdin)
want="189711e3563ea13a5328d52e99a286f082045b98";expected_tree="e253b99e0a5c3b3a680569da0d224fabff0781ba"
def git(*args):return subprocess.check_output(["/usr/bin/git","-C",str(src),*args]).decode().strip()
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def identity():return {"commit":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"status":git("status","--porcelain"),"cargo_lock_sha256":sha(src/"codex-rs/Cargo.lock"),"bazel_lock_sha256":sha(src/"MODULE.bazel.lock")}
def save(n,v):(records/n).write_text(json.dumps(v,indent=2)+"\n")
before=identity();save("BASE_IDENTITY.json",before)
if before["commit"]!=want or before["tree"]!=expected_tree or before["status"]:raise RuntimeError("BASE_NOT_EXACT_CLEAN_189")
for f in files:
 p=src/f["path"];data=f["content"].encode()
 if blob(data)!=f["after"]:raise RuntimeError("POST_BLOB_MISMATCH:"+f["path"])
 if f["before"] is None:
  if p.exists():raise RuntimeError("NEW_PATH_EXISTS")
 else:
  if blob(p.read_bytes())!=f["before"]:raise RuntimeError("PRE_BLOB_MISMATCH")
 p.write_bytes(data)
save("OVERLAY.json",[{k:v for k,v in f.items() if k!="content"}|{"bytes":len(f["content"].encode()),"sha256":hashlib.sha256(f["content"].encode()).hexdigest()} for f in files])
git("add","--",*[f["path"] for f in files])
(records/"SOURCE.patch").write_bytes(subprocess.check_output(["/usr/bin/git","-C",str(src),"diff","--cached","--binary"]))
r=subprocess.run(["/usr/bin/git","-C",str(src),"-c","user.name=Hepta MEM Qualification","-c","user.email=mem-qualification@example.invalid","-c","commit.gpgsign=false","commit","-m","test(mem): reproduce native predecessor withdrawal context"],capture_output=True,text=True)
(records/"local-commit.stdout").write_text(r.stdout);(records/"local-commit.stderr").write_text(r.stderr)
if r.returncode:raise RuntimeError("LOCAL_COMMIT_FAILED")
tested=identity();save("TESTED_IDENTITY.json",tested)
if tested["status"]:raise RuntimeError("RED_SOURCE_DIRTY")
print(json.dumps({"phase":"RED_SOURCE_BOUND","source":tested}),flush=True)
cache=home/"mem8-dependency-validation-ed353817-v2"/"target";target=root/"target";cache_info={"source":str(cache),"destination":str(target),"copies_not_hardlinks":True}
if target.exists():raise RuntimeError("TARGET_ALREADY_EXISTS")
if cache.is_dir():
 d=subprocess.run(["/usr/bin/du","-sb",str(cache)],capture_output=True,text=True,timeout=120);cache_info["du_returncode"]=d.returncode;cache_info["du_stdout"]=d.stdout;cache_info["du_stderr"]=d.stderr
 if d.returncode==0:
  size=int(d.stdout.split()[0]);cache_info["bytes"]=size;cache_info["free_before"]=shutil.disk_usage(root).free
  if size < cache_info["free_before"]-35*1024**3:
   with (records/"cache-copy.stdout").open("wb") as so,(records/"cache-copy.stderr").open("wb") as se:r=subprocess.run(["/bin/cp","-a","--reflink=auto",str(cache),str(target)],stdout=so,stderr=se,timeout=600)
   cache_info["copy_exit"]=r.returncode
   if r.returncode:save("CACHE.json",cache_info);raise RuntimeError("CACHE_COPY_FAILED")
   cache_info["mode"]="independent-copy-reflink-auto"
  else:target.mkdir();cache_info["mode"]="empty-target-insufficient-copy-budget"
 else:target.mkdir();cache_info["mode"]="empty-target-du-failed"
else:target.mkdir();cache_info["mode"]="empty-target-no-cache"
cache_info["free_after"]=shutil.disk_usage(root).free;save("CACHE.json",cache_info)
print(json.dumps({"phase":"CACHE_READY","cache":cache_info}),flush=True)
env={**os.environ,"PATH":"/home/qian-qi/.cargo/bin:/home/qian-qi/.local/bin:"+os.environ.get("PATH",""),"RUSTUP_TOOLCHAIN":"1.96.0","CARGO_TARGET_DIR":str(target),"CARGO_BUILD_JOBS":"4","PYTHONDONTWRITEBYTECODE":"1","RUST_BACKTRACE":"1","TMPDIR":"/tmp","SOURCE_SHA":tested["commit"],"TESTED_SHA":tested["commit"],"BASE_SHA":want,"HEPTA_CI_LANE":"source-head"}
versions={}
for n,a in [("rustc",["--version","--verbose"]),("cargo",["--version"]),("just",["--version"]),("cargo-nextest",["nextest","--version"])]:
 r=subprocess.run([str(home/".cargo/bin"/n),*a],cwd=src/"codex-rs",env=env,capture_output=True,text=True,timeout=60);versions[n]={"exit":r.returncode,"stdout":r.stdout,"stderr":r.stderr}
 if r.returncode:save("TOOLS.json",versions);raise RuntimeError("TOOL_FAILED:"+n)
save("TOOLS.json",versions)
case="production_composition::tests::episodic_control::native_heads::native_predecessor_forget_closes_episodic_context"
command=[str(home/".cargo/bin/just"),"test","--locked","-p","codex-hepta-agentd","--lib","-E","test(="+case+")","--no-capture","--retries","0"]
junit=src/"codex-rs/target/nextest/local/junit.xml";prior_junit=sha(junit) if junit.exists() else None
save("COMMAND.json",{"command":command,"cwd":str(src/"codex-rs"),"environment":{k:env[k] for k in ["RUSTUP_TOOLCHAIN","CARGO_TARGET_DIR","CARGO_BUILD_JOBS","SOURCE_SHA","TESTED_SHA","BASE_SHA","HEPTA_CI_LANE"]},"timeout_seconds":1800})
wrapper=["/usr/bin/python3","-B",str(src/"scripts/hepta_ci_exec.py"),"--output",str(records/"receipt.json"),"--minimum-tests","1","--timeout-seconds","1800","--",*command]
print(json.dumps({"phase":"RED_NATIVE_STARTED","command":command,"timeout_seconds":1800}),flush=True)
t=time.monotonic()
with (records/"wrapper.stdout.log").open("wb") as so,(records/"wrapper.stderr.log").open("wb") as se:r=subprocess.run(wrapper,cwd=src/"codex-rs",env=env,stdout=so,stderr=se,timeout=1920)
after=identity();receipt=json.loads((records/"receipt.json").read_text()) if (records/"receipt.json").exists() else None
out={"wrapper_exit_code":r.returncode,"elapsed_seconds":time.monotonic()-t,"before":tested,"after":after,"source_unchanged":after==tested,"receipt":receipt,"requested_case":case,"classification":"UNADJUDICATED"}
if receipt:
 raw=records/receipt["log_file"];out["raw_verified"]=len(raw.read_bytes())==receipt["log_bytes"] and sha(raw)==receipt["log_sha256"]
 if receipt.get("observed_failed_tests",0)>0:out["classification"]="TEST_FAILURE_OBSERVED_REQUIRES_CASE_ASSERTION_REVIEW"
 elif receipt.get("observed_passed_tests",0)>0:out["classification"]="TEST_PASSED_REVIEW_HYPOTHESIS"
 else:out["classification"]="NO_EXECUTED_TEST_OBSERVED_NOT_A_RED"
if junit.exists() and sha(junit)!=prior_junit:
 data=junit.read_bytes();(records/"red.junit.xml").write_bytes(data);doc=ET.fromstring(data);out["junit"]={"sha256":hashlib.sha256(data).hexdigest(),"cases":[{"name":c.get("name"),"classname":c.get("classname"),"failure":c.find("failure") is not None,"error":c.find("error") is not None,"skipped":c.find("skipped") is not None}for c in doc.iter("testcase")]}
save("RESULT.json",out)
print(json.dumps({"phase":"RED_NATIVE_TERMINAL",**{k:v for k,v in out.items() if k not in ["receipt","before","after","junit"]}}),flush=True)
