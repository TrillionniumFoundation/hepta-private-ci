"""Preserve completed E2 originals without running models or changing sources."""

import hashlib
import json
from pathlib import Path
import stat
import tarfile
import time

ROOT = Path("/dev/shm/hepta-cell-experiments-v3-20261116-0c078a")
RUNTIME = Path("/home/qian-qi/hepta-cell-experiments-v3-20261116-0c078a")
RUN_NAME = "research-round03-20261118-392934-b"
RUN = ROOT / RUN_NAME
OWNED = ROOT / "operations/round03-owned-20261118-392934-b"
CHECKPOINTS = RUNTIME / "operations/round03-checkpoints-20261118-392934-b"
OUT = RUNTIME / "operations/round03-evidence-20261118-392934-b"
WEIGHT_SUFFIXES = {".safetensors", ".pt", ".bin"}


def sha(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(8 * 1024 * 1024):
            value.update(block)
    return value.hexdigest()


def read(path):
    return json.loads(path.read_text())


def write_new(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")


def metadata(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError("regular retained file required: " + str(path))
    digest = sha(path)
    after = path.lstat()
    if (before.st_ino, before.st_size, before.st_mtime_ns) != (
        after.st_ino,
        after.st_size,
        after.st_mtime_ns,
    ):
        raise ValueError("retained file changed while hashing: " + str(path))
    return {"path": str(path), "bytes": after.st_size, "sha256": digest}


def verify_archive(path, expected):
    seen = set()
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            if (
                not member.isfile()
                or member.name not in expected
                or member.name in seen
            ):
                raise ValueError("unexpected archive member: " + member.name)
            raw = archive.extractfile(member)
            value = hashlib.sha256()
            total = 0
            while block := raw.read(8 * 1024 * 1024):
                value.update(block)
                total += len(block)
            item = expected[member.name]
            if total != item["bytes"] or value.hexdigest() != item["sha256"]:
                raise ValueError("archive bytes differ: " + member.name)
            seen.add(member.name)
    if seen != set(expected):
        raise ValueError("archive coverage differs")


def main():
    started = time.perf_counter()
    release = read(OWNED / "SEQUENCE_COMPLETE.json")
    if release.get("all_jobs_wait_returncode_zero") is not True:
        raise ValueError("all frozen E2 jobs must finish before export")
    if (
        sha(OWNED / "SEQUENCE.json")
        != "f273cbd7e7f8921ac3d2bcbdcea4b596bf39f27acd72b064a4ab3231d140056c"
    ):
        raise ValueError("owned sequence differs")
    sequence = read(OWNED / "SEQUENCE.json")
    processes = []
    for job in sequence["jobs"]:
        directory = OWNED / job
        intent = metadata(directory / "INTENT.json")
        launch = metadata(directory / "STARTED.json")
        exit_receipt = read(directory / "EXIT.json")
        if (
            exit_receipt["wait_returncode"] != 0
            or exit_receipt["exit_source"] != "subprocess.Popen.wait"
            or exit_receipt["intent_sha256"] != intent["sha256"]
            or exit_receipt["started_sha256"] != launch["sha256"]
            or exit_receipt["child_identity"]
            != read(directory / "STARTED.json")["child_identity"]
        ):
            raise ValueError("incomplete owned process: " + job)
        for name in ("stdout", "stderr"):
            observed = metadata(directory / (name + ".log"))
            if any(
                observed[key] != exit_receipt[name][key] for key in ("bytes", "sha256")
            ):
                raise ValueError("owned process log changed: " + job)
        processes.append(
            {"job": job, "exit": metadata(directory / "EXIT.json"), **exit_receipt}
        )
    readout = RUN / "recovery-readout-b2d1fce"
    readout_index = read(readout / "INDEX.json")
    if readout_index["readout_commit"] != "b2d1fceeb779b9392c2842bfa32e16feb1079024":
        raise ValueError("readout implementation differs")
    for report in readout_index["reports"]:
        if sha(readout / report["file"]) != report["sha256"]:
            raise ValueError("readout changed")
    OUT.mkdir(exist_ok=False)
    originals = {}
    excluded = {}

    def add_file(path):
        relative = (
            str(path.relative_to(ROOT))
            if path.is_relative_to(ROOT)
            else str(path.relative_to(RUNTIME))
        )
        prefix = "workspace/" if path.is_relative_to(ROOT) else "runtime/"
        item = metadata(path)
        target = excluded if path.suffix in WEIGHT_SUFFIXES else originals
        target[prefix + relative] = item

    def add_directory(path):
        if not path.is_dir():
            raise ValueError("required directory absent: " + str(path))
        for member in sorted(path.rglob("*")):
            if member.is_symlink():
                raise ValueError("symlink in retained originals: " + str(member))
            if member.is_file():
                add_file(member)

    for name in (
        "e2",
        "evaluations",
        "engineering-numerical",
        "engineering-reference",
        "recovery-readout-b2d1fce",
    ):
        add_directory(RUN / name)
    for job in sequence["jobs"][1:]:
        add_directory(RUN / "worker-receipts" / job)
    for name in ("COMPARISON.json", "ENGINEERING_GATE.json"):
        add_file(RUN / name)
    add_directory(OWNED)
    for name in (
        "candidate-qwen-03",
        "research-sft-v1-source",
        "e1e2-operation-helpers-04",
        "round03-source-20261118-392934-b",
        "round03-readout-b2d1fce-20261118-392934",
        "round03-source-20261118-392934",
        "research-round03-20261118-392934",
    ):
        add_directory(ROOT / name)
    add_directory(ROOT / "operations/round03-owned-20261118-392934")
    for name in (
        "launch_round03_392934_b.py",
        "read_round03_recovery_392934_b.py",
        "read_round03_recovery_392934_b_v2.py",
        "launch_qwen_research_owned_v1_02.py",
        "ROUND03_CLOSURE_20261118_392934_V4.json",
        "QWEN_SOURCE_02.json",
    ):
        add_file(ROOT / "operations" / name)
    add_file(Path(__file__).absolute())
    inputs_path = ROOT / "research-sft-02/INPUTS.json"
    if (
        sha(inputs_path)
        != "691945696e7dad9ee0f3023617edf5ca0f787850c16f2623c08d14bc6cfbeaf3"
    ):
        raise ValueError("original inputs differ")
    add_file(inputs_path)
    inputs = read(inputs_path)
    for key, directory in (
        ("recovery_bindings", RUNTIME),
        ("workspace_bindings", ROOT),
    ):
        for relative, expected in inputs["runtime"][key].items():
            path = directory / relative
            if (
                ".." in Path(relative).parts
                or Path(relative).is_absolute()
                or sha(path) != expected
            ):
                raise ValueError("runtime/workspace binding differs: " + relative)
            add_file(path)
    for name in ("RESULT.json", "SMOKE.txt"):
        add_file(RUNTIME / "operations/recovery-20261118-e4c/install" / name)
    add_file(
        RUNTIME / "operations/round03-checkpoints-20261118-392934/00-prepare.tar.json"
    )
    dependency_files = {}
    for mode in ("final_answer", "trajectory", "controlled_correction"):
        directory = (
            ROOT / "research-sft-02/workers" / (mode + "-primary") / "research-model"
        )
        add_directory(directory)
        for path in sorted(directory.rglob("*")):
            if path.is_file():
                dependency_files[str(path.relative_to(ROOT))] = metadata(path)
    dependency_archive = OUT / "DEPENDENCY_MODELS.tar.gz"
    with tarfile.open(dependency_archive, "x:gz") as archive:
        for relative, item in dependency_files.items():
            archive.add(item["path"], arcname=relative, recursive=False)
    verify_archive(dependency_archive, dependency_files)
    checkpoint = CHECKPOINTS / "09-eval-controlled-cold.tar.gz"
    checkpoint_receipt = read(checkpoint.with_suffix(".json"))
    if (
        sha(checkpoint) != checkpoint_receipt["sha256"]
        or checkpoint.stat().st_size != checkpoint_receipt["bytes"]
    ):
        raise ValueError("final persistent model checkpoint differs")
    new_weights = {
        key.removeprefix("workspace/"): item
        for key, item in excluded.items()
        if key.startswith("workspace/" + RUN_NAME + "/")
    }
    seen_weights = set()
    with tarfile.open(checkpoint, "r:gz") as archive:
        for member in archive:
            if member.name in new_weights:
                raw = archive.extractfile(member).read()
                item = new_weights[member.name]
                if (
                    len(raw) != item["bytes"]
                    or hashlib.sha256(raw).hexdigest() != item["sha256"]
                ):
                    raise ValueError(
                        "persistent updated weights differ: " + member.name
                    )
                seen_weights.add(member.name)
    if seen_weights != set(new_weights):
        raise ValueError("updated weight checkpoint coverage differs")
    covered_weights = {"workspace/" + key for key in new_weights}
    covered_weights.update("workspace/" + key for key in dependency_files)
    if set(excluded) - covered_weights:
        raise ValueError("excluded weights lack a verified persistent location")
    base = read(RUN / "e2/teacher/RESULT.json")["final_manifest"]["base_manifest"]
    durable_base = []
    for item in base["files"]:
        path = RUNTIME / base["runtime"]["base_directory"] / item["path"]
        observed = metadata(path)
        if any(observed[key] != item[key] for key in ("bytes", "sha256")):
            raise ValueError("persistent base material differs: " + str(path))
        durable_base.append(observed)
    weights = {
        "excluded_from_raw_archive": excluded,
        "updated_model_checkpoint": {
            **metadata(checkpoint),
            "members": sorted(new_weights),
        },
        "dependency_models": {
            **metadata(dependency_archive),
            "members": dependency_files,
        },
        "persistent_base_materials": durable_base,
        "runtime_root": str(RUNTIME / "venv"),
        "optimizer_policy": "fresh AdamW each round; adapter tensors continue; optimizer files retained",
    }
    write_new(OUT / "WEIGHTS.json", weights)
    write_new(OUT / "PROCESSES.json", processes)
    for name in ("WEIGHTS.json", "PROCESSES.json"):
        add_file(OUT / name)
    for path in sorted(CHECKPOINTS.glob("*.json")):
        add_file(path)
    manifest = OUT / "RAW_FILES.json"
    write_new(manifest, originals)
    archive_expected = {**originals, "RAW_FILES.json": metadata(manifest)}
    archive_path = OUT / "RAW_EVIDENCE.tar.gz"
    with tarfile.open(archive_path, "x:gz") as archive:
        for relative, item in archive_expected.items():
            archive.add(item["path"], arcname=relative, recursive=False)
    verify_archive(archive_path, archive_expected)
    result = {
        "status": "VERIFIED_ARCHIVE",
        "raw_archive": metadata(archive_path),
        "raw_file_manifest": metadata(manifest),
        "raw_file_count": len(originals),
        "raw_file_bytes": sum(item["bytes"] for item in originals.values()),
        "weights_index": metadata(OUT / "WEIGHTS.json"),
        "processes_index": metadata(OUT / "PROCESSES.json"),
        "wall_seconds": time.perf_counter() - started,
        "new_model_calls": 0,
        "new_verifier_calls": 0,
        "new_independent_samples": 0,
        "full_system_cost_complete": False,
        "native_cell_adoption": False,
        "scope": "E2 originals only; Circuit writes excluded; archive contents reread and hashed",
    }
    write_new(OUT / "RESULT.json", result)
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
