"""Read frozen actual Round03 originals without model or verifier calls."""

import hashlib
import json
from pathlib import Path
import sys

ROOT = Path("/dev/shm/hepta-cell-experiments-v3-20261116-0c078a")
RUN = ROOT / "research-round03-20261118-392934-b"
MODULE = ROOT / "round03-source-20261118-392934-b"
READOUT = ROOT / "round03-readout-b2d1fce-20261118-392934"
OWNED = ROOT / "operations/round03-owned-20261118-392934-b"
sys.path[:0] = [
    str(ROOT / "candidate-qwen-03/scripts"),
    str(ROOT / "research-sft-v1-source"),
]
import cell_experiments

cell_experiments.__path__.extend([str(MODULE), str(READOUT)])
from cell_experiments import data
from cell_experiments.onpolicy_readout_v4 import summarize_collection
from cell_experiments.online_v4.round03_plan import material_inputs, panels
from cell_experiments.online_v4.round03_jobs import compare_cold
from cell_experiments.online_v4.reporting_v4 import e2_cost, training_cost


def read(path):
    raw = path.read_bytes()
    return data._parse(raw), hashlib.sha256(raw).hexdigest()


def write_new(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")


def owned_job(job, result):
    directory = OWNED / job
    _, intent_sha = read(directory / "INTENT.json")
    started, started_sha = read(directory / "STARTED.json")
    exited, exit_sha = read(directory / "EXIT.json")
    completed, complete_sha = read(RUN / "worker-receipts" / job / "COMPLETE.json")
    pid = started["child_identity"]["pid"]
    if (
        exited["wait_returncode"] != 0
        or exited["exit_source"] != "subprocess.Popen.wait"
        or exited["started_sha256"] != started_sha
        or exited["intent_sha256"] != intent_sha
        or exited["child_identity"] != started["child_identity"]
        or completed["status"] != "COMPLETE"
        or completed["job"] != job
        or completed["pid"] != pid
        or result.get("pid", pid) != pid
        or completed["result_digest"] != data.digest(result)
    ):
        raise ValueError("result differs from the actual owned process: " + job)
    return {
        "pid": pid,
        "intent_sha256": intent_sha,
        "started_sha256": started_sha,
        "exit_sha256": exit_sha,
        "complete_sha256": complete_sha,
        "child_wall_seconds": exited["child_wall_seconds"],
    }


def main():
    context, _ = material_inputs(ROOT)
    panel = panels(context)
    comparison, freeze_file_sha = read(RUN / "COMPARISON.json")
    out = RUN / "recovery-readout-b2d1fce"
    out.mkdir(exist_ok=False)
    reports = []
    for mode in ("teacher", "shadow", "controlled"):
        study, study_sha = read(RUN / "e2" / mode / "RESULT.json")
        if study["status"] != "COMPLETE" or study["freeze_digest"] != data.digest(
            comparison["E2"]["freezes"][mode]
        ):
            raise ValueError("study is not a complete result of the frozen comparison")
        freeze, freeze_sha = read(RUN / "e2" / mode / "FREEZE.json")
        training = [
            read(RUN / "e2" / mode / f"round-{index:03d}/model/TRAINING.json")
            for index in range(2)
        ]
        pack = {
            "freeze": freeze,
            "result": study,
            "training": [item for item, _ in training],
        }
        loop_cost = e2_cost(pack, mode)
        training_tokens = training_cost(pack)
        report = {
            "mode": mode,
            "study_sha256": study_sha,
            "final_model_digest": study["final_model_digest"],
            "collections": {},
            "evaluations": {},
            "optimizer_steps": study["optimizer_steps"],
            "freeze_file_sha256": freeze_sha,
            "owned_training_job": owned_job("e2-" + mode, study),
            "costs": {
                "e2_loop_call_totals": loop_cost,
                "training_token_totals": training_tokens,
                "training_scopes": [
                    {"training_file_sha256": sha, "cost": item["cost"]}
                    for item, sha in training
                ],
                "nested_wall_scopes_are_additive": False,
                "reference_checks_included_in_student_verifier_totals": False,
                "full_system_cost_complete": False,
            },
        }
        for index in range(2):
            label = f"round-{index:03d}"
            collection, sha = read(
                RUN / "e2" / mode / label / "collection/COLLECTION.json"
            )
            expected = study["rounds"][index]["current_model_digest"]
            if data.digest(collection) != study["rounds"][index]["collection_digest"]:
                raise ValueError("collection differs from its actual training round")
            value = summarize_collection(
                collection,
                panel["old_A"],
                expected,
                maximum=1 if mode == "shadow" else 2,
            )
            report["collections"][label] = {"raw_file_sha256": sha, **value}
        collection, sha = read(RUN / "e2" / mode / "post-update-A/COLLECTION.json")
        if data.digest(collection) != study["post_update_A_digest"]:
            raise ValueError("post-update A differs from the complete study")
        report["collections"]["post-update-A"] = {
            "raw_file_sha256": sha,
            **summarize_collection(
                collection, panel["old_A"], study["final_model_digest"]
            ),
        }
        for output_key, collection_key in (
            ("model_calls", "model_calls"),
            ("verifier_calls", "student_verifier_calls"),
            ("input_tokens", "input_tokens"),
            ("output_tokens", "output_tokens"),
        ):
            if (
                sum(
                    c["actual_call_cost"][collection_key]
                    for c in report["collections"].values()
                )
                != loop_cost[output_key]
            ):
                raise ValueError(
                    "study cost summary differs from its actual collections"
                )
        evaluations = {}
        for phase in ("primary", "cold"):
            evaluation, sha = read(
                RUN / "evaluations" / mode / phase / "EVALUATION.json"
            )
            if (
                evaluation["model_digest"] != study["final_model_digest"]
                or evaluation["comparison_digest"] != comparison["comparison_digest"]
                or evaluation["schema"] != "hepta.round03-exposed-evaluation.v1"
                or evaluation["status"] != "COMPLETE"
                or evaluation["mode"] != mode
                or evaluation["phase"] != phase
                or evaluation["panel_digests"] != comparison["panel_digests"]
                or evaluation["source_inventory"]
                != study["final_manifest"]["source_inventory"]
                or evaluation["independent_sample_increment"] != 0
                or {r["panel"] for r in evaluation["rows"]} != set(panel)
            ):
                raise ValueError("evaluation candidate or comparison differs")
            evaluations[phase] = evaluation
            observed_steps = [
                step for row in evaluation["rows"] for step in row["steps"]
            ]
            observed_cost = {
                "model_calls": len(observed_steps),
                "verifier_calls": len(observed_steps),
                "input_tokens": sum(
                    s["output"]["input_tokens"] for s in observed_steps
                ),
                "output_tokens": sum(
                    s["output"]["output_tokens"] for s in observed_steps
                ),
            }
            if any(
                type(evaluation[key]) is not int or evaluation[key] != value
                for key, value in observed_cost.items()
            ):
                raise ValueError(
                    "evaluation totals differ from its retained actual calls"
                )
            phases = {}
            for name, records in panel.items():
                rows = [r for r in evaluation["rows"] if r["panel"] == name]
                steps = [step for row in rows for step in row["steps"]]
                # This is an explicitly derived view of the original evaluation,
                # never a producer collection or new execution receipt.
                derived = {
                    "schema": "hepta.current-policy-collection.v1",
                    "complete": True,
                    "model_digest": evaluation["model_digest"],
                    "records_digest": data.digest(records),
                    "reused_observation_count": 0,
                    "rows": rows,
                    "model_calls": len(steps),
                    "student_verifier_calls": len(steps),
                    "input_tokens": sum(s["output"]["input_tokens"] for s in steps),
                    "output_tokens": sum(s["output"]["output_tokens"] for s in steps),
                }
                phases[name] = summarize_collection(
                    derived, records, study["final_model_digest"]
                )
            report["evaluations"][phase] = {
                "original_file_sha256": sha,
                "original_receipt_digest": data.digest(evaluation),
                "pid": evaluation["pid"],
                "owned_job": owned_job("eval-" + mode + "-" + phase, evaluation),
                "actual_call_cost": observed_cost,
                "evaluation_wall_seconds": evaluation["wall_seconds"],
                "scope": "derived panel views of retained evaluation; zero new executions",
                "panels": phases,
            }
        cold, cold_sha = read(RUN / "evaluations" / mode / "cold/COLD_COMPARISON.json")
        if cold != compare_cold(evaluations["primary"], evaluations["cold"]):
            raise ValueError(
                "cold comparison differs from actual primary and cold observations"
            )
        report["cold_comparison"] = {"raw_file_sha256": cold_sha, **cold}
        write_new(out / (mode + ".json"), report)
        reports.append(
            {
                "mode": mode,
                "file": mode + ".json",
                "sha256": hashlib.sha256(
                    (out / (mode + ".json")).read_bytes()
                ).hexdigest(),
                "final_model_digest": study["final_model_digest"],
            }
        )
    write_new(
        out / "INDEX.json",
        {
            "schema": "hepta.round03-recovery-evidence-index.v1",
            "source_commit": "9801487a07834ca9c2d1c11ca9d47672913c0a60",
            "source_manifest": json.loads((MODULE / "SOURCE.json").read_text()),
            "retained_source_closure_sha256": "9e56b5cb0e906568a17c17f3aeeaf3979766fdcee880bac6fd40a78f310f5f12",
            "readout_commit": "b2d1fceeb779b9392c2842bfa32e16feb1079024",
            "readout_source_sha256": hashlib.sha256(
                (READOUT / "onpolicy_readout_v4.py").read_bytes()
            ).hexdigest(),
            "evidence_builder_sha256": hashlib.sha256(
                Path(__file__).read_bytes()
            ).hexdigest(),
            "comparison_file_sha256": freeze_file_sha,
            "comparison_digest": comparison["comparison_digest"],
            "reports": reports,
            "new_model_calls": 0,
            "new_verifier_calls": 0,
            "new_independent_tasks": 0,
            "external_teacher_count_added": 0,
            "independent_confirmation_qualified": False,
            "full_system_cost_complete": False,
        },
    )
    print((out / "INDEX.json").read_text())


if __name__ == "__main__":
    main()
