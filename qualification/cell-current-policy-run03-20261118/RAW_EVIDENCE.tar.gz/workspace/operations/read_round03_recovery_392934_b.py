"""Read frozen actual Round03 originals without model or verifier calls."""

import hashlib
import json
from pathlib import Path
import sys

ROOT = Path("/dev/shm/hepta-cell-experiments-v3-20261116-0c078a")
RUN = ROOT / "research-round03-20261118-392934-b"
MODULE = ROOT / "round03-source-20261118-392934-b"
READOUT = ROOT / "round03-readout-b2d1fce-20261118-392934"
sys.path[:0] = [str(ROOT / "candidate-qwen-03/scripts"), str(ROOT / "research-sft-v1-source")]
import cell_experiments

cell_experiments.__path__.extend([str(MODULE), str(READOUT)])
from cell_experiments import data
from cell_experiments.onpolicy_readout_v4 import summarize_collection
from cell_experiments.online_v4.round03_plan import material_inputs, panels


def read(path):
    raw = path.read_bytes()
    return data._parse(raw), hashlib.sha256(raw).hexdigest()


def write_new(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")


def main():
    context, _ = material_inputs(ROOT)
    panel = panels(context)
    comparison, freeze_file_sha = read(RUN / "COMPARISON.json")
    out = RUN / "recovery-readout-b2d1fce"
    out.mkdir(exist_ok=False)
    reports = []
    for mode in ("teacher", "shadow", "controlled"):
        study, study_sha = read(RUN / "e2" / mode / "RESULT.json")
        if study["status"] != "COMPLETE" or study["freeze_digest"] != data.digest(comparison["E2"]["freezes"][mode]):
            raise ValueError("study is not a complete result of the frozen comparison")
        report = {"mode": mode, "study_sha256": study_sha,
                  "final_model_digest": study["final_model_digest"], "collections": {},
                  "evaluations": {}, "optimizer_steps": study["optimizer_steps"]}
        for index in range(2):
            label = f"round-{index:03d}"
            collection, sha = read(RUN / "e2" / mode / label / "collection/COLLECTION.json")
            expected = study["rounds"][index]["current_model_digest"]
            value = summarize_collection(collection, panel["old_A"], expected,
                                         maximum=1 if mode == "shadow" else 2)
            report["collections"][label] = {"raw_file_sha256": sha, **value}
        collection, sha = read(RUN / "e2" / mode / "post-update-A/COLLECTION.json")
        report["collections"]["post-update-A"] = {
            "raw_file_sha256": sha,
            **summarize_collection(collection, panel["old_A"], study["final_model_digest"])}
        for phase in ("primary", "cold"):
            evaluation, sha = read(RUN / "evaluations" / mode / phase / "EVALUATION.json")
            if evaluation["model_digest"] != study["final_model_digest"] or evaluation["comparison_digest"] != comparison["comparison_digest"]:
                raise ValueError("evaluation candidate or comparison differs")
            phases = {}
            for name, records in panel.items():
                rows = [r for r in evaluation["rows"] if r["panel"] == name]
                steps = [step for row in rows for step in row["steps"]]
                # This is an explicitly derived view of the original evaluation,
                # never a producer collection or new execution receipt.
                derived = {"schema": "hepta.current-policy-collection.v1", "complete": True,
                    "model_digest": evaluation["model_digest"], "records_digest": data.digest(records),
                    "reused_observation_count": 0, "rows": rows,
                    "model_calls": len(steps), "student_verifier_calls": len(steps),
                    "input_tokens": sum(s["output"]["input_tokens"] for s in steps),
                    "output_tokens": sum(s["output"]["output_tokens"] for s in steps)}
                phases[name] = summarize_collection(derived, records, study["final_model_digest"])
            report["evaluations"][phase] = {"original_file_sha256": sha,
                "original_receipt_digest": data.digest(evaluation), "pid": evaluation["pid"],
                "scope": "derived panel views of retained evaluation; zero new executions", "panels": phases}
        cold, cold_sha = read(RUN / "evaluations" / mode / "cold/COLD_COMPARISON.json")
        report["cold_comparison"] = {"raw_file_sha256": cold_sha, **cold}
        write_new(out / (mode + ".json"), report)
        reports.append({"mode": mode, "file": mode + ".json",
                        "sha256": hashlib.sha256((out / (mode + ".json")).read_bytes()).hexdigest(),
                        "final_model_digest": study["final_model_digest"]})
    write_new(out / "INDEX.json", {"schema": "hepta.round03-recovery-evidence-index.v1",
        "source_commit": "9801487a07834ca9c2d1c11ca9d47672913c0a60",
        "source_manifest": json.loads((MODULE / "SOURCE.json").read_text()),
        "retained_source_closure_sha256": "9e56b5cb0e906568a17c17f3aeeaf3979766fdcee880bac6fd40a78f310f5f12",
        "readout_commit": "b2d1fceeb779b9392c2842bfa32e16feb1079024",
        "readout_source_sha256": hashlib.sha256((READOUT / "onpolicy_readout_v4.py").read_bytes()).hexdigest(),
        "evidence_builder_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "comparison_file_sha256": freeze_file_sha, "comparison_digest": comparison["comparison_digest"],
        "reports": reports, "new_model_calls": 0, "new_verifier_calls": 0,
        "new_independent_tasks": 0, "external_teacher_count_added": 0,
        "independent_confirmation_qualified": False, "full_system_cost_complete": False})
    print((out / "INDEX.json").read_text())


if __name__ == "__main__":
    main()
