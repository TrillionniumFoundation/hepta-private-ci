"""Recover the isolated CUDA runtime from pinned, hash-verified public wheels."""
import concurrent.futures
from email.parser import Parser
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import zipfile
from pip._vendor import requests
from pip._vendor.packaging.requirements import Requirement
from pip._vendor.packaging.tags import sys_tags
from pip._vendor.packaging.utils import parse_wheel_filename

ROOT = Path("/home/qian-qi/hepta-cell-experiments-v3-20261116-0c078a")
OPS = ROOT / "operations/recovery-03"
WHEELS = OPS / "wheelhouse"
PYTHON = str(ROOT / "venv/bin/python")
KEY = "hepta-e1e6-v3-20261116-0c078a-cuda-recovery03-materialize-resume03"
CHUNK = 1024**2
WORKERS = 8
MIN_FREE = 1536 * 1024**2
LOCK = threading.Lock()
NETWORK = threading.local()
START = time.time()
EXPECTED = {"torch": "2.9.1+cu128", "transformers": "4.57.3", "peft": "0.18.0",
            "safetensors": "0.7.0", "tokenizers": "0.22.2", "numpy": "1.26.4"}
ALLOWED = {"download.pytorch.org", "download-r2.pytorch.org", "files.pythonhosted.org"}
CHECK_FILES = []
DOWNLOADS = []
TORCH = {}

def configure_torch(upstream):
    global TORCH
    TORCH = upstream


def canonical(name):
    return re.sub(r"[-_.]+", "-", name).lower()

def save(name, value):
    path = OPS / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
    return path

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b""):
            h.update(block)
    return h.hexdigest()

def event(value):
    with LOCK:
        with (OPS / "RECOVERY_EVENTS.jsonl").open("a") as stream:
            stream.write(json.dumps({"at_ns": time.time_ns(), **value}) + "\n")
        print(json.dumps(value), flush=True)

def get(url, limit=8 * 1024**2):
    for attempt in range(3):
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "hepta-runtime-recovery-03",
                                                          "Accept-Encoding": "identity"})
            with urllib.request.urlopen(request, timeout=35) as response:
                data = response.read(limit + 1)
            if len(data) > limit:
                raise ValueError("metadata exceeds the explicit size bound")
            return data
        except Exception:
            if attempt == 2:
                raise
            time.sleep(attempt + 1)

API = json.loads((ROOT / "operations/UPSTREAM_MODEL_API.json").read_text())
MODEL_SIZE = next(row["size"] for row in API["siblings"] if row["rfilename"] == "model.safetensors")

def model_remaining():
    path = ROOT / "materials-recovered/model.safetensors"
    return max(0, MODEL_SIZE - (path.stat().st_size if path.exists() else 0))

def reserve():
    return MIN_FREE + model_remaining()

def range_url(url, start, end):
    p = urllib.parse.urlparse(url)
    if p.scheme != "https" or p.hostname not in ALLOWED:
        raise ValueError("wheel URL outside the explicitly permitted public sources")
    return urllib.parse.urlunparse(p._replace(fragment=""))

def read_range(item, offset, count):
    if count == 0:
        return b""
    if not 0 < count <= 16 * 1024**2:
        raise ValueError("range request exceeds bound")
    end = offset + count - 1
    for attempt in range(3):
        try:
            if not hasattr(NETWORK, "session"):
                NETWORK.session = requests.Session()
            started = time.monotonic()
            headers = {"Range": f"bytes={offset}-{end}", "Accept-Encoding": "identity",
                       "User-Agent": "hepta-runtime-recovery-03-keepalive"}
            with NETWORK.session.get(range_url(item["url"], offset, end), headers=headers,
                                     stream=True, timeout=(10, 20)) as response:
                expected = f"bytes {offset}-{end}/{item['bytes']}"
                if response.status_code == 206:
                    if response.headers.get("Content-Range") != expected:
                        raise ValueError("server returned a different byte range")
                elif not (response.status_code == 200 and offset == 0 and count == item["bytes"]):
                    raise ValueError("server did not honor bounded Range")
                data = bytearray()
                for block in response.iter_content(chunk_size=16 * 1024):
                    if time.monotonic() - started > 90:
                        raise TimeoutError("range transfer exceeded 90 second budget")
                    data.extend(block)
                    if len(data) > count:
                        raise ValueError("range response exceeded declared bytes")
            if len(data) != count:
                raise ValueError("incomplete bounded range")
            return bytes(data)
        except Exception as error:
            if hasattr(NETWORK, "session"):
                NETWORK.session.close()
                del NETWORK.session
            with LOCK:
                with (OPS / "RANGE_ERRORS.jsonl").open("a") as stream:
                    stream.write(json.dumps({"filename": item["filename"], "offset": offset,
                        "count": count, "attempt": attempt, "error": repr(error)[:400],
                        "transport": "persistent_requests_eight_workers_resume03"}) + "\n")
            if attempt == 2:
                raise
            time.sleep(attempt + 1)

class RemoteZip(io.RawIOBase):
    def __init__(self, item):
        self.item = item
        self.position = 0
    def seekable(self):
        return True
    def readable(self):
        return True
    def tell(self):
        return self.position
    def seek(self, offset, whence=0):
        position = offset if whence == 0 else self.position + offset if whence == 1 else self.item["bytes"] + offset
        if not 0 <= position <= self.item["bytes"]:
            raise ValueError("invalid archive seek")
        self.position = position
        return position
    def read(self, count=-1):
        count = self.item["bytes"] - self.position if count < 0 else min(count, self.item["bytes"] - self.position)
        result = read_range(self.item, self.position, count)
        self.position += len(result)
        return result

def unpacked_size(item):
    existing = WHEELS / item["filename"]
    source = existing if existing.exists() else RemoteZip(item)
    with zipfile.ZipFile(source) as archive:
        entries = archive.infolist()
        total = sum(row.file_size for row in entries)
        if total > 8 * 1024**3 or len(entries) > 100000:
            raise ValueError("wheel expansion exceeds bound")
        item["uncompressed_bytes"] = total
        item["zip_member_count"] = len(entries)
    return item

TAGS = {tag: index for index, tag in enumerate(sys_tags())}

def pypi_item(name, version, filename=None, expected_sha=None):
    path = OPS / ("PYPI_" + canonical(name) + ".json")
    if path.exists():
        record = json.loads(path.read_text())
        selected = record["selected_file"]
        if filename is not None and selected["filename"] != filename:
            raise ValueError("pinned existing wheel identity conflicts")
    else:
        url = f"https://pypi.org/pypi/{name}/{version}/json"
        raw = get(url)
        payload = json.loads(raw)
        candidates = []
        for row in payload["urls"]:
            if row.get("packagetype") != "bdist_wheel" or row.get("yanked"):
                continue
            if filename is not None and row["filename"] != filename:
                continue
            parsed_name, parsed_version, _, tags = parse_wheel_filename(row["filename"])
            priorities = [TAGS[tag] for tag in tags if tag in TAGS]
            if priorities and canonical(parsed_name) == canonical(name) and str(parsed_version) == version:
                candidates.append((min(priorities), row["filename"], row))
        if not candidates:
            raise ValueError("no compatible pinned binary wheel: " + name + "==" + version)
        selected = min(candidates, key=lambda row: (row[0], row[1]))[2]
        save(path.name, {"url": url, "metadata_sha256": hashlib.sha256(raw).hexdigest(),
                         "selected_file": selected})
    digest = selected["digests"]["sha256"]
    if expected_sha is not None and digest != expected_sha:
        raise ValueError("pip plan hash differs from PyPI metadata")
    if not 0 < selected["size"] < 2 * 1024**3:
        raise ValueError("wheel size exceeds bound")
    return {"name": canonical(name), "version": version, "filename": selected["filename"],
            "url": selected["url"], "sha256": digest, "bytes": selected["size"],
            "upstream_metadata": str(path.relative_to(ROOT))}

def active_target_pip():
    active = []
    for directory in Path("/proc").iterdir():
        if not directory.name.isdigit():
            continue
        try:
            args = (directory / "cmdline").read_bytes().split(b"\0")
        except OSError:
            continue
        if args and args[0] == PYTHON.encode():
            decoded = [part.decode(errors="replace") for part in args]
            if "pip" in decoded and "install" in decoded:
                active.append(int(directory.name))
    return active

def materialize(item, seed=None):
    final = WHEELS / item["filename"]
    if final.exists():
        if final.stat().st_size != item["bytes"] or sha(final) != item["sha256"]:
            raise ValueError("existing complete wheel differs from pinned identity")
        receipt = {**item, "method": "verified_existing_complete", "path": str(final.relative_to(ROOT))}
        DOWNLOADS.append(receipt)
        event({"stage": "wheel_verified", "filename": item["filename"], "bytes": item["bytes"], "method": receipt["method"]})
        return
    partial = WHEELS / (item["filename"] + ".recovery03.part")
    begin = time.perf_counter()
    offset = 0
    seed_receipt = None
    covered = []
    if partial.exists():
        if partial.is_symlink() or partial.stat().st_nlink != 1:
            raise ValueError("unexpected resumable partial")
        if partial.stat().st_size != item["bytes"]:
            raise ValueError("resumable partial has unexpected logical size")
        failure = json.loads((OPS / "ENVIRONMENT_FAILED_RESUME02.json").read_text())
        if failure["operation_key"] != "hepta-e1e6-v3-20261116-0c078a-cuda-recovery03-materialize-resume02" or failure["error"] != "TimeoutError('bounded recovery download deadline reached')":
            raise ValueError("prior deadline-failed worker identity mismatch")
        raw_ranges = (OPS / "RANGE_RECEIPTS.jsonl").read_bytes()
        snapshot = OPS / ("RANGE_RECEIPTS_BEFORE_RESUME_03_" + item["name"] + ".jsonl")
        with snapshot.open("xb") as stream:
            stream.write(raw_ranges)
        retained = []
        with partial.open("rb") as stream:
            for line in raw_ranges.splitlines():
                row = json.loads(line)
                if row["filename"] != item["filename"]:
                    continue
                start, count = row["offset"], row["bytes"]
                if not 0 <= start < start + count <= item["bytes"]:
                    raise ValueError("invalid retained range")
                stream.seek(start)
                data = stream.read(count)
                if len(data) != count or hashlib.sha256(data).hexdigest() != row["sha256"]:
                    raise ValueError("retained range hash mismatch")
                covered.append((start, start + count))
                retained.append(row)
        covered.sort()
        if any(right[0] < left[1] for left, right in zip(covered, covered[1:])):
            raise ValueError("retained ranges overlap")
        save("RESUMED_RANGES_03_" + item["name"] + ".json", {"filename": item["filename"], "ranges": retained,
            "retained_bytes": sum(end - start for start, end in covered),
            "previous_range_snapshot_sha256": sha(snapshot),
            "previous_failure_sha256": sha(OPS / "ENVIRONMENT_FAILED_RESUME02.json"),
            "previous_worker_source_sha256": sha(OPS / "RECOVERY_RESUME_02.py")})
        seed_receipt = {"method": "revalidated_own_sparse_ranges",
                        "receipt": "operations/recovery-03/RESUMED_RANGES_03_" + item["name"] + ".json"}
    else:
        with partial.open("xb") as output:
            if seed is not None:
                source = Path(seed["path"])
                if active_target_pip():
                    raise RuntimeError("cannot reuse a partial while a target pip install is running")
                if source.stat().st_size != seed["before"]["bytes"] or sha(source) != seed["sha256"]:
                    raise ValueError("partial source changed since the preserved preflight")
                with source.open("rb") as stream:
                    shutil.copyfileobj(stream, output, 4 * 1024**2)
                offset = output.tell()
                covered.append((0, offset))
                seed_receipt = {"path": str(source), "bytes": offset, "sha256": seed["sha256"],
                                "method": "copied_prefix_original_unchanged"}
            output.truncate(item["bytes"])
    descriptor = os.open(partial, os.O_WRONLY)
    done = sum(end - start for start, end in covered)
    stop = threading.Event()
    chunk_size = 1024**2 if item["name"] == "torch" else CHUNK
    gaps, cursor = [], 0
    for start, end in covered:
        if start > cursor:
            gaps.append((cursor, start))
        cursor = end
    if cursor < item["bytes"]:
        gaps.append((cursor, item["bytes"]))
    requests = [(position, min(chunk_size, end - position)) for start, end in gaps
                for position in range(start, end, chunk_size)]
    def one(request):
        nonlocal done
        position, count = request
        if stop.is_set():
            return
        if time.time() - START > 3600:
            raise TimeoutError("bounded recovery download deadline reached")
        if shutil.disk_usage(ROOT).free < reserve() + WORKERS * CHUNK:
            raise OSError("free space crossed the model and 1.5 GiB reserve")
        data = read_range(item, position, count)
        if os.pwrite(descriptor, data, position) != len(data):
            raise OSError("short write")
        with LOCK:
            before = done
            done += len(data)
            with (OPS / "RANGE_RECEIPTS.jsonl").open("a") as stream:
                stream.write(json.dumps({"filename": item["filename"], "offset": position,
                    "bytes": count, "sha256": hashlib.sha256(data).hexdigest()}) + "\n")
            if done == item["bytes"] or done // (128 * 1024**2) != before // (128 * 1024**2):
                print(json.dumps({"stage": "range_progress", "filename": item["filename"],
                                  "verified_range_bytes": done, "total_bytes": item["bytes"]}), flush=True)
    pool = concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS)
    futures = [pool.submit(one, request) for request in requests]
    try:
        for future in concurrent.futures.as_completed(futures):
            future.result()
    except BaseException:
        stop.set()
        for future in futures:
            future.cancel()
        raise
    finally:
        pool.shutdown(wait=True, cancel_futures=True)
        os.fsync(descriptor)
        os.close(descriptor)
    if partial.stat().st_size != item["bytes"] or sha(partial) != item["sha256"]:
        raise ValueError("full wheel SHA256 mismatch; partial retained without publication")
    with zipfile.ZipFile(partial) as archive:
        actual = sum(row.file_size for row in archive.infolist())
        if actual != item["uncompressed_bytes"]:
            raise ValueError("wheel expansion size changed")
        if item["name"] == "torch":
            names = [name for name in archive.namelist() if name.endswith(".dist-info/METADATA")]
            if len(names) != 1 or hashlib.sha256(archive.read(names[0])).hexdigest() != TORCH["metadata_sha256"]:
                raise ValueError("downloaded Torch wheel metadata differs from pinned official metadata")
    os.link(partial, final)
    partial.unlink()
    receipt = {**item, "method": "bounded_parallel_ranges", "path": str(final.relative_to(ROOT)),
               "range_count": len(requests), "range_workers": WORKERS, "chunk_bytes": chunk_size, "wall_seconds": time.perf_counter() - begin,
               "seed": seed_receipt}
    DOWNLOADS.append(receipt)
    event({"stage": "wheel_verified", "filename": item["filename"], "bytes": item["bytes"], "method": receipt["method"]})

def run_command(name, argv, timeout, parse=False):
    begin = time.perf_counter()
    environment = {**os.environ, "TMPDIR": str(OPS / "pip-tmp"),
                   "PIP_CONFIG_FILE": os.devnull, "PIP_DISABLE_PIP_VERSION_CHECK": "1",
                   "PIP_NO_INPUT": "1", "HF_HOME": str(OPS / "hf-home"),
                   "HF_HUB_OFFLINE": "1", "TORCH_HOME": str(OPS / "torch-home"),
                   "XDG_CACHE_HOME": str(OPS / "cache"),
                   "CUDA_CACHE_PATH": str(OPS / "cuda-cache"),
                   "TRITON_CACHE_DIR": str(OPS / "triton-cache")}
    result = subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                            env=environment)
    receipt = {"argv": argv, "exit_code": result.returncode, "stdout": result.stdout,
               "stderr": result.stderr, "wall_seconds": time.perf_counter() - begin}
    if parse and result.returncode == 0:
        receipt["result"] = json.loads(result.stdout)
    if name:
        save(name, receipt)
    if result.returncode:
        raise RuntimeError((name or "command") + " failed with exit " + str(result.returncode))
    return receipt

def space_report(items, label):
    missing = sum(row["bytes"] for row in items if not (WHEELS / row["filename"]).exists())
    expansion = sum(row["uncompressed_bytes"] for row in items)
    required = missing + expansion + reserve() + 1024**3
    free = shutil.disk_usage(ROOT).free
    result = {"label": label, "free_bytes": free, "missing_compressed_bytes": missing,
              "installed_uncompressed_bytes": expansion, "other_overhead_reserve_bytes": 1024**3,
              "minimum_free_bytes": MIN_FREE, "ongoing_model_remaining_bytes": model_remaining(),
              "required_free_bytes": required, "sufficient": free >= required,
              "missing_compressed_bytes_is_conservative_full_file_budget": True}
    save(label + ".json", result)
    if not result["sufficient"]:
        raise OSError("space plan cannot preserve model download and the 1.5 GiB reserve")
    return result

