"""Verify installed wheel RECORD bytes without importing package code."""

import base64
import gzip
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys


def main():
    name, version, output = sys.argv[1:]
    prefix = Path(sys.prefix).resolve()
    assert prefix == Path("/home/qian-qi/hepta-cell-experiments-v3-20261116-0c078a/venv")
    distribution = importlib.metadata.distribution(name)
    assert distribution.version == version
    rows = []
    for item in distribution.files or []:
        path = Path(distribution.locate_file(item)).resolve()
        assert path.is_relative_to(prefix) and path.is_file()
        before = path.stat()
        digest = hashlib.sha256()
        with path.open("rb") as source:
            for block in iter(lambda: source.read(4 * 1024**2), b""):
                digest.update(block)
        after = path.stat()
        assert (before.st_ino, before.st_size, before.st_mtime_ns) == (
            after.st_ino, after.st_size, after.st_mtime_ns
        )
        if item.hash is not None:
            assert item.hash.mode == "sha256"
            actual = base64.urlsafe_b64encode(digest.digest()).rstrip(b"=").decode()
            assert actual == item.hash.value, str(item)
        if item.size is not None:
            assert item.size == before.st_size
        rows.append({"path": str(path.relative_to(prefix)), "bytes": before.st_size,
                     "sha256": digest.hexdigest(), "record_hash_present": item.hash is not None})
    assert rows
    content = json.dumps({"distribution": name, "version": version, "files": rows},
                         sort_keys=True, separators=(",", ":")).encode() + b"\n"
    destination = Path(output)
    with destination.open("xb") as target:
        with gzip.GzipFile(filename="", mode="wb", fileobj=target, mtime=0) as stream:
            stream.write(content)
    print(json.dumps({"distribution": name, "version": version,
                      "record_files": len(rows), "record_bytes": sum(row["bytes"] for row in rows),
                      "record_hashes_verified": sum(row["record_hash_present"] for row in rows),
                      "manifest_path": str(destination), "manifest_bytes": destination.stat().st_size,
                      "manifest_sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                      "record_json_sha256": hashlib.sha256(content).hexdigest(),
                      "package_code_imported": False}), flush=True)


if __name__ == "__main__":
    main()
