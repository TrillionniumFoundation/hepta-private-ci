"""Install pinned local wheels individually and release only owned verified copies."""

import json
import os
from pathlib import Path
import shutil
import stat
import time

from cuda_runtime_materials_03 import (
    MIN_FREE, OPS, PYTHON, ROOT, WHEELS, canonical, event, model_remaining,
    run_command, save, sha,
)


OVERHEAD = 1024**3


def protected_names():
    return {row["filename"] for row in json.loads((OPS / "VERIFIED_REUSE.json").read_text())}


def release_eligible(item):
    path = WHEELS / item["filename"]
    if item["filename"] in protected_names() or path.parent != WHEELS:
        return False
    if not path.exists():
        return True
    result = path.lstat()
    return stat.S_ISREG(result.st_mode) and result.st_nlink == 1 and not path.is_symlink()


def ordered(items):
    return sorted(items, key=lambda item: (-item["uncompressed_bytes"], item["name"]))


def space_report(items, label):
    missing = sum(item["bytes"] for item in items if not (WHEELS / item["filename"]).exists())
    free = shutil.disk_usage(ROOT).free
    projected = free - missing
    stages = []
    for item in ordered(items):
        required = item["uncompressed_bytes"] + OVERHEAD + MIN_FREE + model_remaining()
        reclaim = item["bytes"] if release_eligible(item) else 0
        stages.append({"name": item["name"], "free_before": projected,
                       "required_free": required, "new_wheel_reclaim_after_verification": reclaim,
                       "sufficient": projected >= required})
        projected += reclaim - item["uncompressed_bytes"]
    report = {"schema": "hepta.runtime-streaming-space-plan.v1", "label": label,
              "free_bytes": free, "missing_compressed_bytes": missing,
              "minimum_free_bytes": MIN_FREE, "per_install_overhead_bytes": OVERHEAD,
              "projected_final_free_bytes": projected, "stages": stages,
              "sufficient": all(stage["sufficient"] for stage in stages),
              "old_files_or_model_materials_released": False,
              "missing_partial_is_budgeted_as_full_file": True}
    save(label + ".json", report)
    if not report["sufficient"]:
        raise OSError("individual installation plan cannot preserve the 1.5 GiB reserve")
    return report


def release_verified(item, installation, verification):
    path = WHEELS / item["filename"]
    if not release_eligible(item):
        return {"released": False, "filename": item["filename"],
                "reason": "protected original or non-exclusive wheel"}
    installed = json.loads((OPS / installation).read_text())
    checked = json.loads((OPS / verification).read_text())
    assert installed["exit_code"] == 0 and checked["exit_code"] == 0
    result = checked["result"]
    assert result["distribution"] == canonical(item["name"]) and result["version"] == item["version"]
    manifest = Path(result["manifest_path"])
    assert manifest.parent == OPS and not manifest.is_symlink()
    assert manifest.stat().st_size == result["manifest_bytes"] and sha(manifest) == result["manifest_sha256"]
    assert result["record_files"] > 0 and result["record_hashes_verified"] > 0
    before = path.lstat()
    assert before.st_nlink == 1 and before.st_size == item["bytes"]
    assert sha(path) == item["sha256"]
    raw = {"schema": "hepta.verified-owned-wheel-release.v1", "path": str(path),
           "filename": item["filename"], "bytes": before.st_size, "sha256": item["sha256"],
           "device": before.st_dev, "inode": before.st_ino, "links": before.st_nlink,
           "free_bytes_before": shutil.disk_usage(ROOT).free,
           "installation_receipt": installation, "installed_files_receipt": verification,
           "installation_receipt_sha256": sha(OPS / installation),
           "installed_files_receipt_sha256": sha(OPS / verification),
           "scope": "new complete wheel inside this recovery wheelhouse only"}
    prefix = "RELEASE_" + canonical(item["name"])
    save(prefix + "_PREPARED.json", raw)
    after = path.lstat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_nlink) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_nlink
    )
    path.unlink()
    receipt = {**raw, "released": True, "free_bytes_after": shutil.disk_usage(ROOT).free}
    save(prefix + "_COMPLETE.json", receipt)
    return receipt


def install_individually(items, requirements):
    receipts = []
    started = time.monotonic()
    for item in ordered(items):
        remaining = int(1200 - (time.monotonic() - started))
        if remaining <= 0:
            raise TimeoutError("individual offline installation reached its 1200 second budget")
        path = WHEELS / item["filename"]
        assert path.parent == WHEELS and not path.is_symlink()
        assert path.stat().st_size == item["bytes"] and sha(path) == item["sha256"]
        free = shutil.disk_usage(ROOT).free
        if free < item["uncompressed_bytes"] + OVERHEAD + MIN_FREE + model_remaining():
            raise OSError("space changed before an individual wheel installation")
        name = canonical(item["name"])
        report = OPS / ("PIP_INSTALL_" + name + ".json")
        one_requirement = OPS / ("INSTALL_REQUIREMENT_" + name + ".txt")
        with one_requirement.open("x") as stream:
            stream.write(str(path) + " --hash=sha256:" + item["sha256"] + "\n")
        command_name = "INSTALL_COMMAND_" + name + ".json"
        command = run_command(command_name,
            [PYTHON, "-I", "-B", "-m", "pip", "install", "--no-index", "--no-deps",
             "--force-reinstall", "--require-hashes", "--no-cache-dir", "--no-compile",
             "--disable-pip-version-check", "--report", str(report), "-r", str(one_requirement)], min(600, remaining))
        actual = json.loads(report.read_text())["install"]
        assert len(actual) == 1 and canonical(actual[0]["metadata"]["name"]) == name
        assert actual[0]["metadata"]["version"] == item["version"]
        remaining = int(1200 - (time.monotonic() - started))
        if remaining <= 0:
            raise TimeoutError("individual offline installation reached its 1200 second budget")
        verification_name = "INSTALLED_RECORD_" + name + ".json"
        verification = run_command(verification_name,
            [PYTHON, "-I", "-B", str(OPS / "verify_installed_wheel_03.py"), name, item["version"],
             str(OPS / ("INSTALLED_FILES_" + name + ".json.gz"))], min(300, remaining), parse=True)
        release = release_verified(item, command_name, verification_name)
        if shutil.disk_usage(ROOT).free < MIN_FREE + model_remaining():
            raise OSError("post-install free space crossed the protected reserve")
        receipts.append({"name": name, "version": item["version"], "command": command_name,
                         "command_sha256": sha(OPS / command_name), "pip_report": report.name,
                         "pip_report_sha256": sha(report), "verification": verification_name,
                         "verification_sha256": sha(OPS / verification_name),
                         "installed_files": verification["result"], "release": release})
        event({"stage": "individual_wheel_installed", "name": name, "version": item["version"],
               "new_wheel_released": release["released"], "free_bytes": shutil.disk_usage(ROOT).free})
    result = {"schema": "hepta.individual-offline-wheel-install.v1", "offline": True,
              "no_deps": True, "require_hashes": True, "commands": receipts,
              "requirements_sha256": sha(requirements),
              "release_policy": "only new exclusive complete wheels after installed RECORD verification"}
    save("INSTALL_RECEIPTS.json", result)
    return result
