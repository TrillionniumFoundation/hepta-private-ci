"""Resume bounded CUDA materialization after the exact preceding deadline failure."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from cuda_runtime_materials_03 import (
    CHUNK, DOWNLOADS, EXPECTED, KEY, MIN_FREE, OPS, PYTHON, ROOT, WHEELS, WORKERS,
    Parser, Requirement, active_target_pip, canonical, concurrent, configure_torch,
    event, hashlib, json, materialize, model_remaining, pypi_item, reserve, run_command, save, sha,
    shutil, time, unpacked_size, urllib,
)

from cuda_runtime_install_03 import install_individually, space_report

save("MATERIALIZE_STARTED_RESUME03.json", {"at_ns": time.time_ns(), "operation_key": KEY,
                                 "model_loaded": False, "training_started": False})
try:
    prior_failed = json.loads((OPS / "ENVIRONMENT_FAILED_RESUME02.json").read_text())
    if prior_failed["operation_key"] != "hepta-e1e6-v3-20261116-0c078a-cuda-recovery03-materialize-resume02" or prior_failed["error"] != "TimeoutError('bounded recovery download deadline reached')":
        raise ValueError("resume03 requires the exact previous deadline failure")
    if active_target_pip():
        raise RuntimeError("another target pip install remains active")
    (OPS / "pip-tmp").mkdir(exist_ok=True)
    TORCH = json.loads((OPS / "TORCH_UPSTREAM.json").read_text())
    configure_torch(TORCH)
    raw_metadata = (OPS / "TORCH_METADATA.txt").read_bytes()
    if hashlib.sha256(raw_metadata).hexdigest() != TORCH["metadata_sha256"]:
        raise ValueError("Torch metadata identity changed")
    metadata = Parser().parsestr(raw_metadata.decode())
    if metadata["Version"] != EXPECTED["torch"]:
        raise ValueError("Torch metadata version mismatch")
    bootstrap = [{"name": "torch", "version": EXPECTED["torch"], "filename": TORCH["wheel_filename"],
                  "url": TORCH["range_download_url"], "sha256": TORCH["wheel_sha256"],
                  "bytes": 900881648, "upstream_metadata": "operations/recovery-03/TORCH_UPSTREAM.json"}]
    required_gpu = []
    for line in metadata.get_all("Requires-Dist", []):
        requirement = Requirement(line)
        if requirement.marker is not None and not requirement.marker.evaluate({"extra": ""}):
            continue
        if canonical(requirement.name).startswith("nvidia-") or canonical(requirement.name) == "triton":
            specs = list(requirement.specifier)
            if len(specs) != 1 or specs[0].operator != "==":
                raise ValueError("GPU dependency is not exactly pinned")
            required_gpu.append((requirement.name, specs[0].version))
    with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
        bootstrap.extend(pool.map(lambda pair: pypi_item(*pair), required_gpu))
    with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
        bootstrap = list(pool.map(unpacked_size, bootstrap))
    save("BOOTSTRAP_WHEEL_PLAN_RESUME03.json", {"items": bootstrap, "workers": WORKERS, "chunk_bytes": CHUNK})
    space_report(bootstrap, "BOOTSTRAP_SPACE_PLAN_RESUME03")
    prior = json.loads((OPS / "PREFLIGHT.json").read_text())
    seed_by_name = {Path(row["path"]).name: row for row in prior["known_wheels"] if not row.get("zip_complete")}
    for item in bootstrap:
        seed = seed_by_name.get(item["filename"]) if item["name"] == "nvidia-cublas-cu12" else None
        materialize(item, seed=seed)
    event({"stage": "large_wheels_complete", "count": len(bootstrap)})
    plan_path = OPS / "RESOLVED_LOCAL_INSTALL_PLAN.json"
    if plan_path.exists():
        raise FileExistsError("local plan already exists")
    args = [PYTHON, "-I", "-B", "-m", "pip", "install", "--dry-run", "--ignore-installed",
            "--only-binary=:all:", "--no-cache-dir", "--disable-pip-version-check",
            "--index-url", "https://pypi.org/simple", "--report", str(plan_path)]
    args.extend(str(WHEELS / row["filename"]) for row in bootstrap)
    args.extend(name + "==" + version for name, version in EXPECTED.items() if name != "torch")
    run_command("RESOLVE_LOCAL_COMMAND.json", args, 600)
    plan = json.loads(plan_path.read_text())
    if not 6 <= len(plan["install"]) <= 80:
        raise ValueError("unexpected resolved package count")
    by_name = {row["name"]: row for row in bootstrap}
    items = []
    for row in plan["install"]:
        name, version = canonical(row["metadata"]["name"]), row["metadata"]["version"]
        info = row["download_info"]
        pinned_sha = info["archive_info"].get("hashes", {}).get("sha256")
        if not pinned_sha:
            raise ValueError("pip plan lacks a SHA256 digest")
        if name in by_name:
            item = by_name[name]
            if item["sha256"] != pinned_sha or item["version"] != version:
                raise ValueError("local large wheel changed in dependency plan")
        else:
            filename = urllib.parse.unquote(urllib.parse.urlparse(info["url"]).path.rsplit("/", 1)[-1])
            item = unpacked_size(pypi_item(name, version, filename, pinned_sha))
        items.append(item)
    actual_pins = {row["name"]: row["version"] for row in items}
    if any(actual_pins.get(name) != version for name, version in EXPECTED.items()):
        raise ValueError("requested package versions did not resolve exactly")
    save("DOWNLOAD_PLAN.json", {"items": items, "pip_plan_sha256": sha(plan_path)})
    space_report(items, "FINAL_SPACE_PLAN")
    for item in items:
        if item["name"] not in by_name:
            materialize(item)
    for item in items:
        path = WHEELS / item["filename"]
        if path.stat().st_size != item["bytes"] or sha(path) != item["sha256"]:
            raise ValueError("wheel changed before offline installation")
    save("DOWNLOAD_MANIFEST.json", {"schema": "hepta.runtime-wheel-materials.v1",
        "items": DOWNLOADS, "range_receipts_sha256": sha(OPS / "RANGE_RECEIPTS.jsonl"),
        "bootstrap_plan_sha256": sha(OPS / "BOOTSTRAP_WHEEL_PLAN_RESUME03.json"),
        "model_loaded": False, "all_full_sha256_verified": True})
    requirements = OPS / "OFFLINE_REQUIREMENTS.txt"
    with requirements.open("x") as stream:
        for item in items:
            stream.write(str(WHEELS / item["filename"]) + " --hash=sha256:" + item["sha256"] + "\n")
    space_report(items, "BEFORE_INSTALL_SPACE_PLAN")
    install_individually(items, requirements)
    event({"stage": "installed", "package_count": len(items)})
    pip_check = run_command("PIP_CHECK.json", [PYTHON, "-I", "-B", "-m", "pip", "check"], 90)
    pip_list = run_command("PIP_LIST.json", [PYTHON, "-I", "-B", "-m", "pip", "list", "--format=json"], 90, parse=True)
    freeze = run_command(None, [PYTHON, "-I", "-B", "-m", "pip", "freeze", "--all"], 90)
    freeze["distributions"] = {canonical(row["name"]): row["version"] for row in pip_list["result"]}
    freeze["distributions_source"] = "operations/recovery-03/PIP_LIST.json"
    save("PIP_FREEZE.json", freeze)
    probe = """import json,sys
from pathlib import Path
import torch,transformers,peft,safetensors,tokenizers,numpy
versions={'torch':torch.__version__,'transformers':transformers.__version__,'peft':peft.__version__,'safetensors':safetensors.__version__,'tokenizers':tokenizers.__version__,'numpy':numpy.__version__}
expected={'torch':'2.9.1+cu128','transformers':'4.57.3','peft':'0.18.0','safetensors':'0.7.0','tokenizers':'0.22.2','numpy':'1.26.4'}
assert versions==expected
assert sys.flags.isolated==1 and sys.dont_write_bytecode
assert Path(sys.prefix)==Path('/home/qian-qi/hepta-cell-experiments-v3-20261116-0c078a/venv')
assert Path(torch.__file__).resolve().is_relative_to(Path(sys.prefix).resolve())
assert torch.cuda.is_available() and torch.version.cuda=='12.8'
assert torch.cuda.is_bf16_supported()
assert torch.cuda.get_device_capability(0)[0]>=8
a=torch.ones((32,32),device='cuda:0',dtype=torch.bfloat16)
b=torch.ones((32,32),device='cuda:0',dtype=torch.bfloat16)
c=a@b
torch.cuda.synchronize()
error=float((c.float()-32).abs().max().item())
assert c.device.type=='cuda' and c.dtype==torch.bfloat16 and error==0.0
cuda={'available':True,'build':torch.version.cuda,'bf16_supported':True,'bf16_matmul_verified':True,'device_index':0,'device_name':torch.cuda.get_device_name(0),'free_total_bytes':list(torch.cuda.mem_get_info(0))}
print(json.dumps({'versions':versions,'cuda':cuda,'bf16_validation':{'shape':[32,32],'dtype':str(c.dtype),'device':str(c.device),'max_abs_error':error},'python':sys.executable,'prefix':sys.prefix,'torch_location':torch.__file__,'model_loaded':False}))
"""
    runtime = run_command("RUNTIME_PROBE.json", [PYTHON, "-I", "-B", "-c", probe], 120, parse=True)
    run_command("GPU_STATUS.json", ["nvidia-smi", "--query-gpu=name,driver_version,memory.total,memory.free",
                                   "--format=csv,noheader,nounits"], 30)
    if shutil.disk_usage(ROOT).free < reserve():
        raise OSError("post-install space cannot preserve the required reserve")
    old_failure = ROOT / "operations/recovery-02/ENVIRONMENT_FAILED.json"
    if not json.loads(old_failure.read_text())["error"].startswith("TimeoutExpired("):
        raise ValueError("prior failure identity changed")
    all_paths = sorted(path for path in OPS.iterdir()
                       if path.is_file() and path.name != "RECOVERY_EVENTS.jsonl")
    save("EVIDENCE_INDEX_RESUME03.json", {
        "schema": "hepta.runtime-recovery-evidence-index.v1",
        "members": [{"path": str(path.relative_to(ROOT)), "sha256": sha(path),
                     "bytes": path.stat().st_size} for path in all_paths],
        "excluded_live_event_log": "RECOVERY_EVENTS.jsonl",
    })
    files = ["PREFLIGHT.json", "TORCH_UPSTREAM.json", "TORCH_INDEX.html", "TORCH_METADATA.txt",
        "VERIFIED_REUSE.json", "BOOTSTRAP_WHEEL_PLAN_RESUME03.json", "BOOTSTRAP_SPACE_PLAN_RESUME03.json",
        "RESOLVED_LOCAL_INSTALL_PLAN.json", "RESOLVE_LOCAL_COMMAND.json", "DOWNLOAD_PLAN.json",
        "FINAL_SPACE_PLAN.json", "DOWNLOAD_MANIFEST.json", "RANGE_RECEIPTS.jsonl",
        "BEFORE_INSTALL_SPACE_PLAN.json", "OFFLINE_REQUIREMENTS.txt", "SPACE_OBSERVATION_01.json",
        "INSTALL_RECEIPTS.json", "PIP_CHECK.json", "PIP_LIST.json",
        "PIP_FREEZE.json", "RUNTIME_PROBE.json", "GPU_STATUS.json", "EVIDENCE_INDEX_RESUME03.json",
        "RECOVERY_IMPLEMENTATION.py", "RECOVERY_RESUME_01.py", "RECOVERY_RESUME_02.py",
        "RECOVERY_RESUME_03_SPACE.py", "cuda_runtime_materials_03.py",
        "cuda_runtime_install_03.py", "verify_installed_wheel_03.py",
        "ENVIRONMENT_FAILED.json", "ENVIRONMENT_FAILED_RESUME01.json", "ENVIRONMENT_FAILED_RESUME02.json"]
    files.extend(path.name for path in all_paths
                 if path.name.startswith(("RESUMED_RANGES_03_", "RANGE_RECEIPTS_BEFORE_RESUME_03_")))
    assert 7 <= len(files) <= 64 and len(files) == len(set(files))
    checks = [{"path": str((OPS / name).relative_to(ROOT)), "sha256": sha(OPS / name),
               "bytes": (OPS / name).stat().st_size} for name in files]
    ready = {"schema": "hepta.cuda-runtime-recovery.v3", "status": "READY", "recovery_id": "recovery-03",
        "root": str(ROOT), "python": PYTHON, "versions": runtime["result"]["versions"],
        "cuda": runtime["result"]["cuda"],
        "checks": {"pip_check_passed": True, "required_versions_match": True,
                   "isolated_python_probe_passed": True},
        "verification_files": checks,
        "prior_failure": {"path": "operations/recovery-02/ENVIRONMENT_FAILED.json",
                          "sha256": sha(old_failure), "error_type": "TimeoutExpired", "timeout_seconds": 1200},
        "model_loaded": False, "training_started": False, "completed_at_ns": time.time_ns(),
        "free_bytes_after": shutil.disk_usage(ROOT).free,
        "ongoing_model_remaining_bytes": model_remaining(),
        "operation_key": KEY,
        "superseded_download_attempt": {"failure_path": "operations/recovery-03/ENVIRONMENT_FAILED_RESUME02.json",
             "sha256": sha(OPS / "ENVIRONMENT_FAILED_RESUME02.json"), "reason": "preserved all verified ranges after bounded download deadline; eight persistent connections"}}
    save("ENVIRONMENT_READY.json", ready)
    event({"stage": "ENVIRONMENT_READY", "versions": ready["versions"], "cuda": ready["cuda"],
           "free_bytes_after": ready["free_bytes_after"]})
except BaseException as error:
    save("ENVIRONMENT_FAILED_RESUME03.json", {"schema": "hepta.cuda-runtime-recovery-failure.v3",
        "status": "FAILED", "error": repr(error), "completed_at_ns": time.time_ns(),
        "free_bytes": shutil.disk_usage(ROOT).free, "model_loaded": False, "training_started": False,
        "operation_key": KEY, "original_model_download_touched": False})
    event({"stage": "ENVIRONMENT_FAILED", "error": repr(error)})
    raise
