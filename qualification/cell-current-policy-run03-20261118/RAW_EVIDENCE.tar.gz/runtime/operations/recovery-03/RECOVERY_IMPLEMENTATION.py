"""Recover the isolated CUDA runtime from pinned, hash-verified public wheels."""
import concurrent.futures
from email.parser import Parser
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import zipfile
from pip._vendor.packaging.requirements import Requirement
from pip._vendor.packaging.tags import sys_tags
from pip._vendor.packaging.utils import parse_wheel_filename

ROOT = Path("/home/qian-qi/hepta-cell-experiments-v3-20261116-0c078a")
OPS = ROOT / "operations/recovery-03"
WHEELS = OPS / "wheelhouse"
PYTHON = str(ROOT / "venv/bin/python")
KEY = "hepta-e1e6-v3-20261116-0c078a-cuda-recovery03-materialize"
CHUNK = 8 * 1024**2
WORKERS = 6
MIN_FREE = 1536 * 1024**2
LOCK = threading.Lock()
START = time.time()
EXPECTED = {"torch": "2.9.1+cu128", "transformers": "4.57.3", "peft": "0.18.0",
            "safetensors": "0.7.0", "tokenizers": "0.22.2", "numpy": "1.26.4"}
ALLOWED = {"download.pytorch.org", "download-r2.pytorch.org", "files.pythonhosted.org"}
CHECK_FILES = []
DOWNLOADS = []

def canonical(name):
    return re.sub(r"[-_.]+", "-", name).lower()

def save(name, value):
    path = OPS / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
    return path

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b""):
            h.update(block)
    return h.hexdigest()

def event(value):
    with LOCK:
        with (OPS / "RECOVERY_EVENTS.jsonl").open("a") as stream:
            stream.write(json.dumps({"at_ns": time.time_ns(), **value}) + "\n")
        print(json.dumps(value), flush=True)

def get(url, limit=8 * 1024**2):
    for attempt in range(3):
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "hepta-runtime-recovery-03",
                                                          "Accept-Encoding": "identity"})
            with urllib.request.urlopen(request, timeout=35) as response:
                data = response.read(limit + 1)
            if len(data) > limit:
                raise ValueError("metadata exceeds the explicit size bound")
            return data
        except Exception:
            if attempt == 2:
                raise
            time.sleep(attempt + 1)

API = json.loads((ROOT / "operations/UPSTREAM_MODEL_API.json").read_text())
MODEL_SIZE = next(row["size"] for row in API["siblings"] if row["rfilename"] == "model.safetensors")

def model_remaining():
    path = ROOT / "materials-recovered/model.safetensors"
    return max(0, MODEL_SIZE - (path.stat().st_size if path.exists() else 0))

def reserve():
    return MIN_FREE + model_remaining()

def range_url(url, start, end):
    p = urllib.parse.urlparse(url)
    if p.scheme != "https" or p.hostname not in ALLOWED:
        raise ValueError("wheel URL outside the explicitly permitted public sources")
    query = urllib.parse.parse_qsl(p.query)
    query.append(("hepta_recovery_range", f"{start}-{end}"))
    return urllib.parse.urlunparse(p._replace(query=urllib.parse.urlencode(query), fragment=""))

def read_range(item, offset, count):
    if count == 0:
        return b""
    if not 0 < count <= 16 * 1024**2:
        raise ValueError("range request exceeds bound")
    end = offset + count - 1
    for attempt in range(3):
        try:
            request = urllib.request.Request(range_url(item["url"], offset, end),
                headers={"Range": f"bytes={offset}-{end}", "Accept-Encoding": "identity",
                         "User-Agent": "hepta-runtime-recovery-03"})
            with urllib.request.urlopen(request, timeout=45) as response:
                expected = f"bytes {offset}-{end}/{item['bytes']}"
                if response.status == 206:
                    if response.headers.get("Content-Range") != expected:
                        raise ValueError("server returned a different byte range")
                elif not (response.status == 200 and offset == 0 and count == item["bytes"]):
                    raise ValueError("server did not honor bounded Range")
                data = response.read(count + 1)
            if len(data) != count:
                raise ValueError("incomplete bounded range")
            return data
        except Exception as error:
            with LOCK:
                with (OPS / "RANGE_ERRORS.jsonl").open("a") as stream:
                    stream.write(json.dumps({"filename": item["filename"], "offset": offset,
                        "count": count, "attempt": attempt, "error": repr(error)[:400]}) + "\n")
            if attempt == 2:
                raise
            time.sleep(attempt + 1)

class RemoteZip(io.RawIOBase):
    def __init__(self, item):
        self.item = item
        self.position = 0
    def seekable(self):
        return True
    def readable(self):
        return True
    def tell(self):
        return self.position
    def seek(self, offset, whence=0):
        position = offset if whence == 0 else self.position + offset if whence == 1 else self.item["bytes"] + offset
        if not 0 <= position <= self.item["bytes"]:
            raise ValueError("invalid archive seek")
        self.position = position
        return position
    def read(self, count=-1):
        count = self.item["bytes"] - self.position if count < 0 else min(count, self.item["bytes"] - self.position)
        result = read_range(self.item, self.position, count)
        self.position += len(result)
        return result

def unpacked_size(item):
    existing = WHEELS / item["filename"]
    source = existing if existing.exists() else RemoteZip(item)
    with zipfile.ZipFile(source) as archive:
        entries = archive.infolist()
        total = sum(row.file_size for row in entries)
        if total > 8 * 1024**3 or len(entries) > 100000:
            raise ValueError("wheel expansion exceeds bound")
        item["uncompressed_bytes"] = total
        item["zip_member_count"] = len(entries)
    return item

TAGS = {tag: index for index, tag in enumerate(sys_tags())}

def pypi_item(name, version, filename=None, expected_sha=None):
    path = OPS / ("PYPI_" + canonical(name) + ".json")
    if path.exists():
        record = json.loads(path.read_text())
        selected = record["selected_file"]
        if filename is not None and selected["filename"] != filename:
            raise ValueError("pinned existing wheel identity conflicts")
    else:
        url = f"https://pypi.org/pypi/{name}/{version}/json"
        raw = get(url)
        payload = json.loads(raw)
        candidates = []
        for row in payload["urls"]:
            if row.get("packagetype") != "bdist_wheel" or row.get("yanked"):
                continue
            if filename is not None and row["filename"] != filename:
                continue
            parsed_name, parsed_version, _, tags = parse_wheel_filename(row["filename"])
            priorities = [TAGS[tag] for tag in tags if tag in TAGS]
            if priorities and canonical(parsed_name) == canonical(name) and str(parsed_version) == version:
                candidates.append((min(priorities), row["filename"], row))
        if not candidates:
            raise ValueError("no compatible pinned binary wheel: " + name + "==" + version)
        selected = min(candidates, key=lambda row: (row[0], row[1]))[2]
        save(path.name, {"url": url, "metadata_sha256": hashlib.sha256(raw).hexdigest(),
                         "selected_file": selected})
    digest = selected["digests"]["sha256"]
    if expected_sha is not None and digest != expected_sha:
        raise ValueError("pip plan hash differs from PyPI metadata")
    if not 0 < selected["size"] < 2 * 1024**3:
        raise ValueError("wheel size exceeds bound")
    return {"name": canonical(name), "version": version, "filename": selected["filename"],
            "url": selected["url"], "sha256": digest, "bytes": selected["size"],
            "upstream_metadata": str(path.relative_to(ROOT))}

def active_target_pip():
    active = []
    for directory in Path("/proc").iterdir():
        if not directory.name.isdigit():
            continue
        try:
            args = (directory / "cmdline").read_bytes().split(b"\0")
        except OSError:
            continue
        if args and args[0] == PYTHON.encode():
            decoded = [part.decode(errors="replace") for part in args]
            if "pip" in decoded and "install" in decoded:
                active.append(int(directory.name))
    return active

def materialize(item, seed=None):
    final = WHEELS / item["filename"]
    if final.exists():
        if final.stat().st_size != item["bytes"] or sha(final) != item["sha256"]:
            raise ValueError("existing complete wheel differs from pinned identity")
        receipt = {**item, "method": "verified_existing_complete", "path": str(final.relative_to(ROOT))}
        DOWNLOADS.append(receipt)
        event({"stage": "wheel_verified", "filename": item["filename"], "bytes": item["bytes"], "method": receipt["method"]})
        return
    partial = WHEELS / (item["filename"] + ".recovery03.part")
    begin = time.perf_counter()
    offset = 0
    seed_receipt = None
    with partial.open("xb") as output:
        if seed is not None:
            source = Path(seed["path"])
            if active_target_pip():
                raise RuntimeError("cannot reuse a partial while a target pip install is running")
            if source.stat().st_size != seed["before"]["bytes"] or sha(source) != seed["sha256"]:
                raise ValueError("partial source changed since the preserved preflight")
            with source.open("rb") as stream:
                shutil.copyfileobj(stream, output, 4 * 1024**2)
            offset = output.tell()
            seed_receipt = {"path": str(source), "bytes": offset, "sha256": seed["sha256"],
                            "method": "copied_prefix_original_unchanged"}
        output.truncate(item["bytes"])
    descriptor = os.open(partial, os.O_WRONLY)
    done = offset
    stop = threading.Event()
    requests = [(position, min(CHUNK, item["bytes"] - position))
                for position in range(offset, item["bytes"], CHUNK)]
    def one(request):
        nonlocal done
        position, count = request
        if stop.is_set():
            return
        if time.time() - START > 2400:
            raise TimeoutError("bounded recovery download deadline reached")
        if shutil.disk_usage(ROOT).free < reserve() + WORKERS * CHUNK:
            raise OSError("free space crossed the model and 1.5 GiB reserve")
        data = read_range(item, position, count)
        if os.pwrite(descriptor, data, position) != len(data):
            raise OSError("short write")
        with LOCK:
            before = done
            done += len(data)
            with (OPS / "RANGE_RECEIPTS.jsonl").open("a") as stream:
                stream.write(json.dumps({"filename": item["filename"], "offset": position,
                    "bytes": count, "sha256": hashlib.sha256(data).hexdigest()}) + "\n")
            if done == item["bytes"] or done // (128 * 1024**2) != before // (128 * 1024**2):
                print(json.dumps({"stage": "range_progress", "filename": item["filename"],
                                  "verified_range_bytes": done, "total_bytes": item["bytes"]}), flush=True)
    pool = concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS)
    futures = [pool.submit(one, request) for request in requests]
    try:
        for future in concurrent.futures.as_completed(futures):
            future.result()
    except BaseException:
        stop.set()
        for future in futures:
            future.cancel()
        raise
    finally:
        pool.shutdown(wait=True, cancel_futures=True)
        os.fsync(descriptor)
        os.close(descriptor)
    if partial.stat().st_size != item["bytes"] or sha(partial) != item["sha256"]:
        raise ValueError("full wheel SHA256 mismatch; partial retained without publication")
    with zipfile.ZipFile(partial) as archive:
        actual = sum(row.file_size for row in archive.infolist())
        if actual != item["uncompressed_bytes"]:
            raise ValueError("wheel expansion size changed")
        if item["name"] == "torch":
            names = [name for name in archive.namelist() if name.endswith(".dist-info/METADATA")]
            if len(names) != 1 or hashlib.sha256(archive.read(names[0])).hexdigest() != TORCH["metadata_sha256"]:
                raise ValueError("downloaded Torch wheel metadata differs from pinned official metadata")
    os.link(partial, final)
    partial.unlink()
    receipt = {**item, "method": "bounded_parallel_ranges", "path": str(final.relative_to(ROOT)),
               "range_count": len(requests), "range_workers": WORKERS, "wall_seconds": time.perf_counter() - begin,
               "seed": seed_receipt}
    DOWNLOADS.append(receipt)
    event({"stage": "wheel_verified", "filename": item["filename"], "bytes": item["bytes"], "method": receipt["method"]})

def run_command(name, argv, timeout, parse=False):
    begin = time.perf_counter()
    environment = {**os.environ, "TMPDIR": str(OPS / "pip-tmp"),
                   "PIP_CONFIG_FILE": os.devnull, "PIP_DISABLE_PIP_VERSION_CHECK": "1",
                   "PIP_NO_INPUT": "1", "HF_HOME": str(OPS / "hf-home"),
                   "HF_HUB_OFFLINE": "1", "TORCH_HOME": str(OPS / "torch-home"),
                   "XDG_CACHE_HOME": str(OPS / "cache"),
                   "CUDA_CACHE_PATH": str(OPS / "cuda-cache"),
                   "TRITON_CACHE_DIR": str(OPS / "triton-cache")}
    result = subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                            env=environment)
    receipt = {"argv": argv, "exit_code": result.returncode, "stdout": result.stdout,
               "stderr": result.stderr, "wall_seconds": time.perf_counter() - begin}
    if parse and result.returncode == 0:
        receipt["result"] = json.loads(result.stdout)
    if name:
        save(name, receipt)
    if result.returncode:
        raise RuntimeError((name or "command") + " failed with exit " + str(result.returncode))
    return receipt

def space_report(items, label):
    missing = sum(row["bytes"] for row in items if not (WHEELS / row["filename"]).exists())
    expansion = sum(row["uncompressed_bytes"] for row in items)
    required = missing + expansion + reserve() + 1024**3
    free = shutil.disk_usage(ROOT).free
    result = {"label": label, "free_bytes": free, "missing_compressed_bytes": missing,
              "installed_uncompressed_bytes": expansion, "other_overhead_reserve_bytes": 1024**3,
              "minimum_free_bytes": MIN_FREE, "ongoing_model_remaining_bytes": model_remaining(),
              "required_free_bytes": required, "sufficient": free >= required}
    save(label + ".json", result)
    if not result["sufficient"]:
        raise OSError("space plan cannot preserve model download and the 1.5 GiB reserve")
    return result

save("MATERIALIZE_STARTED.json", {"at_ns": time.time_ns(), "operation_key": KEY,
                                 "model_loaded": False, "training_started": False})
try:
    if active_target_pip():
        raise RuntimeError("another target pip install remains active")
    (OPS / "pip-tmp").mkdir(exist_ok=False)
    TORCH = json.loads((OPS / "TORCH_UPSTREAM.json").read_text())
    raw_metadata = (OPS / "TORCH_METADATA.txt").read_bytes()
    if hashlib.sha256(raw_metadata).hexdigest() != TORCH["metadata_sha256"]:
        raise ValueError("Torch metadata identity changed")
    metadata = Parser().parsestr(raw_metadata.decode())
    if metadata["Version"] != EXPECTED["torch"]:
        raise ValueError("Torch metadata version mismatch")
    bootstrap = [{"name": "torch", "version": EXPECTED["torch"], "filename": TORCH["wheel_filename"],
                  "url": TORCH["range_download_url"], "sha256": TORCH["wheel_sha256"],
                  "bytes": 900881648, "upstream_metadata": "operations/recovery-03/TORCH_UPSTREAM.json"}]
    required_gpu = []
    for line in metadata.get_all("Requires-Dist", []):
        requirement = Requirement(line)
        if requirement.marker is not None and not requirement.marker.evaluate({"extra": ""}):
            continue
        if canonical(requirement.name).startswith("nvidia-") or canonical(requirement.name) == "triton":
            specs = list(requirement.specifier)
            if len(specs) != 1 or specs[0].operator != "==":
                raise ValueError("GPU dependency is not exactly pinned")
            required_gpu.append((requirement.name, specs[0].version))
    with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
        bootstrap.extend(pool.map(lambda pair: pypi_item(*pair), required_gpu))
    with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
        bootstrap = list(pool.map(unpacked_size, bootstrap))
    save("BOOTSTRAP_WHEEL_PLAN.json", {"items": bootstrap, "workers": WORKERS, "chunk_bytes": CHUNK})
    space_report(bootstrap, "BOOTSTRAP_SPACE_PLAN")
    prior = json.loads((OPS / "PREFLIGHT.json").read_text())
    seed_by_name = {Path(row["path"]).name: row for row in prior["known_wheels"] if not row.get("zip_complete")}
    for item in bootstrap:
        seed = seed_by_name.get(item["filename"]) if item["name"] == "nvidia-cublas-cu12" else None
        materialize(item, seed=seed)
    event({"stage": "large_wheels_complete", "count": len(bootstrap)})
    plan_path = OPS / "RESOLVED_LOCAL_INSTALL_PLAN.json"
    if plan_path.exists():
        raise FileExistsError("local plan already exists")
    args = [PYTHON, "-I", "-B", "-m", "pip", "install", "--dry-run", "--ignore-installed",
            "--only-binary=:all:", "--no-cache-dir", "--disable-pip-version-check",
            "--index-url", "https://pypi.org/simple", "--report", str(plan_path)]
    args.extend(str(WHEELS / row["filename"]) for row in bootstrap)
    args.extend(name + "==" + version for name, version in EXPECTED.items() if name != "torch")
    run_command("RESOLVE_LOCAL_COMMAND.json", args, 600)
    plan = json.loads(plan_path.read_text())
    if not 6 <= len(plan["install"]) <= 80:
        raise ValueError("unexpected resolved package count")
    by_name = {row["name"]: row for row in bootstrap}
    items = []
    for row in plan["install"]:
        name, version = canonical(row["metadata"]["name"]), row["metadata"]["version"]
        info = row["download_info"]
        pinned_sha = info["archive_info"].get("hashes", {}).get("sha256")
        if not pinned_sha:
            raise ValueError("pip plan lacks a SHA256 digest")
        if name in by_name:
            item = by_name[name]
            if item["sha256"] != pinned_sha or item["version"] != version:
                raise ValueError("local large wheel changed in dependency plan")
        else:
            filename = urllib.parse.unquote(urllib.parse.urlparse(info["url"]).path.rsplit("/", 1)[-1])
            item = unpacked_size(pypi_item(name, version, filename, pinned_sha))
        items.append(item)
    actual_pins = {row["name"]: row["version"] for row in items}
    if any(actual_pins.get(name) != version for name, version in EXPECTED.items()):
        raise ValueError("requested package versions did not resolve exactly")
    save("DOWNLOAD_PLAN.json", {"items": items, "pip_plan_sha256": sha(plan_path)})
    space_report(items, "FINAL_SPACE_PLAN")
    for item in items:
        if item["name"] not in by_name:
            materialize(item)
    for item in items:
        path = WHEELS / item["filename"]
        if path.stat().st_size != item["bytes"] or sha(path) != item["sha256"]:
            raise ValueError("wheel changed before offline installation")
    save("DOWNLOAD_MANIFEST.json", {"schema": "hepta.runtime-wheel-materials.v1",
        "items": DOWNLOADS, "range_receipts_sha256": sha(OPS / "RANGE_RECEIPTS.jsonl"),
        "bootstrap_plan_sha256": sha(OPS / "BOOTSTRAP_WHEEL_PLAN.json"),
        "model_loaded": False, "all_full_sha256_verified": True})
    requirements = OPS / "OFFLINE_REQUIREMENTS.txt"
    with requirements.open("x") as stream:
        for item in items:
            stream.write(str(WHEELS / item["filename"]) + " --hash=sha256:" + item["sha256"] + "\n")
    space_report(items, "BEFORE_INSTALL_SPACE_PLAN")
    installation = run_command("OFFLINE_INSTALL.json",
        [PYTHON, "-I", "-B", "-m", "pip", "install", "--no-index", "--no-deps", "--require-hashes",
         "--no-cache-dir", "--no-compile", "--disable-pip-version-check", "--report",
         str(OPS / "LOCAL_INSTALL_REPORT.json"), "-r", str(requirements)], 900)
    save("INSTALL_RECEIPTS.json", {"commands": [installation], "offline": True,
        "requirements_sha256": sha(requirements), "pip_report_sha256": sha(OPS / "LOCAL_INSTALL_REPORT.json")})
    event({"stage": "installed", "package_count": len(items)})
    pip_check = run_command("PIP_CHECK.json", [PYTHON, "-I", "-B", "-m", "pip", "check"], 90)
    pip_list = run_command("PIP_LIST.json", [PYTHON, "-I", "-B", "-m", "pip", "list", "--format=json"], 90, parse=True)
    freeze = run_command(None, [PYTHON, "-I", "-B", "-m", "pip", "freeze", "--all"], 90)
    freeze["distributions"] = {canonical(row["name"]): row["version"] for row in pip_list["result"]}
    freeze["distributions_source"] = "operations/recovery-03/PIP_LIST.json"
    save("PIP_FREEZE.json", freeze)
    probe = """import json,sys
from pathlib import Path
import torch,transformers,peft,safetensors,tokenizers,numpy
versions={'torch':torch.__version__,'transformers':transformers.__version__,'peft':peft.__version__,'safetensors':safetensors.__version__,'tokenizers':tokenizers.__version__,'numpy':numpy.__version__}
expected={'torch':'2.9.1+cu128','transformers':'4.57.3','peft':'0.18.0','safetensors':'0.7.0','tokenizers':'0.22.2','numpy':'1.26.4'}
assert versions==expected
assert sys.flags.isolated==1 and sys.dont_write_bytecode
assert Path(sys.prefix)==Path('/home/qian-qi/hepta-cell-experiments-v3-20261116-0c078a/venv')
assert Path(torch.__file__).resolve().is_relative_to(Path(sys.prefix).resolve())
assert torch.cuda.is_available() and torch.version.cuda=='12.8'
assert torch.cuda.is_bf16_supported()
assert torch.cuda.get_device_capability(0)[0]>=8
a=torch.ones((32,32),device='cuda:0',dtype=torch.bfloat16)
b=torch.ones((32,32),device='cuda:0',dtype=torch.bfloat16)
c=a@b
torch.cuda.synchronize()
error=float((c.float()-32).abs().max().item())
assert c.device.type=='cuda' and c.dtype==torch.bfloat16 and error==0.0
cuda={'available':True,'build':torch.version.cuda,'bf16_supported':True,'bf16_matmul_verified':True,'device_index':0,'device_name':torch.cuda.get_device_name(0),'free_total_bytes':list(torch.cuda.mem_get_info(0))}
print(json.dumps({'versions':versions,'cuda':cuda,'bf16_validation':{'shape':[32,32],'dtype':str(c.dtype),'device':str(c.device),'max_abs_error':error},'python':sys.executable,'prefix':sys.prefix,'torch_location':torch.__file__,'model_loaded':False}))
"""
    runtime = run_command("RUNTIME_PROBE.json", [PYTHON, "-I", "-B", "-c", probe], 120, parse=True)
    run_command("GPU_STATUS.json", ["nvidia-smi", "--query-gpu=name,driver_version,memory.total,memory.free",
                                   "--format=csv,noheader,nounits"], 30)
    if shutil.disk_usage(ROOT).free < reserve():
        raise OSError("post-install space cannot preserve the required reserve")
    old_failure = ROOT / "operations/recovery-02/ENVIRONMENT_FAILED.json"
    if not json.loads(old_failure.read_text())["error"].startswith("TimeoutExpired("):
        raise ValueError("prior failure identity changed")
    files = ["PREFLIGHT.json", "TORCH_UPSTREAM.json", "TORCH_INDEX.html", "TORCH_METADATA.txt",
        "VERIFIED_REUSE.json", "BOOTSTRAP_WHEEL_PLAN.json", "BOOTSTRAP_SPACE_PLAN.json",
        "RESOLVED_LOCAL_INSTALL_PLAN.json", "RESOLVE_LOCAL_COMMAND.json", "DOWNLOAD_PLAN.json",
        "FINAL_SPACE_PLAN.json", "DOWNLOAD_MANIFEST.json", "RANGE_RECEIPTS.jsonl",
        "BEFORE_INSTALL_SPACE_PLAN.json", "OFFLINE_REQUIREMENTS.txt", "OFFLINE_INSTALL.json",
        "LOCAL_INSTALL_REPORT.json", "INSTALL_RECEIPTS.json", "PIP_CHECK.json", "PIP_LIST.json",
        "PIP_FREEZE.json", "RUNTIME_PROBE.json", "GPU_STATUS.json"]
    checks = [{"path": str((OPS / name).relative_to(ROOT)), "sha256": sha(OPS / name),
               "bytes": (OPS / name).stat().st_size} for name in files]
    ready = {"schema": "hepta.cuda-runtime-recovery.v3", "status": "READY", "recovery_id": "recovery-03",
        "root": str(ROOT), "python": PYTHON, "versions": runtime["result"]["versions"],
        "cuda": runtime["result"]["cuda"],
        "checks": {"pip_check_passed": True, "required_versions_match": True,
                   "isolated_python_probe_passed": True},
        "verification_files": checks,
        "prior_failure": {"path": "operations/recovery-02/ENVIRONMENT_FAILED.json",
                          "sha256": sha(old_failure), "error_type": "TimeoutExpired", "timeout_seconds": 1200},
        "model_loaded": False, "training_started": False, "completed_at_ns": time.time_ns(),
        "free_bytes_after": shutil.disk_usage(ROOT).free,
        "ongoing_model_remaining_bytes": model_remaining(),
        "operation_key": KEY}
    save("ENVIRONMENT_READY.json", ready)
    event({"stage": "ENVIRONMENT_READY", "versions": ready["versions"], "cuda": ready["cuda"],
           "free_bytes_after": ready["free_bytes_after"]})
except BaseException as error:
    save("ENVIRONMENT_FAILED.json", {"schema": "hepta.cuda-runtime-recovery-failure.v3",
        "status": "FAILED", "error": repr(error), "completed_at_ns": time.time_ns(),
        "free_bytes": shutil.disk_usage(ROOT).free, "model_loaded": False, "training_started": False,
        "operation_key": KEY, "original_model_download_touched": False})
    event({"stage": "ENVIRONMENT_FAILED", "error": repr(error)})
    raise
