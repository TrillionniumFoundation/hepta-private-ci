"""Supplemental causal Transformer and DTW voting, frozen before confirmation."""
import argparse,hashlib,json,time
from pathlib import Path
from copy import deepcopy
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from prepare import SETS
from campaign import SEEDS,CHECKS,brier,batches,sh,write


class Encoder(nn.Module):
    def __init__(self,d,cls,width):
        super().__init__()
        self.width=width; self.nheads=2 if width==16 else 1
        self.embed=nn.Linear(d,width); self.position=nn.Parameter(torch.empty(8,width))
        nn.init.normal_(self.position,std=.02)
        self.norm1=nn.LayerNorm(width); self.qkv=nn.Linear(width,3*width);self.project=nn.Linear(width,width)
        self.norm2=nn.LayerNorm(width); self.ff=nn.Sequential(nn.Linear(width,2*width),nn.GELU(),nn.Linear(2*width,width))
        self.out=nn.Linear(2*width,cls);self.double()
    def forward(self,x):
        h=self.embed(x)+self.position
        b,t,w=h.shape
        q,k,v=self.qkv(self.norm1(h)).reshape(b,t,3,self.nheads,w//self.nheads).permute(2,0,3,1,4)
        a=F.scaled_dot_product_attention(q,k,v,is_causal=True)
        h=h+self.project(a.transpose(1,2).reshape(b,t,w))
        h=h+self.ff(self.norm2(h))
        return self.out(torch.cat((h[:,-1],h.mean(1)),1))


def dtw_distances(query,train):
    all_dist=[]
    for q in query:
        local=np.sum((q[None,:,None,:]-train[:,None,:,:])**2,-1)
        n,t1,t2=local.shape
        cost=np.full((n,t1+1,t2+1),np.inf);cost[:,0,0]=0
        for i in range(1,t1+1):
            for j in range(1,t2+1):
                cost[:,i,j]=local[:,i-1,j-1]+np.minimum(np.minimum(cost[:,i-1,j],cost[:,i,j-1]),cost[:,i-1,j-1])
        all_dist.append(cost[:,-1,-1])
    return np.stack(all_dist)


def vote(train_y,dist,k,smoothing,cls):
    ids=np.argsort(dist,axis=1,kind="stable")[:,:k]
    return (np.eye(cls)[train_y[ids]].sum(1)+smoothing)/(k+smoothing*cls)


def fit(data,out):
    out.mkdir(exist_ok=True,parents=True)
    for ds in SETS:
        tr=np.load(data/f"{ds}-fit.npz");nclass=len(tr['labels'])
        xt=torch.from_numpy(tr["x"]);yt=torch.from_numpy(tr["y"]);xd=torch.from_numpy(tr["x_dev"]);yd=tr["y_dev"]
        start=time.perf_counter();dist=dtw_distances(tr["x_dev"],tr["x"]);rows=[]
        for k in (1,3,5,9):
            for smoothing in (.1,1.):
                val=brier(vote(tr["y"],dist,k,smoothing,nclass),yd)
                rows.append(dict(k=k,smoothing=smoothing,dev_brier=val))
        write(out/f"{ds}-dtw.json",dict(selected=min(rows,key=lambda a:a["dev_brier"]),trace=rows,seconds=time.perf_counter()-start))
        for width in (4,16):
            for seed in SEEDS:
                path=out/f"{ds}-transformer{width}-{seed}.pt"
                receipt=path.with_suffix(".json")
                if path.is_file() and receipt.is_file():
                    assert sh(path)==json.loads(receipt.read_text())["sha256"]
                    continue
                full_start=time.perf_counter();best=float("inf");trace=[]
                for rate in (.001,.003,.008):
                    torch.manual_seed(seed);rng=np.random.default_rng(seed);net=Encoder(xt.shape[-1],nclass,width)
                    weights=list(net.parameters());moments=[(torch.zeros_like(v),torch.zeros_like(v)) for v in weights]
                    for step in range(97):
                        if step in CHECKS:
                            net.eval();dev=brier(batches(net,xd).softmax(-1).numpy(),yd)
                            point=dict(rate=rate,step=step,dev_brier=dev,seconds_so_far=time.perf_counter()-full_start)
                            trace.append(point)
                            if dev<best:
                                best=dev;chosen=point;state=deepcopy(net.state_dict())
                        if step==96:break
                        net.train();net.zero_grad(set_to_none=True);i=rng.integers(len(xt),size=16)
                        F.cross_entropy(net(xt[i]),yt[i]).backward()
                        with torch.no_grad():
                            norm=torch.sqrt(sum(v.grad.square().sum() for v in weights))
                            if not torch.isfinite(norm):raise ValueError("nonfinite gradient")
                            scale=min(1.,2/(norm.item()+1e-6));s=step+1
                            for v,(first,second) in zip(weights,moments):
                                g=v.grad*scale;first.lerp_(g,.1);second.mul_(.999).addcmul_(g,g,value=.001)
                                denom=second.sqrt().div_((1-.999**s)**.5).add_(1e-8)
                                v.addcdiv_(first,denom,value=-rate/(1-.9**s))
                torch.save(state,path);write(receipt,dict(sha256=sh(path),selected=chosen,trace=trace,
                  complete_search_seconds=time.perf_counter()-full_start,parameters=sum(v.numel() for v in weights)))
                print(ds,width,seed,"complete",flush=True)
    seal={p.name:sh(p) for p in out.iterdir() if p.suffix in (".json",".pt") and p.name!="SEAL.json"}
    assert len(seal)==39
    write(out/"SEAL.json",{"files":seal,"module":sh(Path(__file__)),"protocol":sh(Path(__file__).with_name("EXTRA_BASELINES.md"))})


def confirm(data,out):
    seal=json.loads((out/"SEAL.json").read_text())
    assert sh(Path(__file__))==seal["module"] and all(sh(out/f)==s for f,s in seal["files"].items())
    pred=out/"predictions";pred.mkdir(exist_ok=True)
    for ds in SETS:
        tr=np.load(data/f"{ds}-fit.npz");te=np.load(data/f"{ds}-confirm.npz");cls=len(tr['labels'])
        start=time.perf_counter();p=json.loads((out/f"{ds}-dtw.json").read_text())["selected"]
        dist=dtw_distances(te["x"],tr["x"]);prob=vote(tr["y"],dist,p["k"],p["smoothing"],cls)
        np.savez_compressed(pred/f"{ds}-dtw.npz",y=te["y"],id=te["id"],full=prob)
        write(pred/f"{ds}-dtw.json",{"seconds":time.perf_counter()-start})
        for width in (4,16):
            for seed in SEEDS:
                start=time.perf_counter();stem=f"{ds}-transformer{width}-{seed}"
                net=Encoder(tr["x"].shape[-1],cls,width)
                net.load_state_dict(torch.load(out/(stem+".pt"),weights_only=True,map_location="cpu"));net.eval()
                p=batches(net,torch.from_numpy(te["x"])).softmax(-1).numpy()
                np.savez_compressed(pred/(stem+".npz"),y=te["y"],id=te["id"],full=p)
                write(pred/(stem+".json"),{"seconds":time.perf_counter()-start})
if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("phase",choices=["fit","confirm"]);ap.add_argument("--data",type=Path,required=True);ap.add_argument("--out",type=Path,required=True)
    a=ap.parse_args();torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    (fit if a.phase=="fit" else confirm)(a.data,a.out)
