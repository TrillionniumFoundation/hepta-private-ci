"""Fit or confirm the conventional baselines in a Torch-free process."""
import argparse,hashlib,json,time
from pathlib import Path
import numpy as np
from prepare import SETS

def sh(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,obj):path.write_text(json.dumps(obj,indent=2)+"\n")
def brier(prob,y):return float(np.mean(np.sum((np.eye(prob.shape[1])[y]-prob)**2,axis=-1)))
def classical_fit(ds,data,out):
    import joblib
    from sklearn.linear_model import LogisticRegression
    from sklearn.svm import SVC
    z=np.load(data/f"{ds}-fit.npz");x=z["x"].reshape(len(z["x"]),-1);y=z["y"]
    dev=z["x_dev"].reshape(len(z["x_dev"]),-1);yd=z["y_dev"]
    for arm in ("logistic","rbf"):
        start=time.perf_counter();rows=[];best=float("inf")
        for c in (.01,.1,1.,10.,100.):
            rule=(LogisticRegression(C=c,max_iter=2000) if arm=="logistic"
                  else SVC(C=c,gamma="scale",probability=True,random_state=109))
            rule.fit(x,y)
            score=brier(rule.predict_proba(dev),yd);rows.append({"C":c,"dev_brier":score})
            if score<best:
                selected=rule;best=score;bestc=c
        path=out/f"{ds}-{arm}.joblib";joblib.dump(selected,path)
        write(out/f"{ds}-{arm}.fit.json",dict(arm=arm,C=bestc,selected_dev_brier=best,seconds=time.perf_counter()-start,
                                              trace=rows,sha256=sh(path)))

def main(phase,data,out):
    out.mkdir(exist_ok=True,parents=True)
    if phase=="fit":
        for ds in SETS:
            classical_fit(ds,data,out)
        return
    import joblib
    seal=json.loads((out/"SEAL.json").read_text())
    assert all(sh(out/f)==expected for f,expected in seal["models"].items())
    pred=out/"predictions";pred.mkdir(exist_ok=True)
    for ds in SETS:
        z=np.load(data/f"{ds}-confirm.npz")
        for arm in ("logistic","rbf"):
            stem=f"{ds}-{arm}";start=time.perf_counter()
            rule=joblib.load(out/f"{stem}.joblib");x=z["x"].reshape(len(z["x"]),-1)
            pr=rule.predict_proba(x)
            np.savez_compressed(pred/f"{stem}.npz",y=z["y"],id=z["id"],full=pr)
            write(pred/f"{stem}.json",{"seconds":time.perf_counter()-start})

if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("phase",choices=["fit","confirm"]);ap.add_argument("--data",type=Path,required=True);ap.add_argument("--out",type=Path,required=True)
    args=ap.parse_args();main(args.phase,args.data,args.out)
