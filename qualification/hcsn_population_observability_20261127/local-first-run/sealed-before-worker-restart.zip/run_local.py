"""Run the preregistered slots sequentially. All CPU math stays single-threaded."""
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
def main(raw,data,root,torchpath):
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",OPENBLAS_NUM_THREADS="1",OMP_NUM_THREADS="1",MKL_NUM_THREADS="1",MALLOC_ARENA_MAX="1")
    runlog=HERE/"local_process_receipt.jsonl"
    fitted=root/"fitted"; extra=root/"extra_fits"
    plan=[("core-fit","campaign.py",["fit","--data",data,"--out",fitted],True),
          ("extra-fit","extras.py",["fit","--data",data,"--out",extra],True),
          ("prepare-confirm","prepare.py",["confirm","--raw",raw,"--out",data],False),
          ("classical-confirm","classical_slot.py",["confirm","--data",data,"--out",fitted],False),
          ("core-confirm","campaign.py",["confirm","--data",data,"--out",fitted],True),
          ("extra-confirm","extras.py",["confirm","--data",data,"--out",extra],True),
          ("core-score","score.py",["--data",data,"--out",fitted],False)]
    for slot,module,arguments,use_torch in plan:
        if slot=="prepare-confirm":
            assert (fitted/"SEAL.json").is_file() and (extra/"SEAL.json").is_file()
        for attempt in range(1,13):
            start=time.time()
            pyenv=env | ({"PYTHONPATH":str(torchpath)} if use_torch else {})
            with (HERE/(slot+".log")).open("ab") as f:
                rc=subprocess.run([sys.executable,"-u",str(HERE/module)]+list(map(str,arguments)),env=pyenv,stdout=f,stderr=f).returncode
            with runlog.open("a") as f:f.write(json.dumps(dict(slot=slot,attempt=attempt,returncode=rc,started_unix=start,seconds=time.time()-start))+"\n")
            if rc==0:break
            if rc not in (-9,137):raise SystemExit(f"{slot} exited {rc}")
            time.sleep(min(30,3*attempt))
        else:raise SystemExit(f"{slot} exceeded transient memory retry budget")
if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("--raw",type=Path,required=True);ap.add_argument("--data",type=Path,required=True);ap.add_argument("--out",type=Path,required=True);ap.add_argument("--torchpath",type=Path,required=True)
    a=ap.parse_args();main(a.raw.resolve(),a.data.resolve(),a.out.resolve(),a.torchpath.resolve())
