"""Exact finite-support observable count and minimax moment-prediction error."""
import argparse,json,warnings
from pathlib import Path
import numpy as np
from scipy.linalg import qr
from scipy.optimize import linprog,OptimizeWarning
from hx_reference import HX,hx_boundary,hx_equity,hx_debt,first_passage_cdf

P=HX(r=.08,delta=.02,sigma=.23,coupon=6.39,principal=61.68,maturity=1.,tax=.27,recovery=.6,sale_cost=.01)
X=np.array([.025,.075,.125,.18,.235,.30,.46,.70])
def F(t,x=X):return first_passage_cdf(x,t,P.mu,P.sigma)
def price_monitors():
    E=hx_equity(X,P)
    D0=P.c/P.q+np.exp(-P.q)*(P.p-P.c/P.q)
    L=D0-hx_debt(X,1.,P,hx_boundary(P))
    return E,L
def rowrank(A,tol=1e-12):
    normalized=A/np.linalg.norm(A,axis=1,keepdims=True)
    sv=np.linalg.svd(normalized,compute_uv=False)
    return int((sv>tol*sv[0]).sum()),sv.tolist()
def minimax(A,h):
    scale=A/np.linalg.norm(A,axis=1,keepdims=True)
    k,n=scale.shape
    objective=np.r_[np.zeros(k),1.]
    H=np.vstack((np.c_[scale.T,-np.ones(n)],np.c_[-scale.T,-np.ones(n)]))
    b=np.r_[h,-h]
    kwargs=dict(method="highs",options={"threads":1,"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9})
    with warnings.catch_warnings():
        warnings.simplefilter("ignore",OptimizeWarning)
        primal=linprog(objective,A_ub=H,b_ub=b,bounds=[(None,None)]*k+[(0,None)],**kwargs)
        # Full nonnegative pairs of mass one; original A includes its constant row.
        constraints=np.vstack((np.c_[scale,-scale],np.r_[np.ones(n),np.zeros(n)],np.r_[np.zeros(n),np.ones(n)]))
        dual=linprog(np.r_[-h,h],A_eq=constraints,b_eq=np.r_[np.zeros(k),1.,1.],bounds=(0,None),**kwargs)
    assert primal.success and dual.success
    worst=abs(scale.T@primal.x[:-1]-h).max();diameter=-dual.fun
    assert abs(2*worst-diameter)<6e-8
    return {"primal_uniform_error":float(worst),"dual_diameter":float(diameter),
            "optimal_center_linear_coeffs_original_units":(primal.x[:-1]/np.linalg.norm(A,axis=1)).tolist(),
            "dual_observed_discrepancy":float(max(abs(scale@(dual.x[:n]-dual.x[n:]))))}
def run():
    E,L=price_monitors()
    base=np.stack((np.ones_like(X),E,L,F(.25))) # fixed current quarter-hit readout also available
    times=np.array([.08,.125,.2,.35,.5,.75,1.,1.5,2.,3.])
    targets=np.stack([F(t) for t in times])
    A=base/np.linalg.norm(base,axis=1,keepdims=True)
    U,s,V=np.linalg.svd(A,full_matrices=True);null=V[len(s):].T
    # Choose linearly independent probe horizons after removing existing observations.
    residual=(targets/np.linalg.norm(targets,axis=1,keepdims=True))@null
    piv=qr(residual.T,pivoting=True)[2]
    order=times[piv[:len(X)-len(base)]].tolist()
    held=[.1,.16,.42,.65,.9,1.25,1.75,2.5]
    cases=[]
    for total in range(len(order)+1):
        AA=np.vstack([base]+[F(t) for t in order[:total]])
        scores={str(t):minimax(AA,F(t)) for t in held}
        cases.append({"extra_probe_horizons":order[:total],"normalized_rank_sv":rowrank(AA),
                      "max_holdout_uniform_error":max(c["primal_uniform_error"] for c in scores.values()),"heldout":scores})
    return {"law":"Table I base, fixed P, known barrier, eight known support locations, arbitrary simplex weights",
            "anchor_times_training_bank":times.tolist(),"test_horizons":held,"base_rows":["mass","equity","priced_loss","F(.25)"],
            "base":rowrank(base),"base_and_all_future":rowrank(np.vstack((base,targets))),
            "augmented":cases,"scope":"Minimum number concerns added linear messages, not parameter count or noisy conditioning. Intermediate holdout bounds are computed only at listed horizons; full-rank reconstruction extends to arbitrary local readouts on this finite grid."}
if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("output",type=Path);a=ap.parse_args();j=run()
    a.output.write_text(json.dumps(j,indent=2)+"\n")
    print(j["base"][0],j["base_and_all_future"][0],[(v["extra_probe_horizons"],v["max_holdout_uniform_error"]) for v in j["augmented"]])
