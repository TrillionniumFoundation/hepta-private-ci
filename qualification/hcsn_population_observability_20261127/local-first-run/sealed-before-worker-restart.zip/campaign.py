"""Train, seal, then separately score frozen candidates on official test records."""
import argparse,hashlib,json,os,sys,time,resource
from pathlib import Path
from copy import deepcopy
import numpy as np
import torch
from cells import Population,LIF,OrdinaryGRU
from prepare import SETS

HERE=Path(__file__).resolve().parent
ARMS=("monetary","probability","gate","lif","gru")
SEEDS=(109,271,443)
CHECKS=(0,16,48,96)
def sh(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,obj):path.write_text(json.dumps(obj,indent=2)+"\n")
def source_digest():
    return {name:sh(HERE/name) for name in ("PROTOCOL.md","sources.json","cells.py","literal_original.py","prepare.py","campaign.py","classical_slot.py")}
def brier(prob,y):
    return float(np.mean(np.sum((np.eye(prob.shape[1])[y]-prob)**2,axis=-1)))
def network(arm,d,k):
    if arm=="lif":return LIF(d,k)
    if arm=="gru":return OrdinaryGRU(d,k)
    return Population(d,k,arm)
def batches(net,x,**kwargs):
    with torch.no_grad():
        output=[net(a,**kwargs) for a in x.split(64)]
    if kwargs.get("trace"):
        return torch.cat([o[0] for o in output]),torch.cat([o[1] for o in output])
    return torch.cat(output)
def neural_fit(ds,arm,seed,data,out):
    z=np.load(data/f"{ds}-fit.npz");x=torch.from_numpy(z['x']);y=torch.from_numpy(z['y'])
    dev=torch.from_numpy(z['x_dev']);yd=z['y_dev'];d=x.shape[-1];k=len(z['labels'])
    torch.manual_seed(seed);rng=np.random.default_rng(seed)
    start=time.perf_counter()
    net=network(arm,d,k)
    trainable=list(net.parameters())
    moments=[(torch.zeros_like(w),torch.zeros_like(w)) for w in trainable]
    best=best30=float("inf");state={};log=[]
    for step in range(97):
        if step in CHECKS:
            net.eval()
            prob=batches(net,dev).softmax(-1).numpy()
            v=brier(prob,yd);elapsed=time.perf_counter()-start
            log.append(dict(step=step,dev_brier=v,seconds=elapsed))
            for which,cond in (("best",v<best),("best30",(step==0 or elapsed<=30) and v<best30)):
                if cond:
                    state[which]=deepcopy(net.state_dict());state[which+"_step"]=step
                    if which=="best":best=v
                    else:best30=v
        if step==96:break
        net.train()
        take=rng.integers(len(y),size=16)
        net.zero_grad(set_to_none=True)
        loss=torch.nn.functional.cross_entropy(net(x[take]),y[take]);loss.backward()
        with torch.no_grad():
            norm=torch.sqrt(sum(w.grad.square().sum() for w in trainable if w.grad is not None))
            if not torch.isfinite(norm):raise FloatingPointError("gradient norm")
            scale=min(1.,2/(norm.item()+1e-6))
            # Adam defaults beta1=.9, beta2=.999, epsilon=1e-8, no weight decay.
            t=step+1
            for w,(first,second) in zip(trainable,moments):
                if w.grad is None:continue
                g=w.grad*scale
                first.lerp_(g,.1)
                second.mul_(.999).addcmul_(g,g,value=.001)
                denom=second.sqrt().div_((1-.999**t)**.5).add_(1e-8)
                w.addcdiv_(first,denom,value=-.008/(1-.9**t))
    ck=out/f"{ds}-{arm}-{seed}.pt"
    torch.save(state,ck)
    row=dict(dataset=ds,arm=arm,seed=seed,trace=log,seconds=time.perf_counter()-start,
             parameters=sum(p.numel() for p in net.parameters()),sha256=sh(ck),
             selected_step=state["best_step"],selected_30s_step=state["best30_step"],
             selected_dev_brier=best,capped_dev_brier=best30)
    write(out/f"{ds}-{arm}-{seed}.fit.json",row)

def fit(data,out):
    out.mkdir(exist_ok=True,parents=True)
    hashes=source_digest(); path=out/"fit-sources.json"
    if path.is_file():assert json.loads(path.read_text())==hashes
    else:write(path,hashes)
    for ds in SETS:
        assert (out/f"{ds}-rbf.fit.json").is_file(), "Run classical_slot.py fit first"
        for seed in SEEDS:
            ordering=list(ARMS);np.random.default_rng(seed).shuffle(ordering)
            for arm in ordering:
                result=out/f"{ds}-{arm}-{seed}.fit.json";ck=out/f"{ds}-{arm}-{seed}.pt"
                if result.is_file() and ck.is_file():
                    assert json.loads(result.read_text())["sha256"]==sh(ck)
                    continue
                st=time.perf_counter()
                neural_fit(ds,arm,seed,data,out)
                print(ds,arm,seed,"fit seconds",round(time.perf_counter()-st,2),flush=True)
    files={p.name:sh(p) for p in out.iterdir() if p.suffix in (".pt",".joblib")}
    assert len(files)==3*(5*3+2)
    choice={}
    for ds in SETS:
        dev={}
        for arm in ("gru","logistic","rbf"):
            rs=list(out.glob(f"{ds}-{arm}*.fit.json"))
            dev[arm]=float(np.mean([json.loads(p.read_text())["selected_dev_brier"] for p in rs]))
        choice[ds]={"selected_ordinary":min(dev,key=dev.get),"comparator_dev_briers":dev}
    write(out/"SEAL.json",{"sources":hashes,"models":files,"ordinary_choice":choice,
                            "train_panels":{p.name:sh(p) for p in data.glob("*-fit.npz")}})
def confirm(data,out):
    seal=json.loads((out/"SEAL.json").read_text());assert source_digest()==seal["sources"]
    assert all(sh(out/f)==s for f,s in seal["models"].items())
    pred=out/"predictions";pred.mkdir(exist_ok=True)
    for ds in SETS:
        z=np.load(data/f"{ds}-confirm.npz");x=torch.from_numpy(z["x"]);k=len(z["labels"])
        for arm in ARMS:
            for seed in SEEDS if arm in ARMS else (0,):
                stem=f"{ds}-{arm}"+(f"-{seed}" if seed else "")
                # Each record is generated from sealed CPU state, with transient models discarded after the slot.
                start=time.perf_counter()
                arrays=dict(y=z["y"],id=z["id"]);details={}
                state=torch.load(out/f"{stem}.pt",weights_only=True,map_location="cpu")
                net=network(arm,x.shape[-1],k);net.load_state_dict(state["best"]);net.eval()
                if arm not in ("gru","lif"):
                    full,t=batches(net,x,trace=True)
                    arrays["full"]=full.softmax(-1).numpy()
                    # Reduce trace before writing. Preserve per-record, per-neuron lineage.
                    for idx,name in [(0,"total_hits"),(1,"first_hits"),(2,"repeat_hits")]:
                        arrays[name]=t[...,idx].sum(1).numpy()
                    details["max_mass_error"]=float((t[...,3]-1).abs().max())
                    details["min_principal"]=float(t[...,4].min())
                    details["max_principal"]=float(t[...,4].max())
                    for rm in ("risk","both","reset"):
                        intervention=batches(net,x,remove=rm)
                        arrays["without_"+rm]=intervention.softmax(-1).numpy()
                        details["mean_abs_logit_delta_without_"+rm]=float((intervention-full).abs().mean())
                else:arrays["full"]=batches(net,x).softmax(-1).numpy()
                if state["best_step"]==state["best30_step"]:
                    arrays["cap30"]=arrays["full"]
                else:
                    net.load_state_dict(state["best30"])
                    arrays["cap30"]=batches(net,x).softmax(-1).numpy()
                np.savez_compressed(pred/f"{stem}.npz",**arrays)
                write(pred/f"{stem}.json",dict(details,seconds=time.perf_counter()-start,
                                               max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))

if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("phase",choices=["fit","confirm"]);ap.add_argument("--data",type=Path,required=True);ap.add_argument("--out",type=Path,required=True)
    a=ap.parse_args();torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    (fit if a.phase=="fit" else confirm)(a.data,a.out)
