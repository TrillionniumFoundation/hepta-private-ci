"""Exact finite-support worst-case prediction under bounded measurement errors."""
import argparse,json,warnings
from pathlib import Path
import numpy as np
from scipy.optimize import linprog,OptimizeWarning
from augmentation import X,F,price_monitors

def cap(A,h,eps):
    A=A/np.max(np.abs(A),axis=1,keepdims=True)
    m,n=A.shape
    # Variables are coefficients c, residual bound t, and bounds on |c_i| for i>0.
    r=m-1;objective=np.r_[np.zeros(m),1.,np.full(r,eps)]
    fit1=np.c_[A.T,-np.ones(n),np.zeros((n,r))]
    fit2=np.c_[-A.T,-np.ones(n),np.zeros((n,r))]
    sign=np.c_[np.zeros(r),np.eye(r)]
    s1=np.c_[sign,np.zeros(r),-np.eye(r)];s2=np.c_[-sign,np.zeros(r),-np.eye(r)]
    args={"method":"highs","options":{"threads":1,"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9}}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore",OptimizeWarning)
        p=linprog(objective,A_ub=np.vstack((fit1,fit2,s1,s2)),b_ub=np.r_[h,-h,np.zeros(2*r)],
            bounds=[(None,None)]*m+[(0,None)]*(r+1),**args)
        if not p.success:raise RuntimeError(p.message)
        aa=np.c_[A[1:],-A[1:]]
        d=linprog(np.r_[-h,h],A_ub=np.vstack((aa,-aa)),b_ub=np.full(2*r,2*eps),
            A_eq=[np.r_[np.ones(n),np.zeros(n)],np.r_[np.zeros(n),np.ones(n)]],b_eq=[1.,1.],bounds=(0,None),**args)
    if not d.success:raise RuntimeError(d.message)
    actual=max(abs(h-A.T@p.x[:m]))+eps*abs(p.x[1:m]).sum()
    assert abs(actual+d.fun/2)<2e-7
    return {"worst_case_error":actual,"dual_half_diameter":-d.fun/2,
            "residual":float(max(abs(h-A.T@p.x[:m]))),"sum_abs_coefficients_on_noisy_readouts":float(abs(p.x[1:m]).sum())}
def run():
    E,L=price_monitors();base=np.stack((np.ones(len(X)),E,L,F(.25)))
    aug=json.loads(Path(__file__).with_name("augmentation.json").read_text());result={}
    for group in aug["augmented"]:
        new=group["extra_probe_horizons"];a=np.vstack([base]+[F(t) for t in new]);rows={}
        for eps in (0.,.0001,.001,.01):
            err={str(t):cap(a,F(t),eps) for t in aug["test_horizons"]}
            rows[str(eps)]={"worst_across_holdout_horizons":max(d["worst_case_error"] for d in err.values()),
                            "by_horizon":err}
        result[str(len(new))]={"extra_probe_times":new,"error_levels":rows}
    return {"scope":"known support and law, normalized readout absolute noise bounds, exact unit mass", "results":result}
if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("output",type=Path);args=p.parse_args()
    j=run();args.output.write_text(json.dumps(j,indent=2)+"\n")
    for k,v in j["results"].items():print(k,[round(r['worst_across_holdout_horizons'],8) for r in v["error_levels"].values()])
