"""Reconcile independent source law, population mass bookkeeping, and gradients."""
import argparse,json,math
from dataclasses import replace
from pathlib import Path
import numpy as np
import torch
from cells import Prices,Population,killed_mass
from hx_reference import HX,hx_boundary,hx_debt,hx_equity

def measure(out):
    torch.set_num_threads(1);torch.manual_seed(4751)
    law=Prices()
    par=HX(r=.08,delta=.02,sigma=.23,coupon=6.39,principal=61.68,maturity=1.,tax=.27,recovery=.6,sale_cost=.01)
    money_scale=float(law.L0);equity_scale=float(law.A0)
    xvals=[0.,1e-6,1e-4,1e-3,.003,.01,.03,.08,.18,.35,.7,1.,1.3,1.6,2.]
    rows=[];forward_error=0.
    for x0 in xvals:
        for pp in [par.principal*.72,par.principal,par.principal*1.28]:
            x=torch.tensor(x0,requires_grad=True,dtype=torch.float64)
            P=torch.tensor(pp,requires_grad=True,dtype=torch.float64)
            E=law.equity(x,P)
            L=law.shortfall(x,P)
            p=replace(par,principal=pp)
            no=p.c/p.q+math.exp(-p.q)*(p.p-p.c/p.q)
            b=hx_boundary(p); ref_e=hx_equity(x0,p)
            ref_l=no-hx_debt(x0,1.,p,b)
            forward_error=max(forward_error,abs(E.item()-ref_e),abs(L.item()-ref_l),abs(b-law.boundary(P).item()))
            erow=torch.autograd.grad(E,(x,P))
            lrow=torch.autograd.grad(L,(x,P))
            j=np.array([[a.item() for a in erow],[a.item() for a in lrow]])
            if x0==0:
                # Exact right limit for loss; autograd for the constant stopped branch at equality is different.
                xr=torch.tensor(1e-12,requires_grad=True,dtype=torch.float64)
                j[1,0]=torch.autograd.grad(law.shortfall(xr,P),xr)[0].item()
            scaled=np.diag([1/equity_scale,1/money_scale])@j@np.diag([.18,.28*par.principal])
            s=np.linalg.svd(scaled,compute_uv=False)
            rows.append(dict(x=x0,P=pp,raw_jacobian=j.tolist(),raw_det=np.linalg.det(j),
                             standardized_singular_values=s.tolist(),condition=float(s[0]/max(s[1],1e-300))))
    gross=0.;minw=1.;max_err=0.;min_hit=1.
    for margin in torch.linspace(-.6,1.8,2049,dtype=torch.float64).split(256):
        M,H=killed_mass(margin,torch.tensor([0,.05,.1,.1525,.2075,.2675,.38,.58],dtype=torch.float64),law.mu,law.p.sigma)
        gross=max(gross,(M.sum(-1)+H-1).abs().max().item())
        minw=min(minw,M.min().item());min_hit=min(min_hit,H.min().item())
        target=torch.where(margin>0,law.passage(margin.clamp_min(0),.25),torch.ones_like(margin))
        max_err=max(max_err,(H-target).abs().max().item())
    model=Population(4,3)
    x=torch.randn(8,8,4,dtype=torch.float64)
    val,trace=model(x,trace=True)
    loss=val[:,0].mean();targets=[(model.rec.weight,(1,0)),(model.gains,(0,0)),(model.gains,(1,0)),(model.drive.weight,(0,1))]
    grad=torch.autograd.grad(loss,[model.rec.weight,model.gains,model.drive.weight])
    gradients=[]
    for (param,idx),ag in zip(targets,(grad[0],grad[1],grad[1],grad[2])):
        with torch.no_grad():
            orig=param[idx].item();delta=1e-5
            param[idx]=orig+delta;up=model(x)[:,0].mean().item()
            param[idx]=orig-delta;dn=model(x)[:,0].mean().item();param[idx]=orig
        fd=(up-dn)/(2*delta);g=ag[idx].item()
        gradients.append(dict(index=idx,autograd=g,centered_difference=fd,abs_error=abs(g-fd)))
    # Grid refinement over an exogenous constant law to quantify finite-bin error.
    # Start at .18, reset to .30, and keep the fixed continuous reference on the first event (before reinjection).
    refinements=[]
    for step in (.04,.02,.01,.005):
        centers=np.unique(np.r_[np.arange(step/2,2.0,step),.18,.30])
        cs=torch.tensor(centers,dtype=torch.float64)
        edges=torch.cat((cs.new_zeros(1),(cs[1:]+cs[:-1])/2))
        matrix,hits=killed_mass(cs,edges,law.mu,law.p.sigma)
        a=(cs==.18).double();init=a.clone();r=torch.tensor(0.,dtype=torch.float64)
        rr=(cs==.30).double();firsts=[];totals=[]
        for i in range(8):
            firsts.append(float(init@hits));totals.append(float(a@hits))
            init=init@matrix
            a,r=a@matrix+r*rr,a@hits
        ref=law.passage(torch.tensor(.18,dtype=torch.float64),2.).item()
        refinements.append(dict(step=step,case="constant barrier, CT first-passage exact, discrete refractory",
                             first_by_t2=sum(firsts),reference=ref,first_abs_error=abs(sum(firsts)-ref),repeat_by_t2=sum(totals)-sum(firsts)))
    scope={ "readout_rows":["equity","credit_shortfall"],"input_scales":[.18,.28*par.principal],
            "output_scales":[equity_scale,money_scale],"coordinate_units":"input (x,P); row output standardized by anchor values",
            "equity_flat_wall":True,"wall_jacobian_convention":"alive-side one-sided limit"}
    assert forward_error<2e-11 and gross<1e-12 and minw> -3e-15 and min_hit> -3e-15
    assert max(g["abs_error"] for g in gradients)<2e-7 and trace[...,3].sub(1).abs().max()<1e-12
    result={"standardization":scope,"jacobian_grid":rows,"max_source_law_forward_error":forward_error,
            "kernel_checks":{"max_mass_error":gross,"min_kernel_entry":minw,"min_hit":min_hit,"max_hit_disagreement":max_err},
            "network_checks":{"mass_error":float((trace[...,3]-1).abs().max().detach()),"sum_hit_per_unit":float(trace[...,0].sum(1).mean().detach()),
                              "sum_repeat_per_unit":float(trace[...,2].sum(1).mean().detach()),"parameters_gradient_order":["recurrent","equity_gain","loss_gain","input"],
                              "gradients":gradients},"mesh_refinement":refinements}
    out.write_text(json.dumps(result,indent=2)+"\n")
if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("output",type=Path);measure(ap.parse_args().output)
