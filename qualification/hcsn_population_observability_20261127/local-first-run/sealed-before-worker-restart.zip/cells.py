"""Finite-state, resettable populations with analytic stationary He–Xiong observables."""
import math
import torch
from torch import nn
from torch.nn import functional as functional
from literal_original import Published

DT = .25
CENTERS = (.025, .075, .125, .18, .235, .30, .46, .70)


class Prices(Published):
    def __init__(self):
        super().__init__()
        x = torch.tensor(.18, dtype=torch.float64, requires_grad=True)
        principal = torch.tensor(self.p.P0, dtype=torch.float64, requires_grad=True)
        with torch.enable_grad():
            loss = self.shortfall(x, principal)
            equity = self.equity(x, principal)
            lx, lp = torch.autograd.grad(loss, (x, principal))
            ep, = torch.autograd.grad(equity, principal)
        for name, value in (("L0", loss), ("Lx", lx), ("Lp", lp), ("Ep", ep)):
            self.register_buffer(name, value.detach())

    def shortfall(self, x, principal):
        h = self.p.m
        std = self.p.sigma * math.sqrt(h)
        chi = math.sqrt(self.mu**2 + 2*self.q*self.var)
        xlive = x.clamp_min(0)
        def term(sign):
            normal = (-xlive - sign*chi*h) / std
            return torch.exp((-self.mu + sign*chi)*xlive/self.var) * torch.special.ndtr(normal)
        discounted = term(1) + term(-1)
        cash = self.c / self.q
        par = principal / self.p.m
        recovery = self.p.alpha * self.boundary(principal) / self.p.m
        Fh = self.passage(xlive,h)
        value = math.exp(-self.q*h)*(par-cash)*Fh + (cash-recovery)*discounted
        at_wall = cash + math.exp(-self.q*h)*(par-cash) - recovery
        return torch.where(x>0,value,at_wall)

    def features(self,x,principal,kind):
        p = self.p
        if kind == "gate":
            dx = .18 * torch.tanh((x-.18)/.18)
            dp = (.28*p.P0) * torch.tanh((principal-p.P0)/(.28*p.P0))
            return (self.dA0*dx + self.Ep*dp)/20, (self.Lx*dx + self.Lp*dp)*self.dF0/self.Lx
        live = x.clamp_min(0)
        equity = (torch.where(x>0,self.equity(live,principal),torch.zeros_like(x)) - self.A0)/20
        if kind == "probability":
            risk = torch.where(x>0,self.passage(live,p.m),torch.ones_like(x)) - self.F0
        else:
            risk = (self.shortfall(x,principal)-self.L0) * self.dF0/self.Lx
        return equity,risk


def killed_mass(margin, edges, mu, sigma, interval=DT):
    """Survival at each lower bin edge from the killed transition image solution."""
    z = margin.clamp_min(0)[...,None]
    std = sigma * math.sqrt(interval)
    first = (z+mu*interval-edges)/std
    image = (-z+mu*interval-edges)/std
    survival = torch.special.ndtr(first)-torch.exp(-2*mu*z/sigma**2)*torch.special.ndtr(image)
    survival = torch.where(margin[...,None]>0,survival,torch.zeros_like(survival))
    matrix = torch.cat((survival[...,:-1]-survival[...,1:],survival[...,-1:]),dim=-1)
    return matrix,1-survival[...,0]


class Population(nn.Module):
    def __init__(self,d,nclasses,kind="monetary",n=4,centers=CENTERS):
        super().__init__()
        self.kind=kind
        self.law=Prices()
        self.drive=nn.Linear(d,n)
        self.rec=nn.Linear(n,n,bias=False)
        self.gains=nn.Parameter(torch.full((2,n),math.log(math.expm1(.4))))
        self.readout=nn.Linear(4*n,nclasses)
        c=torch.tensor(centers,dtype=torch.float64)
        self.register_buffer("centers",c)
        self.register_buffer("edges",torch.cat((c.new_zeros(1),.5*(c[1:]+c[:-1]))))
        self.register_buffer("initial",(c==.18).to(c))
        self.register_buffer("reset",(c==.30).to(c))
        assert self.initial.sum()==1 and self.reset.sum()==1
        self.double()

    def forward(self,series,remove="",trace=False):
        xx=series
        n=self.drive.out_features
        nrows=len(series)
        b=xx.new_zeros(nrows,n)
        equity=risk=refractory=b
        active=self.initial.expand(nrows,n,-1)
        if trace:
            never=active
        gains=functional.softplus(self.gains)
        bs,flows,events=[],[],[]
        for frame in xx.unbind(1):
            drive=self.drive(frame)+self.rec(b)
            if remove not in ("both","equity"):
                drive=drive+gains[0]*torch.tanh(equity)
            if remove not in ("both","risk"):
                drive=drive+gains[1]*torch.tanh(risk)
            principal=self.law.p.P0*(1+.28*torch.tanh(drive))
            newb=torch.log(self.law.boundary(principal)/self.law.B0)
            margin=self.centers+(b-newb)[...,None]
            e,l=self.law.features(margin,principal[...,None],self.kind)
            equity=(active*e).sum(-1)
            risk=(active*l).sum(-1)
            matrix,hit=killed_mass(margin,self.edges,self.law.mu,self.law.p.sigma)
            flux=(active*hit).sum(-1)
            newactive=(active[...,None]*matrix).sum(-2)
            if remove!="reset":
                newactive=newactive+refractory[...,None]*self.reset
                refractory=flux
            else:
                refractory=refractory+flux
            if trace:
                first_hit=(never*hit).sum(-1)
                never=(never[...,None]*matrix).sum(-2)
                events.append(torch.stack((flux,first_hit,flux-first_hit,
                                            newactive.sum(-1)+refractory,principal,newb,
                                            equity,risk),-1))
            active,b=newactive,newb
            bs.append(b);flows.append(flux)
        bounds=torch.stack(bs,1); fluxes=torch.stack(flows,1)
        y=self.readout(torch.cat((b,flows[-1],bounds.mean(1),fluxes.mean(1)),-1))
        return (y,torch.stack(events,1)) if trace else y


class LIF(nn.Module):
    def __init__(self,d,nclasses,n=4):
        super().__init__()
        self.drive=nn.Linear(d,n); self.rec=nn.Linear(n,n,bias=False)
        self.dynamics=nn.Parameter(torch.zeros(2,n))
        self.readout=nn.Linear(4*n,nclasses); self.double()

    def forward(self,series):
        u=series.new_zeros(len(series),self.drive.out_features)
        spike=u
        threshold=.3+functional.softplus(self.dynamics[1])
        decay=torch.sigmoid(self.dynamics[0])
        potentials=[];spikes=[]
        for frame in series.unbind(1):
            pre=decay*u+self.drive(frame)+self.rec(spike)
            soft=torch.sigmoid(5*(pre-threshold))
            spike=(pre>=threshold).to(pre)+soft-soft.detach()
            u=pre-spike*threshold
            potentials.append(pre);spikes.append(spike)
        return self.readout(torch.cat((pre,spike,torch.stack(potentials,1).mean(1),
                                       torch.stack(spikes,1).mean(1)),-1))


class OrdinaryGRU(nn.Module):
    def __init__(self,d,nclasses,n=4):
        super().__init__()
        self.gru=nn.GRU(d,n,batch_first=True);self.readout=nn.Linear(2*n,nclasses);self.double()
    def forward(self,series):
        h,_=self.gru(series)
        return self.readout(torch.cat((h[:,-1],h.mean(1)),-1))
