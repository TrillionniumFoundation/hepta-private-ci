"""Construct positive distributions agreeing in present messages and disagreeing in future risk.

For a fixed physical law, each recorded-signal row is linear in the initial population
weights. If a target row is outside their span with total mass included, some two
strictly positive probability vectors yield the same messages and different targets.
We choose an SVD-nullspace witness as an explicit constructive certificate. No fitted data.
"""
import json
from pathlib import Path
import numpy as np
from hx_reference import HX,hx_debt,hx_equity,hx_boundary,first_passage_cdf

def run():
    law=HX(r=.08,delta=.02,sigma=.23,coupon=6.39,principal=61.68,maturity=1.,tax=.27,recovery=.6,sale_cost=.01)
    x=np.array([.025,.075,.125,.18,.235,.30,.46,.70])
    def F(t):return first_passage_cdf(x,t,law.mu,law.sigma)
    E=hx_equity(x,law);b=hx_boundary(law)
    D0=law.c/law.q+np.exp(-law.q)*(law.p-law.c/law.q)
    L=D0-hx_debt(x,1.,law,b)
    rows={"mass":np.ones(len(x)),"E":E,"L":L,"F_.25":F(.25),"F_1":F(1.)}
    target=F(.5)-F(.25);groups=[]
    for group in (["mass","E","L"],["mass","E","L","F_.25"],["mass","E","L","F_.25","F_1"]):
        obs=np.stack([rows[n] for n in group]);S=obs/np.linalg.norm(obs,axis=1,keepdims=True)
        _,sv,V=np.linalg.svd(S,full_matrices=True)
        null=V[len(group):].T
        v=null@(null.T@target)
        assert np.linalg.norm(v)>1e-8
        base=np.full(len(x),1/len(x))
        # Equal strictly positive weights initially; keep at least 1% of original weight.
        step=.99/len(x)/np.max(np.abs(v))
        hi=base+step*v;lo=base-step*v
        np.testing.assert_allclose(hi.sum(),1,atol=1e-13);np.testing.assert_allclose(lo.sum(),1,atol=1e-13)
        assert min(lo.min(),hi.min())>0 and np.max(abs(obs@(hi-lo)))<2e-12
        groups.append({"observed":group,"row_rank":int(np.linalg.matrix_rank(S)),"normalized_observed_singular_values":sv.tolist(),
                       "high_population":hi.tolist(),"low_population":lo.tolist(),
                       "high_observables":(obs@hi).tolist(),"low_observables":(obs@lo).tolist(),
                       "max_observed_abs_diff":float(max(abs(obs@(hi-lo)))),
                       "prob_first_event_in_second_quarter_high_low":[float(target@hi),float(target@lo)],
                       "future_absolute_gap":float(target@(hi-lo))})
    return {"law":"published Table I baseline, P=61.68, xi*k=.01, absolute constant barrier, point masses at eight distinct live margins. Fixed b known to both observers.",
            "mathematical_scope":"Admissible population states, not a claim of reachable trajectories from a particular common initialization and training input family. Conditional future first hits are evaluated from the exact continuous-time law prior to any reset.",
            "input_log_margins":x.tolist(),"barrier":float(b),"target":"F(0.5)-F(0.25)","groups":groups}
if __name__=="__main__":
    out=run();Path(__file__).with_name("population_observability.json").write_text(json.dumps(out,indent=2)+"\n")
    for g in out["groups"]:print(g["observed"],g["max_observed_abs_diff"],g["future_absolute_gap"])
