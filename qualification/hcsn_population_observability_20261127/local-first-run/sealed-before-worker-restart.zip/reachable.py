"""Steer a single initialized finite population into message-matched states.

The driver controls the bounded principal at each step. The network's external scalar
drive may realize each value by inversion of tanh after subtracting known causal feedback.
This is a reachable set under designed inputs, not a claim about which inputs occur in a
particular external dataset. The last two principal settings are always the common P0.
"""
import argparse,json,math
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from scipy.special import ndtr,erfc
from scipy.integrate import quad
from dataclasses import replace
from augmentation import X,P,F,price_monitors
from hx_reference import hx_boundary
N=len(X);STEPS=12;FREE=STEPS-2;STD=P.sigma*.5;DT=.25
EDGES=np.r_[0,(X[1:]+X[:-1])/2]
INIT=np.r_[np.isclose(X,.18).astype(float),0]
RESET=np.isclose(X,.3).astype(float)
B0=hx_boundary(P)
dbdp=hx_boundary(replace(P,principal=P.principal+1))-B0
slope=.28*P.principal*dbdp
phi=lambda t:np.exp(-t*t/2)/math.sqrt(2*math.pi)

def transitions(dx):
    # Batched over time; individual start margins shift equally.
    x=X+dx[:,None]
    z=np.maximum(0,x)[...,None]
    m1=(z+P.mu*DT-EDGES)/STD;m2=(-z+P.mu*DT-EDGES)/STD
    w=np.exp(-2*P.mu*z/P.sigma**2);image=ndtr(m2)
    S=np.where(x[...,None]>0,ndtr(m1)-w*image,0.)
    dS=np.where(x[...,None]>0,phi(m1)/STD+w*(2*P.mu/P.sigma**2*image+phi(m2)/STD),0.)
    M=np.zeros((len(dx),N+1,N+1));D=M.copy()
    def fill(a,s,hit):
        a[:,:N,:N-1]=s[...,:-1]-s[...,1:]
        a[:,:N,N-1]=s[...,-1];a[:,:N,N]=hit
    fill(M,S,1-S[...,0]);M[:,N,:N]=RESET
    fill(D,dS,-dS[...,0])
    return M,D

def evolve(u):
    commands=np.r_[u,[0.,0.]]
    beta=np.log((B0+slope*commands)/B0)
    dr=np.eye(STEPS,FREE)*(slope/(B0+slope*commands))[:,None]
    shifts=np.r_[0.,beta[:-1]]-beta
    dshift=np.vstack((np.zeros((1,FREE)),dr[:-1]))-dr
    m,dm=transitions(shifts)
    w=INIT.copy();dw=np.zeros((FREE,N+1))
    for i in range(STEPS):
        dw=dw@m[i]+dshift[i,:,None]*(w@dm[i])[None,:];w=w@m[i]
    return w,dw,shifts

def direct_replay(u):
    # Independent real-space density quadrature, no analytic normal CDF columns.
    commands=np.r_[u,[0.,0.]]
    before=B0;weights=INIT.copy();minval=1.;mass_error=0.
    for command in commands:
        now=hx_boundary(replace(P,principal=P.principal*(1+.28*command)))
        intervals=np.r_[EDGES,np.inf];T=np.zeros((N+1,N+1))
        for j,x in enumerate(X+np.log(before/now)):
            if x<=0:T[j,-1]=1;continue
            mean1=x+P.mu*DT;mean2=-x+P.mu*DT;image=np.exp(-2*P.mu*x/P.sigma**2)
            def density(y):
                return (phi((y-mean1)/STD)-image*phi((y-mean2)/STD))/STD
            for g,(lo,hi) in enumerate(zip(intervals[:-1],intervals[1:])):
                T[j,g]=quad(density,lo,hi,epsabs=1e-12,epsrel=1e-11)[0]
            T[j,-1]=1-T[j,:N].sum()
        T[-1,:N]=RESET;weights=weights@T
        minval=min(minval,T.min());mass_error=max(mass_error,abs(weights.sum()-1));before=now
    return weights,{"min_entry":float(minval),"max_mass_error":float(mass_error)}

def run():
    E,L=price_monitors()
    r=np.r_[np.zeros(N),1.]
    rows={"mean_equity":np.r_[E,0],"mean_loss":np.r_[L,0],"refractory":r,
          "quarter_hit":np.r_[F(.25),0],"one_year_hit":np.r_[F(1.),0]}
    # Already refractory can resume after the first interval and hit in the second.
    target=np.r_[F(.5)-F(.25),F(.25,np.array([.30]))[0]]
    rng=np.random.default_rng(613776)
    controls=rng.uniform(-.68,.68,(18,FREE));stats=[]
    for u in controls:
        w,d,shift=evolve(u)
        singular=np.linalg.svd(d[:,:N],compute_uv=False)
        stats.append((singular[-1],u,singular))
    _,base,sv=max(stats,key=lambda z:z[0])
    def centered(u,h):
        return np.stack([(evolve(u+e*h)[0]-evolve(u-e*h)[0])/(2*h) for e in np.eye(len(u))])
    rank_checks=[]
    for h in [1e-5,5e-6]:
        d=centered(base,h)
        rank_checks.append(dict(step=h,max_gradient_error=float(abs(d-evolve(base)[1]).max()),
                                smallest_sv=float(np.linalg.svd(d[:,:N],compute_uv=False)[-1])))
    cases=[]
    for labels in (["mean_equity","mean_loss","refractory"],["mean_equity","mean_loss","refractory","quarter_hit"],
                   ["mean_equity","mean_loss","refractory","quarter_hit","one_year_hit"]):
        a=np.stack([rows[l] for l in labels]);normalized=a/np.linalg.norm(a,axis=1)[:,None]
        # SLSQP caches identical state/Jacobian evaluations when multiple callbacks share a point.
        cache={}
        def pair(uv):
            key=uv.tobytes()
            if key not in cache:
                b,db,_=evolve(uv[:FREE]);c,dc,_=evolve(uv[FREE:])
                cache.clear();cache[key]=(b-c,np.vstack((db,-dc)))
            return cache[key]
        fun=lambda uv:-float(pair(uv)[0]@target)
        jac=lambda uv:-pair(uv)[1]@target
        eq=dict(type="eq",fun=lambda uv:normalized@pair(uv)[0],jac=lambda uv:(pair(uv)[1]@normalized.T).T)
        results=[]
        for i in range(4):
            v=np.clip(base+(.10 if i<2 else .18)*rng.normal(size=FREE),-.80,.80)
            start=np.r_[v,np.clip(v+.08*rng.normal(size=FREE),-.80,.80)]
            rr=minimize(fun,start,jac=jac,method="SLSQP",bounds=[(-.90,.90)]*(2*FREE),
                        constraints=[eq],options={"maxiter":500,"ftol":1e-12})
            diff,_=pair(rr.x)
            if max(abs(a@diff))<1e-8:
                results.append((float(-rr.fun),rr.x.copy(),bool(rr.success),int(rr.nit)))
        if not results:
            raise RuntimeError(f"could not find an independently matched pair: {labels}")
        gap,uv,success,iterations=max(results,key=lambda z:z[0])
        hi,lo=uv[:FREE],uv[FREE:];wh,qh=direct_replay(hi);wl,ql=direct_replay(lo)
        mismatch=max(abs(a@(wh-wl)))
        expected=[evolve(v)[0] for v in (hi,lo)]
        assert mismatch<1e-8 and abs((wh-wl)@target-gap)<1e-9
        cases.append(dict(observed=labels,starts=4,feasible_found=len(results),
                          optimizer_success=success,optimizer_iterations=iterations,high_bounded_controls=hi.tolist()+[0.,0.],
                          low_bounded_controls=lo.tolist()+[0.,0.],physical_principal_high=(P.principal*(1+.28*np.r_[hi,0.,0.])).tolist(),
                          physical_principal_low=(P.principal*(1+.28*np.r_[lo,0.,0.])).tolist(),
                          high_population=wh.tolist(),low_population=wl.tolist(),
                          high_observables=(a@wh).tolist(),low_observables=(a@wl).tolist(),
                          max_observed_abs_difference=float(mismatch),future_hit_high_low=[float(wh@target),float(wl@target)],
                          future_gap=float((wh-wl)@target),independent_replay_error=max(float(abs(e-t).max()) for e,t in zip(expected,(wh,wl))),
                          replay_checks=[qh,ql]))
    return {"assumptions":"One common initialized population, at x=.18. Twelve discrete observation intervals dt=.25, bounded controllable principal, two last intervals at identical P0. Stationary law within each bin. Current mean E,L on live mass (inactive zero), reported refractory mass, common absolute b.",
            "future":"First hit from active mass in (0.25,0.5] plus identical r*F(.25|reset); future boundary fixed, continuous first-passage expectation for given terminal atom marginals",
            "reachable_dimension_probe":{"control":base.tolist()+[0.,0.],"free_control_dimension":FREE,
              "mass_coordinate_dimension":N,"singular_values_unscaled":sv.tolist(),"numerical_rank":int((sv>1e-10).sum()),
              "finite_difference_rechecks":rank_checks},"pairs":cases}
if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("output",type=Path);a=ap.parse_args()
    j=run();a.output.write_text(json.dumps(j,indent=2)+"\n")
    print(j["reachable_dimension_probe"],[(r["observed"],r["future_gap"],r["max_observed_abs_difference"]) for r in j["pairs"]])
