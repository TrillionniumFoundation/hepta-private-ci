"""Re-score frozen held-out predictions. Paired record resampling, with class strata."""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
from prepare import SETS

SEEDS=(109,271,443);ARMS=("monetary","probability","gate","lif","gru","logistic","rbf")
def brier(prob,y):return np.sum((np.eye(prob.shape[-1])[y]-prob)**2,-1)
def put(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+"\n")
def interval(values,rows):return np.quantile(values[rows].mean(1),[.025,.975]).tolist()
def score(data,out):
    seal=json.loads((out/"SEAL.json").read_text());pred=out/"predictions";allsets={}
    for ds in SETS:
        print(ds,flush=True)
        yy=np.load(data/f"{ds}-confirm.npz");y=yy["y"];ids=yy["id"];k=len(yy["labels"])
        tra=np.load(data/f"{ds}-fit.npz");train=tra["y"];dev=tra["y_dev"];n=len(y)
        rng=np.random.default_rng(5251)
        sample=np.concatenate([rng.choice(ind,size=(5000,len(ind)),replace=True) for c in range(k) if len(ind:=np.flatnonzero(y==c))],axis=1)
        method={};losses={};capped={};intervene={}
        for arm in ARMS:
            trials=[];per_loss=[];pc_loss=[]
            for seed in SEEDS if arm not in ("logistic","rbf") else (0,):
                stem=f"{ds}-{arm}"+(f"-{seed}" if seed else "")
                p=np.load(pred/f"{stem}.npz",allow_pickle=False);assert np.array_equal(p["y"],y) and np.array_equal(p["id"],ids)
                pr=p["full"];assert np.isfinite(pr).all() and np.max(abs(pr.sum(1)-1))<1e-9
                err=brier(pr,y);per_loss.append(err);cap=brier(p["cap30"] if "cap30" in p else pr,y);pc_loss.append(cap)
                fit=json.loads((out/f"{stem}.fit.json").read_text())
                classes=[float(np.mean(pr[y==a].argmax(1)==a)) for a in range(k)]
                trials.append(dict(seed=seed,brier=float(err.mean()),acc=float(np.mean(pr.argmax(1)==y)),macro_recall=float(np.mean(classes)),
                                   per_class_acc=classes,fit_seconds=fit["seconds"],selected=fit.get("selected_step",fit.get("C")),
                                   params=fit.get("parameters"),capped_brier=float(cap.mean())))
                if arm in ("monetary","probability","gate"):
                    ir=intervene.setdefault(arm,[])
                    vals={}
                    for rm in ("risk","both","reset"):
                        delta=brier(p["without_"+rm],y)-err
                        vals[rm]={"brier_delta":float(delta.mean()),"mean_probability_abs_change":float(np.mean(abs(p["without_"+rm]-pr)))}
                    vals["total_hits_per_window_unit"]=float(p['total_hits'].mean())
                    vals["repeated_hits_per_window_unit"]=float(p['repeat_hits'].mean())
                    vals["first_hits_per_window_unit"]=float(p['first_hits'].mean())
                    ir.append(vals)
            losses[arm]=np.mean(per_loss,axis=0);capped[arm]=np.mean(pc_loss,axis=0)
            method[arm]={"seeds":trials,"brier":float(losses[arm].mean()),"accuracy":float(np.mean([t['acc'] for t in trials])),
                         "macro_recall":float(np.mean([t['macro_recall'] for t in trials])),
                         "mean_fit_seconds":float(np.mean([t["fit_seconds"] for t in trials])),
                         "capped_brier":float(capped[arm].mean())}
        contrasts={}
        for arm in ARMS[1:]:
            delta=losses["monetary"]-losses[arm]
            limited=capped["monetary"]-capped[arm]
            contrasts[arm]={"delta_brier":float(delta.mean()),"ci95":interval(delta,sample),
                            "delta_brier_30s":float(limited.mean()),"cap30_ci95":interval(limited,sample),
                            "per_class_delta_brier":[float(delta[y==c].mean()) for c in range(k)],
                            "macro_class_delta_brier":float(np.mean([delta[y==c].mean() for c in range(k)]))}
        chosen=seal["ordinary_choice"][ds]["selected_ordinary"]
        gate=all(contrasts[a]["ci95"][1]<0 for a in ("probability","gate","lif",chosen))
        allsets[ds]={"n":n,"nfit":len(train),"ndev":len(dev),"labels":yy["labels"].tolist(),
                     "class_counts_train_dev_test":[np.bincount(z,minlength=k).tolist() for z in (train,dev,y)],
                     "methods":method,"monetary_minus_comparator":contrasts,
                     "interventions":intervene,"preselected_ordinary":chosen,"all_required_comparisons":gate}
    result={"design":"3 fixed model seeds, case-level paired resampling, 5000 replications stratified by true class, fixed split conditional intervals", "datasets":allsets,
            "joint_gate_all_datasets":all(z["all_required_comparisons"] for z in allsets.values())}
    put(out/"RESULTS.json",result)
if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("--data",type=Path,required=True);ap.add_argument("--out",type=Path,required=True)
    args=ap.parse_args();score(args.data,args.out)
