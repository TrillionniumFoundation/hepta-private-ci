"""Verify source blobs then create training-only folds and calibrated sequence features."""
import argparse
import hashlib
import json
from pathlib import Path
import urllib.request
import numpy as np

SETS=("BasicMotions","ItalyPowerDemand","JapaneseVowels")
HERE=Path(__file__).resolve().parent


def acquire_raw(raw,filename,expected):
    p=raw/filename
    if not p.is_file():
        name=filename.split("_")[0]
        url=f"https://raw.githubusercontent.com/aeon-toolkit/aeon/v1.3.0/aeon/datasets/data/{name}/{filename}"
        raw.mkdir(exist_ok=True,parents=True)
        body=urllib.request.urlopen(url,timeout=30).read()
    else:
        body=p.read_bytes()
    actual=hashlib.sha1(f"blob {len(body)}\0".encode()+body).hexdigest()
    if expected!=actual:
        raise ValueError(f"Git content mismatch in {filename}")
    if not p.is_file():
        p.write_bytes(body)
    return body.decode()


def read_ts(text):
    rows=[];labels=[];digests=[]
    for row in text[text.lower().index("@data")+len("@data"):].strip().splitlines():
        if not row.strip() or row.startswith("#"):
            continue
        fields=row.strip().split(":")
        vals=np.array([[float(x) for x in channel.split(",")] for channel in fields[:-1]]).T
        digests.append(hashlib.sha256(vals.astype("<f8").tobytes()).hexdigest())
        assert np.isfinite(vals).all()
        rows.append(vals);labels.append(fields[-1].strip())
    return rows,np.array(labels),np.array(digests)


def summarize(seq):
    parts=[]
    for i in range(8):
        lo,hi=(i*len(seq))//8,((i+1)*len(seq))//8
        sl=seq[lo:max(lo+1,hi)]
        parts.append(np.concatenate([sl.mean(0),np.sqrt(np.mean(sl**2,0))]))
    return np.array(parts)


def prepare(raw,out,phase):
    hashes=json.loads((HERE/"sources.json").read_text())["blobs"]
    out.mkdir(exist_ok=True,parents=True)
    receipts={}
    for name in SETS:
        filename=name+"_TRAIN.ts"; train,y,ids=read_ts(acquire_raw(raw,filename,hashes[filename]))
        classes=np.unique(y); x=np.stack([summarize(s) for s in train]); original=np.arange(len(y))
        dev=[]
        for label in classes:
            subset=original[y==label]
            keys=[hashlib.sha256(f"population-v1/{name}/{i}".encode()).digest() for i in subset]
            dev.extend(subset[sorted(range(len(keys)),key=lambda k:keys[k])[:max(1,round(.2*len(subset)))]])
        dev=np.sort(dev); fit=original[~np.isin(original,dev)]
        m=x[fit].mean((0,1));sd=x[fit].std((0,1)).clip(1e-8)
        scale=lambda a: np.clip((a-m)/sd,-8,8)
        common={"labels":classes,"mean":m,"sd":sd}
        if phase=="fit":
            np.savez_compressed(out/f"{name}-fit.npz",x=scale(x[fit]),y=np.searchsorted(classes,y[fit]),
                                x_dev=scale(x[dev]),y_dev=np.searchsorted(classes,y[dev]),fit=fit,dev=dev,**common)
            receipts[name]={"fit":len(fit),"development":len(dev),"classes":classes.tolist(),
                            "raw_training_file":hashes[filename],"unique_training_sequences":len(set(ids))}
        else:
            filename=name+"_TEST.ts";seq,labels,digests=read_ts(acquire_raw(raw,filename,hashes[filename]))
            keep=~np.isin(digests,ids)
            seen=set()
            for i,code in enumerate(digests):
                if code in seen: keep[i]=False
                seen.add(code)
            np.savez_compressed(out/f"{name}-confirm.npz",x=scale(np.stack([summarize(s) for s in seq])[keep]),
                                y=np.searchsorted(classes,labels[keep]),id=np.flatnonzero(keep),**common)
            receipts[name]={"test_before":len(seq),"test_after":int(keep.sum()),
                            "duplicates_removed":np.flatnonzero(~keep).tolist(),"raw_test_file":hashes[filename]}
    (out/f"source-{phase}.json").write_text(json.dumps(receipts,indent=2)+"\n")


if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("phase",choices=["fit","confirm"])
    ap.add_argument("--raw",type=Path,required=True);ap.add_argument("--out",type=Path,required=True)
    args=ap.parse_args();prepare(args.raw,args.out,args.phase)
