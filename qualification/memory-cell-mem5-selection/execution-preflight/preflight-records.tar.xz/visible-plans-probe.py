import json,hashlib,os,re,subprocess
from pathlib import Path
from collections import defaultdict,Counter
root=Path("/home/qq")
request=json.loads((root/"mem-candidate-retention-20261109-a6b21bc7/request-v2.json").read_text())
materials=Path(request["config"]["material_root"])
catalog=json.loads((materials/request["catalog"]["path"]).read_text())
home_roots=[p for p in root.iterdir() if p.is_dir() and p.name.startswith(("mem-","cell-causal","ndu-real","perc-"))]
skip={"private","public","source","source-v2","node_modules",".git","target","python-deps","ci-env","python","__pycache__","portable-ocr-v1"}
records=[]; errors=[]; visited=0
for base in sorted(home_roots):
 for current,dirs,files in os.walk(base,followlinks=False):
  p=Path(current);depth=len(p.relative_to(base).parts)
  dirs[:]=[d for d in dirs if d not in skip and not (p/d).is_symlink() and depth<8]
  visited+=len(files)
  if visited>100000:errors.append({"path":str(base),"error":"file scan ceiling"});break
  for name in sorted(files):
   if name not in {"PLAN.json","plan.json"}:continue
   path=p/name
   try:
    if path.is_symlink() or path.stat().st_size>8*1024**2:raise ValueError("nonregular/oversized plan")
    raw=path.read_bytes();x=json.loads(raw)
    schema=x.get("schema","")
    groups=set()
    def collect(v):
     if isinstance(v,dict):
      for k,z in v.items():
       if k not in {"reference","references","rubric","source_pins"}:collect(z)
     elif isinstance(v,list):
      for z in v:collect(z)
     elif isinstance(v,str) and re.fullmatch("merchant-[0-9a-f]{24}",v):groups.add(v)
    collect(x)
    records.append({"path":str(path),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"schema":schema,"source_groups":sorted(groups)})
   except Exception as error:errors.append({"path":str(path),"error":repr(error)})
known=set(request["excluded_source_groups"])
exposure=json.loads(Path(request["config"]["source_exposure_ledger_path"]).read_text());known.update(exposure.get("quarantined_source_groups",[]))
for row in records:known.update(row["source_groups"])
by=defaultdict(lambda:defaultdict(dict))
for case in catalog["cases"]:by[(case["role"],case["source_id"])][case["episode_group"]][case["task_family"]]=case["id"]
families={"continuation_not_worthwhile","preparation_required","selective_refinement","text_image_complementary","text_sufficient"}
complete={}
for role in ("development","retention_validation"):
 required=families if role=="development" else {"text_image_complementary"}
 complete[role]=sorted(sid for (r,sid),eps in by.items() if r==role and sid not in known and any(required<=set(fs) for fs in eps.values()))
env={**os.environ,"PYTHONPATH":request["config"]["repository_root"]+":"+request["config"]["scripts_root"]+":"+request["config"]["pillow_path"]}
runtime=subprocess.run([request["config"]["python"],"-c","import ndu_real_runtime.episode,ndu_real_runtime.actor;print('actor_imports_ready')"],capture_output=True,text=True,timeout=30,env=env)
print(json.dumps({"schema":"mem5-visible-plan-exposure-scan-v1","scanned_roots":[str(p) for p in sorted(home_roots)],"scope":"exact PLAN.json/plan.json, depth <=8; source/private/public/venv/cache directories excluded","files_visited":visited,"plans":records,"errors":errors,"known_excluded_source_groups":sorted(known),"complete_remaining_source_groups":complete,"corrected_import_probe":{"exit_code":runtime.returncode,"stdout":runtime.stdout,"stderr":runtime.stderr[-2000:],"pythonpath":env["PYTHONPATH"]},"labels_or_reference_files_opened":False,"actor_inference_or_evaluation_performed":False,"all_possible_exposure_sources_authenticated_complete":False},indent=2,sort_keys=True))
