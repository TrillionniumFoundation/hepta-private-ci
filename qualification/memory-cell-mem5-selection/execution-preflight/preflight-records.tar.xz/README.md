# MEM-5 released-cohort metadata and runtime readiness

This work reads public catalog metadata, bound earlier plans and runtime/model
identities only. It does not open reference values, images or sealed answers,
run an actor episode, call the evaluator, choose a new cohort, or release the
sealed confirmation/retention-test roles.

The 2,199-case pilot catalog has 54 development, 27 retention-validation and
97 train source groups. After excluding the bound original training/tuning
groups, quarantine ledger and 14-source candidate-retention plan, 43 development
and 23 retention-validation groups have a complete eligible episode. This is
enough for the proposed 10+4 group prospective *development validation*, subject
to the final exposure union and frozen protocol. It is not sealed confirmation
or an authenticated assertion of globally unseen sources.

`metadata-readiness.json` and its status retain the first read-only probe. Its
Torch probe passes: Python 3.12.16 and Torch 2.9.1+cpu. The first actor import
probe omitted the repository root from PYTHONPATH and failed; that failure is a
probe configuration error, not a product defect. The corrected import probe in
`visible-plans-scan-v1.json` adds root + scripts + Pillow roots and passes.
Weights, deployment and training-receipt file hashes match their frozen pins.

The first visible-plan walk encountered its 100,000-file ceiling. That exact
observation remains preserved. A separate narrowed ripgrep probe failed
because rg is unavailable in that remote process environment; its failure is
retained in visible-plans-rg-failure.json. The actual walk found only the bound
original candidate plan before its ceiling. No complete exposure audit across
all listed roots, hosts, differently named plans or missing records is claimed.
This limit must remain explicit in any result.

`runtime-bootstrap-template.json` identifies the required source relocation,
Python path, model/OCR/config pins and prior-plan union. It is a template, not an
executed launch request. The original source-v2, request and plans remain intact.
Before any new actor dispatch, the main task must freeze and publish the actual
selector/protocol/source pins and produce a new bounded request/output.

The large local `pilot-catalog.json` is an exact verified copy of existing public
metadata for local selection checks; publish its existing path/size/SHA binding
rather than needlessly duplicating it as a new data artifact.
