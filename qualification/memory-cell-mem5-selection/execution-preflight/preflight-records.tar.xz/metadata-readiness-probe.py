import json, hashlib, os, sys, subprocess, shutil
from pathlib import Path
from collections import Counter, defaultdict
def read(path):
 p=Path(path); data=p.read_bytes(); return json.loads(data), {"path":str(p),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}
request,request_pin=read("/home/qq/mem-candidate-retention-20261109-a6b21bc7/request-v2.json")
root=Path(request["config"]["material_root"])
catalog,catalog_pin=read(root/request["catalog"]["path"])
assert catalog_pin["bytes"]==request["catalog"]["bytes"] and catalog_pin["sha256"]==request["catalog"]["sha256"]
assert set(catalog)=={"cases"}
fields={"id","source_id","role","task_family","packet","reference","episode_group"}
assert all(set(row)==fields for row in catalog["cases"])
plan,plan_pin=read("/home/qq/mem-candidate-retention-20261109-a6b21bc7/run-002/PLAN.json")
assert plan_pin["sha256"]=="488639ca2bd2b25d5c90c77b3adaf58bd8133932bb2cb1bf70fc547447d187d5"
exposure,exposure_pin=read(request["config"]["source_exposure_ledger_path"])
assert exposure_pin["sha256"]==request["config"]["source_exposure_ledger_sha256"]
excluded=set(request["excluded_source_groups"]) | set(exposure.get("quarantined_source_groups",[])) | {e["source_group_id"] for e in plan["episodes"]}
roles=defaultdict(set); episodes=defaultdict(lambda:defaultdict(set))
for row in catalog["cases"]:
 roles[row["role"]].add(row["source_id"]); episodes[row["source_id"]][row["episode_group"]].add(row["task_family"])
families={"text_sufficient","text_image_complementary","selective_correction","prepare_then_benefit","timely_stop"}
family_names=sorted({x["task_family"] for x in catalog["cases"]})
homes=[str(p) for p in Path("/home/qq").iterdir() if p.is_dir() and p.name.startswith(("mem-","cell-causal","ndu-real","perc-"))]
runtime={}
for name in ["python","tesseract","tessdata_dir","ocr_library_dir","pillow_path","repository_root","scripts_root"]:
 p=Path(request["config"][name]);runtime[name]={"path":str(p),"exists":p.exists(),"executable":os.access(p,os.X_OK) if p.is_file() else None}
for key in ["weights","receipt","deployment_profile"]:
 p=Path(request["model"][key]["path"]); runtime["model_"+key]={"path":str(p),"exists":p.is_file(),"sha256":hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None}
checks={}
for label,code in [
 ("python_torch","import sys,torch;print(sys.version);print(torch.__version__)"),
 ("actor_imports","import ndu_real_runtime.episode,ndu_real_runtime.actor;print('imports_ready')")]:
 try:
  r=subprocess.run([request["config"]["python"],"-c",code],capture_output=True,text=True,timeout=30,env={**os.environ,"PYTHONPATH":str(Path(request["config"]["repository_root"])/"scripts")+":"+request["config"]["pillow_path"]})
  checks[label]={"exit_code":r.returncode,"stdout":r.stdout[-3000:],"stderr":r.stderr[-2000:]}
 except Exception as error:checks[label]={"error":repr(error)}
result={"schema":"mem5-current-public-metadata-readiness-v1","request":request_pin,"catalog":catalog_pin,"old_candidate_plan":plan_pin,"exposure":exposure_pin,"catalog_case_count":len(catalog["cases"]),"catalog_sources_per_role":{r:len(s) for r,s in roles.items()},"families":family_names,"known_excluded_source_groups":sorted(excluded),"old_candidate_groups":sorted({e["source_group_id"] for e in plan["episodes"]}),"remaining_released_source_groups":{r:sorted(s-excluded) for r,s in roles.items() if r in {"development","retention_validation"}},"related_root_directories":homes,"runtime":runtime,"readiness":checks,"private_reference_values_read":False,"actor_or_evaluator_executed":False,"source_usage_inventory_complete_authenticated":False}
print(json.dumps(result,sort_keys=True,indent=2))
