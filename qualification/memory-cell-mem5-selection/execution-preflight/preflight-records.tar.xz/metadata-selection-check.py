"""Reconstruct the frozen selection from public metadata only."""

import ast
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "published-final/scripts/ndu_real_runtime/run_candidate_retention.py"
OBJECTIVE = ROOT / "published-final/scripts/ndu_real_runtime/objective.py"
COVERAGE = ROOT / "published-final/scripts/ndu_real_materials/coverage.py"
namespace = {"defaultdict": defaultdict, "json": json, "hashlib": hashlib}
selected_nodes = []
for path, names in (
    (SOURCE, {"require", "select_cases"}),
    (OBJECTIVE, {"canonical_sha"}),
    (COVERAGE, {"FAMILIES", "ROLES"}),
):
    for node in ast.parse(path.read_text()).body:
        identifiers = (
            {node.name}
            if isinstance(node, ast.FunctionDef)
            else {target.id for target in node.targets if isinstance(target, ast.Name)}
            if isinstance(node, ast.Assign)
            else set()
        )
        if identifiers & names:
            selected_nodes.append(node)
exec(compile(ast.Module(body=selected_nodes, type_ignores=[]), str(SOURCE), "exec"), namespace)
catalog_raw = (ROOT / "pilot-catalog.json").read_bytes()
readiness = json.loads((ROOT / "metadata-readiness.json").read_bytes())
assert hashlib.sha256(catalog_raw).hexdigest() == readiness["catalog"]["sha256"]
excluded = readiness["known_excluded_source_groups"]
salt = "mem5-fixed-support-20261110-4b3362-v1"
selected = namespace["select_cases"](
    json.loads(catalog_raw), set(excluded),
    {"development": 10, "retention_validation": 4}, salt,
)
assert len(selected) == 54
assert not set(excluded) & {case["source_id"] for case in selected}
result = {
    "schema": "mem5-public-metadata-selection-reconstruction.v1",
    "source_commit": "5fa0d0e462cd1393f4f9e95565ff5993e9bad29a",
    "selection_salt": salt,
    "catalog": readiness["catalog"],
    "excluded_source_groups": excluded,
    "selected_cases": selected,
    "case_count": len(selected),
    "source_group_count": len({case["source_id"] for case in selected}),
    "cases_by_role": dict(Counter(case["role"] for case in selected)),
    "task_or_reference_values_read": False,
    "scope": "cross-check against visible pinned metadata, not runtime PLAN or authenticated global exposure",
}
destination = ROOT / "metadata-selected-roster.json"
destination.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
print(json.dumps({"case_count": result["case_count"], "source_group_count": result["source_group_count"], "cases_by_role": result["cases_by_role"], "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(), "bytes": destination.stat().st_size}))
