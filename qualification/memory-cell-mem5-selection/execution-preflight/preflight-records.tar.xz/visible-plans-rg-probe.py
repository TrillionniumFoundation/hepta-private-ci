import subprocess,shutil,json,hashlib,re
from pathlib import Path
roots=[str(p) for p in Path("/home/qq").iterdir() if p.is_dir() and p.name.startswith(("mem-","cell-causal","ndu-real","perc-"))]
rg=shutil.which("rg")
if rg is None:raise RuntimeError("rg unavailable")
command=[rg,"--files","--hidden","-g","PLAN.json","-g","plan.json","-g","!**/private/**","-g","!**/public/**","-g","!**/source*/**","-g","!**/node_modules/**","-g","!**/.git/**","-g","!**/target/**","-g","!**/python-deps/**","-g","!**/ci-env/**","-g","!**/python/**","-g","!**/__pycache__/**","-g","!**/portable-ocr-v1/**",*sorted(roots)]
r=subprocess.run(command,text=True,capture_output=True,timeout=60)
if r.returncode not in (0,1):raise RuntimeError(r.stderr)
paths=r.stdout.splitlines();assert len(paths)<=256
plans=[]
for name in sorted(paths):
 p=Path(name);assert p.is_file() and not p.is_symlink() and p.stat().st_size<=8*1024**2
 raw=p.read_bytes();value=json.loads(raw);ids=set()
 def collect(v):
  if isinstance(v,dict):
   for k,z in v.items():
    if k not in {"reference","references","rubric","source_pins"}:collect(z)
  elif isinstance(v,list):
   for z in v:collect(z)
  elif isinstance(v,str) and re.fullmatch("merchant-[0-9a-f]{24}",v):ids.add(v)
 collect(value)
 plans.append({"path":name,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"schema":value.get("schema"),"source_groups":sorted(ids)})
print(json.dumps({"schema":"mem5-visible-plan-exposure-scan-v2","scanned_roots":sorted(roots),"rg_command":command,"rg_exit_code":r.returncode,"rg_stderr":r.stderr,"plans":plans,"plan_count":len(plans),"all_possible_exposure_sources_authenticated_complete":False,"limits":["Exact PLAN.json/plan.json within listed roots, with source/private/public/environment/cache directories excluded and normal ignore rules preserved.","This resolves the previous walk ceiling only; differently named plans, other roots/hosts and unrecorded exposure are not covered."],"private_reference_values_read":False,"actor_inference_or_evaluation_performed":False},indent=2,sort_keys=True))
