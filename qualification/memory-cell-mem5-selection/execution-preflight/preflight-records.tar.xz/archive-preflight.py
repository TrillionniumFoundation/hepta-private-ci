"""Preserve bounded MEM5 preflight records without source or image mutation."""

import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / "mem5-preflight-publish"
OUT.mkdir(exist_ok=True)
names = [
    "README.md", "metadata-readiness-probe.py", "metadata-readiness.json",
    "metadata-readiness-status.json", "complete-source-summary.json",
    "public-source-exposure-v3.json", "visible-plans-probe.py",
    "visible-plans-scan-v1.json", "visible-plans-status-v1.json",
    "visible-plans-rg-probe.py", "visible-plans-rg-failure.json",
    "runtime-bootstrap-template.json", "software-first-execution-bound.json",
    "software-first-status.json", "software-first-stderr.log",
    "software-source49fa176-bootstrap.py", "software-source49fa176-overlay.zip",
    "software-source49fa176-pins.json", "software-tesseract-wrapper.sh.txt",
    "software-tmpdir-fix-execution.json", "software-tmpdir-fix-stderr.log",
    "preflight-review.txt", "metadata-selection-check.py",
    "metadata-selected-roster.json", "request-5fa0d0e462cd.json",
    "final-source-inputs.json", "archive-preflight.py",
]
paths = [(name, ROOT / name) for name in names]
paths += [("ci/" + p.name, p) for p in sorted((ROOT.parent / "mem5-ci").glob("*.json"))]
members = []
archive = OUT / "preflight-records.tar.xz"
with tarfile.open(archive, "w:xz", preset=9) as stream:
    for name, path in paths:
        raw = path.read_bytes()
        members.append({"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
        stream.add(path, arcname=name, recursive=False)
with tarfile.open(archive, "r:xz") as stream:
    assert {x.name for x in stream.getmembers()} == {x["path"] for x in members}
    for row in members:
        raw = stream.extractfile(row["path"]).read()
        assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
capsule = ROOT / "final-source-capsule.zip"
assets = []
for path in (archive, capsule):
    raw = path.read_bytes()
    assert len(raw) < 512000
    assets.append({"path": path.name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "git_blob_sha1": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()})
index = {"schema": "hepta.mem5.preflight-archive.v1", "frozen_execution_commit": "5fa0d0e462cd1393f4f9e95565ff5993e9bad29a", "source_capsule_is_full_git_checkout": False, "assets": assets, "members": members, "all_member_bytes_rechecked": True, "new_task_results_included": False}
(OUT / "INDEX.json").write_text(json.dumps(index, sort_keys=True, indent=2) + "\n")
print(json.dumps({"members": len(members), "assets": assets}))
