import hashlib,json,os,subprocess,time,traceback
from collections import Counter
from pathlib import Path
BASE=Path('/home/qq/mem5-selection-20261110-4b3362')
SOURCE=BASE/'source-5fa0d0e462cd'; REQUEST=BASE/'request-5fa0d0e462cd.json'
OUTPUT=BASE/'run-001-5fa0d0e462cd'; RECORDS=BASE/'launch-001-5fa0d0e462cd'
TMP=BASE/'cohort-tmp-5fa0d0e462cd'
def disk(p):
 v=os.statvfs(p);return {'path':str(p),'device':p.stat().st_dev,'available_bytes':v.f_bavail*v.f_frsize,'free_inodes':v.f_favail}
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,o):p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
assert not OUTPUT.exists() and not RECORDS.exists()
RECORDS.mkdir()
result={'schema':'mem5-released108-launch-execution.v1','idempotency_key':'mem5-selection-5fa0d0e-108-20261110-v1','source_commit':'5fa0d0e462cd1393f4f9e95565ff5993e9bad29a','request':bind(REQUEST),'disk_before':disk(BASE),'tmpdir':str(TMP),'real_task_episode_execution_requested':True,'released_roles':['development','retention_validation'],'confirmation_evaluated':False,'production_adoption':False,'scientific_acceptance':'HOLD','automatic_retry':False,'source_preparation':bind(BASE/'preparation-5fa0d0e462cd'/'PREPARATION.json'),'prior_software_enospc_job':'1a1c453e5f8-cf39-247','tmpdir_only_correction_software_job':'1a1c45fb0af-cf39-2ab','reference_access_order_contract':'Published planner selects entire cohort using public catalog/exclusions/prior-plan metadata before reading released reference-index/rubric, model, then selected packet/reference. Actor receives only public projection. Independent report runs after all actor lifetimes. No sealed-role release.'}
start=time.time();code=1
try:
 assert result['request']['bytes']==16563 and result['request']['sha256']=='cdedbb2f6703be222db1996f6ac76d89e7c6d539dcbb479486f91261d0e875ce'
 assert result['disk_before']['available_bytes']>10*1024**3 and result['disk_before']['free_inodes']>100000
 assert TMP.is_dir() and TMP.stat().st_dev==BASE.stat().st_dev and TMP.stat().st_dev!=Path('/tmp').stat().st_dev
 r=json.loads(REQUEST.read_bytes())
 for p in r['source_pins']:
  b=(SOURCE/p['path']).read_bytes();assert len(b)==p['bytes'] and hashlib.sha256(b).hexdigest()==p['sha256']
 command=[r['config']['python'],'-B','-m','ndu_real_runtime.run_candidate_selection','--request',str(REQUEST),'--output',str(OUTPUT),'--independent-report']
 env=dict(os.environ);env.update(PYTHONPATH=os.pathsep.join([str(SOURCE),str(SOURCE/'scripts'),r['config']['pillow_path']]),TMPDIR=str(TMP),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 result.update(command=command,pythonpath=env['PYTHONPATH'],max_workers=r['max_workers'],episode_wall_seconds=r['config']['episode_wall_seconds'],started_unix_seconds=time.time())
 write(RECORDS/'LAUNCH_INTENT.json',result);print(json.dumps({'event':'launching','command':command,'request_sha256':result['request']['sha256'],'output':str(OUTPUT),'disk_before':result['disk_before']}),flush=True)
 with (RECORDS/'stdout.log').open('wb') as stdout,(RECORDS/'stderr.log').open('wb') as stderr:
  c=subprocess.run(command,cwd=SOURCE,env=env,stdout=stdout,stderr=stderr,timeout=8000)
 code=c.returncode;result.update(returncode=code,status='process_succeeded' if code==0 else 'process_failed')
 for p in r['source_pins']:
  b=(SOURCE/p['path']).read_bytes();assert len(b)==p['bytes'] and hashlib.sha256(b).hexdigest()==p['sha256']
 result['source_unchanged_after']=True
 for name in ['RUN_RECEIPT.json','PLAN.json','selection-report.json','selection-report.md','selection-summary.json']:
  p=OUTPUT/name
  if p.is_file():result.setdefault('output_bindings',{})[name]=bind(p)
 if (OUTPUT/'RUN_RECEIPT.json').is_file():
  receipt=json.loads((OUTPUT/'RUN_RECEIPT.json').read_bytes());result['run_receipt']=receipt
 inventory=[];extensions={}
 for p in OUTPUT.rglob('*'):
  if p.is_file():
   n=p.stat().st_size;ext=p.suffix.lower() or '<none>';inventory.append({'path':p.relative_to(OUTPUT).as_posix(),'bytes':n});s=extensions.setdefault(ext,{'count':0,'bytes':0});s['count']+=1;s['bytes']+=n
 inventory.sort(key=lambda x:x['path']);write(RECORDS/'OUTPUT_INVENTORY.json',inventory)
 result['output_inventory_summary']={'files':len(inventory),'bytes':sum(x['bytes'] for x in inventory),'extensions':extensions,'largest_members':sorted(inventory,key=lambda x:x['bytes'],reverse=True)[:10]}
except BaseException as error:
 result.update(status='launch_wrapper_failed',error={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()})
finally:
 result.update(wall_seconds=time.time()-start,finished_unix_seconds=time.time(),disk_after=disk(BASE))
 for name in ['stdout','stderr']:
  p=RECORDS/(name+'.log')
  if p.is_file():result[name]=bind(p)
 write(RECORDS/'EXECUTION.json',result);print(json.dumps({'event':'terminal','status':result['status'],'returncode':result.get('returncode'),'wall_seconds':result['wall_seconds'],'record':str(RECORDS/'EXECUTION.json'),'disk_after':result['disk_after']}),flush=True)
raise SystemExit(code)
