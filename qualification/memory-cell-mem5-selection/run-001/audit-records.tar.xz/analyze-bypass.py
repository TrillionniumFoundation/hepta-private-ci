"""Explain one reported bypass using ten retained artifacts and existing scores."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = ROOT / "run-result"
RAW = RUN / "bypass-evidence"
PAIR = "mem5-selection-20261110-4b3362-fd415b69187bf21cd1dc"


def read(path):
    return json.loads(path.read_bytes())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    evidence = {
        r["original_operation_id"]: r for r in read(RUN / "EVIDENCE.json")["episodes"]
    }
    plan = {r["original_operation_id"]: r for r in read(RUN / "PLAN.json")["episodes"]}
    report = {
        r["original_operation_id"]: r for r in read(RUN / "REPORT.json")["episodes"]
    }
    checks, inputs, arms = [], [], {}
    records = read(RAW / "RAW_BINDINGS.json")
    require(len(records) == 10, "complete ten retained bypass files required")
    for binding in records:
        original = binding["original_path"]
        mode = (
            "public_rule"
            if "/" + PAIR + "-public_rule/" in original
            else "frozen_neural"
        )
        operation = PAIR + "-" + mode
        relative = original.split("/" + operation + "/", 1)[1]
        path = RAW / mode / relative
        raw = path.read_bytes()
        require(
            len(raw) == binding["bytes"]
            and hashlib.sha256(raw).hexdigest() == binding["sha256"],
            "retained file differs from remote readback binding",
        )
        key = {
            "result.json": "result",
            "trajectory.json": "trajectory",
            "public/case.json": "public_case",
            "delivery-00/delivery.json": "initial_delivery",
            "delivery-04/delivery.json": "final_delivery",
        }[relative]
        pin = evidence[operation][key]
        require(
            pin["sha256"] == binding["sha256"] and pin["bytes"] == binding["bytes"],
            "retained file differs from frozen evidence manifest",
        )
        inputs.append(
            {
                "mode": mode,
                "path": relative,
                "bytes": len(raw),
                "sha256": binding["sha256"],
            }
        )
        checks.append("bound_file:" + mode + ":" + relative)
    for mode in ("frozen_neural", "public_rule"):
        operation = PAIR + "-" + mode
        expected, scored = plan[operation], report[operation]
        base = RAW / mode
        result, trajectory, packet, initial, final = (
            read(base / p)
            for p in (
                "result.json",
                "trajectory.json",
                "public/case.json",
                "delivery-00/delivery.json",
                "delivery-04/delivery.json",
            )
        )
        actions = [s["action"]["action"] for s in trajectory["steps"]]
        require(
            actions
            == ["PREPARE_ROI", "READ_ROI", "RENDER_IMAGE", "STOP"]
            == result["actions"],
            "actual action chain differs",
        )
        require(
            initial["text"] == packet["initial_delivery"]["text"] == final["text"],
            "committed text changed",
        )
        require(
            packet["requirements"] == {"image": True, "text": True}
            and initial["image"] is None,
            "initial full-rubric delivery unexpectedly complete",
        )
        require(
            result["terminal_status"] == "Completed" and result["error"] is None,
            "episode not completed",
        )
        score = result["score_components"]
        require(
            score["case_id"] == expected["case_id"]
            and score["source_group"] == expected["source_group_id"]
            and score["episode_group"] == expected["episode_group"]
            and score["role"] == expected["split"],
            "existing score identity differs",
        )
        require(
            score["delivery_sha256"] == evidence[operation]["final_delivery"]["sha256"],
            "existing score delivery bytes differ",
        )
        require(
            score["text_quality"] == 1.0
            and score["committed_output_preserved"] is True,
            "existing score did not preserve correct committed text",
        )
        require(
            score["image_pixels_verified"] is True,
            "existing scorer did not claim pixel verification",
        )
        require(
            scored["initial_correct"] is False
            and scored["no_op_success"] is False
            and scored["candidate_mediated_delivered"] is False,
            "reported attribution differs",
        )
        require(
            final["image"]["bbox"]
            == trajectory["steps"][2]["action"]["arguments"]["bbox"],
            "render action differs from delivered crop",
        )
        arms[mode] = {
            "operation_id": operation,
            "case_id": expected["case_id"],
            "source_group_id": expected["source_group_id"],
            "task_family": expected["task_family"],
            "actions": actions,
            "initial_image_absent": True,
            "committed_text_preserved": True,
            "rendered_bbox": final["image"]["bbox"],
            "image_sha256": final["image"]["sha256"],
            "existing_score": {
                k: score[k]
                for k in (
                    "text_quality",
                    "committed_output_preserved",
                    "image_pass",
                    "image_pixels_verified",
                    "image_target_coverage",
                    "image_quality",
                    "quality",
                    "evaluator_source_sha256",
                    "reference_sha256",
                )
            },
            "reported_attribution": {
                k: scored[k]
                for k in (
                    "initial_correct",
                    "unconditional_success",
                    "no_op_success",
                    "candidate_mediated_delivered",
                    "bypass_success",
                    "failure_stage",
                    "available",
                    "selected",
                )
            },
        }
        checks.extend(
            [
                "bound_score:" + mode,
                "executed_action_chain:" + mode,
                "preserved_text:" + mode,
            ]
        )
    require(
        arms["frozen_neural"]["existing_score"]["image_pass"] is False
        and arms["frozen_neural"]["existing_score"]["image_target_coverage"] == 0.0,
        "neural comparator differs",
    )
    require(
        arms["public_rule"]["existing_score"]["image_pass"] is True
        and arms["public_rule"]["existing_score"]["image_target_coverage"] == 1.0,
        "public image completion differs",
    )
    output = {
        "schema": "mem5-retained-bypass-explanation.v1",
        "source_commit": "5fa0d0e462cd1393f4f9e95565ff5993e9bad29a",
        "status": "VERIFIED_LIMITED_SCOPE",
        "pair_id": PAIR,
        "input_files": inputs,
        "checks_passed": len(checks),
        "arms": arms,
        "explanation": "The public packet already committed the correct text but required a source-image crop and initially had no image. Neither arm executed WRITE_TEXT. The public rule selected and rendered a different ROI; its existing evaluator score reports full target coverage and image_pass, while the neural arm's image has zero target coverage and fails. Thus the one extra success completes the image requirement while preserving committed text. It is classified as bypass because it is neither an initially complete no-op delivery nor a candidate-mediated text write.",
        "scope": "Ten retained result/trajectory/public-packet/delivery files checked against original EVIDENCE pins; existing score fields inspected",
        "new_reference_read": False,
        "reference_evaluator_rerun": False,
        "delivered_pixel_files_independently_reverified": False,
        "raw_candidate_or_selector_sidecars_replayed": False,
        "same_support_terminal_counterfactual_claimed": False,
        "scientific_acceptance": "HOLD",
        "production_adoption": False,
    }
    destination = ROOT / "bypass-explanation.json"
    destination.write_text(json.dumps(output, sort_keys=True, indent=2) + "\n")
    print(
        json.dumps(
            {
                "status": output["status"],
                "checks_passed": len(checks),
                "output": str(destination),
            }
        )
    )


if __name__ == "__main__":
    main()
