"""Package exact archive-instrument bytes and historical failure observations."""

import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / "mem5-archive-publish"
NAMES = [
    "archive-run.py",
    "archive-run-selfcheck.py",
    "archive-run-selfcheck-normal.json",
    "archive-run-selfcheck-optimized.json",
    "archive-run-strict-v2-selfcheck.py",
    "archive-run-strict-v2-selfcheck-normal.json",
    "archive-run-strict-v2-selfcheck-optimized.json",
    "archive-run-strict-v2-tar-check.py",
    "archive-run-strict-v2-tar-check-normal.json",
    "archive-run-strict-v2-tar-check-optimized.json",
    "archive-run-validation.json",
    "archive-run-review.txt",
    "archive-strict-v2-preformat-ast.json",
    "raw-archive-start-request.json",
    "raw-archive-start-timeout.json",
    "raw-archive-recovery-observations.json",
    "package-archive-instrument.py",
]


def binding(name, raw):
    return {
        "path": name,
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "git_blob_sha1": hashlib.sha1(
            b"blob " + str(len(raw)).encode() + b"\0" + raw
        ).hexdigest(),
    }


OUT.mkdir(exist_ok=True)
source = (ROOT / "archive-run-strict-v2.py").read_bytes()
if (
    hashlib.sha256(source).hexdigest()
    != "3e8466d63a03306f8e52de6e5f68bd378ce235731f98f9022ec47a4696677897"
):
    raise ValueError("strict v2 frozen source changed")
with (OUT / "archive-run-strict-v2.py").open("xb") as stream:
    stream.write(source)
members = []
archive = OUT / "validation-records.tar.xz"
with tarfile.open(archive, "w:xz", preset=9) as stream:
    for name in NAMES:
        raw = (ROOT / name).read_bytes()
        members.append(binding(name, raw))
        stream.add(ROOT / name, arcname=name, recursive=False)
with tarfile.open(archive, "r:xz") as stream:
    if [member.name for member in stream.getmembers()] != NAMES:
        raise ValueError("archive member roster differs")
    for record in members:
        raw = stream.extractfile(record["path"]).read()
        if binding(record["path"], raw) != record:
            raise ValueError("archive member differs")
assets = [
    binding(name, (OUT / name).read_bytes())
    for name in ("archive-run-strict-v2.py", "README.md", "validation-records.tar.xz")
]
if any(row["bytes"] >= 512000 for row in assets):
    raise ValueError("asset exceeds unchanged size policy")
index = {
    "schema": "hepta.mem5.archive-instrument-publication.v1",
    "assets": assets,
    "archive_members": members,
    "all_packaged_member_bytes_rechecked": True,
    "actual_raw_archive_execution_status": "UNKNOWN_AFTER_MCP_TIMEOUT",
    "same_key_reconciliation_required": True,
    "actual_complete_raw_archive_verified": False,
    "archive_process_identity": "UNRESOLVED",
    "additional_start_calls_authorized": False,
    "next_action": "Read-only original stable-key identity/status/log/INDEX recovery after connection resumes",
    "real_study_result_pr": 5676,
    "actor_rerun": False,
    "scientific_acceptance": "HOLD",
}
with (OUT / "INDEX.json").open("x") as stream:
    stream.write(json.dumps(index, sort_keys=True, indent=2) + "\n")
print(
    json.dumps(
        {"members": len(members), "assets": assets, "all_member_bytes_rechecked": True}
    )
)
