"""Retain the v1 verifier limit and exercise the stricter tar admission rule."""

import importlib.util
import io
import json
import lzma
from pathlib import Path
import tarfile
import tempfile


def load(name):
    spec = importlib.util.spec_from_file_location(
        name, Path(__file__).with_name(name + ".py")
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


v1, v2 = load("archive-run"), load("archive-run-strict-v2")
data = b"original evidence"
name = "chunks/" + v2.sha(data)
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode="w:", format=tarfile.USTAR_FORMAT) as stream:
    member = tarfile.TarInfo(name)
    member.size = len(data)
    stream.addfile(member, io.BytesIO(data))
original = buffer.getvalue()
padding = bytearray(original)
padding[512 + len(data)] = 7
cases = [
    ("nonzero-trailer", original + b"extra", name),
    ("nonzero-padding", bytes(padding), name),
]
buffer = io.BytesIO()
long_name = name + "x" * 100
with tarfile.open(fileobj=buffer, mode="w:", format=tarfile.GNU_FORMAT) as stream:
    member = tarfile.TarInfo(long_name)
    member.size = len(data)
    stream.addfile(member, io.BytesIO(data))
cases.append(("hidden-gnu-extension", buffer.getvalue(), long_name))
records = []
with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary)
    for label, payload, member_name in cases:
        raw = lzma.compress(payload, preset=6)
        path = root / (label + ".tar.xz")
        path.write_bytes(raw)
        expected = {member_name: {"bytes": len(data), "sha256": v2.sha(data)}}
        binding = v2.binding(path.name, raw)
        if v1.asset_members(root, binding, expected) != {member_name: data}:
            raise RuntimeError("v1 boundary observation changed")
        try:
            v2.asset_members(root, binding, expected)
        except ValueError as error:
            records.append(
                {
                    "case": label,
                    "v1_admitted": True,
                    "v2_rejected": True,
                    "reason": str(error),
                }
            )
        else:
            raise RuntimeError("strict tar rule failed: " + label)
print(
    json.dumps(
        {
            "schema": "hepta.mem5.archive-strict-tar-check.v1",
            "status": "passed",
            "records": records,
            "actual_run_archives_mutated": False,
        },
        sort_keys=True,
    )
)
