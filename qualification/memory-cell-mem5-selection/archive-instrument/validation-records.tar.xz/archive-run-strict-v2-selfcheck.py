"""Independent roundtrip and refusal checks for the bounded archive instrument."""

import importlib.util
import io
import json
import os
from pathlib import Path
import random
import tarfile
import tempfile

spec = importlib.util.spec_from_file_location(
    "archive_run", Path(__file__).with_name("archive-run-strict-v2.py")
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
checks = []


def check(value, name):
    if not value:
        raise RuntimeError(name)
    checks.append(name)


def rejected(action, name):
    try:
        action()
    except (ValueError, OSError):
        checks.append(name)
    else:
        raise RuntimeError("unexpected admission: " + name)


def members(path):
    with tarfile.open(fileobj=io.BytesIO(path.read_bytes()), mode="r:xz") as stream:
        return {member.name: stream.extractfile(member).read() for member in stream}


with tempfile.TemporaryDirectory() as temporary:
    base = Path(temporary)
    source, output = base / "source", base / "archive"
    source.mkdir()
    (source / "empty").write_bytes(b"")
    (source / "duplicate").write_bytes(b"\x00\xff\x80pixels" * 100)
    os.link(source / "duplicate", source / "hardlink")
    (source / ".hidden-中文").write_bytes((source / "duplicate").read_bytes())
    (source / "large.bin").write_bytes(random.Random(731).randbytes(1200001))
    for number in range(1200):
        (source / (f"case-{number:04d}-" + "x" * 80 + ".json")).write_text(
            json.dumps({"number": number, "data": "frozen" * 100})
        )
    originals = {path.name: path.read_bytes() for path in source.iterdir()}
    created = module.archive(source, output)
    verified = module.verify(output)
    check(
        created == verified and verified["logical_files"] == 1205,
        "complete creation and offline verification",
    )
    index = json.loads((output / "INDEX.json").read_bytes())
    by_asset = {
        row["path"]: members(output / row["path"])
        for row in index["manifest"]["assets"]
    }
    raw = b"".join(
        by_asset[part["asset"]][part["member"]] for part in index["manifest"]["parts"]
    )
    manifest = json.loads(raw)
    check(
        len(raw) > 512000 and len(index["manifest"]["parts"]) > 1,
        "large manifest uses bounded indexed parts",
    )
    payloads = {}
    for asset in manifest["assets"]:
        payloads.update(members(output / asset["path"]))
    restored = {}
    for name, row in manifest["files"].items():
        obj = manifest["objects"][row["object_sha256"]]
        restored[name] = b"".join(
            payloads[manifest["chunks"][key]["member"]] for key in obj["chunks"]
        )
    check(restored == originals, "independent byte-for-byte logical restore")
    check(
        len(manifest["objects"]) == 1203,
        "duplicates and hardlinks retain paths with one object",
    )
    large = manifest["objects"][manifest["files"]["large.bin"]["sha256"]]
    check(len(large["chunks"]) == 5, "oversized binary object splits without byte loss")
    check(
        all(path.stat().st_size < 450000 for path in output.iterdir()),
        "all assets and index remain below bound",
    )
    asset = output / manifest["assets"][0]["path"]
    saved = asset.read_bytes()
    asset.write_bytes(bytes([saved[0] ^ 1]) + saved[1:])
    rejected(lambda: module.verify(output), "changed asset rejected")
    asset.write_bytes(saved)
    (output / "extra").write_bytes(b"extra")
    rejected(lambda: module.verify(output), "unindexed asset rejected")
    (output / "extra").unlink()
    rejected(lambda: module.archive(source, output), "existing output refused")
    rejected(
        lambda: module.archive(source, source / "nested-output"),
        "output inside source refused",
    )
    rejected(
        lambda: module.archive(source, source / ".." / "source" / "nested-output"),
        "dotdot output alias refused",
    )
    (source / "link").symlink_to(source / "empty")
    rejected(
        lambda: module.archive(source, base / "bad-link"), "source symlink refused"
    )
    (source / "link").unlink()
    os.mkfifo(source / "pipe")
    rejected(
        lambda: module.archive(source, base / "bad-pipe"),
        "source FIFO refused without blocking",
    )
    (source / "pipe").unlink()
    (base / "source-alias").symlink_to(source, target_is_directory=True)
    rejected(
        lambda: module.archive(base / "source-alias", base / "bad-root"),
        "symlink source root refused",
    )
    original_pack = module.pack

    def changed_pack(*args):
        result = original_pack(*args)
        (source / "empty").write_bytes(b"changed after capture")
        return result

    module.pack = changed_pack
    rejected(
        lambda: module.archive(source, base / "changed-source"),
        "source mutation around archival refused",
    )
    check(
        not (base / "changed-source/INDEX.json").exists(),
        "changed source never publishes final index",
    )

print(
    json.dumps(
        {
            "status": "passed",
            "checks": checks,
            "count": len(checks),
            "real_run_or_reference_read": False,
        },
        sort_keys=True,
    )
)
