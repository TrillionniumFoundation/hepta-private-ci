import importlib.util,json,time,hashlib,os,sys,resource
from pathlib import Path
root=Path('/home/qq/work/hepta-e3-teacher-20261118-2e9b')
owned=root/'owned-first-2';owned.mkdir(exist_ok=False)
def write(p,v):
 with p.open('xb') as f:f.write(json.dumps(v,sort_keys=True).encode()+b'\n');f.flush();os.fsync(f.fileno())
deployment=json.loads((root/'DEPLOYMENT.json').read_text())
script=root/'run_teacher.py'
assert hashlib.sha256(script.read_bytes()).hexdigest()==deployment['files']['run_teacher.py']['sha256']
spec=importlib.util.spec_from_file_location('e3_existing_teacher',script)
teacher=importlib.util.module_from_spec(spec);spec.loader.exec_module(teacher)
write(owned/'INTENT.json',{'source_commit':deployment['source_commit'],'runner_sha256':deployment['files']['run_teacher.py']['sha256'],'idempotency_key':'e123-teacher-stable-first-ai395-2e9b-001','minimum_continuous_idle_seconds':60,'maximum_observation_seconds':900,'model_call_retries':False,'started_at_ns':time.time_ns()})
tick=time.monotonic();deadline=tick+900;stable=None;since=None;observations=0;started_generation=False
try:
 while time.monotonic()<deadline:
  observations+=1
  try:
   server,credential=teacher.existing_server()
   slots=teacher.idle(credential)
   if stable!=server:stable=server;since=time.monotonic()
   observation={'server':server,'idle_slots':slots,'stable_idle_seconds':time.monotonic()-since}
   ready=time.monotonic()-since>=60
  except Exception as error:
   stable=None;since=None;ready=False
   observation={'error_type':type(error).__name__,'error':str(error),'no_model_request_sent':True}
  write(owned/f'OBSERVATION-{observations:03d}.json',observation)
  if ready:
   print(json.dumps({'status':'STABLE_IDLE_WINDOW','observations':observations,'server_pid':server['pid']}),flush=True)
   started_generation=True
   teacher.main('first',root,root/'run-2',deployment['source_commit'])
   write(owned/'EXIT.json',{'status':'COMPLETE','runner_returned':True,'model_calls':6,'observations':observations,'wall_seconds':time.monotonic()-tick,'client_cpu_seconds':time.process_time(),'full_system_cost_known':False,'automatic_retry':False})
   print(json.dumps({'status':'FIRST_COMPLETE','model_calls':6}),flush=True)
   raise SystemExit(0)
  time.sleep(min(15,max(0,deadline-time.monotonic())))
 raise TimeoutError('no unchanged existing service with all slots idle for 60 seconds')
except Exception as error:
 write(owned/'EXIT.json',{'status':'STOPPED','error_type':type(error).__name__,'error':str(error),'entered_first_stage':started_generation,'observations':observations,'wall_seconds':time.monotonic()-tick,'client_cpu_seconds':time.process_time(),'automatic_retry':False,'unknown_generation_is_not_replayed':True,'full_system_cost_known':False})
 print(json.dumps({'status':'STOPPED','error_type':type(error).__name__,'error':str(error),'entered_first_stage':started_generation}),flush=True)
 raise