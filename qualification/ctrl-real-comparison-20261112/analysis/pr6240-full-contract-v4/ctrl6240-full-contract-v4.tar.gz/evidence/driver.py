"""Execute the exact #6240 contract gates in an isolated checkout, without research actors."""
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import stat
import subprocess
import sys
import tarfile
import time
import traceback

SOURCE = "2411261240f0f38bd0d60e2ba158304f918b8ce1"
OBJECT_SOURCE = Path("/home/qq/neuro-owner-6240-2411261-862531d11598")
ROOT = Path("/home/qq/neuro-ctrl6240-full-2411261-862531d11598-v4")
CHECKOUT = ROOT / "checkout"
EVIDENCE = ROOT / "evidence"
UV = "/home/qq/neuro-owner-tools-862531d11598/v1/bin/uv"
ORDINARY_PYTHON = "/home/qq/hepta-smollm2-weight-research-20261103/ci-env/bin/python"
ORDINARY_DEPS = "/home/qq/ndu-real-runtime-20261107-bc2efaf10cd0/python-deps"
EXPECTED_UV_SHA256 = "fa5fc652fa5ed5b44fa8e7dda507f27975c02f59643787fd8ab4bf36f1ba7438"
EXPECTED_SOURCES = {"AGENTS.md":"c3f80e8386eb170b00af1e21de40d770c4941e464915687e728e2d14a7e79480",".github/workflows/hepta-ctrl-critic-contracts.yml":"179227584e856f58366fa534c73cbfe7cbccaf1855cb440012ad2f9d81f83565","scripts/hepta_ci_exec.py":"9b2bfaa563fff018df4e4f10944f6fbc63d307fa4c4a7e167c392288edb5a5c1","scripts/pyproject.toml":"0b6799e50e7d0e58834615ccd885e23a78acd7b89f43f37b315cdb355cd05fc0","scripts/uv.lock":"6b8e7a82d1a4f4c5d59ce57cf8be472ea031c6fb0a905506258d434132b3c99c"}
EXPECTED_SUITES = [{"minimum":6,"module":"test_ctrl_macro_study"},{"minimum":7,"module":"test_ctrl_macro_content"},{"minimum":5,"module":"test_ctrl_macro_analysis"},{"minimum":11,"module":"test_ctrl_macro_factorial"},{"minimum":8,"module":"ndu_real_runtime.test_macro_attribution"},{"minimum":1,"module":"ndu_real_runtime.test_critic_context"},{"minimum":14,"module":"ndu_real_runtime.test_metacontrol"},{"minimum":7,"module":"ndu_real_runtime.test_metacontrol_study"},{"minimum":3,"module":"ndu_real_runtime.test_metacontrol_reporting"},{"minimum":5,"module":"ndu_real_runtime.test_metacontrol_context"},{"minimum":4,"module":"ndu_real_runtime.test_metacontrol_value_gate"},{"minimum":2,"module":"ndu_real_runtime.test_macro_wire_delivery_admission"},{"minimum":4,"module":"ndu_real_runtime.test_macro_result_binding"},{"minimum":13,"module":"ndu_real_runtime.test_macro_realization"},{"minimum":17,"module":"ndu_real_runtime.test_macro_cohort"},{"minimum":7,"module":"ndu_real_runtime.test_macro_policy_checkpoint"},{"minimum":18,"module":"ndu_real_runtime.test_macro_policy"},{"minimum":6,"module":"ndu_real_runtime.test_macro_actor"},{"minimum":4,"module":"ndu_real_runtime.test_macro_public_state"},{"minimum":3,"module":"ndu_real_runtime.test_macro_execution_plan"},{"minimum":7,"module":"ndu_real_runtime.test_macro_execution"},{"minimum":7,"module":"ndu_real_runtime.test_metacontrol_native_pairs"},{"minimum":6,"module":"ndu_real_runtime.test_macro_training_pairs"},{"minimum":12,"module":"ndu_real_runtime.test_candidate_coverage"},{"minimum":7,"module":"ndu_real_runtime.test_candidate_expansion"},{"minimum":5,"module":"ndu_real_runtime.test_candidate_coverage_legacy"},{"minimum":8,"module":"ndu_real_runtime.test_candidate_gap_diagnostic"},{"minimum":3,"module":"test_summarize_ctrl_factorial"}]
SUMMARY = {"schema": "ctrl6240.full-contract-execution.v1", "source_sha": SOURCE,
           "host": "ai395", "hosted_run": False, "research_actor_calls": 0,
           "production_owner_decision": None, "scope": "manufactured_contract_regressions",
           "status": "running", "suites": [], "commands": [],
           "prior_attempt_jobs": ["1a1cf50d48a-2564-19ea", "1a1cf5d9c1b-2564-1a03", "1a1cf6ba6ec-2564-1a1c"],
           "correction": "remove external PYTHONVERBOSE; preserve original test command",
           "origin_probe_scope": "independent_preexecution_module_resolution_not_test_pid"}
ROOT.mkdir()
EVIDENCE.mkdir()
(EVIDENCE / "driver.py").write_text(DRIVER_SOURCE, encoding="utf-8")
env = os.environ.copy()
for key in ("PYTHONHOME", "PYTHONPATH", "PYTHONVERBOSE", "VIRTUAL_ENV",
            "GITHUB_RUN_ID", "GITHUB_RUN_ATTEMPT", "GITHUB_JOB"):
    env.pop(key, None)
env.update({"SOURCE_SHA": SOURCE, "TESTED_SHA": SOURCE, "BASE_SHA": "",
            "HEPTA_CI_LANE": "source-head", "PYTHONDONTWRITEBYTECODE": "1",
            "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1",
            "UV_PYTHON_INSTALL_DIR": str(ROOT / "managed-python"),
            "UV_PYTHON_BIN_DIR": str(ROOT / "python-bin"),
            "UV_PROJECT_ENVIRONMENT": str(ROOT / "project-env"),
            "UV_CACHE_DIR": str(ROOT / "uv-cache"),
            "UV_PYTHON_DOWNLOADS": "automatic", "UV_HTTP_TIMEOUT": "45",
            "PYTHONPATH": str(CHECKOUT / "scripts") + os.pathsep + str(CHECKOUT)})
env["PATH"] = str(Path(UV).parent) + os.pathsep + env.get("PATH", "")
def sha(data):
    return hashlib.sha256(data).hexdigest()
def save(name, value):
    path = EVIDENCE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
def emit(kind, value):
    print(json.dumps({"kind": kind, **value}, sort_keys=True), flush=True)
def command(label, args, *, cwd=None, child_env=None, timeout=180):
    path = EVIDENCE / (label + ".console.log")
    path.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    result = {"label": label, "command": args, "cwd": str(cwd or ROOT),
              "timeout_seconds": timeout, "timed_out": False, "exit_code": None}
    with path.open("xb") as out:
        try:
            completed = subprocess.run(args, cwd=cwd or ROOT, env=child_env or env,
                                       stdout=out, stderr=subprocess.STDOUT, timeout=timeout)
            result["exit_code"] = completed.returncode
        except subprocess.TimeoutExpired:
            result["timed_out"] = True
    result.update({"elapsed_seconds": time.monotonic() - started,
                   "log": str(path.relative_to(EVIDENCE)),
                   "log_bytes": path.stat().st_size, "log_sha256": sha(path.read_bytes())})
    SUMMARY["commands"].append(result)
    save(label + ".command.json", result)
    emit("command", {"label": label, "exit_code": result["exit_code"],
                     "timed_out": result["timed_out"]})
    return result
def git(*args):
    return subprocess.check_output(["git", *args], cwd=CHECKOUT, env=env, text=True).strip()
def identity():
    return {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "status_porcelain": git("status", "--porcelain", "--untracked-files=normal")}
def source_manifest():
    names = subprocess.check_output(["git", "ls-files", "-z"], cwd=CHECKOUT, env=env).decode().split("\0")
    selected = sorted(p for p in names if p and (
        (p.startswith("scripts/") and p.endswith(".py")) or
        (p.startswith("qualification/ctrl-real-comparison-20261112/analysis/") and p.endswith(".py")) or
        p in EXPECTED_SOURCES))
    entries = []
    for name in selected:
        path = CHECKOUT / name
        if not stat.S_ISREG(path.lstat().st_mode):
            raise ValueError("non-regular selected source: " + name)
        data = path.read_bytes()
        entries.append({"path": name, "bytes": len(data), "sha256": sha(data)})
    return {"identity": identity(), "files": entries}
def runtime_code(path, exact):
    return (
        "import json,os,platform,sys,numpy,PIL\n"
        "from pathlib import Path\n"
        "d={'python':platform.python_version(),'numpy':numpy.__version__,'pillow':PIL.__version__,"
        "'python_executable':sys.executable,'numpy_file':numpy.__file__,'pillow_file':PIL.__file__,"
        "'uid':os.getuid(),'pid':os.getpid(),'probe_scope':'independent_runtime_preflight',"
        "'hosted_run':False}\n"
        + ("assert (d['python'],d['numpy'],d['pillow'])==('3.12.14','2.3.5','11.3.0')\n" if exact else "")
        + "p=Path(" + repr(str(path)) + ")\n"
        "with p.open('x',encoding='utf-8') as f: json.dump(d,f,sort_keys=True);f.write('\\n')\n"
        "print(json.dumps(d,sort_keys=True))\n")

def probe_origins(label, modules, child_env):
    output = EVIDENCE / ("origin-probe-" + label + ".json")
    expected = {name: str(CHECKOUT / "scripts" / (name.replace(".", "/") + ".py"))
                for name in modules}
    if "test_summarize_ctrl_factorial" in expected:
        expected["test_summarize_ctrl_factorial"] = str(CHECKOUT /
            "qualification/ctrl-real-comparison-20261112/analysis/test_summarize_ctrl_factorial.py")
    code = ("import hashlib,importlib.util,json,os\nfrom pathlib import Path\n"
            + "expected = " + repr(expected) + "\n"
            + "rows = []\n"
            + "for name, wanted in expected.items():\n"
            + "    origin = Path(importlib.util.find_spec(name).origin).resolve()\n"
            + "    assert str(origin) == wanted, (name,str(origin),wanted)\n"
            + "    raw = origin.read_bytes()\n"
            + "    rows.append({'module':name,'origin':str(origin),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})\n"
            + "d = {'scope':'independent_preexecution_module_resolution_not_test_pid','pid':os.getpid(),"
            "'cwd':str(Path.cwd()),'pythonpath':os.environ.get('PYTHONPATH'),'modules':rows}\n"
            + "with Path(" + repr(str(output)) + ").open('x',encoding='utf-8') as f: json.dump(d,f,sort_keys=True);f.write('\\n')\n"
            + "print(json.dumps(d,sort_keys=True))\n")
    result = command("probes/" + label, [*test_prefix, "-c", code],
                     cwd=CHECKOUT, child_env=child_env, timeout=30)
    if result["exit_code"] != 0:
        raise ValueError("independent module origin probe failed: " + label)
    return {row["module"]: row for row in json.loads(output.read_text())["modules"]}

try:
    SUMMARY["operator_uid"] = os.getuid()
    SUMMARY["platform"] = platform.platform()
    if os.getuid() == 0:
        raise ValueError("ordinary account execution is required")
    uv_bytes = Path(UV).read_bytes()
    if sha(uv_bytes) != EXPECTED_UV_SHA256:
        raise ValueError("uv binary identity mismatch")
    SUMMARY["uv"] = {"path": UV, "bytes": len(uv_bytes), "sha256": sha(uv_bytes)}
    version = command("uv-version", [UV, "--version"], timeout=20)
    if version["exit_code"] != 0 or "uv 0.11.3" not in (EVIDENCE / version["log"]).read_text():
        raise ValueError("uv version mismatch")
    clone = command("clone", ["git", "clone", "--no-checkout", "--no-hardlinks", "--no-tags",
                              str(OBJECT_SOURCE), str(CHECKOUT)], timeout=180)
    if clone["exit_code"] != 0:
        raise ValueError("independent clone failed")
    checkout = command("checkout", ["git", "checkout", "--detach", SOURCE], cwd=CHECKOUT, timeout=120)
    if checkout["exit_code"] != 0 or identity()["commit"] != SOURCE or identity()["status_porcelain"]:
        raise ValueError("exact clean checkout unavailable")
    for name, expected in EXPECTED_SOURCES.items():
        if sha((CHECKOUT / name).read_bytes()) != expected:
            raise ValueError("independently fetched source mismatch: " + name)
    before = source_manifest()
    save("source-before.json", before)
    workflow = (CHECKOUT / ".github/workflows/hepta-ctrl-critic-contracts.yml").read_text()
    block = workflow.split("done <<'CASES'\n", 1)[1].split("\n          CASES", 1)[0]
    suites = [{"minimum": int(line.strip().split()[0]), "module": line.strip().split()[1]}
              for line in block.strip().splitlines()]
    suites.append({"minimum": 3, "module": "test_summarize_ctrl_factorial"})
    if suites != EXPECTED_SUITES or len(suites) != 28 or sum(s["minimum"] for s in suites) != 200:
        raise ValueError("workflow suite plan mismatch")
    save("suite-plan.json", suites)

    bootstrap_dir = ROOT / "bootstrap-uv"
    bootstrap_dir.mkdir()
    archive_url = "https://github.com/astral-sh/uv/releases/download/0.13.7/uv-x86_64-unknown-linux-gnu.tar.gz"
    archive_expected = "c5221ff41b7892bfc223543883600125f6a47fe845093e0f5bdff4f359196d83"
    bootstrap_raw = Path("/home/qq/neuro-ctrl6240-full-2411261-862531d11598-v2/bootstrap-uv/uv-0.13.7.tar.gz").read_bytes()
    if len(bootstrap_raw) > 64 * 1024 * 1024 or sha(bootstrap_raw) != archive_expected:
        raise ValueError("official bootstrap uv archive identity mismatch")
    bootstrap_archive = bootstrap_dir / "uv-0.13.7.tar.gz"
    with bootstrap_archive.open("xb") as stream:
        stream.write(bootstrap_raw)
    with tarfile.open(bootstrap_archive, "r:gz") as stream:
        member = stream.getmember("uv-x86_64-unknown-linux-gnu/uv")
        if not member.isfile() or not 1 <= member.size <= 128 * 1024 * 1024:
            raise ValueError("invalid bootstrap uv member")
        binary_stream = stream.extractfile(member)
        if binary_stream is None:
            raise ValueError("missing bootstrap uv member")
        bootstrap_binary = binary_stream.read(member.size + 1)
    if (len(bootstrap_binary) != member.size
        or sha(bootstrap_binary) != "4b5e59bc557ff2cd70934beb59d0eaa92820702853d49f0066b50aa11a8f0c52"):
        raise ValueError("bootstrap uv binary identity mismatch")
    bootstrap_uv = bootstrap_dir / "uv"
    with bootstrap_uv.open("xb") as stream:
        stream.write(bootstrap_binary)
    bootstrap_uv.chmod(0o755)
    SUMMARY["python_bootstrap_tool"] = {"path": str(bootstrap_uv), "version": "0.13.7",
        "archive_url": archive_url, "archive_bytes": len(bootstrap_raw), "archive_sha256": archive_expected,
        "binary_bytes": len(bootstrap_binary), "binary_sha256": sha(bootstrap_binary),
        "scope": "install managed Python only; all project test and formatter commands retain uv 0.11.3"}
    save("python-bootstrap-tool.json", SUMMARY["python_bootstrap_tool"])
    bootstrap_version = command("bootstrap-uv-version", [str(bootstrap_uv), "--version"], timeout=20)
    if (bootstrap_version["exit_code"] != 0
        or "uv 0.13.7" not in (EVIDENCE / bootstrap_version["log"]).read_text()):
        raise ValueError("bootstrap uv version mismatch")
    installed = command("install-python-3.12.14",
                        [str(bootstrap_uv), "python", "install", "--install-dir",
                         str(ROOT / "managed-python"), "--no-bin", "3.12.14"],
                        cwd=CHECKOUT, timeout=360)
    SUMMARY["exact_python_install_exit_code"] = installed["exit_code"]

    uv_prefix = [UV, "run", "--frozen", "--project", "scripts", "--python", "3.12.14"]
    uv_test_prefix = uv_prefix + ["--with", "numpy==2.3.5", "--with", "pillow==11.3.0"]
    runtime_path = EVIDENCE / "runtime-exact.json"
    prep = command("prepare-exact-runtime", uv_test_prefix + ["python", "-c", runtime_code(runtime_path, True)],
                   cwd=CHECKOUT, timeout=360)
    if prep["exit_code"] != 0 or not runtime_path.exists():
        raise ValueError("exact workflow runtime unavailable; no suites dispatched")
    runtime = json.loads(runtime_path.read_text())
    wrapper_python = str(ROOT / "project-env" / "bin" / "python")
    if not Path(wrapper_python).is_file():
        raise ValueError("stable project interpreter is absent")
    wrapper_probe = command("stable-wrapper-python",
        [wrapper_python, "-c",
         "import json,os,platform,sys; assert platform.python_version()=='3.12.14'; "
         "print(json.dumps({'python':platform.python_version(),'executable':sys.executable,"
         "'resolved_executable':os.path.realpath(sys.executable),"
         "'scope':'independent_stable_ci_wrapper_preflight'},sort_keys=True))"],
        cwd=CHECKOUT, timeout=20)
    if wrapper_probe["exit_code"] != 0:
        raise ValueError("stable project interpreter version check failed")
    SUMMARY["stable_wrapper_runtime"] = json.loads((EVIDENCE / wrapper_probe["log"]).read_text())
    test_prefix = uv_test_prefix + ["python"]
    SUMMARY["runtime_lane"] = "workflow_locked_versions_on_ai395_not_hosted"
    SUMMARY["runtime"] = runtime
    env["UV_PYTHON_DOWNLOADS"] = "never"
    ruff_version = command("ruff-version", uv_prefix + ["ruff", "--version"],
                           cwd=CHECKOUT, timeout=120)
    if (ruff_version["exit_code"] != 0
        or re.findall(r"^ruff [^\r\n]+$", (EVIDENCE / ruff_version["log"]).read_text(),
                      flags=re.MULTILINE) != ["ruff 0.15.13"]):
        raise ValueError("locked ruff version mismatch")
    SUMMARY["ruff_version"] = "0.15.13"
    SUMMARY["environment_controls"] = {k: env[k] for k in (
        "SOURCE_SHA", "TESTED_SHA", "BASE_SHA", "HEPTA_CI_LANE", "PYTHONDONTWRITEBYTECODE",
        "OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "UV_PYTHON_DOWNLOADS",
        "UV_PYTHON_INSTALL_DIR", "UV_PYTHON_BIN_DIR", "UV_PROJECT_ENVIRONMENT", "UV_CACHE_DIR", "PYTHONPATH")}

    origin_probes = probe_origins("core", [item["module"] for item in suites[:-1]], env)
    summary_env = dict(env)
    summary_env["PYTHONPATH"] = (str(CHECKOUT / "scripts") + os.pathsep + str(CHECKOUT)
        + os.pathsep + str(CHECKOUT / "qualification/ctrl-real-comparison-20261112/analysis")
        + (os.pathsep + ORDINARY_DEPS if SUMMARY["runtime_lane"].startswith("ordinary") else ""))
    origin_probes.update(probe_origins("summary", [suites[-1]["module"]], summary_env))
    source_hashes = {str(CHECKOUT / row["path"]): row["sha256"] for row in before["files"]}
    if any(source_hashes[row["origin"]] != row["sha256"] for row in origin_probes.values()):
        raise ValueError("module resolution probe bytes differ from pre-execution source")
    SUMMARY["independent_module_origin_probes"] = list(origin_probes.values())

    for index, item in enumerate(suites):
        module, minimum = item["module"], item["minimum"]
        child_env = dict(env)
        if module == "test_summarize_ctrl_factorial":
            child_env["PYTHONPATH"] = (str(CHECKOUT / "scripts") + os.pathsep + str(CHECKOUT)
                + os.pathsep + str(CHECKOUT / "qualification/ctrl-real-comparison-20261112/analysis")
                + (os.pathsep + ORDINARY_DEPS if SUMMARY["runtime_lane"].startswith("ordinary") else ""))
        output = EVIDENCE / "suites" / (module + ".json")
        args = [wrapper_python, "scripts/hepta_ci_exec.py", "--timeout-seconds", "120",
                "--minimum-tests", str(minimum), "--output", str(output), "--",
                *test_prefix, "-m", "unittest", "-v", module]
        execution = command("suites/" + module, args, cwd=CHECKOUT, child_env=child_env, timeout=180)
        entry = dict(item, wrapper_exit_code=execution["exit_code"],
                     outer_timed_out=execution["timed_out"], record=str(output.relative_to(EVIDENCE)),
                     module_origin_preprobe_matches_source=module in origin_probes,
                     origin_probe_scope="independent_preexecution_module_resolution_not_test_pid")
        if output.exists():
            record = json.loads(output.read_text())
            entry["record_status"] = record.get("status")
            entry["passed"] = record.get("observed_passed_tests")
            entry["failed"] = record.get("observed_failed_tests")
            entry["inner_timed_out"] = record.get("timed_out")
            entry["source_before_after_equal"] = record.get("before") == record.get("after")
            log_path = output.parent / record["log_file"] if "log_file" in record else None
            if log_path and log_path.exists():
                data = log_path.read_bytes()
                if len(data) != record["log_bytes"] or sha(data) != record["log_sha256"]:
                    raise ValueError("suite original log identity mismatch: " + module)
                log_text = data.decode("utf-8", errors="strict")
                entry["unittest_terminal_summaries"] = re.findall(
                    r"Ran \d+ tests? in [^\n]+\n\s*\n?(?:OK|FAILED)(?: \([^\n]*\))?", log_text)
        SUMMARY["suites"].append(entry)
        emit("suite", {"index": index + 1, **entry})
    relative_modules = re.search(r"files=\(scripts/ndu_real_runtime/\{([^}]+)\}\.py\)", workflow).group(1).split(",")
    format_paths = ["scripts/ndu_real_runtime/" + name + ".py" for name in relative_modules]
    for pattern in ("scripts/ctrl_macro*.py", "scripts/test_ctrl_macro*.py"):
        format_paths.extend(sorted(str(p.relative_to(CHECKOUT)) for p in CHECKOUT.glob(pattern)))
    format_paths.append("qualification/ctrl-real-comparison-20261112/analysis/summarize_ctrl_factorial.py")
    format_paths.extend("scripts/ndu_real_runtime/" + name + ".py" for name in ("macro_attribution", "test_macro_attribution"))
    save("format-paths.json", format_paths)
    command("format-diff", uv_prefix + ["ruff", "format", "--diff", *format_paths], cwd=CHECKOUT, timeout=120)
    format_check = command("format-check", uv_prefix + ["ruff", "format", "--check", *format_paths], cwd=CHECKOUT, timeout=120)
    lint = (command("ruff-critical-check", uv_prefix + ["ruff", "check", "--select", "E9,F63,F7,F82", *format_paths],
                    cwd=CHECKOUT, timeout=120) if format_check["exit_code"] == 0 else {"exit_code": None})
    after = source_manifest()
    save("source-after.json", after)
    SUMMARY["source_before_after_equal"] = before == after
    SUMMARY["identity"] = after["identity"]
    SUMMARY["minimum_tests"] = 200
    SUMMARY["observed_passed_tests"] = sum(s.get("passed") or 0 for s in SUMMARY["suites"])
    SUMMARY["observed_failed_tests"] = sum(s.get("failed") or 0 for s in SUMMARY["suites"])
    SUMMARY["suite_gate_passed"] = all(
        s.get("wrapper_exit_code") == 0 and s.get("record_status") == "passed"
        and not s.get("outer_timed_out") and not s.get("inner_timed_out")
        and s.get("source_before_after_equal") and s.get("module_origin_preprobe_matches_source")
        and (s.get("passed") or 0) >= s["minimum"] and not s.get("failed") for s in SUMMARY["suites"])
    SUMMARY["format_gate_passed"] = format_check["exit_code"] == 0 and lint["exit_code"] == 0
    SUMMARY["status"] = ("passed" if SUMMARY["suite_gate_passed"] and SUMMARY["format_gate_passed"]
                         and SUMMARY["source_before_after_equal"] else "failed")
except Exception as error:
    SUMMARY["status"] = "failed"
    SUMMARY["error"] = {"type": type(error).__name__, "message": str(error)}
    (EVIDENCE / "driver-error.log").write_text(traceback.format_exc(), encoding="utf-8")
finally:
    save("summary.json", SUMMARY)
    files = []
    for path in sorted(EVIDENCE.rglob("*")):
        if path.is_file():
            data = path.read_bytes()
            files.append({"path": str(path.relative_to(EVIDENCE)), "bytes": len(data), "sha256": sha(data)})
    save("file-manifest.json", {"files": files})
    archive = ROOT / "ctrl6240-full-contract-evidence.tar.gz"
    with tarfile.open(archive, "x:gz") as stream:
        stream.add(EVIDENCE, arcname="evidence")
    archive_bytes = archive.read_bytes()
    emit("terminal", {"status": SUMMARY["status"], "source_sha": SOURCE,
                      "runtime_lane": SUMMARY.get("runtime_lane"),
                      "suite_count": len(SUMMARY["suites"]),
                      "observed_passed_tests": SUMMARY.get("observed_passed_tests"),
                      "observed_failed_tests": SUMMARY.get("observed_failed_tests"),
                      "suite_gate_passed": SUMMARY.get("suite_gate_passed"),
                      "format_gate_passed": SUMMARY.get("format_gate_passed"),
                      "source_before_after_equal": SUMMARY.get("source_before_after_equal"),
                      "error": SUMMARY.get("error"), "archive_path": str(archive),
                      "archive_bytes": len(archive_bytes), "archive_sha256": sha(archive_bytes),
                      "original_evidence_files": len(files) + 1})
sys.exit(0 if SUMMARY["status"] == "passed" else 1)
