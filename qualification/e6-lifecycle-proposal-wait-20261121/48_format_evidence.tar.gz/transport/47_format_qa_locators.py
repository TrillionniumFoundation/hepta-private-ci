#!/usr/bin/env python3
"""Add the two approved QA locators to the isolated, already formatted candidate."""

import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

OWNER = Path("/home/qian-qi/work/hepta-e16-ac5459-20261121/e6-waiter-format-v2")
SOURCE = OWNER / "source"
OUT = OWNER / "qa-locator-format-1"
BASE = "84721f3da92ffaac3e7c7e2e39de2df985834370"
RUST = "codex-rs/hepta-agentd/src/ordinary_q24_post_a_progress_tests.rs"
RUST_SHA = "4b0d98a11085203161646d177d0af079254e8d4fe5e2dbcb3adae41141202462"
COMMANDS = []
START = time.monotonic()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def run(name, args, cwd):
    start = time.monotonic()
    p = subprocess.run(args, cwd=cwd, capture_output=True, timeout=120)
    write_new(OUT / f"{name}.stdout", p.stdout)
    write_new(OUT / f"{name}.stderr", p.stderr)
    COMMANDS.append({"name": name, "args": args, "cwd": str(cwd), "exit_code": p.returncode,
        "elapsed_seconds": time.monotonic() - start, "stdout_sha256": sha(p.stdout), "stderr_sha256": sha(p.stderr)})
    assert p.returncode == 0, f"{name}: {p.returncode}"
    return p.stdout


def main():
    OUT.mkdir(mode=0o700, exist_ok=False)
    prior = json.loads((OWNER / "RESULT.json").read_bytes())
    assert prior["successful"] and prior["formatted_sha256"] == RUST_SHA
    assert sha((SOURCE / RUST).read_bytes()) == RUST_SHA
    assert run("head", ["git", "rev-parse", "HEAD"], SOURCE).decode().strip() == BASE
    assert run("status-before", ["git", "status", "--porcelain=v1"], SOURCE).decode().splitlines() == [" M " + RUST]
    raw = Path(sys.argv[1]).read_bytes()
    payload = json.loads(raw)
    assert payload["base_source"] == BASE and len(payload["files"]) == 2
    write_new(OUT / "INPUT_PAYLOAD.json", raw)
    expected_paths = {"qa/b4-no-bypass/test_publication_frame_deadline_source_closure.py",
        "qa/b4-no-bypass/test_root_material_cli_source_closure.py"}
    assert {row["path"] for row in payload["files"]} == expected_paths
    for row in payload["files"]:
        target = SOURCE / row["path"]
        assert sha(target.read_bytes()) == row["before_sha256"]
        data = row["content"].encode()
        assert sha(data) == row["after_sha256"]
        ast.parse(data)
        target.write_bytes(data)
    scope = "import importlib.util,json,sys; from pathlib import Path; p=Path('../scripts/format.py'); s=importlib.util.spec_from_file_location('hepta_format',p); m=importlib.util.module_from_spec(s); sys.modules[s.name]=m; s.loader.exec_module(m); paths=m.changed_paths(); groups=m.scoped_formatter_groups(paths,check=False); print(json.dumps({'changed_paths':paths,'groups':[{'name':g.name,'commands':[{'args':list(c.args),'cwd':str(c.cwd)} for c in g.commands]} for g in groups]},sort_keys=True,indent=2))"
    selected = json.loads(run("selected-formatters", ["python3", "-c", scope], SOURCE / "codex-rs"))
    assert set(selected["changed_paths"]) == expected_paths | {RUST}
    run("original-just-fmt", ["just", "fmt"], SOURCE / "codex-rs")
    assert sha((SOURCE / RUST).read_bytes()) == RUST_SHA
    for row in payload["files"]:
        assert sha((SOURCE / row["path"]).read_bytes()) == row["after_sha256"]
    assert set(run("final-dirty-paths", ["git", "diff", "--name-only"], SOURCE).decode().splitlines()) == expected_paths | {RUST}
    run("final-diff", ["git", "diff"], SOURCE)
    return {"schema": "hepta-e6-three-file-format-v1", "successful": True,
        "source_base": BASE, "original_just_fmt_executed": True, "selected_formatters": selected,
        "rust_sha256_unchanged": RUST_SHA, "qa_file_bytes_unchanged_by_fmt": True,
        "qa_python_ast_parse_only": True, "qa_tests_executed": 0, "callers_executed": 0,
        "rust_builds_executed": 0, "native_tests_executed": 0, "whole_repository_format_qualified": False,
        "files": [{k: v for k, v in row.items() if k != "content"} for row in payload["files"]]}


try:
    result = main()
except BaseException as error:
    result = {"schema": "hepta-e6-three-file-format-v1", "successful": False,
        "error_type": type(error).__name__, "error": str(error), "traceback": traceback.format_exc()}
finally:
    result["commands"] = COMMANDS
    result["owner_elapsed_seconds"] = time.monotonic() - START
    if OUT.is_dir() and not (OUT / "RESULT.json").exists():
        write_new(OUT / "RESULT.json", (json.dumps(result, indent=2, sort_keys=True) + "\n").encode())
    print(json.dumps(result, sort_keys=True), flush=True)
sys.exit(0 if result["successful"] else 1)
