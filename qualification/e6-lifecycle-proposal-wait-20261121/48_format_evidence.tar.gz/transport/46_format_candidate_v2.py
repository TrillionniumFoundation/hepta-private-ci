#!/usr/bin/env python3
"""Format one approved fixture change in a new, isolated ROG checkout."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback


BASE = "84721f3da92ffaac3e7c7e2e39de2df985834370"
SOURCE = Path("/home/qian-qi/work/hepta-e16-ac5459-20261121/e6-readback-test-successor/source")
OWNER = Path("/home/qian-qi/work/hepta-e16-ac5459-20261121/e6-waiter-format-v2")
CHECKOUT = OWNER / "source"
PAYLOAD = Path(sys.argv[1])
PATH = "codex-rs/hepta-agentd/src/ordinary_q24_post_a_progress_tests.rs"
BEFORE = "e3c3c91dc99b0108eb6452a43db621855e41d3919e8449c55588b401ffd6a9c8"
APPROVED = "4b0d98a11085203161646d177d0af079254e8d4fe5e2dbcb3adae41141202462"
PAYLOAD_SHA = "0b3d201fad5566ce06bcdbf499f8d911fbbcd41c5573d7950ae801d90da5f061"
START = time.monotonic()
COMMANDS = []
ENV = os.environ.copy()
ENV["GIT_NO_LAZY_FETCH"] = "1"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def record(name, args, cwd, timeout=120, require=True):
    start = time.monotonic()
    process = subprocess.run(args, cwd=cwd, env=ENV, capture_output=True, timeout=timeout)
    for suffix, data in (("stdout", process.stdout), ("stderr", process.stderr)):
        write_new(OWNER / f"{name}.{suffix}", data)
    row = {"name": name, "command": args, "cwd": str(cwd),
           "exit_code": process.returncode, "elapsed_seconds": time.monotonic() - start,
           "stdout_sha256": sha(process.stdout), "stderr_sha256": sha(process.stderr)}
    COMMANDS.append(row)
    print(json.dumps(row), flush=True)
    if require and process.returncode:
        raise RuntimeError(f"{name} failed with exit {process.returncode}")
    return process


def main():
    OWNER.mkdir(mode=0o700, exist_ok=False)
    write_new(OWNER / "STARTED.json", (json.dumps({"pid": os.getpid(), "base": BASE,
        "candidate_path": PATH, "no_retry": True, "scope": "isolated formatting only"},
        sort_keys=True, indent=2) + "\n").encode())
    payload_bytes = PAYLOAD.read_bytes()
    assert sha(payload_bytes) == PAYLOAD_SHA
    payload = json.loads(payload_bytes)
    write_new(OWNER / "INPUT_PAYLOAD.json", payload_bytes)
    # This donor was read-only verified: exact 84721 tree, all 16557 blobs present.
    # Retain v1 incomplete-donor failure; copy objects without hardlinks/alternates/lazy fetch.
    assert shutil.disk_usage(OWNER).free >= 4 * 1024**3
    original_status = record("original-status-before", ["git", "status", "--porcelain=v1", "--untracked-files=no"], SOURCE).stdout
    original_head = record("original-head-before", ["git", "rev-parse", "HEAD"], SOURCE).stdout
    record("clone", ["git", "clone", "--no-hardlinks", "--no-checkout", str(SOURCE), str(CHECKOUT)], OWNER, 300)
    assert not (CHECKOUT / ".git/objects/info/alternates").exists()
    record("checkout", ["git", "checkout", "--detach", BASE], CHECKOUT, 300)
    assert record("head", ["git", "rev-parse", "HEAD"], CHECKOUT).stdout.decode().strip() == BASE
    assert record("initial-status", ["git", "status", "--porcelain=v1"], CHECKOUT).stdout == b""
    target = CHECKOUT / PATH
    assert sha(target.read_bytes()) == BEFORE
    # The payload shape is validated explicitly before writing the sole approved file.
    rows = payload["files"]
    assert len(rows) == 1 and rows[0]["path"] == PATH
    data = rows[0]["content"].encode()
    assert sha(data) == APPROVED
    target.write_bytes(data)
    for rel in ("AGENTS.md", "justfile", "scripts/just-shell.py", "scripts/format.py",
                ".github/workflows/rust-ci.yml", "codex-rs/rust-toolchain.toml",
                "codex-rs/rustfmt.toml"):
        write_new(OWNER / "format-inputs" / rel, (CHECKOUT / rel).read_bytes())
    record("dirty-paths-before", ["git", "diff", "--name-only"], CHECKOUT)
    assert COMMANDS[-1]["exit_code"] == 0
    assert (OWNER / "dirty-paths-before.stdout").read_text().splitlines() == [PATH]
    record("just-version", ["just", "--version"], CHECKOUT / "codex-rs")
    record("active-toolchain", ["rustup", "show", "active-toolchain"], CHECKOUT / "codex-rs")
    record("rustfmt-version", ["rustfmt", "--version"], CHECKOUT / "codex-rs")
    record("just-dry-run", ["just", "--dry-run", "fmt"], CHECKOUT / "codex-rs")
    scope_code = "import importlib.util,json,sys; from pathlib import Path; p=Path('../scripts/format.py'); s=importlib.util.spec_from_file_location('hepta_format',p); m=importlib.util.module_from_spec(s); sys.modules[s.name]=m; s.loader.exec_module(m); paths=m.changed_paths(); groups=m.scoped_formatter_groups(paths,check=False); print(json.dumps({'changed_paths':paths,'groups':[{'name':g.name,'commands':[{'args':list(c.args),'cwd':str(c.cwd)} for c in g.commands]} for g in groups]},sort_keys=True,indent=2))"
    scope = record("selected-formatters", ["python3", "-c", scope_code], CHECKOUT / "codex-rs")
    selected = json.loads(scope.stdout)
    assert selected["changed_paths"] == [PATH]
    # Mandatory original repository recipe, once.
    record("original-just-fmt", ["just", "fmt"], CHECKOUT / "codex-rs", 120)
    # CI pins Rust 1.96.0 and uses imports_granularity=Item. This checks one file only.
    record("candidate-ci-rustfmt-check", ["rustup", "run", "1.96.0", "rustfmt", "--edition", "2024",
        "--config", "imports_granularity=Item,skip_children=true", "--check", "--", str(target)],
        CHECKOUT / "codex-rs", 120)
    record("final-diff", ["git", "diff", "--", PATH], CHECKOUT)
    record("final-status", ["git", "status", "--porcelain=v1"], CHECKOUT)
    assert (OWNER / "final-status.stdout").read_text().splitlines() == [" M " + PATH]
    assert record("original-head-after", ["git", "rev-parse", "HEAD"], SOURCE).stdout == original_head
    assert record("original-status-after", ["git", "status", "--porcelain=v1", "--untracked-files=no"], SOURCE).stdout == original_status
    write_new(OWNER / "FORMATTED.rs", target.read_bytes())
    return {"schema": "hepta-e6-waiter-format-receipt-v1", "successful": True,
        "source_base": BASE, "candidate_path": PATH, "before_sha256": BEFORE,
        "approved_unformatted_sha256": APPROVED, "formatted_sha256": sha(target.read_bytes()),
        "format_changed_candidate_bytes": sha(target.read_bytes()) != APPROVED,
        "original_just_fmt_executed": True, "selected_formatters": selected,
        "candidate_ci_matching_rustfmt_check_only": True, "whole_repository_format_qualified": False,
        "builds_started": 0, "native_tests_started": 0, "old_ai395_source_or_target_modified": False,
        "old_rog_source_head_and_status_unchanged": True}


try:
    result = main()
except BaseException as error:
    result = {"schema": "hepta-e6-waiter-format-receipt-v1", "successful": False,
              "error_type": type(error).__name__, "error": str(error), "traceback": traceback.format_exc()}
finally:
    result["commands"] = COMMANDS
    result["owner_elapsed_seconds"] = time.monotonic() - START
    if OWNER.is_dir() and not (OWNER / "RESULT.json").exists():
        write_new(OWNER / "RESULT.json", (json.dumps(result, sort_keys=True, indent=2) + "\n").encode())
    print(json.dumps(result, sort_keys=True), flush=True)
sys.exit(0 if result["successful"] else 1)
