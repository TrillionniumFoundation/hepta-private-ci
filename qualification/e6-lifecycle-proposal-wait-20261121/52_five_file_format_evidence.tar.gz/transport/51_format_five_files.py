#!/usr/bin/env python3
"""Format five approved paths on the published readback-reconciliation base."""
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

OWNER = Path("/home/qian-qi/work/hepta-e16-ac5459-20261121/e6-waiter-format-v2")
SOURCE = OWNER / "source"
OUT = OWNER / "five-file-format-1"
BEFORE = "84721f3da92ffaac3e7c7e2e39de2df985834370"
BASE = "72fb96148a3d12db0d3482f46ab0653f7353d532"
COMMANDS = []
START = time.monotonic()
ENV = os.environ.copy()
ENV.update(GIT_NO_LAZY_FETCH="1", GIT_TERMINAL_PROMPT="0")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def run(name, args, cwd, timeout=120):
    start = time.monotonic()
    p = subprocess.run(args, cwd=cwd, env=ENV, capture_output=True, timeout=timeout)
    write_new(OUT / f"{name}.stdout", p.stdout)
    write_new(OUT / f"{name}.stderr", p.stderr)
    row = {"name": name, "args": args, "cwd": str(cwd), "exit_code": p.returncode,
        "elapsed_seconds": time.monotonic() - start, "stdout_sha256": sha(p.stdout), "stderr_sha256": sha(p.stderr)}
    COMMANDS.append(row)
    print(json.dumps(row), flush=True)
    assert p.returncode == 0, f"{name}: {p.returncode}"
    return p.stdout


def main():
    OUT.mkdir(mode=0o700, exist_ok=False)
    three_bytes = Path(sys.argv[1]).read_bytes()
    two_bytes = Path(sys.argv[2]).read_bytes()
    three = json.loads(three_bytes)
    two = json.loads(two_bytes)
    assert three["base_source"] == BEFORE and two["base"] == BASE
    assert len(three["files"]) == 3 and len(two["files"]) == 2
    assert sha(three_bytes) == "949b7892e19c83f460e9760d83115f92d87984fa93fffb6bb7a8d9861829ecc2"
    assert sha(two_bytes) == "830de354ccdba913d32b835fc75d95f480c5541d0f5445c1eac7b8404b09f141"
    assert {r["path"] for r in three["files"] + two["files"]} == {
        "codex-rs/hepta-agentd/src/ordinary_q24_post_a_progress_tests.rs",
        "qa/b4-no-bypass/test_publication_frame_deadline_source_closure.py",
        "qa/b4-no-bypass/test_root_material_cli_source_closure.py",
        "codex-rs/hepta-agentd/src/ordinary_q24_source_keeper_tests.rs",
        "codex-rs/hepta-agentd/src/production_initial_q24_writer.rs",
    }
    write_new(OUT / "THREE_FILE_PAYLOAD.json", three_bytes)
    write_new(OUT / "MECHANICAL_PAYLOAD.json", two_bytes)
    previous = json.loads((OWNER / "qa-locator-format-1/RESULT.json").read_bytes())
    assert previous["successful"]
    assert run("old-head", ["git", "rev-parse", "HEAD"], SOURCE).decode().strip() == BEFORE
    assert set(run("old-dirty-paths", ["git", "diff", "--name-only"], SOURCE).decode().splitlines()) == {r["path"] for r in three["files"]}
    for row in three["files"]:
        assert sha((SOURCE / row["path"]).read_bytes()) == row["after_sha256"]
    run("fetch-published-base", ["git", "-c", "gc.auto=0", "-c", "maintenance.auto=false",
        "fetch", "--depth=1", "--no-tags", "https://github.com/TrillionniumFoundation/hepta-private-ci.git", BASE], SOURCE)
    changed_base = set(run("base-diff", ["git", "diff", "--name-only", BEFORE, BASE], SOURCE).decode().splitlines())
    assert changed_base == {"codex-rs/hepta-neuron/src/cell_generation_control_tests.rs",
        "evidence/e6-readback-reconciliation-20261121/FMT_RECEIPT.json",
        "evidence/e6-readback-reconciliation-20261121/VALIDATION_PLAN.json"}
    run("checkout-published-base", ["git", "checkout", "--detach", BASE], SOURCE)
    assert run("new-head", ["git", "rev-parse", "HEAD"], SOURCE).decode().strip() == BASE
    tree = run("new-tree", ["git", "rev-parse", "HEAD^{tree}"], SOURCE).decode().strip()
    assert sha((SOURCE / "codex-rs/hepta-neuron/src/cell_generation_control_tests.rs").read_bytes()) == "5b6ad7f472e4a9e256c99fe7a998e842869103c0b1a5fe1d0e5f500dc98623f9"
    for index, row in enumerate(three["files"]):
        assert sha((SOURCE / row["path"]).read_bytes()) == row["after_sha256"]
        preimage = run(f"unchanged-preimage-{index}", ["git", "show", BASE + ":" + row["path"]], SOURCE)
        assert sha(preimage) == row["before_sha256"]
    for row in two["files"]:
        target = SOURCE / row["path"]
        before = target.read_bytes()
        assert blob(before) == row["before_blob_sha1"]
        data = row["content"].encode()
        assert len(data) == row["bytes"] and sha(data) == row["after_sha256"] and blob(data) == row["after_blob_sha1"]
        write_new(OUT / "preimages" / row["path"], before)
        target.write_bytes(data)
    expected = {r["path"] for r in three["files"] + two["files"]}
    scope = "import importlib.util,json,sys; from pathlib import Path; p=Path('../scripts/format.py'); s=importlib.util.spec_from_file_location('hepta_format',p); m=importlib.util.module_from_spec(s); sys.modules[s.name]=m; s.loader.exec_module(m); paths=m.changed_paths(); groups=m.scoped_formatter_groups(paths,check=False); print(json.dumps({'changed_paths':paths,'groups':[{'name':g.name,'commands':[{'args':list(c.args),'cwd':str(c.cwd)} for c in g.commands]} for g in groups]},sort_keys=True,indent=2))"
    selected = json.loads(run("selected-formatters", ["python3", "-c", scope], SOURCE / "codex-rs"))
    assert set(selected["changed_paths"]) == expected
    run("original-just-fmt", ["just", "fmt"], SOURCE / "codex-rs")
    rust_paths = sorted(str(SOURCE / name) for name in expected if name.endswith(".rs"))
    assert len(rust_paths) == 3
    run("candidate-ci-rustfmt-check", ["rustup", "run", "1.96.0", "rustfmt", "--edition", "2024",
        "--config", "imports_granularity=Item,skip_children=true", "--check", "--", *rust_paths], SOURCE / "codex-rs")
    for row in three["files"] + two["files"]:
        data = (SOURCE / row["path"]).read_bytes()
        assert sha(data) == row["after_sha256"]
        write_new(OUT / "formatted" / row["path"], data)
    assert set(run("final-dirty-paths", ["git", "diff", "--name-only"], SOURCE).decode().splitlines()) == expected
    run("final-diff", ["git", "diff"], SOURCE)
    return {"schema": "hepta-e6-five-file-format-v1", "successful": True, "source_base": BASE,
        "base_tree": tree, "prior_format_source_base": BEFORE, "prior_format_receipts_retained": True,
        "reviewed_bytes_unchanged_by_formatter": True, "original_just_fmt_executed": True,
        "selected_formatters": selected, "candidate_rust_files_checked": 3,
        "whole_repository_format_qualified": False, "source_qa_tests_executed": 0,
        "callers_executed": 0, "rust_builds_executed": 0, "native_tests_executed": 0,
        "files": [{k: v for k, v in row.items() if k != "content"} for row in three["files"] + two["files"]]}


try:
    result = main()
except BaseException as error:
    result = {"schema": "hepta-e6-five-file-format-v1", "successful": False,
        "error_type": type(error).__name__, "error": str(error), "traceback": traceback.format_exc()}
finally:
    result["commands"] = COMMANDS
    result["owner_elapsed_seconds"] = time.monotonic() - START
    if OUT.is_dir() and not (OUT / "RESULT.json").exists():
        write_new(OUT / "RESULT.json", (json.dumps(result, indent=2, sort_keys=True) + "\n").encode())
    print(json.dumps(result, sort_keys=True), flush=True)
sys.exit(0 if result["successful"] else 1)
