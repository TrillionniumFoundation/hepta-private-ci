"""Import the exact final Git identity and run the unchanged full-stack gate."""
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import time
import traceback

ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / "cloud-final-blob-gate-1"
OUT.mkdir(exist_ok=False)
REPO = ROOT / "cloud-blob-gate-1/objects.git"
BASE = "63f494553a735bd55a3fef7cfe2e76604cd6db7d"
PARENT = "0a57d319ee479c820c36618d6c713881829c04cc"
HEAD = "148e37c26586677e83f0e57e100def8805c1a020"
ENV = dict(os.environ, GIT_NO_LAZY_FETCH="1", GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0")
START = time.monotonic()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def oid(kind, raw):
    return hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def git(*args, data=None):
    return subprocess.check_output(["git", *args], cwd=REPO, env=ENV, input=data, stderr=subprocess.PIPE, timeout=15)


objects = []


def put(kind, raw, expected=None):
    expected = expected or oid(kind, raw)
    assert oid(kind, raw) == expected
    assert git("hash-object", "-t", kind, "-w", "--stdin", data=raw).decode().strip() == expected
    assert git("cat-file", kind, expected) == raw
    objects.append({"oid": expected, "type": kind, "bytes": len(raw), "sha256": sha(raw), "exact_readback": True})
    return expected


def unpack_tree(raw):
    result = {}
    offset = 0
    while offset < len(raw):
        end = raw.index(b"\0", offset)
        mode, name = raw[offset:end].split(b" ", 1)
        result[name] = (mode, raw[end + 1:end + 21].hex())
        offset = end + 21
    assert offset == len(raw)
    return result


def update_tree(tree, changes):
    entries = unpack_tree(git("cat-file", "tree", tree))
    grouped = {}
    for path, blob in changes.items():
        first, sep, rest = path.partition("/")
        if sep:
            grouped.setdefault(first.encode(), {})[rest] = blob
        else:
            assert first.encode() not in entries
            entries[first.encode()] = (b"100644", blob)
    for name, updates in grouped.items():
        mode, old = entries[name]
        assert mode == b"40000"
        entries[name] = (mode, update_tree(old, updates))
    ordered = sorted(entries, key=lambda name: name + (b"/" if entries[name][0] == b"40000" else b""))
    raw = b"".join(entries[name][0] + b" " + name + b"\0" + bytes.fromhex(entries[name][1]) for name in ordered)
    return put("tree", raw)


def state():
    answer = {}
    for name in ["HEAD", "config", "index", "packed-refs"]:
        p = REPO / name
        answer[name] = sha(p.read_bytes()) if p.is_file() else None
    answer["loose_refs"] = {str(p.relative_to(REPO)): sha(p.read_bytes()) for p in (REPO / "refs").rglob("*") if p.is_file()}
    return answer


result = {"schema": "hepta.final-exact-head-original-blob-gate.v1", "host": "managed-cloud-workspace", "base": BASE, "head": HEAD, "max_bytes": 512000, "model_loads": 0, "forward_calls": 0, "generation_calls": 0, "training_updates": 0, "native_replays": 0}
try:
    api = json.loads((ROOT / "FINAL_COMMIT_API.json").read_bytes())
    assert api["sha"] == HEAD and [p["sha"] for p in api["parents"]] == [PARENT]
    assert api["verification"]["reason"] == "unsigned"
    records = json.loads((ROOT / "VERIFICATION_PUBLICATION_MANIFEST.json").read_bytes())["files"]
    changes = {}
    for entry in records:
        raw = (ROOT / "publication-verification" / entry["path"]).read_bytes()
        assert len(raw) == entry["bytes"] and sha(raw) == entry["sha256"]
        changes[entry["path"]] = put("blob", raw, entry["git_blob_sha1"])
    parent_tree = git("rev-parse", PARENT + "^{tree}").decode().strip()
    exact_tree = update_tree(parent_tree, changes)
    assert exact_tree == api["tree"]["sha"] == "def1b4b5f6fcdb8be50afb89224e0407a0763ab9"
    # GitHub's JSON dates normalize to UTC and omit the raw commit offset.
    # Reuse the exact retained parent header offsets and accept only a full
    # Git SHA match. A previous UTC-only serialization did not match and was
    # never imported or used as an authority identity.
    parent_raw = git("cat-file", "commit", PARENT)
    headers = parent_raw.split(b"\n\n", 1)[0].decode().splitlines()
    offsets = {key: next(line for line in headers if line.startswith(key + " ")).rsplit(" ", 1)[1] for key in ["author", "committer"]}
    lines = ["tree " + exact_tree, "parent " + PARENT]
    utc_lines = list(lines)
    for key in ["author", "committer"]:
        person = api[key]
        stamp = int(datetime.datetime.fromisoformat(person["date"].replace("Z", "+00:00")).timestamp())
        lead = f"{key} {person['name']} <{person['email']}> {stamp} "
        lines.append(lead + offsets[key])
        utc_lines.append(lead + "+0000")
    raw = ("\n".join(lines) + "\n\n" + api["message"]).encode()
    normalized = ("\n".join(utc_lines) + "\n\n" + api["message"]).encode()
    (OUT / "COMMIT_RECONSTRUCTION.json").write_text(json.dumps({"normalized_utc_rejected_oid": oid("commit", normalized), "normalized_utc_newline_rejected_oid": oid("commit", normalized + b"\n"), "retained_parent_offsets": offsets, "matched_exact_oid": oid("commit", raw), "api_expected_oid": HEAD}, sort_keys=True) + "\n")
    put("commit", raw, HEAD)
    (OUT / "FINAL_COMMIT.raw").write_bytes(raw)
    (OUT / "EXACT_NEW_OBJECTS.json").write_text(json.dumps(objects, sort_keys=True) + "\n")
    changed_raw = git("diff", "--name-only", "--diff-filter=AM", "--no-renames", "-z", BASE, HEAD)
    paths = [p for p in changed_raw.decode().split("\0") if p]
    previous = json.loads((ROOT / "cloud-blob-gate-1/CHANGED_PATHS.json").read_bytes())
    assert len(paths) == 58 and sorted(paths) == sorted(previous + list(changes))
    (OUT / "changed-paths.stdout").write_bytes(changed_raw)
    (OUT / "CHANGED_PATHS.json").write_text(json.dumps(paths) + "\n")
    gate = ROOT / "cloud-blob-gate-1/check_blob_size.py"
    allow = ROOT / "cloud-blob-gate-1/blob-size-allowlist.txt"
    assert sha(gate.read_bytes()) == "eb7a9eab936b7c7948ed13fbd6d6aca09aa38997c20685a8ee12d72e388d52c3"
    assert sha(allow.read_bytes()) == "56a9a1cd05a0d81bba73a43c19e1451b213443f631dabacfa5b4e8d145e43d1c"
    argv = ["python", str(gate), "--base", BASE, "--head", HEAD, "--max-bytes", "512000", "--allowlist", str(allow)]
    before = state()
    (OUT / "BEFORE.json").write_text(json.dumps(before, sort_keys=True) + "\n")
    (OUT / "INTENT.json").write_text(json.dumps({"argv": argv, "cwd": str(REPO), "timeout_seconds": 120, "base": BASE, "head": HEAD}, sort_keys=True) + "\n")
    began = time.monotonic()
    try:
        child = subprocess.run(argv, cwd=REPO, env=ENV, capture_output=True, timeout=120)
        stdout, stderr, code, timed_out = child.stdout, child.stderr, child.returncode, False
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code, timed_out = exc.stdout or b"", exc.stderr or b"", None, True
    wall = time.monotonic() - began
    (OUT / "stdout").write_bytes(stdout)
    (OUT / "stderr").write_bytes(stderr)
    after = state()
    (OUT / "AFTER.json").write_text(json.dumps(after, sort_keys=True) + "\n")
    result.update({"status": "PASS" if code == 0 and before == after else "FAIL", "argv": argv, "cwd": str(REPO), "exit_code": code, "timed_out": timed_out, "gate_wall_seconds": wall, "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr), "changed_file_count": len(paths), "new_exact_objects": len(objects), "head_ref_index_config_unchanged": before == after, "original_script_sha256": sha(gate.read_bytes()), "original_allowlist_sha256": sha(allow.read_bytes()), "git_version": git("--version").decode().strip()})
except Exception as exc:
    result.update({"status": "ERROR", "error": type(exc).__name__ + ": " + str(exc)})
    (OUT / "exception.txt").write_text(traceback.format_exc())
result["owner_wall_seconds"] = time.monotonic() - START
(OUT / "RESULT.json").write_text(json.dumps(result, sort_keys=True) + "\n")
print(json.dumps(result, indent=2))
raise SystemExit(0 if result["status"] == "PASS" else 1)
