//! Untrusted cold-use transport. No CURRENT, writer or Root capability is created.
//! Source draft only: not declared by the crate and not compiled or deployed.

use codex_hepta_types::Digest32;
use codex_hepta_types::StableId;

pub(super) const PURPOSE: &[u8] = b"hepta.learning-artifacts.cold-task-use-grant.v1";
pub(super) const MAX_RECORD_BYTES: usize = 16 * 1024;
const SUBJECT_PURPOSE: &[u8] = b"hepta.learning-artifacts.cold-task-use-subject.v1";

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum ColdUseError {
    Length,
    Encoding,
    Purpose,
    Version,
    Binding,
    Disabled,
    Policy,
    HeadSigner,
    Signature,
    Time,
}

/// Data only. All fields are covered, in this order, by the new signature domain.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) struct ColdUseGrantV1 {
    pub(super) schema_version: u16,
    pub(super) operation_kind: u8,
    pub(super) policy_id: StableId,
    pub(super) policy_digest: Digest32,
    pub(super) policy_generation: u64,
    pub(super) grant_id: StableId,
    pub(super) nonce: [u8; 32],
    pub(super) head_signer_id: StableId,
    pub(super) head_signing_key_digest: Digest32,
    pub(super) head_authority_epoch: u64,
    pub(super) owner_trust_digest: Digest32,
    pub(super) issued_at_unix_ms: u64,
    pub(super) not_before_unix_ms: u64,
    pub(super) expires_at_unix_ms: u64,
    pub(super) registry_id: StableId,
    pub(super) storage_binding_digest: Digest32,
    pub(super) original_signed_head_digest: Digest32,
    pub(super) historical_chain_tip_digest: Digest32,
    pub(super) registry_generation: u64,
    pub(super) registry_head_digest: Digest32,
    pub(super) registry_snapshot_receipt_digest: Digest32,
    pub(super) registry_file_digest: Digest32,
    pub(super) transaction_receipt_digest: Digest32,
    pub(super) artifact_id: StableId,
    pub(super) artifact_kind: u8,
    pub(super) artifact_generation: u64,
    pub(super) artifact_predecessor_id: Option<StableId>,
    pub(super) content_digest: Digest32,
    pub(super) encoded_size_bytes: u64,
    pub(super) artifact_manifest_digest: Digest32,
    pub(super) whole_model_manifest_digest: Digest32,
    pub(super) bundle_digest: Digest32,
    pub(super) withdrawal_scope_digest: Digest32,
    pub(super) withdrawal_frontier_digest: Digest32,
    pub(super) withdrawal_frontier_generation: u64,
    pub(super) c_learning_operation_id: StableId,
    pub(super) c_completed_history_digest: Digest32,
    pub(super) c_current_head_digest: Digest32,
    pub(super) c_finalized_successor_record_digest: Digest32,
    pub(super) c_full_finalized_cut_digest: Digest32,
    pub(super) c_source_publication_digest: Digest32,
    pub(super) c_whole_model_digest: Digest32,
    pub(super) d_descriptor_digest: Digest32,
    pub(super) d_agent_id: StableId,
    pub(super) d_principal_id: StableId,
    pub(super) d_recipient_identity_digest: Digest32,
    pub(super) d_spawn_generation: u64,
    pub(super) d_run_id: StableId,
    pub(super) d_operation_id: StableId,
    pub(super) d_target_owner_binding_digest: Digest32,
    pub(super) d_target_generation: u64,
    pub(super) d_target_genesis_digest: Digest32,
    pub(super) d_source_files_digest: Digest32,
    pub(super) d_target_files_digest: Digest32,
    pub(super) d_configuration_digest: Digest32,
    pub(super) d_consumer_kind: u8,
    pub(super) d_consumer_trust_digest: Digest32,
    pub(super) authbus_signing_bytes_digest: Digest32,
    pub(super) authbus_issuer_id: StableId,
    pub(super) authbus_signing_key_digest: Digest32,
    pub(super) authbus_authority_epoch: u64,
    pub(super) authbus_message_id: StableId,
    pub(super) authbus_sequence: u64,
    pub(super) authbus_signature_digest: Digest32,
    pub(super) authbus_expires_at_unix_ms: u64,
    pub(super) runtime_digest: Digest32,
    pub(super) feature_semantic_digest: Digest32,
    pub(super) artifact_set_digest: Digest32,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) struct SignedArtifactColdUseGrantV1 {
    pub(super) grant: ColdUseGrantV1,
    pub(super) signature: [u8; 64],
}

impl ColdUseGrantV1 {
    pub(super) fn signing_bytes(&self) -> Result<Vec<u8>, ColdUseError> {
        self.validate_shape()?;
        let mut out = CanonicalBytes::new(PURPOSE);
        out.bytes.extend_from_slice(&self.schema_version.to_be_bytes());
        out.tag(self.operation_kind);
        out.id(&self.policy_id);
        out.digest(self.policy_digest);
        out.u64(self.policy_generation);
        out.id(&self.grant_id);
        out.bytes.extend_from_slice(&self.nonce);
        out.id(&self.head_signer_id);
        out.digest(self.head_signing_key_digest);
        out.u64(self.head_authority_epoch);
        out.digest(self.owner_trust_digest);
        out.u64(self.issued_at_unix_ms);
        out.u64(self.not_before_unix_ms);
        out.u64(self.expires_at_unix_ms);
        self.encode_subject(&mut out);
        let bytes = out.finish();
        if bytes.len() > MAX_RECORD_BYTES - 64 {
            return Err(ColdUseError::Length);
        }
        Ok(bytes)
    }

    // Excludes policy, nonce, grant ID and issuer/time fields; no policy/hash cycle.
    pub(super) fn subject_digest(&self) -> Result<Digest32, ColdUseError> {
        self.validate_subject()?;
        let mut out = CanonicalBytes::new(SUBJECT_PURPOSE);
        self.encode_subject(&mut out);
        Ok(Digest32::of_bytes(&out.finish()))
    }

    fn encode_subject(&self, out: &mut CanonicalBytes) {
        out.id(&self.registry_id);
        out.digest(self.storage_binding_digest);
        out.digest(self.original_signed_head_digest);
        out.digest(self.historical_chain_tip_digest);
        out.u64(self.registry_generation);
        out.digest(self.registry_head_digest);
        out.digest(self.registry_snapshot_receipt_digest);
        out.digest(self.registry_file_digest);
        out.digest(self.transaction_receipt_digest);
        out.id(&self.artifact_id);
        out.tag(self.artifact_kind);
        out.u64(self.artifact_generation);
        match &self.artifact_predecessor_id {
            Some(id) => {
                out.tag(/*value*/ 1);
                out.id(id);
            }
            None => out.tag(/*value*/ 0),
        }
        out.digest(self.content_digest);
        out.u64(self.encoded_size_bytes);
        out.digest(self.artifact_manifest_digest);
        out.digest(self.whole_model_manifest_digest);
        out.digest(self.bundle_digest);
        out.digest(self.withdrawal_scope_digest);
        out.digest(self.withdrawal_frontier_digest);
        out.u64(self.withdrawal_frontier_generation);
        out.id(&self.c_learning_operation_id);
        out.digest(self.c_completed_history_digest);
        out.digest(self.c_current_head_digest);
        out.digest(self.c_finalized_successor_record_digest);
        out.digest(self.c_full_finalized_cut_digest);
        out.digest(self.c_source_publication_digest);
        out.digest(self.c_whole_model_digest);
        out.digest(self.d_descriptor_digest);
        out.id(&self.d_agent_id);
        out.id(&self.d_principal_id);
        out.digest(self.d_recipient_identity_digest);
        out.u64(self.d_spawn_generation);
        out.id(&self.d_run_id);
        out.id(&self.d_operation_id);
        out.digest(self.d_target_owner_binding_digest);
        out.u64(self.d_target_generation);
        out.digest(self.d_target_genesis_digest);
        out.digest(self.d_source_files_digest);
        out.digest(self.d_target_files_digest);
        out.digest(self.d_configuration_digest);
        out.tag(self.d_consumer_kind);
        out.digest(self.d_consumer_trust_digest);
        out.digest(self.authbus_signing_bytes_digest);
        out.id(&self.authbus_issuer_id);
        out.digest(self.authbus_signing_key_digest);
        out.u64(self.authbus_authority_epoch);
        out.id(&self.authbus_message_id);
        out.u64(self.authbus_sequence);
        out.digest(self.authbus_signature_digest);
        out.u64(self.authbus_expires_at_unix_ms);
        out.digest(self.runtime_digest);
        out.digest(self.feature_semantic_digest);
        out.digest(self.artifact_set_digest);
    }

    fn validate_shape(&self) -> Result<(), ColdUseError> {
        if self.schema_version != 1 {
            return Err(ColdUseError::Version);
        }
        if self.operation_kind != 1 {
            return Err(ColdUseError::Purpose);
        }
        if self.nonce == [0; 32]
            || self.policy_generation == 0
            || self.head_authority_epoch == 0
            || self.policy_digest.is_zero()
            || self.head_signing_key_digest.is_zero()
            || self.owner_trust_digest.is_zero()
            || self.issued_at_unix_ms > self.not_before_unix_ms
            || self.not_before_unix_ms >= self.expires_at_unix_ms
            || self.expires_at_unix_ms > self.authbus_expires_at_unix_ms
        {
            return Err(ColdUseError::Binding);
        }
        self.validate_subject()
    }

    fn validate_subject(&self) -> Result<(), ColdUseError> {
        if self.d_consumer_kind != 1 || self.artifact_kind != 2 {
            return Err(ColdUseError::Purpose);
        }
        if self.bundle_digest != self.artifact_set_digest {
            return Err(ColdUseError::Binding);
        }
        // Withdrawal generation may be its original empty frontier. Target
        // genesis digest may be zero only if the independently checked target is.
        if [
            self.registry_generation,
            self.artifact_generation,
            self.encoded_size_bytes,
            self.d_spawn_generation,
            self.d_target_generation,
            self.authbus_authority_epoch,
        ].contains(&0) {
            return Err(ColdUseError::Binding);
        }
        if [
            self.storage_binding_digest,
            self.original_signed_head_digest,
            self.historical_chain_tip_digest,
            self.registry_head_digest,
            self.registry_snapshot_receipt_digest,
            self.registry_file_digest,
            self.transaction_receipt_digest,
            self.content_digest,
            self.artifact_manifest_digest,
            self.whole_model_manifest_digest,
            self.bundle_digest,
            self.withdrawal_scope_digest,
            self.withdrawal_frontier_digest,
            self.c_completed_history_digest,
            self.c_current_head_digest,
            self.c_finalized_successor_record_digest,
            self.c_full_finalized_cut_digest,
            self.c_source_publication_digest,
            self.c_whole_model_digest,
            self.d_descriptor_digest,
            self.d_recipient_identity_digest,
            self.d_target_owner_binding_digest,
            self.d_source_files_digest,
            self.d_target_files_digest,
            self.d_configuration_digest,
            self.d_consumer_trust_digest,
            self.authbus_signing_bytes_digest,
            self.authbus_signing_key_digest,
            self.authbus_signature_digest,
            self.runtime_digest,
            self.feature_semantic_digest,
            self.artifact_set_digest,
        ].into_iter().any(Digest32::is_zero) {
            return Err(ColdUseError::Binding);
        }
        Ok(())
    }
}

impl SignedArtifactColdUseGrantV1 {
    pub(super) fn record_bytes(&self) -> Result<Vec<u8>, ColdUseError> {
        let mut bytes = self.grant.signing_bytes()?;
        bytes.extend_from_slice(&self.signature);
        Ok(bytes)
    }

    pub(super) fn digest(&self) -> Result<Digest32, ColdUseError> {
        let preimage = self.grant.signing_bytes()?;
        Ok(Digest32::of_parts(&[PURPOSE, &preimage, &self.signature]))
    }
}

// Only bounded, typed fields are accepted. StableId retains its original
// 128-byte grammar and u64 big-endian length framing from owner_host::push_id.
pub(super) struct CanonicalBytes {
    bytes: Vec<u8>,
}

impl CanonicalBytes {
    pub(super) fn new(purpose: &[u8]) -> Self {
        Self { bytes: purpose.to_vec() }
    }

    pub(super) fn id(&mut self, id: &StableId) {
        self.u64(id.as_str().len() as u64);
        self.bytes.extend_from_slice(id.as_str().as_bytes());
    }

    pub(super) fn u64(&mut self, value: u64) {
        self.bytes.extend_from_slice(&value.to_be_bytes());
    }

    pub(super) fn tag(&mut self, value: u8) {
        self.bytes.push(value);
    }

    pub(super) fn digest(&mut self, value: Digest32) {
        self.bytes.extend_from_slice(value.as_array());
    }

    pub(super) fn finish(self) -> Vec<u8> {
        self.bytes
    }
}
