//! Bounded binary decoding only. Parsed data never implies installed policy.

use codex_hepta_types::Digest32;
use codex_hepta_types::IdProfileV1;
use codex_hepta_types::StableId;

use super::wire::ColdUseError;
use super::wire::ColdUseGrantV1;
use super::wire::MAX_RECORD_BYTES;
use super::wire::PURPOSE;
use super::wire::SignedArtifactColdUseGrantV1;

impl SignedArtifactColdUseGrantV1 {
    pub(super) fn decode(bytes: &[u8]) -> Result<Self, ColdUseError> {
        if bytes.len() > MAX_RECORD_BYTES {
            return Err(ColdUseError::Length);
        }
        let remaining = bytes.strip_prefix(PURPOSE).ok_or(ColdUseError::Purpose)?;
        let mut input = Cursor { remaining };
        let grant = ColdUseGrantV1 {
            schema_version: u16::from_be_bytes(input.fixed()?),
            operation_kind: input.fixed::<1>()?[0],
            policy_id: input.id()?,
            policy_digest: input.digest()?,
            policy_generation: input.u64()?,
            grant_id: input.id()?,
            nonce: input.fixed()?,
            head_signer_id: input.id()?,
            head_signing_key_digest: input.digest()?,
            head_authority_epoch: input.u64()?,
            owner_trust_digest: input.digest()?,
            issued_at_unix_ms: input.u64()?,
            not_before_unix_ms: input.u64()?,
            expires_at_unix_ms: input.u64()?,
            registry_id: input.id()?,
            storage_binding_digest: input.digest()?,
            original_signed_head_digest: input.digest()?,
            historical_chain_tip_digest: input.digest()?,
            registry_generation: input.u64()?,
            registry_head_digest: input.digest()?,
            registry_snapshot_receipt_digest: input.digest()?,
            registry_file_digest: input.digest()?,
            transaction_receipt_digest: input.digest()?,
            artifact_id: input.id()?,
            artifact_kind: input.fixed::<1>()?[0],
            artifact_generation: input.u64()?,
            artifact_predecessor_id: input.optional_id()?,
            content_digest: input.digest()?,
            encoded_size_bytes: input.u64()?,
            artifact_manifest_digest: input.digest()?,
            whole_model_manifest_digest: input.digest()?,
            bundle_digest: input.digest()?,
            withdrawal_scope_digest: input.digest()?,
            withdrawal_frontier_digest: input.digest()?,
            withdrawal_frontier_generation: input.u64()?,
            c_learning_operation_id: input.id()?,
            c_completed_history_digest: input.digest()?,
            c_current_head_digest: input.digest()?,
            c_finalized_successor_record_digest: input.digest()?,
            c_full_finalized_cut_digest: input.digest()?,
            c_source_publication_digest: input.digest()?,
            c_whole_model_digest: input.digest()?,
            d_descriptor_digest: input.digest()?,
            d_agent_id: input.id()?,
            d_principal_id: input.id()?,
            d_recipient_identity_digest: input.digest()?,
            d_spawn_generation: input.u64()?,
            d_run_id: input.id()?,
            d_operation_id: input.id()?,
            d_target_owner_binding_digest: input.digest()?,
            d_target_generation: input.u64()?,
            d_target_genesis_digest: input.digest()?,
            d_source_files_digest: input.digest()?,
            d_target_files_digest: input.digest()?,
            d_configuration_digest: input.digest()?,
            d_consumer_kind: input.fixed::<1>()?[0],
            d_consumer_trust_digest: input.digest()?,
            authbus_signing_bytes_digest: input.digest()?,
            authbus_issuer_id: input.id()?,
            authbus_signing_key_digest: input.digest()?,
            authbus_authority_epoch: input.u64()?,
            authbus_message_id: input.id()?,
            authbus_sequence: input.u64()?,
            authbus_signature_digest: input.digest()?,
            authbus_expires_at_unix_ms: input.u64()?,
            runtime_digest: input.digest()?,
            feature_semantic_digest: input.digest()?,
            artifact_set_digest: input.digest()?,
        };
        let signature = input.fixed()?;
        if !input.remaining.is_empty() {
            return Err(ColdUseError::Encoding);
        }
        let signed = Self { grant, signature };
        if signed.record_bytes()? != bytes {
            return Err(ColdUseError::Encoding);
        }
        Ok(signed)
    }
}

struct Cursor<'a> {
    remaining: &'a [u8],
}

impl Cursor<'_> {
    fn fixed<const N: usize>(&mut self) -> Result<[u8; N], ColdUseError> {
        let head = self.remaining.get(..N).ok_or(ColdUseError::Length)?;
        let value = head.try_into().map_err(|_| ColdUseError::Length)?;
        self.remaining = self.remaining.get(N..).ok_or(ColdUseError::Length)?;
        Ok(value)
    }

    fn u64(&mut self) -> Result<u64, ColdUseError> {
        Ok(u64::from_be_bytes(self.fixed()?))
    }

    fn digest(&mut self) -> Result<Digest32, ColdUseError> {
        Ok(Digest32::from_array(self.fixed()?))
    }

    fn id(&mut self) -> Result<StableId, ColdUseError> {
        let length = usize::try_from(self.u64()?).map_err(|_| ColdUseError::Length)?;
        let raw = self.remaining.get(..length).ok_or(ColdUseError::Length)?;
        let text = std::str::from_utf8(raw).map_err(|_| ColdUseError::Encoding)?;
        let id = StableId::with_profile(text, IdProfileV1::Stable)
            .map_err(|_| ColdUseError::Encoding)?;
        self.remaining = self.remaining.get(length..).ok_or(ColdUseError::Length)?;
        Ok(id)
    }

    fn optional_id(&mut self) -> Result<Option<StableId>, ColdUseError> {
        match self.fixed::<1>()?[0] {
            0 => Ok(None),
            1 => self.id().map(Some),
            _ => Err(ColdUseError::Encoding),
        }
    }
}
