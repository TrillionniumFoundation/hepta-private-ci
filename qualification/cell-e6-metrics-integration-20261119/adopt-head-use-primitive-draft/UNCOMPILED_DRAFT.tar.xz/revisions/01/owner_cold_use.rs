//! Relative signature facts for a new purpose; not original-owner authority.
//! This source draft is unwired. There is no production enrollment constructor,
//! signer, private key, loader, CURRENT conversion, Root capability or effect.

use std::marker::PhantomData;
use std::rc::Rc;

use codex_hepta_types::AuthorityPosture;
use codex_hepta_types::Digest32;
use codex_hepta_types::StableId;

use super::ArtifactOwnerVerifierV1;
use super::verify_signature;
use super::verify_signer_context;

#[path = "owner_cold_use_wire.rs"]
mod wire;
#[path = "owner_cold_use_decode.rs"]
mod decode;

use wire::CanonicalBytes;
use wire::ColdUseError;
use wire::ColdUseGrantV1;
use wire::SignedArtifactColdUseGrantV1;

const POLICY_PURPOSE: &[u8] = b"hepta.learning-artifacts.cold-task-use-policy.v1";

/// Intentionally private data, not an installed production policy capability.
/// Future component fixtures may construct it in their child test module.
struct RelativeColdUsePolicyV1 {
    policy_id: StableId,
    generation: u64,
    owner_trust_digest: Digest32,
    permitted_subject_digest: Digest32,
    head_signer_id: StableId,
    head_signing_key_digest: Digest32,
    minimum_head_epoch: u64,
    maximum_head_epoch: u64,
    valid_from_unix_ms: u64,
    expires_at_unix_ms: u64,
    maximum_lifetime_ms: u64,
    revoked_at_unix_ms: Option<u64>,
}

#[derive(Default)]
enum Enrollment {
    #[default]
    Disabled,
    RelativeOnly(RelativeColdUsePolicyV1),
}

/// Default always refuses. No public/parent constructor can enroll a purpose.
#[derive(Default)]
struct ColdUseSignatureVerifierV1 {
    enrollment: Enrollment,
}

struct ColdUseCheckTimeV1 {
    now_unix_ms: u64,
    observed_time_floor_unix_ms: u64,
    original_use_deadline_unix_ms: u64,
}

/// A scoped relative fact only. Private fields and Rc marker preclude cloning,
/// serialization and Send/Sync; it has no conversion to CURRENT or writer types.
struct RelativeColdUseSignatureV1<'scope> {
    grant_digest: Digest32,
    policy_digest: Digest32,
    authority: AuthorityPosture,
    scope: PhantomData<(&'scope ColdUseSignatureVerifierV1, Rc<()>)>,
}

impl ColdUseSignatureVerifierV1 {
    fn check_signature<'scope>(
        &'scope self,
        owner: &ArtifactOwnerVerifierV1,
        expected: &ColdUseGrantV1,
        signed: &'scope SignedArtifactColdUseGrantV1,
        time: ColdUseCheckTimeV1,
    ) -> Result<RelativeColdUseSignatureV1<'scope>, ColdUseError> {
        let Enrollment::RelativeOnly(policy) = &self.enrollment else {
            return Err(ColdUseError::Disabled);
        };
        let bytes = signed.grant.signing_bytes()?;
        // Exact equality covers every binding, nonce, time and original request.
        // The future product must derive expected from actual owners; these
        // deliberately untrusted inputs cannot themselves prove C or policy.
        if &signed.grant != expected {
            return Err(ColdUseError::Binding);
        }
        let grant = &signed.grant;
        let policy_digest = policy.digest()?;
        if grant.policy_id != policy.policy_id
            || grant.policy_digest != policy_digest
            || grant.policy_generation != policy.generation
            || owner.trust_digest != policy.owner_trust_digest
            || grant.owner_trust_digest != owner.trust_digest
            || grant.subject_digest()? != policy.permitted_subject_digest
            || grant.head_signer_id != policy.head_signer_id
            || grant.head_signing_key_digest != policy.head_signing_key_digest
            || grant.registry_id != owner.trust.registry_id
            || grant.withdrawal_scope_digest != owner.trust.withdrawal_scope_digest
            || grant.registry_generation < owner.trust.minimum_registry_generation.get()
            || grant.head_authority_epoch < owner.trust.minimum_authority_epoch
            || grant.head_authority_epoch < policy.minimum_head_epoch
            || grant.head_authority_epoch > policy.maximum_head_epoch
        {
            return Err(ColdUseError::Policy);
        }
        let duration = grant.expires_at_unix_ms.checked_sub(grant.issued_at_unix_ms)
            .ok_or(ColdUseError::Time)?;
        if time.now_unix_ms < time.observed_time_floor_unix_ms
            || time.now_unix_ms < grant.not_before_unix_ms
            || time.now_unix_ms > grant.expires_at_unix_ms
            || grant.issued_at_unix_ms < policy.valid_from_unix_ms
            || grant.expires_at_unix_ms > policy.expires_at_unix_ms
            || grant.expires_at_unix_ms > time.original_use_deadline_unix_ms
            || duration > policy.maximum_lifetime_ms
            || policy.revoked_at_unix_ms.is_some_and(|at| time.now_unix_ms >= at)
        {
            return Err(ColdUseError::Time);
        }
        // Reuse the exact original role map and strict current signer checks.
        // A writer, selector or Root key cannot substitute for a head signer.
        let signer = owner.head_signers.get(&grant.head_signer_id)
            .ok_or(ColdUseError::HeadSigner)?;
        if grant.expires_at_unix_ms > signer.expires_at {
            return Err(ColdUseError::Time);
        }
        verify_signer_context(
            signer,
            grant.head_signing_key_digest,
            grant.head_authority_epoch,
            grant.issued_at_unix_ms,
            time.now_unix_ms,
            /* require_current */ true,
        ).map_err(|_| ColdUseError::HeadSigner)?;
        verify_signature(&signer.verifying_key, &bytes, &signed.signature)
            .map_err(|_| ColdUseError::Signature)?;
        Ok(RelativeColdUseSignatureV1 {
            grant_digest: signed.digest()?,
            policy_digest,
            authority: AuthorityPosture::DENY_ALL,
            scope: PhantomData,
        })
    }
}

impl RelativeColdUsePolicyV1 {
    fn digest(&self) -> Result<Digest32, ColdUseError> {
        if self.generation == 0
            || self.owner_trust_digest.is_zero()
            || self.permitted_subject_digest.is_zero()
            || self.head_signing_key_digest.is_zero()
            || self.minimum_head_epoch == 0
            || self.minimum_head_epoch > self.maximum_head_epoch
            || self.valid_from_unix_ms >= self.expires_at_unix_ms
            || self.maximum_lifetime_ms == 0
        {
            return Err(ColdUseError::Policy);
        }
        let mut out = CanonicalBytes::new(POLICY_PURPOSE);
        out.id(&self.policy_id);
        out.u64(self.generation);
        out.digest(self.owner_trust_digest);
        out.digest(self.permitted_subject_digest);
        out.id(&self.head_signer_id);
        out.digest(self.head_signing_key_digest);
        for value in [
            self.minimum_head_epoch,
            self.maximum_head_epoch,
            self.valid_from_unix_ms,
            self.expires_at_unix_ms,
            self.maximum_lifetime_ms,
        ] {
            out.u64(value);
        }
        match self.revoked_at_unix_ms {
            Some(at) => {
                out.tag(/* value */ 1);
                out.u64(at);
            }
            None => out.tag(/* value */ 0),
        }
        Ok(Digest32::of_bytes(&out.finish()))
    }
}
