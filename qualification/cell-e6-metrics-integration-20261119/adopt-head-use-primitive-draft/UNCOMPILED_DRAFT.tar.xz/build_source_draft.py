"""Materialize isolated Rust source drafts; never build, sign, install or execute them."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DESIGN = ROOT.parent / "e6_head_use_design"
WIRE = DESIGN / "WIRE_CONTRACT.json"
assert hashlib.sha256(WIRE.read_bytes()).hexdigest() == "40d0c4ce4b3acdaeabf636eb86eb34b3a5ce5d980260ca6c2bef26bd094727c8"
spec = json.loads(WIRE.read_text())
fields = spec["ordered_fields"]
assert len(fields) == 68 and fields[14]["name"] == "registry_id"
OUT = ROOT / "draft/codex-rs/hepta-learning-artifacts/src"
OUT.mkdir(parents=True, exist_ok=True)


def rust_type(field):
    return {"u16_be": "u16", "u8": "u8", "u64_be": "u64", "Digest32": "Digest32",
            "StableId": "StableId", "Option<StableId>": "Option<StableId>", "[u8;32]": "[u8; 32]"}[field["encoding"]]


def encode(field):
    name, kind = field["name"], field["encoding"]
    if kind == "u16_be":
        return f"        out.bytes.extend_from_slice(&self.{name}.to_be_bytes());"
    if kind == "u64_be":
        return f"        out.u64(self.{name});"
    if kind == "u8":
        return f"        out.tag(self.{name});"
    if kind == "Digest32":
        return f"        out.digest(self.{name});"
    if kind == "StableId":
        return f"        out.id(&self.{name});"
    if kind == "[u8;32]":
        return f"        out.bytes.extend_from_slice(&self.{name});"
    return """        match &self.artifact_predecessor_id {
            Some(id) => {
                out.tag(/*value*/ 1);
                out.id(id);
            }
            None => out.tag(/*value*/ 0),
        }"""


wire = """//! Untrusted cold-use transport. No CURRENT, writer or Root capability is created.
//! Source draft only: not declared by the crate and not compiled or deployed.

use codex_hepta_types::Digest32;
use codex_hepta_types::StableId;

pub(super) const PURPOSE: &[u8] = b"hepta.learning-artifacts.cold-task-use-grant.v1";
pub(super) const MAX_RECORD_BYTES: usize = 16 * 1024;
const SUBJECT_PURPOSE: &[u8] = b"hepta.learning-artifacts.cold-task-use-subject.v1";

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum ColdUseError {
    Length,
    Encoding,
    Purpose,
    Version,
    Binding,
    Disabled,
    Policy,
    HeadSigner,
    Signature,
    Time,
}

/// Data only. All fields are covered, in this order, by the new signature domain.
#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) struct ColdUseGrantV1 {
"""
wire += "\n".join(f"    pub(super) {f['name']}: {rust_type(f)}," for f in fields)
wire += """
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) struct SignedArtifactColdUseGrantV1 {
    pub(super) grant: ColdUseGrantV1,
    pub(super) signature: [u8; 64],
}

impl ColdUseGrantV1 {
    pub(super) fn signing_bytes(&self) -> Result<Vec<u8>, ColdUseError> {
        self.validate_shape()?;
        let mut out = CanonicalBytes::new(PURPOSE);
"""
wire += "\n".join(encode(f) for f in fields[:14])
wire += """
        self.encode_subject(&mut out);
        let bytes = out.finish();
        if bytes.len() > MAX_RECORD_BYTES - 64 {
            return Err(ColdUseError::Length);
        }
        Ok(bytes)
    }

    // Excludes policy, nonce, grant ID and issuer/time fields; no policy/hash cycle.
    pub(super) fn subject_digest(&self) -> Result<Digest32, ColdUseError> {
        self.validate_subject()?;
        let mut out = CanonicalBytes::new(SUBJECT_PURPOSE);
        self.encode_subject(&mut out);
        Ok(Digest32::of_bytes(&out.finish()))
    }

    fn encode_subject(&self, out: &mut CanonicalBytes) {
"""
wire += "\n".join(encode(f) for f in fields[14:])
wire += """
    }

    fn validate_shape(&self) -> Result<(), ColdUseError> {
        if self.schema_version != 1 {
            return Err(ColdUseError::Version);
        }
        if self.operation_kind != 1 {
            return Err(ColdUseError::Purpose);
        }
        if self.nonce == [0; 32]
            || self.policy_generation == 0
            || self.head_authority_epoch == 0
            || self.policy_digest.is_zero()
            || self.head_signing_key_digest.is_zero()
            || self.owner_trust_digest.is_zero()
            || self.issued_at_unix_ms > self.not_before_unix_ms
            || self.not_before_unix_ms >= self.expires_at_unix_ms
            || self.expires_at_unix_ms > self.authbus_expires_at_unix_ms
        {
            return Err(ColdUseError::Binding);
        }
        self.validate_subject()
    }

    fn validate_subject(&self) -> Result<(), ColdUseError> {
        if self.d_consumer_kind != 1 || self.artifact_kind != 2 {
            return Err(ColdUseError::Purpose);
        }
        if self.bundle_digest != self.artifact_set_digest {
            return Err(ColdUseError::Binding);
        }
        // Withdrawal generation may be its original empty frontier. Target
        // genesis digest may be zero only if the independently checked target is.
        if [
            self.registry_generation,
            self.artifact_generation,
            self.encoded_size_bytes,
            self.d_spawn_generation,
            self.d_target_generation,
            self.authbus_authority_epoch,
        ].contains(&0) {
            return Err(ColdUseError::Binding);
        }
        if [
"""
wire += "\n".join(f"            self.{f['name']}," for f in fields[14:]
                  if f["encoding"] == "Digest32" and f["name"] != "d_target_genesis_digest")
wire += """
        ].into_iter().any(Digest32::is_zero) {
            return Err(ColdUseError::Binding);
        }
        Ok(())
    }
}

impl SignedArtifactColdUseGrantV1 {
    pub(super) fn record_bytes(&self) -> Result<Vec<u8>, ColdUseError> {
        let mut bytes = self.grant.signing_bytes()?;
        bytes.extend_from_slice(&self.signature);
        Ok(bytes)
    }

    pub(super) fn digest(&self) -> Result<Digest32, ColdUseError> {
        let preimage = self.grant.signing_bytes()?;
        Ok(Digest32::of_parts(&[PURPOSE, &preimage, &self.signature]))
    }
}

// Only bounded, typed fields are accepted. StableId retains its original
// 128-byte grammar and u64 big-endian length framing from owner_host::push_id.
pub(super) struct CanonicalBytes {
    bytes: Vec<u8>,
}

impl CanonicalBytes {
    pub(super) fn new(purpose: &[u8]) -> Self {
        Self { bytes: purpose.to_vec() }
    }

    pub(super) fn id(&mut self, id: &StableId) {
        self.u64(id.as_str().len() as u64);
        self.bytes.extend_from_slice(id.as_str().as_bytes());
    }

    pub(super) fn u64(&mut self, value: u64) {
        self.bytes.extend_from_slice(&value.to_be_bytes());
    }

    pub(super) fn tag(&mut self, value: u8) {
        self.bytes.push(value);
    }

    pub(super) fn digest(&mut self, value: Digest32) {
        self.bytes.extend_from_slice(value.as_array());
    }

    pub(super) fn finish(self) -> Vec<u8> {
        self.bytes
    }
}
"""
(OUT / "owner_cold_use_wire.rs").write_text(wire)

decoder = """//! Bounded binary decoding only. Parsed data never implies installed policy.

use codex_hepta_types::Digest32;
use codex_hepta_types::IdProfileV1;
use codex_hepta_types::StableId;

use super::wire::ColdUseError;
use super::wire::ColdUseGrantV1;
use super::wire::MAX_RECORD_BYTES;
use super::wire::PURPOSE;
use super::wire::SignedArtifactColdUseGrantV1;

impl SignedArtifactColdUseGrantV1 {
    pub(super) fn decode(bytes: &[u8]) -> Result<Self, ColdUseError> {
        if bytes.len() > MAX_RECORD_BYTES {
            return Err(ColdUseError::Length);
        }
        let remaining = bytes.strip_prefix(PURPOSE).ok_or(ColdUseError::Purpose)?;
        let mut input = Cursor { remaining };
        let grant = ColdUseGrantV1 {
"""
for f in fields:
    expr = {"u16_be": "u16::from_be_bytes(input.fixed()?)", "u8": "input.fixed::<1>()?[0]",
            "u64_be": "input.u64()?", "Digest32": "input.digest()?", "StableId": "input.id()?",
            "Option<StableId>": "match input.fixed::<1>()?[0] {\n                0 => None,\n                1 => Some(input.id()?),\n                _ => return Err(ColdUseError::Encoding),\n            }", "[u8;32]": "input.fixed()?"}[f["encoding"]]
    decoder += f"            {f['name']}: {expr},\n"
decoder += """        };
        let signature = input.fixed()?;
        if !input.remaining.is_empty() {
            return Err(ColdUseError::Encoding);
        }
        let signed = Self { grant, signature };
        if signed.record_bytes()? != bytes {
            return Err(ColdUseError::Encoding);
        }
        Ok(signed)
    }
}

struct Cursor<'a> {
    remaining: &'a [u8],
}

impl Cursor<'_> {
    fn fixed<const N: usize>(&mut self) -> Result<[u8; N], ColdUseError> {
        let head = self.remaining.get(..N).ok_or(ColdUseError::Length)?;
        let value = head.try_into().map_err(|_| ColdUseError::Length)?;
        self.remaining = self.remaining.get(N..).ok_or(ColdUseError::Length)?;
        Ok(value)
    }

    fn u64(&mut self) -> Result<u64, ColdUseError> {
        Ok(u64::from_be_bytes(self.fixed()?))
    }

    fn digest(&mut self) -> Result<Digest32, ColdUseError> {
        Ok(Digest32::from_array(self.fixed()?))
    }

    fn id(&mut self) -> Result<StableId, ColdUseError> {
        let length = usize::try_from(self.u64()?).map_err(|_| ColdUseError::Length)?;
        let raw = self.remaining.get(..length).ok_or(ColdUseError::Length)?;
        let text = std::str::from_utf8(raw).map_err(|_| ColdUseError::Encoding)?;
        let id = StableId::with_profile(text, IdProfileV1::Stable)
            .map_err(|_| ColdUseError::Encoding)?;
        self.remaining = self.remaining.get(length..).ok_or(ColdUseError::Length)?;
        Ok(id)
    }

}
"""
(OUT / "owner_cold_use_decode.rs").write_text(decoder)

verifier = """//! Relative signature facts for a new purpose; not original-owner authority.
//! This source draft is unwired. There is no production enrollment constructor,
//! signer, private key, loader, CURRENT conversion, Root capability or effect.

use std::marker::PhantomData;
use std::rc::Rc;

use codex_hepta_types::AuthorityPosture;
use codex_hepta_types::Digest32;
use codex_hepta_types::StableId;

use super::ArtifactOwnerVerifierV1;
use super::verify_signature;
use super::verify_signer_context;

#[path = "owner_cold_use_wire.rs"]
mod wire;
#[path = "owner_cold_use_decode.rs"]
mod decode;

use wire::CanonicalBytes;
use wire::ColdUseError;
use wire::ColdUseGrantV1;
use wire::SignedArtifactColdUseGrantV1;

const POLICY_PURPOSE: &[u8] = b"hepta.learning-artifacts.cold-task-use-policy.v1";

/// Intentionally private data, not an installed production policy capability.
/// Future component fixtures may construct it in their child test module.
struct RelativeColdUsePolicyV1 {
    policy_id: StableId,
    generation: u64,
    owner_trust_digest: Digest32,
    permitted_subject_digest: Digest32,
    head_signer_id: StableId,
    head_signing_key_digest: Digest32,
    minimum_head_epoch: u64,
    maximum_head_epoch: u64,
    valid_from_unix_ms: u64,
    expires_at_unix_ms: u64,
    maximum_lifetime_ms: u64,
    revoked_at_unix_ms: Option<u64>,
}

#[derive(Default)]
enum Enrollment {
    #[default]
    Disabled,
    RelativeOnly(RelativeColdUsePolicyV1),
}

/// Default always refuses. No public/parent constructor can enroll a purpose.
#[derive(Default)]
struct ColdUseSignatureVerifierV1 {
    enrollment: Enrollment,
}

struct ColdUseCheckTimeV1 {
    now_unix_ms: u64,
    observed_time_floor_unix_ms: u64,
    original_use_deadline_unix_ms: u64,
}

/// A scoped relative fact only. Private fields and Rc marker preclude cloning,
/// serialization and Send/Sync; it has no conversion to CURRENT or writer types.
struct RelativeColdUseSignatureV1<'scope> {
    grant_digest: Digest32,
    policy_digest: Digest32,
    authority: AuthorityPosture,
    scope: PhantomData<(&'scope ColdUseSignatureVerifierV1, Rc<()>)>,
}

impl ColdUseSignatureVerifierV1 {
    fn check_signature<'scope>(
        &'scope self,
        owner: &ArtifactOwnerVerifierV1,
        expected: &ColdUseGrantV1,
        signed: &'scope SignedArtifactColdUseGrantV1,
        time: ColdUseCheckTimeV1,
    ) -> Result<RelativeColdUseSignatureV1<'scope>, ColdUseError> {
        let Enrollment::RelativeOnly(policy) = &self.enrollment else {
            return Err(ColdUseError::Disabled);
        };
        let bytes = signed.grant.signing_bytes()?;
        // Exact equality covers every binding, nonce, time and original request.
        // The future product must derive expected from actual owners; these
        // deliberately untrusted inputs cannot themselves prove C or policy.
        if &signed.grant != expected {
            return Err(ColdUseError::Binding);
        }
        let grant = &signed.grant;
        let policy_digest = policy.digest()?;
        if grant.policy_id != policy.policy_id
            || grant.policy_digest != policy_digest
            || grant.policy_generation != policy.generation
            || owner.trust_digest != policy.owner_trust_digest
            || grant.owner_trust_digest != owner.trust_digest
            || grant.subject_digest()? != policy.permitted_subject_digest
            || grant.head_signer_id != policy.head_signer_id
            || grant.head_signing_key_digest != policy.head_signing_key_digest
            || grant.registry_id != owner.trust.registry_id
            || grant.withdrawal_scope_digest != owner.trust.withdrawal_scope_digest
            || grant.registry_generation < owner.trust.minimum_registry_generation.get()
            || grant.head_authority_epoch < owner.trust.minimum_authority_epoch
            || grant.head_authority_epoch < policy.minimum_head_epoch
            || grant.head_authority_epoch > policy.maximum_head_epoch
        {
            return Err(ColdUseError::Policy);
        }
        let duration = grant.expires_at_unix_ms.checked_sub(grant.issued_at_unix_ms)
            .ok_or(ColdUseError::Time)?;
        if time.now_unix_ms < time.observed_time_floor_unix_ms
            || time.now_unix_ms < grant.not_before_unix_ms
            || time.now_unix_ms > grant.expires_at_unix_ms
            || grant.issued_at_unix_ms < policy.valid_from_unix_ms
            || grant.expires_at_unix_ms > policy.expires_at_unix_ms
            || grant.expires_at_unix_ms > time.original_use_deadline_unix_ms
            || duration > policy.maximum_lifetime_ms
            || policy.revoked_at_unix_ms.is_some_and(|at| time.now_unix_ms >= at)
        {
            return Err(ColdUseError::Time);
        }
        // Reuse the exact original role map and strict current signer checks.
        // A writer, selector or Root key cannot substitute for a head signer.
        let signer = owner.head_signers.get(&grant.head_signer_id)
            .ok_or(ColdUseError::HeadSigner)?;
        if grant.expires_at_unix_ms > signer.expires_at {
            return Err(ColdUseError::Time);
        }
        verify_signer_context(
            signer,
            grant.head_signing_key_digest,
            grant.head_authority_epoch,
            grant.issued_at_unix_ms,
            time.now_unix_ms,
            /*require_current*/ true,
        ).map_err(|_| ColdUseError::HeadSigner)?;
        verify_signature(&signer.verifying_key, &bytes, &signed.signature)
            .map_err(|_| ColdUseError::Signature)?;
        Ok(RelativeColdUseSignatureV1 {
            grant_digest: signed.digest()?,
            policy_digest,
            authority: AuthorityPosture::DENY_ALL,
            scope: PhantomData,
        })
    }
}

impl RelativeColdUsePolicyV1 {
    fn digest(&self) -> Result<Digest32, ColdUseError> {
        if self.generation == 0
            || self.owner_trust_digest.is_zero()
            || self.permitted_subject_digest.is_zero()
            || self.head_signing_key_digest.is_zero()
            || self.minimum_head_epoch == 0
            || self.minimum_head_epoch > self.maximum_head_epoch
            || self.valid_from_unix_ms >= self.expires_at_unix_ms
            || self.maximum_lifetime_ms == 0
        {
            return Err(ColdUseError::Policy);
        }
        let mut out = CanonicalBytes::new(POLICY_PURPOSE);
        out.id(&self.policy_id);
        out.u64(self.generation);
        out.digest(self.owner_trust_digest);
        out.digest(self.permitted_subject_digest);
        out.id(&self.head_signer_id);
        out.digest(self.head_signing_key_digest);
        for value in [
            self.minimum_head_epoch,
            self.maximum_head_epoch,
            self.valid_from_unix_ms,
            self.expires_at_unix_ms,
            self.maximum_lifetime_ms,
        ] {
            out.u64(value);
        }
        match self.revoked_at_unix_ms {
            Some(at) => {
                out.tag(/*value*/ 1);
                out.u64(at);
            }
            None => out.tag(/*value*/ 0),
        }
        Ok(Digest32::of_bytes(&out.finish()))
    }
}
"""
(OUT / "owner_cold_use.rs").write_text(verifier)

inventory = []
for path in sorted(OUT.glob("*.rs")):
    data = path.read_bytes()
    inventory.append({"path": str(path.relative_to(ROOT)), "bytes": len(data),
                      "lines": len(data.splitlines()), "sha256": hashlib.sha256(data).hexdigest()})
assert all(x["lines"] < 500 for x in inventory)
(ROOT / "DRAFT_INVENTORY.json").write_text(json.dumps({
    "schema": "hepta.cold-use.primitive-source-draft.v1",
    "status": "UNWIRED_SOURCE_DRAFT; NOT_COMPILED_NOT_EXECUTED",
    "wire_contract_sha256": hashlib.sha256(WIRE.read_bytes()).hexdigest(),
    "original_source": "2b8125e3f89e83aea90620c94cbc441317d4c3d0",
    "inventory": inventory, "field_count": len(fields),
    "repository_source_modified": False, "module_declaration_installed": False,
    "production_policy_constructor": False, "production_signer": False,
    "compile": 0, "native": 0, "model": 0, "remote_jobs": 0,
}, indent=2) + "\n")
print(json.dumps(inventory))
