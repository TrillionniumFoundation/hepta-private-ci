"""Build design data only; no signatures, source mutation, model or native work."""

from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
STATUS = "PROPOSED_NOT_IMPLEMENTED_NOT_EXECUTED"
ART = "codex-rs/hepta-learning-artifacts/src/"
AG = "codex-rs/hepta-agentd/src/"
DOMAIN = "hepta.learning-artifacts.cold-task-use-grant.v1"


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def fields(group, authority, rows):
    return [{"group": group, "name": name, "encoding": encoding,
             "check_against": check, "authority_source": authority}
            for name, encoding, check in rows]


grant_fields = []
grant_fields += fields("purpose_policy", "independently provisioned actual Artifact authority policy", [
    ("schema_version", "u16_be", "exactly 1; this is a new protocol, not CURRENT V1"),
    ("operation_kind", "u8", "exactly ColdSameModelArtifactUse; fixed tag 1"),
    ("policy_id", "StableId", "the policy installed at the original Artifact owner boundary"),
    ("policy_digest", "Digest32", "all canonical actual policy fields, never a peer-supplied self-hash"),
    ("policy_generation", "u64_be", "exact current trusted policy generation, no regression"),
    ("grant_id", "StableId", "unique grant identity in the actual registry/policy ledger"),
    ("nonce", "[u8;32]", "nonzero independently generated nonce, reservation unique within registry/policy"),
])
grant_fields += fields("issuer", "actual ArtifactOwnerTrustV1.head_signers and current independently authenticated policy/revocation state", [
    ("head_signer_id", "StableId", "present in head_signers and permitted for this new purpose"),
    ("head_signing_key_digest", "Digest32", "digest of the independently provisioned actual verifying key"),
    ("head_authority_epoch", "u64_be", "actual head key epoch range and policy floor; never a Root or selector epoch"),
    ("owner_trust_digest", "Digest32", "the original owner verifier trust, including roles and scope"),
    ("issued_at_unix_ms", "u64_be", "real issuance time within actual signer and policy validity"),
    ("not_before_unix_ms", "u64_be", "issued_at <= not_before <= current actual authority time"),
    ("expires_at_unix_ms", "u64_be", "not_before < expires_at; current time <= expiry and policy maximum duration"),
])
grant_fields += fields("artifact_history", "pinned actual Artifact owner directories, unique complete history, and durable transaction receipts", [
    ("registry_id", "StableId", "original ArtifactOwnerTrustV1.registry_id"),
    ("storage_binding_digest", "Digest32", "original pinned physical storage binding; not path text alone"),
    ("original_signed_head_digest", "Digest32", "actual original head signing bytes plus its signature"),
    ("historical_chain_tip_digest", "Digest32", "actual latest unique physical tip; first version requires exact unchanged tip"),
    ("registry_generation", "u64_be", "actual original witness generation, above original trust/floor"),
    ("registry_head_digest", "Digest32", "actual head witness and registry receipt agree"),
    ("registry_snapshot_receipt_digest", "Digest32", "complete actual snapshot receipt, including original record counts and bindings"),
    ("registry_file_digest", "Digest32", "independently read exact original registry bytes"),
    ("transaction_receipt_digest", "Digest32", "actual durable original transaction checkpoint; no unfinished/conflicting publication"),
])
grant_fields += fields("artifact_model", "actual pinned canonical manifest/payload plus complete C and D model equality", [
    ("artifact_id", "StableId", "actual registry manifest and full selected C model"),
    ("artifact_kind", "u8", "existing ArtifactKind canonical tag and permitted whole-model kind"),
    ("artifact_generation", "u64_be", "actual selected artifact generation"),
    ("artifact_predecessor_id", "Option<StableId>", "actual lineage; None is explicit tag 0, not an invented zero digest"),
    ("content_digest", "Digest32", "complete actual payload bytes, not a selected partial model"),
    ("encoded_size_bytes", "u64_be", "complete actual payload size"),
    ("artifact_manifest_digest", "Digest32", "all canonical ArtifactManifest fields, including producer/objective/support/compatibility"),
    ("whole_model_manifest_digest", "Digest32", "complete actual model manifest, exactly matching completed C and D descriptor"),
    ("bundle_digest", "Digest32", "actual canonical whole bundle digest"),
])
grant_fields += fields("withdrawal", "actual original withdrawal owner/frontier and authenticated current policy status", [
    ("withdrawal_scope_digest", "Digest32", "original owner trust and selected model scope"),
    ("withdrawal_frontier_digest", "Digest32", "actual current frontier at signing and at each effect; exact equality in V1"),
    ("withdrawal_frontier_generation", "u64_be", "actual monotonically held frontier; no rollback or silent advance"),
])
grant_fields += fields("completed_c_conditions", "existing RootFinalizedColdHistoryV1 and RootFinalizedColdCReadV1; a signed condition is not a substitute C attestation", [
    ("c_learning_operation_id", "StableId", "actual completed predecessor operation"),
    ("c_completed_history_digest", "Digest32", "full actual completed history record"),
    ("c_current_head_digest", "Digest32", "actual completed C CURRENT"),
    ("c_finalized_successor_record_digest", "Digest32", "actual original Finalized successor record"),
    ("c_full_finalized_cut_digest", "Digest32", "complete original C cut, including version/profile and all original record bindings"),
    ("c_source_publication_digest", "Digest32", "actual original source publication represented by the complete cut"),
    ("c_whole_model_digest", "Digest32", "the exact complete C model, equal to the allowed artifact and D model"),
])
grant_fields += fields("new_d", "existing original Root cold registration, pinned D source/target and actual process/session context", [
    ("d_descriptor_digest", "Digest32", "canonical pre-selection descriptor; excludes this grant, selector and final UpdateIntent"),
    ("d_agent_id", "StableId", "actual registered D agent"),
    ("d_principal_id", "StableId", "actual enrolled principal"),
    ("d_recipient_identity_digest", "Digest32", "actual full recipient process identity and peer/session binding"),
    ("d_spawn_generation", "u64_be", "actual fresh process/spawn generation, not pid text"),
    ("d_run_id", "StableId", "actual new D run, distinct from completed C"),
    ("d_operation_id", "StableId", "actual original cold operation store key"),
    ("d_target_owner_binding_digest", "Digest32", "actual pinned target owner"),
    ("d_target_generation", "u64_be", "exact target generation under original CAS"),
    ("d_target_genesis_digest", "Digest32", "actual expected empty/genesis target state"),
    ("d_source_files_digest", "Digest32", "complete pre-selection original task/runtime/data source manifest and actual byte hashes; separately supplied new grant/selector/final-intent envelopes are excluded only from this acyclic preimage and bound later by the Root full-input manifest"),
    ("d_target_files_digest", "Digest32", "complete pre-selection original target-file manifest and bindings; no grant/selector/final-intent self-reference"),
    ("d_configuration_digest", "Digest32", "actual canonical pre-selection task configuration; exact mandatory authorization-envelope paths are declared, their future contents are bound by the later Root full-input manifest"),
    ("d_consumer_kind", "u8", "only the original cold same-model task consumer"),
    ("d_consumer_trust_digest", "Digest32", "actual original retained consumer trust and current revocation checks"),
])
grant_fields += fields("new_d_authbus", "actual independently signed original AuthBus request and Feature configuration", [
    ("authbus_signing_bytes_digest", "Digest32", "digest of all actual request signing bytes"),
    ("authbus_issuer_id", "StableId", "actual original authorized issuer"),
    ("authbus_signing_key_digest", "Digest32", "actual issuer key, not the head signer or selector key by substitution"),
    ("authbus_authority_epoch", "u64_be", "actual issuer-specific epoch"),
    ("authbus_message_id", "StableId", "actual original message identity"),
    ("authbus_sequence", "u64_be", "actual original sequence"),
    ("authbus_signature_digest", "Digest32", "actual complete signature bytes"),
    ("authbus_expires_at_unix_ms", "u64_be", "actual request expiry; scope cannot outlive it"),
    ("runtime_digest", "Digest32", "definition.runtime.runtime_digest"),
    ("feature_semantic_digest", "Digest32", "definition.semantic_digest, not bundle.digest"),
    ("artifact_set_digest", "Digest32", "bundle.digest"),
])

wire = {
    "schema": "hepta-artifact-cold-use-wire-design-v1", "status": STATUS,
    "purpose_literal_utf8": DOMAIN,
    "mode": "a single new same-model cold task; grants no training, registration, registry publication or Root authority",
    "encoding": {
        "signed_preimage": "literal purpose bytes followed by ordered_fields below; no signature bytes in preimage",
        "signature": "strict Ed25519, exactly 64 bytes; no alternative algorithm or domain fallback",
        "grant_digest": "SHA256(purpose bytes || complete signing preimage || signature); intentionally separate from original head digest",
        "fixed_integers": "unsigned big-endian; reject overflow rather than clamp or wrap",
        "Digest32": "exactly 32 bytes; independently recompute at the actual owner boundary",
        "StableId": "existing canonical StableId bytes preceded by u64_be byte length, matching original owner_host::push_id; retain existing StableId validation and refuse any ID that exceeds the total record bound",
        "Option<StableId>": "one byte 0 for None or 1 followed by canonical StableId; all other tags reject",
        "maximum_record_bytes_including_signature": 16384,
        "size_limit_source": ART + "owner_host.rs::MAX_SMALL_RECORD_BYTES",
        "text_transport": "if JSON/text is exposed, reject unknown/duplicate fields and require exact typed canonical re-encoding; text hashes are not signature preimages",
        "digest_zero_rule": "reject zero for required identity/authority/content digests; only protocol-defined genesis values may be zero and must equal actual original genesis semantics",
        "future_versions": "reject; no permissive skip, conversion to CURRENT V1, or V1 selector compatibility fallback",
    },
    "ordered_fields": grant_fields,
    "descriptor_dependency_order": [
        "freeze original D request/source/target/recipient/operation and C/model conditions",
        "derive pre-selection D descriptor; exclude grant, selector and final UpdateIntent",
        "actual head authority signs grant after its independent policy checks",
        "independent selector signs new cold-use selection over complete old selector fields plus grant_digest and d_descriptor_digest",
        "Root computes purpose-specific observation and final intent from both signatures and actual original C/D evidence",
    ],
    "descriptor_file_boundary": {
        "preimage_contains": "a closed complete manifest of original D task/runtime/data source, target and pre-selection configuration; mandatory separate authorization-envelope names/roles are declared",
        "excluded_from_preimage_only": ["the new grant bytes", "the subsequent new selector bytes", "the final Root UpdateIntent bytes"],
        "later_binding": "Root full-input manifest binds every actual input including these three envelopes before admission; actual pinned source/target bytes must equal the earlier closed manifest",
        "no_blanket_exclusion": "arbitrary source fields/files cannot be stripped to make a hash match; canonical typed schemas reject unknown/extra/missing task fields and missing required authorization files",
    },
    "selection_domain_proposed": "hepta.learning-artifacts.cold-task-use-selection.v1",
    "selection_additions": ["new purpose/version", "grant_digest", "d_descriptor_digest", "policy_digest", "policy_generation"],
    "selection_existing_fields": "retain every SignedArtifactSelectionV1 field and check; historical witness is a named fact in this new type, never a VerifiedCurrentRegistryViewV1",
    "effective_expiry": {
        "minimum_of": ["new grant expiry", "actual current head signer validity", "actual purpose policy validity", "independent selector expiry", "new Root issuer expiry", "new Root writer expiry", "original AuthBus request expiry", "new D original 120-second deadline", "whole-cold original 480-second deadline"],
        "not_changed": ["old learning 240-second envelope", "old writer actual 300-second retirement rule", "generic CURRENT expiry", "old V3 publication admission"],
        "old_head_expiry": "is still expired and generic interfaces reject; independently authorized historical use does not cap its new permission by the expired old permission",
        "clock": "actual original authority clock and monotonic held floor; external I/O requires a fresh scoped check",
    },
    "production_prerequisites_not_present": [
        "independent actual Artifact authority provisioning for this new purpose",
        "real head private-key custody and issuing service",
        "authenticated current key/policy generation and revocation input",
        "durable signer reservation/Attempted/Signed journal and recovery",
        "if issuer policy requires observing completed C itself: an authenticated actual C read/attestation input, not client-provided expected JSON",
        "new purpose-specific Root/selection/generation/live consumers with original withdrawal checks",
    ],
    "executions": {"signatures_issued": 0, "compile": 0, "native": 0, "model": 0, "remote_jobs": 0},
}
write("WIRE_CONTRACT.json", wire)


def edit(path, mode, boundary, change, invariant, evidence="pinned in SOURCE_BINDINGS.json"):
    return {"path": path, "mode": mode, "boundary": boundary, "proposed_change": change,
            "must_preserve": invariant, "source_evidence": evidence}


primitive = [
    edit(ART + "owner_cold_use_grant.rs", "NEW", "Artifact cryptographic fact",
         "Canonical new transport and policy data; private authenticated fact; strict current head-role and installed-purpose verification",
         "No signing key, default signer, Root capability or generic CURRENT output", "new proposed module; no existing implementation claimed"),
    edit(ART + "owner_cold_use_reader.rs", "NEW", "Artifact original physical facts",
         "Closed original-config constructor and synchronous scoped actual history/receipt/payload/withdrawal read",
         "No public allow_expired, caller-selected historical time, mutable registry, generic current conversion or reusable borrowed capability", "new proposed module"),
    edit(ART + "cold_use_selection.rs", "NEW", "independent selector",
         "New signature purpose and exact grant/D binding, private purpose-specific selected artifact",
         "V1 signing bytes/semantics unchanged; no conversion to generic selected/current types", "new proposed module"),
    edit(ART + "owner_host.rs", "MODIFY_PRIVATE_ONLY", "head role/signature/policy",
         "Share exact private key/epoch/signature logic; add new-purpose verifier that requires independently installed original policy",
         "Current-head and writer-lease verifiers retain original domains and all time/revocation checks"),
    edit(ART + "owner_read_view.rs", "MODIFY_PRIVATE_ONLY", "historical chain facts",
         "Factor private complete chain/snapshot fact scan for historical use while retaining exact final generic current checks",
         "discover_current_head_unanchored still requires current signer and unexpired latest CURRENT"),
    edit(ART + "owner_original_reader.rs", "MODIFY_PRIVATE_ONLY_IF_NEEDED", "file ownership and monotonic floor",
         "Reuse private original-directory, pending-transaction and monotonic-floor helpers without widening its public current reader",
         "Existing original current reader before/after reads, floor updates only on success, and fence behavior"),
    edit(ART + "owner_withdrawal_frontier.rs", "MODIFY_PRIVATE_ONLY_IF_NEEDED", "actual withdrawal",
         "Share only exact original frontier fact checks for new scoped reader",
         "No absence-of-revocation claim from a stale fixed trust snapshot; no frontier rollback"),
    edit(ART + "pinned.rs", "MODIFY_PRIVATE_ONLY_IF_NEEDED", "exact immutable loading",
         "Factor content/canonical-file algorithms only if the new selected wrapper needs them",
         "Old authorization-bearing PinnedCandidateSpec/RevalidatingCandidate cannot accept a new historical grant as current"),
    edit(ART + "lib.rs", "MODIFY_NARROW_EXPORTS", "crate boundary",
         "Wire proposed modules and only required untrusted data/closed owner interfaces",
         "No public constructors for verified operations or cross-crate dependency on Agentd Root types"),
]
product = [
    edit(AG + "authority_host_cold_next_task_enrollment.rs", "MODIFY_PURPOSE_SPECIFIC", "actual Root cold registration",
         "An explicit current-vs-cold-use typed input and closed joining of actual finalized C, D files, grant and selector",
         "Actual original C/history/retirement/consumer/target/genesis checks and current route are unchanged"),
    edit(AG + "authority_host_cold_next_task_context.rs", "MODIFY_PURPOSE_SPECIFIC", "Root operation lifetime",
         "Carry independently pinned policy and purpose identity into a new private scoped conjunction",
         "Existing session/process/clock/current-revocation/lease checks, non-Send borrow and original deadline"),
    edit(AG + "authority_host_cold_next_task_grant.rs", "MODIFY_PURPOSE_SPECIFIC", "actual FinalUse attempt",
         "Bind grant digest/nonce/D descriptor in actual profile and intent, while using the original Root signing authority and store",
         "No Artifact grant converted to SignedFinalUseGrant; preserve Attempted/Issued and original post-observation"),
    edit(AG + "authority_host_cold_next_task_runtime.rs", "MODIFY_PURPOSE_SPECIFIC", "actual operation runtime",
         "Reenter original cold-use checks before effects and after returned effects; purpose-specific durable consumption identity",
         "No callback borrow across await, no retry of uncertain dispatch, one original ObjectiveStart and FinalUse"),
    edit(AG + "production_cold_q24_artifacts.rs", "MODIFY_EXPLICIT_BRANCH", "Artifact loading",
         "New readonly historical-use owner from original files/policy; current route keeps original owner service",
         "Do not open fresh generic Artifact writer to revive expired CURRENT; no writer authority from the new read branch"),
    edit(AG + "production_cold_next_q24.rs", "MODIFY_EXPLICIT_BRANCH", "cold product assembly",
         "Use new selected and generation types only for exact authorized same-model D",
         "Whole-parent budget, original C unchanged, actual Root controls and original NoUpdate path"),
    edit(AG + "neuron_generation_artifact_readback.rs", "MODIFY_CLOSED_VARIANT", "generation read authority",
         "Private RootColdUse variant constructed only from actual Root cold client; explicit scoped readback",
         "writer(), with_initial and old generic update/learning routes reject this variant"),
    edit(AG + "neuron_generation_update_selection.rs", "MODIFY_WITH_NEW_PRIVATE_TYPES", "selected model and observation",
         "New selected wrapper and domain-separated observation including all grant/policy/D fields",
         "No ordinary observation digest reuse, model identity truncation or public selected-type conversion"),
    edit(AG + "neuron_generation_update_cold.rs", "MODIFY_DEDICATED_ENTRY", "same-model cold prepare",
         "New entry accepts only exact typed cold-use operation and OwnerDrainedSameModel; common immutable algorithms may be private",
         "Actual predecessor lock/drain, complete model equality, empty target/genesis and original C physical state"),
    edit(AG + "neuron_generation_update.rs", "MODIFY_TYPED_INTERNAL_CORE_OR_NEW_MODULE", "prepare/publish/recovery",
         "Purpose-specific prepared publication, original FinalUse/CAS and exact published-only recovery; shared mechanics private",
         "Old writer() requirements unchanged; no broad fallback or caller-provided completion/allow callback"),
    edit(AG + "neuron_generation_update_live.rs", "MODIFY_PURPOSE_SPECIFIC", "live use and effect revalidation",
         "Dedicated constructor and live provenance that revalidates the exact new purpose at original effect boundaries",
         "Expired/revoked grants reject new effects; no learning-owner or generic writer downcast"),
    edit(AG + "neuron_generation_update_runtime_support.rs", "REVIEW_AND_MODIFY_ONLY_REQUIRED_TYPED_PLUMBING", "runtime/Feature handoff",
         "Carry purpose-specific owner/provenance through actual model/runtime setup without collapsing it into ordinary authorization",
         "Actual Feature ownership/guard checks and runtime/semantic/bundle distinction"),
]
patch = {
    "schema": "hepta-artifact-cold-use-patch-plan-v1", "status": STATUS,
    "not_a_token_only_patch": True,
    "primitive_layer": primitive, "required_product_layer": product,
    "integration_surfaces_requiring_exact_review_before_implementation": [
        {"surface": "cold task profile serialization, registration digest and persistent nonce store", "reason": "bind grant/nonce/D descriptor in original durable operation without changing identity on retry", "status": "exact owned source must be added to the implementation inventory before edits; not falsely treated as already implemented"},
        {"surface": "Root cold client readback and generation CURRENT publication provenance", "reason": "cross-process input must remain data, with closed actual owner construction and live revalidation", "status": "requires concrete new wire/type review; no arbitrary client callback"},
        {"surface": "production Artifact authority policy enrollment, custody and revocation source", "reason": "there is no current issuer service to attach a fixture key to", "status": "production prerequisite; service path and custody adapter intentionally not invented"},
    ],
    "unchanged_semantic_interfaces": [
        "VerifiedCurrentRegistryViewV1 and generic expired CURRENT rejection",
        "SignedArtifactSelectionV1 signing domain and all original checks",
        "LearningArtifactOwnerService::open writer/current semantics",
        "Artifact V2/V3 publication admission and old learning deadlines",
        "Root FinalUse authority source and original old-process retirement proof",
        "original NoUpdate retained CURRENT 600-second route",
    ],
    "planned_qa": [
        "new component tests use explicit test head policy/key only and are labelled fixture evidence",
        "real original-file/withdrawal/pending-transaction mutation controls",
        "real signer/consumer witness fault and unknown-outcome recovery controls",
        "type/source negative controls for all new closed constructors and before/after boundaries",
        "CALLERS/protected additions preserve the entire final composed cold baseline, including same-path distinct protected constraints",
        "whole-cold Adopt test remains a separate gate using the original deadlines and actual completed C/retirement/new D",
    ],
    "current_source_edits": 0, "current_test_executions": 0,
}
write("PATCH_PLAN.json", patch)


controls = []
def control(title, layer, trigger, owner, expected, durable="no authoritative state mutation before rejection", source=None):
    controls.append({"id": f"CU-{len(controls)+1:02d}", "title": title, "status": "PLANNED_NOT_EXECUTED",
                     "layer": layer, "actual_trigger_required": trigger, "real_owner_boundary": owner,
                     "expected_rejection_or_gate": expected, "required_durable_observation": durable,
                     "source_anchor": source})

control("Wrong signer role", "signature/component", "Sign the new bytes with valid writer-only, selector-only and Root issuer keys in their actual separate test roles", "ArtifactOwnerTrustV1.head_signers plus installed purpose policy", "All reject; a valid head signature is necessary but still not sufficient", source=ART+"owner_host.rs")
control("Self-installed or absent purpose policy", "source/native integration", "Supply a self-consistent policy/trust JSON from D while the original provisioning is absent or different", "actual Artifact policy enrollment", "Default deny; no peer-created verifier/policy is accepted as the original product owner")
control("Signature domain and field substitution", "signature/component", "Reuse CURRENT/writer/selector signatures, mutate each canonical signed field, substitute signature or complete grant digest", "strict new purpose signature", "Strict verification rejects every mutation and cross-domain reuse", source=ART+"owner_host.rs")
control("Current head signer validity and epoch", "signature/component", "Actual signer expired, revoked before use, issued outside key window, or epoch outside range/floor", "actual head signer and current policy state", "Reject independently of a historically valid old head", source=ART+"owner_host.rs")
control("Time and integer boundaries", "component/native clock", "Future issue/not-before, crossed expiry, backward held clock, checked-duration overflow and wrong epoch/time units", "actual authority clock and monotonic reader floor", "Reject without clamping, caller-selected historic now or deadline extension")
control("Policy change after issuance", "native original policy", "Change actual authenticated policy generation or revoke the new purpose between before/after observations", "actual independently provisioned policy owner", "Reject/fence; stale policy hash and old snapshot cannot stand in for current policy")
control("Cross-registry trust or storage", "native physical identity", "Move valid grant to another actual registry/storage owner/withdrawal scope or replace the pinned original trust", "original directories and Artifact verifier", "Reject every scope/binding mismatch", source=ART+"owner_original_reader.rs")
control("Malformed or noncanonical transport", "parser/component", "Oversize record, duplicate/unknown fields, wrong version/tags, truncated signature/digest, extra bytes, bad length or illegal zero binding", "new bounded canonical parser", "Reject before trusted fact creation; no permissive version fallback")
control("Forked/disconnected/rolled-back head history", "native original files", "Modify real pinned head directory into a fork, disconnected link, generation/epoch regression or older trusted floor", "complete physical head scan", "Reject even when every isolated head has a valid historical signature", source=ART+"owner_read_view.rs")
control("Changed tip or unfinished publication", "native original files", "Add a new physical head tip or actual unresolved/conflicting publication checkpoint after issuance", "actual head chain and transaction receipt", "Strict V1 rejects a changed tip and unfinished state, including benign advance", source=ART+"owner_read_view.rs")
control("Expired CURRENT separation", "native paired paths", "Use an actually expired original CURRENT with a valid new fixture grant, then call old generic reader, owner service, V1 selector and writer APIs", "new historical branch versus old generic paths", "Generic paths still reject; any narrow success is only component fixture evidence for the exact D purpose", source=ART+"owner_service.rs")
control("Actual file replacement and directory pins", "native physical fault", "Symlink/replace/mutate pinned directory, registry or payload at real before/after hooks", "actual FDs/inode/uid/mode and before/after reads", "Reject the actual identity/content fault; a lock-busy result alone does not cover a post-read fault", source=ART+"owner_original_reader.rs")
control("Registry snapshot/transaction substitution", "native original files", "Replace a valid-looking snapshot or receipt with different actual bytes/counts/head/witness/storage binding", "actual durable original transaction", "Reject self-consistent derived JSON when original transaction/file identity differs", source=ART+"owner_read_view.rs")
control("Payload bytes and canonical size", "native pinned loading", "Mutate/truncate/append actual payload or substitute noncanonical model bytes at the original pinned loader", "actual immutable model payload", "Reject hash, size or canonical-model mismatch", source=ART+"pinned.rs")
control("Whole-model and lineage substitution", "component/native selection", "Keep one content field while changing artifact ID/kind/generation/predecessor/full manifest or selecting only a partial C model", "full C/Artifact/D model equality", "Reject all changes; complete-model equality is required", source=ART+"model.rs")
control("Actual withdrawal after issuance", "native original withdrawal", "Advance or replace real withdrawal frontier, including target quarantine/revocation, between issuance, selection and effect", "actual original withdrawal owner/frontier", "Reject/fence; V1 also rejects unrelated frontier changes instead of silently relaxing policy", source=ART+"owner_withdrawal_frontier.rs")
control("Selector V1 or grant swap", "signature/component", "Replay an old SignedArtifactSelectionV1 or substitute grant/D descriptor/policy under a new cold-use selection", "independent new Selector purpose", "Reject; V1 cannot authorize the new historical purpose", source=ART+"selection.rs")
control("Selector authority independence", "signature/native", "Use producer-colliding, expired, revoked, wrong-epoch/key or untrusted selector while head grant remains valid", "actual selector trust plus original role collision checks", "Reject independently of the head signature", source=ART+"selection.rs")
control("Unfinalized or JSON-only C", "native actual Root", "Offer Registered/incomplete C or a fabricated completed-C JSON without actual Root history/capability", "RootFinalizedColdHistoryV1 and RootFinalizedColdCReadV1", "Reject; grant C fields are conditions and do not create completed C", source=AG+"authority_host_cold_finalized_c.rs")
control("Changed actual completed C", "native actual Root files", "Mutate actual Finalized successor record, CURRENT, full cut or source publication at a real post-observation hook", "actual C files and complete history", "Reject after-read mismatch with exact hook evidence; retain original C bytes for comparison", source=AG+"authority_host_cold_completed_history.rs")
control("Retirement proof reconstruction", "native process ownership", "Use archived pid/process JSON or no real old-process exit/writer retirement proof before the cold transition", "original Root cold retirement and retained process owners", "Reject; no restoration of pidfd/proof from an evidence archive and no shortening of the original 300-second rule")
control("Wrong D recipient or generation", "native original registration", "Replay to another principal/process/spawn generation/run/target owner or non-genesis target", "actual original cold D session, target and CAS", "Reject every mismatch, even with the same artifact", source=AG+"authority_host_cold_next_task_enrollment.rs")
control("AuthBus request identity", "native original signed input", "Change signed request/file copy, run, runtime, Feature semantic tuple or bundle independently; include the previously observed tuple=bundle construction error", "actual original request and Feature configuration", "Exact full signed-byte match and separate runtime/semantic/bundle checks reject inconsistencies; never weaken the Feature guard")
control("Wrong operation/consumer/source", "native original Root", "Swap operation ID, retained consumer/trust, source or configuration while keeping the grant signature valid for a different descriptor", "actual Root registered slot and consumer revocations", "Reject with no new operation or nonce invented", source=AG+"authority_host_cold_next_task_context.rs")
control("Concurrent/replayed nonce consumption", "native durable store", "Attempt two actual reservations for same nonce; repeat under another operation/recipient/generation or changed preimage", "original Root cold operation store/profile/witness", "At most one matching attempt; mismatches reject", "Record actual reservation and witness bytes; no second effect or hidden nonce replacement")
control("Unknown actual signing outcome", "native custody fault fixture", "Inject lost acknowledgement/failure after the actual fixture custody sign call and before durable Signed result", "proposed real issuer journal and signer adapter", "No automatic re-sign/new nonce/extended grant; only read exact already durable signature", "Actual Reserved/SigningAttempted/Signed bytes and signer call count; explicitly fixture evidence, not deployed custody")
control("Actual FinalUse/witness fault", "native original durable fault", "Inject actual journal or witness persistence failure before and after Root FinalUse issue using hooks that reach the intended write", "original Root cold grant/operation store", "Preserve Attempted or Issued as actually reached; do not rollback to unused or issue again", "Actual journal/witness bytes and sign/dispatch counts; lock contention is not a substitute for write-fault coverage", AG+"authority_host_cold_next_task_grant.rs")
control("Post-publication owner change", "native original CAS/after-read", "Make actual grant/policy/files/C/withdrawal check fail after an actual successful CAS/publication", "original generation publication and after-observation", "Fence/reject further effects, retain actual Published and original C; do not report a clean unattempted rollback", "Actual target and journal before/after plus no second FinalUse/ObjectiveStart", AG+"neuron_generation_update.rs")
control("Private scope escape", "compile-fail/source", "Try public construction, Deserialize/Clone/Send, borrow escape, cross-await retention or fake-trust injection for new operation types", "HRTB and private actual owner constructors", "Compilation/source checks reject; a callback lifetime or guard cannot be chosen by a peer")
control("Writer/current/learning escalation", "compile-fail/native branches", "Pass RootColdUse through writer(), RootInitial, generic update/recovery/learning or convert to VerifiedCurrentRegistryViewV1/ordinary selection", "closed GenerationArtifactOwnerV1 and typed publication provenance", "Every escalation rejects; only the exact cold-same-model entry is possible", source=AG+"neuron_generation_artifact_readback.rs")
control("Recovery without a new effect", "native restart", "Restart after unknown/prepared/issued/published states with exact and mutated grant/operation bindings", "actual original journal and purpose-specific recovery", "Only exact durable published observation recovers; no new sign, dispatch, expiry extension or purpose conversion", "Original durable state preserved across a real restart and call counters prove zero new effects", AG+"neuron_generation_update.rs")
control("Live expiry or revocation", "native actual effect boundary", "Expire grant/selector/Root request or revoke policy/artifact after loading but before the next actual live effect/output", "purpose-specific LiveGenerationCurrent and original guards", "No new effect/output after denial; a one-time startup check is insufficient", "Observe actual effect count and durable/fenced state without inventing a successful completed D", AG+"neuron_generation_update_live.rs")
control("Closed callers and removed-check mutations", "source gates", "Delete each original/new before/after guard, add unauthorized constructor calls including UFCS spellings, or drop cold protected rows", "full final composed CALLERS/protected sets", "Exact guards catch each mutation; preserve every original cold boundary and same-path distinct rule", "Retain original failures and full source inventories; no legacy gate repin to accept a missing check")
control("Whole-cold claim and NoUpdate regression gate", "whole-parent acceptance", "Try to claim completion from only fixture/primitive tests, archived C/retirement, changed deadlines, partial model or missing real FinalUse; compare original NoUpdate route", "original whole-cold A/B/C -> retirement -> new D parent", "A claimed Adopt pass requires fresh actual A/B/C, independent new head permission/selector, true retirement, one D and FinalUse within original 480/240/300/120 rules; NoUpdate600 route unchanged", "Save all original native/parent outputs, failures, exact owners/source and C-unchanged bytes; component pass never counts as whole-parent success")

assert len(controls) == 34
write("REJECTION_CONTROLS.json", {
    "schema": "hepta-artifact-cold-use-rejection-controls-v1", "status": STATUS,
    "planned_controls": len(controls), "executed_controls": 0,
    "controls": controls,
    "execution_authorization": "This document does not start or authorize a new native/model/remote owner. Root coordinates any later implementation and exact-source gates.",
})


bindings = json.loads((ROOT / "SOURCE_BINDINGS.json").read_text())
for item in bindings["sources"]:
    data = (ROOT / "source" / item["path"]).read_bytes()
    assert len(data) == item["bytes"]
    assert hashlib.sha256(data).hexdigest() == item["sha256"]
    assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == item["git_blob"]

anchor_requests = [
    (ART+"owner_host.rs", "pub struct TrustedArtifactSignerV1", "original signer key, epoch, time and revocation fields"),
    (ART+"owner_host.rs", "pub struct ArtifactOwnerTrustV1", "distinct head and writer roles in the original trust"),
    (ART+"owner_host.rs", "fn verify_signed_head(", "original private head-role signature verification"),
    (ART+"owner_host.rs", "fn verify_signer_context(", "historical versus current signer checks"),
    (ART+"owner_host.rs", "fn verify_signature(", "original strict signature verification"),
    (ART+"owner_read_view.rs", "fn discover_current_head_unanchored(", "complete history followed by original current validation"),
    (ART+"owner_read_view.rs", "CurrentHeadExpired", "generic CURRENT expiration rejection remains unchanged"),
    (ART+"owner_original_reader.rs", "fn read_original_registry(", "original file owner before/after checks"),
    (ART+"selection.rs", "pub struct SignedArtifactSelectionV1", "current selection fields do not contain a new D-use grant"),
    (ART+"owner_service.rs", "pub fn open(", "current writer service is not a new historical-use reader"),
    (AG+"neuron_generation_artifact_readback.rs", "enum GenerationArtifactOwnerV1", "current concrete Writer/RootInitial variants"),
    (AG+"neuron_generation_artifact_readback.rs", "fn writer(", "current nonwriter update rejection"),
    (AG+"authority_host_cold_finalized_c.rs", "struct RootFinalizedColdCReadV1", "actual Root proof, never fabricated from grant conditions"),
    (AG+"authority_host_cold_next_task_context.rs", "struct OriginalColdNextTaskContextV1", "actual scoped Root session/lease context"),
    (AG+"authority_host_cold_next_task_grant.rs", "struct RootPreparedColdNextTaskGrantV1", "actual Root FinalUse owner distinct from Artifact head authority"),
]
source_by_path = {x["path"]: x for x in bindings["sources"]}
anchors = []
for path, needle, reason in anchor_requests:
    original = source_by_path[path]
    rows = (ROOT / "source" / path).read_text().splitlines()
    matches = [n for n, line in enumerate(rows, 1) if needle in line]
    assert len(matches) == 1, (path, needle, matches)
    entry = {"path": path, "source": original["source"], "line": matches[0],
             "exact_line": rows[matches[0]-1], "reason": reason,
             "git_blob": original["git_blob"], "sha256": original["sha256"],
             "public_commit": original["public_commit"]}
    if original["public_commit"]:
        entry["url"] = original["url"] + "#L" + str(matches[0])
    anchors.append(entry)
write("SOURCE_ANCHORS.json", {"schema": "hepta-cold-use-source-anchors-v1", "anchors": anchors,
                              "qualification": "exact original source locations, not executed proof of the new design"})

deliverables = ["DESIGN.md", "API_CONTRACT.md", "SOURCE_BINDINGS.json", "SOURCE_ANCHORS.json", "WIRE_CONTRACT.json", "PATCH_PLAN.json", "REJECTION_CONTROLS.json", "build_design_contracts.py"]
inventory = []
for name in deliverables:
    data = (ROOT / name).read_bytes()
    inventory.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
write("RESULT.json", {
    "schema": "hepta-artifact-cold-use-design-readout-v1", "status": "DESIGN_ONLY_COMPLETE_FOR_REVIEW",
    "ordinary_source": "2b8125e3f89e83aea90620c94cbc441317d4c3d0",
    "ordinary_tree": "9fd4268ef5ffd63661e067b6ee043f0e522e97ab",
    "cold_source": "6733159bd974ae6558e138112d81ca2f6da830e2",
    "cold_public_object_claim": False,
    "complete_bound_source_files": len(bindings["sources"]),
    "public_bound_source_files": sum(bool(x["public_commit"]) for x in bindings["sources"]),
    "source_readback": "all complete original source lengths, SHA256 and Git blob hashes match SOURCE_BINDINGS.json",
    "wire_ordered_fields": len(grant_fields),
    "planned_rejection_controls": len(controls), "executed_rejection_controls": 0,
    "product_source_edits": 0, "signatures_issued": 0, "compile": 0, "native": 0, "model": 0, "remote_jobs": 0,
    "physical_energy": None, "monetary_cost": None,
    "separate_from": ["original NoUpdate cold composition", "cold_d_identity_draft three-file request correction", "ordinary source gates and NoUpdate owners"],
    "production_authority_missing": True,
    "can_claim": "source-grounded proposed primitive and explicit integration/rejection design",
    "cannot_claim": ["production issuer/custody/policy enrollment exists", "new signatures or passing controls", "working Adopt cold D", "whole-cold pass", "generic expired CURRENT renewed"],
    "artifacts": inventory,
})
print(json.dumps({"sources_verified": len(bindings["sources"]), "wire_fields": len(grant_fields), "planned_controls": len(controls), "executed": 0, "artifacts": inventory}, ensure_ascii=False))
