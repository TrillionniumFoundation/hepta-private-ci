## Why this candidate exists

Continue the original E1–E6 work with fixed experiment identities, budgets, acceptance gates and negative history. The #6709 accounting fix is integrated: `ADOPTED` / `NO_UPDATE` labels alone no longer count as completed use; the original verified-use and cold-process replay conditions are required.

**All ten joint qualification flags remain false.** This draft is a reviewable integration and evidence checkpoint. It does not authorize a merge, production activation, settlement, public-reward expansion or extra exhausted teacher/student calls.

## Current checkpoint

Evidence head: `d1d3896e2a2628977bc466cee1e00aea93971949`, tree `05c2e91d6387b60b07952282a8911ca52dd3d0bd`, parent `238fc48402f786db3d7f2a80b0abad6c0e5322bb`. The observation was frozen at **2026-11-20 03:30 America/New_York**. The historical joint execution source remains `e52c4f67cb58a65409256f7be263cfb49ac22557`; independent branch passes are not relabelled as a joint execution.

- [Full current readout](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/d1d3896e2a2628977bc466cee1e00aea93971949/qualification/cell-joint-20261118-2e9b/CURRENT_PROGRESS.md)
- [Machine-readable evidence and source bindings](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/d1d3896e2a2628977bc466cee1e00aea93971949/qualification/cell-joint-20261118-2e9b/CURRENT_PROGRESS.json)
- [Exact previous CURRENT bytes and checkpoint construction](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/d1d3896e2a2628977bc466cee1e00aea93971949/qualification/cell-joint-20261118-2e9b/checkpoint-20261120)

## Changes and actual results

| Work | Evidence at this checkpoint | Qualification boundary |
| --- | --- | --- |
| #6709 integration | Exact production/test blobs from `773f25e5`; integrated at `0bdf6544`; original 114 controls / 18 modules pass. Old-production negative control fails as expected. Exact prior candidate formatter and check pass with zero diff. | Correct accounting does not itself qualify native adoption. |
| E1 / E2 | [#6778](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6778): both original 32-update students complete all original 56 new generations; 47 native executions, 9 admission refusals. Both students score 1/4 on A; P and both students score 0/4 on the frozen future panel. [#6780](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6780) verifies changed adapter tensors and actual load bindings. | ResearchNoUpdate. No future gain or demonstrated retention; no extra calls. |
| E3 | [#6781](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6781) at `6cce823f`: bounded independent-weight recovery terminates incomplete; 901,316,608 of 3,422,777,952 unique bytes retained. All four workers have terminal results. | Full weight SHA unverified; no new teacher load, training, generation or native execution. Historical T2 evidence and used budgets remain. |
| E4 | Original strong single-model comparisons and all ablations remain: PP/CC/PC/CP each 5/6; oracle 6/6 is only coverage. | No new calls; effective Circuit necessity not demonstrated. |
| E5 | [#6777](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6777), [#6782](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6782), [#6783](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6783): 16 public project materials and exact original before/after evidence. Staged codec work [#6786](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6786)–[#6790](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6790), final `148e37c2`: 16 structural round trips, 11 limited executable actions, 2 limited static closures. | 15/16 inputs exceed the original token cap; fixed 1/4/16 prefixes are not admitted. Zero growth-training updates and authenticated users; both original curves remain null. |
| E6 | [#6776](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6776), evidence `02d5b32d`, tested source `640bac3c`: full 415 source / 907 protected / 320 targeted / 1,159 caller checks, original project lint and native 11+16+5 pass. Original NoUpdate6 still fails `Invalid("Unavailable")` before completed C. | Complete NoUpdate, Adopt, cold new D, FinalUse and settlement remain false. Earlier read65 and signed-C-identity failures remain. ACK/CURRENT overlap is a source-grounded candidate cause, not a proven historical diagnosis. |
| Chain | [#970](https://github.com/TrillionniumFoundation/Trillionnium-Chain/pull/970) retains focused W1 delay controls and the real old-production negative control. | Original full-repository failures, F0 liveness/depletion failures and incomplete system costs remain; rewards unchanged. |

## Two Mac fixture changes

The only additional product-tree changes in this checkpoint are two test files: external-material fixtures create temporary directories under the canonical temp root, and the causal Cell reopen fixture uses the same canonical fleet path as `create_run`. Product guards and original assertions are unchanged.

Formatting passed. Project native verification remains blocked by exact dependency material. Native4 terminated with dependency-download exit 101; native5, after exact crossterm material preparation, terminated with locked-offline tokio-tungstenite material missing. Both executed zero Rust cases. Original preparation failures, the native3 interruption, the native4 tool/OS status disagreement, the failed overbroad seed precheck, successful scoped local seed, and all subsequent actual terminal receipts are retained. There was no duplicate Cargo owner or PID kill.

## Verification and remaining gates

- The original 238 checkpoint's exact incremental blob gate passed (27 paths); its original receipts are now retained here.
- This candidate passed the exact original blob gate for all 97 changed paths from `238fc484` to `d1d3896e` (exit 0; 0.826 seconds; RESULT SHA256 `5b9bb2e5904bf9c3c9fcb0ff8a7d712e5130c4b8ed55131870212bdd30d5b435`). The threshold stays 512,000 bytes; the original checker / allowlist and isolated Git identity are unchanged. The first local preparation failure (normalized commit response lacked `tree`) is retained; it ran no original checker. The successful exact-head receipt is kept separately to avoid a recursive evidence commit.
- The E5 final exact 58-path gate and E6 final exact 98-path gate are independent, explicitly bound readbacks. Neither substitutes for a full joint native run.
- CI on 238 is not all green: architecture base/required, contract, cargo-deny and some Windows/Mac jobs failed. The actual base ref is `06133474`, a direct successor of PR metadata's `2742bc37`; the actual prospective merge parents are recorded. The metadata lag cause is unknown; no base retarget or gate weakening occurred.
- Cold composition is `OBSERVED_NOT_FINAL`. The default-disabled Adopt cold-use primitive is an unwired, uncompiled three-file draft; 34 planned rejection controls have zero executions. Actual controller authorization, deployment policy/key custody and live revocation freshness are still required.

Nested command/owner/CPU timings are not added as independent cost. Complete physical energy, network, storage-time and monetary accounting remain unknown. All original source identities, costs, failures and limits are retained in the linked readout.

