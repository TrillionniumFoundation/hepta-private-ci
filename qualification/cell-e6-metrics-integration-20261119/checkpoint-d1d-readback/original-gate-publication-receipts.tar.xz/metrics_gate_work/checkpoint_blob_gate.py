"""Exact-object preparation and unchanged #6703 checkpoint blob gate.

This controller never fetches, checks out, changes a ref, or edits source.
The prepare subcommand does not run Git or the gate. Check needs the final
complete file manifest and an exact GitHub commit API record (or raw commit).
"""

import argparse
import base64
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import time
import traceback

BASE = "238fc48402f786db3d7f2a80b0abad6c0e5322bb"
BASE_TREE = "74478db5dad451c13483dd575cd5d94c0a3e6864"
GATE = ("18bc6175c274abaeabe3ef0c32d82627d498bbe7", "eb7a9eab936b7c7948ed13fbd6d6aca09aa38997c20685a8ee12d72e388d52c3")
ALLOW = ("7d46f41aa8fa354ce459471ba590804259548a33", "56a9a1cd05a0d81bba73a43c19e1451b213443f631dabacfa5b4e8d145e43d1c")
HERE = Path(__file__).resolve().parent
METRICS = HERE.parent / "metrics_integration"


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def oid(kind, raw):
    return hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def jload(path):
    return json.loads(Path(path).read_bytes())


def tree_bytes(entries):
    items = []
    for entry in entries:
        name = entry["path"].encode()
        assert name and b"/" not in name and b"\0" not in name
        mode = entry["mode"].lstrip("0").encode()
        assert mode in (b"40000", b"100644", b"100755", b"120000", b"160000")
        items.append((name, mode, bytes.fromhex(entry["sha"])))
    assert len({x[0] for x in items}) == len(items)
    items.sort(key=lambda x: x[0] + (b"/" if x[1] == b"40000" else b""))
    return b"".join(mode + b" " + name + b"\0" + digest for name, mode, digest in items)


def commit_bytes(api, raw_path=None):
    if raw_path:
        raw = Path(raw_path).read_bytes()
        assert oid("commit", raw) == api["sha"]
        return raw, {"source": "supplied exact raw commit"}
    verification = api.get("verification", {})
    if verification.get("signature") or verification.get("verified"):
        raise ValueError("signed commit requires exact raw bytes; preserve signature and verification payload")
    assert verification.get("reason") == "unsigned"
    attempted = []
    for offset in ("-0500", "+0000"):
        lines = ["tree " + api["tree"]["sha"]] + ["parent " + x["sha"] for x in api["parents"]]
        for name in ("author", "committer"):
            person = api[name]
            stamp = int(datetime.datetime.fromisoformat(person["date"].replace("Z", "+00:00")).timestamp())
            lines.append(f"{name} {person['name']} <{person['email']}> {stamp} {offset}")
        payload = ("\n".join(lines) + "\n\n" + api["message"]).encode()
        for ending in (b"", b"\n"):
            raw = payload + ending
            actual = oid("commit", raw)
            attempted.append({"offset": offset, "trailing_newline": bool(ending), "oid": actual})
            if actual == api["sha"]:
                return raw, {"source": "GitHub unsigned metadata, exact Git SHA match", "attempted": attempted}
    raise ValueError("commit metadata serialization did not match; exact raw author/committer offsets or raw commit required")


def file_rows(path):
    data = jload(path)
    return data if isinstance(data, list) else data["files"]


def checked_file(row):
    path = row["path"]
    pure = PurePosixPath(path)
    assert not pure.is_absolute() and ".." not in pure.parts and str(pure) == path
    raw = Path(row["local_path"]).read_bytes()
    expected = row.get("git_blob", row.get("git_blob_sha1", row.get("sha")))
    assert len(raw) == row["bytes"] and sha(raw) == row["sha256"] and oid("blob", raw) == expected, path
    return raw, expected


def prepare(output):
    output.mkdir(exist_ok=False)
    payload = output / "objects"
    payload.mkdir()
    objects = {}

    def retain(kind, raw, expected):
        assert oid(kind, raw) == expected
        if expected in objects:
            assert (payload / expected).read_bytes() == raw
            return
        (payload / expected).write_bytes(raw)
        objects[expected] = {"oid": expected, "type": kind, "bytes": len(raw), "sha256": sha(raw), "local_path": str(payload / expected)}

    records = jload(HERE / "BASE_METADATA_API.json")
    trees = {r.get("path", ""): r["api"] for r in records if r["name"].startswith("tree-")}
    assert trees[""]["sha"] == BASE_TREE
    for path, api in trees.items():
        assert not api["truncated"]
        if path:
            parent, _, name = path.rpartition("/")
            entry = next(x for x in trees[parent]["tree"] if x["path"] == name)
            assert entry["type"] == "tree" and entry["sha"] == api["sha"]
        retain("tree", tree_bytes(api["tree"]), api["sha"])
    api = next(r["api"] for r in records if r["name"] == "commit-238")
    assert api["sha"] == BASE and api["tree"]["sha"] == BASE_TREE
    raw, reconstruction = commit_bytes(api)
    retain("commit", raw, BASE)
    (output / "BASE_COMMIT_RECONSTRUCTION.json").write_bytes(canonical(reconstruction))
    pack_root = METRICS / "checkpoint-policy-pack"
    pack = jload(pack_root / "PACK.json")
    compressed = b""
    for part in pack["parts"]:
        raw = (pack_root / part["name"]).read_bytes()
        assert len(raw) == part["bytes"] and sha(raw) == part["sha256"]
        compressed += raw
    assert len(compressed) == pack["bytes"] and sha(compressed) == pack["sha256"]
    packed = json.loads(gzip.decompress(compressed))["files"]
    assert len(packed) == pack["objects"] == 27
    for row in packed:
        raw = base64.b64decode(row["data"], validate=True)
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
        retain("blob", raw, row["sha"])
    for row in jload(HERE / "BASE_FILES_API.json"):
        parent, _, name = row["path"].rpartition("/")
        entry = next(x for x in trees[parent]["tree"] if x["path"] == name)
        assert entry["type"] == "blob" and entry["sha"] == row["sha"]
        encoded = "".join(row["content"].split())
        retain("blob", base64.b64decode(encoded, validate=True), row["sha"])
    for digest, expected_sha in (GATE, ALLOW):
        assert objects[digest]["sha256"] == expected_sha
    rows = file_rows(METRICS / "next_static_file_manifest.json")
    bindings = {x["path"]: x for x in jload(METRICS / "next_static_blob_objects.json")}
    assert len(rows) == len(bindings) == 21
    for row in rows:
        raw, digest = checked_file(row)
        assert digest == bindings[row["path"]]["sha"]
    manifest = {"schema": "hepta.checkpoint-exact-git-base-preparation.v1", "base": BASE, "tree": BASE_TREE, "objects": list(objects.values()), "base_directory_trees": {p: a["sha"] for p, a in trees.items()}, "static_rows_verified": len(rows), "static_manifest_sha256": sha((METRICS / "next_static_file_manifest.json").read_bytes()), "policy_pack_sha256": sha(compressed), "original_gate": GATE, "original_allowlist": ALLOW, "gate_executed": False, "git_commands_executed": 0, "remote_jobs": 0, "missing_inputs": ["final complete changed-file manifest with local bytes", "exact final commit API record or raw signed commit", "any additional base ancestor trees/before blobs outside the currently prepared paths"]}
    (output / "MANIFEST.json").write_bytes(canonical(manifest))
    print(json.dumps({"output": str(output), "objects": len(objects), "trees": len(trees), "blobs": sum(x["type"] == "blob" for x in objects.values()), "static_rows_verified": len(rows), "gate_executed": False}))


def check(args):
    args.output.mkdir(exist_ok=False)
    repo = args.output / "objects.git"
    env = dict(os.environ, GIT_NO_LAZY_FETCH="1", GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0")
    start = time.monotonic()
    result = {"schema": "hepta.checkpoint-exact-object-original-blob-gate.v1", "base": BASE, "head": args.head, "host": "managed-cloud-workspace", "maximum_bytes": 512000, "controller_sha256": sha(Path(__file__).read_bytes()), "model_calls": 0, "training_updates": 0, "native_task_children": 0}
    try:
        base = jload(args.base_manifest)
        assert base["base"] == BASE and base["tree"] == BASE_TREE
        static_raw = (METRICS / "next_static_file_manifest.json").read_bytes()
        assert sha(static_raw) == base["static_manifest_sha256"], "static baseline manifest changed after preparation"
        static_rows = json.loads(static_raw)
        if not isinstance(static_rows, list):
            static_rows = static_rows["files"]
        result["input_manifests"] = {str(path): sha(path.read_bytes()) for path in [args.base_manifest, args.head_api, *args.files_manifest]}
        init = subprocess.run(["git", "init", "--bare", str(repo)], capture_output=True, timeout=15, env=env)
        (args.output / "init.stdout").write_bytes(init.stdout)
        (args.output / "init.stderr").write_bytes(init.stderr)
        assert init.returncode == 0

        def git(*parts, data=None):
            return subprocess.check_output(["git", *parts], cwd=repo, env=env, input=data, stderr=subprocess.PIPE, timeout=15)

        imported = {}

        def put(kind, raw, expected=None):
            expected = expected or oid(kind, raw)
            assert oid(kind, raw) == expected
            assert git("hash-object", "-t", kind, "-w", "--stdin", data=raw).decode().strip() == expected
            assert git("cat-file", kind, expected) == raw
            imported[expected] = {"oid": expected, "type": kind, "bytes": len(raw), "sha256": sha(raw), "exact_readback": True}
            return expected

        for entry in base["objects"]:
            raw = Path(entry["local_path"]).read_bytes()
            assert len(raw) == entry["bytes"] and sha(raw) == entry["sha256"]
            put(entry["type"], raw, entry["oid"])
        files = {}
        for manifest in args.files_manifest:
            for row in file_rows(manifest):
                raw, digest = checked_file(row)
                if row["path"] in files:
                    assert files[row["path"]]["sha"] == digest
                mode = row.get("mode", "100644")
                assert mode in ("100644", "100755")
                files[row["path"]] = {"sha": put("blob", raw, digest), "mode": mode, "bytes": len(raw), "sha256": sha(raw)}
        assert files
        for row in static_rows:
            assert row["path"] in files and files[row["path"]]["sha"] == row["git_blob"]
        (args.output / "EXPECTED_FILES.json").write_bytes(canonical(files))

        def revise(tree, changes, prefix=""):
            raw = git("cat-file", "tree", tree) if tree else b""
            entries, offset = {}, 0
            while offset < len(raw):
                end = raw.index(b"\0", offset)
                mode, name = raw[offset:end].split(b" ", 1)
                entries[name.decode()] = {"path": name.decode(), "mode": mode.decode(), "sha": raw[end + 1:end + 21].hex()}
                offset = end + 21
            assert offset == len(raw)
            groups = {}
            for path, update in changes.items():
                first, sep, rest = path.partition("/")
                if sep:
                    groups.setdefault(first, {})[rest] = update
                else:
                    if first in entries:
                        old = entries[first]
                        assert old["mode"] in ("100644", "100755")
                        try:
                            previous = git("cat-file", "blob", old["sha"])
                        except subprocess.CalledProcessError as exc:
                            raise ValueError(f"missing before blob: {prefix + path} {old['sha']}") from exc
                        assert oid("blob", previous) == old["sha"]
                        assert old["sha"] != update["sha"] or old["mode"] != update["mode"], "unchanged path in final changed-file manifest"
                    entries[first] = {"path": first, "mode": update["mode"], "sha": update["sha"]}
            for name, updates in groups.items():
                old = entries.get(name)
                assert old is None or old["mode"] == "40000"
                try:
                    new_tree = revise(old["sha"] if old else None, updates, prefix + name + "/")
                except subprocess.CalledProcessError as exc:
                    raise ValueError(f"missing base tree: {prefix + name} {old['sha'] if old else None}") from exc
                entries[name] = {"path": name, "mode": "40000", "sha": new_tree}
            return put("tree", tree_bytes(entries.values()))

        expected_tree = revise(BASE_TREE, files)
        api = jload(args.head_api)
        assert api["sha"] == args.head and api["tree"]["sha"] == expected_tree, "final tree differs from complete file manifest"
        assert [x["sha"] for x in api["parents"]] == [BASE], "supply an explicit extension for a multi-commit checkpoint; do not silently skip ancestry"
        raw, reconstruction = commit_bytes(api, args.head_raw)
        put("commit", raw, args.head)
        (args.output / "COMMIT_RECONSTRUCTION.json").write_bytes(canonical(reconstruction))
        (args.output / "EXACT_OBJECTS.json").write_bytes(canonical(list(imported.values())))
        changed = git("diff", "--name-only", "--diff-filter=AM", "--no-renames", "-z", BASE, args.head)
        paths = [x for x in changed.decode().split("\0") if x]
        assert sorted(paths) == sorted(files), "full actual diff is not the final complete manifest"
        (args.output / "changed-paths.stdout").write_bytes(changed)
        for name, pinned in (("check_blob_size.py", GATE), ("blob-size-allowlist.txt", ALLOW)):
            raw = git("cat-file", "blob", pinned[0])
            assert sha(raw) == pinned[1]
            (args.output / name).write_bytes(raw)

        def state():
            answer = {name: sha((repo / name).read_bytes()) if (repo / name).is_file() else None for name in ("HEAD", "config", "index", "packed-refs")}
            answer["refs"] = {str(p.relative_to(repo)): sha(p.read_bytes()) for p in (repo / "refs").rglob("*") if p.is_file()}
            return answer

        before = state()
        argv = [sys.executable, str(args.output / "check_blob_size.py"), "--base", BASE, "--head", args.head, "--max-bytes", "512000", "--allowlist", str(args.output / "blob-size-allowlist.txt")]
        (args.output / "INTENT.json").write_bytes(canonical({"argv": argv, "cwd": str(repo), "timeout_seconds": 120, "before": before}))
        began = time.monotonic()
        try:
            child = subprocess.run(argv, cwd=repo, env=env, capture_output=True, timeout=120)
            stdout, stderr, code, timed_out = child.stdout, child.stderr, child.returncode, False
        except subprocess.TimeoutExpired as exc:
            stdout, stderr, code, timed_out = exc.stdout or b"", exc.stderr or b"", None, True
        (args.output / "stdout").write_bytes(stdout)
        (args.output / "stderr").write_bytes(stderr)
        after = state()
        result.update({"status": "PASS" if code == 0 and before == after else "FAIL", "exit_code": code, "timed_out": timed_out, "gate_wall_seconds": time.monotonic() - began, "changed_paths": len(paths), "tree": expected_tree, "exact_objects": len(imported), "original_gate": GATE, "original_allowlist": ALLOW, "before": before, "after": after, "repository_identity_unchanged": before == after, "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr)})
    except Exception as exc:
        result.update({"status": "ERROR", "error": type(exc).__name__ + ": " + str(exc)})
        (args.output / "exception.txt").write_text(traceback.format_exc())
    result["owner_wall_seconds"] = time.monotonic() - start
    (args.output / "RESULT.json").write_bytes(canonical(result))
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "PASS" else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    preparation = sub.add_parser("prepare")
    preparation.add_argument("--output", type=Path, required=True)
    gate = sub.add_parser("check")
    gate.add_argument("--base-manifest", type=Path, required=True)
    gate.add_argument("--files-manifest", type=Path, action="append", required=True)
    gate.add_argument("--head-api", type=Path, required=True)
    gate.add_argument("--head-raw", type=Path)
    gate.add_argument("--head", required=True)
    gate.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output = args.output.resolve()
    if args.command == "prepare":
        prepare(args.output)
        return 0
    return check(args)


if __name__ == "__main__":
    raise SystemExit(main())
