# Original CI job logs: 97a1 and 08f

This archive retains 18 complete decoded GitHub Actions job logs (11254757 UTF-8 bytes) from the fixed source observations in SOURCE_MANIFEST.json.

BOM, CRLF, repeated diagnostic blocks, initial failures and cancellation are preserved. Logs are not line-normalized or truncated. The manifest records actual checkout identity separately from the workflow head. The pre-checkout Fence failure has no observed checkout.

The initial 97a1 candidate and its PR merge 4ac have tree 69aa60e46be91f8c10c1b0d809d72cb52b362430. The later 08f candidate and merge 504c have tree 2b700f32ebd90f88e022432e0a62584e4713a69b. These are two different trees; their outcomes are not interchangeable.

The new Dataset fixture failure, the source compilation fix, scoped Windows security success, SDK DNS failure, and current Windows owner/fixture/platform failures are retained separately. No baseline failure is asserted merely because a source path is unchanged. Counts are per original command: duplicate log blocks, retries, platform lanes and shared/native commands must not be added together.

This archive accepts zero ordinary complete chains, zero complete positive-adoption or NoUpdate/rollback chains, zero independent B custody, zero independent C FinalUse, and zero whole daemon/Root cold restart. Native/component success and compilation do not establish those deployment facts. No authority or lock policy was changed.

pack_and_verify.py reconstructs a deterministic tar.xz from the payload directory and completely extracts/verifies every regular member. The external MANIFEST.json records the resulting archive hash, every member hash, the source-manifest hash, and verification results. This packaging command does not execute project tests.
