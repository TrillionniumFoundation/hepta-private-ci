#!/usr/bin/env python3
"""Package cached CI evidence and fully extract/verify every member; runs no project tests."""

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile


def fingerprint(data):
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob_sha1": hashlib.sha1(
            b"blob " + str(len(data)).encode("ascii") + b"\0" + data
        ).hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--archive-name", required=True)
    args = parser.parse_args()
    payload = args.payload.resolve(strict=True)
    output = args.output_dir.resolve(strict=True)
    if Path(args.archive_name).name != args.archive_name:
        raise RuntimeError("archive name must be a basename")
    archive = output / args.archive_name
    manifest_path = output / "MANIFEST.json"
    unpacked = output / "verified-unpacked"
    for target in (archive, manifest_path, unpacked):
        if target.exists():
            raise RuntimeError(f"refusing to replace existing output: {target}")

    source_path = payload / "SOURCE_MANIFEST.json"
    source_bytes = source_path.read_bytes()
    source = json.loads(source_bytes)
    log_pins = {row["path"]: row for row in source["logs"]}
    if len(log_pins) != len(source["logs"]):
        raise RuntimeError("duplicate original job-log path")
    for relative, pin in log_pins.items():
        data = (payload / relative).read_bytes()
        observed = fingerprint(data)
        for key in ("bytes", "sha256", "git_blob_sha1"):
            if observed[key] != pin[key]:
                raise RuntimeError(f"original log pin mismatch: {relative}: {key}")
        if data.startswith(b"\xef\xbb\xbf") != pin["utf8_bom"]:
            raise RuntimeError(f"BOM mismatch: {relative}")
        if data.count(b"\r\n") != pin["crlf_pairs"]:
            raise RuntimeError(f"CRLF mismatch: {relative}")
        if data.count(b"\n") != pin["lf_characters"]:
            raise RuntimeError(f"LF mismatch: {relative}")

    identities = {row["commit"]: row for row in source["identities"]}
    for pair in source["equal_tree_pairs"]:
        if not (
            identities[pair["head"]]["tree"]
            == identities[pair["merge"]]["tree"]
            == pair["tree"]
        ):
            raise RuntimeError("source-tree identity pair mismatch")
    if any(
        value != 0
        for key, value in source["qualification"].items()
        if key.endswith("_accepted")
    ):
        raise RuntimeError("this evidence archive cannot elevate qualification")

    members = []
    for path in sorted(payload.rglob("*")):
        if path.is_symlink():
            raise RuntimeError(f"no symlink inputs: {path}")
        if path.is_dir():
            continue
        if not path.is_file():
            raise RuntimeError(f"not a regular file: {path}")
        relative = path.relative_to(payload).as_posix()
        data = path.read_bytes()
        members.append({"path": relative, "mode": "100644", **fingerprint(data)})
    expected = {row["path"]: row for row in members}
    if set(expected).intersection(log_pins) != set(log_pins):
        raise RuntimeError("missing original log members")

    with tarfile.open(archive, "w:xz", preset=6, format=tarfile.PAX_FORMAT) as bundle:
        for row in members:
            data = (payload / row["path"]).read_bytes()
            if fingerprint(data) != {key: row[key] for key in ("bytes", "sha256", "git_blob_sha1")}:
                raise RuntimeError(f"input changed while packaging: {row['path']}")
            info = tarfile.TarInfo(row["path"])
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            info.uid = 0
            info.gid = 0
            info.uname = ""
            info.gname = ""
            info.pax_headers = {}
            bundle.addfile(info, io.BytesIO(data))

    unpacked.mkdir()
    seen = set()
    with tarfile.open(archive, "r:xz") as bundle:
        for member in bundle:
            relative = PurePosixPath(member.name)
            if (
                not member.isfile()
                or relative.is_absolute()
                or ".." in relative.parts
                or member.name not in expected
                or member.name in seen
                or member.mode != 0o644
            ):
                raise RuntimeError(f"invalid or unexpected archive member: {member.name}")
            retained = bundle.extractfile(member)
            if retained is None:
                raise RuntimeError("regular member has no content")
            data = retained.read()
            target = unpacked.joinpath(*relative.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as out:
                if out.write(data) != len(data):
                    raise RuntimeError("short extraction write")
            pin = expected[member.name]
            if fingerprint(target.read_bytes()) != {
                key: pin[key] for key in ("bytes", "sha256", "git_blob_sha1")
            }:
                raise RuntimeError(f"extracted member hash mismatch: {member.name}")
            seen.add(member.name)
    if seen != set(expected):
        raise RuntimeError("incomplete extraction")
    for row in members:
        if fingerprint((payload / row["path"]).read_bytes()) != {
            key: row[key] for key in ("bytes", "sha256", "git_blob_sha1")
        }:
            raise RuntimeError("payload changed during verification")

    archive_info = {"path": archive.name, "mode": "100644", **fingerprint(archive.read_bytes())}
    source_info = {"path": "SOURCE_MANIFEST.json", "mode": "100644", **fingerprint(source_bytes)}
    manifest = {
        "schema": "hepta.ci.original-job-log-archive-manifest.v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "repository": source["repository"],
        "archive": archive_info,
        "source_manifest": source_info,
        "source_manifest_contents": source,
        "members": members,
        "verification": {
            "result": "PASS",
            "verified_regular_members": len(seen),
            "raw_logs_verified": len(log_pins),
            "raw_log_bytes": sum(row["bytes"] for row in log_pins.values()),
            "all_requested_members_extracted": True,
            "all_extracted_bytes_sha256_and_git_blob_ids_match": True,
            "original_log_BOM_CRLF_and_LF_counts_match": True,
            "payload_before_after_hashes_equal": True,
            "source_tree_pairs_equal": True,
            "project_tests_or_CI_rerun": False,
            "source_or_authority_modified": False,
            "refs_or_PRs_modified": False,
            "scope": "Local archive integrity only; not source qualification.",
        },
        "packaging": {
            "argv": [sys.executable, *sys.argv],
            "cwd": str(Path.cwd()),
            "python": sys.version,
            "tar_format": "PAX regular files; sorted paths; uid/gid/mtime 0; mode 0644",
            "xz_preset": 6,
            "reproduction": "Run this archived script with the extracted payload and a fresh output directory. SOURCE_MANIFEST.json provides original log pins.",
        },
    }
    with manifest_path.open("x", encoding="utf-8", newline="\n") as out:
        json.dump(manifest, out, indent=2, sort_keys=True, ensure_ascii=True)
        out.write("\n")
    print(json.dumps({
        "archive": archive_info,
        "manifest": {"path": manifest_path.name, **fingerprint(manifest_path.read_bytes())},
        "source_manifest": source_info,
        "verified_members": len(seen),
        "raw_logs": len(log_pins),
        "raw_log_bytes": sum(row["bytes"] for row in log_pins.values()),
        "ordinary_complete_chains_accepted": 0,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
