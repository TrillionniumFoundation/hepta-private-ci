import subprocess,json,hashlib,time,os,traceback
from pathlib import Path
root=Path("/home/qq/af52-learning-20261111")
source_repo=root/"source"
repo=root/"native-97a1"
expected_commit="54de04371be6d625e1ecda49931c7d3585d0a2d0"
expected_tree="0003e1f9f859fda1ebbe1c756cce34d5ddc3a170"
expected_parents=["5dcec722472eab39064416d50bf4c4bb7b96b361"]
prefix="ordinary-unified-native-v3"
summary_path=root/(prefix+"-summary.json")
gates={}
initial=None
before=None
helper_command=None
helper_dir=root/(prefix+"-helpers")
def git(directory,*args):
 return subprocess.check_output(["git",*args],cwd=directory,text=True).strip()
def state(directory):
 return {"commit":git(directory,"rev-parse","HEAD"),"tree":git(directory,"rev-parse","HEAD^{tree}"),"worktree":git(directory,"status","--porcelain")}
def write_json(path,data):
 path.write_text(json.dumps(data,indent=2)+"\n")
def fail(phase,code,**details):
 report={"schema":"hepta.ordinary.unified.native.v1","phase":phase,"exit":code,"requested_commit":expected_commit,"requested_tree":expected_tree,"initial_local":initial,"before":before,"gates":gates,"ordinary_complete_chains":0,**details}
 write_json(summary_path,report)
 print(json.dumps(report),flush=True)
 raise SystemExit(code)
def execute(name,command,cwd):
 log=root/(prefix+"-"+name+".log")
 step_before=state(repo)
 print(json.dumps({"phase":name,"source":step_before,"command":command,"log":str(log)}),flush=True)
 started=time.time()
 with log.open("w") as output:
  proc=subprocess.run(command,cwd=cwd,stdout=output,stderr=subprocess.STDOUT)
 raw=log.read_bytes()
 lines=raw.decode(errors="replace").splitlines()
 relevant=[line for line in lines if any(x in line for x in ("Summary"," tests run:","test result:"," FAIL "," FAIL[","TIMEOUT","error:","Caused by:"))]
 step_after=state(repo)
 gate={"command":command,"exit":proc.returncode,"elapsed_seconds":time.time()-started,"before":step_before,"after":step_after,"source_unchanged":step_before==step_after,"log":str(log),"log_bytes":len(raw),"log_sha256":hashlib.sha256(raw).hexdigest(),"result_lines":relevant[-100:]}
 gates[name]=gate
 write_json(root/(prefix+"-"+name+"-result.json"),gate)
 (root/(prefix+"-"+name+"-tail.log")).write_text(("\n".join(lines[-240:])+"\n")[-60000:])
 print(json.dumps({"phase":name+"-complete",**gate}),flush=True)
 return gate
initial=state(source_repo)
assert initial=={"commit":"bc8ac0dc25c621959b7be52280bcfed70b52bb07","tree":"f0f85fcccf7c51e4d6ae46a252bf785bcaa66f61","worktree":""},initial
previous=json.loads((root/"dataset-native-v2-summary.json").read_text())
assert previous["exit"]==100 and previous["source_unchanged"] and previous["helper_verify_after_exit"]==0
unified_previous=json.loads((root/"ordinary-unified-native-v2-summary.json").read_text())
assert unified_previous["phase"]=="fix-agentd" and unified_previous["exit"]==101
assert unified_previous["before"]==unified_previous["after"]
assert set(unified_previous["gates"])=={"fmt-before","fix-agentd"}
old=state(repo)
assert old=={"commit":"5dcec722472eab39064416d50bf4c4bb7b96b361","tree":"f04d39f6b05051f050ef45e9a8d9f9b31a510a0a","worktree":""},old
fetch_log=root/(prefix+"-fetch.log")
with fetch_log.open("w") as output:
 fetch=subprocess.run(["git","fetch","--no-tags","https://github.com/TrillionniumFoundation/hepta-private-ci.git",expected_commit],cwd=repo,stdout=output,stderr=subprocess.STDOUT,timeout=300)
if fetch.returncode:
 fail("fetch",fetch.returncode,fetch_log=str(fetch_log))
assert git(repo,"rev-parse",expected_commit+"^{tree}")==expected_tree
actual_parents=git(repo,"show","-s","--format=%P",expected_commit).split()
assert actual_parents==expected_parents,actual_parents
subprocess.run(["git","checkout","--detach",expected_commit],cwd=repo,check=True,stdout=subprocess.DEVNULL)
before=state(repo)
assert before=={"commit":expected_commit,"tree":expected_tree,"worktree":""},before
assert state(source_repo)==initial
write_json(root/(prefix+"-before.json"),{"native":before,"original":initial,"native_worktree":str(repo),"previous_attempt":old,"parents":actual_parents})
os.environ["SOURCE_SHA"]=expected_commit
os.environ["TESTED_SHA"]=expected_commit
for name in list(os.environ):
 if name.startswith("CARGO_BIN_EXE_"):
  del os.environ[name]
just="/home/qq/hepta-learning-native-4f559bf-d9fb-20261108/transfer/just"
maintenance=[
 ("fmt-before",[just,"fmt","--base","08f963973e02e0f74e499c962635518965f4f68a"]),
 ("fix-agentd",[just,"fix","-p","codex-hepta-agentd","--locked","--offline"]),
 ("fix-artifacts",[just,"fix","-p","codex-hepta-learning-artifacts","--locked","--offline"]),
 ("fmt-after",[just,"fmt","--base","08f963973e02e0f74e499c962635518965f4f68a"])
]
for name,command in maintenance:
 gate=execute(name,command,repo/"codex-rs")
 if gate["exit"]:
  fail(name,gate["exit"],after=state(repo))
 if not gate["source_unchanged"]:
  diff=subprocess.check_output(["git","diff","--binary","HEAD"],cwd=repo)
  diff_path=root/(prefix+"-"+name+"-source-drift.patch")
  diff_path.write_bytes(diff)
  fail("maintenance-source-drift",2,after=state(repo),diff=str(diff_path),diff_sha256=hashlib.sha256(diff).hexdigest(),diff_bytes=len(diff))
helper_command=["/usr/bin/python3","scripts/hepta_cell_test_helpers.py","--package","codex-hepta-infer-worker-host","--output-dir",str(helper_dir)]
for name,args in [("helper-build",helper_command),("helper-verify-before",helper_command+["--verify-only"])]:
 gate=execute(name,args,repo)
 if gate["exit"] or not gate["source_unchanged"]:
  fail(name,gate["exit"] or 2,after=state(repo),helper_manifest=str(helper_dir/"manifest.json"))
helper_environment=json.loads((helper_dir/"env.json").read_text())
assert helper_environment and all(name.startswith("CARGO_BIN_EXE_") for name in helper_environment)
os.environ.update(helper_environment)
agentd_command=[just,"test","-p","codex-hepta-agentd","--lib","--locked","--offline"]
artifacts_command=[just,"test","-p","codex-hepta-learning-artifacts","--lib","--locked","--offline"]
tests=[
 ("focused-dataset",agentd_command+["-E","test(q24_dataset_)"]),
 ("full-agentd",agentd_command),
 ("full-artifacts",artifacts_command)
]
for name,args in tests:
 gate=execute(name,args,repo/"codex-rs")
 if gate["exit"] or not gate["source_unchanged"]:
  break
verified_after=execute("helper-verify-after",helper_command+["--verify-only"],repo)
after=state(repo)
original_after=state(source_repo)
helper_manifest=json.loads((helper_dir/"manifest.json").read_text())
exit_code=next((entry["exit"] or (0 if entry["source_unchanged"] else 2) for entry in gates.values() if entry["exit"] or not entry["source_unchanged"]),0) or (0 if before==after and initial==original_after else 2)
complete_all=all(name in gates and gates[name]["exit"]==0 and gates[name]["source_unchanged"] for name,_ in tests)
summary={"schema":"hepta.ordinary.unified.native.v1","phase":"complete","initial_local":initial,"original_after":original_after,"before":before,"after":after,"exact_published_commit":expected_commit,"parents":actual_parents,"source_sha":os.environ["SOURCE_SHA"],"tested_sha":os.environ["TESTED_SHA"],"exit":exit_code,"gates":gates,"all_requested_gates_completed":complete_all,"source_unchanged":before==after,"original_unchanged":initial==original_after,"toolchain":subprocess.check_output(["/home/qq/.cargo/bin/rustc","-Vv"],text=True),"target":os.environ["CARGO_TARGET_DIR"],"bindgen_args":os.environ["BINDGEN_EXTRA_CLANG_ARGS"],"helper_manifest":str(helper_dir/"manifest.json"),"helper_manifest_sha256":hashlib.sha256((helper_dir/"manifest.json").read_bytes()).hexdigest(),"helper_artifacts":helper_manifest["artifacts"],"helper_environment":helper_environment,"ordinary_complete_chains":0,"positive_adoption_chains":0,"ordinary_no_update_rollback_chains":0,"root_uid0_gate":"not run","scope":"Native library component regressions for the exact unified source; not ordinary full-loop qualification"}
write_json(summary_path,summary)
print(json.dumps(summary),flush=True)
raise SystemExit(exit_code)
