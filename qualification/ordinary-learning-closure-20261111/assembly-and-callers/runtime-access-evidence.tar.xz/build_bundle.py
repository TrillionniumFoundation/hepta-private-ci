import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
pins = json.loads((root / "PINS.json").read_text())
verified = []
for pin in pins["assets"]:
    path = root / pin["path"]
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    git_blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    if git_blob != pin["blob"]:
        raise SystemExit("Git blob mismatch: " + pin["path"])
    if "bytes" in pin and len(raw) != pin["bytes"]:
        raise SystemExit("Byte size mismatch: " + pin["path"])
    if "sha256" in pin and digest != pin["sha256"]:
        raise SystemExit("SHA256 mismatch: " + pin["path"])
    verified.append(dict(pin, bytes=len(raw), sha256=digest, git_blob_verified=True))

assembly = json.loads((root / "assembly/MANIFEST.json").read_text())
postimages = [
    {
        "path": row["path"],
        "mode": row["mode"],
        "git_blob_sha": row["git_blob_sha"],
        "sha256": row["sha256"],
        "bytes": row["size"],
        "provenance": row["kind"],
    }
    for row in assembly["files"]
]
postimages.extend([
    {
        "path": "codex-rs/hepta-agentd/src/cell_q24_dataset_materializer_tests.rs",
        "mode": "100644",
        "git_blob_sha": "fe592edc993c4119404617786fa6aa1545f7edac",
        "sha256": "09503af68af5bd9acbafa8bf44eb07761656d0a2bc9b9110bde353b1a9a7bf05",
        "bytes": 30341,
        "provenance": "Independently identical native formatter postimage; observed 5dcec admission verified these bytes.",
    },
    {
        "path": "codex-rs/hepta-agentd/src/neuron_generation_learning_readback.rs",
        "mode": "100644",
        "git_blob_sha": "3a8d21d2c5d10154f746ae781dacffaa6de23a36",
        "sha256": "b9b4b255ee1d159921aa6224ae0e47771c739d608ae5835057340cbfc5eec856",
        "bytes": 9908,
        "provenance": "Independent static single-arm rejection postimage, matched independently by root and audit; not a runtime gate result.",
    },
])
(root / "postimages").mkdir(exist_ok=True)
(root / "postimages/final25.json").write_text(json.dumps({
    "schema": "hepta.expected-postimage-identities.v1",
    "commit": "54de04371be6d625e1ecda49931c7d3585d0a2d0",
    "tree": "0003e1f9f859fda1ebbe1c756cce34d5ddc3a170",
    "local_full_gate_acceptance": False,
    "files": sorted(postimages, key=lambda row: row["path"]),
}, indent=2) + "\n")

members = []
for path in sorted(root.rglob("*")):
    if path.is_file() and path.name != "BUNDLE_MANIFEST.json":
        raw = path.read_bytes()
        members.append({
            "path": path.relative_to(root).as_posix(),
            "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(),
        })
manifest = {
    "schema": "hepta.runtime-access-evidence-bundle.v1",
    "preserved_original_assets": verified,
    "full_local_caller_acceptance_claimed": False,
    "members_excluding_this_manifest": members,
}
(root / "BUNDLE_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
tar_buffer = io.BytesIO()
with tarfile.open(fileobj=tar_buffer, mode="w", format=tarfile.PAX_FORMAT) as archive:
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        raw = path.read_bytes()
        info = tarfile.TarInfo(path.relative_to(root).as_posix())
        info.size = len(raw)
        info.mode = 0o644
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = ""
        archive.addfile(info, io.BytesIO(raw))
tar_bytes = tar_buffer.getvalue()
xz = lzma.compress(tar_bytes, format=lzma.FORMAT_XZ, preset=6)
if lzma.decompress(xz) != tar_bytes:
    raise SystemExit("XZ round-trip mismatch")
with tarfile.open(fileobj=io.BytesIO(lzma.decompress(xz)), mode="r:") as archive:
    for member in archive.getmembers():
        actual = archive.extractfile(member).read()
        if actual != (root / member.name).read_bytes():
            raise SystemExit("Archive member mismatch: " + member.name)
archive_path = root.parent / (root.name + ".tar.xz")
archive_path.write_bytes(xz)
index = {
    "schema": "hepta.runtime-access-evidence-archive.v1",
    "bundle_directory": str(root),
    "archive_path": str(archive_path),
    "archive_bytes": len(xz),
    "archive_sha256": hashlib.sha256(xz).hexdigest(),
    "archive_git_blob_sha": hashlib.sha1(b"blob " + str(len(xz)).encode() + b"\0" + xz).hexdigest(),
    "tar_bytes": len(tar_bytes),
    "tar_sha256": hashlib.sha256(tar_bytes).hexdigest(),
    "member_count": len(members) + 1,
    "original_assets_verified": len(verified),
    "archive_all_members_roundtrip_verified": True,
}
index_path = root.parent / (root.name + ".ARCHIVE.json")
index_path.write_text(json.dumps(index, indent=2) + "\n")
print(json.dumps(index, indent=2))
