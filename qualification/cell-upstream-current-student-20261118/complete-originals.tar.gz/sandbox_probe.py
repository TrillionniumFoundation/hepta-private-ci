import errno,json,os,pathlib,socket,sys
host_net,host_pid,host_canary=sys.argv[1:]
report={"uid":os.getuid(),"env_keys":sorted(os.environ),"net_namespace":os.readlink("/proc/self/ns/net"),"pid_namespace":os.readlink("/proc/self/ns/pid"),"network_interfaces":socket.if_nameindex(),"host_canary_visible":pathlib.Path(host_canary).exists(),"tests_readonly":bool(os.statvfs("/tests").f_flag & os.ST_RDONLY),"dependencies_readonly":bool(os.statvfs("/venv").f_flag & os.ST_RDONLY)}
assert report["net_namespace"]!=host_net and report["pid_namespace"]!=host_pid
assert report["network_interfaces"]==[(1,"lo")] and not report["host_canary_visible"]
assert "HEPTA_SANDBOX_HOST_CANARY" not in os.environ and report["tests_readonly"] and report["dependencies_readonly"]
try:
 pathlib.Path("/tests/sentinel.txt").write_text("should not write")
except OSError as e:
 report["write_test_errno"]=e.errno
else:
 raise AssertionError("test mount was writable")
assert report["write_test_errno"]==errno.EROFS
s=socket.socket();s.settimeout(0.5)
try:s.connect(("192.0.2.1",9))
except OSError as e:report["network_connect_errno"]=e.errno
else:raise AssertionError("unexpected external connectivity")
assert report["network_connect_errno"] in [errno.ENETUNREACH,errno.EHOSTUNREACH,errno.EPERM]
print(json.dumps(report,sort_keys=True))
