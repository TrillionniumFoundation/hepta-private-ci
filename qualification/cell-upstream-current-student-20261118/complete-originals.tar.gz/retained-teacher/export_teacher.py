"""Retain every original in the owned teacher directory, without new inference."""
import gzip, hashlib, io, json, pathlib, tarfile, time
ROOT = pathlib.Path("/home/qq/work/hepta-upstream-teacher-20261118-2e9b")
def sha(data): return hashlib.sha256(data).hexdigest()
def write(path, value):
    data=value if isinstance(value,bytes) else json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2).encode()+b"\n"
    with path.open("xb") as f:f.write(data)
    return sha(data)
def main():
    tick=time.perf_counter(); out=ROOT/"export-complete-1";out.mkdir(exist_ok=False)
    assert sha((ROOT/"TEACHER_FREEZE.json").read_bytes())=="c9e7b72fb1bd196b32bb7022d6743054e234e1b7de1f08233e93939e3ff33094"
    for stage in ("first","second"):
        done=json.loads((ROOT/(stage.upper()+"_COMPLETE.json")).read_bytes())
        assert done["actual_model_requests"]==done["completed_outputs"]==4
        assert len(list((ROOT/stage).glob("GENERATION_STARTED-*.json")))==4
        assert len(list((ROOT/stage).glob("OUTPUT-*.json")))==4
    items=[]
    for path in sorted(ROOT.rglob("*")):
        relative=path.relative_to(ROOT)
        if not path.is_file() or "__pycache__" in relative.parts or relative.parts[0].startswith("export-"): continue
        assert not path.is_symlink() and path.stat().st_nlink==1
        data=path.read_bytes();items.append((relative.as_posix(),path,data))
    index={"schema":"hepta.retained-original-file-index.v1","role":"existing_teacher","root":str(ROOT),"source_commit":"dfc4e24ba68fa983f4dbdaca1de6c2d54a4df950","actual_model_calls":8,"new_model_calls_by_collector":0,"files":[{"path":name,"bytes":len(data),"sha256":sha(data)} for name,path,data in items]}
    index_raw=json.dumps(index,ensure_ascii=False,sort_keys=True,indent=2).encode()+b"\n"
    write(out/"INDEX.json",index_raw)
    archive=out/"TEACHER_ORIGINALS.tar.gz"
    with archive.open("xb") as raw, gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0) as zipped, tarfile.open(fileobj=zipped,mode="w") as tar:
        for name,path,data in items+[("INDEX.json",out/"INDEX.json",index_raw)]:
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(data))
    result={"archive":str(archive),"sha256":sha(archive.read_bytes()),"bytes":archive.stat().st_size,"original_files":len(items),"index_sha256":sha(index_raw),"collector_source_sha256":sha(pathlib.Path(__file__).read_bytes()),"wall_seconds":time.perf_counter()-tick,"new_model_calls":0,"credentials_retained":False}
    write(out/"ARCHIVE.json",result);print(json.dumps(result),flush=True)
if __name__=="__main__": main()
