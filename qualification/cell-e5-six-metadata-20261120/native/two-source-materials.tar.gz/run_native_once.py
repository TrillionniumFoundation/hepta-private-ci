"""One owner for the original four native children and read-only identity correction."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value,sort_keys=True,indent=2)+'\n'); stream.flush(); os.fsync(stream.fileno())

def main(source_commit):
    root = Path(__file__).resolve().parent
    owner = root/'owner-1'; owner.mkdir(exist_ok=False)
    write(owner/'OWNER_LOCK.json',{'pid':os.getpid(),'started_at_ns':time.time_ns(),'source_commit':source_commit,'max_native_children':4})
    material = json.loads((root/'MATERIALS_MANIFEST.json').read_bytes())
    assert all(sha(root/r['path'])==r['sha256'] for r in material)
    plan=json.loads((root/'ACQUISITION_PLAN.json').read_bytes())
    assert len(plan['projects'])==2 and plan['native']=={'max_seconds_per_test_child':120,'pytest_per_case_timeout_seconds':3,'parallel_test_children':1,'automatic_retry':False,'full_parameter_sets':True,'maximum_owned_native_children':4}
    assert json.loads((root/'ACQUISITION.json').read_bytes())['status']=='ACQUIRED'
    commands=[['/usr/bin/python3','-u',str(root/'replay_sources.py'),'owner','--root',str(root),'--output',str(root/'replay-1'),'--source-commit',source_commit],['/usr/bin/python3','-u',str(root/'verify_replay_identity.py'),'--root',str(root),'--replay',str(root/'replay-1'),'--output',str(root/'identity-readback-1'),'--source-commit',source_commit]]
    stages=[]; began=time.perf_counter()
    for i,argv in enumerate(commands):
        start=time.perf_counter()
        with (owner/f'{i}.stdout').open('xb') as out,(owner/f'{i}.stderr').open('xb') as err:
            process=subprocess.Popen(argv,stdout=out,stderr=err,start_new_session=True)
            write(owner/f'{i}.STARTED.json',{'pid':process.pid,'argv':argv,'started_at_ns':time.time_ns()})
            code=process.wait()
        row={'stage':i,'argv':argv,'exit_code':code,'wall_seconds':time.perf_counter()-start,'stdout_sha256':sha(owner/f'{i}.stdout'),'stderr_sha256':sha(owner/f'{i}.stderr')}
        write(owner/f'{i}.EXIT.json',row); stages.append(row); print(json.dumps(row),flush=True)
        if i==0:
            result=json.loads((root/'replay-1/RESULT.json').read_bytes()); assert result['actual_owned_children']==4 and code in (0,2)
    assert all(sha(root/r['path'])==r['sha256'] for r in material)
    result={'status':'OWNER_COMPLETE','source_commit':source_commit,'stages':stages,'owner_wall_seconds':time.perf_counter()-began,'original_four_children_retained':True,'native_children':4,'new_model_calls':0,'new_training_updates':0,'full_system_cost_known':False}
    write(owner/'RESULT.json',result)
    assert stages[-1]['exit_code']==0
    readback=json.loads((root/'identity-readback-1/READOUT.json').read_bytes())
    print(json.dumps({'readback_admitted_sources':readback['new_admitted_sources'],'original_children':readback['original_native_children_reused'],'new_readback_native_children':readback['new_native_children'],'model_calls':0,'training_updates':0}),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source-commit',required=True);a=p.parse_args();main(a.source_commit)
