"""Freeze a fresh dependency environment before any of the four native children."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
PREVIOUS = Path('/home/qian/work/hepta-e5-additional-sources-20261120-e9e051-v3')
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2) + '\n')
        stream.flush(); os.fsync(stream.fileno())
def checked_fetch(url, cap, destination):
    with urllib.request.urlopen(url, timeout=30) as response:
        body = response.read(cap + 1)
    assert len(body) <= cap
    with destination.open('xb') as stream: stream.write(body)
    return body

def main():
    assert ROOT == Path('/home/qian/work/hepta-e5-two-native-20261120-e9e051')
    write(ROOT/'SETUP_OWNER_LOCK.json', {'pid': os.getpid(), 'started_at_ns': time.time_ns(), 'new_native_children': 0})
    material = json.loads((ROOT/'MATERIALS_MANIFEST.json').read_bytes())
    for entry in material:
        assert digest(ROOT/entry['path']) == entry['sha256']
    env = ROOT/'environment'; env.mkdir()
    wheels = ROOT/'wheels'; wheels.mkdir()
    assert digest(PREVIOUS/'environment/WHEELS.json') == 'f2d87178a1da20cf9e04abc0a6728b040cc60c9f071a648c837fa068d534fece'
    previous = json.loads((PREVIOUS/'environment/WHEELS.json').read_bytes())
    wanted = {'attrs','iniconfig','packaging','pluggy','pygments','pytest','pytest_timeout'}
    reused = []
    requirements = []
    for row in previous:
        distribution, version = row['name'].split('-')[:2]
        if distribution.lower() not in wanted: continue
        source = PREVIOUS/'wheels'/row['name']
        assert source.stat().st_size == row['bytes'] and digest(source) == row['sha256']
        shutil.copyfile(source, wheels/source.name)
        reused.append(row); requirements.append(distribution+'=='+version)
    assert {r['name'].split('-')[0].lower() for r in reused} == wanted
    added = []
    for distribution in ['hypothesis','sortedcontainers']:
        metadata_url = 'https://pypi.org/pypi/'+distribution+'/json'
        metadata_file = env/(distribution+'.pypi.json')
        metadata = json.loads(checked_fetch(metadata_url, 32*1024*1024, metadata_file))
        version = metadata['info']['version']
        compatible = [r for r in metadata['urls'] if r['packagetype']=='bdist_wheel' and (r['filename'].endswith('-py3-none-any.whl') or r['filename'].endswith('-py2.py3-none-any.whl')) and not r.get('yanked')]
        assert len(compatible) == 1
        chosen = compatible[0]
        b = checked_fetch(chosen['url'], 8*1024*1024, wheels/chosen['filename'])
        assert len(b) == chosen['size'] and hashlib.sha256(b).hexdigest() == chosen['digests']['sha256']
        requirements.append(distribution+'=='+version)
        added.append({'distribution':distribution, 'version':version, 'requires_python':metadata['info'].get('requires_python'), 'requires_dist':metadata['info'].get('requires_dist'), 'metadata_url':metadata_url, 'metadata_sha256':digest(metadata_file), 'wheel_url':chosen['url'], 'wheel':chosen['filename'], 'bytes':len(b), 'sha256':digest(wheels/chosen['filename'])})
    write(env/'DEPENDENCY_FREEZE_BEFORE_INSTALL.json', {'reused_wheels_manifest_sha256':digest(PREVIOUS/'environment/WHEELS.json'), 'reused_wheels':reused, 'added_dependencies':added, 'direct_exact_requirements':requirements, 'purpose':'Original natsort conftest imports hypothesis; selected regression has no generated Hypothesis examples. Same environment is used for both variants and both projects.', 'new_native_children':0})
    python = str(ROOT/'venv/bin/python')
    commands = [[sys.executable,'-m','venv',str(ROOT/'venv')],[python,'-m','pip','--isolated','--disable-pip-version-check','install','--no-index','--no-deps','--find-links',str(wheels),*requirements],[python,'-m','pip','check'],[python,'-I','-c','import sys,pytest,pytest_timeout,hypothesis,sortedcontainers; assert sys.version_info[:2] == (3,12); print(sys.version); print(pytest.__version__); print(hypothesis.__version__)']]
    for i,argv in enumerate(commands):
        began = time.perf_counter()
        with (env/f'{i}.stdout').open('xb') as out, (env/f'{i}.stderr').open('xb') as err:
            process = subprocess.run(argv,stdout=out,stderr=err,timeout=180)
        write(env/f'{i}.EXIT.json',{'argv':argv,'exit_code':process.returncode,'wall_seconds':time.perf_counter()-began})
        assert process.returncode == 0, {'stage':i,'exit_code':process.returncode}
    freeze = subprocess.run([python,'-m','pip','freeze','--all'],capture_output=True,check=True,timeout=30).stdout
    (env/'pip-freeze.txt').write_bytes(freeze)
    write(env/'WHEELS.json',[{'name':p.name,'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(wheels.iterdir())])
    for entry in material: assert digest(ROOT/entry['path']) == entry['sha256']
    write(ROOT/'ACQUISITION.json',{'status':'ACQUIRED','material_manifest_sha256':digest(ROOT/'MATERIALS_MANIFEST.json'),'snapshots_sha256':digest(ROOT/'SOURCE_RECEIPTS.json'),'plan_sha256':digest(ROOT/'ACQUISITION_PLAN.json'),'dependency_freeze_sha256':digest(env/'DEPENDENCY_FREEZE_BEFORE_INSTALL.json'),'wheel_manifest_sha256':digest(env/'WHEELS.json'),'pip_freeze_sha256':digest(env/'pip-freeze.txt'),'native_children':0,'model_calls':0,'training_updates':0,'source_growth_qualified':False})
    print(json.dumps({'status':'READY_FOR_PRE_NATIVE_FREEZE','root':str(ROOT),'exact_requirements':requirements,'native_children':0}),flush=True)

if __name__ == '__main__': main()
