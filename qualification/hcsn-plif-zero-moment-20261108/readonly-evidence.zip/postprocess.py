"""Post-process retained state and frozen replay; no forward/backward/optimizer call."""
import hashlib, inspect, json, math
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import torch
root=Path("/home/qian-qi/hepta-hcsn-trainer-20261108-s3-v1")
out=Path("/home/qian-qi/work/plif-readonly-audit-20261108-s1s2/a1")
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v): p.write_text(json.dumps(v,indent=2,allow_nan=False)+"\n")
report=json.loads((out/"RESULT.json").read_text())
assert sha(out/"RESULT.json")=="dc45b9f3616f4f80c10f742999684c63df90f849470c4e8ba1be67d593df0256"
fit=root/"validation-v3/snn_plif"
checkpoint=torch.load(fit/"epoch-1.pt",map_location="cpu",weights_only=True)
initial=torch.load(fit/"initial.pt",map_location="cpu",weights_only=True)
group=checkpoint["optimizer"]["param_groups"][0]
assert len(checkpoint["optimizer"]["param_groups"])==1
b1,b2=group["betas"]; lr=group["lr"]; decay=group["weight_decay"]; a=1-lr*decay
assert 0<b1<1 and 0<b2<1 and 0<a<1
width=initial["head.weight"].shape[1]
initial_logit_bound=float((initial["head.weight"].abs().sum(1)+initial["head.bias"].abs()).max())
K=[]
deltas=[0.]
logit_bounds=[initial_logit_bound]
for t in range(1,13):
    alpha=[(1-b1)*b1**k/(1-b1**t) for k in range(t)]
    beta=[(1-b2)*b2**k/(1-b2**t) for k in range(t)]
    k=math.sqrt(sum(x*x/y for x,y in zip(alpha,beta)))
    K.append(k)
    deltas.append(a*deltas[-1]+lr*k)
    logit_bounds.append(a**t*initial_logit_bound+(width+1)*deltas[-1])
manifest=json.loads((root/"validation-v3/data/data-manifest.json").read_text())
frontend=json.loads((root/"validation-v3/data/frontend.json").read_text())
lookup={row["id"]:row for row in manifest["episodes"]}
seen=set()
for name in report["main_episode_ids"]:
    row=lookup[name]
    p=root/"validation-v3/data"/row["path"]
    assert sha(p)==row["sha256"]
    item=json.loads(p.read_text())
    seen.update(item["y"])
    assert len(item["y"])==128
absent=sorted(set(range(11))-seen)
assert absent
max_logit=max(logit_bounds)
prob_lower=math.exp(-2*max_logit)/11
weight_lower=min(frontend["class_weights"])/(128*max(frontend["class_weights"]))
norms=[row["preclip_gradient_norm"] for row in report["historical_step_diagnostics"]]
clip_lower=min(1.,1./(max(norms)+1e-6))
gradient_lower=prob_lower*weight_lower*clip_lower
moment_lower=(1-b2)*gradient_lower**2*b2**11
zero=set(report["column_audit"]["head_zero_columns"])
frozen={}
for state,record in report["frozen_replays"].items():
    frozen[state]={"tau":record["tau"],"groups":{}}
    for group_name,row in record["aggregate"].items():
        voltage=row["max_charged_voltage_in_zero_moment_columns"]
        fired=set(row["zero_moment_columns_that_spike"])
        still_silent=sorted(zero-fired)
        silent_volts=[voltage[str(n)] for n in still_silent]
        frozen[state]["groups"][group_name]={"episodes":row["episodes"],"events":row["events"],"spikes_total":row["spikes_total"],
            "zero_moment_columns_that_spike":sorted(fired),"zero_moment_columns_that_remain_silent":still_silent,
            "still_silent_max_charged_voltage_range":[min(silent_volts),max(silent_volts)] if silent_volts else None}
ever=set()
for state in report["frozen_replays"].values():
    ever.update(state["aggregate"]["all_45_ABC_windows"]["zero_moment_columns_that_spike"])
proof={"schema":"hepta.plif.zero-column-mechanism.v1","interpretation":"Derived historical spike-silence implication from absent-class cross-entropy head gradient; not an observed per-step neuron trace.",
       "absent_main_class_ids":absent,"head_zero_column_count":len(zero),"optimizer":{"betas":group["betas"],"lr":lr,"weight_decay":decay,"eps":group["eps"],"amsgrad":group["amsgrad"]},
       "scalar_adamw_direction_bound_per_update":K,"bound_formula":"K_t^2=sum_i(alpha_ti^2/beta_ti); Cauchy gives |bias-corrected m|/sqrt(v)<=K_t; epsilon only reduces the update.",
       "initial_absolute_logit_bound":initial_logit_bound,"max_logit_bound_through_12_updates":max_logit,
       "absent_class_softmax_probability_lower_bound":prob_lower,"weighted_mean_coefficient_lower_bound":weight_lower,"gradient_clip_factor_lower_bound":clip_lower,
       "head_gradient_lower_bound_if_any_spike":gradient_lower,"final_second_moment_lower_bound_if_any_spike":moment_lower,
       "float64_smallest_normal":torch.finfo(torch.float64).tiny,"underflow_cannot_explain_zero_under_bound":moment_lower>torch.finfo(torch.float64).tiny,
       "reason":"For any absent class c, dL/dW[c,j]=sum_t positive_class_weight[t]*softmax[c,t]*spike[j,t]/positive_weight_sum. Terms cannot cancel. A spike yields a positive head gradient; all 12 head second moments are zero in the retained columns.",
       "frozen_replays":frozen,"zero_moment_columns_proven_reachable_by_either_endpoint_frozen_replay":sorted(ever),
       "endpoint_reachable_zero_moment_column_count":len(ever),"still_unobserved_at_endpoints":sorted(zero-ever),
       "historical_neuron_trace_available":False,"new_training_runs":0,"backward_calls":0,"optimizer_steps":0}
save(out/"MECHANISM.json",proof)
job=Path("/home/qian-qi/.local/state/hepta-runtime-mac-worker/jobs/1a1bc49b8d9-138b0-16e")
request=json.loads((job/"request.json").read_text())
args=request["args"]
code=args[args.index("-c")+1]
assert hashlib.sha256(code.encode()).hexdigest()=="69ad51addbff60a858b620f594fae3d5a9a4819e415287ce6f38fd51eca51011"
(out/"readonly_diagnose.py").write_text(code)
clip_source=inspect.getsource(torch.nn.utils.clip_grad_norm_)
(out/"CLIP_GRAD_SOURCE.txt").write_text(clip_source)
members=["RESULT.json","MECHANISM.json","UPSTREAM_MECHANISM.txt","CLIP_GRAD_SOURCE.txt","readonly_diagnose.py"]
manifest_out={"schema":"hepta.plif.readonly-diagnostic-archive.v1","original_native_job":"1a1bc49b8d9-138b0-16e",
              "new_training_runs":0,"optimizer_steps":0,"members":[{"path":name,"bytes":(out/name).stat().st_size,"sha256":sha(out/name)} for name in members]}
save(out/"MANIFEST.json",manifest_out)
archive=out/"readonly-diagnostic.zip"
with ZipFile(archive,"x",compression=ZIP_DEFLATED,compresslevel=9) as z:
    for name in members+["MANIFEST.json"]:z.write(out/name,name)
print(json.dumps({"output":str(out),"archive":str(archive),"archive_bytes":archive.stat().st_size,"archive_sha256":sha(archive),
                  "result_bytes":(out/"RESULT.json").stat().st_size,
                  "mechanism":{k:v for k,v in proof.items() if k!="frozen_replays"},"frozen_replays":frozen}),flush=True)
