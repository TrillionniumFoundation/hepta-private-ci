"""Count retained PLIF data/exposure and logged spikes without importing Torch."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--root", type=Path, required=True, help="retained validation-v3 directory")
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
manifest_path = root / "data/data-manifest.json"
events_path = root / "snn_plif/events.jsonl"
assert digest(manifest_path) == "6adb305a8bbb7fb8438821125bb6324eeaf6243cf88b45c5482c0018c358685d"
assert digest(events_path) == "d75109917b6d3f0249f6d1cab08f6a71fcd0eb6a1fd1403780dc4b2631bbdd68"
manifest = json.loads(manifest_path.read_text())
frontend_path = root / "data/frontend.json"
assert digest(frontend_path) == manifest["frontend_sha256"]
frontend = json.loads(frontend_path.read_text())
events = [json.loads(line) for line in events_path.read_text().splitlines()]
used = [row["episode"] for row in events if row["event"] == "update_started" and row.get("phase") == "main"]
assert len(used) == len(set(used)) == 12
counts = {name: Counter() for name in ("retained_main", "remaining_train", "all_train", "dev")}
windows = {name: 0 for name in counts}
sizes = {}
input_hashes = {}
for entry in manifest["episodes"]:
    path = (root / "data" / entry["path"]).resolve()
    assert path.is_relative_to((root / "data").resolve()) and digest(path) == entry["sha256"]
    raw = json.loads(path.read_text())
    assert entry["partition"] in ("train", "dev")
    assert raw["sequence"][0] in ("ABC" if entry["partition"] == "train" else "D")
    sizes[entry["id"]] = len(raw["x"])
    assert sizes[entry["id"]] == len(raw["y"]) == entry["events"] == 128
    input_hashes[entry["path"]] = entry["sha256"]
    if entry["partition"] == "train":
        counts["all_train"].update(raw["y"])
        windows["all_train"] += 1
        group = "retained_main" if entry["id"] in used else "remaining_train"
    else:
        group = "dev"
    counts[group].update(raw["y"])
    windows[group] += 1
diagnostics = [row for row in events if row["event"] == "optimizer_step_completed" and row.get("phase") == "main"]
assert len(diagnostics) == 12
spike_counts = []
for row, episode_id in zip(diagnostics, used):
    raw_count = row["diagnostics"]["spike_fraction"] * sizes[episode_id] * 82
    count = round(raw_count)
    assert abs(raw_count - count) < 1e-8
    spike_counts.append(count)
denominator = sum(sizes[name] for name in used) * 82
report = {
    "schema": "hepta.plif.retained-data-denominators.v1",
    "manifest_sha256": digest(manifest_path),
    "events_sha256": digest(events_path),
    "frontend_sha256": digest(frontend_path),
    "partition_label_counts": {name: dict(sorted(value.items())) for name, value in counts.items()},
    "windows": windows,
    "events": {name: sum(value.values()) for name, value in counts.items()},
    "full_ABC_frontend_class_counts": frontend["class_counts"],
    "full_ABC_frontend_events": frontend["fit_events"],
    "main_episode_ids": used,
    "logged_main_spikes_per_update": spike_counts,
    "logged_main_spikes_total": sum(spike_counts),
    "main_neuron_event_denominator": denominator,
    "logged_main_spike_fraction": sum(spike_counts) / denominator,
    "window_events": 128,
    "new_training_runs": 0,
    "forward_calls": 0,
    "backward_calls": 0,
    "optimizer_steps": 0,
    "confirmation_access": False,
    "input_member_hashes": input_hashes,
}
args.output.parent.mkdir(parents=True, exist_ok=True)
with args.output.open("x") as handle:
    handle.write(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(json.dumps({key: value for key, value in report.items() if key != "input_member_hashes"}))
