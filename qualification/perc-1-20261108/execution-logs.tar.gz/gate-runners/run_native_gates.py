"""Run recorded native PERC-1 gates against the isolated, committed source tree."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('/home/qian-qi/work/perc-1-20261108-r1')
SOURCE = ROOT / 'source'
BASE = '6ddfca2406e4d01416cd2f7ab1655a0dc16f8da5'


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True).strip()


def identity():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain', '--untracked-files=all')}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['test', 'maintenance'])
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--filter')
    args = parser.parse_args()
    output = ROOT / 'evidence' / (args.phase + '-' + args.attempt)
    output.mkdir(parents=True, exist_ok=False)
    before = identity()
    if before['status']:
        raise ValueError('gate requires a clean committed source')
    env = os.environ.copy()
    pinned = {
        'CARGO_TARGET_DIR': '/home/qian-qi/work/chain-hepta-native-1f3ba4601505/target',
        'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0',
        'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
        'LIBCLANG_PATH': '/usr/lib/llvm-21/lib',
        'NEXTEST_PROFILE': 'local', 'NEXTEST_TEST_THREADS': '2',
        'RUSTUP_TOOLCHAIN': '1.96.0', 'RUST_MIN_STACK': '8388608',
        'PATH': '/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
    }
    env.update(pinned)
    result = {'schema': 'hepta.perc1.native-gates.v1', 'base': BASE,
              'phase': args.phase, 'source_before': before, 'environment': pinned,
              'steps': [], 'all_passed': False}
    if args.phase == 'test':
        commands = [
            ('helper', ['cargo', 'build', '--locked', '--message-format=json-render-diagnostics',
                        '-p', 'codex-hepta-infer-worker-host', '--bin', 'hepta-joint-propose']),
            ('neuron', ['just', 'test', '--locked', '-p', 'codex-hepta-neuron', '--lib', '--test-threads', '2']),
        ]
        if args.filter:
            commands[-1][1].extend(['-E', args.filter])
    else:
        commands = [
            ('clippy', ['just', 'fix', '--locked', '-p', 'codex-hepta-neuron', '--lib', '--', '-D', 'warnings']),
            ('fmt', ['just', 'fmt', '--base', BASE]),
        ]
    try:
        for name, argv in commands:
            start = time.time_ns()
            log = output / (name + '.log')
            with log.open('xb') as stream:
                proc = subprocess.run(argv, cwd=SOURCE / 'codex-rs', env=env,
                                      stdout=stream, stderr=subprocess.STDOUT)
            step = {'name': name, 'argv': argv, 'exit_code': proc.returncode,
                    'elapsed_seconds': (time.time_ns() - start) / 1e9,
                    'log_sha256': digest(log), 'log_bytes': log.stat().st_size,
                    'source_after': identity()}
            result['steps'].append(step)
            print(json.dumps(step), flush=True)
            if name == 'helper' and proc.returncode == 0:
                artifacts = []
                for line in log.read_text().splitlines():
                    try:
                        message = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if message.get('reason') == 'compiler-artifact' and message.get('target', {}).get('name') == 'hepta-joint-propose' and message.get('executable'):
                        artifacts.append(message)
                if len(artifacts) != 1:
                    raise ValueError('missing exact helper compiler artifact')
                executable = Path(artifacts[0]['executable'])
                immutable = output / 'hepta-joint-propose'
                immutable.write_bytes(executable.read_bytes())
                immutable.chmod(0o555)
                if digest(executable) != digest(immutable):
                    raise ValueError('helper changed while pinning')
                step['helper'] = {'path': str(immutable), 'sha256': digest(immutable),
                                  'compiler_artifact': artifacts[0]}
                env['CARGO_BIN_EXE_hepta-joint-propose'] = str(immutable)
                env['CARGO_BIN_EXE_hepta_joint_propose'] = str(immutable)
            if name == 'neuron':
                junit = SOURCE / 'codex-rs/target/nextest/local/junit.xml'
                if junit.exists() and junit.stat().st_mtime_ns >= start:
                    raw = junit.read_bytes()
                    xml = ET.fromstring(raw)
                    if xml.attrib.get('uuid') not in log.read_text():
                        raise ValueError('JUnit does not belong to this run')
                    (output / 'neuron.xml').write_bytes(raw)
                    cases = xml.findall('.//testcase')
                    step['tests'] = {'total': len(cases),
                        'failed': sum(c.find('failure') is not None or c.find('error') is not None for c in cases),
                        'skipped': sum(c.find('skipped') is not None for c in cases),
                        'perc_cases': [c.attrib.get('name') for c in cases if 'perception' in c.attrib.get('classname', '') or 'perception' in c.attrib.get('name', '')],
                        'junit_sha256': hashlib.sha256(raw).hexdigest()}
            if proc.returncode:
                raise RuntimeError(name + ' failed; see the retained log')
            if args.phase == 'test' and identity() != before:
                raise ValueError('source changed during test gate')
        result['all_passed'] = True
    except Exception as error:
        result['error'] = str(error)
        raise
    finally:
        result['source_after'] = identity()
        (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
