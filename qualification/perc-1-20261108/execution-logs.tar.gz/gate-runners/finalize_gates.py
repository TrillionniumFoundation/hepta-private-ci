"""Apply the reviewed Python harness and record native-host validation/formatting."""
import argparse
import ast
import base64
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/perc-1-20261108-r1')
SOURCE = ROOT / 'source'
BASE = '6ddfca2406e4d01416cd2f7ab1655a0dc16f8da5'
NATIVE_HEAD = '6745ba2c4da1657ab44b462857a9d010903b9d62'
ENV = os.environ.copy()
ENV.update(TZ='UTC', GIT_AUTHOR_NAME='OpenAI Codex',
           GIT_AUTHOR_EMAIL='codex@openai.com', GIT_COMMITTER_NAME='OpenAI Codex',
           GIT_COMMITTER_EMAIL='codex@openai.com')


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], env=ENV, text=True).strip()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain', '--untracked-files=all')}


def paths():
    return git('diff', '--name-only', BASE).splitlines()


def hashes():
    return {path: digest((SOURCE / path).read_bytes()) for path in paths() if (SOURCE / path).is_file()}


def commit(files, message):
    subprocess.run(['git', '-C', str(SOURCE), 'add', '--', *files], env=ENV, check=True)
    subprocess.run(['git', '-C', str(SOURCE), 'diff', '--cached', '--check'], env=ENV, check=True)
    subprocess.run(['git', '-C', str(SOURCE), 'commit', '-m', message], env=ENV, check=True)
    return identity()


def run_step(argv, output, env, name):
    start = time.time_ns()
    with (output / (name + '.stdout.txt')).open('xb') as stdout, (output / (name + '.stderr.txt')).open('xb') as stderr:
        proc = subprocess.run(argv, cwd=SOURCE, env=env, stdout=stdout, stderr=stderr)
    return {'argv': argv, 'exit_code': proc.returncode, 'elapsed_seconds': (time.time_ns() - start) / 1e9,
            'stdout_sha256': digest((output / (name + '.stdout.txt')).read_bytes()),
            'stderr_sha256': digest((output / (name + '.stderr.txt')).read_bytes())}


def apply_test(package, sha):
    raw = Path(package).read_bytes()
    assert digest(raw) == sha
    payload = json.loads(gzip.decompress(raw))
    assert git('rev-parse', 'HEAD') == NATIVE_HEAD
    output = ROOT / 'evidence' / 'python-native-r1'
    output.mkdir(parents=True, exist_ok=False)
    dirty = git('diff', '--name-only').splitlines()
    assert all(path.startswith('codex-rs/hepta-neuron/src/perception') and path.endswith('.rs') for path in dirty)
    (output / 'initial-rustfmt.patch').write_text(git('diff', '--no-ext-diff') + '\n')
    commits = []
    if dirty:
        commits.append(commit(dirty, 'style(hepta-neuron): format PERC-1 contracts and tests'))
    assert not identity()['status']
    for path, item in payload['files'].items():
        assert (path.startswith('scripts/perc1/') or path.startswith('qualification/perc-1-20261108/') or
                path in ('scripts/test_perc1.py', 'scripts/perc1_marginal.py', 'scripts/test_perc1_marginal.py'))
        assert all(part not in ('', '.', '..') for part in path.split('/'))
        data = base64.b64decode(item['base64'], validate=True)
        assert digest(data) == item['sha256']
        destination = SOURCE / path
        assert not destination.exists()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
    groups = [
        (['scripts/perc1/' + name for name in ('__init__.py', 'schema.py', 'experiment.py', 'native.py')],
         'feat(perc1): validate actor evidence and complete acquisition receipts'),
        (['scripts/perc1/' + name for name in ('report.py', 'fixture.py', '__main__.py', 'example_manifest.json')] + ['scripts/test_perc1.py'],
         'feat(perc1): add paired four-arm reports and diagnostic fixtures'),
        (['scripts/perc1_marginal.py', 'scripts/test_perc1_marginal.py'],
         'feat(perc1): audit final-answer change after one extra observation'),
        ([path for path in payload['files'] if path.startswith('qualification/')],
         'docs(perc1): freeze protocol and state qualification boundaries'),
    ]
    for files, message in groups:
        commits.append(commit(files, message))
    before = identity()
    assert not before['status']
    result = {'schema': 'hepta.perc1.python-native-gate.v1', 'python': sys.version,
              'source_before': before, 'source_hashes': hashes(), 'commits': commits, 'all_passed': False}
    env = ENV.copy(); env['PYTHONPATH'] = str(SOURCE / 'scripts')
    try:
        result['test'] = run_step([sys.executable, '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_perc1*.py', '-v'], output, env, 'tests')
        assert result['test']['exit_code'] == 0
        text = (output / 'tests.stderr.txt').read_text()
        assert 'Ran 24 tests' in text and '\nOK\n' in text
        result['test']['count'] = 24
        assert identity() == before and hashes() == result['source_hashes']
        result['all_passed'] = True
    finally:
        result['source_after'] = identity()
        (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'phase': 'apply-test', 'passed': result['all_passed'], 'tests': 24, 'source': identity()}), flush=True)


def format_source():
    output = ROOT / 'evidence' / 'format-r2'
    output.mkdir(parents=True, exist_ok=False)
    before = identity()
    assert not before['status']
    before_hashes = hashes()
    py_paths = [path for path in before_hashes if path.endswith('.py')]
    ast_before = {path: ast.dump(ast.parse((SOURCE / path).read_text()), include_attributes=False) for path in py_paths}
    uv = Path('/home/qian-qi/work/cell-rsi-p0p2-20261108-858e/tools/uv-0.11.3/uv')
    assert digest(uv.read_bytes()) == 'fa5fc652fa5ed5b44fa8e7dda507f27975c02f59643787fd8ab4bf36f1ba7438'
    env = ENV.copy()
    env.update(RUSTUP_TOOLCHAIN='1.96.0',
               PATH=str(ROOT / 'tools' / 'bin') + ':' + str(uv.parent) + ':/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin:/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin')
    result = {'schema': 'hepta.perc1.format-gate.v1', 'source_before': before,
              'source_hashes_before': before_hashes, 'all_passed': False}
    try:
        result['format'] = run_step(['just', 'fmt', '--base', BASE], output, env, 'format')
        assert result['format']['exit_code'] == 0
        ast_after = {path: ast.dump(ast.parse((SOURCE / path).read_text()), include_attributes=False) for path in py_paths}
        assert ast_before == ast_after
        result['python_ast_unchanged'] = True
        assert (SOURCE / 'codex-rs/hepta-neuron/tests/fixtures/perception-bytes-v1.json').read_bytes().rstrip(b'\n') == subprocess.check_output(['git', '-C', str(SOURCE), 'show', NATIVE_HEAD + ':codex-rs/hepta-neuron/tests/fixtures/perception-bytes-v1.json']).rstrip(b'\n')
        result['native_wire_fixture_unchanged'] = True
        (output / 'format.patch').write_text(git('diff', '--no-ext-diff') + '\n')
        subprocess.run(['git', '-C', str(SOURCE), 'diff', '--check'], env=ENV, check=True)
        changed = git('diff', '--name-only').splitlines()
        if changed:
            result['format_commit'] = commit(changed, 'style(perc1): apply repository formatters without changing Python AST')
        result['source_hashes_after'] = hashes()
        result['all_passed'] = True
    finally:
        result['source_after'] = identity()
        (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'phase': 'format', 'passed': result['all_passed'], 'python_ast_unchanged': result.get('python_ast_unchanged'), 'source': identity()}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['apply-test', 'format'])
    parser.add_argument('--package')
    parser.add_argument('--sha256')
    args = parser.parse_args()
    if args.phase == 'apply-test':
        apply_test(args.package, args.sha256)
    else:
        format_source()
