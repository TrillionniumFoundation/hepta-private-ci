"""Bind engineering evidence and final synthetic diagnostics to immutable sources."""
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time

ROOT = Path('/home/qian-qi/work/perc-1-20261108-r1')
SOURCE = ROOT / 'source'
DEST = SOURCE / 'qualification' / 'perc-1-20261108'
BASE = '6ddfca2406e4d01416cd2f7ab1655a0dc16f8da5'
BASE_TREE = '491eace326f335498334fb051c9e8f298ca7a04c'
NATIVE_TESTED = '6745ba2c4da1657ab44b462857a9d010903b9d62'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def read(path):
    return json.loads(Path(path).read_bytes())


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def git_bytes(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args])


def git(*args):
    return git_bytes(*args).decode().strip()


def identity():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain', '--untracked-files=all')}


def tar_gz(files):
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w') as archive:
        for name, raw in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            archive.addfile(info, io.BytesIO(raw))
    return gzip.compress(stream.getvalue(), mtime=0)


def main():
    source = identity()
    assert not source['status']
    native = read(ROOT / 'evidence/test-r1/result.json')
    maintenance = read(ROOT / 'evidence/maintenance-r1/result.json')
    python = read(ROOT / 'evidence/python-native-r1/result.json')
    formatted = read(ROOT / 'evidence/format-r2/result.json')
    review = read(ROOT / 'format-review.json')
    tools = read(ROOT / 'tools/receipt.json')
    assert native['all_passed'] and native['source_before']['head'] == NATIVE_TESTED
    neuron = next(step for step in native['steps'] if step['name'] == 'neuron')
    assert neuron['tests']['total'] == 190 and neuron['tests']['failed'] == 0 and neuron['tests']['skipped'] == 0
    assert len(neuron['tests']['perc_cases']) == 16
    assert maintenance['steps'][0]['name'] == 'clippy' and maintenance['steps'][0]['exit_code'] == 0
    assert python['all_passed'] and python['test']['count'] == 24
    assert formatted['all_passed'] and formatted['python_ast_unchanged'] and formatted['source_after'] == source
    assert review['review']['conclusion'] == 'mechanical_formatting_only_no_semantic_change_observed'
    assert review['review']['all_before_after_blob_identities_match']
    assert review['patch']['sha256'] == digest((ROOT / 'evidence/python-native-r1/initial-rustfmt.patch').read_bytes())
    code = [path for path in git('diff', '--name-only', BASE).splitlines() if path.startswith(('codex-rs/', 'scripts/'))]
    final_hashes = {path: digest((SOURCE / path).read_bytes()) for path in code}
    assert all(formatted['source_hashes_after'][path] == value for path, value in final_hashes.items())

    output = ROOT / 'evidence' / 'final-diagnostic'
    output.mkdir(parents=True, exist_ok=False)
    smoke = output / 'smoke'
    env = os.environ.copy(); env['PYTHONPATH'] = str(SOURCE / 'scripts')
    commands = [
        ('smoke', [sys.executable, '-m', 'perc1', 'smoke', '--output', str(smoke)]),
        ('reload-report', [sys.executable, '-m', 'perc1', 'report', *[str(smoke / (name + '.json')) for name in ('manifest', 'dataset', 'traces', 'evaluator')], '--output', str(output / 'reloaded-report.json')]),
    ]
    runs = []
    for name, argv in commands:
        started = time.time_ns()
        with (output / (name + '.stdout.txt')).open('xb') as stdout, (output / (name + '.stderr.txt')).open('xb') as stderr:
            result = subprocess.run(argv, cwd=SOURCE, env=env, stdout=stdout, stderr=stderr)
        runs.append({'name': name, 'argv': argv, 'exit_code': result.returncode, 'elapsed_seconds': (time.time_ns() - started) / 1e9,
                     'stdout_sha256': digest((output / (name + '.stdout.txt')).read_bytes()), 'stderr_sha256': digest((output / (name + '.stderr.txt')).read_bytes())})
        assert result.returncode == 0
    assert read(smoke / 'report.json') == read(output / 'reloaded-report.json')
    report = read(smoke / 'report.json')
    assert report['status'] == 'HOLD' and report['scientific_qualified'] is False
    sys.path.insert(0, str(SOURCE / 'scripts'))
    from perc1.experiment import FixtureExecutor
    from perc1.schema import Dataset, load, sha
    from perc1_marginal import compare_pair
    frozen, dataset, evaluator = load(smoke / 'manifest.json'), Dataset(load(smoke / 'dataset.json'), smoke), load(smoke / 'evaluator.json')
    marginal = {}
    for name, index in [('useful_capture', 2), ('distractor_capture', 1)]:
        episode = dataset.episodes['confirmation.missing_document']
        left = FixtureExecutor(frozen, dataset, episode, 11, 'dense_active')
        right = FixtureExecutor(frozen, dataset, episode, 11, 'dense_active')
        left.attempt(episode['initial_ids'][0]); right.attempt(episode['initial_ids'][0])
        right.attempt(episode['source_ids'][index])
        for executor in (left, right):
            for step in executor.trace['steps']:
                if step['observation'] is None:
                    continue
                candidates = [line[7:] for line in base64.b64decode(step['observation']['raw_base64']).decode().splitlines() if line.startswith('answer:')]
                if candidates:
                    executor.trace['answer'] = {'text': candidates[0], 'fields': {'critical': candidates[0]}, 'evidence_ids': [step['proposal']['source_id']]}
        pair = {'schema': 'perc1.marginal-pair.v1', 'world_snapshot_sha256': sha(dataset.value), 'continuation_sha256': frozen['controller']['sha256'], 'inference_seed': 19, 'without': left.trace, 'with': right.trace}
        value = compare_pair(pair, frozen, dataset, evaluator)
        assert value['status'] == 'HOLD' and value['scientific_qualified'] is False
        write(smoke / (name + '-pair.json'), pair)
        write(smoke / (name + '-report.json'), value)
        marginal[name] = value
    assert marginal['useful_capture']['task_success_change'] == 1
    assert marginal['distractor_capture']['task_success_change'] == 0
    assert all(value['incremental_cost'] > 0 for value in marginal.values())
    assert identity() == source
    assert final_hashes == {path: digest((SOURCE / path).read_bytes()) for path in code}

    readme = DEST / 'README.md'
    text = readme.read_text().replace('The source-pinned local run passed **24 Python tests**.', 'The source-pinned local and native-host runs each passed **24 Python tests**.')
    text = text.replace('The public candidate is an extension', 'This candidate is an extension')
    text += '''
## Retained execution evidence

[ENGINEERING.json](ENGINEERING.json) records the completed engineering gate:
190 native tests, 24 Python tests on both hosts, scoped strict Clippy, and the
repository's actual formatting command all passed. [EXECUTION.json](EXECUTION.json)
retains individual attempts, including the first formatting failure caused by a
missing DotSlash executable. The second attempt used verified real DotSlash and uv
binaries. Rust formatting received a separate mechanical review; Python formatting
preserved the complete AST. Functional tests were not rerun solely for formatting.

[SOURCE_CONTENT.json](SOURCE_CONTENT.json) binds final code bytes to the tested and
formatted source identities. [ARTIFACTS.json](ARTIFACTS.json) indexes every retained
artifact and archive member by SHA-256. The [execution archive](execution-logs.tar.gz)
contains complete gate logs, JUnit, formatting patches, tool receipts and gate
runners; the helper executable itself is identified by digest, not embedded.

The [synthetic archive](synthetic-smoke.tar.gz) retains the frozen manifest,
dataset, all captured text views, sealed evaluator, 32 traces, terminal reports and
both single-observation pairs. [SYNTHETIC_REPORT.json](SYNTHETIC_REPORT.json) is the
readable four-arm result; [SYNTHETIC_MARGINAL.json](SYNTHETIC_MARGINAL.json) includes
one useful and one distractor acquisition. Both incur positive cost, and only the
useful synthetic acquisition changes the terminal answer. These records exercise
the evaluation machinery and remain **HOLD**; they are not real model confirmation.
'''
    readme.write_text(text)

    execution = {'schema': 'hepta.perc1.execution.v1', 'native_test': native, 'maintenance_first_attempt': maintenance,
                 'python_native_test': python, 'format_second_attempt': formatted, 'format_review': review, 'formatter_tools': tools,
                 'final_diagnostic': {'source': source, 'commands': runs, 'report_reload_equal': True,
                                      'manifest_sha256': digest((smoke / 'manifest.json').read_bytes()), 'trace_count': len(read(smoke / 'traces.json'))}}
    write(DEST / 'EXECUTION.json', execution)
    write(DEST / 'SOURCE_CONTENT.json', {'schema': 'hepta.perc1.source-content.v1', 'source': source, 'final_sha256': final_hashes,
        'native_tested_commit': NATIVE_TESTED, 'native_format_patch_sha256': digest((ROOT / 'evidence/python-native-r1/initial-rustfmt.patch').read_bytes()),
        'python_tested_commit': python['source_before']['head'], 'python_ast_preserved_by_format': True})
    write(DEST / 'SYNTHETIC_REPORT.json', report)
    write(DEST / 'SYNTHETIC_MARGINAL.json', {'status': 'HOLD', 'scientific_qualified': False, 'diagnostics': marginal})
    write(DEST / 'ENGINEERING.json', {'schema': 'hepta.perc1.engineering-summary.v1', 'engineering_status': 'PASS', 'scientific_status': 'HOLD',
        'scientific_qualified': False, 'production_activated': False, 'source': source, 'native_tests': 190, 'new_perception_tests': 16,
        'python_tests_local_and_native': 24, 'strict_clippy': 'PASS', 'repository_format': 'PASS', 'format_attempts': 2,
        'synthetic_paired_traces': 32, 'real_model_training_runs': 0, 'real_media_confirmation_runs': 0,
        'closed_review_findings': ['unknown acquisition retains pending reservation', 'full immutable metadata cost quoted before read',
                                  'nested actor values frozen', 'same content and locator aliases deduplicated', 'native export numeric and wire bounds aligned'],
        'remaining': ['authenticated learned encoder execution receipts', 'production context.compiler and capture organ wiring',
                      'current-policy acquisition reservation/execution/settlement ownership', 'preregistered real-task four-arm confirmation']})
    log_files = {}
    for relative in ['test-r1/result.json', 'test-r1/helper.log', 'test-r1/neuron.log', 'test-r1/neuron.xml',
                     'maintenance-r1/result.json', 'maintenance-r1/clippy.log', 'maintenance-r1/fmt.log',
                     'python-native-r1/result.json', 'python-native-r1/tests.stdout.txt', 'python-native-r1/tests.stderr.txt', 'python-native-r1/initial-rustfmt.patch',
                     'format-r2/result.json', 'format-r2/format.stdout.txt', 'format-r2/format.stderr.txt', 'format-r2/format.patch']:
        log_files[relative] = (ROOT / 'evidence' / relative).read_bytes()
    for path in output.glob('*.txt'):
        log_files['final-diagnostic/' + path.name] = path.read_bytes()
    log_files['formatter-tools.json'] = (ROOT / 'tools/receipt.json').read_bytes()
    log_files['format-review.json'] = (ROOT / 'format-review.json').read_bytes()
    for name in ('run_native_gates.py', 'finalize_gates.py', 'finalize_artifacts.py'):
        log_files['gate-runners/' + name] = (ROOT / name).read_bytes()
    (DEST / 'execution-logs.tar.gz').write_bytes(tar_gz(log_files))
    smoke_files = {str(path.relative_to(smoke)): path.read_bytes() for path in smoke.rglob('*') if path.is_file()}
    (DEST / 'synthetic-smoke.tar.gz').write_bytes(tar_gz(smoke_files))
    write(DEST / 'ARTIFACTS.json', {'schema': 'hepta.perc1.artifact-index.v1',
        'files': {path.name: {'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes())} for path in sorted(DEST.iterdir()) if path.is_file() and path.name != 'ARTIFACTS.json'},
        'execution_archive_members': {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(log_files.items())},
        'synthetic_archive_members': {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(smoke_files.items())}})
    env = os.environ.copy()
    env.update(TZ='UTC', GIT_AUTHOR_NAME='OpenAI Codex', GIT_AUTHOR_EMAIL='codex@openai.com', GIT_COMMITTER_NAME='OpenAI Codex', GIT_COMMITTER_EMAIL='codex@openai.com')
    subprocess.run(['git', '-C', str(SOURCE), 'add', '--', str(DEST.relative_to(SOURCE))], env=env, check=True)
    subprocess.run(['git', '-C', str(SOURCE), 'diff', '--cached', '--check'], env=env, check=True)
    subprocess.run(['git', '-C', str(SOURCE), 'commit', '-m', 'test(perc1): retain source-bound native gates and synthetic diagnostics'], env=env, check=True)
    final = identity()
    assert not final['status']
    final_paths = git('diff', '--name-only', BASE).splitlines()
    assert not any(path.startswith('.github/') for path in final_paths)
    commits, previous, previous_tree = [], BASE, BASE_TREE
    for sha_value in git('rev-list', '--reverse', BASE + '..HEAD').splitlines():
        assert git('rev-parse', sha_value + '^') == previous
        tree = git('rev-parse', sha_value + '^{tree}')
        changes = []
        for path in git('diff', '--name-only', previous, sha_value).splitlines():
            entry = git('ls-tree', sha_value, '--', path).split(None, 3)
            assert len(entry) == 4 and entry[1] == 'blob'
            data = git_bytes('cat-file', 'blob', entry[2])
            changes.append({'path': path, 'mode': entry[0], 'type': 'blob', 'sha': entry[2], 'sha256': digest(data), 'base64': base64.b64encode(data).decode()})
        commits.append({'sha': sha_value, 'tree': tree, 'base_tree': previous_tree, 'raw_base64': base64.b64encode(git_bytes('cat-file', 'commit', sha_value)).decode(), 'changes': changes})
        previous, previous_tree = sha_value, tree
    payload = {'repository': 'TrillionniumFoundation/hepta-private-ci', 'branch': 'codex/perc-1-20261108-r1', 'base': BASE,
               'base_tree': BASE_TREE, 'head': final['head'], 'tree': final['tree'],
               'review': {'complete': True, 'workflows_unchanged': True, 'gates_passed': True, 'scientific_status': 'HOLD',
                          'execution_sha256': digest((DEST / 'EXECUTION.json').read_bytes()), 'engineering_sha256': digest((DEST / 'ENGINEERING.json').read_bytes()),
                          'source_content_sha256': digest((DEST / 'SOURCE_CONTENT.json').read_bytes())}, 'commits': commits}
    package = gzip.compress(canonical(payload), mtime=0)
    (ROOT / 'publication-package.json.gz').write_bytes(package)
    bundle = {'identity': final, 'files': {path: {'sha256': digest((SOURCE / path).read_bytes()), 'base64': base64.b64encode((SOURCE / path).read_bytes()).decode()} for path in final_paths if not path.endswith('.tar.gz')}}
    bundle_raw = gzip.compress(canonical(bundle), mtime=0)
    (ROOT / 'final-source-bundle.json.gz').write_bytes(bundle_raw)
    receipt = {'head': final['head'], 'tree': final['tree'], 'commits': len(commits), 'paths': len(final_paths),
               'package': {'bytes': len(package), 'sha256': digest(package)}, 'source_bundle': {'bytes': len(bundle_raw), 'sha256': digest(bundle_raw)}}
    write(ROOT / 'publication-manifest.json', receipt)
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
