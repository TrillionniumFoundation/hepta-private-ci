from pathlib import Path
import subprocess,time,hashlib,re,json,statistics,os
root=Path("/tmp/hcsn-7149-musl-witness.4hSOyr")
out=root/"paired";out.mkdir(exist_ok=True)
arms=["baseline","buffered","buffered","baseline"]*3
names={}
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
 return h.hexdigest()
for arm in set(arms):
 binary=root/(arm+"-agentd")
 while not binary.exists():time.sleep(10)
 # Wait for the complete native output copy.
 while True:
  size=binary.stat().st_size
  time.sleep(1)
  if size>0 and size==binary.stat().st_size:break
 lines=subprocess.check_output([str(binary),"--list"],text=True).splitlines()
 hits=[x.removesuffix(": test") for x in lines if x.endswith("::original_next_use_evidence_timing_diagnostic: test")]
 if len(hits)!=1:raise RuntimeError((arm,hits))
 names[arm]=hits[0]
assert len(set(names.values()))==1
results=[]
def measure(arm,i,trace=False):
 binary=root/(arm+"-agentd"); prefix=("trace-" if trace else "run-")+str(i)+"-"+arm
 argv=[str(binary),"--exact",names[arm],"--nocapture","--test-threads=1"]
 if trace: argv=["strace","-f","-c","-e","trace=read,pread64","-o",str(out/(prefix+".strace")),*argv]
 wall=time.monotonic(); load=os.getloadavg()
 try:
  proc=subprocess.run(argv,cwd=root/arm,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240);s=proc.stdout.decode(errors="replace");rc=proc.returncode
 except subprocess.TimeoutExpired as exc:s=(exc.stdout or b"").decode(errors="replace");rc=124
 elapsed=time.monotonic()-wall
 (out/(prefix+".log")).write_text(s)
 metrics=re.findall(r"\b([A-Za-z_]+(?:_us|_ms))\s*[=:]\s*(\d+)",s)
 row=dict(arm=arm,index=i,rc=rc,wall_seconds=elapsed,load_start=load,metrics=[(k,int(v)) for k,v in metrics],test_pass=int("1 passed; 0 failed" in s),test_executed=("running 1 test" in s))
 print(prefix,rc,metrics,flush=True);return row
for i,arm in enumerate(arms,1):
 results.append(measure(arm,i))
 (out/"partial.json").write_text(json.dumps(results,indent=2))
trace=[measure(a,i,True) for i,a in enumerate(("baseline","buffered"),1)]
summary={"design":(root/"plan.txt").read_text(),"binary_sha256":{a:sha(root/(a+"-agentd")) for a in set(arms)},"case":names["baseline"],"runs":results,"strace_diagnostics":trace}
(out/"receipt.json").write_text(json.dumps(summary,sort_keys=True,indent=2)+"\n")
print("receipt",sha(out/"receipt.json"),flush=True)

