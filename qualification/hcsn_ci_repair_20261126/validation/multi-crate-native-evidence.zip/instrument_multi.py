"""Add operation counts to the original timing fixture in an isolated diagnostic checkout."""
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
assert root.name == "multi-count-src" and "musl-immutable" in str(root)
rust = root / "codex-rs"
def code(crate, path): return rust / crate / "src" / path
def insert(file, before, prefix):
    s = file.read_text()
    assert s.count(before) == 1, (file, before)
    file.write_text(s.replace(before, prefix + before, 1))
def counter(n): return f"        crate::hcsn_multi_hit({n});\n"
def create(crate, length):
    file = code(crate, "lib.rs")
    s = file.read_text()
    assert "HCSN_MULTI" not in s
    file.write_text(s + f'''
static HCSN_MULTI: [std::sync::atomic::AtomicU64; {length}] = [const {{ std::sync::atomic::AtomicU64::new(0) }}; {length}];
#[doc(hidden)]
pub fn hcsn_multi_hit(index: usize) {{
    HCSN_MULTI[index].fetch_add(1, std::sync::atomic::Ordering::Relaxed);
}}
#[doc(hidden)]
pub fn hcsn_multi_snapshot() -> [u64; {length}] {{
    std::array::from_fn(|index| HCSN_MULTI[index].load(std::sync::atomic::Ordering::Relaxed))
}}
''')
create("hepta-agentd", 10)
create("hepta-learning-artifacts", 4)
create("hepta-neuron", 1)
create("hepta-contracts", 3)
f = code("hepta-contracts","final_use_retained.rs")
before = "    ) -> Result<FinalUseRevocations, FinalUseError> {\n        if self.0.frontier_store.is_none() {"
data = f.read_text()
assert data.count(before) == 1
f.write_text(data.replace(before, before.replace("        if", counter(0) + "        if"), 1))
insert(f, "        if signed.grant.schema_version != profile.grant_schema()", counter(1))
old = "                && key.key.verify(&input, &signed.signature)"
data = f.read_text()
assert data.count(old) == 1
f.write_text(data.replace(old, "                && { crate::hcsn_multi_hit(2); key.key.verify(&input, &signed.signature) }", 1))
s = code("hepta-learning-artifacts","selection.rs")
insert(s, "        if trust.registry_id != artifact_owner_trust.registry_id", counter(0))
insert(s, "        if current.trust_digest() != self.artifact_owner_trust_digest", counter(1))
insert(s, "        VerifyingKey::from_bytes(&selector.verifying_key)\n", counter(2))
insert(s, "        let mut digest_bytes = signed.signing_bytes();", counter(3))
s = code("hepta-neuron","cell_generation_current.rs")
insert(s, "        for id in [", counter(0))
s = code("hepta-agentd","neuron_generation_current_store.rs")
insert(s, "        let head = match &self.store {", counter(0) + '''
        let variant = match &self.store {
            Store::Host(_) => 6,
            #[cfg(target_os = "linux")]
            Store::Root(_) => 7,
            #[cfg(target_os = "linux")]
            Store::RootInitial(_) => 8,
            #[cfg(test)]
            Store::Test { .. } => 9,
        };
        crate::hcsn_multi_hit(variant);
''')
insert(s, "        head.current.digest().map_err(invalid)?;", counter(1))
insert(s, "        Ok(head)\n", counter(2))
insert(code("hepta-agentd","neuron_generation_current_initial_types.rs"),"        self.target.digest().map_err(invalid)?;",counter(3))
s = code("hepta-agentd","neuron_generation_update_live.rs")
insert(s,"        // Lock order is artifact owner -> selected payload -> FinalUse owner.",counter(4))
insert(s,"        self.authorities\n            .final_use\n            .verify_retained_use(", counter(5))
s = code("hepta-agentd","circuit_next_use_command_owner_tests.rs")
before='        eprintln!("HCSN_ORIGINAL_PHASE {phase} {:?}",'
insert(s,before,'''        eprintln!("HCSN_MULTI_PHASE {phase} {:?} {:?} {:?} {:?}", crate::hcsn_multi_snapshot(), codex_hepta_learning_artifacts::hcsn_multi_snapshot(), codex_hepta_neuron::hcsn_multi_snapshot(), codex_hepta_contracts::hcsn_multi_snapshot());
''')
