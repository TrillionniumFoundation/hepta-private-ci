from pathlib import Path
import sys
r=Path(sys.argv[1]).resolve(); assert 'musl-immutable' in str(r) and str(r).endswith('/count-source');rust=r/'codex-rs';signed=rust/'hepta-learning-ledger/src/signed_evidence.rs';lb=rust/'hepta-learning-ledger/src/lib.rs';pub=rust/'hepta-agentd/src/circuit_learning_read_service.rs';case=rust/'hepta-agentd/src/circuit_next_use_command_owner_tests.rs';s=signed.read_text();assert s.count('VerifyingKey::from_bytes(&signer.verifying_key)')==2
head='''
static PROFILE: [std::sync::atomic::AtomicU64; 11] = [const { std::sync::atomic::AtomicU64::new(0) }; 11];

pub fn hcsn_profile_counts() -> [u64; 11] {
    std::array::from_fn(|i| PROFILE[i].load(std::sync::atomic::Ordering::Relaxed))
}

pub fn hcsn_profile_stage(index: usize, ns: u64) {
    PROFILE[3 + 2 * index].fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    PROFILE[4 + 2 * index].fetch_add(ns, std::sync::atomic::Ordering::Relaxed);
}
''';s=s.replace('const MAX_SIGNERS:',head+'\nconst MAX_SIGNERS:',1);s=s.replace('            let key = VerifyingKey::from_bytes(&signer.verifying_key)','            PROFILE[0].fetch_add(1, std::sync::atomic::Ordering::Relaxed);\n            let key = VerifyingKey::from_bytes(&signer.verifying_key)',1);s=s.replace('        if payload.len() > MAX_PAYLOAD_BYTES {','        PROFILE[1].fetch_add(1, std::sync::atomic::Ordering::Relaxed);\n        if payload.len() > MAX_PAYLOAD_BYTES {',1);s=s.replace('        VerifyingKey::from_bytes(&signer.verifying_key)\n','        PROFILE[2].fetch_add(1, std::sync::atomic::Ordering::Relaxed);\n        VerifyingKey::from_bytes(&signer.verifying_key)\n',1);signed.write_text(s);s=lb.read_text();mark='pub use signed_evidence::LearningEvidenceRoleV1;';assert mark in s;lb.write_text(s.replace(mark,'pub use signed_evidence::{hcsn_profile_counts, hcsn_profile_stage};\n'+mark,1));s=pub.read_text();mark='    fn read_original(&self) -> Result<Readback, Error> {\n'; assert s.count(mark)==1;pre,tail=s.split(mark);macro='''        macro_rules! measure {
            ($stage:expr, $call:expr) => {{
                let time = std::time::Instant::now();
                let result = $call;
                codex_hepta_learning_ledger::hcsn_profile_stage($stage, time.elapsed().as_nanos() as u64);
                result
            }};
        }
''';import re
for i,reg,k in [(0,r'self\.require_task_input_current\(\)',3),(1,r'cell\.read_learning_selection\(&coordinator\)',2),(2,r'cell\.read_learning_next_use\(&prefix, &self\.source, &self\.identity\)',1),(3,r'self\s*\.source\s*\.read_run_publication\(&self\.identity, &self\.cell\.task\.source\(\)\.scope\.run_id\)',2)]:
 tail,n=re.subn(reg,lambda m:'measure!('+str(i)+', '+m.group()+')',tail);assert n==k,(i,n)
pub.write_text(pre+mark+macro+tail);s=case.read_text();mark='async fn original_next_use_evidence_timing_diagnostic() -> anyhow::Result<()> {\n';assert s.count(mark)==1;pre,t=s.split(mark);defn='''    let snapshot = |phase: &str| {
        eprintln!("HCSN_ORIGINAL_PHASE {phase} {:?}", codex_hepta_learning_ledger::hcsn_profile_counts());
    };
    snapshot("fixture_start");
''';need=[('    let command_current = client.readback().await;','    let command_current = client.readback().await;'),];first='    let started = std::time::Instant::now();';j=t.index(first);t=t[:j]+'    snapshot("command_start");\n'+t[j:];t=t.replace('    let command_current = command_current?;','    snapshot("command_return");\n    let command_current = command_current?;',1);e=t.index('    let evidence_server = ');j=t.index(first,e);t=t[:j]+'    snapshot("evidence_start");\n'+t[j:];t=t.replace('    drop(evidence);','    snapshot("evidence_client_return");\n    drop(evidence);',1);k='    eprintln!(\n        "LEARN_FDE_C_TIMING evidence_peer_terminal';assert k in t;t=t.replace(k,'    snapshot("evidence_server_joined");\n'+k,1);t=t.replace('    evidence_terminal?;','    snapshot("fixture_return");\n    evidence_terminal?;',1);case.write_text(pre+mark+defn+t)
