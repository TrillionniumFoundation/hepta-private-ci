"""Summarize source counters for four separately instrumented original Rust crates."""
import hashlib
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent
groups = {
    "hepta-agentd": [
        "CurrentStore_load_enter", "CurrentStore_current_digest_starts", "CurrentStore_load_completed",
        "InitialIntent_target_digest_starts", "LiveGenerationCurrent_check_live",
        "LiveGenerationCurrent_calls_verify_retained_use", "CurrentStore_host_load",
        "CurrentStore_root_load", "CurrentStore_root_initial_load", "CurrentStore_test_load"
    ],
    "hepta-learning-artifacts": [
        "ArtifactSelectionVerifier_new", "ArtifactSelectionVerifier_verify_enter",
        "ArtifactSelectionVerifier_begin_key_decode_and_strict_verify",
        "ArtifactSelectionVerifier_second_signing_bytes_after_success",
    ],
    "hepta-neuron": ["CellGenerationOwnerBinding_digest"],
    "hepta-contracts": [
        "FinalUseAuthority_verify_retained_use_enter", "RetainedUse_authenticate_enter",
        "RetainedUse_actual_pinned_issuer_verify"
    ]
}
ranges = [
    ("command", "command_start", "command_return"),
    ("evidence_client", "evidence_start", "evidence_client_return"),
    ("evidence_beyond_client", "evidence_client_return", "evidence_server_joined"),
    ("evidence_complete", "evidence_start", "evidence_server_joined"),
]
summary = {}
for path in sorted(root.glob("original-multi-?.log")):
    src=path.read_bytes()
    stages = {}
    for phase, tail in re.findall(r'HCSN_MULTI_PHASE (\w+) ([^\n]+)', src.decode()):
        arrays = [json.loads(s) for s in re.findall(r'\[[^]]+\]',tail)]
        assert len(arrays)==4
        stages[phase] = {crate:dict(zip(names, nums, strict=True)) for (crate,names),nums in zip(groups.items(),arrays,strict=True)}
    assert all(a in stages and b in stages for _,a,b in ranges)
    counts={}
    for interval,a,b in ranges:
        counts[interval]={crate:{k:stages[b][crate][k]-stages[a][crate][k] for k in keys}
                          for crate,keys in groups.items()}
    summary[path.name]={"raw_sha256":hashlib.sha256(src).hexdigest(),"counts":counts}
assert len(summary)==2
(root/"original-multi-counts.json").write_text(json.dumps(summary,indent=2)+"\n")
