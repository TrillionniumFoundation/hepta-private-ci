import pathlib,tempfile,os,subprocess,hashlib,json,sys,time
site=pathlib.Path(tempfile.mkdtemp(prefix="hcsn-7149-root-positive."))
pathlib.Path("/tmp/hcsn-7149-root-positive-location").write_text(str(site))
elf=pathlib.Path(sys.argv[1]);phase=sys.argv[2]
cases=("root_broker_late_enrolls_publishes_and_recovers_original_current","root_initial_publication_uses_original_consumer_and_readonly_recovery","root_learning_public_registration_serves_retained_writer_and_recovers_history","root_q24_factory_v2_cold_reopens_original_files_with_new_root_and_writer")
roster=subprocess.check_output([str(elf),"--list"],text=True).splitlines()
names=[next(a.removesuffix(": test") for a in roster if a.endswith("::"+case+": test")) for case in cases]
binary=site/"agentd-tests";subprocess.run(["install","-m","0555",str(elf),str(binary)],check=True)
sha=subprocess.check_output(["sha256sum",str(binary)],text=True).split()[0]
img=next(x.split()[1] for x in subprocess.check_output(["docker","image","ls","--no-trunc","--format","{{.Repository}} {{.ID}}"],text=True).splitlines() if x.startswith("ubuntu "))
print("site",site,"elf_sha256",sha,"image",img,flush=True)
rows=[]
for i,name in enumerate(names):
 dirs=[site/(str(i)+"-"+x) for x in ("state","witness")]
 for path in dirs:path.mkdir(mode=0o700)
 command=["docker","run","--rm","--pull","never","--read-only","--network","none","--cap-drop","ALL","--security-opt","no-new-privileges","--user","0:0","--tmpfs","/tmp:rw,mode=1777","--tmpfs","/run:rw,mode=0755","--mount",f"type=bind,src={binary},dst=/opt/agentd-tests,readonly"]
 for capability in ("FSETID","SETPCAP","CHOWN","SETUID","SETGID","FOWNER","DAC_OVERRIDE"):command+=["--cap-add",capability]
 for path,role in zip(dirs,("state","witness")):
  for target in ("/original/"+role,"/protected/"+role):command+=["--mount",f"type=bind,src={path},dst={target}"]
 for k,v in {"HEPTA_HOST_AUTHORITY_QUALIFICATION_STATE_PARENT":"/protected/state","HEPTA_HOST_AUTHORITY_QUALIFICATION_SOURCE":"/original/state","HEPTA_Q24_FACTORY_WITNESS_BIND":"/protected/witness","HEPTA_Q24_FACTORY_WITNESS_SOURCE":"/original/witness"}.items():command+=["-e",k+"="+v]
 command += [img,"/bin/sh","-ec",'chown 0:0 /protected/state /protected/witness; chmod 0700 /protected/state /protected/witness; id; stat -c "%d:%i %u %a %n" /original/state /protected/state /original/witness /protected/witness; exec /opt/agentd-tests --exact "$1" --ignored --nocapture --test-threads=1',"qualification",name]
 t=time.monotonic()
 try:
  proc=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=190);log=proc.stdout.decode(errors="replace");rc=proc.returncode
 except subprocess.TimeoutExpired as exc:log=(exc.stdout or b"").decode(errors="replace");rc=124
 (site/f"case-{i}.log").write_text(log)
 rows.append({"name":name,"rc":rc,"elapsed_seconds":time.monotonic()-t,"ran":("running 1 test" in log),"passed":(rc==0 and "1 passed; 0 failed; 0 ignored" in log),"error":[l for l in log.splitlines() if l.startswith(("Error:","Caused by:"))]})
 print(rows[-1],flush=True)
 receipt={"image":img,"binary_sha256":sha,"phase":phase,"cases":rows};(site/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")

