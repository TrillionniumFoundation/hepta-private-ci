use super::*;
use codex_hepta_automation::TaskFlowError;
use pretty_assertions::assert_eq;

#[tokio::test]
async fn provider_operation_cannot_change_after_accepted_and_owner_reopen() {
    let fixture = Fixture::new();
    let (store, owner, effect, expected) = prepared_effect_store(&fixture).await;
    let (authority, signed, _authority_dir) = final_use(expected.clone(), "operation-binding");
    let key = ProviderEffectKey::for_logical_effect(
        &effect.destination_id,
        &format!("taskflow:{}:{}", effect.run_id, effect.step_id),
    )
    .expect("provider key");
    let accepted = ProviderEffectAck::new(
        key.clone(),
        effect.payload_digest.clone(),
        Sha256Digest::for_bytes(b"original-provider-operation"),
        ProviderEffectAckStatus::Accepted,
    );
    let replacement = ProviderEffectAck::new(
        key,
        effect.payload_digest.clone(),
        Sha256Digest::for_bytes(b"different-provider-operation"),
        ProviderEffectAckStatus::Completed,
    );
    let adapter = RecordingProviderEffectAdapter::new(
        ProviderEffectDispatch::Ack(accepted),
        ProviderEffectLookup::Ack(replacement),
    );
    let mut driver = ProviderEffectTaskFlowDriver::new(effect.destination_id.clone(), adapter)
        .expect("provider driver");
    let first = store
        .execute_authorized_taskflow_effect_async(
            &authority,
            &mut driver,
            AuthorizedEffectExecutionInput {
                intent: &effect,
                wire_payload: EFFECT_PAYLOAD,
                fence: &owner,
                signed_grant: &signed,
                expected_binding: &expected,
                command_id: "authorized-effect-dispatch",
                now_ms: 30,
            },
        )
        .await
        .expect("original accepted provider operation");
    assert_eq!(first.observation, Some(TaskFlowStepObservation::Indeterminate));
    store.close().await;
    let reopened = AutomationStore::open(&fixture.layout)
        .await
        .expect("reopen original owner");
    let pending = reopened
        .pending_authorized_taskflow_effects(8)
        .await
        .expect("pending original operation");
    let AuthorizedProviderEffectLookup::Observed(replacement) = driver.lookup(&pending[0]).await else {
        panic!("fixture supplies an actual same-key status ACK");
    };
    assert!(matches!(
        reopened
            .recover_authorized_taskflow_effect(
                &effect.run_id,
                &effect.step_id,
                effect.attempt,
                &owner,
                AuthorizedEffectRecovery::Observed(replacement),
                31,
            )
            .await,
        Err(AuthorizedEffectError::TaskFlow(TaskFlowError::Conflict(_)))
    ));
}
