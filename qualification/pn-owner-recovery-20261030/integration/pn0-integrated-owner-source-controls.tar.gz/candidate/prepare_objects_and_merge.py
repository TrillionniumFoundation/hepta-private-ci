from __future__ import annotations

import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/tmp/pn-convergence')
REPO = Path('/workspace/scratch/cedd7bc74ace/hepta-private-ci')
OUT = ROOT / 'hepta-isolated-candidate'
OBJECTS = OUT / 'objects'
INDEX = OUT / 'index'
OBJECTS.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env.update({
    'GIT_DIR': str(REPO / '.git'),
    'GIT_OBJECT_DIRECTORY': str(OBJECTS),
    'GIT_ALTERNATE_OBJECT_DIRECTORIES': str(REPO / '.git/objects'),
    'GIT_INDEX_FILE': str(INDEX),
})


def run(*args: str, data: bytes | None = None, check: bool = True):
    result = subprocess.run(['git', *args], cwd=OUT, env=env,
                            input=data, capture_output=True)
    if check and result.returncode:
        raise RuntimeError((args, result.returncode, result.stderr.decode()))
    return result


def oid(kind: str, data: bytes) -> str:
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def import_object(kind: str, data: bytes, expected: str) -> None:
    assert oid(kind, data) == expected, (kind, expected)
    written = run('hash-object', '-w', '-t', kind, '--stdin', data=data).stdout.decode().strip()
    assert written == expected, (expected, written)


imported = {}
cached = json.loads((ROOT / 'hepta-upstream-overlap-sources.json').read_text())['sources']
for source in cached:
    content = source['content'].encode()
    import_object('blob', content, source['sha'])
    imported[source['sha']] = len(content)
for file in sorted((OUT / 'inputs').glob('blob-batch-*.json')):
    for source in json.loads(file.read_text())['blobs']:
        content = base64.b64decode(source['content'])
        assert len(content) == source['size'], source['sha']
        import_object('blob', content, source['sha'])
        imported[source['sha']] = len(content)

tree_inputs = json.loads((OUT / 'inputs/complete-tree-inputs.json').read_text())
readme = tree_inputs['main_base_readme']
import_object('blob', base64.b64decode(readme['content']), readme['sha'])


def import_tree_inventory(inventory: dict) -> None:
    assert not inventory['truncated']
    directories = {'': {'sha': inventory['sha'], 'entries': []}}
    for entry in inventory['tree']:
        if entry['type'] == 'tree':
            directories[entry['path']] = {'sha': entry['sha'], 'entries': []}
    for entry in inventory['tree']:
        directory, _, name = entry['path'].rpartition('/')
        directories[directory]['entries'].append((name, entry))
    for directory in sorted(directories, key=lambda name: (name.count('/'), name), reverse=True):
        node = directories[directory]
        data = b''.join(
            f"{entry['mode']} {entry['type']} {entry['sha']}\t{name}".encode() + b'\0'
            for name, entry in node['entries']
        )
        actual = run('mktree', '-z', '--missing', data=data).stdout.decode().strip()
        assert actual == node['sha'], (directory, actual, node['sha'])


import_tree_inventory(tree_inputs['base'])
import_tree_inventory(tree_inputs['incoming'])


def import_commit(record: dict) -> None:
    assert record['verification']['reason'] == 'unsigned'
    header = f"tree {record['tree']['sha']}\n"
    header += ''.join(f"parent {parent['sha']}\n" for parent in record['parents'])
    # The published object ID verifies the reconstructed raw representation.
    # No candidate representation is written unless its SHA is the exact input SHA.
    offsets = ['+0000', '+0800', '-0700', '-0800', '+0100', '+0200', '+0900', '-0500', '-0400']
    endings = list(dict.fromkeys([record['message'], record['message'] + '\n']))
    for offset in offsets:
        current = header
        for role in ('author', 'committer'):
            person = record[role]
            stamp = int(datetime.datetime.fromisoformat(person['date'].replace('Z', '+00:00')).timestamp())
            current += f"{role} {person['name']} <{person['email']}> {stamp} {offset}\n"
        for message in endings:
            body = (current + '\n' + message).encode()
            if oid('commit', body) == record['sha']:
                import_object('commit', body, record['sha'])
                return
    raise RuntimeError('Cannot reproduce exact remote commit bytes: ' + record['sha'])


metadata = json.loads((ROOT / 'hepta-candidate-input-commits.json').read_text())
import_commit(metadata['incoming'])
import_commit(metadata['main'])
import_object('blob', b'', metadata['main_delta']['files'][0]['sha'])

new_head = '5e58c92ef3801a7b3cada3bb6af1229410ae989c'
local_fix = '4ff0803e32646b71df9c349d74fcedce05c2fae5'
incoming = '699e9020032dcb148ab504a7b0b932e85b05773f'
base_f874 = 'f874d948a38c119e57b1368adab79437956acd78'


def merge_tree(label: str, base: str, first: str, second: str) -> dict:
    command = ['merge-tree', '--write-tree', '--messages', '--merge-base=' + base, first, second]
    result = run(*command, check=False)
    (OUT / f'{label}-merge-tree.stdout').write_bytes(result.stdout)
    (OUT / f'{label}-merge-tree.stderr').write_bytes(result.stderr)
    text = result.stdout.decode()
    tree = text.splitlines()[0] if text else None
    record = {'label': label, 'command': ['git', *command], 'exit_code': result.returncode,
              'merge_base': base, 'parents': [first, second], 'tree': tree,
              'stdout': str(OUT / f'{label}-merge-tree.stdout'),
              'stderr': str(OUT / f'{label}-merge-tree.stderr')}
    (OUT / f'{label}-canonical.json').write_text(json.dumps(record, indent=2) + '\n')
    return record


def commit_tree(tree: str, parents: list[str], message: str) -> str:
    args = ['-c', 'commit.gpgSign=false', 'commit-tree', tree]
    for parent in parents:
        args += ['-p', parent]
    return run(*args, data=(message + '\n').encode()).stdout.decode().strip()


stage_a = merge_tree('A-parallel-and-fix', base_f874, new_head, local_fix)
assert stage_a['exit_code'] == 0, stage_a
stage_a['commit'] = commit_tree(stage_a['tree'], stage_a['parents'],
    'merge: preserve concurrent CI work with the frozen owner-recovery slice')
stage_a['remote_parent_mapping'] = [new_head, 'b8f5dd998a25d5157682249f39e800c9b6da0a8a']
(OUT / 'A-candidate.json').write_text(json.dumps(stage_a, indent=2) + '\n')
stage_b = merge_tree('B-fixed-upstream-unresolved', tree_inputs['base']['sha'],
                     stage_a['commit'], incoming)
report = {'object_directory': str(OBJECTS), 'alternate_object_directory': str(REPO / '.git/objects'),
          'temporary_index': str(INDEX), 'imported_blob_count': len(imported),
          'imported_blob_bytes': sum(imported.values()),
          'exact_remote_commits_imported': [incoming, metadata['main']['sha']],
          'stage_a': stage_a, 'stage_b_unresolved': stage_b,
          'refs_or_original_worktree_written': False, 'native_commands_run': False}
(OUT / 'construction-stage-ab.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
