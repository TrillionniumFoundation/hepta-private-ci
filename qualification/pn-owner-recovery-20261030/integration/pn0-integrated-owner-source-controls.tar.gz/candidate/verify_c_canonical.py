from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

out = Path('/tmp/pn-convergence/hepta-isolated-candidate')
repo = Path('/workspace/scratch/cedd7bc74ace/hepta-private-ci')
env = os.environ.copy()
env.update({'GIT_DIR': str(repo / '.git'), 'GIT_OBJECT_DIRECTORY': str(out / 'objects'),
            'GIT_ALTERNATE_OBJECT_DIRECTORIES': str(repo / '.git/objects'),
            'GIT_INDEX_FILE': str(out / 'canonical-main-index')})


def git(*args, data=None, check=True):
    result = subprocess.run(['git', *args], cwd=out, env=env, input=data, capture_output=True)
    if check and result.returncode:
        raise RuntimeError((args, result.returncode, result.stderr.decode()))
    return result


def object_id(kind, data):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def import_object(kind, data, expected):
    assert object_id(kind, data) == expected
    actual = git('hash-object', '-w', '-t', kind, '--stdin', data=data).stdout.decode().strip()
    assert actual == expected


def import_inventory(inventory):
    assert inventory['truncated'] is False
    directories = {'': {'sha': inventory['sha'], 'entries': []}}
    for entry in inventory['tree']:
        if entry['type'] == 'tree':
            directories[entry['path']] = {'sha': entry['sha'], 'entries': []}
    for entry in inventory['tree']:
        directory, _, name = entry['path'].rpartition('/')
        directories[directory]['entries'].append((name, entry))
    for path in sorted(directories, key=lambda p: (p.count('/'), p), reverse=True):
        node = directories[path]
        data = b''.join(f"{entry['mode']} {entry['type']} {entry['sha']}\t{name}".encode() + b'\0'
                        for name, entry in node['entries'])
        actual = git('mktree', '-z', '--missing', data=data).stdout.decode().strip()
        assert actual == node['sha'], (path, actual, node['sha'])
    return len(directories)


def import_commit(record):
    assert record['verification']['reason'] == 'unsigned'
    header = f"tree {record['tree']['sha']}\n"
    header += ''.join(f"parent {parent['sha']}\n" for parent in record['parents'])
    for offset in ['+0000', '+0800', '-0700', '-0800', '+0100', '+0200', '+0900', '-0500', '-0400']:
        current = header
        for role in ('author', 'committer'):
            person = record[role]
            stamp = int(datetime.datetime.fromisoformat(person['date'].replace('Z', '+00:00')).timestamp())
            current += f"{role} {person['name']} <{person['email']}> {stamp} {offset}\n"
        for message in dict.fromkeys([record['message'], record['message'] + '\n']):
            raw = (current + '\n' + message).encode()
            if object_id('commit', raw) == record['sha']:
                import_object('commit', raw, record['sha'])
                return
    raise RuntimeError('Exact original commit bytes could not be reconstructed')


inputs = json.loads((out / 'inputs/C-main-canonical-inputs.json').read_text())
counts = {key: import_inventory(inputs[key]) for key in ('base_tree', 'main_tree')}
import_commit(inputs['base_commit'])
b = json.loads((out / 'B-candidate.json').read_text())
c = json.loads((out / 'C-candidate.json').read_text())
assert c['parents'][0] == b['commit']
base = inputs['base_commit']['sha']
command = ['merge-tree', '--write-tree', '--messages', '--merge-base=' + base, *c['parents']]
result = git(*command, check=False)
(out / 'C-canonical-recheck.stdout').write_bytes(result.stdout)
(out / 'C-canonical-recheck.stderr').write_bytes(result.stderr)
tree = result.stdout.decode().splitlines()[0] if result.stdout else None
receipt = {'command': ['git', *command], 'exit_code': result.returncode, 'merge_base': base,
           'main_base_tree': inputs['base_tree']['sha'], 'main_head_tree': inputs['main_tree']['sha'],
           'complete_api_trees_not_truncated': True, 'imported_exact_tree_counts': counts,
           'original_base_commit_sha_verified': True, 'ordered_parents': c['parents'],
           'canonical_tree': tree, 'existing_C_tree': c['tree'],
           'canonical_equals_previously_constructed_C': result.returncode == 0 and tree == c['tree'],
           'C_initial_method_record_preserved': True,
           'C_commit_unchanged': c['commit'], 'native_tests_or_builds': False,
           'existing_worktree_or_refs_modified': False,
           'stdout': str(out / 'C-canonical-recheck.stdout'), 'stderr': str(out / 'C-canonical-recheck.stderr')}
(out / 'C-canonical-recheck.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
assert result.returncode == 0 and tree == c['tree']
