from __future__ import annotations

import ast
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tomllib

ROOT = Path('/tmp/pn-convergence')
REPO = Path('/workspace/scratch/cedd7bc74ace/hepta-private-ci')
OUT = ROOT / 'hepta-isolated-candidate'
env = os.environ.copy()
env.update({'GIT_DIR': str(REPO / '.git'),
            'GIT_OBJECT_DIRECTORY': str(OUT / 'objects'),
            'GIT_ALTERNATE_OBJECT_DIRECTORIES': str(REPO / '.git/objects'),
            'GIT_INDEX_FILE': str(OUT / 'index')})
identity = OUT / 'candidate-commit-time.json'
if identity.exists():
    timestamp = json.loads(identity.read_text())['timestamp']
else:
    timestamp = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat()
    identity.write_text(json.dumps({'timestamp': timestamp}, indent=2) + '\n')
env['GIT_AUTHOR_DATE'] = timestamp
env['GIT_COMMITTER_DATE'] = timestamp


def git(*args: str, data: bytes | None = None, check: bool = True):
    result = subprocess.run(['git', *args], cwd=OUT, env=env, input=data, capture_output=True)
    if check and result.returncode:
        raise RuntimeError((args, result.returncode, result.stderr.decode()))
    return result


def show(ref: str, path: str) -> bytes:
    return git('show', ref + ':' + path).stdout


def blob(ref: str, path: str) -> str:
    return git('rev-parse', ref + ':' + path).stdout.decode().strip()


def store_blob(data: bytes) -> str:
    return git('hash-object', '-w', '--stdin', data=data).stdout.decode().strip()


def make_commit(tree: str, parents: list[str], message: str) -> str:
    args = ['-c', 'commit.gpgSign=false', 'commit-tree', tree]
    for parent in parents:
        args += ['-p', parent]
    return git(*args, data=(message + '\n').encode()).stdout.decode().strip()


stage_a = json.loads((OUT / 'A-candidate.json').read_text())
unresolved = json.loads((OUT / 'B-fixed-upstream-unresolved-canonical.json').read_text())
assert unresolved['exit_code'] == 1
paths = {
    '.github/workflows/hepta-pon-native-pair.yml': 'preserve-current-pair',
    'codex-rs/hepta-contracts/src/final_use.rs': 'union-modules',
    'codex-rs/hepta-agentd/BUILD.bazel': 'preserve-stronger-parallel-fixture',
    'defs.bzl': 'preserve-stronger-parallel-fixture',
}
unmerged_paths = set(re.findall(r'^\d{6} [0-9a-f]{40} [123]\t(.+)$',
                               Path(unresolved['stdout']).read_text(), re.M))
assert unmerged_paths == set(paths), unmerged_paths

resolutions = []
resolved = {}
for path, policy in paths.items():
    original = show(unresolved['tree'], path)
    current = show(stage_a['commit'], path)
    incoming = show('699e9020032dcb148ab504a7b0b932e85b05773f', path)
    if policy == 'union-modules':
        pattern = re.compile(rb'^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n', re.M | re.S)
        matches = list(pattern.finditer(original))
        assert len(matches) == 1
        ours, theirs = matches[0].group(1), matches[0].group(2)
        assert ours.strip() == b'#[path = "final_use_ml_dsa65_v2.rs"]\nmod ml_dsa65_v2;'
        assert theirs.strip() == b'#[path = "final_use_live_owner.rs"]\nmod live_owner;'
        result = pattern.sub(lambda _: theirs + ours, original)
        assert result.count(b'mod live_owner;') == result.count(b'mod ml_dsa65_v2;') == 1
        assert result.count(b'.ensure_live_state(state)?;') == 10
    else:
        result = current
    assert b'<<<<<<<' not in result and b'>>>>>>>' not in result
    destination = OUT / 'resolved-files' / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(result)
    patch = ''.join(difflib.unified_diff(original.decode().splitlines(True),
                                        result.decode().splitlines(True),
                                        fromfile='a/' + path, tofile='b/' + path))
    patch_name = {'preserve-current-pair': 'resolution-pair-source.patch',
                  'union-modules': 'resolution-final-use.patch'}.get(policy)
    if patch_name:
        (OUT / patch_name).write_text(patch)
    resolved[path] = result
    resolutions.append({'path': path, 'policy': policy,
                        'canonical_conflict_blob': blob(unresolved['tree'], path),
                        'first_parent_blob': blob(stage_a['commit'], path),
                        'incoming_blob': blob('699e9020032dcb148ab504a7b0b932e85b05773f', path),
                        'resolved_blob': store_blob(result),
                        'resolved_sha256': hashlib.sha256(result).hexdigest(),
                        'resolved_file': str(destination),
                        'patch': patch_name, 'unresolved_to_resolved_patch': patch})

# The parallel fixture implementation has the same required mapping and closure
# substitution, plus an explicit unknown-stem rejection that the incoming copy lacks.
build_path = 'codex-rs/hepta-agentd/BUILD.bazel'
def fixture_map(data: bytes):
    module = ast.parse(data.decode())
    values = [keyword.value for node in ast.walk(module) if isinstance(node, ast.Call)
              for keyword in node.keywords if keyword.arg == 'integration_test_dependency_replacements']
    assert len(values) == 1
    return ast.literal_eval(values[0])
assert fixture_map(resolved[build_path]) == fixture_map(show('699e9020032dcb148ab504a7b0b932e85b05773f', build_path))
defs = resolved['defs.bzl'].decode()
module = ast.parse(defs)
function = next(node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == 'codex_rust_crate')
arguments = [arg.arg for arg in function.args.args]
assert len(arguments) == len(set(arguments))
assert arguments.count('integration_test_dependency_replacements') == 1
assert 'Unknown integration test dependency replacement: ' in defs
assert defs.count('deps = integration_deps,') == 3
assert 'normal_dev = True,' in defs
bazel_patch = ''.join(row['unresolved_to_resolved_patch'] for row in resolutions
                      if row['policy'] == 'preserve-stronger-parallel-fixture')
(OUT / 'resolution-bazel-semantic-overlap.patch').write_text(bazel_patch)
for row in resolutions:
    row.pop('unresolved_to_resolved_patch')

git('read-tree', unresolved['tree'])
for row in resolutions:
    git('update-index', '--add', '--cacheinfo', '100644,' + row['resolved_blob'] + ',' + row['path'])
stage_b_tree = git('write-tree').stdout.decode().strip()
stage_b_parents = [stage_a['commit'], '699e9020032dcb148ab504a7b0b932e85b05773f']
stage_b_commit = make_commit(stage_b_tree, stage_b_parents,
    'merge: integrate pinned upstream remediation while retaining owner and PQ boundaries')
stage_b = {'label': 'B-fixed-upstream-resolved', 'tree': stage_b_tree, 'commit': stage_b_commit,
           'parents': stage_b_parents, 'canonical_conflict_tree': unresolved['tree'],
           'resolution_count': 4, 'resolution': resolutions,
           'semantic_overlap': {'same_fixture_mapping_verified_by_ast': True,
                                'unknown_test_stem_rejection_retained': True,
                                'single_parameter_definition': True,
                                'three_harness_dependency_substitutions_retained': True,
                                'parallel_files_retained_byte_for_byte': True}}
(OUT / 'B-candidate.json').write_text(json.dumps(stage_b, indent=2) + '\n')

# Current main is exactly one README-only commit over its verified older base.
# The B candidate still has the identical base README, so the complete incoming
# single-file delta applies without a runtime edit or textual conflict.
metadata = json.loads((ROOT / 'hepta-candidate-input-commits.json').read_text())
main_delta = metadata['main_delta']
assert main_delta['ahead_by'] == 1 and main_delta['behind_by'] == 0
assert [item['filename'] for item in main_delta['files']] == ['README.md']
readme_base = json.loads((OUT / 'inputs/complete-tree-inputs.json').read_text())['main_base_readme']['sha']
assert blob(stage_b_commit, 'README.md') == readme_base
readme_head = main_delta['files'][0]['sha']
assert store_blob(b'') == readme_head
git('read-tree', stage_b_tree)
git('update-index', '--add', '--cacheinfo', '100644,' + readme_head + ',README.md')
stage_c_tree = git('write-tree').stdout.decode().strip()
stage_c_parents = [stage_b_commit, '732e934ba496d90fbe042b8d41d479ef901643e5']
stage_c_commit = make_commit(stage_c_tree, stage_c_parents,
    'merge: retain the pinned main README cleanup in the integrated candidate')
stage_c = {'label': 'C-current-main-readme', 'tree': stage_c_tree, 'commit': stage_c_commit,
           'parents': stage_c_parents, 'method': 'Apply the complete API-verified one-file main delta after matching the original README blob; no full merge-tree for this layer.',
           'main_base_commit': main_delta['merge_base_commit']['sha'],
           'readme_base_blob': readme_base, 'readme_result_blob': readme_head,
           'main_changed_paths': ['README.md'], 'unexpected_runtime_changes': False}
assert git('diff-tree', '--no-commit-id', '--name-only', '-r', stage_b_tree, stage_c_tree).stdout.decode().splitlines() == ['README.md']
(OUT / 'C-candidate.json').write_text(json.dumps(stage_c, indent=2) + '\n')


def entries(ref: str):
    result = {}
    for line in git('ls-tree', '-r', '-z', ref).stdout.split(b'\0'):
        if not line:
            continue
        info, name = line.split(b'\t', 1)
        mode, kind, oid = info.decode().split()
        result[name.decode()] = {'mode': mode, 'type': kind, 'blob': oid}
    return result


old = entries('4ff0803e32646b71df9c349d74fcedce05c2fae5')
final = entries(stage_c_tree)
prefixes = [
    'codex-rs/hepta-automation/',
    'codex-rs/hepta-agentd/src/automation_effect_host',
    'codex-rs/hepta-infer-worker-host/src/final_use_authorizer',
    'codex-rs/hepta-contracts/src/final_use_ml_dsa65',
    'codex-rs/hepta-contracts/src/provider_effect',
    'codex-rs/hepta-learning-artifacts/profiles/smollm2-public-initial-v2.execution-sources-',
    'scripts/hepta_smollm_execution_source',
    'scripts/test_hepta_smollm_execution_source',
    'qualification/pn-owner-recovery-20261030/',
]
exact_paths = ['.github/workflows/hepta-pon-native-pair.yml', '.github/workflows/hepta-final-use-pq.yml',
               '.github/workflows/hepta-neural-study-v1.yml', '.github/workflows/hepta-public-initial-v2.yml',
               'scripts/hepta_final_use_pq_ci.py', 'scripts/test_hepta_final_use_pq_ci.py',
               'scripts/hepta_smollm_public_initial_v2.py']
preserved = []
for path, item in old.items():
    if path in exact_paths or any(path.startswith(prefix) for prefix in prefixes):
        assert final.get(path) == item, path
        preserved.append({'path': path, **item})
evidence_six = git('diff-tree', '--no-commit-id', '--name-only', '-r',
                   '70b5cc25ec904fa53f1e0f9abd8ea776b97e0114', '4ff0803e32646b71df9c349d74fcedce05c2fae5').stdout.decode().splitlines()
assert len(evidence_six) == 6 and all(path.startswith('qualification/') for path in evidence_six)
assert all(old[path] == final[path] for path in evidence_six)

# These are syntax/source-integrity checks only, not native or behavioral tests.
for path in ('codex-rs/Cargo.lock', 'codex-rs/Cargo.toml'):
    tomllib.loads(show(stage_c_commit, path).decode())
def unique_json(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result, ('duplicate JSON key', key)
        result[key] = value
    return result
json.loads(show(stage_c_commit, 'MODULE.bazel.lock'), object_pairs_hook=unique_json)
assert b'VISIBILITY=PUBLIC' not in show(stage_c_commit, '.bazelrc')
assert b'hepta-private-ci.git' in show(stage_c_commit, '.bazelrc')
assert b'O_NOFOLLOW | libc::O_NONBLOCK' in show(stage_c_commit, 'codex-rs/hepta-infer-worker-host/src/final_use_authorizer.rs')


def diff_record(label: str, parent: str, child: str):
    raw = git('diff-tree', '--no-commit-id', '-r', '--no-renames', '--numstat', parent, child).stdout
    rows = []
    for line in raw.decode().splitlines():
        add, remove, path = line.split('\t', 2)
        rows.append({'path': path, 'binary': add == '-',
                     'insertions': None if add == '-' else int(add),
                     'deletions': None if remove == '-' else int(remove)})
    record = {'label': label, 'parent': parent, 'child': child, 'paths': rows,
              'path_count': len(rows), 'text_insertions': sum(row['insertions'] or 0 for row in rows),
              'text_deletions': sum(row['deletions'] or 0 for row in rows),
              'binary_files': sum(row['binary'] for row in rows)}
    (OUT / f'{label}-diff-paths.json').write_text(json.dumps(record, indent=2) + '\n')
    (OUT / f'{label}-diff-stat.txt').write_bytes(git('diff-tree', '--no-commit-id', '-r', '--no-renames', '--stat', parent, child).stdout)
    return {key: value for key, value in record.items() if key != 'paths'}


diffs = [diff_record('A', stage_a['parents'][0], stage_a['commit']),
         diff_record('B', stage_b_parents[0], stage_b_commit),
         diff_record('C', stage_c_parents[0], stage_c_commit),
         diff_record('complete-vs-live-5e58', stage_a['parents'][0], stage_c_commit),
         diff_record('complete-vs-local-4ff', '4ff0803e32646b71df9c349d74fcedce05c2fae5', stage_c_commit)]
for label, parent, child in [('A', stage_a['parents'][0], stage_a['commit']), ('B', stage_b_parents[0], stage_b_commit), ('C', stage_c_parents[0], stage_c_commit)]:
    checked = git('diff-tree', '--check', '-r', parent, child, check=False)
    (OUT / f'{label}-diff-check.txt').write_bytes(checked.stdout + checked.stderr)
    # Historical evidence can retain original whitespace. Record the exact result
    # rather than changing original evidence or manufacturing a clean gate.

preservation = {'baseline': '4ff0803e32646b71df9c349d74fcedce05c2fae5', 'candidate': stage_c_commit,
                'critical_paths_preserved': preserved, 'critical_path_count': len(preserved),
                'six_evidence_paths_preserved': evidence_six,
                'syntax_checks': ['Cargo.toml TOML', 'Cargo.lock TOML', 'MODULE.bazel.lock JSON without duplicate keys', 'Bazel replacement map AST equality and unique parameter'],
                'native_tests_or_builds': False,
                'caller_proof_followup': 'Pending independently owned source-pin and helper no-op regression work; old caller-proof pins are not claimed valid for this FinalUse union.'}
(OUT / 'preserved-source-blobs.json').write_text(json.dumps(preservation, indent=2) + '\n')
summary = {'object_directory': str(OUT / 'objects'), 'alternate_object_directory': str(REPO / '.git/objects'),
           'index': str(OUT / 'index'), 'stage_a': stage_a, 'stage_b': stage_b, 'stage_c': stage_c,
           'diffs': diffs, 'critical_path_count': len(preserved),
           'source_refs_or_original_worktree_changed': False, 'native_tests_or_builds_run': False,
           'candidate_qualified': False, 'caller_proof_followup_pending': True}
(OUT / 'candidate-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'A': {'commit': stage_a['commit'], 'tree': stage_a['tree']},
                  'B': {'commit': stage_b_commit, 'tree': stage_b_tree},
                  'C': {'commit': stage_c_commit, 'tree': stage_c_tree},
                  'diffs': diffs, 'critical_paths_preserved': len(preserved)}, indent=2))
