from pathlib import Path
import json
import os
import subprocess

candidate = Path('/tmp/pn-convergence/hepta-isolated-candidate')
checkout = Path('/workspace/scratch/cedd7bc74ace/hepta-integration-candidate-c')
metadata = candidate / 'checkout-git'
shared = Path('/workspace/scratch/cedd7bc74ace/hepta-private-ci')
stage = json.loads((candidate / 'C-candidate.json').read_text())
assert not checkout.exists(), 'Refuse to overwrite an existing checkout'
assert not metadata.exists(), 'Refuse to overwrite temporary Git metadata'
checkout.mkdir()
subprocess.run(['git', 'init', '--bare', '--initial-branch=isolated', str(metadata)], check=True, capture_output=True)
subprocess.run(['git', '--git-dir=' + str(metadata), 'config', 'core.bare', 'false'], check=True)
subprocess.run(['git', '--git-dir=' + str(metadata), 'config', 'core.worktree', str(checkout)], check=True)
(metadata / 'objects/info/alternates').write_text(str(candidate / 'objects') + '\n' + str(shared / '.git/objects') + '\n')
(metadata / 'HEAD').write_text(stage['commit'] + '\n')
(checkout / '.git').write_text('gitdir: ' + str(metadata) + '\n')
env = os.environ.copy()
for name in ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_INDEX_FILE'):
    env.pop(name, None)
subprocess.run(['git', 'read-tree', stage['commit']], cwd=checkout, env=env, check=True)
subprocess.run(['git', 'checkout-index', '--all', '--force'], cwd=checkout, env=env, check=True)
head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=checkout, env=env, check=True, text=True, capture_output=True).stdout.strip()
status = subprocess.run(['git', 'status', '--porcelain=v1'], cwd=checkout, env=env, check=True, text=True, capture_output=True).stdout
assert head == stage['commit'] and not status, (head, status)
shared_head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=shared, env=env, check=True, text=True, capture_output=True).stdout.strip()
shared_status = subprocess.run(['git', 'status', '--porcelain=v1'], cwd=shared, env=env, check=True, text=True, capture_output=True).stdout
assert shared_head == '4ff0803e32646b71df9c349d74fcedce05c2fae5' and not shared_status
receipt = {'checkout': str(checkout), 'git_metadata': str(metadata), 'head': head, 'tree': stage['tree'], 'status': status,
           'shared_head_unchanged': shared_head, 'shared_status': shared_status,
           'environment_required': 'None. The checkout .git file points at its independent temporary metadata; no shared worktree/ref registration.',
           'object_alternates': [str(candidate / 'objects'), str(shared / '.git/objects')],
           'native_tests_or_builds': False}
(candidate / 'checkout-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
