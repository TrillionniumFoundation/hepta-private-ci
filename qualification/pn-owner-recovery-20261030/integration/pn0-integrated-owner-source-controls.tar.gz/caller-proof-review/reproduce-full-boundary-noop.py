import hashlib
import importlib.util
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path("/workspace/scratch/cedd7bc74ace/hepta-integration-candidate-c")
EVIDENCE = Path("/tmp/pn-convergence/caller-proof-review")
SCRIPT = ROOT / "scripts/verify_hepta_callers.py"
spec = importlib.util.spec_from_file_location("verify_hepta_callers", SCRIPT)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

with tempfile.TemporaryDirectory(prefix="hepta-live-owner-full-boundary-") as temporary:
    fixture = Path(temporary)
    sources = module._source_files(ROOT, ("codex-rs",))
    copied_bytes = 0
    for source in sources:
        if source.is_symlink():
            raise AssertionError("the real verifier forbids Rust source symlinks")
        target = fixture / source.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        copied_bytes += target.stat().st_size
    shutil.copyfile(ROOT / "CALLERS.toml", fixture / "CALLERS.toml")
    baseline = module.verify(fixture)
    (EVIDENCE / "full-boundary-provisional-positive.json").write_text(
        json.dumps(baseline, indent=2) + "\n"
    )
    relative = "codex-rs/hepta-contracts/src/final_use_live_owner.rs"
    path = fixture / relative
    original = path.read_text()
    code = module._strip_rust_non_code(original)
    marker = "pub(super) fn ensure_live_state<'state>"
    if code.count(marker) != 1:
        raise AssertionError("must mutate the unique real retained-owner entry")
    brace = code.index("{", code.index(marker))
    end = module._matching_delimiter(code, brace, "{", "}")
    if end is None:
        raise AssertionError("actual delegate body must be balanced")
    mutated = original[:brace] + "{ Ok(state) }" + original[end + 1 :]
    if mutated == original:
        raise AssertionError("the adversarial source must actually change")
    path.write_text(mutated)
    (EVIDENCE / "mutated-live-owner.rs").write_text(mutated)
    refused = False
    try:
        observed = module.verify(fixture)
    except module.VerificationFailure as error:
        refused = True
        observed = {"rejected": str(error)}
    (EVIDENCE / "full-boundary-noop-observation.json").write_text(
        json.dumps(observed, indent=2) + "\n"
    )
    record = {
        "phase": "original_full_45_boundary_verifier_real_live_owner_noop",
        "production_rust_commit": "74ed7adced1a9e5f1c0499f73c7e784d8b6782c5",
        "manifest_scope": "Only legitimate C final_use.rs SHA refrozen; the three delegated owner files are still unpinned.",
        "validator_sha256": hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
        "manifest_sha256": hashlib.sha256((fixture / "CALLERS.toml").read_bytes()).hexdigest(),
        "copied_rust_files": len(sources),
        "copied_rust_bytes": copied_bytes,
        "baseline_status": baseline["status"],
        "baseline_boundaries": len(baseline["boundaries"]),
        "mutated_source": relative,
        "original_sha256": hashlib.sha256(original.encode()).hexdigest(),
        "mutated_sha256": hashlib.sha256(mutated.encode()).hexdigest(),
        "mutated_status": observed.get("status"),
        "mutated_boundaries": len(observed.get("boundaries", [])),
        "required_behavior": "refuse the changed real retained-owner delegate",
        "observed_refusal": refused,
        "candidate_source_mutated": False,
    }
    (EVIDENCE / "full-boundary-noop-red.json").write_text(
        json.dumps(record, indent=2) + "\n"
    )
    print(json.dumps(record), flush=True)
    if not refused:
        raise AssertionError("original verifier accepted the real no-op live-owner delegate")
