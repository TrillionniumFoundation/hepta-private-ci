import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

OUT = Path('/tmp/pn-convergence/windows-roster-fix')
REPO = Path('/workspace/scratch/cedd7bc74ace/hepta-integration-candidate-c')
WORKFLOW = '.github/workflows/hepta-windows-delete-boundary.yml'
SOURCE = 'daa0209d9235ff6a6ff06d130e7f03b1253e9fbf'
GROUPS = ('private-owner-descriptor', 'original-final-use-windows')
NEW_NAMES = {
    GROUPS[0]: 'parent_anchor::tests::actual_canonical_drive_prefix_preserves_held_ancestry_and_store_creation',
    GROUPS[1]: 'final_use::windows_owner::tests::native_retained_owner_drift_fences_preclaimed_entries_and_stays_failed',
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def embedded_checker(data):
    lines = data.splitlines(keepends=True)
    marker = b'          cat > "$RUNNER_TEMP/windows-delete-boundary/check.py" <<\'PY\'\n'
    start = lines.index(marker) + 1
    end = lines.index(b'          PY\n', start)
    assert all(line.startswith(b'          ') for line in lines[start:end])
    return b''.join(line[10:] for line in lines[start:end])


def selectors(code):
    tree = ast.parse(code)
    assignments = {node.targets[0].id: ast.literal_eval(node.value)
                   for node in tree.body if isinstance(node, ast.Assign)
                   and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
                   and node.targets[0].id in ('owner_selectors', 'store_selectors')}
    return {GROUPS[0]: assignments['owner_selectors'],
            GROUPS[1]: assignments['store_selectors'][GROUPS[1]]}


phase = sys.argv[1]
assert phase in ('red', 'green')
archive = OUT / 'windows-daa-source-head-original.zip'
assert digest(archive.read_bytes()) == 'af2c881eb76d3070d8bc6b51188d81a083166aeb1cc315d8ee9b8136cd8d926a'
original = OUT / 'original'
original.mkdir(exist_ok=True)
names = ['check.py', 'source-before.json', 'source-after.json', 'result.json', 'result-v2.json', 'result-v3.json',
         'broad-identity-delete.json', 'legacy-delete-boundary.json', 'command-runner-terminal.json']
names += [group + suffix for group in GROUPS for suffix in ('.log', '.json')]
with zipfile.ZipFile(archive) as payload:
    for name in names:
        data = payload.read(name)
        destination = original / name
        if destination.exists():
            assert destination.read_bytes() == data
        else:
            destination.write_bytes(data)
source_before = json.loads((original / 'source-before.json').read_text())
source_after = json.loads((original / 'source-after.json').read_text())
assert source_before == source_after
assert source_before['source_sha'] == source_before['tested_sha'] == SOURCE
assert source_before['lane'] == 'source-head'
assert source_before['native'] == {'runner': 'windows-latest', 'runner_arch': 'X64', 'target': 'x86_64-pc-windows-msvc'}

baseline_workflow = subprocess.run(['git', 'show', SOURCE + ':' + WORKFLOW], cwd=REPO,
                                   capture_output=True, check=True).stdout
original_checker = (original / 'check.py').read_bytes()
assert embedded_checker(baseline_workflow) == original_checker, 'Original artifact checker must equal exact D workflow heredoc'
if phase == 'red':
    assert (REPO / WORKFLOW).read_bytes() == baseline_workflow
    (OUT / 'workflow.before.yml').write_bytes(baseline_workflow)
    code = original_checker
else:
    code = embedded_checker((REPO / WORKFLOW).read_bytes())
    (OUT / 'workflow.after.yml').write_bytes((REPO / WORKFLOW).read_bytes())
checker = OUT / (phase + '-check.py')
checker.write_bytes(code)
rosters = selectors(code)
old_rosters = selectors(original_checker)
assert [len(old_rosters[group]) for group in GROUPS] == [40, 7]
if phase == 'green':
    for group in GROUPS:
        assert tuple(name for name in rosters[group] if name != NEW_NAMES[group]) == old_rosters[group]
        assert set(rosters[group]) - set(old_rosters[group]) == {NEW_NAMES[group]}
    assert [len(rosters[group]) for group in GROUPS] == [41, 8]

records = []
for group in GROUPS:
    observed = json.loads((original / (group + '.json')).read_text())
    raw = (original / (group + '.log')).read_bytes()
    assert digest(raw) == observed['log_sha256']
    assert observed['returncode'] == observed['logging_returncode'] == 0
    assert observed['observed_failed_tests'] == 0 and observed['status'] == 'failed'
    case_root = OUT / phase / group
    logs = case_root / 'windows-delete-boundary'
    logs.mkdir(parents=True, exist_ok=True)
    (logs / (group + '.log')).write_bytes(raw)
    minimum = observed['minimum_tests'] if phase == 'red' else len(rosters[group])
    actual_codes = f"{observed['returncode']} {observed['logging_returncode']}"
    command = ['python3', str(checker), 'tests', group, str(minimum), actual_codes]
    env = os.environ.copy()
    env['RUNNER_TEMP'] = str(case_root)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    result = subprocess.run(command, cwd=REPO, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    console = case_root / 'checker-output.log'
    console.write_bytes(result.stdout)
    actual = json.loads((logs / (group + '.json')).read_text())
    expected_exit = 1 if phase == 'red' else 0
    assert result.returncode == expected_exit, (group, result.returncode, result.stdout.decode())
    if phase == 'red':
        assert actual == observed, 'Replay must reproduce the original receipt exactly as data'
    else:
        assert actual['status'] == 'passed'
        for field in ('returncode', 'logging_returncode', 'observed_passed_tests', 'observed_failed_tests', 'log_sha256'):
            assert actual[field] == observed[field]
        assert actual['minimum_tests'] == len(rosters[group])
        assert actual.get('owner_supported') is False and actual.get('power_loss_qualified') is False
    records.append({'group': group, 'command': command, 'cwd': str(REPO),
                    'RUNNER_TEMP': str(case_root), 'exit_code': result.returncode,
                    'observed_original_process_returncodes': [observed['returncode'], observed['logging_returncode']],
                    'original_log_sha256': digest(raw), 'receipt': actual,
                    'original_receipt_reproduced_exactly': phase == 'red',
                    'console_log': str(console)})
report = {'phase': phase, 'source_before': source_before,
          'original_checker_equals_D_workflow_heredoc': True,
          'original_checker_sha256': digest(original_checker), 'replayed_checker_sha256': digest(code),
          'roster_counts': {group: len(rosters[group]) for group in GROUPS},
          'records': records,
          'native_windows_execution_performed_locally': False,
          'original_artifact_modified': False,
          'aggregate_original_status': json.loads((original / 'result.json').read_text())['status'],
          'scope': 'Execute the actual embedded checker over exact original artifact tee bytes and observed process/logging return codes; this is a receipt replay, not a new Windows native run or aggregate workflow success.'}
write_json(OUT / (phase + '-replay.json'), report)
print(json.dumps({'phase': phase, 'counts': report['roster_counts'], 'exit_codes': [record['exit_code'] for record in records],
                  'artifact_tee_bytes_and_actual_returncodes': True, 'original_aggregate_status_unchanged': report['aggregate_original_status']}, indent=2))
