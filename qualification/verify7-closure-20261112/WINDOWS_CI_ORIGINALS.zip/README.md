# VERIFY-7 source-bound Windows and artifact readback

Read-only continuation of #6061/#6102/#6103/#6110. No dispatch, rerun,
repository edit, external comment, actor/checker/model execution or SQL query.

## Newly completed original Windows jobs

| Source | Original job | Executed tests |
| --- | --- | ---: |
| packaging `4a08232dbf90f4cbfa995dcaa29607cbd097762e` | 130989017075 | 242 |
| auditor `3ace899a1c61bfda1a46074a5dacc655dda22b09` | 130990205982 | 255 |
| attribution `b4717e6db7dbb933abb473752ca8f6223638e8a8` | 130990511643 | 260 |

All three jobs succeeded. Exact source refs, test totals and complete controlled
132-trajectory study summaries are in the full original decoded logs. Neither
new auditor log contains a matched skipped/failed/error test line; both print
CONSISTENT_COMPLETE_RECORDS. The attribution command runs successfully and its
numerical report is written to an artifact rather than printed.

`WINDOWS_AUDIT.json` binds decoded UTF-8 log bytes and original scalar lines.
The `.original.json` files retain the tool response containers; decoded `.log`
bytes were written from their exact returned strings, preserving CRLF/BOM.
These repeated fixture studies add zero independently adjudicated business tasks.

## Original remote numerical artifact now obtained

`verify6-windows-b4717e6.zip` is original artifact **13917798219**, **482,662
bytes**, SHA-256 **86681744db3ef70598929efdb5e0934c5d564f19b7c9cb5e18d0ff2c4bc156a4**.
It matches the provider-reported digest and size and contains 277 unique members
with valid CRCs. Its original source-commit.txt is exactly `b4717e6db7dbb933abb473752ca8f6223638e8a8`.

The extracted audit and attribution reports are in `windows-artifact-reports/`.
Seven saved-input hashes in the audit match the corresponding archived bytes;
the attribution's embedded audit equals that saved original audit. The actual
remote numerical report has 60 probes and paid conditional resolution increment
1/120 in train/cal/confirm, zero under the declared shift. This closes the earlier
missing remote numerical artifact readback. `ARTIFACT_REVIEW.json` records the
independent saved-byte checks. No database was opened and no model/actor reran.
No signed temporary download URL is retained.

## Remaining direct-job observations

All three VERIFY source heads now pass macOS and Windows. Ubuntu remains queued.
The three newer blocking workflows have queued scope-selection/blob-policy jobs
and successful Codespell jobs. Packaging's blocking workflow still returned zero
jobs. Architecture source/base jobs remain queued. The run-list wrapper continues
to report VERIFY runs as queued even after Windows/macOS completion; retain both
interfaces and use direct jobs for per-job status. No new failure is observed.

No queued job is a pass. Whole-repository CI and scientific adoption remain open.
Source independence, authentic prospective terminal business adjudication,
physical costs and held-out policy/calibration benefits are not established by
these fixture repetitions. HOLD / NoUpdate / NONE.
