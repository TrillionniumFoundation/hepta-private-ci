# Frozen prospective provider-property observations

Twelve genuinely nonterminal GitHub Actions jobs were frozen before any
follow-up terminal read. All were queued at the initial capture. The roster
comes from 14 eligible nonterminal jobs across eight actual source-bound runs;
initially terminal jobs in the same raw provider responses were excluded.
Selection prioritizes in_progress (none available), then VERIFY/blob/architecture/
scope jobs, with run/job identity ties. This is convenience sampling, not an
independent-source scientific dataset.

`PROVIDER_PLAN.json` is the exact minimal adapter plan; SHA-256:
`36475be1f485bd05e4e5c577f8498c3f6331e045899d3b7d4f61448834dffe88`.
`FROZEN_PLAN.json` retains the selection rule, excluded nonterminal candidates,
original payload hashes, UTC capture bounds and source/attempt identity checks;
SHA-256 `963f2e1f7bff4ca20b731a408aee837c984b6f66355ea2facac11ee9b5fb3d60`.
Both plans were written with exclusive creation before follow-up calls.

Full run GETs at 05:30:13 UTC and explicit-attempt job-list GETs at
05:30:34 UTC supply actual run_attempt=1, head_sha, run_id and job_id fields.
The attempt is not guessed from a URL. Exact returned UTF-8 payloads and full
tool response containers are retained separately. Initial snapshots precede
plan freeze and the follow-up at 05:32:25 UTC. Initial/follow-up byte hashes
bind the envelopes to these raw API payloads.

`INITIAL_ENVELOPES.jsonl` has eight original capture envelopes (indices 1..8).
`FOLLOWUP_ENVELOPES.jsonl` has eight later envelopes (9..16).
`ALL_ENVELOPES.jsonl` concatenates them unchanged for the adapter CLI.
Indices order deterministic serialization within concurrent capture batches;
they do not authenticate network completion order. UTC timestamps are caller
capture receipts, not a trusted global clock. Query elapsed was not measured,
remains null and is not synthesized from timestamp differences.

At the one follow-up, **all 12 frozen jobs remain queued**. No denominator is
dropped and no UNKNOWN is treated as success/clean. The included unselected
terminal provider rows are not added to the frozen roster. All business labels
remain UNKNOWN. This source collection scopes only provider CI properties; it
establishes no independent business-task adjudication, calibrated prediction,
scientific policy benefit or complete acquisition cost. One provider/repository
trust cluster, zero new task launches/model calls/SQL queries. HOLD / NONE.
