from copy import deepcopy
import json
from experiments.verification_cell_verify1.test_matched_qualification import example, design_receipt, verify_fixture_design
from experiments.verification_cell_verify1.matched_qualification import analyze_matched

def evaluate(change=None):
    manifest, rows = example(8, clusters=[0] * 8)
    def verifier(m, receipt):
        if change:
            original = m["pairs"]
            m["pairs"] = deepcopy(original)
            for i, pair in enumerate(original):
                pair["cluster_id"] = f"detached-{i}"
        return verify_fixture_design(m, receipt)
    try:
        report = analyze_matched(manifest, rows,
            verify_label=lambda *args: True, verify_cost=lambda *args: True,
            design=design_receipt(manifest), verify_design=verifier)
        return {"status": "returned", "manifest_cluster_count": len({p["cluster_id"] for p in manifest["pairs"]}),
                "reported_cluster_count": report["cluster_count"],
                "p_value": report["paired_group_signflip_one_sided_p"],
                "externally_reviewable": report["gates"]["externally_reviewable"]}
    except ValueError as error:
        return {"status": "refused", "reason": str(error)}
print(json.dumps({"ordinary": evaluate(), "alias_rebinding_callback": evaluate(True)}, sort_keys=True))
