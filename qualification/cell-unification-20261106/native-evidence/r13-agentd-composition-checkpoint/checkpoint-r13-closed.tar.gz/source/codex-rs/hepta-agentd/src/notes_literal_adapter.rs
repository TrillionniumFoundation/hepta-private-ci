//! Finite literal Notes preparation in the original Agentd process. The only
//! untrusted inputs are a navigation ID and document text. Original Root, writer,
//! observer, checkpoint and signer handles are retained from one composition.

use std::sync::Arc;
use std::time::Duration;
use std::time::Instant;

use codex_hepta_memory::ObjectiveSenderOrigin;
use codex_hepta_memory::ObjectiveSenderRequest;
use codex_hepta_memory::ObjectiveSenderTicket;
use codex_hepta_memory::ProductionDurableWriter;
use codex_hepta_memory::ProductionObjectiveSender;
use codex_hepta_memory::ProtectedCognitiveCheckpoint;
use codex_hepta_objective::LiteralNotesSourceContext;
use codex_hepta_objective::MAX_OBJECTIVE_ADMISSION_PROFILE_JSON_BYTES;
use codex_hepta_objective::decode_admission_profile_json_v1;
use codex_hepta_objective::literal_notes_admission_profile_json_v1;
use codex_hepta_objective::literal_notes_source_json_v1;
use codex_hepta_types::Digest32;
use codex_hepta_types::Generation;
use tokio::sync::Semaphore;

use crate::AgentdConfig;
use crate::AgentdError;
use crate::AgentdIdentity;
use crate::AgentdNotesDocumentObserver;
use crate::AgentdNotesObjectiveConfig;
use crate::AgentdRootAuthoritySession;
use crate::AgentdRootProductionAttachment;
use crate::AgentdUnixCognitiveCheckpointTransport;
use crate::AgentdUnixFinalUseGrantProvider;
use crate::AuthBusObjectiveBody;
use crate::AuthBusObjectiveIngress;
use crate::notes_literal_prepare::LiteralOperationInput;
use crate::notes_literal_prepare::prepare_original_literal;
use crate::notes_literal_prepare::utc_millis;

#[path = "notes_literal_read.rs"]
mod read;
pub use read::AgentdNotesRetainedIntents;
#[path = "desktop_adapter_prepare.rs"]
mod desktop_prepare;
#[path = "notes_literal_history.rs"]
mod history;
#[path = "notes_thread_recorded.rs"]
pub(crate) mod recorded;
#[cfg(test)]
pub(crate) use desktop_prepare::prepare_desktop_operation_before;
#[path = "desktop_thread_recorded.rs"]
pub(crate) mod desktop_recorded;
#[path = "notes_ui_runtime.rs"]
mod ui_runtime;
pub use ui_runtime::AgentdNotesUiRuntime;
#[path = "notes_ui_worker.rs"]
mod ui_worker;

type RootCheckpoint = ProtectedCognitiveCheckpoint<AgentdUnixCognitiveCheckpointTransport>;

/// Ephemeral view diagnostics only, never a permit or persistent state.
enum NotesUiCallPhase {
    ReadOnly,
    Preparing,
    Sending,
}

/// Frozen deployment data, supplied by the trusted launcher, never UI IPC.
/// The five artifact/runtime digests must name actual retained source inputs.
/// No default or fabricated model identity is supplied for this no-model action.
pub struct AgentdNotesLiteralBindings {
    pub principal_scope: String,
    pub principal_scope_digest: Digest32,
    pub issuer_id: String,
    pub policy_generation: Generation,
    pub locale: String,
    pub runtime_body_digest: Digest32,
    pub preference_state_digest: Digest32,
    pub model_tuple_digest: Digest32,
    pub prompt_registry_digest: Digest32,
    pub artifact_set_digest: Digest32,
}

/// Private host result, never a renderer message. A retained request is only
/// read/reconciled; it has no new sending permission. `Ready` already occupies
/// the original durable sender fence. `submit_once` consumes that exact sender's
/// permission before authenticated original control I/O, then retains the
/// observation. Losing this result never rearms the request.
pub enum AgentdNotesPreparedObjective {
    Retained(Box<ObjectiveSenderRequest>),
    Ready {
        sender: Arc<ProductionObjectiveSender<RootCheckpoint>>,
        ticket: Box<ObjectiveSenderTicket>,
        ingress: Box<AuthBusObjectiveIngress>,
    },
}

/// One non-cloneable preparation capability, with one bounded blocking slot.
/// The slot remains held by started observation/signing work after cancellation.
/// It owns no database, nonce, request-ID mapping or parallel admission ledger.
#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum NotesAdapterProfile {
    Literal,
    OriginalThread,
    OriginalDesktop,
}

struct ThreadPreparation<'a> {
    expected_revision: u64,
    original_call_id: &'a str,
    original_reference: codex_hepta_memory::OriginalNotesThreadReference,
    human: &'a crate::notes_thread_tool::human::VerifiedHumanTurn,
}

pub struct AgentdNotesLiteralAdapter {
    pub(crate) identity: AgentdIdentity,
    pub(crate) writer: Arc<ProductionDurableWriter>,
    sender: Arc<ProductionObjectiveSender<RootCheckpoint>>,
    root: Arc<AgentdRootAuthoritySession>,
    pub(crate) observer: AgentdNotesDocumentObserver,
    grants: Arc<AgentdUnixFinalUseGrantProvider>,
    pub(crate) bindings: AgentdNotesLiteralBindings,
    pub(crate) profile_digest: Digest32,
    input_schema_digest: Digest32,
    normalization_digest: Digest32,
    pub(crate) blocking: Arc<Semaphore>,
    pub(crate) deadline: Duration,
    profile: NotesAdapterProfile,
    next_request: u64,
}

impl AgentdConfig {
    /// Register the exact existing finite profile and retain the same original
    /// writer's sender. The caller installs the adapter into the original
    /// required Notes UI runtime; another process cannot reconstruct it from
    /// files or the public target.
    pub fn with_root_notes_literal_adapter(
        self,
        attachment: &AgentdRootProductionAttachment,
        bindings: AgentdNotesLiteralBindings,
        deadline: Duration,
    ) -> Result<(Self, AgentdNotesLiteralAdapter), AgentdError> {
        self.with_root_notes_adapter(attachment, bindings, deadline, NotesAdapterProfile::Literal)
    }

    pub(crate) fn with_root_notes_adapter(
        self,
        attachment: &AgentdRootProductionAttachment,
        bindings: AgentdNotesLiteralBindings,
        deadline: Duration,
        profile: NotesAdapterProfile,
    ) -> Result<(Self, AgentdNotesLiteralAdapter), AgentdError> {
        if deadline.is_zero()
            || deadline > Duration::from_secs(10)
            || !matches!(bindings.locale.as_str(), "en-US" | "zh-CN")
            || [
                bindings.runtime_body_digest,
                bindings.preference_state_digest,
                bindings.model_tuple_digest,
                bindings.prompt_registry_digest,
                bindings.artifact_set_digest,
            ]
            .into_iter()
            .any(Digest32::is_zero)
        {
            return Err(invalid("missing or invalid frozen Notes runtime bindings"));
        }
        let observer = attachment
            .notes
            .clone()
            .ok_or_else(|| invalid("actual Session Notes observer is absent"))?;
        let host = self
            .production_writer_host()
            .ok_or(AgentdError::CognitiveWriteRuntimeUnavailable)?;
        let writer = host.writer();
        if writer.authority() != &attachment.root_session.authority()
            || writer.owner_agent_id() != &self.identity().agent_id
            || host.spawn_generation() != self.identity().spawn_generation
        {
            return Err(invalid(
                "Notes Root attachment differs from installed writer",
            ));
        }
        let encode_profile = match profile {
            NotesAdapterProfile::Literal => literal_notes_admission_profile_json_v1,
            NotesAdapterProfile::OriginalThread => {
                codex_hepta_objective::thread_notes_admission_profile_json_v1
            }
            NotesAdapterProfile::OriginalDesktop => {
                codex_hepta_objective::desktop_thread_admission_profile_json_v1
            }
        };
        let expected = encode_profile(
            &bindings.principal_scope,
            bindings.principal_scope_digest,
            &bindings.issuer_id,
        )
        .map_err(AgentdError::Invalid)?;
        let expected = decode_admission_profile_json_v1(expected.as_bytes())
            .map_err(|error| invalid(&error.to_string()))?;
        let path = self
            .objective_profile_file()
            .ok_or_else(|| invalid("original finite Notes profile file is absent"))?;
        let bytes = crate::authbus_trust::read_private_owner_file(
            path,
            self.identity(),
            MAX_OBJECTIVE_ADMISSION_PROFILE_JSON_BYTES as u64,
        )?;
        let selected = decode_admission_profile_json_v1(&bytes)
            .map_err(|error| invalid(&error.to_string()))?;
        if selected != expected {
            return Err(invalid(
                "selected Objective profile differs from literal Notes compiler",
            ));
        }
        let profile_digest = selected
            .digest()
            .map_err(|error| invalid(&error.to_string()))?;
        // Keep the adapter's outer budget; each original sender checkpoint
        // has its own five-second maximum and cannot enlarge a shorter caller.
        let checkpoint_deadline = deadline.min(Duration::from_secs(5));
        let sender = self
            .original_objective_sender(Arc::clone(&attachment.checkpoint), checkpoint_deadline)?;
        let identity = self.identity().clone();
        let configured = if profile == NotesAdapterProfile::OriginalDesktop {
            self
        } else {
            self.with_notes_objective(AgentdNotesObjectiveConfig {
                profile_digest,
                target: observer.target().clone(),
            })?
        };
        let adapter = AgentdNotesLiteralAdapter {
            identity,
            writer,
            sender: Arc::new(sender),
            root: Arc::clone(&attachment.root_session),
            observer,
            grants: Arc::clone(&attachment.grants),
            bindings,
            profile_digest,
            input_schema_digest: selected.expected_input_schema_digest,
            normalization_digest: selected.expected_normalization_profile_digest,
            blocking: Arc::new(Semaphore::new(1)),
            deadline,
            profile,
            next_request: 1,
        };
        adapter.check_available()?;
        Ok((configured, adapter))
    }
}

impl AgentdNotesLiteralAdapter {
    /// Pure deterministic projection in this persistent original owner/scope.
    /// Reusing an ID recovers the first original request and never changes text.
    pub fn run_id(&self, client_intent_id: &str) -> Result<String, AgentdError> {
        if client_intent_id.is_empty()
            || client_intent_id.len() > 96
            || !client_intent_id
                .bytes()
                .all(|byte| byte.is_ascii_alphanumeric() || b"-_".contains(&byte))
        {
            return Err(invalid("invalid Notes client intent ID"));
        }
        let (domain, prefix) = match self.profile {
            NotesAdapterProfile::Literal => ("organ.notes.literal.run.v1", "notes.literal"),
            NotesAdapterProfile::OriginalThread => {
                ("organ.notes.original-turn.run.v1", "notes.thread")
            }
            NotesAdapterProfile::OriginalDesktop => {
                ("organ.desktop.original-turn.run.v1", "desktop.thread")
            }
        };
        let binding = serde_json::to_vec(&(
            domain,
            self.identity.agent_id.as_str(),
            self.bindings.principal_scope_digest.to_string(),
            client_intent_id,
        ))?;
        Ok(format!("{prefix}.{}", Digest32::of_bytes(&binding)))
    }

    pub(crate) async fn retained_thread_request_sha256(
        &self,
        client_intent_id: &str,
        original_call_id: &str,
    ) -> Result<Option<String>, AgentdError> {
        let run_id = self.run_id(client_intent_id)?;
        let request = self
            .sender
            .retained_request_for_run(&run_id)
            .await
            .map_err(|error| invalid(&error.to_string()))?;
        if let Some(request) = &request {
            require_original_thread_call(request, original_call_id)?;
        }
        Ok(request.map(|request| request.identity().original_sha256.as_str().to_owned()))
    }

    pub(crate) async fn verify_original_human_text(
        &self,
        ingress: &crate::AuthBusTextIngress,
        route: &crate::text_session::AgentdTextSessionConfig,
    ) -> Result<crate::text_session::TextOwnerReceipt, AgentdError> {
        self.check_available()?;
        let permit = Arc::clone(&self.blocking)
            .try_acquire_owned()
            .map_err(|_| invalid("original human verification worker is occupied"))?;
        let grants = Arc::clone(&self.grants);
        let root = Arc::clone(&self.root);
        let ingress = ingress.clone();
        let expected = route.clone();
        let receipt = tokio::time::timeout(
            self.deadline,
            tokio::task::spawn_blocking(move || {
                let _permit = permit;
                let receipt = grants
                    .verify_original_human_text(&ingress)
                    .map_err(|_| invalid("Root did not verify this original human input"))?;
                let now = root
                    .clock()
                    .now_unix_ms()
                    .map_err(|_| invalid("protected Root clock unavailable"))?;
                if !receipt.validate() || receipt.route != expected || receipt.expires_at_ms <= now
                {
                    return Err(invalid(
                        "Root human input proof differs from current fixed route or lifetime",
                    ));
                }
                Ok(receipt)
            }),
        )
        .await
        .map_err(|_| invalid("Root human input verification timed out"))?
        .map_err(|_| invalid("Root human verification worker failed"))??;
        self.check_available()?;
        Ok(receipt)
    }

    pub fn check_available(&self) -> Result<(), AgentdError> {
        if self.writer.checkpoint_fenced() {
            return Err(invalid(
                "original Notes writer is permanently checkpoint-fenced",
            ));
        }
        self.root
            .verifier()
            .verify(self.writer.authority(), &self.identity.agent_id)
            .map_err(AgentdError::GenerationFenced)
    }

    /// Retain before returning any signed ingress. This never calls a device,
    /// creates a FinalUse grant, dispatches an outbox row or submits Objective.
    /// A timeout/failed sign may leave original durable preparation; retry can
    /// only observe that owner, and an already retained request is not reissued.
    pub async fn prepare(
        &mut self,
        client_intent_id: &str,
        text: &str,
    ) -> Result<AgentdNotesPreparedObjective, AgentdError> {
        let end = Instant::now() + self.deadline;
        let mut phase = NotesUiCallPhase::ReadOnly;
        tokio::time::timeout_at(
            end.into(),
            self.prepare_until(client_intent_id, text, end, &mut phase),
        )
        .await
        .map_err(|_| invalid("Notes original preparation acknowledgement unknown"))?
    }

    async fn prepare_until(
        &mut self,
        client_intent_id: &str,
        text: &str,
        end: Instant,
        phase: &mut NotesUiCallPhase,
    ) -> Result<AgentdNotesPreparedObjective, AgentdError> {
        if self.profile != NotesAdapterProfile::Literal {
            return Err(invalid("literal UI cannot prepare a model tool operation"));
        }
        self.prepare_bound(client_intent_id, text, None, end, phase)
            .await
    }

    pub(crate) async fn prepare_thread(
        &mut self,
        client_intent_id: &str,
        original_call_id: &str,
        original_reference: codex_hepta_memory::OriginalNotesThreadReference,
        text: &str,
        expected_revision: u64,
        human: &crate::notes_thread_tool::human::VerifiedHumanTurn,
    ) -> Result<AgentdNotesPreparedObjective, AgentdError> {
        if self.profile != NotesAdapterProfile::OriginalThread {
            return Err(invalid(
                "model tool cannot use the no-model literal profile",
            ));
        }
        let (turn, call) =
            recorded::reference_ids(&original_reference, self.identity.agent_id.as_str())?;
        if turn != client_intent_id
            || call != original_call_id
            || original_reference.thread_id != human.route().thread_id
            || original_reference.app_server_session_id != human.route().app_server_session_id
            || !recorded::callback_matches(&original_reference, text, expected_revision)?
        {
            return Err(invalid("original Notes raw callback reference differs"));
        }
        let current_human = self
            .verify_original_human_text(human.ingress(), human.route())
            .await?;
        if !human.owner().same_authorization(&current_human) {
            return Err(invalid(
                "original human authorization changed before Notes preparation",
            ));
        }
        let end = Instant::now() + self.deadline;
        let mut phase = NotesUiCallPhase::ReadOnly;
        tokio::time::timeout_at(
            end.into(),
            self.prepare_bound(
                client_intent_id,
                text,
                Some(ThreadPreparation {
                    expected_revision,
                    original_call_id,
                    original_reference,
                    human,
                }),
                end,
                &mut phase,
            ),
        )
        .await
        .map_err(|_| invalid("original thread preparation acknowledgement unknown"))?
    }

    async fn prepare_bound(
        &mut self,
        client_intent_id: &str,
        text: &str,
        thread: Option<ThreadPreparation<'_>>,
        end: Instant,
        phase: &mut NotesUiCallPhase,
    ) -> Result<AgentdNotesPreparedObjective, AgentdError> {
        if self.profile == NotesAdapterProfile::OriginalDesktop {
            return Err(invalid(
                "Desktop requires its exact six-tool preparation entry",
            ));
        }
        if self.profile == NotesAdapterProfile::OriginalThread && thread.is_none() {
            return Err(invalid(
                "original Notes thread preparation requires verified human input",
            ));
        }
        let expected_revision = thread.as_ref().map(|binding| binding.expected_revision);
        let original_call_id = thread.as_ref().map(|binding| binding.original_call_id);
        let run_id = self.run_id(client_intent_id)?;
        if let Some(retained) = self
            .sender
            .retained_request_for_run(&run_id)
            .await
            .map_err(|error| invalid(&error.to_string()))?
        {
            if let Some(original_call_id) = original_call_id {
                require_original_thread_call(&retained, original_call_id)?;
            }
            if let Some(expected_revision) = expected_revision {
                let original = self
                    .writer
                    .retained_operation(&run_id)
                    .await?
                    .ok_or_else(|| {
                        invalid("retained thread request lost its original operation")
                    })?;
                let payload: serde_json::Value = serde_json::from_str(&original.payload_json)?;
                if payload["text"].as_str() != Some(text)
                    || payload["expected_revision"].as_u64() != Some(expected_revision)
                {
                    return Err(invalid(
                        "original thread call was rebound to different arguments",
                    ));
                }
            }
            return Ok(AgentdNotesPreparedObjective::Retained(Box::new(retained)));
        }
        // The operation ID is the durable original-turn fence. A preparation
        // without a signed sender is uncertainty, not permission to sign again
        // under a new call, worker, connection, or process after a lost reply.
        if original_call_id.is_some() {
            crate::notes_literal_prepare::require_unprepared_original_turn(&self.writer, &run_id)
                .await?;
        }
        self.check_available()?;
        // Startup cannot consume a durable send opportunity while the original
        // control listener/profile is still unavailable. This is a bounded,
        // authenticated read-only query, not a delivery attempt or retry.
        self.require_objective_ready().await?;
        if text.trim().is_empty() || text.len() > 4096 {
            return Err(invalid("literal Notes text exceeds original bounds"));
        }
        let permit = Arc::clone(&self.blocking)
            .try_acquire_owned()
            .map_err(|_| invalid("previous Notes blocking work is still in progress"))?;
        let observer = self.observer.clone();
        let observed = tokio::task::spawn_blocking(move || {
            let _permit = permit;
            if Instant::now() >= end {
                return Err(invalid("Notes observation deadline elapsed"));
            }
            observer.observe_document()
        })
        .await
        .map_err(|_| invalid("Notes observation worker failed"))??;
        self.check_available()?;
        if expected_revision.is_some_and(|revision| revision != observed.revision) {
            return Err(invalid(
                "original thread predecessor changed; no operation was prepared",
            ));
        }
        let now_ms = self
            .root
            .clock()
            .now_unix_ms()
            .map_err(|_| invalid("protected Root clock unavailable"))?;
        let source_deadline = now_ms
            .checked_add(5_000)
            .ok_or_else(|| invalid("Notes source deadline overflow"))?
            .min(
                thread
                    .as_ref()
                    .map_or(u64::MAX, |binding| binding.human.owner().expires_at_ms),
            );
        if source_deadline <= now_ms {
            return Err(invalid("original human Notes window expired"));
        }
        if Instant::now() >= end {
            return Err(invalid(
                "Notes deadline elapsed before original preparation",
            ));
        }
        *phase = NotesUiCallPhase::Preparing;
        let semantic = prepare_original_literal(
            &self.writer,
            LiteralOperationInput {
                target: self.observer.target(),
                observed: &observed,
                run_id: &run_id,
                text,
                subject: self.identity.agent_id.as_str(),
                policy_generation: self.bindings.policy_generation,
            },
        )
        .await?;
        let encode_source = match self.profile {
            NotesAdapterProfile::Literal => literal_notes_source_json_v1,
            NotesAdapterProfile::OriginalThread => {
                codex_hepta_objective::thread_notes_source_json_v1
            }
            NotesAdapterProfile::OriginalDesktop => {
                return Err(invalid("Desktop cannot compile a legacy Notes source"));
            }
        };
        let source = encode_source(LiteralNotesSourceContext {
            client_intent_id: original_call_id.unwrap_or(client_intent_id),
            source_digest: semantic,
            principal_scope_digest: self.bindings.principal_scope_digest,
            locale: &self.bindings.locale,
            observed_at: &utc_millis(now_ms)?,
            deadline: &utc_millis(source_deadline)?,
        })
        .map_err(AgentdError::Invalid)?;
        let body = AuthBusObjectiveBody {
            spawn_generation: self.identity.spawn_generation,
            run_id,
            objective_revision: 1,
            source_envelope_json: source,
            runtime_body_digest: self.bindings.runtime_body_digest.to_string(),
            preference_state_digest: self.bindings.preference_state_digest.to_string(),
            model_tuple_digest: self.bindings.model_tuple_digest.to_string(),
            prompt_registry_digest: self.bindings.prompt_registry_digest.to_string(),
            artifact_set_digest: self.bindings.artifact_set_digest.to_string(),
            authority_epoch: self.root.authority().authority_epoch,
        };
        let permit = Arc::clone(&self.blocking)
            .try_acquire_owned()
            .map_err(|_| invalid("Notes signer slot is occupied"))?;
        let grants = Arc::clone(&self.grants);
        let root = Arc::clone(&self.root);
        let human_check = thread.as_ref().map(|binding| {
            (
                binding.human.ingress().clone(),
                binding.human.owner().clone(),
                binding.human.route().clone(),
            )
        });
        let signed = tokio::task::spawn_blocking(move || {
            let _permit = permit;
            if Instant::now() >= end
                || root
                    .clock()
                    .now_unix_ms()
                    .map_err(|_| invalid("Root clock unavailable before sign"))?
                    >= source_deadline
            {
                return Err(invalid("Notes source expired before Root signing"));
            }
            if let Some((ingress, original, route)) = human_check {
                let current = grants.verify_original_human_text(&ingress).map_err(|_| {
                    invalid("original human session is unavailable before Notes signing")
                })?;
                if !current.validate()
                    || current.route != route
                    || !original.same_authorization(&current)
                    || root
                        .clock()
                        .now_unix_ms()
                        .map_err(|_| invalid("Root clock unavailable"))?
                        >= current.expires_at_ms
                {
                    return Err(invalid(
                        "original human session changed or expired before Notes signing",
                    ));
                }
            }
            grants
                .sign_objective(&body)
                .map_err(|error| invalid(&error.to_string()))
        })
        .await
        .map_err(|_| invalid("Notes Root signing worker failed"))??;
        self.check_available()?;
        if signed.issuer_id != self.bindings.issuer_id
            || self
                .root
                .clock()
                .now_unix_ms()
                .map_err(|_| invalid("Root clock unavailable after sign"))?
                >= source_deadline
        {
            return Err(invalid(
                "Notes signed ingress expired or differs from frozen issuer",
            ));
        }
        let mut origin = self.next_origin()?;
        origin.original_notes_thread = thread
            .as_ref()
            .map(|binding| binding.original_reference.clone());
        let request =
            ObjectiveSenderRequest::from_original(serde_json::to_string(&signed)?, origin)
                .map_err(|error| invalid(&error.to_string()))?;
        let ticket = self
            .sender
            .retain_before_send(request)
            .await
            .map_err(|error| invalid(&error.to_string()))?;
        self.check_available()?;
        if self
            .root
            .clock()
            .now_unix_ms()
            .map_err(|_| invalid("Root clock unavailable after sender retention"))?
            >= source_deadline
        {
            return Err(invalid(
                "Notes source expired during original sender acknowledgement",
            ));
        }
        Ok(AgentdNotesPreparedObjective::Ready {
            sender: Arc::clone(&self.sender),
            ticket: Box::new(ticket),
            ingress: Box::new(signed),
        })
    }
}

pub(crate) fn invalid(message: &str) -> AgentdError {
    AgentdError::Invalid(format!("original literal Notes: {message}"))
}

fn require_original_thread_call(
    request: &ObjectiveSenderRequest,
    original_call_id: &str,
) -> Result<(), AgentdError> {
    let ingress: AuthBusObjectiveIngress = serde_json::from_slice(request.exact_original())?;
    let source = codex_hepta_objective::decode_source_envelope_json_v1(
        ingress.body.source_envelope_json.as_bytes(),
    )
    .map_err(|_| invalid("original thread source is invalid"))?;
    if source.request_id != original_call_id {
        return Err(invalid(
            "this original turn belongs to another Notes call; reconcile that original item",
        ));
    }
    Ok(())
}

#[cfg(test)]
#[path = "notes_thread_sender_tests.rs"]
mod thread_sender_tests;
