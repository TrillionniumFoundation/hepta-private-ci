from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent
REL="codex-rs/external-agent-migration/src/service_tests/plugins/marketplaces.rs"
def pin(b):
    return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
def apply_unified(source,patch,reverse=False):
    original=source.decode().splitlines(keepends=True)
    lines=patch.decode().splitlines(keepends=True)
    out=[]; cursor=0; i=0; hunks=0
    while i<len(lines):
        line=lines[i]
        if not line.startswith("@@ "):
            assert line.startswith("--- ") or line.startswith("+++ "), (i,line)
            i+=1;continue
        match=re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@",line)
        assert match
        old_start,old_count,new_start,new_count=(int(x) if x is not None else 1 for x in match.groups())
        start=(new_start if reverse else old_start)-1
        assert start>=cursor
        out.extend(original[cursor:start]);cursor=start
        removed=added=0;i+=1
        while i<len(lines) and not lines[i].startswith("@@ "):
            s=lines[i];tag=s[0];payload=s[1:]
            assert tag in " +-",(i,s)
            if reverse and tag in "+-": tag="+" if tag=="-" else "-"
            if tag in " -":
                assert cursor<len(original) and original[cursor]==payload,(cursor,payload)
                cursor+=1;removed+=1
            if tag in " +":out.append(payload);added+=1
            i+=1
        assert removed==(new_count if reverse else old_count)
        assert added==(old_count if reverse else new_count)
        hunks+=1
    out.extend(original[cursor:])
    return "".join(out).encode(),hunks
before=(ROOT/"original"/REL).read_bytes()
after=(ROOT/"source"/REL).read_bytes()
patch=(ROOT/"repair.patch").read_bytes()
operations=json.loads((ROOT/"edit-operations.json").read_bytes())
assert hashlib.sha256(before).hexdigest()=="a0899f521c2e3eb2a65d012c65a9d9e6531928e4ee692786085ed36131c27d5b"
applied,hunks=apply_unified(before,patch)
restored,reverse_hunks=apply_unified(after,patch,reverse=True)
assert applied==after and restored==before and hunks==reverse_hunks==1
anchor=operations["anchor"]; insert=operations["insert_after"]
assert before.decode().count(anchor)==1 and after.decode().count(anchor+insert)==1
assert after.decode().replace(anchor+insert,anchor,1).encode()==before
start=before.decode().index(anchor)
end=before.decode().index("\n#[tokio::test]",start)
body=before.decode()[start+len(anchor):end]
assert after.decode()[after.decode().index(anchor)+len(anchor)+len(insert):after.decode().index("\n#[tokio::test]",after.decode().index(anchor))]==body
assert body.count("assert_eq!(")==4 and body.count("assert_single_plugin_raw_error(")==1
assert "set_var(" not in insert and "#[ignore" not in insert and "Duration" not in insert
assert 'stdout.contains("test result: ok. 1 passed; 0 failed;")' in insert
assert insert.count('"--exact"')==1 and insert.count('"GIT_CONFIG_COUNT", "2"')==1
manifest={
 "schema":"hepta.r23-marketplace-fixture-source-manifest.v1",
 "baseline":{"stage":49,"commit":"50dd4bedefcd1b8e2e8cd5cf5023c60a86d38d0a","tree":"be34ab1afe622ad3b8f030c8c5018f4f54fbc304"},
 "files":[{"path":REL,"mode":"100644","before":pin(before),"after":pin(after)}],
 "patch":{"path":"repair.patch",**pin(patch)},
 "edit_operations":{"path":"edit-operations.json",**pin((ROOT/"edit-operations.json").read_bytes())},
 "owner":"codex-external-agent-migration",
 "qualification":{"rust_executed":False,"native_source_changed":False,"canonical_source_changed":False,"status":"ISOLATED_CANDIDATE_NOT_NATIVE_QUALIFIED"}
}
(ROOT/"source-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
readback={
 "schema":"hepta.r23-marketplace-fixture-mechanical-readback.v1",
 "scope":"Pure Python source/patch verification; no Git processes, Rust, behavior probes, or network calls.",
 "inputs":{"before":pin(before),"after":pin(after),"patch":pin(patch)},
 "single_hunk":hunks==1,"unified_forward_bytes_exact":applied==after,"unified_reverse_bytes_exact":restored==before,
 "independent_single_insertion_removal_restores_whole_file":True,
 "inserted_lines":len(insert.splitlines()),"deleted_lines":0,
 "unchanged_original_target_body":{"bytes":len(body.encode()),**pin(body.encode()),"assert_eq_calls":4,"assert_single_plugin_raw_error_calls":1},
 "whole_file_old_assertion_calls_preserved":len(re.findall(r"\bassert(?:_eq|_ne)?!",before.decode())),
 "all_other_source_bytes_preserved":True,
 "test_attributes_names_and_count_unchanged":re.findall(r"#\[(?:tokio::)?test[^\n]*\]\s*\n(?:async )?fn [^\n]+",before.decode())==re.findall(r"#\[(?:tokio::)?test[^\n]*\]\s*\n(?:async )?fn [^\n]+",after.decode()),
 "no_timeout_ignore_feature_filter_config_changes":True,
 "child_internal_exact_selection":{"expected_name":"service::tests::plugins::marketplaces::import_plugins_infers_external_official_marketplace_when_missing_from_settings","successful_status_required":True,"exactly_one_successful_test_summary_required":True,"not_top_level_gate_filter":True},
 "fixture_only_environment":{"mutation":"Command.env on the child process only; no parent process-global set_var","git_config_count":2,"rewritten_source":"https://github.com/anthropics/claude-plugins-official.git","relative_destination":"../official-marketplace","child_working_directory":"fixture_root/work","protocol_file_allow":"always only in the isolated fixture child"}
}
(ROOT/"MECHANICAL-READBACK.json").write_text(json.dumps(readback,indent=2)+"\n")
print(json.dumps({"status":"SOURCE_BYTES_VERIFIED_NOT_EXECUTED","manifest":pin((ROOT/"source-manifest.json").read_bytes()),"mechanical":pin((ROOT/"MECHANICAL-READBACK.json").read_bytes()),"candidate":pin(after)},indent=2))
