from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
ROOT=Path(__file__).resolve().parent
WORKSPACE=ROOT.parent
CANDIDATE=WORKSPACE/"external-agent-marketplace-r23-repair"
URL="https://github.com/anthropics/claude-plugins-official.git"
REL="codex-rs/external-agent-migration/src/service_tests/plugins/marketplaces.rs"
def pin(b):
    return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
def dump(path,value):
    assert not path.exists(),path
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n")
guard_paths=["source/"+REL,"repair.patch","HANDOFF-MANIFEST.json","repair-audit.json"]
before={p:pin((CANDIDATE/p).read_bytes()) for p in guard_paths}
assert before["source/"+REL]["sha256"]=="9d8254f32942924dc90f413d2fc97cd66558f5ebe4b1186626f676134ccb8170"
assert before["repair.patch"]["sha256"]=="9b6fa89bb9094c5360a7a2dcebebc0660bce840783933dc14935d988ae6921ad"
assert before["HANDOFF-MANIFEST.json"]["sha256"]=="b6c2843cbd762e4ba04eef5dee98426a96e9edba010e93e9cf9332be59b8a01b"
fixture=ROOT/"fixture"
assert not fixture.exists(),"probe is create-only, not silently repeatable"
repo=fixture/"official-marketplace";work=fixture/"work";dest=fixture/"cloned-marketplace"
(repo/".claude-plugin").mkdir(parents=True);work.mkdir()
manifest=b'{"name":"claude-plugins-official","plugins":[]}'
(repo/".claude-plugin/marketplace.json").write_bytes(manifest)
git=Path(shutil.which("git")).resolve(strict=True)
git_pin={"lookup":"git","resolved_path":str(git),**pin(git.read_bytes())}
overrides={
 "CODEX_EXTERNAL_OFFICIAL_MARKETPLACE_IMPORT_CHILD":"1",
 "GIT_CONFIG_COUNT":"2",
 "GIT_CONFIG_KEY_0":"url.../official-marketplace.insteadOf",
 "GIT_CONFIG_VALUE_0":URL,
 "GIT_CONFIG_KEY_1":"protocol.file.allow",
 "GIT_CONFIG_VALUE_1":"always",
 "GIT_TERMINAL_PROMPT":"0"
}
child_env=os.environ.copy();child_env.update(overrides)
commands=[]
def run(name,args,cwd,env=None):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock=time.monotonic()
    timed_out=False
    try:
        result=subprocess.run(["git",*args],cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20,check=False)
        rc=result.returncode;stdout=result.stdout;stderr=result.stderr
    except subprocess.TimeoutExpired as exc:
        timed_out=True;rc=None;stdout=exc.stdout or b"";stderr=exc.stderr or b""
    elapsed=time.monotonic()-clock
    out=ROOT/(name+".stdout");err=ROOT/(name+".stderr")
    assert not out.exists() and not err.exists()
    out.write_bytes(stdout);err.write_bytes(stderr)
    rec={"name":name,"argv":["git",*args],"cwd":str(cwd),"environment_overrides":overrides if env is not None else {},"other_environment":"inherited and not collected or modified","started_utc":started,"elapsed_seconds":elapsed,"exit_code":rc,"timed_out":timed_out,"probe_only_observation_timeout_seconds":20,"stdout":{"path":out.name,**pin(stdout)},"stderr":{"path":err.name,**pin(stderr)}}
    dump(ROOT/(name+".receipt.json"),rec);commands.append(rec)
    assert rc==0 and not timed_out,rec
    return stdout
run("01-git-version",["--version"],work)
setup=[
 ["init","--quiet"],
 ["add","."],
 ["-c","user.name=Codex Tests","-c","user.email=codex-tests@openai.com","-c","commit.gpgsign=false","commit","--quiet","-m","official marketplace fixture"]
]
for i,args in enumerate(setup,2):run(f"{i:02d}-fixture-git",args,repo)
rewritten=run("05-resolve-url",["ls-remote","--get-url",URL],work,child_env)
assert rewritten==b"../official-marketplace\n",rewritten
# Exact production clone argv: the source49 constant is separately pinned.
clone_args=["-c","safe.bareRepository=explicit","clone",URL,str(dest)]
run("06-production-clone",clone_args,work,child_env)
actual_manifest=(dest/".claude-plugin/marketplace.json").read_bytes()
assert actual_manifest==manifest
origin=run("07-recorded-origin",["config","--get","remote.origin.url"],dest,child_env)
assert origin==(URL+"\n").encode(),origin
repo_head=run("08-fixture-head",["rev-parse","HEAD"],repo)
clone_head=run("09-cloned-head",["rev-parse","HEAD"],dest)
assert repo_head==clone_head
(ROOT/"fixture-manifest.json").write_bytes(manifest)
(ROOT/"cloned-manifest.json").write_bytes(actual_manifest)
(ROOT/"clone-git-config.txt").write_bytes((dest/".git/config").read_bytes())
after={p:pin((CANDIDATE/p).read_bytes()) for p in guard_paths}
assert after==before
summary={
 "schema":"hepta.r23-local-git-transport-probe.v1",
 "status":"LOCAL_GIT_PROBE_PASS_NOT_RUST_QUALIFICATION",
 "authorization":"Root authorized a single pure-Git probe with exact candidate directory relationship, child Git config and production clone argv.",
 "source_baseline":{"stage":49,"commit":"50dd4bedefcd1b8e2e8cd5cf5023c60a86d38d0a","tree":"be34ab1afe622ad3b8f030c8c5018f4f54fbc304"},
 "git_binary":git_pin,
 "probe_script":pin(Path(__file__).read_bytes()),
 "candidate_guard_before":before,"candidate_guard_after":after,"frozen_candidate_unchanged":True,
 "commands":commands,
 "assertions":{
  "rewrite_resolves_to_expected_relative_local_repository":True,
  "clone_uses_exact_production_argv_and_cwd_relationship":True,
  "production_clone_exit_zero":True,
  "cloned_manifest_matches_fixture_bytes":True,
  "git_records_canonical_official_https_origin":True,
  "fixture_and_cloned_git_head_equal":True,
  "head":repo_head.decode().strip(),
  "manifest":pin(manifest)
 },
 "environment_boundary":"The fixture child explicitly changes two Git configuration entries: canonical URL rewrite and protocol.file.allow=always. GIT_TERMINAL_PROMPT=0 matches production. The private marker matches the candidate. No process-global environment is changed; no sandbox/network-protection variable is read for behavior or overwritten.",
 "network_boundary":"The no-network git ls-remote --get-url preflight returned ../official-marketplace before the actual clone. The clone then succeeded from that existing local repository and preserved the canonical origin. This is not a syscall/network trace and does not locate the original r23 timeout.",
 "qualification_limits":["Local Git transport probe only, not the Rust test, native pocket4 Git version, strict gate or whole workspace.","No candidate, canonical or native source was edited.","The independent probe's 20-second per-command observation guard does not modify the original 60-second nextest budget.","No external repository was used as the clone transport destination; no sandbox/network-protection or global Git configuration was altered."],
 "rust_executed":False
}
dump(ROOT/"PROBE-READBACK.json",summary)
print(json.dumps({"status":summary["status"],"commands":len(commands),"clone_seconds":commands[5]["elapsed_seconds"],"head":summary["assertions"]["head"],"report":pin((ROOT/"PROBE-READBACK.json").read_bytes())},indent=2))
