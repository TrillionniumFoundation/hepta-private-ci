#!/usr/bin/env python3
"""Bind the four original closed failure excerpts to the narrow fixture patch."""
from pathlib import Path
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parent
TASK = ROOT.parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(data), "sha256": sha(data)}


def put(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as out:
        out.write(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def copy_exact(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("xb") as out:
        out.write(source.read_bytes())
    assert source.read_bytes() == destination.read_bytes()


def main():
    manifest = json.loads((ROOT / "source-manifest.json").read_bytes())
    support = json.loads((ROOT / "source-input-pins.json").read_bytes())
    source_manifest = TASK / "native-validation-results/checkpoint-r22/evidence/native-candidate-r22-source.json"
    actual = json.loads(source_manifest.read_bytes())
    assert sha(source_manifest.read_bytes()) == "8cd1ec59c95d6c777d887f3302b257dc5230a7bfa5570fe9df0f0b2ef361aba5"
    assert actual["source_commit"] == manifest["source_commit"] and actual["source_tree"] == manifest["source_tree"]
    assert not any(e["path"].startswith("codex-rs/network-proxy/") or e["path"].endswith("AGENTS.md") for e in actual["changed_files"])
    copy_exact(source_manifest, ROOT / "evidence/source49-native-manifest.json")
    blocks_source = TASK / "native-validation-results/r23-terminal-small/native-workspace-r23-closed-failure-blocks.json"
    assert sha(blocks_source.read_bytes()) == "7973eebdabb440199c65e3c2b27229c43a3d3e047d2dd3e9d135234cbcc286a4"
    copy_exact(blocks_source, ROOT / "evidence/original-r23-failure-blocks.json")
    receipt_source = TASK / "native-validation-results/r23-terminal-small/native-workspace-r23-tests-receipt.json"
    receipt = json.loads(receipt_source.read_bytes())
    assert receipt["source_tree"] == manifest["source_tree"] and receipt["exit_code"] == 100
    assert receipt["command"] == ["just", "test", "--locked", "--retries", "0"]
    copy_exact(receipt_source, ROOT / "evidence/original-r23-tests-receipt.json")
    blocks = [r for r in json.loads(blocks_source.read_bytes()) if r["binary"] == "codex-network-proxy"]
    assert len(blocks) == 4
    assert {x["name"].split("::")[-1] for x in blocks} == {case for f in manifest["files"] for case in f["tests_changed"]}
    for b in blocks:
        raw = b["text"].encode()
        assert b["status"] == "FAIL" and len(raw) == b["end_byte"] - b["start_byte"]
        assert sha(raw) == b["sha256"]
    put("evidence/network-four-failures-derived.json", {
        "source_raw_file": pin(ROOT / "evidence/original-r23-failure-blocks.json"),
        "full_log_sha256_declared_by_original_receipt": receipt["log_sha256"],
        "full_log_byte_range_independent_recheck": "Pending complete r23 archive readback; exact preserved block UTF8 SHA/ranges are checked now.",
        "blocks": blocks,
    })
    refs = {
        "fixture_default": {"path": "codex-rs/network-proxy/src/config.rs", "lines": [150, 170], "fact": "NetworkProxyConfig::default sets allow_local_binding=false; candidate does not change this default."},
        "host_guard": {"path": "codex-rs/network-proxy/src/runtime.rs", "lines": [528, 602], "fact": "host_blocked checks explicit deny, then local/private policy, then allowlist; hostname DNS is reached when allow_local_binding is false."},
        "dns_guard": {"path": "codex-rs/network-proxy/src/runtime.rs", "lines": [934, 972], "fact": "Hostname DNS errors, timeout and non-public results fail closed; 2-second timeout is defined at line49 and stays unchanged."},
        "test_state": {"path": "codex-rs/network-proxy/src/runtime.rs", "lines": [1049, 1095], "fact": "Existing test state keeps supplied config, compiles real hooks, sets MITM state to None and uses a NoopReloader."},
        "http_order": {"path": "codex-rs/network-proxy/src/http_proxy.rs", "lines": [267, 396], "fact": "CONNECT evaluates host policy before mode/MITM-state requirement; missing MITM state is checked only after host allow."},
        "host_policy": {"path": "codex-rs/network-proxy/src/network_policy.rs", "lines": [340, 402], "fact": "CONNECT host policy delegates to the unchanged host_blocked method."},
        "mitm_order": {"path": "codex-rs/network-proxy/src/mitm.rs", "lines": [341, 485], "fact": "Inner request rechecks local/private resolution before hook evaluation and method policy; this remains unchanged."},
        "header_mapping": {"path": "codex-rs/network-proxy/src/responses.rs", "lines": [52, 61], "fact": "Both NotAllowed and NotAllowedLocal map to blocked-by-allowlist; raw header alone does not distinguish the reason."},
        "existing_fixture_pattern": {"path": "codex-rs/network-proxy/src/http_proxy.rs", "lines": [1277, 1303], "fact": "An existing pure host-policy test already selects allow_local_binding=true while retaining its hostname allowlist."},
        "hook_matching": {"path": "codex-rs/network-proxy/src/mitm_hook.rs", "lines": [245, 266], "fact": "Hook lookup and first matching hook logic are unchanged."},
        "full_mode": {"path": "codex-rs/network-proxy/src/config.rs", "lines": [297, 315], "fact": "Full mode accepts methods; the matching-write test's literal failure text does not establish a method-clamp bug."},
    }
    support_by_path = {e["path"]: e for e in support["files"]}
    for value in refs.values():
        value["source_sha256"] = support_by_path[value["path"]]["sha256"]
        value["source_git_blob"] = support_by_path[value["path"]]["git_blob"]
    observed = {
        "http_connect_accept_blocks_hooked_host_in_full_mode_without_mitm_state": {
            "oracle": "403 and x-proxy-error=blocked-by-mitm-required",
            "observed": "403 retained; x-proxy-error was blocked-by-allowlist",
            "inference": "Host policy intercepted the call before the missing-MITM-state branch. The configured hostname is exactly allowlisted; local/DNS precheck is the source-supported cause, while its concrete DNS failure class is not logged.",
        },
        "mitm_policy_allows_matching_hooked_write_in_full_mode": {
            "oracle": "response.is_none and zero blocked events",
            "observed": "response.is_none assertion failed; the raw failure did not print the response headers or internal reason",
            "inference": "The exact source shows local/DNS checking precedes this configured matching hook and Full mode cannot reject the method. Attribution to the common local/DNS precheck is source-supported, not a measured DNS trace or captured response reason.",
        },
        "mitm_policy_blocks_encoded_path_traversal_for_repository_allowlist": {
            "oracle": "One allowed request then three exact blocked-by-mitm-hook responses; exactly three hook-denied telemetry records",
            "observed": "Allowed request and final denial had the expected values; the middle two denials instead had blocked-by-allowlist",
            "inference": "The same test calls the hostname precheck for each path; ambient resolution can intercept only some calls before deterministic path matching. The exact DNS error/timeout/address was not captured.",
        },
        "mitm_policy_blocks_hook_miss_for_hooked_host_and_records_telemetry_in_full_mode": {
            "oracle": "403 blocked-by-mitm-hook and exact single blocked record with GET/host/port/reason",
            "observed": "The header was blocked-by-allowlist instead of blocked-by-mitm-hook",
            "inference": "The inner-policy implementation returns that header from its earlier local/private rejection. The hook-miss assertion remains unchanged.",
        },
    }
    preservation = json.loads((ROOT / "mechanical-audit.json").read_bytes())
    audit = {
        "schema": "hepta.network-proxy-r23-repair-audit.v1",
        "source_commit": manifest["source_commit"], "source_tree": manifest["source_tree"],
        "status": "FROZEN_ISOLATED_CANDIDATE_NOT_NATIVE_TESTED",
        "classification": "Four pure policy-test fixtures depend on ambient DNS before their intended MITM/hook oracle. Production private-address and DNS-rebinding guards remain unchanged.",
        "observed_failure_count": 4, "failure_ids_and_boundaries": observed,
        "proposed_change": "Only add allow_local_binding:true to the existing NetworkProxyConfig literal in each of the four failed policy tests. Use the existing test configuration seam; keep domains, host names, paths, methods, headers, secrets, request order and assertions identical.",
        "why_this_does_not_test_network_access": "The four fixtures call http_connect_accept or mitm_blocking_response directly. They do not forward a request or connect to an upstream server; the intended outcomes are evaluated in memory. No DNS/HTTP probe was run during this audit.",
        "source_chain": refs,
        "evidence_limits": [
            "The failure logs did not record DNS answers, lookup errors or per-lookup latency. Test elapsed durations are not DNS measurements.",
            "blocked-by-allowlist is a shared header for NotAllowed and NotAllowedLocal. Distinguishing branches uses the exact configured allowlist and source control flow, not the header alone.",
            "The matching-write test records only its failed None assertion; this audit does not invent a captured response reason.",
            "The full r23 log and archive are separately subject to complete independent readback; this candidate currently pins exact original closed excerpts and receipt.",
        ],
        "unchanged_negative_coverage": [
            {"path": "codex-rs/network-proxy/src/mitm_tests.rs", "line": 201, "test": "mitm_policy_rechecks_local_private_target_after_connect"},
            {"path": "codex-rs/network-proxy/src/runtime.rs", "line": 1671, "test": "host_blocked_rejects_allowlisted_hostname_when_dns_lookup_fails"},
            {"path": "codex-rs/network-proxy/src/runtime.rs", "line": 1686, "test": "host_resolves_to_non_public_ip_blocks_on_dns_lookup_timeout"},
            {"path": "codex-rs/network-proxy/src/runtime.rs", "line": 1701, "test": "host_resolves_to_non_public_ip_blocks_on_dns_lookup_error"},
            {"path": "codex-rs/network-proxy/src/network_policy.rs", "line": 1021, "test": "evaluate_host_policy_still_denies_not_allowed_local_without_decider_override"},
        ],
        "mechanical_preservation": preservation,
        "rust_api_wire_schema_dependencies_changed": False,
        "production_default_or_execution_policy_changed": False,
        "new_tests_needed": "None: the four unchanged original failing test IDs directly exercise the repaired fixture preconditions; original negative-policy tests remain in the full package gate.",
        "nearest_instructions": {"path": "AGENTS.md", "git_blob": support_by_path["AGENTS.md"]["git_blob"], "basis": "Complete original cached framework tree has no nearer AGENTS; source49 changed-file manifest changes no instruction files."},
        "package": {"name": "codex-network-proxy", "manifest": "codex-rs/network-proxy/Cargo.toml", "git_blob": support_by_path["codex-rs/network-proxy/Cargo.toml"]["git_blob"], "new_owning_package_for_final_scope": True},
        "validation": {"git_apply_forward_reverse_exact": True, "original_assertions_retained": 73,
            "original_test_attributes_retained": 27, "new_lines": 4, "deleted_lines": 0,
            "rust_or_native_commands_run_by_author": False, "applied_to_native": False,
            "required_next_gate": "Owning package original strict and complete tests, then unchanged default-workspace gate under native_validation ownership."},
        "inputs": [pin(ROOT / "source-input-pins.json"), pin(ROOT / "source-manifest.json"), pin(ROOT / "repair.patch"),
                   pin(ROOT / "evidence/original-r23-failure-blocks.json"), pin(ROOT / "evidence/original-r23-tests-receipt.json"),
                   pin(ROOT / "evidence/source49-native-manifest.json")],
    }
    put("repair-audit.json", audit)
    print(json.dumps(pin(ROOT / "repair-audit.json")))


if __name__ == "__main__":
    main()
