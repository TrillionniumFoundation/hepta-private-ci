#!/usr/bin/env python3
"""Create and mechanically check only the four observed policy-test fixture edits."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
CASES = {
    "codex-rs/network-proxy/src/http_proxy.rs": [
        "http_connect_accept_blocks_hooked_host_in_full_mode_without_mitm_state",
    ],
    "codex-rs/network-proxy/src/mitm_tests.rs": [
        "mitm_policy_allows_matching_hooked_write_in_full_mode",
        "mitm_policy_blocks_encoded_path_traversal_for_repository_allowlist",
        "mitm_policy_blocks_hook_miss_for_hooked_host_and_records_telemetry_in_full_mode",
    ],
}


def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
            "mode": "100644"}


def put_json(name, value):
    p = ROOT / name
    with p.open("x") as f:
        f.write(json.dumps(value, indent=2) + "\n")


def main():
    originals = {r["path"]: r for r in json.loads((ROOT / "source-input-pins.json").read_bytes())["files"]}
    entries = []
    edits = []
    diffs = []
    for name, cases in CASES.items():
        before = (ROOT / "original" / name).read_bytes()
        assert identity(before)["sha256"] == originals[name]["sha256"]
        assert identity(before)["git_blob"] == originals[name]["git_blob"]
        after = before
        file_edits = []
        for case in cases:
            marker = ("async fn " + case + "() {").encode()
            assert after.count(marker) == 1
            start = after.index(marker)
            tail = after[start:]
            endmatch = re.search(rb"\n[ \t]*#\[", tail)
            end = start + endmatch.start() if endmatch else len(after)
            block = after[start:end]
            matches = list(re.finditer(rb"(?m)^( +)let mut (?:network|policy) = NetworkProxyConfig \{\n", block))
            assert len(matches) == 1, case
            m = matches[0]
            inserted = m.group(1) + b"    allow_local_binding: true,\n"
            position = start + m.end()
            assert b"allow_local_binding:" not in block, case
            after = after[:position] + inserted + after[position:]
            edit = {"path": name, "test": case, "after_insertion_byte": position,
                    "inserted_utf8": inserted.decode(), "meaning": "Select the existing fixture configuration that does not resolve ambient DNS before checking MITM/hook policy."}
            edits.append(edit)
            file_edits.append(edit)
        inverse = after
        for edit in reversed(file_edits):
            position = edit["after_insertion_byte"]
            inserted = edit["inserted_utf8"].encode()
            assert inverse[position:position + len(inserted)] == inserted
            inverse = inverse[:position] + inverse[position + len(inserted):]
        assert inverse == before, name
        assertion_pattern = rb"\bassert(?:_eq|_ne)?!\s*[({]"
        assertions_before = len(re.findall(assertion_pattern, before))
        assertions_after = len(re.findall(assertion_pattern, after))
        assert assertions_before == assertions_after
        attrs_before = re.findall(rb"(?m)^\s*#\[(?:tokio::)?test[^\n]*", before)
        attrs_after = re.findall(rb"(?m)^\s*#\[(?:tokio::)?test[^\n]*", after)
        assert attrs_before == attrs_after
        if name.endswith("http_proxy.rs"):
            cut = before.index(b"#[cfg(test)]")
            assert before[:cut] == after[:cut]
        target = ROOT / "source" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as f:
            f.write(after)
        entries.append({"path": name, "before": identity(before), "after": identity(after),
                        "tests_changed": cases, "inserted_lines": len(cases),
                        "whole_file_inverse_exact": True,
                        "assertion_macros_before": assertions_before,
                        "assertion_macros_after": assertions_after,
                        "test_attributes_before": len(attrs_before),
                        "test_attributes_after": len(attrs_after)})
        diffs.extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                     fromfile="a/" + name, tofile="b/" + name))
    patch = "".join(diffs).encode()
    with (ROOT / "repair.patch").open("xb") as f:
        f.write(patch)
    results = []
    with tempfile.TemporaryDirectory(prefix="mechanical-", dir=ROOT) as tmp:
        temp = Path(tmp)
        for name in CASES:
            target = temp / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / "original" / name, target)
        for label, args in [("forward-check", ["--check"]), ("forward", []),
                            ("reverse-check", ["--reverse", "--check"]), ("reverse", ["--reverse"])]:
            if label == "reverse-check":
                for name in CASES:
                    assert (temp / name).read_bytes() == (ROOT / "source" / name).read_bytes()
            proc = subprocess.run(["git", "apply", *args, str(ROOT / "repair.patch")], cwd=temp,
                                  capture_output=True, text=True, check=False)
            results.append({"phase": label, "command": ["git", "apply", *args, "repair.patch"],
                            "exit_code": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr})
            assert proc.returncode == 0, results[-1]
        for name in CASES:
            assert (temp / name).read_bytes() == (ROOT / "original" / name).read_bytes()
    put_json("edit-operations.json", edits)
    put_json("source-manifest.json", {"schema": "hepta.network-proxy-r23-candidate.v1", "frozen": True,
        "source_commit": "50dd4bedefcd1b8e2e8cd5cf5023c60a86d38d0a", "source_tree": "be34ab1afe622ad3b8f030c8c5018f4f54fbc304",
        "package": "codex-network-proxy", "files": entries, "patch": identity(patch),
        "scope": "Four fixture-only explicit config fields; no production behavior, DNS guard, API or assertions changed.",
        "rust_execution": "NOT_RUN", "native_source_applied": False})
    put_json("mechanical-audit.json", {"whole_file_inverse_exact": True, "git_apply_roundtrip": results,
        "total_inserted_lines": 4, "total_deleted_lines": 0,
        "assertions_before": sum(x["assertion_macros_before"] for x in entries),
        "assertions_after": sum(x["assertion_macros_after"] for x in entries),
        "all_other_file_bytes_preserved": True, "production_prefix_preserved": True,
        "budgets_and_original_requests_preserved": True, "rust_or_tests_executed": False})
    print(json.dumps({"patch": identity(patch), "files": entries}, indent=2))


if __name__ == "__main__":
    main()
