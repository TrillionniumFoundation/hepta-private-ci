#!/usr/bin/env python3
"""Offline source, patch and fixture-boundary checks; never run Rust."""

import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile
import tomllib


ROOT = Path(__file__).resolve().parent


def pin(data):
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    }


manifest = json.loads((ROOT / "source-manifest.json").read_text())
native = json.loads((ROOT / "evidence/native-source49-input-manifest.json").read_text())
delta = json.loads((ROOT / "evidence/native-source49-changed-files.json").read_text())
base = json.loads((ROOT / "evidence/original-framework-relevant-entries.json").read_text())
assert native["source_tree"] == delta["source_tree"] == manifest["base_tree"]
baseline_map = {row["path"]: {"git_blob": row["sha"], "mode": row["mode"]} for row in base["entries"]}
baseline_map.update({row["path"]: row for row in delta["changed_files"]})
native_files = {row["path"]: row for row in native["files"]}
inputs = []
for file in sorted((ROOT / "original").rglob("*")):
    if not file.is_file():
        continue
    path = file.relative_to(ROOT / "original").as_posix()
    actual = pin(file.read_bytes())
    expected = baseline_map[path]
    assert actual["git_blob"] == expected["git_blob"], path
    assert expected["mode"] == "100644", path
    if path in native_files:
        for key in ("bytes", "sha256", "git_blob"):
            assert actual[key] == native_files[path][key], (path, key)
    inputs.append({
        "path": path, **actual, "mode": expected["mode"],
        "source_commit": manifest["base_commit"],
        "immutable_url": f'https://github.com/TrillionniumFoundation/hepta-private-ci/blob/{manifest["base_commit"]}/{path}',
        "native_packet_also_bound": path in native_files,
    })

patch_text = ""
for row in manifest["files"]:
    before = (ROOT / "original" / row["path"]).read_bytes()
    after = (ROOT / "source" / row["path"]).read_bytes()
    assert pin(before) == row["before"]
    assert pin(after) == row["after"]
    patch_text += "".join(difflib.unified_diff(
        before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True),
        fromfile="a/" + row["path"], tofile="b/" + row["path"],
    ))
assert patch_text.encode() == (ROOT / "repair.patch").read_bytes()

commands = []
with tempfile.TemporaryDirectory(prefix="bwrap-repair-roundtrip-") as directory:
    work = Path(directory)
    subprocess.run(["git", "init", "--quiet", str(work)], check=True)
    for row in manifest["files"]:
        p = work / row["path"]
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes((ROOT / "original" / row["path"]).read_bytes())
    for arguments in (["--check"], [], ["--reverse", "--check"], ["--reverse"]):
        command = ["git", "apply", *arguments, str(ROOT / "repair.patch")]
        run = subprocess.run(command, cwd=work, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
        commands.append({"command": command, "returncode": run.returncode, "output": run.stdout.decode()})
        assert run.returncode == 0
        if not arguments or arguments == ["--reverse"]:
            scope = "source" if not arguments else "original"
            for row in manifest["files"]:
                assert (work / row["path"]).read_bytes() == (ROOT / scope / row["path"]).read_bytes()

fake_path = "codex-rs/exec-server/tests/common/fake_bwrap.rs"
before = (ROOT / "original" / fake_path).read_text()
after = (ROOT / "source" / fake_path).read_text()
instrumentation = '''printf '%s\\n' "$*" >> "${0}.log"
if [[ -f "${0}.fail-once" ]]; then
  rm -f "${0}.fail-once"
  echo "forced fake bwrap failure" >&2
  exit 125
fi'''
assert before.count(instrumentation) == after.count(instrumentation) == 1
assert after[after.index("    let mut permissions ="):] == before[before.index("    let mut permissions ="):]
assert 'echo "Usage: bwrap' not in after
assert 'exec -a ' not in after
assert after.count('exec "$real_bwrap" "$@"') == 4

cargo_path = "codex-rs/exec-server/Cargo.toml"
old_cargo = tomllib.loads((ROOT / "original" / cargo_path).read_text())
new_cargo = tomllib.loads((ROOT / "source" / cargo_path).read_text())
dep = old_cargo["target"]["cfg(windows)"]["dev-dependencies"].pop("codex-utils-cargo-bin")
assert dep == {"workspace": True}
assert not old_cargo["target"]["cfg(windows)"]["dev-dependencies"]
del old_cargo["target"]["cfg(windows)"]["dev-dependencies"]
old_cargo["dev-dependencies"]["codex-utils-cargo-bin"] = dep
assert old_cargo == new_cargo
lock_file = ROOT.parent / "native-validation-results/checkpoint-r22/input/Cargo.lock"
lock_bytes = lock_file.read_bytes()
lock = tomllib.loads(lock_bytes.decode())
exec_package = next(p for p in lock["package"] if p["name"] == "codex-exec-server")
assert "codex-utils-cargo-bin" in exec_package["dependencies"]

runner_path = "scripts/run-nextest.py"
old_runner = (ROOT / "original" / runner_path).read_text()
new_runner = (ROOT / "source" / runner_path).read_text()
start = new_runner.index('    "codex-exec-server": (\n') + len('    "codex-exec-server": (\n')
added = '        ("codex-bwrap", "bwrap"),\n'
assert new_runner[start:start + len(added)] == added
assert new_runner[:start] + new_runner[start + len(added):] == old_runner

test_path = "scripts/test_run_nextest_helpers.py"
old_tests = (ROOT / "original" / test_path).read_text()
new_tests = (ROOT / "source" / test_path).read_text()
new_name = "test_exec_server_receives_repo_bwrap_for_scoped_and_workspace_runs"
tree = ast.parse(new_tests)
original_methods = {node.name: ast.get_source_segment(old_tests, node) for node in ast.walk(ast.parse(old_tests)) if isinstance(node, ast.FunctionDef)}
new_methods = {node.name: ast.get_source_segment(new_tests, node) for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}
assert set(new_methods) - set(original_methods) == {new_name}
for name, body in original_methods.items():
    if name != "setUp":
        assert new_methods[name] == body, name
declared_snapshot = '        self.declared_helpers = copy.deepcopy(RUNNER.RUNTIME_TEST_HELPERS)\n'
assert new_methods["setUp"].replace(declared_snapshot, "") == original_methods["setUp"]
node = next(node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name == new_name)
lines = new_tests.splitlines(keepends=True)
normalized = "".join(lines[:node.lineno - 1] + lines[node.end_lineno + 1:]).replace(declared_snapshot, "")
assert normalized == old_tests

assertion_counts = []
for path in ["codex-rs/exec-server/tests/capability_discovery.rs", "codex-rs/exec-server/tests/file_system_unix.rs"]:
    data = (ROOT / "original" / path).read_bytes()
    assert path not in [row["path"] for row in manifest["files"]]
    assertion_counts.append({"path": path, **pin(data), "assertion_macro_count": len(re.findall(rb'\bassert(?:_eq|_ne|_matches)?!\s*\(', data)), "edited": False})

nearest = []
instructions = {entry["path"] for entry in base["entries"] if entry["path"] == "AGENTS.md" or entry["path"].endswith("/AGENTS.md")}
instructions.update(row["path"] for row in delta["changed_files"] if row["path"] == "AGENTS.md" or row["path"].endswith("/AGENTS.md"))
for row in manifest["files"]:
    ancestors = [p.as_posix() for p in Path(row["path"]).parents]
    candidates = ["AGENTS.md" if p == "." else p + "/AGENTS.md" for p in ancestors]
    found = [p for p in candidates if p in instructions]
    assert found == ["AGENTS.md"], (row["path"], found)
    nearest.append({"path": row["path"], "nearest_to_root": found})

(ROOT / "input-pins.json").write_text(json.dumps({
    "schema": "hepta.exec-fake-bwrap-r23-input-pins.v1", "source_commit": manifest["base_commit"],
    "source_tree": manifest["base_tree"], "files": inputs, "nearest_instructions": nearest,
    "cargo_lock_original": {"path": "native-validation-results/checkpoint-r22/input/Cargo.lock", **pin(lock_bytes)},
    "existing_exec_server_locked_dependencies": exec_package["dependencies"],
    "required_bazel_lock_update": "NOT_EXECUTED; native owner must run original just bazel-lock-update before claiming lock consistency",
}, indent=2) + "\n")
(ROOT / "mechanical-audit.json").write_text(json.dumps({
    "schema": "hepta.exec-fake-bwrap-r23-mechanical-audit.v1", "patch_exact_regenerated": True,
    "git_apply_roundtrip_commands": commands, "whole_file_forward_and_reverse_exact": True,
    "original_wrapper_log_fail_once_permissions_tail_exact": True,
    "cargo_manifest_parsed_change_exactly_existing_dependency_scope_move": True,
    "runner_inverse_exactly_one_mapping_line": True,
    "original_python_test_methods_and_assertions_exact": True,
    "test_file_whole_inverse_exact": True,
    "new_python_method": new_name, "new_python_subcases": ["scoped", "workspace"],
    "original_rust_fixture_files": assertion_counts,
    "python_ast_valid": True, "rust_executed": False, "canonical_or_native_source_modified": False,
}, indent=2) + "\n")
print(json.dumps({"result": "PASS_OFFLINE_MECHANICAL_ONLY", "original_input_files": len(inputs), "changed_files": len(manifest["files"]), "original_integration_assertions": assertion_counts}, indent=2))
