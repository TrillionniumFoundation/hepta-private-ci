#!/usr/bin/env python3
"""Prepare only the isolated, source49-bound fixture/runner candidate."""

from pathlib import Path
import difflib
import hashlib
import json


ROOT = Path(__file__).resolve().parent
PATHS = [
    "codex-rs/exec-server/tests/common/fake_bwrap.rs",
    "codex-rs/exec-server/Cargo.toml",
    "scripts/run-nextest.py",
    "scripts/test_run_nextest_helpers.py",
]


def digest(data):
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    }


original = {path: (ROOT / "original" / path).read_text() for path in PATHS}
candidate = dict(original)
candidate[PATHS[0]] = '''use anyhow::Context;
use std::os::unix::fs::PermissionsExt;
use std::path::Path;
use std::path::PathBuf;

pub(crate) fn write_fake_bwrap(bin_dir: &Path) -> anyhow::Result<PathBuf> {
    let real_bwrap = codex_utils_cargo_bin::cargo_bin("bwrap")?;
    let real_bwrap = real_bwrap
        .to_str()
        .context("bwrap test binary path is not valid UTF-8")?
        .replace('\\\'', "'\\\\''");
    std::fs::create_dir_all(bin_dir)?;
    let fake_bwrap = bin_dir.join("bwrap");
    let mut script = format!("#!/bin/bash\\nreal_bwrap='{real_bwrap}'\\n");
    script.push_str(
        r#"set -euo pipefail

for arg in "$@"; do
  if [[ "${arg}" == "--help" ]]; then
    exec "$real_bwrap" "$@"
  fi
done

args=("$@")
command_start=-1
for i in "${!args[@]}"; do
  if [[ "${args[$i]}" == "--" ]]; then
    command_start=$((i + 1))
    break
  fi
done

# Capability probes must exercise the same binary without consuming fail-once.
if [[ "${command_start}" -lt 0 || "${command_start}" -ge "${#args[@]}" ]]; then
  exec "$real_bwrap" "$@"
fi

cmd=("${args[@]:$command_start}")
case "${cmd[0]}" in
  /usr/bin/true|/bin/true|true)
    exec "$real_bwrap" "$@"
    ;;
esac

printf '%s\\n' "$*" >> "${0}.log"
if [[ -f "${0}.fail-once" ]]; then
  rm -f "${0}.fail-once"
  echo "forced fake bwrap failure" >&2
  exit 125
fi

# Preserve namespace options, argv0, and all inherited descriptors.
exec "$real_bwrap" "$@"
"#,
    );
    std::fs::write(&fake_bwrap, script)?;
    let mut permissions = std::fs::metadata(&fake_bwrap)?.permissions();
    permissions.set_mode(0o755);
    std::fs::set_permissions(&fake_bwrap, permissions)?;
    Ok(fake_bwrap)
}
'''

entry = "codex-utils-cargo-bin = { workspace = true }\n"
windows = "\n[target.'cfg(windows)'.dev-dependencies]\n" + entry
assert candidate[PATHS[1]].endswith(windows)
assert candidate[PATHS[1]].count(entry) == 1
candidate[PATHS[1]] = candidate[PATHS[1]][:-len(windows)]
anchor = "codex-test-binary-support = { workspace = true }\n"
assert candidate[PATHS[1]].count(anchor) == 1
candidate[PATHS[1]] = candidate[PATHS[1]].replace(anchor, anchor + entry)

anchor = '    "codex-exec-server": (\n'
assert candidate[PATHS[2]].count(anchor) == 1
candidate[PATHS[2]] = candidate[PATHS[2]].replace(
    anchor, anchor + '        ("codex-bwrap", "bwrap"),\n'
)

anchor = '        helper_map = patch.dict(\n'
assert candidate[PATHS[3]].count(anchor) == 1
candidate[PATHS[3]] = candidate[PATHS[3]].replace(
    anchor, '        self.declared_helpers = copy.deepcopy(RUNNER.RUNTIME_TEST_HELPERS)\n' + anchor
)
anchor = '    def test_exact_artifact_path_is_exposed_without_changing_test_arguments(self):\n'
test = '''    def test_exec_server_receives_repo_bwrap_for_scoped_and_workspace_runs(self):
        consumer = self.package("codex-exec-server", [])
        owner = self.package("codex-bwrap", ["bwrap"])
        windows = self.package("codex-windows-sandbox", [
            "codex-command-runner", "codex-windows-sandbox-setup",
        ])
        packages = [consumer, owner, windows]
        self.metadata = {
            "workspace_root": str(self.root),
            "workspace_members": [package["id"] for package in packages],
            "workspace_default_members": [consumer["id"]],
            "packages": packages,
        }
        existing = {
            f"CARGO_BIN_EXE_{name}": str(self.executable)
            for name in ("codex-command-runner", "codex-windows-sandbox-setup")
        }
        output = self.output(self.receipt(
            package_id=owner["id"], target=owner["targets"][0],
        ))
        with patch.dict(RUNNER.RUNTIME_TEST_HELPERS, self.declared_helpers, clear=True):
            for arguments in (["-p", "codex-exec-server", "--locked"], ["--workspace", "--locked"]):
                with self.subTest(arguments=arguments):
                    env, build = self.prepare(arguments, output=output, environment=existing)
                    self.assertEqual(env, {**existing, "CARGO_BIN_EXE_bwrap": str(self.executable)})
                    build.assert_called_once()
                    command = build.call_args.args[0]
                    self.assertIn(owner["id"], command)
                    self.assertEqual(
                        [command[index + 1] for index, value in enumerate(command) if value == "--bin"],
                        ["bwrap"],
                    )

'''
assert candidate[PATHS[3]].count(anchor) == 1
candidate[PATHS[3]] = candidate[PATHS[3]].replace(anchor, test + anchor)

rows = []
patch = ""
for path in PATHS:
    before = original[path].encode()
    after = candidate[path].encode()
    target = ROOT / "source" / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(after)
    rows.append({"path": path, "mode": "100644", "before": digest(before), "after": digest(after)})
    patch += "".join(difflib.unified_diff(
        original[path].splitlines(keepends=True), candidate[path].splitlines(keepends=True),
        fromfile="a/" + path, tofile="b/" + path,
    ))
(ROOT / "repair.patch").write_text(patch)
(ROOT / "source-manifest.json").write_text(json.dumps({
    "schema": "hepta.exec-fake-bwrap-r23-repair.sources.v1",
    "status": "ISOLATED_CANDIDATE_NOT_APPLIED_NOT_RUST_TESTED",
    "base_commit": "50dd4bedefcd1b8e2e8cd5cf5023c60a86d38d0a",
    "base_tree": "be34ab1afe622ad3b8f030c8c5018f4f54fbc304",
    "files": rows,
    "patch": {"path": "repair.patch", **digest(patch.encode())},
}, indent=2) + "\n")
print(json.dumps({"files": rows, "patch": digest(patch.encode())}, indent=2))
