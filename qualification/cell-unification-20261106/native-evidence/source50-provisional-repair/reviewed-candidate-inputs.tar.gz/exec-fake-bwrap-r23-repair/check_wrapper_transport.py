#!/usr/bin/env python3
"""Check the exact shell body with a local recorder, not a sandbox or Rust run."""

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
source = (ROOT / "source/codex-rs/exec-server/tests/common/fake_bwrap.rs").read_text()
body = re.search(r'r#"(set -euo pipefail\n.*?)"#,', source, re.S).group(1)
records = []
with tempfile.TemporaryDirectory(prefix="bwrap-transparent-shell-") as directory:
    directory = Path(directory)
    executable = directory / "vendor 'quote' $(false)"
    executable.write_text(
        f"#!{sys.executable}\n"
        "import json,os,sys\n"
        "fd=int(os.environ['TEST_INHERITED_FD'])\n"
        "print(json.dumps({'argv':sys.argv[1:],'inherited_fd_open':os.fstat(fd).st_ino>0}))\n"
    )
    executable.chmod(0o700)
    wrapper = directory / "bwrap"
    quoted = str(executable).replace("'", "'\\''")
    wrapper.write_text(f"#!/bin/bash\nreal_bwrap='{quoted}'\n" + body)
    wrapper.chmod(0o700)
    syntax = subprocess.run(["/bin/bash", "-n", str(wrapper)], capture_output=True, check=False)
    assert syntax.returncode == 0, syntax.stderr
    read_fd, write_fd = os.pipe()
    try:
        environment = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "TEST_INHERITED_FD": str(read_fd)}
        marker = Path(str(wrapper) + ".fail-once")
        log = Path(str(wrapper) + ".log")
        marker.touch()
        probes = [
            ["--help"],
            ["--unshare-user", "--unshare-net", "--ro-bind", "/", "/", "/bin/true"],
            ["--unshare-pid", "--", "/bin/true"],
        ]
        for arguments in probes:
            result = subprocess.run([str(wrapper), *arguments], env=environment, pass_fds=(read_fd,), capture_output=True, check=False)
            observed = json.loads(result.stdout)
            assert result.returncode == 0
            assert observed == {"argv": arguments, "inherited_fd_open": True}
            assert marker.exists() and not log.exists()
            records.append({"kind": "probe_passthrough", "argv": arguments, "exit_code": result.returncode, "observed": observed})
        arguments = ["--as-pid-1", "--unshare-pid", "--argv0", "test argv0", "--preserve-fds", str(read_fd), "--", "/inner command", "argument with spaces", "'literal'", "$(false)"]
        first = subprocess.run([str(wrapper), *arguments], env=environment, pass_fds=(read_fd,), capture_output=True, check=False)
        assert first.returncode == 125 and first.stdout == b""
        assert first.stderr == b"forced fake bwrap failure\n"
        assert not marker.exists()
        assert log.read_text() == " ".join(arguments) + "\n"
        second = subprocess.run([str(wrapper), *arguments], env=environment, pass_fds=(read_fd,), capture_output=True, check=False)
        observed = json.loads(second.stdout)
        assert second.returncode == 0 and second.stderr == b""
        assert observed == {"argv": arguments, "inherited_fd_open": True}
        assert log.read_text() == (" ".join(arguments) + "\n") * 2
        records.append({"kind": "fail_once_then_full_argv_and_fd_passthrough", "argv": arguments, "first_exit_code": first.returncode, "second_exit_code": second.returncode, "observed": observed, "logged_invocations": 2})
    finally:
        os.close(read_fd)
        os.close(write_fd)
report = {
    "schema": "hepta.exec-fake-bwrap-r23-local-shell-transport.v1",
    "candidate_rust_source_sha256": hashlib.sha256(source.encode()).hexdigest(),
    "shell_body_sha256": hashlib.sha256(body.encode()).hexdigest(),
    "result": "PASS_LOCAL_SYNTHETIC_SHELL_TRANSPORT",
    "scope": "Exact candidate shell body plus its statically reviewed quoted-path prefix; recorder executable only. No Rust generator, real bwrap, PID namespace, pidfd, native task or network was executed.",
    "records": records,
}
(ROOT / "evidence/local-shell-transport.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"result": report["result"], "records": len(records)}))
