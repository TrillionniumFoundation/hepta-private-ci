#!/usr/bin/env python3
"""Freeze exact reviewed r23 fixture repairs; does not apply or test them."""
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
BASE_COMMIT = "50dd4bedefcd1b8e2e8cd5cf5023c60a86d38d0a"
BASE_TREE = "be34ab1afe622ad3b8f030c8c5018f4f54fbc304"

def pins(b):
    return {"bytes": len(b), "sha256": hashlib.sha256(b).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(b)).encode() + b"\0" + b).hexdigest()}

def save(path, b):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == b, path
    else:
        path.write_bytes(b)

def jsave(path, data):
    save(path, (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode())

def tree_sha(leaves):
    root = {}
    for path, item in leaves.items():
        node = root
        parts = path.split("/")
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        assert parts[-1] not in node
        node[parts[-1]] = (item["mode"], item["sha"])
    def walk(node):
        content = b""
        for name, value in sorted(node.items(), key=lambda kv: (kv[0] + ("/" if isinstance(kv[1], dict) else "")).encode()):
            mode, sha = ("40000", walk(value)) if isinstance(value, dict) else value
            content += mode.encode() + b" " + name.encode() + b"\0" + bytes.fromhex(sha)
        return hashlib.sha1(b"tree " + str(len(content)).encode() + b"\0" + content).hexdigest()
    return walk(root)

framework = json.loads(gzip.decompress((ROOT / "recovery-independent-readback/input/original-framework-recursive-reserialized.json.gz").read_bytes()))
assert not framework["truncated"]
leaves = {r["path"]: {"mode": r["mode"], "sha": r["sha"], "type": r["type"]} for r in framework["tree"] if r["type"] != "tree"}
old = json.loads((ROOT / "native-validation-results/checkpoint-r23/evidence/native-candidate-r22-source.json").read_text())
assert old["source_commit"] == BASE_COMMIT and old["source_tree"] == BASE_TREE
changed = {r["path"]: dict(r) for r in old["changed_files"]}
for path, row in changed.items():
    data = (ROOT / "hepta-cell" / path).read_bytes()
    assert pins(data) == {k: row[k] for k in ("bytes", "sha256", "git_blob")}, path
    leaves[path] = {"mode": row["mode"], "sha": row["git_blob"], "type": "blob"}
assert tree_sha(leaves) == BASE_TREE

sources = [
    ("cli-telemetry-r23-repair", [{**json.loads((ROOT / "cli-telemetry-r23-repair/repair-audit.json").read_text())}]),
    ("network-proxy-r23-repair", json.loads((ROOT / "network-proxy-r23-repair/source-manifest.json").read_text())["files"]),
    ("exec-fake-bwrap-r23-repair", json.loads((ROOT / "exec-fake-bwrap-r23-repair/source-manifest.json").read_text())["files"]),
    ("external-agent-marketplace-r23-repair", json.loads((ROOT / "external-agent-marketplace-r23-repair/source-manifest.json").read_text())["files"]),
]
files = []
patches = []
for group, rows in sources:
    for row in rows:
        path = row["path"]
        before_dir = "before" if group == "cli-telemetry-r23-repair" else "original"
        before = (ROOT / group / before_dir / path).read_bytes()
        after = (ROOT / group / "source" / path).read_bytes()
        for b, key in [(before, "before"), (after, "after")]:
            assert pins(b) == {k: row[key][k] for k in ("bytes", "sha256", "git_blob")}, (path, key)
        mode = row.get("mode", row["before"].get("mode", "100644"))
        assert leaves[path] == {"mode": mode, "sha": pins(before)["git_blob"], "type": "blob"}, path
        files.append({"path": path, "mode": mode, "before": pins(before), "after": pins(after), "candidate_group": group})
        save(OUT / "original" / path, before)
        save(OUT / "source" / path, after)
        patches.extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile="a/" + path, tofile="b/" + path))

path = ".github/workflows/hepta-cell-framework-native.yml"
before = (ROOT / "hepta-cell" / path).read_bytes()
text = before.decode()
edits = [
    ("              -p codex-hepta-memory-extension\n", "              -p codex-hepta-memory-extension -p codex-network-proxy\n"),
    ("            packages: -p codex-core -p codex-mcp -p core_test_support\n", "            packages: -p codex-core -p codex-mcp -p core_test_support -p codex-external-agent-migration\n"),
    ("            packages: -p codex-app-server -p codex-app-server-client\n", "            packages: -p codex-app-server -p codex-app-server-client -p codex-cli\n"),
]
for a, b in edits:
    assert text.count(a) == 1
    text = text.replace(a, b)
after = text.encode()
inverse = text
for a, b in reversed(edits):
    assert inverse.count(b) == 1
    inverse = inverse.replace(b, a)
assert inverse.encode() == before
assert pins(before)["git_blob"] == leaves[path]["sha"]
files.append({"path": path, "mode": "100644", "before": pins(before), "after": pins(after), "candidate_group": "root-ci-owner-selectors"})
save(OUT / "original" / path, before)
save(OUT / "source" / path, after)
patches.extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile="a/" + path, tofile="b/" + path))
assert len(files) == len({r["path"] for r in files}) == 9

for row in files:
    path = row["path"]
    leaves[path] = {"mode": row["mode"], "sha": row["after"]["git_blob"], "type": "blob"}
    changed[path] = {"path": path, **row["after"], "mode": row["mode"]}
candidate_tree = tree_sha(leaves)
selectors = re.findall(r"-p ([a-zA-Z0-9_-]+)", text.split("    steps:", 1)[0])
assert len(selectors) == len(set(selectors)) == 27
assert {"codex-cli", "codex-exec-server", "codex-network-proxy", "codex-external-agent-migration"} <= set(selectors)
patch = "".join(patches).encode()
save(OUT / "combined.patch", patch)
plan = {
    "schema": "hepta.source50-provisional-r23-repair-plan.v1",
    "status": "FROZEN_REPAIR_INPUT_BAZEL_LOCK_UPDATE_AND_NATIVE_QUALIFICATION_PENDING",
    "before_commit": BASE_COMMIT, "before_tree": BASE_TREE,
    "provisional_after_tree": candidate_tree,
    "source_commit_created": False,
    "lock_update_required": True,
    "lock_note": "Actual just bazel-lock-update must run; any real lock changes require an updated source identity before Rust gates.",
    "files": files, "combined_patch": pins(patch),
    "changed_files_over_framework": sorted(changed.values(), key=lambda r: r["path"]),
    "changed_file_count": len(changed),
    "changed_rust_file_count": sum(p.endswith(".rs") for p in changed),
    "ci_selectors": selectors,
    "required_native_gate_sequence": [
        "just bazel-lock-update after exact nine-file application and before source identity freeze",
        "python3 -m unittest discover -s scripts -p test_run_nextest*.py -v",
        "just clippy --locked -p codex-cli -p codex-exec-server -p codex-network-proxy -p codex-external-agent-migration -- -D warnings",
        "just test --locked -p codex-cli -p codex-exec-server -p codex-network-proxy -p codex-external-agent-migration --retries 0",
        "just test --locked --retries 0 with unchanged 193 default workspace members",
        "only after required gates pass: final scoped just fix --locked, then just fmt; no later local tests",
    ],
    "original_assertions_timeouts_retries_filters_features_ignored_reporting_preserved": True,
    "rust_executed": False, "native_applied": False, "science_verdict": "HOLD", "authority": "DENY_ALL",
}
jsave(OUT / "PLAN.json", plan)
jsave(OUT / "LEAF-MAP.json", leaves)
buf = io.BytesIO()
with tarfile.open(fileobj=buf, mode="w") as tf:
    for relative in ["PLAN.json", "combined.patch"] + ["source/" + r["path"] for r in files]:
        data = (OUT / relative).read_bytes()
        ti = tarfile.TarInfo(relative); ti.size = len(data); ti.mode = 0o644; ti.mtime = 0
        tf.addfile(ti, io.BytesIO(data))
archive = gzip.compress(buf.getvalue(), mtime=0)
save(OUT / "stage50-provisional-input.tar.gz", archive)
print(json.dumps({"files": len(files), "changed_paths": len(changed), "rust_paths": plan["changed_rust_file_count"], "provisional_tree": candidate_tree, "plan": pins((OUT / "PLAN.json").read_bytes()), "archive": pins(archive)}, indent=2))
