#!/usr/bin/env python3
"""Read-only, target-bound /proc sampling for the separately reviewed r19d run."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import time


MARKER = re.compile(r'marker="(codex-command-exec-marker-[0-9]+)"')
STATUS_FIELDS = {
    "Name", "State", "Tgid", "Pid", "PPid", "TracerPid", "NSpid", "NSpgid",
    "NSsid", "NoNewPrivs", "Seccomp",
}


class IdentityUnverified(Exception):
    pass


class IdentityChanged(Exception):
    pass


def stamp():
    return {"time_ns": time.time_ns(), "monotonic_ns": time.monotonic_ns()}


def bounded_text(path, limit=65536):
    with path.open("rb") as handle:
        data = handle.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f"bounded read exceeded {limit}: {path}")
    return data.decode("utf-8", errors="replace")


def optional_read(path, errors, label):
    try:
        return bounded_text(path)
    except OSError as error:
        errors[label] = {"type": type(error).__name__, "errno": error.errno}
        return None


def snapshot(pid, expected_starttime=None, expected_ppid=None):
    base = Path("/proc") / str(pid)
    raw_stat = bounded_text(base / "stat")
    closing = raw_stat.rfind(")")
    if closing < 0:
        raise ValueError("invalid proc stat")
    fields = raw_stat[closing + 2:].split()
    item = {
        "pid": pid,
        "state": fields[0],
        "ppid": int(fields[1]),
        "pgid": int(fields[2]),
        "sid": int(fields[3]),
        "starttime_ticks": int(fields[19]),
    }
    if expected_starttime is not None and item["starttime_ticks"] != expected_starttime:
        raise IdentityChanged("PID birth identity changed before sample")
    if expected_starttime is None and item["ppid"] != expected_ppid:
        raise IdentityUnverified(
            f"first parent {item['ppid']} does not match mapped parent {expected_ppid}"
        )
    errors = {}
    item["comm"] = optional_read(base / "comm", errors, "comm")
    status = optional_read(base / "status", errors, "status")
    if status is not None:
        item["status"] = {
            key: value.strip()
            for line in status.splitlines()
            if ":" in line
            for key, value in [line.split(":", 1)]
            if key in STATUS_FIELDS
        }
    item["security_context"] = optional_read(base / "attr/current", errors, "attr/current")
    for label, path in [("exe", base / "exe"), ("pid_namespace", base / "ns/pid")]:
        try:
            item[label] = os.readlink(path)
        except OSError as error:
            errors[label] = {"type": type(error).__name__, "errno": error.errno}
    try:
        command = bounded_text(base / "cmdline")
        argv = command.split("\0")
        item["argv0"] = argv[0]
        item["marker_arguments"] = [
            value for value in argv if re.fullmatch(r"codex-command-exec-marker-[0-9]+", value)
        ]
    except OSError as error:
        errors["cmdline"] = {"type": type(error).__name__, "errno": error.errno}
    children = set()
    try:
        tasks = sorted((base / "task").iterdir(), key=lambda path: int(path.name))
        if len(tasks) > 128:
            errors["children_bound"] = {"threads": len(tasks), "sampled": 128}
        for task in tasks[:128]:
            try:
                children.update(int(value) for value in bounded_text(task / "children").split())
            except OSError as error:
                errors[f"children/{task.name}"] = {"type": type(error).__name__, "errno": error.errno}
    except OSError as error:
        errors["task"] = {"type": type(error).__name__, "errno": error.errno}
    item["children"] = sorted(children)
    item["errors"] = errors
    final_stat = bounded_text(base / "stat")
    final_closing = final_stat.rfind(")")
    if final_closing < 0:
        raise ValueError("invalid final proc stat")
    final_fields = final_stat[final_closing + 2:].split()
    if int(final_fields[19]) != item["starttime_ticks"]:
        raise IdentityChanged("PID birth identity changed across sample reads")
    return item


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--ready", required=True, type=Path)
    parser.add_argument("--stop", required=True, type=Path)
    parser.add_argument("--summary", required=True, type=Path)
    parser.add_argument("--interval-ms", type=int, default=50)
    args = parser.parse_args()
    if args.interval_ms < 20 or args.interval_ms > 1000:
        raise ValueError("invalid bounded sampling interval")
    if not args.events.is_file() or args.stop.exists():
        raise ValueError("missing precreated event file or stale stop marker")
    for path in [args.output, args.ready, args.summary]:
        if path.exists():
            raise ValueError(f"refusing to replace existing evidence: {path}")

    # Roots come only from the reviewed target-marker pipe_spawn trace. Children
    # are discovered only through those PIDs' task children files, never a global
    # /proc scan or a search through other processes' arguments or environment.
    identities = {}
    active = {}
    known = {}
    events_seen = 0
    samples = 0
    failures = 0
    root_records = []
    started = stamp()
    with args.events.open("r", encoding="utf-8") as events, args.output.open("x") as output:
        def emit(value):
            output.write(json.dumps({**stamp(), **value}, sort_keys=True) + "\n")
            output.flush()

        args.ready.write_text(json.dumps({"pid": os.getpid(), **started}) + "\n")
        while not args.stop.exists():
            while True:
                position = events.tell()
                line = events.readline()
                if not line:
                    break
                if not line.endswith("\n"):
                    events.seek(position)
                    break
                events_seen += 1
                columns = line.rstrip("\n").split("\t", 5)
                if len(columns) != 6 or columns[3] != "pipe_spawn":
                    continue
                match = MARKER.search(columns[5])
                if match is None:
                    continue
                try:
                    root_pid = int(columns[4])
                    host_pid = int(columns[2])
                except ValueError:
                    emit({"kind": "invalid_target_spawn", "line_number": events_seen})
                    failures += 1
                    continue
                marker = match.group(1)
                root = {"marker": marker, "root_pid": root_pid, "host_pid": host_pid,
                        "trace_line": events_seen, "trace_unix_time_ns": columns[0]}
                root_records.append(root)
                emit({"kind": "target_root", **root})
                active.setdefault(root_pid, {"marker": marker, "root_pid": root_pid,
                                             "host_pid": host_pid,
                                             "relation": "original_spawn"})
                known.setdefault(marker, set()).add(root_pid)

            pending = list(active)
            visited = set()
            while pending:
                pid = pending.pop(0)
                if pid in visited or pid not in active:
                    continue
                visited.add(pid)
                owner = active[pid]
                try:
                    expected_parent = (
                        owner["host_pid"] if owner["relation"] == "original_spawn"
                        else owner["discovered_parent_pid"]
                    )
                    value = snapshot(pid, identities.get(pid), expected_parent)
                    birth = value["starttime_ticks"]
                    previous = identities.get(pid)
                    if previous is not None and previous != birth:
                        emit({"kind": "pid_reused_stop_tracking", **owner, "pid": pid,
                              "original_starttime_ticks": previous,
                              "observed_starttime_ticks": birth})
                        del active[pid]
                        continue
                    identities[pid] = birth
                    samples += 1
                    emit({"kind": "proc_sample", **owner, "process": value})
                    for child in value["children"]:
                        if child in active:
                            continue
                        seen = known[owner["marker"]]
                        if child in seen:
                            continue
                        if len(seen) >= 256:
                            emit({"kind": "descendant_bound_reached", **owner,
                                  "known_count": len(seen)})
                            failures += 1
                            break
                        seen.add(child)
                        active[child] = {"marker": owner["marker"],
                                         "root_pid": owner["root_pid"],
                                         "relation": "observed_child",
                                         "discovered_parent_pid": pid,
                                         "discovered_parent_starttime_ticks": birth}
                        pending.append(child)
                except (IdentityUnverified, IdentityChanged) as error:
                    failures += 1
                    emit({"kind": "identity_unknown_stop_tracking", **owner, "pid": pid,
                          "last_starttime_ticks": identities.get(pid),
                          "error_type": type(error).__name__, "error": str(error)})
                    del active[pid]
                except FileNotFoundError:
                    emit({"kind": "pid_no_longer_present", **owner, "pid": pid,
                          "last_starttime_ticks": identities.get(pid)})
                    del active[pid]
                except Exception as error:
                    failures += 1
                    emit({"kind": "sample_error", **owner, "pid": pid,
                          "error_type": type(error).__name__, "error": str(error)})
            time.sleep(args.interval_ms / 1000)
        emit({"kind": "sampler_stopped", "remaining_tracked_pids": sorted(active)})

    data = args.output.read_bytes()
    summary = {
        "started": started, "finished": stamp(), "interval_ms": args.interval_ms,
        "event_lines_read": events_seen, "target_roots": root_records,
        "sample_count": samples, "sampling_errors_or_bounds": failures,
        "observed_identities": identities, "remaining_tracked_pids": sorted(active),
        "output_bytes": len(data), "output_sha256": hashlib.sha256(data).hexdigest(),
        "read_only": True, "process_signals_sent": False,
        "limitations": [
            "Polling can miss children that reparent before their first observed child link.",
            "A process missing at first sample has no verified birth identity.",
            "An already reparented first sample is unknown unless its expected parent was verified before binding birth identity.",
            "Starttime is checked before and after each composite proc sample; a mismatch stops tracking.",
            "Proc access errors and missing comm tags mean unknown, not a zero parent-death signal.",
            "Wall-clock event times are not assumed monotonic; append order and monotonic sample time are recorded.",
            "No process environment or unrelated process command line is read.",
        ],
    }
    args.summary.write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
