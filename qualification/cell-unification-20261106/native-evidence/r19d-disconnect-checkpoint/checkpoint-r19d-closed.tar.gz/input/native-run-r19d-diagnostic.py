#!/usr/bin/env python3
"""One diagnostic gate; restore the reviewed source47 tree before returning."""

import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time


FROZEN = True
INPUT_ARCHIVE_SHA256 = "0e4ecdbcd03f8faf845719c3bf78aef5f9ab6ae6fb8894ef3be305c5592a0bb6"
INPUT_ARCHIVE_BYTES = 64252
PATCH_SHA256 = "12af1838f9a51b268c56a5ce845ad6bc11b61f15ba617d0aa1440f0878f15d01"
AUTHOR_MANIFEST_SHA256 = "f11ab70276daabbacd5accb110f5cea50cd849237af4fe926b67013eae3622c0"
SAMPLER_SHA256 = "b03a267ba546440fce9229ce74d4606f2eff8e25f504f2164fcc541afe616daa"
DIAGNOSTIC_TREE = "16a72fc0d8c808c2cd23ae477dd50559449fdbd9"
ROOT_REVIEW_SHA256 = "f49202866f70b01219bf97ebcd150f9c2ed9b356f6c09a763b01ae776f6433f6"
T = Path("/home/alex/work/hepta-cell-unified-20261106-a")
S = T / "source"
E = T / "evidence"
D = T / "r19d-diagnostic-input"
R = E / "r19-disconnect-diagnostic"
BASE_TREE = "cc2b01c2f69f43d63f8f5c561abd5e941d645769"
BASE_COMMIT = "0c78b43424ced27d37892a7744de065c1497d5e8"
FRAMEWORK_PARENT = "bef6fa7645df9df12b69fda499e97eed25de6c75"
LOCK_SHA256 = "4165307bb6c41d08e6c1c362060f2a958c8200ea43fdab2b8b1e6220ad82b55c"
BASE_MANIFEST_SHA256 = "64e26c5c3340b27d6b64b7342fac8561300224f9f1e96c22f2aa23b184eafee3"
ALLOWED_PATHS = {
    "codex-rs/app-server/src/command_exec.rs",
    "codex-rs/utils/pty/src/process_group.rs",
    "codex-rs/utils/pty/src/pipe.rs",
    "codex-rs/linux-sandbox/src/linux_run_main.rs",
}
COMMAND = ["just", "test", "--locked", "-p", "codex-app-server", "--retries", "0"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=S, text=True).strip()


def write_json(path, value):
    data = (json.dumps(value, indent=2) + "\n").encode()
    with path.open("xb") as handle:
        handle.write(data)
    return {"path": str(path), "bytes": len(data), "sha256": sha(data)}


def file_pin(path, tree):
    raw = (S / path).read_bytes()
    entry = git("ls-tree", tree, "--", path).split("\t")[0].split()
    assert len(entry) == 3 and entry[1] == "blob", (path, entry)
    blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    assert entry[2] == blob, (path, "index/worktree blob mismatch")
    mode = "100755" if (S / path).stat().st_mode & 0o111 else "100644"
    assert mode == entry[0], (path, "mode mismatch")
    return {"path": path, "bytes": len(raw), "sha256": sha(raw),
            "git_blob": blob, "mode": mode}


def guards(tree, files):
    actual = git("write-tree")
    unstaged = git("diff", "--name-only").splitlines()
    untracked = git("ls-files", "--others", "--exclude-standard").splitlines()
    mismatches = []
    for item in files:
        try:
            if file_pin(item["path"], tree) != item:
                mismatches.append(item["path"])
        except Exception as error:
            mismatches.append({"path": item["path"], "error": repr(error)})
    lock = sha((S / "codex-rs/Cargo.lock").read_bytes())
    return {"expected_tree": tree, "actual_tree": actual,
            "unstaged_paths": unstaged, "untracked_paths": untracked,
            "file_mismatches": mismatches, "lock_sha256": lock,
            "pass": actual == tree and not unstaged and not untracked
                    and not mismatches and lock == LOCK_SHA256}


def extract_input():
    raw = (T / "r19d-diagnostic-input.tar.gz").read_bytes()
    assert len(raw) == INPUT_ARCHIVE_BYTES and sha(raw) == INPUT_ARCHIVE_SHA256
    D.mkdir(exist_ok=False)
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
        for member in archive.getmembers():
            relative = Path(member.name)
            assert member.isfile() and not relative.is_absolute() and ".." not in relative.parts
            target = D / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as handle:
                handle.write(archive.extractfile(member).read())
    manifest_raw = (D / "source-manifest.json").read_bytes()
    assert sha(manifest_raw) == AUTHOR_MANIFEST_SHA256
    assert sha((D / "diagnostic.patch").read_bytes()) == PATCH_SHA256
    assert sha((D / "proc_sampler.py").read_bytes()) == SAMPLER_SHA256
    manifest = json.loads(manifest_raw)
    assert manifest["base_tree"] == BASE_TREE and manifest["base_commit"] == BASE_COMMIT
    assert {item["path"] for item in manifest["files"]} == ALLOWED_PATHS
    assert manifest["qualification"] is False
    return manifest


def environment():
    env = os.environ.copy()
    env.update({
        "PATH": str(T / "bin") + ":/home/alex/.cargo/bin:" + env.get("PATH", ""),
        "RUSTUP_TOOLCHAIN": "1.96.0", "CARGO_BUILD_JOBS": "2",
        "CARGO_TARGET_DIR": str(T / "target"), "CARGO_NET_GIT_FETCH_WITH_CLI": "true",
        "NEXTEST_TEST_THREADS": "2", "PYTHONDONTWRITEBYTECODE": "1",
        "CARGO_PROFILE_TEST_DEBUG": "0", "CARGO_PROFILE_DEV_DEBUG": "0",
        "HEPTA_R19_DIAGNOSTIC_PATH": str(R / "host-events.tsv"),
    })
    for key in ["CARGO_INCREMENTAL", "CARGO_BUILD_TARGET", "RUSTFLAGS"]:
        env.pop(key, None)
    for key, value in json.loads((E / "agentd-prerequisite-env.json").read_text()).items():
        if key in {"RUSTY_V8_ARCHIVE", "RUSTY_V8_SRC_BINDING_PATH", "PROTOC",
                   "PROTOC_INCLUDE", "DOTSLASH_CACHE"}:
            env[key] = value
    return env


def run():
    assert FROZEN, "Unfrozen preparation cannot execute"
    assert all(len(value) == 64 for value in [INPUT_ARCHIVE_SHA256, PATCH_SHA256,
                                            AUTHOR_MANIFEST_SHA256, SAMPLER_SHA256])
    assert len(DIAGNOSTIC_TREE) == 40
    base_raw = (E / "native-candidate-r19-source.json").read_bytes()
    assert sha(base_raw) == BASE_MANIFEST_SHA256
    base_manifest = json.loads(base_raw)
    assert base_manifest["source_tree"] == BASE_TREE
    assert len(base_manifest["changed_files"]) == 181
    before = guards(BASE_TREE, base_manifest["changed_files"])
    assert before["pass"], before
    assert shutil.disk_usage(T).free > 20 * 1024**3, "insufficient free task filesystem space"
    manifest = extract_input()
    root_review_raw = (T / "r19d-root-independent-review.json").read_bytes()
    assert sha(root_review_raw) == ROOT_REVIEW_SHA256
    declared_files = {item["path"]: item for item in base_manifest["changed_files"]}
    for item in manifest["files"]:
        raw = (S / item["path"]).read_bytes()
        assert len(raw) == item["before"]["bytes"] and sha(raw) == item["before"]["sha256"]
        assert file_pin(item["path"], BASE_TREE)["git_blob"] == item["before"]["git_blob"]
        declared_files[item["path"]] = {
            "path": item["path"], **item["after"],
            "mode": file_pin(item["path"], BASE_TREE)["mode"],
        }
    expected_diagnostic_files = [declared_files[path] for path in sorted(declared_files)]
    assert len(expected_diagnostic_files) == 185
    R.mkdir(exist_ok=False)
    with (R / "root-independent-review.json").open("xb") as handle:
        handle.write(root_review_raw)
    (R / "host-events.tsv").open("xb").close()
    write_json(R / "preconditions.json", {"diagnostic_only": True, "qualification": False,
               "baseline": before, "baseline_manifest_sha256": sha(base_raw),
               "input_archive_sha256": INPUT_ARCHIVE_SHA256,
               "root_independent_review_sha256": ROOT_REVIEW_SHA256,
               "free_bytes": shutil.disk_usage(T).free})
    applied = False
    diag_tree = None
    source_manifest = None
    rust_process = None
    sampler = None
    sampler_output = None
    test_rc = None
    sampler_rc = None
    process_started_at = None
    process_ended_at = None
    raw_result_written = False
    failure = None
    issues = []
    restored = False

    def note_issue(phase, error):
        nonlocal failure
        issue = {"phase": phase, "type": type(error).__name__, "error": repr(error)}
        issues.append(issue)
        if failure is None:
            failure = issue
        try:
            write_json(R / f"issue-{len(issues):03d}.json", issue)
        except Exception as record_error:
            issues.append({"phase": "issue-persistence", "type": type(record_error).__name__,
                           "error": repr(record_error)})
            try:
                print(json.dumps({"phase": "r19d-bookkeeping-error", "issue": issue,
                                  "persistence_error": repr(record_error)}), flush=True)
            except Exception:
                pass

    def persist_raw_process_result():
        nonlocal raw_result_written
        if raw_result_written or test_rc is None:
            return
        raw = {"schema": "hepta.native-raw-process-result.v1", "phase": "r19d-tests-diagnostic",
               "diagnostic_only": True, "qualification": False, "source_tree": diag_tree,
               "command": COMMAND, "cwd": str(S / "codex-rs"),
               "start_unix": process_started_at, "end_unix": process_ended_at,
               "exit_code": test_rc, "log_and_resource_hashing_pending": True}
        # The controller's durable stdout also retains the actual return code.
        # No log/resource read, source guard, or sampler cleanup precedes this.
        print(json.dumps({"phase": "r19d-raw-process-return", **raw}), flush=True)
        write_json(R / "tests-raw-process-result.json", raw)
        raw_result_written = True
    try:
        subprocess.run(["git", "apply", "--check", "--index", str(D / "diagnostic.patch")], cwd=S, check=True)
        subprocess.run(["git", "apply", "--index", str(D / "diagnostic.patch")], cwd=S, check=True)
        applied = True
        diag_tree = git("write-tree")
        assert diag_tree == DIAGNOSTIC_TREE, diag_tree
        assert set(git("diff", "--name-only", BASE_TREE, diag_tree).splitlines()) == ALLOWED_PATHS
        for item in manifest["files"]:
            actual = file_pin(item["path"], diag_tree)
            assert all(actual[key] == item["after"][key] for key in ["bytes", "sha256", "git_blob"])
        changed = git("diff", "--name-only", FRAMEWORK_PARENT, diag_tree).splitlines()
        assert len(changed) == 185, len(changed)
        files = [file_pin(path, diag_tree) for path in changed]
        assert files == expected_diagnostic_files
        source_manifest = {"schema": "hepta.native-r19d-diagnostic-source.v1",
                           "diagnostic_only": True, "qualification": False,
                           "baseline_source_commit": BASE_COMMIT, "baseline_tree": BASE_TREE,
                           "source_tree": diag_tree, "changed_files": files,
                           "diagnostic_paths": sorted(ALLOWED_PATHS),
                           "lock_sha256": LOCK_SHA256, "patch_sha256": PATCH_SHA256,
                           "author_manifest_sha256": AUTHOR_MANIFEST_SHA256}
        assert guards(diag_tree, files)["pass"]
        write_json(R / "source.json", source_manifest)
        for item in files:
            raw = subprocess.check_output(["git", "show", f"{diag_tree}:{item['path']}"], cwd=S)
            assert sha(raw) == item["sha256"]
            target = R / "source" / item["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as handle:
                handle.write(raw)
            target.chmod(0o755 if item["mode"] == "100755" else 0o644)
        env = environment()
        selected = {key: env.get(key) for key in [
            "RUSTUP_TOOLCHAIN", "CARGO_BUILD_JOBS", "CARGO_TARGET_DIR",
            "NEXTEST_TEST_THREADS", "NEXTEST_PROFILE", "HEPTA_NEXTTEST_FULL_METADATA",
            "CARGO_PROFILE_TEST_DEBUG", "CARGO_PROFILE_DEV_DEBUG", "CARGO_INCREMENTAL",
            "CARGO_BUILD_TARGET", "RUSTFLAGS", "DOTSLASH_CACHE", "HEPTA_R19_DIAGNOSTIC_PATH",
        ]}
        write_json(R / "environment.json", {"source_tree": diag_tree, "selection": selected,
                   "extra_diagnostic_environment_key": "HEPTA_R19_DIAGNOSTIC_PATH",
                   "source_immutable_during_gate": True})
        sampler_args = [sys.executable, str(D / "proc_sampler.py"),
                        "--events", str(R / "host-events.tsv"),
                        "--output", str(R / "proc-samples.jsonl"),
                        "--ready", str(R / "sampler-ready.json"),
                        "--stop", str(R / "sampler-stop"),
                        "--summary", str(R / "sampler-summary.json")]
        sampler_output = (R / "sampler-process.log").open("xb")
        sampler = subprocess.Popen(sampler_args, cwd=T, env=env,
                                   stdout=sampler_output, stderr=subprocess.STDOUT)
        until = time.monotonic() + 5
        while not (R / "sampler-ready.json").is_file():
            assert sampler.poll() is None, "sampler failed before ready"
            assert time.monotonic() < until, "sampler not ready"
            time.sleep(0.01)
        log = R / "tests.log"
        resources = R / "tests.resources.txt"
        print(json.dumps({"phase": "r19d-start", "diagnostic_only": True,
                          "source_tree": diag_tree, "changed_file_count": len(files),
                          "command": COMMAND}), flush=True)
        process_started_at = time.time()
        with log.open("xb") as output:
            rust_process = subprocess.Popen(["/usr/bin/time", "-v", "-o", str(resources), *COMMAND],
                                            cwd=S / "codex-rs", env=env,
                                            stdout=output, stderr=subprocess.STDOUT)
            test_rc = rust_process.wait()
            process_ended_at = time.time()
            persist_raw_process_result()
        write_json(R / "tests-process-result.json", {
            "schema": "hepta.native-gate-receipt.v1", "phase": "r19d-tests-diagnostic",
            "source_tree": diag_tree, "diagnostic_only": True, "qualification": False,
            "source_manifest": "source.json", "environment_manifest": "environment.json",
            "baseline_source_commit": BASE_COMMIT,
            "command": COMMAND, "cwd": str(S / "codex-rs"), "packages": ["codex-app-server"],
            "start_unix": process_started_at, "end_unix": process_ended_at,
            "elapsed_seconds": process_ended_at - process_started_at,
            "exit_code": test_rc, "log_sha256": sha(log.read_bytes()),
            "resources_sha256": sha(resources.read_bytes()), "retries": 0,
        })
        post = guards(diag_tree, files)
        write_json(R / "post-test-source.json", post)
        assert post["pass"], post
    except Exception as error:
        note_issue("execution", error)
    finally:
        # Never kill a Rust subprocess, including when a bookkeeping error occurs.
        rust_terminal = rust_process is None
        try:
            if rust_process is not None:
                if rust_process.poll() is None:
                    test_rc = rust_process.wait()
                else:
                    test_rc = rust_process.returncode
                rust_terminal = True
                if process_ended_at is None:
                    process_ended_at = time.time()
                persist_raw_process_result()
        except Exception as error:
            note_issue("rust-process-result-cleanup", error)
        finally:
            try:
                if sampler is not None:
                    (R / "sampler-stop").touch(exist_ok=True)
                    sampler_rc = sampler.wait()
                    if sampler_output is not None:
                        sampler_output.close()
                    write_json(R / "sampler-process-result.json", {"exit_code": sampler_rc,
                               "sampler_sha256": SAMPLER_SHA256,
                               "log_sha256": sha((R / "sampler-process.log").read_bytes())})
                    if sampler_rc != 0:
                        note_issue("sampler", RuntimeError(f"sampler exit {sampler_rc}"))
            except Exception as error:
                note_issue("sampler-cleanup", error)
            finally:
                # Sampler cleanup or evidence failures must not skip restoration.
                # Conversely, restoration may never race an uncertain/live Rust job.
                if applied:
                    try:
                        assert rust_terminal, "Rust process termination is unconfirmed; retain frozen diagnostic tree"
                        # Unexpected tracked/source mutations are preserved for review.
                        post = guards(diag_tree, expected_diagnostic_files)
                        assert post["pass"], post
                        subprocess.run(["git", "restore", "--source=" + BASE_TREE,
                                        "--staged", "--worktree", "--", *sorted(ALLOWED_PATHS)],
                                       cwd=S, check=True)
                        restored_guard = guards(BASE_TREE, base_manifest["changed_files"])
                        write_json(R / "restored-source47.json", restored_guard)
                        restored = restored_guard["pass"]
                        assert restored, restored_guard
                    except Exception as error:
                        note_issue("restore", error)
    summary = {"diagnostic_only": True, "qualification": False,
               "baseline_tree": BASE_TREE, "diagnostic_tree": diag_tree,
               "test_exit_code": test_rc, "source47_restored_exactly": restored,
               "sampler_exit_code": sampler_rc,
               "failure": failure, "issues": issues, "raw_process_result_written": raw_result_written,
               "free_bytes_after": shutil.disk_usage(T).free,
               "fix_fmt_executed": False, "formal_source48_applied": False,
               "next_formal_gate_requires_no_live_diagnostic_payload": True}
    write_json(R / "complete.json", summary)
    print(json.dumps({"phase": "r19d-complete", **summary}), flush=True)
    return test_rc if restored and failure is None and test_rc is not None else 2


if __name__ == "__main__":
    sys.exit(run())
