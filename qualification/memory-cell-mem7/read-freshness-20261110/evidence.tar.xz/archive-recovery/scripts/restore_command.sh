umask 077
python3 - <<'PY'
import hashlib,pathlib,subprocess,sys
root=pathlib.Path('/home/qian-qi/mem6-cold-custody-20261110-ed353-v1')
script=root/'restore_archive.py'
if hashlib.sha256(script.read_bytes()).hexdigest()!='66abd7fd16340adfc41edaaba5a2a1a16cdd1fdbf2866b50a1e3f95667cee5e4':
 raise ValueError('pinned restore tool bytes differ')
raise SystemExit(subprocess.run([sys.executable,'-B',str(script),'--archive',str(root/'mem6-cas-001.tar.xz'),'--destination',str(root/'payload-recovery-8cf848ba-v1'),'--receipt',str(root/'RESTORE_RECEIPT.json')],check=False).returncode)
PY
