"""Copy the pinned original MEM6 archive through the existing MEM5 SSH channel.

Run on ai395 only. Never starts an actor, rebuilds an archive, changes SSH
configuration, overwrites an existing destination, or claims owner recovery.
"""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import stat
import subprocess


SOURCE = Path('/home/qq/mem6-attribution-20261110-484c/archive-v1/mem6-cas-001.tar.xz')
PARENT = '/home/qian-qi/mem6-cold-custody-20261110-ed353-v1'
TARGET = PARENT + '/mem6-cas-001.tar.xz'
AUDIT = Path('/home/qq/mem6-archive-copy-20261110-ed353-v1')
EXPECTED_VERSION = '66306:102004015:61412948:1794317318863616657:1794317318863616657'
EXPECTED_SHA = 'f77acd9feb27fda3f8000b0d089dbdbe258a4adfb7acedcb2e0cd590cc4f361e'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes', 'desktop']


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def pin_source():
    before = SOURCE.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError('source is not a regular file')
    version = ':'.join(str(v) for v in (
        before.st_dev, before.st_ino, before.st_size,
        before.st_mtime_ns, before.st_ctime_ns,
    ))
    if version != EXPECTED_VERSION:
        raise ValueError('original source version differs')
    digest = hashlib.sha256()
    with SOURCE.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    after = SOURCE.lstat()
    after_version = ':'.join(str(v) for v in (
        after.st_dev, after.st_ino, after.st_size,
        after.st_mtime_ns, after.st_ctime_ns,
    ))
    if version != after_version or digest.hexdigest() != EXPECTED_SHA:
        raise ValueError('original source changed or digest differs')
    return {'path': str(SOURCE), 'bytes': before.st_size,
            'sha256': digest.hexdigest(), 'version': version}


def command(name, argv, timeout=180):
    completed = subprocess.run(argv, capture_output=True, timeout=timeout, check=False)
    (AUDIT / (name + '.stdout')).write_bytes(completed.stdout)
    (AUDIT / (name + '.stderr')).write_bytes(completed.stderr)
    write(AUDIT / (name + '.json'), {'argv': argv, 'returncode': completed.returncode,
                                  'stdout_bytes': len(completed.stdout),
                                  'stderr_bytes': len(completed.stderr)})
    if completed.returncode:
        raise RuntimeError(name + ' failed; original output retained')
    return completed.stdout


def main():
    os.umask(0o077)
    AUDIT.mkdir(mode=0o700, exist_ok=False)
    before = pin_source()
    write(AUDIT / 'SOURCE_BEFORE.json', before)
    preflight = (
        "from pathlib import Path; import stat; "
        f"r=Path({PARENT!r}); p=Path({TARGET!r}); "
        "assert r.is_dir() and not r.is_symlink(); "
        "assert stat.S_IMODE(r.stat().st_mode)==0o700; "
        "assert not p.exists() and not p.is_symlink(); "
        "print('exclusive target absent')"
    )
    command('target-preflight', SSH + ['python3', '-c', shlex.quote(preflight)], 30)
    command('rsync', [
        'rsync', '-a', '--checksum', '--no-owner', '--no-group', '--ignore-existing',
        '-e', 'ssh -o BatchMode=yes -o StrictHostKeyChecking=yes',
        str(SOURCE), 'desktop:' + TARGET,
    ])
    after = pin_source()
    write(AUDIT / 'SOURCE_AFTER.json', after)
    readback = f"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,stat
p=Path({TARGET!r})
s=p.lstat()
if not stat.S_ISREG(s.st_mode) or s.st_size!=61412948:
 raise ValueError('destination is not the expected regular archive')
h=hashlib.sha256()
with p.open('rb') as f:
 for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
after=p.lstat()
identity=lambda st:(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
if h.hexdigest()!={EXPECTED_SHA!r} or identity(after)!=identity(s):
 raise ValueError('destination archive changed or SHA256 differs')
r={{'schema':'hepta.mem6.transfer-byte-readback.v1','host':'desktop',
    'path':str(p),'bytes':s.st_size,'sha256':h.hexdigest(),
    'created_at':datetime.now(timezone.utc).isoformat(),
    'source_host':'ai395','independent_trust_domain':False,
    'full_owner_cold_recovery':False,'archived_runtime_executed':False}}
with (p.parent/'TRANSFER_READBACK.json').open('x') as f:
 json.dump(r,f,indent=2,sort_keys=True);f.write('\\n')
print(json.dumps(r,sort_keys=True))
"""
    raw = command('target-readback', SSH + ['python3', '-c', shlex.quote(readback)], 60)
    result = {
        'schema': 'hepta.mem6.original-archive-copy.v1',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'source_before': before, 'source_after': after,
        'source_unchanged': before == after,
        'target_readback': json.loads(raw),
        'transport': 'existing MEM5 BatchMode StrictHostKeyChecking SSH desktop alias; rsync',
        'archive_regenerated': False, 'original_actor_reexecuted': False,
        'full_owner_cold_recovery': False, 'independent_trust_domain': False,
    }
    write(AUDIT / 'COPY_RECEIPT.json', result)
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
