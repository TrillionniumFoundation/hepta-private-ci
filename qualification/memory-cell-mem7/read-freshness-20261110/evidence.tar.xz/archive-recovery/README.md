# MEM6 original archive: second-host file restoration

The original pinned MEM6 CAS archive was copied from `ai395` to `desktop` through the existing MEM5 SSH alias. The archive bytes were not regenerated. Source version and full SHA256 matched before and after transfer. A separate configured-host file-info read verified the complete target archive. On desktop, the existing pinned `restore_archive.py` verified the whole archive, manifest, exact object set, logical paths and every restored file's bytes and SHA256 after reopening that file from disk.

The restoration verified **10,365 logical files / 243,281,645 bytes**, backed by **7,122 unique CAS objects / 149,046,627 bytes**. All seven receipt checks are true. The restore receipt was created at `2026-11-10T17:00:17.379823+00:00`. The copy job `1a1c662dd06-5074-ec` and restore job `1a1c6670efe-5074-ff` both have authoritative exit code 0, durable complete logs, and empty stderr.

## Evidence and execution

`SECOND_HOST_RESTORE_INDEX.json` binds the source descriptor, target archive, restoration tool, terminal jobs, receipt and each evidence file's exact bytes and SHA256. `RAW_TOOL_EVIDENCE.json` retains the native configured-host observations and authenticated operation-result payloads. The operation payload bytes were base64 decoded, checked against their declared total bytes and SHA256, then parsed. The exact executed commands are retained in `COPY_JOB.json` and `RESTORE_JOB.json`; the source copy script and fixed restore command are therefore reviewable without executing archived code.

The first synchronous copy and restore launch calls returned an MCP timeout, so no failure or success was inferred from those responses. Reissuing each exact request with its original idempotency key returned the original job with `reused: true` and terminal success. An initial direct receipt read returned a generic multi-file read error. A subsequent background read returned the complete receipt with its immutable-read version and SHA256. No uncertain effect was retried under a new key.

Transport reused `BatchMode=yes`, `StrictHostKeyChecking=yes` and the existing `desktop` alias, with rsync owner/group changes disabled and an exclusive new destination. New custody parents have mode 0700; no source archive, SSH configuration, keys or production owner credentials were changed. Archive and source capsule code were not executed; no actor was rerun.

## Scope that remains open

This closes **second-host complete archive verification and file restoration**. It does not close full owner or system capability recovery, independent trust-domain recovery, recovery of external runtime inputs or real effect state, or scientific memory-benefit acceptance. Those claims remain false or HOLD.

The prior cloud download and GitHub raw-archive publication remain incomplete. Their historical checkpoint describes 24,313,856 available bytes, a contiguous prefix of 24,117,248 bytes, and 567 missing chunks. This transfer did not fill or modify that partial cloud download and did not publish the 61,412,948-byte archive to GitHub. Publishing this small evidence bundle is not publication of the complete raw archive. Keep the historical partial-transfer index and missing ranges intact; record this second-host restoration as a separate accomplished milestone.

The local filesystem owners and output parents remain trusted. Hashes establish consistency with the supplied descriptor, not independent authorship. Evidence describes observed bytes and job outcomes; it does not protect against subsequent owner modification. Timestamps from different hosts are not asserted to establish a common global clock.
