"""Run the existing MEM focused suites on a clean, fixed source checkout."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path("/home/qq/mem7-freshness-ed353817")
SOURCE = ROOT / "source"
RECORDS = ROOT / "records" / "suite-run-001"
SOURCE_SHA = "4c3b1fb6d40de7c85aedd1964357e138fc7aa9d8"
TREE = "494fe36854e8d26cd9ae0b510e429fe931cef63d"
PYTHON = "/home/qq/hepta-smollm2-weight-research-20261103/ci-env/bin/python"
RUNTIME = "/home/qq/ndu-real-runtime-20261107-bc2efaf10cd0"
OCR_ROOT = RUNTIME + "/portable-ocr-v1/root"
GROUPS = [
    ("integrity", 180, 34, ["-m", "unittest", "-v",
        "ndu_real_runtime.test_episodic_memory", "ndu_real_runtime.test_episodic_retrieval",
        "ndu_real_runtime.test_episodic_qualification", "ndu_real_runtime.test_revocation_qualification"]),
    ("candidate", 300, 17, ["-m", "unittest", "-v",
        "ndu_real_runtime.test_candidate_memory", "ndu_real_runtime.test_candidate_runtime",
        "ndu_real_runtime.test_candidate_retention_report"]),
    ("selector", 120, 10, ["-m", "unittest", "-v",
        "ndu_real_runtime.test_candidate_selector", "ndu_real_runtime.test_selector_runtime"]),
    ("replay", 120, 6, ["-m", "unittest", "discover", "-s", "scripts/memory_cell_mem1",
        "-p", "test_coverage_control.py", "-v"]),
    ("trajectory", 120, 5, ["-m", "unittest", "discover", "-s", "scripts/memory_cell_mem1",
        "-p", "test_trajectory_coverage.py", "-v"]),
    ("selector-study", 120, 15, ["-m", "unittest", "-v",
        "ndu_real_runtime.test_candidate_selection_plan", "ndu_real_runtime.test_run_candidate_selection",
        "ndu_real_runtime.test_candidate_selection_report"]),
    ("candidate-runner", 180, 7, ["-m", "unittest", "-v",
        "ndu_real_runtime.test_run_candidate_retention"]),
    ("composition", 120, 7, ["-m", "unittest", "discover", "-s", "scripts/memory_cell_mem3",
        "-p", "test_mechanism.py", "-v"]),
    ("mem6", 240, 35, ["-m", "unittest", "-v",
        "ndu_real_runtime.test_candidate_retention_public_plan", "ndu_real_runtime.test_candidate_retention_public",
        "ndu_real_runtime.test_candidate_retention_public_actor", "ndu_real_runtime.test_candidate_retention_inference",
        "ndu_real_runtime.test_episodic_memory", "ndu_real_runtime.test_episodic_retrieval",
        "ndu_real_runtime.test_episodic_qualification"]),
]

def git(*args):
    return subprocess.check_output(["git", "-C", str(SOURCE), *args], text=True).strip()

def main():
    RECORDS.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    env.update({
        "SOURCE_SHA": SOURCE_SHA,
        "TESTED_SHA": SOURCE_SHA,
        "BASE_SHA": "137b8836c77ce95398677846ab122f08e866c5f1",
        "HEPTA_CI_LANE": "source-head",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(SOURCE / "scripts") + ":" + str(SOURCE) + ":" + RUNTIME + "/python-deps",
        "PATH": OCR_ROOT + "/usr/bin:" + env.get("PATH", "/usr/bin:/bin"),
        "LD_LIBRARY_PATH": OCR_ROOT + "/usr/lib/x86_64-linux-gnu",
        "TESSDATA_PREFIX": OCR_ROOT + "/usr/share/tesseract-ocr/5/tessdata",
        "TMPDIR": str(ROOT / "tmp"),
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
    })
    before = {"head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
              "status": git("status", "--porcelain")}
    if before != {"head": SOURCE_SHA, "tree": TREE, "status": ""}:
        raise RuntimeError("source does not match the clean frozen candidate")
    workflow = SOURCE / ".github/workflows/hepta-mem-python.yml"
    start = {"source": before, "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             "workflow_sha256": hashlib.sha256(workflow.read_bytes()).hexdigest(),
             "python": PYTHON, "purpose": "Existing focused regression suites only; no new real actor campaign"}
    (RECORDS / "START.json").write_text(json.dumps(start, indent=2) + "\n")
    print(json.dumps({"event": "started", **start}), flush=True)
    rows = []
    for name, timeout, minimum, arguments in GROUPS:
        record = RECORDS / (name + ".json")
        command = [PYTHON, str(SOURCE / "scripts/hepta_ci_exec.py"),
                   "--timeout-seconds", str(timeout), "--minimum-tests", str(minimum),
                   "--output", str(record), "--", PYTHON, "-B", *arguments]
        started = time.monotonic()
        with (RECORDS / (name + ".console.log")).open("x") as stream:
            completed = subprocess.run(command, cwd=SOURCE, env=env, stdout=stream, stderr=subprocess.STDOUT)
        row = {"group": name, "exit_code": completed.returncode, "elapsed_seconds": time.monotonic() - started,
               "record_path": str(record), "command": command}
        if record.exists():
            data = json.loads(record.read_text())
            row.update({key: data.get(key) for key in ("status", "observed_passed_tests", "observed_failed_tests",
                                                      "before", "after", "log_file", "log_sha256", "error")})
        else:
            row["status"] = "missing_execution_record"
        rows.append(row)
        print(json.dumps({"event": "group_complete", **row}), flush=True)
        (RECORDS / "PROGRESS.json").write_text(json.dumps(rows, indent=2) + "\n")
    after = {"head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
             "status": git("status", "--porcelain")}
    result = {"source": before, "after": after, "source_unchanged": before == after, "groups": rows,
              "all_groups_passed": before == after and all(row["exit_code"] == 0 and row["status"] == "passed" for row in rows),
              "summed_observed_passes": sum(row.get("observed_passed_tests") or 0 for row in rows),
              "summed_observed_failures": sum(row.get("observed_failed_tests") or 0 for row in rows),
              "limits": ["Repeated modules across required workflow groups are not independent tests or task episodes.",
                         "Torch/OCR fixtures use synthetic inputs and do not prove retention benefit or sealed task success.",
                         "No historical 276-actor experiment was rerun."]}
    (RECORDS / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"event": "finished", "all_groups_passed": result["all_groups_passed"],
                      "summed_observed_passes": result["summed_observed_passes"],
                      "summed_observed_failures": result["summed_observed_failures"],
                      "source_unchanged": result["source_unchanged"]}), flush=True)
    return 0 if result["all_groups_passed"] else 1

if __name__ == "__main__":
    sys.exit(main())

