"""Read and cross-check retained MEM unittest logs; never execute source tests."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

SOURCE = "4c3b1fb6d40de7c85aedd1964357e138fc7aa9d8"
TREE = "494fe36854e8d26cd9ae0b510e429fe931cef63d"
PARENT = "137b8836c77ce95398677846ab122f08e866c5f1"
DIRECTORIES = {"ai395-run001": "run001", "ai395-run002": "run002"}
HEADER = re.compile(r"^test_[^\n]+? \(([^)]+)\)", re.M)
FOOTER = re.compile(r"^Ran (\d+) tests? in [^\n]+\n\s*\n?(OK|FAILED)(?: \(([^\n]*)\))?\s*\Z", re.M)

def require(condition, message):
    if not condition:
        raise ValueError(message)

def inspect(root, directory, group, expected_pass):
    receipt_path = root / directory / (group + ".json")
    receipt = json.loads(receipt_path.read_text())
    require(receipt["source_sha"] == receipt["tested_sha"] == SOURCE, "source binding")
    require(receipt["lane"] == "source-head", "source lane")
    expected = {"commit": SOURCE, "tree": TREE, "parents": [PARENT], "dirty": False}
    require(receipt["before"] == receipt["after"] == expected, "clean exact identity")
    require(receipt["timed_out"] is False and receipt["output_limit_exceeded"] is False, "complete execution")
    filename = receipt["log_file"]
    require(Path(filename).name == filename, "log basename")
    path = root / directory / filename
    raw = path.read_bytes()
    require(len(raw) == receipt["log_bytes"], "log byte count")
    require(hashlib.sha256(raw).hexdigest() == receipt["log_sha256"], "log digest")
    text = raw.decode("utf-8")
    terminal = FOOTER.search(text)
    require(terminal is not None, "unittest terminal footer")
    require(len(re.findall(r"^Ran \d+ tests? in [^\n]+$", text, re.M)) == 1, "one terminal Ran summary")
    count, outcome, details = int(terminal[1]), terminal[2], terminal[3]
    fields = dict((k.strip(), int(v)) for k, v in re.findall(r"([a-z ]+)=(\d+)", details or ""))
    require(not any(fields.get(k, 0) for k in ("skipped", "expected failures", "unexpected successes")), "no skips/xfails")
    headers = list(HEADER.finditer(text[:terminal.start()]))
    require(len(headers) == count, "header count and Ran denominator")
    entries, exceptional = [], []
    for i, header in enumerate(headers):
        end = headers[i + 1].start() if i + 1 < len(headers) else terminal.start()
        segment = re.split(r"^[-=]{3,}\s*$", text[header.end():end], maxsplit=1, flags=re.M)[0]
        tail = [line.strip() for line in segment.splitlines() if line.strip()]
        require(bool(tail), "missing individual terminal outcome")
        last = tail[-1]
        status = "ok" if last == "ok" or last.endswith(" ... ok") or last == "... ok" else (
            "FAIL" if last == "... FAIL" or last.endswith(" ... FAIL") or last == "FAIL" else
            "ERROR" if last == "... ERROR" or last.endswith(" ... ERROR") or last == "ERROR" else None)
        require(status is not None, "unparsed individual terminal outcome: " + header[1])
        entries.append({"test_id": header[1], "status": status})
        first_line = text[header.start():].splitlines()[0]
        if not re.match(r"^test_[^\n]+? \([^)]+\) \.\.\. (?:ok|FAIL|ERROR)$", first_line):
            exceptional.append({"test_id": header[1], "header_line": text[:header.start()].count("\n") + 1,
                                "raw_entry": text[header.start():header.end()] + segment})
    statuses = Counter(entry["status"] for entry in entries)
    require(statuses["ok"] == receipt["observed_passed_tests"], "pass count from raw entries")
    require(statuses["FAIL"] + statuses["ERROR"] == receipt["observed_failed_tests"], "fail count from raw entries")
    if expected_pass:
        require(outcome == "OK" and details is None and statuses["ok"] == count, "unqualified OK footer")
        require(receipt["status"] == "passed", "passed receipt status")
        require(all(receipt[key] == 0 for key in ("returncode", "command_exit_code", "exit_code")), "successful exits")
    else:
        require(outcome == "FAILED" and fields == {"failures": 1}, "preserve original failure")
        require(receipt["status"] == "failed" and receipt["exit_code"] != 0, "failed receipt")
    return {"group": group, "artifact_directory": directory, "receipt": str(receipt_path.relative_to(root)),
            "log": str(path.relative_to(root)), "log_sha256": receipt["log_sha256"], "log_bytes": len(raw),
            "terminal_footer": terminal[0].strip(), "passed": statuses["ok"],
            "failed": statuses["FAIL"] + statuses["ERROR"], "skipped": 0, "entries": entries,
            "single_line_regex_misses": exceptional}

def audit(root):
    summary = json.loads((root / "AI395_FOCUSED_QUALIFICATION.json").read_text())
    latest = [inspect(root, DIRECTORIES[row["run"]], row["group"], True) for row in summary["latest_group_results"]]
    original = [inspect(root, "run001", row["group"], row["group"] not in {"candidate", "mem6"})
                for row in summary["latest_group_results"]]
    ids = [entry["test_id"] for row in latest for entry in row["entries"]]
    require(sum(row["passed"] for row in latest) == 152 and len(set(ids)) == 119, "latest denominator")
    require(sum(row["passed"] for row in original) == 150 and sum(row["failed"] for row in original) == 2,
            "original failure denominator")
    misses = [dict(group=row["group"], **miss) for row in latest for miss in row["single_line_regex_misses"]]
    require(len(misses) == 4, "single-line regex explanation")
    return {"schema": "hepta.mem7.raw-log-binding-audit.v1", "source_sha": SOURCE, "tree": TREE,
            "method": "Independently parse test headers into segments; require each final status, a unique Ran N/OK footer, no skipped/expected-failure footer fields, exact receipt log bytes/SHA and clean before/after source identity.",
            "path_mapping": DIRECTORIES,
            "run_field_meaning": "Local download staging label, not a package-relative directory or remote owner identity.",
            "latest": latest, "initial": original, "latest_passed_observations": 152,
            "latest_distinct_test_ids": 119, "latest_skips": 0,
            "initial_passed_observations": 150, "initial_failed_observations": 2,
            "single_line_regex_misses": misses,
            "limits": ["Internal source/log/receipt consistency only; no new tests executed or external trust-domain attestation."]}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("package", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.package)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("latest_passed_observations", "latest_distinct_test_ids",
                                                   "latest_skips", "initial_passed_observations",
                                                   "initial_failed_observations")}, indent=2))

