"""Prepared desktop-only lock generation/verification; do not run before review.

Input bytes, formatted source tree and tool hashes are mandatory. This creates a
new task checkout and caches; it never writes to the donor or old Bazel caches.
"""

import base64
import datetime
import hashlib
import json
import os
import pwd
import shutil
import signal
import subprocess
import sys
import time
import traceback
from pathlib import Path
from pathlib import PurePosixPath

BASE = '2ae5215beaf8d7b7df111a090b82134beae2683d'
BASE_TREE = '12159640adcf073b51f3837e75575e11f5c20233'
REPO = 'https://github.com/TrillionniumFoundation/hepta-private-ci.git'
TASK = Path('/home/qian-qi/mem8-integrated-bazel-lock-ed353817-v1')
SOURCE = TASK / 'source'
RECORDS = TASK / 'records'
TASK_CREATED = False


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def save(name, value):
    with (RECORDS / name).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def invoke(name, argv, *, cwd=TASK, timeout=120):
    started = now()
    started_clock = time.monotonic()
    with (RECORDS / (name + '.stdout')).open('xb') as out, (RECORDS / (name + '.stderr')).open('xb') as err:
        p = subprocess.Popen(argv, cwd=cwd, env=ENV, stdout=out, stderr=err, start_new_session=True)
        cleanup = {'owned_pgid': p.pid, 'new_session': True, 'required': False, 'signals': []}
        timed_out = False
        try:
            p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
        if timed_out or process_group_exists(p.pid):
            cleanup['required'] = True
            cleanup['reason'] = 'timeout' if timed_out else 'descendants remain after parent exit'
            for sig in [signal.SIGTERM, signal.SIGKILL]:
                if not process_group_exists(p.pid):
                    break
                try:
                    os.killpg(p.pid, sig)
                    cleanup['signals'].append({'signal': sig.name, 'at': now(), 'delivered': True})
                except ProcessLookupError:
                    cleanup['signals'].append({'signal': sig.name, 'at': now(), 'delivered': False, 'reason': 'group absent'})
                    break
                until = time.monotonic() + 5
                while process_group_exists(p.pid) and time.monotonic() < until:
                    p.poll()  # Reap this task's leader so its zombie does not hide group retirement.
                    time.sleep(0.1)
            cleanup['group_absent_after'] = not process_group_exists(p.pid)
        else:
            cleanup['group_absent_after'] = True
        try:
            p.wait(timeout=1)
            cleanup['parent_reaped'] = True
        except subprocess.TimeoutExpired:
            cleanup['parent_reaped'] = False
        result = {'command': argv, 'cwd': str(cwd), 'started_at': started,
                  'finished_at': now(), 'exit_code': p.returncode, 'timed_out': timed_out,
                  'timeout_seconds': timeout, 'elapsed_seconds': time.monotonic() - started_clock,
                  'cleanup': cleanup}
    save(name + '.json', result)
    print('MEM8_BAZEL_PHASE ' + json.dumps({'name': name, **result}), flush=True)
    return result


def process_group_exists(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False


def checked(name, argv, *, cwd=TASK, timeout=120):
    result = invoke(name, argv, cwd=cwd, timeout=timeout)
    if result['timed_out'] or result['exit_code'] != 0 or result['cleanup']['required']:
        raise RuntimeError('preparation phase failed: ' + name)


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], env=ENV, text=True).strip()


def identity(root):
    return {'commit': git(root, 'rev-parse', 'HEAD'), 'tree': git(root, 'rev-parse', 'HEAD^{tree}'),
            'status': git(root, 'status', '--porcelain=v1', '--untracked-files=normal')}


def commit_candidate(name, message):
    checked(name, ['git', '-c', 'user.name=MEM qualification',
                  '-c', 'user.email=mem-qualification@localhost',
                  'commit', '--no-gpg-sign', '-m', message], cwd=SOURCE)
    result = identity(SOURCE)
    if result['status']:
        raise RuntimeError('private candidate commit is dirty')
    save(name + '-identity.json', result)
    return result


def run_lock_phase(label, source_identity):
    record = RECORDS / (label + '.json')
    env = dict(ENV, SOURCE_SHA=source_identity['commit'], TESTED_SHA=source_identity['commit'],
               BASE_SHA=BASE, HEPTA_CI_LANE='source-head')
    argv = [sys.executable, '-B', str(SOURCE / 'scripts/hepta_ci_exec.py'), '--output', str(record),
            '--minimum-tests', '0', '--timeout-seconds', str(INPUT['phase_timeout_seconds']),
            '--', INPUT['just_executable'], 'bazel-lock-update']
    started = now()
    # hepta_ci_exec owns the command's bounded process group and full raw log.
    # Do not wrap it in a second subprocess timeout that could orphan that group.
    with (RECORDS / (label + '.wrapper.stdout')).open('xb') as out, (RECORDS / (label + '.wrapper.stderr')).open('xb') as err:
        p = subprocess.run(argv, cwd=SOURCE, env=env, stdout=out, stderr=err)
    receipt = json.loads(record.read_text())
    lock = (SOURCE / 'MODULE.bazel.lock').read_bytes()
    (RECORDS / (label + '.MODULE.bazel.lock.post')).write_bytes(lock)
    phase = {'label': label, 'wrapper_exit_code': p.returncode, 'started_at': started,
             'finished_at': now(), 'receipt': receipt, 'after': identity(SOURCE),
             'post_lock': {'bytes': len(lock), 'sha256': sha256(lock), 'git_blob': git_blob(lock)}}
    save(label + '-phase.json', phase)
    (RECORDS / (label + '.patch')).write_bytes(subprocess.check_output(
        ['git', '-C', str(SOURCE), 'diff', '--binary', 'HEAD'], env=ENV))
    if receipt.get('command_exit_code') != 0 or receipt.get('timed_out') or receipt.get('output_limit_exceeded'):
        raise RuntimeError('actual bazel command failed: ' + label)
    return phase


def main():
    global ENV, INPUT, TASK_CREATED
    if len(sys.argv) != 3:
        raise SystemExit('usage: driver.py INPUT.json EXPECTED_INPUT_SHA256')
    input_bytes = Path(sys.argv[1]).read_bytes()
    if sha256(input_bytes) != sys.argv[2]:
        raise RuntimeError('input capsule digest mismatch')
    INPUT = json.loads(input_bytes)
    if pwd.getpwuid(os.getuid()).pw_name != 'qian-qi' or not Path('/home/qian-qi').is_dir():
        raise RuntimeError('this driver must execute on the desktop target account')
    if INPUT['base_commit'] != BASE or INPUT['base_tree'] != BASE_TREE:
        raise RuntimeError('unexpected integrated source base')
    if not 1 <= INPUT['phase_timeout_seconds'] <= 10800:
        raise RuntimeError('invalid fixed phase budget')
    if INPUT['execution_host'] != 'desktop':
        raise RuntimeError('execution_host must identify desktop, even over ai395 SSH')
    TASK.mkdir(mode=0o700)
    TASK_CREATED = True
    RECORDS.mkdir(mode=0o700)
    (TASK / 'bin').mkdir(mode=0o700)
    ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0',
               PYTHONDONTWRITEBYTECODE='1', RUSTUP_TOOLCHAIN='1.96.0',
               BAZELISK_HOME=str(TASK / 'bazelisk-home'))
    ENV['PATH'] = ':'.join([str(TASK / 'bin'), str(Path(INPUT['just_executable']).parent),
                            '/home/qian-qi/.cargo/bin', '/home/qian-qi/.local/bin', os.environ.get('PATH', '')])
    save('INPUT.json', INPUT)
    save('LOCK_BUDGET.json', {
        'fixed_lock_phase_timeout_seconds': INPUT['phase_timeout_seconds'],
        'maximum_lock_phase_count': 2,
        'total_lock_command_budget_seconds': 2 * INPUT['phase_timeout_seconds'],
        'preparation_command_budget_seconds': 120,
        'fetch_base_budget_seconds': 300,
        'preparation_pgid_cleanup_seconds': {'SIGTERM_grace': 5, 'SIGKILL_grace': 5, 'leader_reap': 1},
        'scope_note': 'Lock-command budget is separate from recorded bounded preparation and cleanup; no claim of a single whole-driver wall deadline.'})
    save('EXECUTION_HOST.json', {'execution_host': 'desktop', 'observed_hostname': os.uname().nodename,
          'uid': os.getuid(), 'user': pwd.getpwuid(os.getuid()).pw_name, 'started_at': now(),
          'transport': INPUT['transport'], 'input_sha256': sys.argv[2],
          'disk': dict(zip(['total', 'used', 'free'], shutil.disk_usage(TASK)))})
    donor = Path(INPUT['donor'])
    donor_before = identity(donor)
    save('DONOR_BEFORE.json', donor_before)
    tool_before = {}
    for kind in ['bazel', 'just']:
        path = Path(INPUT[kind + '_executable'])
        data = path.read_bytes()
        tool_before[kind] = {'path': str(path), 'bytes': len(data), 'sha256': sha256(data)}
        if tool_before[kind]['sha256'] != INPUT[kind + '_sha256']:
            raise RuntimeError(kind + ' tool bytes differ from the reviewed input')
    save('TOOLS_BEFORE.json', tool_before)
    wrapper = ('#!/usr/bin/python3\nimport os,sys\nreal=' + repr(INPUT['bazel_executable']) +
               '\nos.execv(real,[real,"--batch","--noexperimental_remote_repo_contents_cache",' +
               repr('--output_base=' + str(TASK / 'output-base')) + ',*sys.argv[1:],' +
               repr('--repo_contents_cache=' + str(TASK / 'repo-contents-cache')) + ',' +
               repr('--repository_cache=' + str(TASK / 'repository-cache')) + '])\n')
    launcher = TASK / 'bin/bazel'
    launcher.write_text(wrapper)
    launcher.chmod(0o700)
    save('CACHE_ISOLATION.json', {'wrapper': wrapper, 'wrapper_sha256': sha256(wrapper.encode()),
          'old_cache_cleanup_or_writes_requested': False, 'new_task_root': str(TASK)})
    checked('bazel-version', [INPUT['bazel_executable'], '--version'])
    checked('just-version', [INPUT['just_executable'], '--version'])
    checked('clone', ['git', 'clone', '--shared', '--no-checkout', str(donor), str(SOURCE)])
    checked('origin', ['git', '-C', str(SOURCE), 'remote', 'set-url', 'origin', REPO])
    probe = invoke('base-object', ['git', '-C', str(SOURCE), 'cat-file', '-e', BASE + '^{commit}'])
    if probe['cleanup']['required']:
        raise RuntimeError('base-object probe required process-group cleanup')
    if probe['exit_code'] != 0 or probe['timed_out']:
        checked('fetch-base', ['git', '-C', str(SOURCE), 'fetch', '--filter=blob:none', '--depth=1', 'origin', BASE], timeout=300)
    checked('sparse', ['git', '-C', str(SOURCE), 'sparse-checkout', 'set', '--cone',
                      'codex-rs', 'scripts', '.github', 'tools', 'bazel', 'patches', 'docs'])
    checked('checkout-base', ['git', '-C', str(SOURCE), 'checkout', '--detach', BASE])
    if identity(SOURCE) != {'commit': BASE, 'tree': BASE_TREE, 'status': ''}:
        raise RuntimeError('new checkout is not the exact clean integration base')
    source_version = (SOURCE / '.bazelversion').read_text().strip()
    version_output = (RECORDS / 'bazel-version.stdout').read_text().strip()
    if source_version != '9.3.0' or version_output != 'bazel 9.3.0':
        raise RuntimeError('the pinned Bazel tool/source version differs')
    seen = set()
    for entry in INPUT['files']:
        path = PurePosixPath(entry['path'])
        if path.is_absolute() or '..' in path.parts or '.git' in path.parts or path.as_posix() in seen:
            raise RuntimeError('unsafe or duplicate capsule path')
        seen.add(path.as_posix())
        before = entry['preimage_git_blob']
        if before is not None:
            if git(SOURCE, 'rev-parse', BASE + ':' + path.as_posix()) != before:
                raise RuntimeError('capsule preimage mismatch: ' + str(path))
        else:
            existing = subprocess.run(['git', '-C', str(SOURCE), 'cat-file', '-e',
                                       BASE + ':' + path.as_posix()], env=ENV,
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if existing.returncode == 0 or (SOURCE / str(path)).exists():
                raise RuntimeError('new capsule file already exists: ' + str(path))
        data = base64.b64decode(entry['content_base64'], validate=True)
        if len(data) != entry['postimage_bytes'] or sha256(data) != entry['postimage_sha256'] or git_blob(data) != entry['postimage_git_blob']:
            raise RuntimeError('capsule postimage mismatch: ' + str(path))
        if entry['mode'] not in ['100644', '100755']:
            raise RuntimeError('unsupported source file mode')
        output = SOURCE / str(path)
        if not output.resolve().is_relative_to(SOURCE.resolve()) or output.is_symlink():
            raise RuntimeError('capsule destination escapes source or is a symlink')
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(data)
        output.chmod(0o755 if entry['mode'] == '100755' else 0o644)
    checked('stage-candidate', ['git', '-C', str(SOURCE), 'add', '--', *sorted(seen)])
    if git(SOURCE, 'write-tree') != INPUT['candidate_tree']:
        raise RuntimeError('formatted source capsule tree mismatch')
    candidate = commit_candidate('candidate-commit', 'Qualification-only formatted MEM integration candidate')
    phase1 = run_lock_phase('lock-generate', candidate)
    changed = git(SOURCE, 'diff', '--name-only', 'HEAD').splitlines()
    phases = [phase1]
    if changed:
        if changed != ['MODULE.bazel.lock'] or phase1['after']['status'] != 'M MODULE.bazel.lock':
            raise RuntimeError('Bazel changed a source path other than MODULE.bazel.lock')
        # Preserve the real first receipt: its strict clean-tree check fails
        # after expected lock generation. Never relabel that receipt as passed.
        save('LOCK_GENERATION_REVIEW.json', {'state': 'new lock generated; review required before final publication',
              'first_receipt_status': phase1['receipt'].get('status'), 'first_wrapper_exit': phase1['wrapper_exit_code'],
              'published_reference_updated': False})
        checked('stage-lock', ['git', '-C', str(SOURCE), 'add', '--', 'MODULE.bazel.lock'])
        candidate = commit_candidate('lock-commit', 'Qualification-only generated Bazel lock postimage')
        phases.append(run_lock_phase('lock-freshness', candidate))
    last = phases[-1]
    if last['wrapper_exit_code'] != 0 or last['receipt'].get('status') != 'passed' or last['after']['status']:
        raise RuntimeError('final exact-source clean lock freshness gate did not pass')
    donor_after = identity(donor)
    save('DONOR_AFTER.json', donor_after)
    if donor_after != donor_before:
        raise RuntimeError('original donor identity changed during qualification')
    tool_after = {}
    for kind in ['bazel', 'just']:
        path = Path(INPUT[kind + '_executable'])
        data = path.read_bytes()
        tool_after[kind] = {'path': str(path), 'bytes': len(data), 'sha256': sha256(data)}
    save('TOOLS_AFTER.json', tool_after)
    if tool_after != tool_before:
        raise RuntimeError('a bound tool executable changed during qualification')
    lock = (SOURCE / 'MODULE.bazel.lock').read_bytes()
    (RECORDS / 'MODULE.bazel.lock.post').write_bytes(lock)
    save('RESULT.json', {'status': 'passed_local_candidate_lock_gate', 'finished_at': now(),
          'execution_host': 'desktop', 'base_commit': BASE, 'base_tree': BASE_TREE,
          'input_candidate_tree': INPUT['candidate_tree'], 'qualified_local_source': candidate,
          'post_lock': {'bytes': len(lock), 'sha256': sha256(lock), 'git_blob': git_blob(lock)},
          'phase_receipts': [p['label'] + '.json' for p in phases],
          'first_generation_had_lock_drift': bool(changed), 'native_tests_executed': 0,
          'model_requests': 0, 'published_reference_updated': False,
          'review_before_final_source_publication_required': True})
    print('MEM8_BAZEL_RESULT ' + (RECORDS / 'RESULT.json').read_text(), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        failure = traceback.format_exc()
        if TASK_CREATED and RECORDS.is_dir():
            with (RECORDS / 'DRIVER_FAILURE.txt').open('x') as stream:
                stream.write(failure)
        print(failure, file=sys.stderr, flush=True)
        raise
