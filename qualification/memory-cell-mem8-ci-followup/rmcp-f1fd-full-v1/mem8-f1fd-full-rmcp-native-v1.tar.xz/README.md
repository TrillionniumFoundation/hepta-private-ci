# Complete RMCP qualification on original f1fd

This is one fresh complete native run on commit f1fd544b3e12ed6aca83872cdeda8114a1e058c0, tree fff40d06312d4f6a185772cd8a62a618d55f31cf. It is not assembled from the earlier dc96 265-pass/3-fail run and separate three-case retry.

The same-source CLI build exited0, the original268 selected unique RMCP cases passed with zero selected skips and zero retries, and scoped just fix exited0 without modifying the source. Seven tests remained filtered/ignored in the original suite selection. All268 original IDs equal both the JUnit IDs and the268 uniquely numbered PASS lines in the complete raw log. The raw log and JUnit share UUID b86c9959-e257-4ce0-91e0-f2eb7120d2cc. The real CLI SHA256 is unchanged before and after consumer execution.

The build and fix phases each executed zero tests; their success is not added to the test count. Each phase retained its original1,800-second command budget, exact-head clean before/after identities, complete raw stream, wrapper stdout/stderr, and receipt. The command includes compilation; the JUnit test execution duration is39.869 seconds, while the full test command took473.109 seconds. Full native PTY output and terminal exit0 are included.

The source Git commits dc96 and f1fd were published with their original identities. Independent GitHub readback verifies all65 changed paths, modes and actual postimage blobs. The complete65-file source archive and same-f1fd Matrix30-pass evidence already exist at the immutable pointers in source/EXISTING_MATRIX_SOURCE_EVIDENCE_MANIFEST.json. This package includes original source publication intents, not a recreated commit. The initial PR body is a historical checkpoint and accurately labeled pending at creation; this later evidence supplies the final RMCP outcome.

The prior dc96 failures and separate three-case pass remain in their original archive, Git blob64610662ba7dbeac2bf6a9e664d18cb23a391ac4. This result qualifies only this package/source/platform. It does not qualify the later integrated source, all hosted CI, other platforms, production owner custody, a real-provider outcome, or memory benefit.

Run python3 verify_evidence.py PATH_TO_EXTRACTED_PACKAGE. The verifier checks every packaged member, all three full raw hashes, exact-head/clean receipts, the fresh JUnit UUID, original268 unique IDs against both JUnit and raw PASS lines, CLI binding and clean scoped fix. FILE_MANIFEST.json excludes itself to avoid a hash cycle.
