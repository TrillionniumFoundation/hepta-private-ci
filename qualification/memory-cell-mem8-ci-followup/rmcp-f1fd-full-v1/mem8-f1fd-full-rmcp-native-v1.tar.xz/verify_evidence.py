import hashlib
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

HEAD = "f1fd544b3e12ed6aca83872cdeda8114a1e058c0"
TREE = "fff40d06312d4f6a185772cd8a62a618d55f31cf"
BASE = "96038ccf0660154fac143ba6cbe4be81e00813e8"
COMMANDS = {
    "same-source-codex-cli-build": ["cargo", "build", "--locked", "-p", "codex-cli", "--bin", "codex"],
    "full-rmcp-268": ["just", "test", "--locked", "-p", "codex-rmcp-client", "--test-threads", "2", "--no-tests", "fail", "--retries", "0"],
    "scoped-rmcp-fix": ["just", "fix", "--locked", "-p", "codex-rmcp-client"],
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify(root):
    root = Path(root)
    records = root / "records"
    phases = {}
    raw_text = {}
    for name, command in COMMANDS.items():
        receipt = json.loads((records / (name + ".json")).read_text())
        audit = json.loads((records / (name + ".audit.json")).read_text())
        assert receipt["command"] == command == audit["command"]
        assert receipt["status"] == "passed" and receipt["command_exit_code"] == receipt["exit_code"] == 0
        assert receipt["returncode"] == 0 and audit["wrapper_exit_code"] == 0
        assert not receipt["timed_out"] and not receipt["output_limit_exceeded"]
        assert receipt["source_sha"] == receipt["tested_sha"] == HEAD
        assert receipt["base_sha"] == BASE and receipt["lane"] == "source-head"
        assert receipt["before"] == receipt["after"]
        assert receipt["before"]["commit"] == HEAD and receipt["before"]["tree"] == TREE
        assert receipt["before"]["dirty"] is False
        assert audit["before"] == audit["after"] and audit["before"]["dirty"] is False
        assert audit["before"]["commit"] == HEAD and audit["before"]["tree"] == TREE
        assert audit["gate_passed"] is True and audit["command_budget_seconds"] == 1800
        log_file = receipt["log_file"]
        assert Path(log_file).name == log_file
        raw = (records / log_file).read_bytes()
        assert len(raw) == receipt["log_bytes"] and sha(raw) == receipt["log_sha256"]
        assert len(raw) == audit["log_bytes"] and sha(raw) == audit["log_sha256"]
        raw_text[name] = re.sub(r"\x1b\[[0-9;]*m", "", raw.decode())
        phases[name] = receipt
    expected_bytes = (root / "EXPECTED_CASE_IDS.json").read_bytes()
    expected = [tuple(row) for row in json.loads(expected_bytes)]
    assert len(expected) == len(set(expected)) == 268
    assert expected == sorted(expected)
    inputs = json.loads((records / "INPUT.json").read_text())
    assert sha(expected_bytes) == inputs["expected_case_ids_sha256"]
    assert inputs["original_case_id_source_run"] == "c6520272-0490-4d9f-bee4-5d08be7198bd"
    data = (records / "full-rmcp-268.junit.xml").read_bytes()
    doc = ET.fromstring(data)
    cases = list(doc.iter("testcase"))
    ids = [(case.get("classname"), case.get("name")) for case in cases]
    assert len(ids) == len(set(ids)) == 268 and sorted(ids) == expected
    assert all(case.find("failure") is None and case.find("error") is None and case.find("skipped") is None for case in cases)
    assert doc.get("tests") == "268" and doc.get("failures") == doc.get("errors") == "0"
    uuid = doc.get("uuid")
    text = raw_text["full-rmcp-268"]
    assert text.count("Nextest run ID " + uuid) == 1
    passed = re.findall(r"^\s*PASS\s+\[[^\]]+\]\s+\(\s*(\d+)/268\)\s+(\S+)\s+(.+?)\s*$", text, re.MULTILINE)
    raw_ids = [(row[1], row[2]) for row in passed]
    assert len(raw_ids) == len(set(raw_ids)) == 268 and sorted(raw_ids) == expected
    assert sorted(int(row[0]) for row in passed) == list(range(1, 269))
    assert not re.search(r"^\s*(FAIL|LEAK|TIMEOUT|XPASS)\s+\[", text, re.MULTILINE)
    summaries = re.findall(r"Summary\s+\[[^]]+\]\s+268 tests run:\s+268 passed,\s+7 skipped", text)
    assert len(summaries) == 1
    assert phases["full-rmcp-268"]["observed_passed_tests"] == 268
    assert phases["full-rmcp-268"]["observed_failed_tests"] == 0
    for name in ("same-source-codex-cli-build", "scoped-rmcp-fix"):
        assert phases[name]["observed_passed_tests"] == phases[name]["observed_failed_tests"] == 0
    audit = json.loads((records / "full-rmcp-268.audit.json").read_text())["junit"]
    assert audit["run_id"] == uuid and audit["sha256"] == sha(data) and audit["bytes"] == len(data)
    assert sorted(tuple(row) for row in audit["ids"]) == expected
    cli_before = json.loads((records / "CLI_BEFORE_TESTS.json").read_text())
    cli_after = json.loads((records / "CLI_AFTER_TESTS.json").read_text())
    assert cli_before["path"] == cli_after["path"]
    assert cli_before["bytes"] == cli_after["bytes"] == 1440865824
    assert cli_before["sha256"] == cli_after["sha256"] == "da59e2327aa74b81be2b6f64a97c060bf67e17db17c860f7642541f804dadbe2"
    assert cli_before["source"] == cli_after["source"]
    assert cli_before["source"]["commit"] == HEAD and cli_before["source"]["tree"] == TREE and not cli_before["source"]["dirty"]
    result = json.loads((records / "RESULT.json").read_text())
    assert all(result[key] is True for key in ("built", "full_rmcp_268_passed", "scoped_fix_passed_clean", "cli_hash_unchanged_during_tests", "qualification_passed"))
    assert result["source"] == cli_after["source"]
    assert result["whole_ci_pass_claimed"] is False and result["memory_benefit_claimed"] is False
    manifest_path = root / "FILE_MANIFEST.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        actual = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file() and path != manifest_path}
        assert actual == {row["path"] for row in manifest["files"]}
        for row in manifest["files"]:
            path = root / row["path"]
            data = path.read_bytes()
            assert len(data) == row["bytes"] and sha(data) == row["sha256"], row["path"]
    return {
        "source_commit": HEAD, "source_tree": TREE, "base": BASE,
        "selected": 268, "passed": 268, "failed": 0, "selected_skipped": 0,
        "filtered_or_ignored": 7, "retries": 0, "junit_run_id": uuid,
        "original_unique_case_ids_match": True, "raw_unique_pass_ids_match_junit": True,
        "full_raw_hashes_verified": 3, "full_junit_hash_verified": True,
        "cli_before_after_same": True, "cli_sha256": cli_before["sha256"],
        "scoped_fix_exit_zero_and_source_unchanged": True,
        "all_phase_source_identities_clean": True,
        "whole_ci_pass_claimed": False, "memory_benefit_claimed": False,
    }


if __name__ == "__main__":
    print(json.dumps(verify(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent), indent=2))
