## Problem and exact review base

The MEM8 common source still carries a dependency graph that fails the dependency gate and requires coherent SQLite/RMCP consumer updates. This PR extracts the dependency closure from #5865 and adds the measured Matrix development-profile fix. It excludes that upstream PR's unrelated recovery tests, qualification files, and diagnostic SDK/test changes.

This is a draft against #5873's frozen common branch, not a moving main branch:

- Base: `96038ccf0660154fac143ba6cbe4be81e00813e8`.
- Original dependency commit: `dc96a441312e239c165c1642880084dfeccc2c71`, tree `7796279284170f0f2c92449c1185eecac1f4f1b6`.
- Original production-profile head: `f1fd544b3e12ed6aca83872cdeda8114a1e058c0`, tree `fff40d06312d4f6a185772cd8a62a618d55f31cf`.

The two native Git commits were pushed with their original identities. Independent GitHub readback matches all **65 changed paths**, their modes, blob SHAs, and the actual native postimages. No source commit was reconstructed from an evidence bundle.

## Changes and attribution

The selected dependency work comes from #5865 at `6ecfa504d2132f3682ffb01f8c9d65346b26cf5b`; the earlier SQLx syntax/byte review retains its own exact `72251601928807febae580dbd7754edac20bda10` identity.

The 65-path closure contains:

- The complete 57-file `sqlx-sqlite-0.9.0` vendor inventory, with both manifest ranges extended from `>=0.30.1, <0.38.0` to `>=0.30.1, <0.40.0`.
- Two existing Matrix SQLite vendor manifests.
- The root Rust manifest and Cargo/Bazel locks.
- RMCP compatibility updates in `auth_status.rs` and `mcp_2026_oauth_discovery.rs`.
- `MODULE.bazel` for the matching development-profile optimization.

The graph selects rusqlite 0.41.1, libsqlite3-sys 0.39.1, and rmcp 3.9.0. The existing Matrix encryption development optimization is retained. The second commit adds optimization of the locked `sha2:0.11.1` dependency and equivalent Bazel annotations for encryption and SHA-2. The actual Matrix SDK and tests are restored to their original bytes; the five-second test budget, 200,000 KDF rounds, and original assertions remain unchanged.

## SQLx provenance and byte boundaries

The vendored crate is **not byte-identical to the official crate**. Of its 51 Rust files, 44 differ and seven match; both manifests differ, while the other four files match. The earlier normalized-syntax comparison and negative controls support the specific syntax-equivalence finding at their pinned input, not upstream byte identity or a complete official-to-candidate Rustfmt replay.

Relative to the reviewed 722/6ec vendor, the final candidate additionally removes trailing whitespace from three Rustdoc lines in `src/connection/deserialize.rs`; two of those lines carried Markdown hard-break whitespace. The root manifest comment now accurately discloses the formatting/import differences. All 57 final SQLx files match between dc96 and f1fd.

An earlier evidence README referred to an “existing exact-upstream-byte preservation condition” without a repository rule establishing it. That statement is withdrawn in the subsequent erratum; the original archive remains unchanged. The actual applicable instructions require the repository formatter, scoped tests/fix, and lock update. The formatter includes changed Rust vendor files and explicitly uses `imports_granularity=Item`; no vendor exemption or exact-byte preservation rule was found in the reviewed scope. This clarification does not substitute for consumer validation.

## Actual validation, with source identities kept separate

| Source | Actual result | Boundary |
| --- | --- | --- |
| dc96 | Isolated-cache `just bazel-lock-update` exited 0; source and locks unchanged | The prior shared-cache failure is preserved separately |
| dc96 | Original RMCP run: **265 passed, 3 failed**, 268 unique selected cases; seven filtered/ignored, no selected skips | Not relabeled as a 268-pass run |
| dc96 | The original three failing cases, rerun with a CLI built from the same dc96 source: **3 passed, 0 failed**, zero retries; CLI digest unchanged before/after | A separate native run with its own UUID and raw/JUnit |
| f1fd | Original Matrix suite: **30 passed, 0 failed**, two filtered/ignored; scoped fix exited 0 and source stayed clean | The earlier diagnostic and compile-only timeout attempts remain archived |
| f1fd | Fresh same-source CLI build: **exit 0**, clean source before/after | A build is not counted as a test |
| f1fd | Fresh complete RMCP command started **2026-11-11 05:48:01 UTC**, with a 1,800-second command budget | Final 268-case raw/JUnit and subsequent scoped fix are still pending at this PR checkpoint |

The new f1fd command is `just test --locked -p codex-rmcp-client --test-threads 2 --no-tests fail --retries 0`. It binds the actual CLI binary to f1fd, requires the original 268 unique IDs and a fresh JUnit UUID matching the raw log, checks the binary digest before/after, and then runs `just fix --locked -p codex-rmcp-client`. Any source rewrite fails qualification rather than being attributed to the original head.

Full raw logs, original JUnit, failure history, binary/source receipts, and actual source postimages are preserved on the separate evidence PR #5889. Its current checkpoint is `0e1817df5e97b6cf4916a6b0ca7b43602c03fd4e`. The Matrix production archives and the dc96 split-run RMCP archive have been fully read back and independently audited. New f1fd results will be appended with their own identity.

## Remaining qualification

This draft does not claim all hosted CI, all platforms, a completed f1fd RMCP run, or the entire dependency/advisory gate has passed. Current-head hosted dependency/lock/consumer checks remain separately observable gates. No advisory is ignored, CI threshold relaxed, assertion skipped, model request made, or memory/production-owner capability inferred by this change.

