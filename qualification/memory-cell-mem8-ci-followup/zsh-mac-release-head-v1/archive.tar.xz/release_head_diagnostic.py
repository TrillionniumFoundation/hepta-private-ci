#!/usr/bin/env python3
"""One bounded HEAD-only observation; never save headers, redirect URLs, or stderr."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
from urllib.parse import urlsplit


URL = 'https://github.com/openai/codex/releases/download/rust-v0.104.0/codex-shell-tool-mcp-npm-0.104.0.tgz'
RUN = Path('/Users/qianqi/mem8-zsh-mac-release-head-ed353817-v1')
CURL = Path('/usr/bin/curl')
MARKER = 'MEM_FIXED_HEAD_RESULT '


def safe_hostname(value):
    try:
        hostname = urlsplit(value).hostname
    except ValueError:
        return 'INVALID_HOSTNAME'
    if not hostname or not re.fullmatch(r'[A-Za-z0-9.-]{1,253}', hostname):
        return 'INVALID_HOSTNAME'
    return hostname.lower()


def main():
    started = time.time()
    deadline = time.monotonic() + 20
    if sys.platform != 'darwin':
        raise RuntimeError('this observation is restricted to the configured Mac host')
    RUN.mkdir(mode=0o700, exist_ok=False)
    os.chmod(RUN, 0o700)
    result = {
        'schema': 'mem-zsh-mac-release-head-observation-v1',
        'run_id': 'mem8-zsh-mac-release-head-ed353817-v1',
        'scope': 'CURRENT_HEAD_ONLY_AVAILABILITY_NOT_ORIGINAL_DOWNLOAD_OUTCOME',
        'started_utc': datetime.fromtimestamp(started, timezone.utc).isoformat(),
        'total_budget_seconds': 20, 'request_chain_budget_seconds': 15,
        'connect_budget_seconds': 5, 'max_https_redirects': 3,
        'method': 'HEAD', 'initial_hostname': 'github.com',
        'final_http_status': None, 'error_category': None,
        'redirect_hostnames_observed': [], 'redirects_followed_by_curl': None,
        'final_hostname': None, 'curl_exit_code': None,
        'model_requests_issued_by_driver': 0, 'zsh_controls_executed': 0,
        'bundle_download_attempted': False,
        'raw_headers_redirect_queries_stderr_saved': False,
        'logical_probe_invocations': 0,
        'caller_retries': 0,
        'exit_code_interpretation': 'Observation recorded; never a connectivity or original-download PASS.',
    }
    try:
        driver = Path(__file__).read_bytes()
        with (RUN / 'DRIVER.py').open('xb') as stream:
            stream.write(driver)
        result['driver_sha256'] = hashlib.sha256(driver).hexdigest()
        if not CURL.is_file() or not os.access(CURL, os.X_OK):
            raise FileNotFoundError('fixed system curl is unavailable')
        argv = [str(CURL), '--disable', '--head', '--location', '--max-redirs', '3',
                '--connect-timeout', '5', '--max-time', '15',
                '--proto', '=https', '--proto-redir', '=https',
                '--silent', '--show-error', '--output', '/dev/null',
                '--dump-header', '-', '--write-out',
                '\n' + MARKER + '%{http_code} %{num_redirects} %{url_effective}\n', URL]
        result['logical_probe_invocations'] = 1
        child = subprocess.Popen(argv, cwd=RUN, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, start_new_session=True)
        try:
            stdout, stderr = child.communicate(timeout=min(16, deadline - time.monotonic() - 1))
        except subprocess.TimeoutExpired:
            result['error_category'] = 'SUPERVISOR_WAIT_TIMEOUT'
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = child.communicate(timeout=max(0, min(1, deadline - time.monotonic())))
        result['curl_exit_code'] = child.returncode
        text = stdout.decode('utf-8', errors='replace')
        for line in text.splitlines():
            if line.lower().startswith('location:'):
                result['redirect_hostnames_observed'].append(safe_hostname(line.split(':', 1)[1].strip()))
            elif line.startswith(MARKER):
                fields = line[len(MARKER):].split(' ', 2)
                if len(fields) == 3 and re.fullmatch(r'[0-9]{3}', fields[0]) and fields[1].isdigit():
                    result['final_http_status'] = int(fields[0]) or None
                    result['redirects_followed_by_curl'] = int(fields[1])
                    result['final_hostname'] = safe_hostname(fields[2])
        categories = {5: 'PROXY_RESOLUTION_FAILED', 6: 'HOST_RESOLUTION_FAILED',
                      7: 'CONNECT_FAILED', 28: 'CURL_DEADLINE_EXCEEDED',
                      35: 'TLS_HANDSHAKE_FAILED', 47: 'REDIRECT_LIMIT_REACHED',
                      51: 'TLS_PEER_VERIFICATION_FAILED', 52: 'EMPTY_REPLY',
                      56: 'RECEIVE_FAILED', 60: 'TLS_CERTIFICATE_VERIFICATION_FAILED'}
        if result['error_category'] is None:
            if child.returncode:
                result['error_category'] = categories.get(child.returncode, 'CURL_NONZERO_EXIT')
            elif result['final_http_status'] is None:
                result['error_category'] = 'FINAL_HTTP_STATUS_NOT_OBSERVED'
        # Raw transport headers, redirect queries, and stderr remain in memory only.
        del stdout, stderr, text
    except BaseException as error:
        result['error_category'] = result['error_category'] or type(error).__name__
    finally:
        result['finished_utc'] = datetime.now(timezone.utc).isoformat()
        result['elapsed_seconds'] = time.time() - started
        with (RUN / 'RESULT.json').open('x') as stream:
            json.dump(result, stream, indent=2)
            stream.write('\n')
        print(json.dumps(result), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
