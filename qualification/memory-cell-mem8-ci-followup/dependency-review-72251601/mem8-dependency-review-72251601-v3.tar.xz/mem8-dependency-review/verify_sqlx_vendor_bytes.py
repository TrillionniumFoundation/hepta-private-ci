"""Verify the immutable candidate against the checksum-pinned official crate."""

import hashlib
import json
from pathlib import Path
import tarfile


ROOT = Path(__file__).resolve().parent
EXPECTED_ARCHIVE_SHA256 = "488e99c397a62007e4229aec669a179816339afc6d2620ca6fa420dbee2e982c"
archive_path = ROOT / "sqlx-sqlite-0.9.0.crate"
assert hashlib.sha256(archive_path.read_bytes()).hexdigest() == EXPECTED_ARCHIVE_SHA256
tree = json.loads((ROOT / "SQLX_VENDOR_TREE.json").read_text())
assert tree["sha"] == "4098a80235cfe8c3d4a20d1f591ee35ee418c051"
assert tree["truncated"] is False
tree_files = {row["path"]: row["sha"] for row in tree["tree"] if row["type"] == "blob"}
candidate_rows = json.loads((ROOT / "SQLX_CANDIDATE_FILES.json").read_text())
candidate_files = {row["path"]: row for row in candidate_rows}
assert len(candidate_files) == len(candidate_rows)


def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


original_files = {}
with tarfile.open(archive_path, "r:gz") as archive:
    for member in archive.getmembers():
        if not member.isfile():
            continue
        parts = Path(member.name).parts
        assert parts[0] == "sqlx-sqlite-0.9.0" and ".." not in parts
        path = "/".join(parts[1:])
        assert path not in original_files
        original_files[path] = archive.extractfile(member).read()
assert set(original_files) == set(candidate_files) == set(tree_files)
rows = []
for path, original in sorted(original_files.items()):
    candidate = candidate_files[path]["content"].encode()
    assert git_blob(candidate) == candidate_files[path]["sha"] == tree_files[path]
    expected = original
    manifest = path in {"Cargo.toml", "Cargo.toml.orig"}
    if manifest:
        assert original.count(b">=0.30.1, <0.38.0") == 1
        expected = original.replace(b">=0.30.1, <0.38.0", b">=0.30.1, <0.40.0")
        assert candidate == expected
    rows.append({
        "path": path,
        "original_bytes": len(original),
        "candidate_bytes": len(candidate),
        "original_git_blob": git_blob(original),
        "candidate_git_blob": git_blob(candidate),
        "original_sha256": hashlib.sha256(original).hexdigest(),
        "candidate_sha256": hashlib.sha256(candidate).hexdigest(),
        "original_candidate_bytes_equal": original == candidate,
        "expected_manifest_only_git_blob": git_blob(expected),
        "candidate_matches_manifest_only_expected": candidate == expected,
        "declared_manifest_range_change": manifest,
    })
unexpected = [row["path"] for row in rows
              if not row["candidate_matches_manifest_only_expected"]]
result = {
    "schema": "hepta.mem8.sqlx-existing-vendor-byte-review.v2",
    "source_sha": "72251601928807febae580dbd7754edac20bda10",
    "vendor_tree": tree["sha"],
    "official_archive_sha256": EXPECTED_ARCHIVE_SHA256,
    "official_file_count": len(original_files),
    "candidate_file_count": len(candidate_files),
    "exact_same_file_inventory": True,
    "verified_candidate_blob_count": len(rows),
    "only_two_manifest_ranges_changed": not unexpected,
    "declared_manifest_range_changes": [row["path"] for row in rows if row["declared_manifest_range_change"]],
    "other_byte_changed_paths": unexpected,
    "other_byte_changed_count": len(unexpected),
    "note": "The manifest-only byte-preservation proposition is false. Interpret Rust differences using the separate syntax review; successful audit execution is not a native build/test pass.",
    "rows": rows,
}
(ROOT / "SQLX_VENDOR_BYTE_REVIEW.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: value for key, value in result.items() if key not in {"rows", "other_byte_changed_paths"}}, indent=2))
