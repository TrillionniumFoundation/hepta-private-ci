# MEM8 review of the existing dependency candidate

This is read-only evidence for existing PR #5865, not a new dependency proposal or a native test result. The full vendor review is pinned to commit `72251601928807febae580dbd7754edac20bda10` and SQLx subtree `4098a80235cfe8c3d4a20d1f591ee35ee418c051`. The comparison source is MEM8 PR #5873 at `96038ccf0660154fac143ba6cbe4be81e00813e8`.

The subsequently observed #5865 head `6ecfa504d2132f3682ffb01f8c9d65346b26cf5b` is exactly one commit ahead of 7225160, changing only `hepta-agentd/src/learning_iteration_recovery_tests.rs`. Its dependency/vendor bytes are identical. That file-identity conclusion does not transfer any CI result between heads. The clock-bounded 01:22:20–01:22:25 UTC snapshot records native jobs and Windows private-state in progress; no completed current-head cargo-deny or consumer acceptance was observed.

## Official security sources

The four advisory documents are retained at RustSec advisory-db commit `28d73fc95e5972af3403225a217def57dcaba3c4`, with each document's immutable Git blob. The source versions actually locked on MEM8 are libsqlite3-sys 0.37.0 and rmcp 3.1.3.

| Official advisory | Published patched range | Existing candidate |
| --- | --- | --- |
| [RUSTSEC-2026-0459](https://rustsec.org/advisories/RUSTSEC-2026-0459.html) | libsqlite3-sys >=0.39.0 | 0.39.1 |
| [RUSTSEC-2026-0457](https://rustsec.org/advisories/RUSTSEC-2026-0457.html) | rmcp >=3.7.0 | 3.9.0 |
| [RUSTSEC-2026-0461](https://rustsec.org/advisories/RUSTSEC-2026-0461.html) | rmcp >=3.6.0 | 3.9.0 |
| [RUSTSEC-2026-0462](https://rustsec.org/advisories/RUSTSEC-2026-0462.html) | rmcp >=3.9.0 | 3.9.0 |

The current locked versions fall within those advisory ranges. These independently checked version facts are separate from the unrecovered complete cargo-deny job log. Feature/path applicability follows each original advisory: bundled SQLite, OAuth address resolution, server schema caching, and built-in HTTP response buffering respectively. The upstream built-in fixes do not establish custom OAuth/HTTP client policy.

## The actual compatibility changes

SQLx 0.9.0's original manifest requires `libsqlite3-sys >=0.30.1, <0.38.0`. A direct sys bump alone therefore conflicts with that range. The existing candidate reuses the official SQLx package and expands both `Cargo.toml` and `Cargo.toml.orig` to `<0.40.0`, consistent with the [upstream bound expansion](https://github.com/transact-rs/sqlx/commit/10462fa4414c6c7f1ed1d39bb31678e3b726878c). Its Matrix SQLite compatibility manifests select rusqlite =0.41.1, and the root manifest pins sys =0.39.1 and rmcp =3.9.0 and enables the local SQLx patch. The root manifest also contains a separate Matrix store-encryption development opt-level=3 adjustment; it is not merely a two-version edit.

Both real lockfiles are included with exact byte identities. The candidate Cargo.lock SHA256 is `98b3767c6e74bf6eeb5894db760259dbc400cbfd0685af8ad915c92d25408d69`, Git blob `025813e20504f31d12dae2092a0807a1a4066419`; the candidate Bazel lock SHA256 is `783b3ad329fa53bd4a0e48be6907d38259fa2880d61bd1994b863d7f78bbca57`, Git blob `1565448430312c7fb7537a48f97e9cd2da945df3`. They are the same lock bytes reported by the earlier disposable #5852 qualification, not proof of a new same-source run. The Cargo comparison also records updated macro/process/transitive packages and Windows dependency-edge resolution; none is concealed as a two-line change.

## Official bytes versus formatted candidate

The original `sqlx-sqlite-0.9.0.crate` was downloaded from the official crate distribution endpoint. Its 93,440 bytes hash to `488e99c397a62007e4229aec669a179816339afc6d2620ca6fa420dbee2e982c`, exactly the official registry checksum retained in MEM8's lockfile. The archive is retained unchanged.

All 57 candidate files were independently read by immutable Git blob and verified. The complete path inventory equals the official crate. There are two deliberate manifest range changes, 44 byte-different Rust files, seven byte-identical Rust files, and four other byte-identical files. Therefore the proposition that only the two manifests differ is **false**. `SQLX_VENDOR_BYTE_REVIEW.json` records that negative conclusion without replacing original bytes.

The separate syntax review parses all 51 official and 51 candidate Rust files with Tree-sitter 0.25.2 and Rust grammar 0.24.0. It expands grouped imports into path/alias multisets while retaining visibility, cfg attributes and duplicate imports. It retains all other syntax and operators, separates formatting comma tokens only in known structural lists, and checks comment text independently after whitespace normalization. All 51 normalized syntax trees and all 51 comment multisets match. Operator, cfg, alias and duplicate-import negative controls are rejected. This supports classification of the 44 changes as import/format changes under the stated normalization, not a claim of byte identity or unrestricted semantic proof.

No pinned Rustfmt replay, rustc compilation, native test, new actor campaign, dependency update, advisory exception or production operation was executed in this review. These results do not waive an existing exact-upstream-byte preservation condition, qualify all consumers, or establish owner or scientific adoption.

## Reproduction and contents

`SQLX_CANDIDATE_FILES.json` contains every candidate file's full text and immutable blob. The original crate, Git subtree listing, original/candidate manifests and locks, exact-source index, current-head comparison/check snapshot, and primary advisory documents are retained. Each package member's length and SHA256 are recorded in `PACKAGE_INDEX.json`.

In a disposable unpacked copy, run:

```bash
python3 verify_sqlx_vendor_bytes.py
uv run --no-project --with tree-sitter==0.25.2 --with tree-sitter-rust==0.24.0 python compare_rust_syntax.py
```

Both commands read original input bytes and regenerate derived JSON. `REVIEW_EXECUTION.json` retains the actual command, exit, stdout/stderr hashes and unchanged input hashes. Byte-audit exit zero means the audit completed; its `only_two_manifest_ranges_changed` result remains false. The syntax command exits nonzero for any parse error, syntax difference or comment mismatch. Complete raw stdout/stderr are retained. No source file is compiled or executed.
