"""Read-only comparison of official SQLx Rust bytes with an existing candidate.

This is syntax evidence, not rustc execution or a Rustfmt replay. Import trees
are expanded into attributed path/alias multisets; other syntax and operators
are retained. Only structural-list comma tokens and comments are separated.
Comments are checked independently after whitespace normalization.
"""

from collections import Counter
import hashlib
import importlib.metadata
import json
from pathlib import Path
import re
import sys
import tarfile

from tree_sitter import Language, Parser
import tree_sitter_rust


ROOT = Path(__file__).resolve().parent
PARSER = Parser(Language(tree_sitter_rust.language()))
COMMENT_TYPES = {"line_comment", "block_comment"}
STRUCTURAL_LISTS = {
    "arguments", "parameters", "type_arguments", "type_parameters",
    "field_declaration_list", "field_initializer_list", "enum_variant_list",
    "ordered_field_declaration_list", "array_expression", "tuple_expression",
    "match_block", "where_clause", "struct_pattern", "tuple_pattern",
    "tuple_type", "closure_parameters", "ordered_field_pattern",
}


def join_path(prefix, value):
    if value == "self" and prefix:
        return prefix
    if value.startswith("::"):
        assert not prefix
        return value
    return f"{prefix}::{value}" if prefix else value


def path_text(node):
    return re.sub(r"\s+", "", node.text.decode())


def imports(node, prefix=""):
    if node.type == "scoped_use_list":
        path = node.child_by_field_name("path")
        nested = join_path(prefix, path_text(path)) if path else prefix
        return imports(node.child_by_field_name("list"), nested)
    if node.type == "use_list":
        return [value for child in node.named_children
                if child.type not in COMMENT_TYPES for value in imports(child, prefix)]
    if node.type == "use_as_clause":
        path = node.child_by_field_name("path")
        alias = node.child_by_field_name("alias")
        return [(join_path(prefix, path_text(path)), path_text(alias))]
    if node.type in {"identifier", "scoped_identifier", "crate", "self", "super", "use_wildcard"}:
        return [(join_path(prefix, path_text(node)), None)]
    raise AssertionError(f"Unsupported use tree: {node.type}: {node.text!r}")


def normalized(node):
    if not node.children:
        return [node.type, node.text.decode()]
    children = []
    use_items = []
    pending_attributes = []
    for index, child in enumerate(node.children):
        field = node.field_name_for_child(index)
        if child.type in COMMENT_TYPES:
            continue
        if child.type == "," and node.type in STRUCTURAL_LISTS:
            continue
        if child.type == "attribute_item":
            pending_attributes.append((field, normalized(child)))
            continue
        if child.type == "use_declaration":
            visibility = next((c for c in child.named_children
                               if c.type == "visibility_modifier"), None)
            metadata = {
                "attributes": pending_attributes,
                "visibility": normalized(visibility) if visibility else None,
            }
            for path, alias in imports(child.child_by_field_name("argument")):
                use_items.append({**metadata, "path": path, "alias": alias})
            pending_attributes = []
            continue
        children.extend(pending_attributes)
        pending_attributes = []
        children.append((field, normalized(child)))
    children.extend(pending_attributes)
    return [node.type, children, sorted(use_items, key=lambda item: json.dumps(item, sort_keys=True))]


def comments(node):
    if node.type in COMMENT_TYPES:
        return [re.sub(r"\s+", " ", node.text.decode()).strip()]
    return [value for child in node.children for value in comments(child)]


def parse(source):
    tree = PARSER.parse(source)
    assert not tree.root_node.has_error, tree.root_node
    return normalized(tree.root_node), Counter(comments(tree.root_node))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


controls = {
    "grouped_use_equals_attributed_flat_use": parse(b'#[cfg(feature = "x")] pub use a::{self, b as c};')
    == parse(b'#[cfg(feature = "x")] pub use a::{self}; #[cfg(feature = "x")] pub use a::b as c;'),
    "operator_change_is_rejected": parse(b'fn f(a:i32,b:i32)->i32 {a+b}')
    != parse(b'fn f(a:i32,b:i32)->i32 {a-b}'),
    "cfg_change_is_rejected": parse(b'#[cfg(feature="x")] use a::b;')
    != parse(b'#[cfg(feature="y")] use a::b;'),
    "alias_change_is_rejected": parse(b'use a::b as c;') != parse(b'use a::b as d;'),
    "duplicate_use_is_not_collapsed": parse(b'use a::b;') != parse(b'use a::b; use a::b;'),
}
assert all(controls.values()), controls

rows = []
with tarfile.open(ROOT / "sqlx-sqlite-0.9.0.crate", "r:gz") as archive:
    for candidate in json.loads((ROOT / "SQLX_CANDIDATE_FILES.json").read_text()):
        path = candidate["path"]
        if not path.endswith(".rs"):
            continue
        original = archive.extractfile("sqlx-sqlite-0.9.0/" + path).read()
        actual = candidate["content"].encode()
        assert git_blob(actual) == candidate["sha"]
        original_ast, original_comments = parse(original)
        actual_ast, actual_comments = parse(actual)
        rows.append({
            "path": path,
            "original_git_blob": git_blob(original),
            "candidate_git_blob": candidate["sha"],
            "original_sha256": digest(original),
            "candidate_sha256": digest(actual),
            "bytes_equal": original == actual,
            "normalized_syntax_equal": original_ast == actual_ast,
            "comment_multiset_equal": original_comments == actual_comments,
        })
result = {
    "schema": "hepta.mem8.sqlx-existing-vendor-syntax-review.v1",
    "source_sha": "72251601928807febae580dbd7754edac20bda10",
    "vendor_tree": "4098a80235cfe8c3d4a20d1f591ee35ee418c051",
    "tree_sitter": importlib.metadata.version("tree-sitter"),
    "tree_sitter_rust": importlib.metadata.version("tree-sitter-rust"),
    "python_version": sys.version,
    "controls": controls,
    "file_count": len(rows),
    "byte_changed_count": sum(not row["bytes_equal"] for row in rows),
    "normalized_syntax_equal_count": sum(row["normalized_syntax_equal"] for row in rows),
    "comment_multiset_equal_count": sum(row["comment_multiset_equal"] for row in rows),
    "native_rustfmt_replay": False,
    "rustc_or_consumer_execution": False,
    "normalization": "Expand attributed use trees into path/alias multisets within each lexical AST parent; preserve visibility, attributes, duplicates, other syntax and operators. Ignore comma tokens only in named structural-list nodes. Check comments independently after whitespace normalization.",
    "rows": rows,
}
(ROOT / "SQLX_SYNTAX_REVIEW.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: value for key, value in result.items() if key != "rows"}, indent=2))
print(json.dumps([row for row in rows if not row["normalized_syntax_equal"] or not row["comment_multiset_equal"]], indent=2))
raise SystemExit(0 if all(row["normalized_syntax_equal"] and row["comment_multiset_equal"] for row in rows) else 1)
