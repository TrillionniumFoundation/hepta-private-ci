import base64, hashlib, json, os, sys
from pathlib import Path
payload=json.load(sys.stdin)
expected={"DRIVER.py": (10205,"f138748e0be33187567d8f27485e05e050ecace82b7afc95b890cb5a8a148a37"),"SOURCE_FIXTURE.zsh":(2661,"6f94e90693a7c6dcdc57bd8044786a7cdd0ccaa32f1815d5a1e47c3ce8a49d81")}
assert set(payload)==set(expected)
r=Path("/Users/qianqi/mem8-zsh-mac-artifact-preparation-inputs-ed353817-v2")
r.mkdir(mode=0o700,exist_ok=False);os.chmod(r,0o700)
for name, item in payload.items():
    data=base64.b64decode(item["base64"],validate=True)
    assert (len(data),hashlib.sha256(data).hexdigest())==expected[name]
    with (r/name).open("xb") as stream:
        os.chmod(r/name,0o600);stream.write(data);stream.flush();os.fsync(stream.fileno())
os.execv(sys.executable,[sys.executable,str(r/"DRIVER.py"),str(r/"SOURCE_FIXTURE.zsh")])
