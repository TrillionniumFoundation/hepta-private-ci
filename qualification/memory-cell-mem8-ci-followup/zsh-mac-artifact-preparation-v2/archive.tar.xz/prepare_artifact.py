#!/usr/bin/env python3
"""Prepare one fixed Mac artifact in a fresh private cache; never execute zsh."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import time


RUN = Path('/Users/qianqi/mem8-zsh-mac-artifact-preparation-ed353817-v2')
DOTSLASH = Path('/opt/homebrew/bin/dotslash')
DOTSLASH_SHA = '61e4bbf54cf4e8782bb0046b69e26fcb3b74797702043fa8c199333416ff44b3'
FIXTURE_SHA = '6f94e90693a7c6dcdc57bd8044786a7cdd0ccaa32f1815d5a1e47c3ce8a49d81'
FIXTURE_BLOB = 'f796fa7201e16c95009ea776fd78b67a0169c153'
ARCHIVE_BYTES = 53771483
ARCHIVE_BLAKE3 = 'ff664f63f5e1fa62762c9aff0aafa66cf196faf9b157f98ec98f59c152fc7bd3'
MEMBER = 'package/vendor/aarch64-apple-darwin/zsh/macos-15/zsh'


def main():
    if len(sys.argv) != 2:
        raise SystemExit('usage: prepare_artifact.py EXACT_FIXTURE')
    if sys.platform != 'darwin' or os.uname().machine != 'arm64':
        raise RuntimeError('preparation is restricted to Darwin arm64')
    started = time.time()
    deadline = time.monotonic() + 360
    RUN.mkdir(mode=0o700, exist_ok=False)
    os.chmod(RUN, 0o700)
    result = {
        'schema': 'mem-zsh-mac-artifact-preparation-v2',
        'run_id': 'mem8-zsh-mac-artifact-preparation-ed353817-v2',
        'scope': 'ARTIFACT_PREPARATION_ONLY_NOT_V1_RETRY_OR_CI_REPRODUCTION',
        'started_utc': datetime.fromtimestamp(started, timezone.utc).isoformat(),
        'budget_seconds': 360, 'download_cap_seconds': 300,
        'status': 'INCOMPLETE_OR_FAILED', 'zsh_controls_executed': 0,
        'model_requests_issued_by_driver': 0, 'native_rust_tests_executed': 0,
        'escalation_ipc_used': False, 'fetch_invocations': 0,
        'provider_internal_request_count': 'NOT_INSTRUMENTED',
        'original_v1_unchanged': '1a1c9f5686c-2564-3ad: fetch timeout, zero controls',
        'source_fixture_provenance': {'head': '2ae5215beaf8d7b7df111a090b82134beae2683d',
                                      'path': 'codex-rs/app-server/tests/suite/zsh'},
        'artifact_contract': {'tag': 'rust-v0.104.0', 'archive_bytes': ARCHIVE_BYTES,
                              'archive_blake3': ARCHIVE_BLAKE3, 'member': MEMBER},
    }

    def check_time():
        if time.monotonic() >= deadline - 1:
            raise TimeoutError('original 360 second preparation budget exhausted')

    def identity(path, max_bytes=64 * 1024 * 1024):
        check_time()
        stat = path.stat()
        if not path.is_file() or stat.st_size > max_bytes:
            raise RuntimeError('unexpected bounded input: ' + str(path))
        sha = hashlib.sha256()
        git = hashlib.sha1(f'blob {stat.st_size}\0'.encode())
        size = 0
        with path.open('rb') as stream:
            while True:
                check_time()
                block = stream.read(1024 * 1024)
                if not block:
                    break
                size += len(block)
                sha.update(block)
                git.update(block)
        if size != stat.st_size:
            raise RuntimeError('file size changed while hashing')
        return {'bytes': size, 'sha256': sha.hexdigest(), 'git_blob': git.hexdigest()}

    def save(name, value):
        with (RUN / name).open('x') as stream:
            json.dump(value, stream, indent=2)
            stream.write('\n')

    def run(label, argv, *, env=None, cap=5):
        remaining = min(cap, deadline - time.monotonic() - 1)
        if remaining <= 0:
            raise TimeoutError('original preparation budget exhausted')
        stdout, stderr = RUN / (label + '.stdout'), RUN / (label + '.stderr')
        receipt = {'command': argv, 'cwd': str(RUN), 'started_unix': time.time()}
        with stdout.open('xb') as so, stderr.open('xb') as se:
            child = subprocess.Popen(argv, cwd=RUN, env=env, stdout=so, stderr=se,
                                     start_new_session=True)
            try:
                code = child.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                receipt['timed_out'] = True
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                code = child.wait(timeout=max(0, min(1, deadline - time.monotonic())))
        receipt.update(exit_code=code, finished_unix=time.time(),
                       stdout={'path': stdout.name, **identity(stdout)},
                       stderr={'path': stderr.name, **identity(stderr)})
        save(label + '.json', receipt)
        if code or receipt.get('timed_out'):
            raise RuntimeError(label + ' failed; no caller retry or fallback')
        return stdout.read_text()

    try:
        source = Path(sys.argv[1]).resolve(strict=True)
        expected = {'bytes': 2661, 'sha256': FIXTURE_SHA, 'git_blob': FIXTURE_BLOB}
        if identity(source) != expected:
            raise RuntimeError('source fixture differs from exact 2ae bytes')
        fixture = RUN / 'SOURCE_FIXTURE.zsh'
        with fixture.open('xb') as stream:
            stream.write(source.read_bytes())
        result['fixture_before'] = {'path': fixture.name, **identity(fixture)}
        with (RUN / 'DRIVER.py').open('xb') as stream:
            stream.write(Path(__file__).read_bytes())
        result['driver'] = {'path': 'DRIVER.py', **identity(RUN / 'DRIVER.py')}
        dotslash = DOTSLASH.resolve(strict=True)
        result['dotslash_before'] = {'requested_path': str(DOTSLASH),
                                     'resolved_path': str(dotslash), **identity(dotslash)}
        if result['dotslash_before']['sha256'] != DOTSLASH_SHA or not os.access(dotslash, os.X_OK):
            raise RuntimeError('existing trusted DotSlash bytes changed')
        result['dotslash_version'] = run('dotslash-version', [str(dotslash), '--version'])
        if result['dotslash_version'].strip() != 'DotSlash 0.5.9':
            raise RuntimeError('unexpected DotSlash version')
        cache = RUN / 'dotslash-cache'
        cache.mkdir(mode=0o700)
        if any(cache.iterdir()):
            raise RuntimeError('new owned cache is not empty')
        env = dict(os.environ)
        for key in list(env):
            if key.startswith(('HEPTA_LOCAL_PROVIDER_', 'HEPTA_MEM_CONTEXT_', 'HEPTA_MEM_NATIVE_')):
                del env[key]
        env['DOTSLASH_CACHE'] = str(cache)
        result['fetch_invocations'] = 1
        fetched = run('dotslash-fetch', [str(dotslash), '--', 'fetch', str(fixture)],
                      env=env, cap=300).strip()
        zsh = Path(fetched).resolve(strict=True)
        if not zsh.is_relative_to(cache.resolve()) or not str(zsh).endswith('/' + MEMBER):
            raise RuntimeError('fetched path differs from the owned expected member')
        if not os.access(zsh, os.X_OK):
            raise RuntimeError('prepared zsh is not executable')
        result['zsh_before'] = {'path': str(zsh), **identity(zsh, 16 * 1024 * 1024)}
        archives = []
        for directory in sorted(cache.iterdir()):
            check_time()
            if directory.is_symlink() or not directory.is_dir() or len(directory.name) != 2:
                continue
            for path in sorted(directory.iterdir()):
                if not path.is_symlink() and path.is_file() and path.stat().st_size == ARCHIVE_BYTES:
                    archives.append(path)
        if len(archives) != 1:
            raise RuntimeError('expected exactly one retained full bundle in the new owned cache')
        archive = archives[0]
        result['archive_before'] = {'path': str(archive), **identity(archive)}
        digest = run('bundle-blake3', [str(dotslash), '--', 'b3sum', str(archive)], cap=15).strip()
        if digest != ARCHIVE_BLAKE3:
            raise RuntimeError('independent full bundle BLAKE3 mismatch')
        result['archive_blake3_observed'] = digest
        found = []
        with tarfile.open(archive, mode='r|gz') as tar:
            for entry in tar:
                check_time()
                if entry.name != MEMBER:
                    continue
                if not entry.isfile() or entry.size > 16 * 1024 * 1024:
                    raise RuntimeError('expected member is not a bounded regular file')
                member_data = tar.extractfile(entry).read(entry.size + 1)
                if len(member_data) != entry.size:
                    raise RuntimeError('member length mismatch')
                member_sha = hashlib.sha256(member_data).hexdigest()
                if entry.size != result['zsh_before']['bytes'] or member_sha != result['zsh_before']['sha256']:
                    raise RuntimeError('extracted binary differs from verified full bundle member')
                found.append({'member': entry.name, 'bytes': entry.size, 'sha256': member_sha})
        if len(found) != 1:
            raise RuntimeError('full bundle must have exactly one expected member')
        result['member_verification'] = found[0]
        result['fixture_after'] = {'path': fixture.name, **identity(fixture)}
        result['dotslash_after'] = {'requested_path': str(DOTSLASH),
                                    'resolved_path': str(DOTSLASH.resolve(strict=True)), **identity(dotslash)}
        result['zsh_after'] = {'path': str(zsh), **identity(zsh, 16 * 1024 * 1024)}
        result['archive_after'] = {'path': str(archive), **identity(archive)}
        for key in ('fixture', 'dotslash', 'zsh', 'archive'):
            if result[key + '_before'] != result[key + '_after']:
                raise RuntimeError('input changed during preparation: ' + key)
        result['status'] = 'VERIFIED_FIXED_ARTIFACT_READY_NO_ZSH_EXECUTION'
    except BaseException as error:
        result['error'] = f'{type(error).__name__}: {error}'
    finally:
        result['finished_utc'] = datetime.now(timezone.utc).isoformat()
        result['elapsed_seconds'] = time.time() - started
        save('PREP_RESULT.json', result)
        print(json.dumps(result), flush=True)
    return 0 if result['status'] == 'VERIFIED_FIXED_ARTIFACT_READY_NO_ZSH_EXECUTION' else 1


if __name__ == '__main__':
    raise SystemExit(main())
