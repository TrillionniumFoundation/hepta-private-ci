import base64
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile


root = Path('/Users/qianqi/mem8-zsh-mac-artifact-preparation-ed353817-v2')
inputs = Path('/Users/qianqi/mem8-zsh-mac-artifact-preparation-inputs-ed353817-v2')
job = Path('/Users/qianqi/.local/state/hepta-runtime-mac-worker/jobs/1a1ca0b560a-2564-42b')


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()}


def read_fixed(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, 'rb') as stream:
        before = os.fstat(stream.fileno())
        assert stat.S_ISREG(before.st_mode) and before.st_size <= 16384
        data = stream.read(16385)
        after = os.fstat(stream.fileno())
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    assert tuple(getattr(before, x) for x in fields) == tuple(getattr(after, x) for x in fields)
    assert len(data) == before.st_size
    return data, ':'.join(str(getattr(before, x)) for x in fields)


files = {}
versions = {}
for name in ('DRIVER.py', 'SOURCE_FIXTURE.zsh', 'PREP_RESULT.json',
             'dotslash-version.json', 'dotslash-version.stdout', 'dotslash-version.stderr',
             'dotslash-fetch.json', 'dotslash-fetch.stdout', 'dotslash-fetch.stderr'):
    files[name], versions[name] = read_fixed(root / name)
for name in ('exit.json', 'exit.witness.json', 'stdout.log', 'stderr.log', 'started.json', 'launch.json'):
    files['job/' + name], versions['job/' + name] = read_fixed(job / name)
for name in ('DRIVER.py', 'SOURCE_FIXTURE.zsh'):
    files['inputs/' + name], versions['inputs/' + name] = read_fixed(inputs / name)
    assert files['inputs/' + name] == files[name]
result = json.loads(files['PREP_RESULT.json'])
assert result['run_id'] == 'mem8-zsh-mac-artifact-preparation-ed353817-v2'
assert result['status'] == 'INCOMPLETE_OR_FAILED' and result['zsh_controls_executed'] == 0
assert result['finished_utc'] == '2026-11-11T10:03:23.305855+00:00'
assert json.loads(files['job/stdout.log']) == result
exit_record = json.loads(files['job/exit.json'])
assert exit_record['exit_code'] == 1
assert not exit_record.get('timed_out', False)
assert identity(files['DRIVER.py'])['sha256'] == 'f138748e0be33187567d8f27485e05e050ecace82b7afc95b890cb5a8a148a37'
assert identity(files['SOURCE_FIXTURE.zsh'])['git_blob'] == 'f796fa7201e16c95009ea776fd78b67a0169c153'
receipts = []
for name in ('dotslash-version', 'dotslash-fetch'):
    receipt = json.loads(files[name + '.json'])
    for stream in ('stdout', 'stderr'):
        actual = identity(files[receipt[stream]['path']])
        assert all(actual[key] == receipt[stream][key] for key in actual)
    receipts.append({'path': name + '.json', 'exit_code': receipt['exit_code'],
                     'timed_out': receipt.get('timed_out', False)})
assert receipts[1]['timed_out'] and receipts[1]['exit_code'] == -9
manifest = {'schema': 'mem-zsh-mac-preparation-failed-original-members-v2',
            'scope': 'ORIGINAL_300_SECOND_FETCH_TIMEOUT_ZERO_ZSH_CONTROLS',
            'job_id': '1a1ca0b560a-2564-42b', 'cache_excluded': True,
            'post_identity_gate_reached': False, 'command_receipts': receipts,
            'members': [{'path': name, 'original_file_version': versions[name], **identity(data)}
                        for name, data in sorted(files.items())]}
files['MEMBER_MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
output = root / 'PREP_EVIDENCE.tar.xz'
with output.open('xb') as stream:
    os.chmod(output, 0o600)
    with tarfile.open(fileobj=stream, mode='w:xz', preset=6) as tar:
        for name, data in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o600
            member.mtime = 0
            tar.addfile(member, io.BytesIO(data))
    stream.flush()
    os.fsync(stream.fileno())
data = output.read_bytes()
receipt = {'path': str(output), 'members': len(files), **identity(data),
           'original_exit_code': exit_record['exit_code'], 'verified_commands': receipts}
with (root / 'PREP_EVIDENCE_MANIFEST.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({'archive': receipt, 'archive_base64': base64.b64encode(data).decode()}), flush=True)
