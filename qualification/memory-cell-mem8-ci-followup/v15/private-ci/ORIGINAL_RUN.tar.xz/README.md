# 9bd2 Windows private-state original qualification

This archive preserves the single original GitHub Actions run 43021840252, job130526674042, attempt1, at exact source9bd2f589debdba4a93baa363817c3669cb103721/treec77785ecb368c44ea699769001a47402c9f50591. No rerun was started.

The six main selections executed34 unique package/case IDs and all34 passed. Reported skipped counts remain separate. The two acquisition positive-control cases ran again and are not new unique cases. Each of the two intentionally mutated source lanes executed two cases, with exactly one expected failure and one pass; the original production source was restored. The original signed-credit case passed with zero retries, one exact named PASS, a matching full raw receipt and exact clean source before/after.

Both original artifact ZIPs are included whole and CRC/hash checked. All11 members are retained and compared byte for byte; the current production file was independently Git-read and matched positive.rs exactly. No JUnit is claimed: this original workflow retained raw nextest case rows and summaries plus receipts. Run python3 verify_private_original.py after extraction for offline verification.

This is a selected Windows private-state qualification. It does not close the separately failing enabled core hardlink case, every Windows test, the combined required CI, a production owner custody claim or a memory-benefit experiment.
