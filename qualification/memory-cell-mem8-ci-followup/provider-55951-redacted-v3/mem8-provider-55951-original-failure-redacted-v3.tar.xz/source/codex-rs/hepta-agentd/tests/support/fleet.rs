use std::path::Path;
use std::path::PathBuf;
use std::time::Duration;
use std::time::Instant;

use anyhow::Result;
use anyhow::bail;
use anyhow::ensure;
use codex_app_server_client::RemoteAppServerClient;
use codex_app_server_client::RemoteAppServerConnectArgs;
use codex_app_server_client::RemoteAppServerEndpoint;
use codex_hepta_agentd::AgentdClient;
use codex_hepta_agentd::HealthSnapshot;
use codex_hepta_contracts::AgentId;
use codex_hepta_fleet::AgentLifecycle;
use codex_hepta_fleet::AgentManifest;
use codex_hepta_fleet::FleetRegistry;
use codex_hepta_fleet::ResourceBudget;
use codex_hepta_fleet::WorkspaceBinding;
use codex_hepta_paths::HeptaAgentLayout;
use codex_hepta_paths::HeptaFleetRoot;
use codex_hepta_supervisor::AgentCommand;
use codex_hepta_supervisor::AgentRelease;
use codex_hepta_supervisor::AgentSupervisorSnapshot;
use codex_hepta_supervisor::ProcessStream;
use codex_hepta_supervisor::Supervisor;
use codex_hepta_supervisor::SupervisorConfig;
use codex_hepta_supervisor::SupervisorEventKind;
use codex_hepta_supervisor::UnixProcessDriver;
use codex_utils_absolute_path::AbsolutePathBuf;

const READY_TIMEOUT: Duration = Duration::from_secs(60);
const MAX_DIAGNOSTIC_STREAM_BYTES: usize = 4_096;

pub(crate) struct AgentFixture {
    pub(crate) agent_id: AgentId,
    pub(crate) layout: HeptaAgentLayout,
    pub(crate) workspace: PathBuf,
}

pub(crate) struct FleetHarness {
    _temp: Option<tempfile::TempDir>,
    root: PathBuf,
    fleet_root: HeptaFleetRoot,
    pub(crate) registry: FleetRegistry,
    pub(crate) supervisor: Supervisor<UnixProcessDriver>,
    supervisor_config: SupervisorConfig,
    agent_ids: Vec<AgentId>,
    started: bool,
}

impl FleetHarness {
    pub(crate) fn new() -> Result<Self> {
        // Darwin's per-user temporary root can exhaust sockaddr_un before the
        // unchanged fleet/run/<agent>.ctl suffix. Keep the owned fixture short.
        #[cfg(target_os = "macos")]
        let temp = tempfile::tempdir_in(Path::new("/tmp").canonicalize()?)?;
        #[cfg(not(target_os = "macos"))]
        let temp = tempfile::tempdir()?;
        let root = temp.path().canonicalize()?;
        let fleet_root = HeptaFleetRoot::parse(root.join("fleet"))?;
        let registry = FleetRegistry::initialize(fleet_root.clone())?;
        let mut config = SupervisorConfig::local_default();
        config.health_timeout = READY_TIMEOUT;
        config.drain_timeout = Duration::from_secs(2);
        config.stop_grace = Duration::from_secs(1);
        let driver = UnixProcessDriver::new(256)?;
        let (supervisor, recovery) =
            Supervisor::recover(registry.clone(), driver, config.clone(), Instant::now())?;
        ensure!(
            recovery.faults.is_empty(),
            "unexpected supervisor recovery faults: {:?}",
            recovery.faults
        );
        Ok(Self {
            _temp: Some(temp),
            root,
            fleet_root,
            registry,
            supervisor,
            supervisor_config: config,
            agent_ids: Vec::new(),
            started: false,
        })
    }

    /// Retain an opt-in real-provider fixture for reconciliation after an
    /// unknown request outcome. Process cleanup still runs in Drop.
    #[allow(dead_code)]
    pub(crate) fn retain_fixture_root(&mut self) -> Result<PathBuf> {
        use std::os::unix::fs::PermissionsExt;

        ensure!(
            !self.started,
            "retain the fixture before starting any agent"
        );
        let metadata = std::fs::symlink_metadata(&self.root)?;
        ensure!(
            metadata.is_dir() && metadata.permissions().mode() & 0o7777 == 0o700,
            "retained fixture root must be a private 0700 directory"
        );
        let Some(temp) = self._temp.take() else {
            bail!("fixture root was already retained");
        };
        let kept = temp.keep();
        ensure!(
            kept.canonicalize()? == self.root,
            "retained fixture root changed"
        );
        Ok(self.root.clone())
    }

    #[allow(dead_code)]
    pub(crate) fn register(
        &mut self,
        agent_id: &str,
        workspace_name: &str,
    ) -> Result<AgentFixture> {
        self.register_with_resources(agent_id, workspace_name, ResourceBudget::local_default())
    }

    pub(crate) fn register_with_resources(
        &mut self,
        agent_id: &str,
        workspace_name: &str,
        resources: ResourceBudget,
    ) -> Result<AgentFixture> {
        ensure!(
            !self.started,
            "all fleet agents must be registered before the first process starts"
        );
        let workspace = self.root.join(workspace_name);
        std::fs::create_dir(&workspace)?;
        let workspace = workspace.canonicalize()?;
        let agent_id = AgentId::parse(agent_id).map_err(anyhow::Error::msg)?;
        let binding = WorkspaceBinding::new(&workspace, &self.fleet_root)?;
        let manifest = AgentManifest::new(agent_id.clone(), binding, resources)?;
        let record = self.registry.register(manifest)?;
        self.agent_ids.push(agent_id.clone());
        let driver = UnixProcessDriver::new(256)?;
        let (supervisor, recovery) = Supervisor::recover(
            self.registry.clone(),
            driver,
            self.supervisor_config.clone(),
            Instant::now(),
        )?;
        ensure!(
            recovery.faults.is_empty(),
            "unexpected supervisor recovery faults after registering {agent_id}: {:?}",
            recovery.faults
        );
        self.supervisor = supervisor;
        Ok(AgentFixture {
            agent_id,
            layout: record.layout,
            workspace,
        })
    }

    #[allow(dead_code)]
    pub(crate) fn start(&mut self, agent: &AgentFixture) -> Result<()> {
        let binary = agentd_binary()?;
        let command = AgentCommand::new(binary, Vec::new())?;
        self.start_command(agent, command)
    }

    pub(crate) fn start_command(
        &mut self,
        agent: &AgentFixture,
        command: AgentCommand,
    ) -> Result<()> {
        self.supervisor
            .start(&agent.agent_id, command, Instant::now())?;
        self.started = true;
        Ok(())
    }

    #[allow(dead_code)]
    pub(crate) fn start_with_authbus_trust_file(
        &mut self,
        agent: &AgentFixture,
        trust_file: &Path,
        checkpoint_file: &Path,
    ) -> Result<()> {
        let command = AgentCommand::new(
            agentd_binary()?,
            vec![
                "--authbus-trust-file".into(),
                trust_file.as_os_str().to_owned(),
                "--authbus-checkpoint-file".into(),
                checkpoint_file.as_os_str().to_owned(),
            ],
        )?;
        self.supervisor
            .start(&agent.agent_id, command, Instant::now())?;
        self.started = true;
        Ok(())
    }

    #[allow(dead_code)]
    pub(crate) fn start_with_evidence_trust_file(
        &mut self,
        agent: &AgentFixture,
        trust_file: &Path,
    ) -> Result<()> {
        let command = AgentCommand::new(
            agentd_binary()?,
            vec![
                "--evidence-trust-file".into(),
                trust_file.as_os_str().to_owned(),
            ],
        )?;
        self.supervisor
            .start(&agent.agent_id, command, Instant::now())?;
        self.started = true;
        Ok(())
    }

    #[allow(dead_code)]
    pub(crate) fn start_with_evidence_recovery(
        &mut self,
        agent: &AgentFixture,
        evidence_trust_file: &Path,
        recovery_frontier_file: &Path,
        recovery_frontier_trust_file: &Path,
    ) -> Result<()> {
        let command = AgentCommand::new(
            agentd_binary()?,
            vec![
                "--evidence-trust-file".into(),
                evidence_trust_file.as_os_str().to_owned(),
                "--evidence-recovery-frontier-file".into(),
                recovery_frontier_file.as_os_str().to_owned(),
                "--evidence-recovery-frontier-trust-file".into(),
                recovery_frontier_trust_file.as_os_str().to_owned(),
            ],
        )?;
        self.supervisor
            .start(&agent.agent_id, command, Instant::now())?;
        self.started = true;
        Ok(())
    }

    #[allow(dead_code)]
    pub(crate) fn start_with_plasticity_bootstrap_descriptor(
        &mut self,
        agent: &AgentFixture,
        descriptor: &Path,
        descriptor_digest: &str,
    ) -> Result<()> {
        let command = AgentCommand::new(
            agentd_binary()?,
            vec![
                "--plasticity-bootstrap-descriptor".into(),
                descriptor.as_os_str().to_owned(),
                "--plasticity-bootstrap-descriptor-digest".into(),
                descriptor_digest.into(),
            ],
        )?;
        self.supervisor
            .start(&agent.agent_id, command, Instant::now())?;
        self.started = true;
        Ok(())
    }

    #[allow(dead_code)]
    pub(crate) fn start_release(
        &mut self,
        agent: &AgentFixture,
        release: AgentRelease,
    ) -> Result<()> {
        self.supervisor
            .start_release(&agent.agent_id, release, Instant::now())?;
        self.started = true;
        Ok(())
    }

    pub(crate) fn control_client(
        &self,
        agent: &AgentFixture,
        generation: u64,
    ) -> Result<AgentdClient> {
        AgentdClient::new(
            agent.layout.agentd_control_socket().to_path_buf(),
            agent.agent_id.clone(),
            generation,
        )
        .map_err(Into::into)
    }

    pub(crate) async fn wait_ready(
        &mut self,
        agent: &AgentFixture,
        generation: u64,
    ) -> Result<(AgentdClient, HealthSnapshot)> {
        let control = self.control_client(agent, generation)?;
        let health = self.wait_until_ready(&agent.agent_id, &control).await?;
        ensure!(
            health.workspace == agent.workspace,
            "agent workspace drifted"
        );
        ensure!(
            health.home_root == agent.layout.home_root(),
            "agent home drifted"
        );
        Ok((control, health))
    }

    /// Restart acknowledges queued work. Wait for the new leased spawn before
    /// binding a client; a stopped/draining registry generation is not its ID.
    #[allow(dead_code)]
    pub(crate) async fn wait_new_spawn(
        &mut self,
        agent: &AgentFixture,
        previous_generation: u64,
    ) -> Result<(AgentdClient, HealthSnapshot)> {
        let deadline = Instant::now() + READY_TIMEOUT;
        loop {
            let report = self.supervisor.tick(Instant::now());
            ensure!(
                report.faults.is_empty(),
                "restart faults: {:?}",
                report.faults
            );
            let snapshot = self.supervisor.snapshot(&agent.agent_id);
            if let Some(generation) = snapshot.as_ref().and_then(|value| value.spawn_generation)
                && generation > previous_generation
            {
                let control = self.control_client(agent, generation)?;
                let health = self
                    .wait_until_ready_before(&agent.agent_id, &control, deadline)
                    .await?;
                return Ok((control, health));
            }
            ensure!(
                Instant::now() < deadline,
                "queued restart did not create a new spawn: {snapshot:?}"
            );
            tokio::time::sleep(Duration::from_millis(25)).await;
        }
    }

    pub(crate) async fn wait_until_ready(
        &mut self,
        agent_id: &AgentId,
        control: &AgentdClient,
    ) -> Result<HealthSnapshot> {
        self.wait_until_ready_before(agent_id, control, Instant::now() + READY_TIMEOUT)
            .await
    }

    async fn wait_until_ready_before(
        &mut self,
        agent_id: &AgentId,
        control: &AgentdClient,
        deadline: Instant,
    ) -> Result<HealthSnapshot> {
        loop {
            let report = self.supervisor.tick(Instant::now());
            ensure!(
                report.faults.is_empty(),
                "supervisor faults while waiting for {agent_id}: {:?}",
                report.faults
            );
            let snapshot = self.supervisor.snapshot(agent_id);
            let health = control.health().await;
            let last_health = match &health {
                Ok(health) => format!("{health:?}"),
                Err(error) => format!("{error:#}"),
            };
            // Inspect the completed tick: queued restarts may replace an exited
            // process in that same tick, and pending rollouts can still recover.
            if let Some(snapshot) = snapshot.as_ref()
                && !snapshot.active
                && !snapshot.release_change_pending
                && self
                    .registry
                    .load()?
                    .agent(agent_id)
                    .is_some_and(|agent| agent.lifecycle.lifecycle == AgentLifecycle::Failed)
            {
                let diagnostics = readiness_diagnostics(Some(snapshot), &last_health);
                bail!("agent {agent_id} failed before readiness; {diagnostics}");
            }
            if let Ok(health) = health
                && health.ready
            {
                return Ok(health);
            }
            if Instant::now() >= deadline {
                let diagnostics = readiness_diagnostics(snapshot.as_ref(), &last_health);
                bail!("timed out waiting for agent {agent_id} readiness; {diagnostics}");
            }
            tokio::time::sleep(Duration::from_millis(25)).await;
        }
    }
}

fn readiness_diagnostics(snapshot: Option<&AgentSupervisorSnapshot>, last_health: &str) -> String {
    let Some(snapshot) = snapshot else {
        return format!("supervisor snapshot missing; last_health={last_health}");
    };
    let last_exit = snapshot.events.iter().rev().find_map(|event| {
        if let SupervisorEventKind::Exited(exit) = &event.kind {
            Some(exit)
        } else {
            None
        }
    });
    let [stdout, stderr] = [ProcessStream::Stdout, ProcessStream::Stderr].map(|stream| {
        let mut bytes = snapshot
            .logs
            .iter()
            .filter(|log| log.stream == stream)
            .flat_map(|log| log.bytes.iter().copied())
            .rev()
            .take(MAX_DIAGNOSTIC_STREAM_BYTES)
            .collect::<Vec<_>>();
        bytes.reverse();
        let decoded = String::from_utf8_lossy(&bytes);
        // Lossy UTF-8 decoding can expand invalid bytes. Bound the decoded tail
        // too, without splitting a replacement character or a valid code point.
        let mut start = decoded.len().saturating_sub(MAX_DIAGNOSTIC_STREAM_BYTES);
        while !decoded.is_char_boundary(start) {
            start += 1;
        }
        decoded[start..].to_string()
    });
    format!(
        "active={}; healthy={}; runtime_generation={:?}; release_change_pending={}; \
         last_exit={last_exit:?}; last_health={last_health}; \
         stdout (tail, max {MAX_DIAGNOSTIC_STREAM_BYTES} bytes):\n{stdout}\n\
         stderr (tail, max {MAX_DIAGNOSTIC_STREAM_BYTES} bytes):\n{stderr}",
        snapshot.active,
        snapshot.healthy,
        snapshot.runtime_generation,
        snapshot.release_change_pending,
    )
}

pub(crate) fn agentd_binary() -> Result<PathBuf> {
    Ok(codex_utils_cargo_bin::cargo_bin("codex-hepta-agentd")?)
}

impl Drop for FleetHarness {
    fn drop(&mut self) {
        for agent_id in &self.agent_ids {
            let _ = self.supervisor.kill(agent_id);
        }
        let deadline = Instant::now() + Duration::from_secs(3);
        while Instant::now() < deadline {
            self.supervisor.tick(Instant::now());
            if self.agent_ids.iter().all(|agent_id| {
                self.supervisor
                    .snapshot(agent_id)
                    .is_none_or(|snapshot| !snapshot.active)
            }) {
                break;
            }
            std::thread::sleep(Duration::from_millis(20));
        }
    }
}

#[allow(dead_code)]
pub(crate) async fn connect_app_server(
    socket_path: &Path,
    client_name: &str,
    channel_capacity: usize,
) -> Result<RemoteAppServerClient> {
    connect_app_server_with_experimental(
        socket_path,
        client_name,
        channel_capacity,
        /*experimental_api*/ false,
    )
    .await
}

pub(crate) async fn connect_app_server_with_experimental(
    socket_path: &Path,
    client_name: &str,
    channel_capacity: usize,
    experimental_api: bool,
) -> Result<RemoteAppServerClient> {
    let socket_path = AbsolutePathBuf::from_absolute_path(socket_path)?;
    Ok(RemoteAppServerClient::connect(RemoteAppServerConnectArgs {
        endpoint: RemoteAppServerEndpoint::UnixSocket { socket_path },
        client_name: client_name.to_string(),
        client_version: env!("CARGO_PKG_VERSION").to_string(),
        experimental_api,
        mcp_server_openai_form_elicitation: false,
        opt_out_notification_methods: Vec::new(),
        channel_capacity,
    })
    .await?)
}
