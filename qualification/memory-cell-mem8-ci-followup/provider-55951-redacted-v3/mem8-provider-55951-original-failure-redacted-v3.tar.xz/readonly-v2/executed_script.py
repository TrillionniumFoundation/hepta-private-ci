import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
from datetime import datetime, timezone

TASK = Path('/home/qian-qi/mem8-provider-original-settlement-ed353817-v2')
FIXTURE = Path('/tmp/.tmpr79GeL')
AGENT = '018f4f72-5f8f-7cc1-8f55-df9fb3aa2c12'
OWNER_HOME = FIXTURE / 'fleet/agents' / AGENT / 'home'
THREAD = '01a1c8ef-125f-75ae-aaf1-0fe5a4c079f6'
TURN = '01a1c8ef-1fbd-75b0-bc6e-2b22a1f1f596'
CLIENT_KEY = 'qualification-e2e-message:Integer(2)'
ROLLOUT = OWNER_HOME / 'sessions/2026/11/10' / ('rollout-2026-11-10T23-47-53-' + THREAD + '.jsonl')


def now():
    return datetime.now(timezone.utc).isoformat()


def save(name, value):
    with (TASK / name).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')


def regular_bytes(path, limit):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    assert before.st_size <= limit
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, 'rb') as handle:
        data = handle.read(limit + 1)
    after = path.lstat()
    assert len(data) <= limit
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    return data, {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'device': before.st_dev, 'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns, 'mode': oct(stat.S_IMODE(before.st_mode))}


def database_files(name):
    result = []
    for suffix in ('', '-wal'):
        path = OWNER_HOME / (name + suffix)
        if path.exists():
            _, metadata = regular_bytes(path, 16 * 1024 * 1024)
            result.append(metadata)
    return result


def columns(connection, table):
    assert re.fullmatch(r'[a-z_0-9]+', table)
    return [row[1] for row in connection.execute('PRAGMA table_info(' + table + ')')]


def selected(connection, table, required, predicate, values, limit):
    available = columns(connection, table)
    missing = sorted(set(required) - set(available))
    assert not missing, (table, missing)
    query = 'SELECT ' + ', '.join(required) + ' FROM ' + table + ' WHERE ' + predicate + ' LIMIT ' + str(limit)
    return [dict(zip(required, row)) for row in connection.execute(query, values)]


def safe_log(row):
    message = row.pop('feedback_log_body') or ''
    encoded = message.encode()
    low = message.lower()
    categories = {'timeout': ('timeout', 'timed out', 'deadline'), 'connection_refused': ('connection refused',), 'stream_disconnected': ('stream disconnected', 'stream closed', 'stream error'), 'http_error': ('http error', 'status code', 'bad gateway'), 'dns': ('dns', 'name resolution'), 'tls': ('tls', 'certificate'), 'cancelled': ('cancelled', 'canceled', 'aborted'), 'unauthorized': ('unauthorized', 'authentication failed'), 'forbidden': ('forbidden',), 'rate_limited': ('rate limit',), 'invalid_request': ('invalid request', 'unsupported'), 'recovery': ('recover',), 'retry': ('retry', 'retrying')}
    row.update({'message_bytes': len(encoded), 'message_sha256': hashlib.sha256(encoded).hexdigest(), 'raw_message_exported': False, 'contains_original_turn': TURN in message, 'safe_error_categories': [key for key, needles in categories.items() if any(needle in low for needle in needles)], 'http_status_mentions': sorted(set(re.findall(r'(?:status(?: code)?|HTTP(?:/\d(?:\.\d)?)?)[^0-9\n]{0,15}([45][0-9]{2})', message, re.I)))})
    return row


def main():
    os.umask(0o077)
    TASK.mkdir(mode=0o700)
    assert stat.S_IMODE(FIXTURE.lstat().st_mode) == 0o700
    intent = {'schema': 'hepta.mem8.provider-original-readonly-settlement.v2', 'thread_id': THREAD, 'turn_id': TURN, 'client_user_message_id': CLIENT_KEY, 'fixture_root': str(FIXTURE), 'owner_home': str(OWNER_HOME), 'original_owner_pid': 3253029, 'original_pid_path_exists': Path('/proc/3253029').exists(), 'original_source_commit': '55951ed9094ae894f0256a3461fd9504ef060473', 'original_source_tree': '2ca6930d8abd148fe26fbe7d2857c760daa9316b', 'started_at': now(), 'network_operations': 0, 'model_requests_by_this_readonly_script': 0, 'owner_starts': 0, 'sqlite_open_mode': 'ro', 'private_keys_or_auth_configuration_read': False}
    save('INTENT.json', intent)
    assert not intent['original_pid_path_exists'], 'original process PID exists; stop instead of assuming identity'
    raw, rollout_metadata = regular_bytes(ROLLOUT, 128 * 1024)
    records = [json.loads(line) for line in raw.splitlines() if line]
    assert records[0]['type'] == 'session_meta' and records[0]['payload']['id'] == THREAD
    visible = []
    terminal_types = {'task_complete', 'task_completed', 'turn_complete', 'turn_completed', 'turn_aborted', 'turn_failed'}
    for number, record in enumerate(records, 1):
        payload = record.get('payload', {})
        row = {'line': number, 'timestamp': record.get('timestamp'), 'record_type': record.get('type'), 'payload_type': payload.get('type'), 'original_line_sha256': hashlib.sha256(raw.splitlines()[number - 1]).hexdigest()}
        for key in ('turn_id', 'client_id', 'payload_sha256', 'generation', 'state', 'status', 'id', 'role'):
            if key in payload:
                row[key] = payload[key]
        if payload.get('role') == 'assistant':
            texts = [entry.get('text', '') for entry in payload.get('content', []) if entry.get('type') in ('output_text', 'input_text', 'text')]
            joined = ''.join(texts)
            row['assistant_text_bytes'] = len(joined.encode())
            row['assistant_text_sha256'] = hashlib.sha256(joined.encode()).hexdigest()
            row['assistant_text_exactly_READY'] = joined.strip() == 'READY'
        visible.append(row)
    rollout = {'file': rollout_metadata, 'line_count': len(records), 'rows': visible, 'terminal_record_observed': any(x.get('payload_type') in terminal_types for x in visible), 'assistant_record_observed': any(x.get('role') == 'assistant' for x in visible), 'tool_call_record_observed': any(x.get('payload_type') in ('function_call', 'custom_tool_call') for x in visible), 'private_context_text_exported': False}
    save('ROLLOUT_SAFE_OBSERVATIONS.json', rollout)
    outputs = {}
    for filename, table in [('state_5.sqlite', 'threads'), ('queue_1.sqlite', 'queued_client_bindings'), ('logs_2.sqlite', 'logs')]:
        before = database_files(filename)
        path = OWNER_HOME / filename
        connection = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=2)
        try:
            connection.execute('PRAGMA query_only=ON')
            schema = columns(connection, table)
            save(filename + ".SCHEMA.json", {"table": table, "columns": schema})
            if table == 'threads':
                rows = selected(connection, table, ['id', 'rollout_path', 'created_at', 'updated_at', 'model_provider', 'tokens_used', 'has_user_event', 'archived'], 'id = ?', [THREAD], 2)
                assert len(rows) <= 1
            elif table == 'queued_client_bindings':
                rows = selected(connection, table, ['thread_id', 'client_user_message_id', 'payload_sha256', 'state', 'turn_id', 'revision', 'created_at_ms', 'updated_at_ms'], 'thread_id = ? AND client_user_message_id = ?', [THREAD, CLIENT_KEY], 2)
                assert len(rows) <= 1
            else:
                rows = selected(connection, table, ['id', 'ts', 'ts_nanos', 'level', 'target', 'feedback_log_body', 'module_path', 'file', 'line', 'thread_id', 'process_uuid'], 'thread_id = ? ORDER BY id DESC', [THREAD], 100)
                rows = [safe_log(row) for row in reversed(rows)]
        finally:
            connection.close()
        after = database_files(filename)
        assert before == after, 'original database or WAL changed during read-only settlement'
        outputs[filename] = {'table': table, 'columns': schema, 'before': before, 'after': after, 'original_database_and_wal_unchanged': True, 'selection': 'original thread ID; queue binding additionally exact client key', 'rows': rows}
        save(filename + '.SAFE_QUERY.json', outputs[filename])
    result = {'intent': intent, 'finished_at': now(), 'rollout_terminal_observed': rollout['terminal_record_observed'], 'rollout_assistant_observed': rollout['assistant_record_observed'], 'queue_binding_rows': outputs['queue_1.sqlite']['rows'], 'log_rows_observed': len(outputs['logs_2.sqlite']['rows']), 'original_databases_and_wal_unchanged': True, 'provider_qualification_passed': False, 'physical_model_request_count_observed': False, 'remote_model_outcome_observed': False, 'owner_restart_or_model_replay_performed': False}
    save('RESULT.json', result)
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
