"""Build an explicitly derived safe projection; never overwrite original observations."""
import hashlib
import json

SCALAR_KEYS = frozenset({
    "line", "timestamp", "record_type", "payload_type", "original_line_sha256",
    "id", "turn_id", "role", "client_id", "payload_sha256", "generation",
})
TOP_FLAGS = ("terminal_record_observed", "assistant_record_observed", "tool_call_record_observed")
FILE_KEYS = ("path", "bytes", "sha256", "device", "inode", "mtime_ns", "mode")


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def redact_projection(original_bytes, original_path):
    original = json.loads(original_bytes)
    assert isinstance(original, dict) and isinstance(original["rows"], list)
    rows = []
    omitted = []
    for row in original["rows"]:
        assert isinstance(row, dict)
        safe = {}
        for key in SCALAR_KEYS:
            if key in row:
                value = row[key]
                assert value is None or type(value) in (str, int, bool), (key, type(value).__name__)
                assert not isinstance(value, str) or len(value) <= 512, key
                safe[key] = value
        if "state" in row and row.get("record_type") == "event_msg" and row.get("payload_type") == "turn_recovery_candidate":
            value = row["state"]
            assert value is None or type(value) in (str, int, bool)
            assert not isinstance(value, str) or len(value) <= 64
            safe["state"] = value
        omitted_fields = {}
        for key, value in row.items():
            if key in safe:
                continue
            description = {
                "type": type(value).__name__,
                "canonical_json_sha256": sha(canonical(value)),
                "canonical_json_bytes": len(canonical(value)),
            }
            if key == "state" and row.get("record_type") == "world_state":
                assert isinstance(value, dict)
                description["field_names"] = sorted(value)
            omitted_fields[key] = description
        if omitted_fields:
            safe["omitted_fields"] = omitted_fields
            omitted.append({"line": row.get("line"), "record_type": row.get("record_type"), "fields": sorted(omitted_fields)})
        rows.append(safe)
    result = {
        "schema": "hepta.mem8.redacted-rollout-projection.v1",
        "derived_projection_not_original_bytes": True,
        "original_projection": {
            "path": str(original_path), "bytes": len(original_bytes), "sha256": sha(original_bytes),
            "excluded_from_archive": True,
            "original_private_context_text_exported_flag": original.get("private_context_text_exported"),
            "original_flag_is_not_reliable": True,
        },
        "file": {key: original["file"][key] for key in FILE_KEYS},
        "line_count": original["line_count"],
        "rows": rows,
        **{key: original[key] for key in TOP_FLAGS},
        "private_context_text_exported": False,
        "scope_of_claim": "Only this derived projection; the original projection contained world_state context.",
        "redaction": {
            "scalar_allowlist": sorted(SCALAR_KEYS),
            "state_scalar_allowed_only_for": "event_msg payload_type=turn_recovery_candidate",
            "all_other_fields": "type, canonical JSON byte length and SHA256 only",
            "world_state_state": "field names and canonical JSON hash/length; no values",
            "omissions": omitted,
            "canonical_json": "UTF-8, ensure_ascii=False, sort_keys=True, separators=(comma, colon)",
        },
    }
    # These strings must never be included as values by a projection edit.
    original_context_strings = []
    def gather(value):
        if isinstance(value, dict):
            for child in value.values():
                gather(child)
        elif isinstance(value, list):
            for child in value:
                gather(child)
        elif isinstance(value, str) and len(value) >= 80:
            original_context_strings.append(value)
    for row in original["rows"]:
        if row.get("record_type") == "world_state" and "state" in row:
            gather(row["state"])
    serialized = json.dumps(result, indent=2) + "\n"
    for value in original_context_strings:
        assert value not in serialized and json.dumps(value)[1:-1] not in serialized
    return result, original_context_strings
