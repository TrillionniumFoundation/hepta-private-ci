import hashlib
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify(root):
    root = Path(root)
    manifest_path = root / "FILE_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text())
    actual = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file()}
    assert actual == {row["path"] for row in manifest["files"]} | {"FILE_MANIFEST.json"}
    for row in manifest["files"]:
        data = (root / row["path"]).read_bytes()
        assert len(data) == row["bytes"] and sha(data) == row["sha256"], row["path"]
    assert all(not name.endswith((".xz", ".gz", ".zip", ".tar", ".sqlite", ".db", ".pem", ".key")) for name in actual)
    assert not any(name.endswith("/ROLLOUT_SAFE_OBSERVATIONS.json") for name in actual)
    erratum = json.loads((root / "PROJECTION_PRIVACY_ERRATUM.json").read_text())
    assert erratum["original_host_records_modified"] is False
    assert erratum["original_native_logs_receipts_junit_modified"] is False
    assert erratum["physical_provider_outcome"] == "UNKNOWN"
    assert erratum["unsafe_archive_and_original_projection_bytes_excluded_from_this_package"] is True
    assert len(erratum["projections"]) == 2
    for projection in erratum["projections"]:
        data = (root / projection["derived_member"]).read_bytes()
        assert len(data) == projection["derived_bytes"] and sha(data) == projection["derived_sha256"]
        value = json.loads(data)
        assert value["derived_projection_not_original_bytes"] is True
        assert value["original_projection"]["sha256"] == projection["original_sha256"]
        assert value["original_projection"]["bytes"] == projection["original_bytes"]
        assert value["original_projection"]["excluded_from_archive"] is True
        assert value["original_projection"]["original_flag_is_not_reliable"] is True
        assert value["private_context_text_exported"] is False
        assert value["assistant_record_observed"] is False and value["terminal_record_observed"] is False
        for row in value["rows"]:
            for key, field in row.items():
                if key != "omitted_fields":
                    assert field is None or type(field) in (str, int, bool), (key, type(field).__name__)
            if row["record_type"] == "world_state":
                assert "state" not in row and row["omitted_fields"]["state"]["type"] == "dict"
                assert "field_names" in row["omitted_fields"]["state"]
            if "state" in row:
                assert row["record_type"] == "event_msg" and row["payload_type"] == "turn_recovery_candidate"
                assert row["state"] == "ready"
        ready = [row for row in value["rows"] if row.get("state") == "ready"]
        assert len(ready) == 1
    receipt = json.loads((root / "original/real-provider-smoke.json").read_text())
    assert receipt["status"] == "failed" and receipt["command_exit_code"] == 100
    assert receipt["observed_passed_tests"] == 0 and receipt["observed_failed_tests"] == 1
    assert receipt["timed_out"] is False
    assert receipt["before"] == receipt["after"]
    assert receipt["before"]["commit"] == "55951ed9094ae894f0256a3461fd9504ef060473"
    assert receipt["before"]["tree"] == "2ca6930d8abd148fe26fbe7d2857c760daa9316b" and receipt["before"]["dirty"] is False
    raw = (root / "original" / receipt["log_file"]).read_bytes()
    assert len(raw) == receipt["log_bytes"] and sha(raw) == receipt["log_sha256"]
    junit = ET.fromstring((root / "original/real-provider-smoke.junit.xml").read_bytes())
    cases = list(junit.iter("testcase"))
    assert len(cases) == 1 and cases[0].find("failure") is not None and cases[0].find("skipped") is None
    assert cases[0].get("name") == "real_agentd_loopback_provider_read_only_smoke"
    assert junit.get("uuid") == "20e63f6c-6648-4068-9b54-51f828fd99cc"
    assert junit.get("uuid").encode() in raw and b"timed out waiting for turn/completed" in raw
    observations = json.loads((root / "original/PROVIDER_OBSERVATIONS.json").read_text())
    assert [row["phase"] for row in observations] == ["fixture_retained", "configured", "test_owner_ready", "thread_started", "turn_admitted"]
    assert observations[-1]["thread_id"] == "01a1c8ef-125f-75ae-aaf1-0fe5a4c079f6"
    assert observations[-1]["observed_turn_id"] == "01a1c8ef-1fbd-75b0-bc6e-2b22a1f1f596"
    settlement = json.loads((root / "readonly-v2/RESULT.json").read_text())
    assert settlement["original_databases_and_wal_unchanged"] is True
    assert settlement["rollout_terminal_observed"] is False and settlement["rollout_assistant_observed"] is False
    source = json.loads((root / "source/SOURCE_BINDING.json").read_text())
    for entry in source["files"]:
        data = (root / "source" / entry["path"]).read_bytes()
        assert len(data) == entry["bytes"] and sha(data) == entry["sha256"]
        assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == entry["git_blob"]
    return {"member_count": len(actual), "all_member_hashes_verified": True, "unsafe_original_projection_members": 0, "nested_archives_or_capsules": 0, "derived_projections": 2, "original_native_selected": 1, "original_native_passed": 0, "original_native_failed": 1, "selected_skipped": 0, "filtered_or_ignored": 12, "physical_provider_outcome": "UNKNOWN", "original_source_clean": True, "world_state_values_present_in_derived_projection": False}


if __name__ == "__main__":
    print(json.dumps(verify(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]), indent=2))
