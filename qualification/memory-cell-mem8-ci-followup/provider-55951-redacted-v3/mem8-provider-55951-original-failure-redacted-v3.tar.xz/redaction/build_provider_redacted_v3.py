import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile
import xml.etree.ElementTree as ET
from redact_provider_projection_v3 import redact_projection

BASE = Path(__file__).resolve().parent
ORIGINAL = BASE / "provider-unsafe-original-local-only-v2.tar.xz"
STAGE = BASE / "provider-safe-v3-complete"
SHA = "2afb2e0bf0dca015061e1773cbddb38ced52331c019405b95adaacbd9b3bf4df"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def gitsha(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def jb(value):
    return (json.dumps(value, indent=2) + "\n").encode()


def main():
    original = ORIGINAL.read_bytes()
    assert len(original) == 52368 and sha(original) == SHA and gitsha(original) == "0338719385dda608a7815179f88e93265b8a5be3"
    files = {}
    with tarfile.open(fileobj=io.BytesIO(original), mode="r:xz") as archive:
        for member in archive.getmembers():
            assert member.isfile() and not member.name.startswith("/") and ".." not in Path(member.name).parts
            assert member.name not in files
            files[member.name] = archive.extractfile(member).read()
    old_manifest = json.loads(files["FILE_MANIFEST.json"])
    assert set(files) == {row["path"] for row in old_manifest["files"]} | {"FILE_MANIFEST.json"}
    for row in old_manifest["files"]:
        assert len(files[row["path"]]) == row["bytes"] and sha(files[row["path"]]) == row["sha256"]
    native_original = {name: data for name, data in files.items() if name.startswith("original/")}
    originals = []
    forbidden = []
    for label in ("v1", "v2"):
        name = "readonly-" + label + "/ROLLOUT_SAFE_OBSERVATIONS.json"
        raw = files.pop(name)
        host_path = "/home/qian-qi/mem8-provider-original-settlement-ed353817-" + label + "/ROLLOUT_SAFE_OBSERVATIONS.json"
        projected, strings = redact_projection(raw, host_path)
        forbidden += strings
        new_name = "readonly-" + label + "/ROLLOUT_REDACTED_OBSERVATIONS.json"
        files[new_name] = jb(projected)
        originals.append({"excluded_member": name, "original_private_host_path": host_path, "original_bytes": len(raw), "original_sha256": sha(raw), "original_flag_private_context_text_exported": False, "original_flag_was_incorrect": True, "derived_member": new_name, "derived_bytes": len(files[new_name]), "derived_sha256": sha(files[new_name])})
    del files["FILE_MANIFEST.json"]
    del files["README.md"]
    erratum = {
        "schema": "hepta.mem8.provider-projection-privacy-erratum.v1",
        "original_host_records_modified": False,
        "original_native_logs_receipts_junit_modified": False,
        "original_native_test_status": "FAILED",
        "physical_provider_outcome": "UNKNOWN",
        "cause": "Both prior readonly projections copied world_state.state as an entire object while incorrectly declaring private_context_text_exported=false.",
        "correction": "Exclude both original projections. Publish explicitly derived scalar observations and world_state field names/hash/length only. Retain ready only for the event_msg turn_recovery_candidate scalar.",
        "projections": originals,
        "do_not_reference_objects": [
            {"kind": "unsafe_unreferenced_v2_archive", "git_blob": "0338719385dda608a7815179f88e93265b8a5be3", "bytes": 52368, "sha256": SHA},
            {"kind": "superseded_v2_manifest", "git_blob": "48787ad0877c8c4288ba3253939102bb11dc78d7"},
        ],
        "unsafe_objects_uploaded_at": "2026-11-11T06:08:24.647272+00:00",
        "unsafe_objects_not_added_to_tree_commit_or_ref_by_this_task": True,
        "unsafe_archive_and_original_projection_bytes_excluded_from_this_package": True,
        "model_calls_or_database_queries_performed_by_redaction": 0,
    }
    files["PROJECTION_PRIVACY_ERRATUM.json"] = jb(erratum)
    files["redaction/redact_provider_projection_v3.py"] = (BASE / "redact_provider_projection_v3.py").read_bytes()
    files["redaction/build_provider_redacted_v3.py"] = Path(__file__).read_bytes()
    files["redaction/verify_provider_redacted_v3.py"] = (BASE / "verify_provider_redacted_v3.py").read_bytes()
    files["README.md"] = b"""# Original provider failure, with explicitly redacted retained-owner observations

The sole published55951 native smoke selected one case and failed waiting20 seconds for its original turn/completed notification. Its complete raw stdout/stderr, JUnit, exact-head clean receipts, build, source postimages, five phase markers and original driver remain byte-identical to the previously captured files. The20 seconds applies only to that completion wait; it is not a total probe limit. The after-probe health GET failedHTTP502, so unchanged gateway routing across the probe is not established.

The original read-only observations did not find a completed model outcome. Their v1 attempt failed on the old logs column; v2 completed with mode=ro and unchanged database/WAL bytes and metadata. No owner was restarted or model request repeated. The original thread retains a user message and ready recovery candidate, but no assistant or terminal; the exact queue binding is empty. Zero projected tokens or an empty queue does not prove no physical model request.

## Privacy correction

Both original ROLLOUT_SAFE_OBSERVATIONS.json files were incorrectly marked private_context_text_exported=false while copying the world_state.state object, including context text. They are excluded from this package and remain unchanged at their original private paths. The prior v2 archive was uploaded as an unreferenced Git blob before this defect was noticed; its archive/manifest objects are explicitly marked DO NOT REFERENCE in PROJECTION_PRIVACY_ERRATUM.json. No tree, commit or ref was created for them by this task, and neither original unsafe projection nor that archive is embedded here.

ROLLOUT_REDACTED_OBSERVATIONS.json is a new derived artifact, not an assertion of original-byte identity. It includes the excluded original projection's byte size and SHA256, each original rollout line hash, an allowlisted set of scalar observations, and only type/hash/length/field names for world_state. Scalar ready is retained only for an event_msg turn_recovery_candidate. The original false privacy flag is explicitly identified as incorrect. The redaction performs no database query, owner action, model request or mutation of original records.

All original/ files remain byte-identical. Every resulting member was checked against the removed world_state context strings in plain and JSON-escaped form; no nested archive/capsule, database, key file, unsafe original projection or v2 archive is included. The earlier producer scripts are retained as historical code; their now-superseded export assertions are not the current safety finding.

The physical provider request count, remote response outcome, model request ID, remote model echo and provider-payload tool inventory remain UNKNOWN or unobserved. GET request IDs are not model request IDs. This fresh temporary Fleet is not a production-custody or memory-benefit qualification. Later bounded gateway observations have a separate identity and cannot rewrite this failed native attempt.

Run python3 redaction/verify_provider_redacted_v3.py PATH_TO_EXTRACTED_PACKAGE to verify every member, the original failure, and the derived projection boundaries.
"""
    # Check every actual final member, including historical source and JSON containers.
    assert all(not name.endswith((".xz", ".gz", ".zip", ".tar", ".sqlite", ".db", ".pem", ".key")) for name in files)
    assert all(not name.endswith("/ROLLOUT_SAFE_OBSERVATIONS.json") for name in files)
    unique_forbidden = sorted(set(forbidden))
    for name, data in files.items():
        for value in unique_forbidden:
            for needle in (value.encode(), json.dumps(value)[1:-1].encode(), json.dumps(value, ensure_ascii=False)[1:-1].encode()):
                assert needle not in data, ("context text leaked", name)
        assert not re.search(rb"gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,}", data), name
    assert all(files[name] == data for name, data in native_original.items())
    scan = {"all_members_scanned": len(files) + 2, "forbidden_world_state_unique_long_strings": len(unique_forbidden), "forbidden_values": [{"utf8_bytes": len(value.encode()), "sha256": sha(value.encode())} for value in unique_forbidden], "plain_and_json_escaped_search": True, "native_original_members_unchanged": len(native_original), "nested_archives_or_capsules": 0, "original_unsafe_projection_members": 0, "unsafe_v2_archive_members": 0}
    files["REDACTION_MEMBER_AUDIT.json"] = jb(scan)
    manifest = {"schema": "hepta.mem8.provider-redacted-package-files.v1", "manifest_excludes_itself": True, "files": [{"path": name, "bytes": len(data), "sha256": sha(data)} for name, data in sorted(files.items())]}
    files["FILE_MANIFEST.json"] = jb(manifest)
    for name, data in files.items():
        for value in unique_forbidden:
            for needle in (value.encode(), json.dumps(value)[1:-1].encode(), json.dumps(value, ensure_ascii=False)[1:-1].encode()):
                assert needle not in data, ("context text leaked in final member", name)
    STAGE.mkdir(mode=0o700)
    for name, data in files.items():
        path = STAGE / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    from verify_provider_redacted_v3 import verify
    validated = verify(STAGE)
    archive_path = BASE / "mem8-provider-55951-original-failure-redacted-v3.tar.xz"
    with tarfile.open(archive_path, "w:xz") as archive:
        for name, data in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
    data = archive_path.read_bytes()
    assert len(data) < 500000
    with tarfile.open(archive_path, "r:xz") as archive:
        assert len(archive.getmembers()) == len(files)
        for member in archive.getmembers():
            assert archive.extractfile(member).read() == files[member.name]
    publication = {"archive_name": archive_path.name, "bytes": len(data), "sha256": sha(data), "git_blob": gitsha(data), "member_count": len(files), "source_commit": "55951ed9094ae894f0256a3461fd9504ef060473", "source_tree": "2ca6930d8abd148fe26fbe7d2857c760daa9316b", "original_native_passed": 0, "original_native_failed": 1, "physical_provider_outcome": "UNKNOWN", "derived_redaction": True, "original_host_records_modified": False, "all_tar_member_bytes_read_back": True, "local_verifier": validated, "publication_state": "LOCAL_REVIEW_ONLY"}
    (BASE / "PROVIDER_REDACTED_V3_MANIFEST.json").write_bytes(jb(publication))
    (BASE / "PROVIDER_REDACTED_V3_MEMBER_LIST.json").write_bytes(jb(manifest))
    print(json.dumps(publication, indent=2))


if __name__ == "__main__":
    main()
