import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET

TASK = Path(__file__).resolve().parent
STAGING = TASK / 'files'
ORIGINAL = Path('/home/qian-qi/mem8-native-provider-qualified-ed353817-v1')
RECORDS = ORIGINAL / 'records'
SOURCE = Path('/home/qian-qi/mem8-windows-owner-bytes-published-ed353817-v3/source')
HEAD = '55951ed9094ae894f0256a3461fd9504ef060473'
TREE = '2ca6930d8abd148fe26fbe7d2857c760daa9316b'
THREAD = '01a1c8ef-125f-75ae-aaf1-0fe5a4c079f6'
TURN = '01a1c8ef-1fbd-75b0-bc6e-2b22a1f1f596'
PTYROOT = Path('/home/qian-qi/.local/state/hepta-runtime-mac-worker/terminals')
ORIGINAL_PTY = 'dpty-3487d5f846e4631ca4ab45ad4bee36dce74a07d94e5fa0b88ef695cbdd8e5b3f'
PROBES = [('v1', 'dpty-176c4399f3d6e387b9cefa15433c27f619fa82a730def9c32c93b8d67d10f4e7', 'e99203aa8d399fa2bf2a7eb6f33681ae072beec02c3271c2fb9565191b3718ac'), ('v2', 'dpty-e070ff9382d9451dcfbac806c5eca627855aed113461034316446e2256482d7d', 'bd8b6345ef84abba7f406180fc5ee0d6baf8c1bf772a31fbdfe306272cd72a86')]
REPO = 'TrillionniumFoundation/hepta-private-ci'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(name, data):
    target = STAGING / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as handle:
        handle.write(data)


def save(name, value):
    write(name, (json.dumps(value, indent=2) + '\n').encode())


def copy(path, relative):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size < 4 * 1024 * 1024
    data = path.read_bytes()
    after = path.lstat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    write(relative, data)
    return data


def gh_blob(data):
    expected = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    env = dict(os.environ)
    env.pop('GH_DEBUG', None)
    request = json.dumps({'encoding': 'base64', 'content': base64.b64encode(data).decode()}).encode()
    response = subprocess.check_output(['gh', 'api', '--method', 'POST', 'repos/' + REPO + '/git/blobs', '--input', '-'], input=request, env=env)
    value = json.loads(response)
    assert value['sha'] == expected
    return expected


def restore_probe_script(label, session, expected):
    request_path = PTYROOT / session / 'request.json'
    request_bytes = request_path.read_bytes()
    value = json.loads(request_bytes)
    candidates = []
    def visit(item):
        if isinstance(item, dict):
            for key, child in item.items():
                if key in ('args', 'argv') and isinstance(child, list):
                    candidates.extend(x for x in child if isinstance(x, str) and len(x) > 1000 and THREAD in x)
                elif key not in ('env', 'environment', 'credentials', 'auth'):
                    visit(child)
        elif isinstance(item, list):
            for child in item:
                visit(child)
    visit(value)
    matches = {candidate for candidate in candidates if digest(candidate.encode()) == expected}
    assert len(matches) == 1, ('exact probe source not recovered', label)
    script = matches.pop().encode()
    write('readonly-' + label + '/executed_script.py', script)
    save('readonly-' + label + '/SCRIPT_PROVENANCE.json', {'session_id': session, 'request_metadata_path': str(request_path), 'request_metadata_sha256': digest(request_bytes), 'script_sha256': expected, 'script_bytes': len(script), 'extraction': 'Only args/argv strings; exact pre-launch SHA256 match', 'environment_or_auth_fields_exported': False})
    copy(PTYROOT / session / 'output.log', 'readonly-' + label + '/pty-output.raw.log')
    copy(PTYROOT / session / 'exit.json', 'readonly-' + label + '/pty-exit.json')


def main():
    os.umask(0o077)
    STAGING.mkdir(mode=0o700)
    names = ['PROVIDER_COMMAND_INTENT.json', 'PROVIDER_BINARY.json', 'PROVIDER_SOURCE_IDENTITY.json', 'PROVIDER_OBSERVATIONS.json', 'PROVIDER_OBSERVATION_AUDIT.json', 'RETAINED_FIXTURE.json', 'GATEWAY_BEFORE.json', 'gateway-before-health.body.json', 'gateway-before-routing.body.json', 'gateway-before-models.body.json', 'DRIVER_FAILURE.txt', 'provider-source-format.json', 'provider-source-format.stdout.log', 'provider-source-format.stderr.log', 'published-agentd-binary.json', 'published-agentd-binary.audit.json', 'published-agentd-binary.wrapper.stdout.log', 'published-agentd-binary.wrapper.stderr.log', 'real-provider-smoke.json', 'real-provider-smoke.audit.json', 'real-provider-smoke.junit.xml', 'real-provider-smoke.wrapper.stdout.log', 'real-provider-smoke.wrapper.stderr.log']
    for name in names:
        copy(RECORDS / name, 'original/' + name)
    for name in ('published-agentd-binary', 'real-provider-smoke'):
        receipt = json.loads((RECORDS / (name + '.json')).read_text())
        log_name = receipt['log_file']
        assert Path(log_name).name == log_name
        data = copy(RECORDS / log_name, 'original/' + log_name)
        assert len(data) == receipt['log_bytes'] and digest(data) == receipt['log_sha256']
    native_driver = [path for path in ORIGINAL.glob('*.py') if digest(path.read_bytes()) == '7c8bdad1d12a65babf7171dfcd571d801c754a3a197b405b00b97ddc8f048451']
    assert len(native_driver) == 1
    copy(native_driver[0], 'driver/run_native_provider_v1.py')
    copy(PTYROOT / ORIGINAL_PTY / 'output.log', 'driver/original-pty-output.raw.log')
    copy(PTYROOT / ORIGINAL_PTY / 'exit.json', 'driver/original-pty-exit.json')
    copy(Path(__file__), 'driver/package_provider_original_on_host_v1.py')
    source_entries = []
    for path, expected_blob in [('codex-rs/hepta-agentd/tests/cognitive_product_e2e.rs', '2d86359ec9e488369c47d182ac9d8fc273b9f675'), ('codex-rs/hepta-agentd/tests/support/fleet.rs', '169ccd842b31c9550cb000f520f8a6e66c5c5bb6')]:
        data = subprocess.check_output(['git', '-C', str(SOURCE), 'show', HEAD + ':' + path])
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert actual == expected_blob
        write('source/' + path, data)
        source_entries.append({'path': path, 'bytes': len(data), 'sha256': digest(data), 'git_blob': actual})
    save('source/SOURCE_BINDING.json', {'commit': HEAD, 'tree': TREE, 'files': source_entries, 'source_files_from_original_git_objects': True})
    for label, session, expected in PROBES:
        restore_probe_script(label, session, expected)
        folder = Path('/home/qian-qi/mem8-provider-original-settlement-ed353817-' + label)
        paths = ['INTENT.json', 'ROLLOUT_SAFE_OBSERVATIONS.json', 'state_5.sqlite.SAFE_QUERY.json', 'queue_1.sqlite.SAFE_QUERY.json']
        if label == 'v2':
            paths += ['RESULT.json', 'logs_2.sqlite.SAFE_QUERY.json', 'state_5.sqlite.SCHEMA.json', 'queue_1.sqlite.SCHEMA.json', 'logs_2.sqlite.SCHEMA.json']
        for name in paths:
            copy(folder / name, 'readonly-' + label + '/' + name)
    smoke = json.loads((STAGING / 'original/real-provider-smoke.json').read_text())
    assert smoke['before'] == smoke['after'] and smoke['before']['commit'] == HEAD and smoke['before']['tree'] == TREE and smoke['before']['dirty'] is False
    assert smoke['status'] == 'failed' and smoke['command_exit_code'] == 100 and smoke['observed_passed_tests'] == 0 and smoke['observed_failed_tests'] == 1 and smoke['timed_out'] is False
    raw = (STAGING / 'original' / smoke['log_file']).read_bytes()
    junit_bytes = (STAGING / 'original/real-provider-smoke.junit.xml').read_bytes()
    junit = ET.fromstring(junit_bytes)
    cases = list(junit.iter('testcase'))
    assert len(cases) == 1 and cases[0].get('name') == 'real_agentd_loopback_provider_read_only_smoke' and cases[0].find('failure') is not None and cases[0].find('skipped') is None
    assert junit.get('uuid') == '20e63f6c-6648-4068-9b54-51f828fd99cc' and junit.get('uuid').encode() in raw
    assert b'timed out waiting for turn/completed' in raw
    observations = [json.loads(line.split('HEPTA_PROVIDER_QUALIFICATION ', 1)[1]) for line in raw.decode().splitlines() if 'HEPTA_PROVIDER_QUALIFICATION ' in line]
    assert observations == json.loads((STAGING / 'original/PROVIDER_OBSERVATIONS.json').read_text())
    assert [row['phase'] for row in observations] == ['fixture_retained', 'configured', 'test_owner_ready', 'thread_started', 'turn_admitted']
    assert observations[-1]['thread_id'] == THREAD and observations[-1]['observed_turn_id'] == TURN
    assert observations[1]['request_max_retries'] == observations[1]['stream_max_retries'] == 0 and observations[1]['unbounded_connection_retries'] is False and observations[1]['supports_websockets'] is False
    assert observations[1]['turn_completion_timeout_seconds'] == 20
    settlement = json.loads((STAGING / 'readonly-v2/RESULT.json').read_text())
    assert settlement['intent']['thread_id'] == THREAD and settlement['intent']['turn_id'] == TURN and settlement['original_databases_and_wal_unchanged'] is True
    assert settlement['rollout_terminal_observed'] is False and settlement['rollout_assistant_observed'] is False and settlement['queue_binding_rows'] == [] and settlement['log_rows_observed'] == 20
    for filename in ('state_5.sqlite', 'queue_1.sqlite', 'logs_2.sqlite'):
        result = json.loads((STAGING / ('readonly-v2/' + filename + '.SAFE_QUERY.json')).read_text())
        assert result['before'] == result['after'] and result['original_database_and_wal_unchanged'] is True
    assert 'HTTP Error 502: Bad Gateway' in (STAGING / 'original/DRIVER_FAILURE.txt').read_text()
    save('QUALIFICATION_RESULT.json', {'source_commit': HEAD, 'source_tree': TREE, 'native_tests': {'selected': 1, 'passed': 0, 'failed': 1, 'selected_skipped': 0, 'filtered_or_ignored': 12, 'retries': 0, 'junit_run_id': junit.get('uuid')}, 'thread_id': THREAD, 'turn_id': TURN, 'original_provider_test_failed': True, 'turn_completion_wait_seconds': 20, 'whole_probe_bounded_to_20_seconds_claimed': False, 'after_gateway_get_failed_http502': True, 'gateway_configuration_unchanged_claimed': False, 'readonly_v1_failed_on_old_message_column': True, 'readonly_v2_completed_without_database_or_wal_change': True, 'remote_model_outcome_observed': False, 'physical_model_request_count_observed': False, 'provider_payload_tool_inventory_observed': False, 'production_owner_custody_claimed': False, 'memory_benefit_claimed': False})
    readme = '''# Original real-provider smoke: failed, with retained-owner observations

This preserves the sole published55951 real-provider attempt. One selected native test failed while waiting20 seconds for its original turn/completed notification. The outer command did not hit its own timeout. Twelve other tests were filtered/ignored, not selected skips. The20 seconds applies only to the completion wait after TurnStart ACK, not the complete probe/compile/startup duration.

The full command stdout/stderr, JUnit, exact-head clean receipts, true Agentd build, original driver, source postimages, five phase markers, before-only public gateway snapshots, and complete original PTY output are included. The subsequent GET health check failed HTTP502. Duplicate traceback printouts in the PTY are the driver's print-and-reraise path; they do not represent another model invocation. No successful after-gateway snapshot exists, so unchanged routing across the probe is not claimed.

The first read-only reconciliation stopped on the older logs schema's missing message column. Its original code and failure remain included. The second used the actual feedback_log_body column. Both original scripts were recovered only from their own PTY request args and matched the recorded pre-launch SHA256 exactly; env/auth fields were not exported. The second queried only the original thread/client key with SQLite mode=ro and query_only, and verified original database and WAL bytes/metadata before and after. Private databases, WAL files, auth configuration, fixture keys, and raw feedback message bodies are not exported.

At the second observation, the original process PID path was absent. The rollout retained the original user/client key and turn recovery candidate, but no assistant/terminal. The exact queue binding query was empty. The thread projection recorded zero tokens and has_user_event=0 despite the separately persisted rollout user message; neither projection is evidence of no model call. Twenty thread-scoped log rows provided no HTTP status/terminal. The TLS keyword classifications on two INFO rows are not TLS-error findings.

The retained fixture is a fresh temporary test Fleet, not an established production owner. No owner was restarted, no turn was resumed, and no model call was replayed during reconciliation. The physical provider request count, remote response outcome, model request ID, provider payload tool inventory, and remote model echo remain unobserved. GET request IDs are not model request IDs. Any later bounded gateway investigation belongs in a separate evidence record and must not rewrite this original failure.

FILE_MANIFEST.json hashes every packaged member except itself. QUALIFICATION_RESULT.json is a derived summary; the original command receipts, full raw log, JUnit and source identities are the primary evidence. The package producer verifies them before uploading. This package does not establish a successful provider gate, full CI, production custody, cold recovery, or memory benefit.
'''
    write('README.md', readme.encode())
    files = []
    for path in sorted(STAGING.rglob('*')):
        if path.is_file():
            data = path.read_bytes()
            assert not re.search(rb'gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,}', data), 'credential-like material found; refusing publication'
            files.append({'path': str(path.relative_to(STAGING)), 'bytes': len(data), 'sha256': digest(data)})
    save('FILE_MANIFEST.json', {'schema': 'hepta.mem8.original-provider-failure.v1', 'manifest_excludes_itself': True, 'files': files})
    archive = TASK / 'mem8-provider-55951-original-failure-and-settlement-v1.tar.xz'
    with tarfile.open(archive, 'w:xz') as tar:
        for path in sorted(STAGING.rglob('*')):
            if path.is_file():
                info = tar.gettarinfo(str(path), str(path.relative_to(STAGING)))
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                with path.open('rb') as handle:
                    tar.addfile(info, handle)
    data = archive.read_bytes()
    assert len(data) <= 500000
    with tarfile.open(archive, 'r:xz') as tar:
        for member in tar.getmembers():
            assert tar.extractfile(member).read() == (STAGING / member.name).read_bytes()
    archive_sha = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    manifest = {'schema': 'hepta.mem8.provider-original-package.v1', 'archive_name': archive.name, 'bytes': len(data), 'sha256': digest(data), 'git_blob': archive_sha, 'source_commit': HEAD, 'source_tree': TREE, 'native_passed': 0, 'native_failed': 1, 'selected_skipped': 0, 'filtered_or_ignored': 12, 'thread_id': THREAD, 'turn_id': TURN, 'readonly_original_scripts_exactly_recovered': True, 'original_raw_and_junit_hashes_verified': True, 'all_tar_member_bytes_read_back': True, 'remote_model_outcome_observed': False, 'whole_ci_pass_claimed': False}
    manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
    (TASK / 'MANIFEST.json').write_bytes(manifest_bytes)
    assert gh_blob(data) == archive_sha
    manifest_blob = gh_blob(manifest_bytes)
    publication = {**manifest, 'manifest_git_blob': manifest_blob, 'published_at': datetime.now(timezone.utc).isoformat()}
    (TASK / 'PUBLICATION.json').write_text(json.dumps(publication, indent=2) + '\n')
    print(json.dumps(publication, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
