import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time
import traceback
import urllib.request
import uuid
import xml.etree.ElementTree as ET

TASK = Path('/home/qian-qi/mem8-native-provider-qualified-ed353817-v1')
SOURCE = Path('/home/qian-qi/mem8-windows-owner-bytes-published-ed353817-v3/source')
RECORDS = TASK / 'records'
TARGET = Path('/home/qian-qi/mem8-windows-owner-bytes-ed353817-v1/target')
CB = 'cb0b276ffdb9852323cdd13ba9b4399b30ae0c37'
HEAD = '55951ed9094ae894f0256a3461fd9504ef060473'
TREE = '2ca6930d8abd148fe26fbe7d2857c760daa9316b'
CASE = 'circuit_cell::tests::credit_tests::signed_tests::signed_credit_rejects_cross_owner_ledger_episode_before_any_append'
SMOKE = 'real_agentd_loopback_provider_read_only_smoke'
ROUTE = 'http://127.0.0.1:18083'
MODEL = 'qwen38-flash-next-uc'
CONFIG_SHA = '14cc9e9df85b3408dee556750fb680a13a5f6b4793400f87d97d0cad04c6f506'
SERVICE_SOURCE = Path('/home/qian-qi/.local/lib/hepta-inference-transport/v5-openresponses-20261024-r1/client_transport.py')
SERVICE_SHA = 'a49d2e05f34a7eb7556332004cacc08131ae39fd6e6bb8eb9460a179adfb608b'
ENV = {**os.environ, 'PATH': '/home/qian-qi/.cargo/bin:/home/qian-qi/.local/bin:' + os.environ.get('PATH', ''), 'RUSTUP_TOOLCHAIN': '1.96.0', 'CARGO_TARGET_DIR': str(TARGET), 'CARGO_BUILD_JOBS': '4', 'PYTHONDONTWRITEBYTECODE': '1', 'RUST_BACKTRACE': '1', 'TMPDIR': '/tmp'}


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while b := f.read(1024 * 1024):
            h.update(b)
    return h.hexdigest()


def save(name, obj):
    with (RECORDS / name).open('x') as f:
        json.dump(obj, f, indent=2)
        f.write('\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True).strip()


def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'parents': git('show', '-s', '--format=%P').split(), 'dirty': bool(git('status', '--porcelain=v1'))}


def prep(name, cmd, cwd=SOURCE):
    with (RECORDS / (name + '.stdout.log')).open('xb') as out, (RECORDS / (name + '.stderr.log')).open('xb') as err:
        r = subprocess.run(cmd, cwd=cwd, env=ENV, stdout=out, stderr=err, timeout=900)
    save(name + '.json', {'command': cmd, 'cwd': str(cwd), 'exit_code': r.returncode, 'finished_at': now()})
    print('MEM8_NATIVE_PROVIDER_PREPARE ' + json.dumps({'name': name, 'exit_code': r.returncode}), flush=True)
    if r.returncode:
        raise RuntimeError(name + ' failed; do not replay automatically')


def archive_bazel_and_reclaim_owned_cache():
    root = Path('/home/qian-qi/mem8-dependency-bazel-cache-ed353817-v3')
    receipts = root / 'records'
    result = json.loads((receipts / 'RESULT.json').read_text())
    assert result['gate_passed'] and result['after'] == {'commit': 'dc96a441312e239c165c1642880084dfeccc2c71', 'tree': '7796279284170f0f2c92449c1185eecac1f4f1b6', 'dirty': False}
    archive = TASK / 'bazel-clean-cache-v3.tar.xz'
    manifest = []
    with tarfile.open(archive, 'w:xz') as tar:
        for path in sorted(receipts.iterdir()):
            if path.is_file():
                manifest.append({'path': 'bazel-v3/' + path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)})
                tar.add(path, arcname='bazel-v3/' + path.name, recursive=False)
        old = Path('/home/qian-qi/mem8-dependency-validation-ed353817-v2/records')
        report = json.loads((old / 'bazel-lock-update.json').read_text())
        for name in ('bazel-lock-update.json', report['log_file']):
            path = old / name
            assert path.parent == old
            manifest.append({'path': 'original-failed-v2/' + name, 'bytes': path.stat().st_size, 'sha256': digest(path)})
            tar.add(path, arcname='original-failed-v2/' + name, recursive=False)
    archive_sha = digest(archive)
    with tarfile.open(archive, 'r:xz') as tar:
        by_name = {x['path']: x for x in manifest}
        for member in tar.getmembers():
            raw = tar.extractfile(member).read()
            assert len(raw) == by_name[member.name]['bytes'] and hashlib.sha256(raw).hexdigest() == by_name[member.name]['sha256']
    save('BAZEL_ARCHIVE.json', {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': archive_sha, 'members': manifest, 'source_commit': result['source']['commit'], 'source_tree': result['source']['tree'], 'original_failure_preserved': True})
    removed = []
    free_before = shutil.disk_usage(root).free
    for name in ('output-base', 'repo-contents-cache', 'repository-cache'):
        path = root / name
        if path.exists():
            assert path.is_dir() and not path.is_symlink() and path.resolve().is_relative_to(root.resolve())
            for directory, _, _ in os.walk(path, followlinks=False):
                os.chmod(directory, 0o700, follow_symlinks=False)
            shutil.rmtree(path)
            removed.append(str(path))
    save('OWNED_CACHE_RECLAIM.json', {'removed_rebuildable_task_cache_only': removed, 'source_and_records_retained': True, 'original_shared_cache_touched': False, 'archive_sha256': archive_sha, 'free_before': free_before, 'free_after': shutil.disk_usage(root).free, 'finished_at': now()})
    print('MEM8_BAZEL_ARCHIVE_AND_OWN_CACHE_RECLAIM ' + json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': archive_sha, 'free_after': shutil.disk_usage(root).free}), flush=True)


def phase(name, command, expected_case=None, extra_env=None):
    before = identity()
    assert not before['dirty']
    output = RECORDS / (name + '.json')
    junit = SOURCE / 'codex-rs/target/nextest/local/junit.xml'
    previous = (junit.stat().st_mtime_ns, digest(junit)) if junit.is_file() else None
    env = {**ENV, 'SOURCE_SHA': before['commit'], 'TESTED_SHA': before['commit'], 'BASE_SHA': CB if before['commit'] == HEAD else '4eb497e889b053dd40af87469e594d08585f93e8', 'HEPTA_CI_LANE': 'source-head', **(extra_env or {})}
    count = 1 if expected_case else 0
    wrapper = [sys.executable, '-B', str(SOURCE / 'scripts/hepta_ci_exec.py'), '--output', str(output), '--minimum-tests', str(count), '--timeout-seconds', '10800', '--', *command]
    print('MEM8_NATIVE_PROVIDER_PHASE_START ' + json.dumps({'name': name, 'source': before, 'command': command, 'started_at': now()}), flush=True)
    with (RECORDS / (name + '.wrapper.stdout.log')).open('xb') as out, (RECORDS / (name + '.wrapper.stderr.log')).open('xb') as err:
        result = subprocess.run(wrapper, cwd=SOURCE / 'codex-rs', env=env, stdout=out, stderr=err)
    receipt = json.loads(output.read_text())
    after = identity()
    raw = (RECORDS / receipt['log_file']).read_bytes()
    assert len(raw) == receipt['log_bytes'] and hashlib.sha256(raw).hexdigest() == receipt['log_sha256']
    audit = {'before': before, 'after': after, 'command': command, 'exit_code': result.returncode, 'receipt_status': receipt['status'], 'observed_passed': receipt['observed_passed_tests'], 'observed_failed': receipt['observed_failed_tests'], 'log_sha256': receipt['log_sha256'], 'log_bytes': len(raw), 'summaries': re.findall(r'Summary[^\n]+', raw.decode()), 'expected_case': expected_case}
    current = (junit.stat().st_mtime_ns, digest(junit)) if junit.is_file() else None
    if expected_case and current is not None and current != previous:
        jb = junit.read_bytes()
        (RECORDS / (name + '.junit.xml')).write_bytes(jb)
        doc = ET.fromstring(jb)
        cases = list(doc.iter('testcase'))
        ids = [(x.get('classname'), x.get('name')) for x in cases]
        assert len(ids) == len(set(ids))
        audit['junit'] = {'sha256': hashlib.sha256(jb).hexdigest(), 'run_id': doc.get('uuid'), 'ids': ids, 'failed': sum(x.find('failure') is not None or x.find('error') is not None for x in cases), 'skipped': sum(x.find('skipped') is not None for x in cases)}
    passed = result.returncode == 0 and receipt['status'] == 'passed' and before == after
    if expected_case:
        passed = passed and audit.get('junit', {}).get('ids') == [tuple(expected_case)] and not audit['junit']['failed'] and not audit['junit']['skipped'] and audit['observed_passed'] == 1 and audit['observed_failed'] == 0
    audit['gate_passed'] = bool(passed)
    save(name + '.audit.json', audit)
    print('MEM8_NATIVE_PROVIDER_PHASE_RESULT ' + json.dumps(audit), flush=True)
    assert before == after, 'source changed during execution'
    return audit, raw.decode()


def gateway_snapshot(label):
    assert digest(SERVICE_SOURCE) == SERVICE_SHA
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    results = {}
    for name, suffix in [('health', '/health'), ('routing', '/routing'), ('models', '/v1/models')]:
        client_request_id = 'mem8-provider-' + label + '-' + uuid.uuid4().hex
        request = urllib.request.Request(ROUTE + suffix, headers={'X-Request-ID': client_request_id})
        started = now()
        with opener.open(request, timeout=15) as response:
            raw = response.read(1024 * 1024 + 1)
            assert len(raw) <= 1024 * 1024
            status = response.status
            headers = {k: response.headers[k] for k in ('Content-Type', 'Date', 'X-Request-ID') if response.headers.get(k)}
        assert status == 200
        value = json.loads(raw)
        (RECORDS / ('gateway-' + label + '-' + name + '.body.json')).write_bytes(raw)
        results[name] = {'url': ROUTE + suffix, 'client_probe_request_id': client_request_id, 'http_status': status, 'headers': headers, 'body_sha256': hashlib.sha256(raw).hexdigest(), 'body_bytes': len(raw), 'started_at': started, 'finished_at': now(), 'response': value}
    route = results['routing']['response']
    assert route['config_sha256'] == CONFIG_SHA and route['active'] == 'llamacpp'
    assert route['connect_only_failover'] is False and route['draining'] is False
    assert any(x.get('id') == MODEL for x in results['models']['response']['data'])
    stat = SERVICE_SOURCE.stat()
    results['service_source'] = {'path': str(SERVICE_SOURCE), 'sha256': SERVICE_SHA, 'bytes': stat.st_size, 'mode': oct(stat.st_mode & 0o7777), 'uid': stat.st_uid}
    save('GATEWAY_' + label.upper() + '.json', results)
    print('MEM8_GATEWAY_SNAPSHOT ' + json.dumps({'label': label, 'config_sha256': route['config_sha256'], 'routing_request_id': route.get('request_id'), 'active': route['active'], 'active_requests': route.get('active_requests'), 'queued_requests': route.get('queued_requests')}), flush=True)
    return results


def audit_provider_observations(raw):
    marker = 'HEPTA_PROVIDER_QUALIFICATION '
    observations = []
    for line in raw.splitlines():
        if marker in line:
            observations.append(json.loads(line.split(marker, 1)[1]))
    save('PROVIDER_OBSERVATIONS.json', observations)
    phases = [x.get('phase') for x in observations]
    retained = [x for x in observations if x.get('phase') == 'fixture_retained']
    if retained:
        assert len(retained) == 1
        root = Path(retained[0]['retained_fixture_root'])
        stat = root.lstat()
        assert root.is_dir() and not root.is_symlink() and stat.st_mode & 0o7777 == 0o700
        save('RETAINED_FIXTURE.json', {'path': str(root), 'mode': '0700', 'uid': stat.st_uid, 'exists_after_test': True, 'private_owner_state_retained_on_host': True, 'private_state_exported': False})
    expected = ['fixture_retained', 'configured', 'test_owner_ready', 'thread_started', 'turn_admitted', 'turn_completed_notification', 'persisted_read_only_turn_verified']
    if phases != expected:
        return {'verified': False, 'observed_phases': phases, 'expected_phases': expected, 'retained_fixture_observed': bool(retained)}
    _, config, owner, started, admitted, completed, persisted = observations
    assert config['requested_provider_base_url'] == ROUTE + '/v1' and config['requested_model'] == MODEL
    assert config['unbounded_connection_retries'] is False and config['supports_websockets'] is False
    assert config['request_max_retries'] == config['stream_max_retries'] == 0 and config['turn_completion_timeout_seconds'] == 20
    assert digest(Path(config['test_owner_home']) / 'config.toml') == config['rendered_config_sha256']
    import tomllib
    rendered = tomllib.loads((Path(config['test_owner_home']) / 'config.toml').read_text())
    assert rendered['features']['unbounded_connection_retries'] is False
    selected = rendered['model_providers']['local_mlx']
    assert selected['request_max_retries'] == selected['stream_max_retries'] == 0 and selected['supports_websockets'] is False
    assert selected['base_url'] == ROUTE + '/v1' and rendered['model'] == MODEL
    assert started['requested_model'] == started['observed_app_server_model'] == MODEL
    assert started['requested_provider'] == started['observed_app_server_provider'] == 'local_mlx'
    assert started['thread_id'] == admitted['thread_id'] == completed['observed_thread_id'] == persisted['observed_thread_id']
    assert admitted['observed_turn_id'] == completed['observed_turn_id'] == persisted['observed_turn_id']
    assert completed['observed_status'] == 'completed'
    assert persisted['full_persisted_items_checked'] and persisted['observed_tool_item_count'] == 0
    return {'verified': True, 'observed_phases': phases, 'thread_id': started['thread_id'], 'turn_id': admitted['observed_turn_id'], 'turn_start_rpc_id': admitted['rpc_request_id'], 'requested_client_user_message_id': admitted['requested_client_user_message_id'], 'observed_terminal_status': completed['observed_status'], 'test_owner_process_id': owner['process_id'], 'retained_fixture_root': config['retained_fixture_root'], 'test_owner_home': config['test_owner_home'], 'rendered_config_sha256': config['rendered_config_sha256'], 'provider_payload_tool_inventory_observed': False, 'physical_provider_request_count_observed': False, 'provider_response_model_echo_observed': False, 'production_owner_custody_or_episodic_benefit_claimed': False}


def main():
    TASK.mkdir(mode=0o700)
    RECORDS.mkdir(mode=0o700)
    (RECORDS / 'driver.py').write_bytes(Path(__file__).read_bytes())
    old = json.loads(Path('/home/qian-qi/mem8-windows-owner-bytes-published-ed353817-v3/records/signed-credit-original-case-linux.json').read_text())
    assert old['status'] == 'failed' and old['command_exit_code'] == 101 and old['source_sha'] == CB
    assert identity()['commit'] == CB and not identity()['dirty']
    archive_bazel_and_reclaim_owned_cache()
    helper = 'qualification/neuron-v13-generation/proposal_worker.py'
    expected_helper = git('rev-parse', 'HEAD:' + helper)
    assert int(git('cat-file', '-s', 'HEAD:' + helper)) < 16 * 1024 * 1024
    prep('materialize-exact-unix-helper', ['git', '-C', str(SOURCE), 'checkout', '--ignore-skip-worktree-bits', 'HEAD', '--', helper])
    assert git('hash-object', helper) == expected_helper and not identity()['dirty']
    save('LINUX_ATTEMPT_INPUT.json', {'source': identity(), 'materialized_path': helper, 'blob': expected_helper, 'prior_failed_attempt': '/home/qian-qi/mem8-windows-owner-bytes-published-ed353817-v3/records', 'no_source_change': True})
    linux, _ = phase('linux-original-case-v4', ['just', 'test', '--locked', '-p', 'codex-hepta-agentd', '--lib', '-E', 'test(=' + CASE + ')', '--test-threads', '1', '--no-tests', 'fail', '--retries', '0'], ('codex-hepta-agentd', CASE))
    prep('fetch-published-provider-head', ['git', '-C', str(SOURCE), 'fetch', '--depth=3', 'origin', HEAD])
    prep('checkout-published-provider-head', ['git', '-C', str(SOURCE), 'checkout', '--detach', HEAD])
    assert identity() == {'commit': HEAD, 'tree': TREE, 'parents': ['349f39e4478234a7259acbc8fa2d8961ff799133'], 'dirty': False}
    assert git('hash-object', 'codex-rs/hepta-agentd/tests/cognitive_product_e2e.rs') == '2d86359ec9e488369c47d182ac9d8fc273b9f675'
    assert git('hash-object', 'codex-rs/hepta-agentd/tests/support/fleet.rs') == '169ccd842b31c9550cb000f520f8a6e66c5c5bb6'
    save('PROVIDER_SOURCE_IDENTITY.json', identity())
    prep('provider-source-format', ['just', 'fmt', '--base', CB], SOURCE / 'codex-rs')
    assert not identity()['dirty']
    built, _ = phase('published-agentd-binary', ['cargo', 'build', '--locked', '-p', 'codex-hepta-agentd', '--bin', 'codex-hepta-agentd'])
    assert built['gate_passed'], 'source-bound Agentd binary did not build; no model call is allowed'
    binary = TARGET / 'debug/codex-hepta-agentd'
    assert binary.is_file() and os.access(binary, os.X_OK)
    save('PROVIDER_BINARY.json', {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': digest(binary), 'source': identity(), 'build_receipt': 'published-agentd-binary.json'})
    before_gateway = gateway_snapshot('before')
    command = ['just', 'test', '--locked', '-p', 'codex-hepta-agentd', '--test', 'cognitive_product_e2e', '-E', 'test(=' + SMOKE + ')', '--run-ignored', 'only', '--test-threads', '1', '--no-tests', 'fail', '--retries', '0', '--success-output', 'immediate', '--failure-output', 'immediate']
    save('PROVIDER_COMMAND_INTENT.json', {'source': identity(), 'command': command, 'attempt': 'mem8-native-provider-qualified-ed353817-v1', 'requested_endpoint': ROUTE + '/v1', 'requested_model': MODEL, 'turn_completion_wait_seconds': 20, 'automatic_replay_allowed': False, 'started_at': now()})
    extra = {'HEPTA_LOCAL_PROVIDER_BASE_URL': ROUTE + '/v1', 'HEPTA_LOCAL_PROVIDER_MODEL': MODEL, 'NEXTEST_BIN_EXE_codex-hepta-agentd': str(binary), 'CARGO_BIN_EXE_codex-hepta-agentd': str(binary)}
    smoke, raw = phase('real-provider-smoke', command, ('codex-hepta-agentd::cognitive_product_e2e', SMOKE), extra)
    try:
        observations = audit_provider_observations(raw)
        save('PROVIDER_OBSERVATION_AUDIT.json', observations)
    finally:
        after_gateway = gateway_snapshot('after')
    unchanged_gateway = before_gateway['routing']['response']['config_sha256'] == after_gateway['routing']['response']['config_sha256'] == CONFIG_SHA
    result = {'source': identity(), 'linux_original_case': linux['gate_passed'], 'agentd_build': built['gate_passed'], 'provider_test': smoke['gate_passed'], 'provider_observations': observations, 'gateway_config_unchanged': unchanged_gateway, 'test_owner_not_production_owner': True, 'model_capability_or_memory_benefit_claimed': False, 'whole_ci_pass_claimed': False, 'finished_at': now()}
    save('RESULT.json', result)
    print('MEM8_NATIVE_PROVIDER_RESULT ' + json.dumps(result), flush=True)
    if not smoke['gate_passed'] or not observations.get('verified') or not unchanged_gateway:
        raise RuntimeError('real-provider attempt did not qualify; reconcile this original identity and never replay automatically')


if __name__ == '__main__':
    try:
        main()
    except Exception:
        failure = traceback.format_exc()
        if RECORDS.exists():
            with (RECORDS / 'DRIVER_FAILURE.txt').open('x') as f:
                f.write(failure)
        print(failure, flush=True)
        raise
