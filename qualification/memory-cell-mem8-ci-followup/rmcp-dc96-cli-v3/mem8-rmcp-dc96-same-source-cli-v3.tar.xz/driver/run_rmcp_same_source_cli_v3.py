from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import traceback
import xml.etree.ElementTree as ET

TASK = Path('/home/qian-qi/mem8-rmcp-same-source-cli-ed353817-v3')
SOURCE = Path('/home/qian-qi/mem8-dependency-validation-ed353817-v2/source')
TARGET = Path('/home/qian-qi/mem8-dependency-validation-ed353817-v2/target')
RECORDS = TASK / 'records'
HEAD = 'dc96a441312e239c165c1642880084dfeccc2c71'
TREE = '7796279284170f0f2c92449c1185eecac1f4f1b6'
COMMON = '96038ccf0660154fac143ba6cbe4be81e00813e8'
CASES = [
    'streamable_http_discovery_timeout_unblocks_remote_executor',
    'streamable_http_handshake_timeout_unblocks_remote_executor',
    'streamable_http_remote_client_round_trips_through_exec_server',
]
ENV = {**os.environ, 'PATH': '/home/qian-qi/.cargo/bin:/home/qian-qi/.local/bin:' + os.environ.get('PATH', ''), 'RUSTUP_TOOLCHAIN': '1.96.0', 'CARGO_TARGET_DIR': str(TARGET), 'CARGO_BUILD_JOBS': '4', 'PYTHONDONTWRITEBYTECODE': '1', 'RUST_BACKTRACE': '1', 'TMPDIR': '/tmp'}


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def save(name, value):
    with (RECORDS / name).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True).strip()


def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'dirty': bool(git('status', '--porcelain=v1')), 'cargo_lock_sha256': sha(SOURCE / 'codex-rs/Cargo.lock'), 'bazel_lock_sha256': sha(SOURCE / 'MODULE.bazel.lock')}


def phase(name, command, extra=None, test=False):
    before = identity()
    assert before['commit'] == HEAD and before['tree'] == TREE and not before['dirty']
    junit = SOURCE / 'codex-rs/target/nextest/local/junit.xml'
    previous = (junit.stat().st_mtime_ns, sha(junit)) if junit.is_file() else None
    env = {**ENV, 'SOURCE_SHA': HEAD, 'TESTED_SHA': HEAD, 'BASE_SHA': COMMON, 'HEPTA_CI_LANE': 'source-head', **(extra or {})}
    output = RECORDS / (name + '.json')
    wrapper = [sys.executable, '-B', str(SOURCE / 'scripts/hepta_ci_exec.py'), '--output', str(output), '--minimum-tests', '3' if test else '0', '--timeout-seconds', '10800', '--', *command]
    print('MEM8_RMCP_SAME_SOURCE_PHASE_START ' + json.dumps({'name': name, 'source': before, 'command': command, 'started_at': now()}), flush=True)
    with (RECORDS / (name + '.wrapper.stdout.log')).open('xb') as out, (RECORDS / (name + '.wrapper.stderr.log')).open('xb') as err:
        result = subprocess.run(wrapper, cwd=SOURCE / 'codex-rs', env=env, stdout=out, stderr=err)
    receipt = json.loads(output.read_text())
    after = identity()
    raw = (RECORDS / receipt['log_file']).read_bytes()
    assert len(raw) == receipt['log_bytes'] and hashlib.sha256(raw).hexdigest() == receipt['log_sha256']
    text = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode())
    audit = {'before': before, 'after': after, 'command': command, 'exit_code': result.returncode, 'receipt_status': receipt['status'], 'observed_passed': receipt['observed_passed_tests'], 'observed_failed': receipt['observed_failed_tests'], 'log_sha256': receipt['log_sha256'], 'log_bytes': len(raw), 'summary_lines': re.findall(r'Summary[^\n]+', text)}
    current = (junit.stat().st_mtime_ns, sha(junit)) if junit.is_file() else None
    if test and current is not None and current != previous:
        jb = junit.read_bytes()
        (RECORDS / (name + '.junit.xml')).write_bytes(jb)
        doc = ET.fromstring(jb)
        cases = list(doc.iter('testcase'))
        ids = [(x.get('classname'), x.get('name')) for x in cases]
        failed = [x.get('name') for x in cases if x.find('failure') is not None or x.find('error') is not None]
        skipped = [x.get('name') for x in cases if x.find('skipped') is not None]
        assert len(ids) == len(set(ids)), 'duplicate JUnit IDs'
        audit['junit'] = {'sha256': hashlib.sha256(jb).hexdigest(), 'bytes': len(jb), 'run_id': doc.get('uuid'), 'ids': ids, 'failed': failed, 'skipped': skipped}
    passed = result.returncode == 0 and receipt['status'] == 'passed' and before == after
    if test:
        expected = sorted(('codex-rmcp-client::streamable_http_remote', name) for name in CASES)
        observed = audit.get('junit', {})
        passed = passed and sorted(observed.get('ids', [])) == expected and not observed.get('failed') and not observed.get('skipped') and audit['observed_passed'] == 3 and audit['observed_failed'] == 0
        if observed.get('run_id'):
            assert observed['run_id'] in text, 'JUnit run ID must appear in original nextest raw output'
    audit['gate_passed'] = bool(passed)
    save(name + '.audit.json', audit)
    print('MEM8_RMCP_SAME_SOURCE_PHASE_RESULT ' + json.dumps(audit), flush=True)
    assert before == after, 'source changed during execution'
    return audit


def main():
    TASK.mkdir(mode=0o700)
    RECORDS.mkdir(mode=0o700)
    (RECORDS / 'driver.py').write_bytes(Path(__file__).read_bytes())
    source = identity()
    assert source['commit'] == HEAD and source['tree'] == TREE and not source['dirty']
    materialized = []
    for relative in ['docs/modules/MODULES.json', 'qualification/neuron-v13-generation/proposal_worker.py']:
        expected = git('rev-parse', 'HEAD:' + relative)
        assert int(git('cat-file', '-s', 'HEAD:' + relative)) < 16 * 1024 * 1024
        subprocess.run(['git', '-C', str(SOURCE), 'checkout', '--ignore-skip-worktree-bits', 'HEAD', '--', relative], env=ENV, check=True, timeout=120)
        assert git('hash-object', relative) == expected
        materialized.append({'path': relative, 'blob': expected})
    assert identity() == source
    save('INPUT.json', {'source': source, 'sparse_source_files_materialized': materialized, 'original_result': {'unique_tests': 268, 'passed': 265, 'failed': 3, 'filtered_or_ignored': 7, 'junit_run_id': 'c6520272-0490-4d9f-bee4-5d08be7198bd', 'raw_sha256': '2824fd5baadd2559beed9097264bc129542c6a30f679bcc3d0714234129dd054'}, 'rerun_only': CASES, 'source_changed': False, 'assertions_changed': False, 'retries': 0, 'shared_target': str(TARGET), 'free_bytes_before': shutil.disk_usage(TARGET).free, 'cargo_lock_wait_is_allowed': True, 'started_at': now()})
    built = phase('same-source-codex-cli-build', ['cargo', 'build', '--locked', '-p', 'codex-cli', '--bin', 'codex'])
    assert built['gate_passed'], 'required same-source CLI did not build; do not run consumer tests'
    binary = TARGET / 'debug/codex'
    assert binary.is_file() and os.access(binary, os.X_OK)
    binary_identity = {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': sha(binary), 'source': identity(), 'build_receipt': 'same-source-codex-cli-build.json'}
    save('CLI_BINARY.json', binary_identity)
    expression = ' | '.join('test(=' + name + ')' for name in CASES)
    command = ['just', 'test', '--locked', '-p', 'codex-rmcp-client', '--test', 'streamable_http_remote', '-E', expression, '--test-threads', '1', '--no-tests', 'fail', '--retries', '0', '--success-output', 'immediate', '--failure-output', 'immediate']
    selected = phase('original-three-cases-with-same-source-cli', command, {'CARGO_BIN_EXE_codex': str(binary), 'NEXTEST_BIN_EXE_codex': str(binary)}, test=True)
    assert sha(binary) == binary_identity['sha256'], 'CLI binary changed during consumer test'
    result = {'source': identity(), 'build_passed': built['gate_passed'], 'three_original_cases_passed': selected['gate_passed'], 'new_matrix_source_consumers_claimed': False, 'whole_ci_pass_claimed': False, 'original_265_pass_3_fail_preserved': True, 'free_bytes_after': shutil.disk_usage(TARGET).free, 'finished_at': now()}
    save('RESULT.json', result)
    print('MEM8_RMCP_SAME_SOURCE_RESULT ' + json.dumps(result), flush=True)
    return 0 if selected['gate_passed'] else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception:
        failure = traceback.format_exc()
        if RECORDS.exists():
            with (RECORDS / 'DRIVER_FAILURE.txt').open('x') as f:
                f.write(failure)
        print(failure, flush=True)
        raise
