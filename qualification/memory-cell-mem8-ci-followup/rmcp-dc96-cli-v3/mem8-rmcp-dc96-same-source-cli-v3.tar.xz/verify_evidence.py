import hashlib
import json
import lzma
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
HEAD = 'dc96a441312e239c165c1642880084dfeccc2c71'
TREE = '7796279284170f0f2c92449c1185eecac1f4f1b6'


def read_json(name):
    return json.loads((ROOT / name).read_text())


def verify_run(receipt_name, raw_name, junit_name, passed, failed, filtered):
    receipt = read_json(receipt_name)
    raw = (ROOT / raw_name).read_bytes()
    assert len(raw) == receipt['log_bytes']
    assert hashlib.sha256(raw).hexdigest() == receipt['log_sha256']
    assert receipt['before'] == receipt['after']
    assert receipt['source_sha'] == receipt['tested_sha'] == HEAD
    assert receipt['before']['commit'] == HEAD and receipt['before']['tree'] == TREE
    assert receipt['before']['dirty'] is False
    assert receipt['timed_out'] is False and receipt['output_limit_exceeded'] is False
    assert receipt['observed_passed_tests'] == passed and receipt['observed_failed_tests'] == failed
    assert receipt['command'][receipt['command'].index('--retries') + 1] == '0'
    assert receipt['command'][receipt['command'].index('--no-tests') + 1] == 'fail'
    junit = ET.fromstring((ROOT / junit_name).read_bytes())
    cases = list(junit.iter('testcase'))
    ids = [(case.get('classname'), case.get('name')) for case in cases]
    assert len(ids) == len(set(ids)) == passed + failed
    assert all(case.find('skipped') is None for case in cases)
    failures = {(case.get('classname'), case.get('name')) for case in cases if case.find('failure') is not None or case.find('error') is not None}
    assert len(failures) == failed
    text = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode())
    assert 'Nextest run ID ' + junit.get('uuid') in text
    rows = re.findall(r'^\s*(PASS|FAIL)\s+\[[^]]+\]\s+(?:\([^)]*\)\s+)?(\S+)\s+(\S+)\s*$', text, re.M)
    actual_passed = {(a, b) for status, a, b in rows if status == 'PASS'}
    actual_failed = {(a, b) for status, a, b in rows if status == 'FAIL'}
    assert actual_failed == failures and actual_passed == set(ids) - failures
    summary = re.findall(r'Summary\s+\[[^]]+\]\s+(\d+) tests? run:\s+(\d+) passed(?:,\s+(\d+) failed)?,\s+(\d+) skipped', text)
    assert len(summary) == 1
    total, p, f, s = summary[0]
    assert (int(total), int(p), int(f or '0'), int(s)) == (passed + failed, passed, failed, filtered)
    assert receipt['status'] == ('failed' if failed else 'passed')
    assert receipt['exit_code'] == (100 if failed else 0)
    return {'run_id': junit.get('uuid'), 'unique_selected_tests': len(ids), 'passed': passed, 'failed': failed, 'selected_skipped': 0, 'filtered_or_ignored': filtered}, failures, set(ids)


def main():
    for row in read_json('FILE_MANIFEST.json')['files']:
        raw = (ROOT / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    original, original_failures, original_ids = verify_run('original/rmcp-consumers.receipt.canonical.json', 'original/rmcp-consumers.raw.log', 'original/rmcp-consumers.junit.xml', 265, 3, 7)
    selected, failures, selected_ids = verify_run('current/original-three-cases-with-same-source-cli.json', 'current/original-three-cases-with-same-source-cli.json.e4df10fc060448dfa4476aa7d16c37fd.log', 'current/original-three-cases-with-same-source-cli.junit.xml', 3, 0, 0)
    assert original_failures == selected_ids and not failures
    build = read_json('current/same-source-codex-cli-build.json')
    raw = (ROOT / 'current' / build['log_file']).read_bytes()
    assert len(raw) == build['log_bytes'] and hashlib.sha256(raw).hexdigest() == build['log_sha256']
    assert build['status'] == 'passed' and build['command_exit_code'] == 0
    assert build['before'] == build['after'] and build['before']['commit'] == HEAD and build['before']['tree'] == TREE and build['before']['dirty'] is False
    binary = read_json('current/CLI_BINARY.json')
    assert binary['source']['commit'] == HEAD and binary['source']['tree'] == TREE and binary['source']['dirty'] is False
    assert binary['sha256'] == '67e70ed6924951714423b3b2760531a7416f9489f3850e2830ff0da938f5f7d9'
    assert binary['bytes'] == 1440710248
    capsule_raw = (ROOT / 'source/candidate64-v2.json.xz').read_bytes()
    assert hashlib.sha256(capsule_raw).hexdigest() == '2c0b8be4689e9049239d5aae865e3fd6aea295c64a48bf5a414b6bda2b363fc7'
    capsule = json.loads(lzma.decompress(capsule_raw))
    assert len(capsule['files']) == 64
    assert capsule['common_head'] == '96038ccf0660154fac143ba6cbe4be81e00813e8'
    for row in capsule['files']:
        raw = row['content'].encode()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['git_blob']
    result = read_json('current/RESULT.json')
    assert result['three_original_cases_passed'] is True and result['whole_ci_pass_claimed'] is False
    assert result['source']['commit'] == HEAD and result['source']['tree'] == TREE
    driver = (ROOT / 'driver/run_rmcp_same_source_cli_v3.py').read_bytes()
    assert hashlib.sha256(driver).hexdigest() == 'b786978728189e4c26502db6ac9260350540aeb18bf2c03f72f8c4e2e4966f6f'
    assert b"assert sha(binary) == binary_identity['sha256']" in driver
    print(json.dumps({'validation': 'passed', 'source_commit': HEAD, 'source_tree': TREE, 'original': original, 'same_source_cli_rerun': selected, 'rerun_ids_equal_original_failed_ids': True, 'source_capsule_verified_files': 64, 'fresh_f1fd_consumer_validation_claimed': False, 'single_268_pass_run_claimed': False, 'whole_ci_pass_claimed': False}, indent=2))


if __name__ == '__main__':
    main()
