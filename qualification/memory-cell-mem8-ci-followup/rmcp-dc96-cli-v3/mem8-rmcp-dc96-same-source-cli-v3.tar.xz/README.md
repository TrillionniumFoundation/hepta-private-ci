# Same-source RMCP CLI qualification at dc96

The original run selected 268 unique tests: 265 PASS, 3 FAIL, zero selected skips; seven additional tests were filtered/ignored. Its complete command output and JUnit remain unchanged. The three original failures were then rerun with a real codex CLI built from the exact same dc96 source: 3 PASS, 0 FAIL, zero skips, zero retries. This is not a single 268-PASS run.

Source: dc96a441312e239c165c1642880084dfeccc2c71; tree7796279284170f0f2c92449c1185eecac1f4f1b6. All native phases record before/after clean identities. The included 64-file capsule preserves exact postimages against common96038. The source and assertions were not changed for the rerun. Both CARGO_BIN_EXE_codex and NEXTEST_BIN_EXE_codex named the same built binary; the driver hashes that binary before the tests and asserts the same hash after the tests before writing RESULT.json.

The CLI executable itself is not copied into this evidence package. Its 1,440,710,248-byte identity and SHA256 are recorded. The full build log and full combined stdout/stderr of both test invocations are included. The original receipt is a canonical JSON rendering of the complete native readback; original command-log bytes and original JUnit bytes are preserved. Current receipts are full-file native readbacks.

The h_view line renderings of the two new command logs are included. Removing only the verified sequential line-id prefixes and restoring final newlines produced bytes whose length and SHA256 exactly equal their native receipts; no log text was dropped or changed. The terminal PTY readback is the final page, not a claim that this package contains every earlier PTY polling page.

Run python3 verify_evidence.py to verify all packaged file hashes, both command-log/JUnit/run UUID bindings, unique IDs, filtered-versus-selected skips, original failures equaling the rerun cases, exact source identities, and all64 capsule postimages. The verifier does not run native code or a model.

No whole-CI pass, new f1fd consumer pass, scientific adoption, production owner recovery, or memory benefit is claimed. A separate complete 268-case run at published f1fd is required for that newer candidate's exact-head consumer qualification.
