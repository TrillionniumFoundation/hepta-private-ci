"""Freeze cumulative repairs over 2ae, extending the published 69-path tree."""
import ast
import base64
import hashlib
import json
import lzma
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
PRIOR = ROOT / 'mem8-repair-source-v2/root-readback/records'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def listing(data):
    entries = {}
    for record in data.split(b'\0'):
        if record:
            meta, path = record.split(b'\t', 1)
            mode, kind, digest = meta.decode().split()
            name = path.decode()
            assert name not in entries
            entries[name] = {'mode': mode, 'type': kind, 'git_blob': digest}
    return entries

config = json.loads((PRIOR / 'INPUT.json').read_text())
capsule_bytes = (PRIOR / 'FORMATTED_CAPSULE.json').read_bytes()
assert sha(capsule_bytes) == '6081a45344f3fa7687b71901033b813499d5dc3913c052e63a6700a9c96b6a37'
capsule = json.loads(capsule_bytes)
assert capsule['candidate_tree'] == 'e253b99e0a5c3b3a680569da0d224fabff0781ba'
base = listing((PRIOR / 'BASE_TREE.ls-tree').read_bytes())
current = listing((PRIOR / 'CANDIDATE_TREE.ls-tree').read_bytes())
rows = {row['path']: row for row in config['files']}
assert len(rows) == len(capsule['files']) == 69
for row in capsule['files']:
    data = (PRIOR / 'post-format' / row['path']).read_bytes()
    assert (len(data), sha(data), blob(data)) == (row['postimage_bytes'], row['postimage_sha256'], row['postimage_git_blob'])
    rows[row['path']].update(content=data.decode(), bytes=len(data), sha256=sha(data), input_git_blob=blob(data))

review_inputs = []
incremental_paths = set()

def add(path, data, expected_pre, expected_post, group):
    observed_pre = current.get(path, {}).get('git_blob')
    assert observed_pre == expected_pre, (path, observed_pre, expected_pre)
    assert blob(data) == expected_post
    assert path not in incremental_paths
    incremental_paths.add(path)
    if path in rows:
        assert rows[path]['input_git_blob'] == expected_pre
    else:
        rows[path] = {'path': path, 'mode': base.get(path, {}).get('mode', '100644'),
                      'preimage_git_blob': base.get(path, {}).get('git_blob')}
    assert rows[path]['mode'] == '100644'
    rows[path].update(group=group, content=data.decode(), bytes=len(data), sha256=sha(data), input_git_blob=blob(data))

clock_dir = ROOT / 'mem-mac-intel-expiry-clock-candidate'
clock_bytes = (clock_dir / 'CANDIDATE_MANIFEST.json').read_bytes()
assert sha(clock_bytes) == '58e47ce484afaba2b0336a8f3eb192956037afe85f943e8a16b5bcbf92878dd7'
clock = json.loads(clock_bytes)
assert clock['base_tree'] == capsule['candidate_tree']
for row in clock['files']:
    data = (clock_dir / 'source' / row['path']).read_bytes()
    assert (len(data), sha(data)) == (row['bytes'], row['sha256'])
    add(row['path'], data, row['preimage_git_blob'], row['postimage_git_blob'], 'fresh-owner-qualification-lease-clock')
review_inputs.append({'path': str(clock_dir.relative_to(ROOT) / 'CANDIDATE_MANIFEST.json'),
                      'sha256': sha(clock_bytes), 'git_blob': blob(clock_bytes), 'files': len(clock['files'])})

startup_dir = ROOT / 'mem-code-mode-startup-diagnostic-2ae'
startup_bytes = (startup_dir / 'CANDIDATE_MANIFEST.json').read_bytes()
startup = json.loads(startup_bytes)
assert startup['base'] == config['base_sha']
for row in startup['files']:
    data = (startup_dir / 'source' / row['path']).read_bytes()
    assert (len(data), sha(data)) == (row['postimage_bytes'], row['postimage_sha256'])
    add(row['path'], data, row['preimage_git_blob'], row['postimage_git_blob'], 'startup-failure-observation-only')
review_inputs.append({'path': str(startup_dir.relative_to(ROOT) / 'CANDIDATE_MANIFEST.json'),
                      'sha256': sha(startup_bytes), 'git_blob': blob(startup_bytes), 'files': len(startup['files'])})

matrix_dir = ROOT / 'mem-matrix-failure-2ae'
matrix_bytes = (matrix_dir / 'CANDIDATE_MANIFEST.json').read_bytes()
matrix = json.loads(matrix_bytes)
assert matrix['base_commit'] == config['base_sha']
add(matrix['path'], (matrix_dir / 'source' / matrix['path']).read_bytes(),
    matrix['preimage_git_blob'], matrix['postimage_git_blob'], 'matrix-fixture-error-context-only')
review_inputs.append({'path': str(matrix_dir.relative_to(ROOT) / 'CANDIDATE_MANIFEST.json'),
                      'sha256': sha(matrix_bytes), 'git_blob': blob(matrix_bytes), 'files': 1})

model_dir = ROOT / 'mem-model-list-wire-cache-repair-189711'
model_bytes = (model_dir / 'SOURCE_CAPSULE.json').read_bytes()
assert sha(model_bytes) == '25c4e20e6ae7d71b4fd12481f7665aee9ffbbbddd2e666c73943ec5b735a473e'
model = json.loads(model_bytes)
assert model['base_commit'] == '189711e3563ea13a5328d52e99a286f082045b98'
assert model['base_tree'] == capsule['candidate_tree']
assert len(model['files']) == 1
for row in model['files']:
    assert row['path'] == 'codex-rs/app-server/tests/suite/v2/model_list.rs'
    assert row['preimage_git_blob'] == 'bcfad8884054e1eebb9abc27b9fbfc8f0f6a8578'
    assert row['postimage_git_blob'] == '0295b921099f63f245953eafd9b377db435184a9'
    data = base64.b64decode(row['content_base64'], validate=True)
    assert (len(data), sha(data)) == (row['postimage_bytes'], row['postimage_sha256'])
    add(row['path'], data, row['preimage_git_blob'], row['postimage_git_blob'],
        'model-list-wire-cache-equality-repair')
review_inputs.append({'path': str(model_dir.relative_to(ROOT) / 'SOURCE_CAPSULE.json'),
                      'sha256': sha(model_bytes), 'git_blob': blob(model_bytes), 'files': 1})

infer_dir = ROOT / 'mem-infer-physical-observation-repair-189711'
infer_bytes = (infer_dir / 'SOURCE_CAPSULE.json').read_bytes()
infer = json.loads(infer_bytes)
assert infer['base_commit'] == '189711e3563ea13a5328d52e99a286f082045b98'
assert infer['base_tree'] == capsule['candidate_tree']
assert len(infer['files']) == 1
for row in infer['files']:
    assert row['postimage_git_blob'] == '83430468bd935407208061f07b382015836f26a4'
    data = (infer_dir / 'source' / row['path']).read_bytes()
    assert (len(data), sha(data)) == (row['postimage_bytes'], row['postimage_sha256'])
    add(row['path'], data, row['preimage_git_blob'], row['postimage_git_blob'],
        'fresh-write-capable-negative-control-fixture')
review_inputs.append({'path': str(infer_dir.relative_to(ROOT) / 'SOURCE_CAPSULE.json'),
                      'sha256': sha(infer_bytes), 'git_blob': blob(infer_bytes), 'files': 1})

remote_dir = ROOT / 'mem-remote-control-review-189711'
remote_bytes = (remote_dir / 'CANDIDATE_MANIFEST.json').read_bytes()
remote = json.loads(remote_bytes)
assert remote['base_commit'] == '189711e3563ea13a5328d52e99a286f082045b98'
assert remote['base_tree'] == capsule['candidate_tree']
assert len(remote['files']) == 1
for row in remote['files']:
    assert row['post_blob'] == '9f0a732a49b14c1533c69ffae42d89bf5e4665e1'
    data = (remote_dir / 'candidate' / row['path']).read_bytes()
    assert (len(data), sha(data)) == (row['post_bytes'], row['post_sha256'])
    add(row['path'], data, row['pre_blob'], row['post_blob'],
        'remote-fixture-route-models-before-websocket')
review_inputs.append({'path': str(remote_dir.relative_to(ROOT) / 'CANDIDATE_MANIFEST.json'),
                      'sha256': sha(remote_bytes), 'git_blob': blob(remote_bytes), 'files': 1})

neuron_dir = ROOT / 'mem-neuron-rpc-progress-189711'
neuron_bytes = (neuron_dir / 'CANDIDATE_MANIFEST.json').read_bytes()
neuron = json.loads(neuron_bytes)
assert neuron['base_commit'] == '189711e3563ea13a5328d52e99a286f082045b98'
assert neuron['base_tree'] == capsule['candidate_tree']
assert len(neuron['files']) == 2
for row in neuron['files']:
    data = (neuron_dir / 'source' / row['path']).read_bytes()
    assert (len(data), sha(data)) == (row['postimage_bytes'], row['postimage_sha256'])
    add(row['path'], data, row['preimage_git_blob'], row['postimage_git_blob'],
        'unit-test-rpc-progress-diagnostic-only')
review_inputs.append({'path': str(neuron_dir.relative_to(ROOT) / 'CANDIDATE_MANIFEST.json'),
                      'sha256': sha(neuron_bytes), 'git_blob': blob(neuron_bytes), 'files': 2})

assert len(rows) == 92
assert len(incremental_paths) == 31
config['files'] = [rows[path] for path in sorted(rows)]
config['prior_formatted_tree'] = capsule['candidate_tree']
config['published_parent_commit'] = '189711e3563ea13a5328d52e99a286f082045b98'
config['source_gate_run_version'] = 3
config['incremental_paths_since_published_parent'] = sorted(incremental_paths)
config['review_input_manifests'] = review_inputs
config['unresolved'] = [
    'Native qualification on this source has not run',
    'Mac zsh original child input and failure mechanism remain unknown',
    'Startup and storage additions are diagnostics, not established repairs',
    'Reopened neuron RPC timeout remains unresolved; unit-test progress adds observations only',
    'Original provider terminal, owner binding, source exposure and scientific gates remain open',
]
assert config['ready_to_execute'] is True
assert config['execution_scope'] == 'source-only-format-caller-and-full-tree-scan'
raw = (json.dumps(config, indent=2, sort_keys=True) + '\n').encode()
compressed = lzma.compress(raw, preset=6)
(OUT / 'INPUT_SOURCE_GATES.json.xz').write_bytes(compressed)

driver = (ROOT / 'mem8-repair-source-v2/run_source_gates.py').read_text()
changes = {
    '/home/qq/mem8-integrated-repair-source-ed353817-v2': '/home/qq/mem8-integrated-repair-source-ed353817-v3',
    'KEY = "mem8-integrated-repair-source-ai395-ed353817-v2"': 'KEY = "mem8-integrated-repair-source-ai395-ed353817-v3"',
    'or len(rows) != 69:': f'or len(rows) != {len(rows)}:',
}
for before, after in changes.items():
    assert driver.count(before) == 1, before
    driver = driver.replace(before, after)
ast.parse(driver)
(OUT / 'run_source_gates.py').write_text(driver)
index = {key: value for key, value in config.items() if key != 'files'}
index['files'] = [{key: value for key, value in row.items() if key != 'content'} for row in config['files']]
index['input_compressed'] = {'bytes': len(compressed), 'sha256': sha(compressed)}
index['input_plain'] = {'bytes': len(raw), 'sha256': sha(raw)}
index['driver'] = {'bytes': len(driver.encode()), 'sha256': sha(driver.encode())}
index['execution_not_admitted_by_assembly'] = True
(OUT / 'SOURCE_GATE_INDEX.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'paths': len(rows), 'incremental_paths': len(incremental_paths),
                  'new_paths_since_2ae': sum(row['preimage_git_blob'] is None for row in rows.values()),
                  'input': index['input_compressed'], 'plain': index['input_plain'], 'driver': index['driver']}, indent=2))
