"""Bounded source-only qualification of an immutable reviewed repair capsule.

Creates its own checkout, formats it with the repository's recipe, scans the
whole tracked tree, and runs the caller verifier. No Rust test/build, model,
published ref, donor source, or original qualification receipt is changed.
"""
import base64
from datetime import datetime, timedelta, timezone
import hashlib
import io
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import subprocess
import sys
import tarfile
import time
import traceback

BASE = "2ae5215beaf8d7b7df111a090b82134beae2683d"
BASE_TREE = "12159640adcf073b51f3837e75575e11f5c20233"
RUN = Path("/home/qq/mem8-integrated-repair-source-ed353817-v3")
SOURCE = RUN / "source"
RECORDS = RUN / "records"
DONOR = Path("/home/qq/mem8-integrated-sem-caller-ed353817-v1/source")
KEY = "mem8-integrated-repair-source-ai395-ed353817-v3"
TOOLS = Path("/home/qq/mem8-owner-20261111-ed353817/native-6be-20261111/tools/bin")
DOTSLASH = Path("/home/qq/mem8-owner-20261111-ed353817/dotslash-bootstrap-20261111/installation-v2/bin/dotslash")
DOTSLASH_SHA256 = "54a03b42f0337eba584bc33563237d45aeca11a34de2e7159f76d7695fe5b936"
LOCKS = {
    "codex-rs/Cargo.lock": "98b3767c6e74bf6eeb5894db760259dbc400cbfd0685af8ad915c92d25408d69",
    "MODULE.bazel.lock": "783b3ad329fa53bd4a0e48be6907d38259fa2880d61bd1994b863d7f78bbca57",
}
START = datetime.now(timezone.utc)
DEADLINE = time.monotonic() + 600
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", GIT_OPTIONAL_LOCKS="0",
           GIT_TERMINAL_PROMPT="0", RUSTUP_TOOLCHAIN="1.96.0")
for key in list(ENV):
    if key.startswith(("GIT_TRACE", "HEPTA_LOCAL_PROVIDER_", "HEPTA_MEM_CONTEXT_", "HEPTA_MEM_NATIVE_")) or key in {
        "GIT_CURL_VERBOSE", "CARGO_BIN_EXE_codex", "HEPTA_EPISODIC_DRAIN_REGRESSION_CASE"
    }:
        ENV.pop(key)
ENV["PATH"] = f"{TOOLS}:{DOTSLASH.parent}:/home/qq/.cargo/bin:" + ENV.get("PATH", "")


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def info(data):
    return {"bytes": len(data), "sha256": digest(data), "git_blob": blob(data)}


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def save(name, value):
    write(RECORDS / name, (json.dumps(value, indent=2, sort_keys=True) + "\n").encode())


def git(root, *args):
    remaining = min(30, DEADLINE - time.monotonic() - 2)
    if remaining <= 0:
        raise TimeoutError("source-only deadline exhausted before git read")
    return subprocess.check_output(["git", "--no-replace-objects", *args], cwd=root,
                                   env=ENV, timeout=remaining)


def identity(root):
    return {
        "head": git(root, "rev-parse", "HEAD").decode().strip(),
        "tree": git(root, "rev-parse", "HEAD^{tree}").decode().strip(),
        "status": git(root, "status", "--porcelain=v1", "--untracked-files=all").decode(),
    }


def command(label, argv, *, cwd=SOURCE, allowed=(0,)):
    remaining = DEADLINE - time.monotonic() - 3
    if remaining <= 0:
        raise TimeoutError("source-only deadline exhausted before " + label)
    started = now()
    raw_path = RECORDS / (label + ".raw.log")
    timed_out = False
    cleanup = None
    with raw_path.open("xb") as stream:
        child = subprocess.Popen(argv, cwd=cwd, env=ENV, stdout=stream,
                                 stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = child.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            code = child.wait(timeout=max(0.1, min(2, DEADLINE - time.monotonic())))
            cleanup = {"owned_process_group": child.pid, "signal": "SIGKILL", "reaped_exit_code": code}
        stream.flush()
        os.fsync(stream.fileno())
    data = raw_path.read_bytes()
    receipt = {"command": argv, "cwd": str(cwd), "started_at": started,
               "finished_at": now(), "exit_code": code, "timed_out": timed_out,
               "cleanup": cleanup, "raw_file": raw_path.name, **info(data)}
    save(label + ".json", receipt)
    print(json.dumps({"phase": label, **receipt}), flush=True)
    if timed_out or code not in allowed:
        raise RuntimeError(label + " failed; original receipt and output retained")
    return data


def pins(label, rows):
    result = []
    for row in rows:
        path = SOURCE / row["path"]
        if not path.is_file() or path.is_symlink():
            raise RuntimeError("missing or unsafe source path: " + row["path"])
        data = path.read_bytes()
        mode = "100755" if path.stat().st_mode & 0o111 else "100644"
        if mode != row["mode"]:
            raise RuntimeError("source mode changed: " + row["path"])
        write(RECORDS / label / row["path"], data)
        result.append({"path": row["path"], "mode": mode, "group": row["group"],
                       "preimage_git_blob": row["preimage_git_blob"], **info(data)})
    save(label + "-FILES.json", result)
    return result


def lock_pins():
    result = []
    for path, expected in LOCKS.items():
        data = (SOURCE / path).read_bytes()
        if digest(data) != expected:
            raise RuntimeError("unexpected source-only lock drift: " + path)
        result.append({"path": path, **info(data)})
    return result


def donor_files(paths):
    return [{"path": path, **info((DONOR / path).read_bytes())} for path in paths]


def tree_entries(data):
    entries = {}
    for item in data.split(b"\0"):
        if not item:
            continue
        meta, path = item.split(b"\t", 1)
        mode, kind, object_id = meta.decode().split()
        name = path.decode("utf-8")
        if name in entries:
            raise RuntimeError("duplicate complete-tree path")
        entries[name] = {"mode": mode, "type": kind, "git_blob": object_id}
    return entries


def archive():
    rows = []
    for path in sorted(RECORDS.rglob("*")):
        if path.is_symlink():
            raise RuntimeError("symlink in source-only records")
        if path.is_file():
            rows.append({"path": path.relative_to(RECORDS).as_posix(), **info(path.read_bytes())})
    save("FILE_MANIFEST.json", {"schema": "hepta.mem8.repair-source.records.v1", "members": rows})
    output = RUN / "mem8-repair-source-records.tar.xz"
    with output.open("xb") as stream:
        with tarfile.open(fileobj=stream, mode="w:xz", preset=6) as tar:
            for path in sorted(RECORDS.rglob("*")):
                if not path.is_file():
                    continue
                data = path.read_bytes()
                member = tarfile.TarInfo(path.relative_to(RECORDS).as_posix())
                member.size, member.mode, member.mtime = len(data), 0o600, 0
                tar.addfile(member, io.BytesIO(data))
        stream.flush()
        os.fsync(stream.fileno())
    result = {"path": str(output), "members": len(rows) + 1, **info(output.read_bytes())}
    write(RUN / "ARCHIVE_INFO.json", (json.dumps(result, indent=2) + "\n").encode())
    print(json.dumps({"archive": result}), flush=True)


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: run_source_gates.py INPUT.json.xz EXPECTED_COMPRESSED_SHA256")
    encoded = Path(sys.argv[1]).read_bytes()
    if digest(encoded) != sys.argv[2]:
        raise RuntimeError("compressed input digest mismatch")
    config_bytes = lzma.decompress(encoded)
    config = json.loads(config_bytes)
    if config.get("ready_to_execute") is not True or config.get("execution_scope") != "source-only-format-caller-and-full-tree-scan":
        raise RuntimeError("input not frozen for this source-only gate")
    if (config["base_sha"], config["base_tree"]) != (BASE, BASE_TREE):
        raise RuntimeError("unexpected source base")
    rows = config["files"]
    expected = {row["path"] for row in rows}
    if len(expected) != len(rows) or len(rows) != 92:
        raise RuntimeError("unexpected reviewed input path inventory")
    RUN.mkdir(mode=0o700)
    RECORDS.mkdir(mode=0o700)
    write(RECORDS / "DRIVER.py", Path(__file__).read_bytes())
    write(RECORDS / "INPUT.json.xz", encoded)
    write(RECORDS / "INPUT.json", config_bytes)
    status, failure, completed = "failed", None, []
    donor_before = donor_after = donor_bytes_before = donor_bytes_after = None
    source_before = source_after = postimages = candidate_tree = None
    try:
        donor_before = identity(DONOR)
        if (donor_before["head"], donor_before["tree"]) != (BASE, BASE_TREE):
            raise RuntimeError("donor identity changed")
        dirty_paths = sorted(git(DONOR, "diff", "--name-only", "HEAD").decode().splitlines())
        donor_expected = sorted(row["path"] for row in rows if row["group"] in {
            "memory-admission-and-caller", "qualification-profile-coverage"})
        if dirty_paths != donor_expected or git(DONOR, "ls-files", "--others", "--exclude-standard"):
            raise RuntimeError("donor dirty-source inventory differs from the reviewed preflight")
        donor_bytes_before = donor_files(dirty_paths)
        by_path = {row["path"]: row for row in rows}
        for row in donor_bytes_before:
            if row["git_blob"] != by_path[row["path"]]["input_git_blob"]:
                raise RuntimeError("donor modified source bytes changed: " + row["path"])
        dotslash_before = info(DOTSLASH.read_bytes())
        if dotslash_before["bytes"] != 1642752 or dotslash_before["sha256"] != DOTSLASH_SHA256:
            raise RuntimeError("existing DotSlash bytes differ from the qualified tool")
        save("DOTSLASH_TOOL.json", {"path": str(DOTSLASH), **dotslash_before})
        save("START.json", {"run_id": KEY, "started_at": START.isoformat(),
             "deadline_utc": (START + timedelta(seconds=600)).isoformat(),
             "donor_before": donor_before, "donor_modified_source": donor_bytes_before,
             "input_compressed": info(encoded), "disk_free": shutil.disk_usage(RUN).free,
             "native_tests_executed": 0, "model_requests_executed": 0})
        command("clone", ["git", "clone", "--shared", "--no-checkout", str(DONOR), str(SOURCE)], cwd=RUN)
        command("checkout", ["git", "checkout", "--detach", BASE])
        source_before = identity(SOURCE)
        if source_before != {"head": BASE, "tree": BASE_TREE, "status": ""}:
            raise RuntimeError("new checkout is not exact clean base")
        if blob((SOURCE / "AGENTS.md").read_bytes()) != "faa57cc0db48123e1011f1eb47692cd3bbbcfc3a":
            raise RuntimeError("repository instructions changed")
        write(RECORDS / "AGENTS.md", (SOURCE / "AGENTS.md").read_bytes())
        write(RECORDS / "BASE_TREE.ls-tree", git(SOURCE, "ls-tree", "-r", "-z", "HEAD"))
        locks_before = lock_pins()
        save("SOURCE_BEFORE.json", {"identity": source_before, "locks": locks_before})
        tracked = set(git(SOURCE, "ls-files", "-z").decode().rstrip("\0").split("\0"))
        new_paths = []
        for row in rows:
            pure = PurePosixPath(row["path"])
            if pure.is_absolute() or ".." in pure.parts or ".git" in pure.parts:
                raise RuntimeError("unsafe capsule path")
            path = SOURCE / row["path"]
            if not path.resolve().is_relative_to(SOURCE.resolve()) or path.is_symlink():
                raise RuntimeError("capsule destination escapes source")
            if row["mode"] != "100644":
                raise RuntimeError("unexpected reviewed file mode")
            if row["preimage_git_blob"] is None:
                if row["path"] in tracked or path.exists():
                    raise RuntimeError("new source already exists")
                new_paths.append(row["path"])
            else:
                data = path.read_bytes()
                if blob(data) != row["preimage_git_blob"]:
                    raise RuntimeError("base preimage mismatch: " + row["path"])
                write(RECORDS / "base" / row["path"], data)
            data = row["content"].encode("utf-8")
            if info(data) != {"bytes": row["bytes"], "sha256": row["sha256"], "git_blob": row["input_git_blob"]}:
                raise RuntimeError("input postimage mismatch: " + row["path"])
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            path.chmod(0o644)
        if new_paths:
            command("intent-add-new-paths", ["git", "add", "--intent-to-add", "--", *sorted(new_paths)])
        if set(git(SOURCE, "diff", "--name-only", "HEAD").decode().splitlines()) != expected:
            raise RuntimeError("pre-format changed paths differ from reviewed input")
        before_format = pins("pre-format", rows)
        write(RECORDS / "candidate-before-format.patch", git(SOURCE, "diff", "--binary", "HEAD"))
        just = command("just-version", ["just", "--version"])
        rustfmt = command("rustfmt-version", ["rustfmt", "--version"], cwd=SOURCE / "codex-rs")
        if just.strip() != b"just 1.51.0" or rustfmt.strip() != b"rustfmt 1.9.0-stable (ac68faa20c 2026-05-25)":
            raise RuntimeError("source formatter version differs from the pinned tools")
        command("format", ["just", "fmt", "--base", "HEAD"])
        completed.append("format")
        postimages = pins("post-format", rows)
        if set(git(SOURCE, "diff", "--name-only", "HEAD").decode().splitlines()) != expected:
            raise RuntimeError("formatter changed unexpected source paths")
        if git(SOURCE, "ls-files", "--others", "--exclude-standard") or lock_pins() != locks_before:
            raise RuntimeError("formatter left unexpected files or lock drift")
        save("FORMAT_RESULT.json", {"status": "passed", "before": before_format, "after": postimages,
             "formatter_changed_paths": [a["path"] for a, b in zip(before_format, postimages) if a != b],
             "yaml_note": "Repository just fmt has no YAML formatter; reviewed bytes stay pinned."})
        command("diff-check", ["git", "diff", "--check", "HEAD"])
        write(RECORDS / "candidate-after-format.patch", git(SOURCE, "diff", "--binary", "HEAD"))
        rename_args = ["git", "grep", "-n", "-I", "-w", "-F"]
        for old in sorted(config["case_renames"]):
            rename_args.extend(["-e", old])
        rename_raw = command("full-tree-old-case-name-scan", [*rename_args, "--"], allowed=(0, 1))
        matches = []
        for line in rename_raw.decode("utf-8", errors="replace").splitlines():
            path, line_number, text = line.split(":", 2)
            matches.append({"path": path, "line": int(line_number), "text": text,
                            "historical_qualification_path": path.startswith("qualification/")})
        save("FULL_TREE_RENAME_SCAN.json", {"scope": "all tracked text files, whole-word fixed strings, no path exclusion",
             "renames": config["case_renames"], "matches": matches,
             "review_required": bool(matches), "historical_sources_must_not_be_rewritten": True})
        completed.append("full-tree-rename-scan")
        command("caller-self-test", [sys.executable, "-B", "scripts/verify_hepta_callers.py", "self-test"])
        completed.append("caller-self-test")
        command("caller-verify", [sys.executable, "-B", "scripts/verify_hepta_callers.py", "verify"])
        completed.append("caller-verify")
        for row in postimages:
            if info((SOURCE / row["path"]).read_bytes()) != {key: row[key] for key in ("bytes", "sha256", "git_blob")}:
                raise RuntimeError("source changed during caller verification")
        if lock_pins() != locks_before:
            raise RuntimeError("locks changed during caller verification")
        command("stage-formatted-candidate", ["git", "add", "--", *sorted(expected)])
        if git(SOURCE, "diff", "--name-only") or git(SOURCE, "ls-files", "--others", "--exclude-standard"):
            raise RuntimeError("unreviewed unstaged or untracked source remains")
        final_identity = identity(SOURCE)
        if (final_identity["head"], final_identity["tree"]) != (BASE, BASE_TREE):
            raise RuntimeError("source HEAD moved during source-only qualification")
        if set(git(SOURCE, "diff", "--cached", "--name-only", "HEAD").decode().splitlines()) != expected:
            raise RuntimeError("staged source delta exceeds reviewed input paths")
        for row in postimages:
            path = SOURCE / row["path"]
            mode = "100755" if path.stat().st_mode & 0o111 else "100644"
            if path.is_symlink() or mode != row["mode"] or info(path.read_bytes()) != {
                key: row[key] for key in ("bytes", "sha256", "git_blob")
            }:
                raise RuntimeError("final source mode or bytes differ from formatted postimage")
        candidate_tree = git(SOURCE, "write-tree").decode().strip()
        candidate_listing = git(SOURCE, "ls-tree", "-r", "-z", candidate_tree)
        write(RECORDS / "CANDIDATE_TREE.ls-tree", candidate_listing)
        expected_tree = tree_entries((RECORDS / "BASE_TREE.ls-tree").read_bytes())
        for row in postimages:
            expected_tree[row["path"]] = {"mode": row["mode"], "type": "blob", "git_blob": row["git_blob"]}
        if tree_entries(candidate_listing) != expected_tree:
            raise RuntimeError("complete candidate tree differs from exact base plus reviewed formatted overlay")
        save("COMPLETE_TREE_OVERLAY.json", {"base_tree": BASE_TREE, "candidate_tree": candidate_tree,
             "base_plus_overlay_matches_all_candidate_entries": True,
             "complete_candidate_entry_count": len(expected_tree), "overlay_paths": len(postimages)})
        capsule = {"base_commit": BASE, "base_tree": BASE_TREE, "candidate_tree": candidate_tree,
                   "native_tests_executed": 0, "model_requests": 0, "source_refs_modified": False,
                   "unresolved": config["unresolved"], "files": []}
        for row in postimages:
            data = (SOURCE / row["path"]).read_bytes()
            capsule["files"].append({"path": row["path"], "mode": row["mode"],
                "preimage_git_blob": row["preimage_git_blob"], "postimage_git_blob": row["git_blob"],
                "postimage_bytes": row["bytes"], "postimage_sha256": row["sha256"],
                "content_base64": base64.b64encode(data).decode("ascii")})
        save("FORMATTED_CAPSULE.json", capsule)
        donor_after = identity(DONOR)
        donor_bytes_after = donor_files(dirty_paths)
        if donor_after != donor_before or donor_bytes_after != donor_bytes_before:
            raise RuntimeError("donor source changed during source-only gate")
        if info(DOTSLASH.read_bytes()) != dotslash_before:
            raise RuntimeError("DotSlash tool changed during source-only gate")
        source_after = identity(SOURCE)
        status = "passed_source_gates_only_review_remaining"
    except Exception:
        failure = traceback.format_exc()
        write(RECORDS / "DRIVER_FAILURE.txt", failure.encode())
    finally:
        result = {"status": status, "failure": failure, "run_id": KEY,
             "base_sha": BASE, "base_tree": BASE_TREE, "source_before": source_before,
             "source_after": source_after, "candidate_tree": candidate_tree,
             "donor_before": donor_before, "donor_after": donor_after,
             "donor_source_before": donor_bytes_before, "donor_source_after": donor_bytes_after,
             "completed": completed, "started_at": START.isoformat(), "finished_at": now(),
             "deadline_utc": (START + timedelta(seconds=600)).isoformat(),
             "native_tests_executed": 0, "model_requests_executed": 0,
             "source_candidate_committed": False, "source_refs_modified": False,
             "unresolved": config["unresolved"]}
        save("RESULT.json", result)
        print(json.dumps({k: v for k, v in result.items() if k not in {"donor_source_before", "donor_source_after"}}), flush=True)
        archive()
    return 0 if status == "passed_source_gates_only_review_remaining" else 1


if __name__ == "__main__":
    sys.exit(main())
