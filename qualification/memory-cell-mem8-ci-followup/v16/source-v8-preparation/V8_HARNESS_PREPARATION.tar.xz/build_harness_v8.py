"""Prepare V8 from the successful V7 bytes; never admit or execute a gate."""

import argparse
import ast
import difflib
import hashlib
import json
import lzma
from pathlib import Path, PurePosixPath
import re
import subprocess
import tomllib

import yaml


HERE = Path(__file__).resolve().parent
V7_HEAD = "63a4c2492848e9560750c32bebaacce2762bf2a2"
V7_TREE = "7592d3546c460ba1a2f543167be27eeba973c2b7"
PARENT_HEAD = "c7c02cb425646adc6c85c763672cc6fa37e9c53d"
PARENT_TREE = "31fd2be8145d593bf8e470fa598597ab9b23e117"
BASE_HEAD = "2ae5215beaf8d7b7df111a090b82134beae2683d"
BASE_TREE = "12159640adcf073b51f3837e75575e11f5c20233"
DRIVER_SHA = "719517842d609b194f74097e5c55a5bef98802f94f36b14a46bcddc180f9b428"
WORKFLOW_SHA = "97400b7044ecfdfce64dd6677e4eb96c16855797952e09c9aba397652df6de33"
VERIFIER_SHA = "2044858814cab8c2b970e05560774758b703ea674892583fdcdefd6aa8491440"
GOLDEN_SHA = "17ac4ede6046ccde7f2a2952d2e3e699ff75258089e195b3783638ac9735fc96"
CALLERS_BLOB = "c1a1b945171cdb20723e398cabe6a7888fa0abdb"
PRIOR_114_SHA = 'c923455c833ffb85e78852b8fa669b174b96cc86954a814b549a986dcaffbd81'
RENAMES_SHA = "981599dbc6b9ebc19aeacc84d22ada6f580e5b89013068bbb6e28c20e805c6de"


def pin(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def replace(text, old, new, count=1):
    if text.count(old) != count:
        raise ValueError(f"frozen replacement count differs: {old[:90]!r}")
    return text.replace(old, new)


def constant(text, name, value):
    pattern = re.compile(r"^" + re.escape(name) + r" = .*$", re.MULTILINE)
    found = pattern.findall(text)
    if len(found) != 1:
        raise ValueError("ambiguous frozen assignment: " + name)
    return replace(text, found[0], name + " = " + repr(value))


def constants(text):
    result = {}
    for node in ast.parse(text).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                result[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                pass
    return result


def listing(raw):
    entries = {}
    for record in raw.split(b"\0"):
        if not record:
            continue
        meta, raw_name = record.split(b"\t", 1)
        mode, kind, digest = meta.decode().split()
        name = raw_name.decode()
        path = PurePosixPath(name)
        assert name not in entries and kind == "blob"
        assert not path.is_absolute() and ".." not in path.parts and ".git" not in path.parts
        entries[name] = {"mode": mode, "type": kind, "git_blob": digest}
    return entries


def tree_hash(entries):
    root = {}
    for path, row in entries.items():
        node = root
        names = path.split("/")
        for name in names[:-1]:
            node = node.setdefault(name, {})
        assert names[-1] not in node
        node[names[-1]] = (row["mode"], row["git_blob"])

    def visit(node):
        rows = []
        for name, value in node.items():
            directory = isinstance(value, dict)
            mode, digest = ("40000", visit(value)) if directory else value
            rows.append(((name + ("/" if directory else "")).encode(),
                         mode.encode() + b" " + name.encode() + b"\0" + bytes.fromhex(digest)))
        data = b"".join(row[1] for row in sorted(rows))
        return hashlib.sha1(b"tree " + str(len(data)).encode() + b"\0" + data).hexdigest()

    return visit(root)


def make_verifier(original, values, runtime):
    """Bind actual post-admission IDs later; absent IDs never become placeholders."""
    assert re.fullmatch(r"[0-9a-f]{40}", runtime["harness_commit"])
    assert all(type(runtime[key]) is int and runtime[key] > 0 for key in ("run_id", "job_id", "attempt"))
    text = original
    for name, value in {"HEAD": values["head"], "TREE": values["tree"],
                        "HARNESS": runtime["harness_commit"], "INPUT_SHA": values["input"]["sha256"]}.items():
        text = constant(text, name, value)
    replacements = [
        ("(HARNESS, '43042186271', '1')", f'(HARNESS, {str(runtime["run_id"])!r}, {str(runtime["attempt"])!r})'),
        ('len(encoded) == 373068', f'len(encoded) == {values["input"]["bytes"]}'),
        ("'91137ce8dad5da7b214821067c3080c691bf981a'", repr(values["driver"]["git_blob"])),
        ('source["source_gate_run_version"] == 7', 'source["source_gate_run_version"] == 8'),
        ('len(source["files"]) == len(capsule["files"]) == 114', f'len(source["files"]) == len(capsule["files"]) == {values["paths"]}'),
        ('len(input_rows) == len(post_rows) == 114', f'len(input_rows) == len(post_rows) == {values["paths"]}'),
        ('len(initial) == len(final) == 14053', f'len(initial) == len(final) == {values["entries"]}'),
        ('len(roster) == 6204 and len(set(roster)) == 6204', f'len(roster) == {values["rust"]} and len(set(roster)) == {values["rust"]}'),
        ('inventory["rust_files"] == 6204', f'inventory["rust_files"] == {values["rust"]}'),
        ('comparison["explicit_count_delta"] == 4', f'comparison["explicit_count_delta"] == {values["rust"] - 6200}'),
        ('"original_run": 43042186271, "original_job": 130596614396', f'"original_run": {runtime["run_id"]}, "original_job": {runtime["job_id"]}'),
        ('"overlay_paths": 114', f'"overlay_paths": {values["paths"]}'),
        ('"rust_files_scanned": 6204', f'"rust_files_scanned": {values["rust"]}'),
        ('assert len(retained_paths) == 109', 'assert len(retained_paths) == 114'),
    ]
    for old, new in replacements:
        text = replace(text, old, new)
    text = replace(text, 'original V7 source-only', 'original V8 source-only')
    text = replace(text, 'source-ci.v7.offline-verification', 'source-ci.v8.offline-verification')
    ast.parse(text)
    return text


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--assembly", type=Path, required=True)
    parser.add_argument("--pure-head", required=True)
    parser.add_argument("--v7-records", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runtime-identity", type=Path)
    args = parser.parse_args()
    assert re.fullmatch(r"[0-9a-f]{40}", args.pure_head) and args.pure_head != PARENT_HEAD
    assembly = json.loads(args.assembly.read_bytes())
    assert (assembly["base_commit"], assembly["base_tree"], assembly["parent_commit"], assembly["parent_tree"]) == (
        BASE_HEAD, BASE_TREE, PARENT_HEAD, PARENT_TREE)
    encoded = (args.assembly.parent / "INPUT_SOURCE_GATES.json.xz").read_bytes()
    golden = (HERE / "reference/GOLDEN_CALLER_RECEIPT.json").read_bytes()
    assert pin(encoded) == assembly["input"] and pin(golden) == assembly["golden_caller_receipt"]
    assert len(golden) == 75046 and pin(golden)["sha256"] == GOLDEN_SHA
    config = json.loads(lzma.decompress(encoded))
    assert (config["base_sha"], config["base_tree"], config["source_parent_commit"], config["source_parent_tree"],
            config["source_gate_run_version"]) == (BASE_HEAD, BASE_TREE, PARENT_HEAD, PARENT_TREE, 8)
    assert config["expected_initial_tree"] == assembly["candidate_tree"]
    assert config["ready_to_execute"] is True and config["execution_scope"] == "source-only-format-caller-and-full-tree-scan"
    rename_bytes = (HERE / "reference/ORIGINAL_13_RENAMES.json").read_bytes()
    assert pin(rename_bytes)["sha256"] == RENAMES_SHA
    assert config["case_renames"] == json.loads(rename_bytes)
    base = listing((args.v7_records / "BASE_TREE.ls-tree").read_bytes())
    parent = listing((args.v7_records / "CANDIDATE_TREE.ls-tree").read_bytes())
    assert tree_hash(base) == BASE_TREE and tree_hash(parent) == PARENT_TREE
    rows = config["files"]
    assert len(rows) == len({row["path"] for row in rows}) == assembly["cumulative_paths"]
    candidate, by_path = dict(base), {row["path"]: row for row in rows}
    for row in rows:
        assert row["mode"] == "100644"
        assert (base.get(row["path"]) or {}).get("git_blob") == row["preimage_git_blob"]
        assert pin(row["content"].encode()) == {"bytes": row["bytes"], "sha256": row["sha256"], "git_blob": row["input_git_blob"]}
        candidate[row["path"]] = {"mode": row["mode"], "type": "blob", "git_blob": row["input_git_blob"]}
    assert tree_hash(candidate) == assembly["candidate_tree"] and len(candidate) == assembly["full_candidate_entries"]
    assert {path for path in set(base) | set(candidate) if base.get(path) != candidate.get(path)} == set(by_path)
    prior_bytes = (HERE / "reference/PRIOR_114_POSTIMAGES.json").read_bytes()
    assert pin(prior_bytes)["sha256"] == PRIOR_114_SHA
    prior = json.loads(prior_bytes)
    assert len(prior["files"]) == 114 and prior["source_tree"] == PARENT_TREE
    for row in prior["files"]:
        assert parent[row["path"]] == {"mode": row["mode"], "type": "blob", "git_blob": row["git_blob"]}
        assert pin(by_path[row["path"]]["content"].encode()) == {key: row[key] for key in ("bytes", "sha256", "git_blob")}
    changed = {path for path in set(parent) | set(candidate) if parent.get(path) != candidate.get(path)}
    assert changed == {row["path"] for row in assembly["files"]} == {row["path"] for row in config["new_reviewed_edits_vs_parent"]}
    assert len(changed) == assembly["changed_paths_vs_parent"]
    assert changed.isdisjoint({row["path"] for row in prior["files"]})
    for row in assembly["files"]:
        assert (parent.get(row["path"]) or {}).get("git_blob") == row["preimage_git_blob"]
        assert pin(by_path[row["path"]]["content"].encode()) == {key: row[key] for key in ("bytes", "sha256", "git_blob")}
    callers = (HERE / "reference/CALLERS.toml").read_bytes()
    assert pin(callers)["git_blob"] == CALLERS_BLOB == candidate["CALLERS.toml"]["git_blob"]
    roots = tomllib.loads(callers.decode())["source_roots"]
    rust_paths = [path for root in roots for path, row in sorted(candidate.items())
                  if path.startswith(root.rstrip("/") + "/") and path.endswith(".rs")]
    assert len(rust_paths) == len(set(rust_paths))
    assert all(candidate[path]["mode"] in ("100644", "100755") for path in rust_paths)
    driver_bytes = (HERE / "reference/driver_v7.py").read_bytes()
    workflow_bytes = (HERE / "reference/workflow_v7.yml").read_bytes()
    verifier_bytes = (HERE / "reference/verify_source_records_v7.py").read_bytes()
    assert pin(driver_bytes)["sha256"] == DRIVER_SHA and pin(workflow_bytes)["sha256"] == WORKFLOW_SHA
    assert pin(verifier_bytes)["sha256"] == VERIFIER_SHA
    original_constants = constants(driver_bytes.decode())
    for path, names in original_constants["REGRESSION_CASES"].items():
        module = ast.parse(by_path[path]["content"])
        cases = [f"{node.name}.{method.name}" for node in module.body if isinstance(node, ast.ClassDef)
                 for method in node.body if isinstance(method, ast.FunctionDef) and method.name.startswith("test_")]
        assert sorted(cases) == names
    assert sum(map(len, original_constants["REGRESSION_CASES"].values())) == 18
    driver = driver_bytes.decode()
    for name, value in {"HEAD": args.pure_head, "TREE": assembly["candidate_tree"],
                        "INPUT_SHA": pin(encoded)["sha256"], "INPUT_BYTES": len(encoded),
                        "PATH_COUNT": len(rows), "EXPECTED_RUST_FILES": len(rust_paths)}.items():
        driver = constant(driver, name, value)
    driver = replace(driver, "!= (BASE, BASE_TREE, 7)", "!= (BASE, BASE_TREE, 8)")
    driver = replace(driver, "frozen V7 input", "frozen V8 input")
    driver = driver.replace("mem8-source-gates-v7", "mem8-source-gates-v8")
    for old, new in [("114-path overlay", f"{len(rows)}-path overlay"),
                     ("all 114 reviewed paths", f"all {len(rows)} reviewed paths"),
                     ("at most 114 reviewed paths", f"at most {len(rows)} reviewed paths")]:
        driver = replace(driver, old, new)
    workflow = workflow_bytes.decode().replace("source-gates-v7", "source-gates-v8")
    workflow = workflow.replace("source_gates_v7", "source_gates_v8").replace("MEM8 V7", "MEM8 V8")
    workflow = replace(workflow, V7_HEAD, args.pure_head, count=2)
    workflow = replace(workflow, V7_TREE, assembly["candidate_tree"])
    workflow = replace(workflow, "fetch-depth: 8", "fetch-depth: 10")
    ast.parse(driver)
    parsed = yaml.load(workflow, Loader=yaml.BaseLoader)
    job = parsed["jobs"]["source-only"]
    assert job["timeout-minutes"] == "20" and parsed["permissions"] == {"contents": "read"}
    assert [step["with"]["fetch-depth"] for step in job["steps"] if step.get("uses", "").startswith("actions/checkout@")] == ["1", "10"]
    assert constants(driver)["LOCKS"] == original_constants["LOCKS"]
    assert constants(driver)["REGRESSION_CASES"] == original_constants["REGRESSION_CASES"]
    for step in job["steps"]:
        if "run" in step:
            check = subprocess.run(["bash", "-n"], input=step["run"], text=True, capture_output=True)
            assert check.returncode == 0, (step["name"], check.stderr)
            for block in re.findall(r"<<'PY'\n(.*?)\nPY(?:\n|$)", step["run"], re.DOTALL):
                ast.parse(block)
    files = {
        ".github/scripts/mem8_source_gates_v8.py": driver.encode(),
        ".github/workflows/hepta-mem8-source-gates-v8.yml": workflow.encode(),
        "qualification/memory-cell-mem8-source-gates-v8/INPUT_SOURCE_GATES.json.xz": encoded,
        "qualification/memory-cell-mem8-source-gates-v8/GOLDEN_CALLER_RECEIPT.json": golden,
    }
    values = {"head": args.pure_head, "tree": assembly["candidate_tree"], "input": pin(encoded),
              "paths": len(rows), "entries": len(candidate), "rust": len(rust_paths), "driver": pin(driver.encode())}
    if args.runtime_identity:
        runtime = json.loads(args.runtime_identity.read_bytes())
        files["verify_source_records_v8.py"] = make_verifier(verifier_bytes.decode(), values, runtime).encode()
    args.output.mkdir(parents=True, exist_ok=False)
    for name, data in files.items():
        path = args.output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    for name, before, after in [("DRIVER_V7_TO_V8.patch", driver_bytes.decode(), driver),
                                ("WORKFLOW_V7_TO_V8.patch", workflow_bytes.decode(), workflow)]:
        (args.output / name).write_text("".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="v7/" + name, tofile="v8/" + name)))
    audit = {
        "schema": "mem8.source-v8.harness-preparation.v1", "status": "STATIC_PREPARATION_ONLY",
        **values, "assembly": pin(args.assembly.read_bytes()), "golden": pin(golden),
        "retained_formatted_postimages": 114, "new_paths_vs_parent": sorted(changed),
        "caller_manifest": pin(callers), "source_roots": roots, "rust_paths": rust_paths,
        "only_allowed_caller_receipt_change": "rustFilesScanned", "original_golden_count": 6200,
        "derived_rust_count_delta": len(rust_paths) - 6200, "python_cases": original_constants["REGRESSION_CASES"],
        "rename_inventory": 13, "required_actual_old_name_hits": 0,
        "driver_rename_behavior": "Inherited review_required record; complete offline verifier requires zero actual hits",
        "gate_seconds": 600, "job_minutes": 20, "checkout_depths": [1, 10],
        "runtime_verifier_bound": bool(args.runtime_identity),
        "missing_runtime_identity_if_unbound": ["harness_commit", "run_id", "job_id", "attempt"],
        "outputs": [{"path": name, **pin(data)} for name, data in files.items()],
        "source_gate_executed": False, "native_tests_executed": 0, "model_requests_executed": 0, "refs_changed": False,
    }
    (args.output / "STATIC_VALIDATION.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps({key: audit[key] for key in ("status", "head", "tree", "paths", "rust", "outputs")}, indent=2))


if __name__ == "__main__":
    main()
