# V8 source-only harness preparation

The candidate is a minimal successor of the actually successful V7 driver and workflow. `generated/DRIVER_V7_TO_V8.patch` and `generated/WORKFLOW_V7_TO_V8.patch` contain the complete execution delta. No source gate, native test, provider call or ref mutation is performed during generation.

The builder independently checks the full base and parent trees, two exact Clippy postimages, all 114 retained formatted inputs, all 116 cumulative paths, the complete caller manifest and the 6,204-file roster. It preserves the original 18 Python case IDs, 13 retired-name inventory, fixed tools, two lockfiles and full golden semantics. The source checkout depth is 10; the harness depth remains 1.

The unchanged driver records old-name hits for review. Qualification additionally requires the runtime-bound full offline verifier to prove zero actual hits. That verifier is generated only after the real harness commit, run, job and attempt are supplied; none are invented here. The original complete tar inside each Actions artifact is the canonical source record inventory because the direct ZIP layer omits hidden source copies.

See `generated/MEM_CI_INDEPENDENT_HARNESS_PEER.json` for the independent static review. Static preparation is not an execution result.
