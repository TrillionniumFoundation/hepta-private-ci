# Windows scoped lint candidate for b054

This is an unpublished, unexecuted two-file harness candidate. It runs exactly three scoped `just fix` commands against source `b0547d2f874c0aeb54dabd3491caa2bee49fcb0b`, tree `3f89ddeff13d0af85f4abe2690699107357f1038`. No Rust command, model request, host task, workflow dispatch or ref mutation was performed while preparing this candidate.

## Existing entry and minimal implementation

The frozen `hepta-windows-current-ci.yml` has a fixed 19-group test driver. It exposes no three-package fix-only mode. The signed-credit step in `hepta-windows-private-state-native.yml` already uses a direct Windows `subprocess.run` and the Actions job deadline. This candidate reuses that execution pattern and source-identity convention. `scripts/hepta_ci_exec.py::execute_logged` explicitly rejects non-POSIX hosts, so it is not used as a Windows supervisor.

The candidate adds one Python driver and one workflow. Only a push to `codex/mem8-windows-scoped-fix-b054-20261111-ed353817` matches the new workflow. The root must first check that branch's absence and review the final bytes before creating it; this packet performs neither action. The harness checkout uses its actual immutable event SHA. A separate source checkout is fixed to b054. Saved Git credentials are disabled in both checkouts.

The commands, in their original order, are:

1. `just fix --locked -p codex-hepta-neuron --features qualification-owned-file-read`
2. `just fix --locked -p codex-core`
3. `just fix --locked -p codex-windows-sandbox`

They execute from `codex-rs`. The exact repository recipe is `cargo clippy --fix --tests --allow-dirty {args}`. It compiles and lints test code; the harness does not run tests. It installs only Rust 1.96.0 with Clippy and just 1.51.0, using the existing immutable action versions. No Nextest, runtime binary staging, workspace-wide fix, `--all-features`, formatter, provider or owner startup is added.

## Admission correction

`PLAN_CORRECTION.json` preserves and corrects the earlier plan's unnecessary dependency on five native PASS results. Root explicitly clarified that scoped lint may run independently on the frozen source. The final harness contains no validation-evidence input or native-PASS gate. The final native acceptance still needs its separate actual results; lint cannot close it.

The original plan and both completed/failed historical source or native runs are unchanged. The first local static check also recorded an incorrect expected workflow-step count; the final source-only validator uses the actual eight steps. No candidate command executed in either check.

## Deadline and interrupted work

One `timeout-minutes: 65` bounds the complete hosted job, including checkout and tool installation. The first step records an observation time, the run/attempt and harness SHA. It is explicitly later than the Actions job start, not a claim to know that start. Before and after each fix the driver checks the same anchor and remaining envelope; no later command gets a new 65-minute timer. The real Actions timeout remains authoritative and can end the job earlier than that first-step-relative check.

The driver does not use a POSIX process group, a PID kill, a new Windows process capability, or a per-command timeout/retry. As in the existing Windows lane, Actions owns cancellation. Intent and raw output are written before/during every command. If interruption prevents an exit/after receipt, the retained intent remains running or failed/interrupted. An always-run collector attempts to preserve the observed source and complete logs. It cannot supply a missing exit acknowledgement or prove quiescence. If cancellation also prevents artifact upload, that remains an artifact gap. Neither condition can produce a clean lint PASS.

## Source, lock and tool evidence

The complete 14,050-entry source tree was independently recomputed from the actual V6 tree listing and matched `3f89...`; neither new harness path already exists, and root `AGENTS.md` is the only applicable instruction file. `SOURCE_TREE_PROOF.json` binds that calculation. Twelve exact source references were fetched at b054 and their full bytes checked against Git blob identities. The large lockfiles are represented by their immutable blob, length and SHA-256 in `SOURCE_INDEX.json`; the remaining ten original source texts are included under `reference/`.

Before each fix, after each completed fix, and before/after the full sequence, the driver records HEAD, tree, parents, tracked status and **all untracked files including ignored files**, plus byte digests of `codex-rs/Cargo.lock` and `MODULE.bazel.lock`. The initial recipe, policy and toolchain files must match their exact frozen bytes. Build output is placed outside the source checkout.

The workflow supplies process-local Git `core.autocrlf=false` so checkout bytes are not translated on Windows; it does not change global Git settings. Resource limits remain one Cargo build job, incremental disabled, dev/test debug zero and uncolored output. These are checked by the driver. Rust/Cargo/Clippy/just actual versions and resolved executable digests are captured before the full sequence and before/after each command, then compared. The harness's own actual clean commit/tree and script/workflow digests are also recorded.

Every source snapshot retains binary/full-index combined, index, working-tree and qualified-source patches. Every changed regular file is copied in full; deletions and symlinks are represented explicitly. A nonzero exit, source change, lock change or tool change stops the sequence. No reset, automatic apply, commit or continuation on rewritten source occurs. The collector includes hidden postimage paths and a member manifest. Its snapshot is observation only when an underlying command lacks a terminal receipt.

## Review and limits

`verify_candidate_static.py` parses Python and YAML without importing or executing the candidate, checks the fixed commands/pins/trigger/budget and verifies the absence of native-PASS prerequisites. Its result is `STATIC_VALIDATION.json`. This establishes static agreement with the requested scope; it is not a Windows execution or lint result. The candidate is 383 lines across two new repository paths before any later requested correction.

Three actual clean successful receipts would close only the scoped `just fix` instruction for these packages on b054. A compiler/linter failure remains a real failure. Any rewrite requires review as a separate source change and cannot inherit b054's native evidence. This job does not replace required CI, Architecture, the five changed native cases, the Windows elevated-delete boundary or any real-memory benefit/owner qualification.
