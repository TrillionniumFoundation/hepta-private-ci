"""Offline source/AST/YAML review only; never executes the candidate driver."""

import ast
import hashlib
import json
from pathlib import Path

import yaml


root = Path(__file__).resolve().parent
driver_path = root / "source/.github/scripts/mem_windows_scoped_fix.py"
workflow_path = root / "source/.github/workflows/hepta-mem-windows-scoped-fix.yml"
driver = driver_path.read_text()
syntax = ast.parse(driver)
constants = {}
for node in syntax.body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        try:
            constants[node.targets[0].id] = ast.literal_eval(node.value)
        except ValueError:
            pass
workflow = yaml.load(workflow_path.read_text(), Loader=yaml.BaseLoader)
plan = json.loads((root / "reference/ORIGINAL_SCOPED_FIX_PLAN.json").read_text())
pins = json.loads((root / "SOURCE_INDEX.json").read_text())
proof = json.loads((root / "SOURCE_TREE_PROOF.json").read_text())
branch = "codex/mem8-windows-scoped-fix-b054-20261111-ed353817"
assert workflow["on"] == {"push": {"branches": [branch]}}
assert workflow["permissions"] == {"contents": "read"}
assert workflow["concurrency"]["cancel-in-progress"] == "false"
assert set(workflow["jobs"]) == {"scoped-fix"}
job = workflow["jobs"]["scoped-fix"]
assert job["if"] == f"github.ref == 'refs/heads/{branch}'"
assert job["runs-on"] == "windows-latest" and job["timeout-minutes"] == "65"
assert constants["SOURCE_HEAD"] == pins["source_head"]
assert constants["SOURCE_TREE"] == pins["source_tree"] == proof["actual_complete_tree"]
assert proof["new_source_paths_absent"] and proof["applicable_AGENTS"] == ["AGENTS.md"]
assert constants["COMMANDS"] == plan["recommended_job"]["commands"]
assert len(constants["COMMANDS"]) == 3
for key, value in constants["POLICY"].items():
    assert workflow["env"][key] == value
for path, sha in (constants["PINS"] | constants["LOCKS"]).items():
    assert next(row for row in pins["source_index"] if row["path"] == path)["sha256"] == sha
steps = job["steps"]
assert len(steps) == 8
assert steps[1]["with"]["ref"] == "${{ github.sha }}"
assert steps[2]["with"]["ref"] == constants["SOURCE_HEAD"]
assert all(step["with"]["persist-credentials"] == "false" for step in steps[1:3])
assert steps[3]["with"] == {"toolchain": "1.96.0", "components": "clippy"}
assert steps[4]["with"] == {"tool": "just@1.51.0"}
assert steps[-2]["if"] == steps[-1]["if"] == "always()"
assert steps[-1]["with"]["include-hidden-files"] == "true"
assert steps[-1]["with"]["if-no-files-found"] == "error"
allowed_actions = {
    "actions/checkout@de0fac2e4500dabe0009e67214ff5f5447ce83dd",
    "dtolnay/rust-toolchain@d86e0fa8f147d6539442c26a61ebba8becc19489",
    "taiki-e/install-action@44c6d64aa62cd779e873306675c7a58e86d6d532",
    "actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02",
}
assert {step["uses"] for step in steps if "uses" in step} == allowed_actions
assert not any(token in driver for token in [
    "execute_logged", "os.kill", "taskkill", "TerminateProcess", "cargo test",
    "CODEX_SANDBOX_NETWORK_DISABLED", "CODEX_SANDBOX=", "validation_evidence",
])
assert 'anchor["harness_sha"] != os.environ["GITHUB_SHA"]' in driver
assert '"native_test_commands": [], "model_commands": []' in driver
assert 'git(source, "ls-files", "--others", "-z")' in driver
assert '"--binary", "--full-index"' in driver and 'directory / "postimages"' in driver
assert "except BaseException as error" in driver
assert 'result["status"] == "passed_three_clean_scoped_fixes"' in driver
assert "fix *args:\n    cargo clippy --fix --tests --allow-dirty {args}" in (root / "reference/justfile").read_text()
rows = []
for path in [driver_path, workflow_path]:
    data = path.read_bytes()
    rows.append({
        "path": path.relative_to(root / "source").as_posix(), "preimage": None,
        "bytes": len(data), "lines": len(data.splitlines()),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    })
result = {
    "schema": "mem8.windows-scoped-fix.static-check.v1", "status": "PASS_STATIC_ONLY",
    "source_head": constants["SOURCE_HEAD"], "source_tree": constants["SOURCE_TREE"],
    "candidate_files": rows, "candidate_driver_executed": False,
    "native_or_lint_commands_executed": 0, "model_commands_executed": 0,
    "assertions": "AST, YAML, exact commands, pins, source-tree proof, trigger and no native-PASS prerequisite",
    "limitations": "Static checks do not establish Windows execution, tool availability or successful lint",
}
(root / "STATIC_VALIDATION.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, sort_keys=True))
