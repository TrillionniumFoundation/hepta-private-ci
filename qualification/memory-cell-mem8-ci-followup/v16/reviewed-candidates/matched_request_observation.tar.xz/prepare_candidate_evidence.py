import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parent
BASE = "b0547d2f874c0aeb54dabd3491caa2bee49fcb0b"
TREE = "3f89ddeff13d0af85f4abe2690699107357f1038"
PATHS = [
    "codex-rs/core/tests/common/responses.rs",
    "codex-rs/core/tests/common/responses_matcher_tests.rs",
]


def identity(raw):
    return {
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest(),
    }


def write_json(name, value):
    with (ROOT / name).open("x") as out:
        json.dump(value, out, indent=2, ensure_ascii=False)
        out.write("\n")


def between(text, start, end):
    return text[text.index(start):text.index(end, text.index(start))]


before = (ROOT / "original" / PATHS[0]).read_text()
after = (ROOT / "candidate" / PATHS[0]).read_text()
module = '\n#[cfg(test)]\n#[path = "responses_matcher_tests.rs"]\nmod matcher_tests;\n'
assert after.count(module) == 1
reverse = after.replace(module, "")
old_response = between(before, "pub async fn mount_response_once_match", "fn base_mock()")
new_response = between(after, "pub async fn mount_response_once_match", "fn base_mock()")
old_sse = between(before, "pub async fn mount_sse_once_match", "pub async fn mount_sse_once(")
new_sse = between(after, "pub async fn mount_sse_once_match", "pub async fn mount_sse_once(")
assert reverse.count(new_response) == reverse.count(new_sse) == 1
reverse = reverse.replace(new_response, old_response).replace(new_sse, old_sse)
assert reverse == before
base_mock = between(before, "fn base_mock()", "fn compact_mock()")
assert '.given(' not in base_mock
assert 'Mock::given(method("POST"))' in base_mock
assert '.and(path_regex(".*/responses$"))' in base_mock
assert '.and(response_mock.clone())' in base_mock
assert base_mock.count('.and(') == 2
assert "header" not in base_mock
assert new_response.index('.and(matcher)') < new_response.index('.and(response_mock.clone())')
assert old_response.count('.up_to_n_times(1)') == new_response.count('.up_to_n_times(1)') == 1
assert "mount_response_once_match(server, matcher, sse_response(body)).await" in new_sse
for other in ["mount_response_once", "mount_sse_once", "mount_sse_sequence", "mount_response_sequence"]:
    assert re.search(r"pub async fn " + other + r"(?:<|\()", before)

index = json.loads((ROOT / "SOURCE_INDEX.json").read_text())
pinned_tokio = json.loads((ROOT / "PINNED_TOKIO_TUNGSTENITE_REFERENCE.json").read_text())
pinned_bytes = pinned_tokio["content"].encode()
assert identity(pinned_bytes)["git_blob"] == pinned_tokio["git_blob"]
pinned_path = ROOT / "reference" / pinned_tokio["repository"] / pinned_tokio["path"]
pinned_path.parent.mkdir(parents=True, exist_ok=True)
with pinned_path.open("xb") as out:
    out.write(pinned_bytes)
rows = index["sources"] + [
    {key: value for key, value in pinned_tokio.items() if key != "content"}
    | identity(pinned_bytes)
    | {"local_path": str(pinned_path.relative_to(ROOT)), "actual_dependency_pin": True}
]
for row in rows:
    raw = (ROOT / row["local_path"]).read_bytes()
    assert all(identity(raw)[key] == row[key] for key in ("bytes", "sha256", "git_blob"))
    if row["repository"] == "snapview/tokio-tungstenite":
        row["role"] = "Upstream comparison only; actual workspace uses the separately pinned OpenAI fork."
full_index = index | {"source_count": len(rows), "sources": rows}
write_json("FINAL_SOURCE_INDEX.json", full_index)

patch = (ROOT / "CANDIDATE.patch").read_bytes()
with tempfile.TemporaryDirectory(prefix="patch-replay-", dir=ROOT) as directory:
    replay = Path(directory)
    original = replay / PATHS[0]
    original.parent.mkdir(parents=True)
    original.write_bytes(before.encode())
    command = ["git", "apply", "--check", str(ROOT / "CANDIDATE.patch")]
    check = subprocess.run(command, cwd=replay, capture_output=True, check=False)
    assert check.returncode == 0, check.stderr.decode()
    apply = subprocess.run(["git", "apply", str(ROOT / "CANDIDATE.patch")], cwd=replay, capture_output=True, check=False)
    assert apply.returncode == 0, apply.stderr.decode()
    for path in PATHS:
        assert (replay / path).read_bytes() == (ROOT / "candidate" / path).read_bytes()

source_records = []
for path in PATHS:
    old_path = ROOT / "original" / path
    old = old_path.read_bytes() if old_path.exists() else None
    new = (ROOT / "candidate" / path).read_bytes()
    source_records.append({
        "path": path,
        "mode": "100644",
        "before": identity(old) if old is not None else None,
        "after": identity(new),
        "before_content": old.decode() if old is not None else None,
        "after_content": new.decode(),
    })
write_json("SOURCE_CAPSULE.json", {
    "schema": "source-candidate-capsule-v1",
    "base_commit": BASE,
    "base_tree": TREE,
    "state": "FROZEN_SOURCE_CANDIDATE_NOT_FORMATTED_NOT_COMPILED_NOT_EXECUTED",
    "files": source_records,
})

original_root = Path("/workspace/scratch/ed3538174819/mem-ci-9bd2-original")
raw_path = original_root / "job-130526871715-decoded.log"
raw = raw_path.read_bytes()
assert identity(raw)["sha256"] == "c387a603c747128758bbb4440aa2887abf27941adea78a332591edca3e5fd943"
original_audit = (original_root / "WINDOWS_SHARD4_ORIGINAL_AUDIT.json").read_bytes()
audit = json.loads(original_audit)
assert len(audit["original_output_blocks"]) == 8
with (ROOT / "ORIGINAL_EIGHT_BLOCK_AUDIT.json").open("xb") as out:
    out.write(original_audit)
lines = raw.decode().splitlines()
events = []
for block_number, block in enumerate(audit["original_output_blocks"], 1):
    for failure in block["failed_cases"]:
        if "subagent_notifications" not in failure["case"]:
            continue
        lower, upper = failure["failure_block_lines"]
        for line_number in range(lower, upper + 1):
            line = lines[line_number - 1]
            timestamps = re.findall(r"2026-11-11T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z", line)
            response_ids = re.findall(r'"(?:id|response_id)"\s*:\s*"(resp-[a-zA-Z0-9-]+)"', line)
            if "response.completed" in line and response_ids:
                event = {"event": "fixture_sse_response_completed", "fixture_response_ids": response_ids}
            elif "aborting" in line:
                event = {"event": "logged_abort"}
            elif "expected at least" in line:
                event = {"event": "original_hook_log_count_failure", "errors": failure["errors"]}
            else:
                continue
            events.append(event | {
                "block": block_number,
                "case": failure["case"],
                "raw_line": line_number,
                "raw_line_sha256": hashlib.sha256((line + "\n").encode()).hexdigest(),
                "outer_upload_timestamp": timestamps[0] if timestamps else None,
                "internal_timestamp": timestamps[1] if len(timestamps) > 1 else None,
            })
write_json("HOOK_FAILURE_SAFE_TIMELINE.json", {
    "schema": "original-hook-failure-safe-projection-v1",
    "source_head": audit["source_head"],
    "actual_merge_head": audit["actual_merge_head"],
    "tree": audit["tree"],
    "run_id": audit["run_id"],
    "job_id": audit["job_id"],
    "original_raw_path": str(raw_path),
    "original_raw": identity(raw),
    "original_eight_block_audit": identity(original_audit),
    "events": events,
    "scope": "Safe timestamp/event-name/fixture-response-ID projection only. No model prompts, payloads, world state, environment, or Python hook stdin are copied.",
    "unknown": [
        "Original per-mock captured request vectors were not preserved in the raw log.",
        "Original Python process start/end, stdin EOF, and append syscalls were not recorded.",
        "This does not prove that all hook timeouts had one cause, nor that JSONL writes were lost.",
    ],
})

helper_audit = {
    "base_predicates_preserved": ['method("POST")', 'path_regex(".*/responses$")'],
    "base_header_predicates": [],
    "old_order": ["method", "path", "record_and_validate", "custom_semantic_matcher"],
    "new_order": ["method", "path", "custom_semantic_matcher", "record_and_validate"],
    "exact_affected_functions": ["mount_response_once_match", "mount_sse_once_match"],
    "all_other_existing_bytes_restored_by_inverse": True,
    "all_other_helpers_and_expectations_unchanged": True,
    "original_matched_helper_up_to_n_times": 1,
    "candidate_matched_helper_up_to_n_times": 1,
    "original_matched_helper_expect_predicate": None,
    "candidate_matched_helper_expect_predicate": None,
    "sse_template_constructor_unchanged": True,
    "wiremock_short_circuit_evidence": {
        "version": "0.6.5",
        "lock_git_blob": "025813e20504f31d12dae2092a0807a1a4066419",
        "matcher_insertion": "src/mock.rs::MockBuilder::and appends the matcher",
        "matcher_evaluation": "src/mounted_mock.rs::matches evaluates matchers.iter().all in insertion order, after the maximum-match check",
        "mock_selection": "src/mock_set.rs evaluates mounted mocks by priority and returns the first matching response",
    },
    "caller_scope": "Full responses.rs helper chain and full original subagent_notifications.rs were read; no claim of a new whole-repository call-site census.",
}
write_json("STATIC_AUDIT.json", {
    "schema": "response-recorder-static-audit-v1",
    "observed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "base_commit": BASE,
    "base_tree": TREE,
    "patch": identity(patch),
    "whole_patch_actual_git_apply_check_and_replay": "PASS",
    "approved_function_inverse_byte_equality": "PASS",
    "source_reference_hashes": "PASS",
    "helper_chain": helper_audit,
    "new_test_name": "responses::matcher_tests::matched_response_helpers_record_only_accepted_requests",
    "new_test_budget": "One absolute 2-second tokio timeout covers both helpers and all loopback requests.",
    "new_test_controls": [
        "GET on the correct path is rejected without a captured request.",
        "POST on a different path is rejected without a captured request.",
        "Semantically mismatched POST is rejected without a captured request.",
        "Matching POST succeeds and single_request enforces exactly one recorded request with the original complete body.",
        "A second matching POST is rejected by the unchanged up_to_n_times(1), with the same single captured request.",
        "Both generic-response and SSE helper entrypoints undergo the same real loopback controls.",
    ],
    "native_not_run": True,
    "formatter_not_run": True,
    "model_requests": 0,
    "remote_mutations": 0,
    "original_case_budgets_and_assertions_modified": False,
    "original_jsonl_hook_scripts_modified": False,
    "original_cause_uniquely_proved": False,
})

manifest = {
    "schema": "source-candidate-manifest-v1",
    "state": "FROZEN_STATIC_CANDIDATE_NOT_FORMATTED_NOT_COMPILED_NOT_EXECUTED",
    "base_commit": BASE,
    "base_tree": TREE,
    "files": [{key: value for key, value in row.items() if not key.endswith("_content")} for row in source_records],
    "patch": identity(patch),
    "source_capsule": identity((ROOT / "SOURCE_CAPSULE.json").read_bytes()),
    "source_index": identity((ROOT / "FINAL_SOURCE_INDEX.json").read_bytes()),
    "semantic_scope": helper_audit,
    "existing_native_targets": {
        "cargo_package": "core_test_support",
        "cargo_target": "--lib",
        "bazel_target": "//codex-rs/core/tests/common:common-unit-tests",
        "existing_build_glob": "codex-rs/core/tests/common/BUILD.bazel crate_srcs=glob([\"*.rs\"])",
        "new_test_module": "responses.rs #[cfg(test)] #[path = \"responses_matcher_tests.rs\"] mod matcher_tests",
        "dependencies_changed": False,
    },
    "future_validation_not_executed": [
        "just test --locked -p core_test_support --lib -E 'test(=responses::matcher_tests::matched_response_helpers_record_only_accepted_requests)' --no-tests fail --retries 0",
        "Re-execute the two original subagent_notifications integration cases on the next published exact source with their existing 2-second waits and complete original assertions.",
        "Run the repository formatter and scoped lint through the root-coordinated source/qualification workflow; retain all actual postimages and clean-source receipts.",
    ],
    "original_failed_cases": [
        "suite::subagent_notifications::subagent_stop_replaces_stop_and_skips_internal_subagents",
        "suite::subagent_notifications::subagent_start_replaces_session_start_and_injects_context",
    ],
    "boundaries": [
        "The new regression has not been run. The old implementation would record the rejected POST before the custom matcher returns false, by the pinned source contract.",
        "Original Python JSONL writers, 2-second waits, expected log counts, original assertions and production hooks are byte-identical.",
        "The defect is a real request-observation error, but the exact original timeout cause is not uniquely established without original captured request/process traces.",
        "Computed Git blob identities here do not assert that immutable blobs or refs were created.",
    ],
}
write_json("CANDIDATE_MANIFEST.json", manifest)
print(json.dumps({"manifest": identity((ROOT / "CANDIDATE_MANIFEST.json").read_bytes()), "capsule": manifest["source_capsule"], "patch": identity(patch), "files": manifest["files"]}, indent=2))
