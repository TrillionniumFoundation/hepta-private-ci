"""Download and verify an original artifact; never execute archived content."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import urllib.error
import urllib.request
import zipfile

HERE = Path(__file__).resolve().parent

def main():
    artifact = json.loads(Path(sys.argv[1]).read_bytes())
    destination = HERE / "artifacts" / str(artifact["id"])
    destination.mkdir(parents=True, exist_ok=True)
    archive = destination / "original.zip"
    digest = hashlib.sha256()
    length = 0
    try:
        with urllib.request.urlopen(sys.argv[2], timeout=60) as source, archive.open("xb") as sink:
            while chunk := source.read(1024 * 1024):
                sink.write(chunk)
                digest.update(chunk)
                length += len(chunk)
    except Exception as error:
        record = {"error_type": type(error).__name__, "http_code": getattr(error, "code", None),
                  "partial_bytes": length, "signed_download_url_retained": False}
        (destination / "DOWNLOAD_FAILURE.json").write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps(record), file=sys.stderr)
        return 1
    assert length == artifact["size_in_bytes"]
    assert "sha256:" + digest.hexdigest() == artifact["digest"]
    members, seen = [], set()
    with zipfile.ZipFile(archive) as packed:
        assert packed.testzip() is None
        for item in packed.infolist():
            name = item.filename
            path = PurePosixPath(name)
            assert name not in seen and "\\" not in name and not path.is_absolute()
            assert path.parts and not any(p in (".", "..") or ":" in p for p in path.parts)
            seen.add(name)
            mode = item.external_attr >> 16
            assert not stat.S_ISLNK(mode)
            if item.is_dir():
                continue
            assert not stat.S_IFMT(mode) or stat.S_ISREG(mode)
            output = destination / "files" / path
            output.parent.mkdir(parents=True, exist_ok=True)
            md5 = hashlib.sha256()
            count = 0
            with packed.open(item) as source, output.open("xb") as sink:
                while chunk := source.read(1024 * 1024):
                    sink.write(chunk)
                    md5.update(chunk)
                    count += len(chunk)
            assert count == item.file_size
            members.append({"name": name, "bytes": count, "sha256": md5.hexdigest(), "crc": item.CRC})
    manifest = {"artifact": artifact, "archive": {"bytes": length, "sha256": digest.hexdigest()},
                "members": members, "signed_download_url_retained": False}
    (destination / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"artifact_id": artifact["id"], "archive": manifest["archive"], "members": len(members)}))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
