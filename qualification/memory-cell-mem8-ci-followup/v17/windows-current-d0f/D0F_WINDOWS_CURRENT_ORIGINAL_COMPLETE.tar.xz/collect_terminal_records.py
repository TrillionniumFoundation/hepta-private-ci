"""Bind original API and artifact records without executing repository code."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'records'
HEAD = 'd0f6507e08f7f5c5855f5164d07c049a34d1a6d9'
RUN = 43062473110
JOB = 130668436858

def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}

def create(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)

def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

def read_json(path):
    return json.loads(path.read_bytes())

def original_api(path):
    wrapped = read_json(path)
    return json.loads(wrapped['structuredContent']['content'])

def main():
    run = original_api(ROOT / 'FULL_RUN_API.json')
    full_jobs = original_api(ROOT / 'FULL_TERMINAL_JOBS_API.json')
    normalized = read_json(ROOT / 'NORMALIZED_TERMINAL_JOBS.json')['structuredContent']['jobs']
    assert run['id'] == RUN and run['run_attempt'] == 1 and run['head_sha'] == HEAD
    assert run['head_branch'] == 'codex/mem8-integrated-source-20261111-ed353817'
    assert run['status'] == 'completed' and run['conclusion'] is not None
    assert full_jobs['total_count'] == len(full_jobs['jobs']) == len(normalized) == 1
    job, projected = full_jobs['jobs'][0], normalized[0]
    assert job['id'] == JOB and job['run_id'] == RUN and job['run_attempt'] == 1
    assert job['head_sha'] == HEAD and job['head_branch'] == run['head_branch']
    assert job['status'] == 'completed' and job['conclusion'] is not None
    compared = ['id', 'name', 'status', 'conclusion', 'run_id']
    assert all(job[key] == projected[key] for key in compared)
    step_keys = ['name', 'status', 'conclusion', 'number']
    assert [{key: step[key] for key in step_keys} for step in job['steps']] == projected['steps']
    assert projected['logs_url'] is None
    artifacts = read_json(ROOT / 'ARTIFACTS_API.json')['structuredContent']['artifacts']
    name = f'windows-current-ci-{HEAD}-{RUN}-1'
    matched = [row for row in artifacts if row['name'] == name]
    assert len(matched) == 1
    artifact = matched[0]
    assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD
    raw_zip = (OUT / 'ORIGINAL_ARTIFACT.zip').read_bytes()
    assert len(raw_zip) == artifact['size_in_bytes']
    assert 'sha256:' + pin(raw_zip)['sha256'] == artifact['digest']
    with zipfile.ZipFile(OUT / 'ORIGINAL_ARTIFACT.zip') as archive:
        assert archive.testzip() is None
    create(OUT / 'TERMINAL_JOBS.json', (ROOT / 'FULL_TERMINAL_JOBS_API.json').read_bytes())
    create(OUT / 'WORKFLOW_RUN.json', encode(run))
    create(OUT / 'ARTIFACT_METADATA.json', encode(artifact))
    log_response = read_json(ROOT / 'JOB_LOG_TOOL_RESPONSE.json')
    create(OUT / 'ORIGINAL_JOB.log', log_response['structuredContent']['content'].encode())
    mapping = {
        'schema': 'github-original-job-normalized-projection-comparison-v1',
        'original_run': RUN, 'original_job': JOB, 'attempt': 1,
        'full_api': pin((ROOT / 'FULL_TERMINAL_JOBS_API.json').read_bytes()),
        'normalized_api': pin((ROOT / 'NORMALIZED_TERMINAL_JOBS.json').read_bytes()),
        'compared_job_fields': compared, 'compared_step_fields': step_keys,
        'all_shared_projection_fields_equal': True,
        'logs_url_boundary': 'Normalized logs_url is a tool-specific null projection, not a raw GitHub field and not evidence that original logs are unavailable.',
        'head_attempt_branch_timestamps': 'Read from the complete original API JSON; not inferred from absent projected fields.',
    }
    create(ROOT / 'API_PROJECTION_COMPARISON.json', encode(mapping))
    rows = []
    for path in sorted(OUT.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            rows.append({'path': path.relative_to(OUT).as_posix(), **pin(path.read_bytes())})
    create(OUT / 'ORIGINAL_BYTE_PINS.json', encode({'schema': 'mem-d0f-windows-original-byte-pins-v1', 'run_id': RUN, 'job_id': JOB, 'head': HEAD, 'files': rows}))
    print(json.dumps({'original_run': RUN, 'original_job': JOB, 'api_conclusion': job['conclusion'], 'artifact_id': artifact['id'], 'original_zip': pin(raw_zip), 'bound_record_files': len(rows), 'normalized_projection_equal': True}))

if __name__ == '__main__':
    main()
