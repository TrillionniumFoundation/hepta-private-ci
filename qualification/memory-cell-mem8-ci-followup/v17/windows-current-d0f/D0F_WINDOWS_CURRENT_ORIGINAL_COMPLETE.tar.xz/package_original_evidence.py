"""Freeze original Windows-current bytes and offline audits without execution."""
import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUTPUT = Path('/tmp/mem-d0f-windows-current-complete-publication')

def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}

def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

def create(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)

def read(path):
    return json.loads(path.read_bytes())

def main():
    audit = read(ROOT / 'AUDIT.json')
    execution = read(ROOT / 'AUDIT_V1_EXECUTION.json')
    assert execution['actual_return_code'] == 0
    assert execution['reader'] == pin((ROOT / 'records/verify_original.py').read_bytes())
    assert execution['stdout'] == pin((ROOT / 'AUDIT.json').read_bytes())
    assert (ROOT / 'AUDIT_V1.stdout').read_bytes() == (ROOT / 'AUDIT.json').read_bytes()
    assert audit['run_id'] == 43062473110 and audit['job_id'] == 130668436858 and audit['attempt'] == 1
    assert audit['head'] == 'd0f6507e08f7f5c5855f5164d07c049a34d1a6d9'
    assert audit['tree'] == '658fa040046285116b1fd81b94ff8c96444072ad'
    assert audit['job_conclusion'] == 'cancelled'
    assert audit['original_scope_groups'] == 19 and audit['original_scope_cases'] == 167
    assert sum(audit['terminal_counts'].values()) == audit['terminal_distinct_original_case_ids']
    assert audit['terminal_distinct_original_case_ids'] + audit['no_observed_terminal_case_count'] == 167
    classification = read(ROOT / 'TERMINAL_CLASSIFICATION.json')
    assert classification['actual_case_status_counts'] == audit['terminal_counts']
    assert classification['unobserved_terminal_case_count'] == audit['no_observed_terminal_case_count']
    assert audit['original_final_receipt'] is None and audit['source_after_observation'] == 'UNOBSERVED_NO_FINAL_RECEIPT'
    assert audit['archive'] == pin((ROOT / 'records/ORIGINAL_ARTIFACT.zip').read_bytes())
    replay = {
        'schema': 'mem-d0f-windows-original-replay-boundary-v1',
        'command': 'python3 records/verify_original.py records',
        'scope': 'The reader verifies retained original records only; no archived native driver or model is executed.',
        'frozen_reader': pin((ROOT / 'records/verify_original.py').read_bytes()),
        'original_zip': audit['archive'], 'zip_members': len(audit['members']),
        'metadata_projection': 'Full GitHub API JSON binds head/attempt/branch/times; normalized purpose-tool shared fields are compared separately. Its logs_url:null is not evidence that original logs are missing.',
        'counts': 'Only original per-group Nextest terminal records count. Duplicate summary rows are de-duplicated, 9 Python strict-parser controls are separate, absent terminal cases remain unknown.',
        'unchanged_reader_first_run': True,
        'lock_representation_reference': 'Original observed Cargo.lock SHA matches CRLF encoding of exact source Git blob 025813e20504f31d12dae2092a0807a1a4066419. Its LF bytes are available in previously published two-native preparation publication 11c317586715589a39597dd0082befe8bf33589c; original Windows raw lock bytes are not archived here.',
        'qualification_boundary': classification['whole_scope_qualification'],
    }
    create(ROOT / 'OFFLINE_REPLAY_INPUTS.json', encoded(replay))
    sources = {path.name: path for path in ROOT.iterdir() if path.is_file() and not path.name.startswith('ROOT_')}
    sources.update({path.relative_to(ROOT).as_posix(): path for path in (ROOT / 'records').rglob('*') if path.is_file()})
    sources['artifact-original-download/MANIFEST.json'] = ROOT / 'artifacts/13878563215/MANIFEST.json'
    buffer, members = io.BytesIO(), []
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, path in sorted(sources.items()):
            assert path.is_file() and not path.is_symlink()
            raw = path.read_bytes()
            item = tarfile.TarInfo(name)
            item.mode, item.mtime, item.size = 0o644, 0, len(raw)
            archive.addfile(item, io.BytesIO(raw))
            members.append({'path': name, **pin(raw)})
    packed = lzma.compress(buffer.getvalue(), preset=6)
    with tarfile.open(fileobj=io.BytesIO(packed), mode='r:xz') as archive:
        entries = archive.getmembers()
        assert len(entries) == len(sources) and {entry.name for entry in entries} == set(sources)
        for entry in entries:
            assert entry.isfile() and archive.extractfile(entry).read() == sources[entry.name].read_bytes()
    OUTPUT.mkdir(exist_ok=False)
    create(OUTPUT / 'D0F_WINDOWS_CURRENT_ORIGINAL_COMPLETE.tar.xz', packed)
    create(OUTPUT / 'MEMBER_MANIFEST.json', encoded(members))
    index = {
        'schema': 'mem-d0f-windows-current-complete-original-index-v1', 'archive': pin(packed), 'members': len(members),
        'original_run': audit['run_id'], 'original_job': audit['job_id'], 'attempt': 1,
        'source_head': audit['head'], 'source_tree': audit['tree'], 'job_conclusion': audit['job_conclusion'],
        'job_started_at': audit['job_started_at'], 'job_completed_at': audit['job_completed_at'],
        'original_zip': audit['archive'], 'original_zip_members': len(audit['members']), 'original_full_raw': audit['raw'],
        'declared_cases': 167, 'declared_groups': 19, 'completed_group_receipts': audit['completed_group_receipts'],
        'strict_passing_groups': audit['strict_passing_groups'], 'actual_terminal_counts': audit['terminal_counts'],
        'actual_distinct_terminal_case_count': audit['terminal_distinct_original_case_ids'],
        'unobserved_terminal_case_count': audit['no_observed_terminal_case_count'],
        'qualification_boundary': classification['whole_scope_qualification'], 'source_after': audit['source_after_observation'],
        'helper_pe_binary_bytes_archived': False, 'physical_network_requests': None,
        'source_refs_changed': False, 'native_model_or_host_requests_started_by_auditor': 0,
        'all_local_members_full_byte_readback': True, 'publication_state': 'NOT_YET_UPLOADED',
        'replay': replay['command'],
    }
    create(OUTPUT / 'ARCHIVE_INDEX.json', encoded(index))
    print(json.dumps(index, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
