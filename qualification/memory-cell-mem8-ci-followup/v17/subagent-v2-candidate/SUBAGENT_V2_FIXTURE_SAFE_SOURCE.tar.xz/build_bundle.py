"""Create an immutable safe source/diagnosis package; never execute source files."""
import difflib
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "mem-subagent-matcher-route-c895-readonly"


def pin(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}


def main():
    name = "codex-rs/core/tests/suite/subagent_notifications.rs"
    files = {path.relative_to(SOURCE).as_posix(): path.read_bytes() for path in (SOURCE / "source").rglob("*") if path.is_file()}
    selected = ["candidate/" + name, "CANDIDATE.patch", "CANDIDATE_MANIFEST.json", "DIAGNOSIS.json", "ORIGINAL_SAFE_PROJECTION.json", "ROUTE_SOURCE_INDEX.json", "TESTED_MERGE_COMMIT_READBACK.json", "POSTIMAGE_PUBLICATION.json", "MEM_CI_INDEPENDENT_PEER_REVIEW.json", "revision2/candidate/" + name, "revision2/CANDIDATE.patch", "revision2/CANDIDATE_MANIFEST.json", "revision2/REVISION1_TO_REVISION2.patch", "revision2/MEM_CI_INCREMENTAL_PEER_REVIEW.json", "revision2/POSTIMAGE_PUBLICATION.json"]
    for path in selected:
        files[path] = (SOURCE / path).read_bytes()
    pre = files["source/" + name]
    first = files["candidate/" + name]
    final = files["revision2/candidate/" + name]
    manifest = json.loads(files["CANDIDATE_MANIFEST.json"])
    revision = json.loads(files["revision2/CANDIDATE_MANIFEST.json"])
    assert pin(pre) == manifest["before"] == revision["before"]
    assert pin(first) == manifest["after"] == revision["revision1_postimage"]
    assert pin(final) == revision["after"]
    inverse = final.decode().replace(revision["revision2_comment_edit"]["new"], revision["revision2_comment_edit"]["old"])
    assert inverse.encode() == first
    for case in sorted({row["case"] for row in manifest["edits"]}):
        start = inverse.index("async fn " + case + "(")
        end = inverse.find("\nasync fn ", start + 1)
        end = len(inverse) if end == -1 else end
        body = inverse[start:end]
        for row in reversed([row for row in manifest["edits"] if row["case"] == case]):
            assert body.count(row["new"]) == 1
            body = body.replace(row["new"], row["old"])
        inverse = inverse[:start] + body + inverse[end:]
    assert inverse.encode() == pre
    full = "".join(difflib.unified_diff(pre.decode().splitlines(True), final.decode().splitlines(True), fromfile="a/" + name, tofile="b/" + name)).encode()
    assert full == files["revision2/CANDIDATE.patch"]
    projection = json.loads(files["ORIGINAL_SAFE_PROJECTION.json"])
    assert projection["raw_prompts_or_world_state_copied"] is False
    assert projection["physical_requests_replayed"] is False
    assert not any("job-" in path and path.endswith(".log") for path in files)
    files["PACKAGE_SCOPE.json"] = (json.dumps({"schema": "mem8.subagent-v2-fixture.safe-source-package.v1", "scope": "Original exact source, V1 historical candidate, final V2 with comment-only erratum, primary route sources, safe original-log projection and static peers. No native result.", "base_head": "c89540598693697577cda8cba31cb07f6ce65317", "base_tree": "5a7c897a33e4eef48ea8f4bf52eaf48ea7c866ae", "original_raw_log_included": False, "original_raw_log_reference": {key: projection[key] for key in ("original_file_bytes", "original_file_sha256", "original_job")}, "final_candidate": pin(final), "original_full_file_inverse_and_exact_patch_verified": True, "source_fmt_or_native_started_by_packager": 0, "real_model_requests_started_by_packager": 0, "refs_changed": False}, indent=2, sort_keys=True) + "\n").encode()
    files["build_bundle.py"] = Path(__file__).read_bytes()
    members = [{"path": path, **pin(raw)} for path, raw in sorted(files.items())]
    metadata = {"schema": "mem8.subagent-v2-fixture.member-manifest.v1", "member_count": len(members), "members": members}
    with (HERE / "MEMBER_MANIFEST.json").open("x") as stream:
        json.dump(metadata, stream, indent=2, sort_keys=True)
        stream.write("\n")
    output = HERE / "SUBAGENT_V2_FIXTURE_SAFE_SOURCE.tar.xz"
    with output.open("xb") as stream:
        with tarfile.open(fileobj=stream, mode="w:xz", preset=6) as archive:
            for path, raw in sorted(files.items()):
                entry = tarfile.TarInfo(path)
                entry.size, entry.mode, entry.mtime = len(raw), 0o600, 0
                archive.addfile(entry, io.BytesIO(raw))
    with tarfile.open(output, "r:xz") as archive:
        found = archive.getmembers()
        assert len(found) == len(files) and {entry.name for entry in found} == set(files)
        for entry in found:
            assert entry.isfile() and archive.extractfile(entry).read() == files[entry.name]
    audit = {"schema": "mem8.subagent-v2-fixture.local-bundle-audit.v1", "archive": {"path": output.name, **pin(output.read_bytes())}, "member_count": len(files), "every_member_full_bytes_equal": True, "final_source_inverse_full_original_equal": True, "full_patch_recomputed_equal": True, "raw_prompts_or_world_state_included": False, "refs_or_runs_changed": False, "native_result": "NOT_EXECUTED"}
    with (HERE / "LOCAL_AUDIT.json").open("x") as stream:
        json.dump(audit, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps(audit))


if __name__ == "__main__":
    main()
