#!/usr/bin/env python3
"""Bind existing H observations without contacting a host or replaying any operation."""
from __future__ import annotations

import base64
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/scratch/ed3538174819')
OUT = Path(__file__).resolve().parent


def pin(path: Path) -> dict:
    data = path.read_bytes()
    return {
        'path': str(path.relative_to(ROOT)),
        'bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(),
        'git_blob_computed': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
    }


def write_new(name: str, value: dict) -> None:
    data = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
    with (OUT / name).open('xb') as stream:
        stream.write(data)


owner_path = ROOT / 'mem8-owner-v10-root/BLOCKERS_FINAL.json'
publication_path = ROOT / 'mem8-owner-v10-root/ACTUAL_PUBLICATION.json'
upload_path = ROOT / 'mem8-reset-recovery/repair-v4-all-upload-observations.json'
page_path = ROOT / 'mem8-ci-followup-v16/original-h-readonly/OBSERVATION.json'
safe_path = ROOT / 'mem8-ci-followup-v16/original-h-readonly/SAFE_OBSERVATION.json'
owner = json.loads(owner_path.read_bytes())
publication = json.loads(publication_path.read_bytes())
upload = json.loads(upload_path.read_bytes())
page_record = json.loads(page_path.read_bytes())
safe_record = json.loads(safe_path.read_bytes())
file_info = json.loads((OUT / 'V4_FILE_INFO_OBSERVATION.json').read_bytes())
continuation = json.loads((OUT / 'PROCESS_REGISTRY_CONTINUATION_OBSERVATION.json').read_bytes())
contracts = json.loads((OUT / 'EXPOSED_TOOL_CONTRACTS.json').read_bytes())

old_v3 = owner['source_preparation_followup_v5']['original_v3']
old_v4 = owner['source_preparation_followup_v5']['original_v4']
assert old_v3['key'] == 'mem8-integrated-repair-source-ai395-ed353817-v3'
assert old_v3['admission'] == old_v3['terminal'] == 'UNKNOWN'
assert old_v4['source_process_start_requests'] == old_v4['CI_admissions'] == 0
assert old_v4['host_file_upload_effects'] == 'UNKNOWN'
assert publication['after']['head'] == 'f86dfb058edd6e489671e99baf7643a58e7eed35'
owner_pin = pin(owner_path)
assert owner_pin['git_blob_computed'] == '2d5f0256776089b386f8e5ebd9d9eefcbfaac5f2'

binary_request = upload['binary_write']['request']
chunk_request = upload['chunk_upload']['request']
data = base64.b64decode(binary_request['data_base64'], validate=True)
chunk = base64.b64decode(chunk_request['data_base64'], validate=True)
assert len(data) == chunk_request['size'] == old_v4['input_bytes'] == 328808
assert hashlib.sha256(data).hexdigest() == chunk_request['sha256'] == old_v4['input_sha256']
assert chunk == data[:12288]
assert chunk_request['upload_id'] == '58d82c85-983c-4f9e-8ad2-33aa0464c3da'
assert chunk_request['offset'] == 0
assert chunk_request['expected_version'] == binary_request['expected_version'] == 'absent'
assert upload['chunk_upload']['chunk_requests'] == 1
assert upload['chunk_upload']['commit_requests'] == 0
assert upload['driver_upload_requests'] == upload['source_process_start_requests'] == 0
destination = {'host': binary_request['host'], 'path': binary_request['path']}
assert destination == file_info['request']
assert destination == {k: chunk_request[k] for k in ('host', 'path')}
assert destination == {'host': 'ai395', 'path': '/home/qq/mem8-integrated-repair-source-input-ed353817-v4.json.xz'}
assert file_info['response']['isError'] is True
assert file_info['response']['structuredContent']['error_code'] == 'INVALID_ARGUMENT'
assert 'FileNotFoundError' in file_info['response']['content'][0]['text']

page = page_record['process_registry_first_page']
assert page['total'] == 7647 and len(page['jobs']) == 128
assert page['inventory_complete'] is False
assert page['snapshot_sha256'] == safe_record['process_registry_observation']['snapshot_sha256']
assert set().union(*(set(row) for row in page['jobs'])) == {'created_unix_ms', 'execution_mode', 'host', 'id', 'launch_state'}
assert continuation['request'] == {'host': 'ai395', 'limit': 128, 'cursor': page['next_cursor']}
assert continuation['result']['isError'] is True
assert continuation['result']['structuredContent']['error_code'] == 'INVALID_ARGUMENT'
assert continuation['result']['content'][0]['text'] == 'inventory snapshot unavailable, expired or invalidated; restart from the first page'

contract_by_name = {row['name']: row['description'] for row in contracts['contracts']}
assert 'action: "chunk" | "commit" | "abort"' in contract_by_name['mcp__codex_apps__h_binary_upload']
assert 'operation_id: string' in contract_by_name['mcp__codex_apps__h_operation_status']

identities = {
    'schema': 'mem8.h-original-identity.safe-original-bindings.v1',
    'owner_ledger': {
        'repository': publication['repository'],
        'commit': publication['after']['head'],
        'tree': publication['after']['tree'],
        'path': 'qualification/memory-cell-mem8-owner/run-001/BLOCKERS.json',
        **owner_pin,
    },
    'original_v3': {
        **old_v3,
        'host': 'ai395',
        'host_binding_basis': 'Original request key and parent-provided original request context; the observed retained registry was filtered to configured host ai395.',
        'known_job_id': None,
        'known_operation_id': None,
        'job_identity_found_in_inspected_material': False,
    },
    'original_v4': {
        **old_v4,
        'destination': destination,
        'expected_version': 'absent',
        'upload_id': chunk_request['upload_id'],
        'chunk_offset': 0,
        'chunk_bytes': len(chunk),
        'chunk_sha256': hashlib.sha256(chunk).hexdigest(),
        'chunk_equals_first_12288_bytes_of_verified_original_input': True,
        'original_chunk_requests': 1,
        'original_chunk_commit_requests': 0,
        'original_driver_upload_requests': 0,
        'async_file_info_key': upload['async_file_info']['request']['idempotency_key'],
        'known_async_operation_id': None,
        'binary_write_and_chunk_acknowledgments': 'MCP_TIMEOUT; no authenticated write outcome received',
    },
    'original_preparation_archive_reference': {
        'publication_blob': 'bbecfb912ba74432493a8d851140d3b61aa9542d',
        'member_manifest_blob': '719c8b6e758a4b9634d280945ac03d6b20eda14f',
        'whole_archive_sha256': '1d96a60b0d5e7bec25a80f97d3a8ed128df9e3c2f6c5a6fcd9738d8e301a2284',
        'scope': 'Previously root-verified immutable preparation archive, not re-downloaded in this read-only follow-up.',
    },
}
# Keep the repository path separate from its current local evidence path.
identities['owner_ledger']['repository_path'] = 'qualification/memory-cell-mem8-owner/run-001/BLOCKERS.json'
write_new('ORIGINAL_IDENTITIES.json', identities)

projection = {
    'schema': 'mem8.h-original-identity.original-registry-coverage.v1',
    'original_observed_at': page_record['observed_at'],
    'snapshot_sha256': page['snapshot_sha256'],
    'next_cursor_used': page['next_cursor'],
    'total_reported': page['total'],
    'original_rows_inspected': len(page['jobs']),
    'additional_rows_from_current_continuation': 0,
    'total_rows_covered': len(page['jobs']),
    'rows_not_covered': page['total'] - len(page['jobs']),
    'inventory_complete': False,
    'source_first_page_pin': pin(page_path),
    'jobs_canonical_json_sha256': hashlib.sha256(json.dumps(page['jobs'], sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
    'observed_metadata_fields': sorted(set().union(*(set(row) for row in page['jobs']))),
    'request_key_or_command_field_present': False,
    'original_target_matches': [],
    'target_match_interpretation': 'No identity-bound match is available from the inspected fields. This is not a whole-inventory absence result.',
    'other_job_identifiers_or_commands_published': False,
    'continuation_result': 'SNAPSHOT_UNAVAILABLE_EXPIRED_OR_INVALIDATED',
    'fresh_first_page_requested_in_this_followup': False,
}
write_new('REGISTRY_COVERAGE.json', projection)

sources = [owner_path, publication_path, upload_path, page_path, safe_path]
write_new('SOURCE_PINS.json', {
    'schema': 'mem8.h-original-identity.local-source-pins.v1',
    'inputs': [pin(p) for p in sources],
    'serialization_limit': 'The reset-recovery upload-observations file is the retained lossless store-object serialization. Its current 458117-byte pin does not claim equality to an earlier differently serialized local file.',
    'privacy_limit': 'The full original registry first page is intentionally not copied: it contains unrelated job identities. Only its file hash, coverage, fields and target-relevant cursor are retained here.',
    'original_upload_payload': 'Decoded locally and verified against the original length/full SHA256; no base64 source payload is duplicated in this follow-up package.',
})
with (OUT / 'PRIOR_SAFE_OBSERVATION.json').open('xb') as stream:
    stream.write(safe_path.read_bytes())

report = {
    'schema': 'mem8.h-original-identity.readonly-settlement-audit.v1',
    'generated_at_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'One read of the exact original V4 destination plus one continuation of the exact original 7647-entry registry snapshot; no operation re-admitted or replayed.',
    'status': 'READONLY_FOLLOWUP_COMPLETED_ORIGINAL_REQUEST_SETTLEMENT_NOT_CONFIRMED',
    'original_v3': {
        'key': old_v3['key'],
        'host': 'ai395',
        'admission': 'UNKNOWN',
        'terminal': 'UNKNOWN',
        'known_job_id': None,
        'why_status_or_stdout_not_requested': 'No original job_id was found in the inspected identity-bound evidence. The retained page exposes no request key or command, and the original continuation was refused. No unrelated jobs were probed.',
    },
    'original_v4': {
        'destination': destination,
        'upload_id': chunk_request['upload_id'],
        'latest_destination_observation': 'FileNotFoundError',
        'latest_observation_clock_after_response_utc': file_info['observation_clock_after_response_utc'],
        'upload_effects': 'UNKNOWN',
        'late_write_excluded': False,
        'staged_chunk_absence_proven': False,
        'async_file_info_operation_id': None,
        'why_operation_status_not_requested': 'The original initial and same-key operation_start calls timed out without returning an operation_id. The read-only status interface requires that immutable ID.',
        'why_upload_not_queried': 'The exposed binary_upload actions are chunk, commit and abort; no read-only upload-status action is available. Commit or abort would mutate/replay the original upload and was not invoked.',
    },
    'registry': projection,
    'new_calls': {
        'h_file_info': 1,
        'h_process_list_page_continuation': 1,
        'h_process_list_page_new_snapshot': 0,
        'h_process_status': 0,
        'h_process_read': 0,
        'h_operation_status': 0,
        'host_mutations': 0,
        'starts': 0,
        'cancels_or_signals': 0,
        'uploads_chunks_commits_aborts': 0,
        'model_requests': 0,
        'CI_or_native_runs': 0,
    },
    'next_readonly_evidence_needed': [
        'An authenticated original V3 job_id or immutable operation binding, allowing exact-host status/read without probing unrelated jobs.',
        'An authenticated original V4 upload receipt/status binding or immutable operation_id. The current upload interface has no read-only query by upload_id.',
        'A new registry snapshot, if separately authorized, would be a new observation and must not be represented as completion of the expired snapshot; the current metadata fields alone still do not expose request keys.',
    ],
    'unchanged_boundaries': [
        'The original V3 admission and terminal remain UNKNOWN; an incomplete/expired metadata snapshot is not proof of nonexecution.',
        'Destination absence at a read is not settlement of an earlier timed-out upload and does not exclude a late write.',
        'V4 historical source process_start requests remain zero; file upload effects remain separately UNKNOWN.',
        'No change to any owner, service, permission, key, CI run, source ref, provider turn or adoption gate.',
    ],
    'evidence_files': [
        'ORIGINAL_IDENTITIES.json', 'REGISTRY_COVERAGE.json', 'SOURCE_PINS.json',
        'PRIOR_SAFE_OBSERVATION.json', 'V4_FILE_INFO_OBSERVATION.json',
        'PROCESS_REGISTRY_CONTINUATION_OBSERVATION.json', 'EXPOSED_TOOL_CONTRACTS.json',
    ],
}
write_new('READONLY_SETTLEMENT_AUDIT.json', report)
print(json.dumps({'status': report['status'], 'report': pin(OUT / 'READONLY_SETTLEMENT_AUDIT.json'), 'coverage': [128, 7647], 'host_read_calls': 2, 'host_mutations': 0}, indent=2))
