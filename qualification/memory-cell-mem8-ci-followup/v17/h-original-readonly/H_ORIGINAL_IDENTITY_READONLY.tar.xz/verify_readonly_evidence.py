#!/usr/bin/env python3
"""Offline consistency check only. Does not contact H, GitHub, or any process."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


def main(directory: Path) -> dict:
    manifest = json.loads((directory / 'MANIFEST.json').read_bytes())
    for row in manifest['files']:
        relative = Path(row['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        path = directory / relative
        assert path.is_file() and not path.is_symlink(), row['path']
        data = path.read_bytes()
        assert len(data) == row['bytes'], row['path']
        assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['git_blob_computed'], row['path']

    def read(name: str) -> dict:
        return json.loads((directory / name).read_bytes())

    audit = read('READONLY_SETTLEMENT_AUDIT.json')
    identities = read('ORIGINAL_IDENTITIES.json')
    coverage = read('REGISTRY_COVERAGE.json')
    prior = read('PRIOR_SAFE_OBSERVATION.json')
    destination_read = read('V4_FILE_INFO_OBSERVATION.json')
    continuation = read('PROCESS_REGISTRY_CONTINUATION_OBSERVATION.json')
    contracts = {r['name']: r['description'] for r in read('EXPOSED_TOOL_CONTRACTS.json')['contracts']}
    owner = read('ORIGINAL_OWNER_FIELDS_PROJECTION.json')
    uploads = read('ORIGINAL_UPLOAD_METADATA_PROJECTION.json')
    assert identities['owner_ledger']['commit'] == owner['source']['commit'] == 'f86dfb058edd6e489671e99baf7643a58e7eed35'
    assert identities['owner_ledger']['git_blob_computed'] == owner['source']['git_blob'] == '2d5f0256776089b386f8e5ebd9d9eefcbfaac5f2'
    key = 'mem8-integrated-repair-source-ai395-ed353817-v3'
    assert identities['original_v3']['key'] == owner['original_v3']['key'] == audit['original_v3']['key'] == prior['original_v3_key'] == key
    for row in [identities['original_v3'], owner['original_v3'], audit['original_v3']]:
        assert row['admission'] == row['terminal'] == 'UNKNOWN'
    assert identities['original_v3']['known_job_id'] is audit['original_v3']['known_job_id'] is None
    assert identities['original_v3']['known_operation_id'] is None

    destination = {'host': 'ai395', 'path': '/home/qq/mem8-integrated-repair-source-input-ed353817-v4.json.xz'}
    assert destination_read['request'] == identities['original_v4']['destination'] == audit['original_v4']['destination'] == destination
    assert destination_read['response']['isError'] is True
    assert destination_read['response']['structuredContent']['error_code'] == 'INVALID_ARGUMENT'
    assert 'FileNotFoundError' in destination_read['response']['content'][0]['text']
    original_request = uploads['projection']['chunk_upload']['request']
    assert original_request['upload_id'] == identities['original_v4']['upload_id'] == audit['original_v4']['upload_id'] == '58d82c85-983c-4f9e-8ad2-33aa0464c3da'
    assert original_request['offset'] == 0 and original_request['size'] == 328808
    assert original_request['sha256'] == owner['original_v4']['input_sha256'] == '320e3ee8ac8dc90a25f3b85ef0ceda7c1fe8af8fb27446ebc73e0afb1aae3938'
    assert uploads['projection']['chunk_upload']['chunk_requests'] == 1
    assert uploads['projection']['chunk_upload']['commit_requests'] == 0
    assert owner['original_v4']['source_process_start_requests'] == owner['original_v4']['CI_admissions'] == 0
    assert audit['original_v4']['upload_effects'] == owner['original_v4']['host_file_upload_effects'] == 'UNKNOWN'
    assert identities['original_v4']['known_async_operation_id'] is audit['original_v4']['async_file_info_operation_id'] is None
    assert 'action: "chunk" | "commit" | "abort"' in contracts['mcp__codex_apps__h_binary_upload']
    assert 'operation_id: string' in contracts['mcp__codex_apps__h_operation_status']

    assert coverage['snapshot_sha256'] == prior['process_registry_observation']['snapshot_sha256'] == '6b8603cef841ffd2c87d0f7b7b5aa64f5d80453875f6ce2b2a1480a00813cc92'
    assert coverage['total_reported'] == prior['process_registry_observation']['total_reported'] == 7647
    assert coverage['original_rows_inspected'] == prior['process_registry_observation']['metadata_rows_read'] == 128
    assert coverage['additional_rows_from_current_continuation'] == 0
    assert coverage['total_rows_covered'] == 128 and coverage['rows_not_covered'] == 7519
    assert coverage['inventory_complete'] is prior['process_registry_observation']['inventory_complete'] is False
    assert coverage['original_target_matches'] == []
    assert coverage['request_key_or_command_field_present'] is False
    assert coverage['other_job_identifiers_or_commands_published'] is False
    assert continuation['request'] == {'host': 'ai395', 'limit': 128, 'cursor': coverage['next_cursor_used']}
    assert continuation['result']['isError'] is True
    assert continuation['result']['structuredContent']['error_code'] == 'INVALID_ARGUMENT'
    assert continuation['result']['content'][0]['text'] == 'inventory snapshot unavailable, expired or invalidated; restart from the first page'
    assert audit['registry'] == coverage
    assert audit['new_calls'] == {
        'h_file_info': 1, 'h_process_list_page_continuation': 1,
        'h_process_list_page_new_snapshot': 0, 'h_process_status': 0,
        'h_process_read': 0, 'h_operation_status': 0, 'host_mutations': 0,
        'starts': 0, 'cancels_or_signals': 0, 'uploads_chunks_commits_aborts': 0,
        'model_requests': 0, 'CI_or_native_runs': 0,
    }
    return {
        'schema': 'mem8.h-original-identity.offline-consistency-audit.v1',
        'status': 'OFFLINE_EVIDENCE_CONSISTENT_ORIGINAL_SETTLEMENT_UNKNOWN',
        'files_verified': len(manifest['files']),
        'exact_original_destination_reads': 1,
        'exact_original_snapshot_continuations': 1,
        'coverage': {'read': 128, 'total': 7647, 'complete': False},
        'original_v3_admission': 'UNKNOWN',
        'original_v3_terminal': 'UNKNOWN',
        'original_v4_upload_effects': 'UNKNOWN',
        'host_mutations': 0,
        'limits': [
            'This reader verifies the retained observation bytes and their internal bindings; it does not independently authenticate the remote server history.',
            'Full unrelated registry job metadata is deliberately excluded. Its original file and row-set hashes remain references, not a completed inventory.',
            'Original payload/owner projections are linked to fixed original evidence hashes and previously published objects; this compact package does not replace those original archives.',
        ],
    }


if __name__ == '__main__':
    print(json.dumps(main(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent), ensure_ascii=False, indent=2))
