from pathlib import Path
import hashlib
import io
import json
import lzma
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent

def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}

def create(path, raw):
    with path.open("xb") as stream:
        stream.write(raw)

command = [sys.executable, str(ROOT / "verify_supplement.py"),
    "--original-review", str(WORK / "mem-elevated-delete-9bd2-followup-readonly/ELEVATED_CAPABILITY_CLOSURE_REVIEW.tar.xz"),
    "--v10-original", str(WORK / "mem8-source-v10-original-run/publication/V10_COMPLETE_ORIGINAL_SOURCE_GATE.tar.xz"),
    "--five-original", str(WORK / "mem-native-five-c895-original-run/publication/FIVE_NATIVE_ORIGINAL_COMPLETE.tar.xz")]
run = subprocess.run(command, capture_output=True, timeout=30)
create(ROOT / "LOCAL_REPLAY_AUDIT.json", run.stdout)
create(ROOT / "LOCAL_REPLAY_AUDIT.stderr", run.stderr)
assert run.returncode == 0 and not run.stderr
report = json.loads(run.stdout)
assert report["result"] == "PASS_READ_ONLY_BYTE_AND_BINDING_REPLAY"
receipt = {"command": command, "actual_exit_code": run.returncode,
    "stdout": identity(run.stdout), "stderr": identity(run.stderr),
    "reader": identity((ROOT / "verify_supplement.py").read_bytes()),
    "meaning": "Offline evidence verification only; no permission repair, native test, model or host execution."}
create(ROOT / "LOCAL_REPLAY_EXECUTION.json", (json.dumps(receipt, indent=2) + "\n").encode())
paths = sorted(path for path in ROOT.iterdir() if path.is_file())
rows = [{"path": path.name, **identity(path.read_bytes())} for path in paths]
create(ROOT / "MEMBER_MANIFEST.json", (json.dumps({"schema": "mem.elevated-peer-thin-package.v1", "members": rows}, indent=2) + "\n").encode())
paths.append(ROOT / "MEMBER_MANIFEST.json")
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode="w", format=tarfile.PAX_FORMAT) as archive:
    for path in sorted(paths):
        payload = path.read_bytes()
        item = tarfile.TarInfo(path.name)
        item.size = len(payload)
        item.mode = 0o644
        item.mtime = 0
        archive.addfile(item, io.BytesIO(payload))
packed = lzma.compress(raw.getvalue(), preset=6)
with tarfile.open(fileobj=io.BytesIO(packed), mode="r:xz") as archive:
    assert {member.name for member in archive.getmembers()} == {path.name for path in paths}
    for member in archive.getmembers():
        assert member.isfile() and archive.extractfile(member).read() == (ROOT / member.name).read_bytes()
output = ROOT / "publication"
output.mkdir(exist_ok=False)
create(output / "ELEVATED_DELETE_PEER_SUPPLEMENT.tar.xz", packed)
index = {"schema": "mem.elevated-peer-supplement-archive.v1", "archive": identity(packed), "members": len(paths), "manifest_rows": len(rows),
    "complete_original_sources_and_logs_recovered_by_fixed_references": True,
    "duplicate_original_logs_in_this_archive": False,
    "original_source_count": 23, "original_review_archive_git_blob": "14faadee966c4db19f2c4a60cc70535d20aadae4",
    "peer_actual_git_blob": "87cca48879f83c6a9c0c282957b0d22a927c54c9",
    "local_full_archive_member_readback": True, "offline_reader_exit_code": 0,
    "new_permission_source_candidate": False, "native_tests_or_models_started": 0, "source_or_ref_changes": 0,
    "publication": "NOT_YET_CREATED"}
create(output / "ARCHIVE_INDEX.json", (json.dumps(index, indent=2) + "\n").encode())
print(json.dumps(index, indent=2))
