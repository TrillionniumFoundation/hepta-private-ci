from pathlib import Path
import datetime
import difflib
import hashlib
import json
import re
import struct

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent

def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}

index = json.loads((ROOT / "SOURCE_INDEX.json").read_text())
for row in index["files"]:
    assert identity(ROOT / "source" / row["path"]) == {k: row[k] for k in ("bytes", "sha256", "git_blob")}

tree_path = WORK / "mem8-source-v10-original-run/readback/canonical-original/records/CANDIDATE_TREE.ls-tree"
tree = {}
for entry in tree_path.read_bytes().split(b"\0"):
    if entry:
        header, path = entry.split(b"\t", 1)
        mode, kind, sha = header.decode().split()
        tree[path.decode()] = {"mode": mode, "kind": kind, "git_blob": sha}
assert len(tree) == 14053
current = []
for row in index["files"]:
    now = tree[row["path"]]["git_blob"]
    current.append({"path": row["path"], "reviewed_9bd2_blob": row["git_blob"], "current_d0f_blob": now, "same_blob": now == row["git_blob"]})
assert sum(row["same_blob"] for row in current) == 19

post = WORK / "mem8-source-v10-original-run/readback/canonical-original/records/post-format"
source = ROOT / "source"
changed_production = {}
for rel in ("codex-rs/windows-sandbox-rs/src/setup.rs", "codex-rs/windows-sandbox-rs/src/elevated_impl.rs"):
    assert identity(post / rel)["git_blob"] == tree[rel]["git_blob"]
    before, after = (source / rel).read_text(), (post / rel).read_text()
    changed_production[rel] = {"current_identity": identity(post / rel), "full_diff": "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="9bd2/" + rel, tofile="d0f/" + rel))}
old_setup = (source / "codex-rs/windows-sandbox-rs/src/setup.rs").read_text()
new_setup = (post / "codex-rs/windows-sandbox-rs/src/setup.rs").read_text()
for start, end in (("fn gather_full_read_roots_for_permissions(", "pub(crate) fn gather_write_roots_for_permissions("), ("fn run_setup_refresh_inner(", "fn run_setup_refresh_payload("), ("pub struct SetupMarker {", "impl SetupMarker {")):
    assert old_setup[old_setup.index(start):old_setup.index(end)] == new_setup[new_setup.index(start):new_setup.index(end)]

raw = (ROOT / "sandbox-native-delete-routes.log").read_bytes()
assert len(raw) == 27138
assert hashlib.sha256(raw).hexdigest() == "0f4357942bd12783593f3d0a817d97db7ac3d26395a0bee30f5951ac5672976a"
lines = raw.decode().splitlines()
prior_acl = json.loads((ROOT / "CURRENT_ORIGINAL_ACL_AUDIT.json").read_text())
decoded = []
for line_number in range(220, 232):
    line = lines[line_number - 1]
    assert "delete_matrix elevated-child-done path=" in line
    blob = bytes(int(v.strip(), 16) for v in line.split("acl=[", 1)[1].rstrip("]").split(","))
    revision, _, size, count, _ = struct.unpack_from("<BBHHH", blob)
    assert revision == 2 and size == len(blob)
    offset, aces = 8, []
    for _ in range(count):
        kind, flags, ace_size = struct.unpack_from("<BBH", blob, offset)
        mask = struct.unpack_from("<I", blob, offset + 4)[0]
        sid = blob[offset + 8:offset + ace_size]
        sid_revision, sub_count = sid[:2]
        authority = int.from_bytes(sid[2:8], "big")
        assert len(sid) == 8 + 4 * sub_count
        subs = struct.unpack_from("<" + "I" * sub_count, sid, 8)
        sid_text = "S-" + str(sid_revision) + "-" + str(authority) + "".join("-" + str(x) for x in subs)
        assert kind in (0, 1) and sid_text == "S-1-1-0"
        aces.append({"type": "allow" if kind == 0 else "deny", "flags": flags, "mask": mask, "sid": sid_text})
        offset += ace_size
    assert offset == len(blob)
    expected = next(x for x in prior_acl["rows"] if x["line"] == line_number)
    assert aces == expected["aces"]
    assert hashlib.sha256(blob).hexdigest() == expected["acl_sha256"]
    decoded.append({"line": line_number, "acl_sha256": expected["acl_sha256"], "aces": aces})
outcomes = []
for route, file_deleted, directory_deleted in re.findall(r"DeleteOutcome \{ route: (\w+), file_deleted: (true|false), directory_deleted: (true|false) \}", lines[231]):
    outcomes.append({"route": route, "file_deleted": file_deleted == "true", "directory_deleted": directory_deleted == "true"})
assert outcomes == [{"route": r, "file_deleted": r != "Neither", "directory_deleted": r != "Neither"} for r in ("Neither", "TargetOnly", "ParentOnly", "Both")]

def evidence(path, lines):
    row = next(row for row in index["files"] if row["path"].endswith(path))
    return {"path": row["path"], "git_blob": row["git_blob"], "lines": lines}

report = {
    "schema": "mem.elevated-contract-independent-peer.v1",
    "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "reviewer": "/root/mem_experiment_review",
    "reviewed_source": {"head": index["head"], "tree": index["tree"], "complete_files_bytes_sha256_git_blob_verified": 23},
    "reviewed_reports": {name: identity(ROOT / name) for name in ("PRODUCT_REPAIR_FEASIBILITY.json", "REPORT.md", "SOURCE_INDEX.json", "CURRENT_ORIGINAL_ACL_AUDIT.json")},
    "result": "EXISTING_READ_CONTRACT_AND_INTERFACES_DO_NOT_YET_JUSTIFY_A_COMPLETE_FULL_RESTRICTION_REPAIR",
    "conclusion": "Typed role separation and an acknowledgement tied to the current setup request are necessary design changes, but the existing enumerated read-root list cannot by itself preserve the ambient/read-root contract after removing WRITE_RESTRICTED. No safely complete narrow source candidate is established by these 23 files. This is a concrete implementation and coverage gap, not a request to invent an owner, grant, credential, sample, or new acceptance threshold.",
    "original_failure_independently_rechecked": {
        "head": index["head"], "run_id": 43021840561, "job_id": 130526720080,
        "raw": identity(ROOT / "sandbox-native-delete-routes.log"),
        "elevated_after_release_line": 232, "outcomes": outcomes,
        "independent_acl_decode": decoded,
        "original_actual_child_token_dump": "NOT_OBSERVED",
        "causal_boundary": "The repeated outside deletion and broad Everyone ACEs are observed. Which access-check path and actual child token fields authorized each operation were not captured; do not uniquely attribute them to a new proposed token or treat parent-process token diagnostics as the child token."
    },
    "minimal_required_cross_module_changes": [
        {
            "area": "Represent the full authorized read contract before materializing grants",
            "source": [evidence("resolved_permissions.rs", "106-129"), evidence("setup.rs", "556-611"), evidence("legacy_admission.rs", "1-6")],
            "fact": "The typed profile can express symbolic Root/readable roots. The full-read setup collector deliberately filters the ancestor filesystem root, then supplies existing helper/platform/profile/cwd/writable roots. canonical_existing drops missing paths. That list is an ACL refresh worklist, not an exhaustive proof of every ambient normal-token-readable object.",
            "change_needed": "Keep symbolic all-read versus explicit read roots distinct in a trusted grant plan, preserve deny-read semantics and missing/future-path behavior, and supply an implementable normal-read-equivalent rule for platform, volume, protected-inheritance and non-filesystem startup objects before selecting a fully restricted token.",
            "current_gap": "Neither an exhaustive materialization/verification interface nor an already authorized and completed broader host-ACL grant set is present. Narrowing to today's worklist would silently change reads; treating symbolic Root as an instruction to relax all host ACLs is not established by this review."
        },
        {
            "area": "Separate SID roles and current-request selection",
            "source": [evidence("cap.rs", "15-32,88-125"), evidence("spawn_prep.rs", "421-464"), evidence("elevated/ipc_framed.rs", "57-76"), evidence("bin/command_runner/win.rs", "234-287")],
            "fact": "Current write-root selection already omits stale root capabilities. SpawnRequest carries one cap_sids vector plus a network marker; runner validates syntax/nonempty and derives token mode from the profile, but no typed current-read-grant acknowledgement is represented.",
            "change_needed": "Derive read, write, child-object, desktop and network roles from the existing trusted profile/root inputs; carry or independently reconstruct the same request-bound plan through setup/parent/runner. Select only current roots and preserve the existing protocol-version and authentication boundary. A caller-provided SID or digest is not proof that its ACL grant succeeded.",
            "current_gap": "A reusable persisted readonly SID and a flat capability vector do not represent per-root read scope, withdrawal or role-specific rights. Role labels alone do not change the kernel's alternative-SID access check."
        },
        {
            "area": "Acknowledge actual required grants before child admission",
            "source": [evidence("setup.rs", "322-416,420-430"), evidence("bin/setup_main/win.rs", "166-181,189-259,792-841,1027-1035")],
            "fact": "The original parent can wait for the exact main helper and singleflight by payload, but the main helper detaches read grants. An existing read-helper mutex skips spawning the new payload. Existing builtin or sandbox-group readability skips an ACE write. Main helper exit/SetupMarker therefore cannot acknowledge current restricting-read-SID grants.",
            "change_needed": "For any new full-restriction mode, have the existing authorized setup path apply and verify each required role/mask for the same request and report completion through its retained process/channel before allowing spawn. Mutex contention must join or perform the exact needed work rather than count another payload as success. Preserve deny-read ordering and propagate errors; no unrestricted or stale-success fallback.",
            "current_gap": "No acknowledgement contains the required current roots, roles, masks or successful grant/readback state. Adding a wait alone is insufficient, and must consume the original caller/test envelope rather than add a new timeout or retry. Existing request timings do not establish that a new exhaustive grant operation fits."
        },
        {
            "area": "Keep read/network identities out of object and desktop write authority",
            "source": [evidence("token.rs", "55-75,455-543"), evidence("desktop.rs", "70-91,146-252")],
            "fact": "The default DACL grants GENERIC_ALL to every supplied capability SID. With Logon removed from the restricting set, the existing desktop selector copies every restricting SID and grants DESKTOP_ALL_ACCESS, including the route marker. private=false currently refuses that capability-only path.",
            "change_needed": "Pass a deliberately selected child-object/desktop capability set separately; do not append read SIDs to the old cap vector and do not infer desktop authority from all restricting SIDs. Preserve private=false refusal and the real private-desktop/WinSta0 launch contract, without forcing a different profile.",
            "current_gap": "Current constructor and desktop API only receive a token/flat vector, so there is no verified mapping that excludes read/network identities while retaining the exact authorized desktop/object principals."
        },
        {
            "area": "Retain the established write grants, denial and runtime boundaries",
            "source": [evidence("bin/setup_main/win.rs", "851-1004"), evidence("acl.rs", "343-347,494-501,800-844"), evidence("bin/command_runner/win.rs", "269-362"), evidence("process.rs", "1-320"), evidence("conpty/mod.rs", "1-190"), evidence("wfp.rs", "169-211,315-322")],
            "fact": "Active write-root capability grants and denial carveouts are reusable; existing IPC is established by the runner before child-token construction and stdio uses retained handles. Null-device access is explicitly granted to cap_sids. Network filtering uses a separate route marker but existing tests do not prove the final new token's ALE match.",
            "change_needed": "Retain original target/parent delete refusal, inside writes, denied reads, request authentication and inherited-handle isolation. Select the appropriate role for null/stdio/child-created objects and validate final-token read/startup/desktop/network behavior. Do not change WFP or normal token privileges solely to get the four-cell test green.",
            "current_gap": "These are dependencies of the same product contract, not authority supplied by the successful setup-handle lifecycle case. No new token has been executed, and no WFP or full-restriction compatibility success follows from this static peer."
        }
    ],
    "bounded_candidate_assessment": {
        "cap_only_with_write_restricted": "A narrower constructor could remove User/Logon/Everyone only from restricting identities while preserving normal identity reads. It is an independently reviewable partial tightening, but legacy_admission explicitly retains the separate parent FILE_DELETE_CHILD counterexample. Desktop role handling also needs repair. Do not present this as complete product qualification.",
        "full_restriction_with_existing_roots_only": "Not a valid complete candidate: it silently loses ambient/read-root behavior and has no completed current read grants.",
        "single_flag_or_test_bypass": "Rejected; not prepared.",
        "safe_next_code_scope": "First make a reviewable typed grant-plan and exact helper-ack design for the existing permission profile, including the symbolic-root/ambient-read case. Keep it unselected until coverage and authorization are explicit. The available sources do not establish a complete source-local production replacement that can now be safely enabled under unchanged reads and budgets.",
        "new_source_candidate_written": False
    },
    "current_d0f_comparison": {
        "head": "d0f6507e08f7f5c5855f5164d07c049a34d1a6d9", "tree": "658fa040046285116b1fd81b94ff8c96444072ad",
        "complete_tree_identity": identity(tree_path), "leaf_count": len(tree),
        "rows": current,
        "production_delta_full": changed_production,
        "unchanged_critical_setup_sections": ["gather_full_read_roots_for_permissions + gather_read_roots", "run_setup_refresh_inner payload construction", "SetupMarker fields"],
        "boundary": "19 of the 23 source blobs are identical. The two changed production files contain the separately reviewed setup handle-isolation launch and equivalent cancellation-method-pointer edits; complete diffs are retained above. The other two changed files are tests. This does not transfer any 9bd2 native result to d0f."
    },
    "historical_report_clarifications": [
        "The report's 'smallest complete alternative identified' is a proposed architectural direction with unresolved read-scope and grant-ack interfaces, not a proven complete or immediately runnable repair.",
        "The report's 'current LEAK' refers to the frozen 9bd2 original. A later source-c895 five-case run 43047914262 independently passed the original elevated env/output/exit case with 0 LEAK, while its whole job was interrupted during independent core lint. That lifecycle result does not repair or qualify the outside-delete boundary."
    ],
    "primary_api_contracts": [
        {"url": "https://learn.microsoft.com/en-us/windows/win32/api/securitybaseapi/nf-securitybaseapi-createrestrictedtoken", "use": "WRITE_RESTRICTED makes restricting-SID checks write-only; the ordinary full restricted-token contract requires enabled and restricting checks."},
        {"url": "https://learn.microsoft.com/en-us/windows/win32/secauthz/restricted-tokens", "use": "Restricting identities participate in a separate access check; desktop and other secured-object compatibility are part of the runtime boundary."}
    ],
    "actions": {"local_readonly_byte_and_acl_audit": True, "new_native_tests": 0, "new_host_requests": 0, "model_requests": 0, "source_or_ref_mutations": 0, "original_deadline_or_assertion_changes": 0}
}
out = ROOT / "MEM_EXPERIMENT_CONTRACT_PEER.json"
with out.open("x", encoding="utf-8") as f:
    json.dump(report, f, indent=2, ensure_ascii=False)
    f.write("\n")
print(json.dumps({"output": str(out), **identity(out), "source_files_verified": 23, "raw_acl_objects_verified": 12, "new_candidate": False}, indent=2))
