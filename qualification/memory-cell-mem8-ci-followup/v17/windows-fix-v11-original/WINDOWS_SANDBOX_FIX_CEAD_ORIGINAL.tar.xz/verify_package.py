"""Verify this complete original evidence package; rerun only its pinned offline reader."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
import tempfile


READER_SHA256 = "731ae6dbf1d1e37627c83d754a72a54f2573f69259ef7b158181871e33207c92"


def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}


def verify(path):
    raw = path.read_bytes()
    with tarfile.open(path, "r:xz") as archive:
        rows = archive.getmembers()
        names = [row.name for row in rows]
        assert len(names) == len(set(names))
        for row in rows:
            p = PurePosixPath(row.name)
            assert row.isfile() and str(p) == row.name and not p.is_absolute()
            assert ".." not in p.parts and "\\" not in row.name and ":" not in row.name
        contents = {row.name: archive.extractfile(row).read() for row in rows}
    manifest = json.loads(contents["PACKAGE_MANIFEST.json"])
    expected = {row["path"]: {k: row[k] for k in ("bytes", "sha256", "git_blob")} for row in manifest["files"]}
    assert len(expected) == len(manifest["files"])
    assert expected == {name: identity(data) for name, data in contents.items() if name != "PACKAGE_MANIFEST.json"}
    assert hashlib.sha256(contents["audit_original.py"]).hexdigest() == READER_SHA256
    with tempfile.TemporaryDirectory(prefix="mem-v11-lint-offline-") as directory:
        root = Path(directory)
        for name, data in contents.items():
            output = root / name
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(data)
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        result = subprocess.run([sys.executable, str(root / "audit_original.py"), str(root)],
                                capture_output=True, timeout=60, env=env)
        assert result.returncode == 0, result.stderr.decode(errors="replace")
        assert result.stderr == b"" and result.stdout == contents["OFFLINE_AUDIT.json"]
    audit = json.loads(result.stdout)
    assert audit["qualification_passed"] and audit["source_rewrite_paths"] == []
    return {"status": "PASS_COMPLETE_ORIGINAL_PACKAGE_AND_PINNED_READER_REPLAY",
            "archive": identity(raw), "members": len(contents), "original_ZIP": audit["artifact"],
            "full_offline_audit_bytes_equal": True, "source_head": audit["source_head"],
            "source_tree": audit["source_tree"], "run": audit["run_id"], "job": audit["job_id"],
            "attempt": 1, "native_test_commands": 0, "model_commands": 0,
            "archived_build_or_lint_commands_executed_by_verifier": 0}


if __name__ == "__main__":
    print(json.dumps(verify(Path(sys.argv[1])), indent=2, sort_keys=True))
