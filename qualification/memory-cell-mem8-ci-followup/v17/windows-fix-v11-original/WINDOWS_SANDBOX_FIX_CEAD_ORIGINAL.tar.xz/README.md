# Original V11 Windows sandbox scoped lint

The one admitted run `43072390230`, job `130703409994`, attempt `1`, completed successfully on source `ceadcb3b11dbd94a9d07afb7e6301555e4ff3f80` / tree `27651abb15e269c427c75f28f92a3bd1cd9d191f`. Its harness was `fe824cce50037071ff559e1aabdf36f9d5954908` / tree `ac382f3fc9989017ad77ed64e07b02e1e42cb5cc`.

The original job ran from 17:52:58 to 18:12:56 UTC on 2026-11-11, within its unchanged 65-minute budget. It first built the two real Windows sandbox helper executables, with exit code zero and 723.468 seconds recorded for that command. It then ran exactly `just fix --locked -p codex-windows-sandbox`, with exit code zero and 403.797 seconds recorded. Both phases were `passed_clean`: all before, immediate-after, after and collection source identities, both lockfiles, tool identities and observed helper identities matched. There were no source rewrite paths.

This package preserves the complete original 104,338-byte artifact ZIP, all 158 members through that ZIP, the complete original job log and tool response, full terminal API metadata, four exact harness inputs, the plan, original intent/result records through the ZIP, and the pre-terminal pinned offline auditor with its independent identity-only peer. The ZIP digest, CRC, complete member manifest, source and helper checks, and both actual command exit codes were verified by that auditor. `OFFLINE_AUDIT.json` is its unchanged output.

The helper PE files are not archived. Their actual compiler-artifact records and observed byte sizes and hashes are retained; this is not a claim of independently re-reading the complete PE files from the archive. The source checkout is shallow, so an empty recorded `parents` list describes that local checkout view, not the Git commit's ancestry. All twenty complete dependency source files, both complete tree inventories and the actual admission proofs are retained in the separately indexed V11 preparation package; `OFFLINE_REPLAY_INPUTS.json` identifies it exactly.

No native test command or model command ran in this job. Physical network request count remains unspecified because dependency-download traffic is outside that claim. This closes this source's Windows sandbox scoped-lint gate only. It does not turn the original V10 dirty-source failure into a pass, establish required CI acceptance for another head, repair Windows deletion permissions, or close a scientific, owner, cold-recovery or real-effect gate.

To replay the original evidence after safely extracting this package:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 audit_original.py .
```

`verify_package.py` also verifies every outer member and reruns only the pinned offline auditor in a temporary directory, comparing its full output bytes with the retained audit. Neither reader executes the archived build/lint commands or starts a workflow, host process, model or ref update.
