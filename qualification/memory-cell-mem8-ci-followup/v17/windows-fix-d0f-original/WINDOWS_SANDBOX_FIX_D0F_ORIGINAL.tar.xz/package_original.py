"""Package only complete original evidence and independent offline audit files."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent


def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def main():
    names = [
        "ACTUAL_ADMISSION.json", "FROZEN_PLAN.json", "RUN_DISCOVERY.json", "INITIAL_JOBS.json", "RUN_IDENTITY.json",
        "RUN_TERMINAL.json", "TERMINAL_JOBS.json", "JOB_LOG_TOOL_RESPONSE.json", "ARTIFACTS_TERMINAL.json", "ARTIFACT_METADATA.json",
        "original-job.log", "ORIGINAL_ARTIFACT.zip", "RUNNING_LOG_UNAVAILABLE.json", "audit_original.py", "OFFLINE_AUDIT.json",
        "MEM_EXPERIMENT_READER_PEER.json", "ACTUAL_CLIPPY.patch", "ACTUAL_CLIPPY_REVIEW.json", "MEM_EXPERIMENT_CLIPPY_PEER.json",
        "CLIPPY_POSTIMAGE_PUBLICATION.json", "README.md", "verify_package.py", "package_original.py",
        "source-before/codex-rs/windows-sandbox-rs/src/setup_process.rs", "clippy-postimages/codex-rs/windows-sandbox-rs/src/setup_process.rs",
        "harness/mem_windows_sandbox_fix.py", "harness/mem_windows_sandbox_fix_support.py",
        "harness/hepta-mem-windows-sandbox-fix.yml", "harness/mem-windows-sandbox-fix-plan.json",
    ]
    files = {}
    for name in sorted(names):
        path = ROOT / name
        assert path.is_file() and not path.is_symlink()
        files[name] = path.read_bytes()
    manifest = {"schema": "mem8.windows-sandbox-fix-d0f.original-package.v1", "members": [{"path": name, **identity(data)} for name, data in files.items()],
                "original_zip_members": 153, "original_qualification": "FAIL_DIRTY_SOURCE", "scope": "Whole original ZIP/raw/receipts and offline proof; no helper PE binaries or source checkout claimed."}
    files["PACKAGE_MANIFEST.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    (ROOT / "PACKAGE_MANIFEST.json").write_bytes(files["PACKAGE_MANIFEST.json"])
    archive = ROOT / "WINDOWS_SANDBOX_FIX_D0F_ORIGINAL.tar.xz"
    assert not archive.exists()
    with tarfile.open(archive, "w:xz", preset=6) as packed:
        for name, data in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            packed.addfile(info, io.BytesIO(data))
    assert archive.stat().st_size < 500000
    with tarfile.open(archive, "r:xz") as packed:
        assert len(packed.getmembers()) == len(files)
        for item in packed.getmembers():
            assert item.isfile() and packed.extractfile(item).read() == files[item.name]
    result = {"schema": "mem8.windows-sandbox-fix-d0f.original-archive.v1", "archive": {"path": archive.name, **identity(archive.read_bytes())}, "members": len(files),
              "original_artifact": identity(files["ORIGINAL_ARTIFACT.zip"]), "full_original_zip_members": 153,
              "full_local_member_readback_equal": True, "Git_binary_creation": "PENDING", "binary_remote_readback": "PENDING_ROOT_CARRIER", "refs_changed": False}
    (ROOT / "ARCHIVE_INDEX.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
