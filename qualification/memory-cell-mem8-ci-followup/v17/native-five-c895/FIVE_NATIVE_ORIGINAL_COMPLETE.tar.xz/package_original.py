"""Seal the settled original attempt and its independent read-only audit."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import io
import json
import lzma
import tarfile

ROOT = Path(__file__).resolve().parent

def ident(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}

def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()

def write(path, data):
    with path.open("xb") as stream:
        stream.write(data)

def main():
    audit = json.loads((ROOT / "readback/INDEPENDENT_AUDIT.json").read_text())
    files = ROOT / "readback/files"
    result = json.loads((files / "RESULT.json").read_text())
    collection = json.loads((files / "COLLECTION.json").read_text())
    phases = audit["phases"]
    assert audit["observed_status_counts"] == {"PASS": 5}
    assert len(audit["independently_qualified_native_cases"]) == 5
    assert audit["clean_scoped_fix_packages"] == ["core_test_support"]
    assert audit["qualification"] == "NOT_QUALIFIED_RETAIN_ORIGINAL_FAILURE_OR_UNKNOWN"
    report = {
        "schema": "mem-native-five-original-terminal-boundaries-v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "run_id": 43047914262, "job_id": 130616746852, "attempt": 1,
        "source_head": audit["source_head"], "source_tree": audit["source_tree"],
        "harness_head": audit["harness_head"],
        "api_job_conclusion": "cancelled", "original_driver_status": result["status"],
        "original_job_timeout_minutes": 65, "timeout_or_exit_not_extended": True,
        "native_cases": audit["observed_terminal_test_executions"],
        "native_passes_independently_bound_to_three_junit_uuids": audit["independently_qualified_native_cases"],
        "active_execution_status_counts": {"PASS": 5, "FAIL": 0, "LEAK": 0, "TIMEOUT": 0, "SKIP": 0},
        "unselected_filtered_counts_by_original_group": [36, 1098, 187],
        "filtered_counts_are_not_executed_cases": True,
        "original_junit": [phase["original_junit"] for phase in phases if phase.get("kind") == "native"],
        "source_and_integrity_boundary": {
            "all_three_native_phases_and_first_fix": "Complete same-source clean before/after plus identical actual tool, helper and lock fingerprints.",
            "second_fix": "Original command_exit_code remains null and after tool/helper/source receipt is absent. The job log reports cancellation and the raw subprocess log contains KeyboardInterrupt. This is an interrupted UNKNOWN exit, not a clean lint pass.",
            "collection": collection,
            "missing_whole_job_after_receipt": "The later collection independently observed the same clean source and locks; it does not manufacture settlement or after-tool/helper evidence for the interrupted second fix.",
            "auditor_false_integrity_checks": "Four false checks identify missing terminal/after evidence, not observed source, tool or helper drift."
        },
        "lint_status": {
            "core_test_support": "Actual exit 0 and clean before/after; independently qualified.",
            "codex-core": "Started with 72.181792 seconds left; original command exit UNKNOWN after cancellation; no pass.",
            "codex-windows-sandbox": "No intent, raw log or execution evidence; not run."
        },
        "actual_helper_bindings": audit["actual_helper_bindings"],
        "whole_job_qualification": audit["qualification"],
        "known_native_success_not_erased_by_later_lint_interruption": True,
        "later_combined_source_requires_its_own_qualification": True,
        "model_boundary": {"driver_issued_real_provider_requests": 0, "physical_network_requests": None,
                           "selected_cases": "Original local mock/fixture tests; no scientific memory benefit or original provider recovery is claimed."},
        "auditor_started_native_or_model_requests": 0,
    }
    write(ROOT / "TERMINAL_BOUNDARIES.json", encode(report))
    write(ROOT / "OFFLINE_AUDIT_EXECUTION.json", encode({
        "schema": "mem-native-five-offline-audit-execution-v1",
        "command": ["python3", str(ROOT / "audit_original.py"), "--zip", str(ROOT / "ORIGINAL_ARTIFACT.zip"), "--output", str(ROOT / "readback")],
        "actual_exit_code": 0,
        "meaning": "The independent reader completed; its qualification result remains NOT_QUALIFIED. Exit zero is not a native or whole-job pass.",
        "reader": ident((ROOT / "audit_original.py").read_bytes()),
        "report": ident((ROOT / "readback/INDEPENDENT_AUDIT.json").read_bytes()),
        "zip_manifest": ident((ROOT / "readback/ZIP_MEMBER_AUDIT.json").read_bytes()),
    }))
    names = [
        "ORIGINAL_ARTIFACT.zip", "ARTIFACT_METADATA.json", "RUN_METADATA.json", "TERMINAL_JOBS.json",
        "JOB_LOG_TOOL_RESPONSE.json", "original-job-130616746852.log", "ACTUAL_ADMISSION.json",
        "FROZEN_PLAN.json", "audit_original.py", "package_original.py", "TERMINAL_BOUNDARIES.json",
        "OFFLINE_AUDIT_EXECUTION.json", "readback/ZIP_MEMBER_AUDIT.json", "readback/INDEPENDENT_AUDIT.json",
        "observation-020.json", "observation-021.json", "observation-022.json",
    ]
    members = []
    output = ROOT / "publication"
    output.mkdir(exist_ok=False)
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name in sorted(names):
            data = (ROOT / name).read_bytes()
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mtime = 0
            item.mode = 0o644
            archive.addfile(item, io.BytesIO(data))
            members.append({"path": name, **ident(data)})
    packed = lzma.compress(raw.getvalue(), preset=6)
    with tarfile.open(fileobj=io.BytesIO(packed), mode="r:xz") as archive:
        assert sorted(m.name for m in archive.getmembers()) == sorted(names)
        for item in archive.getmembers():
            assert item.isfile() and archive.extractfile(item).read() == (ROOT / item.name).read_bytes()
    write(output / "FIVE_NATIVE_ORIGINAL_COMPLETE.tar.xz", packed)
    write(output / "MEMBER_MANIFEST.json", encode(members))
    index = {"schema": "mem-native-five-complete-original-archive-v1", "archive": ident(packed),
             "members": len(members), "original_zip_members": 353, "original_declared_rows": 352,
             "original_zip": ident((ROOT / "ORIGINAL_ARTIFACT.zip").read_bytes()),
             "archive_full_local_member_readback": True,
             "source_head": audit["source_head"], "harness_head": audit["harness_head"],
             "run_id": 43047914262, "job_id": 130616746852, "attempt": 1,
             "qualification": audit["qualification"], "native_named_cases_passed": 5,
             "native_case_failures": 0, "native_case_leaks": 0, "clean_scoped_lints": ["core_test_support"],
             "interrupted_unknown_scoped_lint": "codex-core", "unexecuted_scoped_lint": "codex-windows-sandbox",
             "git_publication": "NOT_YET_UPLOADED", "source_refs_changed": False}
    write(output / "ARCHIVE_INDEX.json", encode(index))
    print(json.dumps(index, indent=2))

if __name__ == "__main__":
    main()
