"""Package the one original terminal attempt without changing any evidence."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
RUN = 43061843610
JOB = 130666210831
SOURCE = "d0f6507e08f7f5c5855f5164d07c049a34d1a6d9"
HARNESS = "ca9ab8c0d07d1a236ef3c4b76a22f0a131d409ae"

def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}

def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()

def create(path, raw):
    with path.open("xb") as stream:
        stream.write(raw)

def document(name):
    return json.loads((ROOT / name).read_text())

def optional(name):
    path = ROOT / name
    return json.loads(path.read_text()) if path.is_file() else None

def main():
    run = json.loads(document("RUN_METADATA.json")["structuredContent"]["content"])
    jobs = document("TERMINAL_JOBS.json")["structuredContent"]["jobs"]
    matching = [job for job in jobs if job["id"] == JOB and job["run_id"] == RUN]
    assert len(matching) == 1
    job = matching[0]
    assert run["id"] == RUN and run["run_attempt"] == 1 and run["head_sha"] == HARNESS
    assert run["status"] == job["status"] == "completed"
    assert run["conclusion"] is not None and job["conclusion"] is not None
    audit = document("readback/INDEPENDENT_AUDIT.json")
    assert str(audit["run_id"]) == str(RUN) and audit["job_id"] == JOB
    assert audit["source_head"] == SOURCE and audit["harness_head"] == HARNESS
    execution = document("OFFLINE_AUDIT_EXECUTION.json")
    assert execution["actual_exit_code"] == 0
    assert execution["reader"] == identity((ROOT / "audit_original.py").read_bytes())
    assert execution["report"] == identity((ROOT / "readback/INDEPENDENT_AUDIT.json").read_bytes())
    snapshot_audit = document("SOURCE_SNAPSHOT_AUDIT_V2.json")
    snapshot_execution = document("SOURCE_SNAPSHOT_AUDIT_V2_EXECUTION.json")
    assert snapshot_execution["actual_exit_code"] == 0
    assert snapshot_execution["reader"] == identity((ROOT / "audit_snapshot_proofs_v2.py").read_bytes())
    assert snapshot_execution["report"] == identity((ROOT / "SOURCE_SNAPSHOT_AUDIT_V2.json").read_bytes())
    assert snapshot_audit["source_head"] == SOURCE
    assert snapshot_audit["source_tree"] == audit["source_tree"]
    assert snapshot_audit["all_observed_raw_proofs_consistent"] is True
    assert snapshot_audit["checks"] and all(row["passed"] for row in snapshot_audit["checks"])
    original_result = optional("readback/files/RESULT.json")
    original_collection = optional("readback/files/COLLECTION.json")
    observed = audit["observed_terminal_test_executions"]
    status_counts = dict(Counter(row["status"] for row in observed))
    assert status_counts == audit["observed_status_counts"]
    summary = {
        "schema": "mem-two-native-original-terminal-boundaries-v1",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "run_id": RUN, "job_id": JOB, "attempt": 1,
        "source_head": SOURCE, "source_tree": audit["source_tree"], "harness_head": HARNESS,
        "api_run_conclusion": run["conclusion"], "api_job_conclusion": job["conclusion"],
        "original_job_timeout_minutes": 65, "retries_or_deadlines_changed": False,
        "original_driver_result": original_result, "original_collection": original_collection,
        "observed_terminal_test_executions": observed,
        "observed_execution_status_counts": status_counts,
        "independently_qualified_native_cases": audit["independently_qualified_native_cases"],
        "clean_scoped_fix_packages": audit["clean_scoped_fix_packages"],
        "actual_helper_bindings": audit["actual_helper_bindings"],
        "phase_evidence": audit["phases"],
        "independent_evidence_qualification": audit["qualification"],
        "whole_job_qualification": audit["qualification"] if run["conclusion"] == job["conclusion"] == "success" else "NOT_QUALIFIED_ORIGINAL_API_JOB_NOT_SUCCESS",
        "raw_source_snapshot_audit": {"report": identity((ROOT / "SOURCE_SNAPSHOT_AUDIT_V2.json").read_bytes()), "snapshots": len(snapshot_audit["snapshots"]), "checks": len(snapshot_audit["checks"]), "all_observed_raw_proofs_consistent": True, "historical_v1_auditor_error_retained": "SOURCE_SNAPSHOT_READER_CORRECTION.json"},
        "integrity_checks_not_satisfied": [row for row in audit["checks"] if not row["passed"]],
        "count_boundary": audit["count_boundary"],
        "unknown_boundary": "Absent or interrupted original command exits remain unknown. Later source collection cannot manufacture an earlier exit or after-tool/helper receipt. Known native successes and independent lint results are reported separately.",
        "binary_boundary": audit["binary_boundary"],
        "model_boundary": {"auditor_started_native_or_model_requests": 0, "selected_tests": "The two original local mock fixture tests only; no memory-benefit or original provider-recovery conclusion.", "physical_network_request_count": None},
    }
    create(ROOT / "TERMINAL_BOUNDARIES.json", encoded(summary))
    replay = {
        "schema": "mem-two-native-offline-replay-inputs-v1",
        "preparation_publication_git_blob": "11c317586715589a39597dd0082befe8bf33589c",
        "preparation_archive_bytes": 802788,
        "preparation_archive_sha256": "41f8ef614099289bb7cc3ffafcf6cfafb4a2e9cd574bbc8a5d2d2087b85e8873",
        "preparation_archive_raw_parts": ["519fda8be224acb3b085bb9ed5e23fa0a4638696", "95ba2782dfaa23c3fd81e2d8aabd5969d06024d4"],
        "preparation_reader_git_blob": "45d1ebb9ada4808048ecadf92ba1815f1f20283b",
        "replay": "Restore the complete preparation package and its rendered-d0f6507 subtree at the sibling mem-two-native-harness-preparation path. Run audit_original.py against ORIGINAL_ARTIFACT.zip with a new output directory. It reads original evidence only and never starts a test.",
        "actual_full_binary_remote_readback": "See the later root carrier readback; creation ACK alone is not that verification."
    }
    create(ROOT / "OFFLINE_REPLAY_INPUTS.json", encoded(replay))
    names = {
        "ORIGINAL_ARTIFACT.zip", "ARTIFACT_METADATA.json", "RUN_METADATA.json", "TERMINAL_JOBS.json",
        "JOB_LOG_TOOL_RESPONSE.json", "original-job-130666210831.log", "ACTUAL_ADMISSION.json",
        "FROZEN_PLAN.json", "audit_original.py", "package_original.py", "package_original_v2.py", "PACKAGER_V2_DERIVATION.json", "PACKAGER_V1_TO_V2.patch", "TERMINAL_BOUNDARIES.json",
        "OFFLINE_AUDIT_EXECUTION.json", "OFFLINE_REPLAY_INPUTS.json", "AUDITOR_BINDING.json",
        "AUDITOR_FIVE_TO_TWO.patch", "readback/ZIP_MEMBER_AUDIT.json", "readback/INDEPENDENT_AUDIT.json",
        "INITIAL_JOBS.json", "RUN_DISCOVERY.json"
    }
    names.update(path.name for path in ROOT.iterdir() if path.is_file() and path.name.lower().startswith("observation-") and path.suffix == ".json")
    names.update({"package_original_v3.py", "PACKAGER_V2_TO_V3.patch", "PACKAGER_V3_DERIVATION.json",
        "audit_snapshot_proofs.py", "SOURCE_SNAPSHOT_AUDIT.json", "SOURCE_SNAPSHOT_AUDIT_EXECUTION.json",
        "audit_snapshot_proofs_v2.py", "SOURCE_SNAPSHOT_AUDIT_V2.json", "SOURCE_SNAPSHOT_AUDIT_V2_EXECUTION.json",
        "SOURCE_SNAPSHOT_READER_V1_TO_V2.patch", "SOURCE_SNAPSHOT_READER_CORRECTION.json"})
    for name in ("PACKAGER_PREPARATION.json",):
        if (ROOT / name).is_file():
            names.add(name)
    rows = []
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name in sorted(names):
            payload = (ROOT / name).read_bytes()
            item = tarfile.TarInfo(name)
            item.size = len(payload)
            item.mtime = 0
            item.mode = 0o644
            archive.addfile(item, io.BytesIO(payload))
            rows.append({"path": name, **identity(payload)})
    packed = lzma.compress(raw.getvalue(), preset=6)
    with tarfile.open(fileobj=io.BytesIO(packed), mode="r:xz") as archive:
        assert sorted(member.name for member in archive.getmembers()) == sorted(names)
        for member in archive.getmembers():
            assert member.isfile() and archive.extractfile(member).read() == (ROOT / member.name).read_bytes()
    output = ROOT / "publication"
    output.mkdir(exist_ok=False)
    create(output / "TWO_NATIVE_ORIGINAL_COMPLETE.tar.xz", packed)
    create(output / "MEMBER_MANIFEST.json", encoded(rows))
    index = {
        "schema": "mem-two-native-complete-original-archive-v1",
        "archive": identity(packed), "members": len(rows),
        "original_zip": identity((ROOT / "ORIGINAL_ARTIFACT.zip").read_bytes()),
        "original_zip_audit": document("readback/ZIP_MEMBER_AUDIT.json"),
        "archive_full_local_member_readback": True,
        "source_head": SOURCE, "harness_head": HARNESS, "run_id": RUN, "job_id": JOB, "attempt": 1,
        "qualification": summary["whole_job_qualification"], "independent_evidence_qualification": audit["qualification"], "observed_execution_status_counts": status_counts,
        "qualified_native_case_count": len(audit["independently_qualified_native_cases"]),
        "clean_scoped_lints": audit["clean_scoped_fix_packages"],
        "git_publication": "NOT_YET_UPLOADED", "source_refs_changed": False,
    }
    create(output / "ARCHIVE_INDEX.json", encoded(index))
    print(json.dumps({key: index[key] for key in ("archive", "members", "qualification", "observed_execution_status_counts", "clean_scoped_lints")}, indent=2))

if __name__ == "__main__":
    main()
