#!/usr/bin/env python3
"""Prepare only an unadmitted scoped-lint template from the frozen five-case harness."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import yaml

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
ORIGINAL = WORK / 'mem-five-native-harness-preparation/rendered-c895405'


def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def main():
    before = (ORIGINAL / '.github/scripts/mem_native_five.py').read_text()
    assert ident(before.encode())['git_blob'] == 'a524828dbc9de8bf65284fb96e1aab47ce2fd738'
    driver = before
    changes = []

    def replace(old, new, count=1):
        nonlocal driver
        assert driver.count(old) == count, (old, driver.count(old))
        driver = driver.replace(old, new)
        changes.append({'old': old, 'new': new, 'count': count})

    def section(start, end, replacement):
        a = driver.index(start)
        b = driver.index(end, a)
        replace(driver[a:b], replacement)

    replace('"""Run only the frozen five-case Windows plan; interrupted work never passes."""',
            '"""Build real helpers and run only Windows sandbox scoped lint; interruption never passes."""')
    for line in ('from datetime import datetime, timezone\n', 'import re\n', 'import uuid\n', 'import xml.etree.ElementTree as ET\n'):
        replace(line, '')
    replace('import mem_native_five_support as evidence', 'import mem_windows_sandbox_fix_support as evidence')
    section('PLAN_PATH =', 'POLICY =',
            'PLAN_PATH = ".github/fixtures/mem-windows-sandbox-fix-plan.json"\n'
            'WORKFLOW_PATH = ".github/workflows/hepta-mem-windows-sandbox-fix.yml"\n'
            'FIX_COMMAND = ["just", "fix", "--locked", "-p", "codex-windows-sandbox"]\n\n')
    section('def parse_junit(', 'def run(', '')
    replace('"schema": "mem-native-five-original-run-v1"', '"schema": "mem-windows-sandbox-fix-original-run-v1"')
    replace('"native_groups": plan["groups"], "direct_model_requests_issued_by_driver": 0,',
            '"native_test_commands": [], "native_tests_executed": 0, "direct_model_requests_issued_by_driver": 0,')
    replace('"provider_boundary": "The selected Rust fixtures use local loopback mocks; this driver makes no provider request and does not instrument all network requests.",',
            '"provider_boundary": "This driver builds helpers and runs scoped lint only; no test or model command is launched. Dependency-download traffic is not counted as model traffic.",')
    replace('    seen_uuids = set()\n    native_failed = False\n    native_passes = []\n', '')
    replace('        if plan["schema"] != "mem-native-five-frozen-plan-v1" or plan["groups"] != GROUPS:\n            raise ValueError("qualification plan differs from the reviewed five active cases")',
            '        if (plan["schema"] != "mem-windows-sandbox-fix-frozen-plan-v1"\n'
            '                or plan["scoped_fix_command"] != FIX_COMMAND\n'
            '                or plan["native_test_commands"] != []\n'
            '                or plan["job_timeout_minutes"] != 65):\n'
            '            raise ValueError("qualification plan differs from the single reviewed scoped lint")')
    replace('        if source.drive.lower() != records.drive.lower():\n            raise ValueError("source and records must support the original JUnit\'s same-volume retained move")\n', '')
    replace('mem-native-five-case-temp-', 'mem-windows-sandbox-fix-temp-')
    replace('"physicalCaseTemp"', '"physicalBuildTemp"')
    section('        for group in plan["groups"]:', '        result["planned_stages"]',
            '        stages.append({"id": "fix-codex-windows-sandbox", "kind": "fix", "command": FIX_COMMAND})\n')
    replace('        result["planned_stages"] = [{key: value for key, value in stage.items() if key != "group"} for stage in stages]',
            '        result["planned_stages"] = stages')
    section('            if native_failed', '            before =', '')
    replace('            if (source / JUNIT_PATH).exists():\n                raise ValueError("unexpected pre-existing JUnit artifact; no stale report reuse")\n', '')
    section('                elif stage["kind"] == "native":', '                if completed.returncode:', '')
    replace('                # A fully acknowledged native failure may be followed by the\n'
            '                # separately authorized lint scope, but never after unknown\n'
            '                # execution, dirty source or changed tool/helper identities.\n',
            '                # Only an acknowledged exit plus unchanged source/tools/helpers\n'
            '                # may settle a stage. Unknown execution never starts another.\n')
    section('            if phase["status"] != "passed_clean":', '        final =',
            '            if phase["status"] != "passed_clean":\n'
            '                raise ValueError(f"{prefix} failed or has unknown execution/integrity; subsequent commands stopped")\n'
            '            if stage["kind"] == "fix":\n'
            '                fix_passes.append(stage["id"])\n\n')
    section('        native_passed =', '    except BaseException as error:',
            '        if fix_passes != ["fix-codex-windows-sandbox"]:\n'
            '            raise ValueError("the one required scoped lint did not finish cleanly")\n'
            '        result.update(\n'
            '            status="passed_one_clean_windows_sandbox_fix",\n'
            '            after=final, helpers_after=helper_snapshot(helpers),\n'
            '            clean_scoped_fixes=fix_passes,\n'
            '            remaining_job_seconds_after=evidence.budget(records),\n'
            '        )\n')
    replace('passed_five_named_cases_and_three_clean_scoped_fixes', 'passed_one_clean_windows_sandbox_fix', 2)
    ast.parse(driver)
    assert '"test"' not in driver and 'parse_junit' not in driver and 'GROUPS' not in driver
    support = (ORIGINAL / '.github/scripts/mem_native_five_support.py').read_bytes()
    assert ident(support)['git_blob'] == '85b6407d0b8a8fa6bd6859f86ccbbdbae3635595'
    ast.parse(support)
    old_workflow = (ORIGINAL / '.github/workflows/hepta-mem-native-five.yml').read_text()
    assert ident(old_workflow.encode())['git_blob'] == '602a12f6765d9013021d4e8dc131b276aa1c71a9'
    workflow = old_workflow
    workflow_changes = []
    for old, new in [
        ('MEM five native regressions (exact source)', 'MEM Windows sandbox scoped lint (exact source)'),
        ('on:\n', '"on":\n'),
        ('codex/mem8-native-five-v8-20261111-ed353817', 'codex/mem8-windows-sandbox-fix-v10-20261111-ed353817'),
        ('mem-native-five', 'mem-windows-sandbox-fix'),
        ('native-five:', 'sandbox-fix:'),
        ('MEM_NATIVE_RECORDS', 'MEM_LINT_RECORDS'),
        ('mem_native_five.py', 'mem_windows_sandbox_fix.py'),
        ('c89540598693697577cda8cba31cb07f6ce65317', '__FINAL_V10_SOURCE_HEAD__'),
        ('5a7c897a33e4eef48ea8f4bf52eaf48ea7c866ae', '__FINAL_V10_SOURCE_TREE__'),
        ('Build real helpers, qualify the five cases and retain independent scoped lint', 'Build real helpers and run the one frozen Windows sandbox scoped lint'),
        ('Retain every original intent, raw log, JUnit and source rewrite', 'Retain every original intent, raw log and source rewrite'),
    ]:
        count = workflow.count(old)
        assert count > 0, old
        workflow = workflow.replace(old, new)
        workflow_changes.append({'old': old, 'new': new, 'count': count})
    wf = yaml.safe_load(workflow)
    assert wf['on'] == {'push': {'branches': ['codex/mem8-windows-sandbox-fix-v10-20261111-ed353817']}}
    assert wf['jobs']['sandbox-fix']['timeout-minutes'] == 65
    assert wf['permissions'] == {'contents': 'read'} and wf['concurrency']['cancel-in-progress'] is False
    assert all(s.get('shell') in (None, 'pwsh') for s in wf['jobs']['sandbox-fix']['steps'])
    out = HERE / 'templates'
    files = {
        '.github/scripts/mem_windows_sandbox_fix.py': driver.encode(),
        '.github/scripts/mem_windows_sandbox_fix_support.py': support,
        '.github/workflows/hepta-mem-windows-sandbox-fix.yml.in': workflow.encode(),
    }
    for name, data in files.items():
        path = out / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    (HERE / 'DRIVER_FROM_FIVE.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), driver.splitlines(True),
        fromfile='original/mem_native_five.py', tofile='template/mem_windows_sandbox_fix.py')))
    (HERE / 'WORKFLOW_FROM_FIVE.patch').write_text(''.join(difflib.unified_diff(old_workflow.splitlines(True), workflow.splitlines(True),
        fromfile='original/hepta-mem-native-five.yml', tofile='template/hepta-mem-windows-sandbox-fix.yml.in')))
    report = {'schema': 'mem.windows-sandbox-fix.v10.unadmitted-template.v1',
        'status': 'TEMPLATE_ONLY_AWAIT_ACTUAL_FORMATTED_V10_SOURCE',
        'files': [{'path': n, **ident(b)} for n, b in files.items()],
        'original_driver': ident(before.encode()), 'original_support': ident(support),
        'original_workflow': ident(old_workflow.encode()), 'driver_derivation': changes,
        'workflow_derivation': workflow_changes, 'support_unchanged': True,
        'commands': [['cargo', 'build', '--locked', '-p', 'codex-windows-sandbox', '--profile', 'dev-small',
                      '--message-format=json', '--bin', 'codex-windows-sandbox-setup', '--bin', 'codex-command-runner'],
                     ['just', 'fix', '--locked', '-p', 'codex-windows-sandbox']],
        'native_test_commands': [], 'original_five_or_elevated_PASS_admission_dependency': False,
        'original_plan_dependency_correction': 'Root previously authorized independent scoped lint without requiring five-case PASS; old V6 proposal prerequisite does not apply.',
        'job_timeout_minutes': 65, 'budget_origin': 'same first-step/run/attempt/harness bound job anchor; earlier Actions deadline remains authoritative',
        'source_and_lock_guards': 'unchanged original evidence.snapshot/require_source and full rewrite postimage capture',
        'final_source_pins': None, 'new_native_or_model_execution': 0, 'refs_changed': False,
        'static_checks': {'driver_support_ast': 'PASS', 'workflow_yaml': 'PASS', 'all_run_shells': 'pwsh',
                          'native_test_dispatch_code_removed': True, 'scope_has_exactly_one_just_fix': True}}
    (HERE / 'TEMPLATE_STATIC_REVIEW.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    print(json.dumps({k: report[k] for k in ('status', 'files', 'commands', 'job_timeout_minutes', 'final_source_pins')}))


if __name__ == '__main__':
    main()
