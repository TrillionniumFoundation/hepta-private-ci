#!/usr/bin/env python3
"""Render reviewed lint-only templates against the original qualified V10 source."""
import ast
import base64
import hashlib
import json
from pathlib import Path
import runpy
import yaml

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
SOURCE = 'd0f6507e08f7f5c5855f5164d07c049a34d1a6d9'
TREE = '658fa040046285116b1fd81b94ff8c96444072ad'
RECORDS = WORK / 'mem8-source-v10-original-run/readback/canonical-original/records'
PREP = WORK / 'mem8-source-v10-preparation'


def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def load(path):
    return json.loads(path.read_bytes())


def main():
    audit_path = PREP / 'ROOT_SOURCE_GATE_AUDIT.json'
    audit = load(audit_path)
    assert audit['status'] == 'PASS_FULL_ORIGINAL_ZIP_CANONICAL_TAR_AND_UNCHANGED_VERIFIER'
    assert (audit['source'], audit['tree']) == (SOURCE, TREE)
    assert audit['formatter_changed_paths'] == [] and audit['source_after_clean'] is True
    assert audit['python_pass'] == 18 and audit['old_name_hits'] == 0 and audit['rust_inventory'] == 6204
    assert audit['full_golden_equal_except_derived_count'] is True and audit['both_lock_bytes_unchanged'] is True
    assert audit['native_tests_executed'] == audit['real_model_requests'] == 0
    commit = load(PREP / 'FORMATTED_COMMIT_READBACK.json')
    assert commit['sha'] == SOURCE and commit['tree']['sha'] == TREE
    assert [p['sha'] for p in commit['parents']] == ['408226fc670bfa8c1736e2b264750b549237b7c4']
    result = load(RECORDS / 'RESULT.json')
    assert result['status'] == 'passed_source_gates_only_review_remaining'
    assert result['source_before'] == result['source_after'] == {'head': SOURCE, 'tree': TREE, 'status': ''}
    renames = load(RECORDS / 'FULL_TREE_RENAME_SCAN.json')
    assert renames['matches'] == [] and renames['review_required'] is False
    helper_path = WORK / 'mem8-source-v9-harness-candidate/generated/verify_v9_peer.py'
    assert ident(helper_path.read_bytes())['git_blob'] == 'cb1414606f5754c4aa488ecdf81fbb6f597924ad'
    helpers = runpy.run_path(str(helper_path), run_name='readonly_merkle_helpers')
    complete = helpers['entries'](RECORDS / 'CANDIDATE_TREE.ls-tree')
    assert len(complete) == 14053 and helpers['merkle'](complete) == TREE
    assert sum(p.startswith('codex-rs/') and p.endswith('.rs') for p in complete) == 6204
    capsule = load(RECORDS / 'FORMATTED_CAPSULE.json')
    assert capsule['candidate_tree'] == TREE and len(capsule['files']) == 118
    rows = {r['path']: r for r in capsule['files']}
    assert len(rows) == 118
    for path, row in rows.items():
        data = base64.b64decode(row['content_base64'], validate=True)
        assert ident(data) == {'bytes': row['postimage_bytes'], 'sha256': row['postimage_sha256'], 'git_blob': row['postimage_git_blob']}
        assert complete[path] == (row['mode'], row['postimage_git_blob'])
    prior_plan_path = WORK / 'mem-five-native-harness-preparation/rendered-c895405/.github/fixtures/mem-native-five-plan.json'
    prior_plan = load(prior_plan_path)
    files = {}
    origins = {}
    for name, prior in prior_plan['files'].items():
        if name.startswith('codex-rs/core/'):
            continue
        if name in rows:
            row = rows[name]
            data = base64.b64decode(row['content_base64'], validate=True)
            files[name] = {'mode': row['mode'], **ident(data)}
            origins[name] = 'actual V10 canonical formatter capsule bytes'
        else:
            assert complete[name] == (prior['mode'], prior['git_blob'])
            files[name] = prior
            origins[name] = 'same immutable Git blob as the previously frozen actual five-case plan; complete V10 tree independently matched'
    for name in ('codex-rs/windows-sandbox-rs/src/elevated_impl.rs', 'codex-rs/windows-sandbox-rs/tests/helper_manifest.rs'):
        row = rows[name]
        files[name] = {'mode': row['mode'], **ident(base64.b64decode(row['content_base64'], validate=True))}
        origins[name] = 'actual V10 canonical formatter capsule bytes, including reviewed earlier Clippy output'
    assert all(complete[n] == (v['mode'], v['git_blob']) for n, v in files.items())
    assert {p for p in files if p.endswith('.lock')} == {'codex-rs/Cargo.lock', 'MODULE.bazel.lock'}
    plan = {
        'schema': 'mem-windows-sandbox-fix-frozen-plan-v1', 'execution_state': 'PREPARED_NOT_ADMITTED_NOT_RUN',
        'source_head': SOURCE, 'source_tree': TREE, 'job_timeout_minutes': 65,
        'scoped_fix_command': ['just', 'fix', '--locked', '-p', 'codex-windows-sandbox'],
        'native_test_commands': [], 'files': files,
        'complete_tree_leaf_count': len(complete),
        'complete_tree_inventory': ident((RECORDS / 'CANDIDATE_TREE.ls-tree').read_bytes()),
        'commit_readback': ident((PREP / 'FORMATTED_COMMIT_READBACK.json').read_bytes()),
        'source_only_qualification': {'original_run': audit['run'], 'original_job': audit['job'], 'attempt': audit['attempt'],
            'root_full_audit': ident(audit_path.read_bytes()), 'formatted_delta': [],
            'boundary': 'source-only qualification, not a new native result or an original owner recovery'},
        'native_or_elevated_PASS_admission_dependency': False,
        'original_plan_dependency_correction': 'Root explicitly authorized scoped lint independently of five-case PASS; no prior native result is a prerequisite or substituted result.',
        'tool_policy': {'rust': '1.96.0', 'just': '1.51.0', 'nextest_identity_only': '0.9.103',
                        'job_budget': 'unchanged single 65-minute Actions job; no new per-stage allowance'},
        'build_helpers': ['codex-windows-sandbox-setup', 'codex-command-runner'],
        'source_guards': 'before/after every command and final source, full tracked/untracked state, both locks, tool identities and actual helper/sibling bytes; any rewrite fails and retains full patch/postimages',
        'model_boundary': 'no test or model command; no original provider request or recovery operation',
        'other_scopes_excluded': ['core_test_support scoped fix', 'codex-core scoped fix', 'five native cases', 'Windows-current 167-case workflow'],
    }
    rendered = HERE / 'rendered'
    generated = {}
    for name in ('.github/scripts/mem_windows_sandbox_fix.py', '.github/scripts/mem_windows_sandbox_fix_support.py'):
        data = (HERE / 'templates' / name).read_bytes()
        ast.parse(data)
        generated[name] = data
    workflow = (HERE / 'templates/.github/workflows/hepta-mem-windows-sandbox-fix.yml.in').read_text()
    assert workflow.count('__FINAL_V10_SOURCE_HEAD__') == 3 and workflow.count('__FINAL_V10_SOURCE_TREE__') == 1
    workflow = workflow.replace('__FINAL_V10_SOURCE_HEAD__', SOURCE).replace('__FINAL_V10_SOURCE_TREE__', TREE)
    assert '__FINAL_' not in workflow
    wf = yaml.safe_load(workflow)
    job = wf['jobs']['sandbox-fix']
    assert job['timeout-minutes'] == 65
    assert next(s for s in job['steps'] if s.get('id') == 'source')['with']['ref'] == SOURCE
    assert wf['on'] == {'push': {'branches': ['codex/mem8-windows-sandbox-fix-v10-20261111-ed353817']}}
    assert wf['permissions'] == {'contents': 'read'}
    generated['.github/workflows/hepta-mem-windows-sandbox-fix.yml'] = workflow.encode()
    generated['.github/fixtures/mem-windows-sandbox-fix-plan.json'] = (json.dumps(plan, indent=2, sort_keys=True)+'\n').encode()
    for path, data in generated.items():
        destination = rendered / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
    report = {
        'schema': 'mem.windows-sandbox-fix.final-preparation.v1', 'status': 'FROZEN_NOT_ADMITTED_NOT_RUN',
        'source_head': SOURCE, 'source_tree': TREE, 'source_only_original_run': audit['run'],
        'source_only_original_job': audit['job'], 'source_only_root_audit': ident(audit_path.read_bytes()),
        'files': [{'path': n, **ident(b)} for n, b in generated.items()],
        'input_source_pins': len(files), 'pin_origins': origins, 'complete_tree_leaf_count': len(complete),
        'complete_tree_recomputed': TREE, 'support_bytes_unchanged': True,
        'original_five_plan': ident(prior_plan_path.read_bytes()), 'scope': 'real helper build then exactly one scoped Windows sandbox just fix',
        'native_tests': 0, 'model_requests': 0, 'refs_changed': False,
        'independent_peer_required_before_admission': True,
        'static_checks': {'python_ast': 'PASS', 'yaml': 'PASS', 'no_placeholder_pins': 'PASS',
            'same_original_PowerShell_control_structure': 'only namespace, displayed scope and source identities change',
            'PowerShell_execution_or_new_native_test': 'NOT_PERFORMED'}}
    (HERE / 'FINAL_PREPARATION.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    print(json.dumps({k:report[k] for k in ('status','source_head','source_tree','files','input_source_pins','complete_tree_leaf_count')}))


if __name__ == '__main__':
    main()
