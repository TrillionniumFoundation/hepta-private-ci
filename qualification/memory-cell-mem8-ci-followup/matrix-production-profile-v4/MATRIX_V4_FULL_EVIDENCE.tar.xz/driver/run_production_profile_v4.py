import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

TASK = Path('/home/qian-qi/mem8-matrix-production-profile-ed353817-v4')
SOURCE = Path('/home/qian-qi/mem8-matrix-diagnostic-ed353817-v1/source')
TARGET = Path('/home/qian-qi/mem8-dependency-validation-ed353817-v2/target')
PREVIOUS = Path('/home/qian-qi/mem8-matrix-production-profile-ed353817-v3/records')
RECORDS = TASK / 'records'
HEAD = 'f1fd544b3e12ed6aca83872cdeda8114a1e058c0'
TREE = 'fff40d06312d4f6a185772cd8a62a618d55f31cf'
PARENT = 'dc96a441312e239c165c1642880084dfeccc2c71'
ENV = {**os.environ, 'PATH': '/home/qian-qi/.cargo/bin:/home/qian-qi/.local/bin:' + os.environ.get('PATH', ''), 'RUSTUP_TOOLCHAIN': '1.96.0', 'CARGO_TARGET_DIR': str(TARGET), 'CARGO_BUILD_JOBS': '4', 'PYTHONDONTWRITEBYTECODE': '1', 'RUST_BACKTRACE': '1'}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(name, value):
    with (RECORDS / name).open('x') as out:
        json.dump(value, out, indent=2, sort_keys=True)
        out.write('\n')

def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True, env=ENV).strip()

def identity():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'dirty': bool(git('status', '--porcelain=v1')), 'cargo_lock_sha256': sha((SOURCE / 'codex-rs/Cargo.lock').read_bytes()), 'bazel_lock_sha256': sha((SOURCE / 'MODULE.bazel.lock').read_bytes())}

def phase(name, command, minimum, expected_ids=None):
    before = identity()
    assert before['head'] == HEAD and before['tree'] == TREE and not before['dirty']
    junit_path = SOURCE / 'codex-rs/target/nextest/local/junit.xml'
    old_junit = junit_path.read_bytes() if minimum and junit_path.exists() else None
    if old_junit is not None:
        (RECORDS / (name + '.preexisting-junit.xml')).write_bytes(old_junit)
    started_ns = time.time_ns()
    output = RECORDS / (name + '.json')
    env = {**ENV, 'SOURCE_SHA': HEAD, 'TESTED_SHA': HEAD, 'BASE_SHA': PARENT, 'HEPTA_CI_LANE': 'source-head'}
    wrapper = [sys.executable, '-B', str(SOURCE / 'scripts/hepta_ci_exec.py'), '--output', str(output), '--minimum-tests', str(minimum), '--timeout-seconds', '1200', '--', *command]
    save(name + '.intent.json', {'source': before, 'command': command, 'wrapper': wrapper, 'started_ns': started_ns, 'preexisting_junit_sha256': sha(old_junit) if old_junit else None, 'native_command_timeout_seconds': 1200})
    print('MEM8_MATRIX_V4_START ' + json.dumps({'phase': name, 'head': HEAD, 'command': command}), flush=True)
    with (RECORDS / (name + '.wrapper.stdout')).open('xb') as out, (RECORDS / (name + '.wrapper.stderr')).open('xb') as err:
        process = subprocess.run(wrapper, cwd=SOURCE / 'codex-rs', env=env, stdout=out, stderr=err)
    receipt = json.loads(output.read_text())
    raw = (RECORDS / receipt['log_file']).read_bytes()
    assert len(raw) == receipt['log_bytes'] and sha(raw) == receipt['log_sha256']
    after = identity()
    text = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode())
    audit = {'before': before, 'after': after, 'wrapper_exit_code': process.returncode, 'receipt_status': receipt['status'], 'raw_log_bytes': len(raw), 'raw_log_sha256': sha(raw), 'source_unchanged': before == after, 'summaries': [x for x in text.splitlines() if 'Summary [' in x], 'passed': False, 'actual_test_executions': 0, 'preexisting_junit_credited': False}
    (RECORDS / (name + '.source-after.patch')).write_bytes(subprocess.check_output(['git', '-C', str(SOURCE), 'diff', '--binary', 'HEAD']))
    if process.returncode != 0 or receipt['status'] != 'passed' or before != after:
        save(name + '.audit.json', audit)
        raise RuntimeError(name + ' did not complete exact-source gate; original failure retained')
    if minimum:
        jb = junit_path.read_bytes()
        root = ET.fromstring(jb)
        run_id = root.attrib['uuid']
        assert re.fullmatch(r'[0-9a-f-]{36}', run_id) and run_id in text
        assert junit_path.stat().st_mtime_ns >= started_ns
        if old_junit:
            assert sha(jb) != sha(old_junit) and run_id != ET.fromstring(old_junit).attrib.get('uuid')
        cases = list(root.iter('testcase'))
        ids = sorted((x.get('classname'), x.get('name')) for x in cases)
        assert len(ids) == len(set(ids)) == minimum and ids == sorted(tuple(x) for x in expected_ids)
        failed = [x for x in cases if x.find('failure') is not None or x.find('error') is not None]
        skipped = [x for x in cases if x.find('skipped') is not None]
        assert not failed and not skipped
        pass_ids = re.findall(r'^\s*PASS\s+\[[^]]*\]\s+(?:\(\s*\d+/\d+\)\s+)?(\S+)\s+(\S+)\s*$', text, re.M)
        assert len(pass_ids) == len(set(pass_ids)) == minimum
        assert not re.search(r'^\s*(FAIL|RETRY|TRY\s+\d+)\s', text, re.M)
        (RECORDS / (name + '.junit.xml')).write_bytes(jb)
        audit.update({'actual_test_executions': minimum, 'failed': 0, 'selected_skipped': 0, 'nextest_uuid': run_id, 'junit_sha256': sha(jb), 'junit_bytes': len(jb), 'case_ids': ids, 'fresh_junit_bound_to_raw_run_id': True})
    audit['passed'] = True
    save(name + '.audit.json', audit)
    print('MEM8_MATRIX_V4_PHASE_COMPLETE ' + json.dumps({'phase': name, 'passed': True, 'actual_test_executions': audit['actual_test_executions']}), flush=True)
    return audit

def main():
    TASK.mkdir(mode=0o700)
    RECORDS.mkdir(mode=0o700)
    start = identity()
    assert start['head'] == HEAD and start['tree'] == TREE and not start['dirty']
    assert git('hash-object', 'codex-rs/hepta-matrix-sdk/src/sdk.rs') == '3bd27de9e13f5c1998e49aa9710f8b19852ced05'
    assert git('hash-object', 'codex-rs/hepta-matrix-sdk/tests/store_version_migration.rs') == '6f53acc073af77ba496273f2acd98dccff6d4990'
    previous = json.loads((PREVIOUS / 'matrix-consumers.json').read_text())
    assert previous['timed_out'] and previous['exit_code'] == 124 and previous['observed_passed_tests'] == previous['observed_failed_tests'] == 0
    assert sha((PREVIOUS / previous['log_file']).read_bytes()) == '634736dd7ea13ddfd290c45b27242e6aa3e1c4d0dd6c67fd13da4c724fcf8bf8'
    assert json.loads((PREVIOUS / 'fmt.json').read_text())['exit_code'] == 0
    assert json.loads((PREVIOUS / 'bazel-lock-update.json').read_text())['exit_code'] == 0
    save('START.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source': start, 'pid': os.getpid(), 'model_calls': 0, 'previous_timeout_zero_test_attempt_retained': True, 'previous_complete_archive_blob': '1fc0b378442da2e395bef2adc434c3126fcb5af8', 'test_assertions_timeouts_and_crypto_unchanged': True, 'format_metadata_and_bazel_receipts_referenced_not_rerun': str(PREVIOUS)})
    ids = json.loads((Path(__file__).with_name('mem8-matrix-v4-expected-cases.json')).read_text())
    save('EXPECTED_CASES.json', ids)
    test = phase('matrix-consumers', ['just', 'test', '--locked', '-p', 'codex-hepta-matrix-sdk', '--test-threads', '2', '--no-tests', 'fail', '--retries', '0'], 30, ids)
    fix = phase('matrix-scoped-fix', ['just', 'fix', '-p', 'codex-hepta-matrix-sdk'], 0)
    result = {'status': 'passed', 'source': identity(), 'matrix_passed': test['actual_test_executions'], 'matrix_failed': 0, 'matrix_selected_skipped': 0, 'scoped_fix_clean': fix['passed'], 'nextest_uuid': test['nextest_uuid'], 'model_calls': 0, 'cross_version_migration_qualified': False, 'whole_repository_ci_qualified': False}
    save('RESULT.json', result)
    print('MEM8_MATRIX_V4_COMPLETE ' + json.dumps(result), flush=True)

try:
    main()
except Exception as error:
    if RECORDS.is_dir():
        save('DRIVER_ERROR.json', {'type': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc()})
    traceback.print_exc()
    sys.exit(1)
