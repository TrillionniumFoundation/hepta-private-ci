import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import time
import traceback
import xml.etree.ElementTree as ET

TASK = Path('/home/qian-qi/mem8-matrix-production-profile-ed353817-v3')
SOURCE = Path('/home/qian-qi/mem8-matrix-diagnostic-ed353817-v1/source')
RECORDS = TASK / 'records'
TARGET = Path('/home/qian-qi/mem8-dependency-validation-ed353817-v2/target')
PARENT = 'dc96a441312e239c165c1642880084dfeccc2c71'
EXPECTED_CURRENT = 'cbc92000cccb00ff902f9fbfbd902a07052817fe'
CAPSULE = 'bbdbb12b4e2805ced200634fe3020040b334f6c1'
CAPSULE_SHA = '327b5f25b3add421b9c2d9fceef43e8a095c5f8b5647050882182d3536ca5e00'
ENV = {**os.environ, 'PATH': str(TASK / 'bin') + ':/home/qian-qi/.cargo/bin:/home/qian-qi/.local/bin:' + os.environ.get('PATH', ''), 'RUSTUP_TOOLCHAIN': '1.96.0', 'CARGO_TARGET_DIR': str(TARGET), 'CARGO_BUILD_JOBS': '4', 'PYTHONDONTWRITEBYTECODE': '1', 'RUST_BACKTRACE': '1'}

def save(name, value):
    with (RECORDS / name).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True, env=ENV).strip()

def identity():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'dirty': bool(git('status', '--porcelain=v1')), 'parents': git('show', '-s', '--format=%P').split(), 'cargo_lock_sha256': digest(SOURCE / 'codex-rs/Cargo.lock'), 'bazel_lock_sha256': digest(SOURCE / 'MODULE.bazel.lock')}

def prep(name, argv, cwd=TASK, timeout=1200):
    started = time.time()
    with (RECORDS / (name + '.stdout')).open('xb') as out, (RECORDS / (name + '.stderr')).open('xb') as err:
        p = subprocess.run(argv, cwd=cwd, env=ENV, stdout=out, stderr=err, timeout=timeout)
    save(name + '.json', {'argv': argv, 'cwd': str(cwd), 'exit_code': p.returncode, 'started_unix': started, 'finished_unix': time.time()})
    print('MEM8_MATRIX_PRODUCTION_PREP ' + json.dumps({'name': name, 'exit_code': p.returncode}), flush=True)
    if p.returncode:
        raise RuntimeError(name + ' failed; complete logs retained')

def phase(name, argv, minimum):
    before = identity()
    assert not before['dirty']
    output = RECORDS / (name + '.json')
    env = {**ENV, 'SOURCE_SHA': before['head'], 'TESTED_SHA': before['head'], 'BASE_SHA': PARENT, 'HEPTA_CI_LANE': 'source-head'}
    wrapper = [sys.executable, '-B', str(SOURCE / 'scripts/hepta_ci_exec.py'), '--output', str(output), '--minimum-tests', str(minimum), '--timeout-seconds', '1200', '--', *argv]
    print('MEM8_MATRIX_PRODUCTION_START ' + json.dumps({'name': name, 'source': before, 'command': argv}), flush=True)
    with (RECORDS / (name + '.wrapper.stdout')).open('xb') as out, (RECORDS / (name + '.wrapper.stderr')).open('xb') as err:
        result = subprocess.run(wrapper, cwd=SOURCE / 'codex-rs', env=env, stdout=out, stderr=err)
    receipt = json.loads(output.read_text())
    raw = (RECORDS / receipt['log_file']).read_bytes()
    assert len(raw) == receipt['log_bytes'] and hashlib.sha256(raw).hexdigest() == receipt['log_sha256']
    after = identity()
    clean = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode())
    audit = {'before': before, 'after': after, 'source_unchanged': before == after, 'status': receipt['status'], 'wrapper_exit_code': result.returncode, 'raw_log_bytes': len(raw), 'raw_log_sha256': hashlib.sha256(raw).hexdigest(), 'summaries': [line for line in clean.splitlines() if 'Summary' in line], 'gate_passed': result.returncode == 0 and receipt['status'] == 'passed' and before == after}
    if minimum:
        junit = SOURCE / 'codex-rs/target/nextest/local/junit.xml'
        jb = junit.read_bytes()
        (RECORDS / (name + '.junit.xml')).write_bytes(jb)
        cases = list(ET.fromstring(jb).iter('testcase'))
        ids = [(x.get('classname'), x.get('name')) for x in cases]
        assert len(ids) == len(set(ids))
        failed = [x for x in cases if x.find('failure') is not None or x.find('error') is not None]
        skipped = [x for x in cases if x.find('skipped') is not None]
        passed = [x for x in cases if x not in failed and x not in skipped]
        audit['junit'] = {'bytes': len(jb), 'sha256': hashlib.sha256(jb).hexdigest(), 'passed': len(passed), 'failed': len(failed), 'skipped': len(skipped), 'ids': ids}
        audit['gate_passed'] = audit['gate_passed'] and len(passed) == minimum and not failed
    (RECORDS / (name + '.source-after.patch')).write_bytes(subprocess.check_output(['git', '-C', str(SOURCE), 'diff', '--binary', 'HEAD']))
    save(name + '.audit.json', audit)
    print('MEM8_MATRIX_PRODUCTION_RESULT ' + json.dumps({k: v for k, v in audit.items() if k != 'junit'}), flush=True)
    if not audit['gate_passed']:
        raise RuntimeError(name + ' failed exact-source gate; no subsequent test rerun')
    return audit

def main():
    TASK.mkdir(mode=0o700)
    RECORDS.mkdir(mode=0o700)
    (TASK / 'bin').mkdir(mode=0o700)
    save('START.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': os.getpid(), 'parent': PARENT, 'model_calls': 0, 'production_adoption': False})
    current = identity()
    assert current['head'] == EXPECTED_CURRENT and not current['dirty']
    save('PREVIOUS_DIAGNOSTIC_SOURCE.json', current)
    response = subprocess.run(['gh', 'api', 'repos/TrillionniumFoundation/hepta-private-ci/git/blobs/' + CAPSULE], env=ENV, capture_output=True, timeout=120)
    (RECORDS / 'capsule-download.stderr').write_bytes(response.stderr)
    assert response.returncode == 0
    obj = json.loads(response.stdout)
    raw = base64.b64decode(obj['content'])
    assert obj['sha'] == blob(raw) == CAPSULE and len(raw) == 53048 and hashlib.sha256(raw).hexdigest() == CAPSULE_SHA
    (RECORDS / 'PRODUCTION_PROFILE_CAPSULE.json').write_bytes(raw)
    capsule = json.loads(raw)
    prep('checkout-parent', ['git', '-C', str(SOURCE), 'checkout', '--detach', PARENT])
    parent = identity()
    assert parent['head'] == PARENT and parent['tree'] == '7796279284170f0f2c92449c1185eecac1f4f1b6' and not parent['dirty']
    save('PARENT.json', parent)
    assert git('hash-object', 'codex-rs/hepta-matrix-sdk/src/sdk.rs') == '3bd27de9e13f5c1998e49aa9710f8b19852ced05'
    assert git('hash-object', 'codex-rs/hepta-matrix-sdk/tests/store_version_migration.rs') == '6f53acc073af77ba496273f2acd98dccff6d4990'
    for f in capsule['files']:
        p = SOURCE / f['path']
        assert blob(p.read_bytes()) == f['preimage']
        b = f['content'].encode()
        assert blob(b) == f['git_blob'] and hashlib.sha256(b).hexdigest() == f['sha256']
        p.write_bytes(b)
    prep('dotslash-version', ['/usr/local/bin/dotslash', '--version'])
    prep('fmt', ['just', 'fmt'], SOURCE / 'codex-rs')
    prep('cargo-metadata', ['cargo', 'metadata', '--locked', '--no-deps', '--format-version', '1'], SOURCE / 'codex-rs')
    wrapper = '#!/usr/bin/python3\nimport os,sys\nreal="/home/qian-qi/.local/bin/bazel"\nos.execv(real,[real,"--batch","--noexperimental_remote_repo_contents_cache","--output_base=' + str(TASK / 'output-base') + '",*sys.argv[1:],"--repo_contents_cache=' + str(TASK / 'repo-contents-cache') + '","--repository_cache=' + str(TASK / 'repository-cache') + '"])\n'
    wp = TASK / 'bin/bazel'
    wp.write_text(wrapper)
    wp.chmod(0o700)
    save('BAZEL_CACHE_ISOLATION.json', {'wrapper': wrapper, 'sha256': hashlib.sha256(wrapper.encode()).hexdigest(), 'scope': 'New task-owned caches; original failed/shared caches and all evidence retained.'})
    prep('bazel-lock-update', ['just', 'bazel-lock-update'], SOURCE / 'codex-rs')
    changed = git('diff', '--name-only').splitlines()
    assert {'codex-rs/Cargo.toml', 'MODULE.bazel'} <= set(changed) <= {'codex-rs/Cargo.toml', 'MODULE.bazel', 'MODULE.bazel.lock'}, changed
    assert digest(SOURCE / 'codex-rs/Cargo.lock') == parent['cargo_lock_sha256']
    (RECORDS / 'CANDIDATE.patch').write_bytes(subprocess.check_output(['git', '-C', str(SOURCE), 'diff', '--binary', 'HEAD']))
    prep('diff-check', ['git', '-C', str(SOURCE), 'diff', '--check'])
    with tarfile.open(RECORDS / 'candidate-source.tar.xz', 'w:xz') as archive:
        for path in changed:
            archive.add(SOURCE / path, arcname=path)
    prep('stage', ['git', '-C', str(SOURCE), 'add', '--', *changed])
    prep('commit', ['git', '-C', str(SOURCE), '-c', 'user.name=MEM8 build validation', '-c', 'user.email=mem8-validation@localhost', 'commit', '-m', 'fix(matrix): optimize SHA-256 without extending encrypted startup deadline'])
    tested = identity()
    assert not tested['dirty'] and tested['parents'] == [PARENT]
    save('TESTED_SOURCE.json', tested)
    matrix = phase('matrix-consumers', ['just', 'test', '--locked', '-p', 'codex-hepta-matrix-sdk', '--test-threads', '2', '--no-tests', 'fail', '--retries', '0'], 30)
    fix = phase('matrix-scoped-fix', ['just', 'fix', '-p', 'codex-hepta-matrix-sdk'], 0)
    result = {'source': identity(), 'matrix_selected_passed': matrix['junit']['passed'], 'matrix_failed': matrix['junit']['failed'], 'scoped_fix_clean': fix['gate_passed'], 'cargo_lock_unchanged': digest(SOURCE / 'codex-rs/Cargo.lock') == parent['cargo_lock_sha256'], 'original_five_second_deadline_and_crypto_parameters_unchanged': True, 'cross_version_migration_qualified': False, 'whole_repository_ci_qualified': False, 'model_calls': 0}
    save('RESULT.json', result)
    print('MEM8_MATRIX_PRODUCTION_COMPLETE ' + json.dumps(result), flush=True)

try:
    main()
except Exception as error:
    if RECORDS.is_dir():
        save('DRIVER_ERROR.json', {'error_type': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc()})
    traceback.print_exc()
    sys.exit(1)
