"""Offline verification of the frozen 189711 CI observation archive."""
import hashlib
import io
import json
import lzma
import re
import sys
import tarfile

HEAD = '189711e3563ea13a5328d52e99a286f082045b98'
TREE = 'e253b99e0a5c3b3a680569da0d224fabff0781ba'
MERGE = '83b67d85bc8ba58ca1f4e758efdc32dbe5f11c58'
MODEL = 'suite::v2::model_list::list_models_uses_chatgpt_remote_catalog_as_source_of_truth'
INFER = 'durable_control::tests::qualification_observes_physical_same_length_changes_and_retains_the_lock_and_cursor'
NEURON = 'cell_generation_control::tests::lost_rpc_reply_and_queue_capacity_cannot_duplicate_original_dispatch'
HARDLINK = 'suite::apply_patch_cli::apply_patch_cli_preserves_existing_hard_link_outside_workspace'

def metadata(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

def normalized_blocks(text, case):
    lines = text.splitlines()
    result = []
    for start, line in enumerate(lines):
        if '---- ' + case + ' stdout ----' not in line:
            continue
        end = next(n for n in range(start, len(lines)) if 'test result:' in lines[n])
        body = '\n'.join(re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ', '', re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', item)) for item in lines[start:end + 1]) + '\n'
        result.append({'line_start': start + 1, 'line_end': end + 1,
                       'sha256': hashlib.sha256(body.encode()).hexdigest(),
                       'bytes': len(body.encode()), 'summary': lines[end]})
    return result

def apply_patch(original, patch):
    source = original.splitlines(keepends=True)
    lines = patch.splitlines(keepends=True)
    output = []
    consumed = 0
    n = 2
    while n < len(lines):
        match = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[n])
        assert match, lines[n]
        start = int(match.group(1)) - 1
        old_count = int(match.group(2) or 1)
        new_count = int(match.group(4) or 1)
        old, new = [], []
        n += 1
        while n < len(lines) and not lines[n].startswith('@@ '):
            line = lines[n]
            assert line[:1] in [' ', '+', '-']
            if line[0] != '+':
                old.append(line[1:])
            if line[0] != '-':
                new.append(line[1:])
            n += 1
        assert len(old) == old_count and len(new) == new_count
        assert start >= consumed and source[start:start + old_count] == old
        output.extend(source[consumed:start])
        output.extend(new)
        consumed = start + old_count
    output.extend(source[consumed:])
    return ''.join(output)

def verify(path):
    with tarfile.open(path, 'r:xz') as archive:
        members = archive.getmembers()
        assert len({m.name for m in members}) == len(members)
        assert all(m.isfile() and not m.name.startswith('/') and '..' not in m.name.split('/') for m in members)
        data = {m.name: archive.extractfile(m).read() for m in members}
    manifest = json.loads(data['MANIFEST.json'])
    assert set(data) == {row['path'] for row in manifest['files']} | {'MANIFEST.json'}
    for row in manifest['files']:
        assert metadata(data[row['path']]) == {k: row[k] for k in ['bytes', 'sha256', 'git_blob']}, row['path']
    index = json.loads(data['INDEX.json'])
    assert index['source_head'] == HEAD and index['source_tree'] == TREE and index['tested_pr_merge'] == MERGE
    logs = {}
    for row in index['raw_logs']:
        raw = data[row['path']]
        if row['encoding'] == 'xz':
            decoder = lzma.LZMADecompressor()
            raw = decoder.decompress(raw, max_length=row['raw_bytes'] + 1)
            assert decoder.eof and not decoder.unused_data
        assert len(raw) == row['raw_bytes']
        assert hashlib.sha256(raw).hexdigest() == row['raw_sha256']
        logs[row['job_id']] = raw.decode()
    fence = logs[130461335389]
    assert 'local_control_inventory_unavailable' in fence
    assert '[command]git checkout' not in fence
    for job in [130461514712, 130461514922, 130461514980, 130461514744]:
        assert MERGE in logs[job]
    left = normalized_blocks(logs[130461514712], MODEL)
    right = normalized_blocks(logs[130461514922], MODEL)
    assert len(left) == len(right) == 8
    assert [row['sha256'] for row in left] == [row['sha256'] for row in right]
    assert len({row['sha256'] for row in left}) == 6
    assert left[-2]['sha256'] == left[2]['sha256'] and left[-1]['sha256'] == left[5]['sha256']
    infer = normalized_blocks(logs[130461514980], INFER)
    neuron = normalized_blocks(logs[130461514980], NEURON)
    hardlink = normalized_blocks(logs[130461514744], HARDLINK)
    assert len(infer) == len(neuron) == 2
    assert len({row['sha256'] for row in infer}) == len({row['sha256'] for row in neuron}) == 1
    assert len(hardlink) == 4 and len({row['sha256'] for row in hardlink}) == 3
    assert hardlink[-1]['sha256'] == hardlink[2]['sha256']
    receipt = json.loads(data['derived/SIGNED_CREDIT_RECEIPT_FROM_RAW.json'])
    assert receipt['source_sha'] == receipt['tested_sha'] == HEAD
    assert receipt['status'] == 'passed' and receipt['command_exit_code'] == receipt['exit_code'] == 0
    assert receipt['observed_passed_tests'] == receipt['named_pass_rows'] == 1 and receipt['observed_failed_tests'] == 0
    assert receipt['command'][-2:] == ['--retries', '0']
    assert all(receipt[key]['commit'] == HEAD and receipt[key]['tree'] == TREE and receipt[key]['dirty'] is False for key in ['before', 'after'])
    for name in ['model', 'infer']:
        prefix = 'patches/' + name + '/'
        capsule = json.loads(data[prefix + 'SOURCE_CAPSULE.json'])
        row = capsule['files'][0]
        before = data[prefix + 'preimage.rs']
        after = data[prefix + 'postimage.rs']
        assert metadata(before)['git_blob'] == row['preimage_git_blob']
        assert metadata(after)['git_blob'] == row['postimage_git_blob']
        assert apply_patch(before.decode(), data[prefix + 'CANDIDATE.patch'].decode()).encode() == after
        assert capsule['native_tests_executed'] == 0 and capsule['formatted'] is False
    return {'status': 'passed', 'members': len(members), 'full_raw_logs': len(logs),
            'source_head': HEAD, 'source_tree': TREE, 'tested_pr_merge': MERGE,
            'linux_unique_normalized_failure_payloads': 6, 'linux_job_observations': 2,
            'independent_linux_executions_not_inferred_from_job_count': True,
            'windows_shard3_unique_failure_payloads': 2,
            'windows_shard4_unique_failure_payloads': 3,
            'signed_credit_observed_passes': 1, 'whole_ci_pass': False,
            'candidate_native_tests_executed': 0}

if __name__ == '__main__':
    print(json.dumps(verify(sys.argv[1]), indent=2))
