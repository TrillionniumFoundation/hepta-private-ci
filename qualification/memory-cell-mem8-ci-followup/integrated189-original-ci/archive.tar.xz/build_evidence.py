import io
import json
import lzma
import re
import tarfile
from pathlib import Path

from verify_evidence import HARDLINK, HEAD, INFER, MERGE, MODEL, NEURON, TREE, metadata, normalized_blocks, verify

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
files = {}

def add(name, path):
    assert name not in files
    files[name] = Path(path).read_bytes()

raw_rows = []
logs = {}
for job, relative, encoded in [
    (130461335389, 'job-130461335389-decoded.log', False),
    (130461514712, 'linux-failures/job-130461514712-decoded.log.xz', True),
    (130461514922, 'linux-failures/job-130461514922-decoded.log.xz', True),
    (130461514980, 'windows-shard3/job-130461514980-decoded.log.xz', True),
    (130461514744, 'windows-shard4/job-130461514744-decoded.log.xz', True),
    (130461333221, 'windows-private/job-130461333221-decoded.log.xz', True),
]:
    name = 'logs/' + Path(relative).name
    add(name, ROOT / relative)
    raw = lzma.decompress(files[name]) if encoded else files[name]
    logs[job] = raw.decode()
    raw_rows.append({'job_id': job, 'path': name, 'encoding': 'xz' if encoded else 'utf-8',
                     'raw_bytes': len(raw), 'raw_sha256': metadata(raw)['sha256'],
                     'stored_bytes': len(files[name]), 'stored_sha256': metadata(files[name])['sha256']})

snapshot = json.loads((ROOT / 'FIFTH_CHECK_SNAPSHOT.json').read_text())
for relative in ['FIFTH_CHECK_SNAPSHOT.json', 'CI_MERGE_COMMIT.json', 'BLOB_FAILURE_REVIEW.json']:
    add('records/' + relative, ROOT / relative)
for prefix in ['linux-failures', 'windows-shard3', 'windows-shard4', 'windows-private']:
    add('records/' + prefix + '-FULL_RAW_READBACK.json', ROOT / prefix / 'FULL_RAW_READBACK.json')
add('derived/SIGNED_CREDIT_RECEIPT_FROM_RAW.json', ROOT / 'SIGNED_CREDIT_RECEIPT_FROM_RAW.json')

all_blocks = {
    'schema': 'mem8.ci-failure-block-observations.v1',
    'normalization': 'Remove only outer Actions timestamp prefixes and ANSI CSI sequences, then compare UTF-8 blocks from the exact case stdout header through its libtest summary. The full original logs remain unchanged.',
    'model': {str(job): normalized_blocks(logs[job], MODEL) for job in [130461514712, 130461514922]},
    'infer': normalized_blocks(logs[130461514980], INFER),
    'neuron': normalized_blocks(logs[130461514980], NEURON),
    'hardlink': normalized_blocks(logs[130461514744], HARDLINK),
    'remote_control': {str(job): normalized_blocks(logs[job], 'suite::v2::remote_control::stdio_eof_exits_with_remote_control_connection') for job in [130461514712, 130461514922]},
}
files['derived/FAILURE_BLOCKS.json'] = (json.dumps(all_blocks, indent=2) + '\n').encode()

for name, directory, source_path in [
    ('model', 'mem-model-list-wire-cache-repair-189711', 'codex-rs/app-server/tests/suite/v2/model_list.rs'),
    ('infer', 'mem-infer-physical-observation-repair-189711', 'codex-rs/hepta-infer-core/src/durable_control_tests.rs'),
]:
    source = WORKSPACE / directory
    for relative in ['CANDIDATE.patch', 'SOURCE_CAPSULE.json', 'ACTUAL_GIT_PUBLICATION.json']:
        add('patches/' + name + '/' + relative, source / relative)
    add('patches/' + name + '/preimage.rs', source / 'original' / source_path)
    add('patches/' + name + '/postimage.rs', source / 'source' / source_path)
for relative in ['STATIC_AUDIT.json', 'PINNED_CAUSAL_SOURCES.json', 'EXPERIMENT_PEER_REVIEW.json']:
    add('patches/model/' + relative, WORKSPACE / 'mem-model-list-wire-cache-repair-189711' / relative)
for relative in ['STATIC_AUDIT_V2.json', 'WINDOWS_ACCESS_SOURCE.json']:
    add('patches/infer/' + relative, WORKSPACE / 'mem-infer-physical-observation-repair-189711' / relative)

counts = {}
for record in snapshot['records']:
    values = {}
    for job in record['data']['jobs']:
        label = job['conclusion'] or job['status']
        values[label] = values.get(label, 0) + 1
    counts[record['kind']] = values
index = {
    'schema': 'mem8.integrated189.original-ci-evidence.v1',
    'source_head': HEAD, 'source_tree': TREE, 'tested_pr_merge': MERGE,
    'scope': 'Original terminal failures and current snapshot for the first 69-path repair source; no old2ae runs are included.',
    'blocking_run': 43002359918,
    'snapshot_observed_at': snapshot['observed_at'], 'snapshot_counts': counts,
    'raw_logs': raw_rows,
    'failures': [
        {'job_id': 130461335389, 'class': 'pre-checkout Fence infrastructure', 'evidence': 'local_control_inventory_unavailable; resident service failed before readiness; checkout and blob policy did not run', 'source_defect_proven': False, 'root_rerun_request': 'Root reports one job-rerun API attempt was rejected403 because the containing run was still running; no new run attempt is claimed; its request is not copied into this archive.'},
        {'job_id': 130461514712, 'class': 'model-list cache barrier fixture', 'targets': ['//codex-rs/app-server:app-server-all-test', '//codex-rs/app-server:app-server-all-wine-exec-test'], 'case': MODEL, 'causal_review': 'patches/model/STATIC_AUDIT.json'},
        {'job_id': 130461514922, 'class': 'second job observation of identical Linux failure payloads', 'targets': ['//codex-rs/app-server:app-server-all-test', '//codex-rs/app-server:app-server-all-wine-exec-test'], 'case': MODEL, 'independent_execution_not_inferred': True},
        {'job_id': 130461514980, 'class': 'two Windows targets', 'cases': [INFER, NEURON], 'infer': 'Original append-only fixture truncation fails with OS5 before the corruption assertions; test-only candidate is included, no native success claimed.', 'neuron': 'Observed CommitUncertain vs expected Conflict at cell_generation_control_tests.rs:381; cause remains pending independent review.'},
        {'job_id': 130461514744, 'class': 'Windows hard-link write refusal assertion', 'case': HARDLINK, 'evidence': 'Expected Windows refusal for an existing hard link outside workspace; tool returned exit0 and updated hard-link.txt. Three distinct attempt payloads plus one final reprint. No root cause or fix is claimed here.'},
    ],
    'counting_boundaries': [
        'GNU and musl jobs each contain the same eight normalized model stdout blocks: six distinct payloads and two final reprints. The two job labels are not treated as twelve independent executions.',
        'Each model-list failed shard reports52 passed/1 failed/0 ignored/968 filtered; these are shard observations, not a complete suite count.',
        'Windows shard3 infer is37 passed/1 failed/1 ignored. Neuron failing shard is70 passed/1 failed/115 filtered; its other two printed shards are79 passed and36 passed. Final tails reprint original failures.',
        'Windows shard4 hard-link case has3 distinct reported attempts, each67 passed/1 failed/1 ignored/1057 filtered. The tail repeats the final attempt.',
        'Bazel Executed/targets/skipped numbers are retained literally in raw logs and never added to libtest or nextest case counts.',
        'The remote-control WebSocket handshake error is also present in one original block per Linux job; final target persistence is not inferred from this emitted block alone.',
    ],
    'windows_private_success': {
        'run_id': 43002359628, 'job_id': 130461333221,
        'signed_case_pass': 1, 'signed_case_fail': 0, 'filtered': 270, 'retries': 0,
        'exact_source_before_after_clean': True,
        'receipt_provenance': 'Parsed from the complete original job output. The separately uploaded workflow artifact has not been independently downloaded by this packager.',
    },
    'candidate_source': {'model_post_blob': '0295b921099f63f245953eafd9b377db435184a9', 'infer_post_blob': '83430468bd935407208061f07b382015836f26a4', 'infer_latest_audit_blob': '88a1cfe6fe9f53cfbc034a2bffd8df68e8fc595b', 'native_tests_executed': 0, 'formatted': False, 'published_ref_modified': False},
    'whole_ci_pass': False,
}
files['INDEX.json'] = (json.dumps(index, indent=2) + '\n').encode()
files['README.md'] = ('''# Original CI evidence for integrated source 189711

This archive retains complete original logs for five failed jobs and the completed Windows private-state job. It includes the exact source/merge identities, a bounded snapshot of remaining jobs, reproducible failure-payload deduplication, and two source-only fixture repair candidates.

The GNU and musl logs observe the same six distinct model-list failure payloads. Each also prints two final tails; the second job is not additional independent evidence for another six executions. Windows shard3 tails also repeat original payloads. Windows shard4 reports three hard-link assertion attempts and then repeats the final attempt.

The model-list repair corrects the expected wire-decoded catalog without changing the request limit, full comparison, assertions, or shared deadline. The infer negative control creates a fresh read/write descriptor for deliberate same-length corruption and uses the existing private replay/lock path. Product append permissions and all observation assertions remain unchanged. Both are unformatted, uncompiled candidates at this checkpoint.

The Windows signed-credit case passed1/failed0 with270 filtered cases and zero retries on exact189711/treee253, clean before and after. Its receipt in this archive is derived from the full job log, not a separately downloaded artifact.

No whole-CI pass, complete independent platform sweep, scientific MEM gain, or model/owner custody result is claimed. The snapshot still has running jobs. Old2ae failures and this source remain separate.

Run `python3 verify_evidence.py ARCHIVE.tar.xz` to verify every member, nested full raw hash, source identities, failure deduplication, the embedded signed-credit receipt, and both exact patch replays. Verification launches no native tests or network requests.
''').encode()
add('verify_evidence.py', ROOT / 'verify_evidence.py')
add('build_evidence.py', ROOT / 'build_evidence.py')
manifest = {'schema': 'mem8.integrated189.original-ci-evidence.manifest.v1', 'source_head': HEAD, 'source_tree': TREE, 'files': [{'path': name, **metadata(data)} for name, data in sorted(files.items())]}
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
files['MANIFEST.json'] = manifest_bytes
archive_path = ROOT / 'mem8-integrated189-original-ci-and-fixture-repairs-v1.tar.xz'
with tarfile.open(archive_path, 'w:xz', preset=9) as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
assert archive_path.stat().st_size <= 1024 * 1024
(ROOT / 'MANIFEST.json').write_bytes(manifest_bytes)
result = verify(archive_path)
(ROOT / 'OFFLINE_VERIFICATION.json').write_text(json.dumps(result, indent=2) + '\n')
info = {'archive': archive_path.name, **metadata(archive_path.read_bytes()), 'members': len(files), 'manifest': metadata(manifest_bytes), 'offline_verification': result}
(ROOT / 'ARCHIVE_INFO.json').write_text(json.dumps(info, indent=2) + '\n')
print(json.dumps(info, indent=2))
