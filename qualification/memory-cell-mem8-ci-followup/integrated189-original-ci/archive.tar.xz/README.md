# Original CI evidence for integrated source 189711

This archive retains complete original logs for five failed jobs and the completed Windows private-state job. It includes the exact source/merge identities, a bounded snapshot of remaining jobs, reproducible failure-payload deduplication, and two source-only fixture repair candidates.

The GNU and musl logs observe the same six distinct model-list failure payloads. Each also prints two final tails; the second job is not additional independent evidence for another six executions. Windows shard3 tails also repeat original payloads. Windows shard4 reports three hard-link assertion attempts and then repeats the final attempt.

The model-list repair corrects the expected wire-decoded catalog without changing the request limit, full comparison, assertions, or shared deadline. The infer negative control creates a fresh read/write descriptor for deliberate same-length corruption and uses the existing private replay/lock path. Product append permissions and all observation assertions remain unchanged. Both are unformatted, uncompiled candidates at this checkpoint.

The Windows signed-credit case passed1/failed0 with270 filtered cases and zero retries on exact189711/treee253, clean before and after. Its receipt in this archive is derived from the full job log, not a separately downloaded artifact.

No whole-CI pass, complete independent platform sweep, scientific MEM gain, or model/owner custody result is claimed. The snapshot still has running jobs. Old2ae failures and this source remain separate.

Run `python3 verify_evidence.py ARCHIVE.tar.xz` to verify every member, nested full raw hash, source identities, failure deduplication, the embedded signed-credit receipt, and both exact patch replays. Verification launches no native tests or network requests.
