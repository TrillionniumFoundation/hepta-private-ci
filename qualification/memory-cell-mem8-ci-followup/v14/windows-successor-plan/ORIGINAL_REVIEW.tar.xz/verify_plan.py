#!/usr/bin/env python3
"""Verify this static plan packet without importing or running its native driver."""
import ast
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def read_json(path):
    return json.loads((ROOT / path).read_bytes())

def check(condition, message):
    if not condition:
        raise ValueError(message)

manifest = read_json("FILE_MANIFEST.json")
rows = manifest["members"]
check(len({row["path"] for row in rows}) == len(rows), "duplicate member path")
for row in rows:
    path = Path(row["path"])
    check(not path.is_absolute() and ".." not in path.parts, "unsafe member")
    raw = (ROOT / path).read_bytes()
    check(len(raw) == row["bytes"], "member size: " + row["path"])
    check(hashlib.sha256(raw).hexdigest() == row["sha256"], "member SHA: " + row["path"])
    check(blob(raw) == row["gitBlob"], "member Git blob: " + row["path"])
files = {str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file()}
check(files == {r["path"] for r in rows} | {"FILE_MANIFEST.json"}, "unexpected packet files")

plan = read_json("PLAN.json")
check(plan["status"] == "REVIEW_ONLY_NOT_IMPLEMENTED_NOT_ADMITTED", "not a static plan")
check(plan["source"]["head"] == "9bd2f589debdba4a93baa363817c3669cb103721", "wrong head")
check(plan["source"]["tree"] == "c77785ecb368c44ea699769001a47402c9f50591", "wrong tree")
for row in plan["sourcePins"]:
    raw = (ROOT / "source" / row["path"]).read_bytes()
    check(len(raw) == row["bytes"] and blob(raw) == row["gitBlob"], "source pin")
    check(hashlib.sha256(raw).hexdigest() == row["sha256"], "source SHA")

scope = read_json("source/.github/fixtures/windows-current-ci-scope.json")
groups = scope["groups"]
check(len(groups) == 19, "original group count")
check(scope["policy"] == plan["frozenOriginalScope"]["metadata"]["policy"], "policy changed")
check(scope["policy"]["testRetries"] == 0 and scope["policy"]["testThreads"] == 1, "policy")
check(len({g["id"] for g in groups}) == 19, "duplicate original group")
for group in groups:
    check(group["expectedTestCount"] == len(group["requiredTests"]), "count differs")
extra = plan["supplementalGroup"]
all_groups = groups + [extra]
case_rows = [
    {"group": g["id"], "package": g["package"], "test": test}
    for g in all_groups for test in g["requiredTests"]
]
expected = read_json("EXPECTED_CASES.json")
check(case_rows == expected["cases"], "full ordered case set differs")
identities = [(x["package"], x["test"]) for x in case_rows]
check(len(identities) == len(set(identities)) == 170, "170 identity union")
check(sum(g["expectedTestCount"] for g in groups) == 167, "original 167")
check(extra["expectedTestCount"] == 3, "extra 3")

seen = []
partition_sizes = {}
mapping = {g["id"]: g for g in all_groups}
for part in plan["proposedPartitions"]:
    ids = part["groupIds"]
    seen.extend(ids)
    check([groups[i-1]["id"] for i in part["originalOrdinals"]] == part["originalGroups"], "ordinal mapping")
    check(part["originalOrdinals"] == sorted(part["originalOrdinals"]), "original ordering")
    count = sum(mapping[name]["expectedTestCount"] for name in ids)
    check(count == part["total"], "partition count")
    partition_sizes[part["id"]] = count
check(len(seen) == len(set(seen)) == 20 and set(seen) == set(mapping), "partition union")
check(partition_sizes == {"storage-owner":93, "core-session":14, "sandbox-runner":41, "exec-wire":22}, "partitions")

commands = read_json("EXACT_COMMANDS.json")["commands"]
check(len(commands) == 20, "command count")
for group, command in zip(all_groups, commands):
    argv = ["just","test","--locked","-p",group["package"],"--lib",
            "--cargo-profile","dev-small","-E",group["filter"],
            "--test-threads","1","--no-tests","fail","--retries","0"]
    check(command == {"group":group["id"],"cwd":"<exact-source>/codex-rs","argv":argv}, "changed original command")
check(extra["filter"] == " | ".join("test(=" + t + ")" for t in extra["requiredTests"]), "supplemental filter")

driver = (ROOT/"source/.github/scripts/windows_current_ci.py").read_text()
tree = ast.parse(driver)
functions = {n.name:n for n in tree.body if isinstance(n, ast.FunctionDef)}
check([a.arg for a in functions["execute_groups"].args.args] == ["root","output","groups","invoke"], "existing API")
check([a.arg for a in functions["prepare_sandbox_helpers"].args.args] == ["root","output"], "helper API")
check(isinstance(functions["execute_groups"].args.defaults[-1], ast.Constant) and functions["execute_groups"].args.defaults[-1].value is None, "native invoke default")
check('root = Path(__file__).resolve().parents[2]' in driver, "main root contract")
case_source = (ROOT/"source/codex-rs/exec-server/src/windows_restricted_write_tests.rs").read_text()
names = re.findall(r"#\[tokio::test\]\s*async fn\s+(\w+)", case_source)
check(["windows_restricted_write::tests::" + n for n in names] == extra["requiredTests"], "actual new source cases")
check(not plan["separateRequiredCoverage"]["enabledCoreHardlink"]["includedIn170"], "integration must stay separate")

old = read_json("original/groups.json")
check(len(old) == 15 and sum(g["selectedTestCount"] for g in old) == 139, "old completion")
check(sum(bool(g["passed"]) for g in old) == 13, "old strict groups")
for actual, original in zip(old, groups):
    check(actual["id"] == original["id"], "old group order")
    check(actual["observedTests"] == sorted(original["requiredTests"]), "old selected IDs")
    check(actual["selectedTestCount"] == original["expectedTestCount"], "old count")
    check(actual["command"] == next(c["argv"] for c in commands if c["group"] == actual["id"]), "old argv differs")
ansi = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
observed = set()
for filename in ["sandbox-original-failures.log", "sandbox-native-delete-routes.log"]:
    raw = (ROOT/"original"/filename).read_text()
    for status, package, case in re.findall(r"^\s*(PASS|FAIL|TIMEOUT|EXECFAIL|LEAK|SKIP)\s+\[[^\]\n]+\]\s+(?:\(\s*\d+/\d+\)\s+)?(\S+)\s+(\S+)\s*$", ansi.sub("",raw), re.MULTILINE):
        if status != "PASS":
            observed.add((status,package,case))
expected_errors = {(x["terminal"],x["package"],x["test"]) for x in plan["historicalOriginal"]["knownNonPassing"]}
check(observed == expected_errors, "old terminal labels")
durations = read_json("original/ORIGINAL_DURATIONS.json")
check(durations["groups_raw_sha256"] == hashlib.sha256((ROOT/"original/groups.json").read_bytes()).hexdigest(), "duration origin")
check(durations["helper_build_duration_seconds"] == 818.656, "helper timing")
check(len(durations["groups"]) == 15, "timing count")
check(plan["execution"] == {"newWindowsProcesses":0,"newHostProbes":0,"newNativeTests":0,"newModelRequests":0,"newCITriggers":0,"sourceRefsChanged":False,"sourceModified":False,"oldCampaignResumed":False}, "execution boundary")
print(json.dumps({"status":"PASS_OFFLINE_STATIC_PLAN_CONSISTENCY_ONLY",
    "members":len(rows)+1,"sourcePins":len(plan["sourcePins"]),"originalGroups":19,
    "originalCases":167,"supplementalCases":3,"combinedIdentities":170,
    "partitions":partition_sizes,"nativeTestsExecuted":0,"newCITriggers":0,
    "treeRecomputedFromFullRepository":False}, sort_keys=True))
