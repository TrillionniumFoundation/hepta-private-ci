"""Read-only validation of this source/ACL evidence packet; never executes repository code."""
import hashlib
import json
from pathlib import Path
import re
import struct
import sys

def info(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}

def main():
    root = Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else Path(__file__).resolve().parent
    manifest = json.loads((root / "FILE_MANIFEST.json").read_text())
    expected = {x["path"]: x for x in manifest["members"]}
    assert len(expected) == len(manifest["members"])
    actual = set()
    for path in root.rglob("*"):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            actual.add(relative)
            if relative == "FILE_MANIFEST.json":
                continue
            assert relative in expected, relative
            data = path.read_bytes()
            assert info(data) == {k: expected[relative][k] for k in ("bytes", "sha256", "git_blob")}, relative
    assert actual == set(expected) | {"FILE_MANIFEST.json"}
    source = json.loads((root / "SOURCE_INDEX.json").read_text())
    for item in source["sources"]:
        data = (root / "source" / item["path"]).read_bytes()
        assert info(data) == {k: item[k] for k in ("bytes", "sha256", "git_blob")}
    original = json.loads((root / "ORIGINAL_ACL_AUDIT.json").read_text())
    raw = (root / "original/sandbox-native-delete-routes.log").read_bytes()
    assert info(raw) == {k: original["original_raw"][k] for k in ("bytes", "sha256", "git_blob")}
    decoded = []
    for number, line in enumerate(raw.decode().splitlines(), 1):
        if "delete_matrix elevated-child-done path=" not in line:
            continue
        path = json.loads(re.search(r'path=(".*?") identity=', line).group(1))
        data = bytes(int(x.strip(), 16) for x in re.search(r"acl=\[([0-9a-f, ]+)\]", line).group(1).split(","))
        assert len(data) == struct.unpack_from("<H", data, 2)[0]
        offset = 8
        aces = []
        for _ in range(struct.unpack_from("<H", data, 4)[0]):
            kind, flags, length, mask = struct.unpack_from("<BBHI", data, offset)
            sid_bytes = data[offset + 8:offset + length]
            revision, count = sid_bytes[:2]
            assert len(sid_bytes) == 8 + 4 * count
            authority = int.from_bytes(sid_bytes[2:8], "big")
            sid = f"S-{revision}-{authority}"
            sid += "".join(f"-{struct.unpack_from('<I', sid_bytes, 8 + i * 4)[0]}" for i in range(count))
            aces.append({"type": kind, "flags": flags, "mask": mask, "mask_hex": hex(mask), "sid": sid})
            offset += length
        assert offset == len(data)
        route = re.search(r"\\outside\\(Neither|TargetOnly|ParentOnly|Both)(?:\\(file|directory))?$", path)
        state = re.search(r"directory=(\d+) pending=(\d+) links=(\d+)", line)
        decoded.append({"raw_line": number, "path": path, "route": route.group(1),
                        "object": route.group(2) or "parent", "directory": int(state.group(1)),
                        "delete_pending": int(state.group(2)), "links": int(state.group(3)),
                        "acl_bytes": len(data), "aces": aces})
    assert decoded == original["observed_acls"]
    assert len(decoded) == 12
    assert {ace["sid"] for item in decoded for ace in item["aces"]} == {"S-1-1-0"}
    print(json.dumps({"status": "PASS_OFFLINE_PACKET_CONSISTENCY_ONLY",
                      "members": len(actual), "exact_source_files": len(source["sources"]),
                      "original_acl_objects": len(decoded), "native_tests_executed": 0,
                      "model_requests_executed": 0}, sort_keys=True))

if __name__ == "__main__":
    main()
