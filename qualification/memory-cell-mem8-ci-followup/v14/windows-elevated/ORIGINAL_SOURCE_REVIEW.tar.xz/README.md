# Elevated outside-delete: exact189 product closure review

## Result

The Windows-current elevated path remains unqualified for its outside-delete boundary. This packet contains the original 27,138-byte native log, independent decoding of its 12 outside-object ACLs, and 22 exact repository source files. It contains no production patch, host probe, native rerun, provider request, or source-ref change.

The original child actually deleted both files and directories in TargetOnly, ParentOnly and Both; Neither remained. The ordinary-host control behaved as intended. This is separate from the Bazel ordinary-host Neither failure.

## What the source establishes

The typed elevated path resolves its profile and active workspace roots, then sends their capability SIDs to the dedicated-account runner. Both elevated token factories add the token user to the restricting list, and their common Include branch adds Logon and Everyone. The original outside ACLs contain only Everyone. Restricting principals offer alternative ACE matches in the second access check; they are not an additional mandatory workspace-capability conjunction. Thus the source exposes a concrete broad-identity alternative consistent with the original result. The original log does not contain the child token's actual restricting list, flags or privileges, so this is not an invented dynamic token trace.

Removing only Everyone leaves user and Logon. Removing all three still leaves an independent known issue: this exact source's legacy_admission.rs records the native FILE_DELETE_CHILD bypass under WRITE_RESTRICTED. No narrow SID edit has been qualified to repair ParentOnly.

## Why a complete replacement needs more than changing one flag

Current read ACL setup grants the sandbox-users group, or skips a root when built-in identities already grant read access. Workspace token inputs carry active write-root capabilities, not a read-capability closure for all permitted system, runtime and source paths. Dropping WRITE_RESTRICTED while removing broad identity would therefore remove valid reads. Putting the shared sandbox-users group in the restricting list would reuse broad and potentially stale write grants. The current read helper also runs asynchronously; its mutex is not a per-request completion receipt.

A full-restriction design needs explicit read-only capability grants for the original read/execute contract, active-profile scoping and a real admission point after required grants finish. It must preserve deny-read propagation and must not turn a network identity into a filesystem capability.

## Existing compatibility paths and their limits

The original dedicated-account runner opens the parent IPC pipes before deriving the restricted child token. Stdio is handed to the child through an explicit inherited-handle list. The token default DACL grants child-created objects to capabilities separately from the restricting list. These are useful existing interfaces; they do not establish that an unrun new token preserves all PowerShell, pipe or ConPTY behavior.

The private desktop implementation already creates an owned desktop and grants selected restricting SIDs. Core defaults to private=true. Explicit false currently rejects a cap-only token and must not be silently forced to a different profile. Removing Logon causes the present helper to copy every remaining restricting SID, including a network route identity, into DESKTOP_ALL_ACCESS. The old two-capability test lacks a shared route identity and does not spawn a real child or prove WinSta0 access. A replacement must distinguish desktop capabilities from route identity and retain exact private-object isolation.

The WFP offline account condition uses ALE_USER_ID and an account security descriptor. The documented filter match tests FWP_ACTRL_MATCH_FILTER. Retaining a route marker in TokenRestrictedSids is not evidence that all block/allow conditions still match the final token. No network bypass is claimed here; the missing compatibility proof is explicit.

## Small safe option versus restored capability

An early typed isolation-unavailable refusal can prevent the unqualified elevated execution. The first public flow gates belong before side effects in elevated_impl.rs::windows_impl::run_windows_sandbox_capture_for_permission_profile and unified_exec/backends/elevated.rs::spawn_windows_sandbox_session_elevated_for_permission_profile. Direct runner entry and caller error propagation would also need a closed-path check. Such a change would make the feature unavailable; it would not restore it. This packet deliberately does not change the original positive controls, outside-delete assertions or time budgets into success claims.

No partial production patch is recommended for merge from this review. The concrete open conditions and source locations are enumerated in PRODUCT_CLOSURE_REVIEW.json.

## Evidence use

SOURCE_INDEX.json binds every full source file to exact189 Git identity. ORIGINAL_ACL_AUDIT.json binds all 12 decoded ACLs to the original raw bytes and retains the actual file/link state. FILE_MANIFEST.json and verify_packet.py permit offline whole-packet verification. A successful verifier result means artifact consistency only, never Windows native success.

Microsoft primary references are listed in PRIMARY_REFERENCES.json. The earlier root V3/V4 execution states and MEM owner/provider/scientific gates are unaffected.
