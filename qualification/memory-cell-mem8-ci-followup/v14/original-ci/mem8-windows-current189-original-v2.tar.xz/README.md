# mem8-windows-current189-terminal-v1

Original run43002359812/job130461336393 ended cancelled after approximately65min. Complete22-member original artifact and job log; expected19groups/167cases, completed15groups/139unique native cases=137PASS+1LEAK+1FAIL, strict13groups pass. Group16 interrupted while compiling, last3groups not started;28expected cases uncompleted. Exact source-before is clean; source-after/finalaggregate absent. Nine Python receipt-control tests and two synthetic receipts are separate. Run verify_original.py on the extracted directory for independent case/UUID/receipt audit.

Original bytes are preserved. Derived audits are identified by their filenames. Run `python3 verify_archive.py ARCHIVE.tar.xz` to check every regular member, compressed original log, source identity, and included ZIP. This verifier does not execute native tests or models.

## Corrected failure boundary

The original ordinary-host four-cell control passes in this Windows-current run. The explicit elevated child deletes outside objects in TargetOnly, ParentOnly and Both, while Neither survives; the original all-false outside assertion fails at line125. This differs from the separate Bazel ordinary-host Neither failures. The earlier agent message conflating those boundaries is withdrawn in FAILURE_CLASSIFICATION_ERRATUM.json. All original logs, ZIP members and receipts are unchanged. The separately observed LEAK is a different test/process identity; its exact leaked resource remains unknown.
