import collections
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
artifact = root / 'artifact'
def read_json(name):
    return json.loads((root / name).read_text())
def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
source = json.loads((artifact / 'source-before.json').read_text())
assert source['head'] == '189711e3563ea13a5328d52e99a286f082045b98'
assert source['tree'] == 'e253b99e0a5c3b3a680569da0d224fabff0781ba'
assert source['trackedChanges'] == ''
for n in ['EXACT_SCOPE_SOURCE.json', 'EXACT_WORKFLOW_SOURCE.json', 'EXACT_DRIVER_SOURCE.json']:
    a = read_json(n)
    assert blob(a['content'].encode()) == a['sha']
scope = json.loads(read_json('EXACT_SCOPE_SOURCE.json')['content'])
expected = scope['groups']
progress = json.loads((artifact / 'groups.json').read_text())
assert len(expected) == 19
assert len(progress) == 15
assert [r['id'] for r in progress] == [r['id'] for r in expected[:15]]
raw = (root / 'job-130461336393-decoded.log').read_bytes()
raw_binding = read_json('RAW_READBACK.json')
assert len(raw) == raw_binding['raw_bytes']
assert hashlib.sha256(raw).hexdigest() == raw_binding['raw_sha256']
job_receipts = []
for line in raw.decode().splitlines():
    body = re.sub(r'^\S+Z ', '', line)
    if not body.startswith('{'):
        continue
    try:
        value = json.loads(body)
    except ValueError:
        continue
    if isinstance(value, dict) and value.get('id') in {r['id'] for r in expected}:
        job_receipts.append(value)
assert job_receipts == progress
rows = []
observed = []
filtered = 0
for want, got in zip(expected, progress):
    text = (artifact / (want['id'] + '.log')).read_text()
    uuids = re.findall(r'Nextest run ID ([0-9a-f-]{36}) with nextest profile: local', text)
    assert len(uuids) == 1, want['id']
    summaries = re.findall(r'^\s*Summary \[.*$', text, re.M)
    assert len(summaries) == 1
    segment = text.split(summaries[0], 1)[0]
    cases = re.findall(r'^\s*(PASS|FAIL|LEAK|TIMEOUT)\s+\[\s*[\d.]+s\]\s+(\S+)\s+(.+)$', segment, re.M)
    assert len(cases) == want['expectedTestCount'] == got['selectedTestCount']
    assert {x[2] for x in cases} == set(want['requiredTests']) == set(got['observedTests'])
    assert all(x[1] == want['package'] for x in cases)
    assert len({(x[1], x[2]) for x in cases}) == len(cases)
    assert got['selectionMatches'] is True and got['missingRequiredTests'] == []
    nonpassing = sorted(x[2] for x in cases if x[0] != 'PASS')
    assert nonpassing == sorted(got['nonPassingTests'])
    assert got['passed'] == (not nonpassing and got['exitCode'] == 0)
    argv = got['command']
    assert argv[argv.index('--retries') + 1] == '0'
    assert argv[argv.index('--no-tests') + 1] == 'fail'
    assert argv[argv.index('--test-threads') + 1] == '1'
    count = int(re.search(r'(\d+) tests? run:', summaries[0])[1])
    skip = int(re.search(r'(\d+) skipped', summaries[0])[1])
    assert count == len(cases)
    filtered += skip
    observed.extend(cases)
    rows.append({'id': want['id'], 'package': want['package'], 'nextest_run_id': uuids[0], 'actual_case_count': count, 'statuses': dict(collections.Counter(x[0] for x in cases)), 'filtered_skips': skip, 'strict_receipt_passed': got['passed'], 'receipt_exit_code': got['exitCode'], 'duration_seconds': got['durationSeconds'], 'summary': summaries[0].strip(), 'cases': [{'status': s, 'binary': b, 'name': n} for s, b, n in cases]})
assert len(observed) == 139
assert len({(x[1], x[2]) for x in observed}) == 139
assert len({row['nextest_run_id'] for row in rows}) == 15
assert re.search(r'Ran 9 tests in [^\r\n]+', raw.decode())
status_counts = dict(collections.Counter(x[0] for x in observed))
assert status_counts == {'PASS': 137, 'LEAK': 1, 'FAIL': 1}
assert all(not (artifact / (r['id'] + '.log')).exists() for r in expected[16:])
partial = (artifact / 'exec-server-observation-wire.log').read_text()
assert 'Compiling windows-sys' in partial and 'KeyboardInterrupt' in partial
assert 'Nextest run ID' not in partial and not re.search(r'^\s*(PASS|FAIL|LEAK|TIMEOUT)\s+\[', partial, re.M)
assert not (artifact / 'source-after.json').exists()
zip_index = read_json('ZIP_MEMBERS.json')
with zipfile.ZipFile(root / 'windows-current-13851265558.zip') as z:
    assert z.testzip() is None
    assert len(z.namelist()) == 22
    for item in zip_index['members']:
        b = z.read(item['name'])
        assert len(b) == item['bytes'] and hashlib.sha256(b).hexdigest() == item['sha256']
        assert b == (artifact / item['name']).read_bytes()
audit = {
    'schema': 'hepta.mem8.windows-current189.original-audit.v1',
    'source_before': source,
    'run_id': 43002359812,
    'job_id': 130461336393,
    'run_attempt': 1,
    'terminal': 'cancelled',
    'job_started_at': '2026-11-11T10:17:29Z',
    'job_completed_at': '2026-11-11T11:22:40Z',
    'workflow_timeout_minutes': 65,
    'cancellation_evidence': 'Original raw ends with KeyboardInterrupt in execute_groups subprocess wait and operation was canceled; timing matches the pinned 65-minute job budget. The API does not expose a distinct cancel reason here, so timeout attribution is an inference rather than an independent scheduler receipt.',
    'expected_groups': 19,
    'expected_cases': sum(r['expectedTestCount'] for r in expected),
    'completed_groups': 15,
    'strict_passed_groups': sum(r['strict_receipt_passed'] for r in rows),
    'strict_nonpassing_groups': [r['id'] for r in rows if not r['strict_receipt_passed']],
    'actual_native_cases': 139,
    'distinct_package_and_case_ids': 139,
    'statuses': status_counts,
    'nextest_passed_including_leaky': 138,
    'filtered_skips_across_group_runs_not_additional_cases': filtered,
    'interrupted_group': {'id': expected[15]['id'], 'expected_cases': expected[15]['expectedTestCount'], 'actual_observed_tests': 0, 'state': 'compilation log interrupted before any observed nextest run or case terminal'},
    'not_started_groups': [{'id': r['id'], 'expected_cases': r['expectedTestCount']} for r in expected[16:]],
    'uncompleted_expected_cases': sum(r['expectedTestCount'] for r in expected[15:]),
    'python_receipt_controls_separate': {'actual_unittest_cases': 9, 'synthetic_receipts_named_original_and_second': 2, 'not_native_case_count': True},
    'source_after_or_final_aggregate': 'ABSENT: do not claim clean after or all-groups qualification',
    'original_artifact': zip_index,
    'raw_binding': raw_binding,
    'groups': rows,
    'verification': 'Complete 22-member ZIP read/CRC/hash; all 15 raw group receipts exactly match persisted progress; actual per-case lines precede their single nextest Summary, match all pinned required IDs and one fresh run UUID; repeated FAIL summary printing excluded.',
    'changes_or_reexecution': 0,
}
(root / 'ORIGINAL_AUDIT.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({k: audit[k] for k in ['terminal','expected_groups','expected_cases','completed_groups','strict_passed_groups','actual_native_cases','statuses','uncompleted_expected_cases','filtered_skips_across_group_runs_not_additional_cases']}))
