import base64
import collections
import hashlib
import io
import json
import lzma
import sys
import tarfile
import zipfile
from pathlib import PurePosixPath

def digest(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'git_blob': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}

path = sys.argv[1]
with tarfile.open(path, 'r:xz') as archive:
    rows = archive.getmembers()
    assert len({m.name for m in rows}) == len(rows)
    data = {}
    for m in rows:
        name = PurePosixPath(m.name)
        assert m.isfile() and not name.is_absolute() and '..' not in name.parts
        data[m.name] = archive.extractfile(m).read()
manifest = json.loads(data['MANIFEST.json'])
assert set(data) == {m['path'] for m in manifest['members']} | {'MANIFEST.json'}
for m in manifest['members']:
    got = digest(data[m['path']])
    assert all(got[k] == m[k] for k in got), m['path']
for path, content in data.items():
    if path.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            assert z.testzip() is None
            for member in z.infolist():
                q = PurePosixPath(member.filename)
                assert not q.is_absolute() and '..' not in q.parts
                if not member.is_dir():
                    z.read(member)
if 'RAW_LOG_INDEX.json' in data:
    for row in json.loads(data['RAW_LOG_INDEX.json']):
        raw = lzma.decompress(data[row['archive_path']])
        assert len(raw) == row['raw_bytes']
        assert hashlib.sha256(raw).hexdigest() == row['raw_sha256']
if 'VERIFIED_SOURCE_INDEX.json' in data:
    for row in json.loads(data['VERIFIED_SOURCE_INDEX.json']):
        source = json.loads(data['inputs/' + row['record']])['content'].encode()
        got = digest(source)
        assert all(got[k] == row[k] for k in got)
if 'SOURCE_CAPSULE.json' in data and 'EDITS_AND_INVERSE.json' in data:
    capsule = json.loads(data['SOURCE_CAPSULE.json'])
    edits = json.loads(data['EDITS_AND_INVERSE.json'])
    for row in capsule['files']:
        post = base64.b64decode(row['content_base64'], validate=True)
        assert post == data['source/' + row['path']]
        assert digest(post)['git_blob'] == row['postimage_git_blob']
        recovered = post.decode()
        for edit in reversed(edits[row['path']]):
            assert recovered.count(edit['new']) == 1
            recovered = recovered.replace(edit['new'], edit['old'], 1)
        assert recovered.encode() == data['preimages/' + row['path']]
        assert digest(recovered.encode())['git_blob'] == row['preimage_git_blob']
if 'ORIGINAL_ATTEMPT1_SNAPSHOT.json' in data:
    original = json.loads(data['ORIGINAL_ATTEMPT1_SNAPSHOT.json'])['blocking']
    assert original['total_count'] == len(original['jobs']) == 37
    assert collections.Counter(j['conclusion'] for j in original['jobs']) == {'success': 23, 'failure': 10, 'skipped': 4}
    mapping = json.loads(data['ATTEMPT2_JOB_MAPPING.json'])
    executions = [r for r in mapping if not r['skipped'] and not r['same_execution_times']]
    assert {r['attempt2_representative_id'] for r in executions} == {130483156553, 130483324196}
    assert sum(not r['skipped'] and r['same_execution_times'] for r in mapping) == 31
print(json.dumps({'archive': sys.argv[1], 'all_members_verified': len(data), 'verdict': 'PASS_OFFLINE_ARCHIVE_INTEGRITY_ONLY', 'native_or_model_execution': 0}))
