# mem8-integrated189-terminal-addendum-v1

Full original Mac Intel/ARM, Windows shard2 and aggregate logs, final attempt1 required summary, and actual second Fence/required executions. Original attempt1: 37 jobs=23 success/10 failure/4 skipped. Attempt2 API returns representative IDs for inherited jobs: only Blob and final required actually executed again; 31 other non-skipped jobs retain exact original execution times. Printed FAILED names are observations and may repeat or later pass; final target summaries remain separate. Prior 35-member evidence archive is unchanged.

Original bytes are preserved. Derived audits are identified by their filenames. Run `python3 verify_archive.py ARCHIVE.tar.xz` to check every regular member, compressed original log, source identity, and included ZIP. This verifier does not execute native tests or models.
