# mem8-fourcell189-diagnostic-candidate-v1

Three test-only diagnostic postimages with complete exact preimages, inverse edits, source capsule and independent peer review. Original token/ACL/delete operations and refusal assertions remain; no native run or formatter result. This is not a fix of the observed Neither deletion.

Original bytes are preserved. Derived audits are identified by their filenames. Run `python3 verify_archive.py ARCHIVE.tar.xz` to check every regular member, compressed original log, source identity, and included ZIP. This verifier does not execute native tests or models.
