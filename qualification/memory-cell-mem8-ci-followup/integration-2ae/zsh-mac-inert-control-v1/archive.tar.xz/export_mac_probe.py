import base64
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile


root = Path('/Users/qianqi/mem8-zsh-mac-inert-control-ed353817-v1')
inputs = Path('/Users/qianqi/mem8-zsh-mac-inert-inputs-ed353817-v1')


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()}


result = json.loads((root / 'RESULT.json').read_text())
assert result['run_id'] == 'mem8-zsh-mac-inert-control-ed353817-v1'
assert result['status'] == 'INCOMPLETE_OR_FAILED'
assert result['controls'] == []
assert result['finished_utc'] == '2026-11-11T09:34:56.193640+00:00'
files = {}
for path in sorted(root.iterdir()):
    if path.is_dir():
        assert path.name == 'dotslash-cache'
        continue
    assert not path.is_symlink()
    assert path.name in {'DRIVER.py', 'SOURCE_FIXTURE.zsh', 'RESULT.json',
                         'dotslash-version.json', 'dotslash-version.stdout', 'dotslash-version.stderr',
                         'dotslash-fetch.json', 'dotslash-fetch.stdout', 'dotslash-fetch.stderr'}
    assert path.stat().st_size <= 1024 * 1024
    files[path.name] = path.read_bytes()
assert len(files) == 9
assert identity(files['DRIVER.py'])['sha256'] == '85e9b3c3ab22906e838f13c96492d99f949f39b468ea3010cfd41cc422841bb6'
assert identity(files['SOURCE_FIXTURE.zsh'])['git_blob'] == 'f796fa7201e16c95009ea776fd78b67a0169c153'
receipts = []
for name in ('dotslash-version', 'dotslash-fetch'):
    receipt = json.loads(files[name + '.json'])
    for stream in ('stdout', 'stderr'):
        raw = files[receipt[stream]['path']]
        assert all(identity(raw)[key] == receipt[stream][key] for key in ('bytes', 'sha256', 'git_blob'))
    receipts.append({'path': name + '.json', 'exit_code': receipt['exit_code'],
                     'timed_out': receipt.get('timed_out', False)})
for name in ('DRIVER.py', 'SOURCE_FIXTURE.zsh'):
    data = (inputs / name).read_bytes()
    assert data == files[name]
    files['inputs/' + name] = data
manifest = {'schema': 'mem-zsh-mac-original-failed-control-members-v1',
            'scope': 'FETCH_FAILED_NO_ZSH_CONTROLS_EXECUTED_NOT_CI_REPRODUCTION',
            'original_job_id': '1a1c9f5686c-2564-3ad',
            'verified_original_command_receipts': receipts,
            'cache_excluded': True, 'post_identity_gate_reached': False,
            'members': [{'path': name, **identity(data)} for name, data in sorted(files.items())]}
files['MEMBER_MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
output = root / 'MAC_PROBE_EVIDENCE.tar.xz'
with output.open('xb') as stream:
    os.chmod(output, 0o600)
    with tarfile.open(fileobj=stream, mode='w:xz', preset=6) as tar:
        for name, data in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o600
            member.mtime = 0
            tar.addfile(member, io.BytesIO(data))
    stream.flush()
    os.fsync(stream.fileno())
data = output.read_bytes()
receipt = {'path': str(output), 'members': len(files), **identity(data),
           'verified_original_command_receipts': receipts}
with (root / 'MAC_PROBE_EVIDENCE_MANIFEST.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({'archive': receipt, 'archive_base64': base64.b64encode(data).decode()}), flush=True)
