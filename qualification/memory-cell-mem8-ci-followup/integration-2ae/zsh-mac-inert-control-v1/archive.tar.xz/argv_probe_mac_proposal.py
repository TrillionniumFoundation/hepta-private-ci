#!/usr/bin/env python3
"""Unexecuted proposal: pinned Mac ARM artifact, inert wrapper, owned directory."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


FIXTURE_GIT_BLOB = "f796fa7201e16c95009ea776fd78b67a0169c153"
FIXTURE_SHA256 = "6f94e90693a7c6dcdc57bd8044786a7cdd0ccaa32f1815d5a1e47c3ce8a49d81"
FIXTURE_BYTES = 2661
RUN = Path("/Users/qianqi/mem8-zsh-mac-inert-control-ed353817-v1")
DOTSLASH = Path("/opt/homebrew/bin/dotslash")
CONTROLS = (
    ("absolute", "/usr/bin:/bin"),
    ("actual_bazel_action_path", "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"),
    ("dot_first", ".:/usr/bin:/bin"),
    ("empty_first", ":/usr/bin:/bin"),
)


def identity(path):
    if not path.is_file() or path.stat().st_size > 16 * 1024 * 1024:
        raise RuntimeError("missing or unexpectedly large bounded input: " + str(path))
    data = path.read_bytes()
    return {
        "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob": hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest(),
    }


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: argv_probe_mac_proposal.py EXACT_DOTSLASH_FIXTURE")
    started = time.time()
    deadline = time.monotonic() + 60
    if sys.platform != "darwin" or os.uname().machine != "arm64":
        raise RuntimeError("this proposal is restricted to the observed Darwin arm64 host")
    RUN.mkdir(mode=0o700, exist_ok=False)
    os.chmod(RUN, 0o700)
    result = {
        "schema": "mem-zsh-mac-inert-control-v1",
        "run_id": "mem8-zsh-mac-inert-control-ed353817-v1",
        "scope": "PINNED_MAC_ARM_ARTIFACT_CONTROL_NOT_ORIGINAL_CI_ENVIRONMENT",
        "started_utc": datetime.fromtimestamp(started, timezone.utc).isoformat(),
        "budget_seconds": 60, "native_rust_tests_executed": 0,
        "model_requests_issued_by_driver": 0, "escalation_ipc_used": False,
        "source_provenance_only": {
            "repository": "TrillionniumFoundation/hepta-private-ci",
            "commit": "2ae5215beaf8d7b7df111a090b82134beae2683d",
            "fixture": "codex-rs/app-server/tests/suite/zsh",
            "full_repository_checkout_or_qualification": False,
        },
        "controls": [], "status": "INCOMPLETE_OR_FAILED",
    }

    def save(name, data):
        with (RUN / name).open("x") as stream:
            json.dump(data, stream, indent=2)
            stream.write("\n")

    def run(label, argv, *, cwd=RUN, env=None, cap=5):
        remaining = min(cap, deadline - time.monotonic() - 1)
        if remaining <= 0:
            raise TimeoutError("original 60 second control budget exhausted")
        stdout, stderr = RUN / (label + ".stdout"), RUN / (label + ".stderr")
        record = {"command": argv, "cwd": str(cwd), "started_unix": time.time()}
        with stdout.open("xb") as so, stderr.open("xb") as se:
            child = subprocess.Popen(argv, cwd=cwd, env=env, stdout=so, stderr=se,
                                     start_new_session=True)
            try:
                code = child.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                record["timed_out"] = True
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                code = child.wait(timeout=max(0, min(1, deadline - time.monotonic())))
        record.update(exit_code=code, finished_unix=time.time(),
                      stdout={"path": stdout.name, **identity(stdout)},
                      stderr={"path": stderr.name, **identity(stderr)})
        save(label + ".json", record)
        if record.get("timed_out") or code:
            raise RuntimeError(label + " failed; no retry or fallback")
        return stdout.read_text()

    try:
        fixture_input = Path(sys.argv[1]).resolve(strict=True)
        expected = {"bytes": FIXTURE_BYTES, "sha256": FIXTURE_SHA256, "git_blob": FIXTURE_GIT_BLOB}
        if identity(fixture_input) != expected:
            raise RuntimeError("fixture bytes differ from the frozen 2ae input")
        fixture = RUN / "SOURCE_FIXTURE.zsh"
        with fixture.open("xb") as stream:
            stream.write(fixture_input.read_bytes())
        result["fixture_before"] = {"path": fixture.name, **identity(fixture)}
        if {key: result["fixture_before"][key] for key in expected} != expected:
            raise RuntimeError("fixture copy identity mismatch")
        script = RUN / "DRIVER.py"
        with script.open("xb") as stream:
            stream.write(Path(__file__).read_bytes())
        result["driver"] = {"path": script.name, **identity(script)}
        dotslash = DOTSLASH.resolve(strict=True)
        result["dotslash_before"] = {"requested_path": str(DOTSLASH), "resolved_path": str(dotslash), **identity(dotslash)}
        if not os.access(dotslash, os.X_OK):
            raise RuntimeError("existing DotSlash is not executable")
        result["dotslash_version"] = run("dotslash-version", [str(dotslash), "--version"])
        cache = RUN / "dotslash-cache"
        cache.mkdir(mode=0o700)
        fetch_env = dict(os.environ)
        for key in list(fetch_env):
            if key.startswith(("HEPTA_LOCAL_PROVIDER_", "HEPTA_MEM_CONTEXT_", "HEPTA_MEM_NATIVE_")):
                del fetch_env[key]
        fetch_env["DOTSLASH_CACHE"] = str(cache)
        fetched = run("dotslash-fetch", [str(dotslash), "--", "fetch", str(fixture)], env=fetch_env, cap=30).strip()
        zsh = Path(fetched).resolve(strict=True)
        if not zsh.is_relative_to(cache.resolve()) or not os.access(zsh, os.X_OK):
            raise RuntimeError("fetched executable is not in this control's owned cache")
        result["zsh_before"] = {"path": str(zsh), **identity(zsh)}
        result["artifact_contract"] = {
            "tag": "rust-v0.104.0", "archive_bytes": 53771483,
            "archive_blake3": "ff664f63f5e1fa62762c9aff0aafa66cf196faf9b157f98ec98f59c152fc7bd3",
            "member": "package/vendor/aarch64-apple-darwin/zsh/macos-15/zsh",
        }
        if not str(zsh).endswith("/" + result["artifact_contract"]["member"]):
            raise RuntimeError("DotSlash selected a different platform artifact")
        python = str(Path(sys.executable).resolve(strict=True))
        if any(c.isspace() for c in python):
            raise RuntimeError("Python interpreter cannot be used in this literal shebang")
        wrapper = RUN / "observe-exec-wrapper"
        with wrapper.open("x") as stream:
            stream.write(f"#!{python}\nimport json, sys\nprint(json.dumps(sys.argv))\n")
        wrapper.chmod(0o700)
        result["wrapper_before"] = {"path": wrapper.name, **identity(wrapper)}
        for name, value in (("absolute_preflight", "/usr/bin:/bin"), *CONTROLS):
            cwd = RUN / name
            cwd.mkdir(mode=0o700)
            env = {"PATH": value, "HOME": str(cwd), "ZDOTDIR": str(cwd),
                   "TMPDIR": str(cwd), "LC_ALL": "C", "EXEC_WRAPPER": str(wrapper)}
            command = "/usr/bin/true" if name == "absolute_preflight" else "touch -c never-created"
            raw = run(name, [str(zsh), "-fc", f"export PATH='{value}'; {command}"], cwd=cwd, env=env)
            argv = json.loads(raw)
            tail = ["/usr/bin/true"] if name == "absolute_preflight" else ["touch", "-c", "never-created"]
            if not isinstance(argv, list) or len(argv) < 3 or argv[0] != str(wrapper) or argv[2:] != tail:
                raise RuntimeError("literal wrapper argv contract failed; stop without fallback")
            if name == "absolute_preflight" and argv[1] != "/usr/bin/true":
                raise RuntimeError("absolute intercept preflight failed")
            if any(cwd.iterdir()):
                raise RuntimeError("unexpected file effect in owned control cwd")
            result["controls"].append({"name": name, "path_control": value, "argv": argv,
                                       "candidate_passed_to_wrapper": argv[1], "cwd_empty_after": True})
        result["fixture_after"] = {"path": fixture.name, **identity(fixture)}
        result["dotslash_after"] = {"requested_path": str(DOTSLASH), "resolved_path": str(DOTSLASH.resolve(strict=True)), **identity(dotslash)}
        result["zsh_after"] = {"path": str(zsh), **identity(zsh)}
        result["wrapper_after"] = {"path": wrapper.name, **identity(wrapper)}
        for key in ("fixture", "dotslash", "zsh", "wrapper"):
            if result[key + "_before"] != result[key + "_after"]:
                raise RuntimeError("observed input changed during control: " + key)
        result["status"] = "INERT_MAC_ARM_ARTIFACT_CONTROL_COMPLETE_NOT_CI_REPRODUCTION"
    except BaseException as error:
        result["error"] = f"{type(error).__name__}: {error}"
    finally:
        result["finished_utc"] = datetime.now(timezone.utc).isoformat()
        result["elapsed_seconds"] = time.time() - started
        save("RESULT.json", result)
        print(json.dumps(result), flush=True)
    return 0 if result["status"] == "INERT_MAC_ARM_ARTIFACT_CONTROL_COMPLETE_NOT_CI_REPRODUCTION" else 1


if __name__ == "__main__":
    raise SystemExit(main())
