import json,os,platform,shutil,sys
from pathlib import Path
p=Path.home()
paths=['/usr/local/bin/dotslash','/opt/homebrew/bin/dotslash',str(p/'.local/bin/dotslash')]
d={'schema':'mem-zsh-mac-readonly-preflight-v2','scope':'METADATA_ONLY_NO_TEST_CANDIDATE_PROVIDER_OR_SERVICE_CHANGE','kernel':os.uname().sysname,'machine':os.uname().machine,'python':{'executable':sys.executable,'version':platform.python_version()},'tools':{k:shutil.which(k) for k in ['python3','git','dotslash']},'known_dotslash_paths':[{'path':s,'is_file':Path(s).is_file(),'is_symlink':Path(s).is_symlink()} for s in paths],'default_dotslash_cache':{'path':str(p/'.cache/dotslash'),'exists':(p/'.cache/dotslash').is_dir()},'home_free_bytes':shutil.disk_usage(p).free}
print(json.dumps(d,indent=2),flush=True)
