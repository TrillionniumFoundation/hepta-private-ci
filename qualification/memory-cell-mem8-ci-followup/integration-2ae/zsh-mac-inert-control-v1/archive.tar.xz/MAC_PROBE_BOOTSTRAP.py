import base64, hashlib, json, os, sys
from pathlib import Path
payload=json.load(sys.stdin)
assert set(payload)=={"DRIVER.py", "SOURCE_FIXTURE.zsh"}
expected={"DRIVER.py": (9281, "85e9b3c3ab22906e838f13c96492d99f949f39b468ea3010cfd41cc422841bb6"), "SOURCE_FIXTURE.zsh": (2661, "6f94e90693a7c6dcdc57bd8044786a7cdd0ccaa32f1815d5a1e47c3ce8a49d81")}
directory=Path("/Users/qianqi/mem8-zsh-mac-inert-inputs-ed353817-v1")
directory.mkdir(mode=0o700, exist_ok=False)
os.chmod(directory, 0o700)
for name, record in payload.items():
    data=base64.b64decode(record["base64"], validate=True)
    assert (len(data), hashlib.sha256(data).hexdigest())==expected[name]
    with (directory/name).open("xb") as stream:
        os.chmod(directory/name, 0o600)
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
os.execv(sys.executable, [sys.executable, str(directory/"DRIVER.py"), str(directory/"SOURCE_FIXTURE.zsh")])
