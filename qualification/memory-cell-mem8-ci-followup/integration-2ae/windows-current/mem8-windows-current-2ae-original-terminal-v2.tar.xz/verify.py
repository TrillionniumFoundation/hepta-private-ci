#!/usr/bin/env python3
"""Offline verification of the original, interrupted Windows current CI run."""
import collections
import hashlib
import io
import json
import re
import sys
import tarfile
import zipfile
from pathlib import PurePosixPath


def verify(archive):
    with tarfile.open(archive, "r:xz") as tf:
        names = [item.name for item in tf.getmembers()]
        assert len(names) == len(set(names)), "duplicate tar members"
        data = {}
        for item in tf.getmembers():
            path = PurePosixPath(item.name)
            assert item.isfile() and not path.is_absolute() and ".." not in path.parts
            data[item.name] = tf.extractfile(item).read()
    manifest = json.loads(data["MANIFEST.json"])
    assert set(data) == {"MANIFEST.json"} | {row["path"] for row in manifest["files"]}
    for row in manifest["files"]:
        body = data[row["path"]]
        assert len(body) == row["bytes"]
        assert hashlib.sha256(body).hexdigest() == row["sha256"]
    zip_name = "windows-current-ci-2ae5215-42971470233-1.zip"
    with zipfile.ZipFile(io.BytesIO(data[zip_name])) as zf:
        assert zf.testzip() is None
        members = zf.infolist()
        assert len(members) == 20
        for member in members:
            assert not member.is_dir()
            assert zf.read(member) == data["artifact/" + member.filename]
    before = json.loads(data["artifact/source-before.json"])
    assert before["head"] == "2ae5215beaf8d7b7df111a090b82134beae2683d"
    assert before["tree"] == "12159640adcf073b51f3837e75575e11f5c20233"
    assert before["trackedChanges"] == ""
    assert "artifact/source-after.json" not in data
    original = json.loads(data["ORIGINAL_TERMINAL_AUDIT.json"])
    groups = json.loads(data["artifact/groups.json"])
    assert len(groups) == 13
    by_group = {row["id"]: row for row in original["groups"]}
    all_cases = {}
    uuids = set()
    for group in groups:
        raw = data[f"artifact/{group['id']}.log"].decode()
        plain = re.sub(r"\x1b\[[0-9;]*m", "", raw)
        roster = {}
        for status, package, case in re.findall(
            r"^\s*(PASS|FAIL|LEAK)\s+\[\s*[0-9.]+s\]\s+(\S+)\s+(\S+)\s*$",
            plain,
            re.MULTILINE,
        ):
            key = package + "::" + case
            assert key not in roster or roster[key] == status
            roster[key] = status
        assert roster == by_group[group["id"]]["case_statuses"]
        assert not (set(roster) & set(all_cases)), "duplicate identity across groups"
        all_cases.update(roster)
        summaries = re.findall(r"^\s*Summary \[.*?\] (\d+) tests? run: (.+)$", plain, re.MULTILINE)
        assert len(summaries) == 1 and int(summaries[0][0]) == len(roster)
        run_ids = re.findall(r"Nextest run ID ([a-f0-9-]+)", plain)
        assert len(run_ids) == 1 and run_ids[0] not in uuids
        uuids.add(run_ids[0])
        command = group["command"]
        assert command[command.index("--retries") + 1] == "0"
    counts = dict(collections.Counter(all_cases.values()))
    assert len(all_cases) == 124
    assert counts == {"PASS": 115, "LEAK": 1, "FAIL": 8}, counts
    interrupted = data["artifact/core-exit-observation.log"].decode()
    assert "Nextest run ID" not in interrupted and not re.search(r"^\s*Summary \[", interrupted, re.MULTILINE)
    assert original["job_conclusion"] == "cancelled"
    assert original["source_after_present"] is False
    return {
        "archive_members": len(data), "zip_members": 20, "completed_groups": 13,
        "actual_unique_cases": 124, "counts": counts, "unique_nextest_runs": len(uuids),
        "next_group_actual_tests": 0, "terminal_job": "cancelled",
        "source_after": "absent", "scope": "original partial run; not full Windows qualification",
    }


if __name__ == "__main__":
    print(json.dumps(verify(sys.argv[1]), indent=2))
