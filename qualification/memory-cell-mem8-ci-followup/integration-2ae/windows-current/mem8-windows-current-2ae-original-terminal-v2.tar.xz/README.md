# Original Windows current CI interruption at 2ae5215

This archive preserves run 42971470233, job 130360697551, from PR #5935. The job started at 06:19:11 UTC and was cancelled at 07:24:21 UTC on 2026-11-11. Its before-source receipt binds HEAD `2ae5215beaf8d7b7df111a090b82134beae2683d`, tree `12159640adcf073b51f3837e75575e11f5c20233`, and a clean tracked tree. No after-source receipt or final overall driver result exists. The follow-up did not cancel or rerun this job.

All 20 members of GitHub artifact 13836980813 are retained byte for byte, together with the original ZIP and complete job log. Thirteen groups reached nextest summaries: 124 distinct actual cases, consisting of 115 PASS, one passed-but-LEAK, and eight FAIL. Repeated failure listings do not add executions. The next group, core-exit-observation, was interrupted during compilation before a nextest run began; later groups have no execution evidence. Planned selection counts are not actual execution counts.

The eight actual failures include legacy sandbox expectations rejected by the existing FILE_DELETE_CHILD guard. The LEAK belongs to the original elevated non-TTY case. This archive preserves those outcomes and does not assert a root cause or that subsequent candidates have fixed them. The two driver self-test JSON examples printed in the outer job log are excluded from actual group counts.

Run `python verify.py ARCHIVE.tar.xz` for offline checks of every archived byte, every ZIP member, source identity, raw nextest case rosters, 13 unique run UUIDs, zero-retry command arguments, and the interrupted next group. No native test or model call is performed by that verifier.
