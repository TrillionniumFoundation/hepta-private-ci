"""Continue only unexecuted source checks after missing rg; original deadline unchanged."""
import base64,hashlib,io,json,os,re,subprocess,sys,tarfile,time
from pathlib import Path
from datetime import datetime,timezone
RUN=Path('/home/qq/mem8-integrated-sem-caller-ed353817-v1')
SOURCE=RUN/'source'
ORIGINAL=RUN/'records'
RECORDS=RUN/'verification-continuation'
EXPECTED_HEAD='2ae5215beaf8d7b7df111a090b82134beae2683d'
EXPECTED_TREE='12159640adcf073b51f3837e75575e11f5c20233'
KEY='mem8-integrated-sem-caller-ai395-20261111-ed353-checks-cont-v1'
prior=json.loads((ORIGINAL/'RESULT.json').read_text())
fmt=json.loads((ORIGINAL/'FORMAT_RESULT.json').read_text())
cfg=json.loads((ORIGINAL/'INPUT.json').read_text())
assert prior['failure']=="FileNotFoundError: [Errno 2] No such file or directory: 'rg'"
assert prior['completed']==['format'] and prior['status']=='failed' and fmt['command_exit_code']==0
deadline=datetime.fromisoformat(prior['deadline_utc'])
ENV=os.environ.copy()
for k in list(ENV):
    if k.startswith(('GIT_TRACE','HEPTA_LOCAL_PROVIDER_','HEPTA_MEM_CONTEXT_','HEPTA_MEM_NATIVE_')) or k in {'GIT_CURL_VERBOSE','CARGO_BIN_EXE_codex','HEPTA_EPISODIC_DRAIN_REGRESSION_CASE'}:ENV.pop(k)
ENV.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(p,b):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def save(n,o):write(RECORDS/n,(json.dumps(o,indent=2,sort_keys=True)+'\n').encode())
def git(*a):return subprocess.check_output(['git','--no-replace-objects',*a],cwd=SOURCE,env=ENV,timeout=20)
def identity():return {'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain','--untracked-files=normal').decode().strip()}
def guard():
    assert identity()==prior['source_after']
    assert identity()['head']==EXPECTED_HEAD and identity()['tree']==EXPECTED_TREE
    assert set(git('diff','--name-only').decode().splitlines())=={r['path'] for r in prior['final_postimages']}
    assert not git('ls-files','--others','--exclude-standard') and not git('diff','--cached','--name-only')
    for r in prior['final_postimages']:
        b=(SOURCE/r['path']).read_bytes()
        assert len(b)==r['bytes'] and sha(b)==r['sha256'] and blob(b)==r['git_blob']
    before=json.loads((ORIGINAL/'SOURCE_BEFORE.json').read_text())
    for r in before['locks']:assert sha((SOURCE/r['path']).read_bytes())==r['sha256']
def command(label,args):
    remaining=int((deadline-datetime.now(timezone.utc)).total_seconds())
    if remaining<=0:raise RuntimeError('original source gate deadline exhausted')
    log=RECORDS/(label+'.raw.log');start=datetime.now(timezone.utc).isoformat()
    with log.open('xb') as f:
        try:p=subprocess.run(args,cwd=SOURCE,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=remaining);rc=p.returncode;to=False
        except subprocess.TimeoutExpired:rc=124;to=True
        f.flush();os.fsync(f.fileno())
    b=log.read_bytes();record={'command':args,'cwd':str(SOURCE),'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'exit_code':rc,'timed_out':to,'raw_file':log.name,'raw_bytes':len(b),'raw_sha256':sha(b)}
    save(label+'.json',record);print(json.dumps({'phase':label,**record}),flush=True)
    if rc:raise RuntimeError(label+' failed with exit '+str(rc))
    return b
RECORDS.mkdir(mode=0o700)
write(RECORDS/'DRIVER.py',Path(__file__).read_bytes())
save('START.json',{'run_id':KEY,'started_at':datetime.now(timezone.utc).isoformat(),'deadline_utc':deadline.isoformat(),'original_run_id':prior['run_id'],'original_result_sha256':sha((ORIGINAL/'RESULT.json').read_bytes()),'original_format_receipt_sha256':sha((ORIGINAL/'format.json').read_bytes()),'source_unchanged_before_continuation':True,'scope':'No clone, format, source edit or replayed caller run; git grep replaces unavailable rg for tracked-source search.','cargo_build_or_test_commands':0,'model_calls':0})
status='failed';failure=None;completed=[]
try:
    guard()
    refs=command('all-episodic-import-references',['git','grep','-n','episodic_imports','--'])
    assert len(refs.decode().splitlines())==3
    paths=[r['path'] for r in cfg['owner_pins'] if r['path'].endswith('.rs')]
    assert len(paths)==36
    command('owner-guard-inventory',['git','grep','-n','-E','(Mutex|RwLock|Semaphore|[.]lock\\(|[.]read\\(|[.]write\\(|[.]acquire\\()','--',*paths])
    inventory=[]
    for name in paths:
        b=(SOURCE/name).read_bytes();s=b.decode();hits=[]
        for m in re.finditer(r'\.(?:lock|read|write|acquire)\(\)\s*\.await',s):
            hits.append({'line':s.count('\n',0,m.start())+1,'match':m.group(0)})
        inventory.append({'path':name,'git_blob':blob(b),'bytes':len(b),'sha256':sha(b),'async_acquisition_matches':hits})
    save('OWNER_GUARD_SOURCE_SCAN.json',{'files':inventory,'all_repository_episodic_import_references':refs.decode().splitlines(),'scope':'All 36 changed MEM Rust files; lexical inventory, not a native Clippy proof.'})
    completed.append('reference-and-guard-inventory')
    command('caller-self-test',['python3','scripts/verify_hepta_callers.py','self-test']);completed.append('caller-self-test')
    command('caller-verify',['python3','scripts/verify_hepta_callers.py','verify']);completed.append('caller-verify')
    guard()
    status='passed'
except Exception as e:failure=type(e).__name__+': '+str(e)
finally:
    result={'status':status,'failure':failure,'run_id':KEY,'completed':completed,'deadline_utc':deadline.isoformat(),'finished_at':datetime.now(timezone.utc).isoformat(),'base_sha':EXPECTED_HEAD,'base_tree':EXPECTED_TREE,'source_after':identity(),'final_postimages':prior['final_postimages'],'original_formatter_execution_imported_not_repeated':True,'original_failed_driver_result_preserved':True,'cargo_build_or_test_commands':0,'rust_tests_executed':0,'model_calls':0}
    save('RESULT.json',result);print(json.dumps(result,sort_keys=True),flush=True)
    members={}
    for prefix,d in [('formatter-attempt',ORIGINAL),('verification-continuation',RECORDS)]:
        for p in sorted(d.rglob('*')):
            if p.is_file():
                assert not p.is_symlink()
                members[prefix+'/'+p.relative_to(d).as_posix()]=p.read_bytes()
    manifest={'schema':'mem8.final-source-candidate.records.v1','members':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())]}
    members['MEMBER_MANIFEST.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
    out=RUN/'mem8-sem-caller-final-with-continuation.tar.xz'
    with out.open('xb') as f:
        with tarfile.open(fileobj=f,mode='w:xz',preset=6) as a:
            for n,b in sorted(members.items()):
                info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o600;info.mtime=0;a.addfile(info,io.BytesIO(b))
        f.flush();os.fsync(f.fileno())
    b=out.read_bytes();d=RUN/'final-archive-text-chunks';d.mkdir();chunks=[]
    for i,offset in enumerate(range(0,len(b),24576)):
        raw=b[offset:offset+24576];enc=base64.b64encode(raw)+b'\n';p=d/f'part-{i:03d}.b64';write(p,enc)
        chunks.append({'index':i,'offset':offset,'path':str(p),'text_bytes':len(enc),'text_sha256':sha(enc),'decoded_bytes':len(raw),'decoded_sha256':sha(raw)})
    meta={'path':str(out),'bytes':len(b),'sha256':sha(b),'members':len(members),'chunks':chunks}
    write(RUN/'FINAL_ARCHIVE_INFO.json',(json.dumps(meta,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps({'archive':meta}),flush=True)
sys.exit(0 if status=='passed' else 1)
