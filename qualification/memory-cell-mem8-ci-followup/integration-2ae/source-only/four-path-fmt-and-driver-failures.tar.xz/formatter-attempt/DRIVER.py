"""Format and verify a four-file exact-source candidate; no Rust build/test or model."""
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time
import tomllib
from datetime import datetime, timezone, timedelta

CONFIG_PATH=Path(sys.argv[1])
CONFIG=json.loads(CONFIG_PATH.read_text())
RUN=Path('/home/qq/mem8-integrated-sem-caller-ed353817-v1')
SOURCE=RUN/'source'
RECORDS=RUN/'records'
DONOR=Path('/home/qq/mem8-integrated-caller-2ae-ed353817-v1/source')
HEAD=CONFIG['base_sha']
TREE=CONFIG['base_tree']
KEY='mem8-integrated-sem-caller-ai395-20261111-ed353-v1'
START=datetime.now(timezone.utc)
DEADLINE=time.monotonic()+600
ENV=os.environ.copy()
for key in list(ENV):
    if key.startswith(('GIT_TRACE','HEPTA_LOCAL_PROVIDER_','HEPTA_MEM_CONTEXT_','HEPTA_MEM_NATIVE_')) or key in {'GIT_CURL_VERBOSE','CARGO_BIN_EXE_codex','HEPTA_EPISODIC_DRAIN_REGRESSION_CASE'}:
        ENV.pop(key)
ENV.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
ENV['PATH']='/home/qq/mem8-owner-20261111-ed353817/native-6be-20261111/tools/bin:/home/qq/.cargo/bin:'+ENV.get('PATH','')
WF=CONFIG['workflow']['path']
RUST=CONFIG['rust_preimages']
EXPECTED=set(RUST)|{WF}

def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
def save(name,obj):write(RECORDS/name,(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode())
def git(cwd,*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=cwd,env=ENV,timeout=30)
def identity(cwd):return {'head':git(cwd,'rev-parse','HEAD').decode().strip(),'tree':git(cwd,'rev-parse','HEAD^{tree}').decode().strip(),'status':git(cwd,'status','--porcelain','--untracked-files=normal').decode().strip()}
def changed():return set(git(SOURCE,'diff','--name-only').decode().splitlines())
def command(label,args,cwd,allowed=(0,)):
    remaining=int(DEADLINE-time.monotonic())
    if remaining<=0:raise RuntimeError('source-only deadline exhausted before '+label)
    before=datetime.now(timezone.utc).isoformat()
    log=RECORDS/(label+'.raw.log')
    with log.open('xb') as f:
        try:
            p=subprocess.run(args,cwd=cwd,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=remaining)
            code=p.returncode;timed_out=False
        except subprocess.TimeoutExpired:
            code=124;timed_out=True
        f.flush();os.fsync(f.fileno())
    raw=log.read_bytes()
    receipt={'command':args,'cwd':str(cwd),'started_at':before,'finished_at':datetime.now(timezone.utc).isoformat(),'exit_code':code,'timed_out':timed_out,'raw_file':log.name,'raw_bytes':len(raw),'raw_sha256':sha(raw)}
    save(label+'.json',receipt)
    print(json.dumps({'phase':label,**receipt}),flush=True)
    if code not in allowed:raise RuntimeError(label+' failed with exit '+str(code))
    return raw
def files(label):
    out=[]
    for name in sorted(EXPECTED):
        p=SOURCE/name
        assert p.is_file() and not p.is_symlink()
        b=p.read_bytes();write(RECORDS/label/name,b)
        out.append({'path':name,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
    save(label+'-FILES.json',out)
    return out
def lock_pins():
    out=[]
    for name,h in {'codex-rs/Cargo.lock':'98b3767c6e74bf6eeb5894db760259dbc400cbfd0685af8ad915c92d25408d69','MODULE.bazel.lock':'783b3ad329fa53bd4a0e48be6907d38259fa2880d61bd1994b863d7f78bbca57'}.items():
        b=(SOURCE/name).read_bytes();assert sha(b)==h
        out.append({'path':name,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
    return out
def archive_records():
    members=[]
    for p in sorted(RECORDS.rglob('*')):
        if p.is_file():
            assert not p.is_symlink()
            b=p.read_bytes();members.append({'path':p.relative_to(RECORDS).as_posix(),'bytes':len(b),'sha256':sha(b)})
    save('FILE_MANIFEST.json',{'members':members,'schema':'mem8.four-file-source-gates.records.v1'})
    archive=RUN/'mem8-sem-caller-final-candidate-records.tar.xz'
    with archive.open('xb') as f:
        with tarfile.open(fileobj=f,mode='w:xz',preset=6) as tar:
            for p in sorted(RECORDS.rglob('*')):
                if not p.is_file():continue
                b=p.read_bytes();info=tarfile.TarInfo(p.relative_to(RECORDS).as_posix());info.size=len(b);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(b))
        f.flush();os.fsync(f.fileno())
    raw=archive.read_bytes()
    chunks=RUN/'archive-text-chunks';chunks.mkdir()
    rows=[]
    for i,offset in enumerate(range(0,len(raw),24576)):
        b=raw[offset:offset+24576];text=base64.b64encode(b)+b'\n';p=chunks/f'part-{i:03d}.b64';write(p,text)
        rows.append({'index':i,'offset':offset,'path':str(p),'text_bytes':len(text),'text_sha256':sha(text),'decoded_bytes':len(b),'decoded_sha256':sha(b)})
    result={'path':str(archive),'bytes':len(raw),'sha256':sha(raw),'members':len(members)+1,'chunks':rows}
    write(RUN/'ARCHIVE_INFO.json',(json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps({'archive':result}),flush=True)

def main():
    RUN.mkdir(mode=0o700);RECORDS.mkdir(mode=0o700)
    write(RECORDS/'DRIVER.py',Path(__file__).read_bytes());write(RECORDS/'INPUT.json',CONFIG_PATH.read_bytes())
    donor_before=identity(DONOR)
    helper='codex-rs/hepta-memory/src/production_episodic_test_support.rs'
    assert donor_before=={'head':HEAD,'tree':TREE,'status':'M '+helper}
    assert blob((DONOR/helper).read_bytes())=='c822b1c5c4a579737d0487c36c8262926f5186e6'
    save('START.json',{'run_id':KEY,'started_at':START.isoformat(),'deadline_utc':(START+timedelta(seconds=600)).isoformat(),'donor_before':donor_before,'cargo_build_or_test_commands':0,'model_calls':0})
    status='failed';failure=None;completed=[];before=None;after_files=None;locks=None
    try:
        command('clone',['git','clone','--shared','--no-checkout',str(DONOR),str(SOURCE)],RUN)
        command('checkout',['git','checkout','--detach',HEAD],SOURCE)
        before=identity(SOURCE);assert before=={'head':HEAD,'tree':TREE,'status':''}
        assert git(SOURCE,'rev-parse','HEAD:AGENTS.md').decode().strip()=='faa57cc0db48123e1011f1eb47692cd3bbbcfc3a'
        write(RECORDS/'AGENTS.md',(SOURCE/'AGENTS.md').read_bytes())
        write(RECORDS/'SOURCE_TREE.ls-tree',git(SOURCE,'ls-tree','-r','-z','HEAD'))
        locks=lock_pins()
        save('SOURCE_BEFORE.json',{'identity':before,'locks':locks})
        assert len(CONFIG['owner_pins'])==38
        for row in CONFIG['owner_pins']:
            assert blob((SOURCE/row['path']).read_bytes())==row['git_blob'],row['path']
        files('base')
        for name,h in RUST.items():
            p=SOURCE/name;b=p.read_bytes();assert blob(b)==h;s=b.decode()
            if name.endswith('production_writer.rs'):
                old='    // Shared by every capability/clone of this original writer.\n    episodic_imports: Arc<tokio::sync::Mutex<()>>,'
                new='    // One admission slot, shared by every capability/clone of this writer.\n    episodic_imports: Arc<tokio::sync::Semaphore>,'
                assert s.count(old)==1;s=s.replace(old,new)
                old='            episodic_imports: Arc::new(tokio::sync::Mutex::new(())),'
                new='            episodic_imports: Arc::new(tokio::sync::Semaphore::new(/*permits*/ 1)),'
                assert s.count(old)==1;s=s.replace(old,new)
            elif name.endswith('production_episodic.rs'):
                for old,new in [
                    ('        // This lock outlives both the native transaction and its outcome guard.','        // This permit outlives both the native transaction and its outcome guard.'),
                    ('        let _import = self.writer.episodic_imports.lock().await;','        let _import = self.writer.episodic_imports.acquire().await.map_err(unavailable)?;'),
                    ('        // Transaction queues rollback, and before the import lock is released.','        // Transaction queues rollback, and before the import permit is released.')]:
                    assert s.count(old)==1;s=s.replace(old,new)
            else:
                old='pub(super) async fn fixture() -> Result<Fixture, Box<dyn std::error::Error>> {'
                assert s.count(old)==1;s=s.replace(old,'#[cfg(test)]\n'+old)
            post=s.encode();assert blob(post)==CONFIG['rust_pre_format_postimages'][name]
            p.write_bytes(post)
        wf=CONFIG['workflow'];assert blob((SOURCE/WF).read_bytes())==wf['preimage'];assert blob(wf['content'].encode())==wf['postimage'];(SOURCE/WF).write_text(wf['content'])
        assert changed()==EXPECTED
        pre_format=files('pre-format')
        write(RECORDS/'candidate-before-format.patch',git(SOURCE,'diff','--binary'))
        rustfmt=command('rustfmt-version',['rustfmt','--version'],SOURCE/'codex-rs')
        assert b'rustfmt 1.9.0-stable (ac68faa20c 2026-05-25)' in rustfmt
        just=command('just-version',['just','--version'],SOURCE);assert just.strip()==b'just 1.51.0'
        assert tomllib is not None
        # Existing scoped formatter uses rustfmt directly for the three changed
        # Rust files. No Rust configuration or manifest changes trigger cargo fmt.
        command('format',['just','fmt','--base',HEAD],SOURCE)
        completed.append('format')
        after_files=files('post-format')
        assert changed()==EXPECTED and not git(SOURCE,'diff','--cached','--name-only')
        assert not git(SOURCE,'ls-files','--others','--exclude-standard')
        assert lock_pins()==locks
        save('FORMAT_RESULT.json',{'command_exit_code':0,'before':pre_format,'after':after_files,'changed_paths':[a['path'] for a,b in zip(pre_format,after_files) if a!=b],'rust_formatter_version':rustfmt.decode().strip(),'cargo_build_or_test_commands':0,'yaml_note':'Existing scoped just fmt has no YAML formatter; workflow bytes are separately pinned and reviewed.'})
        write(RECORDS/'candidate-after-format.patch',git(SOURCE,'diff','--binary'))
        references=command('all-episodic-import-references',['rg','-n','--hidden','-g','!.git/**','episodic_imports','.'],SOURCE)
        assert len(references.decode().splitlines())==3
        rust_paths=[r['path'] for r in CONFIG['owner_pins'] if r['path'].endswith('.rs')]
        assert len(rust_paths)==36
        command('owner-guard-inventory',['rg','-n','(Mutex|RwLock|Semaphore|[.]lock\\(|[.]read\\(|[.]write\\(|[.]acquire\\()','--',*rust_paths],SOURCE)
        inventory=[]
        for name in rust_paths:
            b=(SOURCE/name).read_bytes();text=b.decode()
            hits=[]
            for match in re.finditer(r'\.(?:lock|read|write|acquire)\(\)\s*\.await',text):
                line=text.count('\n',0,match.start())+1
                hits.append({'line':line,'match':match.group(0)})
            inventory.append({'path':name,'git_blob':blob(b),'bytes':len(b),'sha256':sha(b),'async_acquisition_matches':hits})
        save('OWNER_GUARD_SOURCE_SCAN.json',{'files':inventory,'scope':'All 36 Rust files changed by G over common; lexical inventory, not a substitute for native Clippy or lifetime checking.','all_repository_episodic_import_references':references.decode().splitlines()})
        command('caller-self-test',['python3','scripts/verify_hepta_callers.py','self-test'],SOURCE)
        completed.append('caller-self-test')
        command('caller-verify',['python3','scripts/verify_hepta_callers.py','verify'],SOURCE)
        completed.append('caller-verify')
        assert changed()==EXPECTED and lock_pins()==locks
        for row in after_files:assert blob((SOURCE/row['path']).read_bytes())==row['git_blob']
        assert identity(DONOR)==donor_before
        status='passed'
    except Exception as e:
        failure=type(e).__name__+': '+str(e)
    finally:
        source_after=identity(SOURCE) if (SOURCE/'.git').exists() else None
        result={'status':status,'failure':failure,'run_id':KEY,'base_sha':HEAD,'base_tree':TREE,'source_before':before,'source_after':source_after,'final_postimages':after_files,'donor_before':donor_before,'donor_after':identity(DONOR),'completed':completed,'started_at':START.isoformat(),'finished_at':datetime.now(timezone.utc).isoformat(),'deadline_utc':(START+timedelta(seconds=600)).isoformat(),'cargo_build_or_test_commands':0,'rust_tests_executed':0,'model_calls':0,'source_candidate_is_committed':False}
        save('RESULT.json',result);print(json.dumps(result,sort_keys=True),flush=True)
        archive_records()
    return 0 if status=='passed' else 1
if __name__=='__main__':sys.exit(main())
