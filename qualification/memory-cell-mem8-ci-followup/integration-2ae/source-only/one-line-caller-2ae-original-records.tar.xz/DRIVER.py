"""Source-only exact 2ae caller guard reproduction; no Cargo/model/owner execution."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone, timedelta

RUN = Path('/home/qq/mem8-integrated-caller-2ae-ed353817-v1')
SOURCE = RUN / 'source'
RECORDS = RUN / 'records'
DONOR = Path('/home/qq/mem8-owner-20261111-ed353817/native-fresh-f2-0c32926-20261111/source')
HEAD = '2ae5215beaf8d7b7df111a090b82134beae2683d'
TREE = '12159640adcf073b51f3837e75575e11f5c20233'
DONOR_HEAD = '0c32926cfec58d986477fc72ba3a4787ab75fde9'
DONOR_TREE = '0d5aa1544aad103f9099c7c8347d8075d6ecc76e'
REL = 'codex-rs/hepta-memory/src/production_episodic_test_support.rs'
PRE = '6cb08af29309991e19510cfecd30aaaafa55f6a3'
POST = 'c822b1c5c4a579737d0487c36c8262926f5186e6'
KEY = 'mem8-integrated-caller-2ae-ai395-20261111-ed353-v1'
START = datetime.now(timezone.utc)
DEADLINE = time.monotonic() + 280
ENV = os.environ.copy()
REMOVED = []
for key in list(ENV):
    if key.startswith(('GIT_TRACE', 'HEPTA_LOCAL_PROVIDER_', 'HEPTA_MEM_CONTEXT_', 'HEPTA_MEM_NATIVE_')) or key in {'GIT_CURL_VERBOSE','CARGO_BIN_EXE_codex','HEPTA_EPISODIC_DRAIN_REGRESSION_CASE'}:
        REMOVED.append(key)
        ENV.pop(key)
ENV.update(PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
ENV['PATH'] = '/home/qq/.cargo/bin:' + ENV.get('PATH','')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def write(path, data):
    with path.open('xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())

def save(name, value):
    write(RECORDS / name, (json.dumps(value,indent=2,sort_keys=True)+'\n').encode())

def capture(cwd, *args):
    return subprocess.check_output(['git','--no-replace-objects',*args],cwd=cwd,env=ENV,timeout=20)

def identity(cwd):
    return {'head':capture(cwd,'rev-parse','HEAD').decode().strip(),
            'tree':capture(cwd,'rev-parse','HEAD^{tree}').decode().strip(),
            'status':capture(cwd,'status','--porcelain','--untracked-files=normal').decode().strip()}

def command(name, args, cwd):
    remaining = int(DEADLINE-time.monotonic())
    if remaining <= 0:
        raise RuntimeError('source-only deadline exhausted before '+name)
    log = RECORDS/(name+'.raw.log')
    before = datetime.now(timezone.utc).isoformat()
    with log.open('xb') as f:
        try:
            p=subprocess.run(args,cwd=cwd,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=remaining)
            code=p.returncode
            timeout=False
        except subprocess.TimeoutExpired:
            code=124
            timeout=True
        f.flush()
        os.fsync(f.fileno())
    raw=log.read_bytes()
    value={'command':args,'cwd':str(cwd),'started_at':before,'finished_at':datetime.now(timezone.utc).isoformat(),
           'exit_code':code,'timed_out':timeout,'raw_file':log.name,'raw_bytes':len(raw),'raw_sha256':sha(raw)}
    save(name+'.json',value)
    print(json.dumps({'phase':name,**value}),flush=True)
    return code

def locks():
    expected={'codex-rs/Cargo.lock':'98b3767c6e74bf6eeb5894db760259dbc400cbfd0685af8ad915c92d25408d69',
              'MODULE.bazel.lock':'783b3ad329fa53bd4a0e48be6907d38259fa2880d61bd1994b863d7f78bbca57'}
    out=[]
    for name,h in expected.items():
        d=(SOURCE/name).read_bytes()
        assert sha(d)==h,(name,sha(d))
        out.append({'path':name,'bytes':len(d),'sha256':sha(d),'git_blob':blob(d)})
    return out

def main():
    RUN.mkdir(mode=0o700)
    RECORDS.mkdir(mode=0o700)
    write(RECORDS/'DRIVER.py',Path(__file__).read_bytes())
    donor_before=identity(DONOR)
    assert donor_before=={'head':DONOR_HEAD,'tree':DONOR_TREE,'status':''}
    save('START.json',{'run_id':KEY,'host':'ai395','started_at':START.isoformat(),
                      'deadline_utc':(START+timedelta(seconds=280)).isoformat(),
                      'source_sha':HEAD,'source_tree':TREE,'donor_before':donor_before,
                      'native_test_commands':0,'model_calls':0,'removed_environment_names_only':REMOVED})
    status='failed'
    failure=None
    completed=[]
    before=None
    lock_before=None
    try:
        for label,args,cwd in [
            ('clone',['git','clone','--shared','--no-checkout',str(DONOR),str(SOURCE)],RUN),
            ('fetch',['git','-c','credential.helper=!gh auth git-credential','fetch','--no-tags','https://github.com/TrillionniumFoundation/hepta-private-ci.git',HEAD],SOURCE),
            ('checkout',['git','checkout','--detach',HEAD],SOURCE)]:
            if command(label,args,cwd)!=0:
                raise RuntimeError(label+' failed')
            completed.append(label)
        before=identity(SOURCE)
        assert before=={'head':HEAD,'tree':TREE,'status':''}
        assert identity(DONOR)==donor_before
        lock_before=locks()
        save('SOURCE_BEFORE.json',{'identity':before,'locks':lock_before,
                                 'commit_object':capture(SOURCE,'cat-file','-p','HEAD').decode()})
        write(RECORDS/'SOURCE_TREE.ls-tree',capture(SOURCE,'ls-tree','-r','-z','HEAD'))
        save('INSTRUCTIONS.json',{'paths':capture(SOURCE,'ls-files','AGENTS.md','**/AGENTS.md').decode().splitlines(),
                                'root_git_blob':capture(SOURCE,'rev-parse','HEAD:AGENTS.md').decode().strip()})
        write(RECORDS/'AGENTS.md',(SOURCE/'AGENTS.md').read_bytes())
        assert capture(SOURCE,'rev-parse','HEAD:AGENTS.md').decode().strip()=='faa57cc0db48123e1011f1eb47692cd3bbbcfc3a'
        if command('caller-self-test-before',['python3','scripts/verify_hepta_callers.py','self-test'],SOURCE)!=0:
            raise RuntimeError('original caller self-test failed')
        original_rc=command('caller-verify-before',['python3','scripts/verify_hepta_callers.py','verify'],SOURCE)
        completed.extend(['caller-self-test-before','caller-verify-before'])
        assert identity(SOURCE)==before and locks()==lock_before
        assert original_rc!=0,'expected original caller failure was not reproduced'
        raw=(RECORDS/'caller-verify-before.raw.log').read_text()
        assert 'memory_production_writer_open' in raw and REL in raw
        path=SOURCE/REL
        pre=path.read_bytes()
        assert blob(pre)==PRE
        marker=b'pub(super) async fn fixture() -> Result<Fixture, Box<dyn std::error::Error>> {'
        assert pre.count(marker)==1
        post=pre.replace(marker,b'#[cfg(test)]\n'+marker,1)
        assert blob(post)==POST
        assert sha(post)=='1dff9c211f4808d089ff66ad9ea8448718c5e7170390691b0df3c5e1648e9c88'
        write(RECORDS/'production_episodic_test_support.before.rs',pre)
        write(RECORDS/'production_episodic_test_support.after.rs',post)
        path.write_bytes(post)
        patch=capture(SOURCE,'diff','--binary')
        write(RECORDS/'candidate.patch',patch)
        changed=capture(SOURCE,'diff','--name-only').decode().splitlines()
        assert changed==[REL]
        assert not capture(SOURCE,'diff','--cached','--name-only')
        assert not capture(SOURCE,'ls-files','--others','--exclude-standard')
        rc=command('caller-verify-after',['python3','scripts/verify_hepta_callers.py','verify'],SOURCE)
        completed.append('caller-verify-after')
        assert locks()==lock_before and identity(DONOR)==donor_before
        assert blob(path.read_bytes())==POST
        if rc:
            raise RuntimeError('candidate complete caller verify still failed; preserve raw follow-on diagnostics')
        status='passed'
    except Exception as e:
        failure=type(e).__name__+': '+str(e)
    finally:
        after=identity(SOURCE) if (SOURCE/'.git').exists() else None
        donor_after=identity(DONOR)
        result={'status':status,'failure':failure,'run_id':KEY,'source_sha':HEAD,'source_tree':TREE,
                'source_before':before,'source_after':after,'donor_before':donor_before,'donor_after':donor_after,
                'candidate_path':REL,'preimage_git_blob':PRE,'candidate_git_blob':POST,
                'candidate_is_committed':False,'completed':completed,'native_commands':0,'model_calls':0,
                'started_at':START.isoformat(),'finished_at':datetime.now(timezone.utc).isoformat(),
                'deadline_utc':(START+timedelta(seconds=280)).isoformat()}
        save('RESULT.json',result)
        files=[]
        for p in sorted(RECORDS.iterdir()):
            if p.is_file():
                d=p.read_bytes()
                files.append({'path':p.name,'bytes':len(d),'sha256':sha(d)})
        save('FILE_MANIFEST.json',{'schema':'mem8.source-only.records.v1','members':files})
        print(json.dumps(result,sort_keys=True),flush=True)
    return 0 if status=='passed' else 1

if __name__=='__main__':
    sys.exit(main())
