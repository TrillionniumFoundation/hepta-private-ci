"""Read existing raw logs only; do not infer Rust case totals from Bazel targets."""
import collections
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'job-130374692350-decoded.log'
raw = RAW.read_bytes()
text = raw.decode('utf-8')
lines = text.splitlines()
clean = [re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT\S+Z ', '', line) for line in lines]
jobs = json.loads((ROOT / 'ALL_37_JOBS.json').read_text())['jobs']
job = next(row for row in jobs if row['id'] == 130374692350)
targets = []
for number, line in enumerate(clean, 1):
    match = re.match(r'^(//\S+)\s+(PASSED|FAILED|TIMEOUT|FLAKY)\b(.*)$', line)
    if match:
        targets.append({'target': match[1], 'status': match[2], 'detail': match[3].strip(),
                        'raw_line': number})
failed = [row for row in targets if row['status'] in ('FAILED', 'TIMEOUT')]
flaky = [row for row in targets if row['status'] == 'FLAKY']
assert len(failed) == 20 and len({row['target'] for row in failed}) == 20
assert len(flaky) == 3
summary = next((line for line in clean if line.startswith('Executed ') and '20 fail locally' in line), None)
assert summary is not None
observed = collections.defaultdict(list)
current_target = None
blocks = []
for number, line in enumerate(clean, 1):
    start = re.match(r'^=+ Test output for (//\S+?)(?: \(shard (\d+) of (\d+)\))?:$', line)
    if start:
        current_target = start[1]
        blocks.append({'target': current_target, 'shard': int(start[2]) if start[2] else None,
                       'shard_count': int(start[3]) if start[3] else None, 'raw_start_line': number})
    # Only native libtest result lines at line start; embedded child error strings
    # and the workflow's later selected-summary reprint are not new test runs.
    case = re.match(r'^test ([A-Za-z0-9_:]+) \.\.\. (ok|FAILED|ignored)(?:$|,)', line)
    if case and current_target:
        observed[(current_target, case[1])].append({'outcome': case[2], 'raw_line': number})
all_failed_names = sorted(set(re.findall(r'\btest ([^\n]+?) \.\.\. FAILED', text)))
result = {
    'schema': 'mem8.original-mac-intel-terminal.v1',
    'run_id': 42971470498, 'job_id': 130374692350,
    'head': '2ae5215beaf8d7b7df111a090b82134beae2683d',
    'tested_merge': '41a7efb83cae9187d383732bc80d055ac6074984',
    'tree': '12159640adcf073b51f3837e75575e11f5c20233',
    'raw': {'path': RAW.name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()},
    'job_status': job['status'], 'job_conclusion': job['conclusion'],
    'started_at': job['started_at'], 'completed_at': job['completed_at'],
    'steps': [{key: step[key] for key in ('name', 'status', 'conclusion', 'started_at', 'completed_at')}
              for step in job['steps']],
    'bazel_test_command_exit': 3,
    'bazel_summary_verbatim': summary,
    'summary_unit': 'Bazel test targets/actions; not individual Rust case totals',
    'failed_target_count': len(failed), 'failed_targets': failed,
    'flaky_target_count': len(flaky), 'flaky_targets': flaky,
    'observed_unique_failed_case_names_including_retries_and_summary_reprints': all_failed_names,
    'observed_failed_name_count': len(all_failed_names),
    'observed_failed_name_occurrences': len(re.findall(r'\btest ([^\n]+?) \.\.\. FAILED', text)),
    'case_count_limit': '67 is observed unique names across attempts and summary reprints, not 67 terminal failing cases; 3 targets ultimately FLAKY. No global Rust PASS/FAIL total inferred.',
    'cancellation': {
        'observed_phase': 'Save bazel repository cache, after test exit3 and successful execution-log upload',
        'operation_cancelled_at': '2026-11-11T08:57:02.7629540Z',
        'job_budget_minutes_from_exact_workflow': 120,
        'reason': 'Timing is consistent with the configured 120-minute job bound, but no cancellation actor or explicit timeout reason was retrieved.',
        'check_run_reason_read': 'Connector rejected both output/annotations GET endpoints with HTTP400',
        'sourcegate_or_agent_causation_evidence': False,
    },
    'original_post_run_clean_check': 'skipped; no post-run-clean assertion made',
    'original_execution_artifact': {'id': 13841028458, 'bytes_from_original_upload_log': 10632360,
        'name': 'bazel-execution-logs-test-x86_64-apple-darwin', 'downloaded_by_this_agent': False},
    'mac_arm_clippy': {'job_id': 130374692388, 'conclusion': 'failure',
        'completed_at': '2026-11-11T07:11:23Z',
        'cause': 'Original production episodic Tokio MutexGuard held across await; same known gate failure, not a new independent defect'},
    'new_execution_performed': False,
}
(ROOT / 'TERMINAL_SUMMARY.json').write_text(json.dumps(result, indent=2) + '\n')
(ROOT / 'TARGET_OUTPUT_BLOCKS.json').write_text(json.dumps(blocks, indent=2) + '\n')
print(json.dumps({'terminal': job['conclusion'], 'command_exit': 3, 'failed_targets': len(failed),
                  'flaky_targets': len(flaky), 'observed_unique_failed_names': len(all_failed_names)}))
