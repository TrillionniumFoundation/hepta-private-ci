# Original integrated-source Mac terminal evidence

This is a read-only capture of the original PR #5935 blocking run 42971470498.
The source head remains `2ae5215beaf8d7b7df111a090b82134beae2683d`; checkout was
the original merge `41a7efb83cae9187d383732bc80d055ac6074984`, whose tree is
`12159640adcf073b51f3837e75575e11f5c20233`.

The Mac Intel job ended **cancelled**, but its `bazel test //...` step had
already ended **failure, exit 3**. The execution-log upload then succeeded;
repository-cache saving was cancelled and the final clean-worktree check was
skipped. The complete raw job log includes the post-job cleanup tail. The
roughly 120-minute interval matches the exact workflow's configured job bound;
an explicit cancellation reason or actor was not retrieved. The connector
rejected both check-run output/annotation endpoints. No source-gate causation
is inferred, and no run was rerun, dispatched or cancelled by this capture.

The original Bazel summary reports 392 target results passing, 20 locally
failing and 172 skipped; 299 of 584 were executed. These are **Bazel target or
action counts**, not Rust case counts. The final target table has 16 FAILED,
4 TIMEOUT and 3 FLAKY targets. Sixty-seven unique Rust names appear as FAILED
across attempts and the workflow's later summary reprints; that number is not
67 terminal failing cases. `parse_terminal.py` records this distinction.

The separate Mac ARM Clippy log is the existing Tokio MutexGuard-across-await
failure in production episodic memory. Its job actually completed at 07:11:23
UTC; retrieving its complete log later does not create a new independent
failure. All original failures, retries and skipped checks remain in the raw
files.

`ALL_37_JOBS.json` and `BLOCKING_RUN.json` are the original full terminal REST
observations. `RAW_LOG_INDEX.json` binds the two complete decoded logs.
`bazel.tested-merge.yml` is the exact referenced workflow blob
`73e70ae2300bf6013d69914662d546d8e1b83569`.

This package contains no new native execution, model call, permission change,
source fix, CI rerun or published-ref operation. Proposed repairs elsewhere
are not treated as qualification of this source.
