#!/usr/bin/env python3
"""Read-only audit of the two authorized cancellation phases and final GETs."""
import hashlib
import json
import pathlib
import re
import tarfile

ROOT = pathlib.Path(__file__).resolve().parent
HEAD = "2ae5215beaf8d7b7df111a090b82134beae2683d"
TREE = "12159640adcf073b51f3837e75575e11f5c20233"
PARENTS = [
    "9d9bdfbaeeec3c618f3fc80e2f663a29c13f4b27",
    "55951ed9094ae894f0256a3461fd9504ef060473",
    "f1fd544b3e12ed6aca83872cdeda8114a1e058c0",
]
STANDARD = [42969638203, 42969638208, 42969638213, 42969638232,
            42969638234, 42969638328, 42969638251, 42964451586,
            42964451559, 42964451650, 42953344593]
FORCE = [42969638232, 42969638328, 42964451586, 42964451650, 42953344593]
FANINS = dict(zip(FORCE, [130368089800, 130368414680, 130368751440,
                          130368975012, 130365956011]))
blob = (ROOT / "mem8-superseded-component-ci-cleanup-v1-v2.tar.xz").read_bytes()
assert len(blob) == 49376
assert hashlib.sha256(blob).hexdigest() == "d5e7a513113c59345b62dd25077b5b24d5275743560a9efd80723d3ce2eb94da"
assert hashlib.sha1(b"blob " + str(len(blob)).encode() + b"\0" + blob).hexdigest() == "812871aeb4579ab95c1c3b470564e612cffbaf83"
with tarfile.open(ROOT / "mem8-superseded-component-ci-cleanup-v1-v2.tar.xz", "r:xz") as tar:
    members = tar.getmembers()
    assert len(members) == 389 and len({m.name for m in members}) == 389
    data = {}
    for member in members:
        path = pathlib.PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and ".." not in path.parts
        assert not member.issym() and not member.islnk()
        data[member.name] = tar.extractfile(member).read()
    manifest = json.loads(data["FILE_MANIFEST.json"])
    assert manifest["manifest_excludes_itself"] is True
    assert len(manifest["files"]) == 388
    assert {x["path"] for x in manifest["files"]} == set(data) - {"FILE_MANIFEST.json"}
    for row in manifest["files"]:
        content = data[row["path"]]
        assert len(content) == row["bytes"]
        assert hashlib.sha256(content).hexdigest() == row["sha256"]

def read(path):
    return json.loads(data[path])

def integration_guard(prefix):
    commit = read(prefix + ".integration-commit.json")
    pr = read(prefix + ".integration-pr.json")
    assert commit["sha"] == HEAD and commit["tree"]["sha"] == TREE
    assert [x["sha"] for x in commit["parents"]] == PARENTS
    assert pr["number"] == 5935 and pr["head"]["sha"] == HEAD

def identity(run, spec):
    assert run["id"] == spec["run_id"]
    assert run["head_sha"] == spec["head"] and run["head_branch"] == spec["branch"]
    assert run["event"] == "pull_request" and run["run_attempt"] == 1
    assert run["repository"]["full_name"] == "TrillionniumFoundation/hepta-private-ci"
    assert run["head_repository"]["id"] == run["repository"]["id"] == 1320694176
    assert [p["number"] for p in run["pull_requests"]] == [spec["pr"]]
    assert run["head_sha"] in PARENTS and run["head_sha"] != HEAD

results = {}
post_paths = []
summary = []
for phase, allowed in [("standard-cancel-v1", STANDARD), ("force-fanin-v2", FORCE)]:
    result = read(phase + "/records/RESULT.json")
    results[phase] = result
    assert [s["run_id"] for s in result["specs"]] == allowed
    assert [o["spec"]["run_id"] for o in result["outcomes"]] == allowed
    for index, spec in enumerate(result["specs"], 1):
        run_id = spec["run_id"]
        prefix = f"{phase}/records/{index:02d}-{run_id}"
        integration_guard(prefix)
        before = read(prefix + ".before.json")
        identity(before, spec)
        assert before["status"] != "completed"
        jobs = read(prefix + ".jobs-before.json")
        assert len(jobs["jobs"]) == jobs["total_count"]
        request_path = prefix + ".cancel-result.json"
        post_paths.append(request_path)
        request = read(request_path)
        endpoint = "force-cancel" if phase == "force-fanin-v2" else "cancel"
        assert request["method"] == "POST"
        assert request["repository_endpoint"] == f"actions/runs/{run_id}/{endpoint}"
        assert request["command_exit_code"] == 0 and request["http_status"] == 202
        assert request["post_process_invocations"] == 1 and request["post_retried"] is False
        if phase == "force-fanin-v2":
            remaining = [j for j in jobs["jobs"] if j["status"] != "completed"]
            assert len(remaining) == 1
            fanin = remaining[0]
            assert fanin["id"] == FANINS[run_id] and fanin["status"] == "queued"
            assert fanin["name"] in ("CI required", "Architecture required")
            assert not fanin.get("runner_name") and not fanin.get("steps")
            eligible = read(prefix + ".force-eligibility.json")
            assert eligible["prior_standard_cancel_verified"] is True
            assert eligible["only_exact_empty_fanin_remains"] is True
            prior_index = STANDARD.index(run_id) + 1
            prior_name = f"standard-cancel-v1/records/{prior_index:02d}-{run_id}.cancel-result.json"
            assert eligible["prior_bytes"] == len(data[prior_name])
            assert eligible["prior_sha256"] == hashlib.sha256(data[prior_name]).hexdigest()
            assert eligible["prior_cancel_receipt"] == read(prior_name)
        else:
            final = json.loads((ROOT / f"final-cleanup-api-{run_id}.json").read_bytes())
            identity(final, spec)
            assert final["status"] == "completed" and final["conclusion"] == "cancelled"
            summary.append({
                "run_id": run_id, "pr": spec["pr"], "head": spec["head"],
                "branch": spec["branch"], "before_status": before["status"],
                "before_jobs": [{"id": j["id"], "name": j["name"],
                    "status": j["status"], "conclusion": j["conclusion"],
                    "step_records": len(j.get("steps") or []),
                    "runner_assigned": bool(j.get("runner_name"))} for j in jobs["jobs"]],
                "final_status": final["status"], "final_conclusion": final["conclusion"],
                "force_followup": run_id in FORCE,
            })
assert sorted(n for n in data if n.endswith(".cancel-result.json")) == sorted(post_paths)
assert results["force-fanin-v2"]["all_original_runs_terminal"] is True
assert results["force-fanin-v2"]["unresolved_original_run_ids"] == []
assert set(results["standard-cancel-v1"]["unresolved_original_run_ids"]) == set(FORCE)
assert all(x["after_status"] == "completed" and x["after_conclusion"] == "cancelled"
           for x in results["force-fanin-v2"]["outcomes"])
assert all(not re.search(rb"(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})", b)
           for b in data.values())
audit = {
    "schema": "mem8.superseded-ci-cleanup.independent-audit.v1",
    "status": "passed", "integration_head": HEAD, "integration_tree": TREE,
    "archive_bytes": len(blob), "archive_sha256": hashlib.sha256(blob).hexdigest(),
    "archive_git_blob": "812871aeb4579ab95c1c3b470564e612cffbaf83",
    "regular_members_read": len(data), "manifest_entries_verified": 388,
    "standard_cancel_http_202": 11, "force_cancel_http_202": 5,
    "post_retries": 0, "independent_final_runs_cancelled": 11,
    "integration_run_ids_cancelled": [], "cancelled_is_pass": False,
    "native_tests_launched_by_cleanup": 0, "model_requests_launched_by_cleanup": 0,
    "original_before_job_records_preserved": True, "runs": summary,
    "limits": [
        "Job and step metadata are retained; no prior test count is overwritten with zero.",
        "Queued fan-ins with no runner/steps had no observed step execution, not all jobs in the old run.",
        "Decoded API JSON plus safe POST receipts are not every HTTP wire byte.",
        "This cleanup does not prove hosted CI or the integrated source passed.",
    ],
}
(ROOT / "CLEANUP_INDEPENDENT_AUDIT.json").write_text(json.dumps(audit, indent=2) + "\n")
print(json.dumps({k: v for k, v in audit.items() if k not in ("runs", "limits")}, indent=2))
