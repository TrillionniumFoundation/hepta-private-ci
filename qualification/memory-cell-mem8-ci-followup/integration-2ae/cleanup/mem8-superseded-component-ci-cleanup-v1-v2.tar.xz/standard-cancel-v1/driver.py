from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
import traceback

TASK = Path(__file__).resolve().parent
RECORDS = TASK / "records"
REPO = "TrillionniumFoundation/hepta-private-ci"
INTEGRATED = "2ae5215beaf8d7b7df111a090b82134beae2683d"
TREE = "12159640adcf073b51f3837e75575e11f5c20233"
G = "9d9bdfbaeeec3c618f3fc80e2f663a29c13f4b27"
PROVIDER = "55951ed9094ae894f0256a3461fd9504ef060473"
DEPENDENCY = "f1fd544b3e12ed6aca83872cdeda8114a1e058c0"
PARENTS = [G, PROVIDER, DEPENDENCY]
GROUPS = [
    (5934, DEPENDENCY, "codex/mem8-dependency-f1fd544b-20261111-ed353817", [42969638203,42969638208,42969638213,42969638232,42969638234,42969638328,42969638251]),
    (5926, G, "codex/mem8-native-context-smoke-20261111-ed353817", [42964451586,42964451559,42964451650]),
    (5908, PROVIDER, "codex/mem8-provider-smoke-receipts-20261111-ed353817", [42953344593]),
]
SPECS = [{"pr": pr, "head": head, "branch": branch, "run_id": rid} for pr, head, branch, ids in GROUPS for rid in ids]
ENV = dict(os.environ)
ENV.pop("GH_DEBUG", None)
ENV["GH_HOST"] = "github.com"


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    path = RECORDS / name
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def get(endpoint, label):
    command = ["gh", "api", "--method", "GET", "repos/" + REPO + "/" + endpoint]
    completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=ENV, timeout=45)
    save(label + ".transport.json", {"method": "GET", "repository_endpoint": endpoint, "exit_code": completed.returncode, "stdout_bytes": len(completed.stdout), "stdout_sha256": sha(completed.stdout), "stderr": completed.stderr.decode(errors="replace"), "observed_at": now()})
    assert completed.returncode == 0, ("GET failed", endpoint, completed.returncode)
    value = json.loads(completed.stdout)
    save(label + ".json", value)
    return value


def guard(label):
    pr = get("pulls/5935", label + ".integration-pr")
    assert pr["head"]["sha"] == INTEGRATED, "integration PR head changed; no component cancellation"
    obj = get("git/commits/" + INTEGRATED, label + ".integration-commit")
    assert obj["sha"] == INTEGRATED and obj["tree"]["sha"] == TREE
    assert [value["sha"] for value in obj["parents"]] == PARENTS


def verify_run(value, spec):
    assert value["id"] == spec["run_id"]
    assert value["head_sha"] == spec["head"] != INTEGRATED
    assert value["head_branch"] == spec["branch"]
    assert value["event"] == "pull_request"
    assert value["run_attempt"] == 1, "attempt changed; do not cancel a new attempt"
    assert value["repository"]["full_name"] == REPO
    assert value["head_repository"]["full_name"] == REPO
    assert spec["pr"] in [item["number"] for item in value["pull_requests"]]
    assert value["id"] not in (42971470498,42971470233,42971470466)


def summarize_jobs(value):
    return [{"id": job["id"], "name": job["name"], "status": job["status"], "conclusion": job["conclusion"], "started_at": job["started_at"], "completed_at": job["completed_at"], "runner_name": job.get("runner_name"), "had_step_execution": any(step["status"] in ("in_progress", "completed") for step in job.get("steps", [])), "active_steps": [step["name"] for step in job.get("steps", []) if step["status"] == "in_progress"]} for job in value["jobs"]]


def cancel_once(spec, label):
    endpoint = "actions/runs/" + str(spec["run_id"]) + "/cancel"
    save(label + ".cancel-intent.json", {"repository": REPO, "endpoint": endpoint, "method": "POST", "spec": spec, "authorized_scope": "The 11 explicitly listed superseded component runs only", "reason": "Exact component is a direct parent of integration2ae; prioritize the integrated candidate", "started_at": now(), "retry_policy": "No POST retry after an unknown acknowledgement", "cancelled_is_not_pass": True})
    try:
        completed = subprocess.run(["gh", "api", "--include", "--method", "POST", "repos/" + REPO + "/" + endpoint], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=ENV, timeout=45)
    except subprocess.TimeoutExpired as error:
        save(label + ".cancel-result.json", {"status": "UNKNOWN_ACK", "observed_at": now(), "stdout_bytes": len(error.stdout or b""), "stdout_sha256": sha(error.stdout or b""), "stderr_bytes": len(error.stderr or b""), "stderr_sha256": sha(error.stderr or b""), "post_will_not_be_retried": True})
        observed = get("actions/runs/" + str(spec["run_id"]), label + ".unknown-ack-original-run")
        verify_run(observed, spec)
        if observed["status"] == "completed":
            return "TERMINAL_AFTER_UNKNOWN_ACK_NO_POST_REPLAY"
        raise RuntimeError("cancel acknowledgement unknown; original identity retained, no replay")
    text = completed.stdout.decode(errors="replace")
    status_lines = re.findall(r"^HTTP/\S+\s+(\d{3})[^\n]*", text, re.MULTILINE)
    status = int(status_lines[-1]) if status_lines else None
    safe_headers = [line for line in text.splitlines() if re.match(r"(?i)^(HTTP/|date:|x-github-request-id:|content-type:|content-length:)", line)]
    record = {"method": "POST", "repository_endpoint": endpoint, "command_exit_code": completed.returncode, "http_status": status, "response_status_and_safe_headers": safe_headers, "stdout_bytes": len(completed.stdout), "stdout_sha256": sha(completed.stdout), "stderr": completed.stderr.decode(errors="replace"), "observed_at": now(), "post_process_invocations": 1, "post_retried": False}
    save(label + ".cancel-result.json", record)
    if completed.returncode == 0 and status == 202:
        return "CANCEL_ACCEPTED"
    observed = get("actions/runs/" + str(spec["run_id"]), label + ".post-error-original-run")
    verify_run(observed, spec)
    if observed["status"] == "completed":
        return "BECAME_TERMINAL_DURING_CANCEL_REQUEST"
    raise RuntimeError("cancel not accepted; stopping without retries or other scopes")


def main():
    os.umask(0o077)
    RECORDS.mkdir(mode=0o700)
    assert len(SPECS) == len({item["run_id"] for item in SPECS}) == 11
    save("INPUT.json", {"specs": SPECS, "integration_commit": INTEGRATED, "integration_tree": TREE, "integration_parents": PARENTS, "authorized_by": "/root explicit task instruction", "sequential_mutations": True, "no_dispatch_rerun_ref_or_model_actions": True, "started_at": now()})
    outcomes = []
    for index, spec in enumerate(SPECS):
        label = str(index + 1).zfill(2) + "-" + str(spec["run_id"])
        guard(label)
        before = get("actions/runs/" + str(spec["run_id"]), label + ".before")
        verify_run(before, spec)
        jobs = get("actions/runs/" + str(spec["run_id"]) + "/jobs?per_page=100", label + ".jobs-before")
        assert jobs["total_count"] == len(jobs["jobs"]) <= 100
        summary = {"spec": spec, "label": label, "before_status": before["status"], "before_conclusion": before["conclusion"], "before_jobs": summarize_jobs(jobs)}
        if before["status"] == "completed":
            summary["action"] = "SKIPPED_ALREADY_TERMINAL"
        else:
            summary["action"] = cancel_once(spec, label)
        after = get("actions/runs/" + str(spec["run_id"]), label + ".after")
        verify_run(after, spec)
        summary.update(after_status=after["status"], after_conclusion=after["conclusion"], observed_at=now())
        outcomes.append(summary)
        save(label + ".summary.json", summary)
        print("MEM8_SUPERSEDED_CI " + json.dumps({key: value for key, value in summary.items() if key != "before_jobs"}), flush=True)
    # Bounded readback only. Cancellation itself is never retried.
    unresolved = {item["spec"]["run_id"]: item for item in outcomes if item["after_status"] != "completed"}
    for round_number in range(1, 13):
        if not unresolved:
            break
        time.sleep(5)
        for rid, item in list(unresolved.items()):
            spec = item["spec"]
            label = item["label"] + ".terminal-" + str(round_number).zfill(2)
            current = get("actions/runs/" + str(rid), label)
            verify_run(current, spec)
            item.update(after_status=current["status"], after_conclusion=current["conclusion"], observed_at=now())
            if current["status"] == "completed":
                del unresolved[rid]
    for item in outcomes:
        spec = item["spec"]
        jobs = get("actions/runs/" + str(spec["run_id"]) + "/jobs?per_page=100", item["label"] + ".jobs-final")
        assert jobs["total_count"] == len(jobs["jobs"]) <= 100
        item["final_jobs"] = summarize_jobs(jobs)
    guard("final")
    result = {"specs": SPECS, "outcomes": outcomes, "unresolved_original_run_ids": sorted(unresolved), "all_original_runs_terminal": not unresolved, "integration_commit": INTEGRATED, "integration_tree": TREE, "cancelled_runs_count_as_pass": False, "already_executed_jobs_not_erased": True, "no_new_native_or_model_requests": True, "source_refs_unchanged": True, "finished_at": now()}
    save("RESULT.json", result)
    print("MEM8_SUPERSEDED_CI_RESULT " + json.dumps({"outcomes": [{key: value for key, value in item.items() if key not in ("before_jobs", "final_jobs")} for item in outcomes], "all_original_runs_terminal": not unresolved, "finished_at": result["finished_at"]}), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        failure = traceback.format_exc()
        if RECORDS.exists():
            save("DRIVER_FAILURE.json", {"traceback": failure, "failed_at": now(), "no_uncertain_post_will_be_retried": True})
        print(failure, flush=True)
        raise
