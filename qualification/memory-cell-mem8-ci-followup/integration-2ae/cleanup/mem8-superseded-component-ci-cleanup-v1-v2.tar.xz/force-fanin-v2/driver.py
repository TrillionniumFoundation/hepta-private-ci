from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
import traceback

TASK = Path(__file__).resolve().parent
RECORDS = TASK / "records"
REPO = "TrillionniumFoundation/hepta-private-ci"
INTEGRATED = "2ae5215beaf8d7b7df111a090b82134beae2683d"
TREE = "12159640adcf073b51f3837e75575e11f5c20233"
G = "9d9bdfbaeeec3c618f3fc80e2f663a29c13f4b27"
PROVIDER = "55951ed9094ae894f0256a3461fd9504ef060473"
DEPENDENCY = "f1fd544b3e12ed6aca83872cdeda8114a1e058c0"
PARENTS = [G, PROVIDER, DEPENDENCY]
GROUPS = [
    (5934, DEPENDENCY, "codex/mem8-dependency-f1fd544b-20261111-ed353817", [42969638232,42969638328]),
    (5926, G, "codex/mem8-native-context-smoke-20261111-ed353817", [42964451586,42964451650]),
    (5908, PROVIDER, "codex/mem8-provider-smoke-receipts-20261111-ed353817", [42953344593]),
]
SPECS = [{"pr": pr, "head": head, "branch": branch, "run_id": rid} for pr, head, branch, ids in GROUPS for rid in ids]
ENV = dict(os.environ)
ENV.pop("GH_DEBUG", None)
ENV["GH_HOST"] = "github.com"


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    path = RECORDS / name
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def get(endpoint, label):
    command = ["gh", "api", "--method", "GET", "repos/" + REPO + "/" + endpoint]
    completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=ENV, timeout=45)
    save(label + ".transport.json", {"method": "GET", "repository_endpoint": endpoint, "exit_code": completed.returncode, "stdout_bytes": len(completed.stdout), "stdout_sha256": sha(completed.stdout), "stderr": completed.stderr.decode(errors="replace"), "observed_at": now()})
    assert completed.returncode == 0, ("GET failed", endpoint, completed.returncode)
    value = json.loads(completed.stdout)
    save(label + ".json", value)
    return value


def guard(label):
    pr = get("pulls/5935", label + ".integration-pr")
    assert pr["head"]["sha"] == INTEGRATED, "integration PR head changed; no component cancellation"
    obj = get("git/commits/" + INTEGRATED, label + ".integration-commit")
    assert obj["sha"] == INTEGRATED and obj["tree"]["sha"] == TREE
    assert [value["sha"] for value in obj["parents"]] == PARENTS


def verify_run(value, spec):
    assert value["id"] == spec["run_id"]
    assert value["head_sha"] == spec["head"] != INTEGRATED
    assert value["head_branch"] == spec["branch"]
    assert value["event"] == "pull_request"
    assert value["run_attempt"] == 1, "attempt changed; do not cancel a new attempt"
    assert value["repository"]["full_name"] == REPO
    assert value["head_repository"]["full_name"] == REPO
    assert spec["pr"] in [item["number"] for item in value["pull_requests"]]
    assert value["id"] not in (42971470498,42971470233,42971470466)


def summarize_jobs(value):
    return [{"id": job["id"], "name": job["name"], "status": job["status"], "conclusion": job["conclusion"], "started_at": job["started_at"], "completed_at": job["completed_at"], "runner_name": job.get("runner_name"), "had_step_execution": any(step["status"] in ("in_progress", "completed") for step in job.get("steps", [])), "active_steps": [step["name"] for step in job.get("steps", []) if step["status"] == "in_progress"]} for job in value["jobs"]]


def force_cancel_once(spec, label):
    endpoint = "actions/runs/" + str(spec["run_id"]) + "/force-cancel"
    save(label + ".cancel-intent.json", {"repository": REPO, "endpoint": endpoint, "method": "POST", "spec": spec, "authorized_scope": "The five explicitly authorized old runs whose remaining jobs are empty always fan-in jobs only", "reason": "Exact component is a direct parent of integration2ae; prioritize the integrated candidate", "started_at": now(), "retry_policy": "No force-cancel POST retry after an unknown acknowledgement", "cancelled_is_not_pass": True})
    try:
        completed = subprocess.run(["gh", "api", "--include", "--method", "POST", "repos/" + REPO + "/" + endpoint], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=ENV, timeout=45)
    except subprocess.TimeoutExpired as error:
        save(label + ".cancel-result.json", {"status": "UNKNOWN_ACK", "observed_at": now(), "stdout_bytes": len(error.stdout or b""), "stdout_sha256": sha(error.stdout or b""), "stderr_bytes": len(error.stderr or b""), "stderr_sha256": sha(error.stderr or b""), "post_will_not_be_retried": True})
        observed = get("actions/runs/" + str(spec["run_id"]), label + ".unknown-ack-original-run")
        verify_run(observed, spec)
        if observed["status"] == "completed":
            return "TERMINAL_AFTER_UNKNOWN_ACK_NO_POST_REPLAY"
        raise RuntimeError("cancel acknowledgement unknown; original identity retained, no force-cancel replay")
    text = completed.stdout.decode(errors="replace")
    status_lines = re.findall(r"^HTTP/\S+\s+(\d{3})[^\n]*", text, re.MULTILINE)
    status = int(status_lines[-1]) if status_lines else None
    safe_headers = [line for line in text.splitlines() if re.match(r"(?i)^(HTTP/|date:|x-github-request-id:|content-type:|content-length:)", line)]
    record = {"method": "POST", "repository_endpoint": endpoint, "command_exit_code": completed.returncode, "http_status": status, "response_status_and_safe_headers": safe_headers, "stdout_bytes": len(completed.stdout), "stdout_sha256": sha(completed.stdout), "stderr": completed.stderr.decode(errors="replace"), "observed_at": now(), "post_process_invocations": 1, "post_retried": False}
    save(label + ".cancel-result.json", record)
    if completed.returncode == 0 and status == 202:
        return "FORCE_CANCEL_ACCEPTED"
    observed = get("actions/runs/" + str(spec["run_id"]), label + ".post-error-original-run")
    verify_run(observed, spec)
    if observed["status"] == "completed":
        return "BECAME_TERMINAL_DURING_CANCEL_REQUEST"
    raise RuntimeError("cancel not accepted; stopping without retries or other scopes")


def main():
    os.umask(0o077)
    RECORDS.mkdir(mode=0o700)
    assert len(SPECS) == len({item["run_id"] for item in SPECS}) == 5
    save("INPUT.json", {"phase": "force-cancel only the five retained always fan-in runs", "specs": SPECS, "integration_commit": INTEGRATED, "integration_tree": TREE, "integration_parents": PARENTS, "authorized_by": "/root explicit task instruction", "sequential_mutations": True, "no_dispatch_rerun_ref_or_model_actions": True, "started_at": now()})
    outcomes = []
    for index, spec in enumerate(SPECS):
        label = str(index + 1).zfill(2) + "-" + str(spec["run_id"])
        guard(label)
        before = get("actions/runs/" + str(spec["run_id"]), label + ".before")
        verify_run(before, spec)
        jobs = get("actions/runs/" + str(spec["run_id"]) + "/jobs?per_page=100", label + ".jobs-before")
        assert jobs["total_count"] == len(jobs["jobs"]) <= 100
        summary = {"spec": spec, "label": label, "before_status": before["status"], "before_conclusion": before["conclusion"], "before_jobs": summarize_jobs(jobs)}
        if before["status"] == "completed":
            summary["action"] = "SKIPPED_ALREADY_TERMINAL"
        else:
            original_labels = {42969638232: "04", 42969638328: "06", 42964451586: "08", 42964451650: "10", 42953344593: "11"}
            expected_jobs = {42969638232: (130368089800, "Architecture required"), 42969638328: (130368414680, "CI required"), 42964451586: (130368751440, "Architecture required"), 42964451650: (130368975012, "CI required"), 42953344593: (130365956011, "CI required")}
            prior_path = Path("/home/qian-qi/mem8-superseded-ci-cleanup-ed353817-v1/records") / (original_labels[spec["run_id"]] + "-" + str(spec["run_id"]) + ".cancel-result.json")
            prior_bytes = prior_path.read_bytes()
            prior = json.loads(prior_bytes)
            expected_endpoint = "actions/runs/" + str(spec["run_id"]) + "/cancel"
            prior_valid = prior.get("method") == "POST" and prior.get("repository_endpoint") == expected_endpoint and prior.get("command_exit_code") == 0 and prior.get("http_status") == 202 and prior.get("post_process_invocations") == 1 and prior.get("post_retried") is False
            unfinished = [job for job in jobs["jobs"] if job["status"] != "completed"]
            expected_job, expected_name = expected_jobs[spec["run_id"]]
            fanin_only = len(unfinished) == 1 and unfinished[0]["id"] == expected_job and unfinished[0]["name"] == expected_name and unfinished[0]["status"] == "queued" and not unfinished[0].get("runner_name") and not unfinished[0].get("steps")
            save(label + ".force-eligibility.json", {"prior_path": str(prior_path), "prior_bytes": len(prior_bytes), "prior_sha256": sha(prior_bytes), "prior_cancel_receipt": prior, "prior_standard_cancel_verified": prior_valid, "only_exact_empty_fanin_remains": fanin_only, "unfinished_jobs": summarize_jobs({"jobs": unfinished})})
            if prior_valid and fanin_only:
                summary["action"] = force_cancel_once(spec, label)
            else:
                summary["action"] = "SKIPPED_FORCE_ELIGIBILITY_MISMATCH"
        after = get("actions/runs/" + str(spec["run_id"]), label + ".after")
        verify_run(after, spec)
        summary.update(after_status=after["status"], after_conclusion=after["conclusion"], observed_at=now())
        outcomes.append(summary)
        save(label + ".summary.json", summary)
        print("MEM8_SUPERSEDED_CI_FORCE_FOLLOWUP " + json.dumps({key: value for key, value in summary.items() if key != "before_jobs"}), flush=True)
    # Bounded readback only. Force cancellation itself is never retried.
    unresolved = {item["spec"]["run_id"]: item for item in outcomes if item["after_status"] != "completed"}
    for round_number in range(1, 13):
        if not unresolved:
            break
        time.sleep(5)
        for rid, item in list(unresolved.items()):
            spec = item["spec"]
            label = item["label"] + ".terminal-" + str(round_number).zfill(2)
            current = get("actions/runs/" + str(rid), label)
            verify_run(current, spec)
            item.update(after_status=current["status"], after_conclusion=current["conclusion"], observed_at=now())
            if current["status"] == "completed":
                del unresolved[rid]
    for item in outcomes:
        spec = item["spec"]
        jobs = get("actions/runs/" + str(spec["run_id"]) + "/jobs?per_page=100", item["label"] + ".jobs-final")
        assert jobs["total_count"] == len(jobs["jobs"]) <= 100
        item["final_jobs"] = summarize_jobs(jobs)
    guard("final")
    result = {"specs": SPECS, "outcomes": outcomes, "unresolved_original_run_ids": sorted(unresolved), "all_original_runs_terminal": not unresolved, "integration_commit": INTEGRATED, "integration_tree": TREE, "cancelled_runs_count_as_pass": False, "already_executed_jobs_not_erased": True, "no_new_native_or_model_requests": True, "source_refs_unchanged": True, "finished_at": now()}
    save("RESULT.json", result)
    package_event(result)
    print("MEM8_SUPERSEDED_CI_FORCE_FOLLOWUP_RESULT " + json.dumps({"outcomes": [{key: value for key, value in item.items() if key not in ("before_jobs", "final_jobs")} for item in outcomes], "all_original_runs_terminal": not unresolved, "finished_at": result["finished_at"]}), flush=True)


def package_event(result):
    import io
    import stat
    import tarfile
    original = Path('/home/qian-qi/mem8-superseded-ci-cleanup-ed353817-v1')
    original_exit = Path('/home/qian-qi/.local/state/hepta-runtime-mac-worker/terminals/dpty-d8e80c3dda357e8aa563edfc58843c1fc812fe184ca3098609dd47571399ea09/exit.json')
    deadline = time.monotonic() + 180
    while not original_exit.is_file() and time.monotonic() < deadline:
        time.sleep(5)
    assert original_exit.is_file(), 'Original standard-cancel driver still running; no incomplete archive publication'
    exit_record = json.loads(original_exit.read_text())
    assert exit_record['state'] == 'exited' and exit_record['output_complete'] is True
    assert (original / 'records/RESULT.json').is_file(), 'Preserve original failure; original phase result missing'
    data_files = {}
    for label, directory in [('standard-cancel-v1', original), ('force-fanin-v2', TASK)]:
        for path in sorted(directory.rglob('*')):
            if path.is_file() and (path == directory / 'driver.py' or path.parent == directory / 'records'):
                before = path.lstat()
                assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size < 2 * 1024 * 1024
                raw = path.read_bytes()
                after = path.lstat()
                assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
                data_files[label + '/' + str(path.relative_to(directory))] = raw
    data_files['standard-cancel-v1/original-pty-exit.json'] = original_exit.read_bytes()
    data_files['standard-cancel-v1/original-pty-output.raw.log'] = (original_exit.parent / 'output.log').read_bytes()
    one = json.loads(data_files['standard-cancel-v1/records/INPUT.json'])
    two = json.loads(data_files['force-fanin-v2/records/INPUT.json'])
    assert len(one['specs']) == 11 and len(two['specs']) == 5
    full_ids = {item['run_id'] for item in one['specs']}
    assert {item['run_id'] for item in two['specs']} <= full_ids
    for prefix, inp, suffix in [('standard-cancel-v1', one, '/cancel'), ('force-fanin-v2', two, '/force-cancel')]:
        posts = [json.loads(raw) for name, raw in data_files.items() if name.startswith(prefix + '/records/') and name.endswith('.cancel-result.json')]
        assert len(posts) <= len(inp['specs'])
        for post in posts:
            assert post.get('post_retried') is False and post['method'] == 'POST'
            assert post['repository_endpoint'].endswith(suffix)
            rid = int(post['repository_endpoint'].split('/')[2])
            assert rid in {item['run_id'] for item in inp['specs']} and rid not in (42971470498, 42971470233, 42971470466)
    readme = '''# Superseded component CI cleanup: two explicitly authorized phases

The integrated source is2ae5215beaf8d7b7df111a090b82134beae2683d/tree12159640adcf073b51f3837e75575e11f5c20233. Its three exact parents are G9d9bdfb, provider55951, and dependencyf1fd. This event only cancels the11 specifically enumerated old component runs; it never cancels the new integration or a later evidence branch.

Phase1 issues one ordinary cancel POST per eligible old run after fresh PR/head/branch/event/attempt/repository/parent guards. Already-terminal runs are skipped. Phase2 contains at most one force-cancel POST for each of five explicitly authorized old runs whose normal cancel was accepted but whose exact always fan-in remained queued with no runner and no steps. Original normal-cancel receipts are prerequisites. Unexpected identity, terminal state or nonempty/new work prevents force cancellation.

All before/after workflow and job payloads, original normal-cancel and followup request receipts, and exact scripts are preserved. GET JSON payloads are decoded and serialized; transport records retain the byte length and SHA256 of gh stdout. POST receipts retain status plus safe response headers and stdout digest, not authentication values. These are not a claim to capture every HTTP wire byte. No credential values, process environment or private owner files are included.

Cancellation is never a pass or proof of no prior execution. Original job names, steps, statuses and results remain recorded. Prior test counts and failures are not replaced with zero; this cleanup itself launches zero native tests and zero model requests. The standard-cancel phase may correctly end with pending always fan-ins; the separate force-cancel phase records what subsequently changed. New integration source qualification remains independent.

The first local cleanup driver has a complete terminal PTY archive. The second driver packages this evidence after all force-cancel operations and readbacks, so its later artifact-upload/terminal stdout is not embedded in its own archive. Its API RESULT is included. This package creates only immutable evidence blobs, not source or workflow edits, refs, reruns, model calls, or owner/service operations.
'''
    data_files['README.md'] = readme.encode()
    manifest_files = []
    for name, raw in sorted(data_files.items()):
        assert not re.search(rb'gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,}', raw), name
        manifest_files.append({'path': name, 'bytes': len(raw), 'sha256': sha(raw)})
    data_files['FILE_MANIFEST.json'] = (json.dumps({'manifest_excludes_itself': True, 'files': manifest_files}, indent=2) + '\n').encode()
    archive = TASK / 'mem8-superseded-component-ci-cleanup-v1-v2.tar.xz'
    with tarfile.open(archive, 'w:xz') as tar:
        for name, raw in sorted(data_files.items()):
            info = tarfile.TarInfo(name); info.size = len(raw); info.mode = 0o644
            tar.addfile(info, io.BytesIO(raw))
    raw = archive.read_bytes()
    assert len(raw) <= 500000
    with tarfile.open(archive, 'r:xz') as tar:
        for member in tar.getmembers():
            assert tar.extractfile(member).read() == data_files[member.name]
    archive_blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    manifest = {'schema': 'hepta.mem8.superseded-ci-cleanup.package.v1', 'archive_name': archive.name, 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': archive_blob, 'members': len(data_files), 'integration_commit': INTEGRATED, 'integration_tree': TREE, 'standard_cancel_authorized_runs': 11, 'force_followup_authorized_runs': 5, 'force_phase_all_original_runs_terminal': result['all_original_runs_terminal'], 'no_new_native_tests_or_model_requests': True, 'cancelled_is_pass': False, 'all_tar_member_bytes_read_back': True}
    manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
    (TASK / 'MANIFEST.json').write_bytes(manifest_raw)
    def blob(value):
        import base64
        expected = hashlib.sha1(b'blob ' + str(len(value)).encode() + b'\0' + value).hexdigest()
        payload = json.dumps({'encoding': 'base64', 'content': base64.b64encode(value).decode()}).encode()
        completed = subprocess.run(['gh', 'api', '--method', 'POST', 'repos/' + REPO + '/git/blobs', '--input', '-'], input=payload, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=ENV, timeout=45)
        assert completed.returncode == 0, 'Artifact blob upload failed; original cleanup is not replayed'
        response = json.loads(completed.stdout); assert response['sha'] == expected
        return expected
    assert blob(raw) == archive_blob
    manifest_blob = blob(manifest_raw)
    publication = {**manifest, 'manifest_git_blob': manifest_blob, 'published_at': now()}
    (TASK / 'PUBLICATION.json').write_text(json.dumps(publication, indent=2) + '\n')
    print('MEM8_SUPERSEDED_CI_CLEANUP_PUBLICATION ' + json.dumps(publication), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        failure = traceback.format_exc()
        if RECORDS.exists():
            save("DRIVER_FAILURE.json", {"traceback": failure, "failed_at": now(), "no_uncertain_post_will_be_retried": True})
        print(failure, flush=True)
        raise
