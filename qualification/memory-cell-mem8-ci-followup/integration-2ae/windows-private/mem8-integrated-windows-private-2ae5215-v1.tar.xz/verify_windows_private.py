#!/usr/bin/env python3
"""Audit original GitHub job log and both complete ZIPs without rerunning tests."""
import hashlib
import json
import pathlib
import re
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
HEAD = "2ae5215beaf8d7b7df111a090b82134beae2683d"
TREE = "12159640adcf073b51f3837e75575e11f5c20233"
PARENTS = ["9d9bdfbaeeec3c618f3fc80e2f663a29c13f4b27",
           "55951ed9094ae894f0256a3461fd9504ef060473",
           "f1fd544b3e12ed6aca83872cdeda8114a1e058c0"]
CASE = "circuit_cell::tests::credit_tests::signed_tests::signed_credit_rejects_cross_owner_ledger_episode_before_any_append"
INDEX = {x["id"]: x for x in json.loads((ROOT / "artifact-index.json").read_text())["artifacts"]}
ZIP_DIGESTS = {
    13834397879: (6690, "778afc2d2c9db9058a57d0d876e26c23272fad7c02e0f3cd87dd5c9088682c0d"),
    13833799483: (13524, "788a3e74929e08fdfa32d8adb3bab541f1fcb186d7b8e63f7b1e4445e2aa7f09"),
}

def sha(content):
    return hashlib.sha256(content).hexdigest()

def clean(text):
    text = text.replace("\r\n", "\n")
    text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text)
    return re.sub(r"(?m)^\d{4}-\d\d-\d\dT\S+\s", "", text)

zips = {}
zip_index = []
for ident, (size, digest) in ZIP_DIGESTS.items():
    path = ROOT / f"artifact-{ident}.zip"
    raw = path.read_bytes()
    assert len(raw) == size and sha(raw) == digest
    assert INDEX[ident]["size_in_bytes"] == size
    assert INDEX[ident]["digest"] == "sha256:" + digest
    assert INDEX[ident]["workflow_run"]["id"] == 42971470466
    assert INDEX[ident]["workflow_run"]["head_sha"] == HEAD
    with zipfile.ZipFile(path) as zipped:
        assert zipped.testzip() is None
        names = zipped.namelist()
        assert len(set(names)) == len(names)
        for name in names:
            p = pathlib.PurePosixPath(name)
            assert not p.is_absolute() and ".." not in p.parts
        zips[ident] = {n: zipped.read(n) for n in names}
    zip_index.append({"id": ident, "bytes": size, "sha256": digest,
                      "members": [{"path": n, "bytes": len(b), "sha256": sha(b)}
                                  for n, b in zips[ident].items()]})

run = json.loads((ROOT / "run.json").read_text())
jobs = json.loads((ROOT / "job-index.json").read_text())
assert run["id"] == 42971470466 and run["head_sha"] == HEAD and run["run_attempt"] == 1
assert run["event"] == "pull_request" and [p["number"] for p in run["pull_requests"]] == [5935]
assert run["status"] == "completed" and run["conclusion"] == "success"
assert jobs["total_count"] == 1 and len(jobs["jobs"]) == 1
job = jobs["jobs"][0]
assert job["id"] == 130360697942 and job["head_sha"] == HEAD
assert job["status"] == "completed" and job["conclusion"] == "success"
assert all(s["status"] == "completed" and s["conclusion"] == "success" for s in job["steps"])

credit = zips[13834397879]
assert set(credit) == {"credit-fixture.json", "credit-fixture.log"}
receipt = json.loads(credit["credit-fixture.json"])
assert receipt["status"] == "passed" and receipt["exit_code"] == receipt["command_exit_code"] == 0
assert receipt["source_sha"] == receipt["tested_sha"] == HEAD
assert receipt["run_id"] == "42971470466" and receipt["run_attempt"] == "1"
assert receipt["lane"] == "source-head" and receipt["case"] == CASE
for field in ("before", "after"):
    assert receipt[field] == {"commit": HEAD, "tree": TREE, "parents": PARENTS, "dirty": False}
assert receipt["log_bytes"] == len(credit["credit-fixture.log"]) == 43815
assert receipt["log_sha256"] == sha(credit["credit-fixture.log"]) == "a1185d07dd03242a9170d64fb600998e99a2ae508666ae333d44cb7b8c8c96b1"
assert receipt["command"][-4:] == ["--no-tests", "fail", "--retries", "0"]
assert receipt["observed_passed_tests"] == receipt["named_pass_rows"] == 1
assert receipt["observed_failed_tests"] == 0
credit_text = clean(credit["credit-fixture.log"].decode())
assert re.findall(r"(?m)^\s*PASS\s+\[[^\]]+\]\s+codex-hepta-agentd\s+(.+)$", credit_text) == [CASE]
assert not re.search(r"(?m)^\s*(?:FAIL|RETRY|FLAKY)\s+\[", credit_text)
assert re.findall(r"Summary\s+\[[^\]]+\]\s+(.*)", credit_text) == ["1 test run: 1 passed, 270 skipped"]
assert re.findall(r"Nextest run ID ([0-9a-f-]{36})", credit_text) == ["afb0df92-58ed-4996-ae5d-2d27b08aab7a"]

raw = (ROOT / "github-job-130360697942-decoded.log").read_bytes()
assert len(raw) == 332329 and sha(raw) == "c1dd975f06093db16cec3c560eb2c35ea3a201d663f77ff654fc142c8e8c0155"
log = clean(raw.decode())
starts = list(re.finditer(r"Nextest run ID ([0-9a-f-]{36}) with nextest profile: local", log))
expected = [(15, 5), (2, 26), (3, 147), (2, 148), (11, 260), (1, 270)]
assert len(starts) == len(expected)
groups = []
all_ids = []
for index, (start, (passed, filtered)) in enumerate(zip(starts, expected)):
    text = log[start.start():starts[index + 1].start() if index + 1 < len(starts) else len(log)]
    summary = re.findall(r"(?m)^\s*Summary\s+\[[^\]]+\]\s+(\d+) tests? run: (\d+) passed, (\d+) skipped\s*$", text)
    assert summary == [(str(passed), str(passed), str(filtered))]
    ids = re.findall(r"(?m)^\s*PASS\s+\[[^\]]+\]\s+(\S+)\s+([^\r\n]+)$", text)
    assert len(ids) == len(set(ids)) == passed
    assert not re.search(r"(?m)^\s*(?:FAIL|RETRY|FLAKY)\s+\[", text)
    all_ids.extend(ids)
    groups.append({"nextest_run_id": start.group(1), "passed": passed, "failed": 0,
                   "filtered": filtered, "retries": 0, "unique_test_ids": ids})
assert len(all_ids) == len(set(all_ids)) == 34
assert re.search(r"(?m)^Ran 6 tests in [0-9.]+s\s*$", log)
assert re.search(r"(?m)^OK\s*$", log)

control = zips[13833799483]
assert set(control) == {"manifest.json", "positive.log", "positive.rs",
                       "unchecked-create.log", "unchecked-create.patch", "unchecked-create.rs",
                       "path-check-open.log", "path-check-open.patch", "path-check-open.rs"}
manifest = json.loads(control["manifest.json"])
assert manifest["source_head"] == HEAD and manifest["source_tree"] == TREE
assert manifest["qualified"] is True and manifest["restored"] is True
assert manifest["production_sha256"] == sha(control["positive.rs"])
assert "--retries" in manifest["command"]
assert manifest["command"][manifest["command"].index("--retries") + 1] == "0"
controls = []
for lane in manifest["lanes"]:
    name = lane["lane"]
    assert sha(control[name + ".log"]) == lane["log_sha256"]
    assert sha(control[name + ".rs"]) == lane["production_sha256"]
    if name != "positive":
        assert sha(control[name + ".patch"]) == lane["patch_sha256"]
    text = clean(control[name + ".log"].decode())
    rows = re.findall(r"(?m)^\s*(PASS|FAIL)\s+\[[^\]]+\]\s+codex-utils-path\s+([^\r\n]+)$", text)
    unique = set(rows)
    assert len(rows) == 4 and len(unique) == 2  # immediate plus final output, not four executions
    assert {case: status for status, case in unique} == lane["statuses"]
    for kind, observation in lane["observations"].items():
        assert "PRIVATE_STATE_ACQUISITION " + kind + " " + observation in text
    summary = re.findall(r"(?m)^\s*Summary\s+\[[^\]]+\]\s+(.*)$", text)
    expected_summary = "2 tests run: 2 passed, 18 skipped" if name == "positive" else "2 tests run: 1 passed, 1 failed, 18 skipped"
    assert summary == [expected_summary]
    assert lane["exit_code"] == (0 if name == "positive" else 1)
    controls.append({"lane": name, "nextest_run_id": re.findall(r"Nextest run ID ([0-9a-f-]{36})", text)[0],
                     "passed": 2 if name == "positive" else 1, "failed": 0 if name == "positive" else 1,
                     "filtered": 18, "retries": 0, "expected_mutant_failure": name != "positive",
                     "raw_status_rows": len(rows), "unique_executed_test_ids": len(unique),
                     "statuses": lane["statuses"], "observations": lane["observations"]})

audit = {
    "schema": "mem8.integrated-windows-private.audit.v1", "status": "passed",
    "source_head": HEAD, "source_tree": TREE, "run_id": 42971470466, "attempt": 1,
    "job_id": 130360697942, "job_started_at": job["started_at"], "job_completed_at": job["completed_at"],
    "source_before_after_clean": True, "signed_credit": {"passed": 1, "failed": 0, "filtered": 270,
        "retries": 0, "case": CASE, "nextest_run_id": "afb0df92-58ed-4996-ae5d-2d27b08aab7a",
        "log_bytes": receipt["log_bytes"], "log_sha256": receipt["log_sha256"]},
    "regular_native_groups": groups, "regular_native_unique_cases": 34,
    "python_acquisition_checker_unittests": 6, "acquisition_controls": controls,
    "artifact_zip_digest_and_every_member_verified": zip_index,
    "full_job_log": {"bytes": len(raw), "sha256": sha(raw), "representation": "Full decoded GitHub job log re-encoded UTF-8; not HTTP wire capture."},
    "limits": ["Only this exact source, Windows platform and selected job are qualified.",
               "Acquisition positive-control two cases already occur in the 34-case regular roster.",
               "The two intentional mutant failures are preserved and are required negative-control evidence.",
               "Filtered cases are not selected skips or additional executions; no retry aggregation.",
               "The separate Windows current and blocking CI workflows remain independently pending."],
}
(ROOT / "WINDOWS_PRIVATE_INDEPENDENT_AUDIT.json").write_text(json.dumps(audit, indent=2) + "\n")
print(json.dumps({"status": "passed", "head": HEAD, "tree": TREE, "regular_native_unique_cases": 34,
                  "signed_credit": audit["signed_credit"], "acquisition_control_lanes": 3,
                  "python_unittests": 6, "zip_members_verified": sum(len(z) for z in zips.values())}, indent=2))
