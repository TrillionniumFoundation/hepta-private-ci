import base64,hashlib,io,json,os,tarfile
from pathlib import Path
r=Path('/home/qq/mem8-zsh-argv-probe-ai395-ed353817-v1')
i=Path('/home/qq/mem8-zsh-argv-probe-inputs-ai395-ed353817-v1')
def info(b):
 return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()}
result=json.loads((r/'RESULT.json').read_text()); obs=json.loads((r/'observation/OBSERVATION.json').read_text())
assert result['status']=='INERT_LINUX_OBSERVATION_COMPLETE'
assert obs['status']=='OBSERVATION_COMPLETE_NOT_A_FIX_QUALIFICATION'
assert result['donor_before']==result['donor_after'] and result['source_before']==result['source_after']
assert result['source_before']=={'head':'2ae5215beaf8d7b7df111a090b82134beae2683d','tree':'12159640adcf073b51f3837e75575e11f5c20233','status':''}
assert obs['zsh_before']==obs['zsh_after']
assert info(Path(obs['zsh_after']['path']).read_bytes())=={k:obs['zsh_after'][k] for k in ('bytes','sha256','git_blob')}
verified=0
for p in sorted((r/'prep').glob('*.json')):
 d=json.loads(p.read_text()); raw=r/d['raw']['path']; actual=info(raw.read_bytes())
 assert all(actual[k]==d['raw'][k] for k in actual) and d['exit_code']==0 and not d.get('timed_out')
 verified+=1
for p in sorted((r/'observation').glob('*.json')):
 d=json.loads(p.read_text())
 if 'command' not in d: continue
 assert d['exit_code']==0
 for field in ('stdout','stderr'):
  a=info((r/'observation'/d[field]['path']).read_bytes()); assert all(a[k]==d[field][k] for k in a)
 verified+=1
files={}
for name in ('PREP.json','RESULT.json','argv_probe.py'):
 files[name]=(r/name).read_bytes()
for name in ('launch_argv_probe.py','argv_probe_proposal.py'):
 files['inputs/'+name]=(i/name).read_bytes()
assert info(files['inputs/launch_argv_probe.py'])['sha256']=='04cf873daef0fa88577f81bab6e4b4f4bc57aac8b91a8e3fee0f082e7de7a54e'
assert info(files['inputs/argv_probe_proposal.py'])['sha256']=='575d3aa2712be2fdb60b7bb3224cb8d48e303b19128465c0507c9cd969f646d2'
for directory in ('prep','observation'):
 for p in sorted((r/directory).rglob('*')):
  assert not p.is_symlink()
  if p.is_file(): files[p.relative_to(r).as_posix()]=p.read_bytes()
files['SOURCE_FIXTURE.zsh']=(r/'source/codex-rs/app-server/tests/suite/zsh').read_bytes()
assert info(files['SOURCE_FIXTURE.zsh'])['git_blob']=='f796fa7201e16c95009ea776fd78b67a0169c153'
manifest={'scope':'ORIGINAL_COMPLETED_INERT_LINUX_CONTROL','verified_command_receipts':verified,'members':[{'path':p,**info(b)} for p,b in sorted(files.items())]}
files['MEMBER_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=r/'PROBE_EVIDENCE.tar.xz'
with out.open('xb') as stream:
 with tarfile.open(fileobj=stream,mode='w:xz',preset=6) as tar:
  for name,b in sorted(files.items()):
   m=tarfile.TarInfo(name);m.size=len(b);m.mode=0o600;m.mtime=0;tar.addfile(m,io.BytesIO(b))
 stream.flush();os.fsync(stream.fileno())
b=out.read_bytes();receipt={'path':str(out),'members':len(files),'verified_command_receipts':verified,**info(b)}
(r/'PROBE_EVIDENCE_MANIFEST.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'archive':receipt,'archive_base64':base64.b64encode(b).decode()}),flush=True)
