#!/usr/bin/env python3
"""Not yet executed: prepare an isolated checkout, then run the frozen probe."""

import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


HEAD = "2ae5215beaf8d7b7df111a090b82134beae2683d"
TREE = "12159640adcf073b51f3837e75575e11f5c20233"
DONOR = Path("/home/qq/mem8-integrated-sem-caller-ed353817-v1/source")
RUN = Path("/home/qq/mem8-zsh-argv-probe-ai395-ed353817-v1")
SOURCE = RUN / "source"
KEY = "mem8-zsh-argv-probe-ai395-ed353817-v1"
PROBE_SHA256 = "575d3aa2712be2fdb60b7bb3224cb8d48e303b19128465c0507c9cd969f646d2"
DOTSLASH = Path("/home/qq/mem8-owner-20261111-ed353817/dotslash-bootstrap-20261111/installation-v2/bin/dotslash")
DOTSLASH_BYTES = 1642752
DOTSLASH_SHA256 = "54a03b42f0337eba584bc33563237d45aeca11a34de2e7159f76d7695fe5b936"
DONOR_DIRTY = {
    ".github/workflows/hepta-mem-python.yml": "ca292ac9882fc6cfcb804f4b2312d34453f736ac",
    "codex-rs/hepta-memory/src/production_episodic.rs": "b34481b81ec0fc7284aa37540b7c638d809aa950",
    "codex-rs/hepta-memory/src/production_episodic_test_support.rs": "c822b1c5c4a579737d0487c36c8262926f5186e6",
    "codex-rs/hepta-memory/src/production_writer.rs": "52790168aa66861aae93e8184e2017b1b8ed56a4",
}


def fingerprint(path):
    raw = path.read_bytes()
    return {
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "git_blob": hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest(),
        "mode": oct(path.stat().st_mode & 0o777),
    }


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: launch_argv_probe.py FROZEN_ARGV_PROBE.py")
    started = time.time()
    total_deadline = time.monotonic() + 200
    phase_deadline = min(total_deadline, time.monotonic() + 100)
    probe_input = Path(sys.argv[1])
    if fingerprint(probe_input)["sha256"] != PROBE_SHA256:
        raise RuntimeError("unreviewed observation driver")
    RUN.mkdir(mode=0o700, exist_ok=False)
    os.chmod(RUN, 0o700)
    records = RUN / "prep"
    records.mkdir(mode=0o700)
    env = {
        key: value for key, value in os.environ.items()
        if not key.startswith(("GIT_", "HEPTA_LOCAL_PROVIDER_", "HEPTA_MEM_CONTEXT_", "HEPTA_MEM_NATIVE_"))
        and key not in {"HEPTA_EPISODIC_DRAIN_REGRESSION_CASE", "CARGO_BIN_EXE_codex"}
    }
    env.update(GIT_OPTIONAL_LOCKS="0", GIT_TERMINAL_PROMPT="0", PYTHONDONTWRITEBYTECODE="1")
    result = {
        "schema": "mem-zsh-argv-clean-checkout-v1", "run_id": KEY,
        "started_unix": started, "total_budget_seconds": 200,
        "prep_budget_seconds": 100, "observation_budget_seconds": 60,
        "native_rust_tests_executed": 0, "model_requests_issued_by_driver": 0,
        "scope": "LINUX_INERT_WRAPPER_CONTROL_NOT_MAC_REPRODUCTION",
        "status": "INCOMPLETE_OR_FAILED", "donor_before": None,
        "donor_after": None, "source_before": None, "source_after": None,
    }

    def save(name, value):
        with (RUN / name).open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")

    def command(label, argv, cwd, *, cap=20, allowed=(0,)):
        timeout = min(cap, total_deadline - time.monotonic() - 1, phase_deadline - time.monotonic() - 1)
        if timeout <= 0:
            raise TimeoutError("bounded phase exhausted before " + label)
        log = records / (label + ".raw.log")
        record = {"argv": [str(x) for x in argv], "cwd": str(cwd), "started_unix": time.time()}
        with log.open("xb") as stream:
            child = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stream,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                record["timed_out"] = True
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                code = child.wait(timeout=max(0, min(1, total_deadline - time.monotonic())))
            record.update(exit_code=code, finished_unix=time.time())
        record["raw"] = {"path": str(log.relative_to(RUN)), **fingerprint(log)}
        save(f"prep/{label}.json", record)
        if record.get("timed_out") or code not in allowed:
            raise RuntimeError(label + " failed; raw receipt retained")
        return log.read_text()

    def git_state(root, label, *, donor):
        state = {
            "head": command(label + "-head", ["git", "--no-replace-objects", "rev-parse", "HEAD"], root).strip(),
            "tree": command(label + "-tree", ["git", "--no-replace-objects", "rev-parse", "HEAD^{tree}"], root).strip(),
            "status": command(label + "-status", ["git", "status", "--porcelain=v1", "--untracked-files=all"], root),
        }
        if (state["head"], state["tree"]) != (HEAD, TREE):
            raise RuntimeError("source identity mismatch: " + label)
        if donor:
            expected_status = "".join(" M " + path + "\n" for path in sorted(DONOR_DIRTY))
            if state["status"] != expected_status:
                raise RuntimeError("donor status differs from frozen four-file preflight")
            state["dirty_files"] = {path: fingerprint(root / path) for path in sorted(DONOR_DIRTY)}
            if any(state["dirty_files"][path]["git_blob"] != expected for path, expected in DONOR_DIRTY.items()):
                raise RuntimeError("donor source bytes differ from frozen preflight")
        elif state["status"]:
            raise RuntimeError("new checkout is not clean")
        return state

    try:
        result["donor_before"] = git_state(DONOR, "donor-before", donor=True)
        if DOTSLASH.is_symlink() or not DOTSLASH.is_file():
            raise RuntimeError("known DotSlash input is absent or changed")
        result["dotslash"] = {"path": str(DOTSLASH), **fingerprint(DOTSLASH)}
        if result["dotslash"]["bytes"] != DOTSLASH_BYTES or result["dotslash"]["sha256"] != DOTSLASH_SHA256:
            raise RuntimeError("known DotSlash bytes changed")
        command("clone", ["git", "clone", "--shared", "--no-checkout", str(DONOR), str(SOURCE)], RUN, cap=55)
        command("checkout", ["git", "checkout", "--detach", HEAD], SOURCE, cap=25)
        result["source_before"] = git_state(SOURCE, "source-before", donor=False)
        copied_probe = RUN / "argv_probe.py"
        with copied_probe.open("xb") as stream:
            stream.write(probe_input.read_bytes())
        if fingerprint(copied_probe)["sha256"] != PROBE_SHA256:
            raise RuntimeError("probe copy identity changed")
        result["observation_driver"] = {"path": copied_probe.name, **fingerprint(copied_probe)}
        save("PREP.json", {**result, "status": "PREPARED_NO_OBSERVATION_YET", "finished_unix": time.time()})
        phase_deadline = min(total_deadline, time.monotonic() + 70)
        command("observation", [sys.executable, "-B", str(copied_probe), "--repo", str(SOURCE),
                "--output", str(RUN / "observation"), "--dotslash", str(DOTSLASH)], RUN, cap=70)
        observed = json.loads((RUN / "observation/OBSERVATION.json").read_text())
        if observed.get("status") != "OBSERVATION_COMPLETE_NOT_A_FIX_QUALIFICATION":
            raise RuntimeError("observation did not complete its exact-input gates")
        result["observation_receipt"] = fingerprint(RUN / "observation/OBSERVATION.json")
        result["observation_summary"] = observed["controls"]
        phase_deadline = total_deadline
        result["donor_after"] = git_state(DONOR, "donor-after", donor=True)
        result["source_after"] = git_state(SOURCE, "source-after", donor=False)
        if result["donor_after"] != result["donor_before"]:
            raise RuntimeError("donor status, bytes, or modes changed")
        if result["source_after"] != result["source_before"]:
            raise RuntimeError("isolated source changed")
        result["status"] = "INERT_LINUX_OBSERVATION_COMPLETE"
    except BaseException as error:
        result["error"] = f"{type(error).__name__}: {error}"
    finally:
        result["finished_unix"] = time.time()
        result["elapsed_seconds"] = time.time() - started
        save("RESULT.json", result)
        print(json.dumps(result), flush=True)
    return 0 if result["status"] == "INERT_LINUX_OBSERVATION_COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
