# Source-built zsh: a usable Bazel binding without a public release

Status: proposal only. No build, module update, CI change, or release has been executed. This is separate from the frozen 68-path source-format/caller task.

## Existing connection that can be reused

The original `defs.bzl` already has the required remote-action transport. `codex_rust_crate.extra_binaries_non_windows` turns each label into a `CARGO_BIN_EXE_<label-name>` runfile binding. `_runfile_env_file()` accepts either a declared executable or a target with exactly one file. `_workspace_root_test_impl()` adds that file **and merges its DefaultInfo.default_runfiles**. The generated launcher resolves its logical runfile path at test execution time.

Therefore a filegroup with one zsh executable in `srcs` and a build manifest in `data` can travel through the existing mechanism. The test receives the executor's runfile path. No runner absolute path belongs in `--test_env`, and no mutation of the DotSlash cache is necessary.

## Smallest source-build route to prepare

Use a new, test-only native source repository, evaluated on the Bazel client host before test execution. It should consume labels for the current C patch and the existing `.github/scripts/build-zsh-release-artifact.sh`, plus the fixed upstream source commit. Copy those declared inputs into the repository's own work area, invoke the source-only build script there, and expose the resulting native binary as a declared file. Source retrieval/build happens during this explicit repository preparation; the remote Rust test action receives the completed binary and manifest as runfiles and does not run Git or configure/make.

This avoids introducing an unproven cross-compiling configure/make target or a new public release. The existing CI matrix runs the Mac ARM leg on `macos-15` and tests `aarch64-apple-darwin`; its native host is suitable for that narrow initial build. The first binding should be limited to this existing supported Mac ARM leg, which owns the seven persistent failures. Do not enable a new Mac Intel zsh test capability or broaden all target/platform gates by implication. The same route can be qualified later for other already-supported fixture platforms.

The existing script currently chooses all available cores and has only an absolute `/bin/echo` smoke. For this use, add an explicit bounded build-jobs input (2), a repository execution deadline, and a build-identity output. Do not invoke `rust-release-zsh.yml`; that workflow publishes releases. Missing native prerequisites should fail this source build with their actual diagnostics, never select the old DotSlash artifact as an automatic fallback.

## Concrete source surfaces

| Surface | Required change | Evidence/constraint |
|---|---|---|
| `bazel/rules/zsh_source_repository.bzl` (new) | A lazy test-only repository rule consumes the current patch/build-script labels and fixed zsh commit, builds in its own directory, validates host OS/architecture, and exports zsh plus a sidecar manifest. | Repository work directories may be local; no local path is passed to the remote test. Bound the process and preserve build logs. No publishing credentials or release API. |
| `MODULE.bazel` | Declare the repository with the upstream full commit and source labels. | The rule/source labels bind rebuilds to actual patch and builder changes. No arbitrary "latest" revision. |
| `.github/scripts/build-zsh-release-artifact.sh` | Accept an explicit job cap and emit build metadata beside the binary; retain original source pin and source-only behavior. | Verify actual Git HEAD, patch bytes and builder bytes; capture compiler/tool versions and native target. Preserve existing positive interception test; add the PATH controls only after the C fix is reviewed. |
| `defs.bzl` / a platform configuration | A narrow Mac ARM extra-binary mapping, using the existing runfile exporter rather than a global host path. | Existing non-Windows mappings remain intact. A specific macOS+aarch64 selector prevents accidental expansion to unsupported Mac Intel. This is a small addition to the existing extra-binary selection logic, not a new launcher implementation. |
| `codex-rs/core/BUILD.bazel` | Add the source-built zsh label to that narrow mapping and include the actual checked-in C patch as test data for digest comparison. | Existing wrapper binary, all original cases and test budgets remain the same. |
| `codex-rs/core/tests/common/zsh_fork.rs` | For the declared source-built binding, resolve `cargo_bin("codex-zsh")`, validate its manifest and actual bytes, compare the included current patch digest, and use that exact path. | A supplied binding that is missing, mismatched, wrong-platform, or fails interception is an error. Do not turn it into `Ok(None)`, retry, or DotSlash fallback. Record selected binary identity in the test output. |

The generated repository can export a single-file target of this form (schematic, not yet a checked BUILD file):

```starlark
filegroup(
    name = "codex-zsh",
    srcs = ["bin/zsh"],
    data = ["bin/IDENTITY.json"],
    visibility = ["//visibility:public"],
)
```

The manifest must contain at least the full upstream commit, actual current C-patch SHA256, builder SHA256, host/native target, executable byte length and SHA256, build command, tool versions, and original build/interception results. The test checks the executable against that manifest, checks the manifest's patch against the declared current patch file, and retains the observed input identity. Bazel includes the binary and manifest in its action-input content digest. A successful run is still evidence only for the exact tested source and exact native binary.

## Why an environment-only patch is insufficient

Passing `/home/runner/.../zsh` through `--test_env` does not make the file an input to a remote action. Setting `DOTSLASH_CACHE` to a hand-made directory would also evade the pinned artifact contract. The existing fixture still downloads 0.104.0, so a checked-in C patch without a declared built-binary dependency does not exercise the repair. A runfile dependency and its source/build/executable identities close those specific gaps.

The supported no-release alternative is a separately built artifact imported into the same declared repository with `--override_repository`, **after** verifying its manifest against the exact current source inputs. That is useful for qualification but is not, by itself, a permanent default test binding. Its bytes must still be in the target's runfiles; an absolute path alone remains insufficient.

## Remaining decisions and limits

The C interception correction itself still needs review. The Linux inert probe can establish that dot/empty PATH entries reach the wrapper as bare `touch`; it cannot establish the original Mac runtime PATH or qualify the Mac repair. Source-built zsh must run the unchanged original Mac cases and preserve policy decisions, selected program identity, argv, errno/script behavior and the existing budgets. The native-source binding proposal does not modify those semantics.

This route closes test-input reproducibility without publishing a tool release. It does not claim that existing installed 0.104.0 bundles have changed. Distribution changes would remain a separate, explicit action.
