#!/usr/bin/env python3
"""PROPOSAL ONLY: bounded, isolated zsh argv observation; never run by import.

The Python EXEC_WRAPPER only prints sys.argv. It never executes the requested
program, contacts an escalation socket, or uses a provider. This is a Linux
control for the pinned C patch, not a reproduction of the Mac CI environment.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time


HEAD = "2ae5215beaf8d7b7df111a090b82134beae2683d"
TREE = "12159640adcf073b51f3837e75575e11f5c20233"
FIXTURE = "codex-rs/app-server/tests/suite/zsh"
FIXTURE_BLOB = "f796fa7201e16c95009ea776fd78b67a0169c153"
FIXTURE_SHA256 = "6f94e90693a7c6dcdc57bd8044786a7cdd0ccaa32f1815d5a1e47c3ce8a49d81"
CONTROLS = (
    ("absolute", "/usr/bin:/bin"),
    ("dot_first", ".:/usr/bin:/bin"),
    ("empty_first", ":/usr/bin:/bin"),
)


def identity(path):
    data = path.read_bytes()
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob": hashlib.sha1(
            f"blob {len(data)}\0".encode() + data
        ).hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--dotslash", type=Path, required=True)
    args = parser.parse_args()
    started = time.time()
    deadline = time.monotonic() + 60
    out = args.output.resolve()
    out.mkdir(mode=0o700, parents=False, exist_ok=False)
    os.chmod(out, 0o700)
    repo = args.repo.resolve(strict=True)
    receipt = {
        "schema": "mem-zsh-argv-observation-v1",
        "started_unix": started,
        "budget_seconds": 60,
        "platform": platform.platform(),
        "scope": "LINUX_CONTROL_NOT_ORIGINAL_MAC_ENVIRONMENT",
        "model_requests_issued_by_this_driver": 0,
        "escalation_ipc_used_by_this_driver": False,
        "controls": [],
    }

    def run(label, command, *, cwd=repo, env=None, cap=15):
        # Reserve one second inside the total budget for this driver's own
        # process-group cleanup; never signal an unrelated process.
        remaining = min(cap, deadline - time.monotonic() - 1)
        if remaining <= 0:
            raise TimeoutError("total 60 second budget exhausted")
        stdout = out / f"{label}.stdout"
        stderr = out / f"{label}.stderr"
        with stdout.open("xb") as so, stderr.open("xb") as se:
            child = subprocess.Popen(
                command, cwd=cwd, env=env, stdout=so, stderr=se,
                start_new_session=True,
            )
            try:
                rc = child.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=max(0, min(1, deadline - time.monotonic())))
                raise TimeoutError(f"{label} exceeded its remaining budget")
        record = {
            "command": [str(arg) for arg in command],
            "exit_code": rc,
            "stdout": {"path": stdout.name, **identity(stdout)},
            "stderr": {"path": stderr.name, **identity(stderr)},
        }
        (out / f"{label}.json").write_text(json.dumps(record, indent=2) + "\n")
        if rc:
            raise RuntimeError(f"{label} exited {rc}; retained raw logs")
        return stdout.read_text()

    def source_state(label):
        head = run(f"{label}-head", ["git", "rev-parse", "HEAD"]).strip()
        tree = run(f"{label}-tree", ["git", "rev-parse", "HEAD^{tree}"]).strip()
        status = run(f"{label}-status", [
            "git", "status", "--porcelain=v1", "--untracked-files=all"
        ])
        if (head, tree, status) != (HEAD, TREE, ""):
            raise RuntimeError("exact source or clean-source gate failed")
        return {"head": head, "tree": tree, "status": status}

    try:
        if sys.platform != "linux":
            raise RuntimeError("this approved proposal is a Linux-only control")
        receipt["source_before"] = source_state("before")
        fixture = repo / FIXTURE
        receipt["fixture"] = {"path": FIXTURE, **identity(fixture)}
        if receipt["fixture"]["git_blob"] != FIXTURE_BLOB or receipt["fixture"]["sha256"] != FIXTURE_SHA256:
            raise RuntimeError("DotSlash fixture does not match the frozen input")
        dotslash = args.dotslash.resolve(strict=True)
        receipt["dotslash"] = {"path": str(dotslash), **identity(dotslash)}
        fetched = run("dotslash-fetch", [str(dotslash), "--", "fetch", str(fixture)], cap=25).strip()
        zsh = Path(fetched).resolve(strict=True)
        if not zsh.is_file():
            raise RuntimeError("DotSlash fetch did not resolve a regular executable")
        receipt["zsh_before"] = {"path": str(zsh), **identity(zsh)}
        python = str(Path(sys.executable).resolve(strict=True))
        if any(character.isspace() for character in python):
            raise RuntimeError("Python shebang path contains whitespace")
        wrapper = out / "observe-exec-wrapper"
        wrapper.write_text(f"#!{python}\nimport json, sys\nprint(json.dumps(sys.argv))\n")
        wrapper.chmod(0o700)
        receipt["wrapper"] = {"path": wrapper.name, **identity(wrapper)}
        for name, value in (("absolute_preflight", "/usr/bin:/bin"), *CONTROLS):
            cwd = out / name
            cwd.mkdir(mode=0o700)
            env = {
                "PATH": value, "HOME": str(cwd), "ZDOTDIR": str(cwd),
                "TMPDIR": str(cwd), "LC_ALL": "C", "EXEC_WRAPPER": str(wrapper),
            }
            # Assign inside the script too, after any system zshenv. The values
            # are fixed controls and contain neither a quote nor a newline.
            command = "/usr/bin/true" if name == "absolute_preflight" else "touch -c never-created"
            script = f"export PATH='{value}'; {command}"
            raw = run(name, [str(zsh), "-fc", script], cwd=cwd, env=env, cap=5)
            observed = json.loads(raw)
            expected_tail = ["/usr/bin/true"] if name == "absolute_preflight" else ["touch", "-c", "never-created"]
            if not isinstance(observed, list) or len(observed) < 3 or observed[0] != str(wrapper) or observed[2:] != expected_tail:
                raise RuntimeError("wrapper argv contract failed; do not continue")
            if name == "absolute_preflight" and observed[1] != "/usr/bin/true":
                raise RuntimeError("absolute intercept preflight failed")
            if any(cwd.iterdir()):
                raise RuntimeError("unexpected file effect in private control directory")
            receipt["controls"].append({
                "name": name, "path_control": value, "argv": observed,
                "candidate_passed_to_wrapper": observed[1],
            })
        receipt["source_after"] = source_state("after")
        receipt["zsh_after"] = {"path": str(zsh), **identity(zsh)}
        if receipt["zsh_before"] != receipt["zsh_after"]:
            raise RuntimeError("zsh executable changed during the control")
        if receipt["wrapper"] != {"path": wrapper.name, **identity(wrapper)}:
            raise RuntimeError("observation wrapper changed")
        receipt["status"] = "OBSERVATION_COMPLETE_NOT_A_FIX_QUALIFICATION"
    except BaseException as error:
        receipt["status"] = "INCOMPLETE_OR_FAILED"
        receipt["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        receipt["finished_unix"] = time.time()
        receipt["elapsed_seconds"] = time.time() - started
        (out / "OBSERVATION.json").write_text(json.dumps(receipt, indent=2) + "\n")


if __name__ == "__main__":
    main()
