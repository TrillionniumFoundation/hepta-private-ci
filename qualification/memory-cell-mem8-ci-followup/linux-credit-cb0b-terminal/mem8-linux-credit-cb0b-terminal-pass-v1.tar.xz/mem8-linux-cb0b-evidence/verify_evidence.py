from pathlib import Path
import hashlib,json,lzma,re,xml.etree.ElementTree as E
p=Path(__file__).resolve().parent
case='circuit_cell::tests::credit_tests::signed_tests::signed_credit_rejects_cross_owner_ledger_episode_before_any_append'
head='cb0b276ffdb9852323cdd13ba9b4399b30ae0c37'
tree='61f266ce7f02e0c3b94c22871ebedcc72f28e456'
for stage,missing in [('prior-v2','docs/modules/MODULES.json'),('prior-v3','qualification/neuron-v13-generation/proposal_worker.py')]:
 r=json.loads((p/stage/'receipt-observation.json').read_text())['receipt']
 b=lzma.decompress((p/stage/'raw.log.xz').read_bytes())
 assert len(b)==r['log_bytes'] and hashlib.sha256(b).hexdigest()==r['log_sha256']
 assert r['status']=='failed' and r['command_exit_code']==101 and r['observed_passed_tests']==r['observed_failed_tests']==0
 assert r['before']==r['after'] and not r['before']['dirty'] and r['before']['tree']==tree
 assert missing in b.decode()
r=json.loads((p/'accepted-v4/linux-original-case-v4.json').read_text())
b=lzma.decompress((p/'accepted-v4/linux-original-case-v4.raw.log.xz').read_bytes())
assert len(b)==r['log_bytes']==66447 and hashlib.sha256(b).hexdigest()==r['log_sha256']=='ef58f77c3896332bb231f668c902db699b752fbae1d22e06f5051e5258fa0752'
assert r['status']=='passed' and r['command_exit_code']==r['exit_code']==0
assert r['observed_passed_tests']==1 and r['observed_failed_tests']==0 and r['minimum_tests']==1
assert r['source_sha']==r['tested_sha']==head and r['before']==r['after'] and r['before']['commit']==head and r['before']['tree']==tree and not r['before']['dirty']
assert r['command'][r['command'].index('--retries')+1]=='0' and r['command'][r['command'].index('-E')+1]=='test(='+case+')'
jb=(p/'accepted-v4/linux-original-case-v4.junit.xml').read_bytes()
assert hashlib.sha256(jb).hexdigest()=='4dec3dd690a937a84f258d0e9f4204e84fcbc74cf6daa40a1a7173bc80bb16fb'
d=E.fromstring(jb);cases=list(d.iter('testcase'))
assert len(cases)==1 and cases[0].get('classname')=='codex-hepta-agentd' and cases[0].get('name')==case
assert not any(c.find('failure') is not None or c.find('error') is not None or c.find('skipped') is not None for c in cases)
t=re.sub(r'\x1b\[[0-9;]*m','',b.decode())
assert d.get('uuid')=='62d14f47-4b5f-4427-8adc-de46e43fa154' and d.get('uuid') in t
assert len([line for line in t.splitlines() if re.search(r'\bPASS\b',line) and case in line])==1
assert len([line for line in t.splitlines() if 'Summary' in line and '1 test run: 1 passed (1 slow), 780 skipped' in line])==1
for f in json.loads((p/'MANIFEST.json').read_text())['files']:
 z=(p/f['path']).read_bytes();assert len(z)==f['bytes'] and hashlib.sha256(z).hexdigest()==f['sha256']
print(json.dumps({'verified':True,'source':head,'tree':tree,'executed':1,'passed':1,'failed':0,'selected_skipped':0,'filtered_or_ignored':780,'retries':0,'original_failures_preserved':2}))
