# MEM8 hosted Python evidence at common source 96038ccf

This package preserves the two original GitHub Actions artifact ZIPs from workflow run [42930925227](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42930925227), PR [5873](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5873). No tests were rerun to create this package.

The nine command receipts bind the actual checkout before and after execution to source commit `96038ccf0660154fac143ba6cbe4be81e00813e8`, tree `1277666f3285cdf006d36478e6f74ddec38e1fe0`, parent `adef61556284cc5b58c4f23a33d7c8455e821c3f`, with `dirty: false`. Each receipt uses lane `source-head`, and both `source_sha` and `tested_sha` equal the source commit. The original artifact names contain event merge SHA `dd51a402a5a3b64e685f1bc42144dd4be330ecc5`; that naming convention is not the tested checkout identity.

## Observed results

| Existing test group | Raw observed executions |
| --- | ---: |
| Source-memory integrity, fresh process, revocation | 35 |
| Candidate contracts and real Torch/OCR actor fixture | 17 |
| Selector | 10 |
| Replay | 6 |
| Trajectory | 5 |
| Selector study | 15 |
| Candidate retention runner | 7 |
| Composition mechanism | 7 |
| MEM6 attribution and inherited integrity | 52 |
| Total | 154 |

All 154 executions terminated with `ok`; there were zero failed or skipped tests. The groups contain 120 distinct test IDs and 34 repeated executions across groups. They must not be reported as 154 distinct capabilities or experiments.

`audit_hosted_mem.py` verifies the original ZIP byte hashes, ZIP member hashes, each receipt's source identity and clean before/after state, and the exact raw-log byte length and SHA256. It independently matches each unittest test header to its terminal `ok` and checks those counts against both the `Ran N tests` / `OK` footer and the receipt. Test output may contain JSON or docstrings between a test header and its terminal status, so a single-line `test_... ok` regex is insufficient. Every test ID is retained in `RAW_LOG_BINDING_AUDIT.json`.

The existing post-update revocation campaign also reports 14/14 scenarios, three exited writer processes, fourteen fresh reader processes, and all eight declared invariants true. Its original report explicitly retains `scientific_acceptance: HOLD`, `real_successor_task_benefit: false`, `production_adoption: false`, and no independent trust domain, full owner cold recovery, or external-effect fencing claim. Deletion in this campaign means logical read exclusion; historical snapshot bytes remain. The report records zero model calls. The complete original report and campaign files remain in the original integrity artifact ZIP.

## Contents and reproducibility

- `mem8-13816580885.zip`: original integrity artifact ZIP, including the command receipt, raw log, and existing revocation campaign files.
- `mem8-13816457341.zip`: original frozen candidate artifact ZIP, including eight command receipts, raw logs, source checks, and environment records.
- `ARTIFACT_METADATA.json`: original artifact identities and downloaded ZIP byte hashes, without temporary signed URLs.
- `RAW_LOG_BINDING_AUDIT.json`: independent raw-log, case-ID, and source-binding audit.
- `REVOCATION_CAMPAIGN_REPORT.json`: readable copy of `campaign/REPORT.json` from the original integrity artifact.
- `audit_hosted_mem.py`: standard-library-only audit. Run `python3 audit_hosted_mem.py` in a disposable copy of this directory to regenerate the two derived audit/report files; original ZIP bytes are only read.
- `INDEX.json`: SHA256 and length of each other file in this package.

These are existing research-memory Python/Torch/OCR tests. This package does not establish native Rust fixture repair, ordinary-agent production ownership, full repository CI success, or unseen-successor memory benefit. Pending or failed checks are not converted into passes.
