import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent
HEAD = "96038ccf0660154fac143ba6cbe4be81e00813e8"
TREE = "1277666f3285cdf006d36478e6f74ddec38e1fe0"
PARENT = "adef61556284cc5b58c4f23a33d7c8455e821c3f"
metadata = json.loads((ROOT / "ARTIFACT_METADATA.json").read_text())
rows = []
all_ids = []
artifacts = []
for item in metadata:
    payload = (ROOT / item["name"]).read_bytes()
    assert len(payload) == item["expected_bytes"]
    assert hashlib.sha256(payload).hexdigest() == item["expected_sha256"]
    with zipfile.ZipFile(ROOT / item["name"]) as archive:
        members = archive.namelist()
        assert len(members) == len(set(members))
        assert all(not name.startswith("/") and ".." not in Path(name).parts for name in members)
        artifact_record = {**item, "member_count": len(members), "members": []}
        for member in archive.infolist():
            data = archive.read(member.filename)
            artifact_record["members"].append({"path": member.filename, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        for name in members:
            if "/" in name or not name.endswith(".json"):
                continue
            record = json.loads(archive.read(name))
            if not isinstance(record, dict) or "log_file" not in record:
                continue
            assert record["source_sha"] == record["tested_sha"] == HEAD
            assert record["base_sha"] == PARENT
            assert record["lane"] == "source-head"
            assert record["before"] == record["after"]
            assert record["before"]["commit"] == HEAD
            assert record["before"]["tree"] == TREE
            assert record["before"]["parents"] == [PARENT]
            assert record["before"]["dirty"] is False
            assert record["status"] == "passed"
            assert record["exit_code"] == record["command_exit_code"] == record["returncode"] == 0
            assert record["timed_out"] is False and record["output_limit_exceeded"] is False
            assert record["observed_failed_tests"] == 0
            raw = archive.read(record["log_file"])
            assert len(raw) == record["log_bytes"]
            assert hashlib.sha256(raw).hexdigest() == record["log_sha256"]
            text = raw.decode()
            footers = list(re.finditer(r"(?m)^Ran (\d+) tests? in [^\n]+\n\s*\n?OK\s*(?:\n|$)", text))
            assert len(footers) == 1, (name, "missing/duplicate terminal OK")
            count = int(footers[0].group(1))
            headers = list(re.finditer(r"(?m)^test_[^\s]+ \(([^)\n]+)\)", text[:footers[0].start()]))
            assert len(headers) == count == record["observed_passed_tests"]
            cases = []
            for index, header in enumerate(headers):
                end = headers[index + 1].start() if index + 1 < len(headers) else footers[0].start()
                segment = text[header.start():end].rstrip()
                # The last case segment also contains unittest's dashed separator.
                segment = re.sub(r"\n-+\s*$", "", segment).rstrip()
                assert re.search(r"(?:\s|^)ok$", segment), (name, header.group(1), segment[-200:])
                assert not re.search(r"\.\.\. (?:skipped|expected failure|unexpected success)", segment)
                cases.append(header.group(1))
            assert len(cases) == len(set(cases))
            all_ids.extend(cases)
            rows.append({
                "artifact_id": item["id"],
                "artifact_name": item["artifact_name"],
                "zip_path": item["name"],
                "receipt_path": name,
                "raw_log_path": record["log_file"],
                "raw_log_bytes": len(raw),
                "raw_log_sha256": record["log_sha256"],
                "count_from_raw_footer": count,
                "count_from_raw_test_headers_and_terminal_ok": len(cases),
                "receipt_count": record["observed_passed_tests"],
                "source_before_after": record["before"],
                "actual_case_ids": cases,
                "all_case_statuses": "ok",
                "skips": 0,
                "timeouts": False,
                "truncation": False,
            })
        if "campaign/REPORT.json" in members:
            report = json.loads(archive.read("campaign/REPORT.json"))
            (ROOT / "REVOCATION_CAMPAIGN_REPORT.json").write_text(json.dumps(report, indent=2) + "\n")
        artifacts.append(artifact_record)
assert len(rows) == 9
assert sum(row["count_from_raw_footer"] for row in rows) == 154
result = {
    "schema": "hepta.mem8.hosted-python.raw-log-binding-audit.v1",
    "run_id": 42930925227,
    "source_sha": HEAD,
    "tree_sha": TREE,
    "parent_sha": PARENT,
    "artifact_label_merge_sha": "dd51a402a5a3b64e685f1bc42144dd4be330ecc5",
    "artifact_label_note": "Artifact names use the event merge SHA. All nine raw receipts independently bind actual source-head checkout to 96038ccf; artifact names are not treated as execution identity.",
    "group_count": len(rows),
    "observed_test_executions": len(all_ids),
    "distinct_test_ids": len(set(all_ids)),
    "repeated_test_executions": len(all_ids) - len(set(all_ids)),
    "failed_tests": 0,
    "skipped_tests": 0,
    "groups": rows,
    "artifacts": artifacts,
    "scope": "Existing research-memory Python and Torch/OCR contract tests; no native Rust/ordinary-owner/scientific adoption claim.",
}
(ROOT / "RAW_LOG_BINDING_AUDIT.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key:value for key,value in result.items() if key not in {"groups","artifacts"}}, indent=2))
print(json.dumps([{key:value for key,value in row.items() if key not in {"actual_case_ids","source_before_after"}} for row in rows], indent=2))
