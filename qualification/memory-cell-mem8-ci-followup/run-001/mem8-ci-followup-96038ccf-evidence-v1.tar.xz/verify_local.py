import argparse
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time

EVIDENCE = Path(__file__).resolve().parent
WORK = EVIDENCE.parent / "mem-ci-followup-work"
CAPSULE = json.loads((EVIDENCE / "PATCH_CAPSULE.json").read_text())
MEMORY = json.loads((EVIDENCE / "EPISODIC_MEMORY_5858.json").read_text())


def identity(data):
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob_sha": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    }


def record_command(name, command, cwd, expected):
    started = time.time()
    result = subprocess.run(command, cwd=cwd, env={
        **os.environ,
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(WORK / "candidate" / "scripts"),
    }, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    records = EVIDENCE / "local-verification"
    records.mkdir(exist_ok=True)
    out = records / (name + ".stdout.log")
    err = records / (name + ".stderr.log")
    out.write_bytes(result.stdout)
    err.write_bytes(result.stderr)
    receipt = {
        "command": command,
        "cwd": str(cwd),
        "returncode": result.returncode,
        "expected_returncode": expected,
        "duration_seconds": time.time() - started,
        "stdout": {"path": str(out.relative_to(EVIDENCE)), **identity(result.stdout)},
        "stderr": {"path": str(err.relative_to(EVIDENCE)), **identity(result.stderr)},
    }
    (records / (name + ".json")).write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"command": name, "returncode": result.returncode}))
    if result.returncode != expected:
        raise RuntimeError(f"{name}: expected {expected}, received {result.returncode}; see retained logs")
    return receipt


WORK.mkdir(exist_ok=True)
changes = []
for item in CAPSULE["files"]:
    for stage, field in [("baseline", "preimage"), ("candidate", "postimage")]:
        path = WORK / stage / item["path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(item[field].encode())
    before, after = item["preimage"].encode(), item["postimage"].encode()
    changes.append({
        "path": item["path"],
        "source_pr": item["source_pr"],
        "before": identity(before),
        "after": identity(after),
        "reviewed_postimage_git_sha": item.get("reviewed_postimage_git_sha"),
        "entire_file_matches_reviewed_postimage": identity(after)["git_blob_sha"] == item.get("reviewed_postimage_git_sha") if item.get("reviewed_postimage_git_sha") else None,
        "preimage_hunk_match_counts": [h["match_count"] for h in item.get("hunks", [])],
    })
for stage in ["baseline", "candidate"]:
    path = WORK / stage / MEMORY["path"]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(MEMORY["content"].encode())
    (WORK / stage / "scripts/pyproject.toml").write_bytes((EVIDENCE / "PYPROJECT_5858.toml").read_bytes())
patch = "".join(
    "".join(difflib.unified_diff(
        item["preimage"].splitlines(keepends=True),
        item["postimage"].splitlines(keepends=True),
        fromfile="a/" + item["path"], tofile="b/" + item["path"],
    ))
    for item in CAPSULE["files"]
)
(EVIDENCE / "minimal-ci-followup.patch").write_text(patch)
target = "scripts/ndu_real_runtime/test_episodic_memory.py"
before = (WORK / "baseline" / target).read_bytes()
expected = (WORK / "candidate" / target).read_bytes()
assert ast.dump(ast.parse(before, type_comments=True), include_attributes=False) == ast.dump(ast.parse(expected, type_comments=True), include_attributes=False)
records = []
records.append(record_command("ruff-version", ["uv", "tool", "run", "--from", "ruff==0.15.13", "ruff", "--version"], WORK, 0))
version = (EVIDENCE / records[-1]["stdout"]["path"]).read_text().strip()
assert version == "ruff 0.15.13", version
records.append(record_command("ruff-baseline-check", ["uv", "tool", "run", "--from", "ruff==0.15.13", "ruff", "format", "--check", target], WORK / "baseline", 1))
records.append(record_command("memory-candidate-tests", [sys.executable, "-B", "-m", "unittest", "-v", "ndu_real_runtime.test_episodic_memory"], WORK / "candidate", 0))
test_log = (EVIDENCE / records[-1]["stdout"]["path"]).read_bytes() + (EVIDENCE / records[-1]["stderr"]["path"]).read_bytes()
assert len(re.findall(rb"Ran (\d+) tests? in ", test_log)) == 1
test_count = int(re.search(rb"Ran (\d+) tests? in ", test_log).group(1))
assert test_count == 15
assert re.search(rb"(?m)^OK\r?$", test_log)
assert not re.search(rb"(?i)skipped|expected failure|unexpected success", test_log)
formatter_path = WORK / "formatter-output" / target
formatter_path.parent.mkdir(parents=True, exist_ok=True)
formatter_path.write_bytes(before)
(formatter_path.parents[1] / "pyproject.toml").write_bytes((EVIDENCE / "PYPROJECT_5858.toml").read_bytes())
records.append(record_command("ruff-actual-format", ["uv", "tool", "run", "--from", "ruff==0.15.13", "ruff", "format", target], WORK / "formatter-output", 0))
actual = formatter_path.read_bytes()
assert actual == expected, "actual pinned Ruff output differs from planned one-line repair"
records.append(record_command("ruff-candidate-check", ["uv", "tool", "run", "--from", "ruff==0.15.13", "ruff", "format", "--check", target], WORK / "candidate", 0))
assert ast.dump(ast.parse(before, type_comments=True), include_attributes=False) == ast.dump(ast.parse(actual, type_comments=True), include_attributes=False)
assert (WORK / "candidate" / target).read_bytes() == expected
summary = {
    "schema": "hepta.mem7.ci-followup-local-verification.v1",
    "platform": platform.platform(),
    "python": sys.version,
    "source_projection": "exact retrieved blobs; not a full Git checkout or whole-repository qualification",
    "baseline": CAPSULE["baseline_commit"],
    "python_source": MEMORY["commit"],
    "memory_runtime": identity(MEMORY["content"].encode()),
    "original_memory_test": identity(before),
    "formatted_memory_test": identity(actual),
    "ast_including_type_comments_unchanged": True,
    "formatter": version,
    "test_executions": test_count,
    "test_failures": 0,
    "test_skips": 0,
    "candidate_bytes_unchanged_by_check": True,
    "rust_native_tests": "NOT_RUN",
    "repo_just_fmt": "NOT_RUN",
    "changes": changes,
    "commands": records,
}
(EVIDENCE / "LOCAL_VERIFICATION.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
