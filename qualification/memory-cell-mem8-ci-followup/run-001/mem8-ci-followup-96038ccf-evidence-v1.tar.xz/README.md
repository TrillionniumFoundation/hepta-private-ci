# MEM8 common-source CI follow-up

## Published source

Draft [#5873](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5873) publishes exactly six source files on parent `adef61556284cc5b58c4f23a33d7c8455e821c3f`:

- Commit: `96038ccf0660154fac143ba6cbe4be81e00813e8`
- Tree: `1277666f3285cdf006d36478e6f74ddec38e1fe0`
- Branch: `codex/mem8-common-source-20261111-ed353817`
- Base branch: `codex/mem7-evidence-20261110-ed353817`

`PUBLICATION.json` retains the authenticated GitHub readback and the six exact final blob identities. Original source branches, old qualification records and actor campaigns are unchanged.

## Narrow repairs

The safe snapshot reader and regression come from [#5851](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5851). The exact test preimage is [#5858](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5858), which still failed pinned formatting because two class methods remained separated by an extra blank line. Ruff 0.15.13 removes that line. The full AST including type comments remains equal.

The two Agentd canonical temporary-root fixture changes are the exact reviewed postimages from [#5618](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5618). The LF attribute and TUI expected-path canonicalization are the exact reviewed postimages from [#5863](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5863). Every imported hunk's preimage occurs once; each complete resulting file has the upstream Git blob SHA. No assertion, production guard, dependency or CI gate changes.

## Executed local verification

`LOCAL_VERIFICATION.json` and `local-verification/` retain all commands and full stdout/stderr:

- Python 3.12.14 exact-blob projection: **15 existing memory tests passed, 0 failed, 0 skipped**.
- Exact #5858 test: Ruff 0.15.13 check **failed, exit 1**, reproducing the current hosted failure.
- Actual pinned formatting produced the proposed file; candidate check **passed, exit 0**.
- AST including type comments remained unchanged.
- `git apply --check` succeeded for `minimal-ci-followup.patch`.

This is an exact-blob source projection, not a full Git checkout or whole-repository pass. Native Rust tests and canonical `just fmt` are still pending at this checkpoint.

To reproduce the local check, unpack into a fresh directory, decompress `CHECK_SNAPSHOT.json.xz` if the full check payload is needed, and run `python3 verify_local.py`. The script uses the pinned Ruff version and retained source bytes. It writes new verification output; do not run it over an immutable evidence copy.

## Retained original CI failures

The complete decoded UTF-8 job logs are losslessly compressed under `raw-logs/`. `RAW_LOG_INDEX.json` binds each compressed file to its full decompressed byte length and SHA-256, workflow identity and original failure sections. These are GitHub's decoded job logs, not ZIP transport archives.

| Original job | Actual observed result |
| --- | --- |
| #5818 Blob-size 129998835585 | Fence `unsupported_resolver_layout` before checkout; blob-size tests never ran |
| #5818 macOS Intel 130043385302 | 25 unique test names in failure sections: Agentd fixtures, code-mode listeners, app-server executor skills, Matrix store initialization |
| #5818 Windows shard 1 130043385354 | 2 unique failed test names, including sandbox process refusal and guardian cache |
| #5818 Windows shard 2 130043385257 | 18 unique failed test names across sandbox, app-server and CLI |
| #5818 Windows shard 3 130043385347 | 27 unique failed test names, including seven Agentd fixtures, byte/path identity and other owner/runtime cases |
| #5818 Windows shard 4 130043385453 | 20 unique failed test names across sandboxed filesystem and workspace operations |
| #5818 repository check 130043384538 | Cancelled; no pass inferred |
| #5858 repository check 130157485791 | Remaining Ruff formatting failure reproduced locally |

These numbers deduplicate names within a job's reported failure sections, which can repeat across Bazel retries. They are **not test execution totals**. Full logs preserve the original execution counts and retries. The #5818 Bazel/repository jobs used merge `b44f2819058ef14d5465d72aff0c008d5f005d95`; #5858 repository checks used merge `78a99fd5ac9da8f606147d3bbd55230518f11970`. Source-head and merge execution are not conflated.

The cargo-deny full-log retrievals returned transport errors, retained in `CARGO_LOG_RETRIEVAL_FAILURES.json`. Its independently readable step metadata confirms checkout, toolchain and no-suppression policy success, actual `Run cargo-deny` failure, and a clean final worktree. This checkpoint does not claim a newly verified advisory list or a dependency repair.

## Limits

Original #5813, #5814, #5818, #5851 and #5858 check snapshots remain distinct. All their required CI aggregates were failed at the captured read. A narrow memory test pass does not close inherited Windows sandbox, macOS listener/recovery, dependency or whole-CI gates. Scientific adoption, original-owner cold recovery and production capability are outside this repair claim.
