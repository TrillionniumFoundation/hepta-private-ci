from pathlib import Path
import hashlib
import json
import lzma
import re
import zipfile

ROOT = Path(__file__).resolve().parent
HEAD = 'cb0b276ffdb9852323cdd13ba9b4399b30ae0c37'
TREE = '61f266ce7f02e0c3b94c22871ebedcc72f28e456'
BASE = '4eb497e889b053dd40af87469e594d08585f93e8'
CASE = 'circuit_cell::tests::credit_tests::signed_tests::signed_credit_rejects_cross_owner_ledger_episode_before_any_append'
archive = (ROOT / 'hosted-native-13825285327.zip').read_bytes()
assert len(archive) == 5317
assert hashlib.sha256(archive).hexdigest() == '54318211a67530b6cbdcb73e28a9b23b9a546370926112c92addddaaa095eaa1'
with zipfile.ZipFile(ROOT / 'hosted-native-13825285327.zip') as z:
    assert z.testzip() is None
    assert sorted(z.namelist()) == ['credit-fixture.json', 'credit-fixture.log']
    receipt = json.loads(z.read('credit-fixture.json'))
    raw = z.read('credit-fixture.log')
expected = {'commit': HEAD, 'tree': TREE, 'parents': [BASE], 'dirty': False}
assert receipt['before'] == receipt['after'] == expected
assert receipt['source_sha'] == receipt['tested_sha'] == HEAD
assert receipt['status'] == 'passed' and receipt['command_exit_code'] == receipt['exit_code'] == 0
assert receipt['case'] == CASE
assert receipt['run_id'] == '42947836619' and receipt['run_attempt'] == '1'
assert receipt['command'] == ['just', 'test', '--locked', '-p', 'codex-hepta-agentd', '--lib', '-E', 'test(=' + CASE + ')', '--test-threads', '1', '--no-tests', 'fail', '--retries', '0']
assert receipt['minimum_tests'] == receipt['named_pass_rows'] == receipt['observed_passed_tests'] == 1
assert receipt['observed_failed_tests'] == 0
assert len(raw) == receipt['log_bytes'] == 30039
assert hashlib.sha256(raw).hexdigest() == receipt['log_sha256'] == 'ec565bd335a10979ffcb0be04a389a09ddb48035221fd25b4f990750f185a003'
text = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode())
passes = re.findall(r'^\s*PASS\s+\[[^\]]+\]\s+codex-hepta-agentd\s+(\S+)\s*$', text, re.MULTILINE)
summaries = re.findall(r'^\s*Summary[^\n]+$', text, re.MULTILINE)
assert passes == [CASE]
assert len(summaries) == 1 and re.search(r'1 test run: 1 passed, 269 skipped\s*$', summaries[0])
assert re.findall(r'Nextest run ID ([0-9a-f-]+)', text) == ['b3e2fe3d-1bb1-4584-8580-dce96cb1cab7']
assert not re.search(r'^\s*(FAIL|FLAKY|RETRY)\s', text, re.MULTILINE)
joblog = lzma.decompress((ROOT / 'hosted-native-130284818815.log.xz').read_bytes())
assert len(joblog) == 287793
assert hashlib.sha256(joblog).hexdigest() == 'bf16269435b2c3e8032801a83503f9ac884bc8529d762e5622579b2776cad768'
jobs = json.loads((ROOT / 'HOSTED_JOB.json').read_text())['jobs']
assert len(jobs) == 1 and jobs[0]['id'] == 130284818815
assert jobs[0]['run_id'] == 42947836619 and jobs[0]['status'] == 'completed' and jobs[0]['conclusion'] == 'success'
assert all(step['conclusion'] == 'success' for step in jobs[0]['steps'])
artifacts = json.loads((ROOT / 'HOSTED_ARTIFACTS.json').read_text())['artifacts']
artifact = next(x for x in artifacts if x['id'] == 13825285327)
assert artifact['workflow_run']['head_sha'] == HEAD
assert artifact['digest'] == 'sha256:' + hashlib.sha256(archive).hexdigest()
result = {'source': expected, 'run_id': 42947836619, 'job_id': 130284818815, 'run_attempt': 1, 'nextest_run_id': 'b3e2fe3d-1bb1-4584-8580-dce96cb1cab7', 'selected_unique_case_ids': [('codex-hepta-agentd', CASE)], 'actual_executions': 1, 'passed': 1, 'failed': 0, 'selected_skipped': 0, 'filtered_or_unselected': 269, 'retries': 0, 'exact_command_log_sha256': hashlib.sha256(raw).hexdigest(), 'whole_repository_ci_claimed': False, 'prior_4eb_os33_failure_superseded_or_deleted': False, 'evidence_check': 'PASS'}
print(json.dumps(result, indent=2))
