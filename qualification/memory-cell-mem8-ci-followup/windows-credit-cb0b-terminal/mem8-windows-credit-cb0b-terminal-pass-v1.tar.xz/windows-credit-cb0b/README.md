# MEM8 Windows original signed-credit qualification

The original signed-credit case now passes once on the exact published source, with its original physical byte assertions unchanged. This is target-level Windows evidence, not a whole-repository CI pass or a memory-benefit claim.

Source: `cb0b276ffdb9852323cdd13ba9b4399b30ae0c37`; tree: `61f266ce7f02e0c3b94c22871ebedcc72f28e456`; parent: `4eb497e889b053dd40af87469e594d08585f93e8`. Source is clean before and after the actual command. The signed-test source remains blob `4c59f0a411c6a08ab33589cff9a3544684fc62eb`; #5902 changes the fixture observation path and qualification-only original-handle reader, while preserving exclusive locks and the byte comparisons.

- [Source PR #5902](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/5902)
- [Exact source](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/cb0b276ffdb9852323cdd13ba9b4399b30ae0c37)
- [Windows workflow run 42947836619](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42947836619)
- [Actual job 130284818815](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42947836619/job/130284818815)

The exact original case executed once: 1 passed, 0 failed, 0 selected skips, 269 filtered or unselected tests, and zero retries. Nextest run ID: `b3e2fe3d-1bb1-4584-8580-dce96cb1cab7`. The entire Windows private-state job also completed successfully; its earlier ACL, signed-owner, Prompt Runtime, formatting, and original acquisition-attack gates remain present.

`hosted-native-13825285327.zip` is the unmodified GitHub artifact. It contains the original execution receipt and command log. `hosted-native-130284818815.log.xz` losslessly preserves the complete original job log. `verify_evidence.py` checks the complete ZIP digest/CRC, exact source/tree/parents and clean states, command, original case identity, nextest run ID, raw PASS row, single terminal summary, retry absence, and full job-log digest. It does not derive the count solely from receipt counters.

The earlier 4eb attempt executed this same case once and failed with Windows OS 33. That evidence remains at `qualification/memory-cell-mem8-ci-followup/windows-credit-4eb497e-terminal/` in the separate evidence PR. Its receipt and raw bytes were not changed or removed. The new result closes that concrete failure on cb0b; it does not reinterpret the earlier failure as a pass.

Run `python verify_evidence.py` from this directory to reproduce the local integrity and count audit. No source code, test expectation, retry policy, or CI gate is changed by this evidence package. No provider call or model/owner capability qualification is included.
