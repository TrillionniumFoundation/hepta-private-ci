# MEM integration: original Bazel lock v2 evidence

The one original source-only command passed with no lock drift. Its exact locally executed commit was 65ff5d15075f9193664ab0b5f74e2264cfe0c24c, tree e253b99e0a5c3b3a680569da0d224fabff0781ba. The subsequent published commit 189711e3563ea13a5328d52e99a286f082045b98 has that same tree, but was not itself executed by this task. Original v1 preparation failure remains in its separate immutable archive.

Run python3 verify_archive.py /path/to/archive.tar.xz to check all member hashes, the complete original 4987-byte raw command log, strict receipt identities and return status, no dirty source, identical tool and donor observations, ten bounded preparation phases, and the lossless read-only export. The full 69-path formatted source capsule is retained in the separately published source-gate archive; its size/hash/tree/lock-entry binding is included here.

No Rust tests, model requests or source-ref updates were performed by the lock driver. The detached driver produced a complete successful RESULT and its command wrapper recorded exit 0; a distinct numeric detached-driver OS exit receipt was not produced. The original direct-H read-only batch may remain transport-pending; the independently completed fixed SSH read-only export provides the archived original records and did not replay the lock command.
