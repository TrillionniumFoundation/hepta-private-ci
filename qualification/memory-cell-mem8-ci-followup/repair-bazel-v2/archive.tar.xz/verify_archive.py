import hashlib,json,sys,tarfile,zlib,base64
from pathlib import Path
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
def sh(b): return hashlib.sha256(b).hexdigest()
def gb(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
if p.is_file():
 t=tarfile.open(p,'r:*'); ms=t.getmembers()
 assert all(m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts for m in ms)
 assert len(ms)==len({m.name for m in ms})
 data={m.name:t.extractfile(m).read() for m in ms}
else: data={x.relative_to(p).as_posix():x.read_bytes() for x in p.rglob('*') if x.is_file()}
manifest=json.loads(data['MANIFEST.json'])
assert set(data)=={'MANIFEST.json'}|{r['path'] for r in manifest['files']}
for row in manifest['files']:
 b=data[row['path']];assert len(b)==row['bytes'] and sh(b)==row['sha256'] and gb(b)==row['git_blob']
def j(n): return json.loads(data[n])
r=j('records/lock-generate.json'); s=j('QUALIFICATION_RESULT.json'); phase=j('records/lock-generate-phase.json')
raw=data['records/'+r['log_file']]
assert len(raw)==r['log_bytes']==4987 and sh(raw)==r['log_sha256']=='b9611548ac59c858b88b7bfee1819c2c2b7f2dc7b9e4fa4ca9e50caac34bd13c'
assert r['status']=='passed' and r['command']==['/home/qian-qi/.cargo/bin/just','bazel-lock-update']
assert all(r[k]==0 for k in ['command_exit_code','exit_code','returncode','minimum_tests','observed_failed_tests','observed_passed_tests'])
assert r['timed_out'] is False and r['output_limit_exceeded'] is False
assert r['before']==r['after']==s['source_before']==s['source_after']
assert r['before']=={'commit':'65ff5d15075f9193664ab0b5f74e2264cfe0c24c','tree':'e253b99e0a5c3b3a680569da0d224fabff0781ba','parents':['2ae5215beaf8d7b7df111a090b82134beae2683d'],'dirty':False}
assert r['source_sha']==r['tested_sha']==r['before']['commit']
assert phase['receipt']==r and phase['wrapper_exit_code']==0
assert data['records/lock-generate.patch']==data['records/lock-generate.wrapper.stderr']==b''
assert j('records/TOOLS_BEFORE.json')==j('records/TOOLS_AFTER.json')
assert j('records/DONOR_BEFORE.json')==j('records/DONOR_AFTER.json')
assert j('records/BASE_CHECKOUT_IDENTITY.json')=={'commit':r['base_sha'],'tree':'12159640adcf073b51f3837e75575e11f5c20233','status':''}
assert j('records/BASE_INDEX_TREE.json')=={'expected':'12159640adcf073b51f3837e75575e11f5c20233','actual':'12159640adcf073b51f3837e75575e11f5c20233'}
result=j('records/RESULT.json'); assert result['status']=='passed_local_candidate_lock_gate'
assert result['post_lock']==phase['post_lock']==s['lock']=={'bytes':1788299,'sha256':'783b3ad329fa53bd4a0e48be6907d38259fa2880d61bd1994b863d7f78bbca57','git_blob':'1565448430312c7fb7537a48f97e9cd2da945df3'}
assert result['first_generation_had_lock_drift'] is False and result['phase_receipts']==['lock-generate.json']
assert result['native_tests_executed']==result['model_requests']==0 and result['published_reference_updated'] is False
driver=data['original-driver/driver.stdout']
assert len(driver)==10787 and sh(driver)=='673edb0ea324a63dfa728a4c962f18c1932a43a82fc977f26d1c7eb01f2c7411'
phases=[json.loads(x.split(' ',1)[1]) for x in driver.decode().splitlines() if x.startswith('MEM8_BAZEL_PHASE ')]
assert len(phases)==10 and all(x['exit_code']==0 and not x['timed_out'] and not x['cleanup']['required'] and x['cleanup']['group_absent_after'] for x in phases)
assert json.loads(driver.decode().split('MEM8_BAZEL_RESULT ',1)[1])==result
outer=j('readback/ORIGINAL_SSH_EXPORT.stdout'); packed=base64.b64decode(outer['zlib_base64'],validate=True)
assert len(packed)==outer['compressed_bytes'] and sh(packed)==outer['compressed_sha256']
body=zlib.decompress(packed);assert len(body)==outer['body_bytes'] and sh(body)==outer['body_sha256']
export=json.loads(body);assert len(export['records'])==20 and export['mutation'] is False
for row in export['records']:
 b=base64.b64decode(row['content_base64'],validate=True)
 assert b==data['records/'+row['name']] and len(b)==row['bytes'] and sh(b)==row['sha256'] and gb(b)==row['git_blob']
native=data['readback/ORIGINAL_SSH_EXPORT_SDK.json']
assert len(native)==35113 and sh(native)=='57ba30d82c957b0449f154b90aa95b4461e8136a8b3417c1b4466ad4f3549b94'
read=json.loads(json.loads(native)['content'][0]['text'])
for name in ['stdout','stderr']:
 x=read[name];b=bytes.fromhex(x['bytes_hex'])
 assert b==x['text'].encode()==data['readback/ORIGINAL_SSH_EXPORT.'+name] and x['eof'] and len(b)==x['size']==x['next_offset']
bind=j('SOURCE_CAPSULE_BINDING.json')
assert bind['candidate_tree']==r['before']['tree'] and bind['overlay_paths']==69
assert bind['capsule_sha256']=='6081a45344f3fa7687b71901033b813499d5dc3913c052e63a6700a9c96b6a37'
assert bind['candidate_tree_lock_entry']=='100644 blob 1565448430312c7fb7537a48f97e9cd2da945df3\tMODULE.bazel.lock'
assert s['published_commit_itself_executed_here'] is False and s['native_tests_executed']==s['model_requests']==0
print(json.dumps({'status':'passed','members':len(data),'raw_bytes':len(raw),'executed_commit':r['before']['commit'],'tree':r['before']['tree'],'lock_unchanged':True,'phase_count':1,'native_tests_executed':0,'model_requests':0},sort_keys=True))
