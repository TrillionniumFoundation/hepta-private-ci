"""Prepared transport for one frozen desktop Bazel lock qualification.

Do not run until the parent has reviewed the actual formatted capsule and given
its SHA256 and complete candidate tree. This uses only the established ai395 to
desktop SSH alias, and starts at most one original driver process.
"""

import hashlib
import json
import os
from pathlib import Path
import pwd
import shlex
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone


OUT = Path('/home/qq/mem8-integrated-bazel-lock-transfer-ed353817-v2')
DEST = '/home/qian-qi/mem8-integrated-bazel-lock-inputs-ed353817-v2'
CAPSULE = Path('/home/qq/mem8-integrated-repair-source-ed353817-v2/records/FORMATTED_CAPSULE.json')
SSH = ['/usr/bin/ssh', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'ConnectTimeout=10', 'desktop']
BASE = '2ae5215beaf8d7b7df111a090b82134beae2683d'
BASE_TREE = '12159640adcf073b51f3837e75575e11f5c20233'
DRIVER_SHA256 = '83e05f1a65c5d434f22dff4760dbcfd77590de3281cb5ef329969f0dc9ad3edb'


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, data):
    with (OUT / name).open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def save(name, value):
    write(name, (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


def group_exists(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False


def invoke(label, argv, budget):
    started = now()
    with (OUT / (label + '.stdout')).open('xb') as stdout, (OUT / (label + '.stderr')).open('xb') as stderr:
        process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=stdout,
                                   stderr=stderr, start_new_session=True)
        timed_out = False
        try:
            process.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            timed_out = True
        cleanup = {'owned_pgid': process.pid, 'required': timed_out or group_exists(process.pid), 'signals': []}
        if cleanup['required']:
            for sig in (signal.SIGTERM, signal.SIGKILL):
                if not group_exists(process.pid):
                    break
                try:
                    os.killpg(process.pid, sig)
                    cleanup['signals'].append(sig.name)
                except ProcessLookupError:
                    break
                deadline = time.monotonic() + 5
                while group_exists(process.pid) and time.monotonic() < deadline:
                    process.poll()
                    time.sleep(0.1)
        cleanup['group_absent_after'] = not group_exists(process.pid)
        try:
            process.wait(timeout=1)
            cleanup['parent_reaped'] = True
        except subprocess.TimeoutExpired:
            cleanup['parent_reaped'] = False
    result = {'label': label, 'started_at': started, 'finished_at': now(),
              'timeout_seconds': budget, 'timed_out': timed_out, 'exit_code': process.returncode,
              'cleanup': cleanup}
    for channel in ('stdout', 'stderr'):
        data = (OUT / (label + '.' + channel)).read_bytes()
        result[channel] = {'bytes': len(data), 'sha256': sha(data)}
    save(label + '.json', result)
    print('MEM8_LOCK_TRANSPORT_PHASE ' + json.dumps(result), flush=True)
    if process.returncode or timed_out or cleanup['required']:
        raise RuntimeError(label + ' did not complete cleanly; preserve original identity and reconcile only')
    return (OUT / (label + '.stdout')).read_bytes()


REMOTE = r'''
import hashlib,json,os,pwd,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone

root=Path('/home/qian-qi/mem8-integrated-bazel-lock-inputs-ed353817-v2')
task=Path('/home/qian-qi/mem8-integrated-bazel-lock-ed353817-v2')
expected=json.loads(sys.argv[1])
def sha(data):return hashlib.sha256(data).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def write(name,data):
    with (root/name).open('xb') as stream:
        stream.write(data);stream.flush();os.fsync(stream.fileno())
def save(name,value):write(name,(json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
if pwd.getpwuid(os.getuid()).pw_name!='qian-qi':raise RuntimeError('unexpected desktop account')
if task.exists():raise RuntimeError('qualification task already exists; only reconcile its original identity')
capsule_bytes=(root/'FORMATTED_CAPSULE.json').read_bytes()
driver_bytes=(root/'driver.py').read_bytes()
if sha(capsule_bytes)!=expected['capsule_sha256'] or len(capsule_bytes)!=expected['capsule_bytes']:
    raise RuntimeError('formatted capsule transfer mismatch')
if sha(driver_bytes)!=expected['driver_sha256'] or len(driver_bytes)!=expected['driver_bytes']:
    raise RuntimeError('reviewed driver transfer mismatch')
capsule=json.loads(capsule_bytes)
if (capsule['base_commit'],capsule['base_tree'],capsule['candidate_tree'])!=(expected['base_commit'],expected['base_tree'],expected['candidate_tree']):
    raise RuntimeError('source identity differs from reviewed formatted capsule')
if len(capsule['files'])!=69 or len({r['path'] for r in capsule['files']})!=69:
    raise RuntimeError('formatted source inventory is not the reviewed 69 paths')
config=dict(capsule)
config.update({
  'execution_host':'desktop','transport':'existing ai395 SSH alias desktop, BatchMode=yes, StrictHostKeyChecking=yes, ConnectTimeout=10',
  'phase_timeout_seconds':1200,
  'donor':'/home/qian-qi/mem8-matrix-diagnostic-ed353817-v1/source',
  'bazel_executable':'/home/qian-qi/.cache/bazelisk/downloads/sha256/d302d22ed77ee5658b87857249baa579db84300ecebe0a1e9a357b5b20f80eb8/bin/bazel',
  'bazel_sha256':'d302d22ed77ee5658b87857249baa579db84300ecebe0a1e9a357b5b20f80eb8',
  'just_executable':'/home/qian-qi/.cargo/bin/just',
  'just_sha256':'b73359690704c2aaa0cdfb5b262e6fbf819a8be8cdea2d87565dd441dc7b3f8d',
  'source_gate_capsule_sha256':sha(capsule_bytes),'source_gate_capsule_bytes':len(capsule_bytes),
  'reviewed_driver_sha256':sha(driver_bytes)})
input_bytes=(json.dumps(config,indent=2,sort_keys=True)+'\n').encode()
write('INPUT.json',input_bytes)
save('TRANSFER_VERIFIED.json',dict(expected,observed_at=now(),execution_host='desktop',input_sha256=sha(input_bytes),input_bytes=len(input_bytes)))
argv=[sys.executable,'-B',str(root/'driver.py'),str(root/'INPUT.json'),sha(input_bytes)]
save('DISPATCH_INTENT.json',{'at':now(),'command':argv,'task':str(task),'execution_host':'desktop','state':'dispatch-intent; not terminal evidence'})
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0')
for key in list(env):
    if key.startswith(('GIT_TRACE','HEPTA_LOCAL_PROVIDER_','HEPTA_MEM_CONTEXT_','HEPTA_MEM_NATIVE_')) or key in {'GIT_CURL_VERBOSE','CARGO_BIN_EXE_codex','HEPTA_EPISODIC_DRAIN_REGRESSION_CASE'}:
        env.pop(key)
with (root/'driver.stdout').open('xb') as stdout,(root/'driver.stderr').open('xb') as stderr:
    child=subprocess.Popen(argv,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
receipt={'started_at':now(),'execution_host':'desktop','pid':child.pid,'pgid':child.pid,
         'input_sha256':sha(input_bytes),'candidate_tree':capsule['candidate_tree'],
         'task':str(task),'inputs':str(root),'terminal_result_path':str(task/'records/RESULT.json'),
         'state':'launched; original terminal_result_path required for terminal conclusion',
         'phase_timeout_seconds':1200,'maximum_lock_phase_count':2,'native_tests_executed':0,'model_requests_executed':0}
save('LAUNCH_RECEIPT.json',receipt)
print(json.dumps(receipt),flush=True)
'''


def main():
    if len(sys.argv) != 4:
        raise SystemExit('usage: launch_via_ai395_ssh.py FORMATTED_CAPSULE_SHA256 CANDIDATE_TREE DRIVER_PATH')
    if pwd.getpwuid(os.getuid()).pw_name != 'qq' or not Path('/home/qq').is_dir():
        raise RuntimeError('launcher must run on the existing ai395 account')
    capsule_bytes = CAPSULE.read_bytes()
    driver = Path(sys.argv[3]).resolve()
    if driver.name != 'driver.py':
        raise RuntimeError('driver basename must be driver.py; nothing transferred or launched')
    driver_bytes = driver.read_bytes()
    if sha(capsule_bytes) != sys.argv[1] or sha(driver_bytes) != DRIVER_SHA256:
        raise RuntimeError('input digest differs from parent-reviewed bytes')
    capsule = json.loads(capsule_bytes)
    if (capsule['base_commit'], capsule['base_tree'], capsule['candidate_tree']) != (BASE, BASE_TREE, sys.argv[2]):
        raise RuntimeError('formatted source identity differs from parent review')
    if len(capsule['files']) != 69 or len({row['path'] for row in capsule['files']}) != 69:
        raise RuntimeError('unexpected reviewed path inventory')
    OUT.mkdir(mode=0o700)
    expected = {'base_commit': BASE, 'base_tree': BASE_TREE, 'candidate_tree': sys.argv[2],
                'capsule_sha256': sha(capsule_bytes), 'capsule_bytes': len(capsule_bytes),
                'driver_sha256': sha(driver_bytes), 'driver_bytes': len(driver_bytes)}
    save('START.json', {'at': now(), 'scope': 'transfer two reviewed files, then one desktop lock driver dispatch',
                       'execution_host': 'desktop', 'outer_host': 'ai395', 'destination': DEST,
                       'source_capsule_path': str(CAPSULE), 'expected': expected,
                       'unknown_dispatch_policy': 'read original LAUNCH_RECEIPT/RESULT only; never replay'})
    create = 'from pathlib import Path;Path(' + repr(DEST) + ').mkdir(mode=0o700)'
    invoke('create-exclusive-inputs', SSH + ['python3', '-c', shlex.quote(create)], 30)
    invoke('copy-reviewed-inputs', ['/usr/bin/scp', '-p', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
           '-o', 'ConnectTimeout=10', str(CAPSULE), str(driver), 'desktop:' + DEST + '/'], 90)
    result = invoke('verify-and-dispatch-once', SSH + ['python3', '-c', shlex.quote(REMOTE),
                    shlex.quote(json.dumps(expected, separators=(',', ':')))], 45)
    receipt = json.loads(result)
    if receipt['candidate_tree'] != sys.argv[2] or receipt['execution_host'] != 'desktop':
        raise RuntimeError('dispatch receipt identity mismatch; only reconcile original task')
    save('DESKTOP_LAUNCH_RECEIPT.json', receipt)
    print('MEM8_DESKTOP_LOCK_LAUNCH ' + json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
