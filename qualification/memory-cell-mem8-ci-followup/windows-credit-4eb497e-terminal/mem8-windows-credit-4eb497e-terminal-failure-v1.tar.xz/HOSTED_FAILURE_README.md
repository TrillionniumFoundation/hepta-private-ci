# Windows signed-credit original case: terminal failure retained

Exact source 4eb497e889b053dd40af87469e594d08585f93e8, tree 5bac6ffbef18f9f22317951a059835fe218c4383, parent1530ca1c29991185efe686721a5c97f8c40adc16. Run42941228468 / job130263259830 / attempt1. Before and after source identities are equal and clean.

The original signed-credit case actually executed once with retries0: 0 passed, 1 failed, and269 filtered/unselected cases. The raw log repeats the same FAIL display twice; the full case ID and the single terminal summary establish one execution. The failure is Os code33 during the original fixture file read. The prior directory sync PermissionDenied is absent, but this is not full-case qualification. All original precondition/private-owner/format/acquisition-attack steps succeeded.

The original artifact ZIP is preserved exactly with its receipt and full31189-byte native command log. The entire GitHub job log is separately retained losslessly using XZ. No assertions, locks or source are changed by this archive. A later original-handle-byte observation candidate is separate and unqualified by these records.
