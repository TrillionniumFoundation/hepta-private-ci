from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile

root = Path(__file__).parent
work = Path(tempfile.mkdtemp(prefix="receipt-controls-", dir=root))
repo = work / "source"
(repo / "scripts").mkdir(parents=True)
(repo / "codex-rs").mkdir()
(repo / "scripts/hepta_ci_exec.py").write_bytes((root / "hepta_ci_exec.py").read_bytes())
(repo / "source.txt").write_text("receipt controls only; not native Rust evidence\n")
subprocess.run(["git", "init", "-q", str(repo)], check=True)
subprocess.run(["git", "-C", str(repo), "add", "."], check=True)
subprocess.run([
    "git", "-C", str(repo), "-c", "user.name=Receipt control",
    "-c", "user.email=receipt-control@example.invalid", "commit", "-qm", "synthetic receipt control",
], check=True)
sha = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
bin_dir = work / "bin"
bin_dir.mkdir()
fake = bin_dir / "just"
fake.write_text("""#!/usr/bin/env python3
from pathlib import Path
import os
import sys
case = 'circuit_cell::tests::credit_tests::signed_tests::signed_credit_rejects_cross_owner_ledger_episode_before_any_append'
mode = os.environ['RECEIPT_CONTROL_MODE']
if mode == 'wrong_case':
    case = 'different_case'
if mode == 'dirty':
    Path('unexpected-control-output').write_text('dirty')
if mode in ('zero', 'selected_skip'):
    print('Summary [ 0.001s] 0 tests run: 0 passed, 1 skipped')
elif mode == 'failure':
    print(f'FAIL [ 0.001s] codex-hepta-agentd {case}')
    print('Summary [ 0.001s] 1 test run: 0 passed, 1 failed')
    sys.exit(100)
else:
    print(f'\\x1b[32mPASS\\x1b[0m [ 0.001s] codex-hepta-agentd {case}')
    print('Summary [ 0.001s] 1 test run: 1 passed, 269 skipped')
""")
fake.chmod(0o755)
results = []
for mode in ("pass", "wrong_case", "zero", "selected_skip", "failure", "dirty", "wrong_head"):
    temp = work / mode
    temp.mkdir()
    env = os.environ | {
        "PATH": str(bin_dir) + os.pathsep + os.environ["PATH"],
        "RUNNER_TEMP": str(temp), "SOURCE_SHA": "1" * 40 if mode == "wrong_head" else sha,
        "BASE_SHA": sha, "GITHUB_RUN_ID": "synthetic-control",
        "GITHUB_RUN_ATTEMPT": "1", "GITHUB_JOB": "receipt-control",
        "PYTHONDONTWRITEBYTECODE": "1", "RECEIPT_CONTROL_MODE": mode,
    }
    result = subprocess.run([sys.executable, str(root / "embedded_receipt.py")], cwd=repo / "codex-rs", env=env, capture_output=True)
    (temp / "wrapper.stdout").write_bytes(result.stdout)
    (temp / "wrapper.stderr").write_bytes(result.stderr)
    record = json.loads((temp / "mem8-windows-credit-fixture/credit-fixture.json").read_text())
    assert (result.returncode == 0) == (mode == "pass"), (mode, result.returncode)
    assert (record["status"] == "passed") == (mode == "pass"), mode
    if "log_file" in record:
        data = (temp / "mem8-windows-credit-fixture" / record["log_file"]).read_bytes()
        assert len(data) == record["log_bytes"]
        assert hashlib.sha256(data).hexdigest() == record["log_sha256"]
    if mode == "wrong_head":
        assert record["command_exit_code"] is None
    if mode == "dirty":
        assert record["before"]["dirty"] is False and record["after"]["dirty"] is True
        (repo / "codex-rs/unexpected-control-output").unlink()
    results.append({"control": mode, "wrapper_exit": result.returncode, "receipt_status": record["status"], "expected": True})
report = {"scope": "Synthetic CI receipt acceptance controls on Linux; no Rust native execution", "controls": results, "all_expected": True, "control_directory": str(work)}
(root / "RECEIPT_CONTROL_RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
