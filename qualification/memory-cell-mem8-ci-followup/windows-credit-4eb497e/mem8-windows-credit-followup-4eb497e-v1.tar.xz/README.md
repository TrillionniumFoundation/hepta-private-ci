# Windows credit fixture source and qualification review

This package retains source repair 1530ca1c29991185efe686721a5c97f8c40adc16 (PR #5895) and its CI-only child 4eb497e889b053dd40af87469e594d08585f93e8 (PR #5898), plus original failed native logs. The new exact Windows case has no native result in this package; its workflow run 42941228468 / job 130263259830 was queued at the last observation.

source-repair contains the unchanged original/postimage fixture, same-tree reference, one-line patch and static checks. qualification-ci contains both complete workflow versions, the actual embedded receipt code and synthetic receipt controls. original-logs contains complete original decoded logs compressed with xz: common-source Windows shard 3 and both failed #5880 compilation jobs.

The synthetic controls are not Rust tests. Their original absolute paths and private local Git identity describe where the receipt-control harness ran; packaged copies map under qualification-ci/synthetic-controls/<control>/ and do not imply those local paths exist on the reader's host. Reproduce the receipt logic with python qualification-ci/verify_receipt_gate.py when git and Python are available. This uses a visibly synthetic runner and grants no native qualification.

MANIFEST.json lists every other member and its byte length/SHA-256. The source and workflow postimages were independently fetched back from their immutable GitHub commits and matched byte-for-byte. No current-source native formatter, Windows signed-credit pass, full-CI pass, production-owner or memory-benefit claim is made here.
