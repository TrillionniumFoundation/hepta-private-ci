# Windows signed-credit fixture follow-up

The one-line source change is draft PR #5895, commit `1530ca1c29991185efe686721a5c97f8c40adc16`, tree `6aa5220e0f23ac3676332a53583a6c462b4a06ba`, parent `96038ccf0660154fac143ba6cbe4be81e00813e8`.

The original Windows shard 3 job 130230390981 in run 42930925520 checked out merge `dd51a402a5a3b64e685f1bc42144dd4be330ecc5`. Its raw signed-credit failure is `fixture failed: Durable(Io(PermissionDenied))` through `circuit_cell_test_support.rs:17:23`. The complete original decoded log is retained, including all retries and terminal failures.

The source/error-type review points to `LedgerWriter::from_durable` calling `sync_directory_handle` on a read-only containing-directory handle. This is an inference from exact source and the error wrapper, not a recovered native backtrace. The same source tree's learning-ledger production test fixture already opens Windows directory handles with read and write access; its blob is `8250e8669700ddf6f67dcb2d7da803cb73773edf`. Microsoft's FlushFileBuffers contract requires write access: https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-flushfilebuffers .

The source patch adds only `options.write(true)` inside the existing Windows block. It leaves the existing reparse flags, real directory sync, exclusive locks and all original byte/binding assertions intact. No new configuration-mirroring test was added. Syntax parsing and indexed diff checking are local static evidence only; no native Rust test or formatter pass is claimed for this new source.

The later second-handle raw-byte reads may expose a separate Windows OS error 33 after this early failure is fixed. PR #5880 (`073b91e166c98340a505f747577a90ed080beb1b`) proposes nine test-only observation changes, but is not included: its own retained Windows and Linux scoped logs fail compilation with E0425 for missing LedgerSnapshot and LedgerWitnessFrontier. The Linux execution receipt observes zero tests. Those failures and the proposed observation changes must not be relabeled as a validated fix for this directory-handle problem.

The original learning-ledger package target is reported cached PASS on the Windows shard 2 merge log. That does not establish a new execution of its individual directory test. The existing Windows private-state workflow compiles Agentd but filters execution to prompt_runtime tests; its green status alone cannot qualify the signed-credit case. A separate CI child is being prepared to run the unchanged exact case and retain a source-bound receipt.

SOURCE_INDEX.json records original and proposed blob identities. The source postimage was fetched back from immutable GitHub commit 1530ca1c29991185efe686721a5c97f8c40adc16 and compared byte-for-byte with the local postimage. The GitHub compare result has one commit, one changed file, one insertion and zero deletions.

The initial local audit script incorrectly expected `git diff --no-index --check` to return zero when files differ; it stopped on exit 1 with empty stdout/stderr. A fresh isolated indexed projection then ran `git diff --check` with exit 0. Neither command is a native behavior test.
