from pathlib import Path
import importlib.metadata
import json
from tree_sitter import Language, Parser
import tree_sitter_rust

root = Path(__file__).parent
parser = Parser(Language(tree_sitter_rust.language()))
report = {
    "scope": "Rust syntax parse only; not rustfmt, rustc or native behavior",
    "tree_sitter": importlib.metadata.version("tree-sitter"),
    "tree_sitter_rust": importlib.metadata.version("tree-sitter-rust"),
    "files": [],
}
for name in ("before.rs", "after.rs"):
    data = (root / name).read_bytes()
    tree = parser.parse(data)
    report["files"].append({"file": name, "parse_has_error": tree.root_node.has_error})
    assert not tree.root_node.has_error, name
before = (root / "before.rs").read_bytes()
after = (root / "after.rs").read_bytes()
addition = b"            options.write(true);\n"
assert after.count(addition) == 1
assert after.replace(addition, b"", 1) == before
report["exact_single_statement_addition"] = True
report["existing_assertions_unchanged"] = True
(root / "SYNTAX_REPORT.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
