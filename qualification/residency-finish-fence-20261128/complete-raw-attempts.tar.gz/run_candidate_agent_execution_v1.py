from pathlib import Path
import os,subprocess,time,json,hashlib
R=Path(__file__).resolve().parent;S=R/'source';Q=R/'qualification/candidate-agent-execution-v1';Q.mkdir(mode=0o700)
env=dict(os.environ);env['PATH']='/Users/qianqi/.rustup/toolchains/1.96.1-aarch64-apple-darwin/bin:/opt/homebrew/bin:/Users/qianqi/.cargo/bin:/usr/bin:/bin:/usr/sbin:/sbin';env['CARGO_TARGET_DIR']=str(R/'cargo-target');env['CARGO_BUILD_JOBS']='4'
names=['codex-rs/core/src/agent/control/residency.rs','codex-rs/core/tests/suite/agent_execution.rs','codex-rs/core/tests/suite/agent_execution_finish_fence.rs','codex-rs/Cargo.toml','codex-rs/Cargo.lock']
before={n:(S/n).read_bytes() for n in names}
assert hashlib.sha256(before[names[0]]).hexdigest()=='e774ab1768df97e61408fed530bed676341e417e3918e4543a16dc2012a99d01'
(Q/'source-before.json').write_text(json.dumps({n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in before.items()},indent=2)+'\n')
command=['/opt/homebrew/bin/just','test','--locked','-p','codex-core','--test','all','-E','test(agent_execution)']
(Q/'command.intent.json').write_text(json.dumps({'argv':command,'cwd':str(S/'codex-rs'),'target':env['CARGO_TARGET_DIR']},indent=2)+'\n')
start=time.monotonic()
with (Q/'tests.stdout').open('xb') as out,(Q/'tests.stderr').open('xb') as err:
 child=subprocess.Popen(command,cwd=S/'codex-rs',env=env,stdout=out,stderr=err)
 (Q/'command.started.json').write_text(json.dumps({'pid':child.pid})+'\n')
 result={'returncode':child.wait(),'pid':child.pid,'seconds':time.monotonic()-start}
(Q/'command.terminal.json').write_text(json.dumps(result,indent=2)+'\n')
assert all((S/n).read_bytes()==v for n,v in before.items()),'candidate inputs changed'
raw=(Q/'tests.stderr').read_text()
result.update({'scope':'complete original agent_execution integration module plus two exact Finish controls','source_unchanged':True,'retry_or_flaky_seen':any(x in raw for x in ('TRY 1 FAIL','TRY 2','FLAKY'))})
(Q/'terminal.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
print(raw[-6500:],flush=True)
raise SystemExit(result['returncode'])
