from pathlib import Path
import json,hashlib,subprocess
R=Path('/Users/qianqi/work/codex-residency-finish-fence-20261128-2ac5');S=R/'source';Q=R/'qualification/source-v1';Q.mkdir(mode=0o700)
head=subprocess.check_output(['/usr/bin/git','-C',str(S),'rev-parse','HEAD'],text=True).strip()
assert head=='6f1e6717bd5f19b6c7a4c0b630251fbd013d8b70'
name='codex-rs/core/src/agent/control/residency.rs';p=S/name;old=p.read_bytes();text=old.decode()
text=text.replace('use crate::config::Config;\n','use crate::config::Config;\nuse crate::session::FinishRetryState;\n',1)
needle='''    ) -> bool {
        let candidates_to_scan = self.resident_count();
'''
assert text.count(needle)==1
replacement='''    ) -> bool {
        // A terminal event precedes its exact Finish owner's durable cleanup.
        // Inspect without popping the LRU: waiting must not expose a free slot.
        let candidates = {
            let state = self
                .state
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner);
            state
                .residents
                .iter()
                .copied()
                .filter(|thread_id| Some(*thread_id) != protected_thread_id)
                .collect::<Vec<_>>()
        };
        let mut finish_wait = None;
        for candidate_thread_id in candidates {
            let Ok(candidate) = manager.get_thread(candidate_thread_id).await else {
                continue;
            };
            if !is_resident_candidate(candidate.as_ref()) {
                continue;
            }
            // Preserve the existing preference for any immediately idle resident.
            if is_unloadable(candidate.as_ref()).await {
                finish_wait = None;
                break;
            }
            if finish_wait.is_none()
                && matches!(
                    candidate.agent_status().await,
                    AgentStatus::Completed(_) | AgentStatus::Errored(_) | AgentStatus::Interrupted
                )
            {
                let finish_state = {
                    let active = candidate.session.active_turn.lock().await;
                    candidate.session.finish_retry_state(active.as_ref())
                };
                if let FinishRetryState::Finishing(fences) = finish_state {
                    finish_wait = Some((candidate, fences));
                }
            }
        }
        if let Some((candidate, fences)) = finish_wait {
            'finish_wait: for completion in fences {
                tokio::select! {
                    biased;
                    () = completion.wait() => {},
                    () = candidate.wait_until_terminated() => break 'finish_wait,
                }
            }
        }
        // Do not capture a successor fence. Re-run the complete original unload
        // guards, including active ownership, shutdown, terminalization and mail.
        let candidates_to_scan = self.resident_count();
'''
text=text.replace(needle,replacement,1);p.write_text(text)
(Q/'original-residency.rs').write_bytes(old)
name2='codex-rs/core/tests/suite/agent_execution.rs';p2=S/name2;old2=p2.read_bytes()
assert b'mod finish_fence;' not in old2
p2.write_bytes(old2+b'\n#[path = "agent_execution_finish_fence.rs"]\nmod finish_fence;\n')
(Q/'original-agent_execution.rs').write_bytes(old2)
(Q/'prepared.json').write_text(json.dumps({'head':head,'original_sources':{name:{'bytes':len(old),'sha256':hashlib.sha256(old).hexdigest()},name2:{'bytes':len(old2),'sha256':hashlib.sha256(old2).hexdigest()}},indent=2)+'\n')
print('production and module prepared')
