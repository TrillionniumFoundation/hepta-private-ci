from pathlib import Path
R=Path(__file__).resolve().parent
driver=(R/'run_effective_environment_finish_v2.py').read_text()
start=driver.index("test=S/")
end=driver.index("env=dict(os.environ)")
replacement="""test=S/'codex-rs/core/tests/suite/agent_execution_finish_fence.rs';oldtest=test.read_bytes();(Q/'previous-candidate-test.rs').write_bytes(oldtest)
text=oldtest.decode()
old='use codex_protocol::protocol::EventMsg;'
new='''use codex_protocol::models::PermissionProfile;
use codex_protocol::models::PermissionProfileSnapshot;
use codex_protocol::protocol::EnvironmentConfig;
use codex_protocol::protocol::EnvironmentConfigState;
use codex_protocol::protocol::EventMsg;
use codex_protocol::protocol::ThreadSettingsOverrides;
use codex_protocol::protocol::TurnEnvironmentSelections;
use core_test_support::submit_thread_settings;'''
assert text.count(old)==1;text=text.replace(old,new)
old='    let mut created_threads = test.thread_manager.subscribe_thread_created();'
new='''    let mut child_environment = test.executor_environment().selection().clone();
    child_environment.config = EnvironmentConfigState::Ready(EnvironmentConfig {
        allow_login_shell: test.config.permissions.allow_login_shell,
        permission_profile: PermissionProfileSnapshot::legacy(PermissionProfile::read_only()),
        shell_environment_policy: Default::default(),
        exec_policy: None,
        mcp_policy: None,
        network_policy: None,
        selected_capability_roots: Vec::new(),
    });
    submit_thread_settings(
        &test.codex,
        ThreadSettingsOverrides {
            environments: Some(TurnEnvironmentSelections::new(
                test.config.cwd.clone(),
                vec![child_environment],
            )),
            ..Default::default()
        },
    )
    .await?;
    let mut created_threads = test.thread_manager.subscribe_thread_created();'''
assert text.count(old)==1;text=text.replace(old,new);test.write_text(text)
"""
driver=driver[:start]+replacement+driver[end:]
driver=driver.replace("qualification/effective-environment-finish-v2","qualification/resolved-authority-finish-v3")
driver=driver.replace("actual effective execution environments and original cwd retained; original five controls unchanged","explicit resolved read-only authority before both spawns; whole effective environment and cwd retained; original five controls unchanged")
(R/'run_resolved_authority_finish_v3.py').write_text(driver)
print('v3 immutable driver prepared',flush=True)
