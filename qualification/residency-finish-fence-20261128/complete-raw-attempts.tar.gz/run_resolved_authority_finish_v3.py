from pathlib import Path
import os,subprocess,time,json,hashlib
R=Path(__file__).resolve().parent;S=R/'source';Q=R/'qualification/resolved-authority-finish-v3';Q.mkdir(mode=0o700)
test=S/'codex-rs/core/tests/suite/agent_execution_finish_fence.rs';oldtest=test.read_bytes();(Q/'previous-candidate-test.rs').write_bytes(oldtest)
text=oldtest.decode()
old='use codex_protocol::protocol::EventMsg;'
new='''use codex_protocol::models::PermissionProfile;
use codex_protocol::models::PermissionProfileSnapshot;
use codex_protocol::protocol::EnvironmentConfig;
use codex_protocol::protocol::EnvironmentConfigState;
use codex_protocol::protocol::EventMsg;
use codex_protocol::protocol::ThreadSettingsOverrides;
use codex_protocol::protocol::TurnEnvironmentSelections;
use core_test_support::submit_thread_settings;'''
assert text.count(old)==1;text=text.replace(old,new)
old='    let mut created_threads = test.thread_manager.subscribe_thread_created();'
new='''    let mut child_environment = test.executor_environment().selection().clone();
    child_environment.config = EnvironmentConfigState::Ready(EnvironmentConfig {
        allow_login_shell: test.config.permissions.allow_login_shell,
        permission_profile: PermissionProfileSnapshot::legacy(PermissionProfile::read_only()),
        shell_environment_policy: Default::default(),
        exec_policy: None,
        mcp_policy: None,
        network_policy: None,
        selected_capability_roots: Vec::new(),
    });
    submit_thread_settings(
        &test.codex,
        ThreadSettingsOverrides {
            environments: Some(TurnEnvironmentSelections::new(
                test.config.cwd.clone(),
                vec![child_environment],
            )),
            ..Default::default()
        },
    )
    .await?;
    let mut created_threads = test.thread_manager.subscribe_thread_created();'''
assert text.count(old)==1;text=text.replace(old,new);test.write_text(text)
env=dict(os.environ);env['PATH']='/Users/qianqi/.rustup/toolchains/1.96.1-aarch64-apple-darwin/bin:/opt/homebrew/bin:/Users/qianqi/.cargo/bin:/usr/bin:/bin:/usr/sbin:/sbin';env['CARGO_TARGET_DIR']=str(R/'cargo-target');env['CARGO_BUILD_JOBS']='4'
def run(label,command):
 (Q/(label+'.intent.json')).write_text(json.dumps({'argv':command,'cwd':str(S/'codex-rs'),'target':env['CARGO_TARGET_DIR']},indent=2)+'\n')
 start=time.monotonic()
 with (Q/(label+'.stdout')).open('xb') as out,(Q/(label+'.stderr')).open('xb') as err:
  child=subprocess.Popen(command,cwd=S/'codex-rs',env=env,stdout=out,stderr=err)
  (Q/(label+'.started.json')).write_text(json.dumps({'pid':child.pid})+'\n')
  result={'returncode':child.wait(),'pid':child.pid,'seconds':time.monotonic()-start}
 (Q/(label+'.terminal.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(label,json.dumps(result),flush=True);return result
assert run('just-fmt',['/opt/homebrew/bin/just','fmt'])['returncode']==0
p=S/'codex-rs/core/src/agent/control/residency.rs';candidate=p.read_bytes();original=(R/'qualification/source-v1/original-residency.rs').read_bytes()
names=['codex-rs/core/src/agent/control/residency.rs','codex-rs/core/tests/suite/agent_execution.rs','codex-rs/core/tests/suite/agent_execution_finish_fence.rs','codex-rs/Cargo.toml','codex-rs/Cargo.lock']
def pins(label):
 values={n:(S/n).read_bytes() for n in names}
 (Q/(label+'.json')).write_text(json.dumps({n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in values.items()},indent=2)+'\n')
 return values
p.write_bytes(original);before=pins('original-source-before')
r=run('original-production',['/opt/homebrew/bin/just','test','--locked','-p','codex-core','--test','all','-E','test(residency_reload_waits_for_the_actual_terminal_owner)'])
assert all((S/n).read_bytes()==v for n,v in before.items())
p.write_bytes(candidate)
raw=(Q/'original-production.stderr').read_text()
assert r['returncode']==100 and 'reload settled while its only reclaimable resident still owned Finish: Ok(Err(AgentLimitReached' in raw, 'inspect original actual failure'
before=pins('candidate-source-before')
r2=run('candidate-complete-agent-execution',['/opt/homebrew/bin/just','test','--locked','-p','codex-core','--test','all','-E','test(agent_execution)'])
assert all((S/n).read_bytes()==v for n,v in before.items())
raw=(Q/'candidate-complete-agent-execution.stderr').read_text()
result={'scope':'explicit resolved read-only authority before both spawns; whole effective environment and cwd retained; original five controls unchanged','original_counterexample':r,'candidate':r2,'source_unchanged':True,'candidate_retry_or_flaky_seen':any(x in raw for x in ('TRY 1 FAIL','TRY 2','FLAKY'))}
(Q/'terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);print(raw[-6000:],flush=True)
raise SystemExit(r2['returncode'])
