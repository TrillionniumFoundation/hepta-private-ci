from pathlib import Path
import os,subprocess,time,json,hashlib,shutil
R=Path(__file__).resolve().parent;S=R/'source';Q=R/'qualification/original-finish-counterexample-v1';Q.mkdir(mode=0o700)
env=dict(os.environ);env['PATH']='/Users/qianqi/.rustup/toolchains/1.96.1-aarch64-apple-darwin/bin:/opt/homebrew/bin:/Users/qianqi/.cargo/bin:/usr/bin:/bin:/usr/sbin:/sbin'
env['CARGO_TARGET_DIR']=str(R/'cargo-target');env['CARGO_BUILD_JOBS']='4'
def run(label,command):
    (Q/(label+'.intent.json')).write_text(json.dumps({'argv':command,'cwd':str(S/'codex-rs'),'target':env['CARGO_TARGET_DIR']},indent=2)+'\n')
    start=time.monotonic()
    with (Q/(label+'.stdout')).open('xb') as out,(Q/(label+'.stderr')).open('xb') as err:
        p=subprocess.Popen(command,cwd=S/'codex-rs',env=env,stdout=out,stderr=err)
        (Q/(label+'.started.json')).write_text(json.dumps({'pid':p.pid})+'\n')
        code=p.wait()
    result={'returncode':code,'pid':p.pid,'seconds':time.monotonic()-start}
    (Q/(label+'.terminal.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(label,json.dumps(result),flush=True)
    if code:print((Q/(label+'.stderr')).read_text()[-6000:],flush=True)
    return result
inventory={'tools':{name:shutil.which(name,path=env['PATH']) for name in ('cargo','cargo-nextest','rustc','rustfmt','just')},'available_bytes':os.statvfs(R).f_bavail*os.statvfs(R).f_frsize}
(Q/'environment.json').write_text(json.dumps(inventory,indent=2)+'\n');print(json.dumps(inventory),flush=True)
assert inventory['available_bytes']>12*(1<<30)
assert run('just-fmt',['/opt/homebrew/bin/just','fmt'])['returncode']==0
name='codex-rs/core/src/agent/control/residency.rs';p=S/name;candidate=p.read_bytes();old=(R/'qualification/source-v1/original-residency.rs').read_bytes()
(Q/'candidate-residency.rs').write_bytes(candidate);(Q/'original-residency.rs').write_bytes(old)
sources=[name,'codex-rs/core/tests/suite/agent_execution.rs','codex-rs/core/tests/suite/agent_execution_finish_fence.rs','codex-rs/Cargo.toml','codex-rs/Cargo.lock']
p.write_bytes(old)
before={n:(S/n).read_bytes() for n in sources}
(Q/'source-before.json').write_text(json.dumps({n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in before.items()},indent=2)+'\n')
command=['/opt/homebrew/bin/just','test','--locked','-p','codex-core','--test','all','-E','test(residency_reload_waits_for_the_actual_terminal_owner)']
result=run('original-production-new-race-controls',command)
assert all((S/n).read_bytes()==v for n,v in before.items()),'test inputs changed during original-production observation'
p.write_bytes(candidate)
(Q/'observation.json').write_text(json.dumps({'scope':'original production with new actual Finish lifecycle controls','actual_test_result':result,'candidate_restored':p.read_bytes()==candidate,'original_source_sha256':hashlib.sha256(old).hexdigest(),'candidate_source_sha256':hashlib.sha256(candidate).hexdigest(),'interpretation':'Inspect raw nextest result: a compile/tool failure is not the intended counterexample.'},indent=2)+'\n')
print('OBSERVATION_COMPLETE candidate restored; inspect actual test result',flush=True)
