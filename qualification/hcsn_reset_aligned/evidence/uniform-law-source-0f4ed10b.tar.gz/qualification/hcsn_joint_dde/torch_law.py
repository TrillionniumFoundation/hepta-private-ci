"""First-order CPU FP64 VJP through physical parameters and initial laws.

Every initial-law basis is transported through the actual dense-history DDE,
including all delayed returns. There is no detached-history approximation.
Packet supports and delay are fixed; probabilities/content are differentiable.
Reset remains piecewise affine and is rejected at knots. No higher-order AD,
moving prior geometry, continuum accuracy or task-benefit claim is supplied.
"""

from dataclasses import replace
from fractions import Fraction
import math

import numpy as np
import torch
from torch.autograd.function import once_differentiable

from qualification.hcsn_boundary_audit.refractory_transport import Packet
from qualification.hcsn_joint_dde.sensitivities import PARAMETERS, solve_partials


FIELDS = ("active", "upper", "refractory", "events", "discounted_events",
          "discounted_active_time", "discounted_remaining_phase")


def _array(row):
    return np.concatenate([row["active"], *[np.asarray(row[k])[None] for k in FIELDS[1:]]])


def _packets(supports, weights):
    return tuple(Packet(str(i), lo, hi, Fraction(float(row[0])),
                        tuple(Fraction(float(x)) for x in row[1:]))
                 for i, ((lo, hi), row) in enumerate(zip(supports, weights)))


class _LawFlow(torch.autograd.Function):
    @staticmethod
    def forward(ctx, parameters, law, template, times, supports, options):
        for value in (parameters, law):
            if value.device.type != "cpu" or value.dtype != torch.float64 or not torch.isfinite(value).all():
                raise ValueError("finite CPU FP64 tensors required")
        n = template.spatial.intervals
        if (parameters.shape != (5,) or law.ndim != 2 or
                law.shape[0] != n+len(supports) or not 2 <= law.shape[1] <= 17 or
                not isinstance(supports, tuple) or len(supports) > 8 or n+len(supports) > 64):
            raise ValueError("five physics parameters and bounded nodal/packet law required")
        if torch.any(law[:, 0] < 0) or torch.any(law[n:, 0] <= 0):
            raise ValueError("nonnegative nodal and positive packet probabilities required")
        if any(not isinstance(s, tuple) or len(s) != 2 or
               any(type(x) not in (int, Fraction) for x in s) for s in supports):
            raise ValueError("fixed exact rational packet supports required")
        boundary, drift, sigma, reset, discount = parameters.detach().tolist()
        if reset <= 0:
            raise ValueError("positive absolute reset required")
        model = replace(template, spatial=replace(template.spatial, mu=drift, sigma=sigma),
                        reset=math.log(reset)-boundary, discount=discount)
        initial = law.detach().numpy()
        active = np.r_[0., initial[:n, 0]]
        content = np.vstack((np.zeros((1, law.shape[1]-1)), initial[:n, 1:]))
        phase = _packets(supports, initial[n:])
        result = solve_partials(model, times, active, content, phase,
                                log_boundary=boundary, absolute_reset=reset, **options)
        values = np.stack([_array(row["primal"]) for row in result["rows"]])
        jacobian = np.stack([np.stack([_array(row["partials"][name]) for name in PARAMETERS], -1)
                             for row in result["rows"]])
        # Linearity holds independently per signed mark. Batch at most 16
        # basis columns through the original solver's unchanged channel bound.
        kernels = []
        for start in range(0, len(initial), 16):
            count = min(16, len(initial)-start)
            basis = np.eye(len(initial))[:, start:start+count]
            marked = np.vstack((np.zeros((1, count)), basis[:n]))
            # Unit packet probability is only a valid carrier; its output is
            # discarded. Basis content independently identifies each law row.
            packets = _packets(supports, np.column_stack((np.ones(len(supports)), basis[n:])))
            propagated = model.solve(times, np.zeros(n+1), marked, packets, **options)
            kernels.append(np.stack([_array(row)[:, 1:] for row in propagated["rows"]]))
        kernel = np.concatenate(kernels, axis=-1)
        ctx.save_for_backward(torch.from_numpy(jacobian), torch.from_numpy(kernel))
        return torch.from_numpy(values)

    @staticmethod
    @once_differentiable
    def backward(ctx, cotangent):
        jacobian, kernel = ctx.saved_tensors
        return (torch.einsum("tscp,tsc->p", jacobian, cotangent),
                torch.einsum("tsb,tsc->bc", kernel, cotangent),
                None, None, None, None)


def law_flow(parameters, law, template, times, phase_supports=(), **options):
    """Return [query,state,channel] with gradients for physics and law.

    Physics order is log_boundary, mu, sigma, absolute_reset, discount. Law
    rows are spatial nodes 1..N (upper included), then fixed phase supports;
    column 0 is mass and columns 1..K are signed content totals. Output rows
    are interior nodes followed by upper, refractory, M, H_q, A_q, Z_q.
    Normalization is the caller's responsibility (e.g. softmax probabilities).
    The initial relative-coordinate law is held fixed in physical partials;
    caller dependence of that law on physics is added by ordinary chain rule.
    """
    return _LawFlow.apply(parameters, law, template, times, phase_supports, options)
