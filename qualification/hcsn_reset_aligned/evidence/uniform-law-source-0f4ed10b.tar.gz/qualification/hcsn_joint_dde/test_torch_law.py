"""Actual initial-law/physical VJP, dense-history and reset-kink evidence."""

from dataclasses import replace
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import unittest

import numpy as np
from scipy.linalg import expm
import torch

from qualification.hcsn_boundary_audit.refractory_transport import Packet
from qualification.hcsn_boundary_audit.spatial_generator import KilledSpatialGenerator
from qualification.hcsn_joint_dde.model import JointModel
from qualification.hcsn_joint_dde.torch_law import law_flow


OPTIONS = dict(rtol=2e-11, atol=2e-13, max_step=.015)


def direct(theta, law, template, times, supports=()):
    boundary, drift, sigma, reset, discount = theta.tolist()
    model = replace(template, spatial=replace(template.spatial, mu=drift, sigma=sigma),
                    reset=math.log(reset)-boundary, discount=discount)
    n = model.spatial.intervals
    packets = tuple(Packet(str(i), a, b, Fraction(float(w[0])),
                    tuple(Fraction(float(x)) for x in w[1:]))
                    for i, ((a, b), w) in enumerate(zip(supports, law[n:])))
    result = model.solve(times, np.r_[0., law[:n, 0]],
        np.vstack((np.zeros((1, law.shape[1]-1)), law[:n, 1:])), packets, **OPTIONS)
    fields = ("upper", "refractory", "events", "discounted_events",
              "discounted_active_time", "discounted_remaining_phase")
    return np.stack([np.vstack((row["active"], *[row[k] for k in fields])) for row in result["rows"]])


class InitialLawVjp(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        cls.sources = {str(p.relative_to(Path(__file__).parents[2])):
            hashlib.sha256(p.read_bytes()).hexdigest()
            for name in ("hcsn_joint_dde", "hcsn_boundary_audit")
            for p in (Path(__file__).parents[1]/name).glob("*.py")}
        cls.records = []

    @classmethod
    def tearDownClass(cls):
        print("LAW_VJP_EVIDENCE", json.dumps(dict(source_sha256=cls.sources,
            records=cls.records, scope="first-order CPU FP64 fixed geometry/delay",
            reset_knots_differentiable=False, rare_tail_relative_qualified=False,
            full_network_training=False), sort_keys=True))

    def setUp(self):
        self.model = JointModel(KilledSpatialGenerator(8, 2., -.12, .5), .53, .2, .15)
        self.theta = torch.tensor([.01, -.12, .5, math.exp(.54), .15],
                                  dtype=torch.float64, requires_grad=True)
        self.supports = ((Fraction(0), Fraction(0)),
                         (Fraction(1, 20), Fraction(3, 20)))
        mass = torch.arange(1., 11., dtype=torch.float64)/55
        self.law = torch.stack((mass, .7*mass, -.2*mass), -1).requires_grad_()
        self.times = [0., .1, .2, .6]

    def test_forward_and_joint_physics_initial_law_gradcheck(self):
        output = law_flow(self.theta, self.law, self.model, self.times, self.supports, **OPTIONS)
        reference = direct(self.theta.detach().numpy(), self.law.detach().numpy(),
                           self.model, self.times, self.supports)
        np.testing.assert_allclose(output.detach(), reference, rtol=0, atol=3e-9)
        torch.manual_seed(311)
        passed = torch.autograd.gradcheck(lambda p, law: law_flow(p, law, self.model,
            self.times, self.supports, **OPTIONS), (self.theta, self.law),
            eps=1e-4, atol=4e-6, rtol=5e-4, fast_mode=True)
        self.assertTrue(passed)
        self.records.append(dict(case="joint_gradcheck", passed=True,
            maximum_forward_absolute_error=float(np.max(np.abs(output.detach().numpy()-reference))),
            initial_law_shape=list(self.law.shape), query_times=self.times))

    def test_law_and_signed_content_derivatives_preserve_mass(self):
        output = law_flow(self.theta, self.law, self.model, self.times, self.supports, **OPTIONS)
        # Interior + upper + refractory, for one signed channel at a time.
        for c in range(3):
            gradient = torch.autograd.grad(output[-1, :9, c].sum(), self.law,
                                           retain_graph=True)[0]
            expected = torch.zeros_like(self.law)
            expected[:, c] = 1
            torch.testing.assert_close(gradient, expected, rtol=0, atol=4e-9)
        self.records.append(dict(case="mass_content_law_jacobian", all_channels=True))

    def test_post_delay_derivative_includes_recursive_returns(self):
        law = self.law[:8].detach().clone().requires_grad_()
        result = law_flow(self.theta, law, self.model, [0., .6], **OPTIONS)
        gradient = torch.autograd.grad(result[-1, 9, 0], law)[0][:, 0]
        killed = expm(.6*self.model.spatial.matrix())[1:, 0]
        # Lower-hit probability accounts for only the first hit. A larger
        # derivative proves subsequent DDE-reset cycles reach backward.
        excess = gradient.detach().numpy()-killed
        self.assertGreater(float(np.max(excess)), .01)
        self.assertGreaterEqual(float(np.min(excess)), -1e-9)
        self.records.append(dict(case="recursive_history_derivative", derivative=gradient.tolist(),
                                 killed_first_hit=killed.tolist(), excess=excess.tolist()))

    def test_boundary_low_noise_and_short_time_directional_fd(self):
        cases = [("near_boundary", -.12, .5, .25),
                 ("low_noise", 0., .08, .25),
                 ("short_time", -.12, .5, .001)]
        for name, mu, sigma, horizon in cases:
            theta = self.theta.detach().clone()
            theta[1:3] = torch.tensor([mu, sigma])
            theta.requires_grad_()
            # Strictly positive mass permits two-sided directional checks.
            mass = torch.full((8,), .01, dtype=torch.float64)
            mass[0] = .93
            law = torch.stack((mass, -2*mass), -1).requires_grad_()
            weights = torch.linspace(.1, 1.1, 26, dtype=torch.float64).reshape(13, 2)
            output = law_flow(theta, law, self.model, [0., horizon], **OPTIONS)
            objective = (output[-1]*weights).sum()
            gp, gl = torch.autograd.grad(objective, (theta, law))
            dp = np.array([.3, .1, .4, -.2, .2])
            dl = np.linspace(-.1, .1, 16).reshape(8, 2)
            ad = float(gp@torch.from_numpy(dp)+(gl*torch.from_numpy(dl)).sum())
            estimates = []
            for epsilon in (2e-4, 1e-4):
                high = direct(theta.detach().numpy()+epsilon*dp,
                              law.detach().numpy()+epsilon*dl, self.model, [0., horizon])
                low = direct(theta.detach().numpy()-epsilon*dp,
                             law.detach().numpy()-epsilon*dl, self.model, [0., horizon])
                fd = float(((high[-1]-low[-1])*weights.numpy()).sum()/(2*epsilon))
                self.assertLessEqual(abs(fd-ad), 4e-6+5e-4*abs(fd))
                estimates.append(fd)
            self.records.append(dict(case=name, horizon=horizon, ad=ad,
                finite_differences=estimates, absolute_errors=[abs(x-ad) for x in estimates],
                relative_rare_event_precision_claimed=False))

    def test_actual_reset_kink_is_retained_and_refused(self):
        model = replace(self.model, reset=.5)
        point = np.zeros(9)
        point[1] = 1
        def value(reset):
            row = replace(model, reset=reset).solve([0., .6], point, point[:, None], **OPTIONS)["rows"][-1]
            return float(row["events"][0])
        center = value(.5)
        attempts = []
        for step in (2e-4, 1e-4):
            left = (center-value(.5-step))/step
            right = (value(.5+step)-center)/step
            self.assertGreater(abs(left-right), .01)
            attempts.append(dict(step=step, left=left, right=right, gap=abs(left-right)))
        theta = self.theta.detach().clone()
        theta[3] = math.exp(.5+float(theta[0]))
        with self.assertRaisesRegex(ValueError, "off-knot"):
            law_flow(theta, self.law, model, self.times, self.supports, **OPTIONS)
        self.records.append(dict(case="reset_node_kink", attempts=attempts,
                                 knot_refused=True, smoothed_surrogate=False))


if __name__ == "__main__":
    unittest.main()
