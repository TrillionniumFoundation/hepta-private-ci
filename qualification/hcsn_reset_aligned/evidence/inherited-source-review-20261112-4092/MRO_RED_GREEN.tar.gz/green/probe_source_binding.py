"""Counterfactual changes only an isolated copy of inherited operator code."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np


ROOT = Path(__file__).resolve().parent
COPY = ROOT / "operator-copy"
env = dict(os.environ, PYTHONPATH=str(COPY), PYTHONDONTWRITEBYTECODE="1")
common = """
import hashlib, inspect, json
from pathlib import Path
from qualification.hcsn_joint_dde.state_io import _binding
from qualification.hcsn_reset_aligned.test_common_state import TestCommonCandidateState
case = TestCommonCandidateState('test_migrated_law_aligned_reset_and_cold_state_obey_dynamic_value')
case.setUp()
fields = ('active','upper','refractory','events','discounted_events','discounted_active_time','discounted_remaining_phase')
binding = _binding(case.model)
"""
before_code = common + """
prefix = case.model.solve([.07,.137], case.active, case.content, case.phase, export_state=True, **case.controls)
Path('../CHECKPOINT.json').write_bytes(prefix['checkpoint'])
full = case.model.solve([.07,.137,.417,1.], case.active, case.content, case.phase, **case.controls)
result = dict(binding=binding, matrix=case.model.spatial.matrix().tolist(),
              inherited_rates_source=inspect.getfile(type(case.model.spatial).rates.fget),
              final={key:full['rows'][-1][key].tolist() for key in fields})
print(json.dumps(result, allow_nan=False))
"""
before = subprocess.run([sys.executable, "-B", "-c", before_code], cwd=COPY, env=env,
                        capture_output=True, text=True, timeout=60)
(ROOT / "BEFORE.stdout").write_text(before.stdout)
(ROOT / "BEFORE.stderr").write_text(before.stderr)
before.check_returncode()
reference = json.loads(before.stdout)
path = COPY / "qualification/hcsn_joint_dde/graded.py"
original = path.read_text()
changed = original.replace("(self.sigma**2 - self.mu * right)",
                           "(1.01 * (self.sigma**2 - self.mu * right))")
changed = changed.replace("(self.sigma**2 + self.mu * left)",
                         "(1.01 * (self.sigma**2 + self.mu * left))")
if changed == original:
    raise AssertionError("probe did not alter isolated rates")
path.write_text(changed)
after_code = common + """
raw = Path('../CHECKPOINT.json').read_bytes()
restored = case.model.solve([.417,1.], checkpoint=raw, **case.controls)
result = dict(binding=binding, matrix=case.model.spatial.matrix().tolist(),
              restore_accepted=True, integration_started_at=restored['integration_started_at'],
              final={key:restored['rows'][-1][key].tolist() for key in fields})
print(json.dumps(result, allow_nan=False))
"""
after = subprocess.run([sys.executable, "-B", "-c", after_code], cwd=COPY, env=env,
                       capture_output=True, text=True, timeout=60)
(ROOT / "AFTER.stdout").write_text(after.stdout)
(ROOT / "AFTER.stderr").write_text(after.stderr)
after.check_returncode()
actual = json.loads(after.stdout)
errors = {key: float(np.max(abs(np.asarray(actual['final'][key])-value)))
          for key, value in reference['final'].items()}
report = dict(
    original_sources_modified=False,
    altered_only_isolated_file="qualification/hcsn_joint_dde/graded.py",
    old_graded_sha256=hashlib.sha256(original.encode()).hexdigest(),
    new_graded_sha256=hashlib.sha256(changed.encode()).hexdigest(),
    inherited_rates_source=reference['inherited_rates_source'],
    binding_unchanged=reference['binding']==actual['binding'],
    binding_sources=reference['binding']['sources'],
    graded_file_bound="hcsn_joint_dde/graded.py" in reference['binding']['sources'],
    generator_max_difference=float(np.max(abs(np.asarray(actual['matrix'])-reference['matrix']))),
    restore_accepted=actual['restore_accepted'],
    integration_started_at=actual['integration_started_at'],
    old_operator_continuation_errors=errors,
)
(ROOT / "REVIEW_SOURCE_BINDING.json").write_text(json.dumps(report, indent=2, sort_keys=True)+"\n")
print(json.dumps(report, indent=2, sort_keys=True))
