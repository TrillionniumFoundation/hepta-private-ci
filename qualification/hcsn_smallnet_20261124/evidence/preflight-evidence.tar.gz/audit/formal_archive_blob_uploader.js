/* Read-only archive transport plus Git object creation. No tree/ref operations. */
(() => {
  const K = new Uint32Array([
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]);
  const rr = (x,n) => (x>>>n)|(x<<(32-n));
  const rl = (x,n) => (x<<n)|(x>>>(32-n));
  class Hash {
    constructor(kind) {
      this.kind=kind;this.length=0;this.used=0;this.buffer=new Uint8Array(64);
      this.h=new Uint32Array(kind===1 ? [0x67452301,0xefcdab89,0x98badcfe,0x10325476,0xc3d2e1f0] :
        [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
      this.w=new Uint32Array(kind===1?80:64);
    }
    update(bytes) {
      this.length+=bytes.length;
      let offset=0;
      while(offset<bytes.length) {
        const count=Math.min(64-this.used,bytes.length-offset);
        this.buffer.set(bytes.subarray(offset,offset+count),this.used);
        this.used+=count;offset+=count;
        if(this.used===64){this.block(this.buffer);this.used=0;}
      }
      return this;
    }
    block(bytes) {
      const w=this.w;
      for(let i=0;i<16;i++){const j=i*4;w[i]=((bytes[j]<<24)|(bytes[j+1]<<16)|(bytes[j+2]<<8)|bytes[j+3])>>>0;}
      if(this.kind===1) {
        for(let i=16;i<80;i++)w[i]=rl(w[i-3]^w[i-8]^w[i-14]^w[i-16],1)>>>0;
        let [a,b,c,d,e]=this.h;
        for(let i=0;i<80;i++){
          const f=i<20?((b&c)|(~b&d)):i<40?(b^c^d):i<60?((b&c)|(b&d)|(c&d)):(b^c^d);
          const k=i<20?0x5a827999:i<40?0x6ed9eba1:i<60?0x8f1bbcdc:0xca62c1d6;
          const temp=(rl(a,5)+f+e+k+w[i])>>>0;e=d;d=c;c=rl(b,30)>>>0;b=a;a=temp;
        }
        const q=[a,b,c,d,e];for(let i=0;i<5;i++)this.h[i]=(this.h[i]+q[i])>>>0;
      } else {
        for(let i=16;i<64;i++){const x=w[i-15],y=w[i-2];w[i]=(w[i-16]+(rr(x,7)^rr(x,18)^(x>>>3))+w[i-7]+(rr(y,17)^rr(y,19)^(y>>>10)))>>>0;}
        let [a,b,c,d,e,f,g,h]=this.h;
        for(let i=0;i<64;i++){
          const one=(h+(rr(e,6)^rr(e,11)^rr(e,25))+((e&f)^(~e&g))+K[i]+w[i])>>>0;
          const two=((rr(a,2)^rr(a,13)^rr(a,22))+((a&b)^(a&c)^(b&c)))>>>0;
          h=g;g=f;f=e;e=(d+one)>>>0;d=c;c=b;b=a;a=(one+two)>>>0;
        }
        const q=[a,b,c,d,e,f,g,h];for(let i=0;i<8;i++)this.h[i]=(this.h[i]+q[i])>>>0;
      }
    }
    hex() {
      const length=this.length,pad=new Uint8Array(this.used<56?64-this.used:128-this.used);pad[0]=128;
      const high=Math.floor(length/0x20000000),low=(length*8)>>>0,start=pad.length-8;
      for(let i=0;i<4;i++){pad[start+i]=(high>>>(24-8*i))&255;pad[start+4+i]=(low>>>(24-8*i))&255;}
      this.update(pad);return Array.from(this.h,x=>x.toString(16).padStart(8,'0')).join('');
    }
  }
  const ascii = s => Uint8Array.from(s,c=>c.charCodeAt(0));
  const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  const lookup=new Int16Array(128).fill(-1);for(let i=0;i<64;i++)lookup[alphabet.charCodeAt(i)]=i;
  function decode(s) {
    if(s.length%4||!/^[A-Za-z0-9+/]*={0,2}$/.test(s))throw new Error('noncanonical base64');
    const padding=s.endsWith('==')?2:s.endsWith('=')?1:0,result=new Uint8Array(s.length/4*3-padding);
    let at=0;
    for(let i=0;i<s.length;i+=4){const a=lookup[s.charCodeAt(i)],b=lookup[s.charCodeAt(i+1)],c=s[i+2]==='='?0:lookup[s.charCodeAt(i+2)],d=s[i+3]==='='?0:lookup[s.charCodeAt(i+3)];
      const v=(a<<18)|(b<<12)|(c<<6)|d; if(at<result.length)result[at++]=(v>>>16)&255;if(at<result.length)result[at++]=(v>>>8)&255;if(at<result.length)result[at++]=v&255;
      if(i+4===s.length&&((padding===2&&(b&15))||(padding===1&&(c&3))))throw new Error('nonzero base64 padding bits');
    }
    return result;
  }
  function parseTool(result) {
    if(result.isError)throw new Error('tool_error: '+JSON.stringify(result).slice(0,1800));
    if(result.structuredContent&&typeof result.structuredContent==='object')return result.structuredContent;
    const texts=(result.content||[]).filter(c=>c.type==='text').map(c=>c.text);
    for(const item of texts){try{return JSON.parse(item);}catch{}}
    throw new Error('tool returned no JSON object: '+texts.join('\n').slice(0,1600));
  }
  function verifyVectors() {
    const abc=ascii('abc');
    if(new Hash(1).update(abc).hex()!=='a9993e364706816aba3e25717850c26c9cd0d89d')throw new Error('SHA1 self-test failed');
    if(new Hash(256).update(abc).hex()!=='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')throw new Error('SHA256 self-test failed');
    if(new Hash(1).update(ascii('blob 0\0')).hex()!=='e69de29bb2d1d6434b8b29ae775ad8c2e48c5391')throw new Error('Git header self-test failed');
    if(Array.from(decode('AAECA/7/')).join(',')!=='0,1,2,3,254,255')throw new Error('base64 self-test failed');
    return true;
  }
  async function readRemote(entry,root) {
    let offset=0,version,total,git;const chunks=[],parts=[],transport_retries=[],whole=new Hash(256);const started=Date.now();
    while(true){
      let d;
      for(let attempt=0;attempt<3;attempt++){
        try {
          const raw=await tools.mcp__codex_apps__h_binary_read({host:'desktop',path:root+'/'+entry.file,offset,limit:65535,...(version?{expected_version:version}:{})});
          d=parseTool(raw);break;
        } catch(error) {
          if(attempt===2||!String(error).includes('Connection closed by'))throw error;
          transport_retries.push({offset,attempt:attempt+1,error:String(error).slice(0,1000),at:new Date().toISOString()});
        }
      }
      const bytes=decode(d.data_base64);
      if(d.offset!==offset||d.next_offset!==offset+bytes.length||d.path!==root+'/'+entry.file)throw new Error('source offset/path mismatch');
      if(!version){version=d.version;total=d.size;git=new Hash(1).update(ascii('blob '+total+'\0'));if(entry.bytes!==undefined&&entry.bytes!==total)throw new Error('manifest byte-size mismatch');}
      if(d.version!==version||d.size!==total)throw new Error('archive version changed during read');
      const chunkSha=new Hash(256).update(bytes).hex();if(chunkSha!==d.chunk_sha256)throw new Error('chunk SHA256 mismatch');
      whole.update(bytes);git.update(bytes);parts.push(d.data_base64);chunks.push({offset,bytes:bytes.length,sha256:chunkSha});offset=d.next_offset;
      if(d.eof){if(offset!==total)throw new Error('premature eof');break;}
      if(bytes.length===0||bytes.length%3||d.data_base64.includes('='))throw new Error('nonfinal base64 chunk cannot concatenate exactly');
    }
    const sha256=whole.hex(),git_sha=git.hex();
    if(entry.sha256&&entry.sha256!==sha256)throw new Error('full SHA256 differs from publication manifest');
    if(entry.git_blob_sha1&&entry.git_blob_sha1!==git_sha)throw new Error('Git blob SHA1 differs from publication manifest');
    return {content:parts.join(''),receipt:{file:entry.file,bytes:total,version,sha256,git_sha,chunks,transport_retries,read_wall_ms:Date.now()-started}};
  }
  function blobSha(raw) {
    const value=parseTool(raw);let found=[];
    function visit(v){if(!v||typeof v!=='object')return;for(const [key,item]of Object.entries(v)){if(key==='sha'&&typeof item==='string'&&/^[a-f0-9]{40}$/.test(item))found.push(item);else if(item&&typeof item==='object')visit(item);}}
    visit(value);found=[...new Set(found)];if(found.length!==1)throw new Error('ambiguous GitHub blob receipt');return found[0];
  }
  async function publish(entry,root,repository,prefix) {
    const started=Date.now();const loaded=await readRemote(entry,root);const uploadStarted=Date.now();
    const raw=await tools.mcp__codex_apps__github_create_blob({repository_full_name:repository,encoding:'base64',content:loaded.content});
    const sha=blobSha(raw);if(sha!==loaded.receipt.git_sha)throw new Error('GitHub returned a different blob SHA');
    return {...loaded.receipt,status:'verified_blob_created',path:prefix+'/'+entry.file,mode:'100644',type:'blob',sha,upload_wall_ms:Date.now()-uploadStarted,total_wall_ms:Date.now()-started,verified_at:new Date().toISOString()};
  }
  return {Hash,ascii,decode,parseTool,verifyVectors,readRemote,publish,blobSha};
})()
