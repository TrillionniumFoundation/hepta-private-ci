"""Record logical completion without rewriting the timed-out execution history."""
import hashlib
import json
import pathlib
import sys

root = pathlib.Path('/home/qian-qi/hcsn-smallnet-20261124/formal-v1')
evidence = json.loads(sys.stdin.read())

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def create(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write('\n')

assert evidence['resume']['status']['state'] == 'succeeded'
assert evidence['resume']['status']['exit_code'] == 0
prior = read(root/'final_stage_timeout.json')
assert prior['state'] == 'timed_out' and prior['exit_code'] == 124
resume = read(root/'training/RESUME_RECEIPT.json')
assert resume['completed_before_count'] == 63 and resume['resumed_count'] == 9
assert len(resume['workers_finished']) == 9
assert all(x['returncode'] == 0 for x in resume['workers_finished'])
final = read(root/'training/FINAL_RESULTS.json')
assert len(final['results']) == 72
assert all(x['status'] == 'evaluated' for x in final['results'])
assert final['resume_receipt']['sha256'] == sha(root/'training/RESUME_RECEIPT.json')
assert final['seal_sha256'] == sha(root/'training/SEAL.json')
original = [json.loads(line) for line in evidence['original_finalizer']['stdout'].splitlines()]
opened, completed = original[0], original[1:]
assert opened['stage'] == 'both_selection_stages_sealed'
assert opened['training_seal'] == sha(root/'training/SEAL.json')
assert opened['adaptation_seal'] == sha(root/'adaptation/GLOBAL_ADAPTATION_SEAL.json')
protocol = read(root/'PROTOCOL_FROZEN.json')
expected = {f'n{n}-qvi_full-s{s}' for n in protocol['independent_neurons'] for s in protocol['seeds']}
assert len(completed) == 9 and {r['name'] for r in completed} == expected
assert all(r['returncode'] == 0 for r in completed)
adaptation_body_cpu = 0.0
for row in completed:
    result = read(root/'adaptation'/row['name']/'FINAL_RESULTS.json')
    assert result['training_seal_sha256'] == opened['training_seal']
    assert result['global_adaptation_seal_sha256'] == opened['adaptation_seal']
    assert len(result['results']) == 5
    assert all(r['status'] == 'evaluated' for r in result['results'].values())
    adaptation_body_cpu += result['cost_before_final_json']['cpu_seconds']
for name, files in resume['completed_before'].items():
    for filename, digest in files.items():
        assert sha(root/'training'/name/filename) == digest
create(root/'final_stage_recovery_execution.json', evidence)
rows = [{'name': 'training', 'returncode': 0,
    'returncode_scope': 'logical completion after a timed-out original process and successful missing-slot continuation',
    'completed_original_cases': 63, 'resumed_cases': 9,
    'original_process_exit_code': 124,
    'resume_terminal_status': evidence['resume']['status'],
    'resume_receipt_sha256': sha(root/'training/RESUME_RECEIPT.json')}, *completed]
receipt = {'schema': 2, 'rows': rows,
    'scope': 'ten logical final evaluations completed; original coordinator did NOT exit successfully',
    'operational_attempts': [prior, evidence['resume']],
    'both_sealed_unix_time': opened['unix_time'],
    'holdout_opened_only_after_both_seals': True,
    'original_wall_seconds_including_wait': prior['wall_seconds_including_wait'],
    'all_child_cpu_seconds': None,
    'all_child_cpu_unavailable_reason': prior['systemd_cpu_unavailable_reason'],
    'training_test_body_cpu_seconds_72_disjoint_completed_cases': sum(r['cost']['cpu_seconds'] for r in final['results']),
    'adaptation_test_body_cpu_seconds_9_disjoint_parents': adaptation_body_cpu,
    'resume_child_cpu_including_shutdown_seconds': resume['child_cpu_including_shutdown_seconds'],
    'cost_overlap_note': 'Resume child CPU overlaps nine completed test-body records; do not sum nested values. Original interrupted imports/preflight/unfinished case CPU is missing.',
    'energy_joules': None,
    'evidence_sha256': sha(root/'final_stage_recovery_execution.json'),
    'script_sha256': sha(pathlib.Path(__file__))}
create(root/'FINAL_STAGE_RECEIPT.json', receipt)
print(json.dumps({'logical_final_evaluations_completed': len(rows), 'training_cases': 72,
                  'adaptation_method_cases': 45, 'original_exit_code': 124,
                  'resume_exit_code': 0, 'receipt_sha256': sha(root/'FINAL_STAGE_RECEIPT.json')}))
