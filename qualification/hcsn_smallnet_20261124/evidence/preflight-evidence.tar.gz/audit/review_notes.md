# HCSN 接续研究独立审查记录

日期：2026-11-24 UTC。审查者职责：只读核对远端研究、保全上游原件、检查依赖与新方案；不提交远端、不修改其他协作者代码、不重跑旧 sealed campaign。

## 1. 本轮准确源身份与接续边界

本地 `next_hcsn/upstream/` 是只读研究源胶囊，不是完整 Git 仓库或新的已验证发布。

- 主源：`b1af67a38f8cf9cee700cc067da1e6001ce220a8`，branch `research/hcsn-finite-marked-renewal-20261123`，Draft PR #7032。
- 92 个上游文件均已逐字节重算 Git blob SHA；清单为 `upstream/SOURCE_MANIFEST.json`。本地 materialization 最终已与远端原件一致。
- 唯一异源文件：`qualification/hcsn_network/RESULTS_298fae.md`，原路径为 `qualification/hcsn_network/RESULTS.md`，来自 `298fae004356f4adb5b58f2bc4d61fdde5bdab75`。改名只为避免将另分支实测结果伪称 b1af 的文件。
- #7052 head `78c1012d1b6d63a2cd3d67e2534ba8b8d62e34b6` 是 b1af 上的 Rust qualification 错误传播/帮助函数修复；并没有新增网络训练证据。
- #6987 head `bceb3d93c49442341a10afd751384182b46081e3` 是另一 WSP/action-control 研究栈，不能把其人工故障修复直接当本新网络已有训练资格。
- audit branch 当前读取 head `f8a6b335d8499a8546aac8a46dd6128518650cfd`；其 CURRENT_ZH.md blob `397cdb2cc113022a8cd77c09dc429960c6737a92` 已含 11-24 条件 QVI 回放与两点保持下界。它不是需要重复跑的待办清单。
- default main 仍为 `732e934ba496d90fbe042b8d41d479ef901643e5`；研究栈的 merged 不等于已进 main。例：#6739 merged into integration branch，merge commit `10fb34ca4ff49e8ceb38a41cc0b018dbdf81452d` 不在该 main 中。

源链接：
[PR #7032](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/7032)、
[PR #7052](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/7052)、
[PR #6987](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/6987)。

## 2. 已有研究：不能以本轮新计划重复报为进展

| 已有对象 | 已执行/实现内容 | 限定与本轮应避免的重复 |
| --- | --- | --- |
| hcsn_network，#6754 | 两层完整确定性等待群体、signed content、task-cost 到 QVI 边界梯度；60-update synthetic；完整 PenDigits 30 fits + 30 evaluations | b1af PROTOCOL 的 `source_stage_actual_real_task_training_calls=0` 是冻结时阶段值，不能解读为今天未跑 |
| PenDigits 已封存结果 | HCSN 29.13% ±7.80%，Erlang-4 57.72% ±4.60%，普通 gate 94.00% ±0.92%；831 原文件；campaign elapsed 1143.690149883 s | 不能重用旧 attempt001、旧 test 继续调优，或重跑旧 campaign 冒充本轮新增成果 |
| hcsn_adaptive，#6835/#6853 | 独立 batch 的输入漂移、移动边界守恒 remap、Erlang phase state、19 参数 readout 的 frozen/ridge/BP/zeroth-order/coordinate-edit/edit-then-BP | 一次 BatchedFlow 是一个物理群体 + K 内容通道；K 不等于 K 个独立神经元 |
| 169 sealed configurations | P1 合成任务、P2 learner、P3 真实传感器、P4 4/8/16 宽度 SSL、TaskADV、full HX equity | input drift/boundary 未稳定优于 fixed；TaskADV 选 NoUpdate；coordinate editing 不是 WSP 程序发现 |
| hcsn_scale/model.py | ModelConfig width 1..64；SequenceModel；真实时间戳；event_mask 与 continuous_write；共享 clock 分组 batch；content feedback | width 是内容容量；已有接口不等于独立 N 群体网络，也不等于任意重采样不变 |
| uniformized_flow.py | 同有限生成元的 banded uniformization action、截断预算、无 cross-call numerical cache | 原生 FP32、roundoff 与梯度没有由 Poisson exact-arithmetic tail bound 自动证明 |
| 已有 bounded adaptation | KEEP、DirectHead、ProfileBP、JointBP、BoundedEdit；限定 feedback.projection.weight | 新 WSP 必须是明确可迁移程序，不应把 residual/ridge 坐标搜索换名 |
| 条件 QVI 编辑 | 固定 target 下直接编辑 K、锚点补偿 receiver offset；局部保持与速度计时 | 单个 anchor 的 49 个输出不等于 49 个独立保持约束；已存在 off-anchor drift 和两点不可保持下界 |

[PenDigits 完整结果](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/298fae004356f4adb5b58f2bc4d61fdde5bdab75/qualification/hcsn_network/RESULTS.md)；
[169 配置完整报告](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/6492f72ffbd3d7c477406fbabfc41e09f429324c/qualification/hcsn_adaptive/evidence/20261120-1d88/README.md)。
以上数字是所读原件的既有结果；本审查没有再次执行这些训练。

## 3. 本轮新增问题的准确表述

主协作者已经确定：构造 N=8..64 的**独立物理群体**网络，复用原保守有限群体 + phase state 算子；不是把旧内容通道的 width 从 8 改成 64 后称为 64 个独立神经元。

每个 N 应持有自己的概率/相位密度与边界；仅通过声明的连续消息耦合。允许对 B×N 做向量化，但不能在 batch/sample 或 neuron 之间混合/复制概率。每个群体概率总量各自为 1。完整状态应保留每个群体 active/refractory/escape/边界/clock 及未来推进所需反馈量。

本轮应独立注册源、数据、训练/开发/最终划分、初始权重、预算及 method mask。目标包括：

1. 真实 N 群体的端到端可训练性和内容传递。
2. 明确输入是离散 observation write、event-mask write，还是固定时间段内 continuous write rate。
3. 原生 FP32 与向量化是否在本次明确域中守恒、有限、可微，并相对 FP64 保持输出与梯度质量。
4. KEEP/BP/解析/程序编辑/hybrid 在同一任务、共同 readout mask 与成本口径下的证据。
5. 只有前述 gate 满足，才提高 N/序列长度/任务复杂度；失败保留并停止相应扩大主张。

此次有限 Erlang 网络即使通过，也不是确定性等待半直线 QVI 的自动推广。若新边界由可训练 affine/tanh control 产生，应写“learned boundary control”，不能未经 Bellman 残量、value matching 和 smooth pasting 验证就称为任务最优 free boundary。

## 4. 已知 FP32 与平滑域边界

### 已保留的负例

- adaptive 原生 FP32 predecessor 在第 217 步超过 mass conservation 3e-5（约 3.00165e-5）；mixed FP64 transport + FP32 层的 512-step control 通过，8 phases 最大质量误差约 1.46e-13。mixed 不能标成 native FP32。
- half-line CDF complement：零漂移、x=1e-9、T=1、sigma=.2，FP32 CDF 四舍五入为 1，使 1-CDF=0；真实 survival 约 3.989422570072065e-9，log survival 约 -19.3396193358。绝对 CDF 误差小不保证 tail 相对误差/梯度准确。
- HX barrier 附近，b≈64.6251766753、V=b(1+1e-9) 在 FP32 中会合为同值；后续 log1p 无法恢复已丢失的阈值侧别。保留 ambiguous 状态比虚构侧别正确。
- moving-boundary overlap、upwind flux、ReLU/abs/clip 的网格接触点是 piecewise-differentiable knot；有限差分应明确避开或单独分析，不宜声称处处 smooth-pasting。

### 本轮精度审查必须区分

- FP32 参数/输出 + FP64 state/operator 与全原生 FP32。
- Poisson 截断的精确算术上界与实际 floating-point roundoff、长期守恒、梯度误差。
- finite matrix exponential 对冻结有限过程的精确意义与原 Brownian PDE 的网格/等待时间近似误差。
- 首达 risk、重复 event count、active occupancy 以及 Erlang release，不可互当。
- frozen finite-policy Call 可为负；它并非原 He–Xiong equity call，更不是分类损失的最优 continuation value。
- UniformizedFlow 只覆写 legacy `_transport`；physical `step_physical` 经 `flow_semantics.physical_step` 另走传播。新网络若使用 physical semantics，必须检查是否真正命中了被优化的核。
- 现有 FlowConfig.max_batch≤256；把 B×N 展平时必须正确处理这项实际容量界限，而不是绕开验证或混淆 batch 轴。

## 5. 适用 AGENTS 与执行协议

已实读 b1af 根 [AGENTS.md](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/b1af67a38f8cf9cee700cc067da1e6001ce220a8/AGENTS.md)，blob `faa57cc0db48123e1011f1eb47692cd3bbbcfc3a`。

已用该源树核对：`qualification/` 没有 AGENTS 或 pyproject；hcsn_network、hcsn_adaptive、hcsn_scale、hcsn_currentstate、hcsn_training、hcsn_differentiable、hcsn_mechanism_v2、hcsn_confirmatory_v1 相关顶层/子树没有更深 AGENTS 或 pyproject。scratch 当前路径及各祖先未发现本地 AGENTS。这是适用指引核对，不是断言未来代码已完成所有测试/格式门。

适用要求：

- Python 3；不添加 `__future__` import；目前没有近层 requires-python 声明可覆盖实际 runtime 版本记录。
- 更改保持最小且可审查；非机械总改动原则≤800行，复杂逻辑阶段<500行；需要时按实际依赖拆阶段。
- 不修改 sandbox/权限环境逻辑，不触碰旧 sealed 对象。
- 根 AGENTS 的全仓修改后 `just fmt` 要求，需在最终实际可用 repo 的 `codex-rs` 目录如实执行/记录；源胶囊缺完整 Cargo/just 环境不能伪称通过。Rust 测试必须 `just test` 而非 `cargo test`；本轮只有 Python 研究，不因此要求无关全 Rust 重跑。
- 用户已授权小预算新研发运行；目前没有从这些指引发现需要额外询问用户才能做新独立 Python 实验的阻塞。

远端执行已由主协作者负责并确认 desktop Torch 2.8 CPU runtime 可用。记录单 CPU、新 idempotency key、独立目录、实际 wall/CPU/RSS/退出状态。子审查者未下任何远端训练任务。

可用 runtime 的 process_start/status/read/wait 是已暴露接口。若开始状态不明，应回查同一 job/key；不能换新 key 猜测重试。旧 N256/HPCA/controller identity 和 cost ledger 不重绑。compute-router 是可用文档化可选路线，不等于其某账户/GPU已空闲或有许可；本轮 CPU 研究不依赖它。

## 6. 导入依赖闭包与最小远端文件

机器可读清单：`audit/dependency_closure.json`。这是 AST 对所有显式 import（包括函数内 import）的静态闭包；没有替代远端实际 import smoke，也不推断运行时动态加载的外部数据。

新群体核若复用 BatchedFlow，最小上游闭包 **7 文件**：

- qualification/hcsn_adaptive/__init__.py
- qualification/hcsn_adaptive/batched_flow.py
- qualification/hcsn_adaptive/finite_control.py
- qualification/hcsn_adaptive/impulse_execution.py
- qualification/hcsn_adaptive/flow_semantics.py
- qualification/hcsn_training/__init__.py
- qualification/hcsn_training/population_generator.py

复用 UniformizedFlow 再加 `qualification/hcsn_adaptive/uniformized_flow.py`，共8文件；外部只需 Torch 和 Python 标准库。若新模块直接调用更小子集，可由最终真实 imports 进一步缩减。不要为了缩小列表丢弃非空 package initializer。

旧 SequenceModel 的静态闭包10文件，外部 NumPy/Torch；旧 deterministic FlowNetwork + task_physics + phase_forward 的闭包10文件，外部 Torch。完整路径已在 JSON。

可选旧 adaptation/readout 链仍缺 `qualification/hcsn_confirmatory_v1/semantic_program.py` 与 `qualification/hcsn_mechanism_v2/representation.py` 及它们的传递依赖；它们不在新核心闭包，不需为本轮复制。旧 PenDigits 全基线额外需要 ncps；数值 oracle 测试使用 SciPy。这些可选任务不应被误当新网络运行前提。

## 7. 新代码就绪后独立审查清单

待 model/data/protocol 落地后，只读审查以下关键风险：

- N/B/内容/空间/phase 轴与每群体守恒；输入信息是否真正进入可学习动力学。
- 源 law、两种输入写入约定与具体被调用的核一致；时间步含义及子步插值是否改变模型。
- 全部可训练参数的 graph；detach、float/item、index assignment、in-place 的梯度切断；只作离散数值决策的位置明确记录。
- 8..64 独立群体，不以内容/空间节点数替代；报告状态与 BPTT 代价。
- 精度审查与有限差分尺度；FP64 reference 同法与独立参考各自作用；保留失败。
- data train/dev/test 的生成 seed/source identity 及冻结时点；任何 test 信息是否参与 WSP 发现或超参数选择。
- 五臂共同 init、共同 trainable mask、停止规则、解析目标与 BP 正则尺度一致；解析臂只解决所声明的 convex 子问题。
- WSP 程序发现域/支持、信息输入、失败 KEEP/ABSTAIN、跨模型/未见扰动保持；构造扰动的可逆修复不是从头训练证明。
- 所有 arms 保留成本；共享 feature costs 计一次但报告摊销规则；token/LLM-discovery 计费未知不能写成0。
- 实际测试通过与效能收益通过分开；无显著优势时完整记录，不能只挑一个有利 seed/宽度或把检查点当独立样本。

本记录截至源码材料接收阶段；新模型和新实验结果尚未在本审查中验收。


## 8. 首轮新代码审查（冻结前，结论待修复后复核）

已只读审查 `model.py/data.py/protocol.json/train.py/cost.py/editing.py`。model 的独立 N 轴、保守 lower→phase0/reflection、绝对 reset 沉积、一阶 QVI 隐式反传未见直接阻塞性公式错误。尚未据此验收数值、效果或速度。

以下已发主协作者，不能在修复复核前标记通过：

| ID | 严重度 | 审查发现 | 要求 |
| --- | --- | --- | --- |
| R1 | P1 | train.source_hashes 只绑定新目录 *.py，未绑定实际 imported upstream 核 | 绑定完整依赖闭包和 Python/NumPy/Torch runtime；保持原件哈希 |
| R2 | P1 | final_test 缺 checkpoint SHA 再核对；读 test 后才逐项检查 result | 全 expected roster、身份、source、result、checkpoint 先核验，通过后才构造 test |
| R3 | P1 | state byte 只数 density/boundary | 包含 drift/cost/message 等全部动态 tensor，并单列模型、outputs、AD tape |
| R4 | P1 | 只保留 final_logits 无法独立重算 early/stopping/utility | 留存全 prefix logits、initial prefix logits、late_step 和原 labels/source/ID |
| R5 | P1 | protocol 固定72 fits，seal 要求 N=8/32/64 全部存在 | 明确 N8 后的扩大条件及 staged roster；不因seal要求被迫执行未获结果支持的大规模 |
| R6 | P2 | 失败 step 在 train_cpu 增量之前抛错会漏记该 step 成本 | finally 记录失败计算；full process 计量继续保留 |
| R7 | P2 | model/init/dev evaluation 在 fit try 外 | 初始数值失败也要有失败与费用原件，不能只有无结束结果的 started |
| R8 | 语义 | early_accuracy 是 t0 receiver 无 A 信息的时刻，不是 A 已知时0.75 Bayes性能 | 保存/报告逐样本 late_step 之前的 pre_late_accuracy；不夸大“等待”收益 |
| R9 | 语义 | 新 risk 纳入初始 refractory release 后的区间首达，区别旧 active-only 定义 | 定义为完整状态条件下区间至少一次事件概率，检查 risk≤event count |
| R10 | 语义 | 新 uniformization action 使用 dense batched matmul | 不称 banded/native sparse kernel 或已得 GPU 加速 |

editing.py 中 affine migration 的 (W'=WA^{-1}, b'=b-W'c)、输出置换方向、alias-free 原状态保留与 ABSTAIN 规则在已读源码范围内合理。须按真实模型完整声明 raw-input 分支并验全状态/输出保持。它是单列的已知 interface migration positive control，不能与 head-only 五臂混为同一参数 mask 的优势。

新合成 data 的 A/B 与标签分离、显式 cue、分组 RNG/source IDs、train/dev/test 标号隔离，在已读生成器中未见标签或 future-B 泄漏。source 是模拟参数组，未声称真实独立人体/传感器数据。完整协议是否保持隔离仍依赖后续 runner 的冻结与 test 打开顺序。

## 9. 冻结前修复与复核更新

主协作者已授权本审查者直接修改 `train.py`、`cost.py`，并新增 `protocol_tests.py`；其他协作者文件保持只读。

- R1–R4、R6–R8 已在源码层修复。训练冻结实际 AST 导入闭包，额外把执行入口 campaign 纳入根；实算得到14个逻辑模块，包含上游核，排除仍在开发的 editing/transfer/adaptation。Python、NumPy、Torch 和线程数一起绑定。
- `validate_attempts` 在共同 seal 与最终 claim/test 构造前验证完整 roster、result/protocol/source/arm/N/seed/config、history 和 checkpoint SHA/metadata。完成的 checkpoint 必须有有限初始及选中参数；setup 失败可以有具名失败记录而无 checkpoint。
- 完整状态字节包括 density、boundary、drift、cost、message。原件保留 selected/initial 的全部 prefix logits、late_step 和来源/标签/ID，足以独立复算 pre-late、stopping 和 utility。
- 失败 minibatch 的时间在 finally 计入优化 CPU；有效源码验证后的 setup/初始化/初始 dev 失败也写 result。更早的源/身份拒绝由 campaign worker 的异常及成本原件记录，并不能伪称成功 trial。
- CostMeter 标注 body 计量边界，Windows 无 resource 时 RSS 为 unavailable，macOS 的 ru_maxrss 字节换算成 KiB；完整 fresh-worker/启动到退出费用由 campaign 外层另记。
- R5 撤回：主协作者依据用户上下文澄清，门禁限制的是进一步全模态大规模扩展，本轮 N=8/32/64 是已授权的预声明研究矩阵。因此保留72正式 fits，无新增审批门。
- campaign launcher 显式给所有 worker 设置 OMP/MKL/OPENBLAS_NUM_THREADS=1；线程数与 runtime 身份检查相符。worker 记录 import-inclusive CPU 到记录时，parent 另记启动到退出 wall 与包含子进程关闭阶段的 CPU。
- `protocol_tests.py` 119行：两次独立单槽、单update fit；一次仅源哈希检查。所有 train/dev/test 请求替换成明确标记的 smoke source；它测试协议与反篡改机制，不触及正式 holdout，也不证明正式数据域独立性。实际 Torch 运行由主协作者统一完成。

### 新核的实际梯度缺陷与修复

数学协作者实际发现旧 zero-shift min/max/clamp remap 的 AD 不守恒且超出左右导数区间。已改为单一 cell CDF 的差分：lower F0、各新格 F(k+1)-F(k)、upper 1-FN 在 forward 与导数上望远镜相消。精确 knot 使用左右斜率平均0.5，是所声明的广义导数选择，不是全局光滑定理。

本审查者另指出点沉积 `relu(1-|margin-center|/h)` 在精确内部中心的可复现缺陷：bins=4、extent=2、margin=.75 时，实际一阶矩恒等于 margin，却被默认 ReLU/abs 的 knot 规则给出 AD=0。数学协作者改用同一 symmetric clip，加入一阶矩 AD=1 的专门检查。两个修改是本轮具体的新数值修复；不能将原 kernel 旧检查无条件继承给新实现。

### 五臂及迁移的交叉审查

- Ridge 的 H=XᵀX/(n·classes)+λdiag(weights,0) 与 BP 的 mean(n,classes) MSE+λΣW² 一致，bias不惩罚。
- 所有方法共享真实 selected parent、冻结特征、native parameter cast、同 readout mask。BP 使用无 line-search 的单步 L-BFGS、硬96 closure预算和最多4个非parent开发候选。
- HYBRID 已由主协作者明确同意定义为独立 ridge+开发集选择的 parent-to-ridge blends；它不是 edit-then-BP，不应在汇总中更换算法解释。
- STRICT_WSP 对未知新能力保持 ABSTAIN，已知 affine input migration/label schema 另列 positive controls。program discovery成本未测，不能填0。
- 适配层原先“candidate元数据在 test打开后才校验”的问题已经修复：全部45候选及9正式parent的完整 metadata、source/protocol、父权重digest、非head逐字节保持都提前到 FINAL_CLAIM 与 make_data 之前。源码复核未发现剩余的该类 holdout 阻塞。
- 迁移置换覆盖 sender/receiver 角色内 neuron 轴、recurrent 的三块列、全部 heterogeneous物理buffer及完整state；readout sign view 是明确wrapper，不伪称物理神经元符号对称。一个checkpoint的多view不算独立训练样本。

以上为源码审查及修复说明；正式72-fit/45-adaptation结果与速度/任务收益仍须依据随后实际原件判断。
