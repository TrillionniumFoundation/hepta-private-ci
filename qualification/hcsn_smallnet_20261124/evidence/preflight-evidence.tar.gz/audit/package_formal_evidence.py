"""Package a completed immutable run, then bind each upload to its Git blob ID."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path('/home/qian-qi/hcsn-smallnet-20261124/formal-v1')
output = Path('/home/qian-qi/hcsn-smallnet-20261124/formal-v1-archives')

def read(path):
    return json.loads(path.read_text())

training = read(root/'INDEPENDENT_METRICS_VERIFICATION.json')
adaptation = read(root/'INDEPENDENT_ADAPTATION_VERIFICATION.json')
assert len(training['rows']) == 72 and all(x['status'] == 'verified' for x in training['rows'])
assert len(adaptation['rows']) == 45 and all(x['status'] == 'verified' for x in adaptation['rows'])
assert (root/'summary/SUMMARY.json').is_file()
assert (root/'summary/RESULTS_TRAINING.md').is_file()
subprocess.run([sys.executable, str(root/'postprocess/archive_results.py'),
                '--run-root', str(root), '--output', str(output)], check=True)
index = read(output/'ARCHIVE_INDEX.json')
assert index['archive_count'] == 82
files = []
for path in sorted(output.iterdir()):
    if not path.is_file():
        continue
    data = path.read_bytes()
    row = {'file': path.name, 'bytes': len(data),
           'sha256': hashlib.sha256(data).hexdigest(),
           'git_blob_sha1': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
    if path.suffix == '.gz':
        bound = next(x for x in index['files'] if x['file'] == path.name)
        assert row['bytes'] == bound['bytes'] and row['sha256'] == bound['sha256']
    files.append(row)
manifest = {'schema': 1, 'scope': 'immutable raw archives and member index; excludes this self-referential manifest',
            'repository_prefix': 'qualification/hcsn_smallnet_20261124/evidence/archives/',
            'files': files, 'archive_count': 82,
            'total_bytes_including_index': sum(r['bytes'] for r in files)}
with (output/'GIT_PUBLICATION_MANIFEST.json').open('x') as handle:
    json.dump(manifest, handle, indent=2, sort_keys=True, allow_nan=False)
    handle.write('\n')
print(json.dumps({'files_in_manifest': len(files), 'bytes': manifest['total_bytes_including_index'],
                  'manifest_sha256': hashlib.sha256((output/'GIT_PUBLICATION_MANIFEST.json').read_bytes()).hexdigest()}))
