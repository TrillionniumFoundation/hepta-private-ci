import sys,time,json,pathlib,subprocess,concurrent.futures,os,hashlib,resource
root=pathlib.Path('/home/qian-qi/hcsn-smallnet-20261124/formal-v1');entry=time.perf_counter()
needed=[root/'training'/('SHARD_n'+str(n)+'.json') for n in (8,32,64)]+[root/'adaptation'/'LAUNCHER.json']
while not all(p.exists() for p in needed):
 if time.perf_counter()-entry>1400:raise TimeoutError('complete train/adaptation roster not available; no holdout opened')
 time.sleep(5)
import torch
torch.set_num_threads(1);sys.path.insert(0,str(root))
from qualification.hcsn_smallnet_20261124.train import load_protocol,seal,digest
from qualification.hcsn_smallnet_20261124.adaptation_suite import seal_adaptations
p=load_protocol(root/'PROTOCOL_FROZEN.json');ap=json.loads((root/'ADAPTATION_PROTOCOL_FROZEN.json').read_text())
launch=json.loads((root/'adaptation'/'LAUNCHER.json').read_text());assert len(launch['rows'])==9 and all(r['returncode']==0 for r in launch['rows'])
seal(p,root/'training');seal_adaptations(p,root/'adaptation',adaptation_protocol=ap)
opened=time.time();print(json.dumps({'stage':'both_selection_stages_sealed','training_seal':digest(root/'training'/'SEAL.json'),'adaptation_seal':digest(root/'adaptation'/'GLOBAL_ADAPTATION_SEAL.json'),'unix_time':opened}),flush=True)
base=[sys.executable,'-m'];mod='qualification.hcsn_smallnet_20261124.';jobs=[('training',base+[mod+'train','test','--manifest',str(root/'PROTOCOL_FROZEN.json'),'--output',str(root/'training')])]
for n in p['independent_neurons']:
 for s in p['seeds']:
  name=f'n{n}-qvi_full-s{s}';jobs.append((name,base+[mod+'adaptation_suite','test','--manifest',str(root/'PROTOCOL_FROZEN.json'),'--adaptation-manifest',str(root/'ADAPTATION_PROTOCOL_FROZEN.json'),'--output',str(root/'adaptation'/name),'--training-seal',str(root/'training'/'SEAL.json'),'--adaptation-seal',str(root/'adaptation'/'GLOBAL_ADAPTATION_SEAL.json')]))
logs=root/'final_test_logs';logs.mkdir(exist_ok=False)
def run(pair):
 name,command=pair;start=time.perf_counter()
 with (logs/(name+'.log')).open('x') as f:r=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
 row={'name':name,'returncode':r.returncode,'launch_through_exit_wall_seconds':time.perf_counter()-start};print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(run,jobs))
u=resource.getrusage(resource.RUSAGE_CHILDREN)
with (root/'FINAL_STAGE_RECEIPT.json').open('x') as f:json.dump({'rows':rows,'both_sealed_unix_time':opened,'wall_seconds_including_wait':time.perf_counter()-entry,'all_child_cpu_seconds':u.ru_utime+u.ru_stime,'parent_cpu_seconds':time.process_time(),'energy_joules':None,'holdout_opened_only_after_both_seals':True},f,indent=2)
sys.exit(not all(r['returncode']==0 for r in rows))
