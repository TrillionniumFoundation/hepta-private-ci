import sys,time,json,pathlib,hashlib
entry=time.perf_counter();root=pathlib.Path(sys.argv[1]);name=sys.argv[2];sys.path.insert(0,str(root))
import torch
torch.set_num_threads(1)
from qualification.hcsn_smallnet_20261124.train import load_protocol,initial_for
from qualification.hcsn_smallnet_20261124.adaptation_suite import fit_adaptation
from qualification.hcsn_smallnet_20261124.model import SmallHCSN,ModelConfig
from qualification.hcsn_smallnet_20261124.data import make_data
from qualification.hcsn_smallnet_20261124.transfer_suite import run_transfers
p=load_protocol(root/'PROTOCOL_FROZEN.json');ap=json.loads((root/'ADAPTATION_PROTOCOL_FROZEN.json').read_text());tp=json.loads((root/'TRANSFER_PROTOCOL_FROZEN.json').read_text());assert hashlib.sha256((root/'qualification/hcsn_smallnet_20261124/transfer_suite.py').read_bytes()).hexdigest()==tp['source_sha256']
parent=root/'training'/name/'checkpoint.pt';r=fit_adaptation(p,parent,root/'adaptation'/name,adaptation_protocol=ap)
ckpt=torch.load(parent,map_location='cpu',weights_only=True);model=SmallHCSN(ModelConfig(**ckpt['config']));model.load_state_dict(ckpt['selected_model']);batch=make_data(tp['input_split'],per_source=tp['per_source'],dtype=model.input_drive.weight.dtype)
tr=run_transfers(model,batch.x,lambda model,bs:initial_for(model,batch),output_path=root/'transfer'/(name+'.json'),seed=tp['seed'])
row={'attempt':name,'process_cpu_through_report_seconds':time.process_time(),'wall_including_import_seconds':time.perf_counter()-entry,'transfer_positive_pass':tr['all_positive_controls_passed'],'energy_joules':None,'program_discovery_seconds':None}
with (root/'adaptation'/name/'worker_cost.json').open('x') as h:json.dump(row,h,indent=2)
print(json.dumps(row),flush=True)