from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
source=Path("/home/qq/af52-learning-local-decision-20261111/ordinary-owner-9bfdef-native-v1/source")
records=Path("/home/qq/af52-learning-local-decision-20261111/ordinary-owner-9bfdef-caller-remote-v1")
expected_sha="9bfdef05995409a2257e3c8bd16b967fe6d013e4"
expected_tree="7d4e4bb91a762e455362a131cacaf8b827145e69"
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):
    return subprocess.check_output(["git",*args],cwd=source,text=True).strip()
def save(name,value):
    (records/name).write_text(json.dumps(value,indent=2)+"\n")
def entry(path,oid):
    raw=(source/path).read_bytes()
    computed=hashlib.sha1(f"blob {len(raw)}\0".encode()+raw).hexdigest()
    if computed!=oid:raise RuntimeError(f"source Git blob mismatch: {path}")
    return {"path":path,"blob":oid,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
try:
    sha=git("rev-parse","HEAD");tree=git("rev-parse","HEAD^{tree}");status=git("status","--porcelain")
    if sha!=expected_sha or tree!=expected_tree or status:
        raise RuntimeError(f"unexpected native source identity: {sha}/{tree}/{status!r}")
    tracked={}
    for raw in subprocess.check_output(["git","ls-tree","-rz","HEAD"],cwd=source).split(b"\0"):
        if raw:
            metadata,path=raw.split(b"\t",1)
            mode,kind,oid=metadata.decode().split()
            if kind=="blob":tracked[path.decode()]=oid
    paths=sorted(path for path in tracked if path.startswith("codex-rs/") and path.endswith(".rs"))
    actual={str(p.relative_to(source)) for p in (source/"codex-rs").rglob("*.rs")}
    if set(paths)!=actual or len(paths)!=6363:
        raise RuntimeError(f"unexpected complete Rust input set: tracked={len(paths)} actual={len(actual)}")
    files=[entry(path,tracked[path]) for path in paths]
    controls=[entry(path,tracked[path]) for path in ("CALLERS.toml","scripts/hepta_typed_callers.py","scripts/verify_hepta_callers.py")]
    before={"source_sha":sha,"source_tree":tree,"checkout":str(source),"observed_at":now(),"all_guard_rust_files":len(files),"all_guard_rust_bytes":sum(e["bytes"] for e in files),"status_porcelain":status,"scope":"Complete official caller source inputs from the actual published native checkout; read only; no pycache; independent remote attempt","files":files,"controls":controls}
    save("before.json",before)
except Exception as error:
    save("preflight-failure.json",{"observed_at":now(),"error":repr(error),"authorityGranted":False})
    raise
argv=[sys.executable,"scripts/verify_hepta_callers.py","verify"]
request={"argv":argv,"cwd":str(source),"started_at":now(),"timeout_seconds":1800,"source_sha":sha,"source_tree":tree,"environment_override":{"PYTHONDONTWRITEBYTECODE":"1"},"independent_attempt":"ordinary-owner-9bfdef-caller-remote-v1","local_attempt":"18:13:40.789233Z session48146 terminal unknown at remote admission"}
save("official-request.json",request)
env=dict(os.environ);env["PYTHONDONTWRITEBYTECODE"]="1"
with (records/"official.stdout").open("wb") as out,(records/"official.stderr").open("wb") as err:
    process=subprocess.Popen(argv,cwd=source,env=env,stdout=out,stderr=err)
    print(json.dumps({"started":request["started_at"],"source_sha":sha,"source_tree":tree,"rust_files":len(files),"official_pid":process.pid}),flush=True)
    timed_out=False
    try:rc=process.wait(timeout=1800)
    except subprocess.TimeoutExpired:
        timed_out=True;process.kill();process.wait();rc=124
finished=now()
changed=[]
for expected in files+controls:
    path=source/expected["path"]
    if not path.is_file():
        changed.append({"path":expected["path"],"missing":True});continue
    raw=path.read_bytes();actual_sha=hashlib.sha256(raw).hexdigest()
    if len(raw)!=expected["bytes"] or actual_sha!=expected["sha256"]:
        changed.append({"path":expected["path"],"bytes":len(raw),"sha256":actual_sha})
after={"observed_at":now(),"source_sha":git("rev-parse","HEAD"),"source_tree":git("rev-parse","HEAD^{tree}"),"status_porcelain":git("status","--porcelain"),"rust_files_rehashed":len(files),"changes":changed,"before_manifest_sha256":hashlib.sha256((records/"before.json").read_bytes()).hexdigest()}
save("after.json",after)
logs={}
for name in ("official.stdout","official.stderr"):
    raw=(records/name).read_bytes();logs[name]={"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
clean=not changed and not after["status_porcelain"] and after["source_sha"]==sha and after["source_tree"]==tree
result={"source_sha":sha,"source_tree":tree,"started_at":request["started_at"],"finished_at":finished,"exit":rc,"timed_out":timed_out,"source_clean_before_after":clean,"qualified_fixed_source_guard":rc==0 and not timed_out and clean,"logs":logs,"authorityGranted":False,"attempt":"ordinary-owner-9bfdef-caller-remote-v1","does_not_replace_local_unknown_attempt":True}
save("result.json",result)
print(json.dumps(result,indent=2),flush=True)
raise SystemExit(rc if rc else (0 if clean else 2))
