"""Read-only per-file diagnostics using the unchanged original caller resolver.

This is not official verification, qualification, or permission. It enumerates
every eligible file for the receiver-type boundaries that failed the retained
198947 all-boundary diagnostic. It never executes Rust or modifies source.
"""
import datetime
import hashlib
import importlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ["GIT_OPTIONAL_LOCKS"] = "0"
os.umask(0o077)
CONFIG = json.loads(sys.argv[1])
SOURCE = Path(CONFIG["source"])
WORK = Path(CONFIG["work"])
RECORDS = WORK / "records"
EXPECTED_HEAD = "19894714403a97fcd58ca8c592e75761de95687c"
EXPECTED_TREE = "8c64ab5145f279cafec363130d2a917075800e56"
EXPECTED_IDS = [
    "cell_q24_original_dataset_revalidation",
    "learning_original_source_create",
    "learning_original_q24_stage_require_current",
    "root_generation_current_bound_selection",
    "q24_task_original_ledger_open",
    "q24_task_original_ledger_readback",
    "q24_task_original_dataset_prepare",
    "q24_task_original_profile_install",
    "q24_task_explicit_delivery_sources",
    "q24_training_original_readback_construct",
    "evaluation_original_trainer_borrow",
]
EXPECTED_CONTROLS = {
    "CALLERS.toml": "b15628bc8585a76996d3532838c0a5286b2e9a7b",
    "scripts/verify_hepta_callers.py": "7a6709691c372504ca11b5d2a74e14ba819fca8f",
    "scripts/hepta_typed_callers.py": "e23bb8aa42241b429ef5dbce5a4660853b66eb2f",
}
if os.getuid() == 0 or os.geteuid() == 0:
    raise RuntimeError("the read-only diagnostic must run as the original operator")
if SOURCE.resolve() != SOURCE or WORK.resolve() != WORK:
    raise RuntimeError("absolute canonical source and new work paths required")
if SOURCE == WORK or SOURCE in WORK.parents or WORK in SOURCE.parents:
    raise RuntimeError("diagnostic output must be separate from the fixed source")
if not 300 <= CONFIG["budget_seconds"] <= 3600:
    raise RuntimeError("explicit bounded diagnostic budget required")
original_arguments = list(sys.orig_argv)
command_index = original_arguments.index("-c")
script_bytes = original_arguments[command_index + 1].encode("utf-8")
if hashlib.sha256(script_bytes).hexdigest() != CONFIG["script_sha256"]:
    raise RuntimeError("executed diagnostic script differs from its fixed source")
WORK.mkdir(mode=0o700, parents=False, exist_ok=False)
RECORDS.mkdir(mode=0o700)
(RECORDS / "diagnostic.py").write_bytes(script_bytes)
started = time.monotonic()
deadline = started + CONFIG["budget_seconds"]

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def write_record(name, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")
    path = RECORDS / name
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    directory = os.open(RECORDS, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)

def git(*arguments):
    completed = subprocess.run(
        ["/usr/bin/git", "-C", str(SOURCE), *arguments],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
        timeout=120, env=os.environ.copy(),
    )
    if completed.returncode:
        raise RuntimeError("read-only git observation failed: " +
                           completed.stderr.decode("utf-8", errors="replace"))
    return completed.stdout

def identity():
    observed = {
        "head": git("rev-parse", "HEAD").decode().strip(),
        "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
        "status": git("status", "--porcelain=v1", "--untracked-files=all").decode(),
    }
    if observed != {"head": EXPECTED_HEAD, "tree": EXPECTED_TREE, "status": ""}:
        raise RuntimeError("fixed diagnostic source identity is not clean and exact")
    return observed

def blob_id(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def file_record(relative, expected):
    path = SOURCE / relative
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise RuntimeError("diagnostic source is not a regular original file: " + relative)
    data = path.read_bytes()
    observed = blob_id(data)
    if observed != expected:
        raise RuntimeError("physical source bytes differ from the original tree: " + relative)
    return {"path": relative, "bytes": len(data), "git_blob": observed,
            "sha256": hashlib.sha256(data).hexdigest()}

def fingerprint():
    return {
        "identity": identity(),
        "rust": [file_record(name, tree_files[name]) for name in source_names],
        "controls": [file_record(name, tree_files[name]) for name in control_names],
    }

result = {
    "schema": "hepta.original-receiver-per-file-diagnostic.v1",
    "classification": "DIAGNOSTIC_ONLY_NOT_OFFICIAL_VERIFICATION",
    "source_sha": EXPECTED_HEAD, "source_tree": EXPECTED_TREE,
    "source_path": str(SOURCE), "started_at": utc(), "status": "running",
    "script_sha256": CONFIG["script_sha256"],
    "operator_uid": os.getuid(), "operator_euid": os.geteuid(),
    "python_executable": sys.executable, "python_version": sys.version,
    "official_full_verifier_executed": False, "full_callers_accepted": False,
    "native_executed": False, "authorityGranted": False,
    "boundaries": [], "driver_errors": [],
}
before = None
source_names = []
control_names = []
tree_files = {}
write_record("request.json", CONFIG)
write_record("result.json", result)
try:
    identity()
    original_path = Path(CONFIG["original_diagnostic_result"])
    original_bytes = original_path.read_bytes()
    if hashlib.sha256(original_bytes).hexdigest() != CONFIG["original_result_sha256"]:
        raise RuntimeError("retained all-boundary diagnostic result changed")
    original_result = json.loads(original_bytes)
    if (original_result["source_sha"] != EXPECTED_HEAD
            or original_result["source_tree"] != EXPECTED_TREE
            or original_result["status"] != "completed"
            or original_result["boundaries"] != 491
            or original_result["rust_count"] != 6470
            or not original_result["source_clean_before_after"]):
        raise RuntimeError("retained all-boundary diagnostic is not the fixed completed input")
    if [row["id"] for row in original_result["failures"]] != EXPECTED_IDS:
        raise RuntimeError("selected failed boundary set differs from the retained result")
    result["retained_original_result"] = {
        "path": str(original_path), "bytes": len(original_bytes),
        "sha256": CONFIG["original_result_sha256"],
        "failed_boundary_ids": EXPECTED_IDS,
    }
    for entry in git("ls-tree", "-r", "-z", "--full-tree", "HEAD").split(b"\0"):
        if not entry:
            continue
        header, path = entry.split(b"\t", 1)
        mode, kind, digest = header.decode().split()
        if kind == "blob":
            tree_files[os.fsdecode(path)] = digest
    for relative, expected in EXPECTED_CONTROLS.items():
        if tree_files.get(relative) != expected:
            raise RuntimeError("original checker/registry tree pin differs: " + relative)
        file_record(relative, expected)
    sys.path.insert(0, str(SOURCE / "scripts"))
    checker = importlib.import_module("verify_hepta_callers")
    typed = importlib.import_module("hepta_typed_callers")
    if (Path(checker.__file__).resolve() != SOURCE / "scripts/verify_hepta_callers.py"
            or Path(typed.__file__).resolve() != SOURCE / "scripts/hepta_typed_callers.py"
            or checker.authority_fields is not typed.authority_fields
            or checker.has_authority_call is not typed.has_authority_call):
        raise RuntimeError("resolver modules are not the original pinned modules")
    data = checker._load_manifest(SOURCE / "CALLERS.toml")
    source_roots = checker._string_tuple(data, "source_roots")
    ignored = checker._string_tuple(data, "ignored_path_fragments")
    paths = checker._source_files(SOURCE, source_roots)
    source_names = [path.relative_to(SOURCE).as_posix() for path in paths]
    if len(source_names) != 6470 or len(set(source_names)) != 6470:
        raise RuntimeError("original full source-index size differs")
    control_names = sorted(set(EXPECTED_CONTROLS) | {
        name for name in tree_files
        if name.startswith("scripts/") or name == "AGENTS.md"
        or name == "codex-rs/AGENTS.md"
    })
    before = fingerprint()
    write_record("before.json", before)
    source_index = {}
    for path, name in zip(paths, source_names):
        source_index[name] = checker._strip_cfg_test_items(
            checker._strip_rust_non_code(path.read_text(encoding="utf-8"))
        )
    index_digest = hashlib.sha256()
    for name, code in source_index.items():
        index_digest.update(name.encode() + b"\0" + code.encode() + b"\0")
    result["source_index"] = {
        "rust_count": len(source_index), "masked_index_sha256": index_digest.hexdigest(),
        "control_file_count": len(control_names),
        "source_roots": list(source_roots), "ignored_path_fragments": list(ignored),
    }
    all_boundaries = checker._boundary_rows(data)
    lookup = {boundary.identifier: boundary for boundary in all_boundaries}
    if len(all_boundaries) != 491:
        raise RuntimeError("original boundary count differs")
    for identifier in EXPECTED_IDS:
        if time.monotonic() >= deadline:
            raise TimeoutError("diagnostic budget reached; remaining files are not verified")
        boundary = lookup[identifier]
        if not boundary.receiver_type:
            raise RuntimeError("selected failed boundary is not receiver-typed: " + identifier)
        row = {
            "id": identifier, "receiver_type": boundary.receiver_type,
            "receiver_methods": list(boundary.receiver_methods or
                                     (boundary.symbol.rsplit("::", 1)[-1],)),
            "definition_path": boundary.definition_path,
            "expected_external_callers": list(boundary.product_callers),
            "definition_errors": [], "file_errors": [], "matched_files": [],
            "eligible_files": 0, "visited_files": 0, "skipped_definition": 0,
            "skipped_by_original_policy": 0, "status": "running",
        }
        result["boundaries"].append(row)
        definition = SOURCE / boundary.definition_path
        if not definition.is_file():
            row["definition_errors"].append("definition file is missing")
        else:
            original_definition = definition.read_text(encoding="utf-8")
            row["definition_errors"] = [
                "missing definition marker " + repr(marker)
                for marker in boundary.definition_markers
                if marker not in original_definition
            ]
        try:
            fields = checker.authority_fields(source_index, boundary.receiver_type)
        except Exception as error:
            row["status"] = "original-field-index-error"
            row["field_index_error"] = type(error).__name__ + ": " + str(error)
            write_record("result.json", result)
            print(json.dumps({"id": identifier, "field_index_error": row["field_index_error"]}),
                  flush=True)
            continue
        write_record("fields-" + identifier + ".json", {
            "aliases": sorted(fields.aliases),
            "fields": [[owner, field, value] for (owner, field), value in sorted(fields.items())],
        })
        eligible = []
        for relative in source_index:
            if relative == boundary.definition_path:
                row["skipped_definition"] += 1
            elif checker._is_ignored(relative, ignored):
                row["skipped_by_original_policy"] += 1
            else:
                eligible.append(relative)
        row["eligible_files"] = len(eligible)
        visited = []
        for relative in eligible:
            if time.monotonic() >= deadline:
                row["remaining_files"] = eligible[len(visited):]
                raise TimeoutError("diagnostic budget reached inside " + identifier)
            visited.append(relative)
            row["visited_files"] = len(visited)
            try:
                matched = any(
                    checker.has_authority_call(source_index[relative],
                                               boundary.receiver_type, method, fields)
                    for method in row["receiver_methods"]
                )
            except Exception as error:
                failure = {"path": relative, "exception_type": type(error).__name__,
                           "error": str(error)}
                row["file_errors"].append(failure)
                print(json.dumps({"id": identifier, **failure}), flush=True)
                continue
            if matched:
                row["matched_files"].append(relative)
        observed = set(row["matched_files"])
        expected = set(boundary.product_callers)
        row["missing_external_callers"] = sorted(expected - observed)
        row["unexpected_external_callers"] = sorted(observed - expected)
        row["observed_set_incomplete_if_file_errors"] = bool(row["file_errors"])
        row["visited_paths_sha256"] = hashlib.sha256("\n".join(visited).encode()).hexdigest()
        row["status"] = "diagnosed-all-eligible-files"
        write_record("result.json", result)
        print(json.dumps({"id": identifier, "visited_files": len(visited),
                          "file_errors": len(row["file_errors"]),
                          "missing": row["missing_external_callers"],
                          "unexpected": row["unexpected_external_callers"]}), flush=True)
    result["status"] = "diagnostic-completed-with-findings"
except BaseException as error:
    result["status"] = "diagnostic-incomplete"
    result["driver_errors"].append(type(error).__name__ + ": " + str(error))
    result["traceback"] = traceback.format_exc()
finally:
    if before is not None:
        try:
            after = fingerprint()
            write_record("after.json", after)
            result["source_clean_before_after"] = before == after
            if before != after:
                raise RuntimeError("full physical source fingerprints changed")
        except BaseException as error:
            result["status"] = "diagnostic-incomplete"
            result["source_clean_before_after"] = False
            result["driver_errors"].append("post-source: " + type(error).__name__ + ": " + str(error))
    diagnosed = [row["id"] for row in result["boundaries"]
                 if row["status"] == "diagnosed-all-eligible-files"]
    result["diagnosed_boundary_ids"] = diagnosed
    result["not_fully_diagnosed_boundary_ids"] = [
        identifier for identifier in EXPECTED_IDS if identifier not in diagnosed
    ]
    if result["not_fully_diagnosed_boundary_ids"]:
        result["status"] = "diagnostic-incomplete"
    result["finished_at"] = utc()
    result["duration_seconds"] = time.monotonic() - started
    result["total_file_errors"] = sum(len(row["file_errors"]) for row in result["boundaries"])
    write_record("result.json", result)
print(json.dumps({key: result[key] for key in (
    "status", "source_sha", "source_tree", "duration_seconds", "diagnosed_boundary_ids",
    "not_fully_diagnosed_boundary_ids", "total_file_errors", "driver_errors"
)}), flush=True)
raise SystemExit(0 if result["status"] == "diagnostic-completed-with-findings" else 1)
