"""Two new late-writer files against all original boundaries and full source index.
Read-only diagnostic, not official verification, native testing or authority.
"""
import datetime
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ["GIT_OPTIONAL_LOCKS"] = "0"
os.umask(0o077)
CONFIG = json.loads(sys.argv[1])
SOURCE = Path(CONFIG["source"])
WORK = Path(CONFIG["work"])
RECORDS = WORK / "records"
HEAD = "715a5726f5031e50ad963812d2a1270e8d0cf769"
TREE = "1122b8a0f3342b0944313a895b6f8838918fcddd"
TARGETS = (
    "codex-rs/hepta-agentd/src/production_launcher_late_writer.rs",
    "codex-rs/hepta-agentd/src/production_launcher_late_writer_tests.rs",
)
CONTROLS = {
    "CALLERS.toml": "7296ffa44d8bd9e8ba02a835c48dcdfa14a6641d",
    "scripts/verify_hepta_callers.py": "7a6709691c372504ca11b5d2a74e14ba819fca8f",
    "scripts/hepta_typed_callers.py": "e23bb8aa42241b429ef5dbce5a4660853b66eb2f",
}
if os.getuid() == 0 or os.geteuid() == 0:
    raise RuntimeError("operator-only read-only diagnostic")
if SOURCE.resolve() != SOURCE or WORK.resolve() != WORK:
    raise RuntimeError("canonical absolute paths required")
if SOURCE == WORK or SOURCE in WORK.parents or WORK in SOURCE.parents:
    raise RuntimeError("output must be separate from measured source")
if not 300 <= CONFIG["budget_seconds"] <= 3600:
    raise RuntimeError("bounded diagnostic budget required")
argv = list(sys.orig_argv)
script_bytes = argv[argv.index("-c") + 1].encode()
if hashlib.sha256(script_bytes).hexdigest() != CONFIG["script_sha256"]:
    raise RuntimeError("diagnostic source differs from its fixed pin")
WORK.mkdir(mode=0o700, parents=False, exist_ok=False)
RECORDS.mkdir(mode=0o700)
(RECORDS / "diagnostic.py").write_bytes(script_bytes)
started = time.monotonic()
deadline = started + CONFIG["budget_seconds"]

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def write_record(name, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    path = RECORDS / name
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    directory = os.open(RECORDS, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)

def git(*args):
    r = subprocess.run(
        ["/usr/bin/git", "-C", str(SOURCE), *args],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        timeout=120, check=False, env=os.environ.copy(),
    )
    if r.returncode:
        raise RuntimeError("read-only git failed: " + r.stderr.decode(errors="replace"))
    return r.stdout

def identity():
    value = {
        "head": git("rev-parse", "HEAD").decode().strip(),
        "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
        "status": git("status", "--porcelain=v1", "--untracked-files=all").decode(),
    }
    if value != {"head": HEAD, "tree": TREE, "status": ""}:
        raise RuntimeError("measured source is not the clean fixed source")
    return value

def file_record(name):
    path = SOURCE / name
    if not stat.S_ISREG(path.lstat().st_mode):
        raise RuntimeError("source file is not regular: " + name)
    content = path.read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()
    if blob != tree_files[name]:
        raise RuntimeError("physical source differs from fixed Git tree: " + name)
    return {"path": name, "bytes": len(content), "git_blob": blob,
            "sha256": hashlib.sha256(content).hexdigest()}

def fingerprint():
    return {
        "identity": identity(),
        "rust": [file_record(n) for n in source_names],
        "controls": [file_record(n) for n in control_names],
    }

result = {
    "schema": "hepta.original-late-writer-two-file-diagnostic.v1",
    "classification": "TWO_FILES_FULL_INDEX_PARTIAL_DIAGNOSTIC_NOT_PASS",
    "source_sha": HEAD, "source_tree": TREE, "source_path": str(SOURCE),
    "started_at": utc(), "status": "running", "target_files": list(TARGETS),
    "script_sha256": CONFIG["script_sha256"],
    "operator_uid": os.getuid(), "operator_euid": os.geteuid(),
    "python_executable": sys.executable, "python_version": sys.version,
    "official_full_verifier_executed": False, "full_callers_accepted": False,
    "native_executed": False, "authorityGranted": False,
    "boundaries": [], "driver_errors": [],
}
before = None
source_names = []
control_names = []
tree_files = {}
field_cache = {}
field_errors = {}
field_proofs = {}
write_record("request.json", CONFIG)
write_record("result.json", result)
try:
    identity()
    for item in git("ls-tree", "-r", "-z", "--full-tree", "HEAD").split(b"\0"):
        if not item:
            continue
        header, name = item.split(b"\t", 1)
        mode, kind, digest = header.decode().split()
        if kind == "blob":
            tree_files[os.fsdecode(name)] = digest
    for name, digest in CONTROLS.items():
        if tree_files.get(name) != digest:
            raise RuntimeError("original control pin mismatch: " + name)
        file_record(name)
    sys.path.insert(0, str(SOURCE / "scripts"))
    checker = importlib.import_module("verify_hepta_callers")
    typed = importlib.import_module("hepta_typed_callers")
    if (Path(checker.__file__).resolve() != SOURCE / "scripts/verify_hepta_callers.py"
            or Path(typed.__file__).resolve() != SOURCE / "scripts/hepta_typed_callers.py"
            or checker.authority_fields is not typed.authority_fields
            or checker.has_authority_call is not typed.has_authority_call):
        raise RuntimeError("resolver is not the original pinned implementation")
    manifest = checker._load_manifest(SOURCE / "CALLERS.toml")
    roots = checker._string_tuple(manifest, "source_roots")
    ignored = checker._string_tuple(manifest, "ignored_path_fragments")
    paths = checker._source_files(SOURCE, roots)
    source_names = [path.relative_to(SOURCE).as_posix() for path in paths]
    expected_names = sorted(
        n for n in tree_files if n.endswith(".rs")
        and any(n.startswith(root.rstrip("/") + "/") for root in roots)
    )
    if source_names != expected_names or len(set(source_names)) != len(source_names):
        raise RuntimeError("physical full index differs from complete tracked Rust source roots")
    if any(n not in source_names for n in TARGETS):
        raise RuntimeError("one requested actual source file is absent")
    control_names = sorted(set(CONTROLS) | {
        n for n in tree_files if n.startswith("scripts/")
        or n == "AGENTS.md" or n == "codex-rs/AGENTS.md"
    })
    before = fingerprint()
    write_record("before.json", before)
    source_index = {
        name: checker._strip_cfg_test_items(checker._strip_rust_non_code(
            path.read_text(encoding="utf-8")))
        for path, name in zip(paths, source_names)
    }
    digest = hashlib.sha256()
    for name, code in source_index.items():
        digest.update(name.encode() + b"\0" + code.encode() + b"\0")
    result["source_index"] = {
        "rust_count": len(source_index), "control_count": len(control_names),
        "masked_index_sha256": digest.hexdigest(),
        "source_roots": list(roots), "ignored_path_fragments": list(ignored),
        "matches_all_tracked_rust_paths_in_original_source_roots": True,
    }
    boundaries = checker._boundary_rows(manifest)
    if len(boundaries) != 492:
        raise RuntimeError("original fixed manifest does not have 492 boundaries")
    result["boundaries_total"] = len(boundaries)
    result["field_index_strategy"] = (
        "Original authority_fields(full fixed source_index, receiver_type), cached only "
        "for identical receiver types and identical immutable index. No target-local "
        "fields or aliases are substituted. Original has_authority_call runs for each "
        "eligible requested file and boundary using original methods and exclusions."
    )
    for number, boundary in enumerate(boundaries, 1):
        if time.monotonic() >= deadline:
            raise TimeoutError("diagnostic budget reached; remaining boundaries uncovered")
        row = {
            "index": number, "id": boundary.identifier,
            "receiver_type": boundary.receiver_type,
            "definition_path": boundary.definition_path,
            "files": [], "status": "diagnosing",
        }
        result["boundaries"].append(row)
        fields = None
        if boundary.receiver_type:
            target = boundary.receiver_type
            if target not in field_cache and target not in field_errors:
                try:
                    fields = checker.authority_fields(source_index, target)
                    field_cache[target] = fields
                    field_proofs[target] = {
                        "aliases": sorted(fields.aliases),
                        "fields": [[a, b, c] for (a, b), c in sorted(fields.items())],
                    }
                except Exception as error:
                    field_errors[target] = type(error).__name__ + ": " + str(error)
            if target in field_errors:
                row["field_index_error"] = field_errors[target]
            else:
                fields = field_cache[target]
        pattern = None
        if not boundary.receiver_type:
            pattern = re.compile(boundary.call_pattern if boundary.call_pattern is not None
                                 else re.escape(boundary.symbol) + r"\s*\(")
        for name in TARGETS:
            item = {"path": name, "listed_expected": name in boundary.product_callers}
            row["files"].append(item)
            if name == boundary.definition_path:
                item["status"] = "skipped-original-definition-policy"
                continue
            if checker._is_ignored(name, ignored):
                item["status"] = "skipped-original-ignored-policy"
                continue
            if "field_index_error" in row:
                item["status"] = "original-field-index-error"
                continue
            try:
                if boundary.receiver_type:
                    methods = boundary.receiver_methods or (
                        boundary.symbol.rsplit("::", 1)[-1],
                    )
                    matched = any(
                        checker.has_authority_call(source_index[name],
                                                   boundary.receiver_type, method, fields)
                        for method in methods
                    )
                else:
                    matched = bool(pattern.search(source_index[name]))
                item["matched"] = matched
                item["expected_selected_file_matches"] = matched == item["listed_expected"]
                item["status"] = "diagnosed"
                if not item["expected_selected_file_matches"]:
                    print(json.dumps({"id": boundary.identifier, **item}), flush=True)
            except Exception as error:
                item["status"] = "original-resolver-error"
                item["exception_type"] = type(error).__name__
                item["error"] = str(error)
                print(json.dumps({"id": boundary.identifier, **item}), flush=True)
        row["status"] = "diagnosed-requested-files"
        if number % 25 == 0 or number == len(boundaries):
            write_record("fields.json", field_proofs)
            write_record("result.json", result)
            print(json.dumps({"boundaries_diagnosed": number, "total": len(boundaries),
                              "original_full_field_indexes": len(field_cache),
                              "original_field_index_errors": len(field_errors)}), flush=True)
    result["status"] = "diagnostic-completed"
except BaseException as error:
    result["status"] = "diagnostic-incomplete"
    result["driver_errors"].append(type(error).__name__ + ": " + str(error))
    result["traceback"] = traceback.format_exc()
finally:
    if before is not None:
        try:
            after = fingerprint()
            write_record("after.json", after)
            result["source_clean_before_after"] = before == after
            if before != after:
                raise RuntimeError("full source fingerprints changed")
        except BaseException as error:
            result["status"] = "diagnostic-incomplete"
            result["source_clean_before_after"] = False
            result["driver_errors"].append("post-source: " + type(error).__name__ + ": " + str(error))
    result["completed_boundary_count"] = sum(
        row["status"] == "diagnosed-requested-files" for row in result["boundaries"])
    result["file_errors"] = [
        {"id": row["id"], **item} for row in result["boundaries"] for item in row["files"]
        if item["status"] in ("original-field-index-error", "original-resolver-error")
    ]
    result["selected_file_caller_mismatches"] = [
        {"id": row["id"], **item} for row in result["boundaries"] for item in row["files"]
        if item["status"] == "diagnosed" and not item["expected_selected_file_matches"]
    ]
    result["field_index_errors"] = field_errors
    result["field_index_count"] = len(field_cache)
    result["finished_at"] = utc()
    result["duration_seconds"] = time.monotonic() - started
    write_record("fields.json", field_proofs)
    write_record("result.json", result)
print(json.dumps({k: result[k] for k in (
    "status", "source_sha", "source_tree", "duration_seconds",
    "completed_boundary_count", "file_errors", "selected_file_caller_mismatches",
    "driver_errors"
)}), flush=True)
raise SystemExit(0 if result["status"] == "diagnostic-completed" else 1)
