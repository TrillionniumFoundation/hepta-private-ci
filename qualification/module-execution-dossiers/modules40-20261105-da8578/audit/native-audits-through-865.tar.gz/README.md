# Native evidence audit history through 86582104

This archive preserves the independent bb55, 797, 775 and final 865 audit reports,
their source/navigation reviews, the read-only 797 collection provenance, the
version-pinned final archive download provenance, authoritative runtime receipts,
and all three versions of the local native evidence auditor.

The four native checkpoint archives are separate dependencies, listed with exact
byte counts and SHA256 values in MANIFEST.json. They are not duplicated here.
The original run1 failure remains in the immutable bb55 base checkpoint history.

All 166 files staged before the final 865 audit remain byte-identical. Preparation
notes retain their historical pending status; the manifest and final audit record
the later completed result without rewriting those notes or earlier experiments.

797 was collected using independently versioned file APIs after a separate
archive request remained launch_unknown. It is explicitly not an atomic
cross-file snapshot, and its collector never replayed that archive request.
865's archive launch suffered a transport timeout; same-argument/same-key recovery
returned reused=true, and the separate archive job then had an authoritative
succeeded/exit-0 receipt. Neither event is recast as another test execution.

The final 865 Linux scope passed 1,219 cases (78 existing-profile skips), the 69
required-case audit, seven strict gates, 319 library cases, five selected AppServer
process cases, original Codespell and formatting/Clippy commands, and 28 Python
CI receipt-control cases. The latter do not establish Windows native execution.
Stable rustfmt ignores the nightly-only imports_granularity option; the original
three Clippy policies do not mean -D warnings. All production, platform,
real-provider and activation qualification boundaries remain unchanged.
