#!/usr/bin/env python3
"""Audit a pinned native checkpoint from saved bytes; never execute native tests."""
import argparse
import base64
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
import tomllib
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
for name in ['checkpoint', 'archive', 'archive-sha256', 'runtime-receipt', 'job-id',
             'source-commit', 'source-tree', 'run-label', 'wrapper-label', 'wrapper-file',
             'object-file', 'junit-sha256', 'output-dir']:
    parser.add_argument('--' + name, required=True)
parser.add_argument('--passed', type=int, default=1219)
parser.add_argument('--skipped', type=int, default=78)
parser.add_argument('--binaries', type=int, default=36)
parser.add_argument('--junit-suites', type=int, default=34)
parser.add_argument('--workspace-packages', type=int, default=193)
args = parser.parse_args()
CHECKPOINT = (ROOT / args.checkpoint).resolve()
ARCHIVE = (ROOT / args.archive).resolve()
NATIVE = CHECKPOINT / 'native'
REPRODUCTION = CHECKPOINT / 'reproduction'
OUT = (ROOT / args.output_dir).resolve()
OUT.mkdir(parents=True, exist_ok=True)
RUNTIME_PATH = ROOT / args.runtime_receipt
REMOTE = '/home/qq/work/hepta-modules40-20261105-da8578'
SOURCE = {'commit': args.source_commit, 'tree': args.source_tree, 'status': ''}
RUN = args.run_label
WRAPPER = args.wrapper_label
WRAPPER_FILE = args.wrapper_file
OBJECT_FILE = args.object_file
EXPECTED_JUNIT_SHA = args.junit_sha256
EXPECTED_PASSED = args.passed
EXPECTED_SKIPPED = args.skipped
EXPECTED_BINARIES = args.binaries
EXPECTED_JUNIT_SUITES = args.junit_suites
EXPECTED_WORKSPACE_PACKAGES = args.workspace_packages
PACKAGES = ['codex-hepta-agent-protocol', 'codex-hepta-agentd', 'codex-hepta-infer-worker-host',
            'codex-hepta-runtime', 'codex-hepta-contracts', 'codex-hepta-learning-ledger',
            'codex-hepta-supervisor']

# Helpers and core adapted from fixed bb55 auditor SHA256 971f16f1f340006c8a6515156b4471b9e49cfc6f05b2f2eb5f9badc58bf8e9c5
def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def file_record(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(data), "sha256": digest(data)}


def git_commit(data):
    return hashlib.sha1(f"commit {len(data)}\0".encode() + data).hexdigest()


def verify_receipt(name, expected_command=None):
    path = NATIVE / (name + ".json")
    record = read(path)
    require(record["exit"] == 0, f"Nonzero receipt: {name}")
    require(record["source_before"] == record["source_after"] == SOURCE, f"Source drift: {name}")
    require(record["environment_sha256"] == environment_hash, f"Environment recording mismatch: {name}")
    require(record["start_unix_ns"] < record["end_unix_ns"], f"Invalid time interval: {name}")
    require(abs((record["end_unix_ns"] - record["start_unix_ns"]) / 1e9 - record["elapsed_seconds"]) < 0.02, f"Elapsed interval mismatch: {name}")
    require(record["cwd"] in [REMOTE + "/source", REMOTE + "/source/codex-rs"], f"Unexpected working directory: {name}")
    require(record["log_path"] == REMOTE + "/evidence/" + name + ".log", f"Unexpected log binding: {name}")
    log_path = NATIVE / (name + ".log")
    log = log_path.read_bytes()
    require(len(log) == record["log_bytes"] and digest(log) == record["log_sha256"], f"Log custody mismatch: {name}")
    if expected_command is not None:
        require(record["command"] == expected_command, f"Command scope changed: {name}")
    receipts.append({"name": name, "command": record["command"], "cwd": record["cwd"],
                     "exit": record["exit"], "source_before": record["source_before"],
                     "source_after": record["source_after"], "start_unix_ns": record["start_unix_ns"],
                     "end_unix_ns": record["end_unix_ns"], "receipt": file_record(path),
                     "log": file_record(log_path)})
    return record, log.decode()


def nextest_log(text, count, skipped, binaries):
    lines = re.sub(r"\x1b\[[0-9;]*m", "", text).splitlines()
    passes = []
    slow = []
    for line in lines:
        found = re.match(r"^\s*PASS\s+\[\s*([0-9.]+)s\]\s+(\S+)\s+(.+)$", line)
        if found:
            passes.append({"target": found[2], "test": found[3], "seconds": float(found[1])})
        attempt = re.match(r"^\s*TRY\s+(\d+)\s+(\S+)\s+", line)
        if attempt:
            require(int(attempt[1]) == 1 and attempt[2] == "SLOW", f"Retry or unsuccessful attempt: {line}")
            slow.append(line.strip())
        require(not re.match(r"^\s*(FAIL|TIMEOUT|LEAK|RETRY|CANCELLED|TERMINATING)\s", line), f"Non-clean status: {line}")
    starts = [line for line in lines if re.match(r"^\s*Starting \d+ tests across \d+ binar(?:y|ies)", line)]
    summaries = [line for line in lines if re.match(r"^\s*Summary \[", line)]
    require(len(starts) == len(summaries) == 1, "Missing or repeated nextest run summary")
    require(re.search(rf"Starting {count} tests across {binaries} binar(?:y|ies)", starts[0]), "Wrong announced test scope")
    if skipped:
        require(f"({skipped} tests skipped)" in starts[0], "Starting skip count mismatch")
    match = re.fullmatch(r"\s*Summary \[\s*([0-9.]+)s\] (\d+) tests run: (\d+) passed(?: \((\d+) slow\))?, (\d+) skipped", summaries[0])
    require(match is not None, "Unexpected/non-clean nextest summary")
    require((int(match[2]), int(match[3]), int(match[5])) == (count, count, skipped), "Nextest count mismatch")
    require(len(passes) == count, "PASS-line count differs from summary")
    identities = [(p["target"], p["test"]) for p in passes]
    require(len(set(identities)) == count, "Repeated PASS identity")
    require("NEXTEST_PROFILE=local" in text and "with nextest profile: local" in text, "Original nextest local profile not observed")
    return {"count": count, "passed": count, "skipped_reported_by_runner": skipped,
            "announced_binaries": binaries, "summary": summaries[0], "seconds": float(match[1]),
            "first_attempt_slow_messages": slow, "retried_attempts": 0, "passes": passes}



archive_bytes = ARCHIVE.read_bytes()
require(digest(archive_bytes) == args.archive_sha256, 'Pinned archive digest mismatch')
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    members = archive.getmembers()
    require(all(member.isfile() for member in members), 'Non-file archive member')
    names = [member.name for member in members]
    require(len(names) == len(set(names)), 'Duplicate archive path')
    require(all(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts for name in names), 'Unsafe archive path')
    contents = {member.name: archive.extractfile(member).read() for member in members}
manifest = json.loads(contents['MANIFEST.json'])
require(manifest['source'] == SOURCE, 'Manifest source identity mismatch')
require(len(manifest['entries']) + 1 == len(contents), 'Archive/manifest count mismatch')
require({row['path'] for row in manifest['entries']} == set(contents) - {'MANIFEST.json'}, 'Archive manifest path mismatch')
for row in manifest['entries']:
    data = contents[row['path']]
    require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'Manifest custody mismatch: ' + row['path'])
    require((CHECKPOINT / row['path']).read_bytes() == data, 'Extracted bytes differ: ' + row['path'])
require((CHECKPOINT / 'MANIFEST.json').read_bytes() == contents['MANIFEST.json'], 'Extracted manifest differs')
base_archive = ROOT / 'integration/native-final-bb55-checkpoint.tar.gz'
require(digest(base_archive.read_bytes()) == '28424496bd400d6c5ff6370158f7b093355e463f19ebb550b1df6e7330504886', 'Immutable base archive changed')
require(manifest['base_evidence']['archive_sha256'] == digest(base_archive.read_bytes()), 'Base archive reference changed')
with tarfile.open(base_archive, 'r:gz') as archive:
    OLD_BOUND = json.loads(archive.extractfile('native/seven-package-run1-required-tests.69.source-bound.json').read())
preservation_path = ROOT / 'recovery/successor-candidate-audit/bb55-audit-preservation.json'
preservation = read(preservation_path)
for row in preservation['files']:
    data = (ROOT / row['path']).read_bytes()
    require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'Historical bb55 audit bytes changed: ' + row['path'])
require(len(preservation['files']) == preservation['fileCount'] == 50, 'Historical audit preservation scope changed')
runtime = read(RUNTIME_PATH)
require(runtime['job_id'] == args.job_id and runtime['state'] == 'succeeded' and runtime['exit_code'] == 0, 'Runtime job/result mismatch')
for field in ['automatic_retry', 'cancelled', 'timed_out']:
    require(runtime[field] is False, 'Runtime not clean: ' + field)
for field in ['output_complete', 'output_durable', 'terminal_publication_confirmed', 'audit_recorded']:
    require(runtime[field] is True, 'Incomplete runtime publication: ' + field)
for channel in ['stdout', 'stderr']:
    require(runtime['log_errors'][channel] is None and runtime['log_synced'][channel] is True and runtime['log_truncated'][channel] is False, 'Runtime log custody issue: ' + channel)
    require(runtime['log_bytes'][channel]['seen'] == runtime['log_bytes'][channel]['stored'], 'Runtime lost bytes: ' + channel)
independent_read_custody = None
if 'READ-CUSTODY.json' in contents:
    custody = json.loads(contents['READ-CUSTODY.json'])
    require(custody['atomic_snapshot'] is False and manifest['atomic_snapshot'] is False, 'Independent reads mislabelled atomic')
    require(digest(contents['READ-CUSTODY.json']) == manifest['read_custody_sha256'], 'Read custody digest mismatch')
    require(custody['native_execution_job'] == args.job_id, 'Read custody native job differs')
    require(len(custody['files']) == len({row['path'] for row in custody['files']}), 'Duplicate read custody file')
    for row in custody['files']:
        data = contents[row['path']]
        require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'Read custody assembled bytes differ')
        cursor = 0
        seen_small = 0
        for record_path in row['read_records']:
            record = json.loads(contents[record_path])
            if 'files' in record:
                require(record['atomic_snapshot'] is False and record['snapshot_scope'] == 'independent_file' and record['truncated'] is False, 'Small read atomic/truncation boundary differs')
                matched = [entry for entry in record['files'] if entry['path'] == row['remote_path']]
                require(len(matched) == 1, 'Small read missing/duplicate path')
                entry = matched[0]
                require(entry['text'].encode() == data and entry['version'] == row['version'] and entry['sha256'] == row['sha256'] and entry['size'] == row['bytes'] and entry['eof'], 'Small read payload/custody differs')
                seen_small += 1
            elif 'chunk_sha256' in record:
                require(record['path'] == row['remote_path'] and record['version'] == row['version'], 'Binary path/version differs')
                require(record['offset'] == cursor and record['size'] == len(data), 'Binary chunk gap or size differs')
                require(digest(data[record['offset']:record['next_offset']]) == record['chunk_sha256'], 'Binary chunk hash differs')
                require(record['eof'] == (record['next_offset'] == len(data)), 'Binary EOF differs')
                cursor = record['next_offset']
            else:
                require(record['path'] == row['remote_path'] and record['version'] == row['version'] and record['sha256'] == row['sha256'] and record['size'] == row['bytes'], 'Whole-file metadata differs')
        require((seen_small == 1 and cursor == 0) or (seen_small == 0 and cursor == len(data)), 'Incomplete/mixed read coverage')
    independent_read_custody = {'atomic_snapshot': False, 'files_verified': len(custody['files']),
                               'sha256': digest(contents['READ-CUSTODY.json']),
                               'unknown_archive_request': custody['unknown_archive_request']}
environment_hash = digest((REPRODUCTION / 'environment.json').read_bytes())
original_runner_hash = digest((REPRODUCTION / 'run-final-native.py').read_bytes())
require(original_runner_hash == '9590be884338146913ddec0fc4c0770cd2f134daf69d67c5a4a8bb14d60097eb', 'Original seven-package runner changed')
require("assert digest(runner.read_bytes()) == '" + original_runner_hash + "'" in (REPRODUCTION / f'{WRAPPER_FILE}').read_text(), 'Final runner does not pin the original seven-package runner')
checkout = read(NATIVE / f'{WRAPPER}-source-checkout.json')
require(checkout['source'] == SOURCE and checkout['environment_sha256'] == environment_hash, 'Checkout identity mismatch')
canonical_raw = base64.b64decode(checkout['raw_commit_base64'], validate=True)
require(git_commit(canonical_raw) == SOURCE['commit'] and canonical_raw.startswith(('tree ' + SOURCE['tree'] + '\n').encode()), 'Canonical raw object mismatch')
require(canonical_raw == base64.b64decode(read(REPRODUCTION / OBJECT_FILE)['commits'][0]['raw_base64']), 'Canonical checkout differs from reviewed raw object')
raw_history_count = 0
for path in (CHECKPOINT / 'native-source-history').glob('*.commit'):
    require(git_commit(path.read_bytes()) == path.stem, f'Historical raw commit identity mismatch: {path.name}')
    raw_history_count += 1
receipts = []
preflight_path = NATIVE / f'{RUN}-preflight.json'
preflight = read(preflight_path)
summary = read(NATIVE / f'{RUN}-summary.json')
require(preflight['source'] == summary['source'] == summary['source_after'] == SOURCE, 'Seven-package source identity mismatch')
require(preflight['packages'] == summary['packages'] == PACKAGES and preflight['filter_used'] is False, 'Seven-package selection mismatch')
require(preflight['original_profile'] == 'local' and preflight['required_cases'] == 69, 'Profile or required scope mismatch')
expected_test_command = ['just', 'test', '--locked'] + [item for package in PACKAGES for item in ['-p', package]] + ['--tool-config-file', 'hepta-evidence:' + REMOTE + f'/{RUN}-report-only.nextest.toml', '--cargo-metadata', REMOTE + f'/evidence/{RUN}-original-scoped-metadata.json']
require(preflight['command'] == expected_test_command, 'Seven-package command contains unexpected selection or flags')
test_receipt, main_log = verify_receipt(f'{RUN}-original-test', expected_test_command)
require(digest(preflight_path.read_bytes()) == summary['preflight_sha256'], 'Preflight summary digest mismatch')
require(digest((NATIVE / f'{RUN}-original-test.json').read_bytes()) == summary['original_test_receipt_sha256'], 'Test receipt summary digest mismatch')
require(summary['runner_exit'] == summary['audit_exit'] == 0, 'Summary runner/audit failure')
main_run = nextest_log(main_log, EXPECTED_PASSED, EXPECTED_SKIPPED, EXPECTED_BINARIES)
require(main_run['summary'] == summary['native_summary'] == manifest['final_seven_package_summary'], 'Summary text disagreement')
report_config = preflight['report_only_config']
require(digest(report_config['content'].encode()) == report_config['sha256'], 'Report-only config digest mismatch')
require(tomllib.loads(report_config['content']) == {'profile': {'local': {'junit': {'path': REMOTE + f'/evidence/{RUN}.junit.xml'}}}}, 'Reporting config changes runner behavior')
metadata_path = NATIVE / f'{RUN}-original-scoped-metadata.json'
require(digest(metadata_path.read_bytes()) == preflight['metadata']['sha256'], 'Cargo metadata digest mismatch')
require(preflight['metadata']['command'] == ['cargo', 'metadata', '--no-deps', '--format-version=1', '--locked'] and preflight['metadata']['exit'] == 0, 'Metadata producer changed')
cargo_metadata = read(metadata_path)
require(cargo_metadata['workspace_root'] == REMOTE + '/source/codex-rs' and cargo_metadata['target_directory'] == REMOTE + '/target', 'Cargo metadata workspace mismatch')
metadata_packages = {package['name']: package for package in cargo_metadata['packages']}
require(len(metadata_packages) == len(cargo_metadata['packages']) == EXPECTED_WORKSPACE_PACKAGES, 'Cargo metadata packages are duplicated or trimmed')
require(len(cargo_metadata['workspace_members']) == len(cargo_metadata['workspace_default_members']) == EXPECTED_WORKSPACE_PACKAGES, 'Cargo workspace metadata was narrowed')
for package in PACKAGES:
    require(metadata_packages[package]['id'] in cargo_metadata['workspace_members'], f'Selected package missing from metadata: {package}')
junit_path = NATIVE / f'{RUN}.junit.xml'
junit_bytes = junit_path.read_bytes()
require(len(junit_bytes) == summary['junit']['bytes'] and digest(junit_bytes) == summary['junit']['sha256'] == EXPECTED_JUNIT_SHA, 'JUnit custody mismatch')
require(summary['junit']['fresh_for_run'] is True and test_receipt['start_unix_ns'] <= summary['junit']['mtime_ns'] <= test_receipt['end_unix_ns'], 'JUnit freshness interval mismatch')
xml = ET.fromstring(junit_bytes)
tags = Counter((element.tag for element in xml.iter()))
require(tags == Counter({'testsuites': 1, 'testsuite': EXPECTED_JUNIT_SUITES, 'testcase': EXPECTED_PASSED}), 'Unexpected JUnit failure/skip/retry/output elements')
require(xml.attrib['tests'] == '1219' and xml.attrib['failures'] == xml.attrib['errors'] == '0', 'Root JUnit totals differ')
require('Nextest run ID ' + xml.attrib['uuid'] + ' with nextest profile: local' in main_log, 'JUnit run UUID/profile does not match raw log')
cases = []
suites = []
for suite in xml.findall('testsuite'):
    children = suite.findall('testcase')
    require(int(suite.attrib['tests']) == len(children), 'Suite case total mismatch')
    require(all((suite.attrib.get(key, '0') == '0' for key in ['disabled', 'failures', 'errors', 'skipped'])), 'Non-clean suite aggregate')
    suites.append({'name': suite.attrib['name'], 'tests': len(children)})
    for case in children:
        require(case.attrib['classname'] == suite.attrib['name'] and len(case) == 0, 'Conflicting target or non-clean case')
        timestamp_ns = int(datetime.fromisoformat(case.attrib['timestamp']).timestamp() * 1000000000.0)
        require(test_receipt['start_unix_ns'] <= timestamp_ns <= test_receipt['end_unix_ns'], 'Case timestamp outside producer interval')
        cases.append({'target': case.attrib['classname'], 'test': case.attrib['name'], 'seconds': float(case.attrib['time'])})
identities = [(case['target'], case['test']) for case in cases]
require(len(set(identities)) == EXPECTED_PASSED, 'Duplicate JUnit case identities')
require(set(identities) == {(case['target'], case['test']) for case in main_run['passes']}, 'JUnit cases differ from original log PASS rows')
package_counts = Counter((case['target'].split('::', 1)[0] for case in cases))
require(set(package_counts) == set(PACKAGES), 'JUnit package coverage differs from seven packages')
audit_tools = REPRODUCTION / 'audit-tools'
review_path = audit_tools / 'required-tests.69.json'
history_path = audit_tools / 'history/required-tests.with-e65.json'
bound_path = NATIVE / f'{RUN}-required-tests.69.source-bound.json'
review, history, bound = (read(review_path), read(history_path), read(bound_path))
require(digest(review_path.read_bytes()) == preflight['review_manifest_sha256'] == 'bd5fa881bf712098f23b4f2193af548b5f3b70cf99694a2704d1d9458f5717ed', 'Original 69 review manifest changed')
require(digest(history_path.read_bytes()) == 'f832236003c1937c29ba9ca3f6faeafa2dc9799664ae1069d0df78339366f56e', 'Historical 59 manifest changed')
require(review['required_tests'][:59] == history['required_tests'], 'Historical 59 rows changed')
require(bound['candidate'] == {k: SOURCE[k] for k in ['commit', 'tree']}, 'Bound candidate identity differs')
require(digest(bound_path.read_bytes()) == preflight['source_bound_manifest_sha256'], 'Source-bound manifest digest mismatch')
require(bound['schema_version'] == 2 and bound['required_count'] == len(bound['required_tests']) == len(review['required_tests']) == 69, 'Required manifest size/schema mismatch')
require(bound['review_manifest']['sha256'] == digest(review_path.read_bytes()), 'Bound review lineage differs')
require(bound['included_history_manifest']['sha256'] == digest(history_path.read_bytes()) and bound['included_history_manifest']['required_count'] == 59, 'Bound history lineage differs')
require(set(bound['packages']) == set(PACKAGES) and bound['untracked_paths_observed'] == [], 'Bound source/package scope differs')
for key in ['tracked_worktree_and_index_match_candidate', 'hidden_index_entries_rejected', 'ambient_git_variables_and_global_config_isolated', 'all_selected_source_bytes_match_committed_blobs', 'test_names_targets_and_requirements_unchanged']:
    require(bound['source_binding'][key] is True, f'Source binding check absent: {key}')
old_bound = OLD_BOUND
require(bound['runner_source_context'] == old_bound['runner_source_context'], 'Original runner/profile/toolchain/dependency context changed')
require(len(bound['runner_source_context']) == 14 and len(bound['reviewed_source_files']) == 22, 'Unexpected source binding scope')
source_files = {item['path']: item for item in bound['reviewed_source_files']}
required_results = []
for old, current in zip(review['required_tests'], bound['required_tests']):
    restored = dict(current)
    original_digest = restored.pop('review_source_snapshot_sha256')
    current_blob = restored.pop('source_git_blob')
    restored['source_snapshot_sha256'] = original_digest
    require(restored == old and original_digest == old['source_snapshot_sha256'], 'Required name/target/history changed during binding')
    source = source_files[current['source_path']]
    require(current['source_snapshot_sha256'] == source['sha256'] and current_blob == source['git_blob'], 'Required source hash differs from bound file')
    declared_targets = [target for target in metadata_packages[current['package']]['targets'] if target['name'] == current['binary'] and current['binary_kind'] in target['kind']]
    require(len(declared_targets) == 1, 'Required binary/kind missing or ambiguous in original Cargo metadata')
    require(current['binary_kind'] in ['lib', 'bin'], 'Unreviewed required binary kind')
    expected_target = current['package'] if current['binary_kind'] == 'lib' else current['package'] + '::bin/' + current['binary']
    matches = [case for case in cases if case['test'] == current['test'] and case['target'] == expected_target]
    wrong_target = [case for case in cases if case['test'] == current['test'] and case['target'] != expected_target]
    require(current['required'] is True and len(matches) == 1, f"Required test not exactly covered: {current['test']}")
    require(not wrong_target, f"Required full test name also appears in another target: {current['test']}")
    require(matches[0]['target'].split('::', 1)[0] == current['package'], 'Required package mismatch')
    required_results.append({'package': current['package'], 'binary': current['binary'], 'test': current['test'], 'target': matches[0]['target'], 'matches': 1, 'status': 'CLEAN_PASS', 'source_path': current['source_path'], 'review_source_sha256': original_digest, 'tested_source_sha256': current['source_snapshot_sha256'], 'source_git_blob': current_blob})
require(len({(r['package'], r['binary'], r['test']) for r in required_results}) == 69, 'Duplicate required identities')
reported_audit = read(NATIVE / f'{RUN}-required-tests.69.native-audit.json')
require(reported_audit['gate_result'] == 'CLEAN' and reported_audit['original_suite_exit_code'] == 0, 'Native audit not clean')
require(reported_audit['candidate_identity_supplied_by_operator'] == bound['candidate'], 'Native audit candidate differs')
require(reported_audit['required_count'] == reported_audit['required_clean_passes'] == 69 and reported_audit['observed_case_count'] == EXPECTED_PASSED, 'Native audit totals differ')
require(reported_audit['manifest']['sha256'] == digest(bound_path.read_bytes()), 'Native audit manifest differs')
require(len(reported_audit['junit_inputs']) == 1 and reported_audit['junit_inputs'][0]['sha256'] == digest(junit_bytes), 'Native audit JUnit differs')
for key in ['all_failed_cases', 'all_flaky_or_retried_cases', 'all_skipped_cases', 'aggregate_failures', 'parse_errors']:
    require(reported_audit[key] == [], f'Native audit records non-clean rows: {key}')
for ours, theirs in zip(required_results, reported_audit['required_results']):
    require(all((ours[key] == theirs[key] for key in ['package', 'binary', 'test'])), 'Native required row identity differs')
    require(theirs['status'] == 'PASS' and len(theirs['matches']) == 1 and (theirs['same_name_wrong_target'] == []), 'Native required match differs')
    require(theirs['matches'][0]['classname'] == ours['target'], 'Native required target differs')
verify_receipt(f'{RUN}-bind-manifest', ['python3', REMOTE + '/audit-tools/bind_native_audit_manifest.py', '--repo', REMOTE + '/source', '--review-manifest', REMOTE + '/audit-tools/required-tests.69.json', '--candidate-commit', SOURCE['commit'], '--candidate-tree', SOURCE['tree'], '--output', REMOTE + f'/evidence/{RUN}-required-tests.69.source-bound.json'])
verify_receipt(f'{RUN}-required-audit', ['python3', REMOTE + '/audit-tools/audit_native_junit.py', '--review-manifest', REMOTE + '/audit-tools/required-tests.69.json', '--manifest', REMOTE + f'/evidence/{RUN}-required-tests.69.source-bound.json', '--candidate-commit', SOURCE['commit'], '--candidate-tree', SOURCE['tree'], '--junit', REMOTE + f'/evidence/{RUN}.junit.xml', '--suite-exit-code', '0', '--report', REMOTE + f'/evidence/{RUN}-required-tests.69.native-audit.json'])
strict_commands = {'maps-qualification': ['python3', 'scripts/hepta-implementation-maps.py', 'verify', '--profile', 'qualification', '--expected-sha', SOURCE['commit'], '--expected-tree', SOURCE['tree']], 'status-facts': ['python3', 'scripts/test_hepta_module_status_facts.py'], 'module-registry': ['python3', 'scripts/hepta_module_registry.py', '--strict', '--pretty'], 'documents-qualification': ['python3', 'scripts/hepta-module-docs.py', 'verify', '--profile', 'qualification'], 'chef-custody': ['python3', 'scripts/test_hepta_ci_chef.py'], 'rust-ci-feedback': ['python3', 'scripts/test_hepta_rust_ci_feedback.py'], 'module-docs-metadata': ['python3', 'scripts/test_hepta_module_doc_metadata.py']}
require(summary['qualification_checks'] == {name: 0 for name in strict_commands}, 'Strict gate summary mismatch')
for name, command in strict_commands.items():
    verify_receipt(f'{RUN}-' + name, command)
scope_commands = {'original-codespell': [REMOTE + '/tools/codespell-2.4.3/bin/codespell', '--ignore-words', '.codespellignore', '--skip', './.git'], 'seven-package-original-runner': ['python3', REMOTE + '/run-final-native.py', '--candidate-commit', SOURCE['commit'], '--candidate-tree', SOURCE['tree'], '--run-label', f'{RUN}'], 'original-workspace-format': ['cargo', 'fmt', '--', '--config', 'imports_granularity=Item', '--check'], 'original-four-package-format': ['cargo', 'fmt', '--package', 'codex-utils-path', '--package', 'codex-hepta-prompt-registry', '--package', 'codex-hepta-contracts', '--package', 'codex-hepta-agentd', '--', '--check'], 'original-ci-policy-clippy': ['just', 'clippy', '--locked', '-p', 'codex-exec-server', '-p', 'codex-app-server', '-p', 'codex-app-server-client', '--', '-D', 'clippy::correctness', '-D', 'clippy::await_holding_lock', '-D', 'clippy::await_holding_invalid_type'], 'two-library-regression': ['just', 'test', '--locked', '-p', 'codex-exec-server', '-p', 'codex-app-server-client', '--lib'], 'app-server-process-regression': ['just', 'test', '--locked', '-p', 'codex-app-server', '--test', 'all', '-E', 'test(process_exec)', '--no-tests', 'fail']}
scoped_logs = {}
for name, command in scope_commands.items():
    _, scoped_logs[name] = verify_receipt(f'{WRAPPER}-' + name, command)
format_warning = "Warning: can't set `imports_granularity = Item`, unstable features are only available in nightly channel."
format_ignored_option_counts = {name: text.count(format_warning) for name, text in scoped_logs.items() if name in ['original-workspace-format', 'original-four-package-format']}
require(all((count > 0 for count in format_ignored_option_counts.values())), 'Recorded stable-rustfmt limitation changed')
two_library = nextest_log(scoped_logs['two-library-regression'], 319, 0, 2)
app_server = nextest_log(scoped_logs['app-server-process-regression'], 5, 1016, 1)
final_summary = read(NATIVE / f'{WRAPPER}-summary.json')
require(final_summary['source'] == final_summary['source_after'] == SOURCE and final_summary['checks'] == {name: 0 for name in scope_commands}, 'Final scope summary mismatch')
require(manifest['final_checks'] == final_summary['checks'], 'Archive scope summary differs')
require(max((receipt['end_unix_ns'] for receipt in receipts)) <= final_summary['complete_unix_ns'] <= runtime['at_unix_ms'] * 1000000, 'Runtime/receipt completion chronology differs')
require(runtime['at_unix_ms'] * 1000000 <= manifest['captured_unix_ns'], 'Archive preceded native terminal publication')

require(scoped_logs['original-codespell'] == '', 'Codespell successful output unexpectedly nonempty')
require("== '2.4.3'" in (REPRODUCTION / WRAPPER_FILE).read_text(), 'Wrapper does not assert pinned Codespell version')
navigation_preview = None
navigation_receipt = NATIVE / (WRAPPER + '-navigation-preview.json')
if navigation_receipt.exists():
    record, log = verify_receipt(WRAPPER + '-navigation-preview')
    require(record['command'][:2] == ['python3', REMOTE + '/refresh-navigation-explicit-pins.py'], 'Unexpected navigation helper')
    require('--apply' not in record['command'], 'Navigation preview performed a mutation')
    for flag, value in [('--root', REMOTE + '/source'), ('--expected-sha', SOURCE['commit']), ('--expected-tree', SOURCE['tree'])]:
        require(record['command'][record['command'].index(flag) + 1] == value, 'Navigation preview pin differs')
    navigation_preview = json.loads(log)
    require(navigation_preview['changedMaps'] == 0 and navigation_preview['maps'] == [], 'Nonempty navigation drift remains')
require(len(receipts) == 17 + (navigation_preview is not None), 'Unexpected audited receipt count')
paired = [case for case in cases if case['target'] == 'codex-hepta-supervisor::paired_process_product']
require({case['test'] for case in paired} == {'two_real_pairs_restart_one_without_peer_pid_churn', 'five_real_pairs_adopt_all_ten_children_and_isolate_one_matrix_crash'}, 'Paired product coverage differs')
historical_spelling = []
for label, commit, tree, exit_code in [
    ('codespell-red', 'bb55b0d7d263c396ec504c45393d938c3428dae5', '19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1', 65),
    ('codespell-code-green', 'c4863123b65f895be0eb14e0958d5cfe6c9c78bd', '81e2217141060f123adbe1da78c3dbecf57f3073', 0),
]:
    path = NATIVE / ('spelling-navigation-run1-' + label + '.json')
    if not path.exists():
        continue
    record = read(path)
    log_path = path.with_suffix('.log')
    data = log_path.read_bytes()
    expected_source = {'commit': commit, 'tree': tree, 'status': ''}
    require(record['source_before'] == record['source_after'] == expected_source and record['exit'] == exit_code, 'Historical spelling source/result changed')
    require(record['version'] == '2.4.3' and record['command'] == scope_commands['original-codespell'], 'Historical spelling scope/version changed')
    require(len(data) == record['log_bytes'] and digest(data) == record['log_sha256'], 'Historical spelling log custody mismatch')
    if exit_code == 65:
        require(b'codex-rs/hepta-infer-worker-host/src/native_output_tests.rs:82: hel ==' in data, 'Expected original Codespell failure absent')
    else:
        require(not data, 'Successful Codespell log nonempty')
    historical_spelling.append({'source': expected_source, 'exit': exit_code, 'receipt': file_record(path), 'log': file_record(log_path)})
result = {
    'schema': 'hepta.independent-native-checkpoint-audit.v2', 'status': 'CLEAN_WITHIN_RECORDED_SCOPE', 'source': SOURCE,
    'archive': {**file_record(ARCHIVE), 'members': len(contents), 'manifest_entries': len(manifest['entries']),
                'all_member_hashes_and_extracted_bytes_verified': True, 'manifest_sha256': digest(contents['MANIFEST.json']),
                'base_evidence': manifest['base_evidence'], 'independent_file_api_custody': independent_read_custody},
    'authoritative_runtime': {'receipt': file_record(RUNTIME_PATH), 'job_id': runtime['job_id'], 'state': runtime['state'],
                              'exit_code': 0, 'output_complete': True, 'output_durable': True,
                              'cancelled': False, 'timed_out': False, 'automatic_retry': False},
    'source_binding': {'canonical_raw_commit_verified': True, 'historical_raw_objects_verified': raw_history_count,
                       'bound_receipts': len(receipts), 'all_receipts_match_clean_candidate_before_and_after': True,
                       'review_manifest_sha256': digest(review_path.read_bytes()), 'historical59_manifest_sha256': digest(history_path.read_bytes()),
                       'bound_manifest_sha256': digest(bound_path.read_bytes()), 'reviewed_source_files': len(bound['reviewed_source_files']),
                       'runner_source_context_files': len(bound['runner_source_context']), 'original14_runner_contexts_unchanged': True,
                       'original_profile_observed': 'local', 'report_config_only_adds_junit_path': True,
                       'cargo_metadata_workspace_packages': len(metadata_packages), 'no_added_seven_package_filter': True,
                       'original_runner_sha256': original_runner_hash, 'wrapper_pins_original_runner': True,
                       'environment_sha256': environment_hash},
    'seven_package': {'junit': file_record(junit_path), 'original_log': file_record(NATIVE / (RUN + '-original-test.log')),
                      'run_uuid': xml.attrib['uuid'], 'junit_suites': len(suites), 'junit_testcases': len(cases),
                      'passed': EXPECTED_PASSED, 'failures': 0, 'errors': 0, 'timeouts': 0, 'retries': 0,
                      'duplicate_case_identities': 0, 'junit_skipped_elements': 0, 'runner_reported_skipped': EXPECTED_SKIPPED,
                      'skip_evidence_boundary': 'The runner reports existing-profile skips; JUnit serializes executed cases only, not the skipped identities.',
                      'summary': main_run['summary'], 'announced_binaries': EXPECTED_BINARIES,
                      'package_counts': dict(package_counts), 'suites': suites,
                      'first_attempt_slow_messages': main_run['first_attempt_slow_messages'], 'paired_product_cases': paired},
    'required': {'count': 69, 'exact_unique_clean_passes': 69, 'original59_preserved': True,
                 'required_by_package': dict(Counter(row['package'] for row in required_results)), 'cases': required_results,
                 'native_report_independently_agrees': True},
    'strict_checks': {name: 0 for name in strict_commands}, 'scope_checks': {name: 0 for name in scope_commands},
    'codespell': {'version': '2.4.3', 'original_cli': scope_commands['original-codespell'], 'exit': 0, 'empty_log': True},
    'format_policy_limit': {'ignored_unstable_option': 'imports_granularity=Item', 'warning_counts': format_ignored_option_counts,
                            'recorded_commands_exit': 0, 'nightly_imports_granularity_enforcement_established': False},
    'scoped_regressions': {'two_library': {key: value for key, value in two_library.items() if key != 'passes'},
                           'app_server_process': {key: value for key, value in app_server.items() if key != 'passes'}},
    'navigation_preview': navigation_preview, 'historical_codespell': historical_spelling,
    'receipts': receipts, 'historical_bb55_audit_files_preserved': preservation['fileCount'],
    'auditor': file_record(Path(__file__)),
    'auditor_actions': 'Read saved bytes, hash archive members, parse JSON/TOML/XML/logs; no native execution, remote command, source or ref mutation.',
    'limits': [
        'This audits the captured Linux seven-package run and explicit related scopes; it does not qualify all workspace tests or another OS/architecture.',
        'The five AppServer process_exec cases use the recorded -E expression; 1016 other cases are skipped in that scope.',
        'Clippy passes only the recorded three -D policies; this does not mean zero warnings or -D warnings.',
        'Stable rustfmt ignores imports_granularity=Item with warnings even when both original format commands return zero.',
        'Clean source-before/after receipts are not an independent concurrent-process, filesystem, physical-hardware or real-provider attestation.',
        'Historical candidates and same-tree navigation commits retain separate identities; no execution result transfers to another candidate.',
        'All production, real-provider, platform, deployment, activation and release boundaries remain unchanged.',
    ],
}
if independent_read_custody is not None:
    result['limits'].append('Files were read independently with version/hash checks. The local archive is not a cross-file atomic native snapshot, and the separately unknown archive launch was not replayed.')
def save_exact(path, data):
    if path.exists():
        require(path.read_bytes() == data, 'Existing audit artifact differs; preserve earlier result: ' + str(path))
    else:
        path.write_bytes(data)
json_path = OUT / 'FINAL-NATIVE-AUDIT.json'
save_exact(json_path, (json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode())
lines = [
    '# 固定候选原生执行独立审计', '',
    '**结论：CLEAN_WITHIN_RECORDED_SCOPE。** 这是固定 Linux 原生范围的证据核对，不是生产完成或全平台通过。', '',
    f'- 源码提交：`{SOURCE["commit"]}`；tree：`{SOURCE["tree"]}`。',
    f'- 原生任务：`{runtime["job_id"]}`，authoritative succeeded / exit 0，输出完整持久，没有外层超时、取消或自动重试。',
    f'- 七包：{EXPECTED_PASSED} 个唯一执行案例全部通过，{EXPECTED_SKIPPED} 个 runner 原配置跳过；JUnit {len(suites)} suites，{len(cases)} cases；失败、错误、超时、重试均为 0。',
    '- 69 项关键要求逐项以完整 package/binary/test 身份匹配到唯一通过案例；原 59 项历史定义保留。',
    f'- 两库回归：{two_library["count"]} passed / {two_library["skipped_reported_by_runner"]} skipped；AppServer process_exec：{app_server["count"]} passed / {app_server["skipped_reported_by_runner"]} skipped。',
    f'- 7 项严格检查、7 项 wrapper scope 检查均为 0；{len(receipts)} 份执行 receipt 的 before/after 都绑定该候选，日志长度和 SHA256 一致。',
    '- 原始 Codespell 2.4.3 CLI 通过，输出为空；没有新增 skip/ignore 参数。',
    f'- 归档：{len(contents)} files / {len(manifest["entries"])} manifest entries；SHA256 `{digest(archive_bytes)}`；所有 entry 和解压字节核对一致。',
    '', '## 必须保留的范围限制', '',
    '两个原始格式命令均返回 0，但 stable rustfmt 明确忽略 nightly 专用的 `imports_granularity=Item`。Clippy 使用三个原始 `-D` 策略，不等同于 `-D warnings`。', '',
    'JUnit 仅序列化已执行案例，78 个 profile skip 来自原始 runner 日志。AppServer 的 5 个 process_exec 案例是记录命令选择的范围，不能代表其余 1,016 个案例。', '',
    'source before/after 的干净固定 checkout 是被记录的边界，不是硬件、文件系统并发、真实 provider 或跨平台的独立证明。生产标记、DENY_ALL、真实端到端验收和激活门槛均不改变。',
]
if independent_read_custody is not None:
    lines.extend(['', '## 文件读取 custody', '',
                  f'{independent_read_custody["files_verified"]} 个远程文件逐个经只读 API 的 version、完整 SHA256 或分块 SHA256 校验；这是非原子跨文件采集。单独的归档请求曾被协调者记录为 launch_unknown，本采集没有重放该请求，也没有把它当作测试失败。'])
if historical_spelling:
    lines.extend(['', '## 历史 Codespell 配对', '',
                  '原 bb55 候选的原始 Codespell 返回 65；c486 代码候选返回 0；本候选再运行返回 0。各自保留自己的提交/tree/日志，未把历史结果移植到当前候选。'])
save_exact(OUT / 'FINAL-NATIVE-AUDIT.zh.md', ('\n'.join(lines) + '\n').encode())
audit_manifest = {'schema': 'hepta.independent-native-audit-artifacts.v1', 'source': SOURCE,
                  'inputs': {'archive': file_record(ARCHIVE), 'runtime': file_record(RUNTIME_PATH)},
                  'artifacts': [file_record(path) for path in [Path(__file__), json_path, OUT / 'FINAL-NATIVE-AUDIT.zh.md']]}
save_exact(OUT / 'FINAL-NATIVE-AUDIT-MANIFEST.json', (json.dumps(audit_manifest, ensure_ascii=False, indent=2) + '\n').encode())
print(json.dumps({'status': result['status'], 'source': SOURCE, 'passed': EXPECTED_PASSED,
                  'skipped': EXPECTED_SKIPPED, 'required_clean': 69, 'bound_receipts': len(receipts),
                  'scope_checks': len(scope_commands), 'strict_checks': len(strict_commands),
                  'audit': file_record(json_path), 'manifest': file_record(OUT / 'FINAL-NATIVE-AUDIT-MANIFEST.json')}, ensure_ascii=False))
