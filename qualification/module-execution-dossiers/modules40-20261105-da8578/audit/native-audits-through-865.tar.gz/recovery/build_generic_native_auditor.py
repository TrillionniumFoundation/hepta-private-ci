#!/usr/bin/env python3
"""Parameterize the independently reviewed bb55 auditor without altering history."""
import ast
import hashlib
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
old_path = ROOT / 'recovery/final-candidate-audit/audit_native_final.py'
old = old_path.read_text()
helpers = old[old.index('def require('):old.index('archive_metadata =')]
core = old[old.index('environment_hash ='):old.index('paired =')]
core = core.replace('read(ROOT / "integration/canonical-final-object.json")', 'read(REPRODUCTION / OBJECT_FILE)')
core = core.replace('old_bound = read(NATIVE / "seven-package-run1-required-tests.69.source-bound.json")', 'old_bound = OLD_BOUND')
core = core.replace('len(junit_bytes) == summary["junit"]["bytes"] == 280619', 'len(junit_bytes) == summary["junit"]["bytes"]')
core = core.replace('"8ef498e557bbc63e20230d66af451f1d7c97907ce7934201be171f368a185229"', 'EXPECTED_JUNIT_SHA')
core = core.replace('scope_commands = {\n', 'scope_commands = {\n    "original-codespell": [REMOTE + "/tools/codespell-2.4.3/bin/codespell", "--ignore-words", ".codespellignore", "--skip", "./.git"],\n')


class Parameters(ast.NodeTransformer):
    TOKENS = {'seven-package-run2': 'RUN', 'final-canonical-run1': 'WRAPPER',
              'run-final-canonical.py': 'WRAPPER_FILE'}
    NUMBERS = {1219: 'EXPECTED_PASSED', 78: 'EXPECTED_SKIPPED', 36: 'EXPECTED_BINARIES',
               34: 'EXPECTED_JUNIT_SUITES', 193: 'EXPECTED_WORKSPACE_PACKAGES'}

    def visit_Constant(self, node):
        if type(node.value) is int and node.value in self.NUMBERS:
            return ast.copy_location(ast.Name(id=self.NUMBERS[node.value], ctx=ast.Load()), node)
        if not isinstance(node.value, str) or not any(token in node.value for token in self.TOKENS):
            return node
        values = []
        for part in re.split('(' + '|'.join(re.escape(token) for token in self.TOKENS) + ')', node.value):
            if not part:
                continue
            if part in self.TOKENS:
                values.append(ast.FormattedValue(value=ast.Name(id=self.TOKENS[part], ctx=ast.Load()), conversion=-1))
            else:
                values.append(ast.Constant(value=part))
        return ast.copy_location(ast.JoinedStr(values=values), node)


core_ast = ast.fix_missing_locations(Parameters().visit(ast.parse(core)))
core = ast.unparse(core_ast)
prefix = '''#!/usr/bin/env python3
"""Audit a pinned native checkpoint from saved bytes; never execute native tests."""
import argparse
import base64
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
import tomllib
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
for name in ['checkpoint', 'archive', 'archive-sha256', 'runtime-receipt', 'job-id',
             'source-commit', 'source-tree', 'run-label', 'wrapper-label', 'wrapper-file',
             'object-file', 'junit-sha256', 'output-dir']:
    parser.add_argument('--' + name, required=True)
parser.add_argument('--passed', type=int, default=1219)
parser.add_argument('--skipped', type=int, default=78)
parser.add_argument('--binaries', type=int, default=36)
parser.add_argument('--junit-suites', type=int, default=34)
parser.add_argument('--workspace-packages', type=int, default=193)
args = parser.parse_args()
CHECKPOINT = (ROOT / args.checkpoint).resolve()
ARCHIVE = (ROOT / args.archive).resolve()
NATIVE = CHECKPOINT / 'native'
REPRODUCTION = CHECKPOINT / 'reproduction'
OUT = (ROOT / args.output_dir).resolve()
OUT.mkdir(parents=True, exist_ok=True)
RUNTIME_PATH = ROOT / args.runtime_receipt
REMOTE = '/home/qq/work/hepta-modules40-20261105-da8578'
SOURCE = {'commit': args.source_commit, 'tree': args.source_tree, 'status': ''}
RUN = args.run_label
WRAPPER = args.wrapper_label
WRAPPER_FILE = args.wrapper_file
OBJECT_FILE = args.object_file
EXPECTED_JUNIT_SHA = args.junit_sha256
EXPECTED_PASSED = args.passed
EXPECTED_SKIPPED = args.skipped
EXPECTED_BINARIES = args.binaries
EXPECTED_JUNIT_SUITES = args.junit_suites
EXPECTED_WORKSPACE_PACKAGES = args.workspace_packages
PACKAGES = ['codex-hepta-agent-protocol', 'codex-hepta-agentd', 'codex-hepta-infer-worker-host',
            'codex-hepta-runtime', 'codex-hepta-contracts', 'codex-hepta-learning-ledger',
            'codex-hepta-supervisor']
'''
archive_check = '''
archive_bytes = ARCHIVE.read_bytes()
require(digest(archive_bytes) == args.archive_sha256, 'Pinned archive digest mismatch')
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    members = archive.getmembers()
    require(all(member.isfile() for member in members), 'Non-file archive member')
    names = [member.name for member in members]
    require(len(names) == len(set(names)), 'Duplicate archive path')
    require(all(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts for name in names), 'Unsafe archive path')
    contents = {member.name: archive.extractfile(member).read() for member in members}
manifest = json.loads(contents['MANIFEST.json'])
require(manifest['source'] == SOURCE, 'Manifest source identity mismatch')
require(len(manifest['entries']) + 1 == len(contents), 'Archive/manifest count mismatch')
require({row['path'] for row in manifest['entries']} == set(contents) - {'MANIFEST.json'}, 'Archive manifest path mismatch')
for row in manifest['entries']:
    data = contents[row['path']]
    require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'Manifest custody mismatch: ' + row['path'])
    require((CHECKPOINT / row['path']).read_bytes() == data, 'Extracted bytes differ: ' + row['path'])
require((CHECKPOINT / 'MANIFEST.json').read_bytes() == contents['MANIFEST.json'], 'Extracted manifest differs')
base_archive = ROOT / 'integration/native-final-bb55-checkpoint.tar.gz'
require(digest(base_archive.read_bytes()) == '28424496bd400d6c5ff6370158f7b093355e463f19ebb550b1df6e7330504886', 'Immutable base archive changed')
require(manifest['base_evidence']['archive_sha256'] == digest(base_archive.read_bytes()), 'Base archive reference changed')
with tarfile.open(base_archive, 'r:gz') as archive:
    OLD_BOUND = json.loads(archive.extractfile('native/seven-package-run1-required-tests.69.source-bound.json').read())
preservation_path = ROOT / 'recovery/successor-candidate-audit/bb55-audit-preservation.json'
preservation = read(preservation_path)
for row in preservation['files']:
    data = (ROOT / row['path']).read_bytes()
    require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'Historical bb55 audit bytes changed: ' + row['path'])
require(len(preservation['files']) == preservation['fileCount'] == 50, 'Historical audit preservation scope changed')
runtime = read(RUNTIME_PATH)
require(runtime['job_id'] == args.job_id and runtime['state'] == 'succeeded' and runtime['exit_code'] == 0, 'Runtime job/result mismatch')
for field in ['automatic_retry', 'cancelled', 'timed_out']:
    require(runtime[field] is False, 'Runtime not clean: ' + field)
for field in ['output_complete', 'output_durable', 'terminal_publication_confirmed', 'audit_recorded']:
    require(runtime[field] is True, 'Incomplete runtime publication: ' + field)
for channel in ['stdout', 'stderr']:
    require(runtime['log_errors'][channel] is None and runtime['log_synced'][channel] is True and runtime['log_truncated'][channel] is False, 'Runtime log custody issue: ' + channel)
    require(runtime['log_bytes'][channel]['seen'] == runtime['log_bytes'][channel]['stored'], 'Runtime lost bytes: ' + channel)
independent_read_custody = None
if 'READ-CUSTODY.json' in contents:
    custody = json.loads(contents['READ-CUSTODY.json'])
    require(custody['atomic_snapshot'] is False and manifest['atomic_snapshot'] is False, 'Independent reads mislabelled atomic')
    require(digest(contents['READ-CUSTODY.json']) == manifest['read_custody_sha256'], 'Read custody digest mismatch')
    require(custody['native_execution_job'] == args.job_id, 'Read custody native job differs')
    require(len(custody['files']) == len({row['path'] for row in custody['files']}), 'Duplicate read custody file')
    for row in custody['files']:
        data = contents[row['path']]
        require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'Read custody assembled bytes differ')
        cursor = 0
        seen_small = 0
        for record_path in row['read_records']:
            record = json.loads(contents[record_path])
            if 'files' in record:
                require(record['atomic_snapshot'] is False and record['snapshot_scope'] == 'independent_file' and record['truncated'] is False, 'Small read atomic/truncation boundary differs')
                matched = [entry for entry in record['files'] if entry['path'] == row['remote_path']]
                require(len(matched) == 1, 'Small read missing/duplicate path')
                entry = matched[0]
                require(entry['text'].encode() == data and entry['version'] == row['version'] and entry['sha256'] == row['sha256'] and entry['size'] == row['bytes'] and entry['eof'], 'Small read payload/custody differs')
                seen_small += 1
            elif 'chunk_sha256' in record:
                require(record['path'] == row['remote_path'] and record['version'] == row['version'], 'Binary path/version differs')
                require(record['offset'] == cursor and record['size'] == len(data), 'Binary chunk gap or size differs')
                require(digest(data[record['offset']:record['next_offset']]) == record['chunk_sha256'], 'Binary chunk hash differs')
                require(record['eof'] == (record['next_offset'] == len(data)), 'Binary EOF differs')
                cursor = record['next_offset']
            else:
                require(record['path'] == row['remote_path'] and record['version'] == row['version'] and record['sha256'] == row['sha256'] and record['size'] == row['bytes'], 'Whole-file metadata differs')
        require((seen_small == 1 and cursor == 0) or (seen_small == 0 and cursor == len(data)), 'Incomplete/mixed read coverage')
    independent_read_custody = {'atomic_snapshot': False, 'files_verified': len(custody['files']),
                               'sha256': digest(contents['READ-CUSTODY.json']),
                               'unknown_archive_request': custody['unknown_archive_request']}
'''
tail = '''
require(scoped_logs['original-codespell'] == '', 'Codespell successful output unexpectedly nonempty')
require("== '2.4.3'" in (REPRODUCTION / WRAPPER_FILE).read_text(), 'Wrapper does not assert pinned Codespell version')
navigation_preview = None
navigation_receipt = NATIVE / (WRAPPER + '-navigation-preview.json')
if navigation_receipt.exists():
    record, log = verify_receipt(WRAPPER + '-navigation-preview')
    require(record['command'][:2] == ['python3', REMOTE + '/refresh-navigation-explicit-pins.py'], 'Unexpected navigation helper')
    require('--apply' not in record['command'], 'Navigation preview performed a mutation')
    for flag, value in [('--root', REMOTE + '/source'), ('--expected-sha', SOURCE['commit']), ('--expected-tree', SOURCE['tree'])]:
        require(record['command'][record['command'].index(flag) + 1] == value, 'Navigation preview pin differs')
    navigation_preview = json.loads(log)
    require(navigation_preview['changedMaps'] == 0 and navigation_preview['maps'] == [], 'Nonempty navigation drift remains')
require(len(receipts) == 17 + (navigation_preview is not None), 'Unexpected audited receipt count')
paired = [case for case in cases if case['target'] == 'codex-hepta-supervisor::paired_process_product']
require({case['test'] for case in paired} == {'two_real_pairs_restart_one_without_peer_pid_churn', 'five_real_pairs_adopt_all_ten_children_and_isolate_one_matrix_crash'}, 'Paired product coverage differs')
historical_spelling = []
for label, commit, tree, exit_code in [
    ('codespell-red', 'bb55b0d7d263c396ec504c45393d938c3428dae5', '19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1', 65),
    ('codespell-code-green', 'c4863123b65f895be0eb14e0958d5cfe6c9c78bd', '81e2217141060f123adbe1da78c3dbecf57f3073', 0),
]:
    path = NATIVE / ('spelling-navigation-run1-' + label + '.json')
    if not path.exists():
        continue
    record = read(path)
    log_path = path.with_suffix('.log')
    data = log_path.read_bytes()
    expected_source = {'commit': commit, 'tree': tree, 'status': ''}
    require(record['source_before'] == record['source_after'] == expected_source and record['exit'] == exit_code, 'Historical spelling source/result changed')
    require(record['version'] == '2.4.3' and record['command'] == scope_commands['original-codespell'], 'Historical spelling scope/version changed')
    require(len(data) == record['log_bytes'] and digest(data) == record['log_sha256'], 'Historical spelling log custody mismatch')
    if exit_code == 65:
        require(b'codex-rs/hepta-infer-worker-host/src/native_output_tests.rs:82: hel ==' in data, 'Expected original Codespell failure absent')
    else:
        require(not data, 'Successful Codespell log nonempty')
    historical_spelling.append({'source': expected_source, 'exit': exit_code, 'receipt': file_record(path), 'log': file_record(log_path)})
result = {
    'schema': 'hepta.independent-native-checkpoint-audit.v2', 'status': 'CLEAN_WITHIN_RECORDED_SCOPE', 'source': SOURCE,
    'archive': {**file_record(ARCHIVE), 'members': len(contents), 'manifest_entries': len(manifest['entries']),
                'all_member_hashes_and_extracted_bytes_verified': True, 'manifest_sha256': digest(contents['MANIFEST.json']),
                'base_evidence': manifest['base_evidence'], 'independent_file_api_custody': independent_read_custody},
    'authoritative_runtime': {'receipt': file_record(RUNTIME_PATH), 'job_id': runtime['job_id'], 'state': runtime['state'],
                              'exit_code': 0, 'output_complete': True, 'output_durable': True,
                              'cancelled': False, 'timed_out': False, 'automatic_retry': False},
    'source_binding': {'canonical_raw_commit_verified': True, 'historical_raw_objects_verified': raw_history_count,
                       'bound_receipts': len(receipts), 'all_receipts_match_clean_candidate_before_and_after': True,
                       'review_manifest_sha256': digest(review_path.read_bytes()), 'historical59_manifest_sha256': digest(history_path.read_bytes()),
                       'bound_manifest_sha256': digest(bound_path.read_bytes()), 'reviewed_source_files': len(bound['reviewed_source_files']),
                       'runner_source_context_files': len(bound['runner_source_context']), 'original14_runner_contexts_unchanged': True,
                       'original_profile_observed': 'local', 'report_config_only_adds_junit_path': True,
                       'cargo_metadata_workspace_packages': len(metadata_packages), 'no_added_seven_package_filter': True,
                       'original_runner_sha256': original_runner_hash, 'wrapper_pins_original_runner': True,
                       'environment_sha256': environment_hash},
    'seven_package': {'junit': file_record(junit_path), 'original_log': file_record(NATIVE / (RUN + '-original-test.log')),
                      'run_uuid': xml.attrib['uuid'], 'junit_suites': len(suites), 'junit_testcases': len(cases),
                      'passed': EXPECTED_PASSED, 'failures': 0, 'errors': 0, 'timeouts': 0, 'retries': 0,
                      'duplicate_case_identities': 0, 'junit_skipped_elements': 0, 'runner_reported_skipped': EXPECTED_SKIPPED,
                      'skip_evidence_boundary': 'The runner reports existing-profile skips; JUnit serializes executed cases only, not the skipped identities.',
                      'summary': main_run['summary'], 'announced_binaries': EXPECTED_BINARIES,
                      'package_counts': dict(package_counts), 'suites': suites,
                      'first_attempt_slow_messages': main_run['first_attempt_slow_messages'], 'paired_product_cases': paired},
    'required': {'count': 69, 'exact_unique_clean_passes': 69, 'original59_preserved': True,
                 'required_by_package': dict(Counter(row['package'] for row in required_results)), 'cases': required_results,
                 'native_report_independently_agrees': True},
    'strict_checks': {name: 0 for name in strict_commands}, 'scope_checks': {name: 0 for name in scope_commands},
    'codespell': {'version': '2.4.3', 'original_cli': scope_commands['original-codespell'], 'exit': 0, 'empty_log': True},
    'format_policy_limit': {'ignored_unstable_option': 'imports_granularity=Item', 'warning_counts': format_ignored_option_counts,
                            'recorded_commands_exit': 0, 'nightly_imports_granularity_enforcement_established': False},
    'scoped_regressions': {'two_library': {key: value for key, value in two_library.items() if key != 'passes'},
                           'app_server_process': {key: value for key, value in app_server.items() if key != 'passes'}},
    'navigation_preview': navigation_preview, 'historical_codespell': historical_spelling,
    'receipts': receipts, 'historical_bb55_audit_files_preserved': preservation['fileCount'],
    'auditor': file_record(Path(__file__)),
    'auditor_actions': 'Read saved bytes, hash archive members, parse JSON/TOML/XML/logs; no native execution, remote command, source or ref mutation.',
    'limits': [
        'This audits the captured Linux seven-package run and explicit related scopes; it does not qualify all workspace tests or another OS/architecture.',
        'The five AppServer process_exec cases use the recorded -E expression; 1016 other cases are skipped in that scope.',
        'Clippy passes only the recorded three -D policies; this does not mean zero warnings or -D warnings.',
        'Stable rustfmt ignores imports_granularity=Item with warnings even when both original format commands return zero.',
        'Clean source-before/after receipts are not an independent concurrent-process, filesystem, physical-hardware or real-provider attestation.',
        'Historical candidates and same-tree navigation commits retain separate identities; no execution result transfers to another candidate.',
        'All production, real-provider, platform, deployment, activation and release boundaries remain unchanged.',
    ],
}
if independent_read_custody is not None:
    result['limits'].append('Files were read independently with version/hash checks. The local archive is not a cross-file atomic native snapshot, and the separately unknown archive launch was not replayed.')
def save_exact(path, data):
    if path.exists():
        require(path.read_bytes() == data, 'Existing audit artifact differs; preserve earlier result: ' + str(path))
    else:
        path.write_bytes(data)
json_path = OUT / 'FINAL-NATIVE-AUDIT.json'
save_exact(json_path, (json.dumps(result, ensure_ascii=False, indent=2) + '\\n').encode())
lines = [
    '# 固定候选原生执行独立审计', '',
    '**结论：CLEAN_WITHIN_RECORDED_SCOPE。** 这是固定 Linux 原生范围的证据核对，不是生产完成或全平台通过。', '',
    f'- 源码提交：`{SOURCE["commit"]}`；tree：`{SOURCE["tree"]}`。',
    f'- 原生任务：`{runtime["job_id"]}`，authoritative succeeded / exit 0，输出完整持久，没有外层超时、取消或自动重试。',
    f'- 七包：{EXPECTED_PASSED} 个唯一执行案例全部通过，{EXPECTED_SKIPPED} 个 runner 原配置跳过；JUnit {len(suites)} suites，{len(cases)} cases；失败、错误、超时、重试均为 0。',
    '- 69 项关键要求逐项以完整 package/binary/test 身份匹配到唯一通过案例；原 59 项历史定义保留。',
    f'- 两库回归：{two_library["count"]} passed / {two_library["skipped_reported_by_runner"]} skipped；AppServer process_exec：{app_server["count"]} passed / {app_server["skipped_reported_by_runner"]} skipped。',
    f'- 7 项严格检查、7 项 wrapper scope 检查均为 0；{len(receipts)} 份执行 receipt 的 before/after 都绑定该候选，日志长度和 SHA256 一致。',
    '- 原始 Codespell 2.4.3 CLI 通过，输出为空；没有新增 skip/ignore 参数。',
    f'- 归档：{len(contents)} files / {len(manifest["entries"])} manifest entries；SHA256 `{digest(archive_bytes)}`；所有 entry 和解压字节核对一致。',
    '', '## 必须保留的范围限制', '',
    '两个原始格式命令均返回 0，但 stable rustfmt 明确忽略 nightly 专用的 `imports_granularity=Item`。Clippy 使用三个原始 `-D` 策略，不等同于 `-D warnings`。', '',
    'JUnit 仅序列化已执行案例，78 个 profile skip 来自原始 runner 日志。AppServer 的 5 个 process_exec 案例是记录命令选择的范围，不能代表其余 1,016 个案例。', '',
    'source before/after 的干净固定 checkout 是被记录的边界，不是硬件、文件系统并发、真实 provider 或跨平台的独立证明。生产标记、DENY_ALL、真实端到端验收和激活门槛均不改变。',
]
if independent_read_custody is not None:
    lines.extend(['', '## 文件读取 custody', '',
                  f'{independent_read_custody["files_verified"]} 个远程文件逐个经只读 API 的 version、完整 SHA256 或分块 SHA256 校验；这是非原子跨文件采集。单独的归档请求曾被协调者记录为 launch_unknown，本采集没有重放该请求，也没有把它当作测试失败。'])
if historical_spelling:
    lines.extend(['', '## 历史 Codespell 配对', '',
                  '原 bb55 候选的原始 Codespell 返回 65；c486 代码候选返回 0；本候选再运行返回 0。各自保留自己的提交/tree/日志，未把历史结果移植到当前候选。'])
save_exact(OUT / 'FINAL-NATIVE-AUDIT.zh.md', ('\\n'.join(lines) + '\\n').encode())
audit_manifest = {'schema': 'hepta.independent-native-audit-artifacts.v1', 'source': SOURCE,
                  'inputs': {'archive': file_record(ARCHIVE), 'runtime': file_record(RUNTIME_PATH)},
                  'artifacts': [file_record(path) for path in [Path(__file__), json_path, OUT / 'FINAL-NATIVE-AUDIT.zh.md']]}
save_exact(OUT / 'FINAL-NATIVE-AUDIT-MANIFEST.json', (json.dumps(audit_manifest, ensure_ascii=False, indent=2) + '\\n').encode())
print(json.dumps({'status': result['status'], 'source': SOURCE, 'passed': EXPECTED_PASSED,
                  'skipped': EXPECTED_SKIPPED, 'required_clean': 69, 'bound_receipts': len(receipts),
                  'scope_checks': len(scope_commands), 'strict_checks': len(strict_commands),
                  'audit': file_record(json_path), 'manifest': file_record(OUT / 'FINAL-NATIVE-AUDIT-MANIFEST.json')}, ensure_ascii=False))
'''
source = prefix + '\n# Helpers and core adapted from fixed bb55 auditor SHA256 ' + hashlib.sha256(old_path.read_bytes()).hexdigest() + '\n' + helpers + archive_check + core + '\n' + tail
ast.parse(source)
path = ROOT / 'recovery/audit_native_checkpoint.py'
if path.exists():
    assert path.read_text() == source, 'Do not overwrite a different existing auditor.'
else:
    path.write_text(source)
print(path, hashlib.sha256(source.encode()).hexdigest(), len(source.encode()))
