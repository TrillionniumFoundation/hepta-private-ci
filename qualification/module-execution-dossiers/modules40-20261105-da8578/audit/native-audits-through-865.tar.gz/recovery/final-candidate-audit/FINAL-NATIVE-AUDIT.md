# bb55 最终原生证据独立审计

**结论：`CLEAN_WITHIN_RECORDED_SCOPE`。** 本次独立复核确认，固定 bb55 源码的七包原始原生运行记录为 **1219 passed、78 skipped、exit 0**；69 个必要用例全部以完整测试名和正确目标精确命中一次，原始日志及 JUnit 中没有失败、错误、超时或重试。7 项资格检查和 6 个相关执行 scope 的回执均为 0，所有审计的 16 份命令回执在执行前后都绑定同一干净源码。

该结论只覆盖下列源码和运行身份。它不将既有或后续候选、同 tree 的其他 commit、GitHub Actions 平台任务、真实 provider 接入、部署或 production activation 判定为通过。

## 1. 固定身份与归档完整性

| 项目 | 已核验值 |
| --- | --- |
| Canonical commit | `bb55b0d7d263c396ec504c45393d938c3428dae5` |
| Canonical tree | `19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1` |
| 原生工作区状态 | 每份相关执行前后记录均为 `status: ""` |
| 测试 runtime job | `1a1ac64b60d-fc05-5402` |
| Launch nonce | `9ade45875c357e81f3f38053bfcf1ce1` |
| Authoritative runtime | `succeeded` / `exit_code: 0` |
| 原始归档 | `integration/native-final-bb55-checkpoint.tar.gz` |
| 归档大小 | 1,026,914 bytes |
| 归档 SHA-256 | `28424496bd400d6c5ff6370158f7b093355e463f19ebb550b1df6e7330504886` |
| 归档成员 | 201 个普通文件，含 `MANIFEST.json` 和其精确覆盖的 200 个条目 |
| MANIFEST SHA-256 | `a707b3c7e8a10a0ef3aab290bc65ed208a3946e6492f2715d34b02345dae402d` |

独立重算了归档字节数及摘要、每个成员的字节数和摘要，并比较归档内容与 `integration/final-native-checkpoint/` 的解包字节。成员没有重复、绝对路径或 `..` 路径，也没有解包后额外文件。canonical checkout 中的原始 commit 对象经 Git commit 对象算法重算得到上述 bb55 SHA，且其 tree 与前述 canonical 元数据一致。

runtime 原始回执为 `integration/runtime-receipts/final-canonical-bb55-runtime-status.json`，SHA-256 为 `7756f161e9fe2efcfb37dce0440379454b59c40491f57ddbe366e4a85a722d20`。其状态与归档元数据逐项一致：输出完整且持久化、终态已发布、未取消、未超时、没有 automatic retry；stdout/stderr 的 seen/stored 字节相同，没有截断或日志错误。所有命令回执终止时间早于 runtime 终态，归档捕获又晚于该终态。

这项时间和摘要核验提供已保存记录的对应关系；它不是独立硬件、执行机器或文件系统的远程证明。

## 2. 七包原始运行与 JUnit 的逐项对应

本节原始证据均位于 `integration/final-native-checkpoint/native/`，主要文件为 `seven-package-run2-original-test.{json,log}`、`seven-package-run2.junit.xml`、`seven-package-run2-preflight.json`、`seven-package-run2-original-scoped-metadata.json` 和 `seven-package-run2-summary.json`。

| 量项 | 独立解析结果 |
| --- | ---: |
| Nextest 公告 binaries | 36 |
| JUnit suites | 34 |
| JUnit testcase / 原始日志独立 PASS 行 | 1219 / 1219 |
| Passed | 1219 |
| Failure / error / timeout / retry | 0 / 0 / 0 / 0 |
| 重复 testcase 身份 | 0 |
| Nextest 原始 summary 的 skipped | 78 |
| JUnit 内的 skipped 元素 | 0 |
| Nextest 运行时间 | 36.626 秒 |
| Run UUID | `c10a4d3a-f5bb-4086-afa8-9f305a351d6f` |

JUnit 的 1219 个 `(classname, test name)` 与原始日志中 1219 个 PASS 行的 `(target, test name)` 完全相等。逐 suite 计数与顶层计数一致；每个 testcase 时间戳都在原命令起止时间之内。JUnit 本身只序列化实际执行用例，因此 **78 个跳过来自原始 Nextest 日志，不能因 JUnit 没有 skipped 元素便声称未跳过任何用例**。36 个公告 binary 与 34 个实际有序列化 testcase 的 suite 是不同量项。

| Package | 实际 passed | 必要清单精确命中 |
| --- | ---: | ---: |
| `codex-hepta-agent-protocol` | 14 | 3 |
| `codex-hepta-agentd` | 624 | 15 |
| `codex-hepta-contracts` | 259 | 0 |
| `codex-hepta-infer-worker-host` | 59 | 40 |
| `codex-hepta-learning-ledger` | 125 | 5 |
| `codex-hepta-runtime` | 16 | 3 |
| `codex-hepta-supervisor` | 122 | 3 |
| **合计** | **1219** | **69** |

`contracts` 虽没有额外列入 69 条专门恢复清单，仍在七包原始执行范围内，259 个实际用例已经执行。

原始 summary 为：

```text
Summary [  36.626s] 1219 tests run: 1219 passed (1 slow), 78 skipped
```

唯一的 `TRY 1 SLOW` 是 Agentd 的 `runtime::hos2_recovery_tests::actual_reconciler_asks_original_issuer_for_same_k_d_and_does_not_resend_unknown`，最终在首次尝试以 35.540 秒通过。这是首次运行的慢测试提示；既没有 `TRY 2`，也没有 JUnit 的失败后重跑或 flaky 元素。

两个先前暴露失败/超时的真实进程用例，在本次固定运行中分别为：

| `codex-hepta-supervisor::paired_process_product` 用例 | 结果 |
| --- | --- |
| `two_real_pairs_restart_one_without_peer_pid_churn` | 首次 PASS，8.529 秒 |
| `five_real_pairs_adopt_all_ten_children_and_isolate_one_matrix_crash` | 首次 PASS，23.667 秒 |

| 文件 | bytes | SHA-256 |
| --- | ---: | --- |
| `seven-package-run2-original-test.log` | 200560 | `b5c3027e22467c27ff78992502db389f9aa5b44a35780a136b27595bedb464f3` |
| `seven-package-run2.junit.xml` | 280619 | `8ef498e557bbc63e20230d66af451f1d7c97907ce7934201be171f368a185229` |

## 3. 原 runner/profile、69 条清单与源码绑定

七包命令是原 `just test --locked`，逐项选择前述七包，仅附加报告用 `--tool-config-file` 和预先生成的完整 `--cargo-metadata`。该命令没有新增 `-E`、测试名 filter 或 timeout/retry/profile 覆盖。报告配置经 TOML 解析后只有 `[profile.local.junit]` 的输出路径。原始日志明确显示 `NEXTEST_PROFILE=local` 以及 `nextest profile: local`。

Cargo metadata 的生产命令仍为 `cargo metadata --no-deps --format-version=1 --locked`，193 个 workspace package/member/default member 都在，未裁切成七包替代 workspace。原始七包 runner 的 SHA-256 为 `9590be884338146913ddec0fc4c0770cd2f134daf69d67c5a4a8bb14d60097eb`；最终 canonical runner 在调用前以该摘要约束它。

独立审计保留 59 条历史清单的原始行及历史 source snapshot 摘要，再检查新增 10 条形成的 69 条清单；未用当前摘要覆盖历史摘要。绑定器在当前 source 字段之外另存 `review_source_snapshot_sha256`，恢复该字段后与原 review 行逐字典相等。22 个受审源码文件、14 个 runner/profile/toolchain/dependency context 文件均被记录；14 个 context 条目与 run1 完全相同。

| 文件/身份 | SHA-256 |
| --- | --- |
| 原 `required-tests.69.json` | `bd5fa881bf712098f23b4f2193af548b5f3b70cf99694a2704d1d9458f5717ed` |
| 原 59 条 `history/required-tests.with-e65.json` | `f832236003c1937c29ba9ca3f6faeafa2dc9799664ae1069d0df78339366f56e` |
| 本次 source-bound 69 manifest | `f0cdccd55d9b8e01df324d97ce8d2e50f150185ba74c3fd6dc2cae56f82db61b` |

每条必要用例使用完整名称及准确的 nextest target 匹配，不使用叶名称或模糊后缀。68 条是 library target；唯一 executable unit target `hepta-infer-worker` 在 Cargo metadata 中确认为 `bin`，对应 JUnit 的 `codex-hepta-infer-worker-host::bin/hepta-infer-worker`。69 条全部匹配一次，没有同名错 target 匹配。Ledger 的 `production::reconciliation::tests::...` 及 supervisor 的 `writer_handoff::journal_file::tests::...` 均按完整路径核验。

独立结果与已归档 native audit 的 `CLEAN`、69 required / 69 clean passes、1219 observed、空 failed/flaky/retried/parse-error 集合一致。bound manifest 自身仍保留“绑定完成、尚未由绑定器建立测试执行”的阶段字段；测试事实来自其后对应的原始运行回执、日志和 JUnit。该阶段字段没有被倒填成测试通过。

source-bound manifest 中的 clean checkout、无 hidden index 绕过、隔离 ambient Git、源码匹配 committed blob、名称/target/requirements 不变等记录均为真，和本次 canonical 身份一致。本审计验证保存记录及其摘要/身份一致性，没有重新在远端执行绑定器或测试。

## 4. 七项资格检查

下列每条保存的原命令回执都为 **exit 0**，其 source_before 与 source_after 都是第 1 节的 bb55 / tree19116 / clean。逐条检查了 command、cwd、environment 摘要、时间区间、日志字节数和 SHA-256；完整 command 与 receipt/hash 清单在 `FINAL-NATIVE-AUDIT.json`。

| 检查 | 保存的原命令主体 |
| --- | --- |
| Maps qualification | `python3 scripts/hepta-implementation-maps.py verify --profile qualification --expected-sha bb55b0d7d263c396ec504c45393d938c3428dae5 --expected-tree 19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1` |
| Status facts | `python3 scripts/test_hepta_module_status_facts.py` |
| Module registry | `python3 scripts/hepta_module_registry.py --strict --pretty` |
| Documents qualification | `python3 scripts/hepta-module-docs.py verify --profile qualification` |
| Chef custody | `python3 scripts/test_hepta_ci_chef.py` |
| Rust CI feedback | `python3 scripts/test_hepta_rust_ci_feedback.py` |
| Module docs metadata | `python3 scripts/test_hepta_module_doc_metadata.py` |

## 5. 六个 final-canonical scope

六个 scope 也全部 **exit 0**，执行前后均绑定同一 bb55 / tree19116 / clean。它们包含前述七包 runner 的外层回执，不应将该外层回执视为又运行一次七包。

| Scope | 原命令与已建立范围 |
| --- | --- |
| Seven-package original runner | `python3 /home/qq/work/hepta-modules40-20261105-da8578/run-final-native.py --candidate-commit bb55b0d7d263c396ec504c45393d938c3428dae5 --candidate-tree 19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1 --run-label seven-package-run2` |
| Original workspace format | `cargo fmt -- --config imports_granularity=Item --check` |
| Original four-package format | `cargo fmt --package codex-utils-path --package codex-hepta-prompt-registry --package codex-hepta-contracts --package codex-hepta-agentd -- --check` |
| Original CI policy Clippy | `just clippy --locked -p codex-exec-server -p codex-app-server -p codex-app-server-client -- -D clippy::correctness -D clippy::await_holding_lock -D clippy::await_holding_invalid_type` |
| Two-library regression | `just test --locked -p codex-exec-server -p codex-app-server-client --lib`；**319 passed、0 skipped**，两 binary，45.032 秒 |
| App-server process regression | `just test --locked -p codex-app-server --test all -E test(process_exec) --no-tests fail`；**5 passed、1016 skipped**，一 binary，0.898 秒 |

两库原始日志的 319 个唯一 PASS 行与 summary 一致，没有失败或重试。`tests::next_event_surfaces_lagged_markers` 的 `TRY 1 SLOW` 后以 45.030 秒首次通过。App-server scope 则明确使用原 `test(process_exec)` filter，仅证明五个选中用例，不能据此声称全量 app-server 测试通过。

两项格式命令返回 0，但 stable rustfmt 日志明确警告 `imports_granularity=Item` 属于 nightly 专用选项而被忽略；workspace scope 记录该提示 426 次，四包 scope 29 次。因此只报告原命令成功返回，不将该 nightly 规则描述为已被执行。Clippy 证明的是表内三个 `-D` lint policy；日志保留其他 warning，不据此声称 `-D warnings` 或全 workspace Clippy 通过。

## 6. 历史证据、导航报告与结果界限

`integration/run1-checkpoint/native/` 的 78 个原始文件与最终归档对应路径逐字节相同。旧 run1 的 runner exit 100 和 audit `NOT_CLEAN` 仍然保留。本次新结果没有修改先前失败记录。

同目录既有 `PRELIMINARY-NAVIGATION-AUDIT.md`、`navigation-audit-results.json` 和 `final40-blobs.json` 的原始摘要保持不变。该先前审计记录了 40 个 module 的历史 sourceBase/claimBoundary、371 operations 语义不变、production 全 false，以及 baseline → 原 9 张更新 → 最终 11 张更新的三层重建与旧 ledger 保留。本报告新增原生证据结论，不回写 PRELIMINARY 当时“原生尚待核验”的历史状态。

canonical bb55 与导航导出的 native `8ab12f162b659a209a87f3254fe87cb07f4c07e8` 同 tree，身份仍各自独立。当前结果由 bb55 上新执行的回执建立，不能来自另一个同 tree commit 的历史通过结果。后续候选也必须分别建立源码绑定和执行结果。

**范围限制：** 本报告核验 Linux 原生七包及明确列出的相关 scope。它不证明全部 193 package 的测试通过、其他 OS/架构通过、GitHub Actions 全绿、完整 Agentd 持久恢复闭环、真实 provider 配额/硬件/权重验收、production writer composition、独立 custody 批准链或产品 activation。公开 API 的历史 receipt 仍不构成当前授权；没有由这份审计赋予任何 production 状态。

## 7. 可复核产物

- `FINAL-NATIVE-AUDIT.json`：完整机器可读结果，69 条逐条匹配、34 suite 计数、16 份命令/日志绑定及限制。
- `audit_native_final.py`：仅用本地保存文件重算摘要并解析 JSON/TOML/XML/原始日志；不调用 subprocess、网络、远端测试或 refs 操作。
- `FINAL-NATIVE-AUDIT-MANIFEST.json`：本轮新审计文件摘要及原始输入引用。
- `PRELIMINARY-NAVIGATION-AUDIT.md` 与其原 JSON：原先已冻结的源码/导航审计，未覆盖。

本地复核入口：

```bash
python3 /workspace/scratch/da8578abae00/recovery/final-candidate-audit/audit_native_final.py
```

该入口仅重新解析已保存证据。若已有 FINAL JSON，它要求重新生成的字节完全相同，不覆盖不同结果。
