#!/usr/bin/env python3
"""Audit saved navigation evidence; never access a source checkout or remote."""

import base64
import copy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile
from datetime import datetime, timezone


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
INTEGRATION = ROOT / "integration"
BASE = INTEGRATION / "navigation-baseline"
OLD_LEDGER = "qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history.json"
NEW_LEDGER = "qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history-final.json"
CANONICAL = "bb55b0d7d263c396ec504c45393d938c3428dae5"
FINAL_TREE = "19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1"


def load(path):
    return json.loads(path.read_bytes())


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git_hash(kind, data):
    return hashlib.sha1(f"{kind} {len(data)}\0".encode() + data).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def write_exact(path, data):
    if path.exists():
        require(path.read_bytes() == data, f"Existing audit output differs: {path}")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)


def diff_paths(a, b, path=""):
    if type(a) is not type(b):
        return [path]
    if isinstance(a, dict):
        return [p for k in sorted(a.keys() | b.keys()) for p in
                ([path + "/" + k] if k not in a or k not in b else
                 diff_paths(a[k], b[k], path + "/" + k))]
    if isinstance(a, list):
        if len(a) != len(b):
            return [path]
        return [p for i, (x, y) in enumerate(zip(a, b))
                for p in diff_paths(x, y, path + "/" + str(i))]
    return [path] if a != b else []


def semantic_map(value):
    result = copy.deepcopy(value)
    result.pop("observedAtHead", None)
    for obj in result.get("sourceObjects", []):
        obj.pop("object", None)
    for operation in result["operations"]:
        operation.pop("sourceBlob", None)
    for caller in result.get("productCallers", []):
        caller.pop("blobSha", None)
    return result


def parsed_commit(raw, expected):
    require(git_hash("commit", raw) == expected, f"Commit hash mismatch: {expected}")
    header, message = raw.decode().split("\n\n", 1)
    headers = {}
    for line in header.splitlines():
        key, value = line.split(" ", 1)
        headers.setdefault(key, []).append(value)
    return {"sha": expected, "rawBytes": len(raw), "rawSha256": sha256(raw),
            "tree": headers["tree"][0], "parents": headers.get("parent", []),
            "author": headers["author"][0], "committer": headers["committer"][0],
            "message": message, "messageTrailingLF": message.endswith("\n")}


manifest = load(BASE / "manifest.json")
old_export = load(INTEGRATION / "navigation-export.json")
new_export = load(INTEGRATION / "final-navigation-export.json")
canonical_object = load(INTEGRATION / "canonical-final-object.json")
metadata = load(INTEGRATION / "canonical-final-metadata.json")
parent_metadata = load(INTEGRATION / "canonical-followup-code-metadata.json")
entries = {f["path"]: f for f in manifest["files"]}
old_entries = {f["path"]: f for f in old_export["files"]}
new_entries = {f["path"]: f for f in new_export["files"]}
require(len(entries) == 40, "Expected 40 original map entries")
require(len(old_entries) == 10 and len(new_entries) == 12, "Unexpected export scope")
require(set(old_entries) - set(entries) == {OLD_LEDGER}, "Old export escapes map/ledger scope")
require(set(new_entries) - set(entries) == {NEW_LEDGER}, "Final export escapes map/ledger scope")
require(OLD_LEDGER not in new_entries, "Final export overwrites historical ledger")

# The current directory is already the first navigation postimage, while its
# manifest still describes dd6 preimages. Recover those exact preimages only
# in this auditor's own temporary directory, then require a forward roundtrip.
current = {path: (BASE / path).read_bytes() for path in entries}
current[OLD_LEDGER] = (BASE / OLD_LEDGER).read_bytes()
layer_mismatches = []
for path, entry in entries.items():
    raw = current[path]
    expected = old_entries.get(path, entry)["blob"]
    require(git_hash("blob", raw) == expected, f"Current layer blob mismatch: {path}")
    if git_hash("blob", raw) != entry["blob"]:
        layer_mismatches.append(path)
require(set(layer_mismatches) == set(old_entries) - {OLD_LEDGER}, "Unexpected baseline layer difference")
patch = base64.b64decode(old_export["patch_base64"], validate=True)
patch_paths = re.findall(r"^diff --git a/(.+) b/(.+)$", patch.decode(), re.MULTILINE)
require({a for a, b in patch_paths if a == b} == set(old_entries), "Old patch scope mismatch")
require(len(patch_paths) == len(old_entries), "Unexpected old patch path count")
with tempfile.TemporaryDirectory(prefix="navigation-roundtrip-", dir=OUT) as tmp:
    temporary = Path(tmp)
    for path, raw in current.items():
        target = temporary / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    patch_path = temporary / "original-navigation.patch"
    patch_path.write_bytes(patch)
    for reverse in [True, False]:
        mode = ["--reverse"] if reverse else []
        for check in [True, False]:
            command = ["git", "apply", "--whitespace=error-all", *mode]
            if check:
                command.append("--check")
            command.append(str(patch_path))
            subprocess.run(command, cwd=temporary, check=True, capture_output=True)
        if reverse:
            original = {path: (temporary / path).read_bytes() for path in entries}
            for path, raw in original.items():
                entry = entries[path]
                require(git_hash("blob", raw) == entry["blob"], f"Recovered original blob mismatch: {path}")
                require(sha256(raw) == entry["sha256"], f"Recovered original digest mismatch: {path}")
        else:
            for path, raw in current.items():
                require((temporary / path).read_bytes() == raw, f"Forward roundtrip differs: {path}")

require(sha256(current[OLD_LEDGER]) == old_export["ledger_sha256"] == new_export["historical_ledger_sha256"], "Historical ledger digest mismatch")
final = dict(current)
for path, entry in new_entries.items():
    raw = entry["content"].encode()
    require(entry["mode"] == "100644", f"Unexpected file mode: {path}")
    require(git_hash("blob", raw) == entry["blob"], f"Final exported blob mismatch: {path}")
    require(sha256(raw) == entry["sha256"], f"Final exported digest mismatch: {path}")
    require((INTEGRATION / "final-navigation-postimages" / path).read_bytes() == raw, f"Disk postimage differs: {path}")
    final[path] = raw

rows = []
final_stage_changes = []
for path in sorted(entries):
    before, intermediate, after = [json.loads(table[path]) for table in (original, current, final)]
    require(before["sourceBase"] == intermediate["sourceBase"] == after["sourceBase"], f"Historical sourceBase changed: {path}")
    require(before["claimBoundary"] == intermediate["claimBoundary"] == after["claimBoundary"], f"claimBoundary changed: {path}")
    require(semantic_map(before) == semantic_map(intermediate) == semantic_map(after), f"Map semantics changed: {path}")
    require(after["productionImplementation"] is False and after["claimBoundary"]["productionImplementation"] is False, f"Production claim changed: {path}")
    differences = diff_paths(intermediate, after)
    for pointer in differences:
        require(re.fullmatch(r"/observedAtHead/(commit|tree)|/sourceObjects/\d+/object", pointer), f"Unexpected final navigation field: {path}{pointer}")
    if differences:
        final_stage_changes.append({"module": after["module"], "path": path, "jsonPointers": differences})
    raw = final[path]
    rows.append({"module": after["module"], "path": path, "blob": git_hash("blob", raw),
                 "sha256": sha256(raw), "bytes": len(raw), "operations": len(after["operations"]),
                 "productionImplementation": after["productionImplementation"],
                 "sourceBase": after["sourceBase"], "observedAtHead": after.get("observedAtHead"),
                 "changedByFirstNavigation": path in old_entries,
                 "changedByFinalNavigation": path in new_entries,
                 "originalBlob": entries[path]["blob"], "previousBlob": git_hash("blob", current[path])})
require(len(final_stage_changes) == 11, "Expected exactly 11 final map changes")
require(sum(row["operations"] for row in rows) == 371, "Expected 371 preserved operations")

ledger = json.loads(final[NEW_LEDGER])
require(ledger["sourceCandidate"] == new_export["before"], "Ledger candidate identity differs")
for key in ["executionEvidenceTransferred", "qualificationRulesModified", "historicalSourceBasesModified", "historicalExecutionRecordsModified"]:
    require(ledger[key] is False, f"Ledger changes historical or qualification boundary: {key}")
require(ledger["scope"] == "source_navigation_only" and ledger["qualificationAfterCommitRequired"] is True, "Ledger scope weakened")
require(len(ledger["records"]) == 11, "Expected 11 final ledger records")
require({r["mapPath"] for r in ledger["records"]} == set(new_entries) - {NEW_LEDGER}, "Ledger map coverage differs")
for record in ledger["records"]:
    path = record["mapPath"]
    raw, replacement = current[path], final[path]
    previous, after = json.loads(raw), json.loads(replacement)
    identity = record["previousMap"]
    require(identity["commit"] == new_export["before"]["commit"] and identity["tree"] == new_export["before"]["tree"], f"Previous source mismatch: {path}")
    require(identity["blob"] == git_hash("blob", raw) and identity["sha256"] == sha256(raw) and identity["bytes"] == len(raw), f"Previous map custody mismatch: {path}")
    require(record["previousSourceBase"] == record["replacementSourceBase"] == previous["sourceBase"] == after["sourceBase"], f"Ledger sourceBase mismatch: {path}")
    require(record["previousClaimBoundary"] == previous["claimBoundary"], f"Ledger claimBoundary mismatch: {path}")
    require(record["previousObservedAtHead"] == previous["observedAtHead"], f"Ledger previous observation mismatch: {path}")
    require(record["replacementObservedAtHead"] == after["observedAtHead"] == new_export["before"], f"Ledger replacement observation mismatch: {path}")
    require(record["replacementSha256"] == sha256(replacement), f"Ledger replacement hash mismatch: {path}")
    require(record["historicalCandidateRecordsModified"] is False and record["withdrawnClaims"] == [], f"Ledger history mismatch: {path}")
require(sha256(final[NEW_LEDGER]) == new_export["ledger_sha256"], "New ledger digest mismatch")

require(len(canonical_object["commits"]) == 1, "Expected one canonical raw object")
item = canonical_object["commits"][0]
require(item["sha"] == metadata["sha"] == CANONICAL, "Canonical metadata SHA mismatch")
canonical = parsed_commit(base64.b64decode(item["raw_base64"], validate=True), CANONICAL)
native = parsed_commit(base64.b64decode(new_export["raw_commit_base64"], validate=True), new_export["source"]["commit"])
require(canonical["tree"] == metadata["tree"]["sha"] == native["tree"] == new_export["source"]["tree"] == FINAL_TREE, "Final tree identity mismatch")
require(canonical["parents"] == native["parents"] == [new_export["before"]["commit"]] == [p["sha"] for p in metadata["parents"]], "Final parent mismatch")
require(parent_metadata["sha"] == new_export["before"]["commit"] and parent_metadata["tree"]["sha"] == new_export["before"]["tree"], "Code parent metadata mismatch")
require(canonical["message"] == metadata["message"], "Canonical raw message differs from metadata")
for key in ["author", "committer"]:
    match = re.fullmatch(r"(.*) <(.*)> (\d+) ([+-]\d{4})", canonical[key])
    require(match is not None, f"Invalid raw {key}")
    name, email, epoch, offset = match.groups()
    date = datetime.fromtimestamp(int(epoch), timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    require(metadata[key] == {"name": name, "email": email, "date": date}, f"Canonical {key} differs from metadata")
require(canonical["sha"] != native["sha"], "Do not collapse distinct commit identities")

report_manifest = load(ROOT / "final-report-prep/final-source-verified-blobs.json")
reported = {row["path"]: row for row in report_manifest["files"]}
require(set(reported) == set(entries), "Module reporter map set differs")
for row in rows:
    other = reported[row["path"]]
    require(all(row[key] == other[key] for key in ["blob", "sha256", "bytes"]), f"Independent module-report map mismatch: {row['path']}")

for path, raw in final.items():
    write_exact(OUT / "reconstructed-final" / path, raw)
inventory = {"schema": "hepta.independent-final40-navigation-audit.v1", "sourceCommit": CANONICAL,
             "sourceTree": FINAL_TREE, "files": rows,
             "sourceHistory": [{"path": p, "blob": git_hash("blob", final[p]), "sha256": sha256(final[p]), "bytes": len(final[p])}
                               for p in [OLD_LEDGER, NEW_LEDGER]]}
result = {"status": "PASS_LOCAL_NAVIGATION_AND_IDENTITY_AUDIT", "nativeQualificationStatus": "PENDING_RAW_RECEIPT_AND_JUNIT",
          "maps": 40, "operations": 371, "historicalSourceBasesPreserved": 40, "claimBoundariesPreserved": 40,
          "productionImplementationFalse": 40, "firstNavigationMaps": 9, "finalNavigationMaps": 11,
          "cumulativeChangedMaps": sum(row["originalBlob"] != row["blob"] for row in rows),
          "currentDirectoryLayer": "first-navigation-postimage; manifest describes original preimage",
          "currentDirectoryManifestDifferences": layer_mismatches,
          "originalPreimagesRecoveredAndHashVerified": True, "oldPatchReverseForwardByteRoundtrip": True,
          "firstStageChanges": [{"module": json.loads(current[path])["module"], "path": path,
                                  "jsonPointers": diff_paths(json.loads(original[path]), json.loads(current[path]))}
                                 for path in sorted(set(old_entries) - {OLD_LEDGER})],
          "finalStageChanges": final_stage_changes, "historicalLedgerPreserved": True,
          "finalLedgerPreviousAndReplacementBytesVerified": True, "moduleReporterCrosscheck": "40/40 exact blob, sha256, bytes",
          "canonicalCommit": canonical, "nativeNavigationCommit": native,
          "equalTreesDoNotTransferExecutionIdentity": True, "metadataCryptographicSignatureVerified": False,
          "executionEvidenceTransferred": False, "nativeTestsRunByAuditor": False,
          "sourceRuntimeOrRefsModified": False,
          "limitations": ["Uses saved raw objects, metadata, and navigation exports; no whole-tree remote membership or live ref assertion.",
                          "Does not qualify the product or transfer prior receipts across equal-tree commits.",
                          "Final raw JUnit, source-bound manifest/receipt, seven strict checks, and scoped results remain pending independent review."]}
for name, data in [("final40-blobs.json", inventory), ("navigation-audit-results.json", result)]:
    write_exact(OUT / name, (json.dumps(data, indent=2, ensure_ascii=False) + "\n").encode())
print(json.dumps({key: result[key] for key in ["status", "nativeQualificationStatus", "maps", "operations", "firstNavigationMaps", "finalNavigationMaps", "cumulativeChangedMaps", "moduleReporterCrosscheck"]}, ensure_ascii=False))
