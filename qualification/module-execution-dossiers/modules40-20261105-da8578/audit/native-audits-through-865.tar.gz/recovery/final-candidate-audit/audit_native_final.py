#!/usr/bin/env python3
"""Independently audit saved native evidence. No subprocesses or network calls."""

import base64
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
import tomllib
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
CHECKPOINT = ROOT / "integration/final-native-checkpoint"
NATIVE = CHECKPOINT / "native"
REPRODUCTION = CHECKPOINT / "reproduction"
ARCHIVE = ROOT / "integration/native-final-bb55-checkpoint.tar.gz"
REMOTE = "/home/qq/work/hepta-modules40-20261105-da8578"
SOURCE = {"commit": "bb55b0d7d263c396ec504c45393d938c3428dae5",
          "tree": "19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1", "status": ""}
PACKAGES = ["codex-hepta-agent-protocol", "codex-hepta-agentd", "codex-hepta-infer-worker-host",
            "codex-hepta-runtime", "codex-hepta-contracts", "codex-hepta-learning-ledger",
            "codex-hepta-supervisor"]


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def file_record(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(data), "sha256": digest(data)}


def git_commit(data):
    return hashlib.sha1(f"commit {len(data)}\0".encode() + data).hexdigest()


def verify_receipt(name, expected_command=None):
    path = NATIVE / (name + ".json")
    record = read(path)
    require(record["exit"] == 0, f"Nonzero receipt: {name}")
    require(record["source_before"] == record["source_after"] == SOURCE, f"Source drift: {name}")
    require(record["environment_sha256"] == environment_hash, f"Environment recording mismatch: {name}")
    require(record["start_unix_ns"] < record["end_unix_ns"], f"Invalid time interval: {name}")
    require(abs((record["end_unix_ns"] - record["start_unix_ns"]) / 1e9 - record["elapsed_seconds"]) < 0.02, f"Elapsed interval mismatch: {name}")
    require(record["cwd"] in [REMOTE + "/source", REMOTE + "/source/codex-rs"], f"Unexpected working directory: {name}")
    require(record["log_path"] == REMOTE + "/evidence/" + name + ".log", f"Unexpected log binding: {name}")
    log_path = NATIVE / (name + ".log")
    log = log_path.read_bytes()
    require(len(log) == record["log_bytes"] and digest(log) == record["log_sha256"], f"Log custody mismatch: {name}")
    if expected_command is not None:
        require(record["command"] == expected_command, f"Command scope changed: {name}")
    receipts.append({"name": name, "command": record["command"], "cwd": record["cwd"],
                     "exit": record["exit"], "source_before": record["source_before"],
                     "source_after": record["source_after"], "start_unix_ns": record["start_unix_ns"],
                     "end_unix_ns": record["end_unix_ns"], "receipt": file_record(path),
                     "log": file_record(log_path)})
    return record, log.decode()


def nextest_log(text, count, skipped, binaries):
    lines = re.sub(r"\x1b\[[0-9;]*m", "", text).splitlines()
    passes = []
    slow = []
    for line in lines:
        found = re.match(r"^\s*PASS\s+\[\s*([0-9.]+)s\]\s+(\S+)\s+(.+)$", line)
        if found:
            passes.append({"target": found[2], "test": found[3], "seconds": float(found[1])})
        attempt = re.match(r"^\s*TRY\s+(\d+)\s+(\S+)\s+", line)
        if attempt:
            require(int(attempt[1]) == 1 and attempt[2] == "SLOW", f"Retry or unsuccessful attempt: {line}")
            slow.append(line.strip())
        require(not re.match(r"^\s*(FAIL|TIMEOUT|LEAK|RETRY|CANCELLED|TERMINATING)\s", line), f"Non-clean status: {line}")
    starts = [line for line in lines if re.match(r"^\s*Starting \d+ tests across \d+ binar(?:y|ies)", line)]
    summaries = [line for line in lines if re.match(r"^\s*Summary \[", line)]
    require(len(starts) == len(summaries) == 1, "Missing or repeated nextest run summary")
    require(re.search(rf"Starting {count} tests across {binaries} binar(?:y|ies)", starts[0]), "Wrong announced test scope")
    if skipped:
        require(f"({skipped} tests skipped)" in starts[0], "Starting skip count mismatch")
    match = re.fullmatch(r"\s*Summary \[\s*([0-9.]+)s\] (\d+) tests run: (\d+) passed(?: \((\d+) slow\))?, (\d+) skipped", summaries[0])
    require(match is not None, "Unexpected/non-clean nextest summary")
    require((int(match[2]), int(match[3]), int(match[5])) == (count, count, skipped), "Nextest count mismatch")
    require(len(passes) == count, "PASS-line count differs from summary")
    identities = [(p["target"], p["test"]) for p in passes]
    require(len(set(identities)) == count, "Repeated PASS identity")
    require("NEXTEST_PROFILE=local" in text and "with nextest profile: local" in text, "Original nextest local profile not observed")
    return {"count": count, "passed": count, "skipped_reported_by_runner": skipped,
            "announced_binaries": binaries, "summary": summaries[0], "seconds": float(match[1]),
            "first_attempt_slow_messages": slow, "retried_attempts": 0, "passes": passes}


archive_metadata = read(ROOT / "integration/final-native-archive-metadata.json")
runtime = read(ROOT / "integration/runtime-receipts/final-canonical-bb55-runtime-status.json")
archive_bytes = ARCHIVE.read_bytes()
require(len(archive_bytes) == 1026914 and digest(archive_bytes) == "28424496bd400d6c5ff6370158f7b093355e463f19ebb550b1df6e7330504886", "Archive identity mismatch")
with tarfile.open(ARCHIVE, "r:gz") as archive:
    members = archive.getmembers()
    require(len(members) == 201 and all(member.isfile() for member in members), "Archive member scope/type mismatch")
    names = [member.name for member in members]
    require(len(set(names)) == 201, "Duplicate archive paths")
    require(all(not PurePosixPath(name).is_absolute() and ".." not in PurePosixPath(name).parts for name in names), "Unsafe archive path")
    contents = {member.name: archive.extractfile(member).read() for member in members}
manifest = json.loads(contents["MANIFEST.json"])
require(digest(contents["MANIFEST.json"]) == archive_metadata["archive"]["manifest_sha256"], "Archive manifest digest mismatch")
require(manifest["source"] == SOURCE and len(manifest["entries"]) == 200, "Archive source/count mismatch")
entry_map = {entry["path"]: entry for entry in manifest["entries"]}
require(len(entry_map) == 200 and set(entry_map) == set(contents) - {"MANIFEST.json"}, "Manifest coverage mismatch")
for name, data in contents.items():
    require((CHECKPOINT / name).read_bytes() == data, f"Extraction differs: {name}")
    if name in entry_map:
        require(entry_map[name]["bytes"] == len(data) and entry_map[name]["sha256"] == digest(data), f"Manifest custody mismatch: {name}")
actual_files = {str(p.relative_to(CHECKPOINT)) for p in CHECKPOINT.rglob("*") if p.is_file()}
require(actual_files == set(contents), "Unexpected extracted files")
old_native = ROOT / "integration/run1-checkpoint/native"
old_files = [path for path in old_native.rglob("*") if path.is_file()]
require(len(old_files) == 78, "Unexpected original native file count")
for path in old_files:
    relative = path.relative_to(old_native)
    require((NATIVE / relative).read_bytes() == path.read_bytes(), f"Historical native evidence changed: {relative}")
old_summary = read(NATIVE / "seven-package-run1-summary.json")
old_audit = read(NATIVE / "seven-package-run1-required-tests.69.native-audit.json")
require(old_summary["runner_exit"] == 100 and old_audit["gate_result"] == "NOT_CLEAN", "Historical failure overwritten")

require(runtime == archive_metadata["runtime"], "Authoritative runtime receipt differs from archive metadata")
require(runtime["job_id"] == "1a1ac64b60d-fc05-5402" and runtime["state"] == "succeeded" and runtime["exit_code"] == 0, "Runtime job/result mismatch")
for field in ["cancelled", "timed_out", "automatic_retry"]:
    require(runtime[field] is False, f"Runtime not clean: {field}")
for field in ["audit_recorded", "output_complete", "output_durable", "terminal_publication_confirmed"]:
    require(runtime[field] is True, f"Incomplete runtime publication: {field}")
for channel in ["stdout", "stderr"]:
    require(runtime["log_errors"][channel] is None and runtime["log_synced"][channel] is True and runtime["log_truncated"][channel] is False, f"Runtime log custody issue: {channel}")
    require(runtime["log_bytes"][channel]["seen"] == runtime["log_bytes"][channel]["stored"], f"Runtime lost bytes: {channel}")
environment_hash = digest((REPRODUCTION / "environment.json").read_bytes())
original_runner_hash = digest((REPRODUCTION / "run-final-native.py").read_bytes())
require(original_runner_hash == "9590be884338146913ddec0fc4c0770cd2f134daf69d67c5a4a8bb14d60097eb", "Original seven-package runner changed")
require("assert digest(runner.read_bytes()) == '" + original_runner_hash + "'" in (REPRODUCTION / "run-final-canonical.py").read_text(), "Final runner does not pin the original seven-package runner")
checkout = read(NATIVE / "final-canonical-run1-source-checkout.json")
require(checkout["source"] == SOURCE and checkout["environment_sha256"] == environment_hash, "Checkout identity mismatch")
canonical_raw = base64.b64decode(checkout["raw_commit_base64"], validate=True)
require(git_commit(canonical_raw) == SOURCE["commit"] and canonical_raw.startswith(("tree " + SOURCE["tree"] + "\n").encode()), "Canonical raw object mismatch")
require(canonical_raw == base64.b64decode(read(ROOT / "integration/canonical-final-object.json")["commits"][0]["raw_base64"]), "Canonical checkout differs from reviewed raw object")
raw_history_count = 0
for path in (CHECKPOINT / "native-source-history").glob("*.commit"):
    require(git_commit(path.read_bytes()) == path.stem, f"Historical raw commit identity mismatch: {path.name}")
    raw_history_count += 1

receipts = []
preflight_path = NATIVE / "seven-package-run2-preflight.json"
preflight = read(preflight_path)
summary = read(NATIVE / "seven-package-run2-summary.json")
require(preflight["source"] == summary["source"] == summary["source_after"] == SOURCE, "Seven-package source identity mismatch")
require(preflight["packages"] == summary["packages"] == PACKAGES and preflight["filter_used"] is False, "Seven-package selection mismatch")
require(preflight["original_profile"] == "local" and preflight["required_cases"] == 69, "Profile or required scope mismatch")
expected_test_command = ["just", "test", "--locked"] + [item for package in PACKAGES for item in ["-p", package]] + [
    "--tool-config-file", "hepta-evidence:" + REMOTE + "/seven-package-run2-report-only.nextest.toml",
    "--cargo-metadata", REMOTE + "/evidence/seven-package-run2-original-scoped-metadata.json"]
require(preflight["command"] == expected_test_command, "Seven-package command contains unexpected selection or flags")
test_receipt, main_log = verify_receipt("seven-package-run2-original-test", expected_test_command)
require(digest(preflight_path.read_bytes()) == summary["preflight_sha256"], "Preflight summary digest mismatch")
require(digest((NATIVE / "seven-package-run2-original-test.json").read_bytes()) == summary["original_test_receipt_sha256"], "Test receipt summary digest mismatch")
require(summary["runner_exit"] == summary["audit_exit"] == 0, "Summary runner/audit failure")
main_run = nextest_log(main_log, 1219, 78, 36)
require(main_run["summary"] == summary["native_summary"] == manifest["final_seven_package_summary"], "Summary text disagreement")
report_config = preflight["report_only_config"]
require(digest(report_config["content"].encode()) == report_config["sha256"], "Report-only config digest mismatch")
require(tomllib.loads(report_config["content"]) == {"profile": {"local": {"junit": {"path": REMOTE + "/evidence/seven-package-run2.junit.xml"}}}}, "Reporting config changes runner behavior")
metadata_path = NATIVE / "seven-package-run2-original-scoped-metadata.json"
require(digest(metadata_path.read_bytes()) == preflight["metadata"]["sha256"], "Cargo metadata digest mismatch")
require(preflight["metadata"]["command"] == ["cargo", "metadata", "--no-deps", "--format-version=1", "--locked"] and preflight["metadata"]["exit"] == 0, "Metadata producer changed")
cargo_metadata = read(metadata_path)
require(cargo_metadata["workspace_root"] == REMOTE + "/source/codex-rs" and cargo_metadata["target_directory"] == REMOTE + "/target", "Cargo metadata workspace mismatch")
metadata_packages = {package["name"]: package for package in cargo_metadata["packages"]}
require(len(metadata_packages) == len(cargo_metadata["packages"]) == 193, "Cargo metadata packages are duplicated or trimmed")
require(len(cargo_metadata["workspace_members"]) == len(cargo_metadata["workspace_default_members"]) == 193, "Cargo workspace metadata was narrowed")
for package in PACKAGES:
    require(metadata_packages[package]["id"] in cargo_metadata["workspace_members"], f"Selected package missing from metadata: {package}")

junit_path = NATIVE / "seven-package-run2.junit.xml"
junit_bytes = junit_path.read_bytes()
require(len(junit_bytes) == summary["junit"]["bytes"] == 280619 and digest(junit_bytes) == summary["junit"]["sha256"] == "8ef498e557bbc63e20230d66af451f1d7c97907ce7934201be171f368a185229", "JUnit custody mismatch")
require(summary["junit"]["fresh_for_run"] is True and test_receipt["start_unix_ns"] <= summary["junit"]["mtime_ns"] <= test_receipt["end_unix_ns"], "JUnit freshness interval mismatch")
xml = ET.fromstring(junit_bytes)
tags = Counter(element.tag for element in xml.iter())
require(tags == Counter({"testsuites": 1, "testsuite": 34, "testcase": 1219}), "Unexpected JUnit failure/skip/retry/output elements")
require(xml.attrib["tests"] == "1219" and xml.attrib["failures"] == xml.attrib["errors"] == "0", "Root JUnit totals differ")
require("Nextest run ID " + xml.attrib["uuid"] + " with nextest profile: local" in main_log, "JUnit run UUID/profile does not match raw log")
cases = []
suites = []
for suite in xml.findall("testsuite"):
    children = suite.findall("testcase")
    require(int(suite.attrib["tests"]) == len(children), "Suite case total mismatch")
    require(all(suite.attrib.get(key, "0") == "0" for key in ["disabled", "failures", "errors", "skipped"]), "Non-clean suite aggregate")
    suites.append({"name": suite.attrib["name"], "tests": len(children)})
    for case in children:
        require(case.attrib["classname"] == suite.attrib["name"] and len(case) == 0, "Conflicting target or non-clean case")
        timestamp_ns = int(datetime.fromisoformat(case.attrib["timestamp"]).timestamp() * 1e9)
        require(test_receipt["start_unix_ns"] <= timestamp_ns <= test_receipt["end_unix_ns"], "Case timestamp outside producer interval")
        cases.append({"target": case.attrib["classname"], "test": case.attrib["name"], "seconds": float(case.attrib["time"])})
identities = [(case["target"], case["test"]) for case in cases]
require(len(set(identities)) == 1219, "Duplicate JUnit case identities")
require(set(identities) == {(case["target"], case["test"]) for case in main_run["passes"]}, "JUnit cases differ from original log PASS rows")
package_counts = Counter(case["target"].split("::", 1)[0] for case in cases)
require(set(package_counts) == set(PACKAGES), "JUnit package coverage differs from seven packages")

audit_tools = REPRODUCTION / "audit-tools"
review_path = audit_tools / "required-tests.69.json"
history_path = audit_tools / "history/required-tests.with-e65.json"
bound_path = NATIVE / "seven-package-run2-required-tests.69.source-bound.json"
review, history, bound = read(review_path), read(history_path), read(bound_path)
require(digest(review_path.read_bytes()) == preflight["review_manifest_sha256"] == "bd5fa881bf712098f23b4f2193af548b5f3b70cf99694a2704d1d9458f5717ed", "Original 69 review manifest changed")
require(digest(history_path.read_bytes()) == "f832236003c1937c29ba9ca3f6faeafa2dc9799664ae1069d0df78339366f56e", "Historical 59 manifest changed")
require(review["required_tests"][:59] == history["required_tests"], "Historical 59 rows changed")
require(bound["candidate"] == {k: SOURCE[k] for k in ["commit", "tree"]}, "Bound candidate identity differs")
require(digest(bound_path.read_bytes()) == preflight["source_bound_manifest_sha256"], "Source-bound manifest digest mismatch")
require(bound["schema_version"] == 2 and bound["required_count"] == len(bound["required_tests"]) == len(review["required_tests"]) == 69, "Required manifest size/schema mismatch")
require(bound["review_manifest"]["sha256"] == digest(review_path.read_bytes()), "Bound review lineage differs")
require(bound["included_history_manifest"]["sha256"] == digest(history_path.read_bytes()) and bound["included_history_manifest"]["required_count"] == 59, "Bound history lineage differs")
require(set(bound["packages"]) == set(PACKAGES) and bound["untracked_paths_observed"] == [], "Bound source/package scope differs")
for key in ["tracked_worktree_and_index_match_candidate", "hidden_index_entries_rejected", "ambient_git_variables_and_global_config_isolated", "all_selected_source_bytes_match_committed_blobs", "test_names_targets_and_requirements_unchanged"]:
    require(bound["source_binding"][key] is True, f"Source binding check absent: {key}")
old_bound = read(NATIVE / "seven-package-run1-required-tests.69.source-bound.json")
require(bound["runner_source_context"] == old_bound["runner_source_context"], "Original runner/profile/toolchain/dependency context changed")
require(len(bound["runner_source_context"]) == 14 and len(bound["reviewed_source_files"]) == 22, "Unexpected source binding scope")
source_files = {item["path"]: item for item in bound["reviewed_source_files"]}
required_results = []
for old, current in zip(review["required_tests"], bound["required_tests"]):
    restored = dict(current)
    original_digest = restored.pop("review_source_snapshot_sha256")
    current_blob = restored.pop("source_git_blob")
    restored["source_snapshot_sha256"] = original_digest
    require(restored == old and original_digest == old["source_snapshot_sha256"], "Required name/target/history changed during binding")
    source = source_files[current["source_path"]]
    require(current["source_snapshot_sha256"] == source["sha256"] and current_blob == source["git_blob"], "Required source hash differs from bound file")
    declared_targets = [target for target in metadata_packages[current["package"]]["targets"]
                        if target["name"] == current["binary"] and current["binary_kind"] in target["kind"]]
    require(len(declared_targets) == 1, "Required binary/kind missing or ambiguous in original Cargo metadata")
    require(current["binary_kind"] in ["lib", "bin"], "Unreviewed required binary kind")
    # Nextest's JUnit classname is the package for lib tests and package::bin/name
    # for executable unit tests. Match the full target, never a test-name suffix.
    expected_target = current["package"] if current["binary_kind"] == "lib" else current["package"] + "::bin/" + current["binary"]
    matches = [case for case in cases if case["test"] == current["test"] and case["target"] == expected_target]
    wrong_target = [case for case in cases if case["test"] == current["test"] and case["target"] != expected_target]
    require(current["required"] is True and len(matches) == 1, f"Required test not exactly covered: {current['test']}")
    require(not wrong_target, f"Required full test name also appears in another target: {current['test']}")
    require(matches[0]["target"].split("::", 1)[0] == current["package"], "Required package mismatch")
    required_results.append({"package": current["package"], "binary": current["binary"],
                             "test": current["test"], "target": matches[0]["target"],
                             "matches": 1, "status": "CLEAN_PASS", "source_path": current["source_path"],
                             "review_source_sha256": original_digest, "tested_source_sha256": current["source_snapshot_sha256"],
                             "source_git_blob": current_blob})
require(len({(r["package"], r["binary"], r["test"]) for r in required_results}) == 69, "Duplicate required identities")
reported_audit = read(NATIVE / "seven-package-run2-required-tests.69.native-audit.json")
require(reported_audit["gate_result"] == "CLEAN" and reported_audit["original_suite_exit_code"] == 0, "Native audit not clean")
require(reported_audit["candidate_identity_supplied_by_operator"] == bound["candidate"], "Native audit candidate differs")
require(reported_audit["required_count"] == reported_audit["required_clean_passes"] == 69 and reported_audit["observed_case_count"] == 1219, "Native audit totals differ")
require(reported_audit["manifest"]["sha256"] == digest(bound_path.read_bytes()), "Native audit manifest differs")
require(len(reported_audit["junit_inputs"]) == 1 and reported_audit["junit_inputs"][0]["sha256"] == digest(junit_bytes), "Native audit JUnit differs")
for key in ["all_failed_cases", "all_flaky_or_retried_cases", "all_skipped_cases", "aggregate_failures", "parse_errors"]:
    require(reported_audit[key] == [], f"Native audit records non-clean rows: {key}")
for ours, theirs in zip(required_results, reported_audit["required_results"]):
    require(all(ours[key] == theirs[key] for key in ["package", "binary", "test"]), "Native required row identity differs")
    require(theirs["status"] == "PASS" and len(theirs["matches"]) == 1 and theirs["same_name_wrong_target"] == [], "Native required match differs")
    require(theirs["matches"][0]["classname"] == ours["target"], "Native required target differs")
verify_receipt("seven-package-run2-bind-manifest", ["python3", REMOTE + "/audit-tools/bind_native_audit_manifest.py", "--repo", REMOTE + "/source", "--review-manifest", REMOTE + "/audit-tools/required-tests.69.json", "--candidate-commit", SOURCE["commit"], "--candidate-tree", SOURCE["tree"], "--output", REMOTE + "/evidence/seven-package-run2-required-tests.69.source-bound.json"])
verify_receipt("seven-package-run2-required-audit", ["python3", REMOTE + "/audit-tools/audit_native_junit.py", "--review-manifest", REMOTE + "/audit-tools/required-tests.69.json", "--manifest", REMOTE + "/evidence/seven-package-run2-required-tests.69.source-bound.json", "--candidate-commit", SOURCE["commit"], "--candidate-tree", SOURCE["tree"], "--junit", REMOTE + "/evidence/seven-package-run2.junit.xml", "--suite-exit-code", "0", "--report", REMOTE + "/evidence/seven-package-run2-required-tests.69.native-audit.json"])

strict_commands = {
    "maps-qualification": ["python3", "scripts/hepta-implementation-maps.py", "verify", "--profile", "qualification", "--expected-sha", SOURCE["commit"], "--expected-tree", SOURCE["tree"]],
    "status-facts": ["python3", "scripts/test_hepta_module_status_facts.py"],
    "module-registry": ["python3", "scripts/hepta_module_registry.py", "--strict", "--pretty"],
    "documents-qualification": ["python3", "scripts/hepta-module-docs.py", "verify", "--profile", "qualification"],
    "chef-custody": ["python3", "scripts/test_hepta_ci_chef.py"],
    "rust-ci-feedback": ["python3", "scripts/test_hepta_rust_ci_feedback.py"],
    "module-docs-metadata": ["python3", "scripts/test_hepta_module_doc_metadata.py"],
}
require(summary["qualification_checks"] == {name: 0 for name in strict_commands}, "Strict gate summary mismatch")
for name, command in strict_commands.items():
    verify_receipt("seven-package-run2-" + name, command)

scope_commands = {
    "seven-package-original-runner": ["python3", REMOTE + "/run-final-native.py", "--candidate-commit", SOURCE["commit"], "--candidate-tree", SOURCE["tree"], "--run-label", "seven-package-run2"],
    "original-workspace-format": ["cargo", "fmt", "--", "--config", "imports_granularity=Item", "--check"],
    "original-four-package-format": ["cargo", "fmt", "--package", "codex-utils-path", "--package", "codex-hepta-prompt-registry", "--package", "codex-hepta-contracts", "--package", "codex-hepta-agentd", "--", "--check"],
    "original-ci-policy-clippy": ["just", "clippy", "--locked", "-p", "codex-exec-server", "-p", "codex-app-server", "-p", "codex-app-server-client", "--", "-D", "clippy::correctness", "-D", "clippy::await_holding_lock", "-D", "clippy::await_holding_invalid_type"],
    "two-library-regression": ["just", "test", "--locked", "-p", "codex-exec-server", "-p", "codex-app-server-client", "--lib"],
    "app-server-process-regression": ["just", "test", "--locked", "-p", "codex-app-server", "--test", "all", "-E", "test(process_exec)", "--no-tests", "fail"],
}
scoped_logs = {}
for name, command in scope_commands.items():
    _, scoped_logs[name] = verify_receipt("final-canonical-run1-" + name, command)
format_warning = "Warning: can't set `imports_granularity = Item`, unstable features are only available in nightly channel."
format_ignored_option_counts = {name: text.count(format_warning) for name, text in scoped_logs.items() if name in ["original-workspace-format", "original-four-package-format"]}
require(all(count > 0 for count in format_ignored_option_counts.values()), "Recorded stable-rustfmt limitation changed")
two_library = nextest_log(scoped_logs["two-library-regression"], 319, 0, 2)
app_server = nextest_log(scoped_logs["app-server-process-regression"], 5, 1016, 1)
final_summary = read(NATIVE / "final-canonical-run1-summary.json")
require(final_summary["source"] == final_summary["source_after"] == SOURCE and final_summary["checks"] == {name: 0 for name in scope_commands}, "Final scope summary mismatch")
require(manifest["final_checks"] == final_summary["checks"], "Archive scope summary differs")
require(max(receipt["end_unix_ns"] for receipt in receipts) <= final_summary["complete_unix_ns"] <= runtime["at_unix_ms"] * 1000000, "Runtime/receipt completion chronology differs")
require(runtime["at_unix_ms"] * 1000000 <= manifest["captured_unix_ns"], "Archive preceded native terminal publication")

paired = [case for case in cases if case["target"] == "codex-hepta-supervisor::paired_process_product"]
require({case["test"] for case in paired} == {"two_real_pairs_restart_one_without_peer_pid_churn", "five_real_pairs_adopt_all_ten_children_and_isolate_one_matrix_crash"}, "Paired product coverage differs")
preliminary = {name: file_record(OUT / name) for name in ["PRELIMINARY-NAVIGATION-AUDIT.md", "navigation-audit-results.json", "final40-blobs.json"]}
expected_preliminary_hashes = {"PRELIMINARY-NAVIGATION-AUDIT.md": "9f9f7ba5f42bed99909eeedd6ab0a973d71611f72760d1582e7f56de9fe0bcf5",
                               "navigation-audit-results.json": "d5a71c2246cfb68468745576bf7518597c44f0ca232924cc9826d5ffdb4985fe",
                               "final40-blobs.json": "b5b832c0d0b95eac727e67d40d7b9412bc1ffed26e0bd4fd430b2f5d8fa60c99"}
require({name: record["sha256"] for name, record in preliminary.items()} == expected_preliminary_hashes, "Earlier preliminary audit changed")
result = {
    "schema": "hepta.independent-final-native-audit.v1", "status": "CLEAN_WITHIN_RECORDED_SCOPE", "source": SOURCE,
    "archive": {**file_record(ARCHIVE), "members": 201, "manifest_entries": 200, "all_member_digests_and_extracted_bytes_verified": True,
                "original_native_files_preserved_byte_for_byte": 78, "historical_run1_exit": old_summary["runner_exit"], "historical_run1_audit": old_audit["gate_result"]},
    "authoritative_runtime": {"receipt": file_record(ROOT / "integration/runtime-receipts/final-canonical-bb55-runtime-status.json"),
                              "job_id": runtime["job_id"], "launch_nonce": runtime["launch_nonce"], "state": runtime["state"], "exit_code": 0,
                              "output_complete": True, "output_durable": True, "cancelled": False, "timed_out": False, "automatic_retry": False},
    "source_binding": {"canonical_raw_commit_verified": True, "historical_raw_commit_objects_verified": raw_history_count,
                       "all_16_receipts_match_clean_candidate_before_and_after": len(receipts) == 16,
                       "review_manifest_sha256": digest(review_path.read_bytes()), "historical59_manifest_sha256": digest(history_path.read_bytes()),
                       "bound_manifest_sha256": digest(bound_path.read_bytes()), "reviewed_source_files": 22,
                       "runner_source_context_files": 14, "all14_runner_contexts_unchanged_from_run1": True,
                       "original_profile_observed_in_log": "local", "report_config_only_adds_junit_path": True,
                       "cargo_metadata_workspace_packages": 193, "no_added_seven_package_filter": True,
                       "original_seven_package_runner_sha256": original_runner_hash, "final_runner_pins_original_runner": True},
    "seven_package": {"junit": file_record(junit_path), "original_log": file_record(NATIVE / "seven-package-run2-original-test.log"),
                      "run_uuid": xml.attrib["uuid"], "junit_suites": 34, "junit_testcases": 1219, "passed": 1219,
                      "failures": 0, "errors": 0, "timeouts": 0, "retries": 0, "duplicate_case_identities": 0,
                      "junit_skipped_elements": 0, "runner_reported_skipped": 78,
                      "skip_evidence_boundary": "Nextest reports 78 existing-profile skips; this JUnit serializes only 1219 executed cases, not the 78 skipped identities.",
                      "summary": main_run["summary"], "announced_binaries": 36, "package_counts": dict(package_counts),
                      "suites": suites, "first_attempt_slow_messages": main_run["first_attempt_slow_messages"], "paired_product_cases": paired},
    "required": {"count": 69, "exact_unique_clean_passes": 69, "original59_preserved": True,
                 "required_by_package": dict(Counter(row["package"] for row in required_results)), "cases": required_results,
                 "native_report_independently_agrees": True},
    "strict_checks": {name: 0 for name in strict_commands}, "scope_checks": {name: 0 for name in scope_commands},
    "format_policy_limit": {"ignored_unstable_option": "imports_granularity=Item", "warning_counts": format_ignored_option_counts,
                            "recorded_commands_exit": 0, "nightly_imports_granularity_enforcement_established": False},
    "scoped_regressions": {"two_library": {k: v for k, v in two_library.items() if k != "passes"},
                           "app_server_process": {k: v for k, v in app_server.items() if k != "passes"}},
    "receipts": receipts, "preliminary_artifacts_preserved": preliminary,
    "auditor_actions": "Read saved files, hash archive members, parse JSON/TOML/XML/logs; no subprocess, native test, remote call, source or ref mutation.",
    "limits": ["This audits the captured Linux native seven-package run and explicit related scopes; it does not qualify all workspace tests or other OS/architectures.",
               "App-server process evidence covers five process_exec cases selected by its recorded -E expression; 1016 other cases were skipped in that scope.",
               "Original strict Clippy policy is the recorded three -D lints; this is not a claim of zero warnings or -D warnings.",
               "Both original format commands exit zero, but stable rustfmt warns that imports_granularity=Item is ignored; nightly-only enforcement is not established.",
               "Recorded source binding checks a quiescent clean checkout; it is not an independent hardware, worker, filesystem, or concurrent-process attestation.",
               "Same-tree historical navigation commits retain separate identities; no prior receipt or platform qualification is transferred.",
               "Navigation production flags, real-provider acceptance, deployment qualification, activation and release boundaries remain unchanged."]}
require(len(receipts) == 16, "Unexpected audited receipt count")
output = OUT / "FINAL-NATIVE-AUDIT.json"
data = (json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode()
if output.exists():
    require(output.read_bytes() == data, "Existing FINAL audit differs; preserve earlier result")
else:
    output.write_bytes(data)
print(json.dumps({"status": result["status"], "source": SOURCE, "archive_entries": 200, "junit_suites": 34,
                  "passed": 1219, "runner_skipped": 78, "required_clean": 69, "failures": 0, "errors": 0,
                  "retries": 0, "strict_checks": 7, "scope_checks": 6, "bound_receipts": len(receipts),
                  "output_sha256": digest(data)}, ensure_ascii=False))
