# 最终候选导航与身份独立预审

## 结论与当前范围

本地导航和 raw commit 身份审计通过：40 个历史 `sourceBase`、40 个 `claimBoundary` 及 371 个操作的语义保持不变；40 张 Map 的顶层和 claimBoundary 内 `productionImplementation` 均为 `false`。本轮只更新 11 张 Map 的导航信息，并新增独立的最终导航账本；原导航账本未被覆盖。

这是已有文件的独立内容审计，不是原生资格结果。父 agent 正在收集 job `1a1ac64b60d-fc05-5402` 的最终 JUnit、receipt、严格检查和相关 scope 输出。本审计没有运行原生测试、访问运行中的工作区、变更正式 source/refs，或将父 agent 报告的中间运行结果代填为独立通过。

## 历史层次的核对

`integration/navigation-baseline/manifest.json` 描述 `dd6a8cad33a9f351501b90bf1e0ae6e9bc902db8` 原始 Map 层，但该目录当前的 9 张实际 Map 已是首轮 navigation-export 的 postimage。逐文件重算确认：9 个差异全部精确匹配首轮导出的 Git blob；其余 31 张仍与原 manifest 匹配。这是目录内容与 manifest 所指历史层不同，不是 9 张内容无法追溯。

独立恢复过程只在本审计自己的临时目录执行：复制现有 40 张 Map 和旧账本，反向应用原导出自带 patch，逐张验证恢复出的原始文件与 manifest 的 Git blob 和 SHA256，再正向应用 patch，要求恢复全部当前文件的完全相同字节。最后叠加本轮 11 张 Map。原始目录没有修改。

因此来源链明确为：原始 40 张 → 首轮 9 张导航更新 → 本轮 11 张导航更新。两轮重叠 7 张，累计有 13 张与最初原始版本不同；`cognitive.read` 和 `memory.retrieval` 保留首轮导航版本。最终 40 张与 `final-report-prep/final-source-verified-blobs.json` 独立逐一比对，40/40 的 Git blob、SHA256、字节数完全一致。

## 本轮变更范围

本轮 11 张为 `automation.taskflow`、`inference.worker`、`intelligence.control`、`kernel.authority`、`kernel.operations`、`learning.eval`、`learning.ledger`、`learning.plasticity`、`runtime.agentd`、`runtime.codex`、`runtime.supervisor`。

本轮相对前一导航层只有 39 个 JSON 标量变化：22 个 `observedAtHead.commit/tree` 和 17 个 `sourceObjects[*].object`。本轮全部操作条目正文保持不变，没有修改 caller/writer、owner、外部门槛、资格状态或操作语义。

从最初层跨两轮比较时，首轮另有 12 个 operation `sourceBlob` 和 2 个 product-caller `blobSha` 导航摘要更新。审计只在语义比较中排除这些明确的源码摘要字段、`observedAtHead` 和 `sourceObjects[*].object`；路径、符号、顺序、owner、caller 信息、说明、门槛和其他字段均做深度相等比较。没有将任意不一致字段笼统忽略。

所有 12 个本轮导出文件的内容重新计算 Git blob 和 SHA256，并与导出元数据、磁盘 postimage 逐字节匹配。11 个新账本条目的 previous blob、SHA256、字节数、sourceBase、claimBoundary 和 observedAtHead 均与重建的上一层实际内容核对；replacement 摘要和观察身份也与本轮内容一致。

| 账本 | SHA256 | 状态 |
| --- | --- | --- |
| `source-navigation-history.json` | `485bc0826092755850f2722320c8e7aeb653e6c77047c97fdc56f6b56216f0e7` | 首轮 export、当前保存件和最终集合的字节相同 |
| `source-navigation-history-final.json` | `7ec6f404b3c5438bece2170b19ded4ff785cacbafa8e610fa1ab53ea794546a3` | 独立新文件，11 个 previous/replacement 记录核对通过 |

新账本明确保持 `source_navigation_only`、`executionEvidenceTransferred=false`、`qualificationRulesModified=false`、`historicalSourceBasesModified=false`、`historicalExecutionRecordsModified=false` 和 `qualificationAfterCommitRequired=true`。

## Commit 身份

| 角色 | Commit | Tree | Parent |
| --- | --- | --- | --- |
| canonical 待资格候选 | `bb55b0d7d263c396ec504c45393d938c3428dae5` | `19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1` | `38bd86afdec6ee0558af47ae58bb2813e2ad788e` |
| 原生导航导出提交 | `8ab12f162b659a209a87f3254fe87cb07f4c07e8` | `19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1` | `38bd86afdec6ee0558af47ae58bb2813e2ad788e` |

两份 raw object 都按 Git 的 `commit <bytes>\0<raw>` 规则独立重算并命中各自 commit SHA。canonical 的 raw tree、parent、完整 message、author/committer 名称、邮箱和 UTC timestamp 与保存的 GitHub metadata 相同；parent 身份也与独立保存的代码父提交 metadata 一致。

canonical raw object 是 354 字节、message 无尾部 LF，raw SHA256 为 `b0430401ca59249d514908dcf38817546cd95efb52ad5aa63ecd08191c9cc8af`。原生导航 raw object 是 357 字节、message 有尾部 LF，raw SHA256 为 `12e84de1077ba9324cbd4160999a8cd86be8e3edd64149e4ff7f89ec3bb99f8d`。它们的作者、时间、message 和 commit 身份确实不同；同 tree 只说明记录的源码树相同，不转移任何执行 receipt 或资格结果。保存的 metadata 也没有有效签名证明，本审计未将对象 hash 核对解释为作者签名验证。

Map 的新 observedAtHead 和新账本的 sourceCandidate 绑定的是导航提交之前的代码候选 `38bd86…/62f767…`。最终资格仍须明确绑定 canonical `bb55…/19116…`，不能拿导航导出 `8ab…` 的身份替代。

## 交付与复核入口

- `audit_navigation.py`：独立核对脚本，只读取保存的 integration/report 文件并写本审计目录。
- `navigation-audit-results.json`：机器可读结论、全部变化 JSON pointer、raw object 身份与范围限制。
- `final40-blobs.json`：最终 40 张 Map 和两个账本的 blob/SHA256/字节清单。
- `reconstructed-final/docs/modules/`：可供报告 lane 直接读取的最终 Map 集合。

机器结果当前状态是 `PASS_LOCAL_NAVIGATION_AND_IDENTITY_AUDIT`，原生资格状态仍为 `PENDING_RAW_RECEIPT_AND_JUNIT`。脚本 SHA256 为 `cb265db95fb0b16558479b184d506136cff7d5b047679ee740ef3bd539dd1481`；结果 JSON SHA256 为 `d5a71c2246cfb68468745576bf7518597c44f0ca232924cc9826d5ffdb4985fe`；40 Map 清单 SHA256 为 `b5b832c0d0b95eac727e67d40d7b9412bc1ffed26e0bd4fd430b2f5d8fa60c99`。

## 最终原生证据到齐后待核项目

独立解析原始 JUnit 的 suite/testcase，核对七包范围、总计数、失败/错误/超时和重试记录；不能只信聚合 summary 或 `69/69` 必需用例摘要。将 69 清单作为覆盖审计，检查每个精确用例名的干净通过和重复/遗漏情况，不作为 runner 过滤器。

同时对照原始运行命令、完整 receipt、绑定 manifest、JUnit/日志摘要和源码状态，确认实际运行身份为 canonical `bb55…/19116…`，原 profile 与完整七包范围未被遮蔽筛选，检查后源码未漂移。严格检查和额外 scope 必须各自核对真实退出状态与源绑定；任何旧提交的结果保留原身份。

当前范围不包含远端完整 Git tree membership、live refs、实际 worker 身份的重新读取，也不证明真实 provider、默认产品组成、deployment qualification、activation 或 release。上述限制不会因导航审计通过而解除。
