# C5 独立第二轮源码复核

Reviewer：`/root/recovery/successor_review`。复核方式为本地只读解析、哈希与比较；未执行审计脚本或 native 测试，未调用 runtime/remote，未修改源码、refs 或既有审计文件。

**结论：未发现矛盾，支持 `PASS_SOURCE_IDENTITY_AND_NAVIGATION`。复核时 C5 原生仍为 `PENDING_C5_RAW_RECEIPT_AND_JUNIT`。**

1. 独立比较完整 6,061-byte preimage 和 6,064-byte postimage，唯一变化为第 82 行 `delta("first", "hel")` → `delta("first", "he\x6c")`。运行 UTF-8 字节仍为 `68 65 6c`，保持同一次 delta 调用。其他全部源码字节、四个测试函数、通知顺序、重复 completion、拒绝场景、output/usage/boundary 断言和 byte/metadata limits 不变。postimage 与保存的固定 C5 GitHub 内容相等，blob 为 `42f35deccbf558be66ddd906fb423a18ebfb84f7`。

2. 独立重算两个 canonical raw commit 的 SHA，并逐项比较 tree、single parent、message、author/committer 和归一化时间与 metadata。祖先关系为 bb55 → c486 → `797116d61cf422c26274ffef31297dce84a53a80`；C5 tree 为 `67ce024db1679aa6cd301856ba3a694ea18bc4b6`，340-byte raw 对象 SHA-256 为 `24bc549de0bc6e95eb636ca1402562a152de0d8597deea4635f068c26bf696e7`。native navigation c777 的 raw 对象另行正确重算，与 C5 同 tree/parent，身份仍独立。

3. 两段保存的固定 GitHub compare 明确限定：bb55→c486 仅一份 fixture；c486→C5 仅一张 Map 和一份新 history。三个固定 C5 file response 的 URL 都明确包含 C5 SHA，未见 workflow、配置、ignore、生产代码或其他测试变化。

4. 独立比较所有重建 Map 与旧字节，并重算 blob 和 SHA-256。仅 inference.worker 的 `/observedAtHead/commit`、`/observedAtHead/tree` 改为 c486 身份。371 operations、历史 sourceBase、claimBoundary、108 gaps 和 140 external gates 原值一致，40 个 production flags 均 false。两份旧 history 字节相等；第三份保留 source_navigation_only、四个不转移/不修改标记为 false、qualificationAfterCommitRequired 为 true。

5. canonical wrapper 将原七包 runner 固定为 SHA-256 `9590be884338146913ddec0fc4c0770cd2f134daf69d67c5a4a8bb14d60097eb`，本地 runner 摘要匹配。七个完整 package、69-case audit、7 strict checks、原 local profile 和仅添加 JUnit path 的报告配置均保留。wrapper 保留原 6 scope，并增加版本固定的 Codespell 2.4.3 及原参数 `--ignore-words .codespellignore --skip ./.git`；未见新增 filter、assertion、retry、timeout、budget 或 policy 放宽。

复核者没有独立核验 C5 归档中的原始 JUnit/receipt/69-case audit，因此本记录不提供 C5 的执行通过结论。bb55 RED 与 c486 GREEN 的 Codespell 回执继续保留各自源身份。
