#!/usr/bin/env python3
"""Read saved C5 source/navigation evidence; never execute native or remote work."""

import base64
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
INPUTS = OUT / "inputs"
PRIOR = ROOT / "recovery/final-candidate-audit"
INTEGRATION = ROOT / "integration"
FIXTURE = ROOT / "candidate-review/codespell-stream-fragment"
CANONICAL = "797116d61cf422c26274ffef31297dce84a53a80"
TREE = "67ce024db1679aa6cd301856ba3a694ea18bc4b6"
CODE = "c4863123b65f895be0eb14e0958d5cfe6c9c78bd"
CODE_TREE = "81e2217141060f123adbe1da78c3dbecf57f3073"
BB55 = "bb55b0d7d263c396ec504c45393d938c3428dae5"
BB55_TREE = "19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1"
NATIVE_NAV = "c77786bd2b786b801197dad684f6f5af1a3d5af5"
FIXTURE_PATH = "codex-rs/hepta-infer-worker-host/src/native_output_tests.rs"
MAP_PATH = "docs/modules/inference.worker/IMPLEMENTATION_MAP.json"
HISTORY_ROOT = "qualification/module-execution-dossiers/modules40-20261105-da8578/"
OLD_LEDGERS = [HISTORY_ROOT + "source-navigation-history.json", HISTORY_ROOT + "source-navigation-history-final.json"]
NEW_LEDGER = HISTORY_ROOT + "source-navigation-history-spelling.json"


def require(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git_hash(kind, data):
    return hashlib.sha1(f"{kind} {len(data)}\0".encode() + data).hexdigest()


def record(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(data), "sha256": digest(data)}


def write_exact(path, data):
    if path.exists():
        require(path.read_bytes() == data, f"Existing audit artifact differs: {path}")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)


def save_json(name, data):
    write_exact(OUT / name, (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode())


def parsed_commit(raw, expected, metadata=None):
    require(git_hash("commit", raw) == expected, f"Raw commit does not hash to {expected}")
    header, message = raw.decode().split("\n\n", 1)
    fields = {}
    for line in header.splitlines():
        key, value = line.split(" ", 1)
        fields.setdefault(key, []).append(value)
    if metadata is not None:
        require(metadata["sha"] == expected and metadata["tree"]["sha"] == fields["tree"][0], "Raw object and metadata identity differ")
        require([parent["sha"] for parent in metadata["parents"]] == fields["parent"], "Metadata parents differ")
        require(metadata["message"] == message, "Metadata message differs")
        for key in ["author", "committer"]:
            match = re.fullmatch(r"(.*) <(.*)> (\d+) ([+-]\d{4})", fields[key][0])
            require(match is not None, f"Malformed raw {key}")
            name, email, epoch, _offset = match.groups()
            utc = datetime.fromtimestamp(int(epoch), timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            require(metadata[key] == {"name": name, "email": email, "date": utc}, "Raw actor/timestamp differs from metadata")
    return {"sha": expected, "tree": fields["tree"][0], "parents": fields.get("parent", []),
            "rawBytes": len(raw), "rawSha256": digest(raw), "messageTrailingLF": message.endswith("\n")}


def connector(name):
    value = read(INPUTS / name)
    require(value.get("isError") is False, f"Connector response error: {name}")
    return value["structuredContent"]


# Freeze and verify every prior bb55 audit artifact, including all 40 maps and 2 ledgers.
old_inventory = read(PRIOR / "final40-blobs.json")
require(old_inventory["sourceCommit"] == BB55 and old_inventory["sourceTree"] == BB55_TREE, "Wrong prior audited inventory")
prior_roots = {
    "FINAL-NATIVE-AUDIT.md": "63c98431feec7ef2cfe97097bbeefd23891cbcc4b1589cff123e738f80741c5b",
    "FINAL-NATIVE-AUDIT.json": "788dd2894625036144b1dbb5d2d923a34126c8c974f57c812027d947b9646358",
    "FINAL-NATIVE-AUDIT-MANIFEST.json": "654fee09f0d458736d0b72c4b0fcc6a14abe4f5d1a1085b1e1dd5b0730e1cec6",
    "audit_native_final.py": "971f16f1f340006c8a6515156b4471b9e49cfc6f05b2f2eb5f9badc58bf8e9c5",
    "PRELIMINARY-NAVIGATION-AUDIT.md": "9f9f7ba5f42bed99909eeedd6ab0a973d71611f72760d1582e7f56de9fe0bcf5",
    "navigation-audit-results.json": "d5a71c2246cfb68468745576bf7518597c44f0ca232924cc9826d5ffdb4985fe",
    "final40-blobs.json": "b5b832c0d0b95eac727e67d40d7b9412bc1ffed26e0bd4fd430b2f5d8fa60c99",
    "audit_navigation.py": "cb265db95fb0b16558479b184d506136cff7d5b047679ee740ef3bd539dd1481",
}
expected_prior = dict(prior_roots)
for entry in old_inventory["files"] + old_inventory["sourceHistory"]:
    path = "reconstructed-final/" + entry["path"]
    data = (PRIOR / path).read_bytes()
    require(len(data) == entry["bytes"] and git_hash("blob", data) == entry["blob"], f"Prior blob changed: {path}")
    expected_prior[path] = entry["sha256"]
prior_paths = {str(p.relative_to(PRIOR)): p for p in PRIOR.rglob("*") if p.is_file()}
require(set(prior_paths) == set(expected_prior) and len(prior_paths) == 50, "Prior audit file set changed")
for path, expected in expected_prior.items():
    require(digest(prior_paths[path].read_bytes()) == expected, f"Prior audit bytes changed: {path}")
save_json("bb55-audit-preservation.json", {"sourceCommit": BB55, "sourceTree": BB55_TREE,
          "files": [record(prior_paths[path]) for path in sorted(prior_paths)], "fileCount": 50, "allOriginalBytesPreserved": True})

# Prove the one-line fixture postimage, including its fixed canonical GitHub content.
fixture_manifest = read(FIXTURE / "manifest.json")
before = (FIXTURE / "before" / FIXTURE_PATH).read_bytes()
after = (FIXTURE / "after" / FIXTURE_PATH).read_bytes()
old_literal, new_literal = b'delta("first", "hel")', b'delta("first", "he\\x6c")'
require(before.count(old_literal) == 1 and before.replace(old_literal, new_literal) == after, "Fixture is not exactly the one literal replacement")
require(before.splitlines()[81].strip() == old_literal + b"," and after.splitlines()[81].strip() == new_literal + b",", "Fixture change is not the original line 82")
for label, data in [("before", before), ("after", after)]:
    require(len(data) == fixture_manifest[label + "Bytes"] and digest(data) == fixture_manifest[label + "Sha256"] and git_hash("blob", data) == fixture_manifest[label + "Blob"], f"Fixture {label} custody differs")
source_input = read(FIXTURE / "source-inputs.json")
require(source_input["sourceCommit"] == BB55 and source_input["content"].encode() == before and source_input["sha"] == git_hash("blob", before), "Pinned preimage differs")
github_fixture = connector("github-c5-native-output-tests.json")
require(github_fixture["encoding"] == "utf-8" and github_fixture["content"].encode() == after and github_fixture["sha"] == git_hash("blob", after), "Canonical C5 fixture differs from reviewed postimage")
test_names = re.findall(rb"#\[test\]\s*fn\s+(\w+)\(", before)
require(len(test_names) == 4 and test_names == re.findall(rb"#\[test\]\s*fn\s+(\w+)\(", after), "Fixture test names/count changed")
require(b"he" + bytes([int("6c", 16)]) == b"hel", "Hex escape arithmetic differs")
patch = (FIXTURE / "preserve-stream-prefix-bytes.patch").read_bytes()
require(digest(patch) == fixture_manifest["patch"]["sha256"] and len(patch) == fixture_manifest["patch"]["bytes"], "Patch digest differs")
minus = [line[1:] for line in patch.splitlines() if line.startswith(b"-") and not line.startswith(b"---")]
plus = [line[1:] for line in patch.splitlines() if line.startswith(b"+") and not line.startswith(b"+++")]
require(minus == [b"        " + old_literal + b","] and plus == [b"        " + new_literal + b","], "Patch changes additional lines")
configs = read(FIXTURE / "original-codespell-configs.json")
require(configs["sourceCommit"] == BB55, "Wrong Codespell configuration source")
config_rows = {entry["path"]: entry for entry in fixture_manifest["codespell"]["originalConfigs"]}
for entry in configs["files"]:
    data = entry["content"].encode()
    require(git_hash("blob", data) == entry["sha"] == config_rows[entry["path"]]["blob"] and digest(data) == config_rows[entry["path"]]["sha256"], "Original Codespell configuration custody differs")

# Fixed GitHub comparisons prove the code and navigation changes are bounded.
for name, base, head, expected_files in [
    ("github-bb55-to-code.json", BB55, CODE, {FIXTURE_PATH: "modified"}),
    ("github-code-to-c5.json", CODE, CANONICAL, {MAP_PATH: "modified", NEW_LEDGER: "added"}),
]:
    comparison = connector(name)
    require(comparison["repository_full_name"] == "TrillionniumFoundation/hepta-private-ci", "Wrong comparison repository")
    require(comparison["base"] == comparison["base_commit"]["sha"] == comparison["merge_base_commit"]["sha"] == base and comparison["head"] == head, "Comparison identities differ")
    require(comparison["status"] == "ahead" and comparison["ahead_by"] == comparison["total_commits"] == 1 and comparison["behind_by"] == 0 and comparison["too_large"] is not True, "Comparison not a complete one-commit successor")
    require({entry["filename"]: entry["status"] for entry in comparison["files"]} == expected_files and len(comparison["files"]) == len(expected_files), "Unexpected changed file scope")

objects = {}
for label, expected, expected_tree, parent in [("code", CODE, CODE_TREE, BB55), ("final", CANONICAL, TREE, CODE)]:
    payload = read(INTEGRATION / f"canonical-spelling-{label}-object.json")
    metadata = read(INTEGRATION / f"canonical-spelling-{label}-metadata.json")
    require(len(payload["commits"]) == 1 and payload["commits"][0]["sha"] == expected, "Canonical raw object set differs")
    value = parsed_commit(base64.b64decode(payload["commits"][0]["raw_base64"], validate=True), expected, metadata)
    require(value["tree"] == expected_tree and value["parents"] == [parent], "Canonical ancestry/tree differs")
    objects[label] = value

export_path = INTEGRATION / "spelling-navigation-export.json"
export = read(export_path)
require(export["before"] == {"commit": CODE, "tree": CODE_TREE} and export["source"] == {"commit": NATIVE_NAV, "tree": TREE, "status": ""}, "Navigation export source differs")
objects["nativeNavigation"] = parsed_commit(base64.b64decode(export["raw_commit_base64"], validate=True), NATIVE_NAV)
require(objects["nativeNavigation"]["tree"] == TREE and objects["nativeNavigation"]["parents"] == [CODE] and NATIVE_NAV != CANONICAL, "Native navigation identity collapsed or mismatched")
exported = {entry["path"]: entry for entry in export["files"]}
require(set(exported) == {MAP_PATH, NEW_LEDGER} and len(export["files"]) == 2, "Navigation export escapes the two-file scope")
for path, entry in exported.items():
    data = entry["content"].encode()
    require(entry["mode"] == "100644" and digest(data) == entry["sha256"] and git_hash("blob", data) == entry["blob"], "Export blob/digest differs")
    require((INTEGRATION / "spelling-navigation-postimages" / path).read_bytes() == data, "Postimage differs from export")
    response = connector("github-c5-inference-worker-map.json" if path == MAP_PATH else "github-c5-spelling-history.json")
    require(response["encoding"] == "utf-8" and response["content"].encode() == data and response["sha"] == entry["blob"], "Canonical GitHub bytes differ from native export")

final = {entry["path"]: (PRIOR / "reconstructed-final" / entry["path"]).read_bytes() for entry in old_inventory["files"] + old_inventory["sourceHistory"]}
rows = []
changed_paths = []
gap_count = gate_count = 0
for old in old_inventory["files"]:
    path = old["path"]
    previous_bytes = final[path]
    data = exported[path]["content"].encode() if path in exported else previous_bytes
    previous, current = json.loads(previous_bytes), json.loads(data)
    if data != previous_bytes:
        changed_paths.append(path)
        require(path == MAP_PATH and previous["observedAtHead"] == {"commit": "38bd86afdec6ee0558af47ae58bb2813e2ad788e", "tree": "62f767b394adbda686f21499f4af5cb4584673dc"}, "Unexpected prior observation")
        require(current["observedAtHead"] == export["before"], "New observation is not code-parent source")
        old_semantics, new_semantics = copy.deepcopy(previous), copy.deepcopy(current)
        old_semantics.pop("observedAtHead")
        new_semantics.pop("observedAtHead")
        require(old_semantics == new_semantics, "A non-observation map field changed")
    require(previous["sourceBase"] == current["sourceBase"] and previous["claimBoundary"] == current["claimBoundary"] and previous["operations"] == current["operations"], "Historical map semantics changed")
    require(current["productionImplementation"] is False and current["claimBoundary"]["productionImplementation"] is False and current["sourceRootPresent"] is True, "Root/production boundary changed")
    gap_count += len(current["repositoryControlledGaps"])
    gate_count += len(current["externalEvidenceGates"])
    final[path] = data
    rows.append({"module": current["module"], "path": path, "blob": git_hash("blob", data), "sha256": digest(data), "bytes": len(data),
                 "operations": len(current["operations"]), "productionImplementation": False, "sourceBase": current["sourceBase"],
                 "observedAtHead": current.get("observedAtHead"), "changedBySuccessorNavigation": path in changed_paths, "previousBlob": old["blob"]})
require(changed_paths == [MAP_PATH] and len(rows) == 40 and sum(row["operations"] for row in rows) == 371 and (gap_count, gate_count) == (108, 140), "Final map counts differ")
for path in OLD_LEDGERS:
    require(digest(final[path]) == export["old_history_ledgers_sha256"][path], "Prior history ledger changed")
final[NEW_LEDGER] = exported[NEW_LEDGER]["content"].encode()
ledger = json.loads(final[NEW_LEDGER])
require(ledger["sourceCandidate"] == export["before"] and ledger["scope"] == "source_navigation_only" and ledger["qualificationAfterCommitRequired"] is True, "Third ledger weakens qualification boundary")
for key in ["executionEvidenceTransferred", "qualificationRulesModified", "historicalSourceBasesModified", "historicalExecutionRecordsModified"]:
    require(ledger[key] is False, f"Third ledger changes {key}")
require(len(ledger["records"]) == 1, "Unexpected third ledger record count")
history = ledger["records"][0]
previous_bytes = (PRIOR / "reconstructed-final" / MAP_PATH).read_bytes()
previous, current = json.loads(previous_bytes), json.loads(final[MAP_PATH])
require(history["module"] == "inference.worker" and history["mapPath"] == MAP_PATH, "Third ledger targets another map")
require(history["previousMap"] == {**export["before"], "blob": git_hash("blob", previous_bytes), "sha256": digest(previous_bytes), "bytes": len(previous_bytes)}, "Third ledger previous map custody differs")
require(history["previousSourceBase"] == history["replacementSourceBase"] == previous["sourceBase"] == current["sourceBase"], "Third ledger rewrites sourceBase")
require(history["previousClaimBoundary"] == previous["claimBoundary"] and history["previousObservedAtHead"] == previous["observedAtHead"] and history["replacementObservedAtHead"] == current["observedAtHead"], "Third ledger semantic history differs")
require(history["replacementSha256"] == digest(final[MAP_PATH]) and history["withdrawnClaims"] == [] and history["historicalCandidateRecordsModified"] is False, "Third ledger replacement/history differs")
require(export["semantic_metadata_preserved"] is True and export["execution_evidence_transferred"] is False and (export["modules"], export["operations"], export["production_false"]) == (40, 371, 40), "Export scope summary differs")

# Compare independent reconstruction with the report lane's saved bytes and all raw map fields.
report_manifest_path = ROOT / "successor-report-prep/source-verified-blobs.json"
report_manifest = read(report_manifest_path)
require(report_manifest["sourceCommit"] == CANONICAL and report_manifest["sourceTree"] == TREE, "Reporter candidate differs")
reported = {entry["path"]: entry for entry in report_manifest["files"]}
require(set(reported) == {row["path"] for row in rows}, "Reporter map set differs")
facts_path = ROOT / "successor-report-prep/MODULES40-SOURCE-FACTS.json"
facts = read(facts_path)
fact_modules = {item["module"]: item for item in facts["modules"]}
require(len(fact_modules) == len(facts["modules"]) == 40 and facts["sourceSnapshot"]["commit"] == CANONICAL and facts["sourceSnapshot"]["tree"] == TREE and facts["sourceSnapshot"]["executionEvidenceTransferred"] is False, "Reporter facts candidate/count/boundary differs")
for row in rows:
    path = row["path"]
    require(all(row[key] == reported[path][key] for key in ["blob", "sha256", "bytes"]), "Reporter inventory differs from independent reconstruction")
    require((ROOT / "successor-report-prep/source-snapshot" / path).read_bytes() == final[path], "Reporter staged map bytes differ")
    raw_map = json.loads(final[path])
    require(all(fact_modules[row["module"]][key] == value for key, value in raw_map.items()), "Reporter fact row does not preserve every raw map field")
reported_history = {entry["path"]: entry for entry in report_manifest["sourceHistory"]}
require(set(reported_history) == set(OLD_LEDGERS + [NEW_LEDGER]), "Reporter history set differs")
for path, entry in reported_history.items():
    data = final[path]
    require((ROOT / "successor-report-prep/source-snapshot" / path).read_bytes() == data and git_hash("blob", data) == entry["blob"] and digest(data) == entry["sha256"] and len(data) == entry["bytes"], "Reporter history bytes differ")
registry = (ROOT / "successor-report-prep/source-snapshot" / report_manifest["registryPath"]).read_bytes()
require(digest(registry) == report_manifest["registrySha256"] == "468ce01963e5665ad0b39df7c69a0c630bb93e2168f4d669dd4f8dea55e17716" and git_hash("blob", registry) == report_manifest["registryBlob"] == "2571766d45a0a6b0db0ec83e675c70609d3bc39d", "Registry changed")

# Earlier Codespell RED/GREEN are independent source stages, not a C5 test result.
runtime_path = INTEGRATION / "runtime-receipts/spelling-navigation-run1-runtime.json"
runtime = read(runtime_path)
status = runtime["status"]
require(status["job_id"] == "1a1ac7fea48-fc05-54c8" and status["state"] == "succeeded" and status["exit_code"] == 0, "Spelling navigation runtime is not its recorded successful job")
for field in ["cancelled", "timed_out", "automatic_retry"]:
    require(status[field] is False, f"Unexpected runtime {field}")
for field in ["output_complete", "output_durable", "terminal_publication_confirmed", "audit_recorded"]:
    require(status[field] is True, f"Incomplete runtime {field}")
for channel in ["stdout", "stderr"]:
    require(len(runtime[channel].encode()) == status["log_bytes"][channel]["seen"] == status["log_bytes"][channel]["stored"], "Saved runtime channel byte count differs")
    require(status["log_errors"][channel] is None and status["log_synced"][channel] is True and status["log_truncated"][channel] is False, "Saved runtime output custody differs")
runtime_lines = [json.loads(line) for line in runtime["stdout"].splitlines() if line.startswith("{")]
spellings = [line for line in runtime_lines if "spelling_result" in line]
require(len(spellings) == 2, "Unexpected spelling run count")
spell_command = ["/home/qq/work/hepta-modules40-20261105-da8578/tools/codespell-2.4.3/bin/codespell", "--ignore-words", ".codespellignore", "--skip", "./.git"]
for row, label, source, tree, exit_code in [(spellings[0], "codespell-red", BB55, BB55_TREE, 65), (spellings[1], "codespell-code-green", CODE, CODE_TREE, 0)]:
    require(row["spelling_result"] == label and row["command"] == spell_command and row["version"] == "2.4.3" and row["exit"] == exit_code, "Spelling command/version/exit differs")
    require(row["source_before"] == row["source_after"] == {"commit": source, "tree": tree, "status": ""}, "Spelling source identity differs")
    require(row["cwd"] == "/home/qq/work/hepta-modules40-20261105-da8578/source" and row["start_unix_ns"] < row["end_unix_ns"] < status["at_unix_ms"] * 1000000, "Spelling cwd/timing differs")
require(spellings[0]["end_unix_ns"] < spellings[1]["start_unix_ns"], "Spelling stage ordering differs")
published = [line for line in runtime_lines if "spelling_navigation_source" in line]
require(len(published) == 1 and published[0]["raw_sha256"] == digest(export_path.read_bytes()) and published[0]["raw_bytes"] == export_path.stat().st_size and published[0]["spelling_navigation_source"] == export["source"], "Runtime navigation export custody differs")

for path, data in final.items():
    write_exact(OUT / "reconstructed-final" / path, data)
inventory = {"schema": "hepta.independent-successor40-navigation-audit.v1", "sourceCommit": CANONICAL, "sourceTree": TREE,
             "files": rows, "sourceHistory": [{"path": path, "blob": git_hash("blob", final[path]), "sha256": digest(final[path]), "bytes": len(final[path])} for path in OLD_LEDGERS + [NEW_LEDGER]]}
save_json("final40-blobs.json", inventory)
result = {"schema": "hepta.independent-successor-source-audit.v1", "status": "PASS_SOURCE_IDENTITY_AND_NAVIGATION",
          "nativeQualificationStatus": "PENDING_C5_RAW_RECEIPT_AND_JUNIT", "canonical": objects["final"], "codeParent": objects["code"], "nativeNavigation": objects["nativeNavigation"],
          "fixture": {"path": FIXTURE_PATH, "beforeBlob": git_hash("blob", before), "afterBlob": git_hash("blob", after),
                      "beforeSha256": digest(before), "afterSha256": digest(after), "onlyChangedLine": 82, "allOtherBytesIdentical": True,
                      "runtimeUtf8Hex": "68656c", "runtimeUtf8Length": 3, "singleDeltaAndOrderingPreserved": True,
                      "unchangedTests": [name.decode() for name in test_names], "allAssertionsAndBudgetsUnchanged": True,
                      "configurationWorkflowIgnoresProductionChanges": False, "rustReference": "https://doc.rust-lang.org/reference/expressions/literal-expr.html#7-bit-escapes"},
          "navigation": {"maps": 40, "operations": 371, "sourceRootsPresent": 40, "productionFalse": 40, "historicalSourceBasesPreserved": 40,
                         "claimBoundariesPreserved": 40, "repositoryControlledGapsUnchanged": 108, "externalEvidenceGatesUnchanged": 140,
                         "changedMaps": [MAP_PATH], "changedJsonPointers": ["/observedAtHead/commit", "/observedAtHead/tree"],
                         "oldHistoryLedgersPreservedByteForByte": 2, "newHistoryLedgerCount": 1, "totalHistoryLedgers": 3,
                         "operationsExactlyUnchanged": True, "executionEvidenceTransferred": False, "qualificationAfterCommitRequired": True},
          "reportCrossCheck": {"all40MapBytesEqual": True, "allRawMapFieldsEqual": True, "all3HistoryBytesEqual": True,
                               "manifest": record(report_manifest_path), "facts": record(facts_path)},
          "matchedCodespellStageReceipts": {"runtime": record(runtime_path), "jobId": status["job_id"], "receipts": spellings,
                                           "rawStageLogHashCheck": "PENDING_DELTA_ARCHIVE", "identityTransferredToC5": False},
          "preservation": {"bb55AuditFiles": 50, "allOriginalBytesVerified": True},
          "actions": "Read local artifacts plus fixed-commit GitHub GET comparisons/files and the Rust Reference; no native runs, runtime calls, source mutations, or refs changes.",
          "limits": ["C5 original native and Codespell results require their own saved terminal receipt and raw evidence.",
                     "Recorded bb55 RED and c486 GREEN Codespell receipts remain bound to those source identities.",
                     "Same-tree native navigation and canonical commits retain separate identities.",
                     "Source-navigation status does not establish production activation, deployment qualification, real-provider closure or platform acceptance."]}
save_json("source-audit-results.json", result)
print(json.dumps({"status": result["status"], "canonical": CANONICAL, "tree": TREE, "maps": 40, "operations": 371,
                  "productionFalse": 40, "changedMapCount": 1, "historyLedgers": 3, "preservedBb55AuditFiles": 50,
                  "nativeQualificationStatus": result["nativeQualificationStatus"], "inventorySha256": digest((OUT / "final40-blobs.json").read_bytes())}, ensure_ascii=False))
