# C5 源码、身份与导航独立审计

**源码审计结论：`PASS_SOURCE_IDENTITY_AND_NAVIGATION`。原生资格状态：`PENDING_C5_RAW_RECEIPT_AND_JUNIT`。** 此文件记录新原生归档到齐之前已经建立的事实；后续原生结论应新增独立报告，不回写这里的阶段状态。

## 1. 固定身份

| 阶段 | Commit | Tree | Parent |
| --- | --- | --- | --- |
| 已冻结 bb55 | `bb55b0d7d263c396ec504c45393d938c3428dae5` | `19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1` | 保留既有审计 |
| 字面量修复 | `c4863123b65f895be0eb14e0958d5cfe6c9c78bd` | `81e2217141060f123adbe1da78c3dbecf57f3073` | bb55 |
| Canonical C5 | `797116d61cf422c26274ffef31297dce84a53a80` | `67ce024db1679aa6cd301856ba3a694ea18bc4b6` | c486 |
| Native navigation | `c77786bd2b786b801197dad684f6f5af1a3d5af5` | `67ce024db1679aa6cd301856ba3a694ea18bc4b6` | c486 |

对 `integration/canonical-spelling-{code,final}-object.json` 的原始字节重新计算 Git commit 对象 SHA-1，结果与对应 metadata 的 commit、tree、parent、作者/提交者时间和 message 一致。C5 raw 对象长 340 bytes，SHA-256 为 `24bc549de0bc6e95eb636ca1402562a152de0d8597deea4635f068c26bf696e7`。导航导出中的 native raw 对象也独立计算得到 c777；其 345-byte 对象与 canonical 对象不同，同 tree 不消除二者的执行身份区别。

另行读取了固定 GitHub 的两段 compare 和 C5 的实际文件内容，响应保存在本目录 `inputs/`：bb55 → c486 只有一个测试文件的一行替换；c486 → C5 只有一张 Map 和一份新增 history。没有 workflow、配置、忽略列表、生产代码或其他测试文件变化。

## 2. 最后补丁保留原运行字节与测试切口

固定文件：`codex-rs/hepta-infer-worker-host/src/native_output_tests.rs`。唯一变化是第 82 行：

```diff
-        delta("first", "hel"),
+        delta("first", "he\x6c"),
```

独立检查了整个 preimage/postimage：旧字符串仅出现一次，做这一处替换后得到的完整字节恰好等于 postimage；除此之外没有任何源码字节变化。源码文件长度由 6061 bytes 变为 6064 bytes，运行时的字面量仍是 **3 bytes：`68 65 6c`**。

[Rust Reference 的 7-bit escapes 定义](https://doc.rust-lang.org/reference/expressions/literal-expr.html#7-bit-escapes) 及同页 String literal expressions 说明，普通字符串中的 `\x6c` 表示字符 U+006C，字符串值是对应的 UTF-8 `&'static str`。所以此次替换保留同一个三字节 prefix、同一个 `&str` 参数、同一次 delta 调用及原来的通知顺序；不是将一个 delta 拆成多个事件。

| 文件身份 | Git blob | SHA-256 |
| --- | --- | --- |
| bb55 preimage | `6b5348b24eae3ea59c2a4fdb9c18d369111a7272` | `4b36f8fa7ef821078083079f9d1fdf127cab297dad36fc1e3a5d3260219cb75d` |
| C5 postimage | `42f35deccbf558be66ddd906fb423a18ebfb84f7` | `0366e3be147bac2a0839de76bd0ae3428d7fc57d9a783bcba8543f9c19dd462b` |

固定 GitHub C5 内容与受审 postimage 全字节相等。四个测试名称保持不变：

- `full_message_without_deltas_preserves_terminal_usage_and_local_boundary`
- `completed_items_replace_partial_text_once_in_item_order`
- `completed_text_and_deltas_share_an_atomic_byte_limit`
- `empty_messages_and_item_ids_cannot_grow_unbounded_metadata`

完整 `hello later` 输出比较、第二个 completion 的重复通知、unwitnessed suffix/conflicting completion 的拒绝、整体 output 比较、usage/boundary、byte limit 和 metadata limit 断言都原样保留。没有增加 skip、ignore、重试、timeout/budget 或改变 profile。这里的运行字节等价判断来自 Rust 语言定义和精确源码比较，本审计没有执行 Rust 编译或测试。

## 3. 40 张 Map 与三份 history

使用已冻结的 `recovery/final-candidate-audit/reconstructed-final/` 中 40 张 bb55 Map 和两份历史 ledger 作为起点，仅叠加 `integration/spelling-navigation-export.json` 的两个已核验导出文件。重建结果在本目录 `reconstructed-final/`。

| 核验项 | 结果 |
| --- | --- |
| Module Maps | 40 |
| Operations | 371，逐项原值保持 |
| sourceRootPresent | 40 个 true |
| productionImplementation | 40 个 false，含 claimBoundary 中的对应字段 |
| 历史 sourceBase / claimBoundary | 全部 40 张保持原值 |
| repositoryControlledGaps | 原 108 条完整保留 |
| externalEvidenceGates | 原 140 条完整保留 |
| 变更的 Map | 仅 `inference.worker` |
| 变更的 JSON 字段 | 仅 `/observedAtHead/commit` 和 `/observedAtHead/tree` |
| Source history | 原两份逐字节保留，新增第三份，共 3 份 |

该 Map 的 observedAtHead 从 `38bd86af… / 62f767b3…` 更新为代码父本 `c4863123… / 81e22171…`；其历史 sourceBase 仍为 `de47d561… / b1d01b56…`。operations、owner/caller/writer、roots、所有门槛和 claimBoundary 没有借此升级。新 Map blob 为 `8ad25b2f06c9d48dab97eb89cb0ccc244e0f75d3`，SHA-256 为 `eb7af971ed46e79f800a327f7c5d73234587687512cf46a3e50bc91ee8032c40`。

| History | SHA-256 |
| --- | --- |
| `source-navigation-history.json` | `485bc0826092755850f2722320c8e7aeb653e6c77047c97fdc56f6b56216f0e7` |
| `source-navigation-history-final.json` | `7ec6f404b3c5438bece2170b19ded4ff785cacbafa8e610fa1ab53ea794546a3` |
| 新 `source-navigation-history-spelling.json` | `ac5e4805fa60d849fbbf85caa803b4b760845676bed5f87a80a10b91e05dd68d` |

第三份 ledger 的 previousMap blob、SHA-256 和字节数都对应原 inference.worker Map；previous/replacement sourceBase 相等，原 claimBoundary 和 observation 均完整保存。其 `scope` 为 `source_navigation_only`，`executionEvidenceTransferred`、`qualificationRulesModified`、`historicalSourceBasesModified`、`historicalExecutionRecordsModified` 均为 false，`qualificationAfterCommitRequired` 为 true。

独立 40-blob 清单为 `final40-blobs.json`，SHA-256：`1ddcfe519a2eba43eb8ea0f520163cc53c809cbc13cc2a92eb3490f7babacabe`。这 40 张 Map 及三份 history 已与 `successor-report-prep/source-snapshot/` 全字节交叉一致；新报告 facts 对每张 Map 的每一个原字段也逐项相等。registry 继续匹配原 blob `2571766d45a0a6b0db0ec83e675c70609d3bc39d`。

## 4. 已保存 Codespell 阶段回执的身份边界

`integration/runtime-receipts/spelling-navigation-run1-runtime.json` 保存的独立 job 为 `1a1ac7fea48-fc05-54c8`，终态 succeeded / exit 0，输出完整持久化，无取消、超时、automatic retry 或截断。stdout/stderr 保存字节数与状态中的 seen/stored 数量一致。

其 stdout 中有两份按顺序保存的 Codespell 2.4.3 阶段回执，两次使用相同原参数 `--ignore-words .codespellignore --skip ./.git`、相同执行文件和仓库根目录，阶段前后源码状态各自干净：

| 阶段 | 绑定身份 | 记录 exit |
| --- | --- | ---: |
| Codespell RED | bb55 / tree19116 | 65 |
| Codespell code GREEN | c486 / tree81e221 | 0 |

这验证了已保存回执的命令、版本、顺序、源码身份和终态一致性。**阶段原始 `.log` 的独立摘要核验仍等 delta 归档；这两份回执不作为 C5 上 Codespell 或原生测试通过的替代。** C5 的 `seven-package-run3`、7 个 strict check、原 6 scope 和新增 Codespell 都要使用 C5 自己的终态回执与原始输出。

## 5. 保全与本审计范围

bb55 独立审计目录的全部 **50 个文件**均对照已冻结的根文件摘要和 Map/history 清单重新验证；没有新增、缺失或修改。逐项记录为 `bb55-audit-preservation.json`。旧 PRELIMINARY、旧 FINAL 原生报告及旧失败历史均保持原样。

本轮仅进行保存文件读取、固定 GitHub GET、Rust Reference 读取、哈希和 JSON 字段比较。没有调用 runtime、运行 native 测试、修改源工作区或 refs。源码导航完整并不建立真实 provider 接入、生产 writer composition、完整恢复闭环、部署资格、独立批准链或 activation，也不改变 108 条仓库门槛和 140 条外部验收门槛。

可复核入口：

```bash
python3 /workspace/scratch/da8578abae00/recovery/successor-candidate-audit/audit_successor_source.py
```

该入口只使用已经保存的输入，不重新发起 GitHub、runtime 或 native 操作；已有输出若与重建字节不同便拒绝覆盖。
