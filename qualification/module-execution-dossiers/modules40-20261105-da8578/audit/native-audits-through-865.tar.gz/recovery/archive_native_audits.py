#!/usr/bin/env python3
"""Preserve staged historical audits and append the final fixed-source audit."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'integration/native-audits-through-865.tar.gz'
STAGING = ROOT / 'recovery/audit-history-staging/MANIFEST.json'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def main():
    assert not DEST.exists(), 'Preserve the existing final audit archive.'
    staging = json.loads(STAGING.read_bytes())
    files = {}
    for entry in staging['entries']:
        data = (ROOT / entry['path']).read_bytes()
        assert len(data) == entry['bytes'] and digest(data) == entry['sha256'], entry['path']
        files[entry['path']] = data
    staged_count = len(files)
    files[STAGING.relative_to(ROOT).as_posix()] = STAGING.read_bytes()

    def add(path):
        assert path.is_file() and not path.is_symlink(), path
        name = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        if name in files:
            assert files[name] == data, name
        files[name] = data

    for path in sorted((ROOT / 'recovery/complete-candidate-audit').rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add(path)
    for path in sorted((ROOT / 'integration/complete-native-download').glob('*.json')):
        add(path)
    for name in [
        'recovery/archive_native_audits.py',
        'recovery/complete-native-audit-command.json',
        'integration/complete-native-archive-download-verification.json',
        'integration/complete-native-checkpoint/MANIFEST.json',
        'integration/complete-archive-launch-arguments.json',
        'integration/canonical-complete-object.json',
        'integration/canonical-complete-object.verification.json',
        'candidate-review/upstream-3a39/NATIVE-MERGE-EXPORT-AUDIT.json',
        'candidate-review/upstream-3a39/CI-SCOPE-PRESERVATION.json',
        'candidate-review/upstream-3a39/UPSTREAM-INTEGRATION-REVIEW.zh.md',
    ]:
        add(ROOT / name)
    for name in [
        'final-canonical-bb55-runtime-status.json',
        'spelling-canonical-797-runtime-status.json',
        'spelling-navigation-run1-runtime.json',
        'codespell-setup-run1-runtime-status.json',
        'windows-canonical-775-runtime-status.json',
        'complete-canonical-865-runtime-status.json',
        'upstream-3a39-integration-runtime-status.json',
        'complete-archive-initial-transport-error.json',
        'complete-archive-launch-recovery.json',
        'complete-archive-runtime-status.json',
    ]:
        add(ROOT / 'integration/runtime-receipts' / name)
    dependencies = list(staging['native_checkpoint_dependencies'])
    final_archive = ROOT / 'integration/native-865-checkpoint.tar.gz'
    dependencies.append({'path': final_archive.relative_to(ROOT).as_posix(),
                         'bytes': final_archive.stat().st_size, 'sha256': digest(final_archive.read_bytes()),
                         'included_in_audit_archive': False,
                         'reason': 'Separate final native checkpoint; all its members are independently checked by the included final audit.'})
    for item in dependencies:
        data = (ROOT / item['path']).read_bytes()
        assert len(data) == item['bytes'] and digest(data) == item['sha256']
    reports = []
    for folder in ['final-candidate-audit', 'successor-candidate-audit', 'windows-candidate-audit', 'complete-candidate-audit']:
        name = 'recovery/' + folder + '/FINAL-NATIVE-AUDIT.json'
        report = json.loads(files[name])
        reports.append({'path': name, 'sha256': digest(files[name]), 'source': report['source'],
                        'status': report['status'], 'native_job': report['authoritative_runtime']['job_id']})
    final = json.loads(files['recovery/complete-candidate-audit/FINAL-NATIVE-AUDIT.json'])
    assert final['source']['commit'] == '8658210499706130788c216ff14fd342809b45a4'
    assert final['status'] == 'CLEAN_WITHIN_RECORDED_SCOPE'
    assert len(final['scope_checks']) == 8 and len(final['strict_checks']) == 7
    assert final['source_binding']['bound_receipts'] == 18
    assert final['windows_ci_receipt_controls']['tests'] == 28
    assert final['windows_ci_receipt_controls']['windows_test_execution_established'] is False
    readme = '''# Native evidence audit history through 86582104

This archive preserves the independent bb55, 797, 775 and final 865 audit reports,
their source/navigation reviews, the read-only 797 collection provenance, the
version-pinned final archive download provenance, authoritative runtime receipts,
and all three versions of the local native evidence auditor.

The four native checkpoint archives are separate dependencies, listed with exact
byte counts and SHA256 values in MANIFEST.json. They are not duplicated here.
The original run1 failure remains in the immutable bb55 base checkpoint history.

All 166 files staged before the final 865 audit remain byte-identical. Preparation
notes retain their historical pending status; the manifest and final audit record
the later completed result without rewriting those notes or earlier experiments.

797 was collected using independently versioned file APIs after a separate
archive request remained launch_unknown. It is explicitly not an atomic
cross-file snapshot, and its collector never replayed that archive request.
865's archive launch suffered a transport timeout; same-argument/same-key recovery
returned reused=true, and the separate archive job then had an authoritative
succeeded/exit-0 receipt. Neither event is recast as another test execution.

The final 865 Linux scope passed 1,219 cases (78 existing-profile skips), the 69
required-case audit, seven strict gates, 319 library cases, five selected AppServer
process cases, original Codespell and formatting/Clippy commands, and 28 Python
CI receipt-control cases. The latter do not establish Windows native execution.
Stable rustfmt ignores the nightly-only imports_granularity option; the original
three Clippy policies do not mean -D warnings. All production, platform,
real-provider and activation qualification boundaries remain unchanged.
'''.encode()
    files['README.md'] = readme
    manifest = {'schema': 'hepta.native-audit-history-archive.v1', 'source': final['source'],
                'created_unix_ns': time.time_ns(), 'status': 'CLEAN_WITHIN_RECORDED_LINUX_SCOPE',
                'scope': 'Independent reports, parsers, source/navigation review and read/download custody. Native payload archives remain separate exact-hash dependencies.',
                'staging_manifest': {'path': STAGING.relative_to(ROOT).as_posix(), 'sha256': digest(STAGING.read_bytes()),
                                     'entries': staged_count, 'all_original_bytes_preserved': True},
                'native_checkpoint_dependencies': dependencies, 'audit_reports': reports,
                'final_required_clean': 69, 'final_passed': 1219, 'final_skipped': 78,
                'final_bound_execution_receipts': 18, 'final_strict_checks': 7, 'final_scope_checks': 8,
                'windows_receipt_controls_are_not_windows_native_execution': True,
                'entries': [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(files.items())]}
    files['MANIFEST.json'] = encoded(manifest)
    manifest_path = ROOT / 'recovery/native-audits-through-865-manifest.json'
    assert not manifest_path.exists()
    manifest_path.write_bytes(files['MANIFEST.json'])
    with DEST.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, data in sorted(files.items()):
                    entry = tarfile.TarInfo(name)
                    entry.size = len(data)
                    entry.mode = 0o644
                    entry.mtime = 0
                    archive.addfile(entry, io.BytesIO(data))
    with tarfile.open(DEST, 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(files) and all(member.isfile() for member in members)
        for member in members:
            assert archive.extractfile(member).read() == files[member.name]
    metadata = {'archive_path': str(DEST), 'bytes': DEST.stat().st_size, 'sha256': digest(DEST.read_bytes()),
                'files': len(files), 'manifest_entries': len(manifest['entries']),
                'manifest_path': str(manifest_path), 'manifest_sha256': digest(files['MANIFEST.json']),
                'all_staged_files_preserved': staged_count, 'source': final['source'],
                'all_archive_entries_read_back_and_verified': True}
    path = ROOT / 'integration/native-audits-through-865-metadata.json'
    assert not path.exists()
    path.write_bytes(encoded(metadata))
    print(json.dumps(metadata, ensure_ascii=False))


if __name__ == '__main__':
    main()
