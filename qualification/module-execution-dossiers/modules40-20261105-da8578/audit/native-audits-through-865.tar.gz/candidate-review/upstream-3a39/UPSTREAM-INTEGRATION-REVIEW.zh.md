# 固定并发上游 3a39 的无损整合审核

审核输入为 base `07378034e060f23259bc99c7367f12b1284140f3`、ours `775bf555b0a7faf6eed17627acb0d0433294b737`、theirs `3a39c799a3f776b0aeedfce350341d865d3cc1c4`。本审核只读 API 与本地文件；没有更改远程源码、分支、CI 或任务状态。

## 原始历史与 Git 对象

以下 8 个并发提交按原父链保留。所有提交均 unsigned；每份完整 Git metadata 已保存，重建 raw commit bytes 后逐个核对原 SHA。依据每一步的父 tree 与完整文件 postimage，重新计算 8 个目标 tree，全部匹配。

| 提交 | 内容 | 原 tree |
| --- | --- | --- |
| e5c3f72be991a2fef223170b547142af9820a04f | AppServer initialize 返回值 | ddff7cd8bdac93112682c4fbd1497e348e0a93a0 |
| 22b4a16ace0b97aaf490b05eb5ee39bcb65c8c34 | Windows 沙箱 assert_eq 明确引用 | 71bdd5ec76b1bf20497c2b2000bb99d68a1a0127 |
| f2fd6c66c30d393226fb1282e1ec005004356dc2 | Windows PTY AsRawHandle 明确引用 | 717f3c575dcabfc9c87a95b23559abb7cbe039f0 |
| a25fec842bb492556108dc9c5b20ac66a0b2ed2b | AppServer-client trace: None | deaff175ca8d734ce901845c15a9682797fba141 |
| daa46e7d1a5a2b7038eec5aabb96aa2189c7ce73 | 保留原 OpenSSH 子进程的测试诊断 | c1ff0bf3d073767a2209f1d4300e31de68103699 |
| de7f7ac83922ba6a477adf6adbfe2c7607163307 | 固定分片、原日志、编译 helper bytes 绑定 | 4dc64fdc1dcba84665c10007d232764cee2469d8 |
| a045ce9d58170b9d0c4d868bb977d5debf8c9aa2 | 两个互斥原始范围分片与完整聚合 | eaa46cf173b8df6879e0d635a983dd85e5dc21c8 |
| 3a39c799a3f776b0aeedfce350341d865d3cc1c4 | 覆盖每个原包的工作流触发路径 | f83f9dfc55bda251e05746d1c60a4d26f157e752 |

同时核验了 62 个完整 Git tree 节点和 18 个唯一 blob。文件 mode 来自 immutable tree API，不靠扩展名猜测。两个 workflow 中间版本分别保留，不以最终文件替代历史提交。

## 9 路三方审核

| 文件 | 合并裁决 |
| --- | --- |
| `.github/scripts/aggregate_windows_current_ci.py` | ours/base 均不存在；完整保留 upstream 新文件 |
| `.github/scripts/test_windows_current_ci_shards.py` | ours/base 均不存在；完整保留 upstream 新文件 |
| `.github/scripts/windows_current_ci.py` | ours 与 base 相同；完整保留 upstream |
| `.github/workflows/hepta-windows-current-ci.yml` | ours 与 base 相同；完整保留 upstream |
| `codex-rs/app-server-client/src/remote_process_indeterminate_tests.rs` | ours 与 upstream 已是完全相同的 blob |
| `codex-rs/app-server/tests/suite/v2/process_exec.rs` | ours 与 upstream 已是完全相同的 blob |
| `codex-rs/hepta-operator-acceptance/src/openssh_windows.rs` | ours 与 base 相同；完整吸收 upstream 诊断，再记录 native formatter 的限定变化 |
| `codex-rs/utils/pty/src/win/native_observation_tests.rs` | 唯一实际文本冲突；保留 ours 已审核的同一调用换行格式 |
| `codex-rs/windows-sandbox-rs/src/unified_exec/delete_permission_tests.rs` | ours 与 upstream 已是完全相同的 blob |

所有 9 路均执行未设置偏好侧、未忽略空白的原 `git merge-file` 算法，原始输出与退出码单独保留。PTY 的冲突仅来自同一个 `match unsafe { WaitForSingleObject(...) }` 头部的换行。精确替换证明两侧除这一处格式外完全相同；三处明确限定的 `AsRawHandle`、访问权限、等待、期限和清理逻辑均保留。

## CI 与诊断保持情况

最终采用的四个 CI 文件与 3a39 原字节相同。原始 scope manifest 在 ours775 与 theirs3a39 的 Git blob 同为 `bffedc4c1d8634594958859ecb9b3aae54e582b1`，确有 **19 组、167 个要求用例**。原 `assess` 与 `valid_source` 函数正文逐字节未改；原命令保留 `--retries 0`。非 PASS 的终态、缺失要求用例、数量或包不匹配、非零退出都仍使资格失败；新的聚合器额外要求两个分片和原始单次 Nextest 运行封套。

OpenSSH 原始执行路径、可执行文件固定、环境、stdio、未知子进程保管没有被替换。新增内容是 `cfg(test)` 下的有界诊断。后续 native rustfmt 只产生四处格式 hunk：四处换行以及两个单参数 `Error::other` 调用的可选尾逗号。严格说并非“仅空白”；已用精确四项替换证明所有诊断字符串及其余字节不变。

## 实际 native merge export 的独立核验

父任务提供的 export SHA-256 为 `2486c4784e87b6b8e4b5c62227bcd5d9d5c22b65b72d18b265df1d7405b1b7b0`。其真实 `git merge --no-ff --no-commit 3a39...` 记录唯一 PTY 冲突，与本地三方审核一致。

从 immutable ours775 的完整 tree 与 export 的 **5 个实际变更 postimage** 独立重算，结果为 `6bc86196d10cf83b010f9917e5e9cb471b5f6b68`。raw native commit 重算为 `c2834dcade885fb9ff5da41b3947773067ec652d`；有序 parents 为 775、3a39。8 个上游原提交的 SHA、tree、父链和变更路径均一致，四个 CI 文件逐字节保留。

格式化前的 `1ea655ddf48618ad81105c8976e80c25f44db3dc` 只是独立计算的预期 tree。没有单独 native `write-tree` 回执，因此没有将其写成实际观测。

## 可导入材料与边界

- `native-import-bundle.json`：8 个原 raw commit、每一步完整 postimage、9 路审核结果。SHA-256 `da84194262d2aa04e0f323be8b2b94b21d6f8626dea85b8216e70a7bedaf1893`。
- `native-import-bundle.json.xz`：29,888 bytes；SHA-256 `a5157b920dd745fe525be47d3f5dcd25a475ac7efd9d753876c7d04a18ffa686`。
- `SOURCE-MERGE-AUDIT.json`、`NATIVE-MERGE-EXPORT-AUDIT.json`、`CI-SCOPE-PRESERVATION.json`：对象、合并与范围核验。
- `OPENSSH-NATIVE-FORMAT.patch`：四处精确格式变化。
- `git-metadata/`、`commit-details/`、`tree-metadata/`、`objects/`、`postimages/`、`snapshots/`、`merge-file-raw/`：完整原始输入与中间结果。

源码整合和格式审计不等于合并后测试通过。本审核未继承 775、797 或 bb55 的执行结论，也不关闭 Windows、Bazel、真实外部器官和生产门槛。
