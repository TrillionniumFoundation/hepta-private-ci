# 797116d6 native checkpoint collected through read-only file APIs

This archive contains the native execution outputs for canonical source
797116d61cf422c26274ffef31297dce84a53a80, tree
67ce024db1679aa6cd301856ba3a694ea18bc4b6. The native execution completed
successfully as job 1a1ac84ead1-fc05-54ef before this collection.

Every remote file was read independently. Small files carry their complete UTF-8
payload, version token and SHA256. Large files were read in bounded chunks pinned
to one version, with every chunk hash checked against the assembled bytes. This
is not a cross-file atomic snapshot. Source identity comes from the recorded
before/after native receipts, not from a claim about the later remote checkout.

A separate remote archive request was reported as launch_unknown. The collector
did not replay that request. This local archive was created from read-only file
API results and records that distinction in READ-CUSTODY.json.

The immutable bb55 checkpoint remains the base history. Its original failures,
earlier successes and source identities are not recast as results on 797116d6.
This checkpoint establishes only the recorded Linux scopes. Production flags,
platform qualification, real-provider acceptance and activation are unchanged.
