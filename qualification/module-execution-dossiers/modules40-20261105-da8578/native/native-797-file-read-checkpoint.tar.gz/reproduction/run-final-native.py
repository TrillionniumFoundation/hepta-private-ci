from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('--candidate-commit', required=True)
parser.add_argument('--candidate-tree', required=True)
parser.add_argument('--run-label', required=True)
args = parser.parse_args()
assert re.fullmatch(r'[a-z0-9-]+', args.run_label)
ROOT = Path('/home/qq/work/hepta-modules40-20261105-da8578')
REPO = ROOT / 'source'
EVIDENCE = ROOT / 'evidence'
AUDIT = ROOT / 'audit-tools'
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'environment.json').read_text()))


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=REPO, text=True).strip()


def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    assert not path.exists(), 'evidence must not overwrite an earlier attempt: ' + str(path)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def execute(name, argv, cwd=REPO):
    before = identity()
    assert before == EXPECTED
    log = EVIDENCE / (args.run_label + '-' + name + '.log')
    assert not log.exists()
    record = {'command': argv, 'cwd': str(cwd), 'source_before': before,
              'start_unix_ns': time.time_ns(), 'environment_sha256': digest(ROOT / 'environment.json')}
    start = time.monotonic()
    with log.open('wb') as output:
        process = subprocess.Popen(argv, cwd=cwd, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in process.stdout:
            output.write(line)
            if any(token in line for token in [b'Summary', b'FAIL', b'error:', b'FAILED', b'Finished', b'Ran ', b'OK']):
                sys.stdout.buffer.write(line)
                sys.stdout.buffer.flush()
        code = process.wait()
    record.update(exit=code, elapsed_seconds=time.monotonic() - start, end_unix_ns=time.time_ns(),
                  source_after=identity(), log_path=str(log), log_sha256=digest(log), log_bytes=log.stat().st_size)
    write_json(EVIDENCE / (args.run_label + '-' + name + '.json'), record)
    print(json.dumps({'command_terminal': name, **record}), flush=True)
    assert record['source_after'] == before, 'checkout changed during execution'
    return record


EXPECTED = {'commit': args.candidate_commit, 'tree': args.candidate_tree, 'status': ''}
assert identity() == EXPECTED
PACKAGES = ['codex-hepta-agent-protocol', 'codex-hepta-agentd', 'codex-hepta-infer-worker-host',
            'codex-hepta-runtime', 'codex-hepta-contracts', 'codex-hepta-learning-ledger', 'codex-hepta-supervisor']
prefix = EVIDENCE / args.run_label
manifest = EVIDENCE / (args.run_label + '-required-tests.69.source-bound.json')
metadata = EVIDENCE / (args.run_label + '-original-scoped-metadata.json')
junit = EVIDENCE / (args.run_label + '.junit.xml')
audit_report = EVIDENCE / (args.run_label + '-required-tests.69.native-audit.json')
report_config = ROOT / (args.run_label + '-report-only.nextest.toml')
for path in [manifest, metadata, junit, audit_report, report_config]:
    assert not path.exists(), 'existing evidence or configuration: ' + str(path)

binding = execute('bind-manifest', ['python3', str(AUDIT / 'bind_native_audit_manifest.py'),
    '--repo', str(REPO), '--review-manifest', str(AUDIT / 'required-tests.69.json'),
    '--candidate-commit', args.candidate_commit, '--candidate-tree', args.candidate_tree,
    '--output', str(manifest)])
assert binding['exit'] == 0
metadata_argv = ['cargo', 'metadata', '--no-deps', '--format-version=1', '--locked']
metadata_start = time.monotonic()
metadata_process = subprocess.run(metadata_argv, cwd=REPO / 'codex-rs', env=ENV, capture_output=True)
metadata_elapsed = time.monotonic() - metadata_start
assert metadata_process.returncode == 0, metadata_process.stderr.decode(errors='replace')
metadata.write_bytes(metadata_process.stdout)
assert identity() == EXPECTED
report_config.write_text('[profile.local.junit]\npath = ' + json.dumps(str(junit)) + '\n')
tools = {}
for name, command in [('rustc', ['rustc', '--version']), ('cargo', ['cargo', '--version']),
                      ('rustfmt', ['rustfmt', '--version']), ('clippy', ['cargo', 'clippy', '--version']),
                      ('just', ['just', '--version']), ('nextest', ['cargo', 'nextest', '--version'])]:
    result = subprocess.run(command, cwd=REPO, env=ENV, capture_output=True, text=True, check=True)
    tools[name] = {'command': command, 'executable': shutil.which(command[0], path=ENV['PATH']), 'version': result.stdout.strip()}
argv = ['just', 'test', '--locked']
for package in PACKAGES:
    argv += ['-p', package]
argv += ['--tool-config-file', 'hepta-evidence:' + str(report_config), '--cargo-metadata', str(metadata)]
preflight = {'source': EXPECTED, 'packages': PACKAGES, 'command': argv, 'cwd': str(REPO),
    'original_profile': 'local', 'required_cases': 69, 'filter_used': False, 'toolchain': tools,
    'review_manifest_sha256': digest(AUDIT / 'required-tests.69.json'), 'source_bound_manifest_sha256': digest(manifest),
    'report_only_config': {'path': str(report_config), 'content': report_config.read_text(), 'sha256': digest(report_config)},
    'metadata': {'command': metadata_argv, 'cwd': str(REPO / 'codex-rs'), 'exit': metadata_process.returncode,
                 'elapsed_seconds': metadata_elapsed, 'sha256': digest(metadata)},
    'selected_environment': json.loads((ROOT / 'environment.json').read_text()),
    'scope': 'seven complete packages with original local profile, timeout, retry and assertions; reporting configuration only'}
write_json(EVIDENCE / (args.run_label + '-preflight.json'), preflight)
test = execute('original-test', argv)
native_log = Path(test['log_path']).read_text(errors='replace')
summaries = [line for line in native_log.splitlines() if 'Summary' in line and 'tests run:' in line]
result = {'source': EXPECTED, 'runner_exit': test['exit'], 'native_summary': summaries[-1] if summaries else None,
          'packages': PACKAGES, 'preflight_sha256': digest(EVIDENCE / (args.run_label + '-preflight.json')),
          'original_test_receipt_sha256': digest(EVIDENCE / (args.run_label + '-original-test.json'))}
if junit.exists():
    result['junit'] = {'path': str(junit), 'sha256': digest(junit), 'bytes': junit.stat().st_size,
                       'mtime_ns': junit.stat().st_mtime_ns, 'fresh_for_run': junit.stat().st_mtime_ns >= test['start_unix_ns']}
    assert result['junit']['fresh_for_run']
    xml = ET.parse(junit)
    result['junit_case_count'] = len(list(xml.iter('testcase')))
    audit = execute('required-audit', ['python3', str(AUDIT / 'audit_native_junit.py'),
        '--review-manifest', str(AUDIT / 'required-tests.69.json'), '--manifest', str(manifest),
        '--candidate-commit', args.candidate_commit, '--candidate-tree', args.candidate_tree,
        '--junit', str(junit), '--suite-exit-code', str(test['exit']), '--report', str(audit_report)])
    result['audit_exit'] = audit['exit']
else:
    result['audit_exit'] = None
    result['audit_not_run_reason'] = 'original runner did not produce native JUnit'

checks = [
 ('maps-qualification', ['python3', 'scripts/hepta-implementation-maps.py', 'verify', '--profile', 'qualification',
      '--expected-sha', args.candidate_commit, '--expected-tree', args.candidate_tree]),
 ('status-facts', ['python3', 'scripts/test_hepta_module_status_facts.py']),
 ('module-registry', ['python3', 'scripts/hepta_module_registry.py', '--strict', '--pretty']),
 ('documents-qualification', ['python3', 'scripts/hepta-module-docs.py', 'verify', '--profile', 'qualification']),
 ('chef-custody', ['python3', 'scripts/test_hepta_ci_chef.py']),
 ('rust-ci-feedback', ['python3', 'scripts/test_hepta_rust_ci_feedback.py']),
 ('module-docs-metadata', ['python3', 'scripts/test_hepta_module_doc_metadata.py']),
]
result['qualification_checks'] = {}
for name, command in checks:
    record = execute(name, command)
    result['qualification_checks'][name] = record['exit']
result['source_after'] = identity()
result['complete_unix_ns'] = time.time_ns()
result['qualified_scope'] = 'source regression and navigation only; production and external acceptance remain unchanged'
write_json(EVIDENCE / (args.run_label + '-summary.json'), result)
print(json.dumps({'final_native_summary': result}), flush=True)
if test['exit']:
    sys.exit(test['exit'])
sys.exit(0 if result['audit_exit'] == 0 and all(code == 0 for code in result['qualification_checks'].values()) else 1)
