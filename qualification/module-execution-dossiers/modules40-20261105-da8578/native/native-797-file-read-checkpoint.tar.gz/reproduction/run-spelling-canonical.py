from pathlib import Path
import base64
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/home/qq/work/hepta-modules40-20261105-da8578')
REPO = ROOT / 'source'
EV = ROOT / 'evidence'
COMMIT = '797116d61cf422c26274ffef31297dce84a53a80'
TREE = '67ce024db1679aa6cd301856ba3a694ea18bc4b6'
NATIVE_NAV = 'c77786bd2b786b801197dad684f6f5af1a3d5af5'
LABEL = 'spelling-canonical-run1'
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'environment.json').read_text()))


def git(*args, data=None):
    return subprocess.check_output(['git', *args], cwd=REPO, input=data).decode().strip()


def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(name, data):
    path = EV / (LABEL + '-' + name + '.json')
    assert not path.exists(), path
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


assert identity() == {'commit': NATIVE_NAV, 'tree': TREE, 'status': ''}
preserved = {
    'refs/heads/evidence/da8578-native-spelling-navigation': NATIVE_NAV,
}
for ref, sha in preserved.items():
    git('update-ref', ref, sha, '0' * 40)
    assert git('rev-parse', ref) == sha
payload = json.loads((ROOT / 'spelling-canonical-object.json').read_text())
assert len(payload['commits']) == 1
entry = payload['commits'][0]
assert entry['sha'] == COMMIT
raw = base64.b64decode(entry['raw_base64'], validate=True)
assert hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == COMMIT
assert git('hash-object', '-t', 'commit', '-w', '--stdin', data=raw) == COMMIT
assert git('rev-parse', COMMIT + '^{tree}') == TREE
subprocess.run(['git', 'checkout', '--detach', COMMIT], cwd=REPO, check=True)
EXPECTED = {'commit': COMMIT, 'tree': TREE, 'status': ''}
assert identity() == EXPECTED
save('source-checkout', {'source': EXPECTED, 'raw_commit_base64': entry['raw_base64'],
                        'preserved_native_refs': preserved,
                        'environment_sha256': digest((ROOT / 'environment.json').read_bytes()),
                        'scope': 'canonical source checkout for fresh execution; prior results retain prior identities'})


def run(name, argv, cwd=REPO):
    before = identity()
    assert before == EXPECTED
    path = EV / (LABEL + '-' + name + '.log')
    assert not path.exists()
    start = time.monotonic()
    record = {'command': argv, 'cwd': str(cwd), 'source_before': before,
              'start_unix_ns': time.time_ns(), 'environment_sha256': digest((ROOT / 'environment.json').read_bytes())}
    with path.open('wb') as out:
        proc = subprocess.Popen(argv, cwd=cwd, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in proc.stdout:
            out.write(line)
            if any(token in line for token in [b'Summary', b'FAIL', b'error:', b'error[', b'FAILED',
                                               b'Finished', b'TMT', b'final_native_summary', b'command_terminal']):
                sys.stdout.buffer.write(line)
                sys.stdout.buffer.flush()
        code = proc.wait()
    record.update(exit=code, elapsed_seconds=time.monotonic() - start, end_unix_ns=time.time_ns(),
                  source_after=identity(), log_path=str(path), log_sha256=digest(path.read_bytes()), log_bytes=path.stat().st_size)
    save(name, record)
    print(json.dumps({'canonical_command_terminal': name, **record}), flush=True)
    assert record['source_after'] == before
    return code


runner = ROOT / 'run-final-native.py'
assert digest(runner.read_bytes()) == '9590be884338146913ddec0fc4c0770cd2f134daf69d67c5a4a8bb14d60097eb'
spell = str(ROOT / 'tools/codespell-2.4.3/bin/codespell')
assert subprocess.check_output([spell, '--version'], env=ENV, text=True).strip() == '2.4.3'
checks = {}
checks['original-codespell'] = run('original-codespell', [spell, '--ignore-words', '.codespellignore', '--skip', './.git'])
checks['seven-package-original-runner'] = run('seven-package-original-runner', [
    'python3', str(runner), '--candidate-commit', COMMIT, '--candidate-tree', TREE,
    '--run-label', 'seven-package-run3'])
checks['original-workspace-format'] = run('original-workspace-format', [
    'cargo', 'fmt', '--', '--config', 'imports_granularity=Item', '--check'], cwd=REPO / 'codex-rs')
checks['original-four-package-format'] = run('original-four-package-format', [
    'cargo', 'fmt', '--package', 'codex-utils-path', '--package', 'codex-hepta-prompt-registry',
    '--package', 'codex-hepta-contracts', '--package', 'codex-hepta-agentd', '--', '--check'], cwd=REPO / 'codex-rs')
checks['original-ci-policy-clippy'] = run('original-ci-policy-clippy', [
    'just', 'clippy', '--locked', '-p', 'codex-exec-server', '-p', 'codex-app-server',
    '-p', 'codex-app-server-client', '--', '-D', 'clippy::correctness',
    '-D', 'clippy::await_holding_lock', '-D', 'clippy::await_holding_invalid_type'])
checks['two-library-regression'] = run('two-library-regression', [
    'just', 'test', '--locked', '-p', 'codex-exec-server', '-p', 'codex-app-server-client', '--lib'])
checks['app-server-process-regression'] = run('app-server-process-regression', [
    'just', 'test', '--locked', '-p', 'codex-app-server', '--test', 'all', '-E',
    'test(process_exec)', '--no-tests', 'fail'])
save('summary', {'source': EXPECTED, 'checks': checks, 'source_after': identity(),
                 'complete_unix_ns': time.time_ns(),
                 'scope': 'Linux native seven-package qualification, original pinned Codespell 2.4.3, scoped process regressions and original format/Clippy policies; no production activation or platform qualification transfer'})
print(json.dumps({'final_canonical_checks': checks, 'source': EXPECTED}), flush=True)
sys.exit(0 if all(code == 0 for code in checks.values()) else 1)
