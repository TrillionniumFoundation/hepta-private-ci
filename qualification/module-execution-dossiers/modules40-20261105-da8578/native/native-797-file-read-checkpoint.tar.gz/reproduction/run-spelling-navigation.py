from pathlib import Path
import base64
import hashlib
import importlib.util
import json
import os
import subprocess
import time
import zlib

ROOT = Path('/home/qq/work/hepta-modules40-20261105-da8578')
REPO = ROOT / 'source'
EV = ROOT / 'evidence'
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'environment.json').read_text()))
PAYLOAD = json.loads((ROOT / 'spelling-navigation-input.json').read_text())
BEFORE = 'bb55b0d7d263c396ec504c45393d938c3428dae5'
BEFORE_TREE = '19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1'
CODE = 'c4863123b65f895be0eb14e0958d5cfe6c9c78bd'
CODE_TREE = '81e2217141060f123adbe1da78c3dbecf57f3073'
LABEL = 'spelling-navigation-run1'
LEDGER = 'qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history-spelling.json'
SPELL = str(ROOT / 'tools/codespell-2.4.3/bin/codespell')


def git(*args, data=None, env=None):
    return subprocess.check_output(['git', *args], cwd=REPO, input=data, env=env).decode().strip()


def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    p = EV / (LABEL + '-' + name + '.json')
    assert not p.exists(), p
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def spelling(name):
    before = identity()
    assert before['status'] == ''
    argv = [SPELL, '--ignore-words', '.codespellignore', '--skip', './.git']
    p = EV / (LABEL + '-' + name + '.log')
    assert not p.exists()
    start = time.monotonic()
    stamp = time.time_ns()
    with p.open('wb') as out:
        code = subprocess.run(argv, cwd=REPO, env=ENV, stdout=out, stderr=subprocess.STDOUT).returncode
    receipt = {'command': argv, 'cwd': str(REPO), 'version': '2.4.3', 'source_before': before,
               'source_after': identity(), 'exit': code, 'start_unix_ns': stamp,
               'end_unix_ns': time.time_ns(), 'elapsed_seconds': time.monotonic() - start,
               'log_path': str(p), 'log_bytes': p.stat().st_size, 'log_sha256': digest(p.read_bytes()),
               'scope': 'original Codespell CLI and repository configuration; no ignore or skip changes'}
    assert receipt['source_after'] == before
    save(name, receipt)
    print(json.dumps({'spelling_result': name, **receipt}), flush=True)
    return code, p.read_text()


assert identity() == {'commit': BEFORE, 'tree': BEFORE_TREE, 'status': ''}
setup = json.loads((EV / 'codespell-setup-run1.json').read_text())
assert setup['exit'] == 0 and setup['version'] == '2.4.3'
assert subprocess.check_output([SPELL, '--version'], env=ENV, text=True).strip() == '2.4.3'
original_configs = {p: (REPO / p).read_bytes() for p in ['.codespellignore', '.codespellrc']}
red, red_text = spelling('codespell-red')
assert red != 0
assert 'codex-rs/hepta-infer-worker-host/src/native_output_tests.rs:82: hel ==' in red_text, red_text
row = PAYLOAD['file']
assert row['path'] == 'codex-rs/hepta-infer-worker-host/src/native_output_tests.rs'
assert git('rev-parse', 'HEAD:' + row['path']) == '6b5348b24eae3ea59c2a4fdb9c18d369111a7272'
old = (REPO / row['path']).read_bytes()
new = row['content'].encode()
assert old.count(b'delta("first", "hel")') == 1
assert old.replace(b'delta("first", "hel")', b'delta("first", "he\\x6c")') == new
assert digest(new) == '0366e3be147bac2a0839de76bd0ae3428d7fc57d9a783bcba8543f9c19dd462b'
blob = git('hash-object', '-w', '--stdin', data=new)
assert blob == '42f35deccbf558be66ddd906fb423a18ebfb84f7'
idx = ROOT / 'spelling-code-import.index'
assert not idx.exists()
index_env = ENV.copy()
index_env['GIT_INDEX_FILE'] = str(idx)
git('read-tree', 'HEAD^{tree}', env=index_env)
git('update-index', '--add', '--cacheinfo', '100644,' + blob + ',' + row['path'], env=index_env)
assert git('write-tree', env=index_env) == CODE_TREE
entry = PAYLOAD['object']['commits'][0]
assert entry['sha'] == CODE
raw = base64.b64decode(entry['raw_base64'], validate=True)
assert hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == CODE
assert git('hash-object', '-t', 'commit', '-w', '--stdin', data=raw) == CODE
assert git('show', '-s', '--format=%P', CODE) == BEFORE
subprocess.run(['git', 'checkout', '--detach', CODE], cwd=REPO, check=True)
assert identity() == {'commit': CODE, 'tree': CODE_TREE, 'status': ''}
green, green_text = spelling('codespell-code-green')
assert green == 0, green_text
assert all((REPO / path).read_bytes() == content for path, content in original_configs.items())

helper = ROOT / 'refresh-navigation-explicit-pins.py'
assert digest(helper.read_bytes()) == '940f0fe0d5fccf53dc8d00dacbd4f572cf9b02419704dba0cde35d495f9e7e3b'
spec = importlib.util.spec_from_file_location('navigation_helper', helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
registry = json.loads((REPO / 'docs/modules/MODULES.json').read_text())['modules']
assert len(registry) == 40
maps = {f'docs/modules/{r["id"]}/IMPLEMENTATION_MAP.json': json.loads((REPO / f'docs/modules/{r["id"]}/IMPLEMENTATION_MAP.json').read_text()) for r in registry}
assert sum(len(x['operations']) for x in maps.values()) == 371
assert all(x['productionImplementation'] is False and x['claimBoundary']['productionImplementation'] is False for x in maps.values())
old_ledgers = {p: (REPO / p).read_bytes() for p in [
    'qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history.json',
    'qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history-final.json']}
argv = ['python3', str(helper), '--root', str(REPO), '--expected-sha', CODE,
        '--expected-tree', CODE_TREE, '--ledger', LEDGER]
outputs = {}
for name, command in [('preview', argv), ('apply', argv + ['--apply'])]:
    p = EV / (LABEL + '-' + name + '.log')
    assert not p.exists()
    result = subprocess.run(command, cwd=REPO, env=ENV, capture_output=True)
    p.write_bytes(result.stdout + result.stderr)
    assert result.returncode == 0, p.read_text()
    outputs[name] = json.loads(result.stdout)
    print(json.dumps({name: outputs[name]}), flush=True)
assert outputs['apply']['changedMaps'] > 0
assert outputs['apply']['maps'] == outputs['preview']['maps']
for path, old_map in maps.items():
    new_map = json.loads((REPO / path).read_text())
    assert module.semantic_view(new_map) == module.semantic_view(old_map), path
    assert new_map['sourceBase'] == old_map['sourceBase'], path
assert all((REPO / p).read_bytes() == b for p, b in old_ledgers.items())
ledger_bytes = (REPO / LEDGER).read_bytes()
fmt = EV / (LABEL + '-format.log')
assert not fmt.exists()
with fmt.open('wb') as out:
    subprocess.run(['just', 'fmt'], cwd=REPO, env=ENV, stdout=out, stderr=subprocess.STDOUT, check=True)
assert (REPO / LEDGER).read_bytes() == ledger_bytes
ledger = json.loads(ledger_bytes)
for row in ledger['records']:
    assert digest((REPO / row['mapPath']).read_bytes()) == row['replacementSha256']
assert set(git('diff', '--name-only').splitlines()) == set(outputs['apply']['maps'])
assert git('ls-files', '--others', '--exclude-standard').splitlines() == [LEDGER]
paths = sorted(outputs['apply']['maps'] + [LEDGER])
subprocess.run(['git', 'diff', '--check'], cwd=REPO, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=REPO, check=True)
subprocess.run(['git', 'commit', '-m', 'Refresh source pins after byte-preserving stream fixture spelling repair'], cwd=REPO, check=True)
source = identity()
assert source['status'] == ''
assert git('show', '-s', '--format=%P', 'HEAD') == CODE
assert all((REPO / p).read_bytes() == b for p, b in old_ledgers.items())
patch = subprocess.check_output(['git', 'diff', '--binary', CODE, 'HEAD'], cwd=REPO)
(EV / (LABEL + '-source.patch')).write_bytes(patch)
files = []
for p in paths:
    b = (REPO / p).read_bytes()
    files.append({'path': p, 'mode': git('ls-files', '-s', '--', p).split()[0],
                  'blob': git('rev-parse', 'HEAD:' + p), 'sha256': digest(b), 'content': b.decode()})
raw = subprocess.check_output(['git', 'cat-file', 'commit', 'HEAD'], cwd=REPO)
export = {'before': {'commit': CODE, 'tree': CODE_TREE}, 'source': source,
          'files': files, 'raw_commit_base64': base64.b64encode(raw).decode(),
          'preview': outputs['preview'], 'applied': outputs['apply'], 'patch_sha256': digest(patch),
          'old_history_ledgers_sha256': {p: digest(b) for p, b in old_ledgers.items()},
          'semantic_metadata_preserved': True, 'execution_evidence_transferred': False,
          'operations': 371, 'modules': 40, 'production_false': 40}
data = (json.dumps(export, ensure_ascii=False) + '\n').encode()
p = EV / (LABEL + '-export.json')
assert not p.exists()
p.write_bytes(data)
z = zlib.compress(data, 9)
q = EV / (LABEL + '-export.json.z')
assert not q.exists()
q.write_bytes(z)
print(json.dumps({'spelling_navigation_source': source, 'files': len(files),
                  'raw_bytes': len(data), 'raw_sha256': digest(data), 'compressed_path': str(q),
                  'compressed_bytes': len(z), 'compressed_sha256': digest(z)}), flush=True)
