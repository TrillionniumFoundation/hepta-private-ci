#!/usr/bin/env python3
"""Build a local archive from independently versioned read-only API results."""
import base64
from collections import defaultdict
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

WORK = Path(__file__).resolve().parents[1]
ROOT = WORK / 'integration/spelling-native-checkpoint'
REMOTE = Path('/home/qq/work/hepta-modules40-20261105-da8578')
SOURCE = {'commit': '797116d61cf422c26274ffef31297dce84a53a80',
          'tree': '67ce024db1679aa6cd301856ba3a694ea18bc4b6', 'status': ''}
DEST = WORK / 'integration/native-797-file-read-checkpoint.tar.gz'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def write_exact(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        path.write_bytes(data)


def destination(path):
    relative = Path(path).relative_to(REMOTE)
    if relative.parts[0] == 'evidence':
        return Path('native') / relative.name
    return Path('reproduction') / relative


def main():
    assert not DEST.exists(), 'Preserve an existing checkpoint; do not recreate it with a new capture time.'
    provenance = []
    chunks = defaultdict(list)
    info = {}
    for path in sorted((ROOT / 'reads').glob('*.json')):
        record = json.loads(path.read_bytes())
        origin = path.relative_to(ROOT).as_posix()
        if 'files' in record:
            assert record['atomic_snapshot'] is False
            assert record['snapshot_scope'] == 'independent_file' and record['truncated'] is False
            for item in record['files']:
                target = destination(item['path'])
                data = (ROOT / target).read_bytes()
                assert data == item['text'].encode() and len(data) == item['size']
                assert digest(data) == item['sha256'] and item['eof'] is True and item['version']
                provenance.append({'path': target.as_posix(), 'remote_path': item['path'],
                                   'method': 'read_multiple_files', 'version': item['version'],
                                   'bytes': len(data), 'sha256': digest(data), 'read_records': [origin]})
        elif 'chunk_sha256' in record:
            chunks[record['path']].append((record, origin))
        elif 'sha256' in record and 'path' in record:
            info[record['path']] = (record, origin)
        else:
            raise ValueError(f'Unexpected read record: {origin}')
    for remote_path, rows in sorted(chunks.items()):
        rows.sort(key=lambda row: row[0]['offset'])
        target = destination(remote_path)
        data = (ROOT / target).read_bytes()
        assert len({row[0]['version'] for row in rows}) == 1
        cursor = 0
        for item, origin in rows:
            assert item['offset'] == cursor and item['size'] == len(data)
            chunk = data[item['offset']:item['next_offset']]
            assert digest(chunk) == item['chunk_sha256']
            assert item['eof'] == (item['next_offset'] == len(data))
            cursor = item['next_offset']
        assert cursor == len(data) and rows[-1][0]['eof']
        records = [origin for _, origin in rows]
        if remote_path in info:
            item, origin = info[remote_path]
            assert item['sha256'] == digest(data) and item['size'] == len(data)
            assert item['version'] == rows[0][0]['version']
            records.append(origin)
        provenance.append({'path': target.as_posix(), 'remote_path': remote_path,
                           'method': 'binary_read; all chunks pinned to first version',
                           'version': rows[0][0]['version'], 'bytes': len(data),
                           'sha256': digest(data), 'chunk_count': len(rows), 'read_records': records})
    remote_files = {p.relative_to(ROOT).as_posix() for section in ['native', 'reproduction']
                    for p in (ROOT / section).rglob('*') if p.is_file()}
    assert {item['path'] for item in provenance} == remote_files
    assert len(provenance) == len(remote_files)

    reproduction = ROOT / 'reproduction'
    for file_name in ['ingest-spelling-evidence.py', 'build-spelling-file-read-checkpoint.py']:
        write_exact(reproduction / 'local-collector' / file_name,
                    (WORK / 'integration' / file_name).read_bytes())
    for name in ['spelling-canonical-797-runtime-status.json', 'spelling-navigation-run1-runtime.json',
                 'codespell-setup-run1-runtime-status.json']:
        write_exact(ROOT / 'runtime-receipts' / name, (WORK / 'integration/runtime-receipts' / name).read_bytes())
    objects = []
    source_checkout = json.loads((ROOT / 'native/spelling-canonical-run1-source-checkout.json').read_bytes())
    objects.append((SOURCE['commit'], source_checkout['raw_commit_base64']))
    navigation = json.loads((ROOT / 'native/spelling-navigation-run1-export.json').read_bytes())
    objects.append((navigation['source']['commit'], navigation['raw_commit_base64']))
    nav_input = json.loads((reproduction / 'spelling-navigation-input.json').read_bytes())
    objects.extend((item['sha'], item['raw_base64']) for item in nav_input['object']['commits'])
    previous = json.loads((WORK / 'integration/canonical-final-object.json').read_bytes())
    objects.extend((item['sha'], item['raw_base64']) for item in previous['commits'])
    identities = []
    for sha, encoded in objects:
        data = base64.b64decode(encoded, validate=True)
        assert hashlib.sha1(b'commit ' + str(len(data)).encode() + b'\0' + data).hexdigest() == sha
        write_exact(ROOT / 'native-source-history' / (sha + '.commit'), data)
        header = data.decode().split('\n\n', 1)[0].splitlines()
        identities.append({'commit': sha, 'tree': next(line[5:] for line in header if line.startswith('tree ')),
                           'parents': [line[7:] for line in header if line.startswith('parent ')]})
    write_exact(ROOT / 'native-source-history/identities.json', dump(identities))

    runtime = json.loads((ROOT / 'runtime-receipts/spelling-canonical-797-runtime-status.json').read_bytes())
    assert runtime['job_id'] == '1a1ac84ead1-fc05-54ef' and runtime['state'] == 'succeeded' and runtime['exit_code'] == 0
    assert runtime['output_complete'] and runtime['output_durable'] and not runtime['timed_out'] and not runtime['cancelled']
    seven = json.loads((ROOT / 'native/seven-package-run3-summary.json').read_bytes())
    wrapper = json.loads((ROOT / 'native/spelling-canonical-run1-summary.json').read_bytes())
    assert seven['source'] == seven['source_after'] == wrapper['source'] == wrapper['source_after'] == SOURCE
    assert seven['runner_exit'] == seven['audit_exit'] == 0
    assert len(wrapper['checks']) == 7 and all(value == 0 for value in wrapper['checks'].values())
    base_path = WORK / 'integration/native-final-bb55-checkpoint.tar.gz'
    assert digest(base_path.read_bytes()) == '28424496bd400d6c5ff6370158f7b093355e463f19ebb550b1df6e7330504886'
    custody = {
        'schema': 'hepta.independent-file-read-custody.v1', 'atomic_snapshot': False,
        'scope': 'Complete known output files of completed create-only native writers, read independently through the file API; no cross-file atomic snapshot or current remote checkout attestation.',
        'native_execution_job': runtime['job_id'],
        'unknown_archive_request': {
            'job_id': '1a1ac8ebea3-fc05-5545',
            'idempotency_key': 'modules40-da8578-native-797-archive-run1',
            'state_reported_by_coordinator': 'launch_unknown',
            'provenance': 'Coordinator context; original launch payload is not represented as a successful receipt in this collection.',
            'replayed_by_collector': False,
            'relation_to_native_execution': 'Separate archive request; neither a failed nor a replayed native test run.'},
        'files': sorted(provenance, key=lambda item: item['path']),
        'locally_derived_or_copied': [
            'native-source-history: raw objects decoded from verified previously captured canonical/native payloads, with Git object identity checked.',
            'runtime-receipts: exact coordinator-captured authoritative receipts, copied without modification.',
            'reproduction/local-collector: local ingestion and archive creation code, not a native execution script.'],
    }
    write_exact(ROOT / 'READ-CUSTODY.json', dump(custody))
    readme = '''# 797116d6 native checkpoint collected through read-only file APIs

This archive contains the native execution outputs for canonical source
797116d61cf422c26274ffef31297dce84a53a80, tree
67ce024db1679aa6cd301856ba3a694ea18bc4b6. The native execution completed
successfully as job 1a1ac84ead1-fc05-54ef before this collection.

Every remote file was read independently. Small files carry their complete UTF-8
payload, version token and SHA256. Large files were read in bounded chunks pinned
to one version, with every chunk hash checked against the assembled bytes. This
is not a cross-file atomic snapshot. Source identity comes from the recorded
before/after native receipts, not from a claim about the later remote checkout.

A separate remote archive request was reported as launch_unknown. The collector
did not replay that request. This local archive was created from read-only file
API results and records that distinction in READ-CUSTODY.json.

The immutable bb55 checkpoint remains the base history. Its original failures,
earlier successes and source identities are not recast as results on 797116d6.
This checkpoint establishes only the recorded Linux scopes. Production flags,
platform qualification, real-provider acceptance and activation are unchanged.
'''.encode()
    write_exact(ROOT / 'README.md', readme)
    files = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in ROOT.rglob('*')
             if p.is_file() and 'chunks' not in p.relative_to(ROOT).parts and p.name != 'MANIFEST.json'}
    manifest = {
        'schema': 'hepta.native-evidence-independent-file-read-checkpoint.v1', 'source': SOURCE,
        'captured_unix_ns': time.time_ns(), 'atomic_snapshot': False,
        'scope': custody['scope'], 'read_custody_sha256': digest(dump(custody)),
        'base_evidence': {'commit': 'f038947fd20992e15213d41f7f6d8ac1d2ca10fc',
                          'path': 'qualification/module-execution-dossiers/modules40-20261105-da8578/native/native-final-bb55-checkpoint.tar.gz',
                          'archive_bytes': base_path.stat().st_size,
                          'archive_sha256': digest(base_path.read_bytes()),
                          'source_commit': 'bb55b0d7d263c396ec504c45393d938c3428dae5'},
        'final_seven_package_summary': seven['native_summary'], 'final_checks': wrapper['checks'],
        'entries': [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(files.items())],
    }
    write_exact(ROOT / 'MANIFEST.json', dump(manifest))
    files['MANIFEST.json'] = dump(manifest)
    with DEST.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, data in sorted(files.items()):
                    entry = tarfile.TarInfo(name)
                    entry.size = len(data)
                    entry.mode = 0o644
                    entry.mtime = 0
                    archive.addfile(entry, io.BytesIO(data))
    result = {'archive_path': str(DEST), 'bytes': DEST.stat().st_size, 'sha256': digest(DEST.read_bytes()),
              'files': len(files), 'manifest_entries': len(manifest['entries']),
              'remote_files_with_verified_api_provenance': len(provenance),
              'manifest_sha256': digest(files['MANIFEST.json']), 'source': SOURCE,
              'atomic_snapshot': False, 'native_summary': seven['native_summary']}
    write_exact(WORK / 'integration/native-797-file-read-archive-metadata.json', dump(result))
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
