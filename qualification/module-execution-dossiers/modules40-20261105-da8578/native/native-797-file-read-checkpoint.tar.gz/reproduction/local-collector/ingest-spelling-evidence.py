#!/usr/bin/env python3
"""Persist independently versioned, read-only native API payloads without execution."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent / 'spelling-native-checkpoint'


def write_exact(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, f'Existing bytes differ: {path}'
    else:
        path.write_bytes(data)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['small', 'binary'])
    parser.add_argument('name')
    args = parser.parse_args()
    record = json.load(sys.stdin)
    records = []
    if args.mode == 'small':
        assert record['atomic_snapshot'] is False
        assert record['snapshot_scope'] == 'independent_file'
        assert record['encoding'] == 'utf-8' and record['truncated'] is False
        for entry in record['files']:
            data = entry['text'].encode('utf-8')
            assert len(data) == entry['size'] and entry['eof'] is True
            assert hashlib.sha256(data).hexdigest() == entry['sha256']
            assert entry['version']
            remote = Path(entry['path'])
            remote_root = Path('/home/qq/work/hepta-modules40-20261105-da8578')
            relative = remote.relative_to(remote_root)
            if relative.parts[0] == 'evidence':
                destination = Path('native') / remote.name
            else:
                destination = Path('reproduction') / relative
            write_exact(ROOT / destination, data)
            records.append({'name': destination.as_posix(), 'bytes': len(data), 'sha256': entry['sha256']})
    else:
        data = base64.b64decode(record['data_base64'], validate=True)
        assert len(data) == record['next_offset'] - record['offset']
        assert hashlib.sha256(data).hexdigest() == record['chunk_sha256']
        assert record['eof'] == (record['next_offset'] == record['size'])
        assert record['version']
        name = Path(record['path']).name
        write_exact(ROOT / 'chunks' / (name + '.' + str(record['offset'])), data)
        records.append({'name': name, 'offset': record['offset'], 'bytes': len(data),
                        'sha256': record['chunk_sha256']})
        record = {key: value for key, value in record.items() if key != 'data_base64'}
    write_exact(ROOT / 'reads' / (args.name + '.json'),
                (json.dumps(record, ensure_ascii=False, indent=2) + '\n').encode())
    print(json.dumps({'saved': records}, ensure_ascii=False))


if __name__ == '__main__':
    main()
