#!/usr/bin/env python3
"""Check the 69-case source binding, then audit existing native JUnit only.

This does not run Rust tests, select tests, or establish runner provenance.
The immutable historical JUnit checker supplies the outcome semantics.
"""

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


HERE = Path(__file__).resolve().parent
HISTORY_SHA256 = "f832236003c1937c29ba9ca3f6faeafa2dc9799664ae1069d0df78339366f56e"
CHECKER_SHA256 = "043448357a05cd2c71f3a812a0d9e623e4313a50c6222cbbba03172f95dcae5b"
PACKAGES = [
    "codex-hepta-agent-protocol", "codex-hepta-agentd", "codex-hepta-runtime",
    "codex-hepta-infer-worker-host", "codex-hepta-contracts",
    "codex-hepta-learning-ledger", "codex-hepta-supervisor",
]
IDENTITY_KEYS = [
    "package", "binary", "binary_kind", "target_aliases", "test", "source_path", "required",
]
ADDITIONS = [
    ("agentd", "cognitive_context_hnmf_tests.rs", "cognitive_context::tests::hnmf::"
     "final_use_revalidation_rejects_tombstone_during_provider_callback"),
    ("agentd", "cognitive_context_hnmf_tests.rs", "cognitive_context::tests::hnmf::"
     "final_use_revalidation_rejects_source_drift_during_provider_callback"),
    ("learning-ledger", "production_reconciliation_tests.rs", "production::reconciliation::tests::"
     "committed_decision_recovers_after_lost_ack_expiry_and_reopen"),
    ("learning-ledger", "production_reconciliation_tests.rs", "production::reconciliation::tests::"
     "committed_outcome_recovers_after_lost_ack_expiry_and_reopen"),
    ("learning-ledger", "production_reconciliation_tests.rs", "production::reconciliation::tests::"
     "mismatched_or_missing_committed_reference_never_writes"),
    ("learning-ledger", "production_reconciliation_tests.rs", "production::reconciliation::tests::"
     "reconciliation_neither_revives_revoked_decision_nor_admits_other_event_kinds"),
    ("learning-ledger", "witness_tests.rs", "witness::tests::"
     "complete_unconfirmed_witness_frame_requires_successful_recovery_sync"),
    ("supervisor", "writer_handoff_recovery_tests.rs", "writer_handoff::recovery_tests::"
     "writer_handoff_owner_drop_releases_lock_with_passive_duplicate"),
    ("supervisor", "writer_handoff_recovery_tests.rs", "writer_handoff::recovery_tests::"
     "writer_handoff_failed_recovery_releases_acquired_lock_with_passive_duplicate"),
    ("supervisor", "writer_handoff_lock_tests.rs", "writer_handoff::journal_file::tests::"
     "fork_copy_drop_does_not_unlock_original_handoff_owner"),
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identities(manifest):
    return [{key: row.get(key) for key in IDENTITY_KEYS} for row in manifest["required_tests"]]


def validate_binding(review_path, bound_path, commit, tree):
    historical_bytes = (HERE / "history/required-tests.with-e65.json").read_bytes()
    require(digest(historical_bytes) == HISTORY_SHA256, "historical 59 manifest changed")
    historical = json.loads(historical_bytes)
    review_bytes = review_path.read_bytes()
    review = json.loads(review_bytes)
    require(review["schema_version"] == 1, "review manifest must remain schema v1")
    require(review["packages"] == PACKAGES, "the complete seven-package scope changed")
    rows = review["required_tests"]
    require(review["required_count"] == len(rows) == 69, "expected exactly 69 required rows")
    require(rows[:59] == historical["required_tests"], "original 59 rows or historical hashes changed")
    for key in ["baseline_commit", "selected_donor_commit", "additional_base_commits", "included_review_manifest"]:
        require(review[key] == historical[key], f"historical provenance changed: {key}")
    require(len({(r["package"], r["binary"], r["test"]) for r in rows}) == 69,
            "required cases are not unique")
    require(all(row["required"] is True for row in rows), "all 69 rows must be mandatory")
    for row, (module, filename, test) in zip(rows[59:], ADDITIONS):
        package = "codex-hepta-" + module
        binary = package.replace("-", "_")
        expected = [package, binary, "lib", [package, binary], test,
                    f"codex-rs/hepta-{module}/src/{filename}", True]
        require([row.get(key) for key in IDENTITY_KEYS] == expected,
                f"new test identity changed: {test}")

    bound = json.loads(bound_path.read_bytes())
    require(bound["schema_version"] == 2, "audit requires a separate source-bound schema-v2 manifest")
    require(bound["manifest_stage"] == "candidate_source_bound_not_tested", "wrong binding stage")
    require(bound["candidate"] == {"commit": commit, "tree": tree},
            "supplied candidate differs from source-bound candidate")
    require(bound["review_manifest"]["sha256"] == digest(review_bytes),
            "bound manifest references another reviewed manifest")
    require(bound["required_count"] == 69 and bound["packages"] == PACKAGES,
            "bound count or complete seven-package scope changed")
    require(identities(bound) == identities(review), "binding changed ordered required identities")
    identity_digest = digest(json.dumps(identities(review), sort_keys=True,
                                        separators=(",", ":")).encode())
    require(bound["requirements_identity_sha256"] == identity_digest, "wrong required-identity hash")
    for before, after in zip(rows, bound["required_tests"]):
        require(after["review_source_snapshot_sha256"] == before["source_snapshot_sha256"],
                "binding failed to preserve a reviewed source hash")
        allowed = {"source_snapshot_sha256", "source_git_blob", "review_source_snapshot_sha256"}
        require({k: v for k, v in before.items() if k not in allowed} ==
                {k: v for k, v in after.items() if k not in allowed},
                "binding changed non-source review fields")
        require(re.fullmatch(r"[0-9a-f]{64}", after["source_snapshot_sha256"]) and
                re.fullmatch(r"[0-9a-f]{40}", after["source_git_blob"]),
                "invalid bound source identity")
    sources = {item["path"]: item for item in bound["reviewed_source_files"]}
    for row in bound["required_tests"]:
        source = sources[row["source_path"]]
        require(source["sha256"] == row["source_snapshot_sha256"] and
                source["git_blob"] == row["source_git_blob"], "inconsistent bound source file")
    context_paths = {item["path"] for item in bound["runner_source_context"]}
    required_context = {f"codex-rs/{package.removeprefix('codex-')}/Cargo.toml" for package in PACKAGES}
    required_context |= {"codex-rs/Cargo.toml", "codex-rs/Cargo.lock", "codex-rs/.config/nextest.toml",
                         "scripts/run-nextest.py", "scripts/just-shell.py"}
    require(required_context <= context_paths, "runner source context omits a package or runner input")
    for key in ["tracked_worktree_and_index_match_candidate", "hidden_index_entries_rejected",
                "all_selected_source_bytes_match_committed_blobs", "test_names_targets_and_requirements_unchanged"]:
        require(bound["source_binding"][key] is True, f"source binding did not establish {key}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--review-manifest", type=Path, default=HERE / "required-tests.69.json")
    parser.add_argument("--manifest", type=Path, required=True, help="Separate source-bound schema-v2 file.")
    parser.add_argument("--candidate-commit", required=True)
    parser.add_argument("--candidate-tree", required=True)
    parser.add_argument("--junit", type=Path, action="append", required=True)
    parser.add_argument("--suite-exit-code", type=int, required=True,
                        help="Actual original seven-package runner exit; never infer it from XML.")
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    try:
        require(all(re.fullmatch(r"[0-9a-f]{40}", value) for value in
                    [args.candidate_commit, args.candidate_tree]), "candidate commit/tree must be full SHAs")
        require(not args.report.exists(), "refusing to overwrite an existing audit; choose a new report path")
        validate_binding(args.review_manifest, args.manifest, args.candidate_commit, args.candidate_tree)
        checker = HERE / "history/check_required_junit.py"
        require(digest(checker.read_bytes()) == CHECKER_SHA256, "historical JUnit checker changed")
    except (OSError, KeyError, TypeError, ValueError) as error:
        print(f"PRECONDITION_FAILED: {error}", file=sys.stderr)
        return 2
    command = [sys.executable, str(checker), "--manifest", str(args.manifest),
               "--candidate-commit", args.candidate_commit, "--candidate-tree", args.candidate_tree,
               "--suite-exit-code", str(args.suite_exit_code), "--report", str(args.report)]
    for path in args.junit:
        command.extend(["--junit", str(path)])
    return subprocess.run(command, check=False).returncode


if __name__ == "__main__":
    sys.exit(main())
