# 原生七包 JUnit 的 69 项独立覆盖审计准备

**本目录是审计准备材料，不包含最终原生运行结果，也未填写最终源码 SHA。** `required-tests.69.json` 是执行后核对清单，不是 runner 的筛选表达式。最终测试必须继续使用原 profile、原超时和重试设置，完整运行既定七包；不得由这 69 项反推包集或生成筛选器。

## 清单来源与范围

历史清单来自固定证据提交 [`f0acd773ef35bf7f236a6b9ecbea073d425f3ab5`](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/f0acd773ef35bf7f236a6b9ecbea073d425f3ab5/qualification/module-execution-dossiers/modules40-20261105-a9f4ebc7/product_recovery)。`history/` 下的原 JSON、Markdown、binder 与 JUnit checker 均保留取回的原始字节。

历史 JSON 的 Git blob 是 `c62436688f9c67b6baba59607f6d15a2ff46aed5`，SHA-256 是 `f832236003c1937c29ba9ca3f6faeafa2dc9799664ae1069d0df78339366f56e`。新清单的前 59 行与该历史 JSON 逐字段相等，包括历史 `source_snapshot_sha256`、target aliases、required 标志以及已有来源字段。历史 baseline、donor 和 additional base commits 也保持原值。

| 必须完整运行的包 | 历史必要用例 | 本轮新增 | 必要用例合计 |
|---|---:|---:|---:|
| `codex-hepta-agent-protocol` | 3 | 0 | 3 |
| `codex-hepta-agentd` | 13 | 2 | 15 |
| `codex-hepta-runtime` | 3 | 0 | 3 |
| `codex-hepta-infer-worker-host` | 40 | 0 | 40 |
| `codex-hepta-contracts` | 0 | 0 | 0 |
| `codex-hepta-learning-ledger` | 0 | 5 | 5 |
| `codex-hepta-supervisor` | 0 | 3 | 3 |
| **合计** | **59** | **10** | **69** |

`contracts` 的 0 仅表示本清单没有点名其关键用例；该包仍必须进入完整运行。新 10 项是 memory 2、ledger reconciliation 4、witness sync 1、supervisor recovery 2、supervisor fork 1。所有新增项均为 lib target，完整名字已按真实模块声明核对：ledger 使用 `production::reconciliation::tests::...`，fork 使用 `writer_handoff::journal_file::tests::...`。

新用例的 `source_snapshot_sha256` 标识审阅过的输入字节，并不冒充最终 formatter、merge 后的源码。完整用例名、source_path、reviewed input blob 及来源均列于 JSON。

## 先绑定真正被测试的源码

在原生执行负责人的静止、已提交 checkout 上使用 `bind_native_audit_manifest.py`。该脚本只读取 Git/源码并写一个独立 schema-v2 文件；不构建、不运行测试，也不修改源代码。它与历史 binder 仅有一处加法：runner context 另外记录 contracts、learning-ledger、supervisor 三个 `Cargo.toml`。

以下路径与变量必须来自真实记录，不应把示例解释为已经存在的结果：

```sh
python3 "$AUDIT_PREP_DIR/bind_native_audit_manifest.py" \
  --repo "$TESTED_CHECKOUT" \
  --review-manifest "$AUDIT_PREP_DIR/required-tests.69.json" \
  --candidate-commit "$TESTED_SOURCE_COMMIT" \
  --candidate-tree "$TESTED_SOURCE_TREE" \
  --output "$EVIDENCE_DIR/required-tests.69.source-bound.json"
```

`TESTED_SOURCE_COMMIT` 与 `TESTED_SOURCE_TREE` 必须是完整 40 位身份，且来自最终七包执行的同一固定源码。binder 检查 HEAD、tree、tracked worktree、index 和源文件字节一致，拒绝隐藏的 index 项；在单独文件中将最终源码哈希写入 `source_snapshot_sha256`，将审阅输入哈希保留为 `review_source_snapshot_sha256`。不要原地修改审阅版的历史 59 行。若之后改动源码，先重新冻结并按新身份执行，不能把较早 JUnit 绑定到较新的候选。

## 再核对原生 JUnit

```sh
python3 "$AUDIT_PREP_DIR/audit_native_junit.py" \
  --review-manifest "$AUDIT_PREP_DIR/required-tests.69.json" \
  --manifest "$EVIDENCE_DIR/required-tests.69.source-bound.json" \
  --candidate-commit "$TESTED_SOURCE_COMMIT" \
  --candidate-tree "$TESTED_SOURCE_TREE" \
  --junit "$EXISTING_NATIVE_JUNIT" \
  --suite-exit-code "$RECORDED_ORIGINAL_SUITE_EXIT" \
  --report "$EVIDENCE_DIR/required-tests.69.native-audit.json"
```

如果同一次七包运行产生多个互不重叠的报告，重复传 `--junit`。不得混入旧 RED/GREEN、小过滤器运行、其他源码身份或重叠报告。`RECORDED_ORIGINAL_SUITE_EXIT` 必须读取原生 runner 的真实退出码，不能从 XML 或覆盖通过数推导，也不能预置为 0。

wrapper 先检查原 59 的不可变来源、全部 69 个唯一 mandatory identity、七包范围、schema-v2 来源哈希、候选 commit/tree、源文件绑定和完整 runner context，再调用字节固定的历史 `check_required_junit.py`。输出报告已经存在时拒绝覆盖。历史 checker 的 SHA-256 为 `043448357a05cd2c71f3a812a0d9e623e4313a50c6222cbbba03172f95dcae5b`。

checker 只接受准确 Rust 模块名和正确 binary 元数据。缺失、错误 target、重复、required skip、失败或重试均不能得到 `CLEAN`；任何观察到的非 required 失败或重试、aggregate failure、XML 错误、原 runner 非零退出也会阻断。所有 skip 仍列入报告。wrapper 退出 2 表示前提不满足；历史 checker 退出 0/1 分别表示此覆盖审计的 `CLEAN`/`NOT_CLEAN`，不会改写原 runner 退出码。

## 必须保留的独立证据

即使 69 项全部出现且通过，仍须保存完整七包命令及包集、原 profile、原 runner 输出与退出码、执行开始/结束时间、实际工具链、固定 source commit/tree 和 JUnit 哈希。清单不能证明 `contracts` 被运行，JUnit 本身也无法认证其执行源码；这些关联由原执行回执建立。nextest 的默认 JUnit 可能省略 skipped case，完整 runner 的 skip 总数仍须保留。

本轮最终 ledger 四项使用 witness 独立修复后的每实例 `cfg(test)` 写入故障 seam；早先主阶段的真实只读 witness RED/GREEN 是另一份证据窗口，继续单独保存，不以最终清单替代或改写。历史 committed receipt 依旧不是当前授权。本审计也不证明 Agentd 完整进程重启、默认产品 D/O owner composition 或所有 40 模块资格已闭合。

## 仅审计工具自测

`python3 test_audit_native_junit.py` 使用临时目录中的合成 XML 和明确的虚构绑定字段验证审计行为。15 个 Python 工具用例已在本地运行通过，覆盖缺失、skip、重复、错误 target、仅 leaf name、重试、子集外失败、原退出码非零、fork 缺失、候选错配、schema-v1 误用、历史哈希改写、遗漏 contracts context 和 XML 损坏。它们不是 Rust 用例，不是原生 JUnit，也不提供任何最终候选通过结论。
