from pathlib import Path
import base64
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/home/qq/work/hepta-modules40-20261105-da8578')
REPO = ROOT / 'source'
EV = ROOT / 'evidence'
COMMIT = '8658210499706130788c216ff14fd342809b45a4'
TREE = '6bc86196d10cf83b010f9917e5e9cb471b5f6b68'
NATIVE_SOURCE = 'c2834dcade885fb9ff5da41b3947773067ec652d'
LABEL = 'complete-canonical-run1'
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'environment.json').read_text()))


def git(*args, data=None):
    return subprocess.check_output(['git', *args], cwd=REPO, input=data).decode().strip()


def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(name, data):
    path = EV / (LABEL + '-' + name + '.json')
    assert not path.exists(), path
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


assert identity() == {'commit': NATIVE_SOURCE, 'tree': TREE, 'status': ''}
preserved = {
    'refs/heads/evidence/da8578-native-complete-merge': NATIVE_SOURCE,
}
for ref, sha in preserved.items():
    git('update-ref', ref, sha, '0' * 40)
    assert git('rev-parse', ref) == sha
payload = json.loads((ROOT / 'complete-canonical-object.json').read_text())
assert len(payload['commits']) == 1
entry = payload['commits'][0]
assert entry['sha'] == COMMIT
raw = base64.b64decode(entry['raw_base64'], validate=True)
assert hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == COMMIT
assert git('hash-object', '-t', 'commit', '-w', '--stdin', data=raw) == COMMIT
assert git('rev-parse', COMMIT + '^{tree}') == TREE
subprocess.run(['git', 'checkout', '--detach', COMMIT], cwd=REPO, check=True)
EXPECTED = {'commit': COMMIT, 'tree': TREE, 'status': ''}
assert identity() == EXPECTED
save('source-checkout', {'source': EXPECTED, 'raw_commit_base64': entry['raw_base64'],
                        'preserved_native_refs': preserved,
                        'environment_sha256': digest((ROOT / 'environment.json').read_bytes()),
                        'scope': 'canonical source checkout for fresh execution; prior results retain prior identities'})


def run(name, argv, cwd=REPO):
    before = identity()
    assert before == EXPECTED
    path = EV / (LABEL + '-' + name + '.log')
    assert not path.exists()
    start = time.monotonic()
    record = {'command': argv, 'cwd': str(cwd), 'source_before': before,
              'start_unix_ns': time.time_ns(), 'environment_sha256': digest((ROOT / 'environment.json').read_bytes())}
    with path.open('wb') as out:
        proc = subprocess.Popen(argv, cwd=cwd, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in proc.stdout:
            out.write(line)
            if any(token in line for token in [b'Summary', b'FAIL', b'error:', b'error[', b'FAILED',
                                               b'Finished', b'TMT', b'final_native_summary', b'command_terminal']):
                sys.stdout.buffer.write(line)
                sys.stdout.buffer.flush()
        code = proc.wait()
    record.update(exit=code, elapsed_seconds=time.monotonic() - start, end_unix_ns=time.time_ns(),
                  source_after=identity(), log_path=str(path), log_sha256=digest(path.read_bytes()), log_bytes=path.stat().st_size)
    save(name, record)
    print(json.dumps({'canonical_command_terminal': name, **record}), flush=True)
    assert record['source_after'] == before
    return code


helper = ROOT / 'refresh-navigation-explicit-pins.py'
assert digest(helper.read_bytes()) == '940f0fe0d5fccf53dc8d00dacbd4f572cf9b02419704dba0cde35d495f9e7e3b'
registry = json.loads((REPO / 'docs/modules/MODULES.json').read_text())['modules']
assert len(registry) == 40
maps = {f'docs/modules/{r["id"]}/IMPLEMENTATION_MAP.json': (REPO / f'docs/modules/{r["id"]}/IMPLEMENTATION_MAP.json').read_bytes() for r in registry}
parsed_maps = [json.loads(b) for b in maps.values()]
assert sum(len(m['operations']) for m in parsed_maps) == 371
assert all(m['productionImplementation'] is False and m['claimBoundary']['productionImplementation'] is False for m in parsed_maps)
ledgers = {p: (REPO / p).read_bytes() for p in [
 'qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history.json',
 'qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history-final.json',
 'qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history-spelling.json']}
new_ledger = 'qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history-complete-merge.json'
assert not (REPO / new_ledger).exists()
nav_argv = ['python3', str(helper), '--root', str(REPO), '--expected-sha', COMMIT,
            '--expected-tree', TREE, '--ledger', new_ledger]
nav_log = EV / (LABEL + '-navigation-preview.log')
assert not nav_log.exists()
nav_result = subprocess.run(nav_argv, cwd=REPO, env=ENV, capture_output=True)
nav_log.write_bytes(nav_result.stdout + nav_result.stderr)
assert nav_result.returncode == 0, nav_log.read_text()
nav = json.loads(nav_result.stdout)
assert nav['changedMaps'] == 0 and nav['maps'] == [], nav
assert identity() == EXPECTED
assert all((REPO / p).read_bytes() == b for p,b in {**maps, **ledgers}.items())
assert not (REPO / new_ledger).exists()
save('navigation-preview', {'source': EXPECTED, 'command': nav_argv, 'exit': 0,
 'output': nav, 'log_sha256': digest(nav_log.read_bytes()),
 'all_map_sha256': {p: digest(b) for p,b in maps.items()},
 'history_sha256': {p: digest(b) for p,b in ledgers.items()},
 'operations':371, 'modules':40, 'production_false':40,
 'scope':'read-only original navigation helper preview; zero affected maps; no new history ledger or navigation mutation'})
print(json.dumps({'navigation_preview': nav, 'source': EXPECTED}), flush=True)


runner = ROOT / 'run-final-native.py'
assert digest(runner.read_bytes()) == '9590be884338146913ddec0fc4c0770cd2f134daf69d67c5a4a8bb14d60097eb'
spell = str(ROOT / 'tools/codespell-2.4.3/bin/codespell')
assert subprocess.check_output([spell, '--version'], env=ENV, text=True).strip() == '2.4.3'
checks = {}
checks['original-codespell'] = run('original-codespell', [spell, '--ignore-words', '.codespellignore', '--skip', './.git'])
checks['seven-package-original-runner'] = run('seven-package-original-runner', [
    'python3', str(runner), '--candidate-commit', COMMIT, '--candidate-tree', TREE,
    '--run-label', 'seven-package-run5'])
checks['original-workspace-format'] = run('original-workspace-format', [
    'cargo', 'fmt', '--', '--config', 'imports_granularity=Item', '--check'], cwd=REPO / 'codex-rs')
checks['original-four-package-format'] = run('original-four-package-format', [
    'cargo', 'fmt', '--package', 'codex-utils-path', '--package', 'codex-hepta-prompt-registry',
    '--package', 'codex-hepta-contracts', '--package', 'codex-hepta-agentd', '--', '--check'], cwd=REPO / 'codex-rs')
checks['original-ci-policy-clippy'] = run('original-ci-policy-clippy', [
    'just', 'clippy', '--locked', '-p', 'codex-exec-server', '-p', 'codex-app-server',
    '-p', 'codex-app-server-client', '--', '-D', 'clippy::correctness',
    '-D', 'clippy::await_holding_lock', '-D', 'clippy::await_holding_invalid_type'])
checks['two-library-regression'] = run('two-library-regression', [
    'just', 'test', '--locked', '-p', 'codex-exec-server', '-p', 'codex-app-server-client', '--lib'])
checks['app-server-process-regression'] = run('app-server-process-regression', [
    'just', 'test', '--locked', '-p', 'codex-app-server', '--test', 'all', '-E',
    'test(process_exec)', '--no-tests', 'fail'])
checks['original-windows-ci-receipt-controls'] = run('original-windows-ci-receipt-controls', [
    'python3', '-m', 'unittest', 'discover', '-s', '.github/scripts', '-p', 'test_windows_current_ci*.py'])
save('summary', {'source': EXPECTED, 'checks': checks, 'source_after': identity(),
                 'complete_unix_ns': time.time_ns(),
                 'scope': 'Linux native seven-package qualification, original pinned Codespell 2.4.3, scoped process regressions, original format/Clippy policies and the original Windows CI receipt rejection controls; no production activation or platform qualification transfer'})
print(json.dumps({'final_canonical_checks': checks, 'source': EXPECTED}), flush=True)
sys.exit(0 if all(code == 0 for code in checks.values()) else 1)
