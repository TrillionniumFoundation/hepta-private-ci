from pathlib import Path
import base64
import hashlib
import json
import os
import subprocess
import time
import zlib

ROOT = Path('/home/qq/work/hepta-modules40-20261105-da8578')
REPO = ROOT / 'source'
EV = ROOT / 'evidence'
LABEL = 'upstream-3a39-integration-run1'
BEFORE = {'commit': '775bf555b0a7faf6eed17627acb0d0433294b737',
          'tree': 'e6f4644152d11a06457fdd92d8e5066675b26565', 'status': ''}
UPSTREAM = '3a39c799a3f776b0aeedfce350341d865d3cc1c4'
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'environment.json').read_text()))
PAYLOAD = json.loads((ROOT / 'upstream-3a39-input.json').read_text())


def git(*args, data=None, env=None):
    return subprocess.check_output(['git', *args], cwd=REPO, input=data, env=env).decode().strip()


def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_evidence(name, data):
    path = EV / (LABEL + '-' + name)
    assert not path.exists(), path
    path.write_bytes(data)
    return path


assert identity() == BEFORE
prior = json.loads((EV / 'windows-canonical-run1-summary.json').read_text())
assert prior['source'] == BEFORE and prior['source_after'] == BEFORE
assert len(prior['checks']) == 7 and all(code == 0 for code in prior['checks'].values())
assert len(PAYLOAD['commits']) == 8
index = ROOT / 'upstream-3a39-import.index'
assert not index.exists()
index_env = ENV.copy()
index_env['GIT_INDEX_FILE'] = str(index)
previous = '07378034e060f23259bc99c7367f12b1284140f3'
imports = []
for entry in PAYLOAD['commits']:
    assert entry['parents'] == [previous], entry['sha']
    git('read-tree', previous + '^{tree}', env=index_env)
    for row in entry['files']:
        content = row['content'].encode()
        assert digest(content) == row['sha256'], row['path']
        blob = git('hash-object', '-w', '--stdin', data=content)
        assert blob == row['blob'], row['path']
        assert row['mode'] in ('100644', '100755')
        git('update-index', '--add', '--cacheinfo', row['mode'] + ',' + blob + ',' + row['path'], env=index_env)
    assert git('write-tree', env=index_env) == entry['tree'], entry['sha']
    raw = base64.b64decode(entry['raw_base64'], validate=True)
    assert hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == entry['sha']
    assert git('hash-object', '-t', 'commit', '-w', '--stdin', data=raw) == entry['sha']
    assert git('rev-parse', entry['sha'] + '^{tree}') == entry['tree']
    assert git('show', '-s', '--format=%P', entry['sha']) == previous
    imports.append({'commit': entry['sha'], 'tree': entry['tree'], 'parents': entry['parents'],
                    'files': [r['path'] for r in entry['files']]})
    previous = entry['sha']
assert previous == UPSTREAM
assert identity() == BEFORE
git('update-ref', 'refs/heads/evidence/da8578-upstream-3a39', UPSTREAM, '0' * 40)
registry = json.loads((REPO / 'docs/modules/MODULES.json').read_text())['modules']
maps = {f'docs/modules/{r["id"]}/IMPLEMENTATION_MAP.json': (REPO / f'docs/modules/{r["id"]}/IMPLEMENTATION_MAP.json').read_bytes() for r in registry}
assert len(maps) == 40
pty_path = 'codex-rs/utils/pty/src/win/native_observation_tests.rs'
pty_content = (REPO / pty_path).read_bytes()
assert git('rev-parse', 'HEAD:' + pty_path) == '9f2d9773c78c240c0af7af4cfca04048e19cdb65'
merge_argv = ['git', 'merge', '--no-ff', '--no-commit', UPSTREAM]
result = subprocess.run(merge_argv, cwd=REPO, env=ENV, capture_output=True)
merge_log = write_evidence('merge.log', result.stdout + result.stderr)
conflicts = git('diff', '--name-only', '--diff-filter=U').splitlines()
assert result.returncode in (0, 1), merge_log.read_text()
assert conflicts in ([], [pty_path]), conflicts
if conflicts:
    assert result.returncode == 1
    (REPO / pty_path).write_bytes(pty_content)
    subprocess.run(['git', 'add', '--', pty_path], cwd=REPO, check=True)
else:
    assert result.returncode == 0
assert git('rev-parse', 'MERGE_HEAD') == UPSTREAM
assert not git('diff', '--name-only', '--diff-filter=U')
assert (REPO / pty_path).read_bytes() == pty_content
paths = sorted(set(git('diff', '--name-only', BEFORE['commit']).splitlines()))
allowed = {
    '.github/scripts/aggregate_windows_current_ci.py',
    '.github/scripts/test_windows_current_ci_shards.py',
    '.github/scripts/windows_current_ci.py',
    '.github/workflows/hepta-windows-current-ci.yml',
    'codex-rs/hepta-operator-acceptance/src/openssh_windows.rs',
}
assert set(paths) == allowed, paths
pre_format = {p: (REPO / p).read_bytes() for p in paths}
for path in paths:
    assert pre_format[path] == subprocess.check_output(['git', 'show', UPSTREAM + ':' + path], cwd=REPO)
fmt_argv = ['cargo', 'fmt', '--package', 'codex-hepta-operator-acceptance', '--package', 'codex-utils-pty']
start = time.monotonic()
fmt = subprocess.run(fmt_argv, cwd=REPO / 'codex-rs', env=ENV, capture_output=True)
fmt_log = write_evidence('format.log', fmt.stdout + fmt.stderr)
assert fmt.returncode == 0, fmt_log.read_text()
assert set(git('diff', '--name-only', BEFORE['commit']).splitlines()) == allowed
assert not git('ls-files', '--others', '--exclude-standard')
format_changed = [p for p in paths if (REPO / p).read_bytes() != pre_format[p]]
assert set(format_changed) <= {'codex-rs/hepta-operator-acceptance/src/openssh_windows.rs'}
assert all((REPO / p).read_bytes() == b for p, b in maps.items())
subprocess.run(['git', 'diff', '--check'], cwd=REPO, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=REPO, check=True)
subprocess.run(['git', 'commit', '-m', 'Integrate fixed concurrent Windows qualification and verifier diagnostics'], cwd=REPO, check=True)
source = identity()
assert source['status'] == ''
assert git('show', '-s', '--format=%P', 'HEAD').split() == [BEFORE['commit'], UPSTREAM]
patch = subprocess.check_output(['git', 'diff', '--binary', BEFORE['commit'], 'HEAD'], cwd=REPO)
patch_path = write_evidence('source.patch', patch)
raw = subprocess.check_output(['git', 'cat-file', 'commit', 'HEAD'], cwd=REPO)
files = []
for path in paths:
    content = (REPO / path).read_bytes()
    files.append({'path': path, 'mode': git('ls-files', '-s', '--', path).split()[0],
                  'blob': git('rev-parse', 'HEAD:' + path), 'sha256': digest(content),
                  'content': content.decode()})
export = {'before': BEFORE, 'upstream': UPSTREAM, 'imports': imports, 'source': source,
          'parents': [BEFORE['commit'], UPSTREAM], 'files': files,
          'merge': {'command': merge_argv, 'exit': result.returncode, 'conflicts': conflicts,
                    'pty_resolution': 'retain the reviewed 775 explicit AsRawHandle calls and native rustfmt line breaks',
                    'log_sha256': digest(merge_log.read_bytes())},
          'format': {'command': fmt_argv, 'exit': fmt.returncode, 'changed_paths': format_changed,
                     'log_sha256': digest(fmt_log.read_bytes()), 'elapsed_seconds': time.monotonic() - start},
          'raw_commit_base64': base64.b64encode(raw).decode(), 'patch_sha256': digest(patch),
          'all_maps_unchanged': True, 'execution_evidence_transferred': False,
          'scope': 'fixed two-parent source integration and native formatting; platform qualification and merged-source tests are separate'}
data = (json.dumps(export, ensure_ascii=False) + '\n').encode()
path = write_evidence('export.json', data)
compressed = zlib.compress(data, 9)
zpath = write_evidence('export.json.z', compressed)
print(json.dumps({'source': source, 'parents': export['parents'], 'files': len(files),
                  'conflicts': conflicts, 'formatter_changed_paths': format_changed,
                  'export_path': str(path), 'export_bytes': len(data), 'export_sha256': digest(data),
                  'compressed_path': str(zpath), 'compressed_bytes': len(compressed),
                  'compressed_sha256': digest(compressed)}), flush=True)
