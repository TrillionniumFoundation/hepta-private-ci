from pathlib import Path
import base64
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT = Path('/home/qq/work/hepta-modules40-20261105-da8578')
REPO = ROOT / 'source'
EVIDENCE = ROOT / 'evidence'
PAYLOAD = json.loads((ROOT / 'recovery-stage-payload.json').read_text())
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'environment.json').read_text()))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def identity():
    return {'commit': git('rev-parse', 'HEAD'),
            'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def write_json(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, indent=2) + '\n')


def run(name, argv, expected_exit=0, expected_count=None):
    before = identity()
    assert not before['status'], before
    log = EVIDENCE / (name + '.log')
    record = {'argv': argv, 'cwd': str(REPO / 'codex-rs'),
              'source_before': before, 'start_unix': time.time(),
              'expected_exit': expected_exit, 'expected_cases': expected_count,
              'environment_sha256': hashlib.sha256((ROOT / 'environment.json').read_bytes()).hexdigest()}
    print(json.dumps({'stage_start': name, **record}), flush=True)
    start = time.monotonic()
    with log.open('wb') as output:
        process = subprocess.Popen(argv, cwd=REPO / 'codex-rs', env=ENV,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in process.stdout:
            output.write(line)
            sys.stdout.buffer.write(line)
            sys.stdout.buffer.flush()
        code = process.wait()
    record.update(exit=code, elapsed_seconds=time.monotonic() - start,
                  end_unix=time.time(), source_after=identity(),
                  log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    plain = re.sub(r'\x1b\[[0-9;]*m', '', log.read_text(errors='replace'))
    summaries = [line for line in plain.splitlines() if 'Summary' in line and 'tests run:' in line]
    record['native_summary'] = summaries[-1] if summaries else None
    write_json(name + '.json', record)
    print(json.dumps({'stage_complete': name, **record}), flush=True)
    assert record['source_after'] == before, 'test source changed while executing'
    assert code == expected_exit, (name, 'unexpected exit', code)
    if expected_count is not None:
        assert summaries, (name, 'missing native test summary')
        summary = summaries[-1]
        assert re.search(r'\b' + str(expected_count) + r' tests run:', summary), summary
        if expected_exit == 0:
            assert re.search(r'\b' + str(expected_count) + r' passed\b', summary), summary
        else:
            assert re.search(r'\b' + str(expected_count) + r' failed\b', summary), summary
            assert re.search(r'\b0 passed\b', summary), summary


def replace_reviewed_files(files, message, receipt):
    before = identity()
    assert not before['status'], before
    images = []
    for relative, content in files.items():
        path = REPO / relative
        old = path.read_bytes() if path.exists() else None
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        images.append({'path': relative,
                       'before_sha256': hashlib.sha256(old).hexdigest() if old is not None else None,
                       'reviewed_unformatted_sha256': hashlib.sha256(content.encode()).hexdigest()})
    fmt_log = EVIDENCE / (receipt + '-fmt.log')
    with fmt_log.open('wb') as output:
        subprocess.run(['just', 'fmt'], cwd=REPO / 'codex-rs', env=ENV,
                       stdout=output, stderr=subprocess.STDOUT, check=True)
    subprocess.run(['git', 'diff', '--check'], cwd=REPO, check=True)
    changed = set(git('diff', '--name-only').splitlines())
    untracked = set(git('ls-files', '--others', '--exclude-standard').splitlines())
    assert (changed | untracked) <= set(files), (changed, untracked)
    subprocess.run(['git', 'add', '--', *files], cwd=REPO, check=True)
    subprocess.run(['git', 'commit', '-m', message], cwd=REPO, check=True)
    after = identity()
    assert not after['status'], after
    for image in images:
        relative = image['path']
        image['formatted_sha256'] = hashlib.sha256((REPO / relative).read_bytes()).hexdigest()
        image['git_blob'] = git('rev-parse', 'HEAD:' + relative)
    raw_commit = subprocess.check_output(['git', 'cat-file', 'commit', after['commit']], cwd=REPO)
    write_json(receipt + '.json', {'source_before': before, 'source_after': after,
                                 'files': images, 'commit_object_base64': base64.b64encode(raw_commit).decode(),
                                 'fmt_log_sha256': hashlib.sha256(fmt_log.read_bytes()).hexdigest()})
    print(json.dumps({'source_transition': receipt, 'before': before, 'after': after}), flush=True)


red = json.loads((EVIDENCE / 'combined-red-prep2.json').read_text())
assert red['exit'] == 100, 'a build failure is not behavioral RED'
assert red['source_after'] == 'a3a987d0337efa8707d7f04d0b28a8f8f65b7eb9'
assert red['status_after'] == ''
assert identity()['commit'] == red['source_after']
red_text = (EVIDENCE / 'combined-red-prep2.log').read_text(errors='replace')
red_summary = [line for line in red_text.splitlines() if 'Summary' in line and 'tests run:' in line][-1]
assert '4 tests run:' in red_summary and '0 passed' in red_summary and '4 failed' in red_summary, red_summary

replace_reviewed_files(PAYLOAD['main_green'],
    'Recover committed learning acknowledgements and revalidate final memory use', 'main-green-source')
run('combined-green-main', red['argv'], expected_count=4)

assert git('rev-parse', 'HEAD:codex-rs/hepta-supervisor/src/writer_handoff.rs') == '45d34ab972069027668bb9f6ca290d69f2437c44'
assert git('rev-parse', 'HEAD:codex-rs/hepta-supervisor/src/writer_handoff_recovery_tests.rs') == 'cdcaf903f00d1f6bb817d97e2ca2b7f08f182383'
replace_reviewed_files(PAYLOAD['supervisor_red'],
    'Reproduce handoff lock retention after owner and failed recovery drop', 'supervisor-red-source')
run('supervisor-red', ['just', 'test', '--locked', '-p', 'codex-hepta-supervisor', '--lib', '-E',
    'test(writer_handoff_owner_drop_releases_lock_with_passive_duplicate) | test(writer_handoff_failed_recovery_releases_acquired_lock_with_passive_duplicate)'],
    expected_exit=100, expected_count=2)

replace_reviewed_files(PAYLOAD['final_green'],
    'Release handoff owner locks and require witness recovery synchronization', 'final-green-source')
run('supervisor-green', ['just', 'test', '--locked', '-p', 'codex-hepta-supervisor', '--lib', '-E',
    'test(writer_handoff_owner_drop_releases_lock_with_passive_duplicate) | test(writer_handoff_failed_recovery_releases_acquired_lock_with_passive_duplicate) | test(fork_copy_drop_does_not_unlock_original_handoff_owner)'],
    expected_count=3)
run('witness-green', ['just', 'test', '--locked', '-p', 'codex-hepta-learning-ledger', '--lib', '-E',
    'test(complete_unconfirmed_witness_frame_requires_successful_recovery_sync) | test(committed_decision_recovers_after_lost_ack_expiry_and_reopen) | test(committed_outcome_recovers_after_lost_ack_expiry_and_reopen) | test(mismatched_or_missing_committed_reference_never_writes) | test(reconciliation_neither_revives_revoked_decision_nor_admits_other_event_kinds)'],
    expected_count=5)
write_json('recovery-stages-complete.json', {'source': identity(), 'completed_unix': time.time(),
    'claim': 'matched RED/GREEN and additional scoped regressions only; full suite and production gates remain separate'})
