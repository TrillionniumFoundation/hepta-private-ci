from pathlib import Path
import base64
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/home/qq/work/hepta-modules40-20261105-da8578')
REPO = ROOT / 'source'
EVIDENCE = ROOT / 'evidence'
LABEL = 'paired-drain-diagnostic-run1'
REL = 'codex-rs/hepta-supervisor/tests/paired_process_product.rs'
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'environment.json').read_text()))
PAYLOAD = json.loads((ROOT / 'paired-diagnostic-input.json').read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain')}

def save(name, data):
    path = EVIDENCE / (LABEL + '-' + name + '.json')
    assert not path.exists()
    path.write_text(json.dumps(data, indent=2) + '\n')

before = identity()
assert before == {'commit': 'f5813506b49eb05efad00f203b9362195875892c', 'tree': '00d62de1c2f6ac8a229d23ce9d8e1b9f34b333df', 'status': ''}
assert git('rev-parse', 'HEAD:' + REL) == PAYLOAD['before_blob']
content = PAYLOAD['content'].encode()
assert hashlib.sha256(content).hexdigest() == PAYLOAD['sha256']
(REPO / REL).write_bytes(content)
fmt_log = EVIDENCE / (LABEL + '-fmt.log')
assert not fmt_log.exists()
with fmt_log.open('wb') as output:
    subprocess.run(['just', 'fmt'], cwd=REPO, env=ENV, stdout=output, stderr=subprocess.STDOUT, check=True)
assert set(git('diff', '--name-only').splitlines()) == {REL}
assert not git('ls-files', '--others', '--exclude-standard')
subprocess.run(['git', 'diff', '--check'], cwd=REPO, check=True)
source_patch = subprocess.check_output(['git', 'diff', '--binary', '--', REL], cwd=REPO)
(EVIDENCE / (LABEL + '-source.patch')).write_bytes(source_patch)
subprocess.run(['git', 'add', '--', REL], cwd=REPO, check=True)
subprocess.run(['git', 'commit', '-m', 'Diagnose bounded paired process lifecycle with protocol-correct drain fixture'], cwd=REPO, check=True)
source = identity()
assert not source['status']
raw = subprocess.check_output(['git', 'cat-file', 'commit', source['commit']], cwd=REPO)
save('source', {'before': before, 'source': source, 'commit_object_base64': base64.b64encode(raw).decode(),
     'path': REL, 'content': (REPO / REL).read_text(), 'blob': git('rev-parse', 'HEAD:' + REL),
     'patch_sha256': hashlib.sha256(source_patch).hexdigest(),
     'scope': 'fixture Drain protocol repair and diagnostic timing only; unchanged production code, assertions, budgets, retries and flags'})
print(json.dumps({'source_transition': source}), flush=True)
argv = ['just', 'test', '--locked', '-p', 'codex-hepta-supervisor', '--test', 'paired_process_product']
log = EVIDENCE / (LABEL + '.log')
assert not log.exists()
receipt = {'command': argv, 'cwd': str(REPO), 'source_before': source, 'start_unix_ns': time.time_ns(),
           'environment_sha256': hashlib.sha256((ROOT / 'environment.json').read_bytes()).hexdigest()}
start = time.monotonic()
with log.open('wb') as output:
    process = subprocess.Popen(argv, cwd=REPO, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in process.stdout:
        output.write(line)
        if any(word in line for word in [b'paired-stage', b'Summary', b'FAIL', b'error:', b'FAILED', b'Finished', b'TMT', b'timed out']):
            sys.stdout.buffer.write(line)
            sys.stdout.buffer.flush()
    code = process.wait()
receipt.update(exit=code, elapsed_seconds=time.monotonic()-start, end_unix_ns=time.time_ns(),
               source_after=identity(), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(), log_bytes=log.stat().st_size)
assert receipt['source_after'] == source
save('receipt', receipt)
print(json.dumps({'command_terminal': receipt}), flush=True)
sys.exit(code)
