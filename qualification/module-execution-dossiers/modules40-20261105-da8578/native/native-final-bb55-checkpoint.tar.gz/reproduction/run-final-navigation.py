from pathlib import Path
import base64
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time
import zlib

ROOT = Path('/home/qq/work/hepta-modules40-20261105-da8578')
REPO = ROOT / 'source'
EV = ROOT / 'evidence'
LABEL = 'final-navigation-run1'
INPUT = json.loads((ROOT / 'final-navigation-input.json').read_text())
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'environment.json').read_text()))
CODE = '38bd86afdec6ee0558af47ae58bb2813e2ad788e'
CODE_TREE = '62f767b394adbda686f21499f4af5cb4584673dc'
MERGE = '7f1a825a53946bba67122a76dfb17f713a4301de'
MERGE_TREE = '887b94539c718b0e3616d232df12036d85caa085'
LEDGER = 'qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history-final.json'


def git(*args, env=None, data=None):
    return subprocess.check_output(['git', *args], cwd=REPO, env=env, input=data).decode().strip()


def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(name, data):
    path = EV / (LABEL + '-' + name + '.json')
    assert not path.exists(), path
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


before = identity()
assert before == {'commit': 'afe0d625b01728a5fe2a1c37652573a3a1b6a097',
                  'tree': CODE_TREE, 'status': ''}
index = ROOT / 'canonical-merge073-reconstruction.index'
assert not index.exists()
index_env = ENV.copy()
index_env['GIT_INDEX_FILE'] = str(index)
git('read-tree', 'f5813506b49eb05efad00f203b9362195875892c^{tree}', env=index_env)
base = json.loads((ROOT / 'ci-repair-input.json').read_text())['base']
assert len(base['files']) == 4
for path, entry in sorted(base['files'].items()):
    content = entry['content'].encode()
    blob = git('hash-object', '-w', '--stdin', data=content)
    assert blob == entry['sha'], path
    git('update-index', '--add', '--cacheinfo', '100644,' + blob + ',' + path, env=index_env)
assert git('write-tree', env=index_env) == MERGE_TREE
assert [entry['sha'] for entry in INPUT['commits']] == [MERGE, CODE]
for entry in INPUT['commits']:
    raw = base64.b64decode(entry['raw_base64'], validate=True)
    assert hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == entry['sha']
    assert git('hash-object', '-t', 'commit', '-w', '--stdin', data=raw) == entry['sha']
assert git('rev-parse', CODE + '^{tree}') == CODE_TREE
assert git('show', '-s', '--format=%P', CODE).split() == [MERGE]
assert git('show', '-s', '--format=%P', MERGE).split() == [
    '07378034e060f23259bc99c7367f12b1284140f3',
    'f5813506b49eb05efad00f203b9362195875892c']
subprocess.run(['git', 'checkout', '--detach', CODE], cwd=REPO, check=True)
assert identity() == {'commit': CODE, 'tree': CODE_TREE, 'status': ''}
save('canonical-checkout', {'before': before, 'after': identity(), 'raw_objects': INPUT['commits'],
                          'scope': 'exact source checkout; no staged execution results transferred'})

helper = ROOT / 'refresh-navigation-explicit-pins.py'
assert digest(helper.read_bytes()) == '940f0fe0d5fccf53dc8d00dacbd4f572cf9b02419704dba0cde35d495f9e7e3b'
spec = importlib.util.spec_from_file_location('navigation_helper', helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
registry = json.loads((REPO / 'docs/modules/MODULES.json').read_text())['modules']
assert len(registry) == 40
maps_before = {}
for row in registry:
    path = 'docs/modules/' + row['id'] + '/IMPLEMENTATION_MAP.json'
    maps_before[path] = json.loads((REPO / path).read_text())
historical_ledger = REPO / 'qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history.json'
historical_bytes = historical_ledger.read_bytes()
command = ['python3', str(helper), '--root', str(REPO), '--expected-sha', CODE,
           '--expected-tree', CODE_TREE, '--ledger', LEDGER]
outputs = {}
for name, argv in [('preview', command), ('apply', command + ['--apply'])]:
    log = EV / (LABEL + '-' + name + '.log')
    assert not log.exists()
    result = subprocess.run(argv, cwd=REPO, env=ENV, capture_output=True)
    log.write_bytes(result.stdout + result.stderr)
    assert result.returncode == 0, log.read_text(errors='replace')
    outputs[name] = json.loads(result.stdout)
    print(json.dumps({name: outputs[name]}), flush=True)
assert outputs['preview']['maps'] == outputs['apply']['maps']
assert outputs['apply']['changedMaps'] > 0
assert historical_ledger.read_bytes() == historical_bytes
ledger_bytes = (REPO / LEDGER).read_bytes()
ledger = json.loads(ledger_bytes)
for path, old in maps_before.items():
    new = json.loads((REPO / path).read_text())
    assert new['sourceBase'] == old['sourceBase'], path
    assert module.semantic_view(new) == module.semantic_view(old), path
    assert len(new['operations']) == len(old['operations']), path
assert sum(len(row['operations']) for row in maps_before.values()) == 371
assert set(git('diff', '--name-only').splitlines()) == set(outputs['apply']['maps'])
assert git('ls-files', '--others', '--exclude-standard').splitlines() == [LEDGER]
fmt_log = EV / (LABEL + '-format.log')
assert not fmt_log.exists()
with fmt_log.open('wb') as out:
    subprocess.run(['just', 'fmt'], cwd=REPO, env=ENV, stdout=out, stderr=subprocess.STDOUT, check=True)
assert (REPO / LEDGER).read_bytes() == ledger_bytes
for record in ledger['records']:
    assert digest((REPO / record['mapPath']).read_bytes()) == record['replacementSha256']
assert historical_ledger.read_bytes() == historical_bytes
assert set(git('diff', '--name-only').splitlines()) == set(outputs['apply']['maps'])
assert git('ls-files', '--others', '--exclude-standard').splitlines() == [LEDGER]
subprocess.run(['git', 'diff', '--check'], cwd=REPO, check=True)
paths = sorted(outputs['apply']['maps'] + [LEDGER])
subprocess.run(['git', 'add', '--', *paths], cwd=REPO, check=True)
subprocess.run(['git', 'commit', '-m', 'Refresh final source navigation while preserving historical qualification boundaries'],
               cwd=REPO, check=True)
after = identity()
assert after['status'] == ''
assert git('show', '-s', '--format=%P', 'HEAD') == CODE
patch = subprocess.check_output(['git', 'diff', '--binary', CODE, 'HEAD'], cwd=REPO)
patch_path = EV / (LABEL + '-source.patch')
assert not patch_path.exists()
patch_path.write_bytes(patch)
files = []
for path in paths:
    content = (REPO / path).read_bytes()
    files.append({'path': path, 'content': content.decode(), 'sha256': digest(content),
                  'blob': git('rev-parse', 'HEAD:' + path), 'mode': git('ls-files', '-s', '--', path).split()[0]})
raw_commit = subprocess.check_output(['git', 'cat-file', 'commit', 'HEAD'], cwd=REPO)
export = {'before': {'commit': CODE, 'tree': CODE_TREE}, 'source': after, 'preview': outputs['preview'],
          'applied': outputs['apply'], 'files': files, 'raw_commit_base64': base64.b64encode(raw_commit).decode(),
          'patch_sha256': digest(patch), 'historical_ledger_sha256': digest(historical_bytes),
          'ledger_sha256': digest(ledger_bytes), 'operations': 371, 'modules': 40,
          'historical_source_bases_preserved': True, 'semantic_metadata_preserved': True,
          'execution_evidence_transferred': False, 'complete_unix_ns': time.time_ns()}
raw = (json.dumps(export, ensure_ascii=False) + '\n').encode()
export_path = EV / (LABEL + '-export.json')
assert not export_path.exists()
export_path.write_bytes(raw)
compressed = zlib.compress(raw, 9)
compressed_path = EV / (LABEL + '-export.json.z')
assert not compressed_path.exists()
compressed_path.write_bytes(compressed)
print(json.dumps({'final_navigation_source': after, 'files': len(files), 'raw_bytes': len(raw),
                  'raw_sha256': digest(raw), 'compressed_path': str(compressed_path),
                  'compressed_bytes': len(compressed), 'compressed_sha256': digest(compressed)}), flush=True)
