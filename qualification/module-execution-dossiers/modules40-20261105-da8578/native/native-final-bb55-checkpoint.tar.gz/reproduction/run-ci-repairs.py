from pathlib import Path
import base64
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/home/qq/work/hepta-modules40-20261105-da8578')
REPO = ROOT / 'source'
EVIDENCE = ROOT / 'evidence'
LABEL = 'ci-repair-run1'
PAYLOAD = json.loads((ROOT / 'ci-repair-input.json').read_text())
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'environment.json').read_text()))

def git(*args, env=None, data=None):
    return subprocess.check_output(['git', *args], cwd=REPO, env=env, input=data).decode().strip()

def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain')}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save(name, data):
    p = EVIDENCE / (LABEL + '-' + name + '.json')
    assert not p.exists(), p
    p.write_text(json.dumps(data, indent=2) + '\n')

def raw_commit(sha):
    raw = subprocess.check_output(['git', 'cat-file', 'commit', sha], cwd=REPO)
    return base64.b64encode(raw).decode()

def run(name, argv, cwd=REPO):
    before = identity()
    assert not before['status']
    log = EVIDENCE / (LABEL + '-' + name + '.log')
    assert not log.exists()
    rec = {'command': argv, 'cwd': str(cwd), 'source_before': before, 'start_unix_ns': time.time_ns(),
           'environment_sha256': digest((ROOT / 'environment.json').read_bytes())}
    start = time.monotonic()
    with log.open('wb') as output:
        proc = subprocess.Popen(argv, cwd=cwd, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in proc.stdout:
            output.write(line)
            if any(t in line for t in [b'Summary', b'FAIL', b'error:', b'error[', b'FAILED', b'Finished', b'TMT']):
                sys.stdout.buffer.write(line); sys.stdout.buffer.flush()
        code = proc.wait()
    rec.update(exit=code, elapsed_seconds=time.monotonic()-start, end_unix_ns=time.time_ns(),
               source_after=identity(), log_sha256=digest(log.read_bytes()), log_bytes=log.stat().st_size)
    assert rec['source_after'] == before
    save(name, rec)
    print(json.dumps({'command_terminal': name, **rec}), flush=True)
    return code

before = identity()
assert before == {'commit': '6dba3945714eeccc79fcf7d2f36410408ea69710', 'tree': '92b53bc9b5e6b8994245df16ab776df58df48b5c', 'status': ''}
index = ROOT / 'base-073-reconstruction.index'
assert not index.exists()
index_env = ENV.copy(); index_env['GIT_INDEX_FILE'] = str(index)
git('read-tree', 'dbec41758b5334c7a465ffaa57db731f770b2fb3^{tree}', env=index_env)
base_files = dict(PAYLOAD['base']['files'])
base_paths = set(base_files)
for item in PAYLOAD['base_objects']['commits']:
    sha = item['sha']
    meta = next(m for m in PAYLOAD['base']['commits'] if m['sha'] == sha)
    selected = [p for p in base_files if (p.startswith('codex-rs/tui/')) == (sha == 'd4a79dd6416dc5b4b58f4537b40b608dc806da5f')]
    for p in selected:
        entry = base_files[p]; content = entry['content'].encode()
        blob = git('hash-object', '-w', '--stdin', data=content)
        assert blob == entry['sha'], (p, blob)
        git('update-index', '--add', '--cacheinfo', '100644,' + blob + ',' + p, env=index_env)
    assert git('write-tree', env=index_env) == meta['tree']['sha']
    raw = base64.b64decode(item['raw_base64'])
    assert hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == sha
    assert git('hash-object', '-t', 'commit', '-w', '--stdin', data=raw) == sha
merge_log = EVIDENCE / (LABEL + '-upstream-merge.log')
assert not merge_log.exists()
with merge_log.open('wb') as out:
    subprocess.run(['git', 'merge', '--no-ff', '--no-commit', '07378034e060f23259bc99c7367f12b1284140f3'], cwd=REPO, stdout=out, stderr=subprocess.STDOUT, check=True)
assert set(git('diff', '--cached', '--name-only').splitlines()) == base_paths
assert not git('diff', '--name-only')
subprocess.run(['git', 'commit', '-m', 'Merge reviewed TUI borrowing and independent issuer expiry fixture corrections'], cwd=REPO, check=True)
merged = identity(); assert not merged['status']
assert git('show', '-s', '--format=%P', 'HEAD').split() == [before['commit'], '07378034e060f23259bc99c7367f12b1284140f3']
save('upstream-source', {'before': before, 'source': merged, 'commit_object_base64': raw_commit(merged['commit']),
     'files': sorted(base_paths), 'merge_log_sha256': digest(merge_log.read_bytes())})
print(json.dumps({'upstream_source': merged}), flush=True)

for item in PAYLOAD['repairs']:
    p = item['path']; assert git('rev-parse', 'HEAD:' + p) == item['before_blob']
    content = item['content'].encode(); assert digest(content) == item['sha256']
    (REPO / p).write_bytes(content)
format_packages = ['codex-utils-path', 'codex-hepta-prompt-registry', 'codex-hepta-contracts', 'codex-hepta-agentd',
                   'codex-exec-server', 'codex-app-server', 'codex-app-server-client']
fmt = ['cargo', 'fmt']
for package in format_packages: fmt += ['--package', package]
fmt_log = EVIDENCE / (LABEL + '-native-format.log')
assert not fmt_log.exists()
with fmt_log.open('wb') as out:
    subprocess.run(fmt, cwd=REPO / 'codex-rs', env=ENV, stdout=out, stderr=subprocess.STDOUT, check=True)
allowed = {x['path'] for x in PAYLOAD['repairs']} | base_paths | {x['path'] for x in PAYLOAD['windows_format_oracle']}
changed = set(git('diff', '--name-only').splitlines())
assert changed <= allowed, sorted(changed - allowed)
oracle_results = []
for item in PAYLOAD['windows_format_oracle']:
    actual = digest((REPO / item['path']).read_bytes())
    assert actual == item['after_sha256'], (item['path'], actual, item['after_sha256'])
    oracle_results.append({'path': item['path'], 'sha256': actual, 'matches_original_windows_diagnostic': True})
subprocess.run(['git', 'diff', '--check'], cwd=REPO, check=True)
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=REPO)
(EVIDENCE / (LABEL + '-source.patch')).write_bytes(patch)
subprocess.run(['git', 'add', '--', *sorted(changed)], cwd=REPO, check=True)
subprocess.run(['git', 'commit', '-m', 'Preserve process regression oracles and repair exact platform CI gates'], cwd=REPO, check=True)
source = identity(); assert not source['status']
export = {'before': merged, 'source': source, 'commit_object_base64': raw_commit(source['commit']),
          'format_command': fmt, 'windows_format_oracle': oracle_results, 'patch_sha256': digest(patch),
          'files': [{'path': p, 'blob': git('rev-parse', 'HEAD:' + p), 'content': (REPO / p).read_text(),
                     'sha256': digest((REPO / p).read_bytes())} for p in sorted(changed)]}
save('source-export', export)
print(json.dumps({'repair_source': source, 'changed_files': sorted(changed)}), flush=True)

checks = {}
checks['original-format-gate'] = run('original-format-gate', ['cargo', 'fmt', '--package', 'codex-utils-path', '--package',
    'codex-hepta-prompt-registry', '--package', 'codex-hepta-contracts', '--package', 'codex-hepta-agentd', '--', '--check'], cwd=REPO/'codex-rs')
checks['strict-clippy'] = run('strict-clippy', ['just', 'clippy', '--locked', '-p', 'codex-exec-server', '-p', 'codex-app-server',
    '-p', 'codex-app-server-client', '--', '-D', 'warnings'])
if checks['strict-clippy'] == 0:
    checks['two-library-regression'] = run('two-library-regression', ['just', 'test', '--locked', '-p', 'codex-exec-server',
        '-p', 'codex-app-server-client', '--lib'])
    checks['app-server-process-regression'] = run('app-server-process-regression', ['just', 'test', '--locked', '-p',
        'codex-app-server', '--test', 'all', '-E', 'test(process_exec)', '--no-tests', 'fail'])
save('summary', {'source': source, 'checks': checks, 'source_after': identity(),
    'scope': 'Linux source regression and strict Clippy; not a replacement for Windows CI or seven-package acceptance'})
sys.exit(0 if all(code == 0 for code in checks.values()) else 1)
