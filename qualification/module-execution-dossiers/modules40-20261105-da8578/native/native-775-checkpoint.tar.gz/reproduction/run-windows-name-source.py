from pathlib import Path
import base64
import hashlib
import json
import os
import subprocess
import time
import zlib

ROOT = Path('/home/qq/work/hepta-modules40-20261105-da8578')
REPO = ROOT / 'source'
EV = ROOT / 'evidence'
LABEL = 'windows-name-source-run1'
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / 'environment.json').read_text()))
PAYLOAD = json.loads((ROOT / 'windows-name-input.json').read_text())
BEFORE = {'commit': '797116d61cf422c26274ffef31297dce84a53a80',
          'tree': '67ce024db1679aa6cd301856ba3a694ea18bc4b6', 'status': ''}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()


def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def digest(data):
    return hashlib.sha256(data).hexdigest()


assert identity() == BEFORE
prior = json.loads((EV / 'spelling-canonical-run1-summary.json').read_text())
assert prior['source'] == BEFORE and prior['source_after'] == BEFORE
assert len(prior['checks']) == 7 and all(code == 0 for code in prior['checks'].values())
allowed = {
    'codex-rs/utils/pty/src/win/native_observation_tests.rs',
    'codex-rs/windows-sandbox-rs/src/unified_exec/delete_permission_tests.rs',
}
assert {row['path'] for row in PAYLOAD['files']} == allowed
assert len(PAYLOAD['files']) == 2
for row in PAYLOAD['files']:
    path = row['path']
    assert git('rev-parse', 'HEAD:' + path) == row['beforeBlob']
    old = (REPO / path).read_bytes()
    assert digest(old) == row['beforeSha256']
    new = row['content'].encode()
    assert digest(new) == row['afterSha256']
    assert hashlib.sha1(b'blob ' + str(len(new)).encode() + b'\0' + new).hexdigest() == row['afterBlob']
    (REPO / path).write_bytes(new)
assert set(git('diff', '--name-only').splitlines()) == allowed
fmt = ['cargo', 'fmt', '--package', 'codex-utils-pty', '--package', 'codex-windows-sandbox']
log = EV / (LABEL + '-format.log')
assert not log.exists()
start = time.monotonic()
with log.open('wb') as out:
    subprocess.run(fmt, cwd=REPO / 'codex-rs', env=ENV, stdout=out, stderr=subprocess.STDOUT, check=True)
assert set(git('diff', '--name-only').splitlines()) == allowed
assert not git('ls-files', '--others', '--exclude-standard')
subprocess.run(['git', 'diff', '--check'], cwd=REPO, check=True)
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=REPO)
p = EV / (LABEL + '-source.patch')
assert not p.exists()
p.write_bytes(patch)
subprocess.run(['git', 'add', '--', *sorted(allowed)], cwd=REPO, check=True)
subprocess.run(['git', 'commit', '-m', 'Disambiguate native Windows test handles and assertion macros'], cwd=REPO, check=True)
source = identity()
assert source['status'] == ''
assert git('show', '-s', '--format=%P', 'HEAD') == BEFORE['commit']
raw_commit = subprocess.check_output(['git', 'cat-file', 'commit', 'HEAD'], cwd=REPO)
files = []
for path in sorted(allowed):
    content = (REPO / path).read_bytes()
    reviewed = next(row for row in PAYLOAD['files'] if row['path'] == path)
    files.append({'path': path, 'mode': git('ls-files', '-s', '--', path).split()[0],
                  'blob': git('rev-parse', 'HEAD:' + path), 'sha256': digest(content),
                  'content': content.decode(), 'reviewed_sha256': reviewed['afterSha256'],
                  'formatter_changed_reviewed_postimage': digest(content) != reviewed['afterSha256']})
export = {'before': BEFORE, 'source': source, 'files': files,
          'raw_commit_base64': base64.b64encode(raw_commit).decode(), 'patch_sha256': digest(patch),
          'format': {'command': fmt, 'exit': 0, 'elapsed_seconds': time.monotonic() - start,
                     'log_sha256': digest(log.read_bytes()), 'log_bytes': log.stat().st_size},
          'scope': 'two Windows-only test source name-resolution fixes and native formatting; no Windows compilation or execution claimed',
          'execution_evidence_transferred': False}
data = (json.dumps(export, ensure_ascii=False) + '\n').encode()
p = EV / (LABEL + '-export.json')
assert not p.exists()
p.write_bytes(data)
z = zlib.compress(data, 9)
q = EV / (LABEL + '-export.json.z')
assert not q.exists()
q.write_bytes(z)
print(json.dumps({'windows_name_source': source, 'files': len(files),
                  'raw_bytes': len(data), 'raw_sha256': digest(data),
                  'compressed_path': str(q), 'compressed_bytes': len(z),
                  'compressed_sha256': digest(z),
                  'formatter_changed_paths': [f['path'] for f in files if f['formatter_changed_reviewed_postimage']]}), flush=True)
