from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import subprocess
import tarfile
import time

ROOT = Path('/home/qq/work/hepta-modules40-20261105-da8578')
REPO = ROOT / 'source'
EV = ROOT / 'evidence'
COMMIT = '775bf555b0a7faf6eed17627acb0d0433294b737'
TREE = 'e6f4644152d11a06457fdd92d8e5066675b26565'
DEST = ROOT / 'native-775-checkpoint.tar.gz'
assert not DEST.exists()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()


def identity():
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def stable_stat(path):
    s = path.stat()
    return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_mode, s.st_nlink)


expected = {'commit': COMMIT, 'tree': TREE, 'status': ''}
assert identity() == expected
final = json.loads((EV / 'windows-canonical-run1-summary.json').read_text())
assert final['source'] == expected and final['source_after'] == expected
assert len(final['checks']) == 7 and all(code == 0 for code in final['checks'].values())
seven = json.loads((EV / 'seven-package-run4-summary.json').read_text())
assert seven['source'] == expected and seven['source_after'] == expected
assert seven['runner_exit'] == 0 and seven['audit_exit'] == 0
assert len(seven['qualification_checks']) == 7 and all(code == 0 for code in seven['qualification_checks'].values())
environment = (ROOT / 'environment.json').read_bytes()
assert digest(environment) == '0eba31f9edc07ffc869f685c2dfcf3eab856be5f4dce622721ed36f43b0875d5'
base_archive = ROOT / 'native-final-bb55-checkpoint.tar.gz'
assert digest(base_archive.read_bytes()) == '28424496bd400d6c5ff6370158f7b093355e463f19ebb550b1df6e7330504886'
prefixes = ('windows-name-source-run1', 'seven-package-run4', 'windows-canonical-run1')
files = {}
stable = {}
for path in sorted(EV.iterdir()):
    if not path.name.startswith(prefixes):
        continue
    assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1, path
    stat = stable_stat(path)
    content = path.read_bytes()
    assert stable_stat(path) == stat
    files['native/' + path.name] = content
    stable[path] = (stat, digest(content))
assert len(files) >= 40
for name in ['environment.json', 'run-final-native.py', 'run-windows-name-source.py',
             'run-windows-canonical.py', 'windows-name-input.json',
             'windows-canonical-object.json', 'refresh-navigation-explicit-pins.py',
             'archive-windows-native.py']:
    path = ROOT / name
    assert path.is_file() and not path.is_symlink()
    files['reproduction/' + name] = path.read_bytes()
for path in sorted((ROOT / 'audit-tools').rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts:
        assert not path.is_symlink()
        files['reproduction/audit-tools/' + path.relative_to(ROOT / 'audit-tools').as_posix()] = path.read_bytes()
identities = []
for sha in ['797116d61cf422c26274ffef31297dce84a53a80', '587a37f7cb3196426962024a094dab8947596fef', COMMIT]:
    raw = subprocess.check_output(['git', 'cat-file', 'commit', sha], cwd=REPO)
    assert hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == sha
    files['native-source-history/' + sha + '.commit'] = raw
    identities.append({'commit': sha, 'tree': git('rev-parse', sha + '^{tree}'),
                       'parents': git('show', '-s', '--format=%P', sha).split()})
files['native-source-history/identities.json'] = (json.dumps(identities, indent=2) + '\n').encode()
manifest = {
    'schema': 'hepta.native-evidence-successor-checkpoint.v1', 'source': expected,
    'captured_unix_ns': time.time_ns(),
    'scope': 'new pinned successor evidence; earlier experiments remain in the explicitly linked immutable base archive',
    'base_evidence': {'commit': 'f038947fd20992e15213d41f7f6d8ac1d2ca10fc',
                      'path': 'qualification/module-execution-dossiers/modules40-20261105-da8578/native/native-final-bb55-checkpoint.tar.gz',
                      'archive_bytes': base_archive.stat().st_size,
                      'archive_sha256': '28424496bd400d6c5ff6370158f7b093355e463f19ebb550b1df6e7330504886',
                      'source_commit': 'bb55b0d7d263c396ec504c45393d938c3428dae5'},
    'final_seven_package_summary': seven['native_summary'], 'final_checks': final['checks'],
    'entries': [{'path': name, 'bytes': len(content), 'sha256': digest(content)}
                for name, content in sorted(files.items())],
}
files['MANIFEST.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
for path, (stat, sha) in stable.items():
    assert stable_stat(path) == stat and digest(path.read_bytes()) == sha
assert identity() == expected
with DEST.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, content in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size = len(content)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(content))
    raw.flush()
    os.fsync(raw.fileno())
data = DEST.read_bytes()
print(json.dumps({'archive_path': str(DEST), 'bytes': len(data), 'sha256': digest(data),
                  'files': len(files), 'manifest_entries': len(manifest['entries']),
                  'source': expected, 'summary': seven['native_summary'],
                  'manifest_sha256': digest(files['MANIFEST.json'])}), flush=True)
