# 40 模块源码事实报告的重建

生成器只读取显式传入的固定源码资料，生成中文 40 行表、完整事实 JSON、owner/调用/写入附录、全部 371 条操作与原文 gate 附录、8 条关键路径和本地验证记录。原生执行、平台 CI、发布或验收结论由独立执行章节记录。

## 当前输入身份

- Canonical commit：`bb55b0d7d263c396ec504c45393d938c3428dae5`
- Canonical tree：`19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1`
- 40 张 Map 的来源链：原始下载 manifest → f581 的 9 张导航替换 → 最终的 11 张导航替换；与初始 manifest 相比，受影响模块的并集为 13 张。
- 本地 `integration/navigation-baseline` 的 Map 文件已经包含 f581 的 9 张替换，但该目录的 manifest 仍是初始下载清单。最终生成器使用完整 f581 facts 核对中间层和独立的最终 40 blob 清单，不从目录名推断版本。
- `f581-snapshot` 保存原报告、原事实与原生成器的精确字节；历史的 `sourceBase`、观察字段与 source-navigation ledger 不能通过全局替换升级身份。

## 重建命令

在 `/workspace/scratch/da8578abae00` 运行：

```bash
python final-report-prep/build_source_report.py \
  --source-commit bb55b0d7d263c396ec504c45393d938c3428dae5 \
  --source-tree 19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1 \
  --map-dir final-report-prep/final-source-snapshot/docs/modules \
  --verified-blobs final-report-prep/final-source-verified-blobs.json \
  --registry-file final-report-prep/final-source-snapshot/docs/modules/MODULES.json \
  --canonical-objects integration/canonical-final-object.json \
  --prior-facts final-report-prep/f581-snapshot/MODULES40-SOURCE-FACTS.json \
  --source-history qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history.json=final-report-prep/final-source-snapshot/qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history.json \
  --source-history qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history-final.json=final-report-prep/final-source-snapshot/qualification/module-execution-dossiers/modules40-20261105-da8578/source-navigation-history-final.json \
  --output-dir final-report-prep
```

加上 `--validate-only` 可执行全部输入与语义检查而不写报告。参数中的本地路径可以是绝对路径；`--source-history` 按清单中的每份 ledger 重复传入 `仓库路径=本地路径`。

## Blob 清单格式与检查范围

`--verified-blobs` 接受 `hepta.modules40.verified-source-blobs.v1`。必须提供 repository、sourceCommit、sourceTree、登记表的路径/blob/SHA256/字节数、40 条唯一 Map 文件记录以及全部 source-history ledger 记录。每条 Map 包含仓库路径、blob、SHA256、字节数、origin 和布尔值 changedByFinalNavigation；navigationReplacementMapCount 必须与实际记录数相等。provenance 中 executionEvidenceTransferred 必须为 false。

生成器复算每个 Git blob、SHA256 和字节数，并复算原始 canonical Git commit 对象的 SHA-1、tree 和父提交。它与前一份完整 facts 逐模块比较原有 owner、caller/writer、declared/resolved roots、sourceBase、raw gates 和 claimBoundary。完整非导航语义比较只移除已批准的导航字段：sourceObjects、observedAtHead、observedSourcePaths、mappingSourceIdentityMode、operations.sourceBlob、productCallers.blobSha，以及 path_blob_manifest_v1 条目的 blobSha。

最终 JSON 保留每个当前 Map 的全部原字段，新增说明字段放在 reportMetadata 等单独字段中。历史 ledger 的完整原始 JSON 文档单独保存在 sourceHistory，并记录其原始字节的 blob/SHA256。JSON 序列化后再次逐值核对；模块数必须为 40、操作映射数必须为 371、全部 sourceRootPresent 必须为 true、全部 productionImplementation 必须为 false。操作/gate 附录的 120 个 JSON 区块再次解析并逐值对比，确保 40 模块的操作、仓库内 gate、外部 gate 没有被表格摘要替代或改写。

这份本地验证核对报告与已验证输入之间的一致性；它不会执行模块测试，也不会把源码导航记录当成部署验收。
