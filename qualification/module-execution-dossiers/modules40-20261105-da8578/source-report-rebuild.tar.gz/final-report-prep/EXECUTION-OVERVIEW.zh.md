# 本轮完成情况与证据边界

本轮已经把 40 模块的源码汇总推进到一个固定、可审阅的集成候选，并在该候选上完成 Linux 原生七包回归及相关严格检查。最终提交为 [`bb55b0d7d263c396ec504c45393d938c3428dae5`](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/bb55b0d7d263c396ec504c45393d938c3428dae5)，tree 为 `19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1`；草稿集成 PR 为 [#4888](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/4888)。

40 个登记源码根均存在，371 项操作映射完整保留。**全部 40 个 `productionImplementation` 仍为 false；公共拓扑的 DENY_ALL 边界保持。** 当前结论是固定源码和声明范围内原生回归通过；真实 provider、产品默认生命周期、目标宿主部署、平台 CI、独立 custody 与独立接收方验收继续按各自门槛记录。完整事实见 [源码事实 JSON](MODULES40-SOURCE-FACTS.json)、[源码报告校验](SOURCE-REPORT-VALIDATION.json) 和 [原生必需案例审计](native/seven-package-run2-required-tests.69.native-audit.json)。

## 最终候选实际执行结果

下列结果全部来自 `bb55b0d7… / 19116ccd…`，每条命令执行前后的工作区均干净且身份一致。最终运行服务记录为 `succeeded / exit 0`，输出完整、持久化完成，没有外层超时或取消。原始记录见 [总回执](native/final-canonical-run1-summary.json) 和 [运行服务终态](runtime/final-canonical-bb55-runtime-status.json)。

| 验证范围 | 结果 | 可核对证据 |
| --- | --- | --- |
| 七个完整包，无案例过滤 | **1,219 passed，78 skipped，0 failed，0 timed out**；nextest 执行阶段 36.626 秒 | [原始日志](native/seven-package-run2-original-test.log)、[原始 JUnit](native/seven-package-run2.junit.xml)、[命令回执](native/seven-package-run2-original-test.json) |
| 69 项必需案例及全套失败检查 | **69/69 clean；整体 CLEAN，exit 0** | [审计结果](native/seven-package-run2-required-tests.69.native-audit.json)、[绑定清单](native/seven-package-run2-required-tests.69.source-bound.json) |
| 七项原严格仓库检查 | **7/7 exit 0** | [七包总览](native/seven-package-run2-summary.json) |
| 原全工作区 Rust 格式检查 | **exit 0** | [回执](native/final-canonical-run1-original-workspace-format.json) |
| 原四包格式检查 | **exit 0**；此处实际执行环境为 Linux | [回执](native/final-canonical-run1-original-four-package-format.json) |
| 三个进程包的原 CI Clippy 策略 | **exit 0** | [回执](native/final-canonical-run1-original-ci-policy-clippy.json) |
| ExecServer 与 AppServerClient 两个完整 library target | **319 passed，0 skipped** | [原始日志](native/final-canonical-run1-two-library-regression.log)、[回执](native/final-canonical-run1-two-library-regression.json) |
| AppServer `process_exec` 选择范围 | **5 passed，1,016 skipped** | [原始日志](native/final-canonical-run1-app-server-process-regression.log)、[回执](native/final-canonical-run1-app-server-process-regression.json) |

七包为 `codex-hepta-agent-protocol`、`codex-hepta-agentd`、`codex-hepta-infer-worker-host`、`codex-hepta-runtime`、`codex-hepta-contracts`、`codex-hepta-learning-ledger`、`codex-hepta-supervisor`。69 项清单用于复核完整运行结果，不是测试过滤器；其中 protocol 3、Agentd 15、runtime 3、worker 40、ledger 5、supervisor 3。Contracts 虽没有单独列入这 69 项，仍参加了整个包的执行。

原 `local` profile、超时、重试、断言和包选择保持；仅加入 JUnit 报告配置和原始 Cargo metadata 输入以保存证据。78 个跳过项保持 nextest 原有选择结果，不算通过。不同命令的案例数分列，不相加成不明范围的“总通过数”。完整包执行不等于整个仓库的全平台测试，也不等于真实业务部署已经验收。预检的工具链、命令、环境与摘要见 [preflight](native/seven-package-run2-preflight.json)。

七项严格检查分别为 implementation maps qualification、module status facts、strict module registry、module documents qualification、Chef custody、Rust CI feedback、module docs metadata。Clippy 使用原 CI 的三个 deny 项：`clippy::correctness`、`clippy::await_holding_lock`、`clippy::await_holding_invalid_type`。

## 本轮实际修复了什么

### 1. 记忆读取的最终使用竞态

Agentd 在 retrieval/ranker 回调之后、成功回执之前再次读取实际 SQLite owner cut。这样，准备阶段通过后发生的删除、纠正、到期、撤销或 owner 变化，不能靠旧快照继续成功。修复沿用原 store owner 和当前性边界，没有另造一套 writer。固定源码见 [cognitive_context.rs](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/bb55b0d7d263c396ec504c45393d938c3428dae5/codex-rs/hepta-agentd/src/cognitive_context.rs)。

### 2. 学习账本的丢 ACK 对账与 witness 恢复

新增精确已提交记录的 `CommittedLearningAppendV1`，绑定 ledger、record ID、event digest 和 predecessor chain digest；用它核对历史已认证的 Decision/Outcome 追加。对账不会为缺失的正文追加新记录，不会续发过期权限，也不会复活已经撤销的授权。Witness 恢复在向 owner 暴露完整已解析帧前完成同步，完整帧和截断尾部均保留真实 I/O 失败行为。固定源码见 [production_reconciliation.rs](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/bb55b0d7d263c396ec504c45393d938c3428dae5/codex-rs/hepta-learning-ledger/src/production_reconciliation.rs) 和 [witness.rs](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/bb55b0d7d263c396ec504c45393d938c3428dae5/codex-rs/hepta-learning-ledger/src/witness.rs)。

### 3. Supervisor 接管锁的进程所有权

锁由实际获取它的 PID 执行释放；被动复制和 fork 继承的描述符不能替代原 owner 保留或释放错误的锁。原代次、授权与恢复围栏保持，回归包含真实 fork。固定源码见 [writer_handoff_lock.rs](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/bb55b0d7d263c396ec504c45393d938c3428dae5/codex-rs/hepta-supervisor/src/writer_handoff_lock.rs)。Windows PTY 的局部修复只保持原错误类别，没有据此声明 ACL 或 Windows 私有状态资格完成。

### 4. 完整回归暴露的配对子进程夹具问题

旧 `f581` 的完整七包运行真正失败过：两对进程用例没有得到 Drain acknowledgement，五对进程用例在 60 秒预算内超时。诊断证实，受控子进程原先对所有方法返回 Health；修复后 Drain 必须符合 schema、spawn 身份、持久 Draining 状态和既有代次规则，未支持的方法继续拒绝。

五对进程的另一个瓶颈是重复安装、读取并验证约 313 MB 的调试测试镜像。修复仅在私有临时目录中用系统 `strip -S` 生成约 48 MB 的子进程镜像，再走原安装、完整摘要、执行和接管路径；父测试二进制、构建 profile、60 秒预算及断言保持。缺工具、strip 非零或输出缺失都会失败，没有静默回退。源码见 [paired_process_product.rs](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/bb55b0d7d263c396ec504c45393d938c3428dae5/codex-rs/hepta-supervisor/tests/paired_process_product.rs)。

这些用例启动真实 OS 子进程，但子进程协议仍是受控 fixture；它们不证明真实 Agentd 产品进程或 Matrix homeserver 已完成部署验收。GNU strip 的实际工具身份已记录；Darwin 的二进制签名和原生执行要求仍由其平台门槛验证。

### 5. 原 CI 集成错误与源码格式

合入实际上游 `07378034` 的 TUI borrowing 和独立 issuer expiry fixture 修正，修复 AppServer 初始化 API 返回值、AppServerClient 测试缺少 `trace: None`，并让 ExecServer 的异步观察测试由阻塞 worker 持有原 process-map lock。测试仍在锁占用期间检查原行为，没有提前释放锁或降低 lint。

CI 的 timing 与 source custody 上传拆为两个独立步骤，保留各自文件模式、固定 action、`always()` 和原缺失文件策略，解决跨磁盘公共根目录问题。没有通过修改 Bazel lint、提高超时或放宽检查来隐藏失败。

原全工作区 formatter 另修正 10 个 Rust 文件。独立审阅核对了全部 diff、字面量、import 集合和断言宏；变化限于格式及等价的单表达式布局。证据见 [格式审阅](review/workspace-format10-review.json)。最终候选随后重新执行原格式命令并通过。

## 失败与中间候选保持各自身份

| 固定身份或阶段 | 原结果 | 本轮如何处理 |
| --- | --- | --- |
| `a3a987d0` 真实 combined RED | 4 failed、0 passed、757 skipped，exit 100 | 原失败与后续修复分开保留；此前 CMake/OpenSSL 构建准备失败没有冒充行为 RED |
| `4fbf4f10` Supervisor RED | 2 failed、108 skipped，exit 100 | 真实 fork/锁故障证据保留 |
| `6d63f3f2` 主修复 GREEN | 4 passed、759 skipped，exit 0 | 只证明该原生候选和这 4 项范围 |
| `c1f586bc` 后续定向 GREEN | handoff 3 passed；witness/ledger 5 passed | 两组与前一组存在重叠，不虚报新增唯一案例总数 |
| `f5813506` 完整七包 run1 | 1,217 passed、1 failed、1 timed out、78 skipped，exit 100；69 项通过但整体 NOT_CLEAN | 原始失败、重试、超时、JUnit 和运行服务失败终态完整保留 |
| `6dba3945` Drain 诊断 | 两个执行用例中 1 passed、1 timed out，另 1 skipped | 保留真实失败和时序证据，再处理镜像准备瓶颈 |
| `a00ff322` CI 修复 | 原三策略 Clippy 通过；两 library 319 passed；AppServer 选择 5 passed | 先前额外 `-D warnings` 因既有 AsyncFd deprecation 失败也保留，不把它称为原 CI 策略 |
| `d068620d` 私有镜像修复 | paired target 2 passed、1 skipped | 保留原预算和选择，仅增加成功输出报告参数 |
| `afe0d625` 全工作区格式 | 原格式检查 exit 0 | 格式前失败和格式后成功均保留 |
| `bb55b0d7` 最终 canonical | 本报告的完整七包与全部相关检查通过 | 在确切最终 commit/tree 上重新执行，不从同树中间候选搬运结果 |

最早的四包历史证据和本轮 run1 均仍可追溯；[run1 不可变检查点](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/acf11067530fc12386b090e7e067e518b182088f/qualification/module-execution-dossiers/modules40-20261105-da8578) 未覆盖。最终原生归档还包含原来 78 份 native 文件的完全相同字节。导航准备的一次 list/dict 脚本错误发生在 canonical checkout 和测试之前，作为准备失败单独保留，不算模块测试失败，也不算 RED/GREEN。

## 源码导航与历史证据

最终代码父提交是 `38bd86af…`；其父为实际 GitHub merge `7f1a825a…`，有序父提交为 `07378034…` 和 `f5813506…`。最后 `bb55b0d7…` 只更新受影响的源码导航及一份新历史 ledger。对应原生导航提交 `8ab12f16…` 与 canonical tree 相同，但 commit 不同；本报告只用实际执行 `bb55` 的回执作为最终原生结果。

40 张 Map 的历史 `sourceBase`、`claimBoundary`、owner、caller/writer、371 条操作语义和原 gate 均保持。本轮刷新 11 张 Map；结合上一轮 9 张导航，与初始清单相比变化并集为 13 张。旧 history ledger 字节不变，新 ledger 单独记录前后 Map blob、SHA256、当前观察身份和不可转移的执行边界。[独立重建核对](INDEPENDENT-MAP-CROSSCHECK.json) 验证全部 40 张最终 Map 字节一致。

操作/gate 附录保留 **108 条 `repositoryControlledGaps` 和 140 条 `externalEvidenceGates` 原文登记项**。这些条目包含跨模块重叠和不同层级要求，不是 248 个独立 bug，也不是生产完成百分比。原 gate 中提到的候选回归要结合上面的实际执行总览阅读：本次 Linux 原生范围已经完成；平台、有序合并与真实产品、部署、独立验收范围继续分别计账。

## 原始证据与复核入口

最终原生归档：[native-final-bb55-checkpoint.tar.gz](native/native-final-bb55-checkpoint.tar.gz)。大小为 1,026,914 字节，SHA256 为 `28424496bd400d6c5ff6370158f7b093355e463f19ebb550b1df6e7330504886`，包含 201 个文件，其中 MANIFEST 对其余 200 个文件逐项登记字节数和 SHA256。原始 JUnit 为 280,619 字节，SHA256 为 `8ef498e557bbc63e20230d66af451f1d7c97907ce7934201be171f368a185229`。

归档含原始日志、JUnit、Cargo metadata、命令/环境/源码回执、历次失败、源补丁、raw commit 对象与复现脚本。直接可阅的最终回执另列在 `native/`；报告不会把本证据文档的提交身份当作已执行源码身份。完整发布文件摘要见 [PUBLICATION-MANIFEST.json](PUBLICATION-MANIFEST.json)。
