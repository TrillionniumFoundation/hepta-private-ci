"""Stage the fixed 775 source checkpoint; verify zero module navigation changes."""

from pathlib import Path
import base64
import copy
import hashlib
import json
import shutil


ROOT = Path.cwd()
OUT = ROOT / "windows-775-report-prep"
SOURCE = "775bf555b0a7faf6eed17627acb0d0433294b737"
TREE = "e6f4644152d11a06457fdd92d8e5066675b26565"
PRIOR = "797116d61cf422c26274ffef31297dce84a53a80"
PRIOR_TREE = "67ce024db1679aa6cd301856ba3a694ea18bc4b6"
NATIVE = "587a37f7cb3196426962024a094dab8947596fef"
PRIOR_DIR = ROOT / "successor-report-prep"
FACTS_PATH = PRIOR_DIR / "MODULES40-SOURCE-FACTS.json"
MANIFEST_PATH = PRIOR_DIR / "source-verified-blobs.json"
EXPORT_PATH = ROOT / "integration/windows-source-evidence/windows-name-source-run1-export.json"
PREVIEW_PATH = ROOT / "integration/windows-source-evidence/windows-canonical-run1-navigation-preview.json"
OBJECT_PATH = ROOT / "integration/canonical-windows-final-object.json"
COMPARE_PATH = OUT / "github-797-to-775-compare.json"
REGISTRY_CAPTURE_PATH = OUT / "github-775-registry-capture.json"
CHANGED_PATHS = {
    "codex-rs/utils/pty/src/win/native_observation_tests.rs",
    "codex-rs/windows-sandbox-rs/src/unified_exec/delete_permission_tests.rs",
}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git_object(kind, data):
    return hashlib.sha1(kind.encode() + b" " + str(len(data)).encode() + b"\0" + data).hexdigest()


def read(path):
    data = path.read_bytes()
    return data, json.loads(data)


def label(path):
    return str(path.relative_to(ROOT))


def file_fact(path):
    data = path.read_bytes()
    return {"path": label(path), "bytes": len(data), "sha256": sha256(data)}


def verify_blob(data, expected):
    assert git_object("blob", data) == expected["blob"]
    assert sha256(data) == expected["sha256"]
    if "bytes" in expected:
        assert len(data) == expected["bytes"]


def verify_commit(data, commit, tree):
    assert git_object("commit", data) == commit
    headers = data.split(b"\n\n", 1)[0].splitlines()
    assert headers[0] == b"tree " + tree.encode()
    assert [line[7:].decode() for line in headers if line.startswith(b"parent ")] == [PRIOR]


prior_bytes, prior = read(FACTS_PATH)
manifest_bytes, prior_manifest = read(MANIFEST_PATH)
export_bytes, export = read(EXPORT_PATH)
preview_bytes, preview = read(PREVIEW_PATH)
object_bytes, objects = read(OBJECT_PATH)
compare_bytes, compare = read(COMPARE_PATH)
registry_capture_bytes, registry_capture = read(REGISTRY_CAPTURE_PATH)

assert prior["sourceSnapshot"]["commit"] == prior_manifest["sourceCommit"] == PRIOR
assert prior["sourceSnapshot"]["tree"] == prior_manifest["sourceTree"] == PRIOR_TREE
assert export["before"] == {"commit": PRIOR, "tree": PRIOR_TREE, "status": ""}
assert export["source"] == {"commit": NATIVE, "tree": TREE, "status": ""}
assert export["execution_evidence_transferred"] is False
assert {row["path"] for row in export["files"]} == CHANGED_PATHS
assert export["format"]["exit"] == 0
verify_commit(base64.b64decode(export["raw_commit_base64"], validate=True), NATIVE, TREE)
canonical = [row for row in objects["commits"] if row["sha"] == SOURCE]
assert len(canonical) == 1
verify_commit(base64.b64decode(canonical[0]["raw_base64"], validate=True), SOURCE, TREE)

assert compare["base_commit"]["sha"] == compare["merge_base_commit"]["sha"] == PRIOR
assert compare["base_commit"]["commit"]["tree"]["sha"] == PRIOR_TREE
assert compare["status"] == "ahead" and compare["ahead_by"] == compare["total_commits"] == 1
assert compare["behind_by"] == 0 and len(compare["commits"]) == 1
assert compare["commits"][0]["sha"] == SOURCE
assert compare["commits"][0]["commit"]["tree"]["sha"] == TREE
assert [row["sha"] for row in compare["commits"][0]["parents"]] == [PRIOR]
assert {row["filename"] for row in compare["files"]} == CHANGED_PATHS
assert len(compare["files"]) == 2
compare_files = {row["filename"]: row for row in compare["files"]}
for row in export["files"]:
    data = row["content"].encode()
    verify_blob(data, row)
    assert compare_files[row["path"]]["sha"] == row["blob"]
    assert compare_files[row["path"]]["status"] == "modified"
    assert row["reviewed_sha256"] == row["sha256"]
    assert row["formatter_changed_reviewed_postimage"] is False

assert preview["source"] == {"commit": SOURCE, "tree": TREE, "status": ""}
assert preview["exit"] == 0
assert preview["operations"] == 371 and preview["modules"] == preview["production_false"] == 40
result = preview["output"]
assert result["candidateSource"] == {"commit": SOURCE, "tree": TREE}
assert result["changedMaps"] == 0 and result["maps"] == [] and result["ledger"] is None
assert result["written"] is False and result["historicalSourceBasesModified"] is False
assert result["executionEvidenceTransferred"] is False

prior_rows = {row["reportMetadata"]["mapPath"]: row for row in prior["modules"]}
assert len(prior_rows) == len(prior_manifest["files"]) == 40
assert set(preview["all_map_sha256"]) == set(prior_rows)
entries = []
staged = {}
for entry in prior_manifest["files"]:
    path = entry["path"]
    data = (PRIOR_DIR / "source-snapshot" / path).read_bytes()
    verify_blob(data, entry)
    assert sha256(data) == preview["all_map_sha256"][path]
    row = prior_rows[path]
    original = {key: row[key] for key in row["reportMetadata"]["originalMapFieldsRetained"]}
    assert json.loads(data) == original
    assert entry["blob"] == row["reportMetadata"]["mapGitBlob"]
    for field in ("resolvedRoots", "observedSourcePaths"):
        for observed in original.get(field, []):
            observed = observed.rstrip("/")
            assert not any(path == observed or path.startswith(observed + "/") for path in CHANGED_PATHS)
    entries.append({"path": path, "blob": entry["blob"], "sha256": sha256(data), "bytes": len(data),
                    "origin": "unchanged-prior-canonical-map-verified-by-current-native-preview",
                    "changedByFinalNavigation": False})
    staged[path] = data

history_entries = copy.deepcopy(prior_manifest["sourceHistory"])
assert len(history_entries) == 3
assert {row["path"]: row["sha256"] for row in history_entries} == preview["history_sha256"]
for entry in history_entries:
    data = (PRIOR_DIR / "source-snapshot" / entry["path"]).read_bytes()
    verify_blob(data, entry)
    staged[entry["path"]] = data

registry_path = prior_manifest["registryPath"]
registry = (PRIOR_DIR / "source-snapshot" / registry_path).read_bytes()
verify_blob(registry, {"blob": prior_manifest["registryBlob"], "sha256": prior_manifest["registrySha256"], "bytes": prior_manifest["registryBytes"]})
assert registry_capture["encoding"] == "utf-8"
assert registry_capture["sha"] == prior_manifest["registryBlob"]
assert registry_capture["content"].encode() == registry
assert "/blob/" + SOURCE + "/" + registry_path == registry_capture["display_url"].split("hepta-private-ci", 1)[1]
staged[registry_path] = registry

layers = copy.deepcopy(prior_manifest["provenance"].get("mapOverlayLayers", []))
layers.append({"kind": "source-only-successor-no-navigation-mutation", "canonicalCommit": SOURCE,
               "canonicalTree": TREE, "nativeSourceCommit": NATIVE, "mapCount": 0,
               "navigationPreview": file_fact(PREVIEW_PATH), "newSourceHistoryLedger": None})
manifest = {
    "schema": "hepta.modules40.verified-source-blobs.v1", "repository": prior["repository"],
    "sourceCommit": SOURCE, "sourceTree": TREE, "registryPath": registry_path,
    "registryBlob": prior_manifest["registryBlob"], "registrySha256": sha256(registry), "registryBytes": len(registry),
    "files": entries, "sourceHistory": history_entries, "navigationReplacementMapCount": 0,
    "provenance": {
        "priorFactSnapshot": {**file_fact(FACTS_PATH), "sourceCommit": PRIOR, "sourceTree": PRIOR_TREE},
        "priorVerifiedBlobManifest": file_fact(MANIFEST_PATH),
        "priorSourceProvenance": copy.deepcopy(prior_manifest["provenance"]),
        "nativeSourceExport": {**file_fact(EXPORT_PATH), "nativeCommit": NATIVE, "nativeTree": TREE,
                               "sourceBefore": copy.deepcopy(export["before"]), "changedPaths": sorted(CHANGED_PATHS)},
        "nativeNavigationPreview": file_fact(PREVIEW_PATH),
        "canonicalCommitObject": file_fact(OBJECT_PATH),
        "githubExactParentComparison": file_fact(COMPARE_PATH),
        "githubExactRegistryRead": file_fact(REGISTRY_CAPTURE_PATH),
        "mapOverlayLayers": layers, "executionEvidenceTransferred": False,
    },
    "verification": {
        "all40MapGitBlobsLocallyVerified": True, "all40MapHashesMatchCurrentNativePreview": True,
        "all40OriginalMapBytesUnchanged": True, "allNonNavigationSemanticsUnchanged": True,
        "allThreeHistoryLedgerBytesUnchanged": True, "noNavigationMutationAndNoNewHistoryLedger": True,
        "canonicalAndNativeCommitObjectsVerified": True, "githubParentComparisonHasExactlyTwoAllowedSourceChanges": True,
        "nativeFormatPostimagesMatchReviewedPostimages": True, "registryBlobVerifiedByExactCanonicalFetch": True,
        "nativeAndPlatformExecutionResultTransferred": False,
    },
}
for path, data in staged.items():
    dest = OUT / "source-snapshot" / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
output = OUT / "source-verified-blobs.json"
output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
shutil.copyfile(PRIOR_DIR / "build_source_report.py", OUT / "build_source_report.py")
print(json.dumps({"sourceCommit": SOURCE, "sourceTree": TREE, "mapCount": 40,
                  "navigationReplacementMaps": 0, "sourceHistoryCount": 3,
                  "manifest": label(output), "manifestSha256": sha256(output.read_bytes())}, ensure_ascii=False, indent=2))
