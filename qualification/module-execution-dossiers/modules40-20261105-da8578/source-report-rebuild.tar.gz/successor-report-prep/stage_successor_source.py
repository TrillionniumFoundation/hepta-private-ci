"""Stage an explicit navigation successor without changing its prior snapshot."""

from pathlib import Path
import argparse
import base64
import copy
import hashlib
import json
import re


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--prior-facts", type=Path, required=True)
parser.add_argument("--prior-snapshot", type=Path, required=True)
parser.add_argument("--prior-verified-blobs", type=Path, required=True)
parser.add_argument("--navigation-export", type=Path, required=True)
parser.add_argument("--postimages", type=Path, required=True)
parser.add_argument("--canonical-objects", type=Path, required=True)
parser.add_argument("--source-commit", required=True)
parser.add_argument("--source-tree", required=True)
parser.add_argument("--output-dir", type=Path, required=True)
args = parser.parse_args()
assert re.fullmatch(r"[0-9a-f]{40}", args.source_commit)
assert re.fullmatch(r"[0-9a-f]{40}", args.source_tree)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git_object(kind, data):
    return hashlib.sha1(kind.encode() + b" " + str(len(data)).encode() + b"\0" + data).hexdigest()


def read_json(path):
    data = path.read_bytes()
    return data, json.loads(data)


def verify_blob(data, expected):
    assert git_object("blob", data) == expected["blob"]
    assert sha256(data) == expected["sha256"]
    if "bytes" in expected:
        assert len(data) == expected["bytes"]


def semantic_view(row):
    result = copy.deepcopy(row)
    for key in ("sourceObjects", "observedAtHead", "observedSourcePaths", "mappingSourceIdentityMode"):
        result.pop(key, None)
    for operation in result.get("operations", []):
        operation.pop("sourceBlob", None)
    for caller in result.get("productCallers", []):
        caller.pop("blobSha", None)
    evidence = result.get("exactSourceEvidence")
    if isinstance(evidence, dict) and evidence.get("kind") == "path_blob_manifest_v1":
        for entry in evidence.get("entries", []):
            entry.pop("blobSha", None)
    return result


def verify_commit(data, commit, tree, parent):
    assert git_object("commit", data) == commit
    headers = data.split(b"\n\n", 1)[0].splitlines()
    assert headers[0] == b"tree " + tree.encode()
    assert [line[7:].decode() for line in headers if line.startswith(b"parent ")] == [parent]


prior_bytes, prior = read_json(args.prior_facts)
manifest_bytes, prior_manifest = read_json(args.prior_verified_blobs)
export_bytes, export = read_json(args.navigation_export)
object_bytes, objects = read_json(args.canonical_objects)
assert prior_manifest["sourceCommit"] == prior["sourceSnapshot"]["commit"]
assert prior_manifest["sourceTree"] == prior["sourceSnapshot"]["tree"]
assert prior_manifest["repository"] == prior["repository"]
assert export["source"]["tree"] == args.source_tree and export["source"]["status"] == ""
assert export["modules"] == export["production_false"] == 40
assert export["operations"] == 371
assert export["semantic_metadata_preserved"] is True and export["execution_evidence_transferred"] is False
assert export["preview"]["historicalSourceBasesModified"] is False
assert export["applied"]["historicalSourceBasesModified"] is False
parent = export["before"]["commit"]
verify_commit(base64.b64decode(export["raw_commit_base64"], validate=True), export["source"]["commit"], args.source_tree, parent)
canonical = [entry for entry in objects["commits"] if entry["sha"] == args.source_commit]
assert len(canonical) == 1
verify_commit(base64.b64decode(canonical[0]["raw_base64"], validate=True), args.source_commit, args.source_tree, parent)

prior_rows = {row["reportMetadata"]["mapPath"]: row for row in prior["modules"]}
prior_entries = {row["path"]: row for row in prior_manifest["files"]}
assert len(prior_rows) == len(prior_entries) == 40 and set(prior_rows) == set(prior_entries)
staged = {}
entries = {}
for path, entry in prior_entries.items():
    data = (args.prior_snapshot / path).read_bytes()
    verify_blob(data, entry)
    assert git_object("blob", data) == prior_rows[path]["reportMetadata"]["mapGitBlob"]
    raw_map = {key: prior_rows[path][key] for key in prior_rows[path]["reportMetadata"]["originalMapFieldsRetained"]}
    assert json.loads(data) == raw_map
    staged[path] = data
    entries[path] = {"path": path, "blob": entry["blob"], "sha256": sha256(data), "bytes": len(data),
                     "origin": "retained-prior-canonical-map", "changedByFinalNavigation": False}

history_entries = copy.deepcopy(prior_manifest["sourceHistory"])
assert {row["path"]: row["sha256"] for row in history_entries} == export["old_history_ledgers_sha256"]
for entry in history_entries:
    data = (args.prior_snapshot / entry["path"]).read_bytes()
    verify_blob(data, entry)
    staged[entry["path"]] = data

new_ledger = export["applied"]["ledger"]
changed_map_paths = set(export["applied"]["maps"])
assert changed_map_paths == set(export["preview"]["maps"])
assert len(changed_map_paths) == export["applied"]["changedMaps"]
assert changed_map_paths <= set(prior_entries)
assert new_ledger not in staged
assert len(export["files"]) == len(changed_map_paths) + 1
assert {entry["path"] for entry in export["files"]} == changed_map_paths | {new_ledger}
for entry in export["files"]:
    path = entry["path"]
    assert not Path(path).is_absolute() and ".." not in Path(path).parts
    assert entry["mode"] == "100644"
    data = entry["content"].encode()
    verify_blob(data, entry)
    assert data == (args.postimages / path).read_bytes()
    if path in changed_map_paths:
        assert semantic_view(json.loads(data)) == semantic_view(json.loads(staged[path]))
        entries[path] = {"path": path, "blob": entry["blob"], "sha256": sha256(data), "bytes": len(data),
                         "origin": "successor-navigation-export", "changedByFinalNavigation": True}
    else:
        history_entries.append({"path": path, "blob": entry["blob"], "sha256": sha256(data), "bytes": len(data)})
    staged[path] = data

registry_path = prior_manifest["registryPath"]
registry = (args.prior_snapshot / registry_path).read_bytes()
verify_blob(registry, {"blob": prior_manifest["registryBlob"], "sha256": prior_manifest["registrySha256"], "bytes": prior_manifest["registryBytes"]})
staged[registry_path] = registry
maps = [json.loads(staged[path]) for path in prior_entries]
assert sum(len(row["operations"]) for row in maps) == 371
assert all(row["productionImplementation"] is False for row in maps)
assert all(row["sourceBase"] == prior_rows[path]["sourceBase"] for path, row in zip(prior_entries, maps))

layers = copy.deepcopy(prior_manifest["provenance"].get("mapOverlayLayers", []))
layers.append({"kind": "successor-navigation-replacements", "path": str(args.navigation_export),
               "sha256": sha256(export_bytes), "canonicalCommit": args.source_commit,
               "canonicalTree": args.source_tree, "nativeCommit": export["source"]["commit"],
               "codeParent": copy.deepcopy(export["before"]), "mapCount": len(changed_map_paths)})
manifest = {
    "schema": "hepta.modules40.verified-source-blobs.v1", "repository": prior["repository"],
    "sourceCommit": args.source_commit, "sourceTree": args.source_tree,
    "registryPath": registry_path, "registryBlob": prior_manifest["registryBlob"],
    "registrySha256": sha256(registry), "registryBytes": len(registry),
    "files": [entries[path] for path in prior_entries], "sourceHistory": history_entries,
    "navigationReplacementMapCount": len(changed_map_paths),
    "provenance": {
        "priorFactSnapshot": {"path": str(args.prior_facts), "sha256": sha256(prior_bytes),
                              "sourceCommit": prior["sourceSnapshot"]["commit"], "sourceTree": prior["sourceSnapshot"]["tree"]},
        "priorVerifiedBlobManifest": {"path": str(args.prior_verified_blobs), "sha256": sha256(manifest_bytes)},
        "priorSourceProvenance": copy.deepcopy(prior_manifest["provenance"]),
        "navigationExport": {"path": str(args.navigation_export), "sha256": sha256(export_bytes),
                             "nativeCommit": export["source"]["commit"], "nativeTree": export["source"]["tree"],
                             "sourceBefore": copy.deepcopy(export["before"])},
        "canonicalCommitObject": {"path": str(args.canonical_objects), "sha256": sha256(object_bytes)},
        "mapOverlayLayers": layers, "executionEvidenceTransferred": False,
    },
    "verification": {"all40MapGitBlobsLocallyVerified": True, "allNavigationPostimagesMatchExport": True,
                     "allNonNavigationSemanticsUnchanged": True, "priorHistoryLedgerBytesUnchanged": True,
                     "allHistoryLedgerByteHashesVerified": True, "canonicalAndNativeCommitObjectsVerified": True,
                     "registryBlobVerified": True},
}
snapshot = args.output_dir / "source-snapshot"
for path, data in staged.items():
    dest = snapshot / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
output = args.output_dir / "source-verified-blobs.json"
output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"sourceCommit": args.source_commit, "sourceTree": args.source_tree,
                  "mapCount": len(entries), "navigationReplacementMaps": len(changed_map_paths),
                  "sourceHistoryCount": len(history_entries), "manifest": str(output),
                  "manifestSha256": sha256(output.read_bytes())}, ensure_ascii=False, indent=2))
