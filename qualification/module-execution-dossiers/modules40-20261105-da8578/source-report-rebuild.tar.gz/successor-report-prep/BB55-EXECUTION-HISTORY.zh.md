# 已封存的 bb55 执行结果与 Codespell 阻断

**bb55 的 Linux 原生执行已通过；该候选的平台 Codespell 实跑失败。**这两项结论分别保留。任何后继源码及其导航提交都需要自己的执行回执，不能继承 bb55 的通过状态。bb55 检查点已固定于 [evidence `f038947fd20992e15213d41f7f6d8ac1d2ca10fc`](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/f038947fd20992e15213d41f7f6d8ac1d2ca10fc/qualification/module-execution-dossiers/modules40-20261105-da8578)。

## bb55 原生执行的固定身份

- Source commit：`bb55b0d7d263c396ec504c45393d938c3428dae5`。
- Source tree：`19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1`。
- Native job：`1a1ac64b60d-fc05-5402`；权威终态为 `succeeded / exit 0`，输出完整且已持久化，没有取消、外层超时或自动重试。
- 各命令回执记录的执行前后 commit/tree 相同，工作区状态均为空。

终态依据：[runtime 回执](runtime/final-canonical-bb55-runtime-status.json)；完整命令集合与退出码依据：[final-canonical-run1-summary.json](native/final-canonical-run1-summary.json)。

| 已执行范围 | 原始结果 | 对应回执 |
| --- | --- | --- |
| 七个完整包的原生回归 | **1,219 passed（其中 1 slow）、78 skipped；runner exit 0** | [seven-package-run2-summary.json](native/seven-package-run2-summary.json)、[原始测试命令](native/seven-package-run2-original-test.json)、[原始日志](native/seven-package-run2-original-test.log) |
| 固定源码绑定的 69 项必需测试审计 | **69/69 clean；整体 CLEAN；audit exit 0** | [审计结果](native/seven-package-run2-required-tests.69.native-audit.json)、[审计命令](native/seven-package-run2-required-audit.json) |
| 七项严格仓库检查 | **全部 exit 0** | [七项检查汇总](native/seven-package-run2-summary.json) |
| 原始全 workspace 格式要求 | **exit 0** | [original-workspace-format](native/final-canonical-run1-original-workspace-format.json) |
| 原始四包格式要求 | **exit 0** | [original-four-package-format](native/final-canonical-run1-original-four-package-format.json) |
| 原始三项 Clippy deny policy | **exit 0** | [original-ci-policy-clippy](native/final-canonical-run1-original-ci-policy-clippy.json) |
| ExecServer 与 AppServerClient 两个完整 library | **319 passed（其中 1 slow）、0 skipped；exit 0** | [命令回执](native/final-canonical-run1-two-library-regression.json)、[原始日志](native/final-canonical-run1-two-library-regression.log) |
| AppServer `process_exec` 选择范围 | **5 passed、1,016 skipped；exit 0** | [命令回执](native/final-canonical-run1-app-server-process-regression.json)、[原始日志](native/final-canonical-run1-app-server-process-regression.log) |

七个完整包为 `codex-hepta-agent-protocol`、`codex-hepta-agentd`、`codex-hepta-infer-worker-host`、`codex-hepta-runtime`、`codex-hepta-contracts`、`codex-hepta-learning-ledger`、`codex-hepta-supervisor`。七项严格检查为 `maps-qualification`、`status-facts`、`module-registry`、`documents-qualification`、`chef-custody`、`rust-ci-feedback`、`module-docs-metadata`。[原始汇总](native/seven-package-run2-summary.json)

Clippy 保留原有的 `clippy::correctness`、`clippy::await_holding_lock`、`clippy::await_holding_invalid_type` 三项 deny policy。AppServer 的 5 项结果来自明确的 `test(process_exec)` 选择范围；其余 1,016 项保持原始 skipped 记账，不被纳入通过数。不同命令的结果分别记录，不把多次或不同范围的运行累加为一套全 workspace 验收。[Clippy 原命令](native/final-canonical-run1-original-ci-policy-clippy.json)；[AppServer 原命令](native/final-canonical-run1-app-server-process-regression.json)

## 平台 Codespell 的实际失败身份

GitHub Actions [run `42058691802` / job `127354031805`](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42058691802/job/127354031805) 的 Codespell 2.4.3 实跑发现：`codex-rs/hepta-infer-worker-host/src/native_output_tests.rs:82` 中的流式前缀 `hel` 触发拼写检查。原命令选项是 `--ignore-words .codespellignore --skip ./.git`；日志保留实际错误和失败终态。[原始日志](platform-bb55/logs/job-127354031805.log)

该 job 的 PR head 是 bb55；日志中实际 checkout 的 Git commit 是 `d5c18539ee6f256c52d1f80d40d3b74ec9075ebf`，tree 为 `19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1`，有序父提交为 `07378034e060f23259bc99c7367f12b1284140f3`、`bb55b0d7d263c396ec504c45393d938c3428dae5`。原生直接执行候选与平台合并对象保持各自身份；同 tree 不将其中一方的执行回执变成另一方的运行记录。[日志身份清单](platform-bb55/logs/job-127354031805.manifest.json)；[实际 checkout commit 元数据](platform-bb55/logs/job-127354031805.executed-commit.raw.json)

这一失败使 bb55 的平台阻断 CI 保持未通过状态。流式前缀的字节等价源码修复和后续导航属于新候选，其 Codespell 复现、原生回归及平台执行均应引用各自的新回执。

## 早期运行的身份与结果继续保留

| 固定候选 | 已取得的历史结果 | 原始范围 |
| --- | --- | --- |
| `f5813506b49eb05efad00f203b9362195875892c` / tree `00d62de1c2f6ac8a229d23ce9d8e1b9f34b333df` | 1,217 passed、1 failed、1 timed out、78 skipped；runner exit 100；69 项必需测试 clean，但完整审计仍为 **NOT_CLEAN** | [七包 run1 汇总](native/seven-package-run1-summary.json) |
| `a00ff322e692a0800331c454d3484eec3efffdb9` / tree `a52524e706ae583345c748ecaf3d82909de08ca4` | 原始 Clippy policy、两 library 与 AppServer process 范围均 exit 0 | [CI policy run2 汇总](native/ci-repair-policy-run2-summary.json) |
| `d068620da668c8288dfa7bfb92a1347af1f4a556` / tree `2106a123dd758003cee9aafdfb56224ec3be9a14` | paired-process 范围 **2 passed、1 skipped；exit 0** | [paired-image 回执](native/paired-image-run1-receipt.json)、[原始日志](native/paired-image-run1.log) |
| `afe0d625b01728a5fe2a1c37652573a3a1b6a097` / tree `62f767b394adbda686f21499f4af5cb4584673dc` | 原始全 workspace 格式检查 exit 0 | [global-format-run2 回执](native/global-format-run2.json) |

## 归档完整性与结论范围

bb55 原生归档为 [native-final-bb55-checkpoint.tar.gz](native/native-final-bb55-checkpoint.tar.gz)，共核对 **201 个文件、200 个 manifest 条目**，SHA256 为 `28424496bd400d6c5ff6370158f7b093355e463f19ebb550b1df6e7330504886`。旧 run1 的 78 个原始文件逐字节保留。[归档验证](native/final-native-archive-verification.json)

七包 run2 的 [JUnit](native/seven-package-run2.junit.xml) 为 **280,619 字节、1,219 个 testcase**，SHA256 为 `8ef498e557bbc63e20230d66af451f1d7c97907ce7934201be171f368a185229`。78 项 skipped 来自原始 runner 汇总，不能因 JUnit 只包含执行过的 testcase 而从报告中消失。[七包原始汇总](native/seven-package-run2-summary.json)

这些结果证明记录候选在相应 Linux 原生命令范围内的源码回归与导航检查结果；平台 Codespell 的失败保持独立且可见。40 个模块的 productionImplementation 仍全部为 false，真实 provider、Windows/Darwin 宿主、部署信任、外部资源与独立接收方验收继续按原 gate 记录。
