from pathlib import Path
import argparse
import base64
import copy
import hashlib
import json
import re
import sys

parser = argparse.ArgumentParser(
    description="Build source-only facts and Chinese reports from explicitly pinned, verified module Maps."
)
parser.add_argument("--source-commit", required=True, help="Full immutable canonical commit SHA-1.")
parser.add_argument("--source-tree", required=True, help="Full immutable canonical tree SHA-1.")
parser.add_argument("--map-dir", required=True, type=Path, help="Directory containing the 40 module subdirectories.")
parser.add_argument("--verified-blobs", required=True, type=Path, help="Verified-source-blobs manifest for exactly these 40 Maps.")
parser.add_argument("--registry-file", required=True, type=Path, help="Exact MODULES.json bytes matching the manifest.")
parser.add_argument("--canonical-objects", required=True, type=Path, help="JSON containing commits with sha and raw_base64.")
parser.add_argument("--prior-facts", required=True, type=Path, help="Previous complete facts snapshot with originalMapFieldsRetained metadata.")
parser.add_argument("--source-history", required=True, action="append", help="Repeat for each source-history ledger as REPOSITORY_PATH=LOCAL_PATH.")
parser.add_argument("--output-dir", required=True, type=Path)
parser.add_argument("--repository", default="TrillionniumFoundation/hepta-private-ci")
parser.add_argument("--validate-only", action="store_true", help="Validate every input and invariant without writing report outputs.")
args = parser.parse_args()
ROOT = Path.cwd().resolve()
OUT = args.output_dir.resolve()
MAP_ROOT = args.map_dir.resolve()
SOURCE = args.source_commit
TREE = args.source_tree
REPO = args.repository
if not re.fullmatch(r"[0-9a-f]{40}", SOURCE) or not re.fullmatch(r"[0-9a-f]{40}", TREE):
    parser.error("source-commit and source-tree must each be a full lowercase 40-character Git identity")
BASE = "https://github.com/" + REPO + "/blob/" + SOURCE + "/"
TICK = chr(96)

GROUPS = [
    ("契约与内核", ["platform.types", "platform.wire", "kernel.authority", "kernel.operations", "kernel.evidence"]),
    ("执行运行时", ["runtime.supervisor", "runtime.fleet", "runtime.agentd", "runtime.codex"]),
    ("身份、密钥与推理", ["auth.authbus", "secrets.heptabao", "inference.control", "inference.worker"]),
    ("目标与决策", ["objective.compiler", "utility.ndu", "neuron.runtime", "intuition.policy", "prompt.registry", "prompt.optimizer", "context.compiler", "intelligence.control"]),
    ("认知与记忆", ["cognitive.types", "cognitive.store", "cognitive.read", "memory.retrieval", "memory.federation", "knowledge.graph", "compact.engine"]),
    ("学习与演化", ["learning.ledger", "learning.operator", "learning.eval", "learning.artifacts", "learning.plasticity"]),
    ("外部器官与交互", ["automation.taskflow", "channel.matrix", "browser.servo", "ui.control", "ui.native"]),
    ("全局控制与工程", ["control.runtime", "control.engineering"]),
]

# Source-derived Chinese summaries. These strings do not mutate any Map claim.
NARRATIVE = {
    "platform.types": (
        "有界值、ID、规范摘要、定点数、契约/数值 profile 登记和生成绑定已有源码；尚未组合命名产品 caller，目标协议源码也未全部完成。",
        "补齐 RandomStreamManifestV1、ExternalSystemManifestV1、SensorCalibrationManifestV1 的原生实现，再完成认证产品接入与完整消费者编译矩阵。"),
    "platform.wire": (
        "V1/V2 信封、版本协商、schema 准入和流式解码已有实现；只读调用与已登记端口适配器已在源码中组合。",
        "把 HPTN 协商与 HPTA 编码帧绑定到选定的认证传输/会话；逐个登记并验收新增业务 codec。"),
    "kernel.authority": (
        "最终使用授权、租约 lineage、批准/撤销验证和 frontier owner 已实现；Fleet、Bao host、Agentd/浏览器已有源码接线，尚未产品激活。",
        "为 Bao final-use host 选定真实产品进程 caller；验收受保护的 frontier、可信时钟、密钥托管及撤销分发的当前性和收敛延迟。"),
    "kernel.operations": (
        "OperationIntent、持久 claim/outbox、最终使用派发、Cognitive 终态观察已有源码；Agentd 生命周期和 Automation 消费边已接入，写入仍由既有 CognitiveStore owner 持有。",
        "为每个待激活目的端补齐其自身的去重、apply 和终态观察；同时完成有界分段/检查点保留及真实授权源、宿主崩溃恢复资格。"),
    "kernel.evidence": (
        "回执追加、claim 查询、链校验与恢复快照已接入 Agentd 的配置门控授权 writer；provider effect intent/lookup 入口仍有明确的资格测试边界。",
        "取得当前候选的独立验收，并接通外部单调 CAS/latest-frontier 后端与备份发布流程；历史观察不能随导航更新转移。"),
    "runtime.supervisor": (
        "原生 daemon 已覆盖进程生命周期、有界重启、签名升级/回滚与恢复；本轮加入获取锁进程持有的 handoff 锁生命周期。登记的产品 caller/writer 尚未整体闭合。",
        "闭合完整真实进程回归及所选宿主上的启动、Drain、重启、接管和签名恢复；绑定实际部署二进制、当前 grant/H7 验证配置与代次围栏。"),
    "runtime.fleet": (
        "宿主登记、分配租约与续租/撤销组件已有源码；内存租约组件与真实容量、宿主持久 grant 的组合仍未完成。",
        "把租约连接到持久 FleetRegistry grant/fence 和真实容量观察器，验收非测试的本地执行约束、分区与租约到期。"),
    "runtime.agentd": (
        "已形成 daemon 生命周期、持久 RunStart 投影及运行时组合边界；Agentd 只持有短期准入/快照引用，物理 Codex 执行和当前信任复核仍有缺口。",
        "贯通 runtime.codex 的真实 start/interrupt/terminal 调用；在恢复 RunStart 前接入当前 AuthBus/trust 校验，并把 Neuron owner 纳入 daemon 生命周期。"),
    "runtime.codex": (
        "线程、turn、工具派发和交付观察的候选适配层已组合，沿用既有 App Server owner；当前候选的完整产品 fault matrix/E2E 尚待验收。",
        "绑定实际 Agentd/App Server 进程、代次、连接端身份与外部 final-use authority；验证真实 provider/tool 终态、丢 ACK 和临时历史丢失后的不确定状态处理。"),
    "auth.authbus": (
        "认证、消息准入和入队操作已有源码；Map 尚未登记完整的认证产品 caller 和 owner store 组合。",
        "逐操作绑定命名认证消费者与真实 owner store，再取得当前候选的产品执行和目标宿主资格。"),
    "secrets.heptabao": (
        "KV V2 消费、绑定、租约生命周期 prepare/reconcile 已有源码；动态租约 provider 的兼容性仍为阻断性 partial。",
        "先验收确切 HeptaBao/OpenBao endpoint 合约，再接原生 issue/renew/revoke 派发及认证产品 caller、持久 host owner。"),
    "inference.control": (
        "reserve、schedule、cancel、settle 与持久 run 状态已有实现；现有策略主要保留本地并发槽，不能等同于经济配额或真实硬件容量。",
        "接入真实配额/容量 authority；在进程丢失后从可信 provider 恢复终态与 usage，并在同一 journal owner 下实现有界归档，保留未知派发的容量占用。"),
    "inference.worker": (
        "Worker Host 已有 manifest/grant 校验、精确代次 load/unload；原生 run 已接持久调度与单次私有 Agent/App Server 调用，重开路径不重发 provider。",
        "实现并验收持有真实 weights/tokenizer/runtime/device/memory grant 的本地 driver；补 dispatch-unknown 和缺失 usage 的可信对账，以及 OOM/device-reset 资格。"),
    "objective.compiler": (
        "输入解码、规范意图摘要、结构/准入/可行性检查和编译已有实现；已在源码中组合认证 Agentd 入口，编译器自身无状态。",
        "在固定最终候选与所选 Agentd 宿主上验收真实 Objective 载荷路径，覆盖崩溃、重启和背压，并取得对应双通道资格回执。"),
    "utility.ndu": (
        "候选评估、求解器和系数投影已有实现；请求内只读组合已形成，认证 owner、持久 projection writer 仍是尚未选择/激活的源码候选。",
        "在命名产品 bootstrap 中选择真实 ProjectionStore 与当前 fence/revocation feed；引入独立收敛证据、选定 stochastic artifact，并完成宿主恢复/容量测量。"),
    "neuron.runtime": (
        "tick、推理特征端口、稀疏 journal、外部 witness 和删除重建边界已有源码；AgentdNeuronOwner 已有编译组合边界，尚未进入完整 daemon 生命周期。",
        "把 owner 接入当前 inference.control、选定产物和 witness 生命周期；若推广 PopulationSparse V2，先实现独立版本的持久迁移与恢复。"),
    "intuition.policy": (
        "校准决策 V1/V2 已有源码；命名产品 caller 和 owner store 组合尚未建立。",
        "绑定认证消费者与其状态 owner，并在当前候选、真实产品路径和目标宿主上验收校准决策。"),
    "prompt.registry": (
        "PromptRegistry、V2 realization 登记和兼容读取已有源码；Map 中默认产品 caller/writer 的组合资格仍未建立。",
        "把兼容性读取与登记操作接到认证产品消费者和实际 owner store，取得所选宿主上的持久/恢复与产品接入证据。"),
    "prompt.optimizer": (
        "优化和本地 shadow 计算已有源码；产品 caller 与持久 writer 的组合关系仍未建立。",
        "为优化结果选定认证产品消费者和状态 owner，验证当前候选的实际消费路径及独立语义验收。"),
    "context.compiler": (
        "旧 V1 只读路径已有源码组合；V2 准入快照、编译、序列化、交付准备与观察已实现，但认证 V2 产品 caller 尚未闭合。",
        "绑定确切 tokenizer/serializer/template/tool-schema 和 provider owner，在物理发送前用当前 final-use authority 绑定精确载荷与 ProviderRequestBinding；持久化 attempt/terminal 对账。"),
    "intelligence.control": (
        "只读与评估 shadow 管线、命名 Agentd runner 和跨模块组合入口已形成；ObjectiveStart 到 canonical-run 已源码接线，daemon 到物理 App Server 的完整路径仍开放。",
        "完成默认持久 Decision/Outcome 与跨进程 pending-intent 恢复，再验证真实 App Server 调用、丢 ACK、依赖中断、重启及撤销竞态。"),
    "cognitive.types": (
        "快照、MemoryEvent、Engram/Synapse、回忆/学习/遗忘回执等 15 项规范操作及 V1 wire 已有源码；消费者的认证规范迁移尚未完成。",
        "通过显式 canonical V1 adapter 迁移已登记消费者，并将真实产品消费者绑定到准确的 wire schema；仅登记表投影不足以关闭该门槛。"),
    "cognitive.store": (
        "持久 owner、语义 revision、共享经验及 canonical memory event 写入已形成；正常 Agentd capability 路径已组合，保留同事务 provenance writer，外部 bootstrap 仍待接入。",
        "由独立宿主提供当前 cut witness 与 live authority，验收崩溃重开、响应丢失去重、撤销及容量；补 ancestry-safe 长期保留，区分 tombstone 与物理删除。"),
    "cognitive.read": (
        "当前性读取、持久 SQLite 快照和 canonical shadow 适配已有实现；本地只读 host 已组合，本轮在 retrieval/ranker 回调后增加最终 owner-cut 复读。",
        "把真实 retrieval provider、来源 revision 与物理模型请求附加串起来，验收删除/纠正/到期/回滚/旧代拒绝及进程重启；现有 SQLite kind capability 仍保持 Fact-only。"),
    "memory.retrieval": (
        "cue、候选并集、Engram 落地、recall 和 canonical shadow 适配已组合到显式 profile；hnmf-required 进程没有 provider 时会拒绝启动。",
        "接入认证的 CurrentMemoryRetrievalContext provider；Vector 通道启用前验收真实 encoder/vector-index owner，并取得所选宿主的有界规模与资源测量。"),
    "memory.federation": (
        "只读 execute-once 与取消传播的候选组合已形成；不拥有持久 writer，也尚无完整目标宿主验收。",
        "补需要的显式产品取消归因/回执；跨进程或跨宿主时验收认证传输，并完成当前候选的组合和严格检查。"),
    "knowledge.graph": (
        "完整代次构建、增量算法、发布、关系查询与 prompt-factor 投影已有实现；Cognitive read/default Agentd writer 的候选组合采用失败即拒绝的 owner 边界。",
        "先完成当前候选和宿主资格；以性能证据决定是否把增量算法选为运行时 writer，不能由图模块代替 prompt.registry 的独立持久/激活验收。"),
    "compact.engine": (
        "compact、qualified candidate 构造与压缩证明已有源码；认证产品 caller 和 owner store 组合尚未建立。",
        "将压缩候选与证明接入具体认证消费者和 owner store，再取得当前候选的产品执行及目标宿主资格。"),
    "learning.ledger": (
        "持久 RunStart、D/O、数据集和 witness owner 已有实现；本轮增加精确已提交 D/O 的 ACK 对账与恢复同步。资格消费者已组合，默认 live writer host 尚未建立。",
        "绑定认证 Objective producer 与当前信任的 Agentd consumer，闭合默认 daemon D/O/pending-intent 恢复；独立验收物理 writer、外部 witness、断电与撤回传播。"),
    "learning.operator": (
        "目标构造、验证训练、tabular/world-model 预测、固定产物读取和 owner terminal-cell 操作已有实现；显式读取消费者已组合，默认学习环缺失。",
        "贯通数据集冻结→验证训练→独立评估→选择→新进程加载 shadow 的默认路径，并取得真实未来窗口有效性及宿主训练/推理证据。"),
    "learning.eval": (
        "OPE、区间/序贯估计、时间 holdout、签名证据与本地 final-holdout CAS 已实现；产品资格回执已被 evaluated shadow 消费。",
        "将 EvidenceSink 和 final-holdout namespace 持久绑定到认证宿主；取得独立未来窗口、保留/隐私/遗忘证据及必要的共享文件系统资格。"),
    "learning.artifacts": (
        "产物登记、payload、发布/撤回、生命周期、独立选择与恢复已有实现；命名 owner service 的显式 reader/writer 已组合。",
        "在统一候选上验收 owner 重开和物理断电，配置独立 owner/selector 信任，并取得真实宿主与独立选择/发布验收。"),
    "learning.plasticity": (
        "参数/拓扑候选、Agentd 进程 bootstrap、命名 producer、append-only anchor/fence 和 final-use 拓扑执行/恢复已有源码；真实自迭代触发尚未组合。",
        "接入提交冻结且独立评估候选的非测试 coordinator；把 anchor 放入独立回滚域，并完成目标宿主强制故障 canary、拓扑恢复及事故演练。"),
    "automation.taskflow": (
        "持久日程、确定 occurrence、claim 和 TaskFlow run/step owner 已形成；Agentd/App Server 及 Calendar V2 控制已组合，外部效果产品 caller 仍待接入。",
        "验证所选宿主的完整因果路径，为每个外部效果接入独立 FinalUseAuthority、真实 provider 与可信终态/对账回执；另验收 tzdb、DST 和多调度器。"),
    "channel.matrix": (
        "事件准入、sync frontier、dispatch ledger、outbox 和 transaction identity 已有持久通道源码；真实 homeserver 产品接入尚未闭合。",
        "绑定真实 homeserver/user/device/加密身份与 live sync/send；观察状态须接入原 MatrixDurableStore，并以 homeserver event 确定发送终态。"),
    "browser.servo": (
        "profile/session/page/operation 及注入式浏览器 driver 的 owner 边界已有实现；组件测试中的确定性 driver 不能证明真实 Servo 部署。",
        "提供可复现 Servo 二进制和补丁摘要，验收 OS sandbox/profile/凭证/网络约束，以及真实导航、下载和业务终态。"),
    "ui.control": (
        "Web 控制客户端的视图、会话、请求身份与停止请求边界已形成；授权与持久事实仍由后端 owner 持有。",
        "选定实际 Web 构建产物和浏览器矩阵，接通认证/CSP/CSRF/WebSocket 部署，并完成后端终态与可访问性端到端验收。"),
    "ui.native": (
        "原生 shell 的运行时连接、视图、平台能力和更新边界已有源码；shell 不自行签发业务或平台成功状态。",
        "选定框架/平台矩阵，接入真实签名、公证、Keychain 和 updater 信任根，验证打包后的崩溃、重启、可访问性与更新回滚。"),
    "control.runtime": (
        "snapshot、计划准备/完成、NDU 评估绑定、grant 请求和 PlannerJournal 已有源码；caller/writer 尚未组成完整产品生命周期，grant 入口仅提出请求。",
        "把每个操作接到认证产品 caller 与实际 owner store，贯通计划、授权请求、执行 owner 和恢复观察；不得由计划本身推导执行授权。"),
    "control.engineering": (
        "工作信封、候选生成、sandbox、mutation testing、集成证据、队列及 worker 生命周期已有实现；命名产品 owner 和双通道 caller 已定义，执行资格仍开放。",
        "取得固定源码与有序双父合并的成功回执，保留强 sandbox/mutation 证据；补独立 completion/review、外部密钥 custody、分布式 fence 和不可变审计锚。"),
}

CRITICAL = [
    {
        "title": "收齐固定候选的集成证据与平台、合并验收",
        "modules": ["runtime.supervisor", "runtime.codex", "control.engineering"],
        "action": "按各自固定 commit/tree 收齐原始完整回归、关键清单核对、格式/严格 lint、平台 CI 与有序合并候选的证据。各候选原生回归由独立执行总览记账，后续验收继续引用对应原始回执；每次原始失败、重试、跳过、构建准备变更与运行终态分别保留，局部通过和历史同树观察不转成新候选的全套通过。",
        "acceptance": "存在绑定固定源码、原命令、完整原始日志/JUnit、原退出码和独立审计的完整回执；仍排队或未运行的步骤显式保持未验收。",
    },
    {
        "title": "补齐独立授权、当前性与真实资源来源",
        "modules": ["kernel.authority", "auth.authbus", "secrets.heptabao", "runtime.fleet", "inference.control", "inference.worker"],
        "action": "为产品进程选择认证 caller、真实 Bao/provider endpoint、受保护的 frontier 和可信时钟，绑定撤销分发与密钥托管；把分配/推理接到真实容量、经济配额及模型/设备 grant。",
        "acceptance": "在实际 owner 和宿主上证明身份、当前授权、撤销收敛、租约到期与资源持有；内存槽数、接口存在或自签 fixture 不替代这些证据。",
    },
    {
        "title": "贯通 Objective 到物理执行的进程生命周期",
        "modules": ["objective.compiler", "runtime.agentd", "runtime.codex", "runtime.supervisor", "inference.control", "inference.worker"],
        "action": "连接认证 Objective/RunStart、当前信任复核、Agentd、App Server turn/start/interrupt 和 provider 终态；让重启、Drain、接管、丢 ACK 与进程丢失在各自 owner 上完成对账。",
        "acceptance": "真实进程路径和精确代次/身份一致；可能已派发的运行保持不可自动重发，缺失终态或 usage 不被解释为成功、零消耗或可安全重试。",
    },
    {
        "title": "在真实请求边界闭合上下文与记忆最终使用",
        "modules": ["context.compiler", "cognitive.store", "cognitive.read", "memory.retrieval", "memory.federation", "knowledge.graph"],
        "action": "组合认证 V2 caller、准确的序列化/profile 和真实 retrieval provider，在物理发送前把当前 authority、owner cut、源 revision 与精确请求载荷绑定；验证删除、纠正、到期、回滚和旧代拒绝。",
        "acceptance": "回调后的复读、进程恢复和物理请求附加分别有证据；Vector 有真实 encoder/index owner；逻辑 tombstone、物理删除、派生产物撤回和模型遗忘的范围分别记录。",
    },
    {
        "title": "闭合默认 D/O 账本和完整学习环",
        "modules": ["intelligence.control", "learning.ledger", "learning.operator", "learning.eval", "learning.artifacts", "utility.ndu"],
        "action": "将默认 Decision/Outcome 与 pending-intent 恢复接到持久 owner，然后贯通冻结数据集、验证训练、独立评估、选定产物和新进程加载 shadow；选择真正独立的评估/trust/witness 来源。",
        "acceptance": "进程丢失后的精确 ACK 对账不追加新事件或续发过期授权；完整学习环和真实未来窗口证据成立后，才更新相应产品执行/选择声明。",
    },
    {
        "title": "建立自迭代 coordinator 与可恢复控制闭环",
        "modules": ["control.runtime", "control.engineering", "learning.plasticity", "neuron.runtime", "runtime.supervisor"],
        "action": "由非测试 coordinator 通过命名 Agentd producer 提交冻结且独立评估的下一代参数/拓扑候选；贯通计划、grant 请求、final-use、writer handoff、当前代次/路由更新和恢复观察。",
        "acceptance": "anchor/fence 与提案 registry 的物理回滚域独立，目标宿主强制故障 canary、迁移恢复、独立 review/批准链可追溯；规划或观察回执本身不产生 apply 权限。",
    },
    {
        "title": "按效果 owner 验收外部器官与交互",
        "modules": ["kernel.operations", "automation.taskflow", "channel.matrix", "browser.servo", "ui.control", "ui.native"],
        "action": "保留原 durable schedule/outbox/transaction identity，为每个真实 provider、Matrix homeserver 和 Servo driver 接入目的端去重、发送、终态与对账；让 UI 展示认证后端观察，并接入真实平台权限/更新 owner。",
        "acceptance": "HTTP 接收、本地 ACK、UI 状态变化或 App Server turn 结束不能代替目的端效果终态；实际二进制、网络/沙箱、身份与平台更新回滚均有宿主证据。",
    },
    {
        "title": "完成部署环境与独立接收方的最终验收",
        "modules": ["kernel.evidence", "cognitive.store", "learning.ledger", "learning.artifacts", "learning.eval", "control.engineering"],
        "action": "执行所选宿主的崩溃/断电/文件系统、Windows 私有状态与完整资格、容量/延迟/CPU/RSS、共享存储和恢复测量，并由独立 owner/selector/reviewer 接受证据和回滚演练结果。",
        "acceptance": "完整候选回执、外部不可变锚、独立 custody 与接收方结论共同成立；源码操作数和组件通过数不构成生产完成比例。",
    },
]

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def link(module):
    return "[" + module + "](" + BASE + "docs/modules/" + module + "/IMPLEMENTATION_MAP.json)"

def display_path(path):
    path = path.resolve()
    try:
        return str(path.relative_to(ROOT))
    except ValueError:
        return str(path)

def semantic_view(row):
    """Remove only current navigation fields; all historical provenance stays."""
    result = copy.deepcopy(row)
    for key in ("sourceObjects", "observedAtHead", "observedSourcePaths", "mappingSourceIdentityMode"):
        result.pop(key, None)
    for operation in result.get("operations", []):
        operation.pop("sourceBlob", None)
    for caller in result.get("productCallers", []):
        caller.pop("blobSha", None)
    evidence = result.get("exactSourceEvidence")
    if isinstance(evidence, dict) and evidence.get("kind") == "path_blob_manifest_v1":
        for entry in evidence.get("entries", []):
            entry.pop("blobSha", None)
    return result

def verify_bytes(data, expected, label):
    assert blob(data) == expected["blob"], (label, "Git blob mismatch", blob(data), expected["blob"])
    if "sha256" in expected:
        assert sha256(data) == expected["sha256"], (label, "SHA256 mismatch")
    if "bytes" in expected:
        assert len(data) == expected["bytes"], (label, "byte count mismatch")

order = [module for _, modules in GROUPS for module in modules]
assert len(order) == len(set(order)) == 40
assert set(order) == set(NARRATIVE)
expected_map_paths = {"docs/modules/" + module + "/IMPLEMENTATION_MAP.json" for module in order}
manifest_path = args.verified_blobs.resolve()
manifest_bytes = manifest_path.read_bytes()
manifest = json.loads(manifest_bytes)
assert manifest["schema"] == "hepta.modules40.verified-source-blobs.v1"
assert manifest["repository"] == REPO
assert manifest["sourceCommit"] == SOURCE and manifest["sourceTree"] == TREE
assert len(manifest["files"]) == 40
map_entries = {entry["path"]: entry for entry in manifest["files"]}
assert len(map_entries) == 40 and set(map_entries) == expected_map_paths
assert all(isinstance(entry["changedByFinalNavigation"], bool) for entry in map_entries.values())
changed_maps = {path: entry for path, entry in map_entries.items() if entry["changedByFinalNavigation"]}
assert len(changed_maps) == manifest["navigationReplacementMapCount"]
assert manifest.get("provenance", {}).get("executionEvidenceTransferred") is False

commit_path = args.canonical_objects.resolve()
commit_bytes = commit_path.read_bytes()
commit_objects = json.loads(commit_bytes)["commits"]
pinned_objects = [x for x in commit_objects if x["sha"] == SOURCE]
assert len(pinned_objects) == 1
raw = base64.b64decode(pinned_objects[0]["raw_base64"], validate=True)
assert hashlib.sha1(b"commit " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == SOURCE
assert raw.splitlines()[0] == b"tree " + TREE.encode()
canonical_parents = [line[7:].decode("ascii") for line in raw.split(b"\n\n", 1)[0].splitlines() if line.startswith(b"parent ")]

registry_path = args.registry_file.resolve()
registry_bytes = registry_path.read_bytes()
assert manifest["registryPath"] == "docs/modules/MODULES.json"
verify_bytes(registry_bytes, {
    "blob": manifest["registryBlob"], "sha256": manifest["registrySha256"], "bytes": manifest["registryBytes"]
}, "registry")
registry = json.loads(registry_bytes)
catalog = {x["id"]: x for x in registry["modules"]}
assert len(registry["modules"]) == len(catalog) == 40 and set(catalog) == set(order)

prior_path = args.prior_facts.resolve()
prior_bytes = prior_path.read_bytes()
prior_doc = json.loads(prior_bytes)
assert prior_doc["repository"] == REPO
prior_rows = {x["module"]: x for x in prior_doc["modules"]}
assert len(prior_doc["modules"]) == len(prior_rows) == 40 and set(prior_rows) == set(order)
prior = {}
for module, row in prior_rows.items():
    original_keys = row["reportMetadata"]["originalMapFieldsRetained"]
    assert len(original_keys) == len(set(original_keys))
    assert not {"reportMetadata", "catalogEntry", "operationCount", "sourceRoots"}.intersection(original_keys)
    prior[module] = {key: copy.deepcopy(row[key]) for key in original_keys}
prior_provenance = manifest.get("provenance", {}).get("priorFactSnapshot")
if prior_provenance is not None:
    assert prior_provenance["sha256"] == sha256(prior_bytes)
    assert prior_provenance["sourceCommit"] == prior_doc["sourceSnapshot"]["commit"]
    assert prior_provenance["sourceTree"] == prior_doc["sourceSnapshot"]["tree"]

history_entries = {entry["path"]: entry for entry in manifest["sourceHistory"]}
assert len(history_entries) == len(manifest["sourceHistory"]) > 0
history_inputs = {}
for specification in args.source_history:
    repo_path, separator, local_path = specification.partition("=")
    assert separator and repo_path and local_path, "source-history requires REPOSITORY_PATH=LOCAL_PATH"
    assert repo_path not in history_inputs, (repo_path, "duplicate source-history input")
    history_inputs[repo_path] = Path(local_path).resolve()
assert set(history_inputs) == set(history_entries), "all and only manifest source-history files must be supplied"
source_history = []
history_input_facts = []
for repo_path, entry in history_entries.items():
    local_path = history_inputs[repo_path]
    data = local_path.read_bytes()
    verify_bytes(data, entry, repo_path)
    source_history.append({
        "path": repo_path, "url": BASE + repo_path,
        "gitBlob": blob(data), "sha256": sha256(data), "bytes": len(data),
        "meaning": "Original source-navigation ledger retained as history; it is not an execution receipt for this report's source commit.",
        "document": json.loads(data),
    })
    history_input_facts.append({"path": display_path(local_path), "repositoryPath": repo_path, "sha256": sha256(data), "gitBlob": blob(data)})

group_for = {m: group for group, modules in GROUPS for m in modules}
facts = []
validation_rows = []
for module in order:
    map_path = "docs/modules/" + module + "/IMPLEMENTATION_MAP.json"
    data = (MAP_ROOT / module / "IMPLEMENTATION_MAP.json").read_bytes()
    item = json.loads(data)
    actual_blob = blob(data)
    verify_bytes(data, map_entries[map_path], module)
    assert item["module"] == module
    assert semantic_view(item) == semantic_view(prior[module]), (module, "non-navigation semantics changed")
    assert item["owner"] == catalog[module]["owner"] == prior[module]["owner"]
    assert item["sourceRootPresent"] is True
    assert item["productionImplementation"] is False
    assert catalog[module]["source_root_present"] is True
    assert catalog[module]["production_implementation"] is False
    assert item["claimBoundary"]["productionImplementation"] is False
    assert item["productCallerState"] == prior[module]["productCallerState"]
    assert item["productionWriterState"] == prior[module]["productionWriterState"]
    assert item["sourceBase"] == prior[module]["sourceBase"]
    assert item["resolvedRoots"] == prior[module]["resolvedRoots"]
    assert item["declaredRoots"] == prior[module]["declaredRoots"]
    assert item["claimBoundary"] == prior[module]["claimBoundary"]
    assert item["repositoryControlledGaps"] == prior[module]["repositoryControlledGaps"]
    assert item["externalEvidenceGates"] == prior[module]["externalEvidenceGates"]
    assert all(flag is False for key, flag in item["claimBoundary"].items() if key in ["activation", "release"])
    row = copy.deepcopy(item)
    # Every original Map field/value is retained, including historical source pins.
    assert not {"reportMetadata", "catalogEntry", "operationCount", "sourceRoots"}.intersection(row)
    row["sourceRoots"] = copy.deepcopy(item["resolvedRoots"])
    row["operationCount"] = len(item["operations"])
    row["catalogEntry"] = copy.deepcopy(catalog[module])
    row["reportMetadata"] = {
        "group": group_for[module],
        "mapPath": map_path,
        "mapUrl": BASE + map_path,
        "mapGitBlob": actual_blob,
        "mapSha256": sha256(data),
        "mapBytes": len(data),
        "mapBytesSource": map_entries[map_path]["origin"],
        "changedByFinalNavigation": map_entries[map_path]["changedByFinalNavigation"],
        "summaryZh": {"formedCapabilityAndComposition": NARRATIVE[module][0], "nextOpenGate": NARRATIVE[module][1]},
        "summaryMeaning": "Source-derived description and engineering next step; not a new execution, activation or acceptance assertion.",
        "originalMapFieldsRetained": list(item),
        "originalMapFieldsDeepEqual": all(row[k] == value for k, value in item.items()),
    }
    facts.append(row)
    validation_rows.append({
        "module": module, "mapPath": map_path, "actualBlob": actual_blob,
        "expectedBlob": map_entries[map_path]["blob"], "sha256": sha256(data),
        "allOriginalMapFieldsRetained": True, "sourceBaseUnchangedFromPriorFixedReferenceMap": True,
        "ownerCallerWriterRootsUnchangedFromPriorFactSnapshot": True,
        "allNonNavigationSemanticsUnchanged": True,
        "originalGatesAndClaimBoundaryUnchanged": True,
        "catalogOwnerAndProductionFlagsAgree": True, "operationCount": len(item["operations"]),
    })

operation_count = sum(x["operationCount"] for x in facts)
assert operation_count == 371
assert {x["module"]:x["operationCount"] for x in facts}["learning.ledger"] == 18
assert {x["module"]:x["operationCount"] for x in facts}["runtime.supervisor"] == 12
assert len([x for x in facts if x["reportMetadata"]["changedByFinalNavigation"]]) == len(changed_maps)

validation_inputs = [
    {"path": display_path(manifest_path), "sha256": sha256(manifest_bytes)},
    {"path": display_path(registry_path), "sha256": sha256(registry_bytes), "gitBlob": blob(registry_bytes)},
    {"path": display_path(prior_path), "sha256": sha256(prior_bytes)},
    {"path": display_path(commit_path), "sha256": sha256(commit_bytes)},
] + history_input_facts
validation_checks = {
    "moduleCount": len(facts), "uniqueNarrativeRows": len(NARRATIVE), "groupCounts": {g:len(ms) for g,ms in GROUPS},
    "all40FinalMapBlobsMatch": True, "finalNavigationReplacementMaps": len(changed_maps),
    "canonicalCommitObjectSha1Matches": True, "canonicalCommitTreeMatches": True,
    "registryBlobMatchesExplicitVerifiedManifest": True,
    "all40SourceRootsPresentFlagsTrue": True, "all40ProductionFlagsFalse": True,
    "all40OriginalMapFieldsRetained": True,
    "all40SourceBasesUnchangedFromPriorReferenceMaps": True,
    "all40OwnerCallerWriterAndRootsUnchangedFromPriorFactSnapshot": True,
    "all40NonNavigationSemanticsUnchangedFromPriorFactSnapshot": True,
    "all40RawGatesAndClaimBoundariesUnchanged": True,
    "allSourceHistoryLedgersMatchVerifiedBlobs": True,
    "sourceHistoryLedgerCount": len(source_history),
    "operationCount": operation_count, "criticalPathItems": len(CRITICAL),
    "currentExecutionResultFieldsFabricated": False,
}
doc = {
    "schema": "hepta.modules40.source-facts.v1",
    "repository": REPO,
    "sourceSnapshot": {
        "commit": SOURCE, "tree": TREE,
        "parents": canonical_parents,
        "binding": "Exact local Map, registry and source-history bytes match the explicitly supplied verified-blob manifest; the canonical commit and tree identities are independently checked against the exact raw Git commit object. Historical source fields are retained verbatim, and no execution result is transferred.",
        "verifiedBlobManifest": {"path": display_path(manifest_path), "sha256": sha256(manifest_bytes)},
        "canonicalCommitObject": {"path": display_path(commit_path), "sha256": sha256(commit_bytes)},
        "priorFactSnapshot": {"path": display_path(prior_path), "sha256": sha256(prior_bytes), "commit": prior_doc["sourceSnapshot"]["commit"], "tree": prior_doc["sourceSnapshot"]["tree"]},
        "inputProvenance": copy.deepcopy(manifest.get("provenance", {})),
        "navigationReplacementMapCount": len(changed_maps),
        "executionEvidenceTransferred": False,
    },
    "counts": {
        "moduleCount": len(facts), "sourceRootPresentCount": 40, "productionImplementationCount": 0,
        "operationMapCount": operation_count, "operationMapCountMeaning": "navigation inventory, not passed tests or a production completion percentage",
    },
    "scope": {
        "sourceFactsOnly": True,
        "currentExecutionResultsAdded": False,
        "historicalEvidenceFieldsRetainedAsSourceDeclarations": True,
        "originalClaimBoundariesUnchanged": True,
        "historicalSourcePinsPreserved": True,
        "notComposedMeaning": "The named product caller/owner composition claim remains open; it does not mean that source code is absent.",
        "readonlyOrStatelessMeaning": "A not_applicable or none_by_design writer state must not be read as a missing required writer.",
        "sourceObservationMeaning": "sourceBase, observedAtHead, currentSourceEvidence and sourceReviewAddendum retain their original meanings; none is automatically an execution receipt for sourceSnapshot.commit.",
        "allDynamicNativeAndCiOutcomesBelongInSeparateExecutionOverview": True,
    },
    "groups": [{"name": group, "modules": modules} for group, modules in GROUPS],
    "catalogSource": {"path": "docs/modules/MODULES.json", "url": BASE+"docs/modules/MODULES.json", "gitBlob": blob(registry_bytes), "sha256": sha256(registry_bytes)},
    "sourceHistory": source_history,
    "modules": facts,
    "criticalPath": CRITICAL,
}
serialized_doc = json.dumps(doc, ensure_ascii=False, indent=2) + "\n"
in_memory_round_trip = json.loads(serialized_doc)
for row in in_memory_round_trip["modules"]:
    original = json.loads((MAP_ROOT/row["module"]/"IMPLEMENTATION_MAP.json").read_text())
    assert all(row[k] == value for k, value in original.items())
for entry in in_memory_round_trip["sourceHistory"]:
    assert entry["document"] == json.loads(history_inputs[entry["path"]].read_bytes())
if args.validate_only:
    print(json.dumps({"mode": "validate-only", "sourceCommit": SOURCE, "sourceTree": TREE, "counts": doc["counts"], "checks": validation_checks, "inputs": validation_inputs}, ensure_ascii=False, indent=2))
    sys.exit(0)
OUT.mkdir(parents=True, exist_ok=True)
facts_path = OUT / "MODULES40-SOURCE-FACTS.json"
facts_path.write_text(serialized_doc)

intro = [
    "# 40 个模块的源码能力、组合层级与开放门槛",
    "",
    "当前 40 个模块均有登记的源码根，371 条操作映射构成了实现导航；全部模块的 productionImplementation 仍为 false。源码实现、命名 caller/writer 的组合、固定候选执行、部署资格和独立验收属于不同层级，不能互相替代。",
    "",
    "本节固定描述源码 " + TICK + SOURCE + TICK + "（tree " + TICK + TREE + TICK + "）中的 Map 事实。模块名链接到该提交的对应 Map；原生和平台 CI 的实际结果由执行总览按各自 commit/tree 单独记录。完整源码根、owner、caller/writer 原值、371 条操作、全部 gate 以及历史 source pins 均保存在同目录 " + TICK + "MODULES40-SOURCE-FACTS.json" + TICK + "。",
    "",
    "源码事实以显式传入的 40 张 Map blob 清单、登记表和 canonical Git 对象绑定；" + str(len(source_history)) + " 份 source-navigation history ledger 的原始文档也完整保留在 facts JSON 中。sourceBase 和历史执行观察保持各自身份，新增导航只更新对应源码定位。",
    "",
    "“尚未组合”指命名产品调用与 owner 的组合资格未闭合，不能理解为没有源码。只读、无状态或组合 facade 的模块也不应为了填满 writer 字段而新增持久 owner。",
    "",
    "## 逐模块发展情况",
    "",
    "| 模块 | 实际已形成的能力与组合层级 | 下一项具体开放门槛 |",
    "| --- | --- | --- |",
]
for module in order:
    formed, next_gate = NARRATIVE[module]
    assert "|" not in formed + next_gate
    intro.append("| " + link(module) + " | " + formed + " | " + next_gate + " |")
intro += [
    "",
    "## 读表时保留的边界",
    "",
    "- 表内能力依据当前 Map 的 operation、caller/writer 与 owner 边界概括；完整原字段没有被中文摘要替换或升级。",
    "- 各模块共同需要当前固定源码和有序合并候选的相应资格回执，表中优先列出更具体的产品或外部门槛。",
    "- 历史 sourceBase、observedAtHead、currentSourceEvidence 和源码审阅 addendum 保留原身份。导航重绑不搬运历史执行证据。",
    "- 某些 Map 的内部 gate 列表为空，仍不能据此宣称生产完成；例如 TaskFlow、Servo 和 UI 的实际宿主、二进制、认证与终态验收仍在外部 gate 中。",
    "- 实现操作数不等于模块通过数。局部恢复/取消/撤销回归不代替默认 daemon 完整路径、真实 provider 或独立部署验收。",
    "",
]
(OUT / "MODULES40-DEVELOPMENT-BODY.zh.md").write_text("\n".join(intro))

paths_body = [
    "# 跨模块关键路径",
    "",
    "以下优先顺序由固定源码的开放 gate 与 owner 依赖关系整理，属于工程依赖分析；各项是否完成仍以对应候选和实际宿主的执行回执为准。授权/资源准备、运行时组合和上下文/记忆接入可以并行推进，最终效果执行与验收仍须满足各自 owner 的前提。",
    "",
]
for i, entry in enumerate(CRITICAL, 1):
    paths_body += [
        "## " + str(i) + ". " + entry["title"],
        "",
        entry["action"],
        "",
        "**完成判据：**" + entry["acceptance"],
        "",
        "涉及模块：" + "、".join(link(m) for m in entry["modules"]) + "。",
        "",
    ]
(OUT / "MODULES40-CRITICAL-PATH.zh.md").write_text("\n".join(paths_body))

owner_body = [
    "# 40 模块固定源码根、owner 与调用/写入状态",
    "",
    "固定源码：" + TICK + SOURCE + TICK + "；tree：" + TICK + TREE + TICK + "。下表状态值逐字来自 Map，所有行的 productionImplementation 均为 false。操作列是导航条目数。Map 的 resolvedRoots 与登记表中更广的 sourceEvidenceRoots 分别保留在 JSON 中。",
    "",
    "| 模块 | 固定源码根（resolvedRoots） | Owner | Caller 原状态 | Writer 原状态 | 操作数 |",
    "| --- | --- | --- | --- | --- | ---: |",
]
for row in facts:
    roots = "；".join(TICK+p+TICK for p in row["resolvedRoots"])
    owner_body.append("| "+link(row["module"])+" | "+roots+" | "+TICK+row["owner"]+TICK+" | "+TICK+row["productCallerState"]+TICK+" | "+TICK+row["productionWriterState"]+TICK+" | "+str(row["operationCount"])+" |")
owner_body += ["", "合计：40 个模块、371 条操作映射；生产实现资格为 true 的模块数为 0。", ""]
(OUT / "MODULES40-OWNER-AND-MAPPING.zh.md").write_text("\n".join(owner_body))

def markdown_code(value):
    text = str(value).replace("\r", "\\r").replace("\n", "\\n").replace("|", "\\|")
    longest = max([len(match) for match in re.findall(r"`+", text)] or [0])
    fence = TICK * (longest + 1)
    return fence + " " + text + " " + fence

repository_gate_count = sum(len(row["repositoryControlledGaps"]) for row in facts)
external_gate_count = sum(len(row["externalEvidenceGates"]) for row in facts)
operation_gate_body = [
    "# 40 模块全部操作映射与原文 gate 附录",
    "",
    "固定源码：" + TICK + SOURCE + TICK + "；tree：" + TICK + TREE + TICK + "。本附录完整列出 40 个模块的 371 条操作映射，以及 Map 中保留的 " + str(repository_gate_count) + " 条 repositoryControlledGaps 和 " + str(external_gate_count) + " 条 externalEvidenceGates。所有模块的 productionImplementation 仍为 false。",
    "",
    "各节先提供操作导航表，再完整保留该模块 operations、repositoryControlledGaps 和 externalEvidenceGates 的原始 JSON 字段与值。当前 Map 用 operation 和 designOperation 标识操作，没有 operationId 字段；这里不另造 ID。模块 owner 直接来自 Map；仅在原操作记录实际具备 ownerEntrypoint、ownerBoundary 或委托 owner 字段时才保留对应记录。",
    "",
    "MODULES40-SOURCE-FACTS.json 与固定 Map 原文是完整事实的权威。表内 tests、sourceSemantics 和 sourceBlob 均是源码声明，不是本附录新生成的执行或验收回执。原始 gate 文本保持不变；各候选的执行结果、平台 CI 与合并资格由独立执行总览分别记录，不通过改写历史 gate 或 source pins 转移身份。",
    "",
    "## 模块索引与条目数",
    "",
    "| 模块 | operations | repositoryControlledGaps | externalEvidenceGates |",
    "| --- | ---: | ---: | ---: |",
]
for row in facts:
    operation_gate_body.append("| " + link(row["module"]) + " | " + str(row["operationCount"]) + " | " + str(len(row["repositoryControlledGaps"])) + " | " + str(len(row["externalEvidenceGates"])) + " |")
operation_gate_body += ["", "合计：371 条操作映射；" + str(repository_gate_count) + " 条仓库内 gate；" + str(external_gate_count) + " 条外部证据 gate。", ""]
for index, row in enumerate(facts, 1):
    module = row["module"]
    operation_gate_body += [
        "## " + str(index) + ". " + module,
        "",
        "固定来源：" + link(module) + "。Map Git blob：" + TICK + row["reportMetadata"]["mapGitBlob"] + TICK + "。",
        "",
        "owner：" + markdown_code(row["owner"]) + "；productCallerState：" + markdown_code(row["productCallerState"]) + "；productionWriterState：" + markdown_code(row["productionWriterState"]) + "。",
        "",
        "### 操作导航（" + str(row["operationCount"]) + " 项）",
        "",
        "| operation | designOperation | nativeSymbol | sourcePath | mappingClass |",
        "| --- | --- | --- | --- | --- |",
    ]
    for operation in row["operations"]:
        operation_gate_body.append("| " + " | ".join(markdown_code(operation[field]) for field in ["operation", "designOperation", "nativeSymbol", "sourcePath", "mappingClass"]) + " |")
    for field in ["operations", "repositoryControlledGaps", "externalEvidenceGates"]:
        operation_gate_body += [
            "",
            "### " + field + " 原文（" + str(len(row[field])) + " 项）",
            "",
            "```json",
            json.dumps(row[field], ensure_ascii=False, indent=2),
            "```",
        ]
    operation_gate_body.append("")
operation_gate_path = OUT / "MODULES40-OPERATIONS-AND-GATES.zh.md"
operation_gate_path.write_text("\n".join(operation_gate_body))

validation = {
    "kind": "local-source-fact-snapshot-and-report-verification",
    "sourceCommit": SOURCE, "sourceTree": TREE,
    "readOnlySourceReview": True, "nativeExecutionPerformed": False,
    "githubMutationsPerformed": False, "sourceFilesModified": False,
    "inputs": validation_inputs,
    "checks": validation_checks,
    "modules": validation_rows,
    "outputs": [],
}
for filename in ["MODULES40-DEVELOPMENT-BODY.zh.md", "MODULES40-SOURCE-FACTS.json", "MODULES40-CRITICAL-PATH.zh.md", "MODULES40-OWNER-AND-MAPPING.zh.md", "MODULES40-OPERATIONS-AND-GATES.zh.md"]:
    b=(OUT/filename).read_bytes()
    validation["outputs"].append({"path": filename, "bytes":len(b), "sha256":sha256(b)})

# Confirm that exact original Map values survived the complete JSON round trip.
round_trip = json.loads(facts_path.read_text())
for row in round_trip["modules"]:
    original = json.loads((MAP_ROOT/row["module"]/"IMPLEMENTATION_MAP.json").read_text())
    assert all(row[k] == v for k,v in original.items())
assert len([line for line in (OUT/"MODULES40-DEVELOPMENT-BODY.zh.md").read_text().splitlines() if line.startswith("| [")]) == 40
assert len([line for line in (OUT/"MODULES40-OWNER-AND-MAPPING.zh.md").read_text().splitlines() if line.startswith("| [")]) == 40
operation_gate_text = operation_gate_path.read_text()
operation_gate_blocks = [json.loads(block) for block in re.findall(r"```json\n(.*?)\n```", operation_gate_text, flags=re.DOTALL)]
assert len(operation_gate_blocks) == 120
for index, row in enumerate(facts):
    for offset, field in enumerate(["operations", "repositoryControlledGaps", "externalEvidenceGates"]):
        assert operation_gate_blocks[index * 3 + offset] == row[field], (row["module"], field, "appendix changed raw JSON values")
assert len([line for line in operation_gate_text.splitlines() if line.startswith("| `")]) == operation_count
validation["checks"]["operationsAndGatesAppendixModuleSections"] = len(re.findall(r"^## \d+\. ", operation_gate_text, flags=re.MULTILINE))
assert validation["checks"]["operationsAndGatesAppendixModuleSections"] == 40
validation["checks"]["operationsAndGatesAppendixAll371OperationsPreserved"] = True
validation["checks"]["operationsAndGatesAppendixAllOriginalGateValuesPreserved"] = True
validation["checks"]["repositoryControlledGapCount"] = repository_gate_count
validation["checks"]["externalEvidenceGateCount"] = external_gate_count
(OUT/"SOURCE-REPORT-VALIDATION.json").write_text(json.dumps(validation,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"counts":doc["counts"],"checks":validation["checks"],"outputs":validation["outputs"]},ensure_ascii=False,indent=2))

