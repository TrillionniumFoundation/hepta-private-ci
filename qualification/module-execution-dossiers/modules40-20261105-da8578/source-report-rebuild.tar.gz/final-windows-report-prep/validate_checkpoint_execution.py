"""Verify report statements against a fixed checkpoint's raw receipts and logs."""

from pathlib import Path
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--checkpoint-dir", type=Path, required=True)
parser.add_argument("--source-commit", required=True)
parser.add_argument("--source-tree", required=True)
parser.add_argument("--runtime", type=Path, required=True)
parser.add_argument("--suite-label", required=True)
parser.add_argument("--wrapper-label", required=True)
parser.add_argument("--archive", type=Path, required=True)
parser.add_argument("--archive-sha256", required=True)
parser.add_argument("--expected-wrapper-checks", type=int, default=7)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
native = args.checkpoint_dir / "native"
source = {"commit": args.source_commit, "tree": args.source_tree, "status": ""}
inputs = {}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    data = path.read_bytes()
    inputs[str(path)] = {"path": str(path), "bytes": len(data), "sha256": sha256(data)}
    return data


def document(path):
    return json.loads(read(path))


runtime = document(args.runtime)
assert runtime["state"] == "succeeded" and runtime["exit_code"] == 0
assert runtime["output_complete"] is True and runtime["output_durable"] is True
assert runtime["cancelled"] is False and runtime["timed_out"] is False and runtime["automatic_retry"] is False
assert not any(runtime["log_truncated"].values())
assert all(runtime["log_synced"].values())

archive = read(args.archive)
assert sha256(archive) == args.archive_sha256
manifest = document(args.checkpoint_dir / "MANIFEST.json")
assert manifest["source"] == source
seen = set()
for entry in manifest["entries"]:
    path = Path(entry["path"])
    assert not path.is_absolute() and ".." not in path.parts and str(path) not in seen
    seen.add(str(path))
    data = read(args.checkpoint_dir / path)
    assert len(data) == entry["bytes"] and sha256(data) == entry["sha256"]

suite = document(native / (args.suite_label + "-summary.json"))
wrapper = document(native / (args.wrapper_label + "-summary.json"))
assert suite["source"] == suite["source_after"] == source
assert wrapper["source"] == wrapper["source_after"] == source
assert suite["runner_exit"] == suite["audit_exit"] == 0
assert len(suite["qualification_checks"]) == 7 and set(suite["qualification_checks"].values()) == {0}
assert len(wrapper["checks"]) == args.expected_wrapper_checks and set(wrapper["checks"].values()) == {0}

receipts = []
logs = {}
for path in sorted(native.glob("*.json")):
    if not (path.name.startswith(args.suite_label + "-") or path.name.startswith(args.wrapper_label + "-")):
        continue
    doc = document(path)
    if "source_before" not in doc or "source_after" not in doc or "log_path" not in doc:
        continue
    assert doc["source_before"] == doc["source_after"] == source
    assert doc["exit"] == 0
    log = read(native / Path(doc["log_path"]).name)
    assert len(log) == doc["log_bytes"] and sha256(log) == doc["log_sha256"]
    logs[path.name] = log.decode()
    receipts.append({"path": str(path), "command": doc["command"], "exit": doc["exit"],
                     "elapsedSeconds": doc["elapsed_seconds"], "logSha256": doc["log_sha256"]})
assert receipts

junit_bytes = read(native / (args.suite_label + ".junit.xml"))
assert sha256(junit_bytes) == suite["junit"]["sha256"] and len(junit_bytes) == suite["junit"]["bytes"]
junit = ET.fromstring(junit_bytes)
cases = junit.findall(".//testcase")
suites = junit.findall(".//testsuite")
assert len(cases) == suite["junit_case_count"] == int(junit.attrib["tests"])
assert int(junit.attrib["failures"]) == int(junit.attrib["errors"]) == 0
for tag in ("failure", "error", "skipped", "flakyFailure", "flakyError", "rerunFailure", "rerunError"):
    assert not junit.findall(".//" + tag), tag

audit = document(native / (args.suite_label + "-required-tests.69.native-audit.json"))
bound = document(native / (args.suite_label + "-required-tests.69.source-bound.json"))
assert bound["candidate"] == audit["candidate_identity_supplied_by_operator"] == {"commit": args.source_commit, "tree": args.source_tree}
assert audit["gate_result"] == "CLEAN" and audit["original_suite_exit_code"] == 0
assert audit["required_count"] == audit["required_clean_passes"] == len(audit["required_results"]) == 69
assert audit["observed_case_count"] == len(cases)
assert audit["manifest"]["sha256"] == sha256((native / (args.suite_label + "-required-tests.69.source-bound.json")).read_bytes())
for key in ("all_failed_cases", "all_flaky_or_retried_cases", "all_skipped_cases", "aggregate_failures", "parse_errors"):
    assert audit[key] == []
required_ids = set()
for case in audit["required_results"]:
    identifier = (case["package"], case["binary"], case["test"])
    assert identifier not in required_ids
    required_ids.add(identifier)
    assert case["status"] == "PASS" and len(case["matches"]) == 1 and case["same_name_wrong_target"] == []
    match = case["matches"][0]
    actual = [item for item in cases if item.attrib.get("name") == match["name"] and item.attrib.get("classname") == match["classname"]]
    assert len(actual) == 1
    assert match["skipped"] is False and match["failed"] is False and match["flaky_or_retried"] is False

summary_pattern = re.compile(r"Summary \[\s*([\d.]+)s\]\s+(\d+) tests run:\s+(\d+) passed(?: \((\d+) slow\))?,\s+(\d+) skipped")


def parse_summary(log, label):
    matches = summary_pattern.findall(log)
    assert len(matches) == 1, (label, len(matches))
    elapsed, run, passed, slow, skipped = matches[0]
    assert int(run) == int(passed)
    return {"elapsedSeconds": float(elapsed), "testsRun": int(run), "passed": int(passed),
            "slow": int(slow or 0), "skipped": int(skipped), "failed": 0, "timedOut": 0}


suite_result = parse_summary(logs[args.suite_label + "-original-test.json"], "complete seven packages")
assert suite_result["passed"] == len(cases)
library_result = parse_summary(logs[args.wrapper_label + "-two-library-regression.json"], "two libraries")
appserver_result = parse_summary(logs[args.wrapper_label + "-app-server-process-regression.json"], "AppServer process_exec")
codespell = document(native / (args.wrapper_label + "-original-codespell.json"))
assert codespell["command"][1:] == ["--ignore-words", ".codespellignore", "--skip", "./.git"]
assert "codespell-2.4.3/bin/codespell" in codespell["command"][0]
assert logs[args.wrapper_label + "-original-codespell.json"] == ""
clippy = document(native / (args.wrapper_label + "-original-ci-policy-clippy.json"))
assert clippy["command"][-7:] == ["--", "-D", "clippy::correctness", "-D", "clippy::await_holding_lock", "-D", "clippy::await_holding_invalid_type"]
assert "warnings" not in clippy["command"]
format_warnings = {}
for suffix in ("original-workspace-format", "original-four-package-format"):
    log = logs[args.wrapper_label + "-" + suffix + ".json"]
    format_warnings[suffix] = log.count("can't set `imports_granularity = Item`")
assert format_warnings["original-workspace-format"] > 0

result = {
    "schema": "hepta.modules40.checkpoint-execution-report-validation.v1",
    "sourceCommit": args.source_commit, "sourceTree": args.source_tree,
    "readOnlyLocalEvidenceValidation": True, "newNativeExecutionPerformed": False,
    "runtime": {"jobId": runtime["job_id"], "state": runtime["state"], "exitCode": runtime["exit_code"],
                "outputComplete": True, "outputDurable": True, "timedOut": False, "cancelled": False, "automaticRetry": False},
    "archive": {"path": str(args.archive), "bytes": len(archive), "sha256": sha256(archive),
                "manifestEntryCount": len(manifest["entries"]), "totalFileCountIncludingManifest": len(manifest["entries"]) + 1,
                "allExtractedManifestEntriesMatch": True, "baseEvidence": manifest["base_evidence"]},
    "suite": suite_result, "junit": {"bytes": len(junit_bytes), "sha256": sha256(junit_bytes),
                                     "testSuiteCount": len(suites), "testCaseCount": len(cases),
                                     "failures": 0, "errors": 0, "skippedCasesInJunit": 0,
                                     "skipMeaning": "Original runner summary remains authoritative for selection skips omitted from this JUnit."},
    "requiredAudit": {"count": 69, "cleanPasses": 69, "uniqueRequiredIdentities": 69, "allMatchesFoundIndependentlyInJunit": True,
                      "gateResult": "CLEAN", "candidateIdentityBound": True},
    "sevenStrictChecks": suite["qualification_checks"], "sevenWrapperChecks": wrapper["checks"],
    "twoLibraryResult": library_result, "appServerProcessExecResult": appserver_result,
    "codespellVersionPath": codespell["command"][0], "codespellOriginalArgumentsRetained": True,
    "clippyOriginalThreeDenyPolicyRetained": True, "formatIgnoredNightlyOptionWarningCounts": format_warnings,
    "sourceBoundSuccessfulReceiptCount": len(receipts), "receipts": receipts,
    "limits": ["Linux scope only; no Windows or Darwin compilation/runtime qualification is inferred.",
               "No result is transferred to a later commit, same-tree identity, merge candidate or evidence carrier.",
               "The 69-case manifest is an audit subset, not an execution filter; complete-suite failure would remain failure.",
               "Skipped tests remain skipped; separate command scopes and repeated candidates are not added together.",
               "Stable rustfmt ignores the recorded nightly-only imports_granularity option.",
               "All 40 production flags remain false; provider/deployment/independent acceptance remains open."],
    "inputs": list(inputs.values()),
}
if "atomic_snapshot" in manifest:
    assert manifest["atomic_snapshot"] is False
    custody = read(args.checkpoint_dir / "READ-CUSTODY.json")
    assert sha256(custody) == manifest["read_custody_sha256"]
    result["archive"]["atomicSnapshot"] = False
    result["archive"]["collectionScope"] = manifest["scope"]
    result["archive"]["readCustodySha256"] = sha256(custody)
    result["limits"].append("File API collection uses independent per-file versions and hashes; it is not an atomic cross-file snapshot or current-checkout attestation.")
    result["inputs"] = list(inputs.values())
if args.expected_wrapper_checks == 8:
    result["scopeChecks"] = result.pop("sevenWrapperChecks")
    result["scopeCheckCount"] = 8
    assert wrapper["checks"]["original-windows-ci-receipt-controls"] == 0
    control = document(native / (args.wrapper_label + "-original-windows-ci-receipt-controls.json"))
    assert control["command"] == ["python3", "-m", "unittest", "discover", "-s", ".github/scripts", "-p", "test_windows_current_ci*.py"]
    control_log = logs[args.wrapper_label + "-original-windows-ci-receipt-controls.json"]
    counts = re.findall(r"Ran (\d+) tests? in ([\d.]+)s", control_log)
    assert len(counts) == 1 and re.search(r"^OK\s*$", control_log, re.MULTILINE)
    result["pythonCiReceiptControls"] = {"testCount": int(counts[0][0]), "elapsedSeconds": float(counts[0][1]),
                                        "exitCode": 0, "scope": "Original Python CI receipt rejection controls executed on Linux; not a Windows compilation or runtime qualification."}
    result["inputs"] = list(inputs.values())
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"sourceCommit": args.source_commit, "suite": suite_result,
                  "twoLibrary": library_result, "appServer": appserver_result,
                  "requiredCases": 69, "sourceBoundReceipts": len(receipts),
                  "output": str(args.output), "outputSha256": sha256(args.output.read_bytes())}, ensure_ascii=False, indent=2))
