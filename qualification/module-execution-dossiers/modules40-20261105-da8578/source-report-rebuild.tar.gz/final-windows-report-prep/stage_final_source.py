"""Stage fixed final merge 865 without changing historical Maps or reports."""

from pathlib import Path
import base64
import copy
import hashlib
import json


ROOT = Path.cwd()
OUT = ROOT / "final-windows-report-prep"
SOURCE = "8658210499706130788c216ff14fd342809b45a4"
TREE = "6bc86196d10cf83b010f9917e5e9cb471b5f6b68"
PRIOR = "775bf555b0a7faf6eed17627acb0d0433294b737"
PRIOR_TREE = "e6f4644152d11a06457fdd92d8e5066675b26565"
UPSTREAM = "3a39c799a3f776b0aeedfce350341d865d3cc1c4"
NATIVE = "c2834dcade885fb9ff5da41b3947773067ec652d"
PARENTS = [PRIOR, UPSTREAM]
PRIOR_DIR = ROOT / "windows-775-report-prep"
FACTS_PATH = PRIOR_DIR / "MODULES40-SOURCE-FACTS.json"
MANIFEST_PATH = PRIOR_DIR / "source-verified-blobs.json"
EXPORT_PATH = ROOT / "integration/upstream-3a39-native-export.json"
PREVIEW_PATH = ROOT / "integration/complete-navigation-preview.json"
OBJECT_PATH = ROOT / "integration/canonical-complete-object.json"
METADATA_PATH = ROOT / "integration/canonical-complete-metadata.json"
COMPARE_PATH = OUT / "github-775-to-865-compare.json"
REGISTRY_CAPTURE_PATH = OUT / "github-865-registry-capture.json"
UPSTREAM_COMPARE_PATH = ROOT / "integration/live-base-073-to-3a39-compare.json"
OPENSSH_PREFORMAT_PATH = ROOT / "integration/upstream-3a39-openssh-preformat.rs"
OPENSSH = "codex-rs/hepta-operator-acceptance/src/openssh_windows.rs"
PTY = "codex-rs/utils/pty/src/win/native_observation_tests.rs"
CI_PATHS = {
    ".github/scripts/aggregate_windows_current_ci.py",
    ".github/scripts/test_windows_current_ci_shards.py",
    ".github/scripts/windows_current_ci.py",
    ".github/workflows/hepta-windows-current-ci.yml",
}
CHANGED_PATHS = CI_PATHS | {OPENSSH}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git_object(kind, data):
    return hashlib.sha1(kind.encode() + b" " + str(len(data)).encode() + b"\0" + data).hexdigest()


def read(path):
    data = path.read_bytes()
    return data, json.loads(data)


def fact(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(data), "sha256": sha256(data)}


def verify_blob(data, expected):
    assert git_object("blob", data) == expected["blob"]
    assert sha256(data) == expected["sha256"]
    if "bytes" in expected:
        assert len(data) == expected["bytes"]


def verify_commit(data, commit):
    assert git_object("commit", data) == commit
    headers = data.split(b"\n\n", 1)[0].splitlines()
    assert headers[0] == b"tree " + TREE.encode()
    assert [line[7:].decode() for line in headers if line.startswith(b"parent ")] == PARENTS


prior_bytes, prior = read(FACTS_PATH)
manifest_bytes, prior_manifest = read(MANIFEST_PATH)
export_bytes, export = read(EXPORT_PATH)
preview_bytes, preview = read(PREVIEW_PATH)
object_bytes, objects = read(OBJECT_PATH)
metadata_bytes, metadata = read(METADATA_PATH)
compare_bytes, compare = read(COMPARE_PATH)
registry_capture_bytes, registry_capture = read(REGISTRY_CAPTURE_PATH)
upstream_compare_bytes, upstream_compare = read(UPSTREAM_COMPARE_PATH)

assert prior["sourceSnapshot"]["commit"] == prior_manifest["sourceCommit"] == PRIOR
assert prior["sourceSnapshot"]["tree"] == prior_manifest["sourceTree"] == PRIOR_TREE
assert export["before"] == {"commit": PRIOR, "tree": PRIOR_TREE, "status": ""}
assert export["source"] == {"commit": NATIVE, "tree": TREE, "status": ""}
assert export["parents"] == PARENTS and export["upstream"] == UPSTREAM
assert export["all_maps_unchanged"] is True and export["execution_evidence_transferred"] is False
assert export["merge"]["conflicts"] == [PTY]
assert export["format"]["exit"] == 0 and export["format"]["changed_paths"] == [OPENSSH]
assert {row["path"] for row in export["files"]} == CHANGED_PATHS and len(export["files"]) == 5
verify_commit(base64.b64decode(export["raw_commit_base64"], validate=True), NATIVE)
canonical = [row for row in objects["commits"] if row["sha"] == SOURCE]
assert len(canonical) == 1
verify_commit(base64.b64decode(canonical[0]["raw_base64"], validate=True), SOURCE)
assert metadata["sha"] == SOURCE and metadata["tree"]["sha"] == TREE
assert [row["sha"] for row in metadata["parents"]] == PARENTS

assert compare["base_commit"]["sha"] == compare["merge_base_commit"]["sha"] == PRIOR
assert compare["base_commit"]["commit"]["tree"]["sha"] == PRIOR_TREE
assert compare["status"] == "ahead" and compare["behind_by"] == 0
assert len(compare["commits"]) == compare["total_commits"]
compared_head = [row for row in compare["commits"] if row["sha"] == SOURCE]
assert len(compared_head) == 1 and compared_head[0]["commit"]["tree"]["sha"] == TREE
assert [row["sha"] for row in compared_head[0]["parents"]] == PARENTS
assert {row["filename"] for row in compare["files"]} == CHANGED_PATHS and len(compare["files"]) == 5
compare_files = {row["filename"]: row for row in compare["files"]}
upstream_files = {row["filename"]: row for row in upstream_compare["files"]}
assert upstream_compare["commits"][-1]["sha"] == UPSTREAM
exports = {row["path"]: row for row in export["files"]}
for path, row in exports.items():
    data = row["content"].encode()
    verify_blob(data, row)
    assert compare_files[path]["sha"] == row["blob"]
    if path in CI_PATHS:
        assert row["blob"] == upstream_files[path]["sha"]

preformat = OPENSSH_PREFORMAT_PATH.read_text()
assert git_object("blob", preformat.encode()) == upstream_files[OPENSSH]["sha"]
expected_formatted = preformat
for diagnostic, indentation in [
    ("diagnostic executable exceeds 64 MiB read bound", "            "),
    ("diagnostic executable ended before its bound", "                "),
]:
    old = 'return Err(std::io::Error::other("' + diagnostic + '"));'
    new = 'return Err(std::io::Error::other(\n' + indentation + '    "' + diagnostic + '",\n' + indentation + '));'
    assert expected_formatted.count(old) == 1
    expected_formatted = expected_formatted.replace(old, new, 1)
for diagnostic, indentation in [
    ("HEPTA_OPENSSH_DIAGNOSTIC wait_unknown={error:?}; original_child_and_pins_retained=true", "            "),
    ("HEPTA_OPENSSH_DIAGNOSTIC child_terminal={status:?} stdin_write_result={write_result:?}", "    "),
]:
    old = 'eprintln!("' + diagnostic + '");'
    new = 'eprintln!(\n' + indentation + '    "' + diagnostic + '"\n' + indentation + ');'
    assert expected_formatted.count(old) == 1
    expected_formatted = expected_formatted.replace(old, new, 1)
assert expected_formatted == exports[OPENSSH]["content"]

assert preview["source"] == {"commit": SOURCE, "tree": TREE, "status": ""} and preview["exit"] == 0
assert preview["operations"] == 371 and preview["modules"] == preview["production_false"] == 40
result = preview["output"]
assert result["candidateSource"] == {"commit": SOURCE, "tree": TREE}
assert result["changedMaps"] == 0 and result["maps"] == [] and result["ledger"] is None
assert result["written"] is False and result["historicalSourceBasesModified"] is False
assert result["executionEvidenceTransferred"] is False

prior_rows = {row["reportMetadata"]["mapPath"]: row for row in prior["modules"]}
assert len(prior_rows) == len(prior_manifest["files"]) == 40
assert set(preview["all_map_sha256"]) == set(prior_rows)
entries = []
staged = {}
for entry in prior_manifest["files"]:
    path = entry["path"]
    data = (PRIOR_DIR / "source-snapshot" / path).read_bytes()
    verify_blob(data, entry)
    assert sha256(data) == preview["all_map_sha256"][path]
    row = prior_rows[path]
    original = {key: row[key] for key in row["reportMetadata"]["originalMapFieldsRetained"]}
    assert json.loads(data) == original and entry["blob"] == row["reportMetadata"]["mapGitBlob"]
    for field in ("resolvedRoots", "observedSourcePaths"):
        for observed in original.get(field, []):
            observed = observed.rstrip("/")
            assert not any(path == observed or path.startswith(observed + "/") for path in CHANGED_PATHS)
    entries.append({"path": path, "blob": entry["blob"], "sha256": sha256(data), "bytes": len(data),
                    "origin": "unchanged-prior-canonical-map-verified-by-final-merge-preview",
                    "changedByFinalNavigation": False})
    staged[path] = data

history_entries = copy.deepcopy(prior_manifest["sourceHistory"])
assert len(history_entries) == 3
assert {row["path"]: row["sha256"] for row in history_entries} == preview["history_sha256"]
for entry in history_entries:
    data = (PRIOR_DIR / "source-snapshot" / entry["path"]).read_bytes()
    verify_blob(data, entry)
    staged[entry["path"]] = data
registry_path = prior_manifest["registryPath"]
registry = (PRIOR_DIR / "source-snapshot" / registry_path).read_bytes()
verify_blob(registry, {"blob": prior_manifest["registryBlob"], "sha256": prior_manifest["registrySha256"], "bytes": prior_manifest["registryBytes"]})
assert registry_capture["encoding"] == "utf-8" and registry_capture["sha"] == prior_manifest["registryBlob"]
assert registry_capture["content"].encode() == registry
assert registry_capture["display_url"].endswith("/blob/" + SOURCE + "/" + registry_path)
staged[registry_path] = registry

layers = copy.deepcopy(prior_manifest["provenance"].get("mapOverlayLayers", []))
layers.append({"kind": "fixed-two-parent-merge-no-navigation-mutation", "canonicalCommit": SOURCE,
               "canonicalTree": TREE, "orderedParents": PARENTS, "nativeMergeCommit": NATIVE,
               "mapCount": 0, "navigationPreview": fact(PREVIEW_PATH), "newSourceHistoryLedger": None})
manifest = {
    "schema": "hepta.modules40.verified-source-blobs.v1", "repository": prior["repository"],
    "sourceCommit": SOURCE, "sourceTree": TREE, "registryPath": registry_path,
    "registryBlob": prior_manifest["registryBlob"], "registrySha256": sha256(registry), "registryBytes": len(registry),
    "files": entries, "sourceHistory": history_entries, "navigationReplacementMapCount": 0,
    "provenance": {
        "priorFactSnapshot": {**fact(FACTS_PATH), "sourceCommit": PRIOR, "sourceTree": PRIOR_TREE},
        "priorVerifiedBlobManifest": fact(MANIFEST_PATH),
        "priorSourceProvenance": copy.deepcopy(prior_manifest["provenance"]),
        "nativeMergeExport": {**fact(EXPORT_PATH), "nativeCommit": NATIVE, "nativeTree": TREE,
                              "orderedParents": PARENTS, "changedPathsFromPrior": sorted(CHANGED_PATHS)},
        "nativeNavigationPreview": fact(PREVIEW_PATH), "canonicalCommitObject": fact(OBJECT_PATH),
        "canonicalCommitMetadata": fact(METADATA_PATH), "githubExactPriorComparison": fact(COMPARE_PATH),
        "githubExactRegistryRead": fact(REGISTRY_CAPTURE_PATH), "frozenUpstreamComparison": fact(UPSTREAM_COMPARE_PATH),
        "openSshPreformat": fact(OPENSSH_PREFORMAT_PATH), "mapOverlayLayers": layers,
        "executionEvidenceTransferred": False,
    },
    "verification": {
        "all40MapGitBlobsLocallyVerified": True, "all40MapHashesMatchFinalNativePreview": True,
        "all40OriginalMapBytesUnchanged": True, "allNonNavigationSemanticsUnchanged": True,
        "allThreeHistoryLedgerBytesUnchanged": True, "noNavigationMutationAndNoNewHistoryLedger": True,
        "canonicalAndNativeCommitObjectsVerified": True, "orderedTwoParentsVerified": True,
        "githubPriorComparisonHasExactlyFiveAllowedChanges": True, "allFourCiBlobsMatchFrozenUpstream": True,
        "openSshChangesFromUpstreamAreExactlyFourFormatLayoutsAndTwoTrailingCommas": True,
        "ptyReviewedBytesRetainedInCanonicalMerge": True, "registryBlobVerifiedByExactCanonicalFetch": True,
        "nativeAndPlatformExecutionResultTransferred": False,
    },
}
for path, data in staged.items():
    dest = OUT / "source-snapshot" / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
output = OUT / "source-verified-blobs.json"
output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"sourceCommit": SOURCE, "sourceTree": TREE, "orderedParents": PARENTS,
                  "mapCount": 40, "navigationReplacementMaps": 0, "sourceHistoryCount": 3,
                  "manifest": str(output.relative_to(ROOT)), "manifestSha256": sha256(output.read_bytes())}, ensure_ascii=False, indent=2))
