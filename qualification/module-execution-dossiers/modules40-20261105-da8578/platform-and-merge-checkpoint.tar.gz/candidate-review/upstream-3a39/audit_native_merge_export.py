#!/usr/bin/env python3
"""Independently verify native merge export against fixed immutable source inputs."""
import base64
import copy
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[1]
EXPORT = WORK / "integration/upstream-3a39-native-export.json"


def main():
    spec = importlib.util.spec_from_file_location("builder", ROOT / "build_import_bundle.py")
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    raw_export = EXPORT.read_bytes()
    assert hashlib.sha256(raw_export).hexdigest() == "2486c4784e87b6b8e4b5c62227bcd5d9d5c22b65b72d18b265df1d7405b1b7b0"
    export = json.loads(raw_export)
    inputs = json.loads((ROOT / "inputs.json").read_bytes())
    bundle = json.loads((ROOT / "native-import-bundle.json").read_bytes())
    assert export["before"] == {"commit": bundle["oursCommit"], "tree": bundle["oursTree"], "status": ""}
    assert export["upstream"] == bundle["headCommit"]
    assert export["parents"] == [bundle["oursCommit"], bundle["headCommit"]]
    assert export["merge"]["conflicts"] == [builder.PTY]
    assert export["merge"]["exit"] == 1 and export["format"]["exit"] == 0
    assert export["source"]["status"] == ""
    for observed, expected in zip(export["imports"], bundle["commits"], strict=True):
        assert observed == {"commit": expected["sha"], "tree": expected["tree"], "parents": expected["parents"], "files": [f["path"] for f in expected["files"]]}
    assert len(export["imports"]) == 8
    upstream = {f["path"]: f for f in bundle["resolvedFiles"]}
    files = {f["path"]: f for f in export["files"]}
    expected_paths = {p for p in upstream if p.startswith(".github/") or p.endswith("openssh_windows.rs")}
    assert set(files) == expected_paths and len(files) == 5
    for path, file in files.items():
        data = file["content"].encode()
        assert file["mode"] == "100644"
        assert builder.object_id("blob", data) == file["blob"]
        assert hashlib.sha256(data).hexdigest() == file["sha256"]
        if path.startswith(".github/"):
            assert file["content"] == upstream[path]["content"]
            assert file["blob"] == upstream[path]["blob"]
    operator = "codex-rs/hepta-operator-acceptance/src/openssh_windows.rs"
    before = upstream[operator]["content"]
    after = files[operator]["content"]
    replacements = [
        ('            return Err(std::io::Error::other("diagnostic executable exceeds 64 MiB read bound"));\n',
         '            return Err(std::io::Error::other(\n                "diagnostic executable exceeds 64 MiB read bound",\n            ));\n'),
        ('                return Err(std::io::Error::other("diagnostic executable ended before its bound"));\n',
         '                return Err(std::io::Error::other(\n                    "diagnostic executable ended before its bound",\n                ));\n'),
        ('            eprintln!("HEPTA_OPENSSH_DIAGNOSTIC wait_unknown={error:?}; original_child_and_pins_retained=true");\n',
         '            eprintln!(\n                "HEPTA_OPENSSH_DIAGNOSTIC wait_unknown={error:?}; original_child_and_pins_retained=true"\n            );\n'),
        ('    eprintln!("HEPTA_OPENSSH_DIAGNOSTIC child_terminal={status:?} stdin_write_result={write_result:?}");\n',
         '    eprintln!(\n        "HEPTA_OPENSSH_DIAGNOSTIC child_terminal={status:?} stdin_write_result={write_result:?}"\n    );\n'),
    ]
    expected = before
    for old, new in replacements:
        assert expected.count(old) == 1
        expected = expected.replace(old, new)
    assert expected == after
    assert export["format"]["changed_paths"] == [operator]
    diff = "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="fixed3a39/" + operator, tofile="nativeformatted/" + operator))
    (ROOT / "OPENSSH-NATIVE-FORMAT.patch").write_text(diff)

    trees = {node["sha"]: json.loads(node["raw"])["tree"] for node in inputs["treeNodes"]}

    def update(parent, changes):
        entries = {e["path"]: copy.deepcopy(e) for e in trees[parent]}
        groups = {}
        for path, file in changes.items():
            first, sep, rest = path.partition("/")
            groups.setdefault(first, []).append((rest if sep else None, file))
        for first, group in groups.items():
            if group[0][0] is None:
                assert len(group) == 1
                file = group[0][1]
                entries[first] = {"path": first, "type": "blob", "mode": file["mode"], "sha": file["blob"]}
            else:
                entries[first]["sha"] = update(entries[first]["sha"], dict(group))
        raw = builder.tree_bytes(list(entries.values()))
        result = builder.object_id("tree", raw)
        trees[result] = list(entries.values())
        return result

    computed = update(bundle["oursTree"], files)
    assert computed == export["source"]["tree"] == "6bc86196d10cf83b010f9917e5e9cb471b5f6b68"
    raw_commit = base64.b64decode(export["raw_commit_base64"], validate=True)
    assert builder.object_id("commit", raw_commit) == export["source"]["commit"] == "c2834dcade885fb9ff5da41b3947773067ec652d"
    headers = raw_commit.split(b"\n\n", 1)[0].decode().splitlines()
    assert headers[0] == "tree " + computed
    assert [line[7:] for line in headers if line.startswith("parent ")] == export["parents"]
    report = {
        "exportPath": str(EXPORT), "exportSha256": hashlib.sha256(raw_export).hexdigest(),
        "nativeCommit": export["source"]["commit"], "nativeCommitRawHashVerified": True,
        "nativeTree": computed, "treeIndependentlyReconstructedFromImmutableOursTreeAndExactlyFivePostimages": True,
        "orderedParents": export["parents"], "eightOriginalUpstreamCommitIdentitiesAndTreesPreserved": True,
        "actualMergeConflict": builder.PTY, "allFourCiFilesByteIdenticalToUpstream3a39": True,
        "operatorFormatting": {"hunks": 4, "changes": "Four line wraps plus two optional trailing commas in single-argument std::io::Error::other calls.",
                               "strictlyWhitespaceOnly": False, "exactFourReplacementProof": True,
                               "diagnosticStringBytesAndAllOtherSourceBytesUnchanged": True,
                               "scope": "Formatting only; no change to executable read bound, diagnostic calls, child arguments, environment, stdio, waits or custody."},
        "preformatTree": {"prediction": "1ea655ddf48618ad81105c8976e80c25f44db3dc", "observedNatively": False,
                          "boundary": "No standalone native pre-format write-tree receipt was exported. This remains an independent prediction only."},
        "qualificationBoundary": "Source merge and formatter audit only. No merged-source tests, Windows qualification or production claim is inferred from this export.",
        "remoteMutationsPerformedByAuditor": False,
    }
    (ROOT / "NATIVE-MERGE-EXPORT-AUDIT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
