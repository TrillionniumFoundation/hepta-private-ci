#!/usr/bin/env python3
"""Verify immutable upstream objects and prepare reviewed, local-only merge input."""
from __future__ import annotations

import base64
import copy
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import zlib

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[1]
INPUT = json.loads((ROOT / "inputs.json").read_bytes())
PTY = "codex-rs/utils/pty/src/win/native_observation_tests.rs"


def object_id(kind, content):
    return hashlib.sha1(kind.encode() + b" " + str(len(content)).encode() + b"\0" + content).hexdigest()


def sha(content):
    return hashlib.sha256(content).hexdigest()


def write(path, data):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, str):
        data = data.encode()
    p.write_bytes(data)
    return p


def save(path, obj):
    return write(path, json.dumps(obj, indent=2, ensure_ascii=False) + "\n")


def tree_bytes(entries):
    def key(entry):
        return entry["path"].encode() + (b"/" if entry["type"] == "tree" else b"")
    result = b""
    for entry in sorted(entries, key=key):
        assert "/" not in entry["path"] and "\0" not in entry["path"]
        mode = entry["mode"].lstrip("0")
        result += mode.encode() + b" " + entry["path"].encode() + b"\0" + bytes.fromhex(entry["sha"])
    return result


def main():
    spec = importlib.util.spec_from_file_location("canonical", WORK / "integration/rebuild-canonical-commits.py")
    canonical = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(canonical)
    blobs = {}
    for item in INPUT["blobs"]:
        data = item["content"].encode()
        assert object_id("blob", data) == item["sha"]
        blobs[item["sha"]] = data
        write("objects/blobs/" + item["sha"], data)
    trees = {}
    for item in INPUT["treeNodes"]:
        node = json.loads(item["raw"])
        assert node["sha"] == item["sha"] and not node["truncated"]
        raw = tree_bytes(node["tree"])
        assert object_id("tree", raw) == item["sha"]
        trees[item["sha"]] = node["tree"]
        write("tree-metadata/" + item["sha"] + ".json", item["raw"])
        write("objects/trees/" + item["sha"] + ".raw", raw)

    def update_tree(parent_tree, changes):
        entries = {e["path"]: copy.deepcopy(e) for e in trees[parent_tree]}
        grouped = {}
        for path, change in changes.items():
            first, sep, rest = path.partition("/")
            grouped.setdefault(first, []).append((rest if sep else None, change))
        for first, group in grouped.items():
            if group[0][0] is None:
                assert len(group) == 1
                change = group[0][1]
                entries[first] = {"path": first, "mode": change["mode"], "type": "blob", "sha": change["blob"]}
            else:
                assert entries[first]["type"] == "tree"
                new = update_tree(entries[first]["sha"], dict(group))
                entries[first]["sha"] = new
        raw = tree_bytes(list(entries.values()))
        new = object_id("tree", raw)
        assert new in trees and tree_bytes(trees[new]) == raw, new
        return new

    resolved = INPUT["resolvedPaths"]
    lookup = {(r["purpose"], r["commit"], r["path"]): r for r in resolved}
    commits = []
    raw_reports = []
    parent_sha = INPUT["base"]["sha"]
    parent_tree = INPUT["base"]["tree"]["sha"]
    for item in INPUT["commits"]:
        meta = json.loads(item["metadataRaw"])
        details = json.loads(item["detailsRaw"])
        assert meta["sha"] == details["sha"]
        assert [p["sha"] for p in meta["parents"]] == [parent_sha]
        assert details["commit"]["tree"]["sha"] == meta["tree"]["sha"]
        assert details["parents"][0]["sha"] == parent_sha
        raw, report = canonical.rebuild(meta)
        assert object_id("commit", raw) == meta["sha"]
        write("git-metadata/" + meta["sha"] + ".json", item["metadataRaw"])
        write("commit-details/" + meta["sha"] + ".json", item["detailsRaw"])
        write("objects/commits/" + meta["sha"] + ".raw", raw)
        files = []
        for f in details["files"]:
            assert f["status"] in ("added", "modified")
            r = lookup[("upstream-commit", meta["sha"], f["filename"])]
            assert not r["absent"] and r["entry"]["sha"] == f["sha"]
            data = blobs[f["sha"]]
            entry = {"path": f["filename"], "mode": r["entry"]["mode"], "blob": f["sha"], "sha256": sha(data), "content": data.decode()}
            files.append(entry)
            write("postimages/" + meta["sha"] + "/" + f["filename"], data)
        assert update_tree(parent_tree, {f["path"]: f for f in files}) == meta["tree"]["sha"]
        commits.append({"sha": meta["sha"], "tree": meta["tree"]["sha"], "parents": [parent_sha], "raw_base64": base64.b64encode(raw).decode(), "files": files})
        report["parentTree"] = parent_tree
        report["treeRebuiltExactlyFromParentAndListedPostimages"] = True
        raw_reports.append(report)
        parent_sha, parent_tree = meta["sha"], meta["tree"]["sha"]
    assert parent_sha == INPUT["head"] and len(commits) == 8

    empty = write("merge-input/absent.empty", b"")
    snapshots = {}
    for lane in ("base", "ours", "theirs"):
        commit = INPUT["base"]["sha"] if lane == "base" else INPUT["ours"]["sha"] if lane == "ours" else INPUT["head"]
        snapshots[lane] = {}
        for f in INPUT["compare"]["files"]:
            path = f["filename"]
            r = lookup[(lane + "-snapshot", commit, path)]
            if r["absent"]:
                snapshots[lane][path] = {"exists": False, "file": empty, "bytes": b"", "blob": None, "mode": None}
            else:
                data = blobs[r["entry"]["sha"]]
                p = write("snapshots/" + lane + "/" + path, data)
                snapshots[lane][path] = {"exists": True, "file": p, "bytes": data, "blob": r["entry"]["sha"], "mode": r["entry"]["mode"]}

    merge_rows, final_files = [], []
    for f in INPUT["compare"]["files"]:
        path = f["filename"]
        base, ours, theirs = [snapshots[lane][path] for lane in ("base", "ours", "theirs")]
        command = ["git", "-c", "merge.conflictStyle=merge", "merge-file", "-p", "-L", "ours775", "-L", "base073", "-L", "theirs3a39", str(ours["file"]), str(base["file"]), str(theirs["file"])]
        run = subprocess.run(command, capture_output=True)
        assert 0 <= run.returncode <= 127, (path, run.returncode, run.stderr)
        write("merge-file-raw/" + path, run.stdout)
        write("merge-file-stderr/" + path + ".txt", run.stderr)
        resolution = "original git merge-file output"
        data = run.stdout
        if run.returncode:
            assert path == PTY and run.returncode == 1
            single = b"        match unsafe { WaitForSingleObject(AsRawHandle::as_raw_handle(&self.child).cast(), wait_ms) } {\n"
            wrapped = b"        match unsafe {\n            WaitForSingleObject(AsRawHandle::as_raw_handle(&self.child).cast(), wait_ms)\n        } {\n"
            assert theirs["bytes"].count(single) == 1 and theirs["bytes"].replace(single, wrapped) == ours["bytes"]
            data = ours["bytes"]
            resolution = "Keep exact reviewed ours775 postimage: theirs3a39 differs only by the single verified match-header line wrapping; all three AsRawHandle calls, waits, access rights and deadlines are identical. Raw conflict is retained separately."
        elif ours["bytes"] == theirs["bytes"]:
            assert data == ours["bytes"]
            resolution = "Both branches already contain exactly the same Git blob."
        elif ours["bytes"] == base["bytes"]:
            assert data == theirs["bytes"]
            resolution = "Ours equals base; preserve exact concurrent upstream postimage."
        assert b"<<<<<<< ours775" not in data and b">>>>>>> theirs3a39" not in data
        mode = theirs["mode"]
        result = {"path": path, "mode": mode, "blob": object_id("blob", data), "sha256": sha(data), "content": data.decode(), "gitMergeFileExitCode": run.returncode, "resolution": resolution}
        final_files.append(result)
        write("resolved-postimages/" + path, data)
        diff = "".join(difflib.unified_diff(theirs["bytes"].decode().splitlines(True), data.decode().splitlines(True), fromfile="theirs3a39/" + path, tofile="resolved/" + path))
        write("resolved-vs-upstream/" + path + ".patch", diff)
        merge_rows.append({"path": path, "baseBlob": base["blob"], "oursBlob": ours["blob"], "theirsBlob": theirs["blob"], "resolvedBlob": result["blob"], "gitMergeFileExitCode": run.returncode, "rawMergeSha256": sha(run.stdout), "resolution": resolution, "mergedEqualsTheirs": data == theirs["bytes"], "mergedEqualsOurs": data == ours["bytes"]})

    assert len(final_files) == 9
    assert sum(r["gitMergeFileExitCode"] != 0 for r in merge_rows) <= 1
    # Upstream CI, both new audit scripts, and OpenSSH diagnostics must survive byte-for-byte.
    preserved = [p for p in snapshots["theirs"] if p.startswith(".github/") or p.endswith("openssh_windows.rs")]
    for path in preserved:
        assert next(r for r in merge_rows if r["path"] == path)["mergedEqualsTheirs"]
    bundle = {"schemaVersion": 1, "repository": INPUT["repository"], "baseCommit": INPUT["base"]["sha"], "baseTree": INPUT["base"]["tree"]["sha"], "oursCommit": INPUT["ours"]["sha"], "oursTree": INPUT["ours"]["tree"]["sha"], "headCommit": parent_sha, "headTree": parent_tree, "commits": commits, "resolvedFiles": final_files, "inputSha256": sha((ROOT / "inputs.json").read_bytes()), "reviewBoundary": "Local immutable-input, Git-object and three-way source audit only. No remote repository/ref/source mutation, compilation, native test, platform or production qualification is performed."}
    p = save("native-import-bundle.json", bundle)
    compressed = write("native-import-bundle.json.z", zlib.compress(p.read_bytes(), 9))
    report = {"baseCommit": bundle["baseCommit"], "oursCommit": bundle["oursCommit"], "headCommit": parent_sha, "rawCommitCount": len(commits), "exactTreeCount": len(commits), "verifiedApiTreeNodes": len(trees), "verifiedUniqueBlobs": len(blobs), "commits": raw_reports, "threeWayFiles": merge_rows, "upstreamBytesPreservedExactly": preserved, "bundle": {"path": str(p.relative_to(WORK)), "bytes": p.stat().st_size, "sha256": sha(p.read_bytes())}, "compressedBundle": {"path": str(compressed.relative_to(WORK)), "bytes": compressed.stat().st_size, "sha256": sha(compressed.read_bytes())}, "remoteMutationsPerformed": False}
    save("SOURCE-MERGE-AUDIT.json", report)
    save("snapshot-path-bindings.json", [{k: v for k, v in r.items()} for r in resolved])
    print(json.dumps({"commits": len(commits), "exactTrees": len(commits), "treeNodes": len(trees), "blobs": len(blobs), "conflicts": [r["path"] for r in merge_rows if r["gitMergeFileExitCode"]], "bundle": report["bundle"], "compressedBundle": report["compressedBundle"]}))


if __name__ == "__main__":
    main()
