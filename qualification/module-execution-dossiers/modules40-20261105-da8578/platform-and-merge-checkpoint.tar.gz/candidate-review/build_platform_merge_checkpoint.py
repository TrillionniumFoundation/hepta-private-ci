#!/usr/bin/env python3
"""Archive fixed read-only platform evidence and source-merge review inputs."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import re
import tarfile

WORK = Path(__file__).resolve().parent.parent
ROOTS = [WORK / "candidate-review" / s for s in ["platform-f581", "platform-bb55", "platform-797", "platform-current-audit", "platform-865", "upstream-3a39"]]
ADDITIONAL = [WORK / "integration/upstream-3a39-native-export.json", WORK / "integration/rebuild-canonical-commits.py", Path(__file__).resolve()]
ARCHIVE = WORK / "candidate-review/platform-and-merge-checkpoint.tar.gz"
MANIFEST = WORK / "candidate-review/platform-and-merge-checkpoint.manifest.json"
RECEIPT = WORK / "candidate-review/platform-and-merge-checkpoint.receipt.json"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    assert not ARCHIVE.exists() and not MANIFEST.exists() and not RECEIPT.exists(), "Create-only checkpoint"
    baseline = json.loads((WORK / "candidate-review/platform-current-audit/prior-platform-preservation-baseline.json").read_bytes())
    for row in baseline["files"]:
        data = (WORK / row["path"]).read_bytes()
        assert len(data) == row["bytes"] and sha(data) == row["sha256"], row["path"]
    files = []
    for root in ROOTS:
        assert root.is_dir()
        for path in root.rglob("*"):
            if "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            assert not path.is_symlink(), path
            if path.is_file():
                files.append(path)
    files = sorted(set(files + ADDITIONAL))
    patterns = {
        "private_key_header": re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
        "github_token": re.compile(rb"(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})"),
        "aws_access_key": re.compile(rb"AKIA[0-9A-Z]{16}"),
        "signed_query": re.compile(rb"[?&]sig=[A-Za-z0-9%+/=]{25,}"),
    }
    contents = {}
    manifest_rows = []
    for path in files:
        data = path.read_bytes()
        for label, pattern in patterns.items():
            assert not pattern.search(data), (str(path), label)
        name = str(path.relative_to(WORK))
        contents[name] = data
        manifest_rows.append({"path": name, "bytes": len(data), "sha256": sha(data)})
    manifest = {
        "schemaVersion": 1,
        "createdAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "kind": "local archival of retained read-only GitHub platform observations and fixed source merge audit",
        "sourceCandidates": ["f5813506b49eb05efad00f203b9362195875892c", "bb55b0d7d263c396ec504c45393d938c3428dae5", "797116d61cf422c26274ffef31297dce84a53a80", "775bf555b0a7faf6eed17627acb0d0433294b737", "3a39c799a3f776b0aeedfce350341d865d3cc1c4", "8658210499706130788c216ff14fd342809b45a4"],
        "finalObservedSourceTree": "6bc86196d10cf83b010f9917e5e9cb471b5f6b68",
        "prior94FilesByteIdentical": True,
        "credentialPatternScan": {"patterns": list(patterns), "matches": 0, "boundary": "Limited local pattern check; no credential or signed download URL was added to the evidence."},
        "excluded": ["Python __pycache__ directories and .pyc transient files"],
        "claimBoundary": ["Historical candidate observations remain historical.", "GitHub reads are finite and non-atomic across APIs.", "Native source merge and formatting do not constitute native behavior qualification.", "The 865 platform snapshot has 37 queued, one setup-stage running, and one skipped job; no platform result is promoted.", "All 40 production flags false; public topology DENY_ALL.", "No runtime archive job, source, ref, CI cancellation or rerun was performed by this archival script."],
        "files": manifest_rows,
    }
    manifest_bytes = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode()
    MANIFEST.write_bytes(manifest_bytes)
    contents["MANIFEST.json"] = manifest_bytes
    with ARCHIVE.open("xb") as output:
        with gzip.GzipFile(filename="", mode="wb", compresslevel=9, fileobj=output, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w|") as archive:
                for name, data in sorted(contents.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    archive.addfile(info, io.BytesIO(data))
    with tarfile.open(ARCHIVE, "r:gz") as archive:
        members = archive.getmembers()
        assert len(members) == len(contents)
        for member in members:
            assert member.isfile() and member.name in contents
            assert archive.extractfile(member).read() == contents[member.name]
    for row in manifest_rows:
        data = (WORK / row["path"]).read_bytes()
        assert len(data) == row["bytes"] and sha(data) == row["sha256"], row["path"]
    raw = ARCHIVE.read_bytes()
    receipt = {"archive": str(ARCHIVE), "bytes": len(raw), "sha256": sha(raw), "manifest": str(MANIFEST), "manifestSha256": sha(manifest_bytes),
               "listedFiles": len(manifest_rows), "archiveMembers": len(contents), "uncompressedListedBytes": sum(r["bytes"] for r in manifest_rows),
               "allArchiveMembersByteVerified": True, "sourceFilesUnchangedAfterArchive": True, "credentialPatternMatches": 0,
               "remoteMutationsPerformed": False, "nativeArchiveLaunchUnknownNotRetried": True}
    RECEIPT.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
