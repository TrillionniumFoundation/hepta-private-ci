#!/usr/bin/env python3
"""Summarize retained read-only GitHub snapshots without promoting evidence."""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = "f5813506b49eb05efad00f203b9362195875892c"
TREE = "00d62de1c2f6ac8a229d23ce9d8e1b9f34b333df"


def read(path: Path):
    return json.loads(path.read_text())


def main():
    runs = {}
    job_sets = {}
    first_failures = {}
    polls = []
    for poll in sorted(ROOT.glob("poll-*")):
        observation = poll / "observation.json"
        if not observation.exists():
            continue
        observed = read(observation)["observedAtUtc"]
        polls.append({"directory": poll.name, "observedAtUtc": observed})
        run_file = poll / "runs.raw.json"
        if run_file.exists():
            for run in read(run_file).get("workflow_runs", []):
                assert run["head_sha"] == SOURCE, run["id"]
                runs[run["id"]] = (run, poll.name, observed)
        for job_file in sorted(poll.glob("jobs-*.raw.json")):
            run_id = int(job_file.name.split("-")[1].split(".")[0])
            data = read(job_file)
            jobs = data.get("jobs", [])
            for job in jobs:
                assert job["head_sha"] == SOURCE, job["id"]
                bad_steps = [s for s in job.get("steps", []) if s.get("conclusion") == "failure"]
                if job.get("conclusion") == "failure" or bad_steps:
                    first_failures.setdefault(job["id"], {
                        "runId": run_id,
                        "jobId": job["id"],
                        "name": job["name"],
                        "firstObservedAtUtc": observed,
                        "jobCompletedAt": job.get("completed_at"),
                        "failedSteps": bad_steps,
                        "rawEvidence": str(job_file.relative_to(ROOT)),
                    })
            job_sets[run_id] = (data, poll.name)
    result = {
        "kind": "read_only_platform_observation",
        "sourceCandidate": SOURCE,
        "sourceTree": TREE,
        "polls": polls,
        "evidenceBoundary": "Run/job head_sha identifies the source associated with the run. A base-merge lane's executed commit/tree must be established separately from its logs or receipts; no live merge identity is promoted here.",
        "mutationsPerformed": False,
        "runs": [],
        "firstObservedFailedJobs": list(first_failures.values()),
    }
    for run_id, (run, poll, observed) in sorted(runs.items()):
        jobs_data, jobs_poll = job_sets.get(run_id, ({}, None))
        jobs = jobs_data.get("jobs", [])
        result["runs"].append({
            "id": run_id,
            "name": run["name"],
            "workflowPath": run["path"],
            "event": run["event"],
            "reportedHeadSha": run["head_sha"],
            "reportedHeadBranch": run["head_branch"],
            "eventBaseFromRunApi": [{"number": p["number"], "base": p["base"]["sha"], "head": p["head"]["sha"]} for p in run.get("pull_requests", [])],
            "runAttempt": run["run_attempt"],
            "runStatus": run["status"],
            "runConclusion": run.get("conclusion"),
            "observedAtUtc": observed,
            "runEvidence": f"{poll}/runs.raw.json",
            "jobEvidence": f"{jobs_poll}/jobs-{run_id}.raw.json" if jobs_poll else None,
            "jobCountReported": jobs_data.get("total_count"),
            "jobCountRetained": len(jobs) if jobs_poll else None,
            "jobStatusCounts": dict(Counter(j.get("conclusion") or j["status"] for j in jobs)),
            "terminalJobs": [{"id": j["id"], "name": j["name"], "conclusion": j.get("conclusion"), "completedAt": j.get("completed_at")} for j in jobs if j["status"] == "completed"],
            "executedMergeCommit": None,
            "executedMergeTree": None,
        })
    (ROOT / "summary.latest.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    files = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path.name == "artifact-manifest.json":
            continue
        content = path.read_bytes()
        files.append({"path": str(path.relative_to(ROOT)), "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()})
    (ROOT / "artifact-manifest.json").write_text(json.dumps({"candidate": SOURCE, "files": files}, indent=2) + "\n")
    print(json.dumps({"polls": len(polls), "runs": len(runs), "firstObservedFailedJobs": list(first_failures), "summary": str(ROOT / "summary.latest.json")}))


if __name__ == "__main__":
    main()
