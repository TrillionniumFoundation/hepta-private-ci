#!/usr/bin/env python3
"""Read retained GitHub evidence, check bindings, and summarize finite snapshots."""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[1]
REPO = "TrillionniumFoundation/hepta-private-ci"
CANDIDATES = {
    "bb55": ("bb55b0d7d263c396ec504c45393d938c3428dae5", "19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1", "poll-0006"),
    "797": ("797116d61cf422c26274ffef31297dce84a53a80", "67ce024db1679aa6cd301856ba3a694ea18bc4b6", "poll-0002"),
}
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def file_info(path):
    return {"path": str(path.relative_to(WORK)), "bytes": path.stat().st_size, "sha256": sha(path)}


def save(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def text(job):
    return ANSI.sub("", (ROOT / "logs" / f"job-{job}.log").read_text(encoding="utf-8"))


def checkout(job):
    lines = text(job).splitlines()
    matches = []
    for i, line in enumerate(lines[:-1]):
        if "[command]" in line and "log -1 --format=%H" in line:
            match = re.fullmatch(r"\S+ ([0-9a-f]{40})", lines[i + 1])
            assert match, (job, lines[i + 1])
            matches.append({"sha": match[1], "commandLine": i + 1, "resultLine": i + 2})
    assert len(matches) == 1, (job, matches)
    return matches[0]


def main():
    prior = read(ROOT / "prior-platform-preservation-baseline.json")
    for row in prior["files"]:
        p = WORK / row["path"]
        assert p.stat().st_size == row["bytes"] and sha(p) == row["sha256"], p
    save("prior-platform-preservation-validation.json", {"checkedFiles": len(prior["files"]), "allBytesUnchanged": True, "baselineSha256": sha(ROOT / "prior-platform-preservation-baseline.json")})

    snapshots = {}
    jobs = {}
    for name, (head, tree, poll) in CANDIDATES.items():
        base = WORK / "candidate-review" / f"platform-{name}"
        source = read(base / "candidate-source-commit.raw.json")
        assert source["sha"] == head and source["tree"]["sha"] == tree
        observation = read(base / poll / "observation.json")
        runs = read(base / poll / "runs.raw.json")
        assert len(runs["workflow_runs"]) == runs["total_count"] == 8
        rows = []
        for run in runs["workflow_runs"]:
            assert run["head_sha"] == head
            p = base / poll / f"jobs-{run['id']}.raw.json"
            data = read(p)
            assert data["total_count"] == len(data["jobs"])
            for job in data["jobs"]:
                assert job["head_sha"] == head and job["run_id"] == run["id"]
                jobs[job["id"]] = job
            rows.append({
                "runId": run["id"], "name": run["name"], "event": run["event"],
                "status": run["status"], "conclusion": run.get("conclusion"),
                "attempt": run["run_attempt"], "url": run["html_url"],
                "jobCounts": dict(Counter(j.get("conclusion") or j["status"] for j in data["jobs"])),
                "jobs": [{"id": j["id"], "name": j["name"], "status": j["status"], "conclusion": j.get("conclusion"),
                          "runnerId": j.get("runner_id"), "startedAt": j.get("started_at"), "completedAt": j.get("completed_at"),
                          "failedSteps": [s for s in j.get("steps", []) if s.get("conclusion") == "failure"]} for j in data["jobs"]],
                "rawJobs": file_info(p),
            })
        snapshots[name] = {"sourceHead": head, "sourceTree": tree, "poll": poll, "observation": observation, "runs": rows}

    spelling_job = 127372827355
    spelling_commit = read(ROOT / "logs" / f"job-{spelling_job}.executed-commit.raw.json")
    assert checkout(spelling_job)["sha"] == spelling_commit["sha"] == "2135d80407e147714c2eae5cc1ffa0a7d9f224c2"
    assert spelling_commit["tree"]["sha"] == CANDIDATES["797"][1]
    assert [p["sha"] for p in spelling_commit["parents"]] == ["07378034e060f23259bc99c7367f12b1284140f3", CANDIDATES["797"][0]]
    assert jobs[spelling_job]["conclusion"] == "success"
    spelling_text = text(spelling_job)
    for expected in ["Successfully installed codespell-2.4.3", "Resulting CLI options  --ignore-words .codespellignore --skip ./.git", "Codespell found no problems"]:
        assert expected in spelling_text
    spelling = {"jobId": spelling_job, "runId": 42063954082, "sourceHead": CANDIDATES["797"][0],
                "executedCommit": spelling_commit["sha"], "executedTree": spelling_commit["tree"]["sha"],
                "orderedParents": [p["sha"] for p in spelling_commit["parents"]], "checkoutEvidence": checkout(spelling_job),
                "conclusion": "success", "codespellVersion": "2.4.3", "cliOptions": "--ignore-words .codespellignore --skip ./.git",
                "scope": "Original Codespell on the actual PR merge; same tree as 797, distinct commit identity.",
                "log": file_info(ROOT / "logs" / f"job-{spelling_job}.log")}

    failures = []
    for job_id, kind, code, expected_count in [(127372825575, "Windows ARM64 Clippy method resolution", "E0034", 3), (127372826413, "Windows x64 Clippy macro resolution", "E0659", 8), (127372825550, "Windows Bazel bootstrap execution", None, None)]:
        log = text(job_id)
        assert checkout(job_id)["sha"] == CANDIDATES["797"][0]
        count = len(re.findall(r"error\[" + code + r"\]", log)) if code else None
        if code:
            assert count == expected_count and CANDIDATES["797"][1] in log
        else:
            assert "bootstrap_process_wrapper.exe" in log and "not found in $PATH: No such file or directory" in log
        failures.append({"jobId": job_id, "runId": 42063953259, "kind": kind, "errorCode": code, "errorCount": count,
                         "jobStatusAtSnapshot": jobs[job_id]["status"], "jobConclusionAtSnapshot": jobs[job_id].get("conclusion"),
                         "failedSteps": [s for s in jobs[job_id]["steps"] if s.get("conclusion") == "failure"],
                         "sourceHead": CANDIDATES["797"][0], "sourceTree": CANDIDATES["797"][1],
                         "treeBinding": "native log and immutable commit API" if code else "immutable checkout commit API; no separate native tree print asserted",
                         "checkoutEvidence": checkout(job_id), "log": file_info(ROOT / "logs" / f"job-{job_id}.log")})

    private_job = 127354029766
    art = ROOT / "bb55-private-state-artifact"
    manifest = read(art / "manifest.json")
    assert manifest["source_head"] == checkout(private_job)["sha"] == CANDIDATES["bb55"][0]
    assert manifest["source_tree"] == CANDIDATES["bb55"][1]
    assert manifest["qualified"] is True and manifest["restored"] is True
    assert jobs[private_job]["conclusion"] == "success"
    zipfile = ROOT / "bb55-windows-private-state-acquisition.zip"
    assert zipfile.stat().st_size == 13522
    assert sha(zipfile) == "26c0fffcf8315b9e9e8252430fe0831d431e07e8612ee82975c388834dee13e4"
    assert sha(ROOT / "source" / "private_state_windows_directory.rs") == manifest["production_sha256"]
    assert (ROOT / "source" / "private_state_windows_directory.rs").read_bytes() == (art / "positive.rs").read_bytes()
    for source in read(ROOT / "source" / "api-source-bindings.json")["files"]:
        data = (ROOT / source["localPath"]).read_bytes()
        assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == source["blob"]
    for lane in manifest["lanes"]:
        name = lane["lane"]
        assert sha(art / (name + ".log")) == lane["log_sha256"]
        assert sha(art / (name + ".rs")) == lane["production_sha256"]
        if "patch_sha256" in lane:
            assert sha(art / (name + ".patch")) == lane["patch_sha256"]
    assert [l["exit_code"] for l in manifest["lanes"]] == [0, 1, 1]
    log = text(private_job)
    passed = re.findall(r"PASS \[[^\]]+\] (\S+) (\S+)", log)
    assert len(passed) == len(set(passed)) == 33
    summaries = re.findall(r"Summary \[[^\]]+\] ([^\r\n]+)", log)
    assert summaries == ["15 tests run: 15 passed, 5 skipped", "2 tests run: 2 passed, 26 skipped", "3 tests run: 3 passed, 147 skipped", "2 tests run: 2 passed, 148 skipped", "11 tests run: 11 passed, 187 skipped"]
    private = {"jobId": private_job, "runId": 42058691813, "sourceHead": manifest["source_head"], "sourceTree": manifest["source_tree"],
               "conclusion": "success", "checkoutEvidence": checkout(private_job), "host": "x86_64-pc-windows-msvc", "rustc": manifest["rustc"],
               "scopeSummaries": summaries, "uniquePassingTests": [{"package": p, "name": n} for p, n in passed],
               "laneDetails": manifest["lanes"], "artifact": file_info(zipfile), "artifactId": 13432476348,
               "artifactDigestMatchesGithubApi": True, "allEmbeddedFileHashesMatch": True, "positiveSourceBytesMatchImmutableGithubBlob": True,
               "qualificationSourceRestored": True, "log": file_info(ROOT / "logs" / f"job-{private_job}.log"),
               "claimBoundary": "Only this fixed bb55 Windows private-state security scope. Five filtered scopes; directory positive controls overlap two tests already in the first scope. No full Windows, platform, production, deployment, or successor qualification is claimed."}

    index = {"schemaVersion": 1, "readOnlyObservation": True, "remoteMutationsPerformed": False, "crossApiReadsAreAtomic": False,
             "snapshots": snapshots, "codespell797": spelling, "failures797": failures, "windowsPrivateStateBb55": private,
             "priorFilesVerifiedUnchanged": len(prior["files"]),
             "claimBoundary": ["Queued runner 0 is unexecuted.", "Failed step inside running or cancelled job is not rewritten as a terminal job failure.", "Cancelled jobs are API observations; no cause or actor is inferred and this agent cancelled nothing.", "Historical results are not transferred to later candidates.", "All 40 production flags remain false; public topology remains DENY_ALL.", "Windows Bazel bootstrap execution remains an open platform gate."]}
    save("PLATFORM-EVIDENCE-INDEX.json", index)
    print(json.dumps({"sourceCandidates": list(snapshots), "priorUnchanged": len(prior["files"]), "codespell797": "success", "privateStateBb55UniquePasses": len(passed), "indexSha256": sha(ROOT / "PLATFORM-EVIDENCE-INDEX.json")}))


if __name__ == "__main__":
    main()
