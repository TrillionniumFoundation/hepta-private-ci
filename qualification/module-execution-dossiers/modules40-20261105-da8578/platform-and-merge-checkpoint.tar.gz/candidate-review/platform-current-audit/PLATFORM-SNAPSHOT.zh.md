# 固定候选的平台证据快照

这份快照补齐 `bb55b0d7` 与 `797116d6` 的原始 GitHub Actions 状态、实际检出身份、日志和 Windows 专用安全产物。查询只读，未重跑、取消任务或移动任何分支。各 API 查询独立进行，不构成跨接口的原子快照；本轮观察始于 **2026-11-05 16:48:29 UTC**。后继 `86582104` 的独立快照另存 `platform-865/`。

## 状态与执行范围

| 工作流 | bb55 快照 | 797 快照 |
| --- | --- | --- |
| rust-ci-full | 18 queued、1 in_progress、4 failure、2 cancelled、1 skipped | 17 queued、5 in_progress、2 failure |
| blocking-ci | 2 queued；Codespell failure | 2 queued；Codespell success |
| Windows 私有状态安全专用 | success | in_progress |
| Windows 原始回归 | in_progress | in_progress |
| Architecture convergence | 2 queued | 2 queued |
| Rust UI foundation | 5 queued | 5 queued |
| v8-canary | metadata success，2 jobs skipped | metadata success，2 jobs skipped |
| Production HOS2 proposal | skipped | skipped |

`queued` 且 runner ID 为 0 的任务尚未执行。`cancelled` 是 GitHub API 返回的状态，本审核没有推断取消原因或执行者。bb55 ARM64 release 的 Clippy step 曾失败，但最终 job 状态是 cancelled；797 x64 Clippy 的 step 已失败，而本快照时 job 仍在运行。这两种情况都保留原始层次，未改写成另一种终态。

## 797 Codespell 的实际执行身份

[Codespell job 127372827355](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42063954082/job/127372827355) 成功。完整日志确认工具版本 **2.4.3**，原参数为 `--ignore-words .codespellignore --skip ./.git`。

实际 checkout 是 PR merge `2135d80407e147714c2eae5cc1ffa0a7d9f224c2`，不是把 source-head 名称当成执行身份。该 immutable commit 的 tree 为 `67ce024db1679aa6cd301856ba3a694ea18bc4b6`，有序 parents 为 `07378034e060f23259bc99c7367f12b1284140f3`、`797116d61cf422c26274ffef31297dce84a53a80`。它与 source-head 的 tree 相同，但 commit 身份不同。

## 797 上实际复现的 Windows 阻塞

| Job | 原始结果 | 身份与边界 |
| --- | --- | --- |
| 127372825575，ARM64 Clippy | 3 个 `E0034`，`as_raw_handle` 方法歧义 | 日志直接输出 HEAD 797 和 tree 67ce；job failure |
| 127372826413，x64 Clippy | 8 个 `E0659`，`assert_eq` 宏歧义 | 日志直接输出 HEAD 797 和 tree 67ce；step failure，job 在本快照仍 in_progress |
| 127372825550，Windows Bazel | `bootstrap_process_wrapper.exe` 执行报不存在 | checkout 明确为 797；tree 由 immutable commit API 绑定；job failure |

这两类编译引用问题的后继修复不改变原失败结果。Bazel 的执行平台问题仍是开放门槛；本快照没有取得远程执行器的完整物理身份或 CAS 证据，不能把推断当作已证实的平台根因。

## bb55 Windows 私有状态安全专用结果

[Job 127354029766](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/42058691813/job/127354029766) 的实际 checkout 是 `bb55b0d7d263c396ec504c45393d938c3428dae5`。下载的 artifact ID 为 `13432476348`，ZIP 13,522 bytes，SHA-256 `26c0fffcf8315b9e9e8252430fe0831d431e07e8612ee82975c388834dee13e4`，与 GitHub artifact digest 一致。

Artifact manifest 明确绑定 source-head bb55 与 tree `19116ccdf440a1cddc2a29f3d709ebe1a3cd06c1`。其正例源码与该提交上的 immutable Git blob 完全相同，所有内嵌源码、日志、失效样本 patch 的哈希均已重新验证。

| 原始过滤范围 | 通过 | 跳过 |
| --- | ---: | ---: |
| Windows private file / ACL / reparse / hardlink | 15 | 5 |
| Prompt Registry Windows durable owner | 2 | 26 |
| Final-use Windows durable stores | 3 | 147 |
| Authority-lease Windows durable stores | 2 | 148 |
| Agentd Prompt Runtime integration / reopen | 11 | 187 |

上述五个范围有 **33 个不同的通过测试**。目录获取的两项攻击正例随后还被单独重复运行，不重复计入 33。两个故意破坏保护的对照分别返回 exit 1，原测试正确捕获“先创建后拒绝”与“路径替换导致重定向”；源码恢复状态及最终 `git diff --exit-code` 均保留在日志和 manifest 中。

这个结果只覆盖固定 bb55 的 Windows 私有状态安全专用范围，不能推广为全部 Windows CI 通过，也不能转给 797、775、865 或之后的合并候选。

## 审计材料

- `PLATFORM-EVIDENCE-INDEX.json`：完整身份、任务状态、测试名称、日志哈希与 artifact 校验。
- `audit_platform_snapshot.py`：本地可重复审计，不调用远程执行。
- `prior-platform-preservation-validation.json`：原有 **94 个文件**逐字节保留。
- `logs/`：完整原始 decoded UTF-8 日志，保留 BOM 与 CRLF。
- `bb55-private-state-artifact/`：GitHub ZIP 的原始内嵌文件。

全部 40 个生产开关继续为 false，公共拓扑继续为 DENY_ALL。本快照不授予生产、真实部署或后继提交的资格。
