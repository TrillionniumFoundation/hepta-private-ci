#!/usr/bin/env python3
"""Validate and summarize the finite 865 read-only platform snapshot."""
from pathlib import Path
from collections import Counter
import hashlib
import json

ROOT = Path(__file__).resolve().parent
HEAD = "8658210499706130788c216ff14fd342809b45a4"
TREE = "6bc86196d10cf83b010f9917e5e9cb471b5f6b68"
BASE = "3a39c799a3f776b0aeedfce350341d865d3cc1c4"


def read(path):
    return json.loads((ROOT / path).read_bytes())


def main():
    source = read("candidate-source-commit.raw.json")
    pr = read("observed-pr.raw.json")
    merge = read("observed-pr-merge-commit.raw.json")
    observation = read("poll-0001/observation.json")
    assert source["sha"] == pr["head"]["sha"] == HEAD
    assert source["tree"]["sha"] == TREE
    assert pr["base"]["sha"] == BASE
    assert [p["sha"] for p in source["parents"]] == ["775bf555b0a7faf6eed17627acb0d0433294b737", BASE]
    assert merge["sha"] == pr["merge_commit_sha"] == "d92254c4bcf6635778cf7941a27659fad3e6b3f8"
    assert merge["tree"]["sha"] == TREE
    assert [p["sha"] for p in merge["parents"]] == [BASE, HEAD]
    runs = read("poll-0001/runs.raw.json")
    assert len(runs["workflow_runs"]) == runs["total_count"] == 8
    rows, alljobs = [], []
    for run in runs["workflow_runs"]:
        assert run["head_sha"] == HEAD
        jobs = read(f"poll-0001/jobs-{run['id']}.raw.json")
        assert jobs["total_count"] == len(jobs["jobs"])
        for job in jobs["jobs"]:
            assert job["head_sha"] == HEAD and job["run_id"] == run["id"]
            if job["status"] == "queued":
                assert job["runner_id"] in (0, None)
            assert not [s for s in job["steps"] if s.get("conclusion") == "failure"]
        alljobs.extend(jobs["jobs"])
        rows.append({"id": run["id"], "name": run["name"], "event": run["event"], "status": run["status"],
                     "conclusion": run.get("conclusion"), "runAttempt": run["run_attempt"], "url": run["html_url"],
                     "jobCount": len(jobs["jobs"]), "jobStatusCounts": dict(Counter(j.get("conclusion") or j["status"] for j in jobs["jobs"])),
                     "jobs": [{"id": j["id"], "name": j["name"], "status": j["status"], "conclusion": j.get("conclusion"), "runnerId": j["runner_id"],
                               "currentSteps": [s for s in j["steps"] if s["status"] == "in_progress"]} for j in jobs["jobs"]]})
    result = {"sourceCandidate": HEAD, "sourceTree": TREE, "orderedSourceParents": [p["sha"] for p in source["parents"]],
              "observation": observation, "readOnly": True, "remoteMutationsPerformed": False, "runs": rows,
              "allJobStatusCounts": dict(Counter(j.get("conclusion") or j["status"] for j in alljobs)),
              "queuedRunnerIds": {"zero": sum(j["status"] == "queued" and j["runner_id"] == 0 for j in alljobs), "null": sum(j["status"] == "queued" and j["runner_id"] is None for j in alljobs)},
              "prospectiveMerge": {"commit": merge["sha"], "tree": merge["tree"]["sha"], "orderedParents": [p["sha"] for p in merge["parents"]], "executionObserved": False},
              "boundary": "One finite non-atomic API observation. Queued runner0/null is unexecuted; Set up job is not compile/test completion. No platform pass/fail conclusion exists for this new candidate at this snapshot; HOS proposal is skipped. Historical successes/failures are not transferred. All 40 production flags false; public topology DENY_ALL."}
    path = ROOT / "summary.snapshot.json"
    path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"summarySha256": hashlib.sha256(path.read_bytes()).hexdigest(), "counts": result["allJobStatusCounts"], "queuedRunnerIds": result["queuedRunnerIds"]}))


if __name__ == "__main__":
    main()
