#!/usr/bin/env python3
"""Rebuild unsigned Git commit bytes from downloaded GitHub Git-commit metadata.

Offline only: writes JSON artifacts, never a Git repository, refs or shallow file.
Accepts a REST object, a list of REST objects, or {"commits": [REST objects]}.
The target SHA is mandatory; unmatched objects fail without approximate output.
"""
import argparse
import base64
import calendar
import datetime
import hashlib
import json
from pathlib import Path
import re

SHA = re.compile(r"[0-9a-f]{40}\Z")

def require_sha(value):
    if not isinstance(value, str) or not SHA.fullmatch(value):
        raise ValueError("expected literal SHA-1")
    return value

def git_id(raw):
    return hashlib.sha1(b"commit " + str(len(raw)).encode() + b"\0" + raw).hexdigest()

def ident(value):
    name, email = value["name"], value["email"]
    if any(c in name + email for c in "\r\n\0<>"):
        raise ValueError("unsupported identity delimiters")
    instant = datetime.datetime.fromisoformat(value["date"].replace("Z", "+00:00"))
    if instant.tzinfo is None or instant.microsecond:
        raise ValueError("Git identity requires timezone-aware whole seconds")
    stamp = calendar.timegm(instant.astimezone(datetime.timezone.utc).timetuple())
    return f"{name} <{email}> {stamp} ".encode(), instant.strftime("%z")

def offsets(preferred):
    # GitHub normalizes API dates to UTC; the commit retains its original offset.
    result = list(dict.fromkeys([*preferred, "+0000", "-0500", "-0000"]))
    # First common quarter-hour offsets, then all ordinary ISO minute offsets.
    for stride in (15, 1):
        for minutes in range(0, 24 * 60, stride):
            hours, minute = divmod(minutes, 60)
            for sign in ("+", "-"):
                value = f"{sign}{hours:02d}{minute:02d}"
                if value not in result:
                    result.append(value)
    return [item.encode() for item in result]

def rebuild(meta):
    expected = require_sha(meta["sha"])
    tree = require_sha(meta["tree"]["sha"])
    parents = [require_sha(parent["sha"]) for parent in meta["parents"]]
    verification = meta.get("verification") or {}
    if verification.get("signature") or verification.get("reason") not in (None, "unsigned"):
        raise ValueError(f"{expected}: signed/nonstandard commit needs original raw headers")
    author, author_hint = ident(meta["author"])
    committer, committer_hint = ident(meta["committer"])
    prefix = ("tree " + tree + "\n" + "".join("parent " + p + "\n" for p in parents)).encode()
    prefix += b"author " + author
    middle = b"\ncommitter " + committer
    message = meta["message"].encode("utf-8")
    messages = [message]
    # Accept a changed trailing LF only when the complete object matches its SHA.
    if not message.endswith(b"\n"):
        messages.append(message + b"\n")
    else:
        messages.append(message[:-1])
    zones = offsets([author_hint, committer_hint])
    pairs_first = list(dict.fromkeys([
        (author_hint.encode(), committer_hint.encode()),
        (b"-0500", b"-0500"),
        (b"+0000", b"+0000"),
        *[(zone, zone) for zone in zones],
    ]))
    attempts = 0
    for suffix_message in messages:
        suffix = b"\n\n" + suffix_message
        for author_zone, committer_zone in pairs_first:
            attempts += 1
            raw = prefix + author_zone + middle + committer_zone + suffix
            if git_id(raw) == expected:
                return raw, {
                    "sha": expected, "tree": tree, "parents": parents,
                    "author_offset": author_zone.decode(),
                    "committer_offset": committer_zone.decode(),
                    "message_trailing_lf": suffix_message.endswith(b"\n"),
                    "raw_bytes": len(raw), "hash_attempts": attempts,
                }
    # Different author/committer offsets are also valid. Metadata identities,
    # timestamps, parent ordering and message bytes remain fixed throughout.
    for suffix_message in messages:
        suffix = b"\n\n" + suffix_message
        length = len(prefix) + 5 + len(middle) + 5 + len(suffix)
        object_header = b"commit " + str(length).encode() + b"\0"
        for author_zone in zones:
            seeded = hashlib.sha1(object_header + prefix + author_zone + middle)
            for committer_zone in zones:
                attempts += 1
                trial = seeded.copy()
                trial.update(committer_zone + suffix)
                if trial.hexdigest() == expected:
                    raw = prefix + author_zone + middle + committer_zone + suffix
                    assert git_id(raw) == expected
                    return raw, {
                        "sha": expected, "tree": tree, "parents": parents,
                        "author_offset": author_zone.decode(),
                        "committer_offset": committer_zone.decode(),
                        "message_trailing_lf": suffix_message.endswith(b"\n"),
                        "raw_bytes": len(raw), "hash_attempts": attempts,
                    }
    raise ValueError(f"{expected}: no exact raw serialization; no object emitted")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--metadata", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    content = json.loads(args.metadata.read_text())
    rows = content if isinstance(content, list) else content.get("commits", [content])
    if not rows or len({row["sha"] for row in rows}) != len(rows):
        raise ValueError("metadata list must be nonempty with unique commit identities")
    objects, reports = [], []
    # Complete and verify every object before creating any output.
    for meta in rows:
        raw, report = rebuild(meta)
        objects.append({"sha": meta["sha"], "raw_base64": base64.b64encode(raw).decode("ascii")})
        reports.append(report)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({"commits": objects}, indent=2) + "\n")
    report_path = args.report or args.output.with_suffix(".verification.json")
    report_path.write_text(json.dumps({"metadata": str(args.metadata), "commits": reports, "repositoryModified": False}, indent=2) + "\n")
    print(json.dumps({"output": str(args.output), "report": str(report_path), "verified": reports}, indent=2))

if __name__ == "__main__":
    main()

