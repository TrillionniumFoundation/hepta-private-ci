from dataclasses import replace
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import platform
import subprocess
import time
import numpy as np
from hepta_pred1.models import Model
from hepta_pred1.preparation import evaluate_development_preparations
from hepta_pred1.simulator import generate_dataset

repo=Path('/workspace/scratch/d882890e1711/hepta-stage')
original=Path('/workspace/scratch/d882890e1711/s2-preparation-development')
out=Path('/workspace/scratch/d882890e1711/s2-preparation-development-v2')
prior=json.loads((original/'RESULT.json').read_text())
prior_plan=json.loads((original/'PLAN.json').read_text())
plan={
 'schema':'pred1-preparation-development-replay-plan-v2',
 'reason':'include explicit decision delay in resource reservation, elapsed time and stop utility',
 'scope':'same development samples/checkpoints; no new training or confirmation',
 'decision_time_per_queried_episode':0.25,
 'decision_time_unit':'declared simulator ticks; not host wall time',
 'decision_work_per_queried_episode':prior_plan['decision_work_per_queried_episode'],
 'original_plan_sha256':sha256((original/'PLAN.json').read_bytes()).hexdigest(),
 'original_result_sha256':sha256((original/'RESULT.json').read_bytes()).hexdigest(),
 'new_training_runs':0,'new_confirmation_runs':0,
 'panels':['same_expanded_development_resource_panel','original_generator_resource_panel'],
 'training_seeds_inherited':prior_plan['training_seeds'],
 'same_expanded_development_resource_panel':{'deadline_cycle':prior_plan['development_deadline_cycle'],'remaining_budget_cycle':prior_plan['development_remaining_budget_cycle']},
 'original_generator_resource_panel':{'deadline_support':[4.0,8.0],'remaining_budget_support':[2.0,4.0,8.0]},
 'status':'HOLD'
}
def write(path,value):
 path.write_text(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n')
if (out/'PLAN.json').exists(): raise FileExistsError('create-only replay plan')
write(out/'PLAN.json',plan)
files={str(p.relative_to(repo)):sha256(p.read_bytes()).hexdigest() for p in sorted((repo/'scripts/hepta_pred1').glob('*.py'))}
write(out/'SOURCE.json', {'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files_sha256':files,'uncommitted_new_module':True,'python':platform.python_version(),'numpy':np.__version__,'platform':platform.platform()})
source=out/'source'
source.mkdir(exist_ok=False)
for name in ('preparation.py','test_preparation.py'):
 (source/name).write_bytes((repo/'scripts/hepta_pred1'/name).read_bytes())
started=datetime.now(timezone.utc).isoformat()
wall,cpu=time.perf_counter(),time.process_time()
rows=[]
try:
 for record in prior['records']:
  seed=record['seed']
  checkpoint=original/record['checkpoint']
  if sha256(checkpoint.read_bytes()).hexdigest()!=record['checkpoint_sha256']:
   raise ValueError('original checkpoint changed')
  model=Model.load(checkpoint)
  generated=generate_dataset(prior_plan['dev_episodes'],seed,'dev',prior_plan['history_length'])
  if generated.fingerprint()!=record['generated_dev_fingerprint']:
   raise ValueError('development sample replay changed')
  expanded=replace(generated,deadline=np.resize(prior_plan['development_deadline_cycle'],len(generated.x)),remaining_budget=np.resize(prior_plan['development_remaining_budget_cycle'],len(generated.x)))
  if expanded.fingerprint()!=record['resource_panel_dev_fingerprint']:
   raise ValueError('development resource panel changed')
  for label,data in [('same_expanded_development_resource_panel',expanded),('original_generator_resource_panel',generated)]:
   report=evaluate_development_preparations(model,data,decision_work=np.full(len(data.x),plan['decision_work_per_queried_episode']),decision_time=np.full(len(data.x),plan['decision_time_per_queried_episode']))
   write(out/f'{label}-{seed}.json',report)
   row={'seed':seed,'panel':label,'checkpoint_sha256':record['checkpoint_sha256'],'dataset_fingerprint':data.fingerprint(),'arms':{name:{k:v for k,v in arm.items() if k!='per_episode'} for name,arm in report['arms'].items()},'meter':report['meter']}
   rows.append(row)
   print(json.dumps({'seed':seed,'panel':label,'arms':row['arms'],'prediction_calls':report['meter']['prediction_calls']}),flush=True)
 write(out/'RESULT.json',{'status':'HOLD','execution_status':'completed','started_at':started,'finished_at':datetime.now(timezone.utc).isoformat(),'total_wall_seconds':time.perf_counter()-wall,'total_process_cpu_seconds':time.process_time()-cpu,'new_training_runs':0,'new_confirmation_runs':0,'records':rows,'physical_cost_complete':False,'energy_joules':None,'financial_cost':None})
except BaseException as error:
 write(out/'FAILURE.json',{'status':'HOLD','error_type':type(error).__name__,'error':str(error),'records':rows,'total_wall_seconds':time.perf_counter()-wall,'total_process_cpu_seconds':time.process_time()-cpu})
 raise
