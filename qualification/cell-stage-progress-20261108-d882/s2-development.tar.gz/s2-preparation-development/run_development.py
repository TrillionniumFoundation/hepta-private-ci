from dataclasses import replace
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import platform
import subprocess
import time
import numpy as np
from hepta_pred1.models import Model
from hepta_pred1.preparation import evaluate_development_preparations
from hepta_pred1.simulator import generate_dataset

out = Path('/workspace/scratch/d882890e1711/s2-preparation-development')
repo = Path('/workspace/scratch/d882890e1711/hepta-stage')
config = {
    'schema': 'pred1-preparation-development-plan-v1',
    'scope': 'engineering/development diagnostic; no confirmation or adoption',
    'training_seeds': [9011, 9017],
    'train_episodes': 128, 'dev_episodes': 129, 'history_length': 8,
    'model_kind': 'gru', 'hidden_dim': 8, 'epochs': 12, 'batch_size': 32,
    'learning_rate': 0.01, 'checkpoint_rule': 'last epoch; no reselection',
    'development_deadline_cycle': [4.0, 8.0, 14.0],
    'development_remaining_budget_cycle': [2.0, 8.25, 9.0],
    'decision_work_per_queried_episode': 0.1,
    'resource_panel': 'declared before execution; separate from historical protocol',
    'comparison': 'same trained checkpoint, public histories, forecasts and per-episode resource limits for adaptive/fixed_1/fixed_3/fixed_6',
    'status': 'HOLD',
}
def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')
plan = out / 'PLAN.json'
if plan.exists():
    raise FileExistsError('create-only development plan already exists')
write(plan, config)
source = {str(path.relative_to(repo)): sha256(path.read_bytes()).hexdigest() for path in sorted((repo / 'scripts/hepta_pred1').glob('*.py'))}
write(out / 'SOURCE.json', {
    'base_commit': subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip(),
    'worktree_has_new_uncommitted_module': True,
    'files_sha256': source,
    'plan_sha256': sha256(plan.read_bytes()).hexdigest(),
    'python': platform.python_version(), 'numpy': np.__version__, 'platform': platform.platform(),
})
started = datetime.now(timezone.utc).isoformat()
wall, cpu = time.perf_counter(), time.process_time()
records = []
try:
    for seed in config['training_seeds']:
        tw, tc = time.perf_counter(), time.process_time()
        train = generate_dataset(config['train_episodes'], seed, 'train', config['history_length'])
        generated = generate_dataset(config['dev_episodes'], seed, 'dev', config['history_length'])
        dev = replace(generated, deadline=np.resize(config['development_deadline_cycle'], len(generated.x)), remaining_budget=np.resize(config['development_remaining_budget_cycle'], len(generated.x)))
        if set(train.groups) & set(dev.groups):
            raise AssertionError('training/development overlap')
        data_meter = {'wall_seconds': time.perf_counter()-tw, 'process_cpu_seconds':time.process_time()-tc}
        tw, tc = time.perf_counter(), time.process_time()
        model = Model(config['model_kind'], 16, 7, 32, config['hidden_dim'], seed)
        rng = np.random.default_rng(seed+101)
        curve=[]
        for epoch in range(config['epochs']):
            losses=[]
            order = rng.permutation(len(train.x))
            for start in range(0, len(order), config['batch_size']):
                rows = order[start:start+config['batch_size']]
                losses.append(model.fit_step(train.x[rows], train.query[rows], train.allowed[rows], lr=config['learning_rate']))
            curve.append({'epoch':epoch+1, 'mean_batch_train_nll':float(np.mean(losses))})
        checkpoint=out/f'gru-{seed}-last.npz'
        checkpoint_digest=model.save(checkpoint)
        fitted=Model.load(checkpoint)
        training_meter={'wall_seconds':time.perf_counter()-tw, 'process_cpu_seconds':time.process_time()-tc}
        report = evaluate_development_preparations(fitted, dev, decision_work=np.full(len(dev.x), config['decision_work_per_queried_episode']))
        write(out/f'development-{seed}.json',report)
        record={
            'seed':seed, 'parameters':fitted.parameter_count, 'optimizer_steps':fitted.steps,
            'train_fingerprint':train.fingerprint(), 'generated_dev_fingerprint':generated.fingerprint(), 'resource_panel_dev_fingerprint':dev.fingerprint(),
            'checkpoint':checkpoint.name, 'checkpoint_sha256':checkpoint_digest,
            'curve':curve, 'data_generation':data_meter, 'training_and_checkpoint':training_meter,
            'arms':{name:{k:v for k,v in arm.items() if k!='per_episode'} for name,arm in report['arms'].items()},
            'meter':report['meter'],
        }
        records.append(record)
        print(json.dumps({'seed':seed, 'arms':record['arms']}),flush=True)
    result={'status':'HOLD', 'execution_status':'completed', 'started_at':started, 'finished_at':datetime.now(timezone.utc).isoformat(), 'total_wall_seconds':time.perf_counter()-wall, 'total_process_cpu_seconds':time.process_time()-cpu, 'independent_development_training_runs':len(records), 'registered_confirmation_runs':0, 'records':records, 'physical_cost_complete':False, 'energy_joules':None, 'financial_cost':None}
    write(out/'RESULT.json',result)
except BaseException as error:
    write(out/'FAILURE.json', {'started_at':started, 'error_type':type(error).__name__, 'error':str(error), 'completed_seed_records':records, 'total_wall_seconds':time.perf_counter()-wall, 'total_process_cpu_seconds':time.process_time()-cpu, 'status':'HOLD'})
    raise
