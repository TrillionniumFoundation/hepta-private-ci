import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


parser = argparse.ArgumentParser()
parser.add_argument("label")
args = parser.parse_args()
base = Path("/workspace/scratch/d882890e1711")
root = base / "hepta-stage"
prefix = base / args.label
report = root / "codex-rs/target/nextest/local/junit.xml"
changed = subprocess.check_output(["git", "diff", "--name-only"], cwd=root, text=True).splitlines()
untracked = subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard"], cwd=root, text=True).splitlines()
paths = sorted({p for p in changed + untracked if p.startswith("codex-rs/")} | {"codex-rs/Cargo.toml", "codex-rs/Cargo.lock", "codex-rs/.config/nextest.toml"})
snapshot = Path(str(prefix) + "-source")
for path in paths:
    target = snapshot / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / path, target)


def source_hashes():
    return {path: digest(root / path) for path in paths}


command = ["just", "test", "-p", "codex-hepta-agentd", "--locked", "--cargo-profile", "dev-small", "--lib", "-E", "test(learning_iteration)", "--retries", "0"]
env = os.environ.copy()
env["PATH"] = "/workspace/scratch/d882890e1711/build-tools/cmake/data/bin:/workspace/scratch/ac851b3fedf0/toolchains/rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin:/workspace/scratch/ac851b3fedf0/hepta-tools:" + env["PATH"]
env["CARGO_HOME"] = "/workspace/scratch/ac851b3fedf0/toolchains/cargo"
env["RUSTUP_HOME"] = "/workspace/scratch/ac851b3fedf0/toolchains/rustup"
env["CARGO_TARGET_DIR"] = str(base / "target")
env["CARGO_BUILD_JOBS"] = "2"
receipt = {"command": command, "cwd": str(root), "source_base": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(), "source_files_before": source_hashes(), "source_snapshot": str(snapshot), "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "junit_before_hash": digest(report), "cargo_profile": "dev-small", "retries": 0, "build_jobs": 2}
receipt["build_environment"] = {key: env.get(key) for key in ("CARGO_HOME", "RUSTUP_HOME", "CARGO_TARGET_DIR", "CARGO_BUILD_JOBS", "BINDGEN_EXTRA_CLANG_ARGS")}
receipt_path = Path(str(prefix) + "-receipt.json")
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"started": receipt["started_utc"], "command": command, "receipt": str(receipt_path)}), flush=True)
log_path = Path(str(prefix) + ".log")
with log_path.open("wb") as output:
    result = subprocess.run(command, cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT)
receipt.update({"exit_code": result.returncode, "finished_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "source_files_after": source_hashes(), "junit_after_hash": digest(report), "log_sha256": digest(log_path)})
receipt["source_stable"] = receipt["source_files_before"] == receipt["source_files_after"]
receipt["junit_changed"] = receipt["junit_before_hash"] != receipt["junit_after_hash"]
if report.is_file() and receipt["junit_changed"]:
    destination = Path(str(prefix) + "-junit.xml")
    shutil.copyfile(report, destination)
    receipt["junit_path"] = str(destination)
    tree = ET.parse(destination)
    receipt["junit_suites"] = [{key: suite.attrib.get(key) for key in ("name", "tests", "failures", "errors", "skipped")} for suite in tree.getroot().iter("testsuite")]
    binaries = list((base / "target/dev-small/deps").glob("codex_hepta_agentd-*"))
    receipt["binaries"] = [{"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path)} for path in binaries if path.is_file() and not path.suffix and os.access(path, os.X_OK)]
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt), flush=True)
raise SystemExit(result.returncode)
