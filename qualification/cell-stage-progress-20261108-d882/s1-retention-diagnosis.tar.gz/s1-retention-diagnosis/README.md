# S1 原 retention 零分：只读诊断

本包保存 2026-11-09 对原 20261108 B pilot 的读取证据。没有重新训练、重跑 episode、读取 confirmation/retention_test 或私有 reference，也没有修改原证据。

两份 retention public packet 实际只要求文本，image=false；原 frozen scorer 对它们使用 text=1/image=0。缺少输出图像不是零分原因。原 160 行投影中，47 次直接 STOP，113 次交付文本但文本质量为零，没有 READ_ROI。

按预先固定的同一 ordinary/frozen/reset/fixed profile 查看两条原执行：total 交付 4.80；date 交付 TAX INVOICE,。date 的原 OCR 27 行没有 unchanged DATE regex 可提取的日期，现有候选选择不能从该观察中产生合格日期。没有读取原 private label 来断言 total 的正确候选是否存在。

原训练 receipt 与仓库 B_TRAINING_JOBS SHA 一致：50 行里 21 行有精确候选、29 行没有；20 完整链、14 unique content states、2 source groups。该 content fit 只有 2 epoch/4 optimizer steps。无正候选行的文本 CE 为 0 是现有实现的明确规则；没有发现已证明的标签/mask/评估接口 bug。

raw/ 只保存 evidence.json 列出的原字节。20 KB 原诊断归档包含 160 行结果投影，**不等于保存了 160 份完整 result.json**。本包只保存重新读取的一份完整 result.json、两条原轨迹/OCR/最终 delivery、一个原训练 receipt 和原诊断归档。两份 public packet 已读且验 SHA，但不作为原字节副本保存在本包。commands.json 是核心读取/复现调用清单，不是完整会话日志。

本包包含 retention_validation 事后观察，必须与后续仅 train/development 的诊断输入隔离；不能把它用作拟合日期 regex、标签、阈值或控制策略的训练数据。任何新增候选/ROI 工作应按独立 development 计划登记，保留原任务与评分定义及全部尝试/成本。
