# S1：原训练候选与 ROI 诊断

本次新增独立的 development 诊断程序，保持原 actor、OCR、normalizer、任务与评分定义不变。程序只允许 train/development；明确拒绝 retention_validation、confirmation 和 retention_test。原 retention 事后只读证据另存于本目录 raw/，没有进入此次诊断计划。

## 实际执行

唯一原生作业 `1a1be4c758c-5e21-29` 在 ai395 原 Python 环境完成，succeeded / exit 0，未自动重试。计划在执行前冻结为 `14b820a9dcf17561cbfb4ee15598cbae7993a3b1cd7c7fbf5a407f33f266add7`；执行模块 SHA 为 `c1263f2af0ee3c61bfe69c81aa7559819159811c142d0d4af79c435069fa8b25`。主报告 98,862 字节，SHA `47fd3000e6fab847df9e55ecad6eac67c81c8e7714a759961da88550291ac347`，已完整回读核验。保留 126 个输入绑定。

读取的是原 collector 的全部 20 个 registered attempt、50 条 train 记录、2 个 source group。没有重新执行 actor、OCR、episode 或训练。admitted inventory、原 request/result/attempt receipt、完整记录链、原 trajectory、public packet 和最终 delivery 逐级绑定；未启动、失败、未决结果不会从分母删去。

## 实际发现

| 项目 | 原观察 |
|---|---:|
| 有精确正确候选的记录 | 21 / 50 |
| 缺少精确正确候选的记录 | 29 / 50 |
| WRITE_TEXT 参数正确 | 2 / 8 |
| 正确候选存在但实际选错候选 | 2 / 8 |
| WRITE_TEXT 时没有正确候选 | 4 / 8 |
| 原 READ_ROI 后补回正确候选 | 2 / 7 |
| 原 READ_ROI 后丢失正确候选 | 2 / 7 |
| 正确候选继续存在 | 1 / 7 |
| READ_ROI 后仍缺少正确候选 | 2 / 7 |

20 份最终 delivery 都有原评分绑定的 SHA：10 份文本正确、10 份错误，全部与原 evaluator 一致。其中 **8 份正确文本没有任何 WRITE_TEXT**，来自原公开交付承诺的保留；它们不能被计作新学会的文本交付。

三个可定位的训练侧问题已经分开：`case-a9172a7230b7609f37d58da9` 原 ROI 前存在正确候选，之后丢失并错误写入；`case-fad4394de93653c07120c0fe` 前后都存在正确候选，却两次选择错误；`case-589e5d5e14d601595e242787` 原 ROI 补回候选，随后实际正确写入。另一条 coverage_gained 来自已经交付文本/图像的 continuation_not_worthwhile case，并非新增交付收益。逐次操作、后继 record SHA、覆盖结果与成本见 development-summary.json。

这支持下一独立训练/开发计划检查“ROI 后保留先前已观察候选”及候选排序，但不是已经证明该策略收益。本轮没有实施这个策略，也没有从原 retention 样本拟合日期 regex、标签或阈值。7 次 ROI 的全部反向与无收益观察均保留；不能只用其中成功的案例替代公平评测。

## 成本解释

原 50 个动作的 11.546084601 秒已包含于原 20 个 attempt 的墙钟之和 53.750481397 秒。两个 collection phase 的实际 elapsed wall 分别为 12.422789033 秒与 15.902201132 秒；并发 attempt 的墙钟之和不等于 phase elapsed。三层不能相加。单个 ROI 的 preparation/read 字段是对应动作时间；新 ROI 的 OCR 等工作可能计在后继 decision 中，不能把两项当作完整 ROI 成本。

本次新诊断 wrapper 实测墙钟 0.154168170 秒、进程 CPU 0.104213647 秒，包含导入、准备和分析，未包含 Python 启动之前的工作、工具传输与 native supervisor。能源和平台费用未知，完整物理成本仍为 false。

## 测试与证据边界

新诊断 16 项行为测试及既有 recursive contract 5 项，在最终一次 scoped canonical 命令中 21/21 通过、0 skip、exit 0。测试包含成功的原文件结构集成、失败/未启动分母、候选外写入、最终效果未知、ROI 反向/缺失后继及成本不重复。Pillow 为 13.0.0，不依赖 Torch。

先前两次扩展命令的失败均保留：第一次漏设既有 causal_b 所需的 PYTHONPATH；第二次遇到 sparse checkout 未物化源码以及该旧套件 mock 包名不匹配，另有一项按原规则因缺 Torch 而 skip。没有改旧源码或 skip 条件来制造绿灯。完整命令、错误、日志与限于相关 21 项的最终结果见 development-test-history.json。

这些测试只验证诊断行为。原结果仍属于两个来源的有限训练数据事后诊断，未建立保留能力、学习收益、ROI 政策优势或独立原生 owner 认证。公开仓库只适合接收程序和聚合元数据；原图片、文本、标签与轨迹不随本包公开上传。
