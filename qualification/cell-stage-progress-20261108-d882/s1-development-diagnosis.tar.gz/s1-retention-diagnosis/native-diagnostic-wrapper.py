import base64, hashlib, json, os, runpy, sys, time, traceback
from pathlib import Path
started_wall, started_cpu = time.perf_counter(), time.process_time()
raw = sys.stdin.buffer.read(1024 * 1024 + 1)
if len(raw) > 1024 * 1024:
    raise ValueError("Transfer exceeds bounded stdin")
payload = json.loads(raw)
root = Path("/home/qq/cell-candidate-diagnostic-20261109-d882-v1")
module = base64.b64decode(payload["module_base64"], validate=True)
plan = base64.b64decode(payload["plan_base64"], validate=True)
if hashlib.sha256(module).hexdigest() != "c1263f2af0ee3c61bfe69c81aa7559819159811c142d0d4af79c435069fa8b25":
    raise ValueError("Reviewed diagnostic bytes changed")
if hashlib.sha256(plan).hexdigest() != "14b820a9dcf17561cbfb4ee15598cbae7993a3b1cd7c7fbf5a407f33f266add7":
    raise ValueError("Prewritten diagnostic plan changed")
root.mkdir(mode=0o700, exist_ok=False)
for name, content in (("candidate_diagnostic.py", module), ("plan.json", plan)):
    with (root / name).open("xb") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
status, error = "failed", None
try:
    sys.argv = [str(root / "candidate_diagnostic.py"), "--plan", str(root / "plan.json"), "--plan-sha256", hashlib.sha256(plan).hexdigest(), "--output", str(root / "report.json")]
    runpy.run_path(str(root / "candidate_diagnostic.py"), run_name="__main__")
    status = "completed"
except BaseException as exception:
    error = {"type": type(exception).__name__, "message": str(exception), "traceback": traceback.format_exc()}
    raise
finally:
    receipt = {"schema": "hepta.candidate-diagnostic-execution.v1", "status": status, "error": error,
               "module_sha256": hashlib.sha256(module).hexdigest(), "plan_sha256": hashlib.sha256(plan).hexdigest(),
               "wall_seconds": time.perf_counter() - started_wall, "process_cpu_seconds": time.process_time() - started_cpu,
               "cost_scope": "diagnostic wrapper process after Python startup; includes imports/preparation/diagnostic, excludes transport and native supervisor",
               "energy_joules": None, "provider_charges": None, "full_physical_cost_complete": False,
               "new_actor_runs": 0, "new_ocr_runs": 0, "new_training_runs": 0}
    with (root / "execution-receipt.json").open("x") as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
