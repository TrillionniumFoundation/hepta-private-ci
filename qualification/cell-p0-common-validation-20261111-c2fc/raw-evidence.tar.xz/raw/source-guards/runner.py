#!/usr/bin/env python3
"""Validate source guards and research gates against one frozen full checkout."""
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import tomllib

import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--evidence', type=Path, required=True)
parser.add_argument('--head', required=True)
parser.add_argument('--tree', required=True)
args = parser.parse_args()
REPO = args.repo.resolve()
OUT = args.evidence.resolve()
HEAD = args.head
TREE = args.tree
assert re.fullmatch(r'[0-9a-f]{40}', HEAD)
assert re.fullmatch(r'[0-9a-f]{40}', TREE)
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
SOURCE_MODULES = [
    'test_cell_learning_evaluation_source_closure',
    'test_generation_learning_evidence_source_closure',
    'test_learning_checkpoint_source_closure',
    'test_learning_evaluation_recovery_source_closure',
    'test_original_learning_owner_source_closure',
    'test_q24_training_plan_source_closure',
    'test_root_learning_bootstrap_source_closure',
    'test_root_learning_scope_source_closure',
    'test_training_no_update_source_closure',
    'test_verify_hepta_callers',
]
RESEARCH_MODULES = [
    'test_hepta_cell_research_gate',
    'test_hepta_cell_research_units',
    'test_hepta_cell_research_successor',
    'test_hepta_cell_joint_config',
    'test_hepta_prospective_comparison',
]


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def snapshot(label):
    records = []

    def git(args, artifact):
        cmd = ['git', '--no-lazy-fetch', '--no-optional-locks', '--no-replace-objects', *args]
        proc = subprocess.run(cmd, cwd=REPO, env=ENV, capture_output=True, check=False)
        (OUT / (label + '-' + artifact)).write_bytes(proc.stdout)
        (OUT / (label + '-' + artifact + '.stderr')).write_bytes(proc.stderr)
        records.append({'command': cmd, 'cwd': str(REPO), 'exit_code': proc.returncode, 'stdout_bytes': len(proc.stdout), 'stdout_sha256': hashlib.sha256(proc.stdout).hexdigest(), 'stdout_artifact': label + '-' + artifact, 'stderr_artifact': label + '-' + artifact + '.stderr'})
        if proc.returncode:
            save(label + '-snapshot-failure.json', records)
            raise RuntimeError(f'{label}: git command failed: {args!r}')
        return proc.stdout

    started = now()
    actual_head = git(['rev-parse', 'HEAD'], 'head.txt').decode().strip()
    actual_tree = git(['rev-parse', 'HEAD^{tree}'], 'tree.txt').decode().strip()
    status = git(['status', '--porcelain=v1', '--untracked-files=all'], 'status.txt')
    leaves_raw = git(['ls-tree', '-r', '-z', '--full-tree', 'HEAD'], 'tree-inventory.z')
    index_raw = git(['ls-files', '--stage', '-z'], 'index-inventory.z')
    leaves = {}
    for item in leaves_raw.split(b'\0'):
        if not item:
            continue
        header, path = item.split(b'\t', 1)
        mode, kind, sha = header.decode().split()
        leaves[path.decode()] = {'mode': mode, 'type': kind, 'sha': sha}
    index = {}
    for item in index_raw.split(b'\0'):
        if not item:
            continue
        header, path = item.split(b'\t', 1)
        mode, sha, stage = header.decode().split()
        assert stage == '0', (path, stage)
        index[path.decode()] = {'mode': mode, 'sha': sha}
    assert actual_head == HEAD and actual_tree == TREE, (actual_head, actual_tree)
    assert not status, status.decode()
    assert index == {p: {'mode': e['mode'], 'sha': e['sha']} for p, e in leaves.items()}, 'Index differs from HEAD tree'
    selected = {p: e for p, e in leaves.items() if (p.startswith('codex-rs/') and p.endswith('.rs')) or p.startswith('qa/b4-no-bypass/') or p.startswith('scripts/') or p in {'CALLERS.toml', 'AGENTS.md', 'justfile', 'codex-rs/Cargo.toml'}}
    files = []
    mismatches = []
    for path, entry in selected.items():
        assert entry['type'] == 'blob' and entry['mode'] in {'100644', '100755'}, (path, entry)
        target = REPO / path
        if not target.is_file():
            mismatches.append({'path': path, 'problem': 'missing'})
            continue
        raw = target.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        file_record = {'path': path, **entry, 'actual_blob_sha': actual, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
        files.append(file_record)
        if actual != entry['sha']:
            mismatches.append({'path': path, 'problem': 'blob differs from HEAD', 'actual_blob': actual, 'expected_blob': entry['sha']})
    indexed_rust = {p for p in leaves if p.startswith('codex-rs/') and p.endswith('.rs')}
    actual_rust = {p.relative_to(REPO).as_posix() for p in (REPO / 'codex-rs').rglob('*.rs') if p.is_file()}
    assert indexed_rust == actual_rust, {'extra_rust': sorted(actual_rust - indexed_rust), 'missing_rust': sorted(indexed_rust - actual_rust)}
    callers = tomllib.loads((REPO / 'CALLERS.toml').read_text())
    required = {p for b in callers['boundary'] for p in [b['definition_path'], *b['product_callers']]}
    required.update(row['path'] for row in callers['protected_file'])
    missing_required = sorted(p for p in required if not (REPO / p).is_file())
    data = {'started_utc': started, 'finished_utc': now(), 'head': actual_head, 'tree': actual_tree, 'git_commands': records, 'tracked_entries': len(leaves), 'index_entries': len(index), 'index_equals_head_tree': True, 'worktree_clean': not status, 'source_file_count': len(files), 'rust_file_count': len(indexed_rust), 'source_bytes': sum(f['bytes'] for f in files), 'source_mismatches': mismatches, 'boundary_count': len(callers['boundary']), 'protected_file_rows': len(callers['protected_file']), 'required_paths': len(required), 'missing_required_paths': missing_required, 'source_files': files}
    save(label + '-snapshot.json', data)
    assert not mismatches and not missing_required, (mismatches, missing_required)
    print(json.dumps({k: v for k, v in data.items() if k not in {'source_files', 'git_commands'}}, sort_keys=True), flush=True)
    return data


def run(name, command, cwd):
    start = time.monotonic()
    result = {'name': name, 'command': command, 'cwd': str(cwd), 'head': HEAD, 'tree': TREE, 'started_utc': now(), 'environment_overrides': {'PYTHONDONTWRITEBYTECODE': '1', 'GIT_NO_LAZY_FETCH': '1', 'GIT_OPTIONAL_LOCKS': '0'}}
    save(name + '.started.json', result)
    with (OUT / (name + '.stdout.log')).open('wb') as stdout, (OUT / (name + '.stderr.log')).open('wb') as stderr:
        proc = subprocess.Popen(command, cwd=cwd, env=ENV, stdout=stdout, stderr=stderr)
        result['pid_within_job_namespace'] = proc.pid
        save(name + '.started.json', result)
        waited_pid, wait_status, usage = os.wait4(proc.pid, 0)
        assert waited_pid == proc.pid
        exit_code = os.waitstatus_to_exitcode(wait_status)
        proc.returncode = exit_code
    result.update({'exit_code': exit_code, 'wall_seconds': time.monotonic() - start, 'cpu_user_seconds': usage.ru_utime, 'cpu_system_seconds': usage.ru_stime, 'cpu_measurement': 'POSIX wait4 rusage for this subprocess', 'max_rss_kib': usage.ru_maxrss, 'finished_utc': now(), 'stdout_log': str(OUT / (name + '.stdout.log')), 'stderr_log': str(OUT / (name + '.stderr.log'))})
    raw_stderr = (OUT / (name + '.stderr.log')).read_text()
    if name.endswith('unittest'):
        summary = re.search(r'^Ran (\d+) tests? in ([0-9.]+)s$', raw_stderr, re.MULTILINE)
        result['actual_test_count'] = int(summary[1]) if summary else None
        result['unittest_reported_seconds'] = float(summary[2]) if summary else None
        result['result_line'] = next((s for s in reversed(raw_stderr.splitlines()) if s == 'OK' or s.startswith(('OK (', 'FAILED ('))), None)
        result['individual_failures_or_errors'] = re.findall(r'^(?:FAIL|ERROR): .+$', raw_stderr, re.MULTILINE)
        result['skipped_case_lines'] = [s for s in raw_stderr.splitlines() if ' ... skipped ' in s]
        cases = re.findall(r'^test_[^\s]+ \(([^)]+)\) \.\.\.', raw_stderr, re.MULTILINE)
        result['unique_test_cases'] = sorted(set(cases))
        result['unique_test_case_count'] = len(set(cases))
        result['verbose_case_line_count'] = len(cases)
    elif exit_code == 0:
        result['receipt'] = json.loads((OUT / (name + '.stdout.log')).read_text())
    save(name + '.result.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'receipt'}, sort_keys=True), flush=True)
    return result


OUT.mkdir(exist_ok=False)
(OUT / 'runner.py').write_bytes(Path(__file__).read_bytes())
save('run-started.json', {'head': HEAD, 'tree': TREE, 'repo': str(REPO), 'started_utc': now(), 'command': [sys.executable, *sys.argv]})
before = snapshot('before')
jobs = [('source-unittest', [sys.executable, '-m', 'unittest', '-v', *SOURCE_MODULES], REPO / 'qa/b4-no-bypass'), ('research-unittest', [sys.executable, '-m', 'unittest', '-v', *RESEARCH_MODULES], REPO / 'scripts'), ('callers-verify', [sys.executable, 'scripts/verify_hepta_callers.py', 'verify'], REPO)]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    futures = [pool.submit(run, *job) for job in jobs]
    results = [future.result() for future in concurrent.futures.as_completed(futures)]
after = snapshot('after')
assert before['source_files'] == after['source_files'], 'Source hashes changed during validation'
for artifact in ('tree-inventory.z', 'index-inventory.z', 'head.txt', 'tree.txt', 'status.txt'):
    assert (OUT / ('before-' + artifact)).read_bytes() == (OUT / ('after-' + artifact)).read_bytes(), artifact
passed = all(r['exit_code'] == 0 for r in results)
final = {'head': HEAD, 'tree': TREE, 'status': 'PASS_REQUESTED_SOURCE_AND_RESEARCH_GATES' if passed else 'FAIL_REQUESTED_SOURCE_OR_RESEARCH_GATES', 'before_snapshot': str(OUT / 'before-snapshot.json'), 'after_snapshot': str(OUT / 'after-snapshot.json'), 'source_and_git_inventory_unchanged': True, 'full_checkout': True, 'native_validation': False, 'research_independent_confirmations_added': 0, 'production_authority_granted': False, 'runs': results}
save('validation-result.json', final)
print(json.dumps({k: v for k, v in final.items() if k != 'runs'}, sort_keys=True), flush=True)
sys.exit(0 if passed else 1)
