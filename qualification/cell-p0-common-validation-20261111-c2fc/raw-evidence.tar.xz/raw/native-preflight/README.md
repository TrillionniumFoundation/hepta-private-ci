# Git-attribution native preflight for final source S

Status: **NOT_RUN_RESOURCE_PREFLIGHT**. Neither native test started.

Source SHA: `1e822b3aeac79d9e9fc169f7fc6a48821baa6654`

Source tree: `80f33dcd59cf3721dbec3a9cb2ee695db5187cd5`

The full checkout was clean before and after the resource review; the complete tracked-file inventories match. The prepared command would select exactly the unauthorized-recovery and auth-refresh retry library tests, with locked offline dependencies, a new independent target, and zero retries. The source-owned `hepta_ci_exec.py` and fresh-JUnit collector were planned but were not invoked. There is no test execution record or JUnit report to treat as passing.

The first preflight rejected 6,389,862,400 free bytes against an agent-selected 6 GiB reserve. This was a conservative planning threshold, not a repository rule. Further read-only checks observed shared free space between 5,726,089,216 and 6,295,052,288 bytes. Existing RMCP targets occupy roughly 3.61 to 4.35 GB, and the git-attribution package has a broader declared local dependency scope. Those historical target sizes include unknown prior build scopes and do not prove a precise requirement for this build. Because the fresh compile/link peak remains unknown and the available margin fluctuates, the build was not started. No existing target or cache was reused, deleted, or modified.

`planned-invocation.json` contains the exact planned test, recorder, and collector commands plus compiler settings. `tool-versions.json` records the installed tools. `resource-observations.json` retains capacity observations and their limits; `dependency-scope.json` identifies the static dependency traversal as an upper bound. `first-preflight.observed-output.txt` is a verbatim transcription of the exec tool stderr, rather than an invented native-run log.

`source-before.jsonl` and `source-after.jsonl` enumerate every tracked path, Git blob/mode, actual byte count, and actual SHA-256; their summaries contain matching inventory hashes. These bind only the preflight interval. Compilation, test execution, native pass/fail counts, and build/link cost are not measured. Independent real confirmations remain zero. This report does not certify P0 or substitute for exact-head CI.
