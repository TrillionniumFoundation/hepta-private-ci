#!/usr/bin/env python3
"""Run exactly two git-attribution cases against the frozen common candidate."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time
from datetime import datetime, timezone

REPO = Path('/workspace/scratch/c2fccbdb195e/final-candidate')
OUT = Path('/workspace/scratch/c2fccbdb195e/p0-common-native-1e822b3a')
TARGET = Path('/workspace/scratch/c2fccbdb195e/p0-common-native-1e822b3a-target')
SOURCE = '1e822b3aeac79d9e9fc169f7fc6a48821baa6654'
TREE = '80f33dcd59cf3721dbec3a9cb2ee695db5187cd5'
TOOLCHAIN = Path('/workspace/scratch/f7c0ded86bcc/toolchain/installed/bin')
JUST = Path('/home/agent/.cache/uv/archive-v0/VQZnoBTGY-ZxSFhe/bin')
CMAKE = Path('/workspace/scratch/f7c0ded86bcc/rmcp-tools/cmake/data/bin')
CASES = [
    'tests::policy_resolution_recovers_after_unauthorized',
    'tests::policy_resolution_retries_after_auth_refresh',
]
COMMAND = [
    'just', 'test', '--locked', '--offline', '-p', 'codex-git-attribution',
    '--lib', '-E', ' | '.join('test(=' + case + ')' for case in CASES),
    '--retries', '0', '--test-threads', '2', '--no-fail-fast',
    '--success-output', 'final', '--failure-output', 'final',
]


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def write_json(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def inventory(name):
    started = time.monotonic()
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    status = git('status', '--porcelain=v1', '--untracked-files=all').decode()
    assert head == SOURCE, (head, SOURCE)
    assert tree == TREE, (tree, TREE)
    assert not status, status
    entries = git('ls-files', '--stage', '-z').split(b'\0')
    combined = hashlib.sha256()
    count = total = 0
    with (OUT / (name + '.jsonl')).open('x', encoding='utf-8') as stream:
        for entry in entries:
            if not entry:
                continue
            meta, raw_path = entry.split(b'\t', 1)
            mode, blob, stage = meta.decode().split()
            assert stage == '0', entry
            rel = os.fsdecode(raw_path)
            path = REPO / rel
            info = path.lstat()
            digest = hashlib.sha256()
            if stat.S_ISLNK(info.st_mode):
                raw = os.fsencode(os.readlink(path))
                digest.update(raw)
                size = len(raw)
            elif stat.S_ISREG(info.st_mode):
                size = info.st_size
                with path.open('rb') as source:
                    for chunk in iter(lambda: source.read(1024 * 1024), b''):
                        digest.update(chunk)
            else:
                raise ValueError('unexpected tracked entry kind: ' + rel)
            record = {'path': rel, 'git_blob': blob, 'git_mode': mode,
                      'bytes': size, 'sha256': digest.hexdigest()}
            line = json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n'
            stream.write(line)
            combined.update(line.encode())
            count += 1
            total += size
    result = {'source_sha': head, 'source_tree': tree, 'clean': True,
              'tracked_files': count, 'tracked_bytes': total,
              'inventory_sha256': combined.hexdigest(),
              'wall_seconds': time.monotonic() - started,
              'disk_free_bytes': shutil.disk_usage(REPO).free}
    write_json(OUT / (name + '.json'), result)
    return result


def main():
    assert not TARGET.exists(), 'target must be fresh'
    assert shutil.disk_usage(REPO).free >= 6 * 1024 ** 3, 'insufficient free disk'
    junit = REPO / 'codex-rs/target/nextest/local/junit.xml'
    assert not junit.exists(), 'preexisting JUnit requires separate retention'
    before = inventory('source-before')
    print(json.dumps({'phase': 'preflight', **before}), flush=True)
    TARGET.mkdir(exist_ok=False)
    overrides = {
        'PATH': ':'.join([str(TOOLCHAIN), str(JUST), str(CMAKE), os.environ['PATH']]),
        'CARGO_HOME': '/home/agent/.cargo', 'CARGO_TARGET_DIR': str(TARGET),
        'CARGO_NET_OFFLINE': 'true', 'CARGO_BUILD_JOBS': '2',
        'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
        'CARGO_PROFILE_TEST_DEBUG': '0',
        'RUSTC': str(TOOLCHAIN / 'rustc'), 'RUSTDOC': str(TOOLCHAIN / 'rustdoc'),
        'RUSTC_WRAPPER': '', 'RUSTC_WORKSPACE_WRAPPER': '',
        'SOURCE_SHA': SOURCE, 'TESTED_SHA': SOURCE, 'BASE_SHA': '',
        'HEPTA_CI_LANE': 'source-head', 'CODEX_REPO_ROOT': str(REPO),
        'PYTHONDONTWRITEBYTECODE': '1',
    }
    env = dict(os.environ, **overrides)
    versions = {}
    for name, command in {
        'rustc': [str(TOOLCHAIN / 'rustc'), '-Vv'],
        'cargo': [str(TOOLCHAIN / 'cargo'), '--version'],
        'cargo_nextest': [str(TOOLCHAIN / 'cargo-nextest'), '--version'],
        'just': [str(JUST / 'just'), '--version'],
        'cmake': [str(CMAKE / 'cmake'), '--version'],
    }.items():
        result = subprocess.run(command, env=env, capture_output=True, text=True)
        assert result.returncode == 0, (name, result.stderr)
        versions[name] = {'command': command, 'stdout': result.stdout,
                          'stderr': result.stderr, 'returncode': result.returncode}
    write_json(OUT / 'invocation.json', {
        'source_sha': SOURCE, 'source_tree': TREE, 'repo': str(REPO),
        'target': str(TARGET), 'target_initially_absent': True,
        'environment_overrides': overrides, 'versions': versions,
        'command': COMMAND, 'expected_cases': CASES, 'expected_count': 2,
        'attempt': 1, 'retries': 0, 'native_junit_initially_absent': True,
        'scope': 'git-attribution two lib tests only',
        'independent_real_confirmations': 0, 'full_p0_claim': False,
    })
    execution = OUT / 'git-attribution.execution.json'
    outer_command = [sys.executable, str(REPO / 'scripts/hepta_ci_exec.py'),
                     '--output', str(execution), '--minimum-tests', '2',
                     '--timeout-seconds', '3600', '--', *COMMAND]
    started = time.monotonic()
    started_at = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(outer_command, cwd=REPO / 'codex-rs', env=env)
    execution_wall = time.monotonic() - started
    collect_command = [sys.executable, str(REPO / 'scripts/hepta_ci_junit.py'),
                       '--execution', str(execution), '--junit', str(junit),
                       '--output', str(OUT / 'git-attribution.junit.xml')]
    collected = subprocess.run(collect_command, cwd=REPO / 'codex-rs', env=env)
    after = inventory('source-after')
    same = before['inventory_sha256'] == after['inventory_sha256']
    assert same, 'tracked source bytes changed during command'
    write_json(OUT / 'result.json', {
        'source_sha': SOURCE, 'source_tree': TREE,
        'started_at': started_at, 'finished_at': datetime.now(timezone.utc).isoformat(),
        'execution_command': outer_command, 'execution_exit': result.returncode,
        'execution_outer_wall_seconds': execution_wall,
        'junit_collection_command': collect_command,
        'junit_collection_exit': collected.returncode,
        'source_inventory_unchanged': same,
        'status': 'passed' if result.returncode == collected.returncode == 0 else 'failed',
        'scope': 'git-attribution two lib tests only',
        'independent_real_confirmations': 0, 'full_p0_claim': False,
    })
    return 0 if result.returncode == collected.returncode == 0 else 1


if __name__ == '__main__':
    raise SystemExit(main())
