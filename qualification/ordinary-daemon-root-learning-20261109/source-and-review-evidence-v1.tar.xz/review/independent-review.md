# Independent native evidence review

Status: **verified within the recorded scope; production acceptance remains HOLD**.

The archive has **750120 bytes** and SHA-256
`e6637d247becd574be864da62173b1004abb73c06c6257d7d0b32b2d077ff18f`, matching the requested identity.
All **37 manifest payload hashes/sizes**, **38 extracted files**,
**8 raw log hashes**, **2 JUnit hashes**, and **5 source-inventory file hashes** agree.
No archive entry is a symlink, device, absolute path or parent traversal.

## Recorded executions

| Attempt | Exit | Top-level PASS results before summary |
| --- | ---: | ---: |
| compile-only-v1 | 0 | 0 |
| agentd-full-lib-v1 | 101 | 0 |
| agentd-full-lib-v2 | 0 | 760 |
| root-learning-v2 | 0 | 3 |
| agentd-bins-check-v2 | 0 | 0 |
| scoped-fix-v1 | 0 | 0 |
| changed-fmt-v1 | 0 | 0 |
| agentd-bins-check-v3-renamed | 0 | 0 |

The ordinary raw log independently reports **760 PASS and 64 skipped**.
The 760 unique result names exactly match both JUnit and `executed-cases.json`.
The dedicated Root run has **3 unique parent PASS**, **821 unselected**; its names
also agree across all three artifacts. The two runs total **763 unique top-level PASS**.
JUnit does not include the skipped/unselected cases as executed testcase elements.

The child output records UID **60001**, child PID **2835420**, original Root PID
**2835418**, `sealed=true`, and `cloexec=true`. The embedded tested source performs
actual credential and original-pidfd assertions. Its nested test succeeds and is
not counted as a fourth Root parent. Root success output repeats parent PASS lines
following the summary; those repetitions are excluded from the count.

`agentd-full-lib-v1` failed test compilation with E0599 (`Sha256Digest` lacks
`Display`), exit 101, **zero executed tests**, and no JUnit. The separate earlier
`compile-only-v1` command is a successful pre-freeze bins check, not that failure.

## Maintenance and scope limits

Fix and fmt records both return zero. The empty fmt log is recorded accurately.
The 17 embedded maintenance payloads match their before/after inventory identities.
Both post-maintenance source changes are exactly the `into_runtime` to
`into_learning_runtime` identifier rename; the final renamed bins check exits zero.
No post-maintenance test rerun is recorded. Test results bind manifest
`6d63b225d311abe5eb5dde8748376888d8c95b4d2ad97f3a3aa7c7e0caa6a360`; final compile results bind
`4cd123acf4cb4133c846600e6564a922c8001d62d52f926d1e05262c0a778925`.

The reused `hepta-joint-propose` helper was **not rebuilt this task**. Its 21 source
hashes match the tested inventory. The archive records the prior binary/build
identities but does not contain the binary or original build log for a fresh rehash.

The direct Root UDS fixture covers actual protected CAS, descriptor/pidfd custody
and checkpoint recovery with synthetic scope metadata. It does not qualify the
complete deployed writer registration, live-lease and listener path, real stage
owners, independent evaluation/attestation, ordinary daemon learning, or publication.
Full local/native codex-rs projection is checked separately; this review did not
repeat it. This reviewer executed no tests/builds and modified no repository code.
