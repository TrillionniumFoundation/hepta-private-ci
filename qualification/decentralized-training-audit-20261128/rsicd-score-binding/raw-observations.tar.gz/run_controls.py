"""Run bounded synthetic integrity controls; never train or instantiate a model."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import resource
import sys
import time
import traceback
import unittest

BASE = Path(__file__).resolve().parent
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
CASE_ROOT = BASE / "evidence" / "run-1"
CASE_ROOT.mkdir(parents=True, exist_ok=False)
SOURCE_PATHS = sorted(
    list((BASE / "original").rglob("*.py")) + list((BASE / "candidate").rglob("*.py"))
) + [Path(__file__).resolve()]


def hashes():
    return {
        str(path.relative_to(BASE)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in SOURCE_PATHS
    }


def run():
    before = hashes()
    started = time.perf_counter()
    test_path = BASE / "candidate/qualification/hcsn_sustained_20261128/rsicd_external/test_evaluate_cache.py"
    spec = importlib.util.spec_from_file_location("test_evaluate_cache", test_path)
    tests = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = tests
    spec.loader.exec_module(tests)
    import numpy as np
    import torch

    original_path = BASE / "original/qualification/hcsn_sustained_20261128/rsicd_external/evaluate.py"
    legacy = tests.load_evaluator(original_path)
    normal = tests.CachedPanel(legacy, CASE_ROOT / "baseline-valid")
    normal_result = normal.run()
    wrong = tests.CachedPanel(legacy, CASE_ROOT / "baseline-misdirected")
    wrong.change_target(score_file=wrong.alternate.name)
    wrong_result = wrong.run()
    with np.load(wrong.target.with_suffix(".npz")) as a, np.load(wrong.alternate) as b:
        expected = float(np.mean((b["aligned_cider"] - a["aligned_cider"]) / len(legacy.SEEDS)))
    actual = wrong_result["paired_image_deltas"]["best"]["literal-minus-smooth"]["cider"][0]
    if abs(actual - expected) > 1e-12 or actual == 0.0:
        raise AssertionError(("misdirection baseline not reproduced", actual, expected))
    if wrong.alternate not in wrong.loads:
        raise AssertionError("the original aggregator did not consume the different file")
    if normal_result["averages"] != wrong_result["averages"]:
        raise AssertionError("cached JSON means unexpectedly changed")
    if normal.model_calls != 0 or wrong.model_calls != 0:
        raise AssertionError("unexpected model construction")
    baseline = {
        "status": "BUG_REPRODUCED",
        "subject_commit": "24ac9e35603ecb8d6a96377394fb3d7feba6a5ec",
        "subject_git_blob_oid": "0120c439acbdf7a699ebec16c91cce9128b232bf",
        "expected_score_file": wrong.target.with_suffix(".npz").name,
        "consumed_different_file": wrong.alternate.name,
        "different_file_load_count": sum(p == wrong.alternate for p in wrong.loads),
        "expected_paired_cider_mean": expected,
        "actual_paired_cider_mean": actual,
        "cached_json_means_unchanged": True,
        "model_constructions": 0,
        "scientific_model_or_quality_evidence": False,
    }
    (CASE_ROOT / "baseline.json").write_text(json.dumps(baseline, indent=2) + "\n")

    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(tests.ScoreCacheBindingTests)
    test_started = time.perf_counter()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    test_elapsed = time.perf_counter() - test_started
    (CASE_ROOT / "unittest.log").write_text(stream.getvalue())
    after = hashes()
    if before != after:
        raise AssertionError("tested source changed during execution")
    summary = {
        "baseline": baseline,
        "candidate": {
            "tests_run": result.testsRun,
            "failures": len(result.failures),
            "errors": len(result.errors),
            "skipped": len(result.skipped),
            "successful": result.wasSuccessful(),
            "elapsed_s": test_elapsed,
        },
        "runtime": {
            "executable": sys.executable,
            "python": platform.python_version(),
            "numpy": np.__version__,
            "torch": torch.__version__,
            "cpu_affinity": sorted(os.sched_getaffinity(0)),
            "nice": os.getpriority(os.PRIO_PROCESS, 0),
            "thread_env": {
                key: os.environ.get(key)
                for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")
            },
            "max_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        },
        "elapsed_s_including_import_and_baselines": time.perf_counter() - started,
        "source_sha256": before,
        "source_unchanged_during_execution": True,
        "new_model_training": False,
        "new_model_inference": False,
    }
    (CASE_ROOT / "RESULTS.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(stream.getvalue(), end="")
    print(json.dumps(summary, indent=2))
    if result.testsRun != 6 or not result.wasSuccessful():
        return 1
    return 0


if __name__ == "__main__":
    try:
        sys.exit(run())
    except Exception:
        details = traceback.format_exc()
        (CASE_ROOT / "execution-error.log").write_text(details)
        print(details, file=sys.stderr)
        sys.exit(1)
