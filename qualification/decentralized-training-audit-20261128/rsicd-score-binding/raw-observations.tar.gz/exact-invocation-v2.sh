/usr/bin/nice -n 10 /home/qian-qi/hcsn-e901-torch280-cpu-runtime-20261112/bin/python run_controls_v2.py > execution-v2.stdout 2> execution-v2.stderr
hepta_control_v2_exit=$?
/home/qian-qi/hcsn-e901-torch280-cpu-runtime-20261112/bin/python - "$hepta_control_v2_exit" <<'HEPTA_RSICD_EXIT_V2_5BDF'
import json,sys
from pathlib import Path
result={'exit_code':int(sys.argv[1]),'command':['/usr/bin/nice','-n','10','/home/qian-qi/hcsn-e901-torch280-cpu-runtime-20261112/bin/python','run_controls_v2.py']}
Path('execution-v2.exit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
HEPTA_RSICD_EXIT_V2_5BDF
