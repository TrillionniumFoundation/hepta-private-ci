/usr/bin/nice -n 10 /home/qian-qi/hcsn-e901-torch280-cpu-runtime-20261112/bin/python run_controls.py > execution.stdout 2> execution.stderr
hepta_control_exit=$?
/home/qian-qi/hcsn-e901-torch280-cpu-runtime-20261112/bin/python - "$hepta_control_exit" <<'HEPTA_RSICD_EXIT_5BDF'
import json,sys
from pathlib import Path
result={'exit_code':int(sys.argv[1]),'command':['/usr/bin/nice','-n','10','/home/qian-qi/hcsn-e901-torch280-cpu-runtime-20261112/bin/python','run_controls.py']}
Path('execution.exit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
HEPTA_RSICD_EXIT_5BDF
