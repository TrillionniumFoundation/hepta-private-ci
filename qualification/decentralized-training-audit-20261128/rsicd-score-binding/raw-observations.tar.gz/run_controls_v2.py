"""Second integrity round: freeze NPZ bytes and reproduce post-check replacement."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import resource
import sys
import time
import traceback
import unittest

BASE = Path(__file__).resolve().parent
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
CASE_ROOT = BASE / "evidence" / "run-2"
CASE_ROOT.mkdir(parents=True, exist_ok=False)
SOURCE_PATHS = sorted(
    list((BASE / "original").rglob("*.py"))
    + list((BASE / "v1-tested").rglob("*.py"))
    + list((BASE / "candidate").rglob("*.py"))
) + [Path(__file__).resolve()]


def hashes():
    return {
        str(path.relative_to(BASE)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in SOURCE_PATHS
    }


def run():
    before = hashes()
    started = time.perf_counter()
    test_path = BASE / "candidate/qualification/hcsn_sustained_20261128/rsicd_external/test_evaluate_cache.py"
    spec = importlib.util.spec_from_file_location("test_evaluate_cache", test_path)
    tests = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = tests
    spec.loader.exec_module(tests)
    import numpy as np
    import torch

    v1_path = BASE / "v1-tested/qualification/hcsn_sustained_20261128/rsicd_external/evaluate.py"
    v1 = tests.load_evaluator(v1_path)
    panel = tests.CachedPanel(v1, CASE_ROOT / "baseline-same-path-replacement")
    selected = panel.target.with_suffix(".npz")
    expected_digest = v1.sha(selected)
    expected_mean = float(np.mean(
        (panel.alternate_arrays["aligned_cider"] - panel.arrays["aligned_cider"]) / len(v1.SEEDS)
    ))
    replacements = []

    def replace_after_digest(path):
        if Path(path) == selected and not replacements:
            selected.write_bytes(panel.alternate.read_bytes())
            replacements.append(str(selected))

    result = panel.run(before_load=replace_after_digest)
    actual_mean = result["paired_image_deltas"]["best"]["literal-minus-smooth"]["cider"][0]
    if len(replacements) != 1 or abs(actual_mean - expected_mean) > 1e-12 or actual_mean == 0.0:
        raise AssertionError(("same-path baseline not reproduced", replacements, actual_mean, expected_mean))
    if v1.sha(selected) == expected_digest or panel.model_calls != 0:
        raise AssertionError("replacement or zero-inference boundary")
    baseline = {
        "status": "BUG_REPRODUCED",
        "subject": "previously tested first patch, with verified Path but no immutable bytes",
        "subject_sha256": hashlib.sha256(v1_path.read_bytes()).hexdigest(),
        "selected_path": selected.name,
        "replacement_count": len(replacements),
        "replacement_checkpoint": "np.load entry after cache SHA checks",
        "expected_paired_cider_mean": expected_mean,
        "actual_paired_cider_mean": actual_mean,
        "model_constructions": 0,
        "scientific_model_or_quality_evidence": False,
    }
    (CASE_ROOT / "baseline.json").write_text(json.dumps(baseline, indent=2) + "\n")
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(tests.ScoreCacheBindingTests)
    test_started = time.perf_counter()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    test_elapsed = time.perf_counter() - test_started
    (CASE_ROOT / "unittest.log").write_text(stream.getvalue())
    after = hashes()
    if before != after:
        raise AssertionError("tested source changed during execution")
    summary = {
        "baseline": baseline,
        "candidate": {
            "tests_run": result.testsRun,
            "failures": len(result.failures),
            "errors": len(result.errors),
            "skipped": len(result.skipped),
            "successful": result.wasSuccessful(),
            "elapsed_s": test_elapsed,
        },
        "runtime": {
            "executable": sys.executable,
            "python": platform.python_version(),
            "numpy": np.__version__,
            "torch": torch.__version__,
            "cpu_affinity": sorted(os.sched_getaffinity(0)),
            "nice": os.getpriority(os.PRIO_PROCESS, 0),
            "thread_env": {
                key: os.environ.get(key)
                for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")
            },
            "max_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        },
        "elapsed_s_including_import_and_baseline": time.perf_counter() - started,
        "source_sha256": before,
        "source_unchanged_during_execution": True,
        "new_model_training": False,
        "new_model_inference": False,
        "previous_round_results": "evidence/run-1/RESULTS.json",
    }
    (CASE_ROOT / "RESULTS.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(stream.getvalue(), end="")
    print(json.dumps(summary, indent=2))
    if result.testsRun != 7 or not result.wasSuccessful():
        return 1
    return 0


if __name__ == "__main__":
    try:
        sys.exit(run())
    except Exception:
        details = traceback.format_exc()
        (CASE_ROOT / "execution-error.log").write_text(details)
        print(details, file=sys.stderr)
        sys.exit(1)
