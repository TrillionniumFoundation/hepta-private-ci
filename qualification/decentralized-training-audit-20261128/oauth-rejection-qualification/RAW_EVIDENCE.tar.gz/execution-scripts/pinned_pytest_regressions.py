import pathlib,json,hashlib,tomllib,urllib.request,subprocess,time,os,sys
owned=pathlib.Path.cwd()/'oauth-rejection'
bundle=json.loads((pathlib.Path.cwd()/'oauth-pytest-support-bundle.json').read_text())
assert bundle['source_ref']=='dee6b95562226ffd7a5d7d1ef7671130193f9535'
support=owned/'validation-support'
support.mkdir()
items=[]
for item in bundle['files']:
 data=item['content'].encode()
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['git_blob'],item['path']
 p=support/item['path'];p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes(data)
 items.append({'path':item['path'],'git_blob':item['git_blob'],'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'url':item['url']})
 if item['path']=='scripts/mcp_conformance/regression-baseline-v1.json':
  for side in ('before','candidate'):
   p=owned/side/item['path']
   assert not p.exists(),str(p)
   p.write_bytes(data)
preflight=bytes.fromhex('54726163656261636b20286d6f737420726563656e742063616c6c206c617374293a0d0a202046696c65201b5b33356d223c737464696e3e221b5b306d2c206c696e65201b5b33356d33351b5b306d2c20696e201b5b33356d3c6d6f64756c653e1b5b306d0d0a1b5b313b33356d417373657274696f6e4572726f721b5b306d3a201b5b33356d3f3f20736372697074732f6d63705f636f6e666f726d616e63652f0d0a1b5b306d0d0a')
(owned/'format_scope_preflight_original.log').write_bytes(preflight)
(owned/'FORMAT_SCOPE_PREFLIGHT_FAILURE.json').write_text(json.dumps({'status':'FAILED_BEFORE_FORMATTER','cause':'git status --porcelain collapsed the untracked scripts/mcp_conformance directory; executor expected individual file paths. Production source was not changed and just fmt was not called.','correction':'Use git status --porcelain --untracked-files=all for the exact two-path preflight.','pty_offset':28893,'pty_next_offset':29063,'log_sha256':hashlib.sha256(preflight).hexdigest(),'log_bytes':len(preflight)},indent=2)+'\n')
lock=tomllib.loads((support/'sdk/python/uv.lock').read_text())
names={'pytest','iniconfig','packaging','pluggy','pygments'}
selected={p['name']:p for p in lock['package'] if p['name'] in names}
assert set(selected)==names
assert selected['pytest']['version']=='9.0.3'
actual_deps={x['name'] for x in selected['pytest']['dependencies'] if 'marker' not in x}
assert actual_deps==names-{'pytest'}
assert sys.platform=='linux' and sys.version_info>=(3,11)
wheel_dir=owned/'pytest-wheels';wheel_dir.mkdir()
downloads=[]
for name,p in sorted(selected.items()):
 wheels=[w for w in p['wheels'] if w['url'].endswith('-py3-none-any.whl')]
 assert len(wheels)==1,(name,wheels)
 wheel=wheels[0]
 assert wheel['url'].startswith('https://files.pythonhosted.org/')
 with urllib.request.urlopen(wheel['url'],timeout=30) as response:
  data=response.read(wheel['size']+1)
 assert len(data)==wheel['size'],name
 assert 'sha256:'+hashlib.sha256(data).hexdigest()==wheel['hash'],name
 dest=wheel_dir/wheel['url'].rsplit('/',1)[1]
 with dest.open('xb') as f:f.write(data)
 downloads.append({'name':name,'version':p['version'],'path':str(dest),'url':wheel['url'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 print(json.dumps({'phase':'WHEEL_VERIFIED','name':name,'bytes':len(data)}),flush=True)
req=owned/'pytest-locked-requirements.txt'
req.write_text(''.join(x['name']+' @ '+pathlib.Path(x['path']).as_uri()+' --hash=sha256:'+x['sha256']+'\n' for x in downloads))
uv='/home/qq/hepta-audit-20261128-5bdf/root/format-tools/bin/uv'
venv=owned/'pytest-venv'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',UV_CACHE_DIR=str(owned/'pytest-cache'))
commands=[
 ('venv',[uv,'venv','--python','/usr/bin/python3',str(venv)],owned,60),
 ('install',[uv,'pip','install','--python',str(venv/'bin/python'),'--require-hashes','--no-deps','--no-index','-r',str(req)],owned,60),
 ('regressions',[str(venv/'bin/python'),'-m','pytest','-q','scripts/mcp_conformance/test_official_conformance.py','scripts/mcp_conformance/test_codex_compliance.py','scripts/mcp_conformance/test_auth_rejection_qualification.py'],owned/'candidate',120)
]
results=[]
for label,argv,cwd,deadline in commands:
 start=time.monotonic()
 result=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=deadline)
 elapsed=time.monotonic()-start
 streams={}
 for stream,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  p=owned/('pytest_'+label+'.'+stream+'.log')
  with p.open('xb') as f:f.write(data)
  streams[stream]={'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 row={'name':label,'argv':argv,'cwd':str(cwd),'exit_code':result.returncode,'wall_seconds':elapsed,'streams':streams}
 results.append(row)
 print(json.dumps(row),flush=True)
 if result.returncode:
  print(result.stdout.decode(errors='replace')[-20000:],flush=True)
  print(result.stderr.decode(errors='replace')[-10000:],flush=True)
  break
summary={'status':'PASS' if len(results)==3 and all(r['exit_code']==0 for r in results) else 'FAIL','base_ref':bundle['source_ref'],'python':sys.version,'original_sources':items,'lock_scope':'Only pytest and its complete active Linux/Python3.14 dependency closure from original sdk/python/uv.lock. This is not a full SDK dependency install or SDK/native test.','wheels':downloads,'commands':results,'environment_overrides':{'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','UV_CACHE_DIR':str(owned/'pytest-cache')},'production_source_sha256':hashlib.sha256((owned/'candidate/scripts/mcp_conformance/codex_conformance_adapter.py').read_bytes()).hexdigest(),'new_test_source_sha256':hashlib.sha256((owned/'candidate/scripts/mcp_conformance/test_auth_rejection_qualification.py').read_bytes()).hexdigest()}
(owned/'PYTEST_REGRESSION_RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'phase':'PYTEST_COMPLETE','status':summary['status']}),flush=True)
