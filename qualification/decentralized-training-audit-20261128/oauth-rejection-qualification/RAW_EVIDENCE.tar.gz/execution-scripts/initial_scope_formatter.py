import pathlib,hashlib,json,os,subprocess,shutil,time,ast
owned=pathlib.Path.cwd()/'oauth-rejection'
upstream=pathlib.Path('/home/qq/hepta-audit-20261128-5bdf/root')
record=json.loads((upstream/'FORMAT_SCOPE_RESULT.json').read_text())
work=owned/'format-worktree'
work.mkdir()
for item in record['support']:
 path=upstream/'format-worktree'/item['path']
 data=path.read_bytes()
 assert hashlib.sha256(data).hexdigest()==item['sha256'],item['path']
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['blob'],item['path']
 dest=work/item['path']
 dest.parent.mkdir(parents=True,exist_ok=True)
 dest.write_bytes(data)
old_venv=upstream/'format-worktree/scripts/.venv'
assert old_venv.is_dir(),'original format environment missing'
shutil.copytree(old_venv,work/'scripts/.venv',symlinks=True)
(work/'.gitignore').write_text('scripts/.venv/\n')
def run(argv,cwd=work,env=None):
 return subprocess.run(argv,cwd=cwd,env=env,capture_output=True,text=True,timeout=60,check=True)
run(['git','init','-q'])
run(['git','add','--','.'])
run(['git','-c','user.name=Audit format inventory','-c','user.email=audit-format@example.invalid','-c','commit.gpgsign=false','commit','-q','-m','Synthetic inventory for exact scoped formatter; not upstream source history'])
synthetic_head=run(['git','rev-parse','HEAD']).stdout.strip()
paths=['scripts/mcp_conformance/codex_conformance_adapter.py','scripts/mcp_conformance/test_auth_rejection_qualification.py']
before={}
for path in paths:
 data=(owned/'candidate'/path).read_bytes()
 before[path]={'sha256':hashlib.sha256(data).hexdigest(),'ast':ast.dump(ast.parse(data),include_attributes=False)}
 dest=work/path
 dest.parent.mkdir(parents=True,exist_ok=True)
 dest.write_bytes(data)
scope=run(['git','status','--porcelain']).stdout
expected={('?? '+p) for p in paths}
assert set(scope.splitlines())==expected,scope
env=dict(os.environ)
env['PATH']=str(upstream/'format-tools/bin')+':/home/qq/.cargo/bin:'+env['PATH']
env['UV_OFFLINE']='1'
env['UV_CACHE_DIR']=str(owned/'format-cache')
env['PYTHONDONTWRITEBYTECODE']='1'
results=[]
for label,args in [('fmt',[str(upstream/'format-tools/bin/just'),'fmt']),('fmt_check',[str(upstream/'format-tools/bin/just'),'fmt','--check'])]:
 start=time.monotonic()
 result=subprocess.run(args,cwd=work/'codex-rs',env=env,capture_output=True,timeout=60)
 elapsed=time.monotonic()-start
 streams={}
 for name,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  file=owned/('original_'+label+'.'+name+'.log')
  with file.open('xb') as f:f.write(data)
  streams[name]={'path':str(file),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 results.append({'argv':args,'cwd':str(work/'codex-rs'),'exit_code':result.returncode,'wall_seconds':elapsed,'streams':streams})
 print(json.dumps(results[-1]),flush=True)
 if result.returncode!=0:
  print(result.stderr.decode(errors='replace'),flush=True)
  break
after=[]
if all(x['exit_code']==0 for x in results) and len(results)==2:
 for path in paths:
  data=(work/path).read_bytes()
  same=ast.dump(ast.parse(data),include_attributes=False)==before[path]['ast']
  assert same,path
  (owned/'candidate'/path).write_bytes(data)
  after.append({'path':path,'before_sha256':before[path]['sha256'],'after_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'ast_identical':same})
fmt={'scope':'Actual original just fmt + --check on two untracked source files in a partial synthetic Git inventory; not whole-repository formatting. No tests rerun after formatting.','source_ref':'dee6b95562226ffd7a5d7d1ef7671130193f9535','support':record['support'],'support_verified_against_dee6':True,'commands':results,'files':after,'synthetic_git_head':synthetic_head,'actual_initial_scope':scope,'environment_overrides':{'PATH_prefix':str(upstream/'format-tools/bin')+':/home/qq/.cargo/bin','UV_OFFLINE':'1','UV_CACHE_DIR':str(owned/'format-cache'),'PYTHONDONTWRITEBYTECODE':'1'},'existing_formatter_environment':str(old_venv),'status':'PASS' if len(after)==2 else 'FAIL'}
(owned/'FORMAT_SCOPE_RESULT.json').write_text(json.dumps(fmt,indent=2)+'\n')
print(json.dumps({'phase':'OAUTH_FORMAT_COMPLETE','status':fmt['status'],'files':after}),flush=True)
