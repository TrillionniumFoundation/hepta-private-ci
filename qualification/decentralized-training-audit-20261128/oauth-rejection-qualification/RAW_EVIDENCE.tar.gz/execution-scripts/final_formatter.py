import pathlib,json,hashlib,subprocess,os,time,ast
owned=pathlib.Path.cwd()/'oauth-rejection'
upstream=pathlib.Path('/home/qq/hepta-audit-20261128-5bdf/root')
work=owned/'format-worktree'
record=json.loads((upstream/'FORMAT_SCOPE_RESULT.json').read_text())
assert (owned/'PYTEST_REGRESSION_RESULTS.json').is_file()
assert json.loads((owned/'PYTEST_REGRESSION_RESULTS.json').read_text())['status']=='PASS'
paths=['scripts/mcp_conformance/codex_conformance_adapter.py','scripts/mcp_conformance/test_auth_rejection_qualification.py']
def git(args):
 return subprocess.run(['git']+args,cwd=work,capture_output=True,text=True,check=True,timeout=20).stdout
scope=git(['status','--porcelain','--untracked-files=all'])
assert set(scope.splitlines())=={'?? '+p for p in paths},scope
before={}
for p in paths:
 data=(owned/'candidate'/p).read_bytes()
 assert (work/p).read_bytes()==data,p
 before[p]={'sha256':hashlib.sha256(data).hexdigest(),'ast':ast.dump(ast.parse(data),include_attributes=False)}
for item in record['support']:
 data=(work/item['path']).read_bytes()
 assert hashlib.sha256(data).hexdigest()==item['sha256'],item['path']
env=dict(os.environ)
env['PATH']=str(upstream/'format-tools/bin')+':/home/qq/.cargo/bin:'+env['PATH']
env['UV_OFFLINE']='1'
env['UV_CACHE_DIR']=str(owned/'format-cache')
env['PYTHONDONTWRITEBYTECODE']='1'
results=[]
for label,argv in [('fmt',[str(upstream/'format-tools/bin/just'),'fmt']),('fmt_check',[str(upstream/'format-tools/bin/just'),'fmt','--check'])]:
 start=time.monotonic()
 result=subprocess.run(argv,cwd=work/'codex-rs',env=env,capture_output=True,timeout=60)
 elapsed=time.monotonic()-start
 streams={}
 for stream,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  p=owned/('original_'+label+'.'+stream+'.log')
  with p.open('xb') as f:f.write(data)
  streams[stream]={'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 results.append({'argv':argv,'cwd':str(work/'codex-rs'),'exit_code':result.returncode,'wall_seconds':elapsed,'streams':streams})
 print(json.dumps(results[-1]),flush=True)
 if result.returncode:
  print(result.stderr.decode(errors='replace'),flush=True)
  break
after=[]
if len(results)==2 and all(x['exit_code']==0 for x in results):
 for path in paths:
  data=(work/path).read_bytes()
  same=ast.dump(ast.parse(data),include_attributes=False)==before[path]['ast']
  assert same,path
  (owned/'candidate'/path).write_bytes(data)
  after.append({'path':path,'before_sha256':before[path]['sha256'],'after_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'ast_identical':same})
fmt={'scope':'Actual original just fmt + --check on two untracked source files in a partial synthetic Git inventory; not whole-repository formatting. All tests completed before these format commands; no tests rerun after formatting.','source_ref':'dee6b95562226ffd7a5d7d1ef7671130193f9535','support':record['support'],'support_verified_against_dee6':True,'commands':results,'files':after,'synthetic_git_head':git(['rev-parse','HEAD']).strip(),'actual_initial_scope':scope,'environment_overrides':{'PATH_prefix':str(upstream/'format-tools/bin')+':/home/qq/.cargo/bin','UV_OFFLINE':'1','UV_CACHE_DIR':str(owned/'format-cache'),'PYTHONDONTWRITEBYTECODE':'1'},'existing_formatter_environment_copied_readonly_from':str(upstream/'format-worktree/scripts/.venv'),'preflight_failure_preserved':'FORMAT_SCOPE_PREFLIGHT_FAILURE.json','status':'PASS' if len(after)==2 else 'FAIL'}
(owned/'FORMAT_SCOPE_RESULT.json').write_text(json.dumps(fmt,indent=2)+'\n')
print(json.dumps({'phase':'OAUTH_FORMAT_COMPLETE','status':fmt['status'],'files':after,'pytest_original_log':(owned/'pytest_regressions.stdout.log').read_text()}),flush=True)
