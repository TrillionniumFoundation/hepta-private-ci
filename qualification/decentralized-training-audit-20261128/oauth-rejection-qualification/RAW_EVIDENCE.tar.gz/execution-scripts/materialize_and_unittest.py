import pathlib,json,hashlib,time,subprocess,sys,os
root=pathlib.Path.cwd()
raw=(root/'oauth-rejection-bundle.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='78c0b6eaf76509796ae08895770abb1b9f75196969295983267001c4ca71bf0c'
bundle=json.loads(raw)
work=root/'oauth-rejection'
work.mkdir()
entries=[]
for item in bundle['original']:
 rel=pathlib.PurePosixPath(item['path'])
 assert not rel.is_absolute() and '..' not in rel.parts
 data=item['content'].encode()
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert blob==item['git_blob'],item['path']
 for side in ['before','candidate']:
  dest=work/side/item['path']
  dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as f:f.write(data)
 entries.append({'path':item['path'],'git_blob':blob,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'url':item['url']})
for item in bundle['candidate']:
 rel=pathlib.PurePosixPath(item['path'])
 assert not rel.is_absolute() and '..' not in rel.parts
 dest=work/'candidate'/item['path']
 dest.parent.mkdir(parents=True,exist_ok=True)
 data=item['content'].encode()
 if dest.exists():
  previous=next(x for x in entries if x['path']==item['path'])
  assert hashlib.sha256(dest.read_bytes()).hexdigest()==previous['sha256']
 dest.write_bytes(data)
manifest={'source_ref':bundle['source_ref'],'source_bundle_sha256':hashlib.sha256(raw).hexdigest(),'original':entries,'candidate':[{'path':x['path'],'sha256':hashlib.sha256(x['content'].encode()).hexdigest(),'bytes':len(x['content'].encode())} for x in bundle['candidate']]}
(work/'MATERIALIZED_SOURCES.json').write_text(json.dumps(manifest,indent=2)+'\n')
(work/'PROXY_OAUTH_BASELINE_FINDINGS.json').write_text(json.dumps(bundle['audit'],indent=2)+'\n')
print(json.dumps({'phase':'MATERIALIZED','work':str(work),'verified_originals':len(entries),'changed_files':len(bundle['candidate'])}),flush=True)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
baseline_code="""import json,sys
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import codex_conformance_adapter as adapter
class Client:
 def __init__(self): self.events=[]
 def request(self, method, params):
  assert method=='mcpServer/oauth/login'
  return {'id':1,'error':{'code':-32603,'message':'HTTP destination is outside the configured address capability','data':None}}
 def wait_for_notification(self,*args,**kwargs): raise AssertionError('wrong-stage error must not reach callback')
rows=[]
for scenario in sorted(adapter.EXPECTED_AUTH_REJECTION_SCENARIOS):
 detail=adapter._exercise_auth_scenario(Client(),scenario=scenario,workspace=Path('.'),timeout_seconds=2)
 rows.append({'scenario':scenario,'returned_normally':True,'detail':detail})
assert len(rows)==6 and all(x['detail'].startswith('rejected invalid authorization flow:') for x in rows)
print(json.dumps({'old_false_qualifications':len(rows),'scope':'Original Python adapter function with controlled actual public RPC error shape; no native OAuth execution','rows':rows},indent=2))
"""
(work/'baseline_repro.py').write_text(baseline_code)
commands=[
 ('baseline',[sys.executable,str(work/'baseline_repro.py'),str(work/'before/scripts/mcp_conformance')],work),
 ('qualification_controls',[sys.executable,'-m','unittest','discover','-s',str(work/'candidate/scripts/mcp_conformance'),'-p','test_auth_rejection_qualification.py','-v'],work)
]
results=[]
for name,argv,cwd in commands:
 start=time.monotonic()
 result=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=60)
 duration=time.monotonic()-start
 streams={}
 for stream,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  path=work/(name+'.'+stream+'.log')
  with path.open('xb') as f:f.write(data)
  streams[stream]={'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 record={'name':name,'argv':argv,'returncode':result.returncode,'wall_seconds':duration,'streams':streams}
 results.append(record)
 print(json.dumps(record),flush=True)
 if result.returncode!=0:
  print(result.stderr.decode(errors='replace')[-14000:],flush=True)
  break
summary={'source_ref':bundle['source_ref'],'source_manifest':'MATERIALIZED_SOURCES.json','python':sys.version,'results':results,'scope':'Python adapter behavior and owned loopback browser HTTP only; zero native or full conformance execution; correct semantic rejection qualification remains OPEN'}
(work/'LOCAL_VALIDATION_RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'phase':'VALIDATION_COMPLETE','result_path':str(work/'LOCAL_VALIDATION_RESULTS.json')}),flush=True)
