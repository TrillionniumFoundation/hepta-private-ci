import json,sys
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import codex_conformance_adapter as adapter
class Client:
 def __init__(self): self.events=[]
 def request(self, method, params):
  assert method=='mcpServer/oauth/login'
  return {'id':1,'error':{'code':-32603,'message':'HTTP destination is outside the configured address capability','data':None}}
 def wait_for_notification(self,*args,**kwargs): raise AssertionError('wrong-stage error must not reach callback')
rows=[]
for scenario in sorted(adapter.EXPECTED_AUTH_REJECTION_SCENARIOS):
 detail=adapter._exercise_auth_scenario(Client(),scenario=scenario,workspace=Path('.'),timeout_seconds=2)
 rows.append({'scenario':scenario,'returned_normally':True,'detail':detail})
assert len(rows)==6 and all(x['detail'].startswith('rejected invalid authorization flow:') for x in rows)
print(json.dumps({'old_false_qualifications':len(rows),'scope':'Original Python adapter function with controlled actual public RPC error shape; no native OAuth execution','rows':rows},indent=2))
