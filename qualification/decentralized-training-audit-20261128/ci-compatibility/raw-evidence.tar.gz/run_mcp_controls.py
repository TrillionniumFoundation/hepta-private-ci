"""Run the frozen two-target MCP migration through the repository test entrypoint."""
from pathlib import Path
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/5bdf905e9cad')
REPO = ROOT / 'hepta-ci-repair'
SOURCE = 'f74d0ccde0ac0ad9e1a9819a3bdec4d08ce39919'
OUT = ROOT / 'hepta-ci-evidence/mcp-controls-01'
TOOLS = ROOT / 'opaque-native-toolchain'
TARGET = Path('/tmp/hepta-opaque-native-target')

def git(*args):
    return subprocess.check_output(['git',*args], cwd=REPO, text=True).strip()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def resources():
    return dict(meminfo=Path('/proc/meminfo').read_text(),
                oom_kill=[line for line in Path('/proc/vmstat').read_text().splitlines() if line.startswith('oom_kill ')],
                workspace_free_bytes=shutil.disk_usage(REPO).free,
                tmp_free_bytes=shutil.disk_usage('/tmp').free)

def main():
    assert git('rev-parse','HEAD') == SOURCE and not git('status','--porcelain')
    OUT.mkdir(exist_ok=False)
    with (TARGET / 'debug/.cargo-lock').open('a+b') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        fcntl.flock(lock,fcntl.LOCK_UN)
    paths = git('ls-files','codex-rs/rmcp-client','codex-rs/Cargo.toml','codex-rs/Cargo.lock','codex-rs/.config/nextest.toml','scripts/run-nextest.py','justfile','AGENTS.md').splitlines()
    before = {path:sha(REPO/path) for path in paths}
    env = dict(os.environ)
    settings = dict(CARGO_HOME=str(ROOT/'chain-cargo'),CARGO_TARGET_DIR=str(TARGET),
                    CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0',
                    BINDGEN_EXTRA_CLANG_ARGS='-isystem /usr/lib/gcc/x86_64-linux-gnu/14/include')
    env.update(settings)
    env['PATH'] = os.pathsep.join([str(TOOLS/'installed/bin'),str(TOOLS/'buildenv/bin'),str(ROOT/'learning-tools/bin'),env['PATH']])
    command = ['just','test','-p','codex-rmcp-client','--test','mcp_2026_message_limits','--test','mcp_2026_oauth_discovery','--locked']
    frozen = dict(source_commit=SOURCE,source_tree=git('rev-parse','HEAD^{tree}'),
                  command=command,environment=settings,target_realpath=str(TARGET.resolve()),
                  rustc=subprocess.check_output([str(TOOLS/'installed/bin/rustc'),'-Vv'],text=True),
                  source_before=before,resources_before=resources(),runner_sha256=sha(Path(__file__)),
                  protocol='Original repository nextest profile and controls; no test exclusions or added retry/timeout relaxation.')
    (OUT/'FROZEN.json').write_text(json.dumps(frozen,indent=2)+'\n')
    junit = TARGET/'nextest/local/junit.xml'
    if junit.is_file():
        shutil.copyfile(junit,OUT/'borrowed-junit-before.xml')
    started = time.monotonic_ns()
    print(json.dumps({'event':'started','command':command,'source':SOURCE}),flush=True)
    with (OUT/'native.log').open('wb') as output:
        process = subprocess.Popen(command,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT)
        _,status,usage = os.wait4(process.pid,0)
        exit_code = os.waitstatus_to_exitcode(status)
        process.returncode = exit_code
    after = {path:sha(REPO/path) for path in paths}
    unchanged = before == after and git('rev-parse','HEAD') == SOURCE and not git('status','--porcelain')
    result = dict(source_commit=SOURCE,source_tree=frozen['source_tree'],exit_code=exit_code,duration_ns=time.monotonic_ns()-started,
                  source_unchanged=unchanged,source_after=after,resources_after=resources(),
                  log_sha256=sha(OUT/'native.log'),log_bytes=(OUT/'native.log').stat().st_size,
                  child_usage={name:getattr(usage,name) for name in ['ru_utime','ru_stime','ru_maxrss','ru_minflt','ru_majflt','ru_inblock','ru_oublock']})
    if junit.is_file():
        shutil.copyfile(junit,OUT/'junit-after.xml')
        result['junit_sha256']=sha(OUT/'junit-after.xml')
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['source_after','resources_after']}),flush=True)
    raise SystemExit(exit_code or (0 if unchanged else 1))

if __name__ == '__main__':
    main()
