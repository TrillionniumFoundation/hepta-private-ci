import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile


ROOT = Path('/workspace/scratch/5bdf905e9cad')
REPO = ROOT / 'hepta-ci-repair'
OUT = ROOT / 'hepta-ci-evidence'
BASE = '1383c6f4cdd271bc8eabffe664892b9b5e878749'
HEAD = 'f74d0ccde0ac0ad9e1a9819a3bdec4d08ce39919'
TREE = '76ce2459c31f9f84c30ad8e0928d976b024c8c7d'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def entry(path, relative_to=OUT):
    data = path.read_bytes()
    return {'path': str(path.relative_to(relative_to)),
            'bytes': len(data), 'sha256': digest(data)}


assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
assert not git('status', '--porcelain')
git('diff', '--check', BASE, HEAD)

classification_path = OUT / 'CI_CLASSIFICATION.json'
classification = json.loads(classification_path.read_text())
for item in classification['classes']:
    if item['id'] in {'MCP_TYPED_DISCOVERY_ERROR', 'MCP_HTTP_ERROR_BODY_BOUND'}:
        item['status'] = 'LOCAL_COMMITTED_BUILD_SIGKILL_BEFORE_TEST_EXECUTION'
        item['local_validation'] = {
            'source_commit': HEAD, 'source_tree': TREE,
            'exit_code': 101, 'duration_ns': 155122576309,
            'failed_dependency': 'rama-http', 'signal': 9,
            'tests_executed': 0,
            'result': 'mcp-controls-01/RESULT.json',
            'reason': 'rustc terminated by SIGKILL during dependency code generation; host oom_kill counter rose 29 to 30. This does not establish an assertion pass or fail.'}
        item['reason'] = item['reason'].replace('Draft ', 'Committed patch ')
classification_path.write_text(json.dumps(classification, indent=2) + '\n')

patch = git('diff', '--binary', BASE, HEAD)
(OUT / 'PUBLICATION.diff').write_bytes(patch)
files = []
b4_before = json.loads((OUT / 'repo-checks-fixed/source-before.json').read_text())
b4_after = json.loads((OUT / 'repo-checks-fixed/source-after.json').read_text())
frozen = json.loads((OUT / 'mcp-controls-01/FROZEN.json').read_text())
result = json.loads((OUT / 'mcp-controls-01/RESULT.json').read_text())
assert result['source_unchanged']
for path in git('diff', '--name-only', BASE, HEAD).decode().splitlines():
    f = entry(REPO / path, REPO)
    f['base_blob'] = git('rev-parse', f'{BASE}:{path}').decode().strip()
    f['git_blob'] = git('rev-parse', f'{HEAD}:{path}').decode().strip()
    assert git('show', f'{HEAD}:{path}') == (REPO / path).read_bytes()
    if path.startswith('qa/'):
        assert b4_before[path] == b4_after[path] == f['sha256']
        f['validation'] = 'Original B4 roster passed 125/125 on these exact bytes before commit; no change since.'
    else:
        assert frozen['source_before'][path] == result['source_after'][path] == f['sha256']
        f['validation'] = 'Exact bytes frozen for first native build; dependency SIGKILL prevented all test execution.'
    files.append(f)

evidence_paths = [
    'B4_PATCH.diff', 'B4_PATCH_MANIFEST.json', 'CI_CLASSIFICATION.json',
    'RESOURCE_CLEANUP_20261128.json', 'AI395_READ_ONLY_FALLBACK.json',
    'CARGO_DENY_LOG_FALLBACK.json', 'cargo-deny-gh.stderr.log',
    'RUSTSEC_TRACKED_LOCK_COMPARISON.json',
    'job-140961221223.log', 'job-140961221297.log',
    'job-140961221528.log', 'job-140961221570.log',
    'mcp-controls-01/FROZEN.json', 'mcp-controls-01/RESULT.json',
    'mcp-controls-01/native.log', 'run_mcp_controls.py',
    'repo-checks-fixed/FMT_RESULT.json', 'repo-checks-fixed/RESULT.json',
    'repo-checks-fixed/fmt.stderr.log', 'repo-checks-fixed/fmt.stdout.log',
    'repo-checks-fixed/source-after.json', 'repo-checks-fixed/source-before.json',
    'repo-checks-fixed/stderr.log', 'repo-checks-fixed/stdout.log',
    'cargo-deny-repro/OFFICIAL_RELEASE.json',
    'cargo-deny-repro/CHECK_RESULT.json', 'cargo-deny-repro/FETCH_DB_RESULT.json',
    'cargo-deny-repro/MISSING_CACHE.json',
    'cargo-deny-repro/check.stderr.log', 'cargo-deny-repro/check.stdout.log',
    'cargo-deny-repro/fetch-db.stderr.log', 'cargo-deny-repro/fetch-db.stdout.log',
    'cargo-deny-repro/cargo-deny-0.19.0-advisory-db.rs',
    'cargo-deny-repro/matrix-sdk-0.20.0.Cargo.toml',
    'cargo-deny-repro/fetch_db.py', 'cargo-deny-repro/repro.py',
    'cargo-deny-action/Dockerfile', 'cargo-deny-action/action.yml',
    'PUBLICATION.diff', 'prepare_publication.py',
]
evidence_paths += [str(p.relative_to(OUT)) for p in sorted((OUT / 'rustsec-tracked').glob('*.md'))]
assert len(evidence_paths) == len(set(evidence_paths))
evidence = [entry(OUT / p) for p in sorted(evidence_paths)]
archive_path = OUT / 'PUBLICATION_EVIDENCE.tar.gz'
with archive_path.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
        with tarfile.open(mode='w', fileobj=gz, format=tarfile.USTAR_FORMAT) as tar:
            for item in evidence:
                payload = (OUT / item['path']).read_bytes()
                info = tarfile.TarInfo(item['path'])
                info.size = len(payload)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(payload))
with tarfile.open(archive_path, 'r:gz') as tar:
    assert sorted(tar.getnames()) == sorted(evidence_paths)
    for item in evidence:
        assert digest(tar.extractfile(item['path']).read()) == item['sha256']

manifest = {
    'schema': 'hepta-ci-reviewable-publication-v1',
    'repository': 'TrillionniumFoundation/hepta-private-ci',
    'pull_request': 7261, 'base_commit': BASE,
    'local_branch': 'fix/hepta-ci-source-gates-20261128-5bdf',
    'local_commit': HEAD, 'local_tree': TREE,
    'commits': ['3331112f1a1dc71b30ed2cc9fb1d8a10a8b3d5f9', HEAD],
    'publication_by_parent_pending': True,
    'source_worktree_clean': True,
    'scope': 'Five existing verification files only. Explicit independent B4 source-roster declarations and MCP assertions updated to current actual error domains and body caps. No production source, dependency, workflow, test selection, timeout or security policy changes.',
    'files': files,
    'diff': entry(OUT / 'PUBLICATION.diff'),
    'diff_stat': git('diff', '--stat', BASE, HEAD).decode(),
    'validation': {
        'b4': {'passed': 125, 'failed': 0, 'duration_ns': 18408211342,
               'native_authority_effects_qualified': False,
               'source_identity_note': 'RESULT source_commit names the clean base before patch commit. Its patch digest and complete 10758-file before/after maps bind the actual tested modified tree; all three B4 publication files match those maps.'},
        'mcp': {'command': frozen['command'], 'tests_executed': 0,
                'exit_code': 101, 'duration_ns': 155122576309,
                'rustc_signal': 9, 'failed_dependency': 'rama-http',
                'host_oom_kill_before': 29, 'host_oom_kill_after': 30,
                'source_unchanged': True,
                'status': 'BUILD_BLOCKED_NO_TEST_RESULT',
                'retry_started': False,
                'retry_note': 'Prepared runner never launched; parent requested publication with the original failure preserved instead of another local compile.'},
        'fmt': 'just fmt exited 0; it reported no changed Rust files needing formatting for B4. The MCP incremental fmt and git diff --check passed before f74 commit; no claim of a full-workspace format run.',
        'full_ci_qualified': False,
    },
    'original_ci': {'run_id': 46138718716,
                    'head': BASE, 'merge_checkout': 'a9eb90bacee91535d379f13e7daf528c6c89402e',
                    'source_correspondence_note': 'Relevant original sources were unchanged from PR base; no independently rerun baseline workflow is claimed.'},
    'remaining_open': [
        'MCP assertion migrations have no local native test result; original remote gates remain required.',
        'Legacy SSE local body-limit error propagation: separate uncompiled draft, excluded from this package.',
        'Five restricted proxy functional controls require a safe capability implementation or explicit fixture transport.',
        'SDK OAuth conformance subprocess fixture uses distinct loopback origins without an explicit capability.',
        'Original cargo-deny raw log and original RustSec database revision unknown; current frozen repro stopped before checks on missing cached packages.',
        'Full CI, including other platform jobs, is not qualified by this package.',
    ],
    'resource_record': {
        'cleanup': 'RESOURCE_CLEANUP_20261128.json',
        'deleted_allocated_bytes': 513794048,
        'remote_read_only': 'AI395_READ_ONLY_FALLBACK.json',
        'remote_execution_started': False,
        'target_coordination_lease': 'audit_chain; no active Rust job; no new compile authorized now',
        'visible_process_evidence_scope': 'Cleanup used exact hashes, released prior owner, current coordination lease, conservative dependency exclusion and visible process references. Namespace-local process visibility is not a global host assertion.'
    },
    'evidence_archive': entry(archive_path),
    'evidence': evidence,
    'excluded': ['hepta-sse-draft', 'unstarted run_mcp_controls_retry.py',
                 'zero-byte cargo-deny gh attempt is not a raw job log',
                 'shared or deleted build caches and tool binaries'],
}
(OUT / 'PUBLICATION_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'manifest': str(OUT / 'PUBLICATION_MANIFEST.json'),
                  'manifest_sha256': digest((OUT / 'PUBLICATION_MANIFEST.json').read_bytes()),
                  'changed_files': len(files),
                  'archive': manifest['evidence_archive'],
                  'evidence_files': len(evidence)}, indent=2))
