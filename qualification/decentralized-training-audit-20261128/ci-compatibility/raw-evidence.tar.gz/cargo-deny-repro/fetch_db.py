from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/workspace/scratch/5bdf905e9cad')
EVIDENCE = ROOT / 'hepta-ci-evidence/cargo-deny-repro'
CARGO = EVIDENCE / 'cargo-home'
CARGO.mkdir(exist_ok=True)
for name in ['registry', 'git']:
    dest = CARGO / name
    if not dest.exists():
        dest.symlink_to(ROOT / 'chain-cargo' / name, target_is_directory=True)
env = os.environ.copy()
env['CARGO_HOME'] = str(CARGO)
env['PATH'] = str(ROOT / 'opaque-native-toolchain/installed/bin') + os.pathsep + env['PATH']
env['RUSTC'] = str(ROOT / 'opaque-native-toolchain/installed/bin/rustc')
binary = EVIDENCE / 'installed/cargo-deny-0.19.0-x86_64-unknown-linux-musl/cargo-deny'
command = [str(binary), '--manifest-path', str(ROOT / 'hepta-ci-repair/codex-rs/Cargo.toml'), 'fetch', 'db']
start = time.monotonic_ns()
with (EVIDENCE / 'fetch-db.stdout.log').open('wb') as out, (EVIDENCE / 'fetch-db.stderr.log').open('wb') as err:
    try:
        result = subprocess.run(command, cwd=ROOT / 'hepta-ci-repair/codex-rs', env=env, stdout=out, stderr=err, timeout=120)
        status = {'exit_code': result.returncode, 'timeout': False}
    except subprocess.TimeoutExpired:
        status = {'exit_code': None, 'timeout': True}
status.update(command=command, duration_ns=time.monotonic_ns()-start, binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
(EVIDENCE / 'FETCH_DB_RESULT.json').write_text(json.dumps(status, indent=2)+'\n')
print(json.dumps(status))
