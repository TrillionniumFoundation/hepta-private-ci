from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/workspace/scratch/5bdf905e9cad')
EVIDENCE = ROOT / 'hepta-ci-evidence/cargo-deny-repro'
REPO = ROOT / 'hepta-ci-repair'
DB = EVIDENCE / 'cargo-home/advisory-dbs/advisory-db-3157b0e258782691'
PIN = '3eebb903ba6c43f60c57dc0e15fa61eef06231d1'
def git(*args, cwd=REPO):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()
assert git('rev-parse', 'HEAD', cwd=DB) == PIN
assert git('status', '--porcelain', cwd=DB) == ''
env = os.environ.copy()
env['CARGO_HOME'] = str(EVIDENCE / 'cargo-home')
env['PATH'] = str(ROOT / 'opaque-native-toolchain/installed/bin') + os.pathsep + env['PATH']
env['RUSTC'] = str(ROOT / 'opaque-native-toolchain/installed/bin/rustc')
binary = EVIDENCE / 'installed/cargo-deny-0.19.0-x86_64-unknown-linux-musl/cargo-deny'
command = [str(binary), '--log-level', 'warn', '--manifest-path', './codex-rs/Cargo.toml', '--all-features', '--frozen', 'check', '--config', './codex-rs/deny.toml', '--disable-fetch', '--show-stats']
paths = [REPO/'codex-rs/Cargo.toml', REPO/'codex-rs/Cargo.lock', REPO/'codex-rs/deny.toml']
before = {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
start = time.monotonic_ns()
with (EVIDENCE / 'check.stdout.log').open('wb') as out, (EVIDENCE / 'check.stderr.log').open('wb') as err:
    try:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=out, stderr=err, timeout=180)
        status = {'exit_code': result.returncode, 'timeout': False}
    except subprocess.TimeoutExpired:
        status = {'exit_code': None, 'timeout': True}
after = {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
status.update(command=command, duration_ns=time.monotonic_ns()-start, before=before, after=after, inputs_unchanged=before==after, db_commit=PIN, db_tree=git('rev-parse','HEAD^{tree}',cwd=DB), source_head=git('rev-parse','HEAD'), action_sha='82eb9f621fbc699dd0918f3ea06864c14cc84246', original_ci_db_revision='UNKNOWN', original_ci_checkout='a9eb90bacee91535d379f13e7daf528c6c89402e', extra_controls=['--frozen prevents Cargo.lock changes and registry network fetches', '--disable-fetch pins local RustSec DB; does not suppress any diagnostics', '--config names exact original config explicitly', '--show-stats adds reporting only'])
(EVIDENCE / 'CHECK_RESULT.json').write_text(json.dumps(status, indent=2)+'\n')
print(json.dumps(status))
