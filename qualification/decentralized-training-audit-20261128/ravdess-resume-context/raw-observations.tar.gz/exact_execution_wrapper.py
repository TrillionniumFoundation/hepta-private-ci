import json,os,subprocess,time
from pathlib import Path
base=Path.cwd()
args=["/usr/bin/nice","-n","10","/home/qian-qi/hcsn-e901-torch280-cpu-runtime-20261112/bin/python","run_resume_controls.py"]
environment=dict(os.environ)
for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):environment[name]="1"
started=time.perf_counter()
with (base/"execution.stdout").open("w") as output,(base/"execution.stderr").open("w") as error:
    result=subprocess.run(args,stdout=output,stderr=error,env=environment,timeout=60)
record={"args":args,"cwd":str(base),"exit_code":result.returncode,"elapsed_s":time.perf_counter()-started,
 "thread_limits":{name:environment[name] for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS")}}
(base/"execution.exit.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record),flush=True)
print((base/"execution.stdout").read_text(),flush=True)
print((base/"execution.stderr").read_text(),flush=True)
