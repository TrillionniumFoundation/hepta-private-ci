"""Reproduce the first candidate's two blocking JSON paths in owned child processes."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

BASE=Path(__file__).resolve().parent
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
ROOT=BASE/"evidence/fifo-baseline"
ROOT.mkdir(parents=True,exist_ok=False)
shutil.copytree(BASE/"candidate",BASE/"tested-v1",ignore=shutil.ignore_patterns("__pycache__"))
shutil.copyfile(BASE/"run_resume_controls.py",BASE/"run_resume_controls_v1.py")
child=r'''
import importlib.util,json,os,sys
from pathlib import Path
from unittest.mock import patch
test=Path(sys.argv[1]);base=Path(sys.argv[2]);mode=sys.argv[3]
spec=importlib.util.spec_from_file_location("fifo_baseline_subject",test)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
fixture=module.Fixture(base)
if mode=="source_models":
    fixture.complete()
    target=fixture.out/"source_models.json";target.unlink()
else:
    target=fixture.terminal
os.mkfifo(target)
ordinary=module.scorer.load
def observe(path):
    if path==target:print(json.dumps({"entered_regular_unchecked_json_load":str(path),"mode":mode}),flush=True)
    return ordinary(path)
with patch.object(module.scorer,"load",side_effect=observe):
    fixture.run()
print("UNEXPECTED_RETURN",flush=True)
'''
entries=[]
for mode in ("terminal","source_models"):
    args=[sys.executable,"-u","-c",child,str(BASE/"candidate/qualification/hcsn_sustained_20261128/ravdess/test_ravdess_resume.py"),str(ROOT/mode),mode]
    started=time.perf_counter()
    try:
        result=subprocess.run(args,capture_output=True,timeout=8)
        entry={"mode":mode,"outcome":"returned","exit_code":result.returncode,
               "stdout":result.stdout.decode(),"stderr":result.stderr.decode()}
    except subprocess.TimeoutExpired as error:
        entry={"mode":mode,"outcome":"deadline_after_entered_load","timeout_s":8,
               "stdout":(error.stdout or b"").decode(),"stderr":(error.stderr or b"").decode()}
    entry["elapsed_s"]=time.perf_counter()-started
    entry["reached_json_load"]='"entered_regular_unchecked_json_load"' in entry["stdout"]
    entries.append(entry)
record={"schema":"ravdess-first-candidate-json-fifo-baseline-v1",
        "candidate_sha256":hashlib.sha256((BASE/"candidate/qualification/hcsn_sustained_20261128/ravdess/score.py").read_bytes()).hexdigest(),
        "scope":"Owned synthetic fixture children only. Each child timeout kills and reaps that child; no external or scientific process.",
        "cases":entries}
(ROOT/"RESULTS.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2),flush=True)
if not all(x["outcome"]=="deadline_after_entered_load" and x["reached_json_load"] for x in entries):raise SystemExit(1)
