"""Run synthetic resume controls without scientific model construction or training."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import resource
import sys
import time
import unittest
from unittest.mock import patch

BASE=Path(__file__).resolve().parent
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
EVIDENCE=BASE/"evidence/run-2"
EVIDENCE.mkdir(parents=True,exist_ok=False)
paths=sorted(list((BASE/"original").rglob("*.py"))+list((BASE/"candidate").rglob("*.py")))+[Path(__file__).resolve()]
def hashes():return {str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=hashes();started=time.perf_counter()
test_path=BASE/"candidate/qualification/hcsn_sustained_20261128/ravdess/test_ravdess_resume.py"
spec=importlib.util.spec_from_file_location("test_ravdess_resume",test_path)
tests=importlib.util.module_from_spec(spec);sys.modules[spec.name]=tests;spec.loader.exec_module(tests)
legacy=tests.module_at("legacy_ravdess_score",BASE/"original/qualification/hcsn_sustained_20261128/ravdess/score.py")
fixture=tests.Fixture(EVIDENCE/"legacy-inner-baseline")
fixture.terminal.write_bytes(b"{}")
fixture.weights[0].write_bytes(b"Changed synthetic scalar; not valid model bytes.\n")
fixture.seal.unlink();fixture.selection_terminal.unlink()
modules,_=tests.scorer.source_modules(fixture.src,fixture.study,fixture.analytic)
with patch.dict(sys.modules,{name:modules[name] for name in ("encoder","encoder_adapter","study")}), \
     patch.object(sys,"path",list(sys.path)), \
     patch.object(legacy,"specifications",wraps=legacy.specifications) as selection, \
     patch.object(legacy,"score",side_effect=AssertionError("no inference")) as inference:
    baseline_return=legacy.run(fixture.root,fixture.src,fixture.study,fixture.analytic,fixture.kind)
baseline={"original_entry":"qualification/hcsn_sustained_20261128/ravdess/score.py",
          "original_git_blob":"a48c6f89e63379505699299fecf8782d1d71eafb",
          "fixture":"Explicit synthetic source modules and tiny genuine NPZ/scalar tensor files; no model",
          "terminal_bytes":fixture.terminal.read_text(),"return":baseline_return,
          "source_selection_files_exist":fixture.seal.exists() or fixture.selection_terminal.exists(),
          "changed_selected_weight":str(fixture.weights[0].relative_to(BASE)),
          "specifications_calls":selection.call_count,"inference_calls":inference.call_count}
(EVIDENCE/"BASELINE.json").write_text(json.dumps(baseline,indent=2)+"\n")
stream=io.StringIO();test_start=time.perf_counter()
suite=unittest.defaultTestLoader.loadTestsFromModule(tests)
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
test_elapsed=time.perf_counter()-test_start
(EVIDENCE/"unittest.log").write_text(stream.getvalue())
after=hashes()
record={"schema":"ravdess-resume-integrity-controls-v1",
        "source_base":"04968cc615f6a8c86e3ce501bb37bf53e34e0823",
        "source_manifest":json.loads((BASE/"source_manifest.json").read_text()),
        "scope":"Synthetic filesystem/context/receipt controls. Actual controller subprocess, checked scalar tensor loading, and original module definitions. Numerical score_panel is explicitly replaced; no scientific model construction, inference or training.",
        "tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped),
        "test_elapsed_s":test_elapsed,"total_elapsed_s":time.perf_counter()-started,
        "max_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "runtime":{"python":platform.python_version(),"numpy":tests.np.__version__,"torch":str(tests.torch.__version__)},
        "affinity":sorted(os.sched_getaffinity(0)),"nice":os.nice(0),
        "thread_limits":{key:os.environ.get(key) for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS")},
        "before":before,"after":after,"source_unchanged":before==after,"baseline":baseline,
        "scientific_model_forward_calls":0,"training_calls":0}
(EVIDENCE/"RESULTS.json").write_text(json.dumps(record,indent=2)+"\n")
print(stream.getvalue(),flush=True)
print(json.dumps({k:v for k,v in record.items() if k not in ("before","after","source_manifest")},indent=2),flush=True)
if not result.wasSuccessful() or before!=after:raise SystemExit(1)
