"""Integrity-only baseline for the original RAVDESS controller; no training or inference."""
import importlib.util
from pathlib import Path
import tempfile
from unittest.mock import patch

def reproduce(source_path):
    spec = importlib.util.spec_from_file_location("ravdess_complete_fixed_source", source_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    with tempfile.TemporaryDirectory() as temporary:
        base = Path(temporary)
        root = base / "ravdess"
        root.mkdir()
        (root / "prepared.json").write_text("not-json\n")
        source_markers = {
            "full": base / "hcsn-sustained-1140569/whole_edit/terminal.json",
            "analytic": base / "hcsn-analytic-encoder-1140569/run/terminal.json",
            "sustained": base / "hcsn-sustained-1140569/run/terminal.json",
        }
        for kind, marker in source_markers.items():
            marker.parent.mkdir(parents=True, exist_ok=True)
            marker.write_text("not-json\n")
            output = root / ("scores-" + kind)
            output.mkdir()
            (output / "terminal.json").write_text("not-json\n")
        with patch.object(module.subprocess, "run", side_effect=AssertionError("no jobs authorized")) as child:
            with patch.object(module.time, "sleep", side_effect=AssertionError("unexpected wait")):
                result = module.main(root)
        return {
            "controller_return": result,
            "validation_subprocess_count": child.call_count,
            "all_markers_invalid_json": True,
            "models_or_scores_supplied": False,
            "science_run": False,
        }
