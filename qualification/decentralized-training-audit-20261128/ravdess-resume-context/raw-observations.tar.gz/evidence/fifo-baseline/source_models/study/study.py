HASHES={'src/encoder.py': 'a02215cf79309f2dadad8415021b87c38691e35242596e42bfd881319b914c76', 'src/hcsn_temporal.py': '3fec5c6dced5fe08d5c415b29556ce8b3fbfa8f26641a023ef77475b17138d77', 'src/law4.npz': 'b0ed45c8de0a6deaa825e58a2665fb858b4fd561db0b69acedf85dad9bdc1254', 'data/data.npz': '10987aed2bae2694753112a434852be379453a87dd5f162e98743741fa5aaaaf'}
class Data:
 def __init__(self,*a):raise AssertionError('no science data loading in integrity controls')
