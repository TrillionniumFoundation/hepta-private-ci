from hcsn_temporal import MARKER
class AVText:
 def __init__(self,*a,**k):raise AssertionError('no model construction in integrity controls')
