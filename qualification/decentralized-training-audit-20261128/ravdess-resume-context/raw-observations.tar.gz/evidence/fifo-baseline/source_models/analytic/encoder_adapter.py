from encoder import AVText
from exact_law import value
class AnalyticAVText(AVText):pass
