"""Record one real, source-bound native validation attempt; never infer a pass."""

from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path("/workspace/scratch/5bdf905e9cad/hepta-opaque-native")
OUT = Path(__file__).resolve().parent
TOOLCHAIN = OUT.parent / "opaque-native-toolchain"

name = sys.argv[1]
assert name.replace("-", "").isalnum()
command = sys.argv[2:]
assert command and command[0] == "just"
assert not (OUT / (name + ".json")).exists()

paths = sorted(
    set(
        subprocess.check_output(
            ["git", "diff", "--name-only"], cwd=ROOT, text=True
        ).splitlines()
        + subprocess.check_output(
            ["git", "ls-files", "--others", "--exclude-standard"],
            cwd=ROOT,
            text=True,
        ).splitlines()
    )
)


def hashes():
    return {
        path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
        for path in paths
    }


include = subprocess.check_output(
    ["cc", "-print-file-name=include"], text=True
).strip()
assert (Path(include) / "stddef.h").is_file()
env = dict(os.environ)
env.update(
    PATH="%s:%s:%s:%s"
    % (
        TOOLCHAIN / "installed/bin",
        TOOLCHAIN / "buildenv/bin",
        OUT.parent / "learning-tools/bin",
        env["PATH"],
    ),
    CARGO_HOME=str(OUT.parent / "chain-cargo"),
    CARGO_TARGET_DIR="/tmp/hepta-opaque-native-target",
    CARGO_BUILD_JOBS="1",
    CARGO_PROFILE_DEV_DEBUG="0",
    CARGO_INCREMENTAL="0",
    BINDGEN_EXTRA_CLANG_ARGS="-isystem " + include,
)
record = {
    "base_commit": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip(),
    "argv": command,
    "files_before": hashes(),
    "started_at": time.time(),
    "target_realpath": str(Path(env["CARGO_TARGET_DIR"]).resolve()),
    "env": {
        key: env[key]
        for key in (
            "CARGO_HOME",
            "CARGO_TARGET_DIR",
            "CARGO_BUILD_JOBS",
            "CARGO_PROFILE_DEV_DEBUG",
            "CARGO_INCREMENTAL",
            "BINDGEN_EXTRA_CLANG_ARGS",
        )
    },
    "tools": {
        name: subprocess.check_output(argv, cwd=ROOT, env=env, text=True).strip()
        for name, argv in (
            ("rustc", ["rustc", "--version"]),
            ("nextest", ["cargo-nextest", "--version"]),
            ("cmake", ["cmake", "--version"]),
        )
    },
}
record_path = OUT / (name + ".json")
record_path.write_text(json.dumps(record, indent=2) + "\n")
started = time.monotonic()
with (OUT / (name + ".log")).open("w") as log:
    result = subprocess.run(
        command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT
    )
record.update(
    exit_code=result.returncode,
    finished_at=time.time(),
    seconds=time.monotonic() - started,
    files_after=hashes(),
)
after_paths = set(
    subprocess.check_output(
        ["git", "diff", "--name-only"], cwd=ROOT, text=True
    ).splitlines()
    + subprocess.check_output(
        ["git", "ls-files", "--others", "--exclude-standard"],
        cwd=ROOT,
        text=True,
    ).splitlines()
)
record["additional_dirty_files_after"] = {
    path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
    for path in sorted(after_paths.difference(paths))
}
record["source_unchanged"] = (
    record["files_before"] == record["files_after"]
    and not record["additional_dirty_files_after"]
)
record_path.write_text(json.dumps(record, indent=2) + "\n")
print(
    json.dumps(
        {
            key: record[key]
            for key in ("exit_code", "seconds", "source_unchanged")
        }
    )
)
raise SystemExit(result.returncode)
