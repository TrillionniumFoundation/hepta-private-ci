import hashlib, importlib.metadata, json, pathlib, platform, sys, time, urllib.request
root = pathlib.Path("/Users/qianqi/work/cell-stem-routes-20261108-5e692/semantic-serving")
root.mkdir(parents=True, exist_ok=True)
url = "https://huggingface.co/api/models/mlx-community/SmolLM2-135M-Instruct-4bit?blobs=true"
receipt = {"schema":"hepta.semantic-model-metadata.v1","source":url,"started_unix":time.time(),"status":"started"}
try:
    with urllib.request.urlopen(url, timeout=25) as response:
        data = response.read(2*1024*1024+1)
        if len(data)>2*1024*1024: raise ValueError("metadata exceeds cap")
        receipt["http_status"] = response.status
    info=json.loads(data)
    (root/"hf-model-metadata.json").write_bytes(data)
    receipt.update(status="success",revision=info.get("sha"),metadata_sha256=hashlib.sha256(data).hexdigest())
    files=[{"name":x["rfilename"],"size":x.get("size"),"blobId":x.get("blobId"),"lfs":x.get("lfs")} for x in info.get("siblings",[])]
    receipt.update(model_id=info.get("id"),private=info.get("private"),gated=info.get("gated"),files=files,total_bytes=sum(x["size"] or 0 for x in files))
    print(json.dumps(receipt,sort_keys=True),flush=True)
except Exception as exc:
    receipt.update(status="failure",error=type(exc).__name__+": "+str(exc)[:1000])
    print(json.dumps(receipt,sort_keys=True),flush=True)
finally:
    receipt["finished_unix"]=time.time()
    (root/"metadata-receipt.json").write_text(json.dumps(receipt,sort_keys=True,indent=2)+"\n")
versions={}
for name in ["mlx","mlx-lm","numpy","transformers","tokenizers","huggingface-hub","safetensors"]:
    try: versions[name]=importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError: versions[name]=None
runtime={"python":sys.version,"platform":platform.platform(),"packages":versions}
(root/"runtime-inventory.json").write_text(json.dumps(runtime,sort_keys=True,indent=2)+"\n")
print(json.dumps(runtime,sort_keys=True),flush=True)
