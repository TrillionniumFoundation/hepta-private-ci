import hashlib, json, pathlib, re, time, urllib.request
root = pathlib.Path("/Users/qianqi/work/cell-stem-routes-20261108-5e692/semantic-serving")
root.mkdir(parents=True, exist_ok=True)
model_id="mlx-community/SmolLM-135M-Instruct-4bit"
source="https://huggingface.co/api/models/"+model_id+"?blobs=true"
receipt={"schema":"hepta.semantic-model-download.v1","source":source,"model_id":model_id,"started_unix":time.time(),"status":"started","artifacts":[],"byte_limit":150_000_000,"hard_byte_limit":300_000_000,"retry_limit":0}
def save():
    (root/"download-receipt.json").write_text(json.dumps(receipt,sort_keys=True,indent=2)+"\n")
def request(url):
    return urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"hepta-cell-engineering-probe/1"}),timeout=30)
try:
    with request(source) as response: data=response.read(2*1024*1024+1)
    if len(data)>2*1024*1024: raise ValueError("metadata exceeds cap")
    info=json.loads(data)
    revision=info.get("sha")
    if info.get("private") or info.get("gated") or not isinstance(revision,str) or not re.fullmatch(r"[0-9a-f]{40}",revision):
        raise ValueError("model is not public ungated pinned repository")
    allowed={".gitattributes","README.md","config.json","generation_config.json","merges.txt","model.safetensors","model.safetensors.index.json","special_tokens_map.json","tokenizer.json","tokenizer_config.json","vocab.json"}
    files=info.get("siblings",[])
    if any(x.get("rfilename") not in allowed or type(x.get("size")) is not int or x["size"]<0 for x in files):
        raise ValueError("unexpected model artifact or missing size")
    size=sum(x["size"] for x in files)
    if not 0 < size <= receipt["byte_limit"]: raise ValueError("model exceeds download cap")
    (root/"smollm-hf-model-metadata.json").write_bytes(data)
    folder=root/("model-"+revision); folder.mkdir(exist_ok=True)
    receipt.update(revision=revision,total_expected_bytes=size,model_directory=str(folder),metadata_sha256=hashlib.sha256(data).hexdigest(),status="metadata_verified")
    save()
    print(json.dumps({k:v for k,v in receipt.items() if k!="artifacts"},sort_keys=True),flush=True)
    deadline=time.monotonic()+210
    for item in files:
        if time.monotonic()>deadline: raise TimeoutError("download wall deadline")
        name=item["rfilename"]; destination=folder/name
        if destination.exists(): raise ValueError("refusing to overwrite existing artifact "+name)
        url="https://huggingface.co/"+model_id+"/resolve/"+revision+"/"+name
        temporary=folder/(name+".partial")
        sha=hashlib.sha256(); gitsha=hashlib.sha1(("blob "+str(item["size"])+"\0").encode()); observed=0
        with request(url) as response, temporary.open("xb") as output:
            while True:
                chunk=response.read(1024*1024)
                if not chunk: break
                observed+=len(chunk)
                if observed>item["size"] or time.monotonic()>deadline: raise ValueError("artifact byte/time cap exceeded")
                output.write(chunk); sha.update(chunk); gitsha.update(chunk)
        if observed!=item["size"]: raise ValueError("artifact size mismatch "+name)
        actual=sha.hexdigest()
        lfs=item.get("lfs")
        expected=(lfs or {}).get("sha256") or (lfs or {}).get("oid")
        if expected and expected.removeprefix("sha256:")!=actual: raise ValueError("artifact sha256 mismatch "+name)
        if not lfs and item.get("blobId") and gitsha.hexdigest()!=item["blobId"]: raise ValueError("git blob hash mismatch "+name)
        temporary.replace(destination)
        artifact={"name":name,"bytes":observed,"sha256":actual,"source":url,"metadata_git_blob_id":item.get("blobId"),"metadata_lfs_sha256":expected}
        receipt["artifacts"].append(artifact)
        receipt["status"]="downloading"; save()
        print(json.dumps({"downloaded":artifact},sort_keys=True),flush=True)
    receipt.update(status="success",total_downloaded_bytes=sum(x["bytes"] for x in receipt["artifacts"]))
except Exception as exc:
    receipt.update(status="failure",error=type(exc).__name__+": "+str(exc)[:2000])
finally:
    receipt["finished_unix"]=time.time(); receipt["elapsed_wall_seconds"]=receipt["finished_unix"]-receipt["started_unix"]; save()
    print(json.dumps({"final_status":receipt["status"],"revision":receipt.get("revision"),"total_downloaded_bytes":receipt.get("total_downloaded_bytes"),"error":receipt.get("error")},sort_keys=True),flush=True)
