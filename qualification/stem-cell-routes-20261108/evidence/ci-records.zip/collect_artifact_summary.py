"""Summarize downloaded CI evidence; never execute retained source."""
from pathlib import Path
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

folder = Path(sys.argv[1]).resolve()
kind = sys.argv[2]
run = json.loads((folder / "run.json").read_text())
jobs = json.loads((folder / "jobs.json").read_text())
artifacts = json.loads((folder / "artifacts.json").read_text())
download = json.loads((folder / "artifact-download.json").read_text())
log_path = folder / "job.log"
log_bytes = log_path.read_bytes()
log = re.sub(r"\x1b\[[0-9;]*m", "", log_bytes.decode("utf-8"))
clean_log = re.sub(r"(?m)^\d{4}-\d{2}-\d{2}T\S+\s?", "", log)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(name, value):
    (folder / name).write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")

def unpack(path, destination):
    destination.mkdir(exist_ok=False)
    members = []
    with zipfile.ZipFile(path) as archive:
        for item in archive.infolist():
            target = (destination / item.filename).resolve()
            if not target.is_relative_to(destination.resolve()):
                raise ValueError("Archive member escapes evidence directory")
            if ((item.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError("Archive contains a symlink")
            if item.filename in members:
                raise ValueError("Archive contains duplicate names")
            members.append(item.filename)
        archive.extractall(destination)
    return members

zip_path = folder / download["path"]
raw_zip = zip_path.read_bytes()
if sha(raw_zip) != download["sha256"] or not download["github_digest_matches"]:
    raise ValueError("Archive digest does not match verified download metadata")
members = unpack(zip_path, folder / "extracted")
job = jobs["jobs"][0]
expected_head = "9e3cab866aa6202b99e9546f2c3c52137cc58c86"
if run["head_sha"] != expected_head or job["head_sha"] != expected_head:
    raise ValueError("Unexpected source head")
if run["event"] != "push" or job["status"] != "completed":
    raise ValueError("Unexpected run event or incomplete job")
summary = {
    "schema": "hepta.premaintenance-ci-evidence.v1",
    "repository": "TrillionniumFoundation/hepta-private-ci",
    "head_sha": expected_head,
    "source_tree": "812524cce73a601c09a27e4dbbf50a86b7c03d76",
    "source_commit_evidence": "../source-commit.json",
    "run": {key: run.get(key) for key in
            ("id", "name", "event", "head_sha", "run_attempt", "status", "conclusion",
             "created_at", "updated_at", "html_url")},
    "job": {key: job.get(key) for key in
            ("id", "name", "head_sha", "status", "conclusion", "started_at",
             "completed_at", "html_url", "labels")},
    "steps": job.get("steps", []),
    "raw_log": {"path": "job.log", "bytes": len(log_bytes), "sha256": sha(log_bytes),
                "retrieval": "GitHub workflow-job-log API decoded UTF-8 response, preserved verbatim"},
    "artifact": dict(download, members=members, unpacked_path="extracted",
                     downloaded_and_read=True),
    "maintenance_run_owned_by_this_collector": False,
    "tests_reexecuted_by_collector": False,
}
if kind == "python":
    lines = re.findall(r"(?m)^(test_\w+) \(([^\n]+)\) \.\.\. (ok|skipped[^\n]*|FAIL|ERROR)\s*$",
                       clean_log)
    totals = re.findall(r"Ran (\d+) tests? in ([\d.]+)s", clean_log)
    if not totals:
        raise ValueError("No unittest run count in original log")
    count, seconds = totals[-1]
    cases = [{"method": name, "qualified_case": case, "status": status}
             for name, case, status in lines]
    if len(cases) != int(count):
        raise ValueError("Unittest case lines and summary count differ")
    counts = {name: sum(row["status"] == value for row in cases)
              for name, value in (("passed", "ok"), ("failed", "FAIL"), ("errors", "ERROR"))}
    counts["skipped"] = sum(row["status"].startswith("skipped") for row in cases)
    counts.update(tests=int(count), seconds=float(seconds))
    save("test-cases.json", {"counts": counts, "cases": cases})
    roots = list((folder / "extracted").rglob("result.json"))
    if len(roots) != 1:
        raise ValueError("Expected one probe result")
    probe_root = roots[0].parent
    result = json.loads(roots[0].read_text())
    protocol = json.loads((probe_root / "protocol.json").read_text())
    source = json.loads((probe_root / "source.json").read_text())
    records = []
    for kernel in protocol["kernels"]:
        for seed in protocol["seeds"]:
            fit_path = probe_root / f"{kernel}-{seed}.json"
            row = json.loads(fit_path.read_text())
            if (row["kind"], row["seed"]) != (kernel, seed):
                raise ValueError("Probe fit matrix identity mismatch")
            checkpoint = probe_root / f"{kernel}-{seed}.npz"
            if sha(checkpoint.read_bytes()) != row["checkpoint_sha256"]:
                raise ValueError("Probe checkpoint digest mismatch")
            records.append({"kind": kernel, "seed": seed,
                            "record": str(fit_path.relative_to(folder)),
                            "record_sha256": sha(fit_path.read_bytes()),
                            "checkpoint": str(checkpoint.relative_to(folder)),
                            "checkpoint_sha256": row["checkpoint_sha256"],
                            "actual_parameters": row["actual_parameters"],
                            "train_status": row["training"]["status"],
                            "accuracy_after": row["after"]["accuracy"],
                            "nll_before": row["before"]["nll"],
                            "nll_after": row["after"]["nll"]})
    actual_fit_files = sorted(p.name for p in probe_root.glob("*.json")
                              if re.fullmatch(r"(?:gru|diag_ssm)-\d+\.json", p.name))
    expected_fit_files = sorted(f"{kernel}-{seed}.json"
                                for kernel in protocol["kernels"] for seed in protocol["seeds"])
    if actual_fit_files != expected_fit_files or result["fits"] != len(records):
        raise ValueError("Probe fit count mismatch")
    snapshot = probe_root / "source_snapshot.zip"
    if sha(snapshot.read_bytes()) != result["source_snapshot_sha256"]:
        raise ValueError("Probe source snapshot digest mismatch")
    with zipfile.ZipFile(snapshot) as archive:
        if set(archive.namelist()) != set(source):
            raise ValueError("Probe source snapshot inventory mismatch")
        for name, digest in source.items():
            if sha(archive.read(name)) != digest:
                raise ValueError("Probe source member digest mismatch")
    canonical = lambda value: json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    if sha(canonical(source)) != result["source_manifest_digest"]:
        raise ValueError("Source manifest digest mismatch")
    if sha(canonical(protocol)) != result["protocol_digest"]:
        raise ValueError("Protocol digest mismatch")
    summary["tests"] = counts
    summary["probe"] = {
        "status": result["status"], "fits": len(records),
        "matrix": [{"kind": row["kind"], "seed": row["seed"]} for row in records],
        "raw_fit_records": records, "checkpoint_digests_verified": True,
        "result": str(roots[0].relative_to(folder)),
        "protocol_digest_verified": True, "source_snapshot_and_member_digests_verified": True,
        "source_snapshot_members": len(source), "source_manifest_digest_verified": True,
        "production_qualified": result["production_qualified"],
        "hcsn_formal_study_started": result["hcsn_formal_study_started"],
        "scientific_winner_selected": result["scientific_winner_selected"],
        "llm_vlm_serving_measured": result["llm_vlm_serving_measured"],
        "energy_joules": result["energy_joules"],
    }
else:
    junit_paths = list((folder / "extracted").rglob("junit.xml"))
    if len(junit_paths) != 1:
        raise ValueError("Expected one retained JUnit report")
    junit = ET.parse(junit_paths[0]).getroot()
    cases = list(junit.iter("testcase"))
    passed = [case.attrib["name"] for case in cases
              if case.find("failure") is None and case.find("error") is None and case.find("skipped") is None]
    failures = [case.attrib["name"] for case in cases if case.find("failure") is not None]
    errors = [case.attrib["name"] for case in cases if case.find("error") is not None]
    junit_skipped = [case.attrib["name"] for case in cases if case.find("skipped") is not None]
    log_passed = re.findall(r"PASS\s+\[\s*[\d.]+s\]\s+codex-hepta-learning-artifacts\s+(\S+)", log)
    match = re.search(r"Summary\s+\[\s*([\d.]+)s\]\s+(\d+) tests run:\s+(\d+) passed,\s+(\d+) skipped", log)
    if not match:
        raise ValueError("No complete nextest success summary in original log")
    seconds, total, passed_count, skipped_count = match.groups()
    if sorted(passed) != sorted(log_passed) or len(passed) != int(passed_count):
        raise ValueError("Original nextest log and retained JUnit cases differ")
    skipped_source = json.loads((folder / "skipped-test-source.json").read_text())
    summary["tests"] = {
        "tests_run": int(total), "passed": int(passed_count), "failed": len(failures),
        "errors": len(errors), "skipped": int(skipped_count), "seconds": float(seconds),
        "junit_testcases": len(cases), "junit_skipped_elements": len(junit_skipped),
        "log_and_junit_passed_case_sets_match": True,
        "skipped_case": skipped_source["case"], "skipped_case_evidence": "skipped-test-source.json",
        "junit_path": str(junit_paths[0].relative_to(folder)),
        "junit_sha256": sha(junit_paths[0].read_bytes()),
    }
    save("test-cases.json", {"passed": passed, "failures": failures, "errors": errors,
                            "junit_skipped": junit_skipped, "log_passed": log_passed})
    summary["probe"] = None
save("summary.json", summary)
print(json.dumps({"folder": str(folder), "conclusion": run["conclusion"],
                  "tests": summary["tests"], "probe_fits": summary.get("probe", {}).get("fits") if summary.get("probe") else None,
                  "artifact_sha256": download["sha256"],
                  "artifact_downloaded_and_read": True}, sort_keys=True))
