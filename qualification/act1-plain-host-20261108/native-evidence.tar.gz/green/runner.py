import json,pathlib,subprocess,hashlib,datetime,time,os,re,sys
root=pathlib.Path('/home/qian-qi/work/act1-plain-host-20261108-s1s2'); source=root/'source'
prior=json.loads((root/'red-r2/RESULT.json').read_text())
assert prior['exit_code']==100
raw=(root/'red-r2/tests.log').read_text()
assert 'typed_v1: Ok(TaskFlowStepReceipt' in raw and 'observation: Some(Succeeded)' in raw
assert subprocess.check_output(['/usr/bin/git','-C',str(source),'write-tree'],text=True).strip()=='fe5fde4464c8d7fc017c861b7f7fe11a2e8bd499'
assert subprocess.check_output(['/usr/bin/git','-C',str(source),'diff','--name-only'],text=True)==''
host=source/'codex-rs/hepta-agentd/src/automation_effect_host.rs'
text=host.read_text()
boundary='        Ok(())\n    }\n\n    fn current_fence('
assert text.count(boundary)==1
guard=r'''        if crate::automation_effect_payload::requires_action_skill_host(wire_payload) {
            return Err(AgentdError::Invalid(
                "action skill invocation requires a registered goal-checking host".to_string(),
            ));
        }
'''
host.write_text(text.replace(boundary,guard+boundary))
module=source/'codex-rs/hepta-agentd/src/automation_effect_payload.rs'
with module.open('x') as handle: handle.write(r'''//! Keep action skill envelopes out of the ordinary opaque HTTP effect path.
//!
//! V1 has no separate type tag. Its top-level contract/destination identity
//! pair is reserved here even if another field, version, or trailing JSON is
//! malformed. Nested fields and ordinary opaque bytes retain their semantics.
//! Unrecognizable bytes are not authenticated or validated as action skills.

use std::fmt;

use codex_hepta_automation::ActionSkillInvocationV1;
use serde::Deserializer;
use serde::de::IgnoredAny;
use serde::de::MapAccess;
use serde::de::Visitor;

pub(crate) fn requires_action_skill_host(wire_payload: &[u8]) -> bool {
    if serde_json::from_slice::<ActionSkillInvocationV1>(wire_payload).is_ok() {
        return true;
    }
    let mut identity = SkillIdentityFields::default();
    let mut decoder = serde_json::Deserializer::from_slice(wire_payload);
    // Retain identity fields already decoded if a later field/value is broken.
    // This is syntax classification only, never an authority or goal check.
    let _ = decoder.deserialize_map(SkillIdentityVisitor(&mut identity));
    identity.contract_digest && identity.destination_id
}

#[derive(Default)]
struct SkillIdentityFields {
    contract_digest: bool,
    destination_id: bool,
}

struct SkillIdentityVisitor<'a>(&'a mut SkillIdentityFields);

impl<'de> Visitor<'de> for SkillIdentityVisitor<'_> {
    type Value = ();

    fn expecting(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("a top-level effect payload object")
    }

    fn visit_map<M: MapAccess<'de>>(self, mut map: M) -> Result<(), M::Error> {
        while let Some(key) = map.next_key::<String>()? {
            match key.as_str() {
                "contract_digest" => self.0.contract_digest = true,
                "destination_id" => self.0.destination_id = true,
                _ => {}
            }
            map.next_value::<IgnoredAny>()?;
        }
        Ok(())
    }
}
''')
lib=source/'codex-rs/hepta-agentd/src/lib.rs'; text=lib.read_text()
assert text.count('mod automation_effect_host;')==1
lib.write_text(text.replace('mod automation_effect_host;','mod automation_effect_host;\nmod automation_effect_payload;'))
subprocess.run(['/usr/bin/git','-C',str(source),'add','--','codex-rs/hepta-agentd/src/automation_effect_host.rs','codex-rs/hepta-agentd/src/automation_effect_payload.rs','codex-rs/hepta-agentd/src/lib.rs'],check=True)
evidence=root/'green'; evidence.mkdir(exist_ok=False)
def snapshot():
 return {key:subprocess.check_output(['/usr/bin/git','-C',str(source),*args],text=True).strip() for key,args in [('head',['rev-parse','HEAD']),('index_tree',['write-tree']),('status',['status','--porcelain']),('unstaged',['diff','--name-only'])]}
match=re.search(r'hepta-runtime-job-([^.\/\n]+)',pathlib.Path('/proc/self/cgroup').read_text())
record={'schema':'hepta.act1.plain-host.native-regression.v1','phase':'green','native_job_id':match.group(1) if match else None,'base':'95617b64dfdb035780f18c20df5f344ace1fc34a','source_before':snapshot(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':prior['argv'],'qualification':'host regression only; no goal observer registration or production activation'}
(evidence/'START.json').write_text(json.dumps(record,indent=2)+'\n')
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/qian-qi/work/cell-s0s5-20261108-1628/cargo-target',CARGO_BUILD_JOBS='2',DOTSLASH_CACHE='/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/cache',PATH='/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/bin:/home/qian-qi/work/hepta-cell-ci-repair-20261108-304d/tools/bin:/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin')
print(json.dumps({'started':record,'evidence':str(evidence)}),flush=True)
started=time.monotonic()
with (evidence/'tests.log').open('wb') as log: result=subprocess.run(record['argv'],cwd=source/'codex-rs',env=env,stdout=log,stderr=subprocess.STDOUT)
raw=(evidence/'tests.log').read_bytes(); record.update(exit_code=result.returncode,wall_seconds=time.monotonic()-started,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_after=snapshot(),log_sha256=hashlib.sha256(raw).hexdigest(),log_bytes=len(raw))
(evidence/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);print(raw.decode('utf-8','replace')[-6500:],flush=True);sys.exit(result.returncode)
