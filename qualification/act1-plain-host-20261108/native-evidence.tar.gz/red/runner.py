import json,sys,pathlib,subprocess,hashlib,datetime,time,os
root=pathlib.Path('/home/qian-qi/work/act1-plain-host-20261108-s1s2')
source=root/'source'
payload=json.load(sys.stdin)
assert subprocess.check_output(['/usr/bin/git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==payload['base']
p=source/payload['path']
assert subprocess.check_output(['/usr/bin/git','hash-object',str(p)],text=True).strip()==payload['base_blob']
assert subprocess.check_output(['/usr/bin/git','-C',str(source),'status','--porcelain'],text=True)==''
p.write_text(payload['content'])
subprocess.run(['/usr/bin/git','-C',str(source),'add','--',payload['path']],check=True)
evidence=root/'red'
evidence.mkdir(exist_ok=False)
def snapshot():
 return {key:subprocess.check_output(['/usr/bin/git','-C',str(source),*args],text=True).strip() for key,args in [('head',['rev-parse','HEAD']),('index_tree',['write-tree']),('status',['status','--porcelain']),('unstaged',['diff','--name-only'])]}
record={'schema':'hepta.act1.plain-host.native-regression.v1','phase':'red','base':payload['base'],'source_before':snapshot(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':['just','test','--locked','-p','codex-hepta-agentd','--lib','-E','test(automation_effect_host::tests::)','--test-threads','2','--success-output','immediate']}
(evidence/'START.json').write_text(json.dumps(record,indent=2)+'\n')
env=os.environ.copy()
env['CARGO_TARGET_DIR']='/home/qian-qi/work/cell-s0s5-20261108-1628/cargo-target'
env['CARGO_BUILD_JOBS']='2'
env['DOTSLASH_CACHE']='/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/cache'
env['PATH']='/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/bin:/home/qian-qi/work/hepta-cell-ci-repair-20261108-304d/tools/bin:/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin'
print(json.dumps({'started':record,'evidence':str(evidence)}),flush=True)
started=time.monotonic()
with (evidence/'tests.log').open('wb') as log:
 result=subprocess.run(record['argv'],cwd=source/'codex-rs',env=env,stdout=log,stderr=subprocess.STDOUT)
raw=(evidence/'tests.log').read_bytes()
record.update(exit_code=result.returncode,wall_seconds=time.monotonic()-started,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_after=snapshot(),log_sha256=hashlib.sha256(raw).hexdigest(),log_bytes=len(raw))
(evidence/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
print(raw.decode('utf-8','replace')[-10000:],flush=True)
sys.exit(result.returncode)
