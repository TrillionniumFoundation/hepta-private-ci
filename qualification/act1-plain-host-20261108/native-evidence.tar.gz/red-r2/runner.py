import json,pathlib,subprocess,hashlib,datetime,time,os,re,sys
root=pathlib.Path('/home/qian-qi/work/act1-plain-host-20261108-s1s2'); source=root/'source'
prior=json.loads((root/'red/RESULT.json').read_text())
assert prior['exit_code']==101
assert subprocess.check_output(['/usr/bin/git','-C',str(source),'write-tree'],text=True).strip()=='56dfe0e08048cc8a3368251f50de81eb11ad6ee8'
assert subprocess.check_output(['/usr/bin/git','-C',str(source),'diff','--name-only'],text=True)==''
jobs=pathlib.Path('/home/qian-qi/.local/state/hepta-runtime-mac-worker/jobs')
for d in sorted((p for p in jobs.iterdir() if p.is_dir()),key=lambda p:p.name,reverse=True)[:100]:
 q=d/'request.json'
 if not q.exists() or q.stat().st_size>262144: continue
 v=json.loads(q.read_text())
 a=v.get('args',[])
 if len(a)==2 and a[0]=='-c' and a[1].startswith('import json,sys,pathlib,subprocess,hashlib,datetime,time,os\nroot='):
  print(json.dumps({'recovered_prior_native_job_id':v.get('job_id'),'files':[p.name for p in d.iterdir()]}),flush=True)
p=source/'codex-rs/hepta-agentd/src/automation_effect_host.rs'; text=p.read_text()
needle='contract.digest().expect("contract digest"),'
assert text.count(needle)==1
p.write_text(text.replace(needle,'contract.digest().expect("contract digest").as_str(),'))
subprocess.run(['/usr/bin/git','-C',str(source),'add','--','codex-rs/hepta-agentd/src/automation_effect_host.rs'],check=True)
evidence=root/'red-r2'; evidence.mkdir(exist_ok=False)
def snapshot():
 return {key:subprocess.check_output(['/usr/bin/git','-C',str(source),*args],text=True).strip() for key,args in [('head',['rev-parse','HEAD']),('index_tree',['write-tree']),('status',['status','--porcelain']),('unstaged',['diff','--name-only'])]}
cgroup=pathlib.Path('/proc/self/cgroup').read_text()
match=re.search(r'hepta-runtime-job-([^.\/\n]+)',cgroup)
record={'schema':'hepta.act1.plain-host.native-regression.v1','phase':'red-r2','native_job_id':match.group(1) if match else None,'base':'95617b64dfdb035780f18c20df5f344ace1fc34a','source_before':snapshot(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':prior['argv']}
(evidence/'START.json').write_text(json.dumps(record,indent=2)+'\n')
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/qian-qi/work/cell-s0s5-20261108-1628/cargo-target',CARGO_BUILD_JOBS='2',DOTSLASH_CACHE='/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/cache',PATH='/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/bin:/home/qian-qi/work/hepta-cell-ci-repair-20261108-304d/tools/bin:/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin')
print(json.dumps({'started':record,'evidence':str(evidence)}),flush=True)
started=time.monotonic()
with (evidence/'tests.log').open('wb') as log: result=subprocess.run(record['argv'],cwd=source/'codex-rs',env=env,stdout=log,stderr=subprocess.STDOUT)
raw=(evidence/'tests.log').read_bytes(); record.update(exit_code=result.returncode,wall_seconds=time.monotonic()-started,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_after=snapshot(),log_sha256=hashlib.sha256(raw).hexdigest(),log_bytes=len(raw))
(evidence/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);print(raw.decode('utf-8','replace')[-10000:],flush=True);sys.exit(result.returncode)
