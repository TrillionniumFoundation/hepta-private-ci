import json,pathlib,subprocess,hashlib,datetime,time,os,re,sys
root=pathlib.Path('/home/qian-qi/work/act1-plain-host-20261108-s1s2'); source=root/'source'; evidence=root/'format'; evidence.mkdir(exist_ok=False)
green=json.loads((root/'green/RESULT.json').read_text()); assert green['exit_code']==0
assert subprocess.check_output(['/usr/bin/git','-C',str(source),'write-tree'],text=True).strip()==green['source_after']['index_tree']
assert subprocess.check_output(['/usr/bin/git','-C',str(source),'diff','--name-only'],text=True)==''
def snapshot():
 return {key:subprocess.check_output(['/usr/bin/git','-C',str(source),*args],text=True).strip() for key,args in [('head',['rev-parse','HEAD']),('index_tree',['write-tree']),('status',['status','--porcelain']),('unstaged',['diff','--name-only'])]}
match=re.search(r'hepta-runtime-job-([^.\/\n]+)',pathlib.Path('/proc/self/cgroup').read_text())
record={'schema':'hepta.act1.plain-host.native-format.v1','native_job_id':match.group(1) if match else None,'argv':['just','fmt'],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_before':snapshot(),'tests_rerun_after_format':False}
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/qian-qi/work/cell-s0s5-20261108-1628/cargo-target',CARGO_BUILD_JOBS='2',DOTSLASH_CACHE='/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/cache',PATH='/home/qian-qi/work/cell-s0s5-20261108-1628/ci-tools/bin:/home/qian-qi/work/hepta-cell-ci-repair-20261108-304d/tools/bin:/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin')
(evidence/'START.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
started=time.monotonic()
with (evidence/'fmt.log').open('wb') as log: result=subprocess.run(record['argv'],cwd=source/'codex-rs',env=env,stdout=log,stderr=subprocess.STDOUT)
raw=(evidence/'fmt.log').read_bytes()
patch=subprocess.check_output(['/usr/bin/git','-C',str(source),'diff'],text=True)
(evidence/'post-test-formatting.patch').write_text(patch)
record.update(exit_code=result.returncode,wall_seconds=time.monotonic()-started,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_after=snapshot(),log_sha256=hashlib.sha256(raw).hexdigest(),log_bytes=len(raw),formatting_patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),formatting_patch_bytes=len(patch.encode()))
(evidence/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);print(raw.decode('utf-8','replace')[-5000:],flush=True);print(patch[:14000],flush=True);sys.exit(result.returncode)
