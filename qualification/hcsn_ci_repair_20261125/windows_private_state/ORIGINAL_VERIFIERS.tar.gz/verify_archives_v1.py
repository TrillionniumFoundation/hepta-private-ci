"""Independent read-only verification of the three native Windows CI archives."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
HEAD = "a638030ee1f57a11c101d68f2537af17b38a5dcd"
TREE = "4963be2d879bf1a91eac3567e20e10bf30e92147"
DIGESTS = {
    14989095158: "5a8c9805fe37ac40d58310e2ab84e716df66d606d5a2642eadeb66f089c444db",
    14988991140: "240091ea7d9055dd6a2d720dc1198760cf05540ca0b831c5fe1e78afcb007c15",
    14987818577: "05d9ba6de1b391d65b1fea29179d9da22ce886c8346a0ee4f61d9f213dba42f4",
}
def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def archive(number):
    p = ROOT / f"a638-{number}.zip"
    assert sha(p.read_bytes()) == DIGESTS[number]
    z = zipfile.ZipFile(p)
    assert len(z.namelist()) == len(set(z.namelist()))
    assert all("/" not in n and "\\" not in n for n in z.namelist())
    assert z.testzip() is None
    return z

def clean_identity(record):
    assert record["before"] == record["after"]
    assert record["before"]["commit"] == HEAD
    assert record["before"]["tree"] == TREE
    assert record["before"]["dirty"] is False
    assert record["source_sha"] == HEAD
    assert record["exit_code"] == record["command_exit_code"] == 0
    argv = record["command"]
    assert argv[argv.index("--retries")+1] == "0"

ansi = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
terminal = re.compile(r"^\s*(PASS|FAIL|TIMEOUT|EXECFAIL|LEAK|SKIP)\s+\[[^\]\n]+\]\s+(?:\(\s*\d+/\d+\)\s+)?(\S+)\s+(\S+)\s*$", re.M)
source = (ROOT/"hepta_windows_learn_regressions.py").read_bytes()
assert blob(source) == "725bed3b275ba600ded14b6a936c9600a704200b"
assignment = next(n for n in ast.parse(source).body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id=="CASE_LIST" for t in n.targets))
groups = ast.literal_eval(assignment.value)
expected = Counter((pkg,name) for rows in groups.values() for pkg,names in rows.items() for name in names)
assert len(expected) == sum(expected.values()) == 36
with archive(14987818577) as z:
    execution = json.loads(z.read("execution.json"))
    summary = json.loads(z.read("native-junit.summary.json"))
    receipt = json.loads(z.read("receipt.json"))
    clean_identity(execution)
    assert execution["build_target"] == "x86_64-pc-windows-msvc"
    assert sha(z.read("execution.json")) == summary["execution_sha256"] == receipt["execution_sha256"]
    assert sha(z.read("native.log")) == execution["log_sha256"]
    xml = z.read("native-junit.xml")
    assert sha(xml) == summary["junit_sha256"]
    assert b"<!DOCTYPE" not in xml and b"<!ENTITY" not in xml
    root = ET.fromstring(xml)
    cases = root.findall("./testsuite/testcase")
    assert len(cases) == 36 and all(len(list(c)) == 0 for c in cases)
    actual = Counter((c.attrib["classname"],c.attrib["name"]) for c in cases)
    assert actual == expected
    rows = terminal.findall(ansi.sub("",z.read("native.log").decode()))
    assert len(rows) == 36 and all(status=="PASS" for status,_,_ in rows)
    assert Counter((pkg,name) for _,pkg,name in rows) == expected
with archive(14988991140) as z:
    credit = json.loads(z.read("credit-fixture.json"))
    clean_identity(credit)
    assert sha(z.read("credit-fixture.log")) == credit["log_sha256"]
    rows = terminal.findall(ansi.sub("",z.read("credit-fixture.log").decode()))
    assert rows == [("PASS","codex-hepta-agentd",credit["case"])]
    assert ("codex-hepta-agentd",credit["case"]) in expected
with archive(14989095158) as z:
    manifest = json.loads(z.read("manifest.json"))
    assert manifest["source_head"] == HEAD and manifest["source_tree"] == TREE
    original = (ROOT/"private_state_windows_directory.rs").read_bytes()
    assert blob(original) == "dcf75023b7aa0df18ab4a875c8253f0bc10debbb"
    assert original == z.read("positive.rs")
    assert sha(original) == manifest["production_sha256"]
    for lane in manifest["lanes"]:
        name = lane["lane"]
        assert sha(z.read(name+".rs")) == lane["production_sha256"]
        assert sha(z.read(name+".log")) == lane["log_sha256"]
        if name != "positive":
            assert sha(z.read(name+".patch")) == lane["patch_sha256"]
        rows = terminal.findall(ansi.sub("",z.read(name+".log").decode()))
        assert len(rows)==2
        assert {test:status for status,_,test in rows} == lane["statuses"]
        assert lane["exit_code"] == (0 if name=="positive" else 1)
        assert sum(status=="FAIL" for status,_,_ in rows) == (0 if name=="positive" else 1)
out = {
    "schema": 1, "status": "VERIFIED", "source": HEAD, "tree": TREE,
    "run_id": 45534615741, "job_id": 138938029815,
    "archives": DIGESTS, "registered_native_cases": 36,
    "group_counts": {g:sum(map(len,pkgs.values())) for g,pkgs in groups.items()},
    "exact_registered_inventory_vs_junit_vs_log": True,
    "selected_failed_or_skipped_cases": 0, "retries": 0,
    "separate_credit_case_repeated_within_36": True,
    "directory_acquisition": "Two positive guards pass; each of two original mutations fails its intended guard.",
    "scope": "Native private-state acquisition, credit/ledger/current-state regressions only. Not Core elevated process isolation qualification, not restoration of the three still-failed Core positives, and not retroactive qualification of PR7068.",
    "verifier_sha256": sha(Path(__file__).read_bytes()),
}
(ROOT/"INDEPENDENT_WINDOWS_PRIVATE_STATE_VERIFICATION.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out))
