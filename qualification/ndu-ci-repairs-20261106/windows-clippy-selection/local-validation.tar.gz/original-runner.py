from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parent
FIXTURE = ROOT / "bazel_fixture"
BAZEL = ROOT.parent / "bazel_tooling/bazel-9.0.0-linux-x86_64"
OUTPUT = ROOT / "bazel_fixture_results"
OUTPUT.mkdir(exist_ok=True)
selector = ROOT.parent / "units/20_windows_clippy_compatibility/scripts/list-bazel-clippy-targets.sh"
expression = next(line.strip().strip("'") for line in selector.read_text().splitlines() if line.strip().startswith("'--starlark:expr="))
startup = [str(BAZEL), "--batch", "--host_jvm_args=-Xmx256m", "--host_jvm_args=-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts", "--output_user_root=" + str(ROOT.parent / "bazel_tooling/output")]
query = 'kind("rust_helper rule", attr(tags, "manual", //...))'
cases = [
    ("unconfigured", ["query", query, "--output=label"], {"//:unit-tests-bin", "//:native-test-bin", "//:test-windows-cross-bin", "//:unix-owner-test-bin", "//:indirect-unix-test-bin"}),
]
for platform, labels in [
    ("windows_x86_64_msvc", {"//:unit-tests-bin", "//:native-test-bin"}),
    ("windows_x86_64_gnullvm", {"//:unit-tests-bin", "//:test-windows-cross-bin"}),
    ("linux_x86_64", {"//:unit-tests-bin", "//:native-test-bin", "//:unix-owner-test-bin", "//:indirect-unix-test-bin"}),
    ("macos_arm64", {"//:unit-tests-bin", "//:native-test-bin", "//:unix-owner-test-bin", "//:indirect-unix-test-bin"}),
]:
    cases.append((platform, ["cquery", query, "--platforms=//:" + platform, "--output=starlark", expression], labels))
results = []
for name, arguments, expected in cases:
    started = time.monotonic()
    result = subprocess.run(startup + arguments, cwd=FIXTURE, capture_output=True, timeout=60, check=False)
    (OUTPUT / (name + ".stdout.log")).write_bytes(result.stdout)
    (OUTPUT / (name + ".stderr.log")).write_bytes(result.stderr)
    labels = {line for line in result.stdout.decode().splitlines() if line}
    entry = {"case": name, "argv": startup + arguments, "exit_code": result.returncode, "seconds": time.monotonic() - started, "expected": sorted(expected), "actual": sorted(labels), "matches": result.returncode == 0 and labels == expected, "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(result.stderr).hexdigest()}
    results.append(entry)
    print(json.dumps({k: entry[k] for k in ("case", "exit_code", "matches", "actual")}), flush=True)
    if not entry["matches"]:
        raise RuntimeError(entry)
receipt = {"bazel_version": "9.0.0", "bazel_sha256": hashlib.sha256(BAZEL.read_bytes()).hexdigest(), "official_asset_id": 343421735, "platforms_archive_sha256": "3384eb1c30762704fbe38e440204e114154086c8fc8a8c2e3e28441028c019a8", "tls_verification": "Enabled using the pre-existing system Java trust store; no certificate verification was disabled.", "fixture_files": {n: {"bytes": (FIXTURE / n).stat().st_size, "sha256": hashlib.sha256((FIXTURE / n).read_bytes()).hexdigest()} for n in ("BUILD.bazel", "MODULE.bazel", "rules.bzl", ".bazelignore")}, "source_expression": expression, "results": results, "scope": "Actual Bazel loading and configured analysis of declared-rule fixtures; no Rust crate compilation or full native Windows Clippy qualification."}
(OUTPUT / "RESULT.json").write_text(json.dumps(receipt, indent=2) + "\n")
