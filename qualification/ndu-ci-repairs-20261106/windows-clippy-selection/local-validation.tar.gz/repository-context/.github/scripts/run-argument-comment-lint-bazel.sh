#!/usr/bin/env bash

set -euo pipefail

bazel_lint_args=("$@")
bazel_wrapper_args=()
if [[ "${RUNNER_OS:-}" == "Windows" ]]; then
  # Older callers passed the generic local Windows platform explicitly. That
  # platform selects gnullvm for host-loaded proc macros and overrides the
  # coherent split supplied below. Drop only that obsolete exact spelling;
  # every other explicit caller platform remains authoritative.
  sanitized_bazel_lint_args=()
  for arg in "${bazel_lint_args[@]}"; do
    if [[ "$arg" == "--platforms=//:local_windows" ]]; then
      continue
    fi
    sanitized_bazel_lint_args+=("$arg")
  done
  bazel_lint_args=("${sanitized_bazel_lint_args[@]}")

  # Some Rust top-level targets are still intentionally incompatible with the
  # local Windows exec platform. Skip those explicit targets so the native
  # lint aspect can run across the compatible crate graph instead of failing the
  # whole build after analysis.
  bazel_lint_args+=("--skip_incompatible_explicit_targets")
  # Use the same keyless Windows split as test, Clippy, and release lanes:
  # MSVC for host-loaded proc macros and gnullvm for target code.
  bazel_wrapper_args+=("--windows-cross-compile")
fi

read_query_labels() {
  local query="$1"
  local query_stdout
  local query_stderr
  query_stdout="$(mktemp)"
  query_stderr="$(mktemp)"

  if ! ./.github/scripts/run-bazel-query-ci.sh \
    --keep_going \
    --output=label \
    -- "$query" >"$query_stdout" 2>"$query_stderr"; then
    cat "$query_stderr" >&2
    rm -f "$query_stdout" "$query_stderr"
    exit 1
  fi

  cat "$query_stdout"
  rm -f "$query_stdout" "$query_stderr"
}

final_build_targets=(//codex-rs/...)
if [[ "${RUNNER_OS:-}" == "Windows" ]]; then
  # Bazel's local Windows platform currently lacks a default test toolchain for
  # `rust_test`, so target the concrete Rust crate rules directly. The lint
  # aspect still walks their crate graph, which preserves incremental reuse for
  # non-test code while avoiding non-Rust wrapper targets such as platform_data.
  final_build_targets=()
  while IFS= read -r label; do
    # Native Windows query stdout uses CRLF. read removes LF; remove only
    # that record's single trailing CR, preserving the label itself.
    label="${label%$'\r'}"
    [[ -n "$label" ]] || continue
    final_build_targets+=("$label")
  done < <(read_query_labels 'kind("rust_library rule", //codex-rs/...) union kind("rust_binary rule", //codex-rs/...) union kind("rust_proc_macro rule", //codex-rs/...)')

  if [[ ${#final_build_targets[@]} -eq 0 ]]; then
    echo "Failed to discover Windows Bazel lint targets." >&2
    exit 1
  fi
fi

./.github/scripts/run-bazel-ci.sh \
  "${bazel_wrapper_args[@]}" \
  -- \
  build \
  "${bazel_lint_args[@]}" \
  -- \
  "${final_build_targets[@]}"
