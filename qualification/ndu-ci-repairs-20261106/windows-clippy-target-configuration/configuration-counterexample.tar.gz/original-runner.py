from pathlib import Path
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
REVIEW = ROOT / "configuration_review"
FIXTURE = REVIEW / "fixture"
OUTPUT = REVIEW / "results"
FIXTURE.mkdir(parents=True, exist_ok=True)
OUTPUT.mkdir(exist_ok=True)
for name in ("MODULE.bazel", ".bazelignore"):
    shutil.copy2(ROOT / "bazel_fixture" / name, FIXTURE / name)
if not (FIXTURE / "platforms").exists():
    shutil.copytree(ROOT / "bazel_fixture/platforms", FIXTURE / "platforms")
(FIXTURE / "BUILD.bazel").write_text('''platform(name = "windows_x86_64_msvc", constraint_values = ["@platforms//os:windows", "@platforms//cpu:x86_64"], visibility = ["//visibility:public"])
''')
(FIXTURE / "rules.bzl").write_text('''def _impl(ctx):
    return []

rust_helper = rule(implementation = _impl, attrs = {"deps": attr.label_list(), "tools": attr.label_list(cfg = "exec")})
''')
(FIXTURE / "codex-rs").mkdir(exist_ok=True)
(FIXTURE / "codex-rs/BUILD.bazel").write_text('''load("//:rules.bzl", "rust_helper")
package(default_visibility = ["//visibility:public"])
config_setting(name = "optimized", values = {"compilation_mode": "opt"})
rust_helper(name = "unit-tests-bin", tags = ["manual"])
rust_helper(name = "native-test-bin", tags = ["manual"])
rust_helper(name = "optimized-only-test-bin", tags = ["manual"], target_compatible_with = select({":optimized": [], "//conditions:default": ["@platforms//:incompatible"]}))
''')
(FIXTURE / "support").mkdir(exist_ok=True)
(FIXTURE / "support/BUILD.bazel").write_text('''load("//:rules.bzl", "rust_helper")
rust_helper(name = "exec-consumer", tools = ["//codex-rs:unit-tests-bin", "//codex-rs:optimized-only-test-bin"])
''')
selector = ROOT.parent / "units/20_windows_clippy_compatibility/scripts/list-bazel-clippy-targets.sh"
formatter = next(line.strip().strip("'") for line in selector.read_text().splitlines() if line.strip().startswith("'--starlark:expr="))
startup = [str(ROOT.parent / "bazel_tooling/bazel-9.0.0-linux-x86_64"), "--host_jvm_args=-Xmx384m", "--host_jvm_args=-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts", "--output_user_root=" + str(ROOT.parent / "bazel_tooling/output"), "--output_base=" + str(REVIEW / "server"), "--max_idle_secs=300"]
options = ["--platforms=//:windows_x86_64_msvc", "--host_platform=//:windows_x86_64_msvc", "--compilation_mode=fastbuild"]
query = 'kind("rust_helper rule", attr(tags, "manual", //codex-rs/...))'
results = []


def call(name, command, extra):
    argv = startup + [command] + options + extra
    result = subprocess.run(argv, cwd=FIXTURE, capture_output=True, check=False, timeout=60)
    (OUTPUT / (name + ".stdout.log")).write_bytes(result.stdout)
    (OUTPUT / (name + ".stderr.log")).write_bytes(result.stderr)
    record = {"case": name, "argv": argv, "exit_code": result.returncode, "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(), "stdout": result.stdout.decode()}
    results.append(record)
    (OUTPUT / "RESULT.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({"case": name, "exit_code": result.returncode, "stdout": result.stdout.decode()}), flush=True)
    if result.returncode:
        raise RuntimeError(result.stderr.decode())
    return result.stdout


before_pid = call("server-pid-before", "info", ["server_pid"])
call("original-before-prime", "cquery", [query, "--output=starlark", formatter])
call("prime-exec-transition", "cquery", ['deps(//support:exec-consumer)', "--output=label"])
call("original-after-prime-labels", "cquery", [query, "--output=label"])
call("original-after-prime", "cquery", [query, "--output=starlark", formatter])
call("target-config-after-prime-labels", "cquery", ["config(" + query + ", target)", "--output=label"])
call("target-config-after-prime", "cquery", ["config(" + query + ", target)", "--output=starlark", formatter])
after_pid = call("server-pid-after", "info", ["server_pid"])
assert before_pid == after_pid
print(json.dumps({"same_server_pid": before_pid.decode().strip(), "commands": len(results)}))
