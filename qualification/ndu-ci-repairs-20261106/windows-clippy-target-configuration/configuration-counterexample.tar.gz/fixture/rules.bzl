def _impl(ctx):
    return []

rust_helper = rule(implementation = _impl, attrs = {"deps": attr.label_list(), "tools": attr.label_list(cfg = "exec")})
