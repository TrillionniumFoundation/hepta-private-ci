# PR 5311 source-bound CI observation

Requested head: `7f33cc33aed948779a2725bf9a56f805063abb57`.
Base: `2049567ce7dd6ca81758431b8797938e017a070b`.
Actual NDU tested prospective merge: `0d41d6561e3cc6d06afc19d559a4a1555f5db567`.
GitHub Git object readback proves both commits have tree `83229a2c93cd8bf5b216f252c6eef4f668fff3fc`.

NDU reference job 128393139123 / blocking run 42369039914 passed.
Its retained artifact contains 140 portfolio tests with zero failures/errors/skips,
including 22 learning-outcome and 15 replication tests. The separate semantic/material step passed 33 tests.
The artifact ZIP hash was checked against GitHub's artifact metadata; the original ZIP and extracted results/tests are retained.
Source manifest is `4fc18605d3c5e5e5f0871db524289563164aacbad3e55a78cc661bf7c4a422a7`; source stayed unchanged during execution.

The result remains `RESEARCH_ONLY_HOLD`; native integration was not executed.
These are hosted software checks, not the real five-family confirmation experiment or native NoUpdate-to-next-use evidence.

Architecture convergence run 42369039924 failed on the already identified missing-numpy import during unittest discovery (45 passing tests and one import error).
The factorial agent owns that separate repair. No remote state was modified here.

At this snapshot, Codespell passed. Blocking scope, blob-size and V8 metadata jobs were still checking out; the dependent blocking fan-in was not complete.
Do not describe the overall PR as CI green. See SUMMARY.json and bound-readback.json for precise source and readback details.
