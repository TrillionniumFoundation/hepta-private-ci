import datetime, hashlib, json, pathlib, subprocess, time
root=pathlib.Path('/workspace/scratch/ff41dfc0f7bf/hepta-integration-recovered-cloud')
out=pathlib.Path(__file__).parent
command=['python3','-m','unittest','discover','-s','qa/b4-no-bypass','-p','*source_closure.py','-v']
def capture():
    git=lambda *args: subprocess.check_output(['git',*args],cwd=root).decode().strip()
    paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0')
    digest=hashlib.sha256(); count=0
    for name in paths:
        if not name: continue
        file=root/name.decode()
        if file.is_file():
            data=file.read_bytes(); digest.update(name+b'\0'+hashlib.sha256(data).digest()); count+=1
    return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain'),tracked_files=count,tracked_digest=digest.hexdigest())
before=capture(); assert not before['status'], before
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); tick=time.monotonic()
with (out/'source-qa.log').open('wb') as f:
    result=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT)
after=capture(); data=(out/'source-qa.log').read_bytes()
summary=dict(command=command,before=before,after=after,unchanged=before==after,started=start,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed=time.monotonic()-tick,returncode=result.returncode,log_bytes=len(data),log_sha256=hashlib.sha256(data).hexdigest(),scope='all source closure QA only; no native tests or whole caller qualification')
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
