import datetime,hashlib,importlib.util,json,pathlib,subprocess,sys,time,tomllib
root=pathlib.Path('/dev/shm/hepta-root-c-closure-ff41');out=pathlib.Path(__file__).parent
sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('proof',root/'scripts/verify_hepta_callers.py');v=importlib.util.module_from_spec(spec);sys.modules['proof']=v;spec.loader.exec_module(v)
def capture():
 git=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode().strip()
 names=subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0');h=hashlib.sha256();count=0
 for name in names:
  if not name:continue
  p=root/name.decode()
  if p.is_file():h.update(name+b'\0'+hashlib.sha256(p.read_bytes()).digest());count+=1
 return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain'),files=count,digest=h.hexdigest())
before=capture();assert not before['status'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
m=v._load_manifest(root/'CALLERS.toml');rows=v._boundary_rows(m);v._verify_privileged_inventory(m,rows)
extra={'root_artifact_original_selection_files','root_historical_current_trust_receipt','q24_successor_original_c_ingress','q24_successor_original_signed_finish','learning_original_q24_training_material_export','learning_original_q24_stage_install_generation'}
selected=[r for r in rows if r.identifier.startswith(('post_a_','root_prepared_publication_')) or r.identifier in extra]
files=v._source_files(root,tuple(m['source_roots']));index={str(p.relative_to(root)):v._strip_cfg_test_items(v._strip_rust_non_code(p.read_text())) for p in files};fields={};results=[]
for r in selected:
 try:
  value=v._verify_boundary(root,r,index,tuple(m['ignored_path_fragments']),fields_by_receiver_type=fields);results.append(dict(id=r.identifier,status='PASS',receipt=value))
 except Exception as e:results.append(dict(id=r.identifier,status='FAIL',error=str(e)))
 (out/'caller-progress.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'callers':len(results),'failures':[r for r in results if r['status']=='FAIL']}),flush=True)
command=['python3','-m','unittest','discover','-s','qa/b4-no-bypass','-p','test_post_a_*source_closure.py','-v']
with (out/'source-qa.log').open('wb') as f:r=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT)
after=capture();raw=(out/'source-qa.log').read_bytes();summary=dict(before=before,after=after,unchanged=before==after,started=start,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed=time.monotonic()-tick,rust_files=len(files),caller_results=results,qa_command=command,qa_returncode=r.returncode,qa_bytes=len(raw),qa_sha256=hashlib.sha256(raw).hexdigest(),scope='Affected Root post-A caller closed sets and post-A source negative controls only; no native or whole-chain qualification')
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:x for k,x in summary.items() if k!='caller_results'},indent=2),flush=True)
