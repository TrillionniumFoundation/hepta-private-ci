from pathlib import Path, PurePosixPath
from datetime import datetime
import base64
import hashlib
import json
import tarfile
import xml.etree.ElementTree as ET

B = Path('/workspace/scratch/ef0c911c24f4/native-publication-20261112')
W = B / 'continuation02-final-20261112'
S = W / 'snapshot'
O = B / 'qualification/memory-cell-mem12-native-recovered-20261112'
COMMIT = '811e0e27190066e81a23eebed8ad559ae67d228e'
TREE = '2043cbf11fd00662cc23562123c27ae4e6f72580'


def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def page_of(value):
    if not isinstance(value, dict):
        return None
    needed = {'data_base64', 'operation_id', 'offset', 'total_bytes', 'result_sha256'}
    if needed <= value.keys():
        return value
    structured = value.get('structuredContent')
    if isinstance(structured, dict) and needed <= structured.keys():
        return structured
    for content in value.get('content', []):
        if content.get('type') == 'text':
            try:
                parsed = json.loads(content['text'])
            except (ValueError, TypeError):
                continue
            if isinstance(parsed, dict) and needed <= parsed.keys():
                return parsed
    return None


def all_pages(value):
    found = page_of(value)
    if found:
        yield found
    elif isinstance(value, dict):
        for child in value.values():
            yield from all_pages(child)
    elif isinstance(value, list):
        for child in value:
            yield from all_pages(child)


sdk_files = {digest(p.read_bytes())['sha256']: p for p in S.glob('*.original-sdk-payload.json')}
groups = {}
for path in sorted(S.glob('*READBACK*.json')):
    for page in all_pages(json.loads(path.read_text())):
        group = groups.setdefault(page['operation_id'], {})
        if page['offset'] in group:
            assert group[page['offset']] == page
        group[page['offset']] = page
sdk_checks = []
for op, group in sorted(groups.items()):
    raw = bytearray()
    pages = [group[k] for k in sorted(group)]
    for page in pages:
        block = base64.b64decode(page['data_base64'], validate=True)
        assert page['offset'] == len(raw)
        assert page['next_offset'] == len(raw) + len(block)
        assert page['result_sha256'] == pages[0]['result_sha256']
        assert page['total_bytes'] == pages[0]['total_bytes']
        raw.extend(block)
    assert pages[-1]['eof'] and len(raw) == pages[0]['total_bytes']
    sha = hashlib.sha256(raw).hexdigest()
    assert sha == pages[0]['result_sha256'] and sha in sdk_files
    assert bytes(raw) == sdk_files[sha].read_bytes()
    sdk_checks.append({'operation_id': op, 'file': sdk_files[sha].name, **digest(raw), 'pages': len(pages), 'complete': True})
assert len(sdk_checks) == len(sdk_files) == 7

sdk_map = {'final': 'RESULT.json', 'progress01': 'PROGRESS_01.json', 'progress02': 'PROGRESS_02.json', 'progress03': 'PROGRESS_03.json', 'publication': 'PUBLICATION.json'}
for stem, destination in sdk_map.items():
    native = json.loads((S / (stem + '.original-sdk-payload.json')).read_text())
    assert native['isError'] is False
    result = json.loads(native['content'][0]['text'])
    assert result['truncated'] is False and len(result['files']) == 1
    item = result['files'][0]
    raw = item['text'].encode()
    assert digest(raw) == {'bytes': item['size'], 'sha256': item['sha256']}
    assert raw == (S / destination).read_bytes()
native = json.loads((S / 'junits.original-sdk-payload.json').read_text())
assert native['isError'] is False
result = json.loads(native['content'][0]['text'])
assert result['truncated'] is False and len(result['files']) == 9
for item in result['files']:
    raw = item['text'].encode()
    assert digest(raw) == {'bytes': item['size'], 'sha256': item['sha256']}
    assert raw == (S / 'stage-originals' / Path(item['path']).name).read_bytes()
native = json.loads((S / 'terminal.original-sdk-payload.json').read_text())
assert native['isError'] is False
terminal = json.loads(native['content'][0]['text'])
assert terminal == json.loads((S / 'TERMINAL.json').read_text())
assert terminal['job_id'] == '1a1cedb0568-2564-18ae'
assert terminal['state'] == 'succeeded' and terminal['exit_code'] == 0 and not terminal['timed_out']
assert all(terminal[k] for k in ['output_complete', 'output_durable', 'terminal_publication_confirmed'])
assert not any(terminal['log_truncated'].values())

archive_path = O / 'native-continuation-811e0e27-02.tar.xz'
archive_info = digest(archive_path.read_bytes())
assert archive_info == {'bytes': 166532, 'sha256': '2a46e59a61c6b4afc94cb2bca2d5fa5847484705d9b6ade4672fd4365a2e702c'}
publication = json.loads((S / 'PUBLICATION.json').read_text())
assert publication['bytes'] == archive_info['bytes'] and publication['sha256'] == archive_info['sha256']
assert publication['status'] == 'software_controls_passed'
with tarfile.open(archive_path, 'r:xz') as tar:
    members = tar.getmembers()
    seen = set()
    files = {}
    for member in members:
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in member.name
        assert member.name not in seen and (member.isfile() or member.isdir())
        assert not member.issym() and not member.islnk() and member.size <= 8 * 1024 * 1024
        seen.add(member.name)
        if member.isfile():
            files[member.name] = tar.extractfile(member).read()
    assert sum(m.size for m in members) <= 64 * 1024 * 1024
P = 'continuation-811e0e27-02/'
manifest_raw = files[P + 'MEMBER_MANIFEST.json']
manifest = json.loads(manifest_raw)
assert {P + name for name in manifest} == set(files) - {P + 'MEMBER_MANIFEST.json'}
for name, info in manifest.items():
    assert digest(files[P + name]) == info
assert files[P + 'RESULT.json'] == (S / 'RESULT.json').read_bytes()
r = json.loads(files[P + 'RESULT.json'])
assert digest(files[P + 'RESULT.json']) == {'bytes': 42212, 'sha256': '6350c2cf293438473e606f1b616650713176bc2ef87510901f23a8061817496d'}
assert r['status'] == 'software_controls_passed'
assert r['source_commit'] == COMMIT and r['source_tree'] == TREE
assert r['source_before'] == r['source_after'] == {'commit': COMMIT, 'tree': TREE, 'status': ''}
assert r['source_unchanged'] and r['source_postimages_before'] == r['source_postimages_after']
original = json.loads((B / 'snapshot/recovery-context/originals/RESULT.json').read_text())
assert r['source_postimages_before'] == original['source_postimages_before']
assert len(r['source_postimages_before']) == 25
for name, info in r['source_postimages_before'].items():
    assert digest(files[P + 'source-postimages/' + name]) == info
assert files[P + 'source-rewrites.patch'] == b''
assert r['codex_binary_before'] == r['codex_binary_after'] and r['codex_binary_unchanged']
assert all(r[k] for k in ['native_contracts_passed', 'scoped_fix_passed', 'format_passed', 'memory11_passed', 'strict_isolation_passed'])
assert not r['strict_isolation_executed_in_this_continuation'] and not r['memory11_executed_in_this_continuation']
assert r['new_real_model_calls'] == r['scored_memory_benefit_episodes'] == 0 and r['adoption_decision'] == 'HOLD'

phases = {p['name']: p for p in r['phases']}
assert set(phases) == {'verified-v8', 'codex-build', 'agentd-episodic', 'agentd-qualification-profile', 'native-delivery', 'protocol', 'scoped-fix', 'final-format'}
for name, phase in phases.items():
    assert phase['status'] == 'passed' and phase['exit_code'] == 0
    receipt = json.loads(files[P + name + '.receipt.json'])
    assert receipt == phase['receipt'] and receipt['status'] == 'passed' and receipt['exit_code'] == 0 and not receipt['timed_out']
    assert receipt['before']['commit'] == receipt['after']['commit'] == COMMIT
    assert receipt['before']['tree'] == receipt['after']['tree'] == TREE
    assert receipt['before']['dirty'] is receipt['after']['dirty'] is False
    assert digest(files[P + receipt['log_file']]) == {'bytes': receipt['log_bytes'], 'sha256': receipt['log_sha256']}
    local_receipt = S / 'stage-originals' / (name + '.receipt.json')
    if local_receipt.exists():
        assert local_receipt.read_bytes() == files[P + name + '.receipt.json']

stage_checks = []
last_uuid = '372c4563-0ab7-41df-ac66-f2a8d9c87bb8'
for name, expected in [('agentd-episodic', 7), ('agentd-qualification-profile', 1), ('native-delivery', 7), ('protocol', 16)]:
    phase = phases[name]
    receipt = phase['receipt']
    raw = files[P + name + '.junit.xml']
    assert raw == (S / 'stage-originals' / (name + '.junit.xml')).read_bytes()
    assert digest(raw) == {k: phase['junit'][k] for k in ['bytes', 'sha256']}
    xml = ET.fromstring(raw)
    cases = xml.findall('.//testcase')
    names = [case.attrib['name'] for case in cases]
    uuid = xml.attrib['uuid']
    assert xml.attrib == phase['junit']['attributes']
    assert len(cases) == len(set(names)) == int(xml.attrib['tests']) == expected
    assert names == phase['junit']['case_names']
    assert not any(case.find(tag) is not None for case in cases for tag in ['failure', 'error', 'skipped'])
    assert receipt['observed_passed_tests'] == expected and receipt['observed_failed_tests'] == 0
    assert uuid in files[P + receipt['log_file']].decode()
    start = datetime.fromisoformat(receipt['started_at'])
    finish = datetime.fromisoformat(receipt['finished_at'])
    assert all(start <= datetime.fromisoformat(case.attrib['timestamp']) <= finish for case in cases)
    previous = ET.fromstring(files[P + name + '.previous.junit.xml']).attrib['uuid']
    assert previous == last_uuid and previous != uuid
    last_uuid = uuid
    stage_checks.append({'phase': name, 'executed': expected, 'passed': expected, 'failed': 0, 'skipped': 0, 'uuid': uuid, 'previous_uuid': previous, 'uuid_fresh_from_previous_report': True, 'uuid_in_original_log': True, 'all_case_timestamps_within_original_receipt': True, 'junit': digest(raw), 'receipt': digest(files[P + name + '.receipt.json']), 'log': digest(files[P + receipt['log_file']]), 'case_names': names})
assert any(n.endswith('native_predecessor_forget_closes_episodic_context') for n in phases['agentd-episodic']['junit']['case_names'])
assert 'qualification-cognitive-write' in phases['agentd-qualification-profile']['command']
assert phases['agentd-qualification-profile']['junit']['case_names'] == ['app_runtime::tests::episodic_embedding_keeps_the_store_but_removes_implicit_memory_paths']

prior = B / 'snapshot/continuation-recovery/continuation-01'
for archived, previous in [('continuation01.original-result.json', 'RESULT.json'), ('memory-episodic.junit.xml', 'junit.xml'), ('memory-episodic.receipt.json', 'memory-episodic.receipt.json'), ('memory-episodic.receipt.json.aeee353cc57242a9ac4e2eef8f29f0c6.log', 'memory-episodic.receipt.json.aeee353cc57242a9ac4e2eef8f29f0c6.log')]:
    assert files[P + 'recovered-memory11/' + archived] == (prior / previous).read_bytes()
assert r['memory11_original_receipt'] == json.loads((prior / 'memory-episodic.receipt.json').read_text())
assert r['strict_isolation_original_receipt'] == next(p['receipt'] for p in original['phases'] if p['name'] == 'strict-isolation')
assert sum(s['executed'] for s in stage_checks) == 31

verification = {
    'schema': 'hepta.mem12.native-continuation02-final-verification.v1',
    'qualification_status': 'software_controls_passed',
    'adoption_decision': 'HOLD',
    'tested_source': {'commit': COMMIT, 'tree': TREE, 'clean_before_and_after': True, 'unchanged': True, 'postimages': 25, 'all_archived_postimages_verified': True, 'same_postimages_as_original_attempt': True, 'rewrite_patch_bytes': 0, 'scope': '811e0e27 only; does not qualify the evidence-branch tree or MEM13/MEM14/MEM15'},
    'archive': {'file': archive_path.name, **archive_info},
    'tar_safety': {'members': len(members), 'regular_files': len(files), 'directories': sum(m.isdir() for m in members), 'safe_relative_paths': True, 'links': 0, 'special_files': 0, 'duplicate_paths': 0},
    'original_manifest': {'file': P + 'MEMBER_MANIFEST.json', **digest(manifest_raw), 'entries': len(manifest), 'covers_all_other_regular_files': True, 'all_member_hashes_verified': True},
    'result': digest(files[P + 'RESULT.json']),
    'terminal': {k: terminal[k] for k in ['job_id', 'state', 'exit_code', 'timed_out', 'output_complete', 'output_durable', 'terminal_publication_confirmed']},
    'terminal_original_sdk': digest((S / 'terminal.original-sdk-payload.json').read_bytes()),
    'source_sdk_readbacks': sdk_checks,
    'archive_sdk_download': json.loads((W / 'transport/VERIFIED_DOWNLOAD.json').read_text()),
    'stages': stage_checks,
    'counts': {'new_rust_case_executions_in_continuation02': 31, 'previous_memory_rust_case_executions_referenced_without_rerun': 11, 'total_rust_case_executions': 42, 'previous_strict_isolation_cases_referenced_without_rerun': 8, 'rust_failures': 0, 'rust_skipped': 0, 'interpretation': 'Execution counts across five Rust reports; the profile case runs under two distinct feature configurations, so this is not a distinct-name count.'},
    'prior_memory11_original_bytes_verified': True,
    'prior_strict8_receipt_verified': True,
    'strict_isolation_rerun_in_continuation02': False,
    'memory11_rerun_in_continuation02': False,
    'verified_v8_passed': True,
    'codex_build_passed': True,
    'scoped_fix_passed': True,
    'final_format_passed': True,
    'recorded_codex_binary_before': r['codex_binary_before'],
    'recorded_codex_binary_after': r['codex_binary_after'],
    'recorded_codex_binary_unchanged': True,
    'binary_verification_basis': 'Identical before/after digests in the original authenticated RESULT; binary bytes are not part of the evidence archive.',
    'new_real_model_calls': 0,
    'scored_memory_benefit_episodes': 0,
    'publisher_test_or_model_reruns': 0,
    'original_failed_attempts_preserved': True,
}
(O / 'CONTINUATION_02_VERIFICATION.json').write_text(json.dumps(verification, indent=2) + '\n')
print(json.dumps({'archive': verification['archive'], 'tar_safety': verification['tar_safety'], 'manifest_entries': len(manifest), 'sdk_readbacks': len(sdk_checks), 'counts': verification['counts'], 'terminal': verification['terminal'], 'stage_uuids': [{'phase': s['phase'], 'executed': s['executed'], 'uuid': s['uuid']} for s in stage_checks]}, indent=2))
