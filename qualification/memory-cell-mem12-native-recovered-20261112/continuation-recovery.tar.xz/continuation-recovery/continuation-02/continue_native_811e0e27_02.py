"""Continue only unexecuted native controls after a retained build prerequisite failure."""
import hashlib
from datetime import datetime
import uuid
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time
import traceback
import xml.etree.ElementTree as ET

ROOT = Path("/home/qq/work/mem12-native-qualification-20261112-ef0c")
SOURCE = ROOT / "source-v2"
COMMIT = "811e0e27190066e81a23eebed8ad559ae67d228e"
TREE = "2043cbf11fd00662cc23562123c27ae4e6f72580"
BASE = "ea5d3f77e275906f6623f7f4b64be1678d640f8d"
OUT = ROOT / "continuation-811e0e27-02"
OUT.mkdir(exist_ok=False)
ENV = dict(os.environ)
ENV.update({
    "PATH": "/home/qq/.cargo/bin:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/just-1.58.0:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/uv-0.13.5:" + ENV.get("PATH", "/usr/bin:/bin"),
    "RUSTUP_TOOLCHAIN": "1.96.0",
    "CARGO_BUILD_JOBS": "2",
    "CARGO_INCREMENTAL": "0",
    "CARGO_PROFILE_TEST_DEBUG": "0",
    "CARGO_PROFILE_DEV_DEBUG": "0",
    "CARGO_TARGET_DIR": str(ROOT / "cargo-target"),
    "CODEX_REPO_ROOT": str(SOURCE),
    "PYTHONPATH": str(SOURCE / "scripts") + ":" + str(SOURCE),
    "PYTHONDONTWRITEBYTECODE": "1",
    "HEPTA_MEM9_REQUIRE_ISOLATION": "1",
    "HEPTA_MEM9_EVIDENCE_ROOT": str(OUT / "strict-attempts"),
    "SOURCE_SHA": COMMIT,
    "TESTED_SHA": COMMIT,
    "BASE_SHA": BASE,
    "HEPTA_CI_LANE": "source-head",
})
JUNIT = SOURCE / "codex-rs/target/nextest/local/junit.xml"
RESULT = {
    "schema": "hepta.mem12.native-continuation.v2",
    "source_commit": COMMIT, "source_tree": TREE,
    "started_unix_ns": time.time_ns(), "phases": [],
    "new_real_model_calls": 0, "scored_memory_benefit_episodes": 0,
    "adoption_decision": "HOLD", "status": "running",
    "resource_settings": {"cargo_build_jobs": 2, "outer_nice": 10},
    "scope": "same-source unexecuted native software controls; prior strict8 and verified memory11 are referenced without rerun; no native model-benefit campaign",
}
DELIVERY_CASES = {
    "native_app_server::context::tests::delivery_off_withholds_physical_context_but_keeps_revalidation_and_replay",
    "native_app_server::control::tests::context_delivery_is_bound_before_connection_and_preserves_legacy_admission",
    "native_app_server::control::tests::intelligence_handoff_is_committed_to_native_admission_identity",
    "native_app_server::control::tests::pre_dispatch_cancellation_and_connection_failure_release_without_usage_claims",
    "native_app_server::control::tests::reopened_dispatch_and_completed_duplicate_never_connect_to_provider",
    "native_app_server::control::tests::reopened_explicit_dispatch_rejection_never_connects_or_becomes_unknown",
    "native_app_server::tests::real_agentd_worker_accepts_fresh_context_and_rejects_final_use_tombstone",
}

def save():
    pending = OUT / "RESULT.pending.json"
    pending.write_text(json.dumps(RESULT, indent=2) + "\n")
    pending.replace(OUT / "RESULT.json")

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return {"bytes": path.stat().st_size, "sha256": h.hexdigest()}

def git(*args):
    return subprocess.check_output(["git", "-C", str(SOURCE), *args], env=ENV)

def identity():
    return {
        "commit": git("rev-parse", "HEAD").decode().strip(),
        "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
        "status": git("status", "--porcelain").decode(),
    }

def require_source():
    state = identity()
    if state != {"commit": COMMIT, "tree": TREE, "status": ""}:
        raise RuntimeError("frozen source changed: " + json.dumps(state))
    return state

def command(label, args, minimum=None, timeout=6600, test=False, expected=None, required_suffix=None):
    if label not in ("fetch-final", "fetch-base", "checkout-final", "scoped-fix", "final-format"):
        require_source()
    previous_uuid = None
    if test and JUNIT.exists():
        if JUNIT.is_symlink():
            raise RuntimeError("refuse symlinked JUnit")
        previous_uuid = ET.parse(JUNIT).getroot().get("uuid")
        JUNIT.rename(OUT / (label + ".previous.junit.xml"))
    wrapped = ["/usr/bin/python3.14", str(SOURCE / "scripts/hepta_ci_exec.py"),
               "--timeout-seconds", str(timeout), "--output", str(OUT / (label + ".receipt.json"))]
    if minimum is not None:
        wrapped += ["--minimum-tests", str(minimum)]
    wrapped += ["--", *args]
    preparing = label in ("fetch-final", "fetch-base", "checkout-final")
    if preparing:
        wrapped = args
    entry = {"name": label, "command": args, "started_unix_ns": time.time_ns(), "status": "running"}
    RESULT["phases"].append(entry)
    save()
    with (OUT / (label + ".console.log")).open("wb") as log:
        completed = subprocess.run(wrapped, cwd=SOURCE, env=ENV, stdout=log, stderr=subprocess.STDOUT, timeout=timeout if preparing else None)
    entry["exit_code"] = completed.returncode
    entry["finished_unix_ns"] = time.time_ns()
    entry["status"] = "passed" if completed.returncode == 0 else "failed"
    receipt_path = OUT / (label + ".receipt.json")
    if receipt_path.exists():
        entry["receipt"] = json.loads(receipt_path.read_text())
    if test and JUNIT.exists() and not JUNIT.is_symlink():
        copy = OUT / (label + ".junit.xml")
        shutil.copyfile(JUNIT, copy)
        report = ET.parse(copy).getroot()
        cases = report.findall(".//testcase")
        names = [c.get("name") for c in cases]
        entry["junit"] = {"attributes": report.attrib, "case_names": names, **digest(copy)}
        try:
            run_uuid = str(uuid.UUID(report.attrib["uuid"]))
            receipt = entry["receipt"]
            start = datetime.fromisoformat(receipt["started_at"])
            finish = datetime.fromisoformat(receipt["finished_at"])
            if run_uuid == previous_uuid:
                raise ValueError("reused prior nextest UUID")
            if report.get("tests") != str(len(cases)):
                raise ValueError("JUnit total differs from original cases")
            for case in cases:
                if not start <= datetime.fromisoformat(case.attrib["timestamp"]) <= finish:
                    raise ValueError("case timestamp outside original supervisor receipt")
            entry["junit"]["fresh_uuid_and_case_times_verified"] = True
        except (ValueError, KeyError, TypeError) as error:
            entry["status"] = "failed"
            entry["selection_error"] = "JUnit binding: " + str(error)
        bad = any(c.find(t) is not None for c in cases for t in ("error", "failure", "skipped"))
        if not cases or bad or len(names) != len(set(names)):
            entry["status"] = "failed"
            entry["selection_error"] = "empty, duplicate, failed or skipped cases"
        if expected is not None and (len(cases) != len(expected) or set(names) != expected):
            entry["status"] = "failed"
            entry["selection_error"] = "actual cases differ from the frozen required set"
        if required_suffix and not any(n and n.endswith(required_suffix) for n in names):
            entry["status"] = "failed"
            entry["selection_error"] = "native predecessor withdrawal regression not executed"
    elif test:
        entry["status"] = "failed"
        entry["selection_error"] = "missing fresh JUnit"
    save()
    return entry["status"] == "passed"

try:
    save()
    previous_path = ROOT / "final-811e0e27/RESULT.json"
    previous_raw = previous_path.read_bytes()
    if hashlib.sha256(previous_raw).hexdigest() != "34ad8d821103393df9778496c5dd031eb72bea415cf2769fe82a41420286b556":
        raise RuntimeError("original qualification result differs from readback")
    previous = json.loads(previous_raw)
    phases = {entry["name"]: entry for entry in previous["phases"]}
    memory = phases["memory-episodic"]
    if (previous["source_commit"] != COMMIT or previous["source_tree"] != TREE
            or previous["status"] != "incomplete" or not previous["source_unchanged"]
            or memory["exit_code"] != 101
            or memory["receipt"]["observed_passed_tests"] != 0
            or memory["receipt"]["observed_failed_tests"] != 0
            or not previous["strict_isolation_passed"]
            or phases["strict-isolation"]["receipt"]["observed_passed_tests"] != 8
            or not previous.get("finished_unix_ns")
            or any(name in phases for name in ("agentd-episodic", "native-delivery", "protocol"))):
        raise RuntimeError("continuation preconditions do not prove unexecuted native controls")
    original_log = previous_path.parent / memory["receipt"]["log_file"]
    if digest(original_log)["sha256"] != memory["receipt"]["log_sha256"]:
        raise RuntimeError("original build failure log differs")
    if "fatal error: 'stddef.h' file not found" not in original_log.read_text():
        raise RuntimeError("original build did not establish the exact prerequisite failure")
    repair_path = ROOT / "clang-resources-v1/REPAIR.json"
    repair = json.loads(repair_path.read_text())
    if repair["status"] != "prepared" or repair["system_packages_modified"]:
        raise RuntimeError("task-local Clang resource repair unavailable")
    header = Path(repair["stddef_header"]["path"])
    if digest(header)["sha256"] != repair["stddef_header"]["sha256"]:
        raise RuntimeError("Clang resource header changed after repair")
    ENV.update(repair["build_environment"])
    RESULT["prior_qualification"] = {"path": str(previous_path), **digest(previous_path)}
    RESULT["prior_job_id"] = "1a1cea67111-2564-1763"
    RESULT["prior_job_terminal"] = {"state": "failed", "exit_code": 1, "timed_out": False,
                                    "original_sdk_payload_sha256": "7068402bff42661c1a28196a226d32f268ee101988adbe4067a24bbcc83a67fa"}
    RESULT["strict_isolation_passed"] = True
    RESULT["strict_isolation_executed_in_this_continuation"] = False
    RESULT["strict_isolation_original_receipt"] = phases["strict-isolation"]["receipt"]
    RESULT["header_repair"] = {"path": str(repair_path), **digest(repair_path), "build_environment": repair["build_environment"]}
    RESULT["source_before"] = require_source()
    paths = git("diff", "--name-only", "--diff-filter=ACMRT", BASE, COMMIT).decode().splitlines()
    RESULT["source_postimages_before"] = {p: digest(SOURCE / p) for p in paths if (SOURCE / p).is_file()}
    (OUT / "source-postimages.json").write_text(json.dumps(RESULT["source_postimages_before"], indent=2) + "\n")
    postimages = OUT / "source-postimages"
    postimages.mkdir()
    for path in paths:
        p = SOURCE / path
        if p.is_file() and not p.is_symlink() and p.stat().st_size <= 4 * 1024 * 1024:
            dest = postimages / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(p, dest)
    deps_path = ROOT / "build-dependencies/DEPENDENCIES.json"
    if deps_path.exists():
        deps = json.loads(deps_path.read_text())
        RESULT["dependency_receipt"] = digest(deps_path)
        if deps.get("protoc_usable"):
            ENV["PROTOC"] = deps["protoc_path"]
            ENV["LD_LIBRARY_PATH"] = deps["protoc_libraries"] + ":" + ENV.get("LD_LIBRARY_PATH", "")
    RESULT["build_environment"] = {name: ENV[name] for name in (
        "PATH", "RUSTUP_TOOLCHAIN", "CARGO_BUILD_JOBS", "CARGO_INCREMENTAL",
        "CARGO_PROFILE_TEST_DEBUG", "CARGO_PROFILE_DEV_DEBUG", "CARGO_TARGET_DIR",
        "HEPTA_MEM9_REQUIRE_ISOLATION", "BINDGEN_EXTRA_CLANG_ARGS") }
    if "PROTOC" in ENV:
        RESULT["build_environment"]["PROTOC"] = ENV["PROTOC"]
    continuation_path = ROOT / "continuation-811e0e27-01/RESULT.json"
    continuation_raw = continuation_path.read_bytes()
    if hashlib.sha256(continuation_raw).hexdigest() != "056a621308278d52bc2c20561a64e85c680770ff33c4447bdbb8a5ab018fc1f0":
        raise RuntimeError("continuation01 original result changed")
    continuation = json.loads(continuation_raw)
    previous_phases = {entry["name"]: entry for entry in continuation["phases"]}
    memory = previous_phases["memory-episodic"]
    receipt = memory["receipt"]
    if (continuation["source_commit"] != COMMIT or continuation["source_tree"] != TREE
            or continuation["status"] != "incomplete" or not continuation["source_unchanged"]
            or not continuation.get("finished_unix_ns")
            or set(previous_phases) != {"tool-versions", "memory-episodic", "final-format"}
            or memory["exit_code"] != 0 or receipt["status"] != "passed"
            or receipt["observed_passed_tests"] != 11 or receipt["observed_failed_tests"] != 0
            or memory.get("selection_error") != "missing fresh JUnit"):
        raise RuntimeError("continuation01 does not establish memory11 passed and remaining stages unexecuted")
    recovered = OUT / "recovered-memory11"
    recovered.mkdir()
    shutil.copyfile(continuation_path, recovered / "continuation01.original-result.json")
    original_receipt = continuation_path.parent / "memory-episodic.receipt.json"
    if json.loads(original_receipt.read_text()) != receipt:
        raise RuntimeError("memory11 supervisor receipt changed")
    shutil.copyfile(original_receipt, recovered / original_receipt.name)
    memory_log = continuation_path.parent / receipt["log_file"]
    if digest(memory_log)["sha256"] != "64255bd54c11375511782219f0c36f0d0c2af1d8b178f410213a9e3e9fc80b93":
        raise RuntimeError("memory11 original stdout changed")
    shutil.copyfile(memory_log, recovered / memory_log.name)
    if JUNIT.is_symlink() or digest(JUNIT)["sha256"] != "6c3e2fbc6551df44daa77d4b74349eee80afcf0d3237318759f7f2d03ea02af2":
        raise RuntimeError("memory11 original workspace JUnit changed")
    shutil.copyfile(JUNIT, recovered / "memory-episodic.junit.xml")
    report = ET.parse(JUNIT).getroot()
    cases = report.findall(".//testcase")
    run_uuid = str(uuid.UUID(report.attrib["uuid"]))
    start = datetime.fromisoformat(receipt["started_at"])
    finish = datetime.fromisoformat(receipt["finished_at"])
    if (run_uuid != "372c4563-0ab7-41df-ac66-f2a8d9c87bb8"
            or run_uuid not in memory_log.read_text()
            or len(cases) != 11 or report.get("tests") != "11"
            or report.get("failures") != "0" or report.get("errors") != "0"
            or len({c.get("name") for c in cases}) != 11
            or any(c.find(t) is not None for c in cases for t in ("failure", "error", "skipped"))
            or not all(start <= datetime.fromisoformat(c.attrib["timestamp"]) <= finish for c in cases)
            or any(receipt[side]["commit"] != COMMIT or receipt[side]["tree"] != TREE or receipt[side]["dirty"] for side in ("before", "after"))):
        raise RuntimeError("memory11 JUnit cannot bind original command, timestamps and exact source")
    RESULT["previous_continuation"] = {"path": str(continuation_path), **digest(continuation_path)}
    RESULT["previous_continuation_job"] = {"job_id": "1a1ceb9bc10-2564-1808", "state": "failed", "exit_code": 1, "timed_out": False,
        "original_terminal_sdk_sha256": "9ce53afae42b08824b4f73dc34c9a138b8c418033ced0bedb5935423b17674d1"}
    RESULT["memory11_passed"] = True
    RESULT["memory11_executed_in_this_continuation"] = False
    RESULT["memory11_original_receipt"] = receipt
    RESULT["memory11_original_junit"] = {"path": str(JUNIT), **digest(JUNIT), "uuid": run_uuid, "case_names": [c.get("name") for c in cases]}
    RESULT["collection_correction"] = "The original workspace JUnit path was correct. Continuation01 incorrectly used CARGO_TARGET_DIR for nextest store, causing a collection-only false failure. All original results remain retained."
    native_ok = True
    save()
    if native_ok:
        env_file = OUT / "v8.env"
        ENV["GITHUB_ENV"] = str(env_file)
        native_ok = command("verified-v8", ["/usr/bin/python3.14", str(SOURCE / "scripts/hepta_ci_v8.py")], timeout=900)
        if native_ok:
            if env_file.exists():
                for line in env_file.read_text().splitlines():
                    key, value = line.split("=", 1)
                    if key not in {"RUSTY_V8_ARCHIVE", "RUSTY_V8_SRC_BINDING_PATH"}:
                        raise RuntimeError("unexpected V8 export")
                    ENV[key] = value
            native_ok = command("codex-build", ["cargo", "build", "--locked", "--manifest-path", str(SOURCE / "codex-rs/Cargo.toml"), "-p", "codex-cli", "--bin", "codex"])
    if native_ok:
        binary = Path(ENV["CARGO_TARGET_DIR"]) / "debug/codex"
        RESULT["codex_binary_before"] = {"path": str(binary), **digest(binary)}
        ENV["CARGO_BIN_EXE_codex"] = str(binary)
        native_ok = command("agentd-episodic", ["just", "test", "--locked", "-p", "codex-hepta-agentd", "--lib", "episodic", "--no-capture", "--retries", "0"], minimum=1, test=True, required_suffix="native_predecessor_forget_closes_episodic_context")
    if native_ok:
        case = "app_runtime::tests::episodic_embedding_keeps_the_store_but_removes_implicit_memory_paths"
        native_ok = command("agentd-qualification-profile", ["just", "test", "--locked", "-p", "codex-hepta-agentd", "--features", "qualification-cognitive-write", "--lib", case, "--no-capture", "--retries", "0"], minimum=1, timeout=1800, test=True, expected={case})
    if native_ok:
        expression = "test(native_app_server::context::tests::) | test(native_app_server::control::tests::) | test(native_app_server::tests::real_agentd_worker_accepts_fresh_context_and_rejects_final_use_tombstone)"
        native_ok = command("native-delivery", ["just", "test", "--locked", "-p", "codex-hepta-infer-worker-host", "--lib", "-E", expression, "--no-capture", "--retries", "0"], minimum=7, test=True, expected=DELIVERY_CASES)
    if native_ok:
        native_ok = command("protocol", ["just", "test", "--locked", "-p", "codex-hepta-agent-protocol", "--no-capture", "--retries", "0"], minimum=1, test=True)
    RESULT["native_contracts_passed"] = native_ok
    if native_ok:
        RESULT["scoped_fix_passed"] = command("scoped-fix", ["just", "fix", "--locked", "-p", "codex-hepta-memory", "-p", "codex-hepta-agentd", "-p", "codex-hepta-infer-worker-host", "-p", "codex-hepta-agent-protocol"])
    RESULT["format_passed"] = command("final-format", ["just", "fmt", "--base", BASE], timeout=900)
    RESULT["source_after"] = identity()
    (OUT / "source-rewrites.patch").write_bytes(git("diff", "--binary", "HEAD"))
    RESULT["source_postimages_after"] = {p: digest(SOURCE / p) for p in paths if (SOURCE / p).is_file()}
    RESULT["source_unchanged"] = RESULT["source_before"] == RESULT["source_after"] and RESULT["source_postimages_before"] == RESULT["source_postimages_after"]
    if "codex_binary_before" in RESULT:
        RESULT["codex_binary_after"] = {"path": str(binary), **digest(binary)}
        RESULT["codex_binary_unchanged"] = RESULT["codex_binary_after"] == RESULT["codex_binary_before"]
    RESULT["status"] = "software_controls_passed" if (RESULT["strict_isolation_passed"] and native_ok and RESULT.get("scoped_fix_passed") and RESULT["format_passed"] and RESULT["source_unchanged"]) else "incomplete"
except BaseException as error:
    RESULT["status"] = "failed"
    RESULT["error"] = type(error).__name__ + ": " + str(error)
    (OUT / "exception.txt").write_text(traceback.format_exc())
finally:
    RESULT["finished_unix_ns"] = time.time_ns()
    save()
    manifest = {str(p.relative_to(OUT)): digest(p) for p in OUT.rglob("*") if p.is_file() and not p.is_symlink()}
    (OUT / "MEMBER_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    archive = ROOT / "native-continuation-811e0e27-02.tar.xz"
    with tarfile.open(archive, "x:xz") as target:
        target.add(OUT, arcname=OUT.name)
    publication = {"archive": str(archive), **digest(archive), "result": str(OUT / "RESULT.json"), "status": RESULT["status"]}
    (ROOT / "NATIVE_CONTINUATION_02_PUBLICATION.json").write_text(json.dumps(publication, indent=2) + "\n")
    print(json.dumps(publication, indent=2))
if RESULT["status"] != "software_controls_passed":
    raise SystemExit(1)
