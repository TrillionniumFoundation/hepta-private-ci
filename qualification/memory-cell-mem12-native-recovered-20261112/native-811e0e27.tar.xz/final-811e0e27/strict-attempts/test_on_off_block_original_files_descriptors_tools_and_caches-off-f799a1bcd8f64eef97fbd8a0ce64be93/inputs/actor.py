
import json, os, socket
from pathlib import Path
task = json.loads(Path("/input/task.json").read_bytes())
denied = []
for path in task["forbidden_paths"]:
    try:
        Path(path).read_bytes()
        denied.append(False)
    except OSError:
        denied.append(True)
try:
    os.read(99, 16)
    fd_closed = False
except OSError:
    fd_closed = True
cache = Path("/cache/previous-turn")
cache_was_empty = not cache.exists()
cache.write_text("private-to-this-turn")
memory = Path("/input/memory.txt")
tool = __import__("subprocess").run(
    ["/usr/bin/python3", "-I", "-c",
     "from pathlib import Path; import sys; "
     "print(Path(sys.argv[1]).exists())", task["forbidden_paths"][0]],
    capture_output=True, text=True, check=True)
print(json.dumps({"denied": denied, "fd_closed": fd_closed,
 "tool_can_see_writer": tool.stdout.strip() == "True",
 "cache_was_empty": cache_was_empty,
 "context": memory.read_text() if memory.exists() else "",
 "unexpected_env": sorted(set(os.environ) -
   {"HOME", "XDG_CACHE_HOME", "TMPDIR", "PATH", "LANG", "LC_CTYPE"})}))
