"""Execute the unchanged MEM native and isolation contracts on one frozen source."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time
import traceback
import xml.etree.ElementTree as ET

ROOT = Path("/home/qq/work/mem12-native-qualification-20261112-ef0c")
SOURCE = ROOT / "source-v2"
COMMIT = "811e0e27190066e81a23eebed8ad559ae67d228e"
TREE = "2043cbf11fd00662cc23562123c27ae4e6f72580"
BASE = "ea5d3f77e275906f6623f7f4b64be1678d640f8d"
OUT = ROOT / "final-811e0e27"
OUT.mkdir(exist_ok=False)
ENV = dict(os.environ)
ENV.update({
    "PATH": "/home/qq/.cargo/bin:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/just-1.58.0:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/uv-0.13.5:" + ENV.get("PATH", "/usr/bin:/bin"),
    "RUSTUP_TOOLCHAIN": "1.96.0",
    "CARGO_BUILD_JOBS": "2",
    "CARGO_INCREMENTAL": "0",
    "CARGO_PROFILE_TEST_DEBUG": "0",
    "CARGO_PROFILE_DEV_DEBUG": "0",
    "CARGO_TARGET_DIR": str(ROOT / "cargo-target"),
    "CODEX_REPO_ROOT": str(SOURCE),
    "PYTHONPATH": str(SOURCE / "scripts") + ":" + str(SOURCE),
    "PYTHONDONTWRITEBYTECODE": "1",
    "HEPTA_MEM9_REQUIRE_ISOLATION": "1",
    "HEPTA_MEM9_EVIDENCE_ROOT": str(OUT / "strict-attempts"),
    "SOURCE_SHA": COMMIT,
    "TESTED_SHA": COMMIT,
    "BASE_SHA": BASE,
    "HEPTA_CI_LANE": "source-head",
})
JUNIT = SOURCE / "codex-rs/target/nextest/local/junit.xml"
RESULT = {
    "schema": "hepta.mem12.native-qualification.v1",
    "source_commit": COMMIT, "source_tree": TREE,
    "started_unix_ns": time.time_ns(), "phases": [],
    "new_real_model_calls": 0, "scored_memory_benefit_episodes": 0,
    "adoption_decision": "HOLD", "status": "running",
    "scope": "same-source native software controls and strict no-model isolation; not a native model-benefit campaign",
}
DELIVERY_CASES = {
    "native_app_server::context::tests::delivery_off_withholds_physical_context_but_keeps_revalidation_and_replay",
    "native_app_server::control::tests::context_delivery_is_bound_before_connection_and_preserves_legacy_admission",
    "native_app_server::control::tests::intelligence_handoff_is_committed_to_native_admission_identity",
    "native_app_server::control::tests::pre_dispatch_cancellation_and_connection_failure_release_without_usage_claims",
    "native_app_server::control::tests::reopened_dispatch_and_completed_duplicate_never_connect_to_provider",
    "native_app_server::control::tests::reopened_explicit_dispatch_rejection_never_connects_or_becomes_unknown",
    "native_app_server::tests::real_agentd_worker_accepts_fresh_context_and_rejects_final_use_tombstone",
}

def save():
    pending = OUT / "RESULT.pending.json"
    pending.write_text(json.dumps(RESULT, indent=2) + "\n")
    pending.replace(OUT / "RESULT.json")

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return {"bytes": path.stat().st_size, "sha256": h.hexdigest()}

def git(*args):
    return subprocess.check_output(["git", "-C", str(SOURCE), *args], env=ENV)

def identity():
    return {
        "commit": git("rev-parse", "HEAD").decode().strip(),
        "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
        "status": git("status", "--porcelain").decode(),
    }

def require_source():
    state = identity()
    if state != {"commit": COMMIT, "tree": TREE, "status": ""}:
        raise RuntimeError("frozen source changed: " + json.dumps(state))
    return state

def command(label, args, minimum=None, timeout=6600, test=False, expected=None, required_suffix=None):
    if label not in ("fetch-final", "fetch-base", "checkout-final", "scoped-fix", "final-format"):
        require_source()
    if test and JUNIT.exists():
        if JUNIT.is_symlink():
            raise RuntimeError("refuse symlinked JUnit")
        JUNIT.rename(OUT / (label + ".previous.junit.xml"))
    wrapped = ["/usr/bin/python3.14", str(SOURCE / "scripts/hepta_ci_exec.py"),
               "--timeout-seconds", str(timeout), "--output", str(OUT / (label + ".receipt.json"))]
    if minimum is not None:
        wrapped += ["--minimum-tests", str(minimum)]
    wrapped += ["--", *args]
    preparing = label in ("fetch-final", "fetch-base", "checkout-final")
    if preparing:
        wrapped = args
    entry = {"name": label, "command": args, "started_unix_ns": time.time_ns(), "status": "running"}
    RESULT["phases"].append(entry)
    save()
    with (OUT / (label + ".console.log")).open("wb") as log:
        completed = subprocess.run(wrapped, cwd=SOURCE, env=ENV, stdout=log, stderr=subprocess.STDOUT, timeout=timeout if preparing else None)
    entry["exit_code"] = completed.returncode
    entry["finished_unix_ns"] = time.time_ns()
    entry["status"] = "passed" if completed.returncode == 0 else "failed"
    receipt_path = OUT / (label + ".receipt.json")
    if receipt_path.exists():
        entry["receipt"] = json.loads(receipt_path.read_text())
    if test and JUNIT.exists() and not JUNIT.is_symlink():
        copy = OUT / (label + ".junit.xml")
        shutil.copyfile(JUNIT, copy)
        report = ET.parse(copy).getroot()
        cases = report.findall(".//testcase")
        names = [c.get("name") for c in cases]
        entry["junit"] = {"attributes": report.attrib, "case_names": names, **digest(copy)}
        bad = any(c.find(t) is not None for c in cases for t in ("error", "failure", "skipped"))
        if not cases or bad or len(names) != len(set(names)):
            entry["status"] = "failed"
            entry["selection_error"] = "empty, duplicate, failed or skipped cases"
        if expected is not None and (len(cases) != len(expected) or set(names) != expected):
            entry["status"] = "failed"
            entry["selection_error"] = "actual cases differ from the frozen required set"
        if required_suffix and not any(n and n.endswith(required_suffix) for n in names):
            entry["status"] = "failed"
            entry["selection_error"] = "native predecessor withdrawal regression not executed"
    elif test:
        entry["status"] = "failed"
        entry["selection_error"] = "missing fresh JUnit"
    save()
    return entry["status"] == "passed"

try:
    save()
    for label, args in (
        ("fetch-final", ["git", "-C", str(SOURCE), "fetch", "--no-tags", "--depth=1", "https://github.com/TrillionniumFoundation/hepta-private-ci.git", COMMIT]),
        ("fetch-base", ["git", "-C", str(SOURCE), "fetch", "--no-tags", "--depth=1", "https://github.com/TrillionniumFoundation/hepta-private-ci.git", BASE]),
        ("checkout-final", ["git", "-C", str(SOURCE), "checkout", "--detach", COMMIT]),
    ):
        # Source preparation uses the existing exact reviewed command supervisor.
        if not command(label, args, timeout=600):
            raise RuntimeError(label + " failed")
    RESULT["source_before"] = require_source()
    paths = git("diff", "--name-only", "--diff-filter=ACMRT", BASE, COMMIT).decode().splitlines()
    RESULT["source_postimages_before"] = {p: digest(SOURCE / p) for p in paths if (SOURCE / p).is_file()}
    (OUT / "source-postimages.json").write_text(json.dumps(RESULT["source_postimages_before"], indent=2) + "\n")
    postimages = OUT / "source-postimages"
    postimages.mkdir()
    for path in paths:
        p = SOURCE / path
        if p.is_file() and not p.is_symlink() and p.stat().st_size <= 4 * 1024 * 1024:
            dest = postimages / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(p, dest)
    deps_path = ROOT / "build-dependencies/DEPENDENCIES.json"
    if deps_path.exists():
        deps = json.loads(deps_path.read_text())
        RESULT["dependency_receipt"] = digest(deps_path)
        if deps.get("protoc_usable"):
            ENV["PROTOC"] = deps["protoc_path"]
            ENV["LD_LIBRARY_PATH"] = deps["protoc_libraries"] + ":" + ENV.get("LD_LIBRARY_PATH", "")
    RESULT["build_environment"] = {name: ENV[name] for name in (
        "PATH", "RUSTUP_TOOLCHAIN", "CARGO_BUILD_JOBS", "CARGO_INCREMENTAL",
        "CARGO_PROFILE_TEST_DEBUG", "CARGO_PROFILE_DEV_DEBUG", "CARGO_TARGET_DIR",
        "HEPTA_MEM9_REQUIRE_ISOLATION") }
    if "PROTOC" in ENV:
        RESULT["build_environment"]["PROTOC"] = ENV["PROTOC"]
    command("tool-versions", ["/bin/sh", "-c", "rustc --version --verbose && cargo --version && cargo nextest --version && just --version && uv --version"], timeout=60)
    RESULT["strict_isolation_passed"] = command("strict-isolation", ["/usr/bin/python3.14", "-B", "-m", "unittest", "-v", "ndu_real_runtime.test_episodic_isolation"], minimum=8, timeout=180)
    native_ok = command("memory-episodic", ["just", "test", "--locked", "-p", "codex-hepta-memory", "--lib", "episodic", "--no-capture", "--retries", "0"], minimum=1, test=True)
    if native_ok:
        env_file = OUT / "v8.env"
        ENV["GITHUB_ENV"] = str(env_file)
        native_ok = command("verified-v8", ["/usr/bin/python3.14", str(SOURCE / "scripts/hepta_ci_v8.py")], timeout=900)
        if native_ok:
            if env_file.exists():
                for line in env_file.read_text().splitlines():
                    key, value = line.split("=", 1)
                    if key not in {"RUSTY_V8_ARCHIVE", "RUSTY_V8_SRC_BINDING_PATH"}:
                        raise RuntimeError("unexpected V8 export")
                    ENV[key] = value
            native_ok = command("codex-build", ["cargo", "build", "--locked", "--manifest-path", str(SOURCE / "codex-rs/Cargo.toml"), "-p", "codex-cli", "--bin", "codex"])
    if native_ok:
        binary = Path(ENV["CARGO_TARGET_DIR"]) / "debug/codex"
        RESULT["codex_binary_before"] = {"path": str(binary), **digest(binary)}
        ENV["CARGO_BIN_EXE_codex"] = str(binary)
        native_ok = command("agentd-episodic", ["just", "test", "--locked", "-p", "codex-hepta-agentd", "--lib", "episodic", "--no-capture", "--retries", "0"], minimum=1, test=True, required_suffix="native_predecessor_forget_closes_episodic_context")
    if native_ok:
        case = "app_runtime::tests::episodic_embedding_keeps_the_store_but_removes_implicit_memory_paths"
        native_ok = command("agentd-qualification-profile", ["just", "test", "--locked", "-p", "codex-hepta-agentd", "--features", "qualification-cognitive-write", "--lib", case, "--no-capture", "--retries", "0"], minimum=1, timeout=1800, test=True, expected={case})
    if native_ok:
        expression = "test(native_app_server::context::tests::) | test(native_app_server::control::tests::) | test(native_app_server::tests::real_agentd_worker_accepts_fresh_context_and_rejects_final_use_tombstone)"
        native_ok = command("native-delivery", ["just", "test", "--locked", "-p", "codex-hepta-infer-worker-host", "--lib", "-E", expression, "--no-capture", "--retries", "0"], minimum=7, test=True, expected=DELIVERY_CASES)
    if native_ok:
        native_ok = command("protocol", ["just", "test", "--locked", "-p", "codex-hepta-agent-protocol", "--no-capture", "--retries", "0"], minimum=1, test=True)
    RESULT["native_contracts_passed"] = native_ok
    if native_ok:
        RESULT["scoped_fix_passed"] = command("scoped-fix", ["just", "fix", "--locked", "-p", "codex-hepta-memory", "-p", "codex-hepta-agentd", "-p", "codex-hepta-infer-worker-host", "-p", "codex-hepta-agent-protocol"])
    RESULT["format_passed"] = command("final-format", ["just", "fmt", "--base", BASE], timeout=900)
    RESULT["source_after"] = identity()
    (OUT / "source-rewrites.patch").write_bytes(git("diff", "--binary", "HEAD"))
    RESULT["source_postimages_after"] = {p: digest(SOURCE / p) for p in paths if (SOURCE / p).is_file()}
    RESULT["source_unchanged"] = RESULT["source_before"] == RESULT["source_after"] and RESULT["source_postimages_before"] == RESULT["source_postimages_after"]
    if "codex_binary_before" in RESULT:
        RESULT["codex_binary_after"] = {"path": str(binary), **digest(binary)}
        RESULT["codex_binary_unchanged"] = RESULT["codex_binary_after"] == RESULT["codex_binary_before"]
    RESULT["status"] = "software_controls_passed" if (RESULT["strict_isolation_passed"] and native_ok and RESULT.get("scoped_fix_passed") and RESULT["format_passed"] and RESULT["source_unchanged"]) else "incomplete"
except BaseException as error:
    RESULT["status"] = "failed"
    RESULT["error"] = type(error).__name__ + ": " + str(error)
    (OUT / "exception.txt").write_text(traceback.format_exc())
finally:
    RESULT["finished_unix_ns"] = time.time_ns()
    save()
    manifest = {str(p.relative_to(OUT)): digest(p) for p in OUT.rglob("*") if p.is_file() and not p.is_symlink()}
    (OUT / "MEMBER_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    archive = ROOT / "native-811e0e27.tar.xz"
    with tarfile.open(archive, "x:xz") as target:
        target.add(OUT, arcname=OUT.name)
    publication = {"archive": str(archive), **digest(archive), "result": str(OUT / "RESULT.json"), "status": RESULT["status"]}
    (ROOT / "NATIVE_PUBLICATION.json").write_text(json.dumps(publication, indent=2) + "\n")
    print(json.dumps(publication, indent=2))
if RESULT["status"] != "software_controls_passed":
    raise SystemExit(1)
