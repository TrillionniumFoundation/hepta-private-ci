import hashlib,json,os,re,shutil,subprocess,time,traceback
from pathlib import Path
root=Path("/home/qq/work/mem12-native-qualification-20261112-ef0c")
out=root/"clang-resources-v1";out.mkdir(exist_ok=False)
receipt={"schema":"hepta.mem12.native-clang-resource-repair.v1","started_unix_ns":time.time_ns(),"source_commit":"811e0e27190066e81a23eebed8ad559ae67d228e","reason":"original memory compilation failed in aws-lc-sys bindgen: Clang21 could not find stddef.h","commands":[],"system_packages_modified":False,"tests_executed":0,"new_model_calls":0}
def save():
 p=out/"REPAIR.pending.json";p.write_text(json.dumps(receipt,indent=2)+"\n");p.replace(out/"REPAIR.json")
def run(name,args,cwd=None,timeout=180):
 p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=timeout)
 (out/(name+".stdout")).write_bytes(p.stdout);(out/(name+".stderr")).write_bytes(p.stderr)
 rec={"name":name,"args":args,"returncode":p.returncode,"stdout":p.stdout.decode(errors="replace"),"stderr":p.stderr.decode(errors="replace")}
 receipt["commands"].append(rec);save();return rec
try:
 save()
 run("installed-libclang",["/usr/bin/dpkg-query","-W","-f="+chr(36)+"{Package} "+chr(36)+"{Version}\n","libclang1-21","libclang-21-dev","libclang-common-21-dev"])
 run("candidate-common21",["/usr/bin/apt-cache","show","--no-all-versions","libclang-common-21-dev"])
 candidates=[p for parent in (Path("/usr/lib/llvm-21/lib/clang"),Path("/usr/lib/clang")) if parent.exists() for p in parent.glob("21*/include/stddef.h") if p.is_file()]
 receipt["existing_matching_headers"]=[str(p) for p in candidates];save()
 if not candidates:
  archives=out/"archives";archives.mkdir()
  downloaded=run("download-common21",["/usr/bin/apt-get","download","libclang-common-21-dev"],cwd=archives,timeout=240)
  if downloaded["returncode"]!=0:raise RuntimeError("matching Clang21 headers download failed")
  sysroot=out/"sysroot";sysroot.mkdir()
  receipt["packages"]=[]
  for package in sorted(archives.glob("*.deb")):
   info=run("package-info",["/usr/bin/dpkg-deb","-f",str(package),"Package","Version"])
   unpacked=run("unpack-common21",["/usr/bin/dpkg-deb","-x",str(package),str(sysroot)])
   if unpacked["returncode"]!=0:raise RuntimeError("matching Clang21 package extraction failed")
   receipt["packages"].append({"path":str(package),"bytes":package.stat().st_size,"sha256":hashlib.sha256(package.read_bytes()).hexdigest(),"package":info["stdout"]})
  candidates=[p for p in sysroot.rglob("stddef.h") if p.is_file() and re.search(r"/clang/21(?:[./])",str(p))]
 if len(candidates)!=1:raise RuntimeError("expected exactly one matching Clang21 standard resource directory")
 header=candidates[0];resource=header.parent.parent
 receipt["resource_dir"]=str(resource)
 receipt["stddef_header"]={"path":str(header),"sha256":hashlib.sha256(header.read_bytes()).hexdigest(),"bytes":header.stat().st_size}
 receipt["build_environment"]={"BINDGEN_EXTRA_CLANG_ARGS":"-resource-dir="+str(resource)}
 receipt["status"]="prepared"
except BaseException as error:
 receipt["status"]="failed";receipt["error"]=repr(error)
 (out/"exception.txt").write_text(traceback.format_exc())
finally:
 receipt["finished_unix_ns"]=time.time_ns();save();print(json.dumps({"receipt":str(out/"REPAIR.json"),"status":receipt["status"],"build_environment":receipt.get("build_environment"),"error":receipt.get("error")}))
if receipt["status"]!="prepared":raise SystemExit(1)
