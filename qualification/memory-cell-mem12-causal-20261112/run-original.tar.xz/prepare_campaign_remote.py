import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

EXPECTED_COMMIT = "811e0e27190066e81a23eebed8ad559ae67d228e"
EXPECTED_TREE = "2043cbf11fd00662cc23562123c27ae4e6f72580"
PROFILE = {'model_assets': {'config.json': {'bytes': 861, 'sha256': '8eb740e8bbe4cff95ea7b4588d17a2432deb16e8075bc5828ff7ba9be94d982a'}, 'generation_config.json': {'bytes': 132, 'sha256': '87b916edaaab66b3899b9d0dd0752727dff6666686da0504d89ae0a6e055a013'}, 'merges.txt': {'bytes': 466391, 'sha256': '0b54e8aa4e53d5383e2e4bc635a56b43f9647f7b13832d5d9ecd8f82dac4f510'}, 'model.safetensors': {'bytes': 269060552, 'sha256': '5af571cbf074e6d21a03528d2330792e532ca608f24ac70a143f6b369968ab8c'}, 'special_tokens_map.json': {'bytes': 655, 'sha256': '2b7379f3ae813529281a5c602bc5a11c1d4e0a99107aaa597fe936c1e813ca52'}, 'tokenizer.json': {'bytes': 2104556, 'sha256': '9ca9acddb6525a194ec8ac7a87f24fbba7232a9a15ffa1af0c1224fcd888e47c'}, 'tokenizer_config.json': {'bytes': 3764, 'sha256': '4ec77d44f62efeb38d7e044a1db318f6a939438425312dfa333b8382dbad98df'}, 'vocab.json': {'bytes': 800662, 'sha256': '82b84012e3add4d01d12ba14442026e49b8cbbaead1f79ecf3d919784f82dc79'}}, 'model_dir': '/home/qq/work/hpca-base-output-e901-20261112-evidence/execution/model', 'model_name': 'SmolLM2-135M-Instruct@12fd25f77366fa6b3b4b768ec3050bf629380bac', 'python_executable': '/usr/bin/python3.14', 'python_sha256': '52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41', 'runtime_sha256': 'd0814616180cc42103dbae19274f2a63fc02b7da75fd82d3d49ddd4553d0d76a', 'site_packages': '/home/qq/work/hpca-chat-native-run-20261112-t7/.venv/lib/python3.14/site-packages'}
ROOT = Path("/home/qq/work/mem12-causal-20261112-ef0c")
ROOT.mkdir(parents=True, exist_ok=False)
(ROOT / "prepare_campaign_remote.py").write_bytes(Path(__file__).read_bytes())
(ROOT / "EXECUTION_SPEC.json").write_text(json.dumps({'schema': 'hepta.mem12.outer-execution.v1', 'source_commit': '811e0e27190066e81a23eebed8ad559ae67d228e', 'source_tree': '2043cbf11fd00662cc23562123c27ae4e6f72580', 'host': 'ai395', 'root': '/home/qq/work/mem12-causal-20261112-ef0c', 'prepare_key': 'mem12-causal-prepare-20261112-ef0c-v1', 'run_key': 'mem12-causal-execute-20261112-ef0c-v1', 'outer_run_deadline_seconds': 7200, 'per_model_process_deadline_seconds': 60, 'planned_sources': 8, 'planned_arms': 10, 'planned_generation_rows': 80, 'independent_task_templates': 1, 'run_helper_sha256': 'dd88e2331b09964b238cf729af4fdad4abee2fe960b0443f1e4378b44fd6755f', 'unknown_action_policy': 'read original job and files; never reissue with a new key', 'scientific_acceptance': 'HOLD'}, sort_keys=True, indent=2) + "\n")
SOURCE = ROOT / "source"
SOURCE.mkdir()


def run_command(arguments):
    with (ROOT / "source-setup.log").open("ab") as log:
        result = subprocess.run(arguments, cwd=SOURCE, stdout=log, stderr=subprocess.STDOUT, timeout=600)
    if result.returncode:
        raise RuntimeError("source preparation failed: " + repr(arguments))


started = time.time_ns()
try:
    run_command(["git", "init"])
    run_command(["git", "remote", "add", "origin", "https://github.com/TrillionniumFoundation/hepta-private-ci.git"])
    run_command(["git", "-c", "protocol.version=2", "fetch", "--depth=1", "--filter=blob:none", "origin", EXPECTED_COMMIT])
    run_command(["git", "sparse-checkout", "init", "--cone"])
    run_command(["git", "sparse-checkout", "set", "scripts"])
    run_command(["git", "checkout", "--detach", "FETCH_HEAD"])
    identity = subprocess.check_output(["git", "rev-parse", "HEAD", "HEAD^{tree}"], cwd=SOURCE, text=True).splitlines()
    if identity != [EXPECTED_COMMIT, EXPECTED_TREE]:
        raise RuntimeError("source identity differs from published candidate")
    if subprocess.check_output(["git", "status", "--porcelain"], cwd=SOURCE):
        raise RuntimeError("new source is dirty")
    sys.path.insert(0, str(SOURCE / "scripts"))
    from ndu_real_runtime.episodic_local_provider import runtime_inventory
    from ndu_real_runtime.episodic_isolation import run_isolated_actor
    from ndu_real_runtime.run_episodic_diagnostic import prepare

    runtime = runtime_inventory(PROFILE["site_packages"])
    if runtime["sha256"] != PROFILE["runtime_sha256"]:
        raise RuntimeError("frozen runtime inventory changed")
    assets = {}
    for name, expected in PROFILE["model_assets"].items():
        path = Path(PROFILE["model_dir"]) / name
        if path.is_symlink() or not path.is_file():
            raise RuntimeError("model asset is not a regular file")
        h = hashlib.sha256()
        with path.open("rb") as stream:
            while block := stream.read(1048576):
                h.update(block)
        observed = {"bytes": path.stat().st_size, "sha256": h.hexdigest()}
        if observed != expected:
            raise RuntimeError("frozen model asset changed: " + name)
        assets[name] = observed
    probe = run_isolated_actor(ROOT / "namespace-probe", b'print("MEM12_SETUP_ONLY")\n', {"purpose": "setup-only"}, mode="off")
    if probe["status"] != "EXECUTED":
        raise RuntimeError("strict actor boundary unavailable")
    (ROOT / "PROFILE.json").write_text(json.dumps(PROFILE, sort_keys=True, indent=2) + "\n")
    plan = prepare(ROOT / "cohort", PROFILE, "mem12-ef0c-20261112-v1")
    result = {"status": "PREPARED", "source_commit": identity[0], "source_tree": identity[1], "runtime": runtime,
              "model_assets": assets, "planned_rows": 80, "plan_pin": json.loads((ROOT / "cohort" / "PLAN_PIN.json").read_text()),
              "namespace_probe_status": probe["status"], "new_model_calls": 0, "scientific_acceptance": "HOLD"}
except Exception as error:
    result = {"status": "PREPARE_FAILED", "error": type(error).__name__ + ": " + str(error), "new_model_calls": 0}
result.update(started_at_unix_ns=started, ended_at_unix_ns=time.time_ns())
(ROOT / "PREPARE_RESULT.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
print(json.dumps(result, sort_keys=True))
sys.exit(0 if result["status"] == "PREPARED" else 1)
