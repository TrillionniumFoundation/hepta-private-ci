import hashlib
import io
import json
from pathlib import Path
import resource
import sys
import tarfile
import time

ROOT = Path("/home/qq/work/mem12-causal-20261112-ef0c")
CAMPAIGN_DEADLINE_SECONDS = 7200
(ROOT / "run_campaign_remote.py").write_bytes(Path(__file__).read_bytes())
sys.path.insert(0, str(ROOT / "source" / "scripts"))
from ndu_real_runtime.run_episodic_diagnostic import run, report

prepared = json.loads((ROOT / "PREPARE_RESULT.json").read_text())
if prepared["status"] != "PREPARED":
    raise RuntimeError("no successful frozen preparation")
cohort = ROOT / "cohort"
started = time.time_ns()
error = None
try:
    result = run(cohort)
except Exception as exc:
    error = type(exc).__name__ + ": " + str(exc)
    result = report(cohort)
summary = {key: value for key, value in result.items() if key not in ("rows", "writer_receipts")}
summary.update(started_at_unix_ns=started, ended_at_unix_ns=time.time_ns(), run_error=error,
               outer_supervisor_deadline_seconds=CAMPAIGN_DEADLINE_SECONDS,
               source_commit=prepared["source_commit"], source_tree=prepared["source_tree"])


def observed_sum(values):
    observed = [v for v in values if type(v) in (int, float)]
    return {"observed_sum": sum(observed), "observed_rows": len(observed), "missing_rows": len(values) - len(observed)}


costs = {}
for arm in result["panels"]:
    rows = [r for r in result["rows"] if r["arm"] == arm]
    costs[arm] = {key: observed_sum([r.get(key) for r in rows]) for key in ("wall_seconds", "provider_wall_seconds_with_setup", "prompt_tokens", "output_tokens")}
summary["measured_costs_by_arm"] = costs
summary["common_A_writer_cost"] = {"wall_seconds": observed_sum([w["receipt"].get("wall_seconds") if isinstance(w.get("receipt"), dict) else None for w in result["writer_receipts"]]), "charged_once": True}
(ROOT / "RUN_SUMMARY.json").write_text(json.dumps(summary, sort_keys=True, indent=2) + "\n")
members = {}
for path in sorted([*cohort.rglob("*"), *(ROOT / "namespace-probe").rglob("*")]):
    if path.is_symlink():
        raise RuntimeError("unexpected evidence symlink")
    if path.is_file():
        raw = path.read_bytes()
        members[path.relative_to(ROOT).as_posix()] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
plan = json.loads((cohort / "PLAN.json").read_text())
for name, expected in plan["sources"].items():
    path = ROOT / "source" / "scripts" / name
    raw = path.read_bytes()
    actual = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    if actual != expected:
        raise RuntimeError("frozen source changed during campaign")
    members[path.relative_to(ROOT).as_posix()] = actual
for name in ("PROFILE.json", "PREPARE_RESULT.json", "RUN_SUMMARY.json", "source-setup.log", "prepare_campaign_remote.py", "run_campaign_remote.py", "EXECUTION_SPEC.json"):
    raw = (ROOT / name).read_bytes()
    members[name] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
index = (json.dumps(members, sort_keys=True, indent=2) + "\n").encode()
(ROOT / "EVIDENCE_INDEX.json").write_bytes(index)
archive = ROOT / "evidence.tar.xz"
with tarfile.open(archive, "w:xz") as tar:
    for name in sorted(members):
        tar.add(ROOT / name, arcname=name, recursive=False)
    info = tarfile.TarInfo("EVIDENCE_INDEX.json")
    info.size = len(index)
    tar.addfile(info, io.BytesIO(index))
with tarfile.open(archive, "r:xz") as tar:
    for name, pin in members.items():
        raw = tar.extractfile(name).read()
        if len(raw) != pin["bytes"] or hashlib.sha256(raw).hexdigest() != pin["sha256"]:
            raise RuntimeError("archive readback failed")
manifest = {"archive_bytes": archive.stat().st_size, "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
            "indexed_members": len(members), "verified": True}
(ROOT / "ARCHIVE.json").write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
print(json.dumps({"summary": summary, "archive": manifest}, sort_keys=True))
