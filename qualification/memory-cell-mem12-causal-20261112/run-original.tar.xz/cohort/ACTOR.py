import json
from pathlib import Path
task = json.loads(Path("/input/task.json").read_bytes())
memory = Path("/input/memory.txt")
notes = [] if not memory.exists() else [json.loads(line)["text"]
 for line in memory.read_text().splitlines() if line]
prompt = ("Use only the saved dispatch memo to answer the question. "
 "If the memo does not contain the answer, reply UNKNOWN. "
 "Reply with one color word only.\nSaved memo:\n" + "\n".join(notes)
 + "\nQuestion: " + task["question"] + "\nAnswer:")
print(json.dumps({"model": task["model"], "input": prompt, "store": False,
 "max_output_tokens": 32, "temperature": 0}, sort_keys=True,
 separators=(",", ":"), ensure_ascii=False, allow_nan=False))
