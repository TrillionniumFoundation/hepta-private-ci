import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path("/home/qq/work/mem12-native-qualification-20261112-ef0c")
source=root/"source-v2"; out=root/"preflight";out.mkdir(exist_ok=False)
env=dict(os.environ)
env["PATH"]="/home/qq/.cargo/bin:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/just-1.58.0:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/uv-0.13.5:"+env.get("PATH","/usr/bin:/bin")
env["PYTHONPATH"]=str(source/"scripts")
receipt={"started_unix_ns":time.time_ns(),"commands":[],"tool_paths":{}}
def save(): (out/"PREFLIGHT.json").write_text(json.dumps(receipt,indent=2)+"\n")
def run(label,args,timeout=60):
 p=subprocess.run(args,cwd=source,env=env,capture_output=True,timeout=timeout)
 (out/(label+".stdout")).write_bytes(p.stdout);(out/(label+".stderr")).write_bytes(p.stderr)
 receipt["commands"].append({"label":label,"args":args,"returncode":p.returncode,"stdout":p.stdout[:10000].decode(errors="replace"),"stderr":p.stderr[:10000].decode(errors="replace")});save()
for name in ("cargo","rustc","rustfmt","just","uv","bwrap","cmake","clang","clang++","cc","c++","protoc","pkg-config"):
 path=shutil.which(name,path=env["PATH"]);receipt["tool_paths"][name]=path
 if path is not None: run(name+"-version",[path,"--version"])
run("nextest-version",["/home/qq/.cargo/bin/cargo-nextest","--version"])
run("openssl-libcap",["/usr/bin/pkg-config","--modversion","openssl","libcap"])
run("namespace-probe",["/usr/bin/python3.14","-B","-m","ndu_real_runtime.isolation_host","--output",str(out/"host")],timeout=20)
receipt["host_report"]=json.loads((out/"host"/"HOST.json").read_text())
receipt["extra_tools"]={};receipt["cache_paths"]=[]
for base,dirs,files in os.walk("/home/qq/work"):
 p=Path(base);depth=len(p.relative_to("/home/qq/work").parts)
 if p.name.startswith(("target","cargo-target")) and (p/"debug").is_dir():
  receipt["cache_paths"].append({"path":str(p),"rustc_info":(p/".rustc_info.json").exists(),"v8_archives":[{"path":str(x),"bytes":x.stat().st_size} for x in p.glob("debug/build/v8-*/out/librusty_v8.a")][:10]})
  dirs[:]=[];continue
 dirs[:]=[d for d in dirs if d not in ("source","repo","codex-rs",".git",".venv","node_modules","model","site-packages","__pycache__","evidence","execution") and not d.startswith(".")]
 if depth>=6: dirs[:]=[]
 for name in ("clang","clang++","protoc","cmake"):
  if name in files and os.access(p/name,os.X_OK):receipt["extra_tools"].setdefault(name,[]).append(str(p/name))
receipt["finished_unix_ns"]=time.time_ns();save()
print(json.dumps({"receipt":str(out/"PREFLIGHT.json"),"tool_paths":receipt["tool_paths"],"extra_tools":receipt["extra_tools"],"cache_count":len(receipt["cache_paths"]),"namespace_status":receipt["host_report"]["probe"]["status"]},indent=2))

