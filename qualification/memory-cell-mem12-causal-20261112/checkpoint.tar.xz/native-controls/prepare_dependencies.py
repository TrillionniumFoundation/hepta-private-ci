import hashlib,json,os,re,shutil,subprocess,time,traceback
from pathlib import Path
root=Path("/home/qq/work/mem12-native-qualification-20261112-ef0c")
out=root/"build-dependencies";out.mkdir(exist_ok=False)
env=dict(os.environ);env["PATH"]="/home/qq/.cargo/bin:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/just-1.58.0:/home/qq/work/hepta-cell-s0-ai395-20261108-898e/tools/uv-0.13.5:"+env.get("PATH","/usr/bin:/bin")
env["RUSTUP_TOOLCHAIN"]="1.96.0"
j={"started_unix_ns":time.time_ns(),"commands":[]}
def save(): (out/"DEPENDENCIES.json").write_text(json.dumps(j,indent=2)+"\n")
def run(label,args,cwd=None,extra=None,timeout=180):
 p=subprocess.run(args,cwd=cwd,env=dict(env,**(extra or {})),capture_output=True,timeout=timeout)
 (out/(label+".stdout")).write_bytes(p.stdout);(out/(label+".stderr")).write_bytes(p.stderr)
 rec={"label":label,"args":args,"returncode":p.returncode,"stdout":p.stdout[:16000].decode(errors="replace"),"stderr":p.stderr[:16000].decode(errors="replace")};j["commands"].append(rec);save();return rec
for name in ("cargo","rustc","rustfmt"):run(name+"-pinned",[str(Path("/home/qq/.cargo/bin")/name),"--version"])
j["candidate_roots"]={}
for path in ("/tmp","/home/qq","/home/qq/.local","/home/qq/.cache"):
 p=Path(path)
 j["candidate_roots"][path]=[str(x) for x in p.iterdir() if x.is_dir() and any(t in x.name.lower() for t in ("cargo","target","hepta","rust","v8","proto"))][:100]
j["cache_paths"]=[]
for top in j["candidate_roots"].values():
 for name in top:
  for base,dirs,files in os.walk(name):
   p=Path(base);depth=len(p.relative_to(name).parts)
   if ".rustc_info.json" in files or (p.name.startswith(("target","cargo-target")) and (p/"debug").is_dir()):
    j["cache_paths"].append({"path":str(p),"rustc_info":(p/".rustc_info.json").exists(),"v8_archives":[{"path":str(x),"bytes":x.stat().st_size} for x in p.glob("debug/build/v8-*/out/librusty_v8.a")][:5]})
    dirs[:]=[];continue
   dirs[:]=[d for d in dirs if d not in (".git","src","registry","git","node_modules","site-packages",".venv")]
   if depth>=3:dirs[:]=[]
save()
sysroot="/home/qq/work/hepta-notes-qualification-20261105-4d868a11/tools/sysroot"
libs=":".join(str(p) for p in (Path(sysroot)/"usr/lib/x86_64-linux-gnu",Path(sysroot)/"usr/lib/llvm-18/lib",Path(sysroot)/"usr/lib/llvm-19/lib") if p.is_dir())
j["clang_sysroot"]=sysroot;j["clang_libraries"]=libs
run("clang-version",[sysroot+"/usr/bin/clang","--version"],extra={"LD_LIBRARY_PATH":libs})
protoc=run("apt-protobuf-metadata",["/usr/bin/apt-cache","show","--no-all-versions","protobuf-compiler"])
if protoc["returncode"]==0:
 depends="".join(line.split(":",1)[1] for line in protoc["stdout"].splitlines() if line.startswith("Depends:"))
 packages=["protobuf-compiler"]+sorted(set(re.findall(r"\b(libproto(?:buf|c)[a-zA-Z0-9+.-]*)\b",depends)))
 archives=out/"archives";archives.mkdir()
 download=run("download-protobuf",["/usr/bin/apt-get","download",*packages],cwd=archives)
 if download["returncode"]==0:
  dest=out/"sysroot";dest.mkdir();j["protobuf_packages"]=[]
  for p in sorted(archives.glob("*.deb")):
   version=run("package-"+p.name,["/usr/bin/dpkg-deb","-f",str(p),"Package","Version"])
   extraction=run("extract-"+p.name,["/usr/bin/dpkg-deb","-x",str(p),str(dest)])
   j["protobuf_packages"].append({"file":p.name,"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"version":version["stdout"],"extracted":extraction["returncode"]==0})
  protoc_path=dest/"usr/bin/protoc";libpath=dest/"usr/lib/x86_64-linux-gnu"
  j["protoc_path"]=str(protoc_path);j["protoc_libraries"]=str(libpath)
  probe=run("protoc-version",[str(protoc_path),"--version"],extra={"LD_LIBRARY_PATH":str(libpath)})
  j["protoc_usable"]=probe["returncode"]==0
j["finished_unix_ns"]=time.time_ns();save();print(json.dumps({"receipt":str(out/"DEPENDENCIES.json"),"cache_count":len(j["cache_paths"]),"protoc_usable":j.get("protoc_usable"),"protoc_path":j.get("protoc_path")}))

