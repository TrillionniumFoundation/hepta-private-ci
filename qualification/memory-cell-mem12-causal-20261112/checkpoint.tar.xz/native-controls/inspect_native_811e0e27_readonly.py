"""Read only: reconcile the submitted MEM12 native operation and its originals.

This collector never starts, cancels, reruns, or modifies another job. It does
not correct the original RESULT. Corrected interpretations belong in a separate
recovery record after these originals have been verified.
"""
import base64
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path("/home/qq/work/mem12-native-qualification-20261112-ef0c")
SOURCE = ROOT / "source-v2"
OUT = ROOT / "final-811e0e27"
TARGET_JUNIT = ROOT / "cargo-target/nextest/local/junit.xml"
SUBMITTED_JUNIT = SOURCE / "codex-rs/target/nextest/local/junit.xml"
KEYS = {
    "mem12-native-final-811e0e27-20261112-ef0c-v1",
    "mem12-native-user-dependencies-20261112-ef0c-v1",
}
EXPECTED_COMMIT = "811e0e27190066e81a23eebed8ad559ae67d228e"
EXPECTED_TREE = "2043cbf11fd00662cc23562123c27ae4e6f72580"
STAGES = (
    "fetch-final", "fetch-base", "checkout-final", "tool-versions",
    "strict-isolation", "memory-episodic", "verified-v8", "codex-build",
    "agentd-episodic", "agentd-qualification-profile", "native-delivery",
    "protocol", "scoped-fix", "final-format",
)
summary = {
    "schema": "hepta.mem12.native-readonly-reconciliation.v1",
    "observed_unix_ns": time.time_ns(),
    "expected_source": {"commit": EXPECTED_COMMIT, "tree": EXPECTED_TREE},
    "read_only": True,
    "no_replay": True,
    "files": {},
    "job_metadata_matches": [],
}


def read_file(path, content_limit=65536, tail_limit=0):
    name = str(path)
    rec = {"path": name}
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            before = os.fstat(fd)
            if not stat.S_ISREG(before.st_mode):
                raise ValueError("not a regular file")
            if before.st_size > 256 * 1024 * 1024:
                raise ValueError("read bound exceeded")
            chunks = []
            h = hashlib.sha256()
            tail = b""
            length = 0
            while data := os.read(fd, 1024 * 1024):
                h.update(data)
                length += len(data)
                if before.st_size <= content_limit:
                    chunks.append(data)
                if tail_limit:
                    tail = (tail + data)[-tail_limit:]
            after = os.fstat(fd)
        finally:
            os.close(fd)
        stable = (
            before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
        ) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
        rec.update(
            bytes=length, sha256=h.hexdigest(), stable=stable,
            mtime_ns=after.st_mtime_ns,
        )
        if chunks:
            raw = b"".join(chunks)
            if path.suffix == ".json":
                try:
                    rec["json"] = json.loads(raw)
                except (ValueError, UnicodeDecodeError):
                    rec["invalid_json_base64"] = base64.b64encode(raw).decode()
            elif path.suffix == ".xml":
                try:
                    root = ET.fromstring(raw)
                    rec["junit"] = {
                        "root": root.attrib,
                        "suites": [
                            {
                                "attributes": suite.attrib,
                                "cases": [
                                    {
                                        "attributes": case.attrib,
                                        "bad": [
                                            bad.tag for bad in case
                                            if bad.tag in ("failure", "error", "skipped")
                                        ],
                                    }
                                    for case in suite.findall("testcase")
                                ],
                            }
                            for suite in (
                                [root] if root.tag == "testsuite"
                                else root.findall(".//testsuite")
                            )
                        ],
                    }
                except ET.ParseError as error:
                    rec["parse_error"] = str(error)
            else:
                rec["text"] = raw.decode("utf-8", errors="replace")
        elif tail_limit and tail:
            rec["tail"] = tail.decode("utf-8", errors="replace")
        if not stable:
            rec["interpretation"] = "CHANGED_DURING_READ; original still needed"
    except (OSError, ValueError) as error:
        rec["error"] = type(error).__name__ + ": " + str(error)
    summary["files"][name] = rec
    return rec


env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
summary["source"] = {}
for key, args in (
    ("commit", ["rev-parse", "HEAD"]),
    ("tree", ["rev-parse", "HEAD^{tree}"]),
    ("status", ["status", "--porcelain"]),
):
    try:
        result = subprocess.run(
            ["/usr/bin/git", "-C", str(SOURCE), *args],
            env=env, capture_output=True, timeout=30, check=False,
        )
        summary["source"][key] = {
            "exit_code": result.returncode,
            "stdout": result.stdout.decode("utf-8", errors="replace"),
            "stderr": result.stderr.decode("utf-8", errors="replace"),
        }
    except (OSError, subprocess.TimeoutExpired) as error:
        summary["source"][key] = {"error": str(error)}

for path in (
    ROOT / "build-dependencies/DEPENDENCIES.json",
    OUT / "RESULT.json",
    ROOT / "NATIVE_PUBLICATION.json",
    OUT / "MEMBER_MANIFEST.json",
    OUT / "source-postimages.json",
    OUT / "source-rewrites.patch",
    OUT / "exception.txt",
    TARGET_JUNIT,
    SUBMITTED_JUNIT,
):
    read_file(path)

for stage in STAGES:
    for suffix in (".receipt.json", ".junit.xml", ".console.log"):
        read_file(
            OUT / (stage + suffix),
            content_limit=65536 if suffix != ".console.log" else 4096,
            tail_limit=4096 if suffix == ".console.log" else 0,
        )

# Strict tests retain separate admission and Linux execution records. Inventory
# only this operation's evidence tree and include small original JSON receipts.
strict_root = OUT / "strict-attempts"
if strict_root.is_dir() and not strict_root.is_symlink():
    for path in sorted(strict_root.rglob("*"))[:256]:
        if path.is_file() and not path.is_symlink():
            read_file(path, content_limit=16384 if path.suffix == ".json" else 0)

# A lost start acknowledgement can be reconciled by its exact stable key.
# Inspect only jobs created after the already-observed preflight. Do not expose
# unrelated job payloads, credentials, commands, or output.
jobs = Path("/home/qq/.local/state/hepta-runtime-mac-worker/jobs")
metadata_candidates = []


def bound_keys(value):
    if isinstance(value, dict):
        found = {value["idempotency_key"]} if value.get("idempotency_key") in KEYS else set()
        for child in value.values():
            found.update(bound_keys(child))
        return found
    if isinstance(value, list):
        return set().union(*(bound_keys(child) for child in value))
    return set()


try:
    for path in jobs.iterdir():
        try:
            created_ms = int(path.name.split("-", 1)[0], 16)
        except ValueError:
            continue
        if created_ms >= 1794465745245 and path.is_dir() and not path.is_symlink():
            metadata_candidates.append((created_ms, path))
    summary["job_lookup_candidates"] = len(metadata_candidates)
    summary["job_lookup_bound"] = 256
    summary["job_lookup_complete"] = len(metadata_candidates) <= 256
    for _, directory in sorted(metadata_candidates, reverse=True)[:256]:
        for path in sorted(directory.glob("*.json")):
            if path.is_symlink() or path.stat().st_size > 128 * 1024:
                continue
            raw = path.read_bytes()
            if not any(key.encode() in raw for key in KEYS):
                continue
            try:
                obj = json.loads(raw)
            except (ValueError, UnicodeDecodeError):
                continue
            matched = sorted(bound_keys(obj))
            if not matched:
                continue
            summary["job_metadata_matches"].append({
                "job_id": directory.name,
                "path": str(path),
                "bytes": len(raw),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "matched_keys": matched,
                "metadata": obj,
            })
except OSError as error:
    summary["job_lookup_error"] = str(error)

summary["finished_unix_ns"] = time.time_ns()
print(json.dumps(summary, separators=(",", ":"), sort_keys=True))

