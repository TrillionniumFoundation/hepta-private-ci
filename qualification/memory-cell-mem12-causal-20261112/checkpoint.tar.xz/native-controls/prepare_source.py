import hashlib,json,os,shutil,subprocess,time,traceback
from pathlib import Path
root=Path("/home/qq/work/mem12-native-qualification-20261112-ef0c")
source=root/"source"
expected="dfe3291ed907b380589ede923c782f0bc9f8baed"
tree="3bcb77c86f0fb6eb66d45959787b58b17f65acca"
root.mkdir(parents=True,exist_ok=False)
records=root/"setup"
records.mkdir()
receipt={"status":"preparing","expected_commit":expected,"expected_tree":tree,"started_unix_ns":time.time_ns(),"commands":[]}
def save():
 t=records/"SETUP.pending.json";t.write_text(json.dumps(receipt,indent=2)+"\n");t.replace(records/"SETUP.json")
def run(label,args,cwd=None,timeout=600):
 receipt["commands"].append({"label":label,"args":args,"cwd":str(cwd) if cwd else None});save()
 with (records/(label+".log")).open("wb") as out:
  p=subprocess.run(args,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,timeout=timeout)
 receipt["commands"][-1]["returncode"]=p.returncode;save()
 if p.returncode: raise RuntimeError(label+" returned "+str(p.returncode))
 return (records/(label+".log")).read_text()
try:
 save()
 run("clone",["/usr/bin/git","clone","--shared","--no-checkout","/home/qq/work/hepta-daemon-learning-5600-20261110/source",str(source)])
 run("fetch",["/usr/bin/git","-C",str(source),"fetch","--no-tags","--depth=1","https://github.com/TrillionniumFoundation/hepta-private-ci.git",expected])
 run("checkout",["/usr/bin/git","-C",str(source),"checkout","--detach",expected])
 identity=run("source-identity",["/usr/bin/git","-C",str(source),"rev-parse","HEAD","HEAD^{tree}"]).splitlines()
 assert identity==[expected,tree],identity
 assert not run("source-status",["/usr/bin/git","-C",str(source),"status","--porcelain"])
 receipt["agents_sha256"]=hashlib.sha256((source/"AGENTS.md").read_bytes()).hexdigest()
 receipt["source_identity"]=identity
 receipt["disk_free_bytes"]=shutil.disk_usage(root).free
 tools={}
 for base in (Path("/home/qq/.cargo/bin"),Path("/home/qq/.local/bin"),Path("/usr/local/bin"),Path("/usr/bin")):
  if not base.exists(): continue
  for p in base.iterdir():
   if p.name in ("just","uv","protoc","cmake","cargo","rustc","rustfmt","rustup") or p.name.startswith(("clang-","clang++-")):
    if p.is_file() and os.access(p,os.X_OK): tools.setdefault(p.name,[]).append(str(p))
 for base,dirs,files in os.walk("/home/qq/work"):
  depth=len(Path(base).relative_to("/home/qq/work").parts)
  dirs[:]=[d for d in dirs if d not in ("source","repo","codex-rs","target",".git",".venv","node_modules","model",".cache") and not d.startswith(".")]
  if depth>=4: dirs[:]=[]
  for name in ("just","uv","protoc","clang","clang++","cmake"):
   if name in files and os.access(Path(base)/name,os.X_OK): tools.setdefault(name,[]).append(str(Path(base)/name))
 receipt["tools"]=tools
 receipt["toolchains"]=run("toolchains",["/home/qq/.cargo/bin/rustup","toolchain","list"],timeout=30)
 candidates=[
 "/home/qq/work/hepta-audit-b16-20261105/source/codex-rs/target",
 "/home/qq/work/hepta-audit-pty-diagnostic-20261105/source/codex-rs/target",
 "/home/qq/work/hepta-cell-learning-050e-20261106/source/codex-rs/target",
 "/home/qq/work/hepta-cell-six-371753-20261106/source/codex-rs/target",
 "/home/qq/work/hepta-ci-4853-20261105-bdb7/source/codex-rs/target",
 "/home/qq/work/hepta-convergence-20261105-0c901b/source/codex-rs/target",
 "/home/qq/work/hepta-neuron-framework-734df8eaf8dc-20261106/source/codex-rs/target"]
 receipt["target_caches"]=[]
 for entry in candidates:
  p=Path(entry)
  rec={"path":entry,"exists":p.is_dir(),"resolved":str(p.resolve())}
  if p.is_dir():
   rec["top"]=[x.name for x in p.iterdir()][:20]
   rec["v8_archives"]=[{"path":str(x),"bytes":x.stat().st_size} for x in p.glob("debug/build/v8-*/out/librusty_v8.a")][:10]
  receipt["target_caches"].append(rec)
 receipt["status"]="prepared"
except BaseException as exc:
 receipt["status"]="failed";receipt["error"]=type(exc).__name__+": "+str(exc);traceback.print_exc()
finally:
 receipt["finished_unix_ns"]=time.time_ns();save();print(json.dumps(receipt,indent=2))
if receipt["status"]!="prepared": raise SystemExit(1)

