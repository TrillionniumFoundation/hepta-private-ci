"""Retain every command in this bounded implementation validation; no E scoring."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import traceback
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
PLAN = json.loads((ROOT / "validation-plan-v3.json").read_text())
PYTHON = "/home/qian-qi/hepta-hcsn-trainer-20261108-s3-v1/dependency-recovery-v2/venv/bin/python"
S4 = "/home/qian-qi/hepta-hcsn-trainer-20261108-s3-v1/dependency-recovery-v3/s4"
DATA = "/home/qian-qi/hepta-hcsn-math-closure-20261108-v1/final-native/localization/official-localization.zip"
source = ROOT / "source-v1"
output = ROOT / "validation-v3"
started = time.monotonic()
output.mkdir(exist_ok=False)
report = {"schema": "hcsn-trainer-native-validation-v1", "plan": PLAN, "attempts": [],
          "scientific_admission": "HOLD", "formal_fits_started": 0, "confirmation_access": False,
          "physical_energy_joules": None, "provider_charges": None, "status": "started"}
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
           OPENBLAS_NUM_THREADS="1", CUDA_VISIBLE_DEVICES="", HCSN_S4_REPO=S4)
journal = (output / "commands.jsonl").open("x")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def command(name, arguments, seconds):
    if time.monotonic() - started >= PLAN["whole_validation_seconds"]:
        row = {"name": name, "status": "not_started_whole_budget", "argv": arguments}
        report["attempts"].append(row)
        return row
    row = {"name": name, "status": "started", "argv": arguments, "timeout_seconds": seconds}
    journal.write(json.dumps(row) + "\n"); journal.flush()
    begin = time.monotonic()
    with (output / (name + ".stdout")).open("xb") as stdout, (output / (name + ".stderr")).open("xb") as stderr:
        try:
            process = subprocess.run(arguments, cwd=source, env=env, stdout=stdout, stderr=stderr,
                                     timeout=min(seconds, PLAN["whole_validation_seconds"] - (time.monotonic() - started)), check=False)
            row.update(status="completed" if process.returncode == 0 else "failed", returncode=process.returncode)
        except subprocess.TimeoutExpired:
            row.update(status="timed_out", returncode=None)
        except OSError as error:
            row.update(status="launch_failed", returncode=None, error=str(error))
    row.update(wall_seconds=time.monotonic() - begin,
               stdout_sha256=digest(output / (name + ".stdout")), stderr_sha256=digest(output / (name + ".stderr")))
    journal.write(json.dumps(row) + "\n"); journal.flush()
    report["attempts"].append(row)
    return row


try:
    archive = ROOT / "source-v1.zip"
    if digest(archive) != PLAN["source_archive_sha256"]:
        raise ValueError("source archive mismatch")
    source.mkdir(exist_ok=True)
    with ZipFile(archive) as zipped:
        for name in zipped.namelist():
            if not (source / name).resolve().is_relative_to(source.resolve()):
                raise ValueError("unsafe archive path")
        for name in zipped.namelist():
            if (source / name).read_bytes() != zipped.read(name):
                raise ValueError("retained source differs from frozen archive")
    report["source_before"] = {str(path.relative_to(source)): digest(path) for path in sorted(source.rglob("*")) if path.is_file()}
    module = source / "proposals/localization-v2"
    for name, args in [
        ("regression", ["-m", "unittest", "discover", "-s", str(module), "-p", "test_*.py", "-v"]),
        ("capacity", [str(module / "capacity.py"), "--target-real-scalars", "9804", "--minimum-width", "2", "--maximum-width", "128",
                      "--s4-repo", S4, "--output", str(output / "capacity.json")]),
        ("prepare", [str(module / "train_development.py"), "prepare", "--archive", DATA, "--output", str(output / "data")])]:
        row = command(name, [PYTHON, "-B", *args], 180)
        if row["status"] != "completed":
            raise RuntimeError(name + " did not complete")
    report["capacity_sha256"] = digest(output / "capacity.json")
    manifest = output / "data/data-manifest.json"
    report["prepared_manifest_sha256"] = digest(manifest)
    for row in json.loads((output / "capacity.json").read_text())["arms"]:
        arm = row["arm"]
        args = [PYTHON, "-B", str(module / "train_development.py"), "fit", "--prepared", str(manifest.parent),
                "--manifest-sha256", digest(manifest), "--output", str(output / arm), "--arm", arm,
                "--width", str(row["selected"]["width"]), "--seed", "101", "--epochs", "1", "--max-updates", "12",
                "--memorization-updates", "16", "--learning-rate", ".003", "--weight-decay", ".0001",
                "--gradient-norm-cap", "1", "--wall-seconds", "140", "--rss-bytes", str(2**31), "--s4-repo", S4]
        command("fit-" + arm, args, 150)
    report["status"] = "completed_validation_only" if all(row["status"] == "completed" for row in report["attempts"]) else "partial_validation"
except Exception:
    report.update(status="failed_validation", error=traceback.format_exc())
finally:
    report["wall_seconds"] = time.monotonic() - started
    report["source_after"] = {str(path.relative_to(source)): digest(path) for path in sorted(source.rglob("*")) if path.is_file()}
    report["source_unchanged"] = report.get("source_before") == report["source_after"]
    if not report["source_unchanged"]:
        report["status"] = "source_changed"
    journal.close()
    save(output / "RESULT.json", report)
    print(json.dumps({"status": report["status"], "attempts": len(report["attempts"]), "wall_seconds": report["wall_seconds"]}))
