import hashlib,io,json,os,shutil,sys,tarfile,time
from pathlib import Path
root=Path("/home/qian-qi/work/hepta-upstream-replacement-interface-20261119-2e9b")
pub=root/"publication-1";pub.mkdir(exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
def canonical(v):return (json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)+"\n").encode()
def write(p,v):
 with p.open("xb") as f:f.write(canonical(v))
with (root/"CONTROLLER_RECEIPTS.json").open("xb") as f:f.write(sys.argv[1].encode())
with (pub/"archive_creator.py").open("xb") as f:f.write(sys.argv[2].encode())
d=json.loads((root/"DEPLOYMENT.json").read_bytes());p=json.loads((root/"prepared/PROTOCOL.json").read_bytes())
assert json.loads((root/"analysis-1/READOUT.json").read_bytes())["status"]=="COMPLETE_ORIGINAL_24_RECONCILED"
assert json.loads((root/"owned-evaluation-1/COMPLETE.json").read_bytes())["actual_model_calls"]==24
for name,digest in d["candidate_files"].items():assert sha((root/"execution-source-2"/name).read_bytes())==digest
external=root/"external-originals";external.mkdir(exist_ok=False)
external_index=[]
for ordinal,(path,digest) in enumerate(d["external_source_files"].items()):
 original=Path(path);raw=original.read_bytes();assert sha(raw)==digest
 dest=external/("source-"+str(ordinal)+"-"+original.name)
 with dest.open("xb") as f:f.write(raw)
 external_index.append({"original_path":path,"archived_path":str(dest.relative_to(root)),"bytes":len(raw),"sha256":sha(raw)})
for mode,v in p["models"].items():
 original=Path(v["path"]);raw=original.read_bytes();assert sha(raw)==v["file_sha256"]
 dest=external/(mode+"-manifest.json")
 with dest.open("xb") as f:f.write(raw)
 external_index.append({"original_path":str(original),"archived_path":str(dest.relative_to(root)),"bytes":len(raw),"sha256":sha(raw),"model_weights_not_duplicated":"exact original weights already retained in earlier published experiment archive"})
write(external/"INDEX.json",external_index)
policy=root/"pre-execution-policy";policy.mkdir(exist_ok=False)
for name in ["replacement-18b163-gate","replacement-df459-metadata-gate"]:
 original=Path("/home/qian-qi/work/hepta-layout-final-evidence-policy-20261119-2e9b")/name
 shutil.copytree(original,policy/name)
relative=["execution-source-2","execution-source-preparation-2","deployment-preflight-1","deployment-preflight-2","analysis-source-1","analysis-source-preparation-1","mechanism-source-preparation-1","prepared","results","owned-evaluation-1","owned-readout-1","analysis-1","mechanism-1","owned-mechanism-1","monitor-1","external-originals","pre-execution-policy","DEPLOYMENT.json","OWNER_TERMINAL.json","CONTROLLER_RECEIPTS.json"]
files=[]
for name in relative:
 path=root/name
 assert path.exists(),name
 if path.is_file():files.append(path)
 else:files.extend(x for x in path.rglob("*") if x.is_file() and "__pycache__" not in x.parts)
files.append(pub/"archive_creator.py")
files=sorted(set(files),key=lambda path:str(path.relative_to(root)))
assert not any(path.is_symlink() for path in files)
rows=[{"path":str(path.relative_to(root)),"bytes":path.stat().st_size,"sha256":sha(path.read_bytes())} for path in files]
index={"schema":"hepta.replacement-original-24-archive.v1","execution_source_commit":d["source_commit"],"protocol_sha256":d["protocol_sha256"],"file_count":len(rows),"uncompressed_bytes":sum(row["bytes"] for row in rows),"files":rows,"companion_CPU_archive":{"path":"cpu/CPU_QUALIFICATION.tar.xz","bytes":84484,"sha256":"2512f36a59a25eea5dfc0ffe0f43c0cee0e5a799b5d65c6656dd266652895efb","file_count":361},"derived_pycache_omitted":True,"old_scores_unchanged":True}
write(pub/"INDEX.json",index)
start=time.perf_counter()
archive=pub/"RAW_EVIDENCE.tar.xz"
with tarfile.open(archive,"w:xz",preset=6) as tar:
 for path,row in zip(files,rows):
  raw=path.read_bytes();assert len(raw)==row["bytes"] and sha(raw)==row["sha256"]
  info=tarfile.TarInfo(row["path"]);info.size=len(raw);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(raw))
expected={row["path"]:row for row in rows}
with tarfile.open(archive,"r:xz") as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for member in members:
  assert member.isfile() and member.name in expected
  raw=tar.extractfile(member).read();row=expected[member.name]
  assert sha(raw)==row["sha256"] and len(raw)==row["bytes"]
meta={"schema":"hepta.replacement-original-24-archive-receipt.v1","path":str(archive),"bytes":archive.stat().st_size,"sha256":sha(archive.read_bytes()),"index_sha256":sha((pub/"INDEX.json").read_bytes()),"verified_members":len(rows),"uncompressed_bytes":sum(row["bytes"] for row in rows),"archive_and_member_verification_wall_seconds":time.perf_counter()-start,"finished_at_ns":str(time.time_ns()),"new_model_calls":0,"new_native_children":0}
write(pub/"ARCHIVE.json",meta)
exports={
 "postprocess/readout.py":root/"analysis-source-1/readout.py",
 "postprocess/mechanism.py":root/"analysis-source-1/mechanism.py",
 "postprocess/READOUT_SOURCE_PREPARATION.json":root/"analysis-source-preparation-1/RESULT.json",
 "postprocess/MECHANISM_SOURCE_PREPARATION.json":root/"mechanism-source-preparation-1/RESULT.json",
 "READOUT.json":root/"analysis-1/READOUT.json",
 "COST_LEDGER.json":root/"analysis-1/COST_LEDGER.json",
 "CALLS.json":root/"analysis-1/CALLS.json",
 "PAIRED_TASKS.json":root/"analysis-1/PAIRED_TASKS.json",
 "INPUT_INDEX.json":root/"analysis-1/INPUT_INDEX.json",
 "mechanism/MECHANISM.json":root/"mechanism-1/MECHANISM.json",
 "mechanism/PRIOR_SUPERVISION.json":root/"mechanism-1/PRIOR_SUPERVISION.json",
 "mechanism/PAIRS.json":root/"mechanism-1/PAIRS.json",
 "mechanism/INPUT_INDEX.json":root/"mechanism-1/INPUT_INDEX.json",
 "original/COMPLETE.json":root/"owned-evaluation-1/COMPLETE.json",
 "original/OWNER_TERMINAL.json":root/"OWNER_TERMINAL.json",
 "original/P_RESULT.json":root/"results/P/RESULT.json",
 "original/document_evidence_RESULT.json":root/"results/document_evidence/RESULT.json",
 "original/native_feedback_RESULT.json":root/"results/native_feedback/RESULT.json",
 "INDEX.json":pub/"INDEX.json",
 "ARCHIVE.json":pub/"ARCHIVE.json",
 "postprocess/readout_EXIT.json":root/"owned-readout-1/EXIT.json",
 "postprocess/mechanism_EXIT.json":root/"owned-mechanism-1/EXIT.json",
}
with (pub/"EXPORT.jsonl").open("xb") as stream:
 for relative,path in exports.items():
  raw=path.read_bytes();assert len(raw)<=512000
  stream.write(canonical({"relative":relative,"original_path":str(path),"bytes":len(raw),"sha256":sha(raw),"text":raw.decode()}))
print(json.dumps({"archive":meta,"export_bytes":(pub/"EXPORT.jsonl").stat().st_size,"export_sha256":sha((pub/"EXPORT.jsonl").read_bytes()),"export_files":len(exports)},sort_keys=True))
