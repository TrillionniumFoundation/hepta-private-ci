"""Summarize retained read-only GitHub responses; does not execute tests or jobs."""

from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import re
import zipfile

ROOT = Path('/workspace/scratch/456fa5e702a7/new-ci-readback')
HEAD = '58035205857c154530ba249cb3494cfe739e1875'
RUN_IDS = (43169903848, 43169903915, 43169904934, 43169903898)


def read(name):
    return json.loads((ROOT / name).read_text())


def sha256(data):
    return hashlib.sha256(data).hexdigest()


log_path = ROOT / 'logs-131020438882-final.log'
log_bytes = log_path.read_bytes()
log = log_bytes.decode()
assert len(log_bytes) == 110040
assert sha256(log_bytes) == 'ea17eef47d534c115325132211289fee1529f0b48d015eacebaa529b253cc5a8'
test_rows = re.findall(r'^\S+ (test_\S+) \(([^)]+)\) \.\.\. (.+)$', log, re.M)
test_ids = [row[1] for row in test_rows]
assert len(test_ids) == len(set(test_ids)) == 314
assert all(row[2] == 'ok' for row in test_rows)
assert re.findall(r'Ran (\d+) tests in ([0-9.]+)s', log) == [('314', '16.392')]
assert HEAD in log and 'CONSISTENT_COMPLETE_RECORDS' in log
marker = re.findall(r'ACTUAL_DRAW_PROCESS_DEATH (\{[^\n]+\})', log)
assert len(marker) == 1
death_marker = json.loads(marker[0])
assert death_marker == dict(stage='actual_entropy_draw_before_commit', draw=1, returncode=-9)

runs, all_jobs, observations = [], [], []
for run_id in RUN_IDS:
    run = read(f'run-{run_id}-final.raw.json')
    job_response = read(f'jobs-{run_id}-final.raw.json')
    run_envelope = read(f'run-{run_id}-final.envelope.json')
    jobs_envelope = read(f'jobs-{run_id}-final.envelope.json')
    assert run['head_sha'] == HEAD and run['run_attempt'] == 1
    assert job_response['total_count'] == len(job_response['jobs']) < 100
    jobs = []
    for job in job_response['jobs']:
        assert job['head_sha'] == HEAD and job['run_attempt'] == 1 and job['run_id'] == run_id
        initial_log = read(f"logs-{job['id']}-initial.result.json")
        initial_result = initial_log['result']
        assert initial_result['isError'] and initial_result['structuredContent']['error_code'] == 'NOT_FOUND'
        log_summary = dict(
            initial_query_at=initial_log['finished_utc'],
            initial_result='404 BlobNotFound',
            initial_raw_file=f"logs-{job['id']}-initial.result.json",
            available_original_log=False,
        )
        if job['id'] == 131020438882:
            assert job['status'] == 'completed' and job['conclusion'] == 'success'
            log_summary.update(
                available_original_log=True,
                final_query_at=read('logs-131020438882-final.envelope.json')['finished_utc'],
                raw_log_file=log_path.name, utf8_bytes=len(log_bytes), sha256=sha256(log_bytes),
                tests=314, unique_test_method_ids=314, duplicate_test_method_ids=0,
                all_test_method_results='ok', seconds=16.392,
                exact_source_checkout=HEAD, consistent_complete_records=True,
                actual_draw_process_death=death_marker,
            )
        row = {key: job.get(key) for key in (
            'id', 'run_id', 'run_attempt', 'head_sha', 'name', 'status', 'conclusion',
            'started_at', 'completed_at', 'runner_id', 'runner_name', 'runner_group_id',
            'runner_group_name', 'labels', 'html_url', 'url', 'steps')}
        row['runner_assigned'] = bool(job['runner_id'])
        row['logs'] = log_summary
        jobs.append(row)
        all_jobs.append(row)
    runs.append(dict(
        id=run_id, name=run['name'], head_sha=run['head_sha'],
        attempt=run['run_attempt'], status=run['status'], conclusion=run['conclusion'],
        html_url=run['html_url'], source_tree_sha=run['head_commit']['tree_id'],
        run_read_at=run_envelope['finished_utc'], jobs_read_at=jobs_envelope['finished_utc'],
        currently_listed_job_count=job_response['total_count'], jobs=jobs,
    ))
    observations.append(jobs_envelope['finished_utc'])

source_result = read('test_check_opportunities.remote.result.json')['structuredContent']
source_bytes = (ROOT / 'test_check_opportunities.remote.py').read_bytes()
blob_sha = hashlib.sha1(b'blob ' + str(len(source_bytes)).encode() + b'\0' + source_bytes).hexdigest()
assert blob_sha == source_result['sha'] == 'f2136bbd5342a56afd68046315611440937db480'
local_source = Path('/workspace/scratch/456fa5e702a7/verify-work/experiments/verification_cell_verify1/test_check_opportunities.py')
assert source_bytes == local_source.read_bytes()
source = source_bytes.decode()
assert 'self.assertNotEqual(returncode, 0)' in source
assert 'process.kill()' in source
assert 'signal.SIGKILL' not in source and 'assertEqual(returncode, -9)' not in source

summary = dict(
    schema='hepta.verify.final-head-ci-readback.v1',
    generated_utc=datetime.now(timezone.utc).isoformat(), head_sha=HEAD,
    attempt=1, latest_jobs_read_at=max(observations), runs=runs,
    currently_listed_job_status_counts=dict(Counter(job['status'] for job in all_jobs)),
    currently_listed_job_conclusion_counts=dict(Counter(str(job['conclusion']) for job in all_jobs)),
    all_current_job_pages_complete=True,
    current_job_roster_is_not_a_frozen_future_workflow_dag=True,
    can_truthfully_say_ci_still_pending=True,
    recommended_status='Exact new head: macOS 314 unique tests passed; Windows/Ubuntu and remaining listed gates are still pending.',
    no_completed_failures_in_current_readback=True,
    sigkill_control_review=dict(
        exact_source_url=source_result['display_url'], git_blob_sha1=blob_sha,
        source_sha256=sha256(source_bytes), matches_local_final_source=True,
        process_kill_is_used=True, asserts_nonzero_instead_of_posix_signal_number=True,
        official_api_reference='https://docs.python.org/3/library/subprocess.html#subprocess.Popen.kill',
        official_api_semantics='POSIX kill sends SIGKILL; Windows kill aliases terminate/TerminateProcess.',
        confirmed_cross_platform_defect_found=False,
        macos_original_execution_observed=True,
        windows_execution_qualification=False,
        windows_pending_is_not_failure=True,
    ),
    actions=dict(read_only=True, rerun=False, cancel=False, source_edit=False,
                 local_test_execution=False, wait_for_queued_jobs=False),
    limits=[
        'The macOS result is bound only to this exact head, attempt and job.',
        'Pending jobs have runner_id=0 and empty steps; actual infrastructure cause is not established.',
        'Log 404 responses are historical absence of a retained blob at query time, not job failure.',
        'A run-level queued value does not erase a completed successful job within that run.',
        'Later workflow jobs may materialize after prerequisite jobs; current API pages are not a frozen future job denominator.',
        'Engineering checks do not establish independent ordinary-business truth or the net value of paid checks.',
    ],
)
(ROOT / 'SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
(ROOT / 'UNIQUE_TEST_IDS.json').write_text(json.dumps(test_ids, indent=2) + '\n')

table_rows = []
for job in all_jobs:
    state = job['status'] + (' / ' + job['conclusion'] if job['conclusion'] else '')
    runner = str(job['runner_id']) if job['runner_assigned'] else '0 (unassigned)'
    log_state = 'Full original log retained' if job['logs']['available_original_log'] else '404 BlobNotFound at initial query; still queued'
    table_rows.append(f"| [{job['id']}]({job['html_url']}) | {job['name']} | {state} | {runner} | {log_state} |")
markdown = f'''# Final VERIFY source CI readback

Exact head: `{HEAD}`. All four runs and all currently listed jobs bind to
attempt **1**. Last job-state read: **{max(observations)}**.

**New head macOS: 314 unique tests passed. Remaining listed CI is pending.**

The successful [macOS original job](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43169903848/job/131020438882)
ran 314 unique method IDs in 16.392 seconds, all `ok`. The original log binds its
checkout to the exact head above, records the actual entropy-draw process death
with returncode -9, and contains `CONSISTENT_COMPLETE_RECORDS`.

Original UTF-8 log: `{log_path.name}`; **110040 bytes**;
SHA256 **`{sha256(log_bytes)}`**.

| Job | Name | Current status | Runner ID | Log state |
| --- | --- | --- | --- | --- |
''' + '\n'.join(table_rows) + '''

The four run-level objects still report queued. This aggregate value must not
be interpreted as zero completed jobs: the exact macOS job is already success.
All eight other currently listed jobs remain queued with runner_id=0, empty
runner_name and no steps. Their infrastructure cause is not established.
All current pages have matching total_count; this is the currently materialized
job set, not a frozen roster of every downstream job the workflows may later
create. No completed failure is present in this readback.

## Process-death control portability

The exact remote test source is retained as `test_check_opportunities.remote.py`,
Git blob `f2136bbd5342a56afd68046315611440937db480`. It matches the final local
postimage byte for byte. The control waits for the child's actual draw marker,
calls `process.kill()`, waits, and asserts a nonzero return code. It does not
require returncode -9 or directly invoke `signal.SIGKILL`.

The [official subprocess API](https://docs.python.org/3/library/subprocess.html#subprocess.Popen.kill)
defines `kill()` as SIGKILL on POSIX and as the Windows terminate operation on
Windows. The negative signal-number return convention is POSIX-only. The
existing assertion therefore does not contain that cross-platform mistake.
No definite portability defect was found during this read-only source review.
macOS execution is now directly observed; Windows execution is still pending
and has not been qualified by this review.

## Preservation and boundaries

Initial and final raw API JSON responses, query envelopes, each initial 404 log
response, the full terminal macOS log, exact remote test source and source API
response are retained. Initial 404 means the original log blob was unavailable
at that query time; it is not a failing test receipt. The later successful macOS
log is separately preserved rather than overwriting that earlier observation.

No rerun, cancel, source edit, local test run or wait for queued gates occurred.
This result applies only to the named source/attempt/job and does not replace
pending platforms or required gates. It does not establish ordinary-business
independent truth or the net benefit of paid checks.
'''
(ROOT / 'SUMMARY.md').write_text(markdown)

files = sorted(path for path in ROOT.rglob('*') if path.is_file()
               and path.name not in ('MANIFEST.json', 'ARCHIVE.json')
               and path.suffix != '.zip' and '__pycache__' not in path.parts)
manifest = [{'path':str(path.relative_to(ROOT)), 'bytes':path.stat().st_size,
             'sha256':sha256(path.read_bytes())} for path in files]
(ROOT / 'MANIFEST.json').write_text(json.dumps({'files':manifest}, indent=2) + '\n')
files.append(ROOT / 'MANIFEST.json')
archive = ROOT / 'NEW_HEAD_CI_ORIGINALS.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(files):
        info = zipfile.ZipInfo(str(path.relative_to(ROOT)), date_time=(2026,11,12,0,0,0))
        output.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
assert archive.stat().st_size < 512000
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    for row in manifest:
        assert sha256(saved.read(row['path'])) == row['sha256']
record = dict(path=str(archive), bytes=archive.stat().st_size,
              sha256=sha256(archive.read_bytes()), entries=len(files))
(ROOT / 'ARCHIVE.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(archive=record, unique_tests=len(set(test_ids)),
                     log_sha256=sha256(log_bytes),
                     status_counts=summary['currently_listed_job_status_counts'],
                     latest_jobs_read_at=max(observations)), indent=2))
