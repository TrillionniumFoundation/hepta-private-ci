# Final VERIFY source CI readback

Exact head: `58035205857c154530ba249cb3494cfe739e1875`. All four runs and all currently listed jobs bind to
attempt **1**. Last job-state read: **2026-11-12T06:47:31.824Z**.

**New head macOS: 314 unique tests passed. Remaining listed CI is pending.**

The successful [macOS original job](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43169903848/job/131020438882)
ran 314 unique method IDs in 16.392 seconds, all `ok`. The original log binds its
checkout to the exact head above, records the actual entropy-draw process death
with returncode -9, and contains `CONSISTENT_COMPLETE_RECORDS`.

Original UTF-8 log: `logs-131020438882-final.log`; **110040 bytes**;
SHA256 **`ea17eef47d534c115325132211289fee1529f0b48d015eacebaa529b253cc5a8`**.

| Job | Name | Current status | Runner ID | Log state |
| --- | --- | --- | --- | --- |
| [131020438448](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43169903848/job/131020438448) | VERIFY-1 (windows-2025) | queued | 0 (unassigned) | 404 BlobNotFound at initial query; still queued |
| [131020438702](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43169903848/job/131020438702) | VERIFY-1 (ubuntu-24.04) | queued | 0 (unassigned) | 404 BlobNotFound at initial query; still queued |
| [131020438882](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43169903848/job/131020438882) | VERIFY-1 (macos-15) | completed / success | 1000121483 | Full original log retained |
| [131020439102](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43169903915/job/131020439102) | Select blocking CI scope | queued | 0 (unassigned) | 404 BlobNotFound at initial query; still queued |
| [131020439450](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43169903915/job/131020439450) | Codespell / Check for spelling errors | queued | 0 (unassigned) | 404 BlobNotFound at initial query; still queued |
| [131020439471](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43169903915/job/131020439471) | Blob size policy / Blob size policy | queued | 0 (unassigned) | 404 BlobNotFound at initial query; still queued |
| [131020442665](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43169904934/job/131020442665) | Architecture convergence (source-head) | queued | 0 (unassigned) | 404 BlobNotFound at initial query; still queued |
| [131020442915](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43169904934/job/131020442915) | Architecture convergence (base-merge) | queued | 0 (unassigned) | 404 BlobNotFound at initial query; still queued |
| [131020439208](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/43169903898/job/131020439208) | metadata | queued | 0 (unassigned) | 404 BlobNotFound at initial query; still queued |

The four run-level objects still report queued. This aggregate value must not
be interpreted as zero completed jobs: the exact macOS job is already success.
All eight other currently listed jobs remain queued with runner_id=0, empty
runner_name and no steps. Their infrastructure cause is not established.
All current pages have matching total_count; this is the currently materialized
job set, not a frozen roster of every downstream job the workflows may later
create. No completed failure is present in this readback.

## Process-death control portability

The exact remote test source is retained as `test_check_opportunities.remote.py`,
Git blob `f2136bbd5342a56afd68046315611440937db480`. It matches the final local
postimage byte for byte. The control waits for the child's actual draw marker,
calls `process.kill()`, waits, and asserts a nonzero return code. It does not
require returncode -9 or directly invoke `signal.SIGKILL`.

The [official subprocess API](https://docs.python.org/3/library/subprocess.html#subprocess.Popen.kill)
defines `kill()` as SIGKILL on POSIX and as the Windows terminate operation on
Windows. The negative signal-number return convention is POSIX-only. The
existing assertion therefore does not contain that cross-platform mistake.
No definite portability defect was found during this read-only source review.
macOS execution is now directly observed; Windows execution is still pending
and has not been qualified by this review.

## Preservation and boundaries

Initial and final raw API JSON responses, query envelopes, each initial 404 log
response, the full terminal macOS log, exact remote test source and source API
response are retained. Initial 404 means the original log blob was unavailable
at that query time; it is not a failing test receipt. The later successful macOS
log is separately preserved rather than overwriting that earlier observation.

No rerun, cancel, source edit, local test run or wait for queued gates occurred.
This result applies only to the named source/attempt/job and does not replace
pending platforms or required gates. It does not establish ordinary-business
independent truth or the net benefit of paid checks.
