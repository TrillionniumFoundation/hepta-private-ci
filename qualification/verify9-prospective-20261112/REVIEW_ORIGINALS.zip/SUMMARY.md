# VERIFY independent adversarial review

This archive contains two reproduced software counterexamples, their repaired
behavior, the exact evaluated source bytes, and the probe programs. All inputs
are controlled engineering fixtures. No ordinary business task, paid checker,
independent terminal adjudicator, authenticated randomness, or physical cost
measurement was created by these probes. Scientific admission remains HOLD and
production authority remains NONE.

## Reproduced findings

| Finding | Before | After | Authoritative archived outputs |
| --- | --- | --- | --- |
| A caller can mutate a frozen cost receipt after construction | Setting CPU to -1000 is accepted; one second of wall charge gives declared utility -999, and the declared roster is reported complete | Original constructors revalidate and detach bounded typed input; the same mutation raises `ValueError: invalid process_cpu_seconds` | `negative_cost_before_guard_archived.json`, `negative_cost_after_guard_archived.json` |
| An optional operation remains pending while an external cost receipt claims completion | One original start, zero original completions, and a caller-supplied completed/zero optional receipt yield declared mean net utility -2.3333333333333335 | Pending original optional operations keep declared mean net utility null; the pending operation remains visible | `pending_operation_before_guard_archived.json`, `pending_operation_after_guard_archived.json` |

The second fixture has three planned trajectories and four distinct original
SQLite policy journals. All terminal dispositions are reject and all fixture
labels are clean. The learned policy has a pending `learned/0` optional operation.
Its baseline declared cost is one unit and each reject has loss two. The numeric
value in the old evaluator is therefore a declared fixture calculation, not an
empirical estimate of check value. Both versions still report HOLD and incomplete
physical cost coverage.

## Exact evaluated sources

| Source | SHA256 |
| --- | --- |
| Cost ledger before revalidation | `4b4a7d275afa65a6913a587437263849d960886b64c4b1f0236f9fb1523c2b01` |
| Cost ledger after revalidation | `e605de8d60c214c36631dc5abb89f00f95b0b3fbd441af6456e5b267651f114f` |
| Policy evaluator before pending guard, already after start-to-cost binding | `e19dd231aee1298600956433a77a482012c8339adc64f1cc21f4b7667b272a9a` |
| Policy evaluator after pending guard and helper extraction | `906ccf4cde35c643aeabbfc91523af0d993ee4fa224c70eb6548844ea06192bc` |

Each authoritative output has an adjacent `.cost_ledger.py` or
`.policy_evaluation.py` file containing the exact bytes compiled for that run.
The current dependency context is frozen in `fixture_context`, with its own
source manifest. The original cost module and its original contracts are also
available under `before_cost_context`. `MANIFEST.json` binds every archived file.

## Other reviewed boundaries

The started-operation versus `not_run` cost contradiction was independently
executed and refused. Its historical output is `cost_start_probe.before.json`;
despite that old filename, this is a **post-fix refusal**, not an executed
pre-fix counterexample. The retained source named
`policy_evaluation.before_cost_binding.py` is likewise already after the
start-to-cost binding repair, but before the pending-operation guard. The
authoritative source table above describes its actual state.

The initial file named `pending_operation_pre_fix.json` also records a post-fix
null result. That name was assigned before discovering that the sibling agent
had already applied the guard. Historical output names and contents are retained
unchanged for auditability. They must not be used to invent a before/after
sequence. The authoritative `_archived` pairs avoid this ambiguity.

An initial repaired evaluator was observed at SHA256
`abd4deaa4d5af2cae06638bfb7b4bd073f74f631f6134069895c2ac9073ef8dd`.
That intermediate source was not separately retained before helper extraction.
Its raw output remains historical evidence, while the later frozen-source
replay supplies the fully reproducible repaired result.

Static review covered the opportunity journal's one-use durable intent before
the random draw, original prediction/choice ordering, complete frozen target and
roster equality, same checker-version binding, free snapshot/evidence equality,
fixed missing-data denominators, and final ledger/consumption root checks. The
intent survives an interrupted draw transaction and prevents a public retry
from silently drawing again. The sibling agent owns the separate crash-process
execution evidence; this archive does not claim to have rerun that experiment.

A narrow hardlink alias issue was reported: source and consumer paths can name
the same physical SQLite file while comparing unequal as paths, producing a
second write-lock wait. It was reported as an availability issue, not a path to
scientific or production authority. No expanded audit or repository edit was
performed by this reviewer.

## Reproduction

After extracting, set `AUDIT_DIR` to the extraction directory. Output paths may
be changed to another writable scratch location.

```bash
python -B "$AUDIT_DIR/negative_cost_probe.py" "$AUDIT_DIR/before_cost_context" "$AUDIT_DIR/replay-negative-before.json"
python -B "$AUDIT_DIR/negative_cost_probe.py" "$AUDIT_DIR/fixture_context" "$AUDIT_DIR/replay-negative-after.json"
python -B "$AUDIT_DIR/pending_operation_probe.py" "$AUDIT_DIR/pending_operation_before_guard_archived.policy_evaluation.py" "$AUDIT_DIR/replay-pending-before.json" "$AUDIT_DIR/fixture_context"
python -B "$AUDIT_DIR/pending_operation_probe.py" "$AUDIT_DIR/pending_operation_after_guard_archived.policy_evaluation.py" "$AUDIT_DIR/replay-pending-after.json" "$AUDIT_DIR/fixture_context"
```

## Limits

These local controls do not replace exact-head required CI receipts, do not add
independent samples, and do not establish the overall net benefit of buying
checks. Whole-suite testing and publication belong to the parent workstream.
Ordinary Notes/Calculator predecision and original terminal receipt seams were
identified separately, but no existing composed VERIFY export plus independent
business-truth owner was established. Native scope was not expanded here.
