"""Controlled original-journal inconsistency probe; no business task or truth."""
from dataclasses import asdict
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
from unittest.mock import patch

ROOT = Path('/workspace/scratch/456fa5e702a7/verify-work')
OUT = Path('/workspace/scratch/456fa5e702a7/review-probes')
sys.path.insert(0, str(ROOT))
from experiments.verification_cell_verify1.test_treatment import TreatmentTests
from experiments.verification_cell_verify1.prospective import ShadowJournal, FrozenAttempt
from experiments.verification_cell_verify1.treatment import TreatmentJournal
from experiments.verification_cell_verify1.shadow_risk import TerminalLabel
from experiments.verification_cell_verify1.check_opportunities import CheckOpportunityJournal
from experiments.verification_cell_verify1.cost_ledger import CostItem, CostReceipt, METRICS
from experiments.verification_cell_verify1.contracts import digest

module_file = OUT / 'policy_evaluation.before_cost_binding.py'
spec = importlib.util.spec_from_file_location(
    'experiments.verification_cell_verify1.review_old_policy_evaluation', module_file)
metrics = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metrics)
test = TreatmentTests()
test.setUp()
try:
    second = ShadowJournal.create(
        test.path.with_name('second.sqlite'), target=test.target,
        roster=tuple(FrozenAttempt(p.snapshot.trajectory_id,'heldout',p.snapshot.subject_sha256)
                     for p in test.predictions), frontiers=(0,2),
        risk_model_sha256=digest('risk'), checker_model_sha256=test.effects.model_sha256,
        scheduler_sha256=digest('second scheduler'), producer_id='producer',
        evaluator_id='separate-reader', evaluator_version_sha256=digest('evaluator'))
    other = TreatmentJournal.create(second, test.checkers)
    policies = {'source':test.journal,'other':other}
    costs = {name:[CostItem(name+'-op','0','checker',name+'-resource','clock')]
             for name in policies}
    receipts = {name:[CostReceipt(costs[name][0], 'not_run',0,0,0,0,0,0,digest(name),())]
                for name in policies}
    losses = {name:{'correct':0,'error':1}
              for name in ('accept','reject','interrupted','unknown')}
    frozen = metrics.freeze_evaluation_spec(costs,losses=losses,
        rates={name:1 for name in METRICS},utility_unit='fixture-unit')
    opportunity = CheckOpportunityJournal.create(test.journal,
        policies={name:j.shadow.manifest_sha256 for name,j in policies.items()},
        frontier=0,checker_id='readback',offer_numerator=1,offer_denominator=2,
        free_view_schema_sha256=digest('free-schema'),mandatory_contract_sha256=digest('gates'),
        evaluation_spec_sha256=digest(frozen))
    for prediction in test.predictions:
        test.shadow.record(prediction)
        second.record(prediction)
        with patch('experiments.verification_cell_verify1.check_opportunities.secrets.randbelow',return_value=0):
            opportunity.reserve(prediction.snapshot.trajectory_id,digest('shared-free'),eligible=True,
                                eligibility_evidence_sha256=digest('eligible'))
        opportunity.bind_policy(other,prediction.snapshot.trajectory_id,free_evidence_sha256=digest('shared-free'))
    choice = test.choose()
    opportunity.start_optional(test.journal,choice['record_sha256'],'source-op')
    test.journal.complete('source-op','pass',digest('original-checker-reply'),
                          {'wall_seconds':0.1,'cpu_seconds':0.01,'energy_joules':0})
    for name,journal in policies.items():
        for prediction in test.predictions:
            s=prediction.snapshot
            journal.record_disposition(s.trajectory_id,'accept',hard_checks_complete=True,
                                       gate_evidence_sha256=digest('fixture-gates'))
            journal.shadow.finish(s.trajectory_id,'accept')
            journal.shadow.label(TerminalLabel(s.trajectory_id,s.source_group,s.subject_sha256,
                s.target,'accept',False,3,digest(['truth',s.trajectory_id]),None),
                evaluator_id='separate-reader',authenticate=lambda *args:True)
    try:
        report=metrics.evaluate_policy_journals(opportunity,policies,specification=frozen,
                    cost_rosters=costs,cost_receipts=receipts)
        result={'outcome':'ACCEPTED_CONTRADICTORY_COSTS',
                'source_start': 'source-op',
                'original_completion_costs':{'wall_seconds':0.1,'cpu_seconds':0.01,'energy_joules':0},
                'declared_cost_status':'not_run',
                'reported_cost':report['policies']['source']['cost'],
                'reported_declared_mean_net_utility':report['policies']['source']['declared_mean_net_utility']}
    except Exception as error:
        result={'outcome':'REFUSED','error':type(error).__name__,'message':str(error)}
    result['scope']='controlled synthetic fixture; no real checker execution or business qualification'
    result['evaluated_module_sha256']=hashlib.sha256(module_file.read_bytes()).hexdigest()
    print(json.dumps(result,indent=2))
finally:
    test.doCleanups()
