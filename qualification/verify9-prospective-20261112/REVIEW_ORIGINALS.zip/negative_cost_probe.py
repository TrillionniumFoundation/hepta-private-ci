"""Frozen-object alias regression probe, using only declared synthetic costs."""

from pathlib import Path
import hashlib
import json
import sys
import types

root = Path(sys.argv[1])
sys.path.insert(0, str(root))
module_path = root / 'experiments/verification_cell_verify1/cost_ledger.py'
source = module_path.read_bytes()
Path(sys.argv[2]).with_suffix('.cost_ledger.py').write_bytes(source)
cost_ledger = types.ModuleType('experiments.verification_cell_verify1.audit_negative_cost')
cost_ledger.__file__ = str(module_path)
cost_ledger.__package__ = 'experiments.verification_cell_verify1'
sys.modules[cost_ledger.__name__] = cost_ledger
exec(compile(source, str(module_path), 'exec'), cost_ledger.__dict__)

item = cost_ledger.CostItem('op-probe', 'attempt', 'checker', 'resource', 'clock')
receipt = cost_ledger.CostReceipt(item, 'completed', 0, 10**9,
    1, 1, 0, 0, '1' * 64, ())
object.__setattr__(receipt, 'process_cpu_seconds', -1000.0)
result = dict(scope='controlled cost object corruption, no measured physical business costs',
    module_sha256=hashlib.sha256(source).hexdigest(),
    module_path=cost_ledger.__file__)
try:
    summary = cost_ledger.summarize_costs([item], [receipt],
        {metric: 1 for metric in cost_ledger.METRICS})
    result.update(outcome='ACCEPTED_MUTATED_NEGATIVE_COST',
        totals=summary['totals'],
        declared_receipt_utility=summary['declared_receipt_utility'],
        declared_roster_complete=summary['declared_roster_complete'])
except Exception as error:
    result.update(outcome='REFUSED', error=type(error).__name__, message=str(error))
rendered = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
Path(sys.argv[2]).write_text(rendered)
print(rendered)
