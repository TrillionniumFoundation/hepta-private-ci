"""Controlled SQLite lifecycle probe; no real business truth or execution."""

from pathlib import Path
import hashlib
import json
import sys
import types

ROOT = Path(sys.argv[3]) if len(sys.argv) > 3 else Path('/workspace/scratch/456fa5e702a7/verify-work')
sys.path.insert(0, str(ROOT))
from experiments.verification_cell_verify1.test_policy_evaluation import PolicyEvaluationTests
from experiments.verification_cell_verify1.shadow_risk import TerminalLabel
from experiments.verification_cell_verify1.cost_ledger import CostReceipt
from experiments.verification_cell_verify1.contracts import digest

module_path = Path(sys.argv[1])
source = module_path.read_bytes()
Path(sys.argv[2]).with_suffix('.policy_evaluation.py').write_bytes(source)
module = types.ModuleType('experiments.verification_cell_verify1.audit_pending_metrics')
module.__file__ = str(module_path)
module.__package__ = 'experiments.verification_cell_verify1'
exec(compile(source, str(module_path), 'exec'), module.__dict__)
case = PolicyEvaluationTests()
case.setUp()
try:
    case.observe()
    case.start_check()
    item = case.items['learned'][1]
    case.receipts['learned'][1] = CostReceipt(
        item, 'completed', 10**9, 10**9, 0, 0, 0, 0,
        digest('claimed-completed-with-no-original-completion'), ())
    for journal in case.policies.values():
        for i in range(3):
            journal.record_disposition(str(i), 'reject', hard_checks_complete=True,
                gate_evidence_sha256=digest(['original-gate', i]))
            journal.shadow.finish(str(i), 'reject')
            journal.shadow.label(TerminalLabel(
                str(i), 'one-fixture-source', digest(i), case.target, 'reject',
                False, 3, digest(['fixture-truth', i]), None),
                evaluator_id='fixture-reader', authenticate=lambda *args: True)
    report = module.evaluate_policy_journals(
        case.opportunities, case.policies, specification=case.spec,
        cost_rosters=case.items, cost_receipts=case.receipts)
    row = report['policies']['learned']
    result = dict(
        scope='controlled SQLite engineering fixture, not business evidence',
        case='pending original optional start with caller-declared completed zero-cost receipt',
        actual_optional_starts=row['actual_optional_starts'],
        actual_optional_completions=row['actual_optional_completions'],
        pending_optional_operation_ids=row['pending_optional_operation_ids'],
        declared_mean_net_utility=row['declared_mean_net_utility'],
        original_cost_status='completed', cost_totals=row['cost']['totals'],
        full_physical_cost_complete=report['full_physical_cost_complete'],
        scientific_admission=report['scientific_admission'],
        evaluated_module_sha256=hashlib.sha256(source).hexdigest(),
        evaluated_module_path=str(module_path))
    rendered = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    Path(sys.argv[2]).write_text(rendered)
    print(rendered)
finally:
    case.doCleanups()
