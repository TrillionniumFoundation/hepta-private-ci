# PRED-1 source and path map

This input-only bundle contains 48 original training/development metadata records, the original registered configuration, and the 11 original Python source files bound by the independent confirmation design. `run.py` is one of those 11 files and is stored once. No confirmation observations, confirmation results, checkpoint weights, recovery outputs, or new diagnostic outputs are included.

Three immutable provenance files are also included as inputs to the existing frozen protocol: the original `FREEZE.json`, its independent-study configuration, and the exact diagnostic JSON it cited. The frozen diagnostic is historical development evidence, not new confirmation evidence.

## Absolute paths to bundle-relative paths

Each directory mapping preserves the remaining relative filename. All package paths below are relative to the directory into which the archive is extracted.

| Original location | Bundle location | Scope |
|---|---|---|
| `/workspace/scratch/bdb11c6f9900/pred1_campaign_001/*-training.json` | `training/*-training.json` | Exactly 48 files selected by the original registered seed/variant grid |
| `/workspace/scratch/bdb11c6f9900/pred1_candidate/qualification/pred1/registered_config.json` | `config/original-registered-config.json` | Use this original 8-training-seed configuration for the development diagnostic |
| `/workspace/scratch/bdb11c6f9900/pred1_campaign_001/source/` | `source/hepta_pred1/` | All 11 exact source files bound by `FREEZE.source.files`; includes `run.py` |
| `/workspace/scratch/08b6dd5f2d10/negative-review/independent-confirmation-002/FREEZE.json` | `provenance/independent-confirmation-002/FREEZE.json` | Exact unchanged frozen bytes |
| `/workspace/scratch/08b6dd5f2d10/negative-review/independent-confirmation-002/registered_config.json` | `provenance/independent-confirmation-002/registered_config.json` | The separate prospective 16-new-seed study; do not use this to audit the original 48 fits |
| `/workspace/scratch/08b6dd5f2d10/negative-review/train-dev-diagnostic-002/DIAGNOSTIC.json` | `provenance/train-dev-diagnostic-002/DIAGNOSTIC.json` | Exact immutable diagnostic basis named in `FREEZE.diagnostic_basis` |

The relative `FREEZE.config.path` already resolves alongside the unchanged `FREEZE.json` in `provenance/independent-confirmation-002/`. The original absolute source and diagnostic-basis fields remain unchanged; this map resolves them without rewriting the frozen document. The frozen diagnostic's absolute input-manifest paths use the same training/config/source mappings above.

## Identities and scientific scope

- The unchanged `FREEZE.json` SHA-256 is `19e6d61565d7d8fadf695a9a5814819197ac98835c80ad19d162e61db846b724`.
- Its original diagnostic-basis SHA-256 is `3379e8295293f4967d05a1d19dd8b52dde88885e48bdc86c3cd710415b028b9b`.
- The frozen status remains `DESIGN_FROZEN_NOT_EXECUTED`; the original PRED-1 HOLD remains unchanged.
- `source/hepta_pred1/` belongs only to the original archived PRED-1 experiment. It is neither the release head nor the tested source of the integrated candidate. Packaging or replaying a diagnostic does not qualify integrated training, owner adoption, or real-task benefits.
- `diagnose_training.py` is supplied separately as the current research tool. Replaying it reads original development evidence; it does not run the archived experiment.
- Relocation changes absolute path fields and thus the diagnostic input-manifest hash. Formatting or fixing the current tool changes its implementation hash. Those changes must be recorded; do not rewrite the historical diagnostic or its freeze. Compare scientific fields and input role/SHA/size tuples after normalizing paths.

`MANIFEST.json` records every payload's relative name, original path, role, size and SHA-256. `MANIFEST.sha256` verifies all payloads and `MANIFEST.json`; the outer archive checksum also covers the checksum file itself. All archive members are ordinary relative-path files, with no links.
