"""Create one draft PR after exact source/base readback; never retry its creation."""

import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from urllib.parse import urlencode

ROOT = Path('/Users/qianqi/work/cell-integration-20261108-08b6-publication/draft-pr-001')
GH = '/opt/homebrew/bin/gh'
REPO = 'TrillionniumFoundation/hepta-private-ci'
BRANCH = 'engineering/cell-integrated-20261108-08b6'
BASE = 'fix/codex-v13-same-model-next-task-20261106'
C = 'b839558b26c2e5b667055ca4af4ad749ae41c043'
TREE = 'e411d25b47c166f35783a27054adb6a3f6682594'
BASE_SHA = '6ddfca2406e4d01416cd2f7ab1655a0dc16f8da5'
TITLE = 'Freeze integrated Cell candidate and preserve independent PRED-1 HOLD'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def save(path, raw):
    if not isinstance(raw, bytes):
        raw = (json.dumps(raw, ensure_ascii=False, indent=2) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    directory = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def run_command(name, arguments):
    directory = ROOT / name
    directory.mkdir(mode=0o700, exist_ok=False)
    save(directory / 'intent.json', {'argv': arguments, 'automatic_retry': False})
    env = dict(os.environ)
    env.pop('GH_DEBUG', None)
    env.pop('GH_HOST', None)
    start = time.monotonic()
    result = None
    try:
        with (directory / 'stdout').open('xb') as out, (directory / 'stderr').open('xb') as err:
            try:
                result = subprocess.run(arguments, stdout=out, stderr=err, env=env,
                                        timeout=120, check=False)
            finally:
                for stream in (out, err):
                    stream.flush()
                    os.fsync(stream.fileno())
    finally:
        save(directory / 'result.json', {
            'exit_code': result.returncode if result is not None else None,
            'state': 'RETURNED' if result is not None else 'UNKNOWN',
            'wall_seconds': time.monotonic() - start,
        })
    return result.returncode, (directory / 'stdout').read_bytes()


def api(name, endpoint):
    code, raw = run_command(name, [GH, 'api', '--hostname', 'github.com', endpoint])
    require(code == 0, name + ' read failed; no implicit retry')
    return json.loads(raw)


def main():
    os.umask(0o077)
    ROOT.mkdir(mode=0o700, exist_ok=False)
    payload = json.load(sys.stdin)
    body = base64.b64decode(payload['body'], validate=True)
    require(hashlib.sha256(body).hexdigest() == payload['sha256'], 'PR body transfer differs')
    save(ROOT / 'BODY.zh-CN.md', body)
    user = api('01-user', 'user')
    require(user['login'] == 'ProfHepta', 'Unexpected GitHub identity')
    source = api('02-source-ref', f'repos/{REPO}/git/ref/heads/{BRANCH}')
    base = api('03-base-ref', f'repos/{REPO}/git/ref/heads/{BASE}')
    commit = api('04-source-commit', f'repos/{REPO}/git/commits/{C}')
    require(source['object']['sha'] == C and base['object']['sha'] == BASE_SHA,
            'Source or base branch moved')
    require(commit['tree']['sha'] == TREE, 'Source tree differs')
    query = urlencode({'head': 'TrillionniumFoundation:' + BRANCH,
                       'base': BASE, 'state': 'all', 'per_page': 100})
    endpoint = f'repos/{REPO}/pulls?{query}'
    existing = api('05-pr-preflight', endpoint)
    require(isinstance(existing, list) and not existing, 'Existing matching PR; inspect instead of creating')
    save(ROOT / 'create-intent.json', {
        'repository': REPO, 'head_ref': BRANCH, 'head_sha': C,
        'base_ref': BASE, 'base_sha': BASE_SHA, 'draft': True,
        'title': TITLE, 'body_sha256': payload['sha256'],
        'maximum_creation_calls': 1,
    })
    code, raw = run_command('06-create-once', [GH, 'pr', 'create', '--repo', 'github.com/' + REPO,
        '--head', BRANCH, '--base', BASE, '--draft', '--title', TITLE,
        '--body-file', str(ROOT / 'BODY.zh-CN.md')])
    found = api('07-pr-readback', endpoint)
    require(isinstance(found, list) and len(found) == 1, 'PR creation remains unresolved; never create again')
    pr = found[0]
    require(pr['head']['sha'] == C and pr['base']['sha'] == BASE_SHA
            and pr['head']['ref'] == BRANCH and pr['base']['ref'] == BASE
            and pr['draft'] is True and pr['state'] == 'open', 'PR readback identity differs')
    require(pr['title'] == TITLE and pr['body'] == body.decode(), 'PR readback text differs')
    comparison = api('08-comparison', f'repos/{REPO}/compare/{BASE_SHA}...{C}')
    result = {'state': 'DRAFT_PR_READBACK_VERIFIED', 'number': pr['number'],
        'url': pr['html_url'], 'head': C, 'tree': TREE, 'base': BASE_SHA,
        'draft': True, 'create_exit_code': code, 'body_sha256': payload['sha256'],
        'comparison': {'status': comparison['status'], 'ahead_by': comparison['ahead_by'],
            'behind_by': comparison['behind_by'], 'total_commits': comparison['total_commits'],
            'merge_base': comparison['merge_base_commit']['sha'],
            'returned_changed_files': len(comparison.get('files', []))},
        'ci_qualified': False, 'production_qualified': False}
    save(ROOT / 'RESULT.json', result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
