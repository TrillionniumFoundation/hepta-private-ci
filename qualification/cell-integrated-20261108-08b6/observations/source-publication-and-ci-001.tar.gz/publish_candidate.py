"""Publish the exact locally tested Git objects through the original Mac gh."""

import argparse
import base64
from datetime import datetime, timedelta, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import time

REPO = "TrillionniumFoundation/hepta-private-ci"
BRANCH = "engineering/cell-integrated-20261108-08b6"
BRANCHES = (BRANCH, "engineering/cell-integrated-20261108-08b6-evidence")
GH = "/opt/homebrew/bin/gh"
CAPSULE_LIMIT = 8 * 1024 * 1024


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sync_directory(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def private_directory(path, *, exist_ok=True):
    path.mkdir(mode=0o700, exist_ok=exist_ok)
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fchmod(descriptor, 0o700)
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    sync_directory(path.parent)


def private_file(path):
    descriptor = os.open(
        path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600
    )
    return os.fdopen(descriptor, "wb")


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def save(path, value):
    with private_file(path) as stream:
        stream.write(json_bytes(value))
        stream.flush()
        os.fsync(stream.fileno())
    sync_directory(path.parent)


def git_oid(kind, raw):
    return hashlib.sha1(
        kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw
    ).hexdigest()


def identity(value):
    name, tail = value.rsplit(" <", 1)
    email, stamp, offset = tail.rsplit("> ", 1)[0], *tail.rsplit("> ", 1)[1].split()
    sign = 1 if offset[0] == "+" else -1
    zone = timezone(sign * timedelta(hours=int(offset[1:3]), minutes=int(offset[3:5])))
    return {
        "name": name,
        "email": email,
        "date": datetime.fromtimestamp(int(stamp), zone).isoformat(timespec="seconds"),
    }


def commit_request(raw):
    header, message = raw.decode().split("\n\n", 1)
    fields, parents = {}, []
    for row in header.splitlines():
        key, value = row.split(" ", 1)
        if key == "parent":
            parents.append(value)
        elif key in ("tree", "author", "committer") and key not in fields:
            fields[key] = value
        else:
            raise ValueError("Cannot reproduce an extended/signed Git commit")
    require(set(fields) == {"tree", "author", "committer"}, "Incomplete commit headers")
    return {
        "tree": fields["tree"],
        "parents": parents,
        "message": message,
        "author": identity(fields["author"]),
        "committer": identity(fields["committer"]),
    }


class Publisher:
    def __init__(self, root):
        self.root = root
        self.calls = root / "calls"
        self.intents = root / "object-intents"
        private_directory(self.calls)
        private_directory(self.intents)
        self.count = max(
            (int(path.name) for path in self.calls.iterdir() if path.name.isdigit()),
            default=0,
        )

    def api(self, endpoint, body=None):
        self.count += 1
        directory = self.calls / f"{self.count:04d}"
        private_directory(directory, exist_ok=False)
        args = [GH, "api", "--hostname", "github.com", "--include", endpoint]
        if body is not None:
            save(directory / "request.json", body)
            args += ["--method", "POST", "--input", str(directory / "request.json")]
        save(
            directory / "intent.json",
            {
                "endpoint": endpoint,
                "method": "POST" if body is not None else "GET",
                "request_sha256": hashlib.sha256(json_bytes(body)).hexdigest()
                if body is not None
                else None,
            },
        )
        start = time.monotonic()
        env = dict(os.environ)
        env.pop("GH_DEBUG", None)
        process = None
        try:
            with (
                private_file(directory / "stdout.bin") as out,
                private_file(directory / "stderr.bin") as err,
            ):
                try:
                    process = subprocess.run(
                        args, stdout=out, stderr=err, timeout=40, check=False, env=env
                    )
                finally:
                    for stream in (out, err):
                        stream.flush()
                        os.fsync(stream.fileno())
                    sync_directory(directory)
            raw = (directory / "stdout.bin").read_bytes()
            header, payload = raw.replace(b"\r\n", b"\n").split(b"\n\n", 1)
            status = int(header.splitlines()[0].split()[1])
            parsed = json.loads(payload)
            require(isinstance(parsed, dict), "GitHub response must be a JSON object")
        except (OSError, subprocess.TimeoutExpired, ValueError, IndexError) as error:
            save(
                directory / "result.json",
                {
                    "state": "UNKNOWN",
                    "reason": type(error).__name__,
                    "exit_code": process.returncode if process is not None else None,
                    "wall_seconds": time.monotonic() - start,
                },
            )
            raise RuntimeError(
                f"GitHub request {self.count} remains UNKNOWN; original files retained"
            ) from error
        save(
            directory / "result.json",
            {
                "state": "HTTP_RESPONSE",
                "status": status,
                "exit_code": process.returncode,
                "wall_seconds": time.monotonic() - start,
            },
        )
        if status not in (200, 201, 404):
            raise RuntimeError(
                f"GitHub request {self.count} stopped with HTTP {status}"
            )
        if status in (200, 201) and process.returncode != 0:
            raise RuntimeError("Successful HTTP response has unsuccessful transport")
        return status, parsed

    def object(self, kind, sha, request):
        require(kind in ("blobs", "trees", "commits"), "Unsupported Git object kind")
        require(
            isinstance(sha, str)
            and len(sha) == 40
            and all(c in "0123456789abcdef" for c in sha),
            "Invalid Git object identity",
        )
        endpoint = f"repos/{REPO}/git/{kind}/{sha}"
        intent = self.intents / f"{kind}-{sha}.json"
        binding = {
            "endpoint": endpoint,
            "expected_sha": sha,
            "request_sha256": hashlib.sha256(json_bytes(request)).hexdigest(),
        }
        if intent.exists():
            require(
                json.loads(intent.read_text()) == binding,
                "Original object request binding differs",
            )
        status, result = self.api(endpoint)
        if status == 404:
            if intent.exists():
                raise RuntimeError(
                    f"Original {kind}/{sha} request remains uncertain; no second mutation"
                )
            save(intent, binding)
            status, result = self.api(f"repos/{REPO}/git/{kind}", request)
            require(
                status == 201 and result["sha"] == sha,
                "Created Git object identity differs",
            )
            status, result = self.api(endpoint)
        require(status == 200 and result["sha"] == sha, "Git object readback differs")
        return result


def run(capsule, root, branch=BRANCH):
    require(branch in BRANCHES, "Publication branch is not allowed")
    descriptor = os.open(capsule, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, "rb") as stream:
        require(
            stat.S_ISREG(os.fstat(stream.fileno()).st_mode),
            "Capsule must be a regular file",
        )
        packed = stream.read(CAPSULE_LIMIT + 1)
    require(len(packed) <= CAPSULE_LIMIT, "Compressed capsule exceeds 8 MiB")
    with gzip.GzipFile(fileobj=io.BytesIO(packed)) as stream:
        raw = stream.read(CAPSULE_LIMIT + 1)
    require(len(raw) <= CAPSULE_LIMIT, "Decompressed capsule exceeds 8 MiB")
    data = json.loads(raw)
    require(
        data["repository"] == REPO and data["branch"] == branch,
        "Capsule destination differs",
    )
    previous, tree = data["base_commit"], data["base_tree"]
    require(
        previous == "b040333617ed493944ae028bfb502c94d3b10991", "Base commit differs"
    )
    require(tree == "08e4b2962ad42dfdb544719b5837407bde31498a", "Base tree differs")
    decoded = {}
    for sha, text in data["blobs"].items():
        content = base64.b64decode(text, validate=True)
        require(git_oid("blob", content) == sha, "Capsule blob identity differs")
        decoded[sha] = content
    require(1 <= len(data["commits"]) <= 12, "Capsule requires 1 to 12 commits")
    for commit in data["commits"]:
        content = base64.b64decode(commit["raw"], validate=True)
        require(
            git_oid("commit", content) == commit["sha"],
            "Capsule commit identity differs",
        )
        request = commit_request(content)
        require(
            request["parents"] == [previous] and request["tree"] == commit["tree"],
            "Capsule commit chain differs",
        )
        for change in commit["changes"]:
            require(
                set(change) == {"path", "mode", "type", "sha"},
                "Unexpected tree change fields",
            )
            require(
                change["type"] == "blob"
                and change["mode"] in ("100644", "100755", "120000"),
                "Unsupported tree entry",
            )
            path = Path(change["path"])
            require(
                not path.is_absolute() and ".." not in path.parts,
                "Escaping tree path refused",
            )
            if change["sha"] is not None:
                require(
                    change["sha"] in decoded, "Tree references an absent capsule blob"
                )
        previous, tree = commit["sha"], commit["tree"]
    require(
        previous == data["head"] and tree == data["tree"],
        "Final capsule identity differs",
    )
    private_directory(root)
    binding = {
        "capsule_sha256": hashlib.sha256(packed).hexdigest(),
        "head": data["head"],
        "tree": data["tree"],
        "repository": REPO,
        "branch": branch,
    }
    frozen = root / "binding.json"
    if frozen.exists():
        require(
            json.loads(frozen.read_text()) == binding,
            "Original capsule binding differs",
        )
    else:
        save(frozen, binding)
    publisher = Publisher(root)
    status, viewer = publisher.api("user")
    require(
        status == 200 and viewer["login"] == "ProfHepta", "Unexpected GitHub identity"
    )
    status, repo = publisher.api(f"repos/{REPO}")
    require(
        status == 200
        and repo["full_name"] == REPO
        and repo["permissions"]["push"] is True,
        "Repository push authority differs",
    )
    status, base = publisher.api(f"repos/{REPO}/git/commits/{data['base_commit']}")
    require(
        status == 200 and base["tree"]["sha"] == data["base_tree"],
        "Published base identity differs",
    )
    ref_endpoint = f"repos/{REPO}/git/ref/heads/{branch}"
    status, ref = publisher.api(ref_endpoint)
    if status == 200:
        require(
            ref["object"]["sha"] == data["head"],
            "Existing branch differs; no overwrite",
        )
    elif (root / "ref-intent.json").exists():
        raise RuntimeError(
            "Original reference request remains uncertain; no second mutation"
        )
    else:
        for sha, content in decoded.items():
            value = publisher.object(
                "blobs",
                sha,
                {"encoding": "base64", "content": base64.b64encode(content).decode()},
            )
            require(
                base64.b64decode(value["content"]) == content,
                "Remote blob bytes differ",
            )
        previous_tree = data["base_tree"]
        for commit in data["commits"]:
            publisher.object(
                "trees",
                commit["tree"],
                {"base_tree": previous_tree, "tree": commit["changes"]},
            )
            publisher.object(
                "commits",
                commit["sha"],
                commit_request(base64.b64decode(commit["raw"])),
            )
            previous_tree = commit["tree"]
        status, ref = publisher.api(ref_endpoint)
        if status == 200:
            require(
                ref["object"]["sha"] == data["head"],
                "Concurrent branch differs; no overwrite",
            )
        else:
            request = {
                "query": "mutation($input:UpdateRefsInput!){updateRefs(input:$input){clientMutationId}}",
                "variables": {
                    "input": {
                        "repositoryId": repo["node_id"],
                        "clientMutationId": "hepta-integrated-08b6-"
                        + branch.rsplit("/", 1)[-1]
                        + "-"
                        + data["head"],
                        "refUpdates": [
                            {
                                "name": "refs/heads/" + branch,
                                "beforeOid": "0" * 40,
                                "afterOid": data["head"],
                                "force": False,
                            }
                        ],
                    }
                },
            }
            save(root / "ref-intent.json", request)
            status, result = publisher.api("graphql", request)
            require(
                status == 200 and not result.get("errors"),
                "Reference CAS did not succeed",
            )
    status, ref = publisher.api(ref_endpoint)
    require(
        status == 200 and ref["object"]["sha"] == data["head"],
        "Published branch readback differs",
    )
    status, commit = publisher.api(f"repos/{REPO}/git/commits/{data['head']}")
    require(
        status == 200 and commit["tree"]["sha"] == data["tree"],
        "Published tree readback differs",
    )
    result = {
        **binding,
        "repository": REPO,
        "branch": branch,
        "state": "PUBLISHED_EXACT_HEAD",
        "ci_qualified": False,
        "scientific_qualified": False,
        "calls": publisher.count,
    }
    save(root / f"published-{publisher.count:04d}.json", result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("capsule", type=Path)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--branch", choices=BRANCHES, default=BRANCH)
    args = parser.parse_args()
    run(args.capsule, args.root, args.branch)
