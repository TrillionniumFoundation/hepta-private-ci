"""Bounded read-only visibility retries around the frozen evidence publisher."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
from time import sleep
import types

HELPER_SHA256 = "aa29200938ad622518f361e378afbffeb3d5f1799fdb0bc0c2501e0f69ce29a6"
POLICY = {
    "immutable_404_extra_gets": 4,
    "empty_response_get_unknown_extra_gets": 2,
    "maximum_total_get_attempts_per_api_call": 7,
    "retry_interval_seconds": 1,
    "post_retries": 0,
    "ref_404_retries": 0,
    "original_run_object_and_ref_cas_unchanged": True,
}


def read_regular(path, limit=8 * 1024 * 1024):
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, "rb") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError("Journal/source input must be a regular file")
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ValueError("Journal/source input exceeds bounded read")
    return raw


def record(path):
    value = json.loads(read_regular(path))
    if not isinstance(value, dict):
        raise ValueError("Journal record must be an object")
    return value


def load_helper(path):
    raw = read_regular(path, 65536)
    if hashlib.sha256(raw).hexdigest() != HELPER_SHA256:
        raise ValueError("Frozen evidence publisher SHA-256 differs")
    helper = types.ModuleType("frozen_evidence_publisher")
    helper.__file__ = str(path)
    exec(compile(raw, str(path), "exec"), helper.__dict__)
    return helper


def creation_proof(helper, publisher, endpoint):
    match = re.fullmatch(
        rf"repos/{re.escape(helper.REPO)}/git/(blobs|trees|commits)/([0-9a-f]{{40}})",
        endpoint,
    )
    if match is None:
        return None
    kind, sha = match.groups()
    try:
        binding = record(publisher.intents / f"{kind}-{sha}.json")
        if (
            binding.get("endpoint") != endpoint
            or binding.get("expected_sha") != sha
            or not re.fullmatch("[0-9a-f]{64}", binding.get("request_sha256", ""))
        ):
            return None
    except (OSError, ValueError, TypeError):
        return None
    calls = sorted(
        (p for p in publisher.calls.iterdir() if p.name.isdigit()),
        key=lambda p: int(p.name),
        reverse=True,
    )
    for directory in calls:
        try:
            intent = record(directory / "intent.json")
            if intent != {
                "endpoint": endpoint.rsplit("/", 1)[0],
                "method": "POST",
                "request_sha256": binding["request_sha256"],
            }:
                continue
            result = record(directory / "result.json")
            if (
                result.get("state") != "HTTP_RESPONSE"
                or result.get("status") != 201
                or result.get("exit_code") != 0
            ):
                continue
            request = read_regular(
                directory / "request.json", helper.EVIDENCE_CAPSULE_LIMIT
            )
            if hashlib.sha256(request).hexdigest() != binding["request_sha256"]:
                continue
            raw = read_regular(directory / "stdout.bin")
            header, body = raw.replace(b"\r\n", b"\n").split(b"\n\n", 1)
            if not re.fullmatch(rb"HTTP/[0-9.]+ 201(?: .*)?", header.splitlines()[0]):
                continue
            response = json.loads(body)
            if isinstance(response, dict) and response.get("sha") == sha:
                return {"post_call": int(directory.name), **binding}
        except (OSError, ValueError, TypeError, IndexError):
            continue
    return None


def empty_get_unknown(publisher, endpoint, previous_count):
    if publisher.count != previous_count + 1:
        return False
    directory = publisher.calls / f"{publisher.count:04d}"
    try:
        return (
            record(directory / "intent.json")
            == {"endpoint": endpoint, "method": "GET", "request_sha256": None}
            and record(directory / "result.json").get("state") == "UNKNOWN"
            and read_regular(directory / "stdout.bin") == b""
        )
    except (OSError, ValueError):
        return False


def install_readback(helper, events):
    original_api = helper.Publisher.api

    def api(self, endpoint, body=None):
        if body is not None:
            return original_api(self, endpoint, body)
        misses = unknowns = 0
        while True:
            previous_count = self.count
            try:
                status, response = original_api(self, endpoint)
            except RuntimeError:
                if unknowns >= 2 or not empty_get_unknown(
                    self, endpoint, previous_count
                ):
                    raise
                unknowns += 1
                reason, proof = "GET_UNKNOWN_WITH_EMPTY_RESPONSE", None
            else:
                if status != 404 or misses >= 4:
                    return status, response
                proof = creation_proof(helper, self, endpoint)
                if proof is None:
                    return status, response
                misses += 1
                reason = "IMMUTABLE_404_AFTER_BOUND_HTTP_201"
            helper.save(
                events / f"retry-after-{self.count:04d}.json",
                {
                    "after_call": self.count,
                    "next_method": "GET",
                    "endpoint": endpoint,
                    "reason": reason,
                    "creation_proof": proof,
                    "immutable_404_retries_used": misses,
                    "transport_unknown_retries_used": unknowns,
                },
            )
            sleep(1)

    helper.Publisher.api = api


def main():
    here = Path(__file__).absolute()
    helper = load_helper(here.with_name("publish_evidence_candidate.py"))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capsule", type=Path)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--branch", choices=helper.BRANCHES, default=helper.BRANCH)
    args = parser.parse_args()
    helper.private_directory(args.root)
    runs = args.root / "readback-wrapper-runs"
    helper.private_directory(runs)
    number = 1 + max(
        (int(p.name) for p in runs.iterdir() if p.name.isdigit()), default=0
    )
    events = runs / f"{number:04d}"
    helper.private_directory(events, exist_ok=False)
    helper.save(
        events / "start.json",
        {
            "wrapper_sha256": hashlib.sha256(read_regular(here, 65536)).hexdigest(),
            "frozen_publisher_sha256": HELPER_SHA256,
            "policy": POLICY,
            "capsule_path": str(args.capsule),
            "journal_path": str(args.root),
            "branch": args.branch,
            "state": "STARTING_ONLY_NOT_PUBLICATION_SUCCESS",
        },
    )
    install_readback(helper, events)
    helper.run(args.capsule, args.root, args.branch)


if __name__ == "__main__":
    main()
