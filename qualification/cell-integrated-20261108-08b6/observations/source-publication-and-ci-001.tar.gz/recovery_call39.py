"""One named, byte-identical blob recovery; never creates or updates a ref."""

import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import types

ROOT = Path(
    "/Users/qianqi/work/cell-integration-20261108-08b6-publication/source-journal"
)
CAPSULE = ROOT.parent / "source-capsule.json.gz"
PUBLISHER = ROOT.parent / "publish_candidate.py"
PUBLISHER_SHA = "386e1e95a448a91a11bbe4962d3d7f2be16682f8d74851c890e72530f9f0a16e"
CAPSULE_SHA = "b9f96030150efb3fe38a272be061cb712115f7febadf6745e178482948fe20e1"
CAPSULE_BYTES = 283675
HEAD = "b839558b26c2e5b667055ca4af4ad749ae41c043"
TREE = "e411d25b47c166f35783a27054adb6a3f6682594"
BLOB = "7d26dc86fb86d677ea4d85eff76efc853b2dd84f"
REQUEST_SHA = "27cc97342a7313035174bb4d11bb61c3fb25c55faf8cfcbb839272e7981f7c46"
REPO = "TrillionniumFoundation/hepta-private-ci"
BRANCH = "engineering/cell-integrated-20261108-08b6"
ENDPOINT = f"repos/{REPO}/git/blobs"
NAME = "call0039-blob-7d26dc86-connect-timeout-001"
DIAL_ERROR = (
    b'Post "https://api.github.com/repos/TrillionniumFoundation/hepta-private-ci/git/blobs": '
    b"dial tcp 140.82.112.5:443: i/o timeout\n"
)
LIMIT = 8 * 1024 * 1024


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_regular(path, limit):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        require(stat.S_ISREG(os.fstat(stream.fileno()).st_mode), "Not a regular file")
        raw = stream.read(limit + 1)
    require(len(raw) <= limit, "Bound input exceeds its limit")
    return raw


def load_publisher():
    raw = read_regular(PUBLISHER, 65536)
    require(
        hashlib.sha256(raw).hexdigest() == PUBLISHER_SHA, "Frozen publisher differs"
    )
    module = types.ModuleType("frozen_publisher_for_call39")
    module.__file__ = str(PUBLISHER)
    exec(compile(raw, str(PUBLISHER), "exec"), module.__dict__)
    require(
        module.GH == "/opt/homebrew/bin/gh" and module.REPO == REPO,
        "Publisher authority differs",
    )
    return module


def run():
    pub = load_publisher()
    packed = read_regular(CAPSULE, CAPSULE_BYTES)
    require(
        len(packed) == CAPSULE_BYTES
        and hashlib.sha256(packed).hexdigest() == CAPSULE_SHA,
        "Original source capsule differs",
    )
    with gzip.GzipFile(fileobj=io.BytesIO(packed)) as stream:
        raw = stream.read(LIMIT + 1)
    require(len(raw) <= LIMIT, "Original source capsule exceeds 8 MiB")
    data = json.loads(raw)
    expected_binding = {
        "capsule_sha256": CAPSULE_SHA,
        "head": HEAD,
        "tree": TREE,
        "repository": REPO,
        "branch": BRANCH,
    }
    require(
        (data["repository"], data["branch"], data["head"], data["tree"])
        == (REPO, BRANCH, HEAD, TREE),
        "Source identities differ",
    )
    blob_bytes = base64.b64decode(data["blobs"][BLOB], validate=True)
    require(pub.git_oid("blob", blob_bytes) == BLOB, "Capsule blob bytes differ")
    names = ["binding.json", f"object-intents/blobs-{BLOB}.json"]
    names += [
        f"calls/0039/{name}"
        for name in (
            "intent.json",
            "request.json",
            "result.json",
            "stdout.bin",
            "stderr.bin",
        )
    ]
    originals = {name: read_regular(ROOT / name, LIMIT) for name in names}
    require(
        json.loads(originals["binding.json"]) == expected_binding,
        "Original journal binding differs",
    )
    request_raw = originals["calls/0039/request.json"]
    require(
        hashlib.sha256(request_raw).hexdigest() == REQUEST_SHA,
        "Original request pin differs",
    )
    request = json.loads(request_raw)
    require(
        set(request) == {"encoding", "content"} and request["encoding"] == "base64",
        "Unexpected blob request",
    )
    require(
        base64.b64decode(request["content"], validate=True) == blob_bytes,
        "Original request and capsule differ",
    )
    require(
        pub.json_bytes(request) == request_raw,
        "Replay serialization would change original bytes",
    )
    require(
        json.loads(originals["calls/0039/intent.json"])
        == {"endpoint": ENDPOINT, "method": "POST", "request_sha256": REQUEST_SHA},
        "Original call intent differs",
    )
    require(
        json.loads(originals[f"object-intents/blobs-{BLOB}.json"])
        == {
            "endpoint": f"{ENDPOINT}/{BLOB}",
            "expected_sha": BLOB,
            "request_sha256": REQUEST_SHA,
        },
        "Original object intent differs",
    )
    old = json.loads(originals["calls/0039/result.json"])
    require(
        old["state"] == "UNKNOWN" and old["exit_code"] == 1,
        "Original outcome is not the bound UNKNOWN",
    )
    require(
        originals["calls/0039/stdout.bin"] == b""
        and originals["calls/0039/stderr.bin"] == DIAL_ERROR,
        "Original connect-failure evidence differs",
    )
    intent_data = {
        "schema": "hepta.named-immutable-blob-recovery.v1",
        "name": NAME,
        "source_binding": expected_binding,
        "original_call": 39,
        "original_records_sha256": {
            name: hashlib.sha256(value).hexdigest() for name, value in originals.items()
        },
        "publisher_sha256": PUBLISHER_SHA,
        "expected_blob": BLOB,
        "request_sha256": REQUEST_SHA,
        "decoded_bytes_sha256": hashlib.sha256(blob_bytes).hexdigest(),
        "maximum_additional_posts": 1,
        "reference_mutations_allowed": False,
        "original_unknown_preserved": True,
        "policy": "one exact immutable blob POST after observed TCP connect failure; no attribution of the original attempt",
    }
    pub.private_directory(ROOT / "recovery")
    directory = ROOT / "recovery" / NAME
    pub.private_directory(directory)
    intent = directory / "intent.json"
    if intent.exists():
        require(
            json.loads(read_regular(intent, 65536)) == intent_data,
            "Named recovery binding differs",
        )
    publisher = pub.Publisher(ROOT)
    result = {
        "name": NAME,
        "state": "UNRESOLVED",
        "additional_post_attempted": False,
        "reference_mutations": 0,
        "original_unknown_preserved": True,
        "starting_call_count": publisher.count,
        "expected_blob": BLOB,
    }

    def verify_blob(value):
        require(
            value["sha"] == BLOB and value["encoding"] == "base64",
            "Remote blob identity differs",
        )
        decoded = base64.b64decode("".join(value["content"].split()), validate=True)
        require(
            decoded == blob_bytes and value["size"] == len(blob_bytes),
            "Remote blob bytes differ",
        )

    try:
        status, viewer = publisher.api("user")
        require(
            status == 200 and viewer["login"] == "ProfHepta",
            "Unexpected GitHub identity",
        )
        status, repo = publisher.api(f"repos/{REPO}")
        require(
            status == 200
            and repo["full_name"] == REPO
            and repo["permissions"]["push"] is True,
            "Repository authority differs",
        )
        status, value = publisher.api(f"{ENDPOINT}/{BLOB}")
        ref_status, ref = publisher.api(f"repos/{REPO}/git/ref/heads/{BRANCH}")
        require(
            ref_status == 404 or (ref_status == 200 and ref["object"]["sha"] == HEAD),
            "Source ref differs; recovery stopped",
        )
        result["preflight_blob_status"] = status
        result["preflight_source_ref_status"] = ref_status
        if status == 404:
            require(
                not intent.exists(),
                "Named recovery already exists; GET 404 remains unresolved, no second POST",
            )
            require(
                not (ROOT / "ref-intent.json").exists(),
                "Reference intent exists; no recovery write",
            )
            require(
                all(
                    read_regular(ROOT / name, len(value)) == value
                    for name, value in originals.items()
                ),
                "Original records changed before recovery",
            )
            pub.save(intent, intent_data)
            result["additional_post_attempted"] = True
            status, created = publisher.api(ENDPOINT, request)
            require(
                status == 201 and created["sha"] == BLOB,
                "Recovery POST returned a different object",
            )
            status, value = publisher.api(f"{ENDPOINT}/{BLOB}")
        require(status == 200, "Blob presence remains unresolved")
        verify_blob(value)
        result["state"] = "RESOLVED_PRESENT"
        result["creating_attempt"] = "not_attributed"
    except Exception as error:
        result["reason"] = str(error)
        raise
    finally:
        unchanged = all(
            read_regular(ROOT / name, len(value)) == value
            for name, value in originals.items()
        )
        result["original_records_unchanged"] = unchanged
        result["ending_call_count"] = publisher.count
        if not unchanged:
            result["state"] = "ORIGINAL_RECORDS_CHANGED"
        pub.save(directory / f"observation-{publisher.count:04d}.json", result)
        require(unchanged, "Original UNKNOWN records changed during recovery")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    run()
