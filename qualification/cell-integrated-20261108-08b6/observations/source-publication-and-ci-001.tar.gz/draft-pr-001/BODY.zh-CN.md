## 问题与目的

训练子进程原先整段捕获 stdout/stderr，日志增长与持管后代可能使资源和完成状态失去明确边界。训练输出校验、实际受测源码、完整归档及研究运行又各有不同身份，需要在一个共同候选上验证，才能判断本轮工程改动究竟提供了什么。

本 PR 将这些工程控制收敛到一个精确受测候选，并保留独立研究的负面裁决。它没有将其他 PR 的通过记录或未冻结实现拼接为已经运行的生产系统。

## 具体改动

- 在实际 `pipeline.run_training_job` 调用点接入有界 POSIX 子进程监督：stdout/stderr 各 8 MiB，保留原 660 秒外层预算，清理计入实际 wall；保留真实退出码，超时/超限另行分类。退出或清理无法确认时保持 unresolved，已有 operation 不会隐式重跑。
- 将监督政策与 parent 监督源码独立绑定到 v2 admission；不改写 trainer 模型内容 lineage。保持旧 v2 记录的明确兼容边界，并校验新监督结果与实际训练产物。
- 加入完整源码归档一致性校验、共同配置/状态约束和统一工程门禁；记录运行 profile、源码前后身份、日志及成本作用域。
- 加入 PRED-1 训练/开发诊断与独立确认的冻结、执行 guard 和复现材料。原确认结果不用于继续调参；科学结果与工程门禁分别判断。

## 实际验证身份与结果

| 项目 | 结果 |
|---|---|
| 受测源码 C | `b839558b26c2e5b667055ca4af4ad749ae41c043` |
| 完整 tree | `e411d25b47c166f35783a27054adb6a3f6682594` |
| 原生工程测试 | **74/74 通过，0 skipped，0 failures，0 errors** |
| 测试窗口 / 总门禁窗口 | 14.368647 秒 / 18.233415 秒；测试时间包含在总门禁内 |
| 完整归档 | `source.tar`，162,334,720 bytes；11,386 个 tracked files 完整核对 |
| 归档 SHA-256 | `d1e54cba3f206516725a53a33aed7aafd204003fd7997992878d3f4a7146cf32` |

六组测试覆盖共同配置、状态 codec、子进程监督、训练结果协议、源码归档与 PRED-1 训练/开发诊断。监督测试包含真实 child 的正常/异常退出、日志超限、超时、部分输出、持管后代、I/O 故障及实际 pipeline 调用点；并非只 mock supervisor。门禁前、测试后、门禁结束的 commit/tree/index-tree 一致。

工程环境为 Python 3.12.3、NumPy 1.26.4、Pillow 12.0.0、Torch 2.9.1+cpu，线程设置固定为 1。环境准备 53.4240 秒另记（工程证据包内 `validation-environment-001/RESULT.json`）；上述窗口不包括完整研究、转运、发布或全部准备成本。

## PRED-1：独立模拟完成，HOLD 保留

新研究使用**原归档 runner 与另行冻结的研究配置**，不是在 C 上证明模型或普通 Cell 生产收益。16 个独立训练 seed 的 GRU−single-step 平均净效用增量为 **+0.01093896**，单侧配对符号翻转 **p = 0.08126831**；未达到同时要求的增量 ≥ +0.020、p ≤ 0.05，结果为 `simulation_gain_not_established`，原 HOLD 保留。

完整产物审计核对 435 个 manifest 输出及 114 个 checkpoint；实际消费 114 fits、109,440 optimizer steps、14,008,320 次样本呈现。主统计单位仍是 16 个 seed。原始 NPZ/checkpoint、失败/修复窗口与审计分别归档；这不授予生产采用或完整物理/货币成本资格。

## 尚未闭合的生产范围

本轮未修改 Rust，尚未完成“普通任务→真实经验→训练→独立评价→采用/NoUpdate→不同下一任务消费”。原始 owner 能力、durable native-job、当前签名 trust、独立 holdout custody、采用与 next-use 接线仍需实际接入；不能用 fixture、自签结果或调用者提供的摘要替代。

源码正则审查只支持其可见实现和 main 接线范围，不能证明宏、生成代码或仓库外 provider 不存在。当前 `scientific_qualified=false`、`production_qualified=false`；组织演化与改进器收益未在本 PR 中建立。

## PR 比较范围与外部回执

- 目标 base：`fix/codex-v13-same-model-next-task-20261106`；原 Mac `gh` 预检回读 HEAD 为 `6ddfca2406e4d01416cd2f7ab1655a0dc16f8da5`，实际建 PR 前再次核对。
- `b040333617ed493944ae028bfb502c94d3b10991` 是已发布 commit，但其旧 branch ref 回读为 404，不能用该旧分支名称假定当前比较基线。
- 本 PR 相对暂定 base **可能包含此前 foundation 改动**。本轮候选记录的 8 个提交不是对整个 PR diff 的范围声明；实际 compare/merge-base 和文件列表须随 PR 建立后回读核实。
- 源码分支：`engineering/cell-integrated-20261108-08b6`；发布 HEAD 已回读为 **`b839558b26c2e5b667055ca4af4ad749ae41c043`**，tree 为 `e411d25b47c166f35783a27054adb6a3f6682594`，与受测 C 精确一致。
- 托管 CI：**pending / external receipt**。原生门禁通过不等于托管 CI 已完成。
- 证据分支：`engineering/cell-integrated-20261108-08b6-evidence`；发布 HEAD 与链接：**pending / external receipt**。其报告/证据提交不替代受测 C 的源码身份。

审查材料包括[源码资格与缺口](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/b839558b26c2e5b667055ca4af4ad749ae41c043/qualification/cell-integrated-20261108-08b6)。后续证据分支将保存 `RESULTS.zh-CN.md`、`result.json`、`PRED1_ARTIFACT_AUDIT.json`、`PRED1_RESULT.zh-CN.md` 和完整原始证据包；最终回读后补入链接。
