"""Validate the frozen common candidate, without advancing scientific qualification."""

from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import resource
import shutil
import subprocess
import sys
import time


ROOT = Path("/home/qian-qi/work/cell-integration-20261108-08b6")
SOURCE = ROOT / "source"
HEAD = "b839558b26c2e5b667055ca4af4ad749ae41c043"
TREE = "e411d25b47c166f35783a27054adb6a3f6682594"
OUTPUT = ROOT / "final-validation-001"
PROFILE = SOURCE / "qualification/cell-integrated-20261108-08b6/VALIDATION_PROFILE.json"
STUDY = Path("/home/qian-qi/work/cell-pred1-independent-20261108-08b6")


def pin(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while raw := stream.read(1024 * 1024):
            digest.update(raw)
    return {"path": path.name, "bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def resources():
    values = {"self_process_cpu_seconds": time.process_time(),
              "children": {name: getattr(resource.getrusage(resource.RUSAGE_CHILDREN), name)
                           for name in ("ru_utime", "ru_stime", "ru_maxrss")}}
    try:
        name = next(line[3:] for line in Path("/proc/self/cgroup").read_text().splitlines()
                    if line.startswith("0::"))
        cgroup = Path("/sys/fs/cgroup") / name.lstrip("/")
        values["cgroup"] = str(cgroup)
        values["cgroup_values"] = {name: (cgroup / name).read_text().strip()
                                   for name in ("cpu.max", "cpu.stat", "memory.max", "memory.peak")}
    except (OSError, StopIteration):
        values["cgroup_values"] = None
    return values


def main():
    OUTPUT.mkdir(exist_ok=False)
    start = time.monotonic()
    receipt = {"schema": "hepta.integrated-candidate-native-gate.v1",
               "started_at_utc": datetime.now(timezone.utc).isoformat(),
               "source_commit": HEAD, "source_tree": TREE, "steps": [], "exit_code": None,
               "scientific_qualified": False, "production_qualified": False,
               "joint_learning_configuration": None, "resources_before": resources()}

    def save():
        temporary = OUTPUT / "result.tmp"
        temporary.write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
        os.replace(temporary, OUTPUT / "result.json")

    def run(name, args, timeout):
        before = resource.getrusage(resource.RUSAGE_CHILDREN)
        wall = time.monotonic()
        stdout, stderr = OUTPUT / (name + ".stdout"), OUTPUT / (name + ".stderr")
        with stdout.open("xb") as out, stderr.open("xb") as err:
            process = subprocess.run(args, cwd=SOURCE, env=env, stdout=out, stderr=err,
                                     timeout=timeout, check=False)
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
        row = {"name": name, "argv": args, "exit_code": process.returncode,
               "wall_seconds": time.monotonic() - wall,
               "child_cpu_seconds": after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime,
               "stdout": pin(stdout), "stderr": pin(stderr)}
        receipt["steps"].append(row)
        save()
        print(json.dumps(row), flush=True)
        if process.returncode:
            print(stderr.read_text()[-6000:], flush=True)
            raise RuntimeError(name + " failed")
        return row

    env = os.environ.copy()
    env.update(PYTHONPATH=str(SOURCE / "scripts") + os.pathsep + str(SOURCE),
               PYTHONDONTWRITEBYTECODE="1")
    profile = json.loads(PROFILE.read_text())
    env.update(profile["thread_environment"])
    sys.path.insert(0, str(SOURCE / "scripts"))
    from hepta_cell_joint_config import source_identity

    def identity():
        observed = source_identity(SOURCE)
        if observed != {"commit": HEAD, "tree": TREE, "index_tree": TREE}:
            raise RuntimeError("Complete source bytes/identity differ")
        return observed

    save()
    try:
        receipt["source_before"] = identity()
        versions = {name: importlib.metadata.version(name) for name in profile["dependencies"]}
        if versions != profile["dependencies"] or sys.version_info[:2] != (3, 12):
            raise RuntimeError("Validation environment differs from profile")
        receipt["runtime"] = {"python": sys.version, "platform": platform.platform(),
                              "executable": str(Path(sys.executable).resolve()),
                              "executable_pin": pin(Path(sys.executable).resolve()),
                              "dependencies": versions, "thread_environment": profile["thread_environment"],
                              "profile": pin(PROFILE)}
        save()
        test = run("common-python-controls", [sys.executable, "-B", "-m", "unittest", "-v",
                                               *profile["test_modules"]], profile["test_timeout_seconds"])
        log = (OUTPUT / "common-python-controls.stderr").read_text()
        counts = re.findall(r"^Ran (\d+) tests in ([0-9.]+)s$", log, re.MULTILINE)
        if len(counts) != 1 or int(counts[0][0]) != 74 or not re.search(r"^OK$", log, re.MULTILINE):
            raise RuntimeError("Exactly 74 tests and plain OK (no skips/expected failures) are required")
        if re.search(r"\bskipped\b|\bexpected failure\b|^FAILED", log):
            raise RuntimeError("Skipped or failed test evidence refused")
        test.update(tests=74, passed=74, skipped=0, failures=0, errors=0,
                    unittest_wall_seconds=float(counts[0][1]))
        receipt["source_after_tests"] = identity()
        save()
        archive = OUTPUT / "source.tar"
        run("complete-source-archive", ["git", "archive", "--format=tar", "--prefix=source/",
                                        "--output=" + str(archive), HEAD], 120)
        config = OUTPUT / "VALIDATION_PROFILE.json"
        shutil.copyfile(PROFILE, config)
        binding = {"schema": "hepta.source-archive-binding.v1",
                   "tested_source": {"commit": HEAD, "tree": TREE},
                   "release_source": {"commit": HEAD, "tree": TREE},
                   "archive": pin(archive), "archive_prefix": "source",
                   "runtime_configuration": pin(config)}
        (OUTPUT / "archive-binding.json").write_text(json.dumps(binding, indent=2) + "\n")
        run("complete-archive-integrity", [sys.executable, "-B", "scripts/hepta_source_archive.py",
                                           "--binding", str(OUTPUT / "archive-binding.json"),
                                           "--source-root", str(SOURCE), "--artifact-root", str(OUTPUT),
                                           "--output", str(OUTPUT / "archive-integrity.json")], 180)
        integrity = json.loads((OUTPUT / "archive-integrity.json").read_text())
        if integrity["integrity_verified"] is not True or integrity["tested_source"] != receipt["source_before"]:
            raise RuntimeError("Archive integrity gate differs")
        receipt["archive"] = {"file": pin(archive), "report": pin(OUTPUT / "archive-integrity.json"),
                              "complete_tracked_files": len(integrity["files"]),
                              "inventory_sha256": integrity["inventory_sha256"], "integrity_only": True}
        run("training-dev-diagnostic", [sys.executable, "-B", "scripts/hepta_pred1/diagnose_training.py",
                                         "--campaign", str(STUDY / "bundle/training"),
                                         "--config", str(STUDY / "bundle/config/original-registered-config.json"),
                                         "--source", str(STUDY / "bundle/source/hepta_pred1/run.py"),
                                         "--output", str(OUTPUT / "diagnostic")], 60)
        diagnostic = json.loads((OUTPUT / "diagnostic/DIAGNOSTIC.json").read_text())
        basis = json.loads((STUDY / "bundle/provenance/train-dev-diagnostic-002/DIAGNOSTIC.json").read_text())
        for name in ("fit_rows", "costs", "registered_family_rule_recomputed", "evaluation_training_seed_development_comparisons"):
            if diagnostic[name] != basis[name]:
                raise RuntimeError("Final diagnostic differs scientifically from original frozen basis")
        receipt["diagnostic"] = {"scientific_fields_equal_original": True,
                                 "report": pin(OUTPUT / "diagnostic/DIAGNOSTIC.json")}
        receipt["source_after"] = identity()
        receipt["exit_code"] = 0
    except BaseException as error:
        receipt["exit_code"] = 1
        receipt["error"] = {"type": type(error).__name__, "message": str(error)}
    finally:
        receipt["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        receipt["total_wall_seconds"] = time.monotonic() - start
        receipt["resources_after"] = resources()
        receipt["cost_scope"] = "This validation process and its children only; environment setup, research, remote transport and publication separately recorded. Nested step times are not additive to total."
        save()
        print(json.dumps(receipt), flush=True)
    if receipt["exit_code"]:
        return 1
    sys.path.insert(0, str(ROOT / "helpers"))
    from export_git_capsule import export
    capsule = export(SOURCE, HEAD, "engineering/cell-integrated-20261108-08b6", ROOT / "source-capsule.json.gz")
    (ROOT / "source-capsule-summary.json").write_text(json.dumps(capsule, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
