"""Export exact Git objects for the two private integration publication refs."""

import argparse
import base64
import gzip
import hashlib
import json
from pathlib import Path
import subprocess


BASE = "b040333617ed493944ae028bfb502c94d3b10991"
BASE_TREE = "08e4b2962ad42dfdb544719b5837407bde31498a"
BRANCH = "engineering/cell-integrated-20261108-08b6"


def export(source, head, branch, output):
    def git(*args):
        return subprocess.check_output(["git", "-C", str(source), *args])

    if branch not in (BRANCH, BRANCH + "-evidence"):
        raise ValueError("Unexpected publication branch")
    if git("rev-parse", BASE + "^{tree}").decode().strip() != BASE_TREE:
        raise ValueError("Base tree differs")
    head = git("rev-parse", head + "^{commit}").decode().strip()
    chain = git("rev-list", "--reverse", BASE + ".." + head).decode().splitlines()
    if not 1 <= len(chain) <= 12:
        raise ValueError("Expected at most twelve linear commits")
    capsule = {"repository": "TrillionniumFoundation/hepta-private-ci", "branch": branch,
               "base_commit": BASE, "base_tree": BASE_TREE, "blobs": {}, "commits": [],
               "head": head, "tree": git("rev-parse", head + "^{tree}").decode().strip()}
    previous = BASE
    for sha in chain:
        raw = git("cat-file", "commit", sha)
        headers = raw.split(b"\n\n", 1)[0].splitlines()
        parents = [line[7:].decode() for line in headers if line.startswith(b"parent ")]
        if parents != [previous]:
            raise ValueError("Commit chain is not linear")
        tree = next(line[5:].decode() for line in headers if line.startswith(b"tree "))
        changes = []
        names = git("diff-tree", "--no-commit-id", "--name-only", "--no-renames", "-r", "-z", previous, sha)
        for name in filter(None, names.split(b"\0")):
            path = name.decode("utf-8")
            entry = git("ls-tree", "-z", sha, "--", path)
            deleted = not entry
            if deleted:
                entry = git("ls-tree", "-z", previous, "--", path)
            header, observed_name = entry.rstrip(b"\0").split(b"\t", 1)
            mode, kind, oid = [value.decode() for value in header.split()]
            if observed_name != name or kind != "blob":
                raise ValueError("Unexpected changed tree entry")
            changes.append({"path": path, "mode": mode, "type": kind,
                            "sha": None if deleted else oid})
            if not deleted and oid not in capsule["blobs"]:
                blob = git("cat-file", "blob", oid)
                actual = hashlib.sha1(b"blob " + str(len(blob)).encode() + b"\0" + blob).hexdigest()
                if actual != oid:
                    raise ValueError("Git blob verification failed")
                capsule["blobs"][oid] = base64.b64encode(blob).decode()
        capsule["commits"].append({"sha": sha, "tree": tree,
                                   "raw": base64.b64encode(raw).decode(), "changes": changes})
        previous = sha
    raw = json.dumps(capsule, sort_keys=True, separators=(",", ":")).encode()
    if len(raw) > 8 * 1024 * 1024:
        raise ValueError("Publication capsule exceeds frozen publisher limit")
    packed = gzip.compress(raw, mtime=0)
    with output.open("xb") as stream:
        stream.write(packed)
    result = {"head": head, "tree": capsule["tree"], "branch": branch,
              "commits": len(chain), "blobs": len(capsule["blobs"]),
              "bytes": len(packed), "uncompressed_bytes": len(raw),
              "sha256": hashlib.sha256(packed).hexdigest(), "path": str(output)}
    print(json.dumps(result), flush=True)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("head")
    parser.add_argument("branch")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    export(args.source, args.head, args.branch, args.output)
