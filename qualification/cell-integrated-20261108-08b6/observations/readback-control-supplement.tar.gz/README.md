# Readback control supplement

This independent supplement preserves the final publish_readback_candidate.py wrapper, its original nine-case offline validation receipt, the original unittest/fake-GH scripts, and raw QA logs. The prior local-control-evidence.tar.gz is unchanged and is not duplicated here. All original members retain their exact bytes.

## Role and limits

The wrapper loads the frozen publish_evidence_candidate.py only after verifying SHA-256 aa29200938ad622518f361e378afbffeb3d5f1799fdb0bc0c2501e0f69ce29a6. That dependency is present in the earlier local-control package and must sit beside the wrapper for execution. Both fixed source/evidence branches use this wrapper; the original source 8 MiB and evidence 32 MiB capsule limits remain unchanged.

Only an exact immutable-object GET with matching journal object intent, raw request SHA and HTTP 201 response SHA may receive up to four extra 404 readbacks. A GET UNKNOWN with empty stdout may receive up to two extra GET attempts. Each delay is one second, with at most seven total GET attempts per API call. Existing POST, object intent and ref CAS rules remain in the frozen publisher. No POST is retried automatically, and ref 404 receives no visibility retry. Parsing a pre-existing request proof permits up to 32 MiB; it does not enlarge source capsule limits.

The nine retained tests run real local fake-GH subprocesses with synthetic journals/capsules, under python -O. They check transient and persistent 404s, transport UNKNOWN bounds, no POST/ref-CAS replay, invalid request proof, large blob proof and permission/partial-response handling. The timeout fixture is an exit-1 dial-timeout response with empty stdout, not a 40-second wall timeout. The wrapper delay is mocked in tests and its requested duration is asserted. Test and fake-GH source scripts are retained; only disposable synthetic fixture directories were cleaned.

These offline controls do not establish success of the actual source/evidence publication, GitHub Actions execution, native 74-test run, production adoption, fixed-graph real-task learning benefit, or scientific promotion. This package contains no remote execution results.

## Integrity and reproduction

MANIFEST.json lists each payload file's path, bytes, SHA-256 and original scope, including this README; it omits its own recursive hash. Tar members are sorted ordinary relative files, USTAR, mode 0644, uid/gid 0, empty owner/group names and mtime 0. Gzip uses an empty filename, mtime 0 and level 9. The builder checked every member without extraction, rebuilt identical compressed bytes and rechecked original inputs. No remote operation occurred during packaging.

For an offline rerun, place the frozen evidence publisher beside the wrapper, preserve the listed directory layout, make candidate-review/readback-wrapper-qa/fake_gh.py executable (tar's normalized mode is 0644), and run: python -O -B candidate-review/readback-wrapper-qa/test_publish_readback_candidate.py. This uses local fake GH only.
