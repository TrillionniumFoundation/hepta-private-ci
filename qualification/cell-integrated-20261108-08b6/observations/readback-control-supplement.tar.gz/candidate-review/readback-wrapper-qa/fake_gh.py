#!/usr/bin/env python3
"""Offline queued GH responses; this executable never opens a network connection."""

import hashlib
import json
import os
from pathlib import Path
import sys

scenario = Path(os.environ["HEPTA_READBACK_OFFLINE_CASE"])
state = json.loads(scenario.read_text())
args = sys.argv[1:]
endpoint = args[args.index("--include") + 1]
method = args[args.index("--method") + 1] if "--method" in args else "GET"
request = (
    Path(args[args.index("--input") + 1]).read_bytes() if "--input" in args else None
)
observed = {
    "endpoint": endpoint,
    "method": method,
    "request_sha256": hashlib.sha256(request).hexdigest() if request else None,
}
index = len(state["observed"])
state["observed"].append(observed)
scenario.write_text(json.dumps(state, indent=2))
if index >= len(state["steps"]):
    raise SystemExit("Unexpected extra offline call")
step = state["steps"][index]
if endpoint != step["endpoint"] or method != step.get("method", "GET"):
    raise SystemExit("Offline call does not match the explicit scenario")
if step.get("raw_stdout") is not None:
    sys.stdout.write(step["raw_stdout"])
elif step.get("status") is not None:
    sys.stdout.write(
        f"HTTP/2.0 {step['status']} Offline\r\nContent-Type: application/json\r\n\r\n"
        + json.dumps(step.get("body", {}))
    )
sys.stderr.write(step.get("stderr", ""))
raise SystemExit(step.get("exit_code", 0 if step.get("status") != 404 else 1))
