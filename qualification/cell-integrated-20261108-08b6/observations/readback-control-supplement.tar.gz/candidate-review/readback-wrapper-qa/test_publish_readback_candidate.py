"""Retained original offline QA; only synthetic fixture directories are temporary."""

import base64
import gzip
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

TASK = Path(__file__).absolute().parents[2]
spec = importlib.util.spec_from_file_location(
    "readback_wrapper", TASK / "publish_readback_candidate.py"
)
wrapper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wrapper)
FAKE_GH = Path(__file__).with_name("fake_gh.py").absolute()


class ReadbackControls(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="readback-offline-fixtures-")
        self.addCleanup(temporary.cleanup)
        self.work = Path(temporary.name)
        self.root = self.work / "journal"
        self.case = self.work / "case.json"
        self.helper = wrapper.load_helper(TASK / "publish_evidence_candidate.py")
        self.helper.GH = str(FAKE_GH)
        self.helper.private_directory(self.root)
        self.events = self.root / "wrapper-events"
        self.helper.private_directory(self.events)
        original_run, original_object = self.helper.run, self.helper.Publisher.object
        wrapper.install_readback(self.helper, self.events)
        self.assertIs(self.helper.run, original_run)
        self.assertIs(self.helper.Publisher.object, original_object)
        self.publisher = self.helper.Publisher(self.root)
        environment = patch.dict(
            os.environ, {"HEPTA_READBACK_OFFLINE_CASE": str(self.case)}
        )
        environment.start()
        self.addCleanup(environment.stop)
        sleeping = patch.object(wrapper, "sleep")
        self.sleep = sleeping.start()
        self.addCleanup(sleeping.stop)
        self.sha = "a" * 40
        self.endpoint = f"repos/{self.helper.REPO}/git/trees/{self.sha}"
        self.post = self.endpoint.rsplit("/", 1)[0]
        self.request = {"base_tree": "b" * 40, "tree": []}

    def scenario(self, steps):
        self.case.write_text(json.dumps({"steps": steps, "observed": []}))

    def observed(self):
        return json.loads(self.case.read_text())["observed"]

    def step(self, status, *, endpoint=None, method="GET", body=None, **extra):
        return {
            "endpoint": endpoint or self.endpoint,
            "method": method,
            "status": status,
            "body": body or {"sha": self.sha},
            **extra,
        }

    def test_new_post_201_then_temporary_404_then_200(self):
        self.scenario(
            [
                self.step(404),
                self.step(201, endpoint=self.post, method="POST"),
                self.step(404),
                self.step(200),
            ]
        )
        result = self.publisher.object("trees", self.sha, self.request)
        self.assertEqual(result["sha"], self.sha)
        self.assertEqual(
            [x["method"] for x in self.observed()], ["GET", "POST", "GET", "GET"]
        )
        event = json.loads((self.events / "retry-after-0003.json").read_text())
        self.assertEqual(event["creation_proof"]["post_call"], 2)
        self.sleep.assert_called_once_with(1)

    def test_historical_201_persistent_404_stops_without_new_post(self):
        self.scenario(
            [
                self.step(404),
                self.step(201, endpoint=self.post, method="POST"),
                self.step(200),
            ]
            + [self.step(404) for _ in range(5)]
        )
        self.publisher.object("trees", self.sha, self.request)
        with self.assertRaisesRegex(RuntimeError, "no second mutation"):
            self.publisher.object("trees", self.sha, self.request)
        self.assertEqual(len(self.observed()), 8)
        self.assertEqual(sum(x["method"] == "POST" for x in self.observed()), 1)
        self.assertEqual(self.sleep.call_count, 4)

    def test_get_transport_timeout_then_200(self):
        self.scenario(
            [
                self.step(
                    None,
                    endpoint="user",
                    exit_code=1,
                    stderr='Get "https://api.github.com/user": dial tcp: i/o timeout\n',
                ),
                self.step(200, endpoint="user", body={"login": "ProfHepta"}),
            ]
        )
        self.assertEqual(self.publisher.api("user"), (200, {"login": "ProfHepta"}))
        unknown = json.loads((self.publisher.calls / "0001/result.json").read_text())
        self.assertEqual(unknown["state"], "UNKNOWN")
        self.assertEqual(len(self.observed()), 2)
        self.sleep.assert_called_once_with(1)

    def test_post_unknown_is_never_replayed(self):
        self.scenario(
            [
                self.step(404),
                self.step(
                    None,
                    endpoint=self.post,
                    method="POST",
                    exit_code=1,
                    stderr="dial tcp: i/o timeout\n",
                ),
                self.step(404),
            ]
        )
        with self.assertRaisesRegex(RuntimeError, "UNKNOWN"):
            self.publisher.object("trees", self.sha, self.request)
        with self.assertRaisesRegex(RuntimeError, "no second mutation"):
            self.publisher.object("trees", self.sha, self.request)
        self.assertEqual([x["method"] for x in self.observed()], ["GET", "POST", "GET"])
        self.sleep.assert_not_called()

    def test_mismatched_request_proof_is_not_accepted(self):
        self.scenario(
            [
                self.step(404),
                self.step(201, endpoint=self.post, method="POST"),
                self.step(200),
                self.step(404),
            ]
        )
        self.publisher.object("trees", self.sha, self.request)
        (self.publisher.calls / "0002/request.json").write_text("{}\n")
        with self.assertRaisesRegex(RuntimeError, "no second mutation"):
            self.publisher.object("trees", self.sha, self.request)
        self.assertEqual(len(self.observed()), 4)
        self.sleep.assert_not_called()

    def test_created_blob_request_above_8_mib_is_valid_proof(self):
        raw = b"x" * (6 * 1024 * 1024 + 1)
        sha = self.helper.git_oid("blob", raw)
        request = {"encoding": "base64", "content": base64.b64encode(raw).decode()}
        encoded = self.helper.json_bytes(request)
        self.assertGreater(len(encoded), self.helper.CAPSULE_LIMIT)
        self.assertLess(len(encoded), self.helper.EVIDENCE_CAPSULE_LIMIT)
        endpoint = f"repos/{self.helper.REPO}/git/blobs/{sha}"
        self.scenario(
            [
                self.step(404, endpoint=endpoint),
                self.step(
                    201,
                    endpoint=endpoint.rsplit("/", 1)[0],
                    method="POST",
                    body={"sha": sha},
                ),
                self.step(404, endpoint=endpoint),
                self.step(200, endpoint=endpoint, body={"sha": sha}),
            ]
        )
        self.assertEqual(self.publisher.object("blobs", sha, request)["sha"], sha)
        self.assertEqual(len(self.observed()), 4)
        self.sleep.assert_called_once_with(1)

    def test_permission_or_partial_http_response_is_not_retried(self):
        for step in [
            self.step(403),
            self.step(429),
            self.step(None, raw_stdout="HTTP/2.0 200 OK\n\ninvalid-json"),
        ]:
            with self.subTest(step=step):
                self.scenario([step])
                with self.assertRaises(RuntimeError):
                    self.publisher.api(self.endpoint)
                self.assertEqual(len(self.observed()), 1)
        self.sleep.assert_not_called()

    def test_unknown_get_has_only_two_extra_attempts(self):
        self.scenario(
            [
                self.step(None, exit_code=1, stderr="dial tcp: i/o timeout\n")
                for _ in range(3)
            ]
        )
        with self.assertRaisesRegex(RuntimeError, "UNKNOWN"):
            self.publisher.api(self.endpoint)
        self.assertEqual(len(self.observed()), 3)
        self.assertEqual(self.sleep.call_count, 2)

    def test_ref_unknown_keeps_original_intent_and_never_replays_cas(self):
        h = self.helper
        base = "b040333617ed493944ae028bfb502c94d3b10991"
        base_tree = "08e4b2962ad42dfdb544719b5837407bde31498a"
        raw = (
            f"tree {self.sha}\nparent {base}\nauthor QA <qa@example.invalid> 1700000000 +0000\n"
            "committer QA <qa@example.invalid> 1700000000 +0000\n\nOffline fixture\n"
        ).encode()
        head = h.git_oid("commit", raw)
        capsule = self.work / "fixture.json.gz"
        capsule.write_bytes(
            gzip.compress(
                h.json_bytes(
                    {
                        "repository": h.REPO,
                        "branch": h.BRANCH,
                        "base_commit": base,
                        "base_tree": base_tree,
                        "head": head,
                        "tree": self.sha,
                        "blobs": {},
                        "commits": [
                            {
                                "sha": head,
                                "tree": self.sha,
                                "raw": base64.b64encode(raw).decode(),
                                "changes": [],
                            }
                        ],
                    }
                ),
                mtime=0,
            )
        )
        ref = f"repos/{h.REPO}/git/ref/heads/{h.BRANCH}"
        setup = [
            self.step(200, endpoint="user", body={"login": "ProfHepta"}),
            self.step(
                200,
                endpoint=f"repos/{h.REPO}",
                body={
                    "full_name": h.REPO,
                    "permissions": {"push": True},
                    "node_id": "OFFLINE",
                },
            ),
            self.step(
                200,
                endpoint=f"repos/{h.REPO}/git/commits/{base}",
                body={"tree": {"sha": base_tree}},
            ),
            self.step(404, endpoint=ref),
        ]
        self.scenario(
            setup
            + [
                self.step(200),
                self.step(
                    200,
                    endpoint=f"repos/{h.REPO}/git/commits/{head}",
                    body={"sha": head},
                ),
                self.step(404, endpoint=ref),
                self.step(
                    None,
                    endpoint="graphql",
                    method="POST",
                    exit_code=1,
                    stderr="dial tcp: i/o timeout\n",
                ),
            ]
            + setup
        )
        with self.assertRaisesRegex(RuntimeError, "UNKNOWN"):
            h.run(capsule, self.root)
        original_intent = (self.root / "ref-intent.json").read_bytes()
        with self.assertRaisesRegex(RuntimeError, "no second mutation"):
            h.run(capsule, self.root)
        self.assertEqual((self.root / "ref-intent.json").read_bytes(), original_intent)
        self.assertEqual(sum(x["endpoint"] == "graphql" for x in self.observed()), 1)
        self.assertEqual(len(self.observed()), 12)
        self.sleep.assert_not_called()


if __name__ == "__main__":
    unittest.main(verbosity=2)
