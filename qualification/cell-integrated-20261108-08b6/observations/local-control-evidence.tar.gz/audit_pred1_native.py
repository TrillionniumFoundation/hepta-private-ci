"""Audit all stored artifacts of the one independently frozen PRED-1 execution."""

from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import stat
import tarfile
import time


ROOT = Path("/home/qian-qi/work/cell-pred1-independent-20261108-08b6")


def pin(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while raw := stream.read(1024 * 1024):
            digest.update(raw)
    return {"bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def main():
    start, cpu = time.monotonic(), time.process_time()
    campaign = ROOT / "campaign-002"
    manifest = json.loads((campaign / "manifest.json").read_text())
    actual = {p.relative_to(campaign).as_posix() for p in campaign.rglob("*") if p.is_file()}
    if actual != set(manifest) | {"manifest.json"}:
        raise ValueError("Complete output file inventory differs")
    for name, expected in manifest.items():
        path = Path(name)
        if path.is_absolute() or ".." in path.parts:
            raise ValueError("Unsafe output manifest path")
        target = campaign / path
        if not stat.S_ISREG(target.lstat().st_mode) or pin(target) != expected:
            raise ValueError("Output file pin differs: " + name)
    freeze = json.loads((ROOT / "bundle/provenance/independent-confirmation-002/FREEZE.json").read_text())
    config = json.loads((ROOT / "bundle/provenance/independent-confirmation-002/registered_config.json").read_text())
    summary = json.loads((campaign / "summary.json").read_text())
    selection = json.loads((campaign / "selection.json").read_text())
    attempt = json.loads((campaign / "attempt.json").read_text())
    if attempt["status"] != "completed" or summary["config_sha256"] != freeze["config"]["sha256"]:
        raise ValueError("Completed experiment/configuration identity differs")
    expected = {(v, s) for v in freeze["models"] for s in config["selection_seeds"] + config["seeds"]}
    records = [json.loads(p.read_text()) for p in sorted(campaign.glob("*-training.json"))]
    if {(r["variant"], r["seed"]) for r in records} != expected or len(records) != 114:
        raise ValueError("Registered fit denominator differs")
    for record in records:
        name = record["checkpoint"]
        if selection["checkpoint_sha256"][name] != record["checkpoint_sha256"]:
            raise ValueError("Checkpoint selection record differs")
        if pin(campaign / name)["sha256"] != record["checkpoint_sha256"]:
            raise ValueError("Checkpoint bytes differ after execution")
        if record["epochs_consumed"] != 30 or record["optimizer_steps_consumed"] != 960:
            raise ValueError("Fit was dropped or stopped early")
    confirms = [json.loads(p.read_text()) for p in sorted(campaign.glob("*-confirm.json"))]
    expected_confirms = {(v, s) for v in freeze["models"] for s in config["seeds"]}
    if len(confirms) != 96 or {(r["variant"], r["seed"]) for r in confirms} != expected_confirms:
        raise ValueError("Confirmation model/seed denominator differs")
    if any(r["episodes"] != 1024 for r in confirms):
        raise ValueError("Confirmation episode denominator differs")
    end = json.loads((ROOT / "campaign-002.execution/END.json").read_text())
    if end["status"] != "COMPLETED" or end["confirmation_seeds_generated"] != config["seeds"]:
        raise ValueError("Wrapper execution completion differs")
    prior = json.loads((ROOT / "host-records/RESULT.json").read_text())
    repair = json.loads((ROOT / "environment-repair-001/RESULT.json").read_text())
    prior_python = json.loads((ROOT / "host-records/dependency-identity.stdout").read_text().splitlines()[0])["python"]
    if (ROOT / "campaign").exists() or (ROOT / "campaign.execution").exists():
        raise ValueError("Unexpected prior scientific output")
    report = {"schema": "pred1-complete-stored-artifact-audit-v1", "integrity_only": True,
              "audited_at_utc": datetime.now(timezone.utc).isoformat(),
              "campaign_manifest": pin(campaign / "manifest.json"),
              "verified_manifest_files": len(manifest),
              "verified_manifest_bytes": sum(item["bytes"] for item in manifest.values()),
              "fits": len(records), "checkpoint_byte_pins_verified_after_execution": len(records),
              "optimizer_steps_consumed": sum(r["optimizer_steps_consumed"] for r in records),
              "selected_checkpoint_steps": sum(r["selected_checkpoint_steps"] for r in records),
              "training_examples_consumed": sum(r["training_examples_consumed"] for r in records),
              "confirmation_model_seed_records": len(confirms),
              "confirmation_model_episode_evaluations": sum(r["episodes"] for r in confirms),
              "independent_primary_seed_count": len(config["seeds"]),
              "registered_confirmation_episode_units": len(config["seeds"]) * config["confirm_episodes"],
              "original_hold_unchanged": True, "independent_result": summary["status"],
              "primary_comparison": summary["primary_comparison"],
              "failed_environment_python": prior_python,
              "failed_environment_scientific_output_absent": True,
              "failed_host_window_seconds": prior["host_wall_seconds"],
              "environment_repair_and_successful_host_window_seconds": repair["host_wall_seconds"],
              "combined_observed_host_windows_seconds": prior["host_wall_seconds"] + repair["host_wall_seconds"],
              "full_physical_or_monetary_cost": False,
              "unmeasured": ["research peak memory", "energy", "money", "remote transport/queue", "all human/model research preparation"],
              "not_performed": ["new training", "new confirmation generation", "model reselection", "production adoption"],
              "audit_wall_seconds": time.monotonic() - start,
              "audit_process_cpu_seconds": time.process_time() - cpu}
    with (ROOT / "COMPLETE_ARTIFACT_AUDIT.json").open("x") as stream:
        stream.write(json.dumps(report, indent=2) + "\n")
    groups = ["frozen", "campaign-002", "campaign-002.execution", "host-records", "environment-repair-001"]
    files = [p for name in groups for p in (ROOT / name).rglob("*") if p.is_file()]
    files += [ROOT / "RESULT_EXTRACT.json", ROOT / "COMPLETE_ARTIFACT_AUDIT.json"]
    archive = ROOT / "pred1-independent-002-evidence.tar.gz"
    with archive.open("xb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w|") as tar:
            for path in sorted(files):
                if not stat.S_ISREG(path.lstat().st_mode):
                    raise ValueError("Evidence member is not a regular file")
                info = tarfile.TarInfo(path.relative_to(ROOT).as_posix())
                info.size = path.stat().st_size
                info.mode, info.mtime = 0o644, 0
                with path.open("rb") as content:
                    tar.addfile(info, content)
    result = {"archive": str(archive), **pin(archive), "members": len(files), "audit": report}
    with (ROOT / "EVIDENCE_PACKAGE.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
