# Local control evidence — 08b6

This package preserves seven frozen task-helper sources, their available offline validation receipts, and small original local QA logs. Every original file is retained byte for byte; no helper was formatted or modified during packaging. MANIFEST.json records each payload path, byte count, SHA-256 and original proof scope. It also records this README. The manifest excludes its own hash to avoid a self-reference.

## Proof boundaries

Offline publisher and recovery QA used fake GH subprocesses and synthetic API/journal fixtures. It does not replace the independently recorded native 74-test run, exact native runtime identity, source/archive integrity verification, actual GitHub publication or GitHub Actions execution. The native validation and PRED audit drivers are included as source only; their inclusion does not assert that they ran successfully.

Local archive verification proves its stated integrity behavior only. Local lifecycle QA exercises real POSIX children but does not establish training, production adoption or a full integrated task lifecycle. PRED diagnostic receipts preserve training/development-only and synthetic-guard scopes. They do not establish an independent confirmation result, fixed-graph real-task learning benefit, or scientific promotion. Historical pending flags remain historical facts and have not been rewritten using later evidence.

The r1 publisher receipt belongs to an intermediary helper revision. The r2 receipt belongs to the final original publisher. Consult each receipt and MANIFEST.json for exact source identities; do not combine results from different revisions into one executed system.

## Availability of offline harness sources

The fake GH executables were created by inline Python QA harnesses inside TemporaryDirectory contexts and were removed when those contexts exited. No original fake GH executable or persistent inline harness script remains in the searched task workspace or matching temporary QA directories. They are therefore absent here; none has been reconstructed and presented as an original. The original surviving JSON receipts are included. This package preserves the available evidence and does not claim complete rerun reproducibility for those transient harnesses.

## Included and excluded material

Included are the seven requested task helpers, all available candidate-review helper-validation JSON receipts, recovery/evidence-publisher offline receipts, and selected small archive/lifecycle/PRED QA receipts and raw logs. Lifecycle logs use their actual .stdout/.stderr names; there were no r3 *.log files. Full repositories, source capsules, source archives, model weights, repeated training inputs, native/PRED evidence archives, credentials, environment dumps and unrelated sessions are excluded. Paths appearing inside original receipts are provenance references, not bundled inputs.

## Archive integrity and deterministic construction

Members are ordinary relative files sorted by path, with no duplicates, symlinks or extraction-dependent normalization. Tar uses USTAR, mtime 0, uid/gid 0, empty owner/group names and mode 0644. Gzip uses an empty filename, mtime 0 and compression level 9. The builder read each original once, checked frozen helper pins, verified the archive inventory and every member byte digest without extracting, rebuilt identical compressed bytes, and rechecked that all original files were unchanged. No remote operation was performed during packaging.

To verify, open with Python tarfile in r:gz mode without extracting; parse MANIFEST.json; require that archive members are exactly its files plus MANIFEST.json, then compare each listed bytes and SHA-256 to extractfile(member).read(). A successful check verifies this package's bytes and inventory only; it does not authenticate test execution or scientific claims.
