"""Launch unchanged archived PRED-1 code with a separately pinned reject-only guard.

The hook validates the frozen boundary before any confirmation sample is made.
It never changes source files, model choices, hyperparameters, seeds or metrics.
"""

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import importlib
import json
import os
from pathlib import Path
import platform
import stat
import sys
import time


MAX_FILE_BYTES = 1_048_576


def canonical(value):
    return json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n"


def bounded_bytes(path):
    path = Path(path)
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError(f"ordinary non-symlink file required: {path}")
    if before.st_size > MAX_FILE_BYTES:
        raise ValueError(f"file exceeds frozen-run guard limit: {path}")
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    descriptor = os.open(path, flags)
    with os.fdopen(descriptor, "rb", buffering=0) as stream:
        opened = os.fstat(stream.fileno())
        if not stat.S_ISREG(opened.st_mode) or (
            opened.st_dev, opened.st_ino
        ) != (before.st_dev, before.st_ino):
            raise ValueError(f"file changed before guarded read: {path}")
        if opened.st_size > MAX_FILE_BYTES:
            raise ValueError(f"file exceeds frozen-run guard limit: {path}")
        raw = stream.read(MAX_FILE_BYTES + 1)
    if len(raw) > MAX_FILE_BYTES:
        raise ValueError(f"file exceeds frozen-run guard limit: {path}")
    return raw


def pinned_bytes(path, digest):
    raw = bounded_bytes(path)
    if sha256(raw).hexdigest() != digest:
        raise ValueError(f"pin mismatch: {path}")
    return raw


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(canonical(value))


class FrozenInputs:
    def __init__(self, bundle, supplement):
        self.bundle = Path(bundle).resolve()
        self.supplement = supplement
        self.freeze_path = self.bundle / "provenance/independent-confirmation-002/FREEZE.json"
        self.freeze = json.loads(pinned_bytes(
            self.freeze_path, supplement["original_protocol_sha256"]
        ))
        self.config_path = self.freeze_path.with_name("registered_config.json")
        self.source = self.bundle / "source/hepta_pred1"
        self.basis = self.bundle / "provenance/train-dev-diagnostic-002/DIAGNOSTIC.json"
        self.config = json.loads(pinned_bytes(
            self.config_path, self.freeze["config"]["sha256"]
        ))
        self.source_files = {
            name: identity["sha256"]
            for name, identity in self.freeze["source"]["files"].items()
        }
        self.source_identity = {
            "files": self.source_files,
            "sha256": sha256(canonical(self.source_files).encode()).hexdigest(),
        }
        self.verify()

    def verify(self):
        pinned_bytes(Path(__file__), self.supplement["wrapper_sha256"])
        pinned_bytes(self.freeze_path, self.supplement["original_protocol_sha256"])
        pinned_bytes(self.config_path, self.freeze["config"]["sha256"])
        if sha256(canonical(self.config).encode()).hexdigest() != self.freeze["config"]["sha256"]:
            raise ValueError("in-memory configuration differs from frozen bytes")
        pinned_bytes(self.basis, self.freeze["diagnostic_basis"]["sha256"])
        pinned_bytes(self.bundle / "MANIFEST.json", self.supplement["bundle_manifest_sha256"])
        if {p.name for p in self.source.glob("*.py")} != set(self.source_files):
            raise ValueError("frozen Python source inventory changed")
        for name, digest in self.source_files.items():
            if Path(name).name != name:
                raise ValueError("source pin must be a basename")
            pinned_bytes(self.source / name, digest)
        if self.source_identity["sha256"] != self.supplement["runner_source_identity_sha256"]:
            raise ValueError("runner source identity differs from execution supplement")
        if self.freeze["config"]["sha256"] != self.supplement["independent_config_sha256"]:
            raise ValueError("configuration identity differs from execution supplement")

    def verify_runner(self, runner):
        if Path(runner.__file__).resolve() != (self.source / "run.py").resolve():
            raise ValueError("imported runner is outside the pinned original package")
        if runner.source_identity() != self.source_identity:
            raise ValueError("imported runner source identity differs from original archive")
        if list(runner.VARIANTS) != self.freeze["models"]:
            raise ValueError("model inventory differs from frozen design")


class ConfirmationBoundaryGuard:
    def __init__(self, pins, runner, output, receipts):
        self.pins, self.runner = pins, runner
        self.output, self.receipts = Path(output), Path(receipts)
        self.generate = runner.generate_dataset
        self.passed = False
        self.attempted_seeds, self.generated_seeds = [], []
        self.guard_wall_seconds = 0.0
        self.guard_process_cpu_seconds = 0.0

    def check_boundary(self):
        wall, cpu = time.perf_counter(), time.process_time()
        try:
            self.pins.verify()
            self.pins.verify_runner(self.runner)
            config, freeze = self.pins.config, self.pins.freeze
            family_raw = bounded_bytes(self.output / "family-selection.json")
            selection_raw = bounded_bytes(self.output / "selection.json")
            family, selection = json.loads(family_raw), json.loads(selection_raw)
            expected_family = freeze["expected_family_from_original_development"]
            if family.get("selected_family") != expected_family or selection.get("selected_family") != expected_family:
                raise ValueError("development family differs from the frozen expected GRU; confirmation refused")
            if family.get("selection_seeds") != config["selection_seeds"] or family.get("evaluation_training_seeds") != config["seeds"]:
                raise ValueError("family-selection seed identity differs from frozen design")
            if family.get("frozen_before_evaluation_training") is not True or selection.get("selected_before_confirmation_generation") is not True:
                raise ValueError("original selection boundary is not recorded as frozen")
            if selection.get("independent_family_selection") != family:
                raise ValueError("family record differs from checkpoint selection record")
            all_seeds = config["selection_seeds"] + config["seeds"]
            expected = {
                f"{variant}-{seed}.npz": (variant, seed)
                for seed in all_seeds for variant in freeze["models"]
            }
            checkpoint_pins = selection.get("checkpoint_sha256")
            if not isinstance(checkpoint_pins, dict) or set(checkpoint_pins) != set(expected):
                raise ValueError("all registered fit checkpoints must be frozen before confirmation")
            for name, (variant, seed) in expected.items():
                training = json.loads(bounded_bytes(self.output / f"{variant}-{seed}-training.json"))
                if (training.get("seed"), training.get("variant"), training.get("checkpoint"), training.get("checkpoint_sha256")) != (seed, variant, name, checkpoint_pins[name]):
                    raise ValueError(f"training record does not bind frozen checkpoint: {name}")
                pinned_bytes(self.output / name, checkpoint_pins[name])
            receipt = {
                "schema": "pred1-confirmation-boundary-guard-v1",
                "status": "PASSED_BEFORE_FIRST_CONFIRMATION_GENERATION",
                "checked_at_utc": datetime.now(timezone.utc).isoformat(),
                "selected_family": expected_family,
                "checkpoint_count": len(expected),
                "checkpoint_manifest_sha256": sha256(canonical(checkpoint_pins).encode()).hexdigest(),
                "family_selection_sha256": sha256(family_raw).hexdigest(),
                "selection_sha256": sha256(selection_raw).hexdigest(),
                "runner_source_identity_sha256": self.pins.source_identity["sha256"],
                "independent_config_sha256": freeze["config"]["sha256"],
                "original_protocol_sha256": self.pins.supplement["original_protocol_sha256"],
                "confirmation_datasets_generated_before_guard": 0,
            }
            write_new(self.receipts / "CONFIRMATION_BOUNDARY.json", receipt)
            self.passed = True
        finally:
            self.guard_wall_seconds += time.perf_counter() - wall
            self.guard_process_cpu_seconds += time.process_time() - cpu

    def __call__(self, count, seed, split, length=16):
        if split != "confirm":
            return self.generate(count, seed, split, length)
        config = self.pins.config
        index = len(self.attempted_seeds)
        if index >= len(config["seeds"]) or seed != config["seeds"][index]:
            raise ValueError("confirmation seed order or denominator differs from frozen configuration")
        if count != config["confirm_episodes"] or length != config["history_length"]:
            raise ValueError("confirmation dataset dimensions differ from frozen configuration")
        if not self.passed:
            self.check_boundary()
        self.attempted_seeds.append(seed)
        result = self.generate(count, seed, split, length)
        self.generated_seeds.append(seed)
        return result


def main():
    start_wall, start_cpu = time.perf_counter(), time.process_time()
    started_at = datetime.now(timezone.utc).isoformat()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--supplement", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--check-only", action="store_true", help="Verify file pins only; no NumPy import, training or generation")
    args = parser.parse_args()
    supplement_raw = bounded_bytes(args.supplement)
    supplement = json.loads(supplement_raw)
    pinned_bytes(Path(__file__), supplement["wrapper_sha256"])
    pins = FrozenInputs(args.bundle, supplement)
    if args.check_only:
        print(canonical({"status": "INPUT_PINS_CHECKED_ONLY", "runner_source_identity_sha256": pins.source_identity["sha256"], "training_executed": False, "confirmation_generated": False}), end="")
        return
    if args.output is None:
        parser.error("--output is required unless --check-only is used")
    if sys.version_info[:2] != (3, 12):
        raise ValueError("this execution supplement pins Python 3.12")
    for name, value in supplement["thread_environment"].items():
        if os.environ.get(name) != value:
            raise ValueError(f"set {name}={value} before launching the interpreter")
    output = args.output.absolute()
    if output.exists():
        raise ValueError("campaign output directory must be new")
    receipts = output.with_name(output.name + ".execution")
    receipts.mkdir(parents=True, exist_ok=False)
    write_new(receipts / "START.json", {
        "started_at_utc": started_at,
        "supplement_sha256": sha256(supplement_raw).hexdigest(),
        "wrapper_sha256": supplement["wrapper_sha256"],
        "original_protocol_sha256": supplement["original_protocol_sha256"],
        "runner_source_identity_sha256": pins.source_identity["sha256"],
        "independent_config_sha256": pins.freeze["config"]["sha256"],
        "python": platform.python_version(),
        "platform": platform.platform(),
        "thread_environment": supplement["thread_environment"],
        "campaign_output": str(output),
        "scope": "Original archived PRED-1 simulator with separate reject-only execution guard; no integrated-candidate qualification",
    })
    guard, runner, original_generate = None, None, None
    outcome = {"status": "FAILED_BEFORE_COMPLETION"}
    try:
        sys.path.insert(0, str(pins.source.parent))
        runner = importlib.import_module("hepta_pred1.run")
        pins.verify_runner(runner)
        if runner.np.__version__ != supplement["numpy_version"]:
            raise ValueError("NumPy version differs from execution supplement")
        original_generate = runner.generate_dataset
        guard = ConfirmationBoundaryGuard(pins, runner, output, receipts)
        runner.generate_dataset = guard
        runner.run(pins.config, output)
        if guard.generated_seeds != pins.config["seeds"]:
            raise ValueError("runner did not generate the complete frozen confirmation seed set")
        pins.verify()
        outcome = {"status": "COMPLETED", "numpy_version": runner.np.__version__}
    except BaseException as error:
        outcome["error_type"] = type(error).__name__
        outcome["error"] = str(error)[:2048]
        raise
    finally:
        if runner is not None and original_generate is not None:
            runner.generate_dataset = original_generate
        outcome.update({
            "finished_at_utc": datetime.now(timezone.utc).isoformat(),
            "wrapper_and_campaign_wall_seconds": time.perf_counter() - start_wall,
            "wrapper_and_campaign_process_cpu_seconds": time.process_time() - start_cpu,
            "guard_passed": guard.passed if guard else False,
            "confirmation_seed_attempts": guard.attempted_seeds if guard else [],
            "confirmation_seeds_generated": guard.generated_seeds if guard else [],
            "boundary_guard_wall_seconds": guard.guard_wall_seconds if guard else 0.0,
            "boundary_guard_process_cpu_seconds": guard.guard_process_cpu_seconds if guard else 0.0,
        })
        write_new(receipts / "END.json", outcome)


if __name__ == "__main__":
    main()
