"""Guard checks against synthetic files and a stub generator, never real samples."""

from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest


SPEC = importlib.util.spec_from_file_location(
    "guarded_confirm", Path(__file__).with_name("guarded_confirm.py")
)
G = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(G)


class GuardTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.bundle = self.root / "bundle"
        source = self.bundle / "source/hepta_pred1"
        source.mkdir(parents=True)
        (source / "__init__.py").write_text("")
        (source / "run.py").write_text("raise AssertionError('archived source must never execute in guard tests')\n")
        self.source = source
        provenance = self.bundle / "provenance/independent-confirmation-002"
        provenance.mkdir(parents=True)
        self.config = {"selection_seeds": [11], "seeds": [101, 202],
                       "confirm_episodes": 3, "history_length": 16}
        self.config_path = provenance / "registered_config.json"
        self.config_path.write_text(G.canonical(self.config))
        basis = self.bundle / "provenance/train-dev-diagnostic-002/DIAGNOSTIC.json"
        basis.parent.mkdir(parents=True)
        basis.write_text('{"status":"synthetic training metadata only"}\n')
        files = {p.name: {"sha256": self.digest(p), "bytes": p.stat().st_size}
                 for p in sorted(source.glob("*.py"))}
        freeze = {
            "config": {"sha256": self.digest(self.config_path)},
            "source": {"files": files},
            "diagnostic_basis": {"sha256": self.digest(basis)},
            "models": ["single_step", "gru"],
            "expected_family_from_original_development": "gru",
        }
        freeze_path = provenance / "FREEZE.json"
        freeze_path.write_text(G.canonical(freeze))
        manifest = self.bundle / "MANIFEST.json"
        manifest.write_text('{"kind":"synthetic guard test inputs"}\n')
        source_identity = {name: row["sha256"] for name, row in files.items()}
        supplement = {
            "original_protocol_sha256": self.digest(freeze_path),
            "bundle_manifest_sha256": self.digest(manifest),
            "runner_source_identity_sha256": sha256(G.canonical(source_identity).encode()).hexdigest(),
            "independent_config_sha256": self.digest(self.config_path),
            "wrapper_sha256": self.digest(Path(G.__file__)),
        }
        self.pins = G.FrozenInputs(self.bundle, supplement)
        self.output = self.root / "campaign"
        self.receipts = self.root / "receipts"
        self.output.mkdir()
        self.receipts.mkdir()
        self.family = {
            "selected_family": "gru", "selection_seeds": [11],
            "evaluation_training_seeds": [101, 202],
            "frozen_before_evaluation_training": True,
        }
        checkpoint_pins = {}
        for seed in [11, 101, 202]:
            for variant in ["single_step", "gru"]:
                name = f"{variant}-{seed}.npz"
                # These are plain synthetic test bytes, never model weights.
                checkpoint = self.output / name
                checkpoint.write_bytes(f"synthetic placeholder {name}".encode())
                checkpoint_pins[name] = self.digest(checkpoint)
                record = {"seed": seed, "variant": variant, "checkpoint": name,
                          "checkpoint_sha256": checkpoint_pins[name]}
                (self.output / f"{variant}-{seed}-training.json").write_text(G.canonical(record))
        self.selection = {
            "selected_family": "gru", "independent_family_selection": self.family,
            "selected_before_confirmation_generation": True,
            "checkpoint_sha256": checkpoint_pins,
        }
        self.save_selection()
        self.calls = []
        self.sentinel = object()
        self.runner = SimpleNamespace(
            __file__=str(source / "run.py"),
            source_identity=lambda: self.pins.source_identity,
            VARIANTS={"single_step": None, "gru": None},
            generate_dataset=self.stub_generator,
        )

    def digest(self, path):
        return sha256(Path(path).read_bytes()).hexdigest()

    def save_selection(self):
        (self.output / "family-selection.json").write_text(G.canonical(self.family))
        (self.output / "selection.json").write_text(G.canonical(self.selection))

    def stub_generator(self, *args):
        self.calls.append(args)
        return self.sentinel

    def guard(self):
        return G.ConfirmationBoundaryGuard(self.pins, self.runner, self.output, self.receipts)

    def refused(self, expected):
        with self.assertRaisesRegex((ValueError, FileNotFoundError), expected):
            self.guard()(3, 101, "confirm", 16)
        self.assertEqual(self.calls, [])
        self.assertFalse((self.receipts / "CONFIRMATION_BOUNDARY.json").exists())

    def test_valid_boundary_passes_once_and_preserves_generator_return(self):
        guard = self.guard()
        self.assertIs(guard(3, 101, "confirm", 16), self.sentinel)
        self.assertIs(guard(3, 202, "confirm", 16), self.sentinel)
        self.assertEqual(self.calls, [(3, 101, "confirm", 16), (3, 202, "confirm", 16)])
        receipt = json.loads((self.receipts / "CONFIRMATION_BOUNDARY.json").read_text())
        self.assertEqual((receipt["checkpoint_count"], receipt["selected_family"],
                          receipt["confirmation_datasets_generated_before_guard"]), (6, "gru", 0))
        self.assertEqual(guard.generated_seeds, [101, 202])

    def test_train_and_development_are_exact_passthrough(self):
        guard = self.guard()
        self.assertIs(guard(5, 11, "train", 16), self.sentinel)
        self.assertIs(guard(3, 11, "dev", 16), self.sentinel)
        self.assertEqual(self.calls, [(5, 11, "train", 16), (3, 11, "dev", 16)])
        self.assertFalse(guard.passed)
        self.assertEqual(guard.generated_seeds, [])

    def test_unexpected_family_stops_before_first_generation(self):
        self.family["selected_family"] = self.selection["selected_family"] = "diag_ssm"
        self.save_selection()
        self.refused("family differs")

    def test_missing_checkpoint_pin_stops_before_first_generation(self):
        self.selection["checkpoint_sha256"].pop("gru-202.npz")
        self.save_selection()
        self.refused("all registered fit checkpoints")

    def test_changed_checkpoint_stops_before_first_generation(self):
        (self.output / "gru-202.npz").write_bytes(b"changed synthetic checkpoint")
        self.refused("pin mismatch")

    def test_training_record_must_bind_the_same_checkpoint(self):
        path = self.output / "gru-202-training.json"
        record = json.loads(path.read_text())
        record["checkpoint_sha256"] = "0" * 64
        path.write_text(G.canonical(record))
        self.refused("training record does not bind")

    def test_source_changed_after_startup_stops_before_first_generation(self):
        (self.source / "run.py").write_text("raise AssertionError('changed but never executed')\n")
        self.refused("pin mismatch")

    def test_added_python_source_stops_before_first_generation(self):
        (self.source / "new_code.py").write_text("# extra source\n")
        self.refused("inventory changed")

    def test_config_changed_after_startup_stops_before_first_generation(self):
        self.config_path.write_text(G.canonical({**self.config, "confirm_episodes": 4}))
        self.refused("pin mismatch")

    def test_in_memory_configuration_drift_stops_before_first_generation(self):
        self.pins.config["extra_setting"] = "unexpected"
        self.refused("in-memory configuration")

    def test_wrong_or_repeated_seed_is_refused_without_additional_generation(self):
        guard = self.guard()
        with self.assertRaisesRegex(ValueError, "seed order"):
            guard(3, 202, "confirm", 16)
        self.assertEqual(self.calls, [])
        guard(3, 101, "confirm", 16)
        with self.assertRaisesRegex(ValueError, "seed order"):
            guard(3, 101, "confirm", 16)
        self.assertEqual(len(self.calls), 1)

    def test_confirmation_dimension_change_is_refused(self):
        with self.assertRaisesRegex(ValueError, "dimensions"):
            self.guard()(4, 101, "confirm", 16)
        self.assertEqual(self.calls, [])

    def test_unfrozen_boundary_is_refused(self):
        self.selection["selected_before_confirmation_generation"] = False
        self.save_selection()
        self.refused("not recorded as frozen")


if __name__ == "__main__":
    unittest.main()
