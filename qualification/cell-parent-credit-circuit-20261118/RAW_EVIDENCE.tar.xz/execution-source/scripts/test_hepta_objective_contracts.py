#!/usr/bin/env python3
"""Regression guard for the single canonical Objective V1 wire definition."""

from __future__ import annotations

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(path: str):
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


class ObjectiveContractAlignmentTests(unittest.TestCase):
    def test_source_envelope_capacity_matches_native_lowering(self):
        registry = load("docs/readiness/PROTOCOLS.json")
        row = next(
            p for p in registry["protocols"] if p["id"] == "ObjectiveSourceEnvelopeV1"
        )
        intent = next(f for f in row["fields"] if f["name"] == "structuredIntent")
        fields = {f["name"]: f for f in intent["properties"]}
        self.assertEqual(
            (
                fields["legalActionClasses"]["minItems"],
                fields["legalActionClasses"]["maxItems"],
            ),
            (0, 128),
        )
        self.assertEqual(fields["confirmationActionClasses"]["maxItems"], 128)
        self.assertEqual(fields["constraints"]["maxItems"], 246)
        # Native lowering reserves one slot only when abstain is not explicit;
        # the admitted wire array still permits 128 entries including abstain.
        # The canonical protocol now records cross-field capacity as a compact
        # invariant instead of duplicating the same fact in an aggregateBounds
        # presentation object. Guard the actual invariant that the native
        # lowering relies on, not a redundant document shape.
        self.assertIn(
            "success_terminal_evidence_aggregate_max_128",
            row["invariants"],
        )

    def test_objective_semantics_do_not_redefine_wire_fields(self):
        schemas = load("docs/contracts/PROTOCOL_SCHEMAS.json")
        schema = next(
            p for p in schemas["protocols"] if p["id"] == "ObjectiveFunctionV1"
        )
        wire_fields = [field["name"] for field in schema["fields"]]

        objectives = load("docs/control-plane/OBJECTIVES.json")
        contract = objectives["objectiveFunctionContract"]
        self.assertEqual(contract["schema"], "ObjectiveFunctionV1")
        # registeredV1Fields is the compact semantic projection of the
        # canonical wire schema. Requiring a second fieldShapeAuthority string
        # and immutableWireFields copy only recreated the same source of truth.
        self.assertEqual(contract["registeredV1Fields"], wire_fields)
        self.assertIn("allowedActionClasses", contract["immutableCore"])
        self.assertIn("evidenceRequirements", contract["immutableCore"])
        self.assertIn("forbiddenActionClasses", contract["immutableCore"])
        self.assertFalse(set(contract["futureVersionOnly"]).intersection(wire_fields))
        self.assertNotIn("abstentionThreshold", contract["registeredV1Fields"])


if __name__ == "__main__":
    unittest.main()
