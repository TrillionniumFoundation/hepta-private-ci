set -eu
umask 077
printf 'IMAGE_DEFAULT_USER\n'
id
uname -a
printf 'PATH=%s\n' "$PATH"
for candidate in /usr/local/bin/ssh-keygen /usr/bin/ssh-keygen /bin/ssh-keygen /usr/sbin/ssh-keygen /sbin/ssh-keygen; do
    if test -e "$candidate"; then
        ls -ld "$candidate"
        readlink -f "$candidate"
    else
        printf 'MISSING=%s\n' "$candidate"
    fi
done
if command -v dpkg-query; then
    dpkg-query -W openssh-client libc6 || printf 'PACKAGE_QUERY_NONZERO=%s\n' "$?"
fi
resolved=$(command -v ssh-keygen || true)
printf 'RESOLVED_SSH_KEYGEN=%s\n' "$resolved"
if test -z "$resolved"; then
    printf 'PINNED_IMAGE_TOOL_MISSING\n'
    exit 20
fi
test -x "$resolved"
sha256sum "$resolved"
ldd "$resolved" > /tmp/keygen-ldd.txt
cat /tmp/keygen-ldd.txt
if grep -F 'not found' /tmp/keygen-ldd.txt; then exit 21; fi
mkdir /tmp/state
cd /tmp/state
"$resolved" -q -t ed25519 -N '' -f key
printf 'qualification ' > allowed_signers
cat key.pub >> allowed_signers
printf 'hepta-pinned-rbe-tool-observation-v1\n' > message
"$resolved" -Y sign -f key -n hepta-pinned-rbe message
"$resolved" -Y verify -f allowed_signers -I qualification -n hepta-pinned-rbe -s message.sig < message
printf 'changed-message\n' > changed
set +e
"$resolved" -Y verify -f allowed_signers -I qualification -n hepta-pinned-rbe -s message.sig < changed
refused=$?
set -e
test "$refused" -ne 0
printf 'CHANGED_MESSAGE_REFUSAL=%s\nPINNED_IMAGE_FIXTURE_PASS\n' "$refused"
