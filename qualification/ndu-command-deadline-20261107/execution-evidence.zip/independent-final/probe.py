import ctypes
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


ROOT = Path(__file__).parent
assert ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) == 0  # Reap our short probe descendants.

CHILD = r'''
import json, os, signal, subprocess, sys, time
from pathlib import Path
root = Path(sys.argv[1]); mode = sys.argv[2]
signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
if mode == "success":
    raise SystemExit(0)
grand_code = "import os,signal,sys,time; from pathlib import Path; signal.signal(signal.SIGTERM, signal.SIG_IGN); Path(sys.argv[1]).write_text(str(os.getpid())); time.sleep(20)"
grand = subprocess.Popen([sys.executable, "-c", grand_code, str(root / "grand.ready")])
deadline = time.monotonic() + 3
while not (root / "grand.ready").exists():
    if time.monotonic() > deadline: raise RuntimeError("grandchild did not start")
    time.sleep(.005)
(root / "pids.json").write_text(json.dumps({"leader": os.getpid(), "grandchild": grand.pid}))
(root / "ready").touch()
if mode == "leader_exit": raise SystemExit(0)
time.sleep(20)
'''

WRAPPER = r'''
import importlib.util, json, signal, sys
from pathlib import Path
root = Path(sys.argv[1]); mode = sys.argv[2]
spec = importlib.util.spec_from_file_location("review_meter", sys.argv[3]); meter = importlib.util.module_from_spec(spec); spec.loader.exec_module(meter)
def term(*_): pass
def intr(*_): pass
signal.signal(signal.SIGTERM, term); signal.signal(signal.SIGINT, intr)
command = [sys.executable, sys.argv[4], str(root), mode]
if mode == "spawn_failed": command = [str(root / "nonexistent-command")]
row = meter.execute(command, root / "receipt.json", wall_timeout_seconds=.6 if mode == "timeout" else 4, termination_grace_seconds=.2)
result = {"row": row, "handlers_restored": signal.getsignal(signal.SIGTERM) is term and signal.getsignal(signal.SIGINT) is intr, "receipt_matches_returned_row": json.loads((root / "receipt.json").read_text()) == row}
(root / "result.json").write_text(json.dumps(result, indent=2) + "\n")
raise SystemExit(row["return_code"] if row["return_code"] >= 0 else 128 - row["return_code"])
'''

(ROOT / "child.py").write_text(CHILD)
(ROOT / "wrapper.py").write_text(WRAPPER)


def state(pid):
    try:
        return Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[0]
    except FileNotFoundError:
        return "absent"


def reap():
    while True:
        try:
            pid, _ = os.waitpid(-1, os.WNOHANG)
            if pid == 0:
                return
        except ChildProcessError:
            return


results = []
cases = [("success", None, False), ("timeout", None, False), ("cancel_term", signal.SIGTERM, False), ("cancel_int", signal.SIGINT, False), ("cancel_twice", signal.SIGTERM, True), ("leader_exit", None, False), ("spawn_failed", None, False)]
for name, cancellation, twice in cases:
    case = ROOT / name
    case.mkdir()
    mode = name if name in {"success", "timeout", "leader_exit", "spawn_failed"} else "cancel"
    proc = subprocess.Popen([sys.executable, str(ROOT / "wrapper.py"), str(case), mode, str(ROOT / "review_meter.py"), str(ROOT / "child.py")], start_new_session=True, stdout=subprocess.DEVNULL, stderr=(case / "stderr.log").open("w"))
    try:
        if cancellation:
            deadline = time.monotonic() + 3
            while not (case / "ready").exists():
                if proc.poll() is not None or time.monotonic() > deadline:
                    raise RuntimeError(f"{name}: no ready marker")
                time.sleep(.005)
            proc.send_signal(cancellation)
            if twice:
                time.sleep(.03)
                proc.send_signal(cancellation)
        code = proc.wait(timeout=6)
        result = json.loads((case / "result.json").read_text())
        pids = json.loads((case / "pids.json").read_text()) if (case / "pids.json").exists() else {}
        process_states = {key: state(pid) for key, pid in pids.items()}
        row = result["row"]
        expected = {"success": ("completed", 0), "timeout": ("timed_out", 124), "cancel_term": ("cancelled", 143), "cancel_int": ("cancelled", 130), "cancel_twice": ("cancelled", 143), "leader_exit": ("failed", 1), "spawn_failed": ("failed", 1)}[name]
        checks = {"expected_status_code": (row["status"], code) == expected, "handlers_restored": result["handlers_restored"], "receipt_matches_returned_row": result["receipt_matches_returned_row"], "no_live_inherited_descendants": all(s in {"absent", "Z"} for s in process_states.values()), "logical_failure_not_leader_zero": name not in {"timeout", "cancel_term", "cancel_int", "cancel_twice", "leader_exit"} or row["return_code"] != 0, "unknown_descendant_usage_marked": not pids or "descendant_usage_not_reaped_by_command_leader" in row["unknown_outer_costs"]}
        summary = {"name": name, "exit_code": code, "status": row["status"], "child_return_code": row["child_return_code"], "checks": checks, "process_states_before_reap": process_states, "termination": row.get("termination"), "wall_seconds": row["wall_seconds"]}
        results.append(summary)
        print(json.dumps(summary), flush=True)
    finally:
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait()
        if (case / "pids.json").exists():
            for pid in json.loads((case / "pids.json").read_text()).values():
                if state(pid) not in {"absent", "Z"}:
                    os.kill(pid, signal.SIGKILL)
        time.sleep(.03)
        reap()

report = {"meter_sha256": hashlib.sha256((ROOT / "review_meter.py").read_bytes()).hexdigest(), "cases": results, "all_checks_passed": all(all(r["checks"].values()) for r in results)}
(ROOT / "probe-results.json").write_text(json.dumps(report, indent=2) + "\n")
raise SystemExit(0 if report["all_checks_passed"] else 1)
