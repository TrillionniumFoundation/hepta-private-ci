
import importlib.util, json, signal, sys
from pathlib import Path
root = Path(sys.argv[1]); mode = sys.argv[2]
spec = importlib.util.spec_from_file_location("review_meter", sys.argv[3]); meter = importlib.util.module_from_spec(spec); spec.loader.exec_module(meter)
def term(*_): pass
def intr(*_): pass
signal.signal(signal.SIGTERM, term); signal.signal(signal.SIGINT, intr)
command = [sys.executable, sys.argv[4], str(root), mode]
if mode == "spawn_failed": command = [str(root / "nonexistent-command")]
row = meter.execute(command, root / "receipt.json", wall_timeout_seconds=.6 if mode == "timeout" else 4, termination_grace_seconds=.2)
result = {"row": row, "handlers_restored": signal.getsignal(signal.SIGTERM) is term and signal.getsignal(signal.SIGINT) is intr, "receipt_matches_returned_row": json.loads((root / "receipt.json").read_text()) == row}
(root / "result.json").write_text(json.dumps(result, indent=2) + "\n")
raise SystemExit(row["return_code"] if row["return_code"] >= 0 else 128 - row["return_code"])
