
import json, os, signal, subprocess, sys, time
from pathlib import Path
root = Path(sys.argv[1]); mode = sys.argv[2]
signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
if mode == "success":
    raise SystemExit(0)
grand_code = "import os,signal,sys,time; from pathlib import Path; signal.signal(signal.SIGTERM, signal.SIG_IGN); Path(sys.argv[1]).write_text(str(os.getpid())); time.sleep(20)"
grand = subprocess.Popen([sys.executable, "-c", grand_code, str(root / "grand.ready")])
deadline = time.monotonic() + 3
while not (root / "grand.ready").exists():
    if time.monotonic() > deadline: raise RuntimeError("grandchild did not start")
    time.sleep(.005)
(root / "pids.json").write_text(json.dumps({"leader": os.getpid(), "grandchild": grand.pid}))
(root / "ready").touch()
if mode == "leader_exit": raise SystemExit(0)
time.sleep(20)
