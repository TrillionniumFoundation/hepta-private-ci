"""Isolated control-flow probe. No host access, publication, training or model execution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/5bdf905e9cad/hepta-science-refresh/qualification/hcsn_sustained_20261128/mosi_recovery/publish_mosi.py')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    spec = importlib.util.spec_from_file_location('pinned_mosi_publisher_probe', SOURCE)
    publisher = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(publisher)
    assert sha(HERE / 'pinned_publish_results.py') == publisher.HELPER_SHA
    records = []
    for case in ('invalid-json', 'wrong-scope-receipt'):
        with tempfile.TemporaryDirectory(prefix='mosi-completion-probe-', dir=HERE) as temp:
            task = Path(temp)
            helper = task / 'provider'
            helper.mkdir()
            shutil.copyfile(HERE / 'pinned_publish_results.py', helper / 'publish_results.py')
            shutil.copyfile(HERE / 'pinned_archive.py', helper / 'archive.py')
            publisher.SHARED = str(helper / 'publish_results.py')
            destination = task / 'publication'
            destination.mkdir()
            body = 'not JSON\n' if case == 'invalid-json' else json.dumps({
                'kind': 'foreign-result', 'branch': 'foreign-branch', 'commit': '0'*40,
                'repo_prefix': 'wrong/', 'file_count': 0, 'manifest_sha256': '0'*64,
            })
            for kind in ('mosi_recovery_raw', 'mosi_fresh_raw'):
                (destination / (kind + '-receipt.json')).write_text(body)
            calls = dict(recovery_validation=0, fresh_validation=0, subprocess_or_network=0)

            def forbidden_process(*args, **kwargs):
                calls['subprocess_or_network'] += 1
                raise AssertionError('No subprocess, host access or remote publication is permitted in this probe')

            def recovery_guard(*args, **kwargs):
                calls['recovery_validation'] += 1
                raise AssertionError('A source validation was reached; no source objects are present')

            def fresh_guard(*args, **kwargs):
                calls['fresh_validation'] += 1
                raise AssertionError('A source validation was reached; no source objects are present')

            original_run = subprocess.run
            original_recovery = publisher.recovery_map
            original_fresh = publisher.fresh_map
            prior_archive = sys.modules.pop('archive', None)
            start = time.monotonic()
            try:
                subprocess.run = forbidden_process
                publisher.recovery_map = recovery_guard
                publisher.fresh_map = fresh_guard
                result = publisher.run(task)
            finally:
                subprocess.run = original_run
                publisher.recovery_map = original_recovery
                publisher.fresh_map = original_fresh
                sys.modules.pop('archive', None)
                if prior_archive is not None:
                    sys.modules['archive'] = prior_archive
                sys.path[:] = [value for value in sys.path if value != str(helper)]
            assert result is None and not any(calls.values())
            records.append(dict(case=case, publisher_returned_normally=True,
                                no_source_or_prediction_objects_present=True,
                                calls=calls, wall_seconds=time.monotonic()-start))
    report = dict(
        source_commit='7caa89806980928b6adc29893da33f1827e7099b',
        source_sha256=sha(SOURCE), helper_sha256=sha(HERE / 'pinned_publish_results.py'),
        helper_matches_original_declared_pin=True,
        helper_archive_import_sha256=sha(HERE / 'pinned_archive.py'),
        probe_sha256=sha(Path(__file__)), cases=records,
        fixture_scope='Controlled invalid completion receipts in temporary local directories; provider file path redirected to byte-identical pinned helper. All validators and subprocess/network paths trapped. No original files or live host touched.',
        result='run() treats receipt-path existence as sufficient to skip each entire scope; neither receipt JSON nor source/remote objects are revalidated on resume.',
        limitation='This demonstrates a resume-validation gap. It does not show that the actual operator host has corrupt receipts or establish why the fresh result directory is absent in the fixed result branch.',
    )
    (HERE / 'COMPLETION_GUARD_PROBE.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
