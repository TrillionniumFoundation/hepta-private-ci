"""Run the unchanged unittest suite and retain a bounded, local-only transport trace."""
import json
from pathlib import Path
import resource
import sys
import time
import unittest

work=Path(sys.argv[1]);output=Path(sys.argv[2]);records=[]
class RecordingResult(unittest.TextTestResult):
    def stopTest(self,test):
        records.append({
            "test":test.id(),
            "source_validator_calls":[m.call_count for m in getattr(test,"map_calls",[])],
            "mock_publisher_scopes":[call.args[0] for call in getattr(getattr(test,"push",None),"call_args_list",[])],
            "local_git_backed_api_calls":[list(call.args[:2]) for call in getattr(getattr(test,"api",None),"call_args_list",[])],
            "native_readback_git_commands":getattr(test,"git_calls",[]),
        })
        super().stopTest(test)
suite=unittest.defaultTestLoader.discover(str(work/"qualification/hcsn_sustained_20261128/mosi_recovery"),pattern="test_publish_mosi.py")
started=time.monotonic()
result=unittest.TextTestRunner(verbosity=2,resultclass=RecordingResult).run(suite)
doc={"tests_run":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped),
     "successful":result.wasSuccessful(),"elapsed_seconds":time.monotonic()-started,
     "self_peak_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
     "children_peak_rss_kib":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
     "scope":"GitHub API transport is replaced by a reader over actual local Git objects. Native fallback invokes actual git init/remote/fetch/rev-parse/ls-tree against the temporary local Git origin. Publisher calls are mocks. No remote network or model execution.",
     "records":records}
(output/"control_trace.json").write_text(json.dumps(doc,indent=2)+"\n")
raise SystemExit(0 if result.wasSuccessful() else 1)
