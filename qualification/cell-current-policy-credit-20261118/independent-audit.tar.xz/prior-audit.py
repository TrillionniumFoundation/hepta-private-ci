"""Independent read-only audit of retained model calls and original verifier receipts.
No model loading, generation, verifier execution, or score mutation is performed.
"""
import base64, collections, hashlib, json, pathlib, subprocess, time
ROOT = pathlib.Path("/home/qian-qi/work/hepta-e2-current-credit-20261118-2e9b")
DEST = pathlib.Path("/home/qian-qi/work/hepta-e4-matched-upstream-20261118-2e9b/b2-independent-audit-1")
EXPECTED = {
 "NoUpdate": "430f4051d47672d121a5d790aca0e489804b0d8419c101e3c1171b3d17157786",
 "all_observed": "0585075a5277f7e8e5a7b7ad3f42bc718f17253f1dbf6c2b03e8248cfc1c1562",
 "verified_credit": "785bc1cea2996e33cfe02c9c51a5a3802c931b010060369fc659b47fde4440a1",
}
VERIFIER = "64fcc25e4ccf82f31c2549f5d4c1a5c4af1831c5bed4219c0aac2283b213a020"
GENERATION = "e31715a80c7c2d6fb35843583b19931ec955723cba8366472ed48b461514e3eb"
def sha(value):
 return hashlib.sha256(value).hexdigest()
def canonical(value):
 return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()
def digest(value):
 return sha(canonical(value))
index = {}
def read(path):
 raw = path.read_bytes()
 index[str(path)] = {"bytes":len(raw), "sha256":sha(raw)}
 return json.loads(raw)
def published(path, expected):
 ref="1134793c60c1b9908eaf6e388f753860ee8917c4"
 response=json.loads(subprocess.check_output(["gh","api",f"repos/TrillionniumFoundation/hepta-private-ci/contents/{path}?ref={ref}"]))
 raw=base64.b64decode(response["content"],validate=False)
 assert sha(raw)==expected, (path,sha(raw))
 assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==response["sha"]
 (DEST/path.rsplit("/",1)[-1]).write_bytes(raw)
 return raw
def add_cost(target, output, receipt):
 target["model_calls"]+=1
 target["verifier_calls"]+=1
 target["input_tokens"]+=output["input_tokens"]
 target["output_tokens"]+=output["output_tokens"]
 target["generation_wall_seconds"]+=output["wall_seconds"]
 target["verifier_wall_seconds"]+=receipt["result"].get("wall_ns",0)/1e9
 target["business_verifier_executions"]+=int(receipt["result"].get("executed",False))
 target["format_rejections"]+=int(not receipt["result"].get("executed",False))
 target["output_limit_hits"]+=int(output["hit_output_limit"])
 target["observed_subject_calls"]+=sum(len(o["calls"]) for o in receipt["result"].get("result",{}).get("observations",[]))
def new_cost():
 return dict(model_calls=0,verifier_calls=0,input_tokens=0,output_tokens=0,generation_wall_seconds=0.0,verifier_wall_seconds=0.0,business_verifier_executions=0,format_rejections=0,output_limit_hits=0,observed_subject_calls=0)
def main():
 records_raw=published("qualification/cell-blind-panel-b2-20261118/prepared/records.jsonl","26b2e625c649a73a991c681bb1949cdaf91b995d8e4bc3402b924495797d42cb")
 records=[json.loads(x) for x in records_raw.splitlines() if x]
 by_id={r["record_id"]:r for r in records}
 assert len(records)==len(by_id)==6
 release=json.loads(published("qualification/cell-blind-panel-b2-20261118/RELEASE.json","8dfa14870f674808e91be0fc204464a9f6d7de0db4a653bc45bb3a2f4820c3f4"))
 frozen=read(ROOT/"retained/WEIGHTS_FROZEN.json")
 assert index[str(ROOT/"retained/WEIGHTS_FROZEN.json")]["sha256"]=="dabd5f13f8cc7392e8eb8b8eccbe1fd30dcc4da381d31a51e70818d255bc3bcd"
 freeze_ns=frozen["created_at_ns"] if "created_at_ns" in frozen else frozen["created_ns"]
 release_ns=release["released_at_ns"]
 assert freeze_ns < release_ns
 for arm in ("all_observed","verified_credit"):
  path=ROOT/"retained/training"/arm/"manifest.json"
  read(path)
  assert index[str(path)]["sha256"]==frozen["arms"][arm]["manifest_sha256"]
  assert frozen["arms"][arm]["model_digest"]==EXPECTED[arm]
 summary={}
 calls=[]
 tasks=[]
 first_requests={}
 total=new_cost()
 for arm, model in EXPECTED.items():
  arm_root=ROOT/"retained/evaluation"/arm
  result_paths=sorted(arm_root.glob("*/*/RESULT.json"))
  assert len(result_paths)==18,(arm,len(result_paths))
  arm_summary={}
  for result_path in result_paths:
   folder=result_path.parent
   panel=folder.parent.name
   original=read(folder/"ORIGINAL_RECORD.json")
   result=read(result_path)
   record_id=original["record_id"]
   if panel=="B2_blind_future":
    assert original==by_id[record_id], ("B2 record mismatch",arm,record_id)
    assert original["authorization"]["training_allowed"] is False
   task_summary=arm_summary.setdefault(panel,{"tasks":0,"first":0,"final":0,"selected":0,"recoveries":0,"regressions":0,"retained_successes":0,"cost":new_cost()})
   assert result["task_id"]==original["task_id"]
   assert result["panel"]==panel
   assert len(result["steps"])==2
   raw_outputs=[]; receipts=[]; requests=[]
   for attempt in (0,1):
    request=read(folder/f"REQUEST-{attempt}.json")
    output=read(folder/f"OUTPUT-{attempt}.json")
    receipt=read(folder/f"VERIFICATION-{attempt}.json")
    step=result["steps"][attempt]
    assert step["attempt"]==attempt
    assert step["request_digest"]==digest(request)
    assert step["output_digest"]==digest(output)
    assert step["verification"]==receipt
    assert request["record_id"]==record_id
    assert request["task"]["input"]==original["task"]["input"]
    assert output["loaded_model_digest"]==model
    assert output["generation_config_sha256"]==GENERATION
    assert output["message_protocol"]=="native_chat_v2"
    assert output["max_new_tokens"]==384
    assert output["output_tokens"]==len(output["output_token_ids"])
    assert output["messages_sha256"]==digest(request["task"]["messages"])
    assert output["input_sha256"]==sha(request["task"]["input"].encode())
    assert output["rendered_input_sha256"]==output["rendered_prompt_sha256"]
    assert output["started_at_ns"]<output["completed_at_ns"]
    if panel=="B2_blind_future": assert output["started_at_ns"]>release_ns
    assert output["external_effect_executed"] is False
    assert receipt["record_id"]==record_id
    assert receipt["input_sha256"]==sha(original["task"]["input"].encode())
    assert receipt["answer_sha256"]==sha(output["answer"].encode())
    assert receipt["parameters_sha256"]==digest(original["task"]["verifier"]["parameters"])
    assert receipt["verifier"]==["repo_patch","1"]
    assert receipt["verifier_source_sha256"]==VERIFIER
    receipt_core={k:v for k,v in receipt.items() if k not in ("receipt_sha256","success")}
    assert receipt["receipt_sha256"]==digest(receipt_core)
    assert receipt["success"]==receipt["result"]["success"]
    assert receipt["production_eligible"] is False
    verification=receipt["result"]
    if verification.get("executed"):
     business=verification["result"]
     observations=business["observations"]
     original_obs=[o for o in observations if o["control"]=="original"]
     controls=[o for o in observations if o["control"]!="original"]
     assert len(original_obs)==1 and len(controls)==2
     assert business["original_passed"]==original_obs[0]["passed"]
     rejected=sum(not o["passed"] for o in controls)
     assert business["control_count"]==2
     assert business["controls_rejected"]==rejected
     assert receipt["success"]==(original_obs[0]["passed"] and rejected==2)
    else:
     assert receipt["success"] is False
    for key in ("input_tokens","output_tokens","wall_seconds","hit_output_limit"):
     assert step["model_call_cost"][key]==output[key]
    if attempt==0:
     assert request["task"]["messages"]==original["task"]["messages"]
     key=(panel,record_id)
     if key in first_requests: assert first_requests[key]==request
     else:first_requests[key]=request
    else:
     assert request["task"]["messages"][:-2]==requests[0]["task"]["messages"]
     assert request["task"]["messages"][-2]=={"role":"assistant","content":raw_outputs[0]["answer"]}
     assert request["task"]["messages"][-1]["role"]=="tool"
     feedback=json.loads(request["task"]["messages"][-1]["content"])
     assert feedback["success"]==receipts[0]["success"]
     assert feedback["reason"]==receipts[0]["result"]["reason"]
     assert feedback["execution_performed"]==receipts[0]["result"].get("executed",False)
     assert feedback["next_attempt_resets_template"] is True
    raw_outputs.append(output); receipts.append(receipt); requests.append(request)
    add_cost(task_summary["cost"],output,receipt);add_cost(total,output,receipt)
    calls.append({"arm":arm,"panel":panel,"record_id":record_id,"attempt":attempt,"request_sha256":index[str(folder/f"REQUEST-{attempt}.json")]["sha256"],"output_sha256":index[str(folder/f"OUTPUT-{attempt}.json")]["sha256"],"verifier_sha256":index[str(folder/f"VERIFICATION-{attempt}.json")]["sha256"],"model":model,"success":receipt["success"],"executed":verification.get("executed",False),"input_tokens":output["input_tokens"],"output_tokens":output["output_tokens"],"generation_wall_seconds":output["wall_seconds"],"verifier_wall_ns":verification.get("wall_ns",0),"reason":verification["reason"]})
   first,last=[v["success"] for v in receipts]
   calculated={"first":first,"last":last,"selected":first or last,"recovered":not first and last,"regressed":first and not last}
   for key,value in calculated.items(): assert result[key]==value,(arm,panel,record_id,key)
   task_summary["tasks"]+=1
   task_summary["first"]+=first
   task_summary["final"]+=last
   task_summary["selected"]+=first or last
   task_summary["recoveries"]+=not first and last
   task_summary["regressions"]+=first and not last
   task_summary["retained_successes"]+=first and last
   tasks.append({"arm":arm,"panel":panel,"record_id":record_id,**calculated,"answers":[o["answer"] for o in raw_outputs],"reasons":[v["result"]["reason"] for v in receipts]})
  assert arm_summary["B2_blind_future"]["tasks"]==6
  assert all(p["tasks"]==6 for p in arm_summary.values())
  summary[arm]=arm_summary
 assert len(calls)==108 and total["model_calls"]==108
 audit={"schema":"hepta.independent-retained-call-audit.v1","status":"PASS","created_at_ns":time.time_ns(),"scope":"Original retained requests, outputs and verifier receipts; no new model or verifier executions","record_source_commit":"1134793c60c1b9908eaf6e388f753860ee8917c4","records_sha256":sha(records_raw),"weights_frozen_ns":freeze_ns,"released_at_ns":release_ns,"NoUpdate_is_previously_trained_parent":EXPECTED["NoUpdate"],"summary":summary,"total_call_cost":total,"extra_model_calls":0,"extra_verifier_calls":0,"energy_and_currency_cost":"unmeasured","limits":["Public source may occur in pretraining","Six B2 functions from three projects, not authenticated user sources","No full-repository integration or production eligibility","Generation and verifier durations exclude model initialization; do not substitute for owner elapsed cost"]}
 (DEST/"AUDIT.json").write_bytes(canonical(audit)+b"\n")
 (DEST/"CALLS.json").write_bytes(canonical(calls)+b"\n")
 (DEST/"TASKS.json").write_bytes(canonical(tasks)+b"\n")
 (DEST/"INPUT_INDEX.json").write_bytes(canonical(index)+b"\n")
 print(json.dumps(audit,indent=2))
 print(json.dumps({"outputs":{p.name:{"sha256":sha(p.read_bytes()),"bytes":p.stat().st_size} for p in DEST.iterdir() if p.is_file()}},indent=2))
if __name__=="__main__":
 try:main()
 except Exception as error:
  (DEST/"AUDIT_FAILURE.json").write_text(json.dumps({"exception":type(error).__name__,"message":str(error),"at_ns":time.time_ns()},indent=2)+"\n")
  raise
