"""Read-only MEM3 evidence reconstruction; imports no actor/evaluator code."""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import random


def enc(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def valid(facts, source, version, tick, wanted=None, seen=()):
    fact = facts.get(source)
    if fact is None:
        return "unknown"
    if source in seen:
        return "dependency_cycle"
    if not fact["live"]:
        return "revoked"
    if tick > fact["expires"]:
        return "expired"
    if version != fact["version"] or wanted is not None and wanted != version:
        return "version"
    for parent, parent_version in fact["dependencies"]:
        if valid(facts, parent, parent_version, tick, seen=(*seen, source)) is not None:
            return "dependency"
    return None


def traverse(task, facts, tick, steps=None):
    if len(task["program"]) > task["budget"]:
        require(steps is None or not steps, "budget-abstained task has raw steps")
        return None, "constraint_budget"
    node, used = task["start"], 0
    for relation in task["program"]:
        source = f"{relation}:{node}"
        if source not in facts:
            require(steps is None or used == len(steps), "unknown source has extra steps")
            return None, "unknown"
        if steps is None:
            value, version = facts[source]["value"], facts[source]["version"]
        else:
            require(used < len(steps), "missing raw prediction")
            row = steps[used]
            require(row["source"] == source, "prediction path differs from preceding output")
            value, version = row["value"], row["version"]
            require(type(value) is int and 0 <= value < 8, "bad primitive label")
            require(type(version) is int, "bad version")
        reason = valid(facts, source, version, tick, task.get("required_versions", {}).get(source))
        if steps is not None:
            require(row["gate"] == reason and type(row["used"]) is bool and row["used"] == (reason is None), "incorrect gate receipt")
        used += 1
        if reason is not None:
            require(steps is None or used == len(steps), "steps continued after gate")
            return None, reason
        node = value
    require(steps is None or used == len(steps), "extra predictions")
    if "allowed_end" in task and node not in task["allowed_end"]:
        return None, "constraint_endpoint"
    return node, None


def score(stage, tasks, rows):
    require([r["task_id"] for r in rows] == [t["task_id"] for t in tasks], "task denominator/order")
    facts = {f["source"]: f for f in stage["facts"]}
    total, families, truth = Counter(), defaultdict(Counter), []
    for task, row in zip(tasks, rows):
        for step in row["steps"]:
            require(step["source"] in facts and step["version"] == facts[step["source"]]["version"], "raw version differs from the fixed current-version reader")
        predicted, reason = traverse(task, facts, stage["tick"], row["steps"])
        require(row["value"] == predicted and row["abstain_reason"] == reason, "terminal answer not derived from raw steps")
        expected, _ = traverse(task, facts, stage["tick"])
        count = Counter(tasks=1, joint_correct=int(predicted == expected),
                        answerable=int(expected is not None), answered=int(predicted is not None),
                        answerable_correct=int(expected is not None and predicted == expected),
                        wrong_assertions=int(predicted is not None and predicted != expected),
                        invalid_terminal_assertions=int(predicted is not None and expected is None),
                        unknown_abstentions=int(reason == "unknown"),
                        gate_abstentions=int(reason not in (None, "unknown")), raw_predictions=0,
                        raw_errors=0, raw_valid_predictions=0, raw_valid_errors=0,
                        used_sources=0, invalid_used_sources=0, revoked_used_sources=0)
        for step in row["steps"]:
            safe = valid(facts, step["source"], step["version"], stage["tick"], task.get("required_versions", {}).get(step["source"])) is None
            wrong = step["value"] != facts[step["source"]]["value"]
            count.update(raw_predictions=1, raw_errors=int(wrong), raw_valid_predictions=int(safe),
                         raw_valid_errors=int(safe and wrong), used_sources=int(step["used"]),
                         invalid_used_sources=int(step["used"] and not safe),
                         revoked_used_sources=int(step["used"] and not facts[step["source"]]["live"]))
        total.update(count)
        families[task["family"]].update(count)
        truth.append({"task_id": task["task_id"], "expected": expected, "correct": predicted == expected})
    return {"counts": dict(total), "families": {k: dict(v) for k, v in families.items()}, "truth": truth}


def audit_native(directory, stage, features, seed, rows, cost):
    trace = [json.loads(s) for s in (directory / "native.jsonl").read_text().splitlines()]
    require(len(trace) % 2 == 0, "unmatched native attempt")
    receipts = []
    for a, b in zip(trace[::2], trace[1::2]):
        require(a["event"] == "attempt" and b["event"] == "receipt" and a["request"] == b["request"], "native attempt/receipt mismatch")
        receipts.append(b)
    require(len(receipts) == cost["native_calls"], "native call accounting")
    require(sum(len((r["request"] + "\n").encode()) for r in receipts) == cost["native_request_bytes"], "native request byte accounting")
    require(receipts[0]["request"] == f"new cell:mem3:{seed}:{stage['generation']} scope:mem1 {stage['generation']} 16 8 0.5 1", "wrong native owner/config")
    expected_commands = [receipts[0]["request"]]
    facts = {f["source"]: f for f in stage["facts"]}
    order = [f for f in stage["facts"] if valid(facts, f["source"], f["version"], stage["tick"]) is None] * 8
    random.Random(seed * 101 + stage["generation"]).shuffle(order)
    updates = [r for r in receipts if r["request"].startswith("update ") and r["status"] == "completed"]
    require(len(updates) == len(order) == cost["native_updates"], "update denominator")
    for sequence, (fact, receipt) in enumerate(zip(order, updates), 1):
        key = features[fact["source"]]
        support = sha(enc({"generation": stage["generation"], "fact": fact, "key": key}))
        target = [float(i == fact["value"]) for i in range(8)]
        command = f"update {stage['generation']} {support} " + ",".join(map(repr, key)) + " " + ",".join(map(repr, target))
        expected_commands.append(command)
        require(receipt["request"] == command and receipt["reply"][0] == "U" and int(receipt["reply"][3]) == sequence, "update differs from frozen fixture/order")
    expected_commands.append("checkpoint")
    require(sum(len(enc({"fact": f, "key": features[f["source"]]})) for f in order) == cost["replay_payload_bytes"], "replay payload byte accounting")
    predictions = [r for r in receipts if r["request"].startswith("predict ") and r["status"] == "completed"]
    steps = [s for row in rows for s in row["steps"]]
    require(len(predictions) == len(steps) == cost["native_predictions"], "native prediction denominator")
    for step, receipt in zip(steps, predictions):
        command = f"predict {stage['generation']} " + ",".join(map(repr, features[step["source"]]))
        expected_commands.append(command)
        require(receipt["request"] == command, "prediction does not use its own source feature")
        values = [float(v) for v in receipt["reply"][3].split(",")]
        require(receipt["reply"][0] == "P" and len(values) == 8 and all(map(math.isfinite, values)), "bad raw native scores")
        require(max(range(8), key=values.__getitem__) == step["value"], "task prediction differs from native reply")
    multiplications = sum(int(r["reply"][2]) for r in receipts if r["status"] == "completed" and r["reply"][0] in ("P", "U"))
    require(multiplications == cost["native_multiplications"], "kernel work accounting")
    checkpoints = [r["reply"] for r in receipts if r["request"] == "checkpoint"]
    for cp in checkpoints:
        require(cp[0] == "C" and sha(bytes.fromhex(cp[2])) == cp[1], "checkpoint witness")
    require(bytes.fromhex(checkpoints[0][2]) == (directory / "state.bin").read_bytes(), "saved state differs from native checkpoint")
    versions = {f["source"]: f["version"] for f in stage["facts"]}
    require(len(bytes.fromhex(checkpoints[0][2])) + len(enc({"features": features, "versions": versions})) == cost["stored_payload_bytes"], "stored state accounting")
    failed = [r for r in receipts if r["status"] != "completed"]
    if stage["phase"] == "base":
        require(len(failed) == 2 and len(checkpoints) == 3 and checkpoints[0] == checkpoints[1] == checkpoints[2], "cross-cut diagnostics changed state or disappeared")
        key = ",".join(map(repr, features["A:0"]))
        diagnostic_commands = [f"predict 2 {key}", f"update 2 {'1' * 64} {key} 1,0,0,0,0,0,0,0"]
        expected_commands += ["checkpoint", *diagnostic_commands, "checkpoint"]
        require([r["request"] for r in failed] == diagnostic_commands, "wrong cross-cut requests")
        error_text = "ERR\tSnapshotMismatch"
        require(all(r["error"] == repr(ValueError(error_text)) for r in failed), "cross-cut failure was not snapshot mismatch")
        diagnosis = read(directory / "transition.json")
        require(diagnosis == {"records": [{"command": c, "rejected": True, "error": error_text} for c in diagnostic_commands], "checkpoint_unchanged": True, "before": checkpoints[1][1], "after": checkpoints[2][1]}, "transition summary disagrees with raw trace")
    else:
        require(not failed and len(checkpoints) == 1, "unexpected native failure")
    require([r["request"] for r in receipts] == expected_commands, "native command chronology differs or has extra work")
    require(all(r["status"] == "completed" for r in receipts if r not in failed), "incomplete non-diagnostic native work")
    return {"requests": len(receipts), "transition_rejections": len(failed), "updates": len(updates), "predictions": len(predictions)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--campaign", type=Path, required=True)
    parser.add_argument("--fixture", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    fixture, manifest = read(args.fixture), read(args.campaign / "manifest.json")
    require(sha(args.fixture.read_bytes()) == manifest["fixture_sha256"] == "36e8ec0047f3ec795a3d3828d9bdfa2d0f41063c4dbbccf3eeb9446e0c966a13", "fixture identity")
    require(manifest["native_sha256"] == "e8b95e5b88bfbbdd962812d800f2617daa924aa237dcdeba45b71697cad0713d", "native binary identity")
    for path, digest in manifest["source_sha256"].items():
        require(sha((args.sources / path).read_bytes()) == digest, f"executed source identity: {path}")
    planned = [(s, p, a) for s in range(5) for p in ("base", "version", "revoke", "expiry") for a in ("exact", "bm25", "native")]
    roster = read(args.campaign / "roster.json")
    require([(r["seed"], r["phase"], r["arm"]) for r in roster] == planned and all(r["status"] == "completed" for r in roster), "complete trial denominator")
    require(len(fixture["tasks"]) == 64 and manifest["planned_tasks"] == 3840 and manifest["planned_trials"] == 60, "planned task denominator")
    by_stage, by_seed, by_arm, by_family, costs, audit = (defaultdict(Counter) for _ in range(6))
    for stream in fixture["streams"]:
        for stage in stream["stages"]:
            for arm in ("exact", "bm25", "native"):
                name = f"seed-{stream['seed']}-{stage['phase']}-{arm}"
                directory = args.campaign / name
                task_roster = read(directory / "task-roster.json")
                require([r["task_id"] for r in task_roster] == [t["task_id"] for t in fixture["tasks"]] and all(r["status"] == "completed" for r in task_roster), "complete task roster: " + name)
                rows = [json.loads(s) for s in (directory / "tasks.jsonl").read_text().splitlines()]
                result = read(directory / "result.json")
                require((result["seed"], result["phase"], result["arm"]) == (stream["seed"], stage["phase"], arm), "mislabelled trial identity")
                evaluation = score(stage, fixture["tasks"], rows)
                require(evaluation == result["evaluation"], "independent evaluation differs: " + name)
                count, cost = evaluation["counts"], result["cost"]
                require(type(result["wall_ns"]) is int and result["wall_ns"] >= 0 and all(type(v) is int and v >= 0 for v in cost.values()), "invalid observed cost or timing")
                require(cost["provided_information_bytes"] == len(enc({"stage": stage, "features": stream["features"]})), "same input bytes")
                meta = {f["source"]: {k: v for k, v in f.items() if k != "value"} for f in stage["facts"]}
                require(cost["owner_metadata_bytes"] == len(enc(meta)), "value-blind metadata bytes")
                require(all(cost[k] == 0 for k in ("teacher_calls", "teacher_bytes", "teacher_multiplications")), "unexpected teacher work")
                if arm == "native":
                    audit[arm].update(audit_native(directory, stage, stream["features"], stream["seed"], rows, cost))
                    require(cost["retrieval_calls"] == cost["retrieval_candidates_scored"] == cost["retrieval_payload_bytes"] == 0, "native retrieval contamination")
                else:
                    steps = [s for row in rows for s in row["steps"]]
                    facts = {f["source"]: f if arm == "bm25" else {"value": f["value"], "version": f["version"]} for f in stage["facts"]}
                    docs = {s: [f"node{f['node']}", f"relation{f['relation']}", f"target{f['value']}", f"version{f['version']}"] for s, f in facts.items()} if arm == "bm25" else {}
                    require(cost["stored_payload_bytes"] == len(enc(facts)) + (len(enc(docs)) if docs else 0), "baseline stored payload accounting")
                    require(all(s["value"] == facts[s["source"]]["value"] for s in steps), "baseline did not return the matching current record")
                    require(cost["retrieval_calls"] == len(steps), "retrieval calls")
                    require(cost["retrieval_payload_bytes"] == sum(len(enc({"value": s["value"], "version": s["version"]})) for s in steps), "retrieval payload bytes")
                    require(cost["retrieval_candidates_scored"] == (16 * len(steps) if arm == "bm25" else 0), "retrieval scored count")
                    require(cost["native_updates"] == cost["native_predictions"] == cost["replay_payload_bytes"] == 0, "baseline native-work inflation")
                by_stage[f"{stage['phase']}/{arm}"].update(count)
                by_seed[f"{stream['seed']}/{arm}"].update(count)
                by_arm[arm].update(count)
                for family, counts in evaluation["families"].items():
                    by_family[f"{family}/{arm}"].update(counts)
                costs[arm].update(cost)
                costs[arm].update(trial_wall_ns=result["wall_ns"])
    output = {"schema": "mem3-independent-reconstruction-v1", "verified_trials": len(planned),
              "verified_tasks": sum(c["tasks"] for c in by_arm.values()),
              "counts_by_stage_arm": dict(by_stage), "counts_by_seed_arm": dict(by_seed),
              "counts_by_arm": dict(by_arm), "counts_by_family_arm": dict(by_family),
              "costs_by_arm": dict(costs), "native_trace_audit": dict(audit),
              "observed_not_independently_recomputed": ["native_ipc_wall_ns", "trial_wall_ns"],
              "scope": "independent raw-trace/truth reconstruction, not an additional campaign or native replay"}
    args.output.write_text(json.dumps(output, sort_keys=True, indent=2) + "\n")
    print(json.dumps({k: output[k] for k in ("verified_trials", "verified_tasks", "counts_by_arm", "native_trace_audit")}, sort_keys=True))


if __name__ == "__main__":
    main()
