INPUT_GZIP_BASE64 = 'H4sIAAAAAAACA+29a3PbRtIo/P39FbCeKi11lqZwJQDK8pbjdc76Oc8mOXaSrVNxijUABhbWFMEFSCvaRP/97Z4LMAAGICnJcbKBqhJL5Fx7+t49PT+flPmuiOkyzq+vs+3J4sTzI9uPAysxE8+xrSjwHUp9z0oTk3oBtZLQ9KIwCE6msuu2oBQ6OkkUhC6l4TxxvCD2AieKUpcSy7PmDjETO0rCue1hx2y92W2X12SdpbSESX/+LKsot2S7K6HPN29effn1m7+/+Hb53Vcvv/77N6//59Vfl1+9+Pb196/gkzfffQWN02xFoe0PP59syPYKOsV5Qn96WpTnV3SzJU/Je7reJudlEZ/HWRHvsu0ypTB+AZvaFQV8OStKGCciJV3Sn7JyC6Ntix3lHyEMotstTmHN55YJq7sitjeHiQI3ngemRUgUBLFp2r4buZHlW77jJwEJXSeObErnSRjasRV5YUoDz0siH75wIy9xcNJVHsFIZuSHrhl6TpAQN/VpAj1Cy3ZIZNI0Cf255RFiBt7JHXShaV60luXbyrJoYDp+6kQOtajtuIGdJlbiUdO3bcuhqRUnUWqZPoHlenYSJakfkNiPQhsahcTy62VFNpl78zCNvcS0qRfN/XkK/8WhE9AgcOZhDEuemwEuKy+y99kap/+JxFvAEoN/Qlbw7f3PZrmipFhn6/eHHtLcM1VgpFYQpiF1yJzGsUfncTIPCKGOG/tenPhh4Ht2QGySzF2LUNeL0yhx4AwBE2PXjL0aGI5pmoEZx66fUOKkZuqQNIA+EbHieeJSP43nsUXn2jPyYXj1iOLUI4Fpu0kYpfMwdGzHt1IndlzL9hzLtSPbiVygCjtwExvILExo6jmJbxPfdGOzXhW1I39uxr7tw/FCAwtOBzqkQWIGQGrEtmHvNPQ/5RHlN2taHHo+gRmECiScuZVavg+LjCmM6wRmMncAkrafJIj+QAkAYBfgQAKSuFYaEwokN3fiuWUBs6khEdq27ZLQMhMnDkzPTBIaRJHphwlx5tS0E99JHMd3tOcDhKlijRMEQRJ4UUz9MIwS3zdJEAd+ELupGcaxHXqAREAvVmoDvyOBR+I4SqmXAknBGl1lVU4Yk5i4bjB3qeWY8xh4nu3ZgGlx6gDVJdQH5Ew+5fkUlCSa40nJquyej8rgqBOZsevaYZDGVmy5IUmBZcdBGM5T4Beu7QPJWNSdu2EUAkkRN/TC0Ir8wLMjAKmCpnPYqB1GkQ28aO46bhREdkio73skCWKbuiARnNDSHo5nmSrKACa4QLQuTWPH9iiJfEI83wUuFSVJDFzPAt6b2i4wKNMKfDuwgbSBwwKPngdWnCokbQUAeprQKCCwEiAs4HZhCruCk58jYdrECqx543DW9MbYFNlHsqVGSa7p05isVsbL7968efXVtwaXeXBwRpy+n8Dyt2fGNY2vQKKW1w8/xmW522zyYrvEkcvf86G688BVVuUR1059e04jj1ghcTwzBmozvSBNYK2BY6bEi6N55KfEpbFnWnPiOPPYSWCamPjzelWWSV0Qex6IVNAwHNBSUtcChcQzHYrs0IuJlwbpb+lQf/eHCaxXFW/AED0P2FzoR67rhKjHEJ9YTgg6h2W6lh+AkuRFVmyDZgE8n0agsZg+Dd0oBI0qqFcVOBbQsgW0mFpuTIF8Hc/3YZugapmJHwXz1HG8xP08hyl1E36KTAz2nmWPRmnZKmvziemSOHE90IhRK0DVJHEBYnAmNHV9AEZsAhxp6MSgKQbUtnwbGF7kmJ4V+kkNuLkDQmruuQREEshP6s0jb+4mlILmEiagfVog4EDX6NEorVBdVkxMUG9A8SMgWQmZg6qamE4Ug6Zk4lBxAKOHIHtjkOSgI/qouszT0E2cxI1TlThBObXtJAX1iqSeabqwVWC1JqBqkhCLgB4DaOhFjykOm6dU0uJjFtODT8h0Akc9IdOdJ2QOKrMDcj4IaQqqMKj5Eah+geuAEQCGUZgAd7JA9HtAjQRUOcBp2wVlTNUMQC6ZlusltufOgWNFfjIPfWgCekKMBBRZFoi3wNWfEFhNqsISWLYJ8gsGsz3AjjgOAVMAkLAGGM5xfZB+QDOJHbuxDdQIsAdajqhJbZs4oaJGuZEDjUG1oTZQXezaJvFDi6Y2EitoRL4ZWCloY5/whPaIOP05wY96TrB4ExR/IIAgjgG15lYArIPGPhwZBVgnXhgHcDygaINSR4K5Y3lAHWA8gKgBPVrR4ObA/KwgohaYYdRF0xeoNAIIgvZvRYnnO5YD9NdzTnbDHAmSGPTKADgXHG/gANoEXuKnLswOB0PtBLil50QUFOI0SczIJKlphr5LTbANgQcrJiMoKzFwQsuLncALwXAJgVnY0Rw0WQoKMtoBHkyw75x+nJ5sijzZxdssXy+FMe1NTxD68k8Q1HCW8ZXK8T3gww0W4TlgCAFFm6Dk2nFkwZJBAtig34Ks8dI4cFIblHvQ4S3Ut4IUZHQYmSBWbN90VLqgIUAbWEkaAosK7SAOCUlAxbaiIAFbx4SdWk6KG8vyJf3XDjj9iq7jhj4PxpCqMqa2B1MHZkhsECMA9WBup8DIYDjABrCsacJIyALe5oDpDSQB/NHybDD6LJvWqwM1H3ABSJkGPqye+B6QKEVbA3AEzI4A+jo0ZmBfk232kS7LON+gA+Tbm9xA0QRHsCMgj+hqdf4tKT8Y5SrfPkWfBzU4zhtvmYx6GufXmxWFj5EuDLJODGCZ16WxoQXg2TWBPcNoMZIV/lrQa5Ktje0VNXZrFGjvaVKdtLEtyLpEwjp/yaaZnSBiJPBdcbv8F6woS7OYIBaAinFXeW+ibA1t3iNsC7rJy2ybF7e4myJbraDxOttdf5nv1gnrKmhcSN+ncQaT3Md1dLzPCJnNH8cN9Edzqfyh/BN/HGP/j2oP/9FMxj+eVfXHslD+iNr+3Y+gJDE1bLu8pturPFmCIv2RrolQRbcUtDfQgmDU85u8+FBuQIacl3GBqvS56fgx/AcUGHrnMeh2WYIaEwVddge/JE9jVP9Ax0ue8kmefrTOxW8JqFcg0eQEs80tqkzir+UVKVVNPXQbrm0SgvCaAwAwahBZYC0EEeghvu/HYHGA+gHKrGlRJ5lboIu5AahYUeKbdO4G8H+qgMpyXAeQDVR0z03AqESzMElJBHI+TQFMCdAcRWc4wEk4WGIM6qFLxnizK7fWLJwbEVNAjbd/e3FOkwx1SLCY3PPsGrGiXL4HrXW3IkW2vb18DVuclh+yzTK+ylYJMMNLxI4LY50b8RWNP+S77fmWFO/p9pzr3kw7LssLI1+vbkE/jkHhLc+FB2iTrcvzkOmN56TYZiko5saKRHRVGkJ7xqWP8cXfRHyRgW+3TQMkp/Mnxou1Ia0X40sOb2OL1hSYIrRgRhADNjCayuLiHsDzL9Ee+q6kBpMt5ezdGgf8GlHkDbCkW2Ozi1bCFhJtjDhfl3BogCHbq6w0SEI2WyBB49srWptY/wTEgn/5eNwaK2EV8WpXAjLC8Fd0lTB0TbL3wO+mBnomIxJ/mBof6C36JMHGWgGbuAa0MRD3t9BkzQcECxEsQDDw4HyMbFsaK8Twkq5ojPyiQmFshcvdXcOnO9gmow3c5rs1/lluk8UiLReLLwGzL5TPytt1vFi8KOLuh3/fbelPF3IERgFLhv41N5fzw8Bo2r4E2xUgGGUrIN0v4FBW9Hvr4rD+/yM+A4Iv2Cm8zPlZg+15/0G+jlCysl+1g6zprsjXAACwnfPiH9l2DazjLUxJBxrjVr+AA6Tr5O8ia+J7e0/7v9I0W2d714FN/zddSxBwXnJEj//m2Lh3OXWPrxHXv+AG/96JxPDfIMgP2gsbXS5qX+O3W7p5jckogy2BNnKQKmS1jKHPsoROoFX8a4e+K05iy4+6/tvbDQUU+Str4tj9Ld5uSbSir5Ma9QFSFHCEMf1XRZEXF5ovXifwf8D75ncvuXhAnw938LQ22NPqm5ob7W2L/Av5SbshG6O8oslXDHL1kb9GRFTPY0/77zaoprSb8/NYvq+aLXes3TLK8y3wTbJZLOoxJGX2LbZ3NGR4QNjw/w5dsAP6rx9QRBuXxruTPuMJGOO2yFcgkt+d/PhufZ0zXokfXRzUX/GdVAPIz/QjNNXdmGwI54m6EVibwxYinRrVGOyDw/qiIgQKZGMJ8rNDR9hmBZNSzTHkp33HoWx0C9KRgs5cY3drqM73MCj8ZXBSZWemIKogBaEKvOTfM8yCPhOGWWesawPWi8XXQniL/i+5yxVmQ+zMUAS8XGWS8R411Cupyu8d85jBVOLBXdKfjhmm0fvYNTze1Ixx3rMvEyP37Ftxm//6oQr+/rjvWCuTjP3Njm+ZZj8hmh05kuhlkLLSGVvsoR5Xbo6RdRfPK4HagIQk4koyCHL4pqAJRUsoL1DpK3XIXPcVv4E5W/VqzNGlzH50fUO3KApRhesizD2HeiNWevxYb0QjRaTee12asbpofd+RmGZQPspQjwqtt8zakJrI8GiAdBsCKLT3PO8/lmaFBwy24YMtKxqU0kmldLE2rj/eczxd80MGlAT4WAvsHe++C4TByj20KgXdFVmv6UrPcO419Pe8wTdF/r6ACb5/hNWKIY+glL4hJUK+EHboSzS9N3m23j7CoKjmH8wY9g0m9qxRAh403qEs8MDh/paXj7i449jEgYM29IpHGlHBQ/T9nBvfsLh+ht4kdPFsihzdkoaI9tcxfub8nKEfTNi/xhd4g+IVtEzohq7RLuUjlpKT1+4wVRU3XlXOsyLKwIIrbrl7jTmlSiPJjXW+Na7Rlz3j+07XRttcUBYCbGXybm3AT1K5PxbGadsfMuVtuIsWv++xmaHdmfH0ufGGlrvV9pm05KeGYpk/N37mo2WpGHDGcjFmzFmQJcaTS2Ux8lPeBX9++aXZbVNk6zjbAP/kW5pl5fLftMgnZ9o+PH8iBVN2m4GpNtg4j/6Jp/GRHjT0OtktyzXZlFf59qAO1zkcFnpKltdZXOSlcXlpmLqGCSDzClBRtnt22TdEo/eTiTWbXTrLuWkuTdM8m6F9ht7PyanoDmpuCZvbCYP+ujw7ZPqnvRt4bvQNbPwvw8JF6MFcuQARYPR6s73tO5C65YquJ2cwo2PzsW1X16OK4ZSiQwu7Wl9rhqg/wh+lR+uLbEsLdQD24b+zzeRUO1+7JVnfTn6ZXANFof9ZtDr7xcBP6m6CPqq/G9+IIX+uRwaGtyvWBtDdJFuDXM2SybsTvYMeeAYtMuBWSZamFG3+s7MLPtId/weMZYPdRDMk+i3Zn5N6Pv7xtP5AeurQfXQDc2+kwfRUMKOnODnMNbsmmyWt13n2FzGKXATOXtJrYHNZbDAI7PcxTmrIT41TtljNRGKCrz9MJL9aLPJ0CcrjFijlh3oz0bsT5oac8eDSrN6M4LCNTc0+Wu/eme9OFGjI9c9IuSRFQQDLlW97iXK2zZcRXbLAT9XjxzM47juURHS9uzYUISoRQDgRJ/u9jHJM7kZUEUjKsIWx1/eo7ARU749ZviuVXm1HkPS9VP3upmI7GXyl2w4IMi5IgXvRVcrkzOmQp1zdB5OIKF1T9VOGofDZYiFhtTkzLp8bm5mYST2eurEEUwWdqTGbGXfYU36iG+CuoqY7qUC8Kgg6EzDGhRrDDY9uPC0xvGGgs9u4uUKNgisuKPexmQicybn4UCLKNTO+ykEdAVpGzQNhyTx/ImrWjGSR3fYqxxiugbEzlrFIE1AbQK/ItobUhoT6s4DNrxPlMJDastr5qJyKkP6w+Ybcv6i6ApNPCqZbdXtFeb7q68c6TU6vd1vj8MkqlWqikhp0n+rQ/PQYPI/rABj0HI6PacijutErNK5OxEqyQGWfw/GzDgwqinr2j4XRDaEZf2an+rx92CyY2RO3evaP5w/BApX+kKdzkU4TFCrQVYh4qsQZJv08W6iRcoyZVL+gC8KYbeVJQ6kSor3qgdo39/OpsgP6A46W+TVtS3Rd33y3RTE41OeJbomAB2n2k1blaU+l9ALmsNlQRSFuMTStzK9EFRf2ZFWwkLpUCI36nL+3DUyLUcS/wru4EINTah9794gaqsPRNK9uik2odN8/1xF8ojMR77t/jj8uW2lT8MeM3gD1DkUS2zgqhNXCaAGMbUOxzWsJq6Bik/YVYM3WIPi4dRux1AZQ98Gkeoskeaq2a7AJRvczmbAhep61V4ybnIlEQHnwypAK6d4ZdFXS/v48atozzrR7ime9GoRIfalQi11bEPPWqMeSRJ59kf/0LLldtxn98+cCsoKQQUgU8TNtLFe2bJyPoqeJr2vkG8I91duwx9kw4Guo9KgXgEhkBdytvEJ/NEfJHATDWnHDNHnghRGvcqZSceWqRNVKOGEwFU6g6HmtJPGco6mxph9pYYD9AR0K46ZAww9Vq/J2DZ+U2b9xHcw1gXGohGJa4OQlTEZFLMpoH1xTOcadfm9N8CAaR/v8rHI8vWL+Jg6hc4SfEVcadS1R65yrCgYsOUneuQTTkQ+X5qtVfgM9oluWwoS2B5htnI9iNhXoh/Af4CdaXAbLZwIDDF1NAjz/pjwsVvABWcqlxCl5t5N8JNlKhNkv2J0bpIcSoJHBBoREYctlq6zSwO4DQ9XAkCQh7swsjCGj4Sgs7kXRhktTNC5oTLMNjNifgBRnwtGIDWsMry2iwzYq3H7CRlfotWE5Da5ZZV+s00x1htwdsDCOxcqSZJABVpYW+fUy4ybXoGIK//wJr2Bl8XNFzFbSo19DnR5lwlaGsCqED2aIB/KzA3laWzKjydkvf7lByuDJ/RVaOduSsN+o3m9p+UowtU1eAYfWp4pjpflFxwNUK069mMAl4m8BEXTK2GfEg/v6Ug7HH2aBrdD4kvMIQp9x195Zy9CS7g3ZmjtUT6vOgsd2DJmqgWSss8rQ6th2OGJ7wKpfZaAdMAVX5WTI5Ul3j40GaL+tt7l0zPWPLxj5LK6iiEuSog6gmUFp07twgL8IZRS7NTp4Ly+bEQ7+sbaf4hBXuimfHmcmVnqCvOOaVE5iJe1E4yJu2YgPZ0saH5uELXMVfkoWJfkSW/onZ0t79OnfjyxCXsLdnshOlKil9IVeNNsy5IamIjzK/uw0ksQM7aSHU34EBIsqPG0zKdmO31ETDIQzKmYK8vm6dNgN07aJFX8w+jIcTz1tRB04mM/+MsxcJAya0Um+6L7I5dB4nHGwOIUIGTU4ivwCAxGgSPcOoIRkdaHafd0FP3ui5Wf7Orfjup1huoHfIYhUUkFG6fEgRb427Ob/2m5NVP/Iiw+Yw7dYfPPm6y9f/8+r/tE6MkYJ9jW+O3B1rODAsgS5cU1aw6lfHTcoXaPNUVQUoAwKZ7HNrqlsoht3YOArrIAwMCp+v2fIA8RShwY1MUx5qkI0MQbeMv05N2oE5BiD65Fh8poYE+GVo1Mwj0GPNPKtgnFM4FrIM9GW5xFQra+mq6Aynw3v8UUufhFs7ewwBX2jFSSqaXtvcXnXgBjfaNchrALk6w8T3kxjDDB/bTV3O7anyq6uTWrO6p4N/2zDAh60eoWw043dsngbI8vtCj8jd/wa/C/hdtVetTrKFT0IU8G7GCdGbS0vabL8l+0uFgwhkVVUgpKva1rtrHIt7gus8I57dHXuNq+P8KzFFA9TPFv0zIfYr2nqAaU/NBAaa5YuoNfpng948pG3LAzM0lY+FOHahfGPqRpp/mkprrQujB16AzWK1EDeOCqHD0ALOLQnE2c2u7Tmar6Psqqzgw6kBJ0J4N9IEeEDGBHWlek/kYYaKBDuAG2woeOip7rnot3zetSKQ3e0QBxQ8Eto3r3mtlgwXHi/I0VC2xImbZ6yctKtTz/S+MkP+kt3bRizw0OthYc8BG/BaB7Xp/gOpt1OqjLfJbT+fi1tsTNt82vNANyvvaSbPL5aSP1U/bAz7d2PHUlTIV3rGzGcfvldgaaoC4Mcaz95gCQaoL2GoJ3y4cQazzRG4oNi3xyH28llfKT2pw0NZICk2jlle2FlziqPziqPP+g4/DA8P8cu+g+CsGTNe5zDPpZ6MLDUMPVfjpN8dXiqwXSz0hAj3lsIMlDVAQHu2dufy4vyUuSgZcmiSuVjgG1dBpY77fmYKbfKYKoXQjDFhnXZYQtdbqa1iVVnbyt1d9GX06v00STwLgaSe1Wh30qEXfRlyDbcNI2s2kVPtm1jT5Vbb6HLiO3CrU43XWgSYpvtFUSR2EmRWhYsi0zUJ7je4v3scrMitwwPFKqSh618hNEFZSTMYwSLn3ljZPLiMRf1Ohf9Glf2dNcAT2ThjLFGxVijYqxRMdaoGGtUjDUqfjc1KnqKSNbTK5+PVS7GKhdjlYuxysVY5WKscjFWuRirXIxVLsYqF2OVi7HKxVjlYqxyMVa5GKtcjFUuxioXY5WLscrFWOVirHIxVrkYq1yMVS7GKhdjlYuxysVY5WKscjFWuRirXIxVLsYqF2OVi7HKxVjlYqxyMVa5GKtcjFUuxioXY5WLscrFWOVirHIxVrkYq1yMVS7GKhdjlYuxysVY5WKscjFWuRirXIxVLsYqF2OVi99MlQv+/cnihOXoe35U9Ti5m/58gndh4UsWk3talOcsLPeUJ3iel0V8fsClZaylgSmbrDZGebLYFjvKPzpZ/HzC0jZPFnPPtKcn5RWxvTlMmFpBmIbUIXMaxx6dx8k8IIQ6bux7ceKHge/ZAbFJMnctQl0vTqPEsXxrbnuxa8YezrnKIxjJMU0zMOPY9QFznNRMHZIG0CciVjxPXOqn8Ty26By2K0p+KKvyYXhlVTROPRKYtpuEUToPQ8d2fCt1Yse1bM+xXDuynch1iGkHbmI7thWCOuI5iW8T33Rjs14VtSN/bsa+7fu2DQ2seRxChzRIzICGc2LbsHca+mxVCDylDMl36zJ7DwyPxYef8uzIgqzLFfdzM9Ne5EAK4xTM/+wj+otZLByLdajJkU8MccVDxpRZhZESr4dBHxidrot8hekDPOuFFiImjcFtvM8VI7nIcPkTo3bql/z6h0KEF41aJsC9yx10XecGzAD4ukVM59R6TOGPt+j6Ga4KcVC5DhjnPRUXWFg1kt0Gr7H+r4vhNMHnxrDB0go8szSXaj2HJErdI+PpMbKXhicSAYwqWagng0gqiMfqXixHfFDxQCvm8KAIGDqn9cAN1UqbkaTVRkRQvqOCsFSPih/XyW9tnaSpNrWjYTyH5LYOuOldwOiZrWHdNU0U6Gu+FBldmm+qoBb32Is4nqahIqce6qjsgqzHRVlH3ITf6VA/ZcPbqCLAfm1VR5qqI7JtmCl5as1vTjvBV9V6uwfq93oMMbvoDX2KLIalCjFG/RRrQNWglPlGBToqqkJVKBlWef5ht5kZL+rBGPkmanqTSjgiyym63ZCybCc03WTbK9DNbwDEA/yPJSUCs3329miv0z0TQftV+zojE1ajxgwzUVwHOjWr7fwHcFtdkmiJglCJCfZJysXiK2j+XUnP7kn/kpGqgXrBTxF9cTHSfE0MtqqjCB9TnHkaudFgmhqQtaOvFT+6FCO0QCrYY/ua2ybfdG655R+WebFEITP55RejliZy8/Vc16AQYX4IiA31iEQmvBIu4ryM95o1S16ou6j2fhxy8W77ozicdyxVWAlbW6/hnIqBW+jXGeaJujsVNR6GZPtkTEMNPgrPhml+sagqULR3UN9PFEGIVnBJ9uva1KjQtAFXf3uwRtPdfJcSD1FnEArcfKquP3YIBpACY9tqxqVkrFNVOWt5f3k8/BiWxmU+o0+JkqA/XGdgXiSTU77Mz61KVki5i0Xa0AokT9kTlB1SI2XCVSfW3kau/pytZlLbrJ2esO9yAHcztfOwHkasqPDtxMW8BrnKqwg15I4iVZlWcyrBxj5oc3+WS7CRFqUIkrTNzPYO64wL1SHIveY9ORmqy6f3jq/8kWkpi1b+Sl+ggGehLJrJKj2N+eEtGpkpmqZtkldR/1LJf1Qqs0hrpk1vFUXK28mSXvdcM9ZdNZaypnPTGBRLzUVjNgTjAtqV6u8fMw1UhpWF14vBlN9vWyx4jojcyEQi2PC5/tgJ9LVTIgEifSmVfUkVe+/9NHd130tAvaS+TxzK0iF/B3ithAapCwlWBUlk5sAecclEZpN0NS06ENaN0i94a+tDh7+ahgzyPNuukczYn4Nyt++6FBhm317REo04qt55rtN9uL8PMIJuz/lKVb/ctDOc1Lh36PhKmhceRcTvT6XBLkdf5auE+QBxBuYonTWHqzlovNuyGk5HEfcggXcrJLA99hB5K9Wnn7CbVrrMqu5P7NB171xuP65/Wxgfx5kaI/Txi+Huml6CSQ52qzSh7ldMUVMj8j1NZOGHgbxSvc7X0254vU0GMdsP2waPPoS/DbC03yUH0xLzAM9qRYc/hzXQcZlyVH54YqXQziv1nfu64iuyfk/Rm1bkZSPicbByen/X311PvfoxUPQZAkXKn2qZ5bp8WhUrYhVplVLSf7wAk3TRScfxpTEEpMUCxfLHLAGEZQkyZ93cJu3Gl+iJrqipcZ38VJledxWPneTZAFCbYz+6r7pK+2MLHYLOsz8tp0bltP49O6SHcUAwx4lMg+MlLMa44BgX/E+OCz6UJsaA4X9ewPDTSk8J5gHhKZVGRW2/pzjVTva7PuA/qvAeo8ljNPnXiSY3GZMILU8r7jPGmMcY868XYx68NVP72Rooyy9FinC0HnHHuPQYlx7j0mNceoxLj3HpMS49xqXHuPQYlx7j0mNc+teMS38C1/PdJ716Kh+ZPejeaWAGoXLD05lbqeX71AF5AuM6gZnMnTSe236SOCQyk9COiOXagUsCkrhWGhNqWmTuxHPLspKwvuEZ2rbtktAyEycOTM9MEhpEkemHCXHm1LQT30kcx3e0904Dz1NvwzpBECSBF8XUD8Mo8X2TBHHgB7GbmmEc26EXEGInnpXaSQjfeSSOo5R6qRt5sEZXWZUTxiQmrhvMXWo55jxOXWp7tuvFcer4UZhQ3yHzRHfvtPHuvKgNwsMAKX+Egz8+j+BPjHyNEYN1VXI6ZY9rcGfqjIf/v8qNgtxU1Q6b79Dj8Fg1WmoMoo40sCmgGHzBoyAxf45j38PnrarBex4Bf/UTBX4i34Tb0/j1Gsw/UK/pi4T52g59kfyt0GH3P0mOrOWAh8sBQvW7qnubflPkm7wUL3BrbrrymJBMGalyOViNduP11gDlOIuoyPlIcso9ONVjKkZzTQs+YExWK7SVRQRoQ7LCAOUPPSIGaZx9JqFqbPICtL9cCATWjFXTGixx3UiN0GdT/NyJSNS1xbC+Dq8J362L8+wfz58rdd5lZxQHi+FCz7JWtXKDf2D5/2DI3rt+IQH2VEl6tz7bm1bCSoYz2jwswQRfy2O2d11D5G3r0aC3mkeEGtAFK7UeYtZXV5nDtJa2GpO/W2z7wdkzSoCKPcilKY6sxQplWYchQxXmuQf4cGVKBbwKgjoQauFVB2u/lk8rVW8miWor/9d2jSjPt4CkZMM18I9A59fS86W8CK+rW825tYIlw1jeiFwNNZ00ag7py5hVDgJRdU6UUDlV+KkaYNMw5anRlQTdoji8ICv7f395Q2zZjt9UGXWNj3m2QY/6+MvyF82aFgu28O/W4umAFW3rl7W3pLvOwU3sK0ko3/apePVAUFZzAJpA59cb3NezPrH6/D/oULrAe+TT4WkZ9zqSdi0iaCQdxpqX+lrvQi0qN8rwAXeUsv+k0xXAZ6tsFoma9sHtEU4eGR/rcxjXw5JfeyCOFjKLSTy57Dd7B8xVHfDYSv6eley9wX150B3LXFvA6/4HN5ifUt8XHaCi3rQR3QMnbaHTfc9kuAjbYQVRmi+Q6p8p4G3YsTZKnnXOeMqbzlQk7kkKqZ+Ubb0aUJVAZSP310F9qAekrg8nXB/6+LuaoXlUfK4Kehz2tKp+ywKgx8aZmUejegFwX35i600KlmiwTwDx1185TR/pw9I963evmraiiCr3IoglDtdRTQQJYYhPs03BidW9yXduZ02+LNjwkRvvy8Tp7AxxRCY6VIylnZYjyEdSuNwb1svnv+3PoJHanoRHrf41zncfyshejUcirS69y2Zq2dMmuesrWLbqpPYOrMtFrjzMmi9JCYSYarObYccTnU/k7YYUJX1ZjbpYaFFB+GpFHXd+HJ0oRncjvU2VYv2DT6A8kjO4nqPJFStcPDZ5+vC7ShXyHm6tt11avf4JjQEJkpuA0bDVGybyxUtll0SaGNyy15keGvl9gPokq6RzpayapiLJWY/O364WO6AJiXquD9dg963hV9Wf2+dXge5zwOolo5DvYB0Fhvw7z5z+Vu1gs9fIbO+AV6BeXuWgt4ASswNQvd9HNA81H/dYjfjTXE9VBHY3dx+BHA8kvV8V7fXnoLUim+Cb6mG1f3sqLB6ZLP5THRDmvaz7ztvIv5KH0my7/9oL4fJ/D7FvRLRoYWgCSGp56PxmD5n2WL1HCVK5GplLIh0RvzlBus8n9VmZjTh4Ccypcni/BSm7x+OlSK51nK3oJ+QzdYtfi8Hc18f52YUXPwotY2xDUffSwhEez756B2OCwh8iQeH+FRbGxIYxsWFMbBgTG8bEhjGxYUxsGBMbxsSGMbFhTGz4jIkNj13CpO+mtShUcnh5kp6BHgtkj1Ud5EhwP0ZlrTHBZEwwGRNMxgSTMcFkTDD5dAkmj3DpcMw8GTNPxsyTMfNkzDwZM0/GzJMx82TMPBkzT8bMkzHz5OGZJ5+qcAlmMWjqlqRkVXYLl5jqu/ROZMaua4dBGlux5YYkjVI3DsJwnkah7do+oa5F3bkbRqHjxsQNvTC0Ij/w7CjwPOVd+nmYUDuMIjuxkrnruFEQ2SGhvu+RJIht6gax54SWtmqJZ5lqLRWXBK5nBy5NY8f2KIl8QjzfTWMvSpLYoZZFQje13cCZm1bg24HtWsSERcXmPLDitF6VYwVkntCERgGBlbix6c3DMIVdRTGdp/C7TazAmrerlmizhL5eU6O8BesP7HMsm1kZs5Whx/KApjyDQ4khv/zuzZtXX33Ljd3SyNY8SyjbgrGbFeWWZROtCPxSV05f5dtyZrxYrYy3wgf9vaiBio1ZbhJOVvK663zAYreGwY2Ibm8oXeMjK1lpRDkQxA0vW7yl9dsC7EEX0LOROAxhIFcVs6rkmW2yWFyT4gPmzHxzBapCfv1XsiUX6tf0Wv0T4/FvYvUThNli8aKIL4ZSmrpmdTuFZyBnoZncIzwQMmGIVzhUXNsXMu9EuO3penetdxx8sytA2lQxnapSruCkoizWVPEQHDQOKlR4wEo6wC5QGSuLBjE203a0YDaEWrL38rlhmVNdG1mzC1t4/VkibPNMRZJTva5iJaLXF4wUqj3wtS9wyXeiBe4RH11QFrvhzReDAFHFnhxUfCaHfineaahmSrGenwQ5pmz8LV8lZTNnQ1BR9RgRBlUMsgJJwnh6Cb+D0GdeGkz3AdKIP9RJWSylSz44QMXDBKgrFxn0+zf/fc3ysAi0uaJY6naNIqQwSvIRaC26NQgfTxYK5F5Plml4A2oHysUNLARpYb3l2YUy82RXNjbBmHsDX0We1HDkh0yN4VyvOofm9E9kf+pUVTZtwbFFfLTEQuErutxesVQ6Q2ESz97EYOay9LDagTawrv37qdaOkH31kRa3BpN1iHrcncuPHDrAVx8o3ZQGZc02V7cle1NC8mIB1W4AT4kUHgOho1OX2sW0FdAuFh0SlD8D4D4ysYk93IF5jFnMCKCQb2mJvNRpQ9YxsqgH+yqvIq/40hVKletsje7aHViTK0W0KWjM9G1G5yipSi30gSKXsgtTaz7jIfSwPbNiTQ8/lEbi8TVIReA3YOjQ0vgA5g3IeuaSx1Pj0GSxkvOa+zMVQDkX4Ftp9hPl3JAHrJA2mLppoHp5gRmmgrWxOqPIs0BQUHyfRT3l5rHw2otLwdP3Wd9HcP62S2wo3g+ImWOsERQO9OSz9NhJtYAZO7ypPDwhJ9QoAReqfJS2VB08cRcrpD/XFb+sJ4Z1VTMLWSgBMVXGueiOAdZCJ2Z9p11ezRVa8Zy+9c9m7ZF+6a5yoJGUvb1jMBgjbHrq9m8amrEECCZV4hsGZ2d7yIOXVWbIvCnQPIWuq4SzELIVrB0kCDIexF2jzLYUpDfvwqmyHo0r56yzxRP42a/mueUZgOgAumvWr1p9ulvVAuP1+df4tKAyHjK84iPlr03hCVc8js1OruWjSJUKXo2sqCIz/SM3PE41TGgY5Qe2eJDo/jUJLUuNJywvd7MtlvRfrbzmWf0CwSnuoE547kQph0bhUVw5Bv/ryDg/OyINrjbVRkSb/mD/fqZSU20PE6k3MHgnfojn1HNcHMJItHyul8lh3J01eH4JLOxnfYni4fc7evhAVpFMG8I9628s5/ISZHHPco6E6d1hYO6RD3w5fwaucncQ+PskxNAJPJm4s5loPuPG49nZTBoPQBz40dmjnA5jixE+2Xb4obAcD34qNTguhg+vtZtHOsq+s5OyTLcfbUn6+8h4rYC/OwQn5PK00lX/ksDhJ1rbsgXFMTXneqfPplB0k4ZkfgmSa3fNJR2TvMx65eoqV/7ZMnRWF3/mhCY0URTXF2uDoiya8gtwHAfxkhwWDceRQHet9Va2dbJWjQtuTettClCCy6tJ5Wo5QAoiwTHOTssnE43Qk6d1dtwzRq1jSbJEJl5xNatXyrTOoeVNXtOb6jYhyrSn7EQkzEXSIQAzTt9P8PnjM5DsWN87K68f7ndeAqDxVtoSRy5/z15odx64yqo84tqpb89p5BErJI5nxkHsml6QJrDWwDFT4sXRPPJT4tLYM605cZx57CQwTUz8eb0qy6Su7bhe5IdOFDmJ56SuFQaBZzqU2Db1YuKlQXqYF/orOGykjqecJVUnWRpYy756lpsSfE679kwrD2+XlLuLN0UegamY5AwJr8l6h7Y8ZmVxl/M504OUyu/o8uYPahv4PjjDhVJceUVLVuJxTfdc2iPtyuzJGFfJPWRc1xYJidVK+XDMO80vOyJaMW2Mv+YhC9N7pmnApqu7mPQjFtsHRMcOs3t6mrW+YuWL/S7o1ns6LYo58uLpIw0oFJaLnuuWPOvmS+x2uPdQ2B6Heg6rnPUDnHzTQ+4v6ha9bLsIK59XxYFZlIW7oDhCoq+35LKHq6PIv5kfSyCa9jafECnSJDpUrPCrBny5UpsRF/gAaN0Qo2wqpmslJKZr8QbEEnc1fDP2GFPxUP+Nuuv+89BD49j7G12/IIOYABj68ZcY+jJns4aF0oZ1A8x39VKk6sqtudNNM1zTm1cqYDEUjxnup4vRSBVSrr3lexP/Vruo9g72Ad/GU8M6FgagX2hOENRbbFy9MGjcnXUvbSsZhWl1OuXjYKOKYT/0o9iFYf+oRzPYl/IWk0ItE76xA0+18bzRsaPIp2nlGD/qgVjQf+Ix34CIel+jOsi9JdPZH4+8WcDqYOiT9e1VfoPWiOBuHRJmK34gAbMx9BiK03D2fNlqxjZyNqM/bRBwmAzy7kTG49S3xq93JYYpshXo12JQuSsKVkxBnyh+NjaV+ophbWMf6TASfreeGTU7xusquAsQIO9OOFTruWgBChpAEgTaJs9K9lQ6qvn9e+IzSNExNLiwq3hTPmDziCkpYN6HHTEbQ3/EA6fBOrU44KFEW2+5HhBvY3HeLqtuYIA2oS3HLwu2pKAFc8nw7mT4MDV7qyYf7tM5nibwd2veAN0AD2FfewFdT9RROvRgRHgxZapj49fOhlxeJ6qh18Srgm5AnWWb+yTiX44/KPuqRvdEs/3Avd8MUm7o4U+MFiKLIB4rRoQOARbL5RxiGHn1QNqLv1W3ARRmEU5YRsYDklWsnhdZweo5Rp6KrzBCyfirqJpU8dNqKCVoMuVJTCxaT1H94Jwxh1+lrcscHvkmo0njwURF58PJLrl7sfn4OuLTpHLskfeY34nopagSrdtNB+LK9KG9VBw4agl1ptJD+sjpf9RexZbWv45TtbVW8Vof69CxiE7xaBpN+2lrcKCWWG32endCP1LmRlRcjtyDKQZEfZ4pD1ziVs5OSVEqVd1jlUMMVhJ5IZzAyhIFva8o+Vi7XJLa/7ErMaWvb43ytCpZpzstjvLqAVRht/1n1Wkq99m1OZhP8zflzPzdOzFt27aUVREY2XNhND9yXSe0HRIRn1hOSHzXMl3LD3zL9yIrtmMvIU5AI9PxTZ+GbhTOAzOoVxU4Vuim1jydp5Yb08CKHc/3YZtu5JqJHwXz1HG8xD3IifmWheabRyuOMS47+bOVk/DF+csWM+9U71Ndl8z7qDhIpRNR+gz/VHb8iTrvo3AVcfIX9PaUOTVxQJE5QFhVwDhGbJNeyHLWU4QOlM7t9nZJSlgHk2eLBf99Sf/V9kX2Ov4qfUg+JcwxOM1+wna1Y5A7BUjJuIf8ms3yXz9s8w9ZvljgYn98tyaY8cUMeikPKuJA5lBrYGwkbrCWS35IrNxFUpAbskI/1UGWYwrM54v8p8Vik60nlbj7Um4At3OLUU4YNNuq9qDCvDov176sn/zGl2vxNvGyulOEhT5A030/q+8/i5oR6vCi9gRHW3ljfckIbHKqpCCUtHnJk+VOcC+FCIPWp6HxkejGajoCQen5ImeBr9UKc1YZRCTGUYbMWSGsla4ejtnmzOFfDdY0XcUr9xknODw76VAUAyv2kMxJF/qTsvCPPC19JseYNMHBJlpKA75nw/zx3AqPq5d+J9UT1Gez3fqmEHc+VD2NsZCs8kG1FRMObjk9y2+rxG7DccBsmVa+PpP9XALXZjYT9JJY2zJeJsTjZf0yLrJrmH69hYOul3E2PayLCjm1T886lBlU78W0cQLqN2dNaawMtRfdp00KqY6je7jlNt9MWgSsyP2jWBAeXsV0mJenZkjZWjLm2mP26dkQ06OYu+meA9yLw/Ct67uy7/q7N1nSHo+jmnzWQ7cKWvZMrTarLeWjcK2JZH19+3Y+bcDrSFTt2dMerP4s2mxTCeCg6VNmte9ZW3PLVi9h+cR0SZy43twhYejYdkDsxAWVEZRSmro+aIOxCYokDZ04IW5Abcu3qWVFjulZoZ/UmuPcsUNv7rkkdfEJbOrNI2/uJpQ6qRkmkZdYQRLYnv5Ba1hWqC4rJib1U38ekzgwCZm7MITpRHHiWCYOFQcwekhCK/Z96s9T33WIOU9DN3ESN07VqDwNTNtO0rntkRS0Pxe2GtO5Cbp6khCL+LYPergX6V60fqFRTMk60fqG+VlPeXgeZA5w44ylaSMVtvTNmfGyoOzNeIK3GIp8tWIFgJkvpODZ3F/l320SHvrfEviFVPopq1WF48UguPLkluWrMg9RWcf54xXJrrnrpNxiBWJmXFJ0uTz97vVfDZiTGgndrPJbnLpPhWViKwfFdbfOWNlV0Ei/g1/fbgEBGxfCttk1MJu/7rh6Vqm3x+jA0k8hIhVS52MuwlUGq2yH34c65OstbPiIHiykdER7bUJAq73wrbyh1/mWcpul3NOlEiyDne5pLqB9UGEhA//2dkMrB1G1LeNSsLu923/2Zbai3YjV1NB//vxCTIlDfMsuUqAOzRCIX6tY/Heerf9GsDDbMyHM8c6+sf/knj+/EPHySrNcxhwNZPyMWQUL47Qf5uwa10vWjl3IZtGxQ/CsikUe0ZYXMaBwOAujx2Lp3hgXDdlfmlbAfrI0w9CfaCg/0LTdCl6zlF6lqlPnG916KijX3b+CRtNO/sIadr0E7D3wOCqq+dyHUe3wd3oarFxYey+dQc66Bya5iDioFM9IeFOEvjutjhChuDgI0j3BZiw83+FAz9XgflX9u5tw0c+ZhFOgYog8Na5lyaVNA7UL1mYjUTJN1nnb277Ae3LXdJYxYb+97ekgoKiafzKNoDKhWO4ASoTabn72JyIzA6Trg+dqdbwlSn0WYWFkHylve4DQFX0YFrKcAt0UrwRWKZ105Non3nAvPVTb16WRciU2qIAQt9imLlp0cV1ANf6VobmhgI0itQ5/7YGXXoMYgJa+w71gBatjq5w1YVdzm7xuIj/owpc7Yng4VzANBonFMagnrlzWWsNURnVJUlX12ZPJkhRgz/G5zxRDW3iDLsUk9R5n/wRNRK1I0qhGIufh/z5R87+ZViM1rg06uz+Iapsa05hPP+U7OTvKefIv2122eQL3OdZcT3EBCuN4GQvjn+Xolssqx/coT0qv/6Pr/hDcjReHaellp9JVq56IrDZbSSHFZTCVw2lduhOGyAaa1mu6OsNDldouvr6BRz8R/ZuuYJ5c3GjOPuPeh3rE2mP7d6x7h+k1XC6WxrfsyaALfu+hLNPdyiBbPLJz+WzQeYzXGhl2UBJfVUNFBXwJq6juE9ZhDkFVVbScxUxYFB1TXm9y49vG5WAGA0mtjMWcMXcs/lZ7xfvVCcM/a3u+JGGzceICkwGavt/KRZXOuJPmUZzsnEKeTKrrGV3e06n0w6EsSGLSpowa1yole2qccoQ5FTBrX9DlyKzwPbzxscd4ENaIqE3UDt/jZ7ImPBpEk2+KPNnF21cfyWrHBaksccS+r0YT+KYsUC72TOM0q8+i7VnjOREfWTZOF5IzjrJqFk4Lig8Fq44/VKGcTxDp0TrxGQBm5ky59aAcctpXokogabtkGV2tNLioDXQoe5WlqjSnx5dnzdBJM60gIjWsN/ApQkIyB/Vk2anraFEPhl+bktQEW7bJaS8MGhiMv51dPFoIo8nbGCk8NtrJoUX1zInEuIrTNlGQJkv0sAGMYeCk7LDBT4ec0jbXFHI+lZuYdr/TudabxpGmky7A0DaR2gWgu7XeWWywiTdMtSs19MDTD+VtJKQL8dceyqj6/K5Ig4GhWnoVBVEUcL4Sru5MjaC+XsCjpU3V4S+fIuKnKK28HGlW0Cq7oM7IYjpqnYkgjvbTKqt4lShipSjIulNkqlLFqiVwV7+SwKJPQKyByg2MIzUy+3iNrKyvqRwi4mvkTQUNl3o03ivNtWTYRi0Bhb98Rl5cufVUfqx8OMyTFXJo+9YqgGMWsFzgWTvvtL9/df6qsQSKQO8A3ZnZDgYa1iTUnENrsHUct6edxZ+pSSzy3Tx2TVzUQWyk3PM+O2TGL8UzMCy7qkM5eFlcFt4T98mxyIpMixSXy0UdqipA91KQIs7OKreqhtEDzEqWxX+YXakdgPVf9luZ6uuQbJlnHZNTagLyEgJJ6gIJnAq7udz9NlT/KMPGjibsggHB9ttSZw2JxCY769VoVOC0JGPbA3OAF4ZfYmEYIxw66Hg5SIuoM5mIICnKbDGqUy6nhqXxdVTOJAZaWQla2139sH6iZ2qcKktoKynrRrqxSjXinSURiAClCsvb6rTG2QYfVcl3pbaLVufYP+s+O6o7qdKjV89RMqAYWJvvNQ1PVD1fo3vk6ewzuIx41iC+fNLIj2MfTeYdcZhH1QQqy2XSnocyWjJfmPSy336Tvta1pBYba9h7LThqPZatuV8L6LCd02FzuyPuv66bIXvh5cFo8vc8oSspEn7mVfyWrHIIX163whmWoWm2EmjO69IMU0+LkzWt6wpKh5jZ3TMZsiXufQr3tCU6W9EZFXILw7ZVNZT4uI2oj2Fq/SbBc4TNVXtYeeCkfW3ikxlb1f0HTHQtlURu/iLUkixrzzVf+IE3g8dwAE6jVaY0hzqcSP0g5735mM774x3wn9x1/GCPfOMC3GR5Pwf6AGB68eATKNVtM5t9iAvoV7QfS8Wu7xHcS83+PL4mTubLTbYul1jxs7aDSxEP5Xxxt1nlJAHbX62I9KlCo/xC5RH8UHK7LhegP224J21r/PmyKsrX3151A7yF3+HL/0NvhXNFuNR/sEzrwnDsH1VdDztiIGNoYPxA0I/adZvLT1vLq7Ki2C+3k65y2A5+/G+6Rm0xV5MS+helNqo835nUN6WdtmwsHR9RVVUNOWijSsg6Rwbeznx/mNS6b8hUEVaNnP8KmYTwOm2LvEeKqPyaltQoJ389Oam/TD4ku77I2C0tkLAPjVY/AmoOOKV1+rn5eWMiXHvgZTfL5YqIq06ckteYYbKUVTC5Dp/vADxpitel/gMSeD5TtglnX6z05719vDo2ltAVuaVJdWTHOHpxOQ/28/YO8gk0UpzrrAq5tJxQR+bS4Vj14ymKhtk4MUYVjyRxxAVxTmM9kkcCWlZ1etjZ9I/yCQ6HTfZYp8NgNHg8n5e5f0reLO0Erm8rMeobEHr5DePWmMS33BQ5elOWkYyK/WbY86Rkt7emxm7NavpDz/pO12KxIZniszs/N96++PLVt/9vIf2YvFpCXN1gK6fGzVXGyuOzVLaqngrXQpUI3A49rzBrSVL04K6yCLjhe7ql8MXkrCqJ2LVcD8gUbqf78z12Lm6zjTc/VJiATEKZNJR8VjkrS/q7bbIkTbp9WtKi9a28KicWfp2tQOeaeKa5p2FJ43LiNJuppDuQISPOW61/hLk3oEJM4TBSin90SiD1rdMC0dW3tEYBo4GN9gxgnfWWIDoKd/cw4MfErF7sOhjD9Fh2GKbtxzY2jjhrTV1/cfjt5KvW34cKI6n/dyd6d8JeHFAfSeE+JCyI8F6tZqTaDA1x1oPNdy2L7grrulxKqKix+NpRcinsd+PPhi1FI/Ybdq9cKkPs6fVAJ8vQsIe6WPbr43yW+/rPWe8H2/MP0fv3Od9RglXnwIr1A/0ZKMRBbuE1aJHgwzJRsnW82iXwlXLg2ZaVaVaK3VFjTd8TfFGY3brm4g7fKMZ0F6JUrmHYTopbXsnumhZ0dYvv1rH3ExTJiOuViUYNBJuVuG6yZXnEu2jCEfZM/ZgkycSSwJRaDLuNXa4o3Ux0PFad7wzQX8+jLWTlHJgt0Szo5rmy0o790ncuR9kvv45H/SB19UhHgvVAXwErPXUJHFPe9Va1u+trlh/ZqP/w7gT01us8MRpfX7BKFd3aXGNtg7G2wVjbYKxtMNY2GGsbjLUNxtoGY22DsbbBWNtgrG0w1jYYaxuMtQ3G2gZjbYOxtsFY22CsbTDWNhhrG4y1DcbaBmNtg7G2wVjbYKxtMNY2GGsbjLUNxtoGY22DsbbBWNtgrG0w1jYYaxuMtQ3G2gZjbYOxtsFY22CsbTDWNhhrG4y1DcbaBmNtg7G2wVjbYKxtMNY2GGsbjLUNxtoGY22DsbbBWNtgrG0w1jYYaxuMtQ3G2gaPVNtAO1rr5jhXbrtDiW/LFSixvEwC38vJ4oRdQ/H8qML2k7vpzyc4EXwZ5wn96WlRnl/RzZY8Je9hlOS8LOJzuYDmBXWEWgasrSixEgPQFCjYGSzmZLEtdpR/dLL4+YQdzsnCMp3AmZ6UV8T25jCdb7rzhMz9gDhW6gYhTQMaRDaNYosGrmPafmImYTKHr0Mn9NIoJbYTBWZgu3Nipy5OusojGMkObNNyvcT23Dl17chP5qEPTeYujUngeZFlObYXuLBZUTFCXZblWbayrMCyTc+NYTDbC2kYx2EIf1EP1gDDOa7vBzFxo8SO3dgmEUk90wmtiJrUtokThvWy3MiBxolnUXuezmPXNokfWjS1YzuGRcW+GVhp4BK2LARft4wFWiVPuSjgd4aM/+a3is75NUFjlWO+HgEuiai+ASEtuC4InRwFOi87AVz6psiQ9aAtY9wA/Ve2INaiyEpDnKaxoQUMcF0C9xMVKfJCJFXxVL9WlYk04ddmki+TxypAwRBxybCQWUUFIC0M97e83L7YbUF4gTDAC5gvuVC62NvrdVnuaPGtlG2MvWh6VeiNqScp7z6c2KoZZE13BTLlbiEFTWOsqwCT/JUlOjm2aCEEApqzeGUEDPsr3r1R70P8802dE3PR+F7dpfjooLv1pDReVhrYYZ0x54P3lH81u4LoaX4AZmearSha1CT5hv/RbCHSzJdcy2x+h+jbrK3xgvGq10JR1333Bkz6BvI0G4lNfUvKD5yy6m01G1Z+dtHjJV2ttGVF2kx7C0OLjLblx1bbCvG4dJDCQChdSoUQ7fd8OK3EoPyKGk3UNH3kJBlipcLBK+lR96iaXWiHrtZ86MjqeO/Wm12Extcu3h5SseTlwtAVLHmr+7jyzeA9moUxcGDPXj4XOgl3VC2MATR49lY2lvYgTN5Au3Z9BQW3xVcRN7IWhiT4usua6wnlwqgIfir0igzgeyQEDgEpdK5AhaeB976Hqy8cAdCjgXoAYBvAfdmov8DSnoR37i0o/lODcb/nqisCP2/7BQQfalm9uM+WGc330vqw5/6Tcu6LRbs2VOXc7rqC2GGL05gwVnfWPZTuin9Lp9JF+UNOhlmTWxC6wHUUE/+i2UIQT+0gmIlPJnXfTidpRuPU6pSPcMzdCiAKiXfbagicF0hxVVS4U9bP1j6rBCHKD5b0WttV7d02r+Xy/hJYMgyt6cUQ6HQIg5bPYbxTMSB83oayuHyDZ4M1WQ67S9u7Vc01p1M5xUC3QyCUgtZ7pcOwLBXfPVNR8ZdfWlCUKMfagjX95LLCyxZ2FRTE/ppZuuLyeOViO9EUo6tCDqB0g06PkRlldUqSNJicPArZYhrn5+eM/PhFHqbSV9OA+KXnMYYpgJcYBGsmCYxUvXoihF3M6gFfKJhrXBFmFOQboQmjYcBq0u027wuSUOaMgQZoafCCenkJmo8y3LfqvaIrUMyFF4asVmLFa/TcGNLhGCEoELZMnYB/V2QtxxMii2HFUiYeK2wRb8KmKt/j7mbF9dxkYGzrksd1tEVN2+UuSxbGrhLiDCEl5laNmPd3YQgLSS3Ywj27i8qP06jtwn27nS9VbspKrHWZaVNx1gQL2iSxhPO8zkQsKm3fRa4ZV+ubbXG7JDGbazAXUSC/6slpr4Cl1HFdVvF49iq7hwSIJPx7Pl52vfY9R9eOIGn98RpffGOTzBfJMVVsY3KqbFpHym+xqAjQKSMF2XCKLlBB4dFt85peIa5cGN/zbGVGX/V4LGGcEZe47/TSQAs3L25FDJAmoiZlw8v/lM3FNcGa8CbMbjmr6U9JjOKrqPbZT5DSujEYKPqM+8MRHzg4GoaLBXK7CQO55Nor+p7EGL/hHJs3w7spsiIDwutw/q0JkXSgX43LIcgiJptdASyRvjtpx2x6WL0GbfZhTM3MJcaw8jNkXdU3RWe2tPGMFPSdpygYxNIUXv16ayQ5LZkTnCTXrDDqR8oa1xYfigDEQg5gllXAmwg19RCUUS3Oz4Y8yIYaevsruapKYUcNSMUqg67wUtNDsKY+iEG04WvagzZNXUZiPqOFs0+E9Acu/5NhfdNOanb59VAHY/IodNGxk2E0yrBms0vLDtrArXJFQA7y+CKW3rzoNqI/icwm1Kf5cmbys8kvzG/9S3vwCnJV3hprN1WWdlbLZYq70I7BdlQtkFWjZI3PLvRt+9yri8XrNQvcveHzd3vftbSGu/YULLakAEOzWlCGMdYAtAlHcqf9PiVApqyBQG74TDmup4ali7sjBfB9Kz3xQwGb2W59A8o6cDFJKNX2Rb+z9rB3WmxXSK0b7OrB9OqIOWrzy22Azz/sgh/VA2dF9lQM/p7Gz3bB8/vb4GLsheAm4myZ6lgkdPnPsg5ZgrARONhVhQR36twe5JqrmGRyKn6Z8k7SslYxumXBNYS+zjuAjFAd7BijrVnmrbbc5GZ6LTYOOCKqd6XcOq7i+o9gomq3rVio991xM9+DJ8sJRZL7VV6ff92/bdAhGjsVU6H+isaQgQXSL9BeREeDjGcBf6Q/GWAJXtFVAv+rzMcWIDn+qSVoW669SaNiSfs2sIqu23z5kcaTU4nSIkPyZ6NCPzbnXfss2FgsMH69weQgPAn+2Yqu4c/nhjVfOoF7DMQ7mTY1mkmiH/QMcHprMQ/GMXpdJIyHqEwCr1t0+QPHMXTu4BgVrfY6WnihkMt2P+5gm5zp+UpbxZrx4s6Ts5looCH3qk4vi1cDU8BqVmATcq1H9Ot+2TwTODq2YHGbXLbWjTDYETfa6ic+Guy2KbJ1nG1AGeYBIkwJglUiTjR2Ubc7dCf13Xk5hsjJVS/M48992EKSlVtY0FbBUjxkvoBhfii90KdDbmjudeT6IPvuou3G7roMeVmA0wZqTPmKNHLoMHyWWR59VKXxV/arn9KRucBLXUfGnhtVFjQa6hDpCopiaAEExXQzVpiiHnOidbK25So3Kf6COKXaFLLKw+lpa8IKJlwYVb7i+2BcVdFLXP9rVyIaZI49Z6gK4w4zlNjYC9f7u+cbUHoE73yF0a0B1HpT9/PONzaqc85Xv3ZWr2QngILLX0f52agTGbEASGPxnBzNmVrU50hDu0YXUR0BwD2AI60VN6sJ1UVflKLMnEl3j0qwViH6Wp7HwXSASWv/dXEhUedMJ0M780/UYi1yNWppItgQN6q0BN2CsN5hANbQpPvGArNk2waPjjtcPteZcY1s0a4Xuk6xZVvq+ZJf9QCxpuy4IwhOe2DZEJcNwDZwg6kj7aPtLYozWANPr+e0U3rbK6gjbfo1aAi8qhZ6ymeZNkSq/EuCSDuzEAGf+1T0U2AIjuFO9+se/8ZBvOOlICBDuh+SHSpkhrw3pQGTxgFRidQp96XwlWq5Sfs68J2eRx0lddATeDjLF7bi0a5BheFWvfdD7e6eewJJLqVye436YlWtCmjakD+fUP+Vvu/dmfpswtBbZGMS55jEed8kTvGPmvFduz0ad/5f8ib37f4N99KPKaRjCumYQjqmkI4ppGMK6ZhCOqaQjimkYwrpmEI6ppCOKaRjCumYQjqmkI4ppGMK6ZhCOqaQjimkYwrpmEI6ppCOKaRjCumhKaSVnca7AQyHAlmLBW7pY5bsZF4WcxudHR4KZ7WW60UqUx+1veYwA0qBWDdXCoa29uxPy6lReVT3A24YTGLlEzG/mk0xZuWOWbm/q6zcx8H0MV93zNd9BPkDVpnqlSLJo4uh31eCcGsjymKnRu+2xtzh30fuMHKJNs4JznEwf+ZHuRTemgaqT4UpzqY5NNF4KFFJaXpY2vHwYKJhI7/v/unVR+1yTKf+LaRTD2VO91kA6o9Mru75Vs24HmrSkyhQNVJJqttkTN7+fSdvH6gq7MnqPlxO/1YTvg+Ewx71jb8Fpe34G00h/0R1mncbdCpXlaIPq9YMP2q1ZnuemmEaei4J4jhJyNwKYsejsR+ElEZ+knhhHHhpFNlO7KYkmDuWl1DqmbZjpk7i12WRw3lsUyuIqOXPLerGgZUQ041SzwwsYkWJ5zuW45heT7Vm22xUa07iJPCCxI8iywocGsEiEj91YXYXprETJ7Q9J6I+ddIkMSOTpKYZ+i41PSewqVJE2oxNL/bd0PJiJ/BCL07DgNh2NPc8WC6Zz2MciUa6as0YN30qHo/hT61UdfRZpH0mrwJUmCpz56TTkofHeZ4/DISvBhj0Iy1ujfqF38p/NxOqMRBFuc2TW5aTwBJh86IUT7iwZJhqPBzh/LvXf53KBBvl3Rels0Fgrg0G+OuXglL+mI3+zsCXIIPfkJvurYGHXCjgKfMvirj74d/Rt/s5Lh80en2TA/BvD72xoGaKP/h2w+DFhEaGe3NrByf0V0FrbWb/4XcBxEMsx18eOLhHM2X+/tcE+q4C6NL9WdK5kocg3nbRPLotkL/SzxtvMmGOAtDYmt5UeT9GQsu4yDZIhSlLichK9pSCJEBJxsoLFKnmaabytsRcuAn/6+3/e8tzkJagiqHRgjQjBsKHbfjTmvUrTmIPdI1Zd08mMMHzS8OcGu9O5CrqsAIOCxK+++YUZnMoXEusSIndrKmM31R7nlXvKVT7ERAUin5BbpYAalgRKY3Msc+Y9LzrHkn9Wo/mVHpOtvGc14a9eNWFlPr0yZbFN1mbtOTvfC1r7zBevSL4GNbJOY5w/jMMeXeOndiDa/XbET3LUXWSTSPLDFM8WVS2b2o5JQD9/AMFcK/OgaUk+fW56Aor+EsnDS+77uTfZett3niRSL6NxuKGy20WfygXDBDtEGy5WYEKwp7kg8kAddpD5x+WebFEx8zkF91TdS2ENyrAtcaxWn/ziW+uMpDAGxJ3cwrX26uJFd53OWzjBtu4bjUbUpS0fuapws50LRMwJt38UR2O9gmpCkkBcfraSKu4/dxVJ8GxR6a1tWF8P3VhNGWZzjDTvTiHDIzpQuIc/1SqD9BxvUj7nNZi4Lk5jdG7qeihydhaBpk+C3Nx+Jtu3YzagdfdZBotuuhYRHYhQrmdNlzN6m2krrv1ktjZX/QcULzy1LpKdIjshYF1GCmGOkDci5UNZETVTycKybwUyz3syot+x8odtUP2Pqzj/GaA0M0fVHhKq+PgvbFfbzuN5/74q0rDz/0N38oRL2epry0d9cBk57rOMfdtZI4fszn4PRvmBRL71rFBzi6b7F778B/zLKpZVlabXZ11uQnPbG0sqO0nvusmKU7EMVRcQ09CrNUz3kR7UdD4s/GWgvH4Z+NPKJCzWIz39tDGz8XZMVMXOhXxs0PvGMpUCSXhfTGIkIjw3D684nee/zvP1n8DRWhFn3VTMSv0bXQBHeJmPbnOQZZVd3gGEvB7eLH6RPEfArzdt3IPAa8mTNvM/Lo0WBZmJ0MFJzkixxU7idsL4nZblzg7+a/WmaaRekHl0AzWjn++vUd0xV3oU37lourESeGg6c2cPOUb/YSLF+4omcSi5MT++dKwWs11CXNyiLP7rUh1parvx7bM2AGYt5jsuxOBHM28RbzsRjGpjr+iDcchosHKZZ2B+TmWYp5f/gEt7ncnaCJfkxUaikpennFD5N2a1S3Aa72t7etOToSe37Rfrx9ZzshyjmY5YM19zW+AKi/GgzUnkGtWqV4yh/drg6zYW+dGHrN4S/vOG94e445nvI45Nf7JC+BUlDTlV1bxLlD9/i7MmJKowLgJTNq+saeeq+7NVGHIzT2zE+4DOuqwxl+JgazycqvQO8uHPpSNdLivYCrsYdbOOprv2cLUEk9FgKDkt64wqabOC9Yv5AC+w8dc3hQ5K+fB1OzjCk40ecnpoYykXTHj9CF2btOQqe0SLnHFHEtpnUhrwmiZKTU3kemzjasOXHOvOld3EurHZ6U8ra5JY2LpZldesdTSdydPhVZZS4c2qshb7fUlD53sFQwCp+488NvM/z1yAw9cjq1fDsIUTWKqyb7Hj5UxRC/2sfLSNgEJHDFEhbFU9+DBTkAxQ8sBOMvW+BjxpEODdTD53UnXpdrWivD/TyY/vzvhUXU84AWWywF1ALgshnHBroUP7xqVPx4AcwafHgRoPG2sJXb11iVX/MpdVG6zLSsyVg6pHkOaRlexeDRmcD/HT5MrCMcL4OCws6bKPdJ6OuTl1h5PR5P6ZGN5q0lDcSyZqRbqh5EHe8WccWyR/cez1+R0mrqgvUls705kslTjkmZPzprEcEYX0mEuX94GHWCSZnSV4K2ZzYrE9BrzN/BW5A/1yHibKr6i1wQG0BCR3fCfYMaK5KX69uIy0Dev3rz49vXXX7V715bNYdO1+IA4sM791e5AA3XlFos8XfKHziPYD0jvAtiQeimhwRaG1sNz1WAazNF5vDXx8e63JFXWHbAmAYCnEuefKufbP+cJonQPAlR0UK35R23yeHWttkrvFYR+0XS9QaMfGBr/aFyqiHywgseIkZZPNAmHh/B2sQbO3Xuup/bndQF6UKWSG9diFeHXuofd0T4lmFojMIAsjJ/Zv3c6ffOuKe93m1VOkga8RUP5zQ8tMftji/0dLlR7BKnmHA6Bv1xf5wAUwL8S9T0nSwnRMyWe/gWguCyLADx5m8f5quTlbkSOj0jy5Vk7rC4oyymoko9mGq/8coepDsmwW/5gGAiHqKZ+3yElVupY/V+6BmM7oChVMCWICKo3JkkZ5U2GgotUIWOsKdSyGA+OKbaibPLn4DjhAdHBHnSo6VCcejsM1qqG0EGa4w+6tlVE8ZHLTvjifijRX87lVJ3vU0FiQHvF3NIE00lEbqao25s2L6YwRP5P8Z4pmahMW63TR75UIoQHutd2c/dY/5q+voXT9pRhea+bXDrLWK1k/H98xQsLsULKBk+YPMfrTTNWDSyt3Cyd0VReyfIRNle3ZQasv0IC+JXfRsfx31Z+KawYlW1bHCRL1U1cXhqOtoJGDWcgBczFXU/Mjhfu7leu69GSWL/7wh6HnUUvzxK7EHn9YlEcs1AWay8ItAerjqJjOmuy6BsVQ86GkaF31dWM06pqSV+CvRwjgo2itixoKlVuZaLlxqsyEFGiabvFOgTMr9Rw9mmLm/9Rcp41dYvlPTy1rHYny54VLVYkD9Yvlh3KVb4tL8aM6jGjesyoHjOqx4zqMaN6zKgeM6rHjOoxo3rMqB4zqseM6jGjesyoHjOqx/TGMaN6zKgeM6pHljNmVI8Z1WNG9ZhRPWZUjxnVY0b1mFE9ZlSPGdVjRvWYUT1mVI8Z1WNG9ZhRPWZUjxnVY0b1mFE9ZlSPGdW/l4zqoVrfP979f/8/rKS+FjmTAgA='
INPUT_GZIP_SHA256 = '11d6f6047825235036f136a1c09e07a953631a4157c78a17dae691509fee567f'
INPUT_JSON_SHA256 = 'cb10037ddf2abfeada4698ed17afe2edb028d7b2c96112311a37ceb84dbfc423'
import base64
import datetime
import difflib
import gzip
import hashlib
import json
import os
import pathlib
import subprocess
import traceback


RECORDS = pathlib.Path("/home/qian-qi/hepta-learn-037c-evidence/format-published-current-v1")
EXPECTED_SOURCE = "57b27c81d0d5321b873ee751fd0e58e1d905b988"
EXPECTED_TREE = "3db894ee96d358c583bbf4ea15163a0d2bd96258"
EXPECTED_RUSTFMT_SHA256 = "342c3d56e8958da0b108108a39e37ceac64ebdd42e6eefafa237d219e5b7eb0c"
EXPECTED_PATHS = {
    'codex-rs/hepta-agentd/src/circuit_feature_current.rs',
    'codex-rs/hepta-agentd/src/circuit_feature_current_learning.rs',
    'codex-rs/hepta-agentd/src/circuit_feature_current_owner.rs',
    'codex-rs/hepta-agentd/src/circuit_feature_current_read.rs',
    'codex-rs/hepta-agentd/src/circuit_feature_current_read_support_tests.rs',
    'codex-rs/hepta-agentd/src/circuit_feature_current_read_tests.rs',
    'codex-rs/hepta-agentd/src/circuit_learning_read_owner_tests.rs',
    'codex-rs/hepta-agentd/src/circuit_learning_read_service.rs',
    'codex-rs/hepta-agentd/src/circuit_learning_read_support_tests.rs',
}


def meta(data):
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    }


def write_bytes(relative, data):
    target = RECORDS / relative
    assert target.is_relative_to(RECORDS)
    assert ".." not in pathlib.PurePosixPath(relative).parts
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)


def write_json(relative, value):
    write_bytes(relative, (json.dumps(value, indent=2) + "\n").encode())


def add_patch(parts, path, before, after, original_exists=True):
    if before == after:
        return
    parts.append("diff --git a/" + path + " b/" + path + "\n")
    if not original_exists:
        parts.append("new file mode 100644\n")
    else:
        parts.append("index " + meta(before)["blob"] + ".." + meta(after)["blob"] + " 100644\n")
    parts.extend(difflib.unified_diff(
        before.decode().splitlines(True), after.decode().splitlines(True),
        fromfile="a/" + path if original_exists else "/dev/null", tofile="b/" + path, n=3,
    ))


compressed = base64.b64decode(INPUT_GZIP_BASE64, validate=True)
assert hashlib.sha256(compressed).hexdigest() == INPUT_GZIP_SHA256
payload_bytes = gzip.decompress(compressed)
assert hashlib.sha256(payload_bytes).hexdigest() == INPUT_JSON_SHA256
payload = json.loads(payload_bytes)
assert payload["source_commit"] == EXPECTED_SOURCE
assert payload["source_tree"] == EXPECTED_TREE
assert len(payload["files"]) == 9
assert {row["path"] for row in payload["files"]} == EXPECTED_PATHS

# Create only: an unknown acknowledgement must be reconciled by the same h key.
# This driver has no checkout, Git, Cargo, target, source-owner or native-test access.
RECORDS.mkdir(mode=0o700)
write_bytes("input-payload.json.gz", compressed)
write_bytes("input-payload.json", payload_bytes)
write_json("input-manifest.json", payload["input_manifest"])
write_json("format-method-provenance.json", payload["format_method_provenance"])
files = {}
for row in payload["files"]:
    path = row["path"]
    assert path in EXPECTED_PATHS and path not in files
    original = row["base_utf8"].encode()
    before = row["before_utf8"].encode()
    assert meta(original) == row["base"]
    assert meta(before) == row["before"]
    files[path] = {"base": original, "before": before, "origin": row["origin"], "base_exists": row["base_exists"]}
    for category, data in [("base", original), ("before", before), ("postimages", before)]:
        write_bytes(category + "/" + path, data)
write_json("before-format-manifest.json", [
    {"path": path, "origin": item["origin"], "base_exists": item["base_exists"], "base": meta(item["base"]),
     "before": meta(item["before"])}
    for path, item in sorted(files.items())
])

environment = os.environ.copy()
environment["RUSTUP_HOME"] = "/home/qian-qi/.rustup"
environment["RUSTUP_TOOLCHAIN"] = "1.96.0"
rustup = "/home/qian-qi/.cargo/bin/rustup"
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
toolchain_steps = []
command = None
rustfmt_binary = None
rustc_version = None
rustfmt_version = None
returncode = None
error = None
raw = b""


def toolchain_step(arguments):
    result = subprocess.run(arguments, cwd=RECORDS, env=environment,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    toolchain_steps.append({
        "command": arguments, "returncode": result.returncode,
        "stdout": result.stdout.decode(), "stderr": result.stderr.decode(),
    })
    write_json("toolchain-steps.json", toolchain_steps)
    result.check_returncode()
    return result.stdout.decode()


try:
    tool = toolchain_step([rustup, "which", "--toolchain", "1.96.0", "rustfmt"]).strip()
    rustc_version = toolchain_step([rustup, "run", "1.96.0", "rustc", "--version", "--verbose"])
    assert rustc_version.startswith("rustc 1.96.0 "), rustc_version
    rustfmt_version = toolchain_step([tool, "--version"])
    rustfmt_binary = meta(pathlib.Path(tool).read_bytes())
    assert rustfmt_binary["sha256"] == EXPECTED_RUSTFMT_SHA256, rustfmt_binary
    command = [tool, "--edition", "2024", "--config", "imports_granularity=Item,skip_children=true",
               *[str(RECORDS / "postimages" / path) for path in sorted(files)]]
    write_json("rustfmt-launch.json", {"command": command, "cwd": str(RECORDS),
               "RUSTUP_HOME": environment["RUSTUP_HOME"],
               "RUSTUP_TOOLCHAIN": environment["RUSTUP_TOOLCHAIN"]})
    run = subprocess.run(command, cwd=RECORDS, env=environment,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    returncode = run.returncode
    raw = run.stdout
except Exception:
    error = traceback.format_exc()
    write_bytes("failure.txt", error.encode())
finally:
    write_bytes("rustfmt.raw.log", raw)
    combined = []
    formatted = []
    before_patch = []
    after_files = []
    changed = []
    complete_postimages = []
    for path, item in sorted(files.items()):
        after = (RECORDS / "postimages" / path).read_bytes()
        assert (RECORDS / "base" / path).read_bytes() == item["base"]
        assert (RECORDS / "before" / path).read_bytes() == item["before"]
        after_files.append({"path": path, "origin": item["origin"], "base_exists": item["base_exists"], "base": meta(item["base"]),
                            "before": meta(item["before"]), "after": meta(after)})
        complete_postimages.append({"path": path, "after": meta(after),
                                    "content_base64": base64.b64encode(after).decode()})
        if after != item["before"]:
            changed.append(path)
        add_patch(combined, path, item["base"], after, item["base_exists"])
        add_patch(formatted, path, item["before"], after)
        add_patch(before_patch, path, item["base"], item["before"], item["base_exists"])
    assert {str(path.relative_to(RECORDS / "postimages"))
            for path in (RECORDS / "postimages").rglob("*.rs")} == EXPECTED_PATHS
    write_bytes("published-current-prefmt.patch", "".join(before_patch).encode())
    write_bytes("combined-published-current.patch", "".join(combined).encode())
    write_bytes("format-only.patch", "".join(formatted).encode())
    postimage_payload = (json.dumps(complete_postimages, separators=(",", ":")) + "\n").encode()
    write_bytes("complete-postimages.json.gz", gzip.compress(postimage_payload, mtime=0))
    manifest = {
        "source_commit": EXPECTED_SOURCE, "source_tree": EXPECTED_TREE,
        "source_binding": payload["source_binding"],
        "input_json": meta(payload_bytes), "input_gzip": meta(compressed),
        "rustc_version": rustc_version, "rustfmt_version": rustfmt_version,
        "rustfmt_binary": rustfmt_binary, "command": command,
        "started_at": started,
        "finished_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "returncode": returncode, "error": error, "raw_log": meta(raw),
        "files": after_files, "format_changed": changed,
        "input_files_preserved": True,
        "checkout_access": False, "target_access": False,
        "native_tests_run": False, "ordinary_route_complete": False,
        "qualification": "isolated Published CURRENT formatting only; no native or ordinary qualification",
        "artifacts": [{"path": name, **meta((RECORDS / name).read_bytes())} for name in
                      ["published-current-prefmt.patch", "combined-published-current.patch",
                       "format-only.patch", "complete-postimages.json.gz"]],
    }
    write_json("manifest.json", manifest)
    print(json.dumps({"records": str(RECORDS), "returncode": returncode,
          "error": error, "files": len(files), "format_changed": changed,
          "manifest": meta((RECORDS / "manifest.json").read_bytes()),
          "raw_log": meta(raw), "artifacts": manifest["artifacts"],
          "complete_postimages_root": str(RECORDS / "postimages"),
          "checkout_access": False, "target_access": False}, indent=2), flush=True)

raise SystemExit(returncode if returncode is not None and error is None else 1)
