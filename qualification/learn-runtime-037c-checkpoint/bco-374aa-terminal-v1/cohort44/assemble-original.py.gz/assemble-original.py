import base64
import copy
import difflib
import hashlib
import json
import pathlib
import re
import subprocess
import tomllib

B = pathlib.Path('/tmp/hepta-learn-037c-20261112')
R = B / 'bounded-read-cohort-d397-v1'
OUT = R / 'bco-prepared-v1'
OUT.mkdir(exist_ok=True)
BEFORE = OUT / 'before'
AFTER = OUT / 'after'
BEFORE.mkdir(exist_ok=True)
AFTER.mkdir(exist_ok=True)
PARENT = 'd3977d9a1bed3e89952c576c45660b04ea674faf'
TREE = '57558558841da4a3209164d0033b903a553205d6'
BP = B / 'recovery-b-panel-training-proof-57b-formatted-v1'
CP = B / 'candidate-published-current-57b-v1/delivery-v1'


def meta(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def normalize(value):
    if value is None:
        return None
    value = dict(value)
    if 'git_blob' in value:
        value['blob'] = value.pop('git_blob')
    return value


maps = {}
for area, prefix in [('root', ''), ('src', 'codex-rs/hepta-agentd/src/'), ('b4', 'qa/b4-no-bypass/'), ('github', '.github/'), ('workflows', '.github/workflows/')]:
    tree = json.loads((R / 'original-trees' / (area + '.json')).read_text())
    assert not tree['truncated']
    maps.update({prefix + x['path']: x for x in tree['tree'] if x['type'] == 'blob'})
files = []
seen = set()


def add(path, before, after, expected_base, expected_after, component):
    assert path not in seen, ('overlap requires explicit review', path)
    seen.add(path)
    original = maps.get(path)
    expected_base = normalize(expected_base)
    expected_after = normalize(expected_after)
    if expected_base is None:
        assert original is None and before is None, path
    else:
        assert meta(before) == expected_base, path
        assert original is not None and original['sha'] == expected_base['blob'] and original['size'] == len(before), path
        p = BEFORE / path
        p.parent.mkdir(parents=True, exist_ok=True)
        if p.exists():
            assert p.read_bytes() == before
        p.write_bytes(before)
    assert meta(after) == expected_after, path
    p = AFTER / path
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        assert p.read_bytes() == after
    p.write_bytes(after)
    files.append({'path': path, 'component': component, 'before': expected_base, 'after': expected_after,
                  'parent_git_verified': original['sha'] if original else 'complete parent tree confirms absent'})


bm_bytes = (BP / 'VERIFIED_MANIFEST.json').read_bytes()
assert meta(bm_bytes)['sha256'] == 'f10a97f3c3b4df3ed80594ee56f74d80eaa41624f114e041c141bd437021a350'
bm = json.loads(bm_bytes)
for row in bm['files']:
    path = row['path']
    base_root = B / 'cohort-repair27-v1/after' if row['base_commit'] == PARENT else B / 'recovery-b-panel-training-proof-57b-v2/base'
    before = (base_root / path).read_bytes() if row['base'] is not None else None
    after_path = BP / row['local_area'] / path
    add(path, before, after_path.read_bytes(), row['base'], row['after'], 'B actual same-call panel Training')

cm_bytes = (CP / 'MANIFEST.json').read_bytes()
assert meta(cm_bytes)['sha256'] == 'bda39a359e1159f4463ed27f0db7d96bd34d5d1fa4f3276ffdb42f8b6d649619'
cm = json.loads(cm_bytes)
for row in cm['files']:
    path = row['path']
    before = (CP / 'base-after-repair' / path).read_bytes() if row['base'] is not None else None
    add(path, before, (CP / 'postimages' / path).read_bytes(), row['base'], row['after'], 'C actual same-call Published CURRENT')

rel = 'codex-rs/hepta-agentd/src/circuit_evaluated_version_support_tests.rs'
fetched = json.loads((B / 'root-maintenance-d397-v1/PARENT_FILE_FETCH.original.json').read_text())['structuredContent']
before = base64.b64decode(fetched['content'])
after = (B / 'root-maintenance-d397-v1/originals/postimages' / rel).read_bytes()
assert before.replace(b'use pretty_assertions::assert_ne;\n', b'', 1) == after
add(rel, before, after, meta(before), meta(after), 'Actual d397 clippy postimage')

OP = B / 'profile-resident-origin-formatted-v1'
om_bytes = (OP / 'FINAL_MANIFEST.json').read_bytes()
assert meta(om_bytes)['sha256'] == '63205e566aadc3a4aea10c5b77eaa6ff40184d5ec558b91ce89dd8a07ea70dbf'
om = json.loads(om_bytes)
assert om['source_commit'] == PARENT and om['source_tree'] == TREE
for row in om['files']:
    path = row['path']
    before = (B / 'profile-resident-origin-57b-v1/base' / path).read_bytes() if row['base'] is not None else None
    add(path, before, (OP / 'delivery' / path).read_bytes(), row['base'], row['after'], 'Root private consuming origin before effects')

registry_before = (B / 'cohort-repair27-v1/after/CALLERS.toml').read_bytes()
assert meta(registry_before)['sha256'] == 'a7db9c047ed16b33a889fd95934e64b2268ff1c1b8d4225dc4b558968fddf757'
original = tomllib.loads(registry_before.decode())
expected = copy.deepcopy(original)
bd = json.loads((BP / 'CALLERS-DELTA.actual.json').read_text())
cd = json.loads((CP / 'CALLERS_DELTA_PLAN.json').read_text())
replacements = {'boundary': {}, 'protected_file': {}}
appends = {'boundary': [], 'protected_file': []}
notes = []


def replace(kind, index, before, after, component):
    assert index not in replacements[kind], ('row overlap', kind, index)
    assert expected[kind][index] == before, (kind, index)
    if kind == 'protected_file':
        old_forbidden = before.get('forbidden', [])
        assert after.get('forbidden', [])[:len(old_forbidden)] == old_forbidden
    expected[kind][index] = copy.deepcopy(after)
    replacements[kind][index] = after
    notes.append({'kind': kind, 'index': index, 'component': component, 'id_or_path': after.get('id', after.get('path'))})


for change in bd['boundary_changes']:
    replace('boundary', change['index_in_base'], change['before'], change['after'], 'B')
for change in bd['protected_row_replacements']:
    replace('protected_file', change['index_in_base'], change['before'], change['after'], 'B')
appends['boundary'].extend(bd['new_boundaries'])
appends['protected_file'].extend(bd['new_protected_rows'])
for change in cd['boundary_changes']:
    if change['before'] is None:
        appends['boundary'].append(change['after'])
    else:
        hits = [i for i, x in enumerate(original['boundary']) if x['id'] == change['id']]
        assert len(hits) == 1
        replace('boundary', hits[0], change['before'], change['after'], 'C')
for change in cd['protected_changes']:
    if change['before'] is None:
        appends['protected_file'].append(change['after'])
    else:
        replace('protected_file', change['base_index'], change['before'], change['after'], 'C')

od_bytes = (OP / 'CALLERS_DELTA.json').read_bytes()
assert meta(od_bytes)['sha256'] == '30de380896373ec65d849cf7d9172699333409a03a3b1b62bde7c101e4265beb'
od = json.loads(od_bytes)
assert od['source'] == PARENT and normalize(od['base']) == meta(registry_before)
for change in od['protected_replacements']:
    replace('protected_file', change['index'], change['before'], change['after'], 'Origin')
appends['boundary'].extend(od['new_boundaries'])

new_ids = [x['id'] for x in appends['boundary']]
assert len(new_ids) == 20 and len(set(new_ids)) == 20
assert set(new_ids).isdisjoint(x['id'] for x in original['boundary'])
assert set(new_ids) == set(bd['required_boundary_ids_add']) | set(cd['new_inventory_ids']) | set(od['inventory_add'])
for kind in ['boundary', 'protected_file']:
    expected[kind].extend(copy.deepcopy(appends[kind]))
expected['privileged_inventory']['required_boundary_ids'].extend(new_ids)


def scalar(value):
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, int):
        return str(value)
    if isinstance(value, list):
        return '[' + ', '.join(scalar(x) for x in value) + ']'
    if isinstance(value, dict):
        return '{ ' + ', '.join(k + ' = ' + scalar(v) for k, v in value.items()) + ' }'
    raise TypeError(type(value))


def table(kind, row):
    return '[[' + kind + ']]\n' + ''.join(k + ' = ' + scalar(v) + '\n' for k, v in row.items()) + '\n'


def blocks(text, kind):
    heads = list(re.finditer(r'(?m)^\[\[?([A-Za-z_]\w*)\]?\][ \t]*\n', text))
    result = []
    for i, match in enumerate(heads):
        if match.group(1) == kind:
            result.append((match.start(), heads[i + 1].start() if i + 1 < len(heads) else len(text)))
    return result


text = registry_before.decode()
for kind in ['boundary', 'protected_file']:
    spans = blocks(text, kind)
    assert len(spans) == len(original[kind])
    edits = []
    for index, value in replacements[kind].items():
        start, end = spans[index]
        assert tomllib.loads(text[start:end])[kind][0] == original[kind][index]
        edits.append((start, end, table(kind, value)))
    at = spans[-1][1]
    edits.append((at, at, ''.join(table(kind, row) for row in appends[kind])))
    for start, end, value in sorted(edits, key=lambda item: (item[0], item[1]), reverse=True):
        text = text[:start] + value + text[end:]

match = re.search(r'(?m)^required_boundary_ids = (\[[^\n]*\])$', text)
assert match is not None
assert tomllib.loads('x = ' + match.group(1))['x'] == original['privileged_inventory']['required_boundary_ids']
new_value = match.group(1)[:-1] + ', ' + ', '.join(scalar(x) for x in new_ids) + ']'
text = text[:match.start(1)] + new_value + text[match.end(1):]
text = text.rstrip('\n') + '\n'
assert tomllib.loads(text) == expected
registry_after = text.encode()
for key in original:
    if key not in ['boundary', 'protected_file', 'privileged_inventory']:
        assert expected[key] == original[key]
for kind in ['boundary', 'protected_file']:
    original_spans = blocks(registry_before.decode(), kind)
    new_spans = blocks(text, kind)
    for i in range(len(original[kind])):
        if i not in replacements[kind]:
            assert expected[kind][i] == original[kind][i]
            a, z = original_spans[i]
            c, d = new_spans[i]
            assert registry_before.decode()[a:z] == text[c:d]
preserved = []
for name in ['learning_original_owner_command_channel', 'learning_original_evaluation_host_profile', 'learning_original_evaluation_host_constructor']:
    hits = [i for i, x in enumerate(original['boundary']) if x['id'] == name]
    assert len(hits) == 1 and expected['boundary'][hits[0]] == original['boundary'][hits[0]]
    preserved.append({'id': name, 'index': hits[0], 'complete_original_row_preserved': True})
add('CALLERS.toml', registry_before, registry_after, meta(registry_before), meta(registry_after), 'Exact B/C/origin union preserving d397 three callers')
allow_before = (B / 'cohort-repair27-v1/after/.github/blob-size-allowlist.txt').read_bytes()
allow_after = allow_before + ('\n# Original B panel Training, Published C same-call reads, and private Root origins; exact reviewed inventory.\nsha256:' + meta(registry_after)['sha256'] + ' CALLERS.toml\n').encode()
add('.github/blob-size-allowlist.txt', allow_before, allow_after, meta(allow_before), meta(allow_after), 'One exact current CALLERS hash append')

parts = []
for row in sorted(files, key=lambda row: row['path']):
    path = row['path']
    a = (BEFORE / path).read_bytes() if row['before'] else b''
    z = (AFTER / path).read_bytes()
    assert a != z
    parts.append('diff --git a/' + path + ' b/' + path + '\n')
    if row['before'] is None:
        parts.append('new file mode 100644\n')
    else:
        parts.append('index ' + row['before']['blob'] + '..' + row['after']['blob'] + ' 100644\n')
    parts.extend(difflib.unified_diff(a.decode().splitlines(True), z.decode().splitlines(True), fromfile='a/' + path if row['before'] else '/dev/null', tofile='b/' + path, n=3))
patch = ''.join(parts).encode()
(OUT / 'COHORT.patch').write_bytes(patch)
replay = OUT / 'strict-replay'
replay.mkdir()
for row in files:
    if row['before']:
        p = replay / row['path']
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes((BEFORE / row['path']).read_bytes())
steps = []
for command in [['git', 'apply', '--check', '--whitespace=error-all', str(OUT / 'COHORT.patch')], ['git', 'apply', '--whitespace=error-all', str(OUT / 'COHORT.patch')]]:
    run = subprocess.run(command, cwd=replay, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    steps.append({'command': command, 'exit_code': run.returncode, 'stdout': run.stdout.decode(), 'stderr': run.stderr.decode()})
    assert run.returncode == 0 and not run.stdout and not run.stderr
for row in files:
    assert (replay / row['path']).read_bytes() == (AFTER / row['path']).read_bytes()
registry_review = {
    'base': meta(registry_before), 'after': meta(registry_after), 'old_boundaries': len(original['boundary']),
    'new_boundary_count': len(expected['boundary']), 'old_protected': len(original['protected_file']),
    'new_protected_count': len(expected['protected_file']), 'replacements': notes,
    'new_boundary_ids': new_ids, 'all_unchanged_rows_byte_identical': True,
    'all_old_forbidden_values_in_original_order_and_multiplicity': True,
    'all_global_authority_rules_roots_ignored_paths_unchanged': True, 'd397_three_callers': preserved,
    'allowlist_old_prefix_preserved': True,
}
(OUT / 'REGISTRY_REVIEW.json').write_text(json.dumps(registry_review, indent=2) + '\n')
manifest = {'parent': PARENT, 'parent_tree': TREE, 'files': sorted(files, key=lambda row: row['path']),
            'patch': meta(patch), 'strict_replay': steps, 'all_postimages_exact': True,
            'product_rust': 17, 'test_rust': 14, 'qa': 10, 'workflow': 1, 'registry': 1, 'allowlist': 1,
            'source_gate': 'not run on this union', 'native': 'not run', 'ordinary_qualification': 0}
assert len(files) == 44
assert len([row for row in files if row['before'] is None]) == 12
(OUT / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': len(files), 'patch': meta(patch), 'registry': registry_review}, indent=2))
