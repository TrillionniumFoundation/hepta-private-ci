## Problem

An independently evaluated negative Candidate cannot use the strict TrainingNoUpdate continuation. The actual E/D/T/B prefix, retained publication, original Selector and original C evidence need to describe the same Source and evaluated Candidate. Root also needs an explicit bounded Version/readiness continuation. A signed receipt alone cannot replace actual original-owner readback or grant publication authority.

## Current source

**Current commit:** [e403c45570ad313851ca71392625e5572882405f](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/e403c45570ad313851ca71392625e5572882405f)  
**Current tree:** `70e0953a49cb203acbed270a853fce2e72164a18`  
**Single parent:** `374aa919931e8ee5446b4ccdc49e651b7848cc5d`

This child changes exactly **four existing QA files**. It moves all original B/C mutation attacks to the actual consuming helpers, adds explicit old Individual-entry/physical CURRENT deletion attacks, and includes the new concrete helper functions in exhaustive guard/effect checks. All 35 affected original case names and all helper implementations remain. Actual scoped runs passed B's 14 cases and C's 21 cases, with every input unchanged. Both component patches and the four-file union replay exactly. Production Rust, CALLERS, the original verifier and all runtime budgets are unchanged; the complete Rust subtree is still `4533dfe04fdef2f4d6b43cdab7a40ff4ecb07e1a`.

**The preceding complete 374aa919 source run failed:** unittest ran 504 cases in 307.344 s with one failure and 14 errors. These were four stale QA helper locations/function-set expectations; the complete 132,992-byte log is retained with SHA256 `3682d185fb491d5f1963c2380075ed1a4a1c9ff267f6f63908877124b01ca037`. All 15,230 source inputs stayed identical, the original 600 s budget did not expire, and all 681 evaluated-command mutation attacks remained rejected. The four-file child fixes the actual affected checks; a complete source PASS on this child has not been claimed.

**Actual 374aa919 compiler preflight also failed:** `just fmt` exited 0 with no edits; locked/offline `just fix` exited 101. The compiler reports one E0308 in the new resident-origin test: an actual Training Readback connection was supplied to the Candidate fixture factory requiring an actual Training Command connection. The full 88,704-byte compiler log is retained with SHA256 `5dbc12212a6aa03037f5588662084a1e5d0de7b54497ae64b7c4a88ad7f716b8`. All 15,230 source bytes and Cargo.lock stayed unchanged; there are zero postimages. No native test ran. The narrow test-fixture repair is being prepared without changing the eight owner-origin pairings or zero-effect assertions.

The next complete source run will bind the formatted fixture repair under a new immutable child. Eleven-case native, full caller, five-crate and protected Root gates remain pending. **Ordinary qualification remains zero.**

### B/C and resident-origin product cohort


**Product cohort commit:** [374aa919931e8ee5446b4ccdc49e651b7848cc5d](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/374aa919931e8ee5446b4ccdc49e651b7848cc5d)  
**Product cohort tree:** `981c4675a6579dfd9748046d3d01a2268f11c36f`  
**Single parent:** `d3977d9a1bed3e89952c576c45660b04ea674faf`

This child combines the actual formatted B panel Training read proof, C Published CURRENT proof, private resident-origin prerefusal and the actual d397 one-line clippy postimage. It changes exactly **44 paths: 17 production Rust, 14 test Rust, ten QA, one workflow, CALLERS.toml and its exact allowlist entry**. Twelve paths are new. Both Root and an independent reviewer checked every existing parent blob and new-path absence against all eight complete Git subtrees; the 44-path patch replays exactly with strict whitespace checking and no offset/fuzz. The independently reconstructed whole tree matches the returned Git tree.

- B retains the actual first and last Training reads, the same original Source allocation, consuming call proof, all non-Training reads and original cancellation fencing. Five new native mechanism cases are registered; execution is pending.
- C retains the actual first and last CURRENT reads within the same original published owner and Task allocation. Only the concrete read-owner path can use the private consuming proof; public individual reads retain all original I/O. Two new native mechanism cases are registered; execution is pending.
- Root compares original registration and concrete role origins before authorization binding, queue or runtime effects. The new ignored Root test covers eight real owner/registration pairings and is added to the protected workflow's existing 32 exact parents. All existing names, package selection and runtime budgets remain unchanged; this new case is unrun.

The exact inventory now has **627 boundaries and 428 protected rows**, retaining all old forbidden entries, duplicate-row indices, authority rules, source roots, ignored paths and the three real d397 callers. The only new size allowance is SHA256 `cb874ec8c9cda9fbb00190eb4be47e4f2cbff2c68afb846d592b0dc9c645eb4a` for the exact current CALLERS bytes. Every prior allowlist byte remains.

Actual component Rust 1.96 formatting and scoped QA are retained separately: C 88 PASS; Root origins 30 PASS; B's six new cases plus the existing host security guard pass. These scoped runs are not a combined source/native pass. **The complete 374aa919 source and compiler attempts subsequently failed as recorded above. Their original logs and immutable input identities are preserved. Native, full caller and five-crate/protected Root remain unrun on this cohort.**

### Preceding d397 repair and observed gates


**Preceding repair commit:** [d3977d9a1bed3e89952c576c45660b04ea674faf](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/d3977d9a1bed3e89952c576c45660b04ea674faf)  
**Repair tree:** `57558558841da4a3209164d0033b903a553205d6`  
**Single parent:** `57b27c81d0d5321b873ee751fd0e58e1d905b988`

The preceding d397 child changes exactly **27 existing paths: eight Rust test files, 17 QA files, three caller entries within CALLERS.toml, and one exact allowlist entry**. It preserves production Rust, original tests and assertions, deadlines, stack and authority rules. All 27 parent/postimage pairs replay exactly, with no offset/fuzz. The original full-gate and compiler failures below remain retained under 57b.

The eight test changes resolve the observed macro imports, strict legacy-profile extraction, private test access and exhaustive Fault match. Actual pinned Rust 1.96 formatting completed successfully for all eight; five files changed only import ordering or formatting. Actual maintenance has now completed: `just fmt` exited 0 without changing inputs; the original locked/offline `just fix --tests` exited 0 after 7m 08s and reported no compiler errors. Clippy removed one unused `assert_ne` import in `circuit_evaluated_version_support_tests.rs`. The complete 98,016-byte log and the exact 763-byte patch are retained. Every other source byte and Cargo.lock remained unchanged. This is a successful maintenance attempt with one reviewed postimage, **not a clean exact-commit pass**; the exact one-line output is included in 374aa919 before native acceptance.

The QA repair was actually run as **147 PASS / 0 FAIL / 0 ERROR / 0 SKIP**, with all 293 inputs unchanged. Root independently verified every parent Git blob, all 147 original case names, the complete log and exact three caller appends. The complete original 600-second source gate **passed all 482 cases** on the complete detached d397 checkout: 316.646 s test time, zero failures/errors, and all 15,218 inputs identical before/after. The actual terminal exited 0. All 681 evaluated-command mutation attacks remained rejected.

### Original assembled cohort

**Commit:** [57b27c81d0d5321b873ee751fd0e58e1d905b988](https://github.com/TrillionniumFoundation/hepta-private-ci/commit/57b27c81d0d5321b873ee751fd0e58e1d905b988)  
**Tree:** `3db894ee96d358c583bbf4ea15163a0d2bd96258`  
**Parent:** `a96d1b821d10ed3d9e99dd06c5141f9f242ae318`

The original 57b cohort combined the independently formatted component outputs into one source: **109 Rust files, 13 QA files, CALLERS.toml and its exact size-allowlist entry**. Independent Git comparison confirms exactly **124 paths: 57 additions and 67 modifications**, in one child commit. Every existing parent blob and every new path's absence were checked against the complete a96 Git subtrees. Both complete and incremental patches replay with zero offset/fuzz and identical 122 source/QA postimages.

## Resulting behavior

- **Exact Source profiles.** Dataset v3 joins signed Decision fields to the original NDU snapshot, output/policy, Source publication, canonical candidates and selected action. Independent B uses the same exact Source checks. The complete signed RunStart remains admission provenance. V1/V2 freezes retain their original meaning. Signed-experience intake V2 preserves the Observer's independently signed measurement reference.
- **Explicit evaluated Candidate continuation.** Original S/C receipt and command owners consume the actual evaluated prefix, original retained Cell/Source transport, current publication and exact FinalUse custody. Candidate Selection/NextUse dispatch now has an explicit evaluated route with original Version/readiness channels. The legacy TrainingNoUpdate and Model profiles retain their refusal bounds.
- **Version and Root agree on the prefix.** Explicit evaluated four/five/six-cut profiles carry the real original Trainer and Evaluator clients through private consuming factories. Version progress distinguishes Pending from ReadbackAvailable; the latter requires full actual readback. Pending cannot manufacture CURRENT, initialize a recovered cut or issue a second Prepare.
- **Bounded live reads.** Each Current query still reads the actual host. A private connection may retain its verified immutable initial proof; a new cold connection must establish that proof again. Original frame, connection and lifetime limits are unchanged.
- **Training read transactions.** Source capture, actual native/Generator read, Source recheck, physical-tail recheck and fresh signature verification remain ordered within the original occupied lane. A private per-Source allocation identity prevents a proof from being reused with a new Source containing identical bytes. Cancellation leaves the blocking work holding its original permit and preserves consumed-channel and permanent-refusal behavior.
- **Root post-read custody.** A private non-Clone proof carries the actual same-call post D/T/B readback into the retained Candidate continuation. Full identities, Root gates, mutex ownership, freshness and original effects remain checked.
- **Source guards.** The preceding d397 inventory had **607 boundaries and 425 protected rows**; the shared 374aa919/e403c455 inventory has **627 and 428**. All 389 original protected-row indices, duplicate rows, and forbidden-marker order/multiplicity are retained. Authority rules, source roots, ignored paths and the original verifier are unchanged. The d397 repair appended its exact CALLERS SHA256 `a7db9c047ed16b33a889fd95934e64b2268ff1c1b8d4225dc4b558968fddf757`; the 374aa919 product child appended only its exact hash listed above; every prior allowlist byte is retained.

## Validation by exact source

| Check | Observed result | Limit |
|---|---|---|
| e403c455 four QA repairs | **14 + 21 scoped cases PASS**, unchanged inputs | Exact four-file child; full source gate not yet run |
| 374aa919 complete source gate | **504 cases: 1 FAIL / 14 ERROR**, actual exit 1 | 307.344 s test time; 15,230 inputs unchanged; original 600 s budget |
| 374aa919 compiler preflight | **just fmt 0 / just fix 101**, one E0308 in new origin test | All inputs unchanged; zero postimages; native unrun |
| Current eleven native / full caller / protected Root | **Pending** | Original budgets and exact per-source evidence required |
| d397 complete source gate | **482 PASS / 0 FAIL / 0 ERROR**, actual exit 0 | 316.646 s; all 15,218 inputs unchanged; original 600 s budget |
| d397 complete maintenance | **just fmt 0 / just fix 0**, no compiler errors | One unused test import removed; reviewed actual postimage retained; not a clean exact-commit pass; native unrun |
| Repair scoped QA on exact 57b products | **147 PASS**, 17 affected suites | All 293 inputs unchanged; full source gate remains separate |
| Eight repaired Rust test files | **Actual formatter exit 0**, complete postimages verified | Subsequent actual maintenance compiled test targets; native tests are unrun |
| Combined 13 source/mutation suites | **154 PASS / 0 FAIL / 0 ERROR / 0 SKIP**, 71.889 s | Scoped source checks; all 249 input files identical before/after |
| Final Version source suites | **57 PASS**, including the original 36 cases | Included in the combined 154; not an additional count |
| Actual component formatting | Rust 1.96 formatter exited 0 for every incoming Rust component | Component-level formatting |
| Central merged lib.rs formatting | **Actual exit 0, zero changes**, complete manifest independently read and checked | Uses the same pinned Rust 1.96 formatter and original configuration |
| Complete source gate on 57b | **482 cases: 442 PASS / 38 FAIL / 2 ERROR**, actual exit 1 | Original 600 s gate; completed in 301.385 s test time; 15,218 files unchanged |
| Complete maintenance on 57b | **just fmt: 0, zero changes; just fix: 101, 94 compiler diagnostics** | Original Rust 1.96; all 15,218 files and Cargo.lock unchanged; no tests started |
| Native on 57b | **Not run** | Compile failure must be repaired and verified on a new source identity |
| Full caller index on 57b | **Not run** | Original self-test 300 s / verify 4800 s budgets |
| Final five-crate and protected Root native | **Not run** | Original required packages, 33 protected Root test parents on current source (32 retained plus one new case), real UID0/protected bind |

The complete combined scoped log is **36,596 bytes**, SHA256 `a3c33e485c2ebd35c4efa393a5ba264eb2a577501b5d2cc8d1051f12be2007f8`. The exact source/QA input set, final caller proposal and all uploaded product blobs were independently checked.

Failed preparation observations remain preserved. The first actual Version run was 54 PASS / 3 FAIL because three mutation anchors still used pre-format punctuation; all three attacks remain and now hit the actual code. The first combined run was 152 PASS / 2 ERROR because its isolated QA overlay lacked one exact-a96 dependency file. Adding that original file produced the second 154 PASS run without changing products, QA, registry or verifier. These older failed records are not rewritten.

The complete 57b source gate subsequently failed with 38 failures and two errors. Most failures are exact legacy caller expectations; the two errors are mutation anchors moved into actual helpers. Further narrow checks also exposed three real missing caller entries (Training readback service and two original B factory calls). The d397 repair registers those actual typed calls and updates the affected QA, preserving every original attack and the original verifier. The complete d397 source gate subsequently passed all 482 cases. The failed 57b source log is 165,277 bytes, SHA256 `0f9cc0fa60ceecec68c0186ca6ce960863f9fff11101f775b6d78c320d8c4422`. The full successful d397 source log is 108,766 bytes, SHA256 `fc9122bc4c3b0f4047a10245ddcaa0d9f944d1ae7cef0e738e785707cc845cf8`; both original logs were independently read and hash checked.

Actual 57b maintenance then completed: formatting made no changes, while `just fix -p codex-hepta-agentd --locked --offline` failed with 94 diagnostics across eight test files: 90 ambiguous assertion-macro imports, two private-field/type accesses, one ReadProfile type mismatch and one non-exhaustive Fault match. The full 174,502-byte compiler log has SHA256 `e648b7429a7cca0bf37d7eaeffca18dc8b312e3854b628581a8c056ed8d751e2`. Source and Cargo.lock remained unchanged. No native case ran on 57b.

## Native failures and current diagnostic

The completed four-case diagnostic resolves only the three named cases on its own source. The C deadline failure remains. It does not replace the 109-case focused run or validate the assembled 57b source.

| Exact source | Actual observation |
|---|---|
| cc22 focused native | **109 run: 78 passed, 29 failed, 2 timed out**; 24 confirmed stack overflows |
| 4ab three-case diagnostic | **0 passed, 2 failed, 1 timed out**; Panel stack overflow, C evidence failure before withdrawal, Deep cold-readback timeout |
| 00378 four-case diagnostic v1 | **Zero cases**; missing original V8 input before checkout/fmt/fix/native |
| 00378 four-case diagnostic v2 | **Zero cases**; original target admission assertion failed before checkout/fmt/fix/native |
| 00378 four-case diagnostic v3 | **3 PASS / 1 FAIL / 0 TIMEOUT**, actual completed run; C failed before withdrawal |

The 4ab C failure was `OwnerUnavailable("original learning evidence owner")` after 501.905628 ms, with the server reporting `Transport(DeadlineElapsed)`, before withdrawal. The Deep trace started cold readback at 50.886 s and reached the original 60 s case limit. Its complete log/JUnit remain retained.

The separate diagnostic source is `00378c2e33ede95f4a93bf96f6d87b3bd415d337`, a five-test/diagnostic-file child of 4ab. It adds heap allocation at three observed Panel future boundaries and separates full hot/cold scenarios while preserving assertions. The completed v3 request retained the **8 MiB stack, 60-second case limit, two threads and zero retries**. It does not validate 57b.

The actual Panel case passed in 21.762 s, Deep cold readback in 49.821 s, and Deep hot readback in 50.835 s. C failed in 7.914 s: the actual client returned after 501.635604 ms while the original owner read took about 1.112 s. The server reported `Transport(DeadlineElapsed)` before the publication withdrawal. Fresh JUnit has exactly four unique cases, three passes and one failure. The complete test log is 57,429 bytes, SHA256 `a618f1ca01d4092310be10fdb14eacda614ea1da69d6885c680f022447ac9e1a`.

For v3, actual `just fmt` and `just fix -p codex-hepta-agentd --locked --offline` exited 0 with no postimages. All 14,995 diagnostic-source files and Cargo.lock were unchanged. Actual helper compilation then exited 0 after 704.669 s. No full native or ordinary PASS follows from those maintenance results.

The missing V8 archive was restored by a create-only copy from its original completed download after exact full-byte verification; no new download was used. The complete 3,094-byte restoration result has been independently read and checked. The v3 admission later observed the original target absent and created that original empty task-owned target without removing existing data. The reason for the earlier disappearances remains unknown.

## Retained evidence

- [Actual B panel Training proof, exact formatted postimages and retained scoped evidence](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/7f4a9f63b1b88f61ca7436a571cf923844c39eb7/qualification/learn-panel-training-037c-checkpoint/actual)
- [Actual Root-origin format/readback, source QA, strict replay and full originals](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/b3346f39c6d701d9e86d9a8b2c0e7eca4a37a892/qualification/learn-resident-origin-037c-d397-v1)
- [Ordinary A and resident assembly: exact existing input and implementation contract](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/b3346f39c6d701d9e86d9a8b2c0e7eca4a37a892/qualification/learn-ordinary-input-contract-037c-d397-v1)
- [Complete d397 482-case source PASS, actual test formatting, and maintenance with one reviewed postimage](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/15ac5a5e9a9c089bc58e2d884d652462f1b74904/qualification/learn-runtime-037c-checkpoint/d397-terminal-v1)
- [Original 93-file evidence package](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/b29869e856d08db1bfb066116a9c443376ccc57d/qualification/learn-evaluated-retention-037c)
- [Failed gates, repairs and complete cc22 source/maintenance evidence](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/639f894e088cdc5b30b65ed3732dcaa0a2fbe004/qualification/learn-evaluated-retention-037c-cc22)
- [Complete failed native/JUnit, GDB and prior repair evidence](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/90fd0f22cfdfd6c839ef5ba9c694e9189c51e947/qualification/learn-native-failures-037c-cc22)
- [Runtime requests, original failures, restoration and completed diagnostic evidence](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/a740ebd2164d47ddc109e424d05dde6164412d99/qualification/learn-runtime-037c-checkpoint)
- [Actual 57b source/compile failures and four-case terminal originals](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/a740ebd2164d47ddc109e424d05dde6164412d99/qualification/learn-runtime-037c-checkpoint/terminal-20261112-v1)
- [94-file cohort review, scoped QA and actual merged-lib formatting](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/48064bbf12188ff8113082db1684f3a97311a14c/qualification/learn-cohort-review-037c-57b27c81)
- [91-file exact source repair evidence, preserved failures and 147-case PASS](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/defa4b05db952b3256fcef2e87a7077bfdd96fbc/qualification/learn-source-repair-037c-57b27c81)
- [Exact Training outputs and recovered original guards](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/09b1839e5d1d00287651cfdfaf7a3c9197f0a6cd/qualification/learn-training-037c-checkpoint)

The primary execution environment was unavailable during part of the work. On recovery, the frozen source, manifests and guard inputs were reread with their original matching hashes. The completed cohort uses those original inputs. Recovery attempts and rebuilt alternatives retain their separate identities.

## Qualification and remaining work

**HOLD / Draft. Ordinary evaluated NoUpdate = 0; ordinary Adopt = 0; full daemon + Root cold recovery = 0; multigeneration = 0.**

The next acceptance target is complete ordinary evaluated NoUpdate plus actual daemon/Root cold recovery. Remaining work includes:

1. Close and measure the complete read graph under the original finite channel budgets, including repeated B-to-Trainer reads.
2. Finish exact-source native and full caller gates for the assembled cohort.
3. Supply and connect the actual Q24 A PublishedTask/CURRENT producer, the real role-host streams, and the ordinary launcher/resident handoff. The current ordinary main still uses its existing startup path.
4. Use the original Root issuer/Registry with the exact-purpose authorization and separately bound resident lease supplied by the deployment; public descriptors cannot reconstruct sealed owners or authority.
5. Prove whole daemon/Root cold restart with actual reopened originals and read-only recovery semantics.
6. Then qualify positive Adopt and ordinary C loading and using the new parameters, followed by multigeneration experiments.

Same-process cold fixtures, refusal repair, source guards and signed mechanism receipts each retain their actual scope.
