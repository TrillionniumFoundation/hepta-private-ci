import base64
import hashlib
import json
import lzma
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

root = Path('/home/qian-qi/worktrees/hepta-eval-recovery-173a-20261109')
evidence = Path('/home/qian-qi/worktrees/hepta-eval-recovery-173a-20261109-native/cell-attempt-02')
base = 'e2e20033daa67d9d9826d4942e4d6bdd15ba4ab5'
payload = sys.stdin.buffer.read(1048577)
assert hashlib.sha256(payload).hexdigest() == '0c59dd1974c9658ef0f58b2dcd177e942807ebb4b6c466662d51186ecd0bae4b'
rows = json.loads(lzma.decompress(base64.b64decode(payload, validate=True)))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip() == base
evidence.mkdir(parents=True, exist_ok=False)
for row in rows:
    relative = row['path']
    assert (relative.startswith(('codex-rs/hepta-intelligence-eval/src/','codex-rs/hepta-agentd/src/')) or relative == 'docs/modules/MODULES.json') and '..' not in Path(relative).parts
    path = root / relative
    data = base64.b64decode(row['content'], validate=True)
    assert hashlib.sha256(data).hexdigest() == row['sha256']
    if path.exists():
        actual = path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(actual)).encode() + b'\0' + actual).hexdigest()
        assert blob == row['baseline_blob'] or hashlib.sha256(actual).hexdigest() in {row['sha256'], row['previous_sha256']}, relative
    else:
        assert row['baseline_blob'] is None or relative == 'docs/modules/MODULES.json', relative
        if relative == 'docs/modules/MODULES.json':
            expected = subprocess.check_output(['git','rev-parse',base + ':' + relative], cwd=root).decode().strip()
            assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['baseline_blob'] == expected
            path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.173a-tmp')
    with temporary.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.chmod(temporary, 0o644)
    os.replace(temporary, path)
(evidence / 'candidate-files.json').write_text(json.dumps([{key: value for key, value in row.items() if key != 'content'} for row in rows], indent=2) + '\n')

def inventory():
    tracked = subprocess.check_output(['git', 'ls-tree', '-r', '-z', base, '--', 'codex-rs', 'docs/modules/MODULES.json'], cwd=root).split(b'\0')
    expected = {}
    for entry in tracked:
        if not entry:
            continue
        meta, raw_path = entry.split(b'\t', 1)
        mode, kind, blob = meta.decode().split(' ')
        if kind == 'blob':
            expected[raw_path.decode()] = (mode, blob)
    changed = {row['path']: row for row in rows}
    result = {}
    for name in sorted(set(expected) | set(changed)):
        path = root / name
        mode = path.lstat().st_mode
        data = os.readlink(path).encode() if stat.S_ISLNK(mode) else path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        sha256 = hashlib.sha256(data).hexdigest()
        if name in changed:
            assert sha256 == changed[name]['sha256'], name
        else:
            assert blob == expected[name][1], name
        result[name] = {'git_blob': blob, 'sha256': sha256, 'mode': oct(stat.S_IMODE(mode)), 'symlink': stat.S_ISLNK(mode)}
    return result

before = inventory()
encoded = json.dumps(before, sort_keys=True, separators=(',', ':')).encode()
(evidence / 'source-before.json').write_bytes(encoded)
env = os.environ.copy()
env['PATH'] = '/home/qian-qi/.cargo/bin:' + env.get('PATH', '')
env['RUSTUP_TOOLCHAIN'] = '1.96.0'
env['CARGO_TARGET_DIR'] = '/home/qian-qi/worktrees/hepta-eval-recovery-173a-20261109-native/target'
env['CARGO_BUILD_JOBS'] = '4'
env['CARGO_INCREMENTAL'] = '0'
versions = {}
for tool in ['rustc', 'cargo', 'just', 'cargo-nextest']:
    versions[tool] = subprocess.check_output([tool, '--version'], env=env, cwd=root, text=True).strip()
command = ['just', 'test', '--locked', '--offline', '-p', 'codex-hepta-agentd', '--lib', 'neuron_cell_evaluation', '--test-threads', '2']
started = time.time()
print(json.dumps({'phase': 'native-test-start', 'command': command, 'files_verified': len(before), 'source_inventory_sha256': hashlib.sha256(encoded).hexdigest(), 'versions': versions}), flush=True)
with (evidence / 'test.log').open('wb') as log:
    result = subprocess.run(['/usr/bin/time', '-v', '-o', str(evidence / 'time.txt')] + command, cwd=root / 'codex-rs', env=env, stdout=log, stderr=subprocess.STDOUT)
after = inventory()
(evidence / 'source-after.json').write_text(json.dumps(after, sort_keys=True, separators=(',', ':')))
summary = {'base_commit': base, 'command': command, 'exit_code': result.returncode, 'started_unix_seconds': started, 'elapsed_seconds': time.time() - started, 'source_unchanged': before == after, 'source_inventory_sha256': hashlib.sha256(encoded).hexdigest(), 'source_file_count': len(before), 'versions': versions, 'training_performed': False, 'independent_operator_qualification': False, 'production_adoption': False}
(evidence / 'result.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
print((evidence / 'test.log').read_text(errors='replace')[-12000:], flush=True)
assert before == after
raise SystemExit(result.returncode)
