set -euo pipefail
label="$1"
shift
source_args=(--kind "$SOURCE_KIND" --candidate "$EXPECTED_HEAD" --tested "$EXPECTED_TESTED")
if test "$SOURCE_KIND" = prospective-merge; then
  source_args+=(--base "$EXPECTED_BASE")
fi
python3 scripts/ci/record_pq_native_command.py "${source_args[@]}" --label "$label" --output "$PQ_OUT" -- "$@"
