"""Freeze only the exact source bytes that passed the original complete gates."""
import datetime, fcntl, hashlib, json, os, subprocess, sys, time, traceback
from pathlib import Path
BASE=Path('/home/qq/work/hepta-e6-first-error-20261120-2e9b')
SRC=BASE/'source';OUT=BASE/'read65-frozen-source-1'
PARENT='ab5e792d1bceb583c246f44d01ee8e433d5c60e8'
meta=json.loads(sys.argv[1]);commit=meta['commit'];gate=BASE/meta['source_gate_path']
def sha(path):
 with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=SRC).decode().strip()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def inventory(extra=()):
 names={os.fsdecode(raw) for raw in subprocess.check_output(['git','ls-files','-z'],cwd=SRC).split(b'\0') if raw}|set(extra)
 rows=[]
 for name in sorted(names,key=os.fsencode):
  path=SRC/name;raw=os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes()
  rows.append(dict(path=name,kind='symlink' if path.is_symlink() else 'regular',mode=path.lstat().st_mode&0o7777,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
 raw=(json.dumps(rows,sort_keys=True,separators=(',',':'))+'\n').encode()
 return rows,hashlib.sha256(raw).hexdigest()
def run(name,argv):
 started=time.monotonic();p=subprocess.run(argv,cwd=SRC,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 (OUT/(name+'.stdout')).write_bytes(p.stdout);(OUT/(name+'.stderr')).write_bytes(p.stderr)
 return dict(argv=argv,exit_code=p.returncode,wall_seconds=time.monotonic()-started,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest())
assert os.getuid()==os.geteuid()==1000
locks=[]
for path in [BASE/'native-component-owner.lock',BASE/'native-target/.hepta-root-native-owner.lock']:
 f=path.open('a+b');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
assert not OUT.exists();OUT.mkdir();started=time.monotonic()
try:
 assert sha(gate)==meta['source_gate_sha256']
 g=json.loads(gate.read_text())
 assert g['source_parent']==PARENT and g['successful'] and g['source_tests_successful'] and g['tests_run']==415 and len(g['modules'])==47
 assert g['protected_file_sweep']['passed'] and g['protected_file_sweep']['rows']==907
 assert g['targeted_callers']['passed'] and g['targeted_callers']['expected_boundary_count']==meta['targeted_boundary_count']
 assert g['full_caller_proof_exit']==0 and g['source_unchanged_during_tests']
 assert not g['failures'] and not g['errors'] and not g['skipped']
 assert sha(SRC/'scripts/verify_hepta_callers.py')=='1c2dadc1d631b4004a50c857cd41acd2e6827f775f2efdbd3cbb0d4a47781896'
 assert sha(SRC/'scripts/hepta_typed_callers.py')=='ff7a60b43b5954a6afea4671d78417b0eb65c3bbc997008bde2d8aad0cb4ab44'
 assert sha(SRC/'CALLERS.toml')==meta['caller_manifest_sha256']
 assert git('rev-parse','HEAD')==PARENT and not git('diff','--cached','--name-only')
 new=git('ls-files','--others','--exclude-standard').splitlines()
 assert new==['qa/b4-no-bypass/test_original_historical_operation_scopes_source_closure.py']
 paths=sorted(git('diff','--name-only').splitlines()+new)
 assert paths==sorted(meta['files'])
 for name,row in meta['files'].items():
  assert sha(SRC/name)==row['sha256'],name
  assert (SRC/name).stat().st_size==row['bytes'],name
 before,digest=inventory(new)
 assert digest==g['source_after_sha256']==meta['source_inventory_sha256']
 save(OUT/'SOURCE_GATE_RESULT.json',g)
 save(OUT/'GITHUB_COMMIT.json',commit)
 save(OUT/'SOURCE_FILES_BEFORE.json',before)
 (OUT/'tracked-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=SRC))
 subprocess.run(['git','add','--',*paths],cwd=SRC,check=True)
 assert git('write-tree')==commit['tree']['sha']
 assert len(commit['parents'])==1 and commit['parents'][0]['sha']==PARENT
 def ident(person):
  epoch=int(datetime.datetime.fromisoformat(person['date'].replace('Z','+00:00')).timestamp())
  return person['name']+' <'+person['email']+'> '+str(epoch)+' -0500'
 raw=('tree '+commit['tree']['sha']+'\nparent '+PARENT+'\nauthor '+ident(commit['author'])+'\ncommitter '+ident(commit['committer'])+'\n\n'+commit['message']).encode()
 assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==commit['sha']
 assert subprocess.check_output(['git','hash-object','-t','commit','-w','--stdin'],input=raw,cwd=SRC).decode().strip()==commit['sha']
 subprocess.run(['git','update-ref','--no-deref','HEAD',commit['sha'],PARENT],cwd=SRC,check=True)
 assert not git('status','--porcelain','--untracked-files=all')
 after,after_digest=inventory();assert before==after and digest==after_digest
 save(OUT/'TRACKED_FILES.json',after)
 unit=run('original-blob-policy-tests',[sys.executable,'-B','-m','unittest','discover','-s','scripts/tests','-p','test_blob_size_policy.py'])
 policy=run('exact-source-blob-policy',[sys.executable,'-B','scripts/check_blob_size.py','--base','d83f70f38137a99a86a3afd122199ba9cdae4f79','--head',commit['sha'],'--max-bytes','512000','--allowlist','.github/blob-size-allowlist.txt'])
 assert unit['exit_code']==0 and policy['exit_code']==0
 result=dict(successful=True,source_clean=True,scanned_inputs_byte_identical=True,source=commit['sha'],tree=commit['tree']['sha'],parent=PARENT,
  source_inventory_sha256=digest,source_files=len(after),frozen_at_ns=str(time.time_ns()),source_gate_sha256=sha(gate),changed_paths=paths,
  protected_rows=907,classified_boundaries=1159,verifier_unchanged=True,typed_matcher_unchanged=True,original_blob_policy_tests=unit,exact_source_blob_policy=policy,
  original_history_and_failed_gates_preserved=True,native_runs=0,root_read_cap=64,static_whole_fresh_parent_frames=63,static_budget_is_not_native_result=True,
  deadlines_changed=False,owner_wall_seconds=time.monotonic()-started,original_workspace_mutated=False,
  original_workspace_scope='Earlier operation-scope/cold workspaces are unchanged; only this isolated source HEAD is advanced.',
  isolated_workspace_head_advanced=True)
 save(OUT/'RESULT.json',result);print(json.dumps(result),flush=True)
except BaseException as error:
 (OUT/'ERROR.txt').write_text(traceback.format_exc());save(OUT/'RESULT.json',dict(successful=False,error=repr(error),native_runs=0));raise
finally:
 for f in reversed(locks):f.close()
