"""Run one frozen source through original 11/16, real delivery five, then NoUpdate."""
import ast
import copy
import fcntl
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

BASE = Path('/home/qq/work/hepta-e6-first-error-20261120-2e9b')
OUT = BASE / 'read65-native-pipeline-1'
PARENT = 'ab5e792d1bceb583c246f44d01ee8e433d5c60e8'
TREE = '9fd4268ef5ffd63661e067b6ee043f0e522e97ab'
CALLERS = 'c3ea4fcb0908af3d99953a464e612c9483265fdea5e24dcfc6dad757d771d6cf'
VERIFIER = '1c2dadc1d631b4004a50c857cd41acd2e6827f775f2efdbd3cbb0d4a47781896'
COMPILE_SHA = '8e66d9694399c538c714859dbe32b2c4221233e7dffec37fe59552c28482ed1f'
DELIVERY_CASES = [
    'historical_delivery_cancelled_claim_cold_reopen_never_redispatches',
    'historical_delivery_completed_claim_cold_reopen_returns_exact_head',
    'historical_prepared_claim_drop_before_dispatch_cold_reopen_stays_pending',
    'historical_prepared_completion_cold_reopen_returns_exact_key_and_bytes',
    'historical_prepared_completion_full_witness_keeps_exact_append_for_recovery',
]


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def status(name, **fields):
    result.update(status=name, **fields)
    save(OUT / 'RESULT.json', result)
    print(json.dumps({'status': name, 'source': source, **fields}), flush=True)


def original(path, digest):
    path = BASE / path
    assert sha(path) == digest, str(path)
    return json.loads(path.read_text())


def stage(name, driver, result_path, expected=None, leaf_names=False):
    row = {'name': name, 'driver': str(BASE / driver), 'started_at_ns': str(time.time_ns())}
    result['stages'].append(row)
    status('running-' + name)
    started = time.monotonic()
    completed = subprocess.run([sys.executable, str(BASE / driver)])
    row.update(exit_code=completed.returncode, finished_at_ns=str(time.time_ns()),
               wall_seconds=time.monotonic() - started)
    path = BASE / result_path
    if not path.is_file():
        save(OUT / 'RESULT.json', result)
        raise RuntimeError('Missing terminal stage result: ' + str(path))
    measured = json.loads(path.read_text())
    row.update(result_path=str(path), result_sha256=sha(path),
               successful=measured.get('successful'), source=measured.get('source'))
    assert measured.get('source') == source, row
    if expected is not None:
        row['native_cases'] = measured.get('native_cases')
        row['expected_cases'] = expected
        assert measured.get('native_cases') == len(expected), row
        assert measured.get('source_inventory_sha256') == freeze['source_inventory_sha256'], row
        # The original owner validates exact case sets and preserves full JUnit names.
        assert measured.get('all_native_passed') is True, row
        actual = [case['name'].rsplit('::', 1)[-1] if leaf_names else case['name']
                  for case in measured['test_cases']]
        assert sorted(actual) == sorted(expected), (row, actual)
    save(OUT / 'RESULT.json', result)
    assert measured.get('successful') is True and completed.returncode == 0, row
    return row


def deploy(name, protocol, driver):
    protocol_path = BASE / (name + '-PROTOCOL.json')
    deployment_path = BASE / (name + '-DEPLOYMENT.json')
    assert not protocol_path.exists() and not deployment_path.exists(), name
    save(protocol_path, protocol)
    save(deployment_path, {'schema': 'hepta-e6-read65-frozen-deployment-v1',
                          'protocol_sha256': sha(protocol_path),
                          'driver_sha256': sha(BASE / driver),
                          'source': source, 'automatic_retry': False})


assert os.getuid() == os.geteuid() == 1000
data = json.loads(sys.argv[1])
source = data['source']
assert len(source) == 40 and data['tree'] == TREE
lock = (BASE / 'actual-drain-complete-pipeline.lock').open('a+b')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not OUT.exists(), 'Unique pipeline namespace already used'
OUT.mkdir()
started = time.monotonic()
result = dict(status='preflight', successful=False, source=source, tree=TREE,
              started_at_ns=str(time.time_ns()), automatic_retry=False, stages=[],
              original_read_budget=64, authority_deadlines_changed=False,
              original_executor_mutated=False, original_source_and_failure_inputs_retained=True,
              static_fresh_parent_frames=63, static_budget_is_not_native_result=True,
              actual_root_observe_after_fault_tested=False)
try:
    freeze_path = BASE / 'read65-frozen-source-1/RESULT.json'
    freeze = original(freeze_path, data['source_freeze_result_sha256'])
    assert freeze['successful'] and freeze['source_clean'] and freeze['scanned_inputs_byte_identical']
    assert freeze['source'] == source and freeze['tree'] == TREE and freeze['parent'] == PARENT
    assert freeze['protected_rows'] == 907 and freeze['classified_boundaries'] == 1159
    assert freeze['verifier_unchanged'] and freeze['typed_matcher_unchanged']
    assert freeze['original_blob_policy_tests']['exit_code'] == 0
    assert freeze['exact_source_blob_policy']['exit_code'] == 0
    gate = BASE / 'read65-source-probe-4/RESULT.json'
    g = original(gate, data['source_gate_sha256'])
    assert sha(gate) == freeze['source_gate_sha256']
    assert g['successful'] and g['source_tests_successful'] and g['tests_run'] == 415
    assert len(g['modules']) == 47 and g['source_unchanged_during_tests']
    assert g['source_after_sha256'] == freeze['source_inventory_sha256']
    assert g['protected_file_sweep']['passed'] and g['protected_file_sweep']['rows'] == 907
    assert g['targeted_callers']['passed'] and g['targeted_callers']['expected_boundary_count'] == 320
    assert g['full_caller_proof_exit'] == 0 and not g['failures'] and not g['errors'] and not g['skipped']
    assert sha(BASE / 'source/CALLERS.toml') == CALLERS
    assert sha(BASE / 'source/scripts/verify_hepta_callers.py') == VERIFIER
    compile_path = BASE / 'read65-candidate-compile-5/RESULT.json'
    c = original(compile_path, COMPILE_SHA)
    assert c['successful'] and c['command_exit'] == 0 and c['native_cases'] == 0
    assert c['source_unchanged_during_compile'] and c['format']['exit_code'] == 0
    for name in ['native-validation-5', 'retirement-native-validation-3',
                 'historical-delivery-native-validation-1', 'complete-noupdate-5']:
        assert not (BASE / name).exists(), name
    drivers = data['drivers']
    assert set(drivers) == {'run_native5.py', 'run_retirement_native3.py',
                            'run_delivery_native1.py', 'run_noupdate5.py'}
    for name, body in drivers.items():
        ast.parse(body)
        assert not (BASE / name).exists(), name
        (BASE / name).write_text(body)
    save(OUT / 'SOURCE_FREEZE.json', freeze)
    save(OUT / 'SOURCE_GATE_RESULT.json', g)
    save(OUT / 'COMPILE_ONLY_RESULT.json', c)
    result.update(source_freeze_result_sha256=sha(freeze_path),
                  source_inventory_sha256=freeze['source_inventory_sha256'],
                  source_files=freeze['source_files'], full_caller_gate_source=source,
                  current_source_full_caller_cli_executed=True)
    p = original('native-validation-4/PROTOCOL.json',
                 '73d242c81f5b1a8c89312cfc8200cf236a7c05ceaffb78a9ce124e0ef33344ff')
    old_retirement = original('retirement-native-validation-2/PROTOCOL.json',
                              '803538853530a84d592cccbdac76e5732c4c843d40eb14ff3bc7f90d70963284')
    assert len(p['expected_cases']) == len(set(p['expected_cases'])) == 11
    assert len(old_retirement['expected_cases']) == len(set(old_retirement['expected_cases'])) == 16
    assert p['timeout_seconds'] == old_retirement['timeout_seconds'] == 1800
    assert p['original_read_budget'] == 64 and p['cargo_build_jobs'] == 2
    for key in ['test_import_delta_path', 'test_import_delta_sha256', 'test_import_compile_result_sha256']:
        p.pop(key, None)
    p.update(schema='hepta-e6-read65-original-native-v5',
             scope='Exactly the original eleven native scope regressions on this frozen source; prior results are provenance only.',
             source=source, tree=TREE, source_inventory_sha256=freeze['source_inventory_sha256'],
             source_files=freeze['source_files'], source_freeze_result='read65-frozen-source-1/RESULT.json',
             source_freeze_result_sha256=sha(freeze_path), frozen_at_ns=freeze['frozen_at_ns'],
             source_qa_result_path='read65-source-probe-4/RESULT.json', source_qa_result_sha256=sha(gate),
             full_caller_stdout_sha256=sha(gate.parent / 'full-caller-proof.stdout'),
             full_caller_gate_source=source, current_source_full_caller_cli_executed=True,
             compile_result_path='read65-candidate-compile-5/RESULT.json', compile_result_sha256=COMPILE_SHA,
             prior_protocol_sha256='73d242c81f5b1a8c89312cfc8200cf236a7c05ceaffb78a9ce124e0ef33344ff',
             actual_root_observe_after_fault_tested=False)
    p['source_validation'] = dict(tests=415, module_count=47, modules=g['modules'],
        protected_rows=907, affected_boundaries=320, full_boundaries=1159,
        verifier_sha256=VERIFIER, manifest_sha256=CALLERS,
        reference_source=source, executed_on_current_source=True)
    p['cost_scope'] = ('New component execution on the independently owned reused target. '
        'Compile-only, original eleven, retirement sixteen, delivery five and parent costs remain separate; '
        'overlapping command and owner windows are not additive. No prior native qualification is transferred.')
    deploy('native5', p, 'run_native5.py')
    retirement = copy.deepcopy(p)
    retirement.update(schema='hepta-e6-read65-retirement-native-v3',
        scope='Exactly the unchanged sixteen original completion, drain, physical witness failure/recovery and retained capability tests.',
        argv=old_retirement['argv'], expected_cases=old_retirement['expected_cases'],
        required_result=old_retirement['required_result'],
        prior_protocol_sha256='803538853530a84d592cccbdac76e5732c4c843d40eb14ff3bc7f90d70963284')
    deploy('retirement-native3', retirement, 'run_retirement_native3.py')
    delivery = copy.deepcopy(p)
    delivery.update(schema='hepta-e6-read65-historical-delivery-native-v1',
        scope='Two unchanged real delivery recovery tests and three new real claim/completion/witness-capacity controls; no actual Root observe_after fault injection.',
        expected_cases=DELIVERY_CASES,
        argv=['just', 'test', '--locked', '--offline', '-p', 'codex-hepta-agentd', '--lib', '-E',
              ' | '.join('test(' + case + ')' for case in DELIVERY_CASES)],
        required_result='One new original nextest XML, exactly five unique expected leaf names with full names retained, no failure/error/skip, actual exit zero and unchanged frozen inputs.')
    deploy('delivery-native1', delivery, 'run_delivery_native1.py')
    n = original('complete-noupdate-4/PROTOCOL.json',
                 '02c230f028a5bb5586dcd73cdfda36fb068702b2ba678ea008f7ea10ad2b73d7')
    assert n['root_read_budget'] == 64 and n['expected_parent_cases'] == 1
    assert not n['root_read_budget_changed'] and not n['original_deadlines_changed']
    assert not n['automatic_retry'] and not n['original_test_function_modified']
    for key in ['test_import_delta_path', 'test_import_delta_sha256',
                'prerequisite_result_sha256', 'retirement_native_result_sha256']:
        n.pop(key, None)
    n.update(schema='hepta-e6-read65-original-noupdate-v5', source=source, tree=TREE,
        source_inventory_sha256=freeze['source_inventory_sha256'], source_files=freeze['source_files'],
        source_freeze_result_path='read65-frozen-source-1/RESULT.json', source_freeze_result_sha256=sha(freeze_path),
        complete_caller_result_path='read65-source-probe-4/RESULT.json', complete_caller_result_sha256=sha(gate),
        complete_caller_stdout_sha256=sha(gate.parent / 'full-caller-proof.stdout'),
        full_caller_gate_source=source, current_source_full_caller_cli_executed=True,
        run_id='root-e6-read65-' + source[:8] + '-noupdate-5',
        prerequisite_result_path='native-validation-5/RESULT.json',
        retirement_native_result_path='retirement-native-validation-3/RESULT.json',
        delivery_native_result_path='historical-delivery-native-validation-1/RESULT.json',
        actual_root_observe_after_fault_tested=False, static_whole_fresh_parent_frames=63,
        static_budget_is_not_native_result=True,
        prior_protocol_sha256='02c230f028a5bb5586dcd73cdfda36fb068702b2ba678ea008f7ea10ad2b73d7')
    n['source_validation'] = dict(original_tests=415, module_count=47, modules=g['modules'],
        protected_rows=907, affected_boundary_checks=320,
        full_original_caller_proof='PASS_HEPTA_CALLER_CLOSED_SET', all_original_boundary_count=1159,
        verifier_sha256=VERIFIER, callers_manifest_sha256=CALLERS,
        reference_source=source, executed_on_current_source=True)
    for path in ['complete-noupdate-4/result.json', 'read65-candidate-compile-1/RESULT.json',
                 'read65-candidate-compile-2/RESULT.json', 'read65-source-probe-1/RESULT.json',
                 'read65-source-probe-2/RESULT.json']:
        n['retained_prior_failures'].append({'path': str(BASE / path), 'sha256': sha(BASE / path)})
    for previous in n['retained_prior_failures']:
        assert sha(previous['path']) == previous['sha256']
    n['target_provenance'].update(current_source_actual_native11_result_sha256=None,
        current_source_actual_retirement16_result_sha256=None, current_source_actual_delivery5_result_sha256=None)
    n['cost_scope'] = ('Actual exact-source helper/product/library preparation and one unchanged original NoUpdate parent '
        'after new exact-source native11, retirement16 and delivery5. All source/compile/native/parent windows and historical failures stay separate.')
    n['diagnostic_scope'] = ('Natural synchronous same-owner scopes retain actual physical Root before/after validation, '
        'owner identity, trust, scope, effect fencing and exact original B completion. No Root read authorization crosses external await. '
        'The original 64 historical frame limit includes the one-shot terminal acceptance; deadlines, scorer, parent body, '
        'Active/Retained restrictions and drain predecessor witness gate are unchanged.')
    save(BASE / 'noupdate5-PROTOCOL.preflight.json', n)
    status('protocols-deployed', expected_original_native_cases=p['expected_cases'],
           expected_retirement_cases=retirement['expected_cases'], expected_delivery_cases=DELIVERY_CASES,
           parent_read_budget=64, authority_deadlines_changed=False)
    native = stage('original-native11', 'run_native5.py', 'native-validation-5/RESULT.json', p['expected_cases'])
    retired = stage('retirement-native16', 'run_retirement_native3.py',
                    'retirement-native-validation-3/RESULT.json', retirement['expected_cases'], True)
    delivered = stage('historical-delivery-native5', 'run_delivery_native1.py',
                      'historical-delivery-native-validation-1/RESULT.json', DELIVERY_CASES, True)
    n.update(prerequisite_result_sha256=native['result_sha256'],
             retirement_native_result_sha256=retired['result_sha256'],
             delivery_native_result_sha256=delivered['result_sha256'])
    n['target_provenance'].update(current_source_actual_native11_result_sha256=native['result_sha256'],
        current_source_actual_retirement16_result_sha256=retired['result_sha256'],
        current_source_actual_delivery5_result_sha256=delivered['result_sha256'])
    deploy('noupdate5', n, 'run_noupdate5.py')
    status('native-controls-passed-starting-original-noupdate5',
           native11_result_sha256=native['result_sha256'], retirement16_result_sha256=retired['result_sha256'],
           delivery5_result_sha256=delivered['result_sha256'],
           noupdate5_protocol_sha256=sha(BASE / 'noupdate5-PROTOCOL.json'))
    stage('original-noupdate5', 'run_noupdate5.py', 'complete-noupdate-5/result.json')
    result['successful'] = True
    status('completed', complete_native_NoUpdate=True)
except BaseException as error:
    (OUT / 'ERROR.txt').write_text(traceback.format_exc())
    status('stopped', error=repr(error))
finally:
    result.update(finished_at_ns=str(time.time_ns()), owner_wall_seconds=time.monotonic() - started)
    save(OUT / 'RESULT.json', result)
    lock.close()
raise SystemExit(0 if result['successful'] else 1)
