# E6 delivery candidate peer review

Read-only review of the three files under `e6_owner_work/read65_candidate/codex-rs/hepta-agentd/src/`. The initial captured byte identities are in SOURCE_CAPTURE.json. SOURCE_CAPTURE_FINAL.json binds the reviewed Capacity-test correction and subsequent formatting of all three files. The two product formatting deltas were individually reviewed and contain no behavioral change; they are preserved in PRODUCT_FORMAT_DELTA.patch. Product line numbers below refer to the original captured pre-format review copies, which are retained separately from the final formatted copies. Original Root-wrapper behavior was checked against exact e4aeaa2c source. No source edits or tests were performed by this reviewer.

## Outcome

One concrete native-test defect was found and reported before deployment: the proposed readonly-witness negative control attempted to open a second exclusive witness while the first still held its lock. The implementing owner corrected it to a genuine capacity-exhaustion control. The correction was read back and reviewed. No additional blocking product-control-flow defect was identified in the reviewed delivery claim/completion paths. This does not constitute compile/test success or whole-parent qualification.

The new journal controls do not directly inject a real historical Root after-observation failure. Their scope must remain claim-drop, exact completion, and witness-capacity/recovery behavior. Production source logic covers the relevant error paths structurally, but direct Root-after failure coverage has not been established by these tests.

## Finding F1: readonly witness test failed before its intended boundary (corrected)

Initial candidate tests lines 207–211 opened FileAnchorWitnessStore::open(File::open(original_witness)) while claim.owner.witness was still alive. The original witness is released only by the later assignment at line 212.

The actual hepta-neuron witness.rs implementation acquires an exclusive File::try_lock in WitnessLockedFile::acquire (45–53), invoked at open line 100. A second independent File::open describes the same inode while the original exclusive lock is held, so the new open returns WitnessStoreError::Busy. The test's question-mark exits before completion line 213; it cannot substantiate post-completion witness-write failure.

This was reported immediately to root and hia_circuit. The old candidate bytes remain captured under learning_owner_journal_historical_delivery_tests.rs; they are not replaced by a fabricated successful result.

Corrected test: historical_prepared_completion_full_witness_keeps_exact_append_for_recovery. Its final reviewed source is learning_owner_journal_historical_delivery_tests.capacity.rs. The initial witness capacity is two records. The actual create anchor and actual claim consume those two slots. complete_original_historical_delivery appends the real completion journal frame, and the third witness CAS fails with the real capacity error. The test requires changed journal bytes, unchanged witness bytes, and a fenced live owner. A cold reopen with the same capacity must still fail without changing either file. Only then does the pre-existing eight-record helper recover the exact completed head and demonstrate a second idempotent reopen. This is an explicit test fault and repair; it does not change the product's 64 historical request bound or original work window. It is not labelled readonly or Root-after failure coverage.

## Product claim path

learning_iteration_historical_source.rs:387–400 starts an original Prepared operation, checks the exact source, reserves the original handle, reads the actual journal, and creates a claim only for the original Missing result. It checks the source again and returns the owned reservation, existing result, and same-journal claim.

The claim type in learning_owner_journal_historical_delivery.rs:54–59 has private fields: a mutable borrow of the exact LearningOwnerJournal and a cloned exact key. It is not Clone and contains no OriginalPreparedRead, Root observation, source snapshot, future, or cached authorization. prepare_original_historical_delivery preserves the old current/claim/anchor sequence and the distinct Existing Completed/Pending/error results (67–92).

The candidate Prepared wrapper has a higher-ranked synchronous callback. Its Dataset wrapper captures action's Result before running the after-batch check. The unchanged original Root wrapper similarly captures action's Result, performs its actual observe-after, and fences errors before returning. Thus a real Root after-observation failure after claim construction discards the tuple and guard before reaching dispatch. Dropping the guard does not erase or complete the claim; run_delivery returns an error and drops its journal owner. Durable Pending and the witness remain.

The actual submit select/timeout occurs only after that operation returns at source lines 426–436. The only borrow held through it is the original journal claim; no Root token crosses it. A submit error or cancellation returns Pending without completing or accepting.

## Product completion path

The actual submit result is owned before the second Prepared operation starts at source lines 440–451. That operation retains require_complete, source identity/deadline/receipt checks, exact journal completion, the second completeness check, and the source postcheck.

complete_original_historical_delivery consumes the unique claim (journal lines 95–113). It preserves require_current, exact-key complete, witness anchor_append, saved readback, exact bytes, and fencing. No new claim or readback path can manufacture that guard.

If the actual enclosing Root after-observation fails after durable completion, the outer map_err/question-mark at source line 451 returns immediately. The journal's Completed record and witness are retained. There is no rollback to Pending and no path to accept_original_terminal at line 457. If failure occurs before journal completion, Pending is retained. A journal/witness/readback failure preserves the original CommitUncertain/fenced behavior; the enclosing physical Root after-observation remains in the wrapper's Result error path.

The second Root borrow ends before terminal_acceptance.await at 457–458. Accept was not removed or replaced. The final require_complete remains at 455, and the original terminal method still enforces readiness, identity, expiry, one-shot Root acceptance, and exact acknowledged initial/scope/head.

## Ready and recovery behavior

The original readiness/cancellation loop at source lines 371–382 is unchanged. Existing Completed and Pending do not call prepare or dispatch new work. Their branches explicitly drop the optional claim and invoke the original readback. Saved Completed still compares the returned head bytes exactly (402–410). Both branches preserve readback's physical source checks before/after its await and the outer source check moved into each branch (409 and 416). The unexpected Completed result from a fresh Missing claim still refuses at 422–423 rather than being promoted to replay authority.

Both supervised futures remain joined by the unchanged run implementation. No detached dispatch worker or replacement owner was introduced by these three files.

## Test coverage boundaries and fixtures inspected

The original two tests still cover actual cancellation during an owned pending dispatch and completed cold reopen. The new claim-drop test covers durable Pending and no redispatch after dropping a prepared claim; the new completion test covers exact completed bytes and no second claim. The corrected Capacity test covers a real append/witness uncertainty and cold recovery.

These tests never enter RootHistoricalTaskReadClient::with_current_read or make its actual after-observation fail. Consequently none should be reported as a real Root-after fault control or as proof that terminal Accept was not sent in such a network/session failure.

Closest existing source-operation fixtures were inspected: source_operation_withdrawal_refuses_read_and_outer_completion and q24_training_source_operation_rechecks_withdrawal_before_return use real Live Dataset withdrawal but explicitly are not a deployed historical Root loop. root_source_handoff_finalized_primary_before_failed_postcheck_is_not_recoverable tests a different Root handoff with an explicit closure failure. No directly reusable same-historical-client after-observation fixture was identified in those inspected files. They must not be renamed to claim target coverage.

## Handoff and limits

Root and hia_circuit received F1 immediately, the corrected-test readback, and the structural product review. hia_circuit owns source changes, compilation, original gates, and native measurements. This review ran zero tests, zero model calls, and zero gradient updates. The implementing owner's whole-parent count estimate remains a separate static estimate pending actual original-parent verification.
