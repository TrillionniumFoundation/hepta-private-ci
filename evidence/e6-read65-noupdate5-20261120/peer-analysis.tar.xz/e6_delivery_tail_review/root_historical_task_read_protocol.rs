//! Complete-task data protocol. Only the same live Root route can authorize
//! a read; these serialized values never construct an owner or a Dataset cap.

use std::fs::File;
use std::io;
use std::path::PathBuf;

use codex_hepta_learning_artifacts::LearningIterationSnapshotV1;
use codex_hepta_memory::CognitiveCheckpointPeerLifetime;
use codex_hepta_types::Digest32;
use serde::Deserialize;
use serde::Serialize;

use crate::AgentdIdentity;
use crate::HostAuthorityLearningProfileV1;
use crate::HostAuthorityRegisteredIdentity;
use crate::circuit_task::RootHistoricalTaskPublicationDataV1;
use crate::root_historical_learning_trust_data::HistoricalLearningTrustPinV1;
use crate::root_historical_learning_trust_data::TRUST_PURPOSE;
use crate::root_historical_ledger_data::RootHistoricalLedgerReadDataV1;

pub(crate) const PURPOSE: &str = "runtime.learning.historical-task-read.v1";
pub(crate) const SOCKET: &str = "historical-task-read-v1.sock";
pub(crate) const MAX_READS: u64 = 64;
pub(crate) const WIRE_BOUND: usize = 16_384;

// The Task reply contains both independently bounded canonical DTOs. Keep the
// original request/bootstrap and other-operation limits. This is a paired
// Root/daemon capacity revision: an old v1 reader still rejects replies above
// 16 KiB; the wire shape, purpose and digest domains are unchanged.
const TASK_RESPONSE_ENVELOPE_BOUND: usize =
    br#"{"schema":1,"purpose":"","request_id":,"profile":"","data_cut":"","ledger":,"publication":}"#.len()
        + PURPOSE.len()
        + (MAX_READS.ilog10() as usize + 1)
        + 2 * 64; // Canonical nonzero Digest32 strings: profile and data_cut.
pub(crate) const TASK_RESPONSE_BOUND: usize = RootHistoricalLedgerReadDataV1::JSON_BOUND
    + RootHistoricalTaskPublicationDataV1::JSON_BOUND
    + TASK_RESPONSE_ENVELOPE_BOUND;

#[path = "root_post_a_learning_protocol.rs"]
mod post_a;
pub(crate) use post_a::POST_A_PURPOSE;
pub(crate) use post_a::PostAFrozenLearningResponseV1;
pub(crate) use post_a::require_post_a_learning_reply;

#[path = "root_completed_learning_protocol.rs"]
mod completed;
pub(crate) use completed::ACCEPT_COMPLETED_PURPOSE;
pub(crate) use completed::CAPTURE_COMPLETED_PURPOSE;
pub(crate) use completed::CompletedHistoryModeV1;
pub(crate) use completed::CompletedLearningAcceptanceResponseV1;
pub(crate) use completed::CompletedLearningHistoryResponseV1;
pub(crate) use completed::READ_COMPLETED_PURPOSE;
pub(crate) use completed::require_completed_acceptance_reply;
pub(crate) use completed::require_completed_history_reply;

#[derive(Clone, Copy)]
pub(crate) enum HistoricalReadOperationV1 {
    Task,
    LearningTrust,
    PostAFrozenLearning,
    AcceptCompletedLearning,
    CaptureCompletedHistory,
    ReadCompletedHistory,
}

impl HistoricalReadOperationV1 {
    pub(crate) fn from_purpose(purpose: &str) -> io::Result<Self> {
        match purpose {
            PURPOSE => Ok(Self::Task),
            TRUST_PURPOSE => Ok(Self::LearningTrust),
            POST_A_PURPOSE => Ok(Self::PostAFrozenLearning),
            ACCEPT_COMPLETED_PURPOSE => Ok(Self::AcceptCompletedLearning),
            CAPTURE_COMPLETED_PURPOSE => Ok(Self::CaptureCompletedHistory),
            READ_COMPLETED_PURPOSE => Ok(Self::ReadCompletedHistory),
            _ => Err(io::Error::other("unknown original historical operation")),
        }
    }

    pub(crate) fn response_bound(self) -> usize {
        match self {
            Self::Task => TASK_RESPONSE_BOUND,
            Self::LearningTrust
            | Self::PostAFrozenLearning
            | Self::AcceptCompletedLearning
            | Self::CaptureCompletedHistory
            | Self::ReadCompletedHistory => WIRE_BOUND,
        }
    }

    pub(crate) fn purpose(self) -> &'static str {
        match self {
            Self::Task => PURPOSE,
            Self::LearningTrust => TRUST_PURPOSE,
            Self::PostAFrozenLearning => POST_A_PURPOSE,
            Self::AcceptCompletedLearning => ACCEPT_COMPLETED_PURPOSE,
            Self::CaptureCompletedHistory => CAPTURE_COMPLETED_PURPOSE,
            Self::ReadCompletedHistory => READ_COMPLETED_PURPOSE,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct HistoricalTaskReadProfileV1 {
    pub(crate) purpose: String,
    pub(crate) identity: String,
    pub(crate) writer: String,
    pub(crate) initial: String,
    pub(crate) deployment: String,
    pub(crate) learning_trust: HistoricalLearningTrustPinV1,
    pub(crate) binding: String,
}

impl HistoricalTaskReadProfileV1 {
    pub(crate) fn digest(&self) -> io::Result<String> {
        let mut value = self.clone();
        value.binding.clear();
        Ok(Digest32::of_parts(&[
            b"hepta.root.historical-task-read.profile.v1\0",
            &serde_json::to_vec(&value).map_err(io::Error::other)?,
        ])
        .to_string())
    }

    pub(crate) fn require_original_context(
        &self,
        identity: &AgentdIdentity,
        proof: &str,
        initial: &HostAuthorityLearningProfileV1,
    ) -> io::Result<LearningIterationSnapshotV1> {
        if self.purpose != PURPOSE
            || initial.schema_version != 1
            || initial.update_scope.is_some()
            || self.writer != proof
            || self.identity
                != crate::neuron_generation_process_identity_digest_v1(identity)
                    .map_err(io::Error::other)?
                    .to_string()
            || self.initial
                != Digest32::of_parts(&[
                    b"hepta.root.historical-task-read.initial.v1\0",
                    initial.encoded_initial().as_bytes(),
                ])
                .to_string()
            || self.digest()? != self.binding
        {
            return Err(io::Error::other(
                "original unfrozen historical recipient differs",
            ));
        }
        canonical_digest(&self.deployment)?;
        canonical_digest(&self.writer)?;
        let initial = initial.require_binding(identity, proof)?;
        self.learning_trust.require_initial(&initial)?;
        Ok(initial)
    }
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct HistoricalTaskReadBootstrapV1 {
    pub(crate) schema: u8,
    pub(crate) purpose: String,
    pub(crate) root: CognitiveCheckpointPeerLifetime,
    pub(crate) consumer: CognitiveCheckpointPeerLifetime,
    pub(crate) identity: HostAuthorityRegisteredIdentity,
    pub(crate) initial: HostAuthorityLearningProfileV1,
    pub(crate) profile: HistoricalTaskReadProfileV1,
    pub(crate) socket: PathBuf,
}

/// A Root-created sealed route, without signer, store, writable file or grant.
pub struct RootHistoricalTaskReadOfferV1 {
    pub(crate) bootstrap: File,
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct HistoricalTaskReadRequestV1 {
    pub(crate) schema: u8,
    pub(crate) purpose: String,
    pub(crate) request_id: u64,
    pub(crate) profile: String,
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct HistoricalTaskReadResponseV1 {
    pub(crate) schema: u8,
    pub(crate) purpose: String,
    pub(crate) request_id: u64,
    pub(crate) profile: String,
    pub(crate) data_cut: String,
    pub(crate) ledger: RootHistoricalLedgerReadDataV1,
    pub(crate) publication: RootHistoricalTaskPublicationDataV1,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct HistoricalTaskReadDataV1 {
    pub(crate) data_cut: Digest32,
    pub(crate) ledger: RootHistoricalLedgerReadDataV1,
    pub(crate) publication: RootHistoricalTaskPublicationDataV1,
}

pub(crate) fn require_complete_reply(
    bytes: &[u8],
    request_id: u64,
    profile: &str,
) -> io::Result<HistoricalTaskReadDataV1> {
    if bytes.is_empty()
        || bytes.len() > TASK_RESPONSE_BOUND
        || !(1..=MAX_READS).contains(&request_id)
    {
        return Err(io::Error::other(
            "historical read response exceeds original bounds",
        ));
    }
    let response: HistoricalTaskReadResponseV1 =
        serde_json::from_slice(bytes).map_err(io::Error::other)?;
    if response.schema != 1
        || response.purpose != PURPOSE
        || response.request_id != request_id
        || response.profile != profile
    {
        return Err(io::Error::other(
            "complete historical task response differs from request",
        ));
    }
    canonical_digest(profile)?;
    response.ledger.validate_data()?;
    response
        .publication
        .validate_against(&response.ledger)
        .map_err(io::Error::other)?;
    Ok(HistoricalTaskReadDataV1 {
        data_cut: canonical_digest(&response.data_cut)?,
        ledger: response.ledger,
        publication: response.publication,
    })
}

pub(crate) fn canonical_digest(value: &str) -> io::Result<Digest32> {
    let digest = value.parse::<Digest32>().map_err(io::Error::other)?;
    if digest.is_zero() || digest.to_string() != value {
        return Err(io::Error::other(
            "canonical nonzero historical digest required",
        ));
    }
    Ok(digest)
}

#[cfg(test)]
#[path = "root_historical_task_read_protocol_tests.rs"]
mod tests;
