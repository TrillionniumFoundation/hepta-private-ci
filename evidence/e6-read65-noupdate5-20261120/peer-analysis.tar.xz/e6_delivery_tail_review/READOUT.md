# E6 original delivery completion and terminal acceptance: static review

Source commit: `e4aeaa2cdd1a4aa884d09cafaeef96968feb7a90`. Source tree: `05c36cd26f6dfbd1a8fb0e0cfe275755fef80c86`; agentd source subtree `11b537bb6d59e78913c57fab36dc99db46f5d887`.

This is a read-only source review. No product source changes, native execution, model calls, new owner, or changed limits. Counts below describe the successful fresh/Missing delivery path; they are not an observed successful parent.

## Finding: the fresh delivery tail needs five more requests after Submit returns

Let N be the A RootHistoricalTaskReadClient sequence count already consumed when the actual LearningIterationReservationV1::submit result returns.

| Step | Exact original call | Additional A historical exchanges |
| --- | --- | ---: |
| Validate returned terminal snapshot | historical_source.rs:417 require_complete; the function at 456–474 validates request, owners, scope, and coordinator terminal state | 0 |
| Post-dispatch source check | historical_source.rs:418 require_current_historical_source | 2 Task |
| Complete original journal | learning_owner_journal_historical_delivery.rs:37–49 current, complete, witness anchor, readback, exact bytes | 0 |
| Validate outer completion | historical_source.rs:428 require_complete | 0 |
| Post-journal source check | historical_source.rs:429–430 require_current_historical_source | 2 Task |
| Accept terminal at original Root | historical_source.rs:431–433 → learning_iteration_terminal_acceptance.rs:26–31 → OriginalCompletedLearningAcceptanceV1::accept → accept_completed_once → exchange(AcceptCompletedLearning) | 1 Accept |
| Validate and attach fresh acknowledgement | terminal_acceptance.rs:33–43 → state_q24_completed_history.rs:17–43 | 0 |
| Wait for original cancellation | historical_source.rs:434 | 0 |

**Original successful tail: N + 5.** A legitimate synchronous completion consolidation can save two Task requests, producing **N + 3**. Therefore this local optimization alone requires **N <= 61** to finish the fresh acknowledgement within the original 64-request lane. If N = 64, the old tail requires 69 and the consolidated tail still requires 67. This does not account for any unrelated or concurrent operation not already included in N.

The original failing trace's request 65 is an attempted client exchange rejected by the local range check before transport, not evidence that 65 complete physical Root observations succeeded.

## Accept uses the same original counter

`root_completed_learning_history.rs:83–109` calls `RootHistoricalTaskReadClientV1::exchange(self, AcceptCompletedLearning)`. It retains the same client as the historical source; it does not open another lane. `root_historical_task_read_client.rs:199–207` takes the original lane sequence and checks 1..=MAX_READS for every operation. The Accept reply branch is 271–278. `root_historical_task_read_protocol.rs:24` defines MAX_READS = 64, and its operation enum/purpose mapping includes AcceptCompletedLearning. `authority_host_historical_read_runtime.rs:163–192` independently enforces the same sequence and 64 maximum on the Root side.

The purpose string is `runtime.learning.completed-acceptance.v1`. It is a zero-payload, one-shot original Root acceptance, not a second Task before/after pair. Do not omit it, relocate it to a new client to reset a counter, or replace it with a local digest.

## Fresh acknowledgement is different from completed-history read authority

`OriginalCompletedLearningAcknowledgementV1::require_original_current` in root_completed_learning_acknowledgement.rs:11–28 performs same-client identity/session and DATA validation only. It calls require_completed_identity, not exchange. Its session checks in root_historical_task_connection.rs:110–136 read kernel process credentials, the pinned verifier, and the original deadline.

`AgentdState::attach_original_q24_terminal_acceptance` calls that acknowledgement check before/after local DATA validation. `read_original_q24_terminal_acceptance` does the same for polling the accepted DATA. Their generation check in state_q24_completed_history.rs:109–129 calls state.refresh_generation; state.rs:383–395 reads registry.load_agent. These do not increment A's historical sequence.

In contrast, the separate `OriginalCompletedLearningHistoryV1::require_original_current` in root_completed_learning_history.rs:242–258 performs a ReadCompletedHistory exchange. The fresh acceptance path does not construct or attach that type. Its counts must not be added to fresh acknowledgement polling or silently removed from genuine cold-history recovery.

`RootGenerationCurrentClient` has its own private Lane, sequence, publication purpose, and connection in root_generation_current_client.rs:27–38 and 273–324. It is not the A historical lane. Root acceptance's publication verification reads the original HostAuthorityFrontierStore<CurrentHead> and retained publication files (authority_host_publication_completed.rs:173–202). Zero additional A frames does not mean zero local physical IO or zero total cost.

## Natural synchronous completion operation

The two source checks at historical_source.rs:418 and 430 are in the same delivery continuation after the actual submit future returns. Between them, the journal performs only the existing synchronous completion sequence; there is no new external await. The current async wrappers obscure this boundary but do not introduce a reason to cache Root authority across the actual Submit wait.

Suggested minimum interface for the implementing owner:

1. Keep the original claimed journal/key guard, without a Root borrow, across dispatch.await.
2. After the owned snapshot returns, validate its completeness exactly as before.
3. Enter a new with_original_prepared_operation. Run source.require_original_stage_operation(identity, read), complete the exact claimed journal synchronously, run the original outer require_complete and source.require_original_stage_operation again, and return the owned snapshot/result.
4. The synchronous complete_exact method retains journal.require_current, journal.complete, independent witness anchor_append, journal.read, exact byte comparison, and original fencing behavior from journal delivery lines 37–49.
5. All pure postchecks and the operation's real Root after-observation execute on the required error paths. Do not let a journal error accidentally skip the enclosing physical after-observation.
6. Only after the new operation and its actual Root after-observation succeed, call accept_original_terminal(...).await. Do not move terminal_acceptance.take() before this success, and do not retain OriginalPreparedRead, a Root snapshot, or cached authorization across that await.

This consolidates 4 Task exchanges to the existing before/after pair of one natural 'finish this exact claimed delivery' operation. Accept remains a separate mandatory exchange. The source checks and Root completion/signature checks are not removed.

## Failure and durable-state constraints

| Failure boundary | Required durable behavior |
| --- | --- |
| Submit error, timeout, cancellation, invalid/incomplete returned snapshot | Original claim remains Pending; no completion, no Accept, no redispatch on cold reopen |
| Root before-observation or pure pre-completion source check fails | Do not complete journal; retain Pending |
| Journal complete / witness append / exact readback fails | Preserve original fencing and CommitUncertain behavior; do not fabricate a terminal result |
| Journal completion has persisted but enclosing Root after-observation or outer current check fails | Preserve the actual Completed/uncertain evidence, return failure, and do not send Accept; never roll it back to Pending or treat a local completed head as Root acceptance |
| Accept request or response is uncertain | Original one-shot attempt is consumed; no second Accept retry and no successful local acknowledgement |
| Root accepts but local readiness/identity/deadline/ack binding checks fail | No terminal acknowledgement attachment; retain actual Root/journal evidence and failure |

The consolidation changes where the actual Root after-observation surrounds a synchronous local commit. An error after a persisted completion must be handled as the real state, not falsely relabeled Pending. A new control should cover that boundary, in addition to the original cancelled-claim and completed-claim cold-reopen controls.

## Terminal signature and Root acceptance gates remain necessary

Root provider authority_host_completed_provider.rs:34–57 selects fresh AcceptedPublication and consumes completion_phase 0→1 exactly once. It calls CompletedLearningRecord::accept with original Root descriptors and target. Only after the full observed completion succeeds does it move 1→2 and construct the reply (129–153). An Armed attempt or caught error cannot become an acknowledgement.

authority_host_completed_observation.rs:40–123 and 148–205 independently join the original checkpoint, original historical A task, fixed profile/scope, completed B, original publication, and all completed journals. Fresh acceptance must remain in the original work window (174–177). It records actual verified signature/journal cuts, terminal head, B acceptance, and publication acceptance.

authority_host_completed_signatures.rs:34–49 requires all seven original journals, with exactly two Training records and one record for each other journal, all Completed. Lines 68–113 require seven actual evaluated terminal signatures and reject a TrainingNoUpdate terminal shortcut; the user-authorized independent-B NoUpdate case is distinct. Lines 115–129 bind the second Training record to B's actual plan signature. Lines 146–190 verify exact receipt payloads, actor separation, current signer/trust bindings, and fresh-time validity (including a second fresh verification). The freeze Evaluator signature is also verified. `with_original_completed_context` revalidates current trust, recorded signers, metadata, and original deadline after the action.

No optimization here may substitute the caller's snapshot/head or earlier cached signature success for those original Root checks.

## Handoff

The implementing owner hia_circuit received the exact +5/+3 accounting, distinct-counter explanation, source paths, minimal complete_exact interface, and failure-state obligations. Root received the N<=61 implication. No candidate compilation or original-parent result is claimed by this review.
