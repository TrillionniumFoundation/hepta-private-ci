# Existing Post-A source QA mismatch: exact original provenance

This is a read-only source comparison, with zero tests, compilation, native executions or code edits by this reviewer.

Both published commits `e4aeaa2cdd1a4aa884d09cafaeef96968feb7a90` and `ab5e792d1bceb583c246f44d01ee8e433d5c60e8` contain the following identical bytes, independently fetched through GitHub and checked against the returned Git blob SHA:

| File | Git blob | SHA-256 |
| --- | --- | --- |
| `codex-rs/hepta-agentd/src/production_post_a_q24.rs` | `9337a38cfaa792d17757d710af684e2fbea38bb5` | `5111fb1d31e07a9ac962be464ea3bfe746ec9ccbd53d0ca9f20030d834c2ef3b` |
| `qa/b4-no-bypass/test_post_a_main_source_closure.py` | `ce873bd03c9c94d1ba88546f6cdb168c3bbe9a42` | `052d27d8ec1726f53cdba22cef1304ca8a1ae655a4c16a0dd471ee339dd25c3f` |

The old test at lines 54–66 requires the direct calls `CellQ24DatasetTaskV1::capture_historical(` and `CellQ24DatasetFreezePreparationV1::capture_historical(` inside `assemble_original_post_a_q24`. The exact original production function already uses `CellQ24DatasetFreezePreparationV1::capture_original_historical_task(` at lines 106–113. These missing *direct-call markers* predate the read65 candidate. The older constructors still exist in their respective modules; this finding does not claim they were globally deleted.

The authentic replacement construction chain at e4 is:

1. `production_post_a_q24.rs:90–129`: obtain original files, take actual historical client, observe Root task, activate current learning trust, derive preparation config, capture the combined historical preparation, freeze original signing files, revalidate original Post-A context, install through original Root and require exact prepared scope.
2. `cell_q24_dataset_historical_preparation.rs:28–46` (blob `4a7299b646943c972eaa3bab1e1d7691e8e3b018`): require exact original receipt, enter `OriginalHistoricalLearningTrustV1::with_original_operation`, construct the ledger/task in that operation, borrow its original historical dataset operation, and construct preparation inside it. The function is synchronous; it does not retain a borrow across await.
3. `cell_q24_dataset_historical_ledger.rs:20–41` (blob `41d55bfad13e08faa33df78c8fc80b166077dc1e`): require exact trust/receipt, call `CellQ24DatasetTaskV1::capture_historical_in_operation`, validate the actual original snapshot through `OriginalHistoricalOperationV1::read_for`, then retain exactly that receipt/trust and a single constructed task.
4. `cell_q24_dataset_historical_task.rs:35–50` (blob `44a039c31751cfefdbe5d089018fc28afee0e3bf`): the supplied original operation calls `read_original_task(&receipt, client, session)` and constructs `HistoricalTaskSource`, publication and decision from that result, not a caller-authored publication.
5. Preparation's original operation reads its historical configuration/snapshot/frontier, checks the original envelope expiry, creates the preparation and verifies the signing payload in the same scope before returning (`cell_q24_dataset_historical_preparation.rs:49–84`).

The migration should test those real operations and their ordering, while preserving all existing context checks and timeout constraints. A marker replacement alone is insufficient. Hia reports adding per-marker deletion controls for both preparation and ledger construction; this reviewer has not run or qualified that new test source.

`RETAINED_OLD_FAILURE.json` binds the original failed source-probe1 result without changing it, including the relevant PostAMain records. `SOURCE_BINDINGS.json` binds all seven downloaded files. The complete API responses remain one directory above. The original failure is retained; no pass is inferred from this source comparison.
