"""Read existing local originals only; no exporter/consumer/native execution."""
from pathlib import Path
import base64
import hashlib
import io
import json
import tarfile

W = Path('/workspace/scratch/93bfcfe29fc8')
D = W / 'w1/h4-reference-export'
OUT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, size=None, digest=None):
    raw = path.read_bytes()
    assert size is None or len(raw) == size, (str(path), 'size')
    assert digest is None or sha(raw) == digest, (str(path), 'sha256')
    return raw


def obj(path):
    return json.loads(read(path))


def rpc(path):
    value = obj(path)
    assert not value.get('isError')
    assert value.get('structuredContent') is None
    assert len(value['content']) == 1 and value['content'][0]['type'] == 'text'
    return json.loads(value['content'][0]['text'])


def main():
    delivery_raw = read(D / 'H4-execution-delivery-manifest.json', digest='160b839fbbf3593d86256d9ff9a1304719f16494fd6429240e8222c00e848654')
    delivery = json.loads(delivery_raw)
    assert len(delivery['files']) == delivery['file_count'] == 62
    original_bytes = 0
    for row in delivery['files']:
        raw = read(W / row['path'], row['bytes'], row['sha256'])
        original_bytes += len(raw)
    assert original_bytes == delivery['file_bytes'] == 6201199
    terminal = rpc(D / 'H4-archive-terminal.raw.json')
    assert terminal['job_id'] == '1a1ae17645d-fc05-5d51'
    assert terminal['state'] == 'succeeded' and terminal['exit_code'] == 0
    assert not terminal['timed_out'] and not terminal['automatic_retry']
    assert terminal['at_unix_ms'] == 1793922176412
    assert terminal['output_complete'] and terminal['output_durable']
    assert terminal['log_bytes']['stdout'] == {'seen': 23217, 'stored': 23217}
    assert terminal['log_bytes']['stderr'] == {'seen': 0, 'stored': 0}
    assert not any(terminal['log_truncated'].values())
    completion = obj(D / 'H4-export-completion.json')
    assert obj(D / 'H4-archive.stdout') == completion
    assert read(D / 'H4-archive.stderr') == b''
    assert completion['status'] == 'COMPLETE_WITH_REFERENCED_PARENT'
    assert not completion['standalone_archive']
    assert completion['unique_actual_elfs'] == completion['unique_referenced_elfs'] == 11
    assert completion['unique_embedded_elfs'] == completion['embedded_elf_bytes'] == 0
    assert completion['referenced_elf_bytes'] == 1674575368
    assert completion['selected_sources_actually_read_twice']
    assert not completion['unselected_aliases_reopened']
    assert not completion['binary_rebuilt'] and not completion['native_reexecution'] and not completion['capture_gaps_filled']
    archive = read(D / 'H4-actual-retained-image-references.tar.xz', 100964, '47d3c5efa6b9aa4b2f97ef06a606f2931d8065f068311303f8d079c18a7bbaa5')
    assert len(archive) == completion['archive_bytes'] and sha(archive) == completion['archive_sha256']
    parts = completion['parts']
    assert len(parts) == 1 and parts[0]['index'] == parts[0]['offset'] == 0
    part = read(D / 'H4-child-parts' / parts[0]['name'], parts[0]['bytes'], parts[0]['sha256'])
    assert part == archive

    transfer = obj(D / 'H4-child-transfer-index.json')
    assert len(transfer['records']) == 4
    versions = {}
    for role in ['archive', 'part']:
        rows = [x for x in transfer['records'] if x['role'] == role]
        assert [x['offset'] for x in rows] == [0, 65536]
        assembled = b''
        version = None
        for row in rows:
            request = json.loads(read(W / row['request_path'], digest=row['request_sha256']))
            raw_rpc = read(W / row['rpc_path'], digest=row['rpc_sha256'])
            response = rpc(W / row['rpc_path'])
            assert request['host'] == 'desktop' and request['limit'] == 65536
            assert request['path'] == response['path'] == row['remote_path']
            assert request['offset'] == response['offset'] == row['offset'] == len(assembled)
            assert response['size'] == 100964
            if version is None:
                assert 'expected_version' not in request
                version = response['version']
            else:
                assert request['expected_version'] == version
            assert response['version'] == row['version'] == version
            raw = base64.b64decode(response['data_base64'], validate=True)
            assert len(raw) == row['bytes']
            assert sha(raw) == response['chunk_sha256'] == row['chunk_sha256']
            assert raw == read(D / f'H4-child-{role}-chunk-{row["offset"]}.bin')
            assembled += raw
            assert response['next_offset'] == len(assembled)
            assert response['eof'] == (len(assembled) == 100964)
        assert assembled == archive
        versions[role] = version
    assert versions['archive'] != versions['part']

    members = {}
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:xz') as stream:
        for member in stream:
            assert member.isfile() and not member.issym() and not member.islnk()
            assert member.name not in members and not member.name.startswith('/') and '..' not in Path(member.name).parts
            raw = stream.extractfile(member).read()
            assert len(raw) == member.size
            assert raw == read(D / 'H4-child-extracted' / member.name)
            members[member.name] = {'bytes': len(raw), 'sha256': sha(raw)}
    assert len(members) == 8 and sum(x['bytes'] for x in members.values()) == 2848290
    index_raw = read(D / 'H4-actual-export-index.json', 690778, '3c4355fbd6293e631092c432557289ee770e34ae818c2ec68a590b7388d0041e')
    index = json.loads(index_raw)
    assert members['export-index.json'] == {'bytes': len(index_raw), 'sha256': sha(index_raw)}
    assert {k: v for k, v in members.items() if k != 'export-index.json'} == index['embedded_metadata_files']
    plan_raw = read(D / 'H4-reference-export-plan.json', 1236214, 'c917633ed8b22fa7a97455ea06c4a96fecc4a208375899bd3afededebf007619')
    plan = json.loads(plan_raw)
    assert plan_raw == read(D / 'H4-child-extracted/export-plan.json')
    assert index['plan_sha256'] == completion['plan_sha256'] == sha(plan_raw)
    assert index['exporter_sha256'] == completion['exporter_sha256'] == members['exporter.py']['sha256']
    assert index['source_commit'] == completion['source_commit'] == '6db78eca53a5acdda0d96873d3f4cd65863426f0'
    assert index['source_tree'] == completion['source_tree'] == 'e91f5994017fc5d2cfe58d405a20ee6ad9376772'
    source_map = base64.b64decode(plan['source_map']['data_base64'], validate=True)
    assert source_map == read(D / 'H4-child-extracted/H4/original-source-map.json')
    assert source_map == read(W / 'model_storage/h4-capture-repair/native/joint-h4-native-attempt-1/h4-actual-image-inventory.json')
    assert sha(source_map) == 'a1e42612d6a89337144b00335da2fa690dc7f503b46532ff795f0c92198bdd9c'
    aliases = observations = selected_bytes = 0
    assert len(index['files']) == len(plan['files']) == len(completion['logical_complete_views']) == 11
    for current, planned, view in zip(index['files'], plan['files'], completion['logical_complete_views']):
        assert {k: current[k] for k in planned} == planned
        assert set(current) - set(planned) == {'first_read_metadata', 'second_read_metadata', 'second_read_sha256', 'other_aliases_reopened_by_this_export'}
        assert current['first_read_metadata'] == current['second_read_metadata']
        assert current['first_read_metadata']['bytes'] == current['bytes']
        assert current['first_read_metadata']['nlink'] == 1
        assert current['sha256'] == current['second_read_sha256']
        assert not current['other_aliases_reopened_by_this_export']
        assert current['representation'] == 'referenced-complete-image'
        assert view['name'] == current['name'] and view['bytes'] == current['bytes'] and view['sha256'] == current['sha256']
        assert view['actual_member_bytes_fully_hashed'] and not view['parent_native_credit_transferred']
        assert view['source']['kind'] == 'actual-complete-parent-member'
        assert view['source']['archive_sha256'] == current['parent_reference']['archive_sha256']
        assert view['source']['member'] == current['parent_reference']['member']
        aliases += len(current['aliases'])
        observations += len(current['original_observations'])
        selected_bytes += current['bytes']
    assert (aliases, observations, selected_bytes) == (32, 597, 1674575368)
    parent = obj(D / 'H4-child-extracted/H4/parent-archive-verification.json')
    assert parent['complete_parent_actually_rehashed'] and parent['no_parent_native_credit_transferred']
    assert parent['archive_bytes'] == 283427280 and parent['archive_sha256'] == '5365fcf900781044108e9642ae02a110e4ac8d031d9ee516c4f0b0e471e1e773'
    assert len(parent['all_actual_members']) == 16 and parent['complete_images'] == 11
    assert parent['parent_native_outcome']['result'] == 'FAILED'
    assert read(D / 'H4-child-extracted/H4/referenced-H3-index.json') == read(W / 'w1/h3-elf-export/H3-actual-export-index.json')
    assert read(D / 'H4-child-extracted/H4/referenced-H3-completion.json') == read(W / 'w1/h3-elf-export/H3-export-completion.json')
    for current in index['files']:
        prior = parent['all_actual_members'][current['parent_reference']['member']]
        assert prior == {'bytes': current['bytes'], 'sha256': current['sha256'], 'elf_magic': True}
    release = obj(D / 'H4-archive-owned-release-proof.json')
    assert release['job_id'] == terminal['job_id'] and release['original_launch_nonce'] == terminal['launch_nonce']
    assert release['owned_processes_clear'] and not release['failures']
    assert not release['mutations_performed'] and not release['processes_killed']
    assert release['expected_original_invocation'] is None and not release['original_pid_and_invocation_observed_before_terminal']
    assert release['original_root_processes'] == []
    assert all(not x['exists'] and not x['owned_pids'] for x in release['exact_cgroups'])
    assert release['systemctl']['fields']['LoadState'] == 'not-found'
    assert not delivery['full_dependent_consumer_executed'] and delivery['full_H3_parent_and_original_parts_still_required']
    return {
        'schema': 'independent-H4-actual-reference-archive-review-v1',
        'status': 'ACTUAL_CHILD_ARCHIVE_AND_RECORDS_VERIFIED_PARENT_CONSUMER_PENDING',
        'owner_delivery_sha256': sha(delivery_raw),
        'owner_original_files_verified': 62, 'owner_original_bytes_verified': original_bytes,
        'actual_terminal': terminal,
        'actual_child': {'bytes': len(archive), 'sha256': sha(archive), 'regular_members': members},
        'separate_original_part_matches': True, 'original_versioned_range_responses_verified': 4,
        'version_pins': versions, 'selected_images': 11, 'selected_image_bytes': selected_bytes,
        'actual_source_read_passes_per_selected_path': 2, 'retained_aliases_preserved': aliases,
        'original_observations_preserved': observations, 'other_aliases_reopened': False,
        'parent_desktop_full_read_record_verified': True,
        'parent_whole_archive_locally_read_by_this_review': False,
        'full_dependent_consumer_executed': False,
        'historical_H3_native_result': 'FAILED',
        'release_scope': 'Exact unique runtime unit removed and known cgroup absent; original PID/Invocation not observed and not invented.',
        'review_scope': 'Local original-byte and record review only. No remote calls, native, exporter, capture, utility rerun or complete-parent consumer execution.',
        'bulk_pause_state_modified': False,
    }


if __name__ == '__main__':
    result = main()
    (OUT / 'review.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'owner_original_files_verified', 'owner_original_bytes_verified', 'original_versioned_range_responses_verified', 'selected_images', 'selected_image_bytes', 'retained_aliases_preserved', 'original_observations_preserved', 'full_dependent_consumer_executed']}, indent=2))
