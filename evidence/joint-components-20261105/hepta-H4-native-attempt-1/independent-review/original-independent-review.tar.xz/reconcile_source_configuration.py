#!/usr/bin/env python3
"""Reconcile original before/after guard and configuration receipts locally."""
import hashlib
import json
from reconcile_gate import EVIDENCE, NATIVE, OUT, ROOT, SOURCE, TREE, identity, load

before_path = EVIDENCE / "full-source-before.json"
after_path = EVIDENCE / "full-source-after.json"
before, after = load(before_path), load(after_path)
assert before == after
assert after["identity"]["commit"] == SOURCE and after["identity"]["tree"] == TREE
assert after["identity"]["dirty"] is False and after["raw_git_blob_bytes_match"] is True
assert after["tracked_count"] == after["index_count"] == 11840 and after["tracked_bytes"] == 183410043
assert after["hidden"] == after["missing"] == []
config_path = EVIDENCE / "configuration-after.json"
config = load(config_path)
assert config["unchanged"] is True and config["before"] == config["after"] and len(config["before"]) == 5
environment_path = EVIDENCE / "native-environment.json"
environment = load(environment_path)
runtime_before_path, runtime_after_path = EVIDENCE / "runtime-inputs-before.json", EVIDENCE / "runtime-inputs-after.json"
runtime_before, runtime_after = load(runtime_before_path), load(runtime_after_path)
delta_path = EVIDENCE / "runtime-inputs-delta.json"
delta = load(delta_path)
assert environment["source"] == after
assert environment["scripts"] == runtime_before["external_configuration_sha256"] == runtime_after["external_configuration_sha256"]
assert len(environment["scripts"]) == 12
for name, sha256 in environment["scripts"].items():
    assert identity(NATIVE / name)["sha256"] == sha256
assert delta["external_configuration_unchanged"] is True
assert delta["new_ignored_paths"] == delta["removed_ignored_paths"] == []
assert runtime_before["ignored_paths"] == runtime_after["ignored_paths"]
bytecode_fields = ("path", "sha256", "bytes", "mtime_ns", "ctime_ns", "corresponding_source", "corresponding_source_sha256")
assert [{k: row[k] for k in bytecode_fields} for row in runtime_before["bytecode"]] == [{k: row[k] for k in bytecode_fields} for row in runtime_after["bytecode"]]
assert runtime_before["interpreter_sha256"] == runtime_after["interpreter_sha256"]
plan_path = NATIVE / "h4-native-plan.json"
plan = load(plan_path)
assert plan["source_frozen"] is True and plan["execution_configuration_frozen"] is True
assert plan["source_commit"] == SOURCE and plan["source_tree"] == TREE
assert plan["original_job_timeout_seconds"] == environment["original_job_budget_seconds"] == 5400
files = [before_path, after_path, config_path, environment_path, runtime_before_path, runtime_after_path, delta_path, plan_path]
files.extend(NATIVE / name for name in environment["scripts"])
report = {
    "schema": "H4-independent-source-configuration-readback-v1",
    "status": "ORIGINAL_BEFORE_AFTER_GUARDS_AND_FROZEN_CONFIGURATION_MATCH",
    "source_commit": SOURCE, "source_tree": TREE, "full_source_guard": after,
    "common_and_worktree_config_count": 5, "configuration_hashes_before_after_equal": True,
    "external_configuration_count": 12, "external_hashes": environment["scripts"],
    "external_before_after_and_reviewed_local_bytes_equal": True,
    "ignored_paths_unchanged": True,
    "observed_bytecode_unchanged": [{k: row[k] for k in bytecode_fields} for row in runtime_after["bytecode"]],
    "original_outer_budget_seconds": 5400,
    "inputs": [identity(path) for path in dict.fromkeys(files)],
    "scope": "Independent local verification of the actual original full tracked-byte guard receipts and frozen external configuration before/after. No new desktop/source read, no per-import trace, no claim of complete dynamic runtime closure or final binary persistence.",
    "native_reruns": 0, "desktop_actions": 0, "remote_reads": 0, "whole_h4_run_claim": False
}
output = OUT / "source-configuration-review.json"
output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"report": identity(output), "tracked_count": 11840, "tracked_bytes": 183410043,
                  "configuration_count": 12, "common_and_worktree_config_count": 5}))
