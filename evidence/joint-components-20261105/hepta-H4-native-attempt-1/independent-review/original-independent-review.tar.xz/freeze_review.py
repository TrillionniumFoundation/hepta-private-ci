"""Freeze the already completed H4 local read-only audit and its exact inputs."""
from pathlib import Path
import hashlib
import json

WORKSPACE = Path('/workspace/scratch/93bfcfe29fc8')
ROOT = WORKSPACE / 'pq_recovery/h4-actual-review'
NATIVE = WORKSPACE / 'model_storage/h4-capture-repair/native'


def descriptor(path):
    path = path.resolve()
    data = path.read_bytes()
    return {'path': str(path.relative_to(WORKSPACE)), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


names = [
    'final-use-profile-controls-review.json', 'full-evidence-library-review.json',
    'ordinary-process-review.json', 'source-configuration-review.json',
    'completion-review.json', 'delivery-inventory-review.json',
]
reports = {name: json.loads((ROOT / name).read_text()) for name in names}
delivery_path = NATIVE / 'h4-native-attempt1-delivery.json'
delivery = json.loads(delivery_path.read_text())
assert descriptor(delivery_path)['sha256'] == 'bda6c7127e6b4a84db3256898668cb664d933836e6332275cd9dfaa624f51fba'
inputs = {Path(row['path']).resolve() for row in delivery['files']}
inputs.add(delivery_path.resolve())
for report in reports.values():
    for row in report.get('inputs', []):
        path = Path(row['path'])
        if not path.is_absolute():
            path = WORKSPACE / path
        actual = descriptor(path)
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row
        inputs.add(path.resolve())
for name in ['h4-frozen-package-manifest.json', 'h4-exact-launch-plan.json']:
    path = NATIVE / name
    if path.exists():
        inputs.add(path.resolve())
for path in NATIVE.glob('*bundle*'):
    if path.is_file():
        inputs.add(path.resolve())
for name in ['remaining-selected-read-failed.raw.json', 'directory-capacity-rejection.txt']:
    inputs.add((NATIVE / 'joint-h4-native-attempt-1' / name).resolve())
inventory = reports['delivery-inventory-review.json']
parent_index = Path(inventory['prospective_h3_overlap']['parent_index']['path'])
inputs.add((parent_index if parent_index.is_absolute() else WORKSPACE / parent_index).resolve())

copied = []
for original in sorted(inputs):
    relative = original.relative_to(WORKSPACE)
    data = original.read_bytes()
    target = ROOT / 'inputs' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == data, str(target)
    else:
        target.write_bytes(data)
    copied.append({'original_path': str(relative), **descriptor(target)})

completion = reports['completion-review.json']
summary = {
    'schema': 'H4-independent-complete-actual-native-review-v1',
    'status': 'INDEPENDENT_ACTUAL_ONE_SOURCE_DESKTOP_GATES_VERIFIED',
    'source_commit': completion['source_commit'], 'source_tree': completion['source_tree'],
    'job_id': completion['authoritative_job_id'],
    'authoritative_terminal_unix_ms': completion['authoritative_terminal_unix_ms'],
    'authoritative_terminal_utc': completion['authoritative_terminal_utc'],
    'coordinator_elapsed_seconds': completion['coordinator_elapsed_seconds'],
    'original_outer_budget_seconds': 5400, 'original_per_test_seconds': 60,
    'original_ordered_gates': 20, 'selected_rust_case_occurrences': 74,
    'additional_rust_case_occurrences': [6, 10, 50, 161],
    'rust_case_occurrences': 301, 'unique_target_case_pairs': 276,
    'primary_fd_records': 301, 'live_records': 294,
    'direct_live_matches': 293, 'exact_auxiliary_helpers': 1,
    'daemon_observations': 2, 'total_inventory_observations': 597,
    'unique_complete_images': 11, 'unique_recorded_image_bytes': 1674575368,
    'retained_aliases': 32, 'unobserved_by_polling_but_primary_fd_present': 8,
    'ordinary_process': {'post': 1, 'physical_apply': 1, 'lookup': 2, 'nonce': 1,
        'same_operation': True, 'first_full_copy': True, 'second_held_object_reuse': True,
        'second_full_hash': False, 'controlled_local_operator_provider': True,
        'supervisor_prefenced_sigkill': True},
    'full_library_ignored': ['authbus_outbox_tests::crash_delivery_child'],
    'source_guard_tracked_files': 11840, 'source_guard_tracked_bytes': 183410043,
    'external_configuration_files': 12, 'git_configuration_files': 5,
    'source_and_configuration_before_after_equal': True,
    'owner_delivery': descriptor(delivery_path),
    'owner_declared_files': 131, 'owner_declared_bytes': 5522990,
    'subreviews': [descriptor(ROOT / name) for name in names],
    'subreview_scope_update': 'delivery-inventory-review completes the remaining-live collection boundary stated earlier in completion-review; earlier reports are preserved byte-for-byte.',
    'copied_exact_inputs': copied,
    'copied_exact_input_files': len(copied),
    'copied_exact_input_bytes': sum(row['bytes'] for row in copied),
    'reviewer_initial_errors': [
        'completion parser initially addressed job_id outside the original job response envelope; original error and script retained',
        'delivery parser initially equated uppercase delivery display status with lowercase pipeline literal; original error and script retained',
        'final review input-copy assembly was interrupted before review/manifest creation; relative and absolute paths normalized, existing copied bytes verified unchanged',
    ],
    'limits': [
        'Only the exact one-source desktop execution is qualified; no joint-release or hosted matrix claim.',
        'H1/H2/H3 historical failures remain unchanged.',
        'Actual retained ELF bytes have not been reread by this local audit; complete archive and consumer closure remain pending.',
        '11 H3 overlaps are metadata SHA/size matches, not a substitute for required H4 twice-full-read or parent archive verification.',
        'No independent WAN, multi-operator custody, full-host restore, complete model inference, learning quality, or universal generic-owner bridge qualification.',
        'Dynamic bytecode observation is scoped and is not a complete import-closure trace.',
    ],
    'native_reruns': 0, 'desktop_actions': 0, 'remote_reads': 0,
    'archive_dispatches': 0, 'joint_release_qualification': False,
    'h1_bulk_state': {'status': 'PAUSED', 'verified_bytes': 65536, 'in_flight': 0},
}
write(ROOT / 'review.json', summary)
files = [descriptor(path) for path in sorted(ROOT.rglob('*'))
         if path.is_file() and '__pycache__' not in path.parts
         and path != ROOT / 'delivery-manifest.json']
manifest = {
    'schema': 'H4-independent-complete-actual-review-delivery-v1',
    'source_commit': summary['source_commit'], 'source_tree': summary['source_tree'],
    'job_id': summary['job_id'], 'review': descriptor(ROOT / 'review.json'),
    'file_count': len(files), 'total_bytes': sum(row['bytes'] for row in files),
    'files': files, 'native_reruns': 0, 'remote_reads': 0,
    'archive_or_release_credit': False,
}
write(ROOT / 'delivery-manifest.json', manifest)
for name in ['review.json', 'review.md', 'delivery-manifest.json']:
    print(json.dumps(descriptor(ROOT / name), ensure_ascii=False))
print(json.dumps({'files': len(files), 'total_bytes': manifest['total_bytes'],
                  'copied_inputs': len(copied), 'copied_input_bytes': summary['copied_exact_input_bytes']}))
