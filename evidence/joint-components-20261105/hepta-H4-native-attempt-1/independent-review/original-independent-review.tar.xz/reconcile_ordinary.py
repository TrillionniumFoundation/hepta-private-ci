#!/usr/bin/env python3
"""Read actual local H4 ordinary-process evidence; no native or remote work."""
from collections import Counter
import hashlib
import json
from pathlib import Path
from reconcile_gate import EVIDENCE, NATIVE, OUT, ROOT, RUNNER, SOURCE, TREE, identity, load, raw_cases

receipt, raw, cases, files = raw_cases("effect-pq-product")
expected_names = {"pq_effect_survives_owned_agentd_kill_after_provider_fsync_without_resend",
                  "binary::held_daemon_image_reuse_refuses_wrong_changed_or_missing_files"}
assert len(cases) == 2 and {name for name, _ in cases} == expected_names
fd_path = EVIDENCE / "effect-pq-product.fd-executed-binaries.json"
config_path = EVIDENCE / "effect-pq-product.fd-capture-config.json"
fd, config = load(fd_path), load(config_path)
assert fd["errors"] == [] and fd["per_case_bijection_verified"] is True
assert fd["runner_declared_binary_counts"] == [1]
assert Counter(row["exact_test"] for row in fd["records"]) == Counter(name for name, _ in cases)
assert len({(row["pid"], row["start_ticks"]) for row in fd["records"]}) == 2
assert fd["config_sha256"] == identity(config_path)["sha256"]
assert fd["runner_sha256"] == RUNNER and len(fd["unique_actual_elf_sha256"]) == 1
environment_path = EVIDENCE / "native-environment.json"
environment = load(environment_path)
for row in fd["records"]:
    assert row["source"] == config["source"]
    assert row["source"]["commit"] == SOURCE and row["source"]["tree"] == TREE
    assert row["source"]["environment_sha256"] == identity(environment_path)["sha256"]
    assert row["capture_config_sha256"] == identity(config_path)["sha256"] and row["runner_sha256"] == RUNNER
    assert row["pre_exec_fd_identity_verified"] and row["coordinator_descendant_verified"]
    assert row["coordinator"] == config["coordinator"] and row["status"] == "pre_exec_fd_bound"
    assert row["argv"] == [row["actual_executable"], "--exact", row["exact_test"], "--nocapture"]
    assert row["expected_binary_target"] == "automation_effect_pq_product"
proofs = list((EVIDENCE / "effect-pq-product-process").glob("*/completed.json"))
assert len(proofs) == 1
proof_path = proofs[0]
directory = proof_path.parent
proof = load(proof_path)
source_path = directory / "source.json"
source = load(source_path)
first_path, second_path = directory / "first-process.json", directory / "second-process.json"
first, second = load(first_path), load(second_path)
assert proof["first_process"] == first and proof["second_process"] == second
assert first["source"] == second["source"] == proof["source"] == source
assert source["commit"] == SOURCE and source["tree"] == TREE and source["qualification_binding"] is True
assert source["cargo_lock_sha256"] == environment["source"]["cargo_lock_sha256"] == config["source"]["lock_sha256"]
assert source["rustc"].strip() == environment["rustc"].strip()
for name, value in source["environment"].items():
    if name == "RUSTUP_TOOLCHAIN":
        assert value == environment["environment"][name] + "-x86_64-unknown-linux-gnu"
    else:
        assert value == environment["environment"][name]
assert first["capture_method"] == "first-live-fd-hash-copy"
assert first["full_hash_and_copy_this_capture"] is True and first["same_held_file_object_verified"] is False
assert second["capture_method"] == "same-held-file-object-reuse"
assert second["full_hash_and_copy_this_capture"] is False and second["same_held_file_object_verified"] is True
assert (first["pid"], first["start_ticks"]) != (second["pid"], second["start_ticks"])
assert (first["spawn_generation"], second["spawn_generation"]) == (1, 5)
for name in ("actual_executable", "cargo_resolved_binary", "retained_copy", "sha256", "bytes", "device", "inode"):
    assert first[name] == second[name]
for process in (first, second):
    assert process["opened_fd_and_process_identity_verified"] is True
    assert process["owner_and_generation_verified"] is True
    assert process["origin_capture_pid"] == first["pid"] and process["origin_capture_start_ticks"] == first["start_ticks"]
assert first["bytes"] == 488112384 and first["sha256"] == "00a637f55c720b06a655b569930bddaef19fd791467bc4784fe0bfb9e0002a26"
barrier_path = directory / "provider-fsync-before-kill.json"
exit_path = directory / "first-process-exit.json"
barrier, first_exit = load(barrier_path), load(exit_path)
assert barrier["provider_record"] == proof["provider_record"]
assert barrier["client_result_pending"] is True and barrier["ack_bytes_sent"] == 0
assert barrier["physical_apply_count"] == barrier["post_count"] == 1
assert barrier["authority_frontier"] == proof["frontier_retained"]
assert first_exit["exact_lease_removed"] and first_exit["supervisor_pre_fenced_draining"]
assert first_exit["requested_signal"] == "SIGKILL" and first_exit["next_starting_generation"] == second["spawn_generation"]
assert proof["post_count"] == proof["physical_apply_count"] == proof["used_nonces"] == 1
assert proof["lookup_count"] == 2 and proof["frontier_cas_count"] == 1
assert proof["frontier_retained"]["authority_epoch"] == 9 and proof["frontier_retained"]["revocation_revision"] == 1
assert proof["provider_ack"]["key"] == proof["provider_record"]["effect_key"]
for name in ("payload_sha256", "provider_operation_id_sha256"):
    assert proof["provider_ack"][name] == proof["provider_record"][name]
assert proof["provider_ack"]["status"] == proof["provider_record"]["status"] == "completed"
assert proof["terminal"]["observation"] == "succeeded"
assert proof["cleanup_exit"]["exact_lease_removed"] and proof["cleanup_exit"]["supervisor_pre_fenced_draining"]
assert proof["cleanup_exit"]["requested_signal"] == "SIGKILL" and proof["cleanup_exit"]["next_starting_generation"] == 9

formatted = ROOT / "model_storage/h3-preparation/formatted-candidate"
product_source = formatted / "codex-rs/hepta-agentd/tests/automation_effect_pq_product.rs"
helper_source = formatted / "codex-rs/hepta-agentd/tests/support/automation_effect_binary.rs"
assert identity(product_source)["sha256"] == "9954baf1db179c35f070514ea897614ff2e54b7a8c8b1a05e24144a5cfb7994c"
assert identity(helper_source)["sha256"] == "dc9525efc447080f79e93ae3a7aa79e2c75feefbed80ea0aca2d09b747bda9ab"
files += [fd_path, config_path, environment_path, proof_path, source_path, first_path, second_path,
          barrier_path, exit_path, product_source, helper_source]
report = {
    "schema": "H4-independent-ordinary-process-review-v1", "status": "ACTUAL_TWO_CASES_AND_SIX_PROCESS_PROOFS_MATCH",
    "source_commit": SOURCE, "source_tree": TREE, "wrapper_elapsed_seconds": receipt["elapsed_seconds"],
    "actual_cases": cases, "primary_test_image_sha256": fd["unique_actual_elf_sha256"],
    "completed_sha256": identity(proof_path)["sha256"], "first_process": first, "second_process": second,
    "provider_fsync_before_kill": barrier, "first_owned_exit": first_exit,
    "post_count": 1, "physical_apply_count": 1, "lookup_count": 2, "used_nonces": 1,
    "provider_original_key_payload_operation_equal": True, "terminal": proof["terminal"],
    "final_cleanup": proof["cleanup_exit"], "retained_frontier": proof["frontier_retained"],
    "reached_assertions_from_exact_source_and_actual_pass": [
        "Provider durably applies the original occurrence before the controlled kill; client has no ACK bytes/result.",
        "Supervisor pre-fences and kills the exact owner; old lease removed, new process and generation 5 recorded.",
        "Old client and old-generation grant refuse entry without a second POST.",
        "First lookup absence remains Indeterminate and grants no retry; second lookup settles the original operation.",
        "Third ordinary local read returns identical terminal without an additional provider lookup.",
        "POST 1 / physical application 1 / lookups 2 / original durable FinalUse nonce 1.",
        "Original evidence trust/frontier bytes and claimed external authority frontier are not reset across restart.",
        "Reopened durable store returns the original key/operation acknowledgement and same terminal receipt.",
        "Exact second process cleanup and lease removal complete; next generation 9."
    ],
    "limits": [
        "Controlled local operator/provider with supervisor pre-fenced SIGKILL; not surprise power loss, full-host restore or independently administered custody.",
        "Second generation uses explicit held-file-object verification, not a second full daemon hash/copy.",
        "Opened object stability is not a guarantee against a hostile privileged writer.",
        "This local audit reconciles original proof/receipt/FD bytes; actual retained daemon ELF bytes are not yet downloaded/rehashed by this reviewer.",
        "No retrospective H1/H2/H3 credit and no generic tool/provider PQ bridge qualification."
    ],
    "inputs": [identity(path) for path in dict.fromkeys(files)],
    "native_reruns": 0, "desktop_actions": 0, "remote_reads": 0,
    "whole_h4_run_claim": False
}
output = OUT / "ordinary-process-review.json"
output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"report": identity(output), "actual_cases": len(cases), "process_proofs": 6,
                  "post_apply_lookup_nonce": [1, 1, 2, 1]}))
