#!/usr/bin/env python3
"""Reconcile already collected H4 raw/FD/live records locally; never runs a gate."""
from collections import Counter
from datetime import datetime
import argparse
import hashlib
import json
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
NATIVE = ROOT / "model_storage/h4-capture-repair/native"
EVIDENCE = NATIVE / "joint-h4-native-attempt-1"
SOURCE = "6db78eca53a5acdda0d96873d3f4cd65863426f0"
TREE = "e91f5994017fc5d2cfe58d405a20ee6ad9376772"
RUNNER = "9679cc6e11762c29b4c0ee92dd7715d3fce0555a6f8e0e10ed9d0b007951381a"
KILLED = "final_use::tests::killed_owner_releases_lock_but_keeps_claim"
IGNORED = "authbus_outbox_tests::crash_delivery_child"
IMAGE = ("device", "inode", "bytes", "mtime_ns", "ctime_ns")

def load(path):
    return json.loads(path.read_bytes())

def identity(path):
    b = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}

def image(row):
    return {key: row[key] for key in IMAGE}

def process_key(row):
    return row["pid"], row["start_ticks"]

def raw_cases(name):
    receipt_path = EVIDENCE / (name + ".json")
    receipt = load(receipt_path)
    raw_path = EVIDENCE / receipt["log_file"]
    raw = raw_path.read_bytes()
    assert len(raw) == receipt["log_bytes"] and hashlib.sha256(raw).hexdigest() == receipt["log_sha256"]
    assert receipt["before"] == receipt["after"]
    assert receipt["before"]["commit"] == SOURCE and receipt["before"]["tree"] == TREE and receipt["before"]["dirty"] is False
    assert receipt["source_sha"] == receipt["tested_sha"] == SOURCE
    assert receipt["status"] == "passed" and receipt["command_exit_code"] == receipt["exit_code"] == 0
    assert receipt["timed_out"] is False and receipt["output_limit_exceeded"] is False
    clean = re.sub(r"\x1b\[[0-9;]*m", "", raw.decode())
    cases = re.findall(r"^test ([A-Za-z0-9_:]+) \.\.\. (ok|ignored|FAILED)\s*$", clean, re.M)
    assert all(outcome == "ok" for _, outcome in cases)
    assert len(cases) == receipt["observed_passed_tests"] and receipt["observed_failed_tests"] == 0
    counts = Counter(name for name, _ in cases)
    assert counts and set(counts.values()) == {1}
    return receipt, clean, cases, [receipt_path, raw_path]

def reconcile(name):
    receipt, raw, cases, files = raw_cases(name)
    fd_path = EVIDENCE / (name + ".fd-executed-binaries.json")
    config_path = EVIDENCE / (name + ".fd-capture-config.json")
    live_path = EVIDENCE / (name + ".live-polled-binaries.json")
    fd, config, live = load(fd_path), load(config_path), load(live_path)
    files += [fd_path, config_path, live_path, EVIDENCE / "native-environment.json", NATIVE / "nextest_fd_runner.py"]
    assert identity(NATIVE / "nextest_fd_runner.py")["sha256"] == RUNNER
    config_hash = identity(config_path)["sha256"]
    assert fd["config_sha256"] == config_hash and fd["runner_sha256"] == RUNNER
    assert fd["errors"] == live["errors"] == [] and fd["per_case_bijection_verified"] is True
    assert fd["actual_cases"] == [list(x) for x in cases]
    assert fd["runner_declared_binary_counts"] == [1]
    assert re.findall(r"Starting\s+\d+\s+tests?\s+across\s+(\d+)\s+binar", raw) == ["1"]
    assert Counter(row["exact_test"] for row in fd["records"]) == Counter(case for case, _ in cases)
    fd_ids = {process_key(row): row for row in fd["records"]}
    assert len(fd_ids) == len(fd["records"]) == len(cases)
    environment_hash = identity(EVIDENCE / "native-environment.json")["sha256"]
    for row in fd["records"]:
        assert row["schema"] == "hepta-nextest-fd-runner-v1" and row["status"] == "pre_exec_fd_bound"
        assert row["source"] == config["source"] and row["gate"] == config["gate"] == name
        assert row["source"]["commit"] == SOURCE and row["source"]["tree"] == TREE
        assert row["source"]["environment_sha256"] == environment_hash
        assert row["capture_config_sha256"] == config_hash and row["runner_sha256"] == RUNNER
        assert row["coordinator"] == config["coordinator"] and row["coordinator_descendant_verified"] is True
        assert row["pre_exec_fd_identity_verified"] is True and row["phase"] == "run"
        assert row["observed_selected_tests"] == [row["exact_test"]]
        assert row["argv"] == [row["actual_executable"], "--exact", row["exact_test"], "--nocapture"]
        assert datetime.fromisoformat(receipt["started_at"]).timestamp() <= row["captured_unix"] <= datetime.fromisoformat(receipt["finished_at"]).timestamp()
    hashes = sorted({row["sha256"] for row in fd["records"]})
    assert len(hashes) == 1 and hashes == fd["unique_actual_elf_sha256"]
    assert len({row["actual_executable"] for row in fd["records"]}) == 1
    assert len({tuple(image(row).values()) for row in fd["records"]}) == 1
    assert fd["live_polling_corroboration"]["sha256"] == identity(live_path)["sha256"]
    assert fd["live_polling_corroboration"]["captured_processes"] == len(live["records"])
    live_ids = {process_key(row): row for row in live["records"]}
    assert len(live_ids) == len(live["records"])
    direct, helpers = [], []
    for key, observed in live_ids.items():
        child, parent = observed["process_before"], observed["direct_parent_before"]
        assert child == observed["process_after"] and parent == observed["direct_parent_after"]
        assert process_key(child) == key and child["argv"] == observed["argv"]
        assert child["actual_executable"] == observed["actual_executable"] and child["image"] == image(observed)
        assert child["ppid"] == parent["pid"] and parent["pid"] != child["pid"]
        assert observed["wrapper_descendant_verified"] and observed["post_open_task_and_exe_verified"]
        assert observed["held_child_and_parent_images_stable_through_retention"]
        assert 0 < observed["relationship_observed_before_unix"] <= observed["relationship_observed_after_unix"] <= observed["captured_unix"]
        chain = observed["ancestor_chain_before"]
        assert chain == observed["ancestor_chain_after"] and 2 <= len(chain) <= 64
        assert len({x["pid"] for x in chain}) == len(chain)
        assert all(left["ppid"] == right["pid"] for left, right in zip(chain, chain[1:]))
        assert chain[0] == {k: child[k] for k in ("pid", "ppid", "start_ticks")}
        assert chain[1] == {k: parent[k] for k in ("pid", "ppid", "start_ticks")}
        assert (chain[-1]["pid"], chain[-1]["start_ticks"]) == (observed["wrapper_pid"], observed["wrapper_start_ticks"])
        assert chain[-1]["ppid"] == config["coordinator"]["pid"]
        if key in fd_ids:
            outer = fd_ids[key]
            assert observed["argv"] == outer["argv"] and observed["observed_selected_tests"] == [outer["exact_test"]]
            direct.append({"pid": key[0], "start_ticks": key[1], "exact_test": outer["exact_test"]})
        else:
            assert name == "final-use-profile-controls" and observed["observed_selected_tests"] == [KILLED]
            assert process_key(parent) in fd_ids
            outer = fd_ids[process_key(parent)]
            assert outer["exact_test"] == KILLED and outer["expected_binary_target"] == "codex_hepta_contracts"
            assert child["argv"] == parent["argv"] == outer["argv"] == [outer["actual_executable"], "--exact", KILLED, "--nocapture"]
            assert parent["actual_executable"] == outer["actual_executable"] and parent["image"] == image(outer)
            helpers.append({"observed": observed, "direct_parent_fd": outer})
        assert observed["source"] == outer["source"] and observed["sha256"] == outer["sha256"]
        assert image(observed) == image(outer) and observed["actual_executable"] == outer["actual_executable"]
    assert len(helpers) <= 1
    declared = fd["live_process_correspondence"]
    assert declared["errors"] == [] and declared["direct_fd_matches"] == direct
    assert len(declared["auxiliary_processes"]) == len(helpers)
    for auxiliary, helper in zip(declared["auxiliary_processes"], helpers):
        assert auxiliary["test_outcome_credit"] is False
        assert process_key(auxiliary) == process_key(helper["observed"])
        assert (auxiliary["parent_pid"], auxiliary["parent_start_ticks"]) == process_key(helper["direct_parent_fd"])
    if name == "final-use-profile-controls":
        assert len(cases) == 50 and all("final_use" in case for case, _ in cases)
        assert config["predicate"] == {"kind": "contains", "value": "final_use"}
        assert receipt["command"] == ["just", "test", "--locked", "-p", "codex-hepta-contracts", "--lib", "-E", "test(final_use)", "--no-capture", "--retries", "0", "--test-threads=1"]
        assert len(direct) == 49 and len(helpers) == 1
    else:
        extra_path = NATIVE / "h4-extra-controls.json"
        extra = load(extra_path)["full_evidence_library"]
        assert receipt["command"] == extra["command"] and receipt["minimum_tests"] == extra["minimum"] == 22
        assert len(cases) == 161 and Counter(case for case, _ in cases) == Counter(extra["expected_names"])
        assert config["selected_names"] == sorted(extra["expected_names"])
        assert re.findall(r"Starting\s+(\d+)\s+tests?\s+across\s+1\s+binar(?:y|ies)\s+\((\d+)\s+tests?\s+skipped\)", raw) == [("161", "1")]
        assert all(IGNORED not in row["observed_selected_tests"] for row in live["records"]) and helpers == []
        listing_path = EVIDENCE / "full-evidence-ignored-list.json"
        listing_log = EVIDENCE / "full-evidence-ignored-list.log"
        listing = load(listing_path)
        ignored = sorted(re.findall(r"^([A-Za-z0-9_:]+): test$", listing_log.read_text(), re.M))
        assert ignored == listing["actual_ignored"] == listing["expected_ignored"] == extra["expected_ignored"] == [IGNORED]
        assert listing["log_sha256"] == identity(listing_log)["sha256"]
        assert listing["sha256"] == hashes[0] and listing["same_image"] is True and listing["exit_code"] == 0
        assert listing["source"] == config["source"]
        assert listing["command"] == [fd["records"][0]["actual_executable"], "--list", "--ignored", "--format", "terse"]
        files += [extra_path, listing_path, listing_log]
    report = {"schema": "H4-independent-actual-gate-reconciliation-v1", "gate": name,
              "source_commit": SOURCE, "source_tree": TREE,
              "status": "THIS_GATE_RAW_FD_AND_LIVE_RECORDS_MATCH", "wrapper_elapsed_seconds": receipt["elapsed_seconds"],
              "before_after_identity": receipt["before"], "raw_cases": cases,
              "exact_primary_records": len(fd["records"]), "unique_pid_start_records": len(fd_ids),
              "unique_actual_image_sha256": hashes, "actual_image_bytes": fd["records"][0]["bytes"],
              "live_direct_matches": direct, "auxiliary_helpers": helpers,
              "primary_not_seen_by_polling": [row for key, row in fd_ids.items() if key not in live_ids],
              "inputs": [identity(path) for path in dict.fromkeys(files)],
              "scope": "Independent reconciliation of actual retained raw/receipt/FD/live JSON bytes. No native rerun, no actual remote ELF byte read, no whole-run PASS or retrospective H3 attribution. Exact final terminal/source-after/configuration/ordinary proof reviewed separately."}
    path = OUT / (name + "-review.json")
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"gate": name, "raw_cases": len(cases), "fd_records": len(fd_ids), "live_direct": len(direct),
                      "helpers": len(helpers), "report": identity(path)}))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("gate", choices=["final-use-profile-controls", "full-evidence-library"])
    reconcile(parser.parse_args().gate)
