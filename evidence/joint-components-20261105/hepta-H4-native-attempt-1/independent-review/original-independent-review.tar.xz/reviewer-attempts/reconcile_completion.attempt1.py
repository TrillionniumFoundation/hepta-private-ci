#!/usr/bin/env python3
"""Reconcile the completed original H4 receipts; no native or remote execution."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import re
from pathlib import Path
from reconcile_gate import EVIDENCE, NATIVE, OUT, ROOT, RUNNER, SOURCE, TREE, identity, load

def tool_json(path):
    response = load(path)
    assert response.get("isError") is not True
    if isinstance(response.get("structuredContent"), dict):
        return response["structuredContent"]
    values = [json.loads(row["text"]) for row in response["content"] if row.get("type") == "text"]
    assert len(values) == 1
    return values[0]

pipeline_path = EVIDENCE / "pipeline-status.json"
pipeline = load(pipeline_path)
plan_path = NATIVE / "h4-native-plan.json"
plan = load(plan_path)
terminal_path = EVIDENCE / "status-8.raw.json"
terminal = tool_json(terminal_path)
launch_path = EVIDENCE / "launch.raw.json"
launch = tool_json(launch_path)
request_path = EVIDENCE / "launch-request.json"
request = load(request_path)
assert terminal["state"] == "succeeded" and terminal["exit_code"] == 0 and terminal["timed_out"] is False
assert terminal["automatic_retry"] is False and terminal["cancelled"] is False
assert terminal["output_complete"] is True and terminal["output_durable"] is True
assert terminal["terminal_publication_confirmed"] is True
assert terminal["job_id"] == launch["job_id"] == "1a1ade2970f-fc05-5b5c"
assert terminal["launch_nonce"] == launch["launch_nonce"]
assert request["idempotency_key"] == "ms-joint-h4-native-6db78-attempt1-93bfcf" and request["timeout_seconds"] == 5400
assert request["args"][-3:] == [SOURCE, TREE, "joint-h4-native-attempt-1"]
assert pipeline["status"] == "passed-one-source-desktop-gates-only" and pipeline["phase"] == "final-source-recorded"
assert pipeline["source_before"] == pipeline["source_after"] == load(EVIDENCE / "full-source-after.json")
assert pipeline["configuration_unchanged"] is True
assert 0 < pipeline["timed_coordinator_elapsed_seconds"] < 5400
assert pipeline["budget_semantics"]["outer_seconds"] == 5400
planned = {step["name"]: step for step in plan["steps"]}
native_steps = [step for step in plan["steps"] if step["expected_names"]]
expected_order = ["dependencies", "execution-source-controls", "diverse-source-controls"]
expected_order += [step["name"] for step in native_steps]
expected_order += ["original-six-effect-controls", "provider-effect-existing-and-pq", "final-use-profile-controls", "full-evidence-library", "fix", "format"]
assert list(pipeline["gates"]) == expected_order
assert sum(len(step["expected_names"]) for step in native_steps) == plan["selected_total"] == 74

files = [pipeline_path, plan_path, terminal_path, launch_path, request_path]
rows, native_occurrences, primary_records = [], [], []
for name in expected_order:
    entry = pipeline["gates"][name]
    path = EVIDENCE / entry["receipt"]
    receipt = load(path)
    assert identity(path)["sha256"] == entry["receipt_sha256"]
    assert receipt["before"] == receipt["after"] == pipeline["source_after"]["identity"]
    assert receipt["source_sha"] == receipt["tested_sha"] == SOURCE
    assert receipt["status"] == entry["status"] == "passed"
    assert receipt["exit_code"] == receipt["command_exit_code"] == entry["command_exit_code"] == entry["wrapper_exit"] == 0
    assert receipt["timed_out"] is False and receipt["output_limit_exceeded"] is False
    assert receipt["observed_failed_tests"] == entry["failed"] == 0
    assert receipt["observed_passed_tests"] == entry["passed"]
    raw_path = EVIDENCE / receipt["log_file"]
    raw = raw_path.read_bytes()
    assert len(raw) == receipt["log_bytes"] and hashlib.sha256(raw).hexdigest() == receipt["log_sha256"]
    assert entry["log_file"] == receipt["log_file"] and receipt["elapsed_seconds"] == entry["wrapper_elapsed_seconds"]
    clean = re.sub(r"\x1b\[[0-9;]*m", "", raw.decode())
    cases = re.findall(r"^test ([A-Za-z0-9_:]+) \.\.\. (ok|ignored|FAILED)\s*$", clean, re.M)
    assert entry["observed_cases"] == [list(row) for row in cases]
    if name in planned:
        step = planned[name]
        assert receipt["command"] == step["command"] and receipt["minimum_tests"] == step["minimum"]
        assert entry["command_budget_seconds"] == step["timeout_seconds"]
        if step["expected_names"]:
            assert entry["exact_names_passed"] is True
            assert Counter(case for case, _ in cases) == Counter(step["expected_names"])
    if name in ("execution-source-controls", "diverse-source-controls"):
        count = 135 if name == "execution-source-controls" else 32
        assert receipt["observed_passed_tests"] == receipt["minimum_tests"] == count
        assert re.findall(r"^Ran (\d+) tests? in [^\n]+$", clean, re.M) == [str(count)]
        assert re.search(r"^OK\s*$", clean, re.M)
        assert entry["command_budget_seconds"] == 3600 and entry["timeout_argument_omitted_for_original_default"] is True
    elif cases:
        assert all(result == "ok" for _, result in cases) and len(cases) == receipt["observed_passed_tests"]
        assert len(set(case for case, _ in cases)) == len(cases)
        fd_path = EVIDENCE / (name + ".fd-executed-binaries.json")
        fd = load(fd_path)
        assert fd == entry["actual_binary_evidence"] and fd["errors"] == [] and fd["per_case_bijection_verified"] is True
        assert Counter(row["exact_test"] for row in fd["records"]) == Counter(case for case, _ in cases)
        assert len({(row["pid"], row["start_ticks"]) for row in fd["records"]}) == len(cases)
        assert fd["runner_sha256"] == RUNNER
        expected_images = 2 if name == "neural-runtime-input" else 1
        assert len(fd["unique_actual_elf_sha256"]) == expected_images and fd["runner_declared_binary_counts"] == [expected_images]
        for row in fd["records"]:
            assert row["source"] == entry["source"]
            assert row["source"]["commit"] == SOURCE and row["source"]["tree"] == TREE
            assert row["pre_exec_fd_identity_verified"] is True and row["coordinator_descendant_verified"] is True
            assert row["phase"] == "run" and row["status"] == "pre_exec_fd_bound"
            assert row["gate"] == name and row["runner_sha256"] == RUNNER
            assert row["argv"] == [row["actual_executable"], "--exact", row["exact_test"], "--nocapture"]
        primary_records.extend((name, row) for row in fd["records"])
        native_occurrences.extend((name, case) for case, _ in cases)
        files.append(fd_path)
    if name == "format":
        assert receipt["command"] == ["just", "fmt", "--base", "1556a4df6e279055fd8196f81a4ca2fe0f19384a"]
        assert entry["command_budget_seconds"] == 300 and len(raw) == 0
    rows.append({"gate": name, "passed": receipt["observed_passed_tests"], "failed": 0,
                 "wrapper_elapsed_seconds": receipt["elapsed_seconds"], "original_wrapper_budget_seconds": entry["command_budget_seconds"],
                 "receipt_sha256": identity(path)["sha256"], "raw_file": receipt["log_file"],
                 "raw_bytes": len(raw), "raw_sha256": receipt["log_sha256"]})
    files += [path, raw_path]
assert len(native_occurrences) == len(primary_records) == 301
assert len({(row["pid"], row["start_ticks"]) for _, row in primary_records}) == 301
assert len({(row["expected_binary_target"], row["exact_test"]) for _, row in primary_records}) <= 301

guard_log = EVIDENCE / "selected-tests-guard.log"
assert guard_log.read_bytes() == b""
ordinary_verification_path = EVIDENCE / "effect-pq-product-daemon-verification.json"
ordinary_verification = load(ordinary_verification_path)
proofs = list((EVIDENCE / "effect-pq-product-process").glob("*/completed.json"))
assert len(proofs) == 1
assert ordinary_verification["verified"] is True and ordinary_verification["sha256"] == identity(proofs[0])["sha256"]
assert Path(ordinary_verification["completed"]).name == "completed.json"
assert Path(ordinary_verification["completed"]).parent.name == proofs[0].parent.name
files += [guard_log, ordinary_verification_path, proofs[0]]
report = {
    "schema": "H4-independent-original-completion-reconciliation-v1",
    "status": "AUTHORITATIVE_SUCCEEDED_AND_ORIGINAL_ORDERED_GATE_RECEIPTS_MATCH",
    "source_commit": SOURCE, "source_tree": TREE, "authoritative_job_id": terminal["job_id"],
    "authoritative_terminal_unix_ms": terminal["at_unix_ms"],
    "authoritative_terminal_utc": datetime.fromtimestamp(terminal["at_unix_ms"] / 1000, timezone.utc).isoformat(),
    "automatic_retry": False, "outer_timeout": False, "coordinator_elapsed_seconds": pipeline["timed_coordinator_elapsed_seconds"],
    "original_outer_budget_seconds": 5400, "original_per_test_seconds": 60,
    "pipeline_scope": pipeline["scope"], "gate_count": len(rows), "gates": rows,
    "original_selected_case_occurrences": 74, "compatibility_case_occurrences": 6,
    "provider_case_occurrences": 10, "finaluse_case_occurrences": 50, "full_library_case_occurrences": 161,
    "rust_case_occurrences_across_gates": 301,
    "unique_target_and_case_pairs": len({(row["expected_binary_target"], row["exact_test"]) for _, row in primary_records}),
    "rust_primary_fd_records": 301, "unique_primary_pid_start_pairs": 301,
    "selected_source_python_controls": [135, 32], "selected_guard_original_empty_log_actually_read": True,
    "format_original_empty_log_actually_read": True,
    "ordinary_coordinator_verification": ordinary_verification,
    "inputs": [identity(path) for path in dict.fromkeys(files)],
    "limits": [
        "Counts across overlapping gates are case occurrences, not 301 independent scenarios.",
        "All primary FD/raw ledgers were reconciled; full contemporaneous live records are independently reconciled in the separate FinalUse/full-library reports. Other live sidecars remain for the owner's complete inventory delivery.",
        "Original source/configuration guards are reconciled separately. This does not download retained ELF bytes or establish final durable archive closure.",
        "One source-head desktop execution only: no hosted matrix, WAN, independent custody, full-host restoration, complete model inference or learning qualification.",
        "H1/H2/H3 failures remain unchanged; no retrospective capture attribution."
    ],
    "native_reruns": 0, "desktop_actions": 0, "remote_reads": 0,
    "joint_release_qualification": False
}
path = OUT / "completion-review.json"
path.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"report": identity(path), "gates": len(rows), "rust_case_occurrences": 301,
                  "unique_target_case_pairs": report["unique_target_and_case_pairs"], "raw_inputs": len(files)}))
