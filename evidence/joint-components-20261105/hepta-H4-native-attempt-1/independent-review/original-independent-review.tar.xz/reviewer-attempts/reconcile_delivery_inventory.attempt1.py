#!/usr/bin/env python3
"""Independently verify delivered bytes and every H4 inventory record pointer."""
from collections import Counter, defaultdict
import json
from pathlib import Path
from reconcile_gate import EVIDENCE, NATIVE, OUT, ROOT, SOURCE, TREE, identity, load, image, process_key, KILLED

delivery_path = NATIVE / "h4-native-attempt1-delivery.json"
inventory_path = EVIDENCE / "h4-actual-image-inventory.json"
delivery, inventory = load(delivery_path), load(inventory_path)
assert identity(delivery_path)["sha256"] == "bda6c7127e6b4a84db3256898668cb664d933836e6332275cd9dfaa624f51fba"
assert identity(inventory_path)["sha256"] == "a1e42612d6a89337144b00335da2fa690dc7f503b46532ff795f0c92198bdd9c"
assert delivery["source_commit"] == inventory["source_commit"] == SOURCE
assert delivery["source_tree"] == inventory["source_tree"] == TREE
assert delivery["file_count"] == len(delivery["files"]) == 131
verified_files, empty_files = [], []
for row in delivery["files"]:
    path = Path(row["path"])
    assert path.is_relative_to(ROOT)
    actual = identity(path)
    assert actual["bytes"] == row["bytes"] and actual["sha256"] == row["sha256"], str(path)
    verified_files.append(actual)
    if actual["bytes"] == 0:
        empty_files.append(actual["path"])
assert len({row["path"] for row in verified_files}) == 131
assert sum(row["bytes"] for row in verified_files) == delivery["total_bytes"] == 5522990
pipeline = load(EVIDENCE / "pipeline-status.json")
assert delivery["native_status"] == pipeline["status"] == "passed-one-source-desktop-gates-only"
assert inventory["status"] == "PASSED_ONE_SOURCE_DESKTOP_GATES_ONLY"
assert delivery["job_id"] == inventory["job_id"] == "1a1ade2970f-fc05-5b5c"
assert inventory["terminal_unix_ms"] == 1793919910435
assert delivery["unexecuted"] == inventory["unexecuted"] == []
assert inventory["partial_artifacts"] == []
assert inventory["full_library_ignored"] == ["authbus_outbox_tests::crash_delivery_child"]
assert inventory["source_before_after_equal"] and inventory["configuration_unchanged"]

expected_refs = {}
all_primary, all_live = [], []
relationships, primary_poll_misses = [], []
for gate, entry in pipeline["gates"].items():
    if entry["actual_binary_evidence"] is None:
        continue
    fd_file = gate + ".fd-executed-binaries.json"
    live_file = gate + ".live-polled-binaries.json"
    fd, live = load(EVIDENCE / fd_file), load(EVIDENCE / live_file)
    assert fd == entry["actual_binary_evidence"]
    assert fd["errors"] == live["errors"] == []
    assert fd["live_polling_corroboration"]["sha256"] == identity(EVIDENCE / live_file)["sha256"]
    assert fd["live_polling_corroboration"]["captured_processes"] == len(live["records"])
    fd_ids = {process_key(row): row for row in fd["records"]}
    live_ids = {process_key(row): row for row in live["records"]}
    assert len(fd_ids) == len(fd["records"]) and len(live_ids) == len(live["records"])
    direct = []
    auxiliaries = []
    for index, row in enumerate(fd["records"]):
        expected_refs[(fd_file, index)] = ("pre-exec-fd", gate, row)
        all_primary.append(row)
    for index, row in enumerate(live["records"]):
        expected_refs[(live_file, index)] = ("live-poll", gate, row)
        all_live.append(row)
        child, parent = row["process_before"], row["direct_parent_before"]
        assert child == row["process_after"] and parent == row["direct_parent_after"]
        assert process_key(child) == process_key(row) and child["ppid"] == parent["pid"]
        assert child["argv"] == row["argv"] and child["actual_executable"] == row["actual_executable"]
        assert child["image"] == image(row)
        assert row["wrapper_descendant_verified"] and row["post_open_task_and_exe_verified"]
        assert row["held_child_and_parent_images_stable_through_retention"]
        assert 0 < row["relationship_observed_before_unix"] <= row["relationship_observed_after_unix"] <= row["captured_unix"]
        chain = row["ancestor_chain_before"]
        assert chain == row["ancestor_chain_after"] and 2 <= len(chain) <= 64
        assert len({node["pid"] for node in chain}) == len(chain)
        assert all(left["ppid"] == right["pid"] for left, right in zip(chain, chain[1:]))
        assert chain[0] == {k: child[k] for k in ("pid", "ppid", "start_ticks")}
        assert chain[1] == {k: parent[k] for k in ("pid", "ppid", "start_ticks")}
        assert (chain[-1]["pid"], chain[-1]["start_ticks"]) == (row["wrapper_pid"], row["wrapper_start_ticks"])
        if process_key(row) in fd_ids:
            outer = fd_ids[process_key(row)]
            assert row["argv"] == outer["argv"] and row["observed_selected_tests"] == [outer["exact_test"]]
            direct.append({"pid": row["pid"], "start_ticks": row["start_ticks"], "exact_test": outer["exact_test"]})
        else:
            assert gate == "final-use-profile-controls" and row["observed_selected_tests"] == [KILLED]
            outer = fd_ids[process_key(parent)]
            assert outer["exact_test"] == KILLED and parent["image"] == image(outer)
            assert parent["actual_executable"] == outer["actual_executable"]
            assert child["argv"] == parent["argv"] == outer["argv"] == [outer["actual_executable"], "--exact", KILLED, "--nocapture"]
            auxiliary = fd["live_process_correspondence"]["auxiliary_processes"]
            assert len(auxiliary) == 1
            assert process_key(auxiliary[0]) == process_key(row)
            assert (auxiliary[0]["parent_pid"], auxiliary[0]["parent_start_ticks"]) == process_key(parent)
            assert auxiliary[0]["test_outcome_credit"] is False
            auxiliaries.append(auxiliary[0])
            relationships.append({"gate": gate, "artifact": live_file, "record_index": index, "relationship": auxiliary[0]})
        assert row["source"] == outer["source"] and row["sha256"] == outer["sha256"]
        assert row["actual_executable"] == outer["actual_executable"] and image(row) == image(outer)
    assert fd["live_process_correspondence"]["errors"] == []
    assert fd["live_process_correspondence"]["direct_fd_matches"] == direct
    assert fd["live_process_correspondence"]["auxiliary_processes"] == auxiliaries
    primary_poll_misses.extend({"gate": gate, "pid": row["pid"], "start_ticks": row["start_ticks"], "case": row["exact_test"]}
                               for key, row in fd_ids.items() if key not in live_ids)
assert len(all_primary) == inventory["actual_fd_records"] == delivery["actual_fd_records"] == 301
assert len(all_live) == inventory["actual_live_records"] == delivery["actual_live_records"] == 294
assert inventory["auxiliary_live_observations"] == relationships and len(relationships) == 1
assert len(primary_poll_misses) == 8

images = inventory["images"]
assert len(images) == len({row["sha256"] for row in images}) == 11
used_refs, daemon_roles, alias_images, kinds = set(), set(), {}, Counter()
observations = 0
for row in images:
    aliases, actual_paths = set(), set()
    kinds[row["kind"]] += 1
    for observation in row["observations"]:
        observations += 1
        artifact = EVIDENCE / observation["evidence_file"]
        assert artifact.is_relative_to(EVIDENCE)
        assert identity(artifact)["sha256"] == observation["evidence_sha256"]
        assert observation["source_commit"] == SOURCE and observation["source_tree"] == TREE
        if row["kind"] == "test-image":
            key = observation["evidence_file"], observation["evidence_record_index"]
            assert key not in used_refs and key in expected_refs
            method, gate, actual = expected_refs[key]
            used_refs.add(key)
            assert observation["method"] == method and observation["gate"] == gate
            for field in ("pid", "start_ticks", "device", "inode", "retained_copy"):
                assert observation[field] == actual[field]
            assert observation["selected"] == actual["observed_selected_tests"]
            assert observation["native_test_receipt_status"] == pipeline["gates"][gate]["status"] == "passed"
            assert observation["external_binding_gate_passed"] is True
            assert observation["test_outcome_credit"] is (method == "pre-exec-fd")
        else:
            assert row["kind"] == "ordinary-daemon"
            role = observation["generation_role"]
            assert role in ("first", "second") and role not in daemon_roles
            daemon_roles.add(role)
            actual = load(artifact)[role + "_process"]
            for field in ("pid", "start_ticks", "device", "inode", "retained_copy", "spawn_generation",
                          "origin_capture_pid", "origin_capture_start_ticks", "full_hash_and_copy_this_capture", "same_held_file_object_verified", "scope"):
                assert observation[field] == actual[field]
            assert observation["method"] == actual["capture_method"] and observation["gate"] == "effect-pq-product"
            assert observation["test_outcome_credit"] is False
        assert row["sha256"] == actual["sha256"] and row["bytes"] == actual["bytes"]
        assert actual["source"]["commit"] == SOURCE and actual["source"]["tree"] == TREE
        aliases.add(actual["retained_copy"])
        actual_paths.add(actual["actual_executable"])
    assert len(row["retained_aliases"]) == len(set(row["retained_aliases"]))
    assert set(row["retained_aliases"]) == aliases and set(row["actual_paths"]) == actual_paths
    for alias in aliases:
        assert "/joint-h4-native-attempt-1/" in alias and alias not in alias_images
        alias_images[alias] = row["sha256"]
assert used_refs == set(expected_refs) and daemon_roles == {"first", "second"}
assert observations == 597 and kinds == {"test-image": 10, "ordinary-daemon": 1}
assert len(alias_images) == inventory["complete_retained_alias_count"] == 32
assert sum(row["bytes"] for row in images) == inventory["complete_image_unique_bytes"] == 1674575368

h3_index_path = ROOT / "w1/h3-elf-export/H3-actual-export-index.json"
h3_index = load(h3_index_path)
assert identity(h3_index_path)["sha256"] == "b023aca6ab2dccf4324dccab2e5319a00ef9b32773e0dc73127efc9af3caa002"
parent_images = {row["sha256"]: row for row in h3_index["files"]}
overlap = [row["sha256"] for row in images if row["sha256"] in parent_images and parent_images[row["sha256"]]["bytes"] == row["bytes"]]
assert len(overlap) == 11
report = {
    "schema": "H4-independent-delivery-and-actual-image-inventory-review-v1",
    "status": "ALL_DECLARED_LOCAL_BYTES_AND_ALL_ORIGINAL_INVENTORY_REFERENCES_MATCH",
    "source_commit": SOURCE, "source_tree": TREE, "job_id": inventory["job_id"],
    "delivery": identity(delivery_path), "actual_inventory": identity(inventory_path),
    "declared_files_actually_read": 131, "declared_bytes_actually_read": 5522990,
    "empty_files_actually_read": empty_files, "file_catalog": verified_files,
    "primary_fd_records": 301, "live_records": 294, "direct_live_to_primary_matches": 293,
    "recognized_auxiliary_helpers": relationships, "primary_not_seen_by_polling": primary_poll_misses,
    "daemon_generations": 2, "first_daemon_full_copy": 1, "second_daemon_explicit_held_object_reuse": 1,
    "total_original_observation_references": 597, "all_record_pointers_used_once": True,
    "unique_complete_images": 11, "complete_image_kind_counts": dict(kinds),
    "unique_recorded_image_bytes": 1674575368, "original_retained_aliases": 32,
    "partial_artifacts": [], "partial_scope": inventory["partial_artifact_scope"],
    "prospective_h3_overlap": {"matched_recorded_complete_hash_and_size_pairs": 11, "parent_index": identity(h3_index_path),
        "scope": "Metadata equality only. Neither actual H4 retained files nor the parent archive was opened by this inventory audit. A later actual export must still perform both H4 full reads and complete fixed-parent verification before referencing any bytes."},
    "collection_errors_preserved": delivery["collection_errors_preserved"],
    "scope": "Independent local verification of the complete owner delivery and every original FD/live/daemon record reference; all 294 contemporaneous live observations were reconciled. No native rerun, desktop access, remote bulk, actual retained ELF reread or final binary archive closure.",
    "native_reruns": 0, "desktop_actions": 0, "remote_reads": 0,
    "h3_failure_unchanged": True, "joint_release_qualification": False
}
path = OUT / "delivery-inventory-review.json"
path.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"report": identity(path), "files": 131, "observations": observations,
                  "primary": 301, "live": 294, "direct_live": 293, "helpers": 1,
                  "images": 11, "aliases": 32, "parent_metadata_overlap": len(overlap)}))
