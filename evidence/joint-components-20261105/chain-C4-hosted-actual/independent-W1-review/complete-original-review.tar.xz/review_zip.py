"""Read existing hosted artifacts and exact source; never execute native or CI."""
from collections import Counter
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import shutil
import stat
import zipfile

W = Path('/workspace/scratch/93bfcfe29fc8')
R = Path(__file__).resolve().parent
INPUT = W / 'final-hosted-status'
COMMIT = '8df4b21d893906570d48f5beafabb3b31e0aefbc'
TREE = '6f5aaa2af0432e27e24b6bd2ad18013ab4423d14'
ZIP_NAME = 'C4-W1-fresh-service-head-original.zip'
ZIP_SHA = 'd1a8cf22fe723486d932a88c8401e3bbcc04c62ba5fc634732b012d763dcfa18'
ARTIFACT = 13462092257
RUN = 42076755695
JOB = 127418899990
WINDOW = 4_000_000_000
LIMITS = {'cpu.max': '25000 100000', 'cpu.max.burst': '0',
          'memory.max': '2147483648', 'memory.swap.max': '0', 'pids.max': '256'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def desc(p):
    raw = p.read_bytes()
    return {'path': str(p.relative_to(W)), 'bytes': len(raw), 'sha256': sha(raw)}


def load(p):
    return json.loads(p.read_bytes())


def unwrap(j):
    while isinstance(j, dict) and 'structuredContent' in j:
        j = j['structuredContent']
    if isinstance(j, dict) and isinstance(j.get('content'), str):
        return json.loads(j['content'])
    return j


def save_json(name, value):
    p = R / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


archive_raw = (INPUT / ZIP_NAME).read_bytes()
assert len(archive_raw) == 5_641_053 and sha(archive_raw) == ZIP_SHA
artifact = next(x for x in unwrap(load(INPUT / 'C4-W1-artifacts.raw.json'))['artifacts']
                if x['id'] == ARTIFACT)
assert artifact['size_in_bytes'] == len(archive_raw) and artifact['digest'] == 'sha256:' + ZIP_SHA
assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == COMMIT
job = next(x for x in unwrap(load(INPUT / 'C4-W1-jobs.raw.json'))['jobs'] if x['id'] == JOB)
assert job['run_id'] == RUN and job['head_sha'] == COMMIT and job['run_attempt'] == 1
assert job['name'] == 'W1 fresh challenge service (x64, head)'
assert job['status'] == 'completed' and job['conclusion'] == 'failure'
assert next(x for x in job['steps'] if x['number'] == 6)['conclusion'] == 'failure'
assert all(next(x for x in job['steps'] if x['number'] == n)['conclusion'] == 'success' for n in [3,5,7,8])

members = {}
member_rows = []
with zipfile.ZipFile(INPUT / ZIP_NAME) as z:
    for info in z.infolist():
        path = PurePosixPath(info.filename)
        assert not path.is_absolute() and '..' not in path.parts and str(path) == info.filename
        assert not info.is_dir() and not stat.S_ISLNK(info.external_attr >> 16)
        assert info.filename not in members
        raw = z.read(info)  # zipfile verifies the stored CRC while fully reading.
        assert len(raw) == info.file_size
        members[info.filename] = raw
        member_rows.append({'path': info.filename, 'bytes': len(raw), 'sha256': sha(raw),
                            'compressed_bytes': info.compress_size, 'crc32': f'{info.CRC:08x}'})
assert len(members) == 57 and sum(map(len, members.values())) == 34_539_170
assert sum(not raw for raw in members.values()) == 15
old_index = load(INPUT / 'C4-W1-head-zip-index.json')
assert old_index['artifact_id'] == ARTIFACT and old_index['sha256'] == ZIP_SHA
assert {(x['path'], x['bytes'], x['compressed_bytes']) for x in old_index['members']} == {
    (x['path'], x['bytes'], x['compressed_bytes']) for x in member_rows}

J = lambda name: json.loads(members[name])
manifest = J('fresh-service/manifest.json')
assert manifest['schema'] == 'trnm-w1-fresh-service-execution-v1'
assert manifest['source_before'] == manifest['source_after']
assert manifest['source_expected'] == manifest['source_before']['commit'] == COMMIT
assert manifest['source_before']['tree'] == TREE
source = J('source.json')
assert members['source.json'] == members['source-after.json']
assert source == manifest['source_before']['tracked_source_identity']
assert source['tested_commit'] == source['candidate'] == COMMIT and source['tested_tree'] == TREE
assert source['kind'] == 'head' and source['tracked_worktree_verified'] is True
assert source['tracked_entries'] == 10357 and source['tracked_bytes'] == 985270534
assert source['tests_executed_by_identity_check'] is False
assert manifest['source_recompiled'] is True and manifest['execution_finished'] is True
assert manifest['passed'] is False and manifest['all_named_tests_passed'] is False
assert manifest['requested_window_ns'] == WINDOW and manifest['attack_workers'] == 16
service_members = {n.removeprefix('fresh-service/') for n in members if n.startswith('fresh-service/')}
assert set(manifest['files']) == service_members - {'manifest.json'}
for name, expected_sha in manifest['files'].items():
    assert sha(members['fresh-service/' + name]) == expected_sha
binary_sha = sha(members['fresh-service/public_v3_from_zero'])
assert binary_sha == manifest['binary_sha256_before'] == manifest['binary_sha256_after']
assert binary_sha == 'ab7cf9ead693a8d1da8cb737960ff8c360be96d6be6f5e4c4e401e05e92db9a1'
assert members['fresh-service/public_v3_from_zero'][:4] == b'\x7fELF'

controller = J('fresh-service-host/controller-result.json')
child = J('fresh-service-host/child-result.json')
before = J('fresh-service-host/inside-before.json')
after = J('fresh-service-host/inside-after.json')
assert controller['passed'] is False and controller['systemd_run_exit'] == child['native_child_exit'] == 1
assert controller['failure'] is None and controller['final_host_errors'] == child['host_errors'] == []
assert controller['command_argv'] == child['command_argv']
assert controller['command_argv'][:3] == ['python3','scripts/ci/run_w1_fresh_service_v1.py','--out']
assert controller['parent_lease'] == controller['final_parent_lease']
lease = controller['parent_lease']
assert lease['seal_sha256'] == lease['seal_file']['sha256'] == sha(members['public-fixture-parent.json'])
assert before['parent'] == after['parent'] == lease['parent_identity']['parent']
assert before['limits'] == after['limits'] == lease['parent_identity']['limits'] == LIMITS
assert before['boot_id'] == after['boot_id'] == lease['parent_identity']['boot_id']
assert before['installed_unit_sha256'] == after['installed_unit_sha256'] == lease['parent_identity']['installed_unit_sha256']
for sample in [before,after]:
    assert sample['read_errors'] == {} and sample['uid'] == sample['gid'] == 1001
    assert sample['parent']['uid'] == sample['parent']['gid'] == 0
    assert sample['parent']['symlink'] is False and sample['parent']['directory'] is True
    assert sample['thread_privileges'] == {'CapBnd':'0000000000000000','NoNewPrivs':'1'}
    assert sample['service'] == controller['service']
    assert sample['thread_cgroup'] == '0::/trnmponpublic.slice/' + controller['service']
prep = controller['preparation']
assert prep['source_before'] == prep['source_after'] == manifest['source_before']
assert prep['binary_sha256'] == binary_sha and prep['completed'] is True
assert prep['native_tests_executed'] is False and prep['service_resource_observation'] is False
assert prep['process']['exit_code'] == manifest['build']['exit_code'] == 0
assert prep['process']['timed_out'] is False and manifest['build']['timed_out'] is False
assert prep['process']['command'] == manifest['build']['command']
assert '--locked' in prep['process']['command'] and '--release' in prep['process']['command']
assert prep['process']['stdout_sha256'] == sha(members['fresh-service-host/prepare-build/stdout'])
assert prep['process']['stderr_sha256'] == sha(members['fresh-service-host/prepare-build/stderr'])

tree = unwrap(load(R / 'C4-tree.raw.json'))
assert tree['sha'] == TREE and tree['truncated'] is False and len(tree['tree']) == 11538
blobs = {x['path']:x for x in tree['tree'] if x['type'] == 'blob'}
assert len(blobs) == 10357
source_paths = {
    'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero.rs': W / 'w1/public-gate',
    'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero/fresh_challenge.rs': W / 'w1/public-gate',
    'scripts/ci/run_from_zero_native.py': W / 'w1/public-gate',
    'scripts/ci/run_from_zero_host.py': W / 'w1/public-gate',
    'scripts/ci/public_fixture_host_lease.py': W / 'w1/public-gate',
    'scripts/ci/public_host_ci_observation.py': W / 'w1/public-gate',
    '.github/workflows/pon-w1-work-security.yml': W / 'pq_recovery/w1-independent-c4/source',
    'scripts/ci/verify_ci_source.py': W / 'pq_recovery/w1-independent-c4/source'}
sources = []
for path, root in source_paths.items():
    p = root / path
    raw = p.read_bytes()
    assert (blob(raw),len(raw)) == (blobs[path]['sha'],blobs[path]['size'])
    dest = R / 'source' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
    sources.append({'repository_path':path,'git_blob':blob(raw),**desc(dest)})
assert sha((R/'source/trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero.rs').read_bytes()) == manifest['source_before']['test_sha256']
fresh_runner_path = 'scripts/ci/run_w1_fresh_service_v1.py'
fresh_runner_scope = {'path':fresh_runner_path,'git_blob':blobs[fresh_runner_path]['sha'],
                      'bytes':blobs[fresh_runner_path]['size'],'body_locally_available':False,
                      'scope':'Its exact C4 Git blob is bound by the complete immutable tree; this review does not claim an independent body audit of this unavailable local runner. Actual process logs, complete reports, manifest and host binder source are independently checked.'}


def review_phase(p):
    assert p['requested_window_ns'] == WINDOW and p['workers'] in [0,16]
    calls = [row for worker in p['attacks'] for row in worker['calls']]
    assert len(p['attacks']) == p['workers']
    if p['workers']:
        assert {w['worker'] for w in p['attacks']} == set(range(16))
    cpu = sum(w['calling_thread_cpu_ns'] for w in p['attacks'])
    assert cpu == p['attacker_workers_cpu_ns']
    no_accept = all(r['status'] != 'ok' for r in calls)
    assert no_accept == p['no_attack_accepted'] is True
    records = p['observations']
    assert records['records_not_retained'] == records['measurement_failures'] == 0
    assert records['counter_overflow'] is False
    assert len(records['records']) == records['accepted_connections_seen']
    m = p['service']['metrics']
    accounting = (m['mutation_full_work_cpu_ns'] + m['mutation_dispatch_excluding_work_cpu_ns'] == m['mutation_cpu_charged_ns']
                  and m['work_started'] == m['work_finished'] and m['mutation_cpu_clock_failures'] == 0)
    assert accounting == p['accounting_closed'] is True and p['service']['error'] is None
    heads = p['honest_heads']
    read_success = sum(r['status'] == 'ok' and r['returned_after_deadline'] is False
                       and r['returned_after_window'] is False for r in heads)
    assert read_success == p['honest_head_successes_in_window']
    prior = maximum = 0
    for row in heads:
        if row['status'] == 'ok' and row['returned_after_window'] is False:
            maximum = max(maximum, row['ended_ns'] - prior)
            prior = row['ended_ns']
    maximum = max(maximum, WINDOW-min(prior,WINDOW))
    assert maximum == p['maximum_honest_head_gap_ns']
    obs = p['independent_client_confirmation']
    confirmed = bool(obs and obs['confirmed'] is True and obs['finalized'] is False
                     and obs['execution_authority'] is False and obs['depth'] == 6
                     and p['confirmation_ended_ns'] < WINDOW)
    assert confirmed == p['client_confirmed_before_original_window_end']
    assert int(confirmed) == p['client_confirmed_transactions']
    overlap_count = (sum(r['started_ns'] < p['confirmation_ended_ns'] and r['ended_ns'] > p['business_started_ns']
                         for r in calls) if p['confirmation_ended_ns'] is not None else 0)
    assert overlap_count == p['overlapping_false_calls']
    overlap = p['workers'] == 0 or (p['completed_false_calls_before_business'] > 0 and overlap_count > 0
                                   and p['completed_false_calls_at_confirmation'] > p['completed_false_calls_before_business'])
    assert overlap == p['overlap_demonstrated']
    finite = confirmed and overlap and not p['verification_errors']
    assert finite == p['finite_business_target_met']
    replay = p['independent_history_page_replay']
    for row in replay:
        assert row['replay_ended_ns'] - row['replay_started_ns'] == row['replay_wall_ns']
        assert row['history_request_ended_ns'] <= row['replay_started_ns']
        assert p['honest_history'][row['history_call_index']]['ended_ns'] == row['history_request_ended_ns']
    assert [r['replay_error'] for r in replay if not r['replay_accepted']] == p['verification_errors']
    return {'mode':p['mode'],'requested_window_ns':WINDOW,'workers':p['workers'],
            'finite_business_target_recomputed':finite,'reported_invariant_target_met':p['invariant_target_met'],
            'honest_submission_statuses':dict(Counter(r['status'] for r in p['honest_submissions'])),
            'honest_head_successes_recomputed':read_success,'maximum_head_gap_ns_recomputed':maximum,
            'history_calls':len(p['honest_history']),'successful_history_replays':sum(r['replay_accepted'] for r in replay),
            'history_replays':[{k:v for k,v in r.items() if k!='native_import_observation'} for r in replay],
            'client_confirmation':obs,'confirmation_latency_ns':p['client_confirmation_latency_ns'],
            'client_confirmed_transactions':p['client_confirmed_transactions'],
            'verification_errors':p['verification_errors'],'attack_calls':len(calls),
            'attack_statuses':dict(Counter(r['status'] for r in calls)),
            'attack_response_errors':dict(Counter((r.get('response') or {}).get('value',{}).get('error')
                                                  for r in calls if r['status']=='refused')),
            'attack_client_errors':dict(Counter(r.get('error') for r in calls if r['status']=='error')),
            'no_attack_accepted_recomputed':no_accept,'worker_cpu_ns_recomputed':cpu,
            'complete_retained_request_observations':len(records['records']),
            'receiver_accounting_arithmetic_recomputed':accounting,
            'receiver_work_started_finished':m['work_started'],'receiver_work_failed':m['work_failed'],
            'receiver_mutation_cpu_ns':m['mutation_cpu_charged_ns'],
            'receiver_full_work_cpu_ns':m['mutation_full_work_cpu_ns'],
            'receiver_dispatch_excluding_work_cpu_ns':m['mutation_dispatch_excluding_work_cpu_ns'],
            'independent_replay_cpu_ns':p['independent_replay_and_confirmation_cpu_ns'],
            'independent_replay_wall_ns':p['independent_replay_and_confirmation_wall_ns'],
            'overlap':{'reported':overlap,'definition_requires_confirmation':True,
                       'no_confirmation_does_not_mean_no_attack_traffic':True}}


reports = {name:J(f'fresh-service/{name}/report.json') for name in ['original','fresh']}
assert reports['original']['signed_honest_packets'] == reports['fresh']['signed_honest_packets']
assert len(reports['original']['signed_honest_packets']) == 7
for key in ['network','parameters','genesis','target','task','policy_id']:
    assert reports['original'][key] == reports['fresh'][key]
cases = []
for index, name in enumerate(['original','fresh']):
    report = reports[name]
    run = manifest['runs'][index]
    process = run['process']
    log = members[f'fresh-service/{name}.log'].decode()
    assert process['executed'] is True and process['timed_out'] is False and process['source_verified'] is True
    assert process['expected_source'] == COMMIT and process['command'][0] == prep['binary_path']
    assert process['command'][1] == run['name']
    assert process['command'][2:] == ['--exact','--nocapture','--test-threads=1'] + (['--ignored'] if name=='fresh' else [])
    assert run['log_sha256'] == sha(log.encode()) and run['report_path'] == name + '/report.json'
    assert run['passed'] is False and report['finite_target_met'] is False
    phases = [review_phase(p) for p in report['phases']]
    assert phases[0]['finite_business_target_recomputed'] is True
    assert phases[1]['finite_business_target_recomputed'] is False
    assert all(p['reported_invariant_target_met'] is True for p in phases)
    assert phases[1]['verification_errors'] == ['PUBLIC_REQUEST_DEADLINE']
    if name == 'original':
        assert process['exit_code'] == process['process_exit_code'] == 0
        assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in log
        assert run['failure'] == 'CONFIRMATION_TARGET'
        constructions = report['from_zero_construction']
        assert len(constructions) == 16 and all(c['status']=='target_hit_unverified' for c in constructions)
        setup_cpu = report['attacker_construction_cpu_ns']
        total_cpu = setup_cpu + phases[1]['worker_cpu_ns_recomputed']
        construction = {'retained_input_count':16,'ticket_attempts':sum(len(c['attempts']) for c in constructions),
                        'setup_and_construction_cpu_ns':setup_cpu,'setup_and_construction_wall_ns':report['attacker_construction_wall_ns'],
                        'setup_plus_disjoint_workers_cpu_ns':total_cpu,
                        'scope':'Sixteen from-zero false statements constructed once and replayed. All losing search trials are retained. Construction is separate from traffic worker CPU.'}
    else:
        assert process['exit_code'] == process['process_exit_code'] == 101
        assert 'test result: FAILED. 0 passed; 1 failed; 0 ignored;' in log
        assert 'fresh challenges failed the original four-second/six-depth business target' in log
        assert run['failure'] == 'FRESH_NATIVE_PROCESS_REQUIRED'
        calls=[r for w in report['phases'][1]['attacks'] for r in w['calls']]
        cs=[r['from_zero_construction'] for r in calls]
        c=report['construction_coverage']
        assert len(cs)==c['constructed']==c['submitted']==294 and c['exhausted']==0
        assert len({x['challenge'] for x in cs})==c['unique_challenges']==294
        assert len({r['packet_index'] for r in calls})==c['unique_packet_indices']==294
        assert sum(x['attacker_cpu_ns'] for x in cs)==c['nested_from_zero_construction_cpu_ns']==90_091_781
        assert sum(r['status']=='refused' and (r.get('response') or {}).get('value',{}).get('error')=='WORK:Transcript' for r in calls)==c['full_transcript_rejections']==278
        total_cpu=report['shared_material_setup_cpu_ns']+phases[1]['worker_cpu_ns_recomputed']
        assert total_cpu==report['attacker_setup_and_workers_cpu_ns']==315_619_344
        construction={'fresh_constructed':294,'unique_challenge_strings':294,'unique_packet_indices':294,
                      'ticket_attempts':sum(len(x['attempts']) for x in cs),
                      'shared_setup_cpu_ns':report['shared_material_setup_cpu_ns'],
                      'shared_setup_wall_ns':report['shared_material_setup_wall_ns'],
                      'nested_construction_cpu_ns':c['nested_from_zero_construction_cpu_ns'],
                      'setup_plus_disjoint_workers_cpu_ns':total_cpu,
                      'nested_construction_added_again':False,
                      'scope':'Fresh per-call construction is nested in joined worker CPU. Shared public material setup is added once. This review independently counts stored challenge strings/indices and arithmetic; it does not reexecute cryptographic header validation.'}
    cases.append({'name':name,'selector':run['name'],'native_exit':process['exit_code'],
                  'native_wrapper_elapsed_ns':process['elapsed_ns'],'native_timed_out':False,
                  'business_gate_passed':False,'runner_failure_code':run['failure'],
                  'phases':phases,'construction':construction})

controls=[]
for n, count in [('original-host-controls.log',78),('original-native-controls.log',140),('fresh-service-controls.log',20)]:
    log=members[n].decode()
    match=re.search(r'Ran (\d+) tests in ([0-9.]+)s\n\nOK',log)
    assert match and int(match.group(1))==count
    controls.append({'path':n,'count':count,'seconds':float(match.group(2)),'sha256':sha(members[n]),
                     'scope':'Previously executed hosted Python refusal controls, not added native cases or a new local run.'})

review={
    'schema':'independent-C4-hosted-W1-fresh-service-review-v1',
    'status':'AUDIT_CONSISTENT_BUSINESS_GATES_FAILED',
    'source':{'commit':COMMIT,'tree':TREE,'kind':'head','tracked_source_receipts_before_after_equal':True,
              'tracked_entries':10357,'tracked_bytes':985270534,
              'exact_local_source_files':sources,'fresh_runner_body_scope':fresh_runner_scope,
              'source_guard_boundary':'Actual hosted guards claim a full tracked-byte verification; this independent cloud review rehashes the eight retained sources against the fresh complete immutable C4 tree and does not reread all 985 MB of the hosted worktree.'},
    'github':{'artifact':artifact,'job':job,'workflow_run_id':RUN,'source_not_prospective_merge':True},
    'archive':{'path':str((R/'inputs'/ZIP_NAME).relative_to(W)),'bytes':len(archive_raw),'sha256':ZIP_SHA,
               'regular_members':57,'uncompressed_bytes':34_539_170,'empty_members':15,
               'every_member_fully_read_and_crc_checked':True,'fresh_service_manifest_file_count':len(manifest['files'])},
    'binary':{'bytes':len(members['fresh-service/public_v3_from_zero']),'sha256':binary_sha,
              'compiled_path':prep['binary_path'],'before_after_retained_copy_equal':True,
              'actual_execution_evidence':'Exact command receipts and actual libtest logs. This artifact does not provide the separate held-FD/proc-image capture used in Hepta H4; no equivalent stronger attribution is inferred.'},
    'resources':{'limits':LIMITS,'parent_before_after_equal':before['parent'],
                  'boot_id':before['boot_id'],'inside_uid_gid':[1001,1001],
                  'actual_inside_observations':[before['observed_utc'],after['observed_utc']],
                  'host_read_errors':[],'child_host_errors':[],'final_host_errors':[],
                  'host_setup_was_not_the_failure':True,'workflow_job_timeout_minutes':55,
                  'native_per_phase_window_ns':WINDOW,'pressure_workers':16,
                  'preparation_build_outside_service_resource_observation':True,
                  'preparation_wall_ns':prep['process']['wall_ns'],
                  'preparation_cpu_ns':prep['process']['cpu_ns'],
                  'runtime_limits_not_raised':True},
    'native_build_command':manifest['build']['command'],'cases':cases,'original_hosted_python_controls':controls,
    'outcome_boundary':{'original_native_exit_zero_is_invariants_only':True,
                       'fresh_native_explicit_business_assertion_failed':True,
                       'host_child_and_controller_exit':1,
                       'original_business_failure':'CONFIRMATION_TARGET',
                       'fresh_runner_failure_literal':'FRESH_NATIVE_PROCESS_REQUIRED',
                       'fresh_failure_does_not_mean_unexecuted':True,
                       'both_pressure_cases_reached_real_history_replay_then_deadline':True,
                       'no_post_window_drain_credit':True,
                       'overlap_false_is_not_absence_of_attack':True,
                       'diagnosis_limit':'The retained local replay failure and deadline are observed. This audit does not identify a unique performance cause, prove a repair, or change any timeout/resource/acceptance condition.'},
    'clock_and_cost_scope':'Reported caller-thread CPU and wall nanoseconds retain their distinct scopes. Nested construction, Host, import and service intervals are not summed into whole-system CPU or energy. These two fixed public-service tests do not establish globally cheapest legal work or independently administered WAN performance.',
    'qualification':{'P0_public_service_liveness':'FAIL on this actual fixed C4 hosted observation; retain HOLD until repaired and requalified under original gates',
                     'no_attack_accepted_in_observed_calls':True,'independent_operator_or_WAN_qualified':False,
                     'production_activation':False,'native_or_learning_rerun_by_reviewer':False},
    'privacy_scope':'Inputs are a fixed allowlist. Temporary download-reference.private.raw.json responses were neither read nor copied into this delivery.',
    'local_diagnostic_history':'An exploratory summary first assumed every attack response was a dictionary and stopped on response=null after baseline output. The error is retained in local-diagnostic-failure.json. The final verifier explicitly preserves these failed attempts with null responses and counts them as errors, never drops them.',
    'actions':{'one_readonly_immutable_C4_tree_fetch':True,'native_runs':0,'production_reader_reruns':0,
               'desktop_calls':0,'source_mutations':0,'workflow_dispatch':0,'learning':0,'old_binary_read_state_changes':0}}

save_json('archive-members.json',member_rows)
save_json('review.json',review)
inputs=R/'inputs';inputs.mkdir(exist_ok=True)
for n in [ZIP_NAME,'C4-W1-artifacts.raw.json','C4-W1-jobs.raw.json','C4-W1-head-zip-index.json']:
    shutil.copyfile(INPUT/n,inputs/n)
for n in ['source.json','source-after.json','fresh-service/manifest.json','fresh-service/original.log',
          'fresh-service/fresh.log','fresh-service-host/controller-result.json',
          'fresh-service-host/child-result.json','fresh-service-host/inside-before.json',
          'fresh-service-host/inside-after.json','public-fixture-parent.json']:
    p=R/'selected-actual-members'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(members[n])
files=[desc(p) for p in sorted(R.rglob('*')) if p.is_file() and p.name!='delivery-manifest.json']
assert all('.private.' not in x['path'] for x in files)
save_json('delivery-manifest.json',{'schema':'independent-hosted-W1-review-delivery-v1',
    'review':desc(R/'review.json'),'file_count':len(files),'total_bytes':sum(x['bytes'] for x in files),
    'files':files,'qualification':'BUSINESS_GATES_FAILED; review consistency is not a native PASS'})
print(json.dumps({'status':review['status'],'review':desc(R/'review.json'),
                  'manifest':desc(R/'delivery-manifest.json'),'cases':[
                      {'name':c['name'],'native_exit':c['native_exit'],'business_gate_passed':False,
                       'attack_calls':c['phases'][1]['attack_calls']} for c in cases]}))
