#!/usr/bin/env python3
"""Publish only the explicitly reviewed small evidence set into the local repo."""
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DEST = ROOT / 'hepta-joint-evidence/evidence/joint-components-20261105/artifact-transport/unified-readback/independent-actual-review'
NAMES = [
    'REVIEW.md', 'verify_actual_transport.py', 'transport-review.json', 'verify_consumed_members.py',
    'verify_expected_h3_h4_only.py', 'expected-H3-H4-only-review.json', 'compare_five_extra_files.py',
    'five-extra-file-forensics.json', 'attempt1/verify_consumed_members.py', 'attempt1/returned-output-transcript.txt',
    'attempt1/followup-observation.json', 'attempt1/specific-stat-and-consumer-order.json', 'delivery-manifest.json',
    'build_forensic_public_map.py', 'forensic-public-content-map.json', 'FORENSIC-CONTENT-MAP.md',
    'package_independent_review.py',
]


def need(ok, why):
    if not ok:
        raise ValueError(why)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def write_new(path, raw):
    with path.open('xb') as stream:
        need(stream.write(raw) == len(raw), 'short package output')
        stream.flush()
        os.fsync(stream.fileno())


def main():
    payloads = {}
    for name in NAMES:
        path = HERE / name
        need(path.resolve(strict=True) == path and path.is_file() and not path.is_symlink(), 'noncanonical explicit source')
        before = path.stat()
        need(stat.S_ISREG(before.st_mode) and before.st_size < 1024 * 1024, 'small-file bound')
        raw = path.read_bytes()
        after = path.stat()
        need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
             (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'source changed while collecting')
        payloads[name] = raw
    need(sha(payloads['delivery-manifest.json']) == 'd0c70479c168e4d8fcf987c6f9c982eab3cf269d3ae713836c10dd313167aba8', 'initial frozen delivery changed')
    initial = json.loads(payloads['delivery-manifest.json'])
    for record in initial['files']:
        raw = payloads[record['path']]
        need(len(raw) == record['bytes'] and sha(raw) == record['sha256'], 'frozen first delivery member changed')
    need(sha(payloads['forensic-public-content-map.json']) == '29085e863d6c4b7a9a9ac84ec411c5e2bc3fa2642c12b66d42a084143d82b97c', 'frozen public content map changed')
    manifest = dict(schema='independent-actual-review-small-whitelist-delivery-v1', status='HOLD_UNKNOWN_OUTPUT_PROVENANCE',
                    created_utc=datetime.now(timezone.utc).isoformat(),
                    original_manifest=dict(path='delivery-manifest.json', bytes=len(payloads['delivery-manifest.json']), sha256=sha(payloads['delivery-manifest.json'])),
                    files=[dict(path=name, source_path=str((HERE / name).relative_to(ROOT)), bytes=len(raw), sha256=sha(raw)) for name, raw in payloads.items()],
                    explicit_small_file_count=len(payloads), source_bytes=sum(len(raw) for raw in payloads.values()),
                    original_unknown_files_retained_in_place=5, unknown_original_bytes=1562327640,
                    extra_file_content_mapping='forensic-public-content-map.json', extra_file_provenance_known=False,
                    original_strict_failure_preserved=True, includes_large_binary_or_extra_file_payloads=False,
                    new_Git_write_or_network_call=False, new_native_or_consumer_execution=False)
    manifest_raw = encoded(manifest)
    manifest_name = 'delivery-with-public-map.json'
    write_new(HERE / manifest_name, manifest_raw)
    payloads[manifest_name] = manifest_raw
    need(not DEST.exists(), 'fresh explicitly assigned local evidence directory required')
    DEST.mkdir(parents=True)
    package = DEST / 'independent-actual-review.tar.xz'
    with package.open('xb') as destination:
        with tarfile.open(fileobj=destination, mode='w:xz', preset=6) as archive:
            for name, raw in payloads.items():
                info = tarfile.TarInfo(name)
                info.size = len(raw)
                info.mode = 0o600
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                archive.addfile(info, io.BytesIO(raw))
        destination.flush()
        os.fsync(destination.fileno())
    actual_members = {}
    with tarfile.open(package, mode='r:xz') as archive:
        for info in archive:
            name = PurePosixPath(info.name)
            need(info.isfile() and not name.is_absolute() and '..' not in name.parts and name.as_posix() == info.name and
                 info.name not in actual_members and info.name in payloads and info.size < 1024 * 1024, 'package member allowlist')
            with archive.extractfile(info) as stream:
                raw = stream.read(1024 * 1024 + 1)
            need(raw == payloads[info.name] and len(raw) == info.size, 'lossless member readback')
            actual_members[info.name] = dict(bytes=len(raw), sha256=sha(raw))
    need(set(actual_members) == set(payloads), 'exact package set')
    write_new(DEST / 'delivery-with-public-map.json', manifest_raw)
    write_new(DEST / 'forensic-public-content-map.json', payloads['forensic-public-content-map.json'])
    archive_raw = package.read_bytes()
    verification = dict(schema='independent-actual-review-lossless-small-package-v1', status='HOLD_UNKNOWN_OUTPUT_PROVENANCE',
                        package=dict(path=str(package.relative_to(ROOT)), bytes=len(archive_raw), sha256=sha(archive_raw)),
                        source_manifest=dict(path=str((HERE / manifest_name).relative_to(ROOT)), bytes=len(manifest_raw), sha256=sha(manifest_raw)),
                        public_manifest_copy=dict(path=str((DEST / manifest_name).relative_to(ROOT)), byte_equal_to_source=True),
                        public_forensic_mapping_copy=dict(path=str((DEST / 'forensic-public-content-map.json').relative_to(ROOT)),
                            bytes=len(payloads['forensic-public-content-map.json']), sha256=sha(payloads['forensic-public-content-map.json']), byte_equal_to_source=True),
                        members=actual_members, exact_member_count=len(actual_members), all_members_reopened_and_byte_compared=True,
                        original_unknown_files_copied=False, original_unknown_files_deleted_or_modified=False,
                        original_strict_failure_preserved=True, source_or_native_qualification_awarded=False,
                        Git_publication_performed=False, note='Local evidence-repository placement only. Root owns the final Git publication and README.')
    verification_raw = encoded(verification)
    write_new(DEST / 'pack-verification.json', verification_raw)
    write_new(HERE / 'pack-verification.json', verification_raw)
    directory_fd = os.open(DEST, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)
    print(json.dumps(dict(package=verification['package'], source_manifest=verification['source_manifest'],
                          pack_verification_bytes=len(verification_raw), pack_verification_sha256=sha(verification_raw),
                          exact_members=len(actual_members), status=verification['status'])))


if __name__ == '__main__':
    main()
