#!/usr/bin/env python3
"""Narrow read of declared H3/H4 bytes; unexpected output provenance stays HOLD."""
from __future__ import annotations

import base64
from datetime import datetime, timezone
import io
import json
import os
from pathlib import Path, PurePosixPath
import tarfile
import time

from verify_actual_transport import ROOT, OUT, digest, identity, need, paused_state, read
from verify_consumed_members import CONSUMER_SHA, PINS, OUTPUT, RUN, full_hash


def extras(directory, expected):
    actual = {str(path.relative_to(directory)) for path in directory.rglob('*') if path.is_file() or path.is_symlink()}
    missing = sorted(set(expected) - actual)
    result = {}
    for name in sorted(actual - set(expected)):
        info = (directory / name).lstat()
        result[name] = dict(bytes=info.st_size, device=info.st_dev, inode=info.st_ino,
                            mode=info.st_mode, mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns)
    return dict(unexpected=result, missing=missing, observed_count=len(actual))


def main():
    start = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    paused_before = paused_state()
    directory = OUTPUT / 'H3'
    extracted = directory / 'extracted'
    actual_phase_raw = read(directory / 'readback-verification.json')
    actual_phase = json.loads(actual_phase_raw)
    completion_raw = read(directory / 'H3-export-completion.json', '93d7bf08914054e4bcf05f17eea3cd5ef36fac9bbf0d1e601dda59084e758cd3')
    completion = json.loads(completion_raw)
    index_raw = read(extracted / 'export-index.json', 'b023aca6ab2dccf4324dccab2e5319a00ef9b32773e0dc73127efc9af3caa002')
    index = json.loads(index_raw)
    expected = dict(index['embedded_metadata_files'])
    expected.update({row['name']: {key: row[key] for key in ('bytes', 'sha256')} for row in index['files']})
    expected['export-index.json'] = dict(bytes=len(index_raw), sha256=digest(index_raw))
    need(len(expected) == 16 and expected == actual_phase['members'], 'declared H3 member identities differ')
    extra_before = extras(extracted, expected)
    need(extra_before['missing'] == [], 'declared H3 member missing')
    # No exact-directory assertion is removed from the strict original checker.
    # This separately named diagnostic deliberately retains every extra as HOLD.
    physical = {}
    for name, record in expected.items():
        physical[name] = full_hash(extracted / name, record['bytes'], record['sha256'])
        need('/elf/' not in name or physical[name]['elf_magic'], 'declared complete H3 image has no ELF header')
    need(len(index['files']) == 11 and sum(row['bytes'] for row in index['files']) == 1674575368, 'exact declared H3 image count/bytes')
    h3plan_raw = read(extracted / 'export-plan.json', completion['plan_sha256'])
    h3plan = json.loads(h3plan_raw)
    h3map_raw = read(extracted / 'H3/original-source-map.json', h3plan['source_map']['sha256'])
    need(h3map_raw == base64.b64decode(h3plan['source_map']['data_base64'], validate=True), 'original H3 observation map bytes')
    planned_h3 = {row['name']: row for row in h3plan['files']}
    for row in index['files']:
        need(all(row.get(k) == v for k, v in planned_h3[row['name']].items()), 'original H3 aliases/observations altered')
    need(actual_phase['scope']['original_native_outcome'] == 'FAILED' and
         actual_phase['scope']['capture_gaps_filled'] is False and
         actual_phase['scope']['second_process_full_hash_or_copy_inferred'] is False and
         len(actual_phase['scope']['unmatched_live_observations']) == 1, 'H3 failure/capture boundaries altered')
    print(json.dumps(dict(narrow_scope='declared-H3-members-only', verified=16, unexpected_directory_entries=len(extra_before['unexpected']),
                          overall='HOLD_UNKNOWN_OUTPUT_PROVENANCE')), flush=True)
    h4dir = ROOT / 'w1/h4-reference-export'
    h4completion_raw = read(h4dir / 'H4-export-completion.json', 'd3bda29c2ff27a18895e04ca672109298ca78bc9a9fd290d28a5d3db62930018')
    h4completion = json.loads(h4completion_raw)
    child_path = h4dir / 'H4-actual-retained-image-references.tar.xz'
    child_raw = read(child_path, '47d3c5efa6b9aa4b2f97ef06a606f2931d8065f068311303f8d079c18a7bbaa5')
    need(len(child_raw) == 100964 == h4completion['archive_bytes'] and h4completion['standalone_archive'] is False, 'actual H4 child size/dependency')
    child_members = {}
    with tarfile.open(fileobj=io.BytesIO(child_raw), mode='r:xz') as stream:
        for member in stream:
            path = PurePosixPath(member.name)
            need(member.isfile() and not path.is_absolute() and '..' not in path.parts and
                 path.as_posix() == member.name and member.name not in child_members and member.size <= 2 * 1024 * 1024,
                 'child member safety/uniqueness/bound')
            with stream.extractfile(member) as source:
                raw = source.read(2 * 1024 * 1024 + 1)
            need(len(raw) == member.size, 'child member exact extent')
            child_members[member.name] = raw
    child_index_raw = child_members['export-index.json']
    need(digest(child_index_raw) == h4completion['archive_index_sha256'], 'H4 actual index')
    child_index = json.loads(child_index_raw)
    expected_child = dict(child_index['embedded_metadata_files'])
    expected_child['export-index.json'] = dict(bytes=len(child_index_raw), sha256=digest(child_index_raw))
    need(set(expected_child) == set(child_members), 'exact H4 metadata archive members')
    for name, spec in expected_child.items():
        need(len(child_members[name]) == spec['bytes'] and digest(child_members[name]) == spec['sha256'], 'H4 actual member hash')
    need(child_members['H4/referenced-H3-index.json'] == index_raw and
         child_members['H4/referenced-H3-completion.json'] == completion_raw and
         digest(child_members['exporter.py']) == CONSUMER_SHA, 'exact H4 referenced H3/code bytes')
    h4plan_raw = child_members['export-plan.json']
    h4plan = json.loads(h4plan_raw)
    need(digest(h4plan_raw) == h4completion['plan_sha256'], 'H4 original plan bytes')
    h4map_raw = child_members['H4/original-source-map.json']
    need(h4map_raw == base64.b64decode(h4plan['source_map']['data_base64'], validate=True) and
         h4map_raw == read(ROOT / 'model_storage/h4-capture-repair/native/joint-h4-native-attempt-1/h4-actual-image-inventory.json',
                          'a1e42612d6a89337144b00335da2fa690dc7f503b46532ff795f0c92198bdd9c'), 'original H4 actual inventory preserved')
    h4map = json.loads(h4map_raw)
    h4result_raw = read(OUTPUT / 'H4-full-dependent-consumer.json', '3a986262bd8d1cdd5d2e1fb063db953d9eb546b7154a0cf6dab4a801a22b80e8')
    h4result = json.loads(h4result_raw)
    need(h4result['status'] == 'VERIFIED_COMPLETE_BYTE_CLOSURE' and h4result['native_qualification_awarded'] is False and
         h4result['capture_gaps_filled'] is False, 'original consumer byte-only result scope')
    views = {row['name']: row for row in h4result['complete_logical_views']}
    source_images = {row['sha256']: row for row in h4map['images']}
    need(len(views) == len(child_index['files']) == len(h4plan['files']) == len(source_images) == 11, 'exact H4 eleven images')
    logical = []
    for image, planned in zip(child_index['files'], h4plan['files'], strict=True):
        need(all(image.get(k) == v for k, v in planned.items()) and image['representation'] == 'referenced-complete-image', 'H4 immutable image/reference binding')
        original = source_images[image['sha256']]
        need(image['aliases'] == original['retained_aliases'] and image['original_observations'] == original['observations'] and
             image['original_actual_paths'] == original['actual_paths'], 'H4 original observation/alias equality')
        reference = image['parent_reference']
        actual = physical[reference['member']]
        need(reference['archive_sha256'] == PINS['H3'][1] and reference['archive_bytes'] == PINS['H3'][0] and
             reference['index_sha256'] == digest(index_raw) and reference['bytes'] == image['bytes'] == actual['bytes'] and
             reference['sha256'] == image['sha256'] == actual['sha256'] and actual['elf_magic'], 'actual complete H3 bytes for H4 view')
        view = views[image['name']]
        need(view['bytes'] == actual['bytes'] and view['sha256'] == actual['sha256'] and
             view['source']['member'] == reference['member'] and view['parent_native_credit_transferred'] is False, 'actual consumer view correspondence')
        logical.append(dict(name=image['name'], bytes=actual['bytes'], sha256=actual['sha256'],
                            independently_reopened_complete_member=actual['path'], parent_native_credit_transferred=False))
    need(sum(row['bytes'] for row in logical) == 1674575368, 'H4 complete declared logical bytes')
    extra_after = extras(extracted, expected)
    paused_after = paused_state()
    need(paused_before == paused_after, 'original paused reader state changed')
    result = dict(schema='independent-declared-H3-H4-bytes-with-output-provenance-hold-v1',
                  status='HOLD_UNKNOWN_OUTPUT_PROVENANCE',
                  narrow_expected_H3_content='VERIFIED_16_DECLARED_MEMBERS_WITH_11_COMPLETE_ELF_HASHES',
                  narrow_H4_content='VERIFIED_EXACT_CHILD_METADATA_AND_11_REFERENCED_H3_HASHES',
                  started_at_utc=started, completed_at_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-start,
                  actual_consumer_phase_report=identity(directory / 'readback-verification.json', actual_phase_raw),
                  actual_H4_consumer_report=identity(OUTPUT / 'H4-full-dependent-consumer.json', h4result_raw),
                  source=identity(Path(__file__)), strict_first_attempt_source=identity(OUT / 'attempt1/verify_consumed_members.py'),
                  strict_first_attempt_exit_code=1, strict_first_attempt_result_not_overwritten=True,
                  physical_expected_H3_members=physical, H4_child=identity(child_path, child_raw), H4_members=expected_child,
                  H4_logical_images=logical, H3_original_failed_scope=actual_phase['scope'],
                  unexpected_output_before=extra_before, unexpected_output_after=extra_after,
                  unexpected_entries_removed_or_ignored=False, exact_output_directory_accepted=False,
                  extra_provenance='Unknown; W1 separately checks the five observed extra files. No attribution inferred here.',
                  old_paused_state_before=paused_before, old_paused_state_after=paused_after,
                  original_consumer_reexecuted=False, new_native_execution=False, new_network_calls=0,
                  limitations=['This narrow diagnostic does not replace the failed strict exact-directory review.',
                               'Physical declared contents match their original hashes, but the output directory remains unaccepted because extra-file provenance is unresolved.',
                               'H1/H2/H3 native failures and H2 incomplete capture remain unchanged. No missing process evidence is reconstructed.'])
    raw = (json.dumps(result, sort_keys=True, indent=2) + '\n').encode()
    target = OUT / 'expected-H3-H4-only-review.json'
    with target.open('xb') as stream:
        need(stream.write(raw) == len(raw), 'short narrow report write')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps(dict(status=result['status'], bytes=len(raw), sha256=digest(raw), report=str(target))), flush=True)


if __name__ == '__main__':
    main()
