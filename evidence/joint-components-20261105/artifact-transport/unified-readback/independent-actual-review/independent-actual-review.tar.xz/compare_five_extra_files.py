#!/usr/bin/env python3
"""Exact five-file, same-FD forensic comparison; never attributes a creator."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import time

from verify_actual_transport import ROOT, OUT, digest, file_key, identity, need, paused_state, read

RUN = ROOT / 'w1/unified-archive-readback-execution-01'
PAIRS = [
    ('output/H1/extracted.partial/H1/elf/86a2c65e12fbef81586067783aa478677975e03290bcd62561938645ac1efc7e.elf',
     'output/H1/extracted/H1/elf/86a2c65e12fbef81586067783aa478677975e03290bcd62561938645ac1efc7e.elf',
     399507456, 'f54e7570cabbf06fefb78811f69468993b1529057af55485ce019f2e18810033',
     504265656, '86a2c65e12fbef81586067783aa478677975e03290bcd62561938645ac1efc7e'),
    ('output/H2/extracted.partial/H2/elf/a8bb307bec662845bf2a22cfb756ceb4b3ad0595f5b0e290c8983326a4fb344b.elf',
     'output/H2/extracted/H2/elf/a8bb307bec662845bf2a22cfb756ceb4b3ad0595f5b0e290c8983326a4fb344b.elf',
     504302232, 'a8bb307bec662845bf2a22cfb756ceb4b3ad0595f5b0e290c8983326a4fb344b',
     504302232, 'a8bb307bec662845bf2a22cfb756ceb4b3ad0595f5b0e290c8983326a4fb344b'),
    ('output/H2/extracted.partial/H2/elf/f16fe89c11c71de377b62783fa5f06f23c8461b7d1b697aaf742dc2830d14295.elf',
     'output/H2/extracted/H2/elf/f16fe89c11c71de377b62783fa5f06f23c8461b7d1b697aaf742dc2830d14295.elf',
     120074176, 'f16fe89c11c71de377b62783fa5f06f23c8461b7d1b697aaf742dc2830d14295',
     120074176, 'f16fe89c11c71de377b62783fa5f06f23c8461b7d1b697aaf742dc2830d14295'),
    ('output/H3/.H3-actual-retained-elfs.tar.xz.IOnmZz',
     'output/H3/H3-actual-retained-elfs.tar.xz',
     199753728, 'e96ffd94964e98e713ad921224a6af80d311917c5eb4d3ac345473f8025b8ba1',
     283427280, '5365fcf900781044108e9642ae02a110e4ac8d031d9ee516c4f0b0e471e1e773'),
    ('output/H3/extracted/H3/elf/.00a637f55c720b06a655b569930bddaef19fd791467bc4784fe0bfb9e0002a26.elf.uZrNlA',
     'output/H3/extracted/H3/elf/00a637f55c720b06a655b569930bddaef19fd791467bc4784fe0bfb9e0002a26.elf',
     338690048, 'a768306d399ebe7124320c0f803d4c21dd56e44fb4789f51534dfdc86b8b288a',
     488112384, '00a637f55c720b06a655b569930bddaef19fd791467bc4784fe0bfb9e0002a26'),
]


def details(info):
    return dict(device=info.st_dev, inode=info.st_ino, bytes=info.st_size, mode=stat.S_IMODE(info.st_mode),
                uid=info.st_uid, gid=info.st_gid, mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns,
                mtime_utc=datetime.fromtimestamp(info.st_mtime_ns/1e9, timezone.utc).isoformat(),
                ctime_utc=datetime.fromtimestamp(info.st_ctime_ns/1e9, timezone.utc).isoformat())


def opened(path, size):
    need(path.resolve(strict=True) == path and path.is_relative_to(RUN), 'noncanonical or unowned forensic input')
    stream = os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb')
    info = os.fstat(stream.fileno())
    need(stat.S_ISREG(info.st_mode) and info.st_size == size, 'actual forensic type/extent changed')
    need(file_key(info) == file_key(path.stat()), 'forensic opened object differs from path')
    return stream, info


def main():
    start = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    paused_before = paused_state()
    manifest_path = RUN / 'delivery-manifest.json'
    manifest_raw = read(manifest_path)
    manifest = json.loads(manifest_raw)
    first_files = {entry['path']: entry for entry in manifest['files']}
    terminal_raw = read(RUN / 'terminal.json', '2630adfacf2368edaedc105893386857dd53ca6f939e30aee132c178d406a507')
    terminal = json.loads(terminal_raw)
    need(terminal['exit_code'] == 0, 'original consumer terminal altered')
    proofs = []
    for number, (extra_name, source_name, extra_size, extra_sha, source_size, source_sha) in enumerate(PAIRS):
        need(first_files[extra_name]['bytes'] == extra_size and first_files[extra_name]['sha256'] == extra_sha,
             'original first observed extra identity changed')
        extra_path, source_path = RUN / extra_name, RUN / source_name
        need(extra_size <= source_size, 'extra exceeds explicit reference extent')
        extra_stream, extra_before = opened(extra_path, extra_size)
        with extra_stream:
            source_stream, source_before = opened(source_path, source_size)
            with source_stream:
                extra_digest = hashlib.sha256()
                source_digest = hashlib.sha256()
                compared = total = 0
                while block := source_stream.read(1024 * 1024):
                    source_digest.update(block)
                    if compared < extra_size:
                        wanted = min(len(block), extra_size - compared)
                        partial = extra_stream.read(wanted)
                        need(len(partial) == wanted and partial == block[:wanted], 'actual byte inequality at offset ' + str(compared))
                        extra_digest.update(partial)
                        compared += wanted
                    total += len(block)
                    need(total <= source_size, 'reference file grew')
                need(extra_stream.read(1) == b'' and compared == extra_size and total == source_size, 'forensic complete read extents')
                extra_after = os.fstat(extra_stream.fileno())
                source_after = os.fstat(source_stream.fileno())
                need(file_key(extra_before) == file_key(extra_after) == file_key(extra_path.stat()), 'extra changed during same-FD read')
                need(file_key(source_before) == file_key(source_after) == file_key(source_path.stat()), 'reference changed during same-FD read')
        need(extra_digest.hexdigest() == extra_sha and source_digest.hexdigest() == source_sha, 'independent full SHA mismatch')
        relation = 'EXACT_COMPLETE_BYTES' if extra_size == source_size else 'EXACT_PREFIX_BYTES'
        proofs.append(dict(extra_path=str(extra_path), reference_path=str(source_path), extra_sha256=extra_sha,
                           reference_full_sha256=source_sha, compared_bytes=compared, extra_bytes=extra_size,
                           reference_complete_bytes=source_size, relation=relation,
                           extra_before=details(extra_before), extra_after=details(extra_after),
                           reference_before=details(source_before), reference_after=details(source_after),
                           creator_inferred=False, origin_provenance='UNKNOWN', exact_output_census_accepted=False))
        print(json.dumps(dict(file=number + 1, total=5, relation=relation, compared_bytes=compared,
                              overall='HOLD_UNKNOWN_OUTPUT_PROVENANCE')), flush=True)
    paused_after = paused_state()
    need(paused_before == paused_after, 'old paused controls changed')
    result = dict(schema='five-extra-files-physical-content-relationship-v1', status='HOLD_UNKNOWN_OUTPUT_PROVENANCE',
                  started_at_utc=started, completed_at_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-start,
                  reviewer_source=identity(Path(__file__)), original_first_delivery=identity(manifest_path, manifest_raw),
                  original_consumer_terminal=identity(RUN / 'terminal.json', terminal_raw), original_consumer_exit_code=0,
                  strict_independent_review_exit_code=1, proofs=proofs,
                  original_pause_state_before=paused_before, original_pause_state_after=paused_after,
                  no_files_deleted_moved_or_replaced=True, original_consumer_rerun=False, native_execution=False,
                  new_remote_calls=0, process_scan_performed=False,
                  conclusion='All five extra files were physically read through stable descriptors and compared against the complete verified reference bytes. Two are complete equal copies and three are exact prefixes. Content equality does not identify their creator or explain their presence; the strict output-directory review remains failed and overall closure remains HOLD.',
                  limitations=['No file creation attribution is made from names, timestamps, matching content, or the successful consumer terminal.',
                               'Only these five exact previously observed paths and their explicit reference files were opened. No general process or host scan was performed.',
                               'These extra artifacts are not promoted to complete images, native capture, or trusted archive members.'])
    raw = (json.dumps(result, sort_keys=True, indent=2) + '\n').encode()
    path = OUT / 'five-extra-file-forensics.json'
    with path.open('xb') as stream:
        need(stream.write(raw) == len(raw), 'short forensic report write')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps(dict(status=result['status'], report=str(path), bytes=len(raw), sha256=digest(raw))), flush=True)


if __name__ == '__main__':
    main()
