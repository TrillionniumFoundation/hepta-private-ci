#!/usr/bin/env python3
"""Re-open the completed consumer's physical outputs, without rerunning it."""
from __future__ import annotations

import base64
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile
import time

from verify_actual_transport import (
    ROOT, OUT, COMMIT, TREE, PLAN_SHA, COMPLETIONS, COMBINED_SHA,
    digest, file_key, identity, need, paused_state, read,
)

RUN = ROOT / 'w1/unified-archive-readback-execution-01'
OUTPUT = RUN / 'output'
V3_SHA = 'cd468711332a1e8cf4ac3bbf0e3575f274d692b03140563a65a3f3de0da80054'
CONSUMER_SHA = 'ce96de09dc981311753d37312c1b254751cce3b40c4f950f603303a523508425'
PINS = {
    'H1': (130746864, '7a374c980126ed29507e55f182705486c33889c73e58c285d83e7d1ff5618296', 32, 9, 4, 774620584),
    'H2': (256132128, 'f75c5d36596b84261ebc10705cd73de8abbe68eb87897413fcdb7e0cc92631a7', 62, 14, 8, 1512251368),
    'H3': (283427280, '5365fcf900781044108e9642ae02a110e4ac8d031d9ee516c4f0b0e471e1e773', 68, 16, 11, 1674575368),
}


def full_hash(path, expected_bytes, expected_sha, prefix_size=0):
    path = Path(path).absolute()
    need(path.resolve(strict=True) == path and path.is_relative_to(ROOT), 'noncanonical physical output')
    checksum = hashlib.sha256()
    prefix_checksum = hashlib.sha256()
    total = 0
    magic = b''
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_size == expected_bytes, 'physical size/type mismatch')
        while block := stream.read(1024 * 1024):
            magic = (magic + block[:4])[:4]
            checksum.update(block)
            if total < prefix_size:
                prefix_checksum.update(block[:prefix_size-total])
            total += len(block)
            need(total <= expected_bytes, 'physical file grew')
        need(file_key(before) == file_key(os.fstat(stream.fileno())) == file_key(path.stat()), 'physical output changed during hashing')
    need(total == expected_bytes and checksum.hexdigest() == expected_sha, 'physical hash mismatch: ' + str(path))
    return dict(path=str(path.relative_to(ROOT)), bytes=total, sha256=checksum.hexdigest(), elf_magic=magic == b'\x7fELF',
                prefix_bytes=prefix_size, prefix_sha256=prefix_checksum.hexdigest() if prefix_size else None,
                stable_open_file_identity=list(file_key(before)))


def main():
    started = datetime.now(timezone.utc).isoformat()
    clock = time.monotonic()
    paused_before = paused_state()
    terminal_raw = read(RUN / 'terminal.json', '2630adfacf2368edaedc105893386857dd53ca6f939e30aee132c178d406a507')
    terminal = json.loads(terminal_raw)
    request_raw = read(RUN / 'request.json', '34bdf3b581ef738ee34944c96c8031dc9299c54435d2a48c3bda42a417315aba')
    request = json.loads(request_raw)
    launch_raw = read(RUN / 'actual-launch.json')
    launch = json.loads(launch_raw)
    need(terminal['exit_code'] == 0 and terminal['automatic_retry'] is False and
         terminal['native_execution'] is False and terminal['new_remote_calls'] == 0, 'actual original terminal')
    need(terminal['request_sha256'] == launch['request_sha256'] == digest(request_raw) and
         terminal['pid'] == launch['pid'] and terminal['started_utc'] == launch['started_utc'] and
         request['argv'] == launch['argv'] and request['verifier_sha256'] == V3_SHA, 'actual invocation identity')
    source = ROOT / 'w1/unified-archive-readback-v3/verify_archives.py'
    read(source, V3_SHA)
    read(ROOT / 'w1/unified-archive-readback-v3/reused/archive_reference.py', CONSUMER_SHA)
    streams = {}
    for name, expected in terminal['streams'].items():
        raw = read(RUN / name, expected['sha256'])
        need(len(raw) == expected['bytes'], 'actual stream extent')
        streams[name] = identity(RUN / name, raw)
    need(streams['stderr.log']['bytes'] == 0 and streams['stdout.log']['bytes'] == 477, 'original stream outcome')
    completion_raw = read(OUTPUT / 'completion.json', '5c2f35e1180aa50e9fdacf58459d8d16533e8a16eba80833d4bc2fec9a4d4a79')
    completion = json.loads(completion_raw)
    need(completion['status'] == 'VERIFIED_ORIGINAL_H1_H2_H3_AND_DEPENDENT_H4_BYTES' and
         completion['caller_reviewed_transport_commit'] == COMMIT and completion['caller_reviewed_transport_tree'] == TREE and
         completion['referenced_fetch_receipts_manifest_sha256'] == COMBINED_SHA and
         completion['original_frozen_transport_plan_sha256'] == PLAN_SHA, 'actual consumer source/transport')
    for flag in ('H2_second_process_complete_binding', 'native_reexecution', 'new_binary_read_receipts_created',
                 'new_native_or_capture_credit', 'old_binary_read_progress_changed', 'originals_deleted_or_replaced'):
        need(completion[flag] is False, 'consumer expanded original scope: ' + flag)
    need(completion['original_downloader_state_before'] == completion['original_downloader_state_after'], 'consumer paused-state difference')
    report = {}
    indexes = {}
    total_members = total_image_bytes = total_archive_bytes = total_parts = 0
    for phase, (archive_size, archive_sha, part_count, member_count, image_count, image_bytes) in PINS.items():
        directory = OUTPUT / phase
        original_raw = read(ROOT / 'w1' / (phase.lower() + '-elf-export') / (phase + '-export-completion.json'), COMPLETIONS[phase])
        original = json.loads(original_raw)
        need(read(directory / (phase + '-export-completion.json')) == original_raw, 'consumer completion preserves exact original')
        phase_raw = read(directory / 'readback-verification.json')
        phase_result = json.loads(phase_raw)
        need(phase_result == completion['phases'][phase], 'phase report is not the actual final report')
        need(original['archive_bytes'] == archive_size and original['archive_sha256'] == archive_sha and
             len(original['parts']) == part_count, 'original archive pins')
        archive_path = directory / (phase + '-actual-retained-elfs.tar.xz')
        physical_archive = full_hash(archive_path, archive_size, archive_sha)
        parts_hasher = hashlib.sha256()
        offset = 0
        part_proofs = []
        for number, part in enumerate(original['parts']):
            need(part['index'] == number and part['offset'] == offset, 'original part order/offset')
            raw = read(directory / 'parts' / part['name'], part['sha256'])
            need(len(raw) == part['bytes'], 'physical decoded part size')
            parts_hasher.update(raw)
            offset += len(raw)
            part_proofs.append(identity(directory / 'parts' / part['name'], raw))
        need(offset == archive_size and parts_hasher.hexdigest() == archive_sha, 'physical part concatenation')
        extracted = directory / 'extracted'
        index_raw = read(extracted / 'export-index.json', original['archive_index_sha256'])
        index = json.loads(index_raw)
        indexes[phase] = index
        need(index['source_commit'] == original['source_commit'] and index['source_tree'] == original['source_tree'] and
             index['phase'] == phase and index['native_reexecution'] is False and
             index['original_run_outcome'] == original['original_run_outcome'] and index['capture_limits'] == original['capture_limits'],
             'embedded source/outcome/scope preservation')
        expected = dict(index['embedded_metadata_files'])
        need(len(index['files']) == image_count, 'complete image inventory count')
        for image in index['files']:
            need(image['name'] not in expected and image['name'] == phase + '/elf/' + image['sha256'] + '.elf', 'unique image identity')
            expected[image['name']] = {key: image[key] for key in ('bytes', 'sha256')}
        expected['export-index.json'] = dict(bytes=len(index_raw), sha256=digest(index_raw))
        actual_set = {str(path.relative_to(extracted)) for path in extracted.rglob('*') if path.is_file() or path.is_symlink()}
        need(len(expected) == member_count and expected == phase_result['members'] and actual_set == set(expected), 'physical member inventory')
        physical_members = {}
        for name, item in expected.items():
            prefix_size = 314572800 if phase == 'H2' and name == 'H2/elf/00a637f55c720b06a655b569930bddaef19fd791467bc4784fe0bfb9e0002a26.elf' else 0
            actual = full_hash(extracted / name, item['bytes'], item['sha256'], prefix_size)
            need('/elf/' not in name or actual['elf_magic'], 'complete image missing actual ELF magic')
            physical_members[name] = actual
        need(sum(item['bytes'] for item in index['files']) == image_bytes == phase_result['actual_ELF_bytes'], 'actual image byte total')
        plan_raw = read(extracted / 'export-plan.json', original['plan_sha256'])
        plan = json.loads(plan_raw)
        mapping_raw = read(extracted / (phase + '/original-source-map.json'), plan['source_map']['sha256'])
        need(len(mapping_raw) == plan['source_map']['bytes'] and base64.b64decode(plan['source_map']['data_base64'], validate=True) == mapping_raw,
             'original map exact embedded bytes')
        planned = {entry['name']: entry for entry in plan['files']}
        need(len(planned) == image_count and set(planned) == {entry['name'] for entry in index['files']}, 'planned exact images')
        for image in index['files']:
            need(all(image.get(key) == value for key, value in planned[image['name']].items()) and
                 image['first_read_metadata'] == image['second_read_metadata'] and image['second_read_sha256'] == image['sha256'] and
                 image['other_aliases_reopened_by_this_export'] is False, 'original alias/observation preservation')
        scope = phase_result['scope']
        if phase == 'H1':
            chunk = read(ROOT / 'pq_recovery/h1-actual-elf-download/chunks/000000000.bin',
                         '94972dacc09426ec1d38fb0c2c131ed33599ef68cf35e594582d457fbe2e8a9d')
            with archive_path.open('rb') as stream:
                need(stream.read(65536) == chunk and len(chunk) == 65536, 'original actual binary_read first range')
            need(scope['missing_individual_captures_filled'] is False and original['original_run_outcome']['result'] == 'FAILED', 'H1 preserved failure/gaps')
        elif phase == 'H2':
            need(len(index['partial_prefix_representations']) == 1, 'one original partial representation')
            partial = index['partial_prefix_representations'][0]
            prefix = physical_members[partial['reconstruction']['member']]
            need(prefix['prefix_bytes'] == partial['bytes'] == 314572800 and prefix['prefix_sha256'] == partial['sha256'] ==
                 'b9dc995ee3e6e623056a2563ab8aed3629c003a418b28486ac09db914a0b3f8d', 'H2 actual partial prefix bytes')
            for flag in ('complete_executable', 'completed_process_binding', 'native_evidence_credit'):
                need(partial[flag] is False and scope[flag] is False, 'H2 partial gained execution credit')
            need(original['original_run_outcome']['status'] == 'FAILED', 'H2 original failure retained')
        else:
            need(scope['original_native_outcome'] == 'FAILED' and scope['capture_gaps_filled'] is False and
                 scope['second_process_full_hash_or_copy_inferred'] is False and len(scope['unmatched_live_observations']) == 1,
                 'H3 original failure/helper limitation retained')
        report[phase] = dict(original_completion=identity(directory / (phase + '-export-completion.json'), original_raw),
                             actual_consumer_phase_report=identity(directory / 'readback-verification.json', phase_raw),
                             physical_archive=physical_archive, physical_parts=part_proofs, physical_members=physical_members,
                             original_run_outcome=original['original_run_outcome'], preserved_scope=scope)
        total_members += member_count
        total_image_bytes += image_bytes
        total_archive_bytes += archive_size
        total_parts += part_count
        print(json.dumps(dict(phase=phase, independently_reopened_members=member_count, actual_elf_bytes=image_bytes)), flush=True)
    # The H4 child is only 100,964 bytes. Parse every child member directly,
    # independently, and resolve all eleven images to the rehashed H3 members.
    h4dir = ROOT / 'w1/h4-reference-export'
    h4completion_raw = read(h4dir / 'H4-export-completion.json', 'd3bda29c2ff27a18895e04ca672109298ca78bc9a9fd290d28a5d3db62930018')
    h4completion = json.loads(h4completion_raw)
    child_path = h4dir / 'H4-actual-retained-image-references.tar.xz'
    child_raw = read(child_path, '47d3c5efa6b9aa4b2f97ef06a606f2931d8065f068311303f8d079c18a7bbaa5')
    need(len(child_raw) == 100964 == h4completion['archive_bytes'] and h4completion['standalone_archive'] is False, 'bounded actual dependent child')
    child_members = {}
    with tarfile.open(fileobj=io.BytesIO(child_raw), mode='r:xz') as archive:
        for member in archive:
            relative = PurePosixPath(member.name)
            need(member.isfile() and not relative.is_absolute() and '..' not in relative.parts and
                 member.name == relative.as_posix() and member.name not in child_members and member.size <= 2 * 1024 * 1024,
                 'unsafe/duplicate child metadata')
            with archive.extractfile(member) as stream:
                raw = stream.read(2 * 1024 * 1024 + 1)
            need(len(raw) == member.size, 'child member extent')
            child_members[member.name] = raw
    child_index_raw = child_members['export-index.json']
    need(digest(child_index_raw) == h4completion['archive_index_sha256'], 'actual child index digest')
    child_index = json.loads(child_index_raw)
    expected_child = dict(child_index['embedded_metadata_files'])
    expected_child['export-index.json'] = dict(bytes=len(child_index_raw), sha256=digest(child_index_raw))
    need(set(expected_child) == set(child_members), 'exact metadata-only child inventory')
    for name, expected in expected_child.items():
        need(len(child_members[name]) == expected['bytes'] and digest(child_members[name]) == expected['sha256'], 'actual child member hash')
    need(child_members['H4/referenced-H3-index.json'] == read(OUTPUT / 'H3/extracted/export-index.json') and
         child_members['H4/referenced-H3-completion.json'] == read(OUTPUT / 'H3/H3-export-completion.json'), 'exact referenced H3 metadata bytes')
    need(digest(child_members['exporter.py']) == CONSUMER_SHA, 'original H4 exporter source')
    h4plan = json.loads(child_members['export-plan.json'])
    need(digest(child_members['export-plan.json']) == h4completion['plan_sha256'] and
         child_members['H4/original-source-map.json'] == base64.b64decode(h4plan['source_map']['data_base64'], validate=True),
         'H4 original map/plan byte binding')
    actual_h4map = ROOT / 'model_storage/h4-capture-repair/native/joint-h4-native-attempt-1/h4-actual-image-inventory.json'
    need(child_members['H4/original-source-map.json'] == read(actual_h4map,
         'a1e42612d6a89337144b00335da2fa690dc7f503b46532ff795f0c92198bdd9c'), 'original H4 actual capture inventory bytes')
    h4raw = read(OUTPUT / 'H4-full-dependent-consumer.json', '3a986262bd8d1cdd5d2e1fb063db953d9eb546b7154a0cf6dab4a801a22b80e8')
    h4 = json.loads(h4raw)
    need(h4 == completion['H4_dependency_consumer'] and h4['status'] == 'VERIFIED_COMPLETE_BYTE_CLOSURE' and
         h4['native_qualification_awarded'] is False and h4['capture_gaps_filled'] is False, 'actual H4 byte-only result')
    need(h4['original_native_outcome'] == h4completion['original_run_outcome'] == child_index['original_run_outcome'] ==
         h4plan['original_run_outcome'], 'original H4 outcome retained exactly')
    views = {view['name']: view for view in h4['complete_logical_views']}
    need(len(views) == len(child_index['files']) == len(h4plan['files']) == 11, 'exact eleven H4 logical images')
    logical = []
    expected_parent_index_sha = digest(read(OUTPUT / 'H3/extracted/export-index.json'))
    for image, planned in zip(child_index['files'], h4plan['files'], strict=True):
        need(image['representation'] == 'referenced-complete-image' and all(image.get(key) == value for key, value in planned.items()),
             'H4 exact image/alias/observation mapping')
        reference = image['parent_reference']
        parent = report['H3']['physical_members'][reference['member']]
        need(reference['archive_sha256'] == PINS['H3'][1] and reference['archive_bytes'] == PINS['H3'][0] and
             reference['index_sha256'] == expected_parent_index_sha == h4['parent_index_sha256'] and
             parent['bytes'] == image['bytes'] == reference['bytes'] and parent['sha256'] == image['sha256'] == reference['sha256'] and
             parent['elf_magic'], 'physical complete H3 member behind H4 reference')
        view = views[image['name']]
        need(view['bytes'] == parent['bytes'] and view['sha256'] == parent['sha256'] and
             view['source']['member'] == reference['member'] and view['source']['archive_sha256'] == PINS['H3'][1] and
             view['parent_native_credit_transferred'] is False, 'reported logical view vs physical hash')
        logical.append(dict(name=image['name'], sha256=parent['sha256'], bytes=parent['bytes'],
                            physical_member=parent['path'], parent_native_credit_transferred=False))
    need(sum(row['bytes'] for row in logical) == 1674575368 and total_members == 39 and total_parts == 162 and
         total_archive_bytes == 670306272 and total_image_bytes == 3961447320, 'physical totals')
    paused_after = paused_state()
    need(paused_before == paused_after, 'old paused readers changed during independent check')
    result = dict(schema='independent-physical-archive-and-H4-member-review-v1', status='PASS_PHYSICAL_ARCHIVES_MEMBERS_AND_H4_REFERENCES',
                  started_at_utc=started, completed_at_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-clock,
                  actual_terminal=identity(RUN / 'terminal.json', terminal_raw), actual_launch=identity(RUN / 'actual-launch.json', launch_raw),
                  actual_request=identity(RUN / 'request.json', request_raw), actual_streams=streams,
                  actual_completion=identity(OUTPUT / 'completion.json', completion_raw), reviewed_source=identity(source),
                  reviewer_source=identity(Path(__file__)), phases=report, actual_members=39, actual_complete_image_entries=23,
                  physical_complete_image_bytes=total_image_bytes, original_archive_parts=162, original_archive_bytes=total_archive_bytes,
                  H4=dict(child=identity(child_path, child_raw), child_members=expected_child, logical_images=logical,
                          actual_consumer_report=identity(OUTPUT / 'H4-full-dependent-consumer.json', h4raw),
                          original_run_outcome=h4['original_native_outcome'], parent_credit_transferred=False),
                  old_pause_state_before=paused_before, old_pause_state_after=paused_after,
                  new_network_calls=0, native_execution=False, original_consumer_reexecuted=False,
                  method='Independent complete physical hash of all assembled archives, original decoded parts and extracted members; independent H4 child parse and logical references. The original v3/ce96 consumer was not rerun or imported.',
                  limitations=['The original consumer performed complete archive decompression and extraction. This independent pass reopens and hashes all physical outputs; it does not decompress the three large archives again.',
                               'H2 prefix bytes remain an incomplete second-process artifact. H3 failed correlation remains failed. No process or runtime closure is inferred from byte identity.',
                               'Post-run storage validation is separate from native/hosted acceptance and does not change their resource budgets or outcomes.'])
    raw = (json.dumps(result, sort_keys=True, indent=2) + '\n').encode()
    path = OUT / 'physical-member-review.json'
    with path.open('xb') as stream:
        need(stream.write(raw) == len(raw), 'short independent review write')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps(dict(status=result['status'], report=str(path), bytes=len(raw), sha256=digest(raw))), flush=True)


if __name__ == '__main__':
    main()
