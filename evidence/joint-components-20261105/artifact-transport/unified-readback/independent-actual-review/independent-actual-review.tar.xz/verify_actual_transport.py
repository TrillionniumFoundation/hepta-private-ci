#!/usr/bin/env python3
"""Independent, local-only re-open of published transport and original RPC bytes.

Does not import or execute the root combiner or W1 archive consumer.  It reads
their existing inputs and the root's frozen result, and writes only this review.
"""
from __future__ import annotations

import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import time

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / 'actual-archive-git-readback'
OUT = Path(__file__).resolve().parent
REPO = 'TrillionniumFoundation/hepta-private-ci'
REF = 'refs/heads/evidence/actual-elf-transport-20261105-93bfc-01'
COMMIT = '860dc2d8045f18808b9c5516f86edaef6e830734'
TREE = 'ba8da0b1dad8ba8777c0be85bbdc3ae8d1c0cb26'
PLAN_SHA = 'de5bf769089153d2bfd1fae468cf0af7942da442a9856acc120ee611757e5d5b'
COMBINED_SHA = 'ca1ba8e4683112bd6efa9959e26ada101099d71c36324c14a79d2a7824b9dc52'
COMPLETIONS = {
    'H1': '034f518dc2bd8fd350d2cb7a322056300051c538382370089104a727f6c1341b',
    'H2': 'd991a50f630e509278c20d5fe9f6ca0e53d1006852d954109d268375978407c1',
    'H3': '93d7bf08914054e4bcf05f17eea3cd5ef36fac9bbf0d1e601dda59084e758cd3',
}


def need(ok, why):
    if not ok:
        raise ValueError(why)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git_object(kind, raw):
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def file_key(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def read(path, expected=None, maximum=16 * 1024 * 1024):
    path = Path(path).absolute()
    need(path.resolve(strict=True) == path and path.is_relative_to(ROOT), 'noncanonical or outside review input')
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_size <= maximum, 'input type/size: ' + str(path))
        raw = stream.read(maximum + 1)
        after = os.fstat(stream.fileno())
        need(file_key(before) == file_key(after) == file_key(path.stat()), 'input changed: ' + str(path))
    need(len(raw) == before.st_size, 'short or oversized read')
    need(expected is None or digest(raw) == expected, 'pinned input SHA: ' + str(path))
    return raw


def identity(path, raw=None):
    if raw is None:
        raw = read(path)
    return dict(path=str(Path(path).absolute().relative_to(ROOT)), bytes=len(raw), sha256=digest(raw))


def rpc_json(name):
    path = DATA / 'control' / name
    raw = read(path)
    wrapper = json.loads(raw)
    need(wrapper['isError'] is False, 'Git provenance RPC failed')
    return json.loads(wrapper['structuredContent']['content']), identity(path, raw)


def paused_state():
    phase = json.loads(read(ROOT / 'model_storage/git-archive-readback-h3/H3-phase-manifest.json',
                            '204a339956d0622c1050a015dae5a61ebee14868691db242a6ed12aa96917d78'))
    roots = {'H1': ROOT / 'pq_recovery/h1-actual-elf-download',
             'H2': ROOT / 'w1/h2-actual-elf-download', 'H3': ROOT / 'w1/h3-actual-elf-download'}
    observed = {}
    for proof in phase['old_pause_proofs']:
        values = {}
        for name, expected in proof['files'].items():
            path = roots[proof['phase']] / name
            if expected['exists']:
                raw = read(path, expected['sha256'])
                values[name] = dict(exists=True, bytes=len(raw), sha256=digest(raw))
            else:
                need(not path.exists(), 'old absent state file was created')
                values[name] = dict(exists=False)
            need(values[name] == expected, 'old paused state differs from phase proof')
        progress = json.loads(read(roots[proof['phase']] / 'progress.json'))
        need(progress['status'] == 'PAUSED' and progress['in_flight'] == 0, 'old reader became active')
        observed[proof['phase']] = values
    return observed


def main():
    start = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    paused_before = paused_state()
    combined_path = DATA / 'root-review/combined-fetch-receipts-manifest.json'
    combined_raw = read(combined_path, COMBINED_SHA)
    combined = json.loads(combined_raw)
    need(combined['status'] == 'VERIFIED_ALL_166_ACTUAL_GIT_RESPONSES_AND_PAYLOADS', 'root result status')
    plan_path = ROOT / 'model_storage/git-archive-transport-attempt2/transport-plan.json'
    plan_raw = read(plan_path, PLAN_SHA)
    plan = json.loads(plan_raw)
    prepared_path = ROOT / 'model_storage/git-archive-transport-attempt2/execution/prepared-data-commit.json'
    prepared_raw = read(prepared_path, '45f5ed6fe3d7a6b5af75ca45bbf5845e3b0f05a5e99823bdf2bef3b454cf565f')
    prepared = json.loads(prepared_raw)
    ref, ref_proof = rpc_json('ref.raw.json')
    commit, commit_proof = rpc_json('commit.raw.json')
    tree, tree_proof = rpc_json('tree.raw.json')
    need(ref['ref'] == REF and ref['object']['sha'] == COMMIT and ref['object']['type'] == 'commit', 'actual ref identity')
    need(commit['sha'] == COMMIT and commit['tree']['sha'] == TREE and commit['parents'] == [], 'actual orphan commit identity')
    need(tree['sha'] == TREE and tree['truncated'] is False, 'actual complete tree identity')
    need(plan['repository'] == REPO and plan['destination_ref'] == REF and prepared['commit'] == COMMIT and
         prepared['tree'] == TREE and prepared['parents'] == [], 'prepared/plan identity')
    git_rows = {item['path']: item for item in tree['tree']}
    need(len(git_rows) == len(tree['tree']), 'duplicate recursive Git path')
    leaves = {name: row for name, row in git_rows.items() if row['type'] == 'blob'}
    need(len(leaves) == 166 and sorted(leaves) == plan['expected_transport_paths'], 'exact tree allowlist')
    need({k: v['sha'] for k, v in leaves.items()} == prepared['paths'], 'prepared tree bytes mapping')
    actual_paths = {str(path.relative_to(DATA / 'data')) for path in (DATA / 'data').rglob('*') if path.is_file()}
    need(actual_paths == set(leaves), 'actual local payload set differs')
    root_entries = {row['transport_path']: row for row in combined['entries']}
    need(len(root_entries) == len(combined['entries']) == 166 and set(root_entries) == set(leaves), 'root report set')
    meta_path = DATA / 'control/metadata-assignment.json'
    parts_path = DATA / 'control/parts-assignment.json'
    meta_raw = read(meta_path, 'bdaf5347c162a33f0aff97d50cc4fb456e8ab4f6f6c7e9683c9b72f3f363a33d')
    parts_raw = read(parts_path, 'b57d015fc37e7d7ab19a40c73ae53b3e8e8eb61836f3a1a20965eee0c3cce4a7')
    rows = json.loads(meta_raw)['assignments']
    part_assignments = json.loads(parts_raw)
    for phase in ('H1', 'H2', 'H3'):
        rows += part_assignments['assignments'][phase]
    need(len(rows) == 166 and {row['transport_path'] for row in rows} == set(leaves), 'assignment coverage')
    index_raw = read(DATA / 'data/transport-index.json', 'b3e34c0dde31956c8c470372997bdce9b23d624a82c87260aa3630851165e85b')
    index = json.loads(index_raw)
    need(index['route_plan_sha256'] == PLAN_SHA and index['repository'] == REPO and
         index['destination_ref'] == REF and index['orphan_data_only'] is True and
         index['source_or_native_qualification'] is False, 'index identity/scope')
    envelopes = {row['transport_path']: row for row in index['envelopes']}
    need(len(envelopes) == len(index['envelopes']) == 162, 'envelope uniqueness')
    original_completions = {}
    for phase, pin in COMPLETIONS.items():
        original_path = ROOT / 'w1' / (phase.lower() + '-elf-export') / (phase + '-export-completion.json')
        raw = read(original_path, pin)
        need(raw == read(DATA / 'data/archives' / phase / (phase + '-export-completion.json')), 'completion original bytes')
        original_completions[phase] = json.loads(raw)
    result = []
    counts = Counter()
    totals = Counter()
    for number, row in enumerate(rows):
        name = row['transport_path']
        expected = root_entries[name]
        metadata_raw = read(row['metadata_path'], row['metadata_sha256'])
        metadata = json.loads(metadata_raw)
        directory = Path(row['receipt_directory'])
        receipt_raw = read(directory / 'receipt.json')
        receipt = json.loads(receipt_raw)
        need(receipt['status'] == 'VERIFIED_ACTUAL_RPC_AND_PAYLOAD_BYTES' and
             receipt['native_execution'] is False and receipt['old_downloader_state_changed'] is False,
             'receipt result/scope')
        need(read(directory / 'metadata.json') == metadata_raw and
             json.loads(read(directory / 'declared-request.json')) == row['request'] == metadata['request'], 'original request/metadata')
        need(row['request'] == dict(repository_full_name=REPO, blob_sha=leaves[name]['sha']), 'exact immutable blob request')
        need(metadata['immutable_commit'] == receipt['declared_immutable_commit'] == COMMIT and
             metadata['immutable_tree'] == receipt['declared_immutable_tree'] == TREE and
             metadata['transport_path'] == receipt['transport_path'] == name and
             metadata['repository'] == receipt['repository'] == REPO and receipt['metadata_sha256'] == digest(metadata_raw),
             'metadata source binding')
        payload = read(row['payload_path'])
        need(Path(row['payload_path']) == DATA / 'data' / name, 'actual payload path binding')
        payload_identity = dict(bytes=len(payload), sha256=digest(payload), git_blob=git_object('blob', payload))
        need(payload_identity == expected['payload'], 'root payload identity differs from real bytes')
        need(payload_identity['git_blob'] == leaves[name]['sha'] == metadata['transport_git_blob_sha'] ==
             receipt['transport_git_blob_sha'] and leaves[name]['mode'] == '100644' and leaves[name]['size'] == len(payload), 'actual Git leaf content/mode')
        need(len(payload) == metadata['transport_bytes'] == receipt['transport_bytes'] and
             digest(payload) == metadata['transport_sha256'] == receipt['transport_sha256'], 'declared payload binding')
        raw_rpc = read(directory / 'rpc-original.raw.json')
        rpc = json.loads(raw_rpc)
        need(rpc['isError'] is False and rpc['structuredContent']['content'].encode('utf-8') == payload, 'actual response content')
        need(len(raw_rpc) == receipt['rpc_bytes'] == expected['actual_rpc']['bytes'] and
             digest(raw_rpc) == receipt['rpc_sha256'] == expected['actual_rpc']['sha256'], 'actual raw response digest')
        prefix = read(directory / 'rpc-prefix.bin')
        suffix = read(directory / 'rpc-suffix.bin')
        for label, value in (('prefix', prefix), ('suffix', suffix)):
            need(len(value) == receipt[label + '_bytes'] and digest(value) == receipt[label + '_sha256'], 'literal response boundary bytes')
        codec = receipt['reconstruction_codec']
        need(codec == expected['reconstruction_codec'], 'codec correspondence')
        if codec == 'literal-ascii-base64':
            token = payload
        else:
            need(codec in ('json-string-literal-ensure-ascii-false', 'json-string-literal-ensure-ascii-true'), 'unknown response codec')
            token = json.dumps(payload.decode('utf-8'), ensure_ascii=codec.endswith('-true'), separators=(',', ':')).encode('utf-8')
        need(prefix + token + suffix == raw_rpc, 'physical original RPC exact reconstruction')
        need(receipt['complete_original_rpc_retained'] is True and receipt['original_rpc_byte_equality_verified'] is True, 'original retention flags')
        for proof in expected['proof_files']:
            actual = read(ROOT / proof['path'], proof['sha256'])
            need(len(actual) == proof['bytes'], 'root metadata proof extent')
        original = None
        if name in envelopes:
            envelope = envelopes[name]
            phase = envelope['phase']
            part = envelope['original_part']
            need(part == original_completions[phase]['parts'][part['index']], 'original part offsets/hash/name')
            need(metadata['kind'] == 'base64-original-part' and codec == 'literal-ascii-base64', 'part type/codec')
            need(payload_identity == dict(bytes=envelope['transport_bytes'], sha256=envelope['transport_sha256'],
                                         git_blob=envelope['transport_git_blob']), 'envelope actual identity')
            decoded = base64.b64decode(payload, validate=True)
            need(base64.b64encode(decoded) == payload and b'\n' not in payload and b'\r' not in payload, 'canonical original part encoding')
            need(decoded == read(directory / 'actual-part.bin') and len(decoded) == part['bytes'] == metadata['original_bytes'] ==
                 receipt['actual_original_part_bytes'] and digest(decoded) == part['sha256'] == metadata['original_sha256'] ==
                 receipt['actual_original_part_sha256'], 'physical original part bytes')
            original = dict(phase=phase, index=part['index'], bytes=len(decoded), sha256=digest(decoded))
            need(original == expected['original_part'], 'root original part identity')
            counts[phase] += 1
            totals['decoded_bytes'] += len(decoded)
            totals['base64_bytes'] += len(payload)
        else:
            need(metadata['kind'] == 'json-utf8' and expected['original_part'] is None and isinstance(json.loads(payload), dict), 'metadata JSON kind')
        result.append(dict(path=name, payload=payload_identity, raw_rpc=dict(bytes=len(raw_rpc), sha256=digest(raw_rpc)),
                           receipt=identity(directory / 'receipt.json', receipt_raw), original=original,
                           actual_bytes_reopened=True, exact_rpc_reconstruction=True))
        totals['payload_bytes'] += len(payload)
        totals['rpc_bytes'] += len(raw_rpc)
        if (number + 1) % 32 == 0:
            print(json.dumps(dict(stage='independent-physical-reopen', complete=number + 1, total=166)), flush=True)
    need(dict(counts) == {'H1': 32, 'H2': 62, 'H3': 68}, 'phase part counts')
    need(totals['decoded_bytes'] == combined['original_archive_part_bytes'] == 670306272 and
         totals['base64_bytes'] == 893742124 and totals['payload_bytes'] == combined['actual_payload_bytes'] == 893971896 and
         totals['rpc_bytes'] == combined['actual_original_rpc_bytes'] == 894008077, 'combined actual byte totals')
    # Bottom-up Git tree serialization, independently checking every subtree.
    objects = {name: ('100644', row['sha']) for name, row in leaves.items()}
    directories = {''} | {name for name, row in git_rows.items() if row['type'] == 'tree'}
    for directory in sorted(directories, key=lambda name: (name.count('/') + bool(name)), reverse=True):
        entries = []
        for path, (mode, oid) in objects.items():
            parent, _, base = path.rpartition('/')
            if parent == directory:
                key = base.encode() + (b'/' if mode == '40000' else b'')
                entries.append((key, mode.encode() + b' ' + base.encode() + b'\0' + bytes.fromhex(oid)))
        need(entries, 'unexpected empty tree')
        encoded = b''.join(value for _, value in sorted(entries))
        computed = git_object('tree', encoded)
        if directory:
            need(git_rows[directory]['mode'] == '040000' and git_rows[directory]['sha'] == computed, 'actual subtree object mismatch')
            objects[directory] = ('40000', computed)
        else:
            need(computed == TREE, 'root Git tree object mismatch')
    need(datetime.fromisoformat(plan['commit_date'].replace('Z', '+00:00')).utcoffset().total_seconds() == 0, 'transport commit timezone')
    body = 'tree ' + TREE + '\n'
    for field in ('author', 'committer'):
        person = commit[field]
        seconds = int(datetime.fromisoformat(person['date'].replace('Z', '+00:00')).timestamp())
        body += f"{field} {person['name']} <{person['email']}> {seconds} +0000\n"
    body += '\n' + commit['message'] + '\n'
    need(git_object('commit', body.encode()) == COMMIT, 'independent raw orphan commit reconstruction')
    paused_after = paused_state()
    need(paused_before == paused_after, 'original pause files changed during review')
    sources = [DATA / 'combine_actual_receipts.py', DATA / 'review_and_assign.py', Path(__file__)]
    report = dict(schema='independent-actual-git-transport-byte-review-v1', status='PASS_ACTUAL_166_BYTES_AND_RPC_RECONSTRUCTION',
                  started_at_utc=started, completed_at_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-start,
                  method='Independent implementation; no root combiner, receiver, or W1 consumer was executed or imported.',
                  source_review=[identity(path) for path in sources], reviewed_combined_manifest=identity(combined_path, combined_raw),
                  plan=identity(plan_path, plan_raw), prepared_commit=identity(prepared_path, prepared_raw),
                  actual_git_provenance=[ref_proof, commit_proof, tree_proof], repository=REPO, ref=REF,
                  actual_commit=COMMIT, actual_tree=TREE, parents=[], complete_tree_and_subtree_reconstruction=True,
                  raw_orphan_commit_reconstruction=True, files=166, parts=162, phase_counts=dict(counts), byte_totals=dict(totals),
                  receipts=result, original_pause_state_before=paused_before, original_pause_state_after=paused_after,
                  network_calls=0, native_execution=False, archive_consumer_execution=False, original_state_changed=False,
                  limitations=['Transport-byte closure only; whole archive members and H4 references require the separately running original consumer.',
                               'This local independent review uses preserved actual Git RPCs; it does not perform a fresh network authentication.',
                               'No original H1, H2, or H3 failed native result or incomplete process capture is relabelled.'])
    output = OUT / 'transport-review.json'
    serialized = (json.dumps(report, sort_keys=True, indent=2) + '\n').encode()
    with output.open('xb') as stream:
        need(stream.write(serialized) == len(serialized), 'short review write')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps(dict(status=report['status'], report=str(output), bytes=len(serialized), sha256=digest(serialized))), flush=True)


if __name__ == '__main__':
    main()
