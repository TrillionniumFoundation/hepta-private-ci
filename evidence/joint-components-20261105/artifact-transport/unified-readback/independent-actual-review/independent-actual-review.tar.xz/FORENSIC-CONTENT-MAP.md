# Public reconstruction of observed extra-file content

The five unknown files remain physically in their original consumer output paths. Together they contain 1,562,327,640 bytes. The read-only same-descriptor comparison established two complete equal copies and three exact prefixes. It did not establish a creating actor.

`forensic-public-content-map.json` binds each exact physical path, observed file identity, full SHA-256 and size to an already published complete archive or archive member. It pins the data-only Git publication at commit `860dc2d8045f18808b9c5516f86edaef6e830734`, tree `ba8da0b1dad8ba8777c0be85bbdc3ae8d1c0cb26`, and the actual transport index. All five content sequences can therefore be recovered without uploading an additional 1.56 GB.

For the three prefixes, reconstruct and verify the entire original archive, verify the complete referenced member when applicable, then take the exact offset-zero byte length and verify the additional observed-file SHA-256. The two full copies use the same procedure with their complete member length. The H4 child is not needed to reconstruct these five sequences: their byte sources all belong to the completed H1/H2/H3 archives in the immutable data-only publication.

Reproducing the content does not reproduce or authenticate the original file's inode, timestamps, creator, or process history. **Overall remains `HOLD_UNKNOWN_OUTPUT_PROVENANCE`; the first strict directory failure is preserved.** None of the extra files is deleted, moved, silently excluded from the observed census, or accepted as additional native capture.
