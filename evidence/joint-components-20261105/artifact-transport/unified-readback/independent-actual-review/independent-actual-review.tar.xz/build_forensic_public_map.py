#!/usr/bin/env python3
"""Map five observed extra byte sequences to already published immutable data."""
from pathlib import Path
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def need(ok, why):
    if not ok:
        raise ValueError(why)


def pinned(path, expected):
    raw = path.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == expected, 'source bytes changed: ' + str(path))
    return raw, json.loads(raw)


def main():
    forensic_path = HERE / 'five-extra-file-forensics.json'
    forensic_raw, forensic = pinned(forensic_path, '32f055aac893a1ef1b18fca1ec2bd7a6b6fffa2d1384286d191a021bac3f3e82')
    index_path = ROOT / 'actual-archive-git-readback/data/transport-index.json'
    index_raw, index = pinned(index_path, 'b3e34c0dde31956c8c470372997bdce9b23d624a82c87260aa3630851165e85b')
    _, prepared = pinned(ROOT / 'model_storage/git-archive-transport-attempt2/execution/prepared-data-commit.json',
                         '45f5ed6fe3d7a6b5af75ca45bbf5845e3b0f05a5e99823bdf2bef3b454cf565f')
    publication = dict(repository='TrillionniumFoundation/hepta-private-ci', repository_id=1320694176,
                       visibility='public', immutable_commit='860dc2d8045f18808b9c5516f86edaef6e830734',
                       immutable_tree='ba8da0b1dad8ba8777c0be85bbdc3ae8d1c0cb26',
                       ref='refs/heads/evidence/actual-elf-transport-20261105-93bfc-01',
                       source_or_native_qualification=False)
    archives = {}
    for record in index['archives']:
        phase = record['phase']
        parts = [part for part in index['envelopes'] if part['phase'] == phase]
        archives[phase] = dict(archive_bytes=record['archive_bytes'], archive_sha256=record['archive_sha256'],
                              archive_index_sha256=record['archive_index_sha256'], original_part_count=len(parts),
                              original_completion=dict(path=record['completion_path'], bytes=record['completion_bytes'],
                                  sha256=record['completion_sha256'], git_blob_sha=prepared['paths'][record['completion_path']]),
                              part_mapping='Every original part, its exact envelope path/Git blob/bytes/SHA and offset are in the pinned transport-index.json; no repartitioning.',
                              original_native_outcome_preserved=record['original_native_outcome'])
    observations = []
    runroot = ROOT / 'w1/unified-archive-readback-execution-01/output'
    for proof in forensic['proofs']:
        extra = Path(proof['extra_path'])
        source = Path(proof['reference_path'])
        relative = source.relative_to(runroot)
        phase = relative.parts[0]
        need(phase in archives and extra.is_file() and not extra.is_symlink(), 'assigned original extra is missing or changed type')
        info = extra.stat()
        before = proof['extra_after']
        need(info.st_dev == before['device'] and info.st_ino == before['inode'] and info.st_size == before['bytes'] and
             info.st_mtime_ns == before['mtime_ns'] and info.st_ctime_ns == before['ctime_ns'], 'original extra identity changed after forensic read')
        if relative.parts[1] == 'extracted':
            source_kind = 'complete-archive-member'
            member = '/'.join(relative.parts[2:])
            archive_index = json.loads((runroot / phase / 'extracted/export-index.json').read_bytes())
            matches = [row for row in archive_index['files'] if row['name'] == member]
            need(len(matches) == 1 and matches[0]['bytes'] == proof['reference_complete_bytes'] and
                 matches[0]['sha256'] == proof['reference_full_sha256'], 'declared immutable member identity differs')
        else:
            need(phase == 'H3' and str(relative) == 'H3/H3-actual-retained-elfs.tar.xz', 'unexpected archive reference')
            source_kind = 'complete-archive-bytes'
            member = None
            need(archives[phase]['archive_bytes'] == proof['reference_complete_bytes'] and
                 archives[phase]['archive_sha256'] == proof['reference_full_sha256'], 'complete archive identity differs')
        observations.append(dict(original_unknown_physical_path=str(extra), original_unknown_file_retained_in_place=True,
                                 observed_identity=before, observed_bytes=proof['extra_bytes'], observed_sha256=proof['extra_sha256'],
                                 content_relationship=proof['relation'], content_reconstruction=dict(
                                     archive_phase=phase, source_kind=source_kind, member=member,
                                     verified_complete_source_bytes=proof['reference_complete_bytes'],
                                     verified_complete_source_sha256=proof['reference_full_sha256'],
                                     byte_offset=0, byte_length=proof['extra_bytes'], resulting_sha256=proof['extra_sha256']),
                                 original_creator_known=False, original_file_identity_recreated=False,
                                 complete_execution_or_capture_credit=False))
    need(len(observations) == 5 and sum(row['observed_bytes'] for row in observations) == 1562327640, 'exact five extra byte total')
    result = dict(schema='immutable-public-content-map-for-five-unknown-output-files-v1', status='HOLD_UNKNOWN_OUTPUT_PROVENANCE',
                  publication=publication, transport_index=dict(path='transport-index.json', bytes=len(index_raw),
                    sha256=hashlib.sha256(index_raw).hexdigest(), git_blob_sha='8aaf8fd787c9e84d4698c606cf8f91f4ecef1d09'),
                  source_forensic_report=dict(path=str(forensic_path.relative_to(ROOT)), bytes=len(forensic_raw),
                                             sha256=hashlib.sha256(forensic_raw).hexdigest()),
                  archive_dependencies=archives, extra_files=observations, physical_unknown_file_count=5,
                  original_unknown_bytes=1562327640, complete_content_matches=2, exact_prefix_content_matches=3,
                  reconstruction_steps=[
                      'Read transport-index.json from the exact immutable publication and verify its SHA-256 and Git blob.',
                      'For the named phase, obtain every listed canonical base64 envelope. Verify actual envelope bytes/SHA/Git blob, strict-decode, and verify the original part bytes/SHA/offset.',
                      'Concatenate original decoded parts in index order and verify the complete archive byte length and SHA-256.',
                      'If source_kind is complete-archive-member, read that exact regular member and verify its complete size/SHA-256; otherwise use the verified archive bytes.',
                      'Take exactly byte_offset and byte_length, and verify resulting_sha256. This reconstructs the observed content only, not the original inode, provenance, process attribution or timestamps.'
                  ], new_Git_objects_or_network_calls=0, original_files_deleted_or_moved=False,
                  strict_directory_failure_preserved=True, duplicate_gigabyte_payloads_uploaded=False,
                  limitation='Content is publicly reproducible from already verified archive bytes, but the actor and cause that created these five physical output files remain unknown. No directory or native acceptance is awarded.')
    raw = (json.dumps(result, sort_keys=True, indent=2) + '\n').encode()
    path = HERE / 'forensic-public-content-map.json'
    with path.open('xb') as output:
        need(output.write(raw) == len(raw), 'short mapping write')
        output.flush()
        os.fsync(output.fileno())
    print(json.dumps(dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), status=result['status'])))


if __name__ == '__main__':
    main()
