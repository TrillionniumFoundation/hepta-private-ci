# Independent actual archive byte review

## Current decision

**Overall: `HOLD_UNKNOWN_OUTPUT_PROVENANCE`.** The strict independent physical-directory review failed because the completed H3 extraction directory contains an additional file. Subsequent read-only examination found five extra files across the original consumer output. They remain in place. Their creating actor and cause have not been established.

This decision preserves three separate facts:

1. All 166 actual Git payloads and their retained RPC responses independently verified.
2. The one original v3 archive consumer actually exited 0, and the independently reopened declared archive/member contents match their pinned identities.
3. The exact physical output-directory review remains failed. Neither content equality nor the consumer's successful terminal explains the additional files.

No native execution, archive-consumer retry, remote request, source change, credential change, learning trial, file deletion, relocation, or replacement was performed by this review. The original H1/H2/H3 native failures remain failures; H2's incomplete second-process image is not promoted to a complete capture.

## Verified transport boundary

The immutable data-only publication is commit `860dc2d8045f18808b9c5516f86edaef6e830734`, tree `ba8da0b1dad8ba8777c0be85bbdc3ae8d1c0cb26`, with no parents, in `TrillionniumFoundation/hepta-private-ci`. The independent implementation did not import or execute the root combiner, receiver, or W1 consumer.

It physically reopened every declared payload, original RPC, request, metadata record, reconstruction prefix/suffix, and decoded original part. It checked SHA-256, actual Git blob hashes, canonical base64 without a trailing newline, complete RPC byte reconstruction, all recursive subtree identities, and the raw orphan commit identity. The totals are:

| Actual object | Count / bytes |
| --- | ---: |
| Git payloads | 166 |
| Original archive parts | 162: H1 32, H2 62, H3 68 |
| All payload bytes, including four JSON files | 893,971,896 |
| Retained actual RPC bytes | 894,008,077 |
| Decoded original archive bytes | 670,306,272 |

The frozen result is `transport-review.json`, SHA-256 `ecc74bb4c1a62f87e0a626c7fad3d5ecab9e8fbdc969750e1552af1c597069ee`. The root combined manifest is independently matched at SHA-256 `ca1ba8e4683112bd6efa9959e26ada101099d71c36324c14a79d2a7824b9dc52`.

The separate H3 readback phase has all 68 actual receipts, no failed part or refetch, and zero in-flight operations. Its manifest is `../git-archive-readback-h3/H3-phase-manifest.json`, SHA-256 `204a339956d0622c1050a015dae5a61ebee14868691db242a6ed12aa96917d78`.

## Original consumer and failed strict directory review

The original consumer's request is SHA-256 `34bdf3b581ef738ee34944c96c8031dc9299c54435d2a48c3bda42a417315aba`; its unchanged v3 source is `cd468711332a1e8cf4ac3bbf0e3575f274d692b03140563a65a3f3de0da80054`. Its actual terminal is exit 0, from `2026-11-06T00:55:06.173869+00:00` through `00:59:04.738052+00:00`, elapsed 238.56383343000198 seconds. The terminal has SHA-256 `2630adfacf2368edaedc105893386857dd53ca6f939e30aee132c178d406a507`; stdout is 477 bytes, SHA-256 `03f2e354c5d5ed5bb89376b10c5736f1b3fec1b14a110272ee5fd9ea09930faf`; stderr is empty.

The first independent strict physical pass completed H1's nine declared members and H2's fourteen declared members, including their complete hashes, archive parts, and the H2 partial-prefix boundary. It then rejected the H3 physical member set: the declared and reported sets both contained 16 entries, while the actual extraction directory contained 17. The original failed review source and returned-output transcript are retained under `attempt1/`. The transcript is explicitly a transcription of returned tool output, not a new native or consumer log.

The specific additional H3 ELF file has device 27, inode 556841, 338,690,048 bytes, and mode 0600. Its observed mtime was `2026-11-06T00:58:46.327415196Z`; ctime was `00:59:00.779245367Z`, both during the original consumer interval. Two subsequent observations preserved the same identity, size, mtime, and ctime. This establishes observed timestamps, not a creating actor. A narrow check of the original consumer PID 5 found no current process; no same-process identity or broader process census was inferred.

Static inspection of the executed v3/ce96 sources, the two reused verification helpers, and `run_once.py` found only their fixed `.partial` / `extracted.partial` output naming. No matching randomized temporary-name rule, `mktemp`, `rsync`, or copy operation was identified in these sources. That source inspection is not proof of an environmental cause.

## Narrow declared-content results

The separately named `verify_expected_h3_h4_only.py` did not change or rerun the strict checker. It explicitly retained the unexpected-file census and returned overall HOLD. It independently reopened all 16 declared H3 members, including all 11 complete ELF hashes totaling 1,674,575,368 bytes.

It also directly parsed the complete 100,964-byte H4 child archive, verified every child metadata member, compared the original H4 source map with the actual frozen capture inventory, and resolved all 11 logical H4 images to the physically rehashed H3 members. All original aliases and observations remain unchanged. This does not transfer H3 native credit to H4 or infer missing process evidence.

That narrow result is `expected-H3-H4-only-review.json`, 25,163 bytes, SHA-256 `829c71e21e84ebee8ee19d265bd364ba036496134e5f8d3be61412f091237d93`, with status `HOLD_UNKNOWN_OUTPUT_PROVENANCE`.

## Five extra files: actual content relationships

Only the five explicitly assigned extra paths and their corresponding declared reference files were read. Both descriptors were held throughout comparison; the complete extra and reference SHA-256 values and before/after descriptor and path identities were verified. Original files were not modified.

| Extra location within original consumer output | Extra bytes | Actual relationship |
| --- | ---: | --- |
| H1 `extracted.partial`, image `86a2c65e…` | 399,507,456 | Exact prefix of the complete H1 image |
| H2 `extracted.partial`, image `a8bb307b…` | 504,302,232 | Exact complete bytes of the declared H2 image |
| H2 `extracted.partial`, image `f16fe89c…` | 120,074,176 | Exact complete bytes of the declared H2 image |
| H3 extra archive-shaped file | 199,753,728 | Exact prefix of the complete H3 archive |
| H3 extra ELF-shaped file, image `00a637f5…` | 338,690,048 | Exact prefix of the complete declared daemon image |

The exact paths, full SHA-256 values, and all file identities are in `five-extra-file-forensics.json`, 15,834 bytes, SHA-256 `32f055aac893a1ef1b18fca1ec2bd7a6b6fffa2d1384286d191a021bac3f3e82`.

**These relationships do not explain provenance.** The strict output-directory result remains failed, and the extra files are not accepted as archive members or complete process captures.

## Preserved limits

The old H1, H2, and H3 binary-reader control files remain byte-identical to their original frozen PAUSED states, with zero in-flight reads. H1 still records only its original 65,536-byte read; H2/H3 still record zero through those old readers. New Git readback has not been written into their state.

All review conclusions are post-run byte and record comparisons. They do not establish full runtime/dependency closure, independent operator root custody, whole-machine crash recovery, model adoption or learning quality, real WAN operation, or release-gate acceptance. No historical failed run is relabelled.
