const READBACK_ROOT = "/workspace/scratch/93bfcfe29fc8/actual-archive-git-readback";
const RECEIVER = "/workspace/scratch/93bfcfe29fc8/w1/git-blob-receiver-v1/receive_git_blob.py";
function shellQuote(value) { return "'" + String(value).replace(/'/g, "'\\''") + "'"; }
function utf8Bytes(value) {
  let total = 0;
  for (const character of value) {
    const point = character.codePointAt(0);
    total += point <= 0x7f ? 1 : point <= 0x7ff ? 2 : point <= 0xffff ? 3 : 4;
  }
  return total;
}
async function settleLocal(session) {
  let current = session;
  const output = [session.output || ""];
  while (current.session_id) {
    current = await tools.write_stdin({session_id: current.session_id, chars: "", yield_time_ms: 1000, max_output_tokens: 1500});
    output.push(current.output || "");
  }
  return {...current, output: output.join("")};
}
async function captureActualRpc(value, path) {
  const raw = JSON.stringify(value);
  const size = utf8Bytes(raw);
  const command = ["python", "-B", READBACK_ROOT + "/capture_raw_rpc.py", path, size].map(shellQuote).join(" ");
  const started = await tools.exec_command({cmd: command, tty: true, yield_time_ms: 1000, max_output_tokens: 1000});
  if (!started.session_id || !started.output.includes("READY")) {
    store("unsaved-control-rpc:" + path, value);
    throw Error("Actual RPC retained in session store after receiver pre-READY failure: " + JSON.stringify(started));
  }
  const sent = await tools.write_stdin({session_id: started.session_id, chars: raw, yield_time_ms: 1000, max_output_tokens: 1500});
  const terminal = sent.session_id ? await settleLocal(sent) : sent;
  if (terminal.exit_code !== 0 || !((sent.output || "") + (terminal.output || "")).includes("SAVED_ACTUAL_RPC")) {
    throw Error("Raw RPC capture did not complete: " + JSON.stringify(terminal));
  }
  return {path, bytes: size, terminal};
}
async function fetchAssignedBlob(row) {
  const result = await tools.mcp__codex_apps__github_fetch_blob(row.request);
  const raw = JSON.stringify(result);
  const size = utf8Bytes(raw);
  const args = ["python", "-B", RECEIVER, "--metadata", row.metadata_path,
    "--expected-metadata-sha256", row.metadata_sha256, "--rpc-bytes", size,
    "--output", row.receipt_directory, "--data-root", READBACK_ROOT + "/data",
    "--payload-path", row.payload_path];
  const started = await tools.exec_command({cmd: args.map(shellQuote).join(" "), tty: true, yield_time_ms: 1000, max_output_tokens: 1000});
  if (!started.session_id || !started.output.includes("READY")) {
    const fallback = row.receipt_directory + ".pre-ready-failure.raw.json";
    await captureActualRpc(result, fallback);
    throw Error("Blob receiver pre-READY failure; full actual RPC saved: " + fallback + " " + JSON.stringify(started));
  }
  const sent = await tools.write_stdin({session_id: started.session_id, chars: raw, yield_time_ms: 1000, max_output_tokens: 1500});
  const terminal = sent.session_id ? await settleLocal(sent) : sent;
  const output = (sent.output || "") + (terminal.output || "");
  if (terminal.exit_code !== 0 || !output.includes("PASS_ACTUAL_BYTES")) {
    throw Error("Actual RPC preserved, blob receiver not complete: " + row.transport_path + " " + JSON.stringify(terminal));
  }
  return {path: row.transport_path, receipt_directory: row.receipt_directory, exit_code: terminal.exit_code};
}
