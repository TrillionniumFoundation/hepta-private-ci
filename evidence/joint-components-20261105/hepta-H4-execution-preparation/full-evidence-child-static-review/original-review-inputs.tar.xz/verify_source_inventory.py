#!/usr/bin/env python3
"""Verify pinned read-only source bytes and inventory explicit process syntax."""
import base64
import hashlib
import json
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
COMMIT = "6db78eca53a5acdda0d96873d3f4cd65863426f0"
TREE = "e91f5994017fc5d2cfe58d405a20ee6ad9376772"

def digest(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

directory = json.loads((ROOT / "raw/directory.json").read_text())
entries = json.loads(directory["structuredContent"]["content"])
local = json.loads((ROOT / "local-source-coverage.json").read_text())["exact_local"]
assert len(entries) == 50 and all(x["type"] == "file" for x in entries)
catalog = []
matches = []
pattern = re.compile(r"current_exe|\bCommand\s*::\s*new|process\s*::|#\s*\[\s*ignore|\b(?:fork|execve|execvp|posix_spawn)\s*\(")
for entry in entries:
    path = entry["path"]
    out = ROOT / "source" / path
    if path in local:
        original = WORKSPACE / local[path]
        data = original.read_bytes()
        provenance = {"kind": "existing_local_bytes_rechecked_against_exact_directory_blob", "path": str(original)}
    else:
        original = ROOT / "raw" / (entry["name"] + ".json")
        response = json.loads(original.read_text())
        assert not response.get("isError"), path
        result = response["structuredContent"]
        if result["encoding"] == "base64":
            data = base64.b64decode("".join(result["content"].splitlines()), validate=True)
        else:
            assert result["encoding"] == "utf-8", path
            data = result["content"].encode("utf-8")
        assert result["sha"] == entry["sha"], path
        provenance = {"kind": "exact_commit_github_file_response", "path": str(original)}
    assert len(data) == entry["size"] and blob(data) == entry["sha"], path
    out.parent.mkdir(parents=True, exist_ok=True)
    if not out.exists():
        out.write_bytes(data)
    assert out.read_bytes() == data
    catalog.append({"path": path, "bytes": len(data), "git_blob": blob(data), "sha256": digest(data), "provenance": provenance})
    for line_number, line in enumerate(data.decode().splitlines(), 1):
        if pattern.search(line):
            matches.append({"path": path, "line": line_number, "text": line.strip()})

configuration = []
for name in ("run_h4_native_pipeline.py", "test_elf_capture.py", "live_fd_correspondence.py", "nextest_fd_runner.py", "fd_gate_evidence.py", "h4-extra-controls.json"):
    original = WORKSPACE / "model_storage/h4-capture-repair/native" / name
    data = original.read_bytes()
    out = ROOT / "configuration" / name
    out.parent.mkdir(exist_ok=True)
    if not out.exists():
        out.write_bytes(data)
    assert out.read_bytes() == data
    configuration.append({"path": "configuration/" + name, "original": str(original), "bytes": len(data), "sha256": digest(data)})

extra = json.loads((ROOT / "configuration/h4-extra-controls.json").read_text())["full_evidence_library"]
child = "authbus_outbox_tests::crash_delivery_child"
parent = "authbus_outbox_tests::actual_process_crash_after_send_before_ack_redelivers_same_id"
assert len(extra["expected_names"]) == len(set(extra["expected_names"])) == 161
assert child not in extra["expected_names"] and parent in extra["expected_names"]
assert extra["expected_ignored"] == [child]
assert extra["minimum"] == 22 and extra["timeout_seconds"] == 600

report = {"schema": "hepta-h4-full-evidence-child-source-review-v1", "source_commit": COMMIT, "source_tree": TREE,
          "source_file_count": len(catalog), "source_bytes": sum(x["bytes"] for x in catalog),
          "source_catalog": catalog, "explicit_process_and_ignore_syntax": matches,
          "configuration": configuration, "full_library_gate": extra,
          "child_in_selected_names": False, "parent_in_selected_names": True,
          "native_execution": False, "h4_result_claim": False,
          "scope": "Read-only source binding and bounded explicit-process syntax inventory; not a general Rust static-analysis proof or runtime result."}
(ROOT / "source-inventory.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"files": len(catalog), "source_bytes": report["source_bytes"], "matches": matches, "selected": 161, "ignored": [child]}, indent=2))
