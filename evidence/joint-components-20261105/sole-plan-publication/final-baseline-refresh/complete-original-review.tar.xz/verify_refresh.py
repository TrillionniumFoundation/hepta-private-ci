"""Bind an already completed read-only Git refresh to retained exact sources."""
from pathlib import Path
import hashlib
import json

W = Path('/workspace/scratch/93bfcfe29fc8')
R = Path(__file__).resolve().parent
ORIGINAL = W / 'pq_recovery/chain-sole-plan-trigger-review'
PRIOR = W / 'pq_recovery/chain-sole-plan-refresh-2346'
BASE = 'a5b5127883393da33c8619cc5f2b8e333a2dcf1b'
HEAD = 'e40564bc32d311cb95a284c2bf3cc2a50de551d9'
TREE = '5ccbbe82933533522d0ca91febf690c20bef9cd1'
BRANCH = 'fix/chain-six-axis-performance-20261103'
DOC = 'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
UPDATED_WORKFLOW = '.github/workflows/pon-branch-encoding-acceptance.yml'


def load(p):
    return json.loads(p.read_bytes())


def payload(name, text=False):
    result = load(R / name)
    assert result.get('isError') is False
    value = result['structuredContent']
    if 'content' not in value:
        assert not text
        return value
    return value['content'] if text else json.loads(value['content'])


def desc(p):
    raw = p.read_bytes()
    return {'path': str(p.relative_to(W)), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}


refs = [payload(n) for n in ['ref-before.raw.json', 'ref-after.raw.json']]
for ref in refs:
    assert ref['ref'] == 'refs/heads/' + BRANCH
    assert ref['object']['type'] == 'commit' and ref['object']['sha'] == HEAD
commit = payload('commit.raw.json')
assert commit['sha'] == HEAD and commit['tree']['sha'] == TREE
assert [p['sha'] for p in commit['parents']] == [BASE]
compare = payload('compare.raw.json')
assert compare['base'] == compare['base_commit']['sha'] == compare['merge_base_commit']['sha'] == BASE
assert compare['head'] == HEAD and compare['status'] == 'ahead'
assert compare['ahead_by'] == compare['total_commits'] == 1 and compare['behind_by'] == 0
assert compare['too_large'] in (None, False) and len(compare['files']) == 5
assert all(x['status'] == 'added' and x['filename'].startswith('evidence/node-default-library-20261106/')
           for x in compare['files'])
tree = payload('tree.raw.json')
assert tree['sha'] == TREE and tree['truncated'] is False
assert len(tree['tree']) == 11591
blobs = {x['path']: x for x in tree['tree'] if x['type'] == 'blob'}
assert len(blobs) == 10400

catalog = {}
excluded_error_records = []
for filename in ['workflow-inventory.json', 'entry-source-inventory.json',
                 'model-control-source-inventory.json', 'unit-source-inventory.json']:
    for row in load(ORIGINAL / filename):
        if not row.get('git_blob'):
            assert row.get('error') is True
            excluded_error_records.append({'inventory': filename, 'original_record': row})
            continue
        assert row['path'] not in catalog
        actual = desc(ORIGINAL / 'source' / row['path'])
        assert all(actual[k] == row[k] for k in ['bytes', 'sha256', 'git_blob'])
        catalog[row['path']] = dict(row)
assert len(catalog) == 49 and len(excluded_error_records) == 1
assert excluded_error_records[0]['original_record']['path'] == 'scripts/project_preflight.py'
assert 'scripts/project_preflight.py' not in blobs
updated = desc(PRIOR / 'source' / UPDATED_WORKFLOW)
assert updated['git_blob'] == 'ef548bd61a94d33162436731975fb71493362af6'
assert updated['sha256'] == '31b25eaa1b77216d5c5d2b425e781d7b6fbec3ac9891b906d704f82fb50e1b21'
catalog[UPDATED_WORKFLOW] = {'path': UPDATED_WORKFLOW, **{k: updated[k] for k in ['bytes','sha256','git_blob']}}
verified = []
for path, row in sorted(catalog.items()):
    current = blobs[path]
    assert current['mode'] in ('100644', '100755')
    assert (current['sha'], current['size']) == (row['git_blob'], row['bytes'])
    verified.append({'path': path, 'git_blob': row['git_blob'], 'bytes': row['bytes'], 'mode': current['mode'],
                     'sha256': row['sha256'], 'unchanged_from_last_review': True})
current_workflows = {p for p in blobs if p.startswith('.github/workflows/')}
prior_workflows = {x['path'] for x in load(ORIGINAL / 'workflow-inventory.json')}
assert current_workflows == prior_workflows and len(current_workflows) == 19
changed = {x['filename'] for x in compare['files']}
assert not changed.intersection(catalog) and DOC not in changed

source = payload('sole-plan.raw.json', text=True).encode('utf-8')
assert source == (PRIOR / 'source' / DOC).read_bytes()
assert len(source) == 552675
assert hashlib.sha256(source).hexdigest() == '063df6d6047e08addb40d92c01bf85c2ff1386788369bfd7ba1d22e0a421198b'
assert hashlib.sha1(b'blob 552675\0' + source).hexdigest() == blobs[DOC]['sha'] == '3787d8321ee9f4eb5a0fe5794dcad3f997afecb1'
target = R / 'source' / DOC
target.parent.mkdir(parents=True, exist_ok=True)
target.write_bytes(source)
prior_review = load(ORIGINAL / 'review.json')
unfiltered = [x['path'] for x in prior_review['workflows'] if x['kind'] == 'unfiltered_pr']
assert len(unfiltered) == 5
report = {
    'schema': 'chain-sole-plan-final-baseline-readonly-review-v1',
    'source': {'repository': 'TrillionniumFoundation/Trillionnium-Chain', 'ref': BRANCH,
               'commit': HEAD, 'tree': TREE, 'parents': [BASE],
               'initial_final_ref_equal': True,
               'final_observed_time_utc': '2026-11-06 00:46:08 UTC'},
    'complete_tree': {'truncated': False, 'entries': 11591, 'blobs': 10400,
                      'raw_response': desc(R / 'tree.raw.json')},
    'delta': {'base': BASE, 'commits': 1, 'files': compare['files'],
              'reviewed_source_changes': [], 'canonical_doc_changes': []},
    'catalog': {'paths': verified, 'count': 49, 'unchanged': 49,
                'workflow_count': 19, 'complete_workflow_set_unchanged': True,
                'entry_model_control_count': 30,
                'historical_failed_read_not_a_source_pin': excluded_error_records},
    'sole_plan': desc(target),
    'trigger_scope': {'eligible_original_pr_workflows': unfiltered,
                      'same_as_prior_review': True,
                      'statement': 'Five original unfiltered workflows remain eligible for a single canonical-doc PR; existing deterministic model-mechanism fixture computation remains. The scoped hosted SmolLM owner is still gated by its exact push branch and intent paths. This is not zero CI, zero model logic, an audit of all external automation, or authorization of a new learning trial.'},
    'publication_conditions': {'base_branch': BRANCH, 'reviewed_head_lease': HEAD,
                               'entire_stacked_pr_diff_must_be': [DOC],
                               'do_not_target_main': True,
                               'append_to_these_exact_current_bytes': True,
                               'refresh_and_reconcile_if_head_advances': True,
                               'unresolved_markers_must_not_be_committed': True},
    'historical_reviews': [desc(PRIOR / 'review.json'), desc(ORIGINAL / 'review.json')],
    'local_assembly_history': 'Two local review assembly attempts stopped at AssertionError before source/review writes. First, a historical failed-read placeholder was incorrectly counted as a source pin; the corrected verifier explicitly records and excludes it. Second, this verifier incorrectly assumed every retained regular source was nonexecutable; existing executable script mode 100755 is now recorded alongside 100644, and the complete unchanged-path comparison still binds mode continuity. Neither correction changes current or retained sources, tests, or qualification gates. See assembly-first-failure.json and assembly-second-failure.json.',
    'actions': {'github_read_only_calls': 6, 'git_writes': 0, 'pr_creation': 0,
                'workflow_dispatch': 0, 'native': 0, 'learning': 0,
                'desktop_or_bulk_reads': 0},
    'scope': 'Current source/trigger continuity only; the five added evidence files are not granted native or qualification credit by this review.'}
(R / 'review.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
files = [desc(p) for p in sorted(R.rglob('*')) if p.is_file() and p.name != 'delivery-manifest.json']
manifest = {'schema': 'chain-sole-plan-final-baseline-delivery-v1',
            'review': desc(R / 'review.json'), 'files': files,
            'file_count': len(files), 'total_bytes': sum(x['bytes'] for x in files),
            'source_commit': HEAD, 'source_tree': TREE, 'read_only': True}
(R / 'delivery-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'review': desc(R / 'review.json'), 'manifest': desc(R / 'delivery-manifest.json'),
                  'plan': desc(target), 'unchanged_catalog': 49, 'unchanged_workflows': 19}))
