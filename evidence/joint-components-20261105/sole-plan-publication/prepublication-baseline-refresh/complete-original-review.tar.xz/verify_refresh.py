"""Verify the retained final prepublication Git reads; no network or Git write."""
from pathlib import Path
import hashlib
import json

W = Path('/workspace/scratch/93bfcfe29fc8')
R = Path(__file__).resolve().parent
P = W / 'pq_recovery/chain-sole-plan-final-refresh'
BASE = 'e40564bc32d311cb95a284c2bf3cc2a50de551d9'
HEAD = '502fb53cb120e85f8c33a7b362883c2ffc10d24b'
TREE = '7ec3724fa3a08547ac2eede6e39588cc825901d1'
BRANCH = 'fix/chain-six-axis-performance-20261103'
DOC = 'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'


def load(p):
    return json.loads(p.read_bytes())


def desc(p):
    raw = p.read_bytes()
    return {'path': str(p.relative_to(W)), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}


def payload(name, plain=False):
    response = load(R / name)
    assert response['isError'] is False
    value = response['structuredContent']
    if 'content' not in value:
        return value
    return value['content'] if plain else json.loads(value['content'])


for n in ['ref.raw.json','ref-after.raw.json']:
    ref = payload(n)
    assert ref['ref'] == 'refs/heads/' + BRANCH
    assert ref['object'] == {'sha':HEAD,'type':'commit',
        'url':'https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/git/commits/' + HEAD}
commit = payload('commit.raw.json')
assert commit['sha'] == HEAD and commit['tree']['sha'] == TREE
assert [p['sha'] for p in commit['parents']] == [BASE]
comparison = payload('compare.raw.json')
assert comparison['base'] == comparison['base_commit']['sha'] == comparison['merge_base_commit']['sha'] == BASE
assert comparison['head'] == HEAD and comparison['status'] == 'ahead' and comparison['behind_by'] == 0
assert comparison['ahead_by'] == comparison['total_commits'] == 1
assert comparison['too_large'] in (None,False) and len(comparison['files']) == 11
assert all(x['status']=='added' and x['filename'].startswith('evidence/workspace-default-targets-20261106/')
           for x in comparison['files'])
tree = payload('tree.raw.json')
assert tree['sha'] == TREE and tree['truncated'] is False and len(tree['tree']) == 11603
blobs = {x['path']:x for x in tree['tree'] if x['type']=='blob'}
assert len(blobs) == 10411
prior = load(P / 'review.json')
assert desc(P / 'review.json')['sha256'] == '1c202d306af6bbdde8990e6c00d728181e5cadba0de6906cf2448354ffe8c903'
assert prior['source']['commit'] == BASE and len(prior['catalog']['paths']) == 49
catalog = []
for item in prior['catalog']['paths']:
    current = blobs[item['path']]
    assert (current['sha'],current['size'],current['mode']) == (item['git_blob'],item['bytes'],item['mode'])
    catalog.append({**item,'unchanged_from_last_review':True})
workflows = {p for p in blobs if p.startswith('.github/workflows/')}
assert workflows == {r['path'] for r in catalog if r['path'].startswith('.github/workflows/')}
assert len(workflows) == 19
changed = {r['filename'] for r in comparison['files']}
assert not changed.intersection(r['path'] for r in catalog) and DOC not in changed
doc = payload('sole-plan.raw.json',plain=True).encode('utf-8')
assert doc == (P / 'source' / DOC).read_bytes()
assert len(doc) == blobs[DOC]['size'] == 552675
assert hashlib.sha256(doc).hexdigest() == '063df6d6047e08addb40d92c01bf85c2ff1386788369bfd7ba1d22e0a421198b'
assert hashlib.sha1(b'blob 552675\0'+doc).hexdigest() == blobs[DOC]['sha'] == '3787d8321ee9f4eb5a0fe5794dcad3f997afecb1'
target = R / 'source' / DOC
target.parent.mkdir(parents=True,exist_ok=True)
target.write_bytes(doc)
review = {
    'schema':'chain-canonical-plan-prepublication-refresh-v1',
    'source':{'repository':'TrillionniumFoundation/Trillionnium-Chain','branch':BRANCH,
              'commit':HEAD,'tree':TREE,'parents':[BASE],
              'first_observed_utc':'2026-11-06 01:19:06 UTC',
              'last_observed_utc':'2026-11-06 01:19:52 UTC','observed_ref_stable':True},
    'delta':{'base':BASE,'commits':1,'files':comparison['files'],
             'only_evidence_added':True,'new_trigger_training_or_canonical_document_changes':False},
    'complete_tree':{'entries':11603,'blobs':10411,'truncated':False,
                     'raw_response':desc(R/'tree.raw.json')},
    'catalog':{'reviewed_paths':49,'unchanged_paths':49,'paths':catalog,
               'complete_workflow_count':19,'complete_workflow_set_unchanged':True},
    'canonical_plan':desc(target),
    'trigger_boundary':prior['trigger_scope'],
    'prior_review':desc(P/'review.json'),
    'publication_conditions':{'base_branch':BRANCH,'reviewed_head_lease':HEAD,
                              'entire_stacked_pr_diff_must_be':[DOC],
                              'append_to_exact_current_bytes':True,
                              'do_not_target_main':True,
                              'root_must_still_check_final_CAS':True,
                              'new_head_requires_reconciliation':True,
                              'unresolved_publication_markers_not_approved':True},
    'scope':'Source/trigger continuity only. The 11 added evidence files receive no native, learning, runtime or qualification credit from this refresh. Five original unfiltered CI workflows remain eligible for the strictly one-document stacked PR, as in the prior review.',
    'actions':{'sequential_Git_read_calls':6,'max_concurrent_Git_reads':1,
               'git_writes':0,'PR_creation':0,'CI_execution':0,'native':0,'learning':0,
               'desktop_or_old_binary_downloads':0}}
(R/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[desc(p) for p in sorted(R.rglob('*')) if p.is_file() and p.name!='delivery-manifest.json']
manifest={'schema':'chain-canonical-plan-prepublication-delivery-v1','review':desc(R/'review.json'),
          'file_count':len(files),'total_bytes':sum(x['bytes'] for x in files),'files':files,
          'current_head':HEAD,'current_tree':TREE,'canonical_plan':desc(target),'read_only':True}
(R/'delivery-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'review':desc(R/'review.json'),'manifest':desc(R/'delivery-manifest.json'),
                  'canonical_plan':desc(target),'unchanged_paths':49,'unchanged_workflows':19}))
