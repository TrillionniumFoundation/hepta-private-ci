# Root observation diagnostics: four-file unexecuted candidate

This candidate completes the repository bindings for the two Rust diagnostic changes reviewed in `../e6_initial_a_unavailable_review/`. The base is exact source `9dfded9cecc74e39a19bccd14b9de9dc46c02c63`, tree `d07a8a95a2f0921387446063a1a51661cbd62df7`. The previous 75-member review and candidate1 remain byte-for-byte unchanged.

The full changed source set is exactly four files: `authority_host_service.rs`, `authority_host_peer.rs`, `CALLERS.toml`, and the existing `.github/blob-size-allowlist.txt`. The two Rust files are copied unchanged from candidate1. CALLERS changes one occurrence of the private `exchange_inner` call literal in protected row 630, zero based. All 1164 boundary records, the order of all 908 protected records and all other root data remain. Protected row 555 and the other 907 protected records are identical. Duplicate paths are not collapsed. The allowlist changes only the exact SHA256 of CALLERS; its existing format is hash-bound, with the corresponding exact byte length also recorded in [SOURCE_BINDINGS.json](SOURCE_BINDINGS.json).

The [complete diff](SOURCE.diff) and [ordered policy readback](POLICY_MIGRATION.json) are static material. Rust formatting, compile, lint, source gates, native tests, whole parent, cold D, FinalUse, model and training execution are all zero for this candidate. No new source commit or host owner has been created. Reuse original peer, deadline and Root controls if this candidate is later adopted; no mirrored assertion-only test is introduced here.

## Behavior and budget scope

All original authority, input length, peer lifetime, deadline, handler and response checks stay in their original sequence and execute once. The request and response objects are unchanged. The exact original error is returned. The new local phase writes and handler-failed bit affect diagnostics only; they are not authority or a new retry state. A normal frame still has no diagnostic I/O. Clean first-byte EOF remains `Ok(false)`.

On an error, the contracts code executes its original `shutdown(Shutdown::Both)` before emitting a fixed label. Service classification happens after `channel.exchange` has returned, so no handler log delays that original stream fencing. Diagnostic write errors are discarded without replacing the original transport error. The same original timeout and absolute session end are used; no added time or success interpretation is granted.

Static phase lines do not correlate simultaneous failing lanes. That limitation is retained explicitly; a separately frozen candidate may add an anonymous local thread tag. This candidate is not a repair or a proof of the runtime cause of NoUpdate11.
