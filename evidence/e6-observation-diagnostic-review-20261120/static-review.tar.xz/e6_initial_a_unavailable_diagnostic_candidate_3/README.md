# Root observation diagnostics with local thread correlation

This is a new, unexecuted four-file candidate based on exact source `9dfded9cecc74e39a19bccd14b9de9dc46c02c63`. Candidate1 and candidate2 remain frozen and unchanged. The complete [SOURCE.diff](SOURCE.diff), [source bindings](SOURCE_BINDINGS.json), and incremental [thread-label diff](THREAD_CORRELATION_DELTA.diff) identify all new bytes.

## Why the extra field is necessary

Root serves fixed lanes in parallel standard threads. With fixed stage text alone, two concurrent failures can interleave their contract and service messages. Neighboring lines would not reliably identify which exchange stage belonged to the observation lane. This is an ambiguity in the proposed diagnostics; it is not evidence that concurrent failures caused NoUpdate11.

Candidate3 adds only `std::thread::current().id()` formatted with its standard Debug representation to the contract phase and service classification lines. `channel.exchange`, its synchronous handler, the original stream shutdown, and the enclosing service error inspection execute on the same lane thread. Their thread tags can therefore be correlated within the same original process log even if another lane's lines interleave.

The tag is the runtime's opaque process-local thread identity. It is not an OS owner pidfd, principal, agent, run, nonce, key or permission. It is not compared across processes or used for validation. No global counter or new correlation registry is introduced. No timestamp or clock sampling is added. The label and the typed standard-library thread identifier are independent of request or response contents.

## Preserved behavior and scope

The contract records a fixed local phase through the original frame operations. On error it first executes the existing `shutdown(Shutdown::Both)`, then emits the phase plus local thread tag, and returns the exact original error. The service handler only records a local failure bit; service logging occurs after the channel has already returned. A constructor failure logs only after `from_stream` returns and releases its owned failed stream. Diagnostic write failures cannot replace the original transport error.

Original request/response bounds, once-only handler invocation, all pre/post owner checks, deadline and absolute lifetime, refusal semantics, and `Ok(false)` for clean first-byte EOF are preserved. A successful frame performs no diagnostic I/O or clock read. Local phase assignments remain a small instrumentation cost; no measured performance equivalence is asserted. The refresh task's abort and the existing runtime drain are unchanged.

All public APIs and wire formats remain unchanged. The private diagnostic reference is a static string instead of static bytes solely for formatting the additional thread field. CALLERS and the blob allowlist are byte-for-byte identical to candidate2: 1164 boundary records and 908 ordered protected records remain; only the already declared row 630 private-call literal differs from 9df, while row 555 and the other 907 protected rows remain unchanged. [The retained policy readback](POLICY_MIGRATION_FROM_CANDIDATE2.json) still applies exactly to those unchanged policy bytes.

Formatting, compile, lint, source gates, native cases, whole parent, cold D, FinalUse, model and training executions are all zero for candidate3. No host operation, deployment or Git mutation was performed. Reuse original peer, deadline and Root controls if the candidate is adopted; no new assertion-only test is introduced. This remains an observability candidate, not a root-cause finding or a repair qualification.
