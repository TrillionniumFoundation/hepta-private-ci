# Existing controls for the Root observation diagnostic candidate

This is a read-only execution plan. All sources are pinned to `9dfded9cecc74e39a19bccd14b9de9dc46c02c63`; no test list command, formatting, build, lint, source gate, native test, host call, model or download was executed. The diagnostic candidate's final formatted source remains a separate future binding. Existing test bytes are not modified.

## Scope and complete names

[TESTS.json](TESTS.json) contains every complete Rust test name, source line, ignored/child status, credential requirement and original case limit. Names are derived from the exact module declarations, not inferred from filenames. [SOURCE_PINS.json](SOURCE_PINS.json) binds 19 source files, including module seams, fixtures, Cargo manifest, original just wrapper and nextest configuration.

| Group | Original top-level cases | Full namespace | Execution identity |
|---|---:|---|---|
| Direct peer framing | 11 | `authority_host_issuer_transport::peer::tests::…` | Linux, current ordinary UID; real socket pair and self pidfd. Not ignored. |
| Direct durable deadline | 3 | `authority_host_issuer_transport::peer::deadline_tests::…` | Same; not ignored. |
| Related owner lifecycle | 4 | `authority_host_store::tests::issuer_tests::transport_tests::channel_tests::…` | Ordinary test UID, real local filesystem, pidfd and subprocess. A private fixture does not claim production Root custody. |
| Related service validation | 3 | `authority_host_service::tests::…` | No UID0 requirement; original JSON bounds/decoding and lease validation. |
| Existing three-lane Root qualification | 1 | `authority_host_service::tests::root::root_data_service_three_lanes_use_original_wire_key_and_dedicated_peer` | Ignored; requires UID0, the real protected bind and its matching source, `/run`, and a credential-dropped UID/GID60001 client. |

The 14 peer/deadline cases are the direct new diagnostic source's existing framing controls. The other groups are separately identified related controls; they are not silently added to a selected owner. None of these groups is renamed as, added into, or substituted for the original 47 components.

Two ignored entries are internal subprocess entry points, not additional parent cases: `authority_host_store::tests::issuer_tests::transport_tests::channel_tests::inherited_channel_process_child` and `authority_host_service::tests::root::protected_service_client`. The original parents invoke them with their required environment. The supplied parent filters exclude both entries. Do not select all ignored tests.

## Original limits, unchanged

The peer fixture uses a 100 ms frame timeout and a three-second session. Its existing negative controls clamp absolute end to 80 or 40 ms, sleep 200 or 70 ms to cross an original limit, check that attempts cannot extend the original end, and reject invalid/truncated/oversized or late frames without a retry. The exact values are retained per case in TESTS.json.

The deadline fixture uses a 500 ms frame timeout and a three-second session. One case clamps to 300 ms and verifies that exact deadline reaches the durable handler. Another clamps to 60 ms, deliberately finishes after that same deadline, and requires no response and no second handler. The third refuses a declared 33-byte request against the original 32-byte bound before invoking its handler.

The related owner-exit test uses the original actual process and an inherited descriptor held by a `/usr/bin/sleep 3` descendant. The original parent requires `PeerDenied` within one second after owner exit while proving that the descendant still holds the socket. Original barriers and waits remain 15 seconds for connection, five seconds for readiness/child stop/descendant completion, with a 100 ms trigger. The fixture's default frame/session are five/30 seconds, with shorter limits in its other original cases.

The ignored Root service case has its own existing component profile: a 10-second frame timeout, 20-second service lifetime, built-in client socket read/write limits of 10 seconds, 15-second connect limit, five-second credential transition and a 500 ms observed-feed assertion. These values are not the ordinary A product's 500 ms frame budget. Its baseline lease is 60 seconds; optional existing expiry variants use a two-second lease and three-second sleep. The plan does not enable or redesign those variants.

The exact repository nextest local profile inherits `30s × 2` as its watchdog; no selected case-specific override matches these names. Repository default retry is one. The proposed command explicitly supplies `--retries 0` because this ongoing task requires no automatic replay. That does not change a product deadline or the watchdog. The outer owner's total wall budget is deliberately null until the actual execution owner freezes it; this plan does not invent a new budget or claim current host configuration has been observed.

## Minimal original commands, not run

The root `justfile` selects `codex-rs` and `NEXTEST_PROFILE=local`, then uses the original `scripts/run-nextest.py`. That wrapper forwards `--locked` and `--offline` to both Cargo metadata and nextest. Use it, not direct `cargo test`.

The compact direct-group filter is:

```sh
just test -p codex-hepta-contracts --lib --locked --offline --retries 0 --test-threads 1 -E 'test(/^authority_host_issuer_transport::peer::(tests|deadline_tests)::/)'
```

For a frozen owner, prefer the complete equality-filter argv in [COMMANDS.json](COMMANDS.json), which explicitly enumerates all 14 expected direct names. The separate filter files also enumerate the four lifecycle parents, three service cases and the one ignored Root parent. The latter command uses `--run-ignored only` with the exact single parent equality filter. It requires the original real fixture environment; it is not a command that can safely be run with guessed directories.

[EXECUTION_PRECONDITIONS.json](EXECUTION_PRECONDITIONS.json) records missing host observation, final-source binding and owner budget. It also fixes the scope of the no-model statement: the selected direct cases use only local byte buffers, Unix sockets, procfs/pidfds, clocks and files; the three service unit cases only encode/decode JSON and compare explicit lease values. The Root baseline uses its original built-in local client, with external-client, writer/checkpoint/consumer and expiry overrides absent. An arbitrary externally supplied client binary is outside this claim. No model generation or model download is called by these selected paths. Offline missing dependencies must fail instead of being converted into a download plan.

## Coverage limits

These are existing behavioral controls, not new mirror tests for log text. They cover request/response bounds, malformed and truncated replies, hard deadlines, no retry, same-pinned-owner lifecycle, and existing service refusals. They do not by themselves prove the cause of NoUpdate11, every possible kernel I/O error, or thread-tag correlation under a deliberately injected simultaneous-lane failure. They also do not add a dedicated clean-EOF test that the original peer file does not contain. The source review preserves that existing EOF branch; any execution report must state only the cases actually selected and run.
