"""Preserve exact 9df Initial observation failure and ELF; compile/lint the reviewed diagnostics."""
import base64
import lzma
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import time
import traceback

BASE = Path('/home/qq/work/hepta-e6-first-error-20261120-2e9b')
SRC = BASE / 'source'
TARGET = BASE / 'native-target'
OLD = Path('/home/qq/work/hepta-e6-operation-scope-20261118-2e9b')
OUT = BASE / 'initial-observation-diagnostic-compile-project-fix-1'
PARENT = '9dfded9cecc74e39a19bccd14b9de9dc46c02c63'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=SRC).decode().strip()

def inventory():
    raw = subprocess.check_output(['git', 'ls-files', '-z'], cwd=SRC).split(b'\0')
    raw += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=SRC).split(b'\0')
    rows = []
    for entry in sorted({entry for entry in raw if entry}):
        name = os.fsdecode(entry)
        path = SRC / name
        data = os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes()
        rows.append(dict(path=name, kind='symlink' if path.is_symlink() else 'regular',
                         mode=path.lstat().st_mode & 0o7777, bytes=len(data),
                         sha256=hashlib.sha256(data).hexdigest()))
    encoded = (json.dumps(rows, sort_keys=True, separators=(',', ':')) + '\n').encode()
    return rows, hashlib.sha256(encoded).hexdigest()

def command(label, argv, env, timeout):
    started = time.monotonic()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    with (OUT / (label + '.stdout')).open('xb') as stdout, (OUT / (label + '.stderr')).open('xb') as stderr:
        child = subprocess.run(argv, cwd=SRC / 'codex-rs', env=env,
                               stdout=stdout, stderr=stderr, timeout=timeout)
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    return dict(argv=argv, exit_code=child.returncode, wall_seconds=time.monotonic()-started,
                child_user_cpu_seconds=after.ru_utime-before.ru_utime,
                child_system_cpu_seconds=after.ru_stime-before.ru_stime,
                child_max_rss_kib=after.ru_maxrss,
                stdout_sha256=sha(OUT / (label + '.stdout')),
                stderr_sha256=sha(OUT / (label + '.stderr')))

assert os.getuid() == os.geteuid() == 1000
meta = json.loads(lzma.decompress(base64.b64decode(''.join(sys.argv[1:]), validate=True)))
assert meta['candidate_manifest_sha256'] == '7a67866e38b803371a40bed1eeaa9bb92569f747042396551a241c4639abc8ae'
assert meta['source_parent'] == PARENT
locks = []
for path in [BASE / 'native-component-owner.lock', TARGET / '.hepta-root-native-owner.lock']:
    lock = path.open('a+b')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    locks.append(lock)
assert not OUT.exists()
OUT.mkdir()
started = time.monotonic()
result = dict(status='preflight', successful=False, source_parent=PARENT,
              started_at_ns=str(time.time_ns()), native_cases=0, model_calls=0,
              original_parent_runs=0, automatic_retry=False, original_deadlines_changed=False,
              root_read_budget=64, original_failed_parent_retained=True)
try:
    assert git('rev-parse', 'HEAD') == PARENT and not git('status', '--porcelain', '--untracked-files=all')
    archive = BASE / 'completion-namespace-evidence-1/RESULT.json'
    assert sha(archive) == '37905ee3e7bc42f8279cae789e89efb12de5d2f7df7c3f86c03e5817860e369e'
    archived = json.loads(archive.read_text())
    assert archived['successful'] and archived['original_files_unchanged']
    assert archived['source'] == PARENT and archived['original_files'] == 791
    assert archived['archive_sha256'] == '9d6848aa4145952dbd7b889a76b1f41f67de659ab90c045006c8585c43670341'
    assert sha(BASE / 'completion-namespace-evidence-1/original-evidence.tar.xz') == archived['archive_sha256']
    prior = BASE / 'complete-noupdate-11/result.json'
    assert sha(prior) == '69432bd4a092f2cf9b6060fef652fd615df8400f11fe952a98773c292975ef95'
    previous = json.loads(prior.read_text())
    assert previous['status'] == 'completed' and not previous['successful']
    assert not previous['complete_native_NoUpdate'] and previous['root_lane_mechanism_passed']
    assert previous['root_completion_components_passed']
    assert [row['passed'] for row in previous['root_completion_components']] == [True, True]
    assert previous['ordinary-post-a-no-update']['command_exit_code'] != 0
    assert sha(prior.parent / 'ordinary-post-a-no-update.xml') == '9a7b8aa0fec80a7ab71bf33bb3ce8418527f7b3cf8ff749320cb34e7a0473a93'
    assert previous['compiler_inputs_unchanged']
    assert previous['mount_cleanup_successful'] and previous['source_unchanged'] and previous['tracked_bytes_unchanged']
    assert previous['source'] == PARENT
    pipeline = BASE / 'namespace-fixture-native-pipeline-1/RESULT.json'
    assert sha(pipeline) == '32c18112c50dace10230484eb49194290b89dbaaab013c1778ba75b53bed60a0'
    pipeline_result = json.loads(pipeline.read_text())
    assert pipeline_result['status'] == 'stopped' and not pipeline_result['successful']
    assert len(pipeline_result['stages']) == 7 and all(row['successful'] for row in pipeline_result['stages'][:6])
    before, digest = inventory()
    assert digest == 'e3eb350ec62306da04dfa8e6aec5592a48d8962912204b15d17047f48920405e'
    save(OUT / 'SOURCE_FILES_BEFORE.json', before)
    (OUT / 'RETAINED_ROOT_COMPONENT_RESULT.json').write_bytes(prior.read_bytes())
    (OUT / 'RETAINED_PIPELINE_RESULT.json').write_bytes(pipeline.read_bytes())
    retained = OUT / 'retained-original-component'
    shutil.copytree(BASE / 'complete-noupdate-11', retained, symlinks=True)
    retained_rows = []
    for source in sorted((BASE / 'complete-noupdate-11').rglob('*')):
        if source.is_file():
            target = retained / source.relative_to(BASE / 'complete-noupdate-11')
            assert not source.is_symlink() and not target.is_symlink()
            assert sha(source) == sha(target)
            retained_rows.append(dict(path=str(source.relative_to(BASE / 'complete-noupdate-11')),
                                      bytes=source.stat().st_size, sha256=sha(source)))
    save(OUT / 'RETAINED_COMPONENT_FILES.json', retained_rows)
    native_meta = BASE / 'complete-noupdate-11/actual-native-executable.json'
    assert sha(native_meta) == 'a2f886ecbb7b5140f26d9dffa07c49b5b381eef39c35d4c144def9f9a4fe916a'
    elf = json.loads(native_meta.read_text())
    path = Path(elf['path'])
    st = path.lstat()
    assert path.resolve().is_relative_to(TARGET.resolve()) and not path.is_symlink()
    assert (st.st_dev, st.st_ino, st.st_size, st.st_mode & 0o7777, st.st_nlink) == (elf['device'], elf['inode'], elf['bytes'], 0o555, 1)
    assert sha(path) == elf['sha256']
    with (TARGET / 'debug/.cargo-lock').open('rb') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(lock, fcntl.LOCK_UN)
    held = OUT / 'retained-9df-agentd-test-binary'
    assert not held.exists()
    path.rename(held)
    kept = held.stat()
    assert (kept.st_dev, kept.st_ino, kept.st_size, kept.st_mode & 0o7777) == (st.st_dev, st.st_ino, st.st_size, 0o555)
    assert sha(held) == elf['sha256']
    result['retained_prior_native_elf'] = dict(original_path=str(path), retained_path=str(held),
        sha256=elf['sha256'], bytes=elf['bytes'], device=elf['device'], inode=elf['inode'],
        mode='0555', original_bytes_and_mode_unchanged=True)
    save(OUT / 'INPUT.json', meta)
    (OUT / 'runner.py').write_text(meta['runner_code'])
    assert sha(OUT / 'runner.py') == meta['runner_sha256']
    files = meta['files']
    assert set(files) == {'.github/blob-size-allowlist.txt', 'CALLERS.toml',
                          'codex-rs/hepta-agentd/src/authority_host_service.rs',
                          'codex-rs/hepta-contracts/src/authority_host_peer.rs'}
    new_paths = sorted(name for name, row in files.items() if row['new'])
    assert new_paths == []
    # Validate every input before changing any candidate file. The immutable
    # source and old executed ELF were already preserved above.
    for name, row in files.items():
        assert '..' not in Path(name).parts and not Path(name).is_absolute()
        raw = row['text'].encode()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        target = SRC / name
        if row['new']:
            assert row['before_sha256'] is None and not target.exists()
        else:
            assert target.is_file() and not target.is_symlink()
            assert sha(target) == row['before_sha256']
            prior_file = OUT / 'before' / name
            prior_file.parent.mkdir(parents=True, exist_ok=True)
            prior_file.write_bytes(target.read_bytes())
    for name, row in files.items():
        target = SRC / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(row['text'].encode())
    assert sha(SRC / 'AGENTS.md') == 'c3f80e8386eb170b00af1e21de40d770c4941e464915687e728e2d14a7e79480'
    assert sha(SRC / 'justfile') == '74f869224eba12fc4212b043428e7f5b35b551d26f5b06161c25d8aca525f124'
    assert 'fix *args:\n    cargo clippy --fix --tests --allow-dirty {args}' in (SRC / 'justfile').read_text()
    for name in ['AGENTS.md', 'justfile']:
        (OUT / name).write_bytes((SRC / name).read_bytes())
    env = dict(os.environ)
    original_path = Path('/home/qq/hepta-learn-ff41-tools/env.json')
    assert sha(original_path) == 'c8ddd27960aa7078144c8e827713e28af4293c7e71a3ba0fba9f35225bbbd91e'
    original = json.loads(original_path.read_text())
    for name in ['PATH', 'LIBCLANG_PATH', 'BINDGEN_EXTRA_CLANG_ARGS', 'RUSTUP_TOOLCHAIN',
                 'RUSTY_V8_ARCHIVE', 'RUSTY_V8_SRC_BINDING_PATH', 'RUSTFLAGS', 'LD_LIBRARY_PATH',
                 'CARGO_HOME', 'RUSTUP_HOME']:
        if name in original:
            env[name] = original[name]
    for name in list(env):
        if name.startswith('CARGO_PROFILE_') or name.startswith('CARGO_BIN_EXE_'):
            del env[name]
    env.update(RUSTUP_TOOLCHAIN='1.96.0', CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
               CARGO_TARGET_DIR=str(TARGET), CARGO_NET_OFFLINE='true',
               PYTHONDONTWRITEBYTECODE='1', GIT_TERMINAL_PROMPT='0')
    env['PATH'] = str(OLD / 'tooling/bin') + ':/home/qq/.cargo/bin:' + env.get('PATH', '/usr/bin:/bin')
    for name in ['GIT_TRACE', 'GIT_CURL_VERBOSE', 'GIT_TRACE_CURL']:
        env.pop(name, None)
    result.update(status='format', retained_component_result_sha256=sha(prior),
                  source_before_sha256=digest, runner_sha256=meta['runner_sha256'],
                  changed_paths=sorted(files), new_paths=new_paths, product_sources_unchanged=False,
                  candidate_scope='Failure-only phase diagnostics; execution qualification remains pending.',
                  original_refusal_policy_and_case_assertions_retained=True,
                  original_environment_sha256=sha(original_path), cargo_build_jobs=2)
    result['format'] = command('fmt', ['just', 'fmt'], env, 300)
    assert result['format']['exit_code'] == 0
    refined, refined_digest = inventory()
    before_map = {row['path']: row for row in before}
    delta = sorted(row['path'] for row in refined if row != before_map.get(row['path']))
    assert delta == sorted(files)
    assert sorted(git('diff', '--name-only').splitlines()) == sorted(set(files) - set(new_paths))
    assert sorted(git('ls-files', '--others', '--exclude-standard').splitlines()) == new_paths
    assert sha(SRC / 'scripts/verify_hepta_callers.py') == '1c2dadc1d631b4004a50c857cd41acd2e6827f775f2efdbd3cbb0d4a47781896'
    assert sha(SRC / 'scripts/hepta_typed_callers.py') == 'ff7a60b43b5954a6afea4671d78417b0eb65c3bbc997008bde2d8aad0cb4ab44'
    save(OUT / 'SOURCE_FILES_BEFORE_COMPILE.json', refined)
    result.update(status='compiling', source_before_compile_sha256=refined_digest,
                  only_refinement_paths=sorted(files), source_files=len(refined))
    save(OUT / 'RESULT.json', result)
    print(json.dumps({'status': 'compiling-reviewed-initial-observation-diagnostics', 'native_cases': 0}), flush=True)
    result['compile'] = command('compile', ['cargo', 'nextest', 'list', '--locked', '--offline',
        '-p', 'codex-hepta-agentd', '-p', 'codex-hepta-contracts',
        '--lib', '--list-type', 'binaries-only', '--message-format', 'json'], env, 1800)
    assert result['compile']['exit_code'] == 0
    listed = json.loads((OUT / 'compile.stdout').read_text())
    binaries = list(listed['rust-binaries'].values())
    assert len(binaries) == 2
    assert {item['binary-id'] for item in binaries} == {'codex-hepta-agentd', 'codex-hepta-contracts'}
    after_compile, after_compile_digest = inventory()
    assert refined == after_compile
    result.update(status='original-project-justfix', source_unchanged_during_compile=True,
                  source_after_compile_sha256=after_compile_digest)
    save(OUT / 'RESULT.json', result)
    print(json.dumps({'status': 'required-original-project-justfix', 'native_cases': 0}), flush=True)
    result['justfix'] = command('justfix', ['just', 'fix', '--locked', '--offline',
        '-p', 'codex-hepta-agentd', '-p', 'codex-hepta-contracts'], env, 1800)
    after_lint, after_lint_digest = inventory()
    refined_map = {row['path']: row for row in refined}
    lint_delta = [row['path'] for row in after_lint if row != refined_map.get(row['path'])]
    result.update(status='completed', successful=result['justfix']['exit_code'] == 0 and refined == after_lint,
                  lint_changed_paths=lint_delta, source_unchanged_during_lint=refined == after_lint,
                  compiled_bytes_remain_current=refined == after_lint,
                  source_after_lint_sha256=after_lint_digest)
except BaseException as error:
    result.update(status='failed', successful=False, error=repr(error))
    (OUT / 'ERROR.txt').write_text(traceback.format_exc())
finally:
    after, digest = inventory()
    save(OUT / 'SOURCE_FILES_AFTER.json', after)
    formatted = []
    for name, row in meta['files'].items():
        actual = SRC / name
        if actual.is_file():
            target = OUT / 'candidate-formatted' / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(actual.read_bytes())
            formatted.append(dict(path=name, bytes=actual.stat().st_size, sha256=sha(actual)))
    save(OUT / 'CANDIDATE_MANIFEST_FORMATTED.json', formatted)
    (OUT / 'SOURCE.diff').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=SRC))
    result.update(source_after_sha256=digest, finished_at_ns=str(time.time_ns()),
                  owner_wall_seconds=time.monotonic()-started,
                  native_cases=0, model_calls=0, original_parent_runs=0)
    save(OUT / 'RESULT.json', result)
    for lock in reversed(locks):
        lock.close()
    print(json.dumps({k:result[k] for k in ['status','successful','source_parent','source_after_sha256','owner_wall_seconds','native_cases']},), flush=True)
raise SystemExit(0 if result['successful'] else 1)
