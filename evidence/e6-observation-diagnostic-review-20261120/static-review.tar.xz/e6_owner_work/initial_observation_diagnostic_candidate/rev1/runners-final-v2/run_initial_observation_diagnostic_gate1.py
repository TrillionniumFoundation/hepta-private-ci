"""Rebind original53 modules, retain all prior432 targets and add affected diagnostics callers before the unchanged full CLI."""
import base64
import contextlib
import fcntl
import hashlib
import importlib
import io
import json
import lzma
import os
from pathlib import Path
import re
import resource
import subprocess
import sys
import time
import tomllib
import traceback
import unittest

BASE = Path('/home/qq/work/hepta-e6-first-error-20261120-2e9b')
ROOT = BASE / 'source'
OLD = Path('/home/qq/work/hepta-e6-operation-scope-20261118-2e9b')
OUT = BASE / 'initial-observation-diagnostic-source-probe-1'
PARENT = '9dfded9cecc74e39a19bccd14b9de9dc46c02c63'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()

def inventory():
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0')
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT).split(b'\0')
    rows = []
    for raw_name in sorted({raw for raw in tracked + untracked if raw}):
        name = os.fsdecode(raw_name)
        path = ROOT / name
        raw = os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes()
        rows.append({'path': name, 'kind': 'symlink' if path.is_symlink() else 'regular',
                     'mode': path.lstat().st_mode & 0o7777, 'bytes': len(raw),
                     'sha256': hashlib.sha256(raw).hexdigest()})
    encoded = (json.dumps(rows, sort_keys=True, separators=(',', ':')) + '\n').encode()
    return rows, hashlib.sha256(encoded).hexdigest()

assert os.getuid() == os.geteuid() == 1000
locks = []
for path in [BASE / 'native-component-owner.lock', BASE / 'native-target/.hepta-root-native-owner.lock']:
    lock = path.open('a+b')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    locks.append(lock)
assert not OUT.exists()
OUT.mkdir()
start = time.monotonic()
start_self = resource.getrusage(resource.RUSAGE_SELF)
start_children = resource.getrusage(resource.RUSAGE_CHILDREN)
result = dict(status='preflight', successful=False, source_parent=PARENT, native_cases=0,
              model_calls=0, original_parent_runs=0, automatic_retry=False, started_at_ns=str(time.time_ns()))
before = None
try:
    meta = json.loads(lzma.decompress(base64.b64decode(''.join(sys.argv[1:]), validate=True)))
    assert git('rev-parse', 'HEAD') == PARENT and not git('diff', '--cached', '--name-only')
    previous = BASE / 'initial-observation-diagnostic-compile-project-fix-1/RESULT.json'
    assert sha(previous) == meta['compile_lint_result_sha256']
    compile_result = json.loads(previous.read_text())
    assert compile_result['successful'] and compile_result['compile']['exit_code'] == 0
    assert compile_result['justfix']['exit_code'] == 0 and compile_result['compiled_bytes_remain_current']
    assert compile_result['source_unchanged_during_compile'] and compile_result['source_unchanged_during_lint']
    assert compile_result['native_cases'] == 0 and compile_result['format']['exit_code'] == 0
    assert sorted(git('diff', '--name-only').splitlines()) == sorted(set(compile_result['changed_paths']) - set(compile_result['new_paths']))
    assert sorted(git('ls-files', '--others', '--exclude-standard').splitlines()) == compile_result['new_paths']
    original_rows, original_digest = inventory()
    assert original_digest == compile_result['source_after_sha256']
    save(OUT / 'SOURCE_FILES_AFTER_COMPILE_LINT.json', original_rows)
    save(OUT / 'COMPILE_JUSTFIX_RESULT.json', compile_result)
    before, before_digest = inventory()
    assert before == original_rows and before_digest == original_digest
    failed_gate = BASE / 'ack-source-source-probe-1/RESULT.json'
    assert sha(failed_gate) == '7a796a1e15dcdf1ebb222060d97b83efc4b2c65196606473c6a08f255c18696a'
    retained_failure = json.loads(failed_gate.read_text())
    assert not retained_failure['successful'] and retained_failure['full_caller_proof_exit'] == 125
    save(OUT / 'RETAINED_SOURCE_FAILURE_RESULT.json', retained_failure)
    assert sha(ROOT / 'scripts/verify_hepta_callers.py') == '1c2dadc1d631b4004a50c857cd41acd2e6827f775f2efdbd3cbb0d4a47781896'
    assert sha(ROOT / 'scripts/hepta_typed_callers.py') == 'ff7a60b43b5954a6afea4671d78417b0eb65c3bbc997008bde2d8aad0cb4ab44'
    assert sha(ROOT / 'CALLERS.toml') == meta['caller_sha256']
    (OUT / 'runner.py').write_text(meta['runner_code'])
    assert sha(OUT / 'runner.py') == meta['runner_sha256']
    save(OUT / 'INPUT.json', meta)
    save(OUT / 'SOURCE_FILES_BEFORE.json', before)
    result.update(status='source-tests', original_source_sha256=original_digest,
                  source_before_sha256=before_digest, compile_result_sha256=sha(previous),
                  justfix_result_sha256=sha(previous), runner_sha256=meta['runner_sha256'],
                  verifier_sha256=sha(ROOT / 'scripts/verify_hepta_callers.py'),
                  caller_manifest_sha256=sha(ROOT / 'CALLERS.toml'),
                  changed_paths=compile_result['changed_paths'], new_paths=compile_result['new_paths'],
                  post_compile_rust_bytes_unchanged=True,
                  only_post_compile_delta=[],
                  source_first_is_not_generic_replay_serialization=True,
                  root_component_is_mechanism_only=True)
    save(OUT / 'RESULT.json', result)
    env = dict(os.environ)
    env['PATH'] = str(OLD / 'tooling/bin') + ':/home/qq/.cargo/bin:' + env.get('PATH', '/usr/bin:/bin')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['GIT_TERMINAL_PROMPT'] = '0'
    prior_gate_path = BASE / 'tail-stage-source-probe-1/RESULT.json'
    assert sha(prior_gate_path) == '85d84d242367318b8734388c4a7cee8faf635aacf96900c783407e9c902b1702'
    prior_gate = json.loads(prior_gate_path.read_text())
    assert prior_gate['successful'] and len(prior_gate['modules']) == 50
    original_names = json.loads((BASE / 'tail-stage-source-probe-1/selected-modules.json').read_text())
    assert original_names == prior_gate['modules']
    added_names = ['test_completed_learning_acceptance_source_closure', 'test_completed_learning_context_source_closure', 'test_q24_terminal_acceptance_source_closure']
    assert not set(original_names) & set(added_names)
    names = original_names + added_names
    assert len(names) == 53
    changed = compile_result['changed_paths']
    save(OUT / 'selected-modules.json', names)
    sys.path.insert(0, str(ROOT / 'qa/b4-no-bypass'))
    suite = unittest.TestSuite()
    for name in names:
        suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(name)))
    print(json.dumps({'status': 'source-mutation-tests', 'modules': len(names), 'native_cases': 0}), flush=True)
    qa_start = time.monotonic()
    stream = io.StringIO()
    with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
        qa = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    (OUT / 'source-qa.stdout').write_text(stream.getvalue())
    assert qa.testsRun == 467
    result.update(source_tests_wall_seconds=time.monotonic() - qa_start,
                  source_tests_successful=qa.wasSuccessful(), tests_run=qa.testsRun,
                  modules=names, failures=[{'test': str(test), 'traceback': trace} for test, trace in qa.failures],
                  errors=[{'test': str(test), 'traceback': trace} for test, trace in qa.errors],
                  skipped=[{'test': str(test), 'reason': reason} for test, reason in qa.skipped])
    save(OUT / 'RESULT.json', result)
    print(json.dumps({'status': 'source-tests-finished', 'tests_run': qa.testsRun,
                      'failures': len(qa.failures), 'errors': len(qa.errors), 'skipped': len(qa.skipped)}), flush=True)
    manifest = tomllib.loads((ROOT / 'CALLERS.toml').read_text())
    assert len(manifest['protected_file']) == 908 and len(manifest['boundary']) == 1164
    proof = importlib.import_module('test_historical_ledger_readonly_source_closure').PROOF
    protected_start = time.monotonic()
    protected_failures = []
    for index, row in enumerate(manifest['protected_file']):
        try:
            proof._verify_protected_files(ROOT, {'protected_file': [row]})
        except Exception as error:
            protected_failures.append(dict(index=index, path=row['path'], error=str(error)))
    result['protected_file_sweep'] = dict(rows=len(manifest['protected_file']), passed=not protected_failures,
                                        failures=protected_failures, wall_seconds=time.monotonic() - protected_start)
    save(OUT / 'RESULT.json', result)
    targeted_start = time.monotonic()
    code_index = {path.relative_to(ROOT).as_posix(): proof._strip_cfg_test_items(proof._strip_rust_non_code(path.read_text()))
                  for path in proof._source_files(ROOT, proof._string_tuple(manifest, 'source_roots'))}
    rust = [name for name in changed if name.endswith('.rs')]
    changed_code = '\n'.join(code_index[name] for name in rust)
    prior_targets_path = BASE / 'completion-acceptance-source-probe-1/TARGETED_CALLER_PROOF.json'
    assert sha(prior_targets_path) == meta['prior_targeted_sha256']
    prior_targets = json.loads(prior_targets_path.read_text())
    assert prior_targets['passed'] and prior_targets['expected_boundary_count'] == 432 and len(prior_targets['rows']) == 432
    retained_targets = {row['id'] for row in prior_targets['rows']}
    targets = retained_targets | {row['id'] for row in manifest['boundary'] if row['definition_path'] in rust
               or any(path in rust for path in row['product_callers'])}
    for row in manifest['boundary']:
        name = row['symbol'].rsplit('::', 1)[-1]
        if re.fullmatch(r'[A-Za-z_]\w*', name) and re.search(r'\b' + re.escape(name) + r'\s*\(', changed_code):
            targets.add(row['id'])
    completion_name = 'complete_original_historical_delivery'
    all_completion_hits = []
    for name, code in code_index.items():
        for match in re.finditer(r'\b' + completion_name + r'\s*\(', code):
            all_completion_hits.append({'path': name, 'code_line': code.count('\n', 0, match.start()) + 1,
                                        'ignored_by_original_policy': any(fragment in name for fragment in manifest['ignored_path_fragments']),
                                        'line': code[code.rfind('\n', 0, match.start()) + 1:code.find('\n', match.start()) if '\n' in code[match.start():] else len(code)].strip()})
    save(OUT / 'CLAIM_COMPLETION_CLOSED_CALLS.json', {'method': completion_name, 'all_source_root_hits_after_original_code_stripping': all_completion_hits,
                                                    'boundary': next(row for row in manifest['boundary'] if row['id'] == 'q24_original_delivery_complete_operation'),
                                                    'native_cases': 0})
    boundaries = proof._boundary_rows(manifest)
    proof._verify_privileged_inventory(manifest, boundaries)
    ignored = proof._string_tuple(manifest, 'ignored_path_fragments')
    actual, failures, fields = [], [], {}
    print(json.dumps({'status': 'targeted-original-caller-proof', 'boundaries': len(targets)}), flush=True)
    for boundary in boundaries:
        if boundary.identifier not in targets:
            continue
        try:
            actual.append(proof._verify_boundary(ROOT, boundary, code_index, ignored, fields_by_receiver_type=fields))
        except Exception as error:
            failures.append(dict(id=boundary.identifier, error=str(error), traceback=traceback.format_exc()))
    assert retained_targets <= targets and len(retained_targets) == 432
    assert len(actual) + len(failures) == len(targets)
    save(OUT / 'TARGET_BOUNDARY_IDS.json', dict(retained_prior_432=sorted(retained_targets), all_affected=sorted(targets), added=sorted(targets-retained_targets)))
    targeted = dict(passed=not failures, expected_boundary_count=len(targets), rows=actual, failures=failures,
                    wall_seconds=time.monotonic() - targeted_start)
    save(OUT / 'TARGETED_CALLER_PROOF.json', targeted)
    result['targeted_callers'] = {key: value for key, value in targeted.items() if key != 'rows'}
    save(OUT / 'RESULT.json', result)
    full_start = time.monotonic()
    if qa.wasSuccessful() and not protected_failures and not failures:
        print(json.dumps({'status': 'original-full-caller-cli', 'boundaries': len(boundaries)}), flush=True)
        full = subprocess.run([sys.executable, 'scripts/verify_hepta_callers.py', 'verify'],
                              cwd=ROOT, env=env, capture_output=True, timeout=1800)
    else:
        full = subprocess.CompletedProcess([], 125, b'', b'Original source/caller prerequisite failed; complete caller CLI not started.\n')
    (OUT / 'full-caller-proof.stdout').write_bytes(full.stdout)
    (OUT / 'full-caller-proof.stderr').write_bytes(full.stderr)
    result.update(full_caller_proof_exit=full.returncode, full_caller_proof_wall_seconds=time.monotonic() - full_start,
                  successful=qa.wasSuccessful() and not protected_failures and not failures and full.returncode == 0,
                  status='completed')
except BaseException as error:
    result.update(status='failed', successful=False, error=repr(error))
    (OUT / 'ERROR.txt').write_text(traceback.format_exc())
finally:
    after, after_digest = inventory()
    save(OUT / 'SOURCE_FILES_AFTER.json', after)
    result.update(source_unchanged_during_tests=before is not None and before == after,
                  source_after_sha256=after_digest, finished_at_ns=str(time.time_ns()),
                  owner_wall_seconds=time.monotonic() - start,
                  owner_self_user_cpu_seconds=resource.getrusage(resource.RUSAGE_SELF).ru_utime - start_self.ru_utime,
                  owner_self_system_cpu_seconds=resource.getrusage(resource.RUSAGE_SELF).ru_stime - start_self.ru_stime,
                  owner_child_user_cpu_seconds=resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime - start_children.ru_utime,
                  owner_child_system_cpu_seconds=resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime - start_children.ru_stime,
                  owner_children_max_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
    result['successful'] = result['successful'] and result['source_unchanged_during_tests']
    save(OUT / 'RESULT.json', result)
    for lock in reversed(locks):
        lock.close()
    print(json.dumps({key: value for key, value in result.items()
                      if key not in {'failures', 'errors', 'skipped', 'targeted_callers', 'modules', 'protected_file_sweep'}}), flush=True)
raise SystemExit(0 if result['successful'] else 1)
