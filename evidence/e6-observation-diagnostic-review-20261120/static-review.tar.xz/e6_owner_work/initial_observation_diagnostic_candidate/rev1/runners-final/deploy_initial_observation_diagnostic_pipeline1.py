"""Sequential exact original controls, separate real Root mechanism and one original NoUpdate parent."""
import ast
import copy
import fcntl
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

BASE = Path('/home/qq/work/hepta-e6-first-error-20261120-2e9b')
OUT = BASE / 'initial-observation-diagnostic-native-pipeline-1'
PARENT = '9dfded9cecc74e39a19bccd14b9de9dc46c02c63'
TREE = None
CALLERS = '5533596462eed0fe608e7271b4aab8b76600909268d989dc1d6dc41d6aaf884a'
VERIFIER = '1c2dadc1d631b4004a50c857cd41acd2e6827f775f2efdbd3cbb0d4a47781896'
COMPILE_SHA = None
FRAMING_CASES = ['authority_host_issuer_transport::peer::tests::purpose_bound_rejects_request_before_handler_and_is_permanently_closed', 'authority_host_issuer_transport::peer::tests::oversized_complete_response_emits_no_success_prefix', 'authority_host_issuer_transport::peer::tests::ordinary_complete_denial_can_be_followed_by_a_bounded_response', 'authority_host_issuer_transport::peer::tests::handler_finishing_after_total_deadline_cannot_emit_success', 'authority_host_issuer_transport::peer::tests::pinned_client_preserves_complete_request_response_boundaries', 'authority_host_issuer_transport::peer::tests::pinned_client_invalid_input_emits_nothing_and_closes', 'authority_host_issuer_transport::peer::tests::pinned_client_rejects_truncated_oversized_and_late_replies_without_retry', 'authority_host_issuer_transport::peer::tests::original_absolute_end_expiry_closes_before_any_frame', 'authority_host_issuer_transport::peer::tests::original_absolute_end_can_only_shorten', 'authority_host_issuer_transport::peer::tests::original_absolute_end_limits_the_idle_socket_wait', 'authority_host_issuer_transport::peer::tests::original_absolute_end_crossed_by_handler_emits_no_reply', 'authority_host_issuer_transport::peer::deadline_tests::durable_handler_receives_the_original_clamped_frame_deadline', 'authority_host_issuer_transport::peer::deadline_tests::durable_handler_cannot_emit_success_after_the_shared_frame_deadline', 'authority_host_issuer_transport::peer::deadline_tests::durable_handler_is_not_entered_for_an_invalid_original_frame', 'authority_host_store::tests::issuer_tests::transport_tests::channel_tests::idle_may_exceed_frame_timeout_but_partial_frame_cannot', 'authority_host_store::tests::issuer_tests::transport_tests::channel_tests::a_complete_exchange_does_not_reset_the_hard_lifetime', 'authority_host_store::tests::issuer_tests::transport_tests::channel_tests::arbitrary_descriptor_is_not_an_owner_lifecycle_handle', 'authority_host_store::tests::issuer_tests::transport_tests::channel_tests::owner_exit_ends_idle_session_even_while_descendant_keeps_the_stream_open']
DELIVERY_CASES = [
    'historical_delivery_cancelled_claim_cold_reopen_never_redispatches',
    'historical_delivery_completed_claim_cold_reopen_returns_exact_head',
    'historical_prepared_claim_drop_before_dispatch_cold_reopen_stays_pending',
    'historical_prepared_completion_cold_reopen_returns_exact_key_and_bytes',
    'historical_prepared_completion_full_witness_keeps_exact_append_for_recovery',
]


ACK_CASES = ['feature_socket_ack_timeout_recovers_original_completion_without_redispatch', 'feature_socket_client_drop_keeps_original_source_and_cell_once']
READY_CASES = ['ready_guard_rejects_notification_without_an_installed_original_owner', 'ready_guard_rejects_expiry_and_poison_without_returning_an_owner']
DATA_CASES = ['learning_iteration_checkpoint::completed_tests::completed_reader_accepts_evaluated_and_proposed_terminal_histories', 'learning_iteration_checkpoint::completed_tests::completed_reader_accepts_all_local_decisions_after_selection_and_actual_use', 'learning_iteration_checkpoint::completed_tests::completed_reader_excludes_valid_trainer_no_update_for_this_history_purpose', 'learning_iteration_checkpoint::completed_tests::completed_reader_refuses_every_unfinished_prefix_and_vacant_owner', 'learning_iteration_checkpoint::completed_tests::completed_reader_keeps_original_scope_request_owner_and_outer_record_binding', 'learning_iteration_checkpoint::completed_tests::completed_reader_replays_missing_duplicate_reordered_and_tampered_receipts', 'learning_iteration_checkpoint::completed_tests::completed_reader_requires_the_selected_parent_and_real_next_task_use', 'learning_iteration_checkpoint::completed_tests::completed_reader_rejects_truncated_trailing_and_noncanonical_encoded_payloads', 'authority_host_runtime::session::historical_read::completed_record::tests::original_seven_signature_record_has_identical_wire_bytes_and_digest', 'authority_host_runtime::session::historical_read::completed_record::tests::six_signature_record_is_distinct_and_roundtrips_without_padding', 'authority_host_runtime::session::historical_read::completed_record::tests::signature_digest_data_rejects_other_lengths_or_element_types']
ROOT_COMPLETION_CASES = ['authority_host_service::generation_initial::data_refusal::tests::root_completed_learning_refusal_preserves_bounded_original_identity', 'neuron_generation_current::initial_root_tests::ordinary::cold_acceptance_data::namespace_tests::root_completed_refusal_observer_matches_registered_owner']
ROOT_MECHANISM = 'neuron_generation_current::publication_root_tests::root_broker_late_enrolls_publishes_and_recovers_original_current'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def status(name, **fields):
    result.update(status=name, **fields)
    save(OUT / 'RESULT.json', result)
    print(json.dumps({'status': name, 'source': source, **fields}), flush=True)


def original(path, digest):
    path = BASE / path
    assert sha(path) == digest, str(path)
    return json.loads(path.read_text())


def stage(name, driver, result_path, expected=None, leaf_names=False):
    row = {'name': name, 'driver': str(BASE / driver), 'started_at_ns': str(time.time_ns())}
    result['stages'].append(row)
    status('running-' + name)
    started = time.monotonic()
    completed = subprocess.run([sys.executable, str(BASE / driver)])
    row.update(exit_code=completed.returncode, finished_at_ns=str(time.time_ns()),
               wall_seconds=time.monotonic() - started)
    path = BASE / result_path
    if not path.is_file():
        save(OUT / 'RESULT.json', result)
        raise RuntimeError('Missing terminal stage result: ' + str(path))
    measured = json.loads(path.read_text())
    row.update(result_path=str(path), result_sha256=sha(path),
               successful=measured.get('successful'), source=measured.get('source'))
    assert measured.get('source') == source, row
    if 'root_lane_mechanism_passed' in measured:
        row['root_lane_mechanism_passed'] = measured['root_lane_mechanism_passed']
        row['complete_native_NoUpdate'] = measured.get('complete_native_NoUpdate')
    if expected is not None:
        row['native_cases'] = measured.get('native_cases')
        row['expected_cases'] = expected
        assert measured.get('native_cases') == len(expected), row
        assert measured.get('source_inventory_sha256') == freeze['source_inventory_sha256'], row
        # The original owner validates exact case sets and preserves full JUnit names.
        assert measured.get('all_native_passed') is True, row
        actual = [case['name'].rsplit('::', 1)[-1] if leaf_names else case['name']
                  for case in measured['test_cases']]
        assert sorted(actual) == sorted(expected), (row, actual)
    save(OUT / 'RESULT.json', result)
    assert measured.get('successful') is True and completed.returncode == 0, row
    return row


def deploy(name, protocol, driver):
    protocol_path = BASE / (name + '-PROTOCOL.json')
    deployment_path = BASE / (name + '-DEPLOYMENT.json')
    assert not protocol_path.exists() and not deployment_path.exists(), name
    save(protocol_path, protocol)
    save(deployment_path, {'schema': 'hepta-e6-ack-source-frozen-deployment-v1',
                          'protocol_sha256': sha(protocol_path),
                          'driver_sha256': sha(BASE / driver),
                          'source': source, 'automatic_retry': False})


assert os.getuid() == os.geteuid() == 1000
data = json.loads(sys.argv[1])
source = data['source']
TREE = data['tree']
COMPILE_SHA = data['compile_result_sha256']
assert len(source) == len(TREE) == 40 and len(COMPILE_SHA) == 64
lock = (BASE / 'actual-drain-complete-pipeline.lock').open('a+b')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not OUT.exists(), 'Unique pipeline namespace already used'
OUT.mkdir()
started = time.monotonic()
result = dict(status='preflight', successful=False, source=source, tree=TREE,
              started_at_ns=str(time.time_ns()), automatic_retry=False, stages=[],
              original_read_budget=64, authority_deadlines_changed=False,
              original_executor_mutated=False, original_source_and_failure_inputs_retained=True,
              static_fresh_parent_frames=64, static_budget_is_not_native_result=True,
              actual_root_observe_after_fault_tested=False, fixture_only_delta=False, diagnostic_only_delta=True,
              original_authorization_and_parent_retained=True, root_mechanism_is_full_product_ack=False,
              same_run_replay_serialization=False)
try:
    freeze_path = BASE / 'initial-observation-diagnostic-frozen-source-1/RESULT.json'
    freeze = original(freeze_path, data['source_freeze_result_sha256'])
    assert freeze['successful'] and freeze['source_clean'] and freeze['scanned_inputs_byte_identical']
    assert freeze['source'] == source and freeze['tree'] == TREE and freeze['parent'] == PARENT
    assert freeze['protected_rows'] == 908 and freeze['classified_boundaries'] == 1164
    assert freeze['verifier_unchanged'] and freeze['typed_matcher_unchanged']
    assert freeze['original_blob_policy_tests']['exit_code'] == 0
    assert freeze['exact_source_blob_policy']['exit_code'] == 0
    lint_path = BASE / 'initial-observation-diagnostic-compile-project-fix-1/RESULT.json'
    lint = original(lint_path, data['justfix_result_sha256'])
    assert freeze['project_justfix_passed'] and freeze['project_justfix_result_sha256'] == sha(lint_path)
    assert lint['successful'] and lint['compile']['exit_code'] == 0 and lint['justfix']['exit_code'] == 0
    assert lint['source_unchanged_during_compile'] and lint['source_unchanged_during_lint']
    assert lint['compiled_bytes_remain_current'] and lint['source_after_sha256'] == freeze['source_inventory_sha256']
    save(OUT / 'PROJECT_JUSTFIX_RESULT.json', lint)
    gate = BASE / 'initial-observation-diagnostic-source-probe-1/RESULT.json'
    g = original(gate, data['source_gate_sha256'])
    assert sha(gate) == freeze['source_gate_sha256']
    assert g['successful'] and g['source_tests_successful'] and g['tests_run'] == 467
    assert len(g['modules']) == 53 and g['source_unchanged_during_tests']
    assert g['source_after_sha256'] == freeze['source_inventory_sha256']
    assert g['protected_file_sweep']['passed'] and g['protected_file_sweep']['rows'] == 908
    assert g['targeted_callers']['passed'] and g['targeted_callers']['expected_boundary_count'] == data['targeted_boundary_count']
    assert g['full_caller_proof_exit'] == 0 and not g['failures'] and not g['errors'] and not g['skipped']
    assert sha(BASE / 'source/CALLERS.toml') == CALLERS
    assert sha(BASE / 'source/scripts/verify_hepta_callers.py') == VERIFIER
    compile_path = BASE / 'initial-observation-diagnostic-compile-project-fix-1/RESULT.json'
    c = original(compile_path, COMPILE_SHA)
    assert c['successful'] and c['compile']['exit_code'] == 0 and c['native_cases'] == 0
    assert c['source_unchanged_during_compile'] and c['format']['exit_code'] == 0
    assert c['source_after_sha256'] == freeze['source_inventory_sha256']
    assert g['post_compile_rust_bytes_unchanged'] and g['only_post_compile_delta'] == []
    assert sha(BASE / 'read65-evidence-1/original-evidence.tar.xz') == '2e7f694f7765787170554297bbe175eef82bc9a9c398a984543799691a88cbec'
    last_failed_parent = original('complete-noupdate-11/result.json', '69432bd4a092f2cf9b6060fef652fd615df8400f11fe952a98773c292975ef95')
    assert last_failed_parent['successful'] is False and last_failed_parent['root_lane_mechanism_passed']
    result['retained_last_failed_parent_sha256'] = sha(BASE / 'complete-noupdate-11/result.json')
    result['previous_63_and_67_static_estimates_refuted'] = True
    result['new_ready_positive_is_registered_root_aggregate'] = False
    failed_namespace = original('complete-noupdate-10/result.json',
        'bda9c9b79a193fa65f5cffb56399d0fb1f7437702a77eaa14087419dbba50ade')
    assert failed_namespace['source'] == '527e62b68bdf704efdd8a521c5a95c664bf69172' and not failed_namespace['successful']
    assert failed_namespace['status'] == 'driver_failed'
    assert [row['passed'] for row in failed_namespace['root_completion_components']] == [True, False]
    assert not failed_namespace['complete_native_NoUpdate'] and not failed_namespace['root_lane_mechanism_passed']
    assert 'ordinary-post-a-no-update' not in failed_namespace and 'root-ack-lane-mechanism' not in failed_namespace
    for not_started in ['root-ack-lane-mechanism', 'ordinary-post-a-no-update']:
        assert not_started not in failed_namespace['checks']
        assert all(stage['name'] != not_started + '-execution' for stage in failed_namespace['stages'])
        assert not any(name.startswith(not_started) and name.endswith('.xml')
                       for name in failed_namespace['log_inventory'])
        assert not list((BASE / 'complete-noupdate-10').glob(not_started + '*.xml'))
    result['retained_namespace_component_failure_sha256'] = sha(BASE / 'complete-noupdate-10/result.json')
    result['prior_wrapper10_ordinary_parent_runs'] = 0
    failed_initial = original('complete-noupdate-11/result.json',
        '69432bd4a092f2cf9b6060fef652fd615df8400f11fe952a98773c292975ef95')
    assert failed_initial['source'] == PARENT and not failed_initial['successful']
    assert failed_initial['status'] == 'completed' and failed_initial['root_lane_mechanism_passed']
    assert failed_initial['root_completion_components_passed'] and not failed_initial['complete_native_NoUpdate']
    assert failed_initial['ordinary-post-a-no-update']['command_exit_code'] != 0
    result['retained_initial_observation_parent_failure_sha256'] = sha(BASE / 'complete-noupdate-11/result.json')
    old_failed_parent = original('complete-noupdate-5/result.json', '7e11670e0ea0ca2b09d212aff001395e27c07f71cd69afa21bfae8254629b163')
    assert old_failed_parent['successful'] is False
    for name in ['observation-framing-native-validation-1', 'native-validation-12', 'retirement-native-validation-10',
                 'historical-delivery-native-validation-8', 'feature-ack-native-validation-6', 'ready-slot-native-validation-4', 'completed-data-native-validation-3', 'complete-noupdate-12']:
        assert not (BASE / name).exists(), name
    drivers = data['drivers']
    assert set(drivers) == {'run_observation_framing_native1.py', 'run_native12.py', 'run_retirement_native10.py',
                            'run_delivery_native8.py', 'run_feature_ack_native6.py', 'run_ready_slot_native4.py', 'run_completed_data_native3.py', 'run_noupdate12.py'}
    for name, body in drivers.items():
        ast.parse(body)
        assert not (BASE / name).exists(), name
        (BASE / name).write_text(body)
    save(OUT / 'SOURCE_FREEZE.json', freeze)
    save(OUT / 'SOURCE_GATE_RESULT.json', g)
    save(OUT / 'COMPILE_ONLY_RESULT.json', c)
    result.update(source_freeze_result_sha256=sha(freeze_path),
                  source_inventory_sha256=freeze['source_inventory_sha256'],
                  source_files=freeze['source_files'], full_caller_gate_source=source,
                  current_source_full_caller_cli_executed=True)
    p = original('native-validation-5/PROTOCOL.json',
                 '172c93e6e6f6713a43697248073f403f9b751fbcfdbda5f106488e4c6d28a73d')
    old_retirement = original('retirement-native-validation-3/PROTOCOL.json',
                              '0d3391304c0022b3b22052e1d0cb1968dae5c1530237514b0c51c6166f71a377')
    assert len(p['expected_cases']) == len(set(p['expected_cases'])) == 11
    assert len(old_retirement['expected_cases']) == len(set(old_retirement['expected_cases'])) == 16
    assert p['timeout_seconds'] == old_retirement['timeout_seconds'] == 1800
    assert p['original_read_budget'] == 64 and p['cargo_build_jobs'] == 2
    for key in ['test_import_delta_path', 'test_import_delta_sha256', 'test_import_compile_result_sha256']:
        p.pop(key, None)
    p.update(schema='hepta-e6-ack-source-original-native-v7',
             scope='Exactly the original eleven native scope regressions on this frozen source; prior results are provenance only.',
             source=source, tree=TREE, source_inventory_sha256=freeze['source_inventory_sha256'],
             source_files=freeze['source_files'], source_freeze_result='initial-observation-diagnostic-frozen-source-1/RESULT.json',
             source_freeze_result_sha256=sha(freeze_path), frozen_at_ns=freeze['frozen_at_ns'],
             source_qa_result_path='initial-observation-diagnostic-source-probe-1/RESULT.json', source_qa_result_sha256=sha(gate),
             full_caller_stdout_sha256=sha(gate.parent / 'full-caller-proof.stdout'),
             full_caller_gate_source=source, current_source_full_caller_cli_executed=True,
             compile_result_path='initial-observation-diagnostic-compile-project-fix-1/RESULT.json', compile_result_sha256=COMPILE_SHA,
             prior_protocol_sha256='172c93e6e6f6713a43697248073f403f9b751fbcfdbda5f106488e4c6d28a73d',
             actual_root_observe_after_fault_tested=False)
    p['project_justfix_result_sha256'] = sha(lint_path)
    p['source_validation'] = dict(tests=467, module_count=53, modules=g['modules'],
        protected_rows=908, affected_boundaries=data['targeted_boundary_count'], full_boundaries=1164,
        verifier_sha256=VERIFIER, manifest_sha256=CALLERS,
        reference_source=source, executed_on_current_source=True)
    p['cost_scope'] = ('New component execution on the independently owned reused target. '
        'Compile-only, original eleven, retirement sixteen, delivery five and parent costs remain separate; '
        'overlapping command and owner windows are not additive. No prior native qualification is transferred.')
    deploy('native12', p, 'run_native12.py')
    framing = copy.deepcopy(p)
    framing.update(schema='hepta-e6-original-observation-framing-native-v1',
        scope='Fourteen original peer/deadline and four original owner lifecycle controls, separately counted; no ordinary A/C, complete NoUpdate, or cold qualification.',
        expected_cases=FRAMING_CASES,
        argv=['just', 'test', '--locked', '--offline', '-p', 'codex-hepta-contracts', '--lib',
              '--retries', '0', '--test-threads', '1', '-E',
              ' | '.join('test(=' + case + ')' for case in FRAMING_CASES)],
        required_result='One fresh original nextest XML with exactly eighteen unique complete qualified names, no failure/error/skip, actual exit zero and unchanged frozen inputs. Original case deadlines are unchanged.')
    deploy('observation-framing-native1', framing, 'run_observation_framing_native1.py')

    retirement = copy.deepcopy(p)
    retirement.update(schema='hepta-e6-ack-source-retirement-native-v5',
        scope='Exactly the unchanged sixteen original completion, drain, physical witness failure/recovery and retained capability tests.',
        argv=old_retirement['argv'], expected_cases=old_retirement['expected_cases'],
        required_result=old_retirement['required_result'],
        prior_protocol_sha256='0d3391304c0022b3b22052e1d0cb1968dae5c1530237514b0c51c6166f71a377')
    deploy('retirement-native10', retirement, 'run_retirement_native10.py')
    delivery = copy.deepcopy(p)
    delivery.update(schema='hepta-e6-ack-source-historical-delivery-native-v3',
        scope='Two unchanged real delivery recovery tests and three new real claim/completion/witness-capacity controls; no actual Root observe_after fault injection.',
        expected_cases=DELIVERY_CASES,
        argv=['just', 'test', '--locked', '--offline', '-p', 'codex-hepta-agentd', '--lib', '-E',
              ' | '.join('test(' + case + ')' for case in DELIVERY_CASES)],
        required_result='One new original nextest XML, exactly five unique expected leaf names with full names retained, no failure/error/skip, actual exit zero and unchanged frozen inputs.')
    deploy('delivery-native8', delivery, 'run_delivery_native8.py')
    ack = copy.deepcopy(p)
    ack.update(schema='hepta-e6-original-feature-ack-native-v1',
        scope='Two original signed Feature socket ACK-loss/client-drop cases; the same real C supplies installed-owner Ready and wrong-prefix assertions. FileCAS/slot component, not a registered historical Root aggregate test.',
        expected_cases=ACK_CASES,
        argv=['just', 'test', '--locked', '--offline', '-p', 'codex-hepta-agentd', '--lib', '-E',
              ' | '.join('test(' + case + ')' for case in ACK_CASES)],
        required_result='One fresh original nextest XML with exactly the two expected unique leaf names, no failure/error/skip, exit zero and unchanged frozen inputs.')
    deploy('feature-ack-native6', ack, 'run_feature_ack_native6.py')

    ready = copy.deepcopy(p)
    ready.update(schema='hepta-e6-real-successor-ready-refusal-native-v1',
        scope='Two separately reported new real refusal controls: no installed owner, expiry and actual Mutex poison; no fake Ready positive or registered aggregate proof.',
        expected_cases=READY_CASES,
        argv=['just', 'test', '--locked', '--offline', '-p', 'codex-hepta-agentd', '--lib', '-E',
              ' | '.join('test(' + case + ')' for case in READY_CASES)],
        required_result='One fresh original nextest XML, exactly two unique expected leaf names with full names retained, no failure/error/skip, exit zero and unchanged frozen source.')
    deploy('ready-slot-native4', ready, 'run_ready_slot_native4.py')

    completed_data = copy.deepcopy(p)
    completed_data.update(schema='hepta-e6-completed-data-contract-native-v1',
        scope='Eight completed-checkpoint DATA API cases and three bounded six/seven-signature record codec cases; no real Root signature acceptance, model, or complete NoUpdate qualification.',
        expected_cases=DATA_CASES,
        argv=['just', 'test', '--locked', '--offline', '-p', 'codex-hepta-agentd', '--lib', '-E',
              ' | '.join('test(=' + case + ')' for case in DATA_CASES)],
        required_result='One fresh original nextest XML, exactly eleven unique complete qualified names, no failure/error/skip, exit zero and unchanged exact-source inventory.')
    deploy('completed-data-native3', completed_data, 'run_completed_data_native3.py')

    n = original('complete-noupdate-5/PROTOCOL.json',
                 '1d7797f6d73e09ed3f2fef64b8511839e19ecf7878bc030ca904d1a3e5cec638')
    assert n['root_read_budget'] == 64 and n['expected_parent_cases'] == 1
    assert not n['root_read_budget_changed'] and not n['original_deadlines_changed']
    assert not n['automatic_retry'] and not n['original_test_function_modified']
    for key in ['test_import_delta_path', 'test_import_delta_sha256',
                'prerequisite_result_sha256', 'retirement_native_result_sha256']:
        n.pop(key, None)
    n.update(schema='hepta-e6-ack-source-original-noupdate-v7', source=source, tree=TREE,
        source_inventory_sha256=freeze['source_inventory_sha256'], source_files=freeze['source_files'],
        source_freeze_result_path='initial-observation-diagnostic-frozen-source-1/RESULT.json', source_freeze_result_sha256=sha(freeze_path),
        complete_caller_result_path='initial-observation-diagnostic-source-probe-1/RESULT.json', complete_caller_result_sha256=sha(gate),
        complete_caller_stdout_sha256=sha(gate.parent / 'full-caller-proof.stdout'),
        full_caller_gate_source=source, current_source_full_caller_cli_executed=True,
        run_id='root-e6-completed-acceptance-' + source[:8] + '-noupdate-12',
        prerequisite_result_path='native-validation-12/RESULT.json',
        framing_native_result_path='observation-framing-native-validation-1/RESULT.json', framing_cases=FRAMING_CASES,
        retirement_native_result_path='retirement-native-validation-10/RESULT.json',
        delivery_native_result_path='historical-delivery-native-validation-8/RESULT.json',
        feature_ack_native_result_path='feature-ack-native-validation-6/RESULT.json', feature_ack_cases=ACK_CASES,
        ready_slot_native_result_path='ready-slot-native-validation-4/RESULT.json', ready_slot_cases=READY_CASES,
        completed_data_native_result_path='completed-data-native-validation-3/RESULT.json', completed_data_cases=DATA_CASES,
        root_completion_component_cases=ROOT_COMPLETION_CASES,
        root_mechanism_parent=ROOT_MECHANISM, root_mechanism_original_lifetime_seconds=10,
        root_mechanism_original_frame_milliseconds=500, root_mechanism_original_child_alarm_seconds=60,
        root_mechanism_is_full_product_ack=False, same_run_replay_serialization=False,
        actual_root_observe_after_fault_tested=False, static_whole_fresh_parent_frames=64,
        static_budget_is_not_native_result=True,
        prior_protocol_sha256='1d7797f6d73e09ed3f2fef64b8511839e19ecf7878bc030ca904d1a3e5cec638')
    n['project_justfix_result_sha256'] = sha(lint_path)
    n['source_validation'] = dict(original_tests=467, module_count=53, modules=g['modules'],
        protected_rows=908, affected_boundary_checks=data['targeted_boundary_count'],
        full_original_caller_proof='PASS_HEPTA_CALLER_CLOSED_SET', all_original_boundary_count=1164,
        verifier_sha256=VERIFIER, callers_manifest_sha256=CALLERS,
        reference_source=source, executed_on_current_source=True)
    for path in ['complete-noupdate-11/result.json', 'complete-noupdate-10/result.json', 'complete-noupdate-9/result.json', 'complete-noupdate-8/result.json', 'complete-noupdate-7/result.json', 'complete-noupdate-6/result.json', 'ack-source-source-probe-1/RESULT.json', 'complete-noupdate-5/result.json', 'complete-noupdate-4/result.json', 'read65-candidate-compile-1/RESULT.json',
                 'read65-candidate-compile-2/RESULT.json', 'read65-source-probe-1/RESULT.json',
                 'read65-source-probe-2/RESULT.json']:
        n['retained_prior_failures'].append({'path': str(BASE / path), 'sha256': sha(BASE / path)})
    for previous in n['retained_prior_failures']:
        assert sha(previous['path']) == previous['sha256']
    n['target_provenance'].update(current_source_actual_native11_result_sha256=None,
        current_source_actual_retirement16_result_sha256=None, current_source_actual_delivery5_result_sha256=None)
    n['cost_scope'] = ('Actual exact-source helper/product/library preparation and one unchanged original NoUpdate parent '
        'after eighteen separately counted original peer/owner controls and new exact-source native11, retirement16, delivery5, Feature ACK2, Ready2, eleven separately counted completed DATA cases, two actual Root refusal namespace/bounded-identity components and one separately recorded original Root mechanism parent. All source/compile/native/parent windows and historical failures stay separate.')
    n['diagnostic_scope'] = ('Source-first recovery observes real Missing/Pending without reading the original Root CURRENT lane; '
        'only a complete Source publication enters all original Current/Cell/Source/exact signed admission checks. '
        'Other errors remain errors; no redispatch or extra historical read budget. Original Root try_lock/fence/session semantics are retained, '
        'and failure-only payload-free phase logging follows the original fencing order. '
        'This candidate additionally labels the failing peer frame stage and Observation construct/handler/exchange on an anonymous local thread tag, only after original failure handling; it does not classify the previous Unavailable root cause. '
        'The separately scoped Root mechanism fixtures prove ordering under real lock/session/Source files, not a complete Root Feature ACK or arbitrary concurrent same-run replay serialization. '
        'The original NoUpdate function, 64 historical frames including terminal acceptance, 2s ACK, 500ms Root frame, '
        '240/300/600 deadlines, scorer and original authorization gates remain unchanged.')
    save(BASE / 'noupdate12-PROTOCOL.preflight.json', n)
    status('protocols-deployed', expected_original_native_cases=p['expected_cases'],
           expected_retirement_cases=retirement['expected_cases'], expected_delivery_cases=DELIVERY_CASES,
           expected_feature_ack_cases=ACK_CASES, expected_ready_slot_cases=READY_CASES, expected_framing_cases=FRAMING_CASES, root_mechanism_parent=ROOT_MECHANISM,
           parent_read_budget=64, authority_deadlines_changed=False)
    framed = stage('original-observation-framing18', 'run_observation_framing_native1.py',
                   'observation-framing-native-validation-1/RESULT.json', FRAMING_CASES)
    native = stage('original-native11', 'run_native12.py', 'native-validation-12/RESULT.json', p['expected_cases'])
    retired = stage('retirement-native16', 'run_retirement_native10.py',
                    'retirement-native-validation-10/RESULT.json', retirement['expected_cases'], True)
    delivered = stage('historical-delivery-native5', 'run_delivery_native8.py',
                      'historical-delivery-native-validation-8/RESULT.json', DELIVERY_CASES, True)
    acknowledged = stage('feature-ack-native2', 'run_feature_ack_native6.py',
                         'feature-ack-native-validation-6/RESULT.json', ACK_CASES, True)
    ready_checked = stage('new-ready-refusal-native2', 'run_ready_slot_native4.py',
                          'ready-slot-native-validation-4/RESULT.json', READY_CASES, True)
    completion_checked = stage('new-completed-data-native11', 'run_completed_data_native3.py',
                               'completed-data-native-validation-3/RESULT.json', DATA_CASES)
    n.update(prerequisite_result_sha256=native['result_sha256'],
             framing_native_result_sha256=framed['result_sha256'],
             retirement_native_result_sha256=retired['result_sha256'],
             delivery_native_result_sha256=delivered['result_sha256'],
             feature_ack_native_result_sha256=acknowledged['result_sha256'],
             ready_slot_native_result_sha256=ready_checked['result_sha256'],
             completed_data_native_result_sha256=completion_checked['result_sha256'])
    n['target_provenance'].update(current_source_actual_native11_result_sha256=native['result_sha256'],
        current_source_actual_retirement16_result_sha256=retired['result_sha256'],
        current_source_actual_delivery5_result_sha256=delivered['result_sha256'])
    deploy('noupdate12', n, 'run_noupdate12.py')
    status('native-controls-passed-starting-original-noupdate12',
           framing18_result_sha256=framed['result_sha256'], native11_result_sha256=native['result_sha256'], retirement16_result_sha256=retired['result_sha256'],
           delivery5_result_sha256=delivered['result_sha256'], feature_ack2_result_sha256=acknowledged['result_sha256'], ready_slot2_result_sha256=ready_checked['result_sha256'], completed_data11_result_sha256=completion_checked['result_sha256'],
           noupdate12_protocol_sha256=sha(BASE / 'noupdate12-PROTOCOL.json'))
    stage('original-noupdate12', 'run_noupdate12.py', 'complete-noupdate-12/result.json')
    result['successful'] = True
    status('completed', complete_native_NoUpdate=True, root_completion_components_passed=True, root_lane_mechanism_passed=True, root_mechanism_is_full_product_ack=False)
except BaseException as error:
    (OUT / 'ERROR.txt').write_text(traceback.format_exc())
    status('stopped', error=repr(error))
finally:
    result.update(finished_at_ns=str(time.time_ns()), owner_wall_seconds=time.monotonic() - started)
    save(OUT / 'RESULT.json', result)
    lock.close()
raise SystemExit(0 if result['successful'] else 1)
