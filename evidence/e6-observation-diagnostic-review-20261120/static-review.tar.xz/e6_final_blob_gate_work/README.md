# E6 最终 PR blob 门：本云精确对象准备

状态为 **准备完成；未来 head 的原七项 tests / blob gate 均未执行**。这里保存的本云 Git 库与控制器只支持文件大小门，不授予源码、native、普通父、cold 或 Adopt 的资格。原 9df 宿主 PASS 作为历史出处保留，不能替代未来提交的实测门。

## 已核实的对象与身份

- 原完整 PR 基线：`d83f70f38137a99a86a3afd122199ba9cdae4f79`，tree `ef7a3e525f6b191fbaf73ba99ed95acd958eeb5f`。
- 当前准备锚点：`9dfded9cecc74e39a19bccd14b9de9dc46c02c63`，tree `d07a8a95a2f0921387446063a1a51661cbd62df7`。
- 从 9df 经 527e、bfea 到 d83 的 17 个真实 commit 全部按原始 Git commit 字节重建并重算 OID。d83 的父提交属于本次基线之前，不声称已导入。
- 27 个差异与 policy 路径 tree、219 个 blob、17 个 commit，共 263 个对象。每件同时核对 Git OID、长度、SHA-256；本云新 bare 库逐件 `hash-object` 后 `cat-file` 回读相同。
- 本云真实 Git `diff --name-status --no-renames d83 9df` 得到 **153 路径：66 个修改、87 个新增**。路径和目标长度逐项匹配 9df 原宿主 stdout；这次只运行对象准备与差异核对，未运行原门或 tests。
- 190 个原缺失 blob 直接恢复自已留存本云文件，包含大 CALLERS 和归档分片。其他可复用 blob 来自旧本云 Git 对象库；仅通过只读 Git API 补了 9 个小文本 blob。API、原始归档和历史失败未覆写。

`prepared-shadow/MANIFEST.json` SHA-256 为 `f455cd2fd4b120957fc496a76e5848eb079926412760a90ffd6f32c4caecd6ae`；它列出全部对象的原始字节路径、SHA-256、Git OID 与出处。实际新 bare 库位于 `prepared-shadow/objects.git`。这是**完整差异所需的最小对象闭包**：相等的未修改 subtree 保留其真实 OID，未声称把整个 15,812 文件仓库实体复制到本云；不应对这个最小库运行“整个历史对象都应存在”的 `git fsck` 并把未选入子树误作源文件损坏。

## 原门字节

| 路径 | Git blob | 字节数 | SHA-256 |
|---|---|---:|---|
| `scripts/check_blob_size.py` | `18bc6175c274abaeabe3ef0c32d82627d498bbe7` | 6,551 | `eb7a9eab936b7c7948ed13fbd6d6aca09aa38997c20685a8ee12d72e388d52c3` |
| `scripts/tests/test_blob_size_policy.py` | `71f726876ee37adab36594e53eedb144934da3f1` | 4,951 | `f5017bd436f694f25b3d605fd247d34b47d3b4aa73a2c3c3c9539c39e8348231` |
| `.github/blob-size-allowlist.txt`（9df） | `a7f889fc5ee56581587bebad77a8768928866581` | 15,170 | `636c75d6ed08bfad2a686fbdd966a470bf65d5a90fd4c2cf48a55b41ff01c943` |

原 tests 的七个实际 case 名列于 `prepared-shadow/ORIGINAL_SEVEN_TEST_NAMES.json`。原 freeze runner 对两条命令分别施加 120 秒超时；准备控制器保持相同的每命令 120 秒及 **512,000 字节**上限，无修改 checker 或 tests 的入口。上述 allowlist 原件保持不变；若后续真实 source-only 提交迁移其精确 CALLERS pin，必须提供该新 source 的完整 manifest/API 和独立 allowlist OID/SHA，不能在 evidence 阶段修改。

## 后续调用

### 直接从 9df 添加新证据

最终 head 必须是 9df 的直接子提交，且本阶段只能新增 `evidence/` 内路径，不能覆写已有证据。

```sh
python /workspace/scratch/e9e051ab0825/e6_final_blob_gate_work/final_pr_blob_gate.py \
  --head FINAL_EXACT_HEAD \
  --head-api /absolute/path/RAW_FINAL_GIT_COMMIT_API.json \
  --files-manifest /absolute/path/FINAL_EVIDENCE_FILES.json \
  --output /workspace/scratch/e9e051ab0825/e6_final_blob_gate_work/final-gate-1
```

这只是调用格式；`FINAL_EXACT_HEAD` 尚未存在，本次没有执行该命令。

文件 manifest 是数组，或含 `files` 数组的对象。每行必须含 `path`、`local_path`、`bytes`、`sha256`、`git_blob`（也兼容原清单的 `git_blob_sha1` / `sha`）及可选 `mode`（仅 `100644` / `100755`）。所有路径唯一，原始字节重算后必须与 Git OID 和 SHA-256 同时相符。Git commit API 必须是含真实 `sha/tree/parents/author/committer/message/verification` 的 Git-data 响应；仅含摘要的 create-commit normalized response 不够。已签名提交须额外给 `--head-raw` 的完整原始 commit，不能重造签名。

### 若先存在新 source-only 提交

额外传 `--source-stages /absolute/path/SOURCE_STAGES.json`。它是按父子顺序排列的显式数组；每项示例如下：

```json
[
  {
    "kind": "source",
    "head": "EXACT_SOURCE_HEAD",
    "head_api": "/absolute/path/RAW_SOURCE_GIT_COMMIT_API.json",
    "head_api_sha256": "SHA256_OF_API_FILE",
    "files_manifest": "/absolute/path/COMPLETE_SOURCE_FILES.json",
    "files_manifest_sha256": "SHA256_OF_SOURCE_MANIFEST",
    "allowlist_git_blob": "EXACT_ALLOWLIST_GIT_BLOB",
    "allowlist_sha256": "EXACT_ALLOWLIST_SHA256"
  }
]
```

每个 source 阶段必须为上一锚点的真实直接子提交，完整 manifest 重建的 tree 必须等于 API 里的真实 tree。source 阶段不混入 `evidence/` 文件；最终 evidence commit 必须直接接在最后 source 上。更改 allowlist 时，其路径必须实际列在该 source manifest 中，且新字节必须与给定 OID/SHA 相符；checker 和七项 tests 仍固定为本准备包的原字节。必要时 source 项也可提供 `head_raw` / `head_raw_sha256`。

若未来路径依赖尚未导入的相等祖先 tree 或 before blob，可用 `--extra-objects-manifest` 指明已从原 Git API/本云原件得到的真实对象。数组或 `objects` 数组中的每行必须含 `oid/type/bytes/sha256/local_path`。控制器不会自动获取或改造缺失对象；缺件会在原门前明确失败并保留原件。

## 执行时检查的范围

1. 在新的本云目录初始化新 bare 库；逐对象 SHA、类型、长度与 Git 回读核验。既有对象库只读。
2. 逐 source/evidence 阶段验证实际父提交、完整文件清单、完整 tree、Git OID、原策略身份；不把 source 变更算作 evidence。
3. 对 **d83 → 最终 exact head** 重新执行真实完整 Git 差异，逐路径与所有阶段的净差异核对，禁止删除/类型转换或隐含改动。不会只检查最后证据 commit 的增量。
4. 在新本云临时 fixture 目录运行原七项 tests，检查 exit 0、实际 `Ran 7 tests` 和 `OK`。这些原 controls 会在临时目录建立它们自己的测试 Git refs，不触碰 measured host、已有工作区或远端 Git。
5. 使用最终 source 的既定 allowlist，执行未改动的原 `check_blob_size.py --base d83 --head FINAL --max-bytes 512000`，120 秒。原 stdout 的完整路径数量必须与第 3 步一致。
6. 保留 argv、stdout、stderr、退出、超时、实际耗时、完整对象表和各阶段身份；对 shadow 的 HEAD、refs、index、config，以及全部输入与 policy 字节做前后核对。失败也保留实际状态，不重试、不移动 ref。

准备阶段只做了 Python 语法解析与真实对象/差异检查。未来原 tests/gate 尚未运行；没有新增模型调用、训练、native、宿主进程或外部 Git 变更。完整报告与研究附录仍按 Root 要求冻结。

## 已知准备异常

`API_CAPTURE_FAILURE_1.json` 保留一次只读 API 摘要解析错误：GitHub connector 对 Git blob 返回已解码 UTF-8，初版摘要误作 JSON metadata 解析。实际 source 字节未改；首件保留，两个已完成但未留存的只读响应重新读取，全部九件均以 Git SHA 独立核验。该异常没有执行 tests/gate，也没有触发宿主任务或写远端 Git。
