"""Seal the already collected d83..9df difference closure; execute no gate."""

import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

import prepare_known_objects as source


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
HOST = ROOT / "e6_owner_work/completion_namespace_fixture_candidate/rev2"


def main():
    output = HERE / "prepared-shadow"
    output.mkdir(exist_ok=False)
    began = time.monotonic()
    environment = dict(os.environ, GIT_NO_LAZY_FETCH="1", GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0")
    repository = output / "objects.git"
    child = subprocess.run(["git", "init", "--bare", str(repository)], env=environment, capture_output=True, timeout=15)
    (output / "init.stdout").write_bytes(child.stdout)
    (output / "init.stderr").write_bytes(child.stderr)
    assert child.returncode == 0
    def git(*parts, data=None):
        return subprocess.check_output(["git", "--git-dir", str(repository), *parts], input=data, env=environment, stderr=subprocess.PIPE, timeout=15)

    rows = json.loads((HERE / "OBJECTS.json").read_bytes())
    objects = {row["oid"]: row for row in rows}
    assert len(objects) == len(rows)
    for row in rows:
        raw = Path(row["local_path"]).read_bytes()
        assert len(raw) == row["bytes"] and source.sha(raw) == row["sha256"] and source.oid(row["type"], raw) == row["oid"]
        assert git("hash-object", "-t", row["type"], "-w", "--stdin", data=raw).decode().strip() == row["oid"]
        assert git("cat-file", row["type"], row["oid"]) == raw
    for revision, tree in ((source.BASE, source.BASE_TREE), (source.SOURCE, source.SOURCE_TREE)):
        assert git("rev-parse", revision + "^{tree}").decode().strip() == tree

    ancestry = []
    revision = source.SOURCE
    while True:
        row = objects[revision]
        assert row["type"] == "commit"
        raw = Path(row["local_path"]).read_bytes()
        header = raw.split(b"\n\n", 1)[0].decode().splitlines()
        parents = [line.removeprefix("parent ") for line in header if line.startswith("parent ")]
        ancestry.append({"sha": revision, "tree": header[0].removeprefix("tree "), "parents": parents, "raw_sha256": source.sha(raw)})
        if revision == source.BASE:
            break
        assert len(parents) == 1 and len(ancestry) < 64
        revision = parents[0]
    assert len(ancestry) == 17
    source.save(output / "EXACT_ANCESTRY.json", ancestry)

    expected = json.loads((HERE / "PARTIAL_DIFF.json").read_bytes())
    actual = git("diff", "--name-status", "--no-renames", source.BASE, source.SOURCE).decode().splitlines()
    assert actual == [row["status"] + "\t" + row["path"] for row in expected]
    assert len(expected) == 153 and all(row["status"] in ("A", "M") for row in expected)
    (output / "original-source-full-diff.stdout").write_text("\n".join(actual) + "\n")

    original_stdout = (HOST / "FREEZE_EXACT_BLOB_POLICY.stdout").read_bytes()
    assert source.sha(original_stdout) == "802bf2eacbe5325187747431775eb15c5e958b5a27aeba854de2a82dd78e48a2"
    original_rows = {}
    for line in original_stdout.decode().splitlines()[1:]:
        match = re.fullmatch(r"- (.*): (\d+) bytes \(.*\) \[(binary|non-binary), (ok|allowlisted)\]", line)
        assert match, line
        original_rows[match[1]] = {"bytes": int(match[2]), "kind": match[3], "classification": match[4]}
    assert len(original_rows) == 153
    for row in expected:
        raw = Path(objects[row["after"]["sha"]]["local_path"]).read_bytes()
        assert original_rows[row["path"]]["bytes"] == len(raw)
        row["after"]["bytes"] = len(raw)
        row["after"]["sha256"] = source.sha(raw)
        if row["before"]:
            before = Path(objects[row["before"]["sha"]]["local_path"]).read_bytes()
            row["before"]["bytes"] = len(before)
            row["before"]["sha256"] = source.sha(before)
    source.save(output / "ORIGINAL_FULL_DIFF.json", expected)

    policies = {}
    for path, entry in json.loads((HERE / "POLICY_OBJECTS.json").read_bytes()).items():
        row = objects[entry["sha"]]
        assert git("rev-parse", source.SOURCE + ":" + path).decode().strip() == row["oid"]
        raw = Path(row["local_path"]).read_bytes()
        target = output / "policy" / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        policies[path] = {"git_blob": row["oid"], "sha256": row["sha256"], "bytes": row["bytes"], "mode": entry["mode"], "local_path": str(target)}
    syntax = ast.parse((output / "policy/scripts/tests/test_blob_size_policy.py").read_bytes())
    names = [node.name for item in syntax.body if isinstance(item, ast.ClassDef) for node in item.body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")]
    assert len(names) == 7
    source.save(output / "ORIGINAL_SEVEN_TEST_NAMES.json", names)

    proof = {}
    for name in ("FREEZE_RESULT.json", "FREEZE_EXACT_BLOB_POLICY.stdout", "FREEZE_BLOB_TESTS.stderr", "ROOT_FREEZE_TERMINAL_READBACK.json"):
        raw = (HOST / name).read_bytes()
        target = output / "original-host-proof" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        proof[name] = {"local_path": str(target), "bytes": len(raw), "sha256": source.sha(raw), "original_path": str(HOST / name)}
    host_result = json.loads((HOST / "FREEZE_RESULT.json").read_bytes())
    assert proof["FREEZE_RESULT.json"]["sha256"] == "7a357f31105e61bfa4aad350c7eff11b36cb4809490796ef0390659e9c68e3f2"
    assert host_result["successful"] and host_result["source"] == source.SOURCE
    assert host_result["original_blob_policy_tests"]["exit_code"] == host_result["exact_source_blob_policy"]["exit_code"] == 0
    assert host_result["exact_source_blob_policy"]["argv"][-4:] == ["--max-bytes", "512000", "--allowlist", ".github/blob-size-allowlist.txt"]

    manifest = {
        "schema": "hepta.e6.exact-original-pr-blob-preparation.v1",
        "base": source.BASE,
        "base_tree": source.BASE_TREE,
        "source_anchor": source.SOURCE,
        "source_tree": source.SOURCE_TREE,
        "objects": rows,
        "object_counts": {kind: sum(row["type"] == kind for row in rows) for kind in ("commit", "tree", "blob")},
        "object_bytes": sum(row["bytes"] for row in rows),
        "objects_git": str(repository),
        "original_full_diff": {"local_path": str(output / "ORIGINAL_FULL_DIFF.json"), "sha256": source.sha((output / "ORIGINAL_FULL_DIFF.json").read_bytes()), "paths": 153, "added": 87, "modified": 66},
        "ancestry": {"local_path": str(output / "EXACT_ANCESTRY.json"), "sha256": source.sha((output / "EXACT_ANCESTRY.json").read_bytes()), "commits": 17, "boundary_parent_outside_scope": ancestry[-1]["parents"]},
        "policies": policies,
        "original_test_names": names,
        "original_host_proof": proof,
        "maximum_bytes": 512000,
        "timeout_seconds_per_original_command": 120,
        "scope": "Exact difference closure for original base through 9df, all changed before/after blobs, original policy objects, and complete commit ancestry through the base; equal untouched subtree OIDs are preserved without claiming their full contents are materialized.",
        "preparation_actual_diff_verified": True,
        "original_checker_executed_here": False,
        "original_seven_tests_executed_here": False,
        "future_head_gate_executed": False,
        "future_head_pass_claimed": False,
        "native_experiments": 0,
        "model_calls": 0,
        "remote_objects_or_refs_changed": False,
        "remaining_inputs": ["Future exact source-only stage manifests/API/raw commits, if any; no source mutation may be classified as evidence", "Future exact evidence-only head API/raw commit and all newly changed evidence bytes", "Additional exact ancestor trees/before blobs only if a declared future path needs objects outside this minimum difference closure"],
        "prepared_wall_seconds": time.monotonic() - began,
    }
    source.save(output / "MANIFEST.json", manifest)
    print(json.dumps({"manifest": str(output / "MANIFEST.json"), "sha256": source.sha((output / "MANIFEST.json").read_bytes()), "objects": len(rows), "original_changed_paths": len(expected), "gate_executed": False, "seven_tests_executed": False}))


if __name__ == "__main__":
    main()
