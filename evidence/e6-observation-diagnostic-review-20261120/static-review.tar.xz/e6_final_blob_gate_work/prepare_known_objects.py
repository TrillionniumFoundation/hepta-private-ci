"""Read local retained data to prepare exact E6 Git objects; run no gate.

API acquisition is a separate, read-only connector step. This script only
uses existing local repositories and saved API responses. It does not fetch,
create remote objects, mutate existing repositories, or invoke the checker.
"""

import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess


HERE = Path(__file__).resolve().parent
BASE = "d83f70f38137a99a86a3afd122199ba9cdae4f79"
BASE_TREE = "ef7a3e525f6b191fbaf73ba99ed95acd958eeb5f"
SOURCE = "9dfded9cecc74e39a19bccd14b9de9dc46c02c63"
SOURCE_TREE = "d07a8a95a2f0921387446063a1a51661cbd62df7"
POLICY_PATHS = (
    "scripts/check_blob_size.py",
    "scripts/tests/test_blob_size_policy.py",
    ".github/blob-size-allowlist.txt",
    "AGENTS.md",
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def oid(kind, raw):
    return hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def save(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    path.write_bytes(raw)


def api_record(document):
    if "result" in document:
        document = document["result"]
    if "structuredContent" in document:
        document = document["structuredContent"]
    if isinstance(document.get("content"), str):
        return json.loads(document["content"])
    return document


def tree_bytes(entries):
    rows = []
    for entry in entries:
        name = entry["path"].encode()
        mode = entry["mode"].lstrip("0").encode()
        assert name and b"/" not in name and b"\0" not in name
        assert mode in (b"40000", b"100644", b"100755", b"120000", b"160000")
        rows.append((name, mode, bytes.fromhex(entry["sha"])))
    assert len({row[0] for row in rows}) == len(rows)
    rows.sort(key=lambda row: row[0] + (b"/" if row[1] == b"40000" else b""))
    return b"".join(mode + b" " + name + b"\0" + digest for name, mode, digest in rows)


def parse_tree(raw):
    rows = {}
    cursor = 0
    while cursor < len(raw):
        end = raw.index(b"\0", cursor)
        mode, name = raw[cursor:end].split(b" ", 1)
        digest = raw[end + 1:end + 21]
        assert len(digest) == 20
        text = name.decode()
        assert text not in rows and "/" not in text
        rows[text] = {"path": text, "mode": mode.decode(), "sha": digest.hex(), "type": "tree" if mode == b"40000" else "blob"}
        cursor = end + 21
    assert cursor == len(raw)
    assert tree_bytes(rows.values()) == raw
    return rows


def reconstruct_commit(api):
    verification = api.get("verification", {})
    if verification.get("signature") or verification.get("reason") != "unsigned":
        raise ValueError("exact signed/raw commit bytes required")
    tried = []
    for offset in ("-0500", "+0000", "+0800"):
        lines = ["tree " + api["tree"]["sha"]]
        lines.extend("parent " + parent["sha"] for parent in api["parents"])
        for field in ("author", "committer"):
            person = api[field]
            stamp = int(datetime.datetime.fromisoformat(person["date"].replace("Z", "+00:00")).timestamp())
            lines.append(f"{field} {person['name']} <{person['email']}> {stamp} {offset}")
        payload = ("\n".join(lines) + "\n\n" + api["message"]).encode()
        for suffix in (b"", b"\n"):
            raw = payload + suffix
            actual = oid("commit", raw)
            tried.append({"timezone": offset, "newline_suffix": bool(suffix), "oid": actual})
            if actual == api["sha"]:
                return raw, tried
    raise ValueError("commit serialization does not reproduce exact OID")


def main():
    directory = HERE / "objects"
    directory.mkdir(exist_ok=True)
    imported = {}
    existing = HERE / "OBJECTS.json"
    if existing.exists():
        for row in json.loads(existing.read_bytes()):
            raw = Path(row["local_path"]).read_bytes()
            assert len(raw) == row["bytes"] and sha(raw) == row["sha256"] and oid(row["type"], raw) == row["oid"]
            imported[row["oid"]] = row

    def retain(kind, raw, expected, source):
        assert oid(kind, raw) == expected, (kind, expected)
        path = directory / expected
        if path.exists():
            assert path.read_bytes() == raw
        else:
            path.write_bytes(raw)
        row = imported.setdefault(expected, {"oid": expected, "type": kind, "bytes": len(raw), "sha256": sha(raw), "local_path": str(path), "provenance": []})
        assert row["type"] == kind and row["sha256"] == sha(raw)
        if source not in row["provenance"]:
            row["provenance"].append(source)

    reconstructions = {}
    for path in sorted((HERE / "api").glob("*.json")):
        if path.name.startswith("blob-"):
            document = json.loads(path.read_bytes())
            content = document["result"]["structuredContent"]["content"]
            expected = document["sha"]
            raw = content.encode()
            if oid("blob", raw) != expected:
                api = json.loads(content)
                assert api["encoding"] == "base64" and api["sha"] == expected
                raw = base64.b64decode("".join(api["content"].split()), validate=True)
                assert len(raw) == api["size"]
            retain("blob", raw, expected, {"kind": "exact_git_blob_API_normalized_body", "path": str(path), "sha256": sha(path.read_bytes())})
            continue
        api = api_record(json.loads(path.read_bytes()))
        if path.name.startswith("tree-"):
            assert api["truncated"] is False
            retain("tree", tree_bytes(api["tree"]), api["sha"], {"kind": "nonrecursive_git_tree_API", "path": str(path), "sha256": sha(path.read_bytes())})
        elif path.name.startswith("commit-"):
            raw, attempts = reconstruct_commit(api)
            retain("commit", raw, api["sha"], {"kind": "unsigned_exact_commit_API", "path": str(path), "sha256": sha(path.read_bytes())})
            reconstructions[api["sha"]] = attempts

    inventories = json.loads((HERE / "LOCAL_OBJECT_STORE_INVENTORY.json").read_bytes())["stores"]
    stores = [row["repo"] for row in inventories if row["exit_code"] == 0]
    environment = dict(os.environ, GIT_NO_LAZY_FETCH="1", GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0")
    misses = set()

    def get(kind, digest):
        if digest in imported:
            row = imported[digest]
            assert row["type"] == kind
            return Path(row["local_path"]).read_bytes()
        if (kind, digest) in misses:
            return None
        for repository in stores:
            child = subprocess.run(["git", "--git-dir", repository, "cat-file", kind, digest], env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
            if child.returncode == 0:
                retain(kind, child.stdout, digest, {"kind": "read_only_existing_object_store", "repository": repository})
                return child.stdout
        misses.add((kind, digest))
        return None

    requests = {}
    tree_paths = {}
    def tree(digest, path, side):
        if digest is None:
            return {}
        tree_paths.setdefault(digest, []).append({"path": path, "side": side})
        raw = get("tree", digest)
        if raw is None:
            requests.setdefault(digest, {"type": "tree", "sha": digest, "locations": []})["locations"].append({"path": path, "side": side})
            return None
        return parse_tree(raw)

    changes = []
    def diff(before, after, prefix=""):
        if before == after:
            return
        left = tree(before, prefix, "base")
        right = tree(after, prefix, "source")
        if left is None or right is None:
            return
        for name in sorted(set(left) | set(right)):
            previous, current = left.get(name), right.get(name)
            if previous == current:
                continue
            path = prefix + name
            if (previous and previous["type"] == "tree") or (current and current["type"] == "tree"):
                assert previous is None or previous["type"] == "tree", "tree/file type change must be reviewed"
                assert current is None or current["type"] == "tree", "tree/file type change must be reviewed"
                diff(previous["sha"] if previous else None, current["sha"] if current else None, path + "/")
            else:
                changes.append({"path": path, "status": "A" if previous is None else "D" if current is None else "M", "before": previous, "after": current})

    diff(BASE_TREE, SOURCE_TREE)
    policies = {}
    for path in POLICY_PATHS:
        digest = SOURCE_TREE
        parts = path.split("/")
        for index, name in enumerate(parts):
            entries = tree(digest, "/".join(parts[:index]), "source-policy")
            if entries is None:
                break
            entry = entries[name]
            if index == len(parts) - 1:
                assert entry["type"] == "blob"
                policies[path] = entry
            else:
                assert entry["type"] == "tree"
                digest = entry["sha"]
    blob_needs = {}
    for row in changes:
        for side in ("before", "after"):
            entry = row[side]
            if entry:
                blob_needs.setdefault(entry["sha"], []).append({"path": row["path"], "side": side})
    for path, entry in policies.items():
        blob_needs.setdefault(entry["sha"], []).append({"path": path, "side": "policy"})
    missing_blobs = []
    for digest, locations in blob_needs.items():
        if get("blob", digest) is None:
            missing_blobs.append({"type": "blob", "sha": digest, "locations": locations})
    save(HERE / "OBJECTS.json", sorted(imported.values(), key=lambda row: (row["type"], row["oid"])))
    save(HERE / "COMMIT_RECONSTRUCTIONS.json", reconstructions)
    save(HERE / "TREE_REQUESTS.json", list(requests.values()))
    save(HERE / "TREE_PATHS.json", tree_paths)
    save(HERE / "PARTIAL_DIFF.json", changes)
    save(HERE / "POLICY_OBJECTS.json", policies)
    save(HERE / "MISSING_BLOBS.json", missing_blobs)
    print(json.dumps({"objects": len(imported), "tree_requests": len(requests), "known_changes": len(changes), "missing_blobs": len(missing_blobs), "policy_paths_resolved": len(policies), "gate_executed": False}))


if __name__ == "__main__":
    main()
