"""Recover exact wanted source/evidence blob bytes already retained locally."""

import hashlib
import json
import os
from pathlib import Path

import prepare_known_objects as prepared


def main():
    here = Path(__file__).resolve().parent
    root = here.parent
    objects = json.loads((here / "OBJECTS.json").read_bytes())
    imported = {row["oid"]: row for row in objects}
    needed = {row["sha"]: row for row in json.loads((here / "MISSING_BLOBS.json").read_bytes())}
    names = {Path(location["path"]).name for row in needed.values() for location in row["locations"]}
    sizes = {}
    for path in (here / "api").glob("tree-*.json"):
        api = prepared.api_record(json.loads(path.read_bytes()))
        for row in api["tree"]:
            if row["type"] == "blob" and row["sha"] in needed:
                sizes[row["sha"]] = row["size"]
    wanted_sizes = set(sizes.values())
    assert len(sizes) == len(needed)
    captures = []
    inspected = 0
    def retain(raw, path, description):
        digest = prepared.oid("blob", raw)
        if digest not in needed:
            return
        assert sizes[digest] == len(raw)
        target = here / "objects" / digest
        if target.exists():
            assert target.read_bytes() == raw
        else:
            target.write_bytes(raw)
        source = {"kind": description, "path": str(path), "source_file_sha256": prepared.sha(path.read_bytes())}
        row = imported.setdefault(digest, {"oid": digest, "type": "blob", "bytes": len(raw), "sha256": prepared.sha(raw), "local_path": str(target), "provenance": []})
        if source not in row["provenance"]:
            row["provenance"].append(source)
        captures.append({"oid": digest, "path": str(path), "bytes": len(raw), "sha256": row["sha256"], "kind": description})

    for directory in sorted(root.iterdir()):
        if not directory.is_dir() or not (directory.name.startswith("e6_") or directory.name == "metrics_gate_work") or directory == here:
            continue
        for parent, dirs, files in os.walk(directory):
            dirs[:] = [name for name in dirs if name not in (".git", "objects.git", "__pycache__", "node_modules")]
            for name in files:
                path = Path(parent) / name
                if path.is_symlink():
                    continue
                matches = name in names or any(name.endswith("__" + item) for item in names)
                if matches and path.stat().st_size in wanted_sizes:
                    inspected += 1
                    retain(path.read_bytes(), path, "retained_exact_file")
                elif name.endswith(".json") and name[:-5] in names and path.stat().st_size < 1000000:
                    inspected += 1
                    try:
                        doc = json.loads(path.read_bytes())
                        if "result" in doc:
                            doc = doc["result"]
                        if "structuredContent" in doc:
                            doc = doc["structuredContent"]
                        content = doc.get("content")
                        if isinstance(content, str) and doc.get("encoding") == "utf-8":
                            retain(content.encode(), path, "retained_utf8_file_API")
                    except (ValueError, TypeError, AttributeError):
                        pass
    prepared.save(here / "OBJECTS.json", sorted(imported.values(), key=lambda row: (row["type"], row["oid"])))
    prepared.save(here / "LOCAL_BLOB_RECOVERY.json", {"inspected_candidate_files": inspected, "unique_recovered_blobs": len({row["oid"] for row in captures}), "captures": captures, "new_network_reads": 0, "native_or_model_calls": 0, "source_mutated": False})
    print(json.dumps({"inspected_candidate_files": inspected, "recovered_blobs": len({row["oid"] for row in captures}), "retained_matching_copies": len(captures)}))


if __name__ == "__main__":
    main()
