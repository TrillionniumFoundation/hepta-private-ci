//! The final complete-task purpose belongs to the existing Root session.
//! Protected deployment data fixes both the current recipient and old inputs;
//! it neither opens a legacy learning checkpoint nor freezes a Dataset scope.

use std::io;
use std::io::Write;
use std::os::fd::OwnedFd;
use std::path::Path;
use std::path::PathBuf;
use std::sync::Arc;
use std::sync::Mutex;
use std::sync::atomic::AtomicU8;
use std::sync::atomic::Ordering;
use std::time::Instant;

use codex_hepta_contracts::RootAuthorityDirectory;
use codex_hepta_neuron::CellGenerationOwnerBindingV1;
use serde::Deserialize;

use super::PreparedHostAuthoritySession;
use super::generation_publication::deployment::files::MetadataFile;
use crate::HostAuthorityLearningProfileV1;
use crate::HostAuthorityRegistration;
use crate::HostAuthorityService;
use crate::HostAuthorityServiceConfig;
use crate::RootHistoricalSourceInputsV1;
use crate::authority_host_runtime::RootInitialRunStartFilesV1;
use crate::authority_host_service::generation_initial::cell_retention::RootHistoricalCellInputsV1;
use crate::authority_host_service::generation_initial::historical_source_pin::RootOriginalHistoricalCompleteTaskObservationV1;
use crate::authority_host_service::generation_initial::historical_source_pin::RootOriginalHistoricalTaskReadV1;
use crate::authority_host_service::generation_initial::historical_source_pin::RootRetainedHistoricalCompleteTaskV1;
use crate::authority_host_service::generation_initial::original_root;
use crate::root_historical_task_read_protocol::HistoricalReadOperationV1;
use crate::root_historical_task_read_protocol::HistoricalTaskReadProfileV1;
use crate::root_historical_task_read_protocol::HistoricalTaskReadResponseV1;
use crate::root_historical_task_read_protocol::PURPOSE;
use crate::root_historical_task_read_protocol::SOCKET;
use crate::root_historical_task_read_protocol::WIRE_BOUND;

#[path = "authority_host_completed_checkpoint.rs"]
mod completed_checkpoint;
#[path = "authority_host_completed_deployment.rs"]
mod completed_deployment;
#[path = "authority_host_completed_files.rs"]
mod completed_files;
#[path = "authority_host_completed_journal.rs"]
mod completed_journal;
#[path = "authority_host_completed_learning.rs"]
mod completed_learning;
pub(crate) use completed_learning::OriginalCompletedLearningContextV1;
#[path = "authority_host_completed_observation.rs"]
mod completed_observation;
#[path = "authority_host_completed_provider.rs"]
mod completed_provider;
#[path = "authority_host_completed_record.rs"]
mod completed_record;
#[path = "authority_host_completed_signatures.rs"]
mod completed_signatures;
#[cfg(test)]
pub(crate) use completed_record::RootCompletedLearningAcceptanceDataV1;
#[cfg(test)]
pub(crate) use completed_record::completed_learning_acceptance_owner;
#[path = "authority_host_historical_learning_trust.rs"]
mod learning_trust;
#[path = "authority_host_post_a_learning.rs"]
mod post_a;
#[path = "authority_host_post_a_files.rs"]
mod post_a_files;
#[path = "authority_host_post_a_freeze.rs"]
mod post_a_freeze;
#[path = "authority_host_post_a_provider.rs"]
mod post_a_provider;
#[path = "authority_host_post_a_worker.rs"]
mod post_a_worker;
use crate::root_historical_learning_trust_data::HistoricalLearningTrustResponseV1;
use crate::root_historical_learning_trust_data::TRUST_PURPOSE;
use learning_trust::RootHistoricalLearningTrustV1;
#[path = "authority_host_historical_read_session.rs"]
mod prepared;
#[path = "authority_host_historical_read_runtime.rs"]
mod runtime;
pub(super) use runtime::BoundHistoricalTaskRead;
pub(super) use runtime::serve_optional;

const DEPLOYMENT_PURPOSE: &str = "runtime.learning.historical-task-deployment.v1";
const PREPARED: u8 = 0;
const SEALED: u8 = 1;
const SERVING: u8 = 2;
const STOPPED: u8 = 3;

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct HistoricalTaskDeploymentData {
    schema_version: u32,
    purpose: String,
    initial: HostAuthorityLearningProfileV1,
    target: CellGenerationOwnerBindingV1,
    source_deployment: PathBuf,
    run_start_deployment: PathBuf,
    ledger_deployment: PathBuf,
    learning_trust_deployment: PathBuf,
    #[serde(default)]
    completed_learning_deployment: Option<PathBuf>,
}

pub(super) struct HistoricalTaskReadRuntime {
    metadata: MetadataFile,
    deployment: HistoricalTaskDeploymentData,
    profile: HistoricalTaskReadProfileV1,
    task: RootRetainedHistoricalCompleteTaskV1,
    learning_trust: RootHistoricalLearningTrustV1,
    completed: Option<completed_deployment::CompletedLearningRuntime>,
    post_a: Option<post_a::PostALearningRuntime>,
    post_a_submitter: Mutex<Option<post_a_worker::PostALearningSubmitter>>,
    post_a_worker: Option<post_a_worker::PostALearningWorker>,
    socket: PathBuf,
    phase: AtomicU8,
}

impl HistoricalTaskReadRuntime {
    fn open_original(
        path: &Path,
        service: &HostAuthorityService,
        config: &HostAuthorityServiceConfig,
        registration: &HostAuthorityRegistration,
        owner: &OwnedFd,
    ) -> io::Result<Self> {
        original_root()?;
        let (metadata, bytes) = MetadataFile::open_metadata(path)?;
        let deployment: HistoricalTaskDeploymentData =
            serde_json::from_slice(&bytes).map_err(io::Error::other)?;
        if deployment.schema_version != 1
            || deployment.purpose != DEPLOYMENT_PURPOSE
            || deployment.initial.schema_version != 1
            || deployment.initial.update_scope.is_some()
        {
            return Err(io::Error::other(
                "original unfrozen historical deployment required",
            ));
        }
        deployment.target.digest().map_err(io::Error::other)?;
        let identity = registration.registered_identity.identity()?;
        let (profile, task, learning_trust) = service.with_learning_profile(
            config,
            registration,
            owner,
            &deployment.initial,
            |initial, proof| {
                metadata.require_metadata_unchanged()?;
                let learning_trust = RootHistoricalLearningTrustV1::open_original(
                    service,
                    &deployment.learning_trust_deployment,
                    &initial,
                    &deployment.target,
                )?;
                let mut profile: HistoricalTaskReadProfileV1 = HistoricalTaskReadProfileV1 {
                    purpose: PURPOSE.into(),
                    identity: crate::neuron_generation_process_identity_digest_v1(&identity)
                        .map_err(io::Error::other)?
                        .to_string(),
                    writer: proof,
                    initial: codex_hepta_types::Digest32::of_parts(&[
                        b"hepta.root.historical-task-read.initial.v1\0",
                        deployment.initial.encoded_initial().as_bytes(),
                    ])
                    .to_string(),
                    deployment: metadata.digest().to_string(),
                    learning_trust: learning_trust.pin.clone(),
                    binding: String::new(),
                };
                profile.binding = profile.digest()?;
                profile.require_original_context(
                    &identity,
                    &profile.writer,
                    &deployment.initial,
                )?;
                let task = RootRetainedHistoricalCompleteTaskV1::open_existing(
                    RootAuthorityDirectory::open(&config.state_dir).map_err(io::Error::other)?,
                    deployment.target.clone(),
                    deployment.ledger_deployment.clone(),
                    || {
                        RootHistoricalCellInputsV1::open_original_cell_deployment(
                            &deployment.source_deployment,
                        )
                    },
                )?;
                metadata.require_metadata_unchanged()?;
                RootHistoricalLearningTrustV1::revalidate(&learning_trust, service, &initial)?;
                Ok((profile, task, learning_trust))
            },
        )?;
        let socket = config
            .sockets
            .observation
            .parent()
            .ok_or_else(|| io::Error::other("original Root socket parent missing"))?
            .join(SOCKET);
        metadata.require_metadata_unchanged()?;
        let mut runtime = Self {
            metadata,
            deployment,
            profile,
            task,
            learning_trust,
            completed: None,
            post_a: None,
            post_a_submitter: Mutex::new(None),
            post_a_worker: None,
            socket,
            phase: AtomicU8::new(PREPARED),
        };
        if let Some(path) = &runtime.deployment.completed_learning_deployment {
            runtime.completed = Some(
                completed_deployment::CompletedLearningRuntime::retain_original(
                    path,
                    &runtime,
                    service,
                    config,
                    registration,
                    owner,
                )?,
            );
        }
        Ok(runtime)
    }

    fn observe_complete_task(
        &self,
        service: &HostAuthorityService,
        config: &HostAuthorityServiceConfig,
        registration: &HostAuthorityRegistration,
        owner: &OwnedFd,
        operation: HistoricalReadOperationV1,
        request_id: u64,
        end: Instant,
    ) -> io::Result<Vec<u8>> {
        let trust_requested = match operation {
            HistoricalReadOperationV1::Task => false,
            HistoricalReadOperationV1::LearningTrust => true,
            HistoricalReadOperationV1::PostAFrozenLearning => {
                return self
                    .install_original_frozen_learning(
                        service,
                        config,
                        registration,
                        owner,
                        request_id,
                        end,
                    )
                    .inspect_err(|_| {
                        let _ =
                            io::stderr().write_all(b"root_stage=historical.route_post_a_frozen\n");
                    });
            }
            HistoricalReadOperationV1::AcceptCompletedLearning
            | HistoricalReadOperationV1::CaptureCompletedHistory
            | HistoricalReadOperationV1::ReadCompletedHistory => {
                return self
                    .completed_learning_operation(
                        service,
                        config,
                        registration,
                        owner,
                        operation,
                        request_id,
                        end,
                    )
                    .inspect_err(|_| {
                        let label: &[u8] = if matches!(
                            operation,
                            HistoricalReadOperationV1::AcceptCompletedLearning
                        ) {
                            b"root_stage=historical.route_accept_completed\n"
                        } else if matches!(
                            operation,
                            HistoricalReadOperationV1::CaptureCompletedHistory
                        ) {
                            b"root_stage=historical.route_capture_completed\n"
                        } else {
                            b"root_stage=historical.route_read_completed\n"
                        };
                        let _ = io::stderr().write_all(label);
                    });
            }
        };
        self.task
            .with_original_historical_task(service, end, |read| {
                require_end(end).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.entry_deadline\n"); })?;
                self.metadata.require_metadata_unchanged().inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.entry_metadata\n"); })?;
                let (reply, initial) = service.with_learning_profile(
                    config,
                    registration,
                    owner,
                    &self.deployment.initial,
                    |initial, proof| {
                        let expected = self.profile.require_original_context(
                            &registration.registered_identity.identity().inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.recipient_identity\n"); })?,
                            &proof,
                            &self.deployment.initial,
                        ).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.recipient_profile\n"); })?;
                        if expected != initial || self.phase.load(Ordering::Acquire) != SERVING {
                            return Err(io::Error::other("original historical recipient changed")).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.recipient_state\n"); });
                        }
                        RootHistoricalLearningTrustV1::revalidate(&self.learning_trust, service, &initial).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.trust_before_read\n"); })?;
                        RootOriginalHistoricalTaskReadV1::require_original_target(read, &self.deployment.target).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.target\n"); })?;
                        let observed: RootOriginalHistoricalCompleteTaskObservationV1 = RootOriginalHistoricalTaskReadV1::observe_original_task(
                            read,
                            |identity| {
                                RootHistoricalSourceInputsV1::open_original_source_deployment(
                                    &self.deployment.source_deployment,
                                    identity,
                                ).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.source_deployment\n"); })
                            },
                            || {
                                RootInitialRunStartFilesV1::open_original_deployment(
                                    &self.deployment.run_start_deployment,
                                ).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.run_start_deployment\n"); })
                                .map(Arc::new)
                            },
                        ).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.observe_original_task\n"); })?;
                        let ledger = RootOriginalHistoricalCompleteTaskObservationV1::ledger_read_data(&observed).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.ledger_read_data\n"); })?;
                        RootHistoricalLearningTrustV1::require_original_ledger(&self.learning_trust, &ledger).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.trust_ledger\n"); })?;
                        let data_cut = RootOriginalHistoricalCompleteTaskObservationV1::data_cut_digest(&observed).to_string();
                        let reply = if !trust_requested {
                            serde_json::to_vec(&HistoricalTaskReadResponseV1 {
                                schema: 1,
                                purpose: PURPOSE.into(),
                                request_id,
                                profile: self.profile.binding.clone(),
                                data_cut,
                                ledger,
                                publication: RootOriginalHistoricalCompleteTaskObservationV1::publication_read_data(&observed),
                            })
                        } else {
                            serde_json::to_vec(&HistoricalLearningTrustResponseV1 {
                                schema: 1,
                                purpose: TRUST_PURPOSE.into(),
                                request_id,
                                profile: self.profile.binding.clone(),
                                data_cut,
                                pin: self.learning_trust.pin.clone(),
                                payload: RootHistoricalLearningTrustV1::read_original_payload(&self.learning_trust, service, &initial, &ledger).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.trust_payload\n"); })?,
                            })
                        }.map_err(io::Error::other).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.reply_encode\n"); })?;
                        if !trust_requested && request_id == 1 {
                            let _ = writeln!(io::stderr(),
                                "root_measure=historical.task_reply bytes={} bound={}",
                                reply.len(), operation.response_bound());
                        }
                        if reply.is_empty() || reply.len() > operation.response_bound() {
                            return Err(io::Error::other(
                                "complete historical reply exceeds bound",
                            )).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.reply_bound\n"); });
                        }
                        RootHistoricalLearningTrustV1::revalidate(&self.learning_trust, service, &initial).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.trust_after_reply\n"); })?;
                        require_end(end).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.reply_deadline\n"); })?;
                        Ok((reply, initial))
                    },
                ).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.recipient_service\n"); })?;
                // Actual current recipient postchecks returned before the complete
                // task's final physical rereads and all refusal Ready transitions.
                self.metadata.require_metadata_unchanged().inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.exit_metadata\n"); })?;
                RootHistoricalLearningTrustV1::revalidate(&self.learning_trust, service, &initial).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.exit_trust\n"); })?;
                require_end(end).inspect_err(|_| { let _ = io::stderr().write_all(b"root_stage=historical.exit_deadline\n"); })?;
                Ok(reply)
            }).inspect_err(|_| {
                let label: &[u8] = if trust_requested {
                    b"root_stage=historical.route_learning_trust\n"
                } else {
                    b"root_stage=historical.route_task\n"
                };
                let _ = io::stderr().write_all(label);
            })
    }
}

fn require_end(end: Instant) -> io::Result<()> {
    original_root()?;
    if Instant::now() >= end {
        return Err(io::Error::new(
            io::ErrorKind::TimedOut,
            "original historical read expired",
        ));
    }
    Ok(())
}
