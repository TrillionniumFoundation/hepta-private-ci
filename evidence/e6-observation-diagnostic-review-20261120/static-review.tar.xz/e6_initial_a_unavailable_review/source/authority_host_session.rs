//! Capture and serve using one retained set of the original Root objects.

use super::*;

#[path = "root_agentd_filesystem.rs"]
mod filesystem;

#[path = "root_desktop_startup.rs"]
mod desktop_startup;

#[path = "root_notes_startup.rs"]
mod notes_startup;
pub use notes_startup::RootNotesPolicyPredecessor;

#[path = "authority_host_session_material.rs"]
mod material;

#[path = "authority_host_learning_session.rs"]
mod learning;

#[path = "authority_host_historical_read.rs"]
mod historical_read;
pub(crate) use historical_read::OriginalCompletedLearningContextV1;
#[cfg(test)]
pub(crate) use historical_read::RootCompletedLearningAcceptanceDataV1;
#[cfg(test)]
pub(crate) use historical_read::completed_learning_acceptance_owner;

#[path = "authority_host_q24_model_session.rs"]
mod q24_model;

#[path = "authority_host_q24_evaluation.rs"]
mod q24_evaluation;
pub(crate) use q24_evaluation::BoundRootIndependentBEvaluationV1;
pub(crate) use q24_evaluation::OriginalRootBEvaluationBorrowV1;
pub(crate) use q24_evaluation::OriginalRootIndependentBEvaluationFilesV1;
pub(crate) use q24_evaluation::PreparedRootIndependentBEvaluationV1;
pub use q24_evaluation::RootIndependentBEvaluationOfferV1;
pub(crate) use q24_evaluation::RootIndependentBEvaluationRuntimeV1;
pub use q24_evaluation::RootIndependentBSourceOfferV1;
pub(crate) use q24_evaluation::serve_optional_until as serve_independent_b_until;

#[path = "authority_host_generation_initial_session.rs"]
mod generation_initial;
pub use generation_initial::RootGenerationInitialDeploymentFilesV1;
pub use generation_initial::RootGenerationInitialDeploymentSessionV1;
pub use generation_initial::RootGenerationInitialDeploymentV1;
pub use generation_initial::RootGenerationInitialEnrollmentCapabilityV1;
pub use generation_initial::RootGenerationInitialRegistrationV1;
pub use generation_initial::RootHistoricalSourceCaptureCapabilityV1;
pub use generation_initial::RootHistoricalSourceCaptureReceiptV1;
pub(crate) use generation_initial::RootInitialRunStartFilesV1;

#[path = "authority_host_generation_publication_session.rs"]
mod generation_publication;
pub(crate) use generation_publication::PreparedPublicationData;
pub(crate) use generation_publication::PublicationInputData;
pub use generation_publication::RootGenerationPublicationDeploymentSessionV1;
pub use generation_publication::RootGenerationPublicationDeploymentV1;
pub use generation_publication::RootGenerationPublicationEnrollmentCapabilityV1;
pub use generation_publication::RootGenerationPublicationRegistrationV1;
pub(crate) use generation_publication::RootOriginalSuccessorFilesV1;
pub(crate) use generation_publication::RootSuccessorTaskCutV1;
pub(crate) use generation_publication::publication_data;

/// One Root session's immutable registration, retained actual process handle
/// and original service. This wrapper is not Clone and creates no additional
/// issuer, clock, checkpoint or consumer owner during bootstrap capture.
pub struct PreparedHostAuthoritySession {
    config: HostAuthorityServiceConfig,
    registration: HostAuthorityRegistration,
    owner_pidfd: OwnedFd,
    service: HostAuthorityService,
    fresh_filesystem: bool,
    root_admin: Option<crate::authority_host_admin::RootAdminRuntime>,
    learning: Option<crate::authority_host_service::RegisteredHostLearningCheckpointV1>,
    publication: Option<generation_publication::PublicationRuntime>,
    initial_publication: Option<generation_initial::InitialRuntime>,
    historical_read: Option<historical_read::HistoricalTaskReadRuntime>,
}

impl PreparedHostAuthoritySession {
    /// Mint one non-owning administration route into this SAME service. The
    /// capability stays inactive until original fixed listeners are ready and
    /// is invalidated before this original serve scope can end.
    pub fn enable_root_admin(&mut self) -> io::Result<crate::RootAdminCapability> {
        if self.root_admin.is_some() {
            return Err(io::Error::other("original Root admin already enabled"));
        }
        verify_pinned_process(
            &self.registration,
            self.config.peer_uid,
            self.config.peer_gid,
            &self.owner_pidfd,
            Instant::now() + std::time::Duration::from_millis(self.config.timeout_ms),
        )?;
        self.service.validate_admin_registration()?;
        let (runtime, capability) = crate::authority_host_admin::RootAdminRuntime::mint(
            std::time::Duration::from_millis(self.config.timeout_ms.min(1_000)),
        )?;
        self.service.enable_original_notes_observations()?;
        self.root_admin = Some(runtime);
        Ok(capability)
    }

    /// Explicit Root startup from the already authorized original config and
    /// actual child registration. Open the original authority owners first,
    /// then prepare/publish the fresh DB under those same owners. No issuer,
    /// policy, lease or Registry generation is created by this entry point.
    /// Existing/partial data is an error, never an automatic recovery fallback.
    pub async fn prepare_fresh_from_registered(
        config_file: &Path,
        registration_file: &Path,
        owner_pidfd: OwnedFd,
    ) -> io::Result<Self> {
        let config: HostAuthorityServiceConfig = read_root_json(config_file)?;
        let registration: HostAuthorityRegistration = read_root_json(registration_file)?;
        let service = open_registered_writer(&config, &registration, &owner_pidfd)?;
        let fresh =
            crate::FreshHostCognitiveState::prepare(&registration.registered_identity).await?;
        let service =
            service.initialize_fresh_heads(&config, &registration, &owner_pidfd, fresh)?;
        Ok(Self {
            config,
            registration,
            owner_pidfd,
            service,
            fresh_filesystem: true,
            root_admin: None,
            learning: None,
            publication: None,
            initial_publication: None,
            historical_read: None,
        })
    }

    /// Publish an explicitly prepared fresh original DB and fresh protected
    /// heads, retaining the same service for subsequent capture and serving.
    /// Issuer, clock, writer lease and proof must already be registered by the
    /// original administrative factories. This is never a recovery fallback.
    pub fn initialize_fresh(
        config_file: &Path,
        registration_file: &Path,
        owner_pidfd: OwnedFd,
        fresh: crate::FreshHostCognitiveState,
    ) -> io::Result<Self> {
        let config = read_root_json(config_file)?;
        let registration = read_root_json(registration_file)?;
        let service = open_registered_writer(&config, &registration, &owner_pidfd)?
            .initialize_fresh_heads(&config, &registration, &owner_pidfd, fresh)?;
        Ok(Self {
            config,
            registration,
            owner_pidfd,
            service,
            fresh_filesystem: true,
            root_admin: None,
            learning: None,
            publication: None,
            initial_publication: None,
            historical_read: None,
        })
    }

    /// Open existing Root state once through the original service factory.
    /// No file, lease, signer, consumer or checkpoint is initialized here.
    pub fn open(
        config_file: &Path,
        registration_file: &Path,
        owner_pidfd: OwnedFd,
    ) -> io::Result<Self> {
        let config = read_root_json(config_file)?;
        let registration = read_root_json(registration_file)?;
        let service = open_registered_service(&config, &registration, &owner_pidfd)?;
        Ok(Self {
            config,
            registration,
            owner_pidfd,
            service,
            fresh_filesystem: false,
            root_admin: None,
            learning: None,
            publication: None,
            initial_publication: None,
            historical_read: None,
        })
    }

    /// Release only the freshly published Agent's original data directories
    /// to its dedicated UID/GID. Its original Registry, lifecycle, release
    /// state and writer-lock path remain exclusively writable by Root. This
    /// first composition is restricted to one Agent; it is never a recovery
    /// fallback, recursive chown of an existing workspace or authority reset.
    /// The returned fixed parent is used by `seal_bootstrap` for the original
    /// two local FinalUse journals. Existing/partial consumer state is refused.
    pub fn handoff_fresh_agent_filesystem(mut self) -> io::Result<(Self, std::path::PathBuf)> {
        if !self.fresh_filesystem {
            return Err(io::Error::other(
                "filesystem handoff requires this session's original fresh publication",
            ));
        }
        let end = Instant::now() + std::time::Duration::from_secs(30);
        verify_pinned_process(
            &self.registration,
            self.config.peer_uid,
            self.config.peer_gid,
            &self.owner_pidfd,
            end,
        )?;
        let identity = self.registration.registered_identity.identity()?;
        let parent = filesystem::handoff_fresh_filesystem(
            &identity,
            self.config.peer_uid,
            self.config.peer_gid,
            &self.config.state_dir,
        )?;
        verify_pinned_process(
            &self.registration,
            self.config.peer_uid,
            self.config.peer_gid,
            &self.owner_pidfd,
            end,
        )?;
        self.fresh_filesystem = false;
        Ok((self, parent))
    }

    /// Read and seal this same service's original heads, then retain it for
    /// serving. The paths/config/proof/owner cannot be replaced at this call.
    /// The returned descriptor is an observation; live owner checks remain
    /// mandatory when the daemon connects to the five original lanes.
    pub fn seal_bootstrap(&self, consumer_state_root: &Path) -> io::Result<File> {
        self.service.seal_registered_bootstrap(
            &self.config,
            &self.registration,
            &self.owner_pidfd,
            consumer_state_root,
        )
    }

    /// Trusted Root obtains this target from the original Session's Reserved
    /// capability before forwarding that same offer/endpoint to Agentd. This
    /// is a one-time startup composition, never a peer JSON registration path.
    /// The exact pre-existing issuer policy must match; no policy, issuer or
    /// lease Registry is opened or created by this method.
    pub fn with_registered_notes_from_session(
        mut self,
        target: &codex_hepta_memory::NotesTargetIdentity,
        lifetime_ms: u64,
    ) -> io::Result<Self> {
        let end = Instant::now() + std::time::Duration::from_secs(30);
        verify_pinned_process(
            &self.registration,
            self.config.peer_uid,
            self.config.peer_gid,
            &self.owner_pidfd,
            end,
        )?;
        self.service = self
            .service
            .with_notes_from_original_session(target, lifetime_ms)?;
        verify_pinned_process(
            &self.registration,
            self.config.peer_uid,
            self.config.peer_gid,
            &self.owner_pidfd,
            end,
        )?;
        Ok(self)
    }

    /// Consume this retained service and serve its original fixed lanes.
    pub fn serve(self) -> io::Result<()> {
        self.serve_selected(/*text_ui*/ None, || Ok(()))
    }

    /// Release an already prepared trusted handoff only after all original
    /// listeners, including any registered learning lane, have been bound.
    pub fn serve_with_ready(self, ready: impl FnOnce() -> io::Result<()>) -> io::Result<()> {
        self.serve_selected(/*text_ui*/ None, ready)
    }

    /// Serve this same retained session and the original native text lane.
    /// The original profile, peer, socket and text registration checks apply.
    pub fn serve_with_text(self, text_file: &Path, ui_pidfd: OwnedFd) -> io::Result<()> {
        self.serve_selected(Some((text_file, ui_pidfd)), || Ok(()))
    }

    pub fn serve_with_text_and_ready(
        self,
        text_file: &Path,
        ui_pidfd: OwnedFd,
        ready: impl FnOnce() -> io::Result<()>,
    ) -> io::Result<()> {
        self.serve_selected(Some((text_file, ui_pidfd)), ready)
    }

    /// Retain the original provider's held login leader, independently verify
    /// that exact physical logind session, and fence every Root lane on leader exit.
    /// This neither initializes authority nor accepts a numeric PID substitute.
    pub fn with_original_logind_session(
        mut self,
        profile_file: &Path,
        original_login: OwnedFd,
    ) -> io::Result<Self> {
        let profile: crate::HostAuthorityNativeProfile = read_root_json(profile_file)?;
        self.service = self.service.with_original_logind_session(
            &profile,
            self.config.peer_uid,
            original_login,
        )?;
        Ok(self)
    }

    /// Launch the native UI from this SAME already prepared Root session.
    /// Fresh publication/handoff and native serving cannot reopen the exclusive
    /// clock/issuer/checkpoint owners. The original protected launch checks
    /// still run and both files must equal this retained registration/config.
    pub fn launch_native(
        self,
        config_file: &Path,
        registration_file: &Path,
        profile_file: &Path,
    ) -> io::Result<()> {
        self.launch_native_with_ready(config_file, registration_file, profile_file, || Ok(()))
    }

    /// Complete the same protected native launch before releasing one child
    /// bootstrap at the original fixed-lane listener barrier. The callback
    /// must only release that already prepared handoff; no new owner is opened
    /// and every original peer, deadline and no-retry check remains in force.
    pub fn launch_native_with_ready(
        self,
        config_file: &Path,
        registration_file: &Path,
        profile_file: &Path,
        ready: impl FnOnce() -> io::Result<()>,
    ) -> io::Result<()> {
        let (config, profile) = crate::authority_host_native_launch::inputs(
            config_file,
            registration_file,
            profile_file,
            &self.owner_pidfd,
        )?;
        let registration: HostAuthorityRegistration = read_root_json(registration_file)?;
        self.service
            .check_logind_binding(&profile.original_human_binding())?;
        if serde_json::to_vec(&config).map_err(io::Error::other)?
            != serde_json::to_vec(&self.config).map_err(io::Error::other)?
            || serde_json::to_vec(&registration).map_err(io::Error::other)?
                != serde_json::to_vec(&self.registration).map_err(io::Error::other)?
        {
            return Err(io::Error::other(
                "native launch changed the retained original Root inputs",
            ));
        }
        crate::authority_host_native_launch::launch_prepared_native_with_ready(
            self,
            config,
            profile,
            profile_file,
            ready,
        )
    }

    fn serve_selected(
        self,
        text_ui: Option<(&Path, OwnedFd)>,
        ready: impl FnOnce() -> io::Result<()>,
    ) -> io::Result<()> {
        let Self {
            config,
            registration,
            owner_pidfd,
            service,
            root_admin,
            learning,
            publication,
            initial_publication,
            historical_read,
            ..
        } = self;
        let session_end = Instant::now() + std::time::Duration::from_millis(config.lifetime_ms);
        let historical_read = historical_read
            .map(|runtime| historical_read::BoundHistoricalTaskRead::bind(runtime, &config))
            .transpose()?;
        // Bind the dedicated optional lane before either five-lane ready
        // callback can release the child. Its accept loop runs independently.
        let learning = learning
            .map(|owner| learning::BoundLearning::bind(owner, &config, publication))
            .transpose()?;
        let initial_publication = initial_publication
            .map(|runtime| {
                if learning
                    .as_ref()
                    .is_some_and(|lane| lane.contains_path(runtime.path()))
                {
                    return Err(io::Error::other(
                        "initial publication requires a distinct lane",
                    ));
                }
                generation_initial::BoundInitial::bind(runtime, &config, session_end)
            })
            .transpose()?;
        if text_ui.is_some()
            && config.issuer_record_profile
                != crate::authority_host_config::HostIssuerRecordProfile::TextRecovery
        {
            return Err(io::Error::other(
                "native text requires the explicit text_recovery issuer record profile",
            ));
        }
        if let Some((text_file, ui_pidfd)) = text_ui {
            let text: crate::HostAuthorityTextUiRegistration = read_root_json(text_file)?;
            if text.peer_uid != config.peer_uid {
                return Err(io::Error::other(
                    "text UI must share the registered Agentd owner UID for its existing private ingress",
                ));
            }
            text.validate(&service)?;
            let service = service.with_live_human_text(text.clone(), ui_pidfd.try_clone()?)?;
            if [
                &config.sockets.observation,
                &config.sockets.issuer,
                &config.sockets.checkpoint,
            ]
            .into_iter()
            .chain(config.sockets.device_frontier.iter())
            .chain(config.sockets.notes_frontier.iter())
            .any(|path| path == &text.socket_path)
                || learning
                    .as_ref()
                    .is_some_and(|lane| lane.contains_path(&text.socket_path))
                || initial_publication
                    .as_ref()
                    .is_some_and(|lane| lane.path() == text.socket_path)
                || historical_read
                    .as_ref()
                    .is_some_and(|lane| lane.path() == text.socket_path)
            {
                return Err(io::Error::other("text UI requires a distinct private lane"));
            }
            // A refused one-shot handoff must return before either serving
            // loop starts. All native launch and human registration work is
            // already complete; only the original accept barrier follows.
            let ready = || {
                ready()?;
                if let Some(admin) = &root_admin {
                    admin.activate()?;
                }
                Ok(())
            };
            let bound = listeners::bind_runtime_lanes(&config, ready)?;
            let serve = || {
                historical_read::serve_optional(
                    historical_read.as_ref(),
                    &service,
                    &config,
                    &registration,
                    &owner_pidfd,
                    session_end,
                    || {
                        generation_initial::serve_optional(
                            initial_publication.as_ref(),
                            &service,
                            &config,
                            &registration,
                            &owner_pidfd,
                            || {
                                learning::serve_optional(
                                    learning.as_ref(),
                                    &service,
                                    &config,
                                    &registration,
                                    &owner_pidfd,
                                    || {
                                        std::thread::scope(|scope| {
                                            let worker = scope.spawn(|| {
                                                service.serve_text_ui(
                                                    &text,
                                                    &ui_pidfd,
                                                    &owner_pidfd,
                                                    std::time::Duration::from_millis(
                                                        config.timeout_ms,
                                                    ),
                                                    std::time::Duration::from_millis(
                                                        config.lifetime_ms,
                                                    ),
                                                )
                                            });
                                            let original = listeners::serve_bound_lanes(
                                                &service,
                                                &config,
                                                &registration,
                                                &owner_pidfd,
                                                bound,
                                            );
                                            let ui = worker.join().map_err(|_| {
                                                io::Error::other("text UI lane panicked")
                                            })?;
                                            original.and(ui)
                                        })
                                    },
                                )
                            },
                        )
                    },
                )
            };
            match &root_admin {
                Some(admin) => admin.run(&service, &config, &registration, &owner_pidfd, serve),
                None => serve(),
            }
        } else {
            let serve = || {
                historical_read::serve_optional(
                    historical_read.as_ref(),
                    &service,
                    &config,
                    &registration,
                    &owner_pidfd,
                    session_end,
                    || {
                        generation_initial::serve_optional(
                            initial_publication.as_ref(),
                            &service,
                            &config,
                            &registration,
                            &owner_pidfd,
                            || {
                                learning::serve_optional(
                                    learning.as_ref(),
                                    &service,
                                    &config,
                                    &registration,
                                    &owner_pidfd,
                                    || {
                                        listeners::serve_lanes_with_ready(
                                            &service,
                                            &config,
                                            &registration,
                                            &owner_pidfd,
                                            || {
                                                ready()?;
                                                if let Some(admin) = &root_admin {
                                                    admin.activate()?;
                                                }
                                                Ok(())
                                            },
                                        )
                                    },
                                )
                            },
                        )
                    },
                )
            };
            match &root_admin {
                Some(admin) => admin.run(&service, &config, &registration, &owner_pidfd, serve),
                None => serve(),
            }
        }
    }
}

pub(crate) use generation_initial::RegisteredInitialLearningTrustV1;
pub(crate) use generation_initial::RootHistoricalLedgerDeploymentV1;
pub use generation_initial::RootInitialLearningTrustFilesV1;
