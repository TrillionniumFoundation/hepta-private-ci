//! Actual root-authenticated observation and original writer authority. The
//! retained session owns its single stream; dropping it closes authority.
use crate::AgentdRootAuthorityError;
use crate::AgentdRootAuthorityPeer;
use crate::AgentdRootWriterTrust;
use crate::HOST_AUTHORITY_OBSERVATION_V2;
use crate::HOST_WRITER_AUTHORIZATION_V1;
use crate::HostAuthorityObservationRequestV2;
use crate::HostAuthorityObservationResponseV2;
use crate::HostWriterAuthorizationReadRequestV1;
use crate::HostWriterAuthorizationReadResponseV1;
use crate::root_observation_cache::MAX_AGE_NS;
use crate::root_observation_cache::RootObservationCache;
use crate::root_observation_cache::boottime_ns;
use crate::root_observation_stream::RootObservationStream;
use crate::root_observation_stream::check_lifetime;
use crate::root_writer_proof::VerifiedRootWriterProof;
use codex_hepta_contracts::AgentId;
use codex_hepta_contracts::AuthorityClock;
use codex_hepta_contracts::AuthorityTrustError;
use codex_hepta_contracts::FinalUseAuthority;
use codex_hepta_contracts::FinalUseRevocations;
use codex_hepta_memory::ProductionAuthorityLease;
use codex_hepta_memory::ProductionAuthorityVerifier;
use std::fs::File;
use std::future::Future;
use std::os::fd::OwnedFd;
use std::os::unix::net::UnixStream;
use std::pin::Pin;
use std::sync::Arc;
use std::sync::Mutex;
use std::sync::OnceLock;
use std::sync::atomic::AtomicBool;
use std::sync::atomic::Ordering;
use std::task::Context;
use std::task::Poll;
use std::time::Duration;
use tokio::io::unix::AsyncFd;

struct LiveRoot {
    proof: VerifiedRootWriterProof,
    cache: RootObservationCache,
    root: Arc<AsyncFd<OwnedFd>>,
    end_boottime_ns: u64,
    active: AtomicBool,
    consumers: Mutex<Vec<FinalUseAuthority>>,
    // One asynchronous admission token covers the entire observation and
    // consumer barrier. There is no shared payload behind this permit.
    serial: tokio::sync::Semaphore,
    refresh_diagnostic: arc_swap::ArcSwapOption<RefreshDiagnostic>,
    #[cfg(test)]
    refresh_failed: AtomicBool,
}

// Only the original refresh execution writes these immutable RAM records.
// A single Arc load gives one coherent diagnostic record; it is not authority
// and is not an atomic snapshot with the cache's separate failure-time sample.
enum RefreshPhase {
    Sleeping,
    SerialWait,
    StreamAwait,
    Validate,
    CacheAccept,
    ConsumerLock,
    ConsumerSync,
    FinalCurrent,
    Completed,
}
impl RefreshPhase {
    fn diagnostic_label(&self) -> &'static str {
        match self {
            Self::Sleeping => "sleeping",
            Self::SerialWait => "serial-wait",
            Self::StreamAwait => "stream-await",
            Self::Validate => "validate",
            Self::CacheAccept => "cache-accept",
            Self::ConsumerLock => "consumer-lock",
            Self::ConsumerSync => "consumer-sync",
            Self::FinalCurrent => "final-current",
            Self::Completed => "completed",
        }
    }
}
struct RefreshDiagnostic {
    phase: RefreshPhase,
    request_started_ns: Option<u64>,
    response_ended_ns: Option<u64>,
    // These are the existing I/O timestamps of the last refresh whose original
    // final-current check succeeded, not a new completion clock or lease.
    last_successful_request_started_ns: Option<u64>,
    last_successful_response_ended_ns: Option<u64>,
}

// Only operational lifetimes retain this private, exact original File. Fenced
// read-only LiveRoot clones cannot keep a retired registered owner locked.
type WriterCustody = Arc<OnceLock<Arc<File>>>;

// Field order drops the complete original future, including its stream and
// consumers, before releasing its share of the original registered File.
struct RootWorker<F> {
    future: Pin<Box<F>>,
    _writer_file: WriterCustody,
}
impl<F: Future<Output = ()>> Future for RootWorker<F> {
    type Output = ();

    fn poll(self: Pin<&mut Self>, context: &mut Context<'_>) -> Poll<()> {
        self.get_mut().future.as_mut().poll(context)
    }
}

// A queued blocking closure also drops the actual consumers before File even
// when its executor shuts down without ever starting the original CAS work.
struct ConsumerSyncJob {
    consumers: Vec<FinalUseAuthority>,
    head: FinalUseRevocations,
    writer_file: WriterCustody,
}
impl ConsumerSyncJob {
    fn run(self) -> Result<(), AgentdRootAuthorityError> {
        let _writer_file = self.writer_file;
        let consumers = self.consumers;
        let head = self.head;
        for owner in consumers {
            if owner
                .revocation_head()
                .map_err(|_| AgentdRootAuthorityError::Unavailable)?
                != head
            {
                owner
                    .update_revocations(head.clone())
                    .map_err(|_| AgentdRootAuthorityError::Unavailable)?;
            }
            if owner
                .revocation_head()
                .map_err(|_| AgentdRootAuthorityError::Unavailable)?
                != head
            {
                return Err(AgentdRootAuthorityError::Unavailable);
            }
        }
        Ok(())
    }
}
impl LiveRoot {
    fn record_refresh_diagnostic(
        &self,
        phase: RefreshPhase,
        request_started_ns: Option<u64>,
        response_ended_ns: Option<u64>,
    ) {
        let previous = self.refresh_diagnostic.load_full();
        let completed = matches!(&phase, RefreshPhase::Completed);
        let next = RefreshDiagnostic {
            phase,
            request_started_ns,
            response_ended_ns,
            last_successful_request_started_ns: if completed {
                request_started_ns
            } else {
                previous
                    .as_ref()
                    .and_then(|value| value.last_successful_request_started_ns)
            },
            last_successful_response_ended_ns: if completed {
                response_ended_ns
            } else {
                previous
                    .as_ref()
                    .and_then(|value| value.last_successful_response_ended_ns)
            },
        };
        self.refresh_diagnostic.store(Some(Arc::new(next)));
    }

    fn diagnose_refresh_state(&self) {
        match self.refresh_diagnostic.load_full() {
            Some(value) => root_session_diagnostic(format_args!(
                "ROOT_SESSION_DIAGNOSTIC phase=refresh-state-sample refresh_phase={} request_started_ns={:?} response_ended_ns={:?} last_successful_request_started_ns={:?} last_successful_response_ended_ns={:?}",
                value.phase.diagnostic_label(),
                value.request_started_ns,
                value.response_ended_ns,
                value.last_successful_request_started_ns,
                value.last_successful_response_ended_ns,
            )),
            None => root_session_diagnostic(format_args!(
                "ROOT_SESSION_DIAGNOSTIC phase=refresh-state-sample refresh_phase=unrecorded"
            )),
        }
    }

    fn current(
        &self,
    ) -> Result<(Arc<HostAuthorityObservationResponseV2>, u64), AgentdRootAuthorityError> {
        if check_lifetime(self.root.get_ref())
            .inspect_err(|_error| {
                root_session_diagnostic(format_args!("ROOT_SESSION_DIAGNOSTIC phase=current-pre-lifetime class={}",
                    root_session_error_class(*_error),
                ));
            })
            .is_err()
            || boottime_ns()
                .inspect_err(|_error| {
                    root_session_diagnostic(format_args!("ROOT_SESSION_DIAGNOSTIC phase=current-boottime class={}",
                        root_session_error_class(*_error),
                    ));
                })
                .inspect(|_now| {
                    if *_now >= self.end_boottime_ns {
                        root_session_diagnostic(format_args!(
                            "ROOT_SESSION_DIAGNOSTIC phase=current-session-expired now_ns={} end_ns={}",
                            _now, self.end_boottime_ns,
                        ));
                    }
                })
                .map_or(true, |now| now >= self.end_boottime_ns)
        {
            self.cache.fence();
            return Err(AgentdRootAuthorityError::Unavailable);
        }
        let (observation, now) = self.cache.current().inspect_err(|_error| {
            root_session_diagnostic(format_args!(
                "ROOT_SESSION_DIAGNOSTIC phase=current-cache class={}",
                root_session_error_class(*_error),
            ));
            self.diagnose_refresh_state();
        })?;
        if self
            .proof
            .matches_observation(&observation)
            .inspect_err(|_error| {
                root_session_diagnostic(format_args!(
                    "ROOT_SESSION_DIAGNOSTIC phase=current-proof class={}",
                    root_session_error_class(*_error),
                ));
            })
            .is_err()
            || now
                >= self
                    .proof
                    .authority()
                    .lease_expires_at_unix_seconds
                    .saturating_mul(1000)
            || check_lifetime(self.root.get_ref())
                .inspect_err(|_error| {
                    root_session_diagnostic(format_args!(
                        "ROOT_SESSION_DIAGNOSTIC phase=current-post-lifetime class={}",
                        root_session_error_class(*_error),
                    ));
                })
                .is_err()
        {
            root_session_diagnostic(format_args!(
                "ROOT_SESSION_DIAGNOSTIC phase=current-final-check now_unix_ms={} lease_expiry_seconds={}",
                now,
                self.proof.authority().lease_expires_at_unix_seconds,
            ));
            self.cache.fence();
            return Err(AgentdRootAuthorityError::Unavailable);
        }
        Ok((observation, now))
    }
}
impl AuthorityClock for LiveRoot {
    fn now_unix_ms(&self) -> Result<u64, AuthorityTrustError> {
        self.current()
            .map(|(_, now)| now)
            .map_err(|_| AuthorityTrustError::Unavailable)
    }
}
impl ProductionAuthorityVerifier for LiveRoot {
    fn verify(
        &self,
        authority: &ProductionAuthorityLease,
        expected_agent: &AgentId,
    ) -> Result<(), String> {
        if !self.active.load(Ordering::Acquire)
            || authority != self.proof.authority()
            || &authority.agent_id != expected_agent
        {
            return Err(
                "root writer registration is inactive or differs from its verified proof".into(),
            );
        }
        self.current()
            .map(|_| ())
            .map_err(|_| "root writer observation is unavailable or fenced".into())
    }

    fn verify_sender_process_binding(
        &self,
        authority: &ProductionAuthorityLease,
        expected_agent: &AgentId,
        local_lease_id: &str,
        local_generation: u64,
        spawn_generation: u64,
    ) -> Result<(), String> {
        self.verify(authority, expected_agent)?;
        let (observation, _) = self
            .current()
            .map_err(|_| "root writer observation is unavailable or fenced".to_string())?;
        if observation.spawn_generation != spawn_generation
            || observation.writer.local_lease_id != local_lease_id
            || observation.writer.local_lease_generation != local_generation
        {
            return Err(
                "sender process binding differs from the verified root registration".into(),
            );
        }
        Ok(())
    }
}

/// Keep this handle alive for the whole original owner lifetime. `connect`
/// starts only a read feed. The writer verifier remains disabled until the
/// actual independently opened FinalUse consumers are installed and synced.
pub struct AgentdRootAuthoritySession {
    live: Arc<LiveRoot>,
    worker: tokio::task::JoinHandle<()>,
    writer_file: WriterCustody,
}
impl AgentdRootAuthoritySession {
    pub async fn connect(
        stream: UnixStream,
        peer: AgentdRootAuthorityPeer,
        root_pidfd: OwnedFd,
        timeout: Duration,
        lifetime: Duration,
        trust: AgentdRootWriterTrust,
    ) -> Result<Self, AgentdRootAuthorityError> {
        let created = boottime_ns()?;
        let boot_id = peer.boot_id.clone();
        let stream =
            RootObservationStream::from_stream(stream, peer, root_pidfd, timeout, lifetime)?;
        Self::connect_owned_stream(stream, boot_id, created, lifetime, trust).await
    }
    async fn connect_owned_stream(
        stream: RootObservationStream,
        boot_id: String,
        created: u64,
        lifetime: Duration,
        trust: AgentdRootWriterTrust,
    ) -> Result<Self, AgentdRootAuthorityError> {
        let response: HostWriterAuthorizationReadResponseV1 = stream
            .read(&HostWriterAuthorizationReadRequestV1 {
                schema_version: 1,
                operation: HOST_WRITER_AUTHORIZATION_V1.into(),
            })
            .await?;
        if response.schema_version != 1 || response.operation != HOST_WRITER_AUTHORIZATION_V1 {
            return Err(AgentdRootAuthorityError::Refused);
        }
        let proof = VerifiedRootWriterProof::verify(response.proof, &trust)?;
        let live = Arc::new(LiveRoot {
            proof,
            cache: RootObservationCache::new(boot_id),
            root: stream.root_lifetime(),
            end_boottime_ns: created
                .checked_add(
                    u64::try_from(lifetime.as_nanos())
                        .map_err(|_| AgentdRootAuthorityError::Refused)?,
                )
                .ok_or(AgentdRootAuthorityError::Refused)?,
            active: AtomicBool::new(false),
            consumers: Mutex::new(Vec::new()),
            serial: tokio::sync::Semaphore::new(1),
            refresh_diagnostic: arc_swap::ArcSwapOption::from(None),
            #[cfg(test)]
            refresh_failed: AtomicBool::new(false),
        });
        let writer_file = Arc::new(OnceLock::new());
        refresh(&live, &stream, &writer_file).await?;
        let background = Arc::clone(&live);
        let background_file = Arc::clone(&writer_file);
        let worker = tokio::spawn(RootWorker {
            future: Box::pin(async move {
                let _fence = FenceOnDrop(Arc::clone(&background));
                loop {
                    background.record_refresh_diagnostic(RefreshPhase::Sleeping, None, None);
                    tokio::time::sleep(Duration::from_millis(100)).await;
                    if refresh(&background, &stream, &background_file)
                        .await
                        .inspect_err(|_error| {
                            root_session_diagnostic(format_args!(
                                "ROOT_SESSION_DIAGNOSTIC phase=worker-refresh class={}",
                                root_session_error_class(*_error),
                            ));
                            background.diagnose_refresh_state();
                        })
                        .is_err()
                    {
                        return;
                    }
                }
            }),
            _writer_file: Arc::clone(&writer_file),
        });
        Ok(Self {
            live,
            worker,
            writer_file,
        })
    }
    /// Called only with Config's already acquired original registered File.
    /// A static proof mismatch never binds a foreign owner. Once bound, only
    /// the SAME Arc allocation is accepted; a cache/peer failure cannot clear
    /// custody or make a postload guard refusal release a still-live Root.
    pub(crate) fn retain_registered_writer(
        &self,
        agent: &AgentId,
        generation: u64,
        file: &Arc<File>,
    ) -> Result<(), AgentdRootAuthorityError> {
        if !self
            .live
            .proof
            .matches_registered_process(agent, generation)
        {
            return Err(AgentdRootAuthorityError::Refused);
        }
        let retained = self.writer_file.get_or_init(|| Arc::clone(file));
        if !Arc::ptr_eq(retained, file) {
            return Err(AgentdRootAuthorityError::Refused);
        }
        Ok(())
    }

    pub fn clock(&self) -> Arc<dyn AuthorityClock> {
        self.live.clone()
    }
    pub fn authority(&self) -> ProductionAuthorityLease {
        self.live.proof.authority().clone()
    }
    pub fn verifier(&self) -> Arc<dyn ProductionAuthorityVerifier> {
        self.live.clone()
    }
    pub fn revocations(&self) -> Result<FinalUseRevocations, AgentdRootAuthorityError> {
        self.live
            .current()
            .map(|(value, _)| value.revocations.clone())
    }
    /// Install the exact original Device/Notes owners, not replacement state
    /// or a second nonce ledger. Their separate original frontier stores remain
    /// the only durable owners. Calling twice is refused; failure stays fenced.
    pub async fn activate_final_use_owners(
        &self,
        consumers: Vec<FinalUseAuthority>,
    ) -> Result<(), AgentdRootAuthorityError> {
        if consumers.is_empty() || consumers.len() > 8 || self.live.active.load(Ordering::Acquire) {
            return Err(AgentdRootAuthorityError::Refused);
        }
        let started = boottime_ns()?;
        let _serial = match tokio::time::timeout(
            Duration::from_millis(500),
            self.live.serial.acquire(),
        )
        .await
        {
            Ok(Ok(permit)) => permit,
            Ok(Err(_)) | Err(_) => {
                self.live.cache.fence();
                return Err(AgentdRootAuthorityError::Unavailable);
            }
        };
        if self.live.active.load(Ordering::Acquire) {
            return Err(AgentdRootAuthorityError::Refused);
        }
        let mut attempt = ActivationAttempt {
            live: &self.live,
            complete: false,
        };
        let (observation, _) = self.live.current()?;
        self.live.cache.begin_update();
        synchronize_consumers(
            consumers.clone(),
            observation.revocations.clone(),
            started,
            &self.writer_file,
        )
        .await?;
        *self
            .live
            .consumers
            .lock()
            .map_err(|_| AgentdRootAuthorityError::Unavailable)? = consumers;
        self.live.cache.end_update();
        self.live.current()?;
        self.live.active.store(true, Ordering::Release);
        attempt.complete = true;
        Ok(())
    }
}
impl Drop for AgentdRootAuthoritySession {
    fn drop(&mut self) {
        #[cfg(test)]
        root_session_diagnostic(format_args!("ROOT_SESSION_DIAGNOSTIC phase=session-drop"));
        self.live.cache.fence();
        self.worker.abort();
        // Each original consumer holds this SAME LiveRoot as its clock. Break
        // the strong cycle after fencing; external owners remain independently
        // alive and locked until their own original Arc handles retire.
        let mut consumers = match self.live.consumers.lock() {
            Ok(consumers) => consumers,
            Err(poisoned) => poisoned.into_inner(),
        };
        consumers.clear();
    }
}
struct FenceOnDrop(Arc<LiveRoot>);
impl Drop for FenceOnDrop {
    fn drop(&mut self) {
        #[cfg(test)]
        root_session_diagnostic(format_args!("ROOT_SESSION_DIAGNOSTIC phase=worker-drop"));
        self.0.cache.fence();
    }
}
struct ActivationAttempt<'a> {
    live: &'a LiveRoot,
    complete: bool,
}
impl Drop for ActivationAttempt<'_> {
    fn drop(&mut self) {
        if !self.complete {
            self.live.cache.fence();
        }
    }
}

async fn refresh(
    live: &Arc<LiveRoot>,
    stream: &RootObservationStream,
    writer_file: &WriterCustody,
) -> Result<(), AgentdRootAuthorityError> {
    live.record_refresh_diagnostic(RefreshPhase::SerialWait, None, None);
    let _serial = live
        .serial
        .acquire()
        .await
        .map_err(|_| AgentdRootAuthorityError::Unavailable)
        .inspect_err(|_error| {
            root_session_diagnostic(format_args!(
                "ROOT_SESSION_DIAGNOSTIC phase=refresh-serial class={}",
                root_session_error_class(*_error),
            ));
        })?;
    // The test witness drops before this same serial permit on every failure.
    #[cfg(test)]
    let mut refresh_completion = tests::RefreshCompletion::new(&live.refresh_failed);
    let started = boottime_ns().inspect_err(|_error| {
        root_session_diagnostic(format_args!(
            "ROOT_SESSION_DIAGNOSTIC phase=refresh-start-boottime class={}",
            root_session_error_class(*_error),
        ));
    })?;
    live.record_refresh_diagnostic(RefreshPhase::StreamAwait, Some(started), None);
    let observation: HostAuthorityObservationResponseV2 = stream
        .read(&HostAuthorityObservationRequestV2 {
            schema_version: 2,
            operation: HOST_AUTHORITY_OBSERVATION_V2.into(),
        })
        .await
        .inspect_err(|_error| {
            root_session_diagnostic(format_args!(
                "ROOT_SESSION_DIAGNOSTIC phase=refresh-stream started_ns={started} class={}",
                root_session_error_class(*_error),
            ));
        })?;
    let ended = boottime_ns().inspect_err(|_error| {
        root_session_diagnostic(format_args!(
            "ROOT_SESSION_DIAGNOSTIC phase=refresh-end-boottime class={}",
            root_session_error_class(*_error),
        ));
    })?;
    live.record_refresh_diagnostic(RefreshPhase::Validate, Some(started), Some(ended));
    live.proof.matches_observation(&observation).inspect_err(|_error| {
        root_session_diagnostic(format_args!(
            "ROOT_SESSION_DIAGNOSTIC phase=refresh-proof started_ns={started} ended_ns={ended} class={}",
            root_session_error_class(*_error),
        ));
    })?;
    let head = observation.revocations.clone();
    let changed = !live.cache.revocations_match(&head);
    live.record_refresh_diagnostic(RefreshPhase::CacheAccept, Some(started), Some(ended));
    if changed {
        live.cache.begin_update();
    }
    // Validate and stage the complete response while the public cache is
    // paused, then advance each original consumer before releasing the barrier.
    live.cache.accept(observation, started, ended).inspect_err(|_error| {
        root_session_diagnostic(format_args!(
            "ROOT_SESSION_DIAGNOSTIC phase=refresh-accept started_ns={started} ended_ns={ended} class={}",
            root_session_error_class(*_error),
        ));
    })?;
    if changed {
        live.record_refresh_diagnostic(RefreshPhase::ConsumerLock, Some(started), Some(ended));
        let consumers = live
            .consumers
            .lock()
            .map_err(|_| AgentdRootAuthorityError::Unavailable)
            .inspect_err(|_error| {
                root_session_diagnostic(format_args!(
                    "ROOT_SESSION_DIAGNOSTIC phase=refresh-consumers-lock class={}",
                    root_session_error_class(*_error),
                ));
            })?
            .clone();
        live.record_refresh_diagnostic(RefreshPhase::ConsumerSync, Some(started), Some(ended));
        synchronize_consumers(consumers, head, started, writer_file)
            .await
            .inspect_err(|_error| {
                root_session_diagnostic(format_args!(
                    "ROOT_SESSION_DIAGNOSTIC phase=refresh-consumer-sync started_ns={started} ended_ns={ended} class={}",
                    root_session_error_class(*_error),
                ));
            })?;
        live.cache.end_update();
    }
    live.record_refresh_diagnostic(RefreshPhase::FinalCurrent, Some(started), Some(ended));
    live.current().inspect_err(|_error| {
        root_session_diagnostic(format_args!(
            "ROOT_SESSION_DIAGNOSTIC phase=refresh-final-current started_ns={started} ended_ns={ended} class={}",
            root_session_error_class(*_error),
        ));
    })?;
    #[cfg(test)]
    refresh_completion.complete();
    live.record_refresh_diagnostic(RefreshPhase::Completed, Some(started), Some(ended));
    Ok(())
}
async fn synchronize_consumers(
    consumers: Vec<FinalUseAuthority>,
    head: FinalUseRevocations,
    started: u64,
    writer_file: &WriterCustody,
) -> Result<(), AgentdRootAuthorityError> {
    if consumers.is_empty() {
        return Ok(());
    }
    let elapsed = boottime_ns()?
        .checked_sub(started)
        .ok_or(AgentdRootAuthorityError::Unavailable)?;
    let remaining = MAX_AGE_NS
        .checked_sub(elapsed)
        .filter(|remaining| *remaining > 0)
        .ok_or(AgentdRootAuthorityError::Unavailable)?;
    let job = ConsumerSyncJob {
        consumers,
        head,
        writer_file: Arc::clone(writer_file),
    };
    let result = tokio::time::timeout(
        Duration::from_nanos(remaining),
        // Aborting/timing out this await cannot cancel an already running CAS.
        tokio::task::spawn_blocking(move || job.run()),
    )
    .await
    .map_err(|_| AgentdRootAuthorityError::Unavailable)?
    .map_err(|_| AgentdRootAuthorityError::Unavailable)?;
    result?;
    if boottime_ns()?
        .checked_sub(started)
        .is_none_or(|age| age > MAX_AGE_NS)
    {
        return Err(AgentdRootAuthorityError::Unavailable);
    }
    Ok(())
}

// Failure-only production diagnostics. Callers format fixed labels, static
// error classes, numbers and booleans; no identity, proof or peer body.
fn root_session_diagnostic(detail: std::fmt::Arguments<'_>) {
    use std::io::Write;
    let _ = writeln!(std::io::stderr(), "{detail}");
}

fn root_session_error_class(error: AgentdRootAuthorityError) -> &'static str {
    match error {
        AgentdRootAuthorityError::Refused => "Refused",
        AgentdRootAuthorityError::Unavailable => "Unavailable",
    }
}

#[cfg(test)]
#[path = "root_authority_session_tests.rs"]
pub(crate) mod tests;
