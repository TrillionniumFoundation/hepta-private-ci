# NoUpdate11: initial A completion, Root observation failure, and shutdown scope

## Status and source identity

This is an independent source review of `9dfded9cecc74e39a19bccd14b9de9dc46c02c63`, tree `d07a8a95a2f0921387446063a1a51661cbd62df7`. It does not identify the runtime cause of `Unavailable` and does not grant ordinary, cold D, or FinalUse qualification. No host call, Rust formatting, build, source gate, native case, or model was run for this review. Existing failure originals are unchanged.

All 33 source files in [EXACT_SOURCE_PINS.json](EXACT_SOURCE_PINS.json) were independently checked against the exact Git API blob and against their rows in the cloud reconstruction of the actual source inventory. The reconstruction document hash differs from the repository inventory digest; both are named explicitly. The original source-gate receipt independently reports inventory `e3eb350ec62306da04dfa8e6aec5592a48d8962912204b15d17047f48920405e` and CALLERS `36fce234efc161c4bb0a2eb0dd5a2e66faa25839c941ce35df6d28bc8db70934`.

## What actually completed

The daemon's actual A log records Objective receipt, publication, observation and final RunStart. Its request 6 records phase `completed` and a successful control response. The independent observer process passed its original case in 1.19 seconds. These facts establish local A execution and observation; they are not a substitute for the required successful Root exit and retained Root Source proof.

The parent failed while checking the Root process's successful exit. The Root log contains `root_stage=lane.observation`, `root_stage=cli.serve`, and `Error: Custom { kind: Other, error: Unavailable }`. There is no timestamp or exchange stage attached to that error. `ready.exchange-returned elapsed55728` belongs to an earlier readiness exchange; it is not the time of the later error. The log order alone does not prove an immediate readiness failure or a shutdown race.

Original evidence is under `../e6_owner_work/completion_namespace_noupdate11_failure/`: the parent XML is SHA256 `9a7b8aa0fec80a7ab71bf33bb3ce8418527f7b3cf8ff749320cb34e7a0473a93`; full parent log is `61ad3808d9a132821bc94eb2a8de801559495240b89288b33229fa2829d64400`; Root stderr is `f6e55f434dd01b53ad9d77b75a6b48f4adedd3afa7a2b8970ca3e39c49e857a2`; daemon stderr is `e2eae49a1eb253e8284f64a0f604c6879f8e63913af08a0be4e1cabb2c63ed29`; observer stdout is `64d97bef838aa58c7e1f28a56d1a423b5b84198004400bfc32b1e03c053a6c4a`.

## Exact parent and production shutdown sequence

| Boundary | Exact source | Meaning |
|---|---|---|
| Observer and result checks | `ordinary_q24_process_tests.rs:186–198` | Await original independent observer success, check original fact digest, and compare live control observation and completion observation to the observed outcome. |
| Stop request | `ordinary_q24_process_tests.rs:199–200`; `ordinary_q24_process_child_tests.rs:166–187` | Require both processes live, then send SIGTERM through the retained actual daemon pidfd. This does not synthesize a drain receipt. |
| Exit checks | `ordinary_q24_process_tests.rs:207–210` | Await daemon success first, then Root success, then require both actual pidfds dead. |
| Retained Source proof | `ordinary_q24_process_tests.rs:211–218` | Only after both successes, open the original Root Source pin and require two equal nonzero readbacks. This point was not reached successfully. |
| Signal listener | `runtime.rs:830–842` | Production's original SIGTERM/SIGINT listener resolves the normal shutdown future. |
| A runtime drain | `runtime.rs:535–542`; `runtime_source_capture.rs:21–47` | Await actual runtime drain, task shutdown/join, a real completion oneshot, original control join and released State. Then close and capture the original Source. |
| Runtime task retirement | `runtime_tasks.rs:359–392,451–471` | Original cancellation, join, bounded grace and abort/join remain; latched failure cannot become success. |
| Root attachment lifetime | `production_launcher.rs:707–710`; `production_initial_q24_writer.rs:17–23` | The Root session/checkpoint/grant attachment is held until `crate::run` returns. |
| Root feed worker | `root_authority_session.rs:378–400,493–506` | A separate Tokio worker refreshes the original stream every 100 ms. Session Drop fences its cache, aborts that worker and clears retained consumers. It is not a task owned by `RuntimeTasks`. |

The existing runtime drain is actually awaited by the original path. There is no evidence that the parent omitted that protocol. In the reviewed Root session API, there is no separate async graceful retirement/join operation for the observation worker. The existing exit path is attachment release and Session Drop. Therefore a repair cannot simply call an already available but forgotten Root-feed drain method.

Cancellation of `RootObservationStream::read` drops the taken original stream and leaves its slot permanently empty (`root_observation_stream.rs:165–225`). A session abort during an exchange could therefore close that connection while a server frame is in progress. This is a source-level possibility only. No retained log shows that it caused this failure or when it happened. Handler, storage, clock and transport failures remain unresolved alternatives.

## Complete top-level failure map for the traced observation lane

This table covers the concrete failure-producing boundaries from the Root lane service through framing and the selected observation handlers. It does not infer which filesystem syscall or lease-store condition occurred inside a flattened error.

| Site | Errors and distinguishing behavior |
|---|---|
| `authority_host_service.rs:292–315`, `HostAuthorityPeerChannel::from_stream` | Peer credential, original pidfd bootstrap and nonblocking setup can return errors. Configuration and peer mismatch have distinct variants. Original I/O failures can become `Unavailable`. No reconnect occurs. |
| `authority_host_service.rs:319–358`, pre/post logind checks | The existing `unavailable` conversion erases the underlying logind error. The operation itself is not logged. |
| `authority_host_service.rs:361–372`, decode and route | Bad JSON/schema or unsupported request shape is `InvalidRequest`. Selecting the writer route with no registered writer is `Unavailable`. |
| Same function, v1 `with_live_lease` | Original lease read/revision/use/dispatch verification errors are converted to I/O and then flattened to `Unavailable`. Principal mismatch is also flattened. |
| Same function, v1 handler body | Issuer revocation store read, durable clock projection, post-I/O epoch/expiry validation and bounded encoding can be flattened to `Unavailable`. |
| `authority_host_writer.rs:246–308`, writer v1/v2 route | Unsupported schema/operation is `InvalidRequest`. Actual lease registration/current dispatch, retained proof load/verification/equality, revocation read, clock projection, post-I/O lease validation, proof digest and encoding errors are flattened to `Unavailable`. |
| `contracts/authority_host_peer.rs:160–199`, first-byte wait | A clean zero-byte first read is **`Ok(false)`**, the existing normal EOF path. Deadline, peer loss and syscall failures have separate meanings. |
| Same function, remaining header/body | A mid-frame zero-byte read becomes `Closed`. Invalid request length is `InvalidRequest`. Other syscall or poll failures may become `Unavailable`. |
| Same function, pre/post-handler and final owner checks | Original absolute/frame deadline expiration is `DeadlineElapsed`; an observed original pidfd exit is `PeerDenied`. A poll syscall error can map to `Unavailable`. Checks are not bypassed. |
| Same function, handler | The handler error is propagated unchanged; the service may already have erased a lease, clock or store cause. |
| Same function, response bound | Empty or oversized complete response is directly `Unavailable`. |
| Same function, response writes | Zero-byte write is `Closed`; poll socket ERR/NVAL and non-timeout I/O errors can be `Unavailable`. Actual timeout is `DeadlineElapsed`. |
| `contracts/authority_host_channel.rs:99–133` | Pinned owner exit wins over socket readiness and produces `PeerDenied`; socket ERR/NVAL produces `Unavailable`; HUP is permitted to reach the original read. |
| `contracts/authority_host_issuer_transport.rs:229–236` | I/O TimedOut/WouldBlock maps to `DeadlineElapsed`; other I/O kinds map to `Unavailable`. |

The durable clock implementation uses a blocking `Mutex::lock`, not a try-lock busy result. Poisoning, original store load/CAS, OS clock/boot sampling, projection integrity, forward wall-clock movement and the durable ceiling check can fail. The service flattens both clock `Invalid` and `Unavailable` to transport `Unavailable`. This review does not diagnose clock contention or corruption from the parent error.

The Root listener emits only its lane label after `serve` fails and later joins lane threads (`authority_host_listeners.rs:149–169`). The initial-publication runtime then closes its initial worker after the original fixed-lane result returns and preserves that original result (`authority_host_generation_initial_runtime.rs:82–234`). Those cleanup steps explain propagation, not the initiating error.

## Completed six/seven signatures are not this lane's direct path

The bounded `CompletedSignatureDigests::{Six,Seven}` is private completed-acceptance DATA. It has no initialization hook or background task. Its changed verifier requires an `OriginalCompletedLearningContextV1`, seven actual physical journal pairs, actual receipt matching and independent B. The modified checkpoint reader is reached only through completed-scoped terminal decoding.

The concrete caller is `HistoricalTaskReadRuntime::observe_completed_learning` in `authority_host_completed_observation.rs:28+`. The historical dispatcher enters it for `AcceptCompletedLearning`, `CaptureCompletedHistory` or `ReadCompletedHistory` (`authority_host_historical_read.rs:255–284`). It is not a call of `HostAuthorityService::observe`, the original writer observation or channel framing. Initial A shutdown failed before the parent could proceed to B/completed learning. No such historical route appears in the retained run log.

This establishes absence of a direct completed six/seven acceptance call on the traced failure path. It is not a claim that changed binary layout or scheduling can never influence timing. The Agentd observation service, writer, session and runtime source files also retain their old bfea blobs; the contracts framing source is independently pinned at 9df. The sole 9df change over 527e is the cfg(test) namespace fixture.

## Minimal observability draft

[diagnostic_candidate_1/SOURCE.diff](diagnostic_candidate_1/SOURCE.diff) changes two files only. The service distinguishes channel construction, handler failure and exchange failure. The shared framing function records one fixed local phase and emits it only after the existing stream shutdown on error. The service's handler only sets a local diagnostic bit; it does not log while the failed stream remains live.

The draft preserves the returned original error, all owner checks, callback count/order, original deadlines and bounds, clean EOF success, stream uncertainty fencing, and lack of reconnect/retry. No request, response, key, principal, path, operation string, timestamp or dynamic error text is logged. Normal successful frames perform no additional I/O or clock sampling. A failure writes at most one contract phase and one service classification, in addition to the existing lane/CLI labels. Static labels do not provide event correlation across simultaneous failing lanes and do not reveal the erased handler subcause.

The draft remains unformatted, uncompiled and unexecuted. No gate or previous native result qualifies its new bytes. [CALLERS_IMPACT.json](diagnostic_candidate_1/CALLERS_IMPACT.json) retains all five affected original protected rows. Only protected row 630, zero based, needs a future exact private-call literal migration for the extra diagnostic argument. Row 555 and every original owner/read/write sequence remain textually present; no boundary or authority is added. No policy file was changed. Shared-contract QA and compilation must be considered if this draft is adopted; no new execution is authorized by this document.
