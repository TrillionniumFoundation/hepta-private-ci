# Root observation phase diagnostics: local source draft

Base source: `9dfded9cecc74e39a19bccd14b9de9dc46c02c63`.

Two changed files are completely pinned in [SOURCE_BINDINGS.json](SOURCE_BINDINGS.json); [SOURCE.diff](SOURCE.diff) is their complete unified diff. The service classifies construct/handler/exchange failures. The contracts framing function stores fixed local phase bytes and logs only after its original failed-stream shutdown, then returns the same original error. Public protocol and API signatures are unchanged. The private `exchange_inner` function receives one diagnostic reference.

This is an observability draft, not a failure fix. No unavailable result becomes success, no EOF semantics change, no deadline changes, no replay or reconnect is added, no authority is introduced, and no native qualification is claimed. Session Drop and its abort remain unchanged. No payload, operation, dynamic error, time sample or key is logged.

## Required review if adopted

- Confirm private phase-reference borrowing and compile both affected crates with the repository's original toolchain and gates.
- Preserve all existing error, clean EOF, owner death, mid-frame closure, deadline and response write rejection controls; do not relabel their failures as success.
- Preserve fence-before-diagnostic ordering. The service handler may set its local bit but must not emit before `channel.exchange` has closed an errored stream.
- Migrate only the exact private-call literal identified in [CALLERS_IMPACT.json](CALLERS_IMPACT.json), preserving all original sequences and records. The policy has not been modified in this draft.
- Bind every future execution to the final formatted source; all previous runs remain evidence for their own source only.

All checks in this package are readback, hashing and source review. Rust formatting, source gates, build, lint, native, whole parent, cold D, FinalUse and model execution are all zero for this candidate. The ordinary NoUpdate11 failure is preserved and unresolved.
