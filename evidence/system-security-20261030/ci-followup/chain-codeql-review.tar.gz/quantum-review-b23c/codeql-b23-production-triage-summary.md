# Independent finding triage — b23 source, unchanged Rust at 24b

This is a scratch review note, not product status authority, an exception, or a replacement for the original security gate. No source, query, model, gate, SARIF, or historical evidence was changed. No Rust build/test or check-runs API request was performed.

## Result

No actual embedded production credential or sensitive-information disclosure was confirmed among the reviewed findings. That is a finding-level static conclusion, not a claim that the repository is vulnerability-free. All 780 original SARIF entries remain individually represented in `codeql-b23-production-triage.json`, with their original zero-based index, exact primary region, source context, original fingerprints, rationale, and immutable source references.

The input is original SARIF artifact **12956961696**, run **41007753676**, Rust job **123906399702**, source **b23c0ef85f058507185b2ccb404a5d648e447c06**. ZIP SHA-256: `15f835191f4dbad39260c9140d50039ce7981a0501aaa02fe72a9b55c45e67dc`. The diff from b23 to **24b265834daea34947adbb5903d887e3f6043838** contains no Rust, Cargo manifest, or Cargo lockfile changes. All 81 source files referenced by this review have identical Git blob IDs at both commits. New-hosted results are recorded separately below.

| Original rule | Exact count | Source-level disposition |
|---|---:|---|
| `rust/hard-coded-cryptographic-value` | 757 | 732 test vectors, 19 retained historical test-source vectors, 4 production false positives, 2 research/example cases |
| `rust/cleartext-logging` | 23 | 15 collection operations without logging, 7 public test diagnostics, 1 intentional public CLI output |

The 757 messages label **752 nonce uses and 5 salt uses**. They do not report a production password/private key. Fixed test transaction counters do not become operational credentials merely because the rule calls them cryptographic values. The 732 test findings comprise 644 entries in test-only files/integration targets and 88 inside verified `#[cfg(test)]` modules. Their original scanner results are preserved.

## All hardcoded candidates outside tests and historical evidence

| Original index | b23 location | Finding-level review |
|---:|---|---|
| 223 | `trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v5.rs:31` | `7894` is the public registration wire byte length. It controls allocation and chunk length validation, not a nonce. |
| 224 | Same file, line 32 | `8274` is the public renewal wire byte length, with the same distinction. |
| 225 | Same file, line 132 | `Ok(0)` is the length for statement kind 0. The reported downstream PNX nonce belongs to a different enum arm; the PQ2 arm returns before it. Actual PQ2 nonce remains `prepared.common.nonce`, including the state nonce check and final update. |
| 754 | `trnm-mvcc-fee/src/pon_executor.rs:194` | `[0; 32]` is fully overwritten by exact hex decoding; invalid input returns before `Ok(h)`. |
| 357 | `trnm-pon-node/examples/pon_w1_budget_report.rs:257` | Fixed challenge input belongs to the explicit `FalseTrace` research arm, labeled as the claimed-zero-C/hash-only negative strategy. |
| 755 | `trnm-pon-node/examples/llm_zero_gain_round.rs:242` | The initialized salt is completely replaced by `read_exact` from `/dev/urandom` before use. Entropy errors propagate. |

Paths above are relative to `trillionnium/crates/`. Complete immutable GitHub links and the relevant branch/type evidence are in the JSON. Changing wire constants, nonce domains, or entropy semantics to remove these reports would be unjustified.

## All 23 logging entries

Indices **757–771** report `insert`, `remove`, or `len` expressions on proof/witness/transaction collections in examples, tests, and fuzz targets. These primary operations perform no log I/O. Three same-line expression pairs are retained separately, not deduplicated.

Indices **772 and 774–779** are actual test diagnostics. They print public certificate-validation results, row/key counts, packet/byte counts, durations, and height. The Debug `Capacity` type contains only five integer counters. The release verifier's success value contains public hashes/context/counts; its errors are fieldless variants. None of these reviewed diagnostic arguments contains a private key.

Index **773**, `trnm-pon-node/src/main.rs:2867`, is real stdout: `println!("{value}")`. Its reported Account sources contain public balance and nonce; migration sources expose public origin/claim fields and digests; other sources are verification outcomes or profile metadata. The three reported `secret_identity` calls return an encapsulated object. `DevelopmentIdentity.secret_hex` is private and is read only for signing; that type and its client/server wrappers have no Serialize/Debug implementation. Callers export public keys, signatures, or signed replies, not the private-key bytes. The SARIF names 18 distinct source expressions but retains only four code-flow traces; this review inspected all source locations by their actual type/role and does not invent missing traces. No secret-byte flow was found at the reported sink. A dynamic secret-canary test across actual CLI success/refusal/error paths remains a useful proposed regression; it was not run here.

## New 24b hosted outcomes — observed 2026-10-30 06:24 UTC

| Run/job | Actual new outcome |
|---|---|
| Pinned CodeQL **41011576556**, Rust job **123918417062** | Completed/failure. The original log at 06:14:48Z states `analysis_execution_complete=true`, `source_stable=true`, **`finding_count=780`**, `extraction_coverage_complete=false`, `passed=false`, `official_security_gate_qualified=false`. Actions/C++/Python jobs succeeded. Original diagnostic/SARIF retention and source recheck succeeded. The new total is directly observed, not copied from b23; the per-rule split in this note was recounted from b23 SARIF only. |
| Exact-source export **41011576824**, job **123918418063** | Completed/failure. After 38 waiting messages, its original log states at 06:20:44Z that analyses/checks did not complete and stabilize before the deadline. Source checks and failure-evidence retention succeeded. This establishes failure to obtain the required stable evidence, not an independently observed absence of any aggregate check. |

The raw decoded job logs and supported Actions metadata snapshot are retained alongside this note. The original failed gate remains failed. b23 also retained 304 affected tracked files / 305 semantic diagnostic lines and three unlocated type/SSA errors; no new 24b semantic diagnostic count is inferred from that older inventory.

## Actionable follow-up

The immediate technical work is semantic extraction/coverage repair and faithful upstream reproductions of the suspicious rule flows: collection methods as log sinks, enum-arm return merging, and overwritten-buffer initialization. Keep the original rules and results while qualifying any future pinned extractor/model change. A targeted CLI private-key canary and strict decoding/entropy failure controls can test meaningful boundaries; none is presented here as an already executed test or as grounds to bypass the original gate.
