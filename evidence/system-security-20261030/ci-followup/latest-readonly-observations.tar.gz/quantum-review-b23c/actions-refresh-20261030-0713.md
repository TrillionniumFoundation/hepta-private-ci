# Actions read-only refresh

Observed 2026-10-30 07:13:50 UTC. Only Actions run/jobs/logs were read. This is a scratch audit note, not a product qualification authority.

## Requested runs

| Source | Workflow | Run | Observed result |
|---|---|---|---|
| 24b26583 | History V6 exact-source native recovery | [41011576654](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41011576654) | completed / success |
| 24b26583 | trnm-required-baseline | [41011576723](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41011576723) | in_progress / no conclusion |
| f874d948 | Hepta architecture convergence | [41012864376](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/41012864376) | completed / success |
| f874d948 | blocking-ci | [41012864494](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/41012864494) | in_progress / no conclusion |

24b History V6: all four jobs succeeded. The original native terminal explicitly records 22 passed / 1 ignored, separate material controls 9 passed; lifecycle 12 passed / 0 ignored; reorg continuation 7 passed / 0 ignored. The graph-resource terminal also records passed=true. Their production_qualified and whole_history_p0_closed remain false. These are 24b observations.

Hepta architecture: source-head f874 actually completed all seven native execution steps. The canonical base merge bd620b64a8d481bcb620c500514c71a875acec18 has the same 54c15dd6 tree and explicitly reuses source-head native success; it did not repeat those native commands. The scope-selection flags are not an executed full-repository test count.

## Still open or failed

24b baseline: runtime jobs 123926740504 and 123926740618 still execute Run retained Rust shard. Five jobs already failed: protocol-contract source/prospective, quality source/prospective, and ARM64 cross-arch cost. The source protocol and ARM64 logs specifically report CONFIRMATION_TARGET after individual named tests returned PASS; source quality reports dependency policy refusal and supply-chain FAIL.

f874 blocking: macOS ARM 123922567642 and macOS Intel 123922567741 still execute bazel test; GNU 123922567735 has already failed its test step at 07:11:57Z and was still post-processing. Its run is not yet final. Linux musl 123922567669 completed/failure and actually checked out GitHub merge f39beee703246a60be74330334c2cbcaacd85be9 (not the source-head SHA or architecture's synthetic merge).

The musl log says exactly: `Executed 234 out of 607 tests: 397 tests pass, 1 fails to build, 26 fail remotely, and 183 were skipped.` The 397 includes cached passes. The 26 runtime failures cannot be treated as resolved by the single plasticity_process_e2e compile fix or Windows ABI selection fix.

## New a38 workflow list

Source a38d770966c65ad34c9d5e55f3c2917c2e3bda0f: 14 success, 5 failure, 2 pending. This section records workflow metadata only; it does not reuse 24b/b23 test counts. Release finality is attempt 2; this audit did not initiate it.

| Workflow | Run | Result | Attempt |
|---|---|---|---|
| PoN owned process cleanup | [41014451775](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451775) | success | 1 |
| PoN baseline diagnostic readback | [41014451838](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451838) | success | 1 |
| trnm-required-baseline | [41014451913](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451913) | pending | 1 |
| PoN priority acceptance | [41014451751](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451751) | pending | 1 |
| PoN ticket-first native cost research | [41014451676](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451676) | success | 1 |
| PoN branch encoding exact-source acceptance | [41014451772](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451772) | success | 1 |
| Pinned CodeQL analysis and coverage research | [41014451558](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451558) | failure | 1 |
| PoN original native campaign | [41014451615](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451615) | failure | 1 |
| Native PQ accounts v2 research | [41014451509](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451509) | success | 1 |
| Native PQ quota v3 research | [41014451535](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451535) | success | 1 |
| Native PQ task permissions v4 research | [41014451883](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451883) | success | 1 |
| PoN recent batch exact-source acceptance | [41014451503](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451503) | success | 1 |
| Pure PoN raw History joint research | [41014451843](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451843) | failure | 1 |
| Pure PoN complete v2 ARM64 cost research | [41014451587](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451587) | success | 1 |
| Pure PoN admission and DAA evidence | [41014451683](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451683) | failure | 1 |
| Owned fixed-parent receiver fixture | [41014451679](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451679) | success | 1 |
| Native PQ task renewal v5 research | [41014451823](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451823) | success | 1 |
| CodeQL exact-source analysis export | [41014451738](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451738) | failure | 1 |
| Release finality reference and native baseline | [41014451748](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451748) | success | 2 |
| Pure PoN focused native integration | [41014451618](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451618) | success | 1 |
| History V6 exact-source native recovery | [41014451652](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/41014451652) | success | 1 |

