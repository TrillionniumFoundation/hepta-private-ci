"""Read-only caller-proof review: mutations apply only to temporary snapshots."""
import hashlib
import importlib.util
import json
import sys
import tempfile
import tomllib
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
REPO = OUT / "snapshot"
sys.path.insert(0, str(REPO / "scripts"))
SPEC = importlib.util.spec_from_file_location("caller_review_red", REPO / "scripts/verify_hepta_callers.py")
M = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = M
SPEC.loader.exec_module(M)
PATHS = ["codex-rs/hepta-contracts/src/final_use.rs", "codex-rs/hepta-contracts/src/final_use_ml_dsa65_v2.rs"]
DATA = {"protected_file": [r for r in tomllib.loads((REPO / "CALLERS.toml").read_text())["protected_file"] if r["path"] in PATHS]}
ORIGINAL = (REPO / PATHS[1]).read_text()


def span(source, prefix):
    code = M._strip_rust_non_code(source)
    start = source.index(prefix)
    brace = code.index("{", start)
    end = M._matching_delimiter(code, brace, "{", "}")
    assert end is not None
    return start, brace, end


def nested_other_impl(source):
    a, b, z = span(source, "    pub(super) fn verify(")
    good = source[a:z + 1]
    source = source[:a] + source[a:b] + "{ true }" + source[z + 1:]
    _, _, end = span(source, "impl IssuerVerifier {")
    decoy = "\n    const DECOY: () = {\n        enum OtherIssuer { Ed25519V1(VerifyingKey), MlDsa65V2(Box<MlDsaVerifyingKey<MlDsa65>>), }\n        impl OtherIssuer {\n" + good + "\n        }\n    };\n"
    return source[:end] + decoy + source[end:]


def macro_with_qualified_real_impl(source):
    a, _, z = span(source, "impl IssuerVerifier {")
    good = source[a:z + 1]
    va, vb, vz = span(source, "    pub(super) fn verify(")
    source = source[:va] + source[va:vb] + "{ true }" + source[vz + 1:]
    source = source.replace("impl IssuerVerifier {", "impl self::IssuerVerifier {", 1)
    return source + "\nmacro_rules! ignore { ($($tokens:tt)*) => {}; }\nignore!(" + good + ");\n"


def nested_imports(source):
    imports = "\n".join(line for line in source.splitlines() if line.startswith("use ml_dsa::"))
    source = source.replace("use ml_dsa::MlDsa65;", "use ml_dsa::MlDsa87 as MlDsa65;", 1)
    return source + "\nmod proof_decoy {\n" + imports + "\n}\n"


def nested_context(source):
    constants = "\n".join(line for line in source.splitlines() if line.startswith(("pub const FINAL_USE_ML_DSA65", "const SIGNING_DOMAIN:", "const SIGNATURE_BYTES:", "const PUBLIC_KEY_BYTES:", "const FRAME_PREFIX:")))
    source = source.replace('b"hepta.kernel.final-use.ml-dsa-65.v2"', 'b"hepta.kernel.final-use.ml-dsa-65.v3"', 1)
    return source + "\nmod proof_decoy {\n" + constants + "\n}\n"


def nested_key_binding(source):
    a, b, z = span(source, "fn bind_key_id(")
    good = source[a:z + 1]
    source = source[:a] + source[a:b] + "{ Ok(input.to_vec()) }" + source[z + 1:]
    return source + "\nmod proof_decoy {\nuse super::*;\n" + good + "\n}\n"


records = []
for name, mutation in [("unchanged_positive", lambda s: s), ("nested_other_impl", nested_other_impl), ("macro_with_qualified_real_impl", macro_with_qualified_real_impl), ("nested_import_alias", nested_imports), ("nested_context_constant", nested_context), ("nested_key_binding_function", nested_key_binding)]:
    with tempfile.TemporaryDirectory(prefix="caller-proof-review-") as temp:
        root = Path(temp)
        for path in PATHS:
            p = root / path
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes((REPO / path).read_bytes())
        M._verify_protected_files(root, DATA)
        changed = mutation(ORIGINAL)
        (root / PATHS[1]).write_text(changed)
        try:
            M._verify_protected_files(root, DATA)
            accepted, error = True, None
        except M.VerificationFailure as exc:
            accepted, error = False, str(exc)
        records.append({"case": name, "baseline_passed_before_mutation": True, "accepted_by_scanner": accepted, "expected_acceptance": name == "unchanged_positive", "error": error, "mutated_source_sha256": hashlib.sha256(changed.encode()).hexdigest()})
        if name != "unchanged_positive":
            (OUT / (name + ".rs")).write_text(changed)
report = {"scope": "Independent Python textual gate controls only; no Rust compilation, no product source edit, no production/PQ qualification", "candidate_sha256": hashlib.sha256((REPO / "scripts/verify_hepta_callers.py").read_bytes()).hexdigest(), "records": records}
(OUT / "result.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
