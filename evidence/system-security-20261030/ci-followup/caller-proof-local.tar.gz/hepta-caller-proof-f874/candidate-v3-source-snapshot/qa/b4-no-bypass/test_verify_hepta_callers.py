from __future__ import annotations

import importlib.util
import sys
import tempfile
import textwrap
import tomllib
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location(
    "verify_hepta_callers", ROOT / "scripts/verify_hepta_callers.py"
)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class CallerProofTests(unittest.TestCase):
    def make_fixture(self, *, method_pattern: bool = False) -> Path:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "codex-rs/owner/src").mkdir(parents=True)
        (root / "codex-rs/caller/src").mkdir(parents=True)
        (root / "codex-rs/owner/src/lib.rs").write_text(
            "pub struct Gate; impl Gate { pub fn enter(&self) {} }\n", encoding="utf-8"
        )
        caller = "fn use_gate(gate: &Gate) { gate.enter(); }\n" if method_pattern else "fn use_gate() { Gate::enter(); }\n"
        (root / "codex-rs/caller/src/lib.rs").write_text(caller, encoding="utf-8")
        pattern = 'call_pattern = "gate\\\\s*\\\\.\\\\s*enter\\\\s*\\\\("\n' if method_pattern else ""
        caller_marker = "gate.enter" if method_pattern else "Gate::enter"
        (root / "CALLERS.toml").write_text(
            textwrap.dedent(
                f"""
                schema_version = 2
                plan_id = "HEPTA-GLOBAL-MODULAR-DEVELOPMENT-PLAN"
                source_roots = ["codex-rs"]
                ignored_path_fragments = ["/tests/", "/examples/", "_tests.rs"]
                [privileged_inventory]
                required_boundary_ids = ["gate"]
                [[boundary]]
                id = "gate"
                symbol = "Gate::enter"
                {pattern}definition_path = "codex-rs/owner/src/lib.rs"
                definition_markers = ["pub struct Gate", "pub fn enter"]
                product_callers = ["codex-rs/caller/src/lib.rs"]
                caller_markers = ["{caller_marker}"]
                [[protected_file]]
                path = "codex-rs/caller/src/lib.rs"
                required = ["{caller_marker}"]
                forbidden = ["Gate::bypass"]
                [authority]
                runtime_authority = false
                """
            ).strip()
            + "\n",
            encoding="utf-8",
        )
        return root

    def test_exact_caller_set_passes(self) -> None:
        root = self.make_fixture()
        receipt = MODULE.verify(root, root / "CALLERS.toml")
        self.assertEqual(receipt["status"], "PASS_HEPTA_CALLER_CLOSED_SET")

    def test_method_call_pattern_passes(self) -> None:
        root = self.make_fixture(method_pattern=True)
        receipt = MODULE.verify(root, root / "CALLERS.toml")
        self.assertEqual(receipt["boundaries"][0]["productCallers"], ["codex-rs/caller/src/lib.rs"])

    def test_typed_receiver_rejects_arbitrary_unregistered_parameter(self) -> None:
        root = self.make_fixture(method_pattern=True)
        manifest = root / "CALLERS.toml"
        text = manifest.read_text()
        text = "\n".join(line for line in text.splitlines() if not line.startswith("call_pattern ="))
        manifest.write_text(text.replace('symbol = "Gate::enter"', 'symbol = "Gate::enter"\nreceiver_type = "Gate"') + "\n")
        extra = root / "codex-rs/extra/src"
        extra.mkdir(parents=True)
        (extra / "lib.rs").write_text("fn bypass(completely_different: &Gate) { completely_different.enter(); }\n")
        with self.assertRaisesRegex(MODULE.VerificationFailure, "unexpected"):
            MODULE.verify(root, manifest)

    def test_typed_receiver_rejects_arbitrary_field_alias_in_split_impl(self) -> None:
        root = self.make_fixture(method_pattern=True)
        manifest = root / "CALLERS.toml"
        text = "\n".join(line for line in manifest.read_text().splitlines() if not line.startswith("call_pattern ="))
        manifest.write_text(text.replace('symbol = "Gate::enter"', 'symbol = "Gate::enter"\nreceiver_type = "Gate"') + "\n")
        extra = root / "codex-rs/extra/src"
        extra.mkdir(parents=True)
        (extra / "lib.rs").write_text("struct Owner { anything: Gate }\n")
        (extra / "child.rs").write_text("impl Owner { fn bypass(&self) { self.anything.enter(); } }\n")
        with self.assertRaisesRegex(MODULE.VerificationFailure, "unexpected"):
            MODULE.verify(root, manifest)

    def test_typed_related_method_cannot_bypass_closed_set(self) -> None:
        root = self.make_fixture(method_pattern=True)
        manifest = root / "CALLERS.toml"
        text = "\n".join(line for line in manifest.read_text().splitlines() if not line.startswith("call_pattern ="))
        manifest.write_text(text.replace('symbol = "Gate::enter"', 'symbol = "Gate::enter"\nreceiver_type = "Gate"\nreceiver_methods = ["enter", "enter_next"]') + "\n")
        extra = root / "codex-rs/extra/src"
        extra.mkdir(parents=True)
        (extra / "lib.rs").write_text("fn bypass(unexpected: &Gate) { unexpected.enter_next(); }\n")
        with self.assertRaisesRegex(MODULE.VerificationFailure, "unexpected"):
            MODULE.verify(root, manifest)

    def test_cfg_test_callsite_does_not_manufacture_product_caller(self) -> None:
        root = self.make_fixture()
        extra = root / "codex-rs/extra/src"
        extra.mkdir(parents=True)
        (extra / "lib.rs").write_text(
            "#[cfg(all(test, unix))]\nmod tests { fn only_test() { Gate::enter(); } }\n",
            encoding="utf-8",
        )
        receipt = MODULE.verify(root, root / "CALLERS.toml")
        self.assertEqual(receipt["boundaries"][0]["productCallers"], ["codex-rs/caller/src/lib.rs"])

    def test_cfg_test_fields_preserve_the_production_suffix(self) -> None:
        root = self.make_fixture()
        extra = root / "codex-rs/extra/src"
        extra.mkdir(parents=True)
        (extra / "lib.rs").write_text(
            "struct Store { live: u8, #[cfg(test)] test_only: Pair<u8, u8>, }\n"
            "impl Store { fn open() -> Self { Self { live: 1, #[cfg(test)] test_only: Pair::new(1, 2), } } }\n"
            "fn bypass() { Gate::enter(); }\n",
            encoding="utf-8",
        )
        with self.assertRaisesRegex(MODULE.VerificationFailure, "unexpected"):
            MODULE.verify(root, root / "CALLERS.toml")
        stripped = MODULE._strip_cfg_test_items((extra / "lib.rs").read_text())
        self.assertEqual(stripped.count("{"), stripped.count("}"))
        self.assertIn("fn bypass", stripped)
        self.assertNotIn("test_only", stripped)

    def test_last_cfg_test_field_does_not_remove_enclosing_brace(self) -> None:
        source = "struct Store { live: u8, #[cfg(test)] test_only: u8 } fn f() { Gate::enter(); }"
        stripped = MODULE._strip_cfg_test_items(source)
        self.assertEqual(stripped.count("{"), stripped.count("}"))
        self.assertIn("Gate::enter", stripped)

    def test_cfg_production_alternatives_remain_visible(self) -> None:
        for condition in ("not(test)", "any(test, unix)", "all(not(test), unix)"):
            with self.subTest(condition=condition):
                source = f"#[cfg({condition})] fn bypass() {{ Gate::enter(); }}"
                self.assertIn("Gate::enter", MODULE._strip_cfg_test_items(source))
        self.assertNotIn("Gate::enter", MODULE._strip_cfg_test_items(
            "#[cfg(all(test, unix))] fn only_test() { Gate::enter(); }"
        ))

    def test_inventory_omission_fails(self) -> None:
        root = self.make_fixture()
        manifest = root / "CALLERS.toml"
        manifest.write_text(
            manifest.read_text(encoding="utf-8").replace(
                'required_boundary_ids = ["gate"]',
                'required_boundary_ids = ["gate", "missing_privileged_boundary"]',
            ),
            encoding="utf-8",
        )
        with self.assertRaises(MODULE.VerificationFailure):
            MODULE.verify(root, manifest)

    def test_unexpected_product_caller_fails(self) -> None:
        root = self.make_fixture()
        extra = root / "codex-rs/extra/src"
        extra.mkdir(parents=True)
        (extra / "lib.rs").write_text("fn bypass() { Gate::enter(); }\n", encoding="utf-8")
        with self.assertRaises(MODULE.VerificationFailure):
            MODULE.verify(root, root / "CALLERS.toml")

    def test_comment_and_string_do_not_manufacture_callers(self) -> None:
        root = self.make_fixture()
        extra = root / "codex-rs/extra/src"
        extra.mkdir(parents=True)
        (extra / "lib.rs").write_text(
            '// Gate::enter()\nconst TEXT: &str = "Gate::enter()";\n', encoding="utf-8"
        )
        receipt = MODULE.verify(root, root / "CALLERS.toml")
        self.assertEqual(receipt["boundaries"][0]["productCallers"], ["codex-rs/caller/src/lib.rs"])

    def test_positive_authority_fails(self) -> None:
        root = self.make_fixture()
        manifest = root / "CALLERS.toml"
        manifest.write_text(
            manifest.read_text(encoding="utf-8").replace(
                "runtime_authority = false", "runtime_authority = true"
            ),
            encoding="utf-8",
        )
        with self.assertRaises(MODULE.VerificationFailure):
            MODULE.verify(root, manifest)

    def final_use_fixture(self) -> tuple[Path, dict[str, object]]:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        paths = [
            "codex-rs/hepta-contracts/src/final_use.rs",
            "codex-rs/hepta-contracts/src/final_use_ml_dsa65_v2.rs",
        ]
        manifest = tomllib.loads((ROOT / "CALLERS.toml").read_text())
        data = {"protected_file": [
            row for row in manifest["protected_file"] if row["path"] in paths
        ]}
        self.assertEqual([row["path"] for row in data["protected_file"]], paths)
        for relative in paths:
            target = root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((ROOT / relative).read_bytes())
        # Every negative starts with the actual current owner/delegate passing.
        self.assertEqual(MODULE._verify_protected_files(root, data), paths)
        return root, data

    def test_final_use_real_owner_and_both_issuer_suites_pass(self) -> None:
        root, data = self.final_use_fixture()
        delegate = root / "codex-rs/hepta-contracts/src/final_use_ml_dsa65_v2.rs"
        delegate.write_text(delegate.read_text().replace(
            "key.verify_with_context(", "key /* harmless whitespace/comment */\n.verify_with_context("
        ))
        MODULE._verify_protected_files(root, data)

    def test_final_use_owner_cannot_skip_or_rebind_signature_verification(self) -> None:
        mutations = [
            ('#[path = "final_use_ml_dsa65_v2.rs"]', '#[path = "unverified_issuer.rs"]'),
            ("let input = self.grant_signing_input(signed, expected)?;",
             "let input = self.grant_signing_input(signed, expected);"),
            (".signing_bytes(&signed.grant)?;", ".signing_bytes(&other_grant)?;"),
            ("|| &signed.grant.binding != expected", "|| &signed.grant.binding == expected"),
            ("signed.grant.authority_epoch >= candidate.not_before_authority_epoch",
             "signed.grant.authority_epoch <= candidate.not_before_authority_epoch"),
            ("&candidate.key_id,", "&signed.grant.signer_id,"),
            ("&signed.signature,", "&other_signature,"),
            ("if !verified {", "if false {"),
            ("let mut bytes = domain.to_vec();", "let mut bytes = Vec::new();"),
            ("if self.schema_version != schema", "if false"),
            ("serde_json::to_vec(self)", "serde_json::to_vec(&self.binding)"),
            ("    pub binding: FinalUseBinding,", "    #[serde(skip_serializing)]\n    pub binding: FinalUseBinding,"),
            ("    pub destination_id: String,", "    #[serde(skip_serializing)]\n    pub destination_id: String,"),
        ]
        for old, new in mutations:
            with self.subTest(mutation=old):
                root, data = self.final_use_fixture()
                owner = root / "codex-rs/hepta-contracts/src/final_use.rs"
                source = owner.read_text()
                self.assertEqual(source.count(old), 1)
                owner.write_text(source.replace(old, new))
                with self.assertRaisesRegex(MODULE.VerificationFailure, "required code missing"):
                    MODULE._verify_protected_files(root, data)

    def test_final_use_delegate_cannot_ignore_verification_or_change_suite_bindings(self) -> None:
        verify = "key.verify_with_context(&input, FINAL_USE_ML_DSA65_V2_CONTEXT, &signature)"
        strict = "key.verify_strict(input, &signature).is_ok()"
        mutations = [
            ("use ml_dsa::MlDsa65;", "use ml_dsa::MlDsa87 as MlDsa65;"),
            ("use ml_dsa::Signature as MlDsaSignature;", "use different_suite::Signature as MlDsaSignature;"),
            ("use ml_dsa::VerifyingKey as MlDsaVerifyingKey;", "use different_suite::VerifyingKey as MlDsaVerifyingKey;"),
            ("(Self::MlDsa65V2(key), 2)", "(Self::MlDsa65V2(key), 1)"),
            ("MlDsaSignature::<MlDsa65>::try_from(raw)", "MlDsaSignature::<MlDsa87>::try_from(raw)"),
            ("if actual_key_id != key_id", "if actual_key_id == key_id"),
            ("decode_signature(frame)", "decode_signature(&[])"),
            ("bind_key_id(input, key_id)", "bind_key_id(input, other_key_id)"),
            (verify, "{ let _ = " + verify + "; true }"),
            (verify, "other_key.verify_with_context(&input, FINAL_USE_ML_DSA65_V2_CONTEXT, &signature)"),
            (verify, "key.verify_with_context(&input, SIGNING_DOMAIN, &signature)"),
            (strict, "{ let _ = key.verify_strict(input, &signature); true }"),
            ("(Self::Ed25519V1(_) | Self::MlDsa65V2(_), _) => false",
             "(Self::Ed25519V1(_) | Self::MlDsa65V2(_), _) => true"),
            ('b"hepta.kernel.final-use.ml-dsa-65.v2"', 'b"hepta.kernel.final-use.ml-dsa-65.v3"'),
            ('b"hepta.kernel.authority.final-use.ml-dsa-65.v2\\0"',
             'b"hepta.kernel.authority.final-use.ml-dsa-65.v3\\0"'),
            ('b"HFU2\\x65\\0"', 'b"HFU2\\x44\\0"'),
            ("frame.len() != 8 + length + SIGNATURE_BYTES", "frame.len() < 8 + length + SIGNATURE_BYTES"),
        ]
        for old, new in mutations:
            with self.subTest(mutation=old):
                root, data = self.final_use_fixture()
                delegate = root / "codex-rs/hepta-contracts/src/final_use_ml_dsa65_v2.rs"
                source = delegate.read_text()
                self.assertEqual(source.count(old), 1)
                delegate.write_text(source.replace(old, new))
                with self.assertRaisesRegex(MODULE.VerificationFailure, "required code missing"):
                    MODULE._verify_protected_files(root, data)

    def test_final_use_owner_impl_cannot_be_replaced_by_another_type(self) -> None:
        root, data = self.final_use_fixture()
        owner = root / "codex-rs/hepta-contracts/src/final_use.rs"
        source = owner.read_text()
        self.assertEqual(source.count("impl FinalUseAuthority {"), 1)
        owner.write_text(source.replace("impl FinalUseAuthority {", "impl OtherAuthority {"))
        with self.assertRaisesRegex(MODULE.VerificationFailure, "required code needs one top-level impl"):
            MODULE._verify_protected_files(root, data)

    def test_final_use_context_comment_cannot_mask_different_literal_bytes(self) -> None:
        root, data = self.final_use_fixture()
        delegate = root / "codex-rs/hepta-contracts/src/final_use_ml_dsa65_v2.rs"
        source = delegate.read_text()
        declaration = 'pub const FINAL_USE_ML_DSA65_V2_CONTEXT: &[u8] = b"hepta.kernel.final-use.ml-dsa-65.v2";'
        self.assertEqual(source.count(declaration), 1)
        changed = declaration.replace("ml-dsa-65.v2", "ml-dsa-65. v2")
        delegate.write_text(source.replace(declaration, changed) + "\n// " + declaration + "\n")
        with self.assertRaisesRegex(MODULE.VerificationFailure, "required code missing"):
            MODULE._verify_protected_files(root, data)

    def test_final_use_nested_items_and_macro_tokens_cannot_replace_real_verifier(self) -> None:
        for carrier in (
            "associated_const", "macro", "suite_import", "context", "key_binding",
            "conditional_context", "conditional_key_binding", "conditional_impl", "conditional_verify",
        ):
            with self.subTest(carrier=carrier):
                root, data = self.final_use_fixture()
                delegate = root / "codex-rs/hepta-contracts/src/final_use_ml_dsa65_v2.rs"
                source = delegate.read_text()
                code = MODULE._strip_rust_non_code(source)

                def item(marker: str) -> tuple[str, str]:
                    start = source.index(marker)
                    brace = code.index("{", start)
                    end = MODULE._matching_delimiter(code, brace, "{", "}")
                    self.assertIsNotNone(end)
                    return source[start:end + 1], source[start:brace]

                verify, header = item("pub(super) fn verify(")
                broken = source.replace(verify, header + "{ true }")
                if carrier == "associated_const":
                    decoy = (
                        "const DECOY: () = { enum OtherIssuer { "
                        "Ed25519V1(VerifyingKey), MlDsa65V2(Box<MlDsaVerifyingKey<MlDsa65>>) "
                        "} impl OtherIssuer { " + verify + " } };"
                    )
                    changed = broken.replace("impl IssuerVerifier {", "impl IssuerVerifier { " + decoy)
                elif carrier == "macro":
                    original, _ = item("impl IssuerVerifier {")
                    changed = broken.replace("impl IssuerVerifier {", "impl self::IssuerVerifier {")
                    changed += "\nmacro_rules! ignore { ($($t:tt)*) => {}; }\nignore!(" + original + ");\n"
                elif carrier == "suite_import":
                    imports = source[source.index("use ml_dsa::EncodedVerifyingKey;"):source.index("pub const")]
                    changed = source.replace("use ml_dsa::MlDsa65;", "use ml_dsa::MlDsa87 as MlDsa65;")
                    changed += "\nmod decoy { " + imports + " }\n"
                elif carrier == "context":
                    constants = source[source.index("pub const"):source.index("\n\n/// One host-pinned")]
                    changed = source.replace('b"hepta.kernel.final-use.ml-dsa-65.v2"', 'b"hepta.kernel.final-use.ml-dsa-65.v3"')
                    changed += "\nmod decoy { " + constants + " }\n"
                elif carrier == "key_binding":
                    original, header = item("fn bind_key_id(")
                    changed = source.replace(original, header + "{ Ok(input.to_vec()) }")
                    changed += "\nmod decoy { " + original + " }\n"
                elif carrier == "conditional_context":
                    original = 'pub const FINAL_USE_ML_DSA65_V2_CONTEXT: &[u8] = b"hepta.kernel.final-use.ml-dsa-65.v2";'
                    changed = source.replace(original, '#[cfg(target_os = "windows")]\n' + original)
                    changed += '\n#[cfg(not(target_os = "windows"))]\n' + original.replace("65.v2", "65.v3")
                elif carrier == "conditional_key_binding":
                    original, header = item("fn bind_key_id(")
                    changed = source.replace(original, '#[cfg(target_os = "windows")]\n' + original)
                    changed += '\n#[cfg(not(target_os = "windows"))]\n' + header + "{ Ok(input.to_vec()) }"
                elif carrier == "conditional_impl":
                    original, _ = item("impl IssuerVerifier {")
                    changed = source.replace(original, '#[cfg(target_os = "windows")]\n' + original)
                    fallback = original.replace(verify, header + "{ true }")
                    fallback = fallback.replace("impl IssuerVerifier {", "impl self::IssuerVerifier {")
                    changed += '\n#[cfg(not(target_os = "windows"))]\n' + fallback
                else:
                    changed = source.replace(verify, '#[cfg(target_os = "windows")]\n' + verify + '\n#[cfg(not(target_os = "windows"))]\n' + header + "{ true }")
                delegate.write_text(changed)
                with self.assertRaisesRegex(MODULE.VerificationFailure, "required code"):
                    MODULE._verify_protected_files(root, data)

    def test_final_use_verifier_cannot_be_manufactured_by_non_product_text(self) -> None:
        for carrier in ("comment", "string", "raw_string", "cfg_test"):
            with self.subTest(carrier=carrier):
                root, data = self.final_use_fixture()
                delegate = root / "codex-rs/hepta-contracts/src/final_use_ml_dsa65_v2.rs"
                source = delegate.read_text()
                start = source.index("pub(super) fn verify(")
                code = MODULE._strip_rust_non_code(source)
                brace = code.index("{", start)
                end = MODULE._matching_delimiter(code, brace, "{", "}")
                self.assertIsNotNone(end)
                original = source[start:end + 1]
                replacement = source[start:brace] + "{ true }"
                if carrier == "comment":
                    hidden = "/* " + original + " */"
                elif carrier == "string":
                    hidden = 'const SAVED: &str = "' + original + '";'
                elif carrier == "raw_string":
                    hidden = 'const SAVED: &str = r###"' + original + '"###;'
                else:
                    hidden = "#[cfg(all(test, unix))] impl IssuerVerifier { " + original + " }"
                delegate.write_text(source.replace(original, replacement) + "\n" + hidden + "\n")
                with self.assertRaisesRegex(MODULE.VerificationFailure, "required code missing"):
                    MODULE._verify_protected_files(root, data)


if __name__ == "__main__":
    unittest.main()
