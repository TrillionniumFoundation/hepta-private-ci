"""Read retained Bazel 9.3.0 compact execution evidence; does not run commands."""
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import zipfile

import zstandard

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT / "windows-shard2-execution-logs.zip"


def varint(stream, allow_eof=False):
    out = 0
    for shift in range(0, 70, 7):
        octet = stream.read(1)
        if not octet:
            if allow_eof and shift == 0:
                return None
            raise ValueError("truncated varint")
        byte = octet[0]
        out |= (byte & 127) << shift
        if byte < 128:
            return out
    raise ValueError("oversized varint")


def fields(data):
    stream = io.BytesIO(data)
    parsed = {}
    while (key := varint(stream, allow_eof=True)) is not None:
        number, wire = key >> 3, key & 7
        if wire == 0:
            value = varint(stream)
        elif wire in (1, 5):
            size = 8 if wire == 1 else 4
            value = stream.read(size)
            if len(value) != size:
                raise ValueError("truncated fixed field")
        elif wire == 2:
            size = varint(stream)
            value = stream.read(size)
            if len(value) != size:
                raise ValueError("truncated length field")
        else:
            raise ValueError(f"unsupported protobuf wire {wire}")
        parsed.setdefault(number, []).append(value)
    return parsed


def string(parsed, number, default=""):
    return parsed.get(number, [default.encode()])[0].decode("utf-8")


def number(parsed, field, default=0):
    return parsed.get(field, [default])[0]


def selected_environment(parsed):
    keep = {"CC", "CXX", "AR", "CFLAGS", "CXXFLAGS", "CPPFLAGS", "HOST", "TARGET", "RUSTC", "CARGO_ENCODED_RUSTFLAGS", "CARGO_CFG_TARGET_ENV", "CARGO_CFG_TARGET_ARCH", "CARGO_CFG_TARGET_OS", "CARGO_CFG_TARGET_FEATURE"}
    output = {}
    for raw in parsed.get(2, []):
        item = fields(raw)
        key = string(item, 1)
        if key in keep or key.startswith(("CC_", "CXX_", "CFLAGS_", "CXXFLAGS_")):
            output[key] = string(item, 2)
    return output


def main():
    archive_sha = hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
    assert archive_sha == "8e780da4d93e0bc9b3ca1bbca1c8dce77012f369b6251cffc5f74f73ebc94c8c"
    kinds, mnemonics, runners = Counter(), Counter(), Counter()
    files, selected = {}, []
    entries = 0
    decoded_bytes = 0
    invocation = None
    c_labels = Counter()
    with zipfile.ZipFile(ARCHIVE) as archive:
        names = archive.namelist()
        assert names == ["execution-log-test-test-windows-shard-3180.zst"]
        compressed = archive.read(names[0])
        member_sha = hashlib.sha256(compressed).hexdigest()
        with zstandard.ZstdDecompressor().stream_reader(io.BytesIO(compressed)) as stream:
            while (length := varint(stream, allow_eof=True)) is not None:
                assert length <= 64 * 1024 * 1024
                raw = stream.read(length)
                assert len(raw) == length
                decoded_bytes += length
                entries += 1
                entry = fields(raw)
                payload_kinds = [kind for kind in entry if kind != 1]
                assert len(payload_kinds) == 1
                kind = payload_kinds[0]
                kinds[kind] += 1
                if kind == 2:
                    body = fields(entry[2][0])
                    invocation = {"hash_function": string(body, 1), "workspace_runfiles_directory": string(body, 2), "id": string(body, 4)}
                elif kind == 3:
                    body = fields(entry[3][0])
                    digest = fields(body[2][0]) if 2 in body else {}
                    files[number(entry, 1)] = {"path": string(body, 1), "sha256": string(digest, 1), "bytes": number(digest, 2)}
                elif kind == 7:
                    body = fields(entry[7][0])
                    args = [arg.decode("utf-8") for arg in body.get(1, [])]
                    label, mnemonic = string(body, 7), string(body, 8)
                    runner = string(body, 11)
                    mnemonics[mnemonic] += 1
                    runners[runner] += 1
                    if mnemonic == "CppCompile":
                        c_labels[label] += 1
                    native_example = mnemonic == "CppCompile" and any(arg.endswith(("/bcm.c", "/mem.c")) for arg in args)
                    dependency_build_script = "BuildScript" in mnemonic and any(part in label for part in ("zstd-sys", "libsqlite3-sys", "aws-lc-sys", "ring-"))
                    failed_provider = "rustls-provider-provider-test" in label and number(body, 9) != 0
                    if native_example or dependency_build_script or failed_provider:
                        outputs = []
                        for output_raw in body.get(6, []):
                            output = fields(output_raw)
                            if 5 in output:
                                outputs.append(files.get(number(output, 5), {"entry_id": number(output, 5)}))
                            elif 4 in output:
                                outputs.append({"invalid_output_path": string(output, 4)})
                        selected.append({"entry_ordinal": entries, "entry_id": number(entry, 1), "entry_sha256": hashlib.sha256(raw).hexdigest(), "target_label": label, "mnemonic": mnemonic, "runner": runner, "exit_code": number(body, 9), "status": string(body, 10), "cache_hit": bool(number(body, 12)), "args": args, "selected_environment": selected_environment(body), "outputs": outputs})
    result = {"scope": "Read-only decoding of original shard-2 execution log; no action replay or toolchain execution.", "run_id": 41012864494, "job_id": 123922567662, "tested_merge_commit": "f39beee703246a60be74330334c2cbcaacd85be9", "artifact_id": 12958613227, "archive_sha256": archive_sha, "member": names[0], "member_sha256": member_sha, "schema_url": "https://github.com/bazelbuild/bazel/blob/9.3.0/src/main/protobuf/spawn.proto", "schema_layout": "length-delimited ExecLogEntry, oneof spawn=7; Spawn.args=1/env_vars=2/target_label=7/mnemonic=8/exit_code=9/status=10/runner=11/cache_hit=12/outputs=6", "invocation": invocation, "entries": entries, "decoded_payload_bytes": decoded_bytes, "entry_kind_counts": dict(kinds), "mnemonic_counts": dict(mnemonics), "runner_counts": dict(runners), "c_compile_labels": dict(c_labels), "selected_actions": selected}
    output = ROOT / "windows-shard2-execution-selected.json"
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"output": str(output), "sha256": hashlib.sha256(output.read_bytes()).hexdigest(), "bytes": output.stat().st_size, "entries": entries, "decoded_payload_bytes": decoded_bytes, "mnemonics": dict(mnemonics), "runners": dict(runners), "selected": [{"entry": action["entry_ordinal"], "label": action["target_label"], "mnemonic": action["mnemonic"], "runner": action["runner"], "exit_code": action["exit_code"], "argc": len(action["args"]), "command_first": action["args"][:3], "target_arguments": [arg for arg in action["args"] if "target=" in arg or arg in ("--target", "x86_64-pc-windows-msvc") or arg.endswith(("/bcm.c", "/mem.c"))], "environment": action["selected_environment"]} for action in selected]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
