//! Fresh cold D controller INPUTS from the actual still-current Artifact owner.
//! This opens the read view only. No model publication or owner is reconstructed,
//! and an expired physical CURRENT remains an error, including Adopt after 240s.

use std::fs::OpenOptions;
use std::os::unix::fs::OpenOptionsExt;
use std::path::Path;

use codex_hepta_learning_artifacts::*;
use codex_hepta_neuron::CellBackendManifestV2;
use codex_hepta_types::Digest32;
use codex_hepta_types::StableId;
use ed25519_dalek::Signer;
use ed25519_dalek::SigningKey;
use serde_json::Value;
use serde_json::json;
use sha2::Digest;

use super::cold_next_source::OriginalDInputFiles;
use super::post_a_file::OriginalFileData;
use super::post_a_retained::RetainedOrdinaryQ24Fixture;
use super::post_a_selection::OriginalSelectedArtifactData;
use crate::authority_host_runtime::PublicationInputData;

pub(super) struct OriginalDArtifactInputs {
    pub(super) inputs: PublicationInputData,
    pub(super) selected: OriginalSelectedArtifactData,
    pub(super) writer_lease: OriginalFileData,
    pub(super) writer_lease_sha256: [u8; 32],
    pub(super) selection: OriginalFileData,
    candidate_head: OriginalFileData,
    pub(super) selection_digest: Digest32,
}

impl OriginalDArtifactInputs {
    pub(super) fn observe_and_sign(
        original: &RetainedOrdinaryQ24Fixture,
        d: &OriginalDInputFiles,
        directory: &Path,
    ) -> anyhow::Result<Self> {
        original.daemon.require_dead()?;
        original.root.require_dead()?;
        original.source.require_dead()?;
        let mut value = serde_json::to_value(&original.plan.root.publication_inputs)?;
        value["previous_journal"] = json!(original.plan.resources.c.generation_journal.path);
        value["previous_witness"] = json!(original.plan.resources.c.generation_witness.path);
        value["previous"] = serde_json::to_value(
            super::super::data::ObserverData::from_original_observer(&original.target),
        )?;
        value["target_journal"] = json!(d.generation_journal.path);
        value["target_witness"] = json!(d.generation_witness.path);
        let inputs: PublicationInputData = serde_json::from_value(value)?;
        let now = crate::authbus_ingress::now_ms()?;
        let reader = super::post_a_artifact_inputs::original_reader(&inputs, now)?;
        // This verifies the actual newest signed head at today's time. A new
        // writer lease or selector signature cannot make an expired head current.
        let current = reader.read_original_registry(now)?;
        anyhow::ensure!(
            current.receipt() == original.selected.registry,
            "cold D requires the actual retained C Artifact registry"
        );
        let registry = super::post_a_artifact_inputs::read_registry(&inputs, current.receipt())?;
        let candidate = registry
            .manifest(&original.decision.bundle.artifact_id)
            .filter(|manifest| {
                registry.is_eligible(&manifest.artifact_id)
                    && manifest.kind == ArtifactKind::Model
                    && manifest.generation == original.decision.bundle.generation
            })
            .ok_or_else(|| anyhow::anyhow!("original selected C artifact is unavailable"))?;
        let payload_path = inputs.artifact_root.join("payloads").join(format!(
            "{}-{}.bin",
            candidate.artifact_id, candidate.content_digest
        ));
        let pin = OriginalFileData::capture(&payload_path)?;
        let payload_file = OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_CLOEXEC | libc::O_NOFOLLOW)
            .open(&payload_path)?;
        pin.require_file(&payload_file)?;
        let payload = read_candidate_payload(payload_file, &registry, &candidate.artifact_id)?;
        anyhow::ensure!(
            pin.read_original(65_536)? == payload,
            "actual selected payload changed"
        );
        let manifest: CellBackendManifestV2 = serde_json::from_slice(&payload)?;
        anyhow::ensure!(
            serde_json::to_vec(&manifest)? == payload && manifest == original.selected.manifest,
            "cold D requires the exact complete selected C manifest"
        );
        crate::cell_composed_q24::validate_manifest(&original.decision.bundle, &manifest)?;
        let trust = inputs.owner_trust.original_owner_trust()?;
        let writer_key = SigningKey::from_bytes(&[61; 32]);
        let signer = trust
            .writer_signers
            .iter()
            .find(|signer| signer.signer_id.as_str() == "test-artifact-authority")
            .ok_or_else(|| anyhow::anyhow!("fixed original Artifact signer absent"))?;
        let selector_key = SigningKey::from_bytes(&[62; 32]);
        let selector = inputs
            .selector_trust
            .selectors
            .iter()
            .find(|selector| selector.id == "test-independent-selector")
            .ok_or_else(|| anyhow::anyhow!("fixed original Selector absent"))?;
        let expires = now
            .checked_add(120_000)
            .ok_or_else(|| anyhow::anyhow!("new D input expiry overflow"))?
            .min(inputs.retained_current.expires_at)
            .min(signer.expires_at)
            .min(selector.expires_at);
        anyhow::ensure!(
            now >= signer.valid_from
                && now >= selector.valid_from
                && now < expires
                && signer.revoked_at.is_none()
                && selector.revoked_at.is_none()
                && signer.verifying_key == writer_key.verifying_key().to_bytes()
                && selector.verifying_key == selector_key.verifying_key().to_bytes()
                && selector.id != candidate.producer_id.as_str(),
            "original Artifact and Selector roles, keys or current windows differ"
        );
        let initial = original.plan.profile.original_initial_data()?;
        let mut lease = SignedArtifactWriterLeaseV1 {
            lease_id: StableId::new("ordinary-cold-d-artifact-writer")?,
            producer_id: initial.owners.trainer,
            registry_id: trust.registry_id.clone(),
            withdrawal_scope_digest: trust.withdrawal_scope_digest,
            signer_id: signer.signer_id.clone(),
            signing_key_digest: Digest32::of_bytes(&writer_key.verifying_key().to_bytes()),
            authority_epoch: signer.minimum_authority_epoch,
            lease_generation: 3,
            issued_at: now,
            expires_at: expires,
            signature: [0; 64],
        };
        lease.signature = writer_key.sign(&lease.signing_bytes()).to_bytes();
        let lease_bytes = serde_json::to_vec(&json!({
            "lease_id":lease.lease_id.to_string(), "producer_id":lease.producer_id.to_string(),
            "registry_id":lease.registry_id.to_string(),
            "withdrawal_scope_digest":lease.withdrawal_scope_digest.into_array(),
            "signer_id":lease.signer_id.to_string(),
            "signing_key_digest":lease.signing_key_digest.into_array(),
            "authority_epoch":lease.authority_epoch, "lease_generation":lease.lease_generation,
            "issued_at":lease.issued_at, "expires_at":lease.expires_at,
            "signature":lease.signature.to_vec()
        }))?;
        let mut signed = SignedArtifactSelectionV1 {
            selection_id: StableId::new("ordinary-original-cold-d-selection")?,
            artifact_id: candidate.artifact_id.clone(),
            registry_id: StableId::new(&inputs.selector_trust.registry_id)?,
            withdrawal_scope_digest: Digest32::from_array(inputs.selector_trust.withdrawal_scope),
            registry_head_digest: current.receipt().head_digest,
            current_witness_digest: current.witness_digest(),
            current_trust_digest: current.trust_digest(),
            artifact_kind: candidate.kind,
            artifact_generation: candidate.generation,
            predecessor_id: candidate.predecessor_id.clone(),
            content_digest: candidate.content_digest,
            objective_digest: candidate.objective_digest,
            support_digest: candidate.support_digest,
            compatibility_digest: candidate.compatibility_digest,
            encoded_size_bytes: candidate.encoded_size_bytes,
            selector_id: StableId::new(&selector.id)?,
            selector_credential_digest: Digest32::of_bytes(b"test-selector-credential"),
            signing_key_digest: Digest32::of_bytes(&selector_key.verifying_key().to_bytes()),
            authority_epoch: selector.minimum_authority_epoch,
            issued_at: now,
            expires_at: expires,
            signature: [0; 64],
        };
        signed.signature = selector_key.sign(&signed.signing_bytes()).to_bytes();
        let verifier = inputs.selector_trust.original_selector(&trust)?;
        verifier.verify(&signed, &current, now)?;
        let withdrawals = reader.read_original_withdrawals()?;
        let mut signed_bytes = signed.signing_bytes();
        signed_bytes.extend_from_slice(&signed.signature);
        let selection_digest = Digest32::of_parts(&[
            b"hepta.agentd.generation-selection.v1\0",
            Digest32::of_bytes(&signed_bytes).as_array(),
            signed.registry_head_digest.as_array(),
            signed.current_witness_digest.as_array(),
            signed.current_trust_digest.as_array(),
            verifier.trust_digest().as_array(),
            signed.withdrawal_scope_digest.as_array(),
            withdrawals.head_digest().as_array(),
            signed.content_digest.as_array(),
            &manifest.digest()?,
        ]);
        let reserve = |name| OriginalFileData::reserve(directory.join(name), 60001, 60001);
        let writer_lease = reserve("d-artifact-writer.json")?;
        let selection = reserve("d-artifact-selection.json")?;
        let candidate_head = reserve("d-unused-artifact-candidate.json")?;
        writer_lease.write_original_once(&lease_bytes)?;
        let selection_data = super::super::data::SelectionData::from_original_selection(&signed)?;
        selection.write_original_once(&serde_json::to_vec(&selection_data)?)?;
        let after = reader.read_original_registry(crate::authbus_ingress::now_ms()?)?;
        verifier.verify(&signed, &after, crate::authbus_ingress::now_ms()?)?;
        anyhow::ensure!(
            after.receipt() == current.receipt()
                && after.witness_digest() == current.witness_digest()
                && after.trust_digest() == current.trust_digest()
                && reader.read_original_withdrawals()?.snapshot() == withdrawals.snapshot(),
            "actual Artifact CURRENT or withdrawal changed during new D signatures"
        );
        original.daemon.require_dead()?;
        original.root.require_dead()?;
        original.source.require_dead()?;
        Ok(Self {
            inputs,
            selected: OriginalSelectedArtifactData {
                selection: signed,
                manifest,
                registry: after.receipt(),
            },
            writer_lease,
            writer_lease_sha256: sha2::Sha256::digest(&lease_bytes).into(),
            selection,
            candidate_head,
            selection_digest,
        })
    }

    pub(super) fn daemon_artifact_data(&self) -> Value {
        json!({
            "writer_lease":self.writer_lease.path,
            "candidate_head":self.candidate_head.path,
            "independent_selection":self.selection.path
        })
    }
}
