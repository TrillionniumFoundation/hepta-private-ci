//! Observe exactly one new ordinary D RunStart append through the original
//! readonly parser. Old bytes and their physical inode remain the predecessor;
//! no fixture writes, recovers or locks the RunStart owner.

use std::fs::File;
use std::fs::OpenOptions;
use std::os::unix::fs::OpenOptionsExt;

use codex_hepta_learning_ledger::OriginalRunStartPrefixV1;
use codex_hepta_learning_ledger::ReadOnlyRunStartViewV1;
use codex_hepta_learning_ledger::RunStartAnchor;
use codex_hepta_learning_ledger::RunStartObjectiveDispositionV1;
use codex_hepta_learning_ledger::observe_original_run_start_prefix_v1;
use codex_hepta_objective::decode_admission_profile_json_v1;
use codex_hepta_types::Digest32;
use codex_hepta_types::StableId;
use serde_json::json;

use super::cold_next_plan::OriginalColdDPlan;
use super::post_a_file::OriginalFileData;
use crate::ObjectiveRunAdmission;

pub(super) struct OriginalDRunStartPrefix {
    pub(super) file: OriginalFileData,
    prefix: OriginalRunStartPrefixV1,
    bytes: Vec<u8>,
    profile: Digest32,
    binding: Digest32,
}

impl OriginalDRunStartPrefix {
    pub(super) fn observe(plan: &OriginalColdDPlan<'_>) -> anyhow::Result<Self> {
        let original = &plan.cold.original.plan.resources.original.plan;
        let identity = &plan.cold.administration.successor.identity;
        anyhow::ensure!(
            original.identity.home_root == identity.home_root,
            "D must use the original shared RunStart owner"
        );
        let profile = decode_admission_profile_json_v1(&super::observer::read_private(
            &original.objective_profile,
            262_144,
        )?)?
        .digest()?;
        let binding = crate::objective_runtime::run_start_binding(identity, profile);
        let file = OriginalFileData::capture(
            &identity
                .home_root
                .join("objective-run-start-v1/journal.bin"),
        )?;
        let descriptor = open_original(&file)?;
        let prefix = observe_original_run_start_prefix_v1(&descriptor, binding, 4096)?;
        let bytes = file.read_original(64 * 1024 * 1024)?;
        anyhow::ensure!(
            prefix.length == u64::try_from(bytes.len())?
                && prefix.digest == Digest32::of_bytes(&bytes)
                && prefix.length > 72,
            "original completed A/C RunStart prefix must be fully parsed"
        );
        file.require_file(&descriptor)?;
        Ok(Self {
            file,
            prefix,
            bytes,
            profile,
            binding,
        })
    }

    pub(super) fn require_single_d_append(
        &self,
        plan: &OriginalColdDPlan<'_>,
        receipt: &ObjectiveRunAdmission,
    ) -> anyhow::Result<serde_json::Value> {
        let identity = &plan.cold.administration.successor.identity;
        let request = &plan.authorization.signed_objective;
        let bytes = self.file.read_original(64 * 1024 * 1024)?;
        let start = usize::try_from(self.prefix.length)?;
        anyhow::ensure!(
            bytes.len() > start + 16 && bytes.get(..start) == Some(self.bytes.as_slice()),
            "D changed an old RunStart byte or has no actual new frame"
        );
        // This is an untrusted anchor hint from the original frame header,
        // not a second codec. The original parser below validates all frames,
        // checksums, sequence and canonical records against the real ACK.
        let sequence = u64::from_be_bytes(bytes[start + 8..start + 16].try_into()?);
        let descriptor = open_original(&self.file)?;
        let observed = observe_original_run_start_prefix_v1(&descriptor, self.binding, 4096)?;
        anyhow::ensure!(
            observed.length == u64::try_from(bytes.len())?
                && observed.digest == Digest32::of_bytes(&bytes),
            "D RunStart read changed during physical observation"
        );
        let view = ReadOnlyRunStartViewV1::open(
            descriptor,
            self.binding,
            self.profile,
            4096,
            RunStartAnchor {
                sequence,
                chain_digest: receipt.chain_digest.parse()?,
            },
        )?;
        let run = StableId::new(super::inputs::D_RUN)?;
        let frame = view
            .read_with_frame_at_original_prefix(&run, self.prefix.length, self.prefix.digest)?
            .ok_or_else(|| anyhow::anyhow!("actual D RunStart record absent"))?;
        let record = &frame.observed.record;
        let auth = &record.authentication;
        let claims = crate::authbus_objective_claims(identity, request)?;
        let original = &plan.cold.original.plan.resources.original.plan;
        let trust_bytes = super::observer::read_private(&original.objective_trust, 16_384)?;
        let trust = crate::authbus_trust::TextTrust::from_original_bytes(&trust_bytes, identity)?;
        anyhow::ensure!(
            frame.frame_start == self.prefix.length
                && frame.frame_end == frame.observed_length
                && frame.observed_length == observed.length
                && frame.observed.publication.sequence == sequence
                && frame.observed.publication.record_digest.to_string()
                    == receipt.publication_digest
                && frame.observed.publication.chain_digest.to_string() == receipt.chain_digest
                && record.snapshot.run_id == run
                && record.snapshot.objective_digest.to_string() == receipt.objective_digest
                && record.snapshot.hard_constraint_digest.to_string()
                    == receipt.hard_constraint_digest
                && record.snapshot.model_tuple_digest.to_string()
                    == request.body.model_tuple_digest
                && record.snapshot.artifact_set_digest.to_string()
                    == request.body.artifact_set_digest
                && record.disposition == RunStartObjectiveDispositionV1::Compiled
                && record.admission.profile_digest == self.profile
                && auth.issuer_id.as_str() == request.issuer_id
                && auth.key_epoch == request.key_epoch
                && auth.message_id.as_str() == request.message_id
                && auth.sequence == request.sequence
                && auth.expires_at_ms == request.expires_at_ms
                && auth.scope_digest == claims.scope_digest
                && auth.signed_body_digest == claims.payload_digest
                && auth.signature == crate::authbus_trust::hex_bytes::<64>(&request.signature_hex)?
                && crate::objective_runtime::run_start_matches_original_publisher(
                    identity,
                    &record.snapshot,
                )
                && crate::objective_runtime::authentication_is_current(
                    record,
                    &trust,
                    identity,
                    crate::authbus_ingress::now_ms()?,
                )?,
            "D requires one original compiled, currently authenticated RunStart with exact ACK"
        );
        anyhow::ensure!(
            view.read_with_frame_at_original_prefix(&run, self.prefix.length, self.prefix.digest,)?
                == Some(frame.clone())
                && self.file.read_original(64 * 1024 * 1024)? == bytes,
            "D original RunStart observation changed"
        );
        Ok(json!({
            "old_prefix_bytes":self.prefix.length,
            "old_prefix_digest":self.prefix.digest.to_string(),
            "new_total_bytes":frame.observed_length,
            "actual_publication_sequence":sequence,
            "actual_publication_digest":frame.observed.publication.record_digest.to_string(),
            "actual_chain_digest":frame.observed.publication.chain_digest.to_string(),
            "run_id":record.snapshot.run_id.as_str(),
            "original_spawn_generation":identity.spawn_generation,
            "one_appended_frame":true
        }))
    }
}

fn open_original(file: &OriginalFileData) -> anyhow::Result<File> {
    let descriptor = OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
        .open(&file.path)?;
    file.require_file(&descriptor)?;
    Ok(descriptor)
}
