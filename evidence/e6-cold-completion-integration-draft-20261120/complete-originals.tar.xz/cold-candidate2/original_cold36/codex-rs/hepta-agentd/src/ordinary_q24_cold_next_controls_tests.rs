//! Exact authorized C-to-D state delta. All old learning and C files remain
//! unchanged; the shared RunStart prefix and one consumer nonce are checked
//! through their original typed readers after the real process exits.

use std::path::PathBuf;
use std::sync::Arc;

use codex_hepta_contracts::AuthorityFrontierStore;
use codex_hepta_contracts::FinalUseFrontier;
use codex_hepta_contracts::FinalUseIssuerTrustKey;
use codex_hepta_contracts::HostAuthorityFrontierStore;
use codex_hepta_contracts::RootAuthorityDirectory;
use codex_hepta_contracts::RootFinalUseObserverV1;
use codex_hepta_types::Digest32;
use serde_json::json;

use super::cold_next_plan::OriginalColdDPlan;
use super::cold_next_run_start::OriginalDRunStartPrefix;
use super::cold_successor_data::OriginalColdSuccessorData;
use super::post_a_file::OriginalFileData;
use crate::neuron_generation_current::types::CurrentHead;
use crate::ordinary_q24_cold_snapshot_tests::OriginalBusinessSnapshot;

pub(super) struct OriginalDControlEvidence {
    pub(super) run_start: OriginalDRunStartPrefix,
    old_files: Vec<PathBuf>,
    old_business: OriginalBusinessSnapshot,
    fixed_files: Vec<PathBuf>,
    fixed_inputs: OriginalBusinessSnapshot,
    controls: Vec<PathBuf>,
    control_business: OriginalBusinessSnapshot,
    claims: OriginalFileData,
    previous_claims: Vec<u8>,
    frontier: Arc<HostAuthorityFrontierStore<FinalUseFrontier>>,
    previous_frontier: FinalUseFrontier,
    consumer: RootFinalUseObserverV1,
    signer: String,
}

impl OriginalDControlEvidence {
    pub(super) fn observe(
        plan: &OriginalColdDPlan<'_>,
        successor: &OriginalColdSuccessorData,
    ) -> anyhow::Result<Self> {
        let original = plan.cold.original;
        let run_start = OriginalDRunStartPrefix::observe(plan)?;
        let mut old_files = original.business_files();
        let old_count = old_files.len();
        old_files.retain(|path| path != &run_start.file.path);
        anyhow::ensure!(
            old_files.len() + 1 == old_count,
            "exact shared RunStart exception"
        );
        let old_business = OriginalBusinessSnapshot::capture(&old_files)?;
        let mut fixed_files = vec![
            plan.inputs.source_configuration.path.clone(),
            plan.inputs.target_configuration.path.clone(),
            plan.inputs.signed_ingress.path.clone(),
            plan.inputs.publication_material.path.clone(),
            plan.artifacts.selection.path.clone(),
            plan.artifacts.writer_lease.path.clone(),
            plan.deployment.clone(),
        ];
        fixed_files.extend(plan.authorization.original_paths());
        let fixed_inputs = OriginalBusinessSnapshot::capture(&fixed_files)?;
        let config: crate::HostAuthorityServiceConfig = serde_json::from_slice(
            &super::observer::read_private(&plan.cold.administration.successor.service, 16_384)?,
        )?;
        let slots = config
            .consumers
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("actual D Root consumers absent"))?;
        let (slot, name) = match plan.artifacts.inputs.consumer {
            crate::RootPublicationFinalUseConsumerV1::Device => (&slots.device, "device"),
            crate::RootPublicationFinalUseConsumerV1::Notes => (&slots.notes, "notes"),
        };
        anyhow::ensure!(
            plan.artifacts.inputs.consumer == plan.expected.consumer
                && slot.owner_id == config.signer_id
                && config.peer_uid == 60001,
            "actual D must retain the independently enrolled original consumer"
        );
        let local = plan.artifacts.inputs.consumer_state_root.join(name);
        let claims = OriginalFileData::capture(&local.join("authority.claims"))?;
        let previous_claims = claims.read_original(8 * 1024 * 1024)?;
        anyhow::ensure!(
            !previous_claims.is_empty() && previous_claims.len() % 40 == 0,
            "actual previous FinalUse journal framing"
        );
        let current_owner = format!(
            "cell-generation/{}",
            crate::neuron_generation_current::types::scope_digest(
                plan.authorization.intent.target.scope(),
            )?
        );
        let current_path = frontier_path(&plan.artifacts.inputs.current_directory, &current_owner);
        let consumer_path = frontier_path(&slot.state_dir, &slot.owner_id);
        let before_paths = successor.original_control_paths();
        let changes = [current_path, consumer_path.clone(), claims.path.clone()];
        anyhow::ensure!(
            changes.iter().all(|path| before_paths.contains(path)),
            "D must advance the exact original CURRENT and consumer paths"
        );
        let mut controls = before_paths;
        controls.retain(|path| !changes.contains(path));
        let control_business = OriginalBusinessSnapshot::capture(&controls)?;
        // Require both physical frontier files before the original store API;
        // this readback may not initialize a missing Root record or lock.
        let frontier_files = [
            consumer_path.clone(),
            consumer_path.with_file_name(format!(
                "{}.lock",
                consumer_path.file_name().unwrap().to_string_lossy(),
            )),
        ];
        let before = OriginalBusinessSnapshot::capture(&frontier_files)?;
        let frontier = Arc::new(HostAuthorityFrontierStore::<FinalUseFrontier>::open(
            RootAuthorityDirectory::open(&slot.state_dir)?,
            slot.owner_id.clone(),
        )?);
        let previous_frontier = frontier.load(&slot.owner_id)?;
        let issuer_keys = plan
            .artifacts
            .inputs
            .issuer_keys
            .iter()
            .map(|key| FinalUseIssuerTrustKey {
                key_id: key.key_id.clone(),
                verifying_key: key.verifying_key,
                not_before_authority_epoch: key.not_before_authority_epoch,
                not_after_authority_epoch: key.not_after_authority_epoch,
            })
            .collect();
        let consumer = RootFinalUseObserverV1::open_original(
            &local,
            config.peer_uid,
            slot.owner_id.clone(),
            issuer_keys,
            frontier.clone(),
        )?;
        let c = original
            .completed
            .current
            .published
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("actual C publication absent"))?;
        consumer.verify_original_retained_use(&c.signed, &c.intent.binding()?, &c.witness)?;
        anyhow::ensure!(
            consumer.issuer_trust_digest() == plan.expected.consumer_trust.into_array(),
            "actual C/D consumer issuer trust differs"
        );
        before.require_unchanged(&frontier_files)?;
        old_business.require_unchanged(&old_files)?;
        fixed_inputs.require_unchanged(&fixed_files)?;
        control_business.require_unchanged(&controls)?;
        Ok(Self {
            run_start,
            old_files,
            old_business,
            fixed_files,
            fixed_inputs,
            controls,
            control_business,
            claims,
            previous_claims,
            frontier,
            previous_frontier,
            consumer,
            signer: slot.owner_id.clone(),
        })
    }

    pub(super) fn require_immutable(
        &self,
        original: &super::post_a_retained::RetainedOrdinaryQ24Fixture,
    ) -> anyhow::Result<()> {
        original.daemon.require_dead()?;
        original.root.require_dead()?;
        original.source.require_dead()?;
        let mut expected = original.business_files();
        expected.retain(|path| path != &self.run_start.file.path);
        anyhow::ensure!(expected == self.old_files, "old business path set changed");
        self.old_business.require_unchanged(&self.old_files)?;
        self.fixed_inputs.require_unchanged(&self.fixed_files)?;
        self.control_business.require_unchanged(&self.controls)
    }

    pub(super) fn require_actual_d_consumption(
        &self,
        plan: &OriginalColdDPlan<'_>,
        current: &CurrentHead,
    ) -> anyhow::Result<serde_json::Value> {
        self.require_immutable(plan.cold.original)?;
        let published = current
            .published
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("actual D publication absent"))?;
        let old = plan
            .cold
            .original
            .completed
            .current
            .published
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("actual C publication absent"))?;
        anyhow::ensure!(
            published.intent == plan.authorization.intent
                && published.signed.grant.binding == published.intent.binding()?
                && published.signed.grant.nonce != old.signed.grant.nonce
                && published.signed.grant.grant_id != old.signed.grant.grant_id
                && published.signed_grant_digest != old.signed_grant_digest
                && published.signed.grant.expires_at_unix_ms
                    <= plan.authorization.authorization.expires_at_ms,
            "D must consume its distinct exact-intent FinalUse within new authorization"
        );
        let mut expected = self.previous_claims.clone();
        expected.extend_from_slice(&published.signed.grant.authority_epoch.to_be_bytes());
        expected.extend_from_slice(&published.signed.grant.nonce);
        anyhow::ensure!(
            self.claims.read_original(8 * 1024 * 1024)? == expected,
            "D must append exactly one actual nonce and preserve all old consumer bytes"
        );
        let revocations = self.consumer.verify_original_retained_use(
            &published.signed,
            &published.intent.binding()?,
            &published.witness,
        )?;
        // Old C remains a consumed historical fact under the current epoch and
        // revocations. This neither reuses nor makes its expired grant fresh.
        self.consumer.verify_original_retained_use(
            &old.signed,
            &old.intent.binding()?,
            &old.witness,
        )?;
        let after = self.frontier.load(&self.signer)?;
        anyhow::ensure!(
            after.authority_epoch == self.previous_frontier.authority_epoch
                && after.revocation_revision == self.previous_frontier.revocation_revision
                && after.state_sha256 != self.previous_frontier.state_sha256
                && revocations.authority_epoch == published.signed.grant.authority_epoch
                && self.claims.read_original(8 * 1024 * 1024)? == expected
                && self.frontier.load(&self.signer)? == after,
            "actual D consumer Root frontier or nonce readback differs"
        );
        self.require_immutable(plan.cold.original)?;
        Ok(json!({
            "previous_claim_bytes":self.previous_claims.len(),
            "actual_claim_bytes":expected.len(),
            "new_nonce_claims":1,
            "actual_grant":published.signed,
            "actual_witness":published.witness,
            "current_revocations":revocations,
            "old_business_files_unchanged":self.old_files,
            "old_control_files_unchanged":self.controls
        }))
    }
}

fn frontier_path(directory: &std::path::Path, owner: &str) -> PathBuf {
    directory.join(format!(
        "frontier-v1-{}.json",
        Digest32::of_bytes(owner.as_bytes())
    ))
}
