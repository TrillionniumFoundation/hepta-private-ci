//! Real protected Root store and real joint issuer/writer context, with a live
//! UID60001 pidfd. C/intent values here are explicitly DATA fixtures: this
//! component issues no FinalUse and claims no C completion or D execution.

use super::*;
use crate::cold_next_task_protocol::MAX_REQUESTS;
use pretty_assertions::assert_eq;
use std::time::Duration;
use std::time::Instant;

fn profile_data(
    context: &OriginalColdNextTaskContextV1<'_>,
    label: &str,
) -> io::Result<ColdNextTaskProfileV1> {
    let mut profile =
        crate::cold_next_task_protocol::component_cold_profile_data().map_err(io::Error::other)?;
    profile.identity = crate::neuron_generation_process_identity_digest_v1(context.identity())
        .map_err(io::Error::other)?
        .to_string();
    profile.original_c.identity_digest = profile.identity.clone();
    profile.writer = context.writer_proof()?;
    profile.original_c.successor_record = Digest32::of_bytes(label.as_bytes()).to_string();
    profile.valid_until_ms = context.valid_until_ms();
    profile.binding = profile.digest()?;
    profile.require_data()?;
    Ok(profile)
}

fn request(profile: &ColdNextTaskProfileV1, sequence: u64) -> ColdNextTaskRequestV1 {
    ColdNextTaskRequestV1 {
        schema: 1,
        purpose: COLD_PURPOSE.into(),
        request_id: sequence,
        profile: profile.binding.clone(),
        command: ColdNextTaskCommandV1::Observe,
    }
}

pub(crate) fn qualify_original_cold_operation_store(
    config: &HostAuthorityServiceConfig,
    other_config: &HostAuthorityServiceConfig,
    registration: &HostAuthorityRegistration,
    owner: &OwnedFd,
    root: Arc<RootAuthorityDirectory>,
) -> io::Result<()> {
    original_root()?;
    let (clock, leases, issuer) = crate::authority_host_runtime::open_registered_issuer(config)?;
    let service = HostAuthorityService::from_registered_owner(
        issuer,
        clock,
        registration.registered_identity.identity()?,
    )?
    .with_registered_writer(
        config
            .writer
            .clone()
            .ok_or_else(|| io::Error::other("original registered writer required"))?,
        leases.verifier(),
    )?;
    // The actual original registry remains exclusively locked. A second open
    // of its state is a real refusal, not another operation context.
    match crate::authority_host_runtime::open_registered_issuer(config) {
        Ok(_) => return Err(io::Error::other("original registry was not exclusive")),
        Err(error) => assert_eq!(error.to_string(), "StateLocked"),
    }
    // A separately initialized and registered protected authority supplies a
    // second live context for the same actual identity and pidfd. No owner
    // bytes or issuer state are copied, and the first mutex is never reentered.
    assert_ne!(other_config.state_dir, config.state_dir);
    assert_ne!(
        other_config.expected_verifying_key,
        config.expected_verifying_key
    );
    assert_eq!(other_config.writer, config.writer);
    let (other_clock, other_leases, other_issuer) =
        crate::authority_host_runtime::open_registered_issuer(other_config)?;
    let other_service = HostAuthorityService::from_registered_owner(
        other_issuer,
        other_clock,
        registration.registered_identity.identity()?,
    )?
    .with_registered_writer(
        other_config
            .writer
            .clone()
            .ok_or_else(|| io::Error::other("second original registered writer required"))?,
        other_leases.verifier(),
    )?;
    let end = Instant::now() + Duration::from_millis(config.lifetime_ms);
    service.with_cold_next_task_context(config, registration, owner, end, |context| {
        let check = || context.require_current().map(|_| ());
        let profile = profile_data(context, "actual-store-sequence")?;
        let operation = RegisteredColdNextTaskOperationV1::create_original(
            Arc::clone(&root), profile.clone(),
        )?;
        let initial = operation.load_original()?;
        assert!(operation.with_operation(&request(&profile, 2), context, &check, |_| Ok(())).is_err());
        assert_eq!(operation.load_original()?, initial);
        let other = RegisteredColdNextTaskOperationV1::create_original(
            Arc::clone(&root), profile_data(context, "actual-other-store")?,
        )?;
        for sequence in 1..=MAX_REQUESTS {
            let frame = request(&profile, sequence);
            operation.with_operation(&frame, context, &check, |attempt| {
                attempt.require_original(context, &operation, &frame)?;
                if sequence == 1 {
                    other_service.with_cold_next_task_context(
                        other_config, registration, owner, end, |other_context| {
                            assert_eq!(other_context.identity(), context.identity());
                            assert_ne!(other_context.writer_proof()?, context.writer_proof()?);
                            assert!(
                                attempt.require_original(other_context, &operation, &frame).is_err(),
                                "the same identity cannot substitute another live context"
                            );
                            other_context.require_current()?;
                            Ok(())
                        },
                    )?;
                    let other_frame = request(&other.profile, 1);
                    other.with_operation(&other_frame, context, &check, |other_attempt| {
                        other_attempt.require_original(context, &other, &other_frame)?;
                        assert!(attempt.require_original(context, &other, &other_frame).is_err());
                        assert!(other_attempt.require_original(context, &operation, &frame).is_err());
                        Ok(())
                    })?;
                    attempt.require_original(context, &operation, &frame)?;
                }
                // Actual distinct stores and distinct request objects, including
                // byte-identical JSON, cannot borrow this Armed operation.
                assert!(attempt.require_original(context, &other, &frame).is_err());
                let equal_frame = frame.clone();
                assert_eq!(equal_frame.digest()?, frame.digest()?);
                assert!(attempt.require_original(context, &operation, &equal_frame).is_err());
                assert!(attempt.begin_final_use().is_err());
                assert!(attempt.require_attempted().is_err());
                Ok(())
            })?;
            assert_eq!(operation.load_original()?.operation,
                OperationPhase::Ready { next_request_id: sequence + 1 });
            assert_eq!(operation.load_original()?.grant, GrantPhase::Available {});
        }
        let exhausted = operation.load_original()?;
        for sequence in [1, MAX_REQUESTS, MAX_REQUESTS + 1] {
            assert!(operation.with_operation(&request(&profile, sequence), context, &check, |_| Ok(())).is_err());
            assert_eq!(operation.load_original()?, exhausted);
        }
        let mut replacement = profile.clone();
        replacement.intent.operation_id.push_str("-new-operation-id");
        replacement.binding = replacement.digest()?;
        replacement.require_data()?;
        assert!(RegisteredColdNextTaskOperationV1::create_original(Arc::clone(&root), replacement).is_err());
        assert_eq!(operation.load_original()?, exhausted);

        // A real callback error leaves the original durable Armed frame.
        let failed_profile = profile_data(context, "actual-callback-error")?;
        let failed = RegisteredColdNextTaskOperationV1::create_original(Arc::clone(&root), failed_profile.clone())?;
        let failed_frame = request(&failed_profile, 1);
        let failure = failed.with_operation(&failed_frame, context, &check, |_| {
            Err::<(), _>(io::Error::other("original component physical callback failed"))
        }).expect_err("actual callback failure must survive postchecks");
        assert!(failure.to_string().contains("original component physical callback failed"));
        let retained = failed.load_original()?;
        assert!(matches!(retained.operation, OperationPhase::Armed { request_id: 1, .. }));
        assert_eq!(retained.grant, GrantPhase::Available {});
        assert!(failed.with_operation(&failed_frame, context, &check, |_| Ok(())).is_err());
        assert_eq!(failed.load_original()?, retained);
        assert!(RegisteredColdNextTaskOperationV1::create_original(Arc::clone(&root), failed_profile).is_err());

        // Durable Attempted is reached, but the test never calls an issuer.
        // The original nonce cannot be retried after an uncertain callback.
        let attempted_profile = profile_data(context, "actual-attempted-without-issuer")?;
        let attempted = RegisteredColdNextTaskOperationV1::create_original(Arc::clone(&root), attempted_profile.clone())?;
        let mut frame = request(&attempted_profile, 1);
        frame.command = ColdNextTaskCommandV1::IssueFinalUse {
            expected: attempted_profile.original_c.current_head.clone(),
            intent: attempted_profile.intent.digest().map_err(io::Error::other)?.to_string(),
        };
        let outcome = attempted.with_operation(&frame, context, &check, |attempt| {
            attempt.begin_final_use()?;
            attempt.require_attempted()?;
            assert!(attempt.begin_final_use().is_err());
            Err::<(), _>(io::Error::other("controlled failure before any issuer"))
        });
        assert!(outcome.expect_err("uncertain Attempted must fail").to_string().contains("controlled failure before any issuer"));
        let retained = attempted.load_original()?;
        assert_eq!(retained.grant, GrantPhase::Attempted {});
        assert!(matches!(retained.operation, OperationPhase::Armed { request_id: 1, .. }));
        assert!(attempted.with_operation(&frame, context, &check, |_| Ok(())).is_err());
        assert_eq!(attempted.load_original()?, retained);
        assert!(RegisteredColdNextTaskOperationV1::create_original(Arc::clone(&root), attempted_profile).is_err());

        // Stale and interrupted physical store CAS does not receive an ACK.
        let cas_profile = profile_data(context, "actual-stale-store-cas")?;
        let cas = RegisteredColdNextTaskOperationV1::create_original(Arc::clone(&root), cas_profile.clone())?;
        let stale = cas.load_original()?;
        let frame = request(&cas_profile, 1);
        let outcome = cas.with_operation(&frame, context, &check, |_attempt| {
            let mut stale_next = stale.clone();
            stale_next.operation = OperationPhase::Ready { next_request_id: 55 };
            assert!(cas.store.compare_and_set(&cas.owner, &stale, &stale_next).is_err());
            let armed = cas.load_original()?;
            let mut partial = armed.clone();
            partial.operation = OperationPhase::Ready { next_request_id: 2 };
            cas.store.compare_and_set(&cas.owner, &armed, &partial).map_err(io::Error::other)?;
            Ok(())
        });
        assert!(outcome.is_err());
        assert_eq!(cas.load_original()?.operation, OperationPhase::Ready { next_request_id: 2 });
        assert!(cas.with_operation(&frame, context, &check, |_| Ok(())).is_err());
        println!(
            "ROOT_COLD_STORE_ACTUAL bound={} live_peer_pid={} requests={} cross_store_refused=true identical_frame_refused=true simultaneous_armed_owner_refused=true same_identity_distinct_context_refused=true callback_error_retained=true attempted_without_issuer_retained=true stale_cas_refused=true partial_cas_no_ack=true new_nonce_issuances=0 actual_c_completion=0 actual_d_execution=0",
            config.required_bind.mountpoint.display(), registration.peer_pid, MAX_REQUESTS,
        );
        Ok(())
    })
}
