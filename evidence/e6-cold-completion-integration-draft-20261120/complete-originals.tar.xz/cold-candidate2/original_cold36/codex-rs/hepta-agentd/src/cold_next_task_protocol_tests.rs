//! DATA-boundary negatives only. These fixtures create no Root, owner, grant
//! admission or consumed nonce; the native lane must independently verify all
//! physical authorities and the real consumer before issuance/publication.

use super::*;
use crate::authority_host_service::generation_publication::head_digest;
use crate::neuron_generation_current::types::Published;
use codex_hepta_contracts::FinalUseGrant;
use codex_hepta_contracts::FinalUseWitnessRefV1;
use codex_hepta_neuron::CellGenerationOwnerBindingV1;
use ed25519_dalek::Signer;
use ed25519_dalek::SigningKey;
use pretty_assertions::assert_eq;

struct DataFixture {
    profile: ColdNextTaskProfileV1,
    original_c: CurrentHead,
    prepared: CurrentHead,
    published: CurrentHead,
}

impl DataFixture {
    fn new() -> anyhow::Result<Self> {
        let c = crate::neuron_generation_current::test_support::config()?;
        let mut d = c.clone();
        d.initial.scope.run_id = "cold-new-D".into();
        d.initial.generation += 1;
        d.initial.writer_epoch += 1;
        d.task_digest = [22; 32];
        d.source_frontier = [23; 32];
        let previous = CellGenerationOwnerBindingV1::new(&c, /*max_records*/ 128)?;
        let target = CellGenerationOwnerBindingV1::new(&d, /*max_records*/ 128)?;
        let intent = UpdateIntent {
            operation_id: "cold-next-D".into(),
            supersedes: None,
            previous: previous.clone(),
            previous_checkpoint: [24; 32],
            previous_observation: [25; 32],
            genesis_checkpoint: target.genesis_checkpoint().into_array(),
            target: target.clone(),
            selection: [26; 32],
            completion: NeuronGenerationPredecessorCompletionV1::OwnerDrainedSameModel,
        };
        let original_c = CurrentHead {
            schema_version: 1,
            current: previous,
            prepared: None,
            published: None,
            initial: None,
        };
        let identity = Digest32::from_array([27; 32]).to_string();
        let data = Digest32::from_array([28; 32]).to_string();
        let mut profile = ColdNextTaskProfileV1 {
            purpose: PURPOSE.into(),
            identity: identity.clone(),
            writer: data.clone(),
            original_c: OriginalQ24CompletedHistoryDataV1 {
                schema: 1,
                identity_digest: identity,
                root_profile: data.clone(),
                initial: data.clone(),
                frozen_scope: data.clone(),
                terminal_head: data.clone(),
                acceptance: data.clone(),
                current_head: head_digest(&original_c)?,
                successor_record: data.clone(),
                successor_cut: data.clone(),
            },
            previous_files: data.clone(),
            target_files: data.clone(),
            configuration: data.clone(),
            artifacts: data.clone(),
            controller: data.clone(),
            authorization_binding: data.clone(),
            authorization: data.clone(),
            authorization_id: "cold-D-authorization".into(),
            objective: data.clone(),
            objective_id: "cold-D-objective".into(),
            consumer: RootPublicationFinalUseConsumerV1::Device,
            consumer_trust: data,
            valid_until_ms: 2_000,
            manifest: c.manifest,
            intent,
            binding: String::new(),
        };
        profile.binding = profile.digest()?;
        profile.require_data()?;
        let prepared = CurrentHead {
            prepared: Some(profile.intent.clone()),
            ..original_c.clone()
        };
        let grant = FinalUseGrant {
            schema_version: 1,
            signer_id: "cold-data-issuer".into(),
            authority_epoch: 1,
            grant_id: "cold-D-grant".into(),
            nonce: [29; 32],
            binding: profile.intent.binding()?,
            not_before_unix_ms: 1_000,
            expires_at_unix_ms: 2_000,
        };
        let signed = SignedFinalUseGrant {
            signature: SigningKey::from_bytes(&[98; 32])
                .sign(&grant.signing_bytes()?)
                .to_bytes()
                .to_vec(),
            grant,
        };
        let binding_sha256 = Digest32::of_parts(&[
            b"hepta.kernel.authority.verified-use-binding.final-use.v1\0",
            &serde_json::to_vec(&signed.grant.binding)?,
        ])
        .into_array();
        let witness = VerifiedUseTokenWitnessV1 {
            schema_version: 1,
            authority_epoch: 1,
            verified_at_unix_ms: 1_001,
            boundary: VerifiedUseBoundaryV1::DispatchEntry,
            authority_ref: VerifiedUseAuthorityRefV1::FinalUse(FinalUseWitnessRefV1 {
                signer_id: signed.grant.signer_id.clone(),
                grant_id: signed.grant.grant_id.clone(),
                revocation_revision: 1,
                binding_sha256,
            }),
        };
        let published = CurrentHead {
            schema_version: 1,
            current: target,
            prepared: None,
            initial: None,
            published: Some(Published {
                intent: profile.intent.clone(),
                witness,
                signed_grant_digest: crate::neuron_generation_current::signed_grant_digest(
                    &signed,
                )?
                .into_array(),
                signed,
            }),
        };
        Ok(Self {
            profile,
            original_c,
            prepared,
            published,
        })
    }

    fn request(&self, command: ColdNextTaskCommandV1, request_id: u64) -> ColdNextTaskRequestV1 {
        ColdNextTaskRequestV1 {
            schema: 1,
            purpose: PURPOSE.into(),
            request_id,
            profile: self.profile.binding.clone(),
            command,
        }
    }

    fn response(
        &self,
        request: &ColdNextTaskRequestV1,
        head: CurrentHead,
    ) -> anyhow::Result<ColdNextTaskResponseV1> {
        Ok(ColdNextTaskResponseV1 {
            schema: 1,
            purpose: PURPOSE.into(),
            request_id: request.request_id,
            request: request.digest()?,
            profile: self.profile.clone(),
            head,
            predecessor: None,
            grant: None,
        })
    }
}

#[test]
fn cold_next_task_protocol_preserves_exact_c_before_and_after_own_prepare() -> anyhow::Result<()> {
    let f = DataFixture::new()?;
    f.profile.require_head_data(&f.original_c)?;
    f.profile.require_head_data(&f.prepared)?;
    let mut changed = f.prepared.clone();
    changed.published = f.published.published.clone();
    assert!(f.profile.require_head_data(&changed).is_err());
    let mut changed = f.prepared.clone();
    changed.prepared.as_mut().unwrap().previous_checkpoint = [99; 32];
    assert!(f.profile.require_head_data(&changed).is_err());
    let mut stripped = f.prepared;
    stripped.prepared = None;
    assert_eq!(stripped, f.original_c);
    Ok(())
}

#[test]
fn cold_next_task_protocol_binds_request_operation_and_original_64_boundary() -> anyhow::Result<()>
{
    let f = DataFixture::new()?;
    for request_id in [1, 64] {
        let request = f.request(ColdNextTaskCommandV1::Observe, request_id);
        f.response(&request, f.original_c.clone())?
            .require_data(&request)?;
    }
    let mut request = f.request(ColdNextTaskCommandV1::Observe, /*request_id*/ 1);
    request.profile.clear();
    let response = f.response(&request, f.original_c.clone())?;
    response.require_data(&request)?;
    for request_id in [0, 2, 65] {
        let mut changed = request.clone();
        changed.request_id = request_id;
        assert!(
            f.response(&changed, f.original_c.clone())?
                .require_data(&changed)
                .is_err()
        );
    }
    let mut changed = request.clone();
    changed.command = ColdNextTaskCommandV1::ReadPredecessor;
    assert!(response.require_data(&changed).is_err());
    let mut changed = response.clone();
    changed.request_id += 1;
    assert!(changed.require_data(&request).is_err());
    Ok(())
}

#[test]
fn cold_next_task_protocol_requires_new_task_and_same_complete_selected_model() -> anyhow::Result<()>
{
    let f = DataFixture::new()?;
    let original = serde_json::to_value(&f.profile)?;
    for (field, value) in [
        (
            "scope",
            serde_json::to_value(f.profile.intent.previous.scope())?,
        ),
        (
            "task_digest",
            serde_json::json!(f.profile.intent.previous.task_digest()),
        ),
        ("manifest_digest", serde_json::to_value([99_u8; 32])?),
        (
            "generation",
            serde_json::json!(f.profile.intent.previous.generation()),
        ),
        (
            "writer_epoch",
            serde_json::json!(f.profile.intent.previous.writer_epoch()),
        ),
    ] {
        let mut changed = original.clone();
        changed["intent"]["target"][field] = value;
        let mut profile: ColdNextTaskProfileV1 = serde_json::from_value(changed)?;
        profile.binding = profile.digest()?;
        assert!(profile.require_data().is_err(), "{field}");
    }
    Ok(())
}

#[test]
fn cold_next_task_protocol_prepare_and_issue_require_exact_cas() -> anyhow::Result<()> {
    let f = DataFixture::new()?;
    let mut request = f.request(
        ColdNextTaskCommandV1::Prepare {
            expected: head_digest(&f.original_c)?,
            intent: f.profile.intent.digest()?.to_string(),
        },
        /*request_id*/ 2,
    );
    f.response(&request, f.prepared.clone())?
        .require_data(&request)?;
    assert!(
        f.response(&request, f.original_c.clone())?
            .require_data(&request)
            .is_err()
    );
    if let ColdNextTaskCommandV1::Prepare { expected, .. } = &mut request.command {
        *expected = Digest32::from_array([99; 32]).to_string();
    }
    assert!(
        f.response(&request, f.prepared.clone())?
            .require_data(&request)
            .is_err()
    );
    let mut request = f.request(
        ColdNextTaskCommandV1::IssueFinalUse {
            expected: head_digest(&f.prepared)?,
            intent: f.profile.intent.digest()?.to_string(),
        },
        /*request_id*/ 3,
    );
    let mut response = f.response(&request, f.prepared.clone())?;
    response.grant = Some(f.published.published.as_ref().unwrap().signed.clone());
    response.require_data(&request)?;
    if let ColdNextTaskCommandV1::IssueFinalUse { expected, .. } = &mut request.command {
        *expected = head_digest(&f.original_c)?;
    }
    response.request = request.digest()?;
    assert!(response.require_data(&request).is_err());
    Ok(())
}

#[test]
fn cold_next_task_protocol_requires_full_published_grant_witness_correlation() -> anyhow::Result<()>
{
    let f = DataFixture::new()?;
    f.profile.require_head_data(&f.published)?;
    let original = serde_json::to_value(&f.published)?;
    let changes = [
        (
            "/published/witness/boundary",
            serde_json::json!("consumer_entry"),
        ),
        ("/published/witness/authority_epoch", serde_json::json!(2)),
        (
            "/published/witness/verified_at_unix_ms",
            serde_json::json!(2_000),
        ),
        (
            "/published/witness/authority_ref/authority/grant_id",
            serde_json::json!("old-C-grant"),
        ),
        (
            "/published/witness/authority_ref/authority/signer_id",
            serde_json::json!("other-issuer"),
        ),
        (
            "/published/witness/authority_ref/authority/binding_sha256",
            serde_json::to_value([99_u8; 32])?,
        ),
        (
            "/published/signed/grant/expires_at_unix_ms",
            serde_json::json!(2_001),
        ),
        (
            "/published/signed/grant/binding/request_sha256",
            serde_json::to_value([99_u8; 32])?,
        ),
        ("/published/signed/signature", serde_json::json!([1, 2])),
        (
            "/published/signed_grant_digest",
            serde_json::to_value([99_u8; 32])?,
        ),
    ];
    for (pointer, value) in changes {
        let mut changed = original.clone();
        *changed.pointer_mut(pointer).expect("original DATA field") = value;
        let head: CurrentHead = serde_json::from_value(changed)?;
        assert!(f.profile.require_head_data(&head).is_err(), "{pointer}");
    }
    Ok(())
}

#[test]
fn cold_next_task_protocol_publish_ack_must_match_exact_original_request() -> anyhow::Result<()> {
    let f = DataFixture::new()?;
    let published = f.published.published.as_ref().unwrap();
    let mut request = f.request(
        ColdNextTaskCommandV1::Publish {
            expected: head_digest(&f.prepared)?,
            intent: f.profile.intent.digest()?.to_string(),
            signed: published.signed.clone(),
            witness: published.witness.clone(),
        },
        /*request_id*/ 4,
    );
    let mut response = f.response(&request, f.published.clone())?;
    response.require_data(&request)?;
    if let ColdNextTaskCommandV1::Publish { signed, .. } = &mut request.command {
        signed.grant.grant_id = "another-D-grant".into();
    }
    response.request = request.digest()?;
    assert!(response.require_data(&request).is_err());
    request.command = ColdNextTaskCommandV1::Observe;
    response.grant = Some(published.signed.clone());
    response.request = request.digest()?;
    assert!(response.require_data(&request).is_err());
    Ok(())
}

#[test]
fn cold_next_task_protocol_rejects_oversized_unknown_and_duplicate_frames() -> anyhow::Result<()> {
    let f = DataFixture::new()?;
    let request = f.request(ColdNextTaskCommandV1::Observe, /*request_id*/ 1);
    let original = serde_json::to_vec(&request)?;
    let parsed: ColdNextTaskRequestV1 = serde_json::from_slice(&original)?;
    assert_eq!(parsed.digest()?, request.digest()?);
    let mut value = serde_json::to_value(&request)?;
    value["authority"] = serde_json::json!("grant");
    assert!(serde_json::from_value::<ColdNextTaskRequestV1>(value).is_err());
    let duplicate = String::from_utf8(original)?.replacen("{", "{\"request_id\":1,", 1);
    assert!(serde_json::from_str::<ColdNextTaskRequestV1>(&duplicate).is_err());
    let mut oversized = request;
    oversized.profile = "x".repeat(WIRE_BOUND);
    assert!(oversized.require_data(&f.profile).is_err());
    Ok(())
}

/// Pure DATA for protected-store component tests; no C history or authority.
pub(crate) fn component_cold_profile_data() -> anyhow::Result<ColdNextTaskProfileV1> {
    Ok(DataFixture::new()?.profile)
}
