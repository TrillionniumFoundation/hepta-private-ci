//! Cold D reopens the original Artifact service under its actual signed lease.
//! It neither publishes a model nor obtains a new learning owner or selection.

use super::*;
use crate::AgentdSelectedGenerationV1;
use crate::root_cold_next_task_client::RootColdNextTaskClientV1;
use sha2::Digest;

impl OriginalArtifactPlan {
    pub(in crate::production_launcher::post_a_q24) async fn open_original_cold_selection(
        self,
        client: &RootColdNextTaskClientV1,
        final_use: Arc<FinalUseAuthority>,
        clock: Arc<dyn AuthorityClock>,
        files: &mut OriginalFiles,
        cancelled: &CancellationToken,
    ) -> Result<
        (
            AgentdGenerationUpdateAuthoritiesV1,
            AgentdSelectedGenerationV1,
            OriginalArtifactCustody,
        ),
        AgentdError,
    > {
        let lease = self.lease.wait_original_value(cancelled).await?;
        let selection = self.selection.wait_original_value(cancelled).await?;
        let (authority, selected) = client.with_original_preparation(|fixed| {
            if self.lease_path != fixed.writer_lease {
                return Err(refused(
                    "cold D Artifact lease location differs from fixed Root",
                ));
            }
            let signed_lease = OriginalLateValue::with_original_bytes(&lease, |bytes| {
                let digest: [u8; 32] = sha2::Sha256::digest(bytes).into();
                if digest != fixed.writer_lease_sha256 {
                    return Err(refused("cold D Artifact lease differs from original bytes"));
                }
                let data: data::WriterLeaseData = serde_json::from_slice(bytes)?;
                data.original_signed_lease()
            })?;
            let signed = OriginalLateValue::with_original_bytes(&selection, |bytes| {
                let data: SelectionData = serde_json::from_slice(bytes)?;
                Ok(data.original_selection()?)
            })?;
            if signed != fixed.selection.original_selection()? {
                return Err(refused("cold D selection differs from original Root"));
            }
            let inputs = &fixed.inputs;
            let now = clock.now_unix_ms().map_err(refused)?;
            let withdrawal_registry = withdrawal_floor(inputs, files)?;
            let owner = LearningArtifactOwnerService::open(LearningArtifactOwnerServiceConfigV1 {
                root: inputs.artifact_root.clone(),
                trust: inputs.owner_trust.original_owner_trust()?,
                writer_lease: signed_lease,
                required_current_head: Some(inputs.retained_current.original_current()?),
                withdrawal_registry,
                storage_binding: Digest32::from_array(inputs.storage_binding),
                now,
            })
            .map_err(refused)?;
            let input = original_selection_input(inputs, &signed, files, now)?;
            let selected = AgentdSelectedGenerationV1::load(
                &owner,
                input.verifier,
                input.signed,
                input.files,
                now,
            )?;
            if selected.observation().digest().into_array() != client.profile().intent.selection
                || selected.manifest() != &client.profile().manifest
            {
                return Err(refused(
                    "cold D actual Artifact observation differs from Root",
                ));
            }
            let authority = AgentdGenerationUpdateAuthoritiesV1::new(
                Arc::new(Mutex::new(owner)),
                final_use,
                clock,
            )?;
            lease.require_unchanged()?;
            selection.require_unchanged()?;
            Ok((authority, selected))
        })?;
        let custody = OriginalArtifactCustody {
            lease,
            head: None,
            selection,
            end: self.end,
        };
        custody.require_original()?;
        Ok((authority, selected, custody))
    }
}
