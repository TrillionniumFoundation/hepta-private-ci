//! Root-fixed authorization originals. Paths come from the private cold-task
//! deployment; neither signed message can select a trust registry or role.

use std::io;
use std::path::PathBuf;

use codex_hepta_types::Digest32;
use ed25519_dalek::Signature;
use serde::Deserialize;
use serde::Serialize;

use super::generation_publication::deployment::files::MetadataFile;
use crate::AgentdIdentity;
use crate::AuthBusObjectiveIngress;
use crate::authbus_trust::TextTrust;
use crate::authbus_trust::hex_bytes;
use crate::cold_next_task_data::AUTHORIZATION_BOUND;
use crate::cold_next_task_data::ColdNextTaskAuthorizationDataV1;
use crate::cold_next_task_data::ColdNextTaskBindingDataV1;
use crate::cold_next_task_data::ColdNextTaskControllerDataV1;

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ColdNextTaskAuthorizationFilesDataV1 {
    pub(crate) controller: PathBuf,
    pub(crate) trust: PathBuf,
    pub(crate) authorization: PathBuf,
}

pub(crate) struct RootColdNextTaskAuthorizationFilesV1 {
    controller_file: MetadataFile,
    trust_file: MetadataFile,
    authorization_file: MetadataFile,
    controller: ColdNextTaskControllerDataV1,
    trust: TextTrust,
    authorization: ColdNextTaskAuthorizationDataV1,
}

impl RootColdNextTaskAuthorizationFilesV1 {
    pub(in crate::authority_host_runtime::session) fn open_original(
        data: ColdNextTaskAuthorizationFilesDataV1,
        identity: &AgentdIdentity,
    ) -> io::Result<Self> {
        crate::authority_host_service::generation_publication::original_root()?;
        if data.controller == data.trust
            || data.controller == data.authorization
            || data.trust == data.authorization
        {
            return Err(io::Error::other(
                "cold authorization originals must be distinct",
            ));
        }
        let (controller_file, controller_bytes) = MetadataFile::open_metadata(&data.controller)?;
        let (trust_file, trust_bytes) = MetadataFile::open_metadata(&data.trust)?;
        let (authorization_file, authorization_bytes) =
            MetadataFile::open_metadata(&data.authorization)?;
        if controller_bytes.len() > AUTHORIZATION_BOUND || trust_bytes.len() > AUTHORIZATION_BOUND {
            return Err(io::Error::other("cold authorization original bound"));
        }
        let controller: ColdNextTaskControllerDataV1 =
            serde_json::from_slice(&controller_bytes).map_err(io::Error::other)?;
        if serde_json::to_vec(&controller).map_err(io::Error::other)? != controller_bytes {
            return Err(io::Error::other(
                "canonical installed cold controller required",
            ));
        }
        let trust =
            TextTrust::from_original_bytes(&trust_bytes, identity).map_err(io::Error::other)?;
        let authorization =
            ColdNextTaskAuthorizationDataV1::from_original_bytes(&authorization_bytes)
                .map_err(io::Error::other)?;
        let retained = Self {
            controller_file,
            trust_file,
            authorization_file,
            controller,
            trust,
            authorization,
        };
        retained.require_original_files()?;
        Ok(retained)
    }

    pub(crate) fn require_current(
        &self,
        identity: &AgentdIdentity,
        original: &ColdNextTaskBindingDataV1,
        objective: &AuthBusObjectiveIngress,
        now: u64,
        authority_epoch: u64,
    ) -> io::Result<()> {
        self.require_original_files()?;
        let claims =
            crate::authbus_objective_claims(identity, objective).map_err(io::Error::other)?;
        let signature = hex_bytes::<64>(&objective.signature_hex).map_err(io::Error::other)?;
        let issuer = self.trust.issuer().map_err(io::Error::other)?;
        let canonical: String = signature.iter().map(|byte| format!("{byte:02x}")).collect();
        if identity.agent_id.as_str() != original.agent
            || authority_epoch == 0
            || original.authority_epoch != authority_epoch
            || objective.body.authority_epoch != authority_epoch
            || claims.issuer_id != issuer.issuer_id
            || claims.key_epoch != issuer.key_epoch
            || objective.issuer_id != self.controller.issuer
            || objective.key_epoch != self.controller.key_epoch
            || issuer.revoked
            || objective.signature_hex != canonical
            || now == 0
            || now >= claims.expires_at_ms
            || original.objective != Digest32::of_bytes(&claims.signing_bytes())
            || original.objective_message_id != claims.message_id.as_str()
            || original.objective_sequence != claims.sequence
            || original.objective_expiry_ms != claims.expires_at_ms
            || original.objective_signature != Digest32::of_bytes(&signature)
        {
            return Err(io::Error::other(
                "original current cold Objective authorization differs",
            ));
        }
        issuer
            .verifying_key
            .verify_strict(&claims.signing_bytes(), &Signature::from_bytes(&signature))
            .map_err(|_| io::Error::other("original cold Objective signature invalid"))?;
        self.authorization
            .require_current(&self.controller, &self.trust, original, now)
            .map_err(io::Error::other)?;
        self.require_original_files()
    }

    pub(crate) fn authorization(&self) -> &ColdNextTaskAuthorizationDataV1 {
        &self.authorization
    }

    pub(crate) fn controller_digest(&self) -> Digest32 {
        Digest32::of_parts(&[
            b"hepta.root.cold-next-task.fixed-controller.v1\0",
            self.controller_file.digest().as_array(),
            self.trust_file.digest().as_array(),
        ])
    }

    pub(crate) fn authorization_digest(&self) -> Digest32 {
        self.authorization_file.digest()
    }

    pub(crate) fn require_original_files(&self) -> io::Result<()> {
        crate::authority_host_service::generation_publication::original_root()?;
        self.controller_file.require_metadata_unchanged()?;
        self.trust_file.require_metadata_unchanged()?;
        self.authorization_file.require_metadata_unchanged()
    }
}
