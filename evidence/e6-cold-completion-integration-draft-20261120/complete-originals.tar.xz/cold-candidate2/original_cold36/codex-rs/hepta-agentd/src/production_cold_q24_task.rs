//! New D files are opened only after the actual new Root has authenticated C.
//! No old Source/Cell writer or learning scope enters this task preparation.

use super::*;
use crate::root_cold_next_task_client::RootColdNextTaskClientV1;
use codex_hepta_neuron::CellGenerationOwnerBindingV1;

impl OriginalCTaskPlan {
    pub(in crate::production_launcher::post_a_q24) async fn open_original_cold_task(
        self,
        client: &RootColdNextTaskClientV1,
        identity: &AgentdIdentity,
        model: Arc<LoadedCellQ24ModelV1>,
        files: &mut OriginalFiles,
        cancelled: &CancellationToken,
    ) -> Result<OriginalNewCTask, AgentdError> {
        if !matches!(self.mode, OpenMode::Create) || self.recovery.is_some() {
            return Err(refused("cold D requires a distinct never-opened task"));
        }
        client.with_original_preparation(|fixed| {
            for (input, expected) in [
                (&self.source, &fixed.successor.source_configuration),
                (&self.target, &fixed.successor.target_configuration),
                (&self.ingress, &fixed.successor.signed_ingress),
            ] {
                OriginalLateInput::require_original_pin(
                    input,
                    &expected.path,
                    (
                        expected.device,
                        expected.inode,
                        expected.uid,
                        expected.gid,
                        expected.mode,
                    ),
                )?;
            }
            Ok(())
        })?;
        let source = self.source.wait_original_value(cancelled).await?;
        let original = OriginalLateValue::with_original_bytes(&source, |bytes| {
            Ok(
                OriginalSingleQ24SourceConfigurationV1::from_original_deployment_bytes(
                    bytes, identity,
                )?,
            )
        })?;
        super::super::super::initial_q24::clock::require_source_deadline(&original.source)?;
        let target = self.target.wait_original_value(cancelled).await?;
        let target_description: ObserverData =
            OriginalLateValue::with_original_bytes(&target, |bytes| {
                Ok(serde_json::from_slice(bytes)?)
            })?;
        let target_data = target_description.original_observer_config()?;
        let ingress = self.ingress.wait_original_value(cancelled).await?;
        let request = OriginalLateValue::with_original_bytes(&ingress, |bytes| {
            Ok(serde_json::from_slice(bytes)?)
        })?;
        let (predecessor, new_target, execution) = client.with_original_preparation(|fixed| {
            let profile = client.profile();
            if serde_json::to_vec(&target_description)? != serde_json::to_vec(&fixed.target)?
                || target_data.generation.manifest != profile.manifest
                || CellGenerationOwnerBindingV1::new(
                    &target_data.generation,
                    target_data.journal_records,
                )
                .map_err(refused)?
                    != profile.intent.target
                || CellGenerationOwnerBindingV1::new(
                    &fixed.inputs.previous.generation,
                    fixed.inputs.previous.journal_records,
                )
                .map_err(refused)?
                    != profile.intent.previous
            {
                return Err(refused("cold D target or original C configuration differs"));
            }
            let (previous, target, execution, previous_files, target_files) =
                files::open_original_new_files(
                    &fixed.inputs,
                    &fixed.successor,
                    &target_data,
                    &original,
                    &self.execution,
                    files::NewWitnessInput::InitializedEmpty,
                    files,
                )?;
            if previous_files.to_string() != profile.previous_files
                || target_files.to_string() != profile.target_files
            {
                return Err(refused("cold D actual generation inodes differ from Root"));
            }
            Ok((previous, target, execution))
        })?;
        let previous = PublishedCircuitFeatureCompletionV1::read_original_cold_completion(client)?;
        let custody = OriginalCTaskCustody {
            source,
            target,
            ingress,
            end: self.end,
        };
        custody.require_original()?;
        Ok(OriginalNewCTask {
            predecessor,
            target: OriginalCellQ24FeatureTargetV1 {
                target: new_target,
                definition: original.definition,
                source: original.source,
                model,
                previous,
            },
            target_data,
            execution,
            ingress: request,
            custody,
        })
    }
}
