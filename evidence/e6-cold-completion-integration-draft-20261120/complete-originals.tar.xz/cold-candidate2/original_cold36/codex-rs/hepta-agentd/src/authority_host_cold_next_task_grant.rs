//! The only cold D grant constructor and its immediate original issuer call.
//! The actual joint registry context owns both leases throughout Arm, durable
//! Attempted, signature, original physical postchecks and durable Issued.

use super::super::cold::RegisteredColdNextTaskV1;
use super::super::cold::RootColdNextTaskAttemptV1;
use super::*;
use crate::cold_next_task_protocol::ColdNextTaskCommandV1;
use crate::cold_next_task_protocol::ColdNextTaskRequestV1;
use crate::cold_next_task_protocol::ColdNextTaskResponseV1;
use crate::cold_next_task_protocol::PURPOSE as COLD_PURPOSE;
use codex_hepta_contracts::FinalUseBinding;

/// A scoped input to the existing exact-policy issuer. It is not a bearer
/// token, cannot be cloned/deserialized/sent, and cannot leave this operation.
pub(crate) struct RootPreparedColdNextTaskGrantV1<'a> {
    context: &'a OriginalColdNextTaskContextV1<'a>,
    slot: &'a RegisteredColdNextTaskV1<'a>,
    attempt: &'a RootColdNextTaskAttemptV1<'a>,
    request: &'a ColdNextTaskRequestV1,
    head: CurrentHead,
    binding: FinalUseBinding,
    expiry: u64,
}

impl<'a> RootPreparedColdNextTaskGrantV1<'a> {
    pub(crate) fn into_original_parts(
        self,
        issuer: &crate::DeploymentFinalUseIssuer,
    ) -> io::Result<(
        FinalUseBinding,
        &'a HostAuthorityWriterRegistration,
        &'a HostSignedWriterAuthorizationV1,
        u64,
    )> {
        self.slot
            .require_original_attempt(self.context, self.attempt, self.request)?;
        if !std::ptr::eq(issuer, self.context.service.issuer.as_ref()) {
            return Err(io::Error::other(
                "cold grant left its actual original issuer",
            ));
        }
        self.attempt.require_attempted()?;
        if self.slot.require_grant_cut(self.context)? != self.head
            || OriginalColdNextTaskContextV1::require_current(self.context)? >= self.expiry
        {
            return Err(io::Error::other(
                "cold grant scope changed before original issuer",
            ));
        }
        Ok((
            self.binding,
            self.context.writer,
            self.context.proof,
            self.expiry,
        ))
    }
}

impl OriginalColdNextTaskContextV1<'_> {
    pub(in super::super) fn issue_cold_next_task_grant(
        &self,
        slot: &RegisteredColdNextTaskV1<'_>,
        attempt: &RootColdNextTaskAttemptV1<'_>,
        request: &ColdNextTaskRequestV1,
    ) -> io::Result<ColdNextTaskResponseV1> {
        let ColdNextTaskCommandV1::IssueFinalUse { expected, intent } = &request.command else {
            return Err(io::Error::other("original cold issuer operation required"));
        };
        slot.require_original_attempt(self, attempt, request)?;
        let head = slot.require_grant_cut(self)?;
        let profile = slot.profile();
        let expiry = profile.valid_until_ms.min(self.valid_until_ms);
        if *expected != head_digest(&head)?
            || *intent
                != profile
                    .intent
                    .digest()
                    .map_err(io::Error::other)?
                    .to_string()
            || self.require_current()? >= expiry
        {
            return Err(io::Error::other(
                "cold prepared head, intent or expiry differs",
            ));
        }
        // There is no retry path from this durable state, even if the issuer
        // returns an error or a later physical/authority postcheck refuses.
        attempt.begin_final_use()?;
        if slot.require_grant_cut(self)? != head {
            return Err(io::Error::other(
                "cold CURRENT changed after durable nonce attempt",
            ));
        }
        let admitted = RootPreparedColdNextTaskGrantV1 {
            context: self,
            slot,
            attempt,
            request,
            head: head.clone(),
            binding: profile.intent.binding().map_err(io::Error::other)?,
            expiry,
        };
        let result = crate::DeploymentFinalUseIssuer::issue_original_cold_next_task_final_use(
            &self.service.issuer,
            admitted,
        );
        let after = slot.require_grant_cut(self)?;
        self.require_current()?;
        if after != head {
            return Err(io::Error::other(
                "cold CURRENT changed during original signature",
            ));
        }
        let signed = result?.ok_or_else(|| {
            io::Error::new(
                io::ErrorKind::PermissionDenied,
                "original exact cold D FinalUse policy is not installed",
            )
        })?;
        if self.require_current()? >= signed.grant.expires_at_unix_ms
            || signed.grant.expires_at_unix_ms > expiry
        {
            return Err(io::Error::other(
                "original cold grant expired before completion",
            ));
        }
        let response = ColdNextTaskResponseV1 {
            schema: 1,
            purpose: COLD_PURPOSE.into(),
            request_id: request.request_id,
            request: request.digest()?,
            profile: profile.clone(),
            head: after.clone(),
            predecessor: None,
            grant: Some(signed.clone()),
        };
        response.require_data(request)?;
        attempt.finish_final_use(&signed)?;
        if slot.require_grant_cut(self)? != after
            || self.require_current()? >= signed.grant.expires_at_unix_ms
        {
            return Err(io::Error::other(
                "cold grant durable completion is uncertain",
            ));
        }
        attempt.require_issued(&signed)?;
        Ok(response)
    }
}
