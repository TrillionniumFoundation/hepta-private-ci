//! Install one explicitly selected cold D route beside the unchanged read-only
//! history lane. Only the actual serving Root can enroll its fixed deployment.

use std::path::PathBuf;
use std::sync::atomic::AtomicU8;
use std::sync::atomic::Ordering;

use codex_hepta_memory::CognitiveCheckpointPeerLifetime;

use super::generation_publication::deployment::files::MetadataFile;
use super::*;
use crate::authority_host_service::generation_publication::original_root;
use crate::cold_next_task_bootstrap::ColdNextTaskBootstrapV1;
use crate::cold_next_task_bootstrap::RootColdNextTaskOfferV1;
use crate::cold_next_task_bootstrap::SOCKET;
use crate::cold_next_task_protocol::PURPOSE;

#[path = "authority_host_cold_next_task_runtime.rs"]
mod runtime;
pub(super) use runtime::BoundColdNextTask;
pub(super) use runtime::serve_optional;

const PREPARED: u8 = 0;
const SEALED: u8 = 1;
const SERVING: u8 = 2;
const STOPPED: u8 = 3;

pub(super) struct ColdNextTaskRuntime {
    metadata: MetadataFile,
    deployment: PathBuf,
    preparation: crate::authority_host_runtime::ColdNextTaskPreparationDataV1,
    socket: PathBuf,
    phase: AtomicU8,
}

impl PreparedHostAuthoritySession {
    /// Retain the original Root-private deployment. Live finalized C, current
    /// leases, both D signatures and exact policy are checked during enrollment.
    pub fn enable_original_cold_next_task_from_deployment(
        &mut self,
        path: &Path,
    ) -> io::Result<()> {
        original_root()?;
        if self.cold_next_task.is_some()
            || self.historical_read.is_none()
            || self.learning.is_some()
            || self.publication.is_some()
            || self.initial_publication.is_some()
        {
            return Err(io::Error::other(
                "one cold route requires original history only",
            ));
        }
        let (metadata, bytes) = MetadataFile::open_metadata(path)?;
        let preparation = RootColdNextTaskFilesV1::original_preparation_data(&bytes)?;
        let socket = self
            .config
            .sockets
            .observation
            .parent()
            .ok_or_else(|| io::Error::other("original Root socket parent missing"))?
            .join(SOCKET);
        self.service.with_initial_publication_context(
            &self.config,
            &self.registration,
            &self.owner_pidfd,
            |_| metadata.require_metadata_unchanged(),
        )?;
        self.cold_next_task = Some(ColdNextTaskRuntime {
            metadata,
            deployment: path.to_path_buf(),
            preparation,
            socket,
            phase: AtomicU8::new(PREPARED),
        });
        Ok(())
    }

    pub fn seal_original_cold_next_task(&self) -> io::Result<RootColdNextTaskOfferV1> {
        original_root()?;
        let runtime = self
            .cold_next_task
            .as_ref()
            .ok_or_else(|| io::Error::other("original cold task deployment missing"))?;
        runtime
            .phase
            .compare_exchange(PREPARED, SEALED, Ordering::AcqRel, Ordering::Acquire)
            .map_err(|_| io::Error::other("original cold task offer already consumed"))?;
        let mut offer = None;
        let result = self.service.with_initial_publication_context(
            &self.config,
            &self.registration,
            &self.owner_pidfd,
            |proof| {
                runtime.metadata.require_metadata_unchanged()?;
                let stat = std::fs::read_to_string("/proc/self/stat")?;
                let start = stat
                    .rsplit_once(") ")
                    .and_then(|(_, fields)| fields.split_whitespace().nth(19))
                    .and_then(|value| value.parse::<u64>().ok())
                    .filter(|value| *value != 0)
                    .ok_or_else(|| io::Error::other("missing original Root process identity"))?;
                let bundle = ColdNextTaskBootstrapV1 {
                    schema: 1,
                    purpose: PURPOSE.into(),
                    root: CognitiveCheckpointPeerLifetime {
                        uid: 0,
                        pid: std::process::id(),
                        boot_id: self.registration.boot_id.clone(),
                        process_start_ticks: start,
                    },
                    consumer: CognitiveCheckpointPeerLifetime {
                        uid: self.config.peer_uid,
                        pid: self.registration.peer_pid,
                        boot_id: self.registration.boot_id.clone(),
                        process_start_ticks: self.registration.process_start_ticks,
                    },
                    identity: self.registration.registered_identity.clone(),
                    writer: proof,
                    deployment: runtime.metadata.digest().to_string(),
                    preparation: runtime.preparation.clone(),
                    socket: runtime.socket.clone(),
                };
                let bytes = serde_json::to_vec(&bundle).map_err(io::Error::other)?;
                let bootstrap = crate::authority_host_bootstrap_seal::seal_bytes(&bytes)?;
                runtime.metadata.require_metadata_unchanged()?;
                offer = Some(RootColdNextTaskOfferV1 { bootstrap });
                Ok(())
            },
        );
        if let Err(error) = result {
            runtime.phase.store(STOPPED, Ordering::Release);
            return Err(error);
        }
        offer.ok_or_else(|| io::Error::other("original cold sealed offer absent"))
    }
}
