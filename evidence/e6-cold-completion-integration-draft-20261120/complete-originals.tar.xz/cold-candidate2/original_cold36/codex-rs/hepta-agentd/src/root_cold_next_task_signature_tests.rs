//! Full Ed25519 verification components, not Root admission or consumed use.
//! Historical verification deliberately does not renew an expired C grant.

use super::*;
use codex_hepta_contracts::FinalUseGrant;
use ed25519_dalek::Signer;
use ed25519_dalek::SigningKey;

fn signed_component(epoch: u64, id: &str, key: &SigningKey) -> anyhow::Result<SignedFinalUseGrant> {
    let profile = crate::cold_next_task_protocol::component_cold_profile_data()?;
    let grant = FinalUseGrant {
        schema_version: 1,
        signer_id: id.into(),
        authority_epoch: epoch,
        grant_id: "signature-component-only".into(),
        nonce: [70; 32],
        binding: profile.intent.binding()?,
        not_before_unix_ms: 1_000,
        expires_at_unix_ms: 2_000,
    };
    Ok(SignedFinalUseGrant {
        signature: key.sign(&grant.signing_bytes()?).to_bytes().to_vec(),
        grant,
    })
}

#[test]
fn cold_next_task_full_signature_uses_exact_retained_key_epoch_and_binding() -> anyhow::Result<()> {
    let old = SigningKey::from_bytes(&[71; 32]);
    let new = SigningKey::from_bytes(&[72; 32]);
    let signed = signed_component(4, "old-C-original", &old)?;
    let historical = FinalUseIssuerTrustKey {
        key_id: "old-C-original".into(),
        verifying_key: old.verifying_key().to_bytes(),
        not_before_authority_epoch: 3,
        not_after_authority_epoch: 4,
    };
    require_original_signature(&signed, &signed.grant.binding, &historical)?;
    // Both bounds and all trust bytes are used. A valid new signature cannot
    // replace the old C proof; accepting old C bytes does not authorize D.
    let current = FinalUseIssuerTrustKey {
        key_id: "new-D-current".into(),
        verifying_key: new.verifying_key().to_bytes(),
        not_before_authority_epoch: 5,
        not_after_authority_epoch: 5,
    };
    assert!(require_original_signature(&signed, &signed.grant.binding, &current).is_err());
    let wrong_key = FinalUseIssuerTrustKey {
        verifying_key: new.verifying_key().to_bytes(),
        ..historical.clone()
    };
    assert!(require_original_signature(&signed, &signed.grant.binding, &wrong_key).is_err());
    let newer = signed_component(5, "new-D-current", &new)?;
    require_original_signature(&newer, &newer.grant.binding, &current)?;
    assert!(require_original_signature(&newer, &newer.grant.binding, &historical).is_err());
    for epoch in [2, 5] {
        let outside = signed_component(epoch, "old-C-original", &old)?;
        assert!(require_original_signature(&outside, &outside.grant.binding, &historical).is_err());
    }
    let mut wrong_binding = signed.grant.binding.clone();
    wrong_binding.payload_sha256[0] ^= 1;
    assert!(require_original_signature(&signed, &wrong_binding, &historical).is_err());
    Ok(())
}

#[test]
fn cold_next_task_full_signature_rejects_forged_bytes_and_weak_or_truncated_keys()
-> anyhow::Result<()> {
    let original = SigningKey::from_bytes(&[73; 32]);
    let signed = signed_component(7, "original-component", &original)?;
    let trusted = FinalUseIssuerTrustKey {
        key_id: signed.grant.signer_id.clone(),
        verifying_key: original.verifying_key().to_bytes(),
        not_before_authority_epoch: 7,
        not_after_authority_epoch: 7,
    };
    require_original_signature(&signed, &signed.grant.binding, &trusted)?;
    let mut changed = signed.clone();
    changed.grant.nonce[0] ^= 1;
    assert!(require_original_signature(&changed, &changed.grant.binding, &trusted).is_err());
    let mut changed = signed.clone();
    changed.grant.expires_at_unix_ms += 1;
    assert!(require_original_signature(&changed, &changed.grant.binding, &trusted).is_err());
    let mut changed = signed.clone();
    changed.signature[32] ^= 1;
    assert!(require_original_signature(&changed, &changed.grant.binding, &trusted).is_err());
    for length in [0, 63, 65] {
        let mut changed = signed.clone();
        changed.signature.resize(length, 0);
        assert!(require_original_signature(&changed, &changed.grant.binding, &trusted).is_err());
    }
    // Compressed identity has a valid encoding but is a weak Ed25519 key.
    let mut identity_key = [0; 32];
    identity_key[0] = 1;
    assert!(ed25519_dalek::VerifyingKey::from_bytes(&identity_key)?.is_weak());
    let weak = FinalUseIssuerTrustKey {
        verifying_key: identity_key,
        ..trusted
    };
    assert!(require_original_signature(&signed, &signed.grant.binding, &weak).is_err());
    Ok(())
}
