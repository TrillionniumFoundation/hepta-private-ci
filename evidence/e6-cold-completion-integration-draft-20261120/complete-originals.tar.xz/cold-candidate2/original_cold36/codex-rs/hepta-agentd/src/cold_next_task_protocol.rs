//! Bounded data exchanged on the dedicated cold next-task Root lane.
//! A decoded frame never supplies a Root client, writer, grant admission, or
//! completed-Cell capability. Those require the original authenticated stream.

use std::io;

use codex_hepta_agent_protocol::OriginalQ24CompletedHistoryDataV1;
use codex_hepta_contracts::SignedFinalUseGrant;
use codex_hepta_contracts::VerifiedUseAuthorityRefV1;
use codex_hepta_contracts::VerifiedUseBoundaryV1;
use codex_hepta_contracts::VerifiedUseTokenWitnessV1;
use codex_hepta_neuron::CellBackendManifestV2;
use codex_hepta_neuron::CellDecisionReceiptV1;
use codex_hepta_types::Digest32;
use codex_hepta_types::StableId;
use serde::Deserialize;
use serde::Serialize;
use sha2::Digest;
use sha2::Sha256;

use crate::CircuitTaskSourcePublicationV1;
use crate::NeuronGenerationPredecessorCompletionV1;
use crate::RootPublicationFinalUseConsumerV1;
use crate::authority_host_service::generation_publication::RootCompletedSuccessorDataV1;
use crate::neuron_generation_current::types::CurrentHead;
use crate::neuron_generation_current::types::UpdateIntent;

pub(crate) const PURPOSE: &str = "runtime.circuit.cold-next-task.publication.v1";
pub(crate) const WIRE_BOUND: usize = 16_384;
pub(crate) const MAX_REQUESTS: u64 = 64;

#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ColdNextTaskProfileV1 {
    pub(crate) purpose: String,
    pub(crate) identity: String,
    pub(crate) writer: String,
    pub(crate) original_c: OriginalQ24CompletedHistoryDataV1,
    pub(crate) previous_files: String,
    pub(crate) target_files: String,
    pub(crate) configuration: String,
    pub(crate) artifacts: String,
    pub(crate) controller: String,
    pub(crate) authorization_binding: String,
    pub(crate) authorization: String,
    pub(crate) authorization_id: String,
    pub(crate) objective: String,
    pub(crate) objective_id: String,
    pub(crate) consumer: RootPublicationFinalUseConsumerV1,
    pub(crate) consumer_trust: String,
    pub(crate) valid_until_ms: u64,
    pub(crate) manifest: CellBackendManifestV2,
    pub(crate) intent: UpdateIntent,
    pub(crate) binding: String,
}

impl ColdNextTaskProfileV1 {
    pub(crate) fn digest(&self) -> io::Result<String> {
        let mut original = self.clone();
        original.binding.clear();
        Ok(Digest32::of_parts(&[
            b"hepta.root.cold-next-task.profile.v1\0",
            &serde_json::to_vec(&original).map_err(io::Error::other)?,
        ])
        .to_string())
    }

    pub(crate) fn require_data(&self) -> io::Result<()> {
        self.original_c.validate_data().map_err(io::Error::other)?;
        StableId::new(&self.authorization_id).map_err(io::Error::other)?;
        StableId::new(&self.objective_id).map_err(io::Error::other)?;
        StableId::new(&self.intent.operation_id).map_err(io::Error::other)?;
        let from = &self.intent.previous;
        let to = &self.intent.target;
        if self.purpose != PURPOSE
            || self.identity != self.original_c.identity_digest
            || self.authorization_id == self.objective_id
            || self.valid_until_ms == 0
            || self.intent.supersedes.is_some()
            || self.intent.completion
                != NeuronGenerationPredecessorCompletionV1::OwnerDrainedSameModel
            || from.manifest_digest() != self.manifest.digest().map_err(io::Error::other)?
            || to.manifest_digest() != from.manifest_digest()
            || from.scope().agent_id != to.scope().agent_id
            || from.scope().cell_id != to.scope().cell_id
            || from.scope().principal_digest != to.scope().principal_digest
            || from.scope().run_id == to.scope().run_id
            || from.task_digest() == to.task_digest()
            || from.generation().checked_add(1) != Some(to.generation())
            || from.writer_epoch().checked_add(1) != Some(to.writer_epoch())
            || self.digest()? != self.binding
        {
            return Err(io::Error::other("original cold next-task profile differs"));
        }
        for value in [
            &self.identity,
            &self.writer,
            &self.previous_files,
            &self.target_files,
            &self.configuration,
            &self.artifacts,
            &self.controller,
            &self.authorization_binding,
            &self.authorization,
            &self.objective,
            &self.consumer_trust,
            &self.binding,
        ] {
            let digest: Digest32 = value.parse().map_err(io::Error::other)?;
            if digest.is_zero() || digest.to_string() != *value {
                return Err(io::Error::other(
                    "canonical cold next-task profile digest required",
                ));
            }
        }
        self.intent.binding().map_err(io::Error::other)?;
        Ok(())
    }

    /// Correlate DATA only. The actual Root/client also verifies the original
    /// issuer signature, consumed nonce and current independent consumer.
    pub(crate) fn require_head_data(&self, head: &CurrentHead) -> io::Result<()> {
        self.require_data()?;
        let intent = &self.intent;
        if head.schema_version != 1
            || (head.current != intent.previous && head.current != intent.target)
            || head
                .prepared
                .as_ref()
                .is_some_and(|prepared| prepared != intent)
        {
            return Err(io::Error::other("original cold next-task CURRENT differs"));
        }
        if head.current == intent.previous {
            let mut original = head.clone();
            original.prepared = None;
            if crate::authority_host_service::generation_publication::head_digest(&original)?
                != self.original_c.current_head
            {
                return Err(io::Error::other("original C CURRENT was substituted"));
            }
            return Ok(());
        }
        let published = head
            .published
            .as_ref()
            .ok_or_else(|| io::Error::other("original cold next-task Published record missing"))?;
        let binding = intent.binding().map_err(io::Error::other)?;
        published
            .signed
            .grant
            .signing_bytes()
            .map_err(io::Error::other)?;
        published.witness.validate().map_err(io::Error::other)?;
        let VerifiedUseAuthorityRefV1::FinalUse(reference) = &published.witness.authority_ref
        else {
            return Err(io::Error::other(
                "cold D witness must name its original FinalUse",
            ));
        };
        let mut hash = Sha256::new();
        hash.update(b"hepta.kernel.authority.verified-use-binding.final-use.v1\0");
        hash.update(serde_json::to_vec(&binding).map_err(io::Error::other)?);
        let binding_sha256: [u8; 32] = hash.finalize().into();
        if published.intent != *intent
            || head.prepared.is_some()
            || head.initial.is_some()
            || published.signed.grant.binding != binding
            || published.signed.signature.len() != 64
            || published.signed.grant.expires_at_unix_ms > self.valid_until_ms
            || published.signed_grant_digest
                != crate::neuron_generation_current::signed_grant_digest(&published.signed)
                    .map_err(io::Error::other)?
                    .into_array()
            || published.witness.boundary != VerifiedUseBoundaryV1::DispatchEntry
            || published.witness.authority_epoch != published.signed.grant.authority_epoch
            || reference.signer_id != published.signed.grant.signer_id
            || reference.grant_id != published.signed.grant.grant_id
            || reference.binding_sha256 != binding_sha256
            || published.witness.verified_at_unix_ms < published.signed.grant.not_before_unix_ms
            || published.witness.verified_at_unix_ms >= published.signed.grant.expires_at_unix_ms
        {
            return Err(io::Error::other(
                "original cold next-task publication differs",
            ));
        }
        Ok(())
    }

    /// Decode only the physical C fact already authenticated by the enclosing
    /// Root operation. This method itself confers no currentness or authority.
    pub(crate) fn predecessor_data(
        &self,
        original: &RootCompletedSuccessorDataV1,
    ) -> io::Result<(CircuitTaskSourcePublicationV1, CellDecisionReceiptV1)> {
        self.require_data()?;
        if original.record_digest != self.original_c.successor_record
            || original.original_cut_digest()?.to_string() != self.original_c.successor_cut
            || original.cut.writer_epoch != self.intent.previous.writer_epoch()
        {
            return Err(io::Error::other("original finalized C cut differs"));
        }
        let (source, receipt) = original
            .cut
            .publication
            .decode_original_successor_data()
            .map_err(io::Error::other)?;
        let input = source.input();
        let previous = &self.intent.previous;
        let scope = previous.scope();
        if input.scope.agent_id.as_str() != scope.agent_id
            || input.scope.cell_id.as_str() != scope.cell_id
            || input.scope.run_id.as_str() != scope.run_id
            || input.scope.principal_digest.into_array() != scope.principal_digest
            || input.source_frontier.into_array() != previous.source_frontier()
            || source.bundle_digest().into_array() != self.manifest.bundle_digest
            || receipt.checkpoint_after != source.checkpoint_digest()
        {
            return Err(io::Error::other(
                "original C completion data differs from predecessor",
            ));
        }
        source
            .require_decision(&receipt)
            .map_err(io::Error::other)?;
        Ok((source, receipt))
    }
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(tag = "operation", rename_all = "snake_case", deny_unknown_fields)]
pub(crate) enum ColdNextTaskCommandV1 {
    Observe,
    Prepare {
        expected: String,
        intent: String,
    },
    IssueFinalUse {
        expected: String,
        intent: String,
    },
    Publish {
        expected: String,
        intent: String,
        signed: SignedFinalUseGrant,
        witness: VerifiedUseTokenWitnessV1,
    },
    ReadPredecessor,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ColdNextTaskRequestV1 {
    pub(crate) schema: u8,
    pub(crate) purpose: String,
    pub(crate) request_id: u64,
    pub(crate) profile: String,
    pub(crate) command: ColdNextTaskCommandV1,
}

impl ColdNextTaskRequestV1 {
    pub(crate) fn digest(&self) -> io::Result<String> {
        Ok(Digest32::of_parts(&[
            b"hepta.root.cold-next-task.original-frame.v1\0",
            &serde_json::to_vec(self).map_err(io::Error::other)?,
        ])
        .to_string())
    }

    pub(crate) fn require_data(&self, profile: &ColdNextTaskProfileV1) -> io::Result<()> {
        profile.require_data()?;
        if self.schema != 1
            || self.purpose != PURPOSE
            || !(1..=MAX_REQUESTS).contains(&self.request_id)
            || (!self.profile.is_empty() && self.profile != profile.binding)
            || (self.profile.is_empty()
                && (self.request_id != 1
                    || !matches!(self.command, ColdNextTaskCommandV1::Observe)))
            || serde_json::to_vec(self).map_err(io::Error::other)?.len() > WIRE_BOUND
        {
            return Err(io::Error::other(
                "original bounded cold next-task request differs",
            ));
        }
        if let ColdNextTaskCommandV1::Prepare { expected, intent }
        | ColdNextTaskCommandV1::IssueFinalUse { expected, intent }
        | ColdNextTaskCommandV1::Publish {
            expected, intent, ..
        } = &self.command
        {
            let digest: Digest32 = expected.parse().map_err(io::Error::other)?;
            if digest.is_zero()
                || digest.to_string() != *expected
                || *intent
                    != profile
                        .intent
                        .digest()
                        .map_err(io::Error::other)?
                        .to_string()
            {
                return Err(io::Error::other("cold next-task requested intent differs"));
            }
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ColdNextTaskResponseV1 {
    pub(crate) schema: u8,
    pub(crate) purpose: String,
    pub(crate) request_id: u64,
    pub(crate) profile: ColdNextTaskProfileV1,
    pub(crate) request: String,
    pub(crate) head: CurrentHead,
    pub(crate) predecessor: Option<RootCompletedSuccessorDataV1>,
    pub(crate) grant: Option<SignedFinalUseGrant>,
}

impl ColdNextTaskResponseV1 {
    pub(crate) fn require_data(&self, request: &ColdNextTaskRequestV1) -> io::Result<()> {
        request.require_data(&self.profile)?;
        if self.schema != 1
            || self.purpose != PURPOSE
            || self.request_id != request.request_id
            || self.request != request.digest()?
            || serde_json::to_vec(self).map_err(io::Error::other)?.len() > WIRE_BOUND
        {
            return Err(io::Error::other(
                "original bounded cold next-task response differs",
            ));
        }
        let intent = &self.profile.intent;
        self.profile.require_head_data(&self.head)?;
        match &request.command {
            ColdNextTaskCommandV1::ReadPredecessor => {
                let original = self.predecessor.as_ref().ok_or_else(|| {
                    io::Error::other("original cold next-task predecessor missing")
                })?;
                self.profile.predecessor_data(original)?;
                if self.grant.is_some() {
                    return Err(io::Error::other("historical C data cannot carry a grant"));
                }
            }
            ColdNextTaskCommandV1::IssueFinalUse { expected, .. } => {
                let grant = self.grant.as_ref().ok_or_else(|| {
                    io::Error::other("original cold next-task grant acknowledgement missing")
                })?;
                grant.grant.signing_bytes().map_err(io::Error::other)?;
                if self.predecessor.is_some()
                    || *expected
                        != crate::authority_host_service::generation_publication::head_digest(
                            &self.head,
                        )?
                    || grant.signature.len() != 64
                    || self.head.current != intent.previous
                    || self.head.prepared.as_ref() != Some(intent)
                    || grant.grant.binding != intent.binding().map_err(io::Error::other)?
                    || grant.grant.expires_at_unix_ms > self.profile.valid_until_ms
                {
                    return Err(io::Error::other("original cold next-task grant differs"));
                }
            }
            ColdNextTaskCommandV1::Prepare { expected, .. } => {
                let mut before = self.head.clone();
                before.prepared = None;
                if self.predecessor.is_some()
                    || self.grant.is_some()
                    || self.head.current != intent.previous
                    || self.head.prepared.as_ref() != Some(intent)
                    || *expected
                        != crate::authority_host_service::generation_publication::head_digest(
                            &before,
                        )?
                {
                    return Err(io::Error::other(
                        "cold preparation response differs from exact original C",
                    ));
                }
            }
            ColdNextTaskCommandV1::Publish {
                signed, witness, ..
            } => {
                let actual =
                    self.head.published.as_ref().ok_or_else(|| {
                        io::Error::other("cold publication acknowledgement missing")
                    })?;
                if self.predecessor.is_some()
                    || self.grant.is_some()
                    || self.head.current != intent.target
                    || &actual.signed != signed
                    || &actual.witness != witness
                {
                    return Err(io::Error::other(
                        "cold publication response differs from original consumed result",
                    ));
                }
            }
            ColdNextTaskCommandV1::Observe => {
                if self.predecessor.is_some() || self.grant.is_some() {
                    return Err(io::Error::other(
                        "unexpected cold next-task response payload",
                    ));
                }
            }
        }
        Ok(())
    }
}

#[cfg(test)]
#[path = "cold_next_task_protocol_tests.rs"]
mod tests;

#[cfg(test)]
pub(crate) use tests::component_cold_profile_data;
