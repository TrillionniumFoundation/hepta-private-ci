//! A concrete CURRENT transport retained from the original Root handoff.
//! All frames share one actual connection and one 64-request sequence. A failed
//! frame consumes the stream; no JSON profile can reconstruct this client.

use std::sync::Arc;
use std::sync::Mutex;
use std::sync::atomic::AtomicBool;
use std::sync::atomic::Ordering;

use codex_hepta_contracts::FinalUseBinding;
use codex_hepta_contracts::FinalUseIssuerTrustKey;
use codex_hepta_contracts::SignedFinalUseGrant;
use codex_hepta_neuron::CellBackendManifestV2;
use codex_hepta_neuron::CellDecisionReceiptV1;
use codex_hepta_neuron::CellGenerationOwnerBindingV1;
use codex_hepta_neuron::CellGenerationScopeV2;

use crate::AgentdError;
use crate::AgentdRootAuthoritySession;
use crate::CircuitTaskSourcePublicationV1;
use crate::RootGenerationPublicationConnectionV1;
use crate::authority_host_service::generation_publication::head_digest;
use crate::cold_next_task_bootstrap::ColdNextTaskBootstrapV1;
use crate::cold_next_task_protocol::ColdNextTaskCommandV1;
use crate::cold_next_task_protocol::ColdNextTaskProfileV1;
use crate::cold_next_task_protocol::ColdNextTaskRequestV1;
use crate::cold_next_task_protocol::ColdNextTaskResponseV1;
use crate::cold_next_task_protocol::MAX_REQUESTS;
use crate::cold_next_task_protocol::PURPOSE;
use crate::cold_next_task_protocol::WIRE_BOUND;
use crate::neuron_generation_current::types::CurrentHead;
use crate::neuron_generation_current::types::Published;
use crate::neuron_generation_current::types::UpdateIntent;
use crate::root_completed_learning_history::OriginalCompletedLearningHistoryV1;
use crate::root_generation_current_client::OriginalPublicationStream;
use crate::root_generation_current_client::uncertain;

#[path = "root_cold_next_task_inputs.rs"]
mod inputs;

struct Lane {
    stream: OriginalPublicationStream,
    sequence: u64,
}

pub(crate) struct RootColdNextTaskClientV1 {
    profile: ColdNextTaskProfileV1,
    preparation: crate::authority_host_runtime::ColdNextTaskPreparationDataV1,
    connection: RootGenerationPublicationConnectionV1,
    history: OriginalCompletedLearningHistoryV1,
    lane: Mutex<Option<Lane>>,
    fenced: AtomicBool,
    grant_attempted: AtomicBool,
}

impl RootColdNextTaskClientV1 {
    fn from_original_stream(
        mut stream: OriginalPublicationStream,
        bootstrap: &ColdNextTaskBootstrapV1,
        connection: RootGenerationPublicationConnectionV1,
        history: OriginalCompletedLearningHistoryV1,
    ) -> Result<Self, AgentdError> {
        history.require_original_cold_connection(&connection)?;
        let request = ColdNextTaskRequestV1 {
            schema: 1,
            purpose: PURPOSE.into(),
            request_id: 1,
            profile: String::new(),
            command: ColdNextTaskCommandV1::Observe,
        };
        let raw = stream.exchange(&serde_json::to_vec(&request)?)?;
        if raw.is_empty() || raw.len() > WIRE_BOUND {
            return Err(uncertain());
        }
        let response: ColdNextTaskResponseV1 = serde_json::from_slice(&raw)?;
        response.require_data(&request)?;
        if response.profile.original_c != *history.data()
            || response.profile.writer != bootstrap.writer
            || response.profile.identity
                != crate::neuron_generation_process_identity_digest_v1(
                    &bootstrap.identity.identity()?,
                )?
                .to_string()
        {
            return Err(uncertain());
        }
        authenticate_response(&connection, &response, &bootstrap.preparation)?;
        history.require_original_cold_connection(&connection)?;
        Ok(Self {
            profile: response.profile,
            preparation: bootstrap.preparation.clone(),
            connection,
            history,
            lane: Mutex::new(Some(Lane {
                stream,
                sequence: 2,
            })),
            fenced: AtomicBool::new(false),
            grant_attempted: AtomicBool::new(false),
        })
    }

    pub(crate) fn scope(&self) -> &CellGenerationScopeV2 {
        self.profile.intent.previous.scope()
    }

    pub(crate) fn profile(&self) -> &ColdNextTaskProfileV1 {
        &self.profile
    }

    pub(crate) fn require_original_session(
        &self,
        session: &AgentdRootAuthoritySession,
    ) -> Result<(), AgentdError> {
        if self.fenced.load(Ordering::Acquire) {
            return Err(uncertain());
        }
        let result = (|| {
            self.history
                .require_original_cold_connection(&self.connection)?;
            RootGenerationPublicationConnectionV1::require_same_original_session(
                &self.connection,
                session,
            )?;
            self.history
                .require_original_cold_connection(&self.connection)
        })();
        if result.is_err() {
            self.fence();
        }
        result
    }

    pub(crate) fn observe(&self) -> Result<CurrentHead, AgentdError> {
        Ok(self.exchange_response(ColdNextTaskCommandV1::Observe)?.head)
    }

    pub(crate) fn replace(
        &self,
        expected: &CurrentHead,
        next: &CurrentHead,
    ) -> Result<(), AgentdError> {
        let result = (|| {
            self.profile.require_head_data(expected)?;
            let intent = &self.profile.intent;
            let mut prepared = expected.clone();
            prepared.prepared = Some(intent.clone());
            let command = if expected.current == intent.previous
                && expected.prepared.is_none()
                && next == &prepared
            {
                ColdNextTaskCommandV1::Prepare {
                    expected: head_digest(expected)?,
                    intent: intent.digest()?.to_string(),
                }
            } else {
                let record = next.published.as_ref().ok_or_else(uncertain)?;
                let exact = CurrentHead {
                    schema_version: 1,
                    current: intent.target.clone(),
                    prepared: None,
                    initial: None,
                    published: Some(Published {
                        intent: intent.clone(),
                        signed: record.signed.clone(),
                        witness: record.witness.clone(),
                        signed_grant_digest: crate::neuron_generation_current::signed_grant_digest(
                            &record.signed,
                        )?
                        .into_array(),
                    }),
                };
                if expected.current != intent.previous
                    || expected.prepared.as_ref() != Some(intent)
                    || next != &exact
                {
                    return Err(uncertain());
                }
                self.profile.require_head_data(next)?;
                authenticate_signed(&self.connection, &record.signed, &intent.binding()?)?;
                ColdNextTaskCommandV1::Publish {
                    expected: head_digest(expected)?,
                    intent: intent.digest()?.to_string(),
                    signed: record.signed.clone(),
                    witness: record.witness.clone(),
                }
            };
            if self.exchange_response(command)?.head != *next {
                return Err(uncertain());
            }
            Ok(())
        })();
        if result.is_err() {
            self.fence();
        }
        result
    }

    pub(crate) fn issue_original_prepared_final_use(
        &self,
        intent: &UpdateIntent,
    ) -> Result<SignedFinalUseGrant, AgentdError> {
        let result = (|| {
            if self.grant_attempted.swap(true, Ordering::AcqRel) || intent != &self.profile.intent {
                return Err(uncertain());
            }
            let before = self.observe()?;
            if before.current != intent.previous || before.prepared.as_ref() != Some(intent) {
                return Err(uncertain());
            }
            let response = self.exchange_response(ColdNextTaskCommandV1::IssueFinalUse {
                expected: head_digest(&before)?,
                intent: intent.digest()?.to_string(),
            })?;
            if response.head != before {
                return Err(uncertain());
            }
            response.grant.ok_or_else(uncertain)
        })();
        if result.is_err() {
            self.fence();
        }
        result
    }

    /// The same Root physically rereads retired C before and after the factual
    /// conversion. This callback creates no grant or old generation owner.
    pub(crate) fn with_original_predecessor<T>(
        &self,
        action: impl FnOnce(
            &CellGenerationOwnerBindingV1,
            &CellBackendManifestV2,
            CircuitTaskSourcePublicationV1,
            CellDecisionReceiptV1,
        ) -> Result<T, AgentdError>,
    ) -> Result<T, AgentdError> {
        let result = (|| {
            let before = self.exchange_response(ColdNextTaskCommandV1::ReadPredecessor)?;
            let original = before.predecessor.ok_or_else(uncertain)?;
            let (source, receipt) = self.profile.predecessor_data(&original)?;
            let converted = action(
                &self.profile.intent.previous,
                &self.profile.manifest,
                source,
                receipt,
            );
            let after = self.exchange_response(ColdNextTaskCommandV1::ReadPredecessor)?;
            if after.predecessor.as_ref() != Some(&original) {
                return Err(uncertain());
            }
            converted
        })();
        if result.is_err() {
            self.fence();
        }
        result
    }

    /// The actual Root rechecks the physical C/D cut on both sides. This data
    /// callback supplies no issuer, owner or capability derived from JSON.
    pub(crate) fn with_original_preparation<T>(
        &self,
        action: impl FnOnce(
            &crate::authority_host_runtime::ColdNextTaskPreparationDataV1,
        ) -> Result<T, AgentdError>,
    ) -> Result<T, AgentdError> {
        let result = (|| {
            self.observe()?;
            let result = action(&self.preparation);
            self.observe()?;
            result
        })();
        if result.is_err() {
            self.fence();
        }
        result
    }

    fn fence(&self) {
        self.fenced.store(true, Ordering::Release);
        if let Ok(mut held) = self.lane.try_lock() {
            held.take();
        }
    }

    fn exchange_response(
        &self,
        command: ColdNextTaskCommandV1,
    ) -> Result<ColdNextTaskResponseV1, AgentdError> {
        if self.fenced.load(Ordering::Acquire) {
            return Err(uncertain());
        }
        let result = (|| {
            self.history
                .require_original_cold_connection(&self.connection)?;
            let mut held = self.lane.try_lock().map_err(|_| uncertain())?;
            let mut lane = held.take().ok_or_else(uncertain)?;
            if !(1..=MAX_REQUESTS).contains(&lane.sequence) {
                return Err(uncertain());
            }
            let request = ColdNextTaskRequestV1 {
                schema: 1,
                purpose: PURPOSE.into(),
                request_id: lane.sequence,
                profile: self.profile.binding.clone(),
                command,
            };
            request.require_data(&self.profile)?;
            let raw = OriginalPublicationStream::exchange(
                &mut lane.stream,
                &serde_json::to_vec(&request)?,
            )?;
            if raw.is_empty() || raw.len() > WIRE_BOUND {
                return Err(uncertain());
            }
            let response: ColdNextTaskResponseV1 = serde_json::from_slice(&raw)?;
            response.require_data(&request)?;
            if response.profile != self.profile || self.fenced.load(Ordering::Acquire) {
                return Err(uncertain());
            }
            authenticate_response(&self.connection, &response, &self.preparation)?;
            self.history
                .require_original_cold_connection(&self.connection)?;
            lane.sequence = lane.sequence.checked_add(1).ok_or_else(uncertain)?;
            if self.fenced.load(Ordering::Acquire) {
                return Err(uncertain());
            }
            *held = Some(lane);
            Ok(response)
        })();
        if result.is_err() {
            self.fence();
        }
        result
    }
}

fn authenticate_response(
    connection: &RootGenerationPublicationConnectionV1,
    response: &ColdNextTaskResponseV1,
    preparation: &crate::authority_host_runtime::ColdNextTaskPreparationDataV1,
) -> Result<(), AgentdError> {
    // Signature verification does not lock a FinalUse consumer: Publish runs
    // inside that original consumer's actual dispatch boundary. The ordinary
    // coordinator verifies/consumes it and Root independently observes its nonce.
    if let Some(published) = &response.head.published {
        if response.head.current == response.profile.intent.previous {
            authenticate_historical_signed(
                connection,
                &published.signed,
                &published.intent.binding()?,
                preparation,
            )?;
        } else {
            authenticate_signed(connection, &published.signed, &published.intent.binding()?)?;
        }
    }
    if let Some(signed) = &response.grant {
        authenticate_signed(connection, signed, &response.profile.intent.binding()?)?;
    }
    Ok(())
}

fn authenticate_signed(
    connection: &RootGenerationPublicationConnectionV1,
    signed: &SignedFinalUseGrant,
    binding: &FinalUseBinding,
) -> Result<(), AgentdError> {
    connection.require_original_publication_session()?;
    let (original, _) = connection.original_launch_binding();
    let trusted: FinalUseIssuerTrustKey = original.issuer_key.clone().into();
    if signed.grant.binding != *binding
        || signed.grant.signer_id != trusted.key_id
        || signed.grant.authority_epoch != original.revocations.authority_epoch
        || signed.grant.authority_epoch < trusted.not_before_authority_epoch
        || signed.grant.authority_epoch > trusted.not_after_authority_epoch
        || original
            .revocations
            .revoked_grant_ids
            .contains(&signed.grant.grant_id)
    {
        return Err(uncertain());
    }
    require_original_signature(signed, binding, &trusted)?;
    connection.require_original_publication_session()
}

/// Old C is a physically retained fact, not a request for current authority.
/// Its full signature uses the same Root's fixed retained issuer-key set; D
/// separately requires the new connection's current issuer and authority epoch.
fn authenticate_historical_signed(
    connection: &RootGenerationPublicationConnectionV1,
    signed: &SignedFinalUseGrant,
    binding: &FinalUseBinding,
    preparation: &crate::authority_host_runtime::ColdNextTaskPreparationDataV1,
) -> Result<(), AgentdError> {
    connection.require_original_publication_session()?;
    let mut keys = preparation
        .inputs
        .issuer_keys
        .iter()
        .filter(|key| key.key_id == signed.grant.signer_id);
    let original = keys.next().ok_or_else(uncertain)?;
    if keys.next().is_some() {
        return Err(uncertain());
    }
    let trusted = FinalUseIssuerTrustKey {
        key_id: original.key_id.clone(),
        verifying_key: original.verifying_key,
        not_before_authority_epoch: original.not_before_authority_epoch,
        not_after_authority_epoch: original.not_after_authority_epoch,
    };
    require_original_signature(signed, binding, &trusted)?;
    connection.require_original_publication_session()
}

fn require_original_signature(
    signed: &SignedFinalUseGrant,
    binding: &FinalUseBinding,
    trusted: &FinalUseIssuerTrustKey,
) -> Result<(), AgentdError> {
    if signed.grant.binding != *binding
        || signed.grant.signer_id != trusted.key_id
        || signed.grant.authority_epoch < trusted.not_before_authority_epoch
        || signed.grant.authority_epoch > trusted.not_after_authority_epoch
    {
        return Err(uncertain());
    }
    let key =
        ed25519_dalek::VerifyingKey::from_bytes(&trusted.verifying_key).map_err(|_| uncertain())?;
    if key.is_weak() {
        return Err(uncertain());
    }
    let signature =
        ed25519_dalek::Signature::from_slice(&signed.signature).map_err(|_| uncertain())?;
    key.verify_strict(
        &signed.grant.signing_bytes().map_err(|_| uncertain())?,
        &signature,
    )
    .map_err(|_| uncertain())?;
    Ok(())
}

#[cfg(test)]
#[path = "root_cold_next_task_signature_tests.rs"]
mod signature_tests;
