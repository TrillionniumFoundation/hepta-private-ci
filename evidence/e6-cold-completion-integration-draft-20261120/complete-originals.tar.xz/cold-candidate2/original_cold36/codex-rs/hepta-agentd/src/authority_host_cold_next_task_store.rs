//! Durable one-shot C-to-D operation. A frame becomes Armed before any physical
//! task/CURRENT/issuer work. Errors retain Armed; a later process cannot turn an
//! uncertain attempt into another nonce or reset the original 64-frame budget.

use std::marker::PhantomData;
use std::rc::Rc;

use codex_hepta_contracts::RootAuthorityDirectory;

use super::*;
use crate::cold_next_task_protocol::ColdNextTaskCommandV1;
use crate::cold_next_task_protocol::ColdNextTaskProfileV1;
use crate::cold_next_task_protocol::ColdNextTaskRequestV1;
use crate::cold_next_task_protocol::PURPOSE as COLD_PURPOSE;

#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
#[serde(tag = "phase", rename_all = "snake_case", deny_unknown_fields)]
enum OperationPhase {
    Ready { next_request_id: u64 },
    Armed { request_id: u64, request: String },
}

#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
#[serde(tag = "phase", rename_all = "snake_case", deny_unknown_fields)]
enum GrantPhase {
    Available {},
    Attempted {},
    Issued { signed: SignedFinalUseGrant },
}

#[derive(Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct ColdRecord {
    schema: u8,
    purpose: String,
    profile: ColdNextTaskProfileV1,
    operation: OperationPhase,
    grant: GrantPhase,
}

pub(in super::super) struct RegisteredColdNextTaskOperationV1 {
    store: HostAuthorityFrontierStore<ColdRecord>,
    owner: String,
    profile: ColdNextTaskProfileV1,
}

/// Neither Clone nor Deserialize. This borrow exists only inside the same
/// actual store operation and cannot be returned through the scoped callback.
pub(in super::super) struct RootColdNextTaskAttemptV1<'a> {
    original: &'a RegisteredColdNextTaskOperationV1,
    request: &'a ColdNextTaskRequestV1,
    request_digest: String,
    check: &'a dyn Fn() -> io::Result<()>,
    context: &'a OriginalColdNextTaskContextV1<'a>,
    _not_send: PhantomData<Rc<()>>,
}

impl RegisteredColdNextTaskOperationV1 {
    pub(in super::super) fn create_original(
        root: Arc<RootAuthorityDirectory>,
        profile: ColdNextTaskProfileV1,
    ) -> io::Result<Self> {
        original_root()?;
        profile.require_data()?;
        // The immutable predecessor selects the single transition slot. A new
        // operation ID, new signature or new process cannot bypass an earlier
        // Available/Armed/Attempted/Issued record for this same completed C.
        let owner = format!(
            "cold-next-task/{}",
            Digest32::of_parts(&[
                b"hepta.root.cold-next-task.original-transition.v1\0",
                profile.original_c.current_head.as_bytes(),
                profile.original_c.successor_record.as_bytes(),
                profile.original_c.successor_cut.as_bytes(),
                &profile.intent.previous.digest().map_err(io::Error::other)?,
            ])
        );
        let original = ColdRecord {
            schema: 1,
            purpose: COLD_PURPOSE.into(),
            profile: profile.clone(),
            operation: OperationPhase::Ready { next_request_id: 1 },
            grant: GrantPhase::Available {},
        };
        let store = HostAuthorityFrontierStore::initialize(root, owner.clone(), original.clone())
            .map_err(io::Error::other)?;
        let retained = Self {
            store,
            owner,
            profile,
        };
        if retained.load_original()? != original {
            return Err(io::Error::other(
                "original cold operation initialization uncertain",
            ));
        }
        Ok(retained)
    }

    pub(in super::super) fn with_operation<T>(
        &self,
        request: &ColdNextTaskRequestV1,
        context: &OriginalColdNextTaskContextV1<'_>,
        check: &dyn Fn() -> io::Result<()>,
        action: impl for<'attempt> FnOnce(&RootColdNextTaskAttemptV1<'attempt>) -> io::Result<T>,
    ) -> io::Result<T> {
        original_root()?;
        check()?;
        request.require_data(&self.profile)?;
        let before = self.load_original()?;
        if before.operation
            != (OperationPhase::Ready {
                next_request_id: request.request_id,
            })
        {
            return Err(io::Error::other("original cold operation sequence differs"));
        }
        let request_digest = request.digest()?;
        let mut armed = before.clone();
        armed.operation = OperationPhase::Armed {
            request_id: request.request_id,
            request: request_digest.clone(),
        };
        check()?;
        self.store
            .compare_and_set(&self.owner, &before, &armed)
            .map_err(io::Error::other)?;
        check()?;
        if self.load_original()? != armed {
            return Err(io::Error::other("cold operation Arm readback differs"));
        }
        let attempt = RootColdNextTaskAttemptV1 {
            original: self,
            request,
            request_digest,
            check,
            context,
            _not_send: PhantomData,
        };
        attempt.require_original(context, self, request)?;
        let result = action(&attempt);
        // Run this even when the real physical action returned an error.
        let mut after = attempt.load_armed()?;
        let value = result?;
        if matches!(request.command, ColdNextTaskCommandV1::IssueFinalUse { .. }) {
            if !matches!(before.grant, GrantPhase::Available {})
                || !matches!(after.grant, GrantPhase::Issued { .. })
            {
                return Err(io::Error::other(
                    "cold signing did not retain its single result",
                ));
            }
        } else if after.grant != before.grant {
            return Err(io::Error::other(
                "non-issuer cold operation changed FinalUse state",
            ));
        }
        let original_after = after.clone();
        after.operation = OperationPhase::Ready {
            next_request_id: request
                .request_id
                .checked_add(1)
                .ok_or_else(|| io::Error::other("cold request counter exhausted"))?,
        };
        check()?;
        self.store
            .compare_and_set(&self.owner, &original_after, &after)
            .map_err(io::Error::other)?;
        check()?;
        if self.load_original()? != after {
            return Err(io::Error::other(
                "cold operation completion acknowledgement differs",
            ));
        }
        Ok(value)
    }

    fn load_original(&self) -> io::Result<ColdRecord> {
        original_root()?;
        let record = self.store.load(&self.owner).map_err(io::Error::other)?;
        if record.schema != 1 || record.purpose != COLD_PURPOSE || record.profile != self.profile {
            return Err(io::Error::other("original cold operation record differs"));
        }
        self.profile.require_data()?;
        if let GrantPhase::Issued { signed } = &record.grant {
            self.require_binding(signed)?;
        }
        Ok(record)
    }

    fn require_binding(&self, signed: &SignedFinalUseGrant) -> io::Result<()> {
        if signed.grant.binding != self.profile.intent.binding().map_err(io::Error::other)?
            || signed.grant.expires_at_unix_ms == 0
            || signed.grant.expires_at_unix_ms > self.profile.valid_until_ms
        {
            return Err(io::Error::other("original cold signed grant differs"));
        }
        signed.grant.signing_bytes().map_err(io::Error::other)?;
        Ok(())
    }
}

impl RootColdNextTaskAttemptV1<'_> {
    pub(in super::super) fn require_original(
        &self,
        context: &OriginalColdNextTaskContextV1<'_>,
        operation: &RegisteredColdNextTaskOperationV1,
        request: &ColdNextTaskRequestV1,
    ) -> io::Result<()> {
        if !std::ptr::eq(self.context, context)
            || !std::ptr::eq(self.original, operation)
            || !std::ptr::eq(self.request, request)
            || self.request_digest != request.digest()?
        {
            return Err(io::Error::other(
                "cold attempt left its actual context, owner or Armed frame",
            ));
        }
        self.context.require_current()?;
        self.load_armed()?;
        self.context.require_current()?;
        Ok(())
    }

    fn load_armed(&self) -> io::Result<ColdRecord> {
        (self.check)()?;
        let record = self.original.load_original()?;
        (self.check)()?;
        if record.operation
            != (OperationPhase::Armed {
                request_id: self.request.request_id,
                request: self.request_digest.clone(),
            })
        {
            return Err(io::Error::other("original cold operation no longer Armed"));
        }
        Ok(record)
    }

    pub(in super::super) fn begin_final_use(&self) -> io::Result<()> {
        if !matches!(
            self.request.command,
            ColdNextTaskCommandV1::IssueFinalUse { .. }
        ) {
            return Err(io::Error::other(
                "only the original cold issuer frame may attempt",
            ));
        }
        let before = self.load_armed()?;
        if before.grant != (GrantPhase::Available {}) {
            return Err(io::Error::other(
                "original cold nonce was already attempted",
            ));
        }
        let mut attempted = before.clone();
        attempted.grant = GrantPhase::Attempted {};
        (self.check)()?;
        self.original
            .store
            .compare_and_set(&self.original.owner, &before, &attempted)
            .map_err(io::Error::other)?;
        if self.load_armed()? != attempted {
            return Err(io::Error::other(
                "original cold nonce attempt acknowledgement differs",
            ));
        }
        Ok(())
    }

    pub(in super::super) fn require_attempted(&self) -> io::Result<()> {
        if self.load_armed()?.grant != (GrantPhase::Attempted {}) {
            return Err(io::Error::other(
                "original cold signing attempt is not current",
            ));
        }
        Ok(())
    }

    pub(in super::super) fn finish_final_use(
        &self,
        signed: &SignedFinalUseGrant,
    ) -> io::Result<()> {
        self.require_attempted()?;
        self.original.require_binding(signed)?;
        let before = self.load_armed()?;
        if before.grant != (GrantPhase::Attempted {}) {
            return Err(io::Error::other("original cold signing attempt changed"));
        }
        let mut issued = before.clone();
        issued.grant = GrantPhase::Issued {
            signed: signed.clone(),
        };
        self.original
            .store
            .compare_and_set(&self.original.owner, &before, &issued)
            .map_err(io::Error::other)?;
        if self.load_armed()? != issued {
            return Err(io::Error::other(
                "original cold signed result acknowledgement differs",
            ));
        }
        Ok(())
    }

    pub(in super::super) fn require_issued(&self, signed: &SignedFinalUseGrant) -> io::Result<()> {
        self.original.require_binding(signed)?;
        if self.load_armed()?.grant
            != (GrantPhase::Issued {
                signed: signed.clone(),
            })
        {
            return Err(io::Error::other(
                "cold publication must consume its retained original nonce",
            ));
        }
        Ok(())
    }
}

#[cfg(test)]
#[path = "authority_host_cold_next_task_store_tests.rs"]
mod component_tests;
#[cfg(test)]
pub(crate) use component_tests::qualify_original_cold_operation_store;
