//! A cold CURRENT client can only consume the original sealed route and the
//! actual five-lane receiver's single publication connection. The old historical
//! client remains held for liveness but is not reread after CURRENT advances.

use std::io::Read;
use std::io::Seek;
use std::time::Duration;
use std::time::Instant;

use super::*;
use crate::AgentdRootAuthorityPeer;
use crate::AgentdRootProductionInputs;
use crate::RootColdNextTaskHandoffV1;
use crate::cold_next_task_bootstrap::SOCKET;

impl RootColdNextTaskHandoffV1 {
    pub(crate) async fn connect_original(
        mut self,
        connection: RootGenerationPublicationConnectionV1,
        original: &AgentdRootProductionInputs,
        history: OriginalCompletedLearningHistoryV1,
        timeout: Duration,
        end: Instant,
    ) -> Result<Arc<RootColdNextTaskClientV1>, AgentdError> {
        connection.require_same_original_session(&original.session)?;
        history.require_original_cold_connection(&connection)?;
        let remaining = end
            .checked_duration_since(Instant::now())
            .filter(|left| !left.is_zero() && *left <= Duration::from_secs(300))
            .ok_or_else(uncertain)?;
        if timeout.is_zero() || timeout > Duration::from_millis(500) {
            return Err(uncertain());
        }
        let size = self.bootstrap.metadata()?.len();
        if size == 0 || size > crate::HOST_AUTHORITY_BOOTSTRAP_BOUND as u64 {
            return Err(uncertain());
        }
        crate::authority_host_bootstrap_seal::validate_sealed(&self.bootstrap, size)?;
        self.bootstrap.rewind()?;
        let mut bytes = Vec::with_capacity(size as usize);
        Read::by_ref(&mut self.bootstrap)
            .take(size + 1)
            .read_to_end(&mut bytes)?;
        crate::authority_host_bootstrap_seal::validate_sealed(&self.bootstrap, size)?;
        if bytes.len() as u64 != size {
            return Err(uncertain());
        }
        let bundle: ColdNextTaskBootstrapV1 = serde_json::from_slice(&bytes)?;
        let (launch, identity) = connection.original_launch_binding();
        let socket = launch
            .sockets
            .observation
            .parent()
            .ok_or_else(uncertain)?
            .join(SOCKET);
        if bundle.schema != 1
            || bundle.purpose != PURPOSE
            || bundle.root != launch.root
            || bundle.consumer != launch.consumer
            || bundle.root.pid != self.root_pid
            || bundle.root.uid != 0
            || bundle.identity.identity()? != *identity
            || launch.registered_identity.identity()? != *identity
            || bundle.writer != launch.writer_proof.sha256()?.as_str()
            || bundle.socket != socket
        {
            return Err(uncertain());
        }
        for value in [&bundle.deployment, &bundle.writer] {
            let digest: codex_hepta_types::Digest32 = value.parse().map_err(|_| uncertain())?;
            if digest.is_zero() || digest.to_string() != *value {
                return Err(uncertain());
            }
        }
        let paths = &launch.sockets;
        // SAFETY: getegid only observes this process's actual kernel credential.
        crate::authority_host_runtime::validate_lane_paths(
            &[
                &paths.observation,
                &paths.issuer,
                &paths.checkpoint,
                &paths.device_frontier,
                &paths.notes_frontier,
                &socket,
            ],
            unsafe { libc::getegid() },
        )?;
        history.require_original_cold_connection(&connection)?;
        connection.require_same_original_session(&original.session)?;
        let stream = tokio::time::timeout(
            timeout.min(remaining),
            tokio::net::UnixStream::connect(&socket),
        )
        .await
        .map_err(|_| uncertain())??;
        let stream = OriginalPublicationStream::from_stream_until(
            stream.into_std()?,
            self.root_pidfd,
            AgentdRootAuthorityPeer {
                pid: bundle.root.pid,
                boot_id: bundle.root.boot_id.clone(),
                process_start_ticks: bundle.root.process_start_ticks,
            },
            timeout,
            end,
        )?;
        let client = tokio::task::spawn_blocking(move || {
            RootColdNextTaskClientV1::from_original_stream(stream, &bundle, connection, history)
        })
        .await
        .map_err(|_| uncertain())??;
        client.require_original_session(&original.session)?;
        Ok(Arc::new(client))
    }
}
