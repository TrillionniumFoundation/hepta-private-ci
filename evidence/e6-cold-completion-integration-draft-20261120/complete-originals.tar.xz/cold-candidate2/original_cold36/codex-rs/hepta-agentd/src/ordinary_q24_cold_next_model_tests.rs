//! Controller-side copies of actual selected C component bytes. Loaded model
//! data is not an owner, an admitted task, a learning outcome or a D receipt.

use base64::Engine;
use base64::engine::general_purpose::STANDARD_NO_PAD;
use codex_hepta_learning_artifacts::CellCompatibilityBundleV1;
use codex_hepta_types::Digest32;
use serde_json::Value;
use serde_json::json;
use std::path::Path;
use std::sync::Arc;

use super::post_a_file::OriginalFileData;
use super::post_a_retained::RetainedOrdinaryQ24Fixture;
use crate::CellQ24PrivateHeadV1;
use crate::LoadedCellQ24ModelV1;

pub(super) struct OriginalColdSelectedModelData {
    pub(super) model: Arc<LoadedCellQ24ModelV1>,
    pub(super) deployment: Value,
}

impl OriginalColdSelectedModelData {
    pub(super) fn observe_and_copy(
        original: &RetainedOrdinaryQ24Fixture,
        directory: &Path,
    ) -> anyhow::Result<Self> {
        original.daemon.require_dead()?;
        original.root.require_dead()?;
        original.source.require_dead()?;
        let baseline_path = original
            .plan
            .resources
            .original
            .plan
            .runtime
            .path()
            .join("model");
        let (baseline, baseline_bundle, _) = super::super::material::load(&baseline_path)?;
        let initial = original.plan.profile.original_initial_data()?;
        anyhow::ensure!(
            baseline_bundle == initial.request.selected_bundle,
            "original baseline bytes changed"
        );
        let selected = &original.decision.bundle;
        let heads = if original.decision.adopts() {
            let encoded = &original.source_data.candidate_heads;
            anyhow::ensure!(
                !encoded.is_empty() && encoded.len() <= 65_536_usize.div_ceil(3) * 4,
                "original trained-head DATA bound"
            );
            let actual = STANDARD_NO_PAD.decode(encoded)?;
            anyhow::ensure!(
                actual.len() <= 65_536 && STANDARD_NO_PAD.encode(&actual) == *encoded,
                "original trained-head DATA is not canonical"
            );
            let original_bundle = STANDARD_NO_PAD.decode(&original.source_data.candidate_bundle)?;
            anyhow::ensure!(
                crate::learning_iteration_checkpoint::decode_original_bundle_data(
                    &original_bundle
                )? == *selected
                    && *selected != baseline_bundle,
                "actual adopted C bundle differs from the retained independent source"
            );
            let model = baseline.read_single_head_candidate_data(
                &baseline_bundle,
                selected,
                CellQ24PrivateHeadV1::Drive { index: 0 },
                &actual,
            )?;
            anyhow::ensure!(
                model.components() == &selected.components,
                "actual trained heads do not match selected C"
            );
            let copy = OriginalFileData::reserve(directory.join("d-selected-heads"), 60001, 60001)?;
            copy.write_original_once(&actual)?;
            (Arc::new(model), copy.path)
        } else {
            anyhow::ensure!(
                *selected == baseline_bundle,
                "NoUpdate must retain the original complete baseline bundle"
            );
            (baseline, baseline_path.join("heads"))
        };
        crate::cell_composed_q24::validate_manifest(selected, &original.selected.manifest)?;
        anyhow::ensure!(
            heads.0.components() == &selected.components,
            "new D actual component bytes differ from selected C manifest"
        );
        original.daemon.require_dead()?;
        original.root.require_dead()?;
        original.source.require_dead()?;
        Ok(Self {
            model: heads.0,
            deployment: json!({
                "model": {
                    "base": baseline_path.join("base"),
                    "organ_adapter": null,
                    "cell_adapter": null,
                    "encoder": baseline_path.join("encoder"),
                    "heads": heads.1,
                },
                "bundle": bundle_data(selected),
            }),
        })
    }
}

fn bundle_data(bundle: &CellCompatibilityBundleV1) -> Value {
    json!({
        "artifact_id":bundle.artifact_id.to_string(),
        "generation":bundle.generation.get(),
        "training_lineage":bundle.training_lineage.as_ref().map(|lineage| json!({
            "source_bundle":lineage.source_bundle.into_array(),
            "dataset":lineage.dataset.into_array(),
            "update_rule":lineage.update_rule.into_array(),
            "evaluation_profile":lineage.evaluation_profile.into_array(),
        })),
        "rollback_predecessor":bundle.rollback_predecessor.map(Digest32::into_array),
    })
}
