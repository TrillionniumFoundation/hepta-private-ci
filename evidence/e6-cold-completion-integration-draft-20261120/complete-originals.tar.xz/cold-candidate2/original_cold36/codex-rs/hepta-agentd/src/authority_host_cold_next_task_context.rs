//! A synchronous operation under the new Root's jointly held issuer and writer.
//! Old C/learning expiry is not consulted or renewed. The callback cannot carry
//! a borrowed operation capability out of this registry boundary.

use std::marker::PhantomData;
use std::rc::Rc;
use std::time::Instant;

use codex_hepta_contracts::FinalUseRevocations;
use codex_hepta_contracts::RootAuthorityDirectory;
use codex_hepta_contracts::authority_lease::AuthorityLease;

use super::*;
use crate::HostAuthorityWriterRegistration;
use crate::HostSignedWriterAuthorizationV1;
use crate::authority_host_runtime::verify_pinned_process;

#[path = "authority_host_cold_next_task_grant.rs"]
mod grant;
pub(crate) use grant::RootPreparedColdNextTaskGrantV1;

pub(super) struct OriginalColdNextTaskContextV1<'a> {
    service: &'a HostAuthorityService,
    config: &'a HostAuthorityServiceConfig,
    registration: &'a HostAuthorityRegistration,
    owner: &'a OwnedFd,
    writer: &'a HostAuthorityWriterRegistration,
    proof: &'a HostSignedWriterAuthorizationV1,
    issuer_lease: &'a AuthorityLease,
    revocations: FinalUseRevocations,
    valid_until_ms: u64,
    end: Instant,
    _operation: &'a (),
    _not_send: PhantomData<Rc<()>>,
}

impl OriginalColdNextTaskContextV1<'_> {
    pub(super) fn require_current(&self) -> io::Result<u64> {
        original_root()?;
        refusal::require_end(self.end)?;
        self.config.required_bind.verify()?;
        verify_pinned_process(
            self.registration,
            self.config.peer_uid,
            self.config.peer_gid,
            self.owner,
            self.end,
        )?;
        self.service.check_logind_lifetime()?;
        if self.service.issuer.revocations()? != self.revocations
            || self
                .service
                .issuer
                .retained_writer_authorization(self.writer)?
                != *self.proof
            || self.config.writer.as_ref() != Some(self.writer)
            || self.registration.registered_identity.identity()? != self.service.identity
        {
            return Err(io::Error::other("cold next-task Root authority changed"));
        }
        let now = self
            .service
            .clock
            .refresh_projection()
            .map_err(io::Error::other)?
            .observed_unix_ms;
        super::super::validate_observation_lease(self.issuer_lease, &self.revocations, now)?;
        super::super::validate_observation_lease(
            &self.writer.authority_lease,
            &self.revocations,
            now,
        )?;
        if now >= self.valid_until_ms {
            return Err(io::Error::other("cold next-task operation expired"));
        }
        refusal::require_end(self.end)?;
        Ok(now)
    }

    pub(super) fn original_root_inputs(
        &self,
    ) -> (&HostAuthorityService, &HostAuthorityServiceConfig) {
        (self.service, self.config)
    }

    pub(super) fn authority_epoch(&self) -> u64 {
        self.revocations.authority_epoch
    }

    pub(super) fn revocations(&self) -> &FinalUseRevocations {
        &self.revocations
    }

    pub(super) fn writer_proof(&self) -> io::Result<String> {
        self.proof
            .sha256()
            .map(|value| value.as_str().to_owned())
            .map_err(io::Error::other)
    }

    pub(super) fn identity(&self) -> &crate::AgentdIdentity {
        &self.service.identity
    }

    pub(super) fn valid_until_ms(&self) -> u64 {
        self.valid_until_ms
    }
}

impl HostAuthorityService {
    pub(super) fn with_cold_next_task_context<T>(
        &self,
        config: &HostAuthorityServiceConfig,
        registration: &HostAuthorityRegistration,
        owner: &OwnedFd,
        end: Instant,
        action: impl for<'operation> FnOnce(&OriginalColdNextTaskContextV1<'operation>) -> io::Result<T>,
    ) -> io::Result<T> {
        original_root()?;
        refusal::require_end(end)?;
        config.required_bind.verify()?;
        RootAuthorityDirectory::open(&config.state_dir).map_err(io::Error::other)?;
        if config.schema_version != 1
            || registration.schema_version != 1
            || config.peer_uid == 0
            || config.peer_gid == 0
            || !(1..=500).contains(&config.timeout_ms)
            || !(1..=300_000).contains(&config.lifetime_ms)
            || !config
                .state_dir
                .starts_with(&config.required_bind.mountpoint)
            || registration.registered_identity.identity()? != self.identity
        {
            return Err(io::Error::other(
                "original bounded cold Root context required",
            ));
        }
        let writer = self
            .writer
            .as_ref()
            .ok_or_else(|| io::Error::other("registered cold writer required"))?;
        if config.writer.as_ref() != Some(&writer.registration) {
            return Err(io::Error::other("original cold writer differs"));
        }
        verify_pinned_process(registration, config.peer_uid, config.peer_gid, owner, end)?;
        self.check_logind_lifetime()?;
        crate::DeploymentFinalUseIssuer::with_live_issuer_and_writer(
            &self.issuer,
            &writer.registration,
            |issuer_lease| {
                if self
                    .issuer
                    .retained_writer_authorization(&writer.registration)?
                    != writer.proof
                {
                    return Err(io::Error::other("original cold writer proof changed"));
                }
                let revocations = self.issuer.revocations()?;
                let now = self
                    .clock
                    .refresh_projection()
                    .map_err(io::Error::other)?
                    .observed_unix_ms;
                let remaining = end
                    .checked_duration_since(Instant::now())
                    .filter(|duration| !duration.is_zero())
                    .ok_or_else(|| io::Error::other("original cold session ended"))?;
                let end_ms = now
                    .checked_add(u64::try_from(remaining.as_millis()).map_err(io::Error::other)?)
                    .ok_or_else(|| io::Error::other("original cold end overflow"))?;
                let operation = ();
                let context = OriginalColdNextTaskContextV1 {
                    service: self,
                    config,
                    registration,
                    owner,
                    writer: &writer.registration,
                    proof: &writer.proof,
                    issuer_lease,
                    revocations,
                    valid_until_ms: issuer_lease
                        .expires_at_unix_ms
                        .min(writer.registration.authority_lease.expires_at_unix_ms)
                        .min(end_ms),
                    end,
                    _operation: &operation,
                    _not_send: PhantomData,
                };
                context.require_current()?;
                let result = action(&context);
                // Even an issuer error, caught callback error or lost publication
                // acknowledgement cannot skip either physical authority postcheck.
                context.require_current()?;
                result
            },
        )
    }
}
