//! Factual finalized C custody for a separately authorized next task. The
//! actual completed-history receipt is required; ordinary C JSON cannot open
//! this reader. It never captures, edits, replays or reactivates the old owner.

use std::path::Path;

use super::*;
use crate::authority_host_runtime::RootFinalizedColdHistoryV1;
use crate::authority_host_service::generation_publication::OriginalControlRecord;
use codex_hepta_neuron::CellGenerationOwnerBindingV1;

pub(crate) struct RootFinalizedColdCReadV1 {
    held: RegisteredSuccessorData,
    record: OriginalControlRecord,
    expected: RootCompletedSuccessorDataV1,
    previous: CellGenerationOwnerBindingV1,
}

impl RootFinalizedColdCReadV1 {
    pub(in super::super) fn retain_original(
        history: &RootFinalizedColdHistoryV1<'_>,
        root: Arc<RootAuthorityDirectory>,
        root_path: &Path,
        files: Arc<RootOriginalSuccessorFilesV1>,
        previous: &CellGenerationOwnerBindingV1,
        uid: u32,
        gid: u32,
    ) -> io::Result<Self> {
        original_root()?;
        history.require_physical()?;
        let owner = format!(
            "publication-task/{}",
            Digest32::of_bytes(history.original_operation().as_str().as_bytes()),
        );
        let record_pin = OriginalControlRecord::open(root_path, &owner)?;
        let store = HostAuthorityFrontierStore::<SuccessorRecord>::open(root, owner.clone())
            .map_err(io::Error::other)?;
        let record = store.load(&owner).map_err(io::Error::other)?;
        let profile = ReservedPublicationProfile::original_for_version(
            &record.profile,
            PublicationVersion::DurableV2,
        )?;
        if record.schema != 1
            || record.purpose != SUCCESSOR_PURPOSE
            || record.files != files.deployment_digest()?.to_string()
            || record.publisher.uid != uid
            || record.peer_gid != gid
            || record.publisher_epoch == 0
            || profile.learning_operation != history.original_operation().as_str()
            || profile.initial != history.completion().initial
            || profile.scope != history.completion().frozen_scope
            || profile.intent.target != *previous
            || !matches!(&record.phase, SuccessorPhase::Finalized { .. })
        {
            return Err(io::Error::other(
                "original cold finalized C registration differs",
            ));
        }
        let held: RegisteredSuccessorData = RegisteredSuccessorData {
            store,
            owner,
            original: Mutex::new(record),
            files,
        };
        let cut = held.observe_retired(/*capture*/ false)?;
        let expected: RootCompletedSuccessorDataV1 = held.read_data(cut)?;
        if expected.record_digest != history.completion().successor_record
            || expected.original_cut_digest()?.to_string() != history.completion().successor_cut
        {
            return Err(io::Error::other(
                "actual completed history does not name original C",
            ));
        }
        let reader = Self {
            held,
            record: record_pin,
            expected,
            previous: previous.clone(),
        };
        reader.read_original(history)?;
        Ok(reader)
    }

    pub(in super::super) fn read_original(
        &self,
        history: &RootFinalizedColdHistoryV1<'_>,
    ) -> io::Result<RootCompletedSuccessorDataV1> {
        original_root()?;
        history.require_physical()?;
        self.record.require_unchanged()?;
        self.held.require_exact()?;
        let original = self
            .held
            .original
            .try_lock()
            .map_err(|_| io::Error::other("original cold C observation busy"))?;
        let profile = ReservedPublicationProfile::original_for_version(
            &original.profile,
            PublicationVersion::DurableV2,
        )?;
        if profile.intent.target != self.previous
            || self.expected.record_digest != history.completion().successor_record
            || RootCompletedSuccessorDataV1::original_cut_digest(&self.expected)?.to_string()
                != history.completion().successor_cut
        {
            return Err(io::Error::other("original cold C predecessor changed"));
        }
        drop(original);
        let cut = RegisteredSuccessorData::observe_retired(&self.held, /*capture*/ false)?;
        let data = RegisteredSuccessorData::read_data(&self.held, cut)?;
        if data != self.expected {
            return Err(io::Error::other("physical finalized C differs"));
        }
        self.held.finish_observed(&data.cut)?;
        self.record.require_unchanged()?;
        history.require_physical()?;
        Ok(data)
    }
}
