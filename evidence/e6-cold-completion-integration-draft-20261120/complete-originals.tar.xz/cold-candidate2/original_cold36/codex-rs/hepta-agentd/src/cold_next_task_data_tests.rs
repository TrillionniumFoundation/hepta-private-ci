//! Signed DATA boundary tests. No Root session, owner or issuer is constructed.

use ed25519_dalek::Signer;
use ed25519_dalek::SigningKey;
use pretty_assertions::assert_eq;
use serde_json::json;

use super::*;

struct SignedDataCase {
    binding: ColdNextTaskBindingDataV1,
    policy: ColdNextTaskControllerDataV1,
    trust: TextTrust,
    authorization: ColdNextTaskAuthorizationDataV1,
}

impl SignedDataCase {
    fn new() -> anyhow::Result<Self> {
        let key = SigningKey::from_bytes(&[97; 32]);
        let binding = ColdNextTaskBindingDataV1 {
            agent: "cold-native-agent".into(),
            principal: Digest32::of_bytes(b"current principal"),
            authority_epoch: 3,
            recipient: Digest32::of_bytes(b"new pidfd recipient"),
            writer: Digest32::of_bytes(b"new writer proof"),
            predecessor_current: Digest32::of_bytes(b"physical finalized C CURRENT"),
            predecessor_record: Digest32::of_bytes(b"physical finalized C record"),
            predecessor_cut: Digest32::of_bytes(b"physical finalized C cut"),
            input: Digest32::of_bytes(b"complete D input"),
            task: Digest32::of_bytes(b"new D run and task"),
            target: Digest32::of_bytes(b"new D owner binding"),
            intent: Digest32::of_bytes(b"exact Root-derived FinalUse intent"),
            manifest: Digest32::of_bytes(b"full selected C manifest"),
            selection: Digest32::of_bytes(b"current C selection"),
            objective: Digest32::of_bytes(b"original verified Objective claims"),
            objective_message_id: "cold-objective-d".into(),
            objective_sequence: 41,
            objective_signature: Digest32::of_bytes(b"original Objective signature"),
            objective_expiry_ms: 3_000,
            consumer: RootPublicationFinalUseConsumerV1::Device,
            consumer_trust: Digest32::of_bytes(b"fixed current device trust"),
        };
        let mut authorization = ColdNextTaskAuthorizationDataV1 {
            schema: 1,
            purpose: AUTHORIZATION_PURPOSE.into(),
            issuer_id: "current-cold-controller".into(),
            key_epoch: 2,
            message_id: "cold-authorization-d".into(),
            sequence: 42,
            expires_at_ms: 4_000,
            payload: binding.digest()?.to_string(),
            signature_hex: String::new(),
        };
        authorization.signature_hex = key
            .sign(&authorization.claims(&binding)?.signing_bytes())
            .to_bytes()
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect();
        let policy = ColdNextTaskControllerDataV1 {
            schema: 1,
            purpose: AUTHORIZATION_PURPOSE.into(),
            role: ColdNextTaskControllerRoleV1::ColdNextTask,
            principal: binding.principal.to_string(),
            issuer: authorization.issuer_id.clone(),
            key_epoch: authorization.key_epoch,
            authority_epoch: binding.authority_epoch,
            agent: binding.agent.clone(),
            allowed_scope: binding.scope()?.to_string(),
        };
        let public_key_hex: String = key
            .verifying_key()
            .to_bytes()
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect();
        let trust = serde_json::from_value(json!({
            "schema_version": 1, "agent_id": binding.agent,
            "issuer_id": authorization.issuer_id, "key_epoch": 2,
            "public_key_hex": public_key_hex, "revoked": false, "thread_ids": []
        }))?;
        Ok(Self {
            binding,
            policy,
            trust,
            authorization,
        })
    }

    fn require_current(&self, now: u64) -> Result<(), AgentdError> {
        self.authorization
            .require_current(&self.policy, &self.trust, &self.binding, now)
    }
}

#[test]
fn cold_next_task_accepts_exact_canonical_signed_data() -> anyhow::Result<()> {
    let case = SignedDataCase::new()?;
    let bytes = serde_json::to_vec(&case.authorization)?;
    let restored = ColdNextTaskAuthorizationDataV1::from_original_bytes(&bytes)?;
    assert_eq!(restored, case.authorization);
    case.require_current(2_000)?;
    case.require_current(2_999)?;
    Ok(())
}

#[test]
fn cold_next_task_rejects_unsigned_c_model_input_recipient_and_consumer_changes()
-> anyhow::Result<()> {
    for field in 0..16 {
        let mut case = SignedDataCase::new()?;
        let replacement = Digest32::of_bytes(b"substituted original fact");
        match field {
            0 => case.binding.principal = replacement,
            1 => case.binding.recipient = replacement,
            2 => case.binding.writer = replacement,
            3 => case.binding.predecessor_current = replacement,
            4 => case.binding.predecessor_record = replacement,
            5 => case.binding.predecessor_cut = replacement,
            6 => case.binding.input = replacement,
            7 => case.binding.task = replacement,
            8 => case.binding.target = replacement,
            9 => case.binding.manifest = replacement,
            10 => case.binding.selection = replacement,
            11 => case.binding.objective = replacement,
            12 => case.binding.objective_signature = replacement,
            13 => case.binding.consumer_trust = replacement,
            14 => case.binding.consumer = RootPublicationFinalUseConsumerV1::Notes,
            15 => case.binding.intent = replacement,
            _ => unreachable!(),
        }
        assert!(
            case.require_current(2_000).is_err(),
            "changed original field {field}"
        );
    }
    Ok(())
}

#[test]
fn cold_next_task_rejects_objective_signature_identity_nonce_and_expiry_swap() -> anyhow::Result<()>
{
    let mut case = SignedDataCase::new()?;
    case.binding.objective_message_id = "another-objective".into();
    assert!(case.require_current(2_000).is_err());
    let mut case = SignedDataCase::new()?;
    case.binding.objective_sequence += 1;
    assert!(case.require_current(2_000).is_err());
    let mut case = SignedDataCase::new()?;
    case.binding.objective_expiry_ms += 1;
    assert!(case.require_current(2_000).is_err());
    let mut case = SignedDataCase::new()?;
    case.authorization.message_id = case.binding.objective_message_id.clone();
    assert!(case.authorization.claims(&case.binding).is_err());
    let mut case = SignedDataCase::new()?;
    case.authorization.sequence = case.binding.objective_sequence;
    assert!(case.authorization.claims(&case.binding).is_err());
    Ok(())
}

#[test]
fn cold_next_task_rejects_controller_policy_and_authority_epoch_changes() -> anyhow::Result<()> {
    for field in 0..8 {
        let mut case = SignedDataCase::new()?;
        match field {
            0 => case.policy.principal = Digest32::of_bytes(b"other principal").to_string(),
            1 => case.policy.issuer = "another-controller".into(),
            2 => case.policy.key_epoch += 1,
            3 => case.policy.authority_epoch += 1,
            4 => case.policy.allowed_scope = Digest32::of_bytes(b"another scope").to_string(),
            5 => case.policy.agent = "another-agent".into(),
            6 => case.policy.purpose = "runtime.objective".into(),
            7 => case.binding.authority_epoch += 1,
            _ => unreachable!(),
        }
        assert!(
            case.require_current(2_000).is_err(),
            "changed installed policy {field}"
        );
    }
    Ok(())
}

#[test]
fn cold_next_task_rejects_revocation_and_wrong_actual_signature() -> anyhow::Result<()> {
    let mut case = SignedDataCase::new()?;
    case.authorization.signature_hex = "00".repeat(64);
    assert!(case.require_current(2_000).is_err());
    let mut case = SignedDataCase::new()?;
    case.authorization.signature_hex = SigningKey::from_bytes(&[98; 32])
        .sign(&case.authorization.claims(&case.binding)?.signing_bytes())
        .to_bytes()
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect();
    assert!(case.require_current(2_000).is_err());
    let mut case = SignedDataCase::new()?;
    let public_key_hex: String = SigningKey::from_bytes(&[97; 32])
        .verifying_key()
        .to_bytes()
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect();
    case.trust = serde_json::from_value(json!({
        "schema_version": 1, "agent_id": case.binding.agent,
        "issuer_id": case.authorization.issuer_id, "key_epoch": 2,
        "public_key_hex": public_key_hex, "revoked": true, "thread_ids": []
    }))?;
    assert!(case.require_current(2_000).is_err());
    Ok(())
}

#[test]
fn cold_next_task_rejects_either_signature_expiry_without_renewing_history() -> anyhow::Result<()> {
    let case = SignedDataCase::new()?;
    assert!(case.require_current(0).is_err());
    assert!(case.require_current(3_000).is_err());
    assert!(case.require_current(4_000).is_err());
    let mut case = SignedDataCase::new()?;
    case.authorization.expires_at_ms = 2_000;
    case.authorization.signature_hex = SigningKey::from_bytes(&[97; 32])
        .sign(&case.authorization.claims(&case.binding)?.signing_bytes())
        .to_bytes()
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect();
    case.require_current(1_999)?;
    assert!(case.require_current(2_000).is_err());
    Ok(())
}

#[test]
fn cold_next_task_rejects_unknown_duplicate_noncanonical_and_oversized_data() -> anyhow::Result<()>
{
    let case = SignedDataCase::new()?;
    let bytes = serde_json::to_vec(&case.authorization)?;
    let mut whitespace = bytes.clone();
    whitespace.push(b'\n');
    assert!(ColdNextTaskAuthorizationDataV1::from_original_bytes(&whitespace).is_err());
    let mut value = serde_json::to_value(&case.authorization)?;
    value["trust"] = json!({"issuer": "self-authorized"});
    assert!(
        ColdNextTaskAuthorizationDataV1::from_original_bytes(&serde_json::to_vec(&value)?).is_err()
    );
    let duplicate = String::from_utf8(bytes)?.replacen("{", "{\"schema\":1,", 1);
    assert!(ColdNextTaskAuthorizationDataV1::from_original_bytes(duplicate.as_bytes()).is_err());
    assert!(
        ColdNextTaskAuthorizationDataV1::from_original_bytes(&vec![b' '; AUTHORIZATION_BOUND + 1])
            .is_err()
    );
    assert!(ColdNextTaskAuthorizationDataV1::from_original_bytes(&[]).is_err());
    let mut policy = serde_json::to_value(&case.policy)?;
    policy["role"] = json!("objective_start");
    assert!(serde_json::from_value::<ColdNextTaskControllerDataV1>(policy).is_err());
    Ok(())
}

#[test]
fn cold_next_task_rejects_reused_message_or_wrong_authorization_purpose() -> anyhow::Result<()> {
    for field in 0..5 {
        let mut case = SignedDataCase::new()?;
        match field {
            0 => case.authorization.message_id = "swapped-authorization".into(),
            1 => case.authorization.sequence += 1,
            2 => case.authorization.key_epoch += 1,
            3 => case.authorization.purpose = "runtime.objective".into(),
            4 => case.authorization.signature_hex = case.authorization.signature_hex.to_uppercase(),
            _ => unreachable!(),
        }
        assert!(
            case.require_current(2_000).is_err(),
            "changed signed authorization {field}"
        );
    }
    Ok(())
}
