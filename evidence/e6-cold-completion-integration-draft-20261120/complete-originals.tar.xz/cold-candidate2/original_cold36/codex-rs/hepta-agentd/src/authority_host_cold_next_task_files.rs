//! Root-only fixed input custody for the independently authorized cold D.
//! The constructor requires the actual new recipient's completed C capability;
//! this metadata and its parsed material never construct an owner or grant.

use std::io;
use std::os::unix::fs::FileExt;
use std::path::Path;
use std::sync::Arc;
use std::sync::Mutex;

use serde::Deserialize;
use serde::Serialize;
use sha2::Digest;

use super::data::LateMaterial;
use super::data::Mode;
use super::data::ObserverData;
use super::data::SelectionData;
use super::files::DirectoryPin;
use super::files::MetadataFile;
use super::files::OriginalFile;
use super::input_data::PublicationInputData;
use super::inputs::OriginalInputs;
use super::post_a::OriginalPostAPublicationFiles;
use super::post_a::RootOriginalSuccessorFilesV1;
use super::post_a::RootSuccessorTaskFilesDataV1;
use crate::AgentdIdentity;
use crate::RootGenerationPublicationEnrollmentV1;
use crate::authority_host_runtime::ColdNextTaskAuthorizationFilesDataV1;
use crate::authority_host_runtime::RootColdNextTaskAuthorizationFilesV1;
use crate::authority_host_runtime::RootFinalizedColdHistoryV1;
use crate::authority_host_service::generation_publication::original_root;

pub(crate) const DEPLOYMENT_PURPOSE: &str = "runtime.circuit.cold-next-task-deployment.v1";

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct ColdNextTaskDeploymentDataV1 {
    schema: u8,
    purpose: String,
    operation: String,
    inputs: PublicationInputData,
    material: LateMaterial,
    successor: RootSuccessorTaskFilesDataV1,
    authorization: ColdNextTaskAuthorizationFilesDataV1,
    writer_lease: std::path::PathBuf,
    writer_lease_sha256: [u8; 32],
}

/// Fixed data authenticated only by the actual Root sealed route. These
/// fields do not construct a writer, selector, CURRENT owner or grant.
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ColdNextTaskPreparationDataV1 {
    pub(crate) inputs: PublicationInputData,
    pub(crate) target: ObserverData,
    pub(crate) selection: SelectionData,
    pub(crate) successor: RootSuccessorTaskFilesDataV1,
    pub(crate) writer_lease: std::path::PathBuf,
    pub(crate) writer_lease_sha256: [u8; 32],
}

impl ColdNextTaskDeploymentDataV1 {
    fn decode_original(bytes: &[u8]) -> io::Result<Self> {
        let data: Self = serde_json::from_slice(bytes).map_err(io::Error::other)?;
        codex_hepta_types::StableId::new(&data.operation).map_err(io::Error::other)?;
        super::files::require_absolute(&data.writer_lease)?;
        if data.schema != 1
            || data.purpose != DEPLOYMENT_PURPOSE
            || !matches!(data.inputs.mode, Mode::Reserve)
            || data.inputs.issuer_keys.is_empty()
            || data.material.schema_version != 1
            || data.writer_lease_sha256 == [0; 32]
        {
            return Err(io::Error::other(
                "one original explicit cold task deployment required",
            ));
        }
        Ok(data)
    }
}

pub(crate) struct RootColdNextTaskFilesV1 {
    descriptor: MetadataFile,
    identity: AgentdIdentity,
    uid: u32,
    gid: u32,
    originals: OriginalInputs,
    directories: Vec<DirectoryPin>,
    artifact_files: Vec<OriginalFile>,
    artifact_lease: OriginalFile,
    artifact_lease_digest: [u8; 32],
    original_c: Arc<OriginalPostAPublicationFiles>,
    ready: Mutex<Option<RootGenerationPublicationEnrollmentV1>>,
    pub(crate) current_path: std::path::PathBuf,
    pub(crate) operation: String,
    pub(crate) predecessor: Arc<RootOriginalSuccessorFilesV1>,
    pub(crate) source: Arc<RootOriginalSuccessorFilesV1>,
    pub(crate) authorization: Arc<RootColdNextTaskAuthorizationFilesV1>,
}

impl RootColdNextTaskFilesV1 {
    pub(in crate::authority_host_runtime::session) fn original_preparation_data(
        bytes: &[u8],
    ) -> io::Result<ColdNextTaskPreparationDataV1> {
        original_root()?;
        let data = ColdNextTaskDeploymentDataV1::decode_original(bytes)?;
        Ok(ColdNextTaskPreparationDataV1 {
            inputs: data.inputs,
            target: data.material.target,
            selection: data.material.selection,
            successor: data.successor,
            writer_lease: data.writer_lease,
            writer_lease_sha256: data.writer_lease_sha256,
        })
    }

    fn require_original_artifact_lease(&self) -> io::Result<()> {
        self.artifact_lease.require_original_file()?;
        let file = self.artifact_lease.original_descriptor()?;
        let length = file.metadata()?.len();
        if !(1..=16_384).contains(&length) {
            return Err(io::Error::other("bounded original Artifact lease required"));
        }
        for _ in 0..2 {
            let mut bytes = vec![0; length as usize];
            file.read_exact_at(&mut bytes, /*offset*/ 0)?;
            let digest: [u8; 32] = sha2::Sha256::digest(&bytes).into();
            if file.metadata()?.len() != length || digest != self.artifact_lease_digest {
                return Err(io::Error::other("original Artifact lease bytes changed"));
            }
            self.artifact_lease.require_original_file()?;
        }
        Ok(())
    }

    pub(in crate::authority_host_runtime::session) fn open_original(
        path: &Path,
        history: &RootFinalizedColdHistoryV1<'_>,
        identity: &AgentdIdentity,
        uid: u32,
        gid: u32,
    ) -> io::Result<Arc<Self>> {
        original_root()?;
        history.require_physical()?;
        if history.completion().identity_digest
            != crate::neuron_generation_process_identity_digest_v1(identity)
                .map_err(io::Error::other)?
                .to_string()
        {
            return Err(io::Error::other(
                "cold fixed files require the actual new C observer",
            ));
        }
        let (descriptor, bytes) = MetadataFile::open_metadata(path)?;
        let data = ColdNextTaskDeploymentDataV1::decode_original(&bytes)?;
        let (original_c, predecessor) = OriginalPostAPublicationFiles::retain_cold_publication(
            history,
            &data.inputs,
            uid,
            gid,
        )?;
        let directories = vec![
            DirectoryPin::capture_root(&data.inputs.current_directory)?,
            DirectoryPin::capture_private(&data.inputs.artifact_root)?,
            DirectoryPin::capture_private(&data.inputs.consumer_state_root)?,
        ];
        let originals = OriginalInputs {
            current: codex_hepta_contracts::RootAuthorityDirectory::open(
                &data.inputs.current_directory,
            )
            .map_err(io::Error::other)?,
            previous_journal: OriginalFile::open_original(&data.inputs.previous_journal)?,
            previous_witness: OriginalFile::open_original(&data.inputs.previous_witness)?,
            target_journal: OriginalFile::open_original(&data.inputs.target_journal)?,
            target_witness: OriginalFile::open_original(&data.inputs.target_witness)?,
            withdrawal: OriginalFile::open_original(&data.inputs.withdrawal_file)?,
        };
        let source =
            RootOriginalSuccessorFilesV1::open_original(data.successor, uid, gid, Mode::Reserve)?;
        for file in [
            &originals.previous_journal,
            &originals.previous_witness,
            &originals.target_journal,
            &originals.target_witness,
            &originals.withdrawal,
        ] {
            source.require_distinct(file)?;
        }
        let authorization = Arc::new(RootColdNextTaskAuthorizationFilesV1::open_original(
            data.authorization,
            identity,
        )?);
        let (inputs, artifact_files) =
            originals.enrollment_inputs(&data.inputs, &data.material, uid)?;
        let artifact_lease = OriginalFile::open_original(&data.writer_lease)?;
        let retained = Arc::new(Self {
            descriptor,
            identity: identity.clone(),
            uid,
            gid,
            originals,
            directories,
            artifact_files,
            artifact_lease,
            artifact_lease_digest: data.writer_lease_sha256,
            original_c,
            ready: Mutex::new(Some(inputs)),
            current_path: data.inputs.current_directory,
            operation: data.operation,
            predecessor,
            source,
            authorization,
        });
        retained.require_original_artifact_lease()?;
        retained.require_recipient(identity, uid, gid)?;
        history.require_physical()?;
        Ok(retained)
    }

    pub(crate) fn take_original_inputs(
        &self,
        identity: &AgentdIdentity,
        uid: u32,
        gid: u32,
    ) -> io::Result<RootGenerationPublicationEnrollmentV1> {
        self.require_recipient(identity, uid, gid)?;
        let inputs = self
            .ready
            .try_lock()
            .map_err(|_| io::Error::other("original cold input enrollment busy"))?
            .take()
            .ok_or_else(|| io::Error::other("original cold inputs were already consumed"))?;
        self.require_recipient(identity, uid, gid)?;
        Ok(inputs)
    }

    pub(crate) fn require_recipient(
        &self,
        identity: &AgentdIdentity,
        uid: u32,
        gid: u32,
    ) -> io::Result<()> {
        original_root()?;
        if &self.identity != identity || self.uid != uid || self.gid != gid || uid == 0 || gid == 0
        {
            return Err(io::Error::other("original cold fixed recipient changed"));
        }
        self.descriptor.require_metadata_unchanged()?;
        self.original_c.require_original_files()?;
        for directory in &self.directories {
            directory.require_directory()?;
        }
        self.originals.require_original_inputs()?;
        for file in &self.artifact_files {
            file.require_original_file()?;
        }
        self.source.require_original()?;
        self.require_original_artifact_lease()?;
        self.authorization.require_original_files()?;
        self.original_c.require_original_files()?;
        self.descriptor.require_metadata_unchanged()
    }
}
