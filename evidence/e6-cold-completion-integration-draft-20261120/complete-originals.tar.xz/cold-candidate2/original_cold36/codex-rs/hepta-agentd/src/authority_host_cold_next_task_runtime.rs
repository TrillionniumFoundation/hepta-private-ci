//! One authenticated connection to the fixed cold D purpose. Enrollment reads
//! completed C outside the joint issuer/writer scope; subsequent frames borrow
//! the same actual slot and durable sequence. There is no reconnect or retry.

use std::io::Write;
use std::net::Shutdown;
use std::os::unix::fs::MetadataExt;
use std::os::unix::fs::PermissionsExt;
use std::os::unix::net::UnixListener;
use std::os::unix::net::UnixStream;
use std::sync::Arc;
use std::sync::Mutex;
use std::sync::atomic::AtomicBool;
use std::time::Duration;

use codex_hepta_contracts::HostAuthorityPeerChannel;
use codex_hepta_contracts::HostAuthorityPeerPolicy;
use codex_hepta_contracts::HostIssuerPeer;
use codex_hepta_contracts::HostIssuerTransportError;

use super::*;
use crate::authority_host_runtime::RootColdNextTaskFilesV1;
use crate::authority_host_runtime::owner_alive;
use crate::authority_host_runtime::validate_lane_paths;
use crate::authority_host_runtime::validate_runtime_lanes;
use crate::authority_host_runtime::verify_pinned_process;
use crate::authority_host_service::generation_publication::RegisteredColdNextTaskV1;
use crate::cold_next_task_protocol::ColdNextTaskCommandV1;
use crate::cold_next_task_protocol::ColdNextTaskRequestV1;
use crate::cold_next_task_protocol::MAX_REQUESTS;
use crate::cold_next_task_protocol::WIRE_BOUND;

pub(in super::super) struct BoundColdNextTask {
    runtime: ColdNextTaskRuntime,
    listener: UnixListener,
    device: u64,
    inode: u64,
}

impl BoundColdNextTask {
    pub(in super::super) fn bind(
        runtime: ColdNextTaskRuntime,
        config: &HostAuthorityServiceConfig,
    ) -> io::Result<Self> {
        original_root()?;
        runtime
            .phase
            .compare_exchange(SEALED, SERVING, Ordering::AcqRel, Ordering::Acquire)
            .map_err(|_| io::Error::other("original cold task offer was not sealed"))?;
        runtime.metadata.require_metadata_unchanged()?;
        let mut paths: Vec<_> = validate_runtime_lanes(config)?
            .into_iter()
            .map(|(_, path)| path)
            .collect();
        paths.push(&runtime.socket);
        validate_lane_paths(&paths, config.peer_gid)?;
        let listener = UnixListener::bind(&runtime.socket)?;
        let metadata = std::fs::symlink_metadata(&runtime.socket)?;
        let bound = Self {
            runtime,
            listener,
            device: metadata.dev(),
            inode: metadata.ino(),
        };
        if metadata.uid() != 0 || metadata.gid() != config.peer_gid {
            return Err(io::Error::other("cold task listener custody differs"));
        }
        std::fs::set_permissions(
            &bound.runtime.socket,
            std::fs::Permissions::from_mode(0o660),
        )?;
        bound.listener.set_nonblocking(true)?;
        Ok(bound)
    }

    pub(in super::super) fn path(&self) -> &Path {
        &self.runtime.socket
    }
}

impl Drop for BoundColdNextTask {
    fn drop(&mut self) {
        self.runtime.phase.store(STOPPED, Ordering::Release);
        if std::fs::symlink_metadata(&self.runtime.socket)
            .is_ok_and(|entry| entry.dev() == self.device && entry.ino() == self.inode)
        {
            let _ = std::fs::remove_file(&self.runtime.socket);
        }
    }
}

pub(in super::super) fn serve_optional(
    bound: Option<&BoundColdNextTask>,
    historical: Option<&super::super::historical_read::BoundHistoricalTaskRead>,
    service: &HostAuthorityService,
    config: &HostAuthorityServiceConfig,
    registration: &HostAuthorityRegistration,
    owner: &OwnedFd,
    session_end: Instant,
    original: impl FnOnce() -> io::Result<()>,
) -> io::Result<()> {
    let Some(bound) = bound else {
        return original();
    };
    let historical =
        historical.ok_or_else(|| io::Error::other("cold task requires actual historical lane"))?;
    if bound.path() == historical.path() {
        return Err(io::Error::other(
            "cold and historical lanes must be distinct",
        ));
    }
    let stopping = AtomicBool::new(false);
    let active = Mutex::new(None::<UnixStream>);
    std::thread::scope(|scope| {
        let worker = scope.spawn(|| {
            let result = (|| {
                let stream = loop {
                    if stopping.load(Ordering::Acquire) {
                        return Ok(());
                    }
                    owner_alive(owner, session_end)?;
                    match bound.listener.accept() {
                        Ok((stream, _)) => break stream,
                        Err(error) if error.kind() == io::ErrorKind::WouldBlock => {
                            std::thread::sleep(Duration::from_millis(5));
                        }
                        Err(error) => return Err(error),
                    }
                };
                verify_pinned_process(
                    registration,
                    config.peer_uid,
                    config.peer_gid,
                    owner,
                    session_end,
                )?;
                {
                    let mut held = active
                        .lock()
                        .map_err(|_| io::Error::other("cold task stream slot poisoned"))?;
                    if stopping.load(Ordering::Acquire) {
                        return Ok(());
                    }
                    *held = Some(stream.try_clone()?);
                }
                let policy = HostAuthorityPeerPolicy {
                    peer: HostIssuerPeer {
                        uid: config.peer_uid,
                        pid: registration.peer_pid,
                    },
                    timeout: Duration::from_millis(config.timeout_ms),
                    lifetime: session_end
                        .checked_duration_since(Instant::now())
                        .ok_or_else(|| io::Error::other("original cold task session expired"))?,
                    request_bound: WIRE_BOUND,
                    response_bound: WIRE_BOUND,
                };
                let mut channel =
                    HostAuthorityPeerChannel::from_stream(stream, policy, owner.try_clone()?)
                        .map_err(io::Error::other)?;
                HostAuthorityPeerChannel::limit_original_end(&mut channel, session_end)
                    .map_err(io::Error::other)?;
                let mut sequence = 1_u64;
                let mut slot: Option<RegisteredColdNextTaskV1<'_>> = None;
                while channel
                    .exchange(|bytes| {
                        let mut run = || -> io::Result<Vec<u8>> {
                            if bound.runtime.phase.load(Ordering::Acquire) != SERVING
                                || stopping.load(Ordering::Acquire)
                                || Instant::now() >= session_end
                                || bytes.is_empty()
                                || bytes.len() > WIRE_BOUND
                            {
                                return Err(io::Error::other("original cold task session ended"));
                            }
                            let request: ColdNextTaskRequestV1 =
                                serde_json::from_slice(bytes).map_err(io::Error::other)?;
                            if request.schema != 1
                                || request.purpose != PURPOSE
                                || request.request_id != sequence
                                || !(1..=MAX_REQUESTS).contains(&sequence)
                            {
                                return Err(io::Error::other(
                                    "original cold task sequence differs",
                                ));
                            }
                            bound.runtime.metadata.require_metadata_unchanged()?;
                            if slot.is_none() {
                                if sequence != 1
                                    || !request.profile.is_empty()
                                    || !matches!(request.command, ColdNextTaskCommandV1::Observe)
                                {
                                    return Err(io::Error::other(
                                        "one initial cold Observe required",
                                    ));
                                }
                                // This operation returns Ready and releases all C history
                                // locks before entering the new joint issuer/writer context.
                                let history = super::super::historical_read::HistoricalTaskReadRuntime::retain_finalized_cold_history(
                                    &historical.runtime,
                                    service,
                                    config,
                                    registration,
                                    owner,
                                    session_end,
                                )?;
                                let identity = registration.registered_identity.identity()?;
                                let files = RootColdNextTaskFilesV1::open_original(
                                    &bound.runtime.deployment,
                                    &history,
                                    &identity,
                                    config.peer_uid,
                                    config.peer_gid,
                                )?;
                                bound.runtime.metadata.require_metadata_unchanged()?;
                                slot = Some(service.enroll_original_cold_next_task(
                                    config,
                                    registration,
                                    owner,
                                    session_end,
                                    history,
                                    Arc::clone(&files),
                                )?);
                            }
                            let original_slot = slot
                                .as_ref()
                                .ok_or_else(|| io::Error::other("original cold slot missing"))?;
                            let end = session_end
                                .min(Instant::now() + Duration::from_millis(config.timeout_ms));
                            let response = service.operate_original_cold_next_task(
                                config,
                                registration,
                                owner,
                                end,
                                original_slot,
                                &request,
                            )?;
                            bound.runtime.metadata.require_metadata_unchanged()?;
                            verify_pinned_process(
                                registration,
                                config.peer_uid,
                                config.peer_gid,
                                owner,
                                end,
                            )?;
                            response.require_data(&request)?;
                            let bytes = serde_json::to_vec(&response).map_err(io::Error::other)?;
                            if bytes.is_empty() || bytes.len() > WIRE_BOUND {
                                return Err(io::Error::other(
                                    "original cold response exceeds bound",
                                ));
                            }
                            sequence = sequence
                                .checked_add(1)
                                .ok_or_else(|| io::Error::other("cold sequence overflow"))?;
                            Ok(bytes)
                        };
                        run()
                            .inspect_err(|_| {
                                let _ =
                                    io::stderr().write_all(b"root_stage=cold_next_task.request\n");
                            })
                            .map_err(|_| HostIssuerTransportError::Unavailable)
                    })
                    .map_err(io::Error::other)?
                {
                    owner_alive(owner, session_end)?;
                }
                Ok(())
            })()
            .inspect_err(|_| {
                let _ = io::stderr().write_all(b"root_stage=cold_next_task.worker\n");
            });
            bound.runtime.phase.store(STOPPED, Ordering::Release);
            // A simultaneous original-lane shutdown cannot erase a real
            // callback, identity, sequence or physical-authority failure.
            result
        });
        let result = original();
        stopping.store(true, Ordering::Release);
        if let Some(stream) = active
            .lock()
            .map_err(|_| io::Error::other("cold task stream slot poisoned"))?
            .take()
        {
            let _ = stream.shutdown(Shutdown::Both);
        }
        let cold = worker
            .join()
            .map_err(|_| io::Error::other("cold task worker panicked"))?;
        result.and(cold)
    })
}
