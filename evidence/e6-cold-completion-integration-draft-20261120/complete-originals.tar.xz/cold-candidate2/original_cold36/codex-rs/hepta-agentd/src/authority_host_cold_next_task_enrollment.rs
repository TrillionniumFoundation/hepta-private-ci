//! Closed construction from the new Root's actual history and fixed files.
//! No peer supplies CURRENT, a generation owner, selection, controller or trust.

use super::*;
use crate::authority_host_runtime::RootColdNextTaskFilesV1;
use codex_hepta_neuron::CellGenerationOwnerBindingV1;

impl<'history> RegisteredColdNextTaskV1<'history> {
    fn from_original(
        context: &OriginalColdNextTaskContextV1<'_>,
        history: RootFinalizedColdHistoryV1<'history>,
        files: Arc<RootColdNextTaskFilesV1>,
    ) -> io::Result<Self> {
        let now = context.require_current()?;
        let (service, config) = context.original_root_inputs();
        history.require_physical()?;
        files.require_recipient(context.identity(), config.peer_uid, config.peer_gid)?;
        let inputs =
            files.take_original_inputs(context.identity(), config.peer_uid, config.peer_gid)?;
        if inputs.mode != RootGenerationPublicationModeV1::Reserve
            || files.operation == history.original_operation().as_str()
        {
            return Err(io::Error::other(
                "cold next task cannot recover or reset an uncertain transition",
            ));
        }
        let pin = super::super::super::generation_initial::artifact_pin(&inputs.artifacts)?;
        let artifact_binding = Digest32::of_parts(&[
            b"hepta.root.cold-next-task.original-artifacts.v1\0",
            &serde_json::to_vec(&pin).map_err(io::Error::other)?,
        ]);
        let (artifacts, selected) = super::super::super::generation_initial::open_artifacts(
            inputs.artifacts,
            config.peer_uid,
            now,
        )?;
        let target_config = &inputs.target.config.generation;
        if target_config.manifest != *selected.manifest()
            || inputs.previous.config.generation.manifest != *selected.manifest()
            || target_config.initial.revision != 0
            || !target_config.initial.prefix.is_empty()
            || target_config.initial.stopped
        {
            return Err(io::Error::other(
                "cold D requires a fresh task under the full selected C manifest",
            ));
        }
        let previous = inputs.previous.observe(config.peer_uid)?;
        let target = inputs.target.observe(config.peer_uid)?;
        let old = previous.observe().map_err(io::Error::other)?;
        if !old.is_drained() || old.owner_binding() != previous.owner_binding() {
            return Err(io::Error::other("actual drained C generation required"));
        }
        target
            .require_original_unwritten_or_genesis()
            .map_err(io::Error::other)?;
        let from: CellGenerationOwnerBindingV1 = previous.owner_binding().clone();
        let to = target.owner_binding().clone();
        let intent = UpdateIntent {
            operation_id: files.operation.clone(),
            supersedes: None,
            previous: from.clone(),
            previous_checkpoint: old.observation().owner_checkpoint().into_array(),
            previous_observation: old.observation().digest().map_err(io::Error::other)?,
            target: to.clone(),
            genesis_checkpoint: to.genesis_checkpoint().into_array(),
            selection: selected.observation().digest().into_array(),
            completion: crate::NeuronGenerationPredecessorCompletionV1::OwnerDrainedSameModel,
        };
        let current = NeuronGenerationCurrentOwnerV1::open(
            Arc::clone(&inputs.current_directory),
            from.scope(),
        )
        .map_err(io::Error::other)?;
        let original_head = current.original_broker_head().map_err(io::Error::other)?;
        if original_head.current != from
            || original_head.prepared.is_some()
            || original_head.initial.is_some()
            || original_head.published.is_none()
            || head_digest(&original_head)? != history.completion().current_head
        {
            return Err(io::Error::other(
                "cold next task requires the exact original finalized C CURRENT",
            ));
        }
        let predecessor = RootFinalizedColdCReadV1::retain_original(
            &history,
            Arc::clone(&inputs.current_directory),
            &files.current_path,
            Arc::clone(&files.predecessor),
            &from,
            config.peer_uid,
            config.peer_gid,
        )?;
        let original_c = history.completion().clone();
        let predecessor_data = predecessor.read_original(&history)?;
        let consumer_slot = inputs.consumer;
        let (consumer, _) = service.open_initial_consumer(
            config,
            consumer_slot,
            inputs.consumer_state_root,
            inputs.issuer_keys,
        )?;
        let consumer: RootFinalUseObserverV1 = consumer;
        let published_c = original_head
            .published
            .as_ref()
            .ok_or_else(|| io::Error::other("original C signed publication is missing"))?;
        if RootFinalUseObserverV1::verify_original_retained_use(
            &consumer,
            &published_c.signed,
            &published_c.intent.binding().map_err(io::Error::other)?,
            &published_c.witness,
        )
        .map_err(io::Error::other)?
            != *context.revocations()
        {
            return Err(io::Error::other(
                "current consumer denies the original C publication",
            ));
        }
        let source = Arc::clone(&files.source);
        let authorization = Arc::clone(&files.authorization);
        source.require_registered_baseline(context.identity(), &to)?;
        let input = source.observe_cold_next_task_input(context.identity(), &to)?;
        let binding = derive_original_binding(
            context,
            &original_c,
            &intent,
            selected.manifest(),
            input.configuration,
            &input.objective,
            consumer_slot,
            Digest32::from_array(consumer.issuer_trust_digest()),
        )?;
        authorization.require_current(
            context.identity(),
            &binding,
            &input.objective,
            now,
            context.authority_epoch(),
        )?;
        let expiry = context
            .valid_until_ms()
            .min(binding.objective_expiry_ms)
            .min(authorization.authorization().expires_at_ms);
        let mut profile = ColdNextTaskProfileV1 {
            purpose: COLD_PURPOSE.into(),
            identity: crate::neuron_generation_process_identity_digest_v1(context.identity())
                .map_err(io::Error::other)?
                .to_string(),
            writer: context.writer_proof()?,
            original_c,
            previous_files: previous.files_binding().to_string(),
            target_files: target.files_binding().to_string(),
            configuration: input.configuration.to_string(),
            artifacts: artifact_binding.to_string(),
            controller: authorization.controller_digest().to_string(),
            authorization_binding: binding.digest().map_err(io::Error::other)?.to_string(),
            authorization: authorization.authorization_digest().to_string(),
            authorization_id: authorization.authorization().message_id.clone(),
            objective: binding.objective.to_string(),
            objective_id: binding.objective_message_id,
            consumer: consumer_slot,
            consumer_trust: binding.consumer_trust.to_string(),
            valid_until_ms: expiry,
            manifest: selected.manifest().clone(),
            intent,
            binding: String::new(),
        };
        profile.binding = profile.digest()?;
        let (original_source, _) = profile.predecessor_data(&predecessor_data)?;
        if input.source.observation == original_source.input().observation {
            return Err(io::Error::other("cold D must supply a new actual input"));
        }
        profile.require_head_data(&original_head)?;
        files.require_recipient(context.identity(), config.peer_uid, config.peer_gid)?;
        history.require_physical()?;
        if context.require_current()? >= expiry {
            return Err(io::Error::other(
                "fresh cold D authorization ended before enrollment",
            ));
        }
        let operation = RegisteredColdNextTaskOperationV1::create_original(
            inputs.current_directory,
            profile.clone(),
        )?;
        let slot = Self {
            profile,
            history,
            predecessor,
            original_head,
            current,
            previous,
            target,
            artifacts,
            selected: Mutex::new(selected),
            consumer,
            source,
            authorization,
            operation,
            files,
            artifact_pin: pin,
        };
        slot.require_physical(context)?;
        context.require_current()?;
        Ok(slot)
    }
}

impl HostAuthorityService {
    pub(crate) fn enroll_original_cold_next_task<'history>(
        &self,
        config: &HostAuthorityServiceConfig,
        registration: &HostAuthorityRegistration,
        owner: &OwnedFd,
        end: std::time::Instant,
        history: RootFinalizedColdHistoryV1<'history>,
        files: Arc<RootColdNextTaskFilesV1>,
    ) -> io::Result<RegisteredColdNextTaskV1<'history>> {
        self.with_cold_next_task_context(config, registration, owner, end, |context| {
            RegisteredColdNextTaskV1::from_original(context, history, files)
        })
    }

    pub(crate) fn operate_original_cold_next_task(
        &self,
        config: &HostAuthorityServiceConfig,
        registration: &HostAuthorityRegistration,
        owner: &OwnedFd,
        end: std::time::Instant,
        slot: &RegisteredColdNextTaskV1<'_>,
        request: &ColdNextTaskRequestV1,
    ) -> io::Result<ColdNextTaskResponseV1> {
        self.with_cold_next_task_context(config, registration, owner, end, |context| {
            slot.execute(context, request)
        })
    }
}
