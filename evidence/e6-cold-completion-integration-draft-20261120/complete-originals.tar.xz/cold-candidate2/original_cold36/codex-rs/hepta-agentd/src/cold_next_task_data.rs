//! Data for one explicitly authorized cold next task. These values carry no
//! Root custody, CURRENT writer, consumer, or FinalUse capability. Both peers
//! derive the signed payload from the same fixed files and physical C cut.

use codex_hepta_authbus::SignedMessageClaims;
use codex_hepta_types::Digest32;
use codex_hepta_types::Generation;
use codex_hepta_types::StableId;
use ed25519_dalek::Signature;
use serde::Deserialize;
use serde::Serialize;

use crate::AgentdError;
use crate::RootPublicationFinalUseConsumerV1;
use crate::authbus_trust::TextTrust;

pub(crate) const AUTHORIZATION_PURPOSE: &str = "runtime.circuit.cold-next-task.authorization.v1";
pub(crate) const AUTHORIZATION_BOUND: usize = 16_384;

/// Installed by the original Root deployment, separately from both signed
/// requests. Deserializing this data does not admit a controller: the closed
/// Root lane must retain and recheck its original protected file.
#[derive(Debug, Eq, PartialEq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ColdNextTaskControllerDataV1 {
    pub(crate) schema: u8,
    pub(crate) purpose: String,
    pub(crate) role: ColdNextTaskControllerRoleV1,
    pub(crate) principal: String,
    pub(crate) issuer: String,
    pub(crate) key_epoch: u64,
    pub(crate) authority_epoch: u64,
    pub(crate) agent: String,
    pub(crate) allowed_scope: String,
}

#[derive(Debug, Eq, PartialEq, Deserialize, Serialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum ColdNextTaskControllerRoleV1 {
    ColdNextTask,
}

/// This is an additional, domain-separated AuthBus message. It does not change
/// ObjectiveStart's schema or the meanings of any existing Objective fields.
#[derive(Debug, Eq, PartialEq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ColdNextTaskAuthorizationDataV1 {
    pub(crate) schema: u8,
    pub(crate) purpose: String,
    pub(crate) issuer_id: String,
    pub(crate) key_epoch: u64,
    pub(crate) message_id: String,
    pub(crate) sequence: u64,
    pub(crate) expires_at_ms: u64,
    pub(crate) payload: String,
    pub(crate) signature_hex: String,
}

/// Canonical data derived inside the actual Root from fixed files and current
/// observations. There is no Deserialize implementation and no grant field.
#[derive(Debug)]
pub(crate) struct ColdNextTaskBindingDataV1 {
    pub(crate) agent: String,
    pub(crate) principal: Digest32,
    pub(crate) authority_epoch: u64,
    pub(crate) recipient: Digest32,
    pub(crate) writer: Digest32,
    pub(crate) predecessor_current: Digest32,
    pub(crate) predecessor_record: Digest32,
    pub(crate) predecessor_cut: Digest32,
    pub(crate) input: Digest32,
    pub(crate) task: Digest32,
    pub(crate) target: Digest32,
    pub(crate) intent: Digest32,
    pub(crate) manifest: Digest32,
    pub(crate) selection: Digest32,
    pub(crate) objective: Digest32,
    pub(crate) objective_message_id: String,
    pub(crate) objective_sequence: u64,
    pub(crate) objective_signature: Digest32,
    pub(crate) objective_expiry_ms: u64,
    pub(crate) consumer: RootPublicationFinalUseConsumerV1,
    pub(crate) consumer_trust: Digest32,
}

impl ColdNextTaskBindingDataV1 {
    pub(crate) fn digest(&self) -> Result<Digest32, AgentdError> {
        StableId::new(&self.agent).map_err(invalid)?;
        StableId::new(&self.objective_message_id).map_err(invalid)?;
        if self.authority_epoch == 0
            || self.objective_sequence == 0
            || self.objective_expiry_ms == 0
            || [
                self.principal,
                self.recipient,
                self.writer,
                self.predecessor_current,
                self.predecessor_record,
                self.predecessor_cut,
                self.input,
                self.task,
                self.target,
                self.intent,
                self.manifest,
                self.selection,
                self.objective,
                self.objective_signature,
                self.consumer_trust,
            ]
            .iter()
            .any(|digest| digest.is_zero())
        {
            return Err(invalid("incomplete original cold task binding"));
        }
        Ok(Digest32::of_parts(&[
            b"hepta.agentd.cold-next-task.authorization-payload.v1\0",
            &serde_json::to_vec(&(
                &self.agent,
                self.authority_epoch,
                [
                    self.principal.into_array(),
                    self.recipient.into_array(),
                    self.writer.into_array(),
                    self.predecessor_current.into_array(),
                    self.predecessor_record.into_array(),
                    self.predecessor_cut.into_array(),
                    self.input.into_array(),
                    self.task.into_array(),
                    self.target.into_array(),
                    self.intent.into_array(),
                    self.manifest.into_array(),
                    self.selection.into_array(),
                    self.objective.into_array(),
                    self.objective_signature.into_array(),
                    self.consumer_trust.into_array(),
                ],
                &self.objective_message_id,
                self.objective_sequence,
                self.objective_expiry_ms,
                &self.consumer,
            ))?,
        ]))
    }

    pub(crate) fn scope(&self) -> Result<Digest32, AgentdError> {
        StableId::new(&self.agent).map_err(invalid)?;
        if self.principal.is_zero() {
            return Err(invalid("original cold task principal required"));
        }
        Ok(Digest32::of_parts(&[
            b"hepta.agentd.cold-next-task.authorization-scope.v1\0",
            self.agent.as_bytes(),
            self.principal.as_array(),
        ]))
    }
}

impl ColdNextTaskAuthorizationDataV1 {
    pub(crate) fn from_original_bytes(bytes: &[u8]) -> Result<Self, AgentdError> {
        if bytes.is_empty() || bytes.len() > AUTHORIZATION_BOUND {
            return Err(invalid("original cold task authorization bound"));
        }
        let data: Self = serde_json::from_slice(bytes)?;
        if serde_json::to_vec(&data)? != bytes {
            return Err(invalid("canonical cold task authorization bytes required"));
        }
        Ok(data)
    }

    /// The result remains signed-message data. Only the Root's independently
    /// installed controller role/scope and exact FinalUse policy can admit it.
    pub(crate) fn claims(
        &self,
        original: &ColdNextTaskBindingDataV1,
    ) -> Result<SignedMessageClaims, AgentdError> {
        let payload = original.digest()?;
        if self.schema != 1
            || self.purpose != AUTHORIZATION_PURPOSE
            || self.payload != payload.to_string()
            || self.sequence == 0
            || self.message_id == original.objective_message_id
            || self.sequence == original.objective_sequence
            || self.expires_at_ms == 0
        {
            return Err(invalid("original cold task signed payload differs"));
        }
        Ok(SignedMessageClaims {
            issuer_id: StableId::new(&self.issuer_id).map_err(invalid)?,
            key_epoch: Generation::new(self.key_epoch).map_err(invalid)?,
            message_id: StableId::new(&self.message_id).map_err(invalid)?,
            subject_id: StableId::new(&original.agent).map_err(invalid)?,
            scope_digest: original.scope()?,
            payload_digest: payload,
            sequence: self.sequence,
            expires_at_ms: self.expires_at_ms,
        })
    }

    /// Pure verification only: this does not consume an AuthBus sequence,
    /// reserve a FinalUse nonce, or create a task/publication owner.
    pub(crate) fn require_current(
        &self,
        policy: &ColdNextTaskControllerDataV1,
        trust: &TextTrust,
        original: &ColdNextTaskBindingDataV1,
        now: u64,
    ) -> Result<(), AgentdError> {
        let claims = self.claims(original)?;
        let issuer = trust.issuer()?;
        if policy.schema != 1
            || policy.purpose != AUTHORIZATION_PURPOSE
            || policy.role != ColdNextTaskControllerRoleV1::ColdNextTask
            || policy.principal != original.principal.to_string()
            || policy.agent != original.agent
            || policy.issuer != self.issuer_id
            || policy.key_epoch != self.key_epoch
            || policy.authority_epoch != original.authority_epoch
            || policy.allowed_scope != claims.scope_digest.to_string()
            || issuer.revoked
            || issuer.issuer_id != claims.issuer_id
            || issuer.key_epoch != claims.key_epoch
            || now == 0
            || now >= self.expires_at_ms.min(original.objective_expiry_ms)
        {
            return Err(invalid(
                "current cold task controller authorization refused",
            ));
        }
        let signature_bytes = crate::authbus_trust::hex_bytes::<64>(&self.signature_hex)?;
        let canonical: String = signature_bytes
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect();
        if self.signature_hex != canonical {
            return Err(invalid("canonical cold task signature required"));
        }
        issuer
            .verifying_key
            .verify_strict(
                &claims.signing_bytes(),
                &Signature::from_bytes(&signature_bytes),
            )
            .map_err(|_| invalid("original cold task signature invalid"))?;
        Ok(())
    }
}

fn invalid(error: impl std::fmt::Display) -> AgentdError {
    AgentdError::GenerationFenced(format!("original cold next task: {error}"))
}

#[cfg(test)]
#[path = "cold_next_task_data_tests.rs"]
mod tests;
