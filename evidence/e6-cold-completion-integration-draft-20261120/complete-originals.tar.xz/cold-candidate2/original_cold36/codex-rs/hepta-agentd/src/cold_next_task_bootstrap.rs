//! Sealed routing DATA for one cold next-task purpose. Possessing these bytes
//! does not enroll a task, open CURRENT, or authorize a FinalUse grant.

use std::fs::File;
use std::path::PathBuf;

use codex_hepta_memory::CognitiveCheckpointPeerLifetime;
use serde::Deserialize;
use serde::Serialize;

use crate::HostAuthorityRegisteredIdentity;

pub(crate) const SOCKET: &str = "cell-cold-next-task-v1.sock";

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ColdNextTaskBootstrapV1 {
    pub(crate) schema: u8,
    pub(crate) purpose: String,
    pub(crate) root: CognitiveCheckpointPeerLifetime,
    pub(crate) consumer: CognitiveCheckpointPeerLifetime,
    pub(crate) identity: HostAuthorityRegisteredIdentity,
    pub(crate) writer: String,
    pub(crate) deployment: String,
    pub(crate) preparation: crate::authority_host_runtime::ColdNextTaskPreparationDataV1,
    pub(crate) socket: PathBuf,
}

/// The actual Root-created sealed route. It carries no writer or grant.
pub struct RootColdNextTaskOfferV1 {
    pub(crate) bootstrap: File,
}
