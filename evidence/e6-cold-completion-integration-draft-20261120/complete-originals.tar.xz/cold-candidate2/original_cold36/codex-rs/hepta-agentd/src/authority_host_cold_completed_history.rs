//! Read-only C facts retained by the actual newly serving Root. This object is
//! created only after the complete historical operation reaches Ready. It has
//! no grant, writer, CURRENT mutation or old learning-expiry authority.

use codex_hepta_agent_protocol::OriginalQ24CompletedHistoryDataV1;

use super::completed_files::CompletedFiles;
use super::completed_record::CompletedLearningRecord;
use super::completed_record::completed_learning_acceptance_owner;
use super::*;
use crate::authority_host_service::generation_publication::OriginalCompletedPublicationModeV1;
use crate::authority_host_service::generation_publication::OriginalControlRecord;

pub(crate) struct RootFinalizedColdHistoryV1<'a> {
    runtime: &'a HistoricalTaskReadRuntime,
    completion: OriginalQ24CompletedHistoryDataV1,
    operation: codex_hepta_types::StableId,
    acceptance: OriginalControlRecord,
    checkpoint: OriginalControlRecord,
    files: CompletedFiles,
    cuts: [String; 7],
    end: Instant,
}

impl HistoricalTaskReadRuntime {
    pub(in crate::authority_host_runtime::session) fn retain_finalized_cold_history(
        &self,
        service: &HostAuthorityService,
        config: &HostAuthorityServiceConfig,
        registration: &HostAuthorityRegistration,
        owner: &OwnedFd,
        end: Instant,
    ) -> io::Result<RootFinalizedColdHistoryV1<'_>> {
        original_root()?;
        require_end(end)?;
        if self.phase.load(Ordering::Acquire) != SERVING {
            return Err(io::Error::other("actual serving cold Root required"));
        }
        // The prior explicit capture must have finished. This call cannot turn
        // a Registered C into Finalized or admit an incomplete old operation.
        let observed = self.completed_learning_observation(
            service,
            config,
            registration,
            owner,
            HistoricalReadOperationV1::ReadCompletedHistory,
            end,
        )?;
        if observed.mode != OriginalCompletedPublicationModeV1::ReadFinalized {
            return Err(io::Error::other("actual finalized C history required"));
        }
        let completion = observed.history_data(&self.profile)?;
        let fixed = self
            .completed
            .as_ref()
            .ok_or_else(|| io::Error::other("original completed deployment missing"))?;
        let initial = &observed.initial;
        let (acceptance_digest, retained) = CompletedLearningRecord::read(
            RootAuthorityDirectory::open(&config.state_dir).map_err(io::Error::other)?,
            &config.state_dir,
            &self.deployment.target,
            initial,
            end,
            |fact| {
                if *fact != observed.checked.fact {
                    return Err(io::Error::other(
                        "completed C acceptance changed before retention",
                    ));
                }
                let acceptance = OriginalControlRecord::open(
                    &config.state_dir,
                    &completed_learning_acceptance_owner(initial),
                )?;
                let checkpoint = super::completed_checkpoint::with_original_checkpoint(
                    &config.state_dir,
                    |_, digest| {
                        if digest.to_string() != fact.checkpoint {
                            return Err(io::Error::other("completed C checkpoint changed"));
                        }
                        OriginalControlRecord::open(
                            &config.state_dir.join("learning-checkpoint"),
                            "root-learning-checkpoint-v1",
                        )
                    },
                )?;
                let files = CompletedFiles::retain_original(
                    fixed.data.files.clone(),
                    initial.request.envelope.objective_digest,
                )?;
                let retained = RootFinalizedColdHistoryV1 {
                    runtime: self,
                    completion,
                    operation: initial.request.operation_id.clone(),
                    acceptance,
                    checkpoint,
                    files,
                    cuts: fact.journals.clone(),
                    end,
                };
                retained.require_physical()?;
                Ok(retained)
            },
        )?;
        if acceptance_digest != observed.acceptance {
            return Err(io::Error::other(
                "completed C acceptance changed after retention",
            ));
        }
        retained.require_physical()?;
        Ok(retained)
    }
}

impl RootFinalizedColdHistoryV1<'_> {
    pub(crate) fn original_operation(&self) -> &codex_hepta_types::StableId {
        &self.operation
    }

    pub(crate) fn completion(&self) -> &OriginalQ24CompletedHistoryDataV1 {
        &self.completion
    }

    pub(crate) fn publication_deployment(&self) -> io::Result<&Path> {
        self.require_physical()?;
        let fixed = self
            .runtime
            .completed
            .as_ref()
            .ok_or_else(|| io::Error::other("original completed deployment missing"))?;
        Ok(&fixed.data.publication)
    }

    pub(crate) fn require_physical(&self) -> io::Result<()> {
        original_root()?;
        require_end(self.end)?;
        if self.runtime.phase.load(Ordering::Acquire) != SERVING {
            return Err(io::Error::other("original cold Root ended"));
        }
        self.runtime.metadata.require_metadata_unchanged()?;
        super::completed_deployment::CompletedLearningRuntime::require_original(
            self.runtime
                .completed
                .as_ref()
                .ok_or_else(|| io::Error::other("original completed deployment missing"))?,
        )?;
        self.acceptance.require_unchanged()?;
        self.checkpoint.require_unchanged()?;
        CompletedFiles::with_original_records(&self.files, self.end, |journals| {
            let actual: Vec<String> = journals
                .iter()
                .map(|value| value.cut.data_digest().map(|digest| digest.to_string()))
                .collect::<io::Result<_>>()?;
            if actual.as_slice() != self.cuts {
                return Err(io::Error::other(
                    "original seven C history journals changed",
                ));
            }
            self.acceptance.require_unchanged()?;
            self.checkpoint.require_unchanged()?;
            self.runtime.metadata.require_metadata_unchanged()?;
            super::completed_deployment::CompletedLearningRuntime::require_original(
                self.runtime
                    .completed
                    .as_ref()
                    .ok_or_else(|| io::Error::other("original completed deployment missing"))?,
            )?;
            require_end(self.end)
        })
    }
}
