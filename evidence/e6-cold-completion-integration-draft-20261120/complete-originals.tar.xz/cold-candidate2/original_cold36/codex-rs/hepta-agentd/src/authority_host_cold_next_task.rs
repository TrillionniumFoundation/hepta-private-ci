//! One cold next-task slot assembled by the new Root from actual retained C,
//! original D files, current selection, current controller and the existing
//! consumer. No wire DTO constructs this slot or a generation owner.

use super::*;
use crate::authority_host_runtime::RootColdNextTaskAuthorizationFilesV1;
use crate::authority_host_runtime::RootColdNextTaskFilesV1;
use crate::authority_host_runtime::RootFinalizedColdHistoryV1;
use crate::authority_host_runtime::RootOriginalSuccessorFilesV1;
use crate::cold_next_task_data::ColdNextTaskBindingDataV1;
use crate::cold_next_task_protocol::ColdNextTaskCommandV1;
use crate::cold_next_task_protocol::ColdNextTaskProfileV1;
use crate::cold_next_task_protocol::ColdNextTaskRequestV1;
use crate::cold_next_task_protocol::ColdNextTaskResponseV1;
use crate::cold_next_task_protocol::PURPOSE as COLD_PURPOSE;

use super::cold_context::OriginalColdNextTaskContextV1;

#[path = "authority_host_cold_next_task_enrollment.rs"]
mod enrollment;
#[path = "authority_host_cold_next_task_store.rs"]
mod operation;
pub(super) use operation::RegisteredColdNextTaskOperationV1;
pub(super) use operation::RootColdNextTaskAttemptV1;
#[cfg(test)]
pub(crate) use operation::qualify_original_cold_operation_store;

pub(crate) struct RegisteredColdNextTaskV1<'a> {
    profile: ColdNextTaskProfileV1,
    history: RootFinalizedColdHistoryV1<'a>,
    predecessor: RootFinalizedColdCReadV1,
    original_head: CurrentHead,
    current: NeuronGenerationCurrentOwnerV1,
    previous: CellGenerationJournalObserverV1,
    target: CellGenerationJournalObserverV1,
    artifacts: LearningArtifactReadViewV1,
    selected: Mutex<AgentdSelectedGenerationV1>,
    consumer: RootFinalUseObserverV1,
    source: Arc<RootOriginalSuccessorFilesV1>,
    authorization: Arc<RootColdNextTaskAuthorizationFilesV1>,
    operation: RegisteredColdNextTaskOperationV1,
    files: Arc<RootColdNextTaskFilesV1>,
    artifact_pin: super::super::generation_initial::ArtifactPin,
}

impl RegisteredColdNextTaskV1<'_> {
    pub(super) fn profile(&self) -> &ColdNextTaskProfileV1 {
        &self.profile
    }

    pub(super) fn require_original_attempt(
        &self,
        context: &OriginalColdNextTaskContextV1<'_>,
        attempt: &RootColdNextTaskAttemptV1<'_>,
        request: &ColdNextTaskRequestV1,
    ) -> io::Result<()> {
        attempt.require_original(context, &self.operation, request)?;
        self.require_physical(context)?;
        Ok(())
    }

    pub(super) fn require_physical(
        &self,
        context: &OriginalColdNextTaskContextV1<'_>,
    ) -> io::Result<(CurrentHead, RootCompletedSuccessorDataV1)> {
        let now = context.require_current()?;
        let (_, config) = context.original_root_inputs();
        self.files
            .require_recipient(context.identity(), config.peer_uid, config.peer_gid)?;
        self.profile.require_data()?;
        if !Arc::ptr_eq(&self.source, &self.files.source)
            || !Arc::ptr_eq(&self.authorization, &self.files.authorization)
            || self.profile.intent.operation_id == self.history.original_operation().as_str()
            || self.profile.artifacts
                != Digest32::of_parts(&[
                    b"hepta.root.cold-next-task.original-artifacts.v1\0",
                    &serde_json::to_vec(&self.artifact_pin).map_err(io::Error::other)?,
                ])
                .to_string()
        {
            return Err(io::Error::other(
                "actual cold fixed input and artifact owner changed",
            ));
        }
        if self.history.completion() != &self.profile.original_c
            || self.profile.identity
                != crate::neuron_generation_process_identity_digest_v1(context.identity())
                    .map_err(io::Error::other)?
                    .to_string()
            || self.profile.writer != context.writer_proof()?
            || now >= self.profile.valid_until_ms
            || self.previous.files_binding().to_string() != self.profile.previous_files
            || self.target.files_binding().to_string() != self.profile.target_files
            || self.authorization.controller_digest().to_string() != self.profile.controller
            || self.authorization.authorization_digest().to_string() != self.profile.authorization
            || self.authorization.authorization().message_id != self.profile.authorization_id
            || Digest32::from_array(self.consumer.issuer_trust_digest()).to_string()
                != self.profile.consumer_trust
        {
            return Err(io::Error::other("actual cold Root profile changed"));
        }
        self.history.require_physical()?;
        let predecessor = self.predecessor.read_original(&self.history)?;
        let (original_source, _) = self.profile.predecessor_data(&predecessor)?;
        let old = self.previous.observe().map_err(io::Error::other)?;
        if !old.is_drained()
            || old.owner_binding() != &self.profile.intent.previous
            || old.observation().owner_checkpoint().into_array()
                != self.profile.intent.previous_checkpoint
            || old.observation().digest().map_err(io::Error::other)?
                != self.profile.intent.previous_observation
        {
            return Err(io::Error::other("physical finalized C generation changed"));
        }
        let mut selected = self
            .selected
            .try_lock()
            .map_err(|_| io::Error::other("cold current selection busy"))?;
        selected
            .revalidate_original_artifacts(&self.artifacts, now)
            .map_err(io::Error::other)?;
        if selected.manifest() != &self.profile.manifest
            || selected.observation().digest().into_array() != self.profile.intent.selection
        {
            return Err(io::Error::other("cold task current full selection changed"));
        }
        drop(selected);
        let input = self
            .source
            .observe_cold_next_task_input(context.identity(), &self.profile.intent.target)?;
        if input.configuration.to_string() != self.profile.configuration
            || input.source.scope.run_id.as_str() != self.profile.intent.target.scope().run_id
            || input.source.observation == original_source.input().observation
            || input.objective.message_id != self.profile.objective_id
        {
            return Err(io::Error::other(
                "cold D must retain its new complete original input",
            ));
        }
        let binding = derive_original_binding(
            context,
            &self.profile.original_c,
            &self.profile.intent,
            &self.profile.manifest,
            input.configuration,
            &input.objective,
            self.profile.consumer,
            Digest32::from_array(self.consumer.issuer_trust_digest()),
        )?;
        if binding.digest().map_err(io::Error::other)?.to_string()
            != self.profile.authorization_binding
            || binding.objective.to_string() != self.profile.objective
        {
            return Err(io::Error::other("cold authorization payload changed"));
        }
        self.authorization.require_current(
            context.identity(),
            &binding,
            &input.objective,
            now,
            context.authority_epoch(),
        )?;
        let head = self
            .current
            .original_broker_head()
            .map_err(io::Error::other)?;
        self.profile.require_head_data(&head)?;
        let original = self
            .original_head
            .published
            .as_ref()
            .ok_or_else(|| io::Error::other("original C publication missing"))?;
        if self
            .consumer
            .verify_original_retained_use(
                &original.signed,
                &original.intent.binding().map_err(io::Error::other)?,
                &original.witness,
            )
            .map_err(io::Error::other)?
            != *context.revocations()
        {
            return Err(io::Error::other(
                "current consumer denies retained original C",
            ));
        }
        if head.current == self.profile.intent.target {
            let published = head
                .published
                .as_ref()
                .ok_or_else(|| io::Error::other("cold D publication missing"))?;
            if self
                .consumer
                .verify_original_retained_use(
                    &published.signed,
                    &self.profile.intent.binding().map_err(io::Error::other)?,
                    &published.witness,
                )
                .map_err(io::Error::other)?
                != *context.revocations()
            {
                return Err(io::Error::other(
                    "current consumer denies original D FinalUse",
                ));
            }
            if self
                .target
                .observe()
                .map_err(io::Error::other)?
                .owner_binding()
                != &self.profile.intent.target
            {
                return Err(io::Error::other("physical D generation differs"));
            }
        } else {
            self.target
                .require_original_unwritten_or_genesis()
                .map_err(io::Error::other)?;
            self.source
                .require_registered_baseline(context.identity(), &self.profile.intent.target)?;
        }
        self.history.require_physical()?;
        self.authorization.require_original_files()?;
        self.files
            .require_recipient(context.identity(), config.peer_uid, config.peer_gid)?;
        context.require_current()?;
        Ok((head, predecessor))
    }

    pub(super) fn execute(
        &self,
        context: &OriginalColdNextTaskContextV1<'_>,
        request: &ColdNextTaskRequestV1,
    ) -> io::Result<ColdNextTaskResponseV1> {
        let check = || self.require_physical(context).map(|_| ());
        let response = self.operation.with_operation(
            request,
            context,
            &check,
            |attempt: &RootColdNextTaskAttemptV1<'_>| {
                let (before, predecessor) = self.require_physical(context)?;
                let mut response = ColdNextTaskResponseV1 {
                    schema: 1,
                    purpose: COLD_PURPOSE.into(),
                    request_id: request.request_id,
                    request: request.digest()?,
                    profile: self.profile.clone(),
                    head: before.clone(),
                    predecessor: None,
                    grant: None,
                };
                match &request.command {
                    ColdNextTaskCommandV1::Observe => {}
                    ColdNextTaskCommandV1::ReadPredecessor => {
                        response.predecessor = Some(predecessor);
                    }
                    ColdNextTaskCommandV1::Prepare { expected, .. } => {
                        if before.current != self.profile.intent.previous
                            || before.prepared.is_some()
                            || *expected != head_digest(&before)?
                        {
                            return Err(io::Error::other(
                                "exact original unprepared C CAS required",
                            ));
                        }
                        context.require_current()?;
                        self.current
                            .original_broker_prepare(&self.profile.intent)
                            .map_err(io::Error::other)?;
                        // The ordinary coordinator writes D genesis only after
                        // this durable preparation. Issuance still requires it.
                        response.head = self.require_physical(context)?.0;
                    }
                    ColdNextTaskCommandV1::IssueFinalUse { .. } => {
                        return context.issue_cold_next_task_grant(self, attempt, request);
                    }
                    ColdNextTaskCommandV1::Publish {
                        expected,
                        signed,
                        witness,
                        ..
                    } => {
                        attempt.require_issued(signed)?;
                        if self.require_grant_cut(context)? != before
                            || *expected != head_digest(&before)?
                        {
                            return Err(io::Error::other("exact original prepared C CAS required"));
                        }
                        if self
                            .consumer
                            .verify_original_retained_use(
                                signed,
                                &self.profile.intent.binding().map_err(io::Error::other)?,
                                witness,
                            )
                            .map_err(io::Error::other)?
                            != *context.revocations()
                        {
                            return Err(io::Error::other(
                                "actual original D consumed nonce differs",
                            ));
                        }
                        // These checks happen after real consumer verification and
                        // immediately before the one exact C-to-D CURRENT change.
                        if self.require_grant_cut(context)? != before {
                            return Err(io::Error::other(
                                "original C changed before cold publication",
                            ));
                        }
                        self.current
                            .original_broker_publish(&self.profile.intent, signed, witness)
                            .map_err(io::Error::other)?;
                        response.head = self.require_physical(context)?.0;
                    }
                }
                check()?;
                response.require_data(request)?;
                Ok(response)
            },
        );
        // A failed CAS/issuer/ack still checks the real physical authority.
        check()?;
        context.require_current()?;
        response
    }

    pub(super) fn require_grant_cut(
        &self,
        context: &OriginalColdNextTaskContextV1<'_>,
    ) -> io::Result<CurrentHead> {
        let (head, _) = self.require_physical(context)?;
        let target = self.target.observe().map_err(io::Error::other)?;
        if head.current != self.profile.intent.previous
            || head.prepared.as_ref() != Some(&self.profile.intent)
            || !target.is_genesis()
            || target.owner_binding() != &self.profile.intent.target
            || target.observation().owner_checkpoint().into_array()
                != self.profile.intent.genesis_checkpoint
        {
            return Err(io::Error::other("exact cold D prepared genesis required"));
        }
        context.require_current()?;
        Ok(head)
    }
}

fn derive_original_binding(
    context: &OriginalColdNextTaskContextV1<'_>,
    original_c: &codex_hepta_agent_protocol::OriginalQ24CompletedHistoryDataV1,
    intent: &UpdateIntent,
    manifest: &codex_hepta_neuron::CellBackendManifestV2,
    configuration: Digest32,
    objective: &crate::AuthBusObjectiveIngress,
    consumer: RootPublicationFinalUseConsumerV1,
    consumer_trust: Digest32,
) -> io::Result<ColdNextTaskBindingDataV1> {
    let claims =
        crate::authbus_objective_claims(context.identity(), objective).map_err(io::Error::other)?;
    let signature = crate::authbus_trust::hex_bytes::<64>(&objective.signature_hex)
        .map_err(io::Error::other)?;
    let binding = ColdNextTaskBindingDataV1 {
        agent: context.identity().agent_id.to_string(),
        principal: Digest32::from_array(intent.target.scope().principal_digest),
        authority_epoch: context.authority_epoch(),
        recipient: crate::neuron_generation_process_identity_digest_v1(context.identity())
            .map_err(io::Error::other)?,
        writer: context.writer_proof()?.parse().map_err(io::Error::other)?,
        predecessor_current: original_c.current_head.parse().map_err(io::Error::other)?,
        predecessor_record: original_c
            .successor_record
            .parse()
            .map_err(io::Error::other)?,
        predecessor_cut: original_c.successor_cut.parse().map_err(io::Error::other)?,
        input: configuration,
        task: Digest32::from_array(intent.target.task_digest()),
        target: Digest32::from_array(intent.target.digest().map_err(io::Error::other)?),
        intent: intent.digest().map_err(io::Error::other)?,
        manifest: Digest32::from_array(manifest.digest().map_err(io::Error::other)?),
        selection: Digest32::from_array(intent.selection),
        objective: Digest32::of_bytes(&claims.signing_bytes()),
        objective_message_id: claims.message_id.to_string(),
        objective_sequence: claims.sequence,
        objective_signature: Digest32::of_bytes(&signature),
        objective_expiry_ms: claims.expires_at_ms,
        consumer,
        consumer_trust,
    };
    binding.digest().map_err(io::Error::other)?;
    Ok(binding)
}
