//! Whole original A/B/C -> actual retirement -> new Root/daemon -> fresh D.
//! The parent retains all original waits, pidfds, bounds and owner journals.

use std::time::Duration;
use std::time::Instant;

use codex_hepta_types::Digest32;
use serde_json::json;

use super::b_evaluate::OriginalBusinessCase;
use super::cold_acceptance_data::OriginalColdAcceptanceData;
use super::cold_next_completed_data::OriginalCompletedDData;
use super::cold_next_controls::OriginalDControlEvidence;
use super::cold_next_launch::RunningOrdinaryColdD;
use super::cold_next_plan::OriginalColdDPlan;
use super::cold_phase::OriginalColdPhase;
use super::cold_recipient_data::OriginalColdRecipientData;
use super::cold_successor_data::OriginalColdSuccessorData;
use super::post_a_retained::RetainedOrdinaryQ24Fixture;
use crate::ObjectiveRunAdmission;
use crate::ObjectiveStartOutcome;
use crate::client::ObjectiveStartReplyV1;

#[test]
#[ignore = "actual UID0, exact product binaries, original 60s/300s retirement and <=120s fresh D; no retries"]
fn ordinary_main_cold_executes_new_d_after_original_adopted_c() -> anyhow::Result<()> {
    run_whole_original_cold_d(OriginalBusinessCase::Adopt)
}

#[test]
#[ignore = "actual UID0, exact product binaries, original 60s/300s retirement and <=120s fresh D; no retries"]
fn ordinary_main_cold_executes_new_d_after_original_evaluated_no_update_c() -> anyhow::Result<()> {
    run_whole_original_cold_d(OriginalBusinessCase::EvaluatedNoUpdate)
}

fn run_whole_original_cold_d(case: OriginalBusinessCase) -> anyhow::Result<()> {
    // SAFETY: these calls only inspect the actual test process credentials.
    anyhow::ensure!(
        unsafe { (libc::getuid(), libc::geteuid()) } == (0, 0),
        "whole fresh D qualification requires actual UID0"
    );
    let end = Instant::now()
        .checked_add(Duration::from_secs(480))
        .ok_or_else(|| anyhow::anyhow!("whole cold D deadline overflow"))?;
    let original = super::post_a_process::run_original_business_case(case)?;
    let report = original
        .plan
        .resources
        .original
        .plan
        .protected
        .path()
        .join("ordinary-whole-cold-d-result.json");
    let result = run_original_cold_d(&original, end);
    let archived = original.archive_actual_phase();
    let written = super::root::write_json(
        &report,
        &json!({
            "schema":1,
            "business_case":format!("{case:?}"),
            "source_commit":std::env::var("HEPTA_ORDINARY_SOURCE_COMMIT")?,
            "source_tree":std::env::var("HEPTA_ORDINARY_SOURCE_TREE")?,
            "fresh_d_completed":result.is_ok() && archived.is_ok(),
            "human_independent_controller_authentications":0,
            "cold_d_error":result.as_ref().err().map(|error| format!("{error:#}")),
            "archive_error":archived.as_ref().err().map(|error| format!("{error:#}")),
            "actual":result.as_ref().ok(),
        }),
    );
    eprintln!("ORDINARY_Q24_WHOLE_COLD_D_RESULT={}", report.display());
    result?;
    archived?;
    written?;
    anyhow::ensure!(Instant::now() < end, "whole cold D final deadline");
    Ok(())
}

fn run_original_cold_d(
    original: &RetainedOrdinaryQ24Fixture,
    end: Instant,
) -> anyhow::Result<serde_json::Value> {
    let accepted = OriginalColdAcceptanceData::observe(original)?;
    let accepted_before = accepted.require_unchanged()?;
    let successor = OriginalColdSuccessorData::observe_registered(original)?;
    let phase = OriginalColdPhase::observe_original_completion(original, end)?;
    let (cold, evidence) = phase.wait_for_actual_expiry()?;
    evidence.require_unchanged(original)?;
    accepted.require_unchanged()?;
    let recipient = OriginalColdRecipientData::observe(&cold)?;
    let runtime = tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .build()?;
    let plan = OriginalColdDPlan::prepare(cold, &successor, &runtime)?;
    let controls = OriginalDControlEvidence::observe(&plan, &successor)?;
    let fixed_old_paths = original.business_files();
    let work = (|| {
        let running = RunningOrdinaryColdD::start(plan)?;
        let run_end = running.plan.cold.administration.end;
        let observed = runtime.block_on(async {
            tokio::time::timeout_at(tokio::time::Instant::from_std(run_end), async {
                running.promote_when_initialized().await?;
                running.require_live()?;
                controls.require_immutable(original)?;
                recipient.require_unchanged()?;
                let finalized = successor
                    .observe_finalized_for_next_task(original, &running.plan.expected)?
                    .ok_or_else(|| {
                        anyhow::anyhow!("actual new Root must finalize C before accepting fresh D")
                    })?;
                anyhow::ensure!(
                    accepted.require_unchanged()? > accepted_before,
                    "new Root did not perform actual cold C acceptance verification"
                );
                let client = running.client()?;
                let request = &running.plan.authorization.signed_objective;
                // Exactly one real ordinary submission. Lost ACK is retained
                // as failure; it is never resubmitted or converted to success.
                let reply = client
                    .objective_start_once_until(
                        request.clone(),
                        tokio::time::Instant::from_std(run_end),
                    )
                    .await?;
                let receipt = require_d_acknowledgement(
                    reply,
                    request,
                    running.plan.inputs.expected_source().objective_digest,
                    &evidence.directory,
                )?;
                running.require_live()?;
                controls.require_immutable(original)?;
                recipient.require_unchanged()?;
                let again = successor
                    .observe_finalized_for_next_task(original, &running.plan.expected)?
                    .ok_or_else(|| anyhow::anyhow!("actual finalized C disappeared after D"))?;
                anyhow::ensure!(
                    (&again.record_digest, &again.cut)
                        == (&finalized.record_digest, &finalized.cut)
                        && again.refusal_attempt >= finalized.refusal_attempt,
                    "D changed the actual finalized predecessor C"
                );
                Ok::<_, anyhow::Error>((receipt, again))
            })
            .await
            .map_err(|error| anyhow::anyhow!("actual fresh D phase deadline: {error}"))?
        })?;
        let (plan, daemon, root) = running.stop_after_original_d()?;
        for (name, process) in [("cold-d-daemon", &daemon), ("cold-d-root", &root)] {
            process.require_dead()?;
            let directory = evidence.directory.join(name);
            std::fs::create_dir(&directory)?;
            super::super::owned_mode(&directory, 0, 0, 0o700)?;
            process.archive_original_logs(&directory)?;
        }
        let physical = OriginalCompletedDData::observe_after_original_exit(&plan, &daemon, &root)?;
        let run_start = controls
            .run_start
            .require_single_d_append(&plan, &observed.0)?;
        let consumed = controls.require_actual_d_consumption(&plan, &physical.current)?;
        let finalized = successor
            .observe_finalized_for_next_task(original, &plan.expected)?
            .ok_or_else(|| anyhow::anyhow!("actual finalized C missing after new process exits"))?;
        anyhow::ensure!(
            (&finalized.record_digest, &finalized.cut)
                == (&observed.1.record_digest, &observed.1.cut)
                && original.business_files() == fixed_old_paths,
            "original C finalization or complete original file set changed"
        );
        controls.require_immutable(original)?;
        recipient.require_unchanged()?;
        accepted.require_unchanged()?;
        super::root::write_bytes(
            &evidence.directory.join("actual-d-cell-decision.bin"),
            &crate::circuit_cell_output::encode_receipt(&physical.cell.decision)?,
        )?;
        super::root::write_bytes(
            &evidence.directory.join("actual-d-source-result.bin"),
            physical.source.result_bytes(),
        )?;
        super::root::write_json(
            &evidence.directory.join("actual-d-root-current.json"),
            &physical.current,
        )?;
        super::root::write_json(
            &evidence.directory.join("actual-d-run-start.json"),
            &run_start,
        )?;
        super::root::write_json(
            &evidence.directory.join("actual-d-final-use.json"),
            &consumed,
        )?;
        let process = |child: &crate::ordinary_q24_process_child_tests::ExitedOriginalProcess| {
            let life = child.lifetime();
            json!({"pid":life.pid,"start_ticks":life.start_ticks,"boot_id":life.boot_id})
        };
        anyhow::ensure!(
            Instant::now() < plan.cold.administration.end && Instant::now() < end,
            "actual D complete postchecks exceeded original phase"
        );
        Ok::<_, anyhow::Error>(json!({
            "actual_original_c":finalized,
            "actual_d_acknowledgement":observed.0,
            "actual_d_run_start":run_start,
            "actual_d_final_use":consumed,
            "actual_d_current":physical.current,
            "actual_d_cell_revision":physical.cell.snapshot.revision,
            "actual_d_publication":physical.source.publication_digest().to_string(),
            "actual_d_checkpoint":physical.source.checkpoint_digest().to_string(),
            "actual_d_observation_digest":Digest32::of_bytes(
                &plan.inputs.expected_source().observation
            ).to_string(),
            "actual_d_configuration":plan.authorization.configuration.to_string(),
            "actual_d_authorization_payload":plan.authorization.payload.to_string(),
            "new_daemon":process(&daemon), "new_root":process(&root),
            "original_independent_source":process(&original.source),
        }))
    })();
    // These original DATA proofs also run on a failed/new-child Drop path.
    // Allowed mutations have their stricter success-path physical checks above.
    let immutable = controls.require_immutable(original);
    let acceptance = accepted.require_unchanged();
    let recipient_after = recipient.require_unchanged();
    super::root::write_json(
        &evidence.directory.join("cold-d-postchecks.json"),
        &json!({
            "work_error":work.as_ref().err().map(|error| format!("{error:#}")),
            "immutable_error":immutable.as_ref().err().map(|error| format!("{error:#}")),
            "acceptance_error":acceptance.as_ref().err().map(|error| format!("{error:#}")),
            "recipient_error":recipient_after.as_ref().err().map(|error| format!("{error:#}")),
        }),
    )?;
    let actual = work?;
    immutable?;
    acceptance?;
    recipient_after?;
    Ok(actual)
}

fn require_d_acknowledgement(
    reply: ObjectiveStartReplyV1,
    request: &crate::AuthBusObjectiveIngress,
    objective: Digest32,
    directory: &std::path::Path,
) -> anyhow::Result<ObjectiveRunAdmission> {
    match reply {
        ObjectiveStartReplyV1::Completed(ObjectiveStartOutcome::Admitted { receipt }) => {
            anyhow::ensure!(
                receipt.run_id == super::inputs::D_RUN
                    && receipt.run_id == request.body.run_id
                    && receipt.objective_digest == objective.to_string()
                    && receipt.disposition == "circuit_succeeded"
                    && !receipt.idempotent
                    && !receipt.publication_digest.parse::<Digest32>()?.is_zero()
                    && !receipt.chain_digest.parse::<Digest32>()?.is_zero(),
                "actual ordinary D acknowledgement differs"
            );
            super::root::write_json(&directory.join("actual-d-objective-ack.json"), &receipt)?;
            Ok(receipt)
        }
        ObjectiveStartReplyV1::Completed(ObjectiveStartOutcome::Conflict {
            run_id,
            conflict_digest,
        }) => {
            anyhow::bail!("actual D conflict: run_id={run_id}, conflict_digest={conflict_digest}")
        }
        ObjectiveStartReplyV1::AcknowledgementLost(error) => {
            super::root::write_json(
                &directory.join("actual-d-objective-ack-lost.json"),
                &json!({"error":error.to_string(),"resubmitted":false}),
            )?;
            anyhow::bail!("actual D acknowledgement lost, without resubmission: {error}")
        }
    }
}
