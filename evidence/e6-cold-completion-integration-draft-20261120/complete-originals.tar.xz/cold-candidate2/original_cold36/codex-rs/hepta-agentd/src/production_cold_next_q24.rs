//! Concrete cold D assembly in the actual new recipient. Read-only C history
//! remains its original lane; every new task effect uses the separate Root
//! purpose and the existing Artifact, Control and FinalUse transaction.

use super::*;
use crate::AgentdGenerationUpdateRequestV1;
use crate::CircuitQ24TaskProfileV1;
use crate::NeuronGenerationCurrentOwnerV1;
use crate::OriginalCellQ24FeatureTargetV1;
use crate::PreparedAgentdGenerationUpdateV1;

impl AgentdProductionLaunch {
    pub(super) async fn assemble_original_cold_next_task(
        mut self,
        config: AgentdConfig,
        mut data: deployment::Deployment,
    ) -> Result<(Self, AgentdConfig), AgentdError> {
        let history_mode = data.completed_history.ok_or_else(|| {
            refused("cold D requires an explicit original completed-history phase")
        })?;
        if self.post_a_handoffs.is_some() {
            return Err(refused(
                "cold D cannot carry original learning owner handoffs",
            ));
        }
        let model_data: super::super::initial_q24::OriginalQ24ModelData = data
            .cold_next_task
            .take()
            .ok_or_else(|| refused("original cold D model files are missing"))?;
        let identity = config.identity().clone();
        self.require_original_post_a_context(&identity)?;
        let historical = self.take_original_historical_read()?;
        // CaptureRetired, when explicitly selected, still performs the original
        // one-shot capture followed by an independent ReadFinalized comparison.
        // Only that completed holder reaches the separate cold D handoff.
        let history = RootHistoricalTaskReadClientV1::read_original_completed_history(
            &historical,
            &self.root.session,
            &identity,
            history_mode,
        )?;
        let handoff: crate::RootColdNextTaskHandoffV1 = self
            .cold_next_task
            .take()
            .ok_or_else(|| refused("original cold D purpose handoff is missing"))?;
        let connection = self.take_generation_publication_connection()?;
        let client: Arc<crate::root_cold_next_task_client::RootColdNextTaskClientV1> = handoff
            .connect_original(
                connection,
                &self.root,
                history,
                post_a_remaining(self.session_end)?.min(Duration::from_millis(500)),
                self.session_end,
            )
            .await?;
        self.require_original_post_a_context(&identity)?;
        client.require_original_session(&self.root.session)?;
        let mut files = OriginalFiles::new()?;
        let (model, bundle) = model_data.open_original(&mut files)?;
        crate::cell_composed_q24::validate_manifest(&bundle, &client.profile().manifest)
            .map_err(refused)?;
        let artifacts = artifacts::OriginalArtifactPlan::open_original(
            data.continuation.artifacts,
            &mut files,
            self.session_end,
        )?;
        let task =
            c_task::CTaskData::open_original(data.continuation.task, &mut files, self.session_end)?;
        let final_use = Arc::new(match client.profile().consumer {
            crate::RootPublicationFinalUseConsumerV1::Device => self.root.device.clone(),
            crate::RootPublicationFinalUseConsumerV1::Notes => self.root.notes.clone(),
        });
        let cancelled = tokio_util::sync::CancellationToken::new();
        let (authorities, selected, artifact_custody) = artifacts
            .open_original_cold_selection(
                &client,
                final_use,
                self.root.session.clock(),
                &mut files,
                &cancelled,
            )
            .await?;
        let task = task
            .open_original_cold_task(
                &client,
                &identity,
                Arc::clone(&model),
                &mut files,
                &cancelled,
            )
            .await?;
        task.execution.validate_original_successor_execution(
            &identity,
            &task.target,
            data.queue_capacity,
        )?;
        crate::circuit_feature_initial_root::require_feature(
            &task.target.target.config,
            &bundle,
            &model,
            &task.target.definition,
            &task.target.source,
        )?;
        artifact_custody.require_original()?;
        task.custody.require_original()?;
        client.require_original_session(&self.root.session)?;
        self.require_original_post_a_context(&identity)?;
        let current = Arc::new(
            NeuronGenerationCurrentOwnerV1::from_original_cold_next_task(Arc::clone(&client))?,
        );
        let end = self.session_end;
        let original = Arc::clone(&client);
        let (published, execution, task_custody, artifact_custody) =
            tokio::task::spawn_blocking(move || {
                post_a_remaining(end)?;
                let c_task::OriginalNewCTask {
                    predecessor,
                    target,
                    execution,
                    custody,
                    ingress,
                    ..
                } = task;
                let OriginalCellQ24FeatureTargetV1 {
                    target,
                    definition,
                    source,
                    model: _,
                    previous,
                } = target;
                super::super::initial_q24::clock::require_source_deadline(&source)?;
                let prepared: PreparedAgentdGenerationUpdateV1<_, _> =
                    crate::prepare_agentd_generation_cold_same_model_task_v1(
                        current,
                        authorities,
                        predecessor,
                        selected,
                        target,
                        AgentdGenerationUpdateRequestV1 {
                            operation_id: original.profile().intent.operation_id.clone(),
                        },
                    )?;
                if prepared.intent_digest() != original.profile().intent.digest()? {
                    return Err(refused("cold D coordinator prepared another exact intent"));
                }
                custody.require_original()?;
                artifact_custody.require_original()?;
                post_a_remaining(end)?;
                // The grant constructor remains inside the actual Root lane.
                // Failure after its durable attempt is never retried here.
                let signed = prepared.issue_original_root_final_use()?;
                let ready = prepared.publish(&signed)?;
                let published = ready.into_circuit_feature_task(definition, source, previous)?;
                custody.require_original()?;
                artifact_custody.require_original()?;
                post_a_remaining(end)?;
                // Execution still enters through ordinary signed ObjectiveStart.
                // Reading its fixed original DATA does not manufacture a RunStart.
                drop(ingress);
                Ok::<_, AgentdError>((published, execution, custody, artifact_custody))
            })
            .await
            .map_err(|_| refused("original cold D publication acknowledgement lost"))??;
        client.require_original_session(&self.root.session)?;
        self.require_original_post_a_context(&identity)?;
        let profile = CircuitQ24TaskProfileV1 {
            files: execution.files,
            source_mode: execution.source_mode,
            published_task: published,
            fence: execution.fence,
            circuit: execution.circuit,
            routes: execution.routes,
            bundle,
            model,
            worker_generation: execution.worker_generation,
            maximum_cell_records: execution.maximum_cell_records,
            queue_capacity: data.queue_capacity,
            clock: execution.clock,
        };
        let runtime = config.with_q24_circuit_task_profile(profile)?;
        task_custody.require_original()?;
        artifact_custody.require_original()?;
        client.require_original_session(&self.root.session)?;
        self.require_original_post_a_context(&identity)?;
        // Root retains the immutable physical data for every live CURRENT check.
        // Ordinary Config owns the only new Source/Cell execution capabilities.
        drop((runtime.source, runtime.cell));
        Ok((self, runtime.config))
    }
}
