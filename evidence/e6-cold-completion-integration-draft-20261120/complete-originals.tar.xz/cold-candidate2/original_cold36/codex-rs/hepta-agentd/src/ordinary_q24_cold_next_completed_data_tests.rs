//! Read the actual new D Source, Cell, Generation and Root CURRENT after
//! both new processes exit. No owner, grant or successful result is fabricated.

use std::fs::File;
use std::fs::OpenOptions;
use std::os::unix::fs::OpenOptionsExt;
use std::path::PathBuf;

use codex_hepta_contracts::AuthorityFrontierStore;
use codex_hepta_contracts::HostAuthorityFrontierStore;
use codex_hepta_contracts::RootAuthorityDirectory;
use codex_hepta_neuron::CellGenerationJournalObservedV1;
use codex_hepta_neuron::CellGenerationJournalObserverV1;
use codex_hepta_neuron::CellGenerationOwnerBindingV1;
use codex_hepta_neuron::CellJournalPartitionV1;
use codex_hepta_neuron::CellOriginalJournalFilesV1;
use codex_hepta_neuron::CellOriginalJournalObservationV1;
use codex_hepta_neuron::FileAnchorWitnessStore;
use codex_hepta_neuron::JournalScope;
use codex_hepta_neuron::SparseCheckpoint;
use codex_hepta_neuron::canonical_cell_step_request_digest_v1;
use codex_hepta_neuron::observe_original_guarded_cell_v1;
use codex_hepta_types::AuthorityPosture;
use codex_hepta_types::Digest32;
use codex_hepta_types::Generation;
use serde::Deserialize;

use super::cold_next_plan::OriginalColdDPlan;
use super::post_a_file::OriginalFileData;
use crate::CircuitTaskSourcePublicationV1;
use crate::HistoricalCircuitTaskSourceV1;
use crate::OriginalSingleQ24SourceConfigurationV1;
use crate::neuron_generation_current::types::CurrentHead;
use crate::neuron_generation_current::types::scope_digest;
use crate::ordinary_q24_cold_snapshot_tests::OriginalBusinessSnapshot;
use crate::ordinary_q24_process_child_tests::ExitedOriginalProcess;

#[derive(Debug, Eq, PartialEq)]
pub(super) struct OriginalCompletedDData {
    pub(super) source: CircuitTaskSourcePublicationV1,
    pub(super) cell: CellOriginalJournalObservationV1,
    pub(super) generation: CellGenerationJournalObservedV1,
    pub(super) current: CurrentHead,
}

impl OriginalCompletedDData {
    pub(super) fn observe_after_original_exit(
        plan: &OriginalColdDPlan<'_>,
        daemon: &ExitedOriginalProcess,
        root: &ExitedOriginalProcess,
    ) -> anyhow::Result<Self> {
        daemon.require_dead()?;
        root.require_dead()?;
        plan.cold.original.daemon.require_dead()?;
        plan.cold.original.root.require_dead()?;
        plan.cold.original.source.require_dead()?;
        let d = &plan.inputs;
        let binding = CellGenerationOwnerBindingV1::new(
            &plan.target.generation,
            plan.target.journal_records,
        )?;
        let owner = format!("cell-generation/{}", scope_digest(binding.scope())?);
        let record = format!("frontier-v1-{}.json", Digest32::of_bytes(owner.as_bytes()));
        let mut paths = d.business_files();
        paths.extend([
            plan.artifacts.inputs.current_directory.join(&record),
            plan.artifacts
                .inputs
                .current_directory
                .join(format!("{record}.lock")),
        ]);
        let unchanged = OriginalBusinessSnapshot::capture(&paths)?;
        let result = (|| {
            let registration: crate::HostAuthorityRegistration =
                serde_json::from_slice(&super::observer::read_private(
                    &plan.cold.administration.successor.registration,
                    16_384,
                )?)?;
            anyhow::ensure!(
                registration.peer_pid == daemon.lifetime().pid
                    && registration.boot_id == daemon.lifetime().boot_id
                    && registration.process_start_ticks == daemon.lifetime().start_ticks
                    && daemon.lifetime() != root.lifetime()
                    && daemon.lifetime() != plan.cold.original.daemon.lifetime()
                    && root.lifetime() != plan.cold.original.root.lifetime(),
                "actual D exited processes differ from their registered new incarnation"
            );
            let identity = &plan.cold.administration.successor.identity;
            let bytes = d.source_configuration.read_original(65_536)?;
            let configuration =
                OriginalSingleQ24SourceConfigurationV1::from_original_deployment_bytes(
                    &bytes, identity,
                )?;
            let cell_files: CellFilesData = serde_json::from_value(
                serde_json::from_slice::<serde_json::Value>(&bytes)?["cell_files"].clone(),
            )?;
            let bundle = plan.cold.original.decision.bundle.digest()?;
            let previous = &plan.cold.original.completed;
            anyhow::ensure!(
                configuration.source == *d.expected_source()
                    && configuration.source_journal == d.source_journal.path
                    && configuration.source_witness == d.source_witness.path
                    && cell_files.journal == d.cell_journal.path
                    && cell_files.witness == d.cell_witness.path
                    && configuration.source.scope.run_id.as_str() == super::inputs::D_RUN
                    && configuration.source.scope.run_id != previous.source.input().scope.run_id
                    && configuration.source.observation != previous.source.input().observation
                    && configuration.definition.bundle_digest == bundle
                    && plan.target.generation.manifest == plan.cold.original.selected.manifest
                    && binding == plan.authorization.intent.target
                    && binding != previous.current.current
                    && crate::circuit_feature_task_digest_v1(
                        &configuration.definition,
                        &configuration.source,
                    )?
                    .into_array()
                        == binding.task_digest(),
                "actual D must use distinct fixed input/run and exactly C's full selected model"
            );
            let declared = d.root_successor_data();
            anyhow::ensure!(
                serde_json::to_value(cell_files.witness_scope)? == declared["cell_witness_scope"]
                    && serde_json::to_value(cell_files.witness_objective)?
                        == declared["cell_witness_objective"]
                    && cell_files.witness_generation == declared["cell_witness_generation"]
                    && cell_files.witness_records == declared["cell_witness_records"]
                    && cell_files.maximum_records == declared["maximum_cell_records"],
                "actual new D Cell witness context differs from the Root-fixed files"
            );
            let source_witness = FileAnchorWitnessStore::open(
                open_original(&d.source_witness)?,
                configuration.witness_scope,
                configuration.witness_generation,
                configuration.witness_records,
            )?;
            let mut source = HistoricalCircuitTaskSourceV1::open(
                open_original(&d.source_journal)?,
                source_witness,
                identity,
                &configuration.fence,
                &configuration.registry()?,
                vec![configuration.source.clone()],
            )?;
            let before = source.observe_run_publication(&configuration.source.scope.run_id)?;
            let publication = before.publication();
            anyhow::ensure!(
                publication.input()
                    == &configuration
                        .source
                        .input(publication.input().operation_id.clone(),)
                    && publication.bundle_digest() == bundle
                    && !publication.result_bytes().is_empty(),
                "actual D Source result differs from its complete new input"
            );
            let read_cell = || {
                observe_original_guarded_cell_v1(
                    CellOriginalJournalFilesV1 {
                        journal: open_original(&d.cell_journal)?,
                        witness: open_original(&d.cell_witness)?,
                        witness_scope: JournalScope {
                            scope_digest: Digest32::from_array(cell_files.witness_scope),
                            objective_digest: Digest32::from_array(cell_files.witness_objective),
                        },
                        witness_generation: Generation::new(cell_files.witness_generation)?,
                        witness_records: cell_files.witness_records,
                    },
                    CellJournalPartitionV1 {
                        scope: configuration.source.scope.clone(),
                        definition: configuration.definition.clone(),
                        source_frontier: configuration.source.source_frontier,
                        writer_epoch: binding.writer_epoch(),
                    },
                    cell_files.maximum_records,
                    &binding,
                    &publication.input().operation_id,
                    canonical_cell_step_request_digest_v1(
                        &configuration.definition,
                        publication.input(),
                    )?,
                )
                .map_err(anyhow::Error::from)
            };
            let cell = read_cell()?;
            publication.require_decision(&cell.decision)?;
            anyhow::ensure!(
                cell.snapshot.revision == 1
                    && cell.snapshot.scope == configuration.source.scope
                    && cell.snapshot.writer_epoch == binding.writer_epoch()
                    && cell
                        .snapshot
                        .checkpoint
                        .as_ref()
                        .map(SparseCheckpoint::digest)
                        == Some(cell.decision.checkpoint_after)
                    && cell.decision.checkpoint_after == publication.checkpoint_digest()
                    && cell.decision.bundle_digest == bundle
                    && cell.decision.authority == AuthorityPosture::DENY_ALL,
                "D requires its actual committed Cell revision and exact complete decision"
            );
            let generation_reader = CellGenerationJournalObserverV1::from_original_files(
                open_original(&d.generation_journal)?,
                open_original(&d.generation_witness)?,
                plan.target.clone(),
            )?;
            let generation = generation_reader.observe()?;
            let observed = generation.observation();
            anyhow::ensure!(
                generation.owner_binding() == &binding
                    && generation.is_drained()
                    && observed.manifest_digest()
                        == plan.cold.original.selected.manifest.digest()?
                    && observed.snapshot().revision == 0
                    && observed.snapshot().prefix.is_empty()
                    && !observed.snapshot().stopped
                    && observed.pending_request_digest().is_none()
                    && observed.pending_output().is_none(),
                "Feature D must drain its real new Generation owner without Generation inference"
            );
            let store = HostAuthorityFrontierStore::<CurrentHead>::open(
                RootAuthorityDirectory::open(&plan.artifacts.inputs.current_directory)?,
                owner.clone(),
            )?;
            let current = store.load(&owner)?;
            let published = current
                .published
                .as_ref()
                .ok_or_else(|| anyhow::anyhow!("actual new D CURRENT publication absent"))?;
            anyhow::ensure!(
                current.schema_version == 1
                    && current.current == binding
                    && current.prepared.is_none()
                    && current.initial.is_none()
                    && published.intent == plan.authorization.intent
                    && published.intent.previous == previous.current.current
                    && published.intent.previous_checkpoint
                        == previous
                            .generation
                            .observation()
                            .owner_checkpoint()
                            .into_array()
                    && published.intent.previous_observation
                        == previous.generation.observation().digest()?
                    && published.intent.selection == plan.artifacts.selection_digest.into_array()
                    && published.signed.grant.binding == published.intent.binding()?
                    && published.signed_grant_digest
                        == crate::neuron_generation_current::signed_grant_digest(
                            &published.signed,
                        )?
                        .into_array(),
                "actual Root CURRENT must complete exactly C-to-D with original FinalUse bytes"
            );
            let after = source.observe_run_publication(&configuration.source.scope.run_id)?;
            anyhow::ensure!(
                before.publication() == after.publication()
                    && before.journal_anchor() == after.journal_anchor()
                    && before.binding_digest() == after.binding_digest()
                    && read_cell()? == cell
                    && generation_reader.observe()? == generation
                    && store.load(&owner)? == current,
                "actual D physical observation changed"
            );
            Ok(Self {
                source: publication.clone(),
                cell,
                generation,
                current,
            })
        })();
        unchanged.require_unchanged(&paths)?;
        daemon.require_dead()?;
        root.require_dead()?;
        plan.cold.original.daemon.require_dead()?;
        plan.cold.original.root.require_dead()?;
        plan.cold.original.source.require_dead()?;
        result
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct CellFilesData {
    journal: PathBuf,
    witness: PathBuf,
    witness_scope: [u8; 32],
    witness_objective: [u8; 32],
    witness_generation: u64,
    witness_records: usize,
    maximum_records: usize,
}

fn open_original(declared: &OriginalFileData) -> anyhow::Result<File> {
    let file = OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_CLOEXEC | libc::O_NOFOLLOW)
        .open(&declared.path)?;
    declared.require_file(&file)?;
    anyhow::ensure!(
        file.metadata()?.len() != 0,
        "actual existing D data required"
    );
    Ok(file)
}
