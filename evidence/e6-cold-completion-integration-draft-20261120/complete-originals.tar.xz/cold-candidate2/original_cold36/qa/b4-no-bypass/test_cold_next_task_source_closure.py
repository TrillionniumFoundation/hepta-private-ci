"""Source-only mutations for the cold D authority boundary.

These checks invoke the unchanged repository verifier against copies. They do
not issue a grant, create a Cell owner, or qualify a complete cold process run.
"""
from __future__ import annotations

import importlib
from pathlib import Path
import sys
import tempfile
import tomllib
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
verifier = importlib.import_module("verify_hepta_callers")

CASES = [
    [
        "authority_host_cold_next_task_context.rs",
        "fn require_current(",
        "verify_pinned_process("
    ],
    [
        "authority_host_cold_next_task_context.rs",
        "fn require_current(",
        "self.service.issuer.revocations()? != self.revocations"
    ],
    [
        "authority_host_cold_next_task_context.rs",
        "fn require_current(",
        "validate_observation_lease(self.issuer_lease, &self.revocations, now)?"
    ],
    [
        "authority_host_cold_next_task_context.rs",
        "fn with_cold_next_task_context<T>(",
        "DeploymentFinalUseIssuer::with_live_issuer_and_writer("
    ],
    [
        "authority_host_cold_next_task_context.rs",
        "fn with_cold_next_task_context<T>(",
        "context.require_current()?"
    ],
    [
        "authority_host_cold_next_task_grant.rs",
        "fn into_original_parts(",
        ".require_original_attempt(self.context, self.attempt, self.request)?"
    ],
    [
        "authority_host_cold_next_task_grant.rs",
        "fn into_original_parts(",
        "!std::ptr::eq(issuer, self.context.service.issuer.as_ref())"
    ],
    [
        "authority_host_cold_next_task_grant.rs",
        "fn into_original_parts(",
        "self.attempt.require_attempted()?"
    ],
    [
        "authority_host_cold_next_task_grant.rs",
        "fn issue_cold_next_task_grant(",
        "slot.require_original_attempt(self, attempt, request)?"
    ],
    [
        "authority_host_cold_next_task_grant.rs",
        "fn issue_cold_next_task_grant(",
        "attempt.begin_final_use()?"
    ],
    [
        "authority_host_cold_next_task_grant.rs",
        "fn issue_cold_next_task_grant(",
        "slot.require_grant_cut(self)? != head"
    ],
    [
        "authority_host_cold_next_task_grant.rs",
        "fn issue_cold_next_task_grant(",
        "attempt.finish_final_use(&signed)?"
    ],
    [
        "authority_host_cold_next_task_grant.rs",
        "fn issue_cold_next_task_grant(",
        "attempt.require_issued(&signed)?"
    ],
    [
        "authority_host_cold_next_task_store.rs",
        "fn with_operation<T>(",
        "request.require_data(&self.profile)?"
    ],
    [
        "authority_host_cold_next_task_store.rs",
        "fn with_operation<T>(",
        "attempt.require_original(context, self, request)?"
    ],
    [
        "authority_host_cold_next_task_store.rs",
        "fn with_operation<T>(",
        "let mut after = attempt.load_armed()?"
    ],
    [
        "authority_host_cold_next_task_store.rs",
        "fn require_original(",
        "!std::ptr::eq(self.context, context)"
    ],
    [
        "authority_host_cold_next_task_store.rs",
        "fn require_original(",
        "!std::ptr::eq(self.original, operation)"
    ],
    [
        "authority_host_cold_next_task_store.rs",
        "fn require_original(",
        "!std::ptr::eq(self.request, request)"
    ],
    [
        "authority_host_cold_next_task_store.rs",
        "fn begin_final_use(",
        "before.grant != (GrantPhase::Available {})"
    ],
    [
        "authority_host_cold_next_task_store.rs",
        "fn finish_final_use(",
        "before.grant != (GrantPhase::Attempted {})"
    ],
    [
        "authority_host_cold_next_task.rs",
        "fn require_physical(",
        "self.history.require_physical()?"
    ],
    [
        "authority_host_cold_next_task.rs",
        "fn require_physical(",
        "self.authorization.require_current("
    ],
    [
        "authority_host_cold_next_task.rs",
        "fn execute(",
        "attempt.require_issued(signed)?"
    ],
    [
        "authority_host_cold_next_task.rs",
        "fn execute(",
        ".verify_original_retained_use("
    ],
    [
        "authority_host_cold_next_task.rs",
        "fn require_grant_cut(",
        "!target.is_genesis()"
    ],
    [
        "authority_host_cold_next_task_enrollment.rs",
        "fn from_original(",
        "head_digest(&original_head)? != history.completion().current_head"
    ],
    [
        "authority_host_cold_next_task_enrollment.rs",
        "fn from_original(",
        "input.source.observation == original_source.input().observation"
    ],
    [
        "authority_host_cold_completed_history.rs",
        "fn retain_finalized_cold_history(",
        "observed.mode != OriginalCompletedPublicationModeV1::ReadFinalized"
    ],
    [
        "authority_host_cold_completed_history.rs",
        "fn require_physical(",
        "actual.as_slice() != self.cuts"
    ],
    [
        "authority_host_cold_finalized_c.rs",
        "fn retain_original(",
        "!matches!(&record.phase, SuccessorPhase::Finalized { .. })"
    ],
    [
        "authority_host_cold_finalized_c.rs",
        "fn read_original(",
        "self.record.require_unchanged()?"
    ],
    [
        "authority_host_cold_authorization_files.rs",
        "fn require_current(",
        "objective.body.authority_epoch != authority_epoch"
    ],
    [
        "authority_host_cold_authorization_files.rs",
        "fn require_current(",
        "original.objective_signature != Digest32::of_bytes(&signature)"
    ],
    [
        "authority_host_cold_authorization_files.rs",
        "fn require_current(",
        ".verify_strict(&claims.signing_bytes(), &Signature::from_bytes(&signature))"
    ],
    [
        "authority_host_cold_next_task_files.rs",
        "fn take_original_inputs(",
        ".take()"
    ],
    [
        "authority_host_cold_next_task_files.rs",
        "fn require_original_artifact_lease(",
        "file.metadata()?.len() != length || digest != self.artifact_lease_digest"
    ],
    [
        "cold_next_task_data.rs",
        "fn require_current(",
        "policy.role != ColdNextTaskControllerRoleV1::ColdNextTask"
    ],
    [
        "cold_next_task_data.rs",
        "fn require_current(",
        "policy.allowed_scope != claims.scope_digest.to_string()"
    ],
    [
        "cold_next_task_data.rs",
        "fn require_current(",
        "now >= self.expires_at_ms.min(original.objective_expiry_ms)"
    ],
    [
        "cold_next_task_protocol.rs",
        "fn require_head_data(",
        "original.prepared = None"
    ],
    [
        "cold_next_task_protocol.rs",
        "fn require_head_data(",
        "reference.grant_id != published.signed.grant.grant_id"
    ],
    [
        "authority_host_cold_next_task_runtime.rs",
        "fn serve_optional(",
        "request.request_id != sequence"
    ],
    [
        "authority_host_cold_next_task_runtime.rs",
        "fn serve_optional(",
        "(1..=MAX_REQUESTS).contains(&sequence)"
    ],
    [
        "authority_host_cold_next_task_runtime.rs",
        "fn serve_optional(",
        "result.and(cold)"
    ],
    [
        "authority_host_cold_next_task_session.rs",
        "fn enable_original_cold_next_task_from_deployment(",
        "self.learning.is_some()"
    ],
    [
        "authority_host_cold_next_task_session.rs",
        "fn seal_original_cold_next_task(",
        ".compare_exchange(PREPARED, SEALED, Ordering::AcqRel, Ordering::Acquire)"
    ],
    [
        "root_cold_next_task_inputs.rs",
        "fn connect_original(",
        "bundle.root.pid != self.root_pid"
    ],
    [
        "root_cold_next_task_client.rs",
        "fn from_original_stream(",
        "raw.is_empty() || raw.len() > WIRE_BOUND"
    ],
    [
        "root_cold_next_task_client.rs",
        "fn issue_original_prepared_final_use(",
        "self.grant_attempted.swap(true, Ordering::AcqRel)"
    ],
    [
        "root_cold_next_task_client.rs",
        "fn exchange_response(",
        "self.fenced.load(Ordering::Acquire)"
    ],
    [
        "root_cold_next_task_client.rs",
        "fn authenticate_signed(",
        "signed.grant.authority_epoch != original.revocations.authority_epoch"
    ],
    [
        "root_cold_next_task_client.rs",
        "fn authenticate_historical_signed(",
        "keys.next().is_some()"
    ],
    [
        "root_cold_next_task_client.rs",
        "fn require_original_signature(",
        "key.verify_strict("
    ],
    [
        "production_cold_q24_artifacts.rs",
        "fn open_original_cold_selection(",
        "required_current_head: Some(inputs.retained_current.original_current()?)"
    ],
    [
        "production_cold_q24_task.rs",
        "fn open_original_cold_task(",
        "!matches!(self.mode, OpenMode::Create) || self.recovery.is_some()"
    ],
    [
        "root_cold_next_task_handoff.rs",
        "fn receive_root_cold_next_task_handoff(",
        "descriptors.len() != 2"
    ],
    [
        "deployment_publication.rs",
        "fn issue_original_cold_next_task_final_use(",
        "admitted.into_original_parts(self)?"
    ],
    [
        "production_cold_next_q24.rs",
        "fn assemble_original_cold_next_task(",
        "prepared.intent_digest() != original.profile().intent.digest()?"
    ],
    [
        "production_cold_next_q24.rs",
        "fn assemble_original_cold_next_task(",
        "prepared.issue_original_root_final_use()?"
    ]
]

MANIFEST = tomllib.loads((ROOT / "CALLERS.toml").read_text())


class ColdNextTaskSourceClosure(unittest.TestCase):
    def protect(self, case, comment):
        filename, function, marker = case
        relative = "codex-rs/hepta-agentd/src/" + filename
        rows = [
            row
            for row in MANIFEST["protected_file"]
            if row["path"] == relative
            and any(
                item["function"] == function
                and marker in item["sequence"]
                for item in row.get("required_function_order", [])
            )
        ]
        self.assertEqual(len(rows), 1, (relative, function, marker))
        original = (ROOT / relative).read_text()
        verifier._verify_protected_files(ROOT, {"protected_file": rows})
        code = verifier._strip_cfg_test_items(verifier._strip_rust_non_code(original))
        self.assertEqual(code.count(function), 1)
        start = code.index(function)
        end = verifier._rust_item_end(code, start)
        self.assertIsNotNone(end)
        self.assertEqual(code[end], "}")
        body = code[start : end + 1]
        cursor = 0
        spans = []
        while True:
            found = body.find(marker, cursor)
            if found < 0:
                break
            spans.append((start + found, start + found + len(marker)))
            cursor = found + len(marker)
        self.assertTrue(spans, (function, marker))
        mutated = original
        # Remove every occurrence in this actual function. A repeated check
        # elsewhere or the same bytes in a comment must not replace this guard.
        for left, right in reversed(spans):
            replacement = "/*" + original[left:right] + "*/" if comment else ""
            mutated = mutated[:left] + replacement + mutated[right:]
        with tempfile.TemporaryDirectory(prefix="hepta-cold-authority-source-") as raw:
            root = Path(raw)
            target = root / relative
            target.parent.mkdir(parents=True)
            target.write_text(mutated)
            with self.assertRaises(verifier.VerificationFailure) as failure:
                verifier._verify_protected_files(root, {"protected_file": rows})
        self.assertIn(relative, str(failure.exception))
        self.assertTrue(
            function in str(failure.exception)
            or "required marker missing" in str(failure.exception),
            str(failure.exception),
        )


def mutation(case, comment):
    def run(self):
        self.protect(case, comment)
    return run


for index, case in enumerate(CASES):
    for comment in (False, True):
        name = f"test_guard_{index:02d}_{'comment_is_not_code' if comment else 'cannot_be_removed'}"
        setattr(ColdNextTaskSourceClosure, name, mutation(case, comment))


if __name__ == "__main__":
    unittest.main()
