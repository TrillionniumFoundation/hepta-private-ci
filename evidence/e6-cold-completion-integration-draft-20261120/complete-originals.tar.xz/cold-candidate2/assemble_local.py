"""Render a conditional review overlay from existing cloud bytes; no gates."""

from collections import Counter
import difflib
from hashlib import sha1, sha256
import json
from pathlib import Path
import re
import time
import tomllib


ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
OLD = ROOT / "e6_cold_stage_candidate_1"
ORDINARY = ROOT / "e6_owner_work/completion_acceptance_candidate/rev2"
SOURCE = OUT / "source"
assert not SOURCE.exists(), "This draft is immutable after its first assembly"
START = time.monotonic()


def sha(data):
    return sha256(data).hexdigest()


def blob(data):
    return sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def put(path, data):
    assert not path.exists(), str(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def save(path, value):
    put(path, (json.dumps(value, indent=2) + "\n").encode())


def pin(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(data),
            "sha256": sha(data), "git_blob": blob(data)}


def parts(raw):
    text = raw.decode()
    matches = list(re.finditer(r"(?m)^(?:\[\[(boundary|protected_file)\]\]|\[authority\])\s*$", text))
    result = {"prefix": text[:matches[0].start()], "boundary": [],
              "protected_file": [], "order": []}
    for index, match in enumerate(matches):
        block = text[match.start():matches[index + 1].start() if index + 1 < len(matches) else len(text)]
        kind = match.group(1)
        if kind is None:
            assert "authority" not in result
            result["authority"] = block
            result["order"].append(("authority", None))
        else:
            parsed = tomllib.loads(block)
            assert list(parsed) == [kind] and len(parsed[kind]) == 1
            result["order"].append((kind, len(result[kind])))
            result[kind].append({"row": parsed[kind][0], "raw": block})
    parsed = tomllib.loads(text)
    for kind in ("boundary", "protected_file"):
        assert [item["row"] for item in result[kind]] == parsed[kind]
    return result, parsed


intent = load(OUT / "INTENT.json")
assert sha((OLD / "REVIEW_MANIFEST_1.json").read_bytes()) == intent["previous_manifest_1_sha256"]
assert sha((OLD / "REVIEW_MANIFEST_2.json").read_bytes()) == intent["previous_manifest_2_sha256"]
assert sha((ORDINARY / "MANIFEST.json").read_bytes()) == intent["ordinary_completion_input_manifest_sha256"]
ordinary_manifest = load(ORDINARY / "MANIFEST.json")
assert len(ordinary_manifest["files"]) == 11
for row in ordinary_manifest["files"]:
    data = (ORDINARY / "source" / row["path"]).read_bytes()
    assert (len(data), sha(data), blob(data)) == (row["bytes"], row["sha256"], row["git_blob_oid"])
    if row["before_sha256"] is not None:
        assert sha((ORDINARY / "base" / row["path"]).read_bytes()) == row["before_sha256"]

old_inventory = {str(path.relative_to(OLD / "source")): pin(path)
                 for path in (OLD / "source").rglob("*") if path.is_file()}
assert len(old_inventory) == 65
old_overlay = load(OLD / "OVERLAY_32_MANIFEST.json")
assert len(old_overlay["files"]) == 32
for row in old_overlay["files"]:
    data = (OLD / "source" / row["path"]).read_bytes()
    assert (sha(data), blob(data), len(data)) == (row["after_sha256"], row["after_git_blob"], row["after_bytes"])

policies = {
    "cold": (OLD / "source/CALLERS.toml").read_bytes(),
    "ordinary_before": (ORDINARY / "base/CALLERS.toml").read_bytes(),
    "ordinary_after": (ORDINARY / "source/CALLERS.toml").read_bytes(),
}
pieces = {}
parsed = {}
for side, raw in policies.items():
    pieces[side], parsed[side] = parts(raw)
before, after, cold = (parsed[key] for key in ("ordinary_before", "ordinary_after", "cold"))
assert len(cold["boundary"]) == 1219 and len(cold["protected_file"]) == 928
assert len(before["protected_file"]) == len(after["protected_file"]) == 908
for key in before:
    if key != "protected_file":
        assert before[key] == after[key], key
changes = []
selected = {}
for index, (old_row, new_row) in enumerate(zip(before["protected_file"], after["protected_file"])):
    if old_row == new_row:
        continue
    matches = [i for i, row in enumerate(cold["protected_file"]) if row == old_row]
    assert len(matches) == 1, (old_row["path"], matches)
    cold_index = matches[0]
    assert cold_index not in selected
    selected[cold_index] = pieces["ordinary_after"]["protected_file"][index]
    changes.append({"path": old_row["path"], "ordinary_zero_based_row": index,
                    "cold_zero_based_row": cold_index, "before": old_row,
                    "after": new_row, "resolution": "Exact old semantic occurrence; replace this occurrence only"})
assert len(changes) == 4
rendered = [pieces["cold"]["prefix"]]
for kind, index in pieces["cold"]["order"]:
    if kind == "authority":
        rendered.append(pieces["cold"]["authority"])
    elif kind == "protected_file" and index in selected:
        rendered.append(selected[index]["raw"])
    else:
        rendered.append(pieces["cold"][kind][index]["raw"])
combined_policy = "".join(rendered).encode()
combined_pieces, combined = parts(combined_policy)
for key in cold:
    if key != "protected_file":
        assert cold[key] == combined[key], key
assert len(combined["protected_file"]) == 928
assert sum(x == y for x, y in zip(cold["protected_file"], combined["protected_file"])) == 924
for index, row in enumerate(pieces["cold"]["protected_file"]):
    if index not in selected:
        assert row["raw"] == combined_pieces["protected_file"][index]["raw"]
assert [row["raw"] for row in pieces["cold"]["boundary"]] == [row["raw"] for row in combined_pieces["boundary"]]
prior = load(OLD / "POLICY_COMPOSITION.json")
assert not set(row["path"] for row in changes) & set(prior["prior_49_semantic_groups_raw_blocks_unchanged"])

old_allow = (OLD / "source/.github/blob-size-allowlist.txt").read_bytes()
old_line = f"sha256:{sha(policies['cold'])} CALLERS.toml".encode()
assert old_allow.count(old_line) == 1
combined_allow = old_allow.replace(old_line, f"sha256:{sha(combined_policy)} CALLERS.toml".encode(), 1)

threeway = load(ROOT / "e6_cold_review/independent/THREEWAY_SOURCE_MAP.json")
threeway_paths = {row["path"] for row in threeway["files"]}
assert len(threeway_paths) == 310
assert threeway["cold"] == intent["original_cold_source"]
assert threeway["common"] == "ab12b8bc1e6761efc16ea8c64e839721739cef5f"
ordinary_deltas = {row["path"]: row for row in ordinary_manifest["files"]}
new_source = {path: (OLD / "source" / path).read_bytes() for path in old_inventory}
pending_reads = []
delta_rows = []
for row in ordinary_manifest["files"]:
    path = row["path"]
    if path == "CALLERS.toml":
        baseline = policies["cold"]
        result = combined_policy
        origin = "Four exact protected occurrence migrations; all other cold raw blocks retained"
        baseline_kind = "directly retained frozen cold candidate1 bytes"
    elif path == ".github/blob-size-allowlist.txt":
        baseline = old_allow
        result = combined_allow
        origin = "Only the exact combined CALLERS digest changes"
        baseline_kind = "directly retained frozen cold candidate1 bytes"
    else:
        assert path not in new_source, "Unexpected overlap with old cold overlay; semantic review required"
        assert path not in threeway_paths, "Unexpected cold/common branch delta; semantic review required"
        result = (ORDINARY / "source" / path).read_bytes()
        baseline = (ORDINARY / "base" / path).read_bytes() if row["before_sha256"] else None
        origin = "Exact formatted ordinary completion input; no existing cold-only source overwritten"
        if baseline is None:
            baseline_kind = "new test file; future application must refuse if target path already exists"
        else:
            baseline_kind = "ordinary bfea baseline, inferred common-ancestor identity; no direct cold byte capture retained for this path"
            pending_reads.append({"path": path, "expected_bytes": len(baseline),
                                  "expected_sha256": sha(baseline), "expected_git_blob": blob(baseline),
                                  "required_before_future_application": "Read actual cold-composed target and require byte-exact baseline; mismatch requires new review, never forced replacement",
                                  "current_evidence": "Absent from complete 310-path common/cold/ordinary-parent difference union; ordinary baseline bytes retained",
                                  "direct_cold_entity_readback_complete": False})
    assert path not in new_source or new_source[path] == baseline
    if baseline is not None:
        put(OUT / "conditional_before" / path, baseline)
    new_source[path] = result
    patch = "".join(difflib.unified_diff(baseline.decode().splitlines(True) if baseline is not None else [],
                                       result.decode().splitlines(True),
                                       fromfile="conditional-before/" + path if baseline is not None else "/dev/null",
                                       tofile="source/" + path)).encode()
    assert patch
    put(OUT / "diffs" / (path + ".diff"), patch)
    delta_rows.append({"path": path, "before_kind": baseline_kind,
                       "before_sha256": sha(baseline) if baseline is not None else None,
                       "before_bytes": len(baseline) if baseline is not None else None,
                       "after_sha256": sha(result), "after_bytes": len(result),
                       "after_git_blob": blob(result), "origin": origin,
                       "diff_sha256": sha(patch), "diff_path": "diffs/" + path + ".diff"})
assert len(pending_reads) == 6
assert len(new_source) == 74
for path, data in new_source.items():
    put(SOURCE / path, data)

cold36 = load(OLD / "COLD36_PRESERVATION.json")["files"]
preserved = []
for row in cold36:
    path = row["path"]
    original = (OLD / "original_cold36" / path).read_bytes()
    current = (SOURCE / path).read_bytes()
    assert (sha(original), blob(original), len(original)) == (row["original_sha256"], row["original_git_blob"], row["original_bytes"])
    assert current == (OLD / "source" / path).read_bytes()
    if row["explicit_D_identity_delta"] is None:
        assert current == original
    put(OUT / "original_cold36" / path, original)
    preserved.append({"path": path, "original_sha256": sha(original),
                      "candidate_sha256": sha(current),
                      "explicit_D_identity_delta": row["explicit_D_identity_delta"] is not None,
                      "unchanged_from_candidate1": True})
assert sum(row["explicit_D_identity_delta"] for row in preserved) == 3
unchanged_old_source = [path for path in old_inventory if new_source[path] == (OLD / "source" / path).read_bytes()]
assert len(unchanged_old_source) == 63
store = "codex-rs/hepta-agentd/src/neuron_generation_current_store.rs"
assert new_source[store] == (OLD / "source" / store).read_bytes()

inherited = {row["path"]: dict(row) for row in old_overlay["files"]}
for row in delta_rows:
    path = row["path"]
    if path in inherited:
        inherited[path]["after_sha256"] = row["after_sha256"]
        inherited[path]["after_bytes"] = row["after_bytes"]
        inherited[path]["after_git_blob"] = row["after_git_blob"]
        inherited[path]["new_completion_delta"] = row
    else:
        inherited[path] = row
assert len(inherited) == 41
old_overlay_paths = {row["path"] for row in old_overlay["files"]}
for path, row in inherited.items():
    if path in old_overlay_paths:
        before_path = OLD / "baseline" / path
    else:
        before_path = OUT / "conditional_before" / path
    baseline = before_path.read_bytes() if before_path.is_file() else None
    assert (sha(baseline) if baseline is not None else None) == row["before_sha256"]
    result = new_source[path]
    patch = "".join(difflib.unified_diff(baseline.decode().splitlines(True) if baseline is not None else [],
                                       result.decode().splitlines(True),
                                       fromfile="original-composed-baseline/" + path if baseline is not None else "/dev/null",
                                       tofile="source/" + path)).encode()
    assert patch
    put(OUT / "cumulative_diffs" / (path + ".diff"), patch)
    row["diff_path"] = "cumulative_diffs/" + path + ".diff"
    row["diff_sha256"] = sha(patch)

inputs = [OUT / "INTENT.json", ORDINARY / "MANIFEST.json",
          OLD / "REVIEW_MANIFEST_1.json", OLD / "REVIEW_MANIFEST_2.json",
          OLD / "OVERLAY_32_MANIFEST.json", OLD / "POLICY_COMPOSITION.json",
          OLD / "COLD36_ENTITY_READBACK_2.json",
          ROOT / "e6_cold_review/independent/THREEWAY_SOURCE_MAP.json",
          ROOT / "e6_cold_review/independent/cold-from-common.name-status",
          ROOT / "e6_cold_review/independent/ordinary-parent-from-common.name-status",
          ROOT / "e6_cold_completed_shape_review_1/REVIEW_MANIFEST.json"]
save(OUT / "INPUT_BINDINGS.json", {"files": [pin(path) for path in inputs],
                                   "ordinary_final_source_commit": None,
                                   "ordinary_final_source_tree": None})
save(OUT / "COMPLETION_DELTA_11_MANIFEST.json", {"scope": "11-path conditional delta from the prior cold composition; not a full original673 diff", "files": delta_rows})
save(OUT / "PENDING_SHARED_BASELINE_READBACK.json", {"files": pending_reads,
     "actual_cold_shared_source_reads_performed_this_task": 0,
     "not_a_missing_cold36_original": True,
     "ordinary_baseline_must_not_be_reported_as_cold_entity_readback": True,
     "new_test_path_absence_must_also_be_checked_before_application": [row["path"] for row in delta_rows if row["before_sha256"] is None]})
save(OUT / "COLD36_PRESERVATION.json", {"files": preserved, "originals_retained": 36,
                                       "unchanged_originals": 33, "explicit_D_deltas": 3,
                                       "candidate1_D_deltas_unchanged": True})
save(OUT / "POLICY_MIGRATION.json", {"ordinary_before_sha256": sha(policies["ordinary_before"]),
     "ordinary_after_sha256": sha(policies["ordinary_after"]), "cold_before_sha256": sha(policies["cold"]),
     "cold_after_sha256": sha(combined_policy), "boundary_count": 1219, "protected_occurrences": 928,
     "all_boundary_raw_blocks_unchanged_from_candidate1": True,
     "changed_protected_occurrences": changes, "unchanged_protected_occurrences": 924,
     "duplicate_occurrences_preserved": True, "cold55_raw_blocks_preserved": True,
     "prior49_semantic_group_raw_blocks_preserved": True,
     "prior_two_boundary_six_protected_migrations_and_one_addition_retained": True,
     "all_other_policy_tables_and_root_prefix_unchanged": True,
     "new_authority_boundary_ids": 0, "blob_allowlist_only_CALLERS_digest_changed": True})
save(OUT / "INHERITED_OVERLAY_41_MANIFEST.json", {"scope": "Cumulative review overlay relative to the previously observed6cc cold/read65 composition; not full673 delta", "files": list(inherited.values())})
save(OUT / "SOURCE_74_MANIFEST.json", {"scope": "Partial local review source union, not complete repository",
     "files": [pin(SOURCE / path) for path in sorted(new_source)],
     "inherited_source_paths": 65, "unchanged_inherited_source_paths": unchanged_old_source,
     "newly_materialized_source_paths": 9})
save(OUT / "BINDINGS.json", {"status": "LOCAL_ONLY_CONDITIONAL_SOURCE_DRAFT_NOT_DEPLOYED_OR_QUALIFIED",
     "original_cold_source": intent["original_cold_source"],
     "ordinary_completion_manifest_sha256": intent["ordinary_completion_input_manifest_sha256"],
     "ordinary_completion_final_source_commit": None,
     "ordinary_whole_parent_pass_claimed": False,
     "pending_shared_target_byte_readbacks": 6,
     "new_test_absence_preconditions": 3,
     "cold36_originals_entity_complete": True,
     "source_paths": 74, "new_delta_paths": 11, "cumulative_overlay_paths": 41,
     "source_gates": 0, "formatter_runs_on_combination": 0, "compilations": 0,
     "native_cases": 0, "whole_cold_parents": 0, "model_calls": 0,
     "remote_reads": 0, "host_processes": 0, "host_source_mutations": 0,
     "previous_frozen_candidates_mutated": False,
     "budgets_unchanged": intent["budgets_unchanged"],
     "adopt240_production_authority_gap_solved": False,
     "local_assembly_wall_seconds": time.monotonic() - START})
assert sha((OLD / "REVIEW_MANIFEST_1.json").read_bytes()) == intent["previous_manifest_1_sha256"]
assert sha((OLD / "REVIEW_MANIFEST_2.json").read_bytes()) == intent["previous_manifest_2_sha256"]
assert sha((ORDINARY / "MANIFEST.json").read_bytes()) == intent["ordinary_completion_input_manifest_sha256"]
print(json.dumps({"source_paths": 74, "cold_boundaries": 1219, "protected_occurrences": 928,
                  "policy_sha256": sha(combined_policy), "pending_cold_shared_byte_readbacks": 6,
                  "gates_or_native": 0}, indent=2))
