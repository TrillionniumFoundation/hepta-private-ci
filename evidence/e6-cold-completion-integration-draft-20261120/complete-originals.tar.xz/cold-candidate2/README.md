# Cold candidate 2 — 本云条件合成草案

## 当前状态

本目录在冻结的 `e6_cold_stage_candidate_1` 之上，接入 ordinary completion rev2 的 11 路径增量。输入清单 SHA256 为 `de63e007ca2803a286f22694364348f14a77728af752e627ffe48d04ec6c5ea3`，ordinary 基线为 `bfea526e1cb9a2da718d835cd617e87c67181fe9`。新的 ordinary 最终提交尚未绑定，完整 NoUpdate 父仍未获通过资格。

`source/` 是 **74 个路径的部分本地视图**，并不是完整仓库：此前 65 个路径中，63 个原字节保留，仅两份 policy 文件更新；新增实体为六个共享源码/QA 文件和三个独立测试文件。`COMPLETION_DELTA_11_MANIFEST.json` 描述本轮 11 路径条件增量；`INHERITED_OVERLAY_41_MANIFEST.json` 和 `cumulative_diffs/` 描述相对于此前 observed cold/read65 组合的累计 41 路径增量。两者都不是从原 cold `6733159bd974ae6558e138112d81ca2f6da830e2` 开始的完整差异。

所有准备都在本云完成。没有读取或修改宿主文件，没有启动宿主 owner、formatter、编译、source gate、native、模型或训练；没有更改 candidate1 的文件或 manifest1/2。

## 四条精确 policy 迁移

新的 `CALLERS.toml` SHA256：

`ec10c6b25ac28a8971852e5835b68ebd820c6a2b9a6e4f2f054a65e85bd6016a`

| 目标文件 | 原冷表的零起始记录位置 | 本轮迁移 |
|---|---:|---|
| `learning_iteration_checkpoint.rs` | 808 | 原完整 scope/Coordinator/NextUse 验证保留；移除把容量 8 当作唯一终态长度的条件，并禁止重新引入该条件 |
| `authority_host_completed_record.rs` | 841 | 私有有界 Six/Seven 编码；七份物理 cut、原摘要域、全部 digest 规范检查和不可变首次 fact 门保留 |
| `authority_host_completed_signatures.rs` | 845 | 实际完整终态决定 local journal 记录数 0/1 和签名数 6/7；原真实验签与先后次序保留 |
| `ordinary_q24_cold_acceptance_data_tests.rs` | 874 | 两观察器使用真实 canonical refusal namespace；journals 仍七项，签名按真实非 Proposal receipt 数检查 |

每一条都先在冷表中查到唯一、逐字段相等的旧 ordinary 记录，再替换该 occurrence。未以文件路径折叠重复保护记录。928 条中 **924 条原 raw block 不变，4 条明确替换**；所有 1,219 条 boundary raw block 和其余根表不变。

55 条 cold-only 边界、49 个前次语义解决组以及已声明的两条 boundary 迁移都保留。此前两条为 `q24_original_delivery_complete_operation` 的完整调用拼写规则，以及 `q24_successor_wait_original_generation` 的真实历史调用者；这次没有新增或改变 authority boundary。此前六条 protected 替换和一条新增也保留。从更早 927 条的 6cc 基线累计计算，是 917 条原样、10 条替换和 1 条新增，最终仍为 928 条。

大文件许可表仅把原 `CALLERS.toml` 的精确 SHA 改成新的组合 SHA，未增加路径或改变阈值。

## 共享文件的条件边界

六个共享既有文件的 **ordinary bfea 旧字节** 已在本云；但这六个文件的独立冷工作区实体字节没有保存。本次没有远程补读。

原 common ancestor `ab12b8bc1e6761efc16ea8c64e839721739cef5f`、cold673 和 ordinary-parent ab5 的完整 310 路径差异集合不含这六个文件，也不含三个新测试路径。因此没有已知冷分支冲突；这仍不能冒充对未来应用目标的实读。

`conditional_before/` 明确保存 ordinary 的旧字节，`PENDING_SHARED_BASELINE_READBACK.json` 列出必须核对的六个实际目标：

- `authority_host_completed_record.rs`
- `authority_host_completed_signatures.rs`
- `learning_iteration_checkpoint.rs`
- `ordinary_q24_cold_acceptance_data_tests.rs`
- `qa/b4-no-bypass/test_completed_learning_acceptance_source_closure.py`
- `qa/b4-no-bypass/test_root_learning_scope_source_closure.py`

未来应用必须先读取冷组合工作区的实际文件，匹配清单中的完整长度、SHA256 和 Git blob。任一差异都要求新的语义审查，不得强行覆盖。三个新增测试路径必须确认原目标不存在。本文没有把这些条件标为已通过，也没有把缺少的共享目标实读与已经完整保存的 36 份 cold 原件混为一谈。

## 冷路径保留情况

`original_cold36/` 完整保存 36/36 份原字节；`source/` 中 33 份仍与原673字节完全相同，另三份仍是 candidate1 已声明的 D fixture 身份修正，本轮未再次修改。原 CurrentStore 保持 candidate1 的精确字节，即原冷产品源码加四行 cfg(test) 模块接线，没有把 ordinary Store 整文件覆盖进来。

共享接受链修复不省略冷历史必须观察的七份物理 journal/witness，不改 first fact、Root 当前信任、签名时点、typed ACK、真实退休 proof、新 Root/daemon、D 或 FinalUse 的授权语义。research 的独立冷完成形态复核已作为输入 pin 保存，但其只读结论不是组合源码门或冷父执行结果。

NoUpdate CURRENT 600 秒、原 writer/authority lease 300 秒、新 D 120 秒、whole-cold 480 秒、历史请求 64 上限和旧学习 envelope 均保持。Adopt 240 秒授权缺口继续明确未解决；没有接入默认关闭的 use-grant 草稿，没有放宽 generic expired CURRENT。

## 后续资格

本草案的 combined source gate、formatter、编译、native、whole-cold、模型调用数均为 **零**。实际 ordinary 完整 NoUpdate 父通过并释放测量 owner 后，仍需绑定其最终源码提交、核对上述实际目标、形成完整独立组合源，再单独执行原组合门和原冷父。不能继承 ordinary、旧 cold 或本地 TOML 比较的结果作为这份组合的资格。
