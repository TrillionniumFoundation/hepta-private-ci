//! New D descriptors over the original cold-retired C, with all old learning
//! fields retained. The explicit product branch must avoid those old writers.

use std::os::unix::fs::FileExt;
use std::path::PathBuf;
use std::time::Instant;

use codex_hepta_evidence::HeptaEvidenceStore;
use codex_hepta_neuron::CellGenerationObserverConfigV1;
use codex_hepta_types::Digest32;
use serde_json::Value;
use serde_json::json;

use super::cold_deployment::OriginalColdPlan;
use super::cold_next_artifacts::OriginalDArtifactInputs;
use super::cold_next_authorization::D_OPERATION;
use super::cold_next_authorization::OriginalDControllerInputs;
use super::cold_next_model::OriginalColdSelectedModelData;
use super::cold_next_source::OriginalDInputFiles;
use super::cold_successor_data::ExpectedColdCData;
use super::cold_successor_data::OriginalColdSuccessorData;

pub(super) struct OriginalColdDPlan<'a> {
    pub(super) cold: OriginalColdPlan<'a>,
    pub(super) inputs: OriginalDInputFiles,
    pub(super) artifacts: OriginalDArtifactInputs,
    pub(super) authorization: OriginalDControllerInputs,
    pub(super) target: CellGenerationObserverConfigV1,
    pub(super) deployment: PathBuf,
    pub(super) expected: ExpectedColdCData,
}

impl<'a> OriginalColdDPlan<'a> {
    pub(super) fn prepare(
        mut cold: OriginalColdPlan<'a>,
        successor: &OriginalColdSuccessorData,
        runtime: &tokio::runtime::Runtime,
    ) -> anyhow::Result<Self> {
        anyhow::ensure!(
            Instant::now() < cold.administration.end,
            "new D preparation deadline"
        );
        let original = cold.original;
        original.daemon.require_dead()?;
        original.root.require_dead()?;
        original.source.require_dead()?;
        let expected = successor.declare_expected_cold_data(original)?;
        let root = original.plan.resources.original.plan.runtime.path();
        let data = root.join("cold-d-data");
        let witnesses = root.join("cold-d-witnesses");
        for path in [&data, &witnesses] {
            std::fs::create_dir(path)?;
            super::super::owned_mode(path, 60001, 60001, 0o700)?;
        }
        let frontier = runtime.block_on(original_replay_frontier(&cold))?;
        let mut inputs = OriginalDInputFiles::reserve(
            original,
            &cold.administration.successor,
            &data,
            &witnesses,
            frontier,
        )?;
        let model = OriginalColdSelectedModelData::observe_and_copy(original, &data)?;
        let target = inputs.publish_selected_input_data(
            &cold.administration.successor,
            &original.decision.bundle,
            &model.model,
            &original.selected.manifest,
        )?;
        let artifacts = OriginalDArtifactInputs::observe_and_sign(original, &inputs, &data)?;
        let authorization = OriginalDControllerInputs::sign_current_inputs(
            original,
            &cold.administration.successor,
            &expected,
            &inputs,
            &target,
            &artifacts,
            &cold.administration.directory,
        )?;
        let material = json!({
            "schema_version":1,
            "target":super::super::data::ObserverData::from_original_observer(&target),
            "selection":super::super::data::SelectionData::from_original_selection(
                &artifacts.selected.selection
            )?,
        });
        inputs
            .publication_material
            .write_original_once(&serde_json::to_vec(&material)?)?;
        let deployment = cold.administration.directory.join("cold-next-task.json");
        super::root::write_json(
            &deployment,
            &json!({
                "schema":1, "purpose":"runtime.circuit.cold-next-task-deployment.v1",
                "operation":D_OPERATION,
                "inputs":artifacts.inputs,
                "material":material,
                "successor":inputs.root_successor_data(),
                "authorization":authorization.files,
                "writer_lease":artifacts.writer_lease.path,
                "writer_lease_sha256":artifacts.writer_lease_sha256,
            }),
        )?;
        let length = cold.sealed.metadata()?.len();
        anyhow::ensure!(
            (1..=1_048_576).contains(&length),
            "original sealed cold deployment bound"
        );
        crate::authority_host_bootstrap_seal::validate_sealed(&cold.sealed, length)?;
        let mut bytes = vec![0; usize::try_from(length)?];
        cold.sealed.read_exact_at(&mut bytes, 0)?;
        crate::authority_host_bootstrap_seal::validate_sealed(&cold.sealed, length)?;
        let mut daemon: Value = serde_json::from_slice(&bytes)?;
        anyhow::ensure!(
            daemon["completed_history"] == "capture_retired" && daemon["cold_next_task"].is_null(),
            "new D must first capture and read C through the original cold Root"
        );
        daemon["cold_next_task"] = model.deployment;
        daemon["continuation"]["artifacts"] = artifacts.daemon_artifact_data();
        daemon["continuation"]["task"] = inputs.daemon_task_data();
        // Old freeze/stages/delivery/generation modes and paths remain exactly
        // as in the readonly cold plan. The explicit D branch cannot open them.
        let next = serde_json::to_vec(&daemon)?;
        super::root::write_bytes(
            &cold
                .administration
                .directory
                .join("cold-next-daemon-deployment.json"),
            &next,
        )?;
        cold.sealed = super::fixture::seal_original_readonly_deployment(&next)?;
        original.daemon.require_dead()?;
        original.root.require_dead()?;
        original.source.require_dead()?;
        anyhow::ensure!(
            Instant::now() < cold.administration.end,
            "new D preparation ended late"
        );
        Ok(Self {
            cold,
            inputs,
            artifacts,
            authorization,
            target,
            deployment,
            expected,
        })
    }
}

async fn original_replay_frontier(plan: &OriginalColdPlan<'_>) -> anyhow::Result<Digest32> {
    let original = plan.original;
    original.daemon.require_dead()?;
    original.root.require_dead()?;
    let identity = &original.plan.resources.successor.identity;
    let store =
        HeptaEvidenceStore::open_existing_read_only(&codex_state::SqliteConfig::from_sqlite_home(
            codex_utils_absolute_path::AbsolutePathBuf::from_absolute_path(&identity.home_root)?,
        ))
        .await?;
    let result = store.authbus_replay_frontier_digest().await;
    store.close().await;
    let frontier = result?;
    let checkpoint_path = &original.plan.resources.original.plan.replay_checkpoint;
    let (_, checkpoint) =
        crate::authbus_checkpoint::ReplayCheckpointFile::open(checkpoint_path.clone(), identity)?;
    anyhow::ensure!(
        checkpoint.digest == frontier,
        "actual retired C replay checkpoints differ"
    );
    original.daemon.require_dead()?;
    original.root.require_dead()?;
    original.source.require_dead()?;
    Ok(frontier)
}
