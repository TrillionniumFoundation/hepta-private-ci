//! Explicit controller signatures for one new D after real C retirement.
//! Everything constructed here is DATA. The new Root must derive the same
//! intent from its own finalized C, original files and current authority.

use std::path::Path;
use std::path::PathBuf;

use codex_hepta_neuron::CellGenerationObserverConfigV1;
use codex_hepta_neuron::CellGenerationOwnerBindingV1;
use codex_hepta_types::Digest32;
use ed25519_dalek::Signer;
use ed25519_dalek::SigningKey;

use super::cold_next_artifacts::OriginalDArtifactInputs;
use super::cold_next_source::OriginalDInputFiles;
use super::cold_successor_data::ExpectedColdCData;
use super::post_a_retained::RetainedOrdinaryQ24Fixture;
use super::recovery::OriginalSuccessorAdministration;
use crate::authority_host_runtime::ColdNextTaskAuthorizationFilesDataV1;
use crate::authority_host_runtime::RootSuccessorTaskFilesDataV1;
use crate::cold_next_task_data::AUTHORIZATION_PURPOSE;
use crate::cold_next_task_data::ColdNextTaskAuthorizationDataV1;
use crate::cold_next_task_data::ColdNextTaskBindingDataV1;
use crate::cold_next_task_data::ColdNextTaskControllerDataV1;
use crate::cold_next_task_data::ColdNextTaskControllerRoleV1;
use crate::neuron_generation_current::types::UpdateIntent;

pub(super) const D_OPERATION: &str = "ordinary-original-cold-d-publication";

pub(super) struct OriginalDControllerInputs {
    pub(super) files: ColdNextTaskAuthorizationFilesDataV1,
    pub(super) intent: UpdateIntent,
    pub(super) configuration: Digest32,
    pub(super) signed_objective: crate::AuthBusObjectiveIngress,
    pub(super) payload: Digest32,
    pub(super) authorization: ColdNextTaskAuthorizationDataV1,
}

impl OriginalDControllerInputs {
    pub(super) fn sign_current_inputs(
        original: &RetainedOrdinaryQ24Fixture,
        successor: &OriginalSuccessorAdministration,
        expected: &ExpectedColdCData,
        d: &OriginalDInputFiles,
        target: &CellGenerationObserverConfigV1,
        artifacts: &OriginalDArtifactInputs,
        directory: &Path,
    ) -> anyhow::Result<Self> {
        original.daemon.require_dead()?;
        original.root.require_dead()?;
        original.source.require_dead()?;
        let source_bytes = d.source_configuration.read_original(65_536)?;
        let target_bytes = d.target_configuration.read_original(65_536)?;
        let objective_bytes = d.signed_ingress.read_original(16_384)?;
        let objective: crate::AuthBusObjectiveIngress = serde_json::from_slice(&objective_bytes)?;
        let source = crate::OriginalSingleQ24SourceConfigurationV1::from_original_deployment_bytes(
            &source_bytes,
            &successor.identity,
        )?;
        anyhow::ensure!(
            serde_json::to_vec(&objective)? == objective_bytes
                && serde_json::to_vec(d.objective_request())? == objective_bytes
                && objective.body.run_id == super::inputs::D_RUN
                && objective.body.run_id == source.source.scope.run_id.as_str()
                && objective.body.runtime_body_digest
                    == source.definition.runtime.runtime_digest.to_string()
                && objective.body.model_tuple_digest
                    == source.definition.semantic_digest()?.to_string()
                && objective.body.artifact_set_digest
                    == original.decision.bundle.digest()?.to_string(),
            "signed D Objective must be the full original selected-model request"
        );
        anyhow::ensure!(
            source.source == *d.expected_source()
                && source.source.observation != original.completed.source.input().observation,
            "D requires the declared new actual input, not a replay of C"
        );
        let declared: RootSuccessorTaskFilesDataV1 =
            serde_json::from_value(d.root_successor_data())?;
        let files_digest = Digest32::of_parts(&[
            b"hepta.root.original-successor-files.v1\0",
            &serde_json::to_vec(&declared)?,
        ]);
        let configuration = Digest32::of_parts(&[
            b"hepta.root.original-successor-configuration.v1\0",
            files_digest.as_array(),
            &source_bytes,
            &target_bytes,
            &objective_bytes,
        ]);
        let to = CellGenerationOwnerBindingV1::new(&target.generation, target.journal_records)?;
        let previous = &original.completed.generation;
        anyhow::ensure!(
            previous.is_drained()
                && previous.owner_binding() == &original.completed.current.current
                && to.scope().run_id == super::inputs::D_RUN
                && to.scope().run_id != previous.owner_binding().scope().run_id
                && target.generation.manifest == original.selected.manifest,
            "D must use a fresh task binding under exactly the selected C model"
        );
        let intent = UpdateIntent {
            operation_id: D_OPERATION.into(),
            supersedes: None,
            previous: previous.owner_binding().clone(),
            previous_checkpoint: previous.observation().owner_checkpoint().into_array(),
            previous_observation: previous.observation().digest()?,
            target: to.clone(),
            genesis_checkpoint: to.genesis_checkpoint().into_array(),
            selection: artifacts.selection_digest.into_array(),
            completion: crate::NeuronGenerationPredecessorCompletionV1::OwnerDrainedSameModel,
        };
        let config: crate::HostAuthorityServiceConfig =
            serde_json::from_slice(&super::observer::read_private(&successor.service, 16_384)?)?;
        let writer = config
            .writer
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("actual new cold Root writer absent"))?;
        let authority_epoch = writer.authority_lease.authority_epoch;
        anyhow::ensure!(
            writer.registered_agent_id == successor.identity.agent_id
                && writer.spawn_generation == successor.identity.spawn_generation
                && objective.body.authority_epoch == authority_epoch,
            "new D controller epoch and recipient must match the fixed new Root writer"
        );
        let claims = crate::authbus_objective_claims(&successor.identity, &objective)?;
        let objective_signature = crate::authbus_trust::hex_bytes::<64>(&objective.signature_hex)?;
        let binding = ColdNextTaskBindingDataV1 {
            agent: successor.identity.agent_id.to_string(),
            principal: Digest32::from_array(to.scope().principal_digest),
            authority_epoch,
            recipient: crate::neuron_generation_process_identity_digest_v1(&successor.identity)?,
            writer: successor.writer_proof.sha256()?.as_str().parse()?,
            predecessor_current: expected.current,
            predecessor_record: expected.successor_record,
            predecessor_cut: expected.successor_cut,
            input: configuration,
            task: Digest32::from_array(to.task_digest()),
            target: Digest32::from_array(to.digest()?),
            intent: intent.digest()?,
            manifest: Digest32::from_array(artifacts.selected.manifest.digest()?),
            selection: artifacts.selection_digest,
            objective: Digest32::of_bytes(&claims.signing_bytes()),
            objective_message_id: claims.message_id.to_string(),
            objective_sequence: claims.sequence,
            objective_signature: Digest32::of_bytes(&objective_signature),
            objective_expiry_ms: claims.expires_at_ms,
            consumer: expected.consumer,
            consumer_trust: expected.consumer_trust,
        };
        let now = crate::authbus_ingress::now_ms()?;
        let expires = now
            .checked_add(120_000)
            .ok_or_else(|| anyhow::anyhow!("new D authorization expiry overflow"))?
            .min(claims.expires_at_ms)
            .min(writer.authority_lease.expires_at_unix_ms)
            .min(artifacts.selected.selection.expires_at);
        anyhow::ensure!(now < expires, "new D current authorization window ended");
        let controller = ColdNextTaskControllerDataV1 {
            schema: 1,
            purpose: AUTHORIZATION_PURPOSE.into(),
            role: ColdNextTaskControllerRoleV1::ColdNextTask,
            principal: binding.principal.to_string(),
            issuer: objective.issuer_id.clone(),
            key_epoch: objective.key_epoch,
            authority_epoch,
            agent: binding.agent.clone(),
            allowed_scope: binding.scope()?.to_string(),
        };
        let trust_bytes = super::observer::read_private(
            &original.plan.resources.original.plan.objective_trust,
            16_384,
        )?;
        let trust = crate::authbus_trust::TextTrust::from_original_bytes(
            &trust_bytes,
            &successor.identity,
        )?;
        let payload = binding.digest()?;
        let mut authorization = ColdNextTaskAuthorizationDataV1 {
            schema: 1,
            purpose: AUTHORIZATION_PURPOSE.into(),
            issuer_id: objective.issuer_id.clone(),
            key_epoch: objective.key_epoch,
            message_id: "ordinary-original-cold-d-authorization".into(),
            sequence: 4,
            expires_at_ms: expires,
            payload: payload.to_string(),
            signature_hex: String::new(),
        };
        let key = SigningKey::from_bytes(&[91; 32]);
        authorization.signature_hex = super::inputs::hex(
            &key.sign(&authorization.claims(&binding)?.signing_bytes())
                .to_bytes(),
        );
        authorization.require_current(&controller, &trust, &binding, now)?;
        let files = ColdNextTaskAuthorizationFilesDataV1 {
            controller: directory.join("d-controller.json"),
            trust: directory.join("d-current-authbus-trust.json"),
            authorization: directory.join("d-signed-authorization.json"),
        };
        super::root::write_json(&files.controller, &controller)?;
        super::root::write_bytes(&files.trust, &trust_bytes)?;
        super::root::write_json(&files.authorization, &authorization)?;
        super::root::write_json(
            &directory.join("d-expected-finalized-c-data.json"),
            &serde_json::json!({
                "purpose":"controller-expectation-only-not-Root-finalization",
                "current":expected.current.to_string(),
                "successor_record":expected.successor_record.to_string(),
                "successor_cut":expected.successor_cut.to_string(),
                "cut":expected.cut,
            }),
        )?;
        original.daemon.require_dead()?;
        original.root.require_dead()?;
        original.source.require_dead()?;
        Ok(Self {
            files,
            intent,
            configuration,
            signed_objective: objective,
            payload,
            authorization,
        })
    }

    pub(super) fn original_paths(&self) -> [PathBuf; 3] {
        [
            self.files.controller.clone(),
            self.files.trust.clone(),
            self.files.authorization.clone(),
        ]
    }
}
