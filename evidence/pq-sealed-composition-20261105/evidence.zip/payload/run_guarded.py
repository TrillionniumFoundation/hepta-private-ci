from pathlib import Path
import os, sys, json, signal, subprocess, time, shutil, hashlib
root=Path('/workspace/scratch/baeed38792e5/pq-work')
repo=root/'pq-with-sealed'
label=sys.argv[1]
command=sys.argv[2:]
log=root/(label+'.log')
record={'command':command,'cwd':str(repo/'codex-rs'),'minimum_free_bytes':1200*1024*1024,'compiler':subprocess.check_output(['/root/.cargo/bin/rustc','--version'],cwd=repo/'codex-rs',text=True).strip(),'pkg_config':'/workspace/scratch/baeed38792e5/host-tools/pkgconf','target_dir':str(root/'check-target'),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'started_epoch':time.time()}
paths=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=repo,text=True).splitlines()
record['source_sha256']={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
env=os.environ.copy()
env['PATH']='/root/.cargo/bin:/workspace/scratch/822cc50e24f0/authority-recovery/native-20261105/bin:'+env['PATH']
env['CARGO_TARGET_DIR']=str(root/'check-target')
env['CARGO_BUILD_JOBS']='1'
env['CARGO_NET_OFFLINE']='true'
env['PKG_CONFIG']=record['pkg_config']
free=shutil.disk_usage(root).free
if free<record['minimum_free_bytes']:
 record.update(exit_code=None,resource_stop='insufficient free disk before build',free_bytes=free)
 (root/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 sys.exit(125)
with log.open('w') as out:
 process=subprocess.Popen(command,cwd=repo/'codex-rs',env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 print('Started '+label+' pid='+str(process.pid),flush=True)
 last=time.monotonic()
 while process.poll() is None:
  free=shutil.disk_usage(root).free
  memory={line.split()[0]:int(line.split()[1]) for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines()}
  resident=memory['anon']+memory['shmem']+memory['kernel']
  tmpfree=shutil.disk_usage('/dev/shm').free
  if free<record['minimum_free_bytes'] or resident>6*1024**3 or tmpfree<512*1024**2:
   record['resource_stop']='disk, committed memory, or tmpfs crossed reserve'
   record['free_bytes']=free
   record['anon_shmem_kernel_bytes']=resident
   record['tmpfs_free_bytes']=tmpfree
   os.killpg(process.pid,signal.SIGINT)
   try:process.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
   break
  if time.monotonic()-last>=30:
   print(label+' running; free MiB='+str(free//1024//1024),flush=True)
   last=time.monotonic()
  time.sleep(2)
 record['exit_code']=process.wait()
record['finished_epoch']=time.time()
record['source_unchanged_during_execution']=all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==digest for p,digest in record['source_sha256'].items())
(root/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='source_sha256'}),flush=True)
print('Log tail:',flush=True)
print(''.join(log.read_text(errors='replace').splitlines(keepends=True)[-35:]),flush=True)
sys.exit(record['exit_code'] if record['exit_code']>=0 else 128-record['exit_code'])
