#!/usr/bin/env python3
"""Read-only verification of real tracked bytes, file types and Git modes."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time


def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root)


def state(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_size,
            value.st_mtime_ns, value.st_ctime_ns)


def verify(root, expected):
    started = time.time()
    head = git(root, 'rev-parse', 'HEAD').decode().strip()
    if head != expected:
        raise ValueError(f'HEAD mismatch: {head} != {expected}')
    tree = git(root, 'rev-parse', 'HEAD^{tree}').decode().strip()
    entries = []
    for row in git(root, 'ls-tree', '-rz', '--full-tree', expected).split(b'\0'):
        if row:
            fields, name = row.split(b'\t', 1)
            mode, kind, blob = fields.decode().split()
            entries.append((os.fsdecode(name), mode, kind, blob))
    index_before = git(root, 'ls-files', '--stage', '-z')
    index = {}
    for row in index_before.split(b'\0'):
        if row:
            fields, name = row.split(b'\t', 1)
            mode, blob, stage = fields.decode().split()
            if stage != '0':
                raise ValueError('Index contains an unresolved merge')
            index[os.fsdecode(name)] = (mode, blob)
    if index != {name: (mode, blob) for name, mode, _, blob in entries}:
        raise ValueError('Index mode/blob/path inventory differs from committed tree')
    errors = []
    verified_parents = set()
    stable_states = {}
    modes = Counter()
    permissions = Counter()
    inventory = hashlib.sha256()
    bytes_hashed = 0
    symlinks = []
    for name, mode, kind, expected_blob in entries:
        relative = Path(name)
        full = root / relative
        try:
            if relative.is_absolute() or '..' in relative.parts:
                raise ValueError('Noncanonical Git path')
            for parent in relative.parents:
                if parent in verified_parents:
                    continue
                parent_stat = os.lstat(root / parent)
                if not stat.S_ISDIR(parent_stat.st_mode):
                    raise ValueError(f'Ancestor is not a real directory: {parent}')
                verified_parents.add(parent)
            before = os.lstat(full)
            permissions[f'{stat.S_IMODE(before.st_mode):04o}'] += 1
            actual_blob = None
            if mode in ('100644', '100755'):
                if kind != 'blob' or not stat.S_ISREG(before.st_mode):
                    raise ValueError('Expected a real regular file, not a symlink or special file')
                actual_mode = '100755' if before.st_mode & 0o111 else '100644'
                if actual_mode != mode:
                    raise ValueError(f'Executable mode differs: {actual_mode} != {mode}')
                h = hashlib.sha1(b'blob ' + str(before.st_size).encode() + b'\0')
                fd = os.open(full, os.O_RDONLY | os.O_NOFOLLOW)
                with os.fdopen(fd, 'rb') as stream:
                    if state(os.fstat(stream.fileno())) != state(before):
                        raise ValueError('File changed between lstat and open')
                    size = 0
                    while True:
                        chunk = stream.read(1024 * 1024)
                        if not chunk:
                            break
                        size += len(chunk)
                        h.update(chunk)
                    if size != before.st_size or state(os.fstat(stream.fileno())) != state(before):
                        raise ValueError('File changed while hashing')
                actual_blob = h.hexdigest()
                bytes_hashed += size
            elif mode == '120000':
                if kind != 'blob' or not stat.S_ISLNK(before.st_mode):
                    raise ValueError('Expected an actual symlink')
                target = os.fsencode(os.readlink(full))
                actual_blob = hashlib.sha1(b'blob ' + str(len(target)).encode() + b'\0' + target).hexdigest()
                bytes_hashed += len(target)
                symlinks.append({'path': name, 'target': os.fsdecode(target), 'blob_sha': actual_blob})
            elif mode == '160000':
                if kind != 'commit' or not stat.S_ISDIR(before.st_mode):
                    raise ValueError('Expected a submodule directory')
                actual_blob = git(full, 'rev-parse', 'HEAD').decode().strip()
            else:
                raise ValueError(f'Unsupported tracked Git mode: {mode}')
            if actual_blob != expected_blob:
                raise ValueError(f'Actual byte hash differs: {actual_blob} != {expected_blob}')
            if state(os.lstat(full)) != state(before):
                raise ValueError('File changed during type/mode/byte verification')
            stable_states[name] = state(before)
            modes[mode] += 1
            inventory.update(json.dumps([name, mode, actual_blob], ensure_ascii=True,
                                        separators=(',', ':')).encode() + b'\n')
        except (OSError, ValueError, subprocess.SubprocessError) as error:
            errors.append({'path': name, 'error': str(error)})
    for name, old_state in stable_states.items():
        try:
            if state(os.lstat(root / name)) != old_state:
                errors.append({'path': name, 'error': 'File changed after its byte verification'})
        except OSError as error:
            errors.append({'path': name, 'error': str(error)})
    head_after = git(root, 'rev-parse', 'HEAD').decode().strip()
    index_after = git(root, 'ls-files', '--stage', '-z')
    if head_after != head or index_before != index_after:
        errors.append({'path': '<Git identity>', 'error': 'HEAD or index changed during verification'})
    return {'schema': 'hepta.tracked-real-bytes.v1', 'status': 'PASS' if not errors else 'FAIL',
            'commit': head, 'tree': tree, 'tracked_entries': len(entries),
            'verified_entries': sum(modes.values()), 'bytes_hashed': bytes_hashed,
            'actual_git_modes': dict(modes), 'actual_posix_permissions': dict(permissions),
            'actual_symlinks': symlinks, 'actual_inventory_sha256': inventory.hexdigest(),
            'index_matches_committed_tree': True, 'head_and_index_stable': head_after == head and index_after == index_before,
            'all_successful_paths_restatted_after_hashing': True,
            'errors': errors, 'started_at': datetime.fromtimestamp(started, timezone.utc).isoformat(),
            'elapsed_seconds': time.time() - started,
            'scope': 'Real filesystem bytes/types/Git executable modes and symlink target bytes; no build or runtime qualification',
            'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.repo.resolve(), args.commit)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'actual_symlinks'}, indent=2))
    raise SystemExit(result['status'] != 'PASS')


if __name__ == '__main__':
    main()
