# PQ + sealed qualification integration — DRAFT / HOLD

This package is ready only for reviewable publication to the existing hepta-private-ci PR #4812. It is **not** a qualification, merge, release, or production-activation PASS.

## Fixed source identity

- Repository: TrillionniumFoundation/hepta-private-ci.
- PQ recovery / FinalUse base: `7530e4bc7aa61a0c23a5933fef4a65d86a586cf8`.
- Sealed qualification donor: `06ad4a9b48aa28ef6edfc537243f069e2d48eb40`.
- Final prospective Git tree: `7ad4a974496e587f0ce863ce565cb74a98149b2e`.
- Exactly 24 changed Rust source files; their Git blob SHAs, modes, byte counts and SHA-256 values are in `FINAL_FILES.json` and `FINAL_HANDOFF.json`.
- Complete patch: `pq-sealed-final.patch`, SHA-256 `bac143a09e63a32c496a61bbdecddf658ce38dc75508342be794ad7cbdc6552b` (139442 bytes).
- Immutable changed-source archive: `pq-sealed-final-source.tar.gz`, SHA-256 `8278e57eed4592eb5ed4a56529fe21c89a0c428860237101604b572afdc1811b`.

## What was integrated

Mandatory sealed published qualification is consumed by the Agentd evaluation path, plasticity candidate path and self-evolution selection. Current-use revalidation checks the complete signed decision and current verifier/time. The qualification seal binds the complete decision fields; temporal-plan integrity is recomputed before final holdout consumption. Agentd retains the base branch's authentication-profile agreement, current-owner key/epoch checks and distinct classical/PQ domains. Canonical product selection retains the base's candidate-byte binding. Signed legitimate NoAdmissibleUpdate remains an allowed outcome rather than an invented eligible candidate.

The full PQ recovery / FinalUse base was preserved. The inverse integration (qualification into #4812) was selected because #4855 at44e3552e62e9306f4ad70d083d721a18f8d2d805 still had classical Ed25519 recovery and lacked the PQ contracts module, ML-DSA dependency and corresponding lockfile entry. A5–8file PQ-only transplant into that branch is not a complete compiling base. #4855 does contain the read-only store opener; do not repeat the earlier corrected claim that it was missing.

Independent review found and fixed two fixture/evidence regressions: controller collision is injected only after creation of a valid qualification verifier, and the complete attempted no-update inputs are written before qualification controls can return EvaluationRejected. A native no-update file/digest assertion was added but its actual Agentd execution remains blocked.

## Verification and limits

| Gate | Actual outcome | Scope |
|---|---|---|
| First eval/intelligence native run |205PASS,13FAIL,0skipped | Integration fixture REDs; raw log retained, not a baseline exploit demonstration |
| Repaired prior-source native run |218PASS,0FAIL,0skipped | Original pinnedRust1.96/defaultfeatures/testprofile; prior tree285b7510cf7f247b84a4c55fa349af77810a3b4b only |
| Final scoped `just fix` for eval/intelligence |PASS | One redundant test-fixture clone removed; exactdiff retained |
| Final `just fmt` and `git diff --check` |PASS | No final formatting changes |
| Final exact-source218 revalidation |**BLOCKED_RESOURCE** | Disk preflight rejected before Cargo started:324636672bytes free vs1258291200required |
| Agentd + infer original default graph `--tests` |**BLOCKED_RESOURCE** | Preserved original missingpkg-config failure and5 subsequent originalgraph resource stops; no complete typecheck |
| Agentd + infer scoped `just fix` |**BLOCKED_RESOURCE** | Single attempt stopped atsharedresident6.12GiB; source unchanged |
| Native current-owner/PQ selector/install and3-generation no-update |**BLOCKED_RESOURCE / NOT RUN** | Cannot claim these pass from other-branch binaries or the218test suite |

Final tree is different from the prior218-PASS source. Its later changes are fully recorded, and **prior PASS is not promoted to final same-source PASS**. No claim is made that all P0 effects, original liveness conditions, service archive promises, WAN/physical-power-loss behavior or independent system acceptance have passed.

No Cargo dependency, lockfile, feature, profile, compiler pin or productionPQ backend was changed. The actual installedpkgconf3.0.10 was supplied only for systemOpenSSL3.0.13 discovery in general TLS/sqlx dependencies. Exact tool/config/lock hashes are in `FINAL_HANDOFF.json`. Buildjobs remained1; original resource guards were preserved. Owngeneratedmetadata cache relocation and idleincremental cleanup have separate receipts; they do not represent tests.

## Remaining native work for CI / a provisioned runner

1. Run original locked default-feature Agentd+infer-worker-host `cargo check --tests` to completion; fix any actual interface errors it reveals.
2. Complete scoped `just fix` for both consumers and the final same-source `just test --locked -p codex-hepta-intelligence-eval -p codex-hepta-intelligence`.
3. Run Agentd current-owner evaluation negatives and `native_pq_history_product_current_selector_install_replay_and_live_floor` on this exact tree.
4. Run the retained ignored `three_actual_fits_installations_future_instances_no_update_and_revocation` with a fresh study directory and the exact tracked `qualification/learning-generations/custodian.py`; check the new no-update input/file/digest assertions.
5. Bind results to the same fixed Chain/Hepta/config/binary combination before changing HOLD status. Do not merge main or activate production based on this package.

All source and test failures remain available. `remote_ready=true` means only that the concrete Draft/HOLD source package can be published for review; it does not close a runtime or qualification gate.
