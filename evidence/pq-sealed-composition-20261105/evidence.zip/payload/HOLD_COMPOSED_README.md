# PQ Frontier V4 + sealed qualification — composed DRAFT / HOLD

## Fixed identity and preservation

The new primary base is `97ae5b4bf5e5f0d0589c1c653f1861e1d9c1242f`. It adds Snapshot V3, PQ Frontier V4, actual invocation history, authoritative intent joins and actual SQLite key checks. The exact commit object and all 23 changed file blobs were verified against the clean local checkout of that exact commit. The one-commit object transfer was only 116884 bytes; no large tree was copied.

The prior sealed code identity is commit `5375d7d2774f7422d6c7c352188273e678746376`, tree `7ad4a974496e587f0ce863ce565cb74a98149b2e`, based on `7530e4bc7aa61a0c23a5933fef4a65d86a586cf8`. Its source package and test/resource evidence remain unchanged. A merge commit may use parents `97ae5b4bf5e5f0d0589c1c653f1861e1d9c1242f` and `5375d7d2774f7422d6c7c352188273e678746376`.

**Composed source tree: `039577d88899ddc1725f44dbf508e69d58506fe3`.** There are exactly 24 changed Rust source files relative to the new primary base. `FINAL_COMPOSED_FILES.json` contains each path, Git mode, blob SHA and SHA-256. Complete patch SHA-256: `72cbdfa96e76648f6ecd844d51830dd488b78989c1e68711a2a82995680f26c4`. Changed-source archive SHA-256: `3b48466085948ae041fb3c4e2be88df7993981fab9b53d8f750864929177643e`.

All 22 non-overlapping remote files are byte-identical to 97ae; all 23 non-overlapping sealed files are byte-identical to the prior sealed package. The only overlap is `codex-rs/hepta-agentd/src/lib.rs`. A clean three-way merge retains both `EvidenceRecoveryFrontierV4` and `intelligence_evaluation_binding_payload_v2`; each side's exact one-line difference is retained separately. No recovery, provider-record, workflow, documentation, truth-map or source-registration change from97ae was dropped.

## Checks on this exact composed source

- `just fmt`: PASS; no source changed.
- `python3 scripts/verify_lane_a_foundation.py verify`: PASS.
- `python3 scripts/verify_lane_a_foundation.py self-test`: PASS.
- `hepta_source_registry_closure.verify()`: PASS, zero failures.
- `git diff --check`, reverse-patch verification, and exact file-preservation checks: PASS.

The current registered truth/source checks require no further edits to the inherited maps. Source checks establish formatting, registered ownership/path facts and anchors; they do not qualify runtime behavior. No exact-candidate source receipt was forged from a dirty HEAD: checks and manifests explicitly identify the composed tree.

## Native gate status remains HOLD

**No Cargo command was issued for this composed tree.** Agentd/infer typechecking, Clippy, current-owner/PQ selector installation and the three-generation no-update native entry are NOT RUN / BLOCKED_RESOURCE.

The historical218PASS belongs only to tree285b7510cf7f247b84a4c55fa349af77810a3b4b. The final218 request on the old sealed7ad4 tree was rejected by its disk guard before Cargo started. Neither result is promoted to this composed tree. Prior thirteen fixture failures and all original dependency/resource failures remain available.

Cargo manifests, lockfiles, profiles, compiler pin, build configuration and resource guards were not relaxed. `FINAL_COMPOSED_HANDOFF.json` records current guard-file and tool hashes, and identifies which recovery guard files changed in the legitimate remote advance.

`remote_ready=true` authorizes only publication of this concrete reviewable candidate to existing PR4812 as DRAFT/HOLD, after a fresh CAS check of the primary head. It grants no native qualification, merge to main, release or production activation.
