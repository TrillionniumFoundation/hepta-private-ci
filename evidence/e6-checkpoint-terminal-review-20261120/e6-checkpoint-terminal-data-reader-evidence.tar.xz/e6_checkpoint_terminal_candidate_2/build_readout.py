#!/usr/bin/env python3
"""Record source identities and candidate deltas; never run Rust or host work."""

from pathlib import Path
import difflib
import hashlib
import json
import re


ROOT = Path(__file__).resolve().parent
AUDIT = ROOT.parent / "e6_checkpoint_terminal_contract_review"
PREVIOUS = ROOT.parent / "e6_checkpoint_terminal_candidate_1"
COMMIT = "bfea526e1cb9a2da718d835cd617e87c67181fe9"
TREE = "e047b5fc72284e25a98c0ebb4f2e69a2f6338e56"


def digest(path):
    data = path.read_bytes()
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob": hashlib.sha1(
            b"blob " + str(len(data)).encode() + b"\0" + data
        ).hexdigest(),
    }


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def source_anchor(path, start, end, purpose):
    source = AUDIT / "source" / path
    lines = source.read_text().splitlines()
    assert 1 <= start <= end <= len(lines)
    return {
        "source_commit": COMMIT,
        "path": path,
        "start_line": start,
        "end_line": end,
        "purpose": purpose,
        **digest(source),
        "excerpt": "\n".join(lines[start - 1 : end]),
    }


agentd = "codex-rs/hepta-agentd/src/"
artifacts = "codex-rs/hepta-learning-artifacts/src/"
anchor_specs = [
    (agentd + "learning_iteration_checkpoint_codec.rs", 14, 46, "Codec capacity and headers"),
    (agentd + "learning_iteration_checkpoint_codec.rs", 297, 310, "Bounded count decoding"),
    (agentd + "learning_iteration_checkpoint_codec.rs", 405, 421, "Complete decode and semantic replay"),
    (agentd + "learning_iteration_checkpoint.rs", 258, 278, "Existing write capacity and replay"),
    (agentd + "learning_iteration_checkpoint.rs", 348, 377, "Original completed DATA API"),
    (agentd + "learning_iteration_checkpoint.rs", 379, 424, "Exact scope, bytes, and outer predecessor"),
    (artifacts + "learning_iteration.rs", 114, 132, "Full snapshot replay and equality"),
    (artifacts + "learning_iteration.rs", 138, 179, "Completed disposition"),
    (artifacts + "learning_iteration.rs", 182, 223, "Actual stage graph"),
    (artifacts + "learning_iteration.rs", 225, 266, "Candidate versus retained selection"),
    (artifacts + "learning_iteration.rs", 282, 328, "Receipt owner, chain, timestamp, evidence"),
    (artifacts + "learning_iteration.rs", 429, 499, "Local choice, Selection, and actual next use"),
    (artifacts + "learning_iteration_types.rs", 239, 270, "Stage aliases and independent owners"),
    (artifacts + "learning_iteration_scope.rs", 71, 141, "Frozen request and component boundaries"),
    (artifacts + "learning_iteration_digest.rs", 62, 86, "Exact receipt head uses canonical payload"),
    (artifacts + "learning_iteration_tests.rs", 99, 182, "Existing complete evaluated and proposed NoUpdate tests"),
    (artifacts + "learning_iteration_training_no_update_tests.rs", 56, 166, "Existing five-receipt terminal core test"),
    (artifacts + "learning_iteration_local_decision_tests.rs", 50, 123, "Existing three LocalDecision outcomes"),
    (agentd + "learning_iteration_checkpoint_tests.rs", 25, 55, "Existing bounded persistence controls"),
    (agentd + "learning_iteration_checkpoint_profile_tests.rs", 137, 175, "Existing complete retained-model reopening tests"),
    (agentd + "ordinary_q24_post_a_process_tests.rs", 19, 35, "Ignored physical Adopt and EvaluatedNoUpdate entry points"),
    (agentd + "ordinary_q24_post_a_process_tests.rs", 143, 162, "Original actual Root acceptance wait"),
    (agentd + "ordinary_q24_cold_process_tests.rs", 19, 49, "Ignored cold paths first require complete original acceptance"),
]
anchors = [source_anchor(*spec) for spec in anchor_specs]
write_json(ROOT / "SOURCE_ANCHORS.json", anchors)

product_rel = agentd + "learning_iteration_checkpoint.rs"
before = (ROOT / "baseline" / product_rel).read_bytes()
product = (ROOT / "source" / product_rel).read_bytes()
needle = b"            || snapshot.receipts.len() != codec::MAX_RECEIPTS\n"
module = (
    b'\n#[cfg(all(test, target_os = "linux"))]\n'
    b'#[path = "learning_iteration_checkpoint_completed_tests.rs"]\n'
    b"mod completed_tests;\n"
)
assert before.count(needle) == 1
assert product == before.replace(needle, b"") + module
assert product == (PREVIOUS / "source" / product_rel).read_bytes()
assert digest(ROOT / "baseline" / product_rel)["git_blob"] == (
    "419984870420c0f79b842b62b411d4e110a779e9"
)
changes = []
diff = []
for path in sorted((ROOT / "source").rglob("*.rs")):
    relative = path.relative_to(ROOT / "source").as_posix()
    base = ROOT / "baseline" / relative
    old_text = base.read_text() if base.exists() else ""
    new_text = path.read_text()
    changes.append(
        {
            "path": relative,
            "old": digest(base) if base.exists() else None,
            "new": digest(path),
            "lines": len(new_text.splitlines()),
        }
    )
    diff.extend(
        difflib.unified_diff(
            old_text.splitlines(keepends=True),
            new_text.splitlines(keepends=True),
            fromfile="a/" + relative if base.exists() else "/dev/null",
            tofile="b/" + relative,
        )
    )
assert len(changes) == 2
(ROOT / "PRODUCT.diff").write_text("".join(diff))
test_rel = agentd + "learning_iteration_checkpoint_completed_tests.rs"
test_source = (ROOT / "source" / test_rel).read_text()
tests = re.findall(r"#\[test\]\nfn ([a-z0-9_]+)", test_source)
assert len(tests) == 8
(ROOT / "REVISION_2.diff").write_text(
    "".join(
        difflib.unified_diff(
            (PREVIOUS / "source" / test_rel).read_text().splitlines(keepends=True),
            test_source.splitlines(keepends=True),
            fromfile="candidate_1/" + test_rel,
            tofile="candidate_2/" + test_rel,
        )
    )
)
manifest = json.loads((PREVIOUS / "MANIFEST.json").read_text())
manifest["schema"] = "e6-checkpoint-terminal-data-reader-candidate-v2"
manifest["changes"] = changes
manifest["tests"] = tests
manifest["previous_candidate_manifest"] = digest(PREVIOUS / "MANIFEST.json")
manifest["revision_reason"] = (
    "Peer review found possible stale-head masking in generic error assertions. "
    "Require exact Snapshot(ContextMismatch) for four last-observation controls "
    "and WrongOwner/WrongOperation/EmptyEvidence/DeadlineExceeded for four receipt "
    "controls. Do not recompute heads or copy digest implementation; product unchanged."
)
manifest["source_pins"] = {
    "path": str(AUDIT / "SOURCE_PINS.json"),
    **digest(AUDIT / "SOURCE_PINS.json"),
}
manifest["source_anchors"] = digest(ROOT / "SOURCE_ANCHORS.json")
write_json(ROOT / "MANIFEST.json", manifest)
readout = {
    "status": "UNEXECUTED_LOCAL_CANDIDATE",
    "source_commit": COMMIT,
    "source_tree": TREE,
    "finding": "Eight is capacity, not a universal completion count.",
    "route_counts": {
        "TrainingNoUpdate_core_valid_this_purpose_excluded": 5,
        "EvaluationNoUpdate": 6,
        "ProposalNoAdmissibleUpdate": 7,
        "HistoricalUpdateWithoutLocalDecision": 7,
        "LocalAdopt": 8,
        "LocalDefer": 8,
        "LocalRetain": 8,
    },
    "minimum_product_change": "Remove only the len != MAX_RECEIPTS condition.",
    "root_acceptance_claimed": False,
    "outer_fixed_signature_shape_independent_blocker": True,
    "noupdate9_first_cause_replaced": False,
    "unchanged": manifest["unchanged"],
    "execution": manifest["execution"],
    "test_functions_authored": len(tests),
    "test_functions_executed": 0,
    "source_identity_checks_only": manifest["local_static_checks"],
    "manifest": digest(ROOT / "MANIFEST.json"),
    "product_diff": digest(ROOT / "PRODUCT.diff"),
    "revision_2_diff": digest(ROOT / "REVISION_2.diff"),
    "peer_note": manifest["revision_reason"],
}
write_json(ROOT / "READOUT.json", readout)
print(json.dumps({"manifest": digest(ROOT / "MANIFEST.json"), "readout": digest(ROOT / "READOUT.json"), "changes": changes}, indent=2))
