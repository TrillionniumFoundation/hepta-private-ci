#!/usr/bin/env python3
"""Retain the exact audit inputs, both candidates, and preparation diagnostics."""

import hashlib
import io
import json
from pathlib import Path
import tarfile


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
PUBLICATION = ROOT / "publication"
PUBLICATION.mkdir(exist_ok=False)
PREFIXES = [
    "e6_checkpoint_terminal_contract_review",
    "e6_checkpoint_terminal_candidate_1",
    "e6_checkpoint_terminal_candidate_2",
]
members = []
for prefix in PREFIXES:
    for path in sorted((WORKSPACE / prefix).rglob("*")):
        if not path.is_file() or PUBLICATION in path.parents:
            continue
        assert not path.is_symlink()
        data = path.read_bytes()
        members.append(
            {
                "path": path.relative_to(WORKSPACE).as_posix(),
                "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
            }
        )
archive = PUBLICATION / "e6-checkpoint-terminal-data-reader-evidence.tar.xz"
with tarfile.open(archive, "w:xz", format=tarfile.PAX_FORMAT) as output:
    for member in members:
        data = (WORKSPACE / member["path"]).read_bytes()
        assert len(data) == member["bytes"]
        assert hashlib.sha256(data).hexdigest() == member["sha256"]
        info = tarfile.TarInfo(member["path"])
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        output.addfile(info, io.BytesIO(data))
with tarfile.open(archive, "r:xz") as reopened:
    actual = reopened.getmembers()
    assert [entry.name for entry in actual] == [entry["path"] for entry in members]
    for entry, expected in zip(actual, members, strict=True):
        assert entry.isfile()
        data = reopened.extractfile(entry).read()
        assert len(data) == expected["bytes"]
        assert hashlib.sha256(data).hexdigest() == expected["sha256"]
archive_bytes = archive.read_bytes()
assert len(archive_bytes) <= 480000
index = {
    "source_commit": "bfea526e1cb9a2da718d835cd617e87c67181fe9",
    "members": members,
    "member_count": len(members),
    "total_uncompressed_bytes": sum(member["bytes"] for member in members),
    "archive": {
        "path": archive.name,
        "bytes": len(archive_bytes),
        "sha256": hashlib.sha256(archive_bytes).hexdigest(),
    },
    "reopen_verification": "every member name, size and SHA-256 matched",
    "rust_tests_compiles_native_model_calls": 0,
}
(PUBLICATION / "ARCHIVE_INDEX.json").write_text(json.dumps(index, indent=2) + "\n")
for name in ["README.md", "MANIFEST.json", "READOUT.json", "SOURCE_ANCHORS.json", "PRODUCT.diff", "REVISION_2.diff"]:
    (PUBLICATION / name).write_bytes((ROOT / name).read_bytes())
receipt = {
    "archive": index["archive"],
    "member_count": index["member_count"],
    "all_member_sha256_verified_after_reopen": True,
    "total_uncompressed_bytes": index["total_uncompressed_bytes"],
    "files": [
        {
            "path": path.name,
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
        for path in sorted(PUBLICATION.iterdir())
    ],
    "claim": "Evidence archival verification only, not a Rust or native test result.",
}
(PUBLICATION / "PUBLICATION_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
