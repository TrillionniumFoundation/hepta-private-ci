from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys, time, traceback
ROOT=Path('/workspace/scratch/ff41dfc0f7bf/hepta-c-grant-guards-cloud')
OUT=Path('/workspace/scratch/ff41dfc0f7bf/tooling/validation/root-c-grant-d6843116')
HEAD='d6843116131d094c918cf698cbb842938dc0e747'
def git(*args):
 p=subprocess.run(['git',*args],cwd=ROOT,capture_output=True,text=True,check=True);return p.stdout.strip()
assert git('rev-parse','HEAD')==HEAD
assert not git('status','--porcelain')
sys.path.insert(0,str(ROOT/'scripts'))
import verify_hepta_callers as proof
manifest=proof._load_manifest(ROOT/'CALLERS.toml')
rows={row.identifier:row for row in proof._boundary_rows(manifest)}
selected=[name for name in rows if name.startswith('root_c_grant_')]+[
 'q24_successor_original_root_sign','q24_successor_root_signed_finish',
 'q24_publication_original_lane','root_generation_current_original_broker_head',
 'root_generation_connection_live_session','q24_successor_effect_cancellation',
 'root_publication_original_initial_data','root_publication_refusal_uncertain_ack',
 'q24_successor_original_signed_finish']
assert len(selected)==22 and len(set(selected))==22
rust=proof._source_files(ROOT,tuple(manifest['source_roots']))
tracked=list(rust)+list((ROOT/'scripts').glob('*.py'))+list((ROOT/'qa/b4-no-bypass').glob('*.py'))+[ROOT/'CALLERS.toml',ROOT/'.github/blob-size-allowlist.txt']
def hashes():return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in tracked}
before={'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'files':hashes()}
(OUT/'before.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=[sys.executable,'-m','unittest','-v','test_original_c_grant_source_closure','test_original_c_grant_consumer_source_closure','test_publication_refusal_source_closure','test_root_historical_capture_source_closure','test_root_publication_existing_owner_source_closure','test_post_a_c_recovery_source_closure']
start=time.monotonic();p=subprocess.run(cmd,cwd=ROOT/'qa/b4-no-bypass',stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(OUT/'source-qa.log').write_bytes(p.stdout)
qa={'command':cmd,'returncode':p.returncode,'seconds':time.monotonic()-start,'log_sha256':hashlib.sha256(p.stdout).hexdigest()}
print('SOURCE_QA',json.dumps(qa),flush=True)
try:
 protected=proof._verify_protected_files(ROOT,manifest)
 protected_result={'checked':len(protected),'status':'PASS'}
except Exception as exc:protected_result={'status':'FAIL','error':str(exc),'traceback':traceback.format_exc()}
print('PROTECTED',json.dumps(protected_result),flush=True)
index={}
for path in rust:
 raw=path.read_text();index[str(path.relative_to(ROOT))]=proof._strip_cfg_test_items(proof._strip_rust_non_code(raw))
print('INDEXED',len(index),flush=True)
cache={};results=[];ignored=tuple(manifest['ignored_path_fragments']);start=time.monotonic()
for name in selected:
 try:
  result=proof._verify_boundary(ROOT,rows[name],index,ignored,fields_by_receiver_type=cache);results.append({'id':name,'status':'PASS','result':result});print('CALLER',name,'PASS',flush=True)
 except Exception as exc:
  results.append({'id':name,'status':'FAIL','error':str(exc),'traceback':traceback.format_exc()});print('CALLER',name,'FAIL',str(exc),flush=True)
after={'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'files':hashes()}
(OUT/'after.json').write_text(json.dumps(after,indent=2)+'\n')
result={'source_head':HEAD,'source_tree':before['tree'],'source_qa':qa,'protected':protected_result,'rust_file_count':len(index),'callers':results,'caller_seconds':time.monotonic()-start,'source_unchanged':before==after,'git_clean':not git('status','--porcelain'),'native':'not run'}
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print('FINAL',json.dumps({k:v for k,v in result.items() if k!='callers'}),flush=True)
print('CALLER_SUMMARY',sum(x['status']=='PASS' for x in results),len(results),flush=True)
raise SystemExit(0 if qa['returncode']==0 and protected_result['status']=='PASS' and all(x['status']=='PASS' for x in results) and result['source_unchanged'] and result['git_clean'] else 1)
