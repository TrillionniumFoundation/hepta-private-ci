from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time,tomllib,os
root=Path('/workspace/scratch/ff41dfc0f7bf/hepta-historical-read-cloud')
out=Path('/workspace/scratch/ff41dfc0f7bf/local-validation/initial-peer-ready/frozen-4b351b86')
out.mkdir(exist_ok=True)
def snap():
    head=subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=root,text=True).splitlines()
    status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
    paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0')
    h=hashlib.sha256();count=0
    for path in paths:
        if not path:continue
        f=root/path.decode()
        if f.is_file() and (f.suffix in ('.rs','.py','.toml','.yml','.yaml') or path.decode()=='.github/blob-size-allowlist.txt'):
            h.update(path+b'\0'+hashlib.sha256(f.read_bytes()).digest()); count+=1
    return dict(head=head[0],tree=head[1],status=status,source_files=count,source_digest=h.hexdigest())
before=snap();start=time.time()
commands=[]
command=[sys.executable,'-m','unittest','-v','test_initial_peer_ready_source_closure','test_initial_absolute_deadline_source_closure','test_ordinary_initial_q24_source_closure','test_original_cell_physical_source_closure','test_original_run_start_retention_source_closure','test_root_historical_capture_source_closure','test_root_historical_ledger_source_closure','test_post_a_physical_preparation_source_closure']
with (out/'source-qa.log').open('w') as log:
    proc=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONPATH':'qa/b4-no-bypass','PYTHONDONTWRITEBYTECODE':'1'})
commands.append(dict(command=command,exit_code=proc.returncode))
sys.path.insert(0,str(root/'qa/b4-no-bypass'))
import test_historical_task_read_source_closure as route
manifest=tomllib.loads((root/'CALLERS.toml').read_text())
result={}
try:
    boundaries=route.PROOF._boundary_rows(manifest)
    inventory=route.PROOF._verify_privileged_inventory(manifest,boundaries)
    audit=json.loads(Path('/workspace/scratch/ff41dfc0f7bf/local-validation/initial-peer-ready/final-guard-semantic-audit.json').read_text())
    ids={r['id'] for r in audit['new']} | {r['id'] for r in audit['changed']} | {'original_task_data_validate'}
    selected=[row for row in boundaries if row.identifier in ids]
    assert len(selected)==len(ids)
    protected=route.PROOF._verify_protected_files(root,manifest)
    files=route.PROOF._source_files(root,route.PROOF._string_tuple(manifest,'source_roots'))
    index={p.relative_to(root).as_posix():route.PROOF._strip_cfg_test_items(route.PROOF._strip_rust_non_code(p.read_text())) for p in files}
    ignored=route.PROOF._string_tuple(manifest,'ignored_path_fragments')
    fields={}; rows=[]
    for row in selected:
        try:
            receipt=route.PROOF._verify_boundary(root,row,index,ignored,fields_by_receiver_type=fields)
            rows.append(dict(id=row.identifier,status='PASS',receipt=receipt))
        except Exception as exc:
            rows.append(dict(id=row.identifier,status='FAIL',error=f'{type(exc).__name__}: {exc}'))
        (out/'boundary-progress.json').write_text(json.dumps(rows,indent=2)+'\n')
    result=dict(status='PASS' if all(r['status']=='PASS' for r in rows) else 'FAIL',inventory=len(inventory),selected_protected=len(protected),rust_files_scanned=len(files),boundaries=rows)

except Exception as exc:
    result=dict(status='FAIL',error=f'{type(exc).__name__}: {exc}')
after=snap()
record=dict(before=before,after=after,started_utc=datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),duration_seconds=time.time()-start,commands=commands,markers=result,exact_source=before==after and not after['status'],native='NOT_RUN',full_caller='NOT_RUN',whole_protected='PASS' if result.get('status')=='PASS' else 'SEE_RESULT')
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'head':before['head'],'tree':before['tree'],'exact_source':record['exact_source'],'commands':commands,'markers':{k:v for k,v in result.items() if k!='boundaries'},'failures':[r for r in result.get('boundaries',[]) if r['status']!='PASS'],'seconds':record['duration_seconds']},indent=2),flush=True)
sys.exit(0 if proc.returncode==0 and result.get('status')=='PASS' and record['exact_source'] else 1)
