import json,re,tomllib,hashlib
from pathlib import Path
root=Path('/workspace/scratch/ff41dfc0f7bf/hepta-historical-read-cloud')
p=root/'CALLERS.toml'; text=p.read_text(); original=tomllib.loads(text)
A='codex-rs/hepta-agentd/src/'
R=A+'authority_host_generation_initial_runtime.rs'
E=A+'authority_host_initial_enrollment_runtime.rs'
D=A+'authority_host_initial_peer_deployment.rs'
P=A+'authority_host_initial_peer_runtime.rs'
C=A+'root_generation_initial_peer_ready.rs'
I=A+'root_generation_initial_inputs.rs'
W=A+'root_generation_initial_ready_data.rs'
S=A+'authority_host_generation_initial_session.rs'
G=A+'authority_host_generation_initial.rs'
CLI=A+'bin/hepta-authority-host.rs'
changes={}
def patch_boundary(identifier,**fields):
 global text
 pat=r'(?ms)^\[\[boundary\]\]\nid = "'+re.escape(identifier)+r'"\n.*?(?=^\[\[|\Z)'
 m=re.search(pat,text); assert m,identifier
 old=m.group(); new=old
 for k,v in fields.items():
  line=k+' = '+json.dumps(v,ensure_ascii=False)
  found=re.search(r'(?m)^'+k+r' = .*$',new)
  if found:new=new[:found.start()]+line+new[found.end():]
  else:new=new.rstrip()+'\n'+line+'\n\n'
 changes[identifier]={'old':tomllib.loads(old)['boundary'][0],'new':tomllib.loads(new)['boundary'][0]}
 text=text[:m.start()]+new+text[m.end():]
byid={r['id']:r for r in original['boundary']}
def add_callers(identifier,*paths):
 old=byid[identifier]['product_callers']; patch_boundary(identifier,product_callers=old+[x for x in paths if x not in old])
add_callers('root_initial_original_writer_context',D,E)
add_callers('root_generation_connection_live_session',C)
add_callers('root_initial_original_stream',C)
add_callers('root_initial_deployment_original_inputs',D)
add_callers('root_original_peer_absolute_end',A+'authority_host_generation_initial_transport.rs',P)
for identifier in ['root_initial_original_registration','root_initial_run_start_register','root_original_cell_before_initial_ack','root_original_ledger_runtime_registration']:
 assert byid[identifier]['product_callers']==[R]
 patch_boundary(identifier,product_callers=[E])
patch_boundary('root_initial_one_shot_enrollment',definition_markers=['fn register(', 'compare_exchange(ACTIVE, CONSUMED', 'self.sender', '.recv_timeout(end.checked_duration_since(Instant::now())', 'Instant::now() >= end'])
patch_boundary('root_initial_original_connection_until',definition_markers=['fn connect_until(', 'self.connect_original_until(', 'OriginalEnrollment::RegisteredByRoot'],product_callers=[])
# Rewrite only the known source rows; retain every old row and forbid list.
blocks=list(re.finditer(r'(?ms)^\[\[protected_file\]\]\n.*?(?=^\[\[|\Z)',text))
runtime_index=0
for m in reversed(blocks):
 block=m.group(); row=tomllib.loads(block)['protected_file'][0]; before=json.loads(json.dumps(row)); path=row['path']
 if path==S:
  for f in row.get('required_function_order',[]):
   if f['function']=='fn register(':
    f['sequence']=[x.replace('recv_timeout(self.lifetime)', '.recv_timeout(end.checked_duration_since(Instant::now())') for x in f['sequence']]
    f['sequence'].insert(1,'self.original_end.get()')
    f['sequence'].insert(f['sequence'].index('compare_exchange(ACTIVE, CONSUMED'),'Instant::now() >= end')
    f['sequence']+=['Instant::now() >= end','root_start()? != self.process_start_ticks']
 elif path==I:
  for f in row.get('required_function_order',[]):
   if f['function']=='fn connect_until(':
    f['function']='fn connect_original_until('
    at=f['sequence'].index('RootGenerationInitialClient::from_original_initial_stream(')
    f['sequence'].insert(at+1,'RootGenerationInitialClient::from_original_ready_stream(')
 elif path==A+'production_initial_q24.rs':
  for f in row.get('required_function_order',[]):
   f['sequence']=[x.replace('.connect_until(','.connect_ready_until(') for x in f['sequence']]
 elif path==R:
  rules=row.get('required_function_order',[])
  if not rules:continue
  if row['required']:
   # Actual enrollment is now a concrete shared method. Keep both selected
   # dispatch branches and all original shutdown/join/source-capture checks.
   row['required_function_order']=[
    {'function':'fn serve_optional(','sequence':['.original_end','owner_alive(owner, end)?','compare_exchange(PREPARED, ACTIVE','scope.spawn(','InitialEnrollmentContext {','initial.runtime.peer_deployment','context.accept_original(&active)?','peer_ready::register_original_peer(','receiver.try_recv()','context.enroll_original(submission.inputs, end)','try_send(Ok(slot.profile.binding.clone()))','source_capture::serve_optional(','let stream = match ready_stream','Some(stream) => stream','context.accept_original(&active)?','context.peer_policy()?','service.serve_generation_initial(','let result = original()','stopping.store(true','stream.shutdown(Shutdown::Both)','worker','join()']},
    {'function':'fn serve_optional(','sequence':['context.enroll_original(submission.inputs, end)','source_capture::serve_optional(','initial.runtime.source_capture.as_ref()','source_capture::SourceCaptureContext {','slot: &slot','stopping: &stopping','end,','let stream = match ready_stream','service.serve_generation_initial(','let result = original()','stopping.store(true','initial.runtime.phase.store(CLOSED','source.close()','worker','join()']},
    rules[-1],
    {'function':'fn bind(','sequence':['Instant::now() >= end','runtime.original_end.set(end)','validate_runtime_lanes(config)?','validate_lane_paths(&paths, config.peer_gid)?','UnixListener::bind(&runtime.socket)?','metadata.uid() != 0','metadata.gid() != config.peer_gid','listener.set_nonblocking(true)?','Ok(bound)']}
   ]
  elif any('register_initial_run_start_retention(' in x for f in rules for x in f['sequence']):
   row['path']=E
   row['required_function_order']=[{'function':'fn enroll_original(','sequence':['self.require_original_context(end)?','self.service.enroll_generation_initial(','let enrollment_post = self.require_original_context(end)','let slot: RegisteredGenerationInitial = enrolled?','self.service.register_initial_run_start_retention(','Arc::clone(files)','end,','source.register_original_source_cell(context)?','source.register_original_source_ledger(context)?','RegisteredGenerationInitial::require_profile(&slot)?','let post = self.require_original_context(end)','result.and_then(','Ok(run_start) => Ok((slot, run_start))','RegisteredGenerationInitial::fence(&slot)?']}]
  elif any('submission.acknowledgement.try_send(Err(error.to_string()))' in x for f in rules for x in f['sequence']):
   row['required_function_order']=[{'function':'fn serve_optional(','sequence':['context.enroll_original(submission.inputs, end)','stopping.load(Ordering::Acquire)','try_send(Ok(slot.profile.binding.clone()))','RegisteredGenerationInitial::fence(&slot)?','submission.acknowledgement.try_send(Err(error.to_string()))','return Err(error)','source_capture::serve_optional(']}]
  else:
   assert len(rules)==1 and rules[0]['sequence']==['.register_original_source_cell(context)','.and_then(|()| source.register_original_source_ledger(context))','.try_send(Ok(slot.profile.binding.clone()))'], row
   row['path']=E
   row['required_function_order']=[{'function':'fn enroll_original(','sequence':['self.service.enroll_generation_initial(','self.initial.runtime.source_capture.as_ref()','let context = source_capture::SourceCaptureContext {','slot: &slot','stopping: self.stopping','end,','source.register_original_source_cell(context)?','source.register_original_source_ledger(context)?','let post = self.require_original_context(end)','Ok(run_start) => Ok((slot, run_start))']}]
 if row!=before:
  new='[[protected_file]]\n'+''.join(k+' = '+toml(v)+'\n' for k,v in row.items())+'\n' if False else None
  # fields are intentionally kept in original order; use a small inline TOML serializer.
  def val(v):
   if isinstance(v,dict):return '{'+','.join(k+' = '+val(x) for k,x in v.items())+'}'
   if isinstance(v,list):return '['+','.join(val(x) for x in v)+']'
   return json.dumps(v,ensure_ascii=False)
  new='[[protected_file]]\n'+''.join(k+' = '+val(v)+'\n' for k,v in row.items())+'\n'
  text=text[:m.start()]+new+text[m.end():]

def val(v):
 if isinstance(v,dict):return '{'+','.join(k+' = '+val(x) for k,x in v.items())+'}'
 if isinstance(v,list):return '['+','.join(val(x) for x in v)+']'
 return json.dumps(v,ensure_ascii=False)
def block(kind,row):return '[['+kind+']]\n'+''.join(k+' = '+val(v)+'\n' for k,v in row.items())+'\n'
newbounds=[]
def boundary(identifier,symbol,path,markers,callers,receiver=None,pattern=None):
 row={'id':identifier,'symbol':symbol,'definition_path':path,'definition_markers':markers,'product_callers':callers,'caller_markers':[]}
 if receiver:row['receiver_type']=receiver
 if pattern:row['call_pattern']=pattern
 newbounds.append(row)
boundary('root_initial_peer_deployment_attach','PreparedHostAuthoritySession::enable_original_initial_peer_ready',D,['fn enable_original_initial_peer_ready(','Arc::ptr_eq(&initial.phase, &deployment.capability.phase)','self.service.with_initial_publication_context('],[CLI],receiver='PreparedHostAuthoritySession')
boundary('root_initial_peer_fixed_enrollment','RootGenerationInitialDeploymentV1::with_original_peer_enrollment',D,['fn with_original_peer_enrollment<T>(','.compare_exchange(ACTIVE, CONSUMED','let result = action(inputs)'],[P],receiver='RootGenerationInitialDeploymentV1')
boundary('root_initial_peer_runtime_register','register_original_peer',P,['fn register_original_peer(','channel.exchange_with_original_deadline(','context.enroll_original(inputs, request_end)?'],[R],pattern=r'peer_ready\s*::\s*register_original_peer\s*\(')
for ident,method,callers in [('enrollment','enroll_original',[R,P]),('context','require_original_context',[P]),('accept','accept_original',[R]),('peer_policy','peer_policy',[R,P])]:
 boundary('root_initial_runtime_'+ident,'InitialEnrollmentContext::'+method,E,['fn '+method+'('],callers,receiver='InitialEnrollmentContext')
boundary('root_initial_bound_listener','BoundInitial::bind',R,['fn bind(','runtime.original_end.set(end)'],[A+'authority_host_session.rs'],receiver='BoundInitial')
boundary('root_initial_ready_connection','RootGenerationInitialHandoffV1::connect_ready_until',I,['fn connect_ready_until(','OriginalEnrollment::ReadyPeer'],[A+'production_initial_q24.rs'],receiver='RootGenerationInitialHandoffV1')
boundary('root_initial_connection_selected','RootGenerationInitialHandoffV1::connect_original_until',I,['fn connect_original_until(','OriginalPublicationStream::from_stream_until('],[],receiver='RootGenerationInitialHandoffV1')
boundary('root_initial_ready_client','RootGenerationInitialClient::from_original_ready_stream',C,['fn from_original_ready_stream(','client.profile.binding != acknowledged'],[I],pattern=r'(?:\.\s*|[A-Za-z_]\w*\s*::\s*)from_original_ready_stream\s*\(')
for name,callers in [('bootstrap_binding',[S,C]),('request',[C]),('require_request',[P]),('response',[P]),('require_response',[C])]:
 boundary('root_initial_ready_'+name,'ready::'+name,W,['fn '+name+'('],callers,pattern=r'ready\s*::\s*'+name+r'\s*\(')
boundary('root_initial_profile_check','RegisteredGenerationInitial::require_profile',G,['pub(crate) fn require_profile(','actual != self.profile'],[A+'authority_host_generation_initial_enrollment.rs',A+'authority_host_generation_initial_transport.rs',A+'authority_host_historical_source_transport.rs',A+'authority_host_initial_learning_trust_transport.rs',A+'authority_host_run_start_context.rs',A+'authority_host_historical_source_pin.rs',E,P],receiver='RegisteredGenerationInitial')
boundary('root_initial_profile_refusal','RegisteredGenerationInitial::fence',G,['pub(crate) fn fence(','fence_initial_record(&self.profile_store, &self.profile_owner)'],[A+'authority_host_generation_initial_enrollment.rs',A+'authority_host_generation_initial_transport.rs',A+'authority_host_initial_learning_trust_transport.rs',R,E,P],receiver='RegisteredGenerationInitial')
# Confirm the actual definition marker rather than introducing a weaker global substitute.
newbounds[-2]['definition_markers']=['pub(crate) fn require_profile(','self.profile.digest()? != self.profile.binding']
newprotected=[]
forbid=['AllowVerifier','permit_all','AuthorityPosture::ALLOW_ALL','SigningKey','FinalUseAuthority::','open_registered_writer(','HostAuthorityService::open(','NeuronGenerationCurrentOwnerV1::prepare_initial','claim_final_use(']
def protected(path,rules,required=None,forbidden=None):newprotected.append({'path':path,'required':required or [],'forbidden':forbid if forbidden is None else forbidden,'required_function_order':rules})
def rule(fn,seq,top=None):
 r={'function':'fn '+fn,'sequence':seq}
 if top:r['top_level']=top
 return r
protected(D,[rule('enable_original_initial_peer_ready(',['original_root()?','self.initial_publication.as_ref()','initial.peer_deployment.is_some()','Arc::ptr_eq(&initial.phase, &deployment.capability.phase)','Arc::ptr_eq(&initial.original_end, &deployment.capability.original_end)','initial.phase.load(Ordering::Acquire) != PREPARED','initial.deployment != deployment.files.deployment','self.service.with_initial_publication_context(','proof != initial.writer','deployment.files.require_original_initial_files()','peer_deployment = Some(deployment)','Ok(())']),rule('with_original_peer_enrollment<T>(',['original_root()?','let cap = &self.capability','cap.original_end','end > *original','Instant::now() >= end','std::process::id() != cap.root_pid','root_start()? != cap.process_start_ticks','trim() != cap.boot_id','compare_exchange(ACTIVE, CONSUMED','self.files.require_original_initial_files()?','initial_enrollment_inputs(','&self.files.data','cap.consumer_uid','let result = action(inputs)','let post =','self.files.require_original_initial_files()?','file.require_original_file()?','cap.phase.load(Ordering::Acquire) != CONSUMED','Instant::now() >= end','root_start()? != cap.process_start_ticks','let value = result?','post?','Ok(value)'])],forbidden=forbid+['serde_json::from_slice','File::open','capability.register(','.recv_timeout(','MetadataFile::open_metadata('])
protected(E,[rule('require_original_context(',['end > self.end','self.stopping.load(Ordering::Acquire)','owner_alive(self.owner, end)?','self.service.with_initial_publication_context(','proof != self.initial.runtime.writer','owner_alive(self.owner, end)','owner_alive(self.owner, end)']),rule('accept_original(',['self.stopping.load(Ordering::Acquire)','owner_alive(self.owner, self.end)?','self.initial.listener.accept()','verify_pinned_process(','self.config.peer_uid','self.config.peer_gid','self.owner','self.end','active','self.stopping.load(Ordering::Acquire)','Some(stream.try_clone()?)','Ok(Some(stream))']),rule('peer_policy(',['uid: self.config.peer_uid','pid: self.registration.peer_pid','timeout: Duration::from_millis(self.config.timeout_ms)','checked_duration_since(Instant::now())','request_bound: 16 * 1024','response_bound: 16 * 1024'])],required=['service: &\'a HostAuthorityService','owner: &\'a OwnedFd','end: Instant,'])
protected(P,[rule('register_original_peer(',['HostAuthorityPeerChannel::from_stream(','stream.try_clone()?','context.peer_policy()?','context.owner.try_clone()?','HostAuthorityPeerChannel::limit_original_end(&mut channel, context.end)','channel.exchange_with_original_deadline(|bytes, request_end|','ready::require_request(bytes, &context.initial.runtime.ready_binding)?','context.require_original_context(request_end)?','deployment.with_original_peer_enrollment(request_end, |inputs|','context.enroll_original(inputs, request_end)?','let post = context.require_original_context(request_end)','registration?','post?','RegisteredGenerationInitial::require_profile(slot)?','ready::response(','if !matches!(result, Ok(true))','RegisteredGenerationInitial::fence(slot)?','return Err(','drop(channel)','enrolled.ok_or_else('])],forbidden=forbid+['File::open','OpenOptions','serde_json::from_slice','register(inputs)','Instant::now() +'])
protected(C,[rule('from_original_ready_stream(',['connection.require_original_publication_session()?','ready::bootstrap_binding(bootstrap)?','stream.exchange(&ready::request(&binding)?)?','ready::require_response(&response, &binding)?','connection.require_original_publication_session()?','Self::from_original_initial_stream(stream, bootstrap, connection)?','client.profile.binding != acknowledged','return Err(uncertain())','client.connection.require_original_publication_session()?','Ok(client)'])],forbidden=forbid+['File::open','UnixStream::connect','Instant::now()','Duration::','loop {'])
protected(I,[rule('connect_until(',['self.connect_original_until(','OriginalEnrollment::RegisteredByRoot','.await']),rule('connect_ready_until(',['self.connect_original_until(','OriginalEnrollment::ReadyPeer','.await'])])
protected(W,[rule('bootstrap_binding(',['Digest32::of_parts(','serde_json::to_vec(bootstrap)']),rule('request(',['require_digest(binding)?','ReadyRequest {','schema: 1','purpose: PURPOSE.into()','request_id: 1','bootstrap: binding.to_owned()','command: ReadyCommand::Ready {}']),rule('require_request(',['serde_json::from_slice(bytes)','require_digest(binding)?','request.schema != 1','request.purpose != PURPOSE','request.request_id != 1','request.bootstrap != binding','return Err(']),rule('response(',['require_digest(binding)?','require_digest(profile)?','ReadyResponse {','schema: 1','purpose: PURPOSE.into()','request_id: 1','bootstrap: binding.to_owned()','profile: profile.to_owned()']),rule('require_response(',['serde_json::from_slice(bytes)','require_digest(binding)?','require_digest(&response.profile)?','response.schema != 1','response.purpose != PURPOSE','response.request_id != 1','response.bootstrap != binding','return Err(','Ok(response.profile)']),rule('require_digest(',['parse::<Digest32>()','!digest.is_zero() && digest.to_string() == value','return Err('])],required=['#[serde(deny_unknown_fields)]','enum ReadyCommand {','Ready {},','runtime.cell-generation.initial-peer-ready.v1','hepta.root.generation-initial.peer-ready-bootstrap.v1'],forbidden=forbid+['std::fs','RootAuthorityDirectory','pub struct Ready','pub enum Ready'])
protected(A+'authority_host_generation_initial_transport.rs',[rule('serve_generation_initial(',['HostAuthorityPeerChannel::from_stream(','HostAuthorityPeerChannel::limit_original_end(&mut channel, session_end)','OriginalSourceCaptureExchange::new('])])
protected(A+'authority_host_generation_initial_enrollment.rs',[rule('enroll_generation_initial(',['let result = self.with_initial_publication_context(','enrolled_result = Some(enrolled)','if let Err(error) = result','if let Some(enrolled) = &enrolled_result','enrolled.fence()?','return Err(error)','enrolled_result.ok_or_else('])])
protected(CLI,[],required=['--initial-peer-ready','initial_peer_ready && command != "serve-session" && command != "serve-fresh-session"','initial_peer_ready && initial_deployment.is_none()','PreparedHostAuthoritySession::enable_original_initial_peer_ready('],forbidden=['AllowVerifier','permit_all'])
newprotected[-1]['required_order']=[['if option == "--owner-pidfd-stdin"','option == "--initial-peer-ready"','if initial_peer_ready','initial_peer_ready = true','if initial_peer_ready && command !=','let initial_deployment = options','initial_peer_ready && initial_deployment.is_none()','RootGenerationInitialDeploymentFilesV1::open_original_initial_deployment(','prepared.enable_generation_initial(files.deployment().clone())','capability.with_original_initial_deployment(files)?','if initial_peer_ready','PreparedHostAuthoritySession::enable_original_initial_peer_ready(','&mut prepared','deployment,','(None, Some((handoff, offer)))','(Some(deployment), Some((handoff, offer)))','let initial_worker = initial_deployment.map','deployment.wait_and_register_initial(stop_ref)?','prepared.serve_with_ready(ready)']]
newids=[r['id'] for r in newbounds]
assert not (set(newids)&set(byid))
inventory=original['privileged_inventory']['required_boundary_ids']
text=re.sub(r'(?m)^required_boundary_ids = .*$',lambda _: 'required_boundary_ids = '+val(inventory+newids),text,count=1)
text=text.rstrip()+'\n\n# Original same-session peer readiness: fixed Root inputs, no task evidence.\n\n'+''.join(block('boundary',r) for r in newbounds)+''.join(block('protected_file',r) for r in newprotected)
parsed=tomllib.loads(text)
assert len(parsed['boundary'])==len(original['boundary'])+len(newbounds)
assert len(parsed['protected_file'])==len(original['protected_file'])+len(newprotected)
p.write_text(text)
audit={'before_boundaries':len(original['boundary']),'after_boundaries':len(parsed['boundary']),'before_protected':len(original['protected_file']),'after_protected':len(parsed['protected_file']),'changed_boundaries':changes,'new_boundary_ids':newids,'native':False}
(root.parent/'local-validation/initial-peer-ready/guard-semantic-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
allow=root/'.github/blob-size-allowlist.txt'; at=allow.read_text(); digest=hashlib.sha256(p.read_bytes()).hexdigest()
at=re.sub(r'(?m)^([0-9a-f]{64})(\s+CALLERS\.toml.*)$',lambda m:digest+m.group(2),at)
allow.write_text(at)
print(json.dumps({'new_boundaries':len(newbounds),'new_protected':len(newprotected),'sha256':digest}))
