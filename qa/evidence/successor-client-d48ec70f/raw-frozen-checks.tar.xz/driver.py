from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time,tomllib,os
root=Path('/workspace/scratch/ff41dfc0f7bf/hepta-historical-read-cloud')
out=Path('/workspace/scratch/ff41dfc0f7bf/local-validation/successor-client-d48ec70f')
def snap():
    head=subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=root,text=True).splitlines()
    status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
    paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0')
    h=hashlib.sha256();count=0
    for path in paths:
        if not path:continue
        f=root/path.decode()
        if f.is_file() and (f.suffix in ('.rs','.py','.toml','.yml','.yaml') or path.decode()=='.github/blob-size-allowlist.txt'):
            h.update(path+b'\0'+hashlib.sha256(f.read_bytes()).digest()); count+=1
    return dict(head=head[0],tree=head[1],status=status,source_files=count,source_digest=h.hexdigest())
before=snap();start=time.time()
commands=[]
command=[sys.executable,'-m','unittest','-v','test_successor_historical_client_source_closure','test_current_historical_a_recovery_source_closure','test_publication_v2_source_closure','test_successor_root_custody_source_closure']
with (out/'source-qa.log').open('w') as log:
    proc=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONPATH':'qa/b4-no-bypass','PYTHONDONTWRITEBYTECODE':'1'})
commands.append(dict(command=command,exit_code=proc.returncode))
sys.path.insert(0,str(root/'qa/b4-no-bypass'))
import test_historical_task_read_source_closure as route
manifest=tomllib.loads((root/'CALLERS.toml').read_text())
result={}
try:
    boundaries=route.PROOF._boundary_rows(manifest)
    inventory=route.PROOF._verify_privileged_inventory(manifest,boundaries)
    selected=[row for row in boundaries if row.identifier.startswith(('root_successor_','root_current_recovery_intent','root_current_historical')) or row.identifier in ('q24_current_recovery_intent','q24_current_historical_recover','root_generation_current_bound_selection','post_a_historical_feature_completion','learning_original_q24_stage_install_generation')]
    paths={row.definition_path for row in selected}
    protected=route.PROOF._verify_protected_files(root,{'protected_file':[row for row in manifest['protected_file'] if row['path'] in paths]})
    files=route.PROOF._source_files(root,route.PROOF._string_tuple(manifest,'source_roots'))
    index={p.relative_to(root).as_posix():route.PROOF._strip_cfg_test_items(route.PROOF._strip_rust_non_code(p.read_text())) for p in files}
    ignored=route.PROOF._string_tuple(manifest,'ignored_path_fragments')
    fields={}; rows=[]
    for row in selected:
        try:
            receipt=route.PROOF._verify_boundary(root,row,index,ignored,fields_by_receiver_type=fields)
            rows.append(dict(id=row.identifier,status='PASS',receipt=receipt))
        except Exception as exc:
            rows.append(dict(id=row.identifier,status='FAIL',error=f'{type(exc).__name__}: {exc}'))
        (out/'boundary-progress.json').write_text(json.dumps(rows,indent=2)+'\n')
    result=dict(status='PASS' if all(r['status']=='PASS' for r in rows) else 'FAIL',inventory=len(inventory),selected_protected=len(protected),rust_files_scanned=len(files),boundaries=rows)

except Exception as exc:
    result=dict(status='FAIL',error=f'{type(exc).__name__}: {exc}')
after=snap()
record=dict(before=before,after=after,started_utc=datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),duration_seconds=time.time()-start,commands=commands,markers=result,exact_source=before==after and not after['status'],native='NOT_RUN',full_caller='NOT_RUN',whole_protected='NOT_RUN; only affected paths checked')
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
sys.exit(0 if proc.returncode==0 and result.get('status')=='PASS' and record['exact_source'] else 1)
