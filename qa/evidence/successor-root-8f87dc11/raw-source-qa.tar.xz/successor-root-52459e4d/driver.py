from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time,tomllib,os
root=Path('/workspace/scratch/ff41dfc0f7bf/hepta-historical-read-cloud')
out=Path('/workspace/scratch/ff41dfc0f7bf/local-validation/successor-root-52459e4d')
def snap():
    head=subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=root,text=True).splitlines()
    status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
    paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0')
    h=hashlib.sha256();count=0
    for path in paths:
        if not path:continue
        f=root/path.decode()
        if f.is_file() and (f.suffix in ('.rs','.py','.toml','.yml','.yaml') or path.decode()=='.github/blob-size-allowlist.txt'):
            h.update(path+b'\0'+hashlib.sha256(f.read_bytes()).digest()); count+=1
    return dict(head=head[0],tree=head[1],status=status,source_files=count,source_digest=h.hexdigest())
before=snap();start=time.time()
commands=[]
command=[sys.executable,'-m','unittest','-v','test_successor_root_custody_source_closure','test_post_a_publication_source_closure','test_publication_refusal_source_closure','test_root_historical_capture_source_closure','test_original_task_data_source_closure','test_root_publication_existing_owner_source_closure']
with (out/'source-qa.log').open('w') as log:
    proc=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONPATH':'qa/b4-no-bypass','PYTHONDONTWRITEBYTECODE':'1'})
commands.append(dict(command=command,exit_code=proc.returncode))
sys.path.insert(0,str(root/'qa/b4-no-bypass'))
import test_historical_task_read_source_closure as route
manifest=tomllib.loads((root/'CALLERS.toml').read_text())
result={}
try:
    boundaries=route.PROOF._boundary_rows(manifest)
    inventory=route.PROOF._verify_privileged_inventory(manifest,boundaries)
    selected=[row for row in boundaries if row.identifier.startswith('root_successor_')]
    paths={row.definition_path for row in selected}
    paths.update('codex-rs/hepta-agentd/src/'+name for name in ('authority_host_publication_registration.rs','authority_host_generation_publication_transport.rs','authority_host_post_a_publication.rs'))
    protected=route.PROOF._verify_protected_files(root,{'protected_file':[row for row in manifest['protected_file'] if row['path'] in paths]})
    result=dict(status='PASS',inventory=len(inventory),selected_protected=len(protected),selected_boundaries=[row.identifier for row in selected])
except Exception as exc:
    result=dict(status='FAIL',error=f'{type(exc).__name__}: {exc}')
after=snap()
record=dict(before=before,after=after,started_utc=datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),duration_seconds=time.time()-start,commands=commands,markers=result,exact_source=before==after and not after['status'],native='NOT_RUN',full_caller='NOT_RUN',whole_protected='NOT_RUN; client guard migration remains separate')
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
sys.exit(0 if proc.returncode==0 and result.get('status')=='PASS' and record['exact_source'] else 1)
