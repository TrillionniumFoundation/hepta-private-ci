# Actual exposure review: ready for host recheck and publication

The actual old-evidence review is complete. `exposure-review.json` uses the
runner's exact review schema. It resolves the four named roots and all eight
coverage categories within `audited_known_v6_sources_only`. It preserves the
missing full-002 scientific archive and the explicit historical-query limits.
No new model, corpus preparation or final-target access was run by this review.

## Fixed identities

| Item | Bytes | SHA-256 |
| --- | ---: | --- |
| Original r2 census | 133454 | `148cd0e20df9c01daea9316efb0ea06e426e7f55403f9118e2d79fd1bd0ff4db` |
| Final exposure review | 25617 | `89d9a5fd3302b2729fae25b01fb4600e082c25924c0a6288dd2a5bbde783f627` |
| Review checks | 3777 | `a9ad9eb8cf14875f3822a466c173dff05b9c8bd13e0d956f385d182d4cd68fe9` |

The census **object canonical digest** is
`dd25e347d0cd603f8e541e4ea0eda5a29794077e9dc23018399300ee84868295`.
It is deliberately distinct from the original file hash above.

The code source at scan/freeze is
`689c45e1903a6b28dcff6d05c7b732a07511f512`.
Only the reviewed parser changed after source546ec; training, statistics and
sampling remain unchanged. The actual host passed all33 synthetic tests.

The conservative explicitly enumerated source union is **520**:
360 original full-001/full-002 pixels,128 published validation-probe pixels,
8 recovered CI smoke-case pixels and24 forecast validation pixels. The final24
are development exposures: fit/calibration/dev each use4pairs at offsets0/4/8.
They are not new final probes. The whole train/evaluator/validation partitions
remain outside the fixed future/retention cohort in the preparation code.

All36 standalone metadata files and285 archive members are accounted for. The
archive-member split is202 parsed metadata and83 explicitly resolved opaque
members; there is one additional empty standalone stderr. The two original
synthetic owner failures (timeout and altered configuration) remain recorded.
Neither is treated as a successful execution or a new scientific data run.

## 1. Run the unchanged host freeze

Transfer this review packet to a new directory outside the four census roots.
Use the existing actual r2 census file whose raw identity is fixed above. Do not
replace it with a reformatted projection or add files to its scanned roots.

From `/home/qian-qi/work/hepta-architecture-20261025/ndu-science`, run the original
freeze entry point with the installed Python3.12 environment:

```sh
/home/qian-qi/work/hepta-architecture-20261025/ndu-venv/bin/python \
  -m experiments.multimodal_output_portfolio.v6.fresh_factorial.exposure freeze \
  --template experiments/multimodal_output_portfolio/v6/fresh_factorial/template.json \
  --census "$NDU_CENSUS_R2" \
  --attestation "$NDU_REVIEW_PACKET/exposure-review.json" \
  --source-commit 689c45e1903a6b28dcff6d05c7b732a07511f512 \
  --source-owner /home/qian-qi/work/hepta-architecture-20261025/ndu-fresh-evidence-v1 \
  --output /home/qian-qi/work/hepta-architecture-20261025/ndu-fresh-registration-r2
```

`NDU_CENSUS_R2` is the already recorded main-host r2 census path; `NDU_REVIEW_PACKET`
is the newly transferred directory. Root knows these actual paths. The proposed
owner and registration output must both be unused; the freeze implementation
enforces the owner condition and create-only output. If root has already chosen
another unused owner, bind that exact path here before publication.

Freeze performs the real host-path `verify_review` and complete `recheck_census`,
including root inventory, every file/member identity and the complete exposure
union. Local review ran the pure coverage/opaque checks, not a simulated host
filesystem check. Preserve any failed freeze receipt; do not alter the census to
make it pass.

## 2. Publish the resolved protocol and evidence

Copy the resulting protocol byte-for-byte to
`experiments/multimodal_output_portfolio/v6/fresh_factorial/protocol.json` beside
the unchanged implementation. Save the exact census/review and this review
packet in a committed registration/evidence location. Preserve the two old
metadata bundles, source/history proof packets and original CI artifact custody;
the source union must remain reviewable after Actions artifact retention expires.

Stage only these new registration/evidence paths with `git add --sparse` because
this worktree uses sparse checkout. Commit and publish the branch, then verify
the new commit and exact protocol bytes through GitHub. Do not change any of the
40 algorithm/source pins. The protocol's `algorithm_commit` remains689c; the
execution `--source-commit` must be the new published HEAD containing the
protocol. The runner validates the same algorithm bytes at that HEAD.

## 3. Execute the one bounded fresh study

After publication verification, invoke the existing `fresh_factorial.harness`
once with the published protocol, that published HEAD, the exact recorded owner
and a verified MNIST cache. The four compressed dataset files in the old CI
archive match the registered hashes and can supply the cache; preserve their
bytes and record setup cost separately. No old checkpoint is used.

```sh
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 \
  /home/qian-qi/work/hepta-architecture-20261025/ndu-venv/bin/python \
  -m experiments.multimodal_output_portfolio.v6.fresh_factorial.harness \
  --cache "$NDU_VERIFIED_CACHE" \
  --protocol experiments/multimodal_output_portfolio/v6/fresh_factorial/protocol.json \
  --source-commit "$NDU_PUBLISHED_HEAD" \
  --output /home/qian-qi/work/hepta-architecture-20261025/ndu-fresh-evidence-v1
```

The unchanged harness owns preparation,600 observer updates,12000 base updates,
1440 gate updates, append-only20-model sealing,1080-row inference, independent
replay and the one-time final-access ledger. CPU2,1800-second compute,2-GiB
sampled-RSS/child-peak and1-GiB evidence limits remain fixed. Keep setup cost,
failed stages and partial outputs. A failure is a recorded outcome; the protocol
does not permit automatic retries, new owners, changed sources or enlarged
budgets to obtain a preferred result.
