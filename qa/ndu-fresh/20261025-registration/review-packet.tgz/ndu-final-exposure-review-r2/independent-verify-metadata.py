"""Read-only original metadata checks; never imports artifact code or models."""
import copy
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]
DISCOVERY = ROOT / "ndu-actual-discovery"
OUTPUT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def wire_digest(request):
    fields = ("schema", "request_id", "objective_sha256", "input_source_sha256", "model",
              "required_modalities", "pixels_f32", "mask_f32", "text_tokens", "noise_seed",
              "content_control", "actions")
    pins = ("checkpoint_sha256", "snapshot_sha256", "parameters_sha256", "config_sha256",
            "source_sha256", "python_sha256", "device_sha256", "runtime_versions", "hidden")
    assert set(request) == set(fields) and set(request["model"]) == set(pins)
    ordered = {k: ({p: request[k][p] for p in pins} if k == "model" else request[k]) for k in fields}
    return sha(json.dumps(ordered, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode())


def main():
    census_path = DISCOVERY / "exposure-census-r2.json"
    census = read(census_path)
    archive = next(v for k, v in census["archives"].items() if k.endswith(".zip"))
    members = archive["members"]
    metadata = DISCOVERY / "ndu-ci-metadata-review-v1"
    execution_dir = DISCOVERY / "ndu-ci-execution-metadata-review-v1"
    originals = []
    for root, expected, archive_field in ((metadata, 14, "original_zip_sha256"),
                                         (execution_dir, 6, "archive_sha256")):
        manifest = read(root / "manifest.json")
        assert manifest[archive_field] == archive["sha256"]
        assert len(manifest["members"]) == expected
        for item in manifest["members"]:
            actual = identity(root / item["path"])
            assert actual == {k: item[k] for k in ("bytes", "sha256")}
            assert actual == {k: members[item["path"]][k] for k in ("bytes", "sha256")}
            originals.append({"path": item["path"], **actual})

    forecast = read(metadata / "run/forecast.json")
    training = read(metadata / "run/training.json")
    protocol = read(DISCOVERY / "smoke-protocol.json")
    rows_path = DISCOVERY / "rows.jsonl"
    rows = [json.loads(x) for x in rows_path.read_bytes().splitlines()]
    partition_sets = []
    summaries = {}
    for profile in ("seed-17-supervised", "seed-17-terminal_entropic_ndu"):
        item = forecast[profile]
        assert item["source_manifest_sha256"] == protocol["dataset_manifest"]["manifest_sha256"]
        assert item["snapshot_sha256"] == training[profile]["snapshot_sha256"]
        assert item["checkpoint_file_sha256"] == members[f"run/{profile}-forecast.pt"]["sha256"]
        assert training[profile]["checkpoint_file_sha256"] == members[f"run/{profile}.pt"]["sha256"]
        pixels = set()
        parts = []
        for name, offset in (("fit", 0), ("calibration", 4), ("dev", 8)):
            part = item["partitions"][name]
            ids = part["source_ids"]
            hashes = part["pixel_hashes"]
            assert part["pair_offset"] == offset and part["pairs"] == 4
            assert len(ids) == len(hashes) == len(set(ids)) == len(set(hashes)) == 8
            assert [s.rsplit(":", 1)[-1] for s in ids] == hashes
            assert all(s.startswith("mnist:train:") for s in ids)
            assert sha("\n".join(ids).encode()) == part["identity_sha256"]
            assert sha("\n".join(sorted(hashes)).encode()) == part["pixel_set_sha256"]
            assert not pixels.intersection(hashes)
            pixels.update(hashes)
            parts.append({"name": name, "pair_offset": offset, "pairs": 4, "pixels": 8,
                          "identity_sha256": part["identity_sha256"],
                          "pixel_set_sha256": part["pixel_set_sha256"]})
        partition_sets.append(pixels)
        summaries[profile] = parts
    packet = read(DISCOVERY / "census-r2-review-packet.json")
    new_pixels = set(packet["difference_from_failed_v1"]["new_pixels"])
    assert partition_sets[0] == partition_sets[1] == new_pixels and len(new_pixels) == 24

    fixture_paths = {
        "owner-fixture/owner-evidence-UKoayO/execution.json": "owner-fixture/fixture.json",
        "owner-fixture/conditioned/owner-evidence-XskJc0/execution.json": "owner-fixture/conditioned/fixture.json",
        "owner-fixture/controlled/owner-evidence-2ZWeOf/execution.json": "owner-fixture/controlled/fixture.json",
        "trained-owner-fixture/controlled/owner-evidence-Q8teaG/execution.json": "trained-owner-fixture/controlled/fixture.json",
    }
    successful = {}
    for process_path, fixture_path in fixture_paths.items():
        fixture = read(metadata / fixture_path)
        process = read(execution_dir / process_path)
        execution = process["execution"]
        assert process["request_sha256"] == execution["request_sha256"] == wire_digest(fixture["request"])
        assert process["exit_code"] == 0 and process["timed_out"] is False
        assert process["stderr"] == "" and not process["stdout_truncated"] and not process["stderr_truncated"]
        assert json.loads(bytes(process["stdout"])) == execution
        assert execution["model"] == process["model"] == fixture["pins"] == fixture["request"]["model"]
        assert process["authority"] == execution["authority"] == "deny_all"
        checkpoint = str(Path(fixture_path).parent / "base.pt")
        assert fixture["pins"]["checkpoint_sha256"] == members[checkpoint]["sha256"]
        assert sha(bytes(execution["png"])) == execution["png_sha256"]
        assert sha(execution["caption"].encode()) == execution["text_sha256"]
        if process_path.startswith("owner-fixture/"):
            request = fixture["request"]
            expected_bits = [int.from_bytes(struct.pack("<f", i / (28 * 56 - 1)), "little")
                             for i in range(28 * 56)]
            assert request["pixels_f32"] == expected_bits
            assert request["mask_f32"] == [0x3f800000] * (28 * 56)
            raw = b"".join(struct.pack("<I", x) for x in expected_bits)
            assert sha(raw) == request["input_source_sha256"]
        successful[process_path] = process["request_sha256"]

    original_fixture = read(metadata / "owner-fixture/fixture.json")
    timed = read(execution_dir / "owner-fixture/owner-evidence-l2uRJp/execution.json")
    assert timed["request_sha256"] == wire_digest(original_fixture["request"])
    assert timed["model"] == original_fixture["pins"]
    assert timed["timed_out"] is True and timed["execution"] is None
    changed = copy.deepcopy(original_fixture["request"])
    changed["model"]["config_sha256"] = "a" * 64
    rejected = read(execution_dir / "owner-fixture/owner-evidence-t4xsui/execution.json")
    assert rejected["request_sha256"] == wire_digest(changed)
    assert rejected["model"] == changed["model"]
    assert rejected["exit_code"] == 1 and rejected["timed_out"] is False and rejected["execution"] is None
    assert "validate_checkpoint_config" in rejected["stderr"]
    assert "Snapshot/configuration identity mismatch" in rejected["stderr"]

    provenance = read(metadata / "trained-owner-fixture/provenance.json")
    verification = read(metadata / "trained-owner-fixture/verification.v2.json")
    row = provenance["source_row"]
    assert provenance["source_rows_sha256"] == sha(rows_path.read_bytes()) == verification["source_rows_sha256"]
    assert [r for r in rows if r["receipt_sha256"] == provenance["row_receipt_sha256"]] == [row]
    row_copy = dict(row)
    assert row_copy.pop("receipt_sha256") == sha(canonical(row_copy))
    trained_path = "trained-owner-fixture/controlled/owner-evidence-Q8teaG/execution.json"
    trained = read(execution_dir / trained_path)["execution"]
    assert verification["execution_file_sha256"] == identity(execution_dir / trained_path)["sha256"]
    assert trained["model"]["checkpoint_sha256"] == row["snapshot_file_sha256"]
    assert trained["model"]["snapshot_sha256"] == row["snapshot_sha256"]
    assert trained["states"][-1]["backend_state_sha256"] == row["final_state_sha256"]
    assert trained["png_sha256"] == row["output_hashes"]["image"]
    assert trained["text_sha256"] == row["output_hashes"]["text"]
    assert verification["new_scientific_samples"] == 0 and verification["online_native_control"] is False
    assert verification["recorded_actions_replayed"] == row["actions"]
    source_tests = ROOT / "ndu-fresh-freeze-readiness/ci-source-proof/sources/owner_worker_tests.py"
    source_raw = source_tests.read_bytes()
    assert hashlib.sha1(b"blob " + str(len(source_raw)).encode() + b"\0" + source_raw).hexdigest() == "0aa1bd2485a5519ac2053f314bbadacc1896a64b"

    report = {"schema": "hepta.ndu-census-r2.independent-metadata-review.v1",
              "scope": "audited_known_v6_sources_only", "status": "reviewed",
              "census": identity(census_path), "original_zip_sha256": archive["sha256"],
              "metadata_members_verified": originals,
              "forecast_partitions": summaries,
              "additional_24_pixels_exactly_forecast_fit_calibration_dev": True,
              "forecast_pool_from_exact_83b8_source": "validation",
              "successful_original_request_bindings": successful,
              "known_failure_requests": {"timeout_same_synthetic_request": timed["request_sha256"],
                                        "only_config_sha256_changed": rejected["request_sha256"]},
              "synthetic_input_ramps_verified": 3,
              "synthetic_generator_source": {"commit": "83b8a25c842d6ef803e8524f2a556d3eb9d06bd8",
                                             "git_blob": "0aa1bd2485a5519ac2053f314bbadacc1896a64b",
                                             **identity(source_tests)},
              "trained_replay_original_row_verified": row["receipt_sha256"],
              "new_scientific_samples": 0, "artifact_code_executed": False,
              "checkpoint_loaded": False, "dataset_or_model_executed": False,
              "limits": ["520 is an explicit exposure-exclusion union, not all model-training source pixels.",
                         "24 added pixels were offline fit/calibration/dev sources, not additional final probe cases.",
                         "Original binary journals and weights are classified by bound metadata; they were not deserialized or executed.",
                         "Historical full002 weights are still not recovered.",
                         "This review does not prove absence of arbitrary unknown runs or grant production authority."]}
    out = OUTPUT / "metadata-review.json"
    out.write_bytes(json.dumps(report, sort_keys=True, indent=2).encode() + b"\n")
    print(json.dumps({"status": "passed", "original_metadata_members": len(originals),
                      "forecast_new_pixels": len(new_pixels), "successful_executions": len(successful),
                      "known_failed_requests": 2, "report": identity(out)}, sort_keys=True))


if __name__ == "__main__":
    main()
