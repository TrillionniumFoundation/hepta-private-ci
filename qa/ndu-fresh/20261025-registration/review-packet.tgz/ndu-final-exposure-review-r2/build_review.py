"""Review exact old metadata; no model, corpus loading, or new-source access."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
ACTUAL = ROOT / "ndu-actual-discovery"
META = ACTUAL / "ndu-ci-metadata-review-v1"
EXEC = ACTUAL / "ndu-ci-execution-metadata-review-v1"
sys.path.insert(0, str(ROOT / "ndu-exposure-parser-r2/candidate"))
from experiments.multimodal_output_portfolio.v6.fresh_factorial import census as census_api
from experiments.multimodal_output_portfolio.v6.fresh_factorial import exposure, published


def read(path):
    return json.loads(Path(path).read_bytes())


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = Path(path).read_bytes()
    return {"sha256": sha(raw), "bytes": len(raw)}


def save(name, value):
    raw = canonical(value) + b"\n"
    with (OUT / name).open("xb") as stream:
        stream.write(raw)
    return {"sha256": sha(raw), "bytes": len(raw)}


c = read(ACTUAL / "exposure-census-r2.json")
assert identity(ACTUAL / "exposure-census-r2.json") == {
    "sha256": "148cd0e20df9c01daea9316efb0ea06e426e7f55403f9118e2d79fd1bd0ff4db", "bytes": 133454}
assert sha(canonical(c)) == "dd25e347d0cd603f8e541e4ea0eda5a29794077e9dc23018399300ee84868295"
assert c["source"]["git_commit"] == "689c45e1903a6b28dcff6d05c7b732a07511f512"
assert c["scan_errors"] == [] and c["ready_for_review"] is True
assert c["excluded_directories"] == {} and len(c["files"]) == 36
old = read(ACTUAL / "exposure-census-v1.json")
assert c["roots"] == old["roots"] and c["files"] == old["files"]
changed = {k for k, v in c["source"]["files"].items() if old["source"]["files"].get(k) != v}
assert changed == {"exposure.py"}
assert c["source"]["files"]["exposure.py"] == "591a7b5955ae8f66fa8a241a4bec3866d7603397c25ad26fe3289ee16f692489"
archive = next(k for k in c["archives"] if k.endswith(".zip"))
members = c["archives"][archive]["members"]
assert len(members) == 218 and sum(v["parsed_metadata"] for v in members.values()) == 135

bound_metadata = {}
for directory in (META, EXEC):
    for path in sorted(directory.rglob("*")):
        if not path.is_file() or path.name == "manifest.json":
            continue
        name = str(path.relative_to(directory))
        actual = identity(path)
        assert actual == {k: members[name][k] for k in ("bytes", "sha256")}
        bound_metadata[name] = actual
assert len(bound_metadata) == 20

p = read(ACTUAL / "smoke-protocol.json")
rows_raw = (ACTUAL / "rows.jsonl").read_bytes()
rows = [json.loads(line) for line in rows_raw.splitlines()]
rowmap = {row["receipt_sha256"]: row for row in rows}
assert len(rowmap) == 56
output_paths = set()
for row in rows:
    for kind, path in row["output_paths"].items():
        name = "run/" + path
        assert members[name]["sha256"] == row["output_hashes"][kind]
        output_paths.add(name)
    label = f"seed-{row['seed']}-{row['training']}"
    for name, key in ((label + ".pt", "snapshot_file_sha256"),
                      (label + "-forecast.pt", "forecast_file_sha256"),
                      ("reward-observer.pt", "reward_observer_sha256"),
                      ("audit-observer.pt", "observer_sha256")):
        assert members["run/" + name]["sha256"] == row[key]
assert len(output_paths) == 112
for source in p["dataset_manifest"]["source_files"]:
    assert {k: members["mnist/" + source["name"]][k] for k in ("bytes", "sha256")} == {
        k: source[k] for k in ("bytes", "sha256")}

forecast = read(META / "run/forecast.json")
partitions, forecast_pixels = None, set()
for label, report in forecast.items():
    assert report["schema"] == "hepta.ndu-v6.heteroskedastic-forecast-evidence.v1"
    assert report["profile"]["kind"] == p["forecast_distribution"] == "heteroskedastic_terminal_v1"
    assert report["source_manifest_sha256"] == p["dataset_manifest"]["manifest_sha256"]
    assert report["checkpoint_file_sha256"] == members["run/" + label + "-forecast.pt"]["sha256"]
    if partitions is None:
        partitions = report["partitions"]
    else:
        assert partitions == report["partitions"]
for name, offset in (("fit", 0), ("calibration", 4), ("dev", 8)):
    part = partitions[name]
    ids, pixels = part["source_ids"], part["pixel_hashes"]
    assert part["pair_offset"] == offset and part["pairs"] == 4
    assert len(ids) == len(set(ids)) == len(pixels) == len(set(pixels)) == 8
    assert [s.rsplit(":", 1)[1] for s in ids] == pixels
    assert all(s.startswith("mnist:train:") for s in ids)
    assert sha("\n".join(ids).encode()) == part["identity_sha256"]
    assert sha("\n".join(sorted(pixels)).encode()) == part["pixel_set_sha256"]
    assert not forecast_pixels.intersection(pixels)
    forecast_pixels.update(pixels)
assert forecast_pixels == set(c["all_exposed_pixels"]) - set(old["all_exposed_pixels"])
assert len(forecast_pixels) == 24
assert len(set(c["all_exposed_pixels"])) == c["all_exposed_pixel_count"] == 520
for name in ("forecast.py", "distribution_fit.py"):
    raw = (ROOT / "ndu-census-r2-independent-review/pinned-source" / name).read_bytes()
    assert sha(raw) == p["source"]["files"]["experiments/multimodal_output_portfolio/v6/" + name]
assert exposure.parse_payload((META / "run/forecast.json").read_bytes(), ".json") == forecast_pixels

fixtures = {}
for folder in ("owner-fixture", "owner-fixture/conditioned", "owner-fixture/controlled",
               "trained-owner-fixture/controlled"):
    fixture = read(META / folder / "fixture.json")
    fixtures[folder] = fixture
    assert fixture["pins"] == fixture["request"]["model"]
    assert fixture["pins"]["checkpoint_sha256"] == members[folder + "/base.pt"]["sha256"]
    if folder.startswith("owner-fixture"):
        values = np.linspace(0, 1, 28 * 56, dtype="<f4")
        request = fixture["request"]
        assert request["pixels_f32"] == values.view("<u4").tolist()
        assert request["input_source_sha256"] == sha(values.tobytes())
        assert request["mask_f32"] == [0x3f800000] * (28 * 56)
        assert request["text_tokens"] == [1, 9, 12, 14, 13, 15, 11, 2]
        assert request["noise_seed"] == 17 and fixture["model_id"] == "v6.fixture"
trained = read(META / "trained-owner-fixture/provenance.json")
verification = read(META / "trained-owner-fixture/verification.v2.json")
target = rowmap[trained["row_receipt_sha256"]]
assert trained["source_row"] == target and trained["source_rows_sha256"] == sha(rows_raw)
assert trained["protocol_sha256"] == sha(canonical(p))
assert verification["original_row_receipt"] == target["receipt_sha256"]
assert verification["new_scientific_samples"] == 0
assert verification["model_file_sha256"] == target["snapshot_file_sha256"]
assert read(META / "trained-owner-fixture/fixture.json") == fixtures["trained-owner-fixture/controlled"]

request_order = list(fixtures["owner-fixture"]["request"])
model_order = list(fixtures["owner-fixture"]["pins"])
journal_bindings = []
for path in sorted(EXEC.rglob("execution.json")):
    relative = path.relative_to(EXEC)
    folder = str(relative.parent.parent)
    evidence_id = relative.parent.name
    execution = read(path)
    request = deepcopy(fixtures[folder]["request"])
    if evidence_id == "owner-evidence-t4xsui":
        request["model"]["config_sha256"] = "a" * 64
        assert execution["exit_code"] == 1 and execution["execution"] is None
        assert "Snapshot/configuration identity mismatch" in execution["stderr"]
    elif evidence_id == "owner-evidence-l2uRJp":
        assert execution["timed_out"] is True and execution["execution"] is None
    else:
        assert execution["exit_code"] == 0 and execution["timed_out"] is False
    request = {key: request[key] for key in request_order}
    request["model"] = {key: request["model"][key] for key in model_order}
    wire = json.dumps(request, separators=(",", ":"), allow_nan=False).encode()
    assert sha(wire) == execution["request_sha256"] and request["model"] == execution["model"]
    result = execution["execution"]
    if result is not None:
        assert result["model"] == execution["model"] and result["request_sha256"] == sha(wire)
        assert sha(bytes(result["png"])) == result["png_sha256"]
    journal = str(relative.with_name("inference.journal"))
    assert journal in members and members[journal]["parsed_metadata"] is False
    if folder.startswith("trained-owner"):
        assert identity(path)["sha256"] == verification["execution_file_sha256"]
        assert result["png_sha256"] == target["output_hashes"]["image"]
        assert result["text_sha256"] == target["output_hashes"]["text"]
    journal_bindings.append({"journal": journal, "journal_sha256": members[journal]["sha256"],
        "execution": str(relative), "execution_sha256": identity(path)["sha256"],
        "request_sha256": sha(wire), "fixture": folder + "/fixture.json",
        "exit_code": execution["exit_code"], "timed_out": execution["timed_out"],
        "scope": "same synthetic linspace request" if folder.startswith("owner-fixture") else "exact previously observed smoke row replay"})
assert len(journal_bindings) == 6

terminal = read(META / "terminal-owner/fixture.json")
terminal_evidence = read(META / "terminal-owner/terminal-owner-evidence-HSUJCa/evidence.json")
paired = read(ACTUAL / "paired-fixture.json")
paired_evidence = read(META / "paired-owner/paired-owner-evidence-r6XEXF/evidence.json")
assert json.loads(terminal["protocol_json"]) == json.loads(paired["protocol_json"]) == p
assert terminal_evidence["fixture_sha256"] == members["terminal-owner/fixture.json"]["sha256"]
assert paired_evidence["fixture_sha256"] == members["paired-owner/fixture.json"]["sha256"]
assert terminal_evidence["new_scientific_samples"] == paired_evidence["new_scientific_samples"] == 0
for name, digest in terminal_evidence["source_pins"].items():
    assert members["run/" + name]["sha256"] == digest
for row in terminal_evidence["records"]:
    assert row["source_row_receipt"] in rowmap
assert terminal_evidence["payload_digest"] == members["terminal-owner/terminal-owner-evidence-HSUJCa/candidate.bin"]["sha256"]
assert paired_evidence["original_rows_sha256"] == sha(rows_raw)
assert paired_evidence["original_protocol_sha256"] == sha(canonical(p))
native = (META / "native-binary.sha256").read_text().split()
assert len(native) == 2 and native[0] == p["native_binary_sha256"] == members["ndu-generation-rollout"]["sha256"]
assert "torch" not in sys.modules

archive_ref = lambda member: archive + "!" + member
scope_archive = next(k for k in c["archives"] if k.endswith("ndu-ci-source-scope-proof-v1.tgz"))
history_archive = next(k for k in c["archives"] if k.endswith("ndu-v6-history-proof-v1.tgz"))
groups = census_api.opaque_groups(c)
expected_groups = {".bin": 5, ".gz": 4, ".journal": 6, ".png": 56, ".pt": 10,
                   ".sha256": 1, ".stderr": 1, "<no-suffix>": 1}
assert {k: len(v) for k, v in groups.items()} == expected_groups
reasons = {
    ".bin": ("The five hashed files are the paired owner consumption store and four terminal-owner stores. Their exact sibling evidence binds the already recovered paired/terminal fixtures, original protocol/rows, seven existing terminal row receipts, and the same source pins. The terminal candidate byte hash matches its payload digest. These imports use previously observed smoke outcomes and report zero new scientific samples; their binary stores were not deserialized or treated as independent data runs.",
             [archive_ref(x) for x in ("paired-owner/fixture.json", "paired-owner/paired-owner-evidence-r6XEXF/evidence.json", "terminal-owner/fixture.json", "terminal-owner/terminal-owner-evidence-HSUJCa/evidence.json")]),
    ".gz": ("All four compressed MNIST files have exact SHA256 and byte-length matches to the saved dataset manifest. The unchanged split recipe separates train/evaluator/validation from fresh test/retention pools; prior selected test/retention cases and the reserved smoke windows remain excluded. Loading the public raw corpus is distinguished from prior evaluation/selection use; no universal never-loaded-pixel claim is made.", [archive_ref("run/protocol.json")]),
    ".journal": ("All six hash-inventoried journal paths have byte-verified sibling execution receipts. Reconstructed complete request bytes and model pins match every receipt: three successful synthetic linspace profiles, one timeout of that same synthetic request, one deliberate configuration-hash rejection of that request, and one exact completed smoke-row replay. The six journals record these bounded owners; neither failure implies an unlisted corpus run. Binary journal records were not independently deserialized.", [archive_ref(x["execution"]) for x in journal_bindings] + [scope_archive + "!sources/owner_worker_tests.py", archive_ref("trained-owner-fixture/provenance.json")]),
    ".png": ("Every one of the 56 PNG paths and hashes matches the complete 56-row old smoke record. All paired caption hashes also match, for 112 exact output bindings. Their source identities equal the saved four-case protocol (eight distinct pixels); these output images are not additional independent source samples and were not decoded or rescored.", [archive_ref("run/rows.jsonl"), archive_ref("run/protocol.json")]),
    ".pt": ("The ten model files comprise six old smoke checkpoints bound by every original row and training/forecast/observer metadata, three fixed synthetic fixture initializations with exact linspace requests and checkpoint pins, and one byte-identical copy of the smoke NDU model used for the trained-owner replay. Forecast fitting uses the separately verified 24 validation pixels. No weights were loaded here, and the missing full-002 scientific archive remains unrecovered.", [archive_ref(x) for x in ("run/training.json", "run/forecast.json", "run/observer.json", "run/rows.jsonl", "owner-fixture/fixture.json", "owner-fixture/conditioned/fixture.json", "owner-fixture/controlled/fixture.json", "trained-owner-fixture/provenance.json", "trained-owner-fixture/verification.v2.json")]),
    ".sha256": ("The single 120-byte checksum file was read in full and contains exactly the saved native rollout executable hash and its original runner path. Its checksum matches both the executable member and protocol native_binary_sha256; it contains no dataset or sample identity payload.", [archive_ref("run/protocol.json"), archive_ref("commands/native-build.json")]),
    ".stderr": ("The sole standalone download.stderr is exactly zero bytes with the standard empty SHA256. It has no payload that could contain a source exposure; the corresponding artifact retrieval receipt and full ZIP are bound in this census.", [next(k for k in c["files"] if k.endswith("ndu-ci-smoke-artifact-v1/receipt.json"))]),
    "<no-suffix>": ("The single native rollout executable is hash-identical to protocol native_binary_sha256 and the read checksum receipt. The original clean-tree build and execution command receipts identify its code and fixed smoke invocation. This binary is an implementation artifact; case selection is bound by the recovered protocol and all 56 rows.", [archive_ref("run/protocol.json"), archive_ref("commands/native-build.json"), archive_ref("commands/rollout.json")]),
}
opaque = {suffix: {"file_count": count, "all_source_exposures_covered_by_metadata": True,
                   "reason": reasons[suffix][0], "metadata_evidence": reasons[suffix][1]}
          for suffix, count in expected_groups.items()}
coverage = deepcopy(read(ROOT / "ndu-final-exposure-review/coverage-reasons.json")["coverage"])
for record in coverage.values():
    record["resolved"] = True
coverage["ci_smoke_and_full"]["reason"] += " The complete 218-member smoke archive now parses at source689c45e; its 135 metadata members and83 opaque members are individually inventoried. Actual forecast.json adds24 explicitly recorded validation pixels in disjoint fit/calibration/dev offsets0/4/8, each four pairs, verified against the actual tested source and original dataset manifest. The full conservative enumerated union is520, with no dropped identities."
coverage["terminal_paired_trained_owners"]["reason"] += " Exact current artifact metadata also separates three synthetic linspace checkpoints and five synthetic owner executions (including expected timeout/configuration-rejection cases) from the single trained smoke-row replay. All six complete request digests and checkpoint pins are verified; none is treated as a fresh quality experiment."

discovery = {}
for local, ending in ((ACTUAL / "root-discovery.json", "ndu-root-discovery-v3/root-discovery.json"),
                     (ACTUAL / "smoke-protocol.json", "selected/run/protocol.json"),
                     (ACTUAL / "rows.jsonl", "selected/run/rows.jsonl"),
                     (ACTUAL / "accepted-run.json", "selected/accepted-run.json"),
                     (ACTUAL / "ci-status.json", "selected/ci-status.json"),
                     (ACTUAL / "rollout.json", "selected/commands/rollout.json")):
    name = next(k for k in c["files"] if k.endswith(ending))
    actual = identity(local)
    assert actual == {k: c["files"][name][k] for k in ("bytes", "sha256")}
    discovery[name] = actual
for local in sorted((ACTUAL / "helpers").iterdir()):
    if not local.is_file():
        continue
    name = next(k for k in c["files"] if k.endswith("ndu-root-discovery-v3/helpers/" + local.name))
    actual = identity(local)
    assert actual == {k: c["files"][name][k] for k in ("bytes", "sha256")}
    discovery[name] = actual
assert len(discovery) == 10
archive_reasons = {
    "ndu-v6-smoke-40078201643-1.zip": "The exact recovered CI artifact has218 fully hash-inventoried regular members,135 parsed metadata and83 explicitly resolved opaque members. Its four-case56-row smoke source lineage and forecast24 validation pixels are verified from raw metadata. It is the CI smoke evidence; the full-002 scientific archive remains missing.",
    "ndu-ci-source-scope-proof-v1.tgz": "All18 regular members bind the17 fixed-head test sources and their scope review. The actual tested merge tree equals that fixed head. This supports the executed test entry points and synthetic fixtures within the separate bounded historical execution census.",
    "ndu-exposure-followup-v1.tgz": "All4 regular members are the immutable actual smoke56-row/eight-pixel binding review, four-helper named discovery review, coverage reasons and manifest. Its earlier minimum496 excludes neither the later forecast24 nor any new inventory member; current union520 supersedes that minimum.",
    "ndu-v6-history-proof-v1.tgz": "All45 regular members bind the explicit query limits, ancestry/branch/caller-run census, actual merge and head trees,23 immutable source snapshots and21 command receipts. The stored pending-artifact wording is historical and is closed by separately inspected actual artifact metadata; main discovery limitations remain explicit.",
}
review = {
    "schema": "hepta.ndu-fresh-factorial.exposure-review.v1",
    "census_canonical_sha256": sha(canonical(c)),
    "reviewer": "cell_science: actual old-evidence identity and source-lineage review",
    "all_available_prior_evidence_roots_reviewed": True,
    "reviewed_scope": "Exactly the four census roots,20 pinned published records, bounded v6 GitHub ancestry/branch/caller-job evidence and completed named-host discovery. All285 archive members,36 standalone metadata files and the zero-byte stderr are accounted for. This is audited_known_v6_sources_only; timed-out broad discovery, deleted/inaccessible/unretained or differently named history, unrelated machines and later runs are not claimed exhaustively covered.",
    "source_freshness_scope": "audited_known_v6_sources_only",
    "missing_original_archive_not_recovered": True,
    "unknown_source_exposure_gaps": [],
    "unresolved_manifests": [],
    "published_study_coverage": coverage,
    "root_discovery_evidence": discovery,
    "archive_resolutions": {name: {"archive_sha256": value["sha256"],
        "scanned_member_count": len(value["members"]), "reason": archive_reasons[Path(name).name]}
        for name, value in c["archives"].items()},
    "opaque_suffix_resolutions": opaque,
    "excluded_directory_resolutions": {},
    "explicit_source_identity_union": {"count": 520, "original_full001_full002": 360,
        "published_validation_probe": 128, "actual_ci_smoke_cases": 8,
        "actual_ci_forecast_validation": 24,
        "additional_partition_separation": "The complete training, evaluator and validation pools are outside the fixed future/retention final pool;520 counts explicitly enumerated identities, not every historical training example or every raw corpus byte loaded."},
    "actual_forecast_source_binding": {"member": archive_ref("run/forecast.json"),
        "source_partition": "validation", "pairs": {name: {"offset": part["pair_offset"], "count": part["pairs"]} for name, part in partitions.items()},
        "source_pixel_sha256": sorted(forecast_pixels), "source_recipe_commit": "83b8a25c842d6ef803e8524f2a556d3eb9d06bd8"},
    "journal_lineage": journal_bindings,
    "review_limitations": [
        "No universal unpublished-history or never-loaded-pixel conclusion; no new dataset or new task is claimed.",
        "Four utility helper/log files contain named-branch download/Rust-check history; the branch is not relabelled immutable and the timed-out broad search is not counted complete.",
        "The original full-002 weights archive remains missing; the recovered smoke weights are not replacement full-002 checkpoints.",
        "Opaque journal/store coverage uses byte-bound metadata and known producer/owner lineage; binary journals/stores and model weights were not deserialized by this review.",
        "Root must run the unchanged actual-path identity/inventory recheck, freeze one unused owner, commit and externally verify the resolved protocol before new source preparation or training."],
    "new_model_training_or_new_cohort_access_by_review": False,
}
published.verify_scope_review(review, c["published_v6"])
census_api.verify_opaque_review(c, review)
assert set(review["archive_resolutions"]) == set(c["archives"])
checks = {"schema": "hepta.ndu-fresh.actual-exposure-review-checks.v1",
    "census_original": identity(ACTUAL / "exposure-census-r2.json"),
    "census_canonical_sha256": sha(canonical(c)), "metadata_members_verified": bound_metadata,
    "all_20_metadata_member_identities_match": True, "forecast_new_validation_pixels": 24,
    "forecast_partition_identity_and_pixel_hashes_recomputed": True,
    "raw_source_recipe_hashes_match_actual_protocol": True,
    "row_output_file_hash_bindings": 112, "run_model_file_bindings": 6,
    "synthetic_fixture_bitwise_input_bindings": 3, "exact_owner_request_wire_bindings": 6,
    "owner_execution_outcomes": {"successful": 4, "expected_synthetic_timeout": 1, "expected_synthetic_config_rejection": 1},
    "opaque_suffix_counts": expected_groups, "pure_scope_and_opaque_validators": "passed",
    "host_path_full_verify_review_and_recheck": "root executes before freeze; not simulated locally",
    "torch_imported": False, "new_model_or_corpus_execution": False}
print(json.dumps({"review": save("exposure-review.json", review),
                  "checks": save("review-checks.json", checks)}, indent=2))
