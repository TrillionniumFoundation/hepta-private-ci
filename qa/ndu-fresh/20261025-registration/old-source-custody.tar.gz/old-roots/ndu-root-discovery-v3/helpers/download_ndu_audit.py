import base64
import json
from pathlib import Path
import subprocess
import urllib.parse

REPO = "TrillionniumFoundation/hepta-private-ci"
REF = "codex/utility-ndu-deterministic-closure"
ROOT = Path.home() / "work/ndu997-audit"
ROOT.mkdir(parents=True, exist_ok=True)

def gh(path):
    result = subprocess.run(
        ["gh", "api", path],
        text=True,
        check=True,
        capture_output=True,
    )
    return json.loads(result.stdout)

def fetch_file(path):
    encoded = urllib.parse.quote(path, safe="/")
    data = gh(f"repos/{REPO}/contents/{encoded}?ref={urllib.parse.quote(REF, safe='')}")
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(base64.b64decode(data["content"]))
ref_q = urllib.parse.quote(REF, safe="")
for directory in ["codex-rs/hepta-ndu/src", "codex-rs/hepta-ndu/src/bin"]:
    encoded = urllib.parse.quote(directory, safe="/")
    for item in gh(f"repos/{REPO}/contents/{encoded}?ref={ref_q}"):
        if item["type"] == "file":
            fetch_file(item["path"])

for path in [
    "docs/modules/utility.ndu/IMPLEMENTATION_MAP.json",
    "docs/modules/utility.ndu/TECHNICAL.md",
    "docs/modules/utility.ndu/STATUS.md",
    "docs/readiness/NDU_SYSTEM_EXECUTION.md",
    "docs/learning/NDU_FBSDE_SPEC.md",
    "qualification/module-execution-dossiers/detail/utility.ndu.md",
    ".github/workflows/utility-ndu.yml",
]:
    fetch_file(path)

files = [path for path in ROOT.rglob("*") if path.is_file()]
print(f"downloaded={len(files)} bytes={sum(path.stat().st_size for path in files)}")
