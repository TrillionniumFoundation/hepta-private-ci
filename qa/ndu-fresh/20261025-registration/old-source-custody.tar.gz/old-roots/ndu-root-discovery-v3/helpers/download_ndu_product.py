import base64
import json
from pathlib import Path
import subprocess
import urllib.parse

repo = "TrillionniumFoundation/hepta-private-ci"
ref = "codex/utility-ndu-deterministic-closure"
root = Path.home() / "work/ndu997-product"
paths = [
    "codex-rs/hepta-agentd/src/intelligence_product.rs",
    "codex-rs/hepta-agentd/src/intelligence_product_tests.rs",
    "codex-rs/hepta-agentd/src/lib.rs",
    "codex-rs/hepta-agentd/Cargo.toml",
    "codex-rs/hepta-contracts/src/lib.rs",
    "codex-rs/hepta-contracts/Cargo.toml",
    "codex-rs/hepta-agentd/src/main.rs",
    "codex-rs/hepta-agentd/src/config.rs",
]
root.mkdir(parents=True, exist_ok=True)
for path in paths:
    url = f"repos/{repo}/contents/{urllib.parse.quote(path, safe='/')}?ref={urllib.parse.quote(ref, safe='')}"
    response = subprocess.run(["gh", "api", url], check=True, text=True, capture_output=True)
    data = json.loads(response.stdout)
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(base64.b64decode(data["content"]))
    print(path, target.stat().st_size)
