import base64
import json
from pathlib import Path
import subprocess
import urllib.parse

repo = "TrillionniumFoundation/hepta-private-ci"
ref = "codex/utility-ndu-deterministic-closure"
root = Path.home() / "work/ndu997-edit"
paths = [
    "docs/modules/utility.ndu/IMPLEMENTATION_MAP.json",
    "docs/modules/utility.ndu/TECHNICAL.md",
    "docs/modules/utility.ndu/STATUS.md",
    "docs/readiness/NDU_SYSTEM_EXECUTION.md",
    "qualification/module-execution-dossiers/detail/utility.ndu.md",
]
for path in paths:
    url = f"repos/{repo}/contents/{urllib.parse.quote(path, safe='/')}?ref={urllib.parse.quote(ref, safe='')}"
    response = subprocess.run(["gh", "api", url], check=True, text=True, capture_output=True)
    data = json.loads(response.stdout)
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(base64.b64decode(data["content"]))
    print(path, data["sha"])
