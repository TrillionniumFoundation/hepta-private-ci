#!/usr/bin/env python3
"""Require all eight original race samples in the retained nextest JUnit file."""
import argparse
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

PREFIX = "competing_original_admission_never_coexists_with_a_false_stop"
MODULE = "runtime_process_tests::admission_race_tests::"
REQUIRED = tuple(f"{MODULE}{PREFIX}_case_{index:02d}" for index in range(8))


def inspect(root):
    seen = {name: [] for name in REQUIRED}
    unexpected = []
    for case in root.iter("testcase"):
        name = case.get("name", "")
        if PREFIX not in name:
            continue
        if name not in seen:
            unexpected.append(name)
            continue
        errors = []
        if "automation_effects" not in case.get("classname", ""):
            errors.append("wrong_or_missing_test_binary")
        errors.extend(child.tag for child in case if child.tag in {"failure", "error", "skipped"})
        try:
            elapsed = float(case.attrib["time"])
            if not math.isfinite(elapsed) or elapsed < 0:
                raise ValueError("invalid elapsed")
        except (KeyError, ValueError):
            elapsed = None
            errors.append("missing_or_invalid_elapsed")
        seen[name].append({"elapsed_seconds": elapsed, "errors": errors,
                           "retry_annotations": [child.tag for child in case
                                                 if "rerun" in child.tag.lower() or "flaky" in child.tag.lower()]})
    missing = [name for name, rows in seen.items() if not rows]
    duplicate = [name for name, rows in seen.items() if len(rows) > 1]
    failed = [name for name, rows in seen.items() if any(row["errors"] for row in rows)]
    return {"schema": "hepta-eight-admission-races-junit-census:v1",
            "passed": not (missing or duplicate or failed or unexpected),
            "required_case_count": 8, "observed_unique_cases": sum(bool(rows) for rows in seen.values()),
            "missing": missing, "duplicate": duplicate, "failed": failed, "unexpected": unexpected,
            "cases": seen, "timeout_policy_changed": False,
            "claim": "eight fresh original-owner race cases; not a production latency measurement"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("junit", type=Path)
    args = parser.parse_args()
    report = inspect(ET.parse(args.junit).getroot())
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
