"""Offline verification of retained native controller-crash canary evidence."""
import collections
from decimal import Decimal
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

ROOT = Path(__file__).resolve().parents[1]
PACKET = ROOT / "runtime-controller-crash-v2-raw-review"
OWNER = PACKET / "owner"
OUTPUT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}


def remote_path(path, remote_owner):
    return OWNER / PurePosixPath(path).relative_to(remote_owner)


def main():
    archive = ROOT / "runtime-controller-crash-v2-raw-review.tgz"
    assert identity(archive) == {"bytes": 46869,
                               "sha256": "b3e521ade6dd4aa3695856fb3fa84332a32d2be54559762fd6c6d580e2ea0522"}
    archived = {}
    with tarfile.open(archive, "r:gz") as tar:
        for member in tar.getmembers():
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and ".." not in path.parts
            assert path.parts[0] == PACKET.name and (member.isdir() or member.isfile())
            if member.isfile():
                assert member.name not in archived
                raw = tar.extractfile(member).read()
                assert raw == (ROOT / member.name).read_bytes()
                archived[member.name] = member
    assert len(archived) == 110
    assert {str(p.relative_to(ROOT)) for p in PACKET.rglob("*") if p.is_file()} == set(archived)
    report_path = OWNER / "report.json"
    assert identity(report_path) == {"bytes": 107194,
                                   "sha256": "24a08a193a31cf295f822d07c007cbf352054cb44998da59b9c2c4b8234ff8df"}
    report = read(report_path)
    assert report["passed"] is True and len(report["cases"]) == 2
    assert report["post_crash_start_api_invocations"] == 0
    for key in ("automatic_retry", "production_finaluse_qualified", "host_reboot_qualified",
                "shadow_intent_execution", "services_changed"):
        assert report[key] is False

    receipt_root = PACKET / "receipts"
    build_path = receipt_root / "runtime-canary-reconciliation-v1-build-reconciliation.json"
    build = read(build_path)
    assert {k: report["build_evidence"][k] for k in ("bytes", "sha256")} == identity(build_path)
    assert report["binary"] == build["driver"]["path"] == build["artifact"]["executable"]
    assert report["binary_sha256"] == build["driver"]["sha256"]
    assert build["artifact"]["fresh"] is False and build["cargo_build_finished_success"] is True
    assert build["source_before_equals_scoped_after"] is True
    assert build["original_wrapper_exit_code"] == 1 and build["original_failure_retained"] is True
    assert build["overall_runtime_qualification"] is False
    assert build["custody"]["runtime_source_edits_during_build"] is False
    snapshot = report["source_snapshot"]
    assert snapshot["head"] == "d4d48189d03b8ff8dfe8d82652b749fb44cd9d50"
    inputs = json.dumps(snapshot["inputs"], sort_keys=True, separators=(",", ":")).encode()
    assert sha(inputs) == snapshot["inputs_sha256"] == build["source_inputs_sha256"]
    source_rows = {row["path"]: row for row in snapshot["inputs"]}
    candidate = ROOT / "runtime-native-lookup-patch/candidate"
    native_source_files = []
    for path in candidate.rglob("*"):
        if path.is_file():
            relative = path.relative_to(candidate).as_posix()
            assert source_rows[relative]["sha256"] == identity(path)["sha256"]
            native_source_files.append(relative)
    manifest = read(receipt_root / "runtime-real-canary-manifest.json")
    manifest_files = {r["path"]: r for r in manifest["files"]}
    harness_sources = {
        "run.py": ROOT / "runtime-real-canary-operator-owner-v1/candidate/run.py",
        "control.py": ROOT / "runtime-real-canary-operator-owner-v1/candidate/control.py",
        "evidence.py": ROOT / "runtime-real-canary-snapshot-scope-v1/candidate/evidence.py",
        "worker.py": ROOT / "runtime-real-canary/worker.py",
    }
    for name, path in harness_sources.items():
        pin = identity(path)
        assert report["canary_inputs"][name] == pin["sha256"] == manifest_files[name]["sha256"]
        assert manifest_files[name]["bytes"] == pin["bytes"]
    assert identity(OWNER / "work/worker.py") == identity(harness_sources["worker.py"])

    remote_owner = PurePosixPath(report["root"])
    events = report["events"]
    assert len(events) == 22
    assert {p.name for p in (OWNER / "requests").iterdir()} == {f"{i:03}.json" for i in range(1, 23)}
    parsed = []
    for ordinal, event in enumerate(events, 1):
        request = OWNER / "requests" / f"{ordinal:03}.json"
        stdout = OWNER / "controllers" / f"{ordinal:03}.stdout"
        stderr = OWNER / "controllers" / f"{ordinal:03}.stderr"
        assert event["argv"] == [report["binary"], str(remote_owner / "runtime-config.json"),
                                 event["action"], str(remote_owner / "requests" / request.name)]
        assert event["request_sha256"] == identity(request)["sha256"]
        assert remote_path(event["stdout_path"], remote_owner) == stdout
        assert remote_path(event["stderr_path"], remote_owner) == stderr
        assert event["stdout_sha256"] == identity(stdout)["sha256"]
        assert event["stderr_sha256"] == identity(stderr)["sha256"]
        if event["exit"] == 0:
            assert stdout.stat().st_size > 0  # A successful unknown-key reply must be real JSON null.
        value = json.loads(stdout.read_bytes()) if stdout.stat().st_size else None
        parsed.append((event, read(request), value))
    assert not [e for e in events if e["phase"] == "after_fault" and e["action"] in {"start", "start-hold"}]

    audit_path = OWNER / "state/audit/events.jsonl"
    audit = [json.loads(line) for line in audit_path.read_bytes().splitlines()]
    assert len(audit) == 13
    assert collections.Counter(e["action"] for e in audit)["process_start"] == 2
    assert collections.Counter(e["action"] for e in audit)["process_start_reused"] == 1
    summaries = []
    retained_jobs = set()
    registry_mtime_checks = 0
    for case in report["cases"]:
        kind = case["kind"]
        reference = case["recovered_original_reference"]
        job = reference["job_id"]
        retained_jobs.add(job)
        selected = [(e, request, value) for e, request, value in parsed if e["case"] == kind]
        held = [(e, request, value) for e, request, value in selected if e["action"] == "start-hold"]
        assert len(held) == 1
        event, original, diagnostic = held[0]
        kill = case["owned_controller_sigkill"]
        assert event["controller_pid"] == kill["pid"] and event["exit"] == kill["returncode"] == -9
        assert kill["signal"] == 9 and case["controller_killed"] is True
        assert event["diagnostic_read_after_key_recovery"] is True
        assert diagnostic["job"]["id"] == job
        assert original["idempotency_key"] == case["original_idempotency_key"]
        assert event["receipt_consumed_before_fault"] is (kind == "accepted_resume")
        lookups = [(e, request, value) for e, request, value in selected if e["action"] == "lookup"]
        assert len(lookups) == 6 and all(e["phase"] == "after_fault" for e, _, _ in lookups)
        for e, request, value in lookups[:4]:
            assert request == original and value == reference and e["exit"] == 0
            assert e["registry_unchanged"] is True
        changed_event, changed, changed_reply = lookups[4]
        assert changed == {**original, "args": original["args"] + ["different-payload"]}
        assert changed_event["exit"] == 1 and changed_event["expected_binding_refusal"] is True
        assert changed_reply is None
        missing_event, missing, missing_reply = lookups[5]
        assert missing == {**original, "idempotency_key": original["idempotency_key"] + "-never-admitted"}
        assert missing_event["exit"] == 0 and missing_reply is None and missing_event["registry_unchanged"] is True
        assert case["all_recovery_lookups_preserved_registry"] is True
        for row in case["registry_after_fault"]["files"]:
            record = OWNER / "state/jobs" / row["name"]
            assert row["sha256"] == identity(record)["sha256"] and row["size"] == record.stat().st_size
            # tarfile stores a decimal string converted from the source float mtime;
            # allow only its sub-microsecond representation loss, not a rewrite.
            member = archived[str(record.relative_to(ROOT))]
            archived_ns = Decimal(member.pax_headers["mtime"]) * 1_000_000_000
            assert abs(archived_ns - row["mtime_ns"]) < 1000
            registry_mtime_checks += 1
        record = read(OWNER / "state/jobs" / (job + ".json"))
        assert record["idempotency_key"] == original["idempotency_key"] and record["id"] == job
        for key in ("host", "executable", "args", "cwd"):
            assert record[key] == original[key]
        job_root = OWNER / "target/jobs" / job
        original_request = read(job_root / "request.json")
        assert original_request["request_digest"] == record["request_digest"]
        assert original_request["job_id"] == job and original_request["args"] == original["args"]
        assert (job_root / "stdin.bin").read_bytes() == original["stdin"].encode()
        child = read(job_root / "child.json")
        attempts = (OWNER / "work" / (kind + ".attempts")).read_text().splitlines()
        assert attempts == [str(child["pid"])] == case["execution"]["worker_attempt_pids"]
        assert case["execution"]["physical_worker_entries"] == 1
        marker = OWNER / "work" / (kind + ".marker")
        assert marker.read_bytes() == b"one execution\n"
        assert identity(marker)["sha256"] == case["execution"]["sha256"]
        assert child["pid"] != kill["pid"]
        started = read(job_root / "started.json")
        assert started == read(job_root / "owner-intent.json")
        assert case["running_after_actual_controller_death"]["state"] == "running"
        assert case["running_after_actual_controller_death"]["job_id"] == job
        assert started["job_id"] == job and started["launch_nonce"] == original_request["launch_nonce"]
        exit_record = read(job_root / "exit.json")
        witness = read(job_root / "exit.witness.json")
        assert witness["exit_sha256"] == identity(job_root / "exit.json")["sha256"]
        assert witness["job_id"] == exit_record["job_id"] == job
        assert witness["launch_nonce"] == exit_record["launch_nonce"] == started["launch_nonce"]
        terminal = case["terminal"]
        assert {k: terminal[k] for k in exit_record} == exit_record
        assert terminal["terminal_publication_confirmed"] is True and terminal["terminal_publication_protocol"] == 1
        assert terminal["output_complete"] is True and terminal["output_durable"] is True
        assert terminal["automatic_retry"] is False and terminal["timed_out"] is False
        read_results = [value for e, _, value in selected if e["action"] == "read"]
        assert len(read_results) == 1 and read_results[0]["job_id"] == job
        for label in ("stdout", "stderr"):
            raw = (job_root / (label + ".log")).read_bytes()
            part = read_results[0][label]
            assert bytes.fromhex(part["bytes_hex"]) == raw and part["text"].encode() == raw
            assert part["offset"] == 0 and part["next_offset"] == part["size"] == len(raw) and part["eof"] is True
            assert case[label] == {"bytes": len(raw), "sha256": sha(raw)}
            assert terminal["log_bytes"][label] == {"seen": len(raw), "stored": len(raw)}
            assert terminal["log_synced"][label] is True and terminal["log_truncated"][label] is False
            assert terminal["log_errors"][label] is None
        own_audit = [e for e in audit if e["subject"] == job]
        launches = [e for e in own_audit if e["action"].startswith("process_start")]
        assert all(e["at_unix_ms"] * 1_000_000 < kill["at_unix_ns"] for e in launches)
        assert sum(e["action"] == "process_start" for e in own_audit) == 1
        if kind == "accepted_resume":
            assert case["original_pre_fault_start"]["reused"] is False
            repeat = case["pre_fault_same_request_reuse"]
            assert repeat == diagnostic and repeat["reused"] is True and repeat["retried_launch"] is False
            assert case["original_pre_fault_start"]["job"] == repeat["job"] == record
            assert terminal["state"] == "succeeded" and terminal["exit_code"] == 0 and terminal["cancelled"] is False
            assert (job_root / "stdout.log").read_bytes() == b"BEGIN accepted_resume\nEND accepted_resume\n"
        else:
            assert not [e for e, _, _ in selected if e["action"] == "start"]
            ack = case["cancel_ack_not_terminal_proof"]
            assert ack["job_id"] == job and ack["termination_confirmed"] is False and ack["result"] == "stop_requested"
            assert terminal["state"] == "cancelled" and terminal["exit_code"] == -15 and terminal["cancelled"] is True
            cancel = read(job_root / "cancel-request.json")
            assert cancel["job_id"] == job and cancel["launch_nonce"] == started["launch_nonce"]
            assert kill["at_unix_ns"] < cancel["at_unix_ms"] * 1_000_000 <= exit_record["at_unix_ms"] * 1_000_000
            assert (job_root / "stdout.log").read_bytes() == b"BEGIN unread_cancel\n"
        summaries.append({"kind": kind, "original_key": original["idempotency_key"], "job_id": job,
                          "controller_pid": kill["pid"], "controller_exit": -9, "worker_pid": child["pid"],
                          "worker_entries": 1, "original_key_lookup_results": 4,
                          "changed_payload_refused": True, "unknown_key_was_null": True,
                          "state": terminal["state"], "exit_code": terminal["exit_code"],
                          "exit_sha256": witness["exit_sha256"], "stdout": case["stdout"], "stderr": case["stderr"]})
    assert {p.stem for p in (OWNER / "state/jobs").glob("*.json")} == retained_jobs
    result = {
        "schema": "hepta.native-controller-crash.independent-review.v1", "reviewer": "runtime_audit",
        "status": "passed_for_the_two_recorded_isolated_canary_jobs", "archive": identity(archive),
        "report": identity(report_path), "archived_regular_files_byte_verified": len(archived),
        "source_inputs_sha256": snapshot["inputs_sha256"], "native_candidate_files_matched": native_source_files,
        "binary_sha256": report["binary_sha256"], "build_reconciliation": identity(build_path),
        "events_verified": len(events), "audit_records_verified": len(audit),
        "same_job_post_fault_start_invocations": 0, "cases": summaries,
        "registry_final_bytes_match_runtime_snapshots": True,
        "registry_mtime_archive_correspondence_checks": registry_mtime_checks,
        "mtime_evidence_scope": "Exact mtime_ns/inode/hash before-after equality was asserted by the SHA-bound executing harness. Final archive bytes match the recorded snapshots; PAX float mtime loses sub-microsecond precision and is not claimed to independently reproduce original nanoseconds.",
        "lost_reply_evidence_scope": "One controller was actually SIGKILLed after worker entry and before the caller read the start receipt; the pinned harness performs original-key lookup before diagnostic stdout reads. No network-loss or host-reboot claim.",
        "authority_scope": report["execution_environment"], "runtime_full_gate_passed": False,
        "runtime_full_gate_retained": {"passed": 1151, "failed": 3, "ignored": 21},
        "production_finaluse_qualified": False, "host_reboot_qualified": False,
        "remote_tools_called_by_reviewer": False, "artifact_code_executed_by_reviewer": False,
        "limits": ["The executable itself is not in the review archive; its identity is bound to the retained build reconciliation and executing harness receipt.",
                   "This is an isolated same-account operator process test with existing localhost SSH and OS permissions, not a filesystem/network sandbox or production authorization.",
                   "Original full-suite failures and the earlier configuration-rejected canary remain failures; this evidence does not replace them."]}
    path = OUTPUT / "review.json"
    path.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"status": "passed", "case_count": len(summaries), "review": identity(path)}, sort_keys=True))


if __name__ == "__main__":
    main()
