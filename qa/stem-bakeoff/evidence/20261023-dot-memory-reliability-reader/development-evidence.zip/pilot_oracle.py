"""Execute the reviewed development regression and retain actual module identities."""
import atexit, hashlib, json, runpy, sys, resource
from pathlib import Path

@atexit.register
def retain_imports():
    modules = {}
    for name, module in list(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if filename and '/scripts/memory_cell' in filename:
            path = Path(filename).resolve()
            if path.suffix == '.py':
                modules[name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    usage = {}
    for name, who in [('self', resource.RUSAGE_SELF), ('reaped_children', resource.RUSAGE_CHILDREN)]:
        row = resource.getrusage(who)
        usage[name] = {'user_cpu_seconds': row.ru_utime, 'system_cpu_seconds': row.ru_stime, 'max_rss_kib': row.ru_maxrss}
    usage['limit'] = 'Linux rusage max RSS per process class, not simultaneous aggregate process-tree peak; does not include runner.'
    Path('resources.json').write_text(json.dumps(usage, indent=2)+'\n')
    Path('import-identities.json').write_text(json.dumps(modules, indent=2)+'\n')

runpy.run_path(str(Path(__file__).with_name('test_source_admission.py')), run_name='__main__')
