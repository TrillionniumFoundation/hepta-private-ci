"""Saved-byte checks only; never execute archive code or load a model."""
from pathlib import Path
import hashlib,json,tarfile,subprocess,time
P=Path(__file__).resolve().parent
start=time.monotonic()
archive=P/'hepta-typed-cell-lifecycle-20261023.tar.gz'
parts=json.loads((P/'lifecycle_parts.txt').read_text())
assert hashlib.sha256(archive.read_bytes()).hexdigest()==parts['archive_sha256']
remote={x['path']:x['sha'] for x in json.loads((P/'d61-source-gitblobs.json').read_text())}
with tarfile.open(archive) as t:
 def raw(name):return t.extractfile(name).read()
 def j(name):return json.loads(raw(name))
 manifest=j('evidence-manifest.json')['files']
 assert set(t.getnames())==set(manifest)|{'evidence-manifest.json'}
 for name,spec in manifest.items():
  b=raw(name);assert len(b)==spec['bytes'];assert hashlib.sha256(b).hexdigest()==spec['sha256']
 counts={}
 for run,rev in [('001','a26aeb74cf63c7489deb5ece7e2b9a86e5697748'),('002','d61a36e21d1ad6d90614c145455b88c647c430e8')]:
  ident=j('runs/'+run+'/source-identity.json');assert ident['git_head']==rev
  for path,digest in ident['files_sha256'].items():
   full='scripts/'+path;b=raw('sources/'+rev+'/'+full)
   assert hashlib.sha256(b).hexdigest()==digest
   if run=='001':assert b==subprocess.check_output(['git','show',rev+':'+full],cwd=P.parent/'repo')
   else:assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==remote[full]
  counts[rev]=len(ident['files_sha256'])
 assert j('runs/002/source-identity.json')==j('runs/002/source-identity-after.json')
 result=j('runs/002/result.json');assert all(result['engineering_gates'].values());assert all(result['parameter_control_gates'].values())
 facts=j('runs/002/first-source-snapshot.json')['facts'];scores={}
 def score(label,journal,expected):
  rows=journal['rows'];assert len(rows)==len(expected)
  correct=sum(row['text'].strip()==fact['value'] for row,fact in zip(rows,expected))
  assert [correct,len(rows)]==[result['metrics'][label]['correct'],result['metrics'][label]['total']]
  scores[label]=[correct,len(rows)]
 for panel in ['adapter','base','shuffled']:score(panel,j('runs/002/fresh-controls/'+panel+'.journal.json'),facts)
 corrected=[dict(f) for f in facts];corrected[0]['value']='white'
 score('corrected',j('runs/002/corrected-network-read.json')['journal'],corrected)
 remaining=[f for f in corrected if f['entity']!='case_01']
 score('after_withdrawal',j('runs/002/restart-and-outage.json')['rebuilt']['journal'],remaining)
 training=j('runs/002/all-training-receipts.json')
 assert len(training)==4
 assert sum(x['steps'] for x in training)==800
 assert sum(x['input_tokens'] for x in training)==49400
 child=[j(n) for n in manifest if n.startswith('runs/002/') and n.endswith('.stderr.result.json')]
 assert len(child)==14;assert all(x['returncode']==0 and not x['timed_out'] for x in child)
 interrupted=j('runs/001/execution-interruption.json');assert interrupted['exit_code']==137 and not interrupted['complete_result']
 receipt={'archive_sha256':parts['archive_sha256'],'verified_manifest_files':len(manifest),'source_files_byte_verified_against_pinned_git':counts,'source_before_after_identical':True,'reported_engineering_gates':[sum(result['engineering_gates'].values()),len(result['engineering_gates'])],'reported_parameter_control_gates':[sum(result['parameter_control_gates'].values()),len(result['parameter_control_gates'])],'raw_text_scores_recomputed':scores,'training_updates_reconciled':800,'training_input_tokens_reconciled':49400,'successful_model_child_receipts':len(child),'original_a26_interruption_preserved_exit':137,'result_sha256':hashlib.sha256(raw('runs/002/result.json')).hexdigest(),'model_calls':0,'training_updates':0,'archive_code_executed':False,'scope':'Independent saved-byte, raw-score and pinned-source verification; not new execution or independent-host attestation. Engineering gates are retained declared outcomes, not all independently re-executed.','wall_seconds':time.monotonic()-start}
(P/'lifecycle-verification-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
