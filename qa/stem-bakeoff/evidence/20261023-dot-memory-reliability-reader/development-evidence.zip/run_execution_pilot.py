"""Known-development repair execution, not a model or future-task comparison."""
import hashlib, json, os, shutil, subprocess, time
from pathlib import Path

root=Path(__file__).resolve().parents[1]
experiment=root/'execution-pilot'
inputs={name: hashlib.sha256((root/'evidence'/name).read_bytes()).hexdigest() for name in ['network-repair.patch','network-incomplete-repair.patch','test_source_admission.py','pilot_oracle.py','run_execution_pilot.py']}
protocol={'type':'known_development_patch_execution','original_source':'a26aeb74cf63c7489deb5ece7e2b9a86e5697748','repair_source':'62bfc3a','arms':{'nochange':None,'incomplete_repair':'network-incomplete-repair.patch','complete_repair':'network-repair.patch'},'expected_exit_success':{'nochange':False,'incomplete_repair':False,'complete_repair':True},'test_timeout_seconds_per_arm':90,'threads_per_math_runtime':2,'input_sha256':inputs,'gold_patch_known':True,'model_comparison':False,'future_task_claim':False,'created_unix_ns':time.time_ns()}
(experiment/'protocol.json').write_text(json.dumps(protocol,sort_keys=True,indent=2)+'\n')
report=[]
for arm, patch in protocol['arms'].items():
    directory=experiment/arm
    shutil.copytree(experiment/'baseline',directory)
    applied=[]
    if patch:
        for args in [['git','apply','--check',str(root/'evidence'/patch)], ['git','apply',str(root/'evidence'/patch)]]:
            completed=subprocess.run(args,cwd=directory,capture_output=True,text=True,timeout=20)
            applied.append({'args':args,'returncode':completed.returncode,'stdout':completed.stdout,'stderr':completed.stderr})
            if completed.returncode: raise RuntimeError(applied)
    env=dict(os.environ,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONPATH=':'.join(str(p) for p in (directory/'scripts').glob('memory_cell*') if p.is_dir()))
    start=time.monotonic()
    command=[str(root/'.venv/bin/python'),'-B',str(root/'evidence/pilot_oracle.py')]
    completed=subprocess.run(command,cwd=directory,env=env,capture_output=True,text=True,timeout=90)
    (directory/'test.log').write_text(completed.stdout+completed.stderr)
    imports=json.loads((directory/'import-identities.json').read_text())
    assert imports and all(Path(v['path']).is_relative_to(directory) for v in imports.values()),imports
    row={'arm':arm,'apply':applied,'returncode':completed.returncode,'wall_seconds':time.monotonic()-start,'expected_outcome_observed':(completed.returncode==0)==protocol['expected_exit_success'][arm],'actual_research_imports':len(imports),'resources':json.loads((directory/'resources.json').read_text())}
    report.append(row)
    print(json.dumps(row),flush=True)
(experiment/'result.json').write_text(json.dumps({'protocol_sha256':hashlib.sha256((experiment/'protocol.json').read_bytes()).hexdigest(),'rows':report,'all_controls_observed':all(r['expected_outcome_observed'] for r in report),'model_comparison':False,'future_task_claim':False},indent=2)+'\n')
assert all(r['expected_outcome_observed'] for r in report), report
