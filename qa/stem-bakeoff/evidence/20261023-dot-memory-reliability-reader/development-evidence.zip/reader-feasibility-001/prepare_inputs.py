from pathlib import Path
import hashlib,json,subprocess,time,shutil
root=Path(__file__).resolve().parent
repo=root.parent/'repo'
base='a26aeb74cf63c7489deb5ece7e2b9a86e5697748'
for arm in ['baseline','candidate']:
 d=root/arm/'scripts/memory_cell_domain';d.mkdir(parents=True,exist_ok=False)
 for name in ['domain_data.py','test_domain_data.py']:
  b=subprocess.check_output(['git','show',base+':scripts/memory_cell_domain/'+name],cwd=repo)
  (d/name).write_bytes(b)
start=time.perf_counter()
source=(root/'baseline/scripts/memory_cell_domain/domain_data.py').read_text()
issue='''Fix one data-provenance bug in this real repository file. A historical failed CI run can have created_at before registration but updated_at after registration because it was rerun. produce() currently labels that incident prospective when previously_seen=False. The original failure was observed before registration and must not become prospective just because of the late update.
Requirements: use trustworthy failed-run creation time for first observation when present; retain legacy records lacking that timestamp as finite development data, never as prospective. A missing run_attempt is also incomplete first-observation evidence and must not qualify as prospective. Preserve the positive case: a run created after registration with valid attempt metadata and previously_seen=False may retain prospective_at_registration under this existing finite-development schema. previously_seen=True must remain nonprospective. Do not redesign source grouping or change unrelated functionality. Preserve original data source pinning and existing valid legacy roundtrips. This is a development bug repair, not proof of real-world never-before-seen provenance.
Return one JSON object only, with schema {"edits":[{"path":"scripts/memory_cell_domain/domain_data.py","old":"exact existing substring","new":"replacement substring"}]}. Each old substring must occur exactly once in the current file. Use at most 5 edits. No markdown, tests, shell commands, explanations, or complete replacement files. Propose your own minimal code repair; no known patch is supplied.'''
messages=[{'role':'system','content':'You are a careful Python maintenance engineer. Read the bug report and original source. Produce only the requested JSON edits.'},{'role':'user','content':issue+'\n\nOriginal source file: scripts/memory_cell_domain/domain_data.py\n'+source}]
(root/'messages.json').write_text(json.dumps(messages,ensure_ascii=False,indent=2)+'\n')
(root/'retrieval-receipt.json').write_text(json.dumps({'method':'traceback-identified original file, full file context; no learned retrieval or gold patch','source_commit':base,'source_path':'scripts/memory_cell_domain/domain_data.py','source_sha256':hashlib.sha256(source.encode()).hexdigest(),'source_bytes':len(source.encode()),'seconds':time.perf_counter()-start,'model_calls':0,'future_or_gold_patch_access':False},indent=2)+'\n')
