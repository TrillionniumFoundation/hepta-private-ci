from pathlib import Path
import json,time,resource,hashlib,os
root=Path(__file__).resolve().parent
begin=time.monotonic()
import torch
from transformers import AutoTokenizer,AutoModelForCausalLM
torch.set_num_threads(2);torch.set_num_interop_threads(2);torch.manual_seed(19031)
modelpath=root.parent/'assets/qwen2.5-coder-1.5b-instruct'
start=time.monotonic();tok=AutoTokenizer.from_pretrained(modelpath,local_files_only=True,trust_remote_code=False)
messages=json.loads((root/'messages.json').read_text())
ids=tok.apply_chat_template(messages,add_generation_prompt=True,tokenize=True,return_tensors='pt')
assert ids.shape[1]<=6144,ids.shape
(root/'prompt-token-ids.json').write_text(json.dumps(ids[0].tolist()))
(root/'rendered-prompt.txt').write_text(tok.apply_chat_template(messages,add_generation_prompt=True,tokenize=False))
prompt_secs=time.monotonic()-start
start=time.monotonic();model=AutoModelForCausalLM.from_pretrained(modelpath,local_files_only=True,trust_remote_code=False,torch_dtype=torch.bfloat16,low_cpu_mem_usage=True,attn_implementation='sdpa').eval();load_secs=time.monotonic()-start
start=time.monotonic()
with torch.inference_mode():out=model.generate(ids,attention_mask=torch.ones_like(ids),max_new_tokens=1536,do_sample=False,use_cache=True,pad_token_id=tok.eos_token_id)
gen_secs=time.monotonic()-start
new=out[0,ids.shape[1]:].tolist();text=tok.decode(new,skip_special_tokens=True)
(root/'generation.txt').write_text(text);(root/'generation-token-ids.json').write_text(json.dumps(new))
receipt={'model_path':str(modelpath),'dtype':'bfloat16','attention':'sdpa','seed':19031,'greedy':True,'input_tokens':ids.shape[1],'generated_tokens':len(new),'max_new_tokens':1536,'tokenization_and_prompt_seconds':prompt_secs,'load_seconds':load_secs,'generation_seconds':gen_secs,'cold_child_wall_seconds':time.monotonic()-begin,'rusage_self':{'user_cpu_seconds':resource.getrusage(0).ru_utime,'system_cpu_seconds':resource.getrusage(0).ru_stime,'max_rss_kib':resource.getrusage(0).ru_maxrss},'torch_threads':torch.get_num_threads(),'model_parameters':sum(p.numel() for p in model.parameters()),'model_calls':1,'training_updates':0,'output_sha256':hashlib.sha256(text.encode()).hexdigest()}
(root/'generation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
