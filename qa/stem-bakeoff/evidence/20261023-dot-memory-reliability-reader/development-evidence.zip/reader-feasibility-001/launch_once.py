from pathlib import Path
import json,os,time,hashlib,shutil
import psutil
from bounded_stage import run_stage
root=Path(__file__).resolve().parent;python=str(root.parent/'.venv/bin/python')
p=json.loads((root/'protocol.json').read_text())
for n,h in p['input_sha256'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
assert psutil.virtual_memory().available>=6*1024**3
assert shutil.disk_usage(root).free>=10*1024**3
start=time.time();launch={'started_unix':start,'deadline_unix':start+1800,'initial_available_memory_bytes':psutil.virtual_memory().available,'initial_disk_free_bytes':shutil.disk_usage(root).free,'protocol_sha256':hashlib.sha256((root/'protocol.json').read_bytes()).hexdigest()}
with (root/'launch.json').open('x') as f:json.dump(launch,f,indent=2)
env=dict(os.environ,OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',TOKENIZERS_PARALLELISM='false',HF_HUB_DISABLE_XET='1',HF_HUB_DOWNLOAD_TIMEOUT='60',HF_HOME=str(root/'hf-cache'),PYTHONDONTWRITEBYTECODE='1')
# Acquisition is part of the same 30-minute wall budget and cannot be retried here.
a=run_stage('acquire',[python,'-B',str(root/'acquire_reader.py')],root,env,900)
if a['returncode'] or a['stopped_reason']:raise SystemExit(1)
assert sum(x.stat().st_size for x in (root.parent/'assets').rglob('*') if x.is_file())<=5*1024**3
baseline_env=dict(env,PYTHONPATH=str(root/'baseline/scripts/memory_cell_domain')+':'+str(root),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
b=run_stage('baseline-tests',[python,'-B','-m','unittest','test_domain_data.DomainDataTests','test_reader_clock.ClockControls','-v'],root,baseline_env,30)
if b['returncode']!=1 or b['stopped_reason']:raise RuntimeError('baseline not a clean expected failing test run; do not generate')
g=run_stage('reader',[python,'-B',str(root/'generate_once.py')],root,dict(env,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1'),900)
if g['returncode'] or g['stopped_reason']:raise SystemExit(1)
print('GENERATION_RETAINED_FOR_STATIC_REVIEW; no automatic shell execution',flush=True)
