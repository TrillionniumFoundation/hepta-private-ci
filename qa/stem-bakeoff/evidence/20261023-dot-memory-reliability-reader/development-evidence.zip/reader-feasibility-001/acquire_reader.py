from pathlib import Path
import json,hashlib,time,resource,os
from huggingface_hub import snapshot_download
root=Path(__file__).resolve().parent
api=json.loads((root/'model-api.json').read_text());files=[x for x in api['siblings'] if x['rfilename']!='.gitattributes']
start=time.monotonic();output=root.parent/'assets/qwen2.5-coder-1.5b-instruct'
snapshot_download('Qwen/Qwen2.5-Coder-1.5B-Instruct',revision=api['sha'],local_dir=output,allow_patterns=[x['rfilename'] for x in files],max_workers=2,token=False)
rows=[]
for x in files:
 p=output/x['rfilename'];size=p.stat().st_size;assert size==x['size'] and not p.is_symlink()
 actual=hashlib.sha256();pub=hashlib.sha256() if 'lfs' in x else hashlib.sha1()
 if 'lfs' not in x:pub.update(f'blob {size}\0'.encode())
 with p.open('rb') as f:
  while b:=f.read(1024*1024):actual.update(b);pub.update(b)
 expected=x['lfs']['sha256'] if 'lfs' in x else x['blobId']
 assert pub.hexdigest()==expected,x['rfilename']
 rows.append({'file':x['rfilename'],'bytes':size,'sha256':actual.hexdigest(),'publisher_digest':expected})
receipt={'model':'Qwen/Qwen2.5-Coder-1.5B-Instruct','revision':api['sha'],'license':'Apache-2.0','files':rows,'total_bytes':sum(x['bytes'] for x in rows),'seconds':time.monotonic()-start,'rusage_self':{'user_cpu_seconds':resource.getrusage(0).ru_utime,'system_cpu_seconds':resource.getrusage(0).ru_stime,'max_rss_kib':resource.getrusage(0).ru_maxrss},'trust_remote_code':False}
(root/'acquisition.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
