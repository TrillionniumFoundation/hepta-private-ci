"""Bound subprocesses to the one preregistered deadline and process-tree RSS."""
from pathlib import Path
import json,os,subprocess,time,signal,resource,shutil
import psutil
ROOT=Path(__file__).resolve().parent

def run_stage(name,command,cwd,env,seconds):
 protocol=json.loads((ROOT/'protocol.json').read_text());deadline=json.loads((ROOT/'launch.json').read_text())['deadline_unix']
 remaining=min(seconds,deadline-time.time())
 if remaining<=0:raise RuntimeError('frozen total deadline exhausted')
 start=time.monotonic();cpu0=resource.getrusage(resource.RUSAGE_CHILDREN);peak=0;reason=None
 with (ROOT/(name+'.log')).open('w') as log:
  p=subprocess.Popen(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  proc=psutil.Process(p.pid)
  while p.poll() is None:
   try:
    rss=sum(x.memory_info().rss for x in [proc]+proc.children(recursive=True) if x.is_running());peak=max(peak,rss)
   except (psutil.NoSuchProcess,psutil.AccessDenied):pass
   if time.monotonic()-start>remaining:reason='stage_or_total_wall_timeout'
   elif peak>protocol['limits']['process_tree_peak_rss_bytes']:reason='process_tree_rss_limit'
   elif psutil.virtual_memory().available<protocol['limits']['stop_host_available_below_bytes']:reason='host_memory_pressure'
   elif shutil.disk_usage(ROOT).free<10*1024**3:reason='host_disk_pressure'
   if reason:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(0.2)
  rc=p.wait()
 cpu1=resource.getrusage(resource.RUSAGE_CHILDREN)
 result={'name':name,'argv':command,'returncode':rc,'stopped_reason':reason,'wall_seconds':time.monotonic()-start,'peak_sampled_process_tree_rss_bytes':peak,'cpu_user_seconds':cpu1.ru_utime-cpu0.ru_utime,'cpu_system_seconds':cpu1.ru_stime-cpu0.ru_stime,'includes_child_import_cold_start':True,'rss_sample_seconds':0.2}
 (ROOT/(name+'-stage.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);return result
