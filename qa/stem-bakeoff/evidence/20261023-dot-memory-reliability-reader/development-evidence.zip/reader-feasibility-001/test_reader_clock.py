"""Frozen development evaluator. Source-shaped fixtures, not future incidents."""
import json,unittest
from pathlib import Path
from domain_data import canonical,produce,sha
from test_domain_data import DomainDataTests

class ClockControls(unittest.TestCase):
 def case(self,kind):
  original=DomainDataTests();original.setUp();self.addCleanup(original.doCleanups)
  path,manifest=original.fixture()
  for i,entry in enumerate(manifest['cases']):
   f=original.root/entry['fix']['path'];fix=json.loads(f.read_bytes());fix['files'][0]['patch']=f'+independent_fix_{i}'
   f.write_bytes(canonical(fix));entry['fix']['sha256']=sha(f.read_bytes())
  runpath=original.root/manifest['runs']['path'];runs=json.loads(runpath.read_bytes())
  for run in runs:
   run['created_at']=run['updated_at'];run['run_attempt']=1
  old=runs[0]['created_at']
  for run in runs[:2]:
   run['updated_at']='2026-03-01T10:00:00Z'
   if kind!='old_rerun':run['created_at']='2026-03-01T09:00:00Z'
  manifest['cases'][0]['previously_seen']=(kind=='seen')
  if kind=='old_rerun':runs[0]['run_attempt']=2
  if kind=='missing_created':runs[0].pop('created_at')
  if kind=='missing_attempt':runs[0].pop('run_attempt')
  runpath.write_bytes(canonical(runs));manifest['runs']['sha256']=sha(runpath.read_bytes());path.write_bytes(canonical(manifest))
  receipt=produce(path,original.root/'reader-test-output')
  data=json.loads(Path(receipt['dataset']).read_bytes());row=next(c for c in data['cases'] if c['id']=='case-0')
  self.assertEqual(data['status'],'finite_development');self.assertFalse(data['generalization_established'])
  return data,row,old
 def test_old_rerun_is_not_new_observation(self):
  data,row,old=self.case('old_rerun');self.assertFalse(row['prospective_at_registration']);self.assertNotIn('case-0',data['prospective_cases']);self.assertEqual(row['observed_at'],old)
 def test_missing_creation_keeps_legacy_but_not_prospective(self):
  data,row,_=self.case('missing_created');self.assertFalse(row['prospective_at_registration']);self.assertNotIn('case-0',data['prospective_cases'])
 def test_missing_attempt_does_not_qualify(self):
  data,row,_=self.case('missing_attempt');self.assertFalse(row['prospective_at_registration']);self.assertNotIn('case-0',data['prospective_cases'])
 def test_recorded_new_creation_positive_control(self):
  data,row,_=self.case('new');self.assertTrue(row['prospective_at_registration']);self.assertIn('case-0',data['prospective_cases']);self.assertEqual(row['observed_at'],'2026-03-01T09:00:00Z')
 def test_seen_remains_nonprospective(self):
  data,row,_=self.case('seen');self.assertFalse(row['prospective_at_registration']);self.assertNotIn('case-0',data['prospective_cases'])

if __name__=='__main__':unittest.main()
