from pathlib import Path
import json,hashlib,ast,os,time,subprocess
from bounded_stage import run_stage
root=Path(__file__).resolve().parent
assert time.time()<json.loads((root/'launch.json').read_text())['deadline_unix']
with (root/'evaluation-started.json').open('x') as f:json.dump({'started_unix':time.time(),'manual_static_review_required':True},f)
protocol=json.loads((root/'protocol.json').read_text())
for n,h in protocol['input_sha256'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
text=(root/'generation.txt').read_text().strip()
# Only JSON is accepted: no markdown stripping, repair, continuation, or new prompt.
obj=json.loads(text);assert set(obj)=={'edits'} and 1<=len(obj['edits'])<=5
path='scripts/memory_cell_domain/domain_data.py';base=(root/'baseline'/path).read_text();new=base
for e in obj['edits']:
 assert set(e)=={'path','old','new'} and e['path']==path and all(isinstance(e[k],str) for k in e)
 assert e['old'] and e['old']!=e['new'] and len(e['new'].encode())<=16000
 assert new.count(e['old'])==1,'old substring must match exactly once'
 new=new.replace(e['old'],e['new'],1)
a,b=ast.parse(base),ast.parse(new);assert len(a.body)==len(b.body)
for oldnode,newnode in zip(a.body,b.body):
 if isinstance(oldnode,ast.FunctionDef) and oldnode.name=='produce':
  assert isinstance(newnode,ast.FunctionDef) and newnode.name=='produce' and ast.dump(oldnode.args)==ast.dump(newnode.args)
 else:assert ast.dump(oldnode)==ast.dump(newnode),'only produce body may change'
for n in ast.walk(b):
 if isinstance(n,ast.Name):assert n.id not in {'eval','exec','compile','__import__','breakpoint','globals','locals','setattr','delattr'},n.id
p=root/'candidate'/path;assert not p.is_symlink();p.write_text(new)
diff=subprocess.run(['git','diff','--no-index','--',str(root/'baseline'/path),str(p)],capture_output=True,text=True)
(root/'candidate.patch').write_text(diff.stdout)
env=dict(os.environ,OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(root/'candidate/scripts/memory_cell_domain')+':'+str(root),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
r=run_stage('candidate-tests',[str(root.parent/'.venv/bin/python'),'-B','-m','unittest','test_domain_data.DomainDataTests','test_reader_clock.ClockControls','-v'],root,env,30)
result={'development_reader_patch_pass':r['returncode']==0 and r['stopped_reason'] is None,'generated_proposal_count':1,'tests':'6 original data tests +5 frozen clock controls','future_or_model_comparison':False,'total_wall_since_launch_seconds':time.time()-json.loads((root/'launch.json').read_text())['started_unix'],'candidate_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'current_research_checkout_modified':False}
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
