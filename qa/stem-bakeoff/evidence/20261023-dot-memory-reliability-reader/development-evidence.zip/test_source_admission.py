"""Extra source-bound TCP regression, independent of the original test census."""
import json, os
from pathlib import Path
import tempfile, unittest
from memory_service import MemoryService
from network_client import NetworkClient
from network_test_support import ServiceProcess
from network_wire import RemoteError, call
import test_parametric_model as tiny

class SourceAdmissionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        tiny.SourceMemoryCellTests.setUpClass()
        cls.addClassCleanup(tiny.SourceMemoryCellTests.tearDownClass)
        cls.base=tiny.SourceMemoryCellTests.base

    def test_conflicting_source_blocks_direct_worker_before_model(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); key=os.urandom(32); (root/'key').write_bytes(key)
            source=MemoryService(root/'source','alpha')
            source.write('s1','one','color','red')
            source.work_once(self.base,steps=4,rank=2,templates=tiny.TEMPLATES)
            active=source.parameter_binding()['active']
            authority=ServiceProcess(root/'authority','authority',root/'key',source_root=root/'source',scope='alpha')
            worker=None
            try:
                worker=ServiceProcess(root/'worker','worker',root/'key',node_id='a',authority=authority.address,model=self.base)
                client=NetworkClient(authority.address,{'a':worker.address},key)
                client.stage('a',active.directory,active.manifest_sha256,active.scope)
                placement=dict(scope='alpha',cell_id='memory',node_id='a',generation=0,manifest_sha256=active.manifest_sha256,roots=list(active.roots))
                client.publish(placement,None)
                request=dict(op='read',scope='alpha',cell_id='memory',questions=['What is the color of one?'],control='adapter')
                call(worker.address,key,request,timeout=60)
                before=call(worker.address,key,{'op':'status'})['model_callbacks']
                source.write('s2','one','color','blue')
                self.assertEqual(source.read('one','color').status.value,'conflict')
                self.assertIsNone(source.parameter_binding())
                error=None
                try: response=call(worker.address,key,request,timeout=60)
                except RemoteError as caught: error=str(caught)
                after=call(worker.address,key,{'op':'status'})['model_callbacks']
                print(json.dumps(dict(source_status='conflict',binding=None,before=before,after=after,remote_error=error)),flush=True)
                self.assertEqual(after,before,'conflicted source must block direct worker before model callback')
                self.assertIsNotNone(error)
            finally:
                if worker is not None: worker.stop()
                authority.stop()

if __name__=='__main__': unittest.main(verbosity=2)
