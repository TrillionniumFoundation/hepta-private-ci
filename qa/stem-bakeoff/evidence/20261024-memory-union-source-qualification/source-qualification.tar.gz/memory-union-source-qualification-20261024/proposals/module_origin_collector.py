"""UNEXECUTED proposal: classify virtual origins without fabricating file bytes.

This helper is not wired into the already executed driver. It has not been
imported, tested, or validated. The failed driver and original receipts remain
unchanged. Reading a module dictionary avoids triggering module __getattr__.
"""
import hashlib
import os
from pathlib import Path


def collect_module_origins(modules, source_root):
    source_root = Path(source_root).resolve()
    records, unresolved = {}, []
    for name, module in tuple(modules.items()):
        try:
            namespace = vars(module)
            raw = namespace.get('__file__')
        except (TypeError, AttributeError) as error:
            unresolved.append({'module': name, 'reason': 'no_module_dictionary', 'error': str(error)})
            continue
        if raw is None:
            unresolved.append({'module': name, 'reason': 'no_file_attribute'})
            continue
        try:
            path = Path(os.fsdecode(os.fspath(raw)))
        except TypeError:
            unresolved.append({'module': name, 'reason': 'non_path_file_attribute', 'attribute_type': type(raw).__name__})
            continue
        if not path.is_absolute():
            unresolved.append({'module': name, 'reason': 'relative_or_virtual_file_attribute', 'file': str(path)})
            continue
        try:
            path = path.resolve(strict=True)
            if not path.is_file():
                unresolved.append({'module': name, 'reason': 'nonregular_origin', 'file': str(path)})
                continue
            if path.is_relative_to(source_root):
                data = path.read_bytes()
                records[name] = {'path': str(path.relative_to(source_root)), 'bytes': len(data),
                                 'sha256': hashlib.sha256(data).hexdigest()}
        except (OSError, RuntimeError) as error:
            unresolved.append({'module': name, 'reason': 'unavailable_origin', 'file': str(path), 'error': str(error)})
    return {'source_module_origins': records, 'unresolved': unresolved,
            'complete_dynamic_import_attestation': False}
