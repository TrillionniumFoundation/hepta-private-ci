"""Package exact source-subset evidence and an honestly failed post-test collector."""
import ast
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'publication'
PREFIX = 'memory-union-source-qualification-20261024'
TARGET = 'qa/stem-bakeoff/evidence/20261024-memory-union-source-qualification'
UNION = '3906c552223448a01702ac6eb3bc3c38c24cb5ab'
TREE = 'a797406d71b8c425317659116982e7568f3c04f4'
BUDGET = 'bfe77f5cdd04935d8bbfba9199a725ffc48b69e7'
BUDGET_TREE = '602242090763af109ea782b4e6e03980494b4056'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()


def read(relative):
    return json.loads((ROOT / relative).read_bytes())


def main():
    if OUT.exists():
        raise FileExistsError('Never overwrite a publication freeze')
    pins = read('acquisition/python-source-pins.json')
    remote = read('acquisition/remote-tree-subset.json')
    commit = read('acquisition/remote-commit.json')
    assert pins['commit'] == commit['sha'] == UNION
    assert pins['tree'] == remote['tree'] == commit['tree']['sha'] == TREE
    assert not remote['truncated']
    remote_files = {item['path']: item for item in remote['files']}
    before, after = read('execution/source-before.json'), read('execution/source-after.json')
    assert before == after and len(before) == len(pins['files']) == len(remote_files) == 222
    before_files = {item['path']: item for item in before}
    for item in pins['files']:
        data = (ROOT / 'source' / item['path']).read_bytes()
        assert blob(data) == item['git_blob_sha1'] == remote_files[item['path']]['sha'] == before_files[item['path']]['git_blob_sha1']
        assert sha(data) == before_files[item['path']]['sha256']
    completion, launch = read('execution/completion.json'), read('execution/launch.json')
    failure = read('execution/evolution-runner-failure.json')
    local_log = (ROOT / 'execution/evolution.stderr').read_text()
    local_rows = re.findall(r'^(test_[^( ]+) \([^)]+\) \.\.\. (.+)$', local_log, re.MULTILINE)
    expected_names = {name for row in read('acquisition/static-scope-review.json')['files'] for name in row['methods']}
    assert len(local_rows) == 22 and {row[0] for row in local_rows} == expected_names and all(row[1] == 'ok' for row in local_rows)
    assert re.search(r'^Ran 22 tests in 3\.254s\n\nOK\nTraceback', local_log, re.MULTILINE)
    assert completion['returncode'] == 1 and not completion['timed_out'] and completion['source_unchanged']
    assert failure['type'] == 'FileNotFoundError' and '/source/_ops.py' in failure['message']
    assert not (ROOT / 'execution/evolution-result.json').exists()
    assert sha((ROOT / 'run_evolution_suite.py').read_bytes()) == launch['suite_driver_sha256']
    assert sha((ROOT / 'run_qualification.py').read_bytes()) == launch['coordinator_sha256']
    for stream in ('stdout', 'stderr'):
        data = (ROOT / f'execution/evolution.{stream}').read_bytes()
        assert completion[stream] == {'bytes': len(data), 'sha256': sha(data)}
    events = failure['subprocess_events']
    assert len(events) == 1 and events[0]['argv'][-1] == "import time; print('started', flush=True); time.sleep(10)"
    plan = read('acquisition/execution-plan.json')
    assert plan['actual_selected_local_suites'] == {'evolution': 22}
    assert not plan['local_budget_discovery_or_execution_before_cancellation']
    assert plan['change_before_any_test_execution']
    assert not completion['local_budget_suite_executed']
    host = ROOT / 'hosted-budget-001'
    receipt = json.loads((host / 'receipt.json').read_text())
    zip_raw = (host / 'artifact.zip').read_bytes()
    assert len(zip_raw) == receipt['archive_bytes'] == 1554
    assert sha(zip_raw) == receipt['archive_sha256'] == '6a7a240d31e2c63dfa0e2da65260e0122fa4d92e5f28779b75c080699028b7b6'
    with zipfile.ZipFile(io.BytesIO(zip_raw)) as archive:
        assert set(archive.namelist()) == {item['path'] for item in receipt['members']}
        for item in receipt['members']:
            data = archive.read(item['path'])
            assert len(data) == item['bytes'] and sha(data) == item['sha256']
            assert data == (host / 'artifact' / item['path']).read_bytes()
    assert (host / 'artifact/source.txt').read_text().splitlines() == [BUDGET, BUDGET_TREE]
    assert receipt['source_sha'] == BUDGET
    jobs = json.loads((host / 'job.json').read_text())['jobs']
    assert len(jobs) == 1 and jobs[0]['id'] == 120895835857 and jobs[0]['run_id'] == 40101978822
    assert jobs[0]['status'] == 'completed' and jobs[0]['conclusion'] == 'success'
    assert all(step['conclusion'] == 'success' for step in jobs[0]['steps'])
    host_log = (host / 'artifact/tests.log').read_text()
    host_rows = re.findall(r'^(test_[^( ]+) \([^)]+\) \.\.\. (.+)$', host_log, re.MULTILINE)
    assert len(host_rows) == 29 and all(row[1] == 'ok' for row in host_rows)
    assert re.search(r'^Ran 29 tests in 2\.476s\n\nOK\s*$', host_log, re.MULTILINE)
    relocation = read('acquisition/runtime-relocation-summary.json')
    relocation_raw = gzip.decompress((ROOT / 'acquisition' / relocation['compressed_path']).read_bytes())
    assert len(relocation_raw) == relocation['original_bytes'] and sha(relocation_raw) == relocation['original_sha256']
    assert read('proposals/status.json')['status'] == 'unexecuted_proposal_only'
    audit = {'schema': 'hepta.memory-union.qualification-audit.v1', 'source_commit': UNION, 'source_tree': TREE,
             'remote_commit_and_all_subset_blobs_independently_verified': True, 'source_files': 222, 'python_files': 190,
             'source_bytes': sum(item['bytes'] for item in before), 'source_before_after_current_identical': True,
             'extra_root_fixture_files': [], 'local_evolution': {'tests': 22, 'passed': 22, 'skipped': 0,
             'unittest_seconds': 3.254, 'outer_returncode': 1, 'outer_wall_ns': completion['wall_ns'],
             'pid': completion['pid'], 'timeout': False, 'post_test_failure': failure['type'],
             'failure_detail': 'Collector resolved Torch virtual relative _ops.py against source cwd; failure happened after all original tests passed.',
             'completed_dynamic_module_origin_summary': False, 'actual_source_suite_modified': False, 'automatic_retry': False},
             'hosted_budget': {'source_commit': BUDGET, 'source_tree': BUDGET_TREE, 'run_id': 40101978822,
             'job_id': 120895835857, 'artifact_id': 12562558636, 'tests': 29, 'passed': 29, 'skipped': 0,
             'unittest_seconds': 2.476, 'job_conclusion': 'success', 'artifact_sha256': receipt['archive_sha256']},
             'local_budget_suite_cancelled_before_execution': True, 'all_hosted_artifact_members_verified': True,
             'model_fit_or_generation_calls': 0, 'model_scope_basis': 'Static exact-source review, explicit stub/structural tensor fixtures, and the sole recorded sleep subprocess; complete post-test module-origin summary is unavailable.',
             'local_tensor_dependency_boundary': 'Fixed runtime with torch2.5.1+cpu and safetensors; not a standard-library-only suite. Structural 8-byte fixture validation only.',
             'runtime_relocation_receipt_sha256': relocation['original_sha256'],
             'collector_fix_proposal_executed_or_validated': False,
             'full_git_checkout': False, 'whole_union_CI_qualification': False, 'production_qualification': False,
             'new_model_or_Rust_execution_for_packaging': 0}
    readme = f'''# Scoped published-source qualification

This packet preserves two distinct results: hosted budget checks passed on
`{BUDGET}`, and the 22 original evolution cases passed in a fresh source-subset
capsule bound to union commit `{UNION}`. The local wrapper nevertheless exited
1 after its post-test module-origin collector failed. This packet retains that
failure and does not label the complete wrapper or whole union CI as green.

## Actual execution and identity

| Scope | Exact source | Actual outcome |
|---|---|---|
| Hosted budget component | `{BUDGET}` | 29/29 tests, zero skips, 2.476 s; job success |
| Local union evolution cases | `{UNION}` | 22/22 cases, zero skips, 3.254 s; then post-test collector error, outer exit 1 |

The hosted tree is `{BUDGET_TREE}`; run
[40101978822](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/40101978822),
job 120895835857, artifact 12562558636. The original ZIP is 1,554 bytes with SHA256
`{receipt['archive_sha256']}`. All three ZIP members were checked against their
receipt and extracted bytes. All recorded job steps, including source unchanged,
completed successfully. These component results are not reassigned to the union.

The union tree is `{TREE}`. Its GitHub commit/tree and all 222 subset blob pins
were independently read and compared; the recursive tree response was complete.
The capsule contains 190 Python files and 32 supporting files, 1,664,185 bytes.
Exact matching bytes came from 210 files in the distributed candidate and 12 in
the native candidate. No additional root fixtures were needed. This is a source
subset in the real relative script layout, not a full Git checkout.

Budget's local 29-case suite was cancelled before discovery or execution when
its actual hosted success became available. The recorded pre-run amendment kept
only evolution's 22 cases: four source/budget boundaries, nine stub dispatch and
deadline checks, three source/queue/scoring checks, and six actual-owner topology
checks. Real sibling `BudgetLedger` and `ParametricOwner` path guards execute
inside these unchanged tests; no source or test was edited to obtain a pass.

## Local runtime and retained failure

The fixed Python runtime was used through its original path after its library
files had been moved byte-identically to RAM. The complete relocation receipt
is retained losslessly compressed, with an external original-byte SHA. This
suite needs Torch 2.5.1+cpu and safetensors for an existing 8-byte structural
tensor fixture. It performs no model fit or generation; it is not all-stdlib.

The actual command, environment overlay, PID {completion['pid']}, stdout/stderr,
wall/CPU measurements, and cgroup observations are retained under `execution/`.
The process wall time was {completion['wall_ns'] / 1e9:.6f} seconds. No timeout or
OOM occurred. The only recorded subprocess command is the unchanged pure-Python
sleep used by the 0.15-second deadline test. No local suite was retried.

After `Ran 22 tests in 3.254s / OK`, the added collector resolved Torch's virtual
relative `__file__` value `_ops.py` against the capsule source directory and
raised `FileNotFoundError`. The complete traceback, failure JSON, and outer
exit 1 are preserved. `execution/evolution-result.json` was never produced;
a completed dynamic import-origin summary cannot be reconstructed or claimed.
Source hashes before and after execution match all 222 published blob pins.

`proposals/module_origin_collector.py` separately proposes explicit unresolved
records for virtual, relative and missing origins. It was not wired into the
executed driver, imported, tested or validated. The actual failed driver remains
unchanged and bound to the launch receipt.

## Evidence access and limits

Verify [source-qualification.tar.gz](source-qualification.tar.gz) using
[evidence-manifest.json](evidence-manifest.json), then extract the archive root
`{PREFIX}/`. [members.jsonl](members.jsonl) lists every payload file.
[audit.json](audit.json) reports the independent raw-log/ZIP/source comparison.
The archive includes exact source bytes, original hosted evidence, all local
receipts and failures, both executed drivers, and the unexecuted proposal.
It excludes installed runtime/model binaries and unrelated QA archives.

This supports the specified source-subset mechanisms and sibling dependency
layout. It is not whole-union CI, native/Rust acceptance, distributed-host
acceptance, a complete dynamic import attestation, or production qualification.
No A/B benchmark, model score, task denominator or historical result is changed.
'''
    (ROOT / 'audit.json').write_bytes(encode(audit))
    (ROOT / 'README.md').write_text(readme)
    original = {}
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and not path.is_relative_to(OUT):
            assert not path.is_symlink()
            original[str(path.relative_to(ROOT))] = path.read_bytes()
    members = [{'path': f'{PREFIX}/{name}', 'bytes': len(data), 'sha256': sha(data), 'git_blob_sha1': blob(data), 'mode': '100644'} for name, data in sorted(original.items())]
    member_lines = ('\n'.join(json.dumps(item, sort_keys=True) for item in members) + '\n').encode()
    archive_manifest = encode({'schema': 'hepta.memory-union.archive.v1', 'source_commit': UNION, 'source_tree': TREE,
                               'payload_members': members, 'manifest_self_hash': 'Pinned externally to avoid circular hashing'})
    payload = {f'{PREFIX}/{name}': data for name, data in original.items()}
    payload[f'{PREFIX}/MANIFEST.json'] = archive_manifest
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', filename='', mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(payload.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.uid, info.gid, info.mtime = len(data), 0o644, 0, 0, 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data))
    archive = buffer.getvalue()
    checked = set()
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
        for item in tar:
            name = PurePosixPath(item.name)
            assert item.isfile() and not name.is_absolute() and '..' not in name.parts and item.name not in checked
            assert tar.extractfile(item).read() == payload[item.name]
            checked.add(item.name)
    assert checked == set(payload)
    for name, data in original.items():
        assert (ROOT / name).read_bytes() == data
    OUT.mkdir()
    for name, data in {'README.md': readme.encode(), 'audit.json': encode(audit), 'members.jsonl': member_lines,
                       'source-qualification.tar.gz': archive}.items():
        (OUT / name).write_bytes(data)
    external = {'schema': 'hepta.memory-union.publication-evidence.v1', 'archive': 'source-qualification.tar.gz',
                'archive_bytes': len(archive), 'archive_sha256': sha(archive), 'archive_members': len(payload),
                'archive_manifest_sha256': sha(archive_manifest), 'all_members_verified': True,
                'source_subset_commit': UNION, 'source_subset_tree': TREE, 'hosted_budget_commit': BUDGET,
                'hosted_budget_tree': BUDGET_TREE, 'source_files': 222, 'local_cases_passed': 22,
                'local_process_exit': 1, 'post_test_harness_failure_preserved': True,
                'complete_dynamic_import_attestation': False, 'hosted_budget_cases_passed': 29,
                'local_budget_suite_executed': False, 'new_model_calls': 0, 'automatic_retry': False,
                'archive_format': 'sorted regular files; gzip mtime0/empty name; tar uid/gid/mtime0 and mode0644'}
    (OUT / 'evidence-manifest.json').write_bytes(encode(external))
    files = []
    for path in sorted(OUT.iterdir()):
        data = path.read_bytes();binary = path.suffix == '.gz'
        files.append({'path': f'{TARGET}/{path.name}', 'local_path': str(path), 'mode': '100644', 'bytes': len(data),
                      'sha256': sha(data), 'git_blob_sha1': blob(data), 'lines': None if binary else len(data.splitlines()), 'binary': binary})
    ready = {'schema': 'hepta.memory-union.publication-ready.v1', 'files': files, 'repository_target': TARGET,
             'text_lines': sum(item['lines'] or 0 for item in files), 'archive_sha256': sha(archive),
             'remote_mutation_owner': 'root', 'agent_remote_writes': 0,
             'stage': 'preserve hosted budget success and union source-subset evolution with post-test collector failure'}
    (ROOT / 'publication-ready.json').write_bytes(encode(ready))
    print(json.dumps({'publication_manifest': str(ROOT / 'publication-ready.json'),
                      'manifest_sha256': sha(encode(ready)), 'archive_bytes': len(archive), 'archive_sha256': sha(archive),
                      'members': len(payload), 'text_lines': ready['text_lines'], 'files': files}, sort_keys=True))


if __name__ == '__main__':
    main()
