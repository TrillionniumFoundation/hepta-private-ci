"""One-shot bounded coordinator; no model imports and no retry."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
OUT = ROOT / 'execution'
PYTHON = '/tmp/hepta-memory-runtime-20261024/bin/python'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def retain(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def identity():
    pins = json.loads((ROOT / 'acquisition/python-source-pins.json').read_text())
    actual = []
    for item in pins['files']:
        path = SOURCE / item['path']
        if path.is_symlink():
            raise ValueError('source symlink')
        data = path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if blob != item['git_blob_sha1']:
            raise ValueError('source pin changed: ' + item['path'])
        actual.append({'path': item['path'], 'bytes': len(data), 'sha256': sha(data), 'git_blob_sha1': blob})
    return actual


def resources():
    root = Path('/sys/fs/cgroup')
    return {name: (root / name).read_text() if (root / name).exists() else None
            for name in ['memory.current', 'memory.max', 'memory.events']}


before = identity()
retain(OUT / 'source-before.json', before)
command = [PYTHON, '-I', '-B', str(ROOT / 'run_evolution_suite.py')]
overlay = {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': '',
           'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
           'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1'}
env = os.environ.copy()
env.update(overlay)
start = time.monotonic_ns()
cpu_before = resource.getrusage(resource.RUSAGE_CHILDREN)
pre = resources()
timed_out = False
try:
    with (OUT / 'evolution.stdout').open('xb') as stdout, (OUT / 'evolution.stderr').open('xb') as stderr:
        with subprocess.Popen(command, cwd=SOURCE, env=env, stdout=stdout, stderr=stderr, start_new_session=True) as process:
            retain(OUT / 'launch.json', {'command': command, 'cwd': str(SOURCE), 'environment_overlay': overlay,
                   'pid': process.pid, 'started_unix_ns': time.time_ns(), 'timeout_seconds': 180,
                   'automatic_retry': False, 'resources_before': pre,
                   'runtime_executable_sha256': sha(Path(PYTHON).read_bytes()),
                   'suite_driver_sha256': sha((ROOT / 'run_evolution_suite.py').read_bytes()),
                   'coordinator_sha256': sha(Path(__file__).read_bytes())})
            try:
                returncode = process.wait(timeout=180)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGKILL)
                returncode = process.wait()
    after = identity()
    retain(OUT / 'source-after.json', after)
    cpu_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    result = {'schema': 'hepta.memory-union.qualification-process.v1', 'returncode': returncode,
              'timed_out': timed_out, 'pid': process.pid, 'wall_ns': time.monotonic_ns() - start,
              'child_cpu_ns': int(round(((cpu_after.ru_utime + cpu_after.ru_stime) -
                                        (cpu_before.ru_utime + cpu_before.ru_stime)) * 1e9)),
              'source_unchanged': before == after, 'source_file_count': len(after),
              'resources_after': resources(), 'no_automatic_retry': True,
              'local_budget_suite_executed': False,
              'runner_result_exists': (OUT / 'evolution-result.json').is_file(),
              'stdout': {'bytes': (OUT / 'evolution.stdout').stat().st_size, 'sha256': sha((OUT / 'evolution.stdout').read_bytes())},
              'stderr': {'bytes': (OUT / 'evolution.stderr').stat().st_size, 'sha256': sha((OUT / 'evolution.stderr').read_bytes())}}
    retain(OUT / 'completion.json', result)
    print(json.dumps(result, sort_keys=True), flush=True)
except BaseException as error:
    retain(OUT / 'coordinator-failure.json', {'type': type(error).__name__, 'message': str(error),
           'elapsed_ns': time.monotonic_ns() - start, 'automatic_retry': False, 'resources': resources()})
    raise
raise SystemExit(returncode if returncode else (0 if before == after else 3))
