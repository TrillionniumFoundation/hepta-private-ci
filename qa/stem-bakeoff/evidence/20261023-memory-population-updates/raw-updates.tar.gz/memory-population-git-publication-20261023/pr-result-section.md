## Completed study and independent audit

The registered pretrained study completed on frozen source `07df4a9cc385375cddded5b5e3b99632ce0652ec`. All three seeds exited successfully, and the independent cohort audit reconstructed the results from 114 raw files per seed. Source selection was independently observed before final worker requests in all three seeds. [Immutable evidence and detailed interpretation](EVIDENCE_URL) preserve original outputs, failures, source pins, and measured cost components.

| Seed | Single retention | Learned guarded split | Eligible oracle | Selected arm |
| --- | --- | --- | --- | --- |
| 1907 | 45/64 | 2/64 | 61/64 | single |
| 2719 | 43/64 | 0/64 | 47/64 | parent |
| 4051 | 40/64 | 0/64 | 45/64 | single |

Mean split minus single is **-65.625 percentage points**. The registered fission, learned-routing, heterogeneous retention/transfer, net system compression, and general-memory gates did not pass. Oracle scores are post-hoc upper bounds; full-set complementarity includes source-eligibility coverage, so common-eligibility answer complementarity is reported separately. Production acceptance remains false.

The primary int8 checkpoint storage/quality gate passed: complete packed sizes are 562434, 562276, and 562164 bytes, about 28.93% of the original complete checkpoints, with zero aggregate retention/transfer accuracy loss on the finite registered probe sets. This is lossy weight encoding, decoded into float32 before inference. It establishes neither bitwise losslessness nor inference RAM savings or net system compression.

## Recovery and CI boundaries

All 21 float32 checkpoints, six packed artifacts, three routers, and six original owner databases are retained in checkpoint ZIP SHA-256 `30237f8fb96bd70d56404532b075eb76e2fb50c2494d72276dfa3e8d1ac783b2`. Exactly one fixed-question relocated model worker ran; 15 non-timing fields matched the original journal, actual research module imports came from the pinned extracted bundle, and the serialized-router decision also matched. Raw evidence includes the new owner database and auxiliary failures. An optional wrapper's import-log parser failed after model success; corrected parsing used the retained log without a second model run. Default replay/router entries succeeded; the separate restore-tools package documents the optional-wrapper fix and its validation boundary.

Both hosted population mechanism jobs passed the same 73 distinct tests, not 146. Older full-confirmation CI passed on its own `1e12dbb...` source. Catalog CI on old `cbd139ad...` failed during import because `packaging` was missing; zero actual catalog tests ran. Draft #3489 adds the pinned dependency and an exact repair-branch trigger. Local smoke and six catalog tests passed; hosted repair execution was still queued in the final timestamped evidence snapshot. Queued and skipped jobs are not counted as passes.
