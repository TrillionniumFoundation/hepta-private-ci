"""Stage immutable QA evidence in an isolated worktree and check publication policy."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


ROOT = Path('/workspace/scratch/1d69f04ee9f4')
OUT = ROOT / 'memory-population-git-publication-20261023'
WORK = ROOT / 'memory-population-ci-repair-worktree-20261023'
BUNDLE = ROOT / 'memory-population-evidence-ready-20261023'
DEST = 'qa/stem-bakeoff/evidence/20261023-memory-population'
SOURCE = '07df4a9cc385375cddded5b5e3b99632ce0652ec'
PARENT = '9d0473ff946bc826d8b53b333331c3a1b2841ab7'
REPAIR = '.github/workflows/hepta-parametric-catalog-shadow.yml'
ALLOWLIST = '.github/blob-size-allowlist.txt'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args, environment=None, raw=None):
    return subprocess.check_output(
        ['git', '-C', str(WORK), *args], env=environment, input=raw
    ).decode().strip()


def save(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    assert git('rev-parse', 'HEAD') == SOURCE
    assert BUNDLE.is_dir()
    archive = BUNDLE / 'raw-evidence.tar.gz'
    archive_bytes = archive.read_bytes()
    original = (OUT / 'blob-size-allowlist.original.txt').read_bytes()
    allowlist = original
    if len(archive_bytes) > 512000:
        allowlist += (
            '\n# Immutable three-seed MemoryCell population raw evidence, including failures.\n'
            '# Exact path only; the 512000-byte default remains unchanged.\n'
            f'# {len(archive_bytes)} bytes; sha256 {digest(archive_bytes)}\n'
            f'{DEST}/raw-evidence.tar.gz\n'
        ).encode()
    repair = (WORK / REPAIR).read_bytes()
    assert digest(repair) == '8e2ee90213e0df85f9adfda4bf646a1c0b353fd73e9a3f723c18c6e5e91715b5'
    source_files = sorted(path for path in BUNDLE.rglob('*') if path.is_file())
    expected = {}
    for source in source_files:
        assert not source.is_symlink()
        target = WORK / DEST / source.relative_to(BUNDLE)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == source.read_bytes()
        else:
            with target.open('xb') as stream:
                stream.write(source.read_bytes())
        expected[str(target.relative_to(WORK))] = digest(target.read_bytes())
    assert {str(p.relative_to(WORK)) for p in (WORK / DEST).rglob('*') if p.is_file()} == set(expected)
    (WORK / ALLOWLIST).parent.mkdir(parents=True, exist_ok=True)
    (WORK / ALLOWLIST).write_bytes(allowlist)
    if allowlist != original:
        expected[ALLOWLIST] = digest(allowlist)
    expected[REPAIR] = digest(repair)
    index = OUT / 'publication.index'
    environment = os.environ | {'GIT_INDEX_FILE': str(index)}
    git('read-tree', SOURCE, environment=environment)
    entries = []
    for name in sorted(expected):
        raw = (WORK / name).read_bytes()
        blob = git('hash-object', '-w', '--stdin', raw=raw)
        git('update-index', '--add', '--cacheinfo', '100644', blob, name,
            environment=environment)
        entries.append({'path': name, 'sha': blob, 'sha256': digest(raw), 'bytes': len(raw),
                        'binary': name.endswith('.tar.gz'), 'existing_in_parent': name == REPAIR})
    tree = git('write-tree', '--missing-ok', environment=environment)
    changed = git('diff', '--name-only', SOURCE, tree).splitlines()
    assert set(changed) == set(expected)
    checks = {}
    commands = {
        'blob-policy': ['python', str(ROOT / 'hepta-private-ci/scripts/check_blob_size.py'),
                        '--base', SOURCE, '--head', tree, '--max-bytes', '512000',
                        '--allowlist', str(WORK / ALLOWLIST)],
        'diff-check': ['git', 'diff', '--check', SOURCE, tree],
    }
    for name, command in commands.items():
        t = time.monotonic()
        result = subprocess.run(command, cwd=WORK, capture_output=True)
        with (OUT / (name + '.log')).open('xb') as stream:
            stream.write(result.stdout + result.stderr)
        checks[name] = {'command': command, 'exit_code': result.returncode,
                        'wall_seconds': time.monotonic() - t}
        assert result.returncode == 0, name
    fmt_env = os.environ.copy()
    fmt_env['PATH'] = '/tmp/hepta-output-portfolio-env/bin:' + fmt_env['PATH']
    fmt = subprocess.run(['/tmp/hepta-output-portfolio-env/bin/just', 'fmt'],
                         cwd=WORK / 'codex-rs', env=fmt_env, capture_output=True)
    with (OUT / 'format.log').open('xb') as stream:
        stream.write(fmt.stdout + fmt.stderr)
    assert fmt.returncode == 0
    assert expected == {name: digest((WORK / name).read_bytes()) for name in expected}
    assert git('rev-parse', 'HEAD') == SOURCE
    original_head = subprocess.check_output(
        ['git', '-C', str(ROOT / 'hepta-private-ci'), 'rev-parse', 'HEAD'], text=True
    ).strip()
    assert original_head == SOURCE
    receipt = {'schema': 'hepta.population.git-publication-stage.v1',
               'started_at': started, 'completed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'study_source_head': SOURCE, 'intended_publication_parent': PARENT,
               'locally_computed_tree': tree, 'entries': entries, 'checks': checks,
               'format_command': ['/tmp/hepta-output-portfolio-env/bin/just', 'fmt'],
               'format_exit_code': fmt.returncode, 'format_cwd': str(WORK / 'codex-rs'),
               'format_preserved_all_published_bytes': True, 'tests_run_after_format': False,
               'original_worktree_head_unchanged': True, 'blob_policy_default_bytes': 512000,
               'partial_clone_unchanged_blobs_may_be_unmaterialized': True,
               'changed_blobs_all_locally_materialized': True,
               'write_tree_missing_ok_used': True,
               'exact_raw_archive_allowlist_added': len(archive_bytes) > 512000,
               'passed': True}
    save('stage-receipt.json', receipt)
    print(json.dumps({'passed': True, 'tree': tree, 'files': len(entries),
                      'archive_bytes': len(archive_bytes), 'archive_sha256': digest(archive_bytes)}))


if __name__ == '__main__':
    main()
