#!/usr/bin/env python3
"""Restore the original, byte-identical evidence bundle from transport parts."""

import argparse
import hashlib
import json
import stat
import subprocess
import sys
from pathlib import Path


ARCHIVE_BYTES = 2751996
ARCHIVE_SHA256 = "67b8c7bcdd4f3405188dfb6afd8e8b36cb17252a48dc74502afa2b29702b3b55"
ARCHIVE_GIT_SHA1 = "bb871e1407f842f23817e978fcbc387c09a00e45"
CHECKSUMS_SHA256 = "12c83b9a634b5ced8a5dc5f0909b0d61aa5ab5fd9172437b39173801e3fdc3b4"
MANIFEST_SHA256 = "e59951bc9e6fede963da772725e30a0cab7764212ef64757ba5efdb52f25b0df"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def bounded_read(root, name, limit):
    relative = Path(name)
    require(not relative.is_absolute() and ".." not in relative.parts, "unsafe path")
    target = root
    require(root.is_dir() and not root.is_symlink(), "regular directory required")
    for part in relative.parts:
        target = target / part
        require(not target.is_symlink(), "symlink forbidden")
    info = target.stat()
    require(stat.S_ISREG(info.st_mode) and info.st_size <= limit, "bounded file required")
    with target.open("rb") as stream:
        raw = stream.read(limit + 1)
    require(len(raw) == info.st_size and len(raw) <= limit, "file changed or oversized")
    return raw


def checked_bytes(root, name, row, limit):
    raw = bounded_read(root, name, limit)
    require(len(raw) == row["bytes"], "length mismatch: " + name)
    require(hashlib.sha256(raw).hexdigest() == row["sha256"], "hash mismatch: " + name)
    return raw


def restore(root, output):
    root = Path(root).absolute()
    output = Path(output).absolute()
    require(not output.exists() and not output.is_symlink(), "output must not exist")
    require(not output.resolve().is_relative_to(root.resolve()), "output must be outside publication")
    raw_manifest = bounded_read(root / "transport", "manifest.json", 20000)
    require(hashlib.sha256(raw_manifest).hexdigest() == MANIFEST_SHA256, "transport manifest changed")
    manifest = json.loads(raw_manifest)
    rows = manifest["parts"]
    require(len(rows) == 14, "part inventory changed")
    part_root = root / "transport" / "parts"
    names = {f"raw-evidence.tar.gz.part-{i:03d}" for i in range(14)}
    require({path.name for path in part_root.iterdir()} == names, "unexpected/missing transport part")
    archive_parts = []
    offset = 0
    for index, row in enumerate(rows):
        name = f"raw-evidence.tar.gz.part-{index:03d}"
        require(row["name"] == name and row["offset"] == offset, "part order or offset changed")
        raw = checked_bytes(part_root, name, row, 196608)
        require(hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest()
                == row["git_blob_sha1"], "part Git object mismatch")
        archive_parts.append(raw)
        offset += len(raw)
    archive = b"".join(archive_parts)
    require(len(archive) == ARCHIVE_BYTES, "whole archive length changed")
    require(hashlib.sha256(archive).hexdigest() == ARCHIVE_SHA256, "whole archive hash changed")
    require(hashlib.sha1(f"blob {len(archive)}\0".encode() + archive).hexdigest()
            == ARCHIVE_GIT_SHA1, "whole archive Git object changed")

    source = root / "bundle"
    raw_checksums = bounded_read(source, "checksums.json", 20000)
    require(hashlib.sha256(raw_checksums).hexdigest() == CHECKSUMS_SHA256, "original checksums changed")
    checksums = json.loads(raw_checksums)
    expected = set(checksums["files"]) - {"raw-evidence.tar.gz"}
    require({p.relative_to(source).as_posix() for p in source.rglob("*") if p.is_file()}
            == expected | {"checksums.json"}, "original side-file inventory changed")
    files = {"checksums.json": raw_checksums, "raw-evidence.tar.gz": archive}
    for name in sorted(expected):
        files[name] = checked_bytes(source, name, checksums["files"][name], 512000)

    output.mkdir()
    for name, raw in files.items():
        target = output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(raw)
    command = [sys.executable, "-B", str(output / "tools" / "assemble_evidence.py"),
               "verify", "--bundle", str(output)]
    result = subprocess.run(command, capture_output=True, text=True, check=False)
    require(result.returncode == 0, "original verifier failed: " + result.stderr)
    verification = json.loads(result.stdout)
    require(verification["passed"] and verification["raw_files_verified"] == 955,
            "original verifier did not confirm all raw files")
    return {"schema": "hepta.population.transport-restoration.v1", "passed": True,
            "output": str(output), "bundle_files": len(files), "parts": len(rows),
            "archive_bytes": len(archive), "archive_sha256": ARCHIVE_SHA256,
            "archive_git_blob_sha1": ARCHIVE_GIT_SHA1,
            "original_verifier": verification, "models_or_research_tests_run": False,
            "recompression_performed": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--publication", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    print(json.dumps(restore(arguments.publication, arguments.output), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
