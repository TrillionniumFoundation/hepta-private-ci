"""Independent retained-evidence reconstruction; standard library, read-only inputs."""
import array
import ast
from collections import Counter
import datetime
import hashlib
import json
import math
from pathlib import Path
import platform
import re
import resource
import struct
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/12ef9c5bdc23/routing-diagnosis-work')
E = ROOT / 'run-002'
R = Path('/workspace/scratch/12ef9c5bdc23/hepta-memory-work')
EXPECTED = '916d71c43c09a80ccd942bacb63dd4eeace98c66340f67181cafbf3884ddf9a3'
OLD_REPORT = Path('/tmp/hepta-routing-independent-review.md')
OLD_SHA = '2dd598a4c5b98ad7c02cfb150a27fe3c21a60e836964ca09745c04daf53f4843'
OUT = Path('/tmp/hepta-routing-final-independent-audit.json')
SEEDS = [1907, 2719, 4051]
FAMILIES = ['semantic', 'episode', 'procedure', 'event_interpolation', 'procedure_extrapolation']
GROUPS = dict(all=None, known=set(FAMILIES), retention=set(FAMILIES[:3]),
              transfer=set(FAMILIES[3:]), unknown={'unknown'}, **{k: {k} for k in FAMILIES})
checks, failures, notes = Counter(), [], []
hash_cache, read_cache, tensor_cache = {}, {}, {}
work = Counter(model_calls=0, optimizer_updates=0, gradient_probes=0,
               linear_router_predictions=0, nearest_source_queries=0)
started, cpu_start = time.perf_counter(), time.process_time()


def load(path):
    path = Path(path)
    if path not in read_cache:
        read_cache[path] = json.loads(path.read_text())
    return read_cache[path]


def sha(path):
    path = Path(path)
    if path not in hash_cache:
        h = hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda: f.read(1024 * 1024), b''):
                h.update(block)
        hash_cache[path] = h.hexdigest()
        work['hashed_files'] += 1
        work['hashed_bytes'] += path.stat().st_size
    return hash_cache[path]


def digest(value, ascii=False):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=ascii,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def same(a, b):
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(same(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple, array.array)) and isinstance(b, (list, tuple, array.array)):
        return len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
    if type(a) in (int, float) and type(b) in (int, float):
        return math.isclose(a, b, rel_tol=1e-11, abs_tol=1e-11)
    return a == b


def check(category, label, ok):
    checks[category] += 1
    if not ok:
        failures.append({'category': category, 'label': label})


def equal(category, label, a, b):
    check(category, label, same(a, b))


def eligibility(probe, version, sources):
    op, roots = probe['operation'], probe['source_roots']
    if op['kind'] == 'semantic':
        rows = [r for r in sources if r['kind'] == 'semantic' and r['entity'] == op['entity'] and r['relation'] == op['relation']]
        supported = bool(rows)
    elif op['kind'] in ('event_at', 'event_asof'):
        rows = [r for r in sources if r['kind'] == 'episode' and r['entity'] == op['entity']]
        if op['kind'] == 'event_at':
            rows = [r for r in rows if r['day'] == op['day']]
        supported = any(r['day'] <= op['day'] for r in rows)
    else:
        rows = [r for r in sources if r['kind'] == 'procedure' and r['rule'] == op['rule']]
        supported = bool(rows)
    expected = sorted(r['source_digest'] for r in rows)
    inherited, matches = bool(roots) and set(roots) <= set(version['roots']), sorted(roots) == expected
    return dict(source_supported=inherited, operation_supported=supported, declared_roots_match=matches,
                capability_allowed=inherited and matches and supported, expected_roots=expected)


def assess(probe, raw, version, sources):
    text = None if raw is None else raw['text']
    eligible = eligibility(probe, version or {'roots': []}, sources)
    known, abstained = probe['family'] != 'unknown', raw is None
    exact = not abstained and text == probe['value']
    supported = bool(known and exact and eligible['capability_allowed'])
    return dict(probe_id=probe['probe_id'], family=probe['family'], raw_text=text,
        output_text='unknown' if abstained else text, **eligible, raw_correct=exact,
        supported_correct=supported, correct=supported if known else abstained or text == 'unknown',
        action_abstained=abstained, decoder_unknown=not abstained and text == 'unknown',
        version_manifest_sha256=version['manifest_sha256'] if version else None)


def summarize(rows):
    result = {}
    for name, families in GROUPS.items():
        selected = [r for r in rows if families is None or r['family'] in families]
        n, correct, raw = len(selected), sum(r['correct'] for r in selected), sum(r['raw_correct'] for r in selected)
        result[name] = dict(total=n, correct=correct, accuracy=correct/n if n else None,
            raw_correct=raw, raw_exact_match=raw/n if n else None,
            supported_correct=sum(r['supported_correct'] for r in selected),
            action_abstentions=sum(r['action_abstained'] for r in selected),
            decoder_unknown=sum(r['decoder_unknown'] for r in selected))
    return result


def routed(probes, raw, versions, sources, routes):
    result = []
    for i, (probe, route) in enumerate(zip(probes, routes)):
        slot = route['slot']
        row = assess(probe, None if slot is None else raw[slot][i],
                     None if slot is None else versions[slot], sources)
        result.append(dict(row, slot=slot, route_reason=route['reason']))
    return result


def npy(path):
    with Path(path).open('rb') as f:
        magic = f.read(8)
        check('features', str(path)+' numpy magic', magic[:6] == b'\x93NUMPY')
        size = struct.unpack('<H' if magic[6] == 1 else '<I', f.read(2 if magic[6] == 1 else 4))[0]
        header = ast.literal_eval(f.read(size).decode().strip())
        kind = {'<f4': 'f', '<f8': 'd'}[header['descr']]
        values = array.array(kind)
        values.frombytes(f.read())
        if sys.byteorder != 'little':
            values.byteswap()
    check('features', str(path)+' shape/finite', not header['fortran_order'] and len(values) == math.prod(header['shape']) and all(math.isfinite(v) for v in values))
    n, width = header['shape']
    return [values[i*width:(i+1)*width] for i in range(n)], header


def unit(values):
    norm = math.sqrt(sum(v*v for v in values))
    return [v/norm for v in values] if norm else list(values)


def features(question, config):
    tokens = re.findall(r'\w+', ' '.join(question.casefold().split()))
    weighted = [('w:'+t, 1.) for t in tokens]
    weighted += [('b:'+a+'/'+b, .5) for a, b in zip(tokens, tokens[1:])]
    text = ' '+' '.join(tokens)+' '
    weighted += [(f'c{n}:'+text[i:i+n], .15) for n in (3,4) for i in range(len(text)-n+1)]
    row, key = [0.]*config['dimension'], config['seed'].to_bytes(4, 'little')
    for token, weight in weighted:
        h = hashlib.blake2b(token.encode(), key=key, digest_size=8).digest()
        row[int.from_bytes(h[:4], 'little') % len(row)] += weight if h[4]&1 else -weight
    return unit(row)+[1.]


def router(path, expected):
    equal('router_files', str(path)+' hash', sha(path), expected)
    payload, magic = Path(path).read_bytes(), b'HEPTA_ROUTER_V2\n'
    check('router_files', str(path)+' magic', payload.startswith(magic))
    n = struct.unpack('<I', payload[len(magic):len(magic)+4])[0]
    header = json.loads(payload[len(magic)+4:len(magic)+4+n])
    tensor = payload[len(magic)+4+n:]
    equal('router_files', str(path)+' tensor pin', hashlib.sha256(tensor).hexdigest(), header['weight_sha256'])
    check('router_files', str(path)+' shape', header['weight_shape'] == [513,3] and len(tensor) == 513*3*4)
    weights = struct.unpack('<'+'f'*(len(tensor)//4), tensor)
    return header, weights


def predict(vector, header, weights):
    work['linear_router_predictions'] += 1
    logits = [sum(v*weights[i*3+k] for i,v in enumerate(vector)) for k in range(3)]
    z = [math.exp(v-max(logits)) for v in logits]
    p = [v/sum(z) for v in z]
    top = 0 if p[0] >= p[1] else 1
    confidence, margin = p[0]+p[1], p[top]-p[2]
    c = header['config']
    reason = ('learned_reject' if p[2]>=p[top] else 'low_support_confidence' if confidence<c['min_confidence']
              else 'low_support_margin' if margin<c['min_margin'] else 'routed')
    return {'slot': top if reason=='routed' else None, 'reason':reason, 'probabilities':p}


def terms(question):
    t = re.findall(r'\w+', ' '.join(question.casefold().split()))
    return Counter(['w:'+x for x in t]+['b:'+a+'/'+b for a,b in zip(t,t[1:])])


def tensor_digests(path):
    """Reconstruct worker hashes from safetensors bytes without tensor libraries."""
    path = Path(path)
    if path not in tensor_cache:
        payload = path.read_bytes()
        size = struct.unpack('<Q', payload[:8])[0]
        header, values = json.loads(payload[8:8+size]), payload[8+size:]
        tensors, state = hashlib.sha256(), hashlib.sha256()
        for name, row in sorted(header.items()):
            if name == '__metadata__':
                continue
            start, stop = row['data_offsets']
            dtype, width = {'F32': ('torch.float32',4), 'F16': ('torch.float16',2),
                            'BF16': ('torch.bfloat16',2)}[row['dtype']]
            check('tensor_binding', str(path)+' '+name+' bounds',
                  0 <= start < stop <= len(values) and stop-start == math.prod(row['shape'])*width)
            data = values[start:stop]
            tensors.update(name.encode()); tensors.update(data)
            state.update(digest((name,row['shape'],dtype)).encode()); state.update(data)
        tensor_cache[path] = (tensors.hexdigest(), state.hexdigest())
    return tensor_cache[path]


def target_counts(rows, minimum):
    effective_reject = informative = tied = 0
    for row in rows:
        best = max(row['utilities'])
        if row['reject'] or best < minimum:
            effective_reject += 1
        elif row['utilities'].count(best) == 1:
            informative += 1
        else:
            tied += 1
    return dict(rows=len(rows), explicit_positive=sum(not r['reject'] for r in rows),
                explicit_negative=sum(r['reject'] for r in rows),
                effective_reject=effective_reject, informative_expert=informative, tied_expert=tied)


def nearest_check(label, source, query, targets, observed):
    work['nearest_source_queries'] += 1
    if not any(query):
        equal('nearest_routes', label, observed, {'slot':None,'reason':'no_matching_source_features','source_index':None})
        return
    scores = [sum(a*b for a,b in zip(row,query)) for row in source]
    at = observed['source_index']
    check('nearest_routes', label+' cosine optimum', scores[at] >= max(scores)-1e-12)
    equal('nearest_routes', label+' cosine value', scores[at], observed['cosine'])
    equal('nearest_routes', label+' target', observed['slot'], targets[at])
    equal('nearest_routes', label+' reason', observed['reason'], 'nearest_source_reject' if targets[at] is None else 'routed')


def read_raw(directory, expected_questions, version, plan_commit=None):
    receipt, allrows, spans = load(directory/'receipt.json'), [], []
    lineage = load(Path(version['directory'])/'lineage.json')
    equal('decoder_binding', str(directory)+' version', receipt['version'], version)
    for ref in receipt['journals']:
        path = Path(ref['path']); j = load(path)
        equal('decoder_binding', str(path)+' journal SHA', sha(path), ref['sha256'])
        stem = path.name.removesuffix('-journal.json')
        raw, request = load(path.with_name(stem+'-stdout.json')), load(path.with_name(stem+'-request.json'))
        binding = load(path.with_name(stem+'-binding.json'))
        equal('decoder_binding', str(path)+' stdout rows', j['rows'], raw['rows'])
        equal('decoder_binding', str(path)+' stdout shared fields', {k:j[k] for k in raw}, raw)
        equal('decoder_binding', str(path)+' binding copy', j['binding'], binding)
        equal('decoder_binding', str(path)+' request bytes', j['request_sha256'], hashlib.sha256(json.dumps(request,sort_keys=True).encode()).hexdigest())
        equal('decoder_binding', str(path)+' request binding', binding['request_sha256'], j['request_sha256'])
        check('decoder_binding', str(path)+' closed request', set(request)=={'model','snapshot','manifest_sha256','scope','allowed_roots','questions','rank','seed','control'})
        equal('decoder_binding', str(path)+' manifest', request['manifest_sha256'], version['manifest_sha256'])
        equal('decoder_binding', str(path)+' scope', request['scope'], lineage['scope'])
        equal('decoder_binding', str(path)+' ancestry', set(request['allowed_roots']), set(version['roots']))
        equal('decoder_binding', str(path)+' rank seed', [request['rank'],request['seed']], [version['rank'],version['seed']])
        check('decoder_binding', str(path)+' raw admission', j['owner_admitted_before_and_after'] is True and j['control']=='adapter' and all(j[k] is False for k in ['fact_input','retrieval_input','answer_lexicon_input','production_accepted']))
        equal('decoder_binding', str(path)+' adapter state', j['admitted_adapter_state_sha256'], j['consumed_adapter_state_sha256'])
        tensor_hash, state_hash = tensor_digests(Path(version['directory'])/'adapter_model.safetensors')
        equal('decoder_binding', str(path)+' actual tensor values', j['actual_adapter_tensor_sha256'], tensor_hash)
        equal('decoder_binding', str(path)+' loaded adapter state', j['admitted_adapter_state_sha256'], state_hash)
        effective = dict(base_identity=lineage['base_identity'],adapter_enabled=True,active_adapter_sha256=state_hash)
        equal('decoder_binding', str(path)+' effective state',j['effective_state_sha256'],hashlib.sha256(json.dumps(effective,sort_keys=True).encode()).hexdigest())
        equal('decoder_binding', str(path)+' exact questions', [r['question'] for r in j['rows']], request['questions'])
        check('decoder_binding', str(path)+' raw rows', all(r['answer_postprocessed'] is False and r['adapter_enabled'] is True for r in j['rows']))
        check('decoder_binding', str(path)+' base identity',all(r['base_identity']==lineage['base_identity'] for r in j['rows']))
        for row in j['rows']:
            equal('prompt_tokens', stem+' prompt', row['prompt_sha256'], digest(row['prompt_token_ids']))
            equal('prompt_tokens', stem+' lengths', [row['input_tokens'],row['generated_tokens']], [len(row['prompt_token_ids']),len(row['token_ids'])])
        check('timestamps', str(path)+' time order', binding['bound_unix_ns']<=j['worker_started_unix_ns']<j['worker_finished_unix_ns'])
        if plan_commit:
            check('timestamps', str(path)+' frozen before start', j['worker_started_unix_ns']>plan_commit['route_plan_frozen_unix_ns'])
            equal('timestamps', str(path)+' plan binding', {k:binding['context'][k] for k in plan_commit}, plan_commit)
        spans.append([j['worker_started_unix_ns'],j['worker_finished_unix_ns']])
        allrows.extend(j['rows'])
    equal('decoder_binding', str(directory)+' complete questions', [r['question'] for r in allrows], expected_questions)
    c=receipt['cost']
    for key,value in {'queries':len(allrows),'input_tokens':sum(r['input_tokens'] for r in allrows),
                     'generated_tokens':sum(r['generated_tokens'] for r in allrows),'generation_seconds':sum(r['seconds'] for r in allrows),'fresh_processes':len(spans)}.items():
        equal('costs', str(directory)+' '+key, c[key], value)
    check('costs', str(directory)+' load wall bound', c['wall_seconds']+1e-6>=sum(r['fresh_process_wall_seconds'] for r in receipt['journals']))
    return allrows, receipt, spans


def run():
    global_result=load(E/'result.json'); equal('identity','global result expected SHA',sha(E/'result.json'),EXPECTED)
    equal('identity','early cutoff report untouched',sha(OLD_REPORT),OLD_SHA)
    prepared, identity, protocol, pins, cohort = [load(E/f'{n}.json') for n in ['prepared','source-identity','protocol','input-pins','cohort-pins']]
    for name,key in [('protocol','protocol_sha256'),('input-pins','input_pins_sha256'),('source-identity','source_identity_sha256'),('cohort-pins','cohort_pins_sha256')]:
        equal('identity',name+' prepared pin',sha(E/f'{name}.json'),prepared[key])
    equal('identity','HEAD',subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),identity['git_head'])
    check('identity','tracked source clean',subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=R).returncode==0)
    actual_sources={str(p.relative_to(R)):sha(p) for d in sorted((R/'scripts').glob('memory_cell*')) if d.is_dir() for p in sorted(d.glob('*.py'))}
    equal('identity','all repository Python bytes',actual_sources,identity['repository_sources'])
    equal('identity','repository map digest',digest(actual_sources),identity['repository_source_sha256'])
    for name,pin in identity['diagnosis_sources'].items():
        equal('identity',name+' snapshot',sha(E/'diagnosis-source'/name),pin)
        equal('identity',name+' executed top level',sha(ROOT/name),pin)
    equal('identity','diagnosis map digest',digest(identity['diagnosis_sources']),identity['diagnosis_source_sha256'])
    equal('identity','exact five modules',len(identity['diagnosis_sources']),5)
    check('identity','start prepared binding',load(E/'execution-start.json')['prepared_sha256']==sha(E/'prepared.json'))
    base=load(E/'base-acquisition.json');model=Path(protocol['model'])
    tree=ast.parse((R/'scripts/memory_cell/prepare_parametric.py').read_text())
    constants={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('FILES','REPOSITORY','REVISION')}
    equal('base','publisher origin',[base['repository'],base['revision']],[constants['REPOSITORY'],constants['REVISION']])
    for row in base['files']:
        p=model/row['path'];size,pub=constants['FILES'][row['path']]
        equal('base',row['path']+' SHA',sha(p),row['sha256']);equal('base',row['path']+' size',p.stat().st_size,size)
        if len(pub)==40:
            h=hashlib.sha1(f'blob {size}\0'.encode()+p.read_bytes()).hexdigest()
        else:h=sha(p)
        equal('base',row['path']+' publisher digest',h,pub)
    equal('base','complete inventory',sorted(p.relative_to(model).as_posix() for p in model.rglob('*') if p.is_file() and p.relative_to(model).parts[0]!='.cache'),sorted(constants['FILES']))
    equal('base','base bytes',sum(r['bytes'] for r in base['files']),271170520)
    summaries=[]; total_rows=[]; total_features=0; feature_tokens=0; fit_updates=0; process_spans=[]
    historical_report_count=checkpoint_file_count=0
    for seed,global_seed in zip(SEEDS,global_result['seeds'],strict=True):
        print(json.dumps({'audit_seed':seed,'stage':'read_reconcile'}),flush=True)
        d=E/f'seed-{seed}';p=pins[str(seed)];h=Path(protocol['historical'])/f'seed-{seed}';result=load(d/'result.json')
        equal('global',f'{seed} embedded seed result',result,global_seed)
        for rel,key in [('dataset.json','dataset_file_sha256'),('training/result.json','training_file_sha256'),('selection/precommitted-selection.json','selection_file_sha256')]:equal('historical',f'{seed} {rel}',sha(h/rel),p[key])
        current_reports={str(f.relative_to(h)):sha(f) for f in sorted(h.rglob('*.json')) if 'training' not in f.relative_to(h).parts}
        equal('historical',f'{seed} complete report map',current_reports,p['historical_report_files']);historical_report_count+=len(current_reports)
        for arm,versions in p['versions'].items():
            for slot,v in enumerate(versions):
                directory=Path(v['directory']);inv={f.name:{'sha256':sha(f),'bytes':f.stat().st_size} for f in directory.iterdir() if f.is_file()}
                equal('checkpoints',f'{seed} {arm}-{slot} inventory',inv,p['checkpoint_files'][f'{arm}-{slot}']);checkpoint_file_count+=len(inv)
                line=load(directory/'lineage.json')
                equal('checkpoints',f'{seed} manifest',sha(directory/'lineage.json'),v['manifest_sha256'])
                equal('checkpoints',f'{seed} tensor/config pins',[sha(directory/'adapter_model.safetensors'),sha(directory/'adapter_config.json')],[line['adapter_sha256'],line['config_sha256']])
        old_router_header,_=router(Path(p['original_router_path']),p['original_router_sha256'])
        equal('historical',f'{seed} source costs',result['historical_sunk_source_selection_work'],p['historical_selection_work'])
        equal('historical',f'{seed} training costs',result['historical_sunk_training_costs'],load(h/'training/result.json')['costs'])
        equal('historical',f'{seed} final costs',result['historical_sunk_final_work'],load(h/'final/result.json')['work'])
        data,source,final=[load(d/f'{name}.json') for name in ['dataset','source-panel','final-panel']]
        equal('cohort',f'{seed} historical fixture',data,load(h/'dataset.json'))
        for name,value in [('dataset',data),('source_panel',source),('final_panel',final)]:equal('cohort',f'{seed} {name}',digest(value),cohort[str(seed)][name+'_sha256'])
        equal('cohort',f'{seed} final composition',final,data['retention_final']+data['transfer_final']+data['ood_final'])
        sources,versions=data['sources'],p['versions'];sq=[r['question'] for r in source];fq=[r['question'] for r in final]
        equal('cohort',f'{seed} panel sizes',[len(source),len(final)],[304,120])
        normalized=lambda q:' '.join(q.casefold().split())
        check('cohort',f'{seed} disjoint exact wording',not set(map(normalized,sq))&set(map(normalized,fq)))
        balanced=cohort[str(seed)]['balanced_indices'];counts=Counter((source[i]['wording'],source[i]['reject']) for i in balanced)
        equal('cohort',f'{seed} balanced counts',counts,Counter({(i,False):16 for i in range(4)})+Counter({(i,True):3 for i in range(4)}))
        original_observations=load(h/'selection/router-observations.json')['observations']
        equal('cohort',f'{seed} original observation questions',[row['question'] for row in original_observations],[row['question'] for row in data['router_training']+data['router_reject_training']])
        equal('cohort',f'{seed} original explicit prior',[sum(not r['reject'] for r in original_observations),sum(r['reject'] for r in original_observations)],[64,12])
        raw=[];receipts=[];spans=[]
        for slot,v in enumerate(versions['split']):
            rows,receipt,times=read_raw(d/f'source-expert-{slot}',sq,v);raw.append(rows);receipts.append(receipt);spans+=times
        observation=load(d/'source-observations.json');measured=[];evidence=[]
        for i,probe in enumerate(source):
            el=[eligibility(probe,v,sources) for v in versions['split']]
            u=[float(raw[k][i]['text']==probe['value'] and el[k]['capability_allowed']) for k in range(2)]
            measured.append(dict(question=probe['question'],utilities=u,reject=probe['reject']))
            evidence.append(dict(probe_id=probe['probe_id'],family=probe['family'],wording=probe['wording'],raw_text=[r[i]['text'] for r in raw],eligibility=el,utilities=u,explicit_reject=probe['reject']))
        equal('source_utility',f'{seed} all 304 measured observations',measured,observation['observations']);equal('source_utility',f'{seed} capability/raw evidence',evidence,observation['evidence'])
        plan=load(d/'routing/route-plan.json');commit=load(d/'route-plan-commit.json');source_routes=load(d/'routing/source-routes.json')
        equal('route_freeze',f'{seed} plan file pin',sha(d/'routing/route-plan.json'),commit['route_plan_sha256'])
        equal('route_freeze',f'{seed} result pin',result['route_plan_sha256'],commit['route_plan_sha256'])
        equal('route_freeze',f'{seed} config unchanged',plan['original_config'],old_router_header['config'])
        check('route_freeze',f'{seed} no final output inputs',plan['final_gold_received'] is False and plan['final_raw_outputs_received'] is False)
        equal('route_freeze',f'{seed} metadata only',[{k:row[k] for k in ['probe_id','question','family','operation','source_roots']} for row in plan['rows']],[{k:row[k] for k in ['probe_id','question','family','operation','source_roots']} for row in final])
        finalraw=[];finalspans=[]
        for slot,v in enumerate(versions['split']+versions['single']):
            rows,receipt,times=read_raw(d/f'final-model-{slot}',fq,v,commit);finalraw.append(rows);receipts.append(receipt);finalspans+=times
        check('route_freeze',f'{seed} commit file predates all final starts',(d/'route-plan-commit.json').stat().st_mtime_ns<min(t[0] for t in finalspans))
        spans+=finalspans;process_spans+=spans
        feature=load(d/'parent-features/receipt.json');worker_feature=load(d/'parent-features/worker/receipt.json');request=load(d/'parent-features/request.json')
        equal('features',f'{seed} feature request',request['questions'],sq+fq)
        equal('features',f'{seed} feature request pin',feature['request_sha256'],sha(d/'parent-features/request.json'))
        equal('features',f'{seed} feature tensor pin',feature['sha256'],sha(Path(feature['path'])))
        check('features',f'{seed} actual enabled frozen parent',feature['adapter_enabled'] is True and feature['optimizer_updates']==0 and feature['worker_process_exited'] is True and feature['model_forwards']==424)
        equal('features',f'{seed} parent state digest',feature['adapter_state_sha256'],tensor_digests(Path(versions['parent'][0]['directory'])/'adapter_model.safetensors')[1])
        equal('features',f'{seed} parent version',feature['version'],versions['parent'][0]);equal('features',f'{seed} prompt order',[x['question'] for x in feature['prompts']],sq+fq)
        equal('features',f'{seed} token count',feature['input_tokens'],sum(x['input_tokens'] for x in feature['prompts']))
        vectors,_=npy(Path(feature['path']));dense,_=npy(d/'routing/dense-prototypes.npy');lexical,_=npy(d/'routing/lexical-prototypes.npy')
        equal('features',f'{seed} full shape',[len(vectors),len(vectors[0])],feature['shape'])
        equal('features',f'{seed} dense source prefix',dense,[unit(v) for v in vectors[:304]])
        total_features+=feature['model_forwards'];feature_tokens+=feature['input_tokens']
        targets=[None if row['reject'] or max(row['utilities'])<plan['original_config']['min_utility'] else row['utilities'].index(max(row['utilities'])) for row in measured]
        for name in ['lexical','dense']:
            idx=load(d/f'routing/{name}-index.json');equal('nearest_routes',f'{seed} {name} measured targets',idx['targets'],targets);equal('nearest_routes',f'{seed} {name} source questions',idx['source_questions'],sq)
        lexicon=load(d/'routing/lexical-index.json');documents=[terms(q) for q in sq];vocab=sorted(set().union(*(set(x) for x in documents)));df=Counter(t for doc in documents for t in doc)
        idf=[math.log(305/(1+df[t]))+1 for t in vocab];equal('features',f'{seed} source-only vocabulary',lexicon['vocabulary'],vocab);equal('features',f'{seed} source-only IDF',lexicon['idf'],idf)
        encode=lambda q:unit([terms(q).get(t,0)*idf[i] for i,t in enumerate(vocab)])
        equal('features',f'{seed} lexical stored vectors',lexical,[unit([doc.get(t,0)*idf[i] for i,t in enumerate(vocab)]) for doc in documents])
        dense_unit, lexical_unit = [unit(row) for row in dense], [unit(row) for row in lexical]
        for i,q in enumerate(fq):
            nearest_check(f'{seed} dense {i}',dense_unit,unit(vectors[304+i]),targets,plan['rows'][i]['routes']['dense'])
            nearest_check(f'{seed} lexical {i}',lexical_unit,encode(q),targets,plan['rows'][i]['routes']['lexical'])
        question_vectors=[features(q,plan['original_config']) for q in sq+fq]
        distributions={}
        for name in ['original','full_cross','balanced']:
            rec=plan['router_receipts'].get(name);path=Path(p['original_router_path']) if name=='original' else d/f'routing/{name}-router.bin';expected=p['original_router_sha256'] if name=='original' else rec['sha256']
            header,weights=router(path,expected);equal('router_files',f'{seed} {name} config',header['config'],plan['original_config'])
            if name!='original':
                provenance=load(d/f'routing/{name}-provenance.json');indices=list(range(304)) if name=='full_cross' else balanced;selected=[measured[i] for i in indices]
                equal('router_files',f'{seed} {name} source indices',provenance['source_indices'],indices);equal('router_files',f'{seed} {name} fitted source-only observations',header['training_sha256'],digest(selected,ascii=True))
                equal('router_files',f'{seed} {name} provenance pin',header['source_sha256'],digest(provenance));equal('router_files',f'{seed} {name} updates',header['training']['optimizer_updates'],400)
                fit_updates+=header['training']['optimizer_updates']
            else:
                selected=original_observations
                equal('router_files',f'{seed} original source observations',header['training_sha256'],digest(selected,ascii=True))
            distribution=target_counts(selected,header['config']['min_utility'])
            distributions[name]=distribution
            equal('router_files',f'{seed} {name} actual target counts',
                  [header['training'][key] for key in ['source_examples','informative_expert_examples','tied_expert_examples','reject_examples']],
                  [distribution[key] for key in ['rows','informative_expert','tied_expert','effective_reject']])
            for i,vector in enumerate(question_vectors):
                expected_route=predict(vector,header,weights);actual=source_routes[name][i] if i<304 else plan['rows'][i-304]['routes'][name]
                equal('linear_routes',f'{seed} {name} question {i}',{k:actual[k] for k in expected_route},expected_route)
        assessments=load(d/'final-assessments.json');equal('scoring',f'{seed} assessment pin',sha(d/'final-assessments.json'),result['final_assessments_sha256'])
        experts=[[assess(p,r,v,sources) for p,r in zip(final,rows)] for rows,v in zip(finalraw[:2],versions['split'])]
        equal('scoring',f'{seed} child assessments',assessments['expert_scored'],experts)
        recomputed={}
        for name in plan['rows'][0]['routes']:
            routes=[r['routes'][name] for r in plan['rows']]
            rows=routed(final,finalraw[:2],versions['split'],sources,routes)
            equal('scoring',f'{seed} {name} individual final rows',assessments['policies'][name]['rows'],rows)
            recomputed[name]=summarize(rows)
            guarded=[]
            for i,row in enumerate(plan['rows']):
                eligible=[k for k,v in enumerate(versions['split']) if eligibility(final[i],v,sources)['capability_allowed']]
                equal('scoring',f'{seed} metadata {i}',row['eligible_slots'],eligible)
                desired=row['routes'][name]['slot'] if row['routes'][name]['slot'] in eligible else None
                equal('scoring',f'{seed} guarded {name} {i}',row['guarded_slots'][name],desired)
                guarded.append({'slot':desired,'reason':row['routes'][name]['reason'] if desired is not None else 'metadata_guard_abstention'})
            equal('scoring',f'{seed} guarded metrics {name}',summarize(routed(final,finalraw[:2],versions['split'],sources,guarded)),assessments['policies'][name]['guarded_metrics'])
        recomputed['single']=summarize([assess(p,r,versions['single'][0],sources) for p,r in zip(final,finalraw[2])])
        for name in ['oracle','uniform']:
            rows=[]
            for i,probe in enumerate(final):
                if probe['family']=='unknown':continue
                supported=[e[i]['supported_correct'] for e in experts];rawcorrect=[e[i]['raw_correct'] for e in experts]
                value=max(supported) if name=='oracle' else sum(supported)/2
                rows.append(dict(probe_id=probe['probe_id'],family=probe['family'],correct=value,supported_correct=value,raw_correct=max(rawcorrect) if name=='oracle' else sum(rawcorrect)/2,action_abstained=False,decoder_unknown=False,actual_supported_expert_correct=supported,evaluation_only=True))
            equal('scoring',f'{seed} {name} rows',rows,assessments['policies'][name]['rows']);recomputed[name]=summarize(rows)
        equal('scoring',f'{seed} ALL 9 policy metrics',recomputed,result['metrics'])
        equal('denominators',f'{seed} all denominators',{k:v['all']['total'] for k,v in recomputed.items()},result['all_denominators'])
        for name,m in recomputed.items():
            equal('denominators',f'{seed} {name}',[m['all']['total'],m['known']['total'],m['retention']['total'],m['transfer']['total'],m['unknown']['total']],[96 if name in ('oracle','uniform') else 120,96,64,32,0 if name in ('oracle','uniform') else 24])
        sums={k:sum(rec['cost'][k] for rec in receipts) for k in receipts[0]['cost']}
        equal('costs',f'{seed} ALL decoder ledger',sums,result['costs']['decoder_reads'])
        total_rows += [row for rows in raw+finalraw for row in rows]
        equal('costs',f'{seed} work counts',[sums['queries'],sums['fresh_processes'],feature['model_forwards'],result['costs']['router_fit_optimizer_updates']],[968,9,424,800])
        for name,rec in load(d/'routing/route-costs.json')['receipts'].items():
            if name in ('lexical','dense'):
                for artifact in rec['artifacts']:
                    equal('costs',f'{seed} {name} artifact SHA',sha(Path(artifact['path'])),artifact['sha256'])
                equal('costs',f'{seed} {name} bytes',sum(a['bytes'] for a in rec['artifacts']),rec['artifact_bytes'])
        old=load(h/'final/result.json')['metrics']
        equal('oracle_bounds',f'{seed} unchanged oracle metrics',recomputed['oracle'],old['oracle'])
        metrics={name:{g:{k:v[g][k] for k in ['correct','total','accuracy']} for g in ['retention','transfer','unknown','known','event_interpolation','procedure_extrapolation']} for name,v in recomputed.items()}
        summaries.append({'seed':seed,'raw_source_queries':608,'source_utility_observations':304,'raw_final_queries':360,'route_plan_sha256':commit['route_plan_sha256'],'frozen_unix_ns':commit['route_plan_frozen_unix_ns'],'first_final_worker_started_unix_ns':min(t[0] for t in finalspans),'route_commit_precedes_final_workers':True,'decoder_queries':968,'decoder_processes':9,'parent_feature_forwards':424,'parent_feature_processes':1,'router_updates':800,'metrics':metrics,'training_distribution_counts':distributions,'oracle_identical_to_historical':True,'seed_embedded_hash_status_still_says_pending':result['decoder_hash_check']})
        print(json.dumps({'audit_seed':seed,'stage':'reconciled','failures_so_far':len(failures)}),flush=True)
    totals=global_result['additional_event_costs']
    derived={'decoder_queries':len(total_rows),'decoder_input_tokens':sum(r['input_tokens'] for r in total_rows),'decoder_generated_tokens':sum(r['generated_tokens'] for r in total_rows),'fresh_decoder_processes':len(process_spans),'fresh_parent_feature_processes':3,'parent_feature_forwards':total_features,'parent_feature_input_tokens':feature_tokens,'new_router_optimizer_updates':fit_updates,'new_decoder_optimizer_updates':0,'new_gradient_probes':0,'shared_base_disk_bytes_reused_count_once':271170520}
    equal('global','derived execution work',{k:totals[k] for k in derived},derived)
    for field,key in [('historical_total_decoder_updates','total_optimizer_updates'),('historical_total_gradient_forwards_backwards','gradient_probe_forwards_backwards')]:equal('global',field,global_result[field],sum(pins[str(s)]['historical_training_costs'][key] for s in SEEDS))
    equal('global','historical router updates',global_result['historical_total_original_router_updates'],sum(pins[str(s)]['original_router_receipt']['training']['optimizer_updates'] for s in SEEDS))
    log=(E/'execution.log').read_bytes().splitlines(keepends=True);complete=json.loads(log[-1])
    equal('global','complete stdout metrics',{k:complete[k] for k in totals},totals)
    artifact_bytes=sum(p.stat().st_size for p in E.rglob('*') if p.is_file() and p!=E/'result.json')-len(log[-1])
    equal('costs','before-result artifact accounting',artifact_bytes,totals['actual_event_artifact_bytes_before_result'])
    equal('global','claims remain false',{k:global_result[k] for k in ['confirmation','scientific_phase3_closed','equal_total_budget','capacity_advantage_established','general_memory_proven','production_accepted','live_dispatch_executed']},{k:False for k in ['confirmation','scientific_phase3_closed','equal_total_budget','capacity_advantage_established','general_memory_proven','production_accepted','live_dispatch_executed']})
    check('global','completed integrity assertions',all(global_result[k] is True for k in ['engineering_integrity_passed','original_inputs_and_old_reports_unchanged','base_publisher_bytes_unchanged']))
    notes.append('Per-seed decoder_hash_check strings retain the pre-global pending message; global success plus this independent full-file hash audit supersedes it. Original outputs were not rewritten.')
    notes.append('Nearest-source final routes were independently checked for cosine optimality within 1e-12; floating-point near-tie order is not asserted beyond the stored index/slot and optimum tolerance.')
    notes.append('This local observer and the producer share a host/principal. File hashes and reconstruction are not independent-host execution attestation.')
    notes.append('The initial audit harness incorrectly compared a tensor-content digest to the complete safetensors file hash; its 27 mismatch records were harness errors. The corrected audit independently reconstructs the exact sorted-name/tensor-byte digest and shape/dtype/state digest, without Torch. Initial harness, log and JSON are retained separately under /tmp/*-initial-harness.*.')
    notes.append('An intermediate audit-harness attempt raised KeyError when looking for base_identity in the version locator instead of its pinned lineage.json. Its traceback is retained in /tmp/hepta-routing-final-audit-version-field-harness.log; original trial outputs were unaffected.')
    check('identity','early report remains untouched at finish',hashlib.sha256(OLD_REPORT.read_bytes()).hexdigest()==OLD_SHA)
    report={'schema':'hepta.routing-diagnosis.final-independent-audit.v1','cutoff_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_directory':str(E),'input_result_sha256':EXPECTED,'repository_head':identity['git_head'],'repository_python_files':len(actual_sources),'diagnosis_sources':identity['diagnosis_sources'],'diagnosis_source_sha256':identity['diagnosis_source_sha256'],'protocol_sha256':sha(E/'protocol.json'),'historical_report_files_verified':historical_report_count,'checkpoint_files_verified':checkpoint_file_count,'base_files_verified':len(base['files']),'early_review_sha256_unchanged':OLD_SHA,'audit_passed':not failures,'failures':failures,'reconciliation_counts':dict(checks),'seeds':summaries,'derived_added_execution_work':derived,'recorded_whole_event_wall_seconds':totals['whole_event_wall_seconds'],'historical_sunk_totals':{k:global_result[k] for k in ['historical_total_decoder_updates','historical_total_gradient_forwards_backwards','historical_total_original_router_updates']},'notes':notes,'audit_work_separate_from_original_trial':dict(work,wall_seconds=time.perf_counter()-started,cpu_seconds=time.process_time()-cpu_start,peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,python=platform.python_version(),libraries='Python standard library only',source_sha256=sha(Path(__file__)))}
    OUT.write_text(json.dumps(report,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
    print(json.dumps({'audit_passed':report['audit_passed'],'failures':failures,'output':str(OUT),'work':report['audit_work_separate_from_original_trial']},sort_keys=True),flush=True)


if __name__=='__main__':
    run()
