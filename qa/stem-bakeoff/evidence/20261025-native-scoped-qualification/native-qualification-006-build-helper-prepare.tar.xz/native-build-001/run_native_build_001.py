import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


ROOT = Path('/workspace/scratch/12ef9c5bdc23')
REPO = ROOT / 'hepta-memory-resume-20261024'
OUT = ROOT / 'memory-resume-control-20261024' / 'native-build-001'
OUT.mkdir(exist_ok=False)
command = ['cargo', 'build', '--locked', '-p', 'codex-hepta-agentd', '--example', 'native_memory_daemon', '--example', 'native_memory_shadow', '--features', 'qualification-cognitive-write']
env = dict(os.environ)
env.update(PATH='/tmp/hepta-memory-resume-tools/bin:/tmp/hepta-memory-resume-cargo/bin:' + env['PATH'], RUSTUP_HOME='/tmp/hepta-memory-resume-rustup', CARGO_HOME='/tmp/hepta-memory-resume-cargo', CARGO_TARGET_DIR='/tmp/hepta-memory-resume-target', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1', OPENSSL_DIR='/usr', OPENSSL_LIB_DIR='/usr/lib/x86_64-linux-gnu', OPENSSL_INCLUDE_DIR='/usr/include', PYTHONDONTWRITEBYTECODE='1')
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=REPO).split(b'\0')
before = {p.decode(): hashlib.sha256((REPO / p.decode()).read_bytes()).hexdigest() for p in paths if p and (REPO / p.decode()).is_file()}
(OUT / 'source-before.json').write_text(json.dumps(before, sort_keys=True) + '\n')
receipt = {'command': command, 'cwd': str(REPO / 'codex-rs'), 'started_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(), 'native_model_calls': 0, 'exit_code': None}
subprocess.run(['git', 'diff', '--binary'], cwd=REPO, stdout=(OUT / 'candidate-tracked.patch').open('wb'), check=True)
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert receipt['base_head'] == '8a47cdd26574a85cd314fabce65cc395dbe316a8'
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=REPO)
receipt['rustc_verbose'] = subprocess.check_output(['rustc', '--version', '--verbose'], cwd=REPO / 'codex-rs', env=env, text=True)
started = time.monotonic()
with (OUT / 'build-examples.log').open('wb') as log:
    process = subprocess.Popen(command, cwd=REPO / 'codex-rs', env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt['pid'] = process.pid
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    code = process.wait()
receipt.update(exit_code=code, wall_seconds=time.monotonic()-started, completed_utc=datetime.datetime.now(datetime.UTC).isoformat())
after = {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in before if (REPO / p).is_file()}
receipt['source_unchanged'] = before == after
receipt['log_sha256'] = hashlib.sha256((OUT / 'build-examples.log').read_bytes()).hexdigest()
(OUT / 'source-after.json').write_text(json.dumps(after, sort_keys=True) + '\n')
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
if code == 0:
    receipt['binaries'] = {name: {'sha256': hashlib.sha256((Path(env['CARGO_TARGET_DIR']) / 'debug/examples' / name).read_bytes()).hexdigest(), 'bytes': (Path(env['CARGO_TARGET_DIR']) / 'debug/examples' / name).stat().st_size} for name in ['native_memory_daemon', 'native_memory_shadow']}
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(code)
