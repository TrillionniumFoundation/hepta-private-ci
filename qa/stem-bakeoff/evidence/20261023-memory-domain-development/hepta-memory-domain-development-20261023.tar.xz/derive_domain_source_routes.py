"""Reexecute saved NumPy routers only; preserve the original decoder-read record."""

import argparse
import hashlib
import importlib.abc
import json
import os
from pathlib import Path
import resource
import sys
import tarfile
import tempfile
import time


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()


def require(condition, label):
    if not condition:
        raise ValueError(label)


class NoNeuralImports(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in {"torch", "transformers", "peft"}:
            raise ImportError("Neural runtime forbidden during router-only derivation")
        return None


def run(archive_path, output):
    started, cpu = time.perf_counter(), time.process_time()
    require(not output.exists(), "derivation output must be new")
    require(not any(p in sys.modules for p in ("torch", "transformers", "peft")), "neural runtime already loaded")
    sys.meta_path.insert(0, NoNeuralImports())
    os.environ["OPENBLAS_NUM_THREADS"] = "1"
    os.environ["OMP_NUM_THREADS"] = "1"
    import numpy as np

    source_names = ["source_snapshot/scripts/memory_cell_router/" + p for p in ("learned_router.py", "router_features.py")]
    names = source_names + ["producer/dataset.json"]
    names += ["trial/" + p for p in ("protocol.json", "source-reads.json", "selection.json", "training/training.json", "split.router.bin", "split.router.json", "random_split.router.bin", "random_split.router.json")]
    with tarfile.open(archive_path, "r:xz") as archive:
        manifest = json.load(archive.extractfile("evidence-manifest.json"))
        raw = {name: archive.extractfile(name).read() for name in names}
    pins = {name: {"bytes": len(value), "sha256": sha(value)} for name, value in raw.items()}
    require(all(pin == manifest["files"][name] for name, pin in pins.items()), "input hash mismatch")
    read = lambda name: json.loads(raw[name])
    protocol, data = read("trial/protocol.json"), read("producer/dataset.json")
    require(protocol["source_identity"]["git_head"] == "a26aeb74cf63c7489deb5ece7e2b9a86e5697748", "source revision changed")
    require(np.__version__ == protocol["source_identity"]["dependencies"]["numpy"], "NumPy version differs from original")
    require(sha(raw["producer/dataset.json"]) == protocol["dataset_sha256"], "dataset changed")
    for name in source_names:
        path = name.removeprefix("source_snapshot/scripts/")
        require(sha(raw[name]) == protocol["source_identity"]["files_sha256"][path], "router source changed")
    cases = [c for c in data["cases"] if c["id"] in protocol["train_ids"]]
    probes = [dict(question=protocol["selection_template"].format(entity=c["symptom"], relation="unrecorded checksum" if unknown else "repair"), answer="unknown" if unknown else c["repair_id"], root=None if unknown else c["source_digest"], synthetic_unknown=unknown) for unknown in (False, True) for c in cases]
    selection, source, training = (read("trial/" + p) for p in ("selection.json", "source-reads.json", "training/training.json"))
    require(not selection["final_outputs_seen"], "original selection flag changed")
    output.mkdir()
    arms = {}
    with tempfile.TemporaryDirectory(prefix="router-only-", dir=output) as temporary:
        temporary = Path(temporary)
        for name in source_names:
            (temporary / Path(name).name).write_bytes(raw[name])
        sys.path.insert(0, str(temporary))
        from learned_router import load_router

        for arm in ("split", "random_split"):
            path = temporary / (arm + ".router.bin")
            path.write_bytes(raw["trial/" + path.name])
            receipt = read("trial/" + arm + ".router.json")["receipt"]
            router = load_router(path, expected_sha256=receipt["sha256"])
            require(dict(router.config) == protocol["router_config"], "router configuration changed")
            rows_by_question = [{r["question"]: r for r in rows} for rows in source[arm]]
            routes, outcomes, mapped = [], [], []
            for probe in probes:
                route = router.predict({"question": probe["question"]})
                routes.append(route)
                slot = route["slot"]
                row = None if slot is None else rows_by_question[slot][probe["question"]]
                answer = "unknown" if row is None else row["text"]
                support = slot is not None and probe["root"] in training["versions"][arm][slot]["roots"]
                outcomes.append(answer == probe["answer"] and (support or probe["synthetic_unknown"]))
                mapped.append(dict(answer=answer, supported=support, raw_source_row_sha256=None if row is None else sha(canonical(row))))
            score = dict(correct=sum(outcomes), denominator=len(outcomes), outcomes=outcomes)
            require(score == selection["scores"][arm], "reexecuted source router score differs from original")
            arms[arm] = dict(router_sha256=receipt["sha256"], routes=routes, mapped_original_decoder_rows=mapped, source_score=score)
    require(not any(p in sys.modules for p in ("torch", "transformers", "peft")), "neural runtime unexpectedly imported")
    scores = dict(selection["scores"])
    for arm, result in arms.items():
        scores[arm] = result["source_score"]
    chosen = min(selection["deployment_artifact_bytes"], key=lambda a: (-scores[a]["correct"], selection["deployment_artifact_bytes"][a], a))
    require(chosen == selection["chosen"] == "exact_source", "selector changed after source slot reconstruction")
    result = dict(schema="hepta.domain-source-router-derivation.v1", scope="post-run replay of saved router weights only; original reports and costs unchanged", source_revision=protocol["source_identity"]["git_head"], input_files=pins, derivation_source_sha256=sha(Path(__file__).read_bytes()), argv=sys.argv, numpy_version=np.__version__, source_probes=probes, arms=arms, chosen=chosen, original_decoder_reads=186, extra_audit_router_predictions=sum(len(v["routes"]) for v in arms.values()), extra_decoder_reads=0, optimizer_updates=0, neural_import_blocker_active=True, neural_runtime_imported=False, source_scores_match=True, costs=dict(wall_seconds=time.perf_counter() - started, cpu_seconds=time.process_time() - cpu, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024, measurement_scope="process cumulative peak RSS; in-function wall/CPU including NumPy import and archive reads"))
    (output / "derivation.json").write_bytes(json.dumps(result, indent=2, sort_keys=True).encode() + b"\n")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = run(args.archive, args.output)
    print(json.dumps({k: result[k] for k in ("chosen", "extra_audit_router_predictions", "extra_decoder_reads", "neural_runtime_imported", "source_scores_match", "costs")}, indent=2))
