"""Package the completed domain run; audit retained bytes without model imports."""

import argparse
from collections import Counter
import hashlib
import io
import json
import lzma
from pathlib import Path
import subprocess
import tarfile
import zlib


PINS = {
    "producer/dataset.json": "1642fc42e890f25e32fc5b66289cf07ee3bcf6a81fb4636fd2c2c9333ee74875",
    "trial/protocol.json": "4c011c5cf450a7bf949135a4a2713059b5e41507d54d1e9444b2686b9cf16198",
    "trial/result.json": "9890eaf1fd5e9bc00b977a2056ec70dadb9557d7794fdfe7faab98b40c48eb74",
    "trial/executed-reads.json": "4f018504ca83e3a9718c737845e987571a26fa8b2780c0ecbb2eef4cefbb59ba",
    "trial/final-reads.json": "6a93c39eb5b6db5e2fd635134dcb533a8b623363d5426e9aab76cfd58c8e7a0f",
}
REVISION = "a26aeb74cf63c7489deb5ece7e2b9a86e5697748"
ARCHIVE = "hepta-memory-domain-development-20261023.tar.xz"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()


def pretty(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode()


def require(condition, label):
    if not condition:
        raise ValueError(label)


def metadata(raw):
    return {"bytes": len(raw), "sha256": sha(raw)}


def probe_set(cases, templates, unknown=False):
    return [dict(case_id=c["id"], question=t.format(entity=c["symptom"], relation="unrecorded checksum" if unknown else "repair"), answer="unknown" if unknown else c["repair_id"], root=None if unknown else c["source_digest"], synthetic_unknown=unknown) for c in cases for t in templates]


def collect(args):
    files = {}

    def tree(directory, prefix):
        for path in sorted(directory.rglob("*")):
            require(not path.is_symlink(), "symlink in input tree")
            if path.is_file():
                files[prefix + path.relative_to(directory).as_posix()] = path.read_bytes()

    tree(args.trial, "trial/")
    tree(args.producer, "producer/")
    files["trial.log"] = args.trial.with_suffix(".log").read_bytes()
    files["domain-chronology.json"] = args.chronology.read_bytes()
    chronology = json.loads(files["domain-chronology.json"])
    for name, pin in chronology["inputs"].items():
        raw = (args.inputs / name).read_bytes()
        require(metadata(raw) == pin, "chronology input changed: " + name)
        files["inputs/ci-incidents/" + name] = raw
    protocol = json.loads(files["trial/protocol.json"])
    identity = protocol["source_identity"]
    sources = {"scripts/" + p: h for p, h in identity["files_sha256"].items()}
    sources.update({"scripts/memory_cell_domain/" + p: h for p, h in identity["domain_sources"].items()})
    sources["scripts/memory_cell_domain/README.md"] = None
    for path, pin in sources.items():
        raw = subprocess.check_output(["git", "show", REVISION + ":" + path], cwd=args.repo)
        require(pin is None or sha(raw) == pin, "pinned repository source mismatch: " + path)
        files["source_snapshot/" + path] = raw
    for name, original in (("README.md", "DOMAIN_README.md"), ("PUBLICATION_PLAN.md", "DOMAIN_PUBLICATION_PLAN.md")):
        files[name] = (args.source / original).read_bytes()
    files["package_domain_evidence.py"] = Path(__file__).read_bytes()
    if args.routing_audit:
        tree(args.routing_audit, "router-source-audit/")
        files["router-source-audit/derivation.log"] = args.routing_audit.with_suffix(".log").read_bytes()
        files["derive_domain_source_routes.py"] = (args.source / "derive_domain_source_routes.py").read_bytes()
    files["base-acquisition.json"] = args.base_acquisition.read_bytes()
    files["runtime-requirements.json"] = pretty({k: identity[k] for k in ("python", "platform", "dependencies")})
    return files


def audit_inputs(files, data, protocol):
    require(all(sha(files[p]) == h for p, h in PINS.items()), "executed evidence pin changed")
    identity = protocol["source_identity"]
    require(identity["git_head"] == REVISION, "source revision changed")
    require(sha(canonical(identity["files_sha256"])) == identity["source_manifest_sha256"], "source manifest changed")
    for path, pin in identity["files_sha256"].items():
        require(sha(files["source_snapshot/scripts/" + path]) == pin, "dependency source mismatch")
    for path, pin in identity["domain_sources"].items():
        require(sha(files["source_snapshot/scripts/memory_cell_domain/" + path]) == pin, "domain source mismatch")
    require(protocol["dataset_sha256"] == PINS["producer/dataset.json"], "dataset protocol mismatch")
    require(sha(files["producer/input-manifest.json"]) == data["manifest_sha256"], "producer manifest changed")
    for pin, size in data["source_inventory"].items():
        require(metadata(files["producer/evidence/" + pin]) == {"bytes": size, "sha256": pin}, "source body changed")
    require(sum(data["source_inventory"].values()) == data["source_bytes"], "source byte total")
    for case in data["cases"]:
        require(sha(canonical({k: v for k, v in case.items() if k != "source_digest"})) == case["source_digest"], "case root changed")
    require(data["partitions"] == protocol["partitions"], "partition mismatch")
    require(len(data["cases"]) == 3 and data["partitions"]["future"] == data["partitions"]["validation"] == [], "finite cohort changed")
    require(all(c["previously_seen"] and not c["prospective_at_registration"] for c in data["cases"]), "historical classification changed")
    chronology = json.loads(files["domain-chronology.json"])
    for name, pin in chronology["inputs"].items():
        require(metadata(files["inputs/ci-incidents/" + name]) == pin, "named chronology input changed")
    runs = {r["id"]: r for r in json.loads(files["inputs/ci-incidents/all-runs.json"])}
    for row in chronology["cases"]:
        case = next(c for c in data["cases"] if c["id"] == row["id"])
        fix = json.loads(files["inputs/ci-incidents/commit-" + case["fixed_commit"] + ".json"])
        failure, success = runs[case["failed_run_id"]], runs[case["success_run_id"]]
        stamp = fix["commit"]["committer"]["date"]
        require(fix["parents"][0]["sha"] == case["failed_commit"], "not direct parent")
        require(failure["conclusion"] == "failure" and success["conclusion"] == "success", "run conclusion changed")
        require(row["fix_committed_at"] == stamp and row["failed_run_completed_updated_at"] == failure["updated_at"], "chronology timestamp changed")
        require(row["fix_predates_hosted_failure_completion"] == (stamp < failure["updated_at"]), "chronology classification changed")
    return {"source_python_files": len(identity["files_sha256"]) + len(identity["domain_sources"]), "source_body_files": len(data["source_inventory"]), "known_root_cause_groups": len({c["root_cause"] for c in data["cases"]}), "prospective_cases": 0}


def audit_training(files, training, protocol, base):
    versions, receipts, checkpoints = training["versions"], {}, {}
    base_inventory = {f["path"]: {k: f[k] for k in ("bytes", "sha256")} for f in base["files"]}
    base_identity = sha(canonical(base_inventory))
    require(sum(x["bytes"] for x in base_inventory.values()) == base["total_bytes"], "base byte total")
    for path in sorted(p for p in files if p.startswith("trial/training/") and p.endswith("/lineage.json")):
        lineage = json.loads(files[path])
        directory = path.rsplit("/", 1)[0]
        require(lineage["base_identity"] == base_identity, "adapter base mismatch")
        require(not lineage["production_accepted"] and not lineage["model_install_authority"], "candidate authority changed")
        for field, filename in (("adapter_sha256", "adapter_model.safetensors"), ("config_sha256", "adapter_config.json")):
            require(sha(files[directory + "/" + filename]) == lineage[field], "checkpoint file hash mismatch")
        checkpoints[directory.rsplit("/", 1)[1]] = {"lineage_sha256": sha(files[path]), "adapter_sha256": lineage["adapter_sha256"], "config_sha256": lineage["config_sha256"], "roots": lineage["roots"]}
    require(len(checkpoints) == 8, "checkpoint closure changed")
    total = Counter()
    for arm, vs in versions.items():
        aggregate, exposure = Counter(), Counter()
        for v in vs:
            name = Path(v["directory"]).name
            lineage = json.loads(files["trial/training/" + name + "/lineage.json"])
            receipt = json.loads(files["trial/training/" + name + ".write.json"])
            require(lineage["training"] == receipt, "write receipt differs from saved checkpoint")
            require(checkpoints[name]["lineage_sha256"] == v["manifest_sha256"] and lineage["roots"] == v["roots"], "version manifest/roots mismatch")
            require(receipt["steps"] == len(receipt["losses"]) == len(receipt["schedule_indices"]) == receipt["actual_model_forwards"], "training step receipt mismatch")
            require(sha(canonical(receipt["schedule_indices"])) == receipt["schedule_sha256"], "schedule hash mismatch")
            require([receipt["schedule_indices"].count(i) for i in range(len(receipt["example_visits"]))] == receipt["example_visits"], "example exposure mismatch")
            require(receipt["templates_sha256"] == sha(canonical(protocol["templates"])), "training template changed")
            require(not receipt["evaluation_targets_used"] and receipt["base_unchanged"], "training scope flag changed")
            for root, count in zip(receipt["source_digests"], receipt["fact_visits"]):
                exposure[root] += count
            for key in ("steps", "actual_model_forwards", "input_tokens", "supervised_tokens", "parameter_bytes"):
                aggregate[key] += receipt[key]
            receipts[v["manifest_sha256"]] = v
        require(all(training["costs"][arm][k] == n for k, n in aggregate.items()), "aggregate training cost mismatch")
        expected_roots = versions["parent"][0]["roots"] if arm == "parent" else training["gradient_probe"]["source_digests"]
        require(dict(exposure) == {r: protocol["visits"] for r in expected_roots}, "candidate source exposure mismatch")
        total.update({k: aggregate[k] for k in ("steps", "actual_model_forwards", "input_tokens", "supervised_tokens")})
    require(total["steps"] == training["actual_optimizer_updates"] == 416, "decoder update total")
    require(all(training["costs"][a]["input_tokens"] == 7640 and training["costs"][a]["steps"] == 96 for a in ("single", "expanded", "split", "random_split")), "candidate budget changed")
    expansion = json.loads(files["trial/training/rank-expansion.json"])
    require(expansion["manifest_sha256"] == checkpoints["expanded-parent"]["lineage_sha256"], "expansion checkpoint changed")
    require(expansion["derivation"]["optimizer_updates"] == 0, "expansion update receipt changed")
    return {"receipt_totals": dict(total), "checkpoint_files_verified": checkpoints, "base_identity": base_identity}, receipts


def audit_reads(files, training, protocol, data, result, receipts):
    read = lambda name: json.loads(files["trial/" + name])
    journal, final, source, routes = (read(n) for n in ("executed-reads.json", "final-reads.json", "source-reads.json", "frozen-routes.json"))
    versions, indexed, work = training["versions"], {}, Counter()
    for call in journal:
        version = call["version"]
        require(receipts[version["manifest_sha256"]] == version, "read unregistered version")
        require(call["checkpoint_reload_executed"] == bool(call["rows"]), "read reload receipt changed")
        work[call["category"]] += len(call["rows"])
        for row in call["rows"]:
            key = (call["category"], version["manifest_sha256"], row["question"])
            require(key not in indexed, "duplicate journal read key")
            indexed[key] = row
            require(row["adapter_enabled"] and not row["answer_postprocessed"], "raw-read flags changed")
            require(row["input_tokens"] == len(row["prompt_token_ids"]) and row["generated_tokens"] == len(row["token_ids"]), "token count mismatch")
            require(sha(canonical(row["prompt_token_ids"])) == row["prompt_sha256"], "prompt token hash mismatch")
            for key in ("input_tokens", "generated_tokens"):
                work[key] += row[key]
            work["model_generation_seconds"] += row["seconds"]
    require(dict(work) == result["costs"]["work"], "executed read totals mismatch")
    cases = [c for c in data["cases"] if c["id"] in protocol["train_ids"]]
    source_probes = probe_set(cases, protocol["templates"]) + probe_set(cases, protocol["templates"], True)
    select = probe_set(cases, [protocol["selection_template"]]) + probe_set(cases, [protocol["selection_template"]], True)
    expected_final = probe_set(cases, [protocol["final_template"]]) + probe_set(cases, [protocol["final_template"]], True)
    require(final["probes"] == expected_final, "final questions changed")
    utilities, dispatched = 0, set()
    for arm, vs in versions.items():
        requested = source_probes + select if len(vs) == 2 else select
        for v, rows in zip(vs, source[arm]):
            expected = [indexed[("source_model_reads", v["manifest_sha256"], p["question"])] for p in requested]
            require(rows == expected, "source rows differ from actual read journal")
        if len(vs) == 2:
            router = read(arm + ".router.json")
            expected = [dict(question=p["question"], reject=p["synthetic_unknown"], utilities=[float(p["root"] in v["roots"] and rows[i]["text"] == p["answer"]) for v, rows in zip(vs, source[arm])]) for i, p in enumerate(source_probes)]
            require(router["observations"] == expected, "router label differs from measured utility")
            receipt = router["receipt"]
            require(receipt["source_sha256"] == sha(canonical([protocol["dataset_sha256"], expected])), "router observation pin mismatch")
            require(metadata(files["trial/" + arm + ".router.bin"]) == {"bytes": receipt["artifact_bytes"], "sha256": receipt["sha256"]}, "router artifact changed")
            require(receipt["training"]["optimizer_updates"] == 400 and not receipt["training"]["final_scores_used"], "router training receipt changed")
            utilities += len(expected)
            for v, rows in zip(vs, final["full_expert_diagnostics"][arm]):
                require(rows == [indexed[("diagnostic_model_reads", v["manifest_sha256"], p["question"])] for p in expected_final], "diagnostic journal mismatch")
        for i, p in enumerate(expected_final):
            slot = routes[arm][i]["slot"] if arm in routes else 0
            require(slot is None or type(slot) is int and 0 <= slot < len(vs), "invalid frozen slot")
            key = None if slot is None else ("selected_dispatch_reads", vs[slot]["manifest_sha256"], p["question"])
            expected = "unknown" if key is None else indexed[key]["text"]
            require(final["predictions"][arm][i] == expected, "dispatch differs from frozen route/raw read")
            if key is not None:
                dispatched.add(key)
    require(dispatched == {k for k in indexed if k[0] == "selected_dispatch_reads"}, "uncharged or extraneous dispatched read")
    scores = {}
    for arm, predictions in final["predictions"].items():
        require(len(predictions) == len(expected_final), "prediction count mismatch")
        scores[arm] = {}
        for panel, indices in result["panels"].items():
            correct = sum(predictions[i] == expected_final[i]["answer"] for i in indices)
            score = dict(correct=correct, denominator=len(indices), accuracy=correct / len(indices) if indices else None)
            if arm in versions:
                admitted = 0
                for i in indices:
                    slot = routes[arm][i]["slot"] if arm in routes else 0
                    admitted += slot is not None and expected_final[i]["root"] in versions[arm][slot]["roots"] and predictions[i] == expected_final[i]["answer"]
                score.update(source_admitted_correct=admitted if panel == "known_recall" else None, source_admitted_accuracy=admitted / len(indices) if panel == "known_recall" and indices else None)
            scores[arm][panel] = score
    require(scores == result["scores"], "final score mismatch")
    return {"executed_calls": len(journal), "executed_decoder_reads": len(indexed), "work_recomputed": dict(work), "router_observations_from_measured_utilities": utilities, "frozen_dispatch_reads_reconciled": len(dispatched), "scores_recomputed": scores}


def audit_selection(files, data, training, protocol, result, base):
    selection = json.loads(files["trial/selection.json"])
    require(not selection["final_outputs_seen"] and selection["protocol_sha256"] == PINS["trial/protocol.json"], "selection scope/pin mismatch")
    for score in selection["scores"].values():
        require(sum(score["outcomes"]) == score["correct"] and len(score["outcomes"]) == score["denominator"] == 6, "selection score count mismatch")
    common = data["source_bytes"] + len(files["producer/dataset.json"]) + len(files["producer/input-manifest.json"])
    checkpoint = lambda name: sum(len(b) for p, b in files.items() if p.startswith("trial/training/" + name + "/"))
    deployment = {}
    for arm, versions in training["versions"].items():
        actual = sum(checkpoint(Path(v["directory"]).name) for v in versions)
        require(actual == training["costs"][arm]["checkpoint_bytes"], "checkpoint storage receipt mismatch")
        if arm != "parent":
            deployment[arm] = common + base["total_bytes"] + actual + checkpoint("parent")
            if len(versions) == 2:
                deployment[arm] += len(files["trial/" + arm + ".router.bin"])
    deployment["expanded"] += checkpoint("expanded-parent")
    deployment.update(exact_source=common, tfidf=common + len(files["trial/tfidf-index.json"]), bm25=common + len(files["trial/retrieval.sqlite3"]))
    for arm in ("dense_nearest", "dense_centroid"):
        deployment[arm] = common + base["total_bytes"] + checkpoint("parent") + len(files["trial/dense-source-index.npz"])
    require(deployment == selection["deployment_artifact_bytes"] == result["costs"]["deployment_artifact_bytes"], "deployment storage total mismatch")
    chosen = min(deployment, key=lambda arm: (-selection["scores"][arm]["correct"], deployment[arm], arm))
    require(chosen == selection["chosen"] == result["chosen"] == "exact_source", "source-score/storage selector mismatch")
    for name, measure in result["exact_baselines"]["measurements"].items():
        require(metadata(files["trial/exact-baselines/" + name]) == {k: measure[k] for k in ("bytes", "sha256")}, "exact baseline hash mismatch")
    complete = files["trial/exact-baselines/complete_records.json"]
    require(zlib.decompress(files["trial/exact-baselines/complete_records.zlib9"]) == complete, "zlib lossless roundtrip")
    require(lzma.decompress(files["trial/exact-baselines/complete_records.lzma6"]) == complete, "LZMA lossless roundtrip")
    retained = sum(len(raw) for path, raw in files.items() if path.startswith("trial/") and path != "trial/result.json")
    require(retained == result["costs"]["retained_experiment_bytes_before_result"], "original trial file closure changed")
    return {"chosen_recomputed_from_recorded_source_scores": chosen, "deployment_bytes_recomputed": deployment, "selection_router_source_slots_in_original_trial": False, "router_parameters_not_reexecuted_by_byte_audit": True, "all_original_trial_files_retained": True}


def audit_router_derivation(files, data, protocol, training):
    derived = json.loads(files["router-source-audit/derivation.json"])
    execution = json.loads(files["router-source-audit/execution.json"])
    selection = json.loads(files["trial/selection.json"])
    source = json.loads(files["trial/source-reads.json"])
    require(all(metadata(files[p]) == pin for p, pin in derived["input_files"].items()), "router derivation input changed")
    require(derived["derivation_source_sha256"] == sha(files["derive_domain_source_routes.py"]), "executed derivation module changed")
    require(derived["numpy_version"] == protocol["source_identity"]["dependencies"]["numpy"] and derived["source_revision"] == REVISION, "router derivation runtime/source mismatch")
    require(execution["exit_code"] == 0 and execution["derivation_sha256"] == sha(files["router-source-audit/derivation.json"]), "derivation execution receipt mismatch")
    require(execution["stdout_stderr_sha256"] == sha(files["router-source-audit/derivation.log"]), "derivation log changed")
    cases = [c for c in data["cases"] if c["id"] in protocol["train_ids"]]
    probes = probe_set(cases, [protocol["selection_template"]]) + probe_set(cases, [protocol["selection_template"]], True)
    require(derived["source_probes"] == [{k: v for k, v in p.items() if k != "case_id"} for p in probes], "derivation source probes changed")
    predictions, slots = 0, {}
    for arm, record in derived["arms"].items():
        require(record["router_sha256"] == sha(files["trial/" + arm + ".router.bin"]), "derived router pin changed")
        require(len(record["routes"]) == len(probes), "derivation route count")
        indexed = [{r["question"]: r for r in rows} for rows in source[arm]]
        outcomes, mapped = [], []
        for p, route in zip(probes, record["routes"]):
            slot = route["slot"]
            require(slot is None or type(slot) is int and slot in (0, 1), "derived slot invalid")
            raw = None if slot is None else indexed[slot][p["question"]]
            answer = "unknown" if raw is None else raw["text"]
            support = slot is not None and p["root"] in training["versions"][arm][slot]["roots"]
            outcomes.append(answer == p["answer"] and (support or p["synthetic_unknown"]))
            mapped.append(dict(answer=answer, supported=support, raw_source_row_sha256=None if raw is None else sha(canonical(raw))))
        require(mapped == record["mapped_original_decoder_rows"], "derived source row mapping changed")
        score = dict(correct=sum(outcomes), denominator=len(outcomes), outcomes=outcomes)
        require(score == record["source_score"] == selection["scores"][arm], "derived source score differs from original")
        predictions += len(record["routes"])
        slots[arm] = [r["slot"] for r in record["routes"]]
    require(predictions == derived["extra_audit_router_predictions"] == 12, "audit router cost mismatch")
    require(derived["extra_decoder_reads"] == derived["optimizer_updates"] == 0 and not derived["neural_runtime_imported"] and derived["neural_import_blocker_active"], "derivation scope changed")
    require(derived["original_decoder_reads"] == 186 and derived["chosen"] == selection["chosen"], "original counts/selector changed")
    return dict(extra_router_predictions=predictions, extra_decoder_reads=0, optimizer_updates=0, slots=slots, source_scores_match_original=True, costs=derived["costs"], limitation="byte audit reconciles retained derivation; router execution is the separate recorded NumPy-only process")


def audit(files):
    data, protocol, result, training, base = [json.loads(files[p]) for p in ("producer/dataset.json", "trial/protocol.json", "trial/result.json", "trial/training/training.json", "base-acquisition.json")]
    require(result["source_integrity_verified"] and not result["production_accepted"], "result authority/scope changed")
    inputs = audit_inputs(files, data, protocol)
    trained, receipts = audit_training(files, training, protocol, base)
    reads = audit_reads(files, training, protocol, data, result, receipts)
    selected = audit_selection(files, data, training, protocol, result, base)
    derivation = audit_router_derivation(files, data, protocol, training) if "router-source-audit/derivation.json" in files else None
    return dict(schema="hepta.domain-evidence-byte-audit.v1", checks_passed=True, scope="post-run byte/receipt consistency; not an independent execution signer or new experiment", model_calls_during_byte_audit=0, tests_rerun=0, inputs=inputs, training=trained, reads=reads, selection=selected, separate_router_derivation=derivation)


def tar_bytes(files):
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w", format=tarfile.USTAR_FORMAT) as archive:
        for name, raw in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            archive.addfile(info, io.BytesIO(raw))
    return lzma.compress(buffer.getvalue(), format=lzma.FORMAT_XZ, preset=6)


def verify(archive):
    with tarfile.open(fileobj=io.BytesIO(archive), mode="r:xz") as stream:
        members = stream.getmembers()
        require(all(m.isfile() and not m.name.startswith("/") and ".." not in Path(m.name).parts for m in members), "unsafe archive member")
        require(len({m.name for m in members}) == len(members), "duplicate archive member")
        files = {m.name: stream.extractfile(m).read() for m in members}
    manifest = json.loads(files["evidence-manifest.json"])
    require(set(manifest["files"]) == set(files) - {"evidence-manifest.json"}, "manifest closure mismatch")
    for name, pin in manifest["files"].items():
        require(metadata(files[name]) == pin, "archive file hash mismatch: " + name)
    require(audit(files) == json.loads(files["archive-audit.json"]), "archive audit is not reproducible")
    return {"members": len(files), "payload_bytes": sum(map(len, files.values())), "archive": metadata(archive), "audit_recomputed": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", type=Path)
    parser.add_argument("--routing-audit", type=Path)
    for name in ("source", "trial", "producer", "inputs", "chronology", "repo", "base-acquisition", "output"):
        parser.add_argument("--" + name, type=Path)
    args = parser.parse_args()
    if args.verify:
        print(json.dumps(verify(args.verify.read_bytes()), indent=2))
        return
    require(all(getattr(args, k.replace("-", "_")) is not None for k in ("source", "trial", "producer", "inputs", "chronology", "repo", "base-acquisition", "output")), "all package input paths are required")
    require(not args.output.exists(), "output must be new")
    files = collect(args)
    files["archive-audit.json"] = pretty(audit(files))
    files["evidence-manifest.json"] = pretty({"schema": "hepta.domain-evidence-manifest.v1", "files": {p: metadata(b) for p, b in sorted(files.items())}})
    archive = tar_bytes(files)
    require(archive == tar_bytes(files), "archive build is not deterministic")
    index = verify(archive)
    index.update(schema="hepta.domain-evidence-index.v1", archive_name=ARCHIVE, compression="sorted USTAR plus XZ preset 6; fixed mode/time/owner metadata", repeated_build_identical=True, source_revision=REVISION, external_base_bytes=json.loads(files["base-acquisition.json"])["total_bytes"], runtime_packages_included=False, trial_files=sum(p.startswith("trial/") for p in files), source_files=sum(p.startswith("source_snapshot/") for p in files))
    args.output.mkdir()
    outputs = {ARCHIVE: archive, "bundle-index.json": pretty(index)}
    for name in ("README.md", "PUBLICATION_PLAN.md", "evidence-manifest.json", "archive-audit.json", "domain-chronology.json", "base-acquisition.json", "runtime-requirements.json"):
        outputs[name] = files[name]
    for name, raw in outputs.items():
        (args.output / name).write_bytes(raw)
    (args.output / "SHA256SUMS").write_text("".join(sha(raw) + "  " + name + "\n" for name, raw in sorted(outputs.items())))
    print(json.dumps(index, indent=2))


if __name__ == "__main__":
    main()
