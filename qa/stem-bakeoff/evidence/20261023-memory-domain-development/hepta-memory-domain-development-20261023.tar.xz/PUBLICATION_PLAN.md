# Domain evidence publication plan — separate from procedural replay

Suggested evidence target:
`qa/stem-bakeoff/evidence/20261023-memory-domain-development/`.

Publish the deterministic domain archive, its full evidence manifest, index,
SHA256SUMS and this experiment's standalone README. The original procedural
replay archive remains separate and its already reviewed hash is unchanged.

The domain producer/training/reader sources already exist in
`scripts/memory_cell_domain/` at local revision
`a26aeb74cf63c7489deb5ece7e2b9a86e5697748`. Do not change the executed source or
relabel this finite cohort during evidence publication. Its exact source closure
is captured separately in the archive. The new standard-library packaging/audit
module can be reviewed as a separate code stage below 500 lines, for example at
`scripts/memory_cell_procedure_replay/package_domain_evidence.py`.

The package includes every trial output and all eight saved adapter sets. The
publisher base and installed runtime packages remain external, referenced by
exact base file hashes and recorded dependency versions. Original source bodies,
the exact producer dataset and the three-case chronology are included.

Required claim boundary: short repair-ID recall only; exact retrieval wins the
predeclared source-score/storage rule; split and random split have equal observed
quality; three previously seen source groups; synthetic negatives are not new
incidents; zero validation/future cases; no capacity, net compression, prospective
generalization, procedural execution or production acceptance result.

The chronology audit retains covariance's strict failure→fix→success ordering
and the bind/exception cases' paired-only status. No result rows or costs are
removed. The archive byte audit uses only the standard library. A separate
NumPy-only derivation reexecutes 12 saved router predictions and reconciles the
source-selection slots against retained decoder rows. Those extra audit costs
are recorded separately; there are no additional decoder calls or fits.
`derive_domain_source_routes.py` is a separate code stage below 500 lines.
This task prepares reviewable bytes only; it does not commit or publish them.
