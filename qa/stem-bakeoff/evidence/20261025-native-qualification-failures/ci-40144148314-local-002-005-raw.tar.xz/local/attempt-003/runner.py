import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


ROOT = Path('/workspace/scratch/12ef9c5bdc23')
REPO = ROOT / 'hepta-memory-resume-20261024'
OUT = ROOT / 'memory-resume-control-20261024' / 'shadow-tests-003'
OUT.mkdir(exist_ok=False)
command = ['just', 'test', '--locked', '-p', 'codex-arg0', '-p', 'codex-hepta-memory', '-p', 'codex-hepta-agent-protocol', '-p', 'codex-hepta-agentd', '-p', 'codex-hepta-neuron', '-p', 'codex-hepta-cognitive-store', '--features', 'codex-hepta-agentd/qualification-cognitive-write']
env = dict(os.environ)
env.update(PATH='/tmp/hepta-memory-resume-tools/bin:/tmp/hepta-memory-resume-cargo/bin:' + env['PATH'], RUSTUP_HOME='/tmp/hepta-memory-resume-rustup', CARGO_HOME='/tmp/hepta-memory-resume-cargo', CARGO_TARGET_DIR='/tmp/hepta-memory-resume-target', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1', OPENSSL_DIR='/usr', OPENSSL_LIB_DIR='/usr/lib/x86_64-linux-gnu', OPENSSL_INCLUDE_DIR='/usr/include', PYTHONDONTWRITEBYTECODE='1')
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=REPO).split(b'\0')
before = {p.decode(): hashlib.sha256((REPO / p.decode()).read_bytes()).hexdigest() for p in paths if p and (REPO / p.decode()).is_file()}
(OUT / 'source-before.json').write_text(json.dumps(before, sort_keys=True) + '\n')
receipt = {'command': command, 'cwd': str(REPO / 'codex-rs'), 'started_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(), 'native_model_calls': 0, 'exit_code': None}
subprocess.run(['git', 'diff', '--binary'], cwd=REPO, stdout=(OUT / 'candidate-tracked.patch').open('wb'), check=True)
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
started = time.monotonic()
with (OUT / 'scoped-tests.log').open('wb') as log:
    process = subprocess.Popen(command, cwd=REPO / 'codex-rs', env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt['pid'] = process.pid
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    code = process.wait()
receipt.update(exit_code=code, wall_seconds=time.monotonic()-started, completed_utc=datetime.datetime.now(datetime.UTC).isoformat())
after = {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in before if (REPO / p).is_file()}
receipt['source_unchanged'] = before == after
receipt['log_sha256'] = hashlib.sha256((OUT / 'scoped-tests.log').read_bytes()).hexdigest()
(OUT / 'source-after.json').write_text(json.dumps(after, sort_keys=True) + '\n')
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(code)
