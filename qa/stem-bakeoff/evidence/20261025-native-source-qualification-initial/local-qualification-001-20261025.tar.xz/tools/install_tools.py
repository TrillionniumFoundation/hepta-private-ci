import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import urllib.request


ROOT = Path('/tmp/hepta-memory-resume-tools')
ROOT.mkdir(exist_ok=True)
BIN = ROOT / 'bin'
BIN.mkdir(exist_ok=True)
receipts = []


def download(url, name, expected):
    path = ROOT / name
    with urllib.request.urlopen(url, timeout=60) as response:
        body = response.read()
    actual = hashlib.sha256(body).hexdigest()
    if actual != expected:
        raise ValueError(f'download digest mismatch: {name}')
    path.write_bytes(body)
    receipts.append({'name': name, 'url': url, 'bytes': len(body), 'sha256': actual})
    return path


for url, name, digest, binary in [
    ('https://github.com/casey/just/releases/download/1.59.0/just-1.59.0-x86_64-unknown-linux-musl.tar.gz', 'just.tar.gz', '409044617b6f06517c1035e55ca38c8c856ff8b650e41bc2aa1ef82d5903a23e', 'just'),
    ('https://github.com/nextest-rs/nextest/releases/download/cargo-nextest-0.9.149/cargo-nextest-0.9.149-x86_64-unknown-linux-gnu.tar.gz', 'nextest.tar.gz', '32d1d8c0567b7a80bee2bad8bb09125c846da96bc009b2de11ec08557290c770', 'cargo-nextest'),
]:
    archive = download(url, name, digest)
    with tarfile.open(archive) as source:
        matches = [member for member in source if member.isfile() and Path(member.name).name == binary]
        if len(matches) != 1:
            raise ValueError('archive must contain exactly one requested binary')
        (BIN / binary).write_bytes(source.extractfile(matches[0]).read())
        (BIN / binary).chmod(0o755)
    print(binary, 'verified', flush=True)

url = 'https://static.rust-lang.org/rustup/dist/x86_64-unknown-linux-gnu/rustup-init'
with urllib.request.urlopen(url + '.sha256', timeout=60) as response:
    expected = response.read().decode().split()[0]
installer = download(url, 'rustup-init', expected)
installer.chmod(0o755)
env = dict(os.environ, RUSTUP_HOME='/tmp/hepta-memory-resume-rustup', CARGO_HOME='/tmp/hepta-memory-resume-cargo')
result = subprocess.run([str(installer), '-y', '--no-modify-path', '--profile', 'minimal', '--default-toolchain', '1.95.0', '--component', 'rustfmt,clippy,rust-src'], env=env)
receipts.append({'rustup_exit_code': result.returncode})
(ROOT / 'install-receipt.json').write_text(json.dumps(receipts, indent=2) + '\n')
raise SystemExit(result.returncode)
