# Historical CI incident candidates

`candidate_cohort.json` is a small source-pinned inventory of ten already
inspected natural CI repair pairs in `TrillionniumFoundation/hepta-private-ci`.
It retains failed/successful run IDs, workflow/commit/time metadata, direct-parent
commit pins, changed-file Git blob hashes and source URLs. It is not a repository
census or an untouched future dataset.

Eight pairs meet the strict observed time order: hosted failure completed,
direct-parent fix committed, then same-workflow successful run started. The
newline, hosted loader and Git index cases have full original source/log bundles
and completed local replay under the separate `procedural-replay-work` directory.
The other five are seed-averaged CVaR assertions, actual JPEG positive-fixture
custody, cross-split task-ID alias fixtures, Rust test formatting, and independent
crate-identity error assertions. Every curated fix changes tests or fixtures.

Two additional pairs are not eligible for a sequential failure-response cohort:
the nine-arm per-query assertion fix and causal receipt emission-cost fixture fix
were committed before the corresponding hosted failure completed. A later
successful run and direct-parent relationship cannot repair that chronology.

The retained query snapshot returned zero failed runs created after the existing
registration cutoff. That is a bounded observation at inspection time, not a
promise that no later failure can occur. All ten candidate sources and outcomes
have now been seen by the experimenters. Relabeling them as future would not make
them prospective. With the available inspected evidence, untouched future count
is zero and capacity/interference pressure has not been established. Subtests,
query paraphrases and multiple arms must not be counted as independent incidents.
