# Compact evidence package

This package preserves the exact bytes of the two executed, unformatted replay
modules. The frozen plan pins those bytes. Any readable repository copies may be
formatted only with a separate AST-equivalence receipt; reproduction uses the
archived pinned copies, not a later formatted copy.

The archive includes the complete original replay source/evidence closure, all
three original patch files, the pre-execution plan, all 15 raw command receipts,
all retained command logs, actual diffs, result, environment receipt, and the
original archive audit. It also retains the previously inspected candidate
inventory and the separate three-domain-input chronology source records.

All failed and nonreproduced arms remain present. Four suites failed; loader was
nonreproduced in the observed local environment. No outcome is filtered out.

## Deliberate omissions and two distinct audits

`run-001/<case>/<arm>/work/` directories are disposable materializations of the
original source bundle plus the pinned repair. Their source copies and generated
local Git metadata are omitted. No other original replay evidence is omitted.

The unchanged `run-001/archive-audit.json` audited the original complete local
run directory, including those work copies. Its original file counts/byte counts
remain historical facts; they are not silently reinterpreted as archive counts.
It must not be used as a claim that the omitted directories are still packaged.

`packaging-audit.json` is a new, separate read-only consistency audit. It verifies
the original plan inputs and code, every retained command log and actual diff,
and each before/after source hash in all 15 receipts against the retained source
bundle. It verifies that the actual diff reconstructs the expected fixed file.
Its omission list names every original disposable file omitted from the package.
This audit does not rerun tests, execute patches, invoke models, or add new
scientific evidence. Neither audit is an independent security principal.

`evidence-manifest.json` lists each archived payload file's exact SHA-256, byte
length, role and full relative path, including all original source hashes. The
manifest cannot hash itself; its own hash and the complete compressed archive
hash are in the external `bundle-index.json` and `SHA256SUMS`.

The tar stream has sorted member order, fixed mode 0644, UID/GID 0, empty owner
names and mtime 0. Gzip has an empty filename and mtime 0. The package builder
constructs it twice and requires identical compressed bytes. No symlinks, device
files, executable hooks or absolute member paths are included.

## Reproduce from the exact archived copies

Verify the archive against `SHA256SUMS`, then extract into a new empty directory.
Within the archive's `hepta-ci-repair-replay-20261023` directory run:

```bash
python3 -B replay_run.py \
  --plan protocol-001/plan.json \
  --expected-plan-sha256 42b47342a3c62bff6b273dd1b6a06c23b1968babd4109f6dfff98b64f0abf700 \
  --output reproduction-001
```

This executes all 15 suites again and creates fresh work copies. The original
`run-001` is never overwritten. Python 3.12 and Git are needed; no Torch or model
checkpoint is needed. Raw original receipts retain their original absolute
working-directory paths as provenance rather than rewriting them during export.
The source/runtime limits and nonreproduction rule in the original plan remain
in force. A changed environment can produce different observed outcomes.

## Separate domain chronology

The domain416 input cases are different from the three procedural replay cases.
Their original input manifest, exact run/commit records and raw job logs are under
`related/domain-inputs/`. `domain-chronology.json` checks timestamps and hashes
without reading model scores or modifying any running source/data/protocol.
`source-versioning.json` records where the already tracked producer lives.
