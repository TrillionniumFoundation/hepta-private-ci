# Reviewable publication plan — prepared, not published

No file in the running `hepta-memory-work` checkout has been changed by this
packaging task. No remote repository mutation, commit, PR or upload is included.

## Proposed stages

| Stage | Suggested repository targets | Code scope |
| --- | --- | --- |
| 1. Readable replay source | `scripts/memory_cell_procedure_replay/replay_bundle.py`, `replay_run.py` | Exact executed sources are 178 + 280 = 458 lines. Both files are individually below 500 lines. Preserve originals in the archive; any later formatting needs AST-equivalence evidence. |
| 2. Archive construction and audit | `scripts/memory_cell_procedure_replay/package_evidence.py` | Separate bounded module, independently reviewable, no model or quality rerun. Its exact line count and hash are in the bundle index. |
| 3. Historical evidence | `qa/stem-bakeoff/evidence/20261023-natural-ci-repair-replay/` | Deterministic archive, manifest, index, SHA256SUMS, README/PACKAGING, chronology and publication notes. Generated evidence is separate from behavior changes. |
| 4. Candidate provenance | Same evidence directory under `inputs/candidate-cohort/` | The two small candidate inventory files are copied byte for byte from the archive; do not add them as trained memory or untouched future data. |

The standalone original modules resolve their data relative to their own
directory. Reproduction therefore uses the complete extracted archive, which
contains the exact source/evidence closure adjacent to the pinned modules.
Readable source copies at the scripts target are review/maintenance copies;
their presence alone does not install a complete replay bundle. No runtime path
refactor is proposed in this publication stage.

## Already versioned domain source

The producer and domain experiment are already tracked in local HEAD
`a26aeb74cf63c7489deb5ece7e2b9a86e5697748` under
`scripts/memory_cell_domain/`: `domain_data.py`, `domain_baselines.py`,
`domain_training.py`, `domain_trial.py`, two tests and README. Read-only checks
found no changes to this subtree against that HEAD. The publication task neither
duplicates nor changes those source files. `source-versioning.json` records
their exact full hashes. This is a local source-version observation, not an
assertion that the commit has already been published remotely.

For the domain run's eventual evidence publication, retain its original manifest,
run/commit/log source inputs and generated dataset beside its fixed protocol and
actual output, for example under
`qa/stem-bakeoff/evidence/20261023-memory-domain-development/inputs/`.
The same input sources are included here only to support the chronology audit;
the current domain results are neither read nor repackaged by this task.

## Required review statements

- Two reproduced local historical repairs; one nonreproduced loader incident.
- Same three-action library; real git apply and original test command in every arm.
- Wrong action is a preimage-rejected action followed by real tests.
- Exact and TF-IDF retrieve known original symptoms; no learned-policy result.
- All real fixes modify tests/fixtures; production runner and workflow stay byte-identical.
- All four failed suites and every nonreproduced-arm result remain available.
- Preserve the existing artificial procedure benchmark's negative strong-baseline result.
- Domain bind-fixture and exception-order pairs are historical paired evidence,
  because their repair commits predate hosted failure completion; only covariance
  has the strict failure-completion → fix → success chronology.
- No prospective cohort, capacity pressure, general memory or production acceptance claim.

The compact package has a new audit covering omitted disposable work copies.
The original audit remains unchanged and explicitly refers to the original full
directory. Review the outer index and full SHA-256 manifest before any eventual
publication. Any approval or publication decision remains with the parent task.
