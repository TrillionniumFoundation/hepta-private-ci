"""Build a deterministic compact archive without rerunning any experiment."""

import argparse
from collections import Counter
from datetime import datetime
import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile


DOMAIN_REVISION = "a26aeb74cf63c7489deb5ece7e2b9a86e5697748"
PLAN_SHA = "42b47342a3c62bff6b273dd1b6a06c23b1968babd4109f6dfff98b64f0abf700"
PREFIX = "hepta-ci-repair-replay-20261023"
TEST = "scripts/test_run_hepta_local_closeout.py"


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def record(data):
    return {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def load(path):
    return json.loads(path.read_bytes())


def instant(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def collect(root):
    files = {}
    top = ("replay_bundle.py", "replay_run.py", "package_evidence.py", "README.md",
           "PACKAGING.md", "PUBLICATION_PLAN.md")
    members = [root / name for name in top]
    for name in ("source_bundle", "evidence", "protocol-001", "run-001"):
        members.extend(path for path in (root / name).rglob("*") if path.is_file())
    omitted = []
    for path in sorted(members):
        relative = path.relative_to(root)
        if path.is_symlink():
            raise ValueError("no symlink evidence members")
        if relative.parts[0] == "run-001" and "work" in relative.parts:
            omitted.append({"path": str(relative), **record(path.read_bytes())})
        else:
            files[str(relative)] = path.read_bytes()
    return files, omitted


def audit_replay(files, omitted):
    plan = json.loads(files["protocol-001/plan.json"])
    if record(files["protocol-001/plan.json"])["sha256"] != PLAN_SHA:
        raise ValueError("original frozen plan changed")
    for name, expected in {**plan["inputs"], **plan["code"]}.items():
        if record(files[name]) != expected:
            raise ValueError(f"original plan member changed: {name}")
    cases = {case["id"]: case for case in plan["cases"]}
    rows = []
    for case in plan["cases"]:
        if record(files["protocol-001/" + case["patch"]]) != case["patch_record"]:
            raise ValueError("action patch changed")
        fixed = files[f"source_bundle/{case['after']}/{TEST}"]
        git_blob = hashlib.sha1(f"blob {len(fixed)}\0".encode() + fixed).hexdigest()
        if git_blob != case["fixed_git_blob_sha1"]:
            raise ValueError("fixed source differs from original GitHub blob")
        for arm in plan["arms"]:
            prefix = f"run-001/{case['id']}/{arm}/"
            receipt = json.loads(files[prefix + "receipt.json"])
            before = {path: record(files[f"source_bundle/{case['before']}/{path}"])
                      for path in receipt["before"]}
            if before != receipt["before"]:
                raise ValueError("before source cannot be reconstructed")
            original = files[f"source_bundle/{case['before']}/{TEST}"]
            after_bytes, after = original, dict(before)
            if receipt["action_status"] == "applied":
                action = cases[receipt["selected_action"]]
                if record(original)["sha256"] != action["preimage"]:
                    raise ValueError("admitted action preimage mismatch")
                after_bytes = files[f"source_bundle/{action['after']}/{TEST}"]
                after[TEST] = record(after_bytes)
            if after != receipt["after_action"] or after != receipt["after_tests"]:
                raise ValueError("after source cannot be reconstructed")
            expected_diff = "".join(difflib.unified_diff(
                original.decode().splitlines(keepends=True),
                after_bytes.decode().splitlines(keepends=True),
                fromfile=f"a/{TEST}", tofile=f"b/{TEST}")).encode()
            if files[prefix + "actual.diff"] != expected_diff:
                raise ValueError("actual diff differs from reconstructed source")
            if record(expected_diff) != receipt["actual_diff"]:
                raise ValueError("recorded actual diff digest mismatch")
            for command in receipt["commands"]:
                if record(files[prefix + command["log"]]) != command["log_record"]:
                    raise ValueError("raw command log changed")
            if receipt["commands"][-1]["command"] != plan["command"]:
                raise ValueError("original command changed")
            rows.append({"case": case["id"], "arm": arm,
                         "before_reconstructed_sha256": {k: v["sha256"] for k, v in before.items()},
                         "after_reconstructed_sha256": {k: v["sha256"] for k, v in after.items()},
                         "exit_code": receipt["commands"][-1]["exit_code"],
                         "action_status": receipt["action_status"],
                         "original_observer": receipt["observer"]})
    original_audit = json.loads(files["run-001/archive-audit.json"])
    if record(files["run-001/result.json"]) != original_audit["result"]:
        raise ValueError("result differs from original archive audit")
    return {"schema": "hepta.historical-replay.compact-package-audit.v1",
            "plan_sha256": PLAN_SHA, "source_and_command_integrity_passed": True,
            "original_audit_preserved_unmodified": True,
            "original_audit_scope": "Original complete local run, including work copies; not the compact archive",
            "compact_audit_scope": "Read-only reconstruction of all omitted source copies and retained log/diff hashes",
            "tests_rerun": 0, "model_calls": 0, "patches_executed": 0,
            "omitted_files": omitted, "omitted_bytes": sum(row["bytes"] for row in omitted),
            "omissions_are_only_disposable_work_materializations": True,
            "arm_audits": rows, "independent_security_principal": False}


def domain_inputs(directory, files):
    manifest = load(directory / "manifest.json")
    required = {"manifest.json", manifest["runs"]["path"]}
    rows = load(directory / manifest["runs"]["path"])
    runs = rows["workflow_runs"] if isinstance(rows, dict) else rows
    index = {run["id"]: run for run in runs}
    if record((directory / manifest["runs"]["path"]).read_bytes())["sha256"] != manifest["runs"]["sha256"]:
        raise ValueError("domain run metadata digest mismatch")
    chronology = []
    for case in manifest["cases"]:
        for key in ("fix", "failure_log", "success_log"):
            pin = case[key]
            raw = (directory / pin["path"]).read_bytes()
            if record(raw)["sha256"] != pin["sha256"]:
                raise ValueError("domain original input changed")
            required.add(pin["path"])
        failed, succeeded = index[case["failed_run_id"]], index[case["success_run_id"]]
        commit = load(directory / case["fix"]["path"])
        fixed = commit["commit"]["committer"]["date"]
        errors = [line for line in (directory / case["failure_log"]["path"]).read_text().splitlines()
                  if "##[error]Process completed with exit code 1" in line]
        test_exit = errors[-1].split()[0] if errors else None
        strict = instant(failed["updated_at"]) < instant(fixed) < instant(succeeded["created_at"])
        for run in (failed, succeeded):
            required.add(f"jobs-{run['id']}.json")
        chronology.append({
            "id": case["id"], "repair_id": case["repair_id"], "fix_commit": commit["sha"],
            "direct_parent": [parent["sha"] for parent in commit["parents"]] == [failed["head_sha"]],
            "failed_run_id": failed["id"], "failure_test_exit_at": test_exit,
            "failed_run_completed_updated_at": failed["updated_at"], "fix_committed_at": fixed,
            "success_run_id": succeeded["id"], "success_created_at": succeeded["created_at"],
            "success_completed_updated_at": succeeded["updated_at"],
            "classification": "strict_chronological_historical_pair" if strict else "paired_historical_only",
            "fix_predates_hosted_failure_completion": instant(fixed) < instant(failed["updated_at"]),
            "failure_url": failed.get("html_url"), "success_url": succeeded.get("html_url"),
            "fix_url": f"https://github.com/TrillionniumFoundation/hepta-private-ci/commit/{commit['sha']}",
        })
    input_records = {}
    for name in sorted(required):
        data = (directory / name).read_bytes()
        files["related/domain-inputs/" + name] = data
        input_records[name] = record(data)
    return {"schema": "hepta.domain-input-chronology-audit.v1", "cases": chronology,
            "inputs": input_records, "quality_results_consulted": False,
            "domain_source_data_partitions_protocol_modified": False,
            "all_cases_remain_known_finite_development": True,
            "timestamp_order_is_not_proof_of_developer_awareness": True}


def source_versioning(repo):
    subtree = "scripts/memory_cell_domain"
    names = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", DOMAIN_REVISION, subtree], cwd=repo, text=True).splitlines()
    members = []
    for name in names:
        versioned = subprocess.check_output(["git", "show", f"{DOMAIN_REVISION}:{name}"], cwd=repo)
        if (repo / name).read_bytes() != versioned:
            raise ValueError("domain source differs from expected pinned local revision")
        members.append({"path": name, **record(versioned), "lines": len(versioned.splitlines())})
    return {"schema": "hepta.replay-publication.source-versioning.v1",
            "domain_producer_already_tracked": True, "domain_revision": DOMAIN_REVISION,
            "remote_publication_of_revision_asserted": False, "domain_source_members": members,
            "suggested_procedure_code_target": "scripts/memory_cell_procedure_replay/",
            "suggested_procedure_evidence_target": "qa/stem-bakeoff/evidence/20261023-natural-ci-repair-replay/",
            "suggested_candidate_inventory_target": "qa/stem-bakeoff/evidence/20261023-natural-ci-repair-replay/inputs/candidate-cohort/",
            "suggested_domain_input_target": "qa/stem-bakeoff/evidence/20261023-memory-domain-development/inputs/",
            "domain_source_changes_proposed": False}


def role(name):
    if name.startswith("source_bundle/"):
        return "original_source"
    if name in ("replay_bundle.py", "replay_run.py"):
        return "exact_executed_unformatted_code"
    if name.endswith(".py"):
        return "packaging_code"
    if name.startswith("protocol-001/"):
        return "pre_execution_protocol_or_original_patch"
    if name.startswith("evidence/"):
        return "original_hosted_evidence"
    if name.startswith("run-001/"):
        return "actual_local_execution_evidence"
    if name.startswith("related/"):
        return "related_provenance_not_new_training"
    return "review_document_or_package_audit"


def archive_bytes(files):
    output = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=output, compresslevel=9, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            for name, data in sorted(files.items()):
                member = tarfile.TarInfo(f"{PREFIX}/{name}")
                member.size, member.mode, member.mtime = len(data), 0o644, 0
                member.uid = member.gid = 0
                member.uname = member.gname = ""
                archive.addfile(member, io.BytesIO(data))
    return output.getvalue()


def build(args):
    files, omitted = collect(args.source)
    audit = audit_replay(files, omitted)
    chronology = domain_inputs(args.domain_inputs, files)
    versioning = source_versioning(args.repo)
    for path in sorted(args.candidate_inputs.iterdir()):
        if path.is_file() and path.name in ("README.md", "candidate_cohort.json"):
            files["related/candidate-cohort/" + path.name] = path.read_bytes()
    generated = {"packaging-audit.json": encoded(audit),
                 "domain-chronology.json": encoded(chronology),
                 "source-versioning.json": encoded(versioning)}
    files.update(generated)
    members = [{"path": name, "role": role(name), **record(data)} for name, data in sorted(files.items())]
    manifest = encoded({"schema": "hepta.historical-replay.evidence-manifest.v1",
                        "experiment_plan_sha256": PLAN_SHA, "members": members,
                        "manifest_self_hash_in_outer_index": True,
                        "historical_raw_evidence_rewritten": False})
    files["evidence-manifest.json"] = manifest
    archive = archive_bytes(files)
    if archive != archive_bytes(files):
        raise ValueError("archive construction is not deterministic")
    with tarfile.open(fileobj=io.BytesIO(archive), mode="r:gz") as packed:
        for member in packed.getmembers():
            if not member.isfile() or member.name != PREFIX + "/" + member.name.removeprefix(PREFIX + "/"):
                raise ValueError("unexpected archive member")
            if packed.extractfile(member).read() != files[member.name.removeprefix(PREFIX + "/")]:
                raise ValueError("compressed payload differs from audited bytes")
    filename = PREFIX + ".tar.gz"
    index = {"schema": "hepta.historical-replay.bundle-index.v1", "archive": {"path": filename, **record(archive)},
             "manifest": {"path": "evidence-manifest.json", **record(manifest)},
             "archive_members_including_manifest": len(files),
             "uncompressed_payload_bytes": sum(map(len, files.values())),
             "roles": dict(sorted(Counter(row["role"] for row in members).items())),
             "code": [{"path": name, "lines": len(files[name].splitlines()), **record(files[name])}
                      for name in ("replay_bundle.py", "replay_run.py", "package_evidence.py")],
             "code_stages": [{"stage": 1, "files": ["replay_bundle.py", "replay_run.py"], "lines": 458},
                             {"stage": 2, "files": ["package_evidence.py"], "lines": len(files["package_evidence.py"].splitlines())}],
             "deterministic_double_build_equal": True, "compressed_members_verified": True,
             "source_reconstruction_verified_for_arms": len(audit["arm_audits"]),
             "omitted_disposable_files": len(omitted), "omitted_disposable_bytes": audit["omitted_bytes"],
             "tests_rerun": 0, "model_calls": 0, "remote_mutations": 0,
             "published": False, "original_audit_scope_preserved": True}
    args.output.mkdir(parents=True, exist_ok=False)
    outputs = {**generated, filename: archive, "evidence-manifest.json": manifest,
               "bundle-index.json": encoded(index)}
    for name, data in sorted(outputs.items()):
        (args.output / name).write_bytes(data)
    checksums = "".join(f"{record(data)['sha256']}  {name}\n" for name, data in sorted(outputs.items()))
    (args.output / "SHA256SUMS").write_text(checksums)
    print(json.dumps(index, indent=2, sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--domain-inputs", required=True, type=Path)
    parser.add_argument("--candidate-inputs", required=True, type=Path)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    build(parser.parse_args())
