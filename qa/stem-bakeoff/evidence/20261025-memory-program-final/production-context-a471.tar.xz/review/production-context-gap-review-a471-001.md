# 生产上下文接线复核：a47190bb

审查源提交：`a47190bb84714cb1262fcd85ebb723081fdb0581`。本次仅静态只读审查；27 个逐文件 SHA 与该提交的 Git 原始内容一致，附带四组全树引用搜索和旧调查逐文件比较。未实现 provider，未运行 Rust、测试、模型或 SQLite，未改主工作树。

## 结论

**Objective 的真实签名接入、durable RunStart 和当前授权复核已经存在，可以直接复用。NDU 的认证 owner 库也存在，但未接入 Agentd；缺少带当前授权、选择版本和新鲜度的读取证明。** 因此代码接线可以继续做，实际启用必须等待真实 owner 配置及能力，不得将资格 fixture 升格为生产 provider。

## 可复用的具体路径与缺口

| 部位 | 当前真实 API / 构造点 | 最小缺口 |
| --- | --- | --- |
| Objective | `main.rs:150` 载入 profile；`runtime.rs:176` 打开并安装 `ObjectiveRuntimeHost`；`state_control.rs:224` 的 `ObjectiveStart` 调用 `submit`；`objective_runtime.rs:208` 发布 durable RunStart | 在 host 内添加按明确 `run_id` 读取已发布记录的窄接口。复用 `state.rs:708` 私有 `require_current_run_start`，加上 `AgentRunCoordinator::run(run_id)` 的 phase、revision、deadline 检查。读取不能顺便重新启动 run。 |
| NDU | `hepta-ndu/src/owner.rs` 公开 `NduAuthenticatedOwnerV1::open`、`apply_mutation`、`selected_projection_digest`；认证变更和 durable store 已有 | 全树无生产 owner 构造或 Agentd 挂载。`selected_projection_digest` 只核对本地权威 store；`context()` 是 open 时的固定值。需要真实 owner 挂载与不透明、版本化的 current-projection receipt。 |
| Authority | `FinalUseAuthority::open_state_dir_with_issuer_keys`、`AuthorityClock`、`AuthorityFrontierStore`、`FinalUseRevocationFeedVerifier::apply` 可复用 | 前两种 external-trust 构造器当前只有 contract tests 调用。`frontier()` / `revocation_head()` 是本地头，不能自行证明外部撤回 feed 新鲜。生产激活需真实 keys、clock、独立 CAS frontier 和 feed。 |
| Native 安装 | `native_memory_cell`、`shadow_owner`、`with_native_memory_cell` 仍受 `qualification-cognitive-write` 门控；runtime 在 Objective host 之前接收预构造 cell | 添加要求真实能力的生产工厂，安排在实际 owner 就绪后；加入独立 shadow 路由。现有 control 仅执行 v1 `start/status`，不能视为 v2 已接线。 |
| 上下文与恢复 | `NativeMemoryContextAuthorityV1::current` 已覆盖执行前后与交付复核；真实 objective 已进 journal/witness，source/model/profile 已进 namespace | 当前 ingress 没有 `run_id`，context 比较没有 run / authority 版本。新接口需绑定明确 run、真实 NDU subject 与版本化证明，并保存在结果及恢复 namespace。不要用合成摘要冒充真实 Objective / NDU 摘要。 |

`AgentdIntelligenceInvocationProviderV1::build` 是可复用的宿主组合接口，但全树没有实现，CLI 只安装 runner。`plasticity_process_bootstrap.rs` 从 descriptor 读取 journal 后创建新的 `Arc<RwLock<_>>`；resolver 观察该 Arc 的变化，不等于挂载真实 `NduAuthenticatedOwnerV1` 的当前授权和持久选择。

## 最小实施顺序

| 阶段 | 可直接编码的工作 | 真正启用所需输入 |
| --- | --- | --- |
| 1 | Objective 窄读取接口；明确 run；重用当前 AuthBus/Fleet 复核并加入 run 生命周期 | 实际 AuthBus trust、独立 replay checkpoint、owner profile 和已接纳的 run |
| 2 | Agentd NDU capability/config/state 挂载；owner 内产生当前选择证明，绑定 journal head、policy、owner 和授权版本 | 真实 owner identity/policy、run→subject 映射、签名授权/撤回 feed、受保护时钟和独立单调 frontier |
| 3 | 版本化 native bridge；真实 owner 就绪后创建 cell；proof 绑定结果/恢复域；独立 shadow control 路径 | 实际 recovered writer/source 能力、固定 model/profile、独立保留的 witness 与文件所有权策略 |
| 4 | 对真实产品路径冻结并独立资格验证：取消、过期、key/feed 轮换、选择/撤回/ABA、交付前变更、重启与 witness 恢复 | 前三阶段的真实运行配置；若未来请求 calibrated 模式，再单独提供合法校准数据及 receipt |

前三阶段属于工程实现缺口。缺少运营输入时可以构建接口并保持拒绝激活，不能伪造输入，也不应把所有实现工作统称为外部阻塞。

## 版本一致性约束

- `authentication.key_epoch` 是 AuthBus issuer key 版本；`snapshot.authority_epoch` 来自经过签名的 Objective request body，两者不能直接等同。
- Objective `generation/fence` 要匹配刷新的 Fleet/Agentd 状态；RunStart 仍存在不代表 run 仍 active，phase、revision、deadline 必须复核。
- FinalUse 的 `authority_epoch/revocation_revision` 与 signed-feed 有效期属于其自身授权域。NDU owner 的 principal、scope、host generation、fence、policy 与 frontier 必须匹配真实配置，跨域 generation 关系要显式定义。
- model generation 已与 production writer generation 比较；body generation、NDU owner generation、issuer epoch 仍各有语义，不能合成一个无来源整数。
- 同一 projection 内容的 A→B→A 会逃过仅比较 payload digest 的检查；必须绑定单调的 journal/selection 版本及授权证明，并在最终交付复核。多 owner 的读取一致性需要定义线性化边界，不能仅凭两个先后摘要宣称原子性。
- 同进程 `Instant` 的 Recover 不证明跨进程时钟连续性；需要明确的 clock segment / generation 或真实连续性证明。

## 资格边界

本次没有发现已运行的 production NDU provider，也没有完成生产安装。现有真实模型 shadow 资格仍是 controlled context、未校准、abstain / DENY_ALL；默认 daemon、跨进程连续性和完整生产授权链不能由它推导。八个研究 blocker 的关闭状态仍全部为 false。

完整逐条依据、27 个 source pins、引用搜索、旧调查比较与操作边界在同名 JSON 中。旧调查保持原提交归属，没有重新贴上 a471 标签。
