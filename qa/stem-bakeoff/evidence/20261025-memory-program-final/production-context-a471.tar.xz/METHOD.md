# Capsule method and scope

This is a source-bound static review, not an execution qualification.
The original review JSON and Markdown are preserved byte for byte.
The reviewer identity and original timestamp are retained in provenance/review-identity.json.
The older investigation is retained with its original bytes and attribution; it is not relabelled to a471.

## Capture

1. Require the primary checkout HEAD to equal a47190bb84714cb1262fcd85ebb723081fdb0581 and its porcelain status to be empty.
2. For each of the 27 review pins, read `git show <head>:<path>` as raw bytes; compare length and SHA-256 with the original review.
3. Compare each raw blob with the current working file and its Git object ID from `git ls-tree`; retain Git mode 100644.
4. Preserve the raw commit object; recompute its SHA-1 with the Git `commit <length> NUL` header.
5. Re-run only the four recorded rg searches against the clean exact checkout; retain actual stdout and compare the match multisets with the original review.
6. Preserve the draft scope-review receipt and old draft SHA. Record six corrected excerpts and the revised draft SHA; do not copy either complete draft.
7. Use standard-library JSON, SHA-256, tar and XZ operations to package the bytes. No repository source, model, Rust, test or SQLite code is executed.
8. Read every tar member back; require exact name, mode, size and bytes. Check original review inputs and all 27 working sources remain unchanged.

## Layout

- review/: original a471 review JSON and Markdown.
- source/: exact 27 reviewed Rust blobs under their repository-relative paths.
- searches/: four raw rg stdout files plus commands, counts and match comparisons.
- provenance/: commit object, source inventory and original review identity.
- prior-investigation/: original earlier investigation, retaining its earlier source attribution.
- draft-review/: original scope-review receipt and correction record; no full draft.
- inventory.json: SHA-256 and size for every payload member other than the inventory itself.

## Reproduction and limits

Verify the outer archive SHA-256 and every inventory item before reading conclusions.
The 27 source files support the specific reviewed API statements; this is not a full repository snapshot.
Reproducing absence searches requires the complete exact Git checkout, not the excerpt alone.
Search stdout is a capture from a trusted local read-only inspection, not hardware attestation.
The source review distinguishes implementable bridge work from authentic deployment inputs.
It does not install a production provider, supply an authenticated live NDU owner, establish clock continuity, or close any research blocker.
The draft retained a471 CI as pending at capture; this capsule neither fetches nor certifies later CI status.
The older 33c execution and 595-check audit remain separate immutable evidence.

## Packaging convention

Member names are sorted; tar uid/gid and mtime are zero, names blank, and file modes are 0644.
This normalization describes archive reproducibility, not original production filesystem permissions.
The archive contains regular files only; all source bytes retain their original contents.
