"""Record a new bootstrap-repair test cycle, before its final fix/format."""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time


parser = argparse.ArgumentParser()
parser.add_argument('--name', required=True)
parser.add_argument('--filter')
args = parser.parse_args()
if not re.fullmatch(r'bootstrap-[a-z0-9-]+', args.name):
    raise SystemExit('invalid task-specific evidence name')
ROOT = Path('/workspace/scratch/12ef9c5bdc23')
REPO = ROOT / 'hepta-memory-resume-20261024'
OUT = ROOT / 'memory-resume-control-20261024' / args.name
OUT.mkdir(exist_ok=False)
cases = OUT / 'raw-cases'
cases.mkdir(mode=0o700)
command = ['just', 'test', '--locked', '-p', 'codex-hepta-memory']
if args.filter:
    command.extend(['-E', args.filter])
env = dict(os.environ)
env.update(PATH='/tmp/hepta-memory-resume-tools/bin:/tmp/hepta-memory-resume-cargo/bin:' + env['PATH'], RUSTUP_HOME='/tmp/hepta-memory-resume-rustup', CARGO_HOME='/tmp/hepta-memory-resume-cargo', CARGO_TARGET_DIR='/tmp/hepta-memory-resume-target', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1', OPENSSL_DIR='/usr', OPENSSL_LIB_DIR='/usr/lib/x86_64-linux-gnu', OPENSSL_INCLUDE_DIR='/usr/include', PYTHONDONTWRITEBYTECODE='1', HEPTA_MEMORY_CRASH_EVIDENCE_ROOT=str(cases))


def git(*values):
    return subprocess.check_output(['git', *values], cwd=REPO)


def inventory():
    result = {}
    for item in git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split(b'\0'):
        if not item:
            continue
        path = REPO / os.fsdecode(item)
        if path.is_symlink():
            data = os.fsencode(os.readlink(path))
            kind = 'symlink-text'
        elif path.is_file():
            data = path.read_bytes()
            kind = 'regular-file'
        else:
            continue
        result[os.fsdecode(item)] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'mode': oct(path.lstat().st_mode & 0o777), 'kind': kind}
    return result


before = inventory()
(OUT / 'source-before.json').write_text(json.dumps(before, sort_keys=True) + '\n')
candidate_paths = set(git('diff', '--name-only', '-z').split(b'\0')) | set(git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0'))
for item in candidate_paths:
    if not item:
        continue
    relative = os.fsdecode(item)
    path = REPO / relative
    if not path.is_file() or path.is_symlink():
        continue
    target = OUT / 'executed-candidate-sources' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
(OUT / 'candidate-tracked.patch').write_bytes(git('diff', '--binary'))
receipt = {'command': command, 'cwd': str(REPO / 'codex-rs'), 'started_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'base_head': git('rev-parse', 'HEAD').decode().strip(), 'scope': 'new initial-generation WAL permission repair cycle; tests precede this repair final fix/format', 'source_inventory_semantics': 'file bytes and modes, symlink link-text', 'pretrained_model_commands_started_by_wrapper': 0, 'raw_case_root': str(cases), 'exit_code': None}
proc_status = Path('/proc/self/status')
if proc_status.is_file():
    mask = next((line.split(':', 1)[1].strip() for line in proc_status.read_text().splitlines() if line.startswith('Umask:')), None)
    receipt['wrapper_linux_proc_umask_without_mutation'] = mask
else:
    receipt['wrapper_linux_proc_umask_without_mutation'] = None
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'started': receipt['started_utc'], 'command': command, 'out': str(OUT)}), flush=True)
started = time.monotonic()
with (OUT / 'scoped-tests.log').open('wb') as log:
    child = subprocess.Popen(command, cwd=REPO / 'codex-rs', env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt['pid'] = child.pid
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    code = child.wait()
receipt.update(exit_code=code, wall_seconds=time.monotonic() - started, completed_utc=datetime.datetime.now(datetime.UTC).isoformat())
after = inventory()
receipt['source_unchanged_during_tests'] = before == after
receipt['changed_source_paths_during_tests'] = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
receipt['log_sha256'] = hashlib.sha256((OUT / 'scoped-tests.log').read_bytes()).hexdigest()
(OUT / 'source-after.json').write_text(json.dumps(after, sort_keys=True) + '\n')
raw = {}
for path in sorted(cases.rglob('*')):
    if path.is_file() and not path.is_symlink():
        data = path.read_bytes()
        raw[path.relative_to(cases).as_posix()] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'mode': oct(path.stat().st_mode & 0o777)}
(OUT / 'raw-case-file-inventory.json').write_text(json.dumps(raw, sort_keys=True, indent=2) + '\n')
receipt['retained_case_files'] = len(raw)
receipt['retained_case_file_bytes'] = sum(v['bytes'] for v in raw.values())
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(code)
