"""Seal completed raw qualification evidence; never open SQLite or run Rust."""

from pathlib import Path
import hashlib
import io
import json
import shutil
import stat
import tarfile


ROOT = Path("/workspace/scratch/12ef9c5bdc23")
BASE = ROOT / "native-failure-recovery-20261024/bootstrap-qualification-20261025"
PAYLOAD = BASE / "payload"
CONTROL = ROOT / "memory-resume-control-20261024"
ATTEMPTS = ["bootstrap-baseline-001", "bootstrap-fixed-001", "bootstrap-scoped-001", "bootstrap-final-fix-001", "bootstrap-final-format-001"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify_originals():
    results = []
    for name in ATTEMPTS:
        source = CONTROL / name
        expected = json.loads((PAYLOAD / "inventories" / (name + "-original.json")).read_bytes())
        assert {p.relative_to(source).as_posix() for p in source.rglob("*")} == set(expected)
        for relative, item in expected.items():
            path = source / relative
            metadata = path.lstat()
            assert stat.S_IMODE(metadata.st_mode) == item["mode"]
            assert metadata.st_mtime_ns == item["mtime_ns"] and metadata.st_ctime_ns == item["ctime_ns"]
            assert metadata.st_ino == item["inode"] and metadata.st_dev == item["device"]
            assert metadata.st_nlink == item["links"] and metadata.st_uid == item["uid"] and metadata.st_gid == item["gid"]
            if item["kind"] == "file":
                data = path.read_bytes()
                assert len(data) == item["bytes"] and sha(data) == item["sha256"]
        results.append({"attempt": name, "entries": len(expected), "files": sum(v["kind"] == "file" for v in expected.values()), "file_bytes": sum(v.get("bytes", 0) for v in expected.values()), "original_bytes_modes_identity_timestamps_unchanged": True})
    for filename in ["extra-inputs-original.json", "publication-inputs-original.json"]:
        for relative, item in json.loads((PAYLOAD / "inventories" / filename).read_bytes()).items():
            source = Path(item["source"])
            data = source.read_bytes()
            assert len(data) == item["bytes"] and sha(data) == item["sha256"]
            assert stat.S_IMODE(source.stat().st_mode) == item["mode"]
            assert (PAYLOAD / relative).read_bytes() == data
    return results


archive = BASE / "bootstrap-red-green-and-scoped-qualification.tar.xz"
manifest_path = BASE / "manifest.json"
assert not archive.exists() and not manifest_path.exists()
before = verify_originals()
original_report = {"schema": "bootstrap-original-final-verification-v1", "atime_excluded": True, "sqlite_connections": 0, "rust_or_model_commands": 0, "completed_directories": before}
(PAYLOAD / "inventories/original-final-verification.json").write_text(json.dumps(original_report, indent=2) + "\n")
shutil.copy2(Path(__file__), PAYLOAD / "audits/seal_bootstrap_package.py")
inventory = {}
for path in sorted(PAYLOAD.rglob("*")):
    relative = path.relative_to(PAYLOAD).as_posix()
    metadata = path.lstat()
    record = {"mode": stat.S_IMODE(metadata.st_mode)}
    if path.is_dir():
        record.update(kind="directory")
    else:
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        record.update(kind="file", bytes=len(data), sha256=sha(data))
    inventory[relative] = record
inventory_bytes = (json.dumps(inventory, sort_keys=True, indent=2) + "\n").encode()
with tarfile.open(archive, "w:xz", preset=6) as tar:
    for relative, record in inventory.items():
        path = PAYLOAD / relative
        metadata = path.stat()
        info = tarfile.TarInfo(relative)
        info.mode = record["mode"]
        info.uid, info.gid = metadata.st_uid, metadata.st_gid
        info.mtime = metadata.st_mtime_ns // 1_000_000_000
        if record["kind"] == "directory":
            info.type = tarfile.DIRTYPE
            tar.addfile(info)
        else:
            data = path.read_bytes()
            assert len(data) == record["bytes"] and sha(data) == record["sha256"]
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
    info = tarfile.TarInfo("member-inventory.json")
    info.size, info.mode = len(inventory_bytes), 0o644
    tar.addfile(info, io.BytesIO(inventory_bytes))
assert verify_originals() == before
for relative, record in inventory.items():
    path = PAYLOAD / relative
    assert stat.S_IMODE(path.stat().st_mode) == record["mode"]
    if record["kind"] == "file":
        assert sha(path.read_bytes()) == record["sha256"]
summary = json.loads((PAYLOAD / "qualification-summary.json").read_bytes())
manifest = {
    "schema": "hepta-bootstrap-red-green-qualified-evidence-v1",
    "archive": {"file": archive.name, "bytes": archive.stat().st_size, "sha256": sha(archive.read_bytes()), "payload_files": sum(v["kind"] == "file" for v in inventory.values()), "payload_directories": sum(v["kind"] == "directory" for v in inventory.values()), "payload_file_bytes": sum(v.get("bytes", 0) for v in inventory.values()), "member_inventory_sha256": sha(inventory_bytes)},
    "source": {"local_test_base": summary["local_test_base"], "published_head": summary["publication"]["source_head"], "published_tree": summary["publication"]["source_tree"], "pr": summary["publication"]["pr"], "source_added_lines": 360, "source_removed_lines": 0},
    "local_results": [
        {"stage": "baseline", "exit": 100, "unique_tests": 2, "passed": 1, "failed": 1, "skipped": 285, "retries_retained": 1},
        {"stage": "green", "exit": 0, "unique_tests": 2, "passed": 2, "failed": 0, "skipped": 285},
        {"stage": "affected-crate", "exit": 0, "unique_tests": 280, "passed": 280, "failed": 0, "skipped": 7},
        {"stage": "final-fix", "exit": 0, "warnings": 19, "source_changes": 0},
        {"stage": "final-format", "exit": 0, "source_changes": 1, "separate_explicit_discard_edit_recorded": True}
    ],
    "raw_evidence": {"new_regression_attempts": 7, "new_regression_child_process_receipts": 14, "raw_case_files": summary["raw_case_files_total"], "raw_case_bytes": summary["raw_case_file_bytes_total"], "all_five_original_directories_unchanged": True, "original_atime_excluded": True, "includes_failed_original_wal_and_shm": True},
    "qualification_boundaries": {"pretrained_models_or_training": 0, "local_tests_after_final_tools": 0, "eight_research_full_closure": False, "physical_power_loss_qualified": False, "wal_only_necessity_proven": False, "production_authority_qualified": False, "warning_free_claim": False},
    "independent_ci_identity_only": summary["publication"],
    "verification_script": {"file": "verify_bootstrap_evidence.py", "sha256": sha((BASE / "verify_bootstrap_evidence.py").read_bytes()), "command": "python verify_bootstrap_evidence.py manifest.json", "opens_sqlite_or_executes_tests": False},
    "audits": summary["audits"]
}
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"archive": manifest["archive"], "manifest_sha256": sha(manifest_path.read_bytes()), "readme_lines": len((BASE / "README.md").read_text().splitlines()), "manifest_lines": len(manifest_path.read_text().splitlines()), "original_raw_files": sum(r["files"] for r in before), "original_raw_bytes": sum(r["file_bytes"] for r in before)}, indent=2))
