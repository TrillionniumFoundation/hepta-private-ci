"""Audit completed bootstrap qualification bytes; never open SQLite or run tests."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import stat
import struct


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def inventory(root):
    result = {}
    for path in sorted(root.rglob("*")):
        metadata = path.lstat()
        relative = path.relative_to(root).as_posix()
        item = {
            "mode": oct(stat.S_IMODE(metadata.st_mode)),
            "device": metadata.st_dev,
            "inode": metadata.st_ino,
            "uid": metadata.st_uid,
            "gid": metadata.st_gid,
            "links": metadata.st_nlink,
            "mtime_ns": metadata.st_mtime_ns,
            "ctime_ns": metadata.st_ctime_ns,
        }
        if stat.S_ISREG(metadata.st_mode):
            data = path.read_bytes()
            item.update(kind="file", bytes=len(data), sha256=digest(data))
        elif stat.S_ISDIR(metadata.st_mode):
            item.update(kind="directory")
        else:
            raise AssertionError(f"unexpected non-regular evidence entry: {path}")
        result[relative] = item
    return result


parser = argparse.ArgumentParser()
parser.add_argument("attempt", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--role", choices=["baseline", "green", "full"], required=True)
args = parser.parse_args()
attempt = args.attempt.resolve()
assert not args.output.exists(), "audit output must be new"
original_inventory = inventory(attempt)
checks = []


def check(name, value):
    checks.append({"check": name, "passed": bool(value)})
    if not value:
        raise AssertionError(name)


receipt = load(attempt / "receipt.json")
check("wrapper_completed", receipt["exit_code"] is not None)
check("wrapper_exit", receipt["exit_code"] == (100 if args.role == "baseline" else 0))
before = load(attempt / "source-before.json")
after = load(attempt / "source-after.json")
check("executed_source_unchanged", before == after and receipt["source_unchanged_during_tests"])
check("no_changed_source_paths", receipt["changed_source_paths_during_tests"] == [])
implementation = "codex-rs/hepta-memory/src/cognitive_store.rs"
implementation_sha = (
    "bbdc06e61c9389dc5a0e3558d89167875389a7d4f06ac5d38a048ee0c216d34e"
    if args.role == "baseline"
    else "2ea1c39f6887d8069270c393886215f8c32d00487e2841e20527117ad21f687c"
)
check("exact_initializer_sha", before[implementation]["sha256"] == implementation_sha)
for name, expected in {
    "cognitive_store_recovery_tests.rs": "e8dbb6dfd8a2fa52e70578a02c75bc9f4e853be64ad94c2347d4820b44a602f5",
    "cognitive_store_bootstrap_crash_tests.rs": "216e074038a5ecf19696ce9e43c6fbf8de78e711c8ae8ee85906b206127f32fe",
}.items():
    relative = "codex-rs/hepta-memory/src/" + name
    check("exact_test_sha:" + name, before[relative]["sha256"] == expected)
    check("retained_test_bytes:" + name, digest((attempt / "executed-candidate-sources" / relative).read_bytes()) == expected)
log = (attempt / "scoped-tests.log").read_bytes()
check("raw_log_sha", digest(log) == receipt["log_sha256"])
summary = re.search(r"Summary \[\s*([\d.]+)s\] (\d+) tests run: ([^\n]+)", log.decode())
check("actual_nextest_summary_present", summary is not None)
counts = {name: int(number) for number, name in re.findall(r"(\d+) (passed|failed|skipped)", summary[3])}
unique_tests = int(summary[2])
check("test_count_consistent", unique_tests == counts.get("passed", 0) + counts.get("failed", 0))
if args.role == "baseline":
    check("baseline_two_unique_tests_one_failure", unique_tests == 2 and counts.get("passed") == 1 and counts.get("failed") == 1)
    check("both_default_retry_attempts_retained", "TRY 1 FAIL" in log.decode() and "TRY 2 FAIL" in log.decode())
else:
    check("all_selected_tests_passed", counts.get("passed") == unique_tests and counts.get("failed", 0) == 0)
    if args.role == "green":
        check("green_same_two_unique_tests", unique_tests == 2)
check("no_pretrained_models", receipt["pretrained_model_commands_started_by_wrapper"] == 0)
raw_inventory = load(attempt / "raw-case-file-inventory.json")
for relative, expected in raw_inventory.items():
    path = attempt / "raw-cases" / relative
    data = path.read_bytes()
    check("raw_file:" + relative, len(data) == expected["bytes"] and digest(data) == expected["sha256"] and oct(stat.S_IMODE(path.stat().st_mode)) == expected["mode"])
actual_raw_paths = {p.relative_to(attempt / "raw-cases").as_posix() for p in (attempt / "raw-cases").rglob("*") if p.is_file()}
check("raw_inventory_exhaustive", actual_raw_paths == set(raw_inventory))
check("raw_file_counts", len(raw_inventory) == receipt["retained_case_files"])
check("raw_byte_count", sum(v["bytes"] for v in raw_inventory.values()) == receipt["retained_case_file_bytes"])
case_results = []
all_child_pids = []
for case in sorted((attempt / "raw-cases").iterdir()):
    generation = "initial" if case.name.startswith("initial-generation-") else "recovered"
    expected_success = not (args.role == "baseline" and generation == "initial")
    handoff = load(case / "handoff.json")
    cut = handoff["cut"]
    check(case.name + ":full_cut_shape", set(cut) == {"profile", "owner_agent_id", "schema_digest", "state_digest"} and cut["profile"] == "hepta:cognitive:exact-current-cut:v1" and all(re.fullmatch("[0-9a-f]{64}", cut[k]) for k in ["schema_digest", "state_digest"]))
    source = Path(handoff["source_path"])
    check(case.name + ":source_is_case_local", source.is_relative_to(case) and source.parent.name == "cognitive" and source.parent.parent.name == cut["owner_agent_id"])
    source_before = load(case / "source-before.json")
    source_after = load(case / "source-after.json")
    check(case.name + ":source_before_after_equal", source_before == source_after)
    modes = {}
    for name, recorded in source_before.items():
        path = source.parent / name
        data = path.read_bytes()
        st = path.lstat()
        observed = {"bytes": len(data), "sha256": digest(data), "mode": stat.S_IMODE(st.st_mode), "device": st.st_dev, "inode": st.st_ino, "links": st.st_nlink, "mtime_seconds": st.st_mtime_ns // 1_000_000_000, "mtime_nanoseconds": st.st_mtime_ns % 1_000_000_000, "ctime_seconds": st.st_ctime_ns // 1_000_000_000, "ctime_nanoseconds": st.st_ctime_ns % 1_000_000_000}
        check(case.name + ":original_source_still_identical:" + name, observed == recorded)
        modes[name] = oct(recorded["mode"])
    check(case.name + ":all_bundle_members_present", all(source.name + suffix in source_before for suffix in ["", "-wal", "-shm"]))
    if expected_success:
        check(case.name + ":source_modes_0600", all(v == "0o600" for v in modes.values()))
    else:
        check(case.name + ":original_mode_defect_present", modes[source.name] == "0o600" and modes[source.name + "-wal"] == "0o644" and modes[source.name + "-shm"] == "0o644")
    wal_bytes = (source.parent / (source.name + "-wal")).read_bytes()
    magic, version, page_size = struct.unpack(">III", wal_bytes[:12])
    check(case.name + ":wal_layout", magic in [0x377F0682, 0x377F0683] and version == 3007000 and page_size >= 512 and len(wal_bytes) > 32 and (len(wal_bytes) - 32) % (24 + page_size) == 0)
    children = []
    for phase in ["write", "recover"]:
        directory = case / ("command-" + phase)
        request, child_receipt, process = (load(directory / name) for name in ["request.json", "receipt.json", "process.json"])
        stdout, stderr = ((directory / name).read_bytes() for name in ["stdout.log", "stderr.log"])
        expected_test = "cognitive_store::recovery::tests::bootstrap_crash::" + generation + "_generation_abrupt_exit_recovers_exact_cut"
        check(case.name + ":exact_child_request:" + phase, request["args"] == ["--exact", expected_test, "--nocapture"] and request["child_root"] == str(case) and request["phase"] == phase)
        check(case.name + ":actual_child_identity:" + phase, process["pid"] == child_receipt["pid"] and process["phase"] == phase and process["pid"] != request["parent_pid"])
        check(case.name + ":actual_child_umask:" + phase, process["linux_proc_umask_line"] == "Umask:\t0022")
        expected_exit = 73 if phase == "write" else (0 if expected_success else 101)
        check(case.name + ":actual_child_exit:" + phase, child_receipt["exit_code"] == expected_exit)
        check(case.name + ":exactly_one_child_test_started:" + phase, b"running 1 test" in stdout)
        if phase == "recover":
            if expected_success:
                check(case.name + ":one_child_test_passed", b"test result: ok. 1 passed; 0 failed" in stdout and not stderr)
            else:
                check(case.name + ":precise_strict_recovery_failure", b'Indeterminate("SQLite recovery is indeterminate: the complete immutable file identity was not established")' in stderr and b"cognitive_store_bootstrap_crash_tests.rs:129:18" in stderr and b"test result: FAILED. 0 passed; 1 failed" in stdout)
        all_child_pids.append(child_receipt["pid"])
        children.append({"phase": phase, "parent_pid": request["parent_pid"], "executable": request["executable"], "actual_process": process, "receipt": child_receipt, "stdout_sha256": digest(stdout), "stderr_sha256": digest(stderr), "failure_stderr": stderr.decode() if stderr else None})
    check(case.name + ":distinct_fresh_children", children[0]["receipt"]["pid"] != children[1]["receipt"]["pid"] and children[0]["parent_pid"] == children[1]["parent_pid"])
    result_path = case / "recovered-write.json"
    result = load(result_path) if result_path.exists() else None
    if expected_success:
        check(case.name + ":actual_recovered_cut_equals_external_cut", result is not None and result["observed_before_write"] == cut)
        check(case.name + ":actual_new_write_changes_cut", result["persisted_after_write"] != cut and result["persisted_after_write"]["schema_digest"] == cut["schema_digest"] and result["persisted_after_write"]["owner_agent_id"] == cut["owner_agent_id"])
        check(case.name + ":new_generation_database_exists", result["database_path"] != str(source) and Path(result["database_path"]).is_file() and Path(result["database_path"]).is_relative_to(case))
    else:
        check(case.name + ":no_fabricated_success_result", result is None)
    case_results.append({"case": case.name, "generation": generation, "expected_success": expected_success, "handoff": handoff, "source_bundle": source_before, "source_before_after_equal": True, "wal_layout": {"bytes": len(wal_bytes), "page_size": page_size, "frame_slots": (len(wal_bytes) - 32) // (24 + page_size), "sha256": digest(wal_bytes)}, "children": children, "recovered_write": result})
check("all_actual_child_pids_distinct", len(set(all_child_pids)) == len(all_child_pids))
case_counts = {generation: sum(c["generation"] == generation for c in case_results) for generation in ["initial", "recovered"]}
check("retained_attempt_counts", case_counts == ({"initial": 2, "recovered": 1} if args.role == "baseline" else {"initial": 1, "recovered": 1}))
final_inventory = inventory(attempt)
check("all_original_evidence_bytes_metadata_unchanged", final_inventory == original_inventory)
report = {
    "schema": "hepta-bootstrap-qualification-byte-audit-v1", "role": args.role, "attempt_path": str(attempt),
    "wrapper_receipt": receipt, "source_file_count": len(before), "initializer_sha256": implementation_sha,
    "nextest": {"raw_summary": summary[0], "unique_tests": unique_tests, "counts": counts, "test_wall_seconds": float(summary[1]), "case_attempts": case_counts, "retry_is_not_an_independent_test": True},
    "cases": case_results, "actual_child_process_count": len(all_child_pids),
    "checks": checks, "check_count": len(checks), "all_checks_passed": all(c["passed"] for c in checks),
    "source_and_run_inventory": original_inventory,
    "scope": {"audit_sqlite_connections": 0, "audit_tests_or_models_run": 0, "audit_source_edits": 0, "original_files_unchanged": True, "atime_excluded": True},
    "bounds": ["process::exit(73) tests abrupt process termination without Rust Drop, not physical power loss.", "Retained WAL frames do not prove the final logical cut exists exclusively in WAL.", "Whole-cut equality is checked against actual child receipts and the frozen executed test; the auditor does not recompute SQL table state by opening SQLite.", "The new write is verified by a close/reopen within the recovery child, not a third verifier process.", "Existing test authority is controlled; this does not establish production authentication/freshness or research-blocker closure.", "Default retry is retained as another attempt of the same unique test."]
}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"output": str(args.output), "bytes": args.output.stat().st_size, "sha256": digest(args.output.read_bytes()), "checks": len(checks), "case_attempts": case_counts, "child_processes": len(all_child_pids), "nextest": report["nextest"]}, ensure_ascii=False))
