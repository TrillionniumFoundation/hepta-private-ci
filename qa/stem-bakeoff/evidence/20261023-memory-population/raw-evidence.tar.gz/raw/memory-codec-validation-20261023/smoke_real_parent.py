import hashlib
import json
from pathlib import Path
import subprocess
from unittest.mock import patch

import torch

from checkpoint_codec import encode_checkpoint, decode_checkpoint
from exact_baselines import measure_baselines
from parametric_model import SourceMemoryCell, adapter_digest
from parametric_owner import Frontier, ParametricOwner

root = Path('/workspace/scratch/1d69f04ee9f4')
repo = root / 'hepta-private-ci'
output = root / 'memory-codec-validation-20261023'
parent = root / 'parametric-runs/confirmation-001/lifecycle/rebuilt-cell'
parent_digest = 'c273d4555cc0dbb105fc38a674ac6963a43cf48c58d9fced6a38e373759c2e05'

def hashes(directory):
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.iterdir()) if p.is_file()}

source_before = hashes(repo / 'scripts/memory_cell_codec')
parent_before = hashes(parent)
assert parent_before['lineage.json'] == parent_digest
lineage = json.loads((parent / 'lineage.json').read_text())
facts = json.loads((repo / 'scripts/memory_cell_growth/fixtures/clean-replay-facts.json').read_text())
assert set(lineage['roots']) == {r['source_digest'] for r in facts}
revoked = {'ecbf81965c51e8b9dc77b163f56f5428046b0b0e32b8c6c93079367178471967',
           'ff61b0a343d65ca74aab7f58964c4e834989a8c7760e9d31bc5a78283e62f5fc'}
assert not set(lineage['roots']) & revoked
torch.set_num_threads(2)
cell = SourceMemoryCell('/tmp/hepta-parametric-smol135m', rank=8, seed=2718)
owner = ParametricOwner(output / 'real-smoke-owner.sqlite3')
provider = lambda: Frontier(lineage['scope'], 1, tuple(sorted(revoked)))
arms = {}
with patch.object(cell.reader.model, 'forward', side_effect=AssertionError('smoke must not generate')) as forward:
    for bits in (8, 4):
        packed_dir = output / f'real-parent-int{bits}'
        decoded_dir = output / f'real-parent-int{bits}-decoded'
        packed = encode_checkpoint(parent, packed_dir, expected_manifest_sha256=parent_digest,
                                   allowed_roots=set(lineage['roots']), revoked_roots=revoked, bits=bits)
        decoded = decode_checkpoint(packed_dir, decoded_dir, expected_codec_sha256=packed['codec_manifest_sha256'],
                                    allowed_roots=set(lineage['roots']), revoked_roots=revoked)
        owner.activate(f'int{bits}', decoded_dir, decoded['manifest_sha256'], scope=lineage['scope'],
                       expected_current=None, generation=0, provider=provider, allowed_roots=set(lineage['roots']))
        adopted = owner.invoke(f'int{bits}', lineage['scope'], provider,
                               lambda active: cell.load(active.directory, expected_manifest_sha256=active.manifest_sha256,
                                                        scope=active.scope, allowed_roots=set(active.roots), revoked=revoked))
        assert adapter_digest(cell.reader.model) == decoded['adapter_state_sha256']
        arms[str(bits)] = dict(encoded=packed, decoded=decoded, actual_reader_state_matches=True,
                              owner_admitted=True, reader_adoption=adopted, recall_evaluated=False)
    assert forward.call_count == 0
baselines = measure_baselines(facts, output / 'real-parent-exact-baselines')
assert source_before == hashes(repo / 'scripts/memory_cell_codec')
assert parent_before == hashes(parent)
result = dict(schema='hepta.memory-codec.real-parent-smoke.v1',
              source_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
              code_file_sha256=source_before, parent_file_sha256=parent_before,
              parent_manifest_sha256=parent_digest, arms=arms, exact_baselines=baselines,
              source_unchanged=True, parent_unchanged=True, model_forward_calls=0,
              generation_calls=0, optimizer_updates=0, recall_evaluated=False,
              compression_advantage_over_exact_store_proven=False, production_accepted=False)
(output / 'real-parent-smoke.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, indent=2, sort_keys=True))
