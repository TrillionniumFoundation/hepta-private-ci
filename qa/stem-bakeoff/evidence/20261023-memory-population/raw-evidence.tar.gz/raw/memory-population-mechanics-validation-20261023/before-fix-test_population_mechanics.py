"""Actual tiny-decoder transfer and dependency-balanced gradient mechanics."""

from pathlib import Path
import tempfile
import unittest

from parametric_model import SourceMemoryCell
from population_transfer import expand_verified_parent
import test_parametric_model as tiny_fixture


class PopulationMechanicsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        tiny_fixture.SourceMemoryCellTests.setUpClass()
        cls.base = tiny_fixture.SourceMemoryCellTests.base

    @classmethod
    def tearDownClass(cls):
        tiny_fixture.SourceMemoryCellTests.tearDownClass()

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.directory = Path(self.temporary.name)
        self.facts = [tiny_fixture.fact("one", "red", "a"), tiny_fixture.fact("two", "blue", "b")]
        self.parent_path = self.directory / "parent"
        written = self.cell(4)
        written.fit_sources(self.facts, 4, 0.001, tiny_fixture.TEMPLATES)
        self.parent_manifest = written.save(self.parent_path)
        self.parent = self.cell(4)
        self.parent.load(self.parent_path, expected_manifest_sha256=self.parent_manifest, scope="alpha",
                         allowed_roots={"a" * 64, "b" * 64}, revoked=set())

    def tearDown(self):
        self.temporary.cleanup()

    def cell(self, rank, *, scope="alpha", base=None):
        cell = SourceMemoryCell(self.base if base is None else base, rank=rank)
        cell.reset(scope)
        return cell

    def test_expansion_rejects_parent_with_unsaved_postload_training(self):
        self.parent.fit_sources([tiny_fixture.fact("three", "green", "c")], 1, 0.001, tiny_fixture.TEMPLATES)
        with self.assertRaises(ValueError):
            expand_verified_parent(self.parent, self.cell(8), self.directory / "invalid",
                                   parent_manifest_sha256=self.parent_manifest)
        self.assertFalse((self.directory / "invalid").exists())


if __name__ == "__main__":
    unittest.main()
