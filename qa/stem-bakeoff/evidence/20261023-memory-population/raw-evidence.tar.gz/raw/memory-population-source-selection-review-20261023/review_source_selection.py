"""Post-selection metadata-only diagnosis; no model imports, fitting or final reads."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
import struct


HEAD = "07df4a9cc385375cddded5b5e3b99632ce0652ec"
TRAIN = "What is the {relation} for {entity}?"
SELECTION = "In this memory, which {relation} belongs to {entity}?"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def expand_sources(sources):
    rows = []
    for source in sources:
        kind = source["kind"]
        if kind == "semantic":
            values = [(source["entity"], source["relation"], source["value"])]
        elif kind == "episode":
            values = [(f"{source['entity']} on day {source['day']}", "location", source["location"])]
        else:
            assert kind == "procedure" and source["operation"] == "affine_mod"
            values = [(f"{source['rule']} with input {x}", "result",
                       str((source["multiplier"] * x + source["offset"]) % source["modulus"]))
                      for x in range(6)]
        rows.extend({"entity": entity, "relation": relation, "value": value,
                     "family": kind, "source_roots": [source["source_digest"]]}
                    for entity, relation, value in values)
    assert len(rows) == 64
    return rows


def summarize(rows):
    return {
        "queries": len(rows),
        "routed": sum(r["slot"] is not None for r in rows),
        "abstained": sum(r["slot"] is None for r in rows),
        "routed_source_supported": sum(r["routed_source_supported"] for r in rows),
        "routed_source_unsupported": sum(r["slot"] is not None and not r["routed_source_supported"] for r in rows),
        "split_supported_correct": sum(r["split_supported_correct"] for r in rows),
        "single_supported_correct": sum(r["single_supported_correct"] for r in rows),
        "parent_supported_correct": sum(r["parent_supported_correct"] for r in rows),
        "expert_supported_correct": [sum(r["expert_supported_correct"][slot] for r in rows) for slot in (0, 1)],
        "oracle_available": sum(any(r["expert_supported_correct"]) for r in rows),
        "no_supported_correct_expert": sum(not any(r["expert_supported_correct"]) for r in rows),
        "reject_despite_oracle_available": sum(r["failure"] == "rejected_available_answer" for r in rows),
        "wrong_expert_despite_oracle_available": sum(r["failure"] == "wrong_expert_with_available_answer" for r in rows),
        "wrong_expert_unsupported_route": sum(r["failure"] == "wrong_expert_with_available_answer"
                                               and not r["routed_source_supported"] for r in rows),
        "reject_without_correct_expert": sum(r["slot"] is None and not any(r["expert_supported_correct"]) for r in rows),
        "argmax_without_rejection_supported_correct_diagnostic": sum(r["expert_supported_correct"][r["top_expert"]] for r in rows),
        "metadata_first_supported_expert_correct": sum(r["expert_supported_correct"][r["metadata_slot"]] for r in rows),
        "reasons": dict(sorted(Counter(r["reason"] for r in rows).items())),
        "support_confidence": {"minimum": min(r["support_confidence"] for r in rows),
                               "mean": statistics.mean(r["support_confidence"] for r in rows),
                               "maximum": max(r["support_confidence"] for r in rows)},
        "best_expert_minus_reject": {"minimum": min(r["margin"] for r in rows),
                                     "mean": statistics.mean(r["margin"] for r in rows),
                                     "maximum": max(r["margin"] for r in rows)},
    }


def wording_association(observations):
    forms = {
        "What is": "What is the {relation} for {entity}?",
        "Recall the color associated": "Recall the color associated with person Zxx.",
        "Give the stored weight": "Give the stored weight of person Nxx.",
        "Recall courier": "Recall courier Zxx's last location before day 4.",
        "Return the result": "Return the result of rule Zxx on input 3.",
    }
    rows = []
    for prefix, template in forms.items():
        selected = [o for o in observations if o["question"].startswith(prefix)]
        positive = sum(any(u >= 0.5 for u in o["utilities"]) and not o["reject"] for o in selected)
        rows.append({"template": template, "queries": len(selected), "positive_expert_target": positive,
                     "reject_target": len(selected) - positive,
                     "explicit_unknown_reject": sum(o["reject"] for o in selected),
                     "known_query_no_correct_expert_reject": sum(not o["reject"] and not any(o["utilities"])
                                                                  for o in selected)})
    assert sum(r["queries"] for r in rows) == 76
    positive = sum(r["positive_expert_target"] for r in rows)
    rejects = 76 - positive
    return {"rows": rows, "all_positive_expert_targets_use_what_template": rows[0]["positive_expert_target"] == positive,
            "positive_given_what_fraction": positive / 64,
            "positive_given_other_training_wording_fraction": 0.0,
            "reject_given_what_fraction": rows[0]["reject_target"] / 64,
            "non_what_given_reject_fraction": 12 / rejects,
            "not_a_perfect_template_label_partition": rows[0]["reject_target"] > 0,
            "causal_effect_identified": False,
            "no_same_content_cross_template_router_predictions_generated": True}


def review_trial(study, seed):
    root = study / f"seed-{seed}"
    pins = {}

    def read(relative, *, binary=False):
        path = root / relative
        raw = path.read_bytes()
        pins[relative] = {"bytes": len(raw), "sha256": digest(raw)}
        return raw if binary else json.loads(raw)

    selection = read("selection/precommitted-selection.json")
    assessments = read("selection/source-assessments.json")
    generations = read("selection/source-generations.json")
    provenance = read("selection/router-observations.json")
    sources = read("exact-baselines/complete_records.json")
    router = read("selection/learned-router.bin", binary=True)
    assert digest(canonical(sources)) == selection["sources_sha256"] == provenance["sources_sha256"]
    assert digest(canonical(provenance)) == selection["router_source_sha256"]
    assert digest(router) == selection["router_receipt"]["sha256"]
    magic = b"HEPTA_ROUTER_V2\n"
    assert router.startswith(magic)
    length = struct.unpack("<I", router[len(magic):len(magic) + 4])[0]
    header = json.loads(router[len(magic) + 4:len(magic) + 4 + length])
    assert header["source_sha256"] == selection["router_source_sha256"]
    assert header["training"] == selection["router_receipt"]["training"]
    observations = provenance["observations"]
    assert observations == selection["observations"] and len(observations) == 76
    facts = expand_sources(sources)
    versions = selection["versions"]
    assert len(assessments) == 64
    assert {k: [len(v["rows"]) for v in vs] for k, vs in generations.items()} == {
        "parent": [64], "single": [64], "split": [140, 140]}
    rows, training = [], []
    for index, (fact, assessed) in enumerate(zip(facts, assessments, strict=True)):
        roots = set(fact["source_roots"])
        support = [roots <= set(v["roots"]) for v in versions["split"]]
        assert any(support) and fact["family"] == assessed["family"]
        train_question = TRAIN.format(**fact)
        select_question = SELECTION.format(**fact)
        utilities = []
        for slot in (0, 1):
            train_raw = generations["split"][slot]["rows"][index]
            assert train_raw["question"] == train_question
            utilities.append(float(support[slot] and train_raw["text"] == fact["value"]))
        assert observations[index] == {"question": train_question, "utilities": utilities, "reject": False}
        training.append({"index": index, "family": fact["family"], "utilities": utilities,
                         "available": any(utilities)})
        raw = [v["rows"][76 + index] for v in generations["split"]]
        assert all(r["question"] == select_question for r in raw)
        correct = [r["text"] == fact["value"] and supported for r, supported in zip(raw, support, strict=True)]
        route = assessed["route"]
        slot = route["slot"]
        top = max(range(2), key=lambda i: (route["probabilities"][i], -i))
        routed_correct = slot is not None and correct[slot]
        source_supported = slot is not None and support[slot]
        assert source_supported == assessed["split"]["source_supported"]
        assert routed_correct == assessed["split"]["supported_correct"]
        for arm in ("parent", "single"):
            output = generations[arm][0]["rows"][index]
            assert output["question"] == select_question
            supported = roots <= set(versions[arm][0]["roots"])
            assert (output["text"] == fact["value"] and supported) == assessed[arm]["supported_correct"]
        failure = ("correct" if routed_correct else "no_supported_correct_expert" if not any(correct)
                   else "rejected_available_answer" if slot is None else "wrong_expert_with_available_answer")
        rows.append({"probe_id": assessed["probe_id"], "family": fact["family"], "question": select_question,
                     "slot": slot, "top_expert": top, "metadata_slot": support.index(True),
                     "routed_source_supported": source_supported, "expert_source_supported": support,
                     "expert_raw_text": [r["text"] for r in raw],
                     "expert_supported_correct": correct, "split_supported_correct": routed_correct,
                     "single_supported_correct": assessed["single"]["supported_correct"],
                     "parent_supported_correct": assessed["parent"]["supported_correct"],
                     "source_value": fact["value"], "failure": failure,
                     **{key: route[key] for key in ("reason", "support_confidence", "margin", "probabilities")}})
    assert all(o["reject"] is True and o["utilities"] == [0.0, 0.0] for o in observations[64:])
    def training_group(values):
        return {"queries": len(values), "oracle_available": sum(v["available"] for v in values),
                "expert_supported_correct": [sum(v["utilities"][s] for v in values) for s in (0, 1)],
                "utility_patterns": dict(sorted(Counter(str(v["utilities"]) for v in values).items()))}
    report = {
        "seed": seed, "source_selection_sha256": pins["selection/precommitted-selection.json"]["sha256"],
        "choice": selection["choice"], "router_header": header,
        "selection": {"template": SELECTION, "all": summarize(rows),
                      "families": {family: summarize([r for r in rows if r["family"] == family])
                                   for family in ("semantic", "episode", "procedure")}},
        "training_wording_0": {"template": TRAIN, "all": training_group(training),
                               "families": {family: training_group([r for r in training if r["family"] == family])
                                            for family in ("semantic", "episode", "procedure")}},
        "training_wording_label_association": wording_association(observations),
        "explicit_reject_training": {"queries": 12, "utility_patterns": {"[0.0, 0.0]": 12},
                                     "four_distinct_question_forms": True,
                                     "router_train_decisions_not_generated_or_inferred": True},
        "single_old_regressions": [r for r in rows if r["family"] == "semantic"
                                   and r["parent_supported_correct"] and not r["single_supported_correct"]],
        "per_probe": rows, "input_pins": pins,
        "capability_guard_executed_in_source_selection": False,
        "source_roots_checked_in_utility_and_scoring": True,
        "all_source_selection_probes_have_at_least_one_source_supported_expert": True,
        "other_training_wordings_have_no_retained_source_inference_journals": True,
        "forced_argmax_is_posthoc_diagnostic_only": True,
        "selection_or_thresholds_changed": False, "refit_or_new_inference": False,
        "final_outputs_read": False,
    }
    total = report["selection"]["all"]
    maximum_gain = total["oracle_available"] - total["metadata_first_supported_expert_correct"]
    report["strong_metadata_gate_source_only_ceiling"] = {
        "oracle_minus_metadata_correct_count": maximum_gain,
        "oracle_minus_metadata_accuracy": maximum_gain / 64,
        "registered_gain_threshold": 0.05,
        "some_routing_policy_could_reach_five_pp_on_these_source_outputs": maximum_gain >= 4,
        "bounded_by_measured_supported_expert_outputs": True,
        "source_selection_diagnostic_not_final_retention_gate_result": True,
        "ceiling_applies_to_current_experts_and_same_output_matrix_only": True,
    }
    report["future_separately_registered_candidates"] = [
        "cross every source-positive and explicit-reject family with matched wording templates",
        "calibrate expert availability/rejection separately from relative expert choice on source-only disjoint data",
        "predeclare risk-coverage curves and matched coverage comparisons, preserving strong metadata and oracle baselines",
    ]
    for relative, pin in pins.items():
        assert digest((root / relative).read_bytes()) == pin["sha256"]
    report["inputs_unchanged"] = True
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    assert not output.exists() and not output.is_relative_to(args.study.resolve())
    report = {"schema": "hepta.population.source-selection-diagnostic.v1", "source_head": HEAD,
              "scope": "post-selection source metadata review; no final outputs, model execution or protocol changes",
              "trials": [review_trial(args.study.resolve(), seed) for seed in (1907, 2719)]}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"output": str(output), "sha256": digest(output.read_bytes()),
                      "trials": [{"seed": r["seed"], "selection": r["selection"]["all"],
                                  "training_wording_0": r["training_wording_0"]["all"]}
                                 for r in report["trials"]]}, sort_keys=True))


if __name__ == "__main__":
    main()
