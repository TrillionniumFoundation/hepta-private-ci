# Catalog CI 运行依赖修复准备

## 可直接审阅的 r2

应用对象为 `07df4a9cc385375cddded5b5e3b99632ce0652ec` 的 `.github/workflows/hepta-parametric-catalog-shadow.yml`。

- 完整 proposed YAML：`hepta-parametric-catalog-shadow.proposed-r2.yml`
- 完整 unified diff：`catalog-runtime-fix-r2.patch.txt`
- 静态核验 receipt：`repair-review-receipt-r2.json`
- PR 说明候选：`PR-description-candidate-r2.md`

r2 明确包含两项变化：现有 NumPy/safetensors 安装命令增加 `packaging==26.3`；job 条件额外接受本次修复分支 `codex/memory-catalog-runtime-fix-20261023` 的 pull request。原有 `workflow_dispatch` 和旧分支条件均保留。它不是只有一行依赖变化的 proposal。runner、timeout、permissions、`SOURCE_SHA`、测试命令和保存证据的步骤都保持原值。

r1 依赖修复和全部 r1 文件继续保留。当前能力中没有 workflow_dispatch 写操作；单独发布任意新分支 PR 不会满足原 job 的分支条件，因此需要 r2 的精确分支例外。没有扩大到任意分支。

## 失败事实与版本依据

旧 run `39916012060`、job `120289644892`、HEAD `cbd139ad7cfeaf0be226688f2475cdeb364aa3e1` 于 10:08:52 UTC 失败。导入测试文件时 `safetensors.torch` 请求 `packaging.version`，抛出 `ModuleNotFoundError: No module named 'packaging'`。这次 `Ran 1 test` 是 unittest loader error；实际 catalog tests 执行数为零。安装步骤与 `pip check` 成功并不能证明运行时 import 链完整。

原始证据位于同一 workspace 的 `memory-population-ci-preflight-20261023/refresh-20261023T101617Z/`。完整 job log、2,174 字节原 ZIP、四个原字节文件与 SHA manifest 均保留。ZIP SHA-256 为 `62fd0938e1ecd291d3e90c13893d380c99f62e8ffe1eb87d2d44ace91cc11ee0`，与 GitHub digest 一致。

精确读取 GitHub 上 `07df4a9` 的 workflow，并与本地已有 `cbd139ad` Git object 比较，两者原字节完全相同，SHA-256 为 `cab43afc131b2017d701a1441d907b7c3e28e4074ba96f3955606efaf2f06e14`。因此遗漏仍存在于新的修复基线。

选择 `packaging==26.3` 的依据是实际运行记录：成功的 `07df4a9` CI artifact `12492396909` 的 `runtime.txt` 和现有 `/workspace/scratch/1d69f04ee9f4/parametric-venv` 都记录版本 26.3；它们的 safetensors 为 0.6.2、CPU torch 为 2.5.1。相关原始 runtime 和本地版本读取结果已复制到此目录，没有安装新环境。

## 已完成的静态核验

在此目录的 `patch-check/` 独立原始 YAML 副本上，r1、r2 均通过 `git apply --check`。没有将 patch 应用到原仓库。r2 逆转两项具体替换后与原始 YAML 逐字节一致。receipt 还列出目标逻辑的有限真值表，明确它不是 GitHub Actions 表达式引擎的运行结果。

准备过程没有重跑 73 个实验测试、启动模型、读取未完成第三组的结果、修改实验仓库 tracked 文件或 HEAD，也没有展开旧 artifact 中的权重或建立新的大环境。后续 formatting、catalog 测试和新 CI 由 root 在独立 sparse worktree 完成。

## 必要验证方法

第一步可复用现有环境，运行小型 import/serialization smoke。脚本只检查实际依赖版本，导入 `packaging.version` 和 `safetensors.torch`，并对三个 float32 数值做内存 round trip；不会加载模型、写权重或改仓库。此准备阶段只提供脚本，尚未执行它。

```bash
PYTHONPATH=/tmp/parametric-runtime-1d69f04ee9f4 \
  /workspace/scratch/1d69f04ee9f4/parametric-venv/bin/python -B \
  /workspace/scratch/1d69f04ee9f4/memory-population-ci-repair-20261023/verify_runtime_dependency.py
```

第二步由 root 在独立修复 checkout 运行原 catalog suite，保留完整 stdout/stderr、退出码、修复 source identity 和运行前后 tracked-file 状态。将下面变量替换为 root 实际建立的独立工作树路径；不要指向正在运行实验的原仓库。

```bash
CATALOG_FIX_CHECKOUT=/workspace/scratch/1d69f04ee9f4/ROOT_CREATED_REPAIR_WORKTREE
PYTHONPATH="/tmp/parametric-runtime-1d69f04ee9f4:$CATALOG_FIX_CHECKOUT/scripts/memory_cell:$CATALOG_FIX_CHECKOUT/scripts/memory_cell_catalog" \
  /workspace/scratch/1d69f04ee9f4/parametric-venv/bin/python -B -m unittest discover \
  -s "$CATALOG_FIX_CHECKOUT/scripts/memory_cell_catalog" \
  -p test_metadata_catalog.py -v
```

复用的完整 runtime 可以验证版本兼容性及当前 suite 行为；它不能独立证明最小 fixture 环境的依赖闭包。最后需要新修复 PR 的 exact-head CI 真正执行并通过 catalog suite，才能关闭这个 CI blocker。旧失败 run 保留，不 rerun、不替换历史结果；本轮冻结实验继续引用 `07df4a9`。

## 后续实际本地验证（2026-10-23）

上述准备阶段之后，root 授权在独立 sparse worktree 实施 r2。依赖 smoke 与原 catalog suite 已顺序通过，后者为 6/6（日志中的测试耗时 0.076s）；进程峰值 RSS 分别为 217,333,760 和 221,462,528 字节。随后从该 worktree 的 codex-rs 运行 just fmt，退出码 0，输出说明本次 YAML 变化没有适用的语言 formatter，YAML 原字节保持不变。格式化后没有重跑测试。完整命令、环境覆盖、日志、资源测量、tracked 文件前后哈希及最终差异在 validation-r1/；PR 说明已更新为实际结果。新的 hosted CI 仍需绑定发布后的修复 HEAD 验证最小 fixture 安装。
