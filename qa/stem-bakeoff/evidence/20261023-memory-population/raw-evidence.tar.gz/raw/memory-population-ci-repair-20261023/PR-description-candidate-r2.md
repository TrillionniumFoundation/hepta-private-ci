## Problem

The catalog shadow job at `cbd139ad7cfeaf0be226688f2475cdeb364aa3e1` failed before executing the catalog tests. `test_metadata_catalog.py` imports `safetensors.torch`, which imports `packaging.version`, but the fixture installation omitted `packaging`. Run `39916012060`, job `120289644892`, therefore ended with `ModuleNotFoundError: No module named 'packaging'`. Its original log, runtime listing, source identity, and artifact are preserved.

The catalog workflow at `07df4a9cc385375cddded5b5e3b99632ce0652ec` is byte-identical to the failing workflow, so the dependency omission is still present at the proposed repair base.

## Changes

- Install `packaging==26.3` alongside the existing pinned NumPy and safetensors packages. That exact packaging version is present in the successful `07df4a9` mechanism CI runtime and the local study runtime, both using `safetensors==0.6.2` and CPU `torch==2.5.1`.
- Preserve `workflow_dispatch` and the existing catalog PR branch condition, and additionally allow exactly `codex/memory-catalog-runtime-fix-20261023` for pull request events. This explicit trigger-scope change lets the repair PR execute the same catalog checks through the available PR workflow. It does not admit arbitrary branches.

The runner, timeout, permissions, `SOURCE_SHA`, catalog test command, source-integrity checks, and artifact preservation remain unchanged.

## Validation

Validated in a separate sparse worktree based on exact HEAD `07df4a9cc385375cddded5b5e3b99632ce0652ec`:

- The dependency smoke passed with packaging 26.3, safetensors 0.6.2, NumPy 1.26.4 and CPU torch 2.5.1. It imported the failing dependency chain and round-tripped three float32 values through safetensors in memory; no pretrained model was loaded.
- The existing catalog suite passed all six distinct tests. The full log reports `Ran 6 tests in 0.076s` and `OK`.
- The two validation processes ran sequentially with one CPU thread. Their measured peak RSS was 217,333,760 and 221,462,528 bytes respectively. No packages or new environment were installed.
- After testing, `just fmt` ran from the repair worktree's `codex-rs` directory and exited 0. It reported no changed files requiring a language formatter; the workflow bytes stayed unchanged. Tests were not rerun after formatting.
- `git diff --check` passed. The only changed tracked file is the catalog workflow. All other present tracked-file hashes are unchanged, and the frozen original worktree's HEAD, tracked status and catalog YAML remained unchanged.

Final workflow SHA-256: `8e2ee90213e0df85f9adfda4bf646a1c0b353fd73e9a3f723c18c6e5e91715b5`.

This local validation reuses the existing runtime; the clean hosted fixture installation must still be verified by the new repair PR's exact-head CI. These six catalog tests are a separate repair gate and are not added to the frozen population suite's 73-test count. The original failure and r1/r2 proposals remain preserved.

The frozen `07df4a9` three-seed population study keeps its original source identity. This repair is a separate source change and does not replace the historical failed run or its evidence.
