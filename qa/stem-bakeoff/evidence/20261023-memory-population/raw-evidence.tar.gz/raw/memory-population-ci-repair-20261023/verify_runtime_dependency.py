"""Small optional repair smoke check; does not load a model or alter a repo."""

import datetime
import importlib.metadata
import json
import sys


def main():
    expected = {
        "packaging": "26.3",
        "safetensors": "0.6.2",
        "numpy": "1.26.4",
        "torch": "2.5.1+cpu",
    }
    versions = {name: importlib.metadata.version(name) for name in expected}
    if versions != expected:
        raise RuntimeError({"expected": expected, "actual": versions})

    from packaging.version import Version
    import torch
    from safetensors.torch import load, save

    torch.set_num_threads(1)
    assert Version(torch.__version__) >= Version("2.5.1")
    original = torch.tensor([0.0, 1.0, -2.5], dtype=torch.float32)
    payload = save({"fixture": original})
    restored = load(payload)
    assert set(restored) == {"fixture"}
    assert torch.equal(original, restored["fixture"])
    print(json.dumps({
        "schema": "hepta.ci.catalog-runtime-import-smoke.v1",
        "checked_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "passed": True,
        "python": sys.version,
        "versions": versions,
        "packaging_version_import": True,
        "safetensors_torch_import": True,
        "three_value_in_memory_round_trip": True,
        "serialized_bytes": len(payload),
        "model_loaded": False,
        "repository_modified": False,
        "clean_minimal_environment_proven": False,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
