## Problem

The catalog shadow job at `cbd139ad7cfeaf0be226688f2475cdeb364aa3e1` failed before executing the catalog tests. `test_metadata_catalog.py` imports `safetensors.torch`, which imports `packaging.version`, but the fixture installation omitted `packaging`. Run `39916012060`, job `120289644892`, therefore ended with `ModuleNotFoundError: No module named 'packaging'`. Its original log, runtime listing, source identity, and artifact are preserved.

The catalog workflow at `07df4a9cc385375cddded5b5e3b99632ce0652ec` is byte-identical to the failing workflow, so the dependency omission is still present at the proposed repair base.

## Changes

- Install `packaging==26.3` alongside the existing pinned NumPy and safetensors packages. That exact packaging version is present in the successful `07df4a9` mechanism CI runtime and the local study runtime, both using `safetensors==0.6.2` and CPU `torch==2.5.1`.
- Preserve `workflow_dispatch` and the existing catalog PR branch condition, and additionally allow exactly `codex/memory-catalog-runtime-fix-20261023` for pull request events. This explicit trigger-scope change lets the repair PR execute the same catalog checks through the available PR workflow. It does not admit arbitrary branches.

The runner, timeout, permissions, `SOURCE_SHA`, catalog test command, source-integrity checks, and artifact preservation remain unchanged.

## Validation status before publication

The complete r2 patch passes `git apply --check` against an independent copy of the exact `07df4a9` workflow. Reversing the two intended substitutions reproduces the original bytes. The r1 dependency-only proposal and all failure evidence are retained.

The dependency import smoke check and existing catalog suite should run in the isolated repair checkout before publication. Their outcomes, the final formatting check, and the new exact-head CI result must be added to this description from their actual receipts; they have not been claimed as passed in this preparation note.

The frozen `07df4a9` three-seed population study keeps its original source identity. This repair is a separate source change and does not replace the historical failed run or its evidence.
