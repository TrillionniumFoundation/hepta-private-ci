"""Run one authorized repair validation stage and preserve its resource receipt."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


ROOT = Path("/workspace/scratch/1d69f04ee9f4")
WORKTREE = ROOT / "memory-population-ci-repair-worktree-20261023"
OUTPUT = Path(__file__).resolve().parent
PYTHON = ROOT / "parametric-venv/bin/python"


def main():
    stage = sys.argv[1]
    choices = {
        "smoke": (
            [str(PYTHON), "-B", str(OUTPUT.parent / "verify_runtime_dependency.py")],
            WORKTREE,
        ),
        "catalog": (
            [str(PYTHON), "-B", "-m", "unittest", "discover", "-s",
             "scripts/memory_cell_catalog", "-p", "test_metadata_catalog.py", "-v"],
            WORKTREE,
        ),
        "format": (
            ["/tmp/hepta-output-portfolio-env/bin/just", "fmt"],
            WORKTREE / "codex-rs",
        ),
    }
    command, cwd = choices[stage]
    overrides = {
        "PYTHONPATH": ":".join([
            "/tmp/parametric-runtime-1d69f04ee9f4",
            str(WORKTREE / "scripts/memory_cell"),
            str(WORKTREE / "scripts/memory_cell_catalog"),
        ]),
        "PYTHONDONTWRITEBYTECODE": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "HF_HUB_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1",
    }
    environment = os.environ | overrides
    environment["PATH"] = "/tmp/hepta-output-portfolio-env/bin:" + os.environ["PATH"]
    memory_path = Path("/sys/fs/cgroup/memory.current")
    memory_before = int(memory_path.read_text())
    memory_peak = memory_before
    started_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    start = time.monotonic()
    path = OUTPUT / (stage + ".log")
    with path.open("xb") as stream:
        child = subprocess.Popen(command, cwd=cwd, env=environment,
                                 stdout=stream, stderr=subprocess.STDOUT)
        while True:
            memory_peak = max(memory_peak, int(memory_path.read_text()))
            pid, status, usage = os.wait4(child.pid, os.WNOHANG)
            if pid:
                child.returncode = os.waitstatus_to_exitcode(status)
                break
            time.sleep(0.05)
    path.chmod(0o444)
    output = path.read_bytes()
    receipt = {
        "schema": "hepta.ci.repair-local-validation-stage.v1",
        "stage": stage,
        "command": command,
        "cwd": str(cwd),
        "environment_overrides": overrides,
        "path_prefix": "/tmp/hepta-output-portfolio-env/bin",
        "started_at": started_at,
        "completed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "wall_seconds": time.monotonic() - start,
        "exit_code": child.returncode,
        "process_peak_rss_bytes": int(usage.ru_maxrss) * 1024,
        "process_user_seconds": usage.ru_utime,
        "process_system_seconds": usage.ru_stime,
        "cgroup_memory_before_bytes": memory_before,
        "cgroup_memory_peak_observed_bytes": memory_peak,
        "cgroup_memory_after_bytes": int(memory_path.read_text()),
        "cgroup_memory_limit_bytes": int(Path("/sys/fs/cgroup/memory.max").read_text()),
        "log_path": str(path),
        "log_bytes": len(output),
        "log_sha256": hashlib.sha256(output).hexdigest(),
        "new_environment_installed": False,
        "pretrained_model_loaded": False,
        "worktree_head": subprocess.check_output(
            ["git", "-C", str(WORKTREE), "rev-parse", "HEAD"], text=True).strip(),
        "worktree_status": subprocess.check_output(
            ["git", "-C", str(WORKTREE), "status", "--porcelain"], text=True),
    }
    result = OUTPUT / (stage + "-receipt.json")
    with result.open("xb") as stream:
        stream.write((json.dumps(receipt, sort_keys=True, indent=2) + "\n").encode())
    result.chmod(0o444)
    print(json.dumps(receipt, sort_keys=True))
    raise SystemExit(child.returncode)


if __name__ == "__main__":
    main()
