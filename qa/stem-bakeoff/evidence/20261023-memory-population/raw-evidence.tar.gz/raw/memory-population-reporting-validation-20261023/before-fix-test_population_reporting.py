"""Exact heterogeneous storage and conservative population-reporting gates."""

import copy
import hashlib
import json
import lzma
from pathlib import Path
import sqlite3
import tempfile
import unittest
import zlib

from population_baselines import measure_exact
from population_fixtures import dataset, source_digest


def write_json(path, value):
    Path(path).write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


class PopulationExactBaselineTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.directory = Path(self.temporary.name)
        self.data = dataset(1907)

    def tearDown(self):
        self.temporary.cleanup()

    def test_complete_typed_sources_operations_and_actual_exact_storage(self):
        destination = self.directory / "baseline"
        receipt = measure_exact(self.data, destination, write_json)
        self.assertEqual(receipt["typed_operation_exact"], 1.0)
        self.assertEqual(len(receipt["typed_operation_rows"]), 120)
        probes = self.data["retention_final"] + self.data["transfer_final"] + self.data["ood_final"]
        for probe, row in zip(probes, receipt["typed_operation_rows"], strict=True):
            self.assertEqual((row["probe_id"], row["answer"], row["roots"], row["exact"]),
                             (probe["probe_id"], probe["value"], probe["source_roots"], True))
        self.assertTrue(all(row["answer"] == "unknown" for row in receipt["typed_operation_rows"][-24:]))
        self.assertFalse(receipt["semantic_projection_available"])
        self.assertTrue(receipt["source_metadata_retained"])
        payload = (destination / "complete_records.json").read_bytes()
        self.assertEqual(json.loads(payload), self.data["sources"])
        self.assertEqual(zlib.decompress((destination / "complete_records.zlib9").read_bytes()), payload)
        self.assertEqual(lzma.decompress((destination / "complete_records.lzma6").read_bytes()), payload)
        with sqlite3.connect(destination / "complete_records.sqlite3") as connection:
            recovered = [json.loads(row[0]) for row in connection.execute("SELECT payload FROM memory ORDER BY ordinal")]
        self.assertEqual(recovered, self.data["sources"])
        for name, metadata in receipt["measurements"].items():
            actual = (destination / name).read_bytes()
            self.assertEqual((metadata["bytes"], metadata["sha256"], metadata["lossless"]),
                             (len(actual), hashlib.sha256(actual).hexdigest(), True))
        best = receipt["smallest_complete_exact_representation"]
        self.assertEqual(best["bytes"], min(row["bytes"] for row in receipt["measurements"].values()))
        self.assertFalse(receipt["irreducible_entropy_bound_claimed"])

    def test_saved_seed_and_generator_independently_regenerate_full_ledger(self):
        destination = self.directory / "baseline"
        measure_exact(self.data, destination, write_json)
        bundle = (destination / "seed-and-generator.bin").read_bytes()
        self.assertEqual(zlib.decompress((destination / "seed-and-generator.zlib9").read_bytes()), bundle)
        header_size = int.from_bytes(bundle[:4], "little")
        header = json.loads(bundle[4:4 + header_size])
        source = bundle[4 + header_size:]
        self.assertEqual(hashlib.sha256(source).hexdigest(), header["source_sha256"])
        namespace = {"__name__": "retained_fixture_generator"}
        exec(compile(source, "retained-population-fixtures.py", "exec"), namespace)
        regenerated = namespace["dataset"](header["seed"])["sources"]
        self.assertEqual(regenerated, self.data["sources"])

    def test_probe_gold_changes_scoring_but_not_computed_answer(self):
        poisoned = copy.deepcopy(self.data)
        expected = poisoned["retention_final"][0]["value"]
        poisoned["retention_final"][0]["value"] = "unavailable probe gold"
        receipt = measure_exact(poisoned, self.directory / "baseline", write_json)
        first = receipt["typed_operation_rows"][0]
        self.assertEqual(first["answer"], expected)
        self.assertFalse(first["exact"])
        self.assertAlmostEqual(receipt["typed_operation_exact"], 119 / 120)

    def test_generator_cannot_claim_a_stale_digest_for_a_different_actual_ledger(self):
        changed = copy.deepcopy(self.data)
        changed["sources"][0]["value"] = "amber"
        source = changed["sources"][0]
        source["source_digest"] = source_digest({key: value for key, value in source.items() if key != "source_digest"})
        self.assertNotEqual(source_digest(changed["sources"]), changed["sources_sha256"])
        with self.assertRaises(ValueError):
            measure_exact(changed, self.directory / "mismatched", write_json)


if __name__ == "__main__":
    unittest.main()
