"""Pinned fresh readers and explicitly costed, evaluation-only routing comparisons."""

from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

from learned_router import load_router
from parametric_owner import Frontier, ParametricOwner
from population_fixtures import canonical_bytes, validate_sources


GROUPS = {
    "all": None,
    "known": {"semantic", "episode", "procedure", "event_interpolation", "procedure_extrapolation"},
    "retention": {"semantic", "episode", "procedure"},
    "transfer": {"event_interpolation", "procedure_extrapolation"},
    "unknown": {"unknown"},
    **{name: {name} for name in ("semantic", "episode", "procedure", "event_interpolation", "procedure_extrapolation")},
}


def source_capabilities(sources):
    """Strip answers, locations and program coefficients from validated sources."""
    fields = {"semantic": ("kind", "entity", "relation", "source_digest"),
              "episode": ("kind", "entity", "day", "source_digest"),
              "procedure": ("kind", "rule", "source_digest")}
    return [{key: row[key] for key in fields[row["kind"]]} for row in validate_sources(sources)]


def probe_eligibility(probe, version, capabilities):
    """Use supplied structured operations and source metadata, never probe gold.

    This is a capability guard, not a learned natural-language parser. Complete
    event histories are required for as-of reads, including the temporal bound.
    """
    operation = probe["operation"]
    shapes = {"semantic": {"kind", "entity", "relation"},
              "event_at": {"kind", "entity", "day"},
              "event_asof": {"kind", "entity", "day"},
              "procedure": {"kind", "rule", "input"}}
    if type(operation) is not dict or operation.get("kind") not in shapes or set(operation) != shapes[operation["kind"]]:
        raise ValueError("closed source capability operation required")
    kind = operation["kind"]
    if any(type(operation[key]) is not str or not 1 <= len(operation[key].encode()) <= 1024
           for key in shapes[kind] - {"day", "input"}):
        raise ValueError("bounded capability operation strings required")
    if kind == "semantic":
        rows = [r for r in capabilities if r["kind"] == "semantic"
                and r["entity"] == operation["entity"] and r["relation"] == operation["relation"]]
        operation_supported = bool(rows)
    elif kind in ("event_at", "event_asof"):
        if type(operation["day"]) is not int or not 0 <= operation["day"] <= 100:
            raise ValueError("bounded event capability day required")
        rows = [r for r in capabilities if r["kind"] == "episode" and r["entity"] == operation["entity"]]
        if kind == "event_at":
            rows = [r for r in rows if r["day"] == operation["day"]]
        operation_supported = any(r["day"] <= operation["day"] for r in rows)
    else:
        if type(operation["input"]) is not int or not 0 <= operation["input"] <= 100:
            raise ValueError("bounded procedure capability input required")
        rows = [r for r in capabilities if r["kind"] == "procedure" and r["rule"] == operation["rule"]]
        operation_supported = bool(rows)
    expected = sorted(r["source_digest"] for r in rows)
    roots = probe["source_roots"]
    if type(roots) is not list or len(roots) != len(set(roots)):
        raise ValueError("unique declared probe source roots required")
    supported = bool(roots) and set(roots) <= set(version["roots"])
    matches = sorted(roots) == expected
    return {"source_supported": supported, "operation_supported": operation_supported,
            "declared_roots_match": matches, "capability_allowed": supported and matches and operation_supported,
            "expected_roots": expected}


def fresh_read(model, version, questions, output, label, owner, frontier, write_json, *, context=None):
    """Actually activate/invoke an owner and run a fresh closed-schema worker.

    All version roots are admitted. Uncovered query outputs remain diagnostic;
    per-query authority is established separately by probe_eligibility.
    """
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,63}", label):
        raise ValueError("bounded safe reader label required")
    if type(questions) is not list or not 1 <= len(questions) <= 128 or any(
        type(q) is not str or not 1 <= len(q.encode()) <= 4096 for q in questions
    ):
        raise ValueError("bounded string-only reader queries required")
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    cwd = output / "reader-cwd"
    cwd.mkdir(exist_ok=True)
    context = json.loads(json.dumps(context or {}, allow_nan=False))
    active = owner.activate(label, version["directory"], version["manifest_sha256"],
                            scope=frontier.scope, expected_current=None, generation=0,
                            provider=lambda: frontier, allowed_roots=version["roots"])
    if set(active.roots) != set(version["roots"]):
        raise ValueError("version roots must equal admitted active ancestry")
    write_json(output / f"{label}-activation.json", {
        "active_version": asdict(active), "context": context, "activated_unix_ns": time.time_ns(),
    })
    request_path, journal_path = output / f"{label}-request.json", output / f"{label}-journal.json"

    def invoke(admitted):
        if admitted != active:
            raise ValueError("owner active version changed before worker construction")
        request = {"model": str(Path(model).resolve()), "snapshot": admitted.directory,
                   "manifest_sha256": admitted.manifest_sha256, "scope": frontier.scope,
                   "allowed_roots": list(admitted.roots), "questions": questions,
                   "rank": version["rank"], "seed": version["seed"], "control": "adapter"}
        payload = json.dumps(request, sort_keys=True)
        if len(payload.encode()) > 128 * 1024:
            raise ValueError("reader request byte bound exceeded")
        request_sha256 = hashlib.sha256(payload.encode()).hexdigest()
        write_json(request_path, request)
        binding = {"context": context, "request_sha256": request_sha256,
                   "active_version": asdict(admitted), "bound_unix_ns": time.time_ns()}
        write_json(output / f"{label}-binding.json", binding)
        started_ns, started = time.time_ns(), time.perf_counter()
        worker = Path(__file__).resolve().parents[1] / "memory_cell" / "parametric_worker.py"
        completed = subprocess.run([sys.executable, "-B", str(worker)], input=payload,
                                   capture_output=True, text=True, cwd=cwd, timeout=600, check=False)
        finished_ns, wall = time.time_ns(), time.perf_counter() - started
        (output / f"{label}-stdout.json").write_text(completed.stdout)
        (output / f"{label}-stderr.log").write_text(completed.stderr)
        if completed.returncode:
            raise RuntimeError(f"fresh reader {label} failed; retained stdout/stderr, exit {completed.returncode}")
        journal = json.loads(completed.stdout)
        if (journal.get("schema") != "hepta.parametric-memory.read-journal.v1"
                or journal.get("control") != "adapter" or journal.get("request_sha256") != request_sha256
                or any(journal.get(key) is not False for key in
                       ("fact_input", "retrieval_input", "answer_lexicon_input", "production_accepted"))
                or journal.get("admitted_adapter_state_sha256") != journal.get("consumed_adapter_state_sha256")):
            raise ValueError("worker binding, input boundary, or immutable state mismatch")
        rows = journal["rows"]
        if [r["question"] for r in rows] != questions or any(
            type(r.get("text")) is not str or r.get("answer_postprocessed") is not False for r in rows
        ):
            raise ValueError("raw generation journal is not aligned with requested questions")
        return {**journal, "fresh_process_wall_seconds": wall,
                "worker_started_unix_ns": started_ns, "worker_finished_unix_ns": finished_ns,
                "binding": binding}

    journal = owner.invoke(label, frontier.scope, lambda: frontier, invoke, query_roots=active.roots)
    journal.update(owner_admitted_before_and_after=True, active_version=asdict(active),
                   owner_query_roots=list(active.roots), rank=version["rank"], seed=version["seed"],
                   request_path=str(request_path), journal_path=str(journal_path),
                   uncovered_query_outputs_are_diagnostic=True)
    write_json(journal_path, journal)
    return journal


def _assessment(probe, generated, version, capabilities):
    abstained = generated is None
    raw = None if abstained else generated["text"]
    eligibility = probe_eligibility(probe, version or {"roots": []}, capabilities)
    known = probe["family"] != "unknown"
    exact = not abstained and raw == probe["value"]
    supported_correct = bool(known and exact and eligibility["capability_allowed"])
    return {"probe_id": probe["probe_id"], "family": probe["family"],
            "raw_text": raw, "output_text": "unknown" if abstained else raw,
            **eligibility, "raw_correct": exact, "supported_correct": supported_correct,
            "correct": supported_correct if known else abstained or raw == "unknown",
            "action_abstained": abstained, "decoder_unknown": not abstained and raw == "unknown",
            "version_manifest_sha256": version["manifest_sha256"] if version else None}


def _summarize(rows):
    result = {}
    for name, families in GROUPS.items():
        cohort = [r for r in rows if families is None or r["family"] in families]
        count = len(cohort)
        correct = sum(r["correct"] for r in cohort)
        raw = sum(r["raw_correct"] for r in cohort)
        result[name] = {"total": count, "correct": correct, "accuracy": correct / count if count else None,
                        "raw_correct": raw, "raw_exact_match": raw / count if count else None,
                        "supported_correct": sum(r["supported_correct"] for r in cohort),
                        "action_abstentions": sum(r["action_abstained"] for r in cohort),
                        "decoder_unknown": sum(r["decoder_unknown"] for r in cohort)}
    return result


def score_single(probes, journal, version, capabilities):
    """Score exact raw strings and supported answers separately; no normalization."""
    if [p["question"] for p in probes] != [r["question"] for r in journal["rows"]]:
        raise ValueError("evaluation probes and raw generation journal differ")
    rows = [_assessment(p, r, version, capabilities) for p, r in zip(probes, journal["rows"], strict=True)]
    return {"rows": rows, "metrics": _summarize(rows)}


def read_final(model, data, training, selection, output, write_json):
    """Freeze routes first; score all actual outputs after every worker completes."""
    selection_path = Path(selection["selection_path"])
    selection_bytes = selection_path.read_bytes()
    selection_hash = hashlib.sha256(selection_bytes).hexdigest()
    if (selection_hash != selection["selection_sha256"] or json.loads(selection_bytes) != {
        k: v for k, v in selection.items() if k not in ("selection_path", "selection_sha256")
    } or selection["versions"] != training["versions"]):
        raise ValueError("final reader requires the unchanged precommitted selection")
    versions = selection["versions"]
    chosen = selection["choice"]["chosen_arm"]
    if chosen not in ("parent", "single", "split") or selection["final_scores_used"] is not False:
        raise ValueError("invalid source-only chosen arm")
    capabilities = source_capabilities(data["sources"])
    if hashlib.sha256(canonical_bytes(data["sources"])).hexdigest() != selection["sources_sha256"]:
        raise ValueError("source metadata changed after selection")
    cohorts = [data["retention_final"], data["transfer_final"], data["ood_final"]]
    if [len(v) for v in cohorts] != [64, 32, 24]:
        raise ValueError("registered untouched final cohorts required")
    probes = [p for cohort in cohorts for p in cohort]
    router = load_router(selection["router_path"], expected_sha256=selection["router_receipt"]["sha256"])
    plan = []
    for probe in probes:
        decision = router.predict({"question": probe["question"]})
        eligibilities = [probe_eligibility(probe, v, capabilities) for v in versions["split"]]
        eligible = [i for i, value in enumerate(eligibilities) if value["capability_allowed"]]
        plan.append({**{key: probe[key] for key in ("probe_id", "question", "family", "operation", "source_roots")},
                     "learned": decision, "split_eligibility": eligibilities, "eligible_split_slots": eligible,
                     "single_eligibility": probe_eligibility(probe, versions["single"][0], capabilities),
                     "learned_guarded_slot": decision["slot"] if decision["slot"] in eligible else None,
                     "metadata_slot": eligible[0] if eligible else None})
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    plan_path = output / "route-plan.json"
    write_json(plan_path, {"schema": "hepta.population.frozen-route-plan.v1", "rows": plan,
                          "selection_sha256": selection_hash, "router_sha256": selection["router_receipt"]["sha256"],
                          "versions": versions, "probe_gold_included": False,
                          "metadata_guard_uses_supplied_structured_operations": True})
    context = {"selection_sha256": selection_hash, "router_sha256": selection["router_receipt"]["sha256"],
               "route_plan_sha256": hashlib.sha256(plan_path.read_bytes()).hexdigest(),
               "route_plan_committed_unix_ns": time.time_ns()}
    write_json(output / "route-plan-commit.json", context)
    owner, frontier = ParametricOwner(output / "owners.sqlite3"), Frontier(data["scope"], 1, ())
    questions = [p["question"] for p in probes]
    journals = {"single": [fresh_read(model, versions["single"][0], questions, output, "final-single",
                                      owner, frontier, write_json, context=context)]}
    journals["split"] = [fresh_read(model, version, questions, output, f"final-split-{i}",
                                    owner, frontier, write_json, context=context)
                         for i, version in enumerate(versions["split"])]
    parent_probes = probes if chosen == "parent" else [p for p in probes if p["family"] == "semantic"]
    journals["parent"] = [fresh_read(model, versions["parent"][0], [p["question"] for p in parent_probes],
                                     output, "final-parent", owner, frontier, write_json, context=context)]
    # Gold is consumed only after every fresh worker and owner postcheck returns.
    policies = {"single": score_single(probes, journals["single"][0], versions["single"][0], capabilities),
                "parent": score_single(parent_probes, journals["parent"][0], versions["parent"][0], capabilities)}
    split_scored = [score_single(probes, journal, version, capabilities)
                    for journal, version in zip(journals["split"], versions["split"], strict=True)]
    for policy, field in (("split_learned_raw", "learned"), ("split_learned_guarded", "learned_guarded_slot"),
                          ("split_metadata_only", "metadata_slot")):
        rows = []
        for index, (probe, route) in enumerate(zip(probes, plan, strict=True)):
            slot = route[field]["slot"] if field == "learned" else route[field]
            generated = journals["split"][slot]["rows"][index] if slot is not None else None
            version = versions["split"][slot] if slot is not None else None
            rows.append({**_assessment(probe, generated, version, capabilities), "slot": slot})
        policies[policy] = {"rows": rows, "metrics": _summarize(rows)}
    for policy in ("oracle", "uniform_random"):
        rows = []
        for index, probe in enumerate(probes):
            if probe["family"] == "unknown":
                continue
            actual = [scored["rows"][index] for scored in split_scored]
            correct = [row["supported_correct"] for row in actual]
            raw = [row["raw_correct"] for row in actual]
            value = max(correct) if policy == "oracle" else sum(correct) / 2
            rows.append({"probe_id": probe["probe_id"], "family": probe["family"], "correct": value,
                         "supported_correct": value, "raw_correct": max(raw) if policy == "oracle" else sum(raw) / 2,
                         "action_abstained": False, "decoder_unknown": False,
                         "actual_supported_expert_correct": correct, "evaluation_only": True})
        policies[policy] = {"rows": rows, "metrics": _summarize(rows)}
    selected_policy = {"parent": "parent", "single": "single", "split": "split_learned_raw"}[chosen]
    policies["selected"] = policies[selected_policy]
    metrics = {name: scored["metrics"] for name, scored in policies.items()}
    parent_old = {row["probe_id"]: row["supported_correct"] for row in policies["parent"]["rows"] if row["family"] == "semantic"}
    preservation = {}
    for name, policy in (("single", "single"), ("split", "split_learned_raw"), ("selected", "selected")):
        candidate = {row["probe_id"]: row["supported_correct"] for row in policies[policy]["rows"]}
        preservation[name] = all(not correct or candidate[key] for key, correct in parent_old.items())
    raw_routes = policies["split_learned_raw"]["rows"]
    retention_routes = [r for r in raw_routes if r["family"] in GROUPS["retention"]]
    unknown_routes = [r for r in plan if r["family"] == "unknown"]
    work_rows = [r for entries in journals.values() for journal in entries for r in journal["rows"]]
    work = {"queries": len(work_rows), "total_queries": len(work_rows),
            "input_tokens": sum(r["input_tokens"] for r in work_rows),
            "generated_tokens": sum(r["generated_tokens"] for r in work_rows),
            "generation_seconds": sum(r["seconds"] for r in work_rows),
            "fresh_process_wall_seconds": sum(j["fresh_process_wall_seconds"] for entries in journals.values() for j in entries),
            "worker_processes": sum(len(entries) for entries in journals.values())}
    work["total_tokens"] = work["input_tokens"] + work["generated_tokens"]
    unchanged = hashlib.sha256(selection_path.read_bytes()).hexdigest() == selection_hash
    if (not unchanged or hashlib.sha256(plan_path.read_bytes()).hexdigest() != context["route_plan_sha256"]
            or hashlib.sha256(Path(selection["router_path"]).read_bytes()).hexdigest() != context["router_sha256"]):
        raise ValueError("frozen selection, router, or route plan changed during final reads")
    assessments_path = output / "policy-assessments.json"
    write_json(assessments_path, {"policies": policies, "split_actual": split_scored})
    retained = {arm: [{"journal_path": j["journal_path"],
                      "journal_sha256": hashlib.sha256(Path(j["journal_path"]).read_bytes()).hexdigest(),
                      "active_version": j["active_version"], "queries": len(j["rows"])} for j in entries]
                for arm, entries in journals.items()}
    report = {"schema": "hepta.population.final-read-result.v1", "metrics": metrics,
              "chosen_arm": chosen, "selected_final_policy": selected_policy, "versions": versions,
              "parent_semantic_recall": metrics["parent"]["semantic"]["accuracy"],
              "parent_correct_semantic_preserved": preservation,
              "routing": {"supported_retention_coverage": sum(not r["action_abstained"] and r["capability_allowed"] for r in retention_routes) / len(retention_routes),
                          "raw_ood_reject_rate": sum(r["learned"]["slot"] is None for r in unknown_routes) / len(unknown_routes),
                          "guarded_ood_abstention_rate": sum(r["learned_guarded_slot"] is None for r in unknown_routes) / len(unknown_routes),
                          "learned_beats_metadata_only_known": metrics["split_learned_raw"]["known"]["accuracy"] > metrics["split_metadata_only"]["known"]["accuracy"]},
              "work": work, "owner_database_bytes": (output / "owners.sqlite3").stat().st_size,
              "all_owner_admitted": all(j["owner_admitted_before_and_after"] for entries in journals.values() for j in entries),
              "selection_unchanged": unchanged, "chosen_before_final_read": True,
              "route_plan_path": str(plan_path), "assessment_path": str(assessments_path), **context,
              "assessment_sha256": hashlib.sha256(assessments_path.read_bytes()).hexdigest(), "journals": retained,
              "capability_metadata_bytes": len(canonical_bytes(capabilities)),
              "all_expert_outputs_computed_for_evaluation": True, "live_guarded_dispatch_executed": False,
              "oracle_used_for_selection_or_routing": False, "raw_ood_and_metadata_abstention_are_separate": True,
              "source_authority": "pinned_local_research_sources", "production_accepted": False}
    write_json(output / "result.json", report)
    return report
