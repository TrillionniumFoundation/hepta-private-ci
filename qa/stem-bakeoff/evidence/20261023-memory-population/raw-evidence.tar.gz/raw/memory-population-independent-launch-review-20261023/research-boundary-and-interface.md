## 从 memory cell 到通用 memory：可验证的能力与兼容接口

**可行的工程方向是让不同记忆类型拥有各自的表示、读操作和学习目标，再用同一套版本、来源、预算与资格审查契约连接它们。** “通用”应表示跨任务和长期运行的能力逐项成立，不能由 cell 数量增加或一次分裂的收益直接推出。

### 把“通用”拆成可证伪的能力

| 能力 | 应接受什么反例 | 当前冻结实验的覆盖边界 |
|---|---|---|
| 事实保持 | 新写入后遗忘旧事实，或只记住训练问法 | 测源侧选择、不同措辞的最终64项回忆，以及父体答对的旧语义项是否逐项保留 |
| 时间记忆 | 把未来状态用于过去查询，或无法找出最近一次有效事件 | 测8个实体、固定事件日之间的16项查询；不覆盖任意时钟、乱序到达和因果冲突 |
| 程序记忆 | 只背诵输入输出，遇到新输入或规则组合就失败 | 测4条已知仿射取模规则的16项未训练输入；不覆盖新程序学习、程序组合或一般执行能力 |
| 长期适应 | 多轮更新累积干扰，更新与撤回无法正确重放 | 本轮是一个有限扩展周期；持续时间、长期分布变化与多轮生灭需另外冻结研究方案 |
| 路由与组织 | 学习路由不优于明确能力元数据；增长后成本超过收益 | 测两个专家的实际 oracle、随机期望、元数据与学习路由；不证明多节点拓扑演化 |
| 成本优势 | 省下的 adapter 字节被底座、路由、来源台账、重放和版本成本抵消 | 区分固定int8存储与完整系统成本；公开seed加生成器也是有效无损基线 |

后续研究应逐步扩大未见实体、时间分布、规则族、真实数据和长时序更新，并与静态专家、单体模型及可执行精确存储进行等预算比较。每次扩展先冻结任务、预算、阈值与最终集。有限实验可以支持有范围的泛化结论，不能认证任意任务上的“通用记忆”。这里的扩展方向不修改本轮已经冻结的门槛。

### 一个 cell type 应定义六件事

建议将类型定义为 `type_id + artifact + operator + learning_objective + retention_contract + cost_contract`。数据标签不足以构成新的类型：如果同一decoder、同一completion loss、同一读接口只是换了训练文本，得到的是异质任务数据，而不是已经验证的异质记忆架构。

| 设计项 | 具体含义 |
|---|---|
| Artifact | 带版本与摘要的表示，例如LoRA、时间索引、程序、统计状态；绑定底座/编码器、scope及完整来源依赖 |
| Operator | 明确允许的操作，例如事实读取、`as_of(time)`、程序执行；记录输入域和拒绝条件 |
| Learning objective | 与操作对应的目标，例如事实completion、事件状态预测、程序执行一致性；来源数据和最终评价严格分离 |
| Retention contract | 哪些旧能力必须保留、来源修正与撤回如何处理、是否必须从无污染来源完整重放 |
| Cost contract | 实际读写token、延迟、峰值内存、持久化字节、版本和重放成本；共享底座只计一次但不能省略 |
| Type identity | 在manifest中固定上述契约的schema与版本，禁止把一个类型的通过结果沿用为另一个类型的资格 |

因此 factual cell 可以采用小adapter加可追溯事实台账；episodic cell 可以采用事件日志、有效时间索引和可选预测器；procedural cell 可以保存可执行程序，或者保存接受独立执行验证的模型。是否使用微调应由压缩与泛化的实测收益决定。高熵、不可推导的精确内容仍需付出相应存储成本；已知规则则应与直接保存规则的基线竞争。

### 与当前 Hepta 边界兼容的接入方法

现有 `CellHeadV1` 是绑定 `cell_id / generation / encoder_digest / head_digest` 的不可变Q24仿射头，输出最多16个action logits、一个value估计、一个uncertainty估计及abstain。它适合作为共享编码器上的轻量决策入口；其中 `value_q24` 是头的标量估计，不能被解释成任意事实内容。实际记忆答案应由独立的typed operator返回。现有 `CellEvidenceV1` 已能绑定head与runtime收据、置信/OOD和资源记录，可作为新端口的证据连接点。[1][2]

建议新增的研究接口可以保持下面的职责划分；这些名称是设计建议，本轮没有把它们接入Rust生产运行时。

```text
MemoryCellManifestV1
  cell_id, type_id, generation, scope, parent_manifest_digests
  artifact_digest, base_or_encoder_digest, operator_schema_digest
  source_roots, objective_digest, retention_contract_digest, resource_envelope

read(request, admitted_version) -> MemoryReadResultV1
  answer_or_abstain, used_source_roots, uncertainty, runtime_receipt_digest

prepare_write(source_batch, parent_binding, budget) -> Candidate + WriteReceipt
prepare_split(source_only_statistics, parent_binding, total_budget)
  -> ChildCandidates + DependencyMapping + QualificationPlan

owner.commit(candidate, expected_generation, current_frontier, qualification)
  -> NewActiveVersion
```

`read`只消费已准入版本；`prepare_write`与`prepare_split`生成候选。更新走“候选训练→旧能力及新能力复核→来源/预算校验→owner原子切换版本”，读流量始终绑定明确的generation和frontier。拆分必须继承完整祖先依赖：参数来自父体，不能只把子体后来训练的来源写入lineage。事件历史或程序等不可拆依赖应整组分配；来源撤回影响全部相关后代，清理路由元数据本身不等于从参数中删除来源。

当前 `hepta-memory::NeuronPosition` 只允许 `MemoryRetrievalRank`、`WorkflowSelect`、`BranchRoute`，分别提出既有权重、阈值或预算参数的有限变化；proposal明确为Shadow/ProposalOnly，不能修改拓扑、权限或底座权重。[3] 因而新的memory写入、adapter安装及split/merge必须拥有独立候选契约与owner资格路径。不能把这些动作塞进现有position的delta里，或者把head的action logits直接当作安装授权。现有position可以继续为已有检索与分支行为提供有限建议。

### 本轮能证明的对象

冻结研究使用 **3个固定seed和真实SmolLM2底座；每个seed各有一个rank4父体、rank8单体对照、两个rank4同构子体、一次分区和一次选择**。分区来自真实来源梯度，路由来自实际专家utility，最终评价包含异质任务；它还没有运行多节点学习网络、跨节点通信、反复split/merge、迁移或自组织拓扑搜索。即使全部有范围的能力门槛通过，也只能说明这个有限population在指定条件下的表现。

要研究meta network，应在另一个预注册实验中，把节点与边视为可提议的版本化对象：比较固定拓扑和自适应拓扑，控制总参数、总训练/重放预算、通信量、读取扇出及延迟；同时保留跨节点来源闭包和撤回一致性。只有这种对照才能区分“形成了更有用的组织”与“增加了模型、计算或外部索引”。

源码依据，固定于 `07df4a9cc385375cddded5b5e3b99632ce0652ec`：

1. `codex-rs/hepta-neuron/src/cell_head.rs` 与 `codex-rs/hepta-neuron/CELL_HEAD.md`。
2. `codex-rs/hepta-neuron/src/cell_evidence.rs` 与 `codex-rs/hepta-neuron/CELL_EVIDENCE.md`。
3. `codex-rs/hepta-memory/src/neuron_proposal.rs`。
4. 本轮范围与固定门槛：`scripts/memory_cell_population/population_protocol.py`。
