"""One official frozen cohort audit, with external execution receipt and logs."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import time


BASE = Path(__file__).resolve().parent
STUDY = Path('/workspace/scratch/1d69f04ee9f4/memory-population-20261023')
REPO = Path('/workspace/scratch/1d69f04ee9f4/hepta-private-ci')
SOURCE = REPO / 'scripts/memory_cell_population'
EXPECTED_HEAD = '07df4a9cc385375cddded5b5e3b99632ce0652ec'
EXPECTED_AGGREGATE = 'a475372a8c55278523750cc9abef52ca129e3ce0655650fbc1e7a4ce498026b4'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()


def limits():
    bound = 384 * 1024 * 1024
    resource.setrlimit(resource.RLIMIT_AS, (bound, bound))
    os.nice(10)


def main():
    logdir = BASE / 'cohort-audit-execution'
    logdir.mkdir(exist_ok=False)
    report = BASE / 'independent-cohort-audit.json'
    command = ['/tmp/hepta-population-python', str(SOURCE / 'population_audit.py'),
               '--root', str(STUDY), '--output', str(report)]
    inputs = [STUDY / 'aggregate.json'] + [STUDY / f'seed-{seed}/result.json'
                                         for seed in (1907, 2719, 4051)]
    sources = sorted(SOURCE.glob('population_audit*.py')) + [SOURCE / 'population_fixtures.py']
    input_pins = {str(p): sha(p) for p in inputs}
    source_pins = {str(p): sha(p) for p in sources}
    receipt = {
        'schema': 'hepta.external-cohort-audit-execution.v1',
        'command': command, 'head_before': head(),
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'started_unix_ns': time.time_ns(), 'input_sha256': input_pins,
        'auditor_source_sha256': source_pins, 'runner_sha256': sha(Path(__file__)),
        'hard_address_space_limit_bytes': 384 * 1024 * 1024,
        'bytecode_writes_disabled': True, 'model_loaded_or_fit_run': False,
    }
    if receipt['head_before'] != EXPECTED_HEAD or sha(inputs[0]) != EXPECTED_AGGREGATE:
        raise ValueError('original frozen checkout and approved aggregate required')
    started = time.monotonic()
    stdout, stderr = logdir / 'stdout.log', logdir / 'stderr.log'
    with stdout.open('x') as out, stderr.open('x') as err:
        child = subprocess.Popen(command, cwd=REPO, stdout=out, stderr=err,
                                 preexec_fn=limits)
        pid, status, usage = os.wait4(child.pid, 0)
        child.returncode = os.waitstatus_to_exitcode(status)
    receipt.update({
        'returncode': child.returncode, 'child_pid': pid,
        'elapsed_seconds': time.monotonic() - started,
        'finished_unix_ns': time.time_ns(), 'head_after': head(),
        'input_files_unchanged': {str(p): sha(p) for p in inputs} == input_pins,
        'auditor_sources_unchanged': {str(p): sha(p) for p in sources} == source_pins,
        'child_peak_rss_bytes_from_wait4': usage.ru_maxrss * 1024,
        'child_user_cpu_seconds': usage.ru_utime,
        'child_system_cpu_seconds': usage.ru_stime,
        'stdout_path': str(stdout), 'stdout_sha256': sha(stdout),
        'stderr_path': str(stderr), 'stderr_sha256': sha(stderr),
        'report_exists': report.exists(), 'report_sha256': sha(report) if report.exists() else None,
        'scope': 'frozen artifact consistency and independent raw-result reconstruction; not remote attestation',
    })
    target = logdir / 'execution-receipt.json'
    with target.open('x') as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'receipt': str(target), 'receipt_sha256': sha(target),
                      'returncode': child.returncode, 'report': str(report),
                      'report_sha256': receipt['report_sha256'],
                      'peak_rss_bytes': receipt['child_peak_rss_bytes_from_wait4'],
                      'elapsed_seconds': receipt['elapsed_seconds']}))
    raise SystemExit(child.returncode)


if __name__ == '__main__':
    main()
