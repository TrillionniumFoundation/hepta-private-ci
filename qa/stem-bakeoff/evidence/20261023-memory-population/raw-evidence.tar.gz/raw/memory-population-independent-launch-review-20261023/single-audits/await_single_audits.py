"""External serialized frozen-auditor launcher; never modifies study artifacts."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time


OUT = Path(__file__).resolve().parent
STUDY = Path('/workspace/scratch/1d69f04ee9f4/memory-population-20261023')
REPO = Path('/workspace/scratch/1d69f04ee9f4/hepta-private-ci')
SOURCE = REPO / 'scripts/memory_cell_population'
ENTRY = SOURCE / 'population_audit.py'
PYTHON = '/tmp/hepta-population-python'
SEEDS = (1907, 2719, 4051)
WAIT_SECONDS = 10
MAXIMUM_SECONDS = 90 * 60
RSS_LIMIT_BYTES = 256 * 1024 * 1024
ADDRESS_SPACE_LIMIT_BYTES = 384 * 1024 * 1024
STOP = False


def stop(signum, frame):
    global STOP
    STOP = True


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def own_json(name, value):
    path = OUT / name
    temporary = OUT / (name + '.tmp')
    temporary.write_text(json.dumps(value, sort_keys=True, indent=2,
                                    allow_nan=False) + '\n')
    temporary.replace(path)


def cgroup():
    p = Path('/sys/fs/cgroup')
    result = {}
    for name in ('memory.current', 'memory.max', 'memory.events', 'memory.pressure'):
        try:
            result[name] = (p / name).read_text().strip()
        except OSError as error:
            result[name] = repr(error)
    return result


def rss(pid):
    try:
        for line in Path(f'/proc/{pid}/status').read_text().splitlines():
            if line.startswith('VmRSS:'):
                return int(line.split()[1]) * 1024
    except (OSError, ValueError):
        pass
    return None


def limited_child():
    resource.setrlimit(resource.RLIMIT_AS,
                       (ADDRESS_SPACE_LIMIT_BYTES, ADDRESS_SPACE_LIMIT_BYTES))
    os.nice(10)


def main():
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, stop)
    started = time.monotonic()
    paths = sorted(SOURCE.glob('population_audit*.py')) + [SOURCE / 'population_fixtures.py']
    pins = {str(path): sha(path) for path in paths}
    registration = {
        'schema': 'hepta.external-single-audit-runner.registration.v1',
        'started_unix_ns': time.time_ns(),
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'pid': os.getpid(), 'study_root': str(STUDY), 'output_root': str(OUT),
        'registered_seeds': SEEDS, 'result_poll_seconds': WAIT_SECONDS,
        'maximum_wait_seconds': MAXIMUM_SECONDS, 'maximum_concurrent_audits': 1,
        'auditor_sources_sha256': pins, 'runner_sha256': sha(Path(__file__)),
        'rss_pause_threshold_bytes': RSS_LIMIT_BYTES,
        'hard_child_virtual_address_space_limit_bytes': ADDRESS_SPACE_LIMIT_BYTES,
        'resource_guard_is_not_a_scientific_gate': True,
        'bytecode_writes_disabled': True,
        'cohort_audit_requires_separate_root_notification': True,
        'cgroup_start': cgroup(),
    }
    own_json('registration.json', registration)
    done, receipts = set(), {}
    stopped_reason = None
    print(json.dumps({'stage': 'single-audit-waiter-started', 'pid': os.getpid(),
                      'output_root': str(OUT)}), flush=True)
    while time.monotonic() - started < MAXIMUM_SECONDS:
        if STOP:
            stopped_reason = 'signal_received'
            break
        for seed in SEEDS:
            if seed in done:
                continue
            result = STUDY / f'seed-{seed}' / 'result.json'
            try:
                raw = result.read_bytes()
                parsed = json.loads(raw)
            except (OSError, ValueError):
                continue
            if parsed.get('seed') != seed:
                stopped_reason = 'completed_result_seed_mismatch'
                break
            if {name: sha(Path(name)) for name in pins} != pins:
                stopped_reason = 'frozen_auditor_source_changed'
                break
            report = OUT / f'seed-{seed}-audit.json'
            command = [PYTHON, str(ENTRY), '--single', '--root', str(result.parent),
                       '--output', str(report)]
            stdout_path = OUT / f'seed-{seed}-stdout.log'
            stderr_path = OUT / f'seed-{seed}-stderr.log'
            launched = time.time_ns()
            receipt = {'schema': 'hepta.external-single-audit-execution.v1',
                       'seed': seed, 'command': command, 'launched_unix_ns': launched,
                       'input_result_sha256': hashlib.sha256(raw).hexdigest(),
                       'stdout_path': str(stdout_path), 'stderr_path': str(stderr_path),
                       'resource_before': cgroup(), 'maximum_observed_rss_bytes': 0,
                       'resource_paused': False}
            print(json.dumps({'stage': 'single-audit-started', 'seed': seed,
                              'result_sha256': receipt['input_result_sha256']}), flush=True)
            with stdout_path.open('x') as out, stderr_path.open('x') as err:
                child = subprocess.Popen(command, cwd=REPO, stdout=out, stderr=err,
                                         preexec_fn=limited_child)
                while child.poll() is None:
                    current = rss(child.pid)
                    if current is not None:
                        receipt['maximum_observed_rss_bytes'] = max(
                            current, receipt['maximum_observed_rss_bytes'])
                    if STOP or (current is not None and current > RSS_LIMIT_BYTES):
                        receipt['resource_paused'] = not STOP
                        receipt['interrupted_by_signal'] = STOP
                        child.terminate()
                        try:
                            child.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            child.kill()
                        break
                    time.sleep(1)
                receipt['returncode'] = child.wait()
            error_text = stderr_path.read_text()
            if 'MemoryError' in error_text or 'Cannot allocate memory' in error_text:
                receipt['resource_paused'] = True
            receipt.update({
                'finished_unix_ns': time.time_ns(), 'resource_after': cgroup(),
                'stdout_sha256': sha(stdout_path), 'stderr_sha256': sha(stderr_path),
                'audit_report_exists': report.exists(),
                'audit_report_sha256': sha(report) if report.exists() else None,
                'input_result_unchanged': sha(result) == hashlib.sha256(raw).hexdigest(),
                'auditor_sources_unchanged': {name: sha(Path(name)) for name in pins} == pins,
                'scientific_failure_is_not_audit_failure': True,
            })
            own_json(f'seed-{seed}-execution-receipt.json', receipt)
            receipts[str(seed)] = receipt
            done.add(seed)
            own_json('status.json', {'finished': False, 'receipts': receipts,
                                    'pending': [s for s in SEEDS if s not in done]})
            print(json.dumps({'stage': 'single-audit-finished', 'seed': seed,
                              'returncode': receipt['returncode'],
                              'maximum_observed_rss_bytes': receipt['maximum_observed_rss_bytes'],
                              'resource_paused': receipt['resource_paused']}), flush=True)
            if receipt['resource_paused'] or STOP:
                stopped_reason = 'resource_guard_paused_further_audits' if not STOP else 'signal_received'
                break
        if stopped_reason or len(done) == len(SEEDS):
            break
        time.sleep(WAIT_SECONDS)
    stopped_reason = stopped_reason or ('all_single_audits_attempted' if len(done) == len(SEEDS)
                                        else 'maximum_wait_duration_reached')
    own_json('status.json', {'finished': True, 'stop_reason': stopped_reason,
                            'receipts': receipts, 'pending': [s for s in SEEDS if s not in done]})
    print(json.dumps({'stage': 'single-audit-waiter-finished', 'reason': stopped_reason}), flush=True)


if __name__ == '__main__':
    main()
