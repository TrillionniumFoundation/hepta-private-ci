"""External, read-only study milestone observations; not execution attestation."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import time


STUDY = Path('/workspace/scratch/1d69f04ee9f4/memory-population-20261023')
REPO = Path('/workspace/scratch/1d69f04ee9f4/hepta-private-ci')
OUT = Path(__file__).resolve().parent
SEEDS = (1907, 2719, 4051)
INTERVAL_SECONDS = 0.05
MAXIMUM_SECONDS = 90 * 60
LABELS = ('final-single', 'final-split-0', 'final-split-1', 'final-parent')
SOURCE_NAMES = ('population_selection.py', 'population_reads.py',
                'population_worker.py', 'population_trial.py')
SPECS = [('selection', 'selection/precommitted-selection.json'),
         ('route_plan', 'final/route-plan.json'),
         ('route_commit', 'final/route-plan-commit.json')]
for label in LABELS:
    for kind in ('request', 'stdout', 'journal'):
        SPECS.append((f'{label}_{kind}', f'final/{label}-{kind}.json'))
SPECS += [('final_result', 'final/result.json'), ('trial_result', 'result.json')]
STOP = False


def stopped(signum, frame):
    global STOP
    STOP = True


def utc(ns):
    return datetime.datetime.fromtimestamp(
        ns / 1_000_000_000, datetime.timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      allow_nan=False).encode()


def write_own_json(name, value):
    target = OUT / name
    temporary = OUT / (name + '.tmp')
    temporary.write_bytes(json.dumps(value, indent=2, sort_keys=True,
                                    allow_nan=False).encode() + b'\n')
    temporary.replace(target)


def stat_state(path):
    start = time.time_ns()
    try:
        st = path.stat()
        value = {'exists': True, 'bytes': st.st_size,
                 'mtime_ns': st.st_mtime_ns, 'ctime_ns': st.st_ctime_ns}
    except FileNotFoundError:
        value = {'exists': False}
    except OSError as error:
        value = {'exists': None, 'error': repr(error)}
    return {**value, 'check_started_unix_ns': start,
            'check_finished_unix_ns': time.time_ns()}


def final_states(seed):
    base = STUDY / f'seed-{seed}'
    return {name: stat_state(base / relative) for name, relative in SPECS
            if name != 'selection'}


def current_selection(seed):
    path = STUDY / f'seed-{seed}' / 'selection/precommitted-selection.json'
    try:
        raw = path.read_bytes()
        json.loads(raw)
        return {'sha256': sha(raw), 'bytes': len(raw),
                'observed_unix_ns': time.time_ns()}
    except (OSError, ValueError) as error:
        return {'unreadable': repr(error), 'observed_unix_ns': time.time_ns()}


def main():
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, stopped)
    started = time.time_ns()
    mono_start = time.monotonic_ns()
    sources = {}
    for name in SOURCE_NAMES:
        path = REPO / 'scripts/memory_cell_population' / name
        raw = path.read_bytes()
        sources[str(path)] = {'sha256': sha(raw), 'bytes': len(raw)}
    registration = {
        'schema': 'hepta.external-milestone-observation.registration.v1',
        'started_unix_ns': started, 'started_utc': utc(started),
        'started_monotonic_ns': mono_start, 'pid': os.getpid(),
        'study_root': str(STUDY), 'output_directory': str(OUT),
        'maximum_seconds': MAXIMUM_SECONDS, 'poll_seconds': INTERVAL_SECONDS,
        'seeds': SEEDS, 'path_specs': SPECS,
        'path_specs_derived_from_frozen_source': sources,
        'watcher_sha256': sha(Path(__file__).read_bytes()),
        'writes_only_to_output_directory': True,
        'imports_model_runtime_or_executes_tests': False,
        'limitations': [
            'Polling may miss a stage before the next file appears.',
            'Existence snapshots are sequential checks, not an atomic filesystem snapshot.',
            'Observer timestamps are host observations, not remote execution attestations.',
            'A missing output file does not itself prove the worker has not started.'
        ],
        'initial_states': {str(seed): {name: stat_state(STUDY / f'seed-{seed}' / rel)
                                     for name, rel in SPECS} for seed in SEEDS},
    }
    write_own_json('registration.json', registration)
    seen, invalid, observations = set(), {}, {}
    last_hash = None
    reason = 'maximum_duration_reached'
    event_file = OUT / 'events.jsonl'

    def summary(finished=False):
        write_own_json('summary.json', {
            'schema': 'hepta.external-milestone-observation.summary.v1',
            'started_unix_ns': started, 'updated_unix_ns': time.time_ns(),
            'finished': finished, 'stop_reason': reason if finished else None,
            'observations': observations, 'invalid_json_attempts': invalid,
            'last_event_sha256': last_hash, 'event_file': str(event_file),
            'all_trial_results_observed': all((s, 'trial_result') in seen for s in SEEDS),
        })

    summary()
    print(json.dumps({'stage': 'watcher-started', 'pid': os.getpid(),
                      'directory': str(OUT), 'poll_seconds': INTERVAL_SECONDS}), flush=True)
    with event_file.open('x', buffering=1) as log:
        while time.monotonic_ns() - mono_start < MAXIMUM_SECONDS * 1_000_000_000:
            if STOP:
                reason = 'signal_received'
                break
            for seed in SEEDS:
                for name, relative in SPECS:
                    key = (seed, name)
                    if key in seen:
                        continue
                    path = STUDY / f'seed-{seed}' / relative
                    before = stat_state(path)
                    if before['exists'] is not True:
                        continue
                    read_started = time.time_ns()
                    try:
                        raw = path.read_bytes()
                        parsed = json.loads(raw)
                    except (OSError, ValueError) as error:
                        invalid_key = f'{seed}/{name}'
                        item = invalid.setdefault(invalid_key, {'attempts': 0,
                            'first_attempt_unix_ns': read_started, 'first_error': repr(error)})
                        item['attempts'] += 1
                        continue
                    complete = time.time_ns()
                    complete_mono = time.monotonic_ns()
                    after = stat_state(path)
                    final = final_states(seed)
                    event = {
                        'schema': 'hepta.external-milestone-observation.event.v1',
                        'sequence': len(seen) + 1, 'seed': seed, 'milestone': name,
                        'path': str(path), 'sha256': sha(raw), 'bytes': len(raw),
                        'read_started_unix_ns': read_started,
                        'first_complete_json_unix_ns': complete,
                        'first_complete_json_utc': utc(complete),
                        'first_complete_json_monotonic_ns': complete_mono,
                        'already_existed_at_watcher_start': registration['initial_states'][str(seed)][name]['exists'],
                        'stat_before': before, 'stat_after': after,
                        'unchanged_stat_during_read': all(before.get(k) == after.get(k)
                                                         for k in ('bytes', 'mtime_ns', 'ctime_ns')),
                        'final_file_states_after_complete_json_read': final,
                        'selection_current': current_selection(seed),
                        'previous_event_sha256': last_hash,
                    }
                    if name == 'selection':
                        event['all_final_request_checks_absent'] = all(
                            final[f'{label}_request']['exists'] is False for label in LABELS)
                        event['all_final_output_checks_absent'] = all(
                            final[f'{label}_stdout']['exists'] is False for label in LABELS)
                        event['chosen_arm'] = parsed.get('choice', {}).get('chosen_arm')
                    if name in ('selection', 'route_plan', 'route_commit'):
                        snapshot = OUT / f'seed-{seed}-{name}-first-observed.json'
                        snapshot.write_bytes(raw)
                        event['first_observed_bytes_snapshot'] = str(snapshot)
                    last_hash = sha(canonical(event))
                    log.write(json.dumps({**event, 'event_sha256': last_hash},
                                         sort_keys=True, allow_nan=False) + '\n')
                    log.flush()
                    os.fsync(log.fileno())
                    seen.add(key)
                    observations[f'{seed}/{name}'] = {
                        'sha256': event['sha256'], 'first_complete_json_unix_ns': complete,
                        'event_sequence': event['sequence']}
                    summary()
                    print(json.dumps({'stage': 'milestone', 'seed': seed, 'milestone': name,
                                      'utc': utc(complete), 'sha256': event['sha256']}), flush=True)
            if all((seed, 'trial_result') in seen for seed in SEEDS):
                reason = 'all_three_trial_results_observed'
                break
            time.sleep(INTERVAL_SECONDS)
    summary(finished=True)
    print(json.dumps({'stage': 'watcher-finished', 'reason': reason,
                      'observations': len(observations)}), flush=True)


if __name__ == '__main__':
    main()
