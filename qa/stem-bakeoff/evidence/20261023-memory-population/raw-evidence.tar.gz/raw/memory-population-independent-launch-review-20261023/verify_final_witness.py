"""Verify the completed external observation chain against the static study."""

import datetime
import hashlib
import json
from pathlib import Path


BASE = Path(__file__).resolve().parent
WATCH = BASE / 'milestone-watcher-20261023T094905Z'
STUDY = Path('/workspace/scratch/1d69f04ee9f4/memory-population-20261023')
SEEDS = (1907, 2719, 4051)
LABELS = ('final-single', 'final-split-0', 'final-split-1', 'final-parent')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def require(value, why):
    if not value:
        raise ValueError(why)


def main():
    registration = read(WATCH / 'registration.json')
    summary = read(WATCH / 'summary.json')
    require(summary['finished'] is True and summary['all_trial_results_observed'] is True
            and summary['stop_reason'] == 'all_three_trial_results_observed',
            'witness must have completed normally before final verification')
    require(registration['watcher_sha256'] == sha((WATCH / 'watch_milestones.py').read_bytes()),
            'watcher source pin')
    for path, item in registration['path_specs_derived_from_frozen_source'].items():
        raw = Path(path).read_bytes()
        require(len(raw) == item['bytes'] and sha(raw) == item['sha256'],
                'frozen source defining actual milestone paths')
    require(all(item['exists'] is False for states in registration['initial_states'].values()
                for item in states.values()), 'all observed artifacts absent at watcher start')
    events_raw = (WATCH / 'events.jsonl').read_bytes()
    previous, events = None, []
    for line in events_raw.splitlines():
        item = json.loads(line)
        claimed = item.pop('event_sha256')
        actual = sha(json.dumps(item, sort_keys=True, separators=(',', ':'),
                               allow_nan=False).encode())
        require(actual == claimed and item['previous_event_sha256'] == previous
                and item['sequence'] == len(events) + 1, 'complete ordered event hash chain')
        require(sha(Path(item['path']).read_bytes()) == item['sha256'],
                'first observed bytes match final retained artifact')
        if 'first_observed_bytes_snapshot' in item:
            require(sha(Path(item['first_observed_bytes_snapshot']).read_bytes()) == item['sha256'],
                    'first observed critical byte snapshot')
        previous = claimed
        events.append(item)
    expected = {(seed, name) for seed in SEEDS for name, relative in registration['path_specs']}
    require({(item['seed'], item['milestone']) for item in events} == expected
            and len(events) == len(expected), 'each registered milestone observed exactly once')
    require(summary['last_event_sha256'] == previous, 'final summary chain pin')
    findings = {}
    for seed in SEEDS:
        by_name = {item['milestone']: item for item in events if item['seed'] == seed}
        selection = by_name['selection']
        require(all(item['selection_current'].get('sha256') == selection['sha256']
                    for item in by_name.values()), 'selection unchanged at each milestone')
        result_path = STUDY / f'seed-{seed}/result.json'
        result = read(result_path)
        audit = read(BASE / f'single-audits/seed-{seed}-audit.json')
        require(audit['passed'] is True and audit['result_sha256'] == sha(result_path.read_bytes()),
                'completed result independently audited')
        require(result['selection']['selection_sha256'] == selection['sha256']
                and result['selection']['choice']['chosen_arm'] == selection['chosen_arm'],
                'first-observed source choice matches final retained result')
        file_observations = {}
        for name in ('selection', 'route_plan', 'route_commit'):
            event = by_name[name]
            states = event['final_file_states_after_complete_json_read']
            file_observations[name] = {
                'sha256': event['sha256'], 'observed_utc': event['first_complete_json_utc'],
                'all_final_requests_checked_absent': all(
                    states[f'{label}_request']['exists'] is False for label in LABELS),
                'all_final_outputs_checked_absent': all(
                    states[f'{label}_stdout']['exists'] is False for label in LABELS),
            }
        worker_checks = {}
        for label in LABELS:
            journal = read(STUDY / f'seed-{seed}/final/{label}-journal.json')
            context = journal['binding']['context']
            require(context['selection_sha256'] == selection['sha256']
                    and context['route_plan_sha256'] == by_name['route_plan']['sha256'],
                    'worker context binds first-observed immutable choices')
            worker_checks[label] = {
                'selection_observed_before_recorded_worker_start':
                    selection['first_complete_json_unix_ns'] < journal['worker_started_unix_ns'],
                'route_committed_before_recorded_worker_start':
                    context['route_plan_committed_unix_ns'] <= journal['worker_started_unix_ns'],
                'worker_started_unix_ns': journal['worker_started_unix_ns'],
            }
        findings[str(seed)] = {'chosen_arm': selection['chosen_arm'],
                              'critical_file_observations': file_observations,
                              'worker_bindings': worker_checks,
                              'trial_result_sha256': sha(result_path.read_bytes())}
    report = {
        'schema': 'hepta.external-final-milestone-verification.v1',
        'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'passed': True, 'complete_event_count': len(events),
        'events_sha256': sha(events_raw), 'last_event_sha256': previous,
        'registration_sha256': sha((WATCH / 'registration.json').read_bytes()),
        'watcher_summary_sha256': sha((WATCH / 'summary.json').read_bytes()),
        'verification_script_sha256': sha(Path(__file__).read_bytes()),
        'per_seed': findings,
        'all_selection_observations_preceded_request_files': all(
            value['critical_file_observations']['selection']['all_final_requests_checked_absent']
            for value in findings.values()),
        'limitations': [
            'Per-file existence checks are sequential, not an atomic filesystem snapshot.',
            'Unobserved route-before-request stages remain unobserved even when recorded worker ordering is valid.',
            'Observer and worker timestamps are host evidence, not independent remote execution attestation.'
        ],
    }
    output = BASE / 'final-witness-review.json'
    with output.open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'path': str(output), 'sha256': sha(output.read_bytes()),
                      'events': len(events), 'all_selections_preceded_requests':
                      report['all_selection_observations_preceded_request_files']}))


if __name__ == '__main__':
    main()
