# Hepta memory cell：实现边界与后续架构决策

本文是本轮研究证据的架构解释，随 Git evidence branch 保存。已经运行的实验与尚未实现的接口分开描述；本文不改变冻结协议、门槛或生产准入状态。

本文细化同目录较早的 `research-boundary-and-interface.md`：现有 `CellEvidenceV1` 不是泛型 memory receipt 接口，参数 lineage 不等于答案级因果来源；候选返回契约采用 `declared_dependency_roots + support_evidence`。较早草稿保留为讨论记录。

## 1. 可行的核心命题

可以把一种记忆表示封装为带有版本、来源、读写算子和资源预算的 cell，并让多个 cell 共享编码器或解码器。参数化表示是候选之一。新 cell 是否有用，必须由它在某类读写任务上的能力和成本决定。

“把一份记忆写进小模型参数”“多个专家有互补能力”“路由能调用正确专家”“不断增长的系统在长期分布变化中可靠”是四个不同命题。前一个成立不能推出后一个。本轮分别测量参数保持、专家与路由的有限表现；长期分布变化与自组织网络尚未测量。

模型记住事实与可逆编码也不同。需要精确恢复的内容要保留精确表示，或者提供包含模型、编码器、残差和元数据的完整 codec；单独报告权重文件缩小不足以证明净压缩收益。若只要求任务上有损的语义记忆，应先固定失真定义，例如可回答问题集、允许误差和不可丢失的旧能力。

## 2. 仓库中的实际接入边界

固定源码为 `07df4a9cc385375cddded5b5e3b99632ce0652ec`。

- [`CellHeadV1`](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/07df4a9cc385375cddded5b5e3b99632ce0652ec/codex-rs/hepta-neuron/src/cell_head.rs) 是绑定 cell/generation/encoder/head 摘要的不可变 Q24 仿射头，输出 action logits、标量 value、uncertainty 和 abstain。`value_q24` 不能承载任意记忆答案。
- [`CellEvidenceV1`](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/07df4a9cc385375cddded5b5e3b99632ce0652ec/codex-rs/hepta-neuron/src/cell_evidence.rs) 绑定头、运行时、置信/OOD 和资源证据。现有绑定函数接收 `CellHeadV1`、`CellHeadOutputV1`、`NeuronRuntimeOutputV1`，不是任意 memory operator receipt 的泛型接口；可以借鉴其绑定方式，但新算子仍需符合现有 runtime 验证的适配或新增契约。
- [`NeuronPosition`](https://github.com/TrillionniumFoundation/hepta-private-ci/blob/07df4a9cc385375cddded5b5e3b99632ce0652ec/codex-rs/hepta-memory/src/neuron_proposal.rs) 的现有位置为 `MemoryRetrievalRank`、`WorkflowSelect`、`BranchRoute`，只提出有限参数变化。其 shadow/proposal 权限不包括修改拓扑、安装 adapter 或更新底座。

因此，新的记忆答案应通过 typed operator 返回；训练、分裂和安装应走独立候选契约与 owner 提交路径。当前 Python 研究流水线已经生成实际模型、来源依赖、owner 准入与运行证据，尚未把新的 type registry、分布式节点或 split/merge 控制器接入 Rust 生产路径。

## 3. 类型不能只是一列标签

建议以六元组定义一个类型：

`type_id + artifact + operator + learning_objective + retention_contract + cost_contract`

| 类型候选 | 表示与算子 | 有意义的学习目标 | 必须竞争的基线 |
|---|---|---|---|
| Semantic cell | 小 adapter 或关联记忆网络；按实体/关系读取 | 事实保持、措辞鲁棒性、受校准的拒答 | 压缩事实表、检索加共享 reader |
| Episodic cell | 事件日志、有效时间索引、可选预测状态 | 时间一致性、乱序更新、按已声明时间与事件语义恢复状态 | 精确 `as_of(time)` 索引 |
| Procedural cell | 可执行 DSL/程序，或经执行验证的模型 | 未训练输入、新组合与执行一致性 | 直接保存并执行规则 |
| Statistical cell | 充分统计量、可合并 sketch 或小预测器 | 预先定义的估计误差、校准、漂移适应 | 同误差界的标准统计表示 |
| Associative cell | 共享编码器加小型可学习 key/value 映射 | 检索关联、抗干扰、受限更新 | 向量索引与线性关联记忆 |

后三行中尚未进入本轮实验的类型均是设计候选。当前实验的 semantic/event/procedure 三类操作使用同一个 SmolLM2+LoRA 架构、同类 completion loss，不能称为已经涌现了三种异构神经结构。

每个 cell 不必复制一套 135M 参数模型。建议按共享底座加小私有状态设计模型族，再用真实资源测量验证共享是否在实际执行中成立。模型文件共享不自动意味着多个进程的全部运行内存共享。本轮分别记录共享底座文件、实际加载的 float32 张量、private adapter、进程峰值与共享 cgroup 观察。

## 4. 候选接口及读写生命周期

以下是设计接口，不是对现有 Rust API 的声明。

```text
MemoryCellManifestV1
  cell_id, type_id, generation, scope
  parent_manifest_digests, artifact_digest, base_or_encoder_digest
  operator_schema_digest, objective_digest, retention_contract_digest
  source_roots, resource_envelope

read(request, admitted_version) -> MemoryReadResultV1
  answer_or_abstain, declared_dependency_roots, support_evidence
  uncertainty, runtime_receipt_digest

prepare_write(source_batch, parent_binding, budget)
  -> CandidateVersion + WriteReceipt

prepare_split(source_statistics, parent_binding, total_budget)
  -> ChildCandidates + SourceDependencyMapping + QualificationPlan

owner.commit(candidate, expected_generation, current_frontier, qualification)
  -> NewActiveVersion
```

写入流程是：固定来源与预算，生成候选，在独立数据上检查新能力和旧能力，检查来源闭包与资源，最后由 owner 原子切换。在仍通过当前 frontier 准入时，旧版本在切换前可继续服务；失败候选不能成为活动版本。读请求绑定明确 generation，不依赖可变目录名暗中替换权重。

来源 lineage 说明哪些数据可能影响版本，不自动给出某个神经输出的因果出处。精确算子可返回实际使用的事件/规则引用；纯参数化算子应返回完整声明依赖，并把答案级 support evidence 的缺失明确表示出来，不能把模型自己生成的来源说明当作证明。路由器的 utility 训练也依赖专家和来源，其版本与撤回处理应纳入同一依赖图。

分裂的孩子继承父参数，所以必须继承完整祖先来源依赖。后来只向某个孩子训练了部分新来源，不会消除它从父体继承的旧来源。事件历史和程序应按不可拆依赖组分配。撤回一条来源可能影响多个后代；撤销读取资格与证明参数已经遗忘该来源是不同操作。后者需要另行定义、执行并验证干净重放或其它清除程序。

## 5. 分裂、路由与网络组织的实用目标

分裂提议可以利用来源侧梯度干扰、误差簇、容量压力或不同读操作的冲突，但最终是否接受应按等预算候选比较。可以把目标写成：

`utility = task_quality - λs * retained_bytes - λw * update_work - λr * read_work - λc * communication`

各项必须在同一服务约束下定义；系数是产品选择，不是生物类比能确定的常数。遗忘、来源权限和延迟上限也可以作为硬约束，而不是被平均质量抵消。单体扩容、两个孩子、固定专家和不更新父体都应该是候选。

路由需要分开回答：该请求是否在可用范围内，以及哪个有资格的专家最可能答对。建议分别校准 support/reject 与条件 expert utility，保留 risk-coverage 曲线，而不只报告高拒答率或有回答样本上的准确率。真实路由收益应扣除串行重试、多个专家调用、模型切换和路由器本身的开销。

本轮保留了四个不同量：single 实测质量、eligible oracle 上限、固定元数据路由、学习路由实测质量。`oracle - single` 是固定专家输出集合相对 single 的评估上限差；它单独不能证明专家之间互补，因为一个专家支配另一个时也可能为正。互补应另看 `oracle - max(individual expert accuracy)` 和具体互补正确样本。`oracle - learned` 反映未被路由兑现的上限。oracle 使用评估答案选择正确专家，不能成为上线算法。在同一 probe 子集、同一资格与计分口径下，若固定输出矩阵满足 `oracle - metadata < 5pp`，任何只在该矩阵里选专家的路由器都不可能达到“比 metadata 高 5pp”的门槛；这不是降低门槛的理由。

来源侧已观察到的误拒答应在另一轮独立注册的实验里修复：正负样本覆盖相同措辞族；按实体、操作、模板与时间划分持出集；只在来源/校准集上选择阈值；最终集固定后不用于调参。不能把本轮事后忽略拒答的概率 argmax 当作新算法的通过结果。

meta network 的边也应是版本化对象，例如“该节点对这类请求的成功率估计与调用成本”，由控制器提议增删。节点局部优化受全局预算、最大扇出、回路深度和来源闭包约束。多节点调度还需要定义并发更新、frontier 一致性、失联节点、重试、迁移与跨节点撤回。当前一次两子体分裂不包含这些机制，不能作为自组织网络已经形成的证据。

## 6. 压缩的三个分母

1. **Checkpoint codec**：完整 packed artifact 除以完整原 checkpoint。本轮 int8 是预先固定的主方案，int4 是预先固定的辅助方案，两者均针对 full-source single，独立于拓扑选择。
2. **活动服务成本**：底座摊销、活动表示、router、必要精确来源、能力元数据、owner 状态、执行代码和实际运行资源。需要说清是热内存、磁盘、延迟还是 token 成本。
3. **全部保留成本**：再加上父版本、未被接受的候选、packed 与解码后副本、重放数据、审计记录和回滚材料。实验归档本身也不能被当作活动系统的压缩率。

如果为了精确修正、撤回和重放仍完整保留源记录，参数化 cell 可以改善热读取或泛化，但不能省略源记录后宣布总存储下降。某类精确历史若允许转移到冷存储，必须明示性能与恢复语义的变化。

本轮 codec 解码为 float32 adapter 再推理，因此证明的是持久化格式的缩小，不是整数推理、推理 RAM 降低或整个实验目录变小。完整净压缩主张还需要等价服务能力和完整系统成本；当前 lower-bound 成本报告没有冒充完成这些条件。

## 7. 从有限实验到更强的 memory 能力

后续应逐项扩大覆盖，每一层都有独立失败条件。

| 阶段 | 需要增加的实验 | 可以支持的结论 |
|---|---|---|
| 当前三 seed | 一个父体、一个单体、两个同构孩子；三类操作 | 该有限预算和任务上的分裂、路由、codec 及保持/迁移表现 |
| 长期局部更新 | 多次 arrival/replay、冲突修正、时间乱序、来源撤回 | 有限长期分布下的稳定性与更新成本 |
| 真正异构类型 | 为事件、程序和统计记忆采用不同表示与算子 | 哪种表示在特定操作上有优势 |
| 自适应网络 | 固定拓扑对照、多轮 split/merge、迁移、通信预算 | 拓扑调整是否产生净收益 |
| 更广泛任务 | 未见实体、规则族、语言、真实交互与跨任务组合 | 有边界的泛化能力；仍不能认证任意任务的通用 memory |

长期交互评测可以纳入 LongMemEval 的信息提取、多会话推理、时间推理、知识更新和拒答维度，但不能只跑外部 benchmark 总分来替代本系统的来源、版本和成本检查。[4]

## 8. 与相关研究的关系

- TTT 将隐状态表示为可在测试时通过自监督目标更新的小模型，支持“把学习过程作为记忆更新算子”的研究方向。[1]
- Titans 将神经长时记忆与短时注意力结合；MIRAS 把关联记忆架构、内部目标、保持机制和学习算法作为设计维度。这支持按操作和目标设计不同 cell，但没有证明 Hepta 中任意分裂会产生通用记忆。[2][3]
- MemoryLLM 研究固定 latent memory pool 的自更新，是另一种参数化记忆实例；它的实验结果不能直接替代本项目的运行证据。[5]
- 模型作为预测器可以进入实际压缩编码流程；应同时计入模型和恢复所需信息，避免把“能回答部分事实”误称为无损编码。[6]

以上文献提供机制和评测参考。将其组合成 Hepta typed cells、owner 准入和预算控制的具体设计，是本文基于仓库约束提出的工程推断。

### 主要来源

1. [Learning to (Learn at Test Time): RNNs with Expressive Hidden States](https://arxiv.org/abs/2407.04620)
2. [Titans: Learning to Memorize at Test Time](https://arxiv.org/abs/2501.00663)
3. [It's All Connected: A Journey Through Test-Time Memorization, Attentional Bias, Retention, and Online Optimization](https://arxiv.org/abs/2504.13173)
4. [LongMemEval: Benchmarking Chat Assistants on Long-Term Interactive Memory](https://arxiv.org/abs/2410.10813)
5. [MEMORYLLM: Towards Self-Updatable Large Language Models](https://arxiv.org/abs/2402.04624)
6. [Language Modeling Is Compression](https://arxiv.org/abs/2309.10668)
7. [本轮冻结协议与实际实现](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/07df4a9cc385375cddded5b5e3b99632ce0652ec/scripts/memory_cell_population)
