"""Post-hoc raw-output decomposition; no training, routing change, or new gate."""

import argparse
import datetime
import hashlib
import json
from pathlib import Path
import sys


ROOT = Path('/workspace/scratch/1d69f04ee9f4')
SOURCE = ROOT / 'hepta-private-ci/scripts/memory_cell_population'
sys.path.insert(0, str(SOURCE))
from population_audit_generation import _assessment

STUDY = ROOT / 'memory-population-20261023'
REVIEW = ROOT / 'memory-population-independent-launch-review-20261023'
GROUPS = {
    'retention': {'semantic', 'episode', 'procedure'},
    'semantic': {'semantic'}, 'episode': {'episode'}, 'procedure': {'procedure'},
    'transfer': {'event_interpolation', 'procedure_extrapolation'},
    'event_interpolation': {'event_interpolation'},
    'procedure_extrapolation': {'procedure_extrapolation'},
    'known': {'semantic', 'episode', 'procedure', 'event_interpolation',
              'procedure_extrapolation'},
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def require(value, message):
    if not value:
        raise ValueError(message)


def metrics(rows):
    n = len(rows)
    counts = [sum(row['child_correct'][slot] for row in rows) for slot in (0, 1)]
    eligible = [sum(row['child_eligible'][slot] for row in rows) for slot in (0, 1)]
    oracle = sum(any(row['child_correct']) for row in rows)
    both = sum(all(row['child_correct']) for row in rows)
    exclusive = [sum(row['child_correct'][slot] and not row['child_correct'][1-slot]
                     for row in rows) for slot in (0, 1)]
    single = sum(row['single_correct'] for row in rows)
    best = max(counts)
    best_slots = [slot for slot in (0, 1) if counts[slot] == best] if n else []
    require(oracle - best == min(exclusive), 'union minus best identity')
    require(oracle - single == (oracle - best) + (best - single), 'decomposition identity')
    rescue = {}
    for slot in best_slots:
        corrected = [row for row in rows if not row['child_correct'][slot]
                     and row['child_correct'][1-slot]]
        rescue[str(slot)] = {
            'total': len(corrected),
            'best_child_was_eligible': sum(row['child_eligible'][slot] for row in corrected),
            'best_child_was_ineligible': sum(not row['child_eligible'][slot] for row in corrected),
            'probe_ids': [row['probe_id'] for row in corrected],
        }
    ratio = lambda v: v / n if n else None
    return {
        'total': n, 'eligible_counts': eligible, 'child_correct_counts': counts,
        'child_accuracy': [ratio(v) for v in counts],
        'single_correct': single, 'single_accuracy': ratio(single),
        'oracle_correct': oracle, 'oracle_accuracy': ratio(oracle),
        'best_individual_child_slots': best_slots, 'best_child_correct': best,
        'best_child_accuracy': ratio(best),
        'both_children_correct': both, 'only_child_correct_counts': exclusive,
        'neither_child_correct': n - oracle,
        'oracle_minus_best_child_count': oracle - best,
        'oracle_minus_best_child_accuracy': ratio(oracle - best),
        'best_child_minus_single_count': best - single,
        'best_child_minus_single_accuracy': ratio(best - single),
        'oracle_minus_single_count': oracle - single,
        'oracle_minus_single_accuracy': ratio(oracle - single),
        'eligibility_patterns': {
            'both': sum(all(row['child_eligible']) for row in rows),
            'only_0': sum(row['child_eligible'] == [True, False] for row in rows),
            'only_1': sum(row['child_eligible'] == [False, True] for row in rows),
            'neither': sum(not any(row['child_eligible']) for row in rows),
        },
        'oracle_rescue_relative_to_each_best_child': rescue,
    }


def trial(seed):
    directory = STUDY / f'seed-{seed}'
    result_path = directory / 'result.json'
    # A complete trial result and a passed independent audit are prerequisites.
    # No final-output file is read before both have been admitted.
    result = read(result_path)
    require(result['seed'] == seed, 'completed trial seed identity')
    audit_path = REVIEW / f'single-audits/seed-{seed}-audit.json'
    audit = read(audit_path)
    require(audit['passed'] is True and audit['result_sha256'] == sha(result_path),
            'passed raw-evidence audit must pin this complete result')
    data_path = directory / 'dataset.json'
    assessment_path = directory / 'final/policy-assessments.json'
    data, assessment = read(data_path), read(assessment_path)
    probes = data['retention_final'] + data['transfer_final'] + data['ood_final']
    versions = result['training']['versions']
    journals = {}
    pins = {str(p): sha(p) for p in (result_path, audit_path, data_path, assessment_path)}
    for label in ('single', 'split-0', 'split-1'):
        path = directory / f'final/final-{label}-journal.json'
        journals[label] = read(path)['rows']
        pins[str(path)] = sha(path)
        require(len(journals[label]) == len(probes), 'actual final output row count')
    raw_rows = []
    for index, probe in enumerate(probes):
        actual = []
        for slot in (0, 1):
            generated = journals[f'split-{slot}'][index]
            require(generated['question'] == probe['question'], 'raw child question alignment')
            scored = _assessment(probe, generated, versions['split'][slot], data['sources'])
            require(scored == assessment['split_actual'][slot]['rows'][index],
                    'independent eligibility and correctness match retained assessment')
            actual.append(scored)
        generated = journals['single'][index]
        require(generated['question'] == probe['question'], 'raw single question alignment')
        single = _assessment(probe, generated, versions['single'][0], data['sources'])
        require(single == assessment['policies']['single']['rows'][index],
                'single independent reconstruction')
        if probe['family'] == 'unknown':
            continue
        raw_rows.append({
            'probe_id': probe['probe_id'], 'family': probe['family'],
            'child_correct': [row['supported_correct'] for row in actual],
            'child_eligible': [row['capability_allowed'] for row in actual],
            'child_raw_exact': [row['raw_correct'] for row in actual],
            'single_correct': single['supported_correct'],
        })
    groups = {}
    for name, families in GROUPS.items():
        rows = [row for row in raw_rows if row['family'] in families]
        whole = metrics(rows)
        overlap = metrics([row for row in rows if all(row['child_eligible'])])
        expected = result['final']['metrics']['oracle'][name]
        require((whole['total'], whole['oracle_correct']) ==
                (expected['total'], expected['correct']), 'registered oracle same denominator')
        groups[name] = {'all_registered_probes': whole, 'both_children_eligible_only': overlap}
    return {'seed': seed, 'input_sha256': pins, 'groups': groups, 'per_probe': raw_rows}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seeds', type=int, nargs='+', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(args.seeds in ([1907, 2719], [1907, 2719, 4051]), 'registered ordered complete subset')
    reports = [trial(seed) for seed in args.seeds]
    result = {
        'schema': 'hepta.external-child-complementarity-diagnostic.v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'seeds': args.seeds, 'post_hoc_diagnostic_only': True,
        'changes_training_selection_thresholds_or_claim_gates': False,
        'model_or_fit_executed': False,
        'raw_correctness_reconstructed_with_frozen_independent_capability_rule': True,
        'method': {
            'correct': 'raw exact answer AND source ancestry AND operation capability',
            'denominator': 'all probes in the named registered cohort, including ineligible probes as incorrect',
            'oracle': 'union of eligible correct outputs from the two fixed children',
            'best_child': 'higher empirical score of one fixed child within the named cohort; evaluation-only, no deployed selection',
            'decomposition': '(oracle - single) = (oracle - best child) + (best child - single)',
            'overlap_analysis': 'Recompute all quantities on only probes where BOTH children are eligible, with its own explicitly reported denominator.',
            'limits': [
                'Full-cohort expert complementarity includes imposed source-capability coverage differences.',
                'A positive oracle-minus-single gap alone does not establish mutual child complementarity.',
                'Different family-wise best-child slots are not a deployable family-aware oracle.',
                'No fitted router, network emergence, long-term retention, or new research-gate pass is inferred.'
            ],
        },
        'script_sha256': sha(Path(__file__)),
        'frozen_capability_source_sha256': sha(SOURCE / 'population_audit_generation.py'),
        'trials': reports,
    }
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'path': str(args.output), 'sha256': sha(args.output), 'seeds': args.seeds,
                      'retention': {str(v['seed']): v['groups']['retention'] for v in reports}},
                     sort_keys=True))


if __name__ == '__main__':
    main()
