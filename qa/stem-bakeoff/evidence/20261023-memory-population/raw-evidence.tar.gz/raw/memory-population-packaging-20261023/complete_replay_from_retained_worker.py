"""Complete import/router checks from the one retained successful model worker.

No model worker, training, or language-model inference is started by this script.
The original archive, extracted bundle, failed receipts and worker evidence stay unchanged.
"""

import argparse
import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import runpy
import sys
import time

sys.dont_write_bytecode = True
THIS_FILE = Path(__file__).resolve()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def actual_worker_origins(trace_path, expected, forbidden):
    text = trace_path.read_text()
    names = set(re.findall(r"^import '([^']+)' #", text, flags=re.MULTILINE)) & set(expected)
    paths = set()
    for line in text.splitlines():
        if line.startswith("# code object from "):
            raw = line.removeprefix("# code object from ").strip()
            parsed = ast.literal_eval(raw) if raw.startswith(("'", '"')) else raw
            if isinstance(parsed, str) and parsed.endswith(".py"):
                paths.add(Path(parsed).resolve())
    require(str(forbidden) not in text, "original source repository occurs in worker import trace")
    require({"parametric_model", "pretrained", "tensor_contract", "native"} <= names,
            "expected actual worker imports absent")
    rows = []
    for name in sorted(names):
        pin = expected[name]
        require(pin["path"] in paths and sha(pin["path"]) == pin["sha256"],
                "actual worker compilation was not from bundled pinned source: " + name)
        rows.append({"module": name, "compiled_from": str(pin["path"]),
                     "sha256": pin["sha256"], "pinned_bundle_source": True})
    for path in paths:
        if path.stem in names and any(part.startswith("memory_cell") for part in path.parts):
            require(path == expected[path.stem]["path"], "alternate research source in trace")
    return {"trace_path": str(trace_path), "trace_sha256": sha(trace_path), "research_modules": rows}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("bundle", "output-root", "attempt", "archive", "runtime", "python", "forbidden-repo"):
        p.add_argument("--" + name, type=Path, required=True)
    args = p.parse_args()
    for name in ("bundle", "output_root", "attempt", "archive", "runtime", "forbidden_repo"):
        setattr(args, name, getattr(args, name).resolve())
    require(os.environ.get("PYTHONPATH", "").split(os.pathsep) == [str(args.runtime)], "runtime-only initial PYTHONPATH")
    require(Path(sys.executable).absolute() == args.python.absolute(), "direct declared venv interpreter required")
    require(not any(Path(x or ".").resolve().is_relative_to(args.forbidden_repo) for x in sys.path), "original repository fallback")
    completion = args.output_root / "completion"
    require(not completion.exists(), "new completion directory required")
    require(not (args.output_root / "isolated-replay-receipt.json").exists(), "existing completed receipt")
    sys.path.insert(0, str(args.bundle / "tools"))
    from archive_integrity import load_json, verify_directory
    helper = runpy.run_path(str(args.bundle / "tools/restore_population.py"), run_name="restore_helpers_without_main")
    wrapper = runpy.run_path(str(args.bundle / "tools/run_isolated_replay.py"), run_name="original_helpers_without_main")
    manifest = verify_directory(args.bundle)
    expected = wrapper["expected_modules"](args.bundle, manifest)
    require(not (set(expected) & set(sys.modules)), "research modules must not be preloaded")
    plan = load_json(args.attempt / "launch-plan.json")
    replay = load_json(args.attempt / "replay/replay-result.json")
    journal_path = args.attempt / "replay/relocated-reader-journal.json"
    journal = load_json(journal_path)
    trace_path = args.attempt / "replay/relocated-reader-stderr.log"
    require(plan["seed"] == 1907 and plan["variant"] == "single" and plan["reference_row_index"] == 0,
            "predeclared replay identity differs")
    require(sha(args.archive) == plan["archive_sha256"] and sha(args.bundle / "ARCHIVE-MANIFEST.json") == plan["archive_manifest_sha256"],
            "original archive/member-manifest pins differ")
    catalog = load_json(args.bundle / "metadata/checkpoint-catalog.json")
    audit = load_json(args.bundle / "metadata/independent-audit.json")
    require(audit["passed"] is True and sha(args.bundle / "metadata/independent-audit.json") == plan["independent_audit_sha256"], "cohort audit pin")
    require(sha(args.bundle / "evidence/aggregate.json") == plan["aggregate_sha256"], "aggregate pin")
    for seed, pin in plan["seed_result_sha256"].items():
        require(sha(args.bundle / f"evidence/seed-{seed}/result.json") == pin, "trial result pin")
    version = next(v for v in catalog["checkpoints"] if v["key"] == "1907/single")
    require(version["manifest_sha256"] == plan["checkpoint_manifest_sha256"] == journal["active_version"]["manifest_sha256"], "checkpoint pin")
    require(Path(journal["active_version"]["directory"]).resolve() == args.bundle / version["archive_directory"], "actual relocated checkpoint path")
    request = load_json(args.attempt / "replay/relocated-reader-request.json")
    require(Path(request["model"]) == Path(plan["new_base_directory"]) and request["questions"] == [plan["question"]], "actual new base/question")
    require(journal["binding"]["context"]["archive_manifest_sha256"] == plan["archive_manifest_sha256"], "worker original bundle binding")
    worker_journals = sorted(args.output_root.rglob("relocated-reader-journal.json"))
    worker_requests = sorted(args.output_root.rglob("relocated-reader-request.json"))
    require(worker_journals == [journal_path] and len(worker_requests) == 1, "exactly one recorded fresh worker")
    require(replay["work"]["additional_fresh_worker_processes"] == 1 and replay["work"]["actual_queries"] == 1
            and journal["owner_admitted_before_and_after"] is True, "single owner-admitted query")
    comparison = helper["reference_generation"](args.bundle, 1907, "single", plan["question"], journal)
    require(comparison == replay["reference_comparison"] and comparison["all_fields_match"] is True, "original raw/token/state comparison")
    original_journal = load_json(args.bundle / comparison["original_journal_archive_path"])
    require(original_journal["rows"][0]["evidence"] == journal["rows"][0]["evidence"] == [],
            "raw generated evidence field differs")
    before = {str(path): sha(path) for path in args.output_root.rglob("*") if path.is_file()}
    started = time.perf_counter()
    trace = actual_worker_origins(trace_path, expected, args.forbidden_repo)
    completion.mkdir()
    postprocessor_initial = wrapper["environment"]()
    helper["setup_sources"](args.bundle)
    # Imports only: these modules do not construct or run a language model here.
    import parametric_owner
    import population_worker
    import_origins = wrapper["loaded_origins"](expected, ("parametric_owner", "population_worker", "tensor_contract"))
    capture = io.StringIO()
    old_argv = sys.argv
    try:
        sys.argv = [str(args.bundle / "tools/restore_population.py"), "router", "--bundle", str(args.bundle),
                    "--seed", "1907", "--question", plan["question"]]
        with contextlib.redirect_stdout(capture):
            runpy.run_path(sys.argv[0], run_name="__main__")
    finally:
        sys.argv = old_argv
    raw = capture.getvalue()
    router = json.loads(raw)
    (completion / "router-helper-stdout.json").write_text(raw)
    require(router["reference_available"] is True and router["matches_original_frozen_route"] is True, "same-question router mismatch")
    all_origins = wrapper["loaded_origins"](expected, ("learned_router", "router_features"))
    base = load_json(args.attempt / "base-hardlink-receipt.json")
    for row in base["files"]:
        source, target = Path(row["source"]), Path(row["new_path"])
        require(sha(source) == row["sha256"] == sha(target)
                and source.stat().st_ino == target.stat().st_ino == row["inode"]
                and source.stat().st_dev == target.stat().st_dev == row["device"], "base bytes/hardlink identity")
    verify_directory(args.bundle)
    require(sha(args.archive) == plan["archive_sha256"], "archive changed")
    require(all(sha(Path(path)) == pin for path, pin in before.items()), "prior replay evidence modified")
    require(len(list(args.output_root.rglob("relocated-reader-journal.json"))) == 1, "completion started another model worker")
    effective = wrapper["environment"]()
    require(not any(Path(x or ".").resolve().is_relative_to(args.forbidden_repo) for x in sys.path), "postprocessor source fallback")
    bindings = {name: plan[name] for name in ("source_head", "archive_sha256", "archive_manifest_sha256",
        "independent_audit_sha256", "aggregate_sha256", "seed_result_sha256", "seed", "variant",
        "checkpoint_manifest_sha256", "router_sha256", "original_route_plan_sha256")}
    failures = [{"path": str(path), "sha256": sha(path), "contents": load_json(path)}
                for path in sorted(args.output_root.rglob("failure.json"))]
    receipt = {
        "schema": "hepta.population.isolated-relocated-replay.v1", "passed": True, **bindings,
        "initial_environment": plan["initial_environment"], "effective_environment": effective,
        "postprocessor_initial_environment": postprocessor_initial,
        "parent_module_origins_before_router": import_origins,
        "parent_module_origins_after_router": all_origins,
        "parent_module_origins_phase": "completion process; original launcher check passed before trace parsing exception but its returned rows were not persisted",
        "worker_import_trace": trace, "all_observed_research_modules_from_pinned_bundle": True,
        "initial_pythonpath_runtime_only": True, "original_repository_import_fallback_used": False,
        "replay_result_sha256": sha(args.attempt / "replay/replay-result.json"),
        "replay_result_path": str(args.attempt / "replay/replay-result.json"),
        "reference_comparison": comparison, "router_replay": router, "work": replay["work"],
        "additional_raw_evidence_field_equal": True, "total_non_timing_reference_fields_checked": 15,
        "completion_elapsed_seconds": time.perf_counter() - started,
        "new_model_worker_processes_started_by_completion": 0, "router_inferences_in_completion": 1,
        "base_retrieval": "six hardlinks under a new /tmp path; no download and no additional base payload allocation",
        "shared_base_bytes_and_hardlink_identity_unchanged": True,
        "original_experiment_modified": False, "archive_and_bundle_unchanged": True,
        "prior_replay_evidence_unchanged": True, "answer_correctness_required": False,
        "general_portability_across_platforms_proven": False,
        "auxiliary_failures_preserved": failures,
        "completion_reason": "original optional wrapper failed to parse CPython's unquoted import path after successful model read; corrected parser used only retained stderr, then one router replay",
        "original_wrapper_unchanged": True, "completion_script_sha256": sha(THIS_FILE),
        "all_prior_replay_file_pins": before,
    }
    pending = args.output_root / "isolated-replay-receipt.json.pending"
    write(pending, receipt)
    os.link(pending, args.output_root / "isolated-replay-receipt.json")
    pending.unlink()
    print(json.dumps({"passed": True, "receipt": str(args.output_root / "isolated-replay-receipt.json"),
                      "work": replay["work"], "router_matches": True, "actual_worker_modules": len(trace["research_modules"])}))


if __name__ == "__main__":
    main()
