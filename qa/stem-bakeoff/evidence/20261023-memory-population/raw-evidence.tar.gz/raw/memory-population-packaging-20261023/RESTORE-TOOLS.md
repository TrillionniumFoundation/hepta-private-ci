# Hepta memory：恢复工具补充包与已知问题

本补充包与以下 checkpoint ZIP 配套：

- 文件：`hepta-memory-population-checkpoints-20261023.zip`
- SHA-256：`30237f8fb96bd70d56404532b075eb76e2fb50c2494d72276dfa3e8d1ac783b2`
- 冻结实验 commit：`07df4a9cc385375cddded5b5e3b99632ce0652ec`

**原 checkpoint ZIP 保持原字节。** 三组实验和实际异路径模型读取绑定的是这个哈希；没有为修复事后日志解析器而重跑模型或改写原始 receipts。

## 应使用哪个入口

| 入口 | 状态与用途 |
|---|---|
| checkpoint ZIP 中 `tools/restore_population.py plan` | 可用；只展示 pin 与新的运行定位，不加载模型。 |
| checkpoint ZIP 中 `tools/restore_population.py replay` | 可用；本次异路径实际读取已通过此入口完成，建立新的 owner，输出新的 raw journal 和参考比较。 |
| checkpoint ZIP 中 `tools/restore_population.py router` | 可用；本次同问 serialized-router 重放已实际执行且与原冻结 decision 一致。 |
| checkpoint ZIP 中 `tools/run_isolated_replay.py` | **原始审计快照，有已知事后日志解析缺陷，不应作为默认可用入口。** 原版保留用于审计。 |
| 本补充包 `run_isolated_replay_fixed.py` | 可选的修正包装器，用于需要额外环境与实际导入路径证据的恢复核验。 |
| 本补充包 `complete_replay_from_retained_worker.py` | 从已经成功的唯一 worker 日志完成导入来源校验和同问 router 重放；不会创建模型 worker、训练模型或执行语言模型推理。 |

一般读取请按原 ZIP 的 `RESTORE.md` 使用 `restore_population.py`。其恢复定位、严格 base 校验、owner admission、原始生成和 token/state 比较不受这个可选包装器问题影响。

## 已发生的问题与处理

第一次准备新 base 时，文件系统返回源目录与目标目录相同的 `st_dev`，但实际跨 `/tmp` 到 workspace 的硬链接系统调用返回 `EXDEV`。这一步尚未启动模型。失败记录保留，没有把相同设备号当作硬链接成功的证据。

随后在新的 `/tmp/hepta-population-relocated-base-20261023` 路径建立了六个真实硬链接，逐文件 device/inode、大小、SHA-256 与原 base 一致。没有复制或重新下载 271,170,520 bytes 的 base payload。实际新路径、新 owner 和新 raw journal 均有记录。

唯一 fresh model worker 成功返回后，可选包装器解析 `PYTHONVERBOSE=1` 的 stderr 时退出：它假定 `# code object from ...` 后的路径是带引号的 Python 字符串；本次 CPython 实际输出裸路径。修正仅使解析器同时接受裸路径与带引号的路径，其他行不变。修正函数直接核验了已保留的真实 stderr 中 11 个研究模块的来源与哈希，没有再调用语言模型。

外部后处理随后完成同问 router 的一次实际重放。它保留初次 hardlink 失败、包装器解析失败、成功 worker 的全部原始字节，并生成新的完成 receipt。

## 本次实际恢复证据

固定问题来自 seed 1907 / single 原 final journal 的第一行，没有按模型正确性选题：

> According to the retained record, state the color associated with person N00.

原始生成与异路径生成同为 `yellow`。原 helper 的 14 项非耗时比较全部一致；独立检查又核对了 `evidence=[]`，合计 15 项字段一致。比较覆盖原始 text、generated token IDs、prompt IDs/hash、base 身份以及实际、admitted、consumed 和 effective adapter state。

| 新增工作 | 实测值 |
|---|---:|
| fresh model worker | 1 |
| 实际模型问题 | 1 |
| 输入 token | 65 |
| 生成 token | 2 |
| generation seconds | 0.2416616679984145 |
| fresh-process wall seconds | 8.135626144001435 |
| 新 owner DB | 20,480 bytes |
| 后处理新增语言模型 worker | 0 |
| 后处理 router inference | 1 |

这些额外成本不计入原三 seed 研究。后处理执行时间另记约 2.94 秒；导入日志和校验 I/O 也属于恢复诊断开销。以上 worker 数来自这次调用、请求、journal、stderr 启动记录与工作收据的一致性核验，不是操作系统级的所有进程证明。

模型 worker 的实际导入日志包含 11 个研究模块，全部来自解压 bundle 的 `source/`，SHA-256 与冻结 source identity 一致；原仓库源路径在该日志中出现 0 次。模型启动的初始 `PYTHONPATH` 仅为第三方 runtime，解释器是直接的 venv Python。原包装器在失败前已经完成父进程模块来源检查，但其返回行尚未持久化；完成 receipt 如实区分这点与后处理进程重新记录的实际模块来源，不把后处理进程冒充原模型进程。

实际同问 router decision 与原 `route-plan.json` 完全一致。原 ZIP、全部解压成员、原实验、成功模型日志和两次辅助失败记录均未修改。这证明相同字节在本环境的新路径可被新 owner 加载并实际读取，不证明跨机器/CPU 架构的逐 token 一致性，也不证明回答正确或通用 memory 已成立。

## 使用修正的可选包装器

先完成原 ZIP 的校验和解压，并准备精确 pinned base、相同依赖与直接 venv 解释器。将所有占位路径替换为真实绝对路径；输出目录和新的 base 目录必须尚不存在。初始 `PYTHONPATH` 只允许一个明确的第三方 runtime 目录；如果依赖已直接安装在 venv 中，可使用一个新的空目录作为该白名单项。

```bash
env PYTHONPATH=/absolute/dependency-runtime \
  /absolute/venv/bin/python -B restore-tools/run_isolated_replay_fixed.py \
  --bundle /absolute/population-bundle \
  --archive /absolute/hepta-memory-population-checkpoints-20261023.zip \
  --archive-sha256 30237f8fb96bd70d56404532b075eb76e2fb50c2494d72276dfa3e8d1ac783b2 \
  --base-source /absolute/existing-pinned-base \
  --base-relocated /absolute/new-base-on-same-filesystem \
  --output /absolute/new-replay-output \
  --runtime /absolute/dependency-runtime \
  --python /absolute/venv/bin/python \
  --forbidden-repo /absolute/original-source-repository
```

包装器固定使用 seed 1907 / single 的原第一问。它不会为 hardlink 失败自动复制大模型；实际 link 能力仍由系统调用决定。如果无需额外硬链接来源核验，直接使用原 `restore_population.py replay` 并显式传入已经获取和校验的 base 路径。

修正函数已用本次真实 stderr 验证；为了遵守一次模型读取的固定预算，没有重新执行整个修正包装器的模型路径。`parser-fix-validation.json` 记录原版、修正版、实际输入日志和 11 个模块的哈希。普通 `restore_population.py replay` 的实际成功证据另有保留。

## 补充包内容与校验

- `MANIFEST.json`：本补充包每个文件的 SHA-256 和大小。
- `ORIGINAL-CHECKPOINT.json`：原 ZIP、独立 cohort audit、最终恢复 receipt 的绑定。
- `original/run_isolated_replay.py`：原版辅助包装器的原字节。
- `run_isolated_replay_fixed.py`：只修正日志路径解析的版本。
- `complete_replay_from_retained_worker.py`：本次实际使用的无模型后处理脚本。
- `verification/`：解析器修复验证、最终恢复 receipt 和独立只读复核。

完整 raw worker stderr、request、binding、journal、owner DB 和两次辅助失败在配套 raw-evidence 包中；它们没有被成功 receipt 覆盖。修正与后处理均为实验结束后的辅助工具，不属于已冻结的模型训练、source selection 或研究 gate。
