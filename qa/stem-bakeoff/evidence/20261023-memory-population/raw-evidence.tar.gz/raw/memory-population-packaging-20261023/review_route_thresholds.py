"""Answer-free post-hoc separability bounds from frozen route-plan probabilities."""

import argparse
import ast
import hashlib
import json
import math
from pathlib import Path


HEAD = "07df4a9cc385375cddded5b5e3b99632ce0652ec"
RETENTION = {"semantic", "episode", "procedure"}


def file_pin(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def frozen_config(repo):
    source = repo / "scripts/memory_cell_router/router_features.py"
    module = ast.parse(source.read_bytes())
    config = next(ast.literal_eval(node.value) for node in module.body if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == "DEFAULT_CONFIG" for target in node.targets))
    assert config["min_confidence"] == 0.55 and config["min_margin"] == 0.05
    return config


def read_plan(study, seed, config):
    path = study / f"seed-{seed}/final/route-plan.json"
    before = file_pin(path)
    plan = json.loads(path.read_bytes())
    assert plan["schema"] == "hepta.population.frozen-route-plan.v1"
    assert plan["probe_gold_included"] is False and len(plan["rows"]) == 120
    rows = []
    for row in plan["rows"]:
        assert not any(key in row for key in ("value", "gold", "answer", "text"))
        learned = row["learned"]
        p = learned["probabilities"]
        assert len(p) == 3 and all(type(v) in (int, float) and math.isfinite(v) and 0 <= v <= 1 for v in p)
        assert math.isclose(sum(p), 1.0, abs_tol=1e-12)
        top = max(range(2), key=lambda slot: (p[slot], -slot))
        support, margin = sum(p[:2]), p[top] - p[2]
        assert math.isclose(support, learned["support_confidence"], abs_tol=1e-12)
        assert math.isclose(margin, learned["margin"], abs_tol=1e-12)
        reason = ("learned_reject" if p[2] >= p[top] else
                  "low_support_confidence" if support < config["min_confidence"] else
                  "low_support_margin" if margin < config["min_margin"] else "routed")
        assert learned["reason"] == reason
        assert learned["slot"] == (top if reason == "routed" else None)
        eligible = [i for i, value in enumerate(row["split_eligibility"]) if value["capability_allowed"]]
        assert eligible == row["eligible_split_slots"]
        rows.append({"seed": seed, "probe_id": row["probe_id"], "family": row["family"],
                     "support_confidence": support, "best_expert_minus_reject": margin,
                     "probabilities": p, "expert_argmax": top, "eligible_split_slots": eligible,
                     "argmax_source_capability_eligible": top in eligible,
                     "dominance_admissible": margin > 0,
                     "original_slot": learned["slot"], "original_reason": reason})
    assert sum(r["family"] in RETENTION for r in rows) == 64
    assert sum(r["family"] == "unknown" for r in rows) == 24
    assert file_pin(path) == before
    return rows, {"path": str(path), **before, "inputs_unchanged": True,
                  "selection_sha256": plan["selection_sha256"], "router_sha256": plan["router_sha256"]}


def observed_summary(rows):
    retained = [r for r in rows if r["family"] in RETENTION]
    unknown = [r for r in rows if r["family"] == "unknown"]
    covered = sum(r["original_slot"] is not None and r["argmax_source_capability_eligible"] for r in retained)
    rejected = sum(r["original_slot"] is None for r in unknown)
    dominant = sum(r["dominance_admissible"] and r["argmax_source_capability_eligible"] for r in retained)
    return {
        "retention_count": 64, "unknown_count": 24,
        "supported_retention_target_count": 48, "raw_ood_reject_target_count": 22,
        "original_supported_retention_count": covered, "original_supported_retention_coverage": covered / 64,
        "original_raw_ood_reject_count": rejected, "original_raw_ood_reject_rate": rejected / 24,
        "argmax_supported_retention_without_rejection_upper_count": sum(r["argmax_source_capability_eligible"] for r in retained),
        "dominance_preserved_supported_retention_upper_count": dominant,
        "dominance_preserved_supported_retention_upper_coverage": dominant / 64,
        "dominance_preserved_unknown_accept_count_at_maximal_acceptance": sum(r["dominance_admissible"] for r in unknown),
        "mere_lowering_cannot_increase_raw_ood_rejection": True,
        "mere_lowering_both_targets_impossible_by_monotonicity": rejected < 22,
        "mere_lowering_coverage_target_impossible_by_dominance": dominant < 48,
        "by_retention_family": {
            family: {"count": sum(r["family"] == family for r in retained),
                     "argmax_eligible": sum(r["family"] == family and r["argmax_source_capability_eligible"] for r in retained),
                     "dominance_admissible_eligible": sum(r["family"] == family and r["dominance_admissible"]
                                                        and r["argmax_source_capability_eligible"] for r in retained)}
            for family in sorted(RETENTION)},
    }


def coordinate_domination_certificate(rows):
    retained = [r for r in rows if r["family"] in RETENTION and r["argmax_source_capability_eligible"]]
    unknown = [r for r in rows if r["family"] == "unknown"]
    witnesses = []
    for row in retained:
        dominating = [u["probe_id"] for u in unknown
                      if u["support_confidence"] >= row["support_confidence"]
                      and u["best_expert_minus_reject"] >= row["best_expert_minus_reject"]]
        witnesses.append({"retention_probe_id": row["probe_id"],
                          "ood_points_coordinatewise_greater_or_equal": dominating,
                          "count": len(dominating)})
    minimum = min((r["count"] for r in witnesses), default=24)
    return {
        "proof": "An inclusive upper-right threshold rectangle accepting a retention point must accept every OOD point whose two scores are both at least as large.",
        "argmax_eligible_retention_points": len(retained),
        "minimum_ood_dominators_of_any_eligible_retention_point": minimum,
        "maximum_raw_ood_reject_rate_if_any_eligible_retention_point_accepted_upper_bound": (24 - minimum) / 24,
        "zero_supported_coverage_at_90_percent_raw_ood_reject_proved": minimum > 2,
        "per_retention_witnesses": witnesses,
        "no_answer_values_used": True,
    }


def rectangle_bounds(rows, seeds, config, mode):
    # Every distinct >= threshold acceptance set has a representative at an observed
    # score or a domain endpoint. Exact finite enumeration does not fit or deploy a rule.
    if mode == "mere_lowering_existing_thresholds":
        c_low, c_high = math.nextafter(0.5, 1.0), config["min_confidence"]
        m_low, m_high, preserve = 0.0, config["min_margin"], True
    elif mode == "all_valid_thresholds_preserving_dominance":
        c_low, c_high, m_low, m_high, preserve = math.nextafter(0.5, 1.0), 1.0, 0.0, 1.0, True
    else:
        assert mode == "relaxed_rectangle_without_dominance"
        c_low, c_high, m_low, m_high, preserve = 0.0, 1.0, -1.0, 1.0, False
    relevant = [r for r in rows if r["family"] in RETENTION or r["family"] == "unknown"]
    cuts_c = sorted({c_low, c_high} | {r["support_confidence"] for r in relevant if c_low <= r["support_confidence"] <= c_high})
    cuts_m = sorted({m_low, m_high} | {r["best_expert_minus_reject"] for r in relevant if m_low <= r["best_expert_minus_reject"] <= m_high})

    def mask(predicate):
        return sum(1 << i for i, row in enumerate(relevant) if predicate(row))

    dominance = mask(lambda r: not preserve or r["dominance_admissible"])
    c_masks = {c: mask(lambda r: r["support_confidence"] >= c) for c in cuts_c}
    m_masks = {m: mask(lambda r: r["best_expert_minus_reject"] >= m) for m in cuts_m}
    support_masks = {s: mask(lambda r: r["seed"] == s and r["family"] in RETENTION
                            and r["argmax_source_capability_eligible"]) for s in seeds}
    unknown_masks = {s: mask(lambda r: r["seed"] == s and r["family"] == "unknown") for s in seeds}
    best_by_ood_count = {s: [None] * 25 for s in seeds}
    best_reject_at_target = {s: None for s in seeds}
    joint_best, joint_possible, examined = None, False, 0
    for c in cuts_c:
        for m in cuts_m:
            admitted = dominance & c_masks[c] & m_masks[m]
            metrics = {s: ((admitted & support_masks[s]).bit_count(),
                           (admitted & unknown_masks[s]).bit_count()) for s in seeds}
            examined += 1
            for seed, (covered, unknown_accepted) in metrics.items():
                witness = {"min_support_confidence": c, "min_best_expert_minus_reject": m,
                           "supported_retention_count": covered, "supported_retention_coverage": covered / 64,
                           "raw_ood_accept_count": unknown_accepted, "raw_ood_reject_rate": (24 - unknown_accepted) / 24}
                old = best_by_ood_count[seed][unknown_accepted]
                if old is None or covered > old["supported_retention_count"]:
                    best_by_ood_count[seed][unknown_accepted] = witness
                old = best_reject_at_target[seed]
                if covered >= 48 and (old is None or unknown_accepted < old["raw_ood_accept_count"]):
                    best_reject_at_target[seed] = witness
            if all(unknown <= 2 for _, unknown in metrics.values()):
                minimum = min(covered for covered, _ in metrics.values())
                if joint_best is None or minimum > joint_best["minimum_supported_retention_count"]:
                    joint_best = {"min_support_confidence": c, "min_best_expert_minus_reject": m,
                                  "minimum_supported_retention_count": minimum,
                                  "per_seed_counts": {str(s): {"supported_retention": x[0], "raw_ood_accepted": x[1]}
                                                      for s, x in metrics.items()}}
                joint_possible |= minimum >= 48
    per_seed = {}
    for seed in seeds:
        frontier, best = [], None
        for allowed, candidate in enumerate(best_by_ood_count[seed]):
            if candidate is not None and (best is None or candidate["supported_retention_count"] > best["supported_retention_count"]):
                best = candidate
            frontier.append({"maximum_raw_ood_accepted": allowed,
                             "raw_ood_reject_floor": (24 - allowed) / 24,
                             "best_rectangle": best})
        constrained = frontier[2]["best_rectangle"]
        per_seed[str(seed)] = {
            "maximum_supported_coverage_with_raw_ood_reject_at_least_90_percent": constrained,
            "maximum_raw_ood_reject_with_supported_coverage_at_least_75_percent": best_reject_at_target[seed],
            "both_targets_exist_in_rectangle_family": constrained is not None and constrained["supported_retention_count"] >= 48,
            "complete_count_frontier": frontier,
        }
    return {"mode": mode, "dominant_reject_preserved": preserve,
            "confidence_domain": [c_low, c_high], "margin_domain": [m_low, m_high],
            "distinct_candidate_threshold_pairs_examined": examined,
            "finite_enumeration_method": "observed score cutpoints plus endpoints; inclusive >= rectangles",
            "per_seed": per_seed, "common_threshold_both_targets_exist_for_every_seed": joint_possible,
            "common_threshold_best_minimum_coverage_at_ood_constraint": joint_best,
            "not_a_new_strategy_or_registered_performance_result": True,
            "relaxed_family_changes_hard_reject_rule_and_config_domain": not preserve}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--seeds", nargs="+", type=int, choices=(1907, 2719, 4051), required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    seeds = sorted(args.seeds)
    assert len(seeds) == len(set(seeds)) and not args.output.exists()
    assert not args.output.resolve().is_relative_to(args.study.resolve())
    config = frozen_config(args.repo.resolve())
    rows, pins, summaries, certificates = [], {}, {}, {}
    for seed in seeds:
        these, pin = read_plan(args.study.resolve(), seed, config)
        rows.extend(these)
        pins[str(seed)] = pin
        summaries[str(seed)] = observed_summary(these)
        certificates[str(seed)] = coordinate_domination_certificate(these)
    modes = ("mere_lowering_existing_thresholds", "all_valid_thresholds_preserving_dominance",
             "relaxed_rectangle_without_dominance")
    report = {
        "schema": "hepta.population.frozen-score-threshold-separability.v1", "source_head": HEAD,
        "seeds": seeds, "input_plan_pins": pins, "config": config,
        "frozen_rule": "route fixed stable expert argmax iff reject_probability < best_expert_probability, support_confidence >= min_confidence, and best_expert_minus_reject >= min_margin",
        "coverage_basis": "64 retained queries; accepted fixed argmax must be in supplied eligible_split_slots; answer correctness is never examined",
        "ood_basis": "24 registered unknown queries; raw route rejection, independent of capability guard",
        "observed": summaries, "rectangles": [rectangle_bounds(rows, seeds, config, mode) for mode in modes],
        "coordinate_domination_certificates": certificates,
        "analysis_helper_sha256": file_pin(Path(__file__).resolve())["sha256"],
        "frozen_implementation_pins": {
            name: file_pin(args.repo.resolve() / "scripts" / name)
            for name in ("memory_cell_router/learned_router.py", "memory_cell_router/router_features.py",
                         "memory_cell_population/population_selection.py")},
        "score_projection": rows, "answer_values_or_generation_outputs_read": False,
        "model_loaded_or_fitted": False, "frozen_sources_or_results_modified": False,
        "posthoc_final_plan_labelled_diagnostic_only": True,
        "thresholds_applied_to_original_results": False,
        "claims": "finite score geometry only; no causal diagnosis, calibrated open-set guarantee, or deployable threshold selection",
    }
    for pin in pins.values():
        assert file_pin(Path(pin["path"])) == {key: pin[key] for key in ("bytes", "sha256")}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"output": str(args.output.resolve()), "sha256": file_pin(args.output)["sha256"],
                      "observed": summaries, "rectangle_results": [
                          {"mode": row["mode"], "per_seed": {s: {k: v for k, v in value.items() if k != "complete_count_frontier"}
                                                            for s, value in row["per_seed"].items()},
                           "common_threshold_both_targets_exist_for_every_seed": row["common_threshold_both_targets_exist_for_every_seed"]}
                          for row in report["rectangles"]]}, sort_keys=True))


if __name__ == "__main__":
    main()
