# Hepta memory population：下载包校验与恢复

这个包保存三组实验的实际 adapter 权重、学习路由器、量化 payload、派生 lineage、owner 数据库和完整原始报告。共享基础模型另行按固定 revision 和逐文件哈希获取。

实验源代码固定于：

`07df4a9cc385375cddded5b5e3b99632ce0652ec`

源仓库：<https://github.com/TrillionniumFoundation/hepta-private-ci>

包内 `source/` 包含实验 `source-identity.json` 列出的全部 72 个 Python 文件，以及发布证明覆盖的机制测试入口、CI workflow 和三个模块 README。导出使用本地 frozen 字节；每个 Python 文件同时匹配实验 SHA-256 和已保留的远端 Git tree / Git blob SHA-1 证明，其他附带源文件匹配同一 commit 的发布证明。整个打包过程无需 Git object fetch。

`metadata/git-source-manifest.json` 记录 commit、Git tree、全部导出文件的 SHA-256 / Git blob SHA-1 和证明覆盖范围；`metadata/runtime-source-binding.json` 与 `metadata/published-source-verification.json` 保留原始证明字节。实际依赖版本生成于 `metadata/runtime-requirements.txt` 和 `metadata/runtime-torch-requirement.txt`。`tools/` 是实验结束后附加的打包/恢复工具，未参与生成原实验结果。

这是足够读取和审计本实验的源代码子集，不是完整 Git 仓库。若需完整仓库、其他文档或仓库级许可文件，请在有相应仓库访问权限的环境中获取上述精确 commit；本包不宣称包含当前 checkout 中不存在的许可证文件。

## 1. 先验证下载字节，再解压

发布时同时提供 ZIP 的 SHA-256 和独立 `.zip.receipt.json`。先用可信发布记录中的 SHA-256 校验下载文件。包内 manifest 可以检测成员是否一致；独立发布的 ZIP 哈希才把下载内容绑定到本次发布。

```bash
sha256sum hepta-memory-population-checkpoints-20261023.zip
```

确认与发布记录一致后，解压到新的空目录。保持全部相对路径。

```bash
mkdir population-bundle
python -m zipfile -e hepta-memory-population-checkpoints-20261023.zip population-bundle
python -B population-bundle/tools/archive_population.py verify-directory \
  --bundle population-bundle
```

逐成员 ZIP 校验也可以在解压后运行。将 `PUBLISHED_SHA256` 换成独立发布的完整十六进制哈希。

```bash
python -B population-bundle/tools/archive_population.py verify \
  --archive hepta-memory-population-checkpoints-20261023.zip \
  --expected-sha256 PUBLISHED_SHA256
```

这些校验只需要 Python 标准库，不加载模型、不读取网络、不运行 unit tests。

## 2. 包内完整内容

| 目录/文件 | 用途 |
|---|---|
| `evidence/seed-1907/`、`seed-2719/`、`seed-4051/` | 三个 seed 的所有原始文件，逐字节保留 |
| 每个 seed 的 `training/` | rank-4 parent、rank-8 expanded-parent、rank-8 single、两个 rank-4 split，共五个原始/扩展 checkpoint |
| 每个 seed 的 `codec/int8-packed/`、`int4-packed/` | 实际量化字节、codec manifest、原始 lineage 与 config |
| 每个 seed 的 `codec/int8-materialized/`、`int4-materialized/` | 可直接被现有 reader 使用的 float32 派生 checkpoint，包含原始 lineage 和 codec receipt |
| 每个 seed 的 `selection/learned-router.bin` | 实际拟合得到的 router 参数、特征配方、训练 provenance 和决策规则 |
| 每个 seed 的 `final/owners.sqlite3`、`codec/owners.sqlite3` | 原始本地 owner 状态的证据快照 |
| `evidence/` 中全部其他文件 | source ledger、训练 exposure/gradient receipts、路由冻结计划、raw stdout/stderr、请求、admission bindings、逐 probe 评分、成本和正负结论 |
| `metadata/independent-audit.json` | 对原始完整三 seed 结果的独立一致性审计及结果哈希 |
| `metadata/checkpoint-catalog.json` | 全部 21 个 float32 checkpoint、6 个 packed payload、3 个 router、6 个 owner DB 的定位与 pin |
| `metadata/absolute-path-map.json` | 原绝对路径到包内相对路径或外部依赖的说明 |
| `ARCHIVE-MANIFEST.json` | 除自身外，包内每个文件的 SHA-256 和字节数 |

保留了所有候选和负结果。下载包并不以 source selection 选中的候选替换其他实验臂。

量化包是有损存储派生。现有推理入口使用已 materialize 的 float32 adapter；提供 int8/int4 文件不等于使用 int8/int4 运算，也不构成整个 memory system 的净压缩优势证明。

## 3. 准备与原实验相同的依赖

查看 `metadata/runtime-versions.json` 获取原始 Python、平台和八个实际依赖版本。`metadata/runtime-requirements.txt` 固定除 PyTorch 外的版本；`metadata/runtime-torch-requirement.txt` 固定原实验的完整 PyTorch 版本字符串，其 CPU wheel 单独安装。

以下示例适用于与原实验相容的 Linux CPU 环境。先选择与记录相同的 Python 版本。

```bash
python3 -m venv population-replay-venv
. population-replay-venv/bin/activate
python -m pip install --only-binary=:all: \
  --index-url https://download.pytorch.org/whl/cpu \
  -r population-bundle/metadata/runtime-torch-requirement.txt
python -m pip install --only-binary=:all: \
  -r population-bundle/metadata/runtime-requirements.txt
python -m pip check
```

工具不包含第三方 wheel 或虚拟环境。实际恢复需要这些运行时依赖和共享基础模型。跨操作系统/CPU 架构的浮点输出是否逐 token 一致，应以新 replay journal 与原 journal 的比较为准；文件哈希一致不自动证明数值输出一致。

## 4. 单独获取并验证共享基础模型

固定模型：`HuggingFaceTB/SmolLM2-135M-Instruct`

固定 revision：`12fd25f77366fa6b3b4b768ec3050bf629380bac`

仓库快照：<https://huggingface.co/HuggingFaceTB/SmolLM2-135M-Instruct/tree/12fd25f77366fa6b3b4b768ec3050bf629380bac>

`model.safetensors` 为 269,060,552 bytes；加上配置和 tokenizer，六个必要发布文件总计 271,170,520 bytes。完整逐文件 SHA-256 位于 `metadata/shared-base.json`。ZIP 不包含这些共享文件，恢复时也应把它们放在 bundle 之外。

```bash
python -B population-bundle/source/scripts/memory_cell/prepare_parametric.py \
  --output ./shared-smollm2-135m --download
```

这条命令显式访问公开模型仓库，按固定 revision 获取六个允许文件，并检查发布者内容 pin。已经具备这些文件时，去掉 `--download` 只进行校验。

不要在模型目录混入其它文件；base 身份来自完整文件 inventory。Hugging Face 的 `.cache/` 元数据按原 reader 的规则排除。获取脚本会把 acquisition receipt 写在模型目录旁边。

## 5. 绝对路径的处理原则

原始报告、请求、owner DB 和 adapter config 中可能包含原机器上的绝对路径。这些字符串属于原始证据，已经参与 SHA-256 和 binding 计算，因此全部原样保留。

恢复时采用两层数据：

1. **原始证据层**：不重写 JSON，不修改 SQLite，不改 adapter config，不覆盖任何原 receipt。
2. **新运行层**：从 catalog 复制一个内存中的 version descriptor，只把其 `directory` 指向解压后的真实 checkpoint；显式传入新的 base directory；建立新的 owner DB 并写入全新的 replay receipts。

`tensor_contract.canonical_config` 在兼容性比较时忽略本地 `base_model_name_or_path`，但仍验证原 config 的完整字节哈希，并以完整 base inventory 验证模型身份。因此无需把 config 中的 `/tmp/hepta-parametric-smol135m` 改成新路径。

原 owner DB 内的绝对 checkpoint locator 仍然指向原环境。不要直接把该 DB 当作迁移后已生效的 owner；它用于历史审计。新 owner 的本地 synthetic-fixture frontier 也不代表恢复了外部系统的实时授权或撤回状态。

## 6. 先查看恢复计划，再执行独立 replay

查看 single checkpoint 的 pin 和迁移定位，无需基础模型或深度学习依赖：

```bash
python -B population-bundle/tools/restore_population.py plan \
  --bundle population-bundle --seed 1907 --variant single
```

可用 variant：`parent`、`expanded-parent`、`single`、`split-0`、`split-1`、`int8`、`int4`。后两项使用保留的 float32 materialization。

在新目录进行一次真实 owner-admitted fresh-process read：

```bash
python -B population-bundle/tools/restore_population.py replay \
  --bundle population-bundle --base ./shared-smollm2-135m \
  --seed 1907 --variant single \
  --question 'What is the color for person N00?' \
  --output ./replay-seed1907-single-001
```

新输出目录包含 relocation receipt、新 owner DB、新 request/binding/admission/raw journal，以及 `replay-result.json`。后者单列新增 worker、输入/输出 token、generation seconds、fresh process wall seconds 和 owner DB bytes，不把这些费用并入原实验。工具检查所有包内文件保持不变，使用 catalog 中的实际 rank/seed，并验证全部共享 base bytes。Worker 的输入仍只有 question 字符串、版本 pin 和必要运行参数；没有 probe gold、fact table 或 answer lexicon。

如果该问题唯一匹配所选 variant 的原 final journal，工具自动比较原始 text、generated token IDs、prompt IDs/hash 和实际有效权重状态；结果写入 `reference_comparison`。比较不使用答案正确性，也不要求耗时相同。请将示例问题替换为原 journal 中的实际 `question`，以进行精确同问比较。`expanded-parent` 没有对应的原 final worker journal，因此只支持实际读取，不提供此项原 final 比较。

这个 replay 是新的观测，不覆盖或冒充原实验结果。

## 7. 独立重放学习路由器

Router 不需要加载基础语言模型。安装记录中的 NumPy 版本后，可在同一包内运行：

```bash
python -B population-bundle/tools/restore_population.py router \
  --bundle population-bundle --seed 1907 \
  --question 'What is the color for person N00?'
```

该入口只向 router 提交 question；输出的 `decision` 包括 slot/reject、support confidence、reject probability 和 expert ambiguity。如果问题唯一匹配原 `route-plan.json`，还会给出 `matches_original_frozen_route`。它没有从 structured operation 或 gold 取路由标签。它只重放 router；不自动把路由结果当作来源授权。

## 8. 三种“验证”分别意味着什么

| 验证 | 新机器所需条件 | 能说明什么 |
|---|---|---|
| ZIP/解压目录逐文件 SHA-256 | Python 标准库和独立发布哈希 | 下载内容与发布包一致；原始字节没有变化 |
| relocated checkpoint/router replay | 记录中的依赖、独立获取的 exact base、新 output/owner | 相同权重和配置可在新路径被新 owner 加载并实际执行 |
| 原 frozen 全量 artifact audit 再执行 | 完整源代码、全部原证据、共享 base，并使原记录的绝对路径可读取 | 原始 raw evidence、成本、bindings 与结论仍能被原审计器逐项重构 |

Frozen audit 通过原绝对路径读取部分 checkpoint 和共享 base；简单移动目录后直接运行它会失败。若要重跑该原审计器，应在隔离环境中重建原目录命名空间，或使用另外明确标注的路径解析审计工具。不要为使原审计“通过”而改写 immutable receipts。包中保留了原环境完成的独立审计报告及其 result/aggregate pins。

恢复工具不会建立原绝对路径别名、覆盖已有路径、重新训练模型、运行 unit tests 或重新选择候选。完整通用 memory、真实外部 authority、分布式一致性和净系统压缩等结论仍以保留的实验边界和 gate 为准。

## 9. 本次另行执行的路径隔离核验

`tools/run_isolated_replay.py` 是辅助包装器，固定读取归档中 seed 1907 / single 原 final journal 的第一条问题，只发起一次新的 fresh model worker，然后重放同问的 serialized router。它不搜索表现较好的样本，不以答对作为恢复一致性的要求。

这个包装器要求直接调用指定的 venv Python，初始 `PYTHONPATH` 仅含显式指定的第三方 runtime 目录。包内 helper 随后添加 bundle 中的源目录；原 repository 目录禁止出现在初始或实际 `sys.path`。包装器保留父进程实际 `__file__` 来源及哈希，同时通过 fresh worker 的 `PYTHONVERBOSE=1` stderr 记录实际研究模块导入/编译路径，逐项核对 bundle manifest。导入日志是额外诊断开销；这次新增模型读取和时间、token、owner DB 成本独立保存，不计入原实验。

为避免重复分配共享基础模型 payload，本次核验在新的 base 路径创建现有六个 pinned 文件的硬链接，保留每个文件的 device/inode、哈希和源路径证据。它证明实际使用了不同 locator，不代表重新从发布者下载，也不验证另一机器或 CPU 架构的逐 token 一致性。`isolated-replay-receipt.json` 单列这些限制、环境来源和比较结果；原 study、ZIP、解压证据和 owner 数据库均保持原字节。
