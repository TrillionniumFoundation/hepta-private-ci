"""Standard-library byte verification for a portable population evidence bundle."""

import hashlib
import json
from pathlib import Path, PurePosixPath
import sqlite3
import stat
import zipfile


SEEDS = (1907, 2719, 4051)
MANIFEST = "ARCHIVE-MANIFEST.json"


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode()


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def load_json(path):
    return json.loads(Path(path).read_bytes())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def safe_name(value):
    require(isinstance(value, str) and value, "archive member name must be a nonempty string")
    path = PurePosixPath(value)
    require(path.parts and "\\" not in value
            and not path.is_absolute() and ".." not in path.parts
            and path.as_posix() == value and "\0" not in value,
            "unsafe archive member name")
    return value


def files_under(directory):
    root = Path(directory).resolve()
    result = {}
    for path in sorted(root.rglob("*")):
        require(not path.is_symlink(), f"linked input cannot be archived: {path}")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = path
        else:
            require(path.is_dir(), f"non-regular archive input: {path}")
    return result


def verify_zip(path, expected_sha256=None):
    path = Path(path)
    actual = file_hash(path)
    require(expected_sha256 is None or actual == expected_sha256,
            "archive SHA-256 differs from independently retained download pin")
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), "duplicate ZIP members")
        for info in archive.infolist():
            safe_name(info.filename)
            require(not info.is_dir() and not stat.S_ISLNK(info.external_attr >> 16),
                    "ZIP contains directories or links instead of regular members")
        manifest_raw = archive.read(MANIFEST)
        manifest = json.loads(manifest_raw)
        require(set(names) == set(manifest["files"]) | {MANIFEST},
                "archive inventory does not cover every member")
        for name, expected in manifest["files"].items():
            raw = archive.read(name)
            require({"bytes": len(raw), "sha256": sha256(raw)} == expected,
                    "ZIP content pin mismatch: " + name)
    return {"schema": "hepta.population.archive-verification.v1",
            "archive_sha256": actual, "archive_bytes": path.stat().st_size,
            "manifest_sha256": sha256(manifest_raw), "files_verified": len(names) - 1,
            "independent_download_pin_checked": expected_sha256 is not None,
            "passed": True}


def verify_directory(directory):
    root = Path(directory).resolve()
    manifest_raw = (root / MANIFEST).read_bytes()
    manifest = json.loads(manifest_raw)
    actual = files_under(root)
    require(set(actual) == set(manifest["files"]) | {MANIFEST},
            "extracted bundle contains missing or unlisted files")
    for name, expected in manifest["files"].items():
        safe_name(name)
        path = actual[name]
        require(path.stat().st_size == expected["bytes"]
                and file_hash(path) == expected["sha256"],
                "extracted file pin mismatch: " + name)
    return manifest


def relative_to_study(original, study):
    path = Path(original)
    require(path.is_absolute(), "original artifact locator must be absolute")
    return path.relative_to(Path(study).resolve()).as_posix()


def checkpoint_entry(version, study, key, kind):
    directory = Path(version["directory"])
    relative = relative_to_study(directory, study)
    raw = (directory / "lineage.json").read_bytes()
    lineage = json.loads(raw)
    require(sha256(raw) == version["manifest_sha256"], key + ": lineage pin")
    require(file_hash(directory / "adapter_model.safetensors") == lineage["adapter_sha256"],
            key + ": actual adapter weights are missing or changed")
    require(file_hash(directory / "adapter_config.json") == lineage["config_sha256"],
            key + ": adapter config pin")
    require(lineage["roots"] == version["roots"], key + ": source ancestry")
    config = load_json(directory / "adapter_config.json")
    require(config["r"] == version["rank"], key + ": rank binding")
    return {"key": key, "kind": kind, "original_directory": str(directory),
            "archive_directory": "evidence/" + relative,
            "manifest_sha256": version["manifest_sha256"], "rank": version["rank"],
            "seed": version["seed"], "scope": lineage["scope"],
            "base_identity": lineage["base_identity"], "roots": version["roots"],
            "training": lineage["training"]}


def owner_entry(path, study):
    path = Path(path).resolve()
    for suffix in ("-wal", "-shm", "-journal"):
        require(not Path(str(path) + suffix).exists(),
                "owner database is not a quiescent standalone SQLite artifact")
    before = file_hash(path)
    with sqlite3.connect(path.as_uri() + "?mode=ro&immutable=1", uri=True) as connection:
        require(connection.execute("PRAGMA quick_check").fetchall() == [("ok",)],
                "owner database integrity check failed")
        cells = [json.loads(row[0]) for row in connection.execute("SELECT value FROM cells")]
        frontiers = [json.loads(row[0]) for row in connection.execute("SELECT value FROM frontiers")]
    require(file_hash(path) == before, "read-only SQLite inspection changed bytes")
    return {"archive_path": "evidence/" + relative_to_study(path, study),
            "sha256": before, "cells": cells, "frontiers": frontiers,
            "restore_as_active_owner": False}


def inspect_study(study, expected_head, audit_path):
    study = Path(study).resolve()
    files = files_under(study)
    require(not any(Path(name).name == "model.safetensors" for name in files),
            "shared base unexpectedly appears inside study; do not silently omit it")
    aggregate = load_json(study / "aggregate.json")
    audit = load_json(audit_path)
    require(audit["schema"] == "hepta.memory-population.independent-cohort-audit.v1"
            and audit["passed"] is True and audit["seeds"] == list(SEEDS),
            "completed independent three-seed audit required")
    require(sorted(row["seed"] for row in audit["trials"]) == list(SEEDS)
            and all(row["passed"] is True for row in audit["trials"]),
            "each independently audited registered trial must be present exactly once")
    require(sorted(p.name for p in study.glob("seed-*") if p.is_dir())
            == [f"seed-{seed}" for seed in SEEDS], "unregistered or missing study seed directory")
    require(audit["aggregate_sha256"] == file_hash(study / "aggregate.json"),
            "independent audit is not bound to retained aggregate")
    points, owners, routers, results, identities = [], [], [], [], []
    acquisitions, originals = [], []
    for seed in SEEDS:
        directory = study / f"seed-{seed}"
        result = load_json(directory / "result.json")
        require(result["seed"] == seed, "result cohort mismatch")
        identity = load_json(directory / "source-identity.json")
        require(identity == result["source_identity"]
                == load_json(directory / "source-identity-after.json")
                and identity["git_head"] == expected_head,
                "trial source/runtime identity is not the frozen head")
        require(result["engineering_gates"]
                and all(value is True for value in result["engineering_gates"].values()),
                "engineering gates must close before the archive is labelled complete")
        one_audit = next(row for row in audit["trials"] if row["seed"] == seed)
        require(one_audit["result_sha256"] == file_hash(directory / "result.json"),
                "trial result does not match completed independent audit")
        for name, pin in load_json(directory / "raw-evidence-inventory.json").items():
            safe_name(name)
            path = directory / name
            require(path.stat().st_size == pin["bytes"] and file_hash(path) == pin["sha256"],
                    f"seed {seed}: raw inventory pin {name}")
        versions = result["training"]["versions"]
        for arm in ("parent", "single", "split"):
            for slot, version in enumerate(versions[arm]):
                label = f"split-{slot}" if arm == "split" else arm
                points.append(checkpoint_entry(version, study, f"{seed}/{label}", "trained_float32"))
        points.append(checkpoint_entry(result["training"]["expanded_parent"], study,
                                       f"{seed}/expanded-parent", "function_preserving_expansion"))
        original = Path(versions["single"][0]["directory"]) / "lineage.json"
        for bits in (8, 4):
            variant = result["codec"]["variants"][str(bits)]
            packed = directory / f"codec/int{bits}-packed"
            materialized = Path(variant["version"]["directory"])
            codec_raw = (packed / "codec.json").read_bytes()
            codec = json.loads(codec_raw)
            require(sha256(codec_raw) == variant["encoding"]["codec_manifest_sha256"]
                    and file_hash(packed / "adapter.quantized") == codec["payload_sha256"],
                    "actual packed quantized payload pin")
            require((packed / "source-lineage.json").read_bytes()
                    == (materialized / "source-lineage.json").read_bytes() == original.read_bytes(),
                    "codec source lineage must remain byte-for-byte original")
            require((materialized / "codec-receipt.json").read_bytes() == codec_raw
                    and file_hash(materialized / "adapter_model.safetensors")
                    == codec["decoded_safetensors_sha256"], "materialized derivation pins")
            entry = checkpoint_entry(variant["version"], study, f"{seed}/int{bits}",
                                     "lossy_derived_materialized_float32")
            entry.update(archive_packed_directory="evidence/" + relative_to_study(packed, study),
                         codec_manifest_sha256=sha256(codec_raw), quantized_execution=False)
            points.append(entry)
        selection = result["selection"]
        router_path = Path(selection["router_path"])
        require(file_hash(router_path) == selection["router_receipt"]["sha256"], "learned router pin")
        require(file_hash(selection["selection_path"]) == selection["selection_sha256"],
                "immutable source selection pin")
        routers.append({"seed": seed, "archive_path": "evidence/" + relative_to_study(router_path, study),
                        "sha256": selection["router_receipt"]["sha256"],
                        "receipt": selection["router_receipt"]})
        owners.extend(owner_entry(directory / part / "owners.sqlite3", study)
                      for part in ("final", "codec"))
        originals.append(load_json(directory / "final/final-single-request.json")["model"])
        acquisitions.append(load_json(directory / "model-acquisition.json"))
        results.append(result)
        identities.append(identity)
    require(identities[0] == identities[1] == identities[2], "one source and runtime across all seeds")
    require(acquisitions[0] == acquisitions[1] == acquisitions[2], "one exact shared base acquisition")
    require(aggregate["source_identity"] == identities[0], "aggregate source identity")
    require(len(points) == 21 and len(owners) == 6 and len(routers) == 3,
            "all original, expanded and materialized checkpoints must be retained")
    return {"source_identity": identities[0], "checkpoints": points, "routers": routers,
            "owners": owners, "base_acquisition": acquisitions[0],
            "original_base_directories": sorted(set(originals)),
            "audit_sha256": file_hash(audit_path), "aggregate_sha256": file_hash(study / "aggregate.json"),
            "source_head": expected_head, "seeds": list(SEEDS),
            "all_study_files_included": True, "immutable_receipts_rewritten": False,
            "original_study_root": str(study), "production_accepted": False}
