"""Build or verify a complete checkpoint/evidence ZIP without touching its inputs."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

sys.dont_write_bytecode = True
from archive_integrity import (MANIFEST, canonical, file_hash, files_under, inspect_study,
                               load_json, require, safe_name, sha256, verify_directory, verify_zip)


def source_payloads(repo, head, identity, runtime_proof_path, publication_proof_path):
    """Export only local bytes already bound to the published Git tree."""
    runtime = load_json(runtime_proof_path)
    publication = load_json(publication_proof_path)
    require(runtime["schema"] == "hepta.population.all-frozen-runtime-source-binding.v1"
            and runtime["head"] == head
            and runtime["all_identity_files_bound_to_published_tree"] is True
            and re.fullmatch("[0-9a-f]{40}", runtime["tree"]),
            "complete published runtime-source binding required")
    require(publication["published_source_head"] == head
            and publication["local_worktree_bytes_unchanged"] is True,
            "publication proof does not identify the frozen local bytes")
    identity_files = identity["files_sha256"]
    require(runtime["source_manifest_sha256"] == identity["source_manifest_sha256"]
            == sha256(canonical(identity_files)), "runtime source-manifest binding")
    runtime_rows = {row["path"]: row for row in runtime["files"]}
    require(len(runtime_rows) == len(runtime["files"])
            and set(runtime_rows) == {"scripts/" + name for name in identity_files},
            "published runtime binding must cover exactly the recorded Python sources")
    published_rows = {row["path"]: row for row in publication["files"]}
    require(len(published_rows) == len(publication["files"])
            == publication["verified_file_count"], "publication proof inventory")
    rows = dict(runtime_rows)
    for name, row in published_rows.items():
        if name in rows:
            require(all(rows[name][key] == row[key] for key in ("sha256", "git_blob_sha1")),
                    "independent publication proofs disagree: " + name)
        else:
            rows[name] = row
    payloads, entries = {}, {}
    for name, row in sorted(rows.items()):
        safe_name(name)
        path = repo / name
        require(path.is_file() and not path.is_symlink(), "regular local source required: " + name)
        raw = path.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        require(sha256(raw) == row["sha256"] and blob == row["git_blob_sha1"]
                and ("bytes" not in row or len(raw) == row["bytes"]),
                "local bytes differ from published Git tree binding: " + name)
        if name in runtime_rows:
            require(sha256(raw) == identity_files[name.removeprefix("scripts/")],
                    "local bytes differ from experiment source identity: " + name)
        payloads["source/" + name] = raw
        entries[name] = {"bytes": len(raw), "sha256": sha256(raw), "git_blob_sha1": blob,
                         "experiment_source_identity_bound": name in runtime_rows,
                         "published_git_tree_bound": True}
    manifest = {
        "schema": "hepta.population.frozen-source-export.v1", "head": head,
        "tree": runtime["tree"], "source_manifest_sha256": identity["source_manifest_sha256"],
        "files": entries, "runtime_python_files": len(runtime_rows),
        "export_method": "local bytes checked against retained SHA256 and published Git blob SHA1",
        "git_commands_or_network_fetches_used": False, "complete_repository_export": False,
        "runtime_binding_sha256": file_hash(runtime_proof_path),
        "publication_binding_sha256": file_hash(publication_proof_path),
    }
    return payloads, manifest


def absolute_strings(value):
    if isinstance(value, str) and value.startswith("/"):
        yield value
    elif isinstance(value, dict):
        for nested in value.values():
            yield from absolute_strings(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from absolute_strings(nested)


def build(args):
    require(re.fullmatch("[0-9a-f]{40}", args.source_head), "exact frozen Git commit required")
    study, repo, output = args.study.resolve(), args.repo.resolve(), args.output.resolve()
    require(not output.exists() and not output.is_relative_to(study),
            "new archive output must be outside the immutable study")
    catalog = inspect_study(study, args.source_head, args.audit)
    original_files = files_under(study)
    payloads = {"evidence/" + name: path.read_bytes() for name, path in original_files.items()}
    source_identity = catalog["source_identity"]
    source_files, git_manifest = source_payloads(
        repo, args.source_head, source_identity, args.runtime_source_binding,
        args.published_source_verification)
    payloads.update(source_files)
    tools_root = Path(__file__).resolve().parent
    for name in ("archive_integrity.py", "archive_population.py", "restore_population.py",
                 "run_isolated_replay.py"):
        payloads["tools/" + name] = (tools_root / name).read_bytes()
    payloads["RESTORE.md"] = (tools_root / "RESTORE.md").read_bytes()
    payloads["metadata/independent-audit.json"] = args.audit.read_bytes()
    payloads["metadata/runtime-source-binding.json"] = args.runtime_source_binding.read_bytes()
    payloads["metadata/published-source-verification.json"] = args.published_source_verification.read_bytes()
    payloads["metadata/git-source-manifest.json"] = canonical(git_manifest)
    payloads["metadata/checkpoint-catalog.json"] = canonical(catalog)
    payloads["metadata/shared-base.json"] = canonical({
        "included": False, "reason": "shared publisher base is retrieved separately at exact pinned bytes",
        "acquisition": catalog["base_acquisition"],
        "original_directories": catalog["original_base_directories"],
    })
    versions = source_identity["dependencies"]
    payloads["metadata/runtime-versions.json"] = canonical({
        "python": source_identity["python"], "platform": source_identity["platform"],
        "dependencies": versions, "packages_or_wheels_included": False,
    })
    payloads["metadata/runtime-requirements.txt"] = (
        "# Install the recorded CPU torch wheel separately before these packages.\n"
        + "\n".join(f"{name}=={version}" for name, version in sorted(versions.items()) if name != "torch")
        + "\n").encode()
    payloads["metadata/runtime-torch-requirement.txt"] = ("torch==" + versions["torch"] + "\n").encode()
    mappings = []
    refs = set()
    for name, raw in list(payloads.items()):
        if name.startswith("evidence/") and name.endswith(".json"):
            try:
                refs.update(absolute_strings(json.loads(raw)))
            except (ValueError, UnicodeDecodeError):
                pass  # Raw stdout/stderr evidence is copied regardless of JSON parseability.
    for original in sorted(refs):
        path = Path(original)
        if path.is_relative_to(study):
            kind, target = "archived_evidence", "evidence/" + path.relative_to(study).as_posix()
        elif path.is_relative_to(repo):
            target = "source/" + path.relative_to(repo).as_posix()
            kind = "archived_source" if target in payloads else "full_repository_locator"
            if target not in payloads:
                target = None
        elif any(path.is_relative_to(Path(base)) for base in catalog["original_base_directories"]):
            kind, target = "externally_retrieved_shared_base", None
        elif "/bin/python" in original or "parametric-runtime" in original:
            kind, target = "external_python_runtime", None
        else:
            kind, target = "historical_external_locator", None
        mappings.append({"original": original, "kind": kind, "archive_relative_path": target})
    payloads["metadata/absolute-path-map.json"] = canonical({
        "mappings": mappings, "original_records_modified": False,
        "operational_restore_uses_new_owner_and_new_receipts": True,
    })
    manifest = {
        "schema": "hepta.population.download-archive.v1", "source_head": args.source_head,
        "seeds": catalog["seeds"], "original_study_root": str(study),
        "files": {safe_name(name): {"bytes": len(raw), "sha256": sha256(raw)}
                  for name, raw in sorted(payloads.items())},
        "shared_base_included": False, "immutable_receipts_rewritten": False,
        "packaging_tools_are_auxiliary_post_experiment_code": True,
        "general_memory_proven": False, "production_accepted": False,
    }
    payloads[MANIFEST] = canonical(manifest)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("xb") as stream:
        with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, raw in sorted(payloads.items()):
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    require(set(original_files) == set(files_under(study)), "study inventory changed while packing")
    for name, path in original_files.items():
        require(file_hash(path) == manifest["files"]["evidence/" + name]["sha256"],
                "study file changed while packing: " + name)
    receipt = verify_zip(output, file_hash(output))
    receipt.update(checkpoints=21, routers=3, owner_databases=6, packed_quantized_payloads=6,
                   within_50_decimal_megabytes=output.stat().st_size < 50_000_000,
                   source_head=args.source_head, study_inputs_unchanged=True,
                   runtime_source_binding_sha256=git_manifest["runtime_binding_sha256"],
                   source_files_verified=len(git_manifest["files"]),
                   independent_audit_sha256=catalog["audit_sha256"],
                   shared_base_included=False, immutable_receipts_rewritten=False)
    receipt_path = output.with_suffix(output.suffix + ".receipt.json")
    with receipt_path.open("x") as stream:
        json.dump(receipt, stream, sort_keys=True, indent=2)
    print(json.dumps(receipt, sort_keys=True))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    make = commands.add_parser("build")
    for name in ("study", "repo", "audit", "output", "runtime-source-binding",
                 "published-source-verification"):
        make.add_argument("--" + name, type=Path, required=True)
    make.add_argument("--source-head", required=True)
    check = commands.add_parser("verify")
    check.add_argument("--archive", type=Path, required=True)
    check.add_argument("--expected-sha256")
    directory = commands.add_parser("verify-directory")
    directory.add_argument("--bundle", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "build":
        build(args)
    elif args.command == "verify":
        print(json.dumps(verify_zip(args.archive, args.expected_sha256), sort_keys=True))
    else:
        manifest = verify_directory(args.bundle)
        print(json.dumps({"passed": True, "files_verified": len(manifest["files"]),
                          "source_head": manifest["source_head"]}, sort_keys=True))


if __name__ == "__main__":
    main()
