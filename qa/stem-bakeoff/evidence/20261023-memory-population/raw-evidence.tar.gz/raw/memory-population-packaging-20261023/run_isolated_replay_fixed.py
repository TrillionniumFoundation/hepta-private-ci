"""One predeclared relocated read with actual environment/import evidence.

Auxiliary post-experiment code. Run only after the original cohort audit passed.
It preserves the archive/bundle and never alters the frozen experiment source.
"""

import argparse
import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import runpy
import sys
import time

sys.dont_write_bytecode = True

HEAD = "07df4a9cc385375cddded5b5e3b99632ce0652ec"
WRAPPER_PATH = Path(__file__).resolve()
ENV_KEYS = ("PYTHONPATH", "PYTHONVERBOSE", "PYTHONDONTWRITEBYTECODE", "HF_HUB_OFFLINE",
            "TRANSFORMERS_OFFLINE", "TOKENIZERS_PARALLELISM", "OMP_NUM_THREADS",
            "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VIRTUAL_ENV")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def publish(path, value):
    pending = path.with_suffix(path.suffix + ".pending")
    write(pending, value)
    os.link(pending, path)
    pending.unlink()


def environment():
    return {"sys_executable": sys.executable,
            "executable_resolved": str(Path(sys.executable).resolve()),
            "cwd": str(Path.cwd()), "sys_path": list(sys.path),
            "environment": {key: os.environ.get(key) for key in ENV_KEYS},
            "unlisted_environment_variables_not_collected": True}


def expected_modules(bundle, manifest):
    rows = {}
    for name, pin in manifest["files"].items():
        if name.startswith("source/scripts/") and name.endswith(".py"):
            module = Path(name).stem
            require(module not in rows, "unique flat research-module names required")
            rows[module] = {"path": (bundle / name).resolve(), "sha256": pin["sha256"]}
    return rows


def loaded_origins(expected, required):
    rows = []
    for name, pin in sorted(expected.items()):
        if name not in sys.modules:
            continue
        module = sys.modules[name]
        raw_origin = getattr(module, "__file__", None)
        require(raw_origin is not None, "research module lacks origin: " + name)
        path = Path(raw_origin).resolve()
        require(path == pin["path"] and digest(path) == pin["sha256"],
                "research module was not imported from the pinned bundle: " + name)
        rows.append({"module": name, "actual_file": str(path),
                     "sha256": pin["sha256"], "pinned_bundle_source": True})
    require(set(required) <= {row["module"] for row in rows}, "required module origins missing")
    return rows


def worker_origins(stderr, expected, forbidden):
    text = stderr.read_text()
    imports = set(re.findall(r"^import '([^']+)' #", text, flags=re.MULTILINE))
    compiled = set()
    for line in text.splitlines():
        if not line.startswith("# code object from "):
            continue
        raw_path = line.removeprefix("# code object from ").strip()
        path = ast.literal_eval(raw_path) if raw_path.startswith(("\'", '"')) else raw_path
        if isinstance(path, str) and path.endswith(".py"):
            compiled.add(Path(path).resolve())
    require(str(forbidden) not in text, "worker trace contains the original repository path")
    names = set(expected) & imports
    require({"parametric_model", "tensor_contract", "pretrained", "native"} <= names,
            "actual worker research import trace is incomplete")
    rows = []
    for name in sorted(names):
        pin = expected[name]
        require(pin["path"] in compiled and digest(pin["path"]) == pin["sha256"],
                "worker import lacks a pinned bundle compilation record: " + name)
        rows.append({"module": name, "compiled_from": str(pin["path"]),
                     "sha256": pin["sha256"], "pinned_bundle_source": True})
    for path in compiled:
        if path.stem in names and any(part.startswith("memory_cell") for part in path.parts):
            require(path == expected[path.stem]["path"], "alternate research source in worker trace")
    return {"trace_path": str(stderr), "trace_sha256": digest(stderr),
            "trace_bytes": stderr.stat().st_size, "research_modules": rows,
            "original_repository_path_seen": False,
            "evidence": "actual fresh worker CPython PYTHONVERBOSE=1 import/compilation trace"}


def invoke_helper(helper, argv):
    old_argv = sys.argv
    capture = io.StringIO()
    try:
        sys.argv = [str(helper), *argv]
        with contextlib.redirect_stdout(capture):
            runpy.run_path(str(helper), run_name="__main__")
    finally:
        sys.argv = old_argv
    raw = capture.getvalue()
    return raw, json.loads(raw)


def execute(args):
    bundle, output = args.bundle.resolve(), args.output.resolve()
    base_source, base_new = args.base_source.resolve(), args.base_relocated.resolve()
    forbidden, runtime = args.forbidden_repo.resolve(), args.runtime.resolve()
    require(os.environ.get("PYTHONPATH", "").split(os.pathsep) == [str(runtime)],
            "initial PYTHONPATH must consist only of the explicitly named third-party runtime")
    require(Path(sys.executable).absolute() == args.python.absolute(), "use the direct declared venv interpreter")
    require(not output.exists() and not base_new.exists(), "new output and new base directories required")
    require(not output.is_relative_to(bundle) and not base_new.is_relative_to(bundle),
            "new operational data must be outside the immutable bundle")
    initial = environment()
    require(all(not Path(path or ".").resolve().is_relative_to(forbidden) for path in sys.path),
            "initial sys.path contains the original repository")
    require(digest(args.archive) == args.archive_sha256, "published archive hash mismatch")
    sys.path.insert(0, str(bundle / "tools"))
    from archive_integrity import load_json, verify_directory
    manifest = verify_directory(bundle)
    require(manifest["source_head"] == HEAD, "wrong frozen source head")
    expected = expected_modules(bundle, manifest)
    require(not (set(expected) & set(sys.modules)), "research modules must not be preloaded")
    catalog = load_json(bundle / "metadata/checkpoint-catalog.json")
    audit_path = bundle / "metadata/independent-audit.json"
    audit = load_json(audit_path)
    require(audit["schema"] == "hepta.memory-population.independent-cohort-audit.v1"
            and audit["passed"] is True and audit["seeds"] == [1907, 2719, 4051]
            and digest(audit_path) == catalog["audit_sha256"], "completed pinned cohort audit required")
    seed_pins = {str(seed): digest(bundle / f"evidence/seed-{seed}/result.json")
                 for seed in (1907, 2719, 4051)}
    require(sorted(row["seed"] for row in audit["trials"]) == [1907, 2719, 4051]
            and all(row["passed"] is True and row["result_sha256"] == seed_pins[str(row["seed"])]
                    for row in audit["trials"]),
            "audited trial result pins differ")
    require(digest(bundle / "evidence/aggregate.json") == catalog["aggregate_sha256"]
            == audit["aggregate_sha256"], "audited aggregate pin differs")
    bindings = {
        "independent_audit_sha256": catalog["audit_sha256"],
        "aggregate_sha256": catalog["aggregate_sha256"], "seed_result_sha256": seed_pins,
        "archive_manifest_sha256": digest(bundle / "ARCHIVE-MANIFEST.json"),
        "seed": 1907, "variant": "single",
        "checkpoint_manifest_sha256": next(row["manifest_sha256"] for row in catalog["checkpoints"]
                                             if row["key"] == "1907/single"),
        "router_sha256": next(row["sha256"] for row in catalog["routers"] if row["seed"] == 1907),
        "original_route_plan_sha256": digest(bundle / "evidence/seed-1907/final/route-plan.json"),
    }
    require(base_new.parent.is_dir() and base_source.stat().st_dev == base_new.parent.stat().st_dev,
            "hardlink requires same filesystem; choose a new base path on the source device")
    reference = bundle / "evidence/seed-1907/final/final-single-journal.json"
    original = load_json(reference)
    question = original["rows"][0]["question"]
    output.mkdir(parents=True)
    write(output / "launch-plan.json", {
        "schema": "hepta.population.isolated-replay-plan.v1", "source_head": HEAD,
        **bindings,
        "archive_path": str(args.archive.resolve()), "archive_sha256": args.archive_sha256,
        "bundle_directory": str(bundle), "initial_environment": initial,
        "seed": 1907, "variant": "single", "question": question,
        "question_selection": "predeclared first row of archived seed1907 final single journal",
        "reference_journal_sha256": digest(reference), "reference_row_index": 0,
        "new_base_directory": str(base_new), "new_owner_database": str(output / "replay/owners.sqlite3"),
        "original_repo_forbidden": str(forbidden), "max_fresh_model_worker_processes": 1,
        "counted_in_original_study": False, "wrapper_sha256": digest(WRAPPER_PATH),
    })
    base_new.mkdir(parents=True)
    links = []
    for row in catalog["base_acquisition"]["files"]:
        source, target = base_source / row["path"], base_new / row["path"]
        require(source.is_file() and not source.is_symlink(), "regular source base file required")
        require(source.stat().st_size == row["bytes"] and digest(source) == row["sha256"],
                "source shared base pin mismatch")
        target.parent.mkdir(parents=True, exist_ok=True)
        os.link(source, target)
        a, b = source.stat(), target.stat()
        require((a.st_dev, a.st_ino) == (b.st_dev, b.st_ino), "actual hardlink required")
        links.append({"source": str(source), "new_path": str(target), "bytes": b.st_size,
                      "sha256": row["sha256"], "device": b.st_dev, "inode": b.st_ino,
                      "same_inode_as_source": True})
    write(output / "base-hardlink-receipt.json", {
        "files": links, "download_performed": False, "source_base_files_modified": False,
        "source_directory_st_dev": base_source.stat().st_dev,
        "new_directory_st_dev": base_new.stat().st_dev, "same_device_checked_before_linking": True,
        "additional_base_payload_allocated_bytes": 0, "directory_metadata_bytes_not_measured": True,
    })
    cwd = output / "launcher-cwd"
    cwd.mkdir()
    os.chdir(cwd)
    os.environ["PYTHONVERBOSE"] = "1"
    helper = bundle / "tools/restore_population.py"
    started = time.perf_counter()
    raw, replay_stdout = invoke_helper(helper, [
        "replay", "--bundle", str(bundle), "--base", str(base_new), "--seed", "1907",
        "--variant", "single", "--question", question, "--output", str(output / "replay"),
    ])
    (output / "replay-helper-stdout.json").write_text(raw)
    replay = load_json(output / "replay/replay-result.json")
    origins_before_router = loaded_origins(expected, ("parametric_owner", "population_worker", "tensor_contract"))
    worker = worker_origins(output / "replay/relocated-reader-stderr.log", expected, forbidden)
    require(replay["work"]["additional_fresh_worker_processes"] == 1
            and replay["work"]["actual_queries"] == 1, "exactly one fresh model query required")
    require(replay["reference_comparison"]["available"] is True
            and replay["reference_comparison"]["all_fields_match"] is True,
            "relocated raw output/token/state comparison failed")
    raw_router, router = invoke_helper(helper, [
        "router", "--bundle", str(bundle), "--seed", "1907", "--question", question,
    ])
    (output / "router-helper-stdout.json").write_text(raw_router)
    origins_after_router = loaded_origins(expected, ("learned_router", "router_features"))
    require(router["reference_available"] is True and router["matches_original_frozen_route"] is True,
            "serialized router same-question replay differs")
    verify_directory(bundle)
    require(digest(args.archive) == args.archive_sha256, "archive changed during replay")
    for row in links:
        source, target = Path(row["source"]), Path(row["new_path"])
        require(digest(source) == row["sha256"] == digest(target)
                and source.stat().st_ino == target.stat().st_ino == row["inode"],
                "shared base bytes or hardlink identity changed during replay")
    final_env = environment()
    require(all(not Path(path or ".").resolve().is_relative_to(forbidden) for path in sys.path),
            "effective sys.path contains the original repository")
    receipt = {
        "schema": "hepta.population.isolated-relocated-replay.v1", "passed": True,
        **bindings,
        "source_head": HEAD, "archive_sha256": args.archive_sha256,
        "initial_environment": initial, "effective_environment": final_env,
        "parent_module_origins_before_router": origins_before_router,
        "parent_module_origins_after_router": origins_after_router, "worker_import_trace": worker,
        "all_observed_research_modules_from_pinned_bundle": True,
        "initial_pythonpath_runtime_only": True, "original_repository_import_fallback_used": False,
        "replay_result_sha256": digest(output / "replay/replay-result.json"),
        "reference_comparison": replay["reference_comparison"], "router_replay": router,
        "work": replay["work"], "wrapper_elapsed_seconds": time.perf_counter() - started,
        "base_retrieval": "hardlinks to existing exact pinned bytes; not a new download",
        "shared_base_bytes_and_hardlink_identity_unchanged": True,
        "original_experiment_modified": False, "archive_and_bundle_unchanged": True,
        "wrapper_sha256": digest(WRAPPER_PATH), "answer_correctness_required": False,
        "general_portability_across_platforms_proven": False,
    }
    publish(output / "isolated-replay-receipt.json", receipt)
    print(json.dumps(receipt, sort_keys=True))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("bundle", "archive", "base-source", "base-relocated", "output",
                 "runtime", "python", "forbidden-repo"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--archive-sha256", required=True)
    args = parser.parse_args()
    for name in ("bundle", "archive", "base_source", "base_relocated", "output",
                 "runtime", "forbidden_repo"):
        setattr(args, name, getattr(args, name).resolve())
    args.python = args.python.absolute()
    try:
        execute(args)
    except Exception as exc:
        if args.output.exists() and not (args.output / "failure.json").exists():
            write(args.output / "failure.json", {"type": type(exc).__name__, "message": str(exc),
                  "retry_model_without_review": False, "already_written_receipts_preserved": True})
        raise


if __name__ == "__main__":
    main()
