"""Inspect a bundle or create new relocated replay receipts without changing evidence."""

import argparse
from importlib.metadata import version
import json
import os
from pathlib import Path
import platform
import sys

sys.dont_write_bytecode = True
from archive_integrity import file_hash, files_under, load_json, require, verify_directory


VARIANTS = ("parent", "expanded-parent", "single", "split-0", "split-1", "int8", "int4")
ROW_COMPARISON_FIELDS = ("question", "text", "token_ids", "prompt_token_ids", "prompt_sha256",
                         "input_tokens", "generated_tokens", "base_identity", "adapter_enabled",
                         "answer_postprocessed")


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def setup_sources(bundle):
    script_root = bundle / "source/scripts"
    directories = [str(path) for path in sorted(script_root.iterdir()) if path.is_dir()]
    sys.path[:0] = directories
    os.environ["PYTHONPATH"] = os.pathsep.join(directories + [os.environ.get("PYTHONPATH", "")])
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
        os.environ[name] = "2"


def verify_base(base, acquisition):
    actual = {name: path for name, path in files_under(base).items()
              if ".cache" not in Path(name).parts}
    expected = {row["path"]: row for row in acquisition["files"]}
    require(set(actual) == set(expected), "base directory must contain exactly the pinned publisher files")
    for name, row in expected.items():
        require(actual[name].stat().st_size == row["bytes"]
                and file_hash(actual[name]) == row["sha256"], "shared base byte pin: " + name)


def reference_generation(bundle, seed, variant, question, journal):
    if variant == "expanded-parent":
        return {"available": False, "reason": "expanded parent has no registered final worker journal"}
    part, label = ("codec", "codec-" + variant[3:]) if variant.startswith("int") else (
        "final", "final-" + variant)
    reference = bundle / "evidence" / f"seed-{seed}" / part / (label + "-journal.json")
    original = load_json(reference)
    indices = [i for i, row in enumerate(original["rows"]) if row["question"] == question]
    if len(indices) != 1:
        return {"available": False, "reason": "question is not a unique row in this variant's final journal"}
    old, new = original["rows"][indices[0]], journal["rows"][0]
    matches = {key: old[key] == new[key] for key in ROW_COMPARISON_FIELDS}
    matches.update({key: original[key] == journal[key] for key in (
        "actual_adapter_tensor_sha256", "admitted_adapter_state_sha256",
        "consumed_adapter_state_sha256", "effective_state_sha256")})
    return {"available": True, "original_journal_archive_path": reference.relative_to(bundle).as_posix(),
            "original_journal_sha256": file_hash(reference), "original_row_index": indices[0],
            "field_matches": matches, "all_fields_match": all(matches.values()),
            "answer_correctness_used": False, "timings_expected_equal": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("plan", "replay", "router"):
        command = commands.add_parser(name)
        command.add_argument("--bundle", type=Path, required=True)
        command.add_argument("--seed", type=int, choices=(1907, 2719, 4051), required=True)
        if name != "router":
            command.add_argument("--variant", choices=VARIANTS, required=True)
        if name in ("replay", "router"):
            command.add_argument("--question", required=True)
        if name == "replay":
            command.add_argument("--base", type=Path, required=True)
            command.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    bundle = args.bundle.resolve()
    manifest = verify_directory(bundle)
    catalog = load_json(bundle / "metadata/checkpoint-catalog.json")
    if args.command == "router":
        setup_sources(bundle)
        from learned_router import load_router
        entry = next(row for row in catalog["routers"] if row["seed"] == args.seed)
        router = load_router(bundle / entry["archive_path"], expected_sha256=entry["sha256"])
        decision = router.predict({"question": args.question})
        plan_path = bundle / "evidence" / f"seed-{args.seed}" / "final/route-plan.json"
        references = [row["learned"] for row in load_json(plan_path)["rows"]
                      if row["question"] == args.question]
        verify_directory(bundle)
        print(json.dumps({"decision": decision, "reference_available": len(references) == 1,
                          "matches_original_frozen_route": decision == references[0]
                          if len(references) == 1 else None,
                          "route_plan_sha256": file_hash(plan_path),
                          "evidence_bundle_unchanged": True}, sort_keys=True))
        return
    entry = next(row for row in catalog["checkpoints"] if row["key"] == f"{args.seed}/{args.variant}")
    snapshot = bundle / entry["archive_directory"]
    relocated = {"directory": str(snapshot), "manifest_sha256": entry["manifest_sha256"],
                 "rank": entry["rank"], "seed": entry["seed"], "roots": entry["roots"]}
    if args.command == "plan":
        print(json.dumps({"original_directory": entry["original_directory"],
                          "relocated_operational_version": relocated,
                          "scope": entry["scope"], "immutable_receipts_modified": False,
                          "original_owner_database_reused": False,
                          "source_head": manifest["source_head"]}, sort_keys=True, indent=2))
        return
    output, base = args.output.resolve(), args.base.resolve()
    require(not output.exists() and not output.is_relative_to(bundle),
            "replay requires a new output directory outside the evidence bundle")
    verify_base(base, catalog["base_acquisition"])
    recorded = catalog["source_identity"]["dependencies"]
    installed = {name: version(name) for name in recorded}
    require(installed == recorded, "install the exact recorded package versions before replay")
    setup_sources(bundle)
    from parametric_owner import Frontier, ParametricOwner
    from population_worker import fresh_read
    output.mkdir(parents=True)
    context = {"archive_manifest_sha256": file_hash(bundle / "ARCHIVE-MANIFEST.json"),
               "original_manifest_sha256": entry["manifest_sha256"],
               "original_directory": entry["original_directory"],
               "relocated_replay": True, "original_owner_database_reused": False,
               "source_authority": "historical_synthetic_fixture_in_new_local_owner",
               "current_external_source_authority_established": False}
    write_json(output / "relocation.json", {
        **context, "operational_version": relocated, "base_directory": str(base),
        "python": platform.python_version(), "platform": platform.platform(),
        "dependencies": installed, "original_recorded_runtime": catalog["source_identity"],
    })
    journal = fresh_read(base, relocated, [args.question], output, "relocated-reader",
                         ParametricOwner(output / "owners.sqlite3"),
                         Frontier(entry["scope"], 1, ()), write_json, context=context)
    verify_directory(bundle)
    comparison = reference_generation(bundle, args.seed, args.variant, args.question, journal)
    work = {"additional_fresh_worker_processes": 1, "actual_queries": len(journal["rows"]),
            "input_tokens": sum(row["input_tokens"] for row in journal["rows"]),
            "generated_tokens": sum(row["generated_tokens"] for row in journal["rows"]),
            "generation_seconds": sum(row["seconds"] for row in journal["rows"]),
            "fresh_process_wall_seconds": journal["fresh_process_wall_seconds"],
            "owner_database_bytes": (output / "owners.sqlite3").stat().st_size,
            "counted_in_original_study": False}
    write_json(output / "replay-result.json", {
        "journal_path": journal["journal_path"], "rows": journal["rows"],
        "owner_admitted_before_and_after": journal["owner_admitted_before_and_after"],
        "reference_comparison": comparison, "work": work,
        "evidence_bundle_unchanged": True, "original_experiment_replaced": False,
        "production_accepted": False,
    })
    print(json.dumps({"output": str(output), "raw_text": journal["rows"][0]["text"],
                      "reference_comparison": comparison, "work": work,
                      "evidence_bundle_unchanged": True}, sort_keys=True))


if __name__ == "__main__":
    main()
