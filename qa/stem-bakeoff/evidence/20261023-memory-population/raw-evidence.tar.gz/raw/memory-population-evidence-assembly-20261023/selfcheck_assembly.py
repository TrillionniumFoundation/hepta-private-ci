"""Small synthetic packaging checks; never assemble or execute the live study."""

import hashlib
import json
import os
from pathlib import Path
import tarfile
import tempfile

import assemble_evidence as helper


def rejected(operation, reason):
    try:
        operation()
    except (helper.AssemblyError, OSError, EOFError, tarfile.TarError):
        return reason
    raise AssertionError("expected rejection: " + reason)


def run():
    completed = []
    root = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix="synthetic-selfcheck-", dir=root) as temporary:
        fixture = Path(temporary)
        inputs = fixture / "inputs"
        inputs.mkdir()
        source = inputs / "original.json"
        source.write_bytes(b'{"synthetic":true,"note":"original bytes preserved"}\n')
        name = source.relative_to(helper.WORKSPACE).as_posix()
        raw = source.read_bytes()
        manifest = {"schema": "synthetic-assembly-selfcheck-only", "source_head": helper.HEAD,
                    "files": {"raw/" + name: {"bytes": len(raw), "sha256": helper.sha(raw)}}}
        first, second = fixture / "first.tar.gz", fixture / "second.tar.gz"
        helper.deterministic_archive(first, manifest)
        helper.deterministic_archive(second, manifest)
        assert first.read_bytes() == second.read_bytes()
        completed.append("identical synthetic inputs give identical tar.gz bytes")
        with tarfile.open(first, "r:gz") as archive:
            assert archive.extractfile("raw/" + name).read() == raw
            assert archive.extractfile("MANIFEST.json").read() == helper.json_bytes(manifest)
            assert all(m.mtime == m.uid == m.gid == 0 and m.mode == 0o444 for m in archive)
        completed.append("original bytes and canonical tar metadata round trip")

        bundle = fixture / "bundle"
        bundle.mkdir()
        (bundle / "raw-evidence.tar.gz").write_bytes(first.read_bytes())
        (bundle / "raw-evidence.manifest.json").write_bytes(helper.json_bytes(manifest))
        checksums = {p.name: {"bytes": p.stat().st_size, "sha256": helper.sha(p.read_bytes())}
                     for p in bundle.iterdir()}
        (bundle / "checksums.json").write_bytes(helper.json_bytes({"files": checksums}))
        assert helper.verify_bundle(bundle)["raw_files_verified"] == 1
        completed.append("bundle verifier accepts the complete synthetic checksum set")
        altered = bytearray((bundle / "raw-evidence.tar.gz").read_bytes())
        altered[len(altered) // 2] ^= 1
        (bundle / "raw-evidence.tar.gz").write_bytes(altered)
        completed.append(rejected(lambda: helper.verify_bundle(bundle), "archive corruption is rejected"))
        source.write_bytes(raw + b"changed\n")
        completed.append(rejected(lambda: helper.deterministic_archive(fixture / "changed.tar.gz", manifest),
                                  "a source changed after manifest capture is rejected"))

        for filename in ("adapter_model.safetensors", "adapter.quantized", "owners.sqlite3",
                         "owners.sqlite3-wal", "learned-router.bin"):
            (inputs / filename).write_bytes(b"synthetic excluded payload")
        relative_inputs = inputs.relative_to(helper.WORKSPACE).as_posix()
        all_files, selected, missing = helper.inventory({"evidence_sources": [relative_inputs]})
        assert not missing and set(selected) == {name} and len(all_files) == 6
        completed.append("weight quantized router and SQLite payloads are explicitly excluded")

        link = inputs / "linked.json"
        link.symlink_to(source)
        completed.append(rejected(lambda: helper.read_stable(link.relative_to(helper.WORKSPACE).as_posix()),
                                  "symlink input is rejected before reading"))
        link.unlink()
        fifo = inputs / "pipe.json"
        os.mkfifo(fifo)
        completed.append(rejected(lambda: helper.read_stable(fifo.relative_to(helper.WORKSPACE).as_posix()),
                                  "special-file input is rejected without blocking"))
        fifo.unlink()
        completed.append(rejected(lambda: helper.workspace_path("../other-workspace/data.json"),
                                  "parent traversal is rejected"))

        incomplete = fixture / "incomplete-study"
        incomplete.mkdir()
        spec = {"schema": "hepta.population.evidence-assembly-spec.v1", "source_head": helper.HEAD,
                "seeds": helper.SEEDS, "study_root": incomplete.relative_to(helper.WORKSPACE).as_posix()}
        completed.append(rejected(lambda: helper.completed_inputs(spec),
                                  "a study without a launcher completion receipt is rejected"))
    return {"schema": "hepta.population.evidence-helper-synthetic-selfcheck.v1",
            "passed": True, "checks": completed, "synthetic_check_count": len(completed),
            "live_study_bytes_read": False, "final_evidence_package_created": False,
            "experimental_unit_tests_run": False,
            "helper_sha256": hashlib.sha256((root / "assemble_evidence.py").read_bytes()).hexdigest(),
            "selfcheck_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
