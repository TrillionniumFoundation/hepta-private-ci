#!/usr/bin/env python3
"""Bounded, stdlib-only evidence-helper contract checks; no study tests or models."""

import copy
import importlib.util
import json
from pathlib import Path


root = Path(__file__).parent
loader = importlib.util.spec_from_file_location("assembly_helper", root / "assemble_evidence.py")
helper = importlib.util.module_from_spec(loader)
loader.loader.exec_module(helper)
spec = json.loads((root / "assembly-spec.template.json").read_text())
replay = json.loads(helper.read_stable(spec["isolated_replay_receipt"]))
data = helper.read_stable(helper.REPLAY_OWNER_DATABASE)
checks = []


def passed(name, action):
    action()
    checks.append({"name": name, "passed": True})


def rejected(name, action):
    try:
        action()
    except helper.AssemblyError as error:
        checks.append({"name": name, "passed": True, "expected_error": str(error)})
    else:
        raise AssertionError("invalid evidence unexpectedly accepted: " + name)


passed("actual exact-path bytes match size, SHA and final replay receipt",
       lambda: helper.check_replay_owner_database(helper.REPLAY_OWNER_DATABASE, data, replay))
corrupt = bytes([data[0] ^ 1]) + data[1:]
rejected("one-byte corruption keeps size but fails SHA",
         lambda: helper.check_replay_owner_database(helper.REPLAY_OWNER_DATABASE, corrupt, replay))
rejected("truncated database fails size/hash",
         lambda: helper.check_replay_owner_database(helper.REPLAY_OWNER_DATABASE, data[:-1], replay))
rejected("same bytes at another attempt path are not excepted",
         lambda: helper.check_replay_owner_database(helper.REPLAY_OWNER_DATABASE.replace("002", "003"), data, replay))
bad_receipt = copy.deepcopy(replay)
bad_receipt["all_prior_replay_file_pins"][str(helper.WORKSPACE / helper.REPLAY_OWNER_DATABASE)] = "0" * 64
rejected("receipt database SHA mismatch is rejected",
         lambda: helper.check_replay_owner_database(helper.REPLAY_OWNER_DATABASE, data, bad_receipt))
bad_size = copy.deepcopy(replay)
bad_size["work"]["owner_database_bytes"] = len(data) + 1
rejected("receipt database bytecount mismatch is rejected",
         lambda: helper.check_replay_owner_database(helper.REPLAY_OWNER_DATABASE, data, bad_size))
assert helper.inclusion_reason(helper.REPLAY_OWNER_DATABASE) is None
checks.append({"name": "exact pinned database is included by inventory", "passed": True})
for name in (
    helper.REPLAY_OWNER_DATABASE + "-wal",
    helper.REPLAY_OWNER_DATABASE + "-shm",
    helper.REPLAY_OWNER_DATABASE.replace("002", "003"),
    "memory-population-20261023/seed-1907/owners.sqlite3",
):
    assert helper.inclusion_reason(name) == "model_or_database_payload_excluded", name
    checks.append({"name": "other database/sidecar remains excluded: " + name, "passed": True})
assert helper.replay_result_name(spec, replay) == spec["isolated_replay_result"]
checks.append({"name": "actual completed attempt-002 result location is receipt-bound", "passed": True})
bad_path = copy.deepcopy(replay)
bad_path["replay_result_path"] = str(helper.WORKSPACE / "unrelated/replay-result.json")
rejected("receipt path outside declared replay result is rejected",
         lambda: helper.replay_result_name(spec, bad_path))
bad_spec = copy.deepcopy(spec)
bad_spec["isolated_replay_result"] = "memory-population-relocated-replay-20261023/../unrelated/replay-result.json"
rejected("traversal in configured replay result is rejected",
         lambda: helper.replay_result_name(bad_spec, replay))
print(json.dumps({"schema": "hepta.population.evidence-helper-contract-check.v1",
                  "passed": True, "checks": checks, "check_count": len(checks),
                  "frozen_population_test_count_unchanged": 73,
                  "model_processes_started": 0,
                  "original_evidence_files_modified": False}, ensure_ascii=False, indent=2))
