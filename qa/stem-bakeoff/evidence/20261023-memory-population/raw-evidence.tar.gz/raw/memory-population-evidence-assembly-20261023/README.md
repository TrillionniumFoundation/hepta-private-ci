# Memory population raw-evidence assembly helper

This helper prepares the evidence publication for frozen source
`07df4a9cc385375cddded5b5e3b99632ce0652ec`. It uses only the Python standard
library, imports no experimental modules, loads no model, runs no tests of the
experimental code, performs no network requests, and performs no Git operations.

The helper lives outside the frozen repository. The proposed publication path is
`qa/stem-bakeoff/evidence/20261023-memory-population/`; the root agent can publish
the completed staging directory on an evidence branch that retains the frozen
source as an ancestor. This helper does not create or publish that branch.

**No final evidence package has been created by preparing this helper.** The
template names the planned audit path
`memory-population-independent-launch-review-20261023/independent-cohort-audit.json`;
that final report and the running study's launcher completion receipt are not
present yet. Metadata inventory is permitted while the trials run;
hashing/copying the final evidence requires completion.

The helper itself passed ten checks on tiny synthetic files, recorded in
`helper-selfcheck-r1.log` and its source-bound receipt: deterministic archive
bytes, original-byte round trip, bundle verification, corruption detection,
changed-input rejection, binary/SQLite exclusion, symlink/special-file/path
rejection, and incomplete-study rejection. These checks read no live study
bytes, created no final study package, and are separate from the experiment's
73 distinct tests. The temporary synthetic archives were removed afterwards.
`syntax-check-r1.json` separately preserves standard-library AST parsing of the
two helper scripts without executing them or touching experiment code.
The source-bound r1 checks precede the additional explicit `passed: true` and
positive `files_verified` checkpoint-receipt admission check. `syntax-check-r2.json`
binds that final guard to the packager's actual returned schema. The archive
mechanism itself is unchanged; no experimental tests were rerun.

## Interface

Run from any working directory. All input and staging paths are relative to the
single allowed workspace `/workspace/scratch/1d69f04ee9f4`; absolute input paths,
parent traversal and symlinks are rejected. The `verify` command takes the path
of an already assembled local bundle and needs no original workspace files.

```bash
python -B /workspace/scratch/1d69f04ee9f4/memory-population-evidence-assembly-20261023/assemble_evidence.py inventory \
  --spec memory-population-evidence-assembly-20261023/assembly-spec.template.json
```

`inventory` lists metadata and explicit exclusions. It does not read the bytes
of live trial files and is explicitly labeled a preflight, not a final snapshot.

After all trials, independent cohort audit, and checkpoint archive are complete,
copy the template to a final spec if needed. Set the audit path in the spec or
pass it with `--audit`. The placeholder below must be replaced with the actual
workspace-relative completed audit file; no audit filename is assumed.

```bash
python -B /workspace/scratch/1d69f04ee9f4/memory-population-evidence-assembly-20261023/assemble_evidence.py validate \
  --spec memory-population-evidence-assembly-20261023/assembly-spec.template.json \
  --audit ACTUAL_COMPLETED_COHORT_AUDIT.json

python -B /workspace/scratch/1d69f04ee9f4/memory-population-evidence-assembly-20261023/assemble_evidence.py assemble \
  --spec memory-population-evidence-assembly-20261023/assembly-spec.template.json \
  --audit ACTUAL_COMPLETED_COHORT_AUDIT.json \
  --output memory-population-evidence-ready-20261023

python -B /workspace/scratch/1d69f04ee9f4/memory-population-evidence-assembly-20261023/assemble_evidence.py verify \
  --bundle /workspace/scratch/1d69f04ee9f4/memory-population-evidence-ready-20261023
```

`--checkpoint-receipt PATH` can override the expected
`hepta-memory-population-checkpoints-20261023.zip.receipt.json`. The helper reads
only that receipt and validates its source/audit bindings. The router agent owns
the actual checkpoint ZIP's creation and verification.

If the final audit creates a new directory of logs, failed attempts or repair
receipts, add that directory to `evidence_sources` before final assembly. The
specified audit JSON itself is included automatically, but adjacent files in an
otherwise unlisted directory are not discovered implicitly. Preserve each
validation/assembly attempt's output under a new filename instead of overwriting
an earlier failure log.

Root-authored explanation may be appended to any generated root document using
the optional `narratives` mapping, for example
`{"summary.md": "memory-population-publication-notes-20261023.md"}`. These input
files are archived unchanged, and the additional explanation follows the
machine-derived outcome tables. The helper never edits a result, audit or raw
receipt to make it fit a summary.

## Completion gate and consistency

Assembly requires all of the following:

1. `memory-population-20261023/execution-receipt.json` states that exactly seeds
   1907, 2719 and 4051 have exited and the source HEAD stayed frozen.
2. Each seed has its final `result.json`. Its seed and frozen source/runtime/
   protocol identity agree with the other seeds. The process exit code agrees
   with its actual engineering gates; a completed negative result is preserved.
3. The independent report has schema
   `hepta.memory-population.independent-cohort-audit.v1`, `passed: true`, the exact
   three seeds, and matching original result/aggregate SHA-256 values. Passing
   this audit does not require all scientific hypotheses to pass.
4. The checkpoint ZIP receipt names the same source HEAD and exact audit hash,
   states `passed: true` with positive verified-file count, states that study
   inputs stayed unchanged, and preserves original receipts.
5. The original failed unified-run receipt/log and the later passing receipt/log
   both remain present and their hashes agree. The initial CI count-parser error
   receipt and its corrected receipt also remain present.
6. Both original successful CI job logs contain the same 73 distinct test IDs
   and the expected pre/post exact-HEAD checks. Two executions do not become 146
   independent tests. The small original CI ZIP matches its GitHub digest.

Selected files are bounded regular files and are checked before/after each read.
The helper snapshots the complete selected/excluded inventory, checks source
hashes again while creating the archive, checks the inventory and all selected
hashes again afterwards, and rereads the completion/audit pins. A new or modified
input causes rejection. It stages in a new temporary directory, verifies every
archive member, then renames that directory into the requested new destination.
An existing destination is never overwritten. Outputs inside the frozen
repository or an input tree are rejected.

The completion receipt is the producer's finalization marker. Metadata and
repeated SHA checks protect against ordinary concurrent changes; they are not a
remote execution attestation or a substitute for the independent experiment
audit. No half-written file is accepted as final merely because it happened to
parse once.

## Output files

| File | Purpose |
|---|---|
| `README.md` | Source identity, packaging scope, exclusions and verification |
| `summary.md` | Original aggregate claim flags and all three per-seed summaries/gates |
| `blocker-register.md` | Completed engineering evidence and scientific claims kept distinct; dated ordinary-CI observations retained |
| `source-stack.md` | Published stage/PR/HEAD table ending at the exact frozen source |
| `raw-evidence.tar.gz` | Original source bytes, sorted canonical tar members and deterministic gzip header |
| `raw-evidence.manifest.json` | Every archived original path, byte count and SHA-256; exclusions with sizes and reasons |
| `assembly-spec.json` | Effective paths and selection policy, including any audit override |
| `assembly-receipt.json` | Completion/audit pins and 73 distinct final test IDs |
| `checksums.json` | SHA-256 and bytes for every other bundle file |
| `tools/assemble_evidence.py` | The assembly/verification implementation used |

`MANIFEST.json` inside the tar is identical to the external raw manifest. Each
original file is stored under `raw/<workspace-relative-original-path>`. Original
JSON formatting, absolute paths inside receipts, failure logs and corrections
are preserved byte for byte. SHA-256 detects byte changes; publishing a trusted
top-level checksum/receipt is what binds the bundle to a publication.

Tar members use mode 0444, uid/gid zero, empty owner/group names and mtime zero;
gzip uses mtime zero and an empty filename. The same original bytes, spec, helper
and Python/zlib implementation produce the same raw archive bytes. No wall-clock
assembly timestamp or destination path is inserted into that archive.

## Exact original source inventory

The spec explicitly names only this study's paths in the current workspace:

- `memory-population-20261023/`: final dataset/protocol/source/acquisition JSON,
  all write/gradient/partition/read/codec/result/inventory receipts, complete
  source baseline bytes, per-seed logs and shared resource observations.
- `memory-codec-validation-20261023/`: original codec and heterogeneous-source
  tests, real-parent smoke receipts, retained original baselines and diagnostics.
- `memory-population-{fixture,mechanics,reporting,audit}-validation-20261023/`:
  all original focused successes, failures, pre-fix snapshots and corrections.
- `memory-population-validation-20261023/`: first unified failure, corrected
  pass, source/format/runtime binding, publication/source-stack and workflow
  verification records.
- `memory-population-ci-preflight-20261023/`: raw status snapshots, old queue
  evidence, both successful exact-head original job logs, original CI ZIP and
  extracted contents, initial parser-error receipt and corrected receipt.
- `memory-population-independent-launch-review-20261023/` and the protocol
  review JSON: external launch review, before/after launcher sources, startup
  witness and preserved research-boundary explanations.
- The frozen repository's `scripts/memory_cell_router/validation/` and
  `scripts/memory_cell_population/validation/`: prior router tie/source-support
  validation evidence and read/selection test receipt.
- This helper, its README and template; the completed audit/checkpoint receipt;
  any explicitly supplied additional narrative files.

Actual `.safetensors`, quantized payloads, router `.bin` weights, SQLite/owner
databases and other unlisted binary/cache formats are excluded without reading
their bytes. The exact-data `seed-and-generator.bin` and exact baseline
`.zlib9`/`.lzma6` bytes are kept. The sole allowed ZIP in raw evidence is the
already downloaded 3,355-byte GitHub CI artifact, checked against its known hash.
Every exclusion appears in the manifest; nothing is silently dropped to claim
a better storage result. The separate checkpoint ZIP retains the complete study
tree. Historical auxiliary validation payloads outside the study may remain
excluded, while their original hash-bound receipts and failure logs are kept.

The raw archive is an evidence publication artifact, not a measurement of the
memory system's storage. Its gzip compression ratio must not be reported as the
learned memory's compression advantage.
