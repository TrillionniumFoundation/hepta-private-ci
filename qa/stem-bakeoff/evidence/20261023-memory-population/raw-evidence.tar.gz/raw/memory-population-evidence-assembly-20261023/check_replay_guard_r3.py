"""Synthetic contract checks for the auxiliary assembly replay gate only."""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path


SOURCE = Path(__file__).with_name("assemble_evidence.py")
spec = importlib.util.spec_from_file_location("assembly_replay_guard_r3", SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def fixture():
    expected = {
        "source_head": module.HEAD,
        "archive_sha256": "1" * 64,
        "archive_manifest_sha256": "2" * 64,
        "independent_audit_sha256": "3" * 64,
        "aggregate_sha256": "4" * 64,
        "seed_result_sha256": {str(seed): str(index) * 64
                               for index, seed in enumerate(module.SEEDS, 5)},
        "seed": 1907,
        "variant": "single",
        "checkpoint_manifest_sha256": "8" * 64,
        "router_sha256": "9" * 64,
        "original_route_plan_sha256": "a" * 64,
        "replay_result_sha256": "b" * 64,
    }
    comparison = {"available": True, "all_fields_match": True}
    work = {"additional_fresh_worker_processes": 1, "actual_queries": 1,
            "counted_in_original_study": False}
    replay = {
        **copy.deepcopy(expected),
        "schema": "hepta.population.isolated-relocated-replay.v1",
        "passed": True,
        "all_observed_research_modules_from_pinned_bundle": True,
        "initial_pythonpath_runtime_only": True,
        "archive_and_bundle_unchanged": True,
        "original_repository_import_fallback_used": False,
        "original_experiment_modified": False,
        "answer_correctness_required": False,
        "general_portability_across_platforms_proven": False,
        "reference_comparison": copy.deepcopy(comparison),
        "router_replay": {
            "reference_available": True, "matches_original_frozen_route": True,
            "evidence_bundle_unchanged": True, "route_plan_sha256": "a" * 64,
        },
        "work": copy.deepcopy(work),
    }
    result = {
        "reference_comparison": copy.deepcopy(comparison), "work": copy.deepcopy(work),
        "owner_admitted_before_and_after": True, "evidence_bundle_unchanged": True,
        "original_experiment_replaced": False, "production_accepted": False,
    }
    return replay, expected, result


def main():
    successful = []
    replay, expected, result = fixture()
    module.check_relocated_replay(replay, expected, result)
    successful.append("valid-complete-interface")

    def reject(name, mutation):
        replay, expected, result = fixture()
        mutation(replay, expected, result)
        try:
            module.check_relocated_replay(replay, expected, result)
        except module.AssemblyError:
            successful.append(name)
        else:
            raise AssertionError("unexpected acceptance: " + name)

    for key in expected:
        reject("wrong-binding-" + key,
               lambda replay, expected, result, key=key: replay.__setitem__(key, "unbound"))
    reject("missing-passed", lambda replay, expected, result: replay.pop("passed"))
    reject("false-passed", lambda replay, expected, result: replay.__setitem__("passed", False))
    reject("integer-passed", lambda replay, expected, result: replay.__setitem__("passed", 1))
    reject("incomplete-expected-contract", lambda replay, expected, result: expected.pop("router_sha256"))
    for key in ("all_observed_research_modules_from_pinned_bundle",
                "initial_pythonpath_runtime_only", "archive_and_bundle_unchanged"):
        reject("missing-isolation-" + key,
               lambda replay, expected, result, key=key: replay.__setitem__(key, False))
        reject("integer-isolation-" + key,
               lambda replay, expected, result, key=key: replay.__setitem__(key, 1))
    for key in ("original_repository_import_fallback_used", "original_experiment_modified",
                "answer_correctness_required", "general_portability_across_platforms_proven"):
        reject("invalid-boundary-" + key,
               lambda replay, expected, result, key=key: replay.__setitem__(key, True))
    for key, bad in (("additional_fresh_worker_processes", True),
                     ("additional_fresh_worker_processes", 0), ("actual_queries", True),
                     ("actual_queries", 2), ("counted_in_original_study", True)):
        def mutate(replay, expected, result, key=key, bad=bad):
            replay["work"][key] = result["work"][key] = bad
        reject("invalid-work-" + key + "-" + str(bad), mutate)
    for key in ("available", "all_fields_match"):
        reject("invalid-reference-" + key,
               lambda replay, expected, result, key=key:
               replay["reference_comparison"].__setitem__(key, False))
    for key in ("reference_available", "matches_original_frozen_route", "evidence_bundle_unchanged"):
        reject("invalid-router-" + key,
               lambda replay, expected, result, key=key: replay["router_replay"].__setitem__(key, False))
    reject("router-plan-pin-mismatch", lambda replay, expected, result:
           replay["router_replay"].__setitem__("route_plan_sha256", "c" * 64))
    reject("raw-result-work-mismatch", lambda replay, expected, result:
           result["work"].__setitem__("generated_tokens", 99))
    reject("raw-owner-not-admitted", lambda replay, expected, result:
           result.__setitem__("owner_admitted_before_and_after", False))
    reject("raw-result-replaces-study", lambda replay, expected, result:
           result.__setitem__("original_experiment_replaced", True))
    print(json.dumps({
        "schema": "hepta.population.auxiliary-replay-guard-checks.v1",
        "passed": True, "case_count": len(successful), "cases": successful,
        "helper_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "synthetic_only": True, "original_study_files_read": False,
        "model_loaded": False, "experimental_73_test_count_changed": False,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
