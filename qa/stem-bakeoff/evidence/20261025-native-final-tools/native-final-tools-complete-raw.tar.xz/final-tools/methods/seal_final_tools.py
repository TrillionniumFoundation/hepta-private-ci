"""Seal captured final-tools evidence after independent mechanical review."""
import hashlib
import json
from pathlib import Path
import shutil
import stat
import sys
import tarfile

OUT = Path(__file__).resolve().parent
PAYLOAD = OUT / 'payload'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text())


def rows(root):
    result = {}
    for path in [root, *sorted(root.rglob('*'))]:
        mode = path.lstat().st_mode
        item = {'mode': stat.S_IMODE(mode)}
        if stat.S_ISDIR(mode):
            item['kind'] = 'directory'
        elif stat.S_ISREG(mode):
            item.update(kind='file', bytes=path.stat().st_size, sha256=sha(path))
        else:
            raise ValueError('only plain files and directories admitted to archive')
        result[str(path.relative_to(root))] = item
    return result


def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


review_paths = [Path(value).resolve(strict=True) for value in sys.argv[1:]]
if not review_paths or not any(p.suffix == '.json' for p in review_paths):
    raise ValueError('explicit completed independent review inputs required')
review_directory = PAYLOAD / 'independent-review'
review_directory.mkdir(exist_ok=False)
review_files = []
for path in review_paths:
    before = sha(path)
    destination = review_directory / path.name
    shutil.copy2(path, destination)
    if before != sha(destination) or before != sha(path):
        raise ValueError('independent review changed while copying')
    review_files.append({'path': str(destination.relative_to(PAYLOAD)),
                         'source': str(path), 'sha256': before, 'bytes': path.stat().st_size})
review = read(next(p for p in review_paths if p.suffix == '.json'))
if review['reviewed_base_head'] != '3a1431c5879d084bf49b9df67f9792af8f3acbc7':
    raise ValueError('independent review refers to a different source baseline')
publication = OUT.parent / 'memory-resume-control-20261024/tick-final'
published = read(publication / 'publication-receipt.json')
publication_manifest = read(publication / 'manifest.json')
if published['sha'] != '33c741cb0abe5faac1d92abe5d0ac90bee4abb51':
    raise ValueError('explicit final source publication differs')
for item in publication_manifest['files']:
    path = PAYLOAD / 'source-after-format' / item['path']
    raw = path.read_bytes()
    git_blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    if (sha(path) != item['sha256'] or len(raw) != item['size']
            or git_blob != item['git_blob']
            or stat.S_IMODE(path.lstat().st_mode) != int(item['mode'], 8) & 0o777):
        raise ValueError('published final file differs from captured formatter result')
if len(publication_manifest['files']) != 33:
    raise ValueError('exactly33 published source files required')
(PAYLOAD / 'source-publication').mkdir()
for name in ('publication-receipt.json', 'manifest.json'):
    shutil.copy2(publication / name, PAYLOAD / 'source-publication' / name)
shutil.copy2(Path(__file__), PAYLOAD / 'methods/seal_final_tools.py')
inventory = {'schema': 'hepta.native.final-tools-archive-inventory.v1',
             'excluded_self': 'payload-inventory.json', 'entries': rows(PAYLOAD)}
write(PAYLOAD / 'payload-inventory.json', inventory)
before = rows(PAYLOAD)
archive_path = OUT / 'native-final-tools-complete-raw.tar.xz'
if archive_path.exists():
    raise FileExistsError(archive_path)
with tarfile.open(archive_path, 'w:xz', preset=9) as archive:
    for relative, item in before.items():
        path = PAYLOAD if relative == '.' else PAYLOAD / relative
        info = archive.gettarinfo(str(path), arcname='final-tools' if relative == '.' else 'final-tools/' + relative)
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        info.mtime = 0
        if item['kind'] == 'file':
            with path.open('rb') as stream:
                archive.addfile(info, stream)
        else:
            archive.addfile(info)
actual = {}
with tarfile.open(archive_path) as archive:
    for member in archive.getmembers():
        relative = str(Path(member.name).relative_to('final-tools'))
        if relative in actual:
            raise ValueError('duplicate archive member')
        item = {'mode': member.mode}
        if member.isfile():
            content = archive.extractfile(member).read()
            item.update(kind='file', bytes=len(content), sha256=hashlib.sha256(content).hexdigest())
        elif member.isdir():
            item['kind'] = 'directory'
        else:
            raise ValueError('unexpected archive member type')
        actual[relative] = item
if actual != before or rows(PAYLOAD) != before:
    raise ValueError('archive read-back does not match complete payload')
capture = read(PAYLOAD / 'capture-audit.json')
for entry in capture['captured_inputs']:
    path = Path(entry['source'])
    if (sha(path) != entry['sha256'] or path.stat().st_size != entry['bytes']
            or oct(stat.S_IMODE(path.lstat().st_mode)) != entry['mode']):
        raise ValueError('original captured input changed before seal')
files = {k: v for k, v in before.items() if v['kind'] == 'file'}
manifest = {
    'schema': 'hepta.native.final-tools-evidence.v1',
    'qualified_local_model_source_head': capture['qualified_model_source_head'],
    'original_training_source_head': capture['training_source_head'],
    'published_program_snapshot_head': capture['program_report_snapshot_head'],
    'repository_directory': capture['planned_repository_directory'],
    'archive': {'path': archive_path.name, 'bytes': archive_path.stat().st_size,
                'sha256': sha(archive_path), 'files': len(files),
                'directories': len(before) - len(files), 'uncompressed_file_bytes': sum(v['bytes'] for v in files.values()),
                'all_members_read_back_byte_mode_verified': True},
    'payload_inventory_sha256': sha(PAYLOAD / 'payload-inventory.json'),
    'capture_audit_sha256': sha(PAYLOAD / 'capture-audit.json'),
    'fix': {'exit_code': 0, 'wall_seconds': capture['fix']['wall_seconds'], 'changed_paths': 3,
            'insertions': 5, 'deletions': 6, 'complete_log_bytes': capture['fix']['log_bytes'],
            'zero_warnings_claimed': False},
    'format': {'exit_code': 0, 'wall_seconds': capture['format']['wall_seconds'], 'changed_paths': 32,
               'complete_log_bytes': 0, 'success_output_suppressed_by_formatter_design': True,
               'explicit_base': '429894ac8e0818102cfdea4ad47a56e4583b2902'},
    'combined_patch': {'paths': 33, 'insertions': 2077, 'deletions': 815},
    'source_inventory_entries_before_and_after_each_phase': 9729,
    'fix_to_format_inventory_and_patch_bridge': True,
    'snapshots_verified': {'baseline_git_blobs': 33, 'post_fix_original_files': 3, 'post_format_actual_files': 33},
    'isolated_patch_reconstruction_matches': True,
    'original_bytes_modes_unchanged_by_capture': True,
    'dotslash': {'version': capture['dotslash']['version'], 'archive_included': True,
                 'archive_sha256': capture['dotslash']['archive_sha256'],
                 'actual_installed_binary_sha256': capture['dotslash']['binary_sha256'],
                 'binary_from_archive_matches_installed': True, 'installation_not_reexecuted': True,
                 'install_wall_seconds': None},
    'independent_mechanical_review': review_files,
    'mechanical_review_summary': review['automated_evidence'],
    'critical_source_files_byte_unchanged': len(review['critical_byte_unchanged_files']),
    'published_final_source': {'head': published['sha'], 'tree': published['tree'],
                               'pr': 3828, 'all33_sha256_git_blob_mode_match_capture': True},
    'new_tests_executed': 0, 'new_model_calls': 0, 'new_training_updates': 0,
    'tools_reexecuted_to_make_archive': False,
    'final_exact_commit_ci': {'status': 'pending', 'source_head': published['sha'], 'receipt': None,
                              'run_id_reported_by_root': 40149732280, 'queue_state_at_root_observation': 'queued'},
    'prior_3a_model_execution_requalified_after_source_change': False,
    'full_closure': False, 'complete_research_blockers_closed': 0,
    'complete_research_blockers_total': 8, 'production_accepted': False,
}
write(OUT / 'manifest.json', manifest)
readme = f'''# Final scoped `just fix` / `just fmt`: immutable execution evidence

This package retains two already completed repository tool phases. It does not
rerun tests, models, training, a formatter, or the installer. Root owns publication.

## Actual execution

| Phase | Exit | Wall seconds | Actual changed paths | Retained log |
|---|---:|---:|---:|---:|
| scoped `just fix` | 0 | {capture['fix']['wall_seconds']:.12f} | 3 | {capture['fix']['log_bytes']:,} bytes |
| `just fmt --base 429894ac8e0818102cfdea4ad47a56e4583b2902` | 0 | {capture['format']['wall_seconds']:.12f} | 32 | 0 bytes |

The fix command is retained verbatim in its receipt and wrapper. It uses the six
named crates, `--locked`, examples, and the qualification feature; `cargo clippy
--fix --tests` checks test targets without executing their tests. Its full log
contains warnings. Exit zero is not represented as a zero-warning result.

The formatter deliberately returns an empty buffered output on success, as shown
by the retained `scripts/format.py`. The empty log is preserved with its actual
SHA-256, receipt, source changes, and exit status.

## Source identity and patches

Both phases record HEAD `3a1431c5879d084bf49b9df67f9792af8f3acbc7` and inventories
of 9,729 entries. Entries include file bytes and modes; symlink entries hash link
text. All four original inventories are retained without rewriting.

The three fix edits contain +5/-6 lines. The formatter changes 32 paths, two of
which overlap the fix. The final cumulative diff is 33 files, +2,077/-815 lines.
`format/before-tracked.patch` is byte-identical to `fix/after-tracked.patch`.
The format after-patch is relative to the original HEAD and includes the fix;
it is not mislabeled as a formatter-only patch.

The archive contains the three original post-fix snapshots, all 33 immutable
HEAD blobs, all 33 actual post-format files, logs, receipts, statistics, wrapper,
and formatter/config sources. Each snapshot matches its recorded byte/mode hash.
Both cumulative patches were applied only to isolated evidence copies; all 33
reconstructed files match the corresponding phase inventory. Original captured
inputs remained unchanged in bytes and modes. Read access time is not claimed
unchanged. Archive metadata is normalized; retained raw receipts remain exact.

## Tool identity and independent review

Retain the original DotSlash 0.5.8 archive, install receipt and install script.
Its archive digest is `{capture['dotslash']['archive_sha256']}`; the archive's
binary matches the actual installed binary digest
`{capture['dotslash']['binary_sha256']}`. No installation was repeated.
Installation time was not recorded and remains null. This is not a hermetic
attestation of every transitive formatter/compiler dependency.

The independent mechanical-diff review and its methods are included as original
files under `independent-review/`; their hashes are in the manifest. This review
does not substitute for executing the changed source in the final independent CI.
Six Python ASTs match strictly. All 26 Rust files retain their scoped imports,
cfg and visibility; 23 retain normalized nondeclaration tokens, with three
tail-expression closure-brace changes reviewed explicitly. Trailing commas and
Bazel named-keyword ordering were reviewed. Ninety-five critical source, data,
recipe, control and contract files remain byte-identical. Rust review is lexical
plus targeted manual inspection, not compiler execution or a formal AST proof.

## Qualification boundary

The actual local v1/v2 model success belongs to source head
`3a1431c5879d084bf49b9df67f9792af8f3acbc7`; its reused 96-update training belongs
to `8a47cdd26574a85cd314fabce65cc395dbe316a8`. Those runs preceded these edits.
The [immutable program status snapshot](https://github.com/TrillionniumFoundation/hepta-private-ci/tree/f92ddcacbe21267514f5040c1df6c380a96f0643/qa/stem-bakeoff/evidence/20261025-memory-program-status)
preserves that distinction. Formatting success does not requalify model execution
on the changed source. The final exact-source CI remains **pending** in this
package and will be reported separately. No local tests were rerun after fix/fmt.
The final source was published as [PR3828](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/3828),
head `{published['sha']}`. Its 33 file SHA-256, Git blob and mode identities match
the captured post-format bytes. Root observed [CI run40149732280](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/40149732280)
queued; this package contains no completed CI receipt and makes no CI-pass claim.
Python formatting changes byte-based runtime pins, so final execution must
register its current runtime digest rather than reuse the old successful pins.

All eight complete research blockers remain open; production acceptance is false.

## Archive

`{archive_path.name}`: **{archive_path.stat().st_size:,} bytes**,
**{len(files)} regular files / {len(before) - len(files)} directories**.

SHA-256: `{sha(archive_path)}`.

Every archive member was read back and compared against the complete payload,
including exact bytes and modes. `payload-inventory.json` inside the archive
lists every other member; its own digest is retained in the external manifest.
The capture and sealing scripts are retained for review and reproduction.
'''
with (OUT / 'README.md').open('x') as stream:
    stream.write(readme)
print(json.dumps({'archive': manifest['archive'], 'manifest_sha256': sha(OUT / 'manifest.json'),
                  'readme_sha256': sha(OUT / 'README.md'),
                  'publication_text_lines': len(readme.splitlines()) + len((OUT / 'manifest.json').read_text().splitlines())}))
