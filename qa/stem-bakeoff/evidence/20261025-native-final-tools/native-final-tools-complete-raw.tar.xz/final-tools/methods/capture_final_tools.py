"""Capture already completed tool receipts; never execute fix/fmt/tests/models."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tarfile
import tempfile

ROOT = Path('/workspace/scratch/12ef9c5bdc23')
REPO = ROOT / 'hepta-memory-resume-20261024'
CONTROL = ROOT / 'memory-resume-control-20261024'
OUT = ROOT / 'final-tools-qualification-20261025'
PAYLOAD = OUT / 'payload'
HEAD = '3a1431c5879d084bf49b9df67f9792af8f3acbc7'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text())


def row(path):
    s = path.lstat()
    if not stat.S_ISREG(s.st_mode):
        raise ValueError(f'bounded regular capture input required: {path}')
    return {'sha256': sha(path), 'bytes': s.st_size, 'mode': oct(stat.S_IMODE(s.st_mode))}


def retain(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = value if isinstance(value, bytes) else (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)


def source_row(path):
    return {**row(path), 'kind': 'regular-file'}


def patch_counts(path):
    files = set()
    added = deleted = 0
    for line in path.read_text().splitlines():
        if line.startswith('diff --git a/'):
            before, after = line[13:].split(' b/', 1)
            if before != after or Path(before).is_absolute() or '..' in Path(before).parts:
                raise ValueError('closed unchanged-path patch required')
            files.add(before)
        elif line.startswith('+') and not line.startswith('+++ '):
            added += 1
        elif line.startswith('-') and not line.startswith('--- '):
            deleted += 1
    return {'files': sorted(files), 'insertions': added, 'deletions': deleted}


PAYLOAD.mkdir(parents=True, exist_ok=False)
copied_inputs = []


def copy(source, relative):
    before = row(source)
    target = PAYLOAD / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    if row(source) != before or row(target) != before:
        raise ValueError('capture changed input or destination bytes/mode')
    copied_inputs.append({'source': str(source), 'destination': str(relative), **before})


for phase in ('fix', 'format'):
    source = CONTROL / f'native-final-{phase}-001'
    for path in sorted(source.rglob('*')):
        if path.is_file():
            copy(path, Path('raw') / source.name / path.relative_to(source))
copy(CONTROL / 'run_native_final_tools.py', Path('methods/run_native_final_tools.py'))
copy(CONTROL / 'install_dotslash.py', Path('methods/install_dotslash.py'))
tools_root = Path('/tmp/hepta-memory-resume-tools')
for name in ('dotslash-install-receipt.json', 'dotslash-v0.5.8.tar.gz'):
    copy(tools_root / name, Path('toolchain') / name)
installation = read(tools_root / 'dotslash-install-receipt.json')
if (row(tools_root / 'dotslash-v0.5.8.tar.gz')['sha256'] != installation['archive_sha256']
        or row(tools_root / 'dotslash-v0.5.8.tar.gz')['bytes'] != installation['archive_bytes']
        or row(tools_root / 'bin/dotslash')['sha256'] != installation['binary_sha256']
        or row(tools_root / 'bin/dotslash')['bytes'] != installation['binary_bytes']):
    raise ValueError('actual installed DotSlash bytes differ from retained pin')
with tarfile.open(tools_root / 'dotslash-v0.5.8.tar.gz') as archive:
    members = [m for m in archive.getmembers() if m.isfile()]
    if len(members) != 1:
        raise ValueError('one pinned tool binary required')
    if hashlib.sha256(archive.extractfile(members[0]).read()).hexdigest() != installation['binary_sha256']:
        raise ValueError('pinned archive binary differs from actual installed tool')

fix = CONTROL / 'native-final-fix-001'
fmt = CONTROL / 'native-final-format-001'
fix_before, fix_after = read(fix / 'source-before.json'), read(fix / 'source-after.json')
fmt_before, fmt_after = read(fmt / 'source-before.json'), read(fmt / 'source-after.json')
fix_receipt, fmt_receipt = read(fix / 'receipt.json'), read(fmt / 'receipt.json')
if fix_after != fmt_before or (fix / 'after-tracked.patch').read_bytes() != (fmt / 'before-tracked.patch').read_bytes():
    raise ValueError('fix-to-format immutable source/patch bridge differs')
if (fix / 'before-tracked.patch').stat().st_size != 0:
    raise ValueError('tool run must begin at clean tracked baseline')
changes = {}
for label, before, after, receipt, log in [
        ('fix', fix_before, fix_after, fix_receipt, fix / 'fix.log'),
        ('format', fmt_before, fmt_after, fmt_receipt, fmt / 'format.log')]:
    actual = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
    if (actual != receipt['changed_paths'] or receipt['exit_code'] != 0
            or receipt['base_head'] != HEAD or receipt['native_model_calls'] != 0
            or receipt['tests_executed'] != 0 or sha(log) != receipt['log_sha256']
            or len(before) != 9729 or len(after) != 9729):
        raise ValueError(f'{label} raw receipt or source identity mismatch')
    changes[label] = actual
all_changed = sorted(set(changes['fix']) | set(changes['format']))
if len(changes['fix']) != 3 or len(changes['format']) != 32 or len(all_changed) != 33:
    raise ValueError('observed changed-path cardinality differs')
fix_counts = patch_counts(fix / 'after-tracked.patch')
final_counts = patch_counts(fmt / 'after-tracked.patch')
if (fix_counts != {'files': changes['fix'], 'insertions': 5, 'deletions': 6}
        or final_counts != {'files': all_changed, 'insertions': 2077, 'deletions': 815}):
    raise ValueError('retained actual patch totals differ')

for name in all_changed:
    content = subprocess.check_output(['git', 'show', f'{HEAD}:{name}'], cwd=REPO)
    before_path = PAYLOAD / 'source-before' / name
    retain(before_path, content)
    before_path.chmod(int(fix_before[name]['mode'], 8))
    if source_row(before_path) != fix_before[name]:
        raise ValueError('immutable Git baseline differs from pre-fix inventory')
    copy(REPO / name, Path('source-after-format') / name)
    if source_row(PAYLOAD / 'source-after-format' / name) != fmt_after[name]:
        raise ValueError('actual formatted source differs from recorded final inventory')
for name in changes['fix']:
    snapshot = fix / 'changed-files' / name
    if source_row(snapshot) != fix_after[name]:
        raise ValueError('post-fix snapshot differs from fixed-source identity')

for name in ('justfile', 'scripts/format.py', 'tools/buildifier', 'scripts/pyproject.toml', 'scripts/uv.lock'):
    copy(REPO / name, Path('source-context') / name)
    if source_row(PAYLOAD / 'source-context' / name) != fix_before[name] or fix_before[name] != fmt_after[name]:
        raise ValueError('formatter dispatch/config source changed or differs')

patch_reconstruction = {}
for label, patch, expected in [('post-fix', fix / 'after-tracked.patch', fix_after),
                               ('post-format', fmt / 'after-tracked.patch', fmt_after)]:
    with tempfile.TemporaryDirectory(prefix='hepta-final-patch-audit-', dir=OUT) as scratch:
        scratch = Path(scratch)
        shutil.copytree(PAYLOAD / 'source-before', scratch, dirs_exist_ok=True)
        completed = subprocess.run(['git', 'apply', str(patch)], cwd=scratch, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if completed.returncode != 0:
            raise ValueError(completed.stderr.decode())
        for name in all_changed:
            if source_row(scratch / name) != expected[name]:
                raise ValueError('patch reconstruction differs from retained inventory')
        patch_reconstruction[label] = {'applied_to_isolated_copy_only': True, 'files_checked': len(all_changed), 'exact_bytes_modes_match': True}

copy(Path(__file__), Path('methods/capture_final_tools.py'))
for entry in copied_inputs:
    if row(Path(entry['source'])) != {k: entry[k] for k in ('sha256', 'bytes', 'mode')}:
        raise ValueError('capture input changed during collection')
audit = {
    'schema': 'hepta.native.final-tools-capture.v1', 'qualified_model_source_head': HEAD,
    'training_source_head': '8a47cdd26574a85cd314fabce65cc395dbe316a8',
    'program_report_snapshot_head': 'f92ddcacbe21267514f5040c1df6c380a96f0643',
    'planned_repository_directory': 'qa/stem-bakeoff/evidence/20261025-native-final-tools',
    'fix': {'exit_code': 0, 'wall_seconds': fix_receipt['wall_seconds'], 'changed_paths': changes['fix'], 'patch_totals': fix_counts, 'log_bytes': (fix / 'fix.log').stat().st_size},
    'format': {'exit_code': 0, 'wall_seconds': fmt_receipt['wall_seconds'], 'changed_paths': changes['format'], 'log_bytes': 0, 'successful_formatter_output_suppressed_by_source': True},
    'combined': final_counts, 'fix_to_format_inventory_bridge': True,
    'inventory_files_per_phase': 9729, 'post_fix_snapshots_verified': 3,
    'post_format_snapshots_verified': len(all_changed), 'baseline_git_blobs_verified': len(all_changed),
    'patch_reconstruction': patch_reconstruction, 'input_bytes_modes_unchanged': True,
    'metadata_scope': 'ordinary file bytes and mode checked; access time not preserved or claimed',
    'dotslash': installation, 'captured_inputs': copied_inputs,
    'new_tests_executed': 0, 'new_model_calls': 0, 'new_training_updates': 0,
    'fix_or_formatter_reexecuted_by_capture': False, 'new_source_qualified_by_prior_model_run': False,
    'final_exact_source_ci': {'status': 'pending', 'receipt': None, 'qualified': False},
    'all_eight_full_closure': False, 'production_accepted': False,
    'bounds': ['Exit zero does not mean zero warnings; the complete Clippy log is retained.',
               'Formatting selected changes relative to the explicitly recorded --base commit.',
               'Git apply was used only on an isolated evidence copy to compare patches; no tests/models/formatters were rerun.',
               'Final mechanical diff review will be added separately; neither it nor these tools requalifies model execution on the changed source.']}
retain(PAYLOAD / 'capture-audit.json', audit)
print(json.dumps({'payload': str(PAYLOAD), 'capture_audit_sha256': sha(PAYLOAD / 'capture-audit.json'),
                  'files': len([p for p in PAYLOAD.rglob('*') if p.is_file()]),
                  'input_files_copied': len(copied_inputs), 'changed_source_files': len(all_changed),
                  'actual_new_model_calls': 0, 'actual_new_tests': 0}))
