import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


ROOT = Path('/workspace/scratch/12ef9c5bdc23')
REPO = ROOT / 'hepta-memory-resume-20261024'
phase = sys.argv[1]
if phase not in {'fix', 'format'}:
    raise SystemExit('phase must be fix or format')
OUT = ROOT / 'memory-resume-control-20261024' / f'native-final-{phase}-001'
OUT.mkdir(exist_ok=False)
commands = {
    'fix': ['just', 'fix', '--locked', '-p', 'codex-arg0', '-p', 'codex-hepta-memory', '-p', 'codex-hepta-agent-protocol', '-p', 'codex-hepta-agentd', '-p', 'codex-hepta-neuron', '-p', 'codex-hepta-cognitive-store', '--features', 'codex-hepta-agentd/qualification-cognitive-write', '--examples'],
    'format': ['just', 'fmt', '--base', '429894ac8e0818102cfdea4ad47a56e4583b2902'],
}
env = dict(os.environ)
env.update(PATH='/tmp/hepta-memory-resume-tools/bin:/tmp/hepta-memory-resume-cargo/bin:' + env['PATH'], RUSTUP_HOME='/tmp/hepta-memory-resume-rustup', CARGO_HOME='/tmp/hepta-memory-resume-cargo', CARGO_TARGET_DIR='/tmp/hepta-memory-resume-target', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1', OPENSSL_DIR='/usr', OPENSSL_LIB_DIR='/usr/lib/x86_64-linux-gnu', OPENSSL_INCLUDE_DIR='/usr/include', PYTHONDONTWRITEBYTECODE='1', UV_CACHE_DIR='/tmp/hepta-memory-resume-uv-cache', DOTSLASH_CACHE='/tmp/hepta-memory-resume-dotslash-cache')


def inventory():
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=REPO).split(b'\0')
    result = {}
    for item in paths:
        if not item:
            continue
        path = REPO / item.decode()
        if path.is_symlink():
            content = os.readlink(path).encode()
            kind = 'symlink-text'
        elif path.is_file():
            content = path.read_bytes()
            kind = 'regular-file'
        else:
            continue
        result[item.decode()] = {'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content), 'mode': oct(path.lstat().st_mode & 0o777), 'kind': kind}
    return result


before = inventory()
(OUT / 'source-before.json').write_text(json.dumps(before, sort_keys=True) + '\n')
receipt = {'command': commands[phase], 'cwd': str(REPO / 'codex-rs'), 'started_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(), 'native_model_calls': 0, 'tests_executed': 0, 'tests_were_completed_before_this_phase': True, 'inventory_semantics': 'regular bytes plus symlink link-text, modes included', 'exit_code': None}
with (OUT / 'before-tracked.patch').open('wb') as stream:
    subprocess.run(['git', 'diff', '--binary'], cwd=REPO, stdout=stream, check=True)
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'phase': phase, 'started_utc': receipt['started_utc'], 'out': str(OUT), 'files_before': len(before)}), flush=True)
started = time.monotonic()
with (OUT / f'{phase}.log').open('wb') as log:
    process = subprocess.Popen(commands[phase], cwd=REPO / 'codex-rs', env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt['pid'] = process.pid
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    code = process.wait()
receipt.update(exit_code=code, wall_seconds=time.monotonic()-started, completed_utc=datetime.datetime.now(datetime.UTC).isoformat())
after = inventory()
receipt['files_before'] = len(before)
receipt['files_after'] = len(after)
receipt['changed_paths'] = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
receipt['log_sha256'] = hashlib.sha256((OUT / f'{phase}.log').read_bytes()).hexdigest()
with (OUT / 'after-tracked.patch').open('wb') as stream:
    subprocess.run(['git', 'diff', '--binary'], cwd=REPO, stdout=stream, check=True)
with (OUT / 'after-tracked.stat').open('wb') as stream:
    subprocess.run(['git', 'diff', '--stat'], cwd=REPO, stdout=stream, check=True)
(OUT / 'source-after.json').write_text(json.dumps(after, sort_keys=True) + '\n')
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(code)
