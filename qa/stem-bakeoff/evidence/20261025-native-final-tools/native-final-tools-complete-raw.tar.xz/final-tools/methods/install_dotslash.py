import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import urllib.request


url = "https://github.com/facebook/dotslash/releases/download/v0.5.8/dotslash-ubuntu-22.04.x86_64.tar.gz"
expected = "3905bd406a0b4cc5fbe69843dca96fc7937fed6109164a6d56335fbf61187120"
root = Path("/tmp/hepta-memory-resume-tools")
archive = root / "dotslash-v0.5.8.tar.gz"
assert not archive.exists()
request = urllib.request.Request(url, headers={"User-Agent": "hepta-memory-native-qualification/1"})
with urllib.request.urlopen(request, timeout=120) as response:
    data = response.read(2_000_000)
assert len(data) == 773032
assert hashlib.sha256(data).hexdigest() == expected
archive.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tar:
    files = [member for member in tar.getmembers() if member.isfile()]
    assert len(files) == 1 and Path(files[0].name).name == "dotslash"
    binary = tar.extractfile(files[0]).read()
target = root / "bin/dotslash"
assert not target.exists()
target.write_bytes(binary)
target.chmod(0o755)
version = subprocess.check_output([str(target), "--version"], text=True).strip()
receipt = {"url": url, "release_metadata_source": "https://api.github.com/repos/facebook/dotslash/releases/tags/v0.5.8", "archive_sha256": expected, "archive_bytes": len(data), "binary_sha256": hashlib.sha256(binary).hexdigest(), "binary_bytes": len(binary), "version": version}
(root / "dotslash-install-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
