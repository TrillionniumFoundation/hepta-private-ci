"""Static review only. No Cargo, tests, formatter, models, or primary edits."""
from pathlib import Path
import ast
from collections import Counter
import difflib
import hashlib
import json
import re
import subprocess

ROOT = Path('/workspace/scratch/12ef9c5bdc23')
REPO = ROOT / 'hepta-memory-resume-20261024'
CONTROL = ROOT / 'memory-resume-control-20261024'
FIX = CONTROL / 'native-final-fix-001'
FMT = CONTROL / 'native-final-format-001'
HEAD = '3a1431c5879d084bf49b9df67f9792af8f3acbc7'
def read(p): return json.loads(p.read_text())
def sha(b): return hashlib.sha256(b).hexdigest()

def tokens(text):
    """Keep every literal/operator; discard only whitespace and comments."""
    out=[]; i=0
    while i<len(text):
        if text[i].isspace(): i+=1; continue
        if text.startswith('//',i):
            end=text.find('\n',i); i=len(text) if end<0 else end; continue
        if text.startswith('/*',i):
            depth=1; i+=2
            while depth:
                if text.startswith('/*',i): depth+=1; i+=2
                elif text.startswith('*/',i): depth-=1; i+=2
                else: i+=1
                if i>len(text): raise ValueError('unterminated comment')
            continue
        raw=re.match(r'(?:br|cr|r)(#*)"',text[i:])
        if raw:
            stop='"'+raw.group(1); end=text.find(stop,i+raw.end())
            if end<0: raise ValueError('unterminated raw string')
            end+=len(stop);out.append(text[i:end]);i=end;continue
        literal=re.match(r'(?:b|c)?"',text[i:])
        if literal:
            end=i+literal.end()
            while end<len(text):
                if text[end]=='\\':end+=2;continue
                if text[end]=='"':end+=1;break
                end+=1
            out.append(text[i:end]);i=end;continue
        char=re.match(r"(?:b)?'(?:[^'\\\n]|\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.))'",text[i:])
        if char:out.append(char[0]);i+=len(char[0]);continue
        word=re.match(r'(?:r#)?[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9]*(?:\.[0-9][A-Za-z_0-9]*)?',text[i:])
        if word:out.append(word[0]);i+=len(word[0]);continue
        op=next((op for op in ('<<=','>>=','..=','...','::','->','=>','==','!=','<=','>=','&&','||','+=','-=','*=','/=','%=','&=','|=','^=','<<','>>','..') if text.startswith(op,i)),text[i])
        out.append(op);i+=len(op)
    return out

def matching(ts,start):
    pairs={'(':')','[':']','{':'}'};stack=[pairs[ts[start]]]
    for i in range(start+1,len(ts)):
        if ts[i] in pairs:stack.append(pairs[ts[i]])
        elif ts[i] in pairs.values():
            assert stack and ts[i]==stack.pop()
            if not stack:return i
    raise ValueError('unclosed delimiters')

def use_leaves(ts):
    if '{' not in ts:
        if 'self' in ts and ts.index('self')>0:
            k=ts.index('self')
            if ts[k-1]=='::':ts=ts[:k-1]+ts[k+1:]
        return [tuple(ts)]
    start=ts.index('{');end=matching(ts,start);assert end==len(ts)-1
    prefix=ts[:start]; inner=ts[start+1:end]; leaves=[];begin=depth=0
    for i,t in enumerate(inner+[',']):
        if t=='{':depth+=1
        elif t=='}':depth-=1
        elif t==',' and depth==0:
            if i>begin:leaves+=use_leaves(prefix+inner[begin:i])
            begin=i+1
    return leaves

def strip_declarations(ts):
    """Compare expanded use leaves/module declarations within the same brace scope.

    Attribute and visibility tokens remain attached to every expanded leaf.
    All other token order is preserved.
    """
    out=[]; declarations=[];scope=[];brace=0;i=0
    while i<len(ts):
        j=i;attrs=[];visibility=[]
        while j+1<len(ts) and ts[j]=='#' and ts[j+1]=='[':
            end=matching(ts,j+1);attrs+=ts[j:end+1];j=end+1
        if j<len(ts) and ts[j]=='pub':
            visibility.append('pub');j+=1
            if j<len(ts) and ts[j]=='(':
                end=matching(ts,j);visibility+=ts[j:end+1];j=end+1
        if j<len(ts) and ts[j]=='use':
            end=j+1
            while ts[end]!=';':end+=1
            for leaf in use_leaves(ts[j+1:end]):
                declarations.append((tuple(scope),'use',tuple(attrs),tuple(visibility),leaf))
            i=end+1;continue
        if j+2<len(ts) and ts[j]=='mod' and ts[j+2]==';':
            declarations.append((tuple(scope),'mod',tuple(attrs),tuple(visibility),(ts[j+1],)))
            i=j+3;continue
        t=ts[i];out.append(t)
        if t=='{':brace+=1;scope.append(brace)
        elif t=='}':scope.pop()
        i+=1
    assert not scope
    return out,Counter(declarations)

def no_trailing_commas(ts):
    return [t for i,t in enumerate(ts) if not(t==',' and i+1<len(ts) and ts[i+1] in (')',']','}'))]

def comma_context(ts,index):
    assert ts[index]==',' and ts[index+1] in (')',']','}')
    stack=[];pairs={'(':')','[':']','{':'}'}
    for i,t in enumerate(ts[:index]):
        if t in pairs:stack.append(i)
        elif t in pairs.values():
            assert pairs[ts[stack[-1]]]==t;stack.pop()
    opening=stack[-1];delimiter=ts[opening]
    if delimiter in ('[','{'):return 'trailing array/struct/enum/match comma'
    assert delimiter=='('
    depth=0;commas=0
    for t in ts[opening+1:index]:
        if t in pairs:depth+=1
        elif t in pairs.values():depth-=1
        elif t==',' and depth==0:commas+=1
    previous=ts[opening-1] if opening else ''
    if commas:return 'trailing call/tuple with at least two elements'
    if re.fullmatch(r'(?:r#)?[A-Za-z_][A-Za-z_0-9]*',previous) or previous in (')',']','>','>>','!'):
        return 'trailing function/method/macro/variant argument'
    raise AssertionError(('possible single-element tuple semantics',ts[max(0,opening-6):index+2]))

class SortBazelKeywords(ast.NodeTransformer):
    def visit_Call(self,node):
        self.generic_visit(node)
        assert all(k.arg is not None for k in node.keywords)
        node.keywords.sort(key=lambda k:k.arg)
        return node

fix_before=read(FIX/'source-before.json');fix_after=read(FIX/'source-after.json')
fmt_before=read(FMT/'source-before.json');fmt_after=read(FMT/'source-after.json')
assert fix_after==fmt_before
assert set(fix_before)==set(fix_after)==set(fmt_after)
fix_paths=sorted(p for p in fix_before if fix_before[p]!=fix_after[p])
fmt_paths=sorted(p for p in fmt_before if fmt_before[p]!=fmt_after[p])
assert fix_paths==sorted(read(FIX/'receipt.json')['changed_paths'])
assert fmt_paths==sorted(read(FMT/'receipt.json')['changed_paths'])
paths=sorted(set(fix_paths+fmt_paths))
git_paths=subprocess.check_output(['git','diff','--name-only',HEAD],cwd=REPO,text=True).splitlines()
assert paths==sorted(git_paths)
assert len(paths)==33 and len(fmt_paths)==32 and len(fix_paths)==3
rows=[];comma_deltas=[];unexplained=[]
for name in paths:
    original=subprocess.check_output(['git','show',f'{HEAD}:{name}'],cwd=REPO)
    postfix=(FIX/'changed-files'/name).read_bytes() if name in fix_paths else original
    final=(REPO/name).read_bytes()
    assert sha(original)==fix_before[name]['sha256']
    assert sha(postfix)==fix_after[name]['sha256']
    assert sha(final)==fmt_after[name]['sha256']
    assert fix_before[name]['mode']==fix_after[name]['mode']==fmt_after[name]['mode']
    row={'path':name,'base_sha256':sha(original),'post_fix_sha256':sha(postfix),'final_sha256':sha(final),'final_bytes':len(final),'fix_changed':name in fix_paths,'format_changed':name in fmt_paths}
    if name.endswith('.py'):
        old=ast.dump(ast.parse(postfix),include_attributes=False);new=ast.dump(ast.parse(final),include_attributes=False)
        row['automated']='Python AST equality with no normalization';row['equivalent']=old==new
    elif name.endswith('.bazel'):
        old=ast.dump(SortBazelKeywords().visit(ast.parse(postfix)),include_attributes=False)
        new=ast.dump(SortBazelKeywords().visit(ast.parse(final)),include_attributes=False)
        row['automated']='Bazel Python-compatible AST equality after sorting named call keywords only';row['equivalent']=old==new
    elif name.endswith('.rs'):
        old_ts=tokens(postfix.decode());new_ts=tokens(final.decode())
        old_body,old_decl=strip_declarations(old_ts);new_body,new_decl=strip_declarations(new_ts)
        row['tokens_before']=len(old_ts);row['tokens_after']=len(new_ts)
        row['declarations_with_scope_attributes_visibility_identical']=old_decl==new_decl
        row['nondeclaration_tokens_identical_except_trailing_commas']=no_trailing_commas(old_body)==no_trailing_commas(new_body)
        row['automated']='literal-preserving Rust lexical comparison, expanded use/module declarations per brace scope and attached attributes/visibility; trailing commas handled separately'
        row['equivalent']=old_decl==new_decl and row['nondeclaration_tokens_identical_except_trailing_commas']
        changes=[]
        for tag,a,b,c,d in difflib.SequenceMatcher(a=old_body,b=new_body,autojunk=False).get_opcodes():
            if tag=='equal':continue
            change={'before':old_body[a:b],'after':new_body[c:d],
                    'before_context':' '.join(old_body[max(0,a-12):min(len(old_body),b+8)]),
                    'after_context':' '.join(new_body[max(0,c-12):min(len(new_body),d+8)])}
            if change['before']==[] and change['after']==[',']:
                change['classification']=comma_context(new_body,c)
            if change['before']==[','] and change['after']==[]:
                change['classification']=comma_context(old_body,a)
            changes.append(change)
        row['nondeclaration_edit_count']=len(changes)
        comma_deltas.extend({'path':name,**change} for change in changes)
        if not row['equivalent']:
            unexplained.append({'path':name,'declarations_missing':[str(v) for v in (old_decl-new_decl)],'declarations_added':[str(v) for v in (new_decl-old_decl)],'changes':changes})
    else:raise ValueError(name)
    rows.append(row)

result={'source_head':HEAD,'phase_counts':{'fix':len(fix_paths),'format':len(fmt_paths),'combined':len(paths)},
        'inventory_transition_matches':True,'paths':rows,'nondeclaration_deltas':comma_deltas,'unexplained':unexplained}
output=ROOT/'tick-shadow-recovery-20261024/final-mechanical-analysis-intermediate.json'
output.write_text(json.dumps(result,indent=2)+'\n')
closure_explanations={
    'codex-rs/hepta-agentd/examples/native_memory_shadow_support/evidence.rs':
        'OpenOptions fluent expression closure now has braces and retains the same tail expression; no semicolon, statement, capture, argument or open mode changed.',
    'codex-rs/hepta-agentd/src/native_memory_shadow_namespace.rs':
        'ok_or_else closure still lazily constructs exactly the same missing-independent-witness rejection; braces enclose the same tail expression.',
    'codex-rs/hepta-agentd/src/native_memory_shadow_namespace_tests.rs':
        'Test file-open closure now has braces; same fluent call and unwrap remain its tail expression.',
}
assert set(v['path'] for v in unexplained)==set(closure_explanations)
for row in unexplained:
    assert not row['declarations_missing'] and not row['declarations_added']
    other=[c for c in row['changes'] if c['after']!=[',']]
    assert len(other)==2 and other[0]['before']==other[1]['before']==[]
    assert other[0]['after']==['{'] and other[1]['after']==['}']
    assert '| {' in other[0]['after_context']
    row['manual_resolution']=closure_explanations[row['path']]
for c in comma_deltas:
    assert (c['before']==[] and c['after'] in ([','],['{'],['}'])) or (c['before']==[','] and c['after']==[])
    if c['after']==[','] or c['before']==[',']:assert 'classification' in c

critical_names=[
    'scripts/memory_cell_native/native_controls.py', 'scripts/memory_cell_native/native_trial.py',
    'scripts/memory_cell_native/native_ci.py', 'scripts/memory_cell_native/native_ci_support.py',
    'scripts/memory_cell_native/native_backend.py', 'scripts/memory_cell_network/model_child.py',
    'codex-rs/hepta-agentd/examples/native_memory_support/mod.rs',
    '.github/workflows/hepta-native-memory.yml', 'codex-rs/Cargo.toml', 'codex-rs/Cargo.lock',
    'codex-rs/rust-toolchain.toml',
]
prefixes=('scripts/memory_cell_native/fixtures/','scripts/memory_cell/','codex-rs/hepta-contracts/','codex-rs/hepta-cognitive-types/')
critical_names=sorted(set(critical_names+[p for p in fix_before if p.startswith(prefixes)]))
assert all(fix_before[p]==fmt_after[p] for p in critical_names)
protocol='codex-rs/hepta-agent-protocol/src/lib.rs'
protocol_old=subprocess.check_output(['git','show',f'{HEAD}:{protocol}'],cwd=REPO)
assert protocol_old.split(b'#[cfg(test)]',1)[0]==(REPO/protocol).read_bytes().split(b'#[cfg(test)]',1)[0]
fix_receipt=read(FIX/'receipt.json');fmt_receipt=read(FMT/'receipt.json')
assert sha((FIX/'fix.log').read_bytes())==fix_receipt['log_sha256']
assert sha((FMT/'format.log').read_bytes())==fmt_receipt['log_sha256']
assert fix_receipt['exit_code']==fmt_receipt['exit_code']==0
assert fix_receipt['tests_executed']==fmt_receipt['tests_executed']==0
assert fix_receipt['native_model_calls']==fmt_receipt['native_model_calls']==0

manual_fix=[
    {'path':'codex-rs/hepta-agentd/src/native_memory.rs','change':'two nested if-let conditions collapsed into an ordered let-chain','assessment':'same lock acquisition, same conditional job lookup only after lock success, same result assignment/refusal and lock release before drop(permit); no admission, source, cancellation or execution gate edited'},
    {'path':protocol,'change':'two redundant clone calls removed inside cfg(test)','assessment':'snapshot.plan and snapshot.run_id are moved at their final uses; same fixture payload values and assertions. Production prefix before cfg(test) is byte-identical'},
    {'path':'codex-rs/hepta-neuron/src/cell_head_tests.rs','change':'weights.clone() changed to weights at final use','assessment':'same Vec value goes into the generation-mismatch test; later checks retain bias and create independent narrow_weights; assertions and tested failure variants unchanged'},
]
records=[FIX/'receipt.json',FIX/'after-tracked.patch',FIX/'fix.log',FMT/'receipt.json',FMT/'after-tracked.patch',FMT/'format.log',FIX/'source-before.json',FIX/'source-after.json',FMT/'source-before.json',FMT/'source-after.json']
review={'schema':'hepta.memory-cell.final-mechanical-independent-review.v1',
    'reviewer':'/root/tick_shadow_recovery','reviewed_base_head':HEAD,
    'verdict':'approved as mechanical source changes with explicitly reviewed Clippy ownership/condition simplifications; no detected change to recipe, gates, typed contracts or data',
    'inventory':{'tracked_entries_before_and_after':len(fix_before),'fix_changed_files':3,'format_changed_files':32,'combined_changed_files':33,'interphase_inventory_exact_match':True,'changed_files_match_git_diff':True,'all_changed_file_modes_unchanged':True,'all_current_final_hashes_match_retained_format_inventory':True},
    'automated_evidence':{'python_AST_strictly_equal_files':6,'rust_files_reviewed':26,
        'rust_same_scope_import_module_attribute_visibility_expansion_equal_files':26,
        'rust_nondeclaration_token_sequence_equal_after_trailing_comma_normalization':23,
        'rust_files_requiring_manual_tail_expression_closure_brace_review':3,
        'safe_trailing_comma_additions':sum(c['after']==[','] for c in comma_deltas),
        'safe_trailing_comma_removals':sum(c['before']==[','] for c in comma_deltas),
        'single_element_tuple_change_candidates':0,
        'bazel_AST_equal_after_named_keyword_order_normalization':1,
        'other_Rust_nondeclaration_token_edits_in_format_phase':0},
    'manual_evidence':{'Clippy_fix':manual_fix,'rustfmt_closure_braces':closure_explanations,
        'Rust_module_and_use_order':'only item import expansion/reordering and external mod sorting, with every scope/cfg/path/visibility retained; reviewed moved declarations have no macro_use attribute and no macro-order dependency introduced',
        'Bazel_keyword_order':'only unit_test_dependency_replacements, crate and crate_features move relative to test data attributes; moved values are constants/names/lists, source labels, dependency sets and list order unchanged'},
    'critical_byte_unchanged_files':{name:fmt_after[name] for name in critical_names},
    'changed_files':rows,'reviewed_trailing_comma_and_closure_deltas':comma_deltas,
    'phase_receipts':{'fix':fix_receipt,'format':fmt_receipt},
    'evidence_records':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in records],
    'qualification_boundary':{'Rust_or_model_execution_by_reviewer':False,'tests_after_fix_or_fmt':False,
        'current_final_source_executed_as_model_qualification':False,
        'actual_model_qualification_source_head':HEAD,
        'source_byte_runtime_digest_notice':'Formatting Python source necessarily changes byte-based runtime_digest. The hashing policy and AST are unchanged; retained successful model receipts continue to bind their pre-format 3a143 source archive and pins. Future execution must register final source pins, not reuse old runtime pins.',
        'method_limit':'Rust analysis is lexical plus targeted manual semantic review, not compiler execution or a formal Rust AST proof. Python AST comparison ignores source locations; Bazel comparison ignores named-keyword order only.'},
    'review_operations':{'primary_writes':0,'tests':0,'Cargo_commands':0,'format_commands':0,'model_imports_or_runs':0,'remote_writes':0},
}
final=ROOT/'tick-shadow-recovery-20261024/final-mechanical-review-001.json'
final.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'path':str(final),'bytes':final.stat().st_size,'sha256':sha(final.read_bytes()),'combined_files':len(paths),'automated_evidence':review['automated_evidence'],'critical_unchanged_count':len(critical_names)},indent=2))
