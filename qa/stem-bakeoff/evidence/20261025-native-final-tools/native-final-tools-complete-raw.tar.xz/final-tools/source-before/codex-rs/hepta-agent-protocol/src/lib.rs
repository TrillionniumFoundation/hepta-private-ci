//! Bounded local control protocol shared by one Hepta agent daemon and its supervisor.

#![forbid(unsafe_code)]

mod authbus;
mod capabilities;
mod evidence;
mod memory_cell;
pub use authbus::AuthBusObjectiveBody;
pub use authbus::AuthBusObjectiveIngress;
pub use authbus::AuthBusTextBody;
pub use authbus::AuthBusTextIngress;
pub use authbus::AuthBusTextState;
pub use authbus::AuthBusTextStatus;
pub use authbus::ObjectiveRunAdmission;
pub use authbus::ObjectiveStartOutcome;
pub use capabilities::AGENTD_CAPABILITY_AUTOMATION_CALENDAR_V2;
pub use capabilities::AGENTD_CAPABILITY_AUTOMATION_EXTERNAL_EFFECT;
pub use capabilities::AGENTD_CAPABILITY_CANONICAL_INTELLIGENCE_V1;
pub use capabilities::AGENTD_CAPABILITY_SCHEMA_VERSION;
pub use capabilities::AgentdCapability;
pub use capabilities::AgentdCapabilitySet;
pub use capabilities::NegotiatedAgentdCapabilities;
pub use capabilities::negotiate_capabilities;
pub use evidence::KernelEvidenceAppendIngress;
pub use evidence::KernelEvidenceCandidateV1;
pub use evidence::KernelEvidenceQueryV1;
pub use evidence::KernelEvidenceResult;
pub use evidence::KernelEvidenceVerifyV1;
pub use evidence::MAX_KERNEL_EVIDENCE_ENVELOPE_BYTES;
pub use evidence::MAX_KERNEL_EVIDENCE_REQUIRED_ROLES;
pub use memory_cell::MemoryCellReadIngress;
pub use memory_cell::MemoryCellReadSnapshot;
pub use memory_cell::MemoryCellReadState;
pub use memory_cell::MemoryCellRole;

use std::path::PathBuf;

use codex_hepta_automation::AuthorizedEffectIntent;
use codex_hepta_automation::AutomationCalendarScheduleV2;
use codex_hepta_automation::AutomationMissedRunPolicy;
use codex_hepta_automation::AutomationOverlapPolicy;
use codex_hepta_automation::AutomationTask;
use codex_hepta_automation::AutomationTaskDraft;
use codex_hepta_automation::AutomationTaskId;
use codex_hepta_contracts::AgentId;
use codex_hepta_contracts::Sha256Digest;
use codex_hepta_contracts::SignedFinalUseGrant;
use codex_hepta_fleet::AgentLifecycle;
use serde::Deserialize;
use serde::Serialize;

pub const AGENTD_CONTROL_SCHEMA_VERSION: u32 = 2;
/// Version for the transport-only host turn authority witness.  This type is
/// deliberately not an authority grant and is not consumed by the Agentd
/// runtime yet; it gives a future host/supervisor seam one strict wire shape.
pub const HOST_TURN_AUTHORITY_BINDING_SCHEMA_VERSION: u32 = 1;
pub const MAX_CONTROL_FRAME_BYTES: u64 = 65_536;
pub const MAX_AUTOMATION_EFFECT_WIRE_BYTES: usize = 24 * 1024;
/// Maximum serialized cognitive context accepted by both Agentd and the final model consumer.
pub const MAX_COGNITIVE_CONTEXT_BYTES: usize = 8 * 1024;
pub const COGNITIVE_CONTEXT_REVALIDATION_CAPABILITY: &str = "cognitive.context.revalidate";
pub const MAX_EVENT_BATCH: u16 = 256;
pub const MAX_FEDERATION_CONTROL_LIST: u16 = 128;
pub const AGENTD_RUN_LIFECYCLE_CAPABILITY_ID: &str = "run.lifecycle";
pub const AGENTD_RUN_LIFECYCLE_CAPABILITY_MAJOR: u16 = 1;
pub const AGENTD_RUN_LIFECYCLE_CAPABILITY_MINOR: u16 = 1;
pub const MAX_RUN_CANCEL_REASON_BYTES: usize = 512;
pub const AGENTD_OVERLOAD_RETRY_AFTER_MS: u64 = 50;
pub const AGENTD_CONTROL_OVERLOAD_FRAME: &[u8] =
    b"{\"type\":\"overloaded\",\"retry_after_ms\":50}\n";
const FEDERATION_CAPABILITY_ID_PREFIX: &str = "federation:v1:";

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(transparent)]
pub struct MemoryFederationCapabilityId(String);

impl MemoryFederationCapabilityId {
    pub fn parse(value: impl Into<String>) -> Result<Self, String> {
        let value = value.into();
        let digest = value
            .strip_prefix(FEDERATION_CAPABILITY_ID_PREFIX)
            .ok_or_else(|| "invalid memory federation capability id".to_string())?;
        Sha256Digest::parse(digest.to_string())?;
        Ok(Self(value))
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl<'de> Deserialize<'de> for MemoryFederationCapabilityId {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        let value = String::deserialize(deserializer)?;
        Self::parse(value).map_err(serde::de::Error::custom)
    }
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum MemoryFederationScopeKind {
    AgentPrivate,
    WorkspacePrivate,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum MemoryFederationCapabilityState {
    Granted,
    Revoked,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct MemoryFederationCapabilitySnapshot {
    pub capability_id: MemoryFederationCapabilityId,
    pub owner_agent_id: AgentId,
    pub consumer_agent_id: AgentId,
    pub owner_scope: MemoryFederationScopeKind,
    pub generation: u64,
    pub revision: u64,
    pub effective_at_unix_seconds: i64,
    pub expires_at_unix_seconds: i64,
    pub state: MemoryFederationCapabilityState,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum AgentRunPhase {
    Admitted,
    ContextAttached,
    Dispatched,
    Cancelling,
    Cancelled,
    Succeeded,
    Failed,
    Indeterminate,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct AgentRunSnapshot {
    pub run_id: String,
    pub request_digest: String,
    pub objective_digest: String,
    pub body_digest: String,
    pub artifact_set_digest: String,
    pub authority_epoch: u64,
    pub generation: u64,
    pub fence_digest: String,
    pub deadline_ms: u64,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct AgentContextAttachment {
    pub run_id: String,
    pub request_digest: String,
    pub objective_digest: String,
    pub body_digest: String,
    pub artifact_set_digest: String,
    pub authority_epoch: u64,
    pub generation: u64,
    pub fence_digest: String,
    pub deadline_ms: u64,
    pub context_digest: String,
    pub compilation_receipt_digest: String,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum AgentCancellationDisposition {
    CancelledBeforeDispatch,
    CancellingAfterDispatch,
    AlreadyTerminal,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct AgentRunReceipt {
    pub run_id: String,
    pub revision: u64,
    pub phase: AgentRunPhase,
    pub context_digest: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub compilation_receipt_digest: Option<String>,
    pub authority_epoch: u64,
    pub generation: u64,
    pub fence_digest: String,
    pub deadline_ms: u64,
    pub cancel_reason: Option<String>,
    pub cancel_ack_deadline_ms: Option<u64>,
    pub terminal_observed: bool,
    pub idempotent: bool,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct AgentRunCancellation {
    pub disposition: AgentCancellationDisposition,
    pub receipt: AgentRunReceipt,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct AgentdRequest {
    pub schema_version: u32,
    pub request_id: u64,
    pub spawn_generation: u64,
    pub method: AgentdMethod,
}

impl AgentdRequest {
    pub fn capabilities(request_id: u64, spawn_generation: u64) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::Capabilities,
        }
    }

    pub fn health(request_id: u64, spawn_generation: u64) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::Health,
        }
    }

    pub fn lifecycle(request_id: u64, spawn_generation: u64) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::Lifecycle,
        }
    }

    pub fn readiness(request_id: u64, spawn_generation: u64) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::Readiness,
        }
    }

    pub fn drain(request_id: u64, spawn_generation: u64) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::Drain,
        }
    }

    pub fn session_ingress(request_id: u64, spawn_generation: u64) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::SessionIngress,
        }
    }

    pub fn objective_start(
        request_id: u64,
        spawn_generation: u64,
        request: AuthBusObjectiveIngress,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::ObjectiveStart { request },
        }
    }

    pub fn events(request_id: u64, spawn_generation: u64, after_cursor: u64, limit: u16) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::Events {
                after_cursor,
                limit,
            },
        }
    }

    pub fn automation_create(
        request_id: u64,
        spawn_generation: u64,
        draft: AutomationTaskDraft,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::AutomationCreate { draft },
        }
    }

    pub fn automation_create_calendar_v2(
        request_id: u64,
        spawn_generation: u64,
        draft: AutomationTaskDraft,
        schedule: AutomationCalendarScheduleV2,
        missed_run: AutomationMissedRunPolicy,
        overlap: AutomationOverlapPolicy,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::AutomationCreateCalendarV2 {
                draft,
                schedule,
                missed_run,
                overlap,
            },
        }
    }

    pub fn automation_execute_effect(
        request_id: u64,
        spawn_generation: u64,
        intent: AuthorizedEffectIntent,
        wire_payload_hex: String,
        signed_grant: SignedFinalUseGrant,
        command_id: String,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::AutomationExecuteEffect {
                intent,
                wire_payload_hex,
                signed_grant,
                command_id,
            },
        }
    }

    pub fn automation_reconcile_effect(
        request_id: u64,
        spawn_generation: u64,
        run_id: String,
        step_id: String,
        attempt: u32,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::AutomationReconcileEffect {
                run_id,
                step_id,
                attempt,
            },
        }
    }

    pub fn automation_list(request_id: u64, spawn_generation: u64, limit: u16) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::AutomationList { limit },
        }
    }

    pub fn automation_cancel(
        request_id: u64,
        spawn_generation: u64,
        task_id: AutomationTaskId,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::AutomationCancel { task_id },
        }
    }

    pub fn automation_set_enabled(
        request_id: u64,
        spawn_generation: u64,
        task_id: AutomationTaskId,
        enabled: bool,
        resume_at_ms: Option<u64>,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::AutomationSetEnabled {
                task_id,
                enabled,
                resume_at_ms,
            },
        }
    }

    pub fn memory_federation_grant(
        request_id: u64,
        spawn_generation: u64,
        consumer_agent_id: AgentId,
        owner_scope: MemoryFederationScopeKind,
        lifetime_seconds: u32,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::MemoryFederationGrant {
                consumer_agent_id,
                owner_scope,
                lifetime_seconds,
            },
        }
    }

    pub fn memory_federation_revoke(
        request_id: u64,
        spawn_generation: u64,
        capability_id: MemoryFederationCapabilityId,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::MemoryFederationRevoke { capability_id },
        }
    }

    pub fn memory_federation_list(request_id: u64, spawn_generation: u64, limit: u16) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::MemoryFederationList { limit },
        }
    }

    pub fn memory_federation_status(
        request_id: u64,
        spawn_generation: u64,
        capability_id: MemoryFederationCapabilityId,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::MemoryFederationStatus { capability_id },
        }
    }

    pub fn run_start(request_id: u64, spawn_generation: u64, snapshot: AgentRunSnapshot) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::RunStart { snapshot },
        }
    }

    pub fn run_attach_context(
        request_id: u64,
        spawn_generation: u64,
        expected_revision: u64,
        attachment: AgentContextAttachment,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::RunAttachContext {
                expected_revision,
                attachment,
            },
        }
    }

    pub fn run_mark_dispatched(
        request_id: u64,
        spawn_generation: u64,
        run_id: String,
        expected_revision: u64,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::RunMarkDispatched {
                run_id,
                expected_revision,
            },
        }
    }

    pub fn run_cancel(
        request_id: u64,
        spawn_generation: u64,
        run_id: String,
        expected_revision: u64,
        reason: String,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::RunCancel {
                run_id,
                expected_revision,
                reason,
            },
        }
    }

    pub fn run_observe_terminal(
        request_id: u64,
        spawn_generation: u64,
        run_id: String,
        expected_revision: u64,
        phase: AgentRunPhase,
        terminal_observed: bool,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::RunObserveTerminal {
                run_id,
                expected_revision,
                phase,
                terminal_observed,
            },
        }
    }

    pub fn run_status(request_id: u64, spawn_generation: u64, run_id: String) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::RunStatus { run_id },
        }
    }

    pub fn run_release_closed(
        request_id: u64,
        spawn_generation: u64,
        run_id: String,
        expected_revision: u64,
    ) -> Self {
        Self {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id,
            spawn_generation,
            method: AgentdMethod::RunReleaseClosed {
                run_id,
                expected_revision,
            },
        }
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(tag = "type", rename_all = "snake_case", deny_unknown_fields)]
pub enum AgentdMethod {
    MemoryCellReadStart {
        request: crate::MemoryCellReadIngress,
    },
    MemoryCellReadStatus {
        invocation_id: String,
    },
    Capabilities,
    Health,
    Lifecycle,
    Readiness,
    Drain,
    SessionIngress,
    ObjectiveStart {
        request: AuthBusObjectiveIngress,
    },
    AuthBusText {
        request: AuthBusTextIngress,
    },
    AuthBusTextStatus {
        delivery_id: String,
    },
    KernelEvidenceAppend {
        request: KernelEvidenceAppendIngress,
    },
    KernelEvidenceQuery {
        request: KernelEvidenceQueryV1,
    },
    KernelEvidenceVerify {
        request: KernelEvidenceVerifyV1,
    },
    CognitiveContext {
        query: String,
        limit: u16,
    },
    CognitiveContextRevalidate {
        snapshot_digest: String,
        read_digest: String,
        omitted_records: u64,
        items: Vec<CognitiveContextItem>,
        plan: Option<CognitiveContextPlan>,
    },
    Events {
        after_cursor: u64,
        limit: u16,
    },
    RunStart {
        snapshot: AgentRunSnapshot,
    },
    RunAttachContext {
        expected_revision: u64,
        attachment: AgentContextAttachment,
    },
    RunMarkDispatched {
        run_id: String,
        expected_revision: u64,
    },
    RunCancel {
        run_id: String,
        expected_revision: u64,
        reason: String,
    },
    RunObserveTerminal {
        run_id: String,
        expected_revision: u64,
        phase: AgentRunPhase,
        terminal_observed: bool,
    },
    RunStatus {
        run_id: String,
    },
    RunReleaseClosed {
        run_id: String,
        expected_revision: u64,
    },
    AutomationCreate {
        draft: AutomationTaskDraft,
    },
    AutomationCreateCalendarV2 {
        draft: AutomationTaskDraft,
        schedule: AutomationCalendarScheduleV2,
        missed_run: AutomationMissedRunPolicy,
        overlap: AutomationOverlapPolicy,
    },
    AutomationExecuteEffect {
        intent: AuthorizedEffectIntent,
        wire_payload_hex: String,
        signed_grant: SignedFinalUseGrant,
        command_id: String,
    },
    AutomationReconcileEffect {
        run_id: String,
        step_id: String,
        attempt: u32,
    },
    AutomationList {
        limit: u16,
    },
    AutomationCancel {
        task_id: AutomationTaskId,
    },
    AutomationSetEnabled {
        task_id: AutomationTaskId,
        enabled: bool,
        resume_at_ms: Option<u64>,
    },
    MemoryFederationGrant {
        consumer_agent_id: AgentId,
        owner_scope: MemoryFederationScopeKind,
        lifetime_seconds: u32,
    },
    MemoryFederationRevoke {
        capability_id: MemoryFederationCapabilityId,
    },
    MemoryFederationList {
        limit: u16,
    },
    MemoryFederationStatus {
        capability_id: MemoryFederationCapabilityId,
    },
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum AutomationEffectObservation {
    Succeeded,
    Failed,
    Indeterminate,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct AutomationEffectSnapshot {
    pub run_id: String,
    pub step_id: String,
    pub attempt: u32,
    pub event_seq: u64,
    pub receipt_digest: Option<Sha256Digest>,
    pub observation: AutomationEffectObservation,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum AutomationEffectReconcileState {
    Terminal,
    Indeterminate,
    ProvenAbsent,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct AutomationEffectReconcileSnapshot {
    pub state: AutomationEffectReconcileState,
    pub effect: Option<AutomationEffectSnapshot>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct AgentdResponse {
    pub schema_version: u32,
    pub request_id: u64,
    pub agent_id: AgentId,
    pub spawn_generation: u64,
    pub current_generation: u64,
    pub payload: AgentdPayload,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(tag = "type", rename_all = "snake_case", deny_unknown_fields)]
pub enum AgentdPayload {
    MemoryCellRead(crate::MemoryCellReadSnapshot),
    Capabilities(AgentdCapabilitySet),
    Health(HealthSnapshot),
    Lifecycle(LifecycleSnapshot),
    Readiness(ReadinessSnapshot),
    Drain(DrainSnapshot),
    SessionIngress(SessionIngress),
    ObjectiveRun(ObjectiveRunAdmission),
    ObjectiveConflict {
        run_id: String,
        conflict_digest: String,
    },
    CognitiveContext(CognitiveContextSnapshot),
    CognitiveContextRevalidated(CognitiveContextRevalidation),
    AuthBusTextStatus(AuthBusTextStatus),
    KernelEvidenceResult(KernelEvidenceResult),
    Events(EventBatch),
    RunReceipt(AgentRunReceipt),
    RunCancellation(AgentRunCancellation),
    RunStatus {
        run: Option<AgentRunReceipt>,
    },
    AutomationTask(AutomationTask),
    AutomationEffect(AutomationEffectSnapshot),
    AutomationEffectReconcile(AutomationEffectReconcileSnapshot),
    AutomationTasks {
        tasks: Vec<AutomationTask>,
    },
    MemoryFederationCapability(MemoryFederationCapabilitySnapshot),
    MemoryFederationCapabilities {
        capabilities: Vec<MemoryFederationCapabilitySnapshot>,
    },
    MemoryFederationStatus {
        capability: Option<MemoryFederationCapabilitySnapshot>,
    },
    Error {
        code: String,
        message: String,
    },
}

/// A bounded read from the owning Agent's canonical SQLite store. The digest
/// identifies an observed cut; it is not a grant or a promise of future freshness.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct CognitiveContextSnapshot {
    pub snapshot_digest: String,
    pub read_digest: String,
    pub omitted_records: u64,
    pub items: Vec<CognitiveContextItem>,
    pub plan: Option<CognitiveContextPlan>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CognitiveContextRevalidation {
    pub snapshot_digest: String,
    pub read_digest: String,
    pub verified_item_count: u16,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CognitiveContextPlan {
    /// Binds the evaluated context with `plan: null`, before any abstention.
    pub evaluated_context_digest: String,
    pub plan_receipt_digest: String,
    pub read_allowed: bool,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct CognitiveContextItem {
    pub memory_id: String,
    pub revision: u64,
    pub content: String,
    pub content_sha256: String,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct HealthSnapshot {
    /// True once the App Server initialized while this exact spawn still owns Starting.
    pub promotion_ready: bool,
    /// True only after the supervisor promoted this spawn to Running.
    pub ready: bool,
    pub fenced: bool,
    pub lifecycle: AgentLifecycle,
    pub process_id: u32,
    pub workspace: PathBuf,
    pub home_root: PathBuf,
    pub run_root: PathBuf,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct LifecycleSnapshot {
    pub lifecycle: AgentLifecycle,
    pub app_server_ready: bool,
    pub fenced: bool,
}

/// Explicit promotion/readiness inputs owned by this Agentd generation.
///
/// `revocation_ready` means the configured authority posture has a current
/// revocation witness. The default zero-effect-authority host establishes this
/// locally; any effect-authorized production composition must install and keep
/// its external witness current before opening admission.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ReadinessSnapshot {
    pub critical_stores_ready: bool,
    pub revocation_ready: bool,
    pub required_ports_ready: bool,
    pub admission_open: bool,
}

/// Exact drain acknowledgement from the owning Agentd/App Server composition.
/// New RPC admission is closed before this can report admission_closed=true.
/// running_turns is the App Server authoritative running assistant-turn count;
/// drained=true is emitted only after it reaches zero.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct DrainSnapshot {
    pub admission_closed: bool,
    pub running_turns: u32,
    pub drained: bool,
    pub lifecycle: AgentLifecycle,
    pub fenced: bool,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SessionIngress {
    pub socket_path: PathBuf,
    pub transport: SessionTransport,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum SessionTransport {
    CodexAppServerWebsocketOverUds,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct AgentdEvent {
    pub cursor: u64,
    pub kind: AgentdEventKind,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(tag = "type", rename_all = "snake_case", deny_unknown_fields)]
pub enum AgentdEventKind {
    Bootstrapped,
    Lifecycle {
        lifecycle: AgentLifecycle,
        generation: u64,
    },
    AppServerReady,
    Draining,
    GenerationFenced,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct EventBatch {
    pub events: Vec<AgentdEvent>,
    pub gap: bool,
    pub next_cursor: u64,
    pub latest_cursor: u64,
}

/// Exact host-bound turn/lease identity transported across the Agentd
/// boundary.
///
/// This is a qualification contract only.  It carries the witness that a
/// supervisor can later bind to an Agent-local append-only lease CAS, but the
/// current protocol has no method that grants authority from this value.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct HostTurnAuthorityBinding {
    pub schema_version: u32,
    pub owner_agent_id: AgentId,
    pub lease_id: String,
    pub authority_epoch: u64,
    pub owner_epoch: u64,
    pub generation: u64,
    pub fencing_token: String,
    pub lease_expires_at_unix_seconds: u64,
    pub lease_head_sha256: Sha256Digest,
}

impl HostTurnAuthorityBinding {
    #[expect(
        clippy::too_many_arguments,
        reason = "authority binding constructor keeps all signed identity fields explicit"
    )]
    pub fn new(
        owner_agent_id: AgentId,
        lease_id: impl Into<String>,
        authority_epoch: u64,
        owner_epoch: u64,
        generation: u64,
        fencing_token: impl Into<String>,
        lease_expires_at_unix_seconds: u64,
        lease_head_sha256: Sha256Digest,
    ) -> Result<Self, String> {
        let binding = Self {
            schema_version: HOST_TURN_AUTHORITY_BINDING_SCHEMA_VERSION,
            owner_agent_id,
            lease_id: lease_id.into(),
            authority_epoch,
            owner_epoch,
            generation,
            fencing_token: fencing_token.into(),
            lease_expires_at_unix_seconds,
            lease_head_sha256,
        };
        binding.validate()?;
        Ok(binding)
    }

    pub fn validate(&self) -> Result<(), String> {
        if self.schema_version != HOST_TURN_AUTHORITY_BINDING_SCHEMA_VERSION {
            return Err("unsupported host turn authority binding schema".to_string());
        }
        validate_protocol_text(&self.lease_id, "lease id", /*max_bytes*/ 512)?;
        validate_protocol_text(&self.fencing_token, "fencing token", /*max_bytes*/ 256)?;
        if self.authority_epoch == 0 {
            return Err("authority epoch must be non-zero".to_string());
        }
        if self.owner_epoch == 0 {
            return Err("owner epoch must be non-zero".to_string());
        }
        if self.generation == 0 {
            return Err("lease generation must be non-zero".to_string());
        }
        if self.lease_expires_at_unix_seconds == 0 {
            return Err("lease expiry must be non-zero".to_string());
        }
        Ok(())
    }
}

impl<'de> Deserialize<'de> for HostTurnAuthorityBinding {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct Wire {
            schema_version: u32,
            owner_agent_id: AgentId,
            lease_id: String,
            authority_epoch: u64,
            owner_epoch: u64,
            generation: u64,
            fencing_token: String,
            lease_expires_at_unix_seconds: u64,
            lease_head_sha256: Sha256Digest,
        }

        let wire = Wire::deserialize(deserializer)?;
        let binding = Self {
            schema_version: wire.schema_version,
            owner_agent_id: wire.owner_agent_id,
            lease_id: wire.lease_id,
            authority_epoch: wire.authority_epoch,
            owner_epoch: wire.owner_epoch,
            generation: wire.generation,
            fencing_token: wire.fencing_token,
            lease_expires_at_unix_seconds: wire.lease_expires_at_unix_seconds,
            lease_head_sha256: wire.lease_head_sha256,
        };
        binding.validate().map_err(serde::de::Error::custom)?;
        Ok(binding)
    }
}

fn validate_protocol_text(value: &str, label: &str, max_bytes: usize) -> Result<(), String> {
    if value.trim().is_empty() || value.len() > max_bytes || value.as_bytes().contains(&0) {
        return Err(format!(
            "{label} must contain 1..={max_bytes} non-NUL bytes"
        ));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn capabilities_endpoint_is_additive_and_bounded() {
        let request = AgentdRequest::capabilities(1, 1);
        let bytes = serde_json::to_vec(&request).expect("serialize capabilities request");
        assert!(bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&bytes).unwrap(),
            request
        );
        let payload = AgentdPayload::Capabilities(AgentdCapabilitySet::empty());
        let payload_bytes = serde_json::to_vec(&payload).expect("serialize capabilities payload");
        assert_eq!(
            serde_json::from_slice::<AgentdPayload>(&payload_bytes).unwrap(),
            payload
        );
    }

    #[test]
    fn cognitive_context_response_stays_v2_compatible_and_revalidation_is_additive() {
        let legacy = serde_json::json!({
            "snapshot_digest": "a".repeat(64),
            "read_digest": "b".repeat(64),
            "omitted_records": 0,
            "items": [{
                "memory_id": "memory:v2:test",
                "revision": 1,
                "content": "verified memory",
                "content_sha256": "c".repeat(64)
            }],
            "plan": null
        });
        let snapshot: CognitiveContextSnapshot =
            serde_json::from_value(legacy).expect("legacy cognitive context shape");
        let serialized = serde_json::to_value(&snapshot).expect("serialize cognitive context");
        assert!(serialized.get("cut_digest").is_none());

        let request = AgentdRequest {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id: 13,
            spawn_generation: 3,
            method: AgentdMethod::CognitiveContextRevalidate {
                snapshot_digest: snapshot.snapshot_digest.clone(),
                read_digest: snapshot.read_digest.clone(),
                omitted_records: snapshot.omitted_records,
                items: snapshot.items.clone(),
                plan: snapshot.plan.clone(),
            },
        };
        let bytes = serde_json::to_vec(&request).expect("serialize revalidation request");
        assert!(bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&bytes).expect("parse revalidation request"),
            request
        );
    }

    #[test]
    fn health_wire_round_trip_is_strict_and_bounded() {
        let request = AgentdRequest::health(7, 11);
        let request_bytes = serde_json::to_vec(&request).expect("serialize request");
        assert!(request_bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&request_bytes).expect("parse request"),
            request
        );

        let response = AgentdResponse {
            schema_version: AGENTD_CONTROL_SCHEMA_VERSION,
            request_id: 7,
            agent_id: AgentId::parse("018f4f72-5f8f-7cc1-8f55-df9fb3aa2c12").expect("agent id"),
            spawn_generation: 11,
            current_generation: 11,
            payload: AgentdPayload::Health(HealthSnapshot {
                promotion_ready: true,
                ready: true,
                fenced: false,
                lifecycle: AgentLifecycle::Running,
                process_id: 17,
                workspace: PathBuf::from("/tmp/workspace"),
                home_root: PathBuf::from("/tmp/home"),
                run_root: PathBuf::from("/tmp/run"),
            }),
        };
        let response_bytes = serde_json::to_vec(&response).expect("serialize response");
        assert!(response_bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdResponse>(&response_bytes).expect("parse response"),
            response
        );
    }

    #[test]
    fn automation_wire_round_trip_is_strict_and_bounded() {
        let mut draft = AutomationTaskDraft::new(
            "019153a4-3088-7e03-a56a-9b1964f75ddd",
            "x".repeat(32 * 1024),
            codex_hepta_automation::AutomationSchedule::Once,
            123,
            100,
        );
        draft.task_id =
            AutomationTaskId::parse("019153a4-3088-7000-a56a-9b1964f75001").expect("task id");
        let request = AgentdRequest::automation_create(9, 3, draft);
        let bytes = serde_json::to_vec(&request).expect("serialize request");
        assert!(bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&bytes).expect("parse request"),
            request
        );

        let schedule = codex_hepta_automation::AutomationCalendarScheduleV2 {
            timezone_id: "Etc/UTC".to_string(),
            tzdb_digest: Sha256Digest::for_bytes(b"tzdb-test"),
            start_at_utc_ms: 123,
            end_at_utc_ms: Some(86_400_123),
            every_days: 1,
            local_time_ms: 123,
            dst_gap_policy: codex_hepta_automation::AutomationDstGapPolicy::Skip,
            dst_overlap_policy: codex_hepta_automation::AutomationDstOverlapPolicy::First,
            clock_profile: codex_hepta_automation::AutomationTimeZoneProfileV1 {
                timezone_id: "Etc/UTC".to_string(),
                tzdb_digest: Sha256Digest::for_bytes(b"tzdb-test"),
                valid_from_utc_ms: 0,
                valid_until_utc_ms: 172_800_000,
                initial_offset_seconds: 0,
                transitions: Vec::new(),
            },
        };
        let calendar = AgentdRequest::automation_create_calendar_v2(
            10,
            3,
            AutomationTaskDraft::new(
                "019153a4-3088-7e03-a56a-9b1964f75ddd",
                "calendar task",
                codex_hepta_automation::AutomationSchedule::Once,
                123,
                100,
            ),
            schedule,
            codex_hepta_automation::AutomationMissedRunPolicy::Coalesce,
            codex_hepta_automation::AutomationOverlapPolicy::Forbid,
        );
        let calendar_bytes = serde_json::to_vec(&calendar).expect("serialize calendar request");
        assert!(calendar_bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&calendar_bytes)
                .expect("parse calendar request"),
            calendar
        );
    }

    #[test]
    fn automation_effect_wire_round_trip_is_strict_and_bounded() {
        let payload = b"{\"effect\":\"test\"}";
        let payload_digest = Sha256Digest::for_bytes(payload);
        let intent = AuthorizedEffectIntent {
            run_id: "run-effect".to_string(),
            step_id: "effect".to_string(),
            attempt: 1,
            operation_id: "provider.deliver".to_string(),
            subject_id: "019153a4-3088-7e03-a56a-9b1964f75ddd".to_string(),
            destination_id: "provider:fixture".to_string(),
            payload_digest,
            final_use_scope_digest: Sha256Digest::for_bytes(b"scope"),
            policy_generation: 1,
            expected_predecessor_digest: None,
            dependencies: Vec::new(),
            compensation_for: None,
        };
        let binding = intent.final_use_binding().expect("binding");
        let signed_grant = SignedFinalUseGrant {
            grant: codex_hepta_contracts::FinalUseGrant {
                schema_version: 1,
                signer_id: "security-owner".to_string(),
                authority_epoch: 1,
                grant_id: "effect-grant".to_string(),
                nonce: [7_u8; 32],
                binding,
                not_before_unix_ms: 1,
                expires_at_unix_ms: 1_001,
            },
            signature: vec![9_u8; 64],
        };
        let wire_payload_hex = payload
            .iter()
            .flat_map(|byte| format!("{byte:02x}").chars().collect::<Vec<_>>())
            .collect::<String>();
        let request = AgentdRequest::automation_execute_effect(
            11,
            3,
            intent,
            wire_payload_hex,
            signed_grant,
            "effect-command".to_string(),
        );
        let bytes = serde_json::to_vec(&request).expect("serialize effect request");
        assert!(bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&bytes).expect("parse effect request"),
            request
        );

        let response =
            AgentdPayload::AutomationEffectReconcile(AutomationEffectReconcileSnapshot {
                state: AutomationEffectReconcileState::Indeterminate,
                effect: None,
            });
        let response_bytes = serde_json::to_vec(&response).expect("serialize effect response");
        assert_eq!(
            serde_json::from_slice::<AgentdPayload>(&response_bytes)
                .expect("parse effect response"),
            response
        );
    }

    #[test]
    fn memory_federation_control_is_typed_strict_and_bounded() {
        let consumer = AgentId::parse("019153a4-3088-7e03-a56a-9b1964f75dd3").expect("consumer id");
        let grant = AgentdRequest::memory_federation_grant(
            10,
            3,
            consumer,
            MemoryFederationScopeKind::WorkspacePrivate,
            3_600,
        );
        let grant_bytes = serde_json::to_vec(&grant).expect("serialize grant");
        assert!(grant_bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&grant_bytes).expect("parse grant"),
            grant
        );

        let capability_id =
            MemoryFederationCapabilityId::parse(format!("federation:v1:{}", "a".repeat(64)))
                .expect("capability id");
        let revoke = AgentdRequest::memory_federation_revoke(11, 3, capability_id);
        let revoke_bytes = serde_json::to_vec(&revoke).expect("serialize revoke");
        assert!(revoke_bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&revoke_bytes).expect("parse revoke"),
            revoke
        );

        let malformed = String::from_utf8(revoke_bytes)
            .expect("utf8")
            .replace(&"a".repeat(64), "not-a-digest");
        assert!(serde_json::from_str::<AgentdRequest>(&malformed).is_err());
    }

    #[test]
    fn run_lifecycle_wire_round_trip_is_strict_and_bounded() {
        let snapshot = AgentRunSnapshot {
            run_id: "run.1".to_string(),
            request_digest: "1".repeat(64),
            objective_digest: "2".repeat(64),
            body_digest: "3".repeat(64),
            artifact_set_digest: "4".repeat(64),
            authority_epoch: 7,
            generation: 4,
            fence_digest: "7".repeat(64),
            deadline_ms: 9_999,
        };
        let start = AgentdRequest::run_start(12, 3, snapshot.clone());
        let start_bytes = serde_json::to_vec(&start).expect("serialize run start");
        assert!(start_bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&start_bytes).expect("parse run start"),
            start
        );

        let attachment = AgentContextAttachment {
            run_id: snapshot.run_id.clone(),
            request_digest: snapshot.request_digest.clone(),
            objective_digest: snapshot.objective_digest.clone(),
            body_digest: snapshot.body_digest.clone(),
            artifact_set_digest: snapshot.artifact_set_digest.clone(),
            authority_epoch: snapshot.authority_epoch,
            generation: snapshot.generation,
            fence_digest: snapshot.fence_digest.clone(),
            deadline_ms: snapshot.deadline_ms,
            context_digest: "5".repeat(64),
            compilation_receipt_digest: "6".repeat(64),
        };
        let attach = AgentdRequest::run_attach_context(13, 3, 1, attachment);
        let attach_bytes = serde_json::to_vec(&attach).expect("serialize attachment");
        assert!(attach_bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&attach_bytes).expect("parse attachment"),
            attach
        );

        let cancel = AgentdRequest::run_cancel(
            14,
            3,
            snapshot.run_id.clone(),
            2,
            "operator_request".to_string(),
        );
        let cancel_bytes = serde_json::to_vec(&cancel).expect("serialize cancellation");
        assert!(cancel_bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&cancel_bytes).expect("parse cancellation"),
            cancel
        );

        let release = AgentdRequest::run_release_closed(16, 4, "run.1".to_string(), 10);
        let release_bytes = serde_json::to_vec(&release).expect("serialize release");
        assert!(release_bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<AgentdRequest>(&release_bytes).expect("parse release"),
            release
        );
    }

    #[test]
    fn host_turn_authority_binding_is_strict_and_fail_closed() {
        let owner = AgentId::parse("019153a4-3088-7e03-a56a-9b1964f75dde").expect("owner id");
        let binding = HostTurnAuthorityBinding::new(
            owner,
            "lease:transport-witness",
            7,
            11,
            3,
            "fence:transport-witness",
            1_900_000_000,
            Sha256Digest::for_bytes(b"transport-head"),
        )
        .expect("valid host authority binding");
        let bytes = serde_json::to_vec(&binding).expect("serialize host binding");
        assert!(bytes.len() as u64 <= MAX_CONTROL_FRAME_BYTES);
        assert_eq!(
            serde_json::from_slice::<HostTurnAuthorityBinding>(&bytes).expect("parse host binding"),
            binding
        );

        let mut zero_epoch = serde_json::to_string(&binding).expect("json");
        zero_epoch = zero_epoch.replace("\"authority_epoch\":7", "\"authority_epoch\":0");
        assert!(serde_json::from_str::<HostTurnAuthorityBinding>(&zero_epoch).is_err());

        let unknown = serde_json::to_string(&binding)
            .expect("json")
            .replace('}', ",\"unexpected\":true}");
        assert!(serde_json::from_str::<HostTurnAuthorityBinding>(&unknown).is_err());

        assert!(
            HostTurnAuthorityBinding::new(
                binding.owner_agent_id,
                binding.lease_id.clone(),
                binding.authority_epoch,
                binding.owner_epoch,
                binding.generation,
                "\0",
                binding.lease_expires_at_unix_seconds,
                binding.lease_head_sha256,
            )
            .is_err()
        );
    }
}

#[cfg(test)]
#[path = "objective_tests.rs"]
mod objective_tests;
