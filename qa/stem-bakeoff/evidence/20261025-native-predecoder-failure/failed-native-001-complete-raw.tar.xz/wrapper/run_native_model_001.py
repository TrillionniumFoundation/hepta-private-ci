import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


root = Path("/workspace/scratch/12ef9c5bdc23")
repo = root / "hepta-memory-resume-20261024"
control = root / "memory-resume-control-20261024/native-model-001"
control.mkdir(exist_ok=False)
native = Path("/tmp/hm-native-001")
base = Path("/tmp/hm-native-base-001")
assert not native.exists() and not base.exists()
python = Path("/tmp/hepta-memory-resume-runtime/bin/python")
binary = Path("/tmp/hepta-memory-resume-target/debug/examples/native_memory_daemon")
head = "8a47cdd26574a85cd314fabce65cc395dbe316a8"
build = json.loads((root / "memory-resume-control-20261024/native-build-001/receipt.json").read_text())
assert hashlib.sha256(binary.read_bytes()).hexdigest() == build["binaries"][binary.name]["sha256"]
assert not subprocess.check_output(["git", "status", "--porcelain=v1", "--untracked-files=all"], cwd=repo)
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip() == head
command = [str(python), "-I", "-B", str(repo / "scripts/memory_cell_native/native_ci.py"),
           "--repo", str(repo), "--binary", str(binary), "--out", str(native),
           "--model-out", str(base), "--expected-head", head]
environment = dict(os.environ)
environment.update(OMP_NUM_THREADS="2", MKL_NUM_THREADS="2", TOKENIZERS_PARALLELISM="false", PYTHONDONTWRITEBYTECODE="1", HF_HOME="/tmp/hepta-memory-resume-hf-cache")
receipt = {"command": command, "cwd": str(repo), "source_head": head,
           "started_utc": datetime.datetime.now(datetime.UTC).isoformat(),
           "exit_code": None, "automatic_retry": False,
           "fixed_training_steps": 96, "actual_completed_model_calls": None,
           "output": str(native), "model_output": str(base)}
(control / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
started = time.monotonic()
with (control / "driver.log").open("xb") as log:
    process = subprocess.Popen(command, cwd=repo, env=environment, stdout=log, stderr=subprocess.STDOUT)
    receipt["pid"] = process.pid
    (control / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    code = process.wait()
receipt.update(exit_code=code, wall_seconds=time.monotonic() - started,
               completed_utc=datetime.datetime.now(datetime.UTC).isoformat(),
               log_sha256=hashlib.sha256((control / "driver.log").read_bytes()).hexdigest(),
               after_status=subprocess.check_output(["git", "status", "--porcelain=v1", "--untracked-files=all"], cwd=repo, text=True))
if (native / "report.json").is_file():
    report = json.loads((native / "report.json").read_text())
    receipt["actual_completed_model_calls"] = report["actual_decoder_queries"]
    receipt["actual_native_feature_forwards"] = report["actual_native_feature_forwards"]
    receipt["engineering_pass"] = report["engineering_pass"]
(control / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(code)
