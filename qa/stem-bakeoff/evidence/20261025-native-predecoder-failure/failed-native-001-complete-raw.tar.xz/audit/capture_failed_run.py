"""Archive a completed failed run without opening SQLite or importing model code."""
from pathlib import Path
import hashlib
import io
import json
import os
import shutil
import stat
import tarfile

ROOT = Path('/workspace/scratch/12ef9c5bdc23')
HERE = Path(__file__).resolve().parent
SOURCE = Path('/tmp/hm-native-001')
BASE = Path('/tmp/hm-native-base-001')
HEAD = '8a47cdd26574a85cd314fabce65cc395dbe316a8'
PAYLOAD = HERE / 'payload'
PAYLOAD.mkdir(exist_ok=False)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def metadata(path):
    value = path.lstat()
    return dict(mode=oct(stat.S_IMODE(value.st_mode)), uid=value.st_uid,
                gid=value.st_gid, links=value.st_nlink, bytes=value.st_size,
                inode=value.st_ino, device=value.st_dev,
                mtime_ns=value.st_mtime_ns, ctime_ns=value.st_ctime_ns)


def file_hash(path):
    before = metadata(path)
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        while data := handle.read(1024 * 1024):
            digest.update(data)
    assert metadata(path) == before, str(path)
    return digest.hexdigest()


def inventory(root):
    rows = {}
    for path in [root, *sorted(root.rglob('*'))]:
        row = metadata(path)
        mode = path.lstat().st_mode
        if stat.S_ISREG(mode):
            row.update(type='file', sha256=file_hash(path))
        elif stat.S_ISDIR(mode):
            row['type'] = 'directory'
        else:
            raise AssertionError(f'Unexpected non-regular object: {path}')
        rows[str(path.relative_to(root))] = row
    return rows


def write_json(relative, value):
    path = PAYLOAD / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def copy_file(source, relative):
    target = PAYLOAD / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    assert file_hash(source) == file_hash(target)


before = inventory(SOURCE)
raw_files = {name: value for name, value in before.items() if value['type'] == 'file'}
assert len(raw_files) == 83
assert sum(value['bytes'] for value in raw_files.values()) == 4954052
for name, row in before.items():
    target = PAYLOAD / 'original-run' / name
    if row['type'] == 'directory':
        target.mkdir(parents=True, exist_ok=True)
    else:
        target.write_bytes((SOURCE / name).read_bytes())
        assert file_hash(target) == row['sha256']
    target.chmod(int(row['mode'], 8))
write_json('audit/original-inventory-before.json', before)

control = ROOT / 'memory-resume-control-20261024'
for name in ['receipt.json', 'driver.log']:
    copy_file(control / 'native-model-001' / name, 'wrapper/' + name)
copy_file(control / 'run_native_model_001.py', 'wrapper/run_native_model_001.py')
copy_file(control / 'native-build-001/receipt.json', 'build/native-build-001-receipt.json')
copy_file(control / 'native-runtime-freeze-verified.txt', 'runtime/native-runtime-freeze-verified.txt')
copy_file(ROOT / 'native-failure-recovery-20261024/qualification-006-build-helper-20261025/payload/runtime-environment/method.json', 'runtime/freeze-method.json')
repair = ROOT / 'native-failure-recovery-20261024/prepare-close-repair-20261025'
for name in ['prepare-close-candidate-raw.tar.xz', 'archive-receipt.json', 'candidate.patch', 'prepare-close-independent-review-001.json']:
    copy_file(repair / name, 'post-failure-candidate/' + name)
copy_file(Path(__file__), 'audit/capture_failed_run.py')

acquisition = json.loads((SOURCE / 'acquisition.json').read_bytes())
base_files = []
for pin in acquisition['spec']['files']:
    path = BASE / pin['path']
    observed = dict(path=pin['path'], bytes=path.stat().st_size, sha256=file_hash(path))
    assert observed == pin
    base_files.append({**observed, 'reported_st_blocks_bytes': path.stat().st_blocks * 512})
assert {p.name for p in BASE.iterdir()} == {r['path'] for r in base_files}
assert sum(r['bytes'] for r in base_files) == 271170520
write_json('audit/base-model-inventory.json', {
    'local_root': str(BASE), 'repository': acquisition['spec']['repository'],
    'revision': acquisition['spec']['revision'], 'source_registration_commit': acquisition['spec']['source_registration_commit'],
    'files': base_files, 'total_file_bytes': 271170520,
    'total_reported_st_blocks_bytes': sum(r['reported_st_blocks_bytes'] for r in base_files),
    'all_expected_size_and_sha256_pins_verified': True, 'base_files_in_archive': 0,
    'method': 'read-only file hashing; no model imports or forward passes'})

source = json.loads((SOURCE / 'source-before.json').read_bytes())
invocation = json.loads((SOURCE / 'invocation.json').read_bytes())
wrapper = json.loads((control / 'native-model-001/receipt.json').read_bytes())
build = json.loads((control / 'native-build-001/receipt.json').read_bytes())
assert source['head'] == invocation['expected_head'] == wrapper['source_head'] == build['base_head'] == HEAD
assert source['status'] == wrapper['after_status'] == ''
assert invocation['binary_sha256'] == build['binaries']['native_memory_daemon']['sha256']
assert sha((control / 'native-model-001/driver.log').read_bytes()) == wrapper['log_sha256']
with tarfile.open(SOURCE / 'executed-source.tar.gz', 'r:gz') as archive:
    assert archive.pax_headers['comment'] == HEAD
    observed = {}
    for member in archive.getmembers():
        assert member.isfile() or member.isdir()
        if member.isfile():
            data = archive.extractfile(member).read()
            observed[member.name] = dict(bytes=len(data), sha256=sha(data))
    assert observed == source['files']
    rust = archive.extractfile('codex-rs/hepta-agentd/examples/native_memory_daemon.rs').read().decode()
    driver = archive.extractfile('scripts/memory_cell_native/native_ci.py').read().decode()
    support = archive.extractfile('codex-rs/hepta-agentd/examples/native_memory_support/mod.rs').read()
    assert sha(support) == sha((repair / 'baseline.rs').read_bytes())
    assert rust.index('open_host(root, &config, anchor_sha256).await?') < rust.index('production-source.json') < rust.index('tokio::spawn') < rust.index('raw-result.json')
    assert driver.index('"daemon-probe"') < driver.index('for control in ("base", "shuffled"):')
write_json('audit/source-verification.json', dict(
    head=HEAD, tree=source['tree'], archived_git_comment=HEAD,
    archived_source_files_verified=len(observed), source_before_status=source['status'],
    wrapper_after_status=wrapper['after_status'], binary_pin=build['binaries']['native_memory_daemon'],
    original_support_matches_repair_baseline=True,
    original_final_source_after_json_present=(SOURCE / 'source-after.json').exists(),
    note='No final driver source-after check ran; source-before, exact git archive, wrapper and build receipts retain their distinct scopes.'))

stage_names = ['source-archive', 'prepare-source', 'prepare-owner', 'train-96', 'configure', 'daemon-probe']
assert {p.name for p in (SOURCE / 'commands').iterdir()} == set(stage_names)
commands = []
for name in stage_names:
    directory = SOURCE / 'commands' / name
    commands.append(dict(stage=name, request=json.loads((directory / 'request.json').read_bytes()),
                         receipt=json.loads((directory / 'receipt.json').read_bytes())))
assert [r['receipt']['exit_code'] for r in commands] == [0, 0, 0, 0, 0, 1]
write_json('audit/command-ledger.json', dict(wrapper_command=wrapper['command'],
    stage_order=stage_names, stages=commands, acquisition=acquisition,
    note='Exact argv/cwd/timeouts/receipts are also preserved unchanged in original-run; acquisition is in-process HTTP work, not an additional subprocess stage.'))

training = json.loads((SOURCE / 'trial/training.json').read_bytes())
receipt = training['receipt']
assert receipt['steps'] == receipt['actual_model_forwards'] == len(receipt['losses']) == 96
assert receipt['evaluation_targets_used'] is False and receipt['base_unchanged'] is True
checkpoint = json.loads((SOURCE / 'checkpoint-before.json').read_bytes())
assert checkpoint == {p.name: file_hash(p) for p in (SOURCE / 'trial/checkpoint').iterdir()}
missing = ['native-owner/production-source.json', 'native-owner/hnmf-event.json',
           'native-owner/daemon-health.json', 'native-owner/started.json', 'native-owner/raw-result.json',
           'native-owner/controlled-correction.json', 'native-owner/withdrawal.json',
           'native-owner/final-anchor.json', 'native-owner/report.json', 'commands/control-base',
           'commands/control-shuffled', 'source-after.json', 'report.json']
assert not any((SOURCE / path).exists() for path in missing)
assert (SOURCE / 'trial/native-process-receipts').is_dir()
assert not list((SOURCE / 'trial/native-process-receipts').iterdir())
write_json('audit/phase-and-absence.json', dict(
    checked_absent_paths=missing, empty_directory='trial/native-process-receipts',
    empty_directory_preserved_in_archive=True, source_phase='open_host recovery failed before production source admission and before daemon spawn',
    training_model_forwards=96, completed_training_updates=96,
    derived_decoder_queries=0, derived_native_feature_forwards=0, executed_research_controls=0,
    original_wrapper_actual_completed_model_calls=wrapper['actual_completed_model_calls'],
    derivation='Observed failure + exact archived control-flow ordering + six-stage command set + empty native-process-receipts; original wrapper null is not overwritten.',
    qualification='failed; no native model-read result or production qualification'))
write_json('audit/costs.json', dict(
    wrapper_wall_seconds=wrapper['wall_seconds'], inner_driver_wall_seconds=json.loads((SOURCE / 'failure.json').read_bytes())['wall_seconds'],
    acquisition_wall_seconds=acquisition['wall_seconds'], training_process=commands[3]['receipt'],
    training_worker_wall_seconds=training['wall_seconds'], training_loop_seconds=receipt['seconds'],
    training_model_forwards=96, training_updates=96, input_tokens=receipt['input_tokens'], supervised_tokens=receipt['supervised_tokens'],
    trainable_parameters=receipt['trainable_parameters'], parameter_bytes=receipt['parameter_bytes'],
    gradient_bytes=receipt['gradient_bytes'], optimizer_tensor_bytes=receipt['optimizer_tensor_bytes'],
    decoder_queries=0, native_feature_forwards=0, controls=0,
    retained_raw_run_bytes=4954052, raw_run_files=83, retained_base_file_bytes=271170520,
    checkpoint_file_bytes=sum(p.stat().st_size for p in (SOURCE / 'trial/checkpoint').iterdir()),
    adapter_file_bytes=(SOURCE / 'trial/checkpoint/adapter_model.safetensors').stat().st_size,
    v1_executable_file_bytes=build['binaries']['native_memory_daemon']['bytes'],
    executable_in_archive=False, base_in_archive=False,
    accounting_notes=['Nested wall times overlap and must not be added.', 'Checkpoint and adapter are included in raw run bytes, not additional copies.',
      'Gradient/optimizer sizes are reported transient tensor sizes; full peak RAM and runtime dependency storage were not measured.',
      'Shared base and executable costs are recorded, not erased by excluding their bytes from this archive.',
      'Failed original 96-update training remains a cost of this attempt; any future continuation is separate.']))

after = inventory(SOURCE)
assert before == after
write_json('audit/original-inventory-after.json', after)
write_json('audit/capture-verification.json', dict(
    original_root=str(SOURCE), original_regular_files=83, original_regular_file_bytes=4954052,
    original_before_after_inventory_equal=True, original_files_copied_byte_exact=True,
    original_modes_uid_gid_links_inode_device_mtime_ctime_unchanged=True,
    access_times_excluded='Reading can update atime; identity, content and all other recorded metadata are compared.',
    sqlite_connections=0, original_file_writes=0, original_chmod_calls=0, rust_runs=0, new_model_runs=0,
    existing_training_forwards=96, base_files_copied=0, executables_copied=0,
    post_failure_patch_not_executed_in_original_attempt=True))
print(json.dumps(dict(payload=str(PAYLOAD), original_files=83, original_bytes=4954052,
    source_files_verified=len(observed), base_bytes_verified=271170520,
    checkpoint_bytes=sum(p.stat().st_size for p in (SOURCE / 'trial/checkpoint').iterdir()),
    before_after_equal=before == after)))
