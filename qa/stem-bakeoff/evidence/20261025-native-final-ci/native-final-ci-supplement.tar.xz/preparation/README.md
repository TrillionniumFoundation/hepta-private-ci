# Independent final CI audit preparation

This is an audit plan and unexecuted reader for run **40149732280**, job
**121038539566**, attempt **1**, source head
`33c741cb0abe5faac1d92abe5d0ac90bee4abb51` and tree
`02d11c75658c23b498ba2e7f8b6f082d76ec33b3`.

The locally retained initial API records say `in_progress` with no conclusion.
They do not establish the current remote status or any passing outcome. No
unfinished artifact has been downloaded and this preparation polls no service.

## Admission and provenance

- Require completed run/job metadata with exact run, job, attempt and head.
- Retain original ZIP, artifact metadata/digest, full job logs and final API JSON.
- Verify extracted bytes against every ZIP member; do not modify raw artifacts.
- Bind `source.txt`, both clean source-before/after records, both Git archives,
  full source tree/head and current runtime/worker pins to the exact tested head.
- Retain all successes, skips, failures, partial processes and missing stages.
  Missing outputs do not erase completed training or imply zero partial work.

## Fresh training versus the earlier continuation

The CI workflow calls the original `native_ci.py`, not `native_resume_ci.py`.
Successful completion should contain a new `train-96` command, its actual child
bootstrap/exit, a complete training receipt and fresh acquisition receipts. The
expected successful count is **96 new training updates and forwards**, followed
by **3 v1 decoder queries / 1 explicit feature forward**, then **1 v2 decoder
query / 1 feature forward** reusing that CI checkpoint. These are expectations,
not observations. The earlier local 96 updates and local 3a continuation remain
separate records; CI source/weights must not be relabeled as that continuation.

Verify fixed rank8 / seed24031 / learning-rate0.01 / completion_ce, exact schedule,
source root, typed question, checkpoint manifest and full lineage. Do not require
the fresh CI adapter hash to equal the earlier local adapter hash. The parameter
accuracy gate remains null; a wrong answer must be retained without retuning.

## Actual model and lifecycle evidence

- Reduce actual raw worker stdout, request hashes, bootstrap PIDs, parents,
  exit/timeout receipts, token IDs and outputs; separate started processes,
  completed queries, explicit feature forwards and training updates.
- Check native/base/shuffled questions and prompt tokens match; disabled adapter
  and shuffled state must be actual interventions. Never count source values or
  an oracle-derived report field as model-generated output.
- Verify real v1 source revisions, correction/withdrawal and all existing refusal
  assertions, plus exact native source-use receipts and actual dispatch count.
- Verify v2 full tick/source/query/runtime/profile/namespace binding from archived
  source, raw journal/witness frames, exact replay refusal and unchanged callback.
- Require successful delivery on the recovered owner before a real tombstone,
  then precise source-invalid refusal with the writer authority still live.
- Retain controlled context, abstain/deny-all, null calibration, same-process-only
  recovery and absent v2 control-socket/default-daemon installation boundaries.

## Costs and final source cleanliness

Measure full artifact file bytes, archive bytes, acquisition, complete parameter
resident bytes, RSS, command CPU/wall, training tokens and optimizer memory.
Nested wall times must not be summed twice. The base directory is outside the
workflow's upload path: if absent, say its bytes are not retained and verify its
identity through acquisition, inspection and worker pins. A local reference
model is not the CI runner's preserved original bytes. ZIP permissions also do
not independently prove the original runner's live file modes.

The job's overall success is insufficient: inspect the actual final
`post-test-fix-format.patch`, `.stat` and `final-worktree-status.txt`; all three
must be empty before claiming clean final-source qualification. Preserve full
lint output, including warnings, and the formatter's legitimately empty output.
Tests are not rerun after final fix/fmt. An additional proposed patch remains a
separate, unqualified source change.

The subsequently discovered bootstrap WAL permission defect and its independent
repair/abrupt-child tests belong to a different source phase. Do not mix them
into this 33c CI or modify the frozen program-status snapshot at f92ddcac.

## Execution after root supplies completed evidence

Run the audit reader only on completed evidence, with output outside the artifact:

```text
python -B audit_final_ci.py --artifact-dir EXTRACTED_ARTIFACT --artifact-zip ORIGINAL_ZIP --artifact-metadata ARTIFACT_JSON --job-log FULL_JOB_LOG --run-metadata FINAL_RUN_JSON --jobs-metadata FINAL_JOBS_JSON --out NEW_AUDIT_JSON
```

The reader is a standard-library evidence reducer, not a model/test runner.
Final report deltas require its actual results and the separate bootstrap stage.
All eight complete research gates remain false; independent future groups remain
zero and future accuracy remains null unless genuinely new evidence establishes
otherwise.
