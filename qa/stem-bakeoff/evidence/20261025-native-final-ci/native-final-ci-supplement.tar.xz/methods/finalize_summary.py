"""Attach a separately completed independent frame audit without rewriting either audit."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TICK = ROOT.parent / 'tick-shadow-recovery-20261024'


def main():
    name = 'ci-40149732280-shadow-audit-001.json'
    raw = (TICK / name).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == '3345a0406b0f9005ea8f41ef9e616addee0703c4f0c95444f92ff05da720e809'
    tick = json.loads(raw)
    assert tick['checks_passed'] == len(tick['checks']) == 595
    assert all(row['result'] == 'pass' for row in tick['checks'])
    summary = json.loads((ROOT / 'summary-draft.json').read_text())
    assert tick['source_head'] == summary['source_head'] and tick['ci']['run_id'] == summary['run_id']
    assert tick['ci']['job_id'] == summary['job_id'] and tick['ci']['artifact_id'] == 12581984329
    assert tick['audit_operations']['model_executions'] == tick['audit_operations']['Rust_builds_or_runs'] == 0
    summary['status'] = 'completed_raw_and_independent_full_tick_audits_passed_with_explicit_limits'
    summary['full_tick_audit'] = {
        'file': name, 'sha256': digest, 'checks_passed': 595, 'checks_failed': 0,
        'method': 'audit_ci_shadow_40149732280.py', 'method_sha256': tick['method_sha256'],
        'canonical_checkpoint': tick['digests']['checkpoint_after'],
        'journal_sha256': tick['digests']['journal_sha256'], 'witness_sha256': tick['digests']['witness_sha256'],
        'first_tick_state_independently_recomputed': True, 'complete_journal_frame_independently_recomputed': True,
        'model_calls': 0, 'tests_run': 0, 'sqlite_opens': 0, 'proof_limits': tick['proof_limits']}
    text = '{\n' + ',\n'.join('  ' + json.dumps(key) + ': ' + json.dumps(value, ensure_ascii=False) for key, value in summary.items()) + '\n}\n'
    with (ROOT / 'publication/summary.json').open('x') as output:
        output.write(text)
    print(json.dumps({'bytes': len(text.encode()), 'lines': len(text.splitlines()), 'sha256': hashlib.sha256(text.encode()).hexdigest()}))


if __name__ == '__main__':
    main()
