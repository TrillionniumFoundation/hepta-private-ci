# Independent audit of CI 40149732280 native shadow evidence

This audit reads the original CI artifact for source `33c741cb0abe5faac1d92abe5d0ac90bee4abb51`. It does not execute Rust, import a model library, open SQLite, perform another training/inference run, or change retained evidence. The subsequent source-bootstrap repair cycle and the earlier local reused-checkpoint experiment are separate evidence.

## Inputs and reproducibility

- Original artifact: `native-memory-40149732280-1.zip`, 61,902,851 bytes, SHA256 `b2553066177240e7c8af4304c7c9c69520a4bdd905d4f2830bbaf2527b03b8f2`.
- GitHub run/job/artifact metadata: run `40149732280`, job `121038539566`, artifact `12581984329`, attempt 1, completed successfully.
- Retained source archive and source-before/source-after inventories are inside `artifact/shadow`; the full source commit API independently identifies tree `02d11c75658c23b498ba2e7f8b6f082d76ec33b3`.
- Method: `audit_ci_shadow_40149732280.py`, using Python standard-library modules only. Its SHA256 is also embedded in the generated report.
- Result: `ci-40149732280-shadow-audit-001.json`, containing 595 successful checks, recomputed digests, actual process identifiers, input inventories and explicit qualification limits.

Run the method with an evidence package path and an output outside that package:

```sh
python3 audit_ci_shadow_40149732280.py --package /path/to/native-final-ci-audit-20261025 --out /path/outside/package/audit.json
```

The method first verifies the actual ZIP against the API size and digest, then compares every extracted shadow evidence file against its original ZIP member. It checks the archive's embedded Git commit and every one of the 344 pinned source files. The current mutable checkout is never an execution-evidence input.

## Independent derivations

1. **Source and query.** Recompute the full typed-query digest, the owner/source binding with its digest field zeroed, the canonical HNMF event/key digests, both production mutation receipts, and the ordered execution digest. This binds the request to the retained source bytes, memory revision, typed key and actual returned execution.
2. **Full native tick.** Rebuild all 512 integer input features directly from the question's UTF-8 bytes. Re-encode the complete tick with its identifiers, sequence, monotonic time, previous checkpoint, feature digest, actual objective/NDU file digests and optional fields. Then recompute the source/query/tick join. The source hash is not substituted for objective or NDU context.
3. **Model/runtime/profile.** Recompute the runtime pin from its retained executable/version/source inventory and independently hash each archived Python source. Hash the actual retained CI adapter and lineage bytes; derive the combined weights and tokenizer-inventory pins. Rebuild the runtime receipt, output digest, encoder/head/runtime/output binding, sparse-config digest, shadow-profile digest and source/profile namespace.
4. **First sparse transition.** Starting with the recorded zero predecessor and actual five-element drive/prediction vectors, independently evaluate the fixed first-tick arithmetic. Multiplication uses integer Q24 rounding with ties to even, avoiding floating-point reconstruction. Derive temporal values, stable top-one activation, activity, thresholds, eligibility and any projection. Re-encode and hash the entire canonical checkpoint.
5. **Complete journal and witness.** Reconstruct the journal's root header and the entire 384-byte frame, including the sparse input binding, both checkpoints and the signal-receipt digest. That digest includes the requires-calibration and DENY_ALL bits. Compare all bytes and checksums with the actual 520-byte journal. Independently rebuild the 224-byte witness's namespace/objective/generation header and acknowledged zero-to-one transition. Verify unchanged journal/witness observations after replay, recovery and withdrawal.

The independently reconstructed checkpoint is `c1cfa71f0fb4ce18007c46c169ec3884c7c999408d02b2c81683141b44efba6d`. The complete journal and witness SHA256 values are respectively `cc67fc641e6d096315d196942d229e730b14b4f95cfd9e644eabdeb666be4ef3` and `efc61d0e02df1d72171ee46f8de69c4b52e0bb54f19abdec579a200ad45ec94b`.

## Execution evidence and causality

The original process evidence records parent PID 34959 and model PID 34970, matching the model child's own bootstrap record. There is exactly one retained native request/process directory. The archived worker validates its fixed closed request, performs one explicit feature forward and one generation call for a one-question list, checks model/file identities afterward, and returns the raw output. These source checks and the completed real process support the callback/query counts; report booleans alone are not treated as independent execution proof. This is trusted local execution evidence, not remote hardware attestation, and a decoder query is distinct from its internal autoregressive token forwards.

The archived successful Rust probe orders the operations as follows: actual read and source revalidation; owner drop; durable anchor observation; first same-process Recover followed by exact `Source(Replay)`; poisoned-owner drop; second Recover and successful delivery; real production forget mutation; precise `Source(Invalid("current source revision or typed identity"))`; final unchanged anchor observation. The error enums, actual mutation receipt and unchanged dispatch counters are retained separately. In particular, successful delivery before the tombstone prevents a generic failed-owner state from masquerading as a withdrawal fence.

The audit does not reopen the durable SQLite nonce/source tables. Their logical contents and authorization transitions are therefore supported by the pinned executable path, its successful conditional checks, the retained mutation/use/error receipts and the immutable raw owner files; they are not described as independently re-queried database state.

## Training accounting and limits

This CI job performed a fresh 96-update training command, PID 34770, with 96 recorded training forwards and no learned-parent checkpoint. The shadow stage adds zero training updates and reuses that same CI checkpoint. It does not reuse the old local run's checkpoint. Across the whole CI qualification, the separate general audit records four decoder queries and two explicit feature forwards; this audit's v2 transaction contributes one of each.

The retained ZIP contains adapter bytes and the base-model/Python-executable inventory hashes. It does not contain all original base-model or Python-executable bytes, so those external bytes are not independently rehashed here. Extracted file permissions are not evidence of the original GitHub runner's permissions.

The output remains uncalibrated, abstaining and DENY_ALL. The context provider is explicitly controlled, uses one shared process monotonic clock, and supplies no production Objective/NDU authority. The two owner recoveries are in one process. This v2 probe does not exercise a control socket or default daemon startup. The single exposed case is not a future-task comparison, a multi-host recovery test, an independent witness-custody qualification, or physical unlearning evidence. All eight broader research/production closure gates remain false.
