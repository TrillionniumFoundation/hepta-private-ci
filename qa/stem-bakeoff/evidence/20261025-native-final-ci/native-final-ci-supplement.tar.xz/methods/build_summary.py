"""Reduce immutable evidence for publication; this does not invoke repo code."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT / name).read_text())


def main():
    audit = read('raw-audit-001.json')
    assert audit['checks_passed'] == 60 and audit['checks_failed'] == 0
    findings = audit['findings']
    v1 = read('artifact/run/report.json')
    owner = read('artifact/shadow/shadow-owner/report.json')
    files = audit['retained_files']
    partitions = {prefix: {'files': len(rows), 'bytes': sum(row['bytes'] for row in rows)}
                  for prefix in ('run/', 'shadow/')
                  for rows in [[value for path, value in files.items() if path.startswith(prefix)]]}
    summary = {
        'schema': 'hepta.memory.final-ci-delta.v1',
        'status': 'raw_evidence_passed_full_tick_audit_pending',
        'run_id': audit['run_id'], 'job_id': audit['job_id'], 'run_attempt': 1,
        'source_head': audit['source_head'], 'source_tree': audit['source_tree'],
        'source_identity_external_commit_api': 'source-commit-33c741.json',
        'original_api_artifact': read('artifact-12581984329.json'),
        'raw_audit': {'file': 'raw-audit-001.json', 'sha256': hashlib.sha256((ROOT / 'raw-audit-001.json').read_bytes()).hexdigest(), 'checks_passed': 60, 'checks_failed': 0, 'model_calls': 0, 'tests_run': 0},
        'full_tick_audit': {'status': 'pending', 'model_calls': 0},
        'actual_qualification': {
            'v1_control_socket_neuron_port_worker': True, 'v2_controlled_tick_owner_worker_journal_witness': True,
            'v1_source_correction_revisions': [1, 2, 3], 'v1_native_dispatches': 1, 'v1_refusal_cases': 8,
            'v2_callback_count': owner['actual_backend_dispatches'], 'v2_context_provider_calls': owner['context_provider_calls'],
            'v2_same_process_recovered_owners': owner['same_process_owner_recoveries'],
            'v2_replay_precise_refusal': True, 'v2_recovered_delivery_before_tombstone': True,
            'v2_source_invalid_after_tombstone': True, 'v2_writer_authority_still_live_after_tombstone': True,
            'v2_no_extra_callback_after_replay_or_tombstone': True,
            'v2_journal_bytes': owner['anchors']['journal_bytes'], 'v2_witness_bytes': owner['anchors']['witness_bytes'],
            'v2_context_provider': owner['context_provider'], 'v2_abstain': owner['abstain'],
            'v2_authority_grants_any': owner['authority_grants_any'], 'v2_calibration': owner['calibration'],
            'v1_output_width': 4, 'v2_output_width': 5, 'new_shadow_training': 0},
        'fresh_training': {key: findings['fresh_training'][key] for key in ('source_head', 'new_updates', 'new_forwards', 'input_tokens', 'supervised_tokens', 'gradient_bytes', 'optimizer_tensor_bytes', 'adapter')},
        'model_counts': {'bootstrapped_model_children': 5, 'training_children': 1, 'decoder_queries': 4,
                         'v1_decoder_queries': 3, 'v2_decoder_queries': 1, 'explicit_feature_forwards': 2,
                         'v1_explicit_feature_forwards': 1, 'v2_explicit_feature_forwards': 1,
                         'generated_tokens': 36, 'decoder_prompt_tokens': 296, 'explicit_feature_prompt_tokens': 148,
                         'unknown_partial_work': [], 'generation_internal_forward_count': 'not separately instrumented; decoder queries are not total forward calls'},
        'raw_observations': findings['observations'],
        'tests': {'evidence_driver_regressions': {'passed': 3, 'wall_seconds': 1.033},
                  'wire_regressions': {'passed': 4, 'wall_seconds': 0.007},
                  'six_crates': {'run': 651, 'passed': 651, 'failed': 0, 'skipped': 13, 'test_phase_wall_seconds': 93.119}},
        'final_source': {'patch_bytes': 0, 'stat_bytes': 0, 'status_bytes': 0, 'formatter_stdout_bytes': 0,
                         'fix_and_fmt_steps_success': True, 'lint_warnings_preserved': True, 'tests_after_final_fix_fmt': False},
        'cost': {'api_job_wall_seconds': 1660, 'api_clock_precision_seconds': 1,
                 'drivers': findings['driver_wall_seconds'],
                 'training_command_wall_seconds': findings['fresh_training']['command_receipt']['wall_seconds'],
                 'training_function_wall_seconds': findings['fresh_training']['function_wall_seconds'],
                 'training_loop_wall_seconds': v1['training_receipt']['receipt']['seconds'],
                 'acquisition_wall_seconds': findings['acquisition']['wall_seconds'], 'nested_times_not_resummed': True,
                 'original_zip_bytes': 61902851, 'retained_artifact_file_bytes': 100734907, 'retained_artifact_files': 5704,
                 'run_partitions': partitions, 'fresh_base_files': 6, 'fresh_base_file_bytes': 271170520,
                 'base_bytes_retained_in_zip': False, 'native_binaries_retained_in_zip': False,
                 'resident_parameter_bytes_per_worker': 539903232, 'native_peak_rss_bytes': 1143246848,
                 'shadow_peak_rss_bytes': 1143152640, 'rss_scope': 'reported inference workers only; not complete CI or training peak',
                 'original_runner_modes_independently_proven_by_zip': False,
                 'quality_matched_net_compression_proven': False, 'full_storage_runtime_cost_closed': False},
        'immutability': {'original_zip_digest_and_size_match_api': True, 'all_extracted_bytes_verified': True,
                         'source_before_after_clean': True, 'same344_source_files_in_both_archives': True,
                         'checkpoint_unchanged_through_reads': True, 'v1_run_unchanged_through_shadow': True},
        'limits': {'previously_exposed_cases': 1, 'future_tasks': 0, 'future_accuracy': None, 'parameter_success_gate': None,
                   'production_qualified': False, 'v2_control_socket_exercised': False, 'default_daemon_installed': False,
                   'cross_process_recovery': False, 'physical_unlearning': False, 'production_ndu_owner_attachment_qualified': False,
                   'independent_operational_witness_trust_qualified': False, 'bootstrap_permission_repair_included': False},
        'eight_blockers': [{'name': name, 'full_closure': False} for name in (
            '长期纠正与保留准确性', '真实来源与查询绑定', '未来任务优于强检索', '相同总预算下的分裂收益',
            '学习连边与自治生长', '多物理节点与数据本地性', '净压缩和规模成本', '原生生产集成')],
        'previous_local_training_head': '8a47cdd26574a85cd314fabce65cc395dbe316a8',
        'previous_local_continuation_shadow_head': '3a1431c5879d084bf49b9df67f9792af8f3acbc7',
        'previous_frozen_status_head': 'f92ddcacbe21267514f5040c1df6c380a96f0643'}
    text = '{\n' + ',\n'.join('  ' + json.dumps(key) + ': ' + json.dumps(value, ensure_ascii=False) for key, value in summary.items()) + '\n}\n'
    with (ROOT / 'summary-draft.json').open('x') as output:
        output.write(text)
    print(json.dumps({'output': 'summary-draft.json', 'bytes': len(text.encode()), 'lines': len(text.splitlines())}))


if __name__ == '__main__':
    main()
