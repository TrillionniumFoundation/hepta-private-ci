"""Standard-library readers for completed CI artifacts; no model imports."""
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import tarfile
import zipfile

HEAD = '33c741cb0abe5faac1d92abe5d0ac90bee4abb51'
TREE = '02d11c75658c23b498ba2e7f8b6f082d76ec33b3'
RUN = 40149732280
JOB = 121038539566


def read(path):
    return json.loads(Path(path).read_text())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def files(root):
    result = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('audit does not dereference artifact symlinks')
        if path.is_file():
            result[str(path.relative_to(root))] = {'sha256': file_sha(path), 'bytes': path.stat().st_size}
        elif not path.is_dir():
            raise ValueError('regular artifact files and directories required')
    return result


def source_archive(path):
    result = {}
    contents = {}
    with tarfile.open(path) as archive:
        comment = archive.pax_headers.get('comment')
        for member in archive.getmembers():
            name = Path(member.name)
            if name.is_absolute() or '..' in name.parts:
                raise ValueError('unsafe source archive member')
            if member.isfile():
                if member.name in result:
                    raise ValueError('duplicate source archive member')
                raw = archive.extractfile(member).read()
                result[member.name] = {'sha256': sha(raw), 'bytes': len(raw)}
                contents[member.name] = raw
            elif not member.isdir():
                raise ValueError('unexpected source archive member type')
    return result, contents, comment


def tensor_header(path):
    with path.open('rb') as stream:
        count = struct.unpack('<Q', stream.read(8))[0]
        if count > 8 * 1024 * 1024:
            raise ValueError('bounded safetensors header required')
        header = json.loads(stream.read(count))
    tensors = [v for k, v in header.items() if k != '__metadata__']
    return {'tensors': len(tensors), 'parameters': sum(math.prod(t['shape']) for t in tensors),
            'payload_bytes': sum(t['data_offsets'][1] - t['data_offsets'][0] for t in tensors),
            'dtypes': sorted({t['dtype'] for t in tensors}), 'file_bytes': path.stat().st_size}


def zip_files(path, prefix=''):
    result = {}
    with zipfile.ZipFile(path) as archive:
        for member in archive.infolist():
            name = Path(member.filename)
            if name.is_absolute() or '..' in name.parts or '\\' in member.filename:
                raise ValueError('unsafe ZIP member')
            if member.is_dir():
                continue
            if not member.filename.startswith(prefix):
                raise ValueError('ZIP member outside explicit prefix')
            relative = member.filename[len(prefix):]
            if relative in result:
                raise ValueError('duplicate ZIP member')
            digest = hashlib.sha256()
            size = 0
            with archive.open(member) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(block)
                    size += len(block)
            if size != member.file_size:
                raise ValueError('ZIP declared size differs')
            result[relative] = {'sha256': digest.hexdigest(), 'bytes': size}
    return result


def bootstrap(path):
    for line in path.read_text(errors='replace').splitlines():
        try:
            value = json.loads(line)
        except ValueError:
            continue
        if isinstance(value, dict) and value.get('schema') == 'hepta.memory-process.started.v1':
            return value
    return None


def stage_counts(root):
    """Completed raw receipts prove counts; partial work remains explicitly unknown."""
    native = root / 'run'
    shadow = root / 'shadow'
    result = {'training_updates': None, 'training_forwards': None, 'training_child_bootstrap_observed': False,
              'completed_native_queries': 0, 'completed_control_queries': 0,
              'completed_shadow_queries': 0, 'completed_explicit_feature_forwards': 0,
              'unknown_partial_work': [], 'processes': []}
    training = native / 'trial/training.json'
    train_dir = native / 'commands/train-96'
    if training.exists():
        try:
            receipt = read(training)['receipt']
            result.update(training_updates=receipt['steps'], training_forwards=receipt['actual_model_forwards'])
        except (OSError, ValueError, KeyError, TypeError):
            result['unknown_partial_work'].append('training receipt exists but cannot establish completed updates/forwards')
    if (train_dir / 'stderr.log').exists():
        boot = bootstrap(train_dir / 'stderr.log')
        result['training_child_bootstrap_observed'] = boot is not None
        if boot:
            result['processes'].append({'kind': 'training', **boot})
    if train_dir.exists() and not training.exists():
        result['unknown_partial_work'].append('training command entered without completed training receipt')
    for kind, directory in [('native', native / 'trial/native-process-receipts'), ('shadow', shadow / 'native-process-receipts')]:
        if not directory.exists():
            continue
        for path in sorted(directory.iterdir()):
            if (path / 'stderr.log').exists():
                boot = bootstrap(path / 'stderr.log')
                if boot:
                    result['processes'].append({'kind': kind, **boot})
            try:
                process = read(path / 'process.json')
                execution = read(path / 'stdout.json')
                if process['exit_code'] != 0 or process['timed_out'] or execution['schema'] != 'hepta.memory-cell.native-execution.v1':
                    raise ValueError('incomplete worker')
                result[f'completed_{kind}_queries'] += execution['decoder_queries']
                result['completed_explicit_feature_forwards'] += execution['feature_forward_calls']
            except (OSError, ValueError, KeyError, TypeError):
                result['unknown_partial_work'].append(str(path.relative_to(root)))
    for control in ('base', 'shuffled'):
        path = native / 'commands' / f'control-{control}'
        if not path.exists():
            continue
        if (path / 'stderr.log').exists():
            boot = bootstrap(path / 'stderr.log')
            if boot:
                result['processes'].append({'kind': control, **boot})
        try:
            receipt = read(path / 'receipt.json')
            result['completed_control_queries'] += len(read(path / 'stdout.log')['rows']) if receipt['exit_code'] == 0 else 0
            if receipt['exit_code'] != 0:
                raise ValueError('incomplete control')
        except (OSError, ValueError, KeyError, TypeError):
            result['unknown_partial_work'].append(str(path.relative_to(root)))
    return result


def nextest_summary(path):
    if not path.exists():
        return None
    raw = re.sub(r'\x1b\[[0-9;]*m', '', path.read_text(errors='replace'))
    lines = [line for line in raw.splitlines() if 'Summary [' in line]
    if not lines:
        return None
    text = lines[-1]
    counts = {name: int(match.group(1)) if (match := re.search(r'(\d+) ' + name, text)) else 0
              for name in ('passed', 'failed', 'skipped')}
    match = re.search(r'(\d+) tests run', text)
    return {'run': int(match.group(1)) if match else None, **counts, 'raw_summary': text}
