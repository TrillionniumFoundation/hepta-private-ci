"""Seal raw CI ZIP parts plus a small metadata/audit archive; no source/model execution."""
import hashlib
import json
from pathlib import Path
import stat
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'publication'
TICK = ROOT.parent / 'tick-shadow-recovery-20261024'


def file_record(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return {'bytes': path.stat().st_size, 'sha256': digest.hexdigest(), 'mode': stat.S_IMODE(path.stat().st_mode)}


def compact(value):
    return '{\n' + ',\n'.join('  ' + json.dumps(key) + ': ' + json.dumps(item, ensure_ascii=False) for key, item in value.items()) + '\n}\n'


def main():
    sources = {}
    for name in ('run-final.json', 'jobs-final.json', 'artifacts-final.json', 'artifact-12581984329.json', 'source-commit-33c741.json'):
        sources['metadata/' + name] = ROOT / name
    sources['logs/job-121038539566.log'] = ROOT / 'job-121038539566.log'
    for name in ('native-memory-40149732280-1.download.json', 'extraction-receipt.json', 'split-receipt.json'):
        sources['receipts/' + name] = ROOT / name
    sources['audits/raw-audit-001.json'] = ROOT / 'raw-audit-001.json'
    sources['audits/ci-40149732280-shadow-audit-001.json'] = TICK / 'ci-40149732280-shadow-audit-001.json'
    for name in ('audit_final_ci.py', 'ci_evidence.py', 'extract_verified_artifact.py', 'split_original_zip.py', 'build_summary.py', 'finalize_summary.py', 'package_final_ci.py'):
        sources['methods/' + name] = ROOT / name
    for name in ('audit_ci_shadow_40149732280.py', 'ci-40149732280-shadow-audit-method.md'):
        sources['methods/' + name] = TICK / name
    sources['preparation/README.md'] = ROOT / 'README.md'
    sources['preparation/summary-draft.json'] = ROOT / 'summary-draft.json'
    before = {name: file_record(path) for name, path in sources.items()}
    assert before['audits/raw-audit-001.json']['sha256'] == '60bf75c59bf57f6cfd105d4b3bb8c222e189c42a2ed16401d2722d97476072b4'
    assert before['audits/ci-40149732280-shadow-audit-001.json']['sha256'] == '3345a0406b0f9005ea8f41ef9e616addee0703c4f0c95444f92ff05da720e809'
    summary = json.loads((OUT / 'summary.json').read_text())
    assert summary['full_tick_audit']['checks_passed'] == 595
    assert all(not item['full_closure'] for item in summary['eight_blockers'])
    archive = OUT / 'native-final-ci-supplement.tar.xz'
    with tarfile.open(archive, 'x:xz', preset=6, format=tarfile.PAX_FORMAT) as output:
        for name, path in sorted(sources.items()):
            output.add(path, arcname=name, recursive=False)
    seen = set()
    with tarfile.open(archive) as retained:
        for member in retained:
            assert member.isfile() and member.name in before and member.name not in seen
            seen.add(member.name)
            raw = retained.extractfile(member).read()
            record = before[member.name]
            assert len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256']
            assert member.mode == record['mode']
    assert seen == set(before) and before == {name: file_record(path) for name, path in sources.items()}
    assert archive.stat().st_size <= 5 * 1024 * 1024
    split = json.loads((ROOT / 'split-receipt.json').read_text())
    rebuilt = hashlib.sha256()
    for part in split['parts']:
        raw = (OUT / part['file']).read_bytes()
        assert len(raw) == part['bytes'] and hashlib.sha256(raw).hexdigest() == part['sha256']
        rebuilt.update(raw)
    assert rebuilt.hexdigest() == file_record(ROOT / 'native-memory-40149732280-1.zip')['sha256'] == split['archive_sha256']
    publication_files = {path.name: file_record(path) for path in sorted(OUT.iterdir()) if path.is_file()}
    assert len(publication_files) == 15
    manifest = {
        'schema': 'hepta.memory.final-ci-publication-manifest.v1',
        'planned_repository_directory': 'qa/stem-bakeoff/evidence/20261025-native-final-ci',
        'run_id': 40149732280, 'job_id': 121038539566, 'attempt': 1, 'artifact_id': 12581984329,
        'source_head': summary['source_head'], 'source_tree': summary['source_tree'],
        'original_zip': {'file': 'native-memory-40149732280-1.zip', 'bytes': split['archive_bytes'], 'sha256': split['archive_sha256'], 'parts': split['parts'], 'recompressed': False},
        'original_zip_extracted_files': 5704, 'original_zip_extracted_file_bytes': 100734907,
        'supplement': {'file': archive.name, **file_record(archive), 'members': before, 'files': len(before), 'file_bytes': sum(record['bytes'] for record in before.values())},
        'verification': {'original_zip_digest_size_matches_github_api': True, 'all_parts_hashes_and_reassembly_checked': True,
                         'complete_raw_zip_preserved': True, 'supplement_all_member_bytes_and_modes_readback_verified': True,
                         'supplement_original_inputs_unchanged': True, 'raw_audit_passed': 60, 'independent_tick_audit_passed': 595,
                         'final_patch_stat_status_each_zero_bytes': True, 'auditor_model_calls': 0, 'auditor_training_updates': 0, 'auditor_tests_run': 0},
        'scope_limits': summary['limits'], 'eight_full_closure_flags': [False] * 8,
        'publication_files_excluding_this_manifest': publication_files,
        'publication_file_count_including_manifest': 16,
        'api_json_storage': 'exact UTF-8 JSON content returned by read-only GitHub connector; selected single artifact record also separately retained',
        'job_log_storage': 'complete decoded log string returned by GitHub job log connector, preserved as UTF-8 including its initial BOM',
        'source_and_base_limits': '344 selected source files per execution archive; full commit/tree externally bound. Base, Python executable and native binary original bytes outside uploaded ZIP; hashes and receipts retained. Original runner file modes not independently proven.',
        'prior_status_snapshot_unmodified': 'f92ddcacbe21267514f5040c1df6c380a96f0643',
        'subsequent_bootstrap_repair_source_cycle_included': False}
    with (OUT / 'manifest.json').open('x') as output:
        output.write(compact(manifest))
    lines = sum(len(path.read_text().splitlines()) for path in OUT.iterdir() if path.suffix in ('.md', '.json'))
    assert lines <= 500
    final = {path.name: file_record(path) for path in sorted(OUT.iterdir()) if path.is_file()}
    receipt = {'schema': 'hepta.memory.final-ci-publication-ready.v1', 'publication_directory': str(OUT),
               'files': final, 'file_count': len(final), 'total_bytes': sum(record['bytes'] for record in final.values()),
               'text_lines': lines, 'largest_file_bytes': max(record['bytes'] for record in final.values()),
               'all_verification_passed': True, 'uploaded': False}
    with (ROOT / 'publication-receipt.json').open('x') as output:
        output.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items() if key != 'files'}))


if __name__ == '__main__':
    main()
