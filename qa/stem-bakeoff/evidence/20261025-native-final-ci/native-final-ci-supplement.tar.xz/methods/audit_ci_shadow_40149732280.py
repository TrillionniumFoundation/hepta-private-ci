"""Read retained evidence using stdlib only; never opens SQLite or runs a model."""
from pathlib import Path
import hashlib
import json
import struct
import tarfile
import zipfile
import argparse
import re

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--package', type=Path, default=Path('/workspace/scratch/12ef9c5bdc23/native-final-ci-audit-20261025'))
parser.add_argument('--out', type=Path, default=Path('/workspace/scratch/12ef9c5bdc23/tick-shadow-recovery-20261024/ci-40149732280-shadow-audit-001.json'))
args = parser.parse_args()
PACKAGE, OUT = args.package.resolve(), args.out.resolve()
ROOT, RUN = PACKAGE / 'artifact/shadow', PACKAGE / 'artifact/run'
OWNER = ROOT / 'shadow-owner'
HEAD = '33c741cb0abe5faac1d92abe5d0ac90bee4abb51'
if OUT.is_relative_to(PACKAGE): raise ValueError('audit output must not modify the evidence package')
checks = []

def sha(raw): return hashlib.sha256(raw).hexdigest()
def raw_sha(raw): return hashlib.sha256(raw).digest()
def read(path): return json.loads(path.read_text())
def compact(value, ordered=True):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), sort_keys=not ordered).encode()
def u64(value): return struct.pack('>Q', value)
def i64(value): return struct.pack('>q', value)
def identifier(value):
    raw = value.encode(); return struct.pack('>I', len(raw)) + raw
def digest(value): return bytes.fromhex(value)
def vector(values): return b''.join(i64(value) for value in values)
def vector_digest(domain, values): return sha(domain + u64(len(values)) + vector(values))
def framed(domain, parts):
    return sha(b''.join(u64(len(part)) + part for part in [domain, *parts]))
def equal(name, observed, expected):
    if observed != expected: raise AssertionError((name, observed, expected))
    checks.append({'check': name, 'result': 'pass'})
def inventory(root):
    return {str(p.relative_to(root)): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
            for p in sorted(root.rglob('*')) if p.is_file()}

before, v1_before = inventory(ROOT), inventory(RUN)
metadata_names = ['run-final.json', 'jobs-final.json', 'artifact-12581984329.json', 'source-commit-33c741.json', 'job-121038539566.log']
metadata_before = {name: sha((PACKAGE / name).read_bytes()) for name in metadata_names}
run_meta, jobs_meta, artifact_meta, commit_meta = [read(PACKAGE / name) for name in metadata_names[:4]]
equal('GitHub CI run identity and final disposition', [run_meta['id'], run_meta['head_sha'], run_meta['status'], run_meta['conclusion'], run_meta['run_attempt']], [40149732280, HEAD, 'completed', 'success', 1])
job = next(j for j in jobs_meta['jobs'] if j['id'] == 121038539566)
equal('GitHub job binds the same exact source', [job['head_sha'], job['status'], job['conclusion']], [HEAD, 'completed', 'success'])
equal('GitHub artifact binds the same exact run', [artifact_meta['id'], artifact_meta['workflow_run']['id'], artifact_meta['workflow_run']['head_sha']], [12581984329, 40149732280, HEAD])
zip_path = PACKAGE / 'native-memory-40149732280-1.zip'
zip_digest = sha(zip_path.read_bytes())
equal('actual ZIP digest equals GitHub API digest', 'sha256:' + zip_digest, artifact_meta['digest'])
equal('actual ZIP size equals GitHub API size', zip_path.stat().st_size, artifact_meta['size_in_bytes'])
with zipfile.ZipFile(zip_path) as archive:
    for name, info in before.items():
        equal('CI ZIP raw v2 member: ' + name, sha(archive.read('shadow/' + name)), info['sha256'])
source = read(ROOT / 'source-before.json')
equal('source archive tree binds independent commit API', [source['head'], source['tree']], [commit_meta['sha'], commit_meta['tree']['sha']])
equal('recorded source head', source['head'], HEAD)
equal('source checkout clean during qualification', source['status'], '')
equal('recorded source before/after identity', source, read(ROOT / 'source-after.json'))
source_paths = [
    'codex-rs/hepta-agentd/src/native_memory_types.rs',
    'codex-rs/hepta-agentd/src/native_memory_tick_owner.rs',
    'codex-rs/hepta-agentd/src/native_memory_model.rs',
    'codex-rs/hepta-agentd/src/native_memory_tick_binding.rs',
    'codex-rs/hepta-agentd/src/native_memory_shadow_namespace.rs',
    'codex-rs/hepta-agentd/examples/native_memory_shadow.rs',
    'codex-rs/hepta-agentd/examples/native_memory_shadow_support/mod.rs',
    'codex-rs/hepta-agentd/examples/native_memory_shadow_support/evidence.rs',
    'codex-rs/hepta-memory/src/memory_cell_types.rs',
    'codex-rs/hepta-memory/src/memory_cell_source.rs',
    'codex-rs/hepta-memory/src/memory_cell_invocation.rs',
    'codex-rs/hepta-memory/src/production_writer.rs',
    'codex-rs/hepta-cognitive-types/src/wire.rs',
    'codex-rs/hepta-neuron/src/runtime_types.rs',
    'codex-rs/hepta-neuron/src/runtime_shadow_types.rs',
    'codex-rs/hepta-neuron/src/runtime_shadow.rs',
    'scripts/memory_cell_native/native_backend.py',
    'scripts/memory_cell_native/native_worker.py',
    'scripts/memory_cell_network/model_child.py',
    'codex-rs/hepta-neuron/src/runtime_tick.rs',
    'codex-rs/hepta-neuron/src/sparse.rs',
    'codex-rs/hepta-neuron/src/journal.rs',
    'codex-rs/hepta-neuron/src/witness.rs',
    'scripts/memory_cell_native/native_tick_contract.py',
    'scripts/memory_cell_native/shadow/native_shadow_ci.py',
]
archived_sources = {}
with tarfile.open(ROOT / 'executed-source.tar.gz', 'r:gz') as archive:
    equal('git archive embedded exact commit', archive.pax_headers['comment'], HEAD)
    for name, info in source['files'].items():
        member = archive.extractfile(name)
        if member is None: raise AssertionError(('archive source absent', name))
        archived_sources[name] = member.read()
        equal('archived pinned source: ' + name, sha(archived_sources[name]), info['sha256'])
    equal('all manually audited canonical paths are archived', set(source_paths).issubset(archived_sources), True)

report = read(ROOT / 'report.json')
engineering = read(OWNER / 'report.json')
evidence = read(OWNER / 'read-evidence.json')
execution = read(OWNER / 'raw-execution.json')
use = read(OWNER / 'source-use.json')
binding = use['binding']
query = read(OWNER / 'read-query.json')
model = read(ROOT / 'shadow_config.json')
profile = read(OWNER / 'registered-shadow-profile.json')
registration, frozen = read(ROOT / 'registration.json'), read(ROOT / 'frozen-after.json')
inspection = registration['inspection']
equal('CI v2 uses the actual in-job v1 config', registration['original_config_sha256'], sha((RUN / 'trial/native_config.json').read_bytes()))
equal('CI v2 binds the actual in-job v1 report', registration['original_v1_report_sha256'], sha((RUN / 'report.json').read_bytes()))
equal('CI source provenance agrees for v1/v2', registration['original_v1_source_head'], HEAD)
equal('v2 registered config pin set is unchanged from this CI v1', model['pins'], registration['original_config']['pins'])
equal('only width/config-id/receipt-directory change for v2', sorted(k for k in model if model[k] != registration['original_config'][k]), ['config_id', 'output_width', 'receipt_directory'])
equal('v1 artifacts unchanged across shadow execution', frozen['files'], registration['frozen_before'])
equal('checkpoint unchanged across shadow execution', frozen['checkpoint'], registration['checkpoint_before'])
checkpoint = RUN / 'trial/checkpoint'
for name, info in frozen['checkpoint'].items():
    equal('retained CI checkpoint member: ' + name, {'bytes': (checkpoint/name).stat().st_size, 'sha256': sha((checkpoint/name).read_bytes())}, info)
for name, info in inspection['runtime']['sources'].items():
    equal('runtime pin includes actual archived Python source: ' + name, {'bytes': len(archived_sources[name]), 'sha256': sha(archived_sources[name])}, info)
equal('full runtime pin recomputed from retained version/executable/source inventory', sha(compact(inspection['runtime'], ordered=False)), model['pins']['runtime_digest'])
equal('base identity recomputed from retained model inventory', sha(compact(inspection['model'], ordered=False)), model['pins']['base_identity'])
equal('actual adapter bytes bind pinned checkpoint', sha((checkpoint/'adapter_model.safetensors').read_bytes()), model['pins']['adapter_sha256'])
equal('actual lineage bytes bind pinned manifest', sha((checkpoint/'lineage.json').read_bytes()), model['pins']['manifest_sha256'])
equal('full model weights pin derives from base and adapter identities', sha((model['pins']['base_identity'] + model['pins']['adapter_sha256']).encode()), model['pins']['weights_digest'])
tokenizer_inventory = {k:v for k,v in inspection['model'].items() if 'token' in k or k in ('vocab.json','merges.txt')}
equal('tokenizer inventory pin', sha(compact(tokenizer_inventory, ordered=False)), model['pins']['tokenizer_digest'])
for pin, name in [('worker_sha256','scripts/memory_cell_native/native_worker.py'),('launcher_sha256','scripts/memory_cell_network/model_child.py')]:
    equal('actual archived executable-source pin: ' + pin, sha(archived_sources[name]), model['pins'][pin])
training = read(RUN / 'trial/training.json')
train_command = read(RUN / 'commands/train-96/receipt.json')
train_request = read(RUN / 'commands/train-96/request.json')
equal('this CI actually ran one successful training command', [train_command['attempts'], train_command['exit_code'], train_command['timed_out']], [1,0,False])
equal('this CI training command is explicit train subcommand', 'train' in train_request['argv'], True)
equal('CI fresh training has no learned parent', [training['receipt']['steps'], training['receipt']['actual_model_forwards'], len(training['receipt']['losses']), training['receipt']['initialization'], training['receipt']['learned_parent_manifest_sha256'], training['receipt']['previous_write_receipt_sha256']], [96,96,96,'frozen_base',None,None])
equal('shadow adds no training and reuses this CI checkpoint', [report['training_updates_added'], report['training_updates_reused']], [0,96])
equal('training output and shadow pinned checkpoint agree', training['manifest_sha256'], model['pins']['manifest_sha256'])
context = read(OWNER / 'context-provider.json')
production = read(OWNER / 'production-source.json')
tombstone = read(OWNER / 'source-tombstone.json')
hnmf = read(OWNER / 'hnmf-event.json')
process_dirs = list((ROOT / 'native-process-receipts').iterdir())
equal('actual native process receipt directory count', len(process_dirs), 1)
process_dir = process_dirs[0]
request_bytes = (process_dir / 'request.json').read_bytes()
request = json.loads(request_bytes)
neuron = request['neuron_request']
tick = request['tick_binding']
obs = evidence['observation']
pins = request['pins']
equal('request is actual v2', request['schema'], 'hepta.memory-cell.native-request.v2')
equal('retained request bytes bind directory and raw result', sha(request_bytes), execution['request_sha256'])
equal('process namespace equals request digest', process_dir.name, execution['request_sha256'])
equal('evidence request equals raw request', evidence['request'], request)
equal('raw Rust execution equals Python stdout', execution, read(process_dir / 'stdout.json'))
equal('evidence execution equals raw Rust execution', evidence['execution'], execution)
equal('evidence source equals separately retained source receipt', evidence['source'], use)
equal('committed source-use binds entire ordered raw execution', sha(compact(execution)), use['executionDigest'])
equal('all actual model pins match registered profile', pins, model['pins'])
equal('raw execution model pins match request', execution['pins'], pins)
equal('registered config file hash', profile['config_sha256'], sha((ROOT / 'shadow_config.json').read_bytes()))
equal('registered profile model', profile['model'], model)
for name in ('model_id', 'config_id', 'generation'):
    equal('registered neuron tuple ' + name, neuron[name], model[name])
equal('registered width', neuron['expected_output_width'], model['output_width'])
equal('width five shadow profile', model['output_width'], 5)
equal('request weights', neuron['weights_digest'], pins['weights_digest'])
equal('actual registered encoder identity', neuron['encoder_digest'], sha(b'hepta.memory-cell.query-utf8-q16-padded512.v1'))
equal('actual registered uncalibrated head identity', neuron['head_digest'], sha(b'hepta.memory-cell.hidden-tanh-and-next-token-top-probabilities.v1'))
equal('request nonce matches typed query', neuron['request_id'], query['requestId'])
equal('tick nonce matches native request', tick['tick_id'], neuron['request_id'])
equal('returned observation nonce', obs['tick_id'], tick['tick_id'])
equal('typed question has no source value appended', request['question'], f"What is the {query['key']['relation']} for {query['key']['entity']}?")
equal('actual execution question', execution['question'], request['question'])
equal('whole query including deadline digest', sha(compact(['hepta.memory-cell.query.v1', query])), request['query_digest'])
zero_binding = dict(binding); zero_binding['bindingDigest'] = '0' * 64
equal('owner/source binding digest', sha(compact(['hepta.memory-cell.owner-binding.v1', zero_binding])), binding['bindingDigest'])
equal('source binding query digest', binding['queryDigest'], request['query_digest'])
equal('request source binding', request['source_binding_digest'], binding['bindingDigest'])
equal('raw execution source binding', execution['source_binding_digest'], binding['bindingDigest'])
equal('raw execution query binding', execution['query_digest'], binding['queryDigest'])
source_bytes = production['write']['memory']['content'].encode()
equal('durable source and memory bytes', sha(source_bytes), binding['sourceContentSha256'])
equal('source memory content digest', binding['memoryContentSha256'], binding['sourceContentSha256'])
equal('model lineage root', request['source_root'], sha(source_bytes))
equal('actual typed source key', json.loads(source_bytes)['key'], query['key'])
equal('HNMF canonical event digest', sha(b'hepta.cognitive.contract.canonical-json.v1\0MemoryEventV1\0' + compact(hnmf, ordered=False)), binding['eventDigest'])
equal('HNMF typed semantic key', hnmf['semanticKeys'], ['memory-cell:' + sha(compact(['hepta.memory-cell.key.v1', query['key']]))])
equal('source production receipt identity', production['receipt_sha256'], binding['productionReceiptDigest'])
equal('source memory revision', production['write']['memory']['id'], binding['memory'])

for name, receipt in [('source', production), ('tombstone', tombstone)]:
    equal(name + ' write digest', framed(b'hepta:production-cognitive-mutation-write:v1', [compact(receipt['write'])]), receipt['write_digest'])
    parts = [struct.pack('>I', receipt['schema_version'])]
    parts += [receipt[k].encode() for k in ('namespace', 'mutation_kind', 'operation_digest', 'input_payload_sha256', 'source_content_sha256')]
    parts += [i64(receipt['source_observed_at_unix_seconds']), u64(receipt['expected_predecessor_revision'] or 0)]
    parts += [receipt[k].encode() for k in ('owner_agent_id', 'authority_grant_digest')]
    parts += [u64(receipt['authority_epoch']), u64(receipt['owner_epoch']), receipt['lease_id'].encode(), u64(receipt['generation'])]
    parts += [receipt[k].encode() for k in ('provenance_event_id', 'provenance_outbox_id', 'provenance_commit_event_id', 'write_digest')]
    equal(name + ' full mutation receipt digest', framed(b'hepta:production-cognitive-mutation-receipt:v1', parts), receipt['receipt_sha256'])

features = [byte << 16 for byte in request['question'].encode()]
features += [0] * (512 - len(features))
equal('actual full feature vector from typed question', neuron['feature_vector_q24'], features)
feature_digest = vector_digest(b'hepta.neuron.input-features.q24.v1', features)
equal('full feature digest', feature_digest, tick['input_feature_digest'])
tick_bytes = b'hepta.neuron.tick-input.v1' + identifier(tick['tick_id']) + identifier(tick['subject_id'])
tick_bytes += u64(tick['logical_sequence']) + u64(tick['monotonic_time_micros'])
tick_bytes += b''.join(digest(tick[k]) for k in ('checkpoint_digest', 'input_feature_digest', 'objective_digest', 'ndu_snapshot_digest'))
tick_bytes += b'\0' if tick['body_generation'] is None else b'\1' + u64(tick['body_generation'])
tick_bytes += b'\0' if tick['modulator_digest'] is None else b'\1' + digest(tick['modulator_digest'])
tick_digest = sha(tick_bytes + vector(features))
equal('full canonical tick digest', tick_digest, tick['tick_digest'])
equal('actual callback input digest', tick_digest, neuron['input_digest'])
equal('returned observation input digest', tick_digest, obs['input_digest'])
equal('explicit first-tick context shape', [tick['logical_sequence'], tick['checkpoint_digest'], tick['body_generation'], tick['modulator_digest']], [1, '0' * 64, None, None])
equal('actual monotonic tick clock is positive', tick['monotonic_time_micros'] > 0, True)
equal('source/query/full-tick join', sha(b'hepta.memory-cell.source-query-tick.v1' + digest(binding['bindingDigest']) + digest(binding['queryDigest']) + digest(tick_digest)), tick['joint_digest'])
for name, key in [('objective', 'objective_digest'), ('ndu', 'ndu_snapshot_digest')]:
    equal('actual controlled ' + name + ' file digest', sha((OWNER / f'{name}-context.json').read_bytes()), tick[key])
    equal('context provider ' + name + ' digest', context[key], tick[key])
equal('live context subject', context['subject_id'], tick['subject_id'])
equal('controlled actual context differs from HNMF fixture and source root', len({tick['objective_digest'], tick['ndu_snapshot_digest'], hnmf['objectiveDigest'], request['source_root']}), 4)

runtime = obs['model_runtime']
for field, pin in [('model_manifest_digest', 'manifest_sha256'), ('weights_digest', 'weights_digest'),
                   ('tokenizer_digest', 'tokenizer_digest'), ('preprocessor_digest', 'preprocessor_digest'),
                   ('quantization_digest', 'quantization_digest'), ('runtime_digest', 'runtime_digest'),
                   ('device_identity_digest', 'device_digest')]:
    equal('observed runtime matches actual registered pin: ' + field, runtime[field], pins[pin])
equal('observed actual runtime model/backend/quantization', [runtime['model_id'], runtime['backend_id'], runtime['quantization_id']], [model['model_id'], 'memory-cell:python-cpu', 'float32:none'])
equal('runtime resource measurements match actual execution', [runtime['latency_micros'], runtime['resident_bytes']], [execution['latency_micros'], execution['resident_bytes']])
runtime_bytes = b'hepta.neuron.local-model-runtime-receipt.v1' + identifier(runtime['model_id'])
runtime_bytes += b''.join(digest(runtime[k]) for k in ('model_manifest_digest', 'weights_digest', 'tokenizer_digest', 'preprocessor_digest'))
runtime_bytes += identifier(runtime['quantization_id']) + digest(runtime['quantization_digest']) + identifier(runtime['backend_id'])
runtime_bytes += digest(runtime['runtime_digest']) + digest(runtime['device_identity_digest']) + u64(runtime['latency_micros']) + u64(runtime['resident_bytes'])
runtime_digest = sha(runtime_bytes)
equal('independent runtime receipt digest', runtime_digest, obs['runtime_receipt_digest'])
output_digest = sha(b'hepta.neuron.model-output.q24.v1' + digest(runtime_digest) + u64(5) + vector(execution['drive_q24']) + u64(5) + vector(execution['prediction_q24']))
equal('actual model output digest', output_digest, obs['model_output_digest'])
equal('encoder/head/output/runtime binding', sha(b'hepta.neuron.model-runtime-binding.v1' + digest(neuron['encoder_digest']) + digest(neuron['head_digest']) + digest(output_digest) + digest(runtime_digest)), obs['model_runtime_digest'])
equal('activation vector digest', vector_digest(b'hepta.neuron.activation.q24.v1', obs['signals_q24']), obs['activation_digest'])
equal('first-tick temporal state digest', vector_digest(b'hepta.neuron.temporal-state.q24.v1', execution['drive_q24']), obs['temporal_state_digest'])

normalization = raw_sha(b'controlled-qualification:identity-q24-v1')
config_bytes = b'hepta.neuron.sparse-config.q24.v1' + digest(neuron['head_digest']) + normalization + u64(model['generation'])
config_bytes += vector([5, 1, 1 << 23, 1 << 24, 0, 1 << 21, 1 << 21, 1 << 23, -(1 << 24), 1 << 24])
native_config = sha(config_bytes)
profile_bytes = b'hepta.neuron.shadow-profile.v1' + identifier(model['config_id']) + identifier(model['model_id']) + u64(model['generation'])
profile_bytes += digest(pins['manifest_sha256']) + digest(neuron['encoder_digest']) + digest(neuron['head_digest'])
profile_bytes += b''.join(digest(pins[k]) for k in ('weights_digest', 'tokenizer_digest', 'preprocessor_digest', 'quantization_digest', 'runtime_digest', 'device_digest'))
profile_bytes += normalization + digest(native_config)
profile_bytes += b''.join(u64(v) for v in [512, 5, 1, 120000000, 120000000, 4 << 30, 1 << 20, 4000000])
profile_digest = sha(profile_bytes)
equal('full registered shadow profile digest', profile_digest, profile['shadow_profile_digest'])
namespace = sha(compact(['hepta.memory-cell.shadow-namespace.v1', production['owner_agent_id'], context['subject_id'], 'cell:controlled-native-shadow-qualification', binding['memory'], binding['memoryContentSha256'], binding['sourceContentSha256'], binding['eventDigest'], binding['productionReceiptDigest'], model['scope'], model['rank'], model['seed'], pins, profile_digest]))
anchors = read(OWNER / 'anchors-after-read.json')
equal('full source/model/profile namespace', namespace, anchors['namespace_digest'])
equal('unchanged anchors after replay/recovery/tombstone', anchors, read(OWNER / 'anchors-after-withdrawal.json'))
equal('journal/witness agree', anchors['journal_anchor'], anchors['witness_anchor'])
equal('returned checkpoint equals durable anchor', obs['checkpoint_after'], anchors['journal_anchor']['checkpoint_digest'])
subject_scope = raw_sha(b'hepta.neuron.subject-scope.v1' + identifier(context['subject_id']))
journal = (OWNER / 'shadow-journal').read_bytes()
witness = (OWNER / 'shadow-witness').read_bytes()
for name, raw in [('journal', journal), ('witness', witness)]:
    equal(name + ' actual file length', len(raw), anchors[name + '_bytes'])
    equal(name + ' actual complete file checksum', sha(raw), anchors[name + '_sha256'])
equal('journal actual root header', journal[:104], b'HPTNSJ01' + digest(native_config) + subject_scope + digest(context['objective_digest']))
equal('journal header checksum', raw_sha(journal[:104]), journal[104:136])
frame = journal[136:]
equal('one actual journal frame', len(frame), 384)
equal('journal frame checksum', raw_sha(frame[:-32]), frame[-32:])
body = raw_sha(b'hepta.neuron.body-binding.v1' + digest(neuron['head_digest']) + u64(model['generation']) + u64(0))
expected_tick = u64(1) + u64(tick['monotonic_time_micros']) + subject_scope + digest(context['objective_digest']) + digest(context['ndu_snapshot_digest']) + body + digest(tick_digest) + vector(execution['drive_q24']) + vector(execution['prediction_q24'])
equal('journal contains actual tick and raw model vectors', frame[:256], expected_tick)
equal('journal checkpoint predecessor and successor', frame[256:320], digest(obs['checkpoint_before']) + digest(obs['checkpoint_after']))
# Independently reconstruct the first sparse transition with exact signed Q24 arithmetic.
# This evaluates the retained five-element numeric receipt; it does not load or execute a model.
Q, H = 1 << 24, 8 << 24
params = {k: int(v) for k,v in re.findall(r'(\w+): (-?\d+)', profile['sparse_profile'])}
expected_params = {'width':5,'top_k':1,'temporal_decay_q24':Q//2,'inhibition_gain_q24':Q,'activity_decay_q24':0,'target_activity_q24':Q//8,'threshold_rate_q24':Q//8,'threshold_min_q24':-Q,'threshold_max_q24':Q,'eligibility_decay_q24':Q//2}
equal('actual registered numeric sparse parameters', params, expected_params)
equal('registered first-tick inhibition set is empty', 'inhibition: []' in profile['sparse_profile'], True)
def mul_q24(a, b):
    product = a*b; quotient, remainder = divmod(abs(product), Q)
    quotient += int(remainder*2 > Q or (remainder*2 == Q and quotient%2 == 1))
    return quotient * (1 if product > 0 else -1 if product < 0 else 0)
def clamp(v, lo, hi): return max(lo, min(hi, v))
drive, prediction = execution['drive_q24'], execution['prediction_q24']
equal('actual raw vector widths and bounds', len(drive) == len(prediction) == 5 and all(-H <= v <= H for v in drive + prediction), True)
temporal = [clamp(v, -H, H) for v in drive]
threshold = [clamp(0, -Q, Q)]*5
scores = sorted(((i,h-threshold[i]) for i,h in enumerate(temporal) if h-threshold[i] > 0), key=lambda pair:(-pair[1],pair[0]))
activation = [0]*5; projections = sum(a != b for a,b in zip(drive,temporal))
for i,score in scores[:1]: activation[i]=min(score,H); projections+=int(score > H)
activity = [Q if v > 0 else 0 for v in activation]
raw_threshold = [t + mul_q24(Q//8,rate-Q//8) for t,rate in zip(threshold,activity)]
threshold = [clamp(v,-Q,Q) for v in raw_threshold]
projections += sum(a != b for a,b in zip(raw_threshold,threshold))
eligibility = [mul_q24(d,a) for d,a in zip(drive,activation)]
norm = sum(abs(v) for v in eligibility)
if norm > 4*Q:
    eligibility = [(abs(v)*4*Q//norm)*(1 if v > 0 else -1 if v < 0 else 0) for v in eligibility]
    projections += 1
sparse_input_digest = raw_sha(subject_scope + digest(context['objective_digest']) + digest(context['ndu_snapshot_digest']) + body + digest(tick_digest) + vector(drive) + vector(prediction))
checkpoint_bytes = b'hepta.neuron.sparse-checkpoint.q24.v1' + digest(native_config) + subject_scope + digest(context['objective_digest']) + bytes(32) + sparse_input_digest + u64(1) + u64(tick['monotonic_time_micros'])
for values in [temporal,activation,activity,threshold,eligibility]: checkpoint_bytes += u64(len(values)) + vector(values)
checkpoint_digest = sha(checkpoint_bytes)
equal('independent sparse activation arithmetic', activation, obs['signals_q24'])
equal('independent full canonical checkpoint digest', checkpoint_digest, obs['checkpoint_after'])
equal('first checkpoint starts from zero', obs['checkpoint_before'], '0'*64)
active_ppm = sum(v > 0 for v in activation)*1_000_000//5
prediction_error = max(abs(a-b) for a,b in zip(drive,prediction))
equal('independent sparse active fraction', active_ppm, obs['sparsity_ppm'])
signal_bytes = b'hepta.neuron.journal-receipt.v1' + digest(native_config) + sparse_input_digest + vector(activation) + struct.pack('>I',active_ppm) + i64(prediction_error) + struct.pack('>I',projections) + bytes([1,0])
signal_digest = raw_sha(signal_bytes)
equal('canonical journal signal including requires-calibration and DENY_ALL bits', signal_digest, frame[320:352])
expected_frame = expected_tick + bytes(32) + digest(checkpoint_digest) + signal_digest
expected_frame += raw_sha(expected_frame)
equal('entire actual journal frame independently reconstructed', expected_frame, frame)

equal('witness namespace/objective/generation header', witness[:80], b'HPTNWA01' + digest(namespace) + digest(context['objective_digest']) + u64(1))
equal('witness header checksum', raw_sha(witness[:80]), witness[80:112])
equal('one actual witness record', len(witness), 224)
equal('witness acknowledges exact zero-to-one transition', witness[112:192], u64(0) + bytes(32) + u64(1) + digest(obs['checkpoint_after']))
equal('witness record checksum', raw_sha(witness[112:192]), witness[192:224])

replay = read(OWNER / 'replay-refusal.json')
delivery = read(OWNER / 'delivery-before-tombstone.json')
denied = read(OWNER / 'delivery-after-tombstone.json')
equal('replay refused for durable nonce reason', replay['error_kind'], 'Source(Replay)')
equal('replay did not dispatch', [replay['backend_dispatches_before'], replay['backend_dispatches_after']], [1, 1])
equal('fresh recovered instance successfully delivered before withdrawal', [delivery['delivery_allowed'], delivery['same_process_owner_recovered'], delivery['backend_dispatches']], [True, True, 1])
equal('actual forget mutation', tombstone['mutation_kind'], 'forget')
equal('same source memory advances revision one-to-two', [tombstone['write']['memory']['id']['memory_id'], tombstone['expected_predecessor_revision'], tombstone['write']['memory']['id']['revision']], [binding['memory']['memory_id'], 1, 2])
equal('actual memory tombstone lifecycle', tombstone['write']['memory']['lifecycle']['state'], 'tombstoned')
equal('withdrawal source exactly binds reason', tombstone['source_content_sha256'], sha(tombstone['write']['memory']['lifecycle']['reason'].encode()))
equal('delivery rejects changed source rather than generic failed owner', denied['error_kind'], 'Source(Invalid("current source revision or typed identity"))')
equal('tombstone denial without writer authority withdrawal', [denied['delivery_allowed'], denied['writer_authority_withdrawn']], [False, False])
equal('withdrawal did not dispatch', [denied['backend_dispatches_before'], denied['backend_dispatches_after']], [1, 1])
equal('unchanged controlled issuer across source and tombstone', production['authority_grant_digest'], tombstone['authority_grant_digest'])
process = read(process_dir / 'process.json')
bootstrap = json.loads((process_dir / 'stderr.log').read_text().splitlines()[0])
parent = read(ROOT / 'commands/pretrained-shadow/receipt.json')
equal('actual parent and model processes completed once', [parent['attempts'], parent['exit_code'], process['exit_code'], process['timed_out'], process['stdin_completed']], [1, 0, 0, False, True])
equal('model bootstrap PID and parent PID bind actual processes', [bootstrap['pid'], bootstrap['parent_pid'], bootstrap['expected_parent_pid'], process['parent_pid']], [process['pid'], parent['pid'], parent['pid'], parent['pid']])
equal('actual model callback and outputs count', [engineering['actual_backend_dispatches'], execution['decoder_queries'], execution['feature_forward_calls']], [1, 1, 1])
equal('actual fixed-adapter read control posture', [execution['adapter_enabled'], execution['base_unchanged'], execution['adapter_unchanged'], execution['facts_received'], execution['retrieval_received'], execution['answer_postprocessed']], [True, True, True, False, False, False])
equal('returned observation abstains and grants no authority', [obs['abstain'], obs['authority_grants_any'], evidence['calibration']], [True, False, None])
equal('qualification reports remain explicit about boundaries', [engineering['production_context_provider'], engineering['production_qualified'], engineering['default_daemon_installed'], engineering['v2_control_socket_exercised'], engineering['cross_process_recovery'], engineering['physical_unlearning'], engineering['same_process_owner_recoveries']], [False, False, False, False, False, False, 2])
equal('audited v2 evidence bytes unchanged', inventory(ROOT), before)
equal('audited same-CI v1 evidence bytes unchanged', inventory(RUN), v1_before)
equal('audited CI metadata/log bytes unchanged', {name: sha((PACKAGE/name).read_bytes()) for name in metadata_names}, metadata_before)
equal('audited original CI ZIP unchanged', sha(zip_path.read_bytes()), zip_digest)

result = {
    'schema': 'hepta.memory-cell.independent-ci-shadow-audit.v1',
    'ci': {'run_id':40149732280,'job_id':121038539566,'artifact_id':12581984329,'zip_sha256':zip_digest,'zip_bytes':zip_path.stat().st_size,'metadata_sha256':metadata_before},
    'method_sha256': sha(Path(__file__).read_bytes()),
    'reviewer': '/root/tick_shadow_recovery', 'source_head': HEAD,
    'evidence_root': str(ROOT), 'verdict': 'observed controlled v2 transaction and requested refusal invariants verified',
    'checks_passed': len(checks), 'checks': checks,
    'digests': {'query': binding['queryDigest'], 'source_binding': binding['bindingDigest'], 'full_tick': tick_digest,
                'source_query_tick_join': tick['joint_digest'], 'runtime_receipt': runtime_digest,
                'model_output': output_digest, 'model_runtime_binding': obs['model_runtime_digest'],
                'shadow_profile': profile_digest, 'sparse_config': native_config, 'source_profile_namespace': namespace,
                'checkpoint_after': checkpoint_digest, 'sparse_input': sparse_input_digest.hex(), 'journal_signal': signal_digest.hex(), 'journal_sha256': sha(journal), 'witness_sha256': sha(witness)},
    'recomputed_first_tick_state': {'temporal':temporal,'activation':activation,'activity':activity,'threshold':threshold,'eligibility':eligibility,'projections':projections,'prediction_error_q24':prediction_error},
    'ci_training_accounting': {'fresh_training_updates_in_v1':96,'training_model_forwards':96,'shadow_added_training_updates':0,'shadow_reuses_same_CI_updates':96,'local_reused96_experiment_included':False,'training_command_pid':train_command['pid'],'training_command_wall_seconds':train_command['wall_seconds']},
    'observed_process': {'parent_pid': parent['pid'], 'model_pid': process['pid'], 'actual_backend_dispatches': 1,
                         'decoder_queries': 1, 'feature_forward_calls': 1, 'new_dispatches_for_replay_or_withdrawal': 0},
    'ordering_basis': 'pinned executed Rust probe performs read, drops bootstrap owner, reads actual anchors, Recover plus exact Replay, drops poisoned instance, second Recover plus successful delivery, actual forget, precise Source::Invalid refusal, then verifies unchanged anchors; retained process exited0',
    'source_binding_scope': 'independent hashes recomputed from retained JSON and binary files; actual durable writer execution supported by pinned successful probe receipts; SQLite owner not reopened during audit',
    'qualification_limits': {'context_provider': 'controlled-qualification-context-v1', 'calibration': None, 'abstain': True,
        'authority_grants_any': False, 'default_daemon_installed': False, 'v2_control_socket_exercised': False,
        'production_NDU_attachment': False, 'production_objective_authority': False, 'production_qualified': False,
        'cross_process_recovery': False, 'same_process_owner_recoveries': 2, 'physical_unlearning': False,
        'independent_operational_witness_trust_qualified': False, 'future_task_superiority_qualified': False,
        'independent_first_tick_numeric_reconstruction': True, 'auditor_model_execution': False,
        'eight_research_or_production_gates_closed': [False]*8},
    'audit_operations': {'stdlib_only': True, 'model_imports': 0, 'model_executions': 0, 'Rust_builds_or_runs': 0,
        'SQLite_opens': 0, 'evidence_writes': 0, 'remote_writes': 0, 'new_experiments': 0},
    'audited_source_files': {name: source['files'][name] for name in source_paths},
    'audited_source_origin': 'immutable CI executed-source.tar.gz inside API-digest-verified ZIP, pinned to33c; current bootstrap source/test cycle excluded',
    'proof_limits': ['Logical durable SQLite nonce/source rows were not reopened or reconstructed; ordering and refusal causality rely on the archived executed probe plus successful real process and precise retained error kinds.', 'Base-model and Python-executable bytes are not retained in this ZIP; their pinned inventory hashes are recomputed, but those large external bytes are not independently rehashed by this audit.', 'ZIP extraction modes are local extraction metadata, not proof of original runner permissions.', 'One exposed case, controlled context, same-process owner Recover only; no unseen-task comparison, calibration or production NDU attachment proof.'],
    'v1_evidence_inventory_sha256': sha(compact(v1_before, ordered=False)),
    'source_archive_sha256': sha((ROOT / 'executed-source.tar.gz').read_bytes()),
    'evidence_file_inventory_sha256': sha(compact(before, ordered=False)),
    'evidence_files': before,
}
OUT.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'path': str(OUT), 'bytes': OUT.stat().st_size, 'sha256': sha(OUT.read_bytes()), 'checks_passed': len(checks)}, indent=2))
