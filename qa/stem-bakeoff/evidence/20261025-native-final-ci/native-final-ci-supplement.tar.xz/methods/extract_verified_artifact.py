"""Extract the original completed artifact once, after external digest admission."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
ZIP = ROOT / 'native-memory-40149732280-1.zip'
OUT = ROOT / 'artifact'


def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def main():
    metadata = json.loads((ROOT / 'artifact-12581984329.json').read_text())
    archive_hash = sha(ZIP)
    assert ZIP.stat().st_size == metadata['size_in_bytes']
    assert 'sha256:' + archive_hash == metadata['digest']
    assert metadata['workflow_run']['id'] == 40149732280
    assert metadata['workflow_run']['head_sha'] == '33c741cb0abe5faac1d92abe5d0ac90bee4abb51'
    if OUT.exists():
        raise ValueError('create-new extraction required')
    with zipfile.ZipFile(ZIP) as archive:
        entries = archive.infolist()
        if sum(row.file_size for row in entries) > 400 * 1024 * 1024:
            raise ValueError('extraction exceeds declared local storage allowance')
        names = set()
        for row in entries:
            path = PurePosixPath(row.filename)
            if path.is_absolute() or '..' in path.parts or '\\' in row.filename or str(path) != row.filename.rstrip('/'):
                raise ValueError('unsafe or noncanonical archive member')
            if row.filename in names or stat.S_ISLNK(row.external_attr >> 16):
                raise ValueError('duplicate or symlink archive member')
            names.add(row.filename)
        OUT.mkdir()
        inventory = {}
        for row in entries:
            target = OUT / row.filename
            if row.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256()
            length = 0
            with archive.open(row) as source, target.open('xb') as destination:
                for chunk in iter(lambda: source.read(1024 * 1024), b''):
                    destination.write(chunk)
                    digest.update(chunk)
                    length += len(chunk)
            assert length == row.file_size and digest.hexdigest() == sha(target)
            inventory[row.filename] = {'bytes': length, 'sha256': digest.hexdigest(), 'zip_external_attr': row.external_attr, 'zip_crc32': row.CRC}
    assert sha(ZIP) == archive_hash
    report = {'schema': 'hepta.final-ci-zip-extraction.v1', 'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'artifact_id': metadata['id'], 'zip_sha256': archive_hash, 'zip_bytes': ZIP.stat().st_size,
              'file_count': len(inventory), 'file_bytes': sum(row['bytes'] for row in inventory.values()),
              'all_extracted_bytes_readback_equal': True, 'original_runner_modes_proven': False,
              'signed_url_retained': False, 'inventory': inventory}
    with (ROOT / 'extraction-receipt.json').open('x') as output:
        output.write(json.dumps(report, sort_keys=True, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'inventory'}))


if __name__ == '__main__':
    main()
