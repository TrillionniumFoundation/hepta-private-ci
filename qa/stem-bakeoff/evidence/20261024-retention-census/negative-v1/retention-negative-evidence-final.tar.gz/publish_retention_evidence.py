"""Prepare a compact repository evidence bundle from already sealed results.

No fitting, scoring selection, downloads, repository mutation or remote calls.
The existing independent arithmetic audit must match every supplied input.
"""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

from audit_retention import read_bytes, read_json, require, digest


SOURCE_COMMIT = "6b8f3651b062d5c59659c8e7b67f60c2724adafb"
ARCHIVE_SHA = "7683b135579b62f72a16d405a033b0fb7699dbf753513106637af91a7441cf21"
EXPECTED_PAYLOADS = {"data/data_receipt.json", "data/final_labels.json", "data/sources.json",
    "environment.json", "execution-results.json", "features-report.json", "run/frozen_predictions.npz",
    "run/input_manifest.json", "run/protocol.json", "run/seal.json", "run/summary.json",
    "score-receipt.json", "score.json"}


def write_json(path, value):
    with Path(path).open("xb") as stream:
        stream.write(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode() + b"\n")


def measured_stage(value):
    require(value["exit"] == 0 and value["resource_fields"] == ["user_seconds", "system_seconds",
        "maximum_individual_process_rss_kib", "elapsed_seconds", "exit"], "stage receipt shape")
    user, system, rss, elapsed, status = value["resource_line"].split()
    require(status == "0", "stage process failure")
    return {"stage": value["stage"], "outer_wall_seconds": value["wall_seconds"],
        "user_seconds": float(user), "system_seconds": float(system),
        "cpu_seconds_rounded": float(user) + float(system), "elapsed_seconds_rounded": float(elapsed),
        "maximum_individual_process_rss_bytes": int(rss) * 1024,
        "finished_utc": value["finished_utc"],
        "scope": "Original outer process receipt; CPU rounded to 0.01s, maximum RSS is not simultaneous process-tree RSS."}


def cost_report(raw, audit):
    plan, _ = read_json(raw / "run/protocol.json")
    summary, _ = read_json(raw / "run/summary.json")
    inputs, _ = read_json(raw / "run/input_manifest.json")
    feature, feature_sha = read_json(raw / "features-report.json")
    cohort, cohort_sha = read_json(raw / "data/data_receipt.json")
    stages, _ = read_json(raw / "execution-results.json")
    score_receipt, _ = read_json(raw / "score-receipt.json")
    environment, _ = read_json(raw / "environment.json")
    require(feature_sha == inputs["inputs"]["feature_report"]["sha256"], "feature report differs from sealed input")
    require(cohort_sha == plan["cohort_receipt_sha256"] == inputs["inputs"]["data_receipt"]["sha256"],
            "cohort receipt differs from sealed input")
    require(environment["source_commit_observed"] == SOURCE_COMMIT
            and environment["protocol_sha256"] == audit["verified_input_hashes"]["protocol.json"],
            "environment receipt identity mismatch")
    require(feature["plan"]["source_ids"] == summary["row_source_ids"]
            and feature["plan"]["labels_enter_encoder"] is False and feature["encoder_updates"] == 0,
            "shared encoding identity mismatch")
    require(feature["shape"] == [480, 384] and feature["tensor_bytes"] == 480 * 384 * 4,
            "shared feature dimensions mismatch")
    require(all(item["checkpoint_inventory_sha256"] == plan["encoder_inventory_sha256"]
                and item["checkpoint_revision"] == plan["encoder_revision"]
                and item["device"] == "cpu" and item["mode"] == "SHADOW_ONLY"
                and item["authority"] == "DENY_ALL" for item in feature["receipts"]),
            "encoder receipt identity mismatch")
    require(len(feature["receipts"]) == feature["encoding"]["forward_calls"] == 30,
            "shared encoding census mismatch")
    require(summary["shared_feature_cost"] == {k: feature[k] for k in
            ("encoder_load", "encoding", "tensor_bytes", "peak_rss_bytes")}, "feature cost binding mismatch")
    require(score_receipt["exit"] == 0
            and score_receipt["score_sha256"] == audit["verified_input_hashes"]["score.json"]
            and score_receipt["external_seal_sha256"] == audit["verified_input_hashes"]["seal.json"],
            "outer scoring receipt mismatch")
    require({s["stage"] for s in stages} == {"features", "census"} and len(stages) == 2,
            "outer stage census mismatch")
    grouped = audit["cost_audit"]["per_head_arm"]
    ratios = []
    for head in ("linear", "gated"):
        rows = {v["arm"]: v for v in grouped if v["head"] == head}
        legacy = rows["legacy_full_quadratic"]["reaped_worker_cpu_ns"]
        hinge = rows["retention_hinge_suffix"]["reaped_worker_cpu_ns"]
        ratios.append({"head": head, "hinge_over_legacy_reaped_cpu": hinge / legacy,
                       "extra_cpu_ns_for_three_workers": hinge - legacy})
    legacy = sum(v["reaped_worker_cpu_ns"] for v in grouped if v["arm"] == "legacy_full_quadratic")
    hinge = sum(v["reaped_worker_cpu_ns"] for v in grouped if v["arm"] == "retention_hinge_suffix")
    return {"schema": "hepta.cell-retention.cost-audit.v1", "source_commit_observed": SOURCE_COMMIT,
        "original_experiment_environment": environment,
        "outer_stages_separate": [measured_stage(s) for s in stages],
        "census_accounting": audit["cost_audit"], "worker_cpu_ratios": ratios,
        "combined_hinge_over_legacy_reaped_cpu": hinge / legacy,
        "combined_extra_hinge_cpu_ns_for_six_workers": hinge - legacy,
        "owner_subsets_not_additive": {
            "six_warmups_cpu_ns": sum(i["warmup"]["cpu_ns"] for i in summary["initials"]),
            "six_reference_builds_cpu_ns": sum(i["reference_build"]["cpu_ns"] for i in summary["initials"]),
            "six_reference_builds_wall_ns": sum(i["reference_build"]["wall_ns"] for i in summary["initials"])},
        "shared_encoder_stage_subsets_not_additive": {k: feature[k]
            for k in ("encoder_load", "encoding", "shape", "tensor_bytes", "peak_rss_bytes")},
        "cohort_preparation_separate_internal_interval": {k: cohort[k] for k in ("wall_ns", "cpu_ns")},
        "scoring_separate": {"outer_wall_seconds": score_receipt["wall_seconds"],
                             **audit["scoring_interval_separate"]},
        "state_sizes_reported_not_process_memory": [{k: i[k] for k in
            ("seed", "head", "parameter_count", "private_parameters_bytes", "full_numeric_state_bytes")}
            for i in summary["initials"]],
        "missing_full_chain_costs": ["Complete original model/corpus acquisition and recovery intervals",
            "Complete source exclusion/feasibility and archive/publication intervals",
            "Any unreported preparatory or failed jobs outside this frozen 18-condition census"],
        "missing_costs_are_not_zero": True,
        "net_benefit_certified": False, "deployment_or_energy_claim": False, "authority": "DENY_ALL"}


def readme(audit, cost):
    lines = ["# Frozen retention experiment: negative result, independently recomputed", "",
        "All 18 preregistered conditions completed. Both heads failed both registered gates. "
        "The retention-hinge policy increased the primary future NLL relative to legacy, while "
        "the old-task noninferiority bound was not established. No policy was selected or retrained after this result.", "",
        "## Numerical result", "",
        "All differences are nats per example; lower is better. Intervals are the fixed 2,000-draw "
        "paired, category-stratified source-component bootstrap. The three fixed training seeds are "
        "averaged within each source first, and June/July receive equal weight.", "",
        "| Head | Future: hinge − legacy | 95% interval | Old test: hinge − original warmup | 95% interval | Future / retention / joint |",
        "|---|---:|---|---:|---|---|"]
    for head in ("linear", "gated"):
        row = audit["heads"][head]
        future = row["primary_future_nll_hinge_minus_legacy"]
        old = row["retention_old_test_nll_hinge_minus_original_warmup"]
        lines.append(f"| {head} | {future['estimate']:+.10f} | [{future['ci95'][0]:+.10f}, {future['ci95'][1]:+.10f}] "
                     f"| {old['estimate']:+.10f} | [{old['ci95'][0]:+.10f}, {old['ci95'][1]:+.10f}] | fail / fail / fail |")
    lines.extend(["", "The future gate requires the one-sided 97.5% upper bound to be below zero. "
        "The retention gate requires that upper bound to be at most +0.02 nats against the original warmup. "
        "The gated old-task point estimate improves; its wide interval still does not establish noninferiority. "
        "The linear old-task point estimate is slightly worse. Failure of the retention gate does not itself prove forgetting. "
        "Both primary future intervals are entirely positive, although their absolute effects are small.", "",
        "The published raw score includes every seed, month, zero comparator, balanced accuracy, "
        "and the secondary old-test contrast against legacy. No favorable subset replaces the primary result.", "",
        "## Cost and memory", "",
        "The table sums the three fresh workers per head/arm. CPU is reaped process CPU, including interpreter work. "
        "It excludes shared acquisition, encoding, projection, warmup and reference construction. Controller and "
        "phase timers are subsets of these totals, not extra costs to add.", "",
        "| Head | Arm | Reaped CPU seconds | Sequential supervisor wall seconds | Individual worker peak RSS, MiB range |",
        "|---|---|---:|---:|---|"])
    for row in audit["cost_audit"]["per_head_arm"]:
        lo, hi = [x / 1024**2 for x in row["process_peak_rss_bytes_range"]]
        lines.append(f"| {row['head']} | {row['arm']} | {row['reaped_worker_cpu_ns']/1e9:.6f} "
                     f"| {row['sequential_supervisor_wall_ns']/1e9:.6f} | {lo:.3f}–{hi:.3f} |")
    lines.extend(["", f"Across both heads, hinge uses {cost['combined_hinge_over_legacy_reaped_cpu']:.6f}× "
        "the measured legacy worker CPU, an additional "
        f"{cost['combined_extra_hinge_cpu_ns_for_six_workers']/1e9:.6f} CPU seconds over six workers. "
        "This finite-run ratio is not a load benchmark or a deployment SLA.", "",
        "Shared costs remain visible: the outer encoder stage reports 27.90 CPU seconds and "
        "35.619165458 wall seconds; the outer 18-condition census reports 45.75 CPU seconds "
        "and 47.443987808 wall seconds. The internal census reports 35.750854784 owner CPU seconds "
        "+ 9.776401 reaped-worker CPU seconds = 45.527255784 seconds before final publication work. "
        "Its six reference builds use 34.233840194 CPU seconds and six warmups 0.801555715 seconds, "
        "already included in owner CPU. The outer process measurements include more startup/exit/publication work "
        "and are rounded; they must not be added to their internal subintervals.", "",
        "The feature process peak RSS is 1,316,458,496 bytes. The fixed encoder reports 97,441,152 "
        "loaded parameters and 389,764,864 resident tensor-storage bytes. The small trainable heads contain "
        "36 or 52 parameters; their full numeric optimizer states contain 864 or 1,248 bytes. "
        "These head-state sizes are not total process or agent memory. Individual RSS peaks cannot be summed "
        "into a simultaneous process-tree memory estimate.", "",
        "The compact receipts do not establish all acquisition, source-exclusion, recovery and publication costs. "
        "Missing costs are not zero. This result certifies no net benefit, energy saving or production activation.", "",
        "## Audit and provenance", "",
        f"- Original observed source commit: `{SOURCE_COMMIT}`.",
        f"- Protocol SHA-256: `{audit['verified_input_hashes']['protocol.json']}`.",
        f"- Prediction seal SHA-256: `{audit['verified_input_hashes']['seal.json']}`.",
        f"- Original score SHA-256: `{audit['verified_input_hashes']['score.json']}`.",
        f"- Transfer archive SHA-256: `{ARCHIVE_SHA}`.",
        f"- Independent maximum absolute numerical discrepancy: `{audit['maximum_absolute_score_difference']:.18g}` "
        f"(comparison tolerance `{audit['comparison_absolute_tolerance']}`).", "",
        "The arithmetic auditor and evidence publisher verify 13 transferred payload identities, the seal bindings, all 12 registered "
        "execution/scoring source files, the 18 conditions and 6 warmup predictions, 480 unique source/component "
        "identities, and the 288 aligned final labels. It does not import the original scorer or execute training. "
        "The original run reports complete-state and serving-head reload equality; complete checkpoints and the "
        "feature matrix remain outside this compact bundle, so this arithmetic audit does not independently "
        "rerun encoder inference, training or checkpoint restoration. The audit also cannot prove absence of "
        "unrecorded external label access outside the recorded experiment.", "",
        "```sh", "python3 audit_retention.py --run raw/run --data raw/data --score raw/score.json \\",
        "  --source registered-source --output independently-recomputed.json", "```", "",
        "The original experiment used Python 3.13.12 / NumPy 2.2.6. This independent arithmetic recomputation "
        "used the environment recorded in `audit.actual.json`; the exact input bytes are preserved. "
        "`raw/MANIFEST.json` authenticates the transferred payloads and `BUNDLE_MANIFEST.json` records this publication.", "",
        "## Limits", "",
        "This is one balanced, finite historical news-classification family with three fixed fits. "
        "Registered component disjointness does not prove semantic independence or absence from foundation-model "
        "pretraining. Bootstrap uncertainty does not cover arbitrary training seeds, new task families, or deployment traffic. "
        "The negative result applies to this frozen controller/model/data setup; it neither demonstrates general intelligence "
        "nor rules out every cell architecture. No agent task, cell splitting, learned network formation, production "
        "clock attachment, or Codex replacement benefit was tested here.", ""])
    return "\n".join(lines)


def publish(actual, audit, source, output, transfer_archive, archive):
    raw, source, target = Path(actual), Path(source), Path(output)
    manifest, _ = read_json(raw / "MANIFEST.json")
    require(set(manifest) == EXPECTED_PAYLOADS, "unexpected transfer inventory")
    require(digest(read_bytes(transfer_archive)) == ARCHIVE_SHA, "transfer archive hash mismatch")
    for name, expected in manifest.items():
        payload = read_bytes(raw / name)
        require({"bytes": len(payload), "sha256": digest(payload)} == expected, "transfer payload mismatch: " + name)
    audited, _ = read_json(audit)
    require(audited["status"] == "verified"
            and audited["auditor_source_sha256"] == digest(read_bytes(Path(__file__).with_name("audit_retention.py"))),
            "independent audit source differs")
    for name, sha in audited["verified_input_hashes"].items():
        relative = "score.json" if name == "score.json" else ("data/" if name in
            ("sources.json", "final_labels.json") else "run/") + name
        require(manifest[relative]["sha256"] == sha, "audit input differs from transfer")
    for name, sha in audited["verified_registered_source_hashes"].items():
        require(digest(read_bytes(source / name)) == sha, "registered source differs from audit")
    report = cost_report(raw, audited)
    target.mkdir(parents=True, exist_ok=False)
    for name in sorted({*manifest, "MANIFEST.json"}):
        destination = target / "raw" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(raw / name, destination)
    (target / "registered-source").mkdir()
    for name in sorted(audited["verified_registered_source_hashes"]):
        shutil.copyfile(source / name, target / "registered-source" / name)
    shutil.copyfile(audit, target / "audit.actual.json")
    for name in ("audit_retention.py", "publish_retention_evidence.py"):
        shutil.copyfile(Path(__file__).with_name(name), target / name)
    write_json(target / "cost-audit.json", report)
    (target / "README.md").write_text(readme(audited, report), encoding="utf-8")
    files = {str(path.relative_to(target)): {"bytes": len(data := read_bytes(path)), "sha256": digest(data)}
             for path in sorted(target.rglob("*")) if path.is_file()}
    write_json(target / "BUNDLE_MANIFEST.json", {"schema": "hepta.cell-retention.evidence-bundle.v1",
        "files": files, "no_new_model_execution": True, "authority": "DENY_ALL"})
    with Path(archive).open("xb") as stream:
        with gzip.GzipFile(fileobj=stream, mode="wb", filename="", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as tar:
                for path in sorted(target.rglob("*")):
                    if path.is_file():
                        payload = read_bytes(path)
                        info = tarfile.TarInfo(str(path.relative_to(target)))
                        info.size, info.mode, info.mtime = len(payload), 0o644, 0
                        tar.addfile(info, io.BytesIO(payload))
    return {"output": str(target), "files": len(files) + 1, "archive": str(archive),
            "archive_bytes": Path(archive).stat().st_size, "archive_sha256": digest(read_bytes(archive))}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("actual", "audit", "source", "output", "transfer-archive", "archive"):
        parser.add_argument("--" + name, required=True)
    print(json.dumps(publish(**vars(parser.parse_args())), indent=2))
