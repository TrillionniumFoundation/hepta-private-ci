# Source peer review: explicit partial graph audit

Reviewer: `/root/codex_architecture`. Read-only local source and retained test
log review. No actual graph audit, host operation, inference, hidden-label read,
or change to original experiment sources was performed by this reviewer.

## Verdict and reviewed identity

The final candidate is cleared for the separately recorded read-only actual
audit. No remaining concrete source blocker was found within its stated
partial-evidence scope. An actual audit result is still required.

- Script: `neuron-audit/graph-inference-benchmark/evidence-audit/audit_cell_graph_partial_v2.py`
- Bytes: 19,553.
- SHA-256: `aee46b227c9bcec695dcffae44e941d674d67a23b0799890240969f2b7529392`.
- Test log: `verification/partial-v2-recovery-binding-tests.log`, eight tests
  passed; SHA-256 `73601ce38a6375650d7dffb5e0f9a3504d7572ddbb81748cd2d1f8d326b01024`.
- Test source SHA-256:
  `072cfe23eb1a1304178b1bdc84146460f2ea52820fcbd5459122ea71329ded7f`.

## Concrete finding resolved

The initial script merely read the current old-recovery directory and labelled
the resulting list `original_recovery_census_unchanged`. Its primary-only
reporter comparison could still pass after A was rewritten or B/C were added.

The final script now checks A against the retained exact failure SHA
`758f4ffa3dbeede3a6cf9bb59694b56a8382c845d71d6e5b3733ff217b536c32`,
its original dispatch/request/schema and failed-parser message. B/C files must
remain absent. Any mismatch creates an explicit integrity issue and nonzero
exit. Numerical qualification is reported separately, and `unchanged` is now a
validated boolean. Two new constructed tests exercise rewriting A as completed
and inserting a new B record. The old candidate is retained in history.

## Substantive independence and census checks

The script does more than reread the original report. It reruns the pinned
original reporter with a bounded 60-second subprocess, retaining stdout/stderr
including timeout prefixes. It then reads each retained worker stdout, verifies
its exact bytes/hash, and uses the pinned original decoder for its strict
identity/format validation. From those decoded outputs it independently stacks
all six heads, computes `sum / 6`, and checks the archived arrays and original
tensor hashes. Only the original `b0-A` can be the reference.

The numerical comparison independently applies the frozen tolerance and both
per-head and mean argmax conditions. All 18 rows and 30 worker outputs must
qualify; a failed row is retained. Paired wall-time differences require all six
blocks and are independently recomputed using scalar arithmetic. No successful
subset, alternate reference or relaxed tolerance is selected.

The original reporter's field called `bitwise_equal` uses `np.array_equal`.
The peer-reviewed audit preserves that original comparison convention; this
field alone is not a generic proof about signed-zero byte representations.
Separate retained tensor byte hashes are checked against their original
receipts. This review does not change the frozen original reporter.

## Evidence limits remain intact

The retained prefix is checked by its pinned document, prefix hash, complete
record byte ranges and argument/response hashes. A prefix integrity failure
cannot return overall success. Even when the audit passes, the full original
native-call audit remains unavailable and the complete-cost flag stays false.
The missing original suffix and sealing/outer/helper costs are not reconstructed
or treated as zero. New recovery-v2 results cannot replace the old census.

The candidate qualifies retained numerical and descriptive scalar evidence; it
does not rerun inference, independently establish every lost Runtime receipt,
prove complete total-system cost, or establish any learning/AGI result. Local
fixture tests and this source review are distinct from root's actual audit.
