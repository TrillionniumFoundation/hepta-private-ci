# Independent source review: separate graph recovery validation v2

Reviewer: `/root/codex_architecture`. Scope: local, read-only source and retained
test-log review. No Runtime call, remote host operation, model call, original
worker execution, hidden-label read, or change to the frozen graph/native gate.

## Verdict

The final candidate has no remaining concrete source blocker within its stated
scope: one bounded lookup and exact-output validation for each of the three
original completed jobs. This is clearance to run the separately recorded
validation, not a claim that actual v2 recovery has passed.

The initial candidate was **not** cleared: concatenating many base64 `--part`
arguments into one `bash -c` string still exceeded the operating system's
single-argument limit for a large case record. The final callback now caps each
complete command at 98,304 bytes, stages independent 65,536-byte chunks, and
uses a small final seal command. The real local bash/Python regression retained
a 213,437-byte synthetic case record, with a largest command of 87,906 bytes.
Its second publication was refused without overwriting the original file.

## Exact reviewed identity

All nine protocol-pinned source files matched their declared byte lengths and
SHA-256 values. The generated JavaScript bundle was independently reconstructed
from those sources and matched its retained bytes exactly.

| Artifact | SHA-256 |
| --- | --- |
| `recovery_validation_protocol_v2.json` | `7e73a090d4942afc88aa188b8735388e7585ca54a987c79fc1d1b9b69ee66e50` |
| `cell_graph_recovery_validation_v2.js` | `de3a52ce433139686cae68558069a0950b3f1e67cc570bb210e49a1a4a2e163a` |
| `cell_graph_recovery_start_v2.js` | `2ce1d1db6986bed1aa4936dc4364ad433ba3e4e512b8c91ec0bf99d586dae006` |
| `cell_graph_recovery_journal_v2.js` | `01f54c25a372ffb549584951e95ed37261f68435485cd87cb7ac7ba45b605c1a` |
| `write_recovery_journal_v2.py` | `79cdafa66be0b84d012ebd1ac3bb8420141519347c9234d673e340a33c422a16` |
| `verification/recovery-bundle.json` (52,157 bytes) | `9ca6b0066452b7183b7ce46ce561188c04a27955b8f3c224a99e17e22a56c46a` |
| Bundled executable JavaScript (48,674 bytes) | `2d418ab04261c8a528d7bbcf78b1db30b30fb3c2c7e4a3ec48e876f0979cf2e5` |

Source directory:
`neuron-audit/graph-inference-benchmark/recovery-v2/`.
The original owner remains SHA
`a8f1e561f3bff60b0247351c27619a874403006cd44ee40035b2cc3c8a1de112`.

## Checked invariants

- The fixed order is `b0-A-s0`, `b0-B-s0`, `b0-C-s0`. Each lookup reuses the
  exact original serialized arguments, host, key, stdin, resources and timeout.
  The parser additionally binds job ID, request digest and the losslessly
  retained uint64 fingerprint. A fresh, rebound or retried launch is rejected.
- Completed-job reuse requires `reused: true`, `launch: null`,
  `retried_launch: false` and the original successful complete cached status.
  Fresh-start validation remains strict. New authoritative status/read/status
  observations must recover the exact original stdout and stderr, including
  their lengths, hashes and full byte content.
- The unchanged original owner retains its 24-call/60-second bounds. Journal
  acknowledgement time is included in each raw-call interval. After an intent
  write returns, another deadline check prevents starting a native call late.
  The original post-await check also retains a late result as a failed case.
- Start uncertainty is recorded before awaiting the API. Unknown or mismatched
  starts and failed journal acknowledgements block the next case. A known-ended
  output mismatch remains a failed case; it is never promoted to success.
- Every native call requires an exclusive intent file first. Its returned MCP
  JSON, argument/result hashes and original response are checkpointed before
  receipt interpretation. Chunk manifests, chunk files and final files use
  exclusive creation. A full-file SHA check precedes the final file write.
- The recovered 45 complete records retain exact ranges/hashes in the original
  persisted prefix. Missing suffix bytes, unparsed tail and the declared full
  ledger digest are not repaired or upgraded into verified evidence. The
  preparation stage verifies the three original starts and all 18 report/owner/
  reduction bindings without interpreting worker parameters or probabilities.
- The original failed A recovery and absent/unattempted B/C recoveries remain
  unchanged. New records use a distinct namespace. The original 18 primary
  results, workers, tolerances, graph budgets and source files are untouched.

## Validation evidence reviewed

These were retained author-run results, not tests rerun by this reviewer:

| Log | Observed result | SHA-256 |
| --- | --- | --- |
| `verification/node-frozen-run.log` | 20 constructed receipt/owner/journal tests pass; zero native host calls | `cefc40b86a598d5afb0eea727f7a09471a703144fe5c6466a1bb69c02058a6ff` |
| `verification/python-command-bound-run.log` | 19 prefix/preparation/exclusive-file tests pass | `effb9c3ae139c454472d662ab82e4f223ffb0e9759dd3186c95c6f2a214ed5c2` |
| `verification/journal-large-exec.log` | 3 real local shell/Python transport checks pass; zero Runtime/remote calls | `962fd5db0d37e5b93ebdaf73e579bbf4fbe6a0ca5acabbee270aa3ecbaac51d6` |

The large-record test changes only fixed writer/root paths into its owned local
fixture directory. It executes the actual callback-generated shell commands
and file writer. It does not mock successful filesystem publication.

## Limits that remain explicit

There is no automatic reconstruction of an interrupted controller's state from
the file journal. Existing exclusive intents instead prevent silent repeats;
an uncertain interruption requires inspection of the original recorded calls.
File and directory fsync are implemented, but power-loss recovery and archival
storage lifetime were not qualified. Root must copy/checksum new evidence after
each case and preserve the resulting acknowledgement.

The full original ledger and complete original total cost remain unverified.
Old worker CPU is not charged again for a reused output, and missing CPU/RSS or
service costs remain unknown. Added journal costs make these validation timings
unsuitable as an unbiased speed comparison against the original parser failure.
This review supports no claim about inference efficiency, crash recovery of the
worker, learning, agent competence or general intelligence.

The frozen native gate archive was separately rechecked unchanged: 71,473 bytes,
SHA `4668f409f82d96117784c350fa895b6536361caa9318feb6c1c30cd0ff79e857`,
with all 15 archived files identical to `backend_final_gate_stage/frozen-v1/`.
