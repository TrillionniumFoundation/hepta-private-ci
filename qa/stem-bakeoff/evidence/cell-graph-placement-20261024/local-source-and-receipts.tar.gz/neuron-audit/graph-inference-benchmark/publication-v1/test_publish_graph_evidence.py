"""Constructed custody/git tests only; no real graph, model, network or host."""

import argparse
import base64
import contextlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import tempfile
import unittest
from unittest import mock

import publish_graph_evidence as p


def run(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args], stderr=subprocess.PIPE).decode().strip()


def write(root, name, value):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    data = value if isinstance(value, bytes) else p.canonical(value)
    path.write_bytes(data)
    return p.sha(data)


class PublicationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo, self.evidence = self.root / "repo", self.root / "evidence"
        self.repo.mkdir(); self.evidence.mkdir()
        self.branch = "research/constructed-graph-publication"
        run(self.repo, "init", "-b", self.branch)
        run(self.repo, "config", "user.email", "constructed@example.invalid")
        run(self.repo, "config", "user.name", "Constructed publication test")
        run(self.repo, "config", "commit.gpgsign", "false")
        source_sha = write(self.repo, "protected.py", b"# unchanged original fixture\n")
        run(self.repo, "add", "protected.py"); run(self.repo, "commit", "-m", "constructed base")
        head = run(self.repo, "rev-parse", "HEAD")
        self.bare = self.root / "origin.git"; self.bare.mkdir()
        run(self.bare, "init", "--bare")
        run(self.repo, "remote", "add", "origin", str(self.bare))
        run(self.repo, "push", "origin", "HEAD:refs/heads/" + self.branch)
        graphs, report_rows = [], []
        for block in range(6):
            for arm in "ABC":
                graph_id = f"b{block}-{arm}"
                requests, workers = [], []
                for shard in range(1 if arm == "A" else 2):
                    request_id = graph_id + f"-s{shard}"
                    filename = request_id + ".json"
                    digest = write(self.evidence, "requests-v1/" + filename, {"constructed_request": request_id})
                    requests.append({"request_id": request_id, "request_file": filename, "request_sha256": digest})
                    data = ("constructed existing output " + request_id).encode()
                    workers.append({"stdout_base64": base64.b64encode(data).decode(), "stdout_sha256": p.sha(data), "stdout_bytes": len(data)})
                folder = "graphs/" + graph_id + "/"
                collection_sha = write(self.evidence, folder + "collection.json", {"workers": workers})
                predictions_sha = write(self.evidence, folder + "reduction/predictions.npz", b"constructed archive identity only")
                receipt_sha = write(self.evidence, folder + "reduction/receipt.json", {"status": "completed", "collection_sha256": collection_sha, "predictions_sha256": predictions_sha})
                owner_sha = write(self.evidence, folder + "owner.json", {"status": "completed", "reduction": {"receipt_sha256": receipt_sha}})
                graphs.append({"graph_id": graph_id, "requests": requests})
                report_rows.append({"graph_id": graph_id, "status": "completed", "owner_sha256": owner_sha, "reduction_sha256": receipt_sha})
        pins = {
            "requests-v1/dispatch.json": write(self.evidence, "requests-v1/dispatch.json", {"graphs": graphs}),
            "original-report.json": write(self.evidence, "original-report.json", {"rows": report_rows}),
            "graphs/recovery/b0-A-s0.json": write(self.evidence, "graphs/recovery/b0-A-s0.json", {"status": "failed", "original": True}),
        }
        audit = {"primary_independent_tensor_and_scalar_pass": True, "original_recovery_integrity": {"passed": True},
                 "issues": [], "complete_original_cost_audit_pass": False, "primary_rows": report_rows,
                 "retained_worker_output_count": 30, "retained_prefix": {"full_ledger_sha256_verified": False,
                 "retained_complete_records": 45, "declared_snapshot_records": 383, "present_chunks": 4, "declared_chunks": 34}}
        pins["partial-audit.json"] = write(self.evidence, "partial-audit.json", audit)
        for name in ["manifest.json"] + [f"part-{i:06d}.bin" for i in range(4)]:
            path = "raw/partial/" + name
            pins[path] = write(self.evidence, path, ("constructed prefix " + name).encode())
        export_sha = write(self.evidence, "graph.json", b"unchanged exported fixture")
        local = self.root / "local"; local.mkdir()
        write(local, "README.md", b"# Constructed publication\n")
        write(local, "recovery-audit.json", {"all_three_original_job_byte_reuses_qualified": True, "issues": [],
            "native_call_count": 25, "file_checkpoint_count": 59, "original_full_ledger_recovered": False,
            "original_whole_run_cost_complete": False, "cases": [{"request_id": f"b0-{arm}-s0", "status": "completed"} for arm in "ABC"]})
        write(local, "custody-audit.json", {"all_three_archive_bytes_manifests_and_actual_write_acks_match": True,
            "all_59_final_checkpoint_files_present_and_exact": True, "all_25_native_intent_result_pairs_present": True})
        rows = p.snapshot(local)
        bundle = self.root / "local.tar.gz"
        archive = p.make_archive(local, rows, bundle)
        self.spec = {"schema": "hepta.fixed-cell-graph.publication-spec.v1", "worktree": str(self.repo),
                     "evidence_root": str(self.evidence), "base_head": head, "branch": self.branch,
                     "destination": "qa/stem-bakeoff/evidence/constructed-case", "protected_source_pins": {"protected.py": source_sha},
                     "artifact_pins": pins, "required_content_hashes": [export_sha], "raw_directory": "raw/partial",
                     "must_remain_absent": ["raw/partial/ledger.json", "graphs/recovery/b0-B-s0.json", "graphs/recovery/b0-C-s0.json"],
                     "report_path": "original-report.json", "partial_audit_path": "partial-audit.json",
                     "recovery_audit_bundle_path": "recovery-audit.json", "custody_audit_bundle_path": "custody-audit.json",
                     "readable_local_files": {"README.md": "README.md"}, "local_bundle": {**archive, "files": rows}}
        spec_path = self.root / "spec.json"; spec_path.write_bytes(p.canonical(self.spec))
        self.args = argparse.Namespace(spec=spec_path, spec_sha256=p.sha(spec_path.read_bytes()), bundle=bundle, state=self.root / "state")

    def test_full_census_accepts_only_actual_retained_scope(self):
        result = p.validate_evidence(self.evidence, p.snapshot(self.evidence), self.spec)
        self.assertEqual(result["retained_worker_outputs"], 30)
        self.assertFalse(result["complete_original_cost_audit"])

    def test_missing_graph_artifact_rejected(self):
        (self.evidence / "graphs/b2-C/collection.json").unlink()
        with self.assertRaises((ValueError, FileNotFoundError)):
            p.validate_evidence(self.evidence, p.snapshot(self.evidence), self.spec)

    def test_changed_original_failure_rejected(self):
        write(self.evidence, "graphs/recovery/b0-A-s0.json", {"status": "completed"})
        with self.assertRaises(ValueError):
            p.validate_evidence(self.evidence, p.snapshot(self.evidence), self.spec)

    def test_new_old_recovery_cannot_replace_absence(self):
        write(self.evidence, "graphs/recovery/b0-B-s0.json", {"status": "completed"})
        with self.assertRaises(ValueError):
            p.validate_evidence(self.evidence, p.snapshot(self.evidence), self.spec)

    def test_missing_ledger_cannot_be_synthesized(self):
        write(self.evidence, "raw/partial/ledger.json", {"fabricated": True})
        with self.assertRaises(ValueError):
            p.validate_evidence(self.evidence, p.snapshot(self.evidence), self.spec)

    def test_archive_input_change_retains_failed_output(self):
        rows = p.snapshot(self.evidence)
        write(self.evidence, "graph.json", b"changed after census")
        output = self.root / "failed.tar.gz"
        with self.assertRaises(ValueError):
            p.make_archive(self.evidence, rows, output)
        self.assertTrue(output.exists())

    def test_symlink_rejected_without_reading_outside(self):
        (self.evidence / "escape").symlink_to(self.repo / "protected.py")
        with self.assertRaises(ValueError):
            p.snapshot(self.evidence)

    def test_tar_traversal_rejected_without_extracting(self):
        path = self.root / "unsafe.tar"
        with tarfile.open(path, "w") as archive:
            item = tarfile.TarInfo("../outside"); item.size = 1
            archive.addfile(item, io.BytesIO(b"x"))
        with self.assertRaises(ValueError):
            p.verify_archive(path, [])
        self.assertFalse((self.root / "outside").exists())

    def test_exclusive_receipt_never_overwrites(self):
        path = self.root / "intent.json"
        p.exclusive(path, b"original")
        with self.assertRaises(FileExistsError):
            p.exclusive(path, b"replacement")
        self.assertEqual(path.read_bytes(), b"original")

    def test_prepare_rejects_modified_original_source_before_install(self):
        write(self.repo, "protected.py", b"changed")
        with self.assertRaises(ValueError):
            p.prepare(self.args)
        self.assertFalse((self.repo / self.spec["destination"]).exists())

    def test_origin_identity_does_not_accept_local_bare_test_remote(self):
        with self.assertRaises(ValueError):
            p.check_origin(self.repo)

    def test_staged_blob_corruption_rejected_even_when_worktree_is_exact(self):
        with contextlib.redirect_stdout(io.StringIO()):
            p.prepare(self.args)
        prepared = json.loads((self.args.state / "PREPARED.json").read_bytes())
        path = self.spec["destination"] + "/README.md"
        run(self.repo, "add", "--force", "--", self.spec["destination"])
        blob = subprocess.check_output(["git", "-C", str(self.repo), "hash-object", "-w", "--stdin"], input=b"index-only corruption").decode().strip()
        run(self.repo, "update-index", "--cacheinfo", "100644," + blob + "," + path)
        self.assertEqual((self.repo / path).read_bytes(), b"# Constructed publication\n")
        with self.assertRaisesRegex(ValueError, "staged blob differs"):
            p.staged_tree(self.repo, self.spec, prepared)

    def test_precommit_hook_tree_mutation_retained_without_push(self):
        with contextlib.redirect_stdout(io.StringIO()):
            p.prepare(self.args)
        path = self.spec["destination"] + "/README.md"
        hook = self.repo / ".git/hooks/pre-commit"
        hook.write_text("#!/usr/bin/env python3\nfrom pathlib import Path\nimport subprocess\n"
                        + "root=Path(" + repr(str(self.repo)) + ")\n"
                        + "path=" + repr(path) + "\n"
                        + "(root/path).write_text('constructed hook changed the staged publication\\n')\n"
                        + "subprocess.check_call(['git','-C',str(root),'add','--force','--',path])\n")
        hook.chmod(0o755)
        with mock.patch.object(p, "check_origin"):
            with self.assertRaisesRegex(ValueError, "commit tree differs"):
                p.publish(self.args)
        intent = json.loads((self.args.state / "commit-intent.json").read_bytes())
        self.assertNotEqual(run(self.repo, "rev-parse", "HEAD^{tree}"), intent["expected_tree"])
        self.assertEqual(run(self.bare, "rev-parse", "refs/heads/" + self.branch), self.spec["base_head"])
        self.assertFalse((self.args.state / "push-intent.json").exists())
        self.assertFalse((self.args.state / "COMMITTED.json").exists())
        self.assertTrue((self.args.state / "commit-result.json").exists())

    def test_one_real_local_git_commit_push_and_readonly_confirmation(self):
        with contextlib.redirect_stdout(io.StringIO()):
            p.prepare(self.args)
            # Only the production GitHub identity guard is mocked: all git
            # operations below execute against a new temporary local bare repo.
            with mock.patch.object(p, "check_origin"):
                p.publish(self.args)
                head = run(self.repo, "rev-parse", "HEAD")
                p.confirm(self.args)
                self.assertEqual(run(self.repo, "rev-parse", "HEAD"), head)
                with self.assertRaises(FileExistsError):
                    p.publish(self.args)
        self.assertEqual(run(self.bare, "rev-parse", "refs/heads/" + self.branch), head)
        self.assertEqual(run(self.repo, "rev-parse", head + "^"), self.spec["base_head"])
        self.assertEqual(run(self.repo, "status", "--porcelain"), "")
        self.assertTrue((self.args.state / "PUSH_OBSERVATION.json").exists())
        intent = json.loads((self.args.state / "push-intent.json").read_bytes())
        self.assertEqual(intent["argv"][-1], head + ":refs/heads/" + self.branch)
        self.assertNotIn("HEAD:", intent["argv"][-1])


if __name__ == "__main__":
    unittest.main(verbosity=2)
