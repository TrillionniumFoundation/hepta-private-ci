"""Freeze local graph-only source/receipts and an exact remote publication spec."""

import argparse
import json
from pathlib import Path

from publish_graph_evidence import canonical, exclusive, make_archive, regular, sha, snapshot


ROOT = Path(__file__).resolve().parents[3]
GRAPH = Path("neuron-audit/graph-inference-benchmark")
AUDIT = GRAPH / "evidence-audit"
REMOTE = "/home/qian-qi/workspace/hepta-cell-graph-evidence-20261024"
WORKTREE = "/home/qian-qi/workspace/hepta-cell-graph-benchmark-20261024"


def main(output):
    output.mkdir(parents=False, exist_ok=False)
    payload = output / "local-inputs"
    payload.mkdir()
    paths = set()
    for path in (ROOT / GRAPH).rglob("*"):
        relative = path.relative_to(ROOT)
        if not path.is_file() or "__pycache__" in relative.parts or "publication-v1" in relative.parts:
            continue
        if path.is_symlink():
            raise ValueError("source bundle may not contain symlinks")
        paths.add(relative)
    for name in ("publish_graph_evidence.py", "test_publish_graph_evidence.py", "build_publication_bundle.py", "PR_BODY.md", "RUNBOOK.md", "publication-tests.log", "publication-tests-v2.log"):
        paths.add(GRAPH / "publication-v1" / name)
    for path in (ROOT / GRAPH / "publication-v1/history").rglob("*"):
        if path.is_file() and "__pycache__" not in path.parts:
            paths.add(path.relative_to(ROOT))
    for path in (ROOT / "continued-session").iterdir():
        if path.is_file() and path.name.startswith(("graph_", "original_graph_", "prefix_", "recovery_v2_")):
            paths.add(path.relative_to(ROOT))
    for path in (ROOT / "continued-session/recovery-v2-custody").glob("*-receipt.json"):
        paths.add(path.relative_to(ROOT))
    for name in ("graph_actual_recovery_failure.json", "graph_native_api_contract.txt", "graph_native_api_sample.json",
                 "graph_native_terminal_status_sample.json", "graph_native_current_status_sample.json",
                 "backend_graph_independent_review.md", "backend_graph_native_adapter_review.md",
                 "backend_graph_recovery_v2_review.md", "backend_graph_partial_audit_review.md"):
        paths.add(Path(name))
    publication_review = ROOT / "backend_graph_publication_review.md"
    if publication_review.is_file():
        paths.add(publication_review.relative_to(ROOT))
    for relative in sorted(paths):
        exclusive(payload / relative, regular(ROOT / relative))
    rows = snapshot(payload)
    archive = make_archive(payload, rows, output / "local-source-and-receipts.tar.gz")
    inventory_envelope = json.loads(regular(ROOT / "continued-session/graph_inventory_read.json"))
    native_read = json.loads(inventory_envelope["content"][0]["text"])
    inventory = json.loads(bytes.fromhex(native_read["stdout"]["bytes_hex"]))
    observed_git = inventory["graph_git"]
    assert observed_git == {"branch": "research/cell-graph-placement-20261024", "head": "4435d4b93e130d12bfc24c45ead93fb4a30c4577", "status": ""}
    raw = inventory["raw"]
    assert len(raw) == 1
    raw_dir = Path(raw[0]["path"]).relative_to(REMOTE).as_posix()
    pins = {raw_dir + "/" + item["name"]: item["sha256"] for item in raw[0]["files"]}
    pins.update({
        "requests-v1/dispatch.json": "595d40d93a9ba394c21c39fd41c5c8b60ab5ceddfcdb8bdd9f5102ce193fa4ae",
        "graphs/recovery/b0-A-s0.json": "758f4ffa3dbeede3a6cf9bb59694b56a8382c845d71d6e5b3733ff217b536c32",
        "controller-continuity-v1/original-report.json": "6df19c646c3b610011b138a3f0cc870bc4523d23d5ae1bc2b52f78778dc39102",
        "controller-continuity-v1/independent-partial-audit-v2/partial-audit.json": "33824ede8355be4e27786209956329da5e3ce8e8dcba4ab1d5ac0c0a159a6b16",
        "controller-continuity-v1/recovered-prefix-v1/original-prefix.bin": "c0e41a7adf1c83943f61e146d49b43ff70ffb57800b82cb45f906275a1cfbcfc",
        "controller-continuity-v1/recovered-prefix-v1/complete-prefix-records.json": "bc9d9bf887c5f68fd34815f3ef7e71403bd888c06ff622f4c8c117f63d5cd913",
        "recovery-validation-v2-inputs/case-A-journal.tar.gz": "e5029a8ae54e5c8096d8b810cb208ea5289b8d0cfa044c44931682cf1e17f1ce",
        "recovery-validation-v2-inputs/case-B-journal.tar.gz": "93ca89e25dcda67917c6c4893b166d40f74d77a99195e9ab7626c8eacd18ff51",
        "recovery-validation-v2-inputs/case-C-journal.tar.gz": "169b45a7da7f7eff9e3d51158708e761a40a9dc55263b27be73a67332c34a52a",
    })
    protected = {}
    original = ROOT / GRAPH / "patch/qa/stem-bakeoff"
    for name in ("cell_graph_worker.py", "cell_graph_benchmark.py", "cell_graph_reduce.py", "cell_graph_report.py", "cell_graph_owner.js", "cell_graph_protocol.json"):
        protected["qa/stem-bakeoff/" + name] = sha(regular(original / name))
    for name in ("cell_graph_native_helpers.js", "cell_graph_native_adapter.js", "cell_graph_native_wrapper.py", "cell_graph_native_protocol.json"):
        protected["qa/stem-bakeoff/" + name] = sha(regular(ROOT / GRAPH / "native-adapter" / name))
    spec = {"schema": "hepta.fixed-cell-graph.publication-spec.v1", "worktree": WORKTREE, "evidence_root": REMOTE,
            "base_head": observed_git["head"], "branch": observed_git["branch"],
            "destination": "qa/stem-bakeoff/evidence/cell-graph-placement-20261024",
            "protected_source_pins": protected, "artifact_pins": pins, "raw_directory": raw_dir,
            "required_content_hashes": ["d586621af590751edf604d362a8a7a80045eb9a5748421976df93c74ba65a63e", "0da796e185bd8e0d65718ef2137f11b72c0372344078d9785574a8d31ea33ddc"],
            "must_remain_absent": [raw_dir + "/ledger.json", "graphs/recovery/b0-B-s0.json", "graphs/recovery/b0-C-s0.json"],
            "report_path": "controller-continuity-v1/original-report.json",
            "partial_audit_path": "controller-continuity-v1/independent-partial-audit-v2/partial-audit.json",
            "recovery_audit_bundle_path": str(AUDIT / "actual-v2-recovery-audit-final.json"),
            "custody_audit_bundle_path": str(AUDIT / "verification/actual-recovery-archive-custody.json"),
            "readable_local_files": {
                "README.md": str(AUDIT / "ACTUAL_FIXED_GRAPH_FINDINGS.md"),
                "recovery-v2-audit.json": str(AUDIT / "actual-v2-recovery-audit-final.json"),
                "recovery-archive-custody.json": str(AUDIT / "verification/actual-recovery-archive-custody.json"),
                "PUBLISHING.md": str(AUDIT / "PUBLISH_PARTIAL_ACTUAL_EVIDENCE.md"),
                "PR_BODY.md": str(GRAPH / "publication-v1/PR_BODY.md"),
                "publish_graph_evidence.py": str(GRAPH / "publication-v1/publish_graph_evidence.py"),
                "RUNBOOK.md": str(GRAPH / "publication-v1/RUNBOOK.md")},
            "local_bundle": {**archive, "files": rows},
            "limits": {"remote_all_regular_files_max": 4096, "remote_total_bytes_max": 268435456,
                       "remote_single_file_bytes_max": 16777216, "git_single_archive_bytes_max": 67108864},
            "scope": "Publication only. Exact retained census and explicit missing ledger/cost scope. No original experiment or native recovery call is rerun."}
    exclusive(output / "publication-spec.json", canonical(spec))
    final = {"local_bundle": archive, "local_files": len(rows), "spec_sha256": sha(canonical(spec)),
             "publisher_sha256": sha(regular(ROOT / GRAPH / "publication-v1/publish_graph_evidence.py")),
             "test_source_sha256": sha(regular(ROOT / GRAPH / "publication-v1/test_publish_graph_evidence.py")),
             "test_log_sha256": sha(regular(ROOT / GRAPH / "publication-v1/publication-tests-v2.log")),
             "test_count": 14,
             "source_and_receipt_inputs_frozen_before_remote_publication": True, "remote_publication_not_run_by_builder": True}
    exclusive(output / "BUNDLE_HANDOFF.json", canonical(final))
    print(json.dumps(final, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args().output)
