# Fixed-graph native inference benchmark: final local handoff

## Reviewed and tested package

- Intended isolated worktree source:
  `6b8f3651b062d5c59659c8e7b67f60c2724adafb`.
- Final protocol SHA256:
  `2c88c2a47f56c05ea86f221ad26806fb5190bd17b8b32a9284a0ae31dfbe85e5`.
- Guarded installer: `install_cell_graph_benchmark.py`, 180,441 bytes,
  SHA256 `dec03ef8ee82916c35928fdb0df9a9e331353b52ea4973cbcf5df8ee9a8dbd61`.
- Independent review: `backend_graph_independent_review.md`,
  SHA256 `1d4755b0d2a265135cba9e6885b7ecf5976c21f40bbd11b32b76c3665749e513`.
- Current source verification: 18 Python tests and 8 Node owner cases pass.
  Exact logs, environment and unchanged runtime hashes are in
  `verification/final-v2.json`.

The reviewer cleared protocol `cae0f27b...` and all five runtime files. The final
`2c88c2a4...` protocol only corrects "reservation" to "own configured ceilings"
and renames the unused aggregate metadata key. A reference search showed no code
consumer. `verification/wording-amendment.json` verifies the exact old/new hashes,
unchanged numerical settings and unchanged tested runtime. No runtime retest was
needed for that metadata-only correction.

No original features, original trained heads, task labels or retention outcomes
were read by this implementation lane. There were no remote tools or actual
benchmark/native worker invocations. All local model arithmetic used constructed
fixtures. Local subprocess tests injected cgroup limits because this environment
cannot provision the native systemd jobs; they do not certify native enforcement.

## Install and integration check

Use root's new isolated graph worktree at the intended source commit; the
installer requires an explicit absolute path, actual branch and exact HEAD:

```bash
/usr/bin/python3 /absolute/transferred/install_cell_graph_benchmark.py \
  --worktree /absolute/isolated/graph-worktree \
  --expected-branch ROOT_OBSERVED_GRAPH_BRANCH \
  --expected-head 6b8f3651b062d5c59659c8e7b67f60c2724adafb
```

It adds exactly nine files and verifies seven protected existing source/protocol
preimages. It rejects unrelated worktree changes, wrong HEAD/branch, symlinks and
conflicting new files. It neither commits nor pushes nor runs a model or tool.

From the new worktree's `qa/stem-bakeoff`:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  /data/hepta-cell-input-20261024/.venv/bin/python -W error -m unittest \
  test_cell_graph_benchmark -v
node test_cell_graph_owner.js
```

Run repository format/diff gates and verify every payload hash in
`PATCH_MANIFEST.json`. Commit/push before exporting inputs or running inference.
Any actual integration defect gets retained with its failure before a reviewed
correction; do not overwrite the old evidence or silently change code pins.

## Minimal root orchestration entry

The operational entry is:

```javascript
await executeCellGraph(graph, dispatchSha256, adapter);
```

`executeCellGraph` is defined in the frozen `cell_graph_owner.js`. The root binds
`adapter` to the existing native `process_start` / `process_status` /
`process_read` tools and one fixed reducer location/environment. This file is an
adapter boundary, not an independently deployed service or invented native API.
Its complete method/collection schema is in `CELL_GRAPH_BENCHMARK.md`.

Root confirmed native `process_start` returns top-level `reused` plus
`job.id`, `request_digest`, `request_fingerprint` and original launch data:

- Map actual `reused:false` to `start_disposition:"created"` for all primary jobs.
- Map actual `reused:true` to `start_disposition:"reused"` for the three post-run
  idempotency lookups.
- Retain the full actual native response and its hash, exact original start
  arguments and hash, job ID and authoritative completed status.
- Collect both full JSON stdout lines with pagination. A truncated read cannot
  qualify a worker. The output cap is 196,608 bytes.
- Use the adapter's instrument callback for every native status/read call and
  every separately bounded cleanup call. Do not synthesize native receipts.

The root must freeze the concrete adapter source/hash, task-owned worker paths,
actual start-argument schema, fixed reducer executable and evidence publication
locations before the benchmark. Root should invoke each graph in one owner
script, with no intervening model turn inside the measured critical path.

## Input/environment freeze sequence

The original run directory is:
`/home/qian-qi/workspace/hepta-cell-retention-evidence-20261024/run-v1`.

The source exporter is restricted to that run's original six
`initial/seed{7,17,29}-{linear,gated}` checkpoints, `projected_features.npz`, and
frozen protocol. It reads no controlled-arm heads, summary, frozen predictions or
gold. Its selected graph is fixed independently of outcomes.

The actual read-only interpreter/version bindings supplied by root are:

| Host | Python executable | Python | NumPy |
|---|---|---|---|
| main | `/data/hepta-cell-input-20261024/.venv/bin/python` | 3.13.12 | 2.2.6 |
| pocket4 | `/usr/bin/python3` | 3.14.4 | 2.3.5 |

Root's earlier metadata probes confirmed separate physical instances and local
100% CPU / 1 GiB cgroups on both hosts. Those probes opened no head/features.
The benchmark still verifies the actual own cgroup on **every** worker: A is
200% CPU / 2 GiB; each B/C worker is 100% / 1 GiB. These are local configured
ceilings, not reserved capacity or effective limits under unknown ancestors.

The CLI sequence is documented in `CELL_GRAPH_BENCHMARK.md`:

1. Stage the standalone worker and record its `--inventory` on each host.
2. `freeze-environments` with both inventories and separate physical-host evidence.
3. `export` the six original warmup heads and fixed 480×8 feature matrix.
4. `prepare` requests using exact protocol, environment and graph hashes.
5. Execute the 18 graph entries of generated `dispatch.json` in frozen order.
6. After the primary census, call `recoverCellGraphNode` only for `b0-A-s0`,
   `b0-B-s0`, `b0-C-s0`, replaying exact original start arguments/idempotency keys.
7. Run `cell_graph_report.py` on the complete evidence tree.

All generated output paths must be new. Publish the frozen environment, graph
and dispatch identities before execution. The root has not yet run this graph
benchmark; this handoff does not claim an actual timing/parity result.

## Fixed comparison and claims

A is one main worker for six heads. B is two concurrent main workers for the
same 3+3 partition. C is that partition across main/pocket4. All use one NumPy
thread and equal sums of local CPU/memory ceilings. Six permutations of A/B/C
make six blocks; C swaps shard-to-host assignment by block parity.

Functional qualification requires `atol=1e-12, rtol=1e-12`, every head argmax and
mean argmax exactly matching the predeclared `b0-A` reference. No new reference
or widened tolerance is selected after outputs. Complete 18-graph admission is
required before paired descriptive latency summaries; failures and all known
costs remain visible, unknown costs are not filled with zero.

Post-await deadline checks preserve native calls that completed late but reject
them as timely successes. Cleanup is a distinct six-call/30-second lane whose
cost is within the enclosing owner wall interval. Recovery requires an actual
successful complete original and the same authoritative job/output, not matching
predictions from recomputation. The lookup test is not a crash/power-loss test.

Worker phases include import/load/numerics/serialization. Reducer executable
timers include NumPy/import/CLI startup and separately identify body subsets.
Process RSS peaks are not summed as simultaneous/unique physical memory.
The one owner clock measures actual dispatch/transfer/read/reduce wall; it does
not isolate network latency. Service/owner platform CPU/RSS that are unavailable
remain unmeasured, so the result cannot establish total-system net benefit.

This is a same-fixed-graph serving/cold-dispatch experiment on heterogeneous
deployment stacks. It says nothing by itself about task accuracy, new learning,
beneficial splitting/edges, optimizer migration, native agent competence or AGI.
