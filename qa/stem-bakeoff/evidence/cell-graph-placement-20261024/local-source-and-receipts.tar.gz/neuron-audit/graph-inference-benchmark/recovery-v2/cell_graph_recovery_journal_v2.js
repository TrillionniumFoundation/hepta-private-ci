/* Root binding: exclusive files on the shared local filesystem, before/after
 * each native Runtime call. This uses only local exec, not a remote worker.
 */
function createCellGraphRecoveryJournalV2({tools}) {
  const B=CellGraphBytes,check=B.requireValue;
  const SCRIPT="/workspace/scratch/b291d9fd3bc7/neuron-audit/graph-inference-benchmark/recovery-v2/write_recovery_journal_v2.py";
  const quote=text=>"'"+text.replaceAll("'","'\\''")+"'";
  function argumentsFor(data){
    const base64=B.base64(data),parts=[];
    for(let index=0;index<base64.length;index+=16384)parts.push(base64.slice(index,index+16384));
    return parts.map(part=>" --part "+quote(part)).join("");
  }
  async function invoke(command){
    check(B.utf8(command).length<=98304,"entire bash-c command must remain below96KiB, not only each argv");
    let result=await tools.exec_command({cmd:command,workdir:"/workspace/scratch/b291d9fd3bc7",yield_time_ms:1000,max_output_tokens:1500});
    const outputs=[result.output];
    if(result.session_id!==undefined){
      const sessionId=result.session_id;
      for(let count=0;count<10&&result.session_id!==undefined;count++){
        result=await tools.write_stdin({session_id:sessionId,chars:"",yield_time_ms:1000,max_output_tokens:1500});outputs.push(result.output);
      }
    }
    check(result.exit_code===0 && result.session_id===undefined,"local exclusive journal not acknowledged; no retry");
    return B.parseJSON(outputs.join(""));
  }
  return async entry=>{
    check(entry && /^[0-9a-f]{64}$/.test(entry.namespace) && B.hashText(entry.text)===entry.sha256 &&
      B.utf8(entry.text).length===entry.bytes,"journal callback exact bytes required");
    const command="/usr/bin/python3 "+quote(SCRIPT)+" --namespace "+quote(entry.namespace)+" --name "+quote(entry.file_name)+" --sha256 "+quote(entry.sha256);
    const started=Date.now(),data=B.utf8(entry.text),transport=[];
    let receipt;
    if(data.length<=65536)receipt=await invoke(command+argumentsFor(data));
    else {
      const count=Math.ceil(data.length/65536),common=command+" --full-bytes "+data.length+" --chunks "+count;
      for(let index=0;index<count;index++){
        const chunk=data.slice(index*65536,(index+1)*65536),digest=B.sha256(chunk),chunkStarted=Date.now();
        const ack=await invoke(common+" --chunk-index "+index+" --chunk-sha256 "+quote(digest)+argumentsFor(chunk));
        check(ack.schema==="hepta.fixed-cell-graph.recovery-file-chunk-ack.v2" && ack.publication==="created" &&
          ack.namespace===entry.namespace && ack.file_name===entry.file_name && ack.index===index && ack.chunks===count &&
          ack.sha256===digest && ack.bytes===chunk.length && ack.full_sha256===entry.sha256 && ack.full_file_committed===false,
          "exact exclusive staging chunk acknowledgement required");
        transport.push({...ack,root_callback_started_ms:chunkStarted,root_callback_completed_ms:Date.now()});
      }
      receipt=await invoke(common+" --seal");
    }
    check(receipt.schema==="hepta.fixed-cell-graph.recovery-file-ack.v2","actual local file acknowledgement required");
    return {...receipt,transport,root_callback_started_ms:started,root_callback_completed_ms:Date.now(),
      local_exec_scope:"Local Python file writer; its tool/serialization/await overhead is inside recovery owner except case-level files. Not an original Runtime worker or inference."};
  };
}
