"""Exclusive local per-call journal; no host/network or original evidence writes.

This is a filesystem checkpoint across controller turns, not a demonstrated
power-loss/remote backup guarantee. Root separately publishes the files.
"""

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import time


ROOT = Path("/workspace/scratch/b291d9fd3bc7/continued-session/graph-recovery-v2-journal")
NAME = re.compile(r"(?:raw-[0-9]{6}-(?:intent|returned|failure)|case-b0-[ABC]-s0-(?:intent|record|outer))\.json\Z")


def require(value, message):
    if not value:
        raise ValueError(message)


def sync_directory(path):
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write(namespace, name, expected_sha256, parts):
    started, cpu = time.perf_counter_ns(), time.process_time_ns()
    require(re.fullmatch(r"[0-9a-f]{64}", namespace) and NAME.fullmatch(name), "bounded separate journal namespace/name required")
    require(re.fullmatch(r"[0-9a-f]{64}", expected_sha256), "exact data SHA required")
    require(parts and all(len(part) <= 16384 for part in parts) and sum(map(len, parts)) <= 1_398_104, "bounded base64 parts required")
    data = base64.b64decode("".join(parts), validate=True)
    require(len(data) <= 1_048_576 and hashlib.sha256(data).hexdigest() == expected_sha256, "exact bounded checkpoint bytes required")
    # The name and root are fixed. Refuse preexisting symlink ancestors rather
    # than following them outside this separate task-owned evidence directory.
    for ancestor in (ROOT, *ROOT.parents):
        require(not ancestor.is_symlink(), "journal root has symlink ancestor")
    ROOT.mkdir(parents=True, exist_ok=True)
    folder = ROOT / namespace
    require(not folder.is_symlink(), "journal namespace is a symlink")
    folder.mkdir(exist_ok=True)
    sync_directory(ROOT.parent)
    sync_directory(ROOT)
    path = folder / name
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    sync_directory(folder)
    return {"schema": "hepta.fixed-cell-graph.recovery-file-ack.v2", "namespace": namespace, "file_name": name,
            "file": str(path), "publication": "created", "bytes": len(data), "sha256": expected_sha256,
            "writer_wall_ns_before_ack": time.perf_counter_ns() - started,
            "writer_cpu_ns_before_ack": time.process_time_ns() - cpu,
            "scope": "Exclusive local file plus parent-entry fsync; excludes Python startup/imports and acknowledgement transport. Root archives separately; no power-loss or storage-lifetime test."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("namespace", "name", "sha256"):
        parser.add_argument("--" + key, required=True)
    parser.add_argument("--part", action="append", required=True)
    args = parser.parse_args()
    print(json.dumps(write(args.namespace, args.name, args.sha256, args.part), separators=(",", ":")))
