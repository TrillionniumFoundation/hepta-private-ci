/* A narrowly scoped receipt correction. No tool or host call is performed.
 * Fresh launches still require a launch acknowledgement. A completed-job
 * lookup instead requires reused:true, launch:null, retried_launch:false,
 * and the exact previously acknowledged job/request binding.
 */
const CellGraphRecoveryStartV2 = (() => {
  const B = CellGraphBytes, check = B.requireValue;
  const sha = value => typeof value === "string" && /^[0-9a-f]{64}$/.test(value);
  const equal = (a, b) => B.json(a) === B.json(b);
  function fingerprint(value) {
    check(typeof value === "string" ? /^[0-9]+$/.test(value) : Number.isSafeInteger(value) && value >= 0,
      "exact decimal native fingerprint required");
    return String(value);
  }
  function exactReceipt(result) {
    check(result && result.isError === false && Array.isArray(result.content) && result.content.length === 1 &&
      result.content[0].type === "text" && typeof result.content[0].text === "string", "one exact native JSON text receipt required");
    const value = B.parseJSON(result.content[0].text);
    check(value && value.audit_recorded === true, "authoritative native audit receipt required");
    return value;
  }
  function terminal(value, jobId, maxStdout = 196608, maxStderr = 8192) {
    check(value && value.job_id === jobId, "native status changed job ID");
    check(["running", "succeeded", "failed"].includes(value.state), "unknown authoritative job state");
    if (value.state === "running" || value.output_complete !== true) return null;
    check(Number.isSafeInteger(value.exit_code) && typeof value.timed_out === "boolean" && typeof value.cancelled === "boolean",
      "complete terminal exit/timeout/cancel fields required");
    const sizes = {};
    for (const [stream, bound] of [["stdout", maxStdout], ["stderr", maxStderr]]) {
      const count = value.log_bytes && value.log_bytes[stream];
      check(count && Number.isSafeInteger(count.seen) && count.seen >= 0 && count.seen <= bound && count.stored === count.seen &&
        value.log_errors && value.log_errors[stream] === null && value.log_truncated && value.log_truncated[stream] === false,
        "complete bounded untruncated terminal logs required");
      sizes[stream] = count.stored;
    }
    check(value.state !== "succeeded" || (value.exit_code === 0 && !value.timed_out && !value.cancelled), "inconsistent successful native state");
    return {state:value.state, exit_code:value.exit_code, timed_out:value.timed_out, cancelled:value.cancelled, ...sizes};
  }
  function bind(value, args, expectedDisposition, original = null) {
    const job = value && value.job;
    check(value && typeof value.reused === "boolean" && value.audit_recorded === true && job && typeof job.id === "string" && job.id &&
      job.host === args.host && job.idempotency_key === args.idempotency_key && job.executable === args.executable &&
      equal(job.args, args.args) && job.cwd === args.cwd && Array.isArray(job.env_keys) &&
      equal([...job.env_keys].sort(), Object.keys(args.env).sort()) && sha(job.request_digest) &&
      job.launch_state === "launched" && job.launch_error === null, "native start receipt does not bind original request");
    const fp = fingerprint(job.request_fingerprint);
    if (expectedDisposition === "created") {
      check(value.reused === false && value.launch && value.launch.ok === true && value.retried_launch !== true,
        "fresh primary requires its actual successful launch acknowledgement");
    } else {
      check(expectedDisposition === "reused" && original && value.reused === true && value.launch === null && value.retried_launch === false,
        "completed-job reuse requires no fresh/retried launch");
      check(job.id === original.job_id && job.request_digest === original.native_request_digest && fp === original.native_request_fingerprint,
        "native idempotency lookup rebound original job/digest/fingerprint");
      const ended = terminal(value.status, job.id);
      check(ended && ended.state === "succeeded" && ended.exit_code === 0, "cached original completed-job status required");
      check(ended.stdout === original.stdout_bytes && ended.stderr === original.stderr_bytes, "cached original log sizes changed");
    }
    return {job_id:job.id, start_disposition:expectedDisposition,
      native_request_digest:job.request_digest, native_request_fingerprint:fp};
  }
  return {bind, exactReceipt, terminal};
})();
