/* Real receipt-shape regression plus constructed transport/state cases.
 * No native tools, original stdin, model parameters, labels or outputs read.
 */
const assert=require("node:assert/strict"),crypto=require("node:crypto"),fs=require("node:fs"),path=require("node:path"),vm=require("node:vm");
const hash=value=>crypto.createHash("sha256").update(value).digest("hex");
const plain=value=>JSON.parse(JSON.stringify(value));
const root=__dirname, helpers=fs.readFileSync(path.join(root,"../native-adapter/cell_graph_native_helpers.js"),"utf8");
const parser=fs.readFileSync(path.join(root,"cell_graph_recovery_start_v2.js"),"utf8");
const runtime=fs.readFileSync(path.join(root,"cell_graph_recovery_validation_v2.js"),"utf8");
const owner=fs.readFileSync(path.join(root,"../patch/qa/stem-bakeoff/cell_graph_owner.js"),"utf8");
const frozenAdapter=fs.readFileSync(path.join(root,"../native-adapter/cell_graph_native_adapter.js"),"utf8");
const actual=JSON.parse(fs.readFileSync(path.join(root,"actual_reused_start_fixture.json"),"utf8"));
assert.equal(hash(owner),"a8f1e561f3bff60b0247351c27619a874403006cd44ee40035b2cc3c8a1de112");
assert.equal(hash(frozenAdapter),"df31a3a5a1fcedc8ff1b348e256f9a9a23176dc90dea873011361b8b4ed09f29");
const actualDispatch="595d40d93a9ba394c21c39fd41c5c8b60ab5ceddfcdb8bdd9f5102ce193fa4ae";
const context=vm.createContext({setTimeout:callback=>{callback();return 0;}});
vm.runInContext(helpers+"\n"+parser+"\nglobalThis.api={B:CellGraphBytes,S:CellGraphRecoveryStartV2};",context);
const {B,S}=context.api;
const args={...actual.arguments_without_stdin,stdin:"synthetic opaque bytes only; original stdin intentionally absent"};
const fresh=S.exactReceipt(B.parseJSON(actual.records[0].result_json));
const reused=S.exactReceipt(B.parseJSON(actual.records[1].result_json));
const original={job_id:fresh.job.id,native_request_digest:fresh.job.request_digest,
  native_request_fingerprint:String(fresh.job.request_fingerprint),stdout_bytes:reused.status.log_bytes.stdout.stored,
  stderr_bytes:reused.status.log_bytes.stderr.stored};
let passed=0;
async function test(name,fn){await fn();passed++;console.log("PASS "+name);}

function sourceFixture() {
  const orders=["ABC","ACB","BAC","BCA","CAB","CBA"],graphs=[],refs=[];
  for(let block=0;block<6;block++)for(const arm of orders[block]){
    const graph={graph_id:`b${block}-${arm}`,arm,block,requests:[]};
    for(let shard=0;shard<(arm==="A"?1:2);shard++){
      const id=graph.graph_id+"-s"+shard,stdin="synthetic stdin for "+id+"\n",host=arm==="C"&&shard===block%2?"pocket4":"main";
      const request={request_id:id,host,request_sha256:hash(stdin),request_bytes:Buffer.byteLength(stdin),idempotency_key:"synthetic-original-"+id,
        cpu_quota_percent:arm==="A"?200:100,memory_max_bytes:arm==="A"?2147483648:1073741824};
      graph.requests.push(request);
      if(block!==0||shard!==0)continue;
      const launchArgs={host,executable:"/fixture/python",args:["/fixture/worker.py"],cwd:"/fixture",env:{OMP_NUM_THREADS:"1"},
        idempotency_key:request.idempotency_key,cpu_quota_percent:request.cpu_quota_percent,memory_max_bytes:request.memory_max_bytes,timeout_seconds:45,stdin};
      const argumentsJson=JSON.stringify(launchArgs),output=Buffer.alloc(arm==="A"?196608:41,arm.charCodeAt(0)),stderr=Buffer.from([0,194,128]);
      const native={audit_recorded:true,reused:false,local_record_pending:false,launch:{ok:true},job:{id:"synthetic-job-"+id,host,
        idempotency_key:request.idempotency_key,executable:launchArgs.executable,args:launchArgs.args,cwd:launchArgs.cwd,env_keys:Object.keys(launchArgs.env),
        request_digest:hash(argumentsJson),request_fingerprint:"3841268403567675521",launch_state:"launched",launch_error:null}};
      const resultJson=JSON.stringify({content:[{type:"text",text:JSON.stringify(native)}],structuredContent:null,isError:false});
      const node={request_id:id,host,request_sha256:request.request_sha256,idempotency_key:request.idempotency_key,status:"completed",exit_code:0,
        start_disposition:"created",stdout_complete:true,truncated:false,job_id:native.job.id,native_request_digest:native.job.request_digest,
        native_request_fingerprint:native.job.request_fingerprint,original_start_arguments_sha256:hash(argumentsJson),
        start_disposition_receipt_sha256:hash(resultJson),stdout_base64:output.toString("base64"),stdout_bytes:output.length,stdout_sha256:hash(output),
        stderr_base64:stderr.toString("base64"),stderr_bytes:stderr.length,stderr_sha256:hash(stderr)};
      refs.push({request,original:node,original_start:{lane:"primary",operation:"process_start",request_id:id,status:"returned",
        arguments_json:argumentsJson,arguments_sha256:hash(argumentsJson),result_json:resultJson,native_receipt_sha256:hash(resultJson)}});
    }
    graphs.push(graph);
  }
  const dispatch={schema:"hepta.fixed-cell-graph.dispatch.v1",graphs,requests:30},dispatchText=JSON.stringify(dispatch)+"\n",dispatchSha=hash(dispatchText);
  const reportText=JSON.stringify({schema:"hepta.fixed-cell-graph.report.v1",dispatch_sha256:dispatchSha,completed_comparable_graphs:18,
    rows:graphs.map(g=>({graph_id:g.graph_id,status:"completed"})),failed_or_noncomparable:[]})+"\n";
  const bundle={schema:"hepta.fixed-cell-graph.recovery-source.v2",dispatch_sha256:dispatchSha,dispatch_text:dispatchText,validation_protocol_sha256:"e".repeat(64),
    primary_report_sha256:hash(reportText),primary_report_text:reportText,primary_raw_evidence_sha256:"c".repeat(64),original_full_snapshot_verified:false,
    original_full_run_cost_complete:false,primary_completed_graphs:18,primary_workers:30,
    recovery_order:["b0-A-s0","b0-B-s0","b0-C-s0"],original_recovery_census:[{request_id:"b0-A-s0",status:"failed"},{request_id:"b0-B-s0",status:"absent"},{request_id:"b0-C-s0",status:"absent"}],references:refs};
  const text=JSON.stringify(bundle)+"\n";
  return {bundle,dispatchSha,inputs:{source_bundle_text:text,source_bundle_sha256:hash(text),validation_protocol_sha256:"e".repeat(64)}};
}
function setup(options={}){
  const fixture=sourceFixture(),clock={now:1792850000000},values=new Map([["original-frozen-state",{untouched:true}]]),calls=[],journalFiles=new Map(),timeline=[];
  const sandbox=vm.createContext({Date:{now:()=>clock.now++},setTimeout:callback=>{callback();return 0;}});
  // Only the fixed dispatch-hash constant is substituted in this in-memory test
  // copy so all inputs can remain synthetic. The production source is unchanged
  // and its actual-pin rejection has a separate no-tool regression below.
  assert.equal(runtime.split(actualDispatch).length-1,1);
  const testRuntime=runtime.replace(actualDispatch,fixture.dispatchSha);
  vm.runInContext(helpers+"\n"+parser+"\n"+testRuntime+"\n"+owner+"\nglobalThis.api={create:createCellGraphRecoveryValidationV2,recover:recoverCellGraphNode};",sandbox);
  const refs=fixture.bundle.references,byJob=Object.fromEntries(refs.map(r=>[r.original.job_id,r]));
  const statusCounts={};
  function mcp(v){return {content:[{type:"text",text:JSON.stringify(v)}],structuredContent:null,isError:false};}
  function terminal(ref){return {job_id:ref.original.job_id,state:"succeeded",exit_code:0,timed_out:false,cancelled:false,output_complete:true,
    log_bytes:{stdout:{seen:ref.original.stdout_bytes,stored:ref.original.stdout_bytes},stderr:{seen:ref.original.stderr_bytes,stored:ref.original.stderr_bytes}},
    log_errors:{stdout:null,stderr:null},log_truncated:{stdout:false,stderr:false}};}
  const tools={
    mcp__codex_apps__hepta_runtime_full_operator_process_start:async args=>{
      timeline.push("native:start");
      calls.push({operation:"start",args:plain(args)});const ref=refs.find(r=>r.request.idempotency_key===args.idempotency_key);assert.ok(ref);
      assert.equal(JSON.stringify(args),ref.original_start.arguments_json);
      if(options.unknownStart)throw new Error("constructed transport failure after possible lookup");
      const originalReceipt=JSON.parse(JSON.parse(ref.original_start.result_json).content[0].text);
      const value={...originalReceipt,reused:true,launch:null,retried_launch:false,status:terminal(ref)};
      if(options.freshInstead){value.reused=false;value.launch={ok:true};}
      if(options.rebind)value.job.id="different-job";
      return mcp(value);
    },
    mcp__codex_apps__hepta_runtime_full_operator_process_status:async args=>{
      calls.push({operation:"status",args:plain(args)});const ref=byJob[args.job_id];assert.ok(ref);assert.equal(args.host,ref.request.host);
      statusCounts[args.job_id]=(statusCounts[args.job_id]||0)+1;
      if(options.running)return mcp({audit_recorded:true,job_id:args.job_id,state:"running"});
      if(options.lateFinal&&statusCounts[args.job_id]===2)clock.now+=60001;
      return mcp({audit_recorded:true,...terminal(ref)});
    },
    mcp__codex_apps__hepta_runtime_full_operator_process_read:async args=>{
      calls.push({operation:"read",args:plain(args)});const ref=byJob[args.job_id];assert.ok(ref);assert.equal(args.limit,16384);
      function stream(name){const data=Buffer.from(ref.original[name+"_base64"],"base64");if(options.changed&&name==="stdout")data[0]^=1;
        const offset=args[name+"_offset"],part=data.subarray(offset,offset+16384);
        return {bytes_hex:part.toString("hex"),offset:offset+(options.hole?1:0),next_offset:offset+part.length,size:data.length,eof:offset+part.length===data.length,text:"lossy display unused"};}
      return mcp({audit_recorded:true,job_id:args.job_id,stdout:stream("stdout"),stderr:stream("stderr")});
    }
  };
  const journal=async entry=>{
    timeline.push("journal:"+entry.file_name);assert.equal(hash(entry.text),entry.sha256);assert.equal(Buffer.byteLength(entry.text),entry.bytes);
    assert.ok(!journalFiles.has(entry.file_name),"fixture exclusive journal cannot overwrite");
    if(options.failIntent&&entry.file_name==="raw-000000-intent.json")throw new Error("constructed intent journal unavailable");
    if(options.failOuter&&entry.file_name==="case-b0-A-s0-outer.json")throw new Error("constructed outer journal unavailable");
    journalFiles.set(entry.file_name,entry.text);
    if(options.slowIntent&&entry.file_name==="raw-000000-intent.json")clock.now+=60001;
    if(options.lostReturnAck&&entry.file_name==="raw-000000-returned.json")throw new Error("constructed return-file ack lost after bytes persisted");
    return {publication:"created",namespace:entry.namespace,file_name:entry.file_name,sha256:entry.sha256,bytes:entry.bytes};
  };
  const bindings={tools,journal,store:(k,v)=>values.set(k,plain(v)),load:k=>values.has(k)?plain(values.get(k)):undefined,inputs:fixture.inputs};
  const adapter=sandbox.api.create(bindings);return {adapter,calls,values,fixture,bindings,api:sandbox.api,clock,journalFiles,timeline};
}

(async()=>{
  await test("exact actual native receipt hashes and unsafe integer lexeme preserved",()=>{
    for(const record of actual.records)assert.equal(hash(record.result_json),record.native_receipt_sha256);
    assert.equal(actual.both_original_arguments_exactly_equal,true);assert.equal(fresh.job.request_fingerprint,"3841268403567675521");
    assert.equal(reused.job.id,"1a16d8e52e6-1b6abb-4960");assert.equal(actual.original_failure.status,"failed");
  });
  await test("unchanged frozen parser reproduces observed failure before job binding",()=>{
    const functionSource=frozenAdapter.slice(frozenAdapter.indexOf("  function startResult("),frozenAdapter.indexOf("  async function submit("));
    const pending={host:args.host,arguments_sha256:B.hashText(B.json(args)),job_id:null};
    context.legacyPending=pending;context.legacyArgs=args;context.legacyReused=reused;
    vm.runInContext("const B=CellGraphBytes,check=B.requireValue,equal=(a,b)=>B.json(a)===B.json(b),isSha=x=>typeof x==='string'&&/^[0-9a-f]{64}$/.test(x);const get=()=>({outstanding:{case:legacyPending}}),setState=()=>{};"+functionSource,context);
    assert.throws(()=>vm.runInContext("startResult({value:legacyReused,pending_key:'case'},legacyArgs)",context),/original request\/launch/);
    assert.equal(pending.job_id,null);
  });
  await test("fresh primary acknowledgement remains strict; exact actual reuse shape accepted separately",()=>{
    assert.equal(S.bind(fresh,args,"created").start_disposition,"created");
    assert.equal(S.bind(reused,args,"reused",original).job_id,original.job_id);
    assert.throws(()=>S.bind(reused,args,"created"));assert.throws(()=>S.bind({...fresh,launch:null},args,"created"));
  });
  await test("no fresh/retried/ambiguous launch accepted as completed-job recovery",()=>{
    for(const patch of [{reused:false},{launch:{ok:true}},{retried_launch:true},{retried_launch:undefined}])assert.throws(()=>S.bind({...reused,...patch},args,"reused",original));
  });
  await test("job/digest/fingerprint/request identity rebinding is rejected",()=>{
    for(const patch of [{id:"wrong"},{request_digest:"f".repeat(64)},{request_fingerprint:"1"},{host:"pocket4"},{idempotency_key:"changed"},{cwd:"/changed"},{args:[]}])
      assert.throws(()=>S.bind({...reused,job:{...reused.job,...patch}},args,"reused",original));
  });
  await test("cached terminal status must bind successful complete original logs",()=>{
    for(const patch of [{job_id:"wrong"},{state:"running"},{state:"failed",exit_code:7},{output_complete:false},{log_truncated:{stdout:true,stderr:false}}])
      assert.throws(()=>S.bind({...reused,status:{...reused.status,...patch}},args,"reused",original));
    assert.throws(()=>S.bind(reused,args,"reused",{...original,stdout_bytes:original.stdout_bytes+1}));
  });
  await test("unmodified production source rejects non-frozen dispatch before tools",()=>{
    const fixture=sourceFixture(),sandbox=vm.createContext({});vm.runInContext(helpers+"\n"+parser+"\n"+runtime+"\nglobalThis.make=createCellGraphRecoveryValidationV2",sandbox);
    assert.throws(()=>sandbox.make({tools:{},journal:async()=>{},store:()=>{},load:()=>undefined,inputs:fixture.inputs}),/complete original/);
  });
  await test("three synthetic exact lookups use maximum12 pages, untouched original state and separate namespace",async()=>{
    const {adapter,calls,values,api}=setup();for(const id of ["b0-A-s0","b0-B-s0","b0-C-s0"])assert.equal((await adapter.runNext(id,api.recover)).status,"completed");
    const snapshot=adapter.snapshot();assert.deepEqual(plain(snapshot.cases.map(x=>x.classification)),["completed","completed","completed"]);
    assert.equal(snapshot.cases[0].record.collection.read_pages,12);assert.equal(snapshot.cases[0].record.api_events.length,15);
    assert.equal(calls.filter(c=>c.operation==="start").length,3);assert.equal(snapshot.state.outstanding,null);
    assert.deepEqual(values.get("original-frozen-state"),{untouched:true});assert.ok(adapter.storePrefix.startsWith("cell-graph-recovery-validation-v2:"));
    for(const record of snapshot.records){assert.equal(hash(record.arguments_json),record.arguments_sha256);assert.equal(hash(record.result_json),record.native_receipt_sha256);}
    assert.equal(snapshot.native_process_cpu_ns,null);
  });
  await test("unknown lookup retains pending intent/raw failure and blocks later admission",async()=>{
    const {adapter,calls,api}=setup({unknownStart:true});assert.equal((await adapter.runNext("b0-A-s0",api.recover)).status,"failed");
    const before=calls.length;await assert.rejects(()=>adapter.runNext("b0-B-s0",api.recover));assert.equal(calls.length,before);
    assert.equal(adapter.snapshot().state.outstanding.job_id,null);assert.equal(adapter.snapshot().cases[1].classification,"unattempted");
  });
  await test("fresh or rebound jobs remain failures, never substituted",async()=>{
    for(const options of [{freshInstead:true},{rebind:true}]){const {adapter,calls,api}=setup(options);assert.equal((await adapter.runNext("b0-A-s0",api.recover)).status,"failed");assert.equal(calls.length,1);await assert.rejects(()=>adapter.runNext("b0-B-s0",api.recover));}
  });
  await test("changed complete output or pagination holes cannot qualify",async()=>{
    for(const options of [{changed:true},{hole:true}]){const {adapter,api}=setup(options);assert.equal((await adapter.runNext("b0-A-s0",api.recover)).status,"failed");assert.ok(adapter.snapshot().records.some(r=>r.operation==="process_read"));}
  });
  await test("only10 bounded running statuses; later cases remain unattempted",async()=>{
    const {adapter,calls,api}=setup({running:true});assert.equal((await adapter.runNext("b0-A-s0",api.recover)).status,"failed");assert.equal(calls.filter(x=>x.operation==="status").length,10);await assert.rejects(()=>adapter.runNext("b0-B-s0",api.recover));
  });
  await test("frozen owner's post-final-await60s check preserves real late event as failed",async()=>{
    const {adapter,api}=setup({lateFinal:true});const result=await adapter.runNext("b0-A-s0",api.recover);assert.equal(result.status,"failed");assert.match(result.failure.message,/clock\/deadline/);assert.ok(result.completed_ms-result.started_ms>60000);assert.equal(adapter.snapshot().records.at(-1).status,"returned");
  });
  await test("duplicate invocation cannot overwrite the first result or make a native call",async()=>{
    const {adapter,calls,values,api}=setup();await adapter.runNext("b0-A-s0",api.recover);const key=adapter.storePrefix+"record:b0-A-s0",before=JSON.stringify(values.get(key)),count=calls.length;
    await assert.rejects(()=>adapter.runNext("b0-A-s0",api.recover));assert.equal(calls.length,count);assert.equal(JSON.stringify(values.get(key)),before);
  });
  await test("reconstruction retains independent attempts and counts repeated setup",async()=>{
    const {adapter,bindings,api}=setup();await adapter.runNext("b0-A-s0",api.recover);const restored=api.create(bindings);assert.equal(restored.getState().next_case,1);assert.equal(restored.getState().constructions.length,2);await assert.rejects(()=>restored.runNext("b0-A-s0",api.recover));
  });
  await test("every original lookup is preceded by exclusive intent and raw result precedes case publication",async()=>{
    const {adapter,api,timeline,journalFiles}=setup();await adapter.runNext("b0-A-s0",api.recover);
    assert.ok(timeline.indexOf("journal:raw-000000-intent.json")<timeline.indexOf("native:start"));
    assert.ok(timeline.indexOf("journal:raw-000000-returned.json")<timeline.indexOf("journal:case-b0-A-s0-record.json"));
    const raw=JSON.parse(journalFiles.get("raw-000000-returned.json"));assert.equal(hash(raw.result_json),raw.native_receipt_sha256);
    assert.equal(journalFiles.size,33); // 15 calls x2 + case intent/record/outer.
  });
  await test("failed intent-file acknowledgement prevents native call and blocks next case",async()=>{
    const {adapter,api,calls}=setup({failIntent:true});assert.equal((await adapter.runNext("b0-A-s0",api.recover)).status,"failed");
    assert.equal(calls.length,0);await assert.rejects(()=>adapter.runNext("b0-B-s0",api.recover));assert.ok(adapter.getState().journal_failure);
  });
  await test("lost return acknowledgement retains exact response file and refuses any lookup retry",async()=>{
    const {adapter,api,calls,journalFiles}=setup({lostReturnAck:true});assert.equal((await adapter.runNext("b0-A-s0",api.recover)).status,"failed");
    assert.equal(calls.length,1);assert.ok(journalFiles.has("raw-000000-returned.json"));await assert.rejects(()=>adapter.runNext("b0-A-s0",api.recover));await assert.rejects(()=>adapter.runNext("b0-B-s0",api.recover));
  });
  await test("failed outer-file acknowledgement also blocks subsequent admission",async()=>{
    const {adapter,api}=setup({failOuter:true});await assert.rejects(()=>adapter.runNext("b0-A-s0",api.recover),/outer journal/);
    assert.equal(adapter.snapshot().cases[0].record.status,"completed");assert.ok(adapter.getState().journal_failure);await assert.rejects(()=>adapter.runNext("b0-B-s0",api.recover));
  });
  await test("late intent acknowledgement never starts a native lookup after owner deadline",async()=>{
    const {adapter,api,calls}=setup({slowIntent:true});const result=await adapter.runNext("b0-A-s0",api.recover);
    assert.equal(result.status,"failed");assert.equal(calls.length,0);assert.equal(adapter.snapshot().records[0].native_call_attempted,false);
  });
  console.log(JSON.stringify({passed,native_host_calls:0,original_parameters_or_outputs_read:false,scope:"receipt-shape and synthetic transport qualification only; not actual v2 recovery success"}));
})().catch(error=>{console.error(error);process.exitCode=1;});
