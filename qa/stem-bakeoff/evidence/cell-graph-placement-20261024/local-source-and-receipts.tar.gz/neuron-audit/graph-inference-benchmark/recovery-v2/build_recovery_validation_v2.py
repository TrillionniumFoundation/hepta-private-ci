"""Bundle frozen pure JS recovery-only code; reads no actual graph input."""

import argparse
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    protocol_bytes = (root / "recovery_validation_protocol_v2.json").read_bytes()
    protocol = json.loads(protocol_bytes)
    sources = {}
    for name, entry in protocol["source_files"].items():
        path = root / entry["relative_path"]
        data = path.read_bytes()
        if path.is_symlink() or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise ValueError("frozen recovery/source identity differs: " + name)
        sources[name] = data.decode()
    order = ["helpers", "start_parser", "recovery_adapter", "file_journal_callback", "frozen_owner"]
    source = "(() => {\n" + "\n".join(sources[name] for name in order) + "\nreturn {create:createCellGraphRecoveryValidationV2,createJournal:createCellGraphRecoveryJournalV2,recover:recoverCellGraphNode};\n})()"
    result = {"schema": "hepta.fixed-cell-graph.recovery-bundle.v2", "source": source,
              "source_sha256": hashlib.sha256(source.encode()).hexdigest(), "source_bytes": len(source.encode()),
              "validation_protocol_sha256": hashlib.sha256(protocol_bytes).hexdigest(),
              "source_files": protocol["source_files"], "actual_v2_native_calls": 0}
    data = (json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode()
    with args.output.open("xb") as stream:
        stream.write(data)
    print(json.dumps({"bundle": str(args.output), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                      "source_sha256": result["source_sha256"], "source_bytes": result["source_bytes"],
                      "validation_protocol_sha256": result["validation_protocol_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
