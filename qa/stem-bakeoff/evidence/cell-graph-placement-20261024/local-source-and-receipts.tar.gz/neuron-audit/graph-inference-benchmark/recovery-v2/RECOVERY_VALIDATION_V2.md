# Separate recovery-parser validation after the original failed lookup

This package preserves the original 18 primary graphs, the original failed
`b0-A-s0` recovery, and the two original unattempted recoveries. It does not edit
the original adapter, state, graph owner, reporter, reducer, worker, graph
protocol, head parameters, numerical tolerance, or resource budgets.

## Observed defect and original evidence boundary

The original adapter required `launch.ok === true` for every start receipt.
The actual idempotency lookup returned `reused:true`, `launch:null`, and
`retried_launch:false`, with the same job, request digest and exact uint64
fingerprint as the original fresh start. Its nested status identified that
same completed job. The original check failed before binding `job_id` into
its pending bookkeeping. The failure and its costs are still real results.
They are not evidence that Runtime created another inference or lost output.

The original `flushRawLedger()` has no outstanding-worker admission gate. It
snapshots the original state and starts separate chunk/seal helpers. It could
legitimately begin sealing the failed state. The subsequent controller-store
loss does not permit recreating its old adapter state or retrying its old outer
operation. Actual storage retained only chunks 0–3 of 34, a 2,097,152-byte
prefix of the declared 17,781,056-byte ledger. The manifest's whole-ledger SHA
is **not verified**. The later sealing calls, session-only helper/outer spans,
and other missing original suffix records remain unavailable.

`extract_complete_raw_prefix.py` verifies each existing contiguous chunk against
its original wrapper acknowledgement, then parses complete original JSON objects
from the top-level records array. It retains each exact byte range/hash and the
unparsed tail. It never appends brackets, invents records, fills missing indices,
or calls the partial prefix a sealed ledger. Root's actual extraction recovered
45 complete records out of the snapshot's declared 383, including all three
required block-0 shard-0 starts. Prefix SHA is
`c0e41a7adf1c83943f61e146d49b43ff70ffb57800b82cb45f906275a1cfbcfc`.
The extraction document SHA is
`bc9d9bf887c5f68fd34815f3ef7e71403bd888c06ff622f4c8c117f63d5cd913`.
These are source/provenance recovery results, not new inference results.

The unchanged original reporter separately qualifies numerical parity of all
18 original graphs. A numerical parity result can survive loss of portions of
the controller log. A complete original native-call/whole-cost audit cannot be
claimed from 45 records. Unknown cost and RSS/CPU values never become zero.

## Fixed scope before any v2 lookup

The new validation has the same three references, in order:
`b0-A-s0`, `b0-B-s0`, `b0-C-s0`. All are original completed jobs. Each case uses
the exact original `process_start` argument string, including its original
idempotency key, stdin bytes, host, executable, arguments, environment,
resources and timeout. No new identity, modified task, fresh primary graph,
substitute job, serial fallback, reducer, model or service is authorized.

A newly created/rebound/retried launch is a validation failure. The code never
retries it or treats it as recovery. Because the existing API is `process_start`,
the actual `reused:true` receipt, not the intention alone, establishes that no
new original worker was created. Unexpected start outcomes remain unknown until
root observes the original authority; they block later case admission.

The new parser accepts a completed-job reuse only when `launch:null`,
`retried_launch:false`, original job/digest/fingerprint, and complete successful
cached terminal logs all agree. The fresh-launch branch still requires an
actual fresh acknowledgement. A cached status alone is insufficient for a pass:
the unchanged recovery owner then requests authoritative status, reads complete
stdout/stderr in at most 12 pages of 16 KiB, and requests status again. Both
streams must match the original bytes and hashes exactly.

The original `recoverCellGraphNode` bytes are unchanged. Its 24-call/60-second
bound and post-await deadline checks remain in effect. Status polling is at
most ten observations with the original three-second spacing. No broader
budget, numerical tolerance or recovery policy is introduced.

All attempted, failed, unknown and unattempted entries remain in the new census.
Any unresolved start, failed file acknowledgement, or duplicate attempt blocks
later admission. A known-ended output mismatch remains a failed case. No result
is copied into the original `graphs/recovery/` directory. New passes, if any,
are reported alongside the original parser failure and two missing cases; they
do not revise those original results.

## Immediate per-call file checkpoints

The root must supply the mandatory journal callback. The supplied callback uses
the shared local executor, never a remote inference job. It invokes the pinned
`write_recovery_journal_v2.py`, which opens every file with exclusive creation,
writes exact bytes, and fsyncs the file and directory entries. Existing files,
symlink namespaces, traversal, changed hashes and oversized data are rejected.
There is no identical-existing overwrite or implicit retry.
The complete shell command is capped at 96 KiB. Records above 64 KiB are
transported as separate exclusive 64-KiB chunks, followed by a small seal
command that verifies the complete SHA and exclusively creates the final file.
Splitting one oversized `bash -c` argument into many `--part` arguments would
not satisfy the operating-system limit; the earlier candidate with that defect
is retained under `history/before-command-bound/`. A real local bash/Python
regression transports a synthetic case record larger than 196 KiB.

The new directory is:

`/workspace/scratch/b291d9fd3bc7/continued-session/graph-recovery-v2-journal/<source-bundle-SHA>/`

Before each case there is a case intent. Before every native call there is an
exclusive raw intent; a failed intent acknowledgement prevents the native call.
Immediately after a response, its exact MCP JSON and raw argument/result hashes
are written before receipt interpretation. Case records and outside-owner
timings are also checkpointed. Failure paths retain separate failure files.
The callback is awaited, so raw-call checkpoint costs are within the original
recovery owner interval. A late intent return is checked before admitting the
native call. The case-intent and final outer-file writes have explicitly
separate boundaries.

These files survive the controller-store reset that lost the original session
log. This is not a tested power-loss guarantee or a claim that scratch storage
is an archival backup. Root copies/checksums these files into the separate
remote v2 evidence namespace after each case and includes them in the evidence
archive. The final acknowledgement is retained adjacent to the archive. Do not
reconstruct a new empty state and repeat a case after an uncertain interruption;
the existing intent/record files govern the unknown/failed census.

New validation costs include the extra file writes and a different controller
phase. They cannot be compared as an unbiased speed estimate against the
original failed recovery. Old worker CPU is not charged again for reused output.
No whole-system net benefit, isolated network, persistent-service, learning,
split, agent-competence or AGI claim follows from this validation.

## Source-only preparation and execution interface

Root first saves the original report, complete prefix extraction, and original
graph files unchanged. The preparation script reads and hashes these existing
artifacts. It verifies every imported record's original prefix byte range, raw
argument/result hashes, the original collection/output byte hashes, all 18
report/owner/reduction bindings, and the old failed/absent recovery census.
It treats worker stdin/stdout as opaque bytes and parses no model parameters,
probabilities, gold labels or numeric task outcomes. Missing original starts
are a preparation blocker with their exact request ID.

```bash
/usr/bin/python3 prepare_recovery_validation_v2.py \
  --dispatch /home/qian-qi/workspace/hepta-cell-graph-evidence-20261024/requests-v1/dispatch.json \
  --graph-evidence /home/qian-qi/workspace/hepta-cell-graph-evidence-20261024/graphs \
  --primary-report /home/qian-qi/workspace/hepta-cell-graph-evidence-20261024/controller-continuity-v1/original-report.json \
  --expected-report-sha256 6df19c646c3b610011b138a3f0cc870bc4523d23d5ae1bc2b52f78778dc39102 \
  --raw-ledger /home/qian-qi/workspace/hepta-cell-graph-evidence-20261024/controller-continuity-v1/recovered-prefix-v1/complete-prefix-records.json \
  --expected-ledger-sha256 bc9d9bf887c5f68fd34815f3ef7e71403bd888c06ff622f4c8c117f63d5cd913 \
  --output /home/qian-qi/workspace/hepta-cell-graph-evidence-20261024/recovery-validation-v2-inputs
```

`--expected-ledger-sha256` pins the supplied evidence file, which here is the
explicit partial-prefix document. It does not certify the missing full ledger.
The `recovery_validation_protocol_v2.json` file must be alongside the script.
Output must be new. Root retains the output source bundle/hash before any lookup.

Build the reviewed JS bundle locally with:

```bash
python3 build_recovery_validation_v2.py --output verification/recovery-bundle.json
```

In functions V8, use the exact transferred source bundle and reviewed bundle:

```javascript
const module = eval(bundle.source);
const journal = module.createJournal({tools});
const adapter = module.create({tools, store, load, journal, inputs: {
  source_bundle_text: exactSourceBundleText,
  source_bundle_sha256: actualSourceBundleSha256,
  validation_protocol_sha256: bundle.validation_protocol_sha256
}});
// Save construction/setup receipt separately; calls below are fixed, once each.
const first = await adapter.runNext("b0-A-s0", module.recover);
// Root verifies/publishes new checkpoint files after each case.
// Continue only if the same adapter's admission gate allows the next fixed case.
const second = await adapter.runNext("b0-B-s0", module.recover);
const third = await adapter.runNext("b0-C-s0", module.recover);
const evidence = adapter.snapshot();
```

Do not print original payloads or large snapshots to chat. The new raw files
already retain each completed call if the final snapshot is not returned.
Actual results are deliberately absent from this source-only package.
