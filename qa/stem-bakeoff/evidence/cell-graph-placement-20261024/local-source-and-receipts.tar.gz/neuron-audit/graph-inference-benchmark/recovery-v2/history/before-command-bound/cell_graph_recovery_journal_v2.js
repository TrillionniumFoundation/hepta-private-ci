/* Root binding: exclusive files on the shared local filesystem, before/after
 * each native Runtime call. This uses only local exec, not a remote worker.
 */
function createCellGraphRecoveryJournalV2({tools}) {
  const B=CellGraphBytes,check=B.requireValue;
  const SCRIPT="/workspace/scratch/b291d9fd3bc7/neuron-audit/graph-inference-benchmark/recovery-v2/write_recovery_journal_v2.py";
  const quote=text=>"'"+text.replaceAll("'","'\\''")+"'";
  return async entry=>{
    check(entry && /^[0-9a-f]{64}$/.test(entry.namespace) && B.hashText(entry.text)===entry.sha256 &&
      B.utf8(entry.text).length===entry.bytes,"journal callback exact bytes required");
    const base64=B.base64(B.utf8(entry.text)),parts=[];
    for(let index=0;index<base64.length;index+=16384)parts.push(base64.slice(index,index+16384));
    const command="/usr/bin/python3 "+quote(SCRIPT)+" --namespace "+quote(entry.namespace)+" --name "+quote(entry.file_name)+
      " --sha256 "+quote(entry.sha256)+parts.map(part=>" --part "+quote(part)).join("");
    const started=Date.now();
    let result=await tools.exec_command({cmd:command,workdir:"/workspace/scratch/b291d9fd3bc7",yield_time_ms:1000,max_output_tokens:1500});
    const outputs=[result.output];
    if(result.session_id!==undefined){
      const sessionId=result.session_id;
      for(let count=0;count<10&&result.session_id!==undefined;count++){
        result=await tools.write_stdin({session_id:sessionId,chars:"",yield_time_ms:1000,max_output_tokens:1500});outputs.push(result.output);
      }
    }
    check(result.exit_code===0 && result.session_id===undefined,"local exclusive journal not acknowledged; no retry");
    const receipt=B.parseJSON(outputs.join(""));
    check(receipt.schema==="hepta.fixed-cell-graph.recovery-file-ack.v2","actual local file acknowledgement required");
    return {...receipt,root_callback_started_ms:started,root_callback_completed_ms:Date.now(),
      local_exec_scope:"Local Python file writer; its tool/serialization/await overhead is inside recovery owner except case-level files. Not an original Runtime worker or inference."};
  };
}
