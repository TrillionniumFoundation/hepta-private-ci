"""Exclusive local per-call journal; no host/network or original evidence writes.

This is a filesystem checkpoint across controller turns, not a demonstrated
power-loss/remote backup guarantee. Root separately publishes the files.
"""

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import time


ROOT = Path("/workspace/scratch/b291d9fd3bc7/continued-session/graph-recovery-v2-journal")
NAME = re.compile(r"(?:raw-[0-9]{6}-(?:intent|returned|failure)|case-b0-[ABC]-s0-(?:intent|record|outer))\.json\Z")
CHUNK = 65_536


def require(value, message):
    if not value:
        raise ValueError(message)


def sync_directory(path):
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def folder_for(namespace, name):
    require(re.fullmatch(r"[0-9a-f]{64}", namespace) and NAME.fullmatch(name), "bounded separate journal namespace/name required")
    # The name and root are fixed. Refuse preexisting symlink ancestors rather
    # than following them outside this separate task-owned evidence directory.
    for ancestor in (ROOT, *ROOT.parents):
        require(not ancestor.is_symlink(), "journal root has symlink ancestor")
    ROOT.mkdir(parents=True, exist_ok=True)
    folder = ROOT / namespace
    require(not folder.is_symlink(), "journal namespace is a symlink")
    folder.mkdir(exist_ok=True)
    sync_directory(ROOT.parent)
    sync_directory(ROOT)
    return folder


def exclusive(path, data):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    sync_directory(path.parent)


def decode(parts, maximum=1_048_576):
    require(parts and all(len(part) <= 16384 for part in parts) and sum(map(len, parts)) <= (maximum + 2) // 3 * 4, "bounded base64 parts required")
    data = base64.b64decode("".join(parts), validate=True)
    require(len(data) <= maximum, "bounded decoded payload required")
    return data


def write(namespace, name, expected_sha256, parts):
    started, cpu = time.perf_counter_ns(), time.process_time_ns()
    require(re.fullmatch(r"[0-9a-f]{64}", expected_sha256), "exact data SHA required")
    data = decode(parts)
    require(hashlib.sha256(data).hexdigest() == expected_sha256, "exact bounded checkpoint bytes required")
    folder = folder_for(namespace, name)
    path = folder / name
    exclusive(path, data)
    return acknowledgement(namespace, name, path, data, started, cpu)


def acknowledgement(namespace, name, path, data, started, cpu):
    return {"schema": "hepta.fixed-cell-graph.recovery-file-ack.v2", "namespace": namespace, "file_name": name,
            "file": str(path), "publication": "created", "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "writer_wall_ns_before_ack": time.perf_counter_ns() - started,
            "writer_cpu_ns_before_ack": time.process_time_ns() - cpu,
            "scope": "Exclusive local file plus parent-entry fsync; excludes Python startup/imports and acknowledgement transport. Root archives separately; no power-loss or storage-lifetime test."}


def chunk_operation(namespace, name, expected_sha256, full_bytes, chunks, index=None, parts=None, chunk_sha=None):
    started, cpu = time.perf_counter_ns(), time.process_time_ns()
    require(re.fullmatch(r"[0-9a-f]{64}", expected_sha256) and type(full_bytes) is int and CHUNK < full_bytes <= 1_048_576
            and type(chunks) is int and chunks == (full_bytes + CHUNK - 1) // CHUNK, "bounded exact multi-command checkpoint manifest required")
    folder = folder_for(namespace, name)
    staging = folder / ("." + name + ".parts")
    require(not staging.is_symlink(), "staging directory is a symlink")
    manifest = (json.dumps({"namespace": namespace, "file_name": name, "sha256": expected_sha256,
                           "bytes": full_bytes, "chunks": chunks}, separators=(",", ":")) + "\n").encode()
    if index == 0:
        staging.mkdir(exist_ok=False)
        exclusive(staging / "manifest.json", manifest)
        sync_directory(folder)
    else:
        metadata = staging / "manifest.json"
        require(not metadata.is_symlink() and metadata.is_file() and metadata.stat().st_size <= 1024
                and metadata.read_bytes() == manifest, "exact previous staging manifest required")
    if index is not None:
        require(type(index) is int and 0 <= index < chunks and re.fullmatch(r"[0-9a-f]{64}", chunk_sha or ""), "original chunk index/hash required")
        data = decode(parts, CHUNK)
        require(len(data) == min(CHUNK, full_bytes - index * CHUNK) and hashlib.sha256(data).hexdigest() == chunk_sha,
                "exact bounded checkpoint chunk bytes required")
        exclusive(staging / f"part-{index:06d}.bin", data)
        return {"schema": "hepta.fixed-cell-graph.recovery-file-chunk-ack.v2", "namespace": namespace, "file_name": name,
                "index": index, "chunks": chunks, "bytes": len(data), "sha256": chunk_sha, "full_sha256": expected_sha256,
                "publication": "created", "writer_wall_ns_before_ack": time.perf_counter_ns() - started,
                "writer_cpu_ns_before_ack": time.process_time_ns() - cpu, "full_file_committed": False}
    data_parts = []
    for number in range(chunks):
        path = staging / f"part-{number:06d}.bin"
        require(not path.is_symlink() and path.is_file() and path.stat().st_size == min(CHUNK, full_bytes - number * CHUNK), "complete original checkpoint chunks required")
        data_parts.append(path.read_bytes())
    data = b"".join(data_parts)
    require(len(data) == full_bytes and hashlib.sha256(data).hexdigest() == expected_sha256, "complete staged checkpoint SHA differs")
    destination = folder / name
    exclusive(destination, data)
    result = acknowledgement(namespace, name, destination, data, started, cpu)
    result["transport_chunks"] = chunks
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("namespace", "name", "sha256"):
        parser.add_argument("--" + key, required=True)
    parser.add_argument("--part", action="append")
    parser.add_argument("--chunk-index", type=int)
    parser.add_argument("--chunks", type=int)
    parser.add_argument("--full-bytes", type=int)
    parser.add_argument("--chunk-sha256")
    parser.add_argument("--seal", action="store_true")
    args = parser.parse_args()
    if args.chunk_index is not None or args.seal:
        require(not (args.chunk_index is not None and args.seal), "chunk and seal are distinct operations")
        result = chunk_operation(args.namespace, args.name, args.sha256, args.full_bytes, args.chunks,
                                 args.chunk_index, args.part, args.chunk_sha256)
    else:
        result = write(args.namespace, args.name, args.sha256, args.part)
    print(json.dumps(result, separators=(",", ":")))
