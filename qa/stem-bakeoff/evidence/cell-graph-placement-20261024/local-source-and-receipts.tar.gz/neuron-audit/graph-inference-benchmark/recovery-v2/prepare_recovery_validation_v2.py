"""Read existing fixed-graph evidence into a separate recovery-only byte bundle.

No original data, probabilities or worker output are interpreted numerically.
No model, worker, subprocess, host, network or original evidence write occurs.
"""

import argparse
import base64
import hashlib
import json
from pathlib import Path


DISPATCH_SHA = "595d40d93a9ba394c21c39fd41c5c8b60ab5ceddfcdb8bdd9f5102ce193fa4ae"
ORDER = ["b0-A-s0", "b0-B-s0", "b0-C-s0"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def strict(data):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError("duplicate key: " + key)
            value[key] = item
        return value
    return json.loads(data, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path, maximum=1_048_576):
    require(not path.is_symlink() and path.is_file() and path.stat().st_size <= maximum, "bounded regular evidence file required: " + str(path))
    data = path.read_bytes()
    return data, strict(data)


def prepare(args):
    protocol_raw, _ = read(Path(__file__).with_name("recovery_validation_protocol_v2.json"))
    dispatch_raw, dispatch = read(args.dispatch)
    require(sha(dispatch_raw) == DISPATCH_SHA, "exact original dispatch required")
    report_raw, report = read(args.primary_report)
    require(sha(report_raw) == args.expected_report_sha256, "original reporter bytes changed")
    require(report["schema"] == "hepta.fixed-cell-graph.report.v1" and report["dispatch_sha256"] == DISPATCH_SHA
            and report["completed_comparable_graphs"] == 18 and len(report["rows"]) == 18
            and report["failed_or_noncomparable"] == [], "complete original primary census must qualify independently")
    ledger_raw, ledger = read(args.raw_ledger, 268_435_456)
    require(sha(ledger_raw) == args.expected_ledger_sha256 and ledger["dispatch_sha256"] == DISPATCH_SHA,
            "exact original raw evidence bytes required")
    records = ledger["records"]
    if ledger["schema"] == "hepta.fixed-cell-graph.native-ledger.v1":
        require([record["index"] for record in records] == list(range(ledger["state"]["raw_count"])), "full original snapshot interval required; no partial substitute")
        raw_scope = "complete original snapshot, excluding its own later sealing calls"
        full_snapshot_verified = True
        claimed_ledger_sha = sha(ledger_raw)
        ranges = {}
    else:
        require(ledger["schema"] == "hepta.fixed-cell-graph.partial-native-prefix.v2"
                and ledger["full_ledger_sha256_verified"] is False and ledger["full_run_cost_complete"] is False
                and ledger["no_repaired_or_synthesized_original_records"] is True
                and len(records) == ledger["original_complete_record_count"]
                and [record["index"] for record in records] == list(range(len(records))),
                "verified complete prefix objects required; never substitute partial evidence for a full ledger")
        prefix_path = args.raw_ledger.with_name("original-prefix.bin")
        require(not prefix_path.is_symlink() and prefix_path.is_file() and prefix_path.stat().st_size == ledger["prefix_bytes"]
                and prefix_path.stat().st_size <= 8_388_608, "exact bounded original prefix required")
        prefix = prefix_path.read_bytes()
        require(sha(prefix) == ledger["prefix_sha256"], "original prefix changed")
        require(len(ledger["record_byte_ranges"]) == len(records), "one original byte range per complete record required")
        ranges = {}
        previous_end = 0
        for record, item in zip(records, ledger["record_byte_ranges"], strict=True):
            require(item["index"] == record["index"] and previous_end <= item["begin_byte"] < item["end_byte"] <= len(prefix),
                    "nonoverlapping complete original byte ranges required")
            raw_record = prefix[item["begin_byte"]:item["end_byte"]]
            require(sha(raw_record) == item["original_record_json_sha256"] and strict(raw_record) == record,
                    "original prefix record bytes changed")
            ranges[record["index"]] = item
            previous_end = item["end_byte"]
        raw_scope = "complete JSON records recovered from persisted partial prefix; full ledger and later costs unavailable"
        full_snapshot_verified = False
        claimed_ledger_sha = ledger["declared_full_ledger_sha256"]
    for record in records:
        require(sha(record["arguments_json"].encode()) == record["arguments_sha256"], "raw argument byte hash mismatch")
        if "result_json" in record:
            require(sha(record["result_json"].encode()) == record["native_receipt_sha256"], "raw native receipt byte hash mismatch")
    census, references, source_files = [], [], []
    for graph, row in zip(dispatch["graphs"], report["rows"], strict=True):
        graph_id = graph["graph_id"]
        require(row["graph_id"] == graph_id and row["status"] == "completed", "original18-row order/status differs")
        owner_path = args.graph_evidence / graph_id / "owner.json"
        reduction_path = args.graph_evidence / graph_id / "reduction" / "receipt.json"
        owner_raw, owner = read(owner_path)
        reduction_raw, reduction = read(reduction_path)
        require(row["owner_sha256"] == sha(owner_raw) and row["reduction_sha256"] == sha(reduction_raw)
                and owner["reduction"]["receipt_sha256"] == sha(reduction_raw)
                and owner["status"] == reduction["status"] == "completed", "original report/source receipts differ")
        source_files.extend([{"file": str(owner_path), "sha256": sha(owner_raw)},
                             {"file": str(reduction_path), "sha256": sha(reduction_raw)}])
        request = graph["requests"][0]
        if request["request_id"] not in ORDER:
            continue
        request_id = request["request_id"]
        collection_path = args.graph_evidence / graph_id / "collection.json"
        collection_raw, collection = read(collection_path)
        require(reduction["collection_sha256"] == sha(collection_raw), "original collection/reducer binding changed")
        matches = [item for item in collection["workers"] if item["request_id"] == request_id]
        starts = [item for item in records if item["lane"] == "primary" and item["operation"] == "process_start" and item["request_id"] == request_id]
        require(len(matches) == len(starts) == 1, "exact one original collection and complete primary start required: " + request_id)
        original, raw_start = matches[0], starts[0]
        require(original["status"] == "completed" and original["start_disposition"] == "created"
                and original["start_disposition_receipt_sha256"] == raw_start["native_receipt_sha256"]
                and original["original_start_arguments_sha256"] == raw_start["arguments_sha256"], "original cold job receipt differs")
        native_args = strict(raw_start["arguments_json"])
        require(sha(native_args["stdin"].encode()) == request["request_sha256"]
                and len(native_args["stdin"].encode()) == request["request_bytes"], "original opaque stdin bytes changed")
        for stream in ("stdout", "stderr"):
            output = base64.b64decode(original[stream + "_base64"], validate=True)
            require(sha(output) == original[stream + "_sha256"] and len(output) == original[stream + "_bytes"], "original opaque output bytes changed")
        references.append({"request": request, "original": original, "original_start": raw_start,
                           "owner_sha256": sha(owner_raw), "collection_sha256": sha(collection_raw),
                           "original_start_source": {"raw_evidence_sha256": sha(ledger_raw), "scope": raw_scope,
                               "index": raw_start["index"], "prefix_byte_range": ranges.get(raw_start["index"])}})
        source_files.append({"file": str(collection_path), "sha256": sha(collection_raw)})
    require([ref["request"]["request_id"] for ref in references] == ORDER, "exact three ordered source references required")
    for index, request_id in enumerate(ORDER):
        path = args.graph_evidence / "recovery" / (request_id + ".json")
        if index == 0:
            raw, value = read(path)
            require(value["status"] == "failed" and value["request_id"] == request_id
                    and value["failure"]["message"] == "native start receipt does not bind original request/launch",
                    "preserve exact originally observed parser failure")
            census.append({"request_id": request_id, "status": "failed", "record_sha256": sha(raw), "record": value})
            source_files.append({"file": str(path), "sha256": sha(raw)})
        else:
            require(not path.exists(), "original unattempted recovery must remain absent")
            census.append({"request_id": request_id, "status": "absent", "reason": "not attempted after original admission failure"})
    bundle = {"schema": "hepta.fixed-cell-graph.recovery-source.v2", "dispatch_sha256": DISPATCH_SHA,
              "validation_protocol_sha256": sha(protocol_raw),
              "dispatch_text": dispatch_raw.decode(), "primary_report_sha256": sha(report_raw),
              "primary_report_text": report_raw.decode(), "primary_raw_evidence_sha256": sha(ledger_raw),
              "primary_raw_evidence_scope": raw_scope, "original_full_snapshot_verified": full_snapshot_verified,
              "declared_original_full_ledger_sha256": claimed_ledger_sha, "original_full_run_cost_complete": False,
              "primary_completed_graphs": 18, "primary_workers": 30, "recovery_order": ORDER,
              "original_recovery_census": census, "references": references, "source_files": source_files,
              "scope": "Imported immutable prior evidence only; no primary execution or repair of original failed recovery"}
    data = (json.dumps(bundle, ensure_ascii=False, separators=(",", ":")) + "\n").encode()
    require(len(data) <= 1_048_576, "bounded imported source bundle exceeded1MiB")
    args.output.mkdir(parents=False, exist_ok=False)
    destination = args.output / "recovery-source.json"
    with destination.open("xb") as stream:
        stream.write(data)
    receipt = {"schema": "hepta.fixed-cell-graph.recovery-source-receipt.v2", "source_bundle_sha256": sha(data),
               "validation_protocol_sha256": sha(protocol_raw),
               "source_bundle_bytes": len(data), "source_bundle": str(destination),
               "primary_raw_evidence_sha256": sha(ledger_raw), "primary_raw_evidence_scope": raw_scope,
               "original_full_snapshot_verified": full_snapshot_verified, "original_full_run_cost_complete": False,
               "primary_report_sha256": sha(report_raw),
               "source_files": source_files, "model_or_primary_calls": 0, "labels_parsed": False,
               "old_session_state_reconstructed": False}
    with (args.output / "receipt.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    return {key: receipt[key] for key in ("source_bundle", "source_bundle_sha256", "source_bundle_bytes")}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("dispatch", "graph-evidence", "primary-report", "raw-ledger", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    for name in ("expected-report-sha256", "expected-ledger-sha256"):
        parser.add_argument("--" + name, required=True)
    print(json.dumps(prepare(parser.parse_args()), indent=2))
