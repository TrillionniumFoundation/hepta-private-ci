"""Bounded prefix lexing/provenance tests; no original ledger or native calls."""

import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

SPEC = importlib.util.spec_from_file_location("prefix_v2", Path(__file__).with_name("extract_complete_raw_prefix.py"))
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode()


def record(index, text="opaque中文🤖"):
    args = json.dumps({"literal": 'nested "records":[' + text}, ensure_ascii=False)
    result = json.dumps({"native_text": text}, ensure_ascii=False)
    return {"index": index, "lane": "primary", "operation": "process_start", "request_id": f"fixture-{index}",
            "arguments_json": args, "arguments_sha256": MODULE.sha(args.encode()),
            "result_json": result, "native_receipt_sha256": MODULE.sha(result.encode())}


class Prefix(unittest.TestCase):
    def source(self):
        first, second = encoded(record(0)), encoded(record(1))
        head = b'{"schema":"hepta.fixed-cell-graph.native-ledger.v1","dispatch_sha256":"' + MODULE.DISPATCH.encode() + b'","state":{"raw_count":8,"literal":"fake records key"},"records":['
        return head, first, second

    def test_every_truncated_second_record_preserves_only_complete_first(self):
        head, first, second = self.source()
        for stop in range(1, len(second)):
            data = head + first + b"," + second[:stop]
            result = MODULE.complete_records(data)
            self.assertEqual([row["index"] for row in result["records"]], [0], stop)
            item = result["record_byte_ranges"][0]
            self.assertEqual(data[item["begin_byte"]:item["end_byte"]], first)
            self.assertEqual(item["original_record_json_sha256"], MODULE.sha(first))

    def test_complete_object_at_exact_prefix_end_is_not_fabricated(self):
        head, first, _ = self.source()
        result = MODULE.complete_records(head + first)
        self.assertEqual(len(result["records"]), 1)
        self.assertEqual(result["unparsed_tail_bytes"], 0)

    def test_nested_records_literal_does_not_select_wrong_array(self):
        head, first, second = self.source()
        result = MODULE.complete_records(head + first + b"," + second + b"],")
        self.assertEqual([row["index"] for row in result["records"]], [0, 1])
        self.assertIn("remaining envelope still not certified", result["stop_reason"])

    def test_corrupted_internal_hash_or_duplicate_key_rejected(self):
        head, _, _ = self.source()
        value = record(0)
        value["arguments_sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "argument SHA"):
            MODULE.complete_records(head + encoded(value))
        with self.assertRaisesRegex(ValueError, "duplicate JSON key"):
            MODULE.complete_records(head + b'{"index":0,"index":0}')

    def test_part_wrapper_provenance_and_no_full_sha_claim(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            parts, receipts = root / "parts", root / "receipts"
            parts.mkdir()
            receipts.mkdir()
            head, first, _ = self.source()
            complete = head + first + b"," + encoded(record(1, "x" * 600_000)) + b"]}"
            prefix = complete[:524288]
            manifest = {"dispatch_sha256": MODULE.DISPATCH, "sha256": MODULE.sha(complete), "chunk_bytes": 524288,
                        "bytes": len(complete), "chunks": (len(complete) + 524287) // 524288}
            (parts / "manifest.json").write_bytes(encoded(manifest))
            (parts / "part-000000.bin").write_bytes(prefix)
            receipt = {"schema": "hepta.fixed-cell-graph.native-wrapper-result.v1", "operation": "raw_chunk",
                       "dispatch_sha256": MODULE.DISPATCH, "wrapper_sha256": MODULE.WRAPPER,
                       "index": 0, "chunk_sha256": MODULE.sha(prefix), "publication": "created"}
            (receipts / "fixture.json").write_bytes(encoded(receipt))
            args = SimpleNamespace(parts=parts, wrapper_receipts=receipts, expected_ledger_sha256=MODULE.sha(complete), output=root / "output")
            result = MODULE.extract(args)
            self.assertEqual(result["complete_records"], 1)
            self.assertIs(result["full_ledger_sha256_verified"], False)
            self.assertIs(result["full_run_cost_complete"], False)
            self.assertEqual((args.output / "original-prefix.bin").read_bytes(), prefix)
            receipt["chunk_sha256"] = "0" * 64
            (receipts / "fixture.json").write_bytes(encoded(receipt))
            args.output = root / "rejected"
            with self.assertRaisesRegex(ValueError, "acknowledgement missing"):
                MODULE.extract(args)
            self.assertFalse(args.output.exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
