"""Exclusive local-file checkpoint tests; all files stay in a temp directory."""

import base64
import hashlib
import importlib.util
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location("writer_v2", Path(__file__).with_name("write_recovery_journal_v2.py"))
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class Writer(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        previous = MODULE.ROOT
        MODULE.ROOT = Path(self.temp.name) / "journal"
        self.addCleanup(self.temp.cleanup)
        self.addCleanup(setattr, MODULE, "ROOT", previous)
        self.namespace = "a" * 64
        self.name = "raw-000000-intent.json"

    def call(self, data=b'{"exact":"opaque"}\n', **overrides):
        values = dict(namespace=self.namespace, name=self.name, expected_sha256=hashlib.sha256(data).hexdigest(),
                      parts=[base64.b64encode(data).decode()])
        values.update(overrides)
        return MODULE.write(**values)

    def test_exclusive_exact_bytes_and_no_overwrite(self):
        data = '{"exact":"中文🤖\\n"}\n'.encode()
        receipt = self.call(data)
        self.assertEqual(Path(receipt["file"]).read_bytes(), data)
        self.assertEqual(receipt["publication"], "created")
        self.assertGreaterEqual(receipt["writer_cpu_ns_before_ack"], 0)
        with self.assertRaises(FileExistsError):
            self.call(b"replacement")
        self.assertEqual(Path(receipt["file"]).read_bytes(), data)

    def test_bad_hash_never_creates_namespace(self):
        with self.assertRaisesRegex(ValueError, "checkpoint bytes"):
            self.call(expected_sha256="0" * 64)
        self.assertFalse(MODULE.ROOT.exists())

    def test_traversal_and_invalid_namespace_rejected(self):
        for patch in ({"name": "../original.json"}, {"namespace": "../old-state"}, {"name": "owner.json"}):
            with self.assertRaisesRegex(ValueError, "namespace/name"):
                self.call(**patch)
        self.assertFalse(MODULE.ROOT.exists())

    def test_symlink_namespace_refused(self):
        MODULE.ROOT.mkdir()
        target = Path(self.temp.name) / "unrelated"
        target.mkdir()
        (MODULE.ROOT / self.namespace).symlink_to(target, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, "symlink"):
            self.call()
        self.assertEqual(list(target.iterdir()), [])

    def test_bounded_split_base64_writes_complete_large_record(self):
        data = b"opaque" * 40000
        encoded = base64.b64encode(data).decode()
        parts = [encoded[i:i+16384] for i in range(0, len(encoded), 16384)]
        receipt = self.call(data, parts=parts)
        self.assertEqual(Path(receipt["file"]).read_bytes(), data)
        with self.assertRaisesRegex(ValueError, "base64 parts"):
            self.call(data, name="raw-000001-intent.json")


if __name__ == "__main__":
    unittest.main(verbosity=2)
