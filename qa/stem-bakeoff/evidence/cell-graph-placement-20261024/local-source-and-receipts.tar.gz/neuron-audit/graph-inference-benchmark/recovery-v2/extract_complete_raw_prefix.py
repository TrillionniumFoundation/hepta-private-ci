"""Recover only complete original JSON records from persisted raw-prefix chunks.

This does not complete/seal the old ledger or invent its missing tail. Full
ledger SHA remains unverified. All output is written to a new directory.
"""

import argparse
import codecs
import hashlib
import json
from pathlib import Path
import re
import time


WRAPPER = "fced1311223adde960d9e0c04fc40c8e816d01a4e078f09f802b67b20d3e5b45"
DISPATCH = "595d40d93a9ba394c21c39fd41c5c8b60ab5ceddfcdb8bdd9f5102ce193fa4ae"
MAXIMUM = 8_388_608


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique(items):
    value = {}
    for key, item in items:
        require(key not in value, "duplicate JSON key")
        value[key] = item
    return value


DECODER = json.JSONDecoder(object_pairs_hook=unique,
    parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def read(path, maximum=1_048_576):
    require(not path.is_symlink() and path.is_file() and path.stat().st_size <= maximum, "bounded regular file required: " + str(path))
    data = path.read_bytes()
    return data, json.loads(data, object_pairs_hook=unique)


def complete_records(prefix):
    decoder = codecs.getincrementaldecoder("utf-8")("strict")
    text = decoder.decode(prefix, final=False)
    undecoded, _ = decoder.getstate()
    position, header = 0, {}

    def whitespace(index):
        while index < len(text) and text[index] in " \t\r\n":
            index += 1
        return index

    def token(index, expected):
        index = whitespace(index)
        require(index < len(text) and text[index] == expected, "original top-level JSON prefix syntax differs")
        return index + 1

    position = token(position, "{")
    while True:
        position = whitespace(position)
        key, end = DECODER.raw_decode(text, position)
        require(isinstance(key, str) and key not in header, "unique original top-level key required")
        position = token(end, ":")
        if key == "records":
            position = token(position, "[")
            break
        value, position = DECODER.raw_decode(text, whitespace(position))
        header[key] = value
        position = token(position, ",")
    records, ranges, stop = [], [], "prefix exhausted"
    while True:
        position = whitespace(position)
        if position >= len(text):
            break
        if text[position] == "]":
            stop = "original records array ended within prefix; remaining envelope still not certified"
            break
        require(text[position] == "{", "raw array elements must be original objects")
        start = position
        try:
            value, end = DECODER.raw_decode(text, start)
        except json.JSONDecodeError:
            stop = "next original object is incomplete or undecodable in persisted prefix; bytes retained unchanged"
            break
        require(isinstance(value, dict) and value.get("index") == len(records), "complete original prefix indices must begin at0 without holes")
        require(sha(value["arguments_json"].encode()) == value["arguments_sha256"], "original record argument SHA mismatch")
        if "result_json" in value:
            require(sha(value["result_json"].encode()) == value["native_receipt_sha256"], "original record native-result SHA mismatch")
        begin_byte, end_byte = len(text[:start].encode()), len(text[:end].encode())
        require(prefix[begin_byte:end_byte] == text[start:end].encode(), "original byte range differs")
        records.append(value)
        ranges.append({"index": value["index"], "begin_byte": begin_byte, "end_byte": end_byte,
                       "original_record_json_sha256": sha(prefix[begin_byte:end_byte])})
        position = whitespace(end)
        if position >= len(text):
            break
        if text[position] == "]":
            stop = "original records array ended within prefix; remaining envelope still not certified"
            break
        require(text[position] == ",", "original record delimiter differs")
        position += 1
    trailing_start = len(text[:position].encode())
    return {"header": header, "records": records, "record_byte_ranges": ranges,
            "stop_reason": stop, "unparsed_tail_begin_byte": trailing_start,
            "unparsed_tail_bytes": len(prefix) - trailing_start,
            "unparsed_tail_sha256": sha(prefix[trailing_start:]), "incomplete_utf8_tail_bytes": len(undecoded)}


def extract(args):
    started, cpu = time.perf_counter_ns(), time.process_time_ns()
    manifest_raw, manifest = read(args.parts / "manifest.json")
    require(manifest["dispatch_sha256"] == DISPATCH and manifest["sha256"] == args.expected_ledger_sha256
            and manifest["chunk_bytes"] == 524288 and manifest["chunks"] == (manifest["bytes"] + 524287) // 524288,
            "original ledger manifest differs")
    parts = sorted(args.parts.glob("part-*.bin"))
    require(parts and [path.name for path in parts] == [f"part-{i:06d}.bin" for i in range(len(parts))], "only exact contiguous existing prefix parts may be extracted")
    require(len(parts) < manifest["chunks"] and len(parts) * 524288 <= MAXIMUM, "this tool is only for bounded partial prefixes, not a replacement full-ledger seal")
    receipt_sources = []
    for path in sorted(args.wrapper_receipts.glob("*.json")):
        data, value = read(path)
        if value.get("operation") == "raw_chunk":
            receipt_sources.append((path, data, value))
    evidence, chunks = [], []
    for index, path in enumerate(parts):
        require(not path.is_symlink() and path.is_file() and path.stat().st_size == 524288, "original complete prefix chunk size differs")
        data = path.read_bytes()
        matches = [(p, raw, value) for p, raw, value in receipt_sources
                   if value.get("schema") == "hepta.fixed-cell-graph.native-wrapper-result.v1"
                   and value.get("dispatch_sha256") == DISPATCH and value.get("wrapper_sha256") == WRAPPER
                   and value.get("index") == index and value.get("chunk_sha256") == sha(data)
                   and value.get("publication") in ("created", "identical_existing")]
        require(matches, "original chunk wrapper acknowledgement missing for index " + str(index))
        evidence.append({"index": index, "file": str(path), "bytes": len(data), "sha256": sha(data),
                         "wrapper_receipts": [{"file": str(p), "sha256": sha(raw), "receipt": value} for p, raw, value in matches]})
        chunks.append(data)
    prefix = b"".join(chunks)
    result = complete_records(prefix)
    require(result["header"].get("schema") == "hepta.fixed-cell-graph.native-ledger.v1"
            and result["header"].get("dispatch_sha256") == DISPATCH, "parsed original snapshot header differs")
    result.update(schema="hepta.fixed-cell-graph.partial-native-prefix.v2", dispatch_sha256=DISPATCH,
                  declared_full_ledger_sha256=manifest["sha256"], full_ledger_sha256_verified=False,
                  declared_full_ledger_bytes=manifest["bytes"], declared_full_chunk_count=manifest["chunks"],
                  present_prefix_chunk_count=len(parts), prefix_bytes=len(prefix), prefix_sha256=sha(prefix),
                  manifest_sha256=sha(manifest_raw), original_manifest=manifest, parts=evidence,
                  original_complete_record_count=len(result["records"]), full_run_cost_complete=False,
                  missing_original_suffix_bytes=manifest["bytes"] - len(prefix),
                  no_repaired_or_synthesized_original_records=True,
                  extraction_wall_ns_before_publication=time.perf_counter_ns() - started,
                  extraction_cpu_ns_before_publication=time.process_time_ns() - cpu)
    args.output.mkdir(parents=False, exist_ok=False)
    with (args.output / "original-prefix.bin").open("xb") as stream:
        stream.write(prefix)
    output = (json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n").encode()
    with (args.output / "complete-prefix-records.json").open("xb") as stream:
        stream.write(output)
    found = [record["request_id"] for record in result["records"] if record["lane"] == "primary" and record["operation"] == "process_start"]
    return {"output": str(args.output), "records_bytes": len(output), "records_sha256": sha(output), "prefix_sha256": sha(prefix),
            "complete_records": len(result["records"]), "original_primary_start_ids": found,
            "full_ledger_sha256_verified": False, "full_run_cost_complete": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("parts", "wrapper-receipts", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--expected-ledger-sha256", required=True)
    print(json.dumps(extract(parser.parse_args()), indent=2))
