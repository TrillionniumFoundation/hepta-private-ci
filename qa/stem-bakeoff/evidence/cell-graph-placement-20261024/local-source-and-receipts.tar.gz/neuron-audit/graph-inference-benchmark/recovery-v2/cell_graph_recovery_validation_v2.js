/* Separate, recovery-only qualification. Evaluate after the frozen byte helpers
 * and cell_graph_recovery_start_v2.js. No original adapter state is consulted or
 * changed. The unchanged recoverCellGraphNode remains the owner of the24-call,
 * 60s lookup/read interval. Publication is a separate root-owned operation.
 */
function createCellGraphRecoveryValidationV2({tools, store, load, journal, inputs}) {
  const constructionStarted = Date.now(), B = CellGraphBytes, S = CellGraphRecoveryStartV2, check = B.requireValue;
  const DISPATCH = "595d40d93a9ba394c21c39fd41c5c8b60ab5ceddfcdb8bdd9f5102ce193fa4ae";
  const ORDER = ["b0-A-s0", "b0-B-s0", "b0-C-s0"];
  const TOOLS = {process_start:"mcp__codex_apps__hepta_runtime_full_operator_process_start",
    process_status:"mcp__codex_apps__hepta_runtime_full_operator_process_status", process_read:"mcp__codex_apps__hepta_runtime_full_operator_process_read"};
  const equal = (a,b) => B.json(a) === B.json(b), clone = value => B.parseJSON(B.json(value));
  const size = text => B.utf8(text).length;
  const isSha = value => typeof value === "string" && /^[0-9a-f]{64}$/.test(value);
  check(typeof store === "function" && typeof load === "function", "session store/load required; not a durable journal");
  check(typeof journal === "function", "exclusive per-call root file journal is mandatory before any lookup");
  check(typeof inputs.source_bundle_text === "string" && size(inputs.source_bundle_text) <= 1048576 &&
    isSha(inputs.source_bundle_sha256) && B.hashText(inputs.source_bundle_text) === inputs.source_bundle_sha256, "exact bounded imported evidence bundle required");
  const source = B.parseJSON(inputs.source_bundle_text);
  check(isSha(inputs.validation_protocol_sha256) && source.validation_protocol_sha256===inputs.validation_protocol_sha256,
    "separately frozen recovery-validation protocol identity required");
  check(source.schema === "hepta.fixed-cell-graph.recovery-source.v2" && source.dispatch_sha256 === DISPATCH &&
    equal(source.recovery_order, ORDER) && source.primary_completed_graphs === 18 && source.primary_workers === 30 &&
    isSha(source.primary_report_sha256) && isSha(source.primary_raw_evidence_sha256) &&
    source.original_full_run_cost_complete===false && typeof source.original_full_snapshot_verified==="boolean",
    "complete original primary numerical census and bounded original start evidence required");
  check(typeof source.dispatch_text === "string" && B.hashText(source.dispatch_text) === DISPATCH &&
    typeof source.primary_report_text === "string" && B.hashText(source.primary_report_text) === source.primary_report_sha256,
    "exact original dispatch and unchanged reporter output required");
  const dispatch=B.parseJSON(source.dispatch_text), primaryReport=B.parseJSON(source.primary_report_text);
  check(dispatch.schema==="hepta.fixed-cell-graph.dispatch.v1" && dispatch.graphs.length===18 && dispatch.requests===30 &&
    primaryReport.schema==="hepta.fixed-cell-graph.report.v1" && primaryReport.dispatch_sha256===DISPATCH &&
    primaryReport.completed_comparable_graphs===18 && primaryReport.rows.length===18 && primaryReport.failed_or_noncomparable.length===0 &&
    primaryReport.rows.every((row,i)=>row.graph_id===dispatch.graphs[i].graph_id && row.status==="completed"),
    "unchanged original reporter must retain all18 completed primary rows");
  check(source.original_recovery_census && source.original_recovery_census.length === 3 &&
    source.original_recovery_census[0].request_id === ORDER[0] && source.original_recovery_census[0].status === "failed" &&
    source.original_recovery_census.slice(1).every((item,i) => item.request_id === ORDER[i+1] && item.status === "absent"),
    "preserve original failed A and unattempted B/C recovery census");
  check(source.references && source.references.length === 3, "exact three original references required");
  const refs = {};
  for (let i = 0; i < ORDER.length; i++) {
    const ref = source.references[i], r = ref.request, original = ref.original, raw = ref.original_start;
    check(equal(r,dispatch.graphs.find(graph=>graph.graph_id===ORDER[i].slice(0,4))?.requests[0]), "reference request differs from exact dispatch");
    check(r && r.request_id === ORDER[i] && original && raw && raw.lane === "primary" && raw.operation === "process_start" &&
      raw.request_id === r.request_id && raw.status === "returned" && B.hashText(raw.arguments_json) === raw.arguments_sha256 &&
      B.hashText(raw.result_json) === raw.native_receipt_sha256, "original start raw byte proof required");
    const args = B.parseJSON(raw.arguments_json), receipt = S.exactReceipt(B.parseJSON(raw.result_json));
    check(B.json(args) === raw.arguments_json && args.host === r.host && args.idempotency_key === r.idempotency_key &&
      B.hashText(args.stdin) === r.request_sha256 && size(args.stdin) === r.request_bytes && args.timeout_seconds === 45 &&
      args.cpu_quota_percent === r.cpu_quota_percent && args.memory_max_bytes === r.memory_max_bytes,
      "original native launch bytes/resources differ from frozen dispatch");
    const bound = S.bind(receipt, args, "created");
    check(original.request_id === r.request_id && original.host === r.host && original.request_sha256 === r.request_sha256 &&
      original.idempotency_key === r.idempotency_key && original.status === "completed" && original.exit_code === 0 &&
      original.start_disposition === "created" && original.stdout_complete === true && original.truncated === false &&
      original.job_id === bound.job_id && original.native_request_digest === bound.native_request_digest &&
      original.native_request_fingerprint === bound.native_request_fingerprint &&
      original.original_start_arguments_sha256 === raw.arguments_sha256 && original.start_disposition_receipt_sha256 === raw.native_receipt_sha256,
      "successful original collection/job binding required");
    for (const stream of ["stdout", "stderr"]) {
      const data = B.unbase64(original[stream+"_base64"]);
      check(data.length === original[stream+"_bytes"] && B.sha256(data) === original[stream+"_sha256"], "original complete output byte proof differs");
    }
    check(original.stdout_bytes > 0 && original.stdout_bytes <= 196608 && original.stderr_bytes <= 8192, "original full bounded output required");
    refs[r.request_id] = clone(ref);
  }
  const prefix = "cell-graph-recovery-validation-v2:" + DISPATCH + ":" + inputs.source_bundle_sha256 + ":";
  const get = key => load(prefix+key), put = (key,value) => store(prefix+key,value);
  let state = get("state");
  if (state === undefined) {
    state = {schema:"hepta.fixed-cell-graph.recovery-validation-state.v2", source_bundle_sha256:inputs.source_bundle_sha256,
      validation_protocol_sha256:inputs.validation_protocol_sha256,
      dispatch_sha256:DISPATCH, next_case:0, active:null, attempts:{}, outstanding:null, raw_count:0, constructions:[], checkpoints:[]};
    put("state",state);
  }
  check(state.schema === "hepta.fixed-cell-graph.recovery-validation-state.v2" && state.source_bundle_sha256 === inputs.source_bundle_sha256,
    "separate validation state identity differs");
  async function checkpoint(fileName,value) {
    const text=B.json(value)+"\n",dataSha=B.hashText(text),started=Date.now();
    const entry={namespace:inputs.source_bundle_sha256,file_name:fileName,text,sha256:dataSha,bytes:size(text)};
    let receipt;
    try {
      receipt=await journal(entry);
      check(receipt && receipt.publication==="created" && receipt.namespace===entry.namespace && receipt.file_name===fileName &&
        receipt.sha256===dataSha && receipt.bytes===entry.bytes,"exclusive file-journal acknowledgement differs; never retry/overwrite");
    } catch(error) {
      const latest=get("state");latest.journal_failure={file_name:fileName,name:error.name,message:error.message};put("state",latest);throw error;
    }
    const completed=Date.now(),saved={file_name:fileName,sha256:dataSha,bytes:entry.bytes,started_ms:started,completed_ms:completed,
      elapsed_ms:completed-started,receipt};
    const latest=get("state");latest.checkpoints.push(saved);put("state",latest);return saved;
  }
  function checked(request) {
    const ref = refs[request.request_id]; check(ref && equal(ref.request,request), "request differs from frozen imported reference"); return ref;
  }
  async function native(operation,args,request) {
    check(Object.hasOwn(TOOLS,operation), "only original start/status/read allowed");
    const ref = checked(request), current = get("state"), argumentText = B.json(args);
    check(current.active === request.request_id, "native call outside single active validation case");
    if (operation === "process_start") {
      check(current.outstanding === null && argumentText === ref.original_start.arguments_json,
        "one byte-identical original lookup, never a new request/key or retry");
      current.outstanding = {request_id:request.request_id, host:request.host, job_id:null,
        expected_job_id:ref.original.job_id, arguments_sha256:B.hashText(argumentText), status:"lookup_attempted_outcome_unknown"};
    } else {
      check(args.host === request.host && args.job_id === ref.original.job_id, "read/status changed original job");
    }
    const index = current.raw_count++; put("state",current);
    const key = "raw:"+String(index).padStart(6,"0");
    const record = {schema:"hepta.fixed-cell-graph.recovery-native-call.v2", index, lane:"recovery-v2", operation,
      request_id:request.request_id, arguments_json:argumentText, arguments_sha256:B.hashText(argumentText),
      logical_tool_request_bytes:size(argumentText), started_ms:Date.now(), status:"pending",native_call_attempted:false};
    put(key,record);
    try {
      // If this write/ack fails, the original Runtime call is never made.
      // A returned raw MCP response is written immediately, before validation.
      record.intent_checkpoint=await checkpoint(`raw-${String(index).padStart(6,"0")}-intent.json`,clone(record));
      const admissionTime=Date.now(),ownerNotBefore=get("state").owner_dispatch_started_ms;
      check(Number.isSafeInteger(ownerNotBefore) && admissionTime>=ownerNotBefore && admissionTime-ownerNotBefore<=60000,
        "journal return exceeded original60s owner admission bound; no native call made");
      record.native_await_started_ms=Date.now();
      record.native_call_attempted=true;put(key,record);
      const result = await tools[TOOLS[operation]](clone(args));
      record.finished_ms=Date.now(); record.elapsed_ms=record.finished_ms-record.started_ms;
      record.native_await_finished_ms=record.finished_ms;
      record.native_await_elapsed_ms=record.finished_ms-record.native_await_started_ms;
      record.cost_scope="started/finished encloses intent-file acknowledgement and native await; native_await_* is the nested API span. Return-file acknowledgement is separate but inside frozen owner. Never add nested spans.";
      record.result_json=B.json(result); record.native_receipt_sha256=B.hashText(record.result_json);
      record.logical_tool_response_bytes=size(record.result_json); record.status="returned"; put(key,record);
      record.returned_checkpoint=await checkpoint(`raw-${String(index).padStart(6,"0")}-returned.json`,clone(record));
      put(key,record);
      const value = S.exactReceipt(result);
      if (operation === "process_status" && value.job_id === ref.original.job_id && ["succeeded","failed"].includes(value.state) &&
          Number.isSafeInteger(value.exit_code) && typeof value.timed_out === "boolean" && typeof value.cancelled === "boolean") {
        const latest=get("state");
        if (latest.outstanding && latest.outstanding.job_id===value.job_id) {
          latest.settlement={...latest.outstanding,observed_state:value.state,exit_code:value.exit_code,native_receipt_sha256:record.native_receipt_sha256};
          latest.outstanding=null; put("state",latest);
        }
      }
      return {value,native_receipt_sha256:record.native_receipt_sha256,logical_tool_request_bytes:record.logical_tool_request_bytes,
        logical_tool_response_bytes:record.logical_tool_response_bytes};
    } catch (error) {
      record.finished_ms=Date.now(); record.elapsed_ms=record.finished_ms-record.started_ms;
      record.status="failed"; record.failure={name:error.name,message:error.message}; put(key,record);
      try {record.failure_checkpoint=await checkpoint(`raw-${String(index).padStart(6,"0")}-failure.json`,clone(record));}
      catch(journalError){record.failure_journal_error={name:journalError.name,message:journalError.message};}
      put(key,record); throw error;
    }
  }
  async function replayOriginalStart(request,original) {
    const ref=checked(request); check(equal(original,ref.original), "original output/binding changed");
    const args=B.parseJSON(ref.original_start.arguments_json), call=await native("process_start",args,request);
    const bound=S.bind(call.value,args,"reused",original), current=get("state");
    check(current.outstanding && current.outstanding.request_id===request.request_id, "lookup intent absent");
    current.outstanding.job_id=bound.job_id; current.outstanding.status="acknowledged_awaiting_terminal"; put("state",current);
    return {...call,...bound,start_arguments_sha256:ref.original_start.arguments_sha256};
  }
  async function collect(request,submitted,instrument) {
    const ref=checked(request); check(submitted.job_id===ref.original.job_id && submitted.start_disposition==="reused", "original reused job required");
    let statusCall,end; const statusArgs={host:request.host,job_id:submitted.job_id};
    for(let attempt=0;attempt<10;attempt++) {
      statusCall=await instrument("process_status",()=>native("process_status",statusArgs,request));
      end=S.terminal(statusCall.value,submitted.job_id); if(end)break;
      if(attempt<9)await new Promise(resolve=>setTimeout(resolve,3000));
    }
    check(Boolean(end), "authoritative terminal output unavailable within10 status observations");
    const parts={stdout:[],stderr:[]}, offsets={stdout:0,stderr:0}; let pages=0;
    do {
      check(pages++<12,"bounded stdout pagination exceeded");
      const args={...statusArgs,limit:16384,stdout_offset:offsets.stdout,stderr_offset:offsets.stderr};
      const call=await instrument("process_read",()=>native("process_read",args,request));
      check(call.value.job_id===submitted.job_id,"native read changed job ID");
      for(const stream of ["stdout","stderr"]) {
        const item=call.value[stream]; check(item && item.offset===offsets[stream] && item.size===end[stream] && typeof item.eof==="boolean", "read range/terminal size differs");
        const data=B.unhex(item.bytes_hex);
        check(data.length<=16384 && item.next_offset===item.offset+data.length && item.next_offset<=item.size &&
          item.eof===(item.next_offset===item.size) && (data.length>0 || item.eof),"read cursor has holes/repeats/nonprogress or false EOF");
        parts[stream].push(data); offsets[stream]=item.next_offset;
      }
    } while(offsets.stdout!==end.stdout || offsets.stderr!==end.stderr);
    const finalCall=await instrument("process_status",()=>native("process_status",statusArgs,request));
    const final=S.terminal(finalCall.value,submitted.job_id); check(final && equal(final,end),"terminal status/log identity changed during collection");
    const out=parts.stdout.flat(),err=parts.stderr.flat();
    check(B.sha256(out)===ref.original.stdout_sha256 && B.base64(out)===ref.original.stdout_base64 &&
      B.sha256(err)===ref.original.stderr_sha256 && B.base64(err)===ref.original.stderr_base64, "original complete stdout/stderr changed");
    return {request_id:request.request_id,host:request.host,request_sha256:request.request_sha256,idempotency_key:request.idempotency_key,
      job_id:submitted.job_id,original_start_arguments_sha256:submitted.start_arguments_sha256,start_disposition:submitted.start_disposition,
      start_disposition_receipt_sha256:submitted.native_receipt_sha256,native_request_digest:submitted.native_request_digest,
      native_request_fingerprint:submitted.native_request_fingerprint,status:final.state==="succeeded" && final.exit_code===0 ? "completed":"failed",
      exit_code:final.exit_code,timed_out:final.timed_out,cancelled:final.cancelled,stdout_complete:true,truncated:false,
      stdout_bytes:out.length,stderr_bytes:err.length,stdout_base64:B.base64(out),stdout_sha256:B.sha256(out),
      stderr_base64:B.base64(err),stderr_sha256:B.sha256(err),authoritative_status_sha256:finalCall.native_receipt_sha256,
      initial_terminal_status_sha256:statusCall.native_receipt_sha256,read_pages:pages,native_process_cpu_ns:null,
      native_process_peak_rss_bytes:null,unexposed_native_process_cost_not_zero:true};
  }
  async function publishRecovery(request,record) {
    checked(request); const current=get("state");
    check(current.active===request.request_id && record.request_id===request.request_id && record.dispatch_sha256===DISPATCH &&
      get("record:"+request.request_id)===undefined, "exclusive separate recovery record required");
    put("record:"+request.request_id,clone(record));
    await checkpoint(`case-${request.request_id}-record.json`,{schema:"hepta.fixed-cell-graph.recovery-case-checkpoint.v2",
      validation_protocol_sha256:inputs.validation_protocol_sha256,
      source_bundle_sha256:inputs.source_bundle_sha256,record:clone(record),raw_count:current.raw_count,checkpoints:clone(current.checkpoints)});
    const latest=get("state");
    latest.attempts[request.request_id]={...latest.attempts[request.request_id],status:record.status,completed_ms:record.completed_ms};
    latest.next_case++; latest.active=null; put("state",latest);
  }
  const ownerAdapter={replayOriginalStart,collect,publishRecovery};
  async function runNext(requestId,executeRecovery) {
    const current=get("state"), ref=refs[requestId];
    check(current.active===null && current.outstanding===null && !current.journal_failure && ORDER[current.next_case]===requestId &&
      current.attempts[requestId]===undefined && executeRecovery===recoverCellGraphNode, "next original lookup with frozen owner only; no retry/unsettled overlap");
    const started=Date.now(); current.active=requestId; current.attempts[requestId]={status:"pending",started_ms:started}; put("state",current);
    const outer={request_id:requestId,started_ms:started,status:"pending"}; put("outer:"+requestId,outer);
    try {
      await checkpoint(`case-${requestId}-intent.json`,{schema:"hepta.fixed-cell-graph.recovery-case-intent.v2",
        validation_protocol_sha256:inputs.validation_protocol_sha256,
        source_bundle_sha256:inputs.source_bundle_sha256,request_id:requestId,original_job_id:ref.original.job_id,
        original_arguments_sha256:ref.original_start.arguments_sha256,started_ms:started,attempt:1});
      const admitted=get("state");admitted.owner_dispatch_started_ms=Date.now();put("state",admitted);
      const result=await executeRecovery(clone(ref.request),clone(ref.original),DISPATCH,ownerAdapter); outer.status="returned"; return result;
    }
    catch(error) {outer.status="threw";outer.failure={name:error.name,message:error.message};throw error;}
    finally {
      outer.completed_ms=Date.now();outer.elapsed_ms=outer.completed_ms-started;put("outer:"+requestId,outer);
      try {await checkpoint(`case-${requestId}-outer.json`,{schema:"hepta.fixed-cell-graph.recovery-outer-checkpoint.v2",
        source_bundle_sha256:inputs.source_bundle_sha256,outer:clone(outer),state:clone(get("state")),
        scope:"Outer interval includes case-intent and owner/publication; excludes this final outer-file acknowledgement."});}
      catch(error){outer.outer_journal_error={name:error.name,message:error.message};put("outer:"+requestId,outer);throw error;}
    }
  }
  function snapshot() {
    const current=clone(get("state")),records=[];
    for(let i=0;i<current.raw_count;i++){const item=get("raw:"+String(i).padStart(6,"0"));check(item,"raw receipt missing");records.push(item);}
    return {schema:"hepta.fixed-cell-graph.recovery-validation-evidence.v2",source_bundle_sha256:inputs.source_bundle_sha256,
      validation_protocol_sha256:inputs.validation_protocol_sha256,
      dispatch_sha256:DISPATCH,state:current,records,cases:ORDER.map(id=>({request_id:id,
        classification:get("record:"+id)?.status ?? (current.attempts[id] ? "attempted_outcome_unknown":"unattempted"),
        record:get("record:"+id)??null,outer:get("outer:"+id)??null})),
      original_recovery_census:clone(source.original_recovery_census),publication_scope:"Mandatory exclusive root files for every raw-call intent/return and case. Session state alone is not durable; final copy/archive is separate. Original graph/recovery evidence is never overwritten.",
      old_worker_cost_not_charged_again:true,native_process_cpu_ns:null,native_process_peak_rss_bytes:null};
  }
  const finished=Date.now(); state=get("state"); state.constructions.push({started_ms:constructionStarted,completed_ms:finished,
    elapsed_ms:finished-constructionStarted,source_bundle_bytes:size(inputs.source_bundle_text),scope:"Import/byte checks only; outside recovery owner interval; JS CPU/RSS unknown"}); put("state",state);
  return {runNext,snapshot,getState:()=>clone(get("state")),storePrefix:prefix};
}
