"""Metadata/opaque-byte preparation tests, no model or native jobs."""

import base64
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest


SPEC = importlib.util.spec_from_file_location("prepare_v2", Path(__file__).with_name("prepare_recovery_validation_v2.py"))
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def encoded(value):
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


class Preparation(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.saved_pin = MODULE.DISPATCH_SHA
        self.addCleanup(self.temp.cleanup)
        self.addCleanup(setattr, MODULE, "DISPATCH_SHA", self.saved_pin)
        self.graphs = self.root / "graphs"
        self.graphs.mkdir()
        plans = []
        for block, order in enumerate(("ABC", "ACB", "BAC", "BCA", "CAB", "CBA")):
            for arm in order:
                graph_id = f"b{block}-{arm}"
                request = {"request_id": graph_id + "-s0", "request_sha256": MODULE.sha(b"opaque synthetic stdin"), "request_bytes": 22}
                plans.append({"graph_id": graph_id, "requests": [request]})
        dispatch = {"graphs": plans}
        self.dispatch = self.root / "dispatch.json"
        self.dispatch.write_bytes(encoded(dispatch))
        MODULE.DISPATCH_SHA = MODULE.sha(self.dispatch.read_bytes())
        rows, records = [], []
        for graph in plans:
            graph_id = graph["graph_id"]
            folder = self.graphs / graph_id
            (folder / "reduction").mkdir(parents=True)
            collection = {"workers": []}
            if graph_id in ("b0-A", "b0-B", "b0-C"):
                request_id = graph["requests"][0]["request_id"]
                argument_text = json.dumps({"stdin": "opaque synthetic stdin"}, separators=(",", ":"))
                result_text = json.dumps({"synthetic": True})
                record = {"index": len(records), "lane": "primary", "operation": "process_start", "request_id": request_id,
                          "arguments_json": argument_text, "arguments_sha256": MODULE.sha(argument_text.encode()),
                          "result_json": result_text, "native_receipt_sha256": MODULE.sha(result_text.encode())}
                records.append(record)
                node = {"request_id": request_id, "status": "completed", "start_disposition": "created",
                        "start_disposition_receipt_sha256": record["native_receipt_sha256"],
                        "original_start_arguments_sha256": record["arguments_sha256"]}
                for stream, output in (("stdout", b"opaque output"), ("stderr", b"")):
                    node.update({stream + "_base64": base64.b64encode(output).decode(), stream + "_sha256": MODULE.sha(output), stream + "_bytes": len(output)})
                collection["workers"].append(node)
            (folder / "collection.json").write_bytes(encoded(collection))
            reduction = {"status": "completed", "collection_sha256": MODULE.sha(encoded(collection))}
            reduction_bytes = encoded(reduction)
            (folder / "reduction" / "receipt.json").write_bytes(reduction_bytes)
            owner = {"status": "completed", "reduction": {"receipt_sha256": MODULE.sha(reduction_bytes)}}
            owner_bytes = encoded(owner)
            (folder / "owner.json").write_bytes(owner_bytes)
            rows.append({"graph_id": graph_id, "status": "completed", "owner_sha256": MODULE.sha(owner_bytes), "reduction_sha256": MODULE.sha(reduction_bytes)})
        self.report = self.root / "report.json"
        self.report.write_bytes(encoded({"schema": "hepta.fixed-cell-graph.report.v1", "dispatch_sha256": MODULE.DISPATCH_SHA,
                                        "completed_comparable_graphs": 18, "rows": rows, "failed_or_noncomparable": []}))
        self.ledger = self.root / "ledger.json"
        self.ledger.write_bytes(encoded({"schema": "hepta.fixed-cell-graph.native-ledger.v1", "dispatch_sha256": MODULE.DISPATCH_SHA,
                                        "state": {"raw_count": len(records)}, "records": records}))
        (self.graphs / "recovery").mkdir()
        (self.graphs / "recovery" / "b0-A-s0.json").write_bytes(encoded({"status": "failed", "request_id": "b0-A-s0",
            "failure": {"message": "native start receipt does not bind original request/launch"}}))
        self.args = SimpleNamespace(dispatch=self.dispatch, primary_report=self.report, raw_ledger=self.ledger, graph_evidence=self.graphs,
            expected_report_sha256=MODULE.sha(self.report.read_bytes()), expected_ledger_sha256=MODULE.sha(self.ledger.read_bytes()), output=self.root / "prepared")

    def test_opaque_bytes_and_original_failure_preserved(self):
        before = {str(p): MODULE.sha(p.read_bytes()) for p in self.root.rglob("*") if p.is_file()}
        result = MODULE.prepare(self.args)
        data = Path(result["source_bundle"]).read_bytes()
        self.assertEqual(MODULE.sha(data), result["source_bundle_sha256"])
        value = json.loads(data)
        self.assertEqual([row["status"] for row in value["original_recovery_census"]], ["failed", "absent", "absent"])
        self.assertEqual([ref["request"]["request_id"] for ref in value["references"]], MODULE.ORDER)
        for name, digest in before.items():
            self.assertEqual(MODULE.sha(Path(name).read_bytes()), digest)

    def test_partial_raw_snapshot_rejected(self):
        value = json.loads(self.ledger.read_bytes())
        value["records"].pop()
        self.ledger.write_bytes(encoded(value))
        self.args.expected_ledger_sha256 = MODULE.sha(self.ledger.read_bytes())
        with self.assertRaisesRegex(ValueError, "full original snapshot"):
            MODULE.prepare(self.args)
        self.assertFalse(self.args.output.exists())

    def test_changed_report_hash_rejected(self):
        self.report.write_bytes(self.report.read_bytes() + b" ")
        with self.assertRaisesRegex(ValueError, "reporter bytes changed"):
            MODULE.prepare(self.args)

    def test_changed_opaque_output_rejected(self):
        path = self.graphs / "b0-A" / "collection.json"
        value = json.loads(path.read_bytes())
        value["workers"][0]["stdout_base64"] = base64.b64encode(b"changed").decode()
        path.write_bytes(encoded(value))
        with self.assertRaisesRegex(ValueError, "collection/reducer"):
            MODULE.prepare(self.args)

    def test_preexisting_new_output_never_overwritten(self):
        MODULE.prepare(self.args)
        before = (self.args.output / "recovery-source.json").read_bytes()
        with self.assertRaises(FileExistsError):
            MODULE.prepare(self.args)
        self.assertEqual((self.args.output / "recovery-source.json").read_bytes(), before)

    def test_original_missing_case_not_promoted(self):
        (self.graphs / "recovery" / "b0-B-s0.json").write_text("{}\n")
        with self.assertRaisesRegex(ValueError, "must remain absent"):
            MODULE.prepare(self.args)

    def make_partial(self, keep=3):
        source = json.loads(self.ledger.read_bytes())
        records = source["records"][:keep]
        prefix = b'{"schema":"hepta.fixed-cell-graph.native-ledger.v1","dispatch_sha256":"' + MODULE.DISPATCH_SHA.encode() + b'","state":{"raw_count":99},"records":['
        ranges = []
        for index, record in enumerate(records):
            if index:
                prefix += b"," 
            raw = encoded(record).rstrip(b"\n")
            start = len(prefix)
            prefix += raw
            ranges.append({"index": index, "begin_byte": start, "end_byte": len(prefix), "original_record_json_sha256": MODULE.sha(raw)})
        prefix += b',{"index":3,"incomplete":'
        self.ledger.with_name("original-prefix.bin").write_bytes(prefix)
        partial = {"schema": "hepta.fixed-cell-graph.partial-native-prefix.v2", "dispatch_sha256": MODULE.DISPATCH_SHA,
                   "records": records, "record_byte_ranges": ranges, "original_complete_record_count": len(records),
                   "full_ledger_sha256_verified": False, "full_run_cost_complete": False,
                   "no_repaired_or_synthesized_original_records": True, "prefix_bytes": len(prefix), "prefix_sha256": MODULE.sha(prefix),
                   "declared_full_ledger_sha256": "f" * 64}
        self.ledger.write_bytes(encoded(partial))
        self.args.expected_ledger_sha256 = MODULE.sha(self.ledger.read_bytes())

    def test_verified_partial_prefix_can_bind_three_sources_without_full_cost_claim(self):
        self.make_partial()
        result = MODULE.prepare(self.args)
        value = json.loads(Path(result["source_bundle"]).read_bytes())
        self.assertFalse(value["original_full_snapshot_verified"])
        self.assertFalse(value["original_full_run_cost_complete"])
        self.assertEqual(len(value["references"]), 3)
        self.assertIn("partial prefix", value["primary_raw_evidence_scope"])

    def test_partial_prefix_byte_change_rejected(self):
        self.make_partial()
        path = self.ledger.with_name("original-prefix.bin")
        data = path.read_bytes()
        path.write_bytes(data[:-1] + b" ")
        with self.assertRaisesRegex(ValueError, "prefix changed"):
            MODULE.prepare(self.args)

    def test_missing_complete_c_start_is_named_preparation_blocker(self):
        self.make_partial(keep=2)
        with self.assertRaisesRegex(ValueError, "b0-C-s0"):
            MODULE.prepare(self.args)


if __name__ == "__main__":
    unittest.main(verbosity=2)
