/* Actual local bash/Python transport of a >=196KiB synthetic case record.
 * No original data, Runtime tools, remote hosts or inference are used.
 */
const assert=require("node:assert/strict"),crypto=require("node:crypto"),fs=require("node:fs"),path=require("node:path"),vm=require("node:vm"),child=require("node:child_process");
const hash=data=>crypto.createHash("sha256").update(data).digest("hex");
const temp=fs.mkdtempSync(path.join(__dirname,"verification/journal-exec-"));
const journalRoot=path.join(temp,"journal"),writerPath=path.join(temp,"writer.py");
const realWriter=fs.readFileSync(path.join(__dirname,"write_recovery_journal_v2.py"),"utf8");
const rootPin='ROOT = Path("/workspace/scratch/b291d9fd3bc7/continued-session/graph-recovery-v2-journal")';
assert.equal(realWriter.split(rootPin).length-1,1);
fs.writeFileSync(writerPath,realWriter.replace(rootPin,"ROOT = Path("+JSON.stringify(journalRoot)+")"));
const helper=fs.readFileSync(path.join(__dirname,"../native-adapter/cell_graph_native_helpers.js"),"utf8");
const callback=fs.readFileSync(path.join(__dirname,"cell_graph_recovery_journal_v2.js"),"utf8");
const scriptPin="/workspace/scratch/b291d9fd3bc7/neuron-audit/graph-inference-benchmark/recovery-v2/write_recovery_journal_v2.py";
assert.equal(callback.split(scriptPin).length-1,1);
const context=vm.createContext({});
vm.runInContext(helper+"\n"+callback.replace(scriptPin,writerPath)+"\nglobalThis.create=createCellGraphRecoveryJournalV2;",context);
const commands=[];
const tools={exec_command:async args=>{
  commands.push(Buffer.byteLength(args.cmd));assert.ok(Buffer.byteLength(args.cmd)<=98304);
  try {return {output:child.execFileSync("/bin/bash",["-lc",args.cmd],{encoding:"utf8",maxBuffer:65536,stdio:["ignore","pipe","pipe"]}),exit_code:0};}
  catch(error){return {output:error.stderr?.toString()||"local process failed",exit_code:error.status??1};}
},write_stdin:async()=>{throw new Error("no yielded local process expected in this direct-exec test");}};
const journal=context.create({tools});
let passed=0;
(async()=>{
  const namespace=hash("synthetic-large-local-journal-test"),text=JSON.stringify({schema:"synthetic-only",record:{collection:{stdout_base64:Buffer.alloc(160000,65).toString("base64")}},note:"no original output"})+"\n";
  assert.ok(Buffer.byteLength(text)>=196608);
  const entry={namespace,file_name:"case-b0-A-s0-record.json",text,sha256:hash(text),bytes:Buffer.byteLength(text)};
  const ack=await journal(entry);assert.equal(ack.sha256,entry.sha256);assert.equal(fs.readFileSync(ack.file,"utf8"),text);assert.ok(ack.transport.length>=4);
  assert.ok(commands.length>=5);assert.ok(Math.max(...commands)<131072);passed++;console.log("PASS >=196KiB actual bash/Python case record staged and exclusively sealed with exact SHA");
  const before=fs.readFileSync(ack.file);await assert.rejects(()=>journal(entry),/not acknowledged/);assert.deepEqual(fs.readFileSync(ack.file),before);passed++;console.log("PASS repeated large publication rejected without overwriting original bytes");
  const small="{\"synthetic\":\"small intent\"}\n",count=commands.length;
  const smallAck=await journal({namespace,file_name:"raw-000000-intent.json",text:small,sha256:hash(small),bytes:Buffer.byteLength(small)});
  assert.equal(commands.length-count,1);assert.equal(fs.readFileSync(smallAck.file,"utf8"),small);passed++;console.log("PASS bounded small intent uses single real exclusive write");
  console.log(JSON.stringify({passed,case_record_bytes:entry.bytes,max_entire_bash_c_command_bytes:Math.max(...commands),local_executions:commands.length,native_runtime_calls:0,remote_calls:0,scope:"actual local shell/OS argument-bound regression on synthetic bytes"}));
})().catch(error=>{console.error(error);process.exitCode=1;});
