"""Read only the actual A/B/C custody archives; never extract or invoke a host."""

import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile


ROOT = Path(__file__).resolve().parents[4]
SOURCE = "366bc1fc39a93361f761fadbd22c60070ec0d3a8f63ab7f5e67b155ff61d9b6e"
PINS = {
    "A": "e5029a8ae54e5c8096d8b810cb208ea5289b8d0cfa044c44931682cf1e17f1ce",
    "B": "93ca89e25dcda67917c6c4893b166d40f74d77a99195e9ab7626c8eacd18ff51",
    "C": "169b45a7da7f7eff9e3d51158708e761a40a9dc55263b27be73a67332c34a52a",
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    session = ROOT / "continued-session"
    state_bytes = (session / "recovery_v2_after_C_state.json").read_bytes()
    state = json.loads(state_bytes)
    assert state["source_bundle_sha256"] == SOURCE
    assert state["raw_count"] == 25 and len(state["checkpoints"]) == 59
    union, archive_rows = {}, []
    for arm, wanted in PINS.items():
        path = session / "recovery-v2-custody" / f"case-{arm}.tar.gz"
        raw = path.read_bytes()
        assert sha(raw) == wanted
        with tarfile.open(path) as archive:
            members = archive.getmembers()
            assert len({member.name for member in members}) == len(members)
            contents = {}
            for member in members:
                name = PurePosixPath(member.name)
                assert member.isfile() and not name.is_absolute() and ".." not in name.parts
                assert 0 <= member.size <= 2_097_152
                data = archive.extractfile(member).read()
                assert len(data) == member.size
                contents[member.name] = data
            assert sum(map(len, contents.values())) <= 8_388_608
        manifest = json.loads(contents["MANIFEST.json"])
        assert manifest["source_sha256"] == SOURCE and manifest["case"] == f"b0-{arm}-s0"
        case_state_bytes = contents[f"after-{arm}-state.json"]
        assert sha(case_state_bytes) == manifest["after_case_state_sha256"]
        assert case_state_bytes == (session / f"recovery_v2_after_{arm}_state.json").read_bytes()
        listed = manifest["files"]
        assert len({item["path"] for item in listed}) == len(listed)
        assert set(contents) == {item["path"] for item in listed} | {"MANIFEST.json", f"after-{arm}-state.json"}
        for item in listed:
            name, data = item["path"], contents[item["path"]]
            assert len(data) == item["bytes"] and sha(data) == item["sha256"]
            assert name not in union, "actual journal deltas must not overwrite another case"
            union[name] = data
        ack_name = {"A": "recovery_v2_case_A_archive_ack.json", "B": "recovery_v2_case_B_chunked_commit_ack.json", "C": "recovery_v2_case_C_commit_ack.json"}[arm]
        ack_bytes = (session / ack_name).read_bytes()
        ack = json.loads(ack_bytes)
        envelope = ack.get("result", ack)
        assert envelope["isError"] is False and len(envelope["content"]) == 1
        result = json.loads(envelope["content"][0]["text"])
        assert result["sha256"] == wanted and result["size"] == len(raw)
        assert result.get("written") == len(raw) if arm == "A" else result["committed"] is True
        archive_rows.append({"case": arm, "archive_bytes": len(raw), "archive_sha256": wanted,
                             "journal_delta_files": len(listed), "archive_members": len(contents),
                             "actual_remote_write_ack_sha256": sha(ack_bytes)})
    for checkpoint in state["checkpoints"]:
        data = union[checkpoint["file_name"]]
        assert len(data) == checkpoint["bytes"] and sha(data) == checkpoint["sha256"]
    expected_raw = {f"raw-{index:06d}-{kind}.json" for index in range(25) for kind in ("intent", "returned")}
    assert {name for name in union if name.startswith("raw-")} == expected_raw
    result = {"schema": "hepta.fixed-cell-graph.actual-recovery-archive-union-audit.v1",
              "source_bundle_sha256": SOURCE, "final_state_sha256": sha(state_bytes),
              "all_three_archive_bytes_manifests_and_actual_write_acks_match": True,
              "all_59_final_checkpoint_files_present_and_exact": True,
              "all_25_native_intent_result_pairs_present": True,
              "union_journal_files_including_staged_chunks": len(union), "archives": archive_rows,
              "original_full_ledger_recovered": False, "whole_original_cost_complete": False,
              "no_extraction_no_new_native_or_model_calls": True}
    output = Path(__file__).with_name("actual-recovery-archive-custody.json")
    with output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"qualified": True, "checkpoint_files": 59, "native_call_pairs": 25,
                      "output_sha256": sha(output.read_bytes())}))


if __name__ == "__main__":
    main()
