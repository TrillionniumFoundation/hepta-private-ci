"""Focused arithmetic/partial-scope tests; no real models or host calls."""

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

SPEC = importlib.util.spec_from_file_location("partial_v2", Path(__file__).with_name("audit_cell_graph_partial_v2.py"))
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class PartialAudit(unittest.TestCase):
    def test_exact_and_predeclared_tolerance_are_separate(self):
        reference = np.tile(np.array([0.1, 0.2, 0.3, 0.4]), (6, 480, 1))
        self.assertTrue(MODULE.independent_parity(reference, reference.copy())["bitwise_equal"])
        candidate = reference.copy()
        candidate[0, 0, 0] += 1e-14
        result = MODULE.independent_parity(reference, candidate)
        self.assertFalse(result["bitwise_equal"])
        self.assertTrue(result["within_predeclared_tolerance"])
        self.assertTrue(result["all_head_argmax_equal"])

    def test_tiny_tie_change_cannot_hide_decision_difference(self):
        reference = np.full((6, 480, 4), 0.25)
        candidate = reference.copy()
        candidate[:, 0, 0] -= 1e-13
        candidate[:, 0, 1] += 1e-13
        result = MODULE.independent_parity(reference, candidate)
        self.assertTrue(result["within_predeclared_tolerance"])
        self.assertFalse(result["all_head_argmax_equal"])
        self.assertFalse(result["mean_argmax_equal"])

    def test_nonfinite_or_wrong_shape_rejected(self):
        reference = np.full((6, 480, 4), 0.25)
        candidate = reference.copy()
        candidate[0, 0, 0] = np.nan
        with self.assertRaisesRegex(ValueError, "finite"):
            MODULE.independent_parity(reference, candidate)
        with self.assertRaisesRegex(ValueError, "shape/dtype"):
            MODULE.independent_parity(reference, reference[:, :479])

    def test_all_six_pairs_and_incomplete_census_rejection(self):
        rows = [{"block": block, "arm": arm, "status": "completed", "critical_path_ms": block * 100 + offset}
                for block in range(6) for arm, offset in (("A", 1000), ("B", 900), ("C", 950))]
        result = MODULE.paired_contrasts(rows)
        self.assertEqual(result["C_minus_B"]["all_six_ms"], [50] * 6)
        self.assertEqual(result["C_minus_B"]["mean_ms"], 50)
        self.assertEqual(result["C_minus_A"]["median_ms"], -50)
        with self.assertRaisesRegex(ValueError, "all18"):
            MODULE.paired_contrasts(rows[:-1])
        rows[0]["status"] = "failed"
        with self.assertRaisesRegex(ValueError, "all18"):
            MODULE.paired_contrasts(rows)

    def prefix(self):
        arguments = '{"job_id":"synthetic"}'
        result = '{"synthetic":"opaque receipt"}'
        record = {"index": 0, "lane": "primary", "operation": "process_start", "request_id": "fixture-only",
                  "arguments_json": arguments, "arguments_sha256": MODULE.sha(arguments.encode()),
                  "result_json": result, "native_receipt_sha256": MODULE.sha(result.encode())}
        raw = json.dumps(record).encode()
        prefix = b'{"records":[' + raw + b',{"unfinished":'
        start, end = len(b'{"records":['), len(b'{"records":[') + len(raw)
        document = {"schema": "hepta.fixed-cell-graph.partial-native-prefix.v2", "dispatch_sha256": MODULE.DISPATCH,
            "full_ledger_sha256_verified": False, "full_run_cost_complete": False, "prefix_sha256": MODULE.sha(prefix),
            "prefix_bytes": len(prefix), "records": [record], "original_complete_record_count": 1,
            "record_byte_ranges": [{"index": 0, "begin_byte": start, "end_byte": end, "original_record_json_sha256": MODULE.sha(raw)}],
            "header": {"state": {"raw_count": 3}}, "present_prefix_chunk_count": 1, "declared_full_chunk_count": 4,
            "declared_full_ledger_bytes": len(prefix) * 4, "declared_full_ledger_sha256": "f" * 64}
        return document, prefix

    def test_complete_prefix_proof_never_means_complete_ledger_or_cost(self):
        document, prefix = self.prefix()
        result = MODULE.prefix_check(document, prefix)
        self.assertEqual(result["retained_complete_records"], 1)
        self.assertEqual(result["declared_snapshot_records"], 3)
        self.assertFalse(result["full_ledger_sha256_verified"])
        self.assertFalse(result["whole_run_cost_complete"])
        document["full_ledger_sha256_verified"] = True
        with self.assertRaisesRegex(ValueError, "explicit original partial"):
            MODULE.prefix_check(document, prefix)

    def test_prefix_alteration_and_false_complete_count_rejected(self):
        document, prefix = self.prefix()
        with self.assertRaisesRegex(ValueError, "prefix bytes changed"):
            MODULE.prefix_check(document, prefix[:-1] + b" ")
        document["header"]["state"]["raw_count"] = 1
        with self.assertRaisesRegex(ValueError, "masquerade"):
            MODULE.prefix_check(document, prefix)

    def recovery_fixture(self, root):
        folder = root / "recovery"
        folder.mkdir()
        value = {"schema": "hepta.fixed-cell-graph.recovery.v1", "request_id": "b0-A-s0", "dispatch_sha256": MODULE.DISPATCH,
                 "status": "failed", "failure": {"message": "native start receipt does not bind original request/launch"}}
        data = (json.dumps(value) + "\n").encode()
        (folder / "b0-A-s0.json").write_bytes(data)
        original_pin = MODULE.ORIGINAL_FAILURE_SHA
        self.addCleanup(setattr, MODULE, "ORIGINAL_FAILURE_SHA", original_pin)
        MODULE.ORIGINAL_FAILURE_SHA = MODULE.sha(data)
        return folder, value

    def test_original_A_cannot_be_rewritten_completed_and_called_unchanged(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            folder, value = self.recovery_fixture(root)
            original = MODULE.original_recovery_census(root)
            self.assertTrue(original["passed"])
            self.assertEqual([row["classification"] for row in original["rows"]], ["failed", "absent/unattempted", "absent/unattempted"])
            value["status"] = "completed"
            (folder / "b0-A-s0.json").write_text(json.dumps(value))
            changed = MODULE.original_recovery_census(root)
            self.assertFalse(changed["passed"])
            self.assertEqual(changed["rows"][0]["classification"], "completed")

    def test_new_B_or_C_file_is_recovery_integrity_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            folder, _ = self.recovery_fixture(root)
            (folder / "b0-B-s0.json").write_text('{"status":"completed"}')
            value = MODULE.original_recovery_census(root)
            self.assertFalse(value["passed"])
            self.assertIn("b0-B-s0", value["errors"][0]["request_id"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
