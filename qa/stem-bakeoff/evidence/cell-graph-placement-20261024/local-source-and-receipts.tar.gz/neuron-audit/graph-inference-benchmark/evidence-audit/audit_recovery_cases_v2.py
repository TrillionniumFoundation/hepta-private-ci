"""Read-only independent byte/identity audit of the separate actual v2 journal.

No Runtime/model calls. Does not rewrite original recovery classifications.
Requires the final captured state and source bundle to be supplied explicitly.
"""

import argparse
import base64
import hashlib
import json
from pathlib import Path
import re


ORDER = ["b0-A-s0", "b0-B-s0", "b0-C-s0"]
PROTOCOL = "7e73a090d4942afc88aa188b8735388e7585ca54a987c79fc1d1b9b69ee66e50"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path, manifest, maximum=2_097_152):
    require(not path.is_symlink() and path.is_file() and path.stat().st_size <= maximum, "bounded regular journal file required: " + str(path))
    data = path.read_bytes()
    manifest[str(path)] = {"bytes": len(data), "sha256": sha(data)}
    return data, json.loads(data)


def mcp(raw):
    require(sha(raw["arguments_json"].encode()) == raw["arguments_sha256"]
            and sha(raw["result_json"].encode()) == raw["native_receipt_sha256"], "exact native argument/response hashes differ")
    outer = json.loads(raw["result_json"])
    require(outer["isError"] is False and len(outer["content"]) == 1 and outer["content"][0]["type"] == "text", "one original exact native text receipt required")
    value = json.loads(outer["content"][0]["text"])
    require(value["audit_recorded"] is True, "authoritative native audit acknowledgement required")
    return json.loads(raw["arguments_json"]), value


def terminal(value, original):
    require(value["job_id"] == original["job_id"] and value["state"] == "succeeded" and value["exit_code"] == 0
            and value["timed_out"] is False and value["cancelled"] is False and value["output_complete"] is True,
            "same successful complete original job required")
    for stream in ("stdout", "stderr"):
        require(value["log_bytes"][stream]["seen"] == value["log_bytes"][stream]["stored"] == original[stream + "_bytes"]
                and value["log_errors"][stream] is None and value["log_truncated"][stream] is False,
                "complete original bounded log sizes required")


def completed_case(case, source, records):
    request, original = source["request"], source["original"]
    collection, events = case["collection"], case["api_events"]
    require(case["status"] == "completed" and case["request_id"] == request["request_id"]
            and 0 <= case["completed_ms"] - case["started_ms"] <= 60000 and 2 <= len(events) <= 24,
            "original bounded successful recovery owner required")
    calls = [record for record in records if record["request_id"] == request["request_id"]]
    require(len(calls) == len(events) and sum(record["operation"] == "process_start" for record in calls) == 1
            and calls[0]["operation"] == "process_start", "exactly one original lookup and complete event census required")
    previous = case["started_ms"]
    positions = {"stdout": 0, "stderr": 0}
    output = {"stdout": bytearray(), "stderr": bytearray()}
    seen_terminal, status_count, pages = False, 0, 0
    for record, event in zip(calls, events, strict=True):
        require(record["status"] == "returned" and record["native_call_attempted"] is True and event["status"] == "completed"
                and event["operation"] == record["operation"] and event["request_id"] == request["request_id"]
                and event["native_receipt_sha256"] == record["native_receipt_sha256"]
                and previous <= event["started_ms"] <= record["started_ms"] <= record["native_await_started_ms"]
                <= record["native_await_finished_ms"] <= event["finished_ms"] <= case["completed_ms"],
                "complete original-call timing/provenance event differs")
        previous = event["finished_ms"]
        args, value = mcp(record)
        require(args["host"] == request["host"], "native host changed")
        if record["operation"] == "process_start":
            require(record["arguments_json"] == source["original_start"]["arguments_json"]
                    and record["arguments_sha256"] == source["original_start"]["arguments_sha256"], "original launch bytes changed")
            job = value["job"]
            require(value["reused"] is True and value["launch"] is None and value["retried_launch"] is False
                    and job["id"] == original["job_id"] and job["host"] == request["host"]
                    and job["request_digest"] == original["native_request_digest"]
                    and str(job["request_fingerprint"]) == original["native_request_fingerprint"]
                    and job["idempotency_key"] == request["idempotency_key"], "same original reused job/digest/fingerprint/key required")
            terminal(value["status"], original)
        elif record["operation"] == "process_status":
            require(args["job_id"] == original["job_id"], "status target changed")
            terminal(value, original)
            seen_terminal = True
            status_count += 1
        elif record["operation"] == "process_read":
            require(seen_terminal and args["job_id"] == value["job_id"] == original["job_id"] and args["limit"] == 16384,
                    "original terminal job and16KiB read cap required")
            pages += 1
            for stream in ("stdout", "stderr"):
                item = value[stream]
                require(re.fullmatch(r"(?:[0-9a-f]{2})*", item["bytes_hex"]) is not None, "exact lowercase byte hex required")
                chunk = bytes.fromhex(item["bytes_hex"])
                require(args[stream + "_offset"] == item["offset"] == positions[stream]
                        and item["next_offset"] == positions[stream] + len(chunk) and len(chunk) <= 16384
                        and item["size"] == original[stream + "_bytes"]
                        and item["eof"] is (item["next_offset"] == item["size"]), "complete contiguous original byte ranges required")
                output[stream].extend(chunk)
                positions[stream] += len(chunk)
        else:
            raise ValueError("unexpected original owner operation")
    require(calls[-1]["operation"] == "process_status" and status_count >= 2 and 1 <= pages <= 12, "final authoritative status and bounded full pages required")
    for stream in ("stdout", "stderr"):
        original_bytes = base64.b64decode(original[stream + "_base64"], validate=True)
        repeated = base64.b64decode(collection[stream + "_base64"], validate=True)
        require(bytes(output[stream]) == original_bytes == repeated and len(original_bytes) == original[stream + "_bytes"]
                and sha(original_bytes) == original[stream + "_sha256"] == collection[stream + "_sha256"], "entire old output must be byte-identical")
    require(collection["job_id"] == original["job_id"] and collection["start_disposition"] == "reused"
            and collection["exit_code"] == 0 and collection["status"] == "completed"
            and collection["stdout_complete"] is True and collection["truncated"] is False
            and collection["repeated_start_arguments_sha256"] == source["original_start"]["arguments_sha256"], "original successful collection binding required")
    return {"request_id": request["request_id"], "status": "completed", "job_id": original["job_id"],
            "host": request["host"], "owner_wall_ms": case["completed_ms"] - case["started_ms"],
            "native_calls": len(calls), "read_pages": pages, "stdout_bytes": len(output["stdout"]),
            "stdout_sha256": sha(output["stdout"]), "stderr_exact": True, "original_job_reused_without_fresh_launch": True,
            "old_worker_cpu_charged_again": False, "native_service_cpu_ns": None, "native_service_peak_rss_bytes": None}


def audit(args):
    manifest = {}
    source_bytes, source = read(args.source_bundle, manifest)
    _, state = read(args.state, manifest)
    require(sha(source_bytes) == state["source_bundle_sha256"] and source["validation_protocol_sha256"] == state["validation_protocol_sha256"] == PROTOCOL,
            "actual separately frozen source/protocol namespace required")
    require(args.journal.name == state["source_bundle_sha256"], "original exclusive journal namespace required")
    records, issues, rows = [], [], []
    for index in range(state["raw_count"]):
        try:
            _, intent = read(args.journal / f"raw-{index:06d}-intent.json", manifest)
            _, returned = read(args.journal / f"raw-{index:06d}-returned.json", manifest)
            require(intent["index"] == returned["index"] == index and intent["status"] == "pending"
                    and intent["arguments_json"] == returned["arguments_json"] and intent["native_call_attempted"] is False,
                    "exclusive original pre-call intent differs")
            mcp(returned)
            records.append(returned)
        except (OSError, ValueError, KeyError, TypeError) as error:
            issues.append({"scope": "raw_call", "index": index, "error": str(error)})
    for checkpoint in state["checkpoints"]:
        try:
            name = checkpoint["file_name"]
            require(Path(name).name == name, "checkpoint path must remain in the new journal")
            data, _ = read(args.journal / name, manifest)
            require(len(data) == checkpoint["bytes"] and sha(data) == checkpoint["sha256"]
                    and checkpoint["receipt"]["publication"] == "created", "file checkpoint exact SHA/created receipt differs")
        except (OSError, ValueError, KeyError, TypeError) as error:
            issues.append({"scope": "file_checkpoint", "name": checkpoint.get("file_name"), "error": str(error)})
    for index, request_id in enumerate(ORDER):
        if index >= state["next_case"]:
            rows.append({"request_id": request_id, "status": "not completed in supplied state capture"})
            continue
        try:
            _, checkpoint = read(args.journal / f"case-{request_id}-record.json", manifest)
            require(checkpoint["source_bundle_sha256"] == state["source_bundle_sha256"] and checkpoint["validation_protocol_sha256"] == PROTOCOL,
                    "case source/protocol changed")
            case = checkpoint["record"]
            if case["status"] != "completed":
                rows.append({"request_id": request_id, "status": case["status"], "failure": case.get("failure")})
                continue
            ref = next(item for item in source["references"] if item["request"]["request_id"] == request_id)
            row = completed_case(case, ref, records)
            _, outer = read(args.journal / f"case-{request_id}-outer.json", manifest)
            row["outer_wall_ms_before_final_outer_file_ack"] = outer["outer"]["elapsed_ms"]
            rows.append(row)
        except (OSError, ValueError, KeyError, TypeError) as error:
            rows.append({"request_id": request_id, "status": "audit failed", "error": str(error)})
    qualified = not issues and state["next_case"] == 3 and state["active"] is None and state["outstanding"] is None
    qualified = qualified and not state.get("journal_failure") and all(row["status"] == "completed" for row in rows)
    result = {"schema": "hepta.fixed-cell-graph.recovery-v2-actual-independent-audit.v1", "validation_protocol_sha256": PROTOCOL,
              "source_bundle_sha256": sha(source_bytes), "all_three_original_job_byte_reuses_qualified": qualified,
              "cases": rows, "issues": issues, "native_call_count": state["raw_count"], "file_checkpoint_count": len(state["checkpoints"]),
              "original_recovery_census_unchanged": source["original_recovery_census"],
              "original_full_ledger_recovered": False, "original_whole_run_cost_complete": False,
              "scope": "Independent actual original-job/MCP/page/file byte proof only. No recomputation, new graph, crash/power-loss, speed or intelligence claim.",
              "archive_publication_and_final_ack_cost_excluded": True, "input_files": manifest}
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return {"qualified": qualified, "cases": rows, "issues": issues, "output_sha256": sha(args.output.read_bytes())}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("source-bundle", "state", "journal", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    print(json.dumps(audit(parser.parse_args()), indent=2))
