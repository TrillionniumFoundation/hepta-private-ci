# Fixed six-head graph: actual placement results and incomplete controller evidence

## Outcome

The original unchanged reporter accepts numerical parity for all 18 scheduled
graphs and 30 workers. A and B reproduce the block-0 A probabilities bit for
bit. C's largest absolute difference is `3.3306690738754696e-16`, below the
predeclared `atol=rtol=1e-12`. Every per-head and final-mean decision label is
identical. The logical computation therefore survived these actual placements.

The primary paired comparison does **not** show a multi-host latency benefit
on this execution path. C minus B is slower in four of six blocks; its mean
difference is **+1,225 ms** and median paired difference **+3,500.5 ms**. Six
blocks are descriptive evidence. There is no population confidence interval,
tail-latency claim, or whole-system net-benefit estimate.

The result is for the six original warmup heads and 480 fixed projected inputs.
No heads were selected using later task outcomes. The graph is a shared input,
six unchanged heads, and a fixed equal-weight mean. It is not a learned-edge,
cell-split, migration-learning, agent-task, or general-intelligence experiment.

## Frozen placements and all paired measurements

| Arm | Actual placement | Own configured ceilings | Graph wall median |
| --- | --- | --- | ---: |
| A | One main process, all six heads | 200% CPU; 2 GiB | 55,669 ms |
| B | Two concurrent main processes, fixed three-head shards | Each 100% CPU; 1 GiB | 51,598.5 ms |
| C | Same two shards concurrently on main and pocket4, with frozen host/shard rotation | Each 100% CPU; 1 GiB | 51,216 ms |

All NumPy thread counts were one. The sum of the configured local CPU ceilings
was equal. These are ceilings, not reserved or equal effective CPU capacity.
The hosts have different physical hardware and Python/NumPy/BLAS environments;
ancestor limits, scheduling and background contention are not isolated by this
design. The C−B comparison is not a pure measurement of physical network delay.

| Block | C−B ms (primary) | C−A ms | B−A ms |
| --- | ---: | ---: | ---: |
| 0 | +22,370 | +16,561 | −5,809 |
| 1 | +3,229 | −9,230 | −12,459 |
| 2 | +3,772 | −7,181 | −10,953 |
| 3 | −2,988 | −967 | +2,021 |
| 4 | −24,177 | −18,062 | +6,115 |
| 5 | +5,144 | +2,382 | −2,762 |
| Mean | **+1,225** | −2,749.5 | −3,974.5 |
| Median paired difference | **+3,500.5** | −4,074 | −4,285.5 |

Negative differences mean the candidate was faster. Separate arm medians are
not substitutes for the predeclared within-block comparison. All six paired
values remain; the unusually positive and negative blocks are not discarded.

## The measured operation includes the controller/API path

The pure head computation is much smaller than the enclosing graph interval.
For A, six-head inference takes 1.70–2.12 ms per worker, with a median of
1.98 ms. The worker's measured process interval before its final trailer is
128–390 ms. In contrast, A's enclosing owner interval is 48.3–67.2 seconds;
its worker collection path is 28.6–39.1 seconds and its reducer-service path
18.0–28.5 seconds. These intervals include the cold process dispatch, repeated
original Runtime API observations/read pages, controller-side encoding and
validation, and a separately dispatched reducer.

This is the latency of that actual cold control/API path. It is not the latency
of a persistent cell service or the mathematical matrix operations alone. The
worker/reducer phases are nested inside the owner interval and must not be
added to it. Worker and wrapper CPU measurements also have distinct boundaries;
wrapper child CPU overlaps reducer CPU. Process RSS high-water marks cannot be
summed into simultaneous or unique physical RAM. Native-service and external
JavaScript-owner CPU/RSS remain unmeasured.

The source report retains the actual CPU/RSS values and exclusions. Missing
post-owner or service costs are unknown, not zero. This experiment supports no
comparison between a native agent and Codex as task-solving systems.

## Original recovery failure and subsequent separate correction

The original first recovery, `b0-A-s0`, failed in the adapter parser. Its actual
Runtime response was `reused:true`, `launch:null`, `retried_launch:false`, with
the same original job/digest/fingerprint and completed cached status. The
adapter incorrectly required a fresh `launch.ok` acknowledgement even for reuse,
then retained an unresolved pending entry. The original `b0-B-s0` and
`b0-C-s0` recoveries were not attempted. These three original classifications
remain **failed, absent/unattempted, absent/unattempted**.

The independent recovery-v2 package changes only this receipt interpretation
and its separate validation/persistence boundary. It imports original job and
output identities, uses the unchanged recovery owner and original call/time
bounds, and writes exclusive checkpoints before and after every actual call.
Its results belong to a new evidence namespace. Any later v2 pass must be
reported alongside the original failure and missing cases; it does not revise
them. At this draft's preparation, no v2 result is asserted. Final publication
must append the actual v2 census and its receipt hashes without replacing this
original history.

This is completed-job idempotency lookup/read validation. It is not a crash,
machine-loss, power-loss, migration, or long-term graph-recovery test.

## What survived the controller-store loss

The 18 original owner files, all original graph collections/reductions, and
the failed first recovery were written before the controller session was lost.
Only four of the 34 raw-ledger chunks were persisted: 2,097,152 bytes out of the
declared 17,781,056. Forty-five complete original JSON call records were
recovered from this prefix; the snapshot declared 383 records. The extraction
checks original chunk receipts, byte ranges and internal request/response SHA
values, stops at the first incomplete object, and never synthesizes the suffix.

The full-ledger SHA is not verified. Original missing raw-call suffixes,
post-owner/helper/outer spans and later sealing-call evidence are unavailable.
Thus the original numerical graph result and its recorded enclosing intervals
can be checked from the persisted graph artifacts, while a full original
native-call and total-cost audit remains unavailable. A passing prefix-integrity
check must not be described as a passing full-ledger audit.

The original full-evidence auditor remains unchanged. The new
`audit_cell_graph_partial_v2.py` uses an explicit partial mode: it reruns the
pinned original reporter; independently reconstructs each six-head stack and
equal-weight mean from retained worker stdout; checks the archived tensors,
hashes, frozen tolerance and decision labels; and recomputes the six paired
contrasts. It separately validates the retained prefix and always labels the
original full-native/whole-cost audit unavailable. Its actual run result must
be included with publication; source/unit tests alone are not that result.

## Immutable evidence identifiers

| Evidence | SHA256 |
| --- | --- |
| Original frozen dispatch | `595d40d93a9ba394c21c39fd41c5c8b60ab5ceddfcdb8bdd9f5102ce193fa4ae` |
| Original unchanged reporter result (85,620 bytes) | `6df19c646c3b610011b138a3f0cc870bc4523d23d5ae1bc2b52f78778dc39102` |
| Original failed-recovery capture | `36c3d163aa25c8c3182eaedc19e356399b3aea5308a4d2b73eff9210744a61cd` |
| Actual retained prefix bytes | `c0e41a7adf1c83943f61e146d49b43ff70ffb57800b82cb45f906275a1cfbcfc` |
| Complete-prefix extraction document | `bc9d9bf887c5f68fd34815f3ef7e71403bd888c06ff622f4c8c117f63d5cd913` |
| Separately frozen recovery-v2 protocol | `7e73a090d4942afc88aa188b8735388e7585ca54a987c79fc1d1b9b69ee66e50` |

The manifest's declared full-ledger SHA
`a8cd6fc298c63d525e8794c00d6e738800898c968b30b8ad52e589ad87807589`
is an unverified whole-file claim because 30 original chunks are missing.
It must not be listed as a successfully verified artifact.
