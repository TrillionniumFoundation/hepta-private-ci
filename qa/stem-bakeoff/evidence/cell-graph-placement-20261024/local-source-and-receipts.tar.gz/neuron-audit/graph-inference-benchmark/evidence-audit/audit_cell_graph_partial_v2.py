"""Explicit partial-evidence audit of the original fixed18-graph experiment.

The original reporter and reducer stay unchanged. This reruns the pinned
reporter, independently stacks/averages retained worker outputs, recomputes all
six paired contrasts, and verifies the retained raw-prefix byte ranges. It
never certifies the missing original ledger or whole-run costs.
"""

import argparse
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import statistics
import subprocess
import sys

import numpy as np


PINS = {"cell_graph_report.py": "7a5b7dfaccda71143e0de6b1087d2744bc5ee16e14d0e146f06b77734621544d",
        "cell_graph_reduce.py": "5ac4bba925d161f8fe3eda5c5c036207d7182ec84733f6c1f310befa0da54efb",
        "cell_graph_worker.py": "bb9a6ddc30cc267d22a530e9486e6590cdef15247d1546905b4a051e8eed8358"}
DISPATCH = "595d40d93a9ba394c21c39fd41c5c8b60ab5ceddfcdb8bdd9f5102ce193fa4ae"
REPORT = "6df19c646c3b610011b138a3f0cc870bc4523d23d5ae1bc2b52f78778dc39102"
PREFIX_DOCUMENT = "bc9d9bf887c5f68fd34815f3ef7e71403bd888c06ff622f4c8c117f63d5cd913"
ORIGINAL_FAILURE_SHA = "758f4ffa3dbeede3a6cf9bb59694b56a8382c845d71d6e5b3733ff217b536c32"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path, maximum=1_048_576):
    require(not path.is_symlink() and path.is_file() and path.stat().st_size <= maximum, "bounded regular evidence file required: " + str(path))
    data = path.read_bytes()
    return data, json.loads(data)


def independent_parity(reference, candidate):
    require(reference.shape == candidate.shape == (6, 480, 4) and reference.dtype == candidate.dtype == np.dtype("float64"), "exact six-head tensor shape/dtype required")
    require(np.isfinite(reference).all() and np.isfinite(candidate).all(), "finite probability tensors required")
    difference = np.abs(reference - candidate)
    return {"bitwise_equal": bool(np.array_equal(reference, candidate)), "max_absolute_error": float(difference.max()),
            "within_predeclared_tolerance": bool(np.all(difference <= 1e-12 + 1e-12 * np.abs(candidate))),
            "all_head_argmax_equal": bool(np.array_equal(reference.argmax(axis=2), candidate.argmax(axis=2))),
            "mean_argmax_equal": bool(np.array_equal(reference.mean(axis=0).argmax(axis=1), candidate.mean(axis=0).argmax(axis=1)))}


def paired_contrasts(rows):
    require(len(rows) == 18 and all(row["status"] == "completed" for row in rows), "all18 completed rows required; no selected successful subset")
    lookup = {(row["block"], row["arm"]): row["critical_path_ms"] for row in rows}
    require(set(lookup) == {(block, arm) for block in range(6) for arm in "ABC"}, "complete unique six-block census required")
    result = {}
    for candidate, baseline in (("C", "B"), ("C", "A"), ("B", "A")):
        values = [lookup[(block, candidate)] - lookup[(block, baseline)] for block in range(6)]
        result[candidate + "_minus_" + baseline] = {"all_six_ms": values, "mean_ms": statistics.mean(values),
            "median_ms": statistics.median(values), "candidate_slower_blocks": sum(value > 0 for value in values),
            "candidate_faster_blocks": sum(value < 0 for value in values)}
    return result


def prefix_check(document, prefix_bytes):
    require(document["schema"] == "hepta.fixed-cell-graph.partial-native-prefix.v2"
            and document["full_ledger_sha256_verified"] is False and document["full_run_cost_complete"] is False
            and document["dispatch_sha256"] == DISPATCH, "explicit original partial-prefix scope required")
    require(sha(prefix_bytes) == document["prefix_sha256"] and len(prefix_bytes) == document["prefix_bytes"], "retained original prefix bytes changed")
    records = document["records"]
    require([row["index"] for row in records] == list(range(len(records)))
            and len(records) == document["original_complete_record_count"]
            and len(document["record_byte_ranges"]) == len(records), "contiguous complete original prefix only")
    previous_end = 0
    for record, interval in zip(records, document["record_byte_ranges"], strict=True):
        require(interval["index"] == record["index"] and previous_end <= interval["begin_byte"] < interval["end_byte"] <= len(prefix_bytes), "original byte ranges changed")
        raw = prefix_bytes[interval["begin_byte"]:interval["end_byte"]]
        require(sha(raw) == interval["original_record_json_sha256"] and json.loads(raw) == record, "exact original prefix object differs")
        require(sha(record["arguments_json"].encode()) == record["arguments_sha256"], "raw argument bytes changed")
        if "result_json" in record:
            require(sha(record["result_json"].encode()) == record["native_receipt_sha256"], "raw native response bytes changed")
        previous_end = interval["end_byte"]
    declared = document["header"]["state"]["raw_count"]
    require(len(records) < declared, "partial scope must not masquerade as full snapshot completion")
    starts = [row["request_id"] for row in records if row["lane"] == "primary" and row["operation"] == "process_start"]
    return {"retained_complete_records": len(records), "declared_snapshot_records": declared,
            "present_chunks": document["present_prefix_chunk_count"], "declared_chunks": document["declared_full_chunk_count"],
            "present_prefix_bytes": len(prefix_bytes), "declared_ledger_bytes": document["declared_full_ledger_bytes"],
            "retained_original_primary_start_ids": starts, "prefix_sha256": sha(prefix_bytes),
            "declared_full_ledger_sha256": document["declared_full_ledger_sha256"], "full_ledger_sha256_verified": False,
            "full_original_native_audit_status": "unavailable: missing original raw suffix and later sealing calls",
            "whole_run_cost_complete": False}


def load_decoder(source_dir):
    for name, expected in PINS.items():
        path = source_dir / name
        require(not path.is_symlink() and sha(path.read_bytes()) == expected, "frozen original source changed: " + name)
    sys.path.insert(0, str(source_dir))
    specification = importlib.util.spec_from_file_location("original_cell_graph_reduce_partial_audit", source_dir / "cell_graph_reduce.py")
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module.read_worker


def original_recovery_census(graph_evidence):
    """Exact old failure bytes and continued B/C absence, independent of math."""
    rows, errors = [], []
    for arm in "ABC":
        request_id = f"b0-{arm}-s0"
        path = graph_evidence / "recovery" / (request_id + ".json")
        row = {"request_id": request_id}
        try:
            if arm == "A":
                raw, value = read(path)
                row.update(classification=value.get("status"), sha256=sha(raw), failure=value.get("failure"))
                require(sha(raw) == ORIGINAL_FAILURE_SHA and value.get("schema") == "hepta.fixed-cell-graph.recovery.v1"
                        and value.get("request_id") == request_id and value.get("dispatch_sha256") == DISPATCH
                        and value.get("status") == "failed"
                        and value.get("failure", {}).get("message") == "native start receipt does not bind original request/launch",
                        "exact originally retained A failure bytes/classification changed")
            elif path.exists():
                raw, value = read(path)
                row.update(classification=value.get("status"), sha256=sha(raw))
                raise ValueError("original unattempted " + request_id + " file must remain absent; v2 belongs elsewhere")
            else:
                row["classification"] = "absent/unattempted"
            row["original_integrity_pass"] = True
        except (OSError, ValueError, KeyError, TypeError) as error:
            row.update(original_integrity_pass=False, integrity_failure=str(error))
            errors.append({"request_id": request_id, "error": str(error)})
        rows.append(row)
    return {"passed": not errors, "expected_original_A_sha256": ORIGINAL_FAILURE_SHA, "rows": rows, "errors": errors}


def audit(args):
    args.output.mkdir(parents=False, exist_ok=False)
    inputs, issues, rows = [], [], []
    dispatch_bytes, dispatch = read(args.dispatch)
    report_bytes, report = read(args.report)
    require(sha(dispatch_bytes) == DISPATCH and sha(report_bytes) == REPORT, "pinned actual dispatch/report required")
    for path, data in ((args.dispatch, dispatch_bytes), (args.report, report_bytes)):
        inputs.append({"file": str(path), "bytes": len(data), "sha256": sha(data)})
    decode_worker = load_decoder(args.source_dir)
    rerun = args.output / "original-reporter-rerun.json"
    command = [sys.executable, str(args.source_dir / "cell_graph_report.py"), "--dispatch", str(args.dispatch),
               "--evidence", str(args.graph_evidence), "--output", str(rerun), "--expected-dispatch-sha256", DISPATCH]
    rerun_exact, rerun_primary_equal = False, False
    try:
        completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60, check=False)
        (args.output / "reporter-stdout.bin").write_bytes(completed.stdout)
        (args.output / "reporter-stderr.bin").write_bytes(completed.stderr)
        if completed.returncode == 0 and rerun.is_file():
            rerun_bytes, rerun_value = read(rerun)
            rerun_exact = rerun_bytes == report_bytes
            rerun_primary_equal = all(rerun_value.get(key) == report.get(key) for key in
                ("rows", "completed_comparable_graphs", "failed_or_noncomparable", "arm_wall_ms", "paired_descriptive_wall"))
        else:
            issues.append({"scope": "unchanged_reporter_execution", "returncode": completed.returncode})
    except subprocess.TimeoutExpired as error:
        (args.output / "reporter-stdout.bin").write_bytes(error.stdout or b"")
        (args.output / "reporter-stderr.bin").write_bytes(error.stderr or b"")
        issues.append({"scope": "unchanged_reporter_execution", "failure": "bounded60s audit timeout; partial logs preserved"})
    if not rerun_primary_equal:
        issues.append({"scope": "unchanged_reporter_primary_census", "failure": "complete primary rows/costs do not reproduce"})
    reference = None
    original_nodes = 0
    for graph, reported in zip(dispatch["graphs"], report["rows"], strict=True):
        graph_id = graph["graph_id"]
        row = {"graph_id": graph_id, "arm": graph["arm"], "block": graph["block"], "status": "failed"}
        try:
            require(reported["graph_id"] == graph_id, "full original graph order changed")
            folder = args.graph_evidence / graph_id
            owner_bytes, owner = read(folder / "owner.json")
            receipt_bytes, receipt = read(folder / "reduction" / "receipt.json")
            collection_bytes, collection = read(folder / "collection.json")
            require(sha(owner_bytes) == reported["owner_sha256"] and sha(receipt_bytes) == reported["reduction_sha256"]
                    and receipt["collection_sha256"] == sha(collection_bytes)
                    and owner["reduction"]["receipt_sha256"] == sha(receipt_bytes), "original report/owner/collection/reduction SHA binding differs")
            require(owner["status"] == receipt["status"] == reported["status"] == "completed", "original failed row cannot be promoted")
            values = {}
            for request, worker in zip(graph["requests"], collection["workers"], strict=True):
                data = base64.b64decode(worker["stdout_base64"], validate=True)
                require(sha(data) == worker["stdout_sha256"] and len(data) == worker["stdout_bytes"], "retained worker output byte proof differs")
                decoded, body, _ = decode_worker(data, request)
                require(body["graph_sha256"] == dispatch["graph_sha256"] and body["protocol_sha256"] == dispatch["protocol_sha256"], "original logical graph changed")
                for index, value in zip(request["head_indices"], decoded, strict=True):
                    require(index not in values, "duplicate original head")
                    values[index] = value
                original_nodes += 1
            require(set(values) == set(range(6)), "all six original heads required")
            stacked = np.stack([values[index] for index in range(6)])
            mean = stacked.sum(axis=0, dtype=np.float64) / 6.0
            probability_path = folder / "reduction" / "predictions.npz"
            probability_bytes = probability_path.read_bytes()
            require(sha(probability_bytes) == receipt["predictions_sha256"], "retained prediction archive SHA differs")
            with np.load(probability_path, allow_pickle=False) as archive:
                require(np.array_equal(stacked, archive["per_head"]) and np.array_equal(mean, archive["mean"]), "independent six-head stack/equal-mean differs from original reducer output")
            require(sha(stacked.astype("<f8").tobytes()) == receipt["per_head_tensor_sha256"]
                    and sha(mean.astype("<f8").tobytes()) == receipt["mean_tensor_sha256"], "original reduced tensor hashes differ")
            if graph_id == "b0-A":
                reference = stacked.copy()
            require(reference is not None, "only original b0-A may be reference; no replacement")
            parity = independent_parity(reference, stacked)
            require(parity == reported["parity"] and all(parity[key] for key in ("within_predeclared_tolerance", "all_head_argmax_equal", "mean_argmax_equal")), "independent fixed-tolerance parity differs")
            for key in ("critical_path_ms", "collect_path_ms", "reducer_service_path_ms"):
                require(owner[key] == reported[key], "retained original owner interval differs: " + key)
            row.update(status="completed", parity=parity, critical_path_ms=owner["critical_path_ms"],
                       exact_worker_stack_and_equal_mean=True)
            inputs.extend({"file": str(path), "bytes": len(data), "sha256": sha(data)} for path, data in
                ((folder / "owner.json", owner_bytes), (folder / "reduction" / "receipt.json", receipt_bytes),
                 (folder / "collection.json", collection_bytes)))
            inputs.append({"file": str(probability_path), "bytes": len(probability_bytes), "sha256": sha(probability_bytes)})
        except (OSError, ValueError, KeyError, TypeError) as error:
            row["failure"] = {"type": type(error).__name__, "message": str(error)}
        rows.append(row)
    require(len(rows) == 18, "original complete18-row census required")
    full_numerical = all(row["status"] == "completed" for row in rows) and original_nodes == 30 and rerun_primary_equal
    pairs = None
    if full_numerical:
        pairs = paired_contrasts(rows)
        for name, item in pairs.items():
            original = report["paired_descriptive_wall"][name]
            require(item["all_six_ms"] == original["all_six_ms"] and item["mean_ms"] == original["mean_ms"]
                    and item["median_ms"] == original["median_ms"], "independent complete-census paired costs differ")
    prefix_summary = None
    try:
        document_bytes, document = read(args.partial_prefix, 8_388_608)
        require(sha(document_bytes) == PREFIX_DOCUMENT, "actual partial-prefix extraction document changed")
        prefix_path = args.partial_prefix.with_name("original-prefix.bin")
        require(not prefix_path.is_symlink() and prefix_path.stat().st_size <= 8_388_608, "bounded actual prefix required")
        prefix_summary = prefix_check(document, prefix_path.read_bytes())
        inputs.extend([{"file": str(args.partial_prefix), "bytes": len(document_bytes), "sha256": sha(document_bytes)},
                       {"file": str(prefix_path), "bytes": prefix_path.stat().st_size, "sha256": prefix_summary["prefix_sha256"]}])
    except (OSError, ValueError, KeyError, TypeError) as error:
        issues.append({"scope": "retained_prefix_integrity", "type": type(error).__name__, "message": str(error)})
    old_recovery = original_recovery_census(args.graph_evidence)
    if not old_recovery["passed"]:
        issues.append({"scope": "original_recovery_integrity", "errors": old_recovery["errors"]})
    result = {"schema": "hepta.fixed-cell-graph.explicit-partial-evidence-audit.v2", "original_report_sha256": REPORT,
              "original_reporter_exact_rerun": rerun_exact, "original_reporter_primary_structural_rerun": rerun_primary_equal,
              "source_sha256": PINS,
              "primary_independent_tensor_and_scalar_pass": full_numerical, "primary_rows": rows,
              "retained_worker_output_count": original_nodes, "paired_descriptive_wall": pairs,
              "retained_prefix": prefix_summary, "issues": issues,
              "original_recovery_census": old_recovery["rows"], "original_recovery_census_unchanged": old_recovery["passed"],
              "original_recovery_integrity": old_recovery, "new_v2_recovery_scope": "separate evidence namespace; never substituted here",
              "full_original_native_call_audit_status": "unavailable", "complete_original_cost_audit_pass": False,
              "unknown_costs_are_not_zero": True, "all18_owner_wall_comparison_is_descriptive_only": True,
              "environment": {"python": platform.python_version(), "numpy": np.__version__},
              "method": "Pinned original decoder/report; independent source-output stack, sum/6, tensor archive/hash parity and scalar paired contrasts. No new inference.",
              "limitations": ["Only retained45/383 original raw records, with4/34 chunks; the declared full-ledger SHA is unverified.",
                  "Missing original raw suffix/sealing/outer/helper spans and service/JS CPU/RSS remain unknown.",
                  "Worker/reducer phases are nested, process RSS maxima are not simultaneous total RAM.",
                  "Heterogeneous hardware/Python/NumPy/BLAS and own cgroup ceilings do not isolate network or reserve CPU capacity.",
                  "No successful-subset comparison, new reference, changed tolerance, six-block confidence interval, total-system net benefit or AGI claim."]}
    for name, value in (("partial-audit.json", result), ("input-sha256.json", inputs)):
        with (args.output / name).open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
    return {"primary_independent_tensor_and_scalar_pass": full_numerical,
            "retained_prefix_integrity_pass": not any(issue["scope"] == "retained_prefix_integrity" for issue in issues),
            "original_recovery_integrity_pass": old_recovery["passed"],
            "complete_original_cost_audit_pass": False, "audit_sha256": sha((args.output / "partial-audit.json").read_bytes())}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("source-dir", "dispatch", "graph-evidence", "report", "partial-prefix", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    result = audit(parser.parse_args())
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["primary_independent_tensor_and_scalar_pass"] and result["retained_prefix_integrity_pass"]
                     and result["original_recovery_integrity_pass"] else 1)
