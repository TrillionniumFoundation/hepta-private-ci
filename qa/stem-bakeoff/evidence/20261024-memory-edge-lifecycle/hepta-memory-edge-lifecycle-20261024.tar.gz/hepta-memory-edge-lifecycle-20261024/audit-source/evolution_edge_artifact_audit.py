"""Verify archived tiny base and real topology/parameter-owner SQLite records."""

import argparse
import json
from pathlib import Path
import time

from evolution_audit import Audit
from evolution_common import digest, file_digest, read_json, require, retain
from evolution_lifecycle_audit import database


def analyze(root):
    started, cpu, audit = time.monotonic_ns(), time.process_time_ns(), Audit()
    base, protocol = read_json(root / "base-result.json"), read_json(root / "protocol.json")
    for name, expected in base["files"].items():
        path = root / "tiny-base" / name
        audit.equal(dict(bytes=path.stat().st_size, sha256=file_digest(path)), expected, "tiny base byte mismatch")
    audit.equal(digest(base["files"]), base["base_identity"], "tiny base identity mismatch")
    for path in root.rglob("lineage.json"):
        audit.equal(read_json(path)["base_identity"], base["base_identity"], "checkpoint refers to a different base")
    lifecycle = read_json(root / "topology-lifecycle.json")
    audit.equal([event["kind"] for event in lifecycle["events"]], ["split", "merge", "rollback", "rollback"], "lifecycle sequence differs")
    audit.equal({name: value["manifest_sha256"] for name, value in lifecycle["initial"]["cells"].items()}, {name: value["manifest_sha256"] for name, value in lifecycle["after"]["cells"].items()}, "lifecycle changed final population weights")
    versions = []
    with database(root / "topology/topology.sqlite") as topology:
        for cell, version, data in topology.execute("SELECT cell,version,value FROM versions ORDER BY cell,version"):
            row = json.loads(data)
            checkpoint = root / "topology" / row["directory"].split("/topology/", 1)[1]
            require(checkpoint.resolve().is_relative_to(root.resolve()), "bounded checkpoint path required")
            audit.equal(file_digest(checkpoint / "lineage.json"), row["manifest_sha256"], "SQLite checkpoint pin differs")
            with database(checkpoint.parent / "parameters.sqlite") as owner:
                active = owner.execute("SELECT value FROM cells WHERE scope=? AND cell=?", (protocol["scope"], cell)).fetchone()
                audit.equal(json.loads(active[0]), row["owner_active"], "actual parameter owner differs from topology version")
            audit.equal((row["cell_id"], row["version"], row["owner_active"]["generation"]), (cell, version, version), "stable owner identity/generation differs")
            versions.append(dict(cell_id=cell, generation=version, manifest_sha256=row["manifest_sha256"]))
        for event in lifecycle["events"]:
            stored = topology.execute("SELECT state,receipt FROM operations WHERE id=?", (event["operation_id"],)).fetchone()
            audit.equal((stored[0], json.loads(stored[1])), ("committed", event), "lifecycle operation was not durably committed")
        final_generation, final_data = topology.execute("SELECT generation,value FROM topologies ORDER BY generation DESC LIMIT 1").fetchone()
        final = json.loads(final_data)
    denied = read_json(root / "withdrawal-denials.json")
    with database(root / "sources.sqlite") as source:
        withdrawn = [row[0] for row in source.execute("SELECT root FROM withdrawals ORDER BY root")]
    audit.equal(withdrawn, [denied["source_receipt"]["source_digest"]], "durable withdrawal differs")
    audit.equal(denied["model_callbacks"], 0, "withdrawal denial invoked model")
    audit.equal(set(denied["rejected"]), {"parameter_ancestry", "learned_edge_ancestry", "old_topology_rollback"}, "withdrawal closure paths differ")
    for cell in final["cells"].values():
        audit.equal(sorted(set(cell["roots"]) & set(withdrawn)), [], "withdrawn ancestor in final admitted population")
    audit.equal(final["edge_policy"]["recipe"], "no-edges", "withdrawn learned policy was retained")
    rebuilt = read_json(root / "withdrawal-rebuild.json")["admitted_raw_row"]
    expected = next(case["hint"] for case in protocol["cases"] if rebuilt["question"] == "What is the hint for " + case["case_id"] + "?")
    return dict(schema="hepta.edge-mechanism.artifact-audit.v1", comparisons=audit.comparisons, tiny_base_bytes=sum(row["bytes"] for row in base["files"].values()), verified_owner_versions=versions, final_topology_generation=final_generation, withdrawal_roots=withdrawn, rebuild_raw_answer=rebuilt["text"], rebuild_expected_answer=expected, rebuild_correct=rebuilt["text"].strip() == expected, audit_wall_ns=time.monotonic_ns()-started, audit_cpu_ns=time.process_time_ns()-cpu, auditor_sha256=file_digest(Path(__file__)), extra_model_or_router_predictions=0, sqlite_mode="read-only immutable; reject WAL", autonomous_growth_controller_executed=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--edge", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "new audit output required")
    retain(args.output, analyze(args.edge))
