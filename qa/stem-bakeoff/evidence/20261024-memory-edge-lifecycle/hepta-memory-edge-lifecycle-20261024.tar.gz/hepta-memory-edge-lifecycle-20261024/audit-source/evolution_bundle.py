"""Stream a deterministic source/evidence archive from an explicit frozen spec."""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
import time

from evolution_common import canonical, digest, file_digest, read_json, require, retain


class HashingReader:
    def __init__(self, stream):
        self.stream, self.hasher, self.bytes = stream, hashlib.sha256(), 0

    def read(self, size=-1):
        data = self.stream.read(size)
        self.hasher.update(data)
        self.bytes += len(data)
        return data


def checked_name(value):
    path = PurePosixPath(value)
    require(value and not path.is_absolute() and ".." not in path.parts and str(path) == value, "bounded relative archive name required")
    return value


def members(spec):
    found = {}
    for item in spec["inputs"]:
        require(set(item) == {"path", "archive_path"}, "closed archive input required")
        origin = Path(item["path"])
        require(origin.exists() and not origin.is_symlink(), "regular frozen archive input required")
        paths = sorted(origin.rglob("*")) if origin.is_dir() else [origin]
        for path in paths:
            require(not path.is_symlink(), "archive cannot silently follow links")
            if path.is_dir():
                continue
            require(path.is_file(), "archive contains a nonregular file")
            name = item["archive_path"] + ("/" + path.relative_to(origin).as_posix() if origin.is_dir() else "")
            checked_name(name)
            require(name not in found, "duplicate archive member")
            found[name] = path
    return found


def add(tar, name, stream, size):
    info = tarfile.TarInfo(name)
    info.size, info.mode, info.mtime, info.uid, info.gid = size, 0o644, 0, 0, 0
    info.uname = info.gname = ""
    tar.addfile(info, stream)


def build(spec_path, output):
    require(not output.exists(), "new publication directory required; no overwrite")
    spec = read_json(spec_path)
    require(set(spec) == {"schema", "archive_prefix", "inputs", "completion_guards", "external_dependencies", "interpretation"}, "closed packaging spec")
    checked_name(spec["archive_prefix"])
    require(len(PurePosixPath(spec["archive_prefix"]).parts) == 1, "single archive prefix required")
    require(all(not output.resolve().is_relative_to(Path(x["path"]).resolve()) for x in spec["inputs"] if Path(x["path"]).is_dir()), "publication output must not mutate an input directory")
    for guard in spec["completion_guards"]:
        require(file_digest(guard["path"]) == guard["sha256"], "completion guard changed")
    clock, cpu = time.monotonic_ns(), time.process_time_ns()
    selected = members(spec)
    require(not set(selected) & {"manifest.json", "index.json", "packaging-spec.json"}, "reserved metadata archive name")
    manifest = [dict(path=name, bytes=path.stat().st_size, sha256=file_digest(path)) for name, path in sorted(selected.items())]
    index = dict(schema="hepta.memory-evolution.evidence-index.v1", manifest_sha256=digest(manifest), files=len(manifest), payload_bytes=sum(x["bytes"] for x in manifest), spec_sha256=file_digest(spec_path), builder_sha256=file_digest(Path(__file__)), external_dependencies=spec["external_dependencies"], interpretation=spec["interpretation"], archive_mtime=0, duplicate_embedded_receipts_are_not_additional_model_work=True)
    output.mkdir(parents=True)
    retain(output / "manifest.json", manifest)
    retain(output / "index.json", index)
    archive = output / (spec["archive_prefix"] + ".tar.gz")
    with archive.open("xb") as target, gzip.GzipFile(filename="", mode="wb", fileobj=target, compresslevel=3, mtime=0) as compressed, tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as tar:
        for name, value in (("manifest.json", manifest), ("index.json", index), ("packaging-spec.json", spec)):
            payload = canonical(value) + b"\n"
            add(tar, spec["archive_prefix"] + "/" + name, io.BytesIO(payload), len(payload))
        for entry in manifest:
            path = selected[entry["path"]]
            before = path.stat()
            with path.open("rb") as stream:
                reader = HashingReader(stream)
                add(tar, spec["archive_prefix"] + "/" + entry["path"], reader, entry["bytes"])
            after = path.stat()
            require(reader.bytes == entry["bytes"] and reader.hasher.hexdigest() == entry["sha256"], "input bytes changed during archival")
            require((before.st_mtime_ns, before.st_ctime_ns, before.st_size) == (after.st_mtime_ns, after.st_ctime_ns, after.st_size), "input metadata changed during archival")
    metadata = {name: dict(bytes=len(canonical(value) + b"\n"), sha256=hashlib.sha256(canonical(value) + b"\n").hexdigest()) for name, value in (("manifest.json", manifest), ("index.json", index), ("packaging-spec.json", spec))}
    receipt = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=file_digest(archive), payload_files=len(manifest), archive_members=len(manifest) + 3, metadata_members=metadata, payload_bytes=index["payload_bytes"], wall_ns=time.monotonic_ns() - clock, cpu_ns=time.process_time_ns() - cpu, payload_hash_bytes=2 * index["payload_bytes"], archive_hash_bytes=archive.stat().st_size, model_or_router_calls=0, streaming_compression="gzip level 3; zero header and member timestamps", physical_duplicates_retained=True)
    retain(output / "archive-receipt.json", receipt)
    (output / "SHA256SUMS").write_text(receipt["sha256"] + "  " + archive.name + "\n")
    return receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.spec, args.output), sort_keys=True))
