"""Independent raw-data reduction for a completed bounded edge mechanism trial."""

import argparse
from collections import Counter
import json
from pathlib import Path
import time

from evolution_audit import Audit, inventory
from evolution_common import digest, file_digest, read_json, require, retain


def state_text(state):
    return "Request: " + state["question"] + "\nCell: " + state["cell_id"] + "\nObserved raw output: " + json.dumps(state["raw_text"], ensure_ascii=False)


def audit_trace(audit, trace, rows):
    for step in trace:
        raw = step["raw"]
        audit.equal(step["actual_callbacks"], 1 if raw is not None else 0, "completed trace has unaccounted callback")
        if raw is not None:
            audit.equal(raw["question"], step["prompt"], "raw question differs from actual prompt")
            audit.equal(raw["answer_postprocessed"], False, "postprocessed graph answer")
            rows[digest(raw)] += 1


def reduce(root):
    started, cpu = time.monotonic_ns(), time.process_time_ns()
    result, protocol = read_json(root / "result.json"), read_json(root / "protocol.json")
    audit = Audit()
    audit.equal(result["completed"], True, "completed trial required")
    sources = audit.sources(root)
    weights = audit.checkpoints(root, "training/*/checkpoint/lineage.json")
    children = audit.children(root)
    audit.equal([r for r in children["canonical_child_receipts"] if r["returncode"] != 0 or r["timed_out"]], [], "incomplete child in completed edge result")
    audit.equal(children["incomplete_stdout"], [], "uncounted child output")
    raw_rows = Counter()
    for receipt in children["canonical_child_receipts"]:
        value = json.loads(read_json(root / receipt["path"])["stdout"])
        if value.get("schema") == "hepta.parametric-memory.read-journal.v1":
            raw_rows.update(digest(row) for row in value["rows"])
    represented, observations, utilities = Counter(), [], []
    initial = read_json(root / "initial-source-snapshot.json")
    targets = [c for c in protocol["cells"] if c != "hint"]
    for wording, template in enumerate(protocol["source_templates"]):
        for case in protocol["cases"]:
            folder = root / "source-observations" / (case["case_id"] + f"-source-{wording}")
            observation = read_json(folder / "observation.json")
            entry = read_json(folder / "entry.json")
            audit_trace(audit, entry, represented)
            audit.equal(observation["state"], dict(question=template.format(entity=case["case_id"]), cell_id="hint", raw_text=entry[0]["raw"]["text"]), "source routing state differs from live first output")
            audit.equal(observation["source_roots"], sorted(initial["roots"]), "learned policy omits observed decoder ancestry")
            audit.equal(observation["target_value"], case["color"], "source target differs from registered source")
            values = []
            for target in targets:
                trace = read_json(folder / (target + ".json"))
                audit_trace(audit, trace, represented)
                observed = observation["candidate_outputs"][target]
                audit.equal(observed["receipt_sha256"], digest(trace), "utility receipt hash differs")
                audit.equal(observed["actual_callbacks"], sum(t["actual_callbacks"] for t in trace), "utility callback count differs")
                audit.equal(observed["raw_text"], trace[-1]["raw"]["text"] if trace[-1]["raw"] else None, "utility output differs from actual reader")
                audit.equal(observed["status"], trace[-1]["status"], "utility status differs")
                prompt = trace[0]["capability"]["question"] + " Previous cell output: " + json.dumps(entry[0]["raw"]["text"], ensure_ascii=False)
                audit.equal(trace[0]["prompt"], prompt, "source candidate prompt omitted the actual entry output")
                values.append(float(observed["status"] == "generated" and observed["raw_text"].strip() == case["color"]))
            utilities.append(dict(question=state_text(observation["state"]), utilities=values, reject=not any(values)))
            observations.append(observation)
    audit.equal(len(observations), protocol["source_utility_cases"], "source panel count differs")
    audit.equal(read_json(root / "learned-policy/source-observations.json"), utilities, "router labels differ from measured expert utility")
    policy = read_json(root / "learned-policy/policy.json")
    freeze = read_json(root / "final-policy-freeze.json")
    audit.equal(policy["source_sha256"], digest(observations), "router source panel binding differs")
    audit.equal(policy["router_sha256"], file_digest(root / "learned-policy/router.bin"), "serialized router bytes differ")
    audit.equal(policy["ancestry_roots"], sorted(initial["roots"]), "serialized policy ancestor closure differs")
    audit.equal(policy["training"]["optimizer_updates"], protocol["router_updates"], "router update count differs")
    audit.equal(freeze["final_outcomes_seen"], False, "final outcomes influenced policy freeze")
    audit.equal(freeze["source_observations_sha256"], digest(observations), "freeze panel differs")
    audit.equal(freeze["learned_policy"]["sha256"], file_digest(root / "learned-policy/policy.json"), "policy changed after freeze")
    scores, final_callbacks = {}, 0
    for arm in protocol["arms"]:
        rows = []
        for case in protocol["cases"]:
            path = root / "final" / arm / (case["case_id"] + "-final.json")
            actual = read_json(path)
            require(set(actual["task"]) == {"task_id", "entity", "entry_cell"}, "gold field entered final task")
            if arm in ("direct-parameter", "exact-source"):
                audit.equal(actual["actual_callbacks"], int(arm == "direct-parameter"), "direct-control callback differs")
                if arm == "direct-parameter":
                    represented[digest(actual["raw"])] += 1
                    audit.equal(actual["answer"], actual["raw"]["text"], "direct answer differs from raw row")
            else:
                trace = actual["trace"]
                audit_trace(audit, trace, represented)
                audit.equal(actual["actual_callbacks"], sum(t["actual_callbacks"] for t in trace), "graph callback total differs")
                decision = read_json(path.with_suffix(".decision.json"))
                audit.equal(actual["decision_sha256"], digest(decision), "frozen decision hash differs")
                audit.equal(actual["decision"], decision["decision"], "graph decision changed")
                require(freeze["frozen_monotonic_ns"] <= trace[0]["started_ns"] <= trace[0]["finished_ns"] <= decision["before_next_callback_ns"], "decision/source chronology differs")
                if len(trace) == 2:
                    prompt = trace[1]["capability"]["question"] + " Previous cell output: " + json.dumps(trace[0]["raw"]["text"], ensure_ascii=False)
                    audit.equal(trace[1]["prompt"], prompt, "second decoder did not receive actual first output")
                    require(decision["before_next_callback_ns"] <= trace[1]["started_ns"], "decision was not recorded before next step")
            correct = actual["answer"] is not None and actual["answer"].strip() == case["color"]
            rows.append(dict(task_id=case["case_id"] + "-final", correct=correct, expected=case["color"], actual=actual["answer"], origin=actual["origin"], status=actual["status"], admitted_reader_callbacks=actual["actual_callbacks"]))
            final_callbacks += actual["actual_callbacks"]
        stored = read_json(root / "final" / arm / "score.json")
        audit.equal(stored["cases"], rows, "arm score differs from actual outcome")
        audit.equal(stored["correct"], sum(r["correct"] for r in rows), "arm numerator differs")
        audit.equal(stored["total"], len(protocol["cases"]), "arm denominator differs")
        audit.equal(stored["population_sha256"], digest(freeze["population"]), "arm population identity differs")
        audit.equal(result["arms"][arm], stored, "top-level arm differs")
        scores[arm] = dict(correct=stored["correct"], total=stored["total"], actual_callbacks=sum(r["admitted_reader_callbacks"] for r in rows))
    rebuild = read_json(root / "withdrawal-rebuild.json")
    represented[digest(rebuild["admitted_raw_row"])] += 1
    audit.equal(represented, raw_rows, "raw child calls do not match source/final/rebuild traces exactly once")
    events = [read_json(f) for f in sorted((root / "budget-events").glob("*.json"))]
    measured = Counter()
    for event in events:
        measured.update(event["measured"])
    audit.equal({key: measured[key] for key in result["physical_work"]}, result["physical_work"], "physical budget does not sum from actual receipts")
    audit.equal(weights["optimizer_updates"], protocol["decoder_optimizer_updates"], "decoder updates differ")
    audit.equal(children["raw_rows"], result["physical_work"]["decoder_queries"], "raw query ledger differs")
    audit.equal(weights["training_tokens"], result["physical_work"]["train_tokens"], "training token ledger differs")
    audit.equal(children["input_tokens"], result["physical_work"]["input_tokens"], "input token ledger differs")
    audit.equal(children["output_tokens"], result["physical_work"]["output_tokens"], "output token ledger differs")
    audit.equal(children["child_count"], children["raw_rows"] + weights["training_attempts"] + 1, "unclassified child work")
    return dict(schema="hepta.edge-mechanism.independent-audit.v1", sources=sources, checkpoints=weights, processes=children, source_observations=len(observations), source_utility_rows=utilities, scores=scores, final_decoder_callbacks=final_callbacks, actual_model_or_router_predictions=0, numeric_router_prediction_replay=False, comparisons=audit.comparisons, audit_wall_ns=time.monotonic_ns() - started, audit_cpu_ns=time.process_time_ns() - cpu, auditor_sha256=file_digest(Path(__file__)), natural_groups=0, confirmation=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--edge", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "new derived audit directory required")
    args.output.mkdir(parents=True)
    value = reduce(args.edge)
    retain(args.output / "audit.json", value)
    retain(args.output / "manifest.json", inventory(args.edge))
