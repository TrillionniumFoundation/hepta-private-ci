"""Verify every deterministic archive member without extraction or model imports."""

import argparse
import hashlib
import json
from pathlib import Path
import tarfile
import time

from evolution_common import digest, file_digest, read_json, require, retain


def verify(archive, receipt_path):
    clock, cpu = time.monotonic_ns(), time.process_time_ns()
    receipt = read_json(receipt_path)
    require(archive.stat().st_size == receipt["bytes"] and file_digest(archive) == receipt["sha256"], "archive byte identity differs")
    prefix = archive.name.removesuffix(".tar.gz") + "/"
    metadata, rows, seen, payload_bytes = {}, {}, set(), 0
    with tarfile.open(archive, mode="r|gz") as stream:
        for index, member in enumerate(stream):
            require(member.isfile() and member.name.startswith(prefix), "unexpected archive member")
            name = member.name[len(prefix):]
            require(name not in seen and member.uid == member.gid == member.mtime == 0 and member.mode == 0o644, "duplicate or nondeterministic member")
            require(not member.uname and not member.gname, "nondeterministic archive ownership")
            seen.add(name)
            if index < 3:
                require(name in receipt["metadata_members"] and member.size <= 4 * 1024 * 1024, "bounded registered metadata required")
                data = stream.extractfile(member).read()
                expected = receipt["metadata_members"][name]
                require(len(data) == expected["bytes"] and hashlib.sha256(data).hexdigest() == expected["sha256"], "metadata byte identity differs")
                metadata[name] = json.loads(data)
                if index == 2:
                    require(set(metadata) == {"manifest.json", "index.json", "packaging-spec.json"}, "incomplete metadata")
                    manifest, document = metadata["manifest.json"], metadata["index.json"]
                    rows = {r["path"]: r for r in manifest}
                    require(len(rows) == len(manifest) and digest(manifest) == document["manifest_sha256"], "manifest identity differs")
                    require(len(rows) == document["files"] == receipt["payload_files"], "manifest member count differs")
                continue
            require(name in rows and member.size == rows[name]["bytes"], "unregistered payload member")
            hasher, count = hashlib.sha256(), 0
            source = stream.extractfile(member)
            while data := source.read(1024 * 1024):
                hasher.update(data)
                count += len(data)
            require(count == member.size and hasher.hexdigest() == rows[name]["sha256"], "payload byte identity differs")
            payload_bytes += count
    require(seen == set(rows) | set(metadata), "missing or extra archive member")
    require(len(seen) == receipt["archive_members"], "archive member count differs")
    require(payload_bytes == metadata["index.json"]["payload_bytes"] == receipt["payload_bytes"], "payload extent differs")
    return dict(schema="hepta.memory-evolution.archive-audit.v1", archive_sha256=receipt["sha256"], archive_bytes=receipt["bytes"], member_count=len(seen), payload_files=len(rows), payload_hash_bytes=payload_bytes, compressed_hash_bytes=receipt["bytes"], all_member_hashes_match=True, extracted_files=0, model_or_router_predictions=0, audit_wall_ns=time.monotonic_ns() - clock, audit_cpu_ns=time.process_time_ns() - cpu, auditor_sha256=file_digest(Path(__file__)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "new audit output required")
    result = verify(args.archive, args.receipt)
    retain(args.output, result)
    print(json.dumps(result, sort_keys=True))
