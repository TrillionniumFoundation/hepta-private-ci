"""Read-only byte and raw-receipt audit; never import Torch or execute a model."""

import argparse
import json
import math
from pathlib import Path
import resource
import struct
import time

from evolution_common import digest, file_digest, read_json, require, retain


class Audit:
    def __init__(self):
        self.comparisons = 0

    def equal(self, actual, expected, label):
        self.comparisons += 1
        require(actual == expected, label)

    def sources(self, root):
        identity = read_json(root / "source-identity.json")
        self.equal(read_json(root / "source-identity-after.json"), identity, "source identity changed")
        groups = [("repository_files", "baseline"), ("local_files", "driver"), ("driver_files", "driver"), ("budget_files", "budget")]
        count = 0
        for field, folder in groups:
            for name, expected in identity.get(field, {}).items():
                self.equal(file_digest(root / "source-snapshot" / folder / name), expected, "executed source byte mismatch")
                count += 1
        return dict(identity_sha256=digest(identity), verified_source_files=count)

    def checkpoints(self, root, training_glob):
        training_paths = set(root.glob(training_glob))
        entries, training = [], []
        for path in sorted(root.rglob("lineage.json")):
            lineage = read_json(path)
            if lineage.get("schema") != "hepta.memory-lora-candidate.v2":
                continue
            adapter, config = path.parent / "adapter_model.safetensors", path.parent / "adapter_config.json"
            self.equal(file_digest(adapter), lineage["adapter_sha256"], "adapter file differs from manifest")
            self.equal(file_digest(config), lineage["config_sha256"], "adapter config differs from manifest")
            with adapter.open("rb") as stream:
                header_size = struct.unpack("<Q", stream.read(8))[0]
                require(0 < header_size <= 1024 * 1024, "bounded safetensors header required")
                header = json.loads(stream.read(header_size))
            tensors = {k: v for k, v in header.items() if k != "__metadata__"}
            layout = {k: dict(shape=v["shape"], dtype="torch.float32" if v["dtype"] == "F32" else v["dtype"]) for k, v in tensors.items()}
            self.equal(layout, lineage["tensor_layout"], "actual tensor header layout mismatch")
            ranges = sorted((v["data_offsets"][0], v["data_offsets"][1], math.prod(v["shape"]) * 4) for v in tensors.values())
            end = 0
            for start, finish, size in ranges:
                self.equal((start, finish - start), (end, size), "non-contiguous or wrong-sized float32 tensor")
                end = finish
            self.equal(end, adapter.stat().st_size - 8 - header_size, "safetensors payload extent mismatch")
            write = lineage["training"]
            self.equal(write["parameter_bytes"], end, "recorded adapter bytes differ from actual payload")
            self.equal(write["trainable_parameters"], sum(math.prod(v["shape"]) for v in tensors.values()), "recorded parameter count mismatch")
            record = dict(path=str(path.relative_to(root)), manifest_sha256=file_digest(path), adapter_sha256=lineage["adapter_sha256"], adapter_file_bytes=adapter.stat().st_size, parameter_payload_bytes=end, training_counted=path in training_paths, roots=lineage["roots"])
            entries.append(record)
            if path in training_paths:
                self.equal(write["steps"], len(write["losses"]), "optimizer step/loss count mismatch")
                self.equal(write["steps"], sum(write["fact_visits"]), "actual fact exposure count mismatch")
                self.equal(write["steps"], write["actual_model_forwards"], "completion-CE forward count mismatch")
                require(all(math.isfinite(x) for x in write["losses"]), "nonfinite retained training loss")
                training.append(write)
        self.equal(len(training), len(training_paths), "unrecognized training artifact")
        return dict(checkpoints=entries, physical_checkpoint_copies=len(entries), unique_manifest_sha256=len({r["manifest_sha256"] for r in entries}), training_attempts=len(training), optimizer_updates=sum(t["steps"] for t in training), training_tokens=sum(t["input_tokens"] for t in training), training_seconds=sum(t["seconds"] for t in training))

    def children(self, root):
        records, raw, incomplete = [], [], []
        for path in sorted(root.rglob("*.stderr.result.json")):
            child = read_json(path)
            self.equal(child["bootstrap"]["pid"], child["pid"], "child bootstrap identity differs")
            record = {k: child[k] for k in ("pid", "returncode", "timed_out", "wall_seconds")}
            record.update(path=str(path.relative_to(root)), sha256=file_digest(path))
            records.append(record)
            try:
                output = json.loads(child["stdout"])
            except (ValueError, TypeError):
                incomplete.append(record)
                continue
            if output.get("schema") == "hepta.parametric-memory.read-journal.v1":
                for flag in ("fact_input", "retrieval_input", "answer_lexicon_input"):
                    self.equal(output[flag], False, "source/retrieval input in raw parameter read")
                for row in output["rows"]:
                    self.equal(row["answer_postprocessed"], False, "raw answer changed")
                    self.equal(row["input_tokens"], len(row["prompt_token_ids"]), "raw prompt token counter")
                    self.equal(row["generated_tokens"], len(row["token_ids"]), "raw generated token counter")
                raw.extend(output["rows"])
        return dict(canonical_child_receipts=records, child_count=len(records), distinct_pid_values=len({r["pid"] for r in records}), pid_uniqueness_scope="this run only; no cross-run PID namespace claim", raw_rows=len(raw), input_tokens=sum(r["input_tokens"] for r in raw), output_tokens=sum(r["generated_tokens"] for r in raw), child_wall_seconds=sum(r["wall_seconds"] for r in records), incomplete_stdout=incomplete, embedded_duplicate_journals_counted=False)

    def round_counts(self, snapshot, previous, events, journal, templates, stored):
        facts, rows = snapshot["facts"], journal["rows"]
        expected = [template.format(**fact) for fact in facts for template in templates]
        self.equal([r["question"] for r in rows], expected, "round query/source alignment")
        width, hits = len(templates), {}
        raw_correct = 0
        for index, fact in enumerate(facts):
            correct = [r["text"].strip() == fact["value"] for r in rows[index * width:(index + 1) * width]]
            hits[(fact["entity"], fact["relation"])] = all(correct)
            raw_correct += sum(correct)
        old = {(f["entity"], f["relation"]): f["value"] for f in previous}
        retained = [hits[(f["entity"], f["relation"])] for f in facts if old.get((f["entity"], f["relation"])) == f["value"]]
        changed = {(e["entity"], e["relation"]) for e in events if e["kind"] == "correct"}
        corrected = [hits[key] for key in changed if key in hits]
        counts = dict(raw_queries=dict(correct=raw_correct, total=len(rows)), source_both_wordings=dict(correct=sum(hits.values()), total=len(facts)), unchanged_retention=dict(correct=sum(retained), total=len(retained)), corrected_sources=dict(correct=sum(corrected), total=len(corrected)))
        for field, value in counts.items():
            self.equal({k: stored[field][k] for k in value}, value, "stored score differs from independent raw reduction")
        return counts

    def longitudinal(self, root):
        completed = read_json(root / "campaign-result.json")
        self.equal(completed["completed"], True, "incomplete campaign cannot receive final inventory")
        campaign = read_json(root / "registered-campaign.json")
        seeds = []
        for seed in campaign["launch_order"]:
            directory = root / f"seed-{seed}"
            result, protocol = read_json(directory / "result.json"), read_json(directory / "protocol.json")
            self.equal(protocol, campaign["streams"][str(seed)], "executed seed differs from frozen stream")
            sources = self.sources(directory)
            weights = self.checkpoints(directory, "source-owner/artifacts/*/checkpoint/lineage.json")
            processes = self.children(directory)
            self.equal([r for r in processes["canonical_child_receipts"] if r["returncode"] != 0 or r["timed_out"]], [], "completed campaign contains a failed model child")
            self.equal(processes["incomplete_stdout"], [], "completed campaign contains uncounted child output")
            self.equal(weights["optimizer_updates"], protocol["decoder_optimizer_updates"], "registered optimizer total")
            self.equal(processes["raw_rows"], protocol["expected_parameter_query_rows"], "registered raw-row total")
            self.equal(processes["raw_rows"], result["costs"]["counted_raw_rows"], "reported raw-row total")
            self.equal(weights["optimizer_updates"], result["costs"]["saved_optimizer_updates"], "reported optimizer total")
            scores, controls, previous = [], {}, []
            for index, item in enumerate(protocol["rounds"]):
                folder = directory / f"round-{index}-{item['label']}"
                snapshot = read_json(folder / "source-snapshot.json")
                events = item["before_background"] + item["events"]
                scores.append(self.round_counts(snapshot, previous, events, read_json(folder / "adapter.journal.json"), protocol["read_templates"], result["scores"][index]))
                self.equal(read_json(folder / "dirty-admission.json")["model_callbacks"], 0, "dirty source triggered a model callback")
                if index in protocol["control_rounds"]:
                    controls[str(index)] = {name: self.round_counts(snapshot, previous, events, read_json(folder / (name + ".journal.json")), protocol["read_templates"], result["controls"][str(index)][name]) for name in protocol["controls"]}
                previous = snapshot["facts"]
            limits = protocol["predeclared_quality"]
            gates = dict(every_round_parameter_accuracy=all(s["source_both_wordings"]["correct"] / s["source_both_wordings"]["total"] >= limits["each_round_source_both_wordings_accuracy_min"] for s in scores), every_measured_retention_panel=all(not s["unchanged_retention"]["total"] or s["unchanged_retention"]["correct"] / s["unchanged_retention"]["total"] >= limits["unchanged_retention_both_wordings_accuracy_min"] for s in scores), every_corrected_source_exact=all(s["corrected_sources"]["correct"] == s["corrected_sources"]["total"] for s in scores))
            self.equal(gates, result["quality_gates"], "quality gate reduction mismatch")
            seeds.append(dict(seed=seed, sources=sources, checkpoints=weights, processes=processes, rounds=scores, controls=controls, gates=gates, retention_means_service_after_fresh_replay=True))
        self.equal(sum(s["checkpoints"]["optimizer_updates"] for s in seeds), completed["total_optimizer_updates"], "campaign update total mismatch")
        self.equal(sum(s["processes"]["raw_rows"] for s in seeds), completed["total_raw_rows"], "campaign row total mismatch")
        return dict(seeds=seeds, scientific_confirmation=False, independent_natural_groups=0)


def inventory(root):
    files = []
    paths = sorted(p for p in root.rglob("*") if p.is_file() or p.is_symlink())
    for path in paths:
        require(not path.is_symlink(), "evidence inventory cannot silently follow symlinks")
        before = path.stat()
        sha = file_digest(path)
        after = path.stat()
        require((before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_size, after.st_mtime_ns, after.st_ctime_ns), "evidence changed during inventory")
        files.append(dict(path=str(path.relative_to(root)), bytes=after.st_size, sha256=sha))
    require(paths == sorted(p for p in root.rglob("*") if p.is_file() or p.is_symlink()), "evidence file set changed during inventory")
    return dict(root=str(root), files=files, file_count=len(files), logical_bytes=sum(f["bytes"] for f in files), manifest_sha256=digest(files))


def main(args):
    require(not args.output.exists(), "new derived audit directory required")
    args.output.mkdir(parents=True)
    started, cpu = time.monotonic_ns(), time.process_time_ns()
    audit = Audit()
    result = audit.longitudinal(args.longitudinal)
    manifest = inventory(args.longitudinal)
    retain(args.output / "manifest.json", manifest)
    result.update(comparisons=audit.comparisons, audit_wall_ns=time.monotonic_ns() - started, audit_cpu_ns=time.process_time_ns() - cpu, audit_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024, manifest_hash_payload_bytes=manifest["logical_bytes"], complete_audit_io_measured=False, extra_model_or_router_predictions=0, inventory_sha256=digest(manifest), auditor_sha256=file_digest(Path(__file__)))
    retain(args.output / "audit.json", result)
    print(json.dumps(dict(comparisons=audit.comparisons, manifest_sha256=manifest["manifest_sha256"], file_count=manifest["file_count"], logical_bytes=manifest["logical_bytes"]), sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--longitudinal", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args())
