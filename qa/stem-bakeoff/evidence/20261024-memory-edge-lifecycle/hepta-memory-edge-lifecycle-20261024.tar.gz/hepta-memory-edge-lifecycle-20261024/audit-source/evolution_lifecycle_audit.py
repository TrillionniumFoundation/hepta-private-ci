"""Reduce completed longitudinal lifecycle receipts and immutable SQLite bytes."""

import argparse
from collections import Counter
import json
from pathlib import Path
import sqlite3
import time

from evolution_audit import Audit
from evolution_common import file_digest, read_json, require, retain


def database(path):
    require(not Path(str(path) + "-wal").exists(), "non-checkpointed SQLite WAL requires separate analysis")
    return sqlite3.connect(path.resolve().as_uri() + "?mode=ro&immutable=1", uri=True)


def analyze(root):
    clock, cpu = time.monotonic_ns(), time.process_time_ns()
    audit, seeds = Audit(), []
    campaign = read_json(root / "registered-campaign.json")
    audit.equal(read_json(root / "campaign-result.json")["completed"], True, "completed campaign required")
    for seed in campaign["launch_order"]:
        directory = root / f"seed-{seed}"
        protocol = read_json(directory / "protocol.json")
        dirty, superseded, publications = Counter(), [], []
        with database(directory / "source-owner/sources.sqlite") as source, database(directory / "topology/topology.sqlite") as topology:
            for index, item in enumerate(protocol["rounds"]):
                folder = directory / f"round-{index}-{item['label']}"
                snapshot = read_json(folder / "source-snapshot.json")
                denied = read_json(folder / "dirty-admission.json")
                audit.equal(denied["model_callbacks"], 0, "dirty callback occurred")
                for row in denied["rows"]:
                    value = row["result"]
                    audit.equal(value["response"], None, "dirty read returned raw response")
                    audit.equal(value["source_epoch"], snapshot["epoch"], "dirty read has wrong source epoch")
                    require(value["status"] in ("unavailable", "unknown", "revoked", "conflict"), "unexpected dirty admission")
                    dirty[value["status"]] += 1
                publication = read_json(folder / "topology-publication.json")
                staged = publication["prepared"]["staged_versions"][protocol["cell_id"]]
                committed = publication["committed"]
                audit.equal(committed["generation"], index + 1, "topology generation skipped")
                audit.equal(staged["version"], index, "stable owner version skipped")
                audit.equal(staged["owner_active"]["generation"], index, "parameter generation skipped")
                audit.equal(staged["cell_id"], protocol["cell_id"], "cell identity changed")
                audit.equal(staged["source_epoch"], snapshot["epoch"], "staged source cut differs")
                audit.equal(staged["support_roots"], sorted(f["source_digest"] for f in snapshot["facts"]), "source support differs")
                audit.equal(sorted(set(staged["roots"]) & set(snapshot["revoked"])), [], "withdrawn ancestor in clean owner")
                audit.equal(staged["manifest_sha256"], publication["source_publication"]["manifest_sha256"], "source owner/topology checkpoint mismatch")
                stored = topology.execute("SELECT value FROM versions WHERE cell=? AND version=?", (protocol["cell_id"], index)).fetchone()
                audit.equal(json.loads(stored[0]), staged, "SQLite version differs from committed receipt")
                operation = topology.execute("SELECT state,receipt FROM operations WHERE id=?", (f"publication-{index}",)).fetchone()
                audit.equal((operation[0], json.loads(operation[1])), ("committed", committed), "SQLite operation differs")
                owner_path = directory / "topology/prepared" / f"publication-{index}" / protocol["cell_id"] / "parameters.sqlite"
                with database(owner_path) as owner:
                    value = owner.execute("SELECT value FROM cells WHERE scope=? AND cell=?", (protocol["scope"], protocol["cell_id"])).fetchone()
                    audit.equal(json.loads(value[0]), staged["owner_active"], "actual parameter owner differs")
                publications.append(dict(round=index, source_epoch=snapshot["epoch"], topology_generation=index + 1, owner_generation=index, manifest_sha256=staged["manifest_sha256"]))
                if item["background_steps"]:
                    observed = read_json(folder / "background-construction-observed.json")
                    rejected = read_json(folder / "superseded-training.json")
                    events = read_json(folder / "during-background-events.json")
                    audit.equal(observed["status"], "running", "candidate was not observed running")
                    require(observed["observed_monotonic_ns"] <= events[0]["started_monotonic_ns"], "event predates candidate observation")
                    audit.equal(rejected["result"]["status"], "superseded", "stale candidate published")
                    audit.equal(rejected["result"]["job_id"], observed["job_id"], "superseded job mismatch")
                    audit.equal(rejected["actual_training"]["steps"], item["background_steps"], "background fit was skipped")
                    state = source.execute("SELECT state,epoch FROM jobs WHERE id=?", (observed["job_id"],)).fetchone()
                    audit.equal(state, ("superseded", rejected["result"]["epoch"]), "SQLite supersession differs")
                    superseded.append(dict(round=index, job_id=observed["job_id"], steps=item["background_steps"], training_seconds=rejected["actual_training"]["seconds"]))
            final = snapshot
            withdrawn = [r[0] for r in source.execute("SELECT root FROM withdrawals ORDER BY root")]
            audit.equal(withdrawn, final["revoked"], "durable withdrawal frontier differs")
            audit.equal(topology.execute("SELECT count(*) FROM topologies").fetchone()[0], len(protocol["rounds"]) + 1, "unexpected committed topology history")
        seeds.append(dict(seed=seed, dirty_admissions=sum(dirty.values()), dirty_status_counts=dict(dirty), model_callbacks=0, clean_publications=publications, superseded_attempts=superseded, source_withdrawal_root_count=len(withdrawn)))
    return dict(schema="hepta.longitudinal.lifecycle-audit.v1", seeds=seeds, comparisons=audit.comparisons, actual_model_or_router_calls=0, source_bytes_modified=False, sqlite_open_mode="read-only immutable; reject any WAL", audit_wall_ns=time.monotonic_ns() - clock, audit_cpu_ns=time.process_time_ns() - cpu, auditor_sha256=file_digest(Path(__file__)), limitations=["trusted local source provider", "finite bounded supersession, not sustainable arrival-rate qualification", "old checkpoints retained; withdrawal is admission denial", "publication timestamp not separately measured"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--longitudinal", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "new derived receipt required")
    retain(args.output, analyze(args.longitudinal))
