"""Read and deterministically package an already completed codec replay."""
import ast
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import tarfile

WORK = Path(__file__).resolve().parent
SOURCE = WORK / 'codec-engineering-followup-001'
OUTPUT = WORK / 'codec-publication-001'
PREFIX = 'codec-engineering-followup-20261024'
TARGET = 'qa/stem-bakeoff/evidence/20261024-codec-engineering-followup'
COMMIT = 'a88f2832f2a1a4d3734c1c88f76977dcc9b98ff1'
TREE = 'a536ad588592851225003384121aac243097e0bb'
PROTOCOL_SHA = 'a17a78785482c1e06220d3f973cd9bf73ea5460235f9cdb0d1fa126bc20f00b9'
MANIFEST_SHA = 'c880266b1f27eee68e0e7ff7a2b47def718070b5b8caa8727a591446d77e22b3'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()


def main():
    if OUTPUT.exists():
        raise FileExistsError('Do not overwrite an evidence freeze')
    stat = os.statvfs(WORK)
    if stat.f_bavail * stat.f_frsize < 10 * 1024 * 1024:
        raise OSError('Fewer than 10 MiB available')
    checks = []

    def check(condition, label):
        if not condition:
            raise ValueError(label)
        checks.append(label)

    original = {}
    for path in sorted(SOURCE.rglob('*')):
        if path.is_file():
            check(not path.is_symlink(), 'regular input: ' + str(path.relative_to(SOURCE)))
            original[str(path.relative_to(SOURCE))] = path.read_bytes()
    protocol = json.loads(original['protocol.json'])
    manifest = json.loads(original['source-manifest.json'])
    result = json.loads(original['run-001/result.json'])
    launch = json.loads(original['run-001/launch.json'])
    check(sha(original['protocol.json']) == PROTOCOL_SHA, 'original protocol hash')
    check(sha(original['source-manifest.json']) == MANIFEST_SHA, 'original source manifest hash')
    check(protocol['source_commit'] == manifest['source_commit'] == result['source_commit'] == COMMIT, 'original source commit')
    check(protocol['source_tree'] == manifest['source_tree'] == TREE, 'original source tree')
    check(launch['driver_sha256'] == sha(original['run_followup.py']), 'actual driver hash')
    check(launch['protocol_sha256'] == PROTOCOL_SHA and launch['manifest_sha256'] == MANIFEST_SHA, 'launch pins')
    check(not launch['automatic_retry'] and launch['no_benchmark_credit'], 'no automatic replay or benchmark credit')
    check(result['completed'] and result['source_unchanged'], 'completed source-preserving result')
    check(result['model_calls'] == 0 and not result['memory_repair_credit'] and not result['A_B_benchmark_results_changed'], 'zero model calls and benchmark credit')
    check(not result['original_hosted_installation_qualified'], 'hosted installation remains unqualified')
    check(len(manifest['files']) == 25 and manifest['bytes'] == 220039, '25 original files and byte total')
    for item in manifest['files']:
        data = original['source/' + item['path']]
        check(len(data) == item['bytes'] and sha(data) == item['sha256'] and blob(data) == item['git_blob_sha'], 'source bytes: ' + item['path'])
    check(sum(len(original['source/' + item['path']]) for item in manifest['files']) == 220039, 'actual source byte sum')
    check(json.loads(original['run-001/source-before.json']) == manifest['files'], 'before source identities')
    check(json.loads(original['run-001/source-after.json']) == manifest['files'], 'after source identities')
    declared = set()
    for item in protocol['static_tests']:
        tree = ast.parse(original['source/' + item['path']])
        methods = {node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')}
        check(methods == set(item['method_names']) and len(methods) == item['static_test_method_count'], 'static test methods: ' + item['path'])
        declared.update(methods)
    check(len(declared) == 21, '21 distinct registered methods')
    check(len(protocol['commands']) == len(result['rows']) == 2, 'exactly two commands and results')
    check(protocol['commands'][0]['argv'] == protocol['commands'][1]['argv'], 'identical test argv')
    check(protocol['commands'][0]['cwd'] == protocol['commands'][1]['cwd'], 'identical source working directory')
    observed = []
    for command, row in zip(protocol['commands'], result['rows'], strict=True):
        name = command['name']
        start = json.loads(original[f'run-001/{name}.start.json'])
        check(start['command'] == command and start['pid'] == row['pid'], name + ': actual command and PID')
        check(json.loads(original[f'run-001/{name}.result.json']) == row, name + ': original per-arm result')
        for stream in ('stdout', 'stderr'):
            data = original[f'run-001/{name}.{stream}']
            check(row[stream] == {'bytes': len(data), 'sha256': sha(data)}, name + ': ' + stream + ' identity')
        diagnostic = original[f'run-001/{name}.stderr'].decode()
        lines = re.findall(r'^(test_[^( ]+) \([^)]+\) \.\.\. (.+)$', diagnostic, re.MULTILINE)
        check(len(lines) == 21 and {item[0] for item in lines} == declared, name + ': exact 21 raw rows')
        skipped = sum(item[1].startswith('skipped ') for item in lines)
        passed = sum(item[1] == 'ok' for item in lines)
        counts = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s$', diagnostic, re.MULTILINE)
        check(len(counts) == 1 and int(counts[0][0]) == row['tests_run'] == 21, name + ': denominator')
        check(skipped == row['skipped'] == command['expected_skipped'], name + ': skip count')
        check(passed + skipped == 21 and row['returncode'] == 0 and not row['timed_out'], name + ': process and full outcomes')
        check(all(row[field] == 0 for field in ('errors', 'failures', 'expected_failures', 'unexpected_successes')), name + ': no failure category')
        check(row['passed_registered_environment_check'] and 0 < row['wall_ns'] < 300 * 10**9, name + ': bounded environment check')
        observed.append({'name': name, 'path_overlay': command['env_overlay']['PATH'], 'tests': 21,
                         'passed': passed, 'skipped': skipped, 'returncode': row['returncode'],
                         'wall_ns': row['wall_ns'], 'child_cpu_ns': row['child_cpu_ns'],
                         'pid_in_driver_namespace': row['pid'], 'unittest_reported_seconds': counts[0][1]})
    check(observed[0]['path_overlay'] == '' and observed[0]['skipped'] == 21, 'empty PATH negative')
    check(observed[1]['path_overlay'] == '/usr/bin:/bin' and observed[1]['passed'] == 21, 'real tools positive')
    tool_readback = {}
    for name, item in protocol['available_system_tools'].items():
        data = Path(item['path']).read_bytes()
        check(sha(data) == item['sha256'] and len(data) == item['bytes'], 'current tool matches preparation: ' + name)
        tool_readback[name] = {'path': item['path'], 'bytes': len(data), 'sha256': sha(data)}
    benchmark_pins = {
        'baseline-run-001/result.json': '42687690b436cbfdb4da6e2d7699ac1e4d789b8a9f68a0b92505b14999b00092',
        'input-only-tasks-001/result.json': '3ee1b45b69d33b69a67b1fee638df5290aa19dc17f55890756accf4126944546',
        'retrieval-tasks-001/result.json': 'cc9c91f93713214187c70bb7baf76cd56f09d4e5a5a13a63d5a64fff7969d912',
        'model-budget-run-001/result.json': '5cde385cec6f760bda917b882681c04d9d1dd8cc32a34daf239a74bdb88f0ba0',
    }
    for relative, expected in benchmark_pins.items():
        check(sha((WORK / relative).read_bytes()) == expected, 'unchanged A/B result: ' + relative)
    audit = {'schema': 'hepta.codec-engineering.read-only-audit.v1', 'passed': True, 'checks': len(checks),
             'failures': [], 'source_commit': COMMIT, 'source_tree': TREE, 'source_files': 25, 'source_bytes': 220039,
             'protocol_sha256': PROTOCOL_SHA, 'source_manifest_sha256': MANIFEST_SHA,
             'driver_sha256': sha(original['run_followup.py']), 'raw_result_sha256': sha(original['run-001/result.json']),
             'rows_recomputed_from_raw_logs': observed, 'current_tool_readback': tool_readback,
             'tool_identity_boundary': 'Preparation and packaging hashes agree. Original driver does not retain separate per-tool exec-time hash/PID attestations.',
             'A_B_result_hashes_unchanged': benchmark_pins, 'extra_test_or_model_calls': 0,
             'audit_method': 'Standard-library hashes, AST parsing and raw log/result comparison; no module import or discovery execution.',
             'not_qualified': ['A/B repair', 'model benefit', 'strong RAG', 'common-budget outcome', 'original hosted installation']}
    readme = f'''# Codec environment engineering follow-up

The unchanged historical codec tests reproduce a false green with an empty
`PATH`: the process exits zero while all 21 tests are skipped. With existing
FFmpeg, ffprobe and OpenSSL available, the same original 21 tests execute and
pass with zero skips. This separate environment replay earns no A/B task-repair
or model-benefit credit.

## Actual recorded outcomes

| Environment | Process exit | Discovered | Passed | Skipped | Process wall time |
|---|---:|---:|---:|---:|---:|
| `PATH=""` | 0 | 21 | 0 | 21 | 0.116491 s |
| `PATH="/usr/bin:/bin"` | 0 | 21 | 21 | 0 | 11.383619 s |

Both executions report zero failures, errors, expected failures and unexpected
successes, without a timeout. The negative arm meets its registered environment
observation; it is not successful test coverage. The positive unittest log
reports 11.305 seconds; process wall time also includes startup and coordinator
timing. Neither measure is a general performance result.

The same absolute Python executable, test argv, source directory and 300-second
per-command ceiling were specified before replay. Each arm ran once without an
automatic retry. The discovery pattern `test_*media*.py` covers eight decoded
media tests, six media-type tests and seven signed-media bridge tests. The
unchanged source invokes real codec and OpenSSL subprocesses and uses generated
signal fixtures. Those fixtures are not neural model outputs.

## Exact original source and protocol

- Source commit: `{COMMIT}`.
- Source tree: `{TREE}`.
- Source closure: 25 files, 220,039 bytes, including original fixture helpers.
- Source-manifest SHA256: `{MANIFEST_SHA}`.
- Frozen protocol SHA256: `{PROTOCOL_SHA}`.
- Actual result SHA256: `{audit['raw_result_sha256']}`.

The original manifest, protocol, driver, source-before/source-after records,
command/PID/start receipts, stdout, stderr and result files are preserved
byte-for-byte. Current source matches all 25 original Git blob SHA1 and SHA256
values, and both execution-time source inventories match that manifest. The
launch receipt binds the exact driver and frozen protocol.

The original CI observation is
[run 39964510679, job 120450755349](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/39964510679/job/120450755349).
This local replay does not qualify that hosted workflow's installation process
or transfer a pass to any queued or unrelated CI run. No package installation
was part of this replay; it exposed tools already available on this host.

## Evidence and packaging audit

Download [codec-engineering-followup.tar.gz](codec-engineering-followup.tar.gz)
and verify its SHA256 against [evidence-manifest.json](evidence-manifest.json)
before extraction. The archive root is `{PREFIX}/`. `raw/` contains every
original file. `MANIFEST.json` records member hashes and original path mappings;
[members.jsonl](members.jsonl) gives one record per payload member.

[audit.json](audit.json) records {len(checks)} successful read-only comparisons, including
exact test names/statuses from both raw stderr logs, command/PID bindings,
source/driver identities and unchanged A/B result hashes. These are artifact
comparisons, not newly executed tests. Packaging did not import test/model
modules, run discovery, invoke codec tools or call a model. Every archive
member was then byte-verified with normalized tar/gzip metadata.

The three tool hashes at packaging agree with preparation. The original driver
does not retain separate exec-time hash/PID traces for each FFmpeg, ffprobe or
OpenSSL subprocess. Installed binaries and their complete dynamic runtime are
external dependencies; the archive contains source and receipts.

## Scope preserved

A/B protocols, source seals, budgets, predictions, success metrics and original
gate coverage remain unchanged. This follow-up is not a learned repair, new
prospective task, strong retrieval baseline or equal-budget comparison. It
establishes the two declared local environment observations. Model calls are
zero and memory-repair credit is false. The source manifest's preparation flags
remain historical observations; `raw/run-001/result.json` is the later completed
execution record. The replay occurred after the frozen B model execution and
is excluded from the B cost ledger and all A/B outcome denominators.
'''
    payload = {f'{PREFIX}/raw/{name}': (data, str(SOURCE / name)) for name, data in original.items()}
    payload[f'{PREFIX}/README.md'] = (readme.encode(), 'generated publication report')
    payload[f'{PREFIX}/audit.json'] = (encode(audit), 'generated read-only artifact audit')
    payload[f'{PREFIX}/package_codec_followup.py'] = (Path(__file__).read_bytes(), str(Path(__file__)))
    members = [{'path': name, 'bytes': len(data), 'sha256': sha(data), 'git_blob_sha1': blob(data),
                'mode': '100644', 'original_path': origin} for name, (data, origin) in sorted(payload.items())]
    member_lines = ('\n'.join(json.dumps(row, ensure_ascii=False, sort_keys=True) for row in members) + '\n').encode()
    archive_manifest = {'schema': 'hepta.codec-engineering.archive-members.v1', 'source_commit': COMMIT,
                        'source_tree': TREE, 'original_file_count': len(original), 'payload_member_count': len(members),
                        'members': members, 'manifest_self_hash': 'Pinned by external evidence-manifest.json; no circular hash.'}
    payload[f'{PREFIX}/MANIFEST.json'] = (encode(archive_manifest), 'generated member manifest')
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', filename='', mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, (data, _) in sorted(payload.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.uid, info.gid, info.mtime = len(data), 0o644, 0, 0, 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data))
    archive = buffer.getvalue()
    verified = set()
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
        for member in tar:
            path = PurePosixPath(member.name)
            check(member.isfile() and not path.is_absolute() and '..' not in path.parts and member.name not in verified, 'safe unique member: ' + member.name)
            check(tar.extractfile(member).read() == payload[member.name][0], 'exact member: ' + member.name)
            verified.add(member.name)
    check(verified == set(payload), 'complete archive membership')
    for name, data in original.items():
        check((SOURCE / name).read_bytes() == data, 'original unchanged after packaging: ' + name)
    OUTPUT.mkdir()
    for name, data in {'README.md': readme.encode(), 'audit.json': encode(audit), 'members.jsonl': member_lines,
                       'codec-engineering-followup.tar.gz': archive}.items():
        (OUTPUT / name).write_bytes(data)
    external = {'schema': 'hepta.codec-engineering.publication-evidence.v1', 'source_commit': COMMIT,
                'source_tree': TREE, 'archive_path': 'codec-engineering-followup.tar.gz', 'archive_bytes': len(archive),
                'archive_sha256': sha(archive), 'archive_member_count': len(payload), 'original_file_count': len(original),
                'archive_manifest_sha256': sha(payload[f'{PREFIX}/MANIFEST.json'][0]), 'all_members_byte_verified': True,
                'members_jsonl_sha256': sha(member_lines), 'read_only_audit_sha256': sha(encode(audit)),
                'README_sha256': sha(readme.encode()), 'original_result_sha256': audit['raw_result_sha256'],
                'original_files_unchanged': True, 'extra_model_or_test_execution': 0,
                'archive_normalization': 'sorted regular members; tar uid/gid/mtime=0, mode=0644; gzip empty filename and mtime=0',
                'scope': 'separate local environment replay; no A/B metric, gate coverage, budget or repair-credit changes'}
    (OUTPUT / 'evidence-manifest.json').write_bytes(encode(external))
    files = []
    for path in sorted(OUTPUT.iterdir()):
        data = path.read_bytes()
        binary = path.suffix == '.gz'
        files.append({'path': f'{TARGET}/{path.name}', 'local_path': str(path), 'bytes': len(data), 'sha256': sha(data),
                      'git_blob_sha1': blob(data), 'mode': '100644', 'lines': None if binary else len(data.splitlines()), 'binary': binary})
    publication = {'schema': 'hepta.codec-engineering.publication-ready.v1', 'repository_target': TARGET,
                   'files': files, 'text_lines': sum(row['lines'] or 0 for row in files), 'source_commit': COMMIT,
                   'archive_sha256': sha(archive), 'remote_mutation_owner': 'root', 'agent_remote_writes': 0,
                   'stage': 'preserve independent original codec environment replay evidence'}
    destination = WORK / 'codec-publication-ready.json'
    destination.write_bytes(encode(publication))
    print(json.dumps({'manifest': str(destination), 'manifest_sha256': sha(destination.read_bytes()),
                      'archive_bytes': len(archive), 'archive_sha256': sha(archive), 'members': len(payload),
                      'original_files': len(original), 'audit_comparisons': audit['checks'], 'publication_text_lines': publication['text_lines'],
                      'files': files}, sort_keys=True))


if __name__ == '__main__':
    main()
